# Frozen Document.title replay

The source is the independently authored twelve-case `documentTitleCases`
collection, retained byte-exact with its literal arrays, original audit and
review history. Each named body is invoked in a fresh adapter process in sloppy
and strict mode: twenty-four ordinary-success modes. It must return true and
complete normally; no expectation is replaced with a resource or unsupported
outcome.

Four positive/wrong pairs each run in both modes, for sixteen controls:

* literal exact JavaScript UTF-16 units;
* genuine Text identity and existing exact Node data mutation;
* existing CharacterData setter conversion order, thrown-marker identity and
  retained author mutation;
* an ordinary Document.prototype.title descriptor whose setter keeps raw exact
  data and whose getter normalizes ASCII whitespace.

Each wrong body is its exact positive prefix followed by a deliberate intrinsic
Error. Prerequisite assertions throw TypeError. The declared Error identity
therefore distinguishes the deliberate wrong tail from a failed prerequisite.
Successful DOM operations are part of the guards. The title pair deliberately
requires the proposed feature; no baseline match count is assumed.

`replay.py --prepare` creates the immutable matrix exclusively. `--verify`
reconstructs every input identity and checks the bindings without invoking an
engine. The bounded adaptation from the held append runner is retained in
`runner-preparation/adaptation.diff`; helper ownership, expectations, mode
handling, limits and failure retention are inherited.

Missing, null, nonobject and empty observations cannot match an expectation.
Unexpected runner exceptions become retained runner-error rows; the complete
report is written before the wrapper exits with code 3. Post-run source,
matrix and binary changes are retained as binding failures and exit with code
2. An ordinary expectation mismatch remains a complete observation, not an
infrastructure failure. Exclusive output creation never overwrites a prior
report.

The existing Test262 `run_case` remains sequential with a three-second deadline,
96 KiB stdout and 64 KiB stderr bounds. Its inherited helper terminates a live
direct process and waits in cleanup. This wrapper does not broaden descendant
supervision, raw stream retention, interpreter limits or any baseline policy.

After root source review, the baseline command is:

```sh
python3 /tmp/eris-document-title-1/replay.py /tmp/eris-append-domstrings-1/eris-js 71bb4c92d432ed247c483cf588d1cebaae9364194c5e9d0ed45c1c44b44a47b0 /tmp/eris-document-title-1/title-before.json
```

A candidate uses the same held matrix and explicit independently checked binary
digest, with a different fresh output path. Preparation performs no engine or
compiler execution and does not alter main/worktree sources.
