# Independent title cases

`cases.js` defines `documentTitleCases`. Evaluate the held complete source and
invoke exactly one named body in each fresh realm, separately in sloppy and
strict modes. Every body must return `true` with ordinary runtime completion.
The inventory contains twelve bodies / twenty-four modes. No fixture, parser,
engine or compiler execution has occurred during authorship.

The source itself contains the literal UTF-16 arrays. `cases.json` repeats those
arrays for review and binds the complete source, names, modes and success
expectation; it does not derive expected data from an engine. Cases cover:

1. Direct Text-only ASCII collapse across Comments and an excluded descendant.
2. Cross-child surrogate pairing, isolated units, NBSP and vertical tab.
3. Exact raw setter data, normalized reads, fresh replacement Text, retained
   detached descendants, repeated equal assignment and empty replacement.
4. Literal null/undefined spelling, missing accessor argument, Symbol rejection
   and an unchanged thrown marker after a visible author mutation.
5. String-hint conversion and a newly selected title after a callback replaces
   the previous target.
6. Connected order, detached titles, template ordinary children and the separate
   template content tree.
7. Empty missing-title creation at the end of head, existing title without head,
   and conversion when neither head nor title exists.
8. HTML-namespace non-html root selected after coercion replaces the root;
   a descendant head does not supply document.head.
9. No-root and MathML-root setters still convert; the getter under the foreign
   root can read an HTML title although that setter branch ignores the value.
10. SVG root selects only the first direct SVG title, preserving nested,
    wrong-namespace and later title nodes.
11. Missing SVG title is created before the original first child, even for an
    empty value, and subsequent assignment reuses that title element.
12. Ordinary prototype metadata, genuine receiver brands before conversion,
    own shadows, replacement receivers, deletion without fallback resurrection,
    saved intrinsic calls and restoration.

Setup uses source-verified existing APIs: createElement, Text/Comment,
append/appendChild/removeChild on genuine Nodes, ordinary descriptors,
namespaceURI/nodeName, exact Node textContent and scalar innerHTML parsing.
There is no dependency on createElementNS, Document.removeChild, Document own-key
enumeration, independent Document construction or a synthetic Node(root) alias.

Alternate roots come from detached scalar `<svg>`/`<math>` fragments; setup
checks their actual namespace and node name. A saved, callable Document.append
first succeeds with no arguments. Appending the current root plus a real Text
then must produce the already-supported hierarchy exception after fragment
assembly; both exception identity fields and actual root detachment are checked.
This is setup for title selection, not a title success inferred from an
incidental exception. Each such case owns its fresh realm, so it need not restore
the previous root. No browser witness shares those altered documents.

The largest body is the descriptor group; no body contains unbounded loops or
bulk data. Shared helpers only walk small literal arrays. The full collection is
about 15 KiB and each invocation runs one body. These are source-level bounds,
not a measured claim that parser/runtime quotas suffice. Preserve any future
ordinary-success mismatch or resource refusal without rewriting expectations.

Policy cutpoints, bootstrap allocation, Page/worker title projection and URL
fallback, reactions, CDATA and independent document ownership are separate
tests or missing scope. These ordinary cases do not claim those features.

Normative sources independently read for the assessment:
[HTML title](https://html.spec.whatwg.org/multipage/dom.html#document.title),
[DOM child text content](https://dom.spec.whatwg.org/#concept-child-text-content),
[Infra ASCII collapse](https://infra.spec.whatwg.org/#strip-and-collapse-ascii-whitespace),
and [Web IDL accessors](https://webidl.spec.whatwg.org/#es-attributes).
