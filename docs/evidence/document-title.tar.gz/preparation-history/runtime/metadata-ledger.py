# Source arithmetic only. This does not execute or compile browser/runtime code.
import json,pathlib
base=pathlib.Path(__file__).parent

def bound(n):
    if not n:return 0,0
    c=(n+1)//2;h=1
    while c>=6:c//=6;h+=1
    return min(n,11*h),h

def moves(n):return n+8 if n<11 else 28*(bound(n)[1]+1)
def prop(n,k):return bound(n)[0]*(1+len(k))+moves(n)+1
functions=[{'name':'DOM.Title.'+verb,'display':verb+' title'} for verb in ('get','set')]
for row in functions:row['work']=85+2*len(row['display'])+len(row['name'])
rows=[]
for n,key in enumerate(['querySelector','querySelectorAll','append','createProcessingInstruction','constructor'],2):
    rows.append({'key':key,'old_count':n,'new_count':n+1,'work_delta':prop(n+1,key)-prop(n,key)})
attribute=8+2*len('title')+prop(2,'title')
work=4+sum(row['work'] for row in functions)+attribute+sum(row['work_delta'] for row in rows)
result={'status':'prediction only; no implementation or measured bootstrap','assumptions':['Document title is installed after the two symbol properties and before ParentNode operations','Two cached native bags follow node_data_function with DOM.Title.get/set names','The new installer is called once for Document and charges work(4)','Document prototype order capacity grows from 7 to 8; both native bags reserve 2','No global/native-name/prototype registry entries are added; all subsequent code unchanged'], 'functions':functions,'new_title_property_work':attribute,'later_document_property_deltas':rows,'installer_fixed_work':4,'predicted_work_delta':work,'prior_measured_raw_remaining':6640,'predicted_raw_remaining':6640-work,'objects_before':677,'objects_after':679,'typed_storage_delta':'2*sizeof(ScriptObject) + 2*(72+sizeof(Option<AbortSlot>)+sizeof(Option<f64>)) + 5*sizeof(PropertyKey) + 2*node_bytes<PropertyKey,Property> + 2*sizeof(Native) + 2090','prior_measured_allocated':1798334,'measured_result':'pending future implementation and first bootstrap check'}
# Per bag: display(100), length key+property(88+280), name key+property(80+272), native-name fixed(32+13) = 865.
# Two bags + title key/property(84+276) = 2090, apart from typed blocks above.
(base/'metadata-ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
