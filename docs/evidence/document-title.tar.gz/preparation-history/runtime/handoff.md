# Document.title runtime handoff

Source-only preparation against published `c47fe953a97c45f98045f1f75e43587e50479110` plus the isolated append delta now integrated for root validation. No implementation, fixture changes, compiler or engine runs accompany this plan. Initial audit and layout assessment remain unchanged. Append does not touch the title paths.

## Small implementation boundary

Add `src/script/document_title.rs` and a narrow `src/dom/title.rs`. Re-export only the needed title types within the crate and widen the existing DomMutationBudget work/charge methods only to their DOM parent module so the sibling helper can reuse identical debit semantics. Install one ordinary enumerable/configurable accessor on Document.prototype, before its represented operations and constructor. Its getter/setter have names `get title` / `set title`, lengths 0/1, Function.prototype inheritance, separate mutable cached bags and no own prototype. Use internal names **DOM.Title.get / DOM.Title.set**: DOM.Document.* would collide with the existing broad ParentNode native preflight (DOM.D*/DOM.E*). Add the usual charged invocation-name bridge inside stack cleanup and scoped native dispatch; no generic registry or new global.

Remove both virtual Document title branches in script.rs and only the `(document && key == "title")` exception in dom_own_properties.rs. Keep the HTMLElement attribute rule. Otherwise ordinary assignment bypasses prototype replacement/deletion. Own descriptors retain priority, saved accessors retain authentic receivers, and deleting the prototype descriptor must expose ordinary inherited lookup/expando behavior without resurrecting a virtual title. Do not modify `first_html_element` globally: layout uses it for unrelated html/body selection.

Brand before conversion: accept the authentic singleton Document, defensively checking its real root kind; an authentic `Value::Node(doc.root)` alias can use the same root, while forged objects/inheritors, ordinary Elements and invalid IDs throw TypeError. No prototype walk confers this brand. Setter missing argument becomes undefined and uses ordinary `string_hint` exactly once: null becomes "null", undefined becomes "undefined", Symbols throw, objects retain conversion side effects. Extra arguments are ignored. Conversion occurs even when the eventual branch ignores the string. Reacquire every root/title/head decision afterward.

## Shared selection and normalized reading

Suggested local APIs (names may be simplified during implementation):

```rust
enum TitleMode { Read, Write }
enum TitleTarget {
    None,
    Existing(NodeId),
    Create { parent: NodeId, namespace: Namespace, first: bool },
}
fn title_target(&self, mode: TitleMode, budget: &mut DomMutationBudget)
    -> Result<TitleTarget, DomDataError>;
fn plan_title_text<'a>(&'a self, target: NodeId, maximum_units: usize,
    budget: &mut DomMutationBudget) -> Result<TitleTextPlan<'a>, DomDataError>;
```

The read mode returns only None/Existing. Find the document element from actual Document children. For SVG svg, inspect only its immediate children for the first SVG title. Every other getter branch finds the first connected HTML title in ordinary document tree order, even when the corresponding setter would ignore its input. For the writer, a non-SVG, non-HTML root (or no root) returns None immediately after conversion. Under an HTML-namespace root, use an existing connected HTML title; only if absent consider creation. A head is valid only as an immediate HTML head child of an HTML html document element. A non-html HTML root can update an existing title but cannot invent a head. SVG creation prepends; HTML creation appends to the actual head.

Use one iterative selector for Runtime and host metadata. Scan reached nodes/edges, stop on the first match, and never scan detached arena entries. Traverse ordinary template children, never template.content or host links. A small fallibly grown `(node, next_child_index)` stack avoids allocating/zeroing a whole-arena bitmap or copying every wide sibling list before an early title match. Pay each inspected node, child edge, constant namespace/name comparison, frame push/pop, and actual stack growth/copy before that operation. Bound visits by the existing MAX_NODES and stack depth by existing MAX_DEPTH; validate IDs and parent links. The model's tree invariants come from checked snapshots/mutators; do not claim this bounded selector independently validates every possible malformed duplicate graph. No recursion or persistent selection cache.

The plan retains the borrowed document/target and counts direct Text children only. Comments, PI and nested Elements contribute no units or separators. Normalize TAB/LF/FF/CR/SPACE with `started` and `pending_space` state across child boundaries: emit one pending SPACE only when a later non-space arrives, discard leading/trailing runs. Preserve vertical tab, NBSP, all other units, and isolated surrogates. A high/low pair may cross an excluded Comment or Element. Decode only the final normalized stream for presentation.

Plan and emit must be two paid passes over the same immutable direct-child sequence, with no callback between them. A concrete conservative per-pass ledger is fixed8 + 4 per inspected direct child + each contributing DomString's stored_bytes (decode traversal bound) + 4 per decoded input unit (whitespace/state handling); charge attempted EOF/state finish too. The emission pass additionally pays output-unit writes and the JsString Rc copy. Check arithmetic and normalized output length <= MAX_STRING before allocation; permit a long whitespace-only input when its scan budget fits. Prepay `64 + 4*output_units` for Vec+Rc as existing exact getters do, reserve the Vec exactly, then construct the shared JsString. Do not build a descendant aggregate or cache a second payload. Final fee constants must be reviewed against the concrete iterator before implementation is held.

Host `Document::title()` uses the same selector and normalized stream, then bounded replacement projection. Keep its existing 8 MiB scalar output bound and valid-prefix truncation policy, including carried surrogate state across selected Text children; avoid per-node replacement. Shared helper metering can use a local DomMutationBudget counter for host calls with no author-turn debit, while the structural/output bounds still cap actual work and allocation. Runtime passes its real absolute counters and copies them back on **both** result paths; no resets or refunded scratch. Page::title keeps URL fallback for an empty normalized title; whitespace-only titles newly activate that existing fallback. Worker retains its 512-scalar-character limit and browser its application suffix. No wire-format change. Runtime exact getter must never call the host replacement projection.

## Setter phases and the missing creation seam

1. Authenticate and convert once, then perform the paid fresh write selection. None returns before payload planning/admission.
2. Existing target: plan canonical payload from the retained JsString; fresh `check_text_content_replacement`; emit; `replace_text_content_owned` with absolute counters copied back on success/error. This is the current Node container path, including retained old descendants, base/details effects and no old-subtree storage credit. Store the raw input, not its whitespace-normalized getter form.
3. Missing target: create a checked empty title of the selected namespace, insert it at the required location, **then** plan/replace its contents. Do not preflight the eventual Text ahead of this reached creation/insertion prefix. Empty input still creates the missing title but no Text. At one remaining arena slot, the title may be inserted and the later nonempty Text refused; retain that prefix.

The existing raw create_element_ns filters/copies a tag and may return the document root on refusal; raw append also allocates internal traversal and child storage, and there is no checked insert-before primitive. Thus the only genuinely new DOM mutation prerequisite is a narrow creation/insertion seam for a fresh empty HTML/SVG title, not a general insertBefore implementation:

```rust
fn create_title_element(&mut self, namespace: Namespace,
    budget: &mut DomMutationBudget) -> Result<NodeId, DomDataError>;
fn insert_title_element(&mut self, parent: NodeId, title: NodeId, first: bool,
    budget: &mut DomMutationBudget) -> Result<(), DomDataError>;
```

Creation checks node/retained-tag bytes, prepays the five-byte owned tag, logical node allowance and actual typed arena growth, fallibly reserves last, then publishes the detached empty node. Insertion checks the selected parent shape and the authentic empty/detached title, pays bounded ancestry/depth and exact child-vector growth plus front-shift work, reserves before mutation, then changes child list/parent together. An insertion resource refusal leaves the already created detached title; a later replacement refusal leaves the inserted empty title. No callbacks occur across these private phases. Adding a fresh empty title to the actual HTML head or SVG root neither moves existing details nor introduces/removes a base; document that narrow hook exemption rather than calling the broad unaccounted raw mutator. Existing-title replacement still uses all checked Node hooks. Preserve the DOM ledger and do not silently alias root on any refusal.

## Predicted bootstrap and limits

`metadata-ledger.json` evaluates existing fee formulas for the placement above. Two cached bags cost116work each; the title property41; the once-only installer4; increased Document property-search/movement counts add83 across querySelector/querySelectorAll/append/createProcessingInstruction/constructor. Predicted total **+360 work**, raw remaining **6640 -> 6280**, objects/capacity **677 -> 679**, unchanged321 native-registry/25 legacy-prototype entries. This is source arithmetic, not a measured success.

The storage delta is
`2*sizeof(ScriptObject) + 2*base_object_charge + 5*sizeof(PropertyKey) + 2*node_bytes<PropertyKey,Property> + 2*sizeof(Native) + 2090`.
It includes the enlarged initial arena block, both metadata order buffers, one extra Document order slot, two empty-tree node allowances and every static key/display/native-name debit. No later split threshold is crossed by the proposed Document placement. Measure actual charged bytes and exact/one-short raw bootstrap after implementation; do not blindly change snapshots or any 100000-work/8MiB-runtime-heap/DOM limits. Public author-entry reset sites stay exact.

## Verification and retained boundaries

Preserve existing scalar and exact-getter tests; their no-whitespace direct-Text outcomes remain correct. Add independent cases only after approval to implement: attribute flags/order/identity, own shadows and prototype deletion/replacement, forged brands before conversion, missing/null/undefined/Symbol, callback root/title/head changes, direct-child normalization including split pairs and ignored children, ordinary template children versus content, all getter/writer namespace branches, and load/click host fallback/512-character metadata. Root/layout's separately authored title cases may serve as independent inputs; none were executed here.

SVG/no-root/non-html-root cases need no new API: parse foreign elements, save references, move the original html into a fragment, then append an existing SVG/MathML or freshly created HTML element as document element; a fragment move also gives a no-root document. Snapshot/native setup can cover internal corruption/capacity boundaries separately. Do not require Document.removeChild/createElementNS merely to construct a test.

Measure exact/one-short getter plan/emit, creation, insertion and replacement work/heap with both spare and full vectors; retain consumed budgets and no-publication/current-prefix assertions. Explicitly test empty-at-node/byte-cap, title-only-last-slot prefix, callbacks consuming the final slot/bytes, no normalization of stored text, and cleanup/no catch/finally on terminal resource failure. General Document named properties, independent document ownership, unrepresented CDATA, custom-element reactions/observers/ranges, and unrelated virtual attributes remain gaps. Existing checked replacement's std BTree allocation recovery and inherited URL parsing/allocation limits remain qualified; this title change does not solve them.

Primary text checked for this plan: [HTML title/tree accessors](https://html.spec.whatwg.org/multipage/dom.html#document.title), [DOM child text content and replacement](https://dom.spec.whatwg.org/#concept-child-text-content), [Infra ASCII whitespace](https://infra.spec.whatwg.org/#strip-and-collapse-ascii-whitespace). Descriptor/argument behavior follows the existing reviewed [Web IDL attributes](https://webidl.spec.whatwg.org/#es-attributes) model.
