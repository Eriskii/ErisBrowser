# Document.title follow-up audit

Read-only next-work assessment against published c47fe953a97c45f98045f1f75e43587e50479110, while exact ParentNode.append implementation proceeds separately. No source edits, compiler, browser or fixture execution accompany this note.

## Normative scope

The HTML Document extension declares title as a DOMString attribute with reactions. Reading selects the first immediate SVG title child when the document element is SVG svg; otherwise it uses the first HTML title in document tree order. Only direct Text children contribute. ASCII whitespace is stripped/collapsed. Writing to SVG creates a missing SVG title as first child; writing under an HTML-namespace root updates an existing HTML title or creates one under the head, if available. Other roots ignore the converted input. The selected title receives string replacement. These branches must be selected after conversion effects. [HTML title](https://html.spec.whatwg.org/multipage/dom.html#document.title), checked 2026-10-02.

## Current implementation findings

* `src/script.rs` virtual Document title getter finds the first HTML title and calls the exact **descendant** text reader, without whitespace normalization. The exact getter foundation test has no spaces or nested elements, so it does not cover these distinctions.
* The title setter still calls scalar `dom_string`, losing unpaired units. It then selects/creates an HTML title with parser-oriented raw element/append helpers and uses legacy `set_text_content`. It has no SVG-root or other-root branch, requires a spare Text even for empty assignment, and does not use the staged Node replacement helper.
* `src/dom.rs::Document::title` is a separate presentation getter with the same HTML-only descendant selection. Browser/page and worker metadata use it; changing only JavaScript reads leaves user-visible titles inconsistent.
* `Document::first_html_element` allocates a DFS Vec and BTreeSet without the runtime’s per-reached-scan accounting. A bounded title selector should avoid importing an uncharged arena traversal into new ordinary accessors.

## Proposed narrow follow-up, subject to separate review

Implement ordinary Document.prototype title accessors together with exact reads/writes and matching presentation metadata. This should be a separate checkpoint after append, not an extension of its source delta. Keep existing title/DOMString sources and observations as baseline evidence.

A shared title-target selection helper should distinguish getter/write cases and namespace/root conditions without cloning the DOM. Runtime scanning should charge reached child/ancestor steps and explicit scratch; use parent/child frames or a bounded paid stack, and validate graph assumptions. Preserve template content as a separate tree. SVG selection scans only root children and tests both namespace and local name. HTML lookup stops at the first connected applicable title.

Read exact units from direct Text children in order. A two-pass bounded UTF16 output can normalize only units9,10,12,13,32, retaining U+000B, NBSP, other Unicode spaces and unpaired units. State must cross direct Text boundaries and excluded Comments. Plan exact output length before reserving and pay both traversals. Presentation projects this same normalized sequence with replacement only at the external scalar boundary; it must not rewrite stored data.

Setter conversion uses ordinary DOMString, including literal null/undefined strings and exceptions even for ignored roots. Reacquire target/root/head after author callbacks. Existing target replacement can use the admitted canonical builder and `replace_text_content_owned`, passing/returning actual absolute counters on both outcomes. Missing-title creation additionally needs paid constant tag/namespace construction, typed arena growth and correct first-child/append insertion before the replacement step. Preserve and test the reached failure prefix; no global rollback or widened allowance. Existing general insertion allocator limitations must remain explicit until those paths are redesigned.

Bootstrap costs for two accessor functions and insertion ordering need source prediction and measured confirmation. Delete/shadow behavior must not resurrect the old virtual implementation. Genuine Document brand must precede author conversion; forged prototype objects do not gain a brand. Complete Document ownership, named properties and reaction queues remain separate work.

## Independent cases to author before implementation

1. Exact setter data, fresh replacement Text and retained old children; null/undefined/Symbol and conversion throw prefixes.
2. Cross-child whitespace collapse, ignored nested-element text, Comments, NBSP/vertical-tab preservation, unpaired units and split pairs.
3. First connected HTML title versus detached/template titles; duplicate title ordering; missing head/title and empty values.
4. HTML-namespace non-html roots, no root, and non-HTML/non-SVG roots with coercion still observable.
5. SVG-root direct-title selection, nested SVG title exclusion, namespace distinction, creation at first child and exact replacement.
6. Ordinary descriptor metadata/shadow/delete and saved intrinsics with authentic/fake receivers.
7. Work/heap/node/retained-byte refusal boundaries, callback-fresh target selection, new-title prefix and runtime cleanup.
8. Matching Page and worker title metadata after load/click while stored raw Text whitespace remains unchanged.
