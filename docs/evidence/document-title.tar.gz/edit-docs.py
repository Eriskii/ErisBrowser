from pathlib import Path
import json,hashlib,shutil
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
A=Path(__file__).resolve().parent
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/node-data.md','docs/dom-production.md','docs/append-domstrings.md','docs/dom-strings.md','docs/VALIDATION.md']
for path in paths:
 p=R/path;b=A/'documentation-before'/path;b.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,b)
 def change(old,new):
  global s
  assert old in s,(path,old)
  s=s.replace(old,new)
 s=p.read_text()
 if path=='README.md':
  change('prefixes. Other legacy writers, complete interface members and Document reflection','prefixes. [Document.title](docs/document-title.md) now has ordinary accessors,\nexact normalized reads and staged raw-text replacement for HTML and SVG roots.\nOther legacy writers, complete interface members and Document reflection')
  change('arguments after all conversions finish. Legacy `innerText`, title/textarea\nsetters and attribute writes, HTML parser input','arguments after all conversions finish. [Document.title](docs/document-title.md)\nnow preserves exact strings through ordinary accessors and normalized reads.\nLegacy `innerText`, textarea setters and attribute writes, HTML parser input')
 elif path=='docs/COMPATIBILITY.md':
  change('for Document, Element and DocumentFragment. Its validation remains pending.','for Document, Element and DocumentFragment; all fourteen new modes pass.\n[Document.title](document-title.md) adds ordinary prototype accessors, exact\nASCII-whitespace-normalized reads, HTML/SVG selection and staged replacement.')
  change('separate Texts. Legacy `innerText`, title/textarea setters, attribute and','separate Texts. [Document.title](document-title.md) adds exact raw writes and\nnormalized direct-Text reads. Legacy `innerText`, textarea setters, attribute and')
  change('[Node data assignment](node-data.md), [append arguments](append-domstrings.md),','[Node data assignment](node-data.md), [append arguments](append-domstrings.md),\n[Document.title](document-title.md),')
  change('legacy `innerText`, title/textarea setters and HTML-parser writes can still','legacy `innerText`, textarea setters and HTML-parser writes can still')
 elif path=='docs/ROADMAP.md':
  change('validation is pending. Legacy `innerText`, title/textarea setters and attribute','all fourteen new modes pass. [Document.title](document-title.md) adds ordinary\naccessors, exact normalized reads, HTML/SVG selection and retained failure\nprefixes. Legacy `innerText`, textarea setters and attribute')
  change('remaining legacy innerText/title/textarea, attribute and parser','remaining legacy innerText/textarea, attribute and parser')
 elif path=='docs/SECURITY.md':
  change('string arguments. Legacy `innerText`, title/textarea setters, attribute and','string arguments. [Document.title](document-title.md) uses the same exact\nbuilder and checked replacement after conversion and current-tree selection.\nLegacy `innerText`, textarea setters, attribute and')
  change("The parser's internal insertion path is unchanged. This does not add arbitrary", "[Document.title](document-title.md) separately prepays incremental selection,\nnormalized direct-Text reads and narrow empty-title creation/insertion. A later\nrefusal preserves the completed creation/insertion prefix. Host projection has\na finite bound derived from document limits; author quotas and reset points are\nunchanged. Existing-target replacement retains the Node helper's allocation\nlimitations.\nThe parser's internal insertion path is unchanged. This does not add arbitrary")
 elif path=='docs/node-data.md':
  change('Legacy `innerText`, title and textarea setters, attribute writes, HTML parser input, exact','The later [Document.title increment](document-title.md) migrates title writes\nand normalized reads. Legacy `innerText` and textarea setters, attribute writes, HTML parser input, exact')
 elif path=='docs/dom-production.md':
  change('migrate ParentNode.append. Neither migrates `innerText`, title/textarea setters\nor attribute writes. Those paths, HTML parser input, scalar form','migrate ParentNode.append. A further [Document.title increment](document-title.md)\nadds ordinary exact title accessors and normalized reads. Legacy `innerText` and\ntextarea setters, attribute writes, HTML parser input, scalar form')
 elif path=='docs/append-domstrings.md':
  change('exact attribute or remaining `innerText`/title/textarea writes, the dirty','exact attribute or remaining `innerText`/textarea writes, the dirty')
  change('adoption or full DOM compatibility.','adoption or full DOM compatibility. A later [Document.title increment](document-title.md)\nadds ordinary exact title accessors and normalized reads; it does not alter the\nappend checkpoint measurements above.')
 elif path=='docs/dom-strings.md':
  change('arguments and completed failure prefixes. Other legacy writers, including\n`innerText`, title/textarea setters and attributes, can still replace unmatched', 'arguments and completed failure prefixes. [Document.title](document-title.md)\nadds exact raw writes and normalized reads through ordinary accessors. Other\nlegacy writers, including `innerText`, textarea setters and attributes, can still replace unmatched')
 elif path=='docs/VALIDATION.md':
  s+='\n\n'+(A/'validation-documentation.txt').read_text()
 p.write_text(s)
shutil.copy2(A/'document-title-final.md',R/'docs/document-title.md')
shutil.copy2(A/'append-domstrings-ci.json',R/'docs/evidence/append-domstrings-ci.json')
paths+=['docs/document-title.md','docs/evidence/append-domstrings-ci.json']
rows=[]
for path in paths:
 b=(R/path).read_bytes();d=A/'final-documentation'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 rows.append(dict(path=path,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
(A/'final-documentation.json').write_text(json.dumps({'files':rows},indent=2)+'\n')
print('Updated',len(paths),'documentation/CI paths')
