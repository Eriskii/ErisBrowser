# Document.title browser witness

This is a new, unexecuted fixture. Load once, then dispatch two actual click events to `#change` without reloading the Page or worker generation. Use a 320 × 240 viewport. All six squares must be green, blue, then purple; inspect their literal sample coordinates in expected.json. Require empty script diagnostics in every phase and the body classes `ready`, `empty`, `long`.

The source contains a frozen literal of 511 uppercase ASCII A characters. The readiness proof counts that literal without evaluating JavaScript. It has no `String.prototype.repeat` dependency or repeated-concatenation setup loop. The long suffix consists of the literal UTF-16 units 0xD83D, 0xDE80, 0xD800: one rocket scalar followed by one isolated high surrogate.

## Three independent title observations

1. The page's JavaScript checks exact `document.title` units after strip/collapse of ASCII whitespace, the exact raw Text data, the ordinary saved accessor, and retained node identity. Phase 0 preserves NBSP and vertical tab while collapsing only tab/CR/LF/space; its leading isolated high surrogate remains exact. Phase 1 stores six ASCII whitespace units but the getter returns empty. Phase 2 retains all 514 units.
2. The direct Page test must inspect `Page::title()` separately: phase 0 is literal `A\u{fffd} B\u{00a0}\u{000b}`; phase 1 is the Page's URL string under the existing empty-title fallback; phase 2 is exactly 511 A characters, U+1F680, U+FFFD (513 scalars, 518 UTF-8 bytes). Do not obtain this expected string by decoding actual DOM units or calling the implementation's title helper.
3. The confined worker test must inspect `snapshot.title` directly. Phases 0 and 1 match the short Page metadata (use a fixture URL shorter than 512 scalars). Phase 2 is exactly 511 A characters followed by U+1F680, with no replacement-character tail: 512 scalars, 515 UTF-8 bytes, 513 UTF-16 units. This checks the existing `.chars().take(512)` cap independently of the full Page title and full raw/JavaScript string. Compare to literals/fixed repetition of the known ASCII constant in test code, not a prefix sliced from actual metadata.

## Snapshot identity and exact storage

Resolve the live `#subject`, `#change`, and `#status` nodes. Save their NodeIds plus the single status Text child at load; require the same IDs after each click. Read the subject's one direct Text child and compare its unit iterator to each phase's literal raw array. Save each title Text ID: each later assignment must install a different child, leave every old ID present and detached, and preserve its exact earlier payload. The whitespace-only phase still has a new Text child because its input is nonempty.

Find `id=old-title-branch` in the retained node arena, not through connected `getElementById`. Its parent stays absent; its Text and Comment child IDs and child-parent links remain unchanged. Their exact unit arrays are `[111,108,100,55296]` and `[56320]`. These checks distinguish direct-child detachment from recursively destroying the old subtree. They do not require complete Document own-key enumeration or absent Document child-list getters.

## Visible rendering witness

The connected status Text retains one NodeId and cycles through the exact unit arrays `[76,55296]`, `[66,56320]`, `[80,55296]`. The independent scalar references are literal `L�`, `B�`, `P�`. Inspect a matching text DrawCommand and compare the complete raster with a script-disabled Page built from the same snapshot after replacing only that Text payload with its scalar reference through public checked APIs. Both payload representations retain four bytes: two exact UTF-16 units versus one ASCII UTF-8 byte plus the three-byte replacement character. This avoids changing the retained-byte ledger for a snapshot model reference. Keep every other node and attribute intact, and require non-background glyph pixels near y=105..140 so agreement cannot be vacuous. Check the six squares separately.

The visible glyph strings are deliberately short. The 514-unit title belongs in DOM/host metadata assertions rather than a huge painted line. Worker snapshots must carry the exact raw data and detached nodes before reference construction; recheck the original snapshot after producing the reference.

## Scope

This fixture targets title normalization, exact storage, accessor behavior, fresh replacement Text identity, retained detached children, scalar UI projection, and the existing worker title cap. It makes no synchronous observer/CEReactions or dirty textarea claim. Existing Page URL fallback and worker scalar cap are expected policies, not new standards requirements. Source review and literal arithmetic do not establish execution cost or test success.

Normative references: [HTML document.title](https://html.spec.whatwg.org/multipage/dom.html#document.title), [DOM child text content](https://dom.spec.whatwg.org/#concept-child-text-content), [Infra ASCII whitespace](https://infra.spec.whatwg.org/#strip-and-collapse-ascii-whitespace), [WebIDL attributes](https://webidl.spec.whatwg.org/#es-attributes).
