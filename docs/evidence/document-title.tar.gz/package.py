import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def check(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def total(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(r[i]) for r in rows) for i in range(3)]
assert total('full-default-188-2')==[1672,0,0] and total('full-native-198-2')==[1795,0,0]
source=read('main-source-final.json');assert len(source['files'])==16
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'final-source'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
comparison=read('title-comparison.json');assert not comparison['validation_failures']
s=comparison['summary'];assert s['established']['cases']['unchanged']==4138 and s['established']['controls']['unchanged']==404
assert s['new']['cases']['before_healthy']==4 and s['new']['cases']['after_healthy']==24
assert s['new']['cases']['gains']==20 and s['new']['cases']['losses']==0 and s['new']['cases']['other_changes']==0
assert s['new']['controls']['before_healthy']==12 and s['new']['controls']['after_healthy']==16 and s['new']['controls']['gains']==4
ready=read('source-ready.json')
summary=dict(kind='Ordinary exact Document.title accessors',base_commit=source['base'],scope='Ordinary Document.title accessors preserve exact UTF-16, share normalized direct-Text selection with host presentation, handle HTML/SVG roots, and retain staged title creation/insertion effects under refusal.',source=source,release=release,final_validation={label:check(label) for label in ['full-default-188-2','full-native-198-2','clippy-native-198-2','clippy-presenter-188-1','format-198-final-2','release-adapter-188-1']},tests=dict(default=1672,native=1795,new_groups=35,final_passing_focused_commands_unique=78,final_passing_focused_commands_executions=82,initial_failed_bootstrap_command=dict(passed=22,failed=2),final_failed=0,final_ignored=0,all_build_and_test_commands_passed_first_attempt=False),raw_bootstrap=ready['bootstrap'],compatibility=dict(path='title-comparison.json',sha256=sha(BASE/'title-comparison.json'),summary=s),retained_preparation_history=['Before execution, source review corrected the Document-frame depth accounting to retain accepted edge depth 256. Host ceiling proof includes empty Text per-entry work.','Standalone formatting initially used edition 2021 and rejected existing 2024 let-chains; corrected edition passed.','First compile failed only on an ambiguous empty-array assertion; equivalent is_empty assertion corrected its type without changing expected behavior or production.','First bootstrap filter retained 22 passes and two stale-description failures. Three measured work/object-count literals were updated only after raw bootstrap measurement; no allowance/reset/admission changes.','All independent 24 ordinary case modes and 16 controls remain byte-bound to their baseline inputs. The only later production source rewrite collapsed nested title-selection conditions into a let-chain for strict Clippy; evaluation, budget and error ordering remained identical. Original source and failed lint log retained; both full suites rechecked final source.'],boundaries=['Existing Node replacement BTree/URL/encoding/IDNA and process-OOM limitations remain.','Legacy innerText/textarea setters, exact attributes, parser/scalar-source boundaries and dirty textarea state remain separate work.','Complete mutation reactions, independent document ownership, XML parsing and remaining DOM interfaces are incomplete.','Two original PI host-prototype mutation expectations remain unmet.','No new GPU performance or Chromium comparison. Full web compatibility and production security are not achieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p==BASE/'eris-js' or p.is_symlink() or name=='final-publication-review.json':continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/document-title.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
(ROOT/'docs/evidence/document-title.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
