import hashlib,json,shutil,subprocess
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
WORK=HERE/'worktree'
base='7765fbf8f44c3dea96b6a09316ea352f59a2a57d'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==base
assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()
source=json.loads((HERE/'source-ready.json').read_text())
files=source['files']
for row in files:
 b=(WORK/row['path']).read_bytes();assert hashlib.sha256(b).hexdigest()==row['sha256']
for row in files:
 p=row['path']; b=(WORK/p).read_bytes();d=ROOT/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
 s=HERE/'final-source'/p;s.parent.mkdir(parents=True,exist_ok=True);s.write_bytes(b)
 assert hashlib.sha256(d.read_bytes()).hexdigest()==row['sha256']
final={'base':base,'files':files}
(HERE/'main-source-final.json').write_text(json.dumps(final,indent=2)+'\n')
(HERE/'main-integration.json').write_text(json.dumps({'base':base,'source_manifest_sha256':hashlib.sha256((HERE/'source-ready.json').read_bytes()).hexdigest(),'files':len(files),'all_source_hashes_match':True,'prior_main_clean':True},indent=2)+'\n')
print('Integrated held source',len(files),'paths')
