from pathlib import Path
import hashlib,json
A=Path('/tmp/eris-promise-catch-1/integration');B=Path('/tmp/eris-promise-1/worktree');P=Path('/tmp/eris-promise-catch-plan-1')
def bound(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
for rel in ['tests/promise_foundation.rs','tests/support/promise_foundation.rs','tests/worker/promise_foundation.rs']:
 s=(B/rel).read_text().replace('promise_foundation','promise_catch').replace('promise-foundation','promise-catch').replace('ESQTFMRDAPMTRB','GTSRQDACMB').replace('ESQTFMRD','GTSRQD').replace('601','621').replace('602','622')
 s=s.replace('Promise adoption, shared FIFO and exact rejection values','Generic catch invocation and exact rejection values').replace('Promise jobs preserve shared FIFO order and exact rejection values','Generic catch preserves receivers, raw returns and exact rejection values').replace('adoption_and_rejection','generic_invocation_and_rejection')
 p=A/'raw'/rel.replace('promise_foundation','promise_catch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
p=A/'raw/tests/fixtures/promise-catch.html';p.write_bytes((P/'tests-before/promise-catch.html').read_bytes())
frames=[]
for family,sizes in [('page',[(40,16),(48,16)]),('worker',[(320,240),(300,240)])]:
 for width,height in sizes:
  for state,left,title in [('disabled',2,'before'),('initial',6,'GTSRQD'),('clicked',10,'GTSRQDACMB')]:
   data=bytearray(bytes([255,255,255,255])*(width*height))
   for x,color in [(left,bytes([255,0,0,255])),(20,bytes([0,0,255,255]))]:
    for yy in range(2,6):
     for xx in range(x,x+4):data[4*(yy*width+xx):4*(yy*width+xx)+4]=color
   name=f'{family}-{width}x{height}-{state}';q=A/'tests-before/rgba'/(name+'.rgba');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data)
   frames.append({'id':name,'width':width,'height':height,'state':state,'red_x':left,'blue_x':20,'rectangle_ywh':[2,4,4],'title':title,'rgba':bound(q)})
oracles={'status':'fixed_literals_before_import_or_execution','initial_trace':'GTSRQD','initial_reason':'Generic catch reads then G, calls captured function T, returns poisoned-then marker unchanged. Script S, rejection reaction R then queued Q then child D. D writes title, R moves red6.','click_trace_append':'ACMB','click_reason':'First listener A enqueues rejected reaction C then microtask M. Both run before second listener B publishes title. C moves red10.','forbidden':'No constructor/rejected-value/returned-marker poison getter and no blue move24; no ordinary console report.','frames':frames,'literal_rgba_bytes':sum(f['rgba']['bytes'] for f in frames),'checks':'Two public integration groups, each10 layout or Render calls, four disabled controls first, then enabledinitial/repeatedtasks/click states. CPU Canvas and packed native-plan CPU comparison only; no GPU observation.','worker':'Generations621/622,processed_edit_sequence0,navigationNone,only Page process / Resource broker diagnostics; Runtime.console is not transported.','parent_prediction':'First enabled frame red at(2,2) instead of expectedwhite because catch missing; later enabled assertions not parent observations.'}
p=A/'tests-before/oracles.json';p.write_text(json.dumps(oracles,indent=2)+'\n')
files=[{'target':str(p.relative_to(A/'raw')),'file':bound(p)} for p in sorted((A/'raw').rglob('*')) if p.is_file()]
(A/'source-ready.json').write_text(json.dumps({'status':'root_integration_sources_and_literals_ready_for_peer','files':files,'oracles':bound(A/'tests-before/oracles.json'),'fixture_hold':bound(P/'tests-before/promise-catch.html'),'authoring':bound(A/'author.py'),'execution':'No imports, compiler, candidate runtime or browser output used for these literals.'},indent=2)+'\n')
