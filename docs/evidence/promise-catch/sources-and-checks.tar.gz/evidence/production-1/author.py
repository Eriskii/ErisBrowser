from pathlib import Path
import hashlib,json,difflib
r=Path('/tmp/eris-promise-catch-1/production-1');w=Path('/tmp/eris-promise-catch-1/worktree')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n);return s.replace(a,b)
files=[]
for name in ['src/script/promises.rs','src/script/promises/install.rs','src/script/promises/semantics.rs','src/script/machine/calls.rs']:
 old=(w/name).read_text();new=old
 if name.endswith('promises.rs'):
  new=replace(new,'METADATA_OBJECTS: usize = 6','METADATA_OBJECTS: usize = 7')
 elif name.endswith('install.rs'):
  new=replace(new,'and nine temporary literal-handle releases.','and ten temporary literal-handle releases.')
  new=replace(new,'self.work(16)?;','self.work(17)?;')
  new=replace(new,'            self.dom_proto_text("get [Symbol.species]")?,','            self.dom_proto_text("get [Symbol.species]")?,\n            self.dom_proto_text("catch")?,')
  new=replace(new,'// 15 string keys, 5 display names, 1 prototype tag, 2 constructor handles.','// 18 string keys, 6 display names, 1 prototype tag, 2 constructor handles.')
  new=replace(new,'self.work(23)?;','self.work(27)?;')
  new=replace(new,'self.dom_proto_object(Some(Value::Object(object_prototype)), 3)?','self.dom_proto_object(Some(Value::Object(object_prototype)), 4)?')
  new=replace(new,'            self.promise_intrinsic_method("Promise.getSpecies", pool[8].clone(), 0, keys)?;','            self.promise_intrinsic_method("Promise.getSpecies", pool[8].clone(), 0, keys)?;\n        let catch = self.promise_intrinsic_method("Promise.catch", pool[9].clone(), 1, keys)?;')
  needle='''        self.dom_proto_property(
            prototype,
            tag,
'''
  new=replace(new,needle,'''        self.dom_proto_property(
            prototype,
            pool[9].clone().into(),
            Property::data(catch, true, false, true),
        )?;
'''+needle)
 elif name.endswith('semantics.rs'):
  needle='''    fn promise_then(
'''
  new=replace(new,needle,'''    fn promise_catch(
        &mut self,
        receiver: Value,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        // Invoke performs an observable GetV before Call. Retain the original
        // receiver and forward the unfiltered argument without Promise branding.
        self.work(1)?;
        let method = self.promise_named_get(receiver.clone(), "then", doc)?;
        self.work(1)?;
        let rejected = args.first().cloned().unwrap_or(Value::Undefined);
        let arguments = self.promise_arguments([Value::Undefined, rejected])?;
        self.call(method, arguments, receiver, doc)
    }

'''+needle)
  new=replace(new,'                "Promise.then" => self.promise_then(receiver, args, doc),','                "Promise.then" => self.promise_then(receiver, args, doc),\n                "Promise.catch" => self.promise_catch(receiver, args, doc),')
 elif name.endswith('calls.rs'):
  new=replace(new,'"Promise" | "Promise.then" | "Promise.resolve" | "Promise.reject" | "Promise.getSpecies"','"Promise" | "Promise.then" | "Promise.catch" | "Promise.resolve" | "Promise.reject" | "Promise.getSpecies"')
 for part,data in [('before',old),('raw',new),('diffs',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))]:
  p=r/part/(name+('.patch' if part=='diffs' else ''));p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(data)
 files.append({'target':name,'kind':'production','before':bind(r/'before'/name),'raw':bind(r/'raw'/name),'diff':bind(r/'diffs'/(name+'.patch'))})
# Copy the six immutable migration bytes; do not re-derive assertions.
m=Path('/tmp/eris-promise-catch-1/migrations-before-1');mh=json.loads((m/'source-ready.json').read_text())
for f in mh['files']:
 row={'target':f['target'],'kind':'selected_old_test_migration'}
 for part,field in [('before','before'),('raw','raw'),('diffs','diff')]:
  src=Path(f[field]['path']);data=src.read_bytes();assert hashlib.sha256(data).hexdigest()==f[field]['sha256'];dest=r/part/(f['target']+('.patch'if field=='diff'else''));dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data);row[field]=bind(dest)
 files.append(row)
# Public test input remains exactly the independently frozen file. Root owns registration.
test=Path('/tmp/eris-promise-catch-plan-1/tests-before/promise_catch_tests.rs');target='src/script/promise_catch_tests.rs';p=r/'raw'/target;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(test.read_bytes());patch=r/'diffs'/(target+'.patch');patch.parent.mkdir(parents=True,exist_ok=True);patch.write_text(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=target)));files.append({'target':target,'kind':'new_frozen_public_tests','before':None,'raw':bind(p),'diff':bind(patch)})
review={'status':'external_source_draft_complete','base':'c275ea188c753de3f51f347283ad46a1a789b261','production_changes':'Four files only: metadata object reservation+1, minimal installer extension, generic catch helper/direct dispatcher branch. No constructor/factory/job/queue/cap changes.','orchestration':'Existing public fixed8 envelope; receiver clone1; static then text16work/80heap; unchanged observable Get fees; onRejected clone1; argument vector12work/(32+2V)heap; unchanged Call fees. New explicitly enumerated rows total38work plus inherited Get/Call, not a complete author-execution fee. No filtering, branding, constructor/species read, wrapping or assimilation.','bootstrap':'Installer+102 =>1032; raw99907=>remaining93. Helperheap+A+D+3K+L+N+1029; additional initialarenaO is separate. Seven metadata bags/six direct natives,748totalobjects,212globals/299native_registry/25prototype_registry. Poolkeys reused; no registry scan/cache/state additions.','ordering':'Existing function bags created in old order; catch metadata appended after species getter. Its prototype property is inserted after then and before tag; old IDs retained.','failure':'Get/Call errors propagate through existing Result/fatal observer. Native arm remains inside result expression with unconditional stack cleanup. Existing prepared argument cleanup applies; no fresh budget or checkpoint. No new independent resource-test mirror; existing helper quota groups remain exact and meaningful installer exact/one-short cuts are explicitly migrated.','migrations':'All six selected migration files copied byte-for-byte from the immutable before-production hold. Public test bytes copied exact from its semantic hold.','registration':'Root preserves/adds #[cfg(test)] mod promise_catch_tests; beside other script modules. This overlay deliberately does not replace the large root-owned script.rs or Page/worker integration files. If tests already imported, their held bytes are identical.','execution':'No live imports, compiler, formatter, project tests/browser or git.'}
p=r/'source-review.json';p.write_text(json.dumps(review,indent=2)+'\n')
hold={'status':'external_catch_production_ready_for_independent_source_peer','base':review['base'],'files':files,'plan':bind(Path('/tmp/eris-promise-catch-plan-1/source-ready.json')),'migrations':bind(m/'source-ready.json'),'tests':bind(Path('/tmp/eris-promise-catch-plan-1/tests-before/source-ready.json')),'source_review':bind(p),'registration':review['registration'],'execution':review['execution']}
p=r/'source-ready.json';p.write_text(json.dumps(hold,indent=2)+'\n');print(json.dumps(bind(p)))
