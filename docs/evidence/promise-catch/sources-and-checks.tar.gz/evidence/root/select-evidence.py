from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

inventory = A / 'source-2.json'
sources = json.loads(inventory.read_text())['source_sha256']
assert len(sources) == 788
for name, sha in sources.items():
    assert bind(A / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['native-full-2', 'default-full-3', 'strict-stable-1', 'strict-msrv-1',
              'format-check-1', 'browser-final-build-1', 'references-final-1']:
    r = json.loads((A / 'validation' / (label + '.json')).read_text())
    assert r['exit'] == 0
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256']
    checks[label] = r
for name in ['final-source-2-review.json', 'validation-review.json']:
    assert json.loads((A / 'root' / name).read_text())['status'] in ['clear', 'clear_source_only']
totals = json.loads((A / 'root/full-suite-totals.json').read_text())
assert totals['native-full-2']['passed'] == 3157
assert totals['default-full-3']['passed'] == 2853
reference = json.loads((A / 'root/reference-comparison-final.json').read_text())
assert reference['status'] == 'pass' and reference['pairs'] == 102 and reference['unchanged_pngs'] == 204
artifacts = {}
for directory in ['plans', 'integration', 'production-1', 'migrations-before-1',
                  'migrations-after-1', 'validation', 'root', 'reftests-final']:
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and p.name not in ['selection-final.json', 'publication-verification.json']:
            assert not p.is_symlink() and '__pycache__' not in p.parts
            artifacts[str(p.relative_to(A))] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json']:
        artifacts[p.name] = bind(p)
for name in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/promise-catch.md']:
    artifacts['documentation/' + name] = bind(A / 'worktree' / name)
selection = {
    'source_inventory': bind(inventory), 'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': json.loads(inventory.read_text())['base'],
        'parent_ci': {'status': 'success', 'jobs': 9, 'receipt': bind(A / 'validation/fixed-parent-ci-final.json')},
        'scope': 'Generic Promise.prototype.catch performs observable GetV then Call with the original receiver, exactly two arguments and an unchanged return value.',
        'source_inputs': 788,
        'new_test_groups': {'public_semantics': 7, 'page': 1, 'confined_worker': 1, 'total': 9},
        'baseline': json.loads((A / 'baseline-result.json').read_text()),
        'history': {
            'focused_before_bootstrap_fix': bind(A / 'pre-bootstrap-fix-source.json'),
            'startup_fix': 'Published separately as e8578db3; exact borrowed-bootstrap correction integrated before final catch checks.',
            'source1': bind(A / 'source-1.json'),
            'failed_full_attempts': 'Both first full suites failed only the old node_clone raw-startup inspection: 93 remaining work was less than its 106-work lookup. Those logs are retained.',
            'seventh_migration': bind(A / 'migrations-after-1/source-ready.json'),
            'default_second_attempt': 'After the fixture correction, the parallel default run had one unrelated date_host subprocess TimedOut failure. Its original log remains; the subsequent full default run was executed without a concurrent native suite. No timeout or production code was changed.',
            'old_migrations': 'Six held metadata/count migrations plus one explicit test-only separation of raw startup assertion from subsequent metadata inspection. All original node-clone assertions retained; production limits unchanged.',
            'final_source': bind(inventory)
        },
        'checks': checks,
        'full_suite_totals': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k, v in totals.items()},
        'references': {k: reference[k] for k in ['pairs', 'unchanged_pngs', 'parent_archive_sha256', 'report_sha256']},
        'reference_baseline': 'Published Promise foundation archive at c275ea18; intervening bootstrap-only fix has no separate image baseline.',
        'browser': json.loads((A / 'root/final-browser.json').read_text()),
        'resource_policy': {'bootstrap_allowance': 100000, 'raw_bootstrap_work': 99907, 'remaining': 93,
                            'installer_work': 1032, 'objects': 748, 'globals': 212, 'native_registry': 299,
                            'prototypes': 25, 'unchanged_limits': True, 'author_work': 100000,
                            'cumulative_heap_bytes': 8388608},
        'integration': {'frozen_rgba_frames': 12, 'frozen_rgba_bytes': 1802496,
                        'successful_layout_or_render_calls': 20, 'initial_title': 'GTSRQD',
                        'clicked_title': 'GTSRQDACMB',
                        'oracle_scope': 'Runtime tests compare full frames to fixed-coordinate procedural oracles; twelve archived RGBA files were independently reconciled to the same geometry, not loaded by the runtime tests.',
                        'render_scope': 'CPU Canvas and CPU interpretation of packed native plans; no new acquired GPU surface observation.'},
        'limits': ['Local authored tests, not imported WPT/Test262 conformance results.',
                   'finally, combinators, async/await, fetch, rejection notifications, multiple realms and GC remain unfinished.',
                   'No Chromium performance comparison, complete compatibility or production-security claim.',
                   'Build caches reused; elapsed times are not cold-build measurements.']
    }
}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2)
    out.write('\n')
print(json.dumps({'sources': len(sources), 'artifacts': len(artifacts)}))
