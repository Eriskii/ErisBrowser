from pathlib import Path
import json,hashlib,difflib
r=Path('/tmp/eris-promise-catch-1/migrations-before-1');w=Path('/tmp/eris-promise-catch-1/worktree')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def change(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n);return s.replace(a,b)
files=[]
for name in ['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/dom_bindings/identity_tests.rs','src/script/promises/install_tests.rs','src/script/promise_semantic_tests.rs']:
 old=(w/name).read_text();new=old
 if name.endswith('/bootstrap_tests.rs'):
  new=change(new,'Promise adds930 paid installation work and six metadata bags.','Promise with catch adds1032 paid installation work and seven metadata bags.')
  new=change(new,'assert_eq!(reference.steps, 195);','assert_eq!(reference.steps, 93);');new=change(new,'assert_eq!(reference.objects.len(), 747);','assert_eq!(reference.objects.len(), 748);')
 elif name.endswith('typed_array/tests.rs'):
  new=change(new,'        + 6269;','        + 6269;\n    // catch adds one ordinary metadata bag, reusing existing length/name keys.\n    let catch_added = s + a + d + 3 * k + bpp + n + 1029;')
  new=change(new,'+ 332 - 930','+ 332 - 930 - 102')
  new=change(new,'            + promise_added','            + promise_added\n            + catch_added')
  new=change(new,'(747, 747)','(748, 748)')
 elif name.endswith('processing_instruction/key_cache_tests.rs'):
  new=change(new,'frozen_99805_work_boundary','frozen_99907_work_boundary')
  new=change(new,'Promise installer adds930.','Promise with catch installer adds1032.')
  new=change(new,'[(99_804, false, 0), (99_805, true, 0), (100_000, true, 195)]','[(99_906, false, 0), (99_907, true, 0), (100_000, true, 93)]')
  new=change(new,'assert_eq!(runtime.objects.len(), 747);','assert_eq!(runtime.objects.len(), 748);')
 elif name.endswith('dom_bindings/identity_tests.rs'):
  new=change(new,'assert_eq!(runtime.objects.len(), 747);','assert_eq!(runtime.objects.len(), 748);')
 elif name.endswith('promises/install_tests.rs'):
  new=change(new,'six initial ScriptObject','seven initial ScriptObject')
  new=change(new,'6 * a + 6 * d + 17 * k + 6 * bpp + 5 * n + 4 * bsb + 6269','7 * a + 7 * d + 20 * k + 7 * bpp + 6 * n + 4 * bsb + 7298')
  new=change(new,'assert_eq!(runtime.objects.len(), 747);','assert_eq!(runtime.objects.len(), 748);')
  new=change(new,'reserve six additional','reserve seven additional');new=change(new,'try_reserve_exact(6)','try_reserve_exact(7)');new=change(new,'runtime.objects.len() + 6','runtime.objects.len() + 7')
  new=change(new,'exact930_and_one_short929','exact1032_and_one_short1031');new=change(new,'[(930, true), (929, false)]','[(1032, true), (1031, false)]');new=change(new,'runtime.steps = 930;','runtime.steps = 1032;')
  new=change(new,'runtime.objects.len(), 753','runtime.objects.len(), 755',2)
  new=change(new,'promise_full_raw99805','promise_full_raw99907');new=change(new,'[(99_804, false, 0), (99_805, true, 0), (100_000, true, 195)]','[(99_906, false, 0), (99_907, true, 0), (100_000, true, 93)]');new=change(new,'(747, 747)','(748, 748)')
 elif name.endswith('promise_semantic_tests.rs'):
  new=change(new,"==='constructor,then'","==='constructor,then,catch'")
 for part,data in [('before',old),('raw',new),('diffs',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))]:
  path=r/part/(name+('.patch' if part=='diffs' else ''));path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_text(data)
 files.append({'target':name,'before':bind(r/'before'/name),'raw':bind(r/'raw'/name),'diff':bind(r/'diffs'/(name+'.patch'))})
hold={'status':'six_explicit_old_test_migrations_frozen_before_catch_implementation','base':'c275ea188c753de3f51f347283ad46a1a789b261','files':files,'reason':'Selected catch adds exactly102installerwork,one metadata bag and the held typed heap delta. Existing installer exact/one-short tests remain meaningful; new independent wrapper-mirroring resource tests are intentionally not added under root selection. The one supported public prototype roster adds catch; all other old semantic assertions and helper quota cuts remain unchanged.','plan':bind(Path('/tmp/eris-promise-catch-plan-1/source-ready.json')),'execution':'No project execution, compiler, import or live edits.'}
p=r/'source-ready.json';p.write_text(json.dumps(hold,indent=2)+'\n');print(json.dumps(bind(p)))
