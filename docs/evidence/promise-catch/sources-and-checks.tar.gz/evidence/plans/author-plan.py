from pathlib import Path
import hashlib,json
root=Path('/tmp/eris-promise-catch-plan-1');work=Path('/tmp/eris-promise-1/worktree')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,data):
 p=root/name;assert not p.exists();p.write_text(json.dumps(data,indent=2)+'\n')
source=Path('/tmp/eris-promise-1/source-2.json');inventory=json.loads(source.read_text())
paths=['src/script/promises.rs','src/script/promises/install.rs','src/script/promises/semantics.rs','src/script/promises/factories.rs','src/script/dom_prototypes.rs','src/script/machine/calls.rs','src/script/construction.rs','src/script/property_keys.rs','src/script.rs','src/script/promises/install_tests.rs','src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/dom_bindings/identity_tests.rs','src/script/promise_semantic_tests.rs','tests/promise_foundation.rs','tests/support/promise_foundation.rs','tests/fixtures/promise-foundation.html']
rows=[]
for name in paths:
 b=bind(work/name);assert b['sha256']==inventory['source_sha256'][name],name;rows.append({'target':name,**b})
write('source-context.json',{'status':'bound_to_foundation_candidate_source2_before_foundation_publication','inventory':bind(source),'root_reported_source2_sha256':'9fbec526f99cce5c80a8854061714808aa09c73bca436b024cc02d61cd8cd804','parent_of_foundation':inventory['base'],'foundation_publication':'Pending root publication; do not substitute its parent commit as the new catch base. Rebind the unchanged relevant files to the actual published foundation commit before import.','files':rows,'execution':'Inert byte/hash verification only; no project execution or import.'})
write('resource-ledger.json',{
 'status':'source_derived_proposed_increment_no_execution',
 'layout':'Append catch text to existing fixed pool; reuse existing length/name keys and private method factory. Add one direct native bag; reserve prototype order4 rather than3. Install prototype.catch after then and before @@toStringTag; append its metadata bag after existing method bags, retaining existing metadata IDs.',
 'work_rows':[
  {'name':'one_metadata_bag','increment':9,'basis':'unchanged dom_proto_object8+1; pre-reserved initial object arena'},
  {'name':'literal_catch','increment':18,'basis':'dom_proto_text8+2*5'},
  {'name':'function_length_name_properties','increment':24,'basis':'oldcount0 length=>9; oldcount1 name=>15'},
  {'name':'direct_native','increment':21,'basis':'8+13 bytes in Promise.catch'},
  {'name':'pool_handle_clones','increment':4,'basis':'two immutable length/name key clones, one catch display-name clone, one prototype.catch key clone'},
  {'name':'pool_handle_release','increment':1,'basis':'fixed installer guard/cleanup16=>17 for tenth literal handle'},
  {'name':'prototype_catch_property','increment':23,'basis':'at oldcount2,keylen5:2*(1+5)+(8+2)+1=23'},
  {'name':'following_toStringTag_property','increment':2,'basis':'oldcount2=>3,zero-length symbol key:13=>15; heap unchanged'}],
 'work_total_increment':102,
 'exact_work_projection':{'installer_before':930,'installer_after':1032,'installer_one_short':1031,'raw_before':99805,'raw_after':99907,'raw_one_short':99906,'cap':100000,'remaining_before':195,'remaining_after':93},
 'type_symbols':{'O':'sizeof(ScriptObject)','A':'sizeof(Option<AbortSlot>)','D':'sizeof(Option<f64>)','K':'sizeof(PropertyKey)','N':'sizeof(Native)','L':'16*(sizeof(PropertyKey)+sizeof(Property))+32*sizeof(usize)+64','B':'16*(sizeof(String)+sizeof(Binding))+32*sizeof(usize)+64'},
 'heap_rows':[
  {'name':'initial_object_arena_delta','bytes':'O','owner':'existing eager bootstrap reservation; excluded from helper increment'},
  {'name':'new_bag_base','bytes':'72+A+D'},
  {'name':'order_buffers','bytes':'3K','basis':'two new function metadata slots plus one added prototype property slot'},
  {'name':'new_small_map_leaf','bytes':'L','basis':'new function bag first insertion; no new prototype leaf below11entries'},
  {'name':'three_added_property_records','bytes':828,'basis':'(256+4*6)+(256+4*4)+(256+4*5)'},
  {'name':'one_literal','bytes':84,'basis':'64+4*5'},
  {'name':'one_native','bytes':'N+45','basis':'N+32+13'}],
 'helper_heap_increment':'A+D+3K+L+N+1029',
 'full_startup_heap_increment':'O+A+D+3K+L+N+1029',
 'new_helper_formula':'7A+7D+20K+7L+6N+4B+7298',
 'counts':{'Promise_metadata_objects':[6,7],'all_objects_and_exact_initial_capacity':[747,748],'Promise_direct_natives':[5,6],'native_registry':[299,299],'globals':[212,212],'prototypes_registry':[25,25],'Promise_State_header':'unchanged','shared_FIFO_header_and_slot':'unchanged','five_private_arenas_and_queue_initial_backings':'remain empty/capacity0; catch installation creates no promise/reaction/job'},
 'runtime_schedule':{'proposed_method':'promise_catch(receiver:Value,args:&[Value],doc:&mut Document)->Result<Value>, private inside promises::semantics','sequence':['Existing promise_native_operation fixed8 envelope.','Debit1 then clone original receiver for the property read.','Use unchanged promise_named_get(receiver clone,"then",doc): text16work/80heap plus existing Get fees; all observable getters occur here.','After successful Get, debit1 before copying first argument or supplying Undefined. Do not inspect callability or properties.','Use unchanged promise_arguments([Undefined,onRejected]):12work and32+2*sizeof(Value) heap before fallible reserve.','Call the observed method with original receiver and owned two-argument vector; return original Result<Value> unchanged. Existing callability, stack, author execution and fatal observation remain in existing helpers.'],'new_explicit_orchestration_total':'38 work =8+1+16+1+12, plus existing Get and Call charges; explicit text/vector heap112+2*sizeof(Value), plus existing Get/Call allocations. This is not an end-to-end runtime fee.','failure':'No fresh allowance or callback checkpoint. Get/call abrupt completion propagates exactly; ResourceLimit/Unsupported still reach existing sticky observer. Prepared fixed temporaries/argument cleanup follow existing public-operation8 and argument-builder ownership contracts.'},
 'admission_witness_proposal':['Direct installer replay: fully initialized candidate has748 bags; remove only exposed Promise/privatecache; reserve7sparebags; resetcounters; work1032 succeeds with755bags,1031 fails before global/cachepublication. No private-bag rollback claim.','Exact new helper heap versus one-short at work1032, retaining original failure-state assertions.','Raw finish_bootstrap99906refuses,99907succeedswith0remaining,100000succeedswith93; publictry_new resetsauthorworkonlyaftersuccess.','Assert748objects/capacity,212globals,299native_registry,25prototype_registry,zero private arena/FIFO backing capacities,unchanged type shapes.'],
 'limits':'All numbers are derived from bound source schedules, not observed execution. No independent queue/heap allowance, cache/state header, optimization or cap increase proposed. Root must select this ledger before implementation.'})
write('migration-audit.json',{
 'status':'named_proposed_old_assertion_migrations_before_observations','base_context':bind(root/'source-context.json'),
 'files':[
  {'path':'src/script/bootstrap_tests.rs','changes':['raw remainder195=>93','object count747=>748','update explanatory installer930/sixbags to1032/sevenbags']},
  {'path':'src/script/typed_array/tests.rs','changes':['subtract another102work in raw formula','append typed catch heap delta O+A+D+3K+L+N+1029; no State delta','objects/capacity747=>748; globals212/native299/prototypes25 stayexact']},
  {'path':'src/script/processing_instruction/key_cache_tests.rs','changes':['raw exact/short99805/99804=>99907/99906; remaining195=>93','object747=>748; keep PI key-cache saving332, actual PI assertions and all other counts exact']},
  {'path':'src/script/dom_bindings/identity_tests.rs','changes':['sole bootstrap object count747=>748; all identity/descriptor assertions unchanged']},
  {'path':'src/script/promises/install_tests.rs','changes':['helper formula6A+6D+17K+6L+5N+4B+6269=>7A+7D+20K+7L+6N+4B+7298','replayfixture748 initialbags/reserve7; success755 instead of753','exact1032/short1031,raw99907/99906,remaining93; rename literal-bearing test names','preserve unchanged atomic global/cache refusal,registry,arena,queue,console/frames assertions']},
  {'path':'src/script/promise_semantic_tests.rs','changes':["one explicit supported prototype roster 'constructor,then'=>'constructor,then,catch'; all old function descriptor/binding/Promise semantic assertions remain exact"]}],
 'unchanged':'Microtask private budget literals and queue representation, Promise factory/settlement/argument/reporter exact cuts, existing actual-layout assertions, globals/native/prototype counts and all old public semantic traces. No historical expectation should be silently changed after observation.',
 'registration':'New frozen public semantic module is additive. Page integration is a separately described candidate; root decides actual harness import after foundation publication.',
 'execution':'No migration applied and no tests executed. Future before/raw/diff migration freeze remains required when root authorizes source drafting.'})
write('proposal.json',{
 'status':'bounded_catch_only_plan_ready_for_selection_no_implementation',
 'sources':[{'url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.prototype.catch','rule':'catch invokes the receiver\'s then with Undefined and the original rejection argument, returning that completion.'},{'url':'https://tc39.es/ecma262/multipage/abstract-operations.html#sec-invoke','rule':'Invoke obtains the named method with GetV and calls it using the original lookup receiver as this.'},{'url':'https://tc39.es/ecma262/multipage/ecmascript-standard-built-in-objects.html#sec-properties-of-the-promise-prototype-object','note':'Use the primary catch anchor above; general built-in function property conventions determine length/name and nonconstructability. No browser behavior inferred.'}],
 'primary_source_note':'Current browsed draft labels Promise section27.5.5.1; stable catch anchor is used rather than freezing an obsolete section number.',
 'observable_contract':['No Promise brand check, SpeciesConstructor or NewPromiseCapability at the catch layer. A generic object or supported primitive may provide then.','Read then exactly through the ordinary observable property path, including inherited accessors; preserve primitive this for strict getter/call. Null/Undefined fail through GetV.','Forward exactly two arguments, Undefined followed by the original first argument; omitted means Undefined and extra catch arguments are ignored. Neither callability nor any onRejected metadata is examined by catch.','Call the observed method with the original receiver. A getter may mutate receiver.then or queue work; use the method already returned by that one Get.','Return arbitrary primitive/object values directly, without Promise wrapping, reading returned then, or scheduling a job. Getter/call throws preserve exact thrown values; existing fatal suspension remains.','If the observed then is the installed Promise.then, all existing branding/species/handler filtering/reaction scheduling happens there. catch adds no second implementation or shortcut.'],
 'minimal_seams':[
  {'path':'src/script/promises.rs','change':'METADATA_OBJECTS6=>7 only; no types/arenas/queue fields changed'},
  {'path':'src/script/promises/install.rs','change':'one new pooled catch literal, seven pre-reserved bags, prototype order capacity4, direct Promise.catch metadata length1/namecatch, descriptor writabletrue/enumerablefalse/configurabletrue; prepaid fixed/clones and exact ledger increment'},
  {'path':'src/script/promises/semantics.rs','change':'small generic method using named_get, owned two-argument builder and call; dispatch Promise.catch through existing fixed8/fatal wrapper'},
  {'path':'src/script/machine/calls.rs','change':'add exact Promise.catch to existing direct Promise native operation arm to preserve dynamic receiver without cloned Native name'},
  {'path':'src/script/construction.rs','change':'none: absence from native constructible whitelist preserves nonconstructability'}],
 'metadata':{'display_name':'catch','length':1,'own_function_keys':['length','name'],'own_prototype':False,'function_prototype':'existing Function.prototype','prototype_string_keys':['constructor','then','catch'],'initial_property_identity':'one stored native value, shared across reads; normal writable/configurable mutation and saved-reference use'},
 'tests':bind(root/'tests-before/source-ready.json'),'resource_ledger':bind(root/'resource-ledger.json'),'migration_audit':bind(root/'migration-audit.json'),'source_context':bind(root/'source-context.json'),
 'parent_baseline_prediction':'Foundation lacks catch. Each new group reaches a missing catch value and should fail before its expected result; Page disabled controls remain valid and enabled expected pixels/title fail. Root must execute actual parent baselines after publishing foundation; predictions are not results.',
 'scope_limits':'Single existing realm and existing Get/Call/constructor/Promise support. No finally, combinators, await, rejection events, new scheduler, brand shortcuts, broader bootstrap optimization or cap increase. Existing unsupported Proxy/exotic coverage is not broadened by this plan.',
 'publication':'Foundation publication is pending at drafting; the current bound candidate is source2. Root supplies final published commit and authorizes implementation only after this independent plan/ledger/test freeze.',
 'execution':'No production implementation, live source edits, compiler/browser/tests, project helper imports or git operations.'})
print('plan files written')
