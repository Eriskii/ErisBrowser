from pathlib import Path
import json,hashlib
root=Path('/tmp/eris-promise-catch-plan-1'); data=json.loads((root/'tests-before/oracles.json').read_text());binding=json.loads((root/'tests-before/oracle-freeze.json').read_text());assert hashlib.sha256((root/'tests-before/oracles.json').read_bytes()).hexdigest()==binding['sha256']
def rust(v):
 if isinstance(v,bool):return 'Value::Bool('+str(v).lower()+')'
 if isinstance(v,(int,float)):return 'Value::Number('+str(float(v))+')'
 return 'Value::String('+json.dumps(v)+'.into())'
text='''//! Promise.prototype.catch literals frozen before implementation or execution.
use super::*;

fn observe(script: &str, expression: &str, expected: Value, entry: Option<Value>) {
    let mut runtime = Runtime::try_new().unwrap();
    let mut document = Document::parse("");
    let completion = runtime.execute(script, &mut document).unwrap();
    if let Some(expected) = entry { assert_eq!(completion, expected); }
    assert_eq!(runtime.execute(expression, &mut document).unwrap(), expected);
    assert!(runtime.console.is_empty(), "{:?}", runtime.console);
}

'''
for group in data['groups']:
 text+='#[test]\nfn '+group['name']+'() {\n'
 for row in group['rows']:
  text+='    observe(\n        r###"'+row['script']+'"###,\n        r###"'+row['after_checkpoint_expression']+'"###,\n        '+rust(row['expected'])+',\n        '+('Some('+rust(row['entry_result'])+')' if 'entry_result'in row else 'None')+',\n    );\n'
 text+='}\n\n'
p=root/'tests-before/promise_catch_tests.rs';assert not p.exists();p.write_text(text)
html='''<!doctype html><title>before</title><style>
body{margin:0;background:white}#box,#trap{position:absolute;top:2px;width:4px;height:4px}
#box{left:2px;background:red}#trap{left:20px;background:blue}
</style><div id="box"></div><div id="trap"></div><script>
var trace='',box=document.getElementById('box'),token={},marker={};
Object.defineProperty(token,'constructor',{get:function(){trace+='X';document.getElementById('trap').style.left='24px';while(true){}}});
Object.defineProperty(marker,'then',{get:function(){trace+='X';document.getElementById('trap').style.left='24px';while(true){}}});
var generic={};
Object.defineProperty(generic,'constructor',{get:function(){trace+='X';throw 99;}});
Object.defineProperty(generic,'then',{get:function(){trace+=this===generic?'G':'!';return function(a,b){'use strict';trace+=this===generic&&arguments.length===2&&a===undefined&&b===token?'T':'!';return marker;};}});
if(Promise.prototype.catch.call(generic,token)!==marker)trace+='!';
box.addEventListener('click',function(){
 trace+='A';Promise.reject(token).catch(function(e){trace+=e===token?'C':'!';box.style.left='10px';document.title=trace;});
 queueMicrotask(function(){trace+='M';});
});
box.addEventListener('click',function(){trace+='B';document.title=trace;});
Promise.reject(token).catch(function(e){trace+=e===token?'R':'!';box.style.left='6px';return 9;})
 .then(function(v){trace+=v===9?'D':'!';document.title=trace;});
queueMicrotask(function(){trace+='Q';});
trace+='S';
</script>
'''
p=root/'tests-before/promise-catch.html';assert not p.exists();p.write_text(html)
page={'status':'candidate_public_Page_test_steps_before_implementation','fixture':str(p),'oracle':str(root/'tests-before/oracles.json'),'proposed_target':'tests/promise_catch.rs','steps':['Construct scripts-disabled Page from fixture; at40x16 and48x16 assert whole literal frame, hit atred x+1/y3 identifies#box andblue21/3 identifies#trap; titlebefore;TaskStateIdle;emptydiagnostics/console. Click#box and run_pending_tasks then repeat unchanged controls.','Construct scripts-enabled Page; assert exact initial titleGTSRQD andliteralredx6/bluex20 atbothsizes, hit controls,Idle/emptydiagnostics/console.','Call run_pending_tasks and repeat unchanged initial frame/title.','Click#box; assert no navigation; check exact clicked titleGTSRQDACMB andliteralredx10/bluex20 atbothsizes,hitcontrols,Idle/emptydiagnostics/console.'],'optional_existing_route':'Root may mirror the same fixture/oracles through the existing confined-worker harness after selecting integration scope; no worker result is inferred.','raster':'CPU Canvas and the existing feature-gated packed Native plan comparison can reuse current Promise foundation check helper; no hardware claim.'}
(root/'tests-before/page-candidate.json').write_text(json.dumps(page,indent=2)+'\n')
def bind(path):
 b=path.read_bytes();return{'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
held={'status':'semantic_and_Page_candidate_tests_frozen_before_production','oracles':bind(root/'tests-before/oracles.json'),'freeze':bind(root/'tests-before/oracle-freeze.json'),'files':[bind(root/'tests-before/promise_catch_tests.rs'),bind(root/'tests-before/promise-catch.html'),bind(root/'tests-before/page-candidate.json')],'groups':7,'rows':10,'registration':'Future root-owned cfg(test) module promise_catch_tests in script.rs. No registration or live source import performed. Page file is fixture plus exact candidate steps, not yet an integrated Rust test.','execution':'None. These are source-derived expected outcomes, not actual engine results.'}
p=root/'tests-before/source-ready.json';p.write_text(json.dumps(held,indent=2)+'\n');print(json.dumps(bind(p)))
