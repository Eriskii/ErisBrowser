from pathlib import Path
import shutil
base=Path('/tmp/eris-vulkan-rounded-core-1/worktree')
out=Path('/tmp/eris-vulkan-rounded-core-1/production-1')
plan=Path('/tmp/eris-vulkan-rounded-core-plan-1')
files=['src/graphics/box_decoration.rs','src/graphics/box_decoration/native.rs','src/graphics/raster_bridge/native.rs']
for name in files:
 src=base/name; dst=out/'before'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
 dst=out/'raw'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
def edit(name,old,new):
 path=out/'raw'/name;s=path.read_text();assert s.count(old)==1,(name,old[:100],s.count(old));path.write_text(s.replace(old,new))
name='src/graphics/box_decoration/native.rs'
edit(name,'use std::mem::size_of;','use std::mem::size_of;\n\nmod core;\npub(crate) use core::{BoxCoreReservation, BoxCoreTiles, BoxCoreWindow};')
name='src/graphics/box_decoration.rs'
edit(name,'    BoxMaskError, BoxMaskReservation, BoxMaskTile, BoxMaskTiles, BoxMaskWindow, BoxRectProof,','    BoxCoreReservation, BoxCoreTiles, BoxCoreWindow, BoxMaskError, BoxMaskReservation,\n    BoxMaskTile, BoxMaskTiles, BoxMaskWindow, BoxRectProof,')
name='src/graphics/raster_bridge/native.rs'
edit(name,'        BoxDecoration, BoxMaskError, BoxMaskReservation, BoxMaskTile, BoxMaskTiles, BoxMaskWindow,','        BoxCoreReservation, BoxCoreTiles, BoxCoreWindow, BoxDecoration, BoxMaskError,\n        BoxMaskReservation, BoxMaskTile, BoxMaskTiles, BoxMaskWindow,')
edit(name,'    pub box_rectangles: usize,','    pub box_rectangles: usize,\n    /// Individually oversized Color masks split into one Rect and edge masks.\n    pub box_cores: usize,')
edit(name,'    Mask(BoxMaskReservation),','    Mask(BoxMaskReservation),\n    Core { reservation: BoxCoreReservation, raw_core: BrowserRect },')
edit(name,'/// Called only after complete original-input validation. No coverage, glyphs', '''/// Convert a proved screen interior back to one ordinary raw Rect. Preserve
/// current phase/fixed scopes: core's f32 translation must reproduce all four
/// fields exactly. Fractional raw geometry or offsets remain on the old route.
fn exact_raw_core(
    screen: BrowserRect, raw_outer: BrowserRect, offset: (f32, f32),
) -> Option<BrowserRect> {
    if ![raw_outer.x, raw_outer.y, raw_outer.width, raw_outer.height, offset.0, offset.1]
        .into_iter().all(|v| bounded_scalar(v) && v.fract() == 0.0)
    { return None; }
    let raw = BrowserRect {
        x: screen.x - offset.0, y: screen.y - offset.1,
        width: screen.width, height: screen.height,
    };
    if validate_rect(convert_rect(raw), None).is_err()
        || ![raw.x, raw.y, raw.width, raw.height].into_iter().all(|v| v.fract() == 0.0)
        || raw.translated(offset.0, offset.1) != screen
    { return None; }
    Some(raw)
}

/// Called only after complete original-input validation. No coverage, glyphs''')
old='''                        let window =
                            BoxMaskWindow::new(target.width, target.height, outer, cutout, clip)
                                .map_err(|error| box_error(error, phase, index))?;
                        BoxReservation::Mask(
                            window
                                .reserve(remaining)
                                .map_err(|error| box_error(error, phase, index))?,
                        )'''
new='''                        match BoxMaskWindow::new(target.width, target.height, outer, cutout, clip) {
                            Ok(window) => BoxReservation::Mask(
                                window.reserve(remaining)
                                    .map_err(|error| box_error(error, phase, index))?,
                            ),
                            // Only an individually oversized stored mask can
                            // select the new path; its constructor proves this
                            // independently. CPU or shared-ledger failure never
                            // retries another route or refunds earlier work.
                            Err(BoxMaskError::MaskLimit) => {
                                let failure = at(FallbackKind::MaskPreparation, phase, index);
                                let window = BoxCoreWindow::new(target.width, target.height, outer, cutout, clip)
                                    .map_err(|error| box_error(error, phase, index))?
                                    .ok_or(failure)?;
                                let raw_core = exact_raw_core(window.core_rect(), decoration.shape.rect, offset)
                                    .ok_or(failure)?;
                                let reservation = window.reserve(remaining)
                                    .map_err(|error| box_error(error, phase, index))?;
                                BoxReservation::Core { reservation, raw_core }
                            }
                            Err(error) => return Err(box_error(error, phase, index)),
                        }'''
edit(name,old,new)
edit(name,'    fn box_mask(\n','''    fn box_core(
        &mut self, shape: &BoxCoreReservation, phase: usize, command: usize,
    ) -> NativeResult<()> {
        let info = shape.info();
        let mut next = *self;
        // One original command pays the Rect. Every edge Glyph is additional.
        next.operations = next.operations.checked_add(info.tile_count)
            .filter(|&n| n <= MAX_COMMANDS)
            .ok_or_else(|| at(FallbackKind::CommandLimit, phase, command))?;
        next.box_loop_work = next.box_loop_work.checked_add(info.classification_work)
            .and_then(|n| n.checked_add(info.materialization_work))
            .ok_or_else(|| at(FallbackKind::CpuPaintBudget, phase, command))?;
        // The two CPU stages were already funded in original command order.
        // Reuse the old row/source/storage/GPU diagnostic ordering unchanged.
        for tile in shape.tiles() {
            next.mask(tile.coverage_bytes, tile.row_entries, true, false,
                at(FallbackKind::MaskPreparation, phase, command))?;
        }
        if info.tile_count == 0 {
            next.check_gpu(at(FallbackKind::PlannerLimit, phase, command))?;
        }
        *self = next;
        Ok(())
    }

    fn box_mask(
''')
edit(name,'        (1, size_of::<BoxMaskTiles>()),','''        (1, size_of::<BoxMaskTiles>()),
        // Move-only core metadata and the complete edge owners can coexist
        // with their callers/destination metadata. Payload caps stay shared.
        (2, size_of::<BoxCoreWindow>()),
        (2, size_of::<BoxCoreReservation>()),
        (1, size_of::<BoxCoreTiles>()),
        (2, size_of::<BrowserRect>()),''')
edit(name,'    let mut box_rectangles = 0;','    let mut box_rectangles = 0;\n    let mut box_cores = 0;')
edit(name,'                        (BoxReservation::Mask(reservation), BoxPaint::Color(color)) => {','''                        (BoxReservation::Core { reservation, raw_core }, BoxPaint::Color(color)) => {
                            let coverage = reservation.materialize(
                                |shape| ledger.box_core(shape, phase_index, index),
                                |error| box_error(error, phase_index, index),
                            )?;
                            box_cores += 1;
                            // The Rect retains raw coordinates and surrounding
                            // scopes. Edge Glyphs are already absolute. Their
                            // integer pixels are disjoint, including at seams.
                            lowered.push(Command::Rect {
                                rect: convert_rect(raw_core),
                                rgba: [color.r, color.g, color.b, color.a], radius: 0.0,
                            });
                            for tile in coverage.into_tiles() {
                                lowered.push(Command::Glyph {
                                    source: mask_sources.len() as u32,
                                    rows: row_sources.len() as u32,
                                    y: tile.info().origin_y,
                                    rgba: [color.r, color.g, color.b, color.a],
                                });
                                mask_sources.push(MaskSource::Box(box_tiles.len()));
                                row_sources.push(RowSource::Box(box_tiles.len()));
                                box_tiles.push(tile);
                            }
                            continue;
                        }
                        (BoxReservation::Mask(reservation), BoxPaint::Color(color)) => {''')
edit(name,'        box_rectangles,','        box_rectangles,\n        box_cores,')
path=out/'raw'/name;path.write_text(path.read_text()+'\n#[cfg(test)]\nmod box_core_tests;\n')
# Immutable held tests and explicitly selected legacy migrations.
copies=[
 (plan/'helper-tests-before-1/raw','src/graphics/box_decoration/native/core_tests.rs'),
 (plan/'helper-tests-before-1/raw','src/graphics/box_decoration/native/core-seven-tile-row.bin'),
 (plan/'native-tests-before-1/raw','src/graphics/raster_bridge/native/box_core_tests.rs'),
 (plan/'migration-1/raw','src/graphics/raster_bridge/native/box_decoration_tests.rs'),
 (plan/'migration-2/raw','src/graphics/raster_bridge/native/box_prepass_tests.rs'),
]
for srcroot,name in copies:
 dst=out/'raw'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(srcroot/name,dst)
 if (base/name).exists():
  dst=out/'before'/name;dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/name,dst)
