"""Inert authoring only: JSON, literal pixels, a proposed test-only migration.
Never imports Eris, runs Rust/browser/GPU, or edits the checkout.
"""
from pathlib import Path
import hashlib,json,difflib,struct,math
P=Path('/tmp/eris-vulkan-rounded-core-plan-1')
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def binding(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,value):
 p=P/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(json.dumps(value,indent=2,ensure_ascii=False)+'\n')
 return binding(p)
def text(name,s):
 p=P/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);return binding(p)
put('plan.json',{
 'schema':'eris-rounded-color-core-plan-1','status':'proposal_for_independent_review','observed_execution':False,
 'selection':'Only individually oversized Color mask windows may extract one integer opaque-coverage interior Rect and retain the exact sixteen-sample edge masks.',
 'preserved':['Every existing pure rectangular Color route and its 8+3P allowance.','Every existing individual mask window with stored area at most262144: helper, pixels, partition, work, failure precedence.','All viewport, coordinate, command, scope, source, row, coverage, CPU work, GPU byte and invocation caps.','Complete raw preflight, complete unsupported Image/Gradient eligibility pass, source-key/store validation, initial global full-area debt and original-command-order geometry debits.','Current ordinary Rect, Image, Gradient, text and all existing offscreen fixture pixels.'],
 'eligibility':[
  'Use the existing rectangle proof first. Use the existing BoxMaskWindow::new next. Only an old MaskLimit result can reach the new helper; the helper independently requires original stored area strictly greater than262144.',
  'BoxPaint::Color only. Valid used RoundedBox; cutout must be None, including rejection of empty/disjoint/zero-area Some cutouts. Do not normalize used radii again.',
  'The translated outer x/y/width/height must be exact integers. Adapter additionally requires original raw x/y/width/height and current offset components to be exact integers; this conservative first slice intentionally rejects fractional-raw plus fractional-offset cancellation.',
  'Reuse the exact existing f32 candidate C and stored M expressions. Calculate inset bounds in f64 from the original used radii: left=max(TL.rx,BL.rx), right=max(TR.rx,BR.rx), top=max(TL.ry,TR.ry), bottom=max(BL.ry,BR.ry). For a corner with either radius axis zero use zero on both axes because contains ignores that corner. Apply ceil to left/top, floor to right/bottom, intersect M, and require a nonempty integer core I.',
  'Residual M\\I must fit the unchanged aggregate262144 mask-byte cap and65536 row cap; every tile width/height must fit1024 and there may be at most7 tiles. Metadata arithmetic uses checked operations.',
  'Before reservation, the adapter derives raw_core by subtracting the current offset from screen_core. All four raw fields must pass existing Native1M bounds; the same f32 translation must reproduce all four screen fields exactly. Reject the new route if this check fails. Lower the raw Rect in the existing original scope.',
  'After first debit, query the original RoundedBox at all four extrema of the complete core sample hull: (left+.125,top+.125), (right-.125,top+.125), (right-.125,bottom-.125), (left+.125,bottom-.125). All four must be inside. The existing convex-corner intersection proof then covers all core samples. No shape membership query occurs before this debit.'
 ],
 'partition':{
  'candidate':'C is retained independently of storage M. P=area(C). Core I is a subset of M and hence C.',
  'classification':'Classify C\\I, as four nonoverlapping bands, against the original ShapeMask. Retain conservative P in both work stages; do not substitute edge area. Ambiguous count A equals the original full-candidate classification because proved core pixels are Inside.',
  'payload':'Partition M\\I into top full-width, bottom full-width, left core-height, right core-height bands. Omit empty bands; split each nonempty width into strips of at most1024. No vertical subdivision is needed under Native height1024.',
  'max_tiles':'Top and bottom each use at most2. Left+right widths sum to at most1279 because core width>=1, so their total strip count is at most3. Thus K<=7. The 1100/1 asymmetric-radius literal reaches7.',
  'paint_order':'Emit one raw zero-radius Rect, then masks top left-to-right, bottom left-to-right, left left-to-right, right left-to-right. Rect and masks have disjoint integer pixel sets, so alpha and group opacity apply once per pixel.',
  'clipping':'Core bounds are inside stored M. Its endpoints are at most ceil(clip.end), so even opaque root Rect coverage cannot escape the Box blend membership. Glyphs retain absolute row origins and current clips. Neither clip nor geometry is normalized or translated a second time.',
  'scope':'No new clip, fixed, document, or opacity scopes. Preserve the original command position and raw Rect coordinates; edge Glyph coordinates remain absolute like the existing mask route.'
 },
 'refusal_policy':[
  'Ineligible oversized geometry returns the original MaskPreparation at its original phase/command without scans or payload allocation. Invalid raw/translated geometry keeps InvalidGeometry and its existing earlier precedence.',
  'For eligible geometry, first- or second-stage debt failure is CpuPaintBudget at the original command. No mask fallback retry or refund follows a new-route reservation failure.',
  'Unsupported later Image/Gradient commands, malformed geometry, key/store overages and initial global Line/opacity debt still reject before any Color classification.',
  'Perform one copied-Ledger transaction for Rect plus all masks before any payload allocation. Preserve current row/source/coverage/GPU diagnostic order within each tile and publish the ledger only when the complete batch admits.',
  'Alpha0 and opacity0 retain conservative work, masks and admission counters; the existing core planner may suppress actual draws. Empty or clipped-away commands remain in the old path because they cannot have oversized stored area.'
 ],
 'limits_of_increment':['Many individually small masks can still exhaust the shared mask/source/command budgets; their route is intentionally unchanged.','Rounded images, rounded gradients, cutout rings, fractional raw geometry/offsets, empty inset cores and large residual borders remain fallback cases.','Fewer CPU mask cells and successful admission are source-derived expectations, not measured latency, throughput or hardware claims.','No benchmark-host/acquired-window changes or Chromium comparison in this checkpoint.'],
 'file_ownership':[
  {'owner':'layout helper author after approval','paths':['src/graphics/box_decoration/native/core.rs','src/graphics/box_decoration/native/core_tests.rs'],'scope':'new private helper and focused tests'},
  {'owner':'layout helper author after approval','paths':['src/graphics/box_decoration/native.rs','src/graphics/box_decoration.rs'],'scope':'only module registration/reexports; old helper code and tests stay byte-identical apart from formatting'},
  {'owner':'root adapter/integration','paths':['src/graphics/raster_bridge/native.rs','src/graphics/raster_bridge/native/box_core_tests.rs','src/graphics/raster_bridge/native/box_decoration_tests.rs'],'scope':'new reservation variant/ledger/stats/lowering/peak and held explicit old-cap migration'},
  {'owner':'independent checker author assigned by root','paths':['tools/vulkan-raster-probe/src/box_core_fixtures.rs','tools/vulkan-raster-probe/src/bin/box-core-check.rs','tools/vulkan-raster-probe/src/lib.rs','tools/vulkan-raster-probe/Cargo.toml'],'scope':'reuse existing surface_gpu encoder/readback; literals never enter encoder'},
  {'owner':'root','paths':['.github/workflows/check.yml','README.md','SECURITY.md','docs/'],'scope':'only needed roster/docs/evidence updates; no host changes'}
 ],
 'next_gate':'Independent plan/oracle review before production. Root alone imports, compiles, runs CPU/packed and actual offscreen checks; actual observations must bind final source and binary.'
})
text('api.txt','''Proposed private API, no implementation or new public API:

// native.rs registers mod core; parent box_decoration.rs cfg(feature="raster-bridge")
// reexports only BoxCoreWindow, BoxCoreReservation and BoxCoreTiles as pub(crate).
// Reuse BoxMaskError, BoxMaskInfo, BoxMaskTileInfo and BoxMaskTile unchanged.

pub(crate) struct BoxCoreWindow {
    mask: ShapeMask, candidate: PixelWindow, stored: PixelWindow,
    core: PixelWindow, partition: [Option<BoxMaskTileInfo>; 7], info: BoxMaskInfo,
}
pub(crate) struct BoxCoreReservation { window: BoxCoreWindow }
pub(crate) struct BoxCoreTiles { tiles: [Option<BoxMaskTile>; 7] }

impl BoxCoreWindow {
    pub(crate) fn new(width:u32, height:u32, outer:RoundedBox,
        cutout:Option<RoundedBox>, clip:Rect) -> Result<Option<Self>,BoxMaskError>;
    pub(crate) fn core_rect(&self) -> Rect; // integer screen rectangle, metadata only
    pub(crate) fn reserve(self, remaining:&mut u64)
        -> Result<BoxCoreReservation,BoxMaskError>;
}
impl BoxCoreReservation {
    pub(crate) fn info(&self) -> BoxMaskInfo; // shape_count=1, tile_count excludes Rect
    pub(crate) fn core_rect(&self) -> Rect;
    pub(crate) fn tiles(&self) -> impl Iterator<Item=BoxMaskTileInfo> + '_;
    pub(crate) fn materialize<E>(self,
        admit:impl FnOnce(&Self)->Result<(),E>,
        error:impl Fn(BoxMaskError)->E) -> Result<BoxCoreTiles,E>;
}
impl BoxCoreTiles {
    pub(crate) fn into_tiles(self) -> impl Iterator<Item=BoxMaskTile>;
}

The three owners are move-only. No externally callable unfunded coverage API.
Private test hooks mirror the old reserve_with/materialize_with pattern, with
separate counters for the four proof queries, candidate classifications, payload
reserves and materialized cells. All seven pairs of payload allocations must
succeed before the first coverage evaluation. A failed late reserve drops its
already allocated empty siblings; no partially populated tile escapes.

Native private seam:
BoxReservation::Core { reservation:BoxCoreReservation, raw_core:BrowserRect }
exact_raw_core(screen:BrowserRect, raw_outer:BrowserRect, offset:(f32,f32))
    -> Option<BrowserRect> // fixed metadata only; integer checks, 1M bounds,
                          // exact f32 round-trip; not a public proof constructor
Ledger::box_core(&mut self, &BoxCoreReservation, phase:usize, command:usize)
    -> NativeResult<()> // copied ledger, operations += K, all tile charges, commit
NativeSceneStats::box_cores:usize // admitted original Core commands, even alpha0
Existing box_rectangles stays pure no-mask Color commands; box_masks counts tiles.

Route: unchanged rect_work -> unchanged mask Window::new -> only old MaskLimit
tries Core::new -> exact_raw_core -> reserve -> original-command table.
Core materialization admits complete ledger before all reserves. Lower one raw
Rect plus each absolute Glyph using original color and current scopes. No new
core opcode/shader/source kind. All original command slots stay bounded by256.
''')
put('ledger.json',{
 'status':'proposed_policy_frozen_before_implementation','variables':{'P':'area of original candidate C','I':'integer core area','A':'Partial classifier cells in C minus I','E':'stored edge coverage cells, area(M)-I','K':'nonempty width-split edge tiles, at most7','R':'sum of tile heights'},
 'work':{'first_stage':'12+P','second_stage':'2P+16A+E+R','total':'12+3P+16A+E+R','zero_alpha_or_zero_opacity':'identical conservative tariff','outside_selection':'old tariffs unchanged'},
 'fixed12_explanation':{
  'setup8':'Retain the existing SETUP_WORK=8 policy envelope for bounded command setup. It is not a CPU instruction count. Existing helper constructors/proofs already treat validation/window/partition metadata as bounded setup rather than per-field work.',
  'bounded_metadata_operations':['viewport/geometry/cutout validation','exact existing candidate and storage window expressions','four used-radius maxima with zero-axis handling','four integer inset/intersection bounds','at most4 residual band descriptors and7 strip descriptors','checked area/row/payload totals and individual-cap comparison','adapter integer/raw-coordinate domain checks','four-field same-f32 raw Rect round-trip checks'],
  'additional4':'One funded whole-core corner membership query for each of four hull vertices. Evaluate all four explicitly after the first debit. Queries use the same bounded four-corner RoundedBox::contains; no scan or ellipse samples precede payment.',
  'partition_bound':'No input-sized metadata loop: at most4 radius records,4 bands,7 strips and4 round-trip fields. These bounds do not depend on P. No per-pixel proof is hidden in setup8.',
  'conservative_scans':'P pays the original classification allowance although only P-I candidate cells are classified. The second-stage twoP retains both original shape-classification and destination-paint allowances; only actual edge storage E and rows R replace old whole-mask storage.'
 },
 'transaction':{'cpu':'First debit atomic. If it fails, remaining is unchanged and proof/classification counts are0. If second debit fails, first remains spent, second unchanged, no reservation or payload returned. No refund/retry.','shared_ledger':'Use one local copy. Add K operations (one original operation already counted), both work terms, then call current mask(area,height,true,false,original_failure) for every tile in deterministic order. Commit only after every tile admits.','allocation':'Call aggregate admit before reserve. Reserve coverage and row Vec for every tile; validate empty vectors and minimum capacities. Only then fill rows and evaluate edge samples. Existing allocation-failure mapping retained.','publication':'Fixed MAX_COMMANDS destination capacity already reserved; after successful resources/allocations, append one Rect and K Glyphs. No partially admitted batch is exposed.'},
 'unchanged_caps':{'original_and_lowered_commands':256,'sources':256,'scopes':32,'tile_axis':1024,'individual_and_shared_mask_cells':262144,'row_entries':65536,'frame':[1280,1024],'native_gpu_buffer_bytes':16777216,'padded_invocations':4000000,'cpu_pixels':'clamp(frame_area*16,1000000,32000000)'},
 'storage':{
  'owned_cpu_payload':'E + R*sizeof(i32); aggregate <= MAX_MASK_COVERAGE_BYTES + MAX_ROW_ENTRIES*sizeof(i32), unchanged.',
  'packed_edge_input':'(E+R)*sizeof(u32); existing packed-input cap includes complete shared totals.',
  'per_original_metadata':'MAX_COMMANDS*sizeof(Option<BoxReservation>) uses the actual enlarged enum; no fixed estimated byte count and no per-command boxing.',
  'temporary_peak_addition':'Conservatively add 2*sizeof(BoxCoreWindow) + 2*sizeof(BoxCoreReservation) + sizeof(BoxCoreTiles) + 2*sizeof(BrowserRect) to existing preparation_peak_bytes terms. Existing two BoxReservation temporary copies are retained as well, intentionally overcounting possible moves. BoxCoreWindow already includes all7 tile descriptors, candidate/stored/core windows, ShapeMask and BoxMaskInfo; no separate allocated partition.',
  'handoff':'The existing MAX_COMMANDS*sizeof(BoxMaskTile) destination term plus one BoxCoreTiles accounts for up to7 temporary tile owners coexisting with destination metadata. Payloads move, not clone; global mask/row payload terms already bound them. No extra source/color buffers.',
  'not_claimed':'Actual compiler frame/stack layout, RSS, allocator capacity overhead, hardware time and new measured type sizes are not inferred. This is the existing configured structural allowance accounting, extended symbolically; no configured stack limit changes.'
 },
 'counter_policy':{'box_cores':'one per original admitted new-route Color command','box_masks':'K actual owned edge tiles','box_rectangles':'unchanged pure rectangle route only','lowered_commands':'K+1 for this command, plus unchanged surrounding scopes','box_loop_work':'sum of both prepaid stages','cpu_pixel_upper_bound':'old global/other geometry debt plus new total, no double debit','mask_sources':'one fresh mask source per tile'},
 'proof_failure':'If any funded whole-core membership check fails, refuse MaskPreparation; no coverage materialization or fallback retry. Correct conservative insets should make this unreachable for valid selected inputs, but retain the defensive check.'
})
# Independent literal bytes. Radius1 has13/16 corner hits and full coverage elsewhere.
# Seven-strip coverage uses exact rational ellipse inequalities, not renderer code.
def rgba_fill(w,h,body,corner=None,origin=(0,0)):
 b=bytearray(bytes.fromhex(body+'ff')*(w*h))
 if corner:
  for x,y in [(origin[0],origin[1]),(w-1,origin[1]),(origin[0],h-1),(w-1,h-1)]:
   if 0<=x<w and 0<=y<h:b[4*(y*w+x):4*(y*w+x)+4]=bytes.fromhex(corner+'ff')
 return bytes(b)
def lit(name,w,h,b,rule):
 assert len(b)==w*h*4
 q=P/'literals'/f'{name}.rgba';q.write_bytes(b)
 return {'name':name,'width':w,'height':h,'format':'RGBA8 row-major opaque final frame','rule':rule,'file':binding(q)}
frames=[]
frames.append(lit('core-radius1',512,513,rgba_fill(512,513,'ff0000','ff3030'),'All red except four corners ff3030;13/16 sample hits quantize207, white inverse48.'))
frames.append(lit('core-alpha128',512,513,rgba_fill(512,513,'ff7f7f','ff9898'),'Source red alpha128; corners floor(128*207/255)=103, inverse152; interior inverse127.'))
frames.append(lit('core-opacity-half',512,513,rgba_fill(512,513,'ff8080','ff9898'),'Source opaque red in opacity0.5; RGBA16 pop to white gives interior green/blue127.5 rounded128 and corners151.5 rounded152.'))
frames.append(lit('core-alpha128-opacity-half',512,513,rgba_fill(512,513,'ffbfbf','ffcccc'),'Source alpha128 in opacity0.5; interior inverse191, corners203.5 rounded204.'))
frames.append(lit('core-suppressed',512,513,rgba_fill(512,513,'ffffff'),'Alpha0 or opacity0: all white, identical conservative core reservation/mask counts.'))
frames.append(lit('core-full-viewport',1280,1024,rgba_fill(1280,1024,'ff0000','ff3030'),'All red except the four radius1 corners; same corner207 literal.'))
b=bytearray(rgba_fill(514,514,'ffffff'))
for y in range(1,514):
 for x in range(1,514):b[4*(y*514+x):4*(y*514+x)+4]=bytes.fromhex(('ff3030' if x==513 and y==513 else 'ff0000')+'ff')
frames.append(lit('core-fractional-clip',514,514,bytes(b),'Outer514 square/radius1; clip(.5,.25,513,513), integer origins x/y1..513; row0 and col0 white, sole surviving corner(513,513)ff3030.'))
# Exact boundary sample-count row for rx1100,ry1 on the left; rx1,ry1 on right.
def member8(x8,y8):
 if not (0<=x8<1280*8 and 0<=y8<205*8):return False
 for i,rx in enumerate((1100,1,1,1100)):
  ry=1
  dx=rx*8-x8 if i in (0,3) else x8-(1280-rx)*8
  dy=8-y8 if i<2 else y8-204*8
  if dx>0 and dy>0 and dx*dx*ry*ry+dy*dy*rx*rx>64*rx*rx*ry*ry:return False
 return True
hits=[sum(member8(x*8+sx,sy) for sx in (1,3,5,7) for sy in (1,3,5,7)) for x in range(1280)]
partial=sum(not all(member8(x*8+sx,sy) for sx in (1,7) for sy in (1,7)) for x in range(1280))*2
assert partial==1138
row=bytes(v for n in hits for v in (255,255-(255*n//16),255-(255*n//16),255))
b=row+bytes.fromhex('ff0000ff')*(1280*203)+row
frames.append(lit('core-seven-tiles',1280,205,b,'Used left radii(1100,1),right(1,1), never normalized. Top/bottom exact rational quarter-ellipse sample row;203 full-red middle rows.'))
put('literals/seven-tile-row.json',{'derivation':'At positions(8x+s,t), s/t odd1,3,5,7, require dx^2*ry^2+dy^2*rx^2 <=64*rx^2*ry^2 in every applicable corner quadrant. No f32/renderer evaluation.','sample_hits_by_x':hits,'partial_cells_total':partial})
frames.append(lit('old-cap-new-admission',1280,205,rgba_fill(1280,205,'000000'),'Unmodified original radius0.125 mask_square input; all sample extrema are inside, so every pixel remains black.'))
# Counter constants are hand-derived and explicitly asserted here, not measured.
def case(name,w,h,p,core,a,tiles,expected):
 i=core[2]*core[3];e=sum(t[2]*t[3] for t in tiles);r=sum(t[3] for t in tiles);k=len(tiles)
 assert expected==(12+p,2*p+16*a+e+r,12+3*p+16*a+e+r,e,r,k)
 return {'name':name,'frame':[w,h],'P':p,'core':core,'I':i,'A':a,'tiles_xywh':tiles,'K':k,'E':e,'R':r,'classification_work':expected[0],'materialization_work':expected[1],'total_work':expected[2],'cpu_payload_bytes':e+4*r,'packed_input_bytes':4*(e+r),'candidate_classifications':p-i,'whole_core_queries':4,'materialized_cells':e,'box_cores':1,'box_rectangles':0,'box_masks':k,'lowered_paint_commands':k+1,'parent_outcome':'MaskPreparation, phase0 command0; source-derived prediction, no run'}
cases=[
 case('radius1',512,513,262656,[1,1,510,511],4,[[0,0,512,1],[0,512,512,1],[0,1,1,511],[511,1,1,511]],(262668,528446,791114,2046,1024,4)),
 case('old-cap',1280,205,262400,[1,1,1278,203],0,[[0,0,1024,1],[1024,0,256,1],[0,204,1024,1],[1024,204,256,1],[0,1,1,203],[1279,1,1,203]],(262412,528176,790588,2966,410,6)),
 case('full-viewport',1280,1024,1310720,[1,1,1278,1022],4,[[0,0,1024,1],[1024,0,256,1],[0,1023,1024,1],[1024,1023,256,1],[0,1,1,1022],[1279,1,1,1022]],(1310732,2628156,3938888,4604,2048,6)),
 case('fractional-clip',514,514,263169,[1,1,512,512],1,[[1,513,513,1],[513,1,1,512]],(263181,527892,791073,1025,513,2)),
 case('seven-tiles',1280,205,262400,[1100,1,179,203],1138,[[0,0,1024,1],[1024,0,256,1],[0,204,1024,1],[1024,204,256,1],[0,1,1024,203],[1024,1,76,203],[1279,1,1,203]],(262412,769684,1032096,226063,613,7))]
put('oracles.json',{
 'status':'independent_preimplementation_literals','observed_execution':False,'frames':frames,'cases':cases,
 'radius1_scope_controls':{'alpha128':'same reservation/stats/work791114','alpha0':'same reservation/stats/work791114; actual draws may be suppressed','opacity_half':'same box work791114; two scope commands retain full-area debt525312, total CPU upper1316426; same core/mask stats; RGBA16 group scratch required','alpha128_opacity_half':'same accounting as opacity_half','opacity0':'same accounting as opacity_half, all-white frame, existing planner suppression'},
 'padded_invocation_literals':{'radius1':811008,'full_viewport':3969024,'derivation':'Two padded full-frame grids (clear+conversion), one padded core grid, and one padded grid per edge tile; each dimension rounded up to8. No runtime observation.'},
 'gpu_upper_literals':{'radius1':2115080,'full_viewport':10514432,'derivation':'Root target4*area plus256-byte-row-aligned conversion target+16 uniform, edge input4*(E+R), and(operations+1)*256 parameters. No opacity/source-image payload in these two cases.'},
 'old_preservation':{'frame':[1280,204],'P':261120,'A':0,'box_masks':2,'coverage':261120,'rows':408,'work':1044896,'all_pixels':'000000','new_core_count':0},
 'negative_controls':[
  {'name':'original-oversized-plus-zero-area-cutout','input':'Same1280x205 radius0.125 black Color, cutout=Some(square(0,0,0,0))','expected':'MaskPreparation at0/0; no core proof or class scan'},
  {'name':'fractional-raw-cancellation','input':'512x513 radius1 raw(-.25,-.75,512,513), offset(.25,.75)','expected':'MaskPreparation; conservative first slice excludes fractional raw/offset despite integer translated geometry'},
  {'name':'raw-core-out-of-domain','input':'512x513 radius1 raw x1000000, offset x-1000000; visible outerx0; core rawx1000001','expected':'MaskPreparation; exact original raw outer valid but derived raw Rect violates existing1M field bound'},
  {'name':'empty-inset','input':'512x513 outer radius(256,256.5) all corners','expected':'MaskPreparation; core width0'},
  {'name':'residual-over-cap','input':'1280x1024 outer radius(400,400) all corners','expected':'MaskPreparation; core480x224, residual1203200 >262144'},
  {'name':'invalid-before-alpha0-or-disjoint','input':'NaN/negative/over16M used geometry or invalid raw1M input even alpha0/disjoint','expected':'existing InvalidGeometry precedence'},
  {'name':'unsupported-later-paint-preflight','input':'eligible oversized Color then rounded BoxImage/Gradient','expected':'existing later UnsupportedBoxDecoration before any Color classifier/allocation'},
  {'name':'legacy-upper-clip-cancellation','input':'Retain old helper test x bits0xbfffec57,width4,clip(-2,0,3,1),frame2x1','expected':'old P2,M1,work16 unchanged; new helper ineligible fractional geometry; full candidate fee remains documented'}
 ]
})
# Full old file retained; exactly one existing test group migration, with original input untouched.
rel='src/graphics/raster_bridge/native/box_decoration_tests.rs';old=(R/rel).read_text()
a=old.index('    assert_eq!(\n        plan_native_scene(',old.index('fn native_box_color_shared_mask_area_cap_is_not_per_strip()'))
# Locate this exact assertion end before the group's closing brace.
z=old.index('\n}\n\n#[test]',a)
original=old[a:z]
assert 'at(FallbackKind::MaskPreparation, 0, 0)' in original
addition='''    // Same original oversized input: the new core route admits its exact pixels.
    let result = checked(frame, frame, &commands, &vec![0; 262_400]);
    assert_eq!(
        (result.stats().box_cores, result.stats().box_masks,
         result.stats().coverage_bytes, result.stats().row_entries),
        (1, 6, 2_966, 410)
    );
    assert_eq!(result.stats().box_rectangles, 0);
    assert_eq!(result.stats().box_loop_work, 790_588);
    assert_eq!(result.stats().cpu_pixel_upper_bound, 790_588);
    assert_eq!(result.stats().bridge.lowered_commands, 7);

    // Separate forced-mask control: even an empty cutout excludes core extraction.
    let commands = [decoration(
        mask_square(0.0, 0.0, 1280.0, 205.0),
        Some(square(0.0, 0.0, 0.0, 0.0)),
        Color::BLACK,
    )];
'''+original
new=old[:a]+addition+old[z:]
(P/'migration-1/before'/rel).write_text(old);(P/'migration-1/raw'/rel).write_text(new)
(P/'migration-1/diffs/box_decoration_tests.rs.patch').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
put('migration-1/reason.json',{'status':'tests_first_proposed_migration','file':rel,'group':'native_box_color_shared_mask_area_cap_is_not_per_strip','old':'First1280x204 admitted; original1280x205 no-cutout input refused at cap.','new':'First fixture/literals unchanged. Original1280x205 input remains byte-identical and now admits exact all-black frame with frozen six-tile counters. A separate same-size Some(zero-area cutout) retains old refusal.','guard':'Do not replace the old no-cutout input, relax caps, alter old small-window tariffs or remove the original refusal assertion; it remains on the new explicit forced-mask control.','before':binding(P/'migration-1/before'/rel),'after':binding(P/'migration-1/raw'/rel),'patch':binding(P/'migration-1/diffs/box_decoration_tests.rs.patch'),'observed_execution':False})
# Explicitly permit a clipped rounded shape whose entire visible storage is core.
o=json.loads((P/'oracles.json').read_text())
o['cases'].append(case('all-visible-core',512,513,262656,[0,0,512,513],0,[],(262668,525312,787980,0,0,0)))
o['cases'][-1]['outer']=[-2,-2,516,517];o['cases'][-1]['radii']=[[1,1]]*4
put('oracles.json',o)
put('test-plan.json',{
 'status':'frozen_expected_behaviors_before_implementation','no_observed_result':True,
 'helper_groups':[
  {'name':'oversized_core_partition_and_exact_pixels','checks':'Primary512x513/radius1 literal. Four proof queries,2046 classifications/materialized cells, A4, disjoint complete core+mask partition, exact absolute rows and tariffs.'},
  {'name':'partition_reaches_seven_without_changing_used_radii','checks':'1280x205 used1100/1 horizontal radii literal; K7 exact frozen row, no normalization, E226063/R613/A1138; union equals M and no overlap.'},
  {'name':'zero_edge_payload_and_clipped_core','checks':'Outer(-2,-2,516,517),radius1,frame512x513: I=P262656,K/E/R0, work787980, zero payload reserves/evaluations; one Rect only.'},
  {'name':'selection_bounds_and_invalid_inputs','checks':'At-or-below262144 stored cells return None; above-cap literal selected. Any Some cutout, fractional translated geometry, empty core, residual over cap retain fallback. Invalid geometry rejected before empty/ineligible returns. Alpha is not a helper parameter.'},
  {'name':'two_prepaid_stages_have_exact_cuts','cases':[
    {'remaining_before':262667,'remaining_after':262667,'result':'WorkLimit','proof_queries':0,'classifications':0,'payload_reserves':0},
    {'remaining_before':262668,'remaining_after':0,'result':'WorkLimit on stage2','proof_queries':4,'classifications':2046,'payload_reserves':0},
    {'remaining_before':791113,'remaining_after':528445,'result':'WorkLimit on stage2','proof_queries':4,'classifications':2046,'payload_reserves':0},
    {'remaining_before':791114,'remaining_after':0,'result':'reservation','proof_queries':4,'classifications':2046,'payload_reserves':0}
  ]},
  {'name':'all_payload_reserves_precede_any_sample','checks':'Aggregate admission refusal: no reserve/sample calls. On seven-tile case inject failure at each1..14 coverage/row reserve; zero coverage evaluations and no result. Success14 reserves then226063 coverage evaluations, exact row origins and literal top/bottom coverage. Hook only private/test scope, no public unfunded evaluator.'}
 ],
 'native_groups':[
  {'name':'parent_failing_large_and_fullviewport_admission','checks':'CPU Canvas and independent packed-plan decoding compare every pixel with frozen literal frames; inspect DrawKind oneRectangle+K Glyphs, counters and invocation totals. Parent fails MaskPreparation before a plan for both cases.'},
  {'name':'alpha_and_opacity_do_not_double_blend_partition_seams','checks':'Primary alpha128, opacity0.5, alpha128+opacity0.5, alpha0 and opacity0 frames/counters; both sides of every core/edge seam match. Add subsequent ordinary blue1x1 at a core-edge boundary to prove original command order; existing surrounding scopes retained.'},
  {'name':'fractional_clip_and_document_fixed_round_trip','checks':'Frozen514x514 fractional clip frame. Primary equivalent raw(-3,-5,512,513)+document offset(3,5); fixed raw(-7,-9,512,513)+viewport offset(7,9), enclosed PushFixed/PopFixed and post-pop marker. Exact same core pixels and791114 box work. Reject fractional raw cancellation and raw core x1000001 guard controls. Preserve current empty and exceptional upper-clip tests.'},
  {'name':'aggregate_resources_are_one_transaction','checks':'Using primary K4/E2046/R1024: operations252 ->256 passes,253 ->257 CommandLimit; sources252 ->256 passes,253 ->257 MaskPreparation; coverage260098 ->262144 passes,260099 ->262145 MaskPreparation; rows64512 ->65536 passes,64513 ->65537 GlyphRowLimit. All exact/one-short pairs use otherwise spare resources and compare entire Ledger on failure, no payload allocation. Test aggregate GPU allowance through existing checked mask path. State counters only publish complete transaction.'},
  {'name':'preflight_and_original_work_order','checks':'Later malformed/unsupported Box paint prevents all Color classification; global full-area debt remains first. Earlier ordinary Rect debt reduces remaining before core first debit. Preserve original phase/command diagnostics and prepass regressions.'},
  {'name':'old_cap_fixture_migration','checks':'Apply only held migration-1. Original1280x204 pixels/work unchanged; original1280x205 no-cutout now admitted; separate zero-area-cutout input retains exact old refusal. Existing direct helper cap tests stay unchanged.'}
 ],
 'offscreen_correctness':{
  'fixture_names':['core-radius1','core-alpha128','core-opacity-half','core-full-viewport','core-fractional-clip','core-seven-tiles'],
  'converted_frames_per_adapter':12,'compared_bytes_per_adapter':21002272,
  'protocol':'Follow existing box-rect/image/gradient checker structure. Canvas and packed CPU checks compare independently frozen pixels first. Encoder receives only prepared Native plan; expected pixels never enter encoding. Run actual Vulkan offscreen render+conversion for both existing channel-order formats on root-selected adapters; preserve every attempt/log and binary/source binding.',
  'old_inventory':'All existing offscreen fixture names/pixels remain immutable; separate additive checker inventory. No acquired-window or timing host changes. Device-free parity is not actual GPU evidence.'
 },
 'parent_predictions':'Existing API cannot compile new helper/stat tests until source integration; unchanged-parent baseline should use public plan_native_scene with the same large inputs and expected admission, which fails at current MaskPreparation. Record this separately from later private quota cuts. No expected frame is derived from actual renderer output.',
 'review_gate':'HTML independently checks arithmetic/literals/proof/API. Root selects exact tests/checker ownership and executes; no source-ready plan claims tests have passed.'
})
paths=[
'src/graphics.rs','src/graphics/box_decoration.rs','src/graphics/box_decoration/native.rs',
'src/graphics/box_decoration/native/tests.rs','src/graphics/box_decoration/native/rect_tests.rs','src/graphics/box_decoration/native/proof_tests.rs',
'src/graphics/raster_bridge/native.rs','src/graphics/raster_bridge/native/box_decoration_tests.rs',
'crates/raster-core/src/lib.rs','crates/raster-core/src/profile.rs','crates/raster-core/src/scope.rs','crates/raster-core/src/opacity.rs',
'crates/raster-core/src/opacity_arithmetic_tests.rs','tools/vulkan-raster-probe/src/box_rect_fixtures.rs',
 'tools/vulkan-raster-probe/src/bin/box-rect-check.rs','tools/vulkan-raster-probe/src/surface_gpu.rs']
put('source-bindings.json',{'status':'source_only_current_bytes','sources':[{'relative':r,**binding(R/r)} for r in paths],'prior_audit':binding('/tmp/eris-vulkan-next-audit-1/report.json')})
# Verify literal aggregate explicitly against selected six frame bindings.
selected=set(json.loads((P/'test-plan.json').read_text())['offscreen_correctness']['fixture_names'])
assert sum(x['file']['bytes'] for x in o['frames'] if x['name'] in selected)*2==21002272
# Root frame bytes, partition and work arithmetic checked with independent integers only.
for c in o['cases']:
 w,h=c['frame'];x,y,cw,ch=c['core'];tiles=c['tiles_xywh']
 assert len(tiles)<=7 and all(0<t[2]<=1024 and 0<t[3]<=1024 for t in tiles)
 assert c['E']<=262144 and c['R']<=65536
 # Union area here is stored area. General algorithm retains C separately.
 assert c['I']+c['E']==c['P']
 def overlap(a,b):return max(a[0],b[0])<min(a[0]+a[2],b[0]+b[2]) and max(a[1],b[1])<min(a[1]+a[3],b[1]+b[3])
 parts=[c['core']]+tiles
 assert all(not overlap(a,b) for i,a in enumerate(parts) for b in parts[i+1:])
files=[p for p in sorted(P.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',{'schema':'eris-rounded-core-plan-hold-1','status':'ready_for_independent_source_review','scope':'plan/API/ledger/literals and one explicit test-only migration; no production implementation or renderer execution','files':[{'relative':str(p.relative_to(P)),**binding(p)} for p in files]})
print(json.dumps(binding(P/'source-ready.json')))
