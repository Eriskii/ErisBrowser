from pathlib import Path
import hashlib,json
source=Path('/tmp/eris-vulkan-rounded-core-plan-1');root=Path(__file__).resolve().parents[1];out=root/'plans';assert not out.exists()
files=[p for p in sorted(source.rglob('*')) if p.is_file()]
for p in files:assert not p.is_symlink() and '__pycache__' not in p.parts,p
records=[]
for p in files:
 d=p.read_bytes();q=out/p.relative_to(source);q.parent.mkdir(parents=True,exist_ok=True)
 with q.open('xb') as f:f.write(d)
 assert q.read_bytes()==d
 records.append({'original':str(p),'staged':str(q),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()})
report={'status':'staged_exact','files':records,'file_count':len(records),'total_bytes':sum(x['bytes'] for x in records)}
with (root/'root/plan-stage-1.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='files'}))
