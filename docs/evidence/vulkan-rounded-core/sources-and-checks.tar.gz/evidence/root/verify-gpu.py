from pathlib import Path
import hashlib
import json
import re
import subprocess

A = Path(__file__).resolve().parents[1]
D = A / 'gpu-host-1'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

host = json.loads((D / 'host-results.json').read_text())
probe = json.loads((A / 'root/final-probe.json').read_text())
sources = json.loads((A / 'source-2.json').read_text())['source_sha256']
assert host['success'] and host['adapter_count'] == 3 and len(host['runs']) == 4
assert host['binary_sha256'] == probe['sha256'] == sha(Path(probe['path']))
supplemental = {}
helper_bindings = dict(host['host_source_bindings'])
helper_bindings['browser_protocol.py'] = sha(A / 'worktree/tools/vulkan-raster-probe/browser_protocol.py')
for name, digest in helper_bindings.items():
    target = 'tools/vulkan-raster-probe/' + name
    path = A / 'worktree' / target
    assert digest == sha(path)
    if target in sources:
        assert sources[target] == digest
    else:
        # The inherited source inventory omitted existing Python GPU helpers.
        # Bind those unchanged parent files separately, including the imported
        # browser_protocol module omitted by the preexisting host receipt.
        parent = subprocess.check_output(['git', '-C', str(A / 'worktree'), 'show', 'HEAD:' + target])
        assert hashlib.sha256(parent).hexdigest() == digest
        supplemental[target] = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest}
total_bytes = total_frames = 0
for run in host['runs']:
    name = run['name']
    assert run['status'] == 'exited' and run['returncode'] == 0 and run['error'] is None
    assert run['cleanup']['complete'] and run['cleanup']['checker_returncode'] == 0
    assert run['cleanup']['error'] is None and run['cancellation_signal'] is None
    assert run['captured_bytes'] == run['observed_bytes'] < run['output_limit_bytes']
    for stream in ['stdout', 'stderr']:
        assert sha(D / (name + '.' + stream + '.log')) == run[stream + '_sha256']
    assert not (D / (name + '.stderr.log')).read_bytes()
    assert not (D / (name + '.supervisor.stderr.log')).read_bytes()
    if name == 'enumeration':
        assert len(run['validation']['adapters']) == 3
        continue
    lines = (D / (name + '.stdout.log')).read_text().splitlines()
    passed = [line for line in lines if line.startswith('PASS ')]
    assert len(passed) == 20
    assert all(' exact=true ' in line and 'reference=literal' in line for line in passed)
    compared = sum(int(re.search(r'\bcompared_bytes=(\d+)\b', line)[1]) for line in passed)
    assert compared == 29405216 == run['validation']['gpu_compared_bytes']
    assert run['validation']['fixtures'] == 10 and run['validation']['frames'] == 20
    assert run['validation']['formats'] == 2 and not run['validation']['acquired_surface']
    total_bytes += compared
    total_frames += len(passed)
assert total_bytes == 88215648 and total_frames == 60
result = {'status': 'pass', 'host_results_sha256': sha(D / 'host-results.json'),
          'supplemental_parent_helpers': supplemental,
          'probe_sha256': probe['sha256'], 'adapters': host['runs'][0]['validation']['adapters'],
          'frames_per_adapter': 20, 'frames': total_frames, 'compared_bytes_per_adapter': 29405216,
          'compared_bytes': total_bytes, 'acquired_surface': False,
          'scope': 'Source/binary/host-output joins and retained exact-comparison result rows; raw readback was compared in-process and is not archived.'}
with (A / 'root/gpu-verification.json').open('x') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps(result))
