from pathlib import Path
import hashlib,json,os,shutil
r=Path(__file__).resolve().parents[1];s=r/'source-2.json';v=json.loads(s.read_text())['source_sha256']
for name,digest in v.items():assert hashlib.sha256((r/'worktree'/name).read_bytes()).hexdigest()==digest,name
receipt=json.loads((r/'validation/probe-final-build-2.json').read_text());assert receipt['exit']==0
assert hashlib.sha256((r/'validation'/receipt['log']).read_bytes()).hexdigest()==receipt['sha256']
source=r/'target-msrv/debug/eris-vulkan-box-core-check';target=r/'eris-vulkan-box-core-check-final-1';assert not target.exists()
shutil.copyfile(source,target);os.chmod(target,0o555)
digest=hashlib.sha256(target.read_bytes()).hexdigest();assert digest==hashlib.sha256(source.read_bytes()).hexdigest()
record={'path':str(target),'bytes':target.stat().st_size,'sha256':digest,'rust':'1.88.0','profile':'dev','manifest':'tools/vulkan-raster-probe/Cargo.toml','features':['browser-bridge'],'strip_mode':'none','source_inventory':s.name,'source_inventory_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'verified_source_inputs':len(v),'build':receipt}
with (r/'root/final-probe.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
