"""Independent data-only read/hash/count audit. Does not import/run project code."""
from pathlib import Path
import hashlib,json,re,tarfile
A=Path('/tmp/eris-vulkan-rounded-core-1'); W=A/'worktree'; P=Path('/tmp/eris-vulkan-rounded-core-plan-1')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def read(p):return json.loads(Path(p).read_text())
src=read(A/'source-2.json')['source_sha256'];assert len(src)==810
assert all(sha(W/n)==s for n,s in src.items())
old=read(A/'source-1.json')['source_sha256'];delta=sorted(n for n in src if src[n]!=old.get(n));assert delta==['tests/vulkan_rounded_core.rs','tools/vulkan-raster-probe/src/box_core_fixtures.rs']
receipts={}
for p in sorted((A/'validation').glob('*.json')):
 d=read(p)
 if 'log' in d and 'sha256' in d:
  assert sha(A/'validation'/d['log'])==d['sha256'],p
  receipts[p.stem]={'exit':d['exit'],'receipt':bind(p),'log':bind(A/'validation'/d['log'])}
selected=['native-full-2','default-full-2','strict-stable-2','strict-msrv-2','format-check-2','format-probe-check-2','browser-final-build-1','references-final-1','core-focused-1','core-frames-1','probe-full-msrv-1','probe-strict-msrv-2','probe-strict-stable-1','probe-python-core-1','probe-final-build-2','gpu-host-1']
assert all(receipts[n]['exit']==0 for n in selected)
assert {n:v['exit'] for n,v in receipts.items() if v['exit']!=0}=={'parent-admission-1':101,'strict-stable-1':101}
tot=read(A/'root/full-suite-totals-final.json'); suites={}
for name,expected in [('native-full-2',3213),('default-full-2',2886)]:
 text=(A/'validation'/f'{name}.log').read_text();target=None;roster=[];rows=[]
 for line in text.splitlines():
  m=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
  if m:target=m[1]
  if re.match(r'\s+Doc-tests ',line):target=line.strip()
  m=re.fullmatch(r'test (\S+) \.\.\. (ok|FAILED|ignored)',line)
  if m:roster.append({'target':target,'test':m[1],'status':m[2]})
  m=re.match(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',line)
  if m:
   assert m[1]=='ok' and list(map(int,m.groups()[2:]))==[0,0,0,0];rows.append({'target':target,'passed':int(m[2])})
 assert len(roster)==sum(r['passed'] for r in rows)==expected
 assert len({(r['target'],r['test']) for r in roster})==expected and all(r['status']=='ok' for r in roster)
 assert roster==tot[name]['roster'] and rows==tot[name]['per_target'] and len(rows)==48
 assert sum(r['passed'] for r in rows if r['target']=='tests/worker.rs')==89
 suites[name]={'passed':expected,'failed':0,'ignored':0,'result_rows':48,'worker_tests':89,'log':receipts[name]['log']}
new_groups={}
for n,count in [('src/graphics/box_decoration/native/core_tests.rs',9),('src/graphics/raster_bridge/native/box_core_tests.rs',9),('tests/vulkan_rounded_core.rs',5)]:
 names=re.findall(r'#\[test\]\s*fn\s+(\w+)',(W/n).read_text());assert len(names)==count
 for name in names:assert sum(r['test'].split('::')[-1]==name for r in tot['native-full-2']['roster'])==1,name
 new_groups[n]=names
probe=(A/'validation/probe-full-msrv-1.log').read_text();pr=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',probe)
assert len(pr)==18 and sum(int(r[0]) for r in pr)==20 and all(list(map(int,r[1:]))==[0,0,0,0] for r in pr)
assert 'Ran 4 tests' in (A/'validation/probe-python-core-1.log').read_text()
for name in ['final-browser','final-probe']:
 d=read(A/'root'/f'{name}.json');assert sha(d['path'])==d['sha256'];assert Path(d['path']).stat().st_size==d['bytes'];assert d['source_inventory_sha256']==sha(A/'source-2.json') and d['verified_source_inputs']==810
 assert d['build']==read(A/'validation'/d['build']['log'].replace('.log','.json'))
ref=read(A/'reftests-final/report.json');cmp=read(A/'root/reference-comparison-final.json');assert ref['binary']==read(A/'root/final-browser.json')['path'];assert ref['passed']==ref['total']==len(ref['cases'])==102 and ref['failed']==0
assert cmp['report_sha256']==sha(A/'reftests-final/report.json')
parent=W/'docs/evidence/promise-finally';ps=read(parent/'summary.json');arc=parent/'sources-and-checks.tar.gz';assert sha(arc)==ps['archive']['sha256']==cmp['parent_archive_sha256'];assert arc.stat().st_size==ps['archive']['bytes']
images={r['name']:r for r in cmp['images']};seen=set()
with tarfile.open(arc,'r:gz') as t:
 for m in t:
  pref='evidence/reftests-final/'
  if m.name.startswith(pref) and m.name.endswith('.png'):
   n=m.name[len(pref):];assert m.isfile() and n not in seen and '/' not in n;seen.add(n)
   b=t.extractfile(m).read();cur=A/'reftests-final'/n;assert b==cur.read_bytes();assert len(b)==images[n]['bytes'] and sha(cur)==images[n]['sha256']
assert len(seen)==204 and seen==set(images)=={p.name for p in (A/'reftests-final').glob('*.png')}
host=read(A/'gpu-host-1/host-results.json');gpu=read(A/'root/gpu-verification.json');assert host['success'] and len(host['runs'])==4 and host['adapter_count']==3
assert gpu['host_results_sha256']==sha(A/'gpu-host-1/host-results.json') and gpu['probe_sha256']==host['binary_sha256']==read(A/'root/final-probe.json')['sha256']
for v in host['loader']['files']:assert sha(v['resolved'])==v['sha256'] and Path(v['resolved']).stat().st_size==v['bytes']
for n,s in host['host_source_bindings'].items():assert sha(W/'tools/vulkan-raster-probe'/n)==s
assert len(gpu['supplemental_parent_helpers'])==7
for n,b in gpu['supplemental_parent_helpers'].items():
 assert n not in src and bind(W/n)==b
 assert sha(Path('/tmp/eris-promise-finally-1/worktree')/n)==b['sha256']
frames={f['name']:f for f in read(P/'offscreen-before-1/literal-selection.json')['frames']};assert len(frames)==10
for f in frames.values():assert bind(f['literal']['path'])==f['literal']
all_rows=[]
for i,run in enumerate(host['runs']):
 assert run['status']=='exited' and run['returncode']==0 and run['error'] is None and run['cancellation_signal'] is None
 assert run['cleanup']['complete'] and run['cleanup']['descendants']==0 and run['cleanup']['checker_returncode']==0 and run['cleanup']['error'] is None
 assert run['captured_bytes']==run['observed_bytes']<run['output_limit_bytes']==2097152
 for st in ['stdout','stderr']:assert sha(A/'gpu-host-1'/f'{run["name"]}.{st}.log')==run[st+'_sha256']
 assert (A/'gpu-host-1'/f'{run["name"]}.stderr.log').stat().st_size==0
 assert (A/'gpu-host-1'/f'{run["name"]}.supervisor.stderr.log').stat().st_size==0
 lines=(A/'gpu-host-1'/f'{run["name"]}.stdout.log').read_text().splitlines()
 if i==0:
  adapters=run['validation']['adapters'];assert lines==adapters and len(adapters)==3;continue
 assert lines[:3]==adapters and run['command']==[host['binary'],'--adapter',str(i-1)]
 rows=[];pairs=set()
 for line in lines[3:-1]:
  sp=line.split();assert sp[0]=='PASS';name=sp[1];d=dict(s.split('=',1) for s in sp[2:]);f=frames[name]
  assert (name,d['format']) not in pairs;pairs.add((name,d['format']));assert d['format'] in ['Bgra8Unorm','Rgba8Unorm']
  for k in ['width','height']:assert int(d[k])==f[k]
  assert int(d['compared_bytes'])==4*f['width']*f['height']==f['literal']['bytes']
  for k,v in f['metrics'].items():
   if k=='exact_invocations':
    if v is not None:assert int(d['total_invocations'])==v
   else:assert int(d[k])==v
  assert d['cores']=='1' and all(d[k]=='true' for k in ['exact','canvas','packed_native','rounded_color_core']) and d['reference']=='literal'
  assert int(d['conversion_invocations'])<=int(d['total_invocations'])<=4000000 and int(d['planned_bytes'])<=16777216
  rows.append(d)
 assert pairs=={(n,f) for n in frames for f in ['Bgra8Unorm','Rgba8Unorm']}
 assert len(rows)==20 and sum(int(r['compared_bytes']) for r in rows)==29405216
 assert lines[-1]==f'COMPLETE adapter={i-1} fixtures=10 frames=20 compared_bytes=29405216 exact=true rounded_color_core=true custom_rectangle_glyph_shaders=true offscreen=true acquired_surface=false'
 all_rows+=rows
assert len(all_rows)==gpu['frames']==60 and sum(int(r['compared_bytes']) for r in all_rows)==gpu['compared_bytes']==88215648
ci=read(A/'validation/parent-ci-final.json');assert ci['headSha']==read(A/'source-2.json')['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
result={'status':'clear','scope':'Independent data-only hash/count/readback of existing records; no compiler, project import, test, renderer, GPU, browser, publication script or Git execution.','source':bind(A/'source-2.json'),'source_count':810,'source1_to_source2':delta,'checked_receipts':receipts,'selected_receipts':selected,'suites':suites,'new_root_groups':new_groups,'probe':{'passed':20,'rows':18,'python_groups':4},'references':{'pairs':102,'byte_identical_parent_pngs':204,'parent_archive':bind(arc)},'gpu':{'adapters':adapters,'frames':60,'compared_bytes':88215648,'descendants':0,'actual_rows_bound_to_frozen_metrics':60,'supplemental_helpers':gpu['supplemental_parent_helpers'],'parent_helper_check':'Current files match the retained published AM checkout; root verify-gpu.py additionally checks parent Git blobs. Six supplemental runtime-hashed helpers plus separately verified imported browser_protocol.py.','raw_frames_archived':False},'parent_ci':{'run':ci['databaseId'],'head':ci['headSha'],'jobs':9},'bindings':[bind(A/'root'/n) for n in ['formatted-source-review.json','full-suite-totals-final.json','reference-comparison-final.json','gpu-verification.json','select-evidence.py','verify-gpu.py','final-browser.json','final-probe.json']]+[bind(W/n) for n in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/vulkan-rounded-core.md']]}
(A/'root/html-inert-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'clear','source':810,'suites':{k:v['passed'] for k,v in suites.items()},'gpu_frames':60,'gpu_compared_bytes':88215648,'reference_pngs':204}))
