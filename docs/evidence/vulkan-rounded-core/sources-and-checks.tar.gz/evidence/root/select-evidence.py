from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]


def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inventory = A / 'source-2.json'
sources = json.loads(inventory.read_text())['source_sha256']
assert len(sources) == 810
for name, sha in sources.items():
    assert bind(A / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['native-full-2', 'default-full-2', 'strict-stable-2', 'strict-msrv-2',
              'format-check-2', 'format-probe-check-2', 'browser-final-build-1',
              'references-final-1', 'core-focused-1', 'core-frames-1',
              'probe-full-msrv-1', 'probe-strict-msrv-2', 'probe-strict-stable-1',
              'probe-python-core-1', 'probe-final-build-2', 'gpu-host-1']:
    r = json.loads((A / 'validation' / (label + '.json')).read_text())
    assert r['exit'] == 0
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256']
    checks[label] = r
for name in ['formatted-source-review.json', 'validation-review.json']:
    assert json.loads((A / 'root' / name).read_text())['status'] in ['clear', 'clear_source_only']
totals = json.loads((A / 'root/full-suite-totals-final.json').read_text())
assert totals['native-full-2']['passed'] == 3213
assert totals['default-full-2']['passed'] == 2886
assert all(v['failed'] == v['ignored'] == 0 for v in totals.values())
reference = json.loads((A / 'root/reference-comparison-final.json').read_text())
assert reference['status'] == 'pass' and reference['pairs'] == 102 and reference['unchanged_pngs'] == 204
ci = json.loads((A / 'validation/parent-ci-final.json').read_text())
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 9
assert all(j['conclusion'] == 'success' for j in ci['jobs'])
gpu = json.loads((A / 'root/gpu-verification.json').read_text())
assert gpu['status'] == 'pass' and gpu['frames'] == 60 and gpu['compared_bytes'] == 88215648
artifacts = {}
for directory in ['plans', 'production-1', 'correction-1', 'validation', 'root', 'reftests-final', 'gpu-host-1']:
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and p.name not in ['selection-final.json', 'publication-verification.json']:
            assert not p.is_symlink() and '__pycache__' not in p.parts
            artifacts[str(p.relative_to(A))] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json']:
        artifacts[p.name] = bind(p)
for name in gpu['supplemental_parent_helpers']:
    artifacts['supplemental-host-source/' + name] = bind(A / 'worktree' / name)
    assert artifacts['supplemental-host-source/' + name] == gpu['supplemental_parent_helpers'][name]
for name in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/vulkan-rounded-core.md']:
    artifacts['documentation/' + name] = bind(A / 'worktree' / name)
selection = {
    'source_inventory': bind(inventory), 'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': json.loads(inventory.read_text())['base'],
        'parent_ci': {'status': 'success', 'jobs': 9, 'receipt': bind(A / 'validation/parent-ci-final.json')},
        'scope': 'Selected individually oversized rounded Color boxes become a proven fully covered rectangle plus at most seven edge masks, preserving existing shared limits and ordered blending.',
        'source_inputs': 810,
        'supplemental_host_inputs': 7,
        'new_test_groups': {'private_helper': 9, 'private_native': 9, 'public_frames': 5,
                            'root_total': 23, 'probe_fixture': 1, 'python_protocol': 4},
        'baseline': json.loads((A / 'baseline-result.json').read_text()),
        'history': {
            'old_test_migrations': 'Two former oversized-mask refusals now exercise core admission or the next CPU budget gate. Original geometry is retained; explicit cutout controls preserve MaskPreparation refusal.',
            'validation_parent': 'Parent observations were on 3275179229f6d7753cedf0b66bd91998ada21707; final implementation and checks include Promise.finally at 1ab6c3be57dc0b13dfe10f75eb2da1f4d52fb54a.',
            'correction': json.loads((A / 'correction-1/source-correction.json').read_text()),
            'source1_checks': 'Retained successful full suites and strict Rust1.99 lint failure before two test-only iterator corrections. Final source2 full suites and strict checks rerun.',
            'host_inventory': 'Existing host Python helpers were absent from the inherited source inventory. Seven unchanged parent helpers are separately bound and archived; host runtime hashes join six and the transitively imported browser_protocol.py is verified against the parent Git blob.',
            'final_source': bind(inventory)
        },
        'checks': checks,
        'full_suite_totals': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k, v in totals.items()},
        'confined_worker_tests_per_full_suite': 89,
        'probe_tests': {'passed': 20, 'failed': 0, 'ignored': 0, 'result_rows': 18},
        'python_protocol_groups': 4,
        'references': {k: reference[k] for k in ['pairs', 'unchanged_pngs', 'parent_archive_sha256', 'report_sha256']},
        'reference_baseline': 'Published Promise.finally archive at 1ab6c3be57dc0b13dfe10f75eb2da1f4d52fb54a.',
        'browser': json.loads((A / 'root/final-browser.json').read_text()),
        'probe': json.loads((A / 'root/final-probe.json').read_text()),
        'gpu': gpu,
        'resource_policy': {
            'unchanged_limits': True, 'commands_and_sources': 256, 'coverage_bytes': 262144,
            'rows': 65536, 'gpu_bytes': 16777216, 'shader_invocations': 4000000,
            'max_edge_tiles': 7, 'first_stage_work': '12 + P',
            'second_stage_work': '2P + 16A + E + R', 'total_work': '12 + 3P + 16A + E + R',
            'terms': 'P original candidate area; A ambiguous edge candidates; E stored edge area; R edge tile rows.',
            'actual_x86_64_msrv_bytes': {'Window': 512, 'Reservation': 512, 'Tiles': 560,
                                        'MaskInfo': 80, 'MaskTile': 80, 'PixelWindow': 16,
                                        'NativeBoxReservation': 528, 'OptionNativeBoxReservation': 528,
                                        'NativeSceneStats': 320},
            'actual_layout_observation': 'Explicit output in Rust1.88 core-focused-1; no physical stack-frame or RSS measurement.'
        },
        'limits': ['Narrow integer round-trip geometry, no cutout and individual oversized Color mask only; not all rounded CSS geometry.',
                   'Resource fees and structural preparation estimates are logical accounting, not measured machine instructions, physical stack frames or resident allocator bytes.',
                   'Full1280x1024 observation uses a direct single box. A Page with an extra full-viewport canvas paint exceeds the unchanged invocation limit; selected Page fixture is512x513.',
                   'GPU comparisons are offscreen; no acquired-window observation for this checkpoint, no Chromium performance comparison or complete compatibility/security claim.',
                   'GPU readback compared inside the checker, with output receipts archived; full raw GPU frames are not archived.',
                   'Build caches reused; elapsed times are not cold-build measurements.']
    }
}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2)
    out.write('\n')
print(json.dumps({'sources': len(sources), 'artifacts': len(artifacts)}))
