from pathlib import Path
from collections import Counter
import hashlib, json, re

p = Path(__file__).resolve().parents[1]
w = p / 'worktree'
n = Path('/tmp/eris-visibility-plan-1')

def load(path):
    return json.loads(path.read_bytes())

def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def roster(path):
    return Counter(re.findall(r'^test (\S+) \.\.\. ok$', path.read_text(), re.M))

inventory = load(p / 'source-candidate-1.json')
for row in inventory['files']:
    assert dict(bound(w / row['path']), path=row['path']) == row
changed = load(p / 'root/candidate-snapshots-1.json')['changed_paths']
expected_state = dict(base=inventory['base'], changed=changed)
labels = ['parent-controls-1', 'candidate-controls-1', 'candidate-full-msrv-1',
          'candidate-full-host-vulkan-1', 'candidate-clippy-msrv-1',
          'candidate-clippy-host-vulkan-1', 'candidate-format-check-1',
          'candidate-release-1', 'candidate-reftests-1']
attempts = []
for label in labels:
    receipt = load(p / 'validation' / (label + '.json'))
    log = p / 'validation' / receipt['log']
    assert bound(log)['sha256'] == receipt['sha256']
    assert receipt['source_before'] == receipt['source_after']
    assert receipt['exit'] == (101 if label == 'parent-controls-1' else 0)
    if label == 'parent-controls-1':
        parent_state = dict(expected_state, changed=[r for r in changed if r['path'] != 'src/layout.rs'])
        assert receipt['source_before'] == parent_state
    else:
        assert receipt['source_before'] == expected_state
    rows = [tuple(map(int, values)) for values in re.findall(
        r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text(), re.M)]
    attempts.append(dict(label=label, receipt=bound(p / 'validation' / (label + '.json')),
                         command=receipt['command'], exit=receipt['exit'], log=bound(log),
                         totals=dict(passed=sum(r[0] for r in rows), failed=sum(r[1] for r in rows),
                                     ignored=sum(r[2] for r in rows), suites=len(rows))))
assert attempts[0]['totals'] == dict(passed=8, failed=6, ignored=0, suites=2)
assert attempts[1]['totals'] == dict(passed=14, failed=0, ignored=0, suites=2)
new = Counter()
for path, prefix in [('tests/canvas_display.rs', ''),
                     ('src/page/background_resource_tests.rs', 'page::background_resource_tests::')]:
    names = re.findall(r'^fn (canvas_display_\w+)\(', (w / path).read_text(), re.M)
    names = [name for name in names if name != 'canvas_display_resource_reveal_sequence']
    new.update(prefix + name for name in names)
assert sum(new.values()) == 14
for index, old_label, expected in [(2, 'candidate-full-msrv-2', 3535),
                                    (3, 'candidate-full-host-vulkan-1', 3899)]:
    assert attempts[index]['totals'] == dict(passed=expected, failed=0, ignored=0, suites=59)
    current = p / 'validation' / (attempts[index]['label'] + '.log')
    previous = n / 'validation' / (old_label + '.log')
    assert roster(current) == roster(previous) + new
report = load(p / 'reftests-1/report.json')
assert (report['passed'], report['failed'], report['total']) == (102, 0, 102)
prior = load(n / 'candidate-reftests-1/report.json')
prior_cases = {r['name']: r for r in prior['cases']}
assert set(prior_cases) == {r['name'] for r in report['cases']}
images = []
for case in report['cases']:
    assert case['status'] == 'pass' and case['different_pixels'] == 0
    for kind in ('test_image', 'reference_image'):
        a, b = Path(prior_cases[case['name']][kind]), Path(case[kind])
        assert a.read_bytes() == b.read_bytes()
        images.append(dict(name=case['name'], kind=kind, parent=bound(a), candidate=bound(b)))
summary = dict(status='pass', checkpoint='canvas-display', base=inventory['base'],
               source_inventory=bound(p / 'source-candidate-1.json'), changed_sources=changed,
               inputs=len(inventory['files']), attempts=attempts, new_test_names=sorted(new),
               regression='Parent:8 pass/6 fail; identical controls with six-line fix:14 pass/0 fail.',
               old_rosters_preserved=True, reftest_pairs=102, parent_identical_pngs=len(images),
               reftest_report=bound(p / 'reftests-1/report.json'), images=images,
               release_binary=bound(p / 'target-msrv/release/eris-browser'),
               reviews=[bound(p / name) for name in ('assessment-review-1.json',
                         'implementation-review-1.json', 'controls-review-1.json')],
               qualification='HTML root display:none canvas selection only. No new GPU hardware run, Chromium performance measurement, security certification or full browser compatibility claim. Missing-root/style-row behavior is source-reviewed only. Local test names are counted per target; no ignored tests were skipped.')
with (p / 'root/final-validation.json').open('x') as output:
    json.dump(summary, output, indent=2)
    output.write('\n')
print(json.dumps({k:summary[k] for k in ('status', 'inputs', 'reftest_pairs', 'parent_identical_pngs')}))
print(json.dumps(bound(p / 'root/final-validation.json')))
