from pathlib import Path
import gzip, hashlib, io, json, tarfile

p = Path(__file__).resolve().parents[1]
w = p / 'worktree'
out = w / 'docs/evidence/canvas-display'
out.mkdir(parents=True, exist_ok=True)
summary = json.loads((p / 'root/final-validation.json').read_bytes())
assert summary['status'] == 'pass'
for row in summary['changed_sources']:
    data = (w / row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']

paths = set()
for directory in ('implementation-1', 'controls-1', 'candidate-source-1', 'validation', 'reftests-1'):
    for path in (p / directory).rglob('*'):
        if path.is_file():
            assert not path.is_symlink()
            paths.add(path.relative_to(p).as_posix())
paths.update(['assessment-review-1.json', 'implementation-review-1.json', 'controls-review-1.json',
              'source-candidate-1.json', 'run-tool.py', 'root/run-config.py', 'root/summarize.py',
              'root/package.py', 'root/final-validation.json', 'root/controls-import-1.json',
              'root/controls-formatted-1.json', 'root/implementation-import-1.json'])
for directory in ('root/controls-formatted-1', 'root/docs-draft-1'):
    paths.update(path.relative_to(p).as_posix() for path in (p / directory).rglob('*') if path.is_file())
members = []
archive = out / 'sources-and-checks.tar.gz'
assert not archive.exists()
with archive.open('xb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz:
    with tarfile.open(fileobj=gz, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name in sorted(paths):
            data = (p / name).read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            tar.addfile(info, io.BytesIO(data))
            members.append(dict(path=name, bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
assert len(members) < 1000 and sum(row['bytes'] for row in members) < 32 * 1024 * 1024
with tarfile.open(archive, mode='r:gz') as tar:
    actual = tar.getmembers()
    assert [item.name for item in actual] == [row['path'] for row in members]
    for item, row in zip(actual, members):
        assert item.isfile() and item.size == row['bytes']
        data = tar.extractfile(item).read()
        assert data == (p / row['path']).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row['sha256']
record = dict(schema=1, checkpoint='canvas-display', validation=summary, members=members,
              archive=dict(path=archive.name, bytes=archive.stat().st_size,
                           sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),
              qualification='Selected source/check evidence. Parent outputs are bound to earlier checkpoint paths and hashes; runtime binaries are represented by build receipts and hashes. Dependencies/toolchains are not archived. Git contains the final source and documentation.')
with (out / 'validation.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(dict(status='verified', members=len(members), archive=record['archive'])))
