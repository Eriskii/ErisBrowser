from pathlib import Path
import json,hashlib,subprocess
O=Path('/tmp/eris-canvas-display-plan-1');H=O/'controls-1';W=O/'worktree';N=Path('/tmp/eris-visibility-plan-1/worktree');BASE='af46557a774e2e4b07cc23a7b6e39397eace2e04'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,j):(H/name).write_text(json.dumps(j,indent=2)+'\n')
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD']).decode().strip()==BASE
assessment=Path('/tmp/eris-canvas-display-assessment-1.json');a=json.loads(assessment.read_text())
for r in a['source_context']['source_bindings']:
 p=W/r['relative_path'];assert bind(p)['sha256']==r['sha256'];assert p.read_bytes()==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+r['relative_path']])
static=[]
rows=[
 ('canvas_display_root_none_suppresses_root_color_and_body_fallback','display:none;background:red','background:lime',[0xffffff]*48),
 ('canvas_display_root_none_suppresses_propagated_body_color','display:none;background:transparent','background:red',[0xffffff]*48),
 ('canvas_display_body_none_keeps_transparent_canvas','display:block;background:transparent','display:none;background:red',[0xffffff]*48),
 ('canvas_display_displayed_root_color_survives_body_none','display:block;background:blue','display:none;background:red',[0x0000ff]*48),
 ('canvas_display_visibility_hidden_root_keeps_canvas_color','visibility:hidden;background:yellow','background:transparent',[0xffff00]*48),
 ('canvas_display_visibility_hidden_body_keeps_propagated_color','background:transparent','visibility:hidden;background:yellow',[0xffff00]*48),
 ('canvas_display_root_precedence_keeps_ordinary_body_paint','background:blue','width:2px;height:1px;background:red',[0xff0000]*2+[0x0000ff]*46),
 ('canvas_display_multiple_none_does_not_enable_body_propagation','background:transparent;background-image:none,none','width:2px;height:1px;background:red',[0xff0000]*2+[0xffffff]*46),
]
def html(root,body):return '<!doctype html><html id=root><head><style>html,body{margin:0;padding:0}html{'+root+'}body{'+body+'}</style></head><body id=body></body></html>'
for i,(name,root,body,pixels) in enumerate(rows):
 assert (root,body)==(a['independent_controls']['matrix'][i]['html'],a['independent_controls']['matrix'][i]['body'])
 static.append({'id':name,'assessment_row':i+1,'html':html(root,body),'expected_pixels_rgb':pixels,'viewport':[8,6],'clear_rgb':0xffffff,'rationale':a['independent_controls']['matrix'][i]['purpose']})
dynamic=[]
for name,root,body,target in [
 ('canvas_display_cssom_root_owned_block_none_block','display:block;background:red','background:transparent','root'),
 ('canvas_display_cssom_body_propagated_root_block_none_block','display:block;background:transparent','width:2px;height:1px;background:red','root'),
 ('canvas_display_cssom_body_block_none_block','display:block;background:transparent','display:block;width:2px;height:1px;background:red','body')]:
 dynamic.append({'id':name,'html':html(root,body),'target':target,'modes':['sloppy','strict'],'phases':[{'source':"var canvasStyle = document.getElementById('"+target+"').style; canvasStyle.setProperty('display', 'block'); canvasStyle.display === 'block';",'expected_value':True,'expected_pixels_rgb':[0xff0000]*48},{'source':"canvasStyle.display = 'none'; canvasStyle.getPropertyValue('display') === 'none';",'expected_value':True,'expected_pixels_rgb':[0xffffff]*48},{'source':"canvasStyle.setProperty('display', 'block'); canvasStyle.display === 'block';",'expected_value':True,'expected_pixels_rgb':[0xff0000]*48}]})
resources=[]
for owner in ['root','body']:
 root='display:none;width:8px;height:6px;background:transparent';body='width:8px;height:6px;background:transparent'
 if owner=='root':root+=';background-image:url(tile.png);background-repeat:no-repeat'
 else:body+=';background-image:url(tile.png);background-repeat:no-repeat'
 resources.append({'id':'canvas_display_root_none_'+owner+'_url_waits_for_reveal','owner':owner,'html':html(root,body),'phases':[{'display':'none','source':None,'requests':['https://page.test/start'],'paint_keys':0,'image_cache':0,'background_keys':0,'page_images':0,'decoded_image_bytes':0},{'display':'block','source':"document.getElementById('root').style.display = 'block';",'requests':['https://page.test/start','https://page.test/final/tile.png'],'paint_keys':1,'image_cache':1,'background_keys':1,'page_images':1,'decoded_image_bytes':8},{'display':'none','source':"document.getElementById('root').style.display = 'none';",'requests':['https://page.test/start','https://page.test/final/tile.png'],'paint_keys':0,'cache_retained':True},{'display':'block','source':"document.getElementById('root').style.display = 'block';",'requests':['https://page.test/start','https://page.test/final/tile.png'],'paint_keys':1,'same_key_as_first_reveal':True,'cache_retained':True}]})
positive={'id':'canvas_display_displayed_root_and_body_urls_prepare_once','html_sources':[x['html'].replace('display:none','display:block',1) for x in resources],'requests_before_prepare':['https://page.test/start'],'requests_after_prepare':['https://page.test/start','https://page.test/final/tile.png'],'paint_keys':1,'repeated_prepare_same_key_and_no_extra_request':True}
put('cases.json',{'schema':1,'base':BASE,'viewport':[8,6],'clear_surface':'Explicit Canvas::clear(Color::WHITE); white is the chosen backing surface, not a CSS definition of transparent.','static':static,'dynamic':dynamic,'resources':resources,'displayed_resource_positive':positive,'resource_qualification':'Existing Page resource-selection/cache policy witness using its fake bridge; no network/process-isolation claim and no generic CSS prohibition on fetching invisible images.','scope_exclusions':['No display:contents or containment','No malformed host DOM policy expansion','No image cancellation or cache eviction','No GPU or performance execution']})
put('test-contract.json',{'schema':1,'planned_groups':14,'static_groups':8,'dynamic_groups':3,'dynamic_modes':6,'dynamic_snapshots':18,'resource_groups':3,'resource_scenes':4,'expected_parent_source_prediction':{'passed_groups':8,'failed_groups':6,'static_failed':[static[0]['id'],static[1]['id']],'dynamic_failed':[dynamic[0]['id'],dynamic[1]['id']],'resource_failed':[x['id'] for x in resources],'qualification':'Source-derived only. Root alone measures. Static failures concern canvas color; image-only cases may paint nothing already but still select/fetch an unwanted resource. Later phases after the first assertion failure remain unreached.'},'module_paths':['tests/canvas_display.rs','src/page/background_resource_tests.rs'],'registration':'Integration auto-discovery; append existing private resource module, so no module registration edit.','adapter_plan':'Eight independent full 48-pixel tests; three fresh-per-mode CSSOM scripts with snapshots after each phase; two fake-bridge initial hidden cases then reveal/hide/reveal; one independently reachable displayed positive testing both URL owners.','oracles':'Fixed full arrays and literal URLs/counts from selected semantics, existing fake bridge output and original cache policy; no producer helper computes expectations.','project_execution':False,'producer_inspection':False})
read_paths=['tests/visibility.rs','src/page/background_resource_tests.rs','src/page/background_resources.rs','src/page.rs','src/layout.rs','src/layout/layers_tests.rs','src/page/background_resource_layers_tests.rs','src/script.rs']
put('published-bindings.json',{'base':BASE,'assessment':bind(assessment),'files':[{'relative_path':p,**bind(W/p)} for p in read_paths],'refresh':'Each assessment-bound source matches af46557a published Git. N is read-only and unchanged.'})
put('literals-ready.json',{'schema':1,'status':'frozen independent canvas-display literals and expected observations','base':BASE,'assessment':bind(assessment),'cases':bind(H/'cases.json'),'test_contract':bind(H/'test-contract.json'),'published_bindings':bind(H/'published-bindings.json'),'author':bind(H/'freeze_literals.py'),'project_execution':False,'live_edits':False,'producer_inspection':False})
print(json.dumps(bind(H/'literals-ready.json')))
