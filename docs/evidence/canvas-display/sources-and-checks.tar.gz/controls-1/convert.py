from pathlib import Path
import json,hashlib,difflib,re,subprocess
O=Path('/tmp/eris-canvas-display-plan-1');H=O/'controls-1';W=O/'worktree';BASE='af46557a774e2e4b07cc23a7b6e39397eace2e04'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,s):
 p=H/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def put(p,j):write(p,json.dumps(j,indent=2)+'\n')
c=json.loads((H/'cases.json').read_text());ls=bind(H/'literals-ready.json');assert ls['sha256']=='df52bf32d347df941e100a729b55d234a619b063949c4afab53ad32d2139494b'
def raw(s):assert '"#' not in s;return 'r#"'+s+'"#'
def pixels(xs):
 assert len(xs)==48
 if len(set(xs))==1:return '['+f'0x{xs[0]:06x}'+'; 48]'
 return '[\n'+''.join('            '+', '.join(f'0x{x:06x}' for x in xs[i:i+8])+',\n' for i in range(0,48,8))+'        ]'
head='''//! Literal 8x6 canvas backgrounds; white is an explicit backing-surface clear.
use eris::{
    graphics::{Canvas, Color, Fonts},
    page::Page,
    script::Value,
};
use url::Url;

fn page(source: &str) -> Page {
    Page::from_html(Url::parse("https://canvas-display.invalid/").unwrap(), source, false)
}

fn assert_pixels(page: &Page, fonts: &Fonts, expected: &[u32; 48]) {
    let layout = page.layout(8.0, 6.0, fonts);
    let mut canvas = Canvas::new(8, 6).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(&layout.commands, fonts, &page.images, 0.0, 0.0);
    assert!(!canvas.exhausted());
    assert_eq!(canvas.pixels.as_slice(), expected);
}

fn check_static(source: &str, expected: [u32; 48]) {
    assert_pixels(&page(source), &Fonts::new(), &expected);
}

fn check_dynamic(source: &str, phases: &[(&str, [u32; 48])]) {
    for strict in [false, true] {
        let mut page = page(source);
        let fonts = Fonts::new();
        for (source, expected) in phases {
            let result = if strict {
                page.runtime.execute_strict(source, &mut page.document)
            } else {
                page.runtime.execute(source, &mut page.document)
            };
            assert_eq!(result.unwrap(), Value::Bool(true), "strict={strict}");
            assert_pixels(&page, &fonts, expected);
        }
    }
}
'''
public=head
for r in c['static']:
 public+='\n#[test]\nfn '+r['id']+'() {\n    check_static(\n        '+raw(r['html'])+',\n        '+pixels(r['expected_pixels_rgb'])+',\n    );\n}\n'
for r in c['dynamic']:
 public+='\n#[test]\nfn '+r['id']+'() {\n    check_dynamic(\n        '+raw(r['html'])+',\n        &[\n'
 for p in r['phases']:public+='            ('+raw(p['source'])+', '+pixels(p['expected_pixels_rgb'])+'),\n'
 public+='        ],\n    );\n}\n'
# The old module supplies the thread-local fake bridge and keys()/requests().
resource_before=subprocess.check_output(['git','-C',str(W),'show',BASE+':src/page/background_resource_tests.rs']).decode()
assert resource_before==(W/'src/page/background_resource_tests.rs').read_text()
root_phase=c['resources'][0]['phases'];assert c['resources'][1]['phases']==root_phase
private='''
// Initial suppression tests selection before any image can enter the cache.
// Later hiding retains that cache; this is not an eviction/cancellation test.
fn canvas_display_resource_reveal_sequence(source: &str) {
    with_page(source, |page| {
        let fonts = Fonts::new();
        assert_eq!(requests(), ["https://page.test/start"]);
        let hidden = page.prepare_layout(8.0, 6.0, &fonts);
        assert_eq!(requests(), ["https://page.test/start"]);
        assert!(keys(&hidden).is_empty());
        assert!(page.images.is_empty());
        let resources = page.resources.as_ref().unwrap();
        assert!(resources.image_cache.is_empty());
        assert!(resources.background_keys.is_empty());
        assert_eq!(resources.decoded_image_bytes, 0);

        page.runtime.execute(REVEAL, &mut page.document).unwrap();
        let shown = page.prepare_layout(8.0, 6.0, &fonts);
        let selected = keys(&shown);
        assert_eq!(selected.len(), 1);
        let key = selected[0].to_owned();
        assert_eq!(requests(), ["https://page.test/start", "https://page.test/final/tile.png"]);
        assert_eq!(page.images.len(), 1);
        let resources = page.resources.as_ref().unwrap();
        assert_eq!(resources.image_cache.len(), 1);
        assert_eq!(resources.background_keys.len(), 1);
        assert_eq!(resources.decoded_image_bytes, 8);

        page.runtime.execute(HIDE, &mut page.document).unwrap();
        assert!(keys(&page.prepare_layout(8.0, 6.0, &fonts)).is_empty());
        assert_eq!(requests(), ["https://page.test/start", "https://page.test/final/tile.png"]);
        assert_eq!(page.images.len(), 1);
        let resources = page.resources.as_ref().unwrap();
        assert_eq!(resources.image_cache.len(), 1);
        assert_eq!(resources.background_keys.len(), 1);
        assert_eq!(resources.decoded_image_bytes, 8);

        page.runtime.execute(REAPPEAR, &mut page.document).unwrap();
        let again = page.prepare_layout(8.0, 6.0, &fonts);
        assert_eq!(keys(&again), [key.as_str()]);
        assert_eq!(requests(), ["https://page.test/start", "https://page.test/final/tile.png"]);
        assert_eq!(page.images.len(), 1);
        let resources = page.resources.as_ref().unwrap();
        assert_eq!(resources.image_cache.len(), 1);
        assert_eq!(resources.background_keys.len(), 1);
        assert_eq!(resources.decoded_image_bytes, 8);
    });
}
'''
for marker,index in [('REVEAL',1),('HIDE',2),('REAPPEAR',3)]:private=private.replace(marker,raw(root_phase[index]['source']))
for r in c['resources']:
 private+='\n#[test]\nfn '+r['id']+'() {\n    canvas_display_resource_reveal_sequence(\n        '+raw(r['html'])+',\n    );\n}\n'
pos=c['displayed_resource_positive'];private+='\n#[test]\nfn '+pos['id']+'() {\n    for source in [\n'+''.join('        '+raw(s)+',\n' for s in pos['html_sources'])+'''    ] {
        with_page(source, |page| {
            let fonts = Fonts::new();
            assert_eq!(requests(), ["https://page.test/start"]);
            let result = page.prepare_layout(8.0, 6.0, &fonts);
            let selected = keys(&result);
            assert_eq!(selected.len(), 1);
            let key = selected[0].to_owned();
            assert_eq!(requests(), ["https://page.test/start", "https://page.test/final/tile.png"]);
            assert_eq!(keys(&page.layout(8.0, 6.0, &fonts)), [key.as_str()]);
            assert_eq!(keys(&page.prepare_layout(8.0, 6.0, &fonts)), [key.as_str()]);
            assert_eq!(requests(), ["https://page.test/start", "https://page.test/final/tile.png"]);
        });
    }
}
'''
paths={'tests/canvas_display.rs':('',public),'src/page/background_resource_tests.rs':(resource_before,resource_before+private)}
files=[]
for p,(before,after) in paths.items():
 if before:write('before/'+p,before)
 write('raw/'+p,after)
 fwd=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+p if before else '/dev/null',tofile='b/'+p))
 inv=''.join(difflib.unified_diff(after.splitlines(True),before.splitlines(True),fromfile='a/'+p,tofile='b/'+p if before else '/dev/null'))
 write('diffs/forward/'+p+'.patch',fwd);write('diffs/inverse/'+p+'.patch',inv)
 files.append({'relative_path':p,'before':bind(H/'before'/p) if before else None,'raw':bind(H/'raw'/p),'forward':bind(H/'diffs/forward'/(p+'.patch')),'inverse':bind(H/'diffs/inverse'/(p+'.patch'))})
write('resource-append.rs',private)
# Inert inverse/extraction check. Compare every raw Rust HTML/JS token with its
# independently frozen JSON field; expected arrays are rendered solely from JSON.
assert (H/'raw/src/page/background_resource_tests.rs').read_text().removesuffix(private)==resource_before
expected_raw=[r['html'] for r in c['static']]
for r in c['dynamic']:expected_raw+=[r['html']]+[x['source'] for x in r['phases']]
assert re.findall(r'r#"(.*?)"#',public,re.S)==expected_raw
expected_private=[root_phase[1]['source'],root_phase[2]['source'],root_phase[3]['source']]+[r['html'] for r in c['resources']]+pos['html_sources']
assert re.findall(r'r#"(.*?)"#',private,re.S)==expected_private
for r in c['static']:assert len(r['expected_pixels_rgb'])==48
for r in c['dynamic']:
 assert len(r['phases'])==3
 for p in r['phases']:assert len(p['expected_pixels_rgb'])==48
new_names=re.findall(r'#\[test\]\s*fn (\w+)\(',public+private)
assert len(new_names)==14 and len(set(new_names))==14 and all(x.startswith('canvas_display_') for x in new_names)
oldnames=re.findall(r'#\[test\]\s*fn (\w+)\(',resource_before)
assert re.findall(r'#\[test\]\s*fn (\w+)\(',resource_before+private)==oldnames+[x['id'] for x in c['resources']]+[pos['id']]
put('registration.json',{'integration':'tests/canvas_display.rs auto-discovered by Cargo','private':'Three tests append to existing src/page/background_resource_tests.rs; existing registration unchanged','live_changes':False})
put('conversion-checks.json',{'status':'clear source-only conversion','literal_hold':ls,'all_27_raw_html_js_occurrences_exact':len(expected_raw)+len(expected_private),'public_html_occurrences':11,'public_js_occurrences':9,'private_html_occurrences':4,'private_js_occurrences':3,'pixel_oracles':{'static':8,'dynamic_per_mode':9,'array_length':48,'representation':'Literal RGB words; uniform array repetition or explicit 48 values, with white surface cleared independently.'},'old_resource_module_prefix_exact':True,'old_resource_test_names':oldnames,'new_test_names':new_names,'new_groups':14,'producer_inspection':False,'project_execution':False,'live_edits':False,'constraints':['No new registration, runtime, fee, cache, loader or limit implementation.','Fake bridge checks resource-selection/cache behavior only.','Pixel assertions cover the complete 8x6 RGB framebuffer after explicit white clear.','Dynamic sources execute in both existing ordinary and strict Runtime entrypoints; each phase relayouts the same DOM.']})
put('source-ready.json',{'schema':1,'status':'source-ready independent canvas display tests; unexecuted','base':BASE,'literal_hold':ls,'files':files,'resource_append':bind(H/'resource-append.rs'),'registration':bind(H/'registration.json'),'checks':bind(H/'conversion-checks.json'),'converter':bind(H/'convert.py'),'new_groups':14,'existing_groups_unchanged':len(oldnames),'project_execution':False,'live_edits':False,'producer_inspection':False})
print(json.dumps({'hold':bind(H/'source-ready.json'),'groups':new_names,'old_resource_groups':len(oldnames)}))
