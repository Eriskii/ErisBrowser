"""Held one-seam canvas source correction; no project import or execution."""
from pathlib import Path
import difflib
import hashlib
import json

OUT = Path('/tmp/eris-canvas-display-plan-1/implementation-1')
SOURCE = Path('/tmp/eris-visibility-plan-1/worktree/src/layout.rs')
REL = 'src/layout.rs'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def save(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2) + '\n')
    return bind(path)

before = SOURCE.read_bytes()
assert len(before) == 355464
assert hashlib.sha256(before).hexdigest() == 'a6b8432045b6d562213bb513603093cbf439d8c832f8e63e3375b76857f8f061'
anchor = b'''pub(crate) fn canvas_background_owner(
    styles: &[ComputedStyle],
    html: Option<NodeId>,
    body: Option<NodeId>,
) -> Option<NodeId> {
'''
guard = b'''    if html
        .and_then(|id| styles.get(id))
        .is_some_and(|style| style.display == Display::None)
    {
        return None;
    }
'''
assert before.count(anchor) == 1 and guard not in before
after = before.replace(anchor, anchor + guard, 1)
assert after.replace(anchor + guard, anchor, 1) == before
paths = {}
for kind, data in [('before', before), ('raw', after)]:
    path = OUT / kind / REL
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    paths[kind] = bind(path)
for kind, left, right in [('diff', before, after), ('inverse', after, before)]:
    path = OUT / kind / (REL + '.diff')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(difflib.unified_diff(left.decode().splitlines(True), right.decode().splitlines(True), fromfile='a/' + REL, tofile='b/' + REL)))
    paths[kind] = bind(path)
chunks = save('chunks.json', [{'path': REL, 'before': anchor.decode(), 'after': (anchor + guard).decode(), 'occurrences': 1}])
interaction = save('interaction-review.json', {
    'status': 'author source review; not independent execution evidence',
    'public_interface': 'Existing canvas_background_owner(&[ComputedStyle], Option<NodeId>, Option<NodeId>) -> Option<NodeId> unchanged.',
    'operation': 'One optional html id unwrap, one checked borrowed style lookup and one scalar display comparison before existing selection. No new allocation, iteration, tariff, cap, field or wire byte.',
    'ordering': 'Return before root selection and its body fallback. Filtering only the root candidate would wrongly allow a body background through a display:none root.',
    'branches': [
        'Some valid html with display None returns None regardless of color, image list, body display or body background.',
        'Absent html id or missing html style row skips the guard; the complete old selection expression remains byte-exact.',
        'Displayed root retains precedence, single-none distinction and existing body display None refusal.',
        'Visibility hidden is not examined; the selected visibility canvas-versus-box behavior remains unchanged.'
    ],
    'consumers': [
        {'path': 'src/layout.rs', 'function': 'layout_with_backgrounds', 'effect': 'No propagated canvas slots are reserved for a non-displayed root. Existing subtree layout pruning, background geometry, paint order and hit behavior remain.'},
        {'path': 'src/page/background_resources.rs', 'function': 'Page::background_nodes', 'effect': 'The shared selector no longer re-adds root/body URL owners after ordinary traversal has excluded the display:none root subtree. Existing positive resource selection and later reveal remain unchanged.'}
    ],
    'test_proposals_for_independent_author': [
        'Root display:none with own opaque background and differently colored body: owner None, full white-cleared pixel reference; no body fallback.',
        'Transparent root display:none with colored body: owner None and blank reference.',
        'Missing html id and missing style row preserve existing body fallback.',
        'Displayed colored root plus display:none body still paints root; root/body visibility:hidden retains canvas propagation.',
        'Preserve existing none versus none,none owner test and body double-blend/precedence tests.',
        'Fake resource bridge: root-none root URL and root-none/body URL are not re-added; subsequent reveal allows the selected URL preparation.',
        'Dynamic block-to-none-to-block root toggle restores original root or body canvas background without changing selection priority.'
    ],
    'deferred': ['display:contents', 'containment', 'malformed DOM first-body-child redesign', 'non-HTML root support', 'resource cache eviction/cancellation'],
    'project_execution': False, 'tests_authored_here': False
})
seal = save('source-ready.json', {
    'schema': 1, 'status': 'source-ready held one-function implementation; unexecuted',
    'published_visibility_commit': None,
    'base_qualification': 'Root is publishing the visibility checkpoint. Exact frozen source bytes are authenticated here; a later additive receipt will bind the published commit without rewriting this hold.',
    'origin': bind(SOURCE),
    'assessment': bind(Path('/tmp/eris-canvas-display-assessment-1.json')),
    'paths': [{'path': REL, **paths}],
    'chunks': chunks, 'interaction_review': interaction,
    'changed_functions': ['canvas_background_owner'], 'changed_paths': 1,
    'new_public_interfaces': [], 'production_insertion_lines': 6,
    'exact_inverse': True, 'all_other_source_bytes_exact': True,
    'author_script': bind(OUT / 'author.py'),
    'project_execution': False, 'project_imports': False, 'live_edits': False,
})
print(json.dumps(seal))
