Visibility measurement proposal

This hold contains three script-free rectangle fixtures, a pre-execution full-RGBA oracle, source/binary pins, and a root-only command/acceptance proposal. No browser or project module has been executed/imported by the author.

Use the pinned published parent and a future release candidate built with the same Rust1.88/empty-feature configuration. Bind its actual source/build sidecar first. Run18 supervised browser processes serially as proposal.json specifies. Every fresh output must satisfy the fixed pixel contract before timing interpretation. Existing benchmark tools establish which phases are measured; their fixed case lists need not be run or changed.

The all-visible dense fixture measures the additional path without intentional paint reduction. The hidden-parent/visible-child fixture checks the selected behavioral difference against integer rectangles and an explicit transparent-parent reference. Worker timings additionally include ERWB metadata transfer. Retain all raw logs and failures. These are local descriptive observations with no Chromium, GPU, overall-speed or security claim.

Storage is capacity-weighted. Observed owner growth is8 bytes; the1.6MB figure is initialized payload for one200000-entry roster, not peak RSS. A separate packing follow-up would change representation invariants and is not selected here.
