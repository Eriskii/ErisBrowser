from pathlib import Path
import difflib, hashlib, json, re, subprocess
N=Path('/tmp/eris-visibility-plan-1'); R=N/'all-fixtures-review-1'; W=N/'worktree'
BASE='18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(path): return subprocess.check_output(['git','-C',str(W),'show',BASE+':'+path])
def verify_refs(x):
 if isinstance(x,dict):
  if all(k in x for k in ['path','bytes','sha256']):
   p=Path(x['path']); assert bind(p)=={k:x[k] for k in ['path','bytes','sha256']},p
  for v in x.values():verify_refs(v)
 elif isinstance(x,list):
  for v in x:verify_refs(v)
def diff(a,b,path):return ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
def names(t):return re.findall(r'#\[test\]\s*fn (\w+)\(',t)
def bodies(t):
 m=list(re.finditer(r'#\[test\]\s*fn (\w+)\(',t));return {x.group(1):t[x.start():(m[i+1].start() if i+1<len(m) else len(t))] for i,x in enumerate(m)}
h1=json.loads((N/'all-fixtures-1/source-ready.json').read_text());h2=json.loads((N/'all-fixtures-2/source-ready.json').read_text());verify_refs(h1);verify_refs(h2)
assert sha((N/'all-fixtures-1/source-ready.json').read_bytes())=='576267825b300a23c488e6a1233a316484d283699fd133597b42f918cd30a92b'
assert sha((N/'all-fixtures-2/source-ready.json').read_bytes())=='5d28f27eace895982699aecb2f10c3a35627e9f21e116c09491003f21ba6f42b'
chunks={x['path']:x['chunks'] for x in json.loads((N/'all-fixtures-1/chunks.json').read_text())}
changed=[]; joins=[]
for row in h1['paths']:
 path=row['path'];a=Path(row['before']['path']).read_text();b=Path(row['raw']['path']).read_text();assert a.encode()==git(path)
 c=a
 for q in chunks[path]:assert c.count(q['before'])==q['occurrences'];c=c.replace(q['before'],q['after'])
 assert c==b
 for q in reversed(chunks[path]):assert c.count(q['after'])==q['occurrences'];c=c.replace(q['after'],q['before'])
 assert c==a
 assert Path(row['diff']['path']).read_text()==diff(a,b,path)
 assert Path(row['inverse']['path']).read_text()==diff(b,a,path)
 assert names(a)==names(b)==row['all_test_names_preserved']
 ba=bodies(a);bb=bodies(b);changed.extend(k for k in ba if ba[k]!=bb[k])
 joins.append({'path':path,'published_before_exact':True,'forward_inverse_exact':True,'all_test_names':names(a)})
row=h2['paths'][0];a=Path(row['before']['path']).read_text();b=Path(row['raw']['path']).read_text();path=row['path']
assert a==(N/'all-fixtures-1/raw'/path).read_text();assert a.count('"x".repeat(1)')==1
assert a.replace('"x".repeat(1)','"x".to_string()')==b
assert Path(row['diff']['path']).read_text()==diff(a,b,path)
assert Path(row['inverse']['path']).read_text()==diff(b,a,path)
assert names(a)==names(b)
d=json.loads((N/'all-fixtures-1/derivation.json').read_text());verify_refs(d)
css=(N/'candidate-source-1/src/css.rs').read_text();oldcss=git('src/css.rs').decode()
def roster(s):return re.findall(r'"([a-z-]+)"',re.search(r'const SUPPORTED_PROPERTIES:.*?=\s*&?\[(.*?)\];',s,re.S).group(1))
old=roster(oldcss);new=roster(css)
assert old==d['ordered_old_names'] and new==d['ordered_selected_names']
assert new==old[:1]+['visibility']+old[1:]
assert (len(old),sum(len(x.encode()) for x in old),len(new),sum(len(x.encode()) for x in new))==(86,1049,87,1059)
items=['--a']+new
assert len(items)==88 and items[0]=='--a' and items[1]=='display' and items[2]=='visibility' and items[21]=='border-spacing' and items[87]=='vertical-align'
cssom=(N/'candidate-source-1/src/cssom.rs').read_bytes();assert cssom==git('src/cssom.rs')
for s in ['MAX_INLINE_BYTES: usize = 64 * 1024','MAX_DECLARATIONS: usize = 256','MAX_VALUE_BYTES: usize = 4096','if self.important { 15 } else { 4 }','logical_bytes > MAX_INLINE_BYTES','records.len() > MAX_DECLARATIONS']:
 assert s in cssom.decode(),s
pending='var(--x,'+'0'*728+')';assert len(pending)==737
all_bytes=sum(len(x.encode())+len(pending)+4 for x in new);exact=all_bytes+len('--pad')+len('x')+4
assert all_bytes==65526 and exact==65536 and exact+1==65537
assert 169+len(new)==256 and 170+len(new)==257
assert sum(len(x)+740+4 for x in new)==65787
assert len('all:'+pending+';--pad:x')<65536 and len(pending)<4096
small=sum(len(x)+len('var(--a)')+4 for x in new)+len('--a')+len('initial')+4
release=1+88+small;summary=1+264*88;clone=summary+small+release;names_work=sum(len(x)+1 for x in items)
assert (small,release,summary,clone,names_work)==(2117,2206,23233,27556,1150)
assert sorted(changed)==sorted(d['selected_changed_groups']) and len(changed)==4
receipt=N/'validation/candidate-full-msrv-1.json';r=json.loads(receipt.read_text());log=N/'validation'/r['log'];lb=log.read_bytes();assert sha(lb)==r['sha256'] and r['exit']==101
text=lb.decode();assert 'test result: FAILED. 3142 passed; 12 failed; 0 ignored; 0 measured; 0 filtered out;' in text
final=text.split('\nfailures:\n')[-1].split('\ntest result:')[0]
failed=[x.strip() for x in final.splitlines() if x.strip()];assert len(failed)==12 and len(set(failed))==12
fixture=[x for x in failed if x.startswith('css::') or x.startswith('cssom::')];environment=[x for x in failed if x not in fixture]
assert sorted(x.rsplit('::',1)[-1] for x in fixture)==sorted(changed) and len(environment)==8
assert 'Operation not permitted' in text and 'PermissionDenied' in text
source_pins=[]
for path,needle in [('src/page/css_url_tests.rs','TcpListener::bind("127.0.0.1:0").unwrap()'),('src/page/resource_loading_tests.rs','TcpListener::bind("127.0.0.1:0").unwrap()'),('src/worker/sandbox.rs','TCP preflight')]:
 content=git(path);assert needle in content.decode();source_pins.append({'path':path,'base':BASE,'bytes':len(content),'sha256':sha(content),'qualification':'Published socket-preflight source; no execution.'})
result={'status':'clear','scope':'Independent stdlib/read-only Git source review; no project imports or execution.','holds':[bind(N/'all-fixtures-1/source-ready.json'),bind(N/'all-fixtures-2/source-ready.json')],'published_base':BASE,'path_joins':joins,'second_overlay_exact':True,'all_old_test_groups_preserved':sum(len(x['all_test_names']) for x in joins),'changed_groups':changed,'new_groups':0,'renames':0,'production_changes':0,'roster':{'old_names':86,'old_name_bytes':1049,'selected_names':87,'selected_name_bytes':1059,'exact_insert_after_display':'visibility','custom_plus_all':88,'order_items':{'0':'--a','1':'display','2':'visibility','21':'border-spacing','87':'vertical-align'},'first_absent':88},'record_limit':{'unchanged':256,'exact_custom':169,'refused_custom':170},'byte_limit':{'unchanged':65536,'pending_zeros':728,'pending_bytes':737,'all_reference_bytes':65526,'custom_pad_bytes':10,'total':65536,'one_over':65537,'original_new_roster_payload_alone':65787},'source_formula_bindings':[bind(N/'candidate-source-1/src/css.rs'),bind(N/'candidate-source-1/src/cssom.rs')],'failure_evidence':{'receipt':bind(receipt),'log':bind(log),'passed':3142,'failed':12,'fixture_failures':fixture,'outer_environment_failures':environment,'environment_source_pins':source_pins},'preservation':['Full before files equal published Git; all forward/inverse diffs exact.','Every nonselected function body is unchanged. Four selected assertions/fixture inputs reflect one added longhand.','All non-all shorthand counts, fixed work cuts, typed capacity accounting and Arc sharing/getter checks remain exact.','256-record and 65536-byte limits unchanged; setter and parse one-over refusals and atomic state equality assertions remain.','Overlay changes only construction of the identical one-byte String; no numeric oracle changes.'],'findings':[],'limits':['This review does not execute tests or claim the migrated tests pass.','The eight socket-related failures occurred under outer EPERM restrictions and are separate from the four fixture failures.','Whole-suite validation and final documentation remain root-owned.']}
(R/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'clear','changed_groups':len(changed),'preserved_groups':result['all_old_test_groups_preserved'],'checks':bind(R/'checks.json')}))
