from pathlib import Path
import json,hashlib,subprocess,difflib,re
N=Path('/tmp/eris-visibility-plan-1'); W=N/'worktree'; O=N/'browser-review-1'; BASE='18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,x): (O/name).write_text(json.dumps(x,indent=2)+'\n')
def apply(source,edits,path):
 for edit in edits:
  if edit['path']!=path:continue
  assert source.count(edit['before'])==1,(path,edit['before'])
  source=source.replace(edit['before'],edit['after'],1)
 return source
checks=[]; objects={}
for name in ['browser-producer-1','historical-fixtures-1']:
 H=N/name;m=json.loads((H/'source-ready.json').read_text()); edits=json.loads((H/'edits.json').read_text()); objects[name]=edits
 assert m['base']==BASE
 for rec in m['files']:
  actual=bind(H/rec['path']);assert actual['bytes']==rec['bytes'] and actual['sha256']==rec['sha256'],rec
 for key in ['design','source_parent','report']:
  rec=m[key];actual=bind(Path(rec['path']));assert actual['bytes']==rec['bytes'] and actual['sha256']==rec['sha256']
 rows=[]
 for rel in m['payload_paths']:
  pre=H/'before'/rel;post=H/'raw'/rel;raw=post.read_text()
  if pre.exists():
   before=pre.read_text(); git=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+rel]);assert git==pre.read_bytes()
   rebuilt=apply(before,edits,rel);assert rebuilt==raw,rel
   inverse=raw
   for edit in reversed([x for x in edits if x['path']==rel]):
    assert inverse.count(edit['after'])==1;inverse=inverse.replace(edit['after'],edit['before'],1)
   assert inverse==before
  else: before=''; assert name=='browser-producer-1' and rel.endswith('visibility_tests.rs')
  forward=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+rel if pre.exists() else '/dev/null',tofile='b/'+rel))
  inverse=''.join(difflib.unified_diff(raw.splitlines(True),before.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel if pre.exists() else '/dev/null'))
  assert forward==(H/'diffs/forward'/(rel+'.patch')).read_text(),rel
  assert inverse==(H/'diffs/inverse'/(rel+'.patch')).read_text(),rel
  tests=lambda s:re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',s)
  if name=='historical-fixtures-1':assert tests(before)==tests(raw),rel
  rows.append({'path':rel,'before_git_exact':pre.exists(),'raw':bind(post),'forward_inverse_exact':True,'new_test_names':[x for x in tests(raw) if x not in tests(before)]})
 checks.append({'hold':name,'seal':bind(H/'source-ready.json'),'members_verified':len(m['files']),'edit_count':len(edits),'paths':rows})
# Shared codec changes compose exactly in either order.
rel='src/worker/codec.rs';before=(N/'browser-producer-1/before'/rel).read_text()
a=apply(apply(before,objects['browser-producer-1'],rel),objects['historical-fixtures-1'],rel)
b=apply(apply(before,objects['historical-fixtures-1'],rel),objects['browser-producer-1'],rel)
assert a==b
# Count the exact replacement inventory, distinguishing the extra old-version refusal.
magic={}
for e in objects['historical-fixtures-1']:
 n=e['before'].count('ERWA')
 if n and e['after'].count('ERWB')==n:
  magic[e['path']]=magic.get(e['path'],0)+n
assert sum(magic.values())==15
clar=json.loads((N/'historical-fixtures-1/clarification.json').read_text())
assert magic==clar['magic_replacements_by_file']
assert clar['source_ready_sha256']==bind(N/'historical-fixtures-1/source-ready.json')['sha256']
new=[x for hold in checks for row in hold['paths'] for x in row['new_test_names']]
assert len(new)==7 and len(set(new))==7
put('checks.json',{'status':'all source/hash/inverse checks passed','checks':checks,'shared_codec_composition_commutes':True,'historical_test_rosters_exact':True,'magic_replacements':magic,'magic_total':15,'seven_new_groups':new,'no_project_imports_execution_or_live_edits':True})
put('review.json',{'schema':1,'status':'clear','base':BASE,'scope':'Independent source review of held browser/codec production, seven producer-authored tests and seven historical fixture paths. No candidate outcomes or unrelated controls read.','bindings':[bind(N/'design-1/source-ready.json'),bind(N/'design-1/design.json'),bind(N/'design-1/interfaces.txt'),bind(N/'browser-producer-1/source-ready.json'),bind(N/'historical-fixtures-1/source-ready.json'),bind(N/'historical-fixtures-1/clarification.json'),bind(O/'checks.json')],'findings':[],'independent_checks':[
 {'area':'decoder order','result':'After validated Document construction, bounded count must equal exact DOM count. The complete raw payload is borrowed and all bytes are checked for 0/1 before try_reserve_exact and typed pushes. Truncation/oversized counts/unknown bytes refuse through existing errors. Root validity from Document::from_snapshot precedes hit node count minus one.'},
 {'area':'encoder and wire','result':'ERWB replaces four-byte magic for every message kind. Exact table cardinality and MAX_NODES checked before snapshot fields. Count and one byte per node appear after DOM and before images. Existing max-frame/string/image/command limits and helper bodies remain exact. Hidden-target hits refuse at both encode and decode; decoder validates node range first.'},
 {'area':'focus and event preservation','result':'Own visibility AND is applied after the unchanged positive hit ancestor walk and default-summary rule. No new viewport clip and no early stop at a hidden ancestor. Missing metadata returns all false. Existing click requests, DOM bubbling, tab ordering, disabled/disclosure rules and input reconciliation bodies are byte-exact; reconciliation observes the newly computed eligibility before snapshot acceptance.'},
 {'area':'seven producer tests','result':'Three browser groups cover hidden ancestor versus visible text click, offscreen forward/backward focus, accepted hiding/stale acknowledgment, absent geometry/default summary and short metadata. Four codec groups cover both bytes, exact roundtrip, every truncation of complete reply, old magic, short/long/oversized count, 2/255 bytes, sender mismatches and hidden hits before geometry.'},
 {'area':'historical fixtures','result':'All seven before files join published Git; exact edit/inverse checks preserve every original test name and all code outside listed replacements. Five manual LayoutResult fixtures get all-visible exact-count tables; two manual DOM mutation fixtures resize/reset the table. Fifteen magic replacements leave payload bytes unchanged; old ERWA is added to the stale-version refusal list alongside ERW9/ERW8. Raster document hoist preserves the same default value.'},
 {'area':'composition','result':'Production and historical codec edits apply in either order to identical bytes. No overlapping source weakening or hidden registration change.'}],
 'qualifications':['Source review only; no Rust/project imports, compilation or runtime execution. Seven tests are producer-authored; this receipt does not claim they were frozen independently of that implementation.','Metadata validation is not proof that an untrusted worker computed author CSS correctly.','Existing encode behavior for a hit with an out-of-range node ID is outside this visibility change; the decoder retains its prior range refusal.','The retained original historical checks prose said twelve magic replacements. Additive clarification corrects this to fifteen; source payloads and diffs were already exact.']})
print(json.dumps(bind(O/'review.json')))
