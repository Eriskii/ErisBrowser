from pathlib import Path
import json,hashlib,difflib,subprocess,re
N=Path('/tmp/eris-visibility-plan-1');W=N/'worktree';O=N/'documentation-1';BASE='18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
def write(name,s):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,x):write(name,json.dumps(x,indent=2)+'\n')
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/css-visibility.md']
before={p:subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]).decode() for p in paths[:-1]}
for p,s in before.items(): assert (W/p).read_text()==s;write('before/'+p,s)
notes={
'README.md':'''[CSS visibility](docs/css-visibility.md) now supports `visible` and `hidden`
through the cascade, inline CSSOM and feature queries. Hidden boxes retain their
layout space; visible descendants can still paint and receive hits. Native
focus checks each candidate's own visibility. Canvas backgrounds remain painted,
and table row layers follow the explicitly qualified CSS Tables draft policy.
`collapse` remains unsupported. This adds no complete CSS, security or
Chromium-relative performance claim.

''',
'docs/COMPATIBILITY.md':'''[CSS visibility](css-visibility.md) supports the `visible`/`hidden` subset,
including inheritance, existing CSS-wide keywords, variables, priority and
inline CSSOM. Hidden boxes preserve geometry and allow visible descendants;
their own paint, hit targets and native focus eligibility are suppressed.
`collapse` remains unsupported. Row-background visibility follows the selected
CSS Tables 3 draft interpretation, whose interoperability remains unsettled.
The chapter separates current validation from older checkpoint totals below.

''',
'docs/ROADMAP.md':'''[CSS visibility](css-visibility.md) adds inherited `visible`/`hidden` values
while preserving layout, scroll extent and visible descendants. Paint, hit and
native focus eligibility now use each node's own computed value. The bounded
worker snapshot carries that value in ERWB metadata. `collapse`, broader table
behavior, animations and accessibility API expansion remain future work. The
selected table row-layer rule retains its draft/interoperability qualification;
this checkpoint makes no Chromium performance comparison.

'''}
after=dict(before)
# README keeps its original opening/status paragraphs together; other status notes are additive.
anchor='[JavaScript classes](docs/classes.md)'
assert after['README.md'].count(anchor)==1
after['README.md']=after['README.md'].replace(anchor,notes['README.md']+anchor,1)
for p in ['docs/COMPATIBILITY.md','docs/ROADMAP.md']:
 heading,body=after[p].split('\n\n',1);after[p]=heading+'\n\n'+notes[p]+body
security=after['docs/SECURITY.md']
old='ERWA preserves reciprocal template/fragment ownership and includes those edges in cycle/depth checks.'
new='ERWB preserves reciprocal template/fragment ownership and includes those edges in cycle/depth checks.'
assert security.count(old)==1;security=security.replace(old,new)
old='Connected-tree selection excludes hidden subtrees and template content, with the existing canvas-owner exception.'
new='Connected-tree selection retains its existing subtree and template-content exclusions, with the existing canvas-owner exception; `visibility:hidden` adds no resource-loading exclusion.'
assert security.count(old)==1;security=security.replace(old,new)
security_note='''[Visibility metadata](css-visibility.md) adds an exact DOM-count table to ERWB:
a four-byte count and one checked 0/1 byte per node. The decoder checks the
complete raw table before reserving typed storage, and both directions reject
hits aimed at hidden nodes. The existing 100,000-node cap bounds this additional
wire payload to 100,004 bytes; frame and other resource limits are unchanged.
A missing or mismatched table makes every native focus candidate ineligible.
Visible descendants retain ancestor reachability without granting a hidden
ancestor focus. This metadata is a validated worker claim, not proof that the
worker computed author CSS correctly. Hiding content does not skip its existing
resource preparation, layout, glyph or command admission costs and grants no
new sandbox or origin authority.

'''
assert security.count('## Implemented controls\n')==1
security=security.replace('## Implemented controls\n',security_note+'## Implemented controls\n',1)
after['docs/SECURITY.md']=security
validation='''## CSS visible/hidden visibility

The [visibility subset](css-visibility.md) keeps hidden boxes in layout while
filtering their own paint/hits and native focus eligibility. Visible descendants
retain their clip, fixed-coordinate, opacity and ancestor context. Canvas
backgrounds remain painted; the selected cell-rendered table row-layer policy
is explicitly tied to a working draft with known interoperability differences.
`collapse` is deferred, and existing layout, resource and IPC limits remain.

The parent compiled all sixteen new integration groups and recorded **zero
passes and sixteen failures**: fifteen pixel/hit/reference groups and the CSSOM
group. The latter reached the existing Unsupported result for the missing
property. Direct computed-style tests depend on the newly selected field and
are not described as having run against that parent.

[PENDING_FINAL_VALIDATION: candidate focused/full rosters, lint/format checks,
direct/confined witnesses, selected replay results and final source identity.]
[PENDING_TYPE_MEASUREMENTS: final actual type sizes and node-table capacities.]
[PENDING_FAILURE_LEDGER: retain every candidate failure/correction, if any,
without changing independently frozen semantic or pixel expectations.]

The published parent `18d3648c` has eleven successful remote CI jobs. That is a
parent result, not a result for this visibility checkpoint. No new GPU,
full-browser compatibility, security or Chromium performance result is claimed.

See the [evidence manifest](evidence/css-visibility/manifest.json) and
[source/check archive](evidence/css-visibility/sources-and-checks.tar.gz).
The complete prior validation body below remains byte-exact.

'''
heading,body=before['docs/VALIDATION.md'].split('\n\n',1)
after['docs/VALIDATION.md']=heading+'\n\n'+validation+body
chapter='''# CSS visibility: visible and hidden

`visibility: hidden` now hides a box's own painting and hit targets while
retaining its layout space. A descendant can set `visibility: visible` and
remain painted and interactive. Block/inline flow, flex/grid tracks, table
geometry and document scroll extent continue to include hidden content. This is
the inherited `visible`/`hidden` subset described by [CSS Display](https://www.w3.org/TR/2026/CRD-css-display-3-20260605/#visibility).
`collapse` remains unsupported; this checkpoint does not implement its table or
flex behavior.

The initial value is `visible`. The existing cascade supports `inherit`,
`initial`, `unset`, `revert` and `revert-layer`, including importance and layer
ordering. Values are single identifiers, ASCII-insensitive and escape-aware;
comments cannot join separate identifiers into a keyword. Quoted values,
additional tokens and `collapse` do not replace an earlier valid declaration.
Ordinary variable substitution remains supported. If the winning variable value
is invalid at computed-value time, visibility inherits as `unset` rather than
reviving the earlier declaration, following [CSS Variables](https://drafts.csswg.org/css-variables-1/).

Inline `style.visibility`, `setProperty`, removal and serialization use the
existing bounded CSSOM machinery. Invalid setter values remain no-ops. Feature
queries accept supported visibility identifiers, including escaped spellings.
Condition syntax can decode an escaped visibility property name; the
two-argument `CSS.supports(property, value)` overload retains its literal
property-name rule and rejects escapes in that argument. The existing
conservative feature-query treatment of unresolved `var()` remains unchanged.

Painting is filtered after layout and scope construction. Hidden ancestors do
not cut off visible descendants or erase clip, fixed-coordinate and opacity
scopes. Native focus similarly checks each candidate's own value after deriving
reachability from hit geometry; a visible child does not make its hidden parent
focusable. Offscreen visible controls remain eligible. Accepted hiding clears
native editing focus, and showing a node does not automatically focus it.
DOM event paths remain intact, so a visible child's event can still bubble
through a hidden ancestor; visibility does not make the subtree inert.

The canvas background remains painted when its selected html/body source is
hidden, while ordinary hidden borders and content are suppressed. This follows
the [canvas-versus-element background distinction](https://www.w3.org/TR/2024/CRD-css-backgrounds-3-20240311/#special-backgrounds).
Table background layers need a separate qualification. Existing row fragments
use their originating cell's visibility while retaining row geometry, rank and
opacity: a hidden row with a visible cell paints that row layer; a visible row
with a hidden cell does not. A visible descendant inside a hidden cell paints
its own content without reviving the cell's row layer. This is the selected
cell-rendered interpretation of [CSS Tables 3](https://www.w3.org/TR/2026/WD-css-tables-3-20261008/#drawing-cell-backgrounds),
a working draft explicitly marked not ready for implementation. Its recorded
browser disagreements and open visibility question remain relevant; these
controls are not a claim of settled cross-browser interoperability.

Each layout carries one typed visibility value for every DOM node. Construction
checks the existing 100,000-node bound and reserves the complete table before
copying values. Refusal returns no paint/hit records and no table; it cannot be
encoded as a successful worker snapshot for a nonempty DOM. Hidden content
still consumes the existing resource preparation and layout/glyph/command
allowances. No resource cap is raised.

The worker protocol advances to ERWB. After the DOM records, it carries an
exact count and one 0/1 byte per node: `4 + N` additional bytes, at most 100,004.
The decoder checks cardinality, available bytes and every discriminant before
allocating the typed vector. Hidden-node hits are refused in either direction;
older protocol magic is rejected. Missing metadata excludes all native focus
candidates. These checks validate transport shape, not the correctness of an
untrusted worker's CSS computation, and add no sandbox authority.

Parent Rust 1.88 measurements record `ComputedStyle` at 1,032 bytes,
`PaintOwner` at 16 and `LayoutResult` at 56. These are actual parent types;
field sizes alone do not establish the candidate's complete ABI or allocator
cost. [PENDING_TYPE_MEASUREMENTS: final actual sizes and observed capacities.]

The independent controls use literal CSS/JS expectations and reference pages
without visibility. Rectangular scenes also compare complete RGB canvases with
fixed rectangles; the text pair uses transparent text to retain layout. Their
parent integration run compiled and recorded zero passes and sixteen failures,
including the missing CSSOM property's Unsupported result. Before execution,
source review fixed explicit table widths and a converter's missing property
name additively; original holds and expected pixels remain retained.

[PENDING_FINAL_VALIDATION: measured candidate tests, strict checks, dynamic
witnesses, exact replay scope and final inventory.]
[PENDING_FAILURE_LEDGER: retained candidate attempts and any narrow corrections.]
The published parent's eleven successful CI jobs do not establish this
checkpoint's remote result. No new GPU execution, complete CSS/browser
compatibility, production-security or Chromium performance claim is made.

Sources and commands are retained in the [evidence manifest](evidence/css-visibility/manifest.json)
and [source/check archive](evidence/css-visibility/sources-and-checks.tar.gz).
'''
after['docs/css-visibility.md']=chapter
files=[]
for path in paths:
 pre=before.get(path,'');post=after[path];write('raw/'+path,post)
 write('diffs/forward/'+path+'.patch',''.join(difflib.unified_diff(pre.splitlines(True),post.splitlines(True),fromfile='a/'+path if pre else '/dev/null',tofile='b/'+path)))
 write('diffs/inverse/'+path+'.patch',''.join(difflib.unified_diff(post.splitlines(True),pre.splitlines(True),fromfile='a/'+path,tofile='b/'+path if pre else '/dev/null')))
 files.append({'relative_path':path,'before':bind(O/'before'/path) if pre else None,'raw':bind(O/'raw'/path),'forward':bind(O/'diffs/forward'/(path+'.patch')),'inverse':bind(O/'diffs/inverse'/(path+'.patch'))})
assert after['docs/VALIDATION.md']==heading+'\n\n'+validation+body
assert after['docs/VALIDATION.md'].endswith(body)
parent_log=(N/'validation/parent-visibility-integration-1.log').read_text();assert '0 passed; 16 failed; 0 ignored' in parent_log
for label in ['parent-style-storage-1','parent-layout-storage-1','parent-visibility-integration-1']:
 r=json.loads((N/'validation'/(label+'.json')).read_text());assert r['sha256']==bind(N/'validation'/r['log'])['sha256']
ci=Path('/tmp/eris-object-super-properties-plan-1/publication/ci-observation-2.json');obj=json.loads(ci.read_text());assert obj['headSha']==BASE and obj['conclusion']=='success' and len(obj['jobs'])==11 and all(x['conclusion']=='success' for x in obj['jobs'])
bindings=[N/'design-1/source-ready.json',N/'design-1/design.json',N/'css-producer-2/source-ready.json',N/'css-review-1/review.json',N/'layout-producer-1/source-ready.json',N/'layout-review-1/review.json',N/'browser-producer-1/source-ready.json',N/'browser-review-1/review.json',N/'controls-1/literal-ready-2.json',N/'controls-adapter-correction-1/source-ready.json',ci]
bindings += [N/'validation'/(label+ext) for label in ['parent-style-storage-1','parent-layout-storage-1','parent-visibility-integration-1'] for ext in ['.json','.log']]
put('draft-checks.json',{'status':'draft source and confirmed parent-evidence joins checked; not selected for publication','base':BASE,'files':files,'bindings':[bind(p) for p in bindings],'historical_validation_body_exact':True,'untouched_prior_chapters':['docs/classes.md','docs/class-super-properties.md','docs/object-super-properties.md'],'pending':['candidate actual ABI/capacity measurements','candidate focused and complete rosters','strict Clippy/format receipts','direct/confined dynamic witnesses','selected replay scope/outcomes','final source inventory and independent review','final-validation ledger and retained correction narratives','current checkpoint remote CI if any'],'planned_evidence_paths':['docs/evidence/css-visibility/manifest.json','docs/evidence/css-visibility/sources-and-checks.tar.gz'],'no_project_execution_or_live_edits':True})
put('draft-ready.json',{'schema':1,'status':'frozen documentation draft with explicit pending evidence placeholders; not final source-ready','base':BASE,'files':files,'checks':bind(O/'draft-checks.json'),'chapter_words':len(chapter.split()),'final_hold_must_bind_actual_receipts':True})
print(json.dumps(bind(O/'draft-ready.json')))
