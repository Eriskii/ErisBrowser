# CSS visibility: visible and hidden

`visibility: hidden` now hides a box's own painting and hit targets while
retaining its layout space. A descendant can set `visibility: visible` and
remain painted and interactive. Block/inline flow, flex/grid tracks, table
geometry and document scroll extent continue to include hidden content. This is
the inherited `visible`/`hidden` subset described by [CSS Display](https://www.w3.org/TR/2026/CRD-css-display-3-20260605/#visibility).
`collapse` remains unsupported; this checkpoint does not implement its table or
flex behavior.

The initial value is `visible`. The existing cascade supports `inherit`,
`initial`, `unset`, `revert` and `revert-layer`, including importance and layer
ordering. Values are single identifiers, ASCII-insensitive and escape-aware;
comments cannot join separate identifiers into a keyword. Quoted values,
additional tokens and `collapse` do not replace an earlier valid declaration.
Ordinary variable substitution remains supported. If the winning variable value
is invalid at computed-value time, visibility inherits as `unset` rather than
reviving the earlier declaration, following [CSS Variables](https://drafts.csswg.org/css-variables-1/).

Inline `style.visibility`, `setProperty`, removal and serialization use the
existing bounded CSSOM machinery. Invalid setter values remain no-ops. Feature
queries accept supported visibility identifiers, including escaped spellings.
Condition syntax can decode an escaped visibility property name; the
two-argument `CSS.supports(property, value)` overload retains its literal
property-name rule and rejects escapes in that argument. The existing
conservative feature-query treatment of unresolved `var()` remains unchanged.

Painting is filtered after layout and scope construction. Hidden ancestors do
not cut off visible descendants or erase clip, fixed-coordinate and opacity
scopes. Native focus similarly checks each candidate's own value after deriving
reachability from hit geometry; a visible child does not make its hidden parent
focusable. Offscreen visible controls remain eligible. Accepted hiding clears
native editing focus, and showing a node does not automatically focus it.
DOM event paths remain intact, so a visible child's event can still bubble
through a hidden ancestor; visibility does not make the subtree inert.

The canvas background remains painted when its selected html/body source is
hidden, while ordinary hidden borders and content are suppressed. This follows
the [canvas-versus-element background distinction](https://www.w3.org/TR/2024/CRD-css-backgrounds-3-20240311/#special-backgrounds).
Table background layers need a separate qualification. Existing row fragments
use their originating cell's visibility while retaining row geometry, rank and
opacity: a hidden row with a visible cell paints that row layer; a visible row
with a hidden cell does not. A visible descendant inside a hidden cell paints
its own content without reviving the cell's row layer. This is the selected
cell-rendered interpretation of [CSS Tables 3](https://www.w3.org/TR/2026/WD-css-tables-3-20261008/#drawing-cell-backgrounds),
a working draft explicitly marked not ready for implementation. Its recorded
browser disagreements and open visibility question remain relevant; these
controls are not a claim of settled cross-browser interoperability.

Each layout carries one typed visibility value for every DOM node. Construction
checks the existing 100,000-node bound and reserves the complete table before
copying values. Refusal returns no paint/hit records and no table; it cannot be
encoded as a successful worker snapshot for a nonempty DOM. Hidden content
still consumes the existing resource preparation and layout/glyph/command
allowances. No resource cap is raised.

The worker protocol advances to ERWB. After the DOM records, it carries an
exact count and one 0/1 byte per node: `4 + N` additional bytes, at most 100,004.
The decoder checks cardinality, available bytes and every discriminant before
allocating the typed vector. Hidden-node hits are refused in either direction;
older protocol magic is rejected. Missing metadata excludes all native focus
candidates. These checks validate transport shape, not the correctness of an
untrusted worker's CSS computation, and add no sandbox authority.

Parent Rust 1.88 measurements record `ComputedStyle` at 1,032 bytes,
`PaintOwner` at 16 and `LayoutResult` at 56. These are actual parent types;
field sizes alone do not establish the candidate's complete ABI or allocator
cost. [PENDING_TYPE_MEASUREMENTS: final actual sizes and observed capacities.]

The independent controls use literal CSS/JS expectations and reference pages
without visibility. Rectangular scenes also compare complete RGB canvases with
fixed rectangles; the text pair uses transparent text to retain layout. Their
parent integration run compiled and recorded zero passes and sixteen failures,
including the missing CSSOM property's Unsupported result. Before execution,
source review fixed explicit table widths and a converter's missing property
name additively; original holds and expected pixels remain retained.

[PENDING_FINAL_VALIDATION: measured candidate tests, strict checks, dynamic
witnesses, exact replay scope and final inventory.]
[PENDING_FAILURE_LEDGER: retained candidate attempts and any narrow corrections.]
The published parent's eleven successful CI jobs do not establish this
checkpoint's remote result. No new GPU execution, complete CSS/browser
compatibility, production-security or Chromium performance claim is made.

Sources and commands are retained in the [evidence manifest](evidence/css-visibility/manifest.json)
and [source/check archive](evidence/css-visibility/sources-and-checks.tar.gz).
