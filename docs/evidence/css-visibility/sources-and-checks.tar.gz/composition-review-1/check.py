from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

N = Path('/tmp/eris-visibility-plan-1')
R = N / 'composition-review-1'
BASE = '18d3648ce4435b0d703e3b41fccc2f9f2fae156e'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def read(name):
    return json.loads((N / name).read_text())

def patch(before, diff):
    lines = diff.splitlines(True)
    old = before.splitlines(True)
    out = []
    at = i = 0
    while i < len(lines):
        match = re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@', lines[i])
        if not match:
            i += 1
            continue
        start = max(int(match[1]) - 1, 0)
        assert start >= at
        out.extend(old[at:start])
        at = start
        i += 1
        left = right = 0
        while i < len(lines) and not lines[i].startswith('@@ '):
            line = lines[i]
            i += 1
            assert line[0] in ' +-'
            if line[0] in ' -':
                assert old[at] == line[1:]
                at += 1
                left += 1
            if line[0] in ' +':
                out.append(line[1:])
                right += 1
        assert left == int(match[2] or 1)
        assert right == int(match[4] or 1)
    out.extend(old[at:])
    return ''.join(out)

def lex(source):
    tokens = []
    literals = []
    comments = []
    at = 0
    while at < len(source):
        if source[at].isspace():
            at += 1
            continue
        if source.startswith('//', at):
            end = source.find('\n', at)
            end = len(source) if end < 0 else end
            comments.append(source[at:end])
            at = end
            continue
        if source.startswith('/*', at):
            end = at + 2
            depth = 1
            while depth:
                if source.startswith('/*', end):
                    depth += 1
                    end += 2
                elif source.startswith('*/', end):
                    depth -= 1
                    end += 2
                else:
                    end += 1
                assert end <= len(source)
            comments.append(source[at:end])
            at = end
            continue
        match = re.match(r'(?:br|r)(#*)"', source[at:])
        if match:
            suffix = '"' + match[1]
            end = source.find(suffix, at + match.end())
            assert end >= 0
            end += len(suffix)
            token = source[at:end]
            literals.append(token)
            tokens.append(token)
            at = end
            continue
        if source[at] == '"' or source.startswith('b"', at):
            end = at + (2 if source[at] == 'b' else 1)
            while end < len(source):
                if source[end] == '\\':
                    end += 2
                elif source[end] == '"':
                    end += 1
                    break
                else:
                    end += 1
            token = source[at:end]
            literals.append(token)
            tokens.append(token)
            at = end
            continue
        match = re.match(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'", source[at:])
        if match:
            token = match[0]
            literals.append(token)
            tokens.append(token)
            at += match.end()
            continue
        match = re.match(r'\w+', source[at:])
        if match:
            tokens.append(match[0])
            at += match.end()
        else:
            tokens.append(source[at])
            at += 1
    return tokens, literals, comments

def fmt_tokens(path, source):
    # Exactly the three reviewed independent item reorderings; no body removal.
    if path == 'src/css.rs':
        source = source.replace('pub(crate) use border_spacing::valid as valid_border_spacing;\n', '')
    if path in ('src/browser.rs', 'src/worker/codec.rs'):
        source = source.replace('#[cfg(test)]\nmod visibility_tests;\n', '')
    tokens, literals, comments = lex(source)
    # Formatter optional final separators are separately enumerated in diffs.
    tokens = [t for i, t in enumerate(tokens) if not (t == ',' and i + 1 < len(tokens) and tokens[i + 1] in (')', ']', '}'))]
    return tokens, literals, comments

imported = read('root/candidate-import-1.json')
assert imported['base'] == BASE
for row in imported['bindings']:
    assert sha(Path(row['path']).read_bytes()) == row['sha256']
composed = {}
origins = {}
holds = ['css-producer-2', 'layout-producer-1', 'layout-fixtures-1', 'layout-fixtures-2', 'browser-producer-1']
for hold in holds:
    for path in sorted((N / hold / 'raw').rglob('*')):
        if path.is_file():
            rel = str(path.relative_to(N / hold / 'raw'))
            before = N / hold / 'before' / rel
            if rel in composed and before.exists():
                assert before.read_bytes() == composed[rel], (hold, rel, 'before')
            composed[rel] = path.read_bytes()
            origins.setdefault(rel, []).append(hold)

historical = read('historical-fixtures-1/edits.json')
for edit in historical:
    path = edit['path']
    if path not in composed:
        composed[path] = subprocess.check_output(['git', 'show', BASE + ':' + path])
    before, after = edit['before'].encode(), edit['after'].encode()
    assert composed[path].count(before) == 1, (path, 'historical uniqueness')
    composed[path] = composed[path].replace(before, after, 1)
    origins.setdefault(path, []).append('historical-fixtures-1 edit')

for hold in ['controls-adapter-correction-1', 'dynamic-controls-1']:
    for path in sorted((N / hold / 'raw').rglob('*')):
        if path.is_file():
            rel = str(path.relative_to(N / hold / 'raw'))
            assert rel not in composed
            composed[rel] = path.read_bytes()
            origins.setdefault(rel, []).append(hold)
composed['src/css.rs'] += (N / 'controls-1/registration/css.rs.append').read_bytes()
origins['src/css.rs'].append('controls-1 registration')
composed['tests/worker.rs'] += (N / 'dynamic-controls-1/registration.txt').read_bytes()
origins['tests/worker.rs'].append('dynamic-controls-1 registration')
expected = {row['path']: row for row in imported['paths']}
assert set(composed) == set(expected) and len(composed) == 31
for path, data in composed.items():
    assert sha(data) == expected[path]['after'] and len(data) == expected[path]['bytes'], path

candidate = read('source-candidate-1.json')
parent = read('source-parent.json')
assert candidate['base'] == parent['base'] == BASE
old = {row['path']: row for row in parent['files']}
new = {row['path']: row for row in candidate['files']}
assert len(old) == len(parent['files']) == 15297
assert len(new) == len(candidate['files']) == 15306
assert old.keys() <= new.keys()
changed = {path for path, row in new.items() if old.get(path) != row}
assert changed == set(composed)

# Independently authenticate every old inventory entry against its published blob.
request = R / 'git-parent-blob-requests.txt'
request.write_text(''.join(BASE + ':' + path + '\n' for path in old))
with request.open('rb') as commands:
    proc = subprocess.Popen(['git', 'cat-file', '--batch'], stdin=commands, stdout=subprocess.PIPE)
    assert proc.stdout is not None
    total = 0
    for path, row in old.items():
        header = proc.stdout.readline().decode().split()
        assert len(header) == 3 and header[1] == 'blob', (path, header)
        count = int(header[2])
        assert count == row['bytes'], path
        digest = hashlib.sha256()
        remain = count
        while remain:
            block = proc.stdout.read(min(remain, 65536))
            assert block
            digest.update(block)
            remain -= len(block)
        assert proc.stdout.read(1) == b'\n'
        assert digest.hexdigest() == row['sha256'], path
        total += count
    assert proc.stdout.read() == b'' and proc.wait() == 0

snapshots = read('root/candidate-snapshots-1.json')
assert snapshots['source_inventory']['sha256'] == sha((N / 'source-candidate-1.json').read_bytes())
assert {row['path']: row for row in snapshots['changed_paths']} == {path:new[path] for path in changed}
rows = []
for path, data in sorted(composed.items()):
    target = N / 'candidate-source-1' / path
    actual = target.read_bytes()
    assert sha(actual) == new[path]['sha256'] and len(actual) == new[path]['bytes'], path
    diff = N / 'format-1/diffs' / (path + '.patch')
    if diff.exists():
        assert patch(data.decode(), diff.read_text()).encode() == actual, path
        before_tokens, before_literals, before_comments = fmt_tokens(path, data.decode())
        after_tokens, after_literals, after_comments = fmt_tokens(path, actual.decode())
        assert before_literals == after_literals, (path, 'literal bytes')
        assert before_comments == after_comments, (path, 'comments')
        if before_tokens != after_tokens:
            for i, pair in enumerate(zip(before_tokens, after_tokens)):
                if pair[0] != pair[1]:
                    raise AssertionError((path, 'tokens', i, before_tokens[max(0,i-8):i+14],after_tokens[max(0,i-8):i+14]))
            raise AssertionError((path, 'token count'))
    else:
        assert actual == data, path
        before_literals = lex(data.decode())[1] if path.endswith('.rs') else []
    rows.append(dict(path=path, origin=origins[path], candidate=bind(target), formatting=bind(diff) if diff.exists() else None, literal_count=len(before_literals)))

checks = dict(base=BASE, imported=bind(N / 'root/candidate-import-1.json'), candidate=bind(N / 'source-candidate-1.json'), parent=bind(N / 'source-parent.json'), snapshots=bind(N / 'root/candidate-snapshots-1.json'), authenticated_parent_blobs=len(old), authenticated_parent_bytes=total, candidate_inputs=len(new), changed_paths=len(changed), new_paths=len(new.keys()-old.keys()), formatting_paths=sum(row['formatting'] is not None for row in rows), rows=rows, status='checks complete', project_execution=False)
(R / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps({key:checks[key] for key in ['authenticated_parent_blobs','authenticated_parent_bytes','candidate_inputs','changed_paths','new_paths','formatting_paths']}))
