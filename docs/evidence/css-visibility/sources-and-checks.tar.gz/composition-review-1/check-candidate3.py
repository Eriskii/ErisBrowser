from pathlib import Path
import ast
import difflib
import hashlib
import json
import re

N = Path('/tmp/eris-visibility-plan-1')
R = N / 'composition-review-1'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def load(name):
    return json.loads((N / name).read_text())

def index(name):
    rows = load(name)['files']
    result = {row['path']: row for row in rows}
    assert len(result) == len(rows)
    return result

assert bind(N / 'source-candidate-3.json')['sha256'] == '1421a1fc1b5433361ab03181cf4a5917d2fbe11c7b28d0a0632ac928fd8dfad4'
parent = index('source-parent.json')
one = index('source-candidate-1.json')
two = index('source-candidate-2.json')
three = index('source-candidate-3.json')
expected = {'src/css.rs', 'src/css/visibility_budget_tests.rs', 'src/css/pending_inline_budget_tests.rs', 'src/cssom/pending_record_tests.rs', 'src/cssom/pending_record_accounting_tests.rs'}
delta = {path for path, row in three.items() if one.get(path) != row}
assert delta == expected and len(three) == 15307 and set(one) <= set(three)
assert {p for p, row in two.items() if one.get(p) != row} == {'src/css.rs', 'src/css/visibility_budget_tests.rs'}
assert {p for p, row in three.items() if two.get(p) != row} == expected - {'src/css.rs', 'src/css/visibility_budget_tests.rs'}
changed = {p for p, row in three.items() if parent.get(p) != row}
assert len(changed) == 35
snapshots = load('root/candidate-snapshots-3.json')
assert snapshots['source_inventory']['sha256'] == bind(N / 'source-candidate-3.json')['sha256']
assert {row['path']: row for row in snapshots['changed_paths']} == {p: three[p] for p in changed}
for path in changed:
    bound = bind(N / 'candidate-source-3' / path)
    assert (bound['bytes'], bound['sha256']) == (three[path]['bytes'], three[path]['sha256'])

registration = N / 'css-budget-controls-1/registration/css.rs.append'
reg = registration.read_bytes()
assert reg == b'\n#[cfg(test)]\nmod visibility_budget_tests;\n'
assert (N / 'candidate-source-3/src/css.rs').read_bytes() == (N / 'candidate-source-1/src/css.rs').read_bytes() + reg
budget_import = load('root/budget-controls-import-1.json')
assert budget_import['source_ready'] == bind(N / 'css-budget-controls-1/source-ready.json')['sha256']
assert budget_import['css_before'] == one['src/css.rs']['sha256']
assert budget_import['css_after'] == three['src/css.rs']['sha256']

# Only the pure local checker lexer is reused, never project code.
tree = ast.parse((R / 'check-v3.py').read_text())
definition = next(x for x in tree.body if isinstance(x, ast.FunctionDef) and x.name == 'lex')
space = {'re': re}
exec(compile(ast.Module(body=[definition], type_ignores=[]), '<local-review-lexer>', 'exec'), space)
path = 'src/css/visibility_budget_tests.rs'
raw = (N / 'css-budget-controls-1/raw' / path).read_text()
actual = (N / 'candidate-source-3' / path).read_text()
assert space['lex'](raw) == space['lex'](actual)
assert re.findall(r'#\[test\]\s*fn\s+(\w+)', raw) == load('css-budget-controls-1/source-ready.json')['groups']
module_diff = R / 'candidate3-budget-format.diff'
diff = ''.join(difflib.unified_diff(raw.splitlines(True), actual.splitlines(True), fromfile='held/' + path, tofile='candidate3/' + path))
if module_diff.exists():
    assert module_diff.read_text() == diff
else:
    module_diff.write_text(diff)

imports = load('root/all-fixtures-import-1.json')['paths']
assert len(imports) == 4
for row in imports:
    path, hold = row['path'], row['hold']
    before, after = N / hold / 'before' / path, N / hold / 'raw' / path
    assert bind(before)['sha256'] == row['before'] and bind(after)['sha256'] == row['after']
    if hold == 'all-fixtures-1':
        assert bind(before)['sha256'] == one[path]['sha256']
    else:
        assert before.read_bytes() == (N / 'all-fixtures-1/raw' / path).read_bytes()
rows = []
for path in sorted(delta):
    final = N / 'candidate-source-3' / path
    if path not in {'src/css.rs', 'src/css/visibility_budget_tests.rs'}:
        hold = 'all-fixtures-2' if path.endswith('/pending_record_tests.rs') else 'all-fixtures-1'
        assert final.read_bytes() == (N / hold / 'raw' / path).read_bytes()
    rows.append(dict(path=path, candidate1=one.get(path), candidate3=three[path], snapshot=bind(final)))

# Root's format directories are cumulative against original held payloads.
# Their CSS diff adds the exact registration; it is not itself formatter output.
format_rows = []
oldfiles = {str(p.relative_to(N / 'format-1/diffs')): p for p in (N / 'format-1/diffs').rglob('*') if p.is_file()}
suffix = '@@ -8860,3 +8857,6 @@\n \n #[cfg(test)]\n mod visibility_tests;\n+\n+#[cfg(test)]\n+mod visibility_budget_tests;\n'
for version in [2, 3]:
    files = {str(p.relative_to(N / f'format-{version}/diffs')): p for p in (N / f'format-{version}/diffs').rglob('*') if p.is_file()}
    assert files.keys() == oldfiles.keys()
    for name, file in files.items():
        if name == 'src/css.rs.patch':
            assert file.read_text() == oldfiles[name].read_text() + suffix
        else:
            assert file.read_bytes() == oldfiles[name].read_bytes()
    format_rows.append(dict(directory=f'format-{version}/diffs', original_eleven_diffs_exact=True, css_diff_adds_only_exact_cfg_test_registration=True))

report = {
    'schema': 1, 'status': 'clear',
    'scope': 'Bounded candidate1-to-candidate3 composition addendum only. No repeated published-parent Git authentication or functional outcome claims.',
    'parent_review': bind(R / 'review.json'),
    'candidate1': bind(N / 'source-candidate-1.json'), 'candidate2': bind(N / 'source-candidate-2.json'), 'candidate3': bind(N / 'source-candidate-3.json'),
    'snapshot_receipt': bind(N / 'root/candidate-snapshots-3.json'),
    'selected_holds': [bind(N / x / 'source-ready.json') for x in ['css-budget-controls-1', 'all-fixtures-1', 'all-fixtures-2']],
    'root_imports': [bind(N / 'root/budget-controls-import-1.json'), bind(N / 'root/all-fixtures-import-1.json')],
    'registration': bind(registration), 'derived_new_module_format_diff': bind(module_diff), 'checker': bind(R / 'check-candidate3.py'),
    'rows': rows,
    'checks': {
        'inputs': 15307, 'changed_paths_from_published_base': 35, 'delta_paths_from_candidate1': 5, 'new_paths_from_candidate1': 1,
        'new_test_groups': 5, 'fixture_groups_migrated': 4, 'old_groups_renamed': 0,
        'all_production_candidate1_exact_except_cfg_test_registration': True,
        'all_non_delta_inventory_rows_exact': True, 'all_35_final_snapshot_bindings_match': True,
        'new_module_all_tokens_literals_and_comments_exact_after_whitespace': True,
        'three_historical_test_paths_exact_selected_raw': True,
        'all_original_public_literals_and_dynamic_fixture_paths_unchanged': True,
        'format_directories': format_rows,
    },
    'findings': [],
    'qualifications': [
        'This verifies exact source closure against held payloads. Five new CSS budget groups have separate root review; no execution logs were inspected.',
        'The reviewer authored all-fixtures holds; their independent HTML peer is separate. This addendum checks exact root import and composition.',
        'First inline source check completed inventory/payload checks, then stopped because it expected every cumulative format file to equal format1. Source inspection showed only the exact selected cfg(test) registration appended to the CSS diff. This checker explicitly verifies that suffix. No candidate change resulted.',
        'The cumulative format directories omit the newly introduced budget module; its whitespace-only delta was independently derived and bound here.',
    ],
    'project_execution': False, 'live_edits': False,
}
target = R / 'candidate3-addendum.json'
assert not target.exists()
target.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(bind(target)))
