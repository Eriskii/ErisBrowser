from pathlib import Path
import json, hashlib, difflib, subprocess, re, math
N=Path('/tmp/eris-visibility-plan-1');W=N/'worktree';D=N/'documentation-1';O=N/'documentation-2'
BASE='18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
def bind(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,s):
 p=O/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def put(p,x):write(p,json.dumps(x,indent=2)+'\n')
verified={}
def verify_refs(x):
 if isinstance(x,dict):
  if all(k in x for k in ['path','bytes','sha256']):
   p=Path(x['path']);assert bind(p)=={k:x[k] for k in ['path','bytes','sha256']},str(p);verified[str(p)]=bind(p)
  for v in x.values():verify_refs(v)
 elif isinstance(x,list):
  for v in x:verify_refs(v)
ledger_path=N/'root/final-validation.json';ledger=json.loads(ledger_path.read_text());assert bind(ledger_path)['sha256']=='1c4ecff753c6b9fdc6b1711d4f25c73f7ad557f57529ae0d2551ebb4653cf8eb';assert ledger['status']=='pass';verify_refs(ledger)
draft=json.loads((D/'draft-ready.json').read_text());verify_refs(draft)
assert bind(D/'draft-ready.json')['sha256']=='549b16210b033fb2d524f83ac01451d0f812027941383edc9a67a64cf359bbb0'
paths=[x['relative_path'] for x in draft['files']]
assert paths==['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/css-visibility.md']
before={p:(D/'before'/p).read_text() if (D/'before'/p).exists() else '' for p in paths}
for p,s in before.items():
 if s:
  assert s.encode()==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]);write('before/'+p,s)
after={p:(D/'raw'/p).read_text() for p in paths}
chapter=after['docs/css-visibility.md'];chapter=chapter[:chapter.index('Parent Rust 1.88 measurements record')]+'''Actual Rust 1.88 measurements on this host keep `ComputedStyle` at 1,032 bytes.
`PaintOwner` grows from 16 to 24 bytes and `LayoutResult` from 56 to 80. The
visibility vector adds one byte per stored node; capacity and allocator overhead
are additional. At the unchanged 200,000-command limit, one equally sized owner
roster gains 1,600,000 payload bytes. That arithmetic is not a peak-allocation
bound: construction can retain more than one vector.

The independent controls use literal CSS/JS expectations and reference pages
without visibility. Rectangular scenes compare complete RGB canvases with fixed
rectangles; the text pair uses transparent text to retain layout. All sixteen
parent integration groups compiled and failed, including the missing CSSOM
property's Unsupported result. Separate direct and confined dynamic witnesses
also failed on the parent's hidden red pixel. The final suites include all
thirty-six added groups covering CSS, pixels/CSSOM, focus, codec, dynamic
behavior and resource boundaries, with no old groups removed.

The selected source passed 3,521 tests on Rust 1.88 and 3,885 on Rust 1.99 with
`test262-host,vulkan-raster`, across 58 result rows each, with zero failures or
ignored tests. Both strict Clippy configurations and the formatting check
passed. The release browser passed all 102 existing reference pairs; all 204
test/reference images also matched the published parent exactly. The selected
inventory contains 15,307 source/build/tool/test inputs and 35 changed source
paths; it excludes documentation, build outputs and external dependencies.

An eighteen-process CPU comparison used the parent and candidate release
browsers with fixed visible, hidden and reference scenes. All process, image and
cleanup checks passed. Three alternating-order pairs per rendering path measured
the all-visible dense scene with 100 warm iterations per process. The observed
candidate/parent median ratios were:

| Pair | Direct paint | Confined worker total |
| --- | ---: | ---: |
| 1 | 1.0307 | 1.0430 |
| 2 | 0.9782 | 1.0640 |
| 3 | 1.0384 | 1.0416 |

Pooling the worker's 300 warm samples per revision gives median totals of
2.824274 ms for the parent and 2.964620 ms for the candidate. Direct results are
rounded process summaries and are not pooled as raw samples. These are local,
uncontrolled measurements, with no speed threshold; reduced hidden painting is
a behavioral change, not evidence of a universal speedup. No Chromium comparison
or GPU execution was performed for this checkpoint.

Failures and corrections remain in the evidence. Before execution, source
review made table fixture widths explicit, repaired a converter's missing
property name and supplied a missed visibility field in an old layout fixture.
The first full run's top-level result was 3,142 passes and twelve failures:
four old `all` fixtures had stale roster/byte assumptions, and eight socket
preflights met outer sandbox `EPERM`. The fixture migration accounts for 87
longhands while preserving the exact 256-record and 65,536-byte limits; its
one-byte filler received a source-only lint refinement. Full suites were then
rerun with the required socket permission. The first measurement attempt stopped
at the parent before accepting any samples because `TZ=UTC` required unavailable
timezone data. Cleanup completed; runner2 uses the equivalent POSIX offset
`UTC0`, preserving scene bytes, order, pixels and supervision.

The published parent's eleven successful CI jobs remain a parent result. This
checkpoint makes no complete CSS/browser compatibility, production-security or
Chromium performance claim. Sources, commands, earlier holds and failed attempts
are retained in the [evidence manifest](evidence/css-visibility/manifest.json)
and [source/check archive](evidence/css-visibility/sources-and-checks.tar.gz).
'''
after['docs/css-visibility.md']=chapter
validation='''## CSS visible/hidden visibility

The [visibility subset](css-visibility.md) keeps hidden boxes in layout while
filtering their own paint/hits and native focus eligibility. Visible descendants
retain their clip, fixed-coordinate, opacity and ancestor context. Canvas
backgrounds remain painted; table row layers follow a selected CSS Tables 3
working-draft interpretation with recorded interoperability disagreement.
`collapse` is deferred. Layout, resource and IPC limits are unchanged.

The selected source passed **3,521 tests on Rust 1.88** and **3,885 on Rust 1.99
with `test262-host,vulkan-raster`**, across 58 result rows each, with zero failed
or ignored tests. Both strict Clippy configurations and the final formatting
check passed. The full rosters preserve all prior groups and add 36: six CSS,
sixteen pixel/CSSOM, three native-focus, four codec, two direct/confined dynamic
and five resource-boundary groups. The earlier focused run passed 35 matching
groups (31 new and four existing); the five budget groups were added afterward.

The parent had compiled and failed all sixteen public integration groups:
fifteen pixel/hit/reference groups and one missing-property CSSOM group. Direct
computed-style controls require the new field and were not run against the
parent. Separate direct and confined dynamic parent witnesses failed on the
hidden red pixel. Their selected candidate versions pass in the full suites.

The release browser passed all **102 existing reference pairs**, and all
**204 test/reference images matched the parent exactly**. The separate selected
measurement run completed all eighteen supervised processes with expected pixels
and clean teardown. For the dense all-visible scene, three direct median
candidate/parent ratios were 1.0307, 0.9782 and 1.0384; confined worker-total
ratios were 1.0430, 1.0640 and 1.0416. The worker's pooled 300 warm samples per
revision had median totals of 2.824274 ms parent and 2.964620 ms candidate.
These are uncontrolled local CPU observations, not a performance gate or a
Chromium/GPU comparison. Direct rounded summaries are not pooled as raw samples.

Actual Rust 1.88 type measurements keep `ComputedStyle` at 1,032 bytes;
`PaintOwner` changes from 16 to 24 and `LayoutResult` from 56 to 80. One typed
visibility byte is stored per DOM node, with allocator/capacity overhead
additional. ERWB transmits a four-byte count plus one checked byte per node,
`4 + N` bytes with a maximum of 100,004; all old frame and node caps remain.

The first full attempt's top-level result was 3,142 passes and twelve failures:
four stale historical `all` fixtures and eight localhost socket-preflight
`EPERM` failures. Nested child-process summaries in that log are not additional
top-level groups. The three-file fixture migration updates the 87-longhand
roster and its token/filler arithmetic while preserving the 256-record and exact
65,536-byte caps and atomic one-over refusals. A one-line `repeat(1)` replacement
constructs the same one-byte filler before linting. Full suites then passed with
the required socket permission. Earlier table-width, missing-property-name and
missing-layout-field source corrections remain separate immutable holds with
unchanged pixel oracles. Source-checker interruptions and their narrow checker
corrections are also retained; they did not change candidate behavior.

Measurement attempt1 failed before any accepted samples: `TZ=UTC` could not load
its timezone data on this host. The supervisor recorded completed cleanup and
zero descendants. The additive runner2 selects POSIX `UTC0` with the same offset
and unchanged fixtures, process order, expected images and supervision. The
successful second attempt is the selected result; the first remains archived.

The final source inventory is candidate3: **15,307 inputs and 35 changed source
paths**, SHA-256 `1421a1fc1b5433361ab03181cf4a5917d2fbe11c7b28d0a0632ac928fd8dfad4`.
Its scope includes source, Cargo build inputs, tools and tests, including pinned
corpora; it excludes documentation, build outputs and external dependencies.
The final validation ledger is SHA-256
`1c4ecff753c6b9fdc6b1711d4f25c73f7ad557f57529ae0d2551ebb4653cf8eb`.
The published parent `18d3648c` has eleven successful remote CI jobs; that is
not a remote result for this checkpoint. No new GPU execution, complete browser
compatibility, security certification or Chromium performance result is claimed.

See the [evidence manifest](evidence/css-visibility/manifest.json) and
[source/check archive](evidence/css-visibility/sources-and-checks.tar.gz).
The complete prior validation body below remains byte-exact.

'''
heading,history=before['docs/VALIDATION.md'].split('\n\n',1)
after['docs/VALIDATION.md']=heading+'\n\n'+validation+history
write('current-validation.md',validation)
files=[]
for p in paths:
 a=before[p];b=after[p];write('raw/'+p,b)
 forward=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p if a else '/dev/null',tofile='b/'+p))
 inverse=''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+p,tofile='b/'+p if a else '/dev/null'))
 df=''.join(difflib.unified_diff((D/'raw'/p).read_text().splitlines(True),b.splitlines(True),fromfile='draft1/'+p,tofile='final2/'+p))
 di=''.join(difflib.unified_diff(b.splitlines(True),(D/'raw'/p).read_text().splitlines(True),fromfile='final2/'+p,tofile='draft1/'+p))
 write('diffs/forward/'+p+'.patch',forward);write('diffs/inverse/'+p+'.patch',inverse);write('draft-diffs/forward/'+p+'.patch',df);write('draft-diffs/inverse/'+p+'.patch',di)
 files.append({'relative_path':p,'before':bind(O/'before'/p) if a else None,'raw':bind(O/'raw'/p),'forward':bind(O/'diffs/forward'/(p+'.patch')),'inverse':bind(O/'diffs/inverse'/(p+'.patch')),'draft_forward':bind(O/'draft-diffs/forward'/(p+'.patch')),'draft_inverse':bind(O/'draft-diffs/inverse'/(p+'.patch'))})
for p in paths[:4]:assert after[p]==(D/'raw'/p).read_text()
assert after['docs/VALIDATION.md'].endswith(history)
assert after['docs/VALIDATION.md'].replace(validation,'',1)==before['docs/VALIDATION.md']
assert all('PENDING_' not in x for x in after.values())
# Read-only evidence checks; no repository module is imported or executed.
attempts={x['label']:x for x in ledger['attempts']}
full=[]
for label,total in [('candidate-full-msrv-2',3521),('candidate-full-host-vulkan-1',3885)]:
 row=attempts[label];assert row['accepted'] and row['exit']==0
 raw=Path(row['log']['path']).read_text();matches=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.M)
 assert len(matches)==58 and tuple(sum(int(t[i]) for t in matches) for i in range(3))==(total,0,0)
 full.append({'label':label,'rows':len(matches),'passed':total,'failed':0,'ignored':0,'receipt':row['receipt'],'log':row['log']})
for label in ['candidate-clippy-msrv-1','candidate-clippy-host-vulkan-1','fmt-check-final-1','candidate-release-browser-1','candidate-reftests-1','candidate-measurement-2']:
 assert attempts[label]['accepted'] and attempts[label]['exit']==0
assert sum(ledger['new_coverage'].values())==36
for t in ledger['test_roster_transitions']:assert len(t['added'])==36 and t['removed']==[]
assert ledger['storage']['parent']=={'ComputedStyle':1032,'PaintOwner':16,'LayoutResult':56}
assert ledger['storage']['candidate']=={'ComputedStyle':1032,'PaintOwner':24,'LayoutResult':80}
for x in ledger['storage_measurements']:
 raw=Path(x['log']['path']).read_text()
 for key,value in x['observed'].items():assert f'{key}={value}' in raw,(key,raw)
comparison=json.loads(Path(ledger['visual_parent_candidate_comparison']['path']).read_text());verify_refs(comparison)
assert comparison['status']=='pass' and comparison['pairs']==102 and comparison['images_compared']==204 and len(comparison['cases'])==102
assert sum(len(x['images']) for x in comparison['cases'])==204
for c in comparison['cases']:
 for im in c['images']:assert im['parent']['sha256']==im['candidate']['sha256']
reports=[]
for ref in ledger['visual_references']:
 j=json.loads(Path(ref['path']).read_text());assert (j['passed'],j['failed'],j['total'])==(102,0,102);assert len(j['cases'])==102
 assert all(x['status']=='pass' and x['different_pixels']==0 and x['maximum_channel_error']==0 for x in j['cases']);reports.append(j)
assert [x['name'] for x in reports[0]['cases']]==[x['name'] for x in reports[1]['cases']]
measurement=json.loads(Path(ledger['measurement']['result']['path']).read_text());verify_refs(measurement)
assert measurement['status']=='passed' and len(measurement['attempts'])==18 and measurement['summary']==ledger['measurement']['summary']
assert not measurement['controlled_environment'] and not measurement['chromium_comparison'] and not measurement['hardware_validation']
for a in measurement['attempts']:
 s=json.loads(Path(a['supervisor']['path']).read_text());assert s['status']=='exited' and type(s['returncode']) is int and s['returncode']==0
 assert s['cleanup']['complete'] is True and s['cleanup']['descendants']==0 and s['cleanup']['checker_returncode']==0
pairs=measurement['summary']['pairs'];direct=[];worker=[]
for x in pairs:
 if x['mode']=='direct':direct.append(next(y['ratio'] for y in x['measurements'] if y['phase']=='median_ms'))
 else:worker.append(next(y['ratio'] for y in x['measurements'] if y['phase']=='total_ms' and y['statistic']=='median_ms'))
assert [f'{x:.4f}' for x in direct]==['1.0307','0.9782','1.0384'];assert [f'{x:.4f}' for x in worker]==['1.0430','1.0640','1.0416']
for role,expected in [('parent',2.824274),('candidate',2.964620)]:
 rows=[a for a in measurement['attempts'] if a['role']==role and a['fixture']=='all-visible-dense' and a['mode']=='worker'];assert len(rows)==3
 values=[]
 for a in rows:
  raw=a['raw_worker'];assert len(raw['warm_samples'])==100
  stdout=Path(a['stdout']['path']).read_text();assert json.loads(stdout)==raw
  values.extend(x['total_ms'] for x in raw['warm_samples'])
 values.sort();assert len(values)==300 and values[150]==expected
 assert measurement['summary']['pooled_worker'][role]['total_ms']['median_ms']==expected
first=json.loads((N/'measurement-results-1/result.json').read_text());assert first['status']=='failed' and first['attempts']==[]
super1=json.loads((N/'measurement-results-1/direct-dense-1-parent/supervisor.json').read_text());assert super1['cleanup']['complete'] is True and super1['cleanup']['descendants']==0 and super1['returncode']==1
assert 'host timezone Unavailable' in (N/'measurement-results-1/direct-dense-1-parent/supervisor.stderr.log').read_text()
assert '3142 passed; 12 failed; 0 ignored' in (N/'validation/candidate-full-msrv-1.log').read_text()
ci=Path('/tmp/eris-object-super-properties-plan-1/publication/ci-observation-2.json');cj=json.loads(ci.read_text());assert cj['headSha']==BASE and len(cj['jobs'])==11 and all(x['conclusion']=='success' for x in cj['jobs'])
inventory=json.loads(Path(ledger['source_inventory']['path']).read_text());assert len(inventory['files'])==15307 and ledger['changed_source_paths']==35
snapshots=json.loads(Path(ledger['source_snapshots']['path']).read_text());assert len(snapshots['files'])==35
history_pins=[]
for p in ['docs/classes.md','docs/class-super-properties.md','docs/object-super-properties.md','docs/promise-class-admission.md','docs/vulkan-line-accounting.md']:
 b=(W/p).read_bytes();assert b==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]);history_pins.append(bind(W/p))
links=[]
future={'docs/evidence/css-visibility/manifest.json','docs/evidence/css-visibility/sources-and-checks.tar.gz'}
# Check only inserted or new links; retained published prose is historical.
for p in paths:
 content=after[p] if not before[p] else '\n'.join(x[1:] for x in (O/'diffs/forward'/(p+'.patch')).read_text().splitlines() if x.startswith('+') and not x.startswith('+++'))
 for target in re.findall(r'\]\(([^)]+)\)',content):
  if target.startswith(('https://','http://')): links.append({'from':p,'target':target,'kind':'retained primary specification link'});continue
  resolved=str((Path(p).parent/target).as_posix());assert resolved in paths or resolved in future or (W/resolved).exists(),resolved
  links.append({'from':p,'target':target,'resolved':resolved,'kind':'selected future evidence' if resolved in future else 'repository'})
extra=[N/'design-1/source-ready.json',N/'controls-1/literal-correction-1.json',N/'controls-adapter-correction-1/source-ready.json',N/'layout-fixtures-2/source-ready.json',N/'all-fixtures-1/source-ready.json',N/'all-fixtures-2/source-ready.json',N/'measurement-runner-1/source-ready.json',N/'measurement-runner-2/source-ready.json',N/'measurement-results-1/result.json',N/'measurement-results-1/direct-dense-1-parent/supervisor.json',N/'measurement-results-1/direct-dense-1-parent/supervisor.stderr.log',ci]
put('claims-and-checks.json',{'schema':1,'status':'source and actual-evidence joins checked','base':BASE,'final_validation':bind(ledger_path),'draft_hold':bind(D/'draft-ready.json'),'source_inventory':ledger['source_inventory'],'source_snapshots':ledger['source_snapshots'],'full_suite_summaries':full,'source_inputs':15307,'changed_source_paths':35,'new_groups':36,'visual_pairs':102,'parent_candidate_exact_images':204,'measurement_processes':18,'measurement_summary':measurement['summary'],'storage':ledger['storage'],'retained_failures':ledger['retained_failures'],'first_full_top_level_failure_count':12,'first_full_nested_summary_qualification':'The first failed run also contains two failing child summaries; these do not add top-level groups.','draft_unchanged_paths':paths[:4],'draft_changed_paths':paths[4:],'historical_validation_suffix_exact':True,'prior_chapters_exact':history_pins,'extra_bindings':[bind(x) for x in extra],'verified_file_bindings':list(verified.values()),'links':links,'no_pending_placeholders':True,'no_project_import_execution_or_live_edits':True})
put('source-ready.json',{'schema':1,'status':'source-ready final six-document hold','base':BASE,'final_validation':bind(ledger_path),'source_inventory':ledger['source_inventory'],'source_snapshots':ledger['source_snapshots'],'draft_hold':bind(D/'draft-ready.json'),'files':files,'checks':bind(O/'claims-and-checks.json'),'author':bind(O/'author.py'),'chapter_words':len(chapter.split()),'historical_validation_suffix_exact':True,'unchanged_from_draft':paths[:4],'only_draft_changes':paths[4:],'planned_evidence_paths':sorted(future),'project_execution':False,'live_edits':False})
print(json.dumps({'hold':bind(O/'source-ready.json'),'checks':bind(O/'claims-and-checks.json'),'chapter_words':len(chapter.split()),'verified_bindings':len(verified)}))
