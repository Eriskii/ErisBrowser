Root-only visibility differential runner

Launch only after candidate-browser.json binds the final successful Rust1.88 release build and source-candidate-3.json (or explicitly selected replacement inventory):

python3 -I -B /tmp/eris-visibility-plan-1/measurement-runner-2/run.py --candidate-sidecar /tmp/eris-visibility-plan-1/binaries/candidate-browser.json --candidate-inventory /tmp/eris-visibility-plan-1/source-candidate-3.json --output-dir /tmp/eris-visibility-plan-1/measurement-results-2

The output directory must be a fresh direct measurement-results-* child of the plan root. The runner launches exactly18 serial browser processes through the pinned existing supervisor. No project command has been run by the author. Its only runtime import of repository Python is the pinned reftest PNG decoder after all inputs verify; bytecode writes are disabled.

The supervisor already supplies120-second runtime and5-second owned-descendant cleanup bounds. The wrapper allows140 seconds, then requests supervisor termination and allows15 seconds for its cleanup handler. If that does not finish, it records unresolved cleanup and stops; killing a stuck supervisor never becomes a successful cleanup claim.

All raw browser logs, wrapper logs, supervisor JSON, invocation records, PNGs and per-attempt validated observations remain under the results directory. A failure stops later attempts and retains result.json plus the active attempt and available files. No timings are accepted before full literal pixel equality. The final successful report binds inputs before and after, all18 records and six paired summaries. Direct CLI medians/p95 are rounded process summaries; only worker warm arrays are pooled. A zero denominator yields a null ratio.

The runner does not change source, limits, baselines or policy. No GPU/window process is requested. No Chromium, overall-performance, full-compatibility, security or RSS guarantee is inferred.

Additive runtime environment correction: TZ=UTC0 selects the existing POSIX zero-offset rule directly. TZ=UTC previously reached the unavailable named zone file on this host. The first attempt remains failed with zero validated runs, exit1 and complete one-process cleanup; it is not a timing or rendering result. All18 commands, fixtures, pixel hashes, supervision and summary logic are unchanged. Runner2 has not been executed by its author.
