#!/usr/bin/env python3
"""Root-only execution of the frozen visibility measurement proposal."""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import platform
import re
import signal
import stat
import subprocess
import sys

N = Path('/tmp/eris-visibility-plan-1')
W = N / 'worktree'
H = Path(__file__).resolve().parent
P = N / 'measurement-proposal-1'
BASE = '18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
PROPOSAL_SHA = '5b8b736e2b1608b2d59f1e31cd9fd0f14226db6a6bd63a7e7474a3e5a09f53ac'
CLARIFICATION_SHA = '105bf09875a246b20aff26389ce7b7a9657729c6101f2144aa831ccff683f5f1'
PARENT_BINARY_SHA = '983205612603ae8a7d6e197ef2085a993536340351824954c948cc32a4640d85'
PARENT_SOURCE_SHA = '8745f10c95e0500dd4884b296e387af69ced688d278e399e81ac454b090dd6d6'
VIEWPORT = [1180, 880]
LIMIT = 1024 * 1024
PHASES = ('startup_ms', 'load_ms', 'cold_render_exchange_ms', 'cold_clear_paint_ms', 'teardown_ms')
WARM = ('render_exchange_ms', 'clear_paint_ms', 'total_ms')
PIXELS = {
    ('all-visible-dense', 'parent'): 'a7d174c94c6d1cdd8879033435459ea277713d6bcfb913b86817c4a3d329b6cc',
    ('all-visible-dense', 'candidate'): 'a7d174c94c6d1cdd8879033435459ea277713d6bcfb913b86817c4a3d329b6cc',
    ('hidden-override', 'parent'): '376a3f3d53cb160e37e53cdc6a2e7eae2d905585317530d6335a8cafe06d3304',
    ('hidden-override', 'candidate'): '998676b29d74a7be78a5d13e40a3edf9b9efff234a002279f9915e05b9ccf471',
    ('hidden-reference', 'parent'): '998676b29d74a7be78a5d13e40a3edf9b9efff234a002279f9915e05b9ccf471',
    ('hidden-reference', 'candidate'): '998676b29d74a7be78a5d13e40a3edf9b9efff234a002279f9915e05b9ccf471',
}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    path = Path(path)
    require(path.is_absolute(), f'nonabsolute path: {path}')
    require(stat.S_ISREG(path.lstat().st_mode), f'not a regular file: {path}')
    return path


def binding(path):
    path = regular(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def verify(row):
    require(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}, 'bad binding schema')
    require(type(row['bytes']) is int and row['bytes'] >= 0, 'bad binding byte count')
    require(type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']), 'bad digest')
    require(binding(row['path']) == row, f'binding mismatch: {row["path"]}')
    return Path(row['path'])


def no_duplicates(pairs):
    obj = {}
    for key, value in pairs:
        require(key not in obj, f'duplicate JSON key: {key}')
        obj[key] = value
    return obj


def read_json(path):
    return json.loads(regular(path).read_text(), object_pairs_hook=no_duplicates,
                      parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))


def write_json(path, value):
    with Path(path).open('x') as out:
        json.dump(value, out, indent=2, allow_nan=False)
        out.write('\n')


def inventory(path, live):
    obj = read_json(path)
    require(set(obj) == {'base', 'scope', 'files'} and obj['base'] == BASE, 'source inventory identity')
    require(type(obj['scope']) is str and obj['scope'], 'missing selected source scope')
    require(type(obj['files']) is list and obj['files'], 'missing source list')
    names = []
    for row in obj['files']:
        require(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}, 'inventory row schema')
        rel = Path(row['path'])
        require(not rel.is_absolute() and '..' not in rel.parts and str(rel) == row['path'], 'unsafe inventory path')
        names.append(row['path'])
        if live:
            verify(dict(row, path=str(W / rel)))
    require(names == sorted(set(names)), 'source names are not unique/sorted')
    return obj


def sidecar(path, role, candidate_inventory):
    obj = read_json(path)
    require(set(obj) == {'binary', 'source_inventory', 'build', 'environment'}, 'sidecar schema')
    for row in obj.values():
        verify(row)
    binary = Path(obj['binary']['path'])
    require(os.access(binary, os.X_OK), 'binary is not executable')
    build_path = Path(obj['build']['path'])
    build = read_json(build_path)
    require(build['exit'] == 0 and type(build['exit']) is int, 'unsuccessful release build')
    require(build['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--release', '--bin', 'eris-browser'], 'build command mismatch')
    require(type(build['log']) is str and Path(build['log']).name == build['log'], 'unsafe build log')
    build_log = binding(build_path.parent / build['log'])
    require(build_log['sha256'] == build['sha256'], 'release build log mismatch')
    env = read_json(Path(obj['environment']['path']))
    require(env['config'] == 'msrv' and env['toolchain'] == '1.88.0' and env['features'] == [], 'release configuration mismatch')
    require('host: x86_64-unknown-linux-gnu\n' in env['rustc'] and 'release: 1.88.0\n' in env['rustc'], 'release architecture/compiler mismatch')
    if role == 'parent':
        require(obj['binary']['sha256'] == PARENT_BINARY_SHA, 'published parent binary mismatch')
        require(obj['source_inventory']['sha256'] == PARENT_SOURCE_SHA, 'published parent inventory mismatch')
        require(binary == N / 'binaries/parent-browser', 'parent path mismatch')
    else:
        require(Path(obj['source_inventory']['path']) == candidate_inventory, 'candidate inventory path mismatch')
        output = Path(env['target_dir']) / 'release/eris-browser'
        output_binding = binding(output)
        require((output_binding['bytes'], output_binding['sha256']) == (obj['binary']['bytes'], obj['binary']['sha256']), 'candidate is not the retained release output or byte-identical copy')
        obj = dict(obj, release_output=output_binding)
    source = inventory(Path(obj['source_inventory']['path']), role == 'candidate')
    return dict(sidecar=binding(path), records=obj, build_log=build_log,
                selected_source_files=len(source['files']), source_scope=source['scope'], environment=env)


def inputs(args):
    runner_hold = read_json(H / 'source-ready.json')
    for row in runner_hold['files']:
        verify(row)
    require(any(row['path'] == str(Path(__file__).resolve()) for row in runner_hold['files']), 'runner is absent from selected hold')
    require(binding(P / 'source-ready.json')['sha256'] == PROPOSAL_SHA, 'proposal seal mismatch')
    require(binding(P / 'supervisor-schema-clarification.json')['sha256'] == CLARIFICATION_SHA, 'supervisor clarification mismatch')
    hold = read_json(P / 'source-ready.json')
    for row in hold['files']:
        verify(row)
    plan = read_json(P / 'proposal.json')
    for row in plan['input_pins'] + plan['fixture_pins']:
        verify(row)
    frozen_pixels = read_json(P / 'pixel-contract.json')
    for (fixture, role), expected in PIXELS.items():
        row = frozen_pixels['cases'][fixture]
        require(row.get(role, row.get('both'))['rgba_sha256'] == expected, 'pixel literal differs from frozen contract')
    return dict(runner_hold=binding(H / 'source-ready.json'), proposal=binding(P / 'source-ready.json'), clarification=binding(P / 'supervisor-schema-clarification.json'),
                runner=binding(Path(__file__).resolve()), pixel_contract=binding(P / 'pixel-contract.json'),
                proposal_inputs=plan['input_pins'] + plan['fixture_pins'],
                parent=sidecar(args.parent_sidecar, 'parent', args.candidate_inventory),
                candidate=sidecar(args.candidate_sidecar, 'candidate', args.candidate_inventory))


def sanitized_environment():
    allowed = ('PATH', 'HOME', 'USER', 'LOGNAME', 'TMPDIR', 'XDG_CACHE_HOME', 'XDG_DATA_HOME',
               'XDG_CONFIG_HOME', 'FONTCONFIG_FILE', 'FONTCONFIG_PATH')
    env = {key: os.environ[key] for key in allowed if key in os.environ}
    env.update(LANG='C.UTF-8', LC_ALL='C.UTF-8', TZ='UTC')
    require('PATH' in env and 'HOME' in env, 'missing required environment')
    return env


def load_decoder():
    path = W / 'tools/reftest.py'
    spec = importlib.util.spec_from_file_location('held_visibility_png_decoder', path)
    require(spec is not None and spec.loader is not None, 'PNG decoder import setup')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)  # Root execution only, after every source pin was verified.
    return module.decode_png


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def validate_worker(data, iterations):
    require(type(data) is dict and set(data) == {'schema', 'viewport', 'scripts', 'iterations', 'nodes', 'commands', 'warm_samples', *PHASES}, 'worker root schema')
    require(type(data['schema']) is int and data['schema'] == 1, 'worker schema version')
    require(data['viewport'] == VIEWPORT and all(type(v) is int for v in data['viewport']), 'worker viewport')
    require(data['scripts'] is True and type(data['iterations']) is int and data['iterations'] == iterations, 'worker invocation mismatch')
    require(type(data['nodes']) is int and 0 < data['nodes'] <= 100000, 'worker node count')
    require(type(data['commands']) is int and 0 < data['commands'] <= 200000, 'worker command count')
    require(all(finite(data[key]) for key in PHASES), 'worker phase value')
    require(type(data['warm_samples']) is list and len(data['warm_samples']) == iterations, 'worker sample count')
    for row in data['warm_samples']:
        require(type(row) is dict and set(row) == set(WARM) and all(finite(row[k]) for k in WARM), 'worker warm sample schema/value')
        require(row['total_ms'] + .000002 >= row['render_exchange_ms'] + row['clear_paint_ms'], 'worker total omits measured phases')


def summarize(values):
    values = sorted(values)
    require(values and all(finite(value) for value in values), 'invalid timing summary input')
    return dict(samples=len(values), median_ms=values[len(values) // 2], p95_ms=values[math.ceil(len(values) * .95) - 1])


def run_spec():
    rows = []
    for mode in ('direct', 'worker'):
        for pair, order in enumerate((('parent', 'candidate'), ('candidate', 'parent'), ('parent', 'candidate')), 1):
            for role in order:
                rows.append(dict(id=f'{mode}-dense-{pair}-{role}', fixture='all-visible-dense', mode=mode, role=role, pair=pair, iterations=100))
    for role in ('parent', 'candidate'):
        rows.append(dict(id=f'hidden-direct-{role}', fixture='hidden-override', mode='render', role=role, pair=None, iterations=0))
        rows.append(dict(id=f'hidden-worker-{role}', fixture='hidden-override', mode='worker', role=role, pair=None, iterations=1))
        rows.append(dict(id=f'reference-direct-{role}', fixture='hidden-reference', mode='render', role=role, pair=None, iterations=0))
    require(len(rows) == 18, 'run roster mismatch')
    return rows


def verify_supervisor(path, command, stdout, stderr):
    record = read_json(path)
    require(record['status'] == 'exited' and type(record['returncode']) is int and record['returncode'] == 0, 'supervised browser did not exit successfully')
    require(record['command'] == command and record['timeout_seconds'] == 120 and record['output_limit_bytes'] == LIMIT, 'supervisor command/bounds mismatch')
    cleanup = record['cleanup']
    require(set(cleanup) == {'complete', 'reaped', 'descendants', 'checker_returncode', 'error'}, 'cleanup schema mismatch')
    require(cleanup['complete'] is True and cleanup['error'] is None and type(cleanup['checker_returncode']) is int and cleanup['checker_returncode'] == 0, 'incomplete cleanup')
    require(type(cleanup['descendants']) is int and cleanup['descendants'] == 0, 'surviving descendants')
    require(type(cleanup['reaped']) is int and cleanup['reaped'] == 1, 'unexpected cleanup reap count')
    require(record['cancellation_signal'] is None and record['error'] is None, 'supervisor cancellation/error')
    require(record['capture_gate_required'] is False and record['capture_gate_granted'] is False, 'unexpected GPU gate')
    require(type(record['captured_bytes']) is int and type(record['observed_bytes']) is int, 'output counters must be integers')
    require(record['captured_bytes'] == record['observed_bytes'] == len(stdout) + len(stderr) <= LIMIT, 'output lost or truncated')
    require(record['stdout_sha256'] == digest(stdout) and record['stderr_sha256'] == digest(stderr), 'raw output hash mismatch')
    require(finite(record['elapsed_seconds']) and record['cleanup_seconds'] == 5.0, 'supervisor timing metadata')
    return record


def execute(row, pins, env, out, decoder):
    directory = out / row['id']
    directory.mkdir()
    binary = pins[row['role']]['records']['binary']
    verify(binary)
    fixture = P / 'fixtures' / (row['fixture'] + '.html')
    fixture_pin = next(p for p in pins['proposal_inputs'] if p['path'] == str(fixture))
    verify(fixture_pin)
    image = directory / 'render.png'
    mode = ['--render'] if row['mode'] == 'render' else [('--benchmark' if row['mode'] == 'direct' else '--benchmark-worker'), str(row['iterations'])]
    command = [binary['path'], str(fixture), *mode, '--width', '1180', '--height', '880', '--output', str(image)]
    receipt = directory / 'supervisor.json'
    supervisor = W / 'tools/vulkan-raster-probe/bridge_supervisor.py'
    launch = [sys.executable, '-I', '-B', str(supervisor), '--timeout', '120', '--output-limit', str(LIMIT), '--result', str(receipt), '--', *command]
    write_json(directory / 'invocation.json', dict(row=row, command=command, supervisor_command=launch))
    process = subprocess.Popen(launch, cwd=W, env=env, stdin=subprocess.DEVNULL,
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE, start_new_session=True)
    outer = dict(command=launch, timeout_seconds=140, status='pending')
    try:
        wrapper_stdout, wrapper_stderr = process.communicate(timeout=140)
        outer.update(status='exited', returncode=process.returncode)
    except (subprocess.TimeoutExpired, KeyboardInterrupt):
        # Signal only our still-owned supervisor. Its pinned handler performs
        # descendant cleanup; never claim cleanup if it fails to report it.
        process.send_signal(signal.SIGTERM)
        try:
            wrapper_stdout, wrapper_stderr = process.communicate(timeout=15)
            outer.update(status='cancelled', returncode=process.returncode)
        except subprocess.TimeoutExpired:
            process.kill()
            wrapper_stdout, wrapper_stderr = process.communicate()
            outer.update(status='unresolved_supervisor_cleanup', returncode=process.returncode)
    (directory / 'wrapper.stdout.log').write_bytes(wrapper_stdout)
    (directory / 'wrapper.stderr.log').write_bytes(wrapper_stderr)
    write_json(directory / 'wrapper.json', outer)
    require(outer['status'] == 'exited' and outer['returncode'] == 0, 'outer supervisor failed; retain receipts and stop')
    require(not wrapper_stdout and not wrapper_stderr, 'unexpected supervisor diagnostics')
    stdout = regular(receipt.with_suffix('.stdout.log')).read_bytes()
    stderr = regular(receipt.with_suffix('.stderr.log')).read_bytes()
    record = verify_supervisor(receipt, command, stdout, stderr)
    text = stdout.decode('utf-8', errors='strict')
    errors = stderr.decode('utf-8', errors='strict').splitlines()
    if row['mode'] == 'worker':
        require(all(line.startswith(('[page] Page process ', '[page] Resource broker ')) for line in errors), 'unexpected worker diagnostic')
        data = json.loads(text, object_pairs_hook=no_duplicates, parse_constant=lambda value: (_ for _ in ()).throw(ValueError(value)))
        validate_worker(data, row['iterations'])
        timings = dict(cold={key: data[key] for key in PHASES}, warm={key: summarize([s[key] for s in data['warm_samples']]) for key in WARM})
        counts = dict(nodes=data['nodes'], commands=data['commands'])
    else:
        require(not errors, 'unexpected direct diagnostic')
        lines = text.splitlines()
        require(len(lines) == (2 if row['mode'] == 'direct' else 1), 'unexpected direct output lines')
        rendered = re.fullmatch(r'Rendered .+ → .+ \(1180×880, ([0-9]+) nodes, ([0-9]+) commands, ([0-9.]+) ms total\)', lines[0])
        require(rendered is not None, 'missing direct render summary')
        counts = dict(nodes=int(rendered[1]), commands=int(rendered[2]))
        require(0 < counts['nodes'] <= 100000 and 0 < counts['commands'] <= 200000 and finite(float(rendered[3])), 'invalid direct counts/timing')
        data = None
        timings = None
        if row['mode'] == 'direct':
            match = re.fullmatch(r'Benchmark: 100 iterations; style\+layout\+paint median ([0-9.]+) ms, p95 ([0-9.]+) ms \(warm glyph cache; excludes network, parse, scripts, PNG encoding; no Chromium comparison\)', lines[1])
            require(match is not None and all(finite(float(v)) for v in match.groups()), 'invalid direct benchmark summary')
            timings = dict(median_ms=float(match[1]), p95_ms=float(match[2]), samples=100, rounded_summary_only=True)
    width, height, rgba = decoder(image)
    require([width, height] == VIEWPORT and len(rgba) == width * height * 4, 'pixel dimensions/length')
    pixel_sha = digest(rgba)
    require(pixel_sha == PIXELS[row['fixture'], row['role']], 'exact pixel oracle mismatch')
    verify(binary)
    verify(fixture_pin)
    result = dict(**row, command=command, counts=counts, timings=timings, raw_worker=data,
                  diagnostics=errors, rgba_sha256=pixel_sha, image=binding(image),
                  supervisor=binding(receipt), stdout=binding(receipt.with_suffix('.stdout.log')),
                  stderr=binding(receipt.with_suffix('.stderr.log')), supervisor_elapsed_seconds=record['elapsed_seconds'])
    write_json(directory / 'validated.json', result)
    return result


def comparisons(rows):
    pairs = []
    for mode in ('direct', 'worker'):
        for pair in (1, 2, 3):
            found = {row['role']: row for row in rows if row['mode'] == mode and row['pair'] == pair}
            require(set(found) == {'parent', 'candidate'}, 'missing performance pair')
            require(found['parent']['counts'] == found['candidate']['counts'], 'all-visible geometry/counts changed')
            measures = []
            keys = ('median_ms', 'p95_ms') if mode == 'direct' else WARM
            for key in keys:
                if mode == 'direct':
                    before, after = (found[r]['timings'][key] for r in ('parent', 'candidate'))
                    measures.append(dict(phase=key, parent_ms=before, candidate_ms=after, delta_ms=after-before, ratio=None if before == 0 else after/before))
                else:
                    for statistic in ('median_ms', 'p95_ms'):
                        before, after = (found[r]['timings']['warm'][key][statistic] for r in ('parent', 'candidate'))
                        measures.append(dict(phase=key, statistic=statistic, parent_ms=before, candidate_ms=after, delta_ms=after-before, ratio=None if before == 0 else after/before))
            pairs.append(dict(mode=mode, pair=pair, measurements=measures))
    pooled = {role: {key: summarize([sample[key] for row in rows if row['role'] == role and row['mode'] == 'worker' and row['fixture'] == 'all-visible-dense' for sample in row['raw_worker']['warm_samples']]) for key in WARM} for role in ('parent', 'candidate')}
    return dict(pairs=pairs, pooled_worker=pooled,
                qualification='Local descriptive measurements; no speed threshold or cross-engine/hardware/security claim. Direct values are rounded process summaries, never pooled as individual timing samples. Hidden paint reduction is changed behavior, not universal speedup.')


def fresh_output(path):
    require(path.is_absolute() and path.parent == N and path.name.startswith('measurement-results-'), 'output must be a fresh direct N/measurement-results-* child')
    for parent in reversed(path.parent.parents):
        require(stat.S_ISDIR(parent.lstat().st_mode), 'symlink/non-directory output ancestor')
    require(stat.S_ISDIR(path.parent.lstat().st_mode), 'unsafe output parent')
    require(not path.exists() and not path.is_symlink(), 'output directory already exists')
    path.mkdir()
    require(stat.S_ISDIR(path.lstat().st_mode), 'output creation failed')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--parent-sidecar', type=Path, default=N / 'binaries/parent-browser.json')
    parser.add_argument('--candidate-sidecar', type=Path, default=N / 'binaries/candidate-browser.json')
    parser.add_argument('--candidate-inventory', type=Path, default=N / 'source-candidate-3.json')
    parser.add_argument('--output-dir', type=Path, required=True)
    args = parser.parse_args()
    require(sys.flags.isolated == 1, 'launch this runner with python3 -I')
    sys.dont_write_bytecode = True
    fresh_output(args.output_dir)
    report = dict(schema=1, status='failed', proposal_sha256=PROPOSAL_SHA, attempts=[], scope='18-process visibility differential; CPU/direct and confined software paint only')
    try:
        pins = inputs(args)
        require(pins['parent']['environment']['rustc'] == pins['candidate']['environment']['rustc'], 'different compiler identities')
        env = sanitized_environment()
        write_json(args.output_dir / 'inputs.json', dict(bindings=pins, environment=env, python=sys.version, platform=platform.platform(), cpuinfo_sha256=digest(Path('/proc/cpuinfo').read_bytes()), run_roster=run_spec()))
        decoder = load_decoder()
        for row in run_spec():
            report['active_attempt'] = row
            report['attempts'].append(execute(row, pins, env, args.output_dir, decoder))
        require(inputs(args) == pins, 'bound input changed during measurement')
        require(len(report['attempts']) == 18, 'incomplete attempt roster')
        report.pop('active_attempt', None)
        report.update(status='passed', inputs=binding(args.output_dir / 'inputs.json'), summary=comparisons(report['attempts']),
                      chromium_comparison=False, controlled_environment=False, hardware_validation=False,
                      source_inventory_scope=pins['candidate']['source_scope'])
    except (OSError, ValueError, KeyError, TypeError, ImportError) as error:
        report['error'] = f'{type(error).__name__}: {error}'
    finally:
        write_json(args.output_dir / 'result.json', report)
    print(json.dumps(dict(status=report['status'], attempts_completed=len(report['attempts']), result=str(args.output_dir / 'result.json'))))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
