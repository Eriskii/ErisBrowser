from pathlib import Path
import json,hashlib,re,collections,math,struct,zlib,binascii,ast
N=Path('/tmp/eris-visibility-plan-1'); H=N/'validation-review-1'; W=N/'worktree'
EXPECTED='1c4ecff753c6b9fdc6b1711d4f25c73f7ad557f57529ae0d2551ebb4653cf8eb'
def load(p):return json.loads(Path(p).read_bytes())
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
seen={}
def verify(r):
 p=Path(r['path']);v=bound(p);assert all(v[k]==r[k] for k in ('path','bytes','sha256')),(r,v);seen[str(p)]=v;return p
def walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=set(v) and isinstance(v['path'],str) and v['path'].startswith('/'):verify(v)
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
ledger_path=N/'root/final-validation.json';assert bound(ledger_path)['sha256']==EXPECTED
D=load(ledger_path);walk(D)
assert D['status']=='pass' and D['base']=='18d3648ce4435b0d703e3b41fccc2f9f2fae156e'
parent=load(N/'source-parent.json');candidate=load(verify(D['source_inventory']))
pm={r['path']:r for r in parent['files']};cm={r['path']:r for r in candidate['files']}
assert len(pm)==15297 and len(cm)==len(candidate['files'])==D['selected_inputs']==15307 and not(pm.keys()-cm.keys())
changes=[cm[p] for p in sorted(cm) if pm.get(p)!=cm[p]]
snap=load(verify(D['source_snapshots']));assert snap==dict(root=str(N/'candidate-source-3'),files=changes)
assert len(changes)==D['changed_source_paths']==35
for r in cm.values():assert dict(bound(W/r['path']),path=r['path'])==r
for r in changes:assert dict(bound(N/'candidate-source-3'/r['path']),path=r['path'])==r
# All source peers must bind their selected scopes; later composition closes candidate1.
for r in D['source_reviews']:
 obj=load(verify(r));assert obj['status']=='clear';walk(obj)
add=load(N/'composition-review-1/candidate3-addendum.json');assert add['candidate3']==D['source_inventory']
rows={r['label']:r for r in D['attempts']};assert len(rows)==len(D['attempts'])==24
actual_attempts=[]
for p in sorted((N/'validation').glob('*.json')):
 receipt=load(p)
 if 'command' not in receipt:continue
 actual_attempts.append(p.stem);entry=rows[p.stem];assert entry['receipt']==bound(p)
 text=verify(entry['log']).read_text();assert sha(text.encode())==receipt['sha256']
 for k in ('command','exit','elapsed_seconds'):assert entry[k]==receipt[k]
 suites=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)
 if suites:assert entry['tests']==dict(suites=len(suites),passed=sum(int(x[1]) for x in suites),failed=sum(int(x[2]) for x in suites),ignored=sum(int(x[3]) for x in suites))
 assert entry['accepted']==(p.stem in D['accepted_labels'])
assert actual_attempts==list(rows)
assert all(rows[k]['exit']==0 for k in D['accepted_labels'])
commands={
 'candidate-full-msrv-2':['cargo','+1.88.0','test','--locked','--offline','--all-targets','--','--include-ignored'],
 'candidate-full-host-vulkan-1':['cargo','+1.99.0','test','--locked','--offline','--features','test262-host,vulkan-raster','--all-targets','--','--include-ignored'],
 'candidate-clippy-msrv-1':['cargo','+1.88.0','clippy','--locked','--offline','--all-targets','--','-D','warnings'],
 'candidate-clippy-host-vulkan-1':['cargo','+1.99.0','clippy','--locked','--offline','--features','test262-host,vulkan-raster','--all-targets','--','-D','warnings'],
 'candidate-release-browser-1':['cargo','+1.88.0','build','--locked','--offline','--release','--bin','eris-browser'],
 'fmt-check-final-1':['env','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.88.0','fmt','--all','--','--check'],
}
for label,command in commands.items():assert rows[label]['command']==command,label
new_source=[]
for name in sorted(cm.keys()-pm.keys()):
 if name.endswith('.rs'):
  new_source.extend(re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn (\w+)\(', (W/name).read_text()))
assert len(new_source)==len(set(new_source))==36
rosters=[]
for transition in D['test_roster_transitions']:
 label=transition['label'];current_log=verify(rows[label]['log']);prior_log=verify(transition['parent_log']);prior_receipt=load(verify(transition['parent_receipt']))
 assert prior_receipt['exit']==0 and prior_receipt['sha256']==bound(prior_log)['sha256']
 prior=collections.Counter(re.findall(r'^test (\S+) \.\.\. ok$',prior_log.read_text(),re.M));current=collections.Counter(re.findall(r'^test (\S+) \.\.\. ok$',current_log.read_text(),re.M))
 added=current-prior;assert not(prior-current) and sum(added.values())==36
 assert sorted(added)==transition['added'] and not transition['removed']
 assert sorted(x.rsplit('::',1)[-1] for x in added)==sorted(new_source)
 assert sum(current.values())==transition['current_passed']==rows[label]['tests']['passed']
 assert rows[label]['tests']==dict(suites=58,passed=3521 if 'msrv' in label else 3885,failed=0,ignored=0)
 rosters.append(dict(label=label,prior=sum(prior.values()),current=sum(current.values()),added=36,removed=0,suites=58))
# Actual type measurements, not estimated struct widths.
for r in D['storage_measurements']:
 probe=load(verify(r['receipt']));assert probe['exit']==0
 text=verify(r['log']).read_text();assert sha(text.encode())==probe['sha256']
 m=re.findall(r'actual_layout_storage PaintOwner=(\d+) LayoutResult=(\d+) ComputedStyle=(\d+)',text);assert len(m)==1
 measured=dict(zip(('PaintOwner','LayoutResult','ComputedStyle'),map(int,m[0])));assert measured==r['observed']==D['storage'][r['role']]
# Sidecar build/source provenance and copied-binary equality.
sidecars={}
for r in D['binary_sidecars']:
 path=verify(r);role=path.name.split('-')[0];s=load(path);walk(s);sidecars[role]=s
 assert s['source_inventory']==bound(N/('source-parent.json' if role=='parent' else 'source-candidate-3.json'))
 build=load(s['build']['path']);env=load(s['environment']['path']);assert build['exit']==0 and build['command']==commands['candidate-release-browser-1']
 log=Path(s['build']['path']).parent/build['log'];assert bound(log)['sha256']==build['sha256']
 assert env['toolchain']=='1.88.0' and env['features']==[] and 'host: x86_64-unknown-linux-gnu\n' in env['rustc']
 if role=='candidate':
  actual=bound(Path(env['target_dir'])/'release/eris-browser');assert actual['sha256']==s['binary']['sha256'] and actual['bytes']==s['binary']['bytes']
assert sidecars['parent']['binary']['sha256']=='983205612603ae8a7d6e197ef2085a993536340351824954c948cc32a4640d85'
# Independent stdlib artifact decoder; no import/execution of project helpers.
cache={}
def png_hash(path):
 b=Path(path).read_bytes();bh=sha(b)
 if bh in cache:return cache[bh]
 assert b[:8]==b'\x89PNG\r\n\x1a\n';at=8;payload=bytearray();wh=None;ended=False
 while at<len(b):
  size=struct.unpack_from('>I',b,at)[0];kind=b[at+4:at+8];data=b[at+8:at+8+size];assert len(data)==size
  crc=struct.unpack_from('>I',b,at+8+size)[0];assert binascii.crc32(kind+data)&0xffffffff==crc
  if kind==b'IHDR':
   assert wh is None;wi,he,depth,color,comp,filt,interlace=struct.unpack('>IIBBBBB',data);assert depth==8 and color in (2,6) and (comp,filt,interlace)==(0,0,0) and 0<wi*he<=1180*880;wh=(wi,he);channels=3 if color==2 else 4
  elif kind==b'IDAT':payload.extend(data)
  elif kind==b'IEND':ended=True;break
  at+=size+12
 assert ended and wh
 stride=wi*channels;decoder=zlib.decompressobj();raw=decoder.decompress(payload,he*(stride+1)+1);assert decoder.eof and len(raw)==he*(stride+1)
 prior=bytearray(stride);output=bytearray();at=0
 for y in range(he):
  kind=raw[at];line=bytearray(raw[at+1:at+1+stride]);at+=stride+1;assert kind in range(5)
  if kind:
   for x in range(stride):
    left=line[x-channels] if x>=channels else 0;up=prior[x];corner=prior[x-channels] if x>=channels else 0
    if kind==1:prediction=left
    elif kind==2:prediction=up
    elif kind==3:prediction=(left+up)//2
    else:
     p=left+up-corner;dist=(abs(p-left),abs(p-up),abs(p-corner));prediction=(left,up,corner)[dist.index(min(dist))]
    line[x]=(line[x]+prediction)&255
  if channels==4:output.extend(line)
  else:
   for x in range(0,stride,3):output.extend(line[x:x+3]);output.append(255)
  prior=line
 cache[bh]=(wi,he,sha(output));return cache[bh]
manifest=load(W/'tests/reftests/manifest.json');names=[x['name'] for x in manifest['cases']];assert len(names)==102
reports={}
for r in D['visual_references']:
 p=verify(r);role='parent' if p.parent.name.startswith('parent') else 'candidate';v=load(p);reports[role]=v
 assert v['binary']==sidecars[role]['binary']['path'] and (v['passed'],v['failed'],v['total'])==(102,0,102)
 assert v['viewport']==dict(width=320,height=240) and v['conformance_claim'] is False
 assert [x['name'] for x in v['cases']]==names
 assert all(x['status']=='pass' and x['different_pixels']==x['maximum_channel_error']==0 for x in v['cases'])
 receipt=rows[role+'-reftests-1'];assert '--binary' in receipt['command'] and v['binary'] in receipt['command']
 assert load(receipt['log']['path'])==v
comparison=load(verify(D['visual_parent_candidate_comparison']));assert comparison['status']=='pass' and comparison['pairs']==102 and comparison['images_compared']==204
assert [x['name'] for x in comparison['cases']]==names;walk(comparison)
for i,row in enumerate(comparison['cases']):
 assert [x['kind'] for x in row['images']]==['test_image','reference_image']
 hashes=[]
 for image in row['images']:
  for role in ('parent','candidate'):assert image[role]['path']==reports[role]['cases'][i][image['kind']]
  p=verify(image['parent']);c=verify(image['candidate']);assert p.read_bytes()==c.read_bytes()
  assert png_hash(p)==(320,240,image['rgba_sha256']);hashes.append(image['rgba_sha256'])
 assert hashes[0]==hashes[1]
# Measurement raw rows and independently recomputed paired summaries.
M=load(verify(D['measurement']['result']));I=load(verify(D['measurement']['inputs']));walk(I)
assert M['status']=='passed' and len(M['attempts'])==18 and D['measurement']['summary']==M['summary']
assert I['environment']['TZ']=='UTC0' and not any(k.startswith(('LD_','PYTHON','http_proxy','https_proxy')) for k in I['environment'])
assert I['bindings']['runner']['path']==str(N/'measurement-runner-2/run.py')
assert I['bindings']['candidate']['records']['source_inventory']==D['source_inventory']
for role in ('parent','candidate'):assert I['bindings'][role]['sidecar']==bound(N/'binaries'/f'{role}-browser.json')
expected=[]
for mode in ('direct','worker'):
 for pair,roles in enumerate((('parent','candidate'),('candidate','parent'),('parent','candidate')),1):
  for role in roles:expected.append(dict(id=f'{mode}-dense-{pair}-{role}',fixture='all-visible-dense',mode=mode,role=role,pair=pair,iterations=100))
for role in ('parent','candidate'):
 expected += [dict(id=f'hidden-direct-{role}',fixture='hidden-override',mode='render',role=role,pair=None,iterations=0),dict(id=f'hidden-worker-{role}',fixture='hidden-override',mode='worker',role=role,pair=None,iterations=1),dict(id=f'reference-direct-{role}',fixture='hidden-reference',mode='render',role=role,pair=None,iterations=0)]
assert I['run_roster']==expected
pixels=load(N/'measurement-proposal-1/pixel-contract.json')['cases'];WARM=('render_exchange_ms','clear_paint_ms','total_ms');PHASES=('startup_ms','load_ms','cold_render_exchange_ms','cold_clear_paint_ms','teardown_ms')
def stats(values):
 s=sorted(values);return dict(samples=len(s),median_ms=s[len(s)//2],p95_ms=s[math.ceil(len(s)*.95)-1])
def finite(x):return type(x) in (float,int) and math.isfinite(x) and x>=0
for exp,row in zip(expected,M['attempts']):
 assert {k:row[k] for k in exp}==exp
 path=Path(row['supervisor']['path']).parent
 assert load(path/'validated.json')==row
 invocation=load(path/'invocation.json');assert invocation['row']==exp and invocation['command']==row['command']
 wrapper=load(path/'wrapper.json');assert wrapper['status']=='exited' and wrapper['returncode']==0 and wrapper['command']==invocation['supervisor_command']
 assert (path/'wrapper.stdout.log').read_bytes()==(path/'wrapper.stderr.log').read_bytes()==b''
 walk(row);s=load(row['supervisor']['path']);o=Path(row['stdout']['path']).read_bytes();e=Path(row['stderr']['path']).read_bytes()
 assert s['status']=='exited' and type(s['returncode']) is int and s['returncode']==0 and s['command']==row['command']
 assert s['cleanup']==dict(complete=True,reaped=1,descendants=0,checker_returncode=0,error=None)
 assert s['captured_bytes']==s['observed_bytes']==len(o)+len(e)<=1048576 and s['stdout_sha256']==sha(o) and s['stderr_sha256']==sha(e)
 assert s['timeout_seconds']==120 and s['cleanup_seconds']==5 and s['output_limit_bytes']==1048576
 assert s['error'] is None and s['cancellation_signal'] is None and s['capture_gate_required'] is s['capture_gate_granted'] is False
 assert s['elapsed_seconds']==row['supervisor_elapsed_seconds']
 oracle=pixels[exp['fixture']];oracle=oracle.get(exp['role'],oracle.get('both'))
 assert row['rgba_sha256']==oracle['rgba_sha256'] and png_hash(row['image']['path'])==(1180,880,oracle['rgba_sha256'])
 assert row['command'][0]==sidecars[exp['role']]['binary']['path']
 if exp['mode']=='worker':
  raw=json.loads(o);assert raw==row['raw_worker'];assert raw['schema']==1 and raw['viewport']==[1180,880] and raw['scripts'] is True and raw['iterations']==exp['iterations']
  assert set(raw)=={'schema','viewport','scripts','iterations','nodes','commands','warm_samples',*PHASES}
  assert len(raw['warm_samples'])==exp['iterations'];assert all(finite(raw[k]) for k in PHASES)
  for sample in raw['warm_samples']:assert set(sample)==set(WARM) and all(finite(v) for v in sample.values()) and sample['total_ms']+.000002>=sample['render_exchange_ms']+sample['clear_paint_ms']
  assert row['timings']==dict(cold={k:raw[k] for k in PHASES},warm={k:stats([x[k] for x in raw['warm_samples']]) for k in WARM})
  assert row['counts']=={k:raw[k] for k in ('nodes','commands')}
  assert row['diagnostics']==e.decode().splitlines() and all(line.startswith(('[page] Page process ','[page] Resource broker ')) for line in row['diagnostics'])
 else:
  assert not e and row['raw_worker'] is None and not row['diagnostics'];lines=o.decode().splitlines()
  assert len(lines)==(2 if exp['mode']=='direct' else 1)
  counts=re.search(r'\(1180×880, (\d+) nodes, (\d+) commands, ([0-9.]+) ms total\)',lines[0]);assert counts
  assert row['counts']==dict(nodes=int(counts[1]),commands=int(counts[2]))
  if exp['mode']=='direct':
   values=re.search(r'Benchmark: 100 iterations; style\+layout\+paint median ([0-9.]+) ms, p95 ([0-9.]+) ms',lines[1]);assert values
   assert row['timings']==dict(median_ms=float(values[1]),p95_ms=float(values[2]),samples=100,rounded_summary_only=True)
  else:assert row['timings'] is None
pairs=[]
for mode in ('direct','worker'):
 for pair in (1,2,3):
  group={r['role']:r for r in M['attempts'] if r['mode']==mode and r['pair']==pair};assert group['parent']['counts']==group['candidate']['counts']
  measures=[]
  for key in (('median_ms','p95_ms') if mode=='direct' else WARM):
   for statistic in ((None,) if mode=='direct' else ('median_ms','p95_ms')):
    left,right=[group[role]['timings'][key] if mode=='direct' else group[role]['timings']['warm'][key][statistic] for role in ('parent','candidate')]
    x=dict(phase=key,parent_ms=left,candidate_ms=right,delta_ms=right-left,ratio=None if left==0 else right/left)
    if statistic:x['statistic']=statistic
    measures.append(x)
  pairs.append(dict(mode=mode,pair=pair,measurements=measures))
assert M['summary']['pairs']==pairs
pooled={role:{k:stats([s[k] for r in M['attempts'] if r['role']==role and r['mode']=='worker' and r['fixture']=='all-visible-dense' for s in r['raw_worker']['warm_samples']]) for k in WARM} for role in ('parent','candidate')}
assert M['summary']['pooled_worker']==pooled and all(M[k] is False for k in ('chromium_comparison','controlled_environment','hardware_validation'))
# Retain actual failed timezone attempt as an earlier failure, never a sample.
failure=load(N/'measurement-results-1/result.json');assert failure['status']=='failed' and failure['attempts']==[]
f=load(N/'measurement-results-1/direct-dense-1-parent/supervisor.json');assert f['returncode']==1 and f['cleanup']==dict(complete=True,reaped=1,descendants=0,checker_returncode=1,error=None)
assert (N/'measurement-results-1/direct-dense-1-parent/supervisor.stderr.log').read_bytes()==b'eris-browser: host timezone Unavailable\n'
result=dict(schema=1,status='clear',ledger=bound(ledger_path),assembler=bound(N/'root/assemble-validation.py'),selected_files=15307,changed_paths=35,new_paths=10,attempt_receipts=24,rosters=rosters,new_groups=36,source_reviews=len(D['source_reviews']),visual=dict(pairs_per_binary=102,exact_parent_image_comparisons=204,decoded_unique_png_byte_hashes=len(cache)),measurement=dict(processes=18,cleanup_complete=18,unexpected_descendants=0,pixel_matches=18,worker_dense_samples_per_role=300,pairs=6,pooled=pooled),binary_sidecars=D['binary_sidecars'],storage=D['storage'],failure_summary_qualification=bound(H/'failed-summary-qualification.json'),bound_artifacts_checked=len(seen),project_execution=False,project_imports=False,live_edits=False)
with (H/'actual-artifact-checks.json').open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps(result,indent=2))
