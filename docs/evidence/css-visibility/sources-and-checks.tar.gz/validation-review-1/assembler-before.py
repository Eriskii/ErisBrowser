from pathlib import Path
import hashlib,json,re,subprocess
n=Path(__file__).resolve().parents[1];w=n/'worktree'
def load(p):return json.loads(p.read_bytes())
def bound(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
inventory_path=n/'source-candidate-3.json';inventory=load(inventory_path)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==inventory['base']
for row in inventory['files']:assert dict(bound(w/row['path']),path=row['path'])==row
snapshot=load(n/'root/candidate-snapshots-3.json')
for row in snapshot['changed_paths']:
    assert dict(bound(n/'candidate-source-3'/row['path']),path=row['path'])==row
    assert (w/row['path']).read_bytes()==(n/'candidate-source-3'/row['path']).read_bytes()
accepted=['candidate-full-msrv-2','candidate-full-host-vulkan-1','candidate-clippy-msrv-1','candidate-clippy-host-vulkan-1','fmt-check-final-1','candidate-release-browser-1','candidate-reftests-1']
attempts=[]
for p in sorted((n/'validation').glob('*.json')):
    r=load(p)
    if 'command' not in r:continue
    log=p.parent/r['log'];assert bound(log)['sha256']==r['sha256']
    text=log.read_text();suites=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    item=dict(label=p.stem,receipt=bound(p),log=bound(log),command=r['command'],exit=r['exit'],elapsed_seconds=r['elapsed_seconds'],accepted=p.stem in accepted)
    if suites:item['tests']=dict(suites=len(suites),passed=sum(int(s[1]) for s in suites),failed=sum(int(s[2]) for s in suites),ignored=sum(int(s[3]) for s in suites))
    environment=p.with_name(p.stem+'-environment.json')
    if environment.exists():item['environment']=bound(environment)
    attempts.append(item)
by_name={r['label']:r for r in attempts}
assert all(by_name[label]['exit']==0 for label in accepted)
for label,count in [('candidate-full-msrv-2',3521),('candidate-full-host-vulkan-1',3885)]:
    tests=by_name[label]['tests'];assert tests['passed']==count and tests['failed']==0 and tests['ignored']==0,tests
    text=Path(by_name[label]['log']['path']).read_text()
    for name in ['visibility_dynamic_hiding_preserves_space_and_visible_child_event_bubbling','visibility_dynamic::confined_visibility_dynamic_hiding_preserves_space_and_visible_child_event_bubbling']:
        assert 'test '+name+' ... ok' in text
reviews=['css-review-1/review.json','layout-review-1/review.json','browser-review-1/review.json','controls-review-1/review.json','dynamic-controls-review-1/review.json','composition-review-1/review.json']
record=dict(status='pass',checkpoint='css-visibility',base=inventory['base'],source_inventory=bound(inventory_path),source_snapshots=bound(n/'root/source-snapshots-final.json'),selected_inputs=len(inventory['files']),changed_source_paths=len(snapshot['changed_paths']),accepted_labels=accepted,attempts=attempts,source_reviews=[bound(n/p) for p in reviews],new_coverage=dict(semantic_css=6,pixel_and_cssom=16,native_focus=3,codec=4,dynamic_direct_and_confined=2,resource_boundaries=5),storage=dict(parent=dict(ComputedStyle=1032,PaintOwner=16,LayoutResult=56),candidate=dict(ComputedStyle=1032,PaintOwner=24,LayoutResult=80),wire_bytes='4 + DOM node count; at most100004',qualification='Actual Rust1.88 types on this host; capacity/allocator overhead is additional. One owner roster at200000 logical records adds1600000 payload bytes; not a peak-allocation bound.'),retained_failures=[dict(label='parent-visibility-integration-1',reason='16 frozen integration groups compiled then failed because visibility was unsupported.'),dict(label='parent-visibility-dynamic-1',reason='Published renderer painted hidden red pixels.'),dict(label='parent-confined-visibility-dynamic-1',reason='Published confined renderer painted hidden red pixels.'),dict(label='candidate-full-msrv-1',reason='Four historical all-property controls had stale cardinality/accounting literals; eight network/confinement preflights met outer sandbox localhost EPERM. Exact fixture migration preserves256records/64KiB limits; full suites rerun with authorized escalation.')],qualification='Visible/hidden subset only; collapse deferred. Table row-layer policy follows a draft with recorded interoperability disagreement. CPU packed native-plan controls do not claim new hardware GPU execution. No full compatibility, security certification or Chromium performance claim.')
for label in ['parent-reftests-1','candidate-reftests-1']:
    record.setdefault('visual_references',[]).append(bound(n/label/'report.json'))
with (n/'root/final-validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(bound(n/'root/final-validation.json'))
