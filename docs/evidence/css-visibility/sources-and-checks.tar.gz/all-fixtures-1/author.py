"""Author a source-only historical fixture correction; never import project code."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

N = Path('/tmp/eris-visibility-plan-1')
OUT = N / 'all-fixtures-1'
REPO = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE = '18d3648ce4435b0d703e3b41fccc2f9f2fae156e'

def git(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=REPO)

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save_json(name, value):
    path = OUT / name
    path.write_text(json.dumps(value, indent=2) + '\n')
    return binding(path)

def roster(data):
    body = data.decode().split('const SUPPORTED_PROPERTIES: &[&str] = &[', 1)[1].split('];', 1)[0]
    return re.findall(r'"([^"\n]+)"', body)

old_names = roster(git('src/css.rs'))
new_names = roster((N / 'candidate-source-1/src/css.rs').read_bytes())
assert len(old_names) == 86 and sum(map(len, old_names)) == 1049
assert new_names == old_names[:1] + ['visibility'] + old_names[1:]
assert len(new_names) == 87 and sum(map(len, new_names)) == 1059
assert new_names[0] == 'display' and new_names[20] == 'border-spacing' and new_names[-1] == 'vertical-align'
pending = 'var(--x,' + '0' * 728 + ')'
assert len(pending) == 737
all_logical = sum(len(name) + len(pending) + 4 for name in new_names)
filler = 'x'
assert all_logical == 65526
assert all_logical + len('--pad') + len(filler) + 4 == 65536
assert all_logical + len('--pad') + len(filler + 'x') + 4 == 65537
assert 169 + len(new_names) == 256 and 170 + len(new_names) == 257

changes = {
    'src/css/pending_inline_budget_tests.rs': [
        ('("all", 86)', '("all", 87)'),
    ],
    'src/cssom/pending_record_tests.rs': [
        ('assert_eq!(style.len(), 87);', 'assert_eq!(style.len(), 88);'),
        ('assert_eq!(style.item(20), "border-spacing");', 'assert_eq!(style.item(21), "border-spacing");'),
        ('assert_eq!(style.item(86), "vertical-align");', 'assert_eq!(style.item(87), "vertical-align");'),
        ('assert_eq!(style.item(87), "");', 'assert_eq!(style.item(88), "");'),
        ('for custom_count in [170, 171]', 'for custom_count in [169, 170]'),
        ('if custom_count == 170', 'if custom_count == 169'),
        ('// 86 target names total1049 bytes;86*(740+4)+1049=65033.\n    // --pad contributes5+494+4=503, giving exactly65536.',
         '// 87 target names total 1059 bytes; 87*(737+4)+1059=65526.\n    // --pad contributes 5+1+4=10, giving exactly 65536.'),
        ('"0".repeat(731)', '"0".repeat(728)'),
        ('assert_eq!(pending.len(), 740);', 'assert_eq!(pending.len(), 737);'),
        ('let filler = "x".repeat(494);', 'let filler = "x".repeat(1);'),
    ],
    'src/cssom/pending_record_accounting_tests.rs': [
        ('assert_eq!(style.declarations().len(), 87);', 'assert_eq!(style.declarations().len(), 88);'),
    ],
}
rows = []
chunk_rows = []
for name, replacements in changes.items():
    before = git(name)
    text = before.decode()
    counts = []
    for old, new in replacements:
        count = text.count(old)
        expected = 2 if old == 'assert_eq!(style.len(), 87);' else 1
        assert count == expected, (name, old, count)
        counts.append(count)
        text = text.replace(old, new)
    raw = text.encode()
    inverse = text
    for (old, new), count in reversed(list(zip(replacements, counts))):
        assert inverse.count(new) == count, (name, new)
        inverse = inverse.replace(new, old)
    assert inverse.encode() == before
    # No group rename, new group, or registration change.
    old_tests = re.findall(rb'#\[test\]\s*fn\s+(\w+)', before)
    new_tests = re.findall(rb'#\[test\]\s*fn\s+(\w+)', raw)
    assert old_tests == new_tests
    paths = {}
    for kind, data in [('before', before), ('raw', raw)]:
        path = OUT / kind / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
        paths[kind] = binding(path)
    for kind, left, right in [('diff', before, raw), ('inverse', raw, before)]:
        path = OUT / kind / (name + '.diff')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(''.join(difflib.unified_diff(left.decode().splitlines(True), right.decode().splitlines(True), fromfile='a/' + name, tofile='b/' + name)))
        paths[kind] = binding(path)
    rows.append({'path': name, **paths, 'all_test_names_preserved': [x.decode() for x in old_tests], 'exact_inverse': True})
    chunk_rows.append({'path': name, 'chunks': [{'before': a, 'after': b, 'occurrences': c} for (a, b), c in zip(replacements, counts)]})

chunks = save_json('chunks.json', chunk_rows)
logical = 1059 + 87 * (len('var(--a)') + 4) + len('--a') + len('initial') + 4
release = 1 + 88 + logical
summary = 1 + 264 * 88
assert (logical, release, summary, summary + logical + release) == (2117, 2206, 23233, 27556)
explanation = save_json('derivation.json', {
    'base': BASE,
    'derivation': 'Independent literal roster and integer arithmetic, with read-only Git and Python stdlib; no project execution or outcome-derived expected values.',
    'ordered_old_names': old_names, 'ordered_selected_names': new_names,
    'roster': {'old_longhands': 86, 'selected_longhands': 87, 'added': 'visibility', 'after': 'display', 'old_name_bytes': 1049, 'selected_name_bytes': 1059, 'custom_plus_all_records': 88, 'border_spacing_item': 21, 'vertical_align_item': 87, 'first_absent_item': 88},
    'record_cap': {'limit_unchanged': 256, 'exact_custom_count': 169, 'one_over_custom_count': 170, 'totals': [256, 257]},
    'logical_storage': {'limit_unchanged': 65536, 'token_prefix_suffix_bytes': 9, 'zero_count': 728, 'pending_token_bytes': 737, 'formula_all': '1059 + 87 * (737 + 4)', 'all_bytes': 65526, 'pad_name_bytes': 5, 'pad_token_bytes': 1, 'pad_punctuation_bytes': 4, 'total_exact': 65536, 'one_added_pad_byte': 65537, 'both_set_property_and_parse_refusals_retained': True, 'old_740_byte_payload_alone_now_exceeds_cap': 65787},
    'shared_all_small_fixture_accounting': {'records': 88, 'pending_records': 87, 'logical_bytes': logical, 'release_work': release, 'summary_work': summary, 'clone_work': summary + logical + release, 'names_work': 1150, 'these_derived_values_are_not_new_literal_assertions': True},
    'retained_heap': 'Existing typed capacity-based assertion is byte-exact. It iterates 87 shared pending references, includes the added visibility name allocation, and conservatively charges each reference. No guessed capacities or platform widths are introduced.',
    'preserved': ['256 records', '65536 logical bytes', '4096 single-value bytes', 'all non-all shorthand counts', 'margin traversal 87-work boundary', 'margin accounting 138/143/1338 and other cuts', 'transactional refusal assertions', 'all old test names and registration', 'production source and tariffs'],
    'selected_changed_groups': ['allocation_free_shorthand_count_matches_supported_literal_rosters', 'pending_record_all_expansion_uses_same256_record_cap', 'pending_record_logical_storage_exact64k_charges_each_shared_reference', 'pending_record_shared_all_payload_has_conservative_per_reference_retention'],
    'bindings': [binding(N / 'source-candidate-1.json'), binding(N / 'candidate-source-1/src/css.rs'), binding(N / 'candidate-source-1/src/cssom.rs')],
})
ready = save_json('source-ready.json', {'schema': 1, 'status': 'source-ready historical all-roster correction; unexecuted', 'base': BASE, 'paths': rows, 'chunks': chunks, 'derivation': explanation, 'author_script': binding(OUT / 'author.py'), 'changed_groups': 4, 'new_groups': 0, 'renames': 0, 'production_changes': 0, 'project_execution': False, 'live_edits': False})
print(json.dumps(ready))
