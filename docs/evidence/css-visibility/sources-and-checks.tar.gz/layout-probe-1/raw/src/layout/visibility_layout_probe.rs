//! Temporary inert layout measurement; not part of final product/tests.
use super::*;
use std::mem::{align_of, size_of};

#[allow(dead_code)]
struct ParentPaintOwner {
    node: NodeId,
    background: bool,
    // Explicit pending layer and phase, independent of command admission.
    inline_layer: InlineLayer,
    inline_prefix: f32,
    inline_sides: u8,
    background_image_index: u8,
}

#[allow(dead_code)]
struct ParentLayoutResult {
    commands: Vec<DrawCommand>,
    hit_regions: Vec<HitRegion>,
    content_height: f32,
}

fn reserved_capacity<T>(count: usize) -> usize {
    let mut values: Vec<T> = Vec::new();
    values.try_reserve_exact(count).unwrap();
    values.capacity()
}

#[test]
fn visibility_held_layout_sizes() {
    assert_eq!(size_of::<Visibility>(), 1);
    assert_eq!(Visibility::Visible as u8, 0);
    assert_eq!(Visibility::Hidden as u8, 1);
    eprintln!(
        "visibility_layout type=PaintOwner parent_size={} parent_align={} candidate_size={} candidate_align={}",
        size_of::<ParentPaintOwner>(), align_of::<ParentPaintOwner>(),
        size_of::<PaintOwner>(), align_of::<PaintOwner>()
    );
    eprintln!(
        "visibility_layout type=LayoutResult parent_size={} parent_align={} candidate_size={} candidate_align={}",
        size_of::<ParentLayoutResult>(), align_of::<ParentLayoutResult>(),
        size_of::<LayoutResult>(), align_of::<LayoutResult>()
    );
    eprintln!(
        "visibility_layout type=Visibility candidate_size={} candidate_align={} vec_size={} vec_align={}",
        size_of::<Visibility>(), align_of::<Visibility>(),
        size_of::<Vec<Visibility>>(), align_of::<Vec<Visibility>>()
    );
    for count in [4, 8] {
        eprintln!(
            "visibility_layout reserve=PaintOwner count={} parent_capacity={} candidate_capacity={}",
            count, reserved_capacity::<ParentPaintOwner>(count),
            reserved_capacity::<PaintOwner>(count)
        );
    }
    for count in [0, 1, 4, crate::dom::MAX_NODES] {
        eprintln!(
            "visibility_layout reserve=Visibility count={} capacity={}",
            count, reserved_capacity::<Visibility>(count)
        );
    }
}
