from pathlib import Path
import hashlib,json,difflib,re
N=Path('/tmp/eris-visibility-plan-1'); O=N/'controls-1'; W=N/'worktree'
def put(path,data):
 p=O/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
def write(path,data):
 p=O/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def raw(s):
 n=1
 while '"'+'#'*n in s:n+=1
 return 'r'+'#'*n+'"'+s+'"'+'#'*n
css=json.loads((O/'css-cases.json').read_text());js=json.loads((O/'cssom-cases.json').read_text());pix=json.loads((O/'pixel-cases.json').read_text())
corrected=[]
for row in pix:
 if 'qualification' in row:
  old=row['html']; row['html']=old.replace('td{box-sizing:content-box;height:2px;', 'td{box-sizing:content-box;width:4px;height:2px;')
  assert row['html']!=old
  corrected.append({'id':row['id'],'before_sha256':hashlib.sha256(old.encode()).hexdigest(),'after_sha256':hashlib.sha256(row['html'].encode()).hexdigest(),'change':'Explicit 4px cell width; expected geometry and all other fields unchanged.'})
put('pixel-cases-2.json',pix)
put('literal-correction-1.json',{'status':'source-only fixture prerequisite clarification before conversion/execution','supersedes_only':'pixel-cases.json html in four table groups','original_seal':bind(O/'literal-ready.json'),'original':bind(O/'pixel-cases.json'),'replacement':bind(O/'pixel-cases-2.json'),'changes':corrected,'reason':'With automatic tracks the visible 2px child can change column minimums. Both selected columns are now explicitly 4px within 14px table width minus three 2px spacings. All numeric pixel/hit oracles remain unchanged.','no_producer_reads_or_project_execution':True})
put('literal-ready-2.json',{'status':'frozen selected literals before conversion','original':bind(O/'literal-ready.json'),'correction':bind(O/'literal-correction-1.json'),'files':[bind(O/x) for x in ['contract.json','css-cases.json','cssom-cases.json','pixel-cases-2.json']]})
unit='''//! Independent literal CSS visibility grammar, cascade and feature-query controls.
use super::*;

fn styles(html: &str, sheet: &str) -> (Document, Vec<ComputedStyle>) {
    let doc = Document::parse(html);
    let computed = compute_styles(&doc, &[sheet.to_owned()], 40.0, 32.0);
    (doc, computed)
}

fn assert_nodes(html: &str, sheet: &str, expected: &[(&str, Visibility)]) {
    let (doc, computed) = styles(html, sheet);
    assert_eq!(computed.len(), doc.nodes.len());
    for &(id, visibility) in expected {
        let node = doc.query_selector(&format!("#{id}")).unwrap();
        assert_eq!(computed[node].visibility, visibility, "{id}");
    }
}

'''
roster=[]
for row in css:
 unit+='#[test]\nfn '+row['id']+'() {\n'
 if row['kind']=='value_rows':
  unit+='    for (value, expected) in [\n'+''.join('        ('+raw(v)+', Visibility::'+e+'),\n' for v,e in row['rows'])+'    ] {\n'
  unit+='        let sheet = format!("main {{{}}} #target {{{}{value}}}", '+raw(row['parent'])+', '+raw(row['prefix'])+');\n'
  unit+='        assert_nodes("<main><i id=target></i></main>", &sheet, &[("target", expected)]);\n    }\n'
 else:
  if row['kind']=='supports':
   unit+='    for (property, value, expected) in [\n'+''.join('        ('+raw(p)+', '+raw(v)+', '+str(e).lower()+'),\n' for p,v,e in row['declarations'])+'    ] {\n        assert_eq!(supports_declaration(property, value), expected, "{property}: {value}");\n    }\n'
   unit+='    for (condition, expected) in [\n'+''.join('        ('+raw(q)+', '+str(e).lower()+'),\n' for q,e in row['conditions'])+'    ] {\n        assert_eq!(supports_matches(condition), expected, "{condition}");\n    }\n'
  unit+='    assert_nodes(\n        '+raw(row['html'])+',\n        '+raw(row['css'])+',\n        &[\n'+''.join('            ("'+i+'", Visibility::'+e+'),\n' for i,e in row['expected'])+'        ],\n    );\n'
 unit+='}\n\n'
 roster.append({'name':row['id'],'path':'src/css/visibility_tests.rs','literal_kind':'css','case_id':row['id']})
write('raw/src/css/visibility_tests.rs',unit)
public='''//! Source-derived visibility pixels and geometry; references never use visibility.
//! Table row-layer cases follow the selected CSS Tables 3 draft interpretation,
//! which has known historical interoperability differences.
use eris::{
    dom::Document,
    graphics::{Canvas, Color, Fonts},
    page::Page,
    script::{Runtime, Value},
};
use url::Url;

const WIDTH: u32 = 40;
const HEIGHT: u32 = 32;

type Rect = (u32, u32, u32, u32, u32);
type Hit<'a> = (&'a str, u32, u32, u32, u32, bool);

fn pixels(page: &Page, fonts: &Fonts) -> Vec<u32> {
    let layout = page.layout(WIDTH as f32, HEIGHT as f32, fonts);
    let mut canvas = Canvas::new(WIDTH, HEIGHT).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(&layout.commands, fonts, &page.images, 0.0, 0.0);
    assert!(!canvas.exhausted());
    canvas.pixels
}

fn compare(actual: &[u32], expected: &[u32]) {
    assert_eq!(actual.len(), expected.len());
    if let Some(index) = actual.iter().zip(expected).position(|(a, b)| a != b) {
        panic!("pixel ({},{}) actual={:06x} expected={:06x}",
            index % WIDTH as usize, index / WIDTH as usize, actual[index], expected[index]);
    }
}

struct Scene<'a> {
    html: &'a str,
    reference: &'a str,
    background: u32,
    rectangles: Option<&'a [Rect]>,
    hidden: &'a [&'a str],
    hits: &'a [Hit<'a>],
    points: &'a [(&'a str, f32, f32)],
    content_height: Option<f32>,
}

fn check(scene: Scene<'_>) {
    assert!(!scene.reference.contains("visibility"));
    let url = Url::parse("https://visibility.invalid/").unwrap();
    let page = Page::from_html(url.clone(), scene.html, false);
    let reference = Page::from_html(url, scene.reference, false);
    let fonts = Fonts::new();
    let actual = pixels(&page, &fonts);
    let expected_reference = pixels(&reference, &fonts);
    compare(&actual, &expected_reference);
    if let Some(rectangles) = scene.rectangles {
        let mut expected = vec![scene.background; (WIDTH * HEIGHT) as usize];
        for &(x, y, width, height, color) in rectangles {
            assert!(x + width <= WIDTH && y + height <= HEIGHT);
            for row in y..y + height {
                expected[(row * WIDTH + x) as usize..(row * WIDTH + x + width) as usize].fill(color);
            }
        }
        compare(&expected_reference, &expected);
        compare(&actual, &expected);
    } else {
        assert!(expected_reference.iter().any(|&pixel| pixel != scene.background));
    }
    let layout = page.layout(WIDTH as f32, HEIGHT as f32, &fonts);
    for id in scene.hidden {
        let node = page.document.query_selector(&format!("#{id}")).unwrap();
        assert!(!layout.hit_regions.iter().any(|hit| hit.node == node), "hidden hit: {id}");
    }
    for &(id, x, y, width, height, fixed) in scene.hits {
        let node = page.document.query_selector(&format!("#{id}")).unwrap();
        let hit = layout.hit_regions.iter().find(|hit| hit.node == node).unwrap();
        assert_eq!((hit.rect.x, hit.rect.y, hit.rect.width, hit.rect.height, hit.fixed),
            (x as f32, y as f32, width as f32, height as f32, fixed), "{id}");
        assert_eq!(layout.hit_test(x as f32 + 0.5, y as f32 + 0.5), Some(node), "{id}");
    }
    for &(id, x, y) in scene.points {
        let node = page.document.query_selector(&format!("#{id}")).unwrap();
        assert_eq!(layout.hit_test(x, y), Some(node), "{id}");
    }
    if let Some(height) = scene.content_height {
        assert_eq!(layout.content_height, height);
    }
}

'''
for row in pix:
 public+='#[test]\nfn '+row['id']+'() {\n    check(Scene {\n        html: '+raw(row['html'])+',\n        reference: '+raw(row['reference_html'])+',\n        background: 0x'+format(row['background'],'06x')+',\n'
 if row['rectangles'] is None: public+='        rectangles: None,\n'
 else:
  public+='        rectangles: Some(&['+','.join('(%d, %d, %d, %d, 0x%06x)'%tuple(r) for r in row['rectangles'])+']),\n'
 public+='        hidden: &['+', '.join('"'+i+'"' for i in row['hidden_ids'])+'],\n'
 public+='        hits: &['+','.join('("%s", %d, %d, %d, %d, %s)'%(i,x,y,w,h,str(f).lower()) for i,x,y,w,h,f in row['hits'])+'],\n'
 public+='        points: &['+','.join('("%s", %.1f, %.1f)'%(i,x,y) for i,x,y in row.get('points',[]))+'],\n'
 public+='        content_height: '+('Some(%.1f)'%row['content_height'] if 'content_height' in row else 'None')+',\n    });\n}\n\n'
 roster.append({'name':row['id'],'path':'tests/visibility.rs','literal_kind':'pixels','case_id':row['id']})
for row in js:
 public+='#[test]\nfn '+row['id']+'() {\n    for strict in [false, true] {\n        let mut doc = Document::parse('+raw(row['html'])+');\n        let mut runtime = Runtime::new();\n        let source = '+raw(row['source'])+';\n        let result = if strict {\n            runtime.execute_strict(source, &mut doc)\n        } else {\n            runtime.execute(source, &mut doc)\n        };\n        assert_eq!(result.unwrap(), Value::Bool(true), "strict={strict}");\n    }\n}\n'
 roster.append({'name':row['id'],'path':'tests/visibility.rs','literal_kind':'cssom','case_id':row['id']})
write('raw/tests/visibility.rs',public)
registration='\n#[cfg(test)]\nmod visibility_tests;\n'
write('registration/css.rs.append',registration)
before=(W/'src/css.rs').read_text();write('before/src/css.rs',before)
write('registration/css.rs.diff',''.join(difflib.unified_diff(before.splitlines(True),(before+registration).splitlines(True),fromfile='a/src/css.rs',tofile='b/src/css.rs')))
for path in ['src/css/visibility_tests.rs','tests/visibility.rs']:
 data=(O/'raw'/path).read_text();write('diffs/'+path+'.diff',''.join(difflib.unified_diff([],data.splitlines(True),fromfile='/dev/null',tofile='b/'+path)))
put('roster.json',{'groups':len(roster),'css_groups':6,'integration_groups':16,'cssom_modes':2,'rows':roster})
# Independent lexical inverse: every source literal used by adapter is exact.
checks=[]
for row in css:
 for key in ['html','css']:
  if key in row: assert raw(row[key]) in unit
 for key in ['rows','declarations','conditions']:
  for fields in row.get(key,[]):
   for value in fields:
    if isinstance(value,str) and value not in ['Hidden','Visible']: assert raw(value) in unit or key=='rows'
for row in pix:
 assert raw(row['html']) in public and raw(row['reference_html']) in public
for row in js: assert raw(row['html']) in public and raw(row['source']) in public
names=re.findall(r'#\[test\]\s*fn (\w+)\(',unit+public)
assert sorted(names)==sorted(x['name'] for x in roster) and len(names)==22
put('conversion-checks.json',{'status':'source-only inverse clear; no Rust compiler, formatter or project execution','test_names_exact':True,'all_html_css_js_literals_exact':True,'selected_pixel_contract':bind(O/'pixel-cases-2.json'),'registration':'Append only; root composes with production css.rs independently. Integration tests auto-discover existing Cargo conventions.','limitations':['No observed parent/candidate outcome claims.','CSS unit child requires selected enum/ComputedStyle field; existing integration APIs remain parent-compatible.','No GPU or browser interop execution.']})
files=[]
for path in ['src/css/visibility_tests.rs','tests/visibility.rs']:
 files.append({'relative_path':path,'raw':bind(O/'raw'/path),'before':None,'diff':bind(O/'diffs'/(path+'.diff'))})
put('source-ready.json',{'schema':1,'status':'sealed independent source-only controls; root alone imports/formats/executes','base':'18d3648ce4435b0d703e3b41fccc2f9f2fae156e','literal_seal':bind(O/'literal-ready-2.json'),'retained_original_literal_seal':bind(O/'literal-ready.json'),'files':files,'registration':{'relative_path':'src/css.rs','append':bind(O/'registration/css.rs.append'),'published_before':bind(O/'before/src/css.rs'),'diff':bind(O/'registration/css.rs.diff')},'bindings':[bind(O/x) for x in ['contract.json','css-cases.json','cssom-cases.json','pixel-cases-2.json','literal-correction-1.json','roster.json','conversion-checks.json']],'groups':22,'cssom_modes':2,'no_project_execution':True})
print(json.dumps(bind(O/'literal-ready-2.json')))
print(json.dumps(bind(O/'source-ready.json')))
