from pathlib import Path
import json,hashlib,difflib,shutil
N=Path('/tmp/eris-visibility-plan-1'); P=N/'controls-1'; O=N/'controls-adapter-correction-1'; O.mkdir(exist_ok=False)
def b(p):
 x=p.read_bytes(); return {'path':str(p),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()}
def put(name,x):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
files=[]
for rel in ['src/css/visibility_tests.rs','tests/visibility.rs']:
 before=(P/'raw'/rel).read_text(); after=before
 if rel.startswith('src/'):
  old='format!("main {{{}}} #target {{{}{value}}}",'
  new='format!("main {{{}}} #target {{{}visibility:{value}}}",'
  assert before.count(old)==2
  after=before.replace(old,new)
 for side,data in [('before',before),('raw',after)]:
  p=O/side/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 diff=O/'diffs'/(rel+'.diff');diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 files.append({'relative_path':rel,'raw':b(O/'raw'/rel),'before':b(O/'before'/rel),'diff':b(diff)})
assert (O/'raw/tests/visibility.rs').read_bytes()==(P/'raw/tests/visibility.rs').read_bytes()
put('review.json',{'finding':'The first Rust converter omitted the second visibility property name in the dynamic accepted/refused value-row declaration. Both loops therefore appended a bare value instead of a declaration.','scope':'Only insert visibility: in those two format strings. Frozen value tokens, expected enums, all other CSS/HTML/JS/readback/pixel fields and 22 test names unchanged.','timing':'Found by source inspection before any root import/execution or production-source read.','selected_literal_seal':b(P/'literal-ready-2.json'),'original_adapter_seal':b(P/'source-ready.json'),'source_only':True})
put('source-ready.json',{'schema':1,'status':'selected complete two-file adapter with narrow source-inspected conversion correction','base':'18d3648ce4435b0d703e3b41fccc2f9f2fae156e','files':files,'original_hold':b(P/'source-ready.json'),'literal_seal':b(P/'literal-ready-2.json'),'review':b(O/'review.json'),'registration':json.loads((P/'source-ready.json').read_text())['registration'],'groups':22,'all_original_literals_and_expected_outcomes_preserved':True,'no_project_execution':True})
print(json.dumps(b(O/'source-ready.json')))
