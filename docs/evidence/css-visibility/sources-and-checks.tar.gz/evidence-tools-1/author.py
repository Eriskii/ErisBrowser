from pathlib import Path
import json,hashlib,difflib,re,ast
N=Path('/tmp/eris-visibility-plan-1');O=N/'evidence-tools-1';P=Path('/tmp/eris-object-super-properties-plan-1/evidence-tools-1');R=P.parent/'evidence-tools-review-1/review.json'
BASE='18d3648ce4435b0d703e3b41fccc2f9f2fae156e';OLD='db880b867daa2ec7bfc82cb2041aec935d5b8189'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,s):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def put(name,x):write(name,json.dumps(x,indent=2)+'\n')
prior=json.loads((P/'source-ready.json').read_text());review=json.loads(R.read_text())
assert review['status']=='clear' and review['source_ready']==bind(P/'source-ready.json')
for row in prior['files']: assert bind(Path(row['path']))==row
modules=[]
for name in ['package.py','verify.py','evidence_common.py']:
 before=(P/name).read_text();after=re.sub(r'\bL\b','N',before).replace('object-super-properties','css-visibility').replace(OLD,BASE)
 inverse=re.sub(r'\bN\b','L',after).replace('css-visibility','object-super-properties').replace(BASE,OLD)
 assert inverse==before
 a=ast.parse(after,filename=name);b=ast.parse(inverse,filename=name)
 assert ast.dump(b,include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False)
 write('before/'+name,before);write(name,after)
 write('diffs/'+name+'.diff',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
 write('diffs/'+name+'.inverse.diff',''.join(difflib.unified_diff(after.splitlines(True),before.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
 modules.append({'module':name,'before':bind(O/'before'/name),'raw':bind(O/name),'forward':bind(O/'diffs'/(name+'.diff')),'inverse':bind(O/'diffs'/(name+'.inverse.diff')),'ast_parse':True,'full_module_equality_after_identity_normalization':True,'top_level_functions':[x.name for x in a.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))]})
shape={
 'purpose':'Prospective schema only. Root supplies actual sealed final inputs; this file is not an executable selection or a completed validation receipt.',
 'format':1,'checkpoint':'css-visibility','exact_top_level_keys':['format','checkpoint','inputs','documents','source_snapshot_root','required_artifacts'],
 'binding_shape':{'path':'normalized N-relative regular-file path','bytes':'nonnegative integer','sha256':'64 lowercase hexadecimal digits'},
 'inputs':{
 'source_parent':'Actual source-parent.json binding at published 18d3648c.',
 'source_inventory':'Actual final selected inventory, with its own base/hash/rows. No candidate number, source count or outcome count is hardcoded.',
 'source_snapshots':'Root-supplied selector with exactly root and files. Root is the absolute selected snapshot directory; files contain repo-relative path, bytes and sha256 for every derived changed source.',
 'final_validation':'Actual final root ledger with status pass and the final selected source-inventory hash; pending.',
 'validation_review':'Actual independent peer with status clear and the selected final-ledger hash; pending.',
 'documentation_hold':'Actual final six-document source-ready containing the final-ledger hash. documentation-1/draft-ready.json with pending fields is not final authorization.',
 'documentation_review':'Actual clear independent peer binding both the final doc hold and final ledger; pending.'},
 'source_snapshot_root':'Normalized N-relative final candidate snapshot directory. Its complete regular-file roster and selected source_snapshots rows must equal the independently derived source delta.',
 'documents':'Sorted unique actual repo-relative paths, exactly equal to the selected documentation raw/ roster. Six approved paths are planned; no seal/hash is invented. README.md or docs/ only, excluding docs/evidence/.',
 'planned_document_paths':['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/css-visibility.md'],
 'required_artifacts':'Nonempty unique binding list for selected production/control/correction/review/ABI/budget/dynamic/performance/validation/release/profile receipts as actually selected, plus these tools and their independent peer. Every required artifact must be an eligible archive member.',
 'source_snapshot_receipt_shape':{'root':'absolute N/final-selected-snapshot-directory','files':[{'path':'repo-relative normalized path','bytes':'actual integer','sha256':'actual SHA-256'}]},
 'no_invented_completed_inputs':True}
put('selection-shape.json',shape)
contract={
 'status':'held source-only recipe; root alone executes after complete selection/reviews',
 'checkpoint':'css-visibility','published_base':BASE,'prior_source_ready':bind(P/'source-ready.json'),'prior_review':bind(R),
 'cwd':str(N),'commands':['python3 -B evidence-tools-1/package.py --selection root/evidence-selection-1.json','python3 -B evidence-tools-1/verify.py --selection root/evidence-selection-1.json'],
 'outputs':['worktree/docs/evidence/css-visibility/sources-and-checks.tar.gz','worktree/docs/evidence/css-visibility/manifest.json'],
 'prospective_commands_only':True,
 'sequence':['Root seals final source/snapshot selector, passing final ledger, clear validation peer, final six-document hold and clear doc peer.','Root imports exact selected documents and creates the real seven-input selection with explicit required artifact bindings.','Freeze all eligible N inputs before running either command. Use the same --selection for both. Capture publication output only in publication/ or the three exact excluded root receipts.','Exclusive output creation refuses existing archives/manifests. Retain any failed attempt and diagnose it; do not overwrite or weaken selection to bypass a refusal.'],
 'bounds':{'members':20000,'uncompressed_member_bytes':134217728,'compressed_byte_cap':'No separate gzip-size cap in the reviewed inherited recipe; unchanged.'},
 'exclusions':{'top':['worktree','publication'],'top_prefix':['target'],'directory_names':['__pycache__','.git','target'],'exact_root_paths':['root/publication-verification.json','root/github-publication.json','root/git-publication.json'],'symlinks':'never followed','binaries':'non-JSON binaries/ members and root eris-js-* members excluded; JSON sidecars retained'},
 'preserved_safeguards':['Exact seven-input/top-level schemas, status checks, final ledger/source/doc/peer hash joins.','Complete current source hashing, pinned-base fallback for newly inventoried paths, exact changed-source snapshot roster and lengths/hashes.','Exact final documentation raw roster and byte-identical imported documents; selected final hold must contain each raw hash.','Regular-file/lstat ancestor checks and normalized relative paths; selected symlinks refuse. No extraction.','Sorted USTAR regular members, zero owners/time, fixed mode0644, deterministic gzip level9/mtime0.','All eligible failed/superseded attempts retained. Worktree/build/publication/binary exclusions explicit; special entries, unexpected executables and credential-shaped files refuse.','Exact member roster/body/origin and selected membership checks; read complete gzip trailer and deterministic re-encode to reject hidden tails or concatenated streams.','Preconditions, selected bindings and origin roster rechecked after packaging and verification.'],
 'scope_qualification':'Selected-source evidence only, not a self-contained build graph, Git commit path-count verifier, whole-browser compatibility result, security proof, GPU evidence or Chromium performance comparison.',
 'execution_claim':'Only stdlib AST/source/hash/inverse checks. package.py, verify.py and evidence_common.py were neither imported nor executed.'}
put('execution-contract.json',contract)
current=N/'source-candidate-2.json';assert bind(current)['sha256']=='2e065fe2cbe80d57a3ec012060ced8c9e55a3d2ee44158ca1dd87d941c86ddd3'
inv=json.loads(current.read_bytes());assert inv['base']==BASE and len(inv['files'])==15307
put('adaptation.json',{'status':'identity-only source adaptation','prior':bind(P/'source-ready.json'),'prior_review':bind(R),'modules':modules,'substitutions':{'root_symbol_and_label':'L -> N as a complete word','checkpoint':'object-super-properties -> css-visibility','base':OLD+' -> '+BASE},'entire_algorithm_preserved':True,'current_observation_only_not_recipe_requirement':{'candidate2':bind(current),'selected_inputs':15307,'changed_paths_root_reported':32,'qualification':'Root-selected candidate at authoring; recipe still demands the actual final inventory and independently derives the complete delta.'},'final_counts_docs_seals_not_invented':True,'no_live_edits_or_package_execution':True})
put('source-checks.json',{'status':'clear inert source checks','prior_manifest_all_files_verified':True,'prior_peer_exact_bound_and_clear':True,'modules':modules,'full_ast_and_exact_source_inverse_after_identity_normalization':True,'all_validation_control_flow_and_tar_caps_unchanged':True,'no_project_or_packager_execution':True})
files=[bind(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',{'schema':1,'status':'held source-ready evidence tools; final root selection and execution remain pending','checkpoint':'css-visibility','published_base':BASE,'adapted_from':bind(P/'source-ready.json'),'prior_review':bind(R),'files':files,'modules':modules,'prospective_schema':bind(O/'selection-shape.json'),'execution_contract':bind(O/'execution-contract.json'),'project_execution':False,'live_edits':False,'archive_outputs_created':False,'pending_inputs_are_not_fabricated':True})
print(json.dumps(bind(O/'source-ready.json')))
