from pathlib import Path
import difflib
import hashlib
import json

N = Path(__file__).resolve().parents[1]
W = N / 'worktree'
H = N / 'css-producer-1'
H.mkdir()

def sha(data): return hashlib.sha256(data).hexdigest()
def replace(source, before, after, count=1):
    assert source.count(before) == count, (before, source.count(before), count)
    return source.replace(before, after)

source = (W / 'src/css.rs').read_text()
source = replace(source, 'mod border_spacing;\n', 'mod border_spacing;\nmod visibility;\npub use visibility::Visibility;\npub(crate) use visibility::valid as valid_visibility;\n')
source = replace(source, '    pub display: Display,\n', '    pub display: Display,\n    pub visibility: Visibility,\n')
source = replace(source, '            display: Display::Inline,\n', '            display: Display::Inline,\n            visibility: Visibility::Visible,\n')
source = replace(source, '            s.color = p.color;\n', '            s.color = p.color;\n            s.visibility = p.visibility;\n')
source = replace(source, '        let spacing_property = property.eq_ignore_ascii_case("border-spacing");\n', '        let spacing_property = property.eq_ignore_ascii_case("border-spacing");\n        let visibility_property = property.eq_ignore_ascii_case("visibility");\n')
source = replace(source, '                && !(spacing_property && border_spacing::escape_allowed(*token))\n', '                && !(spacing_property && border_spacing::escape_allowed(*token))\n                && !(visibility_property && visibility::escape_allowed(*token))\n')
source = replace(source, '            "border-spacing"\n                | "object-fit"', '            "border-spacing"\n                | "visibility"\n                | "object-fit"')
source = replace(source, '        let spacing_property = name.eq_ignore_ascii_case("border-spacing");\n', '''        let spacing_property = name.eq_ignore_ascii_case("border-spacing");
        // A supports condition uses CSS syntax for its property identifier.
        // The separate two-argument API deliberately keeps its literal-name rule.
        let visibility_property = css_identifier(name).is_some_and(|(decoded, end)| {
            end == name.len() && decoded.eq_ignore_ascii_case("visibility")
        });
''')
source = replace(source, '        if image_property || box_property || spacing_property {', '        if image_property || box_property || spacing_property || visibility_property {')
source = replace(source, '                    && !(spacing_property && border_spacing::escape_allowed(*t))\n', '                    && !(spacing_property && border_spacing::escape_allowed(*t))\n                    && !(visibility_property && visibility::escape_allowed(*t))\n')
source = replace(source, '            return valid_declaration_value(\n                &name.to_ascii_lowercase(),', '''            let name = if visibility_property {
                "visibility".into()
            } else {
                name.to_ascii_lowercase()
            };
            return valid_declaration_value(
                &name,''')
source = replace(source, '    if name == "border-spacing" {\n        let mut work = MAX_SUPPORTS_WORK;', '    if name == "visibility" {\n        let mut work = MAX_SUPPORTS_WORK;\n        return valid_visibility(value, &mut work).unwrap_or(false);\n    }\n    if name == "border-spacing" {\n        let mut work = MAX_SUPPORTS_WORK;')
source = replace(source, 'const SUPPORTED_PROPERTIES: &[&str] = &[\n    "display",', 'const SUPPORTED_PROPERTIES: &[&str] = &[\n    "display",\n    "visibility",')
source = replace(source, '            "color"\n                | "border-spacing"', '            "color"\n                | "visibility"\n                | "border-spacing"')
source = replace(source, '    match name {\n        "object-fit" => {\n', '''    match name {
        "visibility" => {
            if let Ok(Some(visibility)) = visibility::parse(value, work) {
                s.visibility = visibility;
            }
        }
        "object-fit" => {
''')
source = replace(source, '        "object-fit" => s.object_fit = p.object_fit,', '        "visibility" => s.visibility = p.visibility,\n        "object-fit" => s.object_fit = p.object_fit,')
source = replace(source, ') -> Result<bool, crate::selectors::Error> {\n    if name == "border-spacing" {', ') -> Result<bool, crate::selectors::Error> {\n    if name == "visibility" {\n        valid_visibility(value, work)\n    } else if name == "border-spacing" {')

cssom = (W / 'src/cssom.rs').read_text()
cssom = replace(cssom, '    if property == "border-spacing" {\n', '    if property == "visibility" {\n        return css::valid_visibility(value, work).map_err(|_| Error::Limit);\n    }\n    if property == "border-spacing" {\n')

module = '''//! Inherited visibility for boxes that retain their layout contribution.
use crate::selectors::{self, Error, Kind, Token, spend};

#[repr(u8)]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum Visibility {
    #[default]
    Visible = 0,
    Hidden = 1,
}

// Supports scanners prepay the token scan. Final grammar validation below
// checks decoded spelling; this predicate only permits escaped identifiers.
pub(super) fn escape_allowed(token: Token<'_>) -> bool {
    token.kind == Kind::Ident && !token.raw.contains('\\0')
}

fn keyword(value: &str, work: &mut usize) -> Result<Option<&'static str>, Error> {
    if value.len() > 4096 {
        return Err(Error::Limit);
    }
    // Prepay the significant-token pass and at most seven decoded comparisons.
    spend(work, value.len().saturating_mul(8) + 1)?;
    let tokens = selectors::tokens(value, work)?;
    let mut significant = tokens.iter().filter(|token| token.kind != Kind::Whitespace);
    let Some(token) = significant.next() else {
        return Ok(None);
    };
    if significant.next().is_some() || !escape_allowed(*token) {
        return Ok(None);
    }
    Ok([
        "visible", "hidden", "inherit", "initial", "unset", "revert", "revert-layer",
    ]
    .into_iter()
    .find(|name| token.is_name(name)))
}

pub(crate) fn valid(value: &str, work: &mut usize) -> Result<bool, Error> {
    Ok(keyword(value, work)?.is_some())
}

pub(super) fn parse(value: &str, work: &mut usize) -> Result<Option<Visibility>, Error> {
    Ok(match keyword(value, work)? {
        Some("visible") => Some(Visibility::Visible),
        Some("hidden") => Some(Visibility::Hidden),
        _ => None,
    })
}
'''
rows = []
for relative, raw in [('src/css.rs', source), ('src/cssom.rs', cssom), ('src/css/visibility.rs', module)]:
    path = W / relative
    before = path.read_bytes() if path.exists() else None
    after = raw.encode()
    for sub, data in [('before', before), ('raw', after)]:
        if data is not None:
            dest = H / sub / relative
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
    diff = ''.join(difflib.unified_diff((before or b'').decode().splitlines(True), raw.splitlines(True), fromfile='a/' + relative, tofile='b/' + relative))
    inverse = ''.join(difflib.unified_diff(raw.splitlines(True), (before or b'').decode().splitlines(True), fromfile='b/' + relative, tofile='a/' + relative))
    for sub, data in [('diffs', diff), ('inverse', inverse)]:
        dest = H / sub / (relative + '.patch'); dest.parent.mkdir(parents=True, exist_ok=True); dest.write_text(data)
    rows.append(dict(path=relative, before=None if before is None else sha(before), after=sha(after), bytes=len(after)))
record = dict(base='18d3648ce4435b0d703e3b41fccc2f9f2fae156e', status='held CSS source; unexecuted', paths=rows,
              contract='Visible=0 default, Hidden=1 repr(u8). Shared bounded single-identifier grammar through declarations, supports and CSSOM. Inherited with existing CSS-wide, var and cascade routes. Collapse deferred.',
              qualifications='No layout/paint/focus behavior claimed by this hold alone. Struct size and full behavior remain to be measured.', live_edits=False)
(H / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print('Authored three held CSS production paths.')
