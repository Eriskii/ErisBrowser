from pathlib import Path
import hashlib,json

n=Path(__file__).resolve().parents[1];w=n/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def verify(p,record):
    b=p.read_bytes();assert len(b)==record['bytes'] and sha(b)==record['sha256'],str(p)
    return b
selected={};bindings=[]
def stage(path,b,before=None):
    old=selected.get(path,(w/path).read_bytes() if (w/path).exists() else None)
    if before is not None: assert old==before,path
    selected[path]=b
def hold(name):
    p=n/name/'source-ready.json';bindings.append({'path':str(p),'sha256':sha(p.read_bytes())});return read(p)
css=hold('css-producer-2')
for row in css['paths']:
    p=n/'css-producer-2/raw'/row['path'];b=p.read_bytes()
    assert sha(b)==row['after'] and len(b)==row['bytes']
    old=(w/row['path']).read_bytes() if (w/row['path']).exists() else None
    assert (sha(old) if old is not None else None)==row['before']
    stage(row['path'],b)
for name in ['layout-producer-1','layout-fixtures-1','layout-fixtures-2']:
    for row in hold(name)['paths']:
        stage(row['path'],verify(Path(row['raw']['path']),row['raw']),verify(Path(row['before']['path']),row['before']))
for name in ['browser-producer-1','historical-fixtures-1']:
    data=hold(name)
    for row in data['files']:verify(n/name/row['path'],row)
    if name=='browser-producer-1':
        for path in data['payload_paths']:
            before=n/name/'before'/path
            stage(path,(n/name/'raw'/path).read_bytes(),before.read_bytes() if before.exists() else None)
    else:
        edits=read(n/name/'edits.json')
        for path in data['payload_paths']:
            parent=(n/name/'before'/path).read_bytes()
            old=selected.get(path,parent).decode()
            for edit in edits:
                if edit['path']==path:
                    assert old.count(edit['before'])==1,(path,edit['before'])
                    old=old.replace(edit['before'],edit['after'],1)
            if path!='src/worker/codec.rs':assert old.encode()==(n/name/'raw'/path).read_bytes()
            stage(path,old.encode())
data=hold('controls-adapter-correction-1')
for row in data['files']:stage(row['relative_path'],verify(Path(row['raw']['path']),row['raw']))
registration=data['registration']['append']
selected['src/css.rs']+=verify(Path(registration['path']),registration)
data=hold('dynamic-controls-1')
for row in data['files']:stage(row['path'],verify(n/'dynamic-controls-1/raw'/row['path'],row))
selected['tests/worker.rs']+=data['registration']['append'].encode()
parent=read(n/'source-parent.json')
for row in parent['files']:
    p=w/row['path'];verify(p,row)
rows=[]
for path,b in sorted(selected.items()):
    p=w/path;old=p.read_bytes() if p.exists() else None
    for folder,content in [('before',old),('after',b)]:
        if content is not None:
            out=n/'candidate-import-1'/folder/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(content)
    rows.append({'path':path,'before':sha(old) if old is not None else None,'after':sha(b),'bytes':len(b)})
for path,b in selected.items():
    p=w/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
receipt={'base':parent['base'],'bindings':bindings,'paths':rows,'status':'exact held sources composed; format and execution pending'}
with (n/'root/candidate-import-1.json').open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print('Imported',len(rows),'paths')
