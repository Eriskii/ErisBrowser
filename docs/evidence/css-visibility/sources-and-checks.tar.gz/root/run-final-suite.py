from pathlib import Path
import subprocess,sys
n=Path(__file__).resolve().parents[1]
commands=[
 ['candidate-full-msrv-2','msrv','test','--all-targets','--','--include-ignored'],
 ['candidate-full-host-vulkan-1','host-vulkan','test','--all-targets','--','--include-ignored'],
 ['candidate-clippy-msrv-1','msrv','clippy','--all-targets','--','-D','warnings'],
 ['candidate-clippy-host-vulkan-1','host-vulkan','clippy','--all-targets','--','-D','warnings'],
 ['candidate-release-browser-1','msrv','build','--release','--bin','eris-browser'],
]
for args in commands:
    print('Starting '+args[0],flush=True)
    result=subprocess.run([sys.executable,str(n/'root/run-config.py'),*args])
    if result.returncode:raise SystemExit(result.returncode)
raise SystemExit(subprocess.run([sys.executable,str(n/'run-tool.py'),'fmt-check-final-1','env','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.88.0','fmt','--all','--','--check']).returncode)
