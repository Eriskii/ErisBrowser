from pathlib import Path
import os,subprocess,sys,json
k=Path(__file__).resolve().parents[1];label,config,*args=sys.argv[1:]
configs={'msrv':('1.88.0','target-msrv',[]),'host-vulkan':('1.99.0','target-1990',['--features','test262-host,vulkan-raster']),'msrv-host':('1.88.0','target-msrv',['--features','test262-host']),'host':('1.99.0','target-1990',['--features','test262-host'])}
version,target,features=configs[config]
env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR=str(k/target),CARGO_BUILD_JOBS='4')
command=['cargo','+'+version,args[0],'--locked','--offline',*features,*args[1:]]
meta={'config':config,'toolchain':version,'rustc':subprocess.check_output(['rustc','+'+version,'--version','--verbose'],env=env).decode(),'features':features,'target_dir':str(k/target)}
with (k/'validation'/(label+'-environment.json')).open('x') as out:json.dump(meta,out,indent=2);out.write('\n')
raise SystemExit(subprocess.run([sys.executable,str(k/'run-tool.py'),label,*command],env=env).returncode)
