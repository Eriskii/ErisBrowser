from pathlib import Path
import hashlib,json
n=Path(__file__).resolve().parents[1]
def binding(relative):
    b=(n/relative).read_bytes();return dict(path=relative,bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
inputs=dict(source_parent='source-parent.json',source_inventory='source-candidate-3.json',source_snapshots='root/source-snapshots-final.json',final_validation='root/final-validation.json',validation_review='validation-review-1/review.json',documentation_hold='documentation-2/source-ready.json',documentation_review='documentation-review-1/review.json')
required={p.relative_to(n).as_posix() for pattern in ['*/source-ready.json','*/review.json','validation/*.json'] for p in n.glob(pattern)}
required.update(['controls-1/literal-ready-2.json','composition-review-1/candidate3-addendum.json','root/all-fixtures-import-1.json','root/budget-controls-import-1.json','root/candidate-import-1.json','root/measurement-oracle-review-1.json','root/reftest-comparison-1.json','binaries/parent-browser.json','binaries/candidate-browser.json','measurement-results-1/result.json','measurement-results-2/result.json'])
raw=n/'documentation-2/raw';docs=sorted(p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file())
assert docs==['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/css-visibility.md']
record=dict(format=1,checkpoint='css-visibility',inputs={key:binding(path) for key,path in inputs.items()},documents=docs,source_snapshot_root='candidate-source-3',required_artifacts=[binding(p) for p in sorted(required)])
with (n/'root/evidence-selection-1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Selected',len(required),'required artifacts and',len(docs),'documents')
