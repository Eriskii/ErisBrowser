from pathlib import Path
import hashlib,json,difflib,subprocess,sys
n=Path(__file__).resolve().parents[1];w=n/'worktree';version=sys.argv[1]
def sha(b):return hashlib.sha256(b).hexdigest()
parent=json.loads((n/'source-parent.json').read_text());rows={r['path']:r for r in parent['files']}
paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=w,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w,text=True).splitlines())
changed=[]
for path in sorted(set(rows)|paths):
    p=w/path
    if not p.is_file():raise ValueError(path)
    b=p.read_bytes()
    if path in paths:
        out=n/('candidate-source-'+version)/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
        changed.append({'path':path,'bytes':len(b),'sha256':sha(b)})
        imported=n/'candidate-import-1/after'/path
        if imported.exists() and imported.read_bytes()!=b:
            diff=''.join(difflib.unified_diff(imported.read_text().splitlines(True),b.decode().splitlines(True),fromfile='held/'+path,tofile='candidate/'+path))
            d=n/('format-'+version)/'diffs'/(path+'.patch');d.parent.mkdir(parents=True,exist_ok=True);d.write_text(diff)
    else:assert len(b)==rows[path]['bytes'] and sha(b)==rows[path]['sha256'],path
    rows[path]={'path':path,'bytes':len(b),'sha256':sha(b)}
data={'base':parent['base'],'scope':parent['scope'],'files':[rows[p] for p in sorted(rows)]}
p=n/('source-candidate-'+version+'.json')
with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
receipt={'source_inventory':{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'inputs':len(rows)},'changed_paths':changed}
with (n/'root'/('candidate-snapshots-'+version+'.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(receipt['source_inventory']);print('Changed paths',len(changed))
