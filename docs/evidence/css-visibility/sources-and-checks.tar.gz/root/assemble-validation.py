from pathlib import Path
import hashlib,json,re,subprocess,collections
n=Path(__file__).resolve().parents[1];w=n/'worktree'
def load(p):return json.loads(p.read_bytes())
def bound(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
inventory_path=n/'source-candidate-3.json';inventory=load(inventory_path)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip()==inventory['base']
for row in inventory['files']:assert dict(bound(w/row['path']),path=row['path'])==row
snapshot=load(n/'root/candidate-snapshots-3.json')
assert load(n/'root/source-snapshots-final.json') == dict(root=str(n/'candidate-source-3'),files=snapshot['changed_paths'])
for row in snapshot['changed_paths']:
    assert dict(bound(n/'candidate-source-3'/row['path']),path=row['path'])==row
    assert (w/row['path']).read_bytes()==(n/'candidate-source-3'/row['path']).read_bytes()
accepted=['candidate-full-msrv-2','candidate-full-host-vulkan-1','candidate-clippy-msrv-1','candidate-clippy-host-vulkan-1','fmt-check-final-1','candidate-release-browser-1','candidate-reftests-1','candidate-measurement-2']
attempts=[]
for p in sorted((n/'validation').glob('*.json')):
    r=load(p)
    if 'command' not in r:continue
    log=p.parent/r['log'];assert bound(log)['sha256']==r['sha256']
    text=log.read_text();suites=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
    item=dict(label=p.stem,receipt=bound(p),log=bound(log),command=r['command'],exit=r['exit'],elapsed_seconds=r['elapsed_seconds'],accepted=p.stem in accepted)
    if suites:item['tests']=dict(suites=len(suites),passed=sum(int(s[1]) for s in suites),failed=sum(int(s[2]) for s in suites),ignored=sum(int(s[3]) for s in suites))
    environment=p.with_name(p.stem+'-environment.json')
    if environment.exists():item['environment']=bound(environment)
    attempts.append(item)
by_name={r['label']:r for r in attempts}
assert all(by_name[label]['exit']==0 for label in accepted)
for label,version,features,verb,tail in [
 ('candidate-full-msrv-2','1.88.0',[],'test',['--all-targets','--','--include-ignored']),
 ('candidate-full-host-vulkan-1','1.99.0',['--features','test262-host,vulkan-raster'],'test',['--all-targets','--','--include-ignored']),
 ('candidate-clippy-msrv-1','1.88.0',[],'clippy',['--all-targets','--','-D','warnings']),
 ('candidate-clippy-host-vulkan-1','1.99.0',['--features','test262-host,vulkan-raster'],'clippy',['--all-targets','--','-D','warnings']),
 ('candidate-release-browser-1','1.88.0',[],'build',['--release','--bin','eris-browser'])]:
    assert by_name[label]['command']==['cargo','+'+version,verb,'--locked','--offline',*features,*tail]
for label,count in [('candidate-full-msrv-2',3521),('candidate-full-host-vulkan-1',3885)]:
    tests=by_name[label]['tests'];assert tests==dict(suites=58,passed=count,failed=0,ignored=0),tests
    text=Path(by_name[label]['log']['path']).read_text()
    for name in ['visibility_dynamic_hiding_preserves_space_and_visible_child_event_bubbling','visibility_dynamic::confined_visibility_dynamic_hiding_preserves_space_and_visible_child_event_bubbling']:
        assert 'test '+name+' ... ok' in text
new_roster=[]
for path,prefix in [('src/css/visibility_tests.rs','css::visibility_tests::'),('src/css/visibility_budget_tests.rs','css::visibility_budget_tests::'),('src/browser/visibility_tests.rs','browser::visibility_tests::'),('src/worker/codec/visibility_tests.rs','worker::codec::visibility_tests::'),('tests/visibility.rs',''),('tests/visibility_dynamic.rs',''),('tests/worker/visibility_dynamic.rs','visibility_dynamic::')]:
    new_roster.extend(prefix+name for name in re.findall(r'(?m)^fn (\w+)\(\)',(w/path).read_text()))
assert len(new_roster)==len(set(new_roster))==36
transitions=[]
l=Path('/tmp/eris-object-super-properties-plan-1')
for label,old_label in [('candidate-full-msrv-2','candidate-full-msrv-2'),('candidate-full-host-vulkan-1','candidate-full-host-vulkan-1')]:
    parent_log=l/'validation'/(old_label+'.log');parent_receipt=l/'validation'/(old_label+'.json');p=load(parent_receipt);assert p['exit']==0 and p['sha256']==bound(parent_log)['sha256']
    prior=collections.Counter(re.findall(r'(?m)^test (\S+) \.\.\. ok$',parent_log.read_text()))
    current=collections.Counter(re.findall(r'(?m)^test (\S+) \.\.\. ok$',Path(by_name[label]['log']['path']).read_text()))
    assert current==prior+collections.Counter(new_roster),(label,current-prior,prior-current)
    transitions.append(dict(label=label,parent_receipt=bound(parent_receipt),parent_log=bound(parent_log),prior_passed=sum(prior.values()),current_passed=sum(current.values()),added=sorted(new_roster),removed=[]))
reviews=['css-review-1/review.json','layout-review-1/review.json','browser-review-1/review.json','controls-review-1/review.json','dynamic-controls-review-1/review.json','composition-review-1/review.json','composition-review-1/candidate3-addendum.json','all-fixtures-review-1/review.json','measurement-runner-review-1/review.json','measurement-runner-review-2/review.json']
assert all(load(n/path)['status']=='clear' for path in reviews)
record=dict(status='pass',checkpoint='css-visibility',base=inventory['base'],source_inventory=bound(inventory_path),source_snapshots=bound(n/'root/source-snapshots-final.json'),selected_inputs=len(inventory['files']),changed_source_paths=len(snapshot['changed_paths']),accepted_labels=accepted,attempts=attempts,source_reviews=[bound(n/p) for p in reviews],new_coverage=dict(semantic_css=6,pixel_and_cssom=16,native_focus=3,codec=4,dynamic_direct_and_confined=2,resource_boundaries=5),storage=dict(parent=dict(ComputedStyle=1032,PaintOwner=16,LayoutResult=56),candidate=dict(ComputedStyle=1032,PaintOwner=24,LayoutResult=80),wire_bytes='4 + DOM node count; at most100004',qualification='Actual Rust1.88 types on this host; capacity/allocator overhead is additional. One owner roster at200000 logical records adds1600000 payload bytes; not a peak-allocation bound.'),retained_failures=[dict(label='parent-visibility-integration-1',reason='16 frozen integration groups compiled then failed because visibility was unsupported.'),dict(label='parent-visibility-dynamic-1',reason='Published renderer painted hidden red pixels.'),dict(label='parent-confined-visibility-dynamic-1',reason='Published confined renderer painted hidden red pixels.'),dict(label='candidate-full-msrv-1',reason='Four historical all-property controls had stale cardinality/accounting literals; eight network/confinement preflights met outer sandbox localhost EPERM. Exact fixture migration preserves256records/64KiB limits; full suites rerun with authorized escalation.')],qualification='Visible/hidden subset only; collapse deferred. Table row-layer policy follows a draft with recorded interoperability disagreement. CPU packed native-plan controls do not claim new hardware GPU execution. No full compatibility, security certification or Chromium performance claim.')
record['test_roster_transitions']=transitions
for role,label in [('parent','parent-reftests-1'),('candidate','candidate-reftests-1')]:
    sidecar_path=n/'binaries'/(role+'-browser.json');sidecar=load(sidecar_path)
    for row in sidecar.values():assert bound(Path(row['path']))==row
    assert sidecar['source_inventory']==bound(n/('source-parent.json' if role=='parent' else 'source-candidate-3.json'))
    record.setdefault('binary_sidecars',[]).append(bound(sidecar_path))
    report=n/label/'report.json';v=load(report)
    assert (v['passed'],v['failed'],v['total'])==(102,0,102) and v['binary']==sidecar['binary']['path'] and v['viewport']==dict(width=320,height=240)
    assert len(v['cases'])==102 and all(r['status']=='pass' and r['different_pixels']==r['maximum_channel_error']==0 for r in v['cases'])
    record.setdefault('visual_references',[]).append(bound(report))
assert [r['name'] for r in load(n/'parent-reftests-1/report.json')['cases']]==[r['name'] for r in load(n/'candidate-reftests-1/report.json')['cases']]
comparison=load(n/'root/reftest-comparison-1.json');assert comparison['status']=='pass' and comparison['pairs']==102 and comparison['images_compared']==204
assert comparison['parent_report']==bound(n/'parent-reftests-1/report.json') and comparison['candidate_report']==bound(n/'candidate-reftests-1/report.json')
assert len(comparison['cases'])==102 and [row['name'] for row in comparison['cases']]==[row['name'] for row in load(n/'parent-reftests-1/report.json')['cases']]
for row in comparison['cases']:
    assert len(row['images'])==2
    for image in row['images']:
        for role in ['parent','candidate']:assert bound(Path(image[role]['path']))==image[role]
record['visual_parent_candidate_comparison']=bound(n/'root/reftest-comparison-1.json')
for role in ['parent','candidate']:
    label=role+'-layout-storage-1';attempt=by_name[label];assert attempt['exit']==0
    match=re.search(r'actual_layout_storage PaintOwner=(\d+) LayoutResult=(\d+) ComputedStyle=(\d+)',Path(attempt['log']['path']).read_text());assert match
    observed=dict(zip(['PaintOwner','LayoutResult','ComputedStyle'],map(int,match.groups())))
    assert observed==record['storage'][role]
    record.setdefault('storage_measurements',[]).append(dict(role=role,receipt=attempt['receipt'],log=attempt['log'],observed=observed))
measurement_path=n/'measurement-results-2/result.json';measurement=load(measurement_path)
assert measurement['status']=='passed' and len(measurement['attempts'])==18 and len(measurement['summary']['pairs'])==6
assert measurement['chromium_comparison'] is measurement['controlled_environment'] is measurement['hardware_validation'] is False
assert bound(Path(measurement['inputs']['path']))==measurement['inputs']
pins=load(Path(measurement['inputs']['path']))['bindings']
for role in ['parent','candidate']:assert pins[role]['sidecar']==bound(n/'binaries'/(role+'-browser.json'))
for row in measurement['attempts']:
    for name in ['image','supervisor','stdout','stderr']:assert bound(Path(row[name]['path']))==row[name]
record['measurement']=dict(result=bound(measurement_path),inputs=measurement['inputs'],summary=measurement['summary'])
record['retained_failures'].append(dict(label='candidate-measurement-1',reason="Runner-selected TZ=UTC required absent /usr/share/zoneinfo/UTC on NixOS. Parent stopped before any accepted samples; supervisor confirmed clean teardown. Additive runner2 uses POSIX UTC0 with the same intended offset, retaining all pixels, process order and supervision."))
with (n/'root/final-validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(bound(n/'root/final-validation.json'))
