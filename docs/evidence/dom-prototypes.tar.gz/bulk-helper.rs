// Byte-key maps only. PropertyKey metadata uses full UTF-16 comparison work.
struct BulkPlan { work: usize, bytes: usize }
fn bulk_plan<K: Ord + AsRef<str>,V>(old:&BTreeMap<K,V>, new:&[(K,V)]) -> Result<BulkPlan> {
    let total=old.len().checked_add(new.len()).ok_or_else(|| ScriptError::resource("DOM metadata map length overflow"))?;
    let max=old.keys().map(|key|key.as_ref().len()).chain(new.iter().map(|(key,_)|key.as_ref().len())).max().unwrap_or(0);
    let mut height=0usize; let mut span=1usize;
    while span<=total/12 {span*=12;height+=1;}
    let old_nodes=if old.is_empty(){0}else{1+(old.len()-1)/5};
    let allocated_nodes=if total==0{0}else{total/11+height+1};
    // Validate staged ordering and collisions, merge once, then the pinned
    // sorted-input stable-sort and dedup each compare adjacent keys once.
    let comparisons=new.len().saturating_sub(1) + total + total.saturating_sub(1)*3;
    let structural=64 + 8*(old.len()+old_nodes) + 6*total
        + 8*total + 4*(height+1)*(total/12) + 64*height + 16*(height+1);
    let work=structural.saturating_add(comparisons.saturating_mul(1+max/8));
    // Sorted stable sort requests max(N,48) scratch slots. Vec IntoIter
    // collection reuses the unadvanced merged Vec on pinned 1.88/1.98.
    // Old tree allocations remain charged; these are complete replacement
    // nodes including a transient right spine before final border repair.
    let bytes=total.max(48).checked_mul(std::mem::size_of::<(K,V)>())
        .and_then(|n|n.checked_add(allocated_nodes.checked_mul(node_bytes::<K,V>())?))
        .ok_or_else(||ScriptError::resource("DOM metadata map storage overflow"))?;
    Ok(BulkPlan{work,bytes})
}
fn validate_staged<K:Ord,V>(old:&BTreeMap<K,V>,new:&[(K,V)])->Result<()> {
    if new.windows(2).any(|pair|pair[0].0>=pair[1].0) {
        return Err(ScriptError::resource("DOM metadata staging is not strictly sorted"));
    }
    let mut old=old.keys().peekable();
    for (key,_) in new {
        while old.peek().is_some_and(|candidate|*candidate<key) {old.next();}
        if old.peek().is_some_and(|candidate|*candidate==key) {
            return Err(ScriptError::resource("DOM metadata collides with an existing intrinsic"));
        }
    }
    Ok(())
}
fn merged_map<K:Ord,V>(old:BTreeMap<K,V>,new:Vec<(K,V)>,mut merged:Vec<(K,V)>)->BTreeMap<K,V> {
    let mut old=old.into_iter().peekable();
    let mut new=new.into_iter().peekable();
    while let (Some(a),Some(b))=(old.peek(),new.peek()) {
        match a.0.cmp(&b.0) {
            std::cmp::Ordering::Less=>merged.push(old.next().unwrap()),
            std::cmp::Ordering::Greater=>merged.push(new.next().unwrap()),
            std::cmp::Ordering::Equal=>unreachable!("prevalidated disjoint metadata maps"),
        }
    }
    merged.extend(old); merged.extend(new);
    merged.into_iter().collect()
}
