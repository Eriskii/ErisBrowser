//! Interface identity and prototype metadata for represented DOM nodes.
//! Other interface members remain explicitly incomplete; node brands are not
//! inferred from mutable JavaScript prototype membership.
use super::*;
use std::collections::btree_map::Entry;

mod interfaces;
#[cfg(test)]
mod tests;

use interfaces::{ConstructorKind, INTERFACES};
pub(super) const PREFIX: &str = "DOM.Interface.";
// Five unscopables objects: ParentNode's three including interfaces, plus
// CharacterData and DocumentType's ChildNode lists (Element combines both).
pub(super) const BOOTSTRAP_OBJECTS: usize = 352 + 2 * (INTERFACES.len() - 1) + 5;

#[derive(Default)]
pub(super) struct State {
    // Only genuine constructed nodes with an explicit different prototype
    // need an entry. Own descriptor bags remain independent.
    overrides: BTreeMap<NodeId, Value>,
}

pub(super) fn is_interface_name(name: &str) -> bool {
    name.starts_with(PREFIX)
}
fn tree_bound(count: usize) -> (usize, usize) {
    if count == 0 {
        return (0, 0);
    }
    let mut capacity = count.saturating_add(1) / 2;
    let mut height = 1;
    while capacity >= 6 {
        capacity /= 6;
        height += 1;
    }
    (count.min(11 * height), height)
}
fn search(count: usize, length: usize) -> usize {
    tree_bound(count).0.saturating_mul(1 + length / 8)
}
fn moves(count: usize) -> usize {
    if count < 11 {
        count + 8
    } else {
        28 * (tree_bound(count).1 + 1)
    }
}
fn node_bytes<K, V>() -> usize {
    16 * (std::mem::size_of::<K>() + std::mem::size_of::<V>())
        + 32 * std::mem::size_of::<usize>()
        + 64
}
fn insert_bytes<K, V>(count: usize) -> usize {
    if count == 0 {
        node_bytes::<K, V>()
    } else if count < 11 {
        0
    } else {
        (tree_bound(count).1 + 1) * node_bytes::<K, V>()
    }
}

impl Runtime {
    fn dom_proto_text(&mut self, text: &str) -> Result<JsString> {
        // Installer strings are static ASCII. Two copies: exact Vec then Rc.
        self.work(8 + 2 * text.len())?;
        self.charge(64 + 4 * text.len())?;
        let mut units = Vec::new();
        units
            .try_reserve_exact(text.len())
            .map_err(|_| ScriptError::resource("DOM prototype string allocation failed"))?;
        units.extend(text.bytes().map(u16::from));
        Ok(units.into())
    }
    fn dom_interface_value(&mut self, name: &str) -> Result<Value> {
        let length = PREFIX.len() + name.len();
        self.work(8 + length)?;
        self.charge(std::mem::size_of::<Native>() + 32 + length)?;
        let mut full = String::new();
        full.try_reserve_exact(length)
            .map_err(|_| ScriptError::resource("DOM interface name allocation failed"))?;
        full.push_str(PREFIX);
        full.push_str(name);
        Ok(Value::Native(Rc::new(Native {
            name: full,
            receiver: Value::Window,
        })))
    }
    fn dom_proto_object(&mut self, prototype: Option<Value>) -> Result<usize> {
        self.work(8)?;
        self.charge(
            72 + std::mem::size_of::<Option<AbortSlot>>() + std::mem::size_of::<Option<f64>>(),
        )?;
        if self.objects.len() == self.objects.capacity() {
            return Err(ScriptError::resource(
                "DOM prototype arena reservation exhausted",
            ));
        }
        let id = self.objects.len();
        self.objects.push(ScriptObject {
            prototype,
            ..ScriptObject::default()
        });
        Ok(id)
    }
    fn dom_proto_property(
        &mut self,
        owner: usize,
        key: PropertyKey,
        property: Property,
    ) -> Result<()> {
        let count = self.objects[owner].values.len();
        let length = key.as_string().map_or(0, JsString::len);
        let order = &self.objects[owner].order;
        let grow = order.len() == order.capacity();
        let capacity = order.len() + 1;
        self.work(search(count, length) + moves(count) + if grow { 1 + 2 * count } else { 1 })?;
        self.charge(
            256 + 4 * length
                + insert_bytes::<PropertyKey, Property>(count)
                + if grow {
                    capacity * std::mem::size_of::<PropertyKey>()
                } else {
                    0
                },
        )?;
        let bag = &mut self.objects[owner];
        if grow {
            bag.order
                .try_reserve_exact(1)
                .map_err(|_| ScriptError::resource("DOM prototype order allocation failed"))?;
        }
        let Entry::Vacant(entry) = bag.values.entry(key.clone()) else {
            return Err(ScriptError::resource("duplicate DOM prototype member"));
        };
        bag.order.push(key);
        entry.insert(property);
        Ok(())
    }
    pub(super) fn dom_proto_named(
        &mut self,
        owner: usize,
        key: &str,
        property: Property,
    ) -> Result<()> {
        let key = self.dom_proto_text(key)?.into();
        self.dom_proto_property(owner, key, property)
    }
    fn dom_proto_global(&mut self, name: &str, value: Value) -> Result<()> {
        let count = self.environments[0].bindings.len();
        self.work(search(count, name.len()) + moves(count) + name.len() + 4)?;
        self.charge(BINDING_BYTES + name.len() + insert_bytes::<String, Binding>(count))?;
        let order = self.next_global_order;
        let next = order
            .checked_add(1)
            .ok_or_else(|| ScriptError::resource("global creation order overflow"))?;
        let Entry::Vacant(entry) = self.environments[0].bindings.entry(name.to_owned()) else {
            return Err(ScriptError::resource("duplicate DOM interface global"));
        };
        entry.insert(Binding {
            value,
            accessor: None,
            mutable: true,
            initialized: true,
            strict_immutable: false,
            global_property: true,
            global_order: order,
            enumerable: false,
            deletable: true,
        });
        self.next_global_order = next;
        Ok(())
    }
    pub(super) fn dom_proto_id(&mut self, name: &str) -> Result<usize> {
        self.work(search(self.prototypes.len(), name.len()))?;
        self.prototypes
            .get(name)
            .copied()
            .ok_or_else(|| ScriptError::resource("DOM prototype parent missing"))
    }
    pub(super) fn initialize_dom_prototypes(&mut self) -> Result<()> {
        let tag_key = self.well_known_key("toStringTag");
        for interface in INTERFACES {
            if interface.name == "EventTarget" {
                let owner = self.dom_proto_id("EventTarget")?;
                let tag = self.dom_proto_text("EventTarget")?;
                self.dom_proto_property(
                    owner,
                    tag_key.clone(),
                    Property::data(Value::String(tag), false, false, true),
                )?;
                continue;
            }
            let parent = interface.parent.unwrap_or("Object");
            let parent_id = self.dom_proto_id(parent)?;
            self.work(search(self.environments[0].bindings.len(), parent.len()))?;
            let parent_constructor = if interface.parent.is_some() {
                self.environments[0]
                    .bindings
                    .get(parent)
                    .ok_or_else(|| ScriptError::resource("DOM constructor parent missing"))?
                    .value
                    .clone()
            } else {
                Value::Function(self.function_prototype)
            };
            let constructor = self.dom_interface_value(interface.name)?;
            let prototype = self.dom_proto_object(Some(Value::Object(parent_id)))?;
            let properties = self.dom_proto_object(Some(parent_constructor))?;
            let name = self.dom_proto_text(interface.name)?;
            self.dom_proto_named(
                properties,
                "length",
                Property::data(Value::Number(interface.length as f64), false, false, true),
            )?;
            self.dom_proto_named(
                properties,
                "name",
                Property::data(Value::String(name.clone()), false, false, true),
            )?;
            self.dom_proto_named(
                properties,
                "prototype",
                Property::data(Value::Object(prototype), false, false, false),
            )?;
            self.dom_proto_named(
                prototype,
                "constructor",
                Property::data(constructor.clone(), true, false, true),
            )?;
            self.dom_proto_property(
                prototype,
                tag_key.clone(),
                Property::data(Value::String(name), false, false, true),
            )?;
            let count = self.prototypes.len();
            self.work(search(count, interface.name.len()) + moves(count))?;
            self.charge(insert_bytes::<&'static str, usize>(count))?;
            let Entry::Vacant(entry) = self.prototypes.entry(interface.name) else {
                return Err(ScriptError::resource("duplicate DOM interface prototype"));
            };
            entry.insert(prototype);
            let Value::Native(native) = &constructor else {
                unreachable!()
            };
            let count = self.native_properties.len();
            self.work(search(count, native.name.len()) + moves(count) + native.name.len())?;
            self.charge(insert_bytes::<String, usize>(count) + native.name.len())?;
            let Entry::Vacant(entry) = self.native_properties.entry(native.name.clone()) else {
                return Err(ScriptError::resource("duplicate DOM interface constructor"));
            };
            entry.insert(properties);
            self.dom_proto_global(interface.name, constructor)?;
        }
        self.work(search(
            self.environments[0].bindings.len(),
            "Document".len(),
        ))?;
        let document = self.environments[0].bindings["Document"].value.clone();
        self.dom_proto_global("HTMLDocument", document)?;
        self.install_dom_parent_prototypes()?;
        let node = self.dom_proto_id("Node")?;
        self.work(search(self.environments[0].bindings.len(), 4))?;
        let constructor = self.environments[0].bindings["Node"].value.clone();
        let Value::Native(native) = constructor else {
            unreachable!()
        };
        self.work(search(self.native_properties.len(), native.name.len()))?;
        let constructor = self.native_properties[&native.name];
        for (key, value) in [
            ("ELEMENT_NODE", 1),
            ("ATTRIBUTE_NODE", 2),
            ("TEXT_NODE", 3),
            ("CDATA_SECTION_NODE", 4),
            ("ENTITY_REFERENCE_NODE", 5),
            ("ENTITY_NODE", 6),
            ("PROCESSING_INSTRUCTION_NODE", 7),
            ("COMMENT_NODE", 8),
            ("DOCUMENT_NODE", 9),
            ("DOCUMENT_TYPE_NODE", 10),
            ("DOCUMENT_FRAGMENT_NODE", 11),
            ("NOTATION_NODE", 12),
            ("DOCUMENT_POSITION_DISCONNECTED", 1),
            ("DOCUMENT_POSITION_PRECEDING", 2),
            ("DOCUMENT_POSITION_FOLLOWING", 4),
            ("DOCUMENT_POSITION_CONTAINS", 8),
            ("DOCUMENT_POSITION_CONTAINED_BY", 16),
            ("DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC", 32),
        ] {
            for owner in [node, constructor] {
                self.dom_proto_named(
                    owner,
                    key,
                    Property::data(Value::Number(value as f64), false, true, false),
                )?;
            }
        }
        for (name, keys) in [
            ("Document", &["prepend", "append", "replaceChildren"][..]),
            (
                "DocumentFragment",
                &["prepend", "append", "replaceChildren"][..],
            ),
            (
                "Element",
                &[
                    "prepend",
                    "append",
                    "replaceChildren",
                    "before",
                    "after",
                    "replaceWith",
                    "remove",
                ][..],
            ),
            (
                "CharacterData",
                &["before", "after", "replaceWith", "remove"][..],
            ),
            (
                "DocumentType",
                &["before", "after", "replaceWith", "remove"][..],
            ),
        ] {
            let owner = self.dom_proto_id(name)?;
            let bag = self.dom_proto_object(None)?;
            for key in keys {
                self.dom_proto_named(
                    bag,
                    key,
                    Property::data(Value::Bool(true), true, true, true),
                )?;
            }
            self.dom_proto_property(
                owner,
                self.well_known_key("unscopables"),
                Property::data(Value::Object(bag), false, false, true),
            )?;
        }
        Ok(())
    }
    pub(super) fn dom_interface_exists(&mut self, name: &str) -> Result<bool> {
        Ok(self.dom_interface_kind(name)?.is_some())
    }
    fn dom_interface_kind(&mut self, name: &str) -> Result<Option<ConstructorKind>> {
        let Some(name) = name.strip_prefix(PREFIX) else {
            return Ok(None);
        };
        self.work(interfaces::interface_lookup_work(name.len()))?;
        Ok(interfaces::interface(name).map(|interface| interface.constructor))
    }
    pub(super) fn prototype_of_in(
        &mut self,
        value: &Value,
        doc: &Document,
    ) -> Result<Option<Value>> {
        let id = match value {
            Value::Document => doc.root,
            Value::Node(id) => *id,
            _ => return Ok(self.prototype_of(value)),
        };
        self.work(search(self.dom_prototypes.overrides.len(), 0))?;
        if let Some(value) = self.dom_prototypes.overrides.get(&id) {
            return Ok(Some(value.clone()));
        }
        let work = interfaces::mapping_work(doc, id)
            .ok_or_else(|| ScriptError::type_error("invalid DOM node"))?;
        self.work(work)?;
        let name = interfaces::node_interface(doc, id)
            .ok_or_else(|| ScriptError::type_error("invalid DOM node"))?;
        Ok(Some(Value::Object(self.dom_proto_id(name)?)))
    }
    pub(super) fn dom_interface_construct(
        &mut self,
        name: &str,
        args: &[Value],
        new_target: Value,
        doc: &mut Document,
    ) -> Result<Value> {
        let kind = self
            .dom_interface_kind(name)?
            .ok_or_else(|| ScriptError::type_error("unknown DOM interface"))?;
        match kind {
            ConstructorKind::Illegal | ConstructorKind::Html => {
                return Err(ScriptError::type_error(
                    "illegal DOM interface construction",
                ));
            }
            ConstructorKind::Document | ConstructorKind::ProcessingInstruction => {
                return Err(ScriptError::unsupported(
                    "independent Document and ProcessingInstruction constructors are not implemented",
                ));
            }
            ConstructorKind::EventTarget => {
                return Err(ScriptError::type_error(
                    "invalid EventTarget constructor route",
                ));
            }
            _ => {}
        }
        let text = if matches!(kind, ConstructorKind::Text | ConstructorKind::Comment) {
            let text = match args.first() {
                None | Some(Value::Undefined) => JsString::default(),
                Some(value) => self.string_hint(value.clone(), doc)?,
            };
            self.work(1 + text.len())?;
            let mut bytes = 0usize;
            for scalar in char::decode_utf16(text.units().iter().copied()) {
                bytes += scalar
                    .map_err(|_| {
                        ScriptError::unsupported(
                            "unpaired surrogate DOMString storage is not implemented",
                        )
                    })?
                    .len_utf8();
            }
            self.work(1 + text.len())?;
            self.charge(bytes)?;
            let mut output = String::new();
            output
                .try_reserve_exact(bytes)
                .map_err(|_| ScriptError::resource("DOM constructor text allocation failed"))?;
            for scalar in char::decode_utf16(text.units().iter().copied()) {
                output.push(scalar.unwrap());
            }
            output
        } else {
            String::new()
        };
        let interface = name.strip_prefix(PREFIX).unwrap();
        let prototype = self.constructor_prototype(new_target, interface, doc)?;
        // Re-read document limits after every author conversion/prototype getter.
        if !doc.admits_text_node(text.len()) {
            return Err(ScriptError::resource(
                "DOM constructor node or text limit exceeded",
            ));
        }
        self.ensure_dom_capacity(doc, 1)?;
        let count = self.dom_prototypes.overrides.len();
        self.work(search(count, 0) + moves(count) + 1)?;
        self.charge(insert_bytes::<NodeId, Value>(count) + text.len())?;
        if doc.nodes.len() == doc.nodes.capacity() {
            self.work(1 + 2 * doc.nodes.len())?;
            self.charge(
                (doc.nodes.len() + 1).saturating_mul(std::mem::size_of::<crate::dom::Node>()),
            )?;
            doc.nodes
                .try_reserve_exact(1)
                .map_err(|_| ScriptError::resource("DOM constructor node allocation failed"))?;
        }
        let id = match kind {
            ConstructorKind::DocumentFragment => doc.create_document_fragment(),
            ConstructorKind::Text => doc.create_text_node(&text),
            ConstructorKind::Comment => doc.create_comment(&text),
            _ => unreachable!(),
        };
        self.dom_prototypes.overrides.insert(id, prototype);
        Ok(Value::Node(id))
    }
}
