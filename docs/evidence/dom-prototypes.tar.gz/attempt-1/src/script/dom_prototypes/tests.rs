use super::*;

#[test]
fn dom_prototypes_bootstrap_admission() {
    let mut runtime = Runtime::uninitialized();
    let result = runtime
        .reserve_bootstrap_objects()
        .and_then(|()| machine::initialize(&mut runtime))
        .and_then(|()| runtime.initialize_intrinsics());
    println!(
        "DOM_PROTOTYPE_BOOTSTRAP remaining={} allocated={} objects={} capacity={} native={} prototypes={} result={result:?}",
        runtime.steps,
        runtime.allocated,
        runtime.objects.len(),
        runtime.objects.capacity(),
        runtime.native_properties.len(),
        runtime.prototypes.len()
    );
    result.unwrap();
    assert_eq!(runtime.objects.len(), BOOTSTRAP_OBJECTS);
}

#[test]
fn dom_prototypes_independent_core_fixture_in_both_modes() {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut doc = Document::parse("<!doctype html><html><head></head><body></body></html>");
        let source = include_str!("../../../tests/fixtures/dom-prototypes.js");
        let result = if strict {
            runtime.execute_strict(source, &mut doc)
        } else {
            runtime.execute(source, &mut doc)
        };
        assert_eq!(result.unwrap(), Value::Bool(true));
        assert_eq!(runtime.calls, 0);
        assert_eq!(runtime.stack_units, 0);
        assert!(runtime.frames.is_empty());
    }
}
