//! Static initial interface identity for the represented DOM node kinds.
//!
//! Mapping sources (read 2026-10-02):
//! - https://dom.spec.whatwg.org/#interface-document
//! - https://html.spec.whatwg.org/multipage/indices.html#elements-3
//! - https://html.spec.whatwg.org/multipage/dom.html#elements-in-the-dom
//! - https://html.spec.whatwg.org/multipage/obsolete.html
//! - https://svgwg.org/svg2-draft/idl.html
//! - https://svgwg.org/svg2-draft/types.html#SVGDOMElements
//! - https://svgwg.org/specs/animations/
//! - https://www.w3.org/TR/filter-effects-1/#DOMInterfaces
//! - https://drafts.csswg.org/css-masking/#dom-interfaces
//! - https://w3c.github.io/mathml-core/#dom-and-javascript
//!
//! These names identify initial prototypes, not complete interface APIs. No
//! custom-element upgrade, arbitrary namespace, Attr, CDATASection, XMLDocument
//! or ShadowRoot is represented here. HTMLDocument is an alias for Document;
//! it must not create a second interface/prototype pair. A template fragment's
//! host does not turn the fragment into a ShadowRoot. Mutable prototype
//! overrides and authentic receiver brands belong to the caller.

use crate::dom::{Document, Namespace, NodeId, NodeKind};
use std::cmp::Ordering;

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ConstructorKind {
    /// No constructor operation: ordinary Call and attempted construction throw
    /// TypeError. WebIDL issue #698 leaves [[Construct]] presence ambiguous.
    Illegal,
    EventTarget,
    Document,
    DocumentFragment,
    Text,
    Comment,
    /// The current DOM standard declares a real (target, optional data) ctor.
    ProcessingInstruction,
    /// [HTMLConstructor]: direct new throws; successful construction requires
    /// custom-element registry/construction-stack semantics, outside this map.
    Html,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct Interface {
    pub(super) name: &'static str,
    /// None means Object.prototype for instances, Function.prototype for the
    /// interface object. Otherwise both chains use the named parent interface.
    pub(super) parent: Option<&'static str>,
    pub(super) constructor: ConstructorKind,
    pub(super) length: usize,
}

const fn entry(
    name: &'static str,
    parent: Option<&'static str>,
    constructor: ConstructorKind,
    length: usize,
) -> Interface {
    Interface {
        name,
        parent,
        constructor,
        length,
    }
}

/// Parent-before-child order. EventTarget already exists and must be reused.
pub(super) const INTERFACES: &[Interface] = &[
    entry("EventTarget", None, ConstructorKind::EventTarget, 0),
    entry("Node", Some("EventTarget"), ConstructorKind::Illegal, 0),
    entry("CharacterData", Some("Node"), ConstructorKind::Illegal, 0),
    entry(
        "Comment",
        Some("CharacterData"),
        ConstructorKind::Comment,
        0,
    ),
    entry("Document", Some("Node"), ConstructorKind::Document, 0),
    entry(
        "DocumentFragment",
        Some("Node"),
        ConstructorKind::DocumentFragment,
        0,
    ),
    entry("DocumentType", Some("Node"), ConstructorKind::Illegal, 0),
    entry("Element", Some("Node"), ConstructorKind::Illegal, 0),
    entry("HTMLElement", Some("Element"), ConstructorKind::Html, 0),
    entry(
        "HTMLAnchorElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLAreaElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMediaElement",
        Some("HTMLElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "HTMLAudioElement",
        Some("HTMLMediaElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLBRElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLBaseElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLBodyElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLButtonElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLCanvasElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDListElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDataElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDataListElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDetailsElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDialogElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDirectoryElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLDivElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLEmbedElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLFieldSetElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLFontElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLFormElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLFrameElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLFrameSetElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLHRElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLHeadElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLHeadingElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLHtmlElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLIFrameElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLImageElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLInputElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLLIElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLLabelElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLLegendElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLLinkElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMapElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMarqueeElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMenuElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMetaElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLMeterElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLModElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLOListElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLObjectElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLOptGroupElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLOptionElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLOutputElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLParagraphElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLParamElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLPictureElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLPreElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLProgressElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLQuoteElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLScriptElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLSelectElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLSelectedContentElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLSlotElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLSourceElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLSpanElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLStyleElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableCaptionElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableCellElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableColElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableRowElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTableSectionElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTemplateElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTextAreaElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTimeElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTitleElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLTrackElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLUListElement",
        Some("HTMLElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "HTMLUnknownElement",
        Some("HTMLElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "HTMLVideoElement",
        Some("HTMLMediaElement"),
        ConstructorKind::Html,
        0,
    ),
    entry(
        "MathMLElement",
        Some("Element"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "ProcessingInstruction",
        Some("CharacterData"),
        ConstructorKind::ProcessingInstruction,
        1,
    ),
    entry("SVGElement", Some("Element"), ConstructorKind::Illegal, 0),
    entry(
        "SVGGraphicsElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGAElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGAnimationElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGAnimateElement",
        Some("SVGAnimationElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGAnimateMotionElement",
        Some("SVGAnimationElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGAnimateTransformElement",
        Some("SVGAnimationElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGGeometryElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGCircleElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGClipPathElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGComponentTransferFunctionElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGDefsElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGDescElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGEllipseElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEBlendElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEColorMatrixElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEComponentTransferElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFECompositeElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEConvolveMatrixElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEDiffuseLightingElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEDisplacementMapElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEDistantLightElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEDropShadowElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEFloodElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEFuncAElement",
        Some("SVGComponentTransferFunctionElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEFuncBElement",
        Some("SVGComponentTransferFunctionElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEFuncGElement",
        Some("SVGComponentTransferFunctionElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEFuncRElement",
        Some("SVGComponentTransferFunctionElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEGaussianBlurElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEImageElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEMergeElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEMergeNodeElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEMorphologyElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEOffsetElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFEPointLightElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFESpecularLightingElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFESpotLightElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFETileElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFETurbulenceElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGFilterElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGForeignObjectElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGGElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGGradientElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGImageElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGLineElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGLinearGradientElement",
        Some("SVGGradientElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGMPathElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGMarkerElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGMaskElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGMetadataElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGPathElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGPatternElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGPolygonElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGPolylineElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGRadialGradientElement",
        Some("SVGGradientElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGRectElement",
        Some("SVGGeometryElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGSVGElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGScriptElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGSetElement",
        Some("SVGAnimationElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGStopElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGStyleElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGSwitchElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGSymbolElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTextContentElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTextPositioningElement",
        Some("SVGTextContentElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTSpanElement",
        Some("SVGTextPositioningElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTextElement",
        Some("SVGTextPositioningElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTextPathElement",
        Some("SVGTextContentElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGTitleElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGUseElement",
        Some("SVGGraphicsElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry(
        "SVGViewElement",
        Some("SVGElement"),
        ConstructorKind::Illegal,
        0,
    ),
    entry("Text", Some("CharacterData"), ConstructorKind::Text, 0),
];

// A separate sorted index permits bounded lookup without changing installation
// order or allocating an owned map. Each stored name is the descriptor's name.
const INTERFACE_INDEX: &[(&str, usize)] = &[
    ("CharacterData", 2),
    ("Comment", 3),
    ("Document", 4),
    ("DocumentFragment", 5),
    ("DocumentType", 6),
    ("Element", 7),
    ("EventTarget", 0),
    ("HTMLAnchorElement", 9),
    ("HTMLAreaElement", 10),
    ("HTMLAudioElement", 12),
    ("HTMLBRElement", 13),
    ("HTMLBaseElement", 14),
    ("HTMLBodyElement", 15),
    ("HTMLButtonElement", 16),
    ("HTMLCanvasElement", 17),
    ("HTMLDListElement", 18),
    ("HTMLDataElement", 19),
    ("HTMLDataListElement", 20),
    ("HTMLDetailsElement", 21),
    ("HTMLDialogElement", 22),
    ("HTMLDirectoryElement", 23),
    ("HTMLDivElement", 24),
    ("HTMLElement", 8),
    ("HTMLEmbedElement", 25),
    ("HTMLFieldSetElement", 26),
    ("HTMLFontElement", 27),
    ("HTMLFormElement", 28),
    ("HTMLFrameElement", 29),
    ("HTMLFrameSetElement", 30),
    ("HTMLHRElement", 31),
    ("HTMLHeadElement", 32),
    ("HTMLHeadingElement", 33),
    ("HTMLHtmlElement", 34),
    ("HTMLIFrameElement", 35),
    ("HTMLImageElement", 36),
    ("HTMLInputElement", 37),
    ("HTMLLIElement", 38),
    ("HTMLLabelElement", 39),
    ("HTMLLegendElement", 40),
    ("HTMLLinkElement", 41),
    ("HTMLMapElement", 42),
    ("HTMLMarqueeElement", 43),
    ("HTMLMediaElement", 11),
    ("HTMLMenuElement", 44),
    ("HTMLMetaElement", 45),
    ("HTMLMeterElement", 46),
    ("HTMLModElement", 47),
    ("HTMLOListElement", 48),
    ("HTMLObjectElement", 49),
    ("HTMLOptGroupElement", 50),
    ("HTMLOptionElement", 51),
    ("HTMLOutputElement", 52),
    ("HTMLParagraphElement", 53),
    ("HTMLParamElement", 54),
    ("HTMLPictureElement", 55),
    ("HTMLPreElement", 56),
    ("HTMLProgressElement", 57),
    ("HTMLQuoteElement", 58),
    ("HTMLScriptElement", 59),
    ("HTMLSelectElement", 60),
    ("HTMLSelectedContentElement", 61),
    ("HTMLSlotElement", 62),
    ("HTMLSourceElement", 63),
    ("HTMLSpanElement", 64),
    ("HTMLStyleElement", 65),
    ("HTMLTableCaptionElement", 66),
    ("HTMLTableCellElement", 67),
    ("HTMLTableColElement", 68),
    ("HTMLTableElement", 69),
    ("HTMLTableRowElement", 70),
    ("HTMLTableSectionElement", 71),
    ("HTMLTemplateElement", 72),
    ("HTMLTextAreaElement", 73),
    ("HTMLTimeElement", 74),
    ("HTMLTitleElement", 75),
    ("HTMLTrackElement", 76),
    ("HTMLUListElement", 77),
    ("HTMLUnknownElement", 78),
    ("HTMLVideoElement", 79),
    ("MathMLElement", 80),
    ("Node", 1),
    ("ProcessingInstruction", 81),
    ("SVGAElement", 84),
    ("SVGAnimateElement", 86),
    ("SVGAnimateMotionElement", 87),
    ("SVGAnimateTransformElement", 88),
    ("SVGAnimationElement", 85),
    ("SVGCircleElement", 90),
    ("SVGClipPathElement", 91),
    ("SVGComponentTransferFunctionElement", 92),
    ("SVGDefsElement", 93),
    ("SVGDescElement", 94),
    ("SVGElement", 82),
    ("SVGEllipseElement", 95),
    ("SVGFEBlendElement", 96),
    ("SVGFEColorMatrixElement", 97),
    ("SVGFEComponentTransferElement", 98),
    ("SVGFECompositeElement", 99),
    ("SVGFEConvolveMatrixElement", 100),
    ("SVGFEDiffuseLightingElement", 101),
    ("SVGFEDisplacementMapElement", 102),
    ("SVGFEDistantLightElement", 103),
    ("SVGFEDropShadowElement", 104),
    ("SVGFEFloodElement", 105),
    ("SVGFEFuncAElement", 106),
    ("SVGFEFuncBElement", 107),
    ("SVGFEFuncGElement", 108),
    ("SVGFEFuncRElement", 109),
    ("SVGFEGaussianBlurElement", 110),
    ("SVGFEImageElement", 111),
    ("SVGFEMergeElement", 112),
    ("SVGFEMergeNodeElement", 113),
    ("SVGFEMorphologyElement", 114),
    ("SVGFEOffsetElement", 115),
    ("SVGFEPointLightElement", 116),
    ("SVGFESpecularLightingElement", 117),
    ("SVGFESpotLightElement", 118),
    ("SVGFETileElement", 119),
    ("SVGFETurbulenceElement", 120),
    ("SVGFilterElement", 121),
    ("SVGForeignObjectElement", 122),
    ("SVGGElement", 123),
    ("SVGGeometryElement", 89),
    ("SVGGradientElement", 124),
    ("SVGGraphicsElement", 83),
    ("SVGImageElement", 125),
    ("SVGLineElement", 126),
    ("SVGLinearGradientElement", 127),
    ("SVGMPathElement", 128),
    ("SVGMarkerElement", 129),
    ("SVGMaskElement", 130),
    ("SVGMetadataElement", 131),
    ("SVGPathElement", 132),
    ("SVGPatternElement", 133),
    ("SVGPolygonElement", 134),
    ("SVGPolylineElement", 135),
    ("SVGRadialGradientElement", 136),
    ("SVGRectElement", 137),
    ("SVGSVGElement", 138),
    ("SVGScriptElement", 139),
    ("SVGSetElement", 140),
    ("SVGStopElement", 141),
    ("SVGStyleElement", 142),
    ("SVGSwitchElement", 143),
    ("SVGSymbolElement", 144),
    ("SVGTSpanElement", 147),
    ("SVGTextContentElement", 145),
    ("SVGTextElement", 148),
    ("SVGTextPathElement", 149),
    ("SVGTextPositioningElement", 146),
    ("SVGTitleElement", 150),
    ("SVGUseElement", 151),
    ("SVGViewElement", 152),
    ("Text", 153),
];

// Includes current HTML elements, obsolete-defined interfaces, the explicit
// obsolete fallbacks, and the eight reserved custom-element names.
const HTML_NAMES: &[(&str, &str)] = &[
    ("a", "HTMLAnchorElement"),
    ("abbr", "HTMLElement"),
    ("acronym", "HTMLElement"),
    ("address", "HTMLElement"),
    ("annotation-xml", "HTMLUnknownElement"),
    ("applet", "HTMLUnknownElement"),
    ("area", "HTMLAreaElement"),
    ("article", "HTMLElement"),
    ("aside", "HTMLElement"),
    ("audio", "HTMLAudioElement"),
    ("b", "HTMLElement"),
    ("base", "HTMLBaseElement"),
    ("basefont", "HTMLElement"),
    ("bdi", "HTMLElement"),
    ("bdo", "HTMLElement"),
    ("bgsound", "HTMLUnknownElement"),
    ("big", "HTMLElement"),
    ("blink", "HTMLUnknownElement"),
    ("blockquote", "HTMLQuoteElement"),
    ("body", "HTMLBodyElement"),
    ("br", "HTMLBRElement"),
    ("button", "HTMLButtonElement"),
    ("canvas", "HTMLCanvasElement"),
    ("caption", "HTMLTableCaptionElement"),
    ("center", "HTMLElement"),
    ("cite", "HTMLElement"),
    ("code", "HTMLElement"),
    ("col", "HTMLTableColElement"),
    ("colgroup", "HTMLTableColElement"),
    ("color-profile", "HTMLUnknownElement"),
    ("data", "HTMLDataElement"),
    ("datalist", "HTMLDataListElement"),
    ("dd", "HTMLElement"),
    ("del", "HTMLModElement"),
    ("details", "HTMLDetailsElement"),
    ("dfn", "HTMLElement"),
    ("dialog", "HTMLDialogElement"),
    ("dir", "HTMLDirectoryElement"),
    ("div", "HTMLDivElement"),
    ("dl", "HTMLDListElement"),
    ("dt", "HTMLElement"),
    ("em", "HTMLElement"),
    ("embed", "HTMLEmbedElement"),
    ("fieldset", "HTMLFieldSetElement"),
    ("figcaption", "HTMLElement"),
    ("figure", "HTMLElement"),
    ("font", "HTMLFontElement"),
    ("font-face", "HTMLUnknownElement"),
    ("font-face-format", "HTMLUnknownElement"),
    ("font-face-name", "HTMLUnknownElement"),
    ("font-face-src", "HTMLUnknownElement"),
    ("font-face-uri", "HTMLUnknownElement"),
    ("footer", "HTMLElement"),
    ("form", "HTMLFormElement"),
    ("frame", "HTMLFrameElement"),
    ("frameset", "HTMLFrameSetElement"),
    ("h1", "HTMLHeadingElement"),
    ("h2", "HTMLHeadingElement"),
    ("h3", "HTMLHeadingElement"),
    ("h4", "HTMLHeadingElement"),
    ("h5", "HTMLHeadingElement"),
    ("h6", "HTMLHeadingElement"),
    ("head", "HTMLHeadElement"),
    ("header", "HTMLElement"),
    ("hgroup", "HTMLElement"),
    ("hr", "HTMLHRElement"),
    ("html", "HTMLHtmlElement"),
    ("i", "HTMLElement"),
    ("iframe", "HTMLIFrameElement"),
    ("img", "HTMLImageElement"),
    ("input", "HTMLInputElement"),
    ("ins", "HTMLModElement"),
    ("isindex", "HTMLUnknownElement"),
    ("kbd", "HTMLElement"),
    ("keygen", "HTMLUnknownElement"),
    ("label", "HTMLLabelElement"),
    ("legend", "HTMLLegendElement"),
    ("li", "HTMLLIElement"),
    ("link", "HTMLLinkElement"),
    ("listing", "HTMLPreElement"),
    ("main", "HTMLElement"),
    ("map", "HTMLMapElement"),
    ("mark", "HTMLElement"),
    ("marquee", "HTMLMarqueeElement"),
    ("menu", "HTMLMenuElement"),
    ("meta", "HTMLMetaElement"),
    ("meter", "HTMLMeterElement"),
    ("missing-glyph", "HTMLUnknownElement"),
    ("multicol", "HTMLUnknownElement"),
    ("nav", "HTMLElement"),
    ("nextid", "HTMLUnknownElement"),
    ("nobr", "HTMLElement"),
    ("noembed", "HTMLElement"),
    ("noframes", "HTMLElement"),
    ("noscript", "HTMLElement"),
    ("object", "HTMLObjectElement"),
    ("ol", "HTMLOListElement"),
    ("optgroup", "HTMLOptGroupElement"),
    ("option", "HTMLOptionElement"),
    ("output", "HTMLOutputElement"),
    ("p", "HTMLParagraphElement"),
    ("param", "HTMLParamElement"),
    ("picture", "HTMLPictureElement"),
    ("plaintext", "HTMLElement"),
    ("pre", "HTMLPreElement"),
    ("progress", "HTMLProgressElement"),
    ("q", "HTMLQuoteElement"),
    ("rb", "HTMLElement"),
    ("rp", "HTMLElement"),
    ("rt", "HTMLElement"),
    ("rtc", "HTMLElement"),
    ("ruby", "HTMLElement"),
    ("s", "HTMLElement"),
    ("samp", "HTMLElement"),
    ("script", "HTMLScriptElement"),
    ("search", "HTMLElement"),
    ("section", "HTMLElement"),
    ("select", "HTMLSelectElement"),
    ("selectedcontent", "HTMLSelectedContentElement"),
    ("slot", "HTMLSlotElement"),
    ("small", "HTMLElement"),
    ("source", "HTMLSourceElement"),
    ("spacer", "HTMLUnknownElement"),
    ("span", "HTMLSpanElement"),
    ("strike", "HTMLElement"),
    ("strong", "HTMLElement"),
    ("style", "HTMLStyleElement"),
    ("sub", "HTMLElement"),
    ("summary", "HTMLElement"),
    ("sup", "HTMLElement"),
    ("table", "HTMLTableElement"),
    ("tbody", "HTMLTableSectionElement"),
    ("td", "HTMLTableCellElement"),
    ("template", "HTMLTemplateElement"),
    ("textarea", "HTMLTextAreaElement"),
    ("tfoot", "HTMLTableSectionElement"),
    ("th", "HTMLTableCellElement"),
    ("thead", "HTMLTableSectionElement"),
    ("time", "HTMLTimeElement"),
    ("title", "HTMLTitleElement"),
    ("tr", "HTMLTableRowElement"),
    ("track", "HTMLTrackElement"),
    ("tt", "HTMLElement"),
    ("u", "HTMLElement"),
    ("ul", "HTMLUListElement"),
    ("var", "HTMLElement"),
    ("video", "HTMLVideoElement"),
    ("wbr", "HTMLElement"),
    ("xmp", "HTMLPreElement"),
];

const SVG_NAMES: &[(&str, &str)] = &[
    ("a", "SVGAElement"),
    ("animate", "SVGAnimateElement"),
    ("animateMotion", "SVGAnimateMotionElement"),
    ("animateTransform", "SVGAnimateTransformElement"),
    ("circle", "SVGCircleElement"),
    ("clipPath", "SVGClipPathElement"),
    ("defs", "SVGDefsElement"),
    ("desc", "SVGDescElement"),
    ("ellipse", "SVGEllipseElement"),
    ("feBlend", "SVGFEBlendElement"),
    ("feColorMatrix", "SVGFEColorMatrixElement"),
    ("feComponentTransfer", "SVGFEComponentTransferElement"),
    ("feComposite", "SVGFECompositeElement"),
    ("feConvolveMatrix", "SVGFEConvolveMatrixElement"),
    ("feDiffuseLighting", "SVGFEDiffuseLightingElement"),
    ("feDisplacementMap", "SVGFEDisplacementMapElement"),
    ("feDistantLight", "SVGFEDistantLightElement"),
    ("feDropShadow", "SVGFEDropShadowElement"),
    ("feFlood", "SVGFEFloodElement"),
    ("feFuncA", "SVGFEFuncAElement"),
    ("feFuncB", "SVGFEFuncBElement"),
    ("feFuncG", "SVGFEFuncGElement"),
    ("feFuncR", "SVGFEFuncRElement"),
    ("feGaussianBlur", "SVGFEGaussianBlurElement"),
    ("feImage", "SVGFEImageElement"),
    ("feMerge", "SVGFEMergeElement"),
    ("feMergeNode", "SVGFEMergeNodeElement"),
    ("feMorphology", "SVGFEMorphologyElement"),
    ("feOffset", "SVGFEOffsetElement"),
    ("fePointLight", "SVGFEPointLightElement"),
    ("feSpecularLighting", "SVGFESpecularLightingElement"),
    ("feSpotLight", "SVGFESpotLightElement"),
    ("feTile", "SVGFETileElement"),
    ("feTurbulence", "SVGFETurbulenceElement"),
    ("filter", "SVGFilterElement"),
    ("foreignObject", "SVGForeignObjectElement"),
    ("g", "SVGGElement"),
    ("image", "SVGImageElement"),
    ("line", "SVGLineElement"),
    ("linearGradient", "SVGLinearGradientElement"),
    ("marker", "SVGMarkerElement"),
    ("mask", "SVGMaskElement"),
    ("metadata", "SVGMetadataElement"),
    ("mpath", "SVGMPathElement"),
    ("path", "SVGPathElement"),
    ("pattern", "SVGPatternElement"),
    ("polygon", "SVGPolygonElement"),
    ("polyline", "SVGPolylineElement"),
    ("radialGradient", "SVGRadialGradientElement"),
    ("rect", "SVGRectElement"),
    ("script", "SVGScriptElement"),
    ("set", "SVGSetElement"),
    ("stop", "SVGStopElement"),
    ("style", "SVGStyleElement"),
    ("svg", "SVGSVGElement"),
    ("switch", "SVGSwitchElement"),
    ("symbol", "SVGSymbolElement"),
    ("text", "SVGTextElement"),
    ("textPath", "SVGTextPathElement"),
    ("title", "SVGTitleElement"),
    ("tspan", "SVGTSpanElement"),
    ("use", "SVGUseElement"),
    ("view", "SVGViewElement"),
];

const fn max_name_bytes<T>(table: &[(&str, T)]) -> usize {
    let mut maximum = 0;
    let mut at = 0;
    while at < table.len() {
        let length = table[at].0.len();
        if length > maximum {
            maximum = length;
        }
        at += 1;
    }
    maximum
}

const HTML_MAX_NAME: usize = max_name_bytes(HTML_NAMES);
const SVG_MAX_NAME: usize = max_name_bytes(SVG_NAMES);
const INTERFACE_MAX_NAME: usize = max_name_bytes(INTERFACE_INDEX);

fn lookup<T: Copy>(table: &[(&str, T)], name: &str) -> Option<T> {
    let mut low = 0;
    let mut high = table.len();
    while low < high {
        let middle = low + (high - low) / 2;
        match table[middle].0.cmp(name) {
            Ordering::Less => low = middle + 1,
            Ordering::Greater => high = middle,
            Ordering::Equal => return Some(table[middle].1),
        }
    }
    None
}

// floor(log2(count)) + 1 bounds comparisons in the explicit binary search.
// Each comparison reserves its possible byte prefix plus 9 fixed units for
// length/order decisions and loop bookkeeping. No name scan happens here.
fn lookup_work(count: usize, maximum: usize, name_bytes: usize) -> usize {
    let comparisons = usize::BITS as usize - count.leading_zeros() as usize;
    comparisons * (name_bytes.min(maximum) + 9)
}

/// Prepay before interface_index(name) or interface(name) for a runtime name.
/// This is separate from caller-owned prototype/native registry lookup fees.
pub(super) fn interface_lookup_work(name_bytes: usize) -> usize {
    lookup_work(INTERFACE_INDEX.len(), INTERFACE_MAX_NAME, name_bytes)
}

/// Index into INTERFACES, using the same single prepaid name lookup.
pub(super) fn interface_index(name: &str) -> Option<usize> {
    lookup(INTERFACE_INDEX, name)
}

pub(super) fn interface(name: &str) -> Option<&'static Interface> {
    interface_index(name).map(|index| &INTERFACES[index])
}

/// Existing lexicographic interface-name order; no sorting or allocation.
/// Callers account for each visited index and any retained copy.
pub(super) fn interface_order() -> impl Iterator<Item = usize> {
    INTERFACE_INDEX.iter().map(|&(_, index)| index)
}

fn element_mapping_work(namespace: Namespace, name_bytes: usize) -> Option<usize> {
    match namespace {
        // The custom-name fallback makes one complete byte pass at most:
        // one visit plus one classification unit per byte, prepaid even on a
        // successful ordinary-tag lookup. Checked arithmetic refuses overflow.
        Namespace::Html => name_bytes
            .checked_mul(2)?
            .checked_add(lookup_work(HTML_NAMES.len(), HTML_MAX_NAME, name_bytes))?
            .checked_add(4),
        Namespace::Svg => Some(lookup_work(SVG_NAMES.len(), SVG_MAX_NAME, name_bytes) + 4),
        Namespace::MathMl => Some(4),
    }
}

/// Pure O(1) preflight: callers must pay this before node_interface. None means
/// an invalid NodeId or arithmetic overflow, never permission for free lookup.
/// It covers only initial node/tag mapping; it allocates no storage.
pub(super) fn mapping_work(doc: &Document, id: NodeId) -> Option<usize> {
    match &doc.nodes.get(id)?.kind {
        NodeKind::Element(element) => element_mapping_work(element.namespace, element.tag.len()),
        _ => Some(4),
    }
}

/// Must follow successful mapping_work prepayment. Uses the stored namespace
/// and local name, without lowercasing, cloning, parsing, callbacks or mutation.
pub(super) fn node_interface(doc: &Document, id: NodeId) -> Option<&'static str> {
    Some(match &doc.nodes.get(id)?.kind {
        NodeKind::Document => "Document",
        NodeKind::DocumentFragment { .. } => "DocumentFragment",
        NodeKind::Element(element) => element_interface(element.namespace, &element.tag),
        NodeKind::Text(_) => "Text",
        NodeKind::Comment(_) => "Comment",
        NodeKind::Doctype(_) => "DocumentType",
        NodeKind::ProcessingInstruction { .. } => "ProcessingInstruction",
    })
}

fn element_interface(namespace: Namespace, name: &str) -> &'static str {
    match namespace {
        Namespace::Html => lookup(HTML_NAMES, name).unwrap_or_else(|| {
            if custom_name_after_reserved_lookup(name) {
                "HTMLElement"
            } else {
                "HTMLUnknownElement"
            }
        }),
        Namespace::Svg => lookup(SVG_NAMES, name).unwrap_or("SVGElement"),
        Namespace::MathMl => "MathMLElement",
    }
}

// Current HTML valid-custom-element-name references DOM's valid-element-local-
// name, rather than the older PCENChar grammar:
// https://html.spec.whatwg.org/multipage/custom-elements.html#valid-custom-element-name
// https://dom.spec.whatwg.org/#valid-element-local-name
// Once the required first lowercase ASCII letter is established, the current
// local-name rule rejects only ASCII whitespace, NULL, '/' and '>'. Also reject
// uppercase ASCII and require a hyphen. UTF-8 bytes >= 128 cannot be an excluded
// ASCII code point, so this single byte pass preserves all represented scalars.
// The eight reserved names have already matched HTML_NAMES.
fn custom_name_after_reserved_lookup(name: &str) -> bool {
    if !name.as_bytes().first().is_some_and(u8::is_ascii_lowercase) {
        return false;
    }
    let mut hyphen = false;
    for byte in name.bytes() {
        if byte.is_ascii_uppercase()
            || matches!(
                byte,
                0 | b'\t' | b'\n' | b'\x0c' | b'\r' | b' ' | b'/' | b'>'
            )
        {
            return false;
        }
        hyphen |= byte == b'-';
    }
    hyphen
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::dom::{Element, Node};
    use std::collections::BTreeMap;

    #[test]
    fn inventory_is_unique_parent_first_and_all_lookup_rows_are_bound() {
        assert_eq!(INTERFACES.len(), 154);
        assert_eq!(INTERFACE_INDEX.len(), INTERFACES.len());
        for (index, descriptor) in INTERFACES.iter().enumerate() {
            assert_eq!(interface_index(descriptor.name), Some(index));
            assert_eq!(interface(descriptor.name), Some(descriptor));
            assert!(
                !INTERFACES[..index]
                    .iter()
                    .any(|row| row.name == descriptor.name)
            );
            if let Some(parent) = descriptor.parent {
                assert!(INTERFACES[..index].iter().any(|row| row.name == parent));
            } else {
                assert_eq!(descriptor.name, "EventTarget");
            }
        }
        assert!(interface_order().eq(INTERFACE_INDEX.iter().map(|row| row.1)));
        assert!(INTERFACE_INDEX.windows(2).all(|rows| rows[0].0 < rows[1].0));
        for &(name, index) in INTERFACE_INDEX {
            assert_eq!(INTERFACES[index].name, name);
        }
        for absent in [
            "HTMLDocument",
            "Attr",
            "CDATASection",
            "XMLDocument",
            "ShadowRoot",
        ] {
            assert_eq!(interface_index(absent), None, "{absent}");
            assert_eq!(interface(absent), None, "{absent}");
        }
    }

    #[test]
    fn constructor_categories_preserve_real_and_conditional_construction() {
        for (name, kind, length) in [
            ("Node", ConstructorKind::Illegal, 0),
            ("Element", ConstructorKind::Illegal, 0),
            ("CharacterData", ConstructorKind::Illegal, 0),
            ("DocumentType", ConstructorKind::Illegal, 0),
            ("Document", ConstructorKind::Document, 0),
            ("DocumentFragment", ConstructorKind::DocumentFragment, 0),
            ("Text", ConstructorKind::Text, 0),
            ("Comment", ConstructorKind::Comment, 0),
            (
                "ProcessingInstruction",
                ConstructorKind::ProcessingInstruction,
                1,
            ),
            ("EventTarget", ConstructorKind::EventTarget, 0),
            ("HTMLElement", ConstructorKind::Html, 0),
            ("HTMLDivElement", ConstructorKind::Html, 0),
            ("HTMLUnknownElement", ConstructorKind::Illegal, 0),
            ("HTMLMediaElement", ConstructorKind::Illegal, 0),
            ("SVGSVGElement", ConstructorKind::Illegal, 0),
            ("MathMLElement", ConstructorKind::Illegal, 0),
        ] {
            let descriptor = interface(name).unwrap();
            assert_eq!(
                (descriptor.constructor, descriptor.length),
                (kind, length),
                "{name}"
            );
        }
    }

    #[test]
    fn static_tag_tables_are_ordered_and_target_declared_interfaces() {
        assert_eq!(HTML_NAMES.len(), 149);
        assert_eq!(SVG_NAMES.len(), 63);
        for table in [HTML_NAMES, SVG_NAMES] {
            assert!(table.windows(2).all(|rows| rows[0].0 < rows[1].0));
            for &(name, target) in table {
                assert_eq!(lookup(table, name), Some(target));
                assert!(interface(target).is_some(), "{name}: {target}");
            }
        }
    }

    #[test]
    fn html_literal_families_keep_the_most_derived_interface() {
        for (tag, expected) in [
            ("section", "HTMLElement"),
            ("article", "HTMLElement"),
            ("search", "HTMLElement"),
            ("div", "HTMLDivElement"),
            ("a", "HTMLAnchorElement"),
            ("audio", "HTMLAudioElement"),
            ("video", "HTMLVideoElement"),
            ("h1", "HTMLHeadingElement"),
            ("h6", "HTMLHeadingElement"),
            ("q", "HTMLQuoteElement"),
            ("blockquote", "HTMLQuoteElement"),
            ("ins", "HTMLModElement"),
            ("del", "HTMLModElement"),
            ("col", "HTMLTableColElement"),
            ("colgroup", "HTMLTableColElement"),
            ("td", "HTMLTableCellElement"),
            ("th", "HTMLTableCellElement"),
            ("tbody", "HTMLTableSectionElement"),
            ("tfoot", "HTMLTableSectionElement"),
            ("thead", "HTMLTableSectionElement"),
            ("template", "HTMLTemplateElement"),
            ("slot", "HTMLSlotElement"),
            ("selectedcontent", "HTMLSelectedContentElement"),
        ] {
            assert_eq!(element_interface(Namespace::Html, tag), expected, "{tag}");
        }
        assert_eq!(
            interface("HTMLAudioElement").unwrap().parent,
            Some("HTMLMediaElement")
        );
        assert_eq!(
            interface("HTMLVideoElement").unwrap().parent,
            Some("HTMLMediaElement")
        );
        assert_eq!(
            interface("HTMLMediaElement").unwrap().parent,
            Some("HTMLElement")
        );
        assert_eq!(interface("HTMLElement").unwrap().parent, Some("Element"));
    }

    #[test]
    fn obsolete_html_rules_and_custom_reserved_names_are_not_conflated() {
        for tag in [
            "applet",
            "bgsound",
            "blink",
            "isindex",
            "keygen",
            "multicol",
            "nextid",
            "spacer",
            "annotation-xml",
            "color-profile",
            "font-face",
            "font-face-src",
            "font-face-uri",
            "font-face-format",
            "font-face-name",
            "missing-glyph",
        ] {
            assert_eq!(
                element_interface(Namespace::Html, tag),
                "HTMLUnknownElement",
                "{tag}"
            );
        }
        for tag in [
            "acronym",
            "basefont",
            "big",
            "center",
            "nobr",
            "noembed",
            "noframes",
            "plaintext",
            "rb",
            "rtc",
            "strike",
            "tt",
        ] {
            assert_eq!(
                element_interface(Namespace::Html, tag),
                "HTMLElement",
                "{tag}"
            );
        }
        for (tag, expected) in [
            ("listing", "HTMLPreElement"),
            ("xmp", "HTMLPreElement"),
            ("dir", "HTMLDirectoryElement"),
            ("font", "HTMLFontElement"),
            ("frame", "HTMLFrameElement"),
            ("frameset", "HTMLFrameSetElement"),
            ("marquee", "HTMLMarqueeElement"),
            ("param", "HTMLParamElement"),
        ] {
            assert_eq!(element_interface(Namespace::Html, tag), expected, "{tag}");
        }
    }

    #[test]
    fn current_custom_names_use_ascii_exclusions_not_old_pcen_ranges() {
        for name in [
            "x-",
            "x-widget",
            "math-α",
            "emotion-😍",
            "x-:",
            "x-!",
            "x-=",
            "x-\u{b}",
            "x-\u{80}",
            "x-\u{ffff}",
            "x-\u{10ffff}",
        ] {
            assert_eq!(
                element_interface(Namespace::Html, name),
                "HTMLElement",
                "{name:?}"
            );
        }
        for name in [
            "",
            "widget",
            "X-widget",
            "x-Widget",
            "-widget",
            "1-widget",
            "α-widget",
            "x-\0",
            "x-\t",
            "x-\n",
            "x-\u{c}",
            "x-\r",
            "x- ",
            "x-/",
            "x->",
        ] {
            assert_eq!(
                element_interface(Namespace::Html, name),
                "HTMLUnknownElement",
                "{name:?}"
            );
        }
    }

    #[test]
    fn svg_literal_chains_namespace_and_case_are_preserved() {
        for (tag, expected, parent) in [
            ("svg", "SVGSVGElement", "SVGGraphicsElement"),
            ("symbol", "SVGSymbolElement", "SVGGraphicsElement"),
            ("clipPath", "SVGClipPathElement", "SVGElement"),
            ("mask", "SVGMaskElement", "SVGElement"),
            ("path", "SVGPathElement", "SVGGeometryElement"),
            ("text", "SVGTextElement", "SVGTextPositioningElement"),
            ("tspan", "SVGTSpanElement", "SVGTextPositioningElement"),
            ("textPath", "SVGTextPathElement", "SVGTextContentElement"),
            (
                "linearGradient",
                "SVGLinearGradientElement",
                "SVGGradientElement",
            ),
            ("animate", "SVGAnimateElement", "SVGAnimationElement"),
            ("mpath", "SVGMPathElement", "SVGElement"),
            (
                "feFuncR",
                "SVGFEFuncRElement",
                "SVGComponentTransferFunctionElement",
            ),
            ("feDropShadow", "SVGFEDropShadowElement", "SVGElement"),
        ] {
            assert_eq!(element_interface(Namespace::Svg, tag), expected, "{tag}");
            assert_eq!(interface(expected).unwrap().parent, Some(parent));
        }
        for tag in ["div", "x-widget", "lineargradient", "unknown"] {
            assert_eq!(
                element_interface(Namespace::Svg, tag),
                "SVGElement",
                "{tag}"
            );
        }
        assert_eq!(
            element_interface(Namespace::Html, "DIV"),
            "HTMLUnknownElement"
        );
        for tag in ["math", "mrow", "mi", "annotation-xml", "svg", "unknown"] {
            assert_eq!(element_interface(Namespace::MathMl, tag), "MathMLElement");
        }
    }

    #[test]
    fn stored_parser_namespaces_and_template_fragments_drive_mapping() {
        let mut doc = Document::parse(
            "<!doctype html><body><svg id='s'><linearGradient id='g'></linearGradient><foreignObject><div id='h'></div></foreignObject></svg><math><mrow id='m'></mrow></math><template id='t'></template>",
        );
        for (selector, expected) in [
            ("#s", "SVGSVGElement"),
            ("#g", "SVGLinearGradientElement"),
            ("#h", "HTMLDivElement"),
            ("#m", "MathMLElement"),
            ("#t", "HTMLTemplateElement"),
        ] {
            assert_eq!(
                node_interface(&doc, doc.query_selector(selector).unwrap()),
                Some(expected)
            );
        }
        assert_eq!(node_interface(&doc, doc.root), Some("Document"));
        let template = doc.query_selector("#t").unwrap();
        assert_eq!(
            node_interface(&doc, doc.template_contents(template).unwrap()),
            Some("DocumentFragment")
        );
        let fragment = doc.create_document_fragment();
        let text = doc.create_text_node("x");
        let comment = doc.create_comment("x");
        let pi = doc.create_processing_instruction("target", "data");
        for (node, expected) in [
            (fragment, "DocumentFragment"),
            (text, "Text"),
            (comment, "Comment"),
            (pi, "ProcessingInstruction"),
        ] {
            assert_eq!(node_interface(&doc, node), Some(expected));
            assert_eq!(mapping_work(&doc, node), Some(4));
        }
        let doctype = doc
            .nodes
            .iter()
            .position(|node| matches!(node.kind, NodeKind::Doctype(_)))
            .unwrap();
        assert_eq!(node_interface(&doc, doctype), Some("DocumentType"));
        assert_eq!(node_interface(&doc, usize::MAX), None);
        assert_eq!(mapping_work(&doc, usize::MAX), None);
    }

    #[test]
    fn mapping_preflight_accounts_long_names_and_refuses_arithmetic_overflow() {
        let mut doc = Document::parse("");
        let tag = format!("x-{}", "a".repeat(8192));
        let bytes = tag.len();
        let id = doc.nodes.len();
        // Direct stored-node fixture avoids the separate parser/createElement
        // name clamp; it tests mapping's own length bound and no normalization.
        doc.nodes.push(Node {
            parent: None,
            children: Vec::new(),
            kind: NodeKind::Element(Element {
                namespace: Namespace::Html,
                tag,
                attrs: BTreeMap::new(),
                attr_namespaces: BTreeMap::new(),
                template_contents: None,
            }),
        });
        let paid = mapping_work(&doc, id).unwrap();
        assert!(paid >= bytes * 2);
        assert!(paid > mapping_work(&doc, doc.root).unwrap());
        assert_eq!(node_interface(&doc, id), Some("HTMLElement"));
        assert_eq!(element_mapping_work(Namespace::Html, usize::MAX), None);
        assert_eq!(element_mapping_work(Namespace::MathMl, usize::MAX), Some(4));
        // Table comparisons are bounded by their short static keys, so an
        // unbounded lookup key cannot overflow or force a full suffix scan.
        assert_eq!(
            interface_lookup_work(usize::MAX),
            interface_lookup_work(INTERFACE_MAX_NAME)
        );
        assert!(interface_lookup_work(0) > 0);
    }
}
