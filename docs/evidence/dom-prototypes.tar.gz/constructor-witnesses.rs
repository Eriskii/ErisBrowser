// Append within dom_prototypes::tests (which already imports super::*).
// Private constructor witnesses; callback-mutation cases are authored separately.

fn constructor_witness_clean(runtime: &Runtime) {
    assert_eq!(runtime.calls, 0);
    assert_eq!(runtime.stack_units, 0);
    assert_eq!(runtime.eval_depth, 0);
    assert!(runtime.frames.is_empty());
}

fn constructor_witness_target(
    runtime: &mut Runtime,
    doc: &mut Document,
    prototype: Value,
) -> Value {
    let target = runtime
        .execute("(function ConstructorWitness() {}).bind(null)", doc)
        .unwrap();
    assert!(runtime.is_constructor(target.clone()).unwrap());
    assert!(
        runtime
            .define_own(
                &target,
                &"prototype".into(),
                PropertyDescriptor::data_property(prototype, true, false, true),
            )
            .unwrap()
    );
    target
}

fn constructor_witness_id(value: Value) -> NodeId {
    let Value::Node(id) = value else {
        panic!("constructor did not return a genuine node: {value:?}");
    };
    id
}

fn constructor_witness_kind(doc: &Document, id: NodeId, name: &str, text: &str) {
    assert_eq!(doc.nodes[id].parent, None);
    assert!(doc.nodes[id].children.is_empty());
    match (&doc.nodes[id].kind, name) {
        (NodeKind::DocumentFragment { host: None }, "DocumentFragment") => {}
        (NodeKind::Text(value), "Text") | (NodeKind::Comment(value), "Comment") => {
            assert_eq!(value, text);
        }
        other => panic!("unexpected node kind: {other:?}"),
    }
}

#[test]
fn dom_constructor_default_and_primitive_fallback_keep_overrides_sparse() {
    for name in ["DocumentFragment", "Text", "Comment"] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut doc = Document::parse("<p>kept</p>");
        let default = Value::Object(runtime.dom_proto_id(name).unwrap());
        let constructor = runtime.environments[0].bindings[name].value.clone();
        let fallback = constructor_witness_target(&mut runtime, &mut doc, Value::Null);
        for target in [constructor, fallback] {
            let count = doc.nodes.len();
            let value = runtime
                .dom_interface_construct(&format!("{PREFIX}{name}"), &[], target, &mut doc)
                .unwrap();
            let id = constructor_witness_id(value.clone());
            assert_eq!(id, count);
            assert_eq!(doc.nodes.len(), count + 1);
            constructor_witness_kind(&doc, id, name, "");
            assert_eq!(
                runtime.prototype_of_in(&value, &doc).unwrap(),
                Some(default.clone())
            );
            assert!(runtime.dom_prototypes.overrides.is_empty());
            constructor_witness_clean(&runtime);
        }
    }
}

#[test]
fn dom_constructor_explicit_prototype_preserves_distinct_native_node_identity() {
    for name in ["DocumentFragment", "Text", "Comment"] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut doc = Document::parse("<p>kept</p>");
        let prototype = runtime.object_ordered([]).unwrap();
        let target = constructor_witness_target(&mut runtime, &mut doc, prototype.clone());
        let first = doc.nodes.len();
        for expected in [first, first + 1] {
            let value = runtime
                .dom_interface_construct(
                    &format!("{PREFIX}{name}"),
                    &[Value::String("A𝄞".into())],
                    target.clone(),
                    &mut doc,
                )
                .unwrap();
            let id = constructor_witness_id(value.clone());
            assert_eq!(id, expected);
            constructor_witness_kind(&doc, id, name, "A𝄞");
            assert_eq!(runtime.dom_prototypes.overrides.get(&id), Some(&prototype));
            assert_eq!(
                runtime.prototype_of_in(&value, &doc).unwrap(),
                Some(prototype.clone())
            );
        }
        assert_eq!(doc.nodes.len(), first + 2);
        assert_eq!(runtime.dom_prototypes.overrides.len(), 2);
        constructor_witness_clean(&runtime);
    }
}

fn constructor_witness_cutpoint_setup(grow: bool) -> (Runtime, Document, Value, Value) {
    let mut runtime = Runtime::try_new().unwrap();
    let mut doc = Document::parse("<p>kept</p>");
    let prototype = runtime.object_ordered([]).unwrap();
    let target = constructor_witness_target(&mut runtime, &mut doc, prototype.clone());
    // Test-owned capacity setup, outside the measured constructor span.
    doc.nodes = doc.nodes.into_boxed_slice().into_vec();
    assert_eq!(doc.nodes.len(), doc.nodes.capacity());
    if !grow {
        doc.nodes.try_reserve_exact(1).unwrap();
        assert!(doc.nodes.capacity() > doc.nodes.len());
    }
    runtime.steps = MAX_STEPS;
    (runtime, doc, target, prototype)
}

#[test]
fn dom_constructor_measured_exact_and_one_short_admission_has_no_partial_node() {
    for grow in [false, true] {
        let arguments = [Value::String("A𝄞".into())];
        let (mut measure, mut doc, target, _) = constructor_witness_cutpoint_setup(grow);
        let before_heap = measure.allocated;
        measure
            .dom_interface_construct("DOM.Interface.Text", &arguments, target, &mut doc)
            .unwrap();
        let work = MAX_STEPS - measure.steps;
        let heap = measure.allocated - before_heap;
        assert!(work > 0 && heap > 0);
        // Measure real debits; do not duplicate the production fee formula.
        for (steps, available, succeeds) in [
            (work, heap, true),
            (work - 1, heap, false),
            (work, heap - 1, false),
        ] {
            let (mut runtime, mut doc, target, prototype) =
                constructor_witness_cutpoint_setup(grow);
            let before = format!("{doc:?}");
            let count = doc.nodes.len();
            let capacity = doc.nodes.capacity();
            runtime.steps = steps;
            runtime.allocated = MAX_HEAP - available;
            let result =
                runtime.dom_interface_construct("DOM.Interface.Text", &arguments, target, &mut doc);
            if succeeds {
                assert_eq!(constructor_witness_id(result.unwrap()), count);
                assert_eq!(doc.nodes.len(), count + 1);
                constructor_witness_kind(&doc, count, "Text", "A𝄞");
                assert_eq!(
                    runtime.dom_prototypes.overrides.get(&count),
                    Some(&prototype)
                );
                assert_eq!(runtime.dom_prototypes.overrides.len(), 1);
                assert_eq!(runtime.steps, 0);
                assert_eq!(runtime.allocated, MAX_HEAP);
            } else {
                assert!(result.unwrap_err().is_resource_limit());
                assert_eq!(format!("{doc:?}"), before);
                assert_eq!(doc.nodes.capacity(), capacity);
                assert!(runtime.dom_prototypes.overrides.is_empty());
            }
            constructor_witness_clean(&runtime);
        }
    }
}

#[test]
fn dom_constructor_accepts_surrogate_pairs_and_explicitly_refuses_lone_units() {
    for name in ["Text", "Comment"] {
        for units in [vec![0xd800], vec![0xdc00], vec![0x61, 0xd800]] {
            let mut runtime = Runtime::try_new().unwrap();
            let mut doc = Document::parse("<p>kept</p>");
            let target = runtime.environments[0].bindings[name].value.clone();
            let qualified = format!("{PREFIX}{name}");
            let valid = runtime
                .dom_interface_construct(
                    &qualified,
                    &[Value::String(vec![0xd834, 0xdd1e].into())],
                    target.clone(),
                    &mut doc,
                )
                .unwrap();
            constructor_witness_kind(&doc, constructor_witness_id(valid), name, "𝄞");
            let before = format!("{doc:?}");
            let error = runtime
                .dom_interface_construct(
                    &qualified,
                    &[Value::String(units.into())],
                    target,
                    &mut doc,
                )
                .unwrap_err();
            assert!(error.is_unsupported());
            assert_eq!(format!("{doc:?}"), before);
            assert!(runtime.dom_prototypes.overrides.is_empty());
            constructor_witness_clean(&runtime);
        }
    }
}

#[test]
fn dom_prototype_invalid_node_cannot_be_rescued_by_cached_override() {
    let mut runtime = Runtime::try_new().unwrap();
    let doc = Document::parse("<p>kept</p>");
    let prototype = Value::Object(runtime.dom_proto_id("Text").unwrap());
    for id in [doc.nodes.len(), usize::MAX] {
        for cached in [false, true] {
            if cached {
                // A deliberately stale private entry; JavaScript cannot forge NodeIds.
                runtime
                    .dom_prototypes
                    .overrides
                    .insert(id, prototype.clone());
            }
            let error = runtime.prototype_of_in(&Value::Node(id), &doc).unwrap_err();
            assert_eq!(error.name(), "TypeError");
            assert_eq!(runtime.dom_prototypes.overrides.contains_key(&id), cached);
        }
    }
    constructor_witness_clean(&runtime);
}
