    pub(super) fn initialize_dom_prototypes(&mut self) -> Result<()> {
        let count = INTERFACES.len();
        self.work(8 + count)?;
        self.charge(count * std::mem::size_of::<InterfaceRecord>())?;
        let mut records = Vec::<InterfaceRecord>::new();
        records.try_reserve_exact(count).map_err(|_| ScriptError::resource("DOM interface records allocation failed"))?;
        let keys = [self.dom_proto_text("name")?.into(), self.dom_proto_text("length")?.into(),
            self.dom_proto_text("prototype")?.into(), self.dom_proto_text("constructor")?.into()];
        let tag_key = self.well_known_key("toStringTag");
        let unscopables_key = self.well_known_key("unscopables");
        let first_order = self.next_global_order;
        let mut new_count = 0usize;
        for interface in INTERFACES {
            if interface.name == "EventTarget" {
                let prototype = self.dom_proto_id("EventTarget")?;
                self.work(search(self.environments[0].bindings.len(),11) + search(self.native_properties.len(),11))?;
                let constructor = self.environments[0].bindings["EventTarget"].value.clone();
                let properties = self.native_properties["EventTarget"];
                let tag = self.dom_proto_text("EventTarget")?;
                self.dom_proto_property(prototype,tag_key.clone(),Property::data(Value::String(tag),false,false,true))?;
                records.push(InterfaceRecord { prototype, properties, constructor, order: 0 });
                continue;
            }
            let parent = interface.parent.ok_or_else(|| ScriptError::resource("DOM interface parent missing"))?;
            self.work(interfaces::interface_lookup_work(parent.len()))?;
            let parent_index = interfaces::interface_index(parent).ok_or_else(|| ScriptError::resource("DOM interface parent index missing"))?;
            let parent = records.get(parent_index).ok_or_else(|| ScriptError::resource("DOM interface inventory is not parent-first"))?;
            let parent_prototype = parent.prototype;
            let parent_constructor = parent.constructor.clone();
            let constructor = self.dom_interface_value(interface.name)?;
            let constants = if interface.name == "Node" { NODE_CONSTANTS } else { &[] };
            let unscopables = match interface.name {
                "Document" | "DocumentFragment" => PARENT_UNSCOPABLES,
                "Element" => ELEMENT_UNSCOPABLES,
                "CharacterData" | "DocumentType" => CHILD_UNSCOPABLES,
                _ => &[],
            };
            let methods = usize::from(matches!(interface.name,"Document"|"DocumentFragment"|"Element")) * 3;
            let prototype = self.dom_proto_object(Some(Value::Object(parent_prototype)),
                2 + constants.len() + methods + usize::from(!unscopables.is_empty()))?;
            let properties = self.dom_proto_object(Some(parent_constructor),3 + constants.len())?;
            let name = self.dom_proto_text(interface.name)?;
            self.dom_proto_property(properties,keys[1].clone(),Property::data(Value::Number(interface.length as f64),false,false,true))?;
            self.dom_proto_property(properties,keys[0].clone(),Property::data(Value::String(name.clone()),false,false,true))?;
            self.dom_proto_property(properties,keys[2].clone(),Property::data(Value::Object(prototype),false,false,false))?;
            self.dom_proto_property(prototype,tag_key.clone(),Property::data(Value::String(name),false,false,true))?;
            if !unscopables.is_empty() {
                let bag = self.dom_proto_object(None,unscopables.len())?;
                for key in unscopables { self.dom_proto_named(bag,key,Property::data(Value::Bool(true),true,true,true))?; }
                self.dom_proto_property(prototype,unscopables_key.clone(),Property::data(Value::Object(bag),false,false,true))?;
            }
            if methods != 0 { self.install_dom_parent_prototype(interface.name,prototype)?; }
            for &(key,value) in constants {
                let key: PropertyKey = self.dom_proto_text(key)?.into();
                for owner in [prototype,properties] {
                    self.dom_proto_property(owner,key.clone(),Property::data(Value::Number(value as f64),false,true,false))?;
                }
            }
            // Web IDL places operations/constants before this string property.
            self.dom_proto_property(prototype,keys[3].clone(),Property::data(constructor.clone(),true,false,true))?;
            let order = first_order.checked_add(new_count as u64).ok_or_else(|| ScriptError::resource("DOM interface order overflow"))?;
            records.push(InterfaceRecord { prototype, properties, constructor, order });
            new_count += 1;
        }
        let alias_order = first_order.checked_add(new_count as u64).ok_or_else(|| ScriptError::resource("DOM alias order overflow"))?;
        let next_order = alias_order.checked_add(1).ok_or_else(|| ScriptError::resource("DOM interface order overflow"))?;
        self.work(interfaces::interface_lookup_work(8))?;
        let document = records[interfaces::interface_index("Document").unwrap()].constructor.clone();
        let mut prototype_entries = self.dom_proto_vector::<(&'static str,usize)>(new_count)?;
        let mut native_entries = self.dom_proto_vector::<(String,usize)>(new_count)?;
        let mut global_entries = self.dom_proto_vector::<(String,Binding)>(new_count+1)?;
        let mut alias_pending = true;
        self.work(4 * count)?;
        for index in interfaces::interface_order() {
            let interface = &INTERFACES[index];
            if interface.name == "EventTarget" { continue; }
            let record = &records[index];
            if alias_pending && interface.name > "HTMLDocument" {
                let name = self.dom_proto_owned_name("HTMLDocument")?;
                global_entries.push((name,interface_binding(document.clone(),alias_order)));
                alias_pending = false;
            }
            prototype_entries.push((interface.name,record.prototype));
            let Value::Native(native) = &record.constructor else { unreachable!() };
            let full = self.dom_proto_owned_name(&native.name)?;
            native_entries.push((full,record.properties));
            let name = self.dom_proto_owned_name(interface.name)?;
            global_entries.push((name,interface_binding(record.constructor.clone(),record.order)));
        }
        if alias_pending {
            global_entries.push((self.dom_proto_owned_name("HTMLDocument")?,interface_binding(document,alias_order)));
        }
        // Prepay every scan, comparison, stable-sort scratch, fresh tree and
        // complete merged tree before taking any existing map. There is no
        // fallible runtime operation between take and final publication.
        self.dom_proto_publication_admission(&prototype_entries,&native_entries,&global_entries)?;
        let mut prototypes = std::mem::take(&mut self.prototypes);
        let mut natives = std::mem::take(&mut self.native_properties);
        let mut globals = std::mem::take(&mut self.environments[0].bindings);
        let mut new_prototypes = prototype_entries.into_iter().collect();
        let mut new_natives = native_entries.into_iter().collect();
        let mut new_globals = global_entries.into_iter().collect();
        prototypes.append(&mut new_prototypes);
        natives.append(&mut new_natives);
        globals.append(&mut new_globals);
        self.prototypes = prototypes;
        self.native_properties = natives;
        self.environments[0].bindings = globals;
        self.next_global_order = next_order;
        Ok(())
    }
    fn dom_proto_vector<T>(&mut self,count:usize)->Result<Vec<T>> {
        self.work(1)?;
        self.charge(count.saturating_mul(std::mem::size_of::<T>()))?;
        let mut result=Vec::new();
        result.try_reserve_exact(count).map_err(|_| ScriptError::resource("DOM metadata vector allocation failed"))?;
        Ok(result)
    }
    fn dom_proto_owned_name(&mut self,name:&str)->Result<String> {
        self.work(1 + name.len())?;
        self.charge(name.len())?;
        let mut result=String::new();
        result.try_reserve_exact(name.len()).map_err(|_| ScriptError::resource("DOM metadata name allocation failed"))?;
        result.push_str(name);
        Ok(result)
    }
