This is a source-only, independently authored success fixture for the bounded core-prototype increment. Run the same source in sloppy and strict modes when authorized. It has not been parsed or executed by its author. Assertions come from standards, not candidate outcomes.

The [DOM interface definitions](https://dom.spec.whatwg.org/#interface-node) establish the tested inheritance; [ParentNode](https://dom.spec.whatwg.org/#interface-parentnode) places the three existing operations separately on Document, Element and DocumentFragment. [DocumentFragment](https://dom.spec.whatwg.org/#interface-documentfragment), [Text](https://dom.spec.whatwg.org/#interface-text), and [Comment](https://dom.spec.whatwg.org/#interface-comment) define the exercised construction/data behavior.

[Web IDL interface objects](https://webidl.spec.whatwg.org/#interface-object), [prototype objects](https://webidl.spec.whatwg.org/#interface-prototype-object), [operations](https://webidl.spec.whatwg.org/#es-operations), and [platform-object creation](https://webidl.spec.whatwg.org/#new) supply descriptors, brand checks and conversion-before-prototype ordering. Illegal call/new must throw; the fixture deliberately does not assert that Node/Element/CharacterData can be Reflect.construct newTarget values (open issue #698). Bound ordinary functions supply observable prototype getters without Proxy or mutable ordinary-function prototype descriptors.

HTML elements are checked by Element ancestry, not an incorrect flattened immediate prototype. The parsed document uses Document.prototype; [HTMLDocument is an alias](https://html.spec.whatwg.org/multipage/nav-history-apis.html#the-window-object), not a separate subclass. SVG/MathML mapping is outside this fixture.

Separate unmet standards-success cases, deliberately not converted into negative expectations here:

- Independent Document construction: `new Document()` must produce a distinct document with its own tree/ownership; never alias the current document.
- Native attribute migration: Node/CharacterData/Document attribute descriptors, original-receiver getters/setters, prototype replacement/deletion and absence of synthesized fallback need their own tests. This fixture uses already-supported instance attributes only to observe genuine construction.
- Complete Document enumeration: full own-key reflection/for-in must include its actual Web IDL/HTML platform properties. Here Document method enumerability is observed through a plain object inheriting Document.prototype, leaving host enumeration out of the passing population.

No foreign realm, independent Document allocation, HTML/SVG subclass constructor matrix, or complete DOM-conformance claim. Prototype operation mutations are restored with saved descriptors in finally blocks. The fresh fixture realm supplies the ordinary HTML document and supported native factory methods.

Node constants, prototype Symbol.toStringTag descriptors (including Document, not a historical HTMLDocument tag), and the implemented append entry of each ParentNode Symbol.unscopables object are checked. The fixture does not claim that unsupported ParentNode operations are implemented.
