import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
binary=Path(sys.argv[1]).resolve(); output=Path(sys.argv[2]); fixture=Path(__file__).parent/'core-fixture.js'
source=fixture.read_bytes(); expected='dd05b044d6ff66e5e3705881af2f44575e91e642f608608b7d0bba9a0c35734e'
assert hashlib.sha256(source).hexdigest()==expected
records=[]
for mode in ('sloppy','strict'):
 case=dict(id='dom-prototypes-aggregate#'+mode,file='core-fixture.js',mode=mode,source=source,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=[])
 case['case_sha256']=runner.case_fingerprint(case)
 record=runner.run_case(case,binary,3)
 record['expected_observation']=dict(status='complete',phase='runtime')
 record['matches_expectation']=all(record.get('observation',{}).get(k)==v for k,v in record['expected_observation'].items())
 records.append(record)
result=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),fixture_sha256=expected,runner_sha256=hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),cases=records)
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
