# Native property-cache work review

Source-only; no engines, tests or compiler runs. Native.properties Some(id) makes property_object resolve the bag directly; None still searches native_properties. Exactly three explicit registry-work terms can skip the Native arm when properties is Some:

| Site | Eliminated term | Reached paths |
| --- | --- | --- |
| script.rs: reduce_property_in | lookup_work(native_properties.len(), name.len()) * 3 | reduce/reduceRight, generic array_methods live length/index/species reads, Array.from named/index reads via reduce_get |
| array_from.rs: array_from_native_lookup | lookup_work(native_properties.len(), name.len()) * passes | iterator symbol search (3 passes); array_from_own_budget (3 * passes), which supports output definition and length setting |
| array_splice.rs: splice_native_budget | search_work(native_properties.len(), name.len()) * passes | splice_own_budget (3 * passes) for live reads/definitions/deletions; splice_symbol_get (2 passes), also reused by concat spreadability/species/conversion |

Minimal arm in each helper: `Value::Native(native) if native.properties.is_none() => Some(native.name.as_str())`. Leave the wildcard returning None, JSON/Math name cases and legacy Native None behavior unchanged. Keep per-edge ticks, property and mapped-argument searches, binding and array-hole work, key conversion, host-symbol lookup preflights, prototype traversal, allocations and existing pass multipliers. Do not change installer registry searches: those still execute by name.

No separate native-name debit exists in read_own_property/read_own_property_key, own_property/own_property_key, find_property_in/find_property_key_in, ordinary_define_own_key, descriptor reflection, own_keys/own_symbol_keys or object_integrity. Their existing base/key/table charges therefore have no justified subtraction from this cache change. ensure_symbol_property_object already returns early for a cached bag; its absent-native allocation route remains necessary for None.

The full core fixture predominantly uses ordinary metadata, own descriptors and prototype traversal. Its explicit array operations operate on arrays, not cached native receivers. This review does not establish that these three conditional changes admit that fixture; no quota or accounting-unit change is justified by this result.

Read snapshots (source may continue changing):
- `src/script.rs`: `c0772d4ecc045aa234981f57d12f57034d5ae247a09795736bec0808bedbd81f`
- `src/script/array_from.rs`: `a242e39ef3f698c0f98b9de687c89e8a6fd0fcf9946770fef3adc4a66ab825ab`
- `src/script/array_splice.rs`: `a90873f01d5f6774a4c1fb41019781fef241d0ee04da4bf8cc94d043cc825035`
- `src/script/dom_own_properties.rs`: `23cfd5dc1ec6965a769f04dcd27767f1d2ba8aae9c662dd9717b40fff08ffea4`
- `src/script/property_keys.rs`: `70cd65bcfeeb60edd4d799ac51d37696c521eab5d2fb18b105abe08cd87dcd29`
- `src/script/own_keys.rs`: `ea454686281aa5105f3694a1deb73554c36d624117a8b1235a66425025c4125c`
