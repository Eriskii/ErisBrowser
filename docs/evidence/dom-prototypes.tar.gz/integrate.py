from pathlib import Path
root=Path('/tmp/eris-dom-prototypes-1/worktree')
p=root/'src/script.rs';s=p.read_text();s=s.replace('mod dom_own_properties;','mod dom_own_properties;\nmod dom_prototypes;');s=s.replace('    data_views: data_view::State,','    data_views: data_view::State,\n    dom_prototypes: dom_prototypes::State,');s=s.replace('            data_views: data_view::State::default(),','            data_views: data_view::State::default(),\n            dom_prototypes: dom_prototypes::State::default(),');s=s.replace('+ std::mem::size_of::<data_view::State>()','+ std::mem::size_of::<data_view::State>()\n                + std::mem::size_of::<dom_prototypes::State>()')
start=s.index('    fn initialize_intrinsics(');end=s.index('    fn intrinsic_function(',start);chunk=s[start:end];mark='        Ok(())\n    }\n';pos=chunk.rfind(mark);assert pos>=0;chunk=chunk[:pos]+'        self.initialize_dom_prototypes()?;\n'+chunk[pos:];s=s[:start]+chunk+s[end:]
# Remove precisely six fallbacks; prototype lookup must be authoritative after deletion.
import re
s,n=re.subn(r'\s*"(querySelector|querySelectorAll|append)" => \{\n\s*return self\.dom_parent_method\(\n\s*&receiver,\n\s*dom_bindings::ParentOperation::\w+,\n\s*doc,\n\s*\);\n\s*\}', '',s);assert n==6,n
# Before generic native handling and argument payload scans.
start=s.index('    fn native_call(');pos=s.index('\n',s.index(') -> Result<Value> {',start))+1;s=s[:pos]+'        if dom_prototypes::is_interface_name(&native.name) {\n            self.dom_interface_kind(&native.name)?;\n            return Err(ScriptError::type_error("DOM interface constructor requires new"));\n        }\n'+s[pos:]
p.write_text(s)
p=root/'src/script/dom_bindings.rs';s=p.read_text().replace('const BOOTSTRAP_OBJECT_CAPACITY: usize = 512;','const BOOTSTRAP_OBJECT_CAPACITY: usize = dom_prototypes::BOOTSTRAP_OBJECTS;');pos=s.index('    pub(super) fn initialize_dom_bindings');s=s[:pos]+'''    pub(super) fn install_dom_parent_prototypes(&mut self) -> Result<()> {
        for row in &PARENT_METHODS {
            let name = match row.interface {
                ParentInterface::Document => "Document",
                ParentInterface::Element => "Element",
                ParentInterface::DocumentFragment => "DocumentFragment",
            };
            let owner = self.dom_proto_id(name)?;
            self.work(8 + row.full.len())?;
            self.charge(std::mem::size_of::<Native>() + 32 + row.full.len())?;
            let function = Self::native(row.full, Value::Undefined);
            self.dom_proto_named(owner, row.name, Property::data(function,true,true,true))?;
        }
        Ok(())
    }

'''+s[pos:];# Keep old private getter helper solely for existing admission tests.
s=s.replace('    pub(super) fn dom_parent_method(', '    #[cfg(test)]\n    pub(super) fn dom_parent_method(');s=s.replace('fn parent_method(\n','#[cfg(test)]\nfn parent_method(\n');p.write_text(s)
p=root/'src/script/dom_prototypes.rs';s=p.read_text().replace('    fn dom_proto_named(', '    pub(super) fn dom_proto_named(').replace('    fn dom_proto_id(', '    pub(super) fn dom_proto_id(');p.write_text(s)
p=root/'src/script/construction.rs';s=p.read_text();s=s.replace('return Ok(native.receiver == Value::Window\n                        && matches!(', 'return Ok(native.receiver == Value::Window\n                        && (self.dom_interface_kind(&native.name)?.is_some() || matches!(');s=s.replace('                                | "AbortSignal"\n                        ));','                                | "AbortSignal"\n                        )));');needle='                let name = native.name.as_str();\n                match name {';s=s.replace(needle,'                let name = native.name.as_str();\n                if dom_prototypes::is_interface_name(name) {\n                    return self.dom_interface_construct(name, &arguments, new_target, doc);\n                }\n                match name {');p.write_text(s)
p=root/'src/script/machine/calls.rs';s=p.read_text();s=s.replace('    let result = if NumberPredicate::from_name(&native.name).is_some() {','    let result = if NumberPredicate::from_name(&native.name).is_some()\n        || crate::script::dom_prototypes::is_interface_name(&native.name)\n    {');p.write_text(s)
