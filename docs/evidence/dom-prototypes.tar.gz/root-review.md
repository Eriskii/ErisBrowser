# DOM prototype review

Root reviewed supported prototype consumers: Get, symbol lookup, in, Set, descriptor conversion, isPrototypeOf, instanceof, prototype-cycle checks and for-in use the active Document. Remaining primitive boxing and Function.bind calls cannot receive DOM hosts. Array.from and splice explicitly reject their existing unsupported host traversal before the older helper.

Constructor review requested exact UTF-16 decoding, fresh document admission after callbacks, separate retained UTF-8 copy work, default override elision and full UTF-16 property-key fees. These fixes are present in the reviewed source; validation is pending. The independent reviewer additionally requested node-ID validation before override lookup and metadata constructor-order correction.

The first actual bootstrap attempt stopped at the unchanged work limit. Repeated per-entry map publication alone projects108530 work for153 interfaces, so final-bag sharing cannot by itself fit. A true sorted bulk construction/merge algorithm is being reviewed against both supported toolchains. Neither work/heap quotas nor comparison units may be discounted to force admission.

Core/browser fixtures were authored separately and are held unchanged. Root added a separate script-level15-case HTML/SVG/MathML mapping fixture before execution, including clone, tag and intermediate-chain checks. No pass is assigned before running it.

## Final source review before integration

The main script diff routes supported internal prototype consumers through the active Document, including property search, descriptors, membership, for-in and cycle checks. The test-only wrappers supply their own empty Document and are not production fallbacks. Default mapping now returns the static descriptor index directly after unchanged mapping prepayment. Native cache identity remains name plus receiver; invocation copies preserve the auxiliary handle. Initial globals and every reached legacy factory account for the new optional slot; existing broader allocation gaps remain declared. Reviewed the constructor publication path, immutable default selection, sparse alternate prototype map, and invalid-node precheck. No new concrete defect found.

The original aggregate fixture is retained byte-for-byte (dd05b044d6ff66e5e3705881af2f44575e91e642f608608b7d0bba9a0c35734e). Its expected ordinary completion is not changed to a resource expectation. Baseline adapter observes missing Node in both modes; indexed implementation still stops at the fixed work limit. Separate bounded cases are additional coverage, not a pass for the original aggregate. Main src/dom.rs serializer changes must remain intact during integration.
