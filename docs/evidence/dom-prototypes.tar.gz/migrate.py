from pathlib import Path
import re
root=Path('/tmp/eris-dom-prototypes-1/worktree')
names=['find_property','find_property_key','resolve_binding','reduce_property','object_is_prototype_of','set_object_prototype']
# Only Rust production calls: test bodies retain existing signatures through
# private test-only adapters in the parent module where necessary.
for p in [root/'src/script.rs',*(root/'src/script').rglob('*.rs')]:
 if p.name in ['tests.rs','identity_tests.rs','interfaces.rs'] or p.name.endswith('_tests.rs'): continue
 s=p.read_text(); mark=s.find('#[cfg(test)]\nmod tests'); production=s if mark<0 else s[:mark];tail='' if mark<0 else s[mark:]
 hits=[]
 for m in re.finditer(r'\b('+ '|'.join(names)+r')\s*\(', production):
  pos=m.end(); depth=1; quote=None; escape=False
  while depth:
   c=production[pos]
   if quote:
    if escape: escape=False
    elif c=='\\':escape=True
    elif c==quote:quote=None
   elif c=='"':quote=c
   elif c=='(':depth+=1
   elif c==')':depth-=1
   pos+=1
  definition=production[max(0,m.start()-3):m.start()]=='fn '
  inner=production[m.end():pos-1].rstrip().removesuffix(',')
  addition='doc: &Document' if definition else 'doc'
  hits.append((m.start(),pos,m.group(1)+'_in('+inner+', '+addition+')'))
 for a,b,replacement in reversed(hits):production=production[:a]+replacement+production[b:]
 p.write_text(production+tail)
# Document-aware links on supported generic paths. Other remaining raw links
# are primitive/callable-only or refuse host objects before traversal.
p=root/'src/script.rs';s=p.read_text(); start=s.index('    fn object_is_prototype_of_in');end=s.index('    fn own_property(',start);part=s[start:end].replace('self.prototype_of(&value)','self.prototype_of_in(&value, doc)?');s=s[:start]+part+s[end:]
for name,endname in [('find_property_in','lookup_property'),('reduce_property_in','reduce_get')]:
 start=s.index('    fn '+name);end=s.index('    fn '+endname,start);part=s[start:end].replace('self.prototype_of(&value)','self.prototype_of_in(&value, doc)?');s=s[:start]+part+s[end:]
s=s.replace('return Ok(self.prototype_of(&object).unwrap_or(Value::Null));','return Ok(self.prototype_of_in(&object, doc)?.unwrap_or(Value::Null));');p.write_text(s)
for file in ['property_keys.rs','symbols.rs']:
 p=root/'src/script'/file;s=p.read_text().replace('self.prototype_of(&value)','self.prototype_of_in(&value, doc)?').replace('self.prototype_of(&current)','self.prototype_of_in(&current, doc)?');p.write_text(s)
p=root/'src/script/machine/statements.rs';s=p.read_text();s=s.replace('runtime.prototype_of(&state.object)','runtime.prototype_of_in(&state.object, doc)?');s=s.replace('for_in_next(runtime, frame, state)','for_in_next(runtime, frame, state, doc)');s=s.replace('for_in_start(runtime, frame, value(output))','for_in_start(runtime, frame, value(output), doc)');s=s.replace('fn for_in_start(runtime: &mut Runtime, frame: Frame, value: Value)', 'fn for_in_start(runtime: &mut Runtime, frame: Frame, value: Value, doc: &Document)');s=s.replace('    mut state: ForInState,\n) -> Result<Option<Output>> {','    mut state: ForInState,\n    doc: &Document,\n) -> Result<Option<Output>> {');p.write_text(s)
# Keep old private test callsites focused on their original non-DOM algorithms.
p=root/'src/script.rs';s=p.read_text();pos=s.index('    fn find_property_in(');s=s[:pos]+'''    #[cfg(test)]
    fn resolve_binding(&mut self, env: usize, name: &str) -> Result<Option<usize>> {
        self.resolve_binding_in(env, name, &Document::parse(""))
    }
    #[cfg(test)]
    fn reduce_property(&mut self, receiver: &Value, key: &JsString) -> Result<Option<Property>> {
        self.reduce_property_in(receiver, key, &Document::parse(""))
    }
    #[cfg(test)]
    fn object_is_prototype_of(&mut self, receiver: Value, value: Value) -> Result<Value> {
        self.object_is_prototype_of_in(receiver, value, &Document::parse(""))
    }
    #[cfg(test)]
    fn set_object_prototype(&mut self, object: &Value, prototype: Value) -> Result<()> {
        self.set_object_prototype_in(object, prototype, &Document::parse(""))
    }

'''+s[pos:];p.write_text(s)
