# Consuming-merge collision check: proposed ledger delta

Source-only follow-up to `bulk-implementation-review.md`. This reviews the parent-approved algorithm change, not an already executed or finalized implementation. No compiler, engine, or admission run was performed by this reviewer.

Remove the separate old/new collision preflight. Keep the strict staged-order check before taking maps. A single `cmp` inside the consuming merge now reports equality as an initialization invariant error. All three full plans and reservations still precede any `mem::take`; publish the three completed maps and `next_global_order` only together after success. A failed initializer is discarded, never retried or exposed with taken maps.

For old entries o, staged entries m, N=o+m, old-node bound b, fresh-node bound a, and fresh-tree height h, retain:

```
comparisons = max(m-1,0) + 3*max(N-1,0)
structure   = 64 + 4*(o+b) + 6*N + 8*N
            + 4*(2*h+2)*floor(N/12) + 64*h + 8*a + 16*(h+1)
work        = structure + comparisons*(1+max_key_bytes/8)
```

The removed comparisons are exactly `o+2m`; staged ordering, merge, ascending-run detection, and adjacent dedup remain. The merge uses at most N−1 comparisons both on success and on a collision: before a collision at least two unconsumed entries remain, and every preceding comparison consumed one entry. Equality is a branch of the existing comparison, not another key scan.

The old-tree term loses only its reference-validation traversal. One consuming traversal retains four logical units per entry for key/value reads and entry-handle/remaining-count updates, and four per node for downward/upward traversal, retirement and node-state transition. Peek-cache transfers and merged-vector writes remain in the separate 6N term. The maximum-length scan is still independently prepaid before planning. This is the same fixed-metadata unit mapping used by the prior review; no fee changes or quota/headroom target enters the calculation.

All output storage stays unchanged: staged vector, complete merged vector, stable-sort scratch, and every admitted fresh node. On a collision, consuming the remaining old iterator for destruction does not visit an old node twice. Current staged/merged vector destruction can use the prepaid but unexecuted full-build allowance; no string-byte copy or author callback is introduced by dropping these concrete metadata types. Previously completed temporary maps and the rest of the failed Runtime are discarded under the existing terminal-initialization cleanup contract. Do not claim preservation of the original maps on error.

Keep checked arithmetic, direct unadvanced merged Vec collection, recorded global order, and all header/overflow/repair terms unchanged. Update the old success-only comment: invariant errors can now occur after taking a map, even though author callbacks and recoverable allocation requests still cannot.
