#[test]
fn dom_prototypes_and_native_constructors_survive_page_callbacks() {
    assert_six_scripted_samples_with_result_text(
        include_str!("fixtures/dom-prototypes.html"),
        Some(["ready", "6"]),
    );
}
