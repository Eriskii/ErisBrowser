# AbortSignal inherited class-string regression

The first integrated full default run retained `abort_controller_signal_slots_and_reason_identity_are_private` failing with a Test262Error. Source tracing shows that the new EventTarget prototype owns `Symbol.toStringTag = "EventTarget"`, while the already-supported AbortSignal prototype inherits EventTarget and had no own tag. `Object.toString` correctly reads inherited symbol properties before its old slot-derived fallback, so it now returns the wrong class string for a genuine signal.

[DOM AbortSignal](https://dom.spec.whatwg.org/#interface-AbortSignal) inherits EventTarget. [Web IDL interface prototype objects](https://webidl.spec.whatwg.org/#es-interface-prototype-object) have their interface-qualified class string; [Web IDL class strings](https://webidl.spec.whatwg.org/#dfn-class-string) require an own Symbol.toStringTag data property with writable=false, enumerable=false, configurable=true.

The correction adds only the missing AbortSignal prototype entry while EventTarget metadata is initialized. The existing dom_proto_id, dom_proto_text and dom_proto_property helpers retain prototype-search, string, map, descriptor and order storage/work admission. No renderer, quota, author reset, tag lookup or existing assertion changes. The new same-file regression covers both source modes, own descriptor flags, genuine and ordinary inheritor tags, base-tag replacement, explicit deletion exposing the base tag, and restoration.

No engine/compiler/test execution by this author. The rustup-backed Rustfmt 1.88.0 attempt failed before formatting because its temporary directory is read-only; the attempt is retained in format-attempt-1.log. Root owns the focused and full runtime checks.
