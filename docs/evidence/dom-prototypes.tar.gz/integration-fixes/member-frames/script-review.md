# Independent member-continuation source review

Clear on the scoped diff; no source edits, compiler or engine execution by reviewer.

Before SHA256: 54a5d6573cb19cebcbf2465a5333b76cddbea264ba65ea2ff6a3e461db39db77
Reviewed SHA256: c0626c9845dbb17052171cd806538dedde58a1a0eb3e34f1b8e084b94f77c270

- Base value is evaluated before the computed key. The same raw key enters read_reference after evaluation; its existing null/undefined and property-key conversion order is unchanged.
- Reference contexts still return raw references. MemberCallee retains the original receiver before Get; assignment/update/delete continue using their existing consuming phases.
- A value Member retains one logical expression weight. The eliminated reference frame had zero expression/call weights and no tick. Success/ordinary-error paths decrement once; terminal errors restore drive's saved frames, depth, calls and stack. Callback reads occur after the consuming frame is popped in both versions.
- Eliminated pushes, duplicated Rc frame ownership and possible frame growth are real removed operations. Expression ticks, reserve/relocation fees for remaining growth, quotas and native-call guards stay intact.
- Existing every_work_cut_unwinds_only_its_frames_and_releases_owned_payloads and callback_reentry_preserves_outer_values_references_and_abrupt_identity are relevant independent witnesses; root owns execution.
