# Object.is installer admission correction

The original full-default Rust1.88 run failed the existing exact/one-short Object.is installer test (line488): the one-short heap path published a new native_properties row and object before returning ResourceLimit. The prototype increment moved generic intrinsic_function's final factory to alloc_native, adding a reached eight-byte metadata-slot admission after those mutations.

Move that same NATIVE_METADATA_BYTES charge to the beginning of intrinsic_function; return the raw native factory after existing bag construction/publication. Every successful call retains exactly the same work and storage debit, including the existing-row path. Refusal of that native-slot debit happens before any metadata mutation; later object_ordered property refusals continue to happen before arena publication. No quota, test outcome, installer formula or semantic algorithm changes.

The existing Object.is exact/one-short full-admission test is retained byte-exact and is the regression witness. Source-only correction: root owns compiler/test validation. Other Object.is production/tests unchanged. git diff --check on assigned paths passed.
