"""Independent inert AST/source audit. Never imports or calls project code."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

E = Path('/tmp/eris-promise-try-upstream-plan-1')
H = E / 'runner-1'
O = E / 'runner-review-1'
BASE = '15db31c76f5a2f259deffadbf0f95e212a5fa61c'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def load(path):
    return json.loads(Path(path).read_text())

def bind(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))

def verify(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            actual = bind(value['path'])
            assert (actual['bytes'], actual['sha256']) == (value['bytes'], value['sha256']), value['path']
        for child in value.values():
            verify(child)
    elif isinstance(value, list):
        for child in value:
            verify(child)

seal = load(H / 'source-ready.json')
assert bind(H / 'source-ready.json')['sha256'] == 'f01344ba4369e7aed9a4d903d19e09741d7837c89ab3bc2d5d8431a8b0799537'
verify(seal)
before = (H / 'before/tools/test262_conformance.py').read_text()
after = (H / 'raw/tools/test262_conformance.py').read_text()
published = subprocess.check_output(['git', 'show', BASE + ':tools/test262_conformance.py'], cwd=E/'worktree')
assert before.encode() == published

def functions(source):
    lines = source.splitlines(keepends=True)
    return {node.name: (node, ''.join(lines[node.lineno-1:node.end_lineno]))
            for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}

old, new = functions(before), functions(after)
added = sorted(new.keys() - old.keys())
changed = sorted(name for name in old if old[name][1] != new[name][1])
unchanged = sorted(name for name in old if old[name][1] == new[name][1])
assert changed == ['decode_response', 'harness_preflight', 'load_corpus', 'main', 'run_case']
assert len(unchanged) == 63 and len(added) == 6 and old.keys() <= new.keys()
assert added == sorted(['promise_try_preflight_variants', 'promise_try_preflight_cases',
                       'promise_try_preflight_reference', 'promise_try_preflight_checks',
                       'promise_try_preflight_healthy', 'promise_try_harness_preflight'])

# Reconstruct every parent byte with independently specified seam reversals.
inverse = after
start = inverse.index('def promise_try_preflight_variants():\n')
end = inverse.index('def check_baseline(', start)
payload = inverse[start:end]
assert payload == (H/'payload/try-preflight.py').read_text() + '\n\n'
inverse = inverse[:start] + inverse[end:]
reversals = [
    ("PROMISE_TRY_PROFILE = 'promise-try'\nPROMISE_TRY_FEATURES = {'Reflect.construct', 'promise-try'}\nPROFILE_FEATURES[PROMISE_TRY_PROFILE] = PROMISE_TRY_FEATURES\nPROMISE_HOST_PROFILES.add(PROMISE_TRY_PROFILE)\n", '', 1),
    ("if profile in {PROMISE_TRY_PROFILE, PROMISE_WITH_RESOLVERS_PROFILE,", "if profile in {PROMISE_WITH_RESOLVERS_PROFILE,", 2),
    ("    if profile == PROMISE_TRY_PROFILE and not output.startswith(b'ERJR3'):\n        raise ValueError('Promise.try profile requires an ERJR3 response')\n", '', 1),
    ('PROMISE_WITH_RESOLVERS_PROFILE, PROMISE_TRY_PROFILE} else decode_response(output))', 'PROMISE_WITH_RESOLVERS_PROFILE} else decode_response(output))', 1),
    ('        status = (classify_promise(case, observation) if profile == PROMISE_TRY_PROFILE\n                  else classify(case, observation, profile=profile)\n', '        status = (classify(case, observation, profile=profile)\n', 1),
    ('    if profile == PROMISE_TRY_PROFILE:\n        return promise_try_harness_preflight(files, binary, timeout)\n', '', 1),
    ('        preflight_ok = (promise_try_preflight_healthy(preflight, files) if args.profile == PROMISE_TRY_PROFILE\n                        else with_resolvers_preflight_healthy(preflight, files) if args.profile == PROMISE_WITH_RESOLVERS_PROFILE\n', '        preflight_ok = (with_resolvers_preflight_healthy(preflight, files) if args.profile == PROMISE_WITH_RESOLVERS_PROFILE\n', 1),
]
for candidate, parent, count in reversals:
    assert inverse.count(candidate) == count, candidate
    inverse = inverse.replace(candidate, parent)
assert inverse == before

diff = (H/'diffs/tools__test262_conformance.py.diff').read_text()
headers = diff.splitlines()[:2]
independent_diff = ''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True), fromfile=headers[0][4:], tofile=headers[1][4:]))
assert independent_diff == diff

# Extract only literal return values; do not call the candidate functions.
def literal(name):
    node = new[name][0]
    return ast.literal_eval(next(child.value for child in node.body if isinstance(child, ast.Return)))

common = literal('promise_preflight_variants')
selected = literal('promise_try_preflight_variants')
controls = E/'controls-contract-1'
oracle = load(controls/'raw/tools/promise-try-controls-oracle.json')
assert selected == load(controls/'variants.json') == oracle['variants']
assert common == oracle['common_variants'] and len(common) == 37 and len(selected) == 10
package = E/'importer-contract-1/corpus/tests/upstream/test262-promise-try'
for name, record in oracle['helpers'].items():
    data = (package/'harness'/name).read_bytes()
    assert record == dict(bytes=len(data), sha256=digest(data))

# Independently model the selected canonical builder from the reviewed recipe.
records = []
for rows, prefix in ((common, 'promise-methods-'), (selected, 'promise-try-')):
    for mode in ('sloppy', 'strict'):
        for item in rows:
            policy = item['completion_policy']
            names = ['assert.js', 'sta.js'] + (['doneprintHandle.js'] if policy else []) + item['includes']
            dependencies = []
            if prefix == 'promise-methods-':
                if item['prerequisite']:
                    dependencies.append(prefix+item['prerequisite'])
                if item['origin'] == 'original-literal':
                    dependencies.extend(prefix+x['name'] for x in common if x['origin'] == 'new-prerequisite')
                    if item['name'] != 'one-async-completion':
                        dependencies.append(prefix+'one-async-completion')
            else:
                dependencies = ['promise-methods-'+x['name'] for x in common]
                if item['name'] != 'api':
                    dependencies.append('promise-try-api')
                if item['prerequisite'] and prefix+item['prerequisite'] not in dependencies:
                    dependencies.append(prefix+item['prerequisite'])
            name = prefix+item['name']
            source_hash = digest(item['source'].encode())
            metadata = dict(flags=['async'] if policy else [], includes=item['includes'], features=[], locale=[], negative=None)
            harness = [dict(name=n, sha256=digest((package/'harness'/n).read_bytes())) for n in names]
            identity = dict(source_sha256=source_hash, mode=mode, metadata=metadata, harness=harness, completion_policy=policy)
            record = dict(name=name, mode=mode, id='harness-preflight:'+name, file='<preflight>',
                          metadata=metadata, source=item['source'], source_sha256=source_hash, harness=harness,
                          completion_policy=policy, expected=item['expected'],
                          prerequisites=[[dep, mode] for dep in dependencies],
                          case_sha256=digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode()))
            assert record == {key:value for key,value in oracle['records'][len(records)].items() if key != 'mock_observation'}
            records.append(record)
assert len(records) == 94
index = {(record['name'],record['mode']):record for record in records}
assert len(index) == 94
edges = 0
references = []
for record in records:
    refs = []
    for dependency in record['prerequisites']:
        target = index[tuple(dependency)]
        assert target['mode'] == record['mode']
        refs.append(dict(name=target['name'], mode=target['mode'], verified=True,
                         case_sha256=target['case_sha256'], source_sha256=target['source_sha256']))
        edges += 1
    assert len(refs) == len({(ref['name'],ref['mode']) for ref in refs})
    references.append(refs)
assert edges == 1204

seen, active = set(), set()
def visit(key):
    assert key not in active
    if key in seen:
        return
    active.add(key)
    for dependency in index[key]['prerequisites']:
        visit(tuple(dependency))
    active.remove(key)
    seen.add(key)
for key in index:
    visit(key)

# Pin unchanged shared arities/defaults and the deliberate Try-only routing.
protected = ['classify', 'encode_request', 'unsupported_reason', 'profile_intrinsic_errors',
             'decode_promise_response', 'validate_promise_observation', 'classify_promise',
             'promise_completion_passes', 'promise_host_reason', 'promise_preflight_verified']
assert all(name in unchanged for name in protected)
assert 'return decode_promise_response(output)\n' in new['decode_response'][1]
assert 'classify_promise(case, observation) if profile == PROMISE_TRY_PROFILE' in new['run_case'][1]
for name in ['decode_response', 'run_case', 'harness_preflight', 'load_corpus', 'main']:
    assert ast.dump(old[name][0].args) == ast.dump(new[name][0].args)

checks = dict(status='clear', runner=bind(H/'source-ready.json'), base=BASE,
              before_equals_published_git=True, full_byte_inverse=True, exact_unified_diff=True,
              existing_functions=len(old), unchanged_functions=unchanged, changed_functions=changed,
              new_functions=added, protected_functions=protected, old_signatures_unchanged=True,
              literal_variants=10, common_records=74, total_records=94, prerequisite_edges=edges,
              prerequisite_graph_acyclic=True, helpers=8,
              fingerprint_vector_sha256=digest(json.dumps([(r['name'],r['mode'],r['case_sha256']) for r in records],separators=(',',':')).encode()),
              canonical_reference_vector_sha256=digest(json.dumps(references,separators=(',',':')).encode()),
              execution='Only this independent stdlib/AST/hash model and read-only Git; no project imports, candidate calls, tests, builds, or live edits.')
(O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(bind(O/'checks.json'),indent=2))
