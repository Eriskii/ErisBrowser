from pathlib import Path
import collections
import difflib
import hashlib
import json
import posixpath
import re
import subprocess

E = Path('/tmp/eris-promise-try-upstream-plan-1')
W = E / 'worktree'
R = E / 'documentation-review-1'
BASE = '15db31c76f5a2f259deffadbf0f95e212a5fa61c'

def read(p):
    return json.loads(p.read_bytes())

def digest(b):
    return hashlib.sha256(b).hexdigest()

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=digest(b))

def bound(row):
    b = Path(row['path']).read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256'], row['path']
    return b

def all_bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            bound(value)
        for item in value.values():
            all_bindings(item)
    elif isinstance(value, list):
        for item in value:
            all_bindings(item)

def git(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=W)

ledger = read(E / 'root/final-validation.json')
peer = read(E / 'validation-review-1/final-review.json')
all_bindings(ledger)
all_bindings(peer)
assert ledger['status'] == 'pass' and peer['status'] == 'clear'

# Review the original complete hold even when a corrected hold is pending.
hold = read(E / 'documentation-1/source-ready.json')
all_bindings(hold)
assert hold['base'] == BASE and len(hold['files']) == 6
documents = []
for row in hold['files']:
    name = row['relative_path']
    before = bound(row['before']) if row['before'] else b''
    raw = bound(row['raw'])
    if row['before']:
        assert before == git(name)
    else:
        assert subprocess.run(['git', 'cat-file', '-e', BASE + ':' + name], cwd=W,
                              stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode != 0
    expected_diff = ''.join(difflib.unified_diff(
        before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True),
        fromfile=name if row['before'] else '/dev/null', tofile=name))
    assert expected_diff.encode() == bound(row['diff'])
    documents.append(dict(path=name, before_sha256=digest(before) if before else None,
                          raw_sha256=digest(raw), exact_published_before=True, exact_diff=True))

before = (E / 'documentation-1/before/docs/VALIDATION.md').read_bytes()
raw = (E / 'documentation-1/raw/docs/VALIDATION.md').read_bytes()
header = b'# Validation record\n'
assert before.startswith(header) and raw.startswith(header)
assert raw.endswith(before[len(header):])
runtime_chapter = 'docs/promise-try.md'
assert git(runtime_chapter) == (W / runtime_chapter).read_bytes()
assert git(runtime_chapter) == (E / 'documentation-1/before' / runtime_chapter).read_bytes()
road_before = (E / 'documentation-1/before/docs/ROADMAP.md').read_text()
road_raw = (E / 'documentation-1/raw/docs/ROADMAP.md').read_text()
road_changes = [x for x in difflib.ndiff(road_before.splitlines(), road_raw.splitlines())
                if x.startswith(('- ', '+ '))]
assert not any('vulkan' in x.lower() for x in road_changes)

# Read complete raw records; do not use summary counts as their substitute.
first = read(E / 'upstream-try-1.json')
replay = read(E / 'upstream-try-check-1.json')
for field in ['cases', 'harness_preflight', 'counts', 'runner_policy', 'runner_policy_sha256',
              'revision', 'corpus_manifest_sha256', 'binary_sha256']:
    assert first[field] == replay[field], field
assert len(first['cases']) == 30 and len(first['harness_preflight']) == 94
assert collections.Counter(c['status'] for c in first['cases']) == {'passed': 24, 'unsupported': 6}
assert all(c['verified'] is True for c in first['harness_preflight'])
assert first['negative_source_tests'] == 0 and first['fixture_files'] == []
assert first['regressions'] == replay['regressions'] == []
assert first['improvements'] == replay['improvements'] == []
policy = first['runner_policy']
assert policy['supported_features'] == ['Reflect.construct', 'promise-try']
assert policy['request_protocol'] == 'ERJS2' and policy['response_protocol'] == 'ERJR3'
assert len(policy['negative_intrinsic_errors']) == 7
assert digest(json.dumps(policy, sort_keys=True).encode()) == first['runner_policy_sha256']
split = collections.Counter()
mode_sources = []
for c in first['cases']:
    p = W / 'tests/upstream/test262-promise-try' / c['file']
    data = p.read_bytes()
    assert digest(data) == c['source_sha256']
    meta = re.search(r'/\*---(.*?)---\*/', data.decode(), re.S).group(1)
    async_mode = bool(re.search(r'^flags:\s*\[[^\]]*\basync\b', meta, re.M))
    split[('async' if async_mode else 'sync', c['status'])] += 1
    if c['status'] == 'unsupported':
        assert c['reason'] == 'unimplemented declared features: class'
        assert 'observation' not in c
        assert re.search(r'^features:\s*\[[^\]]*\bclass\b', meta, re.M)
    else:
        assert c['observation']['completion']['policy'] == int(async_mode)
    mode_sources.append(dict(id=c['id'], async_mode=async_mode, status=c['status']))
assert split == {('async', 'passed'): 6, ('async', 'unsupported'): 2,
                 ('sync', 'passed'): 18, ('sync', 'unsupported'): 4}
baseline = read(W / 'tests/conformance/test262-promise-try-current.json')
assert baseline['cases'] == {c['id']: {k: c[k] for k in ['status', 'case_sha256', 'source_sha256']}
                             for c in first['cases']}
for key in ['revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'binary_sha256']:
    assert baseline[key] == first[key]

old = []
for parent in sorted((E / 'replay-parent').glob('upstream-*-1.json')):
    prior, actual = read(parent), read(E / parent.name)
    for key in ['cases', 'harness_preflight', 'counts', 'runner_policy', 'runner_policy_sha256',
                'revision', 'corpus_manifest_sha256', 'binary_sha256']:
        assert prior[key] == actual[key], (parent.name, key)
    old.append(dict(parent=bind(parent), current=bind(E / parent.name),
                    cases=len(actual['cases']), controls=len(actual['harness_preflight'])))
assert len(old) == 7
assert sum(x['cases'] for x in old) == 1300
assert sum(x['controls'] for x in old) == 546

rosters = {}
for name, count in [('python-parent-1', 652), ('python-selected-candidate-1', 31), ('python-full-1', 683)]:
    log = (E / 'validation' / (name + '.log')).read_text()
    ids = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$', log, re.M)
    assert len(ids) == len(set(ids)) == count
    assert f'Ran {count} tests in ' in log and log.rstrip().endswith('OK')
    rosters[name] = ids
assert set(rosters['python-full-1']) == set(rosters['python-parent-1']) | set(rosters['python-selected-candidate-1'])
assert set(rosters['python-parent-1']).isdisjoint(rosters['python-selected-candidate-1'])
parent_log = (E / 'validation/python-selected-parent-1.log').read_text()
parent_rows = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\.([^\n]*)$', parent_log, re.M)
parent_groups = {}
for name, status in parent_rows:
    if name in parent_groups:
        assert parent_groups[name].strip() == '' and status.strip() in ('FAIL', 'ERROR')
    parent_groups[name] = status
assert len(parent_groups) == 31 and sum(x.strip() == 'ok' for x in parent_groups.values()) == 6
assert 'FAILED (failures=60, errors=46)' in parent_log

reuse = read(E / 'root/binary-reuse-1.json')
all_bindings(reuse)
for row in reuse['binaries']:
    metadata = read(Path(row['retained_build_metadata']['path']))
    assert '1.88' in json.dumps(metadata)
unchanged = ['src', 'crates', 'Cargo.toml', 'Cargo.lock', 'build.rs', '.cargo']
diff = subprocess.check_output(['git', 'diff', BASE, '--name-only', '--', *unchanged], cwd=W)
extra = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '--', *unchanged], cwd=W)
assert diff == extra == b''
ci = read(E / 'root/prior-ci-observation-1.json')
assert ci['headSha'] == BASE and ci['databaseId'] == 38817823918
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 11
assert all(j['conclusion'] == 'success' for j in ci['jobs'])

manifest_path = W / 'tests/upstream/test262-promise-try/manifest.json'
manifest = read(manifest_path)
proof_rows = manifest['inventory_proof']['files']
assert manifest['test_files'] == 15 and len(manifest['files']) == 25
assert len(proof_rows) == 7 and len(manifest['files']) + len(proof_rows) + 1 == 33
assert digest(manifest_path.read_bytes()) == first['corpus_manifest_sha256']
helper_rows = [f for f in manifest['files'] if f['path'].startswith('harness/')]
assert len(helper_rows) == 8
for row in manifest['files'] + proof_rows:
    b = (manifest_path.parent / row['path']).read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256']
shim = (manifest_path.parent / 'harness/compareArray.js').read_text()
assert len(shim.encode()) == 243 and 'function compareArray' not in shim
assert 'function compareArray' in (manifest_path.parent / 'harness/assert.js').read_text()

links = []
future = {'docs/evidence/promise-try-upstream/manifest.json',
          'docs/evidence/promise-try-upstream/sources-and-checks.tar.gz'}
held = {r['relative_path'] for r in hold['files']}
for row in hold['files']:
    text = bound(row['raw']).decode()
    original = bound(row['before']).decode() if row['before'] else ''
    for label, target in re.findall(r'\[([^\]]+)\]\(([^)]+)\)', text):
        if target.startswith(('https:', '#')) or f']({target})' in original:
            continue
        normalized = posixpath.normpath(str(Path(row['relative_path']).parent / target.split('#')[0]))
        assert normalized in held or (W / normalized).exists() or normalized in future, normalized
        links.append(dict(source=row['relative_path'], target=target, resolved=normalized,
                          future_evidence=normalized in future))
chapter = (E / 'documentation-1/raw/docs/promise-try-upstream.md').read_text()
command = re.search(r'```sh\n([^`]+)```', chapter).group(1).strip()
assert command in (W / '.github/workflows/check.yml').read_text()

result = dict(status='all original-hold checks clear except the separately retained async wording finding',
              documents=documents, history=dict(validation_prior_body_exact=True,
              runtime_chapter_exact=bind(W / runtime_chapter), vulkan_roadmap_unchanged=True),
              final_ledger=bind(E / 'root/final-validation.json'), validation_peer=bind(E / 'validation-review-1/final-review.json'),
              raw_reports=[bind(E / 'upstream-try-1.json'), bind(E / 'upstream-try-check-1.json')],
              actual_counts=dict(passed=24, unsupported=6, controls=94),
              async_split=[dict(policy=k[0], status=k[1], count=v) for k, v in sorted(split.items())],
              mode_sources=mode_sources, legacy_replays=old,
              python_rosters=rosters, parent_new_groups=dict(passed=6, nonpassing=25, failures_with_subtests=60, errors_with_subtests=46),
              binary_reuse=bind(E / 'root/binary-reuse-1.json'), runtime_git_unchanged=True,
              prior_ci=bind(E / 'root/prior-ci-observation-1.json'), corpus=bind(manifest_path),
              baseline=bind(W / 'tests/conformance/test262-promise-try-current.json'), links=links,
              qualification='Independent stdlib/Git/hash/raw-log review only. No project imports, tests, builds, network or live edits. The original doc-only finding remains pending a separately sealed replacement hold.')
(R / 'checks-original-hold.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status=result['status'], old_cases=1300, old_controls=546, python=683, checked_documents=6)))
