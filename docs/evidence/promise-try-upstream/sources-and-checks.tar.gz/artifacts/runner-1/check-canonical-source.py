"""Derive canonical identities from inert AST literals; do not call runner code."""
from pathlib import Path
import ast, hashlib, json
E=Path('/tmp/eris-promise-try-upstream-plan-1');H=E/'runner-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def digest(b):return hashlib.sha256(b).hexdigest()
source=(H/'raw/tools/test262_conformance.py').read_text();tree=ast.parse(source)
functions={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
def literals(name):return ast.literal_eval(functions[name].body[-1].value)
common=literals('promise_preflight_variants');new=literals('promise_try_preflight_variants')
oraclepath=E/'controls-contract-1/raw/tools/promise-try-controls-oracle.json'
oracle=json.loads(oraclepath.read_bytes())
assert common==oracle['common_variants'] and new==oracle['variants']
pool=E/'importer-contract-1/corpus/tests/upstream/test262-promise-try/harness'
for name,held in oracle['helpers'].items():
 b=(pool/name).read_bytes();assert len(b)==held['bytes'] and digest(b)==held['sha256']
records=[]
for rows,prefix in [(common,'promise-methods-'),(new,'promise-try-')]:
 for mode in ['sloppy','strict']:
  for row in rows:
   name=prefix+row['name'];policy=row['completion_policy']
   refs=[]
   if prefix=='promise-methods-':
    if row['prerequisite']:refs.append(prefix+row['prerequisite'])
    if row['origin']=='original-literal':
     refs.extend(prefix+x['name'] for x in common if x['origin']=='new-prerequisite')
     if row['name']!='one-async-completion':refs.append(prefix+'one-async-completion')
   else:
    refs.extend('promise-methods-'+x['name'] for x in common)
    if row['name']!='api':refs.append('promise-try-api')
    if row['prerequisite'] and prefix+row['prerequisite'] not in refs:refs.append(prefix+row['prerequisite'])
   metadata=dict(flags=['async'] if policy else [],includes=row['includes'],features=[],locale=[],negative=None)
   helpernames=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+row['includes']
   helperids=[dict(name=n,sha256=digest((pool/n).read_bytes())) for n in helpernames]
   identity=dict(source_sha256=digest(row['source'].encode()),mode=mode,metadata=metadata,harness=helperids,completion_policy=policy)
   fingerprint=digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
   records.append(dict(name=name,mode=mode,id='harness-preflight:'+name,file='<preflight>',metadata=metadata,source=row['source'],source_sha256=identity['source_sha256'],harness=helperids,completion_policy=policy,expected=row['expected'],prerequisites=[[n,mode] for n in refs],case_sha256=fingerprint))
assert len(records)==94
for actual,held in zip(records,oracle['records']):
 for key,value in actual.items():assert held[key]==value,(actual['name'],actual['mode'],key)
lookup={(row['name'],row['mode']):row for row in records}
for held in oracle['records']:
 refs=[dict(name=name,mode=mode,verified=True,case_sha256=lookup[(name,mode)]['case_sha256'],source_sha256=lookup[(name,mode)]['source_sha256']) for name,mode in held['prerequisites']]
 assert refs==held['prerequisite_references']
# The production cases/reference/health/harness scaffolding is the existing Any
# pattern under name-only substitution; checks use the selected default APIs.
parent=(H/'before/tools/test262_conformance.py').read_text();pt=ast.parse(parent)
pf={n.name:ast.get_source_segment(parent,n) for n in pt.body if isinstance(n,ast.FunctionDef)}
for old,newname in [('promise_any_preflight_cases','promise_try_preflight_cases'),('promise_any_preflight_reference','promise_try_preflight_reference'),('promise_any_preflight_healthy','promise_try_preflight_healthy'),('promise_any_harness_preflight','promise_try_harness_preflight')]:
 expected=pf[old].replace('promise_any','promise_try').replace('promise-any-','promise-try-').replace('PROMISE_ANY','PROMISE_TRY').replace('102','94')
 assert ast.get_source_segment(source,functions[newname])==expected,newname
protected=json.loads((E/'preservation-contract-1/raw/tools/promise-try-preservation-oracle.json').read_bytes())['unchanged_functions']['tools/test262_conformance.py']
assert all(digest(ast.get_source_segment(source,functions[name]).encode())==sha for name,sha in protected.items())
report=dict(status='clear source-only self-check',production=bind(H/'source-ready.json'),oracle=bind(oraclepath),script=bind(Path(__file__)),common_variants=37,new_variants=10,canonical_rows=94,exact_case_source_helper_metadata_policy_fingerprints=True,exact_prerequisite_edges_and_references=True,protected_old_bodies=63,qualification='Inert AST literal/hash derivation only. No runner/importer function or test was executed; root frozen executable tests remain the behavioral oracle.',records=records)
with (H/'canonical-source-check.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(bind(H/'canonical-source-check.json')))
