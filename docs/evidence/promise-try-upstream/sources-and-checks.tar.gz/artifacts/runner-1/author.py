"""External Try runner payload; bound independent contracts, source/AST only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import pprint

E=Path('/tmp/eris-promise-try-upstream-plan-1');H=E/'runner-1';REL='tools/test262_conformance.py'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,v):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
contracts={
 'protocol-contract-1/source-ready.json':'46c52fd8b1a7ece5f3dcc4c0a7879662d95e853e714b0d73e55d5ce7b3649df1',
 'controls-contract-1/source-ready.json':'5e94f5654d61695549eb8743c8f990601a14aaec463ecbd8694d296d1b98e89e',
 'controls-contract-1/oracle-ready.json':'ae1e9528bc55012a5ebd87791697aed17517c235f6c1cb5112f03e04489ebf9f',
}
for rel,sha in contracts.items():assert bind(E/rel)['sha256']==sha
variants=json.loads((E/'controls-contract-1/variants.json').read_bytes())
assert len(variants)==10
before=(H/'before'/REL).read_text();after=before;edits=[]
def replace(label,old,new):
 global after
 assert after.count(old)==1,label
 after=after.replace(old,new,1);edits.append(dict(label=label,before=old,after=new))
replace('standalone selected features and host membership',
        'PROFILE_FEATURES[PROMISE_WITH_RESOLVERS_PROFILE] = PROMISE_WITH_RESOLVERS_FEATURES\n',
        'PROFILE_FEATURES[PROMISE_WITH_RESOLVERS_PROFILE] = PROMISE_WITH_RESOLVERS_FEATURES\n'
        "PROMISE_TRY_PROFILE = 'promise-try'\n"
        "PROMISE_TRY_FEATURES = {'Reflect.construct', 'promise-try'}\n"
        'PROFILE_FEATURES[PROMISE_TRY_PROFILE] = PROMISE_TRY_FEATURES\n'
        'PROMISE_HOST_PROFILES.add(PROMISE_TRY_PROFILE)\n')
for label,anchor in [
 ('root-linked auxiliary authentication','\n    if profile in {PROMISE_WITH_RESOLVERS_PROFILE,'),
 ('exact complete package inventory','\n        if profile in {PROMISE_WITH_RESOLVERS_PROFILE,')]:
 replace(label,anchor,anchor.replace('{PROMISE_WITH_RESOLVERS_PROFILE,','{PROMISE_TRY_PROFILE, PROMISE_WITH_RESOLVERS_PROFILE,'))
replace('selected wire downgrade refusal before shared decoder',
        'def decode_response(output, *, profile=None):\n',
        'def decode_response(output, *, profile=None):\n'
        "    if profile == PROMISE_TRY_PROFILE and not output.startswith(b'ERJR3'):\n"
        "        raise ValueError('Promise.try profile requires an ERJR3 response')\n")
replace('selected decoder context preserving old route arities',
        '                                      PROMISE_WITH_RESOLVERS_PROFILE} else decode_response(output))\n',
        '                                      PROMISE_WITH_RESOLVERS_PROFILE, PROMISE_TRY_PROFILE} else decode_response(output))\n')
replace('selected direct shared classification without generic fallback',
        '        status = (classify(case, observation, profile=profile)\n'
        '                  if profile == PROMISE_ANY_PROFILE else classify(case, observation))\n',
        '        status = (classify_promise(case, observation) if profile == PROMISE_TRY_PROFILE\n'
        '                  else classify(case, observation, profile=profile)\n'
        '                  if profile == PROMISE_ANY_PROFILE else classify(case, observation))\n')
replace('selected preflight dispatch',
        "def harness_preflight(files, binary, timeout, profile='string-json'):\n",
        "def harness_preflight(files, binary, timeout, profile='string-json'):\n"
        '    if profile == PROMISE_TRY_PROFILE:\n'
        '        return promise_try_harness_preflight(files, binary, timeout)\n')
replace('main selected canonical health before inherited host blocking',
        '        preflight_ok = (with_resolvers_preflight_healthy(preflight, files) if args.profile == PROMISE_WITH_RESOLVERS_PROFILE\n',
        '        preflight_ok = (promise_try_preflight_healthy(preflight, files) if args.profile == PROMISE_TRY_PROFILE\n'
        '                        else with_resolvers_preflight_healthy(preflight, files) if args.profile == PROMISE_WITH_RESOLVERS_PROFILE\n')

factory='def promise_try_preflight_variants():\n    """Frozen Try literals, once per logical variant; modes expand below."""\n    return '+pprint.pformat(variants,width=100,sort_dicts=False).replace('\n','\n    ')+'\n'
# Reuse the reviewed canonical construction pattern as source text, with only
# the new profile namespace changed. No project function is called here.
tree=ast.parse(before)
sources={n.name:ast.get_source_segment(before,n) for n in tree.body if isinstance(n,ast.FunctionDef)}
cases=sources['promise_any_preflight_cases'].replace('promise_any','promise_try').replace('promise-any-','promise-try-')+'\n'
reference=sources['promise_any_preflight_reference'].replace('promise_any','promise_try')+'\n'
checks='''def promise_try_preflight_checks(outcomes, files):
    """Recheck canonical identities, raw host evidence and prerequisite health."""
    try:
        definitions = promise_try_preflight_cases(files)
        if not isinstance(outcomes, list) or len(outcomes) != 94 or len(definitions) != 94:
            return None
        canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
        if len(canonical) != 94:
            return None
        observed = {}
        for item in outcomes:
            if (not isinstance(item, dict)
                    or set(item) != {'name', 'expected', 'verified', 'result', 'prerequisites'}
                    or not isinstance(item['name'], str)
                    or not isinstance(item['expected'], str)
                    or type(item['verified']) is not bool
                    or not isinstance(item['result'], dict)
                    or not isinstance(item['result'].get('mode'), str)
                    or not isinstance(item['prerequisites'], list)):
                return None
            identity = (item['name'], item['result']['mode'])
            if identity in observed or identity not in canonical:
                return None
            observed[identity] = item
        if observed.keys() != canonical.keys():
            return None
        raw_checks = {}
        for identity, (row, case) in canonical.items():
            item, result = observed[identity], observed[identity]['result']
            expected_status = ('passed' if row['expected'] == 'passed' else
                               'resource' if row['expected'] == 'resource' else 'failed')
            expected_result = {key: case[key] for key in ('id', 'file', 'mode', 'case_sha256')}
            expected_result.update(source_sha256=digest(case['source']),
                                   expected_negative=case['metadata']['negative'], status=expected_status)
            expected_prerequisites = [promise_try_preflight_reference(*canonical[key])
                                      for key in row['prerequisites']]
            prerequisites = item['prerequisites']
            good = (item['expected'] == row['expected']
                    and set(result) == set(expected_result) | {'observation'}
                    and all(result.get(key) == value for key, value in expected_result.items())
                    and len(prerequisites) == len(expected_prerequisites)
                    and all(isinstance(ref, dict)
                            and set(ref) == {'name', 'mode', 'verified', 'case_sha256', 'source_sha256'}
                            and type(ref.get('verified')) is bool
                            and all(isinstance(ref.get(key), str) for key in
                                    ('name', 'mode', 'case_sha256', 'source_sha256'))
                            for ref in prerequisites)
                    and prerequisites == expected_prerequisites
                    and isinstance(result.get('observation'), dict))
            if good:
                observation = result['observation']
                try:
                    validate_promise_observation(observation)
                    good = (observation['completion']['policy'] == case['completion_policy']
                            and classify_promise(case, observation) == expected_status
                            and promise_preflight_verified(case, result, row['expected']))
                    # Preserve common74 verifier semantics. New semantic rows
                    # additionally freeze their complete successful setup and
                    # completion counters; synchronous diagnostics stay bounded.
                    if good and row['name'].startswith('promise-try-'):
                        policy = case['completion_policy']
                        counts = (1, 1, 0) if policy else (0, 0, 0)
                        flags = 0
                        if row['expected'] == 'synchronous-exception':
                            flags = 256
                        elif row['expected'] == 'completion-error':
                            counts, flags = (1, 0, 1), 1
                        good = observation['harness'] == '' and observation['completion'] == dict(
                            policy=policy, done_calls=counts[0], success_prints=counts[1],
                            failure_prints=counts[2], flags=flags,
                            quiescent=True, audited=True, unhandled=0)
                except (KeyError, TypeError, ValueError):
                    good = False
            raw_checks[identity] = good
        checked, visiting = {}, set()

        def healthy(identity):
            if identity in checked:
                return checked[identity]
            if identity in visiting:
                return False
            visiting.add(identity)
            row, _ = canonical[identity]
            value = raw_checks[identity] and all(healthy(key) for key in row['prerequisites'])
            visiting.remove(identity)
            checked[identity] = value
            return value

        for identity in canonical:
            healthy(identity)
        return checked
    except (KeyError, TypeError, ValueError):
        return None
'''
healthy=sources['promise_any_preflight_healthy'].replace('promise_any','promise_try').replace('102','94')+'\n'
harness=sources['promise_any_harness_preflight'].replace('promise_any','promise_try').replace('PROMISE_ANY','PROMISE_TRY')+'\n'
payload='\n\n'.join([factory,cases,reference,checks,healthy,harness])
payload_path=H/'payload/try-preflight.py';payload_path.parent.mkdir(parents=True,exist_ok=True)
with payload_path.open('x') as f:f.write(payload)
replace('six isolated Try canonical gate functions',
        'def check_baseline(previous, current):\n',payload+'\n\ndef check_baseline(previous, current):\n')

newtree=ast.parse(after)
newfuncs={n.name:ast.get_source_segment(after,n) for n in newtree.body if isinstance(n,ast.FunctionDef)}
changed=[name for name in sources if sources[name]!=newfuncs[name]]
assert changed==['load_corpus','decode_response','run_case','harness_preflight','main'],changed
added=[name for name in newfuncs if name not in sources]
assert added==['promise_try_preflight_variants','promise_try_preflight_cases','promise_try_preflight_reference','promise_try_preflight_checks','promise_try_preflight_healthy','promise_try_harness_preflight']
factory_node=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name==added[0])
assert ast.literal_eval(factory_node.body[-1].value)==variants
restored=after
for edit in reversed(edits):
 assert restored.count(edit['after'])==1,edit['label']
 restored=restored.replace(edit['after'],edit['before'],1)
assert restored==before
raw=H/'raw'/REL;raw.parent.mkdir(parents=True,exist_ok=True)
with raw.open('x') as f:f.write(after)
diff=H/'diffs/tools__test262_conformance.py.diff';diff.parent.mkdir(parents=True,exist_ok=True)
with diff.open('x') as f:f.write(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)))
dump(H/'edit-manifest.json',dict(edits=edits,whole_file_inverse_exact=True))
dump(H/'function-ledger.json',[dict(name=name,changed=name in changed,before_sha256=hashlib.sha256(value.encode()).hexdigest(),raw_sha256=hashlib.sha256(newfuncs[name].encode()).hexdigest()) for name,value in sources.items()])
dump(H/'source-ready.json',dict(status='sealed external runner-only payload; AST/source checks, no execution',base='15db31c76f5a2f259deffadbf0f95e212a5fa61c',
 selection=bind(E/'root/selection-1.json'),snapshot=bind(H/'snapshot-ready.json'),contracts=[bind(E/p) for p in contracts],
 gate_contract=bind(E/'controls-contract-1/gate-contract.json'),literal_variants=bind(E/'controls-contract-1/variants.json'),
 files=[dict(relative_path=REL,before=bind(H/'before'/REL),raw=bind(raw),diff=bind(diff),new=False)],
 payload=bind(payload_path),edits=bind(H/'edit-manifest.json'),functions=bind(H/'function-ledger.json'),author=bind(Path(__file__)),
 checks=dict(ast_parse=True,changed_old_functions=changed,unchanged_old_functions=len(sources)-len(changed),new_functions=added,exact_full_inverse=True,exact_ten_literal_variants=True,execution=False),
 qualification='All60 prior policies/default arities/shared helpers remain source-preserved. Selected Try strict ERJR3 routes to unchanged default-seven decoder and classifier; no Rust, corpus, baseline, CI or old-test edits. Actual94 gate and30 originals await root-owned frozen-test execution.'))
print(json.dumps(bind(H/'source-ready.json')))
