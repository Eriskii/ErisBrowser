"""Independent source/JSON/AST derivation; does not import or execute project code."""
from pathlib import Path
import ast,collections,hashlib,json,re,shutil,subprocess
D=Path('/tmp/eris-promise-try-runtime-plan-1');O=D/'next-upstream-readiness-1';W=D/'worktree';BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9';REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def gh(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
P=W/'tests/upstream/test262-promise-with-resolvers'
leaf='8e31e175a3e53480752c825f7f89f364220d643a';trees={};proof=[]
for f in (P/'inventory-proof').glob('*.json'):
 if f.name=='tree-062393e615d0cf97a0252e6a93923bd91444a455.json':continue
 p=O/'proof'/f.name;p.write_bytes(f.read_bytes());proof.append({'origin':str(f),'copy':bind(p)})
for f in (O/'proof').glob('tree-*.json'):
 j=json.loads(f.read_text());assert not j['truncated'];rows=sorted(j['tree'],key=lambda r:(r['path']+('/' if r['type']=='tree' else '')).encode());raw=b''.join(r['mode'].lstrip('0').encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha']) for r in rows);assert gh('tree',raw)==j['sha'];trees[j['sha']]=j
commit=json.loads((O/'proof/commit.json').read_text());assert commit['sha']==REV;root=commit['tree']['sha'];assert root=='91b2052adad1f066ae031e2ff3a1e9bd6d732886'
chain=[];node=root
for part in ['test','built-ins','Promise','try']:
 row=next(r for r in trees[node]['tree'] if r['path']==part);assert row['type']=='tree';chain.append({'parent':node,'name':part,'tree':row['sha']});node=row['sha']
assert node==leaf and len(trees)==6
harness=next(r for r in trees[root]['tree'] if r['path']=='harness')['sha'];hrows={r['path']:r for r in trees[harness]['tree']}
helpers=['assert.js','sta.js','doneprintHandle.js','asyncHelpers.js','compareArray.js','isConstructor.js','propertyHelper.js','promiseHelper.js'];aux=[]
for name in helpers:
 source=(W/'tests/upstream/test262-for-of/harness'/name) if name=='asyncHelpers.js' else (W/'tests/upstream/test262-promise-race/harness'/name)
 if not source.exists():source=W/'tests/upstream/test262-promise-any/harness'/name
 data=source.read_bytes();assert gh('blob',data)==hrows[name]['sha'] and len(data)==hrows[name]['size'];p=O/'helpers'/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data)
 aux.append({'name':name,'origin':str(source),'git_blob':hrows[name]['sha'],'file':bind(p),'role':'common37 guard only' if name=='promiseHelper.js' else 'corpus metadata/default closure'})
for name in ['LICENSE','INTERPRETING.md']:
 data=(P/name).read_bytes();row=next(r for r in trees[root]['tree'] if r['path']==name);assert gh('blob',data)==row['sha'];p=O/'legal'/name;p.parent.mkdir(exist_ok=True);p.write_bytes(data);aux.append({'name':name,'origin':str(P/name),'git_blob':row['sha'],'file':bind(p),'role':'legal'})
rows=[];features=collections.Counter();includes=collections.Counter();flags=collections.Counter();identities=[]
for p in sorted((O/'sources').glob('*.js')):
 source=p.read_text();front=re.search(r'/\*---(.*?)---\*/',source,re.S).group(1);metadata={}
 for key in ['flags','includes','features','locale']:
  found=re.search(r'^'+key+r':\s*\[([^\]]*)\]\s*$',front,re.M);metadata[key]=[x.strip() for x in found[1].split(',') if x.strip()] if found else []
 assert not re.search(r'^(negative|timeout|locale):',front,re.M);metadata['negative']=None
 features.update(metadata['features']);includes.update(metadata['includes']);flags.update(metadata['flags']);assert not(set(metadata['flags'])-{'async'})
 policy=int('async' in metadata['flags']);names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+metadata['includes'];srcsha=bind(p)['sha256']
 row={'name':p.name,'file':bind(p),'metadata':metadata,'completion_policy':policy,'helper_order':names,'modes':['sloppy','strict'],'body_class_syntax':bool(re.search(r'\bclass\s+\w+',source))};rows.append(row)
 for mode in ['sloppy','strict']:
  ident={'source_sha256':srcsha,'mode':mode,'metadata':metadata,'harness':[{'name':n,'sha256':bind(O/'helpers'/n)['sha256']} for n in names],'completion_policy':policy}
  identities.append({'id':'test/built-ins/Promise/try/'+p.name+':'+mode,'case_sha256':hashlib.sha256(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode()).hexdigest(),'source_sha256':srcsha,'mode':mode,'completion_policy':policy})
bindings=[]
for relative in ['tools/import_test262.py','tools/test262_conformance.py','src/script/promises/semantics.rs','src/script/test262_host.rs','src/bin/eris-js.rs']:
 data=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+relative]);p=O/'parent'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);bindings.append({'relative':relative,'file':bind(p),'published_base':BASE})
runner=(O/'parent/tools/test262_conformance.py').read_text();tree=ast.parse(runner);func=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='promise_preflight_variants');common=ast.literal_eval(next(n for n in func.body if isinstance(n,ast.Return)).value);assert len(common)==37
imptree=ast.parse((O/'parent/tools/import_test262.py').read_text());profiles=next(n.value for n in imptree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROFILES' for t in n.targets));names=[ast.literal_eval(k) for k in profiles.keys];assert len(names)==60
out={'base':BASE,'revision':REV,'root_tree':root,'ancestry':chain,'tree_files':6,'commit_binding':bind(O/'proof/commit.json'),'proof_copies':proof,'all_tree_objects_reconstructed':True,'source_count':len(rows),'mode_count':len(identities),'async_sources':flags['async'],'sync_sources':len(rows)-flags['async'],'feature_counts':dict(sorted(features.items())),'include_counts':dict(sorted(includes.items())),'flag_counts':dict(flags),'negative_sources':0,'files':rows,'case_identities':identities,'auxiliary':aux,'raw_source_helper_count':7,'proposed_common37_helper_count':8,'proposed_packaged_file_count':15+8+2+7+1,'old_profile_names':names,'old_profile_count':len(names),'common37_literal_sha256':hashlib.sha256(json.dumps(common,sort_keys=True).encode()).hexdigest(),'source_bindings':bindings}
(O/'source-census.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:out[k] for k in ['source_count','mode_count','async_sources','sync_sources','feature_counts','include_counts','raw_source_helper_count','proposed_common37_helper_count','old_profile_count','proposed_packaged_file_count']},indent=2))
