"""Read-only pinned upstream retrieval into this external readiness hold."""
from pathlib import Path
import urllib.request,hashlib,json,concurrent.futures
O=Path('/tmp/eris-promise-try-runtime-plan-1/next-upstream-readiness-1');REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd';SHA='8e31e175a3e53480752c825f7f89f364220d643a'
def get(url):
 with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Eris-source-readiness'}),timeout=30) as r:return r.read()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
url='https://api.github.com/repos/tc39/test262/git/trees/'+SHA
b=get(url);j=json.loads(b);assert j['sha']==SHA and j['truncated'] is False
assert all(r['type']=='blob' and r['mode']=='100644' and r['path'].endswith('.js') and '/' not in r['path'] for r in j['tree'])
def objhash(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
entries=sorted(j['tree'],key=lambda r:r['path'].encode());raw=b''.join(r['mode'].lstrip('0').encode()+b' '+r['path'].encode()+b'\0'+bytes.fromhex(r['sha']) for r in entries);assert objhash('tree',raw)==SHA
(O/'proof').mkdir(exist_ok=True);p=O/'proof'/('tree-'+SHA+'.json');p.write_bytes(b)
(O/'sources').mkdir(exist_ok=True)
def one(r):
 u='https://raw.githubusercontent.com/tc39/test262/'+REV+'/test/built-ins/Promise/try/'+r['path'];b=get(u)
 assert len(b)==r['size'] and objhash('blob',b)==r['sha'];p=O/'sources'/r['path'];p.write_bytes(b)
 return {'name':r['path'],'url':u,'git_blob':r['sha'],'file':bind(p)}
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:rows=list(pool.map(one,entries))
receipt={'revision':REV,'tree_url':url,'tree':bind(O/'proof'/('tree-'+SHA+'.json')),'complete_tree_oid':SHA,'files':rows,'sources':len(rows),'bytes':sum(r['file']['bytes'] for r in rows),'authentication':'Full nonrecursive tree Git object reproduced; every raw source size and Git blob hash reproduced. Root ancestry joins retained published proof separately.','initial_attempt':'Sandbox DNS lookup failed before any fetched bytes; this retry uses read-only authorized networking.'}
(O/'fetch-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({'sources':len(rows),'bytes':receipt['bytes'],'names':[r['name'] for r in rows]}))
