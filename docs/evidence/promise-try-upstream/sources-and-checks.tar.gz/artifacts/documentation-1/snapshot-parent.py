from pathlib import Path
import hashlib
import json
import subprocess

E = Path('/tmp/eris-promise-try-upstream-plan-1')
D = E / 'documentation-1'
W = E / 'worktree'
BASE = '15db31c76f5a2f259deffadbf0f95e212a5fa61c'
PATHS = ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
         'docs/SECURITY.md', 'docs/VALIDATION.md', 'docs/promise-try-upstream.md']

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

rows = []
for rel in PATHS + ['docs/promise-try.md']:
    found = subprocess.run(['git', 'show', f'{BASE}:{rel}'], cwd=W,
                           capture_output=True, check=False)
    if rel == 'docs/promise-try-upstream.md':
        assert found.returncode != 0 and not (W / rel).exists()
        rows.append({'relative_path': rel, 'parent_absent': True, 'selected': True})
        continue
    assert found.returncode == 0 and found.stdout == (W / rel).read_bytes(), rel
    target = D / 'before' / rel
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(found.stdout)
    rows.append({'relative_path': rel, 'before': bind(target),
                 'selected': rel in PATHS, 'published_git_exact': True})

record = {
    'status': 'published documentation snapshotted; outcome prose pending actual evidence',
    'base': BASE,
    'files': rows,
    'selection': bind(E / 'root/selection-1.json'),
    'source_parent': bind(E / 'source-parent.json'),
    'readiness_refresh': bind(E / 'root/readiness-base-refresh.json'),
    'selected_parent_observation': bind(E / 'root/selected-parent-observation.json'),
    'immutable_runtime_chapter': 'docs/promise-try.md',
    'historical_validation_rule': 'Prepend the new current checkpoint section after the title; preserve every byte of the prior body.',
    'awaiting': ['actual focused/full Python receipts and rosters',
                 'actual complete 30-case/94-control profile and baseline/replay evidence',
                 'seven legacy complete 1300-case/546-control arrays',
                 'source-final, unchanged Rust/binary joins, final validation ledger'],
    'selected_parent_qualification': '31 groups: 6 passed and 25 nonpassing. The 60 failure and 46 error observations include subtests; they are not 106 groups.',
    'scope': 'Six documentation paths only; no live writes or project execution. No candidate or upstream outcome is predicted.'
}
target = D / 'parent-snapshot.json'
assert not target.exists()
target.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(bind(target)))
