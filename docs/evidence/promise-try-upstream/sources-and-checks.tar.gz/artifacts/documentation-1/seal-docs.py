from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import re
import subprocess

E = Path('/tmp/eris-promise-try-upstream-plan-1')
D = E / 'documentation-1'
W = E / 'worktree'
BASE = '15db31c76f5a2f259deffadbf0f95e212a5fa61c'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_bytes())
def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
def put(name, data):
    path = D / name
    assert not path.exists(), path
    path.write_text(json.dumps(data, indent=2) + '\n')
    return bind(path)

bound = {}
def verify_bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and Path(value['path']).is_absolute():
            actual = bind(Path(value['path']))
            assert all(actual[k] == value[k] for k in actual), value['path']
            bound[value['path']] = actual
        for item in value.values(): verify_bindings(item)
    elif isinstance(value, list):
        for item in value: verify_bindings(item)

ledger = read(E / 'root/final-validation.json')
assert bind(E / 'root/final-validation.json')['sha256'] == '62e129f47ef34bbd311594f5167979d5b589210153b7212cd3c58ce4e004f4a4'
assert ledger['status'] == 'pass' and ledger['base'] == BASE
draft = read(D / 'draft.json')
verify_bindings(ledger)
verify_bindings(draft)
verify_bindings(read(E / 'root/binary-reuse-1.json'))
assert len(ledger['validation_receipts']) == 13

rosters = {}
for name, count in [('python-parent-1', 652), ('python-selected-candidate-1', 31), ('python-full-1', 683)]:
    text = (E / 'validation' / (name + '.log')).read_text()
    pairs = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. (ok)$', text, re.M)
    names = [x[0] for x in pairs]
    assert len(names) == len(set(names)) == count
    assert re.search(rf'^Ran {count} tests in ', text, re.M) and text.rstrip().endswith('OK')
    rosters[name] = sorted(names)
assert set(rosters['python-full-1']) == set(rosters['python-parent-1']) | set(rosters['python-selected-candidate-1'])
assert not set(rosters['python-parent-1']) & set(rosters['python-selected-candidate-1'])
parent_log = (E / 'validation/python-selected-parent-1.log').read_text()
parent_rows = re.findall(r'^test_\S+ \(([^)]+)\) \.\.\.([^\n]*)$', parent_log, re.M)
parent_groups = {}
for name, result in parent_rows:
    result = result.strip()
    if name in parent_groups:
        assert not parent_groups[name] and result in {'FAIL', 'ERROR'}
    parent_groups[name] = result
assert len(parent_groups) == 31 and sum(x == 'ok' for x in parent_groups.values()) == 6
assert 'FAILED (failures=60, errors=46)' in parent_log
assert set(parent_groups) == set(rosters['python-selected-candidate-1'])

report = read(E / 'upstream-try-1.json')
replay = read(E / 'upstream-try-check-1.json')
for key in ['cases', 'harness_preflight', 'counts', 'runner_policy', 'runner_policy_sha256',
            'corpus_manifest_sha256', 'binary_sha256']:
    assert report[key] == replay[key], key
assert Counter(x['status'] for x in report['cases']) == {'passed': 24, 'unsupported': 6}
assert len(report['cases']) == 30 and len(report['harness_preflight']) == 94
assert all(x['verified'] is True for x in report['harness_preflight'])
assert report['harness_preflight_passed'] is True and replay['harness_preflight_passed'] is True
assert report['regressions'] == replay['regressions'] == report['improvements'] == replay['improvements'] == []
assert report['negative_source_tests'] == 0 and report['fixture_files'] == []
oracle = read(E / 'importer-contract-1/raw/tools/test262-promise-try-import-oracle.json')
assert [{'id': x['id'], 'case_sha256': x['case_sha256']} for x in report['cases']] == oracle['case_identities']
mode_counts = Counter()
for row in report['cases']:
    metadata = oracle['metadata'][row['file']]
    policy = int('async' in metadata['flags'])
    mode_counts[policy] += 1
    if 'class' in metadata['features']:
        assert row['status'] == 'unsupported' and row['reason'] == 'unimplemented declared features: class'
        assert 'observation' not in row
    else:
        assert row['status'] == 'passed' and row['observation']['completion']['policy'] == policy
assert mode_counts == {0: 22, 1: 8}
baseline = read(W / 'tests/conformance/test262-promise-try-current.json')
assert set(baseline) == {'revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'binary_sha256', 'cases'}
for key in set(baseline) - {'cases'}: assert baseline[key] == report[key]
assert baseline['cases'] == {r['id']: {k:r[k] for k in ['status','case_sha256','source_sha256']} for r in report['cases']}
control_oracle = read(E / 'controls-contract-1/raw/tools/promise-try-controls-oracle.json')
canonical = {(r['name'],r['mode']):r for r in control_oracle['records']}
for row, expected in zip(report['harness_preflight'], control_oracle['records'], strict=True):
    assert row['name'] == expected['name'] and row['expected'] == expected['expected']
    references = []
    for name, mode in expected['prerequisites']:
        prerequisite = canonical[name,mode]
        references.append({'name':name,'mode':mode,'verified':True,
                           'case_sha256':prerequisite['case_sha256'],
                           'source_sha256':prerequisite['source_sha256']})
    assert row['prerequisites'] == references
    for key in ['id', 'file', 'mode', 'source_sha256', 'case_sha256']:
        assert row['result'][key] == expected[key]

legacy = []
for path in sorted((E / 'replay-parent').glob('upstream-*-1.json')):
    before = read(path); after = read(E / path.name)
    for key in ['cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
                'corpus_manifest_sha256', 'binary_sha256', 'counts']:
        assert before[key] == after[key], (path.name, key)
    legacy.append({'parent': bind(path), 'replay': bind(E/path.name),
                   'cases': len(after['cases']), 'controls': len(after['harness_preflight'])})
assert len(legacy) == 7 and sum(x['cases'] for x in legacy) == 1300 and sum(x['controls'] for x in legacy) == 546

inventory = read(E / 'source-final.json')['source_sha256']
candidate = read(E / 'source-candidate-1.json')['source_sha256']
assert len(inventory) == 1820 and set(inventory) - set(candidate) == {'tests/conformance/test262-promise-try-current.json'}
assert all(inventory[k] == v for k,v in candidate.items())
for rel, digest in inventory.items(): assert sha((W / rel).read_bytes()) == digest, rel
ci = read(E / 'root/prior-ci-observation-1.json')
assert ci['databaseId'] == 38817823918 and ci['headSha'] == BASE and ci['conclusion'] == 'success'
assert len(ci['jobs']) == 11 and all(x['conclusion'] == 'success' for x in ci['jobs'])

files = draft['files']
assert len(files) == 6
links = []
future_links = {'docs/evidence/promise-try-upstream/manifest.json', 'docs/evidence/promise-try-upstream/sources-and-checks.tar.gz'}
from posixpath import normpath
for row in files:
    rel = row['relative_path']; raw = Path(row['raw']['path']).read_bytes()
    before = Path(row['before']['path']).read_bytes() if row['before'] else b''
    if row['before']:
        assert before == subprocess.check_output(['git', 'show', f'{BASE}:{rel}'], cwd=W)
    expected_diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), raw.decode().splitlines(True),
                                               fromfile=rel if before else '/dev/null', tofile=rel)).encode()
    assert expected_diff == Path(row['diff']['path']).read_bytes()
    assert not any(line.rstrip() != line for line in raw.decode().splitlines())
    new_links = set(re.findall(r'\]\(([^)]+)\)', raw.decode())) - set(re.findall(r'\]\(([^)]+)\)', before.decode()))
    for link in sorted(new_links):
        if '://' in link or link.startswith('#'): continue
        target = normpath(str(Path(rel).parent / link.split('#')[0]))
        exists = (D / 'raw' / target).exists() or (W / target).exists()
        assert exists or target in future_links, (rel, link)
        links.append({'from': rel, 'link': link, 'target': target,
                      'status': 'existing or held' if exists else 'root-selected future evidence destination'})
title = b'# Validation record\n\n'
old_validation = (D / 'before/docs/VALIDATION.md').read_bytes()
new_validation = (D / 'raw/docs/VALIDATION.md').read_bytes()
assert new_validation.startswith(title) and new_validation.endswith(old_validation[len(title):])
runtime = (D / 'before/docs/promise-try.md').read_bytes()
assert runtime == (W / 'docs/promise-try.md').read_bytes() == subprocess.check_output(['git','show',f'{BASE}:docs/promise-try.md'],cwd=W)
marker = b'## Vulkan rendering backend'
assert (D/'raw/docs/ROADMAP.md').read_bytes().split(marker,1)[1] == (D/'before/docs/ROADMAP.md').read_bytes().split(marker,1)[1]
assert all('PENDING_' not in Path(row['raw']['path']).read_text() for row in files)

checks = put('claims-and-checks.json', {
    'status': 'clear', 'final_ledger': bind(E/'root/final-validation.json'),
    'verified_bindings': list(bound.values()), 'python_rosters': rosters,
    'parent_selected': {'groups':31,'passed':6,'nonpassing':25,'failure_observations':60,'error_observations':46,
                        'summary_lines':len(parent_rows),'qualification':'Four repeated top-level status lines are deduplicated by full test identity; initial local audit stopped before receipt creation until this parser distinction was applied. Raw logs and documentation outcomes unchanged.'},
    'new_profile': {'cases':30,'passed':24,'unsupported':6,'sync_modes':22,'async_modes':8,'controls':94,
                    'complete_case_and_control_arrays_exact':True,'baseline_projection_exact':True,
                    'frozen_oracle_identities_exact':True,
                    'prerequisite_comparison':'The frozen oracle stores name/mode pairs; the audit reconstructs the five-field report references. An initial comparison of unlike representations stopped before receipt creation; no project or report changed.'},
    'legacy_complete_arrays':legacy, 'final_selected_source_hashes_verified':1820,
    'prior_ci': {'run':38817823918,'jobs':11,'all_success':True,'applies_only_to':BASE},
    'historical_validation_body_exact':True, 'runtime_chapter_exact':True,
    'vulkan_roadmap_exact':True, 'before_raw_diff_joins_exact':True,
    'scope':'Documentation claim checks only; no project import/execution or live source write.'})
link_binding = put('links.json', {'links':links,'future_evidence_paths':sorted(future_links)})
seal = put('source-ready.json', {
    'status':'ready for independent review and root import', 'base':BASE,
    'files':files, 'final_validation':bind(E/'root/final-validation.json'),
    'source_final':bind(E/'source-final.json'), 'claims_and_checks':checks, 'links':link_binding,
    'parent_snapshot':bind(D/'parent-snapshot.json'),
    'authors':[bind(D/'snapshot-parent.py'),bind(D/'author-docs.py'),bind(D/'seal-docs.py')],
    'scope':'Six documentation paths only. Historical validation body, Promise.try runtime chapter and Vulkan roadmap remain exact. Root owns import/archive/publication.',
    'qualification':'Observed24/6 and94controls,683Python; exact30/94 new and1300/546 old complete arrays. Reused binaries and no new Rust execution. Prior CI success applies only to15db.'})
print(json.dumps(seal))
