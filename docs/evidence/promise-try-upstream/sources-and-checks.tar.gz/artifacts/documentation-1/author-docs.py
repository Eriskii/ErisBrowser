from pathlib import Path
import difflib
import hashlib
import json

E = Path('/tmp/eris-promise-try-upstream-plan-1')
D = E / 'documentation-1'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}

def replace_once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new, 1)

texts = {rel: (D / 'before' / rel).read_text() for rel in [
    'README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
    'docs/SECURITY.md', 'docs/VALIDATION.md']}

texts['README.md'] = replace_once(texts['README.md'],
'''and existing terminal suspension. This runtime checkpoint adds no dedicated
Promise.try upstream profile.
''',
'''and existing terminal suspension. Its separate [complete pinned upstream
profile](docs/promise-try-upstream.md) retains all 15 sources and 30 modes:
**24 passed and six unsupported**, with all **94 controls verified**.
The six class-tagged modes remain excluded; authenticated completion uses the
existing Promise host adapter.
''')

texts['docs/COMPATIBILITY.md'] = replace_once(texts['docs/COMPATIBILITY.md'],
'''There is no dedicated Promise.try upstream result in this checkpoint.
''',
'''The separate [complete pinned Try profile](promise-try-upstream.md) retains
all 15 sources and 30 modes, recording **24 passed and six unsupported** with
all **94 controls verified**. Both modes of each of three class-tagged sources
remain excluded before adapter execution. The profile uses existing ERJS2/ERJR3
completion evidence and the seven intrinsic error identities; it adds no class,
async-function or realm support.
''')

texts['docs/ROADMAP.md'] = replace_once(texts['docs/ROADMAP.md'],
'''limits. A dedicated pinned upstream profile remains subsequent work; reference
sources and readiness notes alone establish no upstream outcomes.
''',
'''limits. Its separate [complete pinned upstream profile](promise-try-upstream.md)
now retains all 15 sources and 30 modes: 24 passed and six class-metadata
exclusions, with all 94 controls verified. The existing host adapter supplies
authenticated completion; all seven older profile reports remain exact.
''')

texts['docs/SECURITY.md'] = replace_once(texts['docs/SECURITY.md'],
'''charges do not certify complete allocation coverage or process-memory bounds.

## Representative limits
''',
'''charges do not certify complete allocation coverage or process-memory bounds.

The [Try upstream profile](promise-try-upstream.md) requires the existing
ERJS2/ERJR3 host transport and seven intrinsic error identities. Its 94-control
gate checks canonical source/helper identities, complete raw completion fields
and same-mode prerequisites, then recomputes the existing Promise classification.
Missing, forged or unhealthy evidence blocks all 30 modes and prevents baseline
writes. These checks rely on the trusted adapter and preserve older profile
policies; they add no runtime authority, transport capability or resource limit.

## Representative limits
''')

validation = '''## Complete pinned Promise.try selection

The [Try upstream profile](promise-try-upstream.md) retains all 15 pinned sources
and 30 modes. It records **24 passed and six unsupported modes**, with all
**94 controls verified**. The unsupported rows are both modes of
`avoids-wrap-for-subclass.js`, `ctx-ctor-for-error.js` and `ctx-ctor.js`, excluded
for their declared `class` feature before adapter execution. All originals,
including those exclusions, remain in the authenticated corpus and report.

The complete Python suite passes **683 tests**, preserving all 652 parent
identities and adding 31 groups. All 31 pass on the first candidate. Against the
published parent, those groups record six passes and 25 nonpassing groups;
the unittest totals of 60 failures and 46 errors include subtests and are not
106 groups. No candidate, test or control correction was needed.

The first profile run records a baseline with a healthy gate; recording and
the subsequent baseline check both exit zero. Their complete **30 case and
94 control arrays** are exact, with zero regressions or improvements. The seven
older profiles preserve all **1,300 case and 546 control records**, policies,
corpus identities and binary identities, including existing failed and
unsupported outcomes. No old baseline changes are made.

A report-checking assertion initially compared the empty `fixture_files` list
with the numeric negative-source count. The corrected assertion checks their
respective types and values. Both engine runs had already completed with healthy
gates; this bookkeeping correction changes no source, test, oracle or report.

This tooling checkpoint reuses the exact published Rust 1.88 ordinary and host
adapters. Rust/Cargo/build inputs and runtime limits are unchanged; no new Rust
suite, Clippy or build is claimed. The selected inventory contains 1,820 inputs
and is supplemented by a tracked-source review, not a complete build graph.
All 11 jobs of prior CI run `38817823918` passed for published parent `15db31c7`.
The configured Try baseline CI step adds no current remote-success claim.
Evidence is linked from the chapter. All prior validation text below remains
byte-exact, including the earlier runtime checkpoint's scope.

'''
title = '# Validation record\n\n'
assert texts['docs/VALIDATION.md'].startswith(title)
texts['docs/VALIDATION.md'] = title + validation + texts['docs/VALIDATION.md'][len(title):]

texts['docs/promise-try-upstream.md'] = '''# Complete pinned Promise.try selection

The `promise-try` profile retains the complete 15-source Test262 directory at
revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd` and all 30 strict/sloppy modes.
It records **24 passed and six unsupported modes**, with all **94 controls
verified**. This is a bounded upstream selection, separate from the earlier
[Promise.try runtime checkpoint](promise-try.md).

The six unsupported rows are both modes of `avoids-wrap-for-subclass.js`,
`ctx-ctor-for-error.js` and `ctx-ctor.js`. Their declared `class` feature is
excluded before adapter execution. The original bodies remain unchanged in the
corpus and all six rows remain in the report. There are no negative-metadata
sources or substituted fixtures. Of the 30 modes, 22 have synchronous policy
and eight require authenticated async completion; all eight async modes pass.

The [corpus manifest](../tests/upstream/test262-promise-try/manifest.json) binds
the complete 33-file package: 15 source bodies, eight harness files, two legal
files, seven retained proof documents and the manifest. Complete root-linked
Git trees and blob IDs authenticate the selection and helper bytes. Seven
helpers come from the original source closure; `promiseHelper.js` is added for
the existing harness guards. The unchanged `compareArray.js` is a compatibility
shim: executable global and assertion comparison routines come from `assert.js`.
Equal and unequal array controls exercise those routines; the async pair also
exercises `asyncTest` and `assert.throwsAsync` from `asyncHelpers.js`.

The profile uses the existing `test262-host` adapter with ERJS2 requests and
ERJR3 responses. Synchronous cases use checked-sync completion; async cases
require authenticated `$DONE`. The existing final-quiescent unhandled-rejection
veto remains in force. The seven intrinsic error identities remain unchanged;
this profile adds no AggregateError identity capability, protocol bytes or
runtime behavior. Its supported feature tags are `Reflect.construct` and
`promise-try`.

The canonical gate preserves all 74 common controls and adds five positive/
mismatch pairs in both modes: method metadata, callback ordering and arguments,
genuine Promise identity, ordinary rejection and async helper behavior. Each
mismatch changes one final assertion or expected value. The gate checks exact
source/helper fingerprints, complete raw observations and same-mode prerequisite
records, then recomputes the existing Promise classification. Missing, duplicate,
extra, forged or unhealthy records block all 30 source modes and prevent writing
either a new or an existing baseline. These are checks on trusted adapter
evidence, not a new browser security boundary.

The complete Python suite passes **683 tests**, retaining all 652 parent groups
and adding 31. All 31 pass on the first candidate. On the published parent,
six of those groups pass and 25 do not; unittest's 60 failure and 46 error
observations include subtests. Import and loader tests reproduce the exact
package and reject source, helper, proof and selection mutations, including
manifest rewrites with self-consistent hashes. Protocol and gate tests cover
completion evidence, prerequisite failures and baseline refusal. No candidate
source, test or expectation correction was needed.

The initial healthy run records the [new baseline](../tests/conformance/test262-promise-try-current.json).
Recording and the subsequent baseline check both exit zero. The complete 30
case and 94 control arrays match exactly, with zero regressions or improvements.
All seven older profiles also preserve their complete **1,300 case and 546
control arrays**, policies, corpus identities and reused binary identities,
including retained failed and unsupported outcomes. The 60 earlier profile
policies and their baselines remain unchanged.

A root report checker initially compared the empty `fixture_files` list with a
numeric count and stopped before producing its receipt. Correcting that
comparison changed no candidate source, test, oracle or report; both actual
profile runs were already complete with healthy gates. The original checker
and correction remain in the evidence.

This checkpoint reuses the exact Rust 1.88 ordinary and host release adapters
from the published runtime. Rust/Cargo/build inputs and runtime limits are
unchanged; no new Rust suite, Clippy or build is claimed. The 1,820-input selected
inventory has a separate tracked-source review and is not a complete build
graph. All 11 jobs of prior CI run `38817823918` passed for published parent
`15db31c7`; the configured baseline step is not a new remote-success result.
Classes, async functions and multiple realms remain unfinished, and these
measurements establish no full-conformance, production-security or performance
claim. The runtime chapter and earlier validation body remain byte-exact.

With a host-enabled adapter already built, run the recorded gate from the
repository root:

```sh
python3 tools/test262_conformance.py --binary target/release/eris-js --profile promise-try --baseline tests/conformance/test262-promise-try-current.json --output artifacts/test262-promise-try-gate.json
```

The [evidence manifest](evidence/promise-try-upstream/manifest.json) and
[source/check archive](evidence/promise-try-upstream/sources-and-checks.tar.gz)
retain the frozen contracts, authenticated corpus, parent observations and
complete validation records.
'''

rows = []
for rel, text in texts.items():
    path = D / 'raw' / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    before = D / 'before' / rel
    prior = before.read_text() if before.exists() else ''
    diff = D / 'diff' / (rel + '.diff')
    diff.parent.mkdir(parents=True, exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(prior.splitlines(True), text.splitlines(True),
                                              fromfile=rel if before.exists() else '/dev/null', tofile=rel)))
    rows.append({'relative_path': rel, 'before': bind(before) if before.exists() else None,
                 'raw': bind(path), 'diff': bind(diff)})

assert len(rows) == 6
old_validation = (D / 'before/docs/VALIDATION.md').read_bytes()
assert (D / 'raw/docs/VALIDATION.md').read_bytes().endswith(old_validation[len(title):])
assert texts['docs/ROADMAP.md'].split('## Vulkan rendering backend', 1)[1] == (D / 'before/docs/ROADMAP.md').read_text().split('## Vulkan rendering backend', 1)[1]
draft = {'status': 'content draft; final ledger binding and seal pending', 'files': rows,
         'published_parent': bind(D / 'parent-snapshot.json'),
         'actual_evidence': [bind(E / 'root' / name) for name in [
             'try-validation.json', 'python-validation.json', 'profile-validation.json',
             'source-validation.json', 'binary-reuse-1.json', 'try-check-orchestration.json',
             'final-validation.json', 'prior-ci-observation-1.json']],
         'historical_validation_body_exact': True, 'vulkan_roadmap_exact': True,
         'runtime_chapter_not_selected': bind(D / 'before/docs/promise-try.md')}
(D / 'draft.json').write_text(json.dumps(draft, indent=2) + '\n')
print(json.dumps(bind(D / 'draft.json')))
