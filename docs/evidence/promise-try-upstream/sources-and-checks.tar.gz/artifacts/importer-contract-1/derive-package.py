"""Inert independent package derivation from authenticated retained bytes."""
from pathlib import Path
import ast,collections,hashlib,json,re,subprocess
E=Path('/tmp/eris-promise-try-upstream-plan-1');R=E/'readiness-1';O=E/'importer-contract-1';P=O/'corpus/tests/upstream/test262-promise-try'
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c';REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd';ROOT='91b2052adad1f066ae031e2ff3a1e9bd6d732886';LEAF='8e31e175a3e53480752c825f7f89f364220d643a'
HELPERS=['assert.js','sta.js','doneprintHandle.js','asyncHelpers.js','compareArray.js','isConstructor.js','propertyHelper.js','promiseHelper.js']
SCOPE='all 15 original .js files in the complete Promise/try subtree; root-linked nonrecursive Git proofs and unchanged eight-helper closure including guard-only promiseHelper.js; all original feature metadata retained; no execution or conformance claim'
def sha(b):return hashlib.sha256(b).hexdigest()
def gh(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def binding(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def put(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def write(p,d):put(p,(json.dumps(d,indent=2)+'\n').encode())
# All six complete trees are independently reconstructed, including unrelated entries.
trees={};proof={};tree_auth=[]
for p in sorted((R/'proof').glob('tree-*.json')):
 b=p.read_bytes();d=json.loads(b);assert d['truncated'] is False
 assert d['sha']==p.stem.removeprefix('tree-');names=set();encoded=[]
 for x in d['tree']:
  name=x['path'];assert name and name not in names and '/' not in name and '\\' not in name and '\0' not in name;names.add(name)
  assert {'040000':'tree','100644':'blob','100755':'blob','120000':'blob','160000':'commit'}[x['mode']]==x['type']
  encoded.append(((name+('/' if x['type']=='tree' else '')).encode(),x['mode'].lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(x['sha'])))
 raw=b''.join(b for _,b in sorted(encoded));assert gh('tree',raw)==d['sha']
 trees[d['sha']]={x['path']:x for x in d['tree']};proof['inventory-proof/'+p.name]=b
 tree_auth.append(dict(sha=d['sha'],entries=len(names),bytes=len(b),sha256=sha(b)))
assert len(trees)==6
commit=(R/'proof/commit.json').read_bytes();c=json.loads(commit);assert c['sha']==REV and c['tree']['sha']==ROOT
proof['inventory-proof/commit.json']=commit
node=ROOT;chain=[]
for part in ['test','built-ins','Promise','try']:
 x=trees[node][part];assert x['type']=='tree';chain.append(dict(parent=node,name=part,sha=x['sha']));node=x['sha']
assert node==LEAF and len(trees[LEAF])==15
assert all(x['type']=='blob' and x['mode'] in ['100644','100755'] and name.endswith('.js') for name,x in trees[LEAF].items())
harness=trees[trees[ROOT]['harness']['sha']];sources={};metadata={};orders={};identities=[];features=collections.Counter();includes=collections.Counter();flags=collections.Counter()
for name,x in sorted(trees[LEAF].items()):
 p=R/'sources'/name;b=p.read_bytes();assert len(b)==x['size'] and gh('blob',b)==x['sha']
 path='test/built-ins/Promise/try/'+name;sources[path]=b
 front=re.search(r'/\*---(.*?)---\*/',b.decode(),re.S).group(1);m={}
 for key in ['flags','includes','features','locale']:
  found=re.search(r'^'+key+r':\s*\[([^\]]*)\]\s*$',front,re.M)
  m[key]=[v.strip() for v in found[1].split(',') if v.strip()] if found else []
 assert not re.search(r'^(negative|timeout|locale):',front,re.M);m['negative']=None
 assert set(m['flags'])<= {'async'};metadata[path]=m;features.update(m['features']);includes.update(m['includes']);flags.update(m['flags'])
 names=['assert.js','sta.js']+(['doneprintHandle.js'] if 'async' in m['flags'] else [])+m['includes'];assert len(names)==len(set(names));orders[path]=names
for name in sorted(HELPERS):
 b=(R/'helpers'/name).read_bytes();assert len(b)==harness[name]['size'] and gh('blob',b)==harness[name]['sha'];sources['harness/'+name]=b
for name in ['LICENSE','INTERPRETING.md']:
 b=(R/'legal'/name).read_bytes();assert len(b)==trees[ROOT][name]['size'] and gh('blob',b)==trees[ROOT][name]['sha'];sources[name]=b
closure={'assert.js','sta.js'}|set(includes)|({'doneprintHandle.js'} if flags['async'] else set());assert closure==set(HELPERS)-{'promiseHelper.js'}
assert flags=={'async':4} and features=={'promise-try':15,'class':3,'Reflect.construct':1}
for path,m in metadata.items():
 policy=int('async' in m['flags']);hs=[dict(name=n,sha256=sha(sources['harness/'+n])) for n in orders[path]]
 for mode in ['sloppy','strict']:
  case=dict(source_sha256=sha(sources[path]),mode=mode,metadata=m,harness=hs,completion_policy=policy)
  identities.append(dict(id=path+':'+mode,case_sha256=sha(json.dumps(case,sort_keys=True,ensure_ascii=True).encode())))
# Cross-check independent derivation against frozen readiness without consuming its expectations.
census=json.loads((R/'source-census.json').read_text());assert identities==[dict(id=x['id'],case_sha256=x['case_sha256']) for x in census['case_identities']]
aux={k:harness[k.removeprefix('harness/')]['sha'] for k in sorted(sources) if k.startswith('harness/')}
for name in ['LICENSE','INTERPRETING.md']:aux[name]=trees[ROOT][name]['sha']
description=dict(method='complete-nonrecursive-git-trees',revision=REV,root_tree=ROOT,directory_trees={'Promise/try':LEAF},auxiliary_blobs=aux)
manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=REV,scope=SCOPE,directories={'Promise/try':sorted(trees[LEAF])},test_files=15,files=[])
manifest['inventory_proof']=dict(description,files=[])
for path,b in sorted(proof.items()):
 route='commits/'+REV if path.endswith('/commit.json') else 'trees/'+Path(path).stem.removeprefix('tree-')
 manifest['inventory_proof']['files'].append(dict(path=path,bytes=len(b),sha256=sha(b),url='https://api.github.com/repos/tc39/test262/git/'+route));put(P/path,b)
for path,b in sorted(sources.items()):
 manifest['files'].append(dict(path=path,upstream_path=path,bytes=len(b),sha256=sha(b)));put(P/path,b)
write(P/'manifest.json',manifest)
all_files=[dict(path=p.relative_to(P).as_posix(),bytes=p.stat().st_size,sha256=sha(p.read_bytes())) for p in sorted(P.rglob('*')) if p.is_file()]
assert len(all_files)==33 and len(manifest['files'])==25 and len(manifest['inventory_proof']['files'])==7 and sum(len(sources[p]) for p in metadata)==7328
# Published tables read as inert AST expressions only; no importer execution.
parent=subprocess.check_output(['git','show',BASE+':tools/import_test262.py'],cwd=E/'worktree');assert parent==(R/'parent/tools/import_test262.py').read_bytes();put(O/'parent/tools/import_test262.py',parent)
astmod=ast.parse(parent);assign={t.id:n.value for n in astmod.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
def value(n):
 if isinstance(n,ast.Name):return value(assign[n.id])
 if isinstance(n,ast.Dict):return {value(k):value(v) for k,v in zip(n.keys,n.values)}
 if isinstance(n,ast.Set):return {value(e) for e in n.elts}
 if isinstance(n,ast.List):return [value(e) for e in n.elts]
 if isinstance(n,ast.Tuple):return tuple(value(e) for e in n.elts)
 return ast.literal_eval(n)
tables={n:value(assign[n]) for n in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES']};tables['TREE_PROFILES']=sorted(tables['TREE_PROFILES']);assert len(tables['PROFILES'])==60
oracle=dict(format=1,profile='promise-try',base=BASE,expected_manifest=manifest,manifest_sha256=sha((P/'manifest.json').read_bytes()),all_files=all_files,metadata=metadata,helper_order=orders,case_identities=identities,source_bytes=7328,features=dict(features),includes=dict(includes),async_sources=4,sync_sources=11,raw_helpers=sorted(closure),selected_helpers=sorted(HELPERS),guard_only_helpers=['promiseHelper.js'],old_profile_count=60,old_tables_sha256={n:sha(json.dumps(v,sort_keys=True).encode()) for n,v in tables.items()})
write(O/'raw/tools/test262-promise-try-import-oracle.json',oracle)
write(O/'authentication.json',dict(status='authenticated from retained bytes; no project execution',base=BASE,revision=REV,root_tree=ROOT,ancestry=chain,tree_authentication=tree_auth,source_blobs=15,auxiliary_blobs=10,source_bytes=7328,files=33,bytes=sum(r['bytes'] for r in all_files),mode_cases=30,async_modes=8,sync_modes=22,scope=SCOPE,helper_closure='Raw source/default seven, plus only the selected common-control promiseHelper.js guard; authenticate all eight against the root-linked harness tree.',commit_qualification='Commit JSON SHA and root bind the published pin/root constants; complete tree object IDs and every selected blob are reconstructed independently.',oracle=binding(O/'raw/tools/test262-promise-try-import-oracle.json')))
write(O/'package-ready.json',dict(status='package_and_oracle_frozen_before_producer',base=BASE,selection=binding(E/'root/selection-1.json'),readiness=binding(R/'source-ready.json'),base_refresh=binding(E/'root/readiness-base-refresh.json'),derivation=binding(O/'derive-package.py'),authentication=binding(O/'authentication.json'),oracle=binding(O/'raw/tools/test262-promise-try-import-oracle.json'),manifest=binding(P/'manifest.json'),all_files=all_files,interfaces={'profile':'promise-try','directories':{'Promise/try':15},'helpers':sorted(HELPERS),'importer':'import_corpus(output, profile), profile_tree_inventory(profile, read=None)','loader':'load_corpus(directory, profile)','closure':'Require raw metadata/default seven exactly before adding only promiseHelper.js; final selected closure exactly eight.'},execution='Stdlib/hash/AST plus read-only Git only. No project imports, network, tests, build, producer source inspection or live edits.'))
print(json.dumps(binding(O/'package-ready.json'),indent=2));print('manifest',sha((P/'manifest.json').read_bytes()),'oracle',sha((O/'raw/tools/test262-promise-try-import-oracle.json').read_bytes()),'bytes',sum(r['bytes'] for r in all_files))
