"""Author source-only tests from published patterns and frozen independent oracle."""
from pathlib import Path
import ast,hashlib,json,subprocess
E=Path('/tmp/eris-promise-try-upstream-plan-1');O=E/'importer-contract-1';W=E/'worktree';BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
oracle=json.loads((O/'raw/tools/test262-promise-try-import-oracle.json').read_text());H=hashlib.sha256((O/'raw/tools/test262-promise-try-import-oracle.json').read_bytes()).hexdigest()
def old(name):return subprocess.check_output(['git','show',BASE+':tools/'+name],cwd=W).decode()
def rename(s):
 for a,b in [('Promise.withResolvers','Promise.try'),('PromiseWithResolvers','PromiseTry'),('PROMISE_WITH_RESOLVERS','PROMISE_TRY'),('WITH_RESOLVERS_TREE','TRY_TREE'),('promise-with-resolvers','promise-try'),('Promise/withResolvers','Promise/try'),('withResolvers','Try'),('5b88482eae075e32cf5f0dd4221eb68c14555a7937cc1d964928055ce34b3d56',H),('062393e615d0cf97a0252e6a93923bd91444a455','8e31e175a3e53480752c825f7f89f364220d643a')]:s=s.replace(a,b)
 return s
s=rename(old('test_import_test262_promise_with_resolvers.py'))
s=s.replace("DIRECTORIES = {'Promise/try': 6}","DIRECTORIES = {'Promise/try': 15}")
s=s.replace("HELPERS = {'assert.js', 'sta.js', 'propertyHelper.js'}","HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js', 'asyncHelpers.js',\n           'compareArray.js', 'isConstructor.js', 'propertyHelper.js', 'promiseHelper.js'}")
s=s.replace('test_complete_19_file_replay','test_complete_33_file_replay').replace('(6, 11, 7)', '(15, 25, 7)').replace('(19, 101418)', '(33, 118162)').replace('len(expected_urls), 18','len(expected_urls), 32')
a=s.index('    def test_all_12_metadata_identities');b=s.index('    def test_all_proofs',a)
s=s[:a]+'''    def test_all_30_metadata_identities_preserve_completion_and_exact_helper_order(self):
        helpers, identities = {'assert.js', 'sta.js'}, []
        source_bytes, features, includes, policies = 0, Counter(), Counter(), Counter()
        for path, expected in self.oracle['metadata'].items():
            data = (CORPUS / path).read_bytes()
            metadata = importer.parse_metadata(data.decode('utf-8'))
            self.assertEqual(metadata, expected, path)
            self.assertLessEqual(set(metadata['flags']), {'async'})
            self.assertEqual(metadata['locale'], [])
            self.assertIsNone(metadata['negative'])
            self.assertNotIn('timeout', metadata)
            source_bytes += len(data)
            helpers.update(metadata['includes'])
            policy = int('async' in metadata['flags'])
            if policy:
                helpers.add('doneprintHandle.js')
            names = ['assert.js', 'sta.js'] + (['doneprintHandle.js'] if policy else []) + metadata['includes']
            self.assertEqual(names, self.oracle['helper_order'][path])
            harness = [dict(name=name, sha256=digest((CORPUS / 'harness' / name).read_bytes()))
                       for name in names]
            for mode in ('sloppy', 'strict'):
                identity = dict(source_sha256=digest(data), mode=mode, metadata=metadata,
                                harness=harness, completion_policy=policy)
                identities.append(dict(id=path + ':' + mode,
                    case_sha256=digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())))
                policies[policy] += 1
            features.update(metadata['features'])
            includes.update(metadata['includes'])
        self.assertEqual((len(self.oracle['metadata']), source_bytes), (15, 7328))
        self.assertEqual(helpers, HELPERS - {'promiseHelper.js'})
        self.assertNotIn('promiseHelper.js', includes)
        self.assertEqual(identities, self.oracle['case_identities'])
        self.assertEqual(len({r['id'] for r in identities}), 30)
        self.assertEqual(policies, {0: 22, 1: 8})
        self.assertEqual(features, {'promise-try': 15, 'class': 3, 'Reflect.construct': 1})
        self.assertEqual(dict(includes), self.oracle['includes'])
        self.assertEqual(self.oracle['guard_only_helpers'], ['promiseHelper.js'])

'''+s[b:]
s=s.replace('test_frozen_selection_refusals_and_all_59_old_profile_tables_are_preserved','test_frozen_selection_refusals_and_all_60_old_profile_tables_are_preserved')
s=s.replace("{'Promise/try': 5}","{'Promise/try': 14}").replace("{'Promise/try': 7}","{'Promise/try': 16}").replace("{'Promise/resolve': 6}","{'Promise/resolve': 15}").replace("{'Promise/try': 6, 'Promise/try/child': 1}","{'Promise/try': 15, 'Promise/try/child': 1}")
s=s.replace("self.oracle['old_profile_count'], 59","self.oracle['old_profile_count'], 60")
s=s.replace('(11, 6, 3)', '(25, 15, 8)').replace('Promise/try/result.js','Promise/try/args.js').replace("HELPERS | {'compareArray.js'}","HELPERS | {'testTypedArray.js'}")
# Missing/corrupt every selected source/helper/legal file is distinct from a source-requested closure omission.
a=s.index("\n\nif __name__ == '__main__':")
s=s[:a]+'''    def test_observed_source_closure_cannot_be_filled_from_the_guard_pool(self):
        self.assertEqual(importer.PROMISE_TRY_HELPERS, HELPERS)
        parse = importer.parse_metadata
        # This fault lies after authenticated bytes, isolating helper derivation.
        # Dropping all async flags must not silently recover doneprintHandle.
        for kind in ('include', 'completion'):
            def changed(source):
                metadata = copy.deepcopy(parse(source))
                if kind == 'include':
                    metadata['includes'] = [n for n in metadata['includes'] if n != 'asyncHelpers.js']
                else:
                    metadata['flags'] = [n for n in metadata['flags'] if n != 'async']
                return metadata
            with self.subTest(kind=kind), tempfile.TemporaryDirectory() as temporary, patch.object(
                    importer, 'fetch', side_effect=self.cached_fetch), patch.object(
                    importer, 'parse_metadata', side_effect=changed):
                output = Path(temporary) / 'corpus'
                with self.assertRaisesRegex(ValueError, 'harness|helper'):
                    importer.import_corpus(output, PROFILE)
                self.assertFalse(output.exists())

'''+s[a:]
# Existing standard helper/metadata APIs only; no new seam invented.
ast.parse(s);(O/'raw/tools/test_import_test262_promise_try.py').write_text(s)

s=rename(old('test_test262_promise_with_resolvers_loader.py'))
s=s.replace('test_actual_loader_admits_exact_12_ordinary_identities_and_helper_bytes','test_actual_loader_admits_all_30_host_identities_and_exact_helper_bytes')
s=s.replace('len(files), 11','len(files), 25').replace('len(cases), 12','len(cases), 30').replace('len(auxiliary), 5','len(auxiliary), 10')
s=s.replace("self.assertNotIn('completion_policy', case)","self.assertIs(type(case['completion_policy']), int)\n            self.assertEqual(case['completion_policy'], int('async' in meta['flags']))")
s=s.replace("['assert.js', 'sta.js'] + meta['includes']","self.oracle['helper_order'][case['file']]")
s=s.replace('Promise/try/result.js','Promise/try/args.js').replace("remove('result.js')","remove('args.js')").replace("{'Promise/try': 5}","{'Promise/try': 14}")
# Add helper closure and retained unsupported denominator assertions to successful loader control.
needle="        self.assertEqual({c['file'] for c in cases}, set(self.oracle['metadata']))\n"
s=s.replace(needle,needle+'''        self.assertEqual(sum(c['completion_policy'] == 1 for c in cases), 8)
        self.assertEqual(sum('class' in c['metadata']['features'] for c in cases), 6)
        self.assertTrue(all('promiseHelper.js' not in [n for n, _ in c['harness']] for c in cases))
        self.assertIn('harness/promiseHelper.js', files)
        self.assertEqual(runner.PROFILE_FEATURES[PROFILE], {'Reflect.construct', 'promise-try'})
''')
# Stage helper mutation test already authenticates all ten auxiliaries; extra proof and
# narrowed manifest plus patched tables reach the frozen selection postcondition.
ast.parse(s);(O/'raw/tools/test_test262_promise_try_loader.py').write_text(s)
print('authored importer7 and loader3 source groups')
