"""Read-only preservation/migration/CI audit; no project import or execution."""
from pathlib import Path
from collections import Counter
import ast, difflib, hashlib, json, re, subprocess
E=Path('/tmp/eris-promise-try-upstream-plan-1'); H=E/'preservation-review-1'
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'; bindings={}
def read(p):
 p=Path(p);b=p.read_bytes();bindings[str(p)]=dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest());return b
def load(p):return json.loads(read(p))
def verify(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():
   b=read(v['path']);assert len(b)==v['bytes'] and hashlib.sha256(b).hexdigest()==v['sha256']
  for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
def git(p):return subprocess.check_output(['git','-C',str(E/'worktree'),'show',BASE+':'+p])
def constants(source):
 return Counter((type(n.value).__name__,repr(n.value)) for n in ast.walk(ast.parse(source)) if isinstance(n,ast.Constant))

holds={n:load(E/n/'source-ready.json') for n in ['preservation-contract-1','migrations-1','ci-1']}
for h in holds.values():verify(h);assert h['base']==BASE
assert bindings[str(E/'preservation-contract-1/source-ready.json')]['sha256']=='932f10ad086e8ee50f0168c98e74c52e0499140c8ae06c190710d7ffd4aa01a0'
assert bindings[str(E/'migrations-1/source-ready.json')]['sha256']=='1586103a056f4a926f932e27b0ae91b11f218c8b2898dfb082e9984c2acd93ad'
assert bindings[str(E/'ci-1/source-ready.json')]['sha256']=='929f2ea22dcee7f94817003481637f9b62f6258288a05176c74c17b86107df9f'

# Evaluate only literal/container construction in top-level AST, never functions,
# imports, attribute lookups, source code via eval, or any project callable.
def tables(source):
 env={}
 def val(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,(ast.Set,ast.List,ast.Tuple)):
   values=[val(x) for x in n.elts];return set(values) if isinstance(n,ast.Set) else values
  if isinstance(n,ast.Dict):return {val(k):val(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.BitOr):return val(n.left)|val(n.right)
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Sub):return val(n.left)-val(n.right)
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Name) and n.func.id=='set' and len(n.args)<=1 and not n.keywords:return set(val(n.args[0])) if n.args else set()
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='copy' and not n.args and not n.keywords:
   v=val(n.func.value)
   if isinstance(v,(set,dict,list)):return v.copy()
  raise ValueError(type(n).__name__)
 for n in ast.parse(source).body:
  if isinstance(n,ast.Assign):
   try:v=val(n.value)
   except (ValueError,KeyError,TypeError):continue
   for target in n.targets:
    if isinstance(target,ast.Name):env[target.id]=v
    elif isinstance(target,ast.Subscript) and isinstance(target.value,ast.Name):env[target.value.id][val(target.slice)]=v
  elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
   c=n.value
   if isinstance(c.func,ast.Attribute) and c.func.attr=='add' and isinstance(c.func.value,ast.Name) and c.func.value.id=='PROMISE_HOST_PROFILES':env[c.func.value.id].add(val(c.args[0]))
 return env

old_sources={r:git(r).decode() for r in ['tools/import_test262.py','tools/test262_conformance.py']}
it=tables(old_sources['tools/import_test262.py']);rt=tables(old_sources['tools/test262_conformance.py'])
oracle=load(E/'preservation-contract-1/raw/tools/promise-try-preservation-oracle.json')
assert oracle['profiles']==it['PROFILES'] and len(it['PROFILES'])==60
assert oracle['roots']==it['PROFILE_ROOTS'] and oracle['tree_profiles']==sorted(it['TREE_PROFILES'])
assert oracle['features']=={k:sorted(v) for k,v in rt['PROFILE_FEATURES'].items()}
assert oracle['promise_host_profiles']==sorted(rt['PROMISE_HOST_PROFILES'])
assert oracle['intrinsic_errors']==sorted(rt['INTRINSIC_ERRORS']) and len(rt['INTRINSIC_ERRORS'])==7
for profile,record in oracle['policies_at_timeout3'].items():
 identities=rt['INTRINSIC_ERRORS']|({'AggregateError'} if profile in {'aggregate-error','promise-any'} else set())
 policy=dict(format=2,supported_features=sorted(rt['PROFILE_FEATURES'][profile]),negative_intrinsic_errors=sorted(identities),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if profile in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:policy['excluded_harness']=['resizableArrayBufferUtils.js']
 if profile in rt['PROMISE_HOST_PROFILES']:
  policy.update(format=3,async_completion=True,host_hooks=True,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
 assert record==dict(policy=policy,sha256=hashlib.sha256(json.dumps(policy,sort_keys=True).encode()).hexdigest()),profile
frozen={}
for rel,source in old_sources.items():
 excluded={'profile_tree_inventory','import_corpus'} if rel.endswith('/import_test262.py') else {'load_corpus','decode_response','run_case','harness_preflight','main'}
 frozen[rel]={n.name:hashlib.sha256(ast.get_source_segment(source,n).encode()).hexdigest() for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name not in excluded}
assert frozen==oracle['unchanged_functions'] and sum(map(len,frozen.values()))==74

preservation_test=read(E/'preservation-contract-1/raw/tools/test_test262_promise_try_preservation.py').decode()
pt=ast.parse(preservation_test)
test_names=[n.name for n in ast.walk(pt) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(test_names)==2
assert oracle['base']==BASE
for row in holds['preservation-contract-1']['files']:
 rel=row['relative_path'];raw=read(row['raw']['path']);patch=read(row['diff']['path']).decode();headers=patch.splitlines()
 assert subprocess.check_output(['git','-C',str(E/'worktree'),'ls-tree','--name-only',BASE,'--',rel])==b''
 assert ''.join(difflib.unified_diff([],raw.decode().splitlines(True),fromfile=headers[0][4:],tofile=headers[1][4:]))==patch

parentlog=read(E/'validation/python-parent-1.log').decode()
assert hashlib.sha256(parentlog.encode()).hexdigest().startswith('a6f4cb8d')
actual=re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. ok$',parentlog,re.M)
assert len(actual)==len(set(actual))==652 and 'Ran 652 tests' in parentlog and parentlog.rstrip().endswith('OK')
migrations=holds['migrations-1'];assert len(migrations['files'])==24 and sum(len(r['edits'])for r in migrations['files'])==47
retained=[];rows=[]
for row in migrations['files']:
 rel=row['relative_path'];before=read(row['before']['path']).decode();raw=read(row['raw']['path']).decode();assert before.encode()==git(rel)
 forward=before
 for edit in row['edits']:
  assert forward.count(edit['before'])==1
  forward=forward.replace(edit['before'],edit['after'],1)
 assert forward==raw
 reverse=raw
 for edit in reversed(row['edits']):
  assert reverse.count(edit['after'])==1
  reverse=reverse.replace(edit['after'],edit['before'],1)
 assert reverse==before
 a,b=constants(before),constants(raw)
 assert not (a-b) and b-a==Counter({('str',repr('promise-try')):len(row['edits'])}),rel
 old_methods=[n.name for n in ast.walk(ast.parse(before)) if isinstance(n,ast.FunctionDef)]
 new_methods=[n.name for n in ast.walk(ast.parse(raw)) if isinstance(n,ast.FunctionDef)]
 assert old_methods==new_methods
 module=Path(rel).stem+'.';found=sorted(v for v in actual if v.startswith(module));assert found==row['retained_groups'],rel
 retained.extend(found);rows.append(dict(path=rel,edits=len(row['edits']),retained_actual_parent_groups=len(found),whole_file_inverse=True,only_added_constant='promise-try'))
assert len(retained)==len(set(retained))==295 and sorted(retained)==migrations['roster']
assert migrations['retained_groups']==295

ci=holds['ci-1']['files'][0];before=read(ci['before']['path']).decode();raw=read(ci['raw']['path']).decode();assert before.encode()==git(ci['relative_path'])
assert raw.count(ci['addition'])==1 and raw.replace(ci['addition'],'',1)==before
assert raw.index('--profile promise-any')<raw.index('--profile promise-try')
assert raw.index('cargo build --locked --release --features test262-host --bin eris-js')<raw.index('--profile promise-try')
assert '--baseline tests/conformance/test262-promise-try-current.json --output artifacts/test262-promise-try-gate.json' in ci['addition']
out=dict(status='clear',old_policies=60,old_protected_functions={k:len(v) for k,v in frozen.items()},preservation_groups=2,migration_paths=24,migration_entries=47,retained_actual_parent_groups=295,parent_full_python=652,migrations=rows,ci_exact_single_step_inverse=True,bindings=sorted(bindings.values(),key=lambda x:x['path']))
with (H/'checks.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['bindings','migrations']}))
