"""External producer authoring from frozen package/interface data; stdlib only."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

E = Path('/tmp/eris-promise-try-upstream-plan-1')
H = E / 'importer-1'
REL = 'tools/import_test262.py'

def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')

package_path = E / 'importer-contract-1/package-ready.json'
assert binding(package_path)['sha256'] == '7bcf95f131441d41398739e5be04945e4883878b72bab6cfc16c3adc76cde9f7'
package = json.loads(package_path.read_bytes())
manifest_path = Path(package['manifest']['path'])
assert binding(manifest_path) == package['manifest']
manifest = json.loads(manifest_path.read_bytes())
assert package['interfaces']['directories'] == {'Promise/try': 15}
assert len(package['all_files']) == 33

before = (H / 'before' / REL).read_text()
after = before
edits = []

def replace(label, old, new):
    global after
    assert after.count(old) == 1, label
    after = after.replace(old, new, 1)
    edits.append(dict(label=label, before=old, after=new))

replace('new profile directory and eight-helper constants',
        "PROMISE_WITH_RESOLVERS_DIRECTORIES = {'Promise/withResolvers': 6}\n",
        "PROMISE_TRY_DIRECTORIES = {'Promise/try': 15}\n"
        "PROMISE_TRY_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js', 'asyncHelpers.js',\n"
        "                       'compareArray.js', 'isConstructor.js', 'propertyHelper.js',\n"
        "                       'promiseHelper.js'}\n"
        "PROMISE_WITH_RESOLVERS_DIRECTORIES = {'Promise/withResolvers': 6}\n")
replace('tree profile membership', "TREE_PROFILES = {'promise-with-resolvers',", "TREE_PROFILES = {'promise-try', 'promise-with-resolvers',")
replace('directory selection table', "PROFILES = {'promise-with-resolvers':", "PROFILES = {'promise-try': PROMISE_TRY_DIRECTORIES, 'promise-with-resolvers':")
replace('profile root table', "PROFILE_ROOTS = {'promise-with-resolvers':", "PROFILE_ROOTS = {'promise-try': 'test/built-ins', 'promise-with-resolvers':")
replace('complete Try leaf selection before unchanged old branches',
        "def profile_tree_inventory(profile, read=None):\n",
        "def profile_tree_inventory(profile, read=None):\n"
        "    if profile == 'promise-try':\n"
        "        expected = {'Promise/try': 15}\n"
        "        if (PROMISE_TRY_DIRECTORIES != expected or PROFILES[profile] != expected\n"
        "                or PROFILE_ROOTS[profile] != 'test/built-ins'):\n"
        "            raise ValueError('Promise.try frozen directory selection mismatch')\n"
        "        listings, proof, description = git_tree_inventory(\n"
        "            expected, 'test/built-ins', read, auxiliary_helpers=PROMISE_TRY_HELPERS)\n"
        "        if any(len(listings[name]) != count for name, count in expected.items()):\n"
        "            raise ValueError('Promise.try complete directory counts differ')\n"
        "        # The authenticated leaf is complete only when it has no descendants.\n"
        "        sha = description['directory_trees']['Promise/try']\n"
        "        tree = json.loads(proof[tree_proof_path('trees/' + sha)])\n"
        "        if any(entry['type'] == 'tree' for entry in tree['tree']):\n"
        "            raise ValueError('Promise.try incomplete descendant selection')\n"
        "        return listings, proof, description\n")
replace('raw source closure then explicit guard helper',
        "    if profile == 'promise-with-resolvers' and harness != PROMISE_WITH_RESOLVERS_HELPERS:\n",
        "    if profile == 'promise-try':\n"
        "        # The originals request seven helpers; only the common host guards\n"
        "        # require promiseHelper.js. Do not fill missing source evidence.\n"
        "        if harness != PROMISE_TRY_HELPERS - {'promiseHelper.js'}:\n"
        "            raise ValueError('Promise.try requested harness differs from the frozen seven source helpers')\n"
        "        harness.add('promiseHelper.js')\n"
        "        if harness != PROMISE_TRY_HELPERS:\n"
        "            raise ValueError('Promise.try selected harness differs from the frozen eight helpers')\n"
        "    if profile == 'promise-with-resolvers' and harness != PROMISE_WITH_RESOLVERS_HELPERS:\n")
replace('root-linked auxiliary authentication membership',
        "    if profile in {'promise-with-resolvers', 'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views', 'reflect-properties', 'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:\n",
        "    if profile in {'promise-try', 'promise-with-resolvers', 'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views', 'reflect-properties', 'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:\n")
replace('independent frozen manifest scope',
        "    scope = {\n",
        "    scope = {\n        'promise-try': " + repr(manifest['scope']) + ",\n")

# Parse source text only: never import or call the project module.
old_tree, new_tree = ast.parse(before), ast.parse(after)
old_funcs = {n.name: ast.get_source_segment(before, n) for n in old_tree.body if isinstance(n, ast.FunctionDef)}
new_funcs = {n.name: ast.get_source_segment(after, n) for n in new_tree.body if isinstance(n, ast.FunctionDef)}
assert old_funcs.keys() == new_funcs.keys()
changed = [name for name in old_funcs if old_funcs[name] != new_funcs[name]]
assert changed == ['profile_tree_inventory', 'import_corpus'], changed
restored = after
for edit in reversed(edits):
    assert restored.count(edit['after']) == 1
    restored = restored.replace(edit['after'], edit['before'], 1)
assert restored == before

raw_path = H / 'raw' / REL
raw_path.parent.mkdir(parents=True, exist_ok=True)
with raw_path.open('x') as f:
    f.write(after)
diff_path = H / 'diffs/tools__import_test262.py.diff'
diff_path.parent.mkdir(parents=True, exist_ok=True)
with diff_path.open('x') as f:
    f.write(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/' + REL, tofile='b/' + REL)))
dump(H / 'edit-manifest.json', dict(edits=edits, whole_file_inverse_exact=True))
ledger = []
for name in old_funcs:
    ledger.append(dict(name=name, changed=name in changed,
                       before_sha256=hashlib.sha256(old_funcs[name].encode()).hexdigest(),
                       raw_sha256=hashlib.sha256(new_funcs[name].encode()).hexdigest()))
dump(H / 'function-ledger.json', ledger)
dump(H / 'source-ready.json', dict(
    status='sealed external importer-only production payload; source parsed, not executed',
    base=package['base'], selection=binding(E / 'root/selection-1.json'),
    snapshot=binding(H / 'snapshot-ready.json'),
    package_contract=binding(package_path), oracle=package['oracle'], expected_manifest=package['manifest'],
    files=[dict(relative_path=REL, before=binding(H / 'before' / REL), raw=binding(raw_path), diff=binding(diff_path), new=False)],
    edits=binding(H / 'edit-manifest.json'), functions=binding(H / 'function-ledger.json'), author=binding(Path(__file__)),
    checks=dict(ast_parse=True, changed_old_functions=changed, unchanged_old_functions=len(old_funcs)-2, exact_full_inverse=True,
                sources=15, selected_helpers=8, package_files=33, execution=False),
    qualification='No project module imported/called; no network, live edit, corpus publication, test/build execution or outcome prediction. Root owns importer replay against the independently frozen package.'))
print(json.dumps(binding(H / 'source-ready.json')))
