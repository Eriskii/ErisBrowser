assert.sameValue(typeof Promise.try, 'function');
var P = Promise, method = P.try, trace = '', probes = 0;
var pending = new P(function () {}), receiver = {};
function poison() { probes++; throw new Test262Error('unexpected lookup'); }
Object.defineProperty(pending, 'constructor', {get: function () { trace += 'G'; return receiver; }, configurable: true});
Object.defineProperty(receiver, 'resolve', {get: poison, configurable: true});
Object.defineProperty(receiver, Symbol.species, {get: poison, configurable: true});
Object.defineProperty(P, 'resolve', {get: poison, configurable: true});
Object.defineProperty(P, Symbol.species, {get: poison, configurable: true});
Promise = function () { probes++; throw new Test262Error('replacement Promise'); };
var result = method.call(receiver, function () { trace += 'F'; return pending; });
assert.sameValue(trace, 'FG');
assert.sameValue(probes, 0);
assert.sameValue(result, pending);
