assert.sameValue(typeof Promise.try, 'function');
var trace = [], first = {}, second = {}, holder = {}, seen;
function C(executor) {
  trace.push('C');
  executor(function (value) {
    'use strict';
    trace.push('R');
    assert.sameValue(this, undefined);
    assert.sameValue(value, first);
  }, function () { throw new Test262Error('unexpected reject'); });
  return holder;
}
var result = Promise.try.call(C, function (a, b, c) {
  'use strict';
  trace.push('F');
  assert.sameValue(this, undefined);
  assert.sameValue(arguments.length, 3);
  seen = [a, b, c];
  assert.compareArray(seen, [first, second, -0]);
  return a;
}, first, second, -0);
assert.sameValue(result, holder);
assert.sameValue(compareArray([first, second], [first, second]), true);
assert.sameValue(compareArray([first, second], [second, first]), false);
assert(compareArray(trace, ['C', 'F', 'R']), 'Promise.try callback order');
