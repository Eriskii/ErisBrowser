assert.sameValue(typeof Promise.try, 'function');
var trace = [], reason = {}, escaped = {}, holder = {}, rejects = 0, resolves = 0;
function C(executor) {
  trace.push('C');
  executor(function () { resolves++; }, function (value) {
    'use strict';
    trace.push('J'); rejects++;
    assert.sameValue(this, undefined);
    assert.sameValue(value, reason);
  });
  return holder;
}
var result = Promise.try.call(C, function () { trace.push('F'); throw reason; });
assert.sameValue(result, holder);
function Throwing(executor) {
  trace.push('C');
  executor(function () { resolves++; }, function (value) {
    'use strict';
    trace.push('J'); rejects++;
    assert.sameValue(this, undefined);
    assert.sameValue(value, reason);
    throw escaped;
  });
  return holder;
}
var caught = false;
try { Promise.try.call(Throwing, function () { trace.push('F'); throw reason; }); }
catch (error) { caught = true; assert.sameValue(error, escaped); }
assert.sameValue(caught, true);
assert.sameValue(rejects, 2);
assert.sameValue(resolves, 0);
assert(trace.join('') === 'FCJFCJJ', 'Promise.try rejection order');
