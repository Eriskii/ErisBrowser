assert.sameValue(typeof Promise.try, 'function');
assert.sameValue(typeof asyncTest, 'function');
assert.sameValue(typeof assert.throwsAsync, 'function');
var token = {};
asyncTest(function () {
  return Promise.try(function () { return token; }).then(function (value) {
    assert.sameValue(value, token);
    return assert.throwsAsync(RangeError, function () {
      return Promise.try(function () { throw new TypeError('try-control'); });
    });
  });
});
