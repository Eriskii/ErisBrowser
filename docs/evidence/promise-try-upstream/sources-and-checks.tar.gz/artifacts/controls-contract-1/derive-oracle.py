from pathlib import Path
import hashlib
import json
import subprocess

E=Path('/tmp/eris-promise-try-upstream-plan-1');H=E/'controls-contract-1';W=E/'worktree'
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def put(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p
    p.write_text(json.dumps(x,indent=2)+'\n')
def fingerprint(row):
    identity={k:row[k] for k in ['source_sha256','mode','metadata','harness','completion_policy']}
    return digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
common=json.loads((H/'common-variants.json').read_bytes())
variants=json.loads((H/'variants.json').read_bytes())
observations=json.loads((H/'expected-observations.json').read_bytes())['new_variants']
old_path=Path('/tmp/eris-promise-any-upstream-plan-1/controls-1/raw/tools/promise-any-controls-oracle.json')
old=json.loads(old_path.read_bytes())
assert old['common_variants']==common
helpers={p.name:{'bytes':len(p.read_bytes()),'sha256':digest(p.read_bytes())} for p in sorted((H/'helpers').glob('*.js'))}
for k,v in old['helpers'].items():assert helpers[k]==v
records=[]
common_names=['promise-methods-'+x['name'] for x in common]
for rows,prefix in [(common,'promise-methods-'),(variants,'promise-try-')]:
    for mode in ['sloppy','strict']:
        for held in rows:
            policy=held['completion_policy'];name=prefix+held['name']
            names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+held['includes']
            required=[]
            if prefix=='promise-methods-':
                if held['prerequisite']:required.append(prefix+held['prerequisite'])
                if held['origin']=='original-literal':
                    required.extend(prefix+x['name'] for x in common if x['origin']=='new-prerequisite')
                    if held['name']!='one-async-completion':required.append(prefix+'one-async-completion')
            else:
                required=common_names.copy()
                if held['name']!='api':required.append('promise-try-api')
                if held['prerequisite'] and prefix+held['prerequisite'] not in required:
                    required.append(prefix+held['prerequisite'])
            row={'name':name,'mode':mode,'id':'harness-preflight:'+name,'file':'<preflight>',
                 'metadata':{'flags':['async'] if policy else [],'includes':held['includes'],'features':[],'locale':[],'negative':None},
                 'source':held['source'],'source_sha256':digest(held['source'].encode()),
                 'harness':[{'name':n,'sha256':helpers[n]['sha256']} for n in names],
                 'completion_policy':policy,'expected':held['expected'],
                 'prerequisites':[[x,mode] for x in required]}
            row['case_sha256']=fingerprint(row)
            if prefix=='promise-methods-':
                original=next(x for x in old['records'] if x['name']==name and x['mode']==mode)
                row['mock_observation']=original['mock_observation']
                assert row==original,(name,mode)
            else:row['mock_observation']=observations[held['name']]['observation']
            records.append(row)
assert records[:74]==old['records'][:74]
assert len(records)==94 and len({(r['name'],r['mode']) for r in records})==94
index={(x['name'],x['mode']):x for x in records}
for row in records:
    assert len(row['prerequisites'])==len({tuple(x) for x in row['prerequisites']})
    for key in row['prerequisites']:assert tuple(key) in index and key[1]==row['mode']
visiting=set();visited=set()
def visit(key):
    assert key not in visiting,key
    if key in visited:return
    visiting.add(key)
    for dep in index[key]['prerequisites']:visit(tuple(dep))
    visiting.remove(key);visited.add(key)
for key in index:visit(key)
originals=[]
census=json.loads((E/'readiness-1/source-census.json').read_bytes())
for file in census['files']:
    source=(E/'readiness-1/sources'/file['name']).read_text()
    assert digest(source.encode())==file['file']['sha256']
    for mode in file['modes']:
        name='test/built-ins/Promise/try/'+file['name']
        row={'id':name+':'+mode,'file':name,'mode':mode,'metadata':file['metadata'],
             'source':source,'source_sha256':digest(source.encode()),
             'harness':[{'name':n,'sha256':helpers[n]['sha256']} for n in file['helper_order']],
             'completion_policy':file['completion_policy']}
        row['case_sha256']=fingerprint(row)
        held=next(x for x in census['case_identities'] if x['id']==row['id'])
        assert row['case_sha256']==held['case_sha256']
        originals.append(row)
assert len(originals)==30
assert sum('class' in x['metadata']['features'] for x in originals)==6
parent=json.loads((E/'source-parent.json').read_bytes())
published=[]
for rel in ['tools/test262_conformance.py','tools/import_test262.py','src/bin/eris-js.rs',
            'src/bin/eris-js/test262_host.rs','src/script/test262_host.rs']:
    data=subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
    assert data==(W/rel).read_bytes()
    assert digest(data)==parent['source_sha256'][rel]
    oldfile=H/'parent'/rel
    if oldfile.exists():assert oldfile.read_bytes()==data
    published.append({'relative_path':rel,'bytes':len(data),'sha256':digest(data),'published_git_exact':True})
refresh={'status':'published-base refresh; frozen literal bytes and expectations unchanged',
         'base':BASE,'selection':bind(E/'root/selection-1.json'),'parent':bind(E/'source-parent.json'),
         'root_refresh':bind(E/'root/readiness-base-refresh.json'),'literal_ready':bind(H/'literals-ready.json'),
         'published_sources':published,
         'qualification':'Initial literal seal names7149 tooling and pending runtime publication; this additive join resolves that pending base to15db without rewriting it. No outcome input.'}
put(H/'published-base-refresh.json',refresh)
oracle={'schema':1,'status':'frozen source-derived oracle; mock observations are not execution results',
        'base':BASE,'profile':'promise-try','variants':variants,'common_variants':common,'helpers':helpers,
        'records':records,'original_cases_for_blocking':originals,
        'counts':{'common':74,'new':20,'total':94,'original_modes':30},
        'bindings':{'literals':bind(H/'literals-ready.json'),'refresh':bind(H/'published-base-refresh.json'),
                    'legacy_frozen_common_oracle':bind(old_path),'metadata_census':bind(E/'readiness-1/source-census.json')},
        'derivation':'Stdlib literal/JSON/hash and read-only Git only. All94 source/harness/metadata/policy fingerprints reconstructed. Common74 records exactly equal an earlier independent frozen oracle and published common37 definitions.'}
oracle_path=H/'raw/tools/promise-try-controls-oracle.json';put(oracle_path,oracle)
gate={'status':'selected independent interface and gate contract before runner implementation',
      'profile':'promise-try','features':['Reflect.construct','promise-try'],
      'apis':['promise_try_preflight_variants()','promise_try_preflight_cases(files)',
              'promise_try_preflight_reference(row, case)','promise_try_preflight_checks(outcomes, files)',
              'promise_try_preflight_healthy(outcomes, files)','promise_try_harness_preflight(files, binary, timeout)'],
      'variants':'Exactly variants.json objects in their held order; common37 unchanged. No required_observation field added to these seven-field variant objects.',
      'cases':'List of(row,case) pairs in oracle order: common sloppy37 then strict37; new sloppy10 then strict10. Row retains variant fields, prefixes name and carries ordered same-mode prerequisites as(name,mode) pairs. Case is id,file,mode,metadata,source(bytes),harness[(name,bytes)],completion_policy,case_sha256.',
      'reference_fields':['name','mode','verified','case_sha256','source_sha256'],
      'reference':'Exact five-field canonical reference with verified=True; hashes from the independent case/source identity. Ordered references may not be substituted, repeated, omitted or widened.',
      'outcome_fields':['name','expected','verified','result','prerequisites'],
      'result_fields':['id','file','mode','case_sha256','source_sha256','expected_negative','status','observation'],
      'observation_fields':['status','phase','error_type','error_identity','message','harness','completion'],
      'completion_fields':['policy','done_calls','success_prints','failure_prints','flags','quiescent','audited','unhandled'],
      'raw_checks':[
          'Use unchanged default-seven validate_promise_observation and classify_promise for every canonical raw row. Never infer a selected Try result through generic classify without policy/completion.',
          'Require exact canonical94 membership, row/result schema/types/identities and original expected labels; verified=True never replaces raw checking.',
          'Preserve common74 source/fingerprints/order and their existing raw verifier criteria exactly. Their mock_observation rows are admissible representatives, not a new stricter legacy diagnostic contract.',
          'For each new positive require exact complete/runtime/empty diagnostic+harness fields and exact policy-specific successful completion object.',
          'For four sync mismatch pairs require failed classification, exception/runtime/Test262Error/empty intrinsic identity/empty harness and exact policy0 counters0/flags256/quiescent/audited/unhandled0. Keep bounded diagnostic-string acceptance from the unchanged validator; the oracle records its source-derived current diagnostic.',
          'Async-helper mismatch requires failed classification and exact host-failure/host/empty error fields/message completion-error/empty harness, policy1 counts1,0,1 flags1 with quiescent/audited true and unhandled0.',
          'Require canonical prerequisite records plus recursive actual raw health, no cycles or alternative edges. A bad same-mode positive poisons all dependent records despite forged reference verified=True.',
          'Missing or changed helper bytes cannot reuse healthy fingerprints. Malformed/unhashable nested data must refuse without an uncaught exception.',
          'An unhealthy gate blocks all30 original modes, including six class exclusions, before run_case; no absent or existing baseline destination may be created/overwritten.'
      ],
      'wire':'Selected Try uses only ERJS2/ERJR3 and the existing seven intrinsic names; no AggregateError extension, no negative metadata or old helper changes.',
      'helper_qualification':'compareArray.js has no executable definition; compareArray/assert.compareArray use assert.js. All eight exact authenticated helpers remain part of the selected closure.'}
put(H/'gate-contract.json',gate)
ready={'status':'complete94 control oracle frozen before implementation or project execution',
       'base':BASE,'oracle':bind(oracle_path),'gate_contract':bind(H/'gate-contract.json'),
       'literal_ready':bind(H/'literals-ready.json'),'refresh':bind(H/'published-base-refresh.json'),
       'author':bind(H/'derive-oracle.py'),'counts':oracle['counts'],
       'qualification':'Executable independent tests follow separately; this record freezes their expected control data and gate contract.'}
put(H/'oracle-ready.json',ready)
print(json.dumps(bind(H/'oracle-ready.json')))
