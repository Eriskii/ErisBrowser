from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

E=Path('/tmp/eris-promise-try-upstream-plan-1')
H=E/'controls-contract-1'
D=Path('/tmp/eris-promise-try-runtime-plan-1')
W=D/'worktree'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'

def bind(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,b):
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists(),p
    p.write_bytes(b if isinstance(b,bytes) else b.encode())
def obj(p,v):save(p,json.dumps(v,indent=2)+'\n')

cases=[
dict(name='api', includes=['propertyHelper.js','isConstructor.js'], policy=0,
source="""assert.sameValue(typeof Promise.try, 'function');
var method = Promise.try;
verifyProperty(Promise, 'try', {value: method, writable: true, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'name', {value: 'try', writable: false, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'length', {value: 1, writable: false, enumerable: false, configurable: true}, {restore: true});
assert.sameValue(Promise.try, method);
assert.notSameValue(method, Promise.resolve);
assert.sameValue(Object.prototype.hasOwnProperty.call(method, 'prototype'), false);
assert.sameValue(isConstructor(function () {}), true);
assert.throws(TypeError, function () { new method(function () {}); });
assert(isConstructor(method) === false, 'Promise.try constructibility');
""",
before="assert(isConstructor(method) === false, 'Promise.try constructibility');",
after="assert(isConstructor(method) === true, 'Promise.try constructibility');",
derivation='Three restoring descriptor checks retain the callable. The existing isConstructor helper distinguishes an ordinary constructor from the nonconstructible builtin. Only the final constructibility expectation differs.'),
dict(name='callback-order-and-arguments', includes=['compareArray.js'], policy=0,
source="""assert.sameValue(typeof Promise.try, 'function');
var trace = [], first = {}, second = {}, holder = {}, seen;
function C(executor) {
  trace.push('C');
  executor(function (value) {
    'use strict';
    trace.push('R');
    assert.sameValue(this, undefined);
    assert.sameValue(value, first);
  }, function () { throw new Test262Error('unexpected reject'); });
  return holder;
}
var result = Promise.try.call(C, function (a, b, c) {
  'use strict';
  trace.push('F');
  assert.sameValue(this, undefined);
  assert.sameValue(arguments.length, 3);
  seen = [a, b, c];
  assert.compareArray(seen, [first, second, -0]);
  return a;
}, first, second, -0);
assert.sameValue(result, holder);
assert.sameValue(compareArray([first, second], [first, second]), true);
assert.sameValue(compareArray([first, second], [second, first]), false);
assert(compareArray(trace, ['F', 'C', 'R']), 'Promise.try callback order');
""",
before="assert(compareArray(trace, ['F', 'C', 'R']), 'Promise.try callback order');",
after="assert(compareArray(trace, ['C', 'F', 'R']), 'Promise.try callback order');",
derivation='Call reaches the strict callback F with Undefined this and exact ordered tail identities, then constructs C, then calls its supplied resolver R with the callback result and Undefined this. The arbitrary constructor object is returned. Global compareArray equal/unequal and assert.compareArray exercise assert.js; compareArray.js is retained as the requested no-op compatibility shim.'),
dict(name='genuine-identity', includes=[], policy=0,
source="""assert.sameValue(typeof Promise.try, 'function');
var P = Promise, method = P.try, trace = '', probes = 0;
var pending = new P(function () {}), receiver = {};
function poison() { probes++; throw new Test262Error('unexpected lookup'); }
Object.defineProperty(pending, 'constructor', {get: function () { trace += 'G'; return receiver; }, configurable: true});
Object.defineProperty(receiver, 'resolve', {get: poison, configurable: true});
Object.defineProperty(receiver, Symbol.species, {get: poison, configurable: true});
Object.defineProperty(P, 'resolve', {get: poison, configurable: true});
Object.defineProperty(P, Symbol.species, {get: poison, configurable: true});
Promise = function () { probes++; throw new Test262Error('replacement Promise'); };
var result = method.call(receiver, function () { trace += 'F'; return pending; });
assert.sameValue(trace, 'FG');
assert.sameValue(probes, 0);
assert.sameValue(result, pending);
""",
before='assert.sameValue(result, pending);',after='assert.notSameValue(result, pending);',
derivation='A genuine pending Promise reads its own constructor once after callback F. Matching the object-valued nonconstructor receiver returns it unchanged before IsConstructor can fail. No capability or job is created, and neither resolve/species poison nor the replaced global is consulted. No then observer is attached after species poisoning.'),
dict(name='ordinary-rejection', includes=[], policy=0,
source="""assert.sameValue(typeof Promise.try, 'function');
var trace = [], reason = {}, escaped = {}, holder = {}, rejects = 0, resolves = 0;
function C(executor) {
  trace.push('C');
  executor(function () { resolves++; }, function (value) {
    'use strict';
    trace.push('J'); rejects++;
    assert.sameValue(this, undefined);
    assert.sameValue(value, reason);
  });
  return holder;
}
var result = Promise.try.call(C, function () { trace.push('F'); throw reason; });
assert.sameValue(result, holder);
function Throwing(executor) {
  trace.push('C');
  executor(function () { resolves++; }, function (value) {
    'use strict';
    trace.push('J'); rejects++;
    assert.sameValue(this, undefined);
    assert.sameValue(value, reason);
    throw escaped;
  });
  return holder;
}
var caught = false;
try { Promise.try.call(Throwing, function () { trace.push('F'); throw reason; }); }
catch (error) { caught = true; assert.sameValue(error, escaped); }
assert.sameValue(caught, true);
assert.sameValue(rejects, 2);
assert.sameValue(resolves, 0);
assert(trace.join('') === 'FCJFCJ', 'Promise.try rejection order');
""",
before="assert(trace.join('') === 'FCJFCJ', 'Promise.try rejection order');",
after="assert(trace.join('') === 'FCJFCJJ', 'Promise.try rejection order');",
derivation='The thrown sentinel survives successful capability construction unchanged. Normal custom reject returns the arbitrary promise object. A second custom reject throws the distinct escaped sentinel once; it propagates synchronously and is caught, with no retry. Each trace is F,C,J, total rejects two and resolves zero.'),
dict(name='async-helper', includes=['asyncHelpers.js'], policy=1,
source="""assert.sameValue(typeof Promise.try, 'function');
assert.sameValue(typeof asyncTest, 'function');
assert.sameValue(typeof assert.throwsAsync, 'function');
var token = {};
asyncTest(function () {
  return Promise.try(function () { return token; }).then(function (value) {
    assert.sameValue(value, token);
    return assert.throwsAsync(TypeError, function () {
      return Promise.try(function () { throw new TypeError('try-control'); });
    });
  });
});
""",
before='return assert.throwsAsync(TypeError, function () {',
after='return assert.throwsAsync(RangeError, function () {',
derivation='The first Try fulfills with the exact token; its reaction returns the helper Promise. The nested Try rejects with an actual TypeError, and assert.throwsAsync matches its constructor. asyncTest awaits the complete chain and delegates once to authenticated DONE. A RangeError expectation makes the helper chain reject with Test262Error and asyncTest calls DONE(error); every rejection in that chain is handled, so unhandled remains zero. The raw host response reports completion-error rather than serializing that Test262Error as a body exception.')]

variants=[];pairs=[]
for case in cases:
    source=case['source']
    assert source.startswith("assert.sameValue(typeof Promise.try, 'function');\n")
    assert source.count(case['before'])==1
    mismatch=source.replace(case['before'],case['after'])
    for label,payload in [(case['name'],source),(case['name']+'-mismatch',mismatch)]:
        path=H/'literals'/f'{label}.js';save(path,payload)
        variants.append({'name':label,'source':payload,
             'expected':'passed' if label==case['name'] else ('completion-error' if case['policy'] else 'synchronous-exception'),
             'completion_policy':case['policy'],'includes':case['includes'],
             'origin':'promise-try-control','prerequisite':None if label==case['name'] else case['name']})
    diff=''.join(difflib.unified_diff(source.splitlines(True),mismatch.splitlines(True),fromfile=case['name']+'.js',tofile=case['name']+'-mismatch.js'))
    save(H/'pair-diffs'/f"{case['name']}.diff",diff)
    assert sum(x.startswith('-') and not x.startswith('---') for x in diff.splitlines())==1
    assert sum(x.startswith('+') and not x.startswith('+++') for x in diff.splitlines())==1
    pairs.append({'name':case['name'],'positive':bind(H/'literals'/f"{case['name']}.js"),
       'mismatch':bind(H/'literals'/f"{case['name']}-mismatch.js"),'diff':bind(H/'pair-diffs'/f"{case['name']}.diff"),
       'only_change':{'before':case['before'],'after':case['after']},'derivation':case['derivation']})

published={}
for rel in ['tools/test262_conformance.py','src/bin/eris-js.rs','src/bin/eris-js/test262_host.rs',
            'src/script.rs','src/script/test262_host.rs']:
    data=subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
    # script.rs has selected D production changes, so bind its published bytes without claiming current equality.
    if rel!='src/script.rs':assert data==(W/rel).read_bytes(),rel
    save(H/'parent'/rel,data);published[rel]=bind(H/'parent'/rel)
tree=ast.parse((H/'parent/tools/test262_conformance.py').read_text())
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='promise_preflight_variants')
returns=[n for n in fn.body if isinstance(n,ast.Return)]
assert len(returns)==1
common=ast.literal_eval(returns[0].value)
assert len(common)==37
obj(H/'common-variants.json',common)
obj(H/'variants.json',variants)
helper_rows={}
for name in ['assert.js','sta.js','doneprintHandle.js','asyncHelpers.js','compareArray.js','isConstructor.js','propertyHelper.js','promiseHelper.js']:
    p=E/'readiness-1/helpers'/name
    save(H/'helpers'/name,p.read_bytes());helper_rows[name]=bind(H/'helpers'/name)

obs={}
for variant in variants:
    policy=variant['completion_policy'];expected=variant['expected']
    counts=(0,0,0) if policy==0 else ((1,1,0) if expected=='passed' else (1,0,1))
    row={'status':'complete','phase':'runtime','error_type':'','error_identity':'','message':'','harness':'',
         'completion':{'policy':policy,'done_calls':counts[0],'success_prints':counts[1],'failure_prints':counts[2],
                       'flags':0,'quiescent':True,'audited':True,'unhandled':0}}
    if expected=='synchronous-exception':
        row.update(status='exception',error_type='Test262Error',message='uncaught exception: [object Object]')
        row['completion']['flags']=256
    elif expected=='completion-error':
        row.update(status='host-failure',phase='host',message='completion-error');row['completion']['flags']=1
    obs[variant['name']]={'classification':'passed' if expected=='passed' else 'failed','expected':expected,
                          'observation':row}
obj(H/'expected-observations.json',{'status':'source-derived expectations, not observed results','new_variants':obs,
 'diagnostic_basis':'Synchronous Test262Error values are ordinary objects. Published ScriptError::thrown and Value::Display yield uncaught exception: [object Object]; data-only throw metadata supplies Test262Error name with empty intrinsic identity. Async mismatch is host completion-error.',
 'gate_diagnostic_policy':'For synchronous mismatch, preserve the existing bounded diagnostic-string acceptance rather than making wording an additional semantic requirement; all other raw fields and complete completion object are exact. Positive and async-mismatch messages are exact.'})
contract={'status':'frozen literals and prospective observations; publication base refresh pending',
 'profile':'promise-try','tooling_base':BASE,'runtime_contract':bind(D/'root/selection-1.json'),
 'prospective_selection':bind(E/'root/prospective-selection.json'),
 'families':pairs,'variants':bind(H/'variants.json'),'common_variants':bind(H/'common-variants.json'),
 'observations':bind(H/'expected-observations.json'),'helpers':helper_rows,'published_sources':published,
 'counts':{'common_variants':37,'common_modes':74,'new_variants':10,'new_modes':20,'total_modes':94},
 'metadata':'Both sloppy and strict. flags async only for async-helper pair; includes exactly held ordered lists; features=[], locale=[], negative=null. completion_policy0 for four sync pairs and1 for async-helper pair.',
 'prerequisites':'Preserve all common74 exact legacy same-mode prerequisites. Each new row depends on all37 common same-mode identities; every non-api new row also requires positive api in that mode, and each mismatch requires its corresponding same-mode positive without duplicate edges.',
 'helper_qualification':'compareArray.js is an unchanged authenticated compatibility shim; executable compareArray/assert.compareArray live in assert.js. promiseHelper.js is common-control-only. asyncHelpers.js is directly exercised by the async pair.',
 'limitations':['No engine/project module imports, execution or future runner reads.',
                'No actual 15-source profile outcome or healthy-gate result is inferred.',
                'Final seal must bind the newly published D base and exact unchanged tooling additively.']}
obj(H/'literal-contract.json',contract)
ready={'status':'literal subset frozen; no final publication-base seal yet','contract':bind(H/'literal-contract.json'),
       'author':bind(H/'author-literals.py'),'payloads':[bind(p) for p in sorted((H/'literals').glob('*.js'))],
       'variants':bind(H/'variants.json'),'observations':bind(H/'expected-observations.json')}
obj(H/'literals-ready.json',ready)
print(json.dumps(bind(H/'literals-ready.json')))
