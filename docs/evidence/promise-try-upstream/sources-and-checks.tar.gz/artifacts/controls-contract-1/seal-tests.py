from pathlib import Path
import ast
import difflib
import hashlib
import json

E=Path('/tmp/eris-promise-try-upstream-plan-1');H=E/'controls-contract-1'
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p
    p.write_text(json.dumps(x,indent=2)+'\n')
module=H/'raw/tools/test_test262_promise_try_controls.py'
source=module.read_text();tree=ast.parse(source)
classes=[n for n in tree.body if isinstance(n,ast.ClassDef)]
assert len(classes)==1
tests=[n for n in classes[0].body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(tests)==10
names=[n.name for n in tests]
for n in tests:
    segment=ast.get_source_segment(source,n)
    if n.name.startswith('test_common_74_'):
        assert 'self.require_try()' not in segment
    else:assert isinstance(n.body[0],ast.Expr) and ast.unparse(n.body[0])=='self.require_try()'
oracle=json.loads((H/'raw/tools/promise-try-controls-oracle.json').read_bytes())
assert oracle['counts']=={'common':74,'new':20,'total':94,'original_modes':30}
sha=bind(H/'raw/tools/promise-try-controls-oracle.json')['sha256']
assert f"ORACLE_SHA = '{sha}'" in source
old_ast=ast.parse((H/'parent/tools/test262_conformance.py').read_text())
old_fns={n.name for n in old_ast.body if isinstance(n,ast.FunctionDef)}
old_imports={a.asname or a.name for n in old_ast.body if isinstance(n,ast.ImportFrom) for a in n.names}
assert 'promise_try_preflight_healthy' not in old_fns
for name in ['bounded_process','promise_preflight_variants','promise_harness_preflight','run_case',
             'harness_preflight','classify','classify_promise','load_corpus','main']:
    assert name in old_fns | old_imports,name
assert 'import test262_conformance as runner' in source
assert 'import import_test262 as importer' in source
assert "side_effect=AssertionError('network/adapter forbidden')" in source
assert "side_effect=AssertionError('blocked case dispatched')" in source
assert 'for exists in (False, True):' in source
assert "self.assertEqual(document['counts'], {'blocked': 30})" in source
assert not any(isinstance(n,(ast.AsyncFunctionDef,ast.Await)) for n in ast.walk(tree))
files=[]
for p in sorted((H/'raw/tools').iterdir()):
    rel='tools/'+p.name
    assert not (E/'worktree'/rel).exists(),rel
    diff=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=rel))
    out=H/'diffs'/(rel.replace('/','__')+'.diff');out.parent.mkdir(parents=True,exist_ok=True)
    assert not out.exists();out.write_text(diff)
    files.append({'relative_path':rel,'before':None,'raw':bind(p),'diff':bind(out)})
roster={'groups':10,'names':names,'oracle_rows':94,'new_literal_sources':10,'new_mode_rows':20,
        'preserved_common_rows':74,'blocked_original_modes':30,'class_excluded_modes_in_blocked_fixture':6,
        'parent_prediction':{'passed_groups':1,'failed_groups':9,'error_groups':0,
          'condition':'After root imports the independently authenticated33-file corpus and these two new test files, with published15db tooling otherwise unchanged.',
          'passed':'Existing common74 composition exercises only existing parent APIs and exact previous raw representatives.',
          'failure':'Each other group first checks the selected Promise.try gate exists and fails the explicit assertion selected Promise.try gate is absent.',
          'unreached':'New factory/gate/dispatch/adversarial/main assertions in those nine groups. No parent execution or healthy control outcome is claimed.'},
        'meaningful_checks':['canonical94 literals/metadata/helper order/fingerprints/references',
          'selected dispatch and exact outcomes with a guarded mock adapter',
          'each row required; missing/duplicate/extra/schema/identity/verified attacks',
          'default-seven raw errors/completion types, malformed Unicode/nested objects and harness attribution',
          'recursive same-mode positive dependencies plus altered or cyclic edge refusal',
          'each missing or changed helper including authenticated compareArray shim',
          'every raw row reclassified through unchanged default-seven classify_promise',
          'positive/mismatch swaps and precise async versus bounded sync diagnostic contracts',
          'all30 modes blocked before run_case including metadata-excluded modes; absent/existing baseline protection'],
        'scope':'Only source parsing and static contract checks here; no import of project modules, no engine/adapter/tests/network execution.'}
put(H/'test-roster.json',roster)
checks={'status':'source ready; independent expectations frozen before runner implementation',
        'syntax':'stdlib ast.parse succeeds; this is not a project test result',
        'import_eligibility':'Only existing module imports at module scope; all new API access is inside test bodies after an explicit feature assertion.',
        'old_common':'Prior frozen74 records and published common37 exact by derive-oracle; helper fingerprints independently reconstructed.',
        'literal_inverses':'Five one-line changes only, checked before literal freeze.',
        'parent_prediction':roster['parent_prediction'],'execution':'None',
        'files':files,'oracle_ready':bind(H/'oracle-ready.json'),'test_roster':bind(H/'test-roster.json')}
put(H/'source-checks.json',checks)
record={'status':'sealed independent control/gate test payload; no project execution or future implementation read',
        'base':'15db31c76f5a2f259deffadbf0f95e212a5fa61c','files':files,
        'selection':bind(E/'root/selection-1.json'),'source_parent':bind(E/'source-parent.json'),
        'literals':bind(H/'literals-ready.json'),'oracle_ready':bind(H/'oracle-ready.json'),
        'published_refresh':bind(H/'published-base-refresh.json'),
        'gate_contract':bind(H/'gate-contract.json'),'source_checks':bind(H/'source-checks.json'),
        'roster':bind(H/'test-roster.json'),
        'author_scripts':[bind(H/n) for n in ['author-literals.py','derive-oracle.py','seal-tests.py']],
        'payload_members':[bind(p) for folder in ['literals','pair-diffs','helpers','parent'] for p in sorted((H/folder).rglob('*')) if p.is_file()],
        'limits':['Mock observations are frozen source-derived expectations, not observations of the adapter.',
                  'Expected source modes remain30; no actual profile pass/fail total is predicted.',
                  'Common74 acceptance stays at the existing verifier criteria; no old decoder/classifier policy is widened.',
                  'Root owns project imports/executions and independent peers; this hold writes only external files.']}
put(H/'source-ready.json',record)
print(json.dumps(bind(H/'source-ready.json')))
