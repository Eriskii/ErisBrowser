from pathlib import Path
import ast
from collections import Counter
import hashlib
import json
import re
import subprocess

E=Path('/tmp/eris-promise-try-upstream-plan-1');R=E/'layout-contract-review-1'
I=E/'importer-contract-1';P=E/'protocol-contract-1'
C=I/'corpus/tests/upstream/test262-promise-try'
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,v):
    assert not p.exists(),p;p.write_text(json.dumps(v,indent=2)+'\n')
verified=[]
def bindings(x):
    if isinstance(x,dict):
        if {'path','bytes','sha256'} <= x.keys() and Path(x['path']).is_absolute():
            p=Path(x['path']);b=p.read_bytes()
            assert (len(b),sha(b))==(x['bytes'],x['sha256']),p
            verified.append(bind(p))
        for value in x.values():bindings(value)
    elif isinstance(x,list):
        for value in x:bindings(value)
isr=json.loads((I/'source-ready.json').read_bytes());psr=json.loads((P/'source-ready.json').read_bytes())
assert sha((I/'source-ready.json').read_bytes())=='8bdd2572e5fa5852b79f5aef5ede6f3d3480d45be5b7f76a57bd0ff14b5773b5'
assert sha((P/'source-ready.json').read_bytes())=='46c52fd8b1a7ece5f3dcc4c0a7879662d95e853e714b0d73e55d5ce7b3649df1'
for value in [isr,psr,json.loads((I/'package-ready.json').read_bytes())]:bindings(value)
assert isr['base']==psr['base']==BASE
parent=json.loads((E/'source-parent.json').read_bytes())['source_sha256']
published=[]
for entry in isr['parent_bindings']:
    rel=entry['relative'];p=Path(entry['file']['path']);b=p.read_bytes()
    assert b==subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=E/'worktree')
    assert sha(b)==parent[rel],rel
    published.append({'relative':rel,'held':bind(p),'published_and_parent_exact':True})
assert Path(psr['published_parent']['path']).read_bytes()==(I/'parent/tools/test262_conformance.py').read_bytes()

oracle=json.loads((I/'raw/tools/test262-promise-try-import-oracle.json').read_bytes())
manifest=json.loads((C/'manifest.json').read_bytes())
assert manifest==oracle['expected_manifest']
assert sha((C/'manifest.json').read_bytes())==oracle['manifest_sha256']
actual=[{'path':p.relative_to(C).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())}
        for p in sorted(C.rglob('*')) if p.is_file()]
assert actual==oracle['all_files']
assert len(actual)==33 and sum(x['bytes'] for x in actual)==118162
assert len(manifest['files'])==25 and len(manifest['inventory_proof']['files'])==7
for row in manifest['files']+manifest['inventory_proof']['files']:
    b=(C/row['path']).read_bytes();assert (len(b),sha(b))==(row['bytes'],row['sha256'])
trees={};tree_checks=[]
for path in sorted((C/'inventory-proof').glob('tree-*.json')):
    t=json.loads(path.read_bytes());assert t['truncated'] is False
    assert t['sha']==path.stem[5:]
    names=[x['path'] for x in t['tree']]
    assert len(names)==len(set(names))
    chunks=[]
    for row in t['tree']:
        name=row['path'];assert name not in {'.','..'} and not any(c in name for c in '/\\\0')
        assert {'040000':'tree','100644':'blob','100755':'blob','120000':'blob','160000':'commit'}[row['mode']]==row['type']
        order=(name+('/' if row['type']=='tree' else '')).encode()
        chunks.append((order,row['mode'].lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(row['sha'])))
    assert oid('tree',b''.join(v for _,v in sorted(chunks)))==t['sha']
    trees[t['sha']]={x['path']:x for x in t['tree']}
    tree_checks.append({'sha':t['sha'],'entries':len(names),'reconstructed':True})
assert len(trees)==6
source=(I/'parent/tools/import_test262.py').read_text();im=ast.parse(source)
assign={target.id:n.value for n in im.body if isinstance(n,ast.Assign) for target in n.targets if isinstance(target,ast.Name)}
def inert(n):
    if isinstance(n,ast.Name):return inert(assign[n.id])
    if isinstance(n,ast.Dict):return {inert(k):inert(v) for k,v in zip(n.keys,n.values)}
    if isinstance(n,ast.Set):return {inert(x) for x in n.elts}
    if isinstance(n,(ast.List,ast.Tuple)):return [inert(x) for x in n.elts]
    return ast.literal_eval(n)
revision=inert(assign['REVISION']);root=inert(assign['REVISION_TREE'])
commit=json.loads((C/'inventory-proof/commit.json').read_bytes())
assert commit['sha']==revision==manifest['revision'] and commit['tree']['sha']==root
ancestry=[];node=root
for name in ['test','built-ins','Promise','try']:
    entry=trees[node][name];assert entry['type']=='tree'
    ancestry.append({'parent':node,'name':name,'child':entry['sha']});node=entry['sha']
leaf=trees[node];assert len(leaf)==15 and all(x['type']=='blob' for x in leaf.values())
assert sorted(leaf)==manifest['directories']['Promise/try']
harness=trees[trees[root]['harness']['sha']]
for row in manifest['files']:
    rel=row['path'];b=(C/rel).read_bytes()
    if rel.startswith('test/'):
        entry=leaf[Path(rel).name];retained=E/'readiness-1/sources'/Path(rel).name
    elif rel.startswith('harness/'):
        entry=harness[Path(rel).name];retained=E/'readiness-1/helpers'/Path(rel).name
    else:
        entry=trees[root][rel];retained=E/'readiness-1/legal'/rel
    assert (oid('blob',b),len(b))==(entry['sha'],entry['size']),rel
    assert b==retained.read_bytes(),rel
    if not rel.startswith('test/'):
        assert manifest['inventory_proof']['auxiliary_blobs'][rel]==entry['sha']
metadata={};orders={};identities=[];features=Counter();includes=Counter();policies=Counter()
for name in sorted(leaf):
    rel='test/built-ins/Promise/try/'+name;b=(C/rel).read_bytes()
    front=re.search(rb'/\*---(.*?)---\*/',b,re.S).group(1).decode()
    m={}
    for key in ['flags','includes','features','locale']:
        field=re.search(r'^'+key+r':\s*\[([^\]]*)\]\s*$',front,re.M)
        m[key]=[x.strip() for x in field[1].split(',') if x.strip()] if field else []
    assert not re.search(r'^(negative|timeout):',front,re.M)
    m['negative']=None;metadata[rel]=m;features.update(m['features']);includes.update(m['includes'])
    policy=int('async' in m['flags']);assert set(m['flags'])<= {'async'}
    names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+m['includes'];orders[rel]=names
    hashes=[{'name':x,'sha256':sha((C/'harness'/x).read_bytes())} for x in names]
    for mode in ['sloppy','strict']:
        identity={'source_sha256':sha(b),'mode':mode,'metadata':m,'harness':hashes,'completion_policy':policy}
        identities.append({'id':rel+':'+mode,'case_sha256':sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())})
        policies[policy]+=1
assert metadata==oracle['metadata'] and orders==oracle['helper_order'] and identities==oracle['case_identities']
assert features=={'promise-try':15,'class':3,'Reflect.construct':1} and policies=={0:22,1:8}
assert {'assert.js','sta.js','doneprintHandle.js'}|set(includes)==set(oracle['raw_helpers'])
assert set(oracle['selected_helpers'])-set(oracle['raw_helpers'])=={'promiseHelper.js'}
for name in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES']:
    data=inert(assign[name]);data=sorted(data) if name=='TREE_PROFILES' else data
    assert sha(json.dumps(data,sort_keys=True).encode())==oracle['old_tables_sha256'][name]
assert len(inert(assign['PROFILES']))==60

protocol=P/'raw/tools/test_test262_promise_try_protocol.py';pt=ast.parse(protocol.read_text())
hashmap=next(ast.literal_eval(n.value) for n in pt.body if isinstance(n,ast.Assign)
             and any(isinstance(t,ast.Name) and t.id=='PRESERVED_FUNCTIONS' for t in n.targets))
old=(P/'parent/tools/test262_conformance.py').read_text();ot=ast.parse(old);lines=old.splitlines(True)
protected=[]
for name,expected in hashmap.items():
    fn=next(n for n in ot.body if isinstance(n,ast.FunctionDef) and n.name==name)
    body=''.join(lines[fn.lineno-1:fn.end_lineno]);assert sha(body.encode())==expected,name
    protected.append({'name':name,'sha256':expected})
assert len(protected)==10
rosters=[]
for path in [I/'raw/tools/test_import_test262_promise_try.py',I/'raw/tools/test_test262_promise_try_loader.py',protocol]:
    t=ast.parse(path.read_text());names=[n.name for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
    rosters.append({'source':bind(path),'tests':names,'groups':len(names)})
assert [x['groups'] for x in rosters]==[7,3,9]
checks={'status':'clear','source_ready_bindings':[bind(I/'source-ready.json'),bind(P/'source-ready.json')],
        'verified_hold_members':verified,'published_joins':published,'package_files':33,'package_bytes':118162,
        'tree_checks':tree_checks,'ancestry':ancestry,'root_pin':{'revision':revision,'tree':root},
        'blob_checks':{'sources':15,'auxiliaries':10,'all_git_objects_and_retained_bytes_exact':True},
        'metadata':{'sources':15,'mode_cases':30,'sync_modes':22,'async_modes':8,'class_modes':6,
                    'features':dict(features),'helpers':8,'guard_only':'promiseHelper.js'},
        'fingerprints':identities,'protected_functions':protected,'rosters':rosters,
        'old_tables':{'profiles':60,'all_frozen_hashes_recomputed':True},
        'authentication_limit':'Commit receipt joins fixed published revision/root; six complete tree IDs and25 selected blob IDs are independently reconstructed. No claim to reconstruct the raw Git commit object.'}
put(R/'checks.json',checks)
review={'status':'clear','findings':[],
        'importer_contract':bind(I/'source-ready.json'),'protocol_contract':bind(P/'source-ready.json'),
        'selection':bind(E/'root/selection-1.json'),'checks':bind(R/'checks.json'),'audit_source':bind(R/'audit.py'),
        'assessment':[
          'All parent snapshots join published15db and parent inventory. Package33/hash/manifest membership, six root-linked complete trees,15 source and10 auxiliary blobs and all30 policy-bearing fingerprints independently reconcile.',
          'All15 bodies remain, with22 sync and8 async modes. Six class-bearing modes remain in the loader result; metadata admission excludes class later. Raw source helper closure is seven; only promiseHelper is added for common guards; compareArray shim remains unchanged.',
          'Importer tests replay exact32 fetch URLs and33 byteset, preserve60 old tables, reject pinned proof/blob/selection mutations before publication, and isolate the no-descendant and observed-helper-closure postconditions.',
          'Loader tests mutate physical bytes and rewrite manifest entries/counts before authentication checks; auxiliary authority rewrites, omissions, extras, rehashed sources/proofs and proof aliases have explicit refusal assertions. Positive assertions independently check every case/helper identity, not only counts.',
          'Protocol tests construct ERJS2/ERJR3 bytes independently, test all truncation prefixes and malformed trailer/UTF8 fields, and distinguish primitive wire errors from decoded dictionary downgrades.',
          'Selected Try routing is tested before encoding/transport and through direct unchanged classify_promise, while the old default/profile decode/classification call arities remain asserted. Seven intrinsic identities and the existing Any/AggregateError exceptions stay separate.',
          'Resource/unsupported/harness-error/host-veto/timeout/adapter-error fixtures assert distinct routing categories; mocked structurally valid packets are not represented as observed engine outputs. Ten protected function hashes match inert published source.',
          'No candidate runner/importer production was inspected or project module imported/executed. Parent outcomes remain source predictions; this peer makes no compile, health or profile-result claim.'
        ],
        'scope':'Bounded static test/package/protocol review; no live source writes or execution.'}
put(R/'review.json',review)
print(json.dumps(bind(R/'review.json')))
