import hashlib
import json
from pathlib import Path

E = Path('/tmp/eris-promise-try-upstream-plan-1')
W = E / 'worktree'

def stamp(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def verify(row):
    assert stamp(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}, row

reviews = []
for name in ['layout-contract-review-1', 'controls-review-1', 'preservation-review-1']:
    p = E / name / 'review.json'
    d = json.loads(p.read_bytes())
    assert d['status'] == 'clear', d
    reviews.append(stamp(p))

# Preserve mutable published source references before any candidate import.
snapshot = E / 'root/published-inputs'
snapshot.mkdir(exist_ok=True)
for rel in ['tools/import_test262.py', 'tools/test262_conformance.py', '.github/workflows/check.yml']:
    dest = snapshot / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('xb') as f:
        f.write((W / rel).read_bytes())

sources = []
holds = []
for name in ['importer-contract-1', 'protocol-contract-1', 'controls-contract-1', 'preservation-contract-1']:
    ready = E / name / 'source-ready.json'
    d = json.loads(ready.read_bytes())
    holds.append(stamp(ready))
    for row in d['files']:
        rel = row.get('relative_path', row.get('relative'))
        assert rel.startswith('tools/')
        assert not (W / rel).exists(), rel
        verify(row['raw'])
        sources.append((rel, Path(row['raw']['path'])))

package = json.loads((E / 'importer-contract-1/package-ready.json').read_bytes())
corpus = E / 'importer-contract-1/corpus/tests/upstream/test262-promise-try'
for row in package['all_files']:
    source = corpus / row['path']
    got = stamp(source)
    assert (got['bytes'], got['sha256']) == (row['bytes'], row['sha256'])
    rel = 'tests/upstream/test262-promise-try/' + row['path']
    assert not (W / rel).exists()
    sources.append((rel, source))
assert len(sources) == 41
assert len({r for r, _ in sources}) == 41
for rel, source in sources:
    dest = W / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    with dest.open('xb') as f:
        f.write(source.read_bytes())
record = dict(phase='tests and independently frozen corpus on unchanged published parent',
              reviews=reviews, holds=holds,
              files=[dict(relative_path=rel, **stamp(W / rel)) for rel, _ in sources])
with (E / 'root/test-contract-import-1.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(dict(imported=len(sources), receipt=stamp(E / 'root/test-contract-import-1.json'))))
