from pathlib import Path
import hashlib,json,shutil,subprocess
E=Path(__file__).resolve().parents[1];D=Path('/tmp/eris-promise-try-runtime-plan-1');C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');W=E/'worktree'
publication=json.loads((D/'root/github-publication.json').read_bytes());assert publication['status']=='pushed';base=publication['commit']
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,text=True).strip()
assert git('rev-parse','HEAD')==base and git('status','--porcelain')=='';assert not W.exists()
subprocess.run(['git','worktree','add','-b','promise-try-upstream',str(W),base],cwd=MAIN,check=True)
source=json.loads((D/'source-final.json').read_bytes());source['base']=base
source['scope']='Published Promise.try runtime selected inputs. This is a cumulative selected-input inventory, not the complete build graph. Rust, Cargo/build settings and existing tooling/corpus/policy bytes will be compared explicitly in the next profile checkpoint.'
for rel,sha in source['source_sha256'].items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==sha,rel
(E/'source-parent.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ['run-tool.py','run-check.py']:shutil.copyfile(D/name,E/name)
for name in ['target-msrv','target-1990']:(E/name).symlink_to((D/name).resolve(),target_is_directory=True)
for directory in ['validation','replay-parent','python-parent']:(E/directory).mkdir()
for short in ['aggregate-error','existing','all','race','settled','any','with-resolvers']:shutil.copyfile(D/f'upstream-{short}-1.json',E/'replay-parent'/f'upstream-{short}-1.json')
for suffix in ['log','json']:shutil.copyfile(C/'validation'/f'python-full-1.{suffix}',E/'python-parent'/f'python-full-1.{suffix}')
record=dict(base=base,branch='promise-try-upstream',worktree=str(W),parent_source_count=len(source['source_sha256']),parent_source_sha256=hashlib.sha256((E/'source-parent.json').read_bytes()).hexdigest(),scope='Pinned complete Promise.try profile. Reuse exact published ordinary/host binaries; no Rust or host wire/identity change. Preserve all60 old profile policies and full seven-profile1300case546control arrays; parent Python652 groups.')
(E/'root/setup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
