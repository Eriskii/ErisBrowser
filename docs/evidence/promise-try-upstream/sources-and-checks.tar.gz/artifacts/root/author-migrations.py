from pathlib import Path
import ast,hashlib,json,difflib,re
E=Path(__file__).resolve().parents[1];W=E/'worktree';H=E/'migrations-1';H.mkdir(exist_ok=True)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
census=json.loads((E/'readiness-1/preservation-census.json').read_text());by={}
for row in census['entries']:by.setdefault(row['path'],[]).append(row)
assert len(by)==24 and sum(map(len,by.values()))==47
log=(E/'validation/python-parent-1.log').read_text();groups=re.findall(r'^test\S+ \(([^)]+)\) \.\.\. ok$',log,re.M);assert len(groups)==652
rows=[];retained=[]
for rel,entries in sorted(by.items()):
 before=(W/rel).read_text();after=before;edits=[]
 for row in entries:
  line=row['source'];assert before.splitlines()[row['line']-1]==line,(rel,row)
  if "'promise-with-resolvers'" in line:
   assert line.count("'promise-with-resolvers'")==1;new=line.replace("'promise-with-resolvers'","'promise-with-resolvers', 'promise-try'")
  elif 'if k != PROFILE' in line:new=line.replace('if k != PROFILE',"if k not in {PROFILE, 'promise-try'}")
  elif 'if k != NEW_PROFILE' in line:new=line.replace('if k != NEW_PROFILE',"if k not in {NEW_PROFILE, 'promise-try'}")
  elif '- {NEW_PROFILE}' in line:new=line.replace('- {NEW_PROFILE}',"- {NEW_PROFILE, 'promise-try'}")
  elif '- {PROFILE}' in line:new=line.replace('- {PROFILE}',"- {PROFILE, 'promise-try'}")
  elif "- {'promise-any'}" in line:new=line.replace("- {'promise-any'}","- {'promise-any', 'promise-try'}")
  elif 'runner.PROMISE_HOST_PROFILES' in line:new=line.replace('runner.PROMISE_HOST_PROFILES',"runner.PROMISE_HOST_PROFILES - {'promise-try'}")
  else:raise AssertionError((rel,line))
  assert after.count(line+'\n')==1;after=after.replace(line+'\n',new+'\n',1);edits.append(dict(before=line+'\n',after=new+'\n'))
 restored=after
 for edit in reversed(edits):
  assert restored.count(edit['after'])==1;restored=restored.replace(edit['after'],edit['before'],1)
 assert restored==before
 ba,aa=ast.parse(before),ast.parse(after)
 constants=lambda tree:[n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and not isinstance(n.value,str)]
 assert constants(ba)==constants(aa)
 names=lambda tree:[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef)]
 assert names(ba)==names(aa)
 for prefix,data in [('before',before),('raw',after)]:
  p=H/prefix/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
 p=H/'diffs'/(Path(rel).name+'.diff');p.parent.mkdir(exist_ok=True);p.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=rel,tofile=rel)))
 module=Path(rel).stem+'.';group_rows=[g for g in groups if g.startswith(module)];assert group_rows;retained+=group_rows
 rows.append(dict(relative_path=rel,before=bind(H/'before'/rel),raw=bind(H/'raw'/rel),diff=bind(p),edits=edits,retained_groups=group_rows))
assert len(retained)==len(set(retained))
out=dict(status='frozen exact new-profile exclusions only; no oracle or numeric expectation changes',base='15db31c76f5a2f259deffadbf0f95e212a5fa61c',selection=bind(E/'root/selection-1.json'),census=bind(E/'readiness-1/preservation-census.json'),files=rows,paths=24,edits=47,retained_groups=len(retained),roster=sorted(retained),qualification='All old test names, numeric literals, expected maps, oracle hashes, source strings and semantics survive exact inverse restoration. Add only promise-try to historical profile/host-set exclusions; no production/live edits or project execution.')
(H/'source-ready.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(ready=bind(H/'source-ready.json'),paths=24,exclusions=47,retained_groups=len(retained))))
