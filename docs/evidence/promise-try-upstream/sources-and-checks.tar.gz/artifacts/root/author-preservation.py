from pathlib import Path
import ast,hashlib,json,difflib
E=Path(__file__).resolve().parents[1];W=E/'worktree';H=E/'preservation-contract-1';(H/'raw/tools').mkdir(parents=True,exist_ok=True)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def named_assignments(source):
 return {t.id:n.value for n in ast.parse(source).body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
old=json.loads((W/'tools/with-resolvers-preservation-oracle.json').read_text());oracle=dict(old)
oracle['base']='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
source=(W/'tools/import_test262.py').read_text();nodes=named_assignments(source)
profiles={ast.literal_eval(k):ast.literal_eval(nodes[v.id]) for k,v in zip(nodes['PROFILES'].keys,nodes['PROFILES'].values)}
roots=ast.literal_eval(nodes['PROFILE_ROOTS']);trees=sorted(ast.literal_eval(nodes['TREE_PROFILES']))
assert {k:v for k,v in profiles.items() if k!='promise-with-resolvers'}==old['profiles']
assert {k:v for k,v in roots.items() if k!='promise-with-resolvers'}==old['roots']
assert [k for k in trees if k!='promise-with-resolvers']==old['tree_profiles']
assert len(profiles)==60
oracle.update(profiles=profiles,roots=roots,tree_profiles=trees)
features=dict(old['features']);features['promise-with-resolvers']=sorted(ast.literal_eval(named_assignments((W/'tools/test262_conformance.py').read_text())['PROMISE_WITH_RESOLVERS_FEATURES']));oracle['features']=features
policies=dict(old['policies_at_timeout3']);report=json.loads((E/'replay-parent/upstream-with-resolvers-1.json').read_text());policy=report['runner_policy'];assert policy['timeout_seconds']==3.0
assert hashlib.sha256(json.dumps(policy,sort_keys=True).encode()).hexdigest()==report['runner_policy_sha256']
policies['promise-with-resolvers']={'policy':policy,'sha256':report['runner_policy_sha256']};oracle['policies_at_timeout3']=policies
oracle.pop('old58_policy_join');oracle['old59_policy_join']=True
unchanged={}
for rel,excluded in [('tools/import_test262.py',{'profile_tree_inventory','import_corpus'}),('tools/test262_conformance.py',{'load_corpus','decode_response','run_case','harness_preflight','main'})]:
 s=(W/rel).read_text();all_funcs={n.name:hashlib.sha256(ast.get_source_segment(s,n).encode()).hexdigest() for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
 assert {n:all_funcs[n] for n in old['unchanged_functions'][rel]}==old['unchanged_functions'][rel]
 unchanged[rel]={n:h for n,h in all_funcs.items() if n not in excluded}
assert {k:len(v) for k,v in unchanged.items()}=={'tools/import_test262.py':11,'tools/test262_conformance.py':63}
oracle['unchanged_functions']=unchanged
op=H/'raw/tools/promise-try-preservation-oracle.json';op.write_text(json.dumps(oracle,indent=2)+'\n');digest=bind(op)['sha256']
test=(W/'tools/test_test262_with_resolvers_preservation.py').read_text()
test=test.replace('Literal parent policies and source boundaries for the ordinary Promise.withResolvers profile.','Frozen parent policies and source boundaries for the Promise.try host profile.')
test=test.replace('with-resolvers-preservation-oracle.json','promise-try-preservation-oracle.json').replace("ORACLE_SHA = '51a2a9bfff4649528852183f1db1ccf0abc6ad66c33411770cfaef4b5a23d9c3'",'ORACLE_SHA = '+repr(digest)).replace("NEW_PROFILE = 'promise-with-resolvers'","NEW_PROFILE = 'promise-try'").replace('WithResolversPreservationTests','PromiseTryPreservationTests').replace('test_all_59_old_tables','test_all_60_old_tables').replace("len(old['profiles']), 59","len(old['profiles']), 60").replace('sorted(runner.PROMISE_HOST_PROFILES)','sorted(runner.PROMISE_HOST_PROFILES - {NEW_PROFILE})').replace("'promise_all_settled_preflight_healthy'):","'promise_all_settled_preflight_healthy', 'with_resolvers_preflight_healthy'):")
assert 'with_resolvers_preflight_healthy' in test
test=test.replace("        self.assertIn('classify',", "        self.assertEqual(sum(len(v) for v in self.oracle['unchanged_functions'].values()), 74)\n        self.assertIn('classify',")
tp=H/'raw/tools/test_test262_promise_try_preservation.py';tp.write_text(test);ast.parse(test)
files=[]
for p in [op,tp]:
 rel=str(p.relative_to(H/'raw'));assert not (W/rel).exists();diff=H/'diffs'/ (p.name+'.diff');diff.parent.mkdir(exist_ok=True);diff.write_text(''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile=rel)));files.append(dict(relative_path=rel,before_absent=True,raw=bind(p),diff=bind(diff)))
result=dict(status='frozen independent preservation contract before production changes',base=oracle['base'],selection=bind(E/'root/selection-1.json'),files=files,old_policy_count=60,unchanged_functions={'importer':11,'runner':63},groups=['PromiseTryPreservationTests.test_all_60_old_tables_features_and_actual_main_policies_remain_exact','PromiseTryPreservationTests.test_old_import_authentication_gates_classifiers_and_encoders_remain_exact'],derivation='Published59-profile literal oracle plus exact retained withResolvers policy/report and AST-only published tables/function bodies; no project import or execution.',sources=[bind(W/'tools/with-resolvers-preservation-oracle.json'),bind(W/'tools/import_test262.py'),bind(W/'tools/test262_conformance.py'),bind(W/'tools/test_test262_with_resolvers_preservation.py'),bind(E/'replay-parent/upstream-with-resolvers-1.json')])
(H/'source-ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(ready=bind(H/'source-ready.json'),oracle=bind(op),groups=2,old_policies=60,unchanged_functions=74)))
