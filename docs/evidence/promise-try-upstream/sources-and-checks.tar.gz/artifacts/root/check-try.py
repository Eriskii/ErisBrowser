import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parents[1]
W = E / 'worktree'
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
report_path = E / 'upstream-try-1.json'
report = json.loads(report_path.read_bytes())
checked_path = E / 'upstream-try-check-1.json'
checked = json.loads(checked_path.read_bytes())
baseline_path = W / 'tests/conformance/test262-promise-try-current.json'
baseline = json.loads(baseline_path.read_bytes())
oracle = json.loads((W / 'tools/test262-promise-try-import-oracle.json').read_bytes())
controls = json.loads((W / 'tools/promise-try-controls-oracle.json').read_bytes())
assert report['harness_preflight_passed'] is True
assert report['mode_cases'] == 30 and report['source_files'] == report['source_tests'] == 15
assert report['negative_source_tests'] == report['fixture_files'] == 0
assert len(report['cases']) == len(baseline['cases']) == 30
assert sum(report['counts'].values()) == 30
assert set(report['counts']) <= {'passed', 'failed', 'unsupported'}
assert report['binary_sha256'] == '9655090e7ffeeeef80c0adccf96bf1276bf80f6f164213d6afd965adb3480ab6'
assert report['corpus_manifest_sha256'] == oracle['manifest_sha256']
assert [(r['id'], r['case_sha256']) for r in report['cases']] == [(r['id'], r['case_sha256']) for r in oracle['case_identities']]
assert set(baseline) == {'revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'binary_sha256', 'cases'}
for key in set(baseline) - {'cases'}:
    assert baseline[key] == report[key]
assert baseline['cases'] == {r['id']: {k: r[k] for k in ('status', 'case_sha256', 'source_sha256')} for r in report['cases']}
preflight = report['harness_preflight']
assert len(preflight) == len(controls['records']) == 94
for actual, frozen in zip(preflight, controls['records']):
    assert actual['name'] == frozen['name'] and actual['expected'] == frozen['expected']
    assert actual['verified'] is True
    for key in ('id', 'file', 'mode', 'case_sha256', 'source_sha256'):
        assert actual['result'][key] == frozen[key], (actual['name'], key)
    assert all(r['verified'] is True for r in actual['prerequisites'])
for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256', 'counts',
            'corpus_manifest_sha256', 'binary_sha256', 'harness_preflight_passed'):
    assert report[key] == checked[key], key
assert not checked['regressions'] and not checked['improvements']
result = dict(status='pass', report=bind(report_path), baseline_check=bind(checked_path),
              baseline=bind(baseline_path), counts=report['counts'], cases=30, controls=94,
              first_candidate=True, full_control_and_case_records_stable=True,
              runner_policy=report['runner_policy'], runner_policy_sha256=report['runner_policy_sha256'],
              nonpassing=[r for r in report['cases'] if r['status'] != 'passed'])
(E / 'root/try-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result))
