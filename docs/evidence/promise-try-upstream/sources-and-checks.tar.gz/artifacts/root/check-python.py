import hashlib
import json
import re
from pathlib import Path

E = Path(__file__).resolve().parents[1]
def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def passed(label, count):
    path = E / 'validation' / (label + '.json')
    receipt = json.loads(path.read_bytes())
    log = E / 'validation' / receipt['log']
    assert receipt['exit'] == 0 and receipt['sha256'] == bind(log)['sha256']
    text = log.read_text()
    rows = re.findall(r'^test_\S+ \((test_\S+)\) \.\.\. ok$', text, re.M)
    assert len(rows) == len(set(rows)) == count, (label, len(rows))
    assert re.search(rf'^Ran {count} tests in ', text, re.M)
    assert text.rstrip().endswith('OK')
    return rows, dict(receipt=bind(path), log=bind(log), passed=count)

parent, parent_record = passed('python-parent-1', 652)
selected, selected_record = passed('python-selected-candidate-1', 31)
full, full_record = passed('python-full-1', 683)
plan = json.loads((E / 'root/validation-plan.json').read_bytes())
assert set(selected) == set(plan['new_groups'])
assert set(full) == set(parent) | set(selected)
assert not set(parent) & set(selected)
result = dict(status='pass', parent=parent_record, first_candidate=selected_record,
              full=full_record, previous_groups_retained=652, new_groups=31,
              exact_683_group_roster=True,
              parent_selected=bind(E / 'root/selected-parent-observation.json'))
with (E / 'root/python-validation.json').open('x') as f:
    json.dump(result, f, indent=2)
    f.write('\n')
print(json.dumps(result))
