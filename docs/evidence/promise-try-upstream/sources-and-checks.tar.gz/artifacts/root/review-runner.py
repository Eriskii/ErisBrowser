import ast
import hashlib
import json
import subprocess
from pathlib import Path

E = Path('/tmp/eris-promise-try-upstream-plan-1')
out = E / 'runner-root-review-1'
out.mkdir(exist_ok=True)
def bind(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
ready = E / 'runner-1/source-ready.json'
d = json.loads(ready.read_bytes())
row, = d['files']
for name in ('before', 'raw'):
    assert bind(row[name]['path']) == row[name]
before = Path(row['before']['path']).read_bytes()
after = Path(row['raw']['path']).read_bytes()
assert before == subprocess.check_output(['git', 'show', d['base'] + ':tools/test262_conformance.py'], cwd=E / 'worktree')
edits = json.loads((E / 'runner-1/edit-manifest.json').read_bytes())['edits']
forward = before.decode()
for edit in edits:
    assert forward.count(edit['before']) == 1
    forward = forward.replace(edit['before'], edit['after'], 1)
assert forward.encode() == after
inverse = after.decode()
for edit in reversed(edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'], 1)
assert inverse.encode() == before
def funcs(data):
    lines = data.decode().splitlines(keepends=True)
    return {n.name: ''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(data).body if isinstance(n, ast.FunctionDef)}
old, new = funcs(before), funcs(after)
changed = [n for n in old if old[n] != new[n]]
assert changed == ['load_corpus', 'decode_response', 'run_case', 'harness_preflight', 'main']
assert len(old) - len(changed) == 63
added = sorted(set(new) - set(old))
assert len(added) == 6 and all(n.startswith('promise_try_') for n in added)
report = dict(status='clear', reviewer_kind='root source review before candidate testing; independent peer remains required before publication',
    source=bind(ready), script=bind(__file__), exact_inverse=True, changed_old_functions=changed,
    preserved_old_functions=63, new_functions=added, findings=[], reasoning=[
        'Selected host membership activates the unchanged metadata/completion admission and ERJS2 encoder. The Try ERJR3 guard precedes shared decoding, which keeps default seven-identity arity.',
        'Selected run_case invokes classify_promise directly. Existing profile routing and all generic classifiers remain unchanged.',
        'The canonical gate checks all94 unique mode identities, exact result keys, helper/source fingerprints and prerequisite records. It revalidates raw observations and reclassifies; cached verified flags alone cannot establish health.',
        'New semantic rows require empty harness plus exact completion counters. Acyclic canonical dependencies propagate failures. Main uses this selected gate and inherited host blocking before dispatch/baseline recording.'
    ])
(out / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(bind(out / 'review.json')))
