from pathlib import Path
import hashlib
import json
import subprocess
import sys

E = Path(__file__).resolve().parents[1]
D = Path('/tmp/eris-promise-try-runtime-plan-1')
profiles = [('aggregate-error', 'aggregate-error'), ('existing', 'promise-methods-async'),
            ('all', 'promise-all'), ('race', 'promise-race'), ('settled', 'promise-all-settled'),
            ('any', 'promise-any'), ('with-resolvers', 'promise-with-resolvers')]
binaries = dict(ordinary='9d941548f9c327fb57ae80450111b33d7f8fa0812d47c590da67dba1b24c505b',
                host='9655090e7ffeeeef80c0adccf96bf1276bf80f6f164213d6afd965adb3480ab6')
rows = []
for short, profile in profiles:
    kind = 'ordinary' if short in ('aggregate-error', 'with-resolvers') else 'host'
    binary = D / f'eris-js-{kind}-1'
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == binaries[kind]
    command = [sys.executable, '-B', str(E / 'run-tool.py'), 'upstream-' + short + '-1',
               sys.executable, '-B', 'tools/test262_conformance.py', '--binary', str(binary),
               '--profile', profile, '--output', str(E / f'upstream-{short}-1.json'),
               '--baseline', f'tests/conformance/test262-{profile}-current.json']
    subprocess.run(command, check=True)
    path = E / f'upstream-{short}-1.json'
    report = json.loads(path.read_bytes())
    parent = json.loads((E / 'replay-parent' / path.name).read_bytes())
    for field in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
                  'corpus_manifest_sha256', 'counts', 'mode_cases', 'binary_sha256'):
        assert report[field] == parent[field], (short, field)
    assert report['harness_preflight_passed'] and not report['regressions'] and not report['improvements']
    assert all(row['verified'] is True for row in report['harness_preflight'])
    assert report['binary_sha256'] == binaries[kind]
    rows.append(dict(name=short, cases=len(report['cases']), controls=len(report['harness_preflight']),
                     counts=report['counts'], sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                     binary_sha256=report['binary_sha256']))
assert sum(row['cases'] for row in rows) == 1300
assert sum(row['controls'] for row in rows) == 546
record = dict(status='pass', profiles=rows, cases=1300, controls=546,
              comparison='Complete case/control arrays, policies, corpus and reused published binary identities exact. No prior baseline changes.')
with (E / 'root/profile-validation.json').open('x') as f:
    json.dump(record, f, indent=2)
    f.write('\n')
print(json.dumps(record))
