import json
from pathlib import Path
import subprocess
B=Path(__file__).resolve().parents[1];W=B/'worktree';MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c';P=B/'publication';P.mkdir(exist_ok=True);record_path=B/'root/github-publication.json';assert not record_path.exists()
verified=json.loads((B/'root/publication-verification.json').read_bytes());assert verified['status']=='verified' and verified['path_count']==77

def git(directory,*args):
 r=subprocess.run(['git',*args],cwd=directory,text=True,capture_output=True,check=True);return r.stdout.strip()

assert git(MAIN,'branch','--show-current')=='main'
assert git(MAIN,'rev-parse','HEAD')==git(W,'rev-parse','HEAD')==BASE
assert git(MAIN,'status','--porcelain')=='' and git(W,'diff','--cached','--name-only')==''
paths=verified['expected_commit_paths'];pathspec=P/'paths.nul';pathspec.write_bytes(b'\0'.join(p.encode() for p in paths)+b'\0')
git(W,'add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul')
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
import hashlib
expected_hashes=json.loads((B/'source-final.json').read_bytes())['source_sha256']
for row in json.loads((B/'documentation-1/source-ready.json').read_bytes())['files']:
 expected_hashes[row['relative_path']]=row['raw']['sha256']
for key in ('archive','manifest'):
 row=verified[key];expected_hashes[str(Path(row['path']).relative_to(W))]=row['sha256']
for path in paths:
 staged=subprocess.check_output(['git','show',':'+path],cwd=W)
 assert hashlib.sha256(staged).hexdigest()==expected_hashes[path],path
 assert staged==(W/path).read_bytes(),path
whitespace=json.loads((B/'root/whitespace-qualification.json').read_bytes())
check=subprocess.run(['git','diff','--cached','--check'],cwd=W,text=True,capture_output=True)
assert check.returncode==whitespace['expected_staged_exit'] and check.stdout==whitespace['expected_staged_stdout'] and not check.stderr
import hashlib
for row in whitespace['files']:
 assert hashlib.sha256((W/row['path']).read_bytes()).hexdigest()==row['sha256']
(P/'whitespace-check.json').write_text(json.dumps({'status':'exact retained upstream diagnostics only','returncode':check.returncode,'stdout':check.stdout},indent=2)+'\n')
message=P/'commit-message.txt';message.write_text('Gate complete pinned Promise.try conformance\n\nAuthenticate all 15 original upstream files and eight helpers, preserving all\n30 strict/sloppy cases. Require canonical raw completion evidence under a\n94-control gate before case dispatch or baseline recording.\n\nValidate 31 new groups and all 683 Python tests. Reuse published custom-engine\nbinaries: 24 Try modes pass and six remain unsupported for class syntax. All\n1300 case and 546 control records across seven prior profiles remain exact.\n')
(P/'commit.log').write_text(git(W,'commit','-F',str(message))+'\n');commit=git(W,'rev-parse','HEAD')
assert git(W,'status','--porcelain')==''
assert set(git(W,'diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())==set(paths)
record={'status':'committed','base':BASE,'commit':commit,'repository':'https://github.com/Eriskii/ErisBrowser','paths':len(paths)};record_path.write_text(json.dumps(record,indent=2)+'\n')
(P/'merge.log').write_text(git(MAIN,'merge','--ff-only','promise-try-upstream')+'\n')
assert git(MAIN,'rev-parse','HEAD')==commit and git(MAIN,'status','--porcelain')==''
(P/'push.log').write_text(git(MAIN,'push','origin','main')+'\n');remote=git(MAIN,'ls-remote','origin','refs/heads/main').split()[0];assert remote==commit
record.update(status='pushed',remote_head=remote,ci='not yet observed');record_path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
