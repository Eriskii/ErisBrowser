import hashlib
import json
import subprocess
from pathlib import Path

E = Path('/tmp/eris-promise-try-upstream-plan-1')
W = E / 'worktree'
def bind(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def verify(row):
    assert bind(row['path']) == {k: row[k] for k in ('path', 'bytes', 'sha256')}

reviews = []
for name in ['importer-review-1', 'runner-root-review-1', 'preservation-review-1']:
    p = E / name / 'review.json'
    assert json.loads(p.read_bytes())['status'] == 'clear'
    reviews.append(bind(p))
assert (E / 'validation/python-selected-parent-1.json').exists()
parent = json.loads((E / 'source-parent.json').read_bytes())
for rel, sha in parent['source_sha256'].items():
    assert bind(W / rel)['sha256'] == sha, rel
new_tests = json.loads((E / 'root/test-contract-import-1.json').read_bytes())
for row in new_tests['files']:
    verify(row)
inputs, holds = [], []
for name in ['importer-1', 'runner-1', 'migrations-1', 'ci-1']:
    path = E / name / 'source-ready.json'
    hold = json.loads(path.read_bytes())
    holds.append(bind(path))
    for row in hold['files']:
        rel = row['relative_path']
        verify(row['before'])
        verify(row['raw'])
        assert (W / rel).read_bytes() == Path(row['before']['path']).read_bytes()
        inputs.append((rel, row['raw']))
assert len(inputs) == 27 and len({rel for rel, _ in inputs}) == 27
for rel, raw in inputs:
    (W / rel).write_bytes(Path(raw['path']).read_bytes())
record = dict(reviews=reviews, holds=holds,
              files=[dict(relative_path=rel, held=raw, imported=bind(W / rel)) for rel, raw in inputs])
(E / 'root/candidate-import-1.json').write_text(json.dumps(record, indent=2) + '\n')
sources = dict(parent['source_sha256'])
for rel, _ in inputs:
    sources[rel] = bind(W / rel)['sha256']
for row in new_tests['files']:
    sources[row['relative_path']] = row['sha256']
assert len(sources) == 1819
candidate = dict(base=parent['base'], scope='Pinned Promise.try tooling/profile selected inputs before measured baseline. Cumulative selected-input inventory, not complete build graph. Rust/runtime/Cargo/build settings unchanged; published binaries reused exactly.',
                 source_sha256=dict(sorted(sources.items())))
(E / 'source-candidate-1.json').write_text(json.dumps(candidate, indent=2) + '\n')
print(json.dumps(dict(imported=len(inputs), source=bind(E / 'source-candidate-1.json'))))
