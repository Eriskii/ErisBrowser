import hashlib
import json
import subprocess
from pathlib import Path

E = Path(__file__).resolve().parents[1]
W = E / 'worktree'
def bind(p):
    p = Path(p)
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
ready = E / 'documentation-2/source-ready.json'
docs = json.loads(ready.read_bytes())
peer = E / 'documentation-review-1/review.json'
assert json.loads(peer.read_bytes())['status'] == 'clear'
assert len(docs['files']) == 6
for row in docs['files']:
    rel = row['relative_path']
    assert bind(row['raw']['path']) == row['raw']
    if row['before']:
        assert bind(row['before']['path']) == row['before']
        assert (W / rel).read_bytes() == Path(row['before']['path']).read_bytes()
        assert (W / rel).read_bytes() == subprocess.check_output(['git', 'show', docs['base'] + ':' + rel], cwd=W)
    else:
        assert not (W / rel).exists()
before_validation = (W / 'docs/VALIDATION.md').read_bytes()
after_validation = Path(next(r['raw']['path'] for r in docs['files'] if r['relative_path'] == 'docs/VALIDATION.md')).read_bytes()
assert before_validation.split(b'\n', 1)[1] in after_validation
runtime = subprocess.check_output(['git', 'show', docs['base'] + ':docs/promise-try.md'], cwd=W)
assert (W / 'docs/promise-try.md').read_bytes() == runtime
for row in docs['files']:
    (W / row['relative_path']).write_bytes(Path(row['raw']['path']).read_bytes())
record = dict(status='six reviewed docs imported exactly', source=bind(ready), peer=bind(peer),
              files=[dict(relative_path=r['relative_path'], **bind(W / r['relative_path'])) for r in docs['files']],
              historical_validation_body_exact=True, runtime_chapter_exact=True)
(E / 'root/documentation-import-1.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(bind(E / 'root/documentation-import-1.json')))
