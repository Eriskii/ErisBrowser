import hashlib,json,subprocess,tarfile
from pathlib import Path
B=Path(__file__).resolve().parents[1];W=B/'worktree';E=W/'docs/evidence/promise-try-upstream'
def bind(path):
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
manifest=json.loads((E/'manifest.json').read_bytes());archive=E/manifest['archive']['path'];assert bind(archive)['sha256']==manifest['archive']['sha256']
selected=json.loads((B/'root/evidence-selection.json').read_bytes())['members'];assert manifest['members']==selected
with tarfile.open(archive,'r:gz') as t:
 assert t.getnames()==[r['path'] for r in selected]
 for r in selected:
  m=t.getmember(r['path']);assert m.isfile() and not m.issym() and not m.islnk();data=t.extractfile(m).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256'];assert data==Path(r['origin']).read_bytes(),r['origin']
final=json.loads((B/'source-final.json').read_bytes())['source_sha256'];parent=json.loads((B/'source-parent.json').read_bytes())['source_sha256']
for path,sha in final.items():assert bind(W/path)['sha256']==sha,path
sources={p for p,sha in final.items() if parent.get(p)!=sha}
docs=json.loads((B/'documentation-1/source-ready.json').read_bytes())['files'];docpaths={r.get('relative',r.get('relative_path',r.get('path'))) for r in docs}
for r in docs:assert bind(W/r.get('relative',r.get('relative_path',r.get('path'))))['sha256']==r['raw']['sha256']
expected=sources|docpaths|{'docs/evidence/promise-try-upstream/manifest.json','docs/evidence/promise-try-upstream/sources-and-checks.tar.gz'}
assert len(sources)==69 and len(docpaths)==6 and len(expected)==77
changed=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines());changed.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines());assert changed==expected,{'extra':sorted(changed-expected),'missing':sorted(expected-changed)}
subprocess.run(['git','diff','--check'],cwd=W,check=True)
record={'status':'verified','expected_commit_paths':sorted(expected),'path_count':len(expected),'source_paths':len(sources),'documentation_paths':len(docpaths),'evidence_paths':2,'archive':bind(archive),'manifest':bind(E/'manifest.json'),'members':len(selected),'every_archive_member_equals_origin':True,'every_selected_source_equals_final_inventory':True}
with (B/'root/publication-verification.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='expected_commit_paths'}))
