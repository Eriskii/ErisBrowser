import ast
import hashlib
import json
import subprocess
from pathlib import Path

E = Path('/tmp/eris-promise-try-upstream-plan-1')
out = E / 'importer-review-1'
out.mkdir(exist_ok=True)
base = '15db31c76f5a2f259deffadbf0f95e212a5fa61c'

def stamp(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

checked = []
def refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and value['path'].startswith('/'):
            assert stamp(value['path']) == {k: value[k] for k in ('path', 'bytes', 'sha256')}, value
            checked.append(value['path'])
        for child in value.values():
            refs(child)
    elif isinstance(value, list):
        for child in value:
            refs(child)

ready = json.loads((E / 'importer-1/source-ready.json').read_bytes())
refs(ready)
row, = ready['files']
before = Path(row['before']['path']).read_bytes()
after = Path(row['raw']['path']).read_bytes()
published = subprocess.check_output(['git', 'show', base + ':tools/import_test262.py'], cwd=E / 'worktree')
assert before == published
edits = json.loads((E / 'importer-1/edit-manifest.json').read_bytes())['edits']
rebuilt = before.decode()
for edit in edits:
    assert rebuilt.count(edit['before']) == 1, edit['label']
    rebuilt = rebuilt.replace(edit['before'], edit['after'], 1)
assert rebuilt.encode() == after
inverse = after.decode()
for edit in reversed(edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'], 1)
assert inverse.encode() == before

def functions(data):
    lines = data.decode().splitlines(keepends=True)
    return {n.name: ''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(data).body
            if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))}

old, new = functions(before), functions(after)
assert old.keys() == new.keys()
changed = [n for n in old if old[n] != new[n]]
assert changed == ['profile_tree_inventory', 'import_corpus']
package = json.loads((E / 'importer-contract-1/package-ready.json').read_bytes())
root = E / 'importer-contract-1/corpus/tests/upstream/test262-promise-try'
for item in package['all_files']:
    got = stamp(root / item['path'])
    assert (got['bytes'], got['sha256']) == (item['bytes'], item['sha256'])
assert {p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()} == {r['path'] for r in package['all_files']}
assert len(package['all_files']) == 33
report = dict(status='clear', base=base, production=stamp(E / 'importer-1/source-ready.json'),
    independent_package=stamp(E / 'importer-contract-1/package-ready.json'),
    reviewer=stamp(__file__), checks=dict(bound_references=len(checked), edit_pairs=len(edits),
        exact_forward_and_inverse=True, old_function_count=len(old), changed_old_functions=changed,
        unchanged_old_functions=11, complete_package_files=33),
    findings=[], review=[
        'The new profile selects the complete pinned 15-body Promise/try leaf through the unchanged bounded root-linked Git walker. The selected count and prefix are literal guards; descendant trees are refused after authentication.',
        'All source bytes are checked against authenticated Git blobs before parsing metadata. The original seven-helper closure must match before the sole guard-only promiseHelper.js is added; all eight helpers and two legal files are checked against root-linked blobs before output.',
        'Edits add selected constants/table entries and selected branches only. All eleven other old function bodies are byte-identical, including parsing, fetch bounds, shared proof readers and CLI.',
        'The held manifest scope matches the independently frozen package. No original metadata, helper or upstream source is edited. Runtime outcomes remain unmeasured.'
    ], qualification='Source review and stdlib/read-only Git checks only; root execution remains separate.')
(out / 'review.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(stamp(out / 'review.json')))
