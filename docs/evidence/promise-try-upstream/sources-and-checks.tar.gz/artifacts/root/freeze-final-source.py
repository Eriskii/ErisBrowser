import hashlib
import json
import subprocess
from pathlib import Path

E = Path(__file__).resolve().parents[1]
W = E / 'worktree'
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
parent = json.loads((E / 'source-parent.json').read_bytes())
candidate = json.loads((E / 'source-candidate-1.json').read_bytes())
source = dict(candidate['source_sha256'])
for rel, sha in source.items():
    assert bind(W / rel)['sha256'] == sha, rel
baseline = 'tests/conformance/test262-promise-try-current.json'
assert baseline not in source
source[baseline] = bind(W / baseline)['sha256']
expected = {rel for rel, sha in source.items() if parent['source_sha256'].get(rel) != sha}
assert len(expected) == 69 and len(source) == 1820
changed = set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=W, text=True).splitlines())
added = set(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W, text=True).splitlines())
assert changed | added == expected, (changed | added) ^ expected
assert len(changed) == 27 and len(added) == 42
assert not any(rel.startswith(('src/', 'crates/', 'assets/')) or rel in {'Cargo.toml', 'Cargo.lock', 'build.rs'} for rel in expected)
final = dict(base=parent['base'], scope='Pinned Promise.try profile tooling, frozen independent tests/oracles, complete upstream corpus and measured baseline. Cumulative selected-input inventory, not complete build graph. All tracked changes exhaustively checked against these69 paths before documentation; Rust/Cargo/build/runtime inputs unchanged and published adapter binaries reused.',
             source_sha256=dict(sorted(source.items())))
(E / 'source-final.json').write_text(json.dumps(final, indent=2) + '\n')
report = dict(status='pass', selected_inputs=1820, changed_existing=27, added=42,
              all_tracked_changes_accounted=True, rust_cargo_build_runtime_unchanged=True,
              source=bind(E / 'source-final.json'), candidate=bind(E / 'source-candidate-1.json'),
              candidate_to_final_only_added_baseline=baseline, changed_paths=sorted(expected))
(E / 'root/source-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
