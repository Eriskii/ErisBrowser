import hashlib
import json
from pathlib import Path

E = Path(__file__).resolve().parents[1]
def bind(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def read(name):
    return json.loads((E / name).read_bytes())
for name in ['python-validation', 'try-validation', 'profile-validation', 'source-validation']:
    assert read('root/' + name + '.json')['status'] == 'pass'
peers = ['importer-review-1', 'runner-root-review-1', 'runner-review-1', 'layout-contract-review-1',
         'controls-review-1', 'preservation-review-1']
for name in peers:
    assert read(name + '/review.json')['status'] == 'clear'
receipts = []
for p in sorted((E / 'validation').glob('*.json')):
    d = json.loads(p.read_bytes())
    log = E / 'validation' / d['log']
    assert bind(log)['sha256'] == d['sha256']
    assert d['exit'] == (1 if p.stem == 'python-selected-parent-1' else 0), p
    receipts.append(dict(receipt=bind(p), log=bind(log), exit=d['exit']))
assert len(receipts) == 13
ci = read('root/prior-ci-observation-1.json')
assert ci['headSha'] == '15db31c76f5a2f259deffadbf0f95e212a5fa61c'
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 11
assert all(job['conclusion'] == 'success' for job in ci['jobs'])
ledger = dict(status='pass', scope='Complete validation for selected Promise.try upstream tooling checkpoint; browser goal remains incomplete',
    base=ci['headSha'], changed_source_paths=69,
    inventory=dict(production_files=2, new_test_modules=5, new_test_groups=31, new_oracles=3,
        historical_test_paths=24, historical_selection_edits=47, retained_affected_parent_groups=295,
        ci_steps_added=1, corpus_files=33, baseline_files=1),
    selection=bind(E / 'root/selection-1.json'),
    source=dict(parent=bind(E / 'source-parent.json'), candidate=bind(E / 'source-candidate-1.json'),
        final=bind(E / 'source-final.json'), closure=bind(E / 'root/source-validation.json'),
        selected_inputs=1820, qualification='Cumulative selected-input inventory, not full build graph; exhaustive tracked-diff check accounts for all69 changed/added paths. Rust/Cargo/build/runtime inputs unchanged. Candidate-to-final adds only measured baseline; all candidate input hashes remain exact.'),
    python=read('root/python-validation.json'),
    parent_selected=read('root/selected-parent-observation.json'),
    binary_reuse=bind(E / 'root/binary-reuse-1.json'),
    upstream=read('root/try-validation.json'),
    preserved_profiles=read('root/profile-validation.json'),
    preservation=dict(old_policies=60, protected_function_bodies=74,
        importer_bodies=11, runner_bodies=63, published_tables_and_feature_maps_exact=True,
        old_baselines_unchanged=True, regression_cases=1300, regression_controls=546),
    authenticated_corpus=dict(revision='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd',
        package=bind(E / 'importer-contract-1/package-ready.json'),
        independent_proof=bind(E / 'importer-contract-1/authentication.json'),
        source_files=15, mode_cases=30, sync_modes=22, async_modes=8, helpers=8,
        compareArray_qualification='compareArray.js is the retained243-byte compatibility shim; executable global compareArray and assert.compareArray come from assert.js.',
        offline_replay='The actual new importer test reconstructs all33 bytes-identical package files using mocked fetch of frozen originals; it passes in focused and full candidate suites.'),
    source_reviews=[bind(E / name / 'review.json') for name in peers],
    validation_receipts=receipts,
    prior_ci=dict(receipt=bind(E / 'root/prior-ci-observation-1.json'), run=ci['databaseId'],
                  url=ci['url'], all_11_jobs='success', applies_to='published parent15db only'),
    bookkeeping=[bind(E / 'root/try-check-orchestration.json')],
    qualifications=[
        '31 new groups passed on the first candidate. Parent comparison was6 passed/25 nonpassing groups; unittest60 failures46 errors include subtest observations and must not be presented as group counts.',
        'Try actual24 passed/6 unsupported/0 failed modes and94 verified controls are a complete pinned directory selection, not full ECMAScript or browser compatibility. The six excluded modes declare class in three retained originals.',
        'No Rust build/test, hardware test or performance benchmark was rerun for this tooling-only checkpoint. The exact previously built ordinary and test262-host executables were reused.',
        'Prior seven-profile1300 case and546 control records, policies, corpus and binary identities remain exact. Their existing failed/unsupported outcomes remain; no old baseline was reset.',
        'Current-checkpoint remote CI is configured but not yet observed. Full browser security, standards coverage and Chromium performance target remain unfulfilled.'
    ])
with (E / 'root/final-validation.json').open('x') as f:
    json.dump(ledger, f, indent=2)
    f.write('\n')
print(json.dumps(bind(E / 'root/final-validation.json')))
