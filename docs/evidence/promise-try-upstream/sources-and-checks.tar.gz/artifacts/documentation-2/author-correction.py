from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import re

E = Path('/tmp/eris-promise-try-upstream-plan-1')
OLD = E / 'documentation-1'
NEW = E / 'documentation-2'

def sha(data): return hashlib.sha256(data).hexdigest()
def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
def load(path): return json.loads(path.read_bytes())
def put(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    return bind(path)
def put_json(path, value): return put(path, (json.dumps(value, indent=2) + '\n').encode())
def checked(row):
    path = Path(row['path'])
    assert bind(path) == row
    return path.read_bytes()

original = load(OLD / 'source-ready.json')
assert bind(OLD / 'source-ready.json')['sha256'] == '5c86b2a9c67f01a392eda95c7a4a2bd2967939c5014fe1529d7cac242f0555d9'
chapter = 'docs/promise-try-upstream.md'
old_sentence = b'and eight require authenticated async completion; all eight async modes pass.\n'
new_sentence = (b'and eight require authenticated async completion. Six async modes pass and two\n'
                b'are excluded for `class`; 18 synchronous modes pass and four are excluded.\n')
rows = []
changed = []
for row in original['files']:
    rel = row['relative_path']
    before = checked(row['before']) if row['before'] else b''
    prior = checked(row['raw'])
    raw = prior
    if rel == chapter:
        assert raw.count(old_sentence) == 1
        raw = raw.replace(old_sentence, new_sentence, 1)
        assert raw.replace(new_sentence, old_sentence, 1) == prior
        changed.append(rel)
        put(NEW / 'correction.diff', ''.join(difflib.unified_diff(
            prior.decode().splitlines(True), raw.decode().splitlines(True),
            fromfile='documentation-1/' + rel, tofile='documentation-2/' + rel)).encode())
    else:
        assert raw == prior
    before_binding = put(NEW / 'before' / rel, before) if row['before'] else None
    raw_binding = put(NEW / 'raw' / rel, raw)
    diff_binding = put(NEW / 'diff' / (rel + '.diff'), ''.join(difflib.unified_diff(
        before.decode().splitlines(True), raw.decode().splitlines(True),
        fromfile=rel if row['before'] else '/dev/null', tofile=rel)).encode())
    rows.append({'relative_path':rel,'before':before_binding,'raw':raw_binding,'diff':diff_binding})
assert changed == [chapter] and len(rows) == 6

report_path = E / 'upstream-try-1.json'
replay_path = E / 'upstream-try-check-1.json'
report = load(report_path); replay = load(replay_path)
assert report['cases'] == replay['cases'] and report['harness_preflight'] == replay['harness_preflight']
assert len(report['cases']) == 30 and len(report['harness_preflight']) == 94
counts = {'async':Counter(),'sync':Counter()}
source_bindings = {}; observations = []
for row in report['cases']:
    source = E / 'importer-contract-1/corpus/tests/upstream/test262-promise-try' / row['file']
    data = source.read_bytes()
    assert sha(data) == row['source_sha256']
    front = re.search(rb'/\*---(.*?)---\*/', data, re.S).group(1).decode()
    def inline(key):
        found = re.search(r'^' + key + r':\s*\[([^\]]*)\]\s*$', front, re.M)
        return [x.strip() for x in found.group(1).split(',') if x.strip()] if found else []
    flags, features = inline('flags'), inline('features')
    policy = 'async' if 'async' in flags else 'sync'
    counts[policy][row['status']] += 1
    if row['status'] == 'unsupported':
        assert 'class' in features and row['reason'] == 'unimplemented declared features: class'
        assert 'observation' not in row
    else:
        assert row['status'] == 'passed' and 'class' not in features
        assert row['observation']['completion']['policy'] == int(policy == 'async')
    source_bindings[str(source)] = bind(source)
    observations.append({'id':row['id'],'flags':flags,'features':features,'policy':policy,
                         'status':row['status'],'source_sha256':row['source_sha256'],
                         'case_sha256':row['case_sha256']})
assert counts == {'async':{'passed':6,'unsupported':2},'sync':{'passed':18,'unsupported':4}}
assert Counter(x['status'] for x in report['cases']) == {'passed':24,'unsupported':6}
assert all(x['verified'] for x in report['harness_preflight'])
assert bind(E / 'root/final-validation.json') == original['final_validation']
assert bind(E / 'source-final.json') == original['source_final']
title = b'# Validation record\n\n'
assert (NEW/'raw/docs/VALIDATION.md').read_bytes().endswith((NEW/'before/docs/VALIDATION.md').read_bytes()[len(title):])
assert (OLD/'before/docs/promise-try.md').read_bytes() == (E/'worktree/docs/promise-try.md').read_bytes()

checks = put_json(NEW / 'claims-and-checks.json', {
    'status':'clear after narrow documentation correction',
    'superseded_hold':bind(OLD/'source-ready.json'),
    'original_claim_checks':bind(OLD/'claims-and-checks.json'),
    'finding':'The first chapter incorrectly said all eight async modes passed. Its original check counted async metadata but did not assert the status split. The peer identified the two async class exclusions in ctx-ctor-for-error.js.',
    'correction':'Only the chapter sentence changes: async6passed2unsupported and sync18passed4unsupported. Aggregate24passed6unsupported and94controls remain exact.',
    'report':bind(report_path),'replay':bind(replay_path),
    'sources':list(source_bindings.values()),'rows':observations,
    'counts':counts,'changed_raw_paths':changed,'other_five_raw_files_exact':True,
    'chapter_inverse_restores_original':True,'before_snapshots_exact':True,
    'historical_validation_body_exact':True,'runtime_chapter_exact':True,
    'final_ledger':original['final_validation'],'source_final':original['source_final'],
    'scope':'External documentation only. No changes to the frozen first hold, live source, tests, expectations or observed reports.'})
links = put(NEW / 'links.json', (OLD/'links.json').read_bytes())
seal = put_json(NEW / 'source-ready.json', {
    'status':'ready for independent review and root import', 'base':original['base'],
    'files':rows,'supersedes':bind(OLD/'source-ready.json'),
    'correction':bind(NEW/'correction.diff'),'claims_and_checks':checks,'links':links,
    'final_validation':original['final_validation'],'source_final':original['source_final'],
    'parent_snapshot':original['parent_snapshot'], 'author':bind(NEW/'author-correction.py'),
    'scope':'Full six-file final documentation hold. Only the chapter async/sync outcome sentence differs from hold1; all other raw bytes, historical validation and runtime chapter are exact.',
    'qualification':'Observed async6/2 and sync18/4, overall24/6 with94controls;683Python; complete new30/94 and old1300/546 arrays. Existing evidence and source assertions retained.'})
print(json.dumps(seal))
