"""Independent evidence/source review. Stdlib and read-only Git; no project imports."""
from pathlib import Path
import ast, collections, hashlib, json, re, subprocess

E=Path('/tmp/eris-promise-try-upstream-plan-1'); W=E/'worktree'; O=E/'validation-review-1'
D=Path('/tmp/eris-promise-try-runtime-plan-1')
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
def sha(v): return hashlib.sha256(v).hexdigest()
def load(p): return json.loads(Path(p).read_bytes())
def bind(p):
    p=Path(p); v=p.read_bytes(); return dict(path=str(p),bytes=len(v),sha256=sha(v))
def verify(v):
    if isinstance(v,dict):
        if {'path','bytes','sha256'}<=v.keys():
            a=bind(v['path']); assert (a['bytes'],a['sha256'])==(v['bytes'],v['sha256']),v['path']
        for x in v.values(): verify(x)
    elif isinstance(v,list):
        for x in v: verify(x)
def git(*args): return subprocess.check_output(['git',*args],cwd=W)
ledger=load(E/'root/final-validation.json')
assert bind(E/'root/final-validation.json')['sha256']=='62e129f47ef34bbd311594f5167979d5b589210153b7212cd3c58ce4e004f4a4'
verify(ledger)
for row in ledger['validation_receipts']:
    r=load(row['receipt']['path']); log=Path(row['log']['path'])
    assert r['exit']==row['exit'] and r['sha256']==sha(log.read_bytes())
    assert r['log']==log.name
    assert r['exit']==(1 if log.name=='python-selected-parent-1.log' else 0)
assert len(ledger['validation_receipts'])==13
def roster(name,count):
    text=(E/'validation'/f'{name}.log').read_text()
    rows=re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. ok$',text,re.M)
    assert len(rows)==len(set(rows))==count and re.search(rf'^Ran {count} tests in ',text,re.M)
    assert text.rstrip().endswith('OK'); return set(rows)
parent=roster('python-parent-1',652); selected=roster('python-selected-candidate-1',31); full=roster('python-full-1',683)
assert not parent&selected and full==parent|selected
assert selected==set(load(E/'root/validation-plan.json')['new_groups'])
prior=(E/'validation/python-selected-parent-1.log').read_text()
rows=dict(re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. (.*)$',prior,re.M))
assert set(rows)==selected and sum(v=='ok' for v in rows.values())==6
assert 'FAILED (failures=60, errors=46)' in prior

parent_source=load(E/'source-parent.json')['source_sha256']
candidate=load(E/'source-candidate-1.json')['source_sha256']
final=load(E/'source-final.json')['source_sha256']
baseline_rel='tests/conformance/test262-promise-try-current.json'
assert len(parent_source)==1778 and len(candidate)==1819 and len(final)==1820
assert set(final)-set(candidate)=={baseline_rel} and {k:final[k] for k in candidate}==candidate
for rel,h in final.items(): assert sha((W/rel).read_bytes())==h,rel
expected={rel for rel,h in final.items() if parent_source.get(rel)!=h}
tracked=set(git('diff','--name-only',BASE).decode().splitlines())
untracked=set(git('ls-files','--others','--exclude-standard').decode().splitlines())
assert len(expected)==69 and len(tracked)==27 and len(untracked)==42
assert tracked|untracked==expected
assert not any(r.startswith(('src/','crates/','assets/')) or r in {'Cargo.toml','Cargo.lock','build.rs'} for r in expected)
tree=git('ls-tree','-r','-z',BASE).split(b'\0'); entries=[]
for item in tree:
    if item:
        meta,path=item.split(b'\t',1);mode,kind,oid=meta.decode().split();entries.append((path.decode(),kind,oid))
assert all(kind=='blob' for _,kind,_ in entries)
assert tracked<={p for p,_,_ in entries}
# Hash every tracked blob independently of Git's index/stat cache.
old_unchanged=0; old_upstream=0; old_conformance=0; rust_inputs=0
for rel,_,oid in entries:
    data=(W/rel).read_bytes()
    if rel in tracked: continue
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==oid,rel
    old_unchanged+=1
    old_upstream+=rel.startswith('tests/upstream/')
    old_conformance+=rel.startswith('tests/conformance/')
    rust_inputs+=(rel.startswith(('src/','crates/')) or rel in {'Cargo.toml','Cargo.lock','build.rs'})

# Every changed source byte comes from the independently frozen holds or baseline.
composed={}
for hold in ['importer-1','runner-1','migrations-1','ci-1','importer-contract-1','protocol-contract-1','controls-contract-1','preservation-contract-1']:
    seal=load(E/hold/'source-ready.json')
    for f in seal['files']:
        rel=f.get('relative_path', f.get('relative')); raw=Path(f['raw']['path']).read_bytes()
        assert (W/rel).read_bytes()==raw and final[rel]==sha(raw),rel
        assert rel not in composed; composed[rel]=hold
package=E/'importer-contract-1/corpus/tests/upstream/test262-promise-try'
files=sorted(p for p in package.rglob('*') if p.is_file());assert len(files)==33
for p in files:
    rel='tests/upstream/test262-promise-try/'+str(p.relative_to(package))
    assert (W/rel).read_bytes()==p.read_bytes() and rel not in composed
    composed[rel]='authenticated-package'
composed[baseline_rel]='measured-baseline'
assert set(composed)==expected

preservation=load(E/'preservation-contract-1/raw/tools/promise-try-preservation-oracle.json')
preserved=0
for rel,names in preservation['unchanged_functions'].items():
    src=(W/rel).read_text(); nodes={n.name:n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)}
    for name,h in names.items(): assert sha(ast.get_source_segment(src,nodes[name]).encode())==h;preserved+=1
assert preserved==74 and len(preservation['policies_at_timeout3'])==60
for value in preservation['policies_at_timeout3'].values():
    assert sha(json.dumps(value['policy'],sort_keys=True).encode())==value['sha256']

reuse=load(E/'root/binary-reuse-1.json');verify(reuse)
bins={row['kind']:row['binary']['sha256'] for row in reuse['binaries']}
for row in reuse['binaries']:
    meta=load(row['retained_build_metadata']['path']); assert meta['sha256']==row['binary']['sha256']
    assert meta['toolchain']=='1.88.0' and meta['features']==(['test262-host'] if row['kind']=='host' else [])
    build=load(meta['build']);assert build['exit']==0

report=load(E/'upstream-try-1.json'); replay=load(E/'upstream-try-check-1.json'); baseline=load(W/baseline_rel)
assert report['counts']=={'passed':24,'unsupported':6} and report['source_tests']==report['source_files']==15
assert report['mode_cases']==len(report['cases'])==30 and report['fixture_files']==[] and report['negative_source_tests']==0
assert report['harness_preflight_passed'] is True and report['binary_sha256']==bins['host']
keys=['cases','harness_preflight','counts','runner_policy','runner_policy_sha256','corpus_manifest_sha256','binary_sha256','mode_cases','harness_preflight_passed']
for key in keys: assert report[key]==replay[key],key
assert not replay['regressions'] and not replay['improvements']
assert baseline==dict(revision=report['revision'],corpus_manifest_sha256=report['corpus_manifest_sha256'],runner_policy_sha256=report['runner_policy_sha256'],binary_sha256=report['binary_sha256'],cases={r['id']:{k:r[k] for k in ['status','case_sha256','source_sha256']} for r in report['cases']})
oracle=load(E/'importer-contract-1/raw/tools/test262-promise-try-import-oracle.json')
assert [{k:r[k] for k in ['id','case_sha256']} for r in report['cases']]==oracle['case_identities']
assert report['corpus_manifest_sha256']==oracle['manifest_sha256']
for r in report['cases']:
    assert r['source_sha256']==sha((W/'tests/upstream/test262-promise-try'/r['file']).read_bytes())
    if r['status']=='unsupported': assert r['reason']=='unimplemented declared features: class' and 'class' in oracle['metadata'][r['file']]['features']
    else: assert r['status']=='passed' and r['observation']['status']=='complete'

control=load(E/'controls-contract-1/raw/tools/promise-try-controls-oracle.json')
records=control['records']; assert len(records)==len(report['harness_preflight'])==94
index={(r['name'],r['mode']):r for r in records}; diagnostic_differences=[]
for a,b in zip(report['harness_preflight'],records):
    assert a['name']==b['name'] and a['expected']==b['expected'] and a['verified'] is True
    result=a['result'];assert all(result[k]==b[k] for k in ['id','file','mode','case_sha256','source_sha256'])
    assert result['expected_negative'] is None
    assert result['status']==('passed' if b['expected']=='passed' else 'resource' if b['expected']=='resource' else 'failed')
    refs=[]
    for dep in b['prerequisites']:
        target=index[tuple(dep)];refs.append(dict(name=target['name'],mode=target['mode'],verified=True,case_sha256=target['case_sha256'],source_sha256=target['source_sha256']))
    assert a['prerequisites']==refs
    obs=result['observation'];mock=b['mock_observation']
    if obs!=mock:
        assert {k:v for k,v in obs.items() if k!='message'}=={k:v for k,v in mock.items() if k!='message'}
        assert mock['message']=='marker' and obs['status'] in ['exception','resource']
        assert len(obs['message'].encode())<=16384
        diagnostic_differences.append([a['name'],result['mode']])
assert len(diagnostic_differences)==10
control_counts=dict(collections.Counter(r['result']['status'] for r in report['harness_preflight']))
assert control_counts=={'passed':42,'failed':50,'resource':2}
assert sha(json.dumps(report['runner_policy'],sort_keys=True).encode())==report['runner_policy_sha256']
assert report['runner_policy']['supported_features']==['Reflect.construct','promise-try']
assert report['runner_policy']['negative_intrinsic_errors']==['Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError']

replays=[]
for short,profile in [('aggregate-error','aggregate-error'),('existing','promise-methods-async'),('all','promise-all'),('race','promise-race'),('settled','promise-all-settled'),('any','promise-any'),('with-resolvers','promise-with-resolvers')]:
    p=E/f'upstream-{short}-1.json'; retained=E/'replay-parent'/p.name
    assert retained.read_bytes()==(D/p.name).read_bytes()
    actual=load(p); old=load(retained)
    for key in keys: assert actual[key]==old[key],(short,key)
    assert actual['harness_preflight_passed'] is True and not actual['regressions'] and not actual['improvements']
    assert all(r['verified'] is True for r in actual['harness_preflight'])
    assert actual['runner_policy']==preservation['policies_at_timeout3'][profile]['policy']
    assert actual['binary_sha256']==bins['ordinary' if short in ['aggregate-error','with-resolvers'] else 'host']
    replays.append(dict(name=short,cases=len(actual['cases']),controls=len(actual['harness_preflight']),counts=actual['counts'],report=bind(p),parent=bind(retained)))
assert sum(r['cases'] for r in replays)==1300 and sum(r['controls'] for r in replays)==546
book=load(E/'root/try-check-orchestration.json');verify(book)
assert Path(book['original']['path']).read_text().replace(book['before'],book['after'])==Path(book['corrected']['path']).read_text()
checks=dict(status='clear',ledger=bind(E/'root/final-validation.json'),source=bind(E/'source-final.json'),
    selected_inputs=1820,changed_paths=69,existing_changes=27,new_paths=42,
    tracked_blobs=len(entries),unchanged_tracked_blobs=old_unchanged,unchanged_old_upstream_files=old_upstream,
    unchanged_old_conformance_files=old_conformance,unchanged_rust_source_build_paths=rust_inputs,
    exact_frozen_hold_composition=True,baseline_only_after_candidate=True,
    parent_python=652,parent_selected_passes=6,parent_selected_nonpassing=25,
    parent_failure_observations=60,parent_error_observations=46,candidate_selected=31,full_python=683,
    exact_old_and_new_roster_union=True,protected_bodies=74,old_policies=60,
    try_counts=report['counts'],try_cases=30,try_controls=94,control_expected_status_counts=control_counts,
    exact_new_replay_arrays=True,expected_mock_diagnostic_only_differences=diagnostic_differences,
    old_replays=replays,reused_binaries=reuse['binaries'],no_new_build_or_rust_test_claim=True,
    original_checker_error='Only the external fixture_files list-vs-count assertion changed in v2; actual runs and all candidate bytes remain exact.',
    execution='Independent stdlib/hash/AST/log review and read-only Git only; no project imports/execution, builds, tests, network or live edits.')
(O/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(bind(O/'final-checks.json'),indent=2))
