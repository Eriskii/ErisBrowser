"""Independent static source/hash/control-oracle peer; no project execution."""
from pathlib import Path
import ast,collections,difflib,hashlib,json,subprocess
E=Path('/tmp/eris-promise-try-upstream-plan-1');H=E/'controls-contract-1';O=E/'controls-review-1';BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
def load(p):return json.loads(Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def verify_bindings(value):
 if isinstance(value,dict):
  if {'path','bytes','sha256'}<=set(value):
   b=bind(value['path']);assert (b['bytes'],b['sha256'])==(value['bytes'],value['sha256']),value['path']
  for v in value.values():verify_bindings(v)
 elif isinstance(value,list):
  for v in value:verify_bindings(v)
def write(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
seal=load(H/'source-ready.json');assert sha((H/'source-ready.json').read_bytes())=='5e94f5654d61695549eb8743c8f990601a14aaec463ecbd8694d296d1b98e89e';verify_bindings(seal)
for n in ['literals-ready.json','oracle-ready.json','published-base-refresh.json','literal-contract.json']:verify_bindings(load(H/n))
for f in seal['files']:
 raw=Path(f['raw']['path']).read_text();expected=''.join(difflib.unified_diff([],raw.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+f['relative_path']))
 # The retained diff headers may use new path labels; body reconstruction below is exact.
 diff=Path(f['diff']['path']).read_text();restored=''.join(line[1:] for line in diff.splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++'))
 assert restored==raw,f['relative_path']
parent=subprocess.check_output(['git','show',BASE+':tools/test262_conformance.py'],cwd=E/'worktree');assert parent==(H/'parent/tools/test262_conformance.py').read_bytes()
node=next(n for n in ast.parse(parent).body if isinstance(n,ast.FunctionDef) and n.name=='promise_preflight_variants')
common=ast.literal_eval(next(n for n in node.body if isinstance(n,ast.Return)).value)
assert len(common)==37 and common==load(H/'common-variants.json')
oracle=load(H/'raw/tools/promise-try-controls-oracle.json');assert oracle['common_variants']==common
legacy=load(oracle['bindings']['legacy_frozen_common_oracle']['path']);assert oracle['records'][:74]==legacy['records'][:74]
assert common==load(E/'worktree/tools/promise-methods-runner-oracle.json')['controls']
variants=load(H/'variants.json');assert variants==oracle['variants'] and len(variants)==10
pairs=[];literal=load(H/'literal-contract.json')
for family in literal['families']:
 name=family['name'];a=(H/'literals'/f'{name}.js').read_text();b=(H/'literals'/f'{name}-mismatch.js').read_text();c=family['only_change']
 assert a.count(c['before'])==1 and a.replace(c['before'],c['after'])==b
 for key,src in [(name,a),(name+'-mismatch',b)]:assert next(v for v in variants if v['name']==key)['source']==src
 pairs.append(dict(name=name,only_change=c,positive_sha256=sha(a.encode()),mismatch_sha256=sha(b.encode())))
# Eight helpers joined to the independently derived authenticated package.
package=E/'importer-contract-1/corpus/tests/upstream/test262-promise-try'
for name,meta in oracle['helpers'].items():
 b=(H/'helpers'/name).read_bytes();assert b==(package/'harness'/name).read_bytes();assert meta==dict(bytes=len(b),sha256=sha(b))
assert len(oracle['helpers'])==8
# Rebuild every record's source/metadata/helper/policy fingerprint and exact prerequisite graph.
records=[]
for rows,prefix in [(common,'promise-methods-'),(variants,'promise-try-')]:
 for mode in ['sloppy','strict']:
  for v in rows:
   policy=v['completion_policy'];names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+v['includes'];deps=[]
   if prefix=='promise-methods-':
    if v['prerequisite']:deps.append(prefix+v['prerequisite'])
    if v['origin']=='original-literal':
     deps.extend(prefix+x['name'] for x in common if x['origin']=='new-prerequisite')
     if v['name']!='one-async-completion':deps.append(prefix+'one-async-completion')
   else:
    deps=['promise-methods-'+x['name'] for x in common]
    if v['name']!='api':deps.append('promise-try-api')
    if v['prerequisite'] and prefix+v['prerequisite'] not in deps:deps.append(prefix+v['prerequisite'])
   name=prefix+v['name'];source_sha=sha(v['source'].encode());metadata=dict(flags=['async'] if policy else [],includes=v['includes'],features=[],locale=[],negative=None)
   harness=[dict(name=n,sha256=sha((package/'harness'/n).read_bytes())) for n in names]
   identity=dict(source_sha256=source_sha,mode=mode,metadata=metadata,harness=harness,completion_policy=policy)
   row=dict(name=name,mode=mode,id='harness-preflight:'+name,file='<preflight>',metadata=metadata,source=v['source'],source_sha256=source_sha,harness=harness,completion_policy=policy,expected=v['expected'],prerequisites=[[d,mode] for d in deps],case_sha256=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()))
   held=oracle['records'][len(records)];assert {k:v for k,v in held.items() if k!='mock_observation'}==row
   records.append(row)
assert len(records)==94
index={(r['name'],r['mode']):r for r in records};assert len(index)==94
visited=set();active=set();edgecount=0
for r in records:
 assert len(r['prerequisites'])==len({tuple(x) for x in r['prerequisites']})
 for dep in r['prerequisites']:assert tuple(dep) in index and dep[1]==r['mode'];edgecount+=1
def visit(key):
 assert key not in active
 if key in visited:return
 active.add(key)
 for d in index[key]['prerequisites']:visit(tuple(d))
 active.remove(key);visited.add(key)
for key in index:visit(key)
# Model source-derived new raw expectations independently; old common rows stay exact.
expected_new=load(H/'expected-observations.json')['new_variants']
for r in oracle['records'][74:]:
 name=r['name'].removeprefix('promise-try-');mismatch=name.endswith('-mismatch');async_case=name.startswith('async-helper');policy=int(async_case)
 e=dict(policy=policy,done_calls=int(async_case),success_prints=int(async_case and not mismatch),failure_prints=int(async_case and mismatch),flags=(1 if async_case else 256) if mismatch else 0,quiescent=True,audited=True,unhandled=0)
 obs=dict(status=('host-failure' if async_case else 'exception') if mismatch else 'complete',phase='host' if async_case and mismatch else 'runtime',error_type='Test262Error' if mismatch and not async_case else '',error_identity='',message=('completion-error' if async_case else 'uncaught exception: [object Object]') if mismatch else '',harness='',completion=e)
 assert r['mock_observation']==obs and expected_new[name]['observation']==obs
 assert expected_new[name]['classification']==('failed' if mismatch else 'passed')
# Common mock fields meet retained default-seven raw schema; no production callable used.
SEVEN={'Error','TypeError','RangeError','ReferenceError','SyntaxError','EvalError','URIError'}
field_names={'status','phase','error_type','error_identity','message','harness','completion'}
e_names={'policy','done_calls','success_prints','failure_prints','flags','quiescent','audited','unhandled'}
def pass_e(e):return e['flags']==0 and e['quiescent'] and e['audited'] and e['unhandled']==0 and (e['done_calls'],e['success_prints'],e['failure_prints'])==((0,0,0) if e['policy']==0 else (1,1,0))
def host_reason(e):
 for bit,reason in [(8,'fatal-observation'),(2,'premature-completion'),(4,'queued-exception'),(1,'completion-error'),(64,'delegate-abrupt'),(128,'session-violation'),(16,'unauthenticated-completion'),(32,'invalid-completion-print')]:
  if e['flags']&bit:return reason
 if not e['quiescent']:return 'nonquiescent-runtime'
 if not e['audited']:return 'unaudited-runtime'
 if e['unhandled']:return 'unhandled-rejection'
 if e['policy']==1:
  if e['done_calls']==2:return 'duplicate-completion'
  if e['done_calls']==0:return 'missing-completion'
  if e['success_prints']!=1 or e['failure_prints']!=0:return 'completion-protocol-error'
 return None
classifications=collections.Counter()
for r in oracle['records']:
 o=r['mock_observation'];e=o['completion'];assert set(o)==field_names and set(e)==e_names
 assert all(type(o[k]) is str and len(o[k].encode())<=16384 for k in field_names-{'completion'})
 assert all(type(e[k]) is int for k in e_names-{'quiescent','audited'}) and all(type(e[k]) is bool for k in ['quiescent','audited'])
 assert e['policy']==r['completion_policy'] and e['policy'] in [0,1]
 assert all(e[k] in (0,1,2) for k in ['done_calls','success_prints','failure_prints']) and 0<=e['flags']<=511 and 0<=e['unhandled']<=0xffffffff
 assert not o['error_identity'] or o['error_identity'] in SEVEN
 assert not(e['audited'] and (not e['quiescent'] or e['flags']&8)) and not(not e['audited'] and e['unhandled'])
 assert not((e['success_prints'] or e['failure_prints']) and not e['done_calls'])
 assert not(e['policy']==0 and (e['done_calls'] or e['success_prints'] or e['failure_prints']))
 if o['status']=='complete':assert o['phase']=='runtime' and all(o[k]=='' for k in ['error_type','error_identity','message','harness']) and pass_e(e)
 if o['status']=='exception':assert o['phase'] in ['parse','runtime'] and o['error_type'] and not o['harness'] and (o['phase']!='runtime' or e['flags']&256)
 if o['status']=='host-failure':assert o['phase']=='host' and not o['error_type'] and not o['error_identity'] and o['message'] and not pass_e(e)
 classification=o['status'] if o['status'] in ['unsupported','resource','harness-error'] else ('passed' if o['status']=='complete' else 'failed');classifications[classification]+=1
 if r['expected']=='passed':assert classification=='passed'
 elif r['expected']=='synchronous-exception':assert classification=='failed' and o['status']=='exception' and o['phase']=='runtime' and o['error_type']=='Test262Error' and o['error_identity']=='' and e['flags']==256 and e['quiescent'] and e['audited'] and e['unhandled']==0
 elif r['expected']=='resource':assert classification=='resource' and o['phase']=='runtime' and o['error_type']=='ResourceLimit' and e['flags']&8 and not e['audited']
 else:assert classification=='failed' and o['status']=='host-failure' and o['message']==r['expected']==host_reason(e)
# Independent original30 identities already authenticated in the importer hold.
orig=load(E/'importer-contract-1/raw/tools/test262-promise-try-import-oracle.json');assert len(oracle['original_cases_for_blocking'])==30
for r,want in zip(oracle['original_cases_for_blocking'],orig['case_identities']):
 assert dict(id=r['id'],case_sha256=r['case_sha256'])==want
 assert r['metadata']==orig['metadata'][r['file']] and r['source'].encode()==(package/r['file']).read_bytes()
 assert [x['name'] for x in r['harness']]==orig['helper_order'][r['file']]
 assert r['source_sha256']==sha(r['source'].encode())
assert sum('class' in r['metadata']['features'] for r in oracle['original_cases_for_blocking'])==6
# Inspect test syntax/roster and constant oracle seal; no test calls are run.
test=H/'raw/tools/test_test262_promise_try_controls.py';tree=ast.parse(test.read_text());tests=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(tests)==10
h=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ORACLE_SHA' for t in n.targets));assert h==sha((H/'raw/tools/promise-try-controls-oracle.json').read_bytes())
write('checks.json',dict(status='clear',source_ready=bind(H/'source-ready.json'),published_common_function_exact=True,common_records_exact=74,complete_records=94,fingerprint_vector_sha256=sha(json.dumps([(r['name'],r['mode'],r['case_sha256']) for r in records],separators=(',',':')).encode()),same_mode_prerequisite_edges=edgecount,acyclic=True,pairs=pairs,expected_classification_counts=dict(classifications),original_cases=30,retained_class_modes=6,helper_count=8,tests=tests,authorship='Reviewed independent author HTML controls; independent metadata30 comparison uses this reviewer\'s earlier authenticated importer hold.',execution='Stdlib/hash/AST and read-only published Git only; no producer reads or project imports/execution.'))
print(json.dumps(bind(O/'checks.json'),indent=2))
