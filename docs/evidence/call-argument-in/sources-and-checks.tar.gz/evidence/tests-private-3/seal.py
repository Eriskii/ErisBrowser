from pathlib import Path
import hashlib, json, difflib

base=Path('/tmp/eris-call-argument-in-1')
out=base/'tests-private-3'
previous=base/'tests-private-2'
relative='src/script/parser/driver/expressions/argument_in_context_tests.rs'
def binding(path):
    data=Path(path).read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def write_json(name,value):
    (out/name).write_text(json.dumps(value,indent=2)+'\n')

old='                assert!(parser.is(if source == "(1)" { "1" } else { "x" }));\n'
new='''                if source == "(1)" {
                    assert!(matches!(&parser.tokens[parser.pos].kind, TokenKind::Number(value) if *value == 1.0));
                    assert_eq!(parser.tokens[parser.pos].offset, 1);
                } else {
                    assert!(parser.is("x"));
                    assert_eq!(parser.tokens[parser.pos].offset, 4);
                }
'''
patch_rows=[]
for source_folder,destination in [(previous/'raw','raw'),(base/'worktree','formatted')]:
    before=(source_folder/relative).read_text()
    assert before.count(old)==1
    after=before.replace(old,new)
    assert after.replace(new,old)==before
    before_path=out/('before-'+destination)/relative
    after_path=out/destination/relative
    before_path.parent.mkdir(parents=True,exist_ok=True)
    after_path.parent.mkdir(parents=True,exist_ok=True)
    before_path.write_text(before)
    after_path.write_text(after)
    patch_path=out/(destination+'-correction.patch')
    patch_path.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+relative,tofile='after/'+relative)))
    patch_rows.append({'relative':relative,'composition':destination,'before':binding(before_path),'raw':binding(after_path),'diff':binding(patch_path)})

source1=json.loads((base/'source1.json').read_text())
assert source1['source_sha256'][relative]==patch_rows[1]['before']['sha256']
parser=(base/'worktree/src/script/parser.rs').read_text()
start=parser.index('    fn is(&self, text: &str) -> bool {')
end=parser.index('    fn eat(&mut self, text: &str) -> bool {',start)
assert 'Some(TokenKind::Word(word))' in parser[start:end]
assert 'Some(TokenKind::Symbol(symbol))' in parser[start:end]
assert 'TokenKind::Number' not in parser[start:end]
log_binding=binding(base/'validation/focused-argument-in-1.log')
assert log_binding['sha256'].startswith('b344a275')

reason={
    'finding':'Parser::is delegates to token_is, which recognizes unescaped Word and Symbol tokens only. Number(1.0) cannot satisfy is("1").',
    'why_parent_missed_it':'The parent failed earlier in this group at missing +In activation, so the token assertion was unreached. Candidate execution exposed a fixture-domain defect, not a changed grammar expectation.',
    'selected_correction':'Replace only the generic token assertion with Number(1.0) and offset1 for (1), or existing is("x") and offset4 for (...x). No source literal, semantic flag, fee, counter, group or production change.',
    'source_derivation':'Lexer represents the decimal literal at source byte1 as Number(1.0); contiguous dots consume bytes1..3 and leave the unescaped x token at byte4. The spread identifier check keeps the existing helper domain.',
    'retained_hold':binding(previous/'source-ready.json'),
    'retained_candidate_source':binding(base/'source1.json'),
    'failed_receipt':binding(base/'validation/focused-argument-in-1.json'),
    'failed_log':log_binding,
    'source_bindings':[binding(base/'worktree/src/script/parser.rs'),binding(base/'worktree/src/script.rs')],
    'execution_by_author':False,
    'live_edits':False,
    'production_changes':False,
}
write_json('correction.json',reason)
selection={
    'previous_hold':binding(previous/'source-ready.json'),
    'selected_raw':patch_rows[0],
    'source1_minimal_import':patch_rows[1],
    'unchanged':'Registration, ledger, all ten groups, four/six parent role roster, ABI qualification, source strings and every other assertion remain selected from hold2/its retained hold1 support.',
    'production':'No production path changes. Root owns applying this minimal correction and formatting/testing.',
}
write_json('selection.json',selection)
manifest={
    'schema':'eris-argument-in-private-tests-hold-v3',
    'status':'frozen-test-only-helper-domain-correction',
    'retained_hold':binding(previous/'source-ready.json'),
    'new_test_modules':[{'relative':relative,'raw':patch_rows[0]['raw'],'groups':10}],
    'source1_minimal_correction':patch_rows[1],
    'support':[binding(out/'correction.json'),binding(out/'selection.json'),patch_rows[0]['before'],patch_rows[0]['diff']],
    'groups':10,
    'parent_eligible_groups':10,
    'source_predicted_parent_roles':{'pass':4,'fail':6},
    'new_execution':False,
    'live_edits':False,
    'production_changes':False,
    'authoring_helper':binding(out/'seal.py'),
}
write_json('source-ready.json',manifest)
print(json.dumps(binding(out/'source-ready.json')))
