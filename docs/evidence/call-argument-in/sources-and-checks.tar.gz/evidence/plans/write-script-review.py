from pathlib import Path
import json,hashlib
B=Path('/tmp/eris-call-argument-in-plan-1')
def bind(p):
 p=Path(p);raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
def load(p):return json.loads((B/p).read_text())
manifest=load('source-ready.json')
assert bind(B/'source-ready.json')['sha256']=='1c68d5c646f2650df078f7fc889584b39a0ef84ca3f91701eb0752cfa63d6389'
for item in manifest['artifacts']+[manifest['authoring_helper']]:assert bind(item['path'])==item
sources=load('sources.json')
for entry in sources['files']:
 assert bind(entry['snapshot']['path'])==entry['snapshot']
 assert bind(entry['read_from']['path'])==entry['read_from']
review={
 'schema':'eris-call-argument-in-independent-source-review-v1',
 'status':'clear_for_bounded_next_checkpoint_selection',
 'selected_hold':bind(B/'source-ready.json'),
 'artifacts_verified':manifest['artifacts'],
 'source_snapshots_verified':[r['snapshot'] for r in sources['files']],
 'findings':[],
 'recommendation':{
  'scope':'Select call/new ArgumentList +In only, including ordinary and spread operands; do not bundle separate computed-member or conditional-true-operand repairs.',
  'representation':'Append one saved_in bool to each existing Arguments and NewArguments variant: (has_spread,current_spread,saved_in). Keep two existing variants, parent/callee IDs, Vec<ExprId>, dispatch count and list ownership. Add an explicit field-order comment; do not repurpose async_call or spread flags.',
  'success':'After the first fallible ellipsis recognition succeeds on a nonempty list, capture outer allow_in and set true before scheduling Assignment. Carry saved_in unchanged at every comma. At either closing-parenthesis branch restore before call_done/new_done, record emission or postfix resumption. Empty lists and no-parenthesis new do not mutate the flag.',
  'error':'Capture run-entry allow_in once; retain the existing run body Result; restore only on Err, then return the original Result. The closure must include initial enter, dispatch work, step and child enter. No new Result wrapping/error kind/offset or budget restoration.',
  'fees':'Recommend explicit selection of zero additional work debits under the existing bounded grammar-transition and fixed error-cleanup conventions, conditional on retaining exactly these scalar transitions and no new dispatcher iteration. This is a recommended tariff interpretation, not a claim that a numerical spare unit was previously reserved for each CPU instruction.',
  'heap':'Retain actual-size continuation admission. A bool is stored in the existing Frame payload; no separate allocation/header or field in Parser/Runtime. Observe prospective and final Frame/Kind/Transition on both selected toolchains before asserting unchanged concrete sizes/cuts.'
 },
 'charge_map':[
  {'operation':'Capture enclosing flag and enable +In for first argument','existing_boundary':'driver.rs169-188: work(1) precedes expressions::step; postfix531 and new_members613 are reached inside that already charged transition. Ellipsis recognition keeps its separate existing8 before flag mutation.','classification':'Bounded transition-local scalar state work. The same dispatcher already covers computed-key capture/enable at expressions396-400 and grouping/array/object capture at663/676/687 without per-bool debits.','new_work_recommendation':0},
  {'operation':'Carry saved_in across a later argument','existing_boundary':'Arguments/NewArguments resume is itself preceded by work(1); child(parent,next) uses existing move/push and existing reserve.','classification':'One more scalar in the same fixed-size continuation move. No extra scan, Clone of heap-owned handles, child, or grammar dispatch.','new_work_recommendation':0},
  {'operation':'Restore outer flag on successful close','existing_boundary':'The existing Arguments/NewArguments charged resume already consumes delimiter and calls call_done/new_done.','classification':'One scalar store in that transition. Existing ComputedKey405, TemplatePart411 and array/object/cover finish helpers restore the same grammar flag within their original dispatch envelopes. Restore before any fallible emission/postfix work.','new_work_recommendation':0},
  {'operation':'Capture run-entry scalar and inspect final Result','existing_boundary':'One run invocation has the existing root admission and transition loop; no new grammar operation or iteration is introduced.','classification':'Fixed host control around already-budgeted parsing, comparable to existing local output/Vec initialization and Result propagation. Do not describe initial read as literally occurring after a work debit. A root-admission refusal has not changed allow_in; writing back the same scalar on that path performs no rollback of author work.','new_work_recommendation':0},
  {'operation':'Restore flag when dispatch work, step or child reserve refuses','existing_boundary':'Existing terminal error path already drops the bounded pending continuation container; a scalar restore can always run after zero work is reached.','classification':'Fixed error cleanup; no author callback, allocation, extra charge or traversed frame stack. No new terminal budget or charge that could replace the original error. This zero-additional fixed epilogue must be selected explicitly.','new_work_recommendation':0},
  {'operation':'Reserve/move physical continuation storage','existing_boundary':'driver.rs105-124 retains growth work len+1, heap32+capacity*sizeof(Kind), logical maximum MAX_HEAP/sizeof(Kind), fallible reserve then push.','classification':'Same number of parent/child records and same capacity sequence for unchanged syntax if actual Kind size remains equal. Existing spare capacity behavior is retained; there is no new independent logical-admission field or allocation request. If measured Kind changes, actual-size formulas remain honest and exact-cut claims must be reconsidered before freeze.','new_work_recommendation':0},
  {'operation':'Legacy oracle argument helper','existing_boundary':'parser_legacy.rs1249/1751 test-only existing unary/new recursion and depth guards.','classification':'Retain the parse Result before restoring the flag; no production parser heap/work statement may be derived from this oracle. Avoid adding a new recursive grammar level.','new_work_recommendation':0}
 ],
 'fee_limits':[
  'work(1) here is the established grammar-transition unit, not an instruction-count claim. Existing one-unit branches already perform multiple bounded reads/writes/grammar tests; longer lists or source-sensitive scans retain their own existing admissions.',
  'The new runtime spread item6 schedule remains exact and separate. Parser saved_in does not license dropping either runtime marker inspection or treating runtime item charges as compile work.',
  'No new work debit is necessary for this selected scalar restoration proposal. If implementation instead introduces a RestoreIn continuation, another run call, a frame scan or heap-owned guard, that falls outside this review and requires explicit accounting.',
  'No allowance increase, startup change, fresh cleanup budget, refund, source/token/stack/call cap change or old helper fee reduction is recommended.'
 ],
 'layout':{
  'minimality':'Three bools in the existing tuple are the narrowest source change. A separate context frame would add dispatches/occupancy; a heap guard or ancestor scan adds avoidable ownership/work. A named small flags record could be legible but is unnecessary for this checkpoint.',
  'source_inference':'On held x86_64 Linux component sizes, Postfix occupies24 and Vec24: Arguments raw fields increase50 to51 bytes before enum representation/padding; NewArguments fields increase34 to35. These still fit the next alignment boundaries56 and40. Existing larger alternatives determine the observed72-byte enum, so unchanged maximum is plausible.',
  'not_measurement':'Rust enum field/discriminant/niche layout is not established by this arithmetic. No compiler was run. Previous Frame72/Kind112/Transition224/Output88 and buffer480/limit74898 are AT observations only, not +In measurements.',
  'required_measurements':['Both established x86_64 Linux toolchain configurations on exact prospective definitions.','Actual final Frame,Kind,Transition,Output and derived four-slot buffer/limit once implementation exists.','Preserve platform gating and size-dependent symbolic quotas elsewhere.','Unchanged small-stack parser witness; no native stack/RSS guarantee from enum-size equality.']
 },
 'dynamic_function':{
  'handoff':'functions::Frame::Dynamic calls Context::enter (allow_in=true), then function_body returns Output::Parameters(state) while the context remains active. driver::dynamic_function subsequently replaces tokens, invokes run for body, then calls functions::finish to restore saved Context.',
  'success':'A successful first run must not reset allow_in to its own entry value. A private false-entry test is decisive: after Parameters, allow_in must be true; after body run it remains true until finish restores false. Ordinary public construction starts true and alone would not isolate this bug.',
  'error':'An error in run1 restores run1 entry; an error in run2 restores run2 entry (normally true from active function context), not the outer value stored in State. Preserve the original ScriptError and cumulative budget.',
  'outside_run':'lex(source) between the runs, functions::finish after run2, and later publication/name work are outside this narrow run epilogue. They do not gain a general flag/context rollback guarantee. Public parser failure still discards the parser; no reuse promise.',
  'other_context':'No claim to restore strictness, function_depth, labels, loop/switch/new_target fields, pos, tokens, records or allocation counters on Err. Rust panic/unwind is excluded.'
 },
 'public_oracle_read':{
  'cases':15,'new_admission_cases':9,'preservation_or_negative_cases':6,
  'status':'Manual grammar/value derivation finds no wrong literal; no execution. Both ordinary and spread call/new branches, nested lists, var/let initializers, outer for-in separators and valid parenthesized controls discriminate the intended state lifetime.',
  'literal_notes':['Nested f/C pairs yield false,true;true,false; from inner-first evaluation.','Mixed call spread yields true,7,false; new spread/trailing yields3,4.','Single-property for-in target evaluation yields AaBa and TaTa; these require restoring outer~In before separator recognition.','Classic-for sources containing an unparenthesized outer in remain SyntaxError; grouping of that outer in is separately valid.']
 },
 'tests_before_production':[
  'Freeze exact public literals unchanged in existing-API tests and baseline only after AT publication; ordinary cases demonstrate the pre-existing grammar defect rather than a spread-specific regression.',
  'Private owner transitions: both entry flags, call/new, ordinary/spread, empty/one/multiple/nested/trailing lists; assert restored flag before emission/refusal or postfix/for-head continuation.',
  'Error-only run epilogue: fail initial reserve, dispatch after activation, child enter reserve, marker/list record heap/work, malformed later ellipsis/operand/close and Unsupported; preserve error/counters and run-entry flag. No failed-parser reuse assertion.',
  'Dynamic false-entry two-stage private handoff and each run error; label lex-between-runs/finish failures separately if tested so their existing context behavior is not accidentally overclaimed.',
  'Compare exact compile work/heap and canonical output for matched no-in sources and unchanged AT cuts; derive any numeric one-short fixtures from actual existing helpers before freezing them. No new arbitrary fee cuts.',
  'Measure actual type sizes and preserve old isolated ellipsis8, record/list/page and runtime spread tests. No startup/count migration is anticipated if types are unchanged.'
 ],
 'standards_independently_reopened':[
  {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-left-hand-side-expressions','finding':'ArgumentList operands explicitly use +In for ordinary/spread first and later positions; Arguments itself carries Yield/Await, not In.'},
  {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-for-statement','finding':'Classic-for initializer is~In while later expressions are+In; outer for-in/of separators remain distinct.'}
 ],
 'execution':False,'live_edits':False,'test_or_production_authoring':False
}
p=B/'script-review.json';p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(p)))
