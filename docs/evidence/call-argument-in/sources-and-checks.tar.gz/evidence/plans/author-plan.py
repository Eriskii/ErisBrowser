from pathlib import Path
import json,hashlib
D=Path('/tmp/eris-call-argument-in-plan-1');A=Path('/tmp/eris-call-spread-plan-1');H=A/'production-parser-1';W=A/'worktree'
def write(n,x): (D/n).write_text(json.dumps(x,indent=2)+'\n')
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
inv=json.loads((A/'source1.json').read_text())['source_sha256'];rows=[]
for rel in ['src/script/parser.rs','src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs']:
 p=H/'raw'/rel if (H/'raw'/rel).exists() else W/rel
 q=D/'source-snapshots'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
 row={'relative':rel,'read_from':info(p),'snapshot':info(q)}
 if not (H/'raw'/rel).exists():
  row['matches_current_source1_inventory']=info(p)['sha256']==inv[rel];assert row['matches_current_source1_inventory']
 rows.append(row)
write('sources.json',{'parser_hold':info(H/'source-ready.json'),'parser_peer':info(H/'html-review.json'),'current_inventory':info(A/'source1.json'),'files':rows,'qualification':'Three parser sources are immutable raw held production; three driver sources are current source1-bound bytes. The driver registration order was formatted after source-before-production; it is not claimed byte-identical to that earlier inventory.'})
write('standards.json',{'checked_date':'2026-10-15','access':'Current official TC39 multipage ECMA-262 opened with web tool, no engine execution.','sources':[
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-left-hand-side-expressions','section':'13.3 Syntax','finding':'Arguments has Yield/Await parameters, not In. Every ordinary and spread ArgumentList operand explicitly uses AssignmentExpression[+In]. CallExpression and new MemberExpression both use Arguments.'},
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-grouping-operator','section':'13.2.9','finding':'Parenthesized expressions supply an existing positive control; grouping is not required around an in expression inside arguments.'},
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-for-statement','section':'14.7.4 Syntax','finding':'The first classic-for expression/declaration uses ~In; test and update use +In.'},
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-for-in-and-for-of-statements','section':'14.7.5 Syntax and early errors','finding':'For-in separates its left-hand-side target from a +In right side. Argument parsing must restore the outer ~In context before that separator.'}]})
write('proposal.json',{
 'status':'proposal-only-unselected',
 'scope':'Next checkpoint only; no change to sealed AT parser production or tests.',
 'defect':'A for initializer sets Parser.allow_in=false. Nonempty call/new argument parsing schedules Assignment without overriding it, rejecting direct in expressions. Grouping/array/object contexts already override allow_in and can hide this defect.',
 'seams':[
 {'file':'src/script/parser/driver/expressions.rs','held_lines':[20,199,251,543,581,603,629],'change':'Append saved_in bool to Arguments and NewArguments. At nonempty-list entry, complete fallible ellipsis recognition, save surrounding flag, enable true, then schedule existing Assignment. Carry saved_in unchanged across commas. Restore immediately after recognizing closing parenthesis, before call_done/new_done, emission or postfix resumption, on both ordinary and trailing-comma paths.'},
 {'file':'src/script/parser/driver.rs','current_lines':[168,172,180,189],'change':'Save entry allow_in, evaluate the existing run body in a local Result-producing closure, restore entry flag if Err, then propagate Result. Include dispatch work, step errors and continuation-reserve failure. Leave successful runs unchanged: owner continuations restore their own contexts.'},
 {'file':'src/script/parser_legacy.rs','held_seams':['unary_inner call-argument loop','new_expression_inner constructor-argument loop'],'change':'Use a shared test-only argument-list helper or equivalent local closure after opening parenthesis. Save flag, enable true for nonempty list, retain Result, restore flag before returning Ok or Err. Both callers preserve current ordinary/spread parents, recursion/depth and test-only allocation policies.'}],
 'restoration':{
 'empty':'Empty argument lists and constructor forms without parentheses never change the flag or add a continuation/ellipsis fee.',
 'nested_success':'A nested list restores true to its containing argument list; the outermost list restores false to its for initializer. Restore before binary tails and for-head delimiter recognition.',
 'failure':'A child failure skips the suspended argument continuation. The driver error boundary therefore restores the run invocation-entry allow_in for Syntax, Unsupported, work/heap and reserve refusal without scanning/unwinding pending frames. This does not rewind pos, budget, strict mode or every Parser field; failed parsers still are not reusable.',
 'dynamic':'Do not reset after every successful run. functions::Frame::Dynamic returns Parameters(state) with its context active; the second run parses the body, then functions::finish restores Context. Error-only driver restoration preserves this successful handoff.',
 'legacy':'The Result must be retained before restoration; set/parse?/restore is insufficient on errors.',
 'panic':'Only Result paths are covered; no new Rust panic/unwind or process-abort guarantee.'},
 'layout_resources':{
 'candidate':'One extra bool per existing argument continuation. No new variant, Parser/Runtime field, syntax node, edge list, auxiliary vector, dispatch, scan or recursive parser entry.',
 'size':'Unchanged maximum Frame size is plausible because the two payloads have alignment padding and larger variants already determine the current72-byte enum. This is not a Rust layout guarantee. Root should measure exact prospective/actual Frame/Kind/Transition and initial-buffer/heap-limit quotients before selecting unchanged size or allocation fees.',
 'historical_controls':'AT measured x86_64 Linux Frame72, Kind112, Transition224 and initial four-Kind buffer480. These are not measurements of this proposal; preserve ABI qualification.',
 'fixed_operations':'Per nonempty list: save flag, enable true, restore at close, plus carrying bool with existing continuation. Per run: save entry bool, classify Result, restore on error. No new fee is selected here; root must explicitly choose whether current aggregate dispatch envelope covers these operations.',
 'unchanged_scope':'Ellipsis recognition8; marker/list work and heap; spread runtime entry8/item6/acquisition/attempt/append fees; all caps; startup; ordinary runtime argument collection.',
 'no_claim':'No compiler, type-size, native-stack/RSS, benchmark, performance or conformance result.'},
 'not_selected':['No generic RestoreIn continuation with extra dispatch/occupancy.','No packing into unrelated async/chain fields or scanning ancestor frames.','No leaving true until for_head.','No full parser-context rollback redesign.'],
 'separate_docket':['Computed member expressions and conditional true operands have independent +In seams; do not silently broaden this correction.','Optional calls, super and import remain under existing support policy.']})
base="var o={x:1}, out='';";cases=[]
fail='Source predicts SyntaxError at direct inner in on the current AT spread candidate; not executed.'
keep='Source predicts preserved control on the current AT spread candidate; not executed.'
def c(id,kind,s,expected,reason):
 cases.append({'id':id,'kind':kind,'source':s,'expected':expected,'rationale':reason,'parent_prediction':fail if kind=='new-admission' else keep,'modes':['sloppy','strict']})
c('call-direct','new-admission',base+"function f(v){out+=v?'T':'F';} for(f('x' in o);false;){} out;",'T','Ordinary argument resets for-init ~In.')
c('new-direct','new-admission',base+"function C(v){out+=v?'T':'F';} for(new C('x' in o);false;){} out;",'T','Constructor Arguments has the same obligation.')
c('call-nested-multiple','new-admission',base+"function f(a,b){out+=a+','+b+';';return false;} for(f('x' in o,f('y' in o,'x' in o));false;){} out;",'false,true;true,false;','Inner list and later arguments restore to enclosing +In.')
c('new-nested-multiple','new-admission',base+"function C(a,b){out+=a+','+b+';';this.flag=a;} for(new C('x' in o,new C('y' in o,'x' in o).flag);false;){} out;",'false,true;true,false;','Nested constructors preserve enclosing list context.')
c('call-mixed-spread','new-admission',base+"function f(a,b,c){out=a+','+b+','+c;} for(f('x' in o,...'missing' in o?[]:[7],'missing' in o);false;){} out;",'true,7,false','Unparenthesized spread AssignmentExpression and both ordinary sides.')
c('new-spread-trailing','new-admission',base+"function C(a,b){out=a+','+b;} for(new C(...'x' in o?[3,4]:[],);false;){} out;",'3,4','Spread +In and trailing-comma closing path.')
for kind in ['var','let']:
 c('declaration-'+kind,'new-admission',base+"function f(v){out+=v?'T':'F';return 0;} for("+kind+" saved=f('x' in o);false;){} out;",'T','Declaration initializer remains ~In outside nested Arguments.')
c('parenthesized-call-new','preservation',base+"function f(v){out+=v?'T':'F';} function C(v){out+=v?'T':'F';} for(f(('x' in o));false;){} for(new C(('x' in o));false;){} out;",'TT','Existing grouping supplies +In and proves prerequisites.')
c('parenthesized-spread','preservation',base+"function f(a,b){out+=a+','+b+';';} function C(a,b){out+=a+','+b+';';} for(f(...(('x' in o)?[1,2]:[]));false;){} for(new C(...(('x' in o)?[3,4]:[]),);false;){} out;",'1,2;3,4;','Existing spread and trailing-comma preservation.')
c('outer-for-in-after-call-new','preservation',"var holder={}, out=''; function f(v){out+='A';return holder;} function C(v){out+='B';return holder;} for(f(0).slot in {a:1}){out+=holder.slot;} for(new C(0).slot in {a:1}){out+=holder.slot;} out;",'AaBa','Leaking true would consume the outer in as binary syntax and reject valid for-in.')
c('inner-and-outer-in','new-admission',base+"var holder={}; function f(v){out+=v?'T':'F';return holder;} function C(v){out+=v?'T':'F';return holder;} for(f('x' in o).slot in {a:1}){out+=holder.slot;} for(new C('x' in o).slot in {a:1}){out+=holder.slot;} out;",'TaTa','Discriminates inner admission from outer separator restoration in one source.')
c('no-leak-call-classic-for','negative',"function f(x){return 'x';} for(f(0) in {x:1};false;){}",{'error_kind':'SyntaxError'},'A leaked true would wrongly admit this classic-for binary initializer.')
c('no-leak-new-classic-for','negative',"function C(x){} for(new C(0) in {x:1};false;){}",{'error_kind':'SyntaxError'},'Constructor list must not relax outer ~In.')
c('parenthesized-outer-in','preservation',"var out=''; function f(x){out+='F';return 'x';} for((f(0) in {x:1});false;){} out;",'F','Explicit grouping legitimately admits outer binary in; no blanket rejection.')
write('public-controls.json',{'status':'literal-proposals-not-imported-tests','baseline':'Current AT spread candidate after its independent acceptance. Pre-spread parent is not a baseline for spread controls.','count':len(cases),'cases':cases,'verification_scope':'Expectations are derived from grammar and source. No JavaScript/parser/Rust execution. Future tests should use fresh Runtime in both modes and active/legacy canonical parsing.'})
write('private-controls.json',{'status':'prospective-only','controls':[
 {'id':'success-context','input':'Both entry flags, call/new, empty/one/multiple/nested/trailing lists.','expect':'Exact entry flag restored; unchanged syntax parent and no new record.'},
 {'id':'syntax-error-context','input':'Bad operand, missing comma/close, malformed ellipsis on a later item after entering +In.','expect':'Original SyntaxError/offset policy and run-entry flag restored; no pos/budget rollback.'},
 {'id':'resource-error-context','input':'Paid setup then refuse dispatch, expr/list heap and continuation reserve after +In activation.','expect':'Original resource counters/kind; entry flag restored. Freeze numeric cuts only after actual fee/source selection.'},
 {'id':'unsupported-context','input':'Existing unsupported expression within argument.','expect':'Unsupported preserved; entry flag restored.'},
 {'id':'dynamic-handoff','input':'Dynamic Function defaults/body success and failure in each run.','expect':'Successful Parameters context handoff retained; each error restores its run-entry flag, not a claimed full Context reset.'},
 {'id':'shape-and-accounting','input':'Exact new definitions on the two established x86_64 Linux compiler configurations; matched no-in sources.','expect':'Observe Frame/Kind/Transition and reserve quotients before claiming unchanged size/fees. No new dispatch/runtime migration.'}]})
items=[info(p) for p in sorted(D.glob('*.json')) if p.name!='source-ready.json']
write('source-ready.json',{'schema':'eris-call-argument-in-next-plan-v1','status':'source-only-proposal-ready','artifacts':items,'authoring_helper':info(D/'author-plan.py'),'scope':'No production/test authoring, live edits/imports, Rust/JavaScript/parser execution, browser, formatter or git. Inert source snapshots/hash operations only. Root selection and concrete tests-first freeze precede implementation.'})
print(json.dumps(info(D/'source-ready.json')))
