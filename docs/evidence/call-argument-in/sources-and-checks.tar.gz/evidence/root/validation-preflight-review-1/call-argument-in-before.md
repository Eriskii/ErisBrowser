# Call and constructor argument grammar contexts

Call and constructor arguments accept `in` expressions even when the argument
list appears in a `for` initializer. For example:

```js
for (consume("key" in object); false;) {}
for (new Box("key" in object); false;) {}
for (consume(..."key" in object ? [1] : []); false;) {}
```

ECMAScript's ArgumentList grammar enables `In` for each assignment-expression
operand. The parser previously inherited the initializer's restriction instead.
Each nonempty argument continuation now saves the outer flag, enables it for its
operands, and restores it before publishing the call/new expression. Nested
argument lists own their own saved flags. Both closing-parenthesis paths,
including trailing commas, restore the context. Empty lists and constructors
without parentheses retain their existing behavior.

On parser errors, the continuation driver restores its invocation-entry `In`
flag. It preserves the original error, token position and spent quotas. This is
not full parser rollback or a guarantee that failed parsers can be reused.
Successful dynamic-function parameter parsing still carries its active function
context into body parsing; function completion restores the outer context.

The change uses the existing argument frames and grammar dispatch charges. It
adds no runtime fields, allocations, syntax records, dispatches or resource-limit
changes. The reference parser used by differential tests implements the same
argument-context rule.

This correction does not complete ECMAScript grammar, web compatibility,
production security or the Chromium-relative performance target. Computed
member and conditional-expression contexts remain separate follow-ups.

Specification: [Argument lists](https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-argument-lists).
