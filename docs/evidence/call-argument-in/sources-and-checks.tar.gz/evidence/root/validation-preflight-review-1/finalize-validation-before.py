import hashlib, json, re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def read(p): return json.loads(p.read_bytes())
def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

source = read(A / 'source2.json')
for path, digest in source['source_sha256'].items():
    assert bind(W / path)['sha256'] == digest, path
public = [r['test'] for r in read(A / 'tests-public-1/oracle.json')['groups']]
private = ['script::parser::driver::expressions::argument_in_context_tests::' + r['name']
           for r in read(A / 'tests-private-2/roster.json')['groups_detail']]
names = public + private
assert len(names) == len(set(names)) == 25
checks = {}
labels = ['focused-argument-in-2', 'default-full-1', 'host-vulkan-full-1',
          'clippy-msrv-1', 'clippy-host-vulkan-1', 'format-check-1',
          'host-release-1', 'upstream-all-1', 'upstream-existing-1']
pattern = r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
for label in labels:
    receipt = A / 'validation' / (label + '.json')
    record = read(receipt)
    log = A / 'validation' / record['log']
    assert record['exit'] == 0 and bind(log)['sha256'] == record['sha256']
    checks[label] = {'receipt': bind(receipt), 'log': bind(log)}
    if label in ['focused-argument-in-2', 'default-full-1', 'host-vulkan-full-1']:
        text = log.read_text()
        rows = [(s, *map(int, nums)) for s, *nums in re.findall(pattern, text, re.M)]
        found = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
        total = {'focused-argument-in-2': 25, 'default-full-1': 3024, 'host-vulkan-full-1': 3378}[label]
        assert sum(r[1] for r in rows) == len(found) == total
        assert all(found.count(n) == 1 for n in names)
        assert all(r[0] == 'ok' and r[2:5] == (0, 0, 0) for r in rows)
        if label == 'focused-argument-in-2':
            assert len(rows) == 1 and set(found) == set(names)
        else:
            assert len(rows) == 50 and all(r[5] == 0 for r in rows)
        checks[label].update(passed=total, result_rows=len(rows), failed=0, ignored=0)

binary = read(A / 'binary.json')
assert bind(Path(binary['path'])) == {k: binary[k] for k in ['path', 'bytes', 'sha256']}
reports = {}
for name, total, guards in [('promise-all-report.json', 196, 90), ('promise-existing-report.json', 458, 74)]:
    report = read(A / name)
    previous = read(Path('/tmp/eris-call-spread-plan-1') / name)
    assert report['cases'] == previous['cases']
    assert report['harness_preflight'] == previous['harness_preflight']
    assert report['mode_cases'] == len(report['cases']) == total
    assert len(report['harness_preflight']) == guards and report['harness_preflight_passed']
    assert all(c['verified'] for c in report['harness_preflight'])
    assert not report['regressions'] and not report['improvements']
    assert report['binary_sha256'] == binary['sha256']
    for key in ['revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'counts']:
        assert report[key] == previous[key]
    reports[name] = {'report': bind(A / name), 'counts': report['counts'], 'modes': total,
                     'harness_controls': guards, 'all_case_and_harness_records_unchanged': True}

out = {'status': 'pass', 'base': source['base'], 'source': bind(A / 'source2.json'),
       'source_inputs': len(source['source_sha256']), 'new_groups': {'public': 15, 'private': 10, 'total': 25},
       'checks': checks, 'binary': binary, 'replays': reports,
       'parent_public': bind(A / 'root/parent-public-baseline.json'),
       'parent_private': bind(A / 'root/parent-private-baseline.json'),
       'test_corrections': 'Private hold1 had inaccessible count-only assertions; hold2 removed them before execution. Hold3 corrects a number-token matcher after 24/25 candidate groups passed. No semantic or numeric expectation was retuned.',
       'preservation': 'Actual x86_64 Linux Frame72/Kind112/Transition224 and fourteen parent full-compile tariff rows pass in both configurations. No runtime source or caps changed; no old test migrations.',
       'limitations': ['Selected argument grammar correction only; full web compatibility remains unfinished.',
                       'No GPU-device, physical-memory, native-stack or Chromium-speed measurement at this checkpoint.',
                       'Error cleanup restores only invocation-entry In flag, not full failed-parser state.']}
(A / 'root/final-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'status': 'pass', 'default': 3024, 'host_vulkan': 3378, 'new_groups': 25}))
