from pathlib import Path
from collections import Counter
import hashlib, json, re

base=Path('/tmp/eris-call-argument-in-1')
worktree=base/'worktree'
ancestor=Path('/tmp/eris-call-spread-plan-1')
def read(p): return json.loads(p.read_text())
def bind(p):
    data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def verify_binding(b):
    actual=bind(Path(b['path']))
    assert all(actual[k]==b[k] for k in ['path','bytes','sha256']), b['path']

final=read(base/'root/final-validation.json')
assert final['status']=='pass'
bound=[]
def visit(obj):
    if isinstance(obj,dict):
        if {'path','bytes','sha256'}<=obj.keys():
            verify_binding(obj);bound.append({k:obj[k] for k in ['path','bytes','sha256']})
        else:
            for v in obj.values(): visit(v)
    elif isinstance(obj,list):
        for v in obj: visit(v)
visit(final)
source=read(base/'source2.json')
parent=read(base/'parent-source.json')
assert len(source['source_sha256'])==final['source_inputs']==1238
assert len(parent['source_sha256'])==1236
assert source['base']==parent['base']==final['base']=='8159301e555010f4c7879e1fbd31c9cfc784b686'
for name,digest in source['source_sha256'].items():
    assert bind(worktree/name)['sha256']==digest,name
changed={name for name,digest in source['source_sha256'].items() if parent['source_sha256'].get(name)!=digest}
assert changed=={
    'src/script.rs','src/script/parser/driver.rs','src/script/parser/driver/expressions.rs',
    'src/script/parser_legacy.rs','src/script/call_argument_in_tests.rs',
    'src/script/parser/driver/expressions/argument_in_context_tests.rs'}
assert set(parent['source_sha256'])<=set(source['source_sha256'])

public=[r['test'] for r in read(base/'tests-public-1/oracle.json')['groups']]
private=['script::parser::driver::expressions::argument_in_context_tests::'+r['name'] for r in read(base/'tests-private-2/roster.json')['groups_detail']]
expected=Counter(public+private)
assert len(public)==15 and len(private)==10 and len(expected)==25 and set(expected.values())=={1}

def parse_log(path):
    summary=[]; cases=[]
    for line in path.read_text().splitlines():
        if line.startswith('test result: '):
            parts=line.split(';')
            assert len(parts)>=6,line
            state, passed=parts[0][len('test result: '):].split('. ',1)
            values=[int(passed.split()[0])]+[int(part.strip().split()[0]) for part in parts[1:5]]
            summary.append((state,*values))
        match=re.fullmatch(r'test (\S+) \.\.\. (ok|FAILED|ignored)',line)
        if match: cases.append(match.groups())
    return summary,cases

receipts={}
for name,entry in final['checks'].items():
    receipt=read(Path(entry['receipt']['path']))
    assert receipt['exit']==0
    assert receipt['log']==Path(entry['log']['path']).name
    assert receipt['sha256']==entry['log']['sha256']
    receipts[name]=receipt
assert set(receipts)=={'focused-argument-in-2','default-full-1','host-vulkan-full-1','clippy-msrv-1','clippy-host-vulkan-1','format-check-1','host-release-1','upstream-all-1','upstream-existing-1'}
checks=[]
for name,total,rows in [('focused-argument-in-2',25,1),('default-full-1',3024,50),('host-vulkan-full-1',3378,50)]:
    entry=final['checks'][name]
    summary,cases=parse_log(Path(entry['log']['path']))
    assert len(summary)==rows
    assert sum(r[1] for r in summary)==total==len(cases)==entry['passed']
    assert all(r[0]=='ok' and r[2:5]==(0,0,0) for r in summary)
    assert all(state=='ok' for _,state in cases)
    found=Counter(n for n,_ in cases)
    assert all(found[n]==1 for n in expected)
    if name=='focused-argument-in-2': assert found==expected
    else:
        assert all(r[5]==0 for r in summary)
        oldsummary,oldcases=parse_log(ancestor/'validation'/f'{name}.log')
        oldfound=Counter(n for n,state in oldcases if state=='ok')
        assert not (oldfound-found) and found-oldfound==expected
        assert total-sum(r[1] for r in oldsummary)==25
    checks.append({'name':name,'passed':total,'rows':rows,'exact_new_roster':25,'failed':0,'ignored':0,'measured':0,'filtered':sum(r[5] for r in summary),'old_suite_delta':'exactly the selected25 full names' if rows==50 else None})

assert receipts['default-full-1']['command']==['cargo','+1.88.0','test','--locked','--offline','--manifest-path','Cargo.toml','--','--include-ignored']
assert receipts['host-vulkan-full-1']['command']==['cargo','+1.99.0','test','--locked','--offline','--manifest-path','Cargo.toml','--features','test262-host,vulkan-raster','--','--include-ignored']
for label,version,features in [('clippy-msrv-1','+1.88.0',[]),('clippy-host-vulkan-1','+1.99.0',['--features','test262-host,vulkan-raster'])]:
    assert receipts[label]['command']==['cargo',version,'clippy','--locked','--offline','--manifest-path','Cargo.toml']+features+['--all-targets','--','-D','warnings']
assert receipts['format-check-1']['command'][-4:]==['fmt','--all','--','--check']
assert Path(final['checks']['format-check-1']['log']['path']).stat().st_size==0
assert receipts['host-release-1']['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--features','test262-host','--release','--bin','eris-js']

binary=read(base/'binary.json')
verify_binding(binary)
assert binary==final['binary']
assert binary['source_inventory']==str(base/'source2.json')
assert binary['build_receipt']==str(base/'validation/host-release-1.json')
replays=[]
for name,total,guards,files,statuses,label,profile in [
    ('promise-all-report.json',196,90,98,{'passed':174,'failed':14,'unsupported':8},'upstream-all-1','promise-all'),
    ('promise-existing-report.json',458,74,232,{'passed':420,'failed':8,'unsupported':30},'upstream-existing-1','promise-methods-async')]:
    report=read(base/name); previous=read(base/'replay-parent'/name)
    assert (base/'replay-parent'/name).read_bytes()==(ancestor/name).read_bytes()
    assert report['cases']==previous['cases'] and report['harness_preflight']==previous['harness_preflight']
    assert len(report['cases'])==report['mode_cases']==total
    assert report['source_tests']==files
    assert Counter(c['status'] for c in report['cases'])==report['counts']==statuses
    assert len({c['id'] for c in report['cases']})==total
    assert len(report['harness_preflight'])==guards and report['harness_preflight_passed'] is True
    assert all(c['verified'] is True for c in report['harness_preflight'])
    assert report['regressions']==report['improvements']==[]
    for key in ['suite','full_test262_conformance','repository','revision','corpus_manifest_sha256','runner_policy','runner_policy_sha256','source_files','source_tests','negative_source_tests','fixture_files','mode_cases','counts']:
        assert report[key]==previous[key],(name,key)
    assert report['full_test262_conformance'] is False
    assert report['binary']==binary['path'] and report['binary_sha256']==binary['sha256']
    command=receipts[label]['command']
    assert command[command.index('--binary')+1]==binary['path']
    assert command[command.index('--profile')+1]==profile
    assert command[command.index('--output')+1]==str(base/name)
    entry=final['replays'][name]
    assert entry['counts']==statuses and entry['modes']==total and entry['harness_controls']==guards and entry['all_case_and_harness_records_unchanged'] is True
    replays.append({'profile':profile,'files':files,'modes':total,'counts':statuses,'verified_controls':guards,'case_records_equal_parent':True,'control_records_equal_parent':True,'retained_parent_byte_exact_to_AT':True})

baseline=[]
for name,passed,failed in [('public',6,9),('private',4,6)]:
    record=read(base/'root'/f'parent-{name}-baseline.json')
    summary,cases=parse_log(Path(record['log']['path']))
    verify_binding(record['log']);verify_binding(record['receipt'])
    assert len(summary)==1 and summary[0][1:3]==(passed,failed)
    assert read(Path(record['receipt']['path']))['exit']==101
    assert Counter(status for _,status in cases)==Counter({'ok':passed,'FAILED':failed})
    baseline.append({'scope':name,'passed':passed,'failed':failed,'eligibility':'Existing parent APIs; failed groups stop at first reached assertion, later rows not parent observations.'})
failed_summary,failed_cases=parse_log(base/'validation/focused-argument-in-1.log')
assert len(failed_summary)==1 and failed_summary[0][1:3]==(24,1)
assert [n for n,status in failed_cases if status=='FAILED']==['script::parser::driver::expressions::argument_in_context_tests::argument_owner_entry_enables_in_without_changing_empty_lists']
assert read(base/'tests-private-3/layout-review.json')['status'].startswith('clear')

helper=(base/'root/finalize-validation.py').read_text()
assert "read(A / 'tests-public-1/oracle.json')['groups']" in helper
assert "found = re.findall(r'^test (\\S+) \\.\\.\\. ok$', text, re.M)" in helper
assert "'parent_report': bind(parent)" in helper
assert "assert parent.read_bytes() ==" in helper
doc=worktree/'docs/call-argument-in.md'
text=doc.read_text()
for literal in ['All 25 new regression groups pass','3,024','3,378','50 result rows','72, 112 and 224','Fourteen existing','196-mode','458-mode','all 90 and 74','not full parser rollback','separate follow-ups']:
    assert literal in text,literal

review={
    'status':'clear',
    'scope':'Independent reconciliation of terminal AU validation receipts/logs, source2/binary/replay identity and final documentation; inert file parsing only.',
    'final_validation':bind(base/'root/final-validation.json'),
    'finalizer':bind(base/'root/finalize-validation.py'),
    'preflight_findings':'Both closed: frozen oracle supplies exact full public names and private names are fully qualified; copied parent reports are byte-compared with AT and included in replay bindings.',
    'retained_preflight':bind(base/'root/validation-preflight-review-1/review.json'),
    'verified_final_bindings':len(bound),
    'source':{'inventory':bind(base/'source2.json'),'inputs_checked':1238,'parent_inputs':1236,'changed_or_added_paths':sorted(changed),'unchanged_parent_inputs':1232,'base':source['base'],'source_composition_peer':bind(base/'root/final-source-review.json')},
    'tests':checks,
    'toolchain_checks':'Receipt commands confirm 1.88 default and 1.99 test262-host,vulkan-raster full suites; both strict all-target Clippy commands pass, formatting check is empty/successful, and 1.88 test262-host release build succeeds.',
    'binary':binary,
    'replays':replays,
    'parent_observations':baseline,
    'correction_provenance':{'original_privacy_hold':bind(base/'tests-private-1/source-ready.json'),'selected_privacy_correction':bind(base/'tests-private-2/source-ready.json'),'retained24pass1fail':bind(base/'validation/focused-argument-in-1.log'),'token_correction':bind(base/'tests-private-3/source-ready.json'),'token_correction_peer':bind(base/'tests-private-3/layout-review.json'),'interpretation':'No production, source input, semantic result or numeric cut retuned; final focused25pass observed separately.'},
    'preservation':'Actual ABI and fourteen full-compile tariff assertions are present in the exact private group roster in both complete configurations. Entire old suite pass-name multisets remain, with exactly the selected25 names added. Existing caps and runtime paths are source-bound unchanged.',
    'documentation':{'file':bind(doc),'status':'clear','review':'Exact validation counts, parent outcomes, two disclosed test-helper corrections, x86_64 Linux layout qualification, fourteen tariff observations and replay record preservation agree. No full conformance, security, GPU-device or performance claim. The compact archive explanation agrees with select-evidence.py selection design; publication/archive creation is root-owned and not claimed executed by this review.','selector_source':bind(base/'root/select-evidence.py')},
    'findings':[],
    'limitations':['This reviewer ran no project/compiler/test/browser code; validation execution is root-owned and reconciled from bound receipts.','Failed parent groups do not establish observations of their later rows.','Publication/archive packaging is separate from validation.'],
    'review_helper':bind(base/'root/review-final-validation.py'),
}
(base/'root/final-validation-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(base/'root/final-validation-review.json')))
