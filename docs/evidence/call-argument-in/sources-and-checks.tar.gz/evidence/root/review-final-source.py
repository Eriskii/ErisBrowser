from pathlib import Path
import json,hashlib,re,difflib
B=Path('/tmp/eris-call-argument-in-1');W=B/'worktree';D=B/'tests-private-3'
private='src/script/parser/driver/expressions/argument_in_context_tests.rs';public='src/script/call_argument_in_tests.rs'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
def read(n):return json.loads((B/n).read_text())
def verify(obj):
 if isinstance(obj,dict):
  if 'path' in obj and 'sha256' in obj:
   p=Path(obj['path']);assert h(p)==obj['sha256'],p
   if 'bytes' in obj:assert p.stat().st_size==obj['bytes'],p
  for v in obj.values():verify(v)
 elif isinstance(obj,list):
  for v in obj:verify(v)
def save(p,obj):
 assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n');print(json.dumps(ref(p)))
raw=read('source-raw.json')['source_sha256'];one=read('source1.json')['source_sha256'];two=read('source2.json')['source_sha256'];parent=read('source-parent-tests.json')['source_sha256']
assert set(raw)==set(one)==set(two)==set(parent) and len(two)==1238
assert [r for r in one if one[r]!=two[r]]==[private]
for r,v in two.items():assert h(W/r)==v,r
def source1(r):return D/'before-formatted'/r if r==private else W/r
for r,v in one.items():assert h(source1(r))==v,r
changed=[r for r in raw if raw[r]!=one[r]]
assert set(changed)=={'src/script/parser/driver/expressions.rs',public,private}
assert set(r for r in raw if parent[r]!=raw[r])=={'src/script/parser/driver.rs','src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs'}
for p in (B/'unformatted').rglob('*.rs'):assert h(p)==raw[str(p.relative_to(B/'unformatted'))]
ph=read('production-parser-1/source-ready.json');verify(ph)
for row in ph['paths']:assert row['raw']['sha256']==raw[row['relative']]
dh=read('production-driver-1/source-ready.json');verify(dh);assert dh['after']['sha256']==raw[dh['relative']]==two[dh['relative']]
assert h(B/'tests-public-1/raw'/public)==raw[public]
assert h(B/'tests-private-2/raw'/private)==raw[private]
# Lexical comparison only, with full literal bytes retained. No Rust execution.
pat=re.compile(r'(?P<space>\s+)|(?P<comment>//[^\n]*|/\*[\s\S]*?\*/)|(?P<raw>r(?P<hashes>\#*)"[\s\S]*?"(?P=hashes))|(?P<string>b?"(?:\\[\s\S]|[^"\\])*")|(?P<char>\'(?:\\.|[^\'\\\n])\')|(?P<ident>[A-Za-z_][A-Za-z_0-9]*)|(?P<number>\d[\w.]*)|(?P<other>.)')
def tokens(s):return [(m.lastgroup,m.group()) for m in pat.finditer(s) if m.lastgroup not in ('space','comment')]
checks=[]
for r in changed:
 a=(B/'unformatted'/r).read_text();z=source1(r).read_text();notes=[]
 if r==private:
  ah,ab=a.split('fn setup',1);zh,zb=z.split('fn setup',1)
  assert ah=='//! Frozen context/charge controls through existing parser entry points.\nuse super::*;\nuse super::super::{run, Kind, Output, Transition, functions, statements};\nuse std::mem::size_of;\n#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;\n\n'
  assert zh=='//! Frozen context/charge controls through existing parser entry points.\nuse super::super::{Kind, Output, Transition, functions, run, statements};\nuse super::*;\n#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;\nuse std::mem::size_of;\n\n'
  a='fn setup'+ab;z='fn setup'+zb;notes.append('Use ordering/brace-list sorting; names and cfg exact.')
 x=tokens(a);y=tokens(z);lits=lambda ts:[v for k,v in ts if k in ('raw','string','char','number')]
 assert lits(x)==lits(y),r
 comma=blockopen=blockclose=0
 for tag,i,j,k,l in difflib.SequenceMatcher(a=x,b=y,autojunk=False).get_opcodes():
  if tag=='equal':continue
  if tag=='insert' and y[k:l]==[('other',',')] and y[l][1] in (')',']','}'):comma+=1
  elif r==private and tag=='insert' and y[k:l]==[('other','{')] and [v for _,v in y[l:l+7]]==['(','state','.','value',',','false',')']:blockopen+=1
  elif r==private and tag=='replace' and x[i:j]==[('other',',')] and y[k:l]==[('other','}')] and [v for _,v in y[k-7:k]]==['(','state','.','value',',','false',')']:blockclose+=1
  else:raise AssertionError((r,tag,x[i:j],y[k:l]))
 assert blockopen==blockclose==(1 if r==private else 0)
 checks.append({'relative':r,'raw_sha256':raw[r],'source1_sha256':one[r],'exact_literal_tokens':len(lits(x)),'added_trailing_commas':comma,'match_arm_block_wraps':blockopen,'other':notes})
j=read('tests-private-3/source-ready.json');verify(j)
s=read('tests-private-3/selection.json');verify(s);verify(read('tests-private-3/correction.json'))
old='                assert!(parser.is(if source == "(1)" { "1" } else { "x" }));\n'
new='''                if source == "(1)" {
                    assert!(matches!(&parser.tokens[parser.pos].kind, TokenKind::Number(value) if *value == 1.0));
                    assert_eq!(parser.tokens[parser.pos].offset, 1);
                } else {
                    assert!(parser.is("x"));
                    assert_eq!(parser.tokens[parser.pos].offset, 4);
                }
'''
for key in ['selected_raw','source1_minimal_import']:
 row=s[key];a=Path(row['before']['path']).read_text();z=Path(row['raw']['path']).read_text()
 assert a.count(old)==z.count(new)==1 and a.replace(old,new)==z and z.replace(new,old)==a
 assert re.findall(r'#\[test\]\s*fn\s+(\w+)',a)==re.findall(r'#\[test\]\s*fn\s+(\w+)',z)
 assert len(re.findall(r'#\[test\]',a))==10
assert s['selected_raw']['before']['sha256']==raw[private]
assert s['source1_minimal_import']['before']['sha256']==one[private]
assert tokens(Path(s['source1_minimal_import']['raw']['path']).read_text())==tokens((W/private).read_text())
peer={
 'status':'clear','hold':ref(D/'source-ready.json'),
 'scope':'Narrow source-only token-helper correction; no production or tariff change.',
 'checks':['All referenced source/diff/log hashes and lengths match.','Both raw and formatted replacements are exactly the selected one-assertion correction; exact reversal recovers each before file.','Parser::is/token_is recognizes unescaped Word and Symbol only; Number(1.0) cannot satisfy is("1"). Lexer keeps the token start byte.','For (1), the operand is Number(1.0) at byte1. For (...x), contiguous ellipsis leaves unescaped Word x at byte4. The corrected branches test the intended positions using the appropriate token domain.','Ten names, all source literals, fee/counter/context checks and every other assertion remain exact. Retained focused log records24 passed/1 fixture-domain assertion failure; no semantic expectation changes.'],
 'findings':[],'project_execution':False,'live_edits':False
}
q=D/'layout-review.json';save(q,peer)
review={
 'status':'clear','scope':'Final source2 composition, formatting and selected test-helper correction; source-only review.',
 'raw_inventory':ref(B/'source-raw.json'),'source1_inventory':ref(B/'source1.json'),'final_inventory':ref(B/'source2.json'),'inputs':1238,
 'production_holds':[ref(B/'production-parser-1/source-ready.json'),ref(B/'production-driver-1/source-ready.json')],
 'test_holds':[ref(B/'tests-public-1/source-ready.json'),ref(B/'tests-private-2/source-ready.json'),ref(D/'source-ready.json')],
 'source1_formatting':checks,
 'correction_peer':ref(q),
 'composition':['All1238 current hashes match source2. Raw inventory differs from frozen parent-plus-tests only in the three selected production paths; each raw equals its sealed hold. All six retained unformatted copies match source-raw.','Only expressions.rs and the two new test modules differ between raw and source1. Full literal bytes/order and remaining body tokens are exact after the enumerated harmless formatting changes.','Source1 to source2 changes only the private test module. It equals the selected hold3 minimal correction plus whitespace formatting; all production is byte-exact source1. Public15/private10 names and both registrations are retained.','Driver and legacy remain byte-exact to their production holds; expressions.rs only has a multiline NewArguments formatting change. The root run wrapper includes initial enter and every fallible exit, restores entry allow_in only on Err, and preserves successful Dynamic handoff.','No selected fee, cap, production behavior, source input literal or unrelated assertion changed. The one corrected assertion has a separately bound source rationale.'],
 'findings':[],'validation_limit':'No compiler/test execution by reviewer. Root owns observed outcomes; source1 focused failure is retained rather than treated as a passing run.',
 'project_execution':False,'live_edits':False
}
save(B/'root/final-source-review.json',review)
