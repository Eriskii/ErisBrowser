import hashlib, json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'tests-private-2'
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def verify_bindings(value):
    if isinstance(value, dict):
        if set(value) == {'path', 'bytes', 'sha256'}:
            assert bind(Path(value['path'])) == value, value['path']
        else:
            for child in value.values(): verify_bindings(child)
    elif isinstance(value, list):
        for child in value: verify_bindings(child)

hold = json.loads((H / 'source-ready.json').read_bytes())
verify_bindings(hold)
source = json.loads((A / 'source-parent-public.json').read_bytes())
for relative, digest in source['source_sha256'].items():
    assert bind(W / relative)['sha256'] == digest, relative
for entry in hold['existing_registration_patches']:
    target = W / entry['relative']
    before = Path(entry['before']['path']).read_bytes()
    after = Path(entry['raw']['path']).read_bytes()
    assert target.read_bytes() == before
    assert before.startswith(b'use super::*;\n')
    assert after == before.replace(b'use super::*;\n', b'use super::*;\n\n#[cfg(test)]\nmod argument_in_context_tests;\n', 1)
    target.write_bytes(after)
    source['source_sha256'][entry['relative']] = bind(target)['sha256']
for entry in hold['new_test_modules']:
    target = W / entry['relative']
    assert not target.exists()
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(Path(entry['raw']['path']).read_bytes())
    source['source_sha256'][entry['relative']] = bind(target)['sha256']
source['scope'] = 'Published parent plus frozen 15 public and 10 private groups; cfg(test) registrations only; no production changes.'
(A / 'source-parent-tests.json').write_text(json.dumps(source, indent=2) + '\n')
(A / 'root/private-import.json').write_text(json.dumps({'hold': bind(H / 'source-ready.json'), 'source': bind(A / 'source-parent-tests.json'), 'groups': 10}, indent=2) + '\n')
print(json.dumps({'source_inputs': len(source['source_sha256']), 'private_groups': 10}))
