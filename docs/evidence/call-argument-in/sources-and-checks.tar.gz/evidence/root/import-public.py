import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-public-1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
assert sha(H/'source-ready.json')=='3ef9ec05496676aed913d9cf82a9c7066960c8e5b8480329751a15f28b7fe583'
hold=json.loads((H/'source-ready.json').read_bytes())
for b in hold['files']:assert bind(Path(b['path']))==b,b['path']
source=json.loads((A/'parent-source.json').read_bytes())
for r,h in source['source_sha256'].items():assert sha(W/r)==h,r
instructions=json.loads((H/'import-instructions.json').read_bytes())
new=instructions['new_file']['to'];registration=instructions['registration'];target=W/'src/script.rs'
assert not (W/new).exists() and sha(target)==registration['before']['sha256']
assert target.read_bytes()+registration['exact_text'].encode()==Path(registration['after']['path']).read_bytes()
(W/new).write_bytes(Path(instructions['new_file']['from']).read_bytes())
target.write_bytes(Path(registration['after']['path']).read_bytes())
for r in [new,'src/script.rs']:source['source_sha256'][r]=sha(W/r)
source['scope']='Published parent plus frozen15 public argument +In groups and one cfgtest registration; no production changes.'
(A/'source-parent-public.json').write_text(json.dumps(source,indent=2)+'\n')
(A/'root/public-import.json').write_text(json.dumps({'hold':bind(H/'source-ready.json'),'source':bind(A/'source-parent-public.json'),'groups':15,'files':[new,'src/script.rs']},indent=2)+'\n')
print(json.dumps({'source_inputs':len(source['source_sha256']),'public_groups':15}))
