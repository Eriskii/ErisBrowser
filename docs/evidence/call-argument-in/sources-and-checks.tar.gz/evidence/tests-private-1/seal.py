from pathlib import Path
import json,hashlib,difflib,re
B=Path('/tmp/eris-call-argument-in-1/tests-private-1');P=B.parent;W=P/'worktree'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(rel,text):
 p=B/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);return p
def dump(rel,value):return put(rel,json.dumps(value,indent=2)+'\n')
inv=json.loads((P/'source-parent-public.json').read_text())['source_sha256']
rel='src/script/parser/driver/expressions.rs';before_text=(W/rel).read_text()
assert bind(W/rel)['sha256']==inv[rel]=='4c38edd52699467a04b98beaaf8ee70c8f0365eb047541b43333f0ac821fa2b2'
assert 'argument_in_layout_probe' not in before_text
before=put('before/'+rel,before_text)
registration='\n#[cfg(test)]\nmod argument_in_context_tests;\n'
registered=before_text.replace('use super::*;\n','use super::*;\n'+registration,1)
assert registered.replace(registration,'',1)==before_text
raw_registration=put('raw-registration/'+rel,registered)
diff=put('diffs/src__script__parser__driver__expressions.rs.patch',''.join(difflib.unified_diff(before_text.splitlines(True),registered.splitlines(True),fromfile=rel,tofile=rel)))
rawrel='src/script/parser/driver/expressions/argument_in_context_tests.rs';raw=B/'raw'/rawrel
names=re.findall(r'#\[test\]\s*fn (\w+)\(',raw.read_text());assert len(names)==10
predictions=[
 ('fail','First false-entry nonempty call must enable +In; parent leaves false.',14),
 ('fail','First false-entry call owner must already be active before child parsing; parent leaves false. Later close-fee rows are not claimed reached on parent.',32),
 ('fail','First false-entry direct inner in is rejected by parent; expected successful Member before outer separator.',16),
 ('fail','First f((1 syntax failure leaves parent allow_in=true instead of run-entry false.',8),
 ('pass','Preservation: exact root/ellipsis prefix refusals and counters already hold; final original flag also holds on parent because parent argument owner never enabled it.',12),
 ('fail','First existing Cover activation followed by dispatch refusal leaves parent flag true rather than false. Later storage cuts remain frozen source oracles, not reached-parent claims.',8),
 ('pass','Existing successful Dynamic Parameters/body/finish context handoff is preserved.',4),
 ('fail','After preserved1/2 cuts, first a=( parameters failure leaves parent active true rather than false; later error rows remain independently frozen.',12),
 ('pass','Existing actual parent types match both selected mirrors. Exact layout group runs only on x86_64 Linux.',1),
 ('pass','Fourteen full-compile rows were independently observed on both parent toolchains before production. Runs only on x86_64 Linux.',14),
]
roster=dump('roster.json',{
 'module':rawrel,'groups':10,'all_groups_use_existing_parent_apis':True,
 'groups_detail':[{'name':name,'parent_compiles':True,'expected_parent_outcome':outcome,'reason':why,'fixture_rows':rows,'abi_gate':'x86_64 Linux' if i>=8 else None} for i,(name,(outcome,why,rows)) in enumerate(zip(names,predictions))],
 'selected_abi_expected_groups':{'pass':4,'fail':6},'other_abis':'Two exact-layout/full-tariff groups are cfg-excluded; remaining eight use symbolic type-dependent cuts.',
 'baseline_claim':'Source prediction only for these ten groups; no private candidate/parent module executed by this author. Public15 and root layout/tariff probes are separate observed evidence.'})
ledger=dump('ledger.json',{
 'selection':bind(P/'root/plan-selection-2.json'),
 'new_fee':0,'new_caps':0,'new_runtime_or_parser_fields':0,
 'symbols':{'R':'32+4*sizeof(Kind)','G':'32+8*sizeof(Kind)','E':'32+sizeof(ExprId)','P':'32+128*sizeof(code::Expr)'},
 'owner_close':{'ordinary_exact_work':4,'ordinary_final_emit_refusal_work':3,'spread_exact_work':5,'spread_final_emit_refusal_work':4,'heap':'E','sequence':'prepaid dispatch1; optional warm marker append1; cold edge append1+growth1 and E; consume close/restore; warm parent record1. All records fit an already admitted page. Both close branches use the same stages.'},
 'root_prefix_rows':[
  {'source':'(1)','work':0,'heap':'R','pos':0,'allocated':'MAX_HEAP-R'},
  {'source':'(1)','work':1,'heap':'R','pos':0,'allocated':'MAX_HEAP'},
  {'source':'(1)','work':2,'heap':'R','pos':1,'allocated':'MAX_HEAP'},
  {'source':'(...x)','work':9,'heap':'R','pos':1,'allocated':'MAX_HEAP'},
  {'source':'(...x)','work':10,'heap':'R','pos':4,'allocated':'MAX_HEAP'},
  {'source':'(1)','work':1,'heap':'R-1','pos':0,'allocated':'MAX_HEAP+1'}],
 'root_prefix_sequence':'Initial vector work1/R; root dispatch1; optional ellipsis8; then child dispatch1. Exact2/10 leave zero before the next child dispatch. Work9 leaves7 for ellipsis8, so dots remain. Every listed row returns Resource; steps end0.',
 'other_refusals':[
  {'source':'(','root':'Primary','available_work':2,'available_heap':'R','consumed_work':2,'allocated':'MAX_HEAP','pos':1,'records':0,'reason':'Existing Cover enables true; next child dispatch refuses. Generic Err epilogue restores original flag.'},
  {'source':'((','root':'Primary','available_work':'MAX_STEPS','available_heap':'R','consumed_work':10,'allocated':'MAX_HEAP+G','pos':1,'records':0,'reason':'Initial enter1 plus four dispatches Primary/Assignment/Binary/Unary=5; Unary next-child admission has len4, growth work5 and eight-slot G. Heap refuses before child publication.'},
  {'source':'(1)','root':'PostfixResume','available_work':'MAX_STEPS','available_heap':'R+E-1','consumed_work':7,'allocated':'MAX_HEAP+1','pos':2,'records':2,'reason':'Initial1+postfix1+Assignment1+literal append1+Arguments1+edge append1+growth1. Calee record preexists; literal commits before edge heap refusal.'},
  {'source':'(1)','root':'PostfixResume,128 warm records','available_work':'MAX_STEPS','available_heap':'R+P-1','consumed_work':5,'allocated':'MAX_HEAP+1','pos':2,'records':128,'reason':'Initial1+postfix1+Assignment1+append1+new page1. Existing directory has spare capacity; page heap refuses before record publication.'}],
 'dynamic_empty_parameters':{'work1':'Initial R buffer admitted; dispatch refuses before Context::enter, original flag/depth0.','work2':'Initial1+Dynamic dispatch1 yield Parameters, active flagtrue/depth1.','heap':'R','both_final':'steps0, allocatedMAX_HEAP'},
 'fixture_provenance':'Lexer, callee and child-record setup pay the real existing budget. Isolated reset happens only at the stated private boundary. paid_step pays the existing driver dispatch1 before the actual expressions::step; it does not implement a continuation loop. Parent/child states come from real begin_owner and run; the tests never construct new-arity Arguments/NewArguments. Scope/capacity and parser state after refused work are asserted before any later fixture reset.',
 'unchanged_helpers':'Original ellipsis8, ExprId append/growth, record-page growth, root/child continuation reserve, and Runtime spread tariffs stay untouched. No old test migrations.'})
obs=json.loads((P/'root/parent-tariff-observations.json').read_text())
assert obs['observations'][0]['rows']==obs['observations'][1]['rows']
source_by_id=dict(obs['sources'])
for row in obs['observations'][0]['rows']:
 needle='("'+source_by_id[row['id']]+'", '+str(row['work'])+', '+str(row['heap'])+'),'
 assert needle in raw.read_text(),needle
oracles=dump('oracles.json',{
 'public_nesting':'Inner in must be consumed under either entry flag. Outer in remains a separator when entryfalse and becomes BinaryChain when entrytrue. Empty/no-parentheses preserve the same rule.',
 'syntax':[{'source':'f((1','message':"expected ','",'offset':4},{'source':'new C((1','message':"expected ','",'offset':8},{'source':'f(1,. . .x)','message':'invalid argument spread ellipsis','offset':6}],
 'unsupported':{'source':'f((function*(){}))','message':'generator functions are not implemented','offset':None},
 'dynamic':'For either outer flag, successful Parameters and body remain active true; finish restores the exact saved outer flag and normal function_depth/new_target. Parameter-error run restores its original flag but keeps active context fields; body-error run restores true, regardless of State.saved false. No finish call on failed body and no failed-parser reuse.',
 'shape_observations':bind(P/'root/layout-observations.json'),'shape_expectations_x86_64_linux':{'Frame':[72,8],'Kind':[112,8],'Transition':[224,8],'Output':[88,8],'initial_buffer':480,'heap_ceiling':74898},
 'parent_full_compile_observations':bind(P/'root/parent-tariff-observations.json'),'parent_tariff_peer':bind(P/'root/parent-tariff-html-review.json'),'full_compile_rows':obs['observations'][0]['rows'],'source_by_id':source_by_id,
 'limits':'Parent fee observations precede candidate code; no new test expectation was read from candidate execution. Original sources/strict flags are exact. Fixture rows are not all claimed reached by a failing parent group.'})
outline=json.loads((P/'private-outline-1/outline.json').read_text())
prior=[x for x in outline['source_bindings'] if x['path'].endswith('/parser/driver/expressions.rs')][0]
clarification=dump('outline-binding-addendum.json',{
 'retained_outline':bind(P/'private-outline-1/source-ready.json'),'retained_expression_binding':prior,
 'context':'The retained outline was written while root temporarily registered the layout probe in expressions.rs. Its expression binding is that temporary test-only context, not the final restored parent. Its source-derived semantics/fees did not depend on the probe.',
 'selected_restored_expression':bind(before),'selected_parent_public_inventory':bind(P/'source-parent-public.json'),
 'correction':'All final test source joins use restored4c38edd52699467a04b98beaaf8ee70c8f0365eb047541b43333f0ac821fa2b2. No probe declaration occurs in selected before/raw-registration. Original outline is preserved unchanged.'})
source_rows=[]
for path in ['src/script/parser/driver/expressions.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','src/script/parser.rs','src/script/code.rs','src/script/code/records.rs','src/script/parser/call_spread_cut_tests.rs']:
 assert bind(W/path)['sha256']==inv[path],path
 copy=put('source-inputs/'+path,(W/path).read_text())
 source_rows.append({'relative':path,'snapshot':bind(copy),'parent_public_sha256':inv[path]})
source_map=dump('source-bindings.json',{'parent_base':bind(P/'parent-source.json'),'current_parent_public':bind(P/'source-parent-public.json'),'selected':bind(P/'root/plan-selection-2.json'),'files':source_rows,'old_migration_audit':'rg Frame::Arguments/NewArguments finds only six current production sites in expressions.rs. Tests use .. patterns and existing helpers, so no new tuple arity dependency or historical test migration is needed. Actual shape expectations remain unchanged and ABI-qualified.'})
notes=put('import-instructions.txt','''All ten private groups compile against the published parent: the module uses existing run, step, Frame roots, helpers and .. variant patterns. No proposed Arguments tuple fields are constructed or accessed. On selected x86_64 Linux, source predicts4pass/6fail; a failure stops that group, so later rows are not parent-observed claims. Two ABI-specific groups are excluded elsewhere.
Root may import only the raw module and one cfg(test) expressions registration after independent peer, run the exact module on parent, and retain logs before production. Preserve the raw bytes/ledger/oracles; candidate observations cannot retune them. Root owns formatting/import/build/run.
Registration before is the fully restored source-parent-public form4c38edd5, not either temporary layout/tariff probe. The retained outline's probe-time source binding is explicitly qualified in outline-binding-addendum.json.
No production files or existing tests are changed by this hold beyond the test-only registration. Existing AT tests/cuts remain exact. Counter resets are fixture setup boundaries only and never recovery of a failed production parse. Dynamic tests intentionally make no complete context rollback or parser reuse claim.
''')
manifest={
 'schema':'eris-argument-in-private-tests-hold-v1','status':'frozen-before-production',
 'base':'8159301e555010f4c7879e1fbd31c9cfc784b686','parent_public_inventory':bind(P/'source-parent-public.json'),'selection':bind(P/'root/plan-selection-2.json'),
 'new_test_modules':[{'relative':rawrel,'raw':bind(raw),'groups':10}],
 'existing_registration_patches':[{'relative':rel,'before':bind(before),'raw':bind(raw_registration),'diff':bind(diff)}],
 'support':[bind(p) for p in [roster,ledger,oracles,clarification,source_map,notes]],
 'groups':10,'parent_eligible_groups':10,'selected_abi_expected_parent':{'pass':4,'fail':6},'old_test_migrations':[],
 'execution':False,'live_edits':False,'production_authored':False,
 'author_source_review':'Complete staged ledger and exact existing API visibility read. One helper shadowing/import cleanup was resolved in the unsealed draft; no test or compiler execution occurred. All selected source bindings match restored parent-public inventory.'
}
manifest['authoring_helper']=bind(B/'seal.py')
out=dump('source-ready.json',manifest);print(json.dumps(bind(out)))
