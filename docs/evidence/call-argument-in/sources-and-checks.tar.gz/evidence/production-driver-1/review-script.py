from pathlib import Path
import hashlib, json, difflib

folder = Path('/tmp/eris-call-argument-in-1/production-driver-1')
base = folder.parent

def binding(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

manifest = json.loads((folder/'source-ready.json').read_text())
for name in ['before', 'after', 'diff', 'selection', 'private_freeze']:
    assert binding(manifest[name]['path']) == manifest[name]
before = (folder/'before.rs').read_text()
after = (folder/'after.rs').read_text()
header = "fn run(parser: &mut Parser<'_>, root: Kind) -> Result<Output> {\n"
tail = '\n}\n\n#[cfg(test)]\nmod tests {'
assert before.count(header) == after.count(header) == 1
bprefix, btail = before.split(header)
aprefix, atail = after.split(header)
bbody, bsuffix = btail.split(tail, 1)
abody, asuffix = atail.split(tail, 1)
assert bprefix == aprefix and bsuffix == asuffix
start = '    let entry_in = parser.allow_in;\n    let result = (|| {\n'
end = '\n    })();\n    // Successful Dynamic parameters deliberately hand context to the body run.\n    // On errors, restore only this invocation\'s grammar flag; quotas stay spent.\n    if result.is_err() {\n        parser.allow_in = entry_in;\n    }\n    result'
assert abody.startswith(start) and abody.endswith(end)
inner = abody[len(start):-len(end)]
assert all(line.startswith('    ') or not line for line in inner.splitlines())
unindented = '\n'.join(line[4:] if line else line for line in inner.splitlines())
assert unindented == bbody
assert before.replace(bbody, abody, 1) == after
diff = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='before/src/script/parser/driver.rs', tofile='after/src/script/parser/driver.rs'))
assert diff == (folder/'change.patch').read_text()
inventory = json.loads((base/'source-parent-public.json').read_text())
assert inventory['source_sha256']['src/script/parser/driver.rs'] == manifest['before']['sha256']
assert bbody.count('enter(parser, &mut frames, root)?;') == 1
assert bbody.count('parser.compile_budget.work(1).map_err(regexp_error)?;') == 1

review = {
    'status': 'clear_source_only',
    'scope': 'Only production-driver-1 driver::run local Result closure and invocation-entry allow_in error restoration.',
    'hold': binding(folder/'source-ready.json'),
    'bindings': [manifest[name] for name in ['before','after','diff','selection','private_freeze']] + [binding(base/'source-parent-public.json'), binding(base/'root/plan-selection-1.json')],
    'mechanical_checks': {
        'manifest_bindings_match': True,
        'before_matches_restored_parent_inventory': True,
        'prefix_and_suffix_byte_identical': True,
        'complete_closure_body_dedents_byte_exactly_to_original_run_body': True,
        'whole_file_reconstruction_exact': True,
        'unified_diff_reconstructed_exactly': True,
    },
    'source_findings': [],
    'error_coverage': [
        'entry_in captured before initial enter; initial vector work/heap/reserve failures return through the closure and epilogue',
        'all four step dispatch result paths and the existing work1 failure remain inside the closure',
        'child enter failures also pass through the same epilogue',
        'only allow_in is restored on Err; position, diagnostics, spent counters, function depth, strictness and other context remain untouched',
        'no continuation walk or post-failure resource admission is added',
    ],
    'success_and_dynamic': [
        'Ok returns the original Output and does not overwrite allow_in',
        'successful Dynamic Parameters therefore retains active context for the separate body run',
        'the body run captures its own entry flag; functions::finish remains the separate successful Context restoration owner',
        'dynamic_function and all callers are byte-identical; lexing between runs and finish failures remain outside the run epilogue',
    ],
    'accounting': 'The original complete dispatch/reserve/body sequence is byte-preserved modulo indentation. No new dispatch, reserve, Vec allocation, record, handle clone, recursion or fixed debit is introduced. Scalar capture/classification/restoration follows root\'s explicitly selected zero-additional fixed cleanup convention; this review does not reinterpret it as CPU operation counting.',
    'private_controls_join': 'Selected hold2 exercises root admission, step/child/storage refusal, syntax and Unsupported errors, successful Dynamic Parameters/body/finish and independent body error restoration. Tests remain unexecuted by this reviewer; parent or candidate observations belong to root.',
    'limits': 'No panic restoration, complete context rollback, failed-parser reuse, compiler result or measured stack claim.',
    'execution': False,
    'live_edits': False,
    'review_helper': binding(folder/'review-script.py'),
}
(folder/'script-review.json').write_text(json.dumps(review, indent=2)+'\n')
print(json.dumps(binding(folder/'script-review.json')))
