from pathlib import Path
import difflib, hashlib, json, re
B=Path('/tmp/eris-call-argument-in-1')
D=B/'production-parser-1'
assert not (D/'source-ready.json').exists()
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def write(name,obj):
 p=D/name; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,indent=2)+'\n'); return p
files=['src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs']
parent=json.loads((B/'parent-source.json').read_text())
registered=B/'tests-private-1/raw-registration'/files[0]
assert (D/'before'/files[0]).read_bytes()==registered.read_bytes()
assert sha(D/'before'/files[1])==parent['source_sha256'][files[1]]
for r in files: assert (D/'before'/r).read_bytes()==(B/'worktree'/r).read_bytes()
e=(D/'raw'/files[0]).read_text(); eb=(D/'before'/files[0]).read_text()
l=(D/'raw'/files[1]).read_text(); lb=(D/'before'/files[1]).read_text()
assert e.count('mod argument_in_context_tests;')==eb.count('mod argument_in_context_tests;')==1
assert e.count('Arguments(Postfix, Vec<ExprId>, bool, bool, bool)')==1
assert e.count('NewArguments(ExprId, Vec<ExprId>, bool, bool, bool)')==1
assert e.count('let current_spread = argument_spread(p)?;\n            let saved_in = p.allow_in;\n            p.allow_in = true;')==1
assert e.count('let current_spread = argument_spread(p)?;\n        let saved_in = p.allow_in;\n        p.allow_in = true;')==1
for s in ['call_done(p, state, arguments, has_spread)','new_done(p, constructor, arguments, has_spread)']:
 assert len(re.findall(r'p\.allow_in = saved_in;\n\s+'+re.escape(s),e))==2
assert l.count('let result: Result<()> = (|| {')-lb.count('let result: Result<()> = (|| {')==2
assert len(re.findall(r'self\.allow_in = saved_in;\n\s+result\?;',l))-len(re.findall(r'self\.allow_in = saved_in;\n\s+result\?;',lb))==2
# Named explicit resource calls in each owned source are byte-identical in order.
fee_pattern=r'\b(?:compile_budget|budget)\.(?:work|allocate|heap|reserve)\([^\n]*'
for a,z in [(eb,e),(lb,l)]: assert re.findall(fee_pattern,a)==re.findall(fee_pattern,z)
rows=[]
for r in files:
 before=D/'before'/r; raw=D/'raw'/r
 p=D/'diffs'/(r.replace('/','__')+'.patch'); p.parent.mkdir(exist_ok=True)
 p.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),raw.read_text().splitlines(True),fromfile='a/'+r,tofile='b/'+r)))
 rows.append({'relative':r,'before':ref(before),'raw':ref(raw),'diff':ref(p)})
notes=write('implementation-notes.json',{
 'scope':'Only nonempty ordinary and new argument lists gain their specified +In operand context. Two external parser files; no driver wrapper, Runtime or test edits.',
 'active':[
  'Append saved_in as the third bool of Arguments/NewArguments. The first two bool meanings and field ordering remain unchanged.',
  'Recognize the first argument ellipsis at the existing fee/token boundary before capturing allow_in and enabling true.',
  'Keep the saved owner flag across later items; their operand context stays true.',
  'Both ordinary and trailing-comma close paths restore saved_in before call_done/new_done, including final-emission refusal.',
  'Empty arguments and no-parenthesis new keep their prior routes. Nested owners save true and restore true while their enclosing owner restores its own value.',
  'Errors before successful owner close require the separately root-owned driver::run Err epilogue. This hold alone does not supply that error restoration.'
 ],
 'legacy':[
  'Recognize the first ellipsis before saving/enabling allow_in, preserving its early refusal behavior.',
  'A local Result<()> closure runs the existing expression, push, close/comma and later-ellipsis loop. Restore saved_in before propagating the closure result.',
  'The later ellipsis check moves to the preceding iteration tail; it still occurs exactly once after a nonterminal comma and before the next expression. No empty/trailing-close recognition is added.',
  'Existing expression/new recursion entry points, chain/depth guards, vector pushes, AST construction and async-arrow checks are retained.'
 ],
 'resource_contract':{
  'new_fixed_debits':0,
  'basis':'Root-selected bounded grammar transition/error-cleanup accounting; existing dispatch, spread-marker, edge-growth and emission charges remain.',
  'existing_ellipsis_debit':8,
  'allocations':'No new owned heap buffer or allocation call. Existing argument vectors and expression pushes unchanged.',
  'shape':'Selected root prospective x86_64 Linux mirrors observed Frame72/Kind112/Transition224, initial480 and limit74898. Final production shape must still be checked by root; this draft makes no actual stack/RSS or timing claim.',
  'caps':'No limit or quota changes.'
 },
 'preserved_limits':['Only run-entry allow_in rollback on active failure is expected; parser tokens, budgets and all other contexts are not generally rolled back.','Successful Dynamic Parameters-to-body context handoff is owned by the unchanged driver protocol and root error-only wrapper.','Computed-member and conditional grammar context questions remain outside this change.'],
 'static_checks':['Both before snapshots matched current worktree at sealing.','Registered expression baseline matches the exact selected private hold1 registration retained by hold2.','Legacy before snapshot matches the published parent inventory.','Two third-bool fields, two entry activations and four close restorations checked.','Two legacy local-result closures and restore-before-propagate sequences checked.','Owned-source explicit budget call text/order and selected test registration retained.'],
 'execution':{'rust':False,'formatter':False,'tests':False,'engine':False,'git':False,'live_edits':False}
})
manifest={
 'schema':'eris-argument-in-parser-production-v1','status':'source-ready','base':parent['base'],
 'selected_semantics':ref(B/'root/plan-selection-1.json'),'selected_shape_and_fees':ref(B/'root/plan-selection-2.json'),
 'prospective_shape_observations':ref(B/'root/layout-observations.json'),
 'private_tests':ref(B/'tests-private-2/source-ready.json'),'public_tests':ref(B/'tests-public-1/source-ready.json'),
 'parent_inventory':ref(B/'parent-source.json'),
 'registered_expression_baseline':ref(registered),
 'paths':rows,
 'support':[ref(notes),ref(D/'seal.py')],
 'integration':'Replace exactly the two raw relative paths after checking before hashes. The expression raw includes the already-selected private test registration. Root composes driver::run Err restoration separately; import no other file from this hold.',
 'test_changes':[],'old_test_migrations':[],
 'validation':'Source/diff/hash checks only. Root owns compilation, formatting, tests and final actual layout checks.',
 'live_edits':False,'project_execution':False
}
p=write('source-ready.json',manifest)
print(json.dumps(ref(p),indent=2))
