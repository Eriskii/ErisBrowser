from pathlib import Path
import hashlib, json, difflib

base = Path('/tmp/eris-call-argument-in-1')
folder = base/'production-parser-1'

def binding(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

manifest = json.loads((folder/'source-ready.json').read_text())
verified=[]
def visit(obj):
    if isinstance(obj, dict):
        if {'path','bytes','sha256'} <= obj.keys():
            assert binding(obj['path']) == obj
            verified.append(obj)
        else:
            for value in obj.values(): visit(value)
    elif isinstance(obj, list):
        for value in obj: visit(value)
visit(manifest)
rows={row['relative']:row for row in manifest['paths']}
expr='src/script/parser/driver/expressions.rs'
legacy='src/script/parser_legacy.rs'
before_expr=Path(rows[expr]['before']['path']).read_text()
raw_expr=Path(rows[expr]['raw']['path']).read_text()
before_legacy=Path(rows[legacy]['before']['path']).read_text()
raw_legacy=Path(rows[legacy]['raw']['path']).read_text()

# Independent selected-delta reversal; full remaining file must be exact.
reverse=raw_expr
def replace_once_count(text, old, new, count=1):
    assert text.count(old)==count, (old, text.count(old), count)
    return text.replace(old,new)
reverse=replace_once_count(reverse,'// Argument flags are (any spread, current operand is spread, saved allow_in).','// Argument flags are (any spread so far, current operand is spread).')
reverse=replace_once_count(reverse,'Arguments(Postfix, Vec<ExprId>, bool, bool, bool)','Arguments(Postfix, Vec<ExprId>, bool, bool)')
reverse=replace_once_count(reverse,'NewArguments(ExprId, Vec<ExprId>, bool, bool, bool)','NewArguments(ExprId, Vec<ExprId>, bool, bool)')
for name, first in [('Arguments','state'),('NewArguments','constructor')]:
    reverse=replace_once_count(reverse,f'Frame::{name}({first}, mut arguments, has_spread, current_spread, saved_in)',f'Frame::{name}({first}, mut arguments, has_spread, current_spread)')
reverse=replace_once_count(reverse,'\n                p.allow_in = saved_in;\n','\n',2)
reverse=replace_once_count(reverse,'\n                    p.allow_in = saved_in;\n','\n',2)
reverse=replace_once_count(reverse,'                            saved_in,\n','',2)
for indent in ['            ','        ']:
    prefix='\n'+indent+'let current_spread = argument_spread(p)?;\n'
    reverse=replace_once_count(reverse,prefix+indent+'let saved_in = p.allow_in;\n'+indent+'p.allow_in = true;\n',prefix)
reverse=replace_once_count(reverse,'Frame::Arguments(state, Vec::new(), current_spread, current_spread, saved_in)','Frame::Arguments(state, Vec::new(), current_spread, current_spread)')
reverse=replace_once_count(reverse,'Frame::NewArguments(state.value, Vec::new(), current_spread, current_spread, saved_in)','Frame::NewArguments(state.value, Vec::new(), current_spread, current_spread)')
assert reverse==before_expr

# The two legacy loops differ only in indentation and destination vector.
def indent(text, spaces):
    return ''.join(' '*spaces+line+'\n' for line in text.splitlines())
old_template='''loop {
    let spread = self.is(".");
    if spread {
        self.argument_ellipsis()?;
    }
    let item = self.expression()?;
    VECTOR.push(if spread {
        Expr::SpreadArgument(Box::new(item))
    } else {
        item
    });
    has_spread |= spread;
    if self.eat(")") {
        break;
    }
    self.expect(",")?;
    if self.eat(")") {
        break;
    }
}'''
new_template='''let mut spread = self.is(".");
if spread {
    self.argument_ellipsis()?;
}
let saved_in = self.allow_in;
self.allow_in = true;
let result: Result<()> = (|| {
    loop {
        let item = self.expression()?;
        VECTOR.push(if spread {
            Expr::SpreadArgument(Box::new(item))
        } else {
            item
        });
        has_spread |= spread;
        if self.eat(")") {
            break;
        }
        self.expect(",")?;
        if self.eat(")") {
            break;
        }
        spread = self.is(".");
        if spread {
            self.argument_ellipsis()?;
        }
    }
    Ok(())
})();
self.allow_in = saved_in;
result?;'''
reverse=raw_legacy
for vector, spaces in [('arguments',20),('args',12)]:
    new=indent(new_template.replace('VECTOR',vector),spaces)
    old=indent(old_template.replace('VECTOR',vector),spaces)
    assert before_legacy.count(old)==1
    reverse=replace_once_count(reverse,new,old)
assert reverse==before_legacy

for row in rows.values():
    before=Path(row['before']['path']).read_text()
    raw=Path(row['raw']['path']).read_text()
    patch=Path(row['diff']['path']).read_text()
    lines=patch.splitlines()
    assert lines[0].startswith('--- ') and lines[1].startswith('+++ ')
    actual=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile=lines[0][4:],tofile=lines[1][4:]))
    assert actual==patch
parent=json.loads((base/'parent-source.json').read_text())['source_sha256']
assert rows[legacy]['before']['sha256']==parent[legacy]
assert rows[expr]['before']['sha256']==manifest['registered_expression_baseline']['sha256']
assert raw_expr.count('mod argument_in_context_tests;')==1

review={
    'status':'clear_source_only',
    'hold':binding(folder/'source-ready.json'),
    'scope':'Exactly active expressions.rs argument-owner context and cfg(test) legacy parser argument-list closure.',
    'verified_bindings':verified,
    'mechanical_proofs':[
        'All source-ready path/length/hash bindings match.',
        'Exact reversal of the selected two bool fields, six argument-frame sites, two entry activations and four close restorations reconstructs the complete active before file.',
        'Independent old/new legacy loop templates reconstruct both full loop transformations and recover the complete legacy before file.',
        'Both unified diffs regenerate byte-exactly.',
        'Legacy before matches published parent; expressions before matches the selected registered private baseline. Test registration is retained.'
    ],
    'source_findings':[],
    'active_checks':[
        'First fallible argument_spread remains before capture and enable at both nonempty entries; empty and no-parenthesis paths do not mutate allow_in.',
        'The third bool is appended after existing spread flags, never repurposes either; both comma paths retain the original saved_in.',
        'Nested argument owners save active true and restore it; the enclosing owner separately restores its own surrounding flag.',
        'All four closing branches restore before call_done/new_done, their fallible final record emission, async-arrow diagnosis and postfix continuation.',
        'Earlier item/marker/list/comma/ellipsis errors rely on the separately reviewed driver::run error epilogue. This parser hold is not claimed sufficient alone.'
    ],
    'legacy_checks':[
        'First ellipsis recognition precedes context activation and retains its original early-error behavior.',
        'The first spread probe is moved before the closure; later probes are at the preceding iteration tail, after the same comma and nontrailing-close tests, immediately before the next expression.',
        'Every fallible expression/comma/later-ellipsis operation is inside Result<()> closure; restore executes before result? on success and error.',
        'Existing depth/chain guards, recursive expression entry points, pushes, parent construction and async-arrow checks are unchanged. No new recursive grammar helper exists.',
        'Legacy is cfg(test); its own allocation policy does not establish production resource accounting.'
    ],
    'accounting_and_scope':'No explicit tariff, dispatch, reserve, owned buffer, cap, Runtime or Parser field, marker/edge/page path changes. Scalar owner capture/carry/restoration uses the explicitly selected existing bounded transition convention. Proposed ABI sizes were independently measured but final candidate measurement remains root-owned. Computed-member and conditional grammar paths are byte-preserved.',
    'related_driver_review':binding(base/'production-driver-1/script-review.json'),
    'parent_baseline_reference':binding(base/'root/parent-private-baseline.json'),
    'validation_scope':'Source-only review; no compilation, execution, formatter, live edit or final candidate observation.',
    'review_helper':binding(folder/'review-script.py')
}
(folder/'script-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(binding(folder/'script-review.json')))
