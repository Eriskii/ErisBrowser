from pathlib import Path
import hashlib,json,difflib
B=Path('/tmp/eris-call-argument-in-1/layout-probe-1');P=B.parent;W=P/'worktree'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(rel,text):
 p=B/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);return p
def dump(rel,data):return put(rel,json.dumps(data,indent=2)+'\n')
inventory=json.loads((P/'parent-source.json').read_text())['source_sha256']
exprrel='src/script/parser/driver/expressions.rs'
expr=(W/exprrel).read_text();driver=(W/'src/script/parser/driver.rs').read_text()
def definition(src,start):
 a=src.index(start);z=src.index('\n}',a)+2;return src[a:z]
frame=definition(expr,'pub(super) enum Frame {')
kind=definition(driver,'enum Kind {')
transition=definition(driver,'enum Transition {')
baseline=frame.replace('pub(super) enum Frame {','enum BaselineExpressionFrame {',1)
proposed=baseline.replace('enum BaselineExpressionFrame {','enum ProposedExpressionFrame {',1)
for old,new in [('Arguments(Postfix, Vec<ExprId>, bool, bool),','Arguments(Postfix, Vec<ExprId>, bool, bool, bool),'),('NewArguments(ExprId, Vec<ExprId>, bool, bool),','NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),')]:
 assert proposed.count(old)==1;proposed=proposed.replace(old,new,1)
proposed=proposed.replace('// Argument flags are (any spread so far, current operand is spread).','// Flags: any spread, current operand is spread, saved outer allow_in.')
bk=kind.replace('enum Kind {','enum BaselineKind {',1).replace('Expression(expressions::Frame)','Expression(BaselineExpressionFrame)',1)
pk=kind.replace('enum Kind {','enum ProposedKind {',1).replace('Expression(expressions::Frame)','Expression(ProposedExpressionFrame)',1)
bt=transition.replace('enum Transition {','enum BaselineTransition {',1).replace('Again(Kind)','Again(BaselineKind)').replace('Child(Kind, Kind)','Child(BaselineKind, BaselineKind)')
pt=transition.replace('enum Transition {','enum ProposedTransition {',1).replace('Again(Kind)','Again(ProposedKind)').replace('Child(Kind, Kind)','Child(ProposedKind, ProposedKind)')
header='''//! Prospective +In argument-context layout only; no production implementation.
//! Full enum variants/order come from the frozen parent. Neighboring payload
//! types are the actual parent types, not substituted or stripped mirrors.
//! Only proposed Arguments/NewArguments append one saved_in bool each.
#![allow(dead_code)]
use super::*;
use super::super::{Body, Kind, Output, Transition, functions, statements};
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "ARGUMENT_IN_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn same<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}

'''
body='''#[test]
fn prospective_argument_in_parser_layout() {
    // Check the exact baseline reconstruction before measuring the proposal.
    // Proposed equality is deliberately not an assertion: root selects the
    // concrete size-dependent fees only after observing both configurations.
    same::<Frame, BaselineExpressionFrame>();
    same::<Kind, BaselineKind>();
    same::<Transition, BaselineTransition>();
    pair::<Frame, ProposedExpressionFrame>("parser.expressions.Frame");
    pair::<Kind, ProposedKind>("parser.driver.Kind");
    pair::<Transition, ProposedTransition>("parser.driver.Transition");
    pair::<Output, Output>("parser.driver.Output");
    pair::<Body, Body>("parser.driver.Body");
    pair::<Binary, Binary>("parser.expressions.Binary");
    pair::<Postfix, Postfix>("parser.expressions.Postfix");
    pair::<NewState, NewState>("parser.expressions.NewState");
    pair::<Cover, Cover>("parser.expressions.Cover");
    pair::<Array, Array>("parser.expressions.Array");
    pair::<Object, Object>("parser.expressions.Object");
    pair::<statements::Frame, statements::Frame>("parser.statements.Frame");
    pair::<statements::BodyFrame, statements::BodyFrame>("parser.statements.BodyFrame");
    pair::<functions::Frame, functions::Frame>("parser.functions.Frame");
    pair::<functions::State, functions::State>("parser.functions.State");
    println!(
        "ARGUMENT_IN_DERIVED_V1 name=parser.initial_kind_buffer current={} proposed={}",
        4 * size_of::<Kind>() + 32,
        4 * size_of::<ProposedKind>() + 32
    );
    println!(
        "ARGUMENT_IN_DERIVED_V1 name=parser.kind_heap_ceiling current={} proposed={}",
        MAX_HEAP / size_of::<Kind>(),
        MAX_HEAP / size_of::<ProposedKind>()
    );
}
'''
rawrel='src/script/parser/driver/expressions/argument_in_layout_probe.rs'
raw=put('raw/'+rawrel,header+'\n\n'.join([baseline,proposed,bk,pk,bt,pt])+'\n\n'+body)
registration='\n#[cfg(test)]\nmod argument_in_layout_probe;\n'
assert expr.startswith('use super::*;\n')
registered=expr.replace('use super::*;\n','use super::*;\n'+registration,1)
before=put('before/'+exprrel,expr)
reg=put('raw-registration/'+exprrel,registered)
diff=put('diffs/src__script__parser__driver__expressions.rs.patch',''.join(difflib.unified_diff(expr.splitlines(True),registered.splitlines(True),fromfile=exprrel,tofile=exprrel)))
assert registered.replace(registration,'',1)==expr
srcs=[]
for rel in ['src/script/parser/driver/expressions.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','src/script/parser.rs','src/script/code.rs','Cargo.toml','Cargo.lock']:
 assert bind(W/rel)['sha256']==inventory[rel]
 srcs.append({'relative':rel,'binding':bind(W/rel),'matches_parent_inventory':True})
source_map=dump('source-map.json',{
 'parent':'8159301e555010f4c7879e1fbd31c9cfc784b686',
 'parent_inventory':bind(P/'parent-source.json'),'selection':bind(P/'root/plan-selection-1.json'),
 'files':srcs,
 'extracted_definitions':[{'name':n,'source':r,'bytes':len(t.encode()),'sha256':hashlib.sha256(t.encode()).hexdigest()} for n,r,t in [('Frame',exprrel,frame),('Kind','src/script/parser/driver.rs',kind),('Transition','src/script/parser/driver.rs',transition)]],
 'construction':'Full baseline Frame copied in exact variant order; proposed differs in only two appended bool payloads plus explanatory comment. Kind replaces only Expression payload with the baseline/proposed complete Frame. Transition replaces only Kind payloads. Actual Output, Body, Binary,Postfix,NewState,Cover,Array,Object and sibling statement/function frame types are referenced unchanged.',
 'scope':'Probe is a cfg(test) child of expressions and accesses its actual private payload types. No production visibility change, stripped placeholder type, repr change, target-universal numeric assertion or Parser/Runtime field is introduced.',
 'registration_inverse':'Remove the one exact cfg(test) module block immediately after use super::*; to recover full before bytes.'})
expected=dump('expected-observations.json',{
 'group':'script::parser::driver::expressions::argument_in_layout_probe::prospective_argument_in_parser_layout',
 'groups':1,'pair_rows':15,'derived_rows':2,
 'required_comparisons':'BaselineExpressionFrame==actual Frame, BaselineKind==actual Kind, BaselineTransition==actual Transition for size and alignment. These assertions validate mirror construction, not equality of proposed and actual types.',
 'parent_historical_x86_64_linux_only':{'Frame':[72,8],'Kind':[112,8],'Transition':[224,8],'Output':[88,8],'initial_kind_buffer':480,'kind_heap_ceiling':74898},
 'proposed':'Observe rather than assert. Source padding suggests unchanged72/112/224, but this is a prospective hypothesis, not a measurement or a portable Rust representation promise.',
 'derived_formulas':{'initial_kind_buffer':'32+4*sizeof(Kind)','kind_heap_ceiling':'MAX_HEAP/sizeof(Kind)'},
 'compiler_configurations':'Root runs Rust1.88 default and current stable1.99 with the selected combined test262-host,vulkan-raster configuration on x86_64 Linux; retain exact commands/versions/target in observations.',
 'runtime':'No parser program, JavaScript, Runtime initialization or allocator-reserve fault is executed by the probe. It only queries layouts/prints/asserts baseline shape equality.'})
notes=put('import-instructions.txt','''Root-owned temporary import only.
1. Verify parent inventory and before expressions.rs hash. Copy the single raw module to its relative path and apply the exact registration-only patch; no other source edits.
2. Run the one prospective_argument_in_parser_layout test with --nocapture on both selected compiler configurations. Record actual sizes/alignments, pair rows and both derived values. Proposed equality is not an assertion; any difference must inform selection before implementation.
3. Archive this immutable source and both execution records. Remove the temporary probe file and registration, proving expressions.rs exact restoration against before/parent.
4. This hold authorizes no production import or final actual-layout assertion. The eventual implementation must independently corroborate the selected mirror observations.
''')
manifest={
 'schema':'eris-argument-in-prospective-layout-hold-v1','status':'source-ready-prospective-layout-only',
 'parent':bind(P/'parent-source.json'),'selection':bind(P/'root/plan-selection-1.json'),
 'new_test_modules':[{'relative':rawrel,'raw':bind(raw)}],
 'temporary_registrations':[{'relative':exprrel,'before':bind(before),'raw':bind(reg),'diff':bind(diff),'delta':'One cfg(test) child-module declaration near imports; exact inverse retained.'}],
 'support':[bind(source_map),bind(expected),bind(notes)],
 'groups':1,'pair_rows':15,'derived_rows':2,
 'execution':False,'live_edits':False,'production_authored':False,
 'source_review':'Exact source extraction and two payload additions verified inertly; all eight source bindings match the published parent inventory. No guessed payload shapes. Root/peer can inspect before execution.'
}
manifest['authoring_helper']=bind(B/'author.py')
out=dump('source-ready.json',manifest);print(json.dumps(bind(out)))
