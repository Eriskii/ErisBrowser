from pathlib import Path
import json,hashlib,difflib,re
A=Path('/tmp/eris-call-argument-in-1');W=A/'worktree';D=A/'tests-public-1';P=Path('/tmp/eris-call-argument-in-plan-1')
def write(n,x): (D/n).write_text(json.dumps(x,indent=2)+'\n')
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
held=json.loads((P/'public-controls.json').read_text());cases=held['cases'];assert len(cases)==15
header='''//! Call/new argument +In literals held before the grammar correction.
//! Parent-compatible Runtime and active/legacy parser interfaces only.
use super::*;

fn execute_mode(
    runtime: &mut Runtime,
    document: &mut Document,
    strict: bool,
    source: &str,
) -> Result<Value> {
    if strict {
        runtime.execute_strict(source, document)
    } else {
        runtime.execute(source, document)
    }
}

fn clean(runtime: &Runtime, case_id: &str, strict: bool) {
    assert_eq!(
        (
            runtime.frames.len(),
            runtime.eval_depth,
            runtime.stack_units,
            runtime.calls
        ),
        (0, 0, 0, 0),
        "{case_id} strict={strict}"
    );
    assert!(!runtime.microtasks_suspended(), "{case_id} strict={strict}");
    assert!(runtime.console.is_empty(), "{case_id} strict={strict}");
}

fn succeeds(case_id: &str, source: &str, expected: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let observed = execute_mode(&mut runtime, &mut document, strict, source)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} runtime: {error:?}"));
        assert_eq!(
            observed,
            Value::String(expected.into()),
            "{case_id} strict={strict}"
        );
        clean(&runtime, case_id, strict);

        let active = parser::Parser::program_context(source, false, strict)
            .map(|unit| code::canonical(&unit))
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} active: {error:?}"));
        let legacy = parser_legacy::Parser::program_context(source, false, strict)
            .and_then(code::compile)
            .map(|unit| code::canonical(&unit))
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} legacy: {error:?}"));
        assert_eq!(active, legacy, "{case_id} strict={strict}");
    }
}

fn syntax_error(case_id: &str, source: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let runtime_error = execute_mode(&mut runtime, &mut document, strict, source)
            .unwrap_err();
        let active_error = parser::Parser::program_context(source, false, strict).unwrap_err();
        let legacy_error = parser_legacy::Parser::program_context(source, false, strict).unwrap_err();
        for (path, error) in [
            ("runtime", runtime_error),
            ("active", active_error),
            ("legacy", legacy_error),
        ] {
            assert_eq!(error.name(), "SyntaxError", "{case_id} strict={strict} {path}");
            assert!(
                error.is_parse_error() && !error.is_unsupported(),
                "{case_id} strict={strict} {path}: {error:?}"
            );
        }
        clean(&runtime, case_id, strict);
    }
}
'''
parts=[header];roster=[]
for c in cases:
 name='call_argument_in_'+c['id'].replace('-','_');neg=c['kind']=='negative'
 p='''\n#[test]\nfn %s() {\n    %s(\n        "%s",\n        r###"%s"###,%s\n    );\n}\n'''%(name,'syntax_error' if neg else 'succeeds',c['id'],c['source'],'' if neg else '\n        '+json.dumps(c['expected'])+',')
 parts.append(p)
 roster.append({'test':'script::call_argument_in_tests::'+name,'case_id':c['id'],'kind':c['kind'],'planned_modes':['sloppy','strict'],'expected_parent':'fail' if c['kind']=='new-admission' else 'pass','parent_stop':'First sloppy Runtime parse is expected SyntaxError; strict and both canonical checks are unreached.' if c['kind']=='new-admission' else 'Both modes and all configured Runtime/parser checks should complete.','source':c['source'],'expected':c['expected'],'rationale':c['rationale']})
raw=D/'raw/src/script/call_argument_in_tests.rs';raw.write_text(''.join(parts))
assert re.findall(r'r###"(.*?)"###',raw.read_text(),re.S)==[c['source'] for c in cases]
assert len(re.findall(r'^#\[test\]$',raw.read_text(),re.M))==15
assert re.findall(r'^fn (call_argument_in_\w+)\(',raw.read_text(),re.M)==[r['test'].rsplit('::',1)[1] for r in roster]
orig=(W/'src/script.rs').read_bytes();before=D/'before/src/script.rs';before.write_bytes(orig)
addition=b'\n#[cfg(test)]\nmod call_argument_in_tests;\n';assert b'mod call_argument_in_tests;' not in orig
post=D/'registration-after/src/script.rs';post.write_bytes(orig+addition)
patch=''.join(difflib.unified_diff(orig.decode().splitlines(True),(orig+addition).decode().splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs'))
(D/'registration.patch').write_text(patch)
(D/'registration.txt').write_bytes(addition)
inv=json.loads((A/'parent-source.json').read_text());assert inv['base']=='8159301e555010f4c7879e1fbd31c9cfc784b686'
bindings=[]
for rel in ['src/script.rs','src/script/parser.rs','src/script/parser/driver.rs','src/script/parser/driver/expressions.rs','src/script/parser/driver/statements.rs','src/script/parser_legacy.rs','src/script/code.rs','src/script/call_spread_tests.rs']:
 p=W/rel; row={'relative':rel,**info(p)};assert row['sha256']==inv['source_sha256'][rel];bindings.append(row)
write('oracle.json',{'status':'frozen-before-production-and-observations','held_literals':info(P/'public-controls.json'),'source_text_and_expected_values':'All15 sources and expected values are exact copies; no selected literal or rationale changed.','groups':roster,'planned_group_total':15,'planned_mode_rows':30,'parent_expected':{'pass_groups':6,'fail_groups':9,'not_execution':'Nine failure groups are expected to stop in sloppy Runtime source parsing. Their strict mode, runtime observations/cleanup and active/legacy canonical checks are not predicted to be observed in that run. Six preservation/negative groups are expected to complete both modes.'},'assertion_order':'Success: fresh Runtime execution and literal return, clean state, active canonical, legacy compile/canonical equality, then next mode. Negative: Runtime/active/legacy exact non-Unsupported SyntaxError, clean state, then next mode.'})
write('source-bindings.json',{'base':inv['base'],'parent_inventory':info(A/'parent-source.json'),'selection':info(A/'root/plan-selection-1.json'),'plan':info(P/'source-ready.json'),'plan_peer':info(P/'script-review.json'),'standards':info(P/'standards.json'),'existing_sources':bindings})
write('literal-checks.json',{'method':'Inert Python extraction/hash/diff inspection only; no project or JavaScript import/execution.','source_literals_exact':15,'expected_literals_exact':15,'test_groups':15,'planned_mode_rows':30,'registration':'Exact append of one cfg(test) module; original script.rs prefix byte-identical.','parent_binding':'Eight current source files match published-parent inventory.','no_changes':['Production','Existing tests','Caps/fees','Current held proposal literals']})
write('import-instructions.json',{'new_file':{'from':str(raw),'to':'src/script/call_argument_in_tests.rs'},'registration':{'patch':str(D/'registration.patch'),'exact_text':addition.decode(),'before':info(before),'after':info(post),'instruction':'Root imports only the new test file and appends this cfg(test) declaration; use retained patch against the bound parent or compose the exact declaration if other independent registrations have since been appended.'},'baseline':'Filter script::call_argument_in_tests::; expected15groups6pass9fail. Parent-compatible interfaces only. Root owns execution and result reporting.'})
files=[info(raw),info(before),info(post),info(D/'registration.patch'),info(D/'registration.txt')]
files += [info(D/n) for n in ['oracle.json','source-bindings.json','literal-checks.json','import-instructions.json']]
write('source-ready.json',{'schema':'eris-call-argument-in-public-tests-before-v1','status':'frozen-for-independent-source-review','base':inv['base'],'files':files,'groups':15,'planned_modes':30,'expected_parent_groups':{'pass':6,'fail':9},'scope':'One new test module and one cfg(test) registration only. No production, live edits, formatter, compiler, parser, JavaScript, test, browser or git execution. Source/hash/diff authoring only.','authoring_helper':info(D/'author-freeze.py')})
print(json.dumps(info(D/'source-ready.json')))
