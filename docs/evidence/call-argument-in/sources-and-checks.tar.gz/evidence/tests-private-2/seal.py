from pathlib import Path
import hashlib, json, difflib, re

base = Path('/tmp/eris-call-argument-in-1')
old = base / 'tests-private-1'
out = base / 'tests-private-2'
rel = 'src/script/parser/driver/expressions/argument_in_context_tests.rs'

def binding(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write_json(name, value):
    (out / name).write_text(json.dumps(value, indent=2) + '\n')

original = (old / 'raw' / rel).read_text()
selected = original
for before, after, expected in [
    ('                    let records = parser.unit.expressions.len();\n', '', 1),
    ('                    assert_eq!(parser.unit.expressions.len(), records + usize::from(spread) + usize::from(!refuse));\n', '', 1),
    ('assert_eq!((parser.allow_in, parser.pos, parser.unit.expressions.len()), (initial, 1, 0));', 'assert_eq!((parser.allow_in, parser.pos), (initial, 1));', 2),
    ('assert_eq!((parser.allow_in, parser.pos, parser.unit.expressions.len()), (initial, 2, 2));', 'assert_eq!((parser.allow_in, parser.pos), (initial, 2));', 1),
    ('assert_eq!((parser.allow_in, parser.pos, parser.unit.expressions.len()), (initial, 2, 128));', 'assert_eq!((parser.allow_in, parser.pos), (initial, 2));', 1),
]:
    assert selected.count(before) == expected
    selected = selected.replace(before, after)
assert 'parser.unit.expressions' not in selected
assert len(re.findall(r'^#\[test\]$', selected, re.M)) == 10
for folder, data in [('before', original), ('raw', selected)]:
    path = out / folder / rel
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)
diff = ''.join(difflib.unified_diff(original.splitlines(True), selected.splitlines(True), fromfile='a/'+rel, tofile='b/'+rel))
(out / 'correction.patch').write_text(diff)

roster = json.loads((old / 'roster.json').read_text())
roster['eligibility_correction'] = 'The original hold incorrectly claimed compile eligibility despite sibling-private Unit.expressions reads. Hold2 removes only those reads; all ten groups now use existing visible parent APIs. No compiler execution is claimed.'
for group in roster['groups_detail']:
    group['role'] = 'preservation' if group['expected_parent_outcome'] == 'pass' else 'intentional-parent-failure'
write_json('roster.json', roster)

ledger = json.loads((old / 'ledger.json').read_text())
for row in ledger['other_refusals']:
    row.pop('records')
ledger['observation_qualification'] = 'Hold2 no longer reads the private Unit.expressions record count. Record/page staging remains a source-derived explanation; exact flags, positions, error kinds, budget counters, warm128 setup and successful AST shape checks are retained. No record count is claimed observed by these selected tests.'
write_json('ledger.json', ledger)

reason = {
    'finding': 'code::Unit.expressions is private to the sibling code module; the expressions child test cannot read it.',
    'selection': 'Root selected removal of ancillary record-count reads/assertions, with no production visibility or test-only accessor change.',
    'removed': ['one pre-close count snapshot', 'one post-close count-delta assertion', 'record-count component of four refusal-state tuple assertions'],
    'preserved': ['all ten test functions', 'semantic flags and AST shape assertions', 'positions and error kinds', 'all exact work/heap assertions', 'all source literals', 'warm128 setup via actual emit_expr', 'registration and restored parent joins', 'four preservation versus six intentional-failure expectations'],
    'lost_coverage': 'Direct ancillary expression-record count observations only. Existing counter and semantic/AST observations continue to cover the selected behavior and cuts.',
    'hold1': binding(old/'source-ready.json'),
    'original_source': binding(old/'raw'/rel),
    'production_changes': False,
    'execution': False,
    'live_edits': False,
}
write_json('correction.json', reason)

selection = {
    'retained_hold': binding(old/'source-ready.json'),
    'selected_module': binding(out/'raw'/rel),
    'selected_roster': binding(out/'roster.json'),
    'selected_ledger': binding(out/'ledger.json'),
    'unchanged_from_hold1': ['existing_registration_patches', 'oracles.json', 'outline-binding-addendum.json', 'source-bindings.json'],
    'scope_override': 'Any original record-count observation or unqualified compile-eligibility claim is superseded by correction.json. Original hold remains unchanged.',
}
write_json('selection.json', selection)
old_manifest = json.loads((old/'source-ready.json').read_text())
manifest = {
    'schema': 'eris-argument-in-private-tests-hold-v2',
    'status': 'frozen-before-production',
    'retained_hold': binding(old/'source-ready.json'),
    'base': old_manifest['base'],
    'parent_public_inventory': old_manifest['parent_public_inventory'],
    'selection': old_manifest['selection'],
    'new_test_modules': [{'relative': rel, 'raw': binding(out/'raw'/rel), 'groups': 10}],
    'existing_registration_patches': old_manifest['existing_registration_patches'],
    'support': [binding(out/name) for name in ['selection.json', 'correction.json', 'correction.patch', 'roster.json', 'ledger.json']],
    'unchanged_support': [binding(old/name) for name in ['oracles.json','outline-binding-addendum.json','source-bindings.json']],
    'groups': 10,
    'parent_eligible_groups': 10,
    'selected_abi_expected_parent': {'pass': 4, 'fail': 6},
    'baseline': 'Source-predicted only; no private parent or candidate execution. ABI-specific groups run only on x86_64 Linux.',
    'old_test_migrations': [],
    'execution': False, 'live_edits': False, 'production_authored': False,
    'authoring_helper': binding(out/'seal.py'),
}
write_json('source-ready.json', manifest)
print(json.dumps(binding(out/'source-ready.json')))
