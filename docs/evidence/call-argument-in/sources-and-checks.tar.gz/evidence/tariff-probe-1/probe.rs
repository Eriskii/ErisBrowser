//! Parent-only full-compile tariff observation, before candidate production.
use super::*;

#[test]
fn parent_argument_in_compile_tariffs() {
    for (id, source) in [
        ("call_one", "f(1)"),
        ("call_trailing", "f(1,2,)"),
        ("new_one", "new C(1)"),
        ("new_trailing", "new C(1,2,)"),
        ("call_spread", "f(...x)"),
        ("new_spread_trailing", "new C(...x,)"),
        ("outer_for_in", "for(f(0).slot in {a:1}){}"),
    ] {
        for strict in [false, true] {
            let parser = Parser::parse_context(source, false, strict).unwrap();
            assert!(parser.done());
            assert!(parser.allow_in);
            let mut ledger = parser.compile_budget;
            let _unit = parser.unit.finish(&mut ledger).unwrap();
            println!("ARGUMENT_IN_PARENT_TARIFF_V1 id={} strict={} work={} heap={}", id, strict, MAX_STEPS-ledger.steps, ledger.allocated);
        }
    }
}
