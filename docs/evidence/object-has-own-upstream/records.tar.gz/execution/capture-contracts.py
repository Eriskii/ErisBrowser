"""Capture data-only historical profiles; adapter execution is prohibited."""
import hashlib
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
A = Path(__file__).resolve().parent
mode = sys.argv[1]
assert mode in ['before', 'after']
root = (Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
        if mode == 'before' else A/'worktree')
sys.path.insert(0, str(root/'tools'))
from test_test262_object_integrity import canonical, capture_contracts

result = capture_contracts(excluded=() if mode == 'before' else {'object-has-own'})
data = canonical(result)
with (A/f'contracts-{mode}.json').open('xb') as stream:
    stream.write(data)
print(json.dumps(dict(mode=mode, counts=result['counts'], bytes=len(data), sha256=hashlib.sha256(data).hexdigest())))
