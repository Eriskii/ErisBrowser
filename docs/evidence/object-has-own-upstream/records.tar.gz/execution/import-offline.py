"""Import the pinned original upstream bytes with network fetching forbidden."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
A = Path(__file__).resolve().parent
W = A / 'worktree'
P = Path('/tmp/eris-object-has-own-upstream-preparation-1/layout')
sys.path.insert(0, str(W/'tools'))
import import_test262 as importer
import test262_conformance as runner

inventory = json.loads((P/'inventory.json').read_text())
raw_prefix = f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
api_prefix = f'https://api.github.com/repos/{importer.REPOSITORY}/git/'
sources = {}
for row in inventory['upstream_tests'] + inventory['auxiliary']:
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    sources[raw_prefix + row['upstream_path']] = (Path(row['path']), data)
for row in inventory['proof_files']:
    path = Path(row['path']); data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    route = ('commits/' + importer.REVISION if path.name == 'commit.json'
             else 'trees/' + path.stem.removeprefix('tree-'))
    sources[api_prefix + route] = (path, data)
tree = 'c415403752259885fd6cfda1999381beef67ee70'
recursive = P/'recursive-proof'/f'recursive-{tree}.json'
data = recursive.read_bytes()
assert hashlib.sha256(data).hexdigest() == 'd12cf03ee0caf86e00bf64d53fe3c86525e1e8ea94a9fea9874315c7fcea2193'
sources[api_prefix + f'trees/{tree}?recursive=1'] = (recursive, data)
requested = []
def fetch(url):
    path, data = sources[url]  # Unknown routes fail; no network fallback.
    assert path.read_bytes() == data
    requested.append(dict(url=url, path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest()))
    return data

output = W/'tests/upstream/test262-object-has-own'
assert not output.exists()
with patch.object(importer, 'fetch', side_effect=fetch):
    importer.import_corpus(output, 'object-has-own')
with patch.object(importer, 'fetch', side_effect=AssertionError('offline validation requested network')):
    manifest, files, cases, fixtures, digest = runner.load_corpus(output, 'object-has-own')
assert len(cases) == 124 and not fixtures and manifest['test_files'] == 62
case_roster = [(case['id'], case['case_sha256']) for case in cases]
record = dict(status='imported and loaded original pinned bytes offline; no engine',
              output=str(output), requests=sorted(requested, key=lambda r:r['url']),
              manifest_sha256=digest, files=len(files), cases=len(cases),
              case_roster=case_roster,
              mode_counts={mode:sum(c['mode']==mode for c in cases) for mode in ['sloppy','strict']})
with (A/'import-result.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps({key:record[key] for key in ['status','manifest_sha256','files','cases','mode_counts']}))
