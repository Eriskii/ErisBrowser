import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

A = Path(__file__).resolve().parent
label = sys.argv[1]
assert label in ['ownership-tools', 'all-test262-tools']
pattern = 'test_test262_object_has_own.py' if label == 'ownership-tools' else 'test_test262*.py'
argv = ['python3', '-m', 'unittest', 'discover', '-s', 'tools', '-p', pattern, '-v']
log = A/(label+'.log')
start = time.monotonic()
with log.open('xb') as stream:
    result = subprocess.run(argv, cwd=A/'worktree', stdout=stream, stderr=subprocess.STDOUT)
record = dict(command=argv, exit=result.returncode, elapsed_seconds=time.monotonic()-start,
              log=log.name, sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (A/(label+'-execution.json')).open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record))
print(log.read_text()[-6000:])
raise SystemExit(result.returncode)
