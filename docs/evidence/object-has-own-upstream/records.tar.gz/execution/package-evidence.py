import gzip, hashlib, io, json, tarfile
from pathlib import Path
A=Path(__file__).resolve().parent
P=Path('/tmp/eris-object-has-own-upstream-preparation-1')
W=A/'worktree'
E=W/'docs/evidence/object-has-own-upstream'
E.mkdir(exist_ok=False)
def digest(data): return hashlib.sha256(data).hexdigest()
def row(path):
 data=path.read_bytes();return {'bytes':len(data),'sha256':digest(data)}
files={}
for path in A.iterdir():
 if path.is_file(): files['execution/'+path.name]=path.read_bytes()
for base,label in [(P,'preparation'),(A/'historical-test-exclusion-correction','historical-test-exclusion-correction')]:
 for path in sorted(base.rglob('*')):
  if path.is_symlink(): raise ValueError(path)
  if path.is_file() and '__pycache__' not in path.parts:
   files[label+'/'+path.relative_to(base).as_posix()]=path.read_bytes()
manifest={name:{'bytes':len(data),'sha256':digest(data)} for name,data in sorted(files.items())}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
with (E/'records.tar.gz').open('xb') as raw:
 with gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as archive:
   for name,data in sorted(files.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
    archive.addfile(info,io.BytesIO(data))
(E/'report.json').write_bytes((A/'upstream-report.json').read_bytes())
review=P/'layout/upstream-results-review.json'
(E/'result-review.json').write_bytes(review.read_bytes())
index={
 'scope':'Complete pinned Object.hasOwn upstream profile; validation/tooling only',
 'base_commit':'3ee89d4835a40d652b1be6fe73cff425f7598289',
 'runtime_changed':False,
 'binary':json.loads((A/'base.json').read_text())['published_release'],
 'results':{'sources':62,'source_bytes':33881,'modes':124,'passed':124,'healthy_controls':64},
 'python':{'new_groups':10,'first_test262_suite':{'tests':261,'failures':3,'exit':1},'corrected_full_suite':{'tests':394,'failures':0,'exit':0}},
 'correction':'Three older fixed-population tests now exclude only the newly added profile; historical expected counts and fingerprints are unchanged.',
 'historical_contracts':json.loads((A/'contracts-comparison.json').read_text()),
 'review_scope':'Independent data-only review of 124 results, 64 controls, 81 engine input bindings and baseline; historical Python corrections reviewed separately by root.',
 'no_new_rust_build':True,
 'no_gpu_or_performance_measurement':True,
 'evidence':{name:row(E/name) for name in ['report.json','result-review.json','records.tar.gz']},
 'archive_members':len(files),
 'archive_manifest_sha256':digest(files['manifest.json']),
 'limitations':['Selected upstream directory is not full ECMAScript conformance.','Proxy, BigInt, universal host reflection and full browser compatibility remain incomplete.','Historical contract comparison is data-only, not a fresh engine replay.']}
(E/'index.json').write_text(json.dumps(index,indent=2)+'\n')
with tarfile.open(E/'records.tar.gz','r:gz') as archive:
 members=archive.getmembers();assert len(members)==len(files)
 for member in members:
  assert member.isfile() and archive.extractfile(member).read()==files[member.name]
print(json.dumps({'archive':row(E/'records.tar.gz'),'members':len(files),'verified':True}))
