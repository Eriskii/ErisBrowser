import hashlib
import json
from pathlib import Path
import subprocess
import time

A = Path(__file__).resolve().parent
W = A/'worktree'
BINARY = Path('/tmp/eris-node-clone-1/eris-js')
BINARY_SHA = 'e77a1efcd0b08a2ac570d65e0d0a4579aa55b51f02a4c99188b6bbbf19e7310d'
def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

assert binding(BINARY)['sha256'] == BINARY_SHA
paths = [W/'tools'/p for p in ['import_test262.py', 'test262_conformance.py', 'html_conformance.py']]
paths += sorted(p for p in (W/'tests/upstream/test262-object-has-own').rglob('*') if p.is_file())
paths += [BINARY, Path(__file__).resolve()]
bindings = [binding(path) for path in paths]
with (A/'engine-inputs.json').open('x') as stream:
    json.dump(bindings, stream, indent=2); stream.write('\n')
output = A/'upstream-report.json'
baseline = W/'tests/conformance/test262-object-has-own-current.json'
assert not output.exists() and not baseline.exists()
argv = ['python3', 'tools/test262_conformance.py', '--profile', 'object-has-own',
        '--binary', str(BINARY), '--jobs', '1', '--timeout', '3',
        '--output', str(output), '--record-baseline', str(baseline)]
log = A/'upstream-execution.log'
start = time.monotonic()
with log.open('xb') as stream:
    result = subprocess.run(argv, cwd=W, stdout=stream, stderr=subprocess.STDOUT)
after = [binding(path) for path in paths]
record = dict(command=argv, exit=result.returncode, elapsed_seconds=time.monotonic()-start,
              log=log.name, sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
              input_bindings_unchanged=after == bindings, binary_sha256=BINARY_SHA)
with (A/'upstream-execution.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record))
print(log.read_text()[-5000:])
assert after == bindings, 'engine input binding drift'
raise SystemExit(result.returncode)
