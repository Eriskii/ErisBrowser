"""Independent source/data checks only; never import the reviewed tools."""
import ast
import collections
import copy
import datetime
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/tmp/eris-object-has-own-upstream-preparation-1')
ARTIFACT = Path('/tmp/eris-object-has-own-upstream-1')
bindings = {}


def read(path):
    path = Path(path)
    data = path.read_bytes()
    bindings[str(path)] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return data


def load(path):
    return json.loads(read(path))


def bound(row):
    data = read(row['path'])
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    return data


def dump(node):
    return ast.dump(node, include_attributes=False)


def assignment(tree, name):
    return next(n.value for n in tree.body if isinstance(n, ast.Assign)
                and any(isinstance(t, ast.Name) and t.id == name for t in n.targets))


class RemoveNewProfile(ast.NodeTransformer):
    def visit_Assign(self, node):
        if any(isinstance(t, ast.Name) and t.id in {'OBJECT_HAS_OWN_DIRECTORIES', 'OBJECT_HAS_OWN_FEATURES'}
               for t in node.targets):
            return None
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == 'object_has_own_preflight_variants':
            return None
        return self.generic_visit(node)

    def visit_If(self, node):
        if dump(node.test) == dump(ast.parse("profile == 'object-has-own'", mode='eval').body):
            return None
        return self.generic_visit(node)

    def visit_Dict(self, node):
        keep = [(k, v) for k, v in zip(node.keys, node.values)
                if not (isinstance(k, ast.Constant) and k.value == 'object-has-own')]
        node.keys = [k for k, _ in keep]
        node.values = [v for _, v in keep]
        return self.generic_visit(node)

    def visit_Set(self, node):
        node.elts = [v for v in node.elts if not (isinstance(v, ast.Constant) and v.value == 'object-has-own')]
        return self.generic_visit(node)


hold = load(ROOT / 'runtime/source-ready.json')
for row in hold['references']:
    bound(row)
trees = {}
for row in hold['files']:
    old = bound(row['before'])
    new = bound(row['future'])
    # Integration is root-owned and already happened; verify exact held bytes only.
    assert read(ARTIFACT / 'worktree' / row['path']) == new
    if row['path'] in {'tools/import_test262.py', 'tools/test262_conformance.py'}:
        before, future = ast.parse(old), ast.parse(new)
        trees[row['path']] = (before, future)
        assert dump(before) == dump(RemoveNewProfile().visit(copy.deepcopy(future))), row['path']
    else:
        assert new.count(b"'object-has-own', ") == 1
        assert new.replace(b"'object-has-own', ", b'', 1) == old, row['path']
assert len(hold['files']) == 12
before_import, future_import = trees['tools/import_test262.py']
before_runner, future_runner = trees['tools/test262_conformance.py']
assert len(assignment(before_import, 'PROFILES').keys) == 44
assert len(assignment(future_import, 'PROFILES').keys) == 45
feature_set = ast.literal_eval(assignment(future_runner, 'OBJECT_HAS_OWN_FEATURES'))
assert feature_set == {'Object.hasOwn', 'Symbol', 'Symbol.toPrimitive', 'Reflect.construct', 'arrow-function'}
assert ast.literal_eval(assignment(future_import, 'OBJECT_HAS_OWN_DIRECTORIES')) == {'Object/hasOwn': 62}

layout_hold = load(ROOT / 'layout/source-ready.json')
for row in layout_hold['files']:
    bound(row)
bound(layout_hold['assessment'])
bound(layout_hold['inventory'])
inventory = load(ROOT / 'layout/inventory.json')
features = collections.Counter()
includes = collections.Counter()
entries = {}
for row in inventory['upstream_tests']:
    data = bound(row)
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob']
    front = re.search(r'/\*---\n(.*?)\n---\*/', data.decode(), re.S).group(1)
    for key in ['features', 'flags', 'includes', 'locale']:
        match = re.search(r'^' + key + r':\s*\[([^\]\n]*)\]\s*$', front, re.M)
        value = [v.strip() for v in match.group(1).split(',') if v.strip()] if match else []
        assert value == row['metadata'][key], (row['path'], key)
    assert not re.search(r'^(?:negative|timeout):', front, re.M)
    assert row['metadata']['negative'] is None
    assert row['modes'] == ['sloppy', 'strict']
    assert not row['metadata']['flags'] and not row['metadata']['locale']
    features.update(row['metadata']['features'])
    includes.update(row['metadata']['includes'])
    name = Path(row['path']).name
    assert name not in entries
    entries[name] = row
assert len(entries) == 62
assert sum(row['bytes'] for row in entries.values()) == 33881
assert sum(len(row['modes']) for row in entries.values()) == 124
assert set(features) == feature_set
assert features == {'Object.hasOwn': 62, 'Symbol': 3, 'Symbol.toPrimitive': 2, 'Reflect.construct': 1, 'arrow-function': 1}
assert includes == {'propertyHelper.js': 3, 'isConstructor.js': 1}
for row in inventory['auxiliary']:
    data = bound(row)
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == row['git_blob']

recursive_receipt = load(ROOT / 'layout/recursive-proof/receipt.json')
recursive = json.loads(bound(recursive_receipt))
assert recursive['sha'] == inventory['subtree'] and recursive['truncated'] is False
assert len(recursive['tree']) == 62
raw_tree = []
for row in recursive['tree']:
    assert row['type'] == 'blob' and row['mode'] == '100644'
    expected = entries[row['path']]
    assert row['sha'] == expected['git_blob'] and row['size'] == expected['bytes']
    raw_tree.append((row['path'].encode(), b'100644 ' + row['path'].encode() + b'\0' + bytes.fromhex(row['sha'])))
body = b''.join(v for _, v in sorted(raw_tree))
assert hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest() == inventory['subtree']

pair_data = load(ROOT / 'runtime/preflight-pairs.json')
function = next(n for n in future_runner.body if isinstance(n, ast.FunctionDef) and n.name == 'object_has_own_preflight_variants')
assert ast.literal_eval(assignment(function, 'guard')) == pair_data['guard']
assert ast.literal_eval(assignment(function, 'pairs')) == [tuple(row) for row in pair_data['pairs']]
expected_controls = []
for name, setup, actual, good, bad in pair_data['pairs']:
    assert good != bad
    for variant, value, expected in [('positive', good, 'passed'), ('wrong', bad, 'failed')]:
        for mode in ['sloppy', 'strict']:
            source = pair_data['guard'] + setup + '\n' + f'assert.sameValue({actual},{value});'
            expected_controls.append(dict(name='object-has-own-' + name + '-' + variant,
                mode=mode, expected=expected, source=source, sha256=hashlib.sha256(source.encode()).hexdigest(),
                positive_partner='object-has-own-' + name + '-positive' if variant == 'wrong' else None,
                harness=['assert.js', 'sta.js'] + (['propertyHelper.js'] if 'property-' in name else [])))
assert expected_controls == load(ROOT / 'runtime/frozen-controls.json')
assert len(expected_controls) == len({(r['name'], r['mode']) for r in expected_controls}) == 32
preflight = next(n for n in before_runner.body if isinstance(n, ast.FunctionDef) and n.name == 'harness_preflight')
common = ast.literal_eval(assignment(preflight, 'scripts'))
extras = ast.literal_eval(preflight.body[4].value)
assert len(common) * 2 + len(extras) == 32

# This later root-owned result is bound, not rerun. Its existence fixes review timing.
import_result = load(ARTIFACT / 'import-result.json')
assert import_result['mode_counts'] == {'sloppy': 62, 'strict': 62}
for row in import_result['requests']:
    bound(row)

receipt = dict(status='clear source/data review; no implementation or oracle finding',
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    timing='This final peer seal follows the root-owned offline import. It was not a pre-import execution gate.',
    scope='Original held twelve-file tools patch, complete layout inventory, literal controls, historical profiles and later recursive proof.',
    checks=dict(runtime_hold_files=12, layout_hold_files=len(layout_hold['files']),
        importer_and_runner_whole_asts_exact_after_removing_only_new_profile_additions=True,
        old_profiles=44, new_profiles=45, historical_test_deltas_only_ten_explicit_exclusion_additions=True,
        unchanged_defaults_limits_baseline_and_old_profile_execution_paths=True,
        source_files=62, source_bytes=33881, modes=124, exact_features=dict(features), includes=dict(includes),
        recursive_tree_and_all_source_blob_hashes=True, feature_controls_reconstructed=32,
        common_controls_unchanged=32, total_controls=64),
    source_reasoning=[
        'Registration reaches the unchanged root-linked recursive tree verifier; complete file counts, directories, source blobs, auxiliary blobs, legal files and exact helper inventory are checked.',
        'Only this profile admits Object.hasOwn, with exactly the five declared upstream feature labels. No older policy or default admits the new tag.',
        'Every feature pair first proves callable own/inherited/missing behavior. Accessor presence, target-before-key, three Symbol conversions, metadata and nonconstruction pairs have literal positive and wrong tails.',
        'A wrong feature control needs failed status, actual Test262Error and the separately verified same-mode positive partner. Missing-method or broken-prerequisite Test262Error observations stay raw and unhealthy.',
        'The nonconstructor control first proves Reflect.construct works with a genuine constructable function. The target-before-key pair proves the method works on objects before testing nullish targets.',
        'Unhealthy preflight prevents compact baseline recording through the unchanged main path; complete raw observations remain in the report.',
        'Whole-AST reversal preserves old forty-four profile code paths and defaults; the ten historical contract tests retain their original asserted counts and digests. No runtime contract test execution is claimed.',
        'The independently acquired original recursive response is now held separately. Identical bytes to a nonrecursive response for this leaf-only tree do not change its recorded acquisition provenance.'
    ],
    limitations=[
        'The new imported-corpus corruption, offline round-trip and all-profile regression tests are planned separately; this review did not run them.',
        'No importer, runner, JavaScript parser, engine or compiler was invoked by this reviewer.',
        'No upstream passing count or full ECMAScript support follows from source inspection.'
    ], findings=[], bindings=sorted(bindings.values(), key=lambda x:x['path']))
read(Path(__file__))
receipt['bindings'] = sorted(bindings.values(), key=lambda x:x['path'])
output = ROOT / 'html-review/source-review.json'
with output.open('x') as handle:
    json.dump(receipt, handle, indent=2)
    handle.write('\n')
print(json.dumps(dict(path=str(output), sha256=hashlib.sha256(output.read_bytes()).hexdigest(),
                     bound_files=len(bindings), status=receipt['status'])))
