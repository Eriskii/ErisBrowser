# Required data-only regression checks before engine validation

Adapt tools/test_test262_object_is.py into a new explicit object-has-own suite after the authorized importer supplies the actual corpus manifest. Bind the original62 source hashes, four harness hashes and legal hashes from layout/inventory.json. Do not invent a manifest digest before import.

- Exact completeness:62 sources,33,881 test bytes,124 modes (62 each), empty flags/negative metadata, no fixtures, exact declared feature admission and assert/sta/includes order. Pin resulting case-fingerprint roster independently.
- Proof refusal: recursive truncation/omission/duplicate/blob/mode/path/orphan/oversize mutations; substituted ancestor/root/harness/legal blobs; rehashed manifest cannot bless changed or extra files; symlink payload/proof refusal.
- Offline import round-trip: intercept network fetching with the exact retained original API responses and pinned raw files; compare complete output manifest/file/case identities. Current layout nonrecursive proof cannot stand in for the original recursive response.
- All44 predecessor profiles: capture before and future tools contracts under a patched adapter prohibition and require every corpus/policy/case/preflight/expectation byte unchanged. All historical fixed-population contract assertions retain their original count/hash by explicitly excluding the new profile at each historical call site.
- Exact64 controls: common32 byte-identical to default; feature32 match frozen-controls.json order, literal source hash, helper roster and expectation. Distinct name+mode identities are mandatory.
- Negative health: missing callable, false own/inherited guard, TypeError/ReferenceError/SyntaxError/RangeError, timeout/resource/unsupported/adapter-error, absent result, wrong mode or failed positive partner must never verify the corresponding wrong control. Check positive and wrong observations remain retained independently; only actual Test262Error plus successful same-mode partner verifies a wrong assertion.
- CLI/profile defaults: string-json default and default corpus mapping stay exact; Object.hasOwn is admitted only by its own new feature policy. No change to execution limits, output schema, baseline policy or old test sources.

These are planned checks, not execution claims. The new data-only regression module can be completed and source-frozen with the actual imported corpus pins after root authorizes that stage.
