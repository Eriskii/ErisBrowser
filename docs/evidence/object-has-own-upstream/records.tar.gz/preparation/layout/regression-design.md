# Independent Object.hasOwn tooling regression source

The single proposed repository path is `tools/test_test262_object_has_own.py`, held in `layout/future/tools/`. It has ten unittest groups and has not been imported or executed. Root owns its eventual execution. Only Python AST syntax inspection and independent byte/JSON calculations were performed here.

The suite follows the existing Object.is pattern but independently fixes the Object.hasOwn inventory and control expectations. It covers complete 62-file/124-mode admission, actual imported manifest bytes, exact case identities and four-helper order, preservation of all 44 preceding profile contracts, exact 32 feature-control sources and dependencies, unchanged common controls, unhealthy incidental/absent/malformed adapter observations, same-mode positive health, original recursive/ancestor proof tampering, offline round-trip, blob corruption, rehashed manifest substitution, extras and symlink rejection.

All tests prohibit actual adapter and network execution by default. Tests that exercise protocol handling substitute literal responses for the adapter. The round-trip substitutes only retained original API/source bytes for network fetches. Temporary corpus mutation is confined to test-created directories. Nothing executes JavaScript.

The manifest digest `ec06ac5c6d9df81904821234389ed31d6638d7e2421df43345818ca8a12f05b9` comes from root's actual offline import. The 124-case fingerprint digest `0b8bf07f...` was independently derived from held source/metadata/harness bytes and then matched against that actual import. The feature-control identity digest `cf7cd2df...` comes from independently reconstructed literal rows and the reviewed frozen controls.

The old44 contract expectation `5124e0e1...` was first derived by a disjoint JSON merge of the retained historical43 contract and the retained Object.is single-profile contract. Root subsequently captured both published-before and candidate-after contracts data-only: both match this digest and the literal 19,727 cases/4,564 preflights. These are source/harness contracts, not engine pass counts.

The original recursive API response is separately retained in `recursive-proof/`. Its exact 62 path/mode/type/blob/size rows equal the held nonrecursive response; binary Git tree reconstruction matches `c415403752259885fd6cfda1999381beef67ee70`. Original responses are not synthesized or relabelled.

The proposed test module binds the actual imported manifest but does not write an importer, runner or existing historical test. Script owns the reviewed profile/preflight changes under `runtime/future/tools/`. The separate `runtime/layout-source-review.json` records the bounded peer review of those changes.
