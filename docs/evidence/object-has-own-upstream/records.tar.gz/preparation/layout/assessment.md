# Pinned Object.hasOwn upstream inventory

The existing Test262 revision contains a complete 62-file `test/built-ins/Object/hasOwn` directory: 33,881 source bytes and 124 ordinary cases, split equally between sloppy and strict mode. All files have empty flags and no negative metadata, fixtures, locale, timeout, async, module, Proxy, BigInt or host-hook requirements. This is a future profile proposal; neither the current 21-profile clone comparison nor its separate 16-case/8-control Object.hasOwn replay was changed or executed here.

The repository pins `tc39/test262` revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`, root tree `91b2052adad1f066ae031e2ff3a1e9bd6d732886`. The complete Object/hasOwn tree is `c415403752259885fd6cfda1999381beef67ee70`. Its original nonrecursive API response has no subdirectories and is not truncated. I reconstructed its Git tree hash, verified all 62 raw source Git blob hashes, and authenticated the ancestor and harness trees using the existing Object.is corpus proofs. The local globally recursive cache is truncated and was used only to locate the directory; it is not the completeness proof. Exact sources, legal files, proof responses and a per-path metadata/hash inventory are retained alongside this note.

Declared features are `Object.hasOwn` in all 62 files, `Symbol` in three, `Symbol.toPrimitive` in two, and `Reflect.construct` plus `arrow-function` in one. The required harness is the existing `assert.js`, `sta.js`, `propertyHelper.js` and `isConstructor.js`, all verified against the pinned root-linked harness tree. Three tests include propertyHelper; one includes isConstructor. Preserve the runner's order: assert, sta, then the source's includes.

## What this adds to the eight local bodies

- Twenty-four own-property and twenty-four inherited-property tests cover ordinary data, getter-only, setter-only and getter/setter descriptors across writable, enumerable and configurable combinations. The local cases cover each broad behavior but do not enumerate these combinations.
- `symbol_property_toString.js` requires ordinary toString to return a Symbol directly without subsequently calling valueOf. `symbol_property_valueOf.js` requires a null toString to be skipped and valueOf to return a Symbol. The local cases cover direct/boxed Symbols and string-valued ordinary fallback, but not these two exact combinations.
- `symbol_property_toPrimitive.js` checks one conversion call returning a Symbol. The local exotic hook checks use a string return; the boxed-Symbol case is a different path.
- `toobject_before_topropertykey.js` additionally poisons the getters for ordinary toString/valueOf on a null target. The local target-before-key case poisons Symbol.toPrimitive and checks argument-expression ordering, so these probes are complementary.
- The metadata tests use unchanged upstream verifyProperty, which exercises actual writability/enumerability/configurability behavior, and the constructor test uses the unchanged isConstructor helper.

The upstream directory does not replace the local primitive UTF-16 indices, array holes, exact non-scalar/NUL keys, callback mutation, DOM/Window, saved-method, realm-isolation or work/heap witnesses. It also cannot establish Proxy or other unrepresented host-object behavior merely because this directory has no such test.

## Existing workflow and necessary registration

The published browser source inspected here is `0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`. Its tools have 44 profiles; none is `object-has-own`, and no existing feature policy admits `Object.hasOwn`. The current CLI therefore cannot import or select this directory without a reviewed tools change. No such change was made.

The smallest consistent future route is to follow the existing Object.is profile:

1. Add `{'Object/hasOwn': 62}` to the importer profile registry and built-ins root mapping, with the pinned subtree above in ITERATION_SUBTREES, the four helpers in ITERATION_HELPERS, TREE_PROFILES membership and an accurate scope description. Obtain and retain the original recursive subtree response for that workflow; the current preparation retains the complete nonrecursive response. Both describe the same leaf-only tree.
2. Add a profile-local feature set containing the five declared feature names (or the existing construction set plus only the new Object.hasOwn tag). Do not add Object.hasOwn globally to unrelated policies.
3. Extend the runner's explicit auxiliary-blob and exact auxiliary-inventory checks to this profile. Those current allow-lists are separate from PROFILE_FEATURES and must not be missed. Preserve source, metadata, harness and case fingerprints.
4. Add guarded positive/wrong preflight pairs for real own-descriptor results, conversion ordering/Symbol fallback and metadata/construction. Preserve the existing common controls. Require the same-mode positive partner for each wrong assertion and the actual Test262Error identity; failed prerequisites must never verify a negative pair.
5. Adapt the Object.is data-only importer/runner regression pattern: exact complete inventory and modes, root/leaf/harness/legal hash corruption rejection, unchanged 44-profile contracts, offline import round-trip, captured control bytes, and rejection of incidental errors/missing observations. Freeze those controls before any new baseline engine execution.

Two important admission cautions: upstream `assert.throws(TypeError, ...)` tests can accidentally succeed when a method is absent, so a healthy actual-method preflight is required before interpreting aggregate success. Also isConstructor catches an exception from Reflect.construct; its positive constructor prerequisite must work in the preflight. Do not rewrite or remove those upstream tests to avoid either issue.

After that registration is reviewed, the existing command forms are:

```sh
python3 tools/import_test262.py --profile object-has-own --output /tmp/eris-object-has-own-upstream/corpus
python3 tools/test262_conformance.py --profile object-has-own --corpus /tmp/eris-object-has-own-upstream/corpus --binary /absolute/path/to/frozen-eris-js --jobs 1 --timeout 3 --output /tmp/eris-object-has-own-upstream/before.json
```

These are future commands, not executed commands. A later candidate can use the same exact corpus and separately retained output. Baseline recording with the inherited `--record-baseline` option is conditional on all harness preflights being healthy; an absent-method predecessor with failed feature controls must retain its raw report instead of forcing a baseline record. The official runner's compact baseline is not a replacement for the full observation rows required by the current complete-row comparison process.

The fixed upstream population is 62 sources/124 modes. A new preflight control population has not been designed or frozen, so no total including those controls is claimed. No upstream pass count, feature conformance result or expected runtime outcome is inferred from this inspection.

Primary pinned source: [Object.hasOwn tests at the pinned revision](https://github.com/tc39/test262/tree/7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd/test/built-ins/Object/hasOwn). The current importer and runner snapshots are under `inspected/tools/`; `inventory.json` binds every retained upstream path and proof.
