import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((BASE/p).read_text())
def checked(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def totals(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(x[i]) for x in rows) for i in range(3)]
assert totals('full-default-188-2')==[1775,0,0]
assert totals('full-native-198-1')==[1898,0,0]
source=read('candidate-source-final.json');assert len(source['files'])==19
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'held-source-final'/row['path'])
docs=read('documentation-ready.json');assert len(docs['files'])==10
for row in docs['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'documentation-draft'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(BASE/'candidate-source-final.json')
comparison=read('normalize-comparison.json');assert not comparison['validation_failures'];s=comparison['summary']
for kind,count,unchanged,losses in [('cases',4204,4202,2),('controls',444,440,4)]:
 row=s['established'][kind];assert row['before_total']==row['after_total']==count and row['unchanged']==unchanged and row['losses']==losses
 assert row['gains']==row['other_changes']==0
for kind,count,before in [('cases',32,0),('controls',16,4)]:
 row=s['new'][kind];assert row['before_total']==row['after_total']==row['after_healthy']==count
 assert row['before_healthy']==before and row['gains']==count-before and row['unchanged']==before
 assert row['losses']==row['other_changes']==0
classification=read('inventory-classification.json')
ci=read('text-operations-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
summary=dict(
 kind='Exact Node.normalize ordinary descendant Text runs',base_commit=source['base'],
 scope='Ordinary cached Node.prototype.normalize, authentic internal receivers, exact UTF-16 runs and first nonempty survivor identity. Empty removal, canonical replacement and tail removal retain separate admitted stages and detached data. Separate template content and unchanged worker transport.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-2','clippy-native-198-2','clippy-presenter-188-2','full-default-188-2','full-native-198-1','release-adapter-188-1']},
 tests=dict(default=1775,native=1898,new_groups=42,focused=read('focused-validation-review.json'),final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False),
 accounting=dict(remaining_bootstrap_work=10199,allocated_bytes=1744501,objects=682,object_capacity=682,native_entries=321,legacy_prototype_entries=25,additional_work=437,additional_charged_bytes=3230,bootstrap_work_limit=100000,author_work_limit=100000,cumulative_heap_limit=8388608,numeric_limits_and_resets_changed=False),
 compatibility=dict(path='normalize-comparison.json',sha256=sha(BASE/'normalize-comparison.json'),summary=s,inventory_classification=dict(path='inventory-classification.json',sha256=sha(BASE/'inventory-classification.json'),report=classification)),
 retained_history=[
 'Initial all-target compilation and all40 new DOM/runtime groups passed. Initial bootstrap filter retained25 passes/two stale assertion failures; exactly three descriptive literals across two files changed after measurement.',
 'First full default suite retained1535 passes/one old partial Node-order assertion failure. The private group is explicitly renamed and now requires normalize before ELEMENT_NODE; original source/failure and review are retained. Production and independently frozen fixtures are unchanged.',
 'New replay baseline retains32 missing-method TypeErrors and4/16 healthy controls. Candidate preserves the expected nonzero historical Node profile and aggregate runner exit: two old inventory cases fail with Error and four old controls are unhealthy with TypeError. No health waiver or fixture rewrite.'],
 boundaries=[
 'Represented exclusive Text only. No CDATASection, XMLDocument, live Range updates, MutationObserver records, custom-element reactions or slotting.',
 'Receiver itself is excluded. Ordinary descendants only; separate template content must be normalized explicitly. Removed IDs, data and own properties remain retained.',
 'Canonical replacement precedes separately admitted tail removal. Late refusal can retain duplicated joined text with tails attached, previous mutations, or the fully changed tree before final bookkeeping. No transactional rollback or tail-byte credit.',
 'Singleton runs use full canonical copies; full node arenas need no new slots. Reached traversal/map growth and each suffix compaction are charged; no universal linear-time or physical allocator OOM guarantee.',
 'Page and confined-worker witnesses check exact units/identities, metadata/style/clean textarea, summary identity/cache and literal pixels. Per-node display projection can change surrogate glyphs after joining; no cross-node shaping equivalence claim.',
 'No performance or physical-memory measurement. Full web compatibility, production security and the requested Chromium performance threshold remain unachieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','target','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p.is_symlink() or name in {'eris-js','final-publication-review.json'}:continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/node-normalize.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
p=ROOT/'docs/evidence/node-normalize.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
