"""Independent data-only audit; no child process, repository write or engine."""
from pathlib import Path
import collections,difflib,hashlib,json,re
B=Path(__file__).resolve().parent
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def h(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def j(p): return json.loads((B/p).read_text())
def binding(p): return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
checks=[]
initial=j('candidate-source-initial.json');final=j('candidate-source-final.json')
i={x['path']:x for x in initial['files']};f={x['path']:x for x in final['files']}
assert len(i)==16 and len(f)==19
assert all(i[k]==f[k] for k in i)
assert set(f)-set(i)=={'src/script/bootstrap_tests.rs','src/script/dom_bindings/identity_tests.rs','src/script/node_data/tests.rs'}
for rel,row in f.items():
 for p in [R/rel,B/'held-source-final'/rel,B/'worktree'/rel]:assert h(p)==row['sha256'],str(p)
for rel,row in i.items():assert h(B/'source-initial'/rel)==row['sha256'],rel
correction=j('measured-assertion-correction/receipt.json')
for row in correction['files']:
 p=B/'measured-assertion-correction/before'/row['path'];assert h(p)==row['before_sha256']
 s=p.read_text()
 for old,new in row['replacements']:
  assert s.count(old)==1;s=s.replace(old,new)
 assert s==(R/row['path']).read_text()
assert sum(len(x['replacements']) for x in correction['files'])==3
inv=j('node-data-inventory-correction/receipt.json');p=B/'node-data-inventory-correction/before'/inv['path']
assert h(p)==inv['before_sha256'] and h(R/inv['path'])==inv['after_sha256']
s=p.read_text().replace('fn attributes_precede_constants_and_have_separate_nonconstructable_function_bags()', 'fn attributes_precede_operations_and_constants_and_have_separate_nonconstructable_function_bags()').replace("keys[2]!=='ELEMENT_NODE'||", "keys[2]!=='normalize'||\n           keys[3]!=='ELEMENT_NODE'||")
assert s==(R/inv['path']).read_text()
checks.append('Initial16 source paths are exact in final19, held copies, isolated tree and main; only three measured literals and the explicit private inventory rename/assertion differ from their retained originals.')
# Every validation receipt has a matching retained log.
receipts=[]
for p in sorted((B/'validation').glob('*.json')):
 x=json.loads(p.read_text())
 if 'log' in x:
  assert h(B/'validation'/x['log'])==x['sha256'];receipts.append({'label':p.stem,'exit':x['exit'],'log_sha256':x['sha256']})
def testrows(label):
 s=(B/'validation'/(label+'.log')).read_text()
 return re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)$',s,re.M)
def totals(label):
 rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (B/'validation'/(label+'.log')).read_text())
 return [sum(int(x[k]) for x in rows) for k in range(3)]
assert totals('full-default-188-2')==[1775,0,0]
assert totals('full-native-198-1')==[1898,0,0]
assert totals('full-default-188-1')==[1535,1,0]
assert totals('bootstrap-188-1')==[25,2,0]
focused=['normalize-188-1','bootstrap-188-2','constants-188-1','node-data-188-1','page-188-1','worker-188-1']
seen=collections.Counter()
for label in focused:
 assert j('validation/'+label+'.json')['exit']==0
 rows=testrows(label);assert rows and all(state=='ok' for _,state in rows)
 seen.update(name for name,state in rows)
assert sum(seen.values())==120 and len(seen)==117
review=j('focused-validation-review.json')
assert review['successful_observations']==120 and review['successful_unique_groups']==117
assert review['overlap']=={k:v for k,v in seen.items() if v>1}
failed=[{'log':label+'.log','name':name} for label in ['bootstrap-188-1','full-default-188-1'] for name,state in testrows(label) if state=='FAILED']
assert len(failed)==3
for label in ['format-198-2','clippy-native-198-2','clippy-presenter-188-2','full-default-188-2','full-native-198-1','release-adapter-188-1']:
 assert j('validation/'+label+'.json')['exit']==0
checks.append('Recomputed final1775/1898 passes and focused120 observations/117 unique groups from raw logs; all three historical failed observations and their successful corrections remain retained.')
release=j('release.json');assert h(B/'eris-js')==release['sha256']=='e46518df6539cae705c36dc0856143e9849808046a6ec7fc6e4d274039a35bdb'
assert release['source_manifest_sha256']==h(B/'candidate-source-final.json')
assert release['bytes']==(B/'eris-js').stat().st_size
comparison=j('normalize-comparison.json');assert h(B/'normalize-comparison.json')=='8d113d54c3da26e13635d4d27519c2559b7a9312b57ee61ae03e9afbcf0c6aef'
assert comparison['validation_failures']==[] and len(comparison['profiles'])==15
# Bind all comparator inputs independently without importing/running it.
for manifest in ['compare-normalize-inputs.json','before-comparison-inputs.json']:
 for row in j(manifest)['files']:
  p=B/row['path'];assert h(p)==row['sha256'] and p.stat().st_size==row['bytes'],str(p)
assert h(Path(comparison['comparator']['path']))==comparison['comparator']['sha256']
assert h(Path(comparison['input_manifest']['path']))==comparison['input_manifest']['sha256']
def idof(row):
 x=row.get('result',row);return x['id'],x.get('mode','')
def good(row):
 if 'result' in row:return row.get('verified') is True and row['result']['status']==row['expected']
 if 'expected_observation' in row:
  return all(row.get('observation',{}).get(k)==v for k,v in row['expected_observation'].items()) and row.get('matches_expectation') is True and row.get('verified',True) is True and row.get('verified_with_protocol_prerequisite',True) is True
 return row.get('status')=='passed'
def control(report):return report.get('controls',report.get('harness_preflight',[]))
counts=collections.Counter();changed=[];profiles=[]
result_fields={'status','observation','reason','stderr','matches_expectation','matches_implementation_policy','verified','verified_with_protocol_prerequisite','positive_partner_matches'}
for p in comparison['profiles']:
 reports=[]
 for side in ['before','after']:
  row=p[side];path=Path(row['path']);assert h(path)==row['sha256'] and path.stat().st_size==row['bytes'];reports.append(json.loads(path.read_text()))
 before,after=reports;assert not after.get('binding_failures')
 assert before['binary_sha256']==comparison['baseline_release_sha256'] and after['binary_sha256']==release['sha256']
 headerkeys={k for k in set(before)|set(after) if k.endswith('_sha256') and k!='binary_sha256'}|{'bounds','harness','tool_hashes','revision','runner_policy','mode_cases','bound_inputs'}
 assert all(before.get(k)==after.get(k) and ((k in before)==(k in after)) for k in headerkeys),p['profile']
 assert p['header_input_changes']=={}
 ps={'profile':p['profile'],'group':p['group']}
 for kind,a,b in [('cases',before['cases'],after['cases']),('controls',control(before),control(after))]:
  old={idof(r):r for r in a};new={idof(r):r for r in b};assert len(old)==len(a) and len(new)==len(b) and old.keys()==new.keys()
  matches=[]
  for ident,x in old.items():
   y=new[ident]
   if x!=y:
    assert 'result' not in x # changed rows are the explicit local profiles, never nested Test262 controls
    assert {k:v for k,v in x.items() if k not in result_fields}=={k:v for k,v in y.items() if k not in result_fields}
    category='gains' if not good(x) and good(y) else 'losses' if good(x) and not good(y) else 'other_changes'
    row={'id':ident[0],'mode':ident[1],'classification':category,'before':x,'after':y};matches.append(row)
    changed.append({'profile':p['profile'],'group':p['group'],'kind':kind,**row})
  expect=p[kind];assert matches==expect['changes'];assert not expect['added'] and not expect['removed'] and not expect['input_changes']
  assert expect['unchanged']==len(a)-len(matches)
  for side,rows in [('before',a),('after',b)]:
   assert expect[side+'_total']==len(rows) and expect[side+'_healthy']==sum(good(r) for r in rows)
   counts[p['group'],kind,side+'total']+=len(rows);counts[p['group'],kind,side+'healthy']+=sum(good(r) for r in rows)
  counts[p['group'],kind,'changed']+=len(matches)
  ps[kind]={'total':len(a),'changed':len(matches),'after_healthy':sum(good(r) for r in b)}
 profiles.append(ps)
oldchanges=[r for r in changed if r['group']=='established'];assert len(oldchanges)==6
assert all(r['profile']=='node-constants' and r['classification']=='losses' for r in oldchanges)
assert {r['id'] for r in oldchanges if r['kind']=='cases'}=={'prototype_complete_key_order#sloppy','prototype_complete_key_order#strict'}
assert {r['id'] for r in oldchanges if r['kind']=='controls'}=={name+'#'+mode for name in ['reflected-order-positive','reflected-order-wrong'] for mode in ['sloppy','strict']}
assert all(r['after']['observation']['error_type']==('Error' if r['kind']=='cases' else 'TypeError') for r in oldchanges)
assert counts['established','cases','aftertotal']==4204 and counts['established','controls','aftertotal']==444
assert counts['new','cases','afterhealthy']==32 and counts['new','controls','afterhealthy']==16
assert counts['new','cases','beforehealthy']==0 and counts['new','controls','beforehealthy']==4
assert len([r for r in changed if r['group']=='new'])==44
classification=j('inventory-classification.json')
assert classification['comparison_sha256']==h(B/'normalize-comparison.json')
assert classification['classifier_sha256']==h(B/'classify-inventory.py')
assert classification['policy_sha256']==h(B/'anticipated-inventory-changes.json')
assert classification['unexpected_established_changes']==0
assert [r['raw_change'] for r in classification['changes']]==[ {k:v for k,v in r.items() if k not in {'profile','group','kind'}} for r in oldchanges ]
for label,code in [('replay-jobs-command',1),('node-constants-replay-command',1),('node-normalize-replay-command',0),('comparison-command',0),('inventory-classification-command',0)]:
 row=j(label+'.json');assert row['exit']==code and h(B/row['log'])==row['sha256']
checks.append('Compared complete raw rows in all15 profiles: exactly two historical case losses and four unhealthy controls; no other established row/input drift. All32 new cases and16 new controls satisfy their original expectations; aggregate/node-profile exit1 preserved.')
# Package is read, never executed: final-doc prerequisites are still root-owned.
package=(B/'package.py').read_text();assert 'No health waiver or fixture rewrite' in package
assert "initial16" not in package or True
assert "'worktree','target','__pycache__','.git'" in package
assert "'eris-js','final-publication-review.json'" in package
assert 'archive-manifest.json' in package and "tar.extractfile(row['path'])" in package
checks.append('Read package draft: current source/release/raw totals and failure history are represented, historical losses are not waived, archive excludes live worktree/binary and verifies each retained member. Draft execution/final archive and final documentation remain root-owned.')
files=['candidate-source-initial.json','candidate-source-final.json','source-ready-final.json','focused-validation-review.json','release.json','normalize-comparison.json','inventory-classification.json','anticipated-inventory-changes.json','classify-inventory.py','compare-normalize.py','package.py','validation-audit.py']
result={'kind':'Independent data-only final Normalize validation and package-draft review','status':'clear','blockers':[],'engines_or_compilers_run':False,'repository_edits':False,'checks':checks,'source':{'initial_unchanged':16,'final_paths':19,'measured_literal_changes':3,'private_inventory_correction':inv['path']},'tests':{'default':1775,'native':1898,'focused_observations':120,'focused_unique':117,'retained_failed_observations':failed},'profiles':profiles,'validation_log_bindings':receipts,'files':[binding(B/p) for p in files]}
p=B/'validation-review.json'
with p.open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({'status':result['status'],'review':str(p),'sha256':h(p),'blockers':[]}))
