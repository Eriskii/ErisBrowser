# Normalize Text-range removal: concrete held ledger

Only `src/dom.rs` (module declaration), `src/dom/node_normalize.rs`, and its private test module are owned here. The original dom.rs is preserved under `original/`. No compiler, engine or tests have run. Rust 1.88 rustfmt is the only Rust tool invoked, with edition 2024 and skip_children=true on those three files.

The crate-private API is `Document::remove_normalize_text_range(parent,start,end,survivor,&mut DomMutationBudget) -> Result<(),DomDataError>`. The nonempty half-open range is removed without allocation. Runtime owns current-run uniqueness proof and keeps it valid through immediate callback-free use. The helper does not detect arbitrary duplicate tail IDs itself; it freshly validates all range IDs, Text childlessness, backlinks and survivor exclusion. `Some(survivor)` also requires the immediately preceding child to be that authentic Text. `None` leaves the caller's empty-Text action interpretation with Runtime. It is not a general-purpose graph validator or a replacement for the runtime reached-ID map.

The parent must be an Element, the parentless actual Document root, or a parentless Fragment. A fragment's host association is not followed. Host/snapshot Document-parent Text remains accepted. No ancestor/depth walk is performed: removing these links cannot increase depth, and the private witness preserves an accepted depth-256 tree. Receiver/descendant traversal stays outside this module.

Let K=end-start and T=old_children_length-end. All arithmetic that can overflow uses checked add/multiply. Differences occur only after range bounds establish they are safe. The complete successful debit is:

`16 + (survivor.is_some() ? 12 : 0) + 12*K + 8 + 3*K + 2*T` work, zero charged bytes.

| Phase | Reached allowance | Operation covered |
| --- | --- | --- |
| Entry | 16 before reads | Arena bound, parent lookup/kind/root/parent checks, range ordering/end checks, children length bound. |
| Optional survivor | 12 before reads | Preceding-index check, survivor lookup, root/parent exclusions, backlink, leaf and Text checks. |
| Selected entries | 12 each before reads | Parent children lookup/index advance, child lookup, parent/root/survivor exclusion, backlink, empty child list and Text kind. |
| Final fixed staging | 8 | Checked counts/work sum, debit dispatch, final Vec length staging/commit bookkeeping. |
| Detach | 3K prepaid | Read each removed NodeId, locate its node, write parent=None, in existing order. |
| Suffix compaction | 2T prepaid | Each moved NodeId read and write; one copy_within. Truncate drops only Copy NodeIds and does not deallocate the Vec. |

Final debit happens before any link changes. Every error leaves this stage's Document state and both Vec capacities unchanged. Work refusal sets steps to zero through the existing meter. The helper never changes allocated or heap_limit, so it can succeed with no heap headroom and a full node arena. Caller bridges retain the absolute steps/allocated on both outcomes. There is no charge, checked arithmetic, allocator call, authored callback, or Result-returning operation after commit starts.

The payloads and retained_bytes ledger remain untouched. Runtime may already have published merged survivor data; refusal preserves that stage and still-attached tails. Success preserves all detached payloads/IDs and cannot create a reusable arena slot. No details-group traversal, BTree mutation, summary-cache invalidation, toggle operation or URL recomputation occurs. Verified Text leaves cannot change which base/summary Elements are selected.

One selected range compacts its suffix once. Multiple separate empty removals/runs can shift the suffix again; the total normalizer is not advertised as linear. Every call pays its reached physical shifts.

Eleven private groups cover literal merged/tail units, retained identities/bytes/capacities, independent empty removal, every work cut and exact successful boundary with nonzero initial allocation, actual suffix-length charge growth, invalid parent/ranges/local IDs/backlinks/leaf/survivor checks, earlier empty/replacement prefix retention, Document-parent Text at MAX_NODES with zero heap headroom, accepted depth256 via snapshot admission, independent template lists, and frozen base/cached summary/details/toggle state. Duplicate/cycle proof tests belong to the runtime owner; this module's tests explicitly state that boundary. Tests are prepared, not executed.
