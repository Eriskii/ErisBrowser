#!/usr/bin/env python3
"""Annotate six anticipated historical inventory losses without changing raw health."""
import hashlib,json,sys
from pathlib import Path
if not __debug__:raise SystemExit('Python optimization is refused')
B=Path(__file__).resolve().parent
P=B/'anticipated-inventory-changes.json'
EXPECTED='396002bf1bdff3c814a8e17bd6d4c503ec01be3d5e9453ae5a27c69344088a3f'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(P)==EXPECTED
policy=json.loads(P.read_text());old=json.loads((B/'comparison-before/node-constants-after.json').read_text())
assert len(policy['rows'])==6
for row in policy['rows']:
 assert [x for x in old[row['kind']] if x['id']==row['id'] and x['mode']==row['mode']]==[row['before']]
 assert row['before']['matches_expectation'] is True
 if row['kind']=='controls':assert row['before']['verified'] is True
if sys.argv[1:]==['--verify-before']:
 print(json.dumps({'verified_before':True,'anticipated_case_losses':2,'anticipated_unhealthy_controls':4,'policy_sha256':EXPECTED}));raise SystemExit
assert not sys.argv[1:]
path=B/'normalize-comparison.json';result=json.loads(path.read_text());assert not result['validation_failures']
assert result['candidate']['sha256']==sha(Path(result['candidate']['path']))
policies={(x['kind'],x['id'],x['mode']):x for x in policy['rows']};seen=set();annotated=[]
for profile in result['profiles']:
 if profile['group']!='established':continue
 for kind in ['cases','controls']:
  group=profile[kind]
  assert not group['input_changes'] and not group['removed'] and not group['added']
  for change in group['changes']:
   assert profile['profile']==policy['profile']
   key=(kind,change['id'],change['mode']);assert key in policies and key not in seen;seen.add(key)
   expected=policies[key];assert change['classification']=='losses' and change['before']==expected['before']
   after=change['after'];assert after['status']=='failed' and after['matches_expectation'] is False
   assert all(after['observation'].get(k)==v for k,v in expected['expected_after_observation'].items())
   if kind=='controls':assert after['verified'] is False and after['positive_partner_matches'] is False
   annotated.append({'profile':profile['profile'],'kind':kind,'classification':'anticipated historical represented-inventory loss','raw_change':change})
assert seen==set(policies)
for kind,count,loss in [('cases',4204,2),('controls',444,4)]:
 r=result['summary']['established'][kind]
 assert r['before_total']==r['after_total']==count and r['unchanged']==count-loss
 assert r['losses']==loss and r['gains']==r['other_changes']==0
for kind,count,before in [('cases',32,0),('controls',16,4)]:
 r=result['summary']['new'][kind]
 assert r['before_total']==r['after_total']==r['after_healthy']==count and r['before_healthy']==before
 assert r['gains']==count-before and r['unchanged']==before and r['losses']==r['other_changes']==0
current_path=B/'normalize-after.json'
current_profile=next(x for x in result['profiles'] if x['profile']=='node-normalize')
assert sha(current_path)==current_profile['after']['sha256']
current=json.loads(current_path.read_text())
assert current['binary_sha256']==result['candidate']['sha256']
for mode in ['sloppy','strict']:
 assert next(x for x in current['cases'] if x['id']=='represented_complete_key_order#'+mode)['matches_expectation'] is True
 for variant in ['positive','wrong']:
  row=next(x for x in current['controls'] if x['id']=='represented-node-order-'+variant+'#'+mode)
  assert row['verified'] is True and row['positive_partner_matches'] is True
out={'classification':'Six retained historical inventory assumptions are invalidated by the new ordinary Node method. Raw losses and unhealthy controls remain unchanged; no historical control-health waiver.','policy_sha256':EXPECTED,'comparison_sha256':sha(path),'classifier_sha256':sha(Path(__file__)),'expected_case_losses':2,'expected_unhealthy_controls':4,'unexpected_established_changes':0,'new_cases_healthy':32,'new_controls_healthy':16,'changes':annotated}
with (B/'inventory-classification.json').open('x') as f:json.dump(out,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in out.items() if k!='changes'},indent=2))
