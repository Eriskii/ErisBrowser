from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parent
r=json.loads((B/'comparison-before/node-constants-after.json').read_text())
case_ids=['prototype_complete_key_order#sloppy','prototype_complete_key_order#strict']
control_ids=['reflected-order-positive#sloppy','reflected-order-positive#strict','reflected-order-wrong#sloppy','reflected-order-wrong#strict']
rows=[]
for kind,ids in [('cases',case_ids),('controls',control_ids)]:
 for id in ids:
  old=next(x for x in r[kind] if x['id']==id)
  rows.append({'kind':kind,'id':id,'mode':old['mode'],'before':old,'expected_after_observation':{'status':'exception','phase':'runtime','error_type':'Error' if kind=='cases' else 'TypeError','error_identity':'Error' if kind=='cases' else 'TypeError'}})
p=B/'anticipated-inventory-changes.json';assert not p.exists()
p.write_text(json.dumps({'phase':'Frozen before Normalize candidate execution','base':'9825a53adf2f5751c85812e80dd60324a5c46258','profile':'node-constants','basis':'Adding the standard normalize operation before constants changes the represented prototype from22 to23 own keys. Old inputs and expected outcomes remain byte-exact historical assumptions.','policy':'Retain every old row and classify actual losses/unhealthy controls. This annotation never changes their expectation health, excludes rows, or treats failed historical controls as healthy. New independently authored complete inventory and positive/wrong controls cover current shape.','new_fixture_sha256':'337b5acb013b8e1aea04e933913c50746c0372185117edd32f84b48c648d3f20','rows':rows},indent=2)+'\n')
print(hashlib.sha256(p.read_bytes()).hexdigest())
