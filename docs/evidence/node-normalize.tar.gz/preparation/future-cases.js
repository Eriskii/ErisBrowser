// Deferred sketches only: XML/CDATA and live Range prerequisites are unavailable.
// These bodies are excluded from the ordinary source/mode count and any replay.
const futureNodeNormalizeCases={
  cdata_is_a_barrier_even_when_empty: function(){
    if(!document.implementation||typeof document.implementation.createDocument!=='function')
      throw new TypeError('deferred XMLDocument prerequisite');
    const xml=document.implementation.createDocument(null,'root'),root=xml.documentElement;
    if(typeof xml.createCDATASection!=='function')throw new TypeError('deferred CDATA prerequisite');
    const a=xml.createTextNode('a'),b=xml.createTextNode('b'),cd=xml.createCDATASection(''),c=xml.createTextNode('c'),d=xml.createTextNode('d');
    for(const node of [a,b,cd,c,d])root.appendChild(node);
    if(typeof root.normalize!=='function')throw new TypeError('normalize prerequisite');
    if(root.normalize()!==undefined||root.childNodes.length!==3||root.childNodes[0]!==a||root.childNodes[1]!==cd||root.childNodes[2]!==c)
      throw new Error('exclusive Text runs separated by CDATA');
    if(a.data!=='ab'||c.data!=='cd'||cd.nodeType!==4||cd.data!==''||b.parentNode!==null||d.parentNode!==null||b.data!=='b'||d.data!=='d')
      throw new Error('CDATA and removed nodes retain identities/data');
    return true;
  },
  live_ranges_move_from_merged_nodes_and_parent_boundaries: function(){
    if(typeof document.createRange!=='function')throw new TypeError('deferred live Range prerequisite');
    const box=document.createElement('div'),a=document.createTextNode('ab'),b=document.createTextNode('cd'),c=document.createTextNode('ef');
    box.append(a,b,c);const r=document.createRange(),s=document.createRange();
    r.setStart(b,1);r.setEnd(c,1);s.setStart(box,1);s.setEnd(box,2);
    if(typeof box.normalize!=='function')throw new TypeError('normalize prerequisite');
    if(box.normalize()!==undefined||box.childNodes.length!==1||box.firstChild!==a||a.data!=='abcdef')throw new Error('merged run');
    if(r.startContainer!==a||r.startOffset!==3||r.endContainer!==a||r.endOffset!==5||r.toString()!=='de')throw new Error('node boundary remap');
    if(s.startContainer!==a||s.startOffset!==2||s.endContainer!==a||s.endOffset!==4||s.toString()!=='cd')throw new Error('parent boundary remap');
    return true;
  }
};
