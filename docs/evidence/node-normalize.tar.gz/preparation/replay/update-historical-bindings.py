#!/usr/bin/env python3
"""Add historical control provenance using data only, preserving draft one."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value, mode='x'):
    with path.open(mode) as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


initial = HERE / 'initial-history-inventory'
initial.mkdir()
preserved = []
for name in ('preparation-history.json', 'replay-inputs.json', 'replay-matrix.json',
             'static-review.json', 'static-validation.json', 'README.md',
             'inert-verify.json', 'inert-verify.stdout', 'inert-verify.stderr'):
    raw = (HERE / name).read_bytes()
    with (initial / name).open('xb') as stream:
        stream.write(raw)
    preserved.append(dict(path=name, bytes=len(raw), sha256=sha(raw)))
save(initial / 'preserved.json', preserved)

inventory = json.loads((HERE / 'replay-inputs.json').read_text())
matrix = json.loads((HERE / 'replay-matrix.json').read_text())
history = json.loads((HERE / 'preparation-history.json').read_text())
old_rows = matrix['rows']
for origin, relative in [
    (Path('/tmp/eris-node-constants-batch-1/replay-preparation/replay-inputs.json'),
     'history/historical-node-replay-inputs.json'),
    (HERE.parent / 'historical-inventory-addendum.md', 'history/historical-inventory-addendum.md'),
]:
    raw = origin.read_bytes()
    with (HERE / relative).open('xb') as stream:
        stream.write(raw)
    history.append(dict(origin=str(origin), copy=relative, bytes=len(raw), sha256=sha(raw)))
old = json.loads((HERE / 'history/historical-node-replay-inputs.json').read_text())
pair = [r for r in old['controls'] if r['pair'] == 'reflected-order']
assert [r['name'] for r in pair] == ['reflected-order-positive', 'reflected-order-wrong']
assert all(r['modes'] == ['sloppy', 'strict'] and 'p.length!==22' in r['source'] for r in pair)
inventory['historical_node_inventory'].update(
    controls_source='history/historical-node-replay-inputs.json',
    controls_source_sha256=sha((HERE / 'history/historical-node-replay-inputs.json').read_bytes()),
    controls=[r['name'] for r in pair], affected_case_modes=2, affected_control_modes=4,
    expected_historical_inventory_differences=6,
    raw_failures_must_remain_visible=True,
    addendum='history/historical-inventory-addendum.md')
save(HERE / 'replay-inputs.json', inventory, 'w')
save(HERE / 'preparation-history.json', history, 'w')
paths = [HERE / 'replay.py', HERE / 'replay-inputs.json', HERE / 'preparation-history.json',
         *[HERE / row['copy'] for row in history]]
matrix['inventory_sha256'] = sha((HERE / 'replay-inputs.json').read_bytes())
matrix['bound_inputs'] = [dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p.read_bytes()))
                          for p in paths]
assert matrix['rows'] == old_rows and len(old_rows) == 48
assert inventory['cases'] == json.loads((initial / 'replay-inputs.json').read_text())['cases']
assert inventory['controls'] == json.loads((initial / 'replay-inputs.json').read_text())['controls']
save(HERE / 'replay-matrix.json', matrix, 'w')
save(HERE / 'historical-binding-correction.json', dict(
    reason='Add four historical reflected-order control modes to the existing two case modes',
    initial=preserved, bound_files=len(paths), history_copies=len(history),
    ordinary_case_modes=32, paired_control_modes=16, all_48_rows_unchanged=True,
    driver_unchanged=True, historical_case_modes=2, historical_control_modes=4,
    original_proposal_unchanged=True, engine_runs=0, compiler_runs=0))
print(json.dumps(dict(matrix_sha256=sha((HERE / 'replay-matrix.json').read_bytes()),
                      bound_files=len(paths), rows=len(old_rows))))
