#!/usr/bin/env python3
"""Write exclusive normalize replay inputs using data only; no runner import."""
import ast
import difflib
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREP = HERE.parent
PRIOR = Path('/tmp/eris-text-operations-preparation-1/replay')
FIXTURE_SHA = '337b5acb013b8e1aea04e933913c50746c0372185117edd32f84b48c648d3f20'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


history = []
for origin, relative in [
    (PREP / 'cases.js', 'independent/cases.js'),
    (PREP / 'cases.json', 'independent/cases.json'),
    (PREP / 'source-ready.json', 'independent/source-ready.json'),
    (PREP / 'references.json', 'independent/references.json'),
    (PREP / 'layout/fixture-source-review.json', 'history/layout-fixture-review.json'),
    (PREP / 'historical-node-constants.js', 'history/historical-node-constants.js'),
    (PRIOR / 'replay.py', 'history/text-replay.py'),
    (PRIOR / 'source-ready.json', 'history/text-source-ready.json'),
    *[(PRIOR / 'tools' / name, 'tools/' + name) for name in (
        'test262_conformance.py', 'html_conformance.py', 'import_test262.py')],
]:
    raw = origin.read_bytes()
    with (HERE / relative).open('xb') as stream:
        stream.write(raw)
    history.append(dict(origin=str(origin), copy=relative, bytes=len(raw), sha256=digest(raw)))
save(HERE / 'preparation-history.json', history)

fixture = (HERE / 'independent/cases.js').read_bytes()
assert digest(fixture) == FIXTURE_SHA
authored = json.loads((HERE / 'independent/cases.json').read_text())
assert authored['ordinary_sources'] == 16 and authored['ordinary_modes'] == 32
assert re.findall(r'^  ([a-z_]+): function', fixture.decode(), re.M) == [
    row['id'] for row in authored['ordinary_cases']]
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')

prefixes = [
    ('utf16-literal', 'common',
     r"var s='A\uD83D\uDE80\uD800',e=[65,55357,56960,55296];"
     "if(s.length!==4)throw new TypeError('UTF16 literal length');"
     "for(var i=0;i<4;i++){if(s.charCodeAt(i)!==e[i])throw new TypeError('UTF16 literal unit');}"),
    ('normalize-method', 'feature',
     "if(typeof Node!=='function'||typeof Text!=='function'||typeof Object.getOwnPropertyDescriptor!=='function')"
     "throw new TypeError('Node method prerequisites');"
     "var d=Object.getOwnPropertyDescriptor(Node.prototype,'normalize');"
     "if(!d||typeof d.value!=='function'||!d.writable||!d.enumerable||!d.configurable||"
     "d.get!==undefined||d.set!==undefined)throw new TypeError('normalize descriptor');"
     "var name=Object.getOwnPropertyDescriptor(d.value,'name'),length=Object.getOwnPropertyDescriptor(d.value,'length');"
     "if(!name||name.value!=='normalize'||name.writable||name.enumerable||!name.configurable||"
     "!length||length.value!==0||length.writable||length.enumerable||!length.configurable)"
     "throw new TypeError('normalize metadata');"
     "var text=new Text('kept');if(text.normalize!==d.value||d.value.call(text)!==undefined||"
     "text.data!=='kept'||text.parentNode!==null)throw new TypeError('working authentic leaf call');"),
    ('exact-merge-retention', 'feature',
     "if(typeof Node!=='function'||typeof Text!=='function'||typeof DocumentFragment!=='function'||"
     "typeof Object.getOwnPropertyDescriptor!=='function')throw new TypeError('merge prerequisites');"
     "var d=Object.getOwnPropertyDescriptor(Node.prototype,'normalize');"
     "if(!d||typeof d.value!=='function')throw new TypeError('normalize function');"
     r"var box=new DocumentFragment(),a=new Text('A\uD83D'),empty=new Text(''),b=new Text('\uDE80B');"
     "if(typeof box.append!=='function')throw new TypeError('fragment append');box.append(a,empty,b);"
     "var before=box.childNodes;if(before.length!==3||before[0]!==a||before[1]!==empty||before[2]!==b)"
     "throw new TypeError('actual append success');"
     "if(d.value.call(box)!==undefined||box.childNodes.length!==1||box.firstChild!==a||a.parentNode!==box||"
     "empty.parentNode!==null||empty.data!==''||b.parentNode!==null)throw new TypeError('merge identities');"
     "var joined=a.data,e=[65,55357,56960,66];if(joined.length!==4)throw new TypeError('merged length');"
     "for(var i=0;i<4;i++){if(joined.charCodeAt(i)!==e[i])throw new TypeError('merged units');}"
     "if(b.data.length!==2||b.data.charCodeAt(0)!==56960||b.data.charCodeAt(1)!==66)"
     "throw new TypeError('detached original units');"),
    ('represented-node-order', 'feature',
     "if(typeof Node!=='function'||typeof Text!=='function'||typeof Symbol!=='function'||"
     "typeof Symbol.toStringTag!=='symbol'||typeof Reflect!=='object'||typeof Reflect.ownKeys!=='function')"
     "throw new TypeError('reflection prerequisites');"
     "var d=Object.getOwnPropertyDescriptor(Node.prototype,'normalize');"
     "if(!d||typeof d.value!=='function'||d.value.call(new Text('x'))!==undefined)"
     "throw new TypeError('working normalize prerequisite');"
     "var constants=['ELEMENT_NODE','ATTRIBUTE_NODE','TEXT_NODE','CDATA_SECTION_NODE','ENTITY_REFERENCE_NODE',"
     "'ENTITY_NODE','PROCESSING_INSTRUCTION_NODE','COMMENT_NODE','DOCUMENT_NODE','DOCUMENT_TYPE_NODE',"
     "'DOCUMENT_FRAGMENT_NODE','NOTATION_NODE','DOCUMENT_POSITION_DISCONNECTED','DOCUMENT_POSITION_PRECEDING',"
     "'DOCUMENT_POSITION_FOLLOWING','DOCUMENT_POSITION_CONTAINS','DOCUMENT_POSITION_CONTAINED_BY',"
     "'DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC'];"
     "var expected=['nodeValue','textContent','normalize'].concat(constants,['constructor']);"
     "var actual=Reflect.ownKeys(Node.prototype);"
     "if(actual.length!==23||actual[22]!==Symbol.toStringTag)throw new TypeError('new prototype inventory size/tag');"
     "for(var i=0;i<22;i++){if(actual[i]!==expected[i])throw new TypeError('new prototype inventory order');}"
     "var ctor=Reflect.ownKeys(Node),old=['length','name','prototype'].concat(constants);"
     "if(ctor.length!==21)throw new TypeError('unchanged constructor inventory size');"
     "for(var i=0;i<21;i++){if(ctor[i]!==old[i])throw new TypeError('unchanged constructor inventory order');}"),
]
controls = []
for pair, area, prefix in prefixes:
    for positive in (True, False):
        controls.append(dict(name=pair + ('-positive' if positive else '-wrong'),
                             pair=pair, positive=positive, area=area,
                             modes=['sloppy', 'strict'],
                             source=prefix + ('' if positive else "throw new Error('deliberately wrong expectation');"),
                             expected_observation=complete if positive else wrong))
inventory = dict(fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA,
                 collection='nodeNormalizeCases',
                 cases=[dict(name=row['id'], modes=['sloppy', 'strict'], expected_observation=complete)
                        for row in authored['ordinary_cases']],
                 controls=controls, case_modes=32, control_modes=16, baseline_binary=None,
                 deferred=dict(admitted=False, sources=2, scope='CDATA and live Range sketches'),
                 historical_node_inventory=dict(
                     source='history/historical-node-constants.js',
                     sha256='e3253ef6cdc80310be70fa6975e5bbe41ba9482177ac568e6bc5dc2156685d1a',
                     case='prototype_complete_key_order', modes=['sloppy', 'strict'],
                     run_in_this_matrix=False,
                     purpose='Exact old inventory retained for a separate historical comparison'))
save(HERE / 'replay-inputs.json', inventory)

old = (PRIOR / 'replay.py').read_text()
new = old
for before, after in [
    ('Frozen Text operation observations', 'Frozen Node normalize observations'),
    ('6a7d6f008628d4fab814ab380dc1e1590a77a22b6154532ec7a39a4efc0e2363', FIXTURE_SHA),
    ('textOperationCases', 'nodeNormalizeCases'),
    ("len(inventory['cases']) == 14 and len(inventory['controls']) == 6",
     "len(inventory['cases']) == 16 and len(inventory['controls']) == 8"),
    ("== (28, 12)", "== (32, 16)"),
    ("file='text-operations.js'", "file='node-normalize.js'"),
    ('len(matrix) == 40', 'len(matrix) == 48'),
    ("for case, _ in matrix}) == 40", "for case, _ in matrix}) == 48"),
    ('Frozen 28 independent case modes and 12 paired controls',
     'Frozen 32 independent case modes and 16 paired controls'),
]:
    assert before in new, before
    new = new.replace(before, after)
ast.parse(new)
with (HERE / 'replay.py').open('x') as stream:
    stream.write(new)
with (HERE / 'replay.py.diff').open('x') as stream:
    stream.write(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                           fromfile='held-text/replay.py', tofile='normalize/replay.py')))

# Independently construct the inherited source/mode/metadata/harness identity.
# No helper module or driver is imported or executed here.
rows = []
for kind, inputs in [('case', inventory['cases']), ('control', controls)]:
    for row in inputs:
        body = (fixture + b'\nif(nodeNormalizeCases.' + row['name'].encode() +
                b'() !== true) throw new Error("case did not return true");'
                if kind == 'case' else row['source'].encode())
        for mode in row['modes']:
            identity = dict(source_sha256=digest(body), mode=mode,
                            metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None),
                            harness=[])
            fingerprint = digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())
            item = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind,
                        source_sha256=digest(body), case_sha256=fingerprint,
                        expected_observation=row['expected_observation'])
            if kind == 'control':
                item.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                            partner=row['pair'] + '-positive#' + mode)
            rows.append(item)
assert len(rows) == len({r['id'] for r in rows}) == 48
paths = [HERE / n for n in ('replay.py', 'replay-inputs.json', 'preparation-history.json')]
paths.extend(HERE / row['copy'] for row in history)
frozen = dict(fixture_sha256=FIXTURE_SHA,
              inventory_sha256=binding(HERE / 'replay-inputs.json')['sha256'],
              replay_sha256=binding(HERE / 'replay.py')['sha256'],
              runner_sha256=binding(HERE / 'tools/test262_conformance.py')['sha256'],
              bounds=dict(timeout_seconds=3, stdout_limit=96*1024, stderr_limit=64*1024,
                          execution='sequential inherited run_case'),
              bound_inputs=[binding(p) for p in paths], rows=rows)
save(HERE / 'replay-matrix.json', frozen)
assert len(paths) == 14
for row in frozen['bound_inputs']:
    assert binding(Path(row['path'])) == row
for row in controls:
    positive = next(x for x in controls if x['pair'] == row['pair'] and x['positive'])
    assert row['source'] == positive['source'] + ('' if row['positive'] else "throw new Error('deliberately wrong expectation');")
    assert all('TypeError' in throw for throw in re.findall(r'throw new ([^;]+)', positive['source']))
assert r"\uD83D" in prefixes[0][2] and r"\\uD83D" not in prefixes[0][2]
assert binding(HERE / 'history/historical-node-constants.js')['sha256'] == inventory['historical_node_inventory']['sha256']
save(HERE / 'static-validation.json', dict(
    status='passed data-only construction and consistency checks',
    matrix_rows=48, ordinary_modes=32, control_pairs=4, control_modes=16, bound_files=len(paths),
    python_ast='replay.py parsed, never imported or executed by this generator',
    fingerprints='all 48 constructed from the inherited identity formula',
    controls='four exact-prefix positive/wrong pairs; TypeError guards versus intrinsic Error tails; inherited positive-partner verification',
    fixtures='all16 bodies byte-exact; old Node fixture byte-exact and separate; deferred CDATA/Range excluded',
    engine_compiler_or_driver_runs=0, helper_imports=0))
print(json.dumps(dict(driver=binding(HERE / 'replay.py'), matrix=binding(HERE / 'replay-matrix.json'),
                     validation=binding(HERE / 'static-validation.json')), indent=2))
