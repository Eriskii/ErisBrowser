# Node.normalize: DOM implementation assessment

Preparation only, 2026-10-02. No code, compiler, engine, or fixture execution. Main is published `774c275b229198039a69cc996d0ffd05976dbf02`; the inspected Text worktree is a prospective dependency, not an assertion that Text validation or publication succeeded. `source-inputs.json` binds the exact inspected files.

Implement a paid descendant walk, reuse the existing canonical DOM-data builder, and add one checked Text-only removal seam. Do not route through textContent assignment, wholeText output, the parser, or the general raw remove_child operation. No new node is needed, and removing nodes does not recover arena slots.

## Normative boundary

The current algorithm visits descendant exclusive Text nodes in tree order. An empty node is removed immediately. A nonempty survivor receives the concatenated data of the remaining adjacent exclusive Text nodes through replace-data; live-range adjustments precede their ordered removal. The receiver itself is excluded. CDATA is not exclusive Text. Even a singleton reaches replace-data with an empty insertion. The IDL operation returns undefined, takes no arguments, and carries CEReactions. These details come from the [current Node algorithm and IDL](https://dom.spec.whatwg.org/#dom-node-normalize), read from the Living Standard updated 2026-09-24. [Exclusive Text](https://dom.spec.whatwg.org/#exclusive-text-node) and ordinary descendant relationships supply the traversal boundary.

## Existing implementation facts

`DomString` stores scalar data as UTF-8 and nonscalar data as exact u16 units. Its borrowed units iterator preserves cross-node surrogate pairing. `Runtime::plan_dom_data` and `emit_dom_data` already classify the whole repeatable stream, admit one exact output payload, and emit its canonical representation. They must receive borrowed stable data without intervening author callbacks.

`check_character_data_replacement` admits retained-old_survivor_bytes+new_survivor_bytes against 32 MiB and the resulting single payload against 8 MiB. `replace_character_data` repeats that check, preserves identity, and moves the admitted buffer. Removed tails remain allocated in Document.nodes and retain their complete original payloads. Runtime allocation is cumulative, so neither dropping the old survivor buffer nor detaching tails refunds its allocation counter. Existing author limits remain 100,000 work and 8 MiB charged heap; this proposal changes none of them or their reset sites.

The prospective Text sibling helpers already distinguish Document/Element/Fragment parents, childless Text, actual ordinary children, and snapshot-admitted Document-parent Text. Their small validation predicates are useful precedents. Reusing their private methods across sibling modules would require deliberate narrow visibility changes; do not assume they are already accessible. `whole_text_units_bounded` is unsuitable as a merge builder: it creates an unnecessary u16 buffer and its runtime caller applies the unrelated 256 Ki-unit JS string limit.

## Paid walk and smallest useful seams

Keep orchestration in a small runtime normalize module so it can reuse the existing paid canonical builder without moving or duplicating that builder. A private DOM module can own the checked removal seam. Suggested API shape, not frozen source:

```
Document::remove_normalize_text_range(
    parent: NodeId, start: usize, end: usize,
    survivor: Option<NodeId>, budget: &mut DomMutationBudget
) -> Result<(), DomDataError>
```

The half-open range contains only removed Text leaves. For an empty first Text it has length one and no survivor. For a merged run it excludes, and follows, the surviving Text. The helper rechecks parent kind, bounds, IDs, links and forbidden survivor alias, prepays validation and compaction, detaches in tree order, then compacts the children Vec once. It neither alters payloads nor allocates nodes nor changes retained bytes. Once its mutation starts there must be no allocation, callback, or Resource return. Existing absolute steps/allocated values must be copied back into Runtime on both success and failure.

Use an explicit DFS cursor with frames `(parent, next_child_index)` and a bounded visited-edge counter. Parent frames are advanced before descending; after removing an empty child retain its index, while after completing a merged run advance past the survivor. Pop exhausted frames. Visit ordinary children only. This avoids a full list of Text IDs that becomes stale during removal and avoids scanning unrelated arena entries.

Admit a cursor Vec header and each actual requested capacity before reservation; charge its full requested typed block and movement of existing frames when it grows, and each push/pop/cursor update. A leaf or empty container needs no heap cursor buffer. Bound depth and total reached edges independently of the work allowance. A child at edge-depth 256 remains accepted; no new depth is introduced. Do not walk ancestors or template hosts merely to revalidate a subtree whose structure does not grow.

At a reached nonempty Text, scan the right-adjacent Text interval with paid node/kind/backlink checks. Include empty trailing Text in that interval. Count and classify the complete survivor-plus-tail stream, freshly admit the replacement, emit it, and publish it into the survivor. Only then call the removal seam for the tails. Do not remove empty tails early to make admission easier. A non-Text barrier is visited normally next; its descendants are handled by DFS rather than flattened into the surrounding run.

The runtime walk can use existing crate-visible node fields with small local checked lookups. There is no need for a public iterator framework, a general tree mutation transaction, or a new DOM-string architecture. If a DOM-owned run descriptor is preferable for borrow checking, keep it to `(parent,start,end,survivor)` and consume it without callbacks; refresh its exact range before any write.

## Work and storage rows to freeze with concrete code

Let M be the selected run's members, B their total stored payload bytes, U the final unit count, S the final canonical payload bytes, K removed nodes, and T child IDs following the removed range. All additions/products require checked arithmetic.

| Reached work | Required charge / boundary |
| --- | --- |
| DFS lookup, edge and frame movement | Fixed charges before every reached lookup/branch and push/pop, including failure paths; no free skipped children. |
| Cursor growth | Header once, requested_capacity × size_of(Frame), and movement of every existing frame; admit before try_reserve_exact. No whole-arena scratch for a leaf/small subtree. |
| Reached-ID uniqueness map | One paid Entry search per marked ID, integer-key comparisons, conservative split/move work and full typed node storage; no allocation on leaf/empty fast paths. Caller-owned uniqueness proof is required for the immediate callback-free removal seam. |
| Run length/count pass | Pay member lookup/transition and actual UTF-8/unit traversal. Existing Text precedent uses 8 per member plus 1+B for each payload scan. |
| Builder input transitions | Include member transitions and repeated node lookups in source_work C, not only B. A concrete cloneable iterator can conservatively use C=B+8M with the existing lookup convention, subject to its actual implementation. |
| Existing canonical classification | C+2U+8 work. |
| Existing scalar emission | Another C+2U+8+S work and S heap bytes. |
| Existing nonscalar emission | C+U+8 work and 2U heap bytes, then the existing separate 2U+1 canonical validation. |
| Replacement publication | Fixed checked admission, payload move and retained-ledger update work, prepaid before publication. No Rc/string wrapper and no NodeVec growth. |
| Text-range removal | Fresh range/backlink validation, K parent-link writes, one overlapping copy of T NodeIds, and final Vec length change. Charge at least the actual T reads+writes (2T) plus all K validations and writes. Retain child Vec capacity. |

These are operation rows, not a proposed fee cut or a measured budget result. Final fixed constants and malformed-link validation costs must be reviewed against the concrete loops. The builder can stream across borrowed nodes without an intermediate concatenation Vec or JsString. Charge simultaneous cursor and output storage while all old source buffers remain alive. Refusing oversized canonical output is a resource outcome; do not truncate or substitute replacement characters.

Canonical size is not the sum of source storage sizes. Literal examples (hex units):

| Before attached nodes | Survivor after merge | Retained bytes before → after detach |
| --- | --- | --- |
| Scalar [0041], Units [D800] | Units [0041,D800] | 1+2=3 → 4+2=6 |
| Units [D83D], Units [DE80] | Scalar [D83D,DE80] | 2+2=4 → 4+2=6 |
| Units [D800], Scalar [4E00,4E01] | Units [D800,4E00,4E01] | 2+6=8 → 6+6=12 |

The rightmost term after the arrow includes the unchanged detached tail. Classification must span all members, including a surrogate pair repaired at a boundary. Independent per-node projection or source-byte summation gives the wrong result or admission.

## Resource prefixes and malformed input policy

There is no whole-tree rollback. A failure while visiting a later branch preserves earlier removals and completed runs. Count/classification/output/admission failure leaves the current run intact, although work/heap consumption remains recorded. After survivor publication, a refusal before removal leaves the enlarged survivor and still-attached tails; this can temporarily duplicate the subtree's aggregate text. A successful range-removal commit detaches all of that validated range. This proposed single-compaction helper has no failure inside its commit; therefore it does not manufacture a partially detached range. An implementation choosing per-node removal instead may expose a detached prefix and must retain it honestly, with all repeated vector shifts charged. Do not clear the survivor or rollback earlier operations after either outcome.

One-vector compaction is a real reduction of physical shifts, not a charge discount. It does not make the entire operation linear: separate empty removals or many runs can repeatedly shift the remaining suffix, and each actual shift must be charged. It is viable for the current callback-free represented Text removal slice; future mutation records, live ranges or per-removal hooks would need their own ordered actions before claiming full behavior. The normalizer must not call overridable JS appendData/removeChild/normalize functions internally.

Admitted snapshots guarantee unique ordinary child links and acyclic depth; public Rust mutation can violate those guarantees. Always bounds-check reached IDs, childless leaf kinds and backlinks; prohibit the receiver/ancestor being descended into and the survivor occurring among removed tails; bound all scans. Duplicate IDs in an otherwise locally consistent tail range need an explicit check: backlinks alone do not detect them. Following runtime-owner coordination, recommend a paid per-call BTreeMap<NodeId,()> or BTreeSet of reached IDs, allocated only after leaf/empty fast paths. Seed the receiver and mark every reached child, including every run tail, before current-run publication; cursor resumption must not mark the survivor twice. This detects duplicate tails and cycles within the reached subtree without a whole-arena bitmap or quadratic membership scan. Pay each actual integer-key search/insertion, reached split/movement bound and full typed node allowance before the operation; retain the inherited infallible BTree allocator limitation explicitly. Prefer one entry/insert operation to a redundant contains+insert pair and charge whichever is actually implemented. Prior mutations survive a later duplicate refusal. This is bounded reached-subtree validation, not a global audit of detached arena nodes or unvisited template contents. Final collection API, type/layout ledger and malformed-host tests still require concrete source review. The standalone range helper needs an explicit internal precondition that its range passed the per-call uniqueness admission; its own fresh checks remain required.

## Receiver, ownership and observable boundary

Document, Element and detached/template-content Fragment can be cursor roots. Authentic Text, Comment, PI and Doctype leaves return without processing themselves or neighbors; even an attached empty Text remains attached when it is the receiver. Structurally admitted host Document children may include Text, so handle them without inserting a new HierarchyRequestError. Normalization only removes/updates existing children and should not require spare node slots. At MAX_NODES it may still proceed within data/work limits; detached IDs remain unavailable for reuse.

An HTML template's ordinary children and its content fragment are separate child lists. Starting at the template walks the former; explicitly starting at its content fragment walks the latter. There is no host jump or concatenation across either boundary. Existing NodeKind has no CDATA or Attr implementation to add opportunistically.

The general remove_child scans for details membership, invalidates a summary map entry and can refresh the base URL. None is needed when removing verified Text leaves: details groups and selected base elements do not move, and first_summary caches an ID rather than a child index. Keep that cache, frozen base and any pending toggle state unchanged. No payload, expandos, listener identity or custom prototype on a detached tail should be destroyed.

Current Page::layout rereads the live document; stylesheets compare current direct Text source with cached originals; Page title and clean textarea read current aggregate data. Completed runs preserve those unit sequences, while a resource prefix after replacement need not. Avoid a blanket claim that rendering is unchanged: layout projects per Text, so merging [D83D] and [DE80] can replace two displayed replacement glyphs with one rocket while exact aggregate units stay unchanged. Compare against an independently built literal normalized reference, not simply the old canvas. Worker snapshots must retain removed nodes and their old data, with the survivor ID unchanged. Existing scalar title presentation and worker truncation policy stay separate.

## Focused checks and decisions before implementation

Useful private checks are: leading-empty removal followed by forced merge refusal; merged survivor followed by removal refusal; all step/heap cuts with absolute counter retention; exact one-short canonical output and retained-DOM limits without tail credit; no-new-node behavior at capacity; accepted depth 256; host Document Text; invalid IDs/backlinks/cycles/duplicate policy; retained detached payloads and owner identities; summary index shift without cache/queue changes; fixed base; template host isolation. A successful second normalization should preserve the resulting topology/data without requiring a new arena slot.

One small Page/worker fixture can retain all original Text handles, normalize a scalar run and a split-surrogate run on load/click, check exact literal units and survivor/removed IDs, and compare a nonempty rendered scene with a literal normalized reference. Separate short assertions can preserve title/style/clean-textarea aggregates, a primed summary ID and base URI. Snapshot checks must inspect detached nodes as well as connected children. Do not infer dirty-editor, selection or reaction support from those checks.

Live Range retargeting, MutationObserver records, CEReactions, shadow slotting, CDATA and Attr remain explicit gaps. Singleton/empty-tail no-op replacement is an implementation choice requiring a notification-gap qualification: retaining the existing replace-data route is simplest initially; skipping an otherwise pointless payload copy can be a genuine optimization only when its current observable scope and future hook obligation are stated. The recommended duplicate-link check still needs concrete typed accounting and source review; it does not change ordinary JS expectations.

Root also identified a separate runtime installer dependency: adding normalize changes Node.prototype's pre-constant bag from three to four members while the constructor remains three. Existing exact owner guards, paid capacity/work and the historical represented-key-order witness must be adapted honestly by that owner. No bootstrap saving, current Text success, or future normalize budget total is claimed here.
