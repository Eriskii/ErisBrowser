# Historical Node inventory observations

This additive correction preserves the initial sealed proposal and every independent JavaScript case unchanged. The initial proposal named two affected case modes but did not enumerate four affected control modes. No baseline or candidate engine has executed the normalize replay during this preparation.

The original Node constant replay has these six inventory-sensitive observations:

- `prototype_complete_key_order#sloppy` and `#strict` expect the previous prototype inventory.
- `reflected-order-positive#sloppy` and `#strict` require 22 total prototype keys, with constants immediately after `nodeValue` and `textContent`.
- `reflected-order-wrong#sloppy` and `#strict` repeat those prerequisites before the intentionally wrong `Error` tail.

Adding `normalize` before constants gives 23 total prototype keys. Thus the two old cases and four old controls are expected historical inventory differences. The old positive control should fail its TypeError prerequisite; the old wrong control should also stop at that prerequisite instead of reaching its expected Error tail. Neither old negative control is healthy when its same-mode positive partner fails. Preserve all original sources, ordinary expectations, raw observations and failed control status; do not claim all historical controls remain healthy. These are predictions from the fixed sources, not execution results.

The Node constructor remains at 21 keys. Its inventory and the other existing constant behavior remain comparison obligations. The new normalize replay already independently authored a `represented-node-order` positive/wrong pair: complete literal 22-string-plus-symbol prototype order and unchanged constructor order, after a successful authentic normalize call. It supplements the new syntax, method metadata and exact-merge controls; it does not replace or revise any old rows.

The normalize replay retains the complete original Node `replay-inputs.json` as `replay/history/historical-node-replay-inputs.json`. The old fixture and inventory are provenance inputs only in this matrix. Root will run the historical comparison separately and identify the exact two case/four control changes alongside all remaining rows. CDATA and Range sketches remain excluded.
