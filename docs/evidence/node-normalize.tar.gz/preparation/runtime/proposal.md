# Node.normalize runtime handoff

Source-only preparation against the held Text candidate based on `774c275b229198039a69cc996d0ffd05976dbf02`. `inputs.json` binds the inspected implementation and sibling plans. No repository edits, compiler, engine, or fixture execution belongs to this preparation. Text's observed raw bootstrap is 10,636 remaining work, 1,741,271 charged bytes, 681 objects/capacity, 321 native registry entries and 25 legacy prototype entries. Predictions below are conditional source arithmetic, not Normalize measurements.

## Binding and installation

Use a new `src/script/node_normalize.rs` module for traversal, with one ordinary cached Native named `DOM.Node.normalize`. Reuse the existing `node_data_function` factory through narrow `pub(super)` visibility; display name `normalize`, length 0, Undefined receiver, and a distinct two-property metadata bag. Its name/length retain nonwritable, nonenumerable, configurable flags; Node.prototype.normalize is writable, enumerable and configurable. It inherits Function.prototype, has no own prototype and is not constructible. No global/interface identity, virtual getter fallback or unscopables entry is added.

Install after `install_node_data_members` and before `install_node_constants` in the existing Node arm. Give `install_node_normalize` a fixed four-work debit and one `METADATA_OBJECTS` slot. Node's prototype order reservation becomes 23; its constructor reservation remains 21. The existing attributes precede the new operation, then constants and constructor, following [Web IDL prototype installation](https://webidl.spec.whatwg.org/#es-interface-prototype-object).

Reuse `DOM.Node.` invocation preflight and wrapper cache propagation, so machine/calls.rs needs no new production prefix branch. For the new full name, that existing preflight pays 22 work and 50 bytes before copying its temporary name within the cleanup boundary. In `node_data_native`, before the unchanged four-accessor dispatcher, prepay one work for a length discriminator. Only length-nine suffixes pay nine more work for comparison with `normalize`; a match delegates to the new handler. Thus existing accessor calls have one additional reached comparison debit, explicitly retained, while their original eight-work dispatch remains unchanged. Normalize itself then pays 16 work for its fixed brand/root checks. This avoids a new global native-prefix search or a hidden uncharged comparison. Unsupported private suffixes still fail explicitly.

The handler accepts Value::Document only when doc.root is a valid Document, and accepts an in-range Value::Node by its actual node kind, including a Node-valued Document alias. Authentic leaf kinds succeed without processing the receiver; forged prototype inheritors, primitives and invalid IDs fail TypeError. Mutable prototypes and own properties never confer or remove a native brand. No arguments are required or coerced; argument expression evaluation remains the ordinary caller's responsibility. All traversal reads use internal fields, never authored childNodes, data, length, parentNode or normalize properties. The [DOM operation](https://dom.spec.whatwg.org/#dom-node-normalize) covers descendant exclusive Text and returns undefined; CDATA, ranges, mutation records and custom reactions remain explicit absent facilities.

## Proposed private shapes

```rust
struct NormalizeFrame { parent: NodeId, next: usize }
struct NormalizeRun<'d> {
    doc: &'d Document,
    members: &'d [NodeId], // validated, unique contiguous Text leaves
    units: usize,
    source_bytes: usize,
}
// A cloneable, allocation-free iterator retaining the run's immutable borrow.
// Its member transitions inspect only validated IDs, then yield DomUnits.
struct NormalizeUnits<'d> { /* slice cursor + current DomUnits + doc borrow */ }

fn install_node_normalize(&mut self, prototype: usize) -> Result<()>;
fn node_normalize(&mut self, receiver: Value, doc: &mut Document) -> Result<Value>;
fn normalize_mark(&mut self, reached: &mut BTreeMap<NodeId, ()>, id: NodeId)
    -> Result<()>;
fn normalize_push(&mut self, frames: &mut Vec<NormalizeFrame>, frame: NormalizeFrame)
    -> Result<()>;
fn normalize_run<'d>(&mut self, doc: &'d Document, parent: NodeId, start: usize,
                    reached: &mut BTreeMap<NodeId, ()>) -> Result<NormalizeRun<'d>>;
```

Names are proposed seams rather than a requirement to expose structs across modules. A valid, privately constructed run makes the repeated iterator input safe: no author callback or DOM mutation occurs between validation, planning and emission. The iterator must not silently discard an invalid member. Any direct indexing relies only on this retained immutable borrow and prior bounds checks, with malformed-input tests exercising the validation before iterator construction.

The only new DOM mutation API is layout's proposed:

```rust
Document::remove_normalize_text_range(
    parent: NodeId, start: usize, end: usize, survivor: Option<NodeId>,
    budget: &mut DomMutationBudget,
) -> Result<(), DomDataError>;
```

Runtime proves reached-ID uniqueness before any current-run replacement. The immediate callback-free DOM helper independently checks the current parent/range, Text childlessness, backlinks and survivor exclusion. Its duplicate-prevalidation prerequisite must be documented; it is not a general externally reusable graph validator. Existing `check_character_data_replacement` and `replace_character_data` suffice for data. Every DOM budget uses absolute Runtime steps/allocated and MAX_HEAP, and both counters are copied back before mapping either result. No post-commit charge or arithmetic is permitted.

## Traversal and scratch admission

Pay eight work for the receiver's kind/children/arena-bound classification after its brand. A valid leaf or empty container returns without scratch allocation, parent walk or unrelated-arena traversal. Reject malformed leaf children explicitly. For a nonempty container, use a Vec of `(parent,next)` frames and a per-call BTreeMap<NodeId,()> of reached IDs. Seed the receiver, then mark each reached child exactly once. Never follow template_contents or fragment.host. This is an ordinary child-edge walk, not an inclusive-descendant or shadow-including walk.

Each loop iteration prepays eight work for frame/cursor/end decisions, plus twelve before the reached child ID/kind/backlink/bounds checks. Advance a parent's cursor before descending into an Element/Fragment; pop exhausted frames. A Document child is valid only as the actual root, which cannot be a descendant of this walk. A valid root Document may contain host-admitted Text children. Keep a checked reached-node cap MAX_NODES and frame depth MAX_DEPTH+1, accepting an edge depth of MAX_DEPTH. The seen map rejects repeated IDs, including cycles and same-parent duplicate tails, before the current run's publication. Previously completed prefixes remain if a later malformed link is reached.

For a first empty Text, call removal on its one-entry range and keep the cursor index. For a nonempty survivor, scan its right-hand Text interval, including empty tails; prepay eight work before each candidate/boundary check. Mark Text tails as discovered, but do not mark a non-Text barrier until its later DFS visit. The survivor was already marked by the outer loop and is not marked again. After merging/removal advance once past the survivor. This avoids rediscovering removed tails or rescanning the left sibling prefix. Bounds and backlink checks also apply at non-Text boundaries before kind inspection.

Cursor storage: charge the existing 32-byte temporary-vector allowance once, after the fast path. Before a push, pay one work. If full, select checked `max(len+1, min(2*capacity, MAX_DEPTH+1))`, prepay `1+2*len` movement work and the entire requested `capacity*sizeof(NormalizeFrame)` block, then try_reserve_exact before pushing. Pay one work for each pop. Previous blocks remain charged; no refund on growth or drop. Eight setup work covers empty scratch construction/teardown. No frames or payload references survive this call.

Reached-map storage/work uses the established BTree fanout bound with integer keys, rather than a full-arena bitmap or uncharged collection:

* Before computing the bound, pay 16 work for setup, checked count and its bounded integer-height loop. With m existing entries, use the existing bound h=0 for m=0; otherwise start h=1, capacity=(m+1)/2 and divide capacity by six while it is at least six. At most c=min(m,11h) key comparisons occur in one Entry lookup.
* Prepay `c + 44*(h+1) + 4` work. The rows are comparisons c; existing conservative split/shift/navigation `28*(h+1)`; node-header work `8*(h+1)`; prepaid eventual node traversal/destruction `8*(h+1)`; and four units for eventual entry traversal/destruction. This includes cleanup after a later Resource exit, without requiring budget after failure. The integer-height setup is a separate reached cost, not hidden inside a lookup.
* Define Q=`16*(sizeof(NodeId)+sizeof(()))+32*sizeof(usize)+64`. Charge Q at m=0; no node block for 1<=m<11; otherwise charge `(h+1)*Q` before Entry. A vacant insertion can allocate at most this many nodes; an occupied entry refuses duplicate input and is terminal. There is one Entry operation, no contains+insert double search. On current 64-bit targets Q is 448, but retain sizeof expressions in production.

The BTree allocation is the inherited infallible standard-library allocator boundary; logical prepayment is not physical OOM recovery. Scratch grows with reached nodes, not arena length, and remains cumulatively charged after drop. DFS/run discovery is a forward walk plus logarithmic reached-map operations; do not advertise unconditional linear-time normalization. The final implementation must review the fixed loop constants against its actual branches before this ledger becomes a code claim.

## Exact merge and mutation phases

For M selected Texts, first pay `9+B_i` per payload to validate/count its exact units and stored bytes. Sum U units and B stored bytes with checked arithmetic. This counting is separate from classification. Feed a cloneable borrowed stream to the unchanged `plan_dom_data` with `result_units=U` and `source_work=C=B+8M`. The per-member term pays repeated lookups, iterator transitions, empty members and EOF; no JS string, wholeText Vec, Rc allocation or MAX_STRING intermediate is used.

Existing builder work remains exactly: classification C+2U+8; scalar emission another C+2U+8+S and S charged bytes; nonscalar emission C+U+8 and 2U charged bytes followed by the separate 2U+1 canonical validation. Plan the entire joined stream before choosing one canonical payload, preserving pairs formed across member boundaries and all unmatched units. Do not sum per-node scalar projections or repeatedly append owned prefixes.

Pay eight work before fresh replacement-aware DOM admission. It credits only the old survivor payload; every tail's existing bytes remain retained. Emit the chosen payload, pay eight publication work, and move it through replace_character_data. Drop the run borrow before mutation. Then call the separately metered range-removal helper on tails, if any. It prepays all current range validation, parent-link writes, `2*T` movement for T following child IDs, and final vector-length change before any link write. All tails detach in their original order and the child vector compacts once; no node/payload is reclaimed. Text-only removal leaves base selection, named details groups, summary IDs and toggle state unchanged.

**Singleton decision:** initially run the same full canonical plan/emit/replacement path even when there are no tails. It copies the unchanged payload and consumes its measured work/storage; only the zero-length tail-removal call is skipped. This preserves a clear replacement stage and avoids an undocumented no-copy exception. No-op MutationObserver records, Range adjustments and CEReactions are still unimplemented; performing a payload copy does not supply those facilities. A later no-copy optimization would need its own scope/accounting review.

Before current replacement, failure retains only earlier completed empties/runs. After replacement, a removal refusal may retain the enlarged survivor and still-attached tails. Successful range compaction has no internal Resource exit; it does not invent a partial-tail prefix. Later-subtree failure preserves all earlier mutations. No whole-operation rollback, callbacks or late budget reset are added. Tail data, expandos, native identity and prototype overrides remain untouched. For two separate surrogate halves, total retained bytes can rise from four to six despite detachment; no future removal credit is available. A full node arena is acceptable because no node is created.

## Exact 4/3 Node constant batching change

Keep the literal 18-key permutation, UTF-16 comparison fee and typed representations. Replace the shared OLD_COUNT assumption with exact owner-specific constants/borrowed expected slices:

| Owner | Pre-map/order | Sorted old keys | Physical old order | Map after constants / order capacity |
|---|---:|---|---|---:|
| Prototype | 4 / 4 | nodeValue, normalize, textContent, tag | tag, nodeValue, textContent, normalize | 22 / 23 |
| Constructor | 3 / 3 | length, name, prototype | length, name, prototype | 21 / 21 |

Still require valid distinct owner IDs, symbol tag, exact keys/order, maximum key length and capacity. Preserve old descriptor values/native handles by move. Reserve the 18-key buffer and both complete entry buffers before either map is taken. Append constants in their original declaration order to both order vectors. Keep both new maps local until both builds succeed; invalid post-take staging discards the private initializer. No reusable-map rollback or physical OOM guarantee is introduced.

For o old entries and N=o+18, retain the small-map formula:

`map_work(o,N) = 3*(N-1)*42 +64 +4*(o+1) +6N +8N +16 +64 +24 +32`.

The three comparison passes are actual strict ordering, sorted-collect run checking and dedup. Prototype N=22 uses 63 full comparisons and 528 structure =3174; constructor N=21 keeps 60 comparisons and 510 structure =3030. Both pinned Rust versions still have at most one leaf overflow (`floor(N/12)=1`) and height one, so initial leaf plus at most two overflow allocations gives the same three-node bound at N=22. This explicit small-size proof matters: the looser floor(N/11)+h+1 bound alone would increase to four at 22. Both builds retain full possible 48-entry stable-sort scratch and direct unadvanced Vec IntoIter collection, as in the [held pinned-source review](../../eris-dom-prototypes-1/bulk-source-review.md).

Owner-guard work becomes `32+4*(o+1)+2o*42`: prototype388, constructor300, total688 versus600. Thus constant-helper work increases by144+88=232, from8244 to8476. All other rows are unchanged. Typed constant-helper storage becomes `14820+18K+139E+6Btree`, versus138E before: one additional entry slot, no extra sort block/node/refund. Here K=sizeof(PropertyKey), E=sizeof((PropertyKey,Property)), Btree=`16*(sizeof(PropertyKey)+sizeof(Property))+32*sizeof(usize)+64`.

## Conditional bootstrap prediction and tests

| Added reached component | Work |
|---|---:|
| normalize function bag/strings/Native | 121 |
| normalize owner key/insertion at existing count3 | 68 |
| one-time installer | 4 |
| exact 4/3 constant guards/builds | 232 |
| later constructor insertion count21→22 | 12 |
| **Total** | **437** |

That predicts remaining10,199 from held10,636, with682 objects/capacity and unchanged321/25 registries. Typed incremental charged storage is `1334 + sizeof(ScriptObject) + sizeof(Option<AbortSlot>) + sizeof(Option<f64>) + sizeof(Native) + 3K + Btree + E`. It includes the arena slot, metadata header/order/leaves, Node's extra order slot, all key/name Vec/Rc copies, Native name/handle and the extra constants entry. The old private Node batch's measured old/new charges imply K=16, E=72 and Btree=1472 on its tested target; combined with Text's observed6335-byte delta this conditionally predicts +3230 bytes, or1744501 total. This is inference from bound source/old observations, not a new type/layout measurement. Preserve first raw bootstrap result and any refusal before touching descriptive snapshots.

Private acceptance should cover measured exact/one-short metadata/helper boundaries, asymmetric owner rejection, retained normalize Rc identity, invalid permutation and terminal post-take discard. Update test-owned setup capacity/count to prototype23/4 and constructor21/3, retaining semantic assertions. Historical `nodeConstantCases.prototype_complete_key_order` strict/sloppy rows must remain byte-exact external history with an explicit inventory-change observation. The old reflected-order-positive and reflected-order-wrong controls also hard-code the prior 22-key total, in both modes: retain all four raw unhealthy historical control outcomes as well as both historical case losses. Do not report that old replay as all-controls-healthy. The new Normalize replay needs its own independently reviewed current-23-key positive/wrong pair. For the current Rust regression, rename only that group to `prior_node_constant_inventory_after_removing_configurable_normalize`. In each fresh realm/mode, save the actual normalize descriptor, delete this newly configurable property, invoke the unchanged `nodeConstantCases.prototype_complete_key_order()` body, and restore the descriptor in finally; require successful deletion and restored identity. This explicitly tests the prior inventory under its prior shape, not the current complete inventory, and must not catch/ignore an oracle failure. Deleting and redefining a configurable property cannot restore its original creation-order position: the finally block restores descriptor/value identity only. Use a fresh disposable realm for this historical-shape wrapper; run the new current-order oracle in a separate pristine realm. Keep the other six old cases and the fixture bytes unchanged. The independently authored Normalize `represented_complete_key_order` supplies the new literal complete represented inventory, pending peer freeze before implementation.

Runtime checks should exercise authentic Document/Node aliases and alternate prototypes, ignored poison arguments, saved identity and no resurrection, every work cut across empties/merged-survivor/tail-removal/later-subtree boundaries, canonical representation changes, no tail byte credit, full node arena, singleton-copy cost, unrelated arena independence, real frame growth, seen-map refusal/duplicate/cycle detection, depth-edge acceptance, malformed leaf/backlink/ID refusal and native invocation cleanup. Run sixteen independent ordinary bodies separately in both modes when authorized. Page/worker tests remain independently authored work; no fixture or production path was changed by this proposal.

Expected implementation paths: new runtime module/tests and script.rs module declaration; node_data.rs factory visibility/charged dispatch; dom_prototypes.rs metadata count/capacity/invocation; node_constants.rs and its private setup/ledger witnesses; DOM owner module/declaration; future reviewed fixture and descriptive assertions only after measurement. No machine prefix edit, wire change, constructor map change, general native fallback inventory, quota increase or author-entry reset is needed.
