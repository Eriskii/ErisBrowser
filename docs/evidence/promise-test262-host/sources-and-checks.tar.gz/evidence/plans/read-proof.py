from pathlib import Path
import urllib.request,json,hashlib,shutil
P=Path('/tmp/eris-promise-test262-plan-1');D=P/'proof';D.mkdir(exist_ok=True)
base=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser/tests/upstream/test262-object-is/inventory-proof')
for n in ['commit.json','tree-91b2052adad1f066ae031e2ff3a1e9bd6d732886.json','tree-a2eada339f3c7e678edfc08497985f261a9ae258.json','tree-b42c4a8f19ad479b70ee2f64ecd683735d83cde9.json','tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json']:
 if not (D/n).exists(): shutil.copyfile(base/n,D/n)
seen={};total=0
def tree(sha):
 global total
 if sha in seen:return seen[sha]
 assert len(seen)<32
 p=D/('tree-'+sha+'.json')
 if not p.exists():
  u='https://api.github.com/repos/tc39/test262/git/trees/'+sha
  data=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Eris-source-audit'}),timeout=20).read(2*1024*1024+1)
  assert len(data)<=2*1024*1024
  p.write_bytes(data)
 data=p.read_bytes();total+=len(data);assert total<=8*1024*1024
 j=json.loads(data);assert j['sha']==sha and j['truncated'] is False
 names=set();ordered=[]
 for e in j['tree']:
  n=e['path'];assert n not in names and '/' not in n and n not in ('.','..') and '\0' not in n;names.add(n)
  assert e['type'] in ('tree','blob') and e['mode'] in ('040000','100644','100755')
  ordered.append((n.encode()+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+n.encode()+b'\0'+bytes.fromhex(e['sha'])))
 body=b''.join(b for _,b in sorted(ordered));assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==sha
 seen[sha]=j['tree'];return j['tree']
root='91b2052adad1f066ae031e2ff3a1e9bd6d732886';sha=root
for segment in ('test','built-ins','Promise'):
 sha=next(e['sha'] for e in tree(sha) if e['path']==segment and e['type']=='tree')
assert sha=='176043820c3a0729f2da2a047303a984cca036c6'
dirs={};files=[]
def walk(path,sha):
 entries=tree(sha);direct=[e for e in entries if e['type']=='blob']
 dirs[path]={'tree':sha,'direct_files':len(direct),'direct_js':sum(e['path'].endswith('.js') for e in direct),'children':[e['path'] for e in entries if e['type']=='tree']}
 for e in entries:
  rel=path+'/'+e['path']
  if e['type']=='tree':walk(rel,e['sha'])
  else:files.append({'path':'test/built-ins/'+rel,'blob':e['sha'],'bytes':e['size'],'fixture':'_FIXTURE' in e['path']})
walk('Promise',sha)
inv={'status':'authenticated_complete_tree_inventory_only_no_case_execution','revision':'7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd','root_tree':root,'promise_tree':sha,'directories':dirs,'files':sorted(files,key=lambda x:x['path']),'total_files':len(files),'total_bytes':sum(f['bytes'] for f in files),'proof_documents':len(list(D.glob('*.json')))}
(P/'inventory.json').write_text(json.dumps(inv,indent=2)+'\n')
print(json.dumps({k:v for k,v in inv.items() if k!='files'},indent=2))
