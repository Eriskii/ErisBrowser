from pathlib import Path
import ast,hashlib,json,struct
root=Path('/tmp/eris-promise-test262-plan-1/concrete-1/tests-before')
hold=root/'transport-source-ready.json'
H=json.loads(hold.read_text())
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','bytes','sha256')):
   assert bind(v['path'])=={k:v[k] for k in ('path','bytes','sha256')}
  for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
verify(H)
test=Path(H['files'][0]['raw']['path']);a=ast.parse(test.read_text())
cls=next(n for n in a.body if isinstance(n,ast.ClassDef))
methods={n.name:n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
notes=json.loads(Path(H['notes']['path']).read_text())
assert list(methods)==notes['groups'] and len(methods)==H['group_count']==12
parent=Path('/tmp/eris-promise-finally-1/worktree/tools/test262_conformance.py')
p=ast.parse(parent.read_text()); funcs={n.name:n for n in p.body if isinstance(n,ast.FunctionDef)}
for n,argc in [('encode_request',1),('decode_response',1),('classify',2),('unsupported_reason',3)]:
 assert len(funcs[n].args.args)==argc
# Independently reconstruct the four frozen request byte witnesses from the specified field order.
def request(magic,mode,policy,source,harness=()):
 b=magic+bytes([mode,0])+(b'' if policy is None else bytes([policy]))+struct.pack('<I',len(harness))
 for name,data in harness:b+=struct.pack('<I',len(name))+name+struct.pack('<I',len(data))+data
 return b+struct.pack('<I',len(source))+source
legacy=next(n for n in ast.walk(methods[notes['groups'][0]]) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='assertEqual')
assert ast.literal_eval(legacy.args[1])==request(b'ERJS1',0,None,b'1')
method=methods['test_opt_in_erjs2_has_exact_policy_byte_and_retains_payload']
loop=next(n for n in method.body if isinstance(n,ast.For))
for policy,asynchronous,mode,header in ast.literal_eval(loop.iter):
 assert header+b'\0\0\0\0\1\0\0\0'+b'1'==request(b'ERJS2',int(mode=='strict'),policy,b'1')
asserts=[n for n in method.body if isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='assertEqual']
assert ast.literal_eval(asserts[-1].value.args[1])==request(b'ERJS2',0,1,b'$DONE();',[(b'x.js',b'2')])
protocol=Path('/tmp/eris-promise-test262-plan-1/concrete-1/protocol.json');P=json.loads(protocol.read_text())
assert struct.calcsize('<BBBBHBBI')==P['response']['tail_bytes']==12
assert len(P['response']['fixed_tail'])==8
cases=[
('test_legacy_framing_and_outcomes_remain_exact_without_opt_in','pass','Existing ERJS1 bytes, ERJR2 six-field dictionary and intrinsic parse-negative identity rules match.'),
('test_old_profile_host_and_async_exclusions_do_not_change','pass','Existing async early refusal and conservative $DONE/print source refusal have the asserted exact messages.'),
('test_opt_in_erjs2_has_exact_policy_byte_and_retains_payload','fail','First assertion compares the new ERJS2 header against parent ERJS1; parent ignores completion_policy.'),
('test_invalid_explicit_policy_and_new_mode_combinations_are_refused','fail','First policy=-1 row is ignored by parent encoder, so no ValueError is raised.'),
('test_only_new_profile_admits_done_and_print_harness_routes','fail','First async request meets parent unconditional async refusal before profile admission.'),
('test_new_profile_keeps_unimplemented_features_and_cross_realm_nonpass','pass','class/cross-realm remain outside supplied feature set, and $262 is caught by the unchanged source check.'),
('test_complete_erjr3_requires_matching_private_evidence','fail','Parent decoder raises invalid response magic for first valid ERJR3.'),
('test_host_vetoes_remain_failed_with_distinct_evidence','fail','Parent decoder raises invalid response magic before first new host-failure observation can be asserted.'),
('test_new_framing_rejects_missing_extra_and_out_of_domain_evidence','pass','Every row has unknown ERJR3/ERJR4 magic on parent; this does not demonstrate individual new-domain validation.'),
('test_new_complete_and_audit_contradictions_cannot_be_defaulted_to_pass','pass','Every row is rejected at parent magic gate; contradiction checks are unexercised on parent.'),
('test_classify_requires_protocol_and_policy_correspondence','fail','First requested-new/observed-old complete pair is incorrectly passed by parent classify, which ignores completion_policy.'),
('test_actual_errors_keep_phase_identity_and_never_use_sentinel_messages','fail','Parent decoder rejects the first ERJR3 exception before phase/error/sentinel assertions.')]
assert {n for n,r,_ in cases if r=='pass'}==set(notes['source_predicted_parent_groups']['pass'])
assert {n for n,r,_ in cases if r=='fail'}==set(notes['source_predicted_parent_groups']['fail'])
report={
 'status':'findings','scope':'Independent source/AST/hash/literal-byte inspection only; no project import, transport test execution, adapter invocation, Rust, browser, Git or live edits.',
 'hold':bind(hold),'tests':bind(test),'notes':bind(Path(H['notes']['path'])),
 'parent_runner':bind(parent),'parent_api_lines':{k:funcs[k].lineno for k in ['unsupported_reason','encode_request','decode_response','classify']},
 'contracts':H['proposed_contract'],
 'parent_compatible':True,'predicted_parent':{'observed':False,'passed_groups':5,'failed_groups':7,'rows':[{'group':n,'result':r,'source_basis':b} for n,r,b in cases]},
 'literal_checks':{'request_witnesses':4,'response_tail_bytes':12,'response_tail_fields':8,'group_count':12},
 'findings':[
 {'id':'bool_policy_isolation','severity':'test_gap','path':str(test),'group':'test_invalid_explicit_policy_and_new_mode_combinations_are_refused','detail':'The only explicit bool row uses True with synchronous metadata. An encoder that treats bool as int but rejects policy/async disagreement can pass this row while accepting True for async and False for sync.','requested_additive_correction':'Keep original rows and group count; add case(asynchronous=True, policy=True) and case(policy=False). Both must raise ValueError. Predicted parent5/7 split remains unchanged.'},
 {'id':'tail_field_count_wording','severity':'documentation','path':str(protocol),'detail':'response.decoder_result says nine named tail fields, but the selected fixed_tail, Test262Observation and test evidence dictionary contain eight fields totaling12 bytes.','requested_additive_correction':'Correct nine to eight in a new contract binding; no field/protocol/test value change.'}],
 'meaningful_coverage':['Legacy byte/dictionary/negative-identity controls coexist with new valid request/response cases, avoiding a decoder that rejects all new frames appearing sufficient.','New response domain and contradiction vectors, policy/version mismatch and host veto evidence protect pass classification; ordinary exception/resource/parse identity and sentinel text remain nonpass.','Malformed packet parent successes prove only the old magic refusal; later test rows in failed groups are not parent observations.','Small synthetic x.js/empty helper requests are encoder-only witnesses. Exact helper authentication, Runtime observation latches, shared quotas, real process framing and actual upstream outcomes are intentionally separate tests.'],
 'reviewer_changes':'Only this external review helper/receipt; held sources unchanged.'}
out=root/'transport-layout-review.json';out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(out)))
