from pathlib import Path
import json,hashlib,collections
P=Path('/tmp/eris-promise-test262-plan-1');W=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def put(name,value): (P/name).write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n')
def binding(path):
 p=Path(path);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
inv=json.loads((P/'inventory.json').read_text());metadata=json.loads((P/'selected-metadata.json').read_text());revision=inv['revision'];url='https://raw.githubusercontent.com/tc39/test262/'+revision+'/'
source_paths=['Cargo.toml','tools/import_test262.py','tools/test262_conformance.py','tools/test_test262_conformance.py','src/bin/eris-js.rs','src/script.rs','src/script/microtasks.rs','src/script/promises.rs','src/script/promises/semantics.rs','src/script/machine/calls.rs']
put('source-context.json',{'status':'read_only_source_bindings','parent':'3275179229f6d7753cedf0b66bd91998ada21707','source_root':str(W),'files':[binding(W/p) for p in source_paths],'prior_audit':binding('/tmp/eris-promise-test262-next-audit-1.json'),'separate_from_finally':True})
put('host-contract.json',{
 'status':'proposal_only_not_implemented_or_executed','scope':'An explicitly selected eris-js/Test262 host mode for bounded single-realm script + microtask tests. No browser-global host hooks, timers, agents, modules, general event loop, Promise API expansion, or limit increase.',
 'primary_sources':[
  {'url':url+'INTERPRETING.md','basis':'Test262-Defined Bindings, allowed harness-function overrides, async print completion, unchanged includes order, strict/raw/negative mode rules.'},
  {'url':url+'harness/doneprintHandle.js','basis':'The first argument is tested by truthiness. Falsy arguments indicate success; truthy arguments produce failure, with observable name/message or String conversion.'},
  {'url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-host-promise-rejection-tracker','basis':'Rejected-but-unhandled state is distinct from an ordinary exception reported by a host job. Handling a rejection during the same permitted checkpoint prevents a final unhandled verdict.'}
 ],
 'legacy_preservation':[
  'ERJS1 request decoding, ERJR2 output/classification, existing profile policy hashes/baselines/feature sets and harness ordering remain the old default. No blanket removal of async or host-hook exclusions.',
  'All new behavior requires a new request magic and explicit runner profile/policy. Existing profiles continue to send ERJS1; the adapter must not infer async mode from text, a Promise return value, console output, or a global named $DONE.',
  'Parse-negative requests continue to parse before host capture, Runtime creation, harness evaluation and hook installation. The selected 232 files contain no negative tests, but independent compatibility controls retain the existing parse-negative path.',
  'Store and hash every upstream source and helper byte unchanged. Document the host override as adapter policy, never a rewritten upstream fixture or harness blob.'
 ],
 'protocol_proposal':{
  'request':'ERJS2 + u8 mode + u8 parse_only + u8 completion_policy + existing u32 harness_count and bounded length-prefixed name/source pairs + source. Policy0 means checked synchronous, policy1 means authenticated async completion. Unknown bits/values, trailing bytes and illegal combinations fail closed.',
  'initial_restrictions':'Only sloppy/strict scripts and parse_only=false use ERJS2 initially. Raw/module, async runtime-negative and unsupported host contracts stay explicit unsupported. Existing ERJS1 handles parse-only controls. New sync Promise rows use policy0 so queued errors cannot be hidden by successful script return.',
  'response':'Use distinct ERJR3 with the six legacy semantic fields followed by fixed-width private evidence: policy, saturated completion-call count0/1/2, completion-error flag, authenticated-success-print count0/1/2, sticky failure bits, quiescent flag, and checked unhandled-rejection count. Exact byte widths/status roster must be frozen before implementation; malformed or contradictory evidence is adapter-error, never passed.',
  'limits':'Retain request4MiB, source2MiB, harness count32/name256, response field16384, stdout96KiB/stderr64KiB,512MiB AS/zero-core process cap and existing runner timeout/job limits. No repeated execute or fresh-budget polling to wait for completion.'
 },
 'installation_and_authentication':[
  'Prefer a separately gated test262-host facility: disabled in ordinary builds/realms; ERJS2 without the facility returns nonpass unsupported. Existing eris-js ERJS1 remains usable without it. Root must select the exact feature/API shape and measure any feature-enabled Runtime header delta before production.',
  'After successful normal Runtime initialization, enable one private one-shot session before harness execution, with bounded adapter setup accounting. This is not a new ordinary bootstrap intrinsic: current finally raw bootstrap leaves only5 work. Never add $DONE/print to normal bootstrap/global rosters.',
  'Install an adapter-only native print hook. Evaluate assert.js, sta.js and the exact authenticated doneprintHandle.js bytes in their existing order. Immediately after doneprintHandle returns successfully, capture its actual Function handle without author getters and replace only its global $DONE data value with a private native observer. Do this before any test-specific include may capture $DONE.',
  'The native observer is bound to the private session by immutable runtime identity, not by a mutable global, Native display name, console prefix, JavaScript counter or printed token. Retain the original harness Function privately. Saved aliases and call/apply must invoke the same authenticated observer.',
  'On every observed $DONE call, saturate a private count at2 and latch truthiness of argument0 before invoking author-accessible helper properties. Missing or any falsy first argument follows the pinned success branch (undefined,null,false,+0,-0,NaN,empty string; BigInt zero if later supported). Extra arguments are ignored by the harness. Objects and Symbols are truthy without coercion.',
  'Delegate to the saved original doneprintHandle function with the original args/receiver so its name/message getters, String conversion, __consolePrintHandle__/print lookup and exact abrupt behavior remain observable. The observer is not a replacement simplified JavaScript body. Its scoped active-invocation depth must be restored unconditionally on ordinary/fatal return.',
  'Native print may authenticate a success/failure sentinel only while that private observer is invoking the saved helper. A direct public print sentinel cannot authorize a pass. Truthy-argument failure is already sticky before getters can throw, lie, print a success marker or replace helpers. Completion-print counts also saturate at2.',
  'The completion observer is armed only for the test body. A call during harness setup, repeated adapter arming, duplicate $DONE, malformed print payload, forged completion print, or a failed helper invocation is nonpass. Replacing/deleting public $DONE or print does not reset private state; a saved observer alias remains usable. Loss of the genuine print path prevents successful completion evidence.',
  'The selected232 sources neither directly call print nor replace $DONE/__consolePrintHandle__. Full print-only Test262 async support is outside this first authenticated-$DONE profile and must remain unsupported if encountered later; do not silently count a printed string as authentication.'
 ],
 'checkpoint_and_verdict':[
  'Each harness entry uses its existing execute boundary; sticky observations survive all of them. Stop on any harness/initialization error before test execution. The test executes once, and the already-selected Runtime checkpoint drains the shared FIFO under that same author-turn budget, including jobs appended during the drain.',
  '$DONE success does not terminate execution or drain early. Continue the current synchronous body and all permitted queued jobs. A later duplicate, uncaught synchronous error, ordinary reported host job error, fatal stop, remaining queue, or unhandled rejection vetoes the provisional success.',
  'No new render/timer/task pump or budget reset. At return require author_depth0, checkpoint-running=false, queue empty and suspension=false. If the queue is empty but $DONE is absent, return missing-completion immediately: this finite profile has no external scheduler that could deliver a later result. Wall timeout remains a separate nonpass guard.',
  'Before reporter formatting, console-cap suppression or console publication, record a private sticky ordinary-job-error fact for callback and abrupt custom-capability Promise jobs. Reporter allocation/work failure is fatal regardless of previous $DONE. Console strings are diagnostic only; empty console is not evidence of success.',
  'At the final quiescent boundary inspect the private Promise arena for Settlement::Rejected with handled=false. Existing append/register paths already mark handled; do not mark every historical rejection as a sticky error. A source handled later within the permitted drain is okay, and propagated rejection is checked on its unhandled child.',
  'Prepay a checked bounded scan from the cached arena length before reading records; borrow state without cloning reasons, accessing constructors/getters, coercing values or executing callbacks. Scan refusal is resource/nonpass. Report only bounded counts/first private index if desired; never fabricate a JS exception.',
  'Policy1 pass requires normal body/harness completion, exactly one successful observer call, exactly one authenticated success print, no truthy completion argument or sticky failure, no final unhandled rejection and quiescent healthy runtime. Policy0 omits completion requirements but retains queued/fatal/unhandled checks.',
  'An unhandled rejection veto is an explicit adapter host policy, not proof that an upstream assertion failed. Preserve a distinct reason/category and raw evidence. Intentionally rejected-but-unhandled upstream tests, if observed, remain nonpass under this policy and are never silently waived or deleted.'
 ],
 'resource_contract_to_freeze_before_code':[
  'No new independent queue/job/heap allowance and no increase to100000 work,8MiB cumulative Runtime heap or stack/depth caps. Existing callback/Promise queue, dispatch, reporter and metadata charges remain unchanged in inactive/legacy mode.',
  'Use fixed-size saturating private observations; no unbounded log/vector per completion or queued error. Session allocation, original callable retention/clone/drop, global native metadata and lookup/insertion, wrapper call/argument ownership and final borrowed-arena scan all require explicit source-derived work/heap/cleanup admission.',
  'Install the session only after successful normal bootstrap under a bounded setup turn; each existing harness execute may retain its established reset, but the test body, all its jobs, completion delegation and final audit share one budget. Never reset after success, queue exhaustion, reporter error or audit refusal.',
  'Fatal observations and final Result must not depend on allocating a diagnostic. Preserve private sticky state even if a later observation charge refuses; ordinary job-error detection must occur before a report can be suppressed.',
  'Freeze exact/one-short setup, wrapper, observer publication and final audit cuts before implementation; include physical layout and unchanged128KiB startup controls on1.88 and current stable. Numeric new tariffs are deliberately unselected in this proposal.'
 ],
 'minimal_api_sketch':{
  'enable':'Runtime::enable_test262_host(policy)->Result<()>; trusted embedder only, once, no ordinary global installation before opt-in.',
  'harness_ready':'Runtime::bind_test262_done_from_harness()->Result<()>; only after exact selected doneprintHandle blob, before includes, data-only Function capture, no key/getter ambiguity.',
  'arm':'Runtime::arm_test262_body()->Result<()>; one-shot phase transition after all harness entries and their checkpoints are healthy.',
  'finish':'Runtime::finish_test262_body(&body_result)->Result<Test262Observation>; no author calls/reset/checkpoint restart; combines Result, private flags, health and metered arena scan.',
  'private_native_routes':'Dedicated authenticated native identity dispatch for observer/print; do not dispatch based solely on public Native.name or mutable receiver. Invocation cleanup must use the existing unconditional native-stack epilogue.'
 },
 'implementation_seams':{
  'tools/import_test262.py':'New profile and root-linked Promise directory/harness inventory. No old constants/counts changed.',
  'tools/test262_conformance.py':'Opt-in profile feature/host policy, request/response version branches, authenticated verdict, preflight pairs and policy-fingerprinted baseline. Existing unsupported_reason behavior remains default.',
  'src/bin/eris-js.rs':'Versioned decoder/evaluation path; per-harness hook binding/arming, fatal/no-DONE nonpass and bounded ERJR3 framing; no runtime initialization on parse-only.',
  'src/script/test262_host.rs (proposed)':'Feature-gated private session, native observer/print, snapshot/final audit interface and exact new fees.',
  'src/script/microtasks.rs':'Opt-in private error latch at ordinary job-error observation before reporter cap/formatting; unchanged scheduling and normal mode behavior.',
  'src/script/promises.rs':'Feature-gated borrowed quiescent unhandled count over existing settlement/handled fields; no web unhandledrejection events or settlement semantics change.',
  'src/script/machine/calls.rs':'Minimal explicit private native observer/print routing with identity authentication and existing stack cleanup.',
  'Cargo.toml/src/script.rs':'Only if selected feature/state plumbing requires it; no feature added or code changed by this plan.'
 },
 'open_selection_before_implementation':['Final feature gate/API/type shape and inactive-mode layout accounting.','Exact observer/print metadata descriptors and call-identity implementation; preserve delegated helper behavior.','Source-derived new fees and tests-first cuts, output framing widths/status codes.','Independent host-contract and inventory peer, then root-authorized implementation after the current finally/render checkpoint.']
})
# Full inventory remains broader than the proposed initial executable profile.
selected=set(metadata['selected_directories']);dirs=inv['directories'];bydir={}
for r in metadata['sources']:
 k=str(Path(r['path']).parent).removeprefix('test/built-ins/');c=bydir.setdefault(k,collections.Counter());c['files']+=1;c['async' if 'async' in r['metadata']['flags'] else 'sync']+=1;c['modes']+=1 if set(r['metadata']['flags'])&{'onlyStrict','noStrict','module','raw'} else 2
put('inventory-plan.json',{
 'status':'complete_authenticated_tree_roster_and_proposed_profile_not_conformance_results','revision':revision,'root_tree':inv['root_tree'],'promise_tree':inv['promise_tree'],
 'whole_promise_tree':{'directories':len(dirs),'files':inv['total_files'],'source_bytes':inv['total_bytes'],'counts':{k:v['direct_js'] for k,v in dirs.items()},'inventory_binding':binding(P/'inventory.json')},
 'proposed_first_profile':{'name':'promise-methods-async','complete_directories':{k:dict(bydir[k]) for k in sorted(selected)},'files':232,'mode_cases':458,'async_files':113,'async_modes':222,'sync_files':119,'sync_modes':236,'fixtures':0,'negative_files':0,'source_bytes':236187,'auxiliary_bytes':49033,'metadata_binding':binding(P/'selected-metadata.json')},
 'retained_outside_first_execution_scope':{k:v['direct_js'] for k,v in dirs.items() if k not in selected},
 'feature_policy':'Propose current construction/symbol feature set plus narrowly named Promise and Promise.prototype.finally for this directory-scoped profile, with async host policy only through ERJS2. Class and cross-realm remain unsupported. Keep all7 class-tagged files and the1 cross-realm/$262 file in denominators and report them without source rewriting. Actual eligible totals are policy-derived, not predicted passes.',
 'metadata_observations':{'flags':metadata['flags'],'features':metadata['features'],'module_raw_timeout_locale_negative':'none in selected232','host_tokens':'Only proto-from-ctor-realm.js uses $262. No selected test directly calls print or assigns $DONE/__consolePrintHandle__. Async sources rely on unchanged doneprintHandle.js.'},
 'integrity_steps':[
  'Preserve the pinned commit and root tree. Validate every nonrecursive tree by reconstructing its canonical Git tree object and checking SHA1, with no truncation, duplicate/unsafe paths, symlinks or submodules.',
  '21 proof documents (commit,3 ancestor trees,16 Promise trees,1 harness tree) occupy202996 bytes; this fits existing32-document/8MiB proof limits. Independently verify the harness tree too. Complete first-profile proof may retain all21 or an exact smaller subset, but manifest must bind the selected proof roster.',
  'Inventory all732 regular .js paths/blob IDs/lengths before execution selection. For the first232 source bodies and8 auxiliary blobs, verify Git blob SHA1 and local SHA256/bytes. These are stored only in the external planning cache; the project importer was not run.',
  'Authenticate LICENSE and INTERPRETING.md through the root tree; authenticate assert.js,sta.js,doneprintHandle.js,isConstructor.js,promiseHelper.js,propertyHelper.js through the harness tree. No polyfill, helper subset, transpilation, source suffix, altered assertion or per-test waiver.',
  'Future import uses the existing importer with a new profile, then load_corpus independently verifies the same roster/blobs. Full original bytes, include order and strict/non-strict variants are retained. Per-file failure/unsupported/resource statuses remain in the report.',
  'Record case hashes including source, metadata, mode, exact harness bytes and the new completion policy; freeze a distinct runner policy hash. Old profile case/policy baselines are unchanged and cannot be compared across the new policy as if it were a runtime-only improvement.',
  'Report complete selection and actual nonpass categories. No full Test262 or full Promise conformance claim; inventories of excluded combinator/try/withResolvers directories are provenance, not a support claim.'
 ],
 'source_retrieval_only':True,'compiled_or_run_cases':0
})
checks=[]
def case(id,source,expect,why,policy='authenticated-async',kind='literal-js'):
 checks.append({'id':id,'kind':kind,'policy':policy,'source':source,'expected':expect,'reason':why})
case('one-async-completion',"var reached=0; Promise.resolve(7).then(function(v){assert.sameValue(v,7);reached++;}).then(function(){assert.sameValue(reached,1);$DONE();},$DONE);",'passed','Healthy actual queued assertion and exactly one completion; guard typeof Promise/then and exact reached value in preflight.')
case('poisoned-queued-assertion',"var reached=0; Promise.resolve(7).then(function(v){assert.sameValue(v,8);reached++;}).then(function(){assert.sameValue(reached,1);$DONE();},$DONE);",'completion-error','Only7→8 differs from healthy partner; cannot succeed through missing Promise or ignored assertions.')
for arg in ['', 'undefined','null','false','0','-0','NaN',"''"]:case('falsy-done-'+(arg or 'omitted'),'$DONE('+arg+');','passed','Retain pinned helper ToBoolean semantics; one fresh realm per argument.')
case('truthy-done-error',"$DONE(new Test262Error('marker'));",'completion-error','Error path is nonpass regardless of formatting output.')
case('truthy-error-getter-abrupt',"var hits=0;try{$DONE({get name(){hits++;throw 7;}});}catch(e){assert.sameValue(e,7);}assert.sameValue(hits,1);",'completion-error','Latch truthy failure before delegating; preserve exactly one genuine helper getter and its abrupt completion.')
case('success-not-immediate-exit',"$DONE();throw new Test262Error('after');",'synchronous-exception','A provisional completion cannot hide later synchronous abrupt completion.')
case('missing-completion','Promise.resolve(7).then(function(v){assert.sameValue(v,7);});','missing-completion','Synchronous return and quiescent FIFO are insufficient for async.')
case('duplicate-sync',"$DONE();try{$DONE();}catch(e){}",'duplicate-completion','Private duplicate state cannot be erased by catching errors.')
case('duplicate-queued',"$DONE();Promise.resolve().then($DONE);",'duplicate-completion','Must drain jobs after first success.')
case('queued-error-before-done',"queueMicrotask(function(){throw new Test262Error('job');});queueMicrotask(function(){$DONE();});",'queued-exception','Ordinary callback error remains a sticky host observation even though the drain reaches completion.')
case('queued-error-after-done',"$DONE();queueMicrotask(function(){throw new Test262Error('job');});",'queued-exception','Later queued error vetoes provisional success.')
case('custom-capability-job-error',"function C(executor){executor(function(){throw 'cap';},function(){});}var p=Promise.resolve(1);p.constructor={};p.constructor[Symbol.species]=C;p.then();$DONE();",'queued-exception','Abrupt custom capability is reported as a Promise job error, not an ordinary handled rejection.')
case('handled-rejection',"Promise.reject('marker').then(undefined,function(v){assert.sameValue(v,'marker');}).then($DONE,$DONE);",'passed','Expected handled rejection does not latch the ordinary reported-job-error flag.')
case('handled-later-in-checkpoint',"var p=Promise.reject('marker');queueMicrotask(function(){p.catch(function(v){assert.sameValue(v,'marker');}).then($DONE,$DONE);});",'passed','Final quiescent state matters; do not permanently poison on initial rejection.')
case('unhandled-rejection-after-success',"$DONE();Promise.resolve().then(function(){throw 'marker';});",'unhandled-rejection','A thrown handler becomes an unhandled rejected child even if no console reporter is called.')
case('propagated-unhandled-child',"var p=Promise.reject('marker');p.then();p.catch(function(){});$DONE();",'unhandled-rejection','The handled parent does not excuse an unhandled child.')
case('forged-print-no-done',"print('Test262:AsyncTestComplete');",'unauthenticated-completion','Exact public sentinel text alone is not a pass.')
case('console-spoof',"console.log('Test262:AsyncTestComplete');",'missing-completion','Console text is never the completion channel.')
case('overwritten-done-noop',"$DONE=function(){};$DONE();",'missing-completion','A function merely named $DONE cannot mutate private state.')
case('saved-done-alias',"var done=$DONE;$DONE=function(){throw 7;};Promise.resolve().then(function(){done();});",'passed','The genuine saved callable remains authenticated after global replacement.')
case('overwritten-print-noop',"print=function(){};$DONE();",'completion-protocol-error','Observer call alone cannot hide loss of the delegated original helper print path.')
case('fatal-after-success',"$DONE();queueMicrotask(function(){while(true){}});",'resource','No retry, increased limit or pass after exhausted checkpoint.')
case('checked-sync-queued-failure',"queueMicrotask(function(){throw 'marker';});",'queued-exception','New profile synchronous rows require a healthy final checkpoint too.',policy='checked-sync')
case('sync-no-done-required','Promise.resolve(1).then(function(v){assert.sameValue(v,1);});','passed','Checked synchronous rows do not require async completion.',policy='checked-sync')
case('suppressed-reporter-private-control','Preload console at reporter admission threshold1024, queue an ordinary throwing callback followed by genuine DONE; independently repeat with a cleared console.','queued-exception','Latch before capped reporter/formatting; author console contents cannot authorize success.',kind='private-rust-fixture-plan')
case('audit-one-short','Run healthy async body with N private Promise records; exact remaining audit fee passes, one less refuses before traversing; no budget reset.','exact-pass-one-short-resource','Meaningful final-audit refusal contract; numerical fee to be selected from implementation source before tests are frozen.',kind='private-rust-fixture-plan')
case('setup-failure-before-arm','Inject metadata/global/session allocation refusal, then ensure no test body runs and no prepared success can be emitted.','adapter-initialization-error','Setup is not an author negative exception; no cap increases.',kind='private-rust-fixture-plan')
case('harness-premature-done','A test include invokes the observed DONE before body arming; another include only queues a throwing callback.','harness-error','Neither case can be hidden by the next harness execute reset.',kind='transport-harness-fixture-plan')
case('protocol-compatibility','Retain exact ERJS1→ERJR2 fixtures and all old runner policy baselines; add unknown magic/policy, illegal mode, truncation, oversized frame, duplicate/missing evidence and contradictory ERJR3 fixtures.','legacy-exact-new-invalid-nonpass','No unchecked defaulting from malformed async evidence.',kind='binary-framing-fixture-plan')
case('parse-negative-compatibility','Existing ERJS1 parse_only malformed source returns expected parse SyntaxError with a host-capture closure that would panic if invoked; runtime SyntaxError cannot pass a parse-negative.','legacy-exact','No Runtime/session/harness invocation before parsing.',kind='adapter-fixture-plan')
put('guarded-cases.json',{'status':'independent_literal_proposals_frozen_before_any_implementation_or_execution','harness':'Exact pinned assert.js/sta.js/doneprintHandle.js; actual runtime helper preflight separately checks promiseHelper.checkSequence and propertyHelper healthy/poisoned pairs.','cases':checks,'preflight_rule':'Both healthy and poisoned partners must reach guarded actual Promise behavior; require exact expected category, not any generic failure. If a prerequisite is unavailable, preflight fails and no upstream pass claim is issued.','note':'These are planning literals, not imported Rust/Python tests or observed results; final API/fees require tests-first freeze.'})
# Bind every retained proof/cache byte and every authored plan artifact; no self-embedding.
outputs=['source-context.json','host-contract.json','inventory-plan.json','guarded-cases.json','inventory.json','selected-metadata.json','read-proof.py','read-selected-sources.py','write-plan.py']
entries=[binding(P/name) for name in outputs]
entries += [binding(p) for sub in ['proof','primary-cache'] for p in sorted((P/sub).rglob('*')) if p.is_file()]
put('source-ready.json',{'status':'source_only_proposal_ready_for_root_selection','revision':revision,'parent':'3275179229f6d7753cedf0b66bd91998ada21707','files':entries,'all_promise_tree_files':732,'proposed_profile_files':232,'proposed_profile_modes':458,'prototype_finally_files':29,'project_imports':0,'project_execution':False,'changes_to_live_source':False,'claims':'Authenticated inventory and source-derived design only; no upstream passing result or full conformance claim. New fees/API/framing remain subject to root selection and independent peer before implementation.'})
print(json.dumps(binding(P/'source-ready.json')))
