from pathlib import Path
import json,ast,pprint,difflib
R=Path('/tmp/eris-promise-test262-plan-1/runner-1')
s=(R/'before/tools/test262_conformance.py').read_text()
def replace(a,b):
 global s
 assert s.count(a)==1,(a[:100],s.count(a))
 s=s.replace(a,b)
replace("INTRINSIC_ERRORS = {'Error',", "PROMISE_PROFILE = 'promise-methods-async'\nPROMISE_FEATURES = {'Promise', 'Promise.prototype.finally', 'Symbol.species',\n                    'Reflect.construct', 'arrow-function', 'Reflect',\n                    'Symbol.toStringTag', 'Symbol'}\nPROFILE_FEATURES[PROMISE_PROFILE] = PROMISE_FEATURES\nINTRINSIC_ERRORS = {'Error',")
replace("    if profile in {'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:","    if profile in {'promise-methods-async', 'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:")
replace("        if profile in {'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys() != (", "        if profile in {'promise-methods-async', 'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys() != (")
replace("        names = harness_names(metadata)\n        harness = []", "        names = harness_names(metadata)\n        if profile == PROMISE_PROFILE and len(set(names)) != len(names):\n            raise ValueError('duplicate Promise harness include')\n        harness = []")
replace("                        source=files[path], metadata=metadata, harness=harness)\n            case['case_sha256']", "                        source=files[path], metadata=metadata, harness=harness)\n            if profile == PROMISE_PROFILE:\n                case['completion_policy'] = int('async' in metadata['flags'])\n            case['case_sha256']")
replace("                    harness=[dict(name=name, sha256=digest(source)) for name, source in case['harness']])\n    return digest", "                    harness=[dict(name=name, sha256=digest(source)) for name, source in case['harness']])\n    if 'completion_policy' in case:\n        identity['completion_policy'] = case['completion_policy']\n    return digest")
replace("    metadata = case['metadata']\n    flags = set(metadata['flags'])\n    if case['mode']", "    metadata = case['metadata']\n    flags = set(metadata['flags'])\n    if profile == PROMISE_PROFILE:\n        policy = case.get('completion_policy')\n        if (type(policy) is not int or policy not in (0, 1)\n                or policy != int('async' in flags)):\n            return 'Promise completion policy does not match metadata'\n        if case['mode'] not in {'sloppy', 'strict'} or metadata['negative'] is not None:\n            return 'Promise profile supports only ordinary sloppy/strict script modes'\n    if case['mode']")
replace("    if 'async' in flags:\n        return 'asynchronous completion and jobs are not implemented'", "    if 'async' in flags and profile != PROMISE_PROFILE:\n        return 'asynchronous completion and jobs are not implemented'")
replace("    if any(re.search(rb'\\$262\\b|\\$DONE\\b|\\bprint\\s*\\(', source) for source in sources):", "    if profile == PROMISE_PROFILE:\n        if any(re.search(rb'\\$262\\b', source) for source in sources):\n            return 'Test262 realm host hooks are not implemented (conservative source check)'\n        return None\n    if any(re.search(rb'\\$262\\b|\\$DONE\\b|\\bprint\\s*\\(', source) for source in sources):")
replace("def encode_request(case):\n    output = bytearray(b'ERJS1')", "def encode_request(case):\n    selected = 'completion_policy' in case\n    if selected:\n        policy = case['completion_policy']\n        if (type(policy) is not int or policy not in (0, 1)\n                or policy != int('async' in case['metadata']['flags'])\n                or case['mode'] not in {'sloppy', 'strict'}\n                or (case['metadata']['negative'] or {}).get('phase') == 'parse'):\n            raise ValueError('invalid Promise completion policy or mode')\n    output = bytearray(b'ERJS2' if selected else b'ERJS1')")
replace("    output.append(int((case['metadata']['negative'] or {}).get('phase') == 'parse'))\n    output.extend", "    output.append(int((case['metadata']['negative'] or {}).get('phase') == 'parse'))\n    if selected:\n        output.append(policy)\n    output.extend")
replace("def decode_response(output):\n    if not output.startswith", "def decode_response(output):\n    if output.startswith(b'ERJR3'):\n        return decode_promise_response(output)\n    if not output.startswith")
replace("def classify(case, observation):\n    status", "def classify(case, observation):\n    if 'completion_policy' in case or 'completion' in observation:\n        return classify_promise(case, observation)\n    status")
replace('    """Fail closed if the upstream assertions no longer enforce basic failures."""\n    scripts = [', '    """Fail closed if the upstream assertions no longer enforce basic failures."""\n    if profile == PROMISE_PROFILE:\n        return promise_harness_preflight(files, binary, timeout)\n    scripts = [')
old='''        preflight_ok = all(item['verified'] for item in preflight)
        supported_features = PROFILE_FEATURES[args.profile]
        with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
            results = list(pool.map(lambda case: run_case(case, binary, args.timeout, supported_features, args.profile), cases))
'''
new='''        preflight_ok = (promise_preflight_healthy(preflight) if args.profile == PROMISE_PROFILE
                        else all(item['verified'] for item in preflight))
        supported_features = PROFILE_FEATURES[args.profile]
        if args.profile == PROMISE_PROFILE and not preflight_ok:
            results = [dict(id=case['id'], file=case['file'], mode=case['mode'],
                            case_sha256=case['case_sha256'], source_sha256=digest(case['source']),
                            expected_negative=case['metadata']['negative'], status='blocked',
                            reason='Promise host preflight failed') for case in cases]
        else:
            with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
                results = list(pool.map(lambda case: run_case(case, binary, args.timeout, supported_features, args.profile), cases))
'''
replace(old,new)
replace("        policy_hash = digest(json.dumps(policy, sort_keys=True).encode())", "        if args.profile == PROMISE_PROFILE:\n            policy.update(format=3, async_completion=True, host_hooks=True,\n                          request_protocol='ERJS2', response_protocol='ERJR3',\n                          adapter_feature='test262-host',\n                          completion_policy={'sync': 'checked-sync', 'async': 'authenticated-done'},\n                          unhandled_rejection_policy='final-quiescent-veto', print_only_completion=False)\n        policy_hash = digest(json.dumps(policy, sort_keys=True).encode())")
controls=json.loads((R/'tests-before/raw/tools/promise-methods-runner-oracle.json').read_text())['controls']
variants='def promise_preflight_variants():\n    """Frozen37 sources; both modes run, with no outcome-based selection."""\n    return '+pprint.pformat(controls,width=110,sort_dicts=False).replace('\n','\n    ')+'\n\n\n'
helpers=(R/'production-draft/helpers.py.txt').read_text()
replace('def check_baseline(previous, current):', variants+helpers+'\n\n'+'def check_baseline(previous, current):')
ast.parse(s)
out=R/'raw/tools/test262_conformance.py';out.parent.mkdir(parents=True,exist_ok=True);out.write_text(s)
diff=R/'diffs/tools/test262_conformance.py.patch';diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(''.join(difflib.unified_diff((R/'before/tools/test262_conformance.py').read_text().splitlines(True),s.splitlines(True),fromfile='before/tools/test262_conformance.py',tofile='raw/tools/test262_conformance.py')))
print(len(s.encode()),len(diff.read_bytes()))
