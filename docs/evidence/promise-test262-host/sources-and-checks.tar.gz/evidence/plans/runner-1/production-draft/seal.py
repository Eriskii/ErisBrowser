from pathlib import Path
import json,hashlib,ast,difflib
R=Path('/tmp/eris-promise-test262-plan-1/runner-1');P=R.parent

def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
h=json.loads((R/'tests-before/source-ready-2.json').read_text())
for row in h['files']:
 p=Path(row['raw']['path']);assert bind(p)==row['raw'];out=R/'raw'/row['target'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
before=R/'before/tools/test262_conformance.py';after=R/'raw/tools/test262_conformance.py'
oldtree=ast.parse(before.read_text());newtree=ast.parse(after.read_text())
old={n.name:n for n in oldtree.body if isinstance(n,ast.FunctionDef)};new={n.name:n for n in newtree.body if isinstance(n,ast.FunctionDef)}
changed=[k for k in old if ast.dump(old[k])!=ast.dump(new[k])]
assert changed==['load_corpus','case_fingerprint','unsupported_reason','encode_request','decode_response','classify','harness_preflight','main']
controls=json.loads((R/'raw/tools/promise-methods-runner-oracle.json').read_text())['controls']
assert ast.literal_eval(new['promise_preflight_variants'].body[-1].value)==controls
notes={
 'status':'external_production_source_ready_unexecuted',
 'selected_tests':bind(R/'tests-before/source-ready-2.json'),
 'selected_transport':bind(P/'concrete-1/tests-before/transport-source-ready-2.json'),
 'selected_protocol':bind(P/'concrete-1/protocol-2.json'),
 'selected_api':bind(P/'concrete-1/api.txt'),
 'parent_source':bind(before),
 'scope':'Only tools/test262_conformance.py plus two exactly held new test/oracle files. No importer, Rust, existing test modules or live-worktree edits.',
 'new_route':['Importer already authenticates the complete new corpus; runner extends its existing authenticated auxiliary-blob check and exact file-set check to the new profile, then retains all232files/458modes. Six helper bytes/order remain source-authenticated, never rewritten.',
 'Only loaded new-profile cases receive completion_policy; only that new field participates in new case fingerprints and selects ERJS2. Existing ERJS1/ERJR2 branches remain present. Explicit bool/invalid/mismatched policy, new raw/module/parse-only requests refuse.',
 'ERJR3 has six bounded UTF-8 strings and one exact12-byte/eight-field evidence tail. It validates all domains and selected consistency invariants, including actual parse/runtime error identity and no successful message/sentinel shortcut. Response/request policy and protocol must match before a pass.',
 'Separate host-failure observations retain phase host and their reason; final unhandled-rejection is host policy, not an upstream assertion failure. Resource/unsupported/harness errors retain their categories.',
 '37guard sources run in each of sloppy/strict:31originalJSexact plus6new prerequisites. Same-mode positive/poisoned prerequisite evidence and the healthy queued control gate original negative verification. Generic failures, absent evidence or wrong host reasons do not verify.',
 'New-profile report health requires exactly74unique expected name/mode identities, each verified=True. Any missing/extra/duplicate/altered/unverified row blocks all458upstream identities, retains preflight evidence, runs no upstream case, refuses baseline recording and exits nonzero.',
 'Only the new profile serializes format3 with explicit request/response/feature/completion/unhandled policy. Binary SHA is independently retained/rechecked by unchanged existing report flow. No adapter feature assertion is substituted for actual guarded execution.'],
 'legacy_preservation':{'changed_existing_functions':changed,'all_other_existing_functions_ast_exact':True,'full_legacy_preflight_body_ast_exact_after_new_early_dispatch':True,'legacy_decode_and_classify_ast_exact_after_new_early_dispatch':True,'old53policy_values_and_hashes':'Held independent source-derived oracle; no historical hash recomputation or expectation edits. Root separately owns exact old-profile enumeration exclusions.','modes_harness_names_run_case_check_baseline':'Entire functions AST-exact.'},
 'limits':'Existing corpus/file/proof, request4MiB, response field16384, process stdout96KiB/stderr64KiB, jobs1..16, timeout(0,60] and process restrictions unchanged. No retry, polling or execution budget introduced.',
 'observations':'No candidate execution or pass outcome claimed. Root has retained parent runner/transport baselines separately. All scripts used here are inert own AST/hash/source construction helpers, not project imports.',
 'integration':['Import the three exact held paths. Importer/corpus and root-owned historical enumeration adapters are separate prerequisites.','Run selected12transport and9runner controls with network/process mocking, then real root-owned feature adapter guards/upstream. Actual outcomes must be retained; no pass population is frozen.']}
n=R/'notes.json';n.write_text(json.dumps(notes,indent=2)+'\n')
files=[{'relative':'tools/test262_conformance.py','before':bind(before),'raw':bind(after),'diff':bind(R/'diffs/tools/test262_conformance.py.patch')}]
for row in h['files']:files.append({'relative':row['target'],'raw':bind(R/'raw'/row['target'])})
hold={'status':'source_ready_external_unexecuted','files':files,'notes':bind(n),'tests_before':bind(R/'tests-before/source-ready-2.json'),'guard_sources':37,'guard_observations':74,'group_count':9,'execution':False}
p=R/'source-ready.json';p.write_text(json.dumps(hold,indent=2)+'\n');print(json.dumps(bind(p)))
