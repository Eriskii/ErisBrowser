from pathlib import Path
import ast,json,hashlib,collections
P=Path('/tmp/eris-promise-test262-plan-1');R=P/'runner-1';base=Path('/tmp/eris-promise-finally-1/worktree')
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
guards=json.loads((P/'guarded-cases.json').read_text())
controls=[]
api="assert.sameValue(typeof Promise,'function');assert.sameValue(typeof Promise.resolve,'function');assert.sameValue(typeof Promise.reject,'function');assert.sameValue(typeof Promise.prototype.then,'function');assert.sameValue(typeof Promise.prototype.catch,'function');assert.sameValue(typeof Promise.prototype.finally,'function');var p=Promise.resolve(7);"
for name,good,bad,includes in [
 ('promise-api',api+'assert.sameValue(Promise.resolve(p),p);',api+'assert.notSameValue(Promise.resolve(p),p);',[]),
 ('promise-helper',"assert.sameValue(typeof checkSequence,'function');assert.sameValue(checkSequence([1,2,3]),true);","assert.sameValue(typeof checkSequence,'function');assert.sameValue(checkSequence([1,3,2]),true);",['promiseHelper.js']),
 ('property-helper',"assert.sameValue(typeof verifyProperty,'function');verifyProperty(Promise.prototype,'then',{value:Promise.prototype.then,writable:true,enumerable:false,configurable:true});","assert.sameValue(typeof verifyProperty,'function');verifyProperty(Promise.prototype,'then',{value:Promise.prototype.then,writable:true,enumerable:true,configurable:true});",['propertyHelper.js'])]:
 for suffix,src,expected in [('positive',good,'passed'),('poisoned',bad,'synchronous-exception')]:
  controls.append(dict(name=name+'-'+suffix,source=src,expected=expected,completion_policy=0,includes=includes,origin='new-prerequisite',prerequisite=name+'-positive' if suffix=='poisoned' else None))
for g in guards['cases']:
 if g['kind']=='literal-js':controls.append(dict(name=g['id'],source=g['source'],expected=g['expected'],completion_policy=int(g['policy']=='authenticated-async'),includes=[],origin='original-literal',prerequisite=None))
assert len(controls)==37
# Static expression evaluation of pre-existing feature-set declarations only.
a=ast.parse((base/'tools/test262_conformance.py').read_text());env={}
def value(n):
 if isinstance(n,ast.Constant):return n.value
 if isinstance(n,ast.Name):return env[n.id]
 if isinstance(n,(ast.Set,ast.List,ast.Tuple)):
  v=[value(x) for x in n.elts];return set(v) if isinstance(n,ast.Set) else v
 if isinstance(n,ast.Dict):return {value(k):value(v) for k,v in zip(n.keys,n.values)}
 if isinstance(n,ast.BinOp) and isinstance(n.op,ast.BitOr):return value(n.left)|value(n.right)
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='copy':return value(n.func.value).copy()
 raise ValueError(ast.dump(n))
for n in a.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  key=n.targets[0].id
  if key.endswith('_FEATURES') or key=='INTRINSIC_ERRORS':env[key]=value(n.value)
policies={}
for name,features in env['PROFILE_FEATURES'].items():
 d=dict(format=2,supported_features=sorted(features),negative_intrinsic_errors=sorted(env['INTRINSIC_ERRORS']),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if name in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:d['excluded_harness']=['resizableArrayBufferUtils.js']
 policies[name]={'policy':d,'sha256':sha(json.dumps(d,sort_keys=True).encode())}
assert len(policies)==53
features=sorted({'Promise','Promise.prototype.finally','Symbol.species','Reflect.construct','arrow-function','Reflect','Symbol.toStringTag','Symbol'})
new=dict(format=3,supported_features=features,negative_intrinsic_errors=sorted(env['INTRINSIC_ERRORS']),strict=True,modules=False,async_completion=True,host_hooks=True,timeout_seconds=3.0,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
im=json.loads((P/'importer-1/raw/tools/promise-methods-importer-oracle.json').read_text())
rows=[x for x in im['expected_manifest']['files'] if not x['path'].startswith('test/')]
blob={x['path']:x for x in rows}
O={'schema':1,'profile':'promise-methods-async','modes':['sloppy','strict'],'observations':74,
 'guards_source':bind(P/'guarded-cases.json'),'original_guard_records':guards['cases'],
 'ownership':{g['id']:('runner-preflight' if g['kind']=='literal-js' else 'Script private Runtime' if g['kind']=='private-rust-fixture-plan' else 'HTML adapter' if g['kind'] in ['transport-harness-fixture-plan','adapter-fixture-plan'] else 'transport hold2') for g in guards['cases']},
 'controls':controls,'features':features,'new_policy':new,'new_policy_sha256':sha(json.dumps(new,sort_keys=True).encode()),
 'old_policies':policies,'old_policy_map_sha256':sha(json.dumps(policies,sort_keys=True,separators=(',',':')).encode()),
 'corpus_counts':im['counts'],'auxiliary_files':blob,'importer_oracle':bind(P/'importer-1/raw/tools/promise-methods-importer-oracle.json'),
 'scope':'Frozen expectation literals only; no adapter or JS run.31 original JS strings exact; six new prerequisite sources and74 selected observations are distinct from original37 plan records. Resource/host failures are intended preflight outcomes, not upstream passes.'}
p=R/'tests-before/raw/tools/promise-methods-runner-oracle.json';p.write_text(json.dumps(O,indent=2)+'\n')
print(bind(p));print('controls',len(controls),'oldpolicysha',O['old_policy_map_sha256'],'newpolicysha',O['new_policy_sha256'])
