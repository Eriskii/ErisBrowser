from pathlib import Path
import ast,copy,json,hashlib,difflib
p=Path('/tmp/eris-promise-test262-plan-1/importer-1')
def bind(path):
 path=Path(path);b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():
   b=bind(v['path']);assert all(b[k]==v[k] for k in b),v['path']
  for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
h=json.loads((p/'source-ready.json').read_text());verify(h)
frozen=json.loads((p/'tests-before/source-ready.json').read_text());verify(frozen)
contract=json.loads((p/'tests-before/contract.json').read_text())
old=(p/'before/tools/import_test262.py').read_text();new=(p/'raw/tools/import_test262.py').read_text()
assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/tools/import_test262.py',tofile='b/tools/import_test262.py'))==(p/'diffs/tools/import_test262.py.patch').read_text()
a=ast.parse(old);b=ast.parse(new)
oldf={n.name:n for n in a.body if isinstance(n,ast.FunctionDef)};newf={n.name:n for n in b.body if isinstance(n,ast.FunctionDef)}
assert oldf.keys()==newf.keys()
changed=[n for n in oldf if ast.dump(oldf[n])!=ast.dump(newf[n])]
assert set(changed)=={'git_tree_inventory','profile_tree_inventory','import_corpus'}
def same(x,y):assert ast.dump(x)==ast.dump(y)
generic=copy.deepcopy(newf['git_tree_inventory'])
assert len(generic.args.kwonlyargs)==1 and generic.args.kwonlyargs[0].arg=='auxiliary_helpers'
assert isinstance(generic.args.kw_defaults[0],ast.Constant) and generic.args.kw_defaults[0].value is None
generic.args.kwonlyargs=[];generic.args.kw_defaults=[]
assert isinstance(generic.body[-2],ast.If) and ast.unparse(generic.body[-2].test)=='auxiliary_helpers is not None'
del generic.body[-2];same(oldf['git_tree_inventory'],generic)
profile=copy.deepcopy(newf['profile_tree_inventory']);assert ast.unparse(profile.body[0].test)=="profile == 'promise-methods-async'";del profile.body[0];same(oldf['profile_tree_inventory'],profile)
class DropPromise(ast.NodeTransformer):
 def visit_If(self,node):
  if ast.unparse(node.test)=="profile == 'promise-methods-async' and harness != PROMISE_METHOD_HELPERS":return None
  return self.generic_visit(node)
 def visit_Set(self,node):
  node.elts=[x for x in node.elts if not(isinstance(x,ast.Constant) and x.value=='promise-methods-async')];return self.generic_visit(node)
 def visit_Dict(self,node):
  keep=[i for i,x in enumerate(node.keys) if not(isinstance(x,ast.Constant) and x.value=='promise-methods-async')]
  node.keys=[node.keys[i] for i in keep];node.values=[node.values[i] for i in keep];return self.generic_visit(node)
same(oldf['import_corpus'],DropPromise().visit(copy.deepcopy(newf['import_corpus'])))
def tables(tree):
 assigned={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
 def value(n):
  if isinstance(n,ast.Name):return value(assigned[n.id])
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Dict):return {value(k):value(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.Set):return {value(x) for x in n.elts}
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.Mult):return value(n.left)*value(n.right)
  raise AssertionError(ast.dump(n))
 return {n:value(assigned[n]) for n in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES','MAX_FILE','MAX_TOTAL']}
oldtables=tables(a);newtables=tables(b)
newtables['PROFILES'].pop('promise-methods-async');newtables['PROFILE_ROOTS'].pop('promise-methods-async');newtables['TREE_PROFILES'].remove('promise-methods-async')
assert oldtables==newtables and len(oldtables['PROFILES'])==53
fingerprint={'profiles':oldtables['PROFILES'],'roots':oldtables['PROFILE_ROOTS'],'tree_profiles':sorted(oldtables['TREE_PROFILES'])}
assert hashlib.sha256(json.dumps(fingerprint,sort_keys=True,separators=(',',':')).encode()).hexdigest()=='e51b4b6882c1163b10fa3eb84321fac4b923acadc8a29a41b648c0d399a502e6'
tests=ast.parse((p/'raw/tools/test_import_test262_promise.py').read_text());names=[n.name for n in ast.walk(tests) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(names)==6
oracle=json.loads((p/'raw/tools/promise-methods-importer-oracle.json').read_text())['expected_manifest']
assert oracle['test_files']==232 and len(oracle['files'])==240 and len(oracle['inventory_proof']['files'])==13
assert sum(x['bytes'] for x in oracle['inventory_proof']['files'])==86344
assert {n:len(v) for n,v in oracle['directories'].items()}==contract['selection']['directories']
assert oracle['inventory_proof']['auxiliary_blobs']==contract['selection']['auxiliary_blobs']
assert sum(contract['selection']['directories'].values())==232
out={'status':'clear','scope':'Bounded independent source/contract/default-path peer. Python AST parsing and literal evaluation/hash/diff checks only; no importer/project imports, tests, corpus execution/download or live-source edits. Root already authenticated selected complete trees and blobs; that inventory is not re-observed here.','hold':bind(p/'source-ready.json'),'frozen_tests':bind(p/'tests-before/source-ready.json'),'production':bind(p/'raw/tools/import_test262.py'),'groups':names,'default_preservation':{'changed_existing_functions':changed,'all_other_functions_ast_exact':True,'generic_reader_without_keyword_option_and_new_guard_ast_exact':True,'profile_dispatch_without_new_first_branch_ast_exact':True,'import_corpus_without_only_new_profile_guard_and_set_dict_entries_ast_exact':True,'old_profile_tables':53,'old_table_fingerprint':'e51b4b6882c1163b10fa3eb84321fac4b923acadc8a29a41b648c0d399a502e6','limits_unchanged':True},'contract':['The new profile contains exactly eight complete immediate directories totaling232 original JS files, plus six harness helpers and two legal files. Class/cross-realm and async inputs remain in the corpus; importer performs no outcome-based selection or execution.','Optional auxiliary authentication is absent for every existing caller. The selected Promise branch adds one root-linked harness tree; original tree hash reconstruction, regular-file checks, safe routes,32-document/8MiB proof and2MiB-file/16MiB aggregate limits stay unchanged.','All selected body Git blob hashes are checked before parsing helpers. Exact helper-set equality precedes fetching auxiliary bodies; helper/legal Git blobs are checked against authenticated root/harness entries before any output directory/file publication.','Six tests cover exact manifest/bytes, metadata population, every proof tamper, complete-directory mutations, offline replay, raw and all eight auxiliary mutations with empty-output refusal, and old53 table/legacy proof preservation. Network fetch is explicitly mocked; new test group source and complete manifest oracle are exactly the tests-before bytes.','Manifest semantic equality covers232 tests/240 source-helper-legal entries/13 original proof documents and86344 proof bytes. These are retained-corpus assertions, not newly observed test outcomes.','Importer registration changes the shared profile map; runner old-profile isolation remains the explicit separate Script-owned integration seam. This source does not change ERJS1 or authorize asynchronous Test262 execution.'],'findings':[]}
(p/'layout-source-review.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(bind(p/'layout-source-review.json')))
