from pathlib import Path
import ast
import difflib
import hashlib
import json

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
P = A / 'legacy-profile-adapters-1'
assert not P.exists()
prefix = 'tools/test_test262_'
set_files = ['typedarray_to_reversed', 'typedarray_reverse', 'typedarray_fill',
             'typedarray_search', 'typedarray_views', 'reflect_properties',
             'typedarray_foundation', 'object_has_own']
replacements = {prefix + name + '.py': (
    'len(set(runner.PROFILES) - {',
    "len(set(runner.PROFILES) - {'promise-methods-async', ") for name in set_files}
replacements[prefix + 'typedarray_copy_within.py'] = (
    'len(runner.PROFILES)', "len(set(runner.PROFILES) - {'promise-methods-async'})")
for name in ['conformance', 'array_predicates']:
    replacements[prefix + name + '.py'] = (
        "if name in {'typedarray-copy-within', ",
        "if name in {'promise-methods-async', 'typedarray-copy-within', ")
replacements[prefix + 'object_integrity.py'] = (
    'sorted(set(runner.PROFILES) - set(excluded))',
    "sorted(set(runner.PROFILES) - set(excluded) - {'promise-methods-async'})")
assert len(replacements) == 12
rows = []
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
for name, (old, new) in replacements.items():
    before = (W / name).read_text()
    assert before.count(old) == 1, name
    assert new not in before
    after = before.replace(old, new)
    assert after.replace(new, old) == before
    # Every preexisting literal, including all counts and hashes, is retained.
    literals = lambda text: [n.value for n in ast.walk(ast.parse(text)) if isinstance(n, ast.Constant)]
    values = literals(after)
    assert values.count('promise-methods-async') == 1
    values.remove('promise-methods-async')
    # AST traversal order can shift with inserted set/subtraction nodes; compare
    # a typed multiset instead of conflating boolean/int or reordering fixtures.
    typed = lambda vals: sorted((type(x).__name__, repr(x)) for x in vals)
    assert typed(values) == typed(literals(before)), name
    paths = [P / 'before' / name, P / 'raw' / name, P / 'diffs' / (name + '.patch')]
    contents = [before, after, ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/' + name, tofile='b/' + name))]
    for path, content in zip(paths, contents):
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open('x') as out: out.write(content)
    rows.append({'target': name, 'before': bind(paths[0]), 'raw': bind(paths[1]), 'diff': bind(paths[2]),
                 'exact_reversal': {'old': old, 'new': new}})
result = {'status': 'source_only_explicit_historical_profile_adapters', 'files': rows,
          'scope': 'Only new promise-methods-async is excluded from historical profile witnesses. All original source is recovered by the one recorded reversal per file; existing literal counts/hashes, unknown-profile validation, execution and corpus bytes remain unchanged.',
          'execution': 'Inert AST/text/hash checks only. No live edits or project execution.'}
with (P / 'source-ready.json').open('x') as out:
    json.dump(result, out, indent=2); out.write('\n')
print(json.dumps({'files': len(rows), 'hold': bind(P / 'source-ready.json')}))
