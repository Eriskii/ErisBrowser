"""Root-owned sequential checks: never run worker suites concurrently."""
from pathlib import Path
import subprocess

A = Path(__file__).resolve().parents[1]
checks = [
    ['host-full-msrv-1', '1.88.0', 'Cargo.toml', 'test262-host', 'test', '--', '--include-ignored'],
    ['host-native-full-stable-1', '1.99.0', 'Cargo.toml', 'vulkan-raster,test262-host', 'test', '--', '--include-ignored'],
    ['host-clippy-msrv-2', '1.88.0', 'Cargo.toml', 'test262-host', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['default-clippy-msrv-1', '1.88.0', 'Cargo.toml', '-', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['default-clippy-stable-1', '1.99.0', 'Cargo.toml', '-', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['host-runtime-list-1', '1.88.0', 'Cargo.toml', 'test262-host', 'test', '--lib', 'script::test262_host::', '--', '--list'],
    ['host-adapter-list-1', '1.88.0', 'Cargo.toml', 'test262-host', 'test', '--bin', 'eris-js', 'test262_', '--', '--list'],
]
for version, enabled, label in [
    ('1.88.0', False, 'inactive-layout-stack-msrv-1'),
    ('1.88.0', True, 'active-layout-stack-msrv-1'),
    ('1.99.0', True, 'active-layout-stack-stable-1'),
]:
    checks.append([label, version, 'Cargo.toml', 'test262-host' if enabled else '-', 'test', '--lib', '--',
                   'small_native_stack', 'finally_actual_capture_layout',
                   'host_actual_inline_layout', 'bootstrap_reports_types_and_reconciles_installation_ledger',
                   '--include-ignored', '--nocapture', '--test-threads=1'])
for row in checks:
    print('START ' + row[0], flush=True)
    subprocess.run(['python3', str(A / 'run-check.py'), *row], check=True, close_fds=True)
print('ALL SELECTED CHECKS COMPLETE', flush=True)
