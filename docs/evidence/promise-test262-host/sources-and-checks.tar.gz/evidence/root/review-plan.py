from pathlib import Path
import hashlib,json,re
A=Path('/tmp/eris-promise-test262-plan-1')
OUT=Path(__file__).resolve().parent

def unique(pairs):
 d={}
 for k,v in pairs:
  assert k not in d,k
  d[k]=v
 return d

def read(p):return json.loads(p.read_text(),object_pairs_hook=unique)
def sha(data):return hashlib.sha256(data).hexdigest()
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
hold=read(A/'source-ready.json')
for row in hold['files']:
 p=Path(row['path']);assert p.is_relative_to(A) and not p.is_symlink()
 assert binding(p)==row,p
proofs={}
for p in sorted((A/'proof').glob('tree-*.json')):
 t=read(p);assert t['truncated'] is False
 entries=t['tree'];names=set();payload=b''
 assert entries==sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
 for e in entries:
  n=e['path'];assert n not in names and n not in ['.','..'] and not any(c in n for c in '/\\\0');names.add(n)
  assert (e['type'],e['mode']) in [('tree','040000'),('blob','100644'),('blob','100755')]
  mode='40000' if e['type']=='tree' else e['mode']
  payload+=mode.encode()+b' '+n.encode()+b'\0'+bytes.fromhex(e['sha'])
 assert hashlib.sha1(b'tree '+str(len(payload)).encode()+b'\0'+payload).hexdigest()==t['sha']
 assert t['sha'] not in proofs;proofs[t['sha']]=t
assert len(proofs)==20
root='91b2052adad1f066ae031e2ff3a1e9bd6d732886'
commit=read(A/'proof/commit.json');assert commit['sha']=='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd' and commit['tree']['sha']==root

def entry(path):
 tree=root
 for i,part in enumerate(path.split('/')):
  e=next(x for x in proofs[tree]['tree'] if x['path']==part)
  if i+1<len(path.split('/')):assert e['type']=='tree';tree=e['sha']
 return e
promise=entry('test/built-ins/Promise');assert promise['sha']=='176043820c3a0729f2da2a047303a984cca036c6'
actual=[];dirs={}
def walk(prefix,tree):
 t=proofs[tree];dirs[prefix]=tree
 for e in t['tree']:
  name=prefix+'/'+e['path']
  if e['type']=='tree':walk(name,e['sha'])
  else:
   assert e['mode']=='100644' and name.endswith('.js')
   actual.append((name,e['sha'],e['size']))
walk('test/built-ins/Promise',promise['sha'])
inv=read(A/'inventory.json');assert sorted(actual)==sorted((x['path'],x['blob'],x['bytes']) for x in inv['files'])
assert len(actual)==732 and len(dirs)==16 and sum(x[2] for x in actual)==822354
for path,tree in dirs.items():assert inv['directories'][path.removeprefix('test/built-ins/')]['tree']==tree
meta=read(A/'selected-metadata.json');sel=set(meta['selected_directories'])
expected={p for p,_,_ in actual if p.rsplit('/',1)[0].removeprefix('test/built-ins/') in sel}
assert expected=={r['path'] for r in meta['sources']} and len(expected)==232
modes=async_modes=async_files=0
for row in meta['sources']+meta['auxiliary']:
 p=A/'primary-cache'/row['path'];b=p.read_bytes();e=entry(row['path'])
 assert e['type']=='blob' and e['sha']==row['blob']
 assert len(b)==e['size']==row['bytes'] and sha(b)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['blob']
 if row in meta['sources']:
  text=b.decode();front=text.split('/*---',1)[1].split('---*/',1)[0]
  flag=re.search(r'(?m)^flags:[ \t]*\[([^\]]*)\]',front)
  assert flag is not None or not re.search(r'(?m)^flags:',front)
  flags=[] if flag is None else [x.strip(' \t\n\r\'\"') for x in flag[1].split(',') if x.strip()]
  assert flags==row['metadata']['flags']
  n=1 if ('onlyStrict' in flags or 'noStrict' in flags) else 2
  modes+=n
  if 'async' in flags:async_files+=1;async_modes+=n
assert (modes,async_files,async_modes)==(458,113,222)
assert len(meta['auxiliary'])==8
report={'status':'clear_source_plan_only','hold':binding(A/'source-ready.json'),'bindings_verified':len(hold['files']),
 'git_tree_objects_reconstructed':len(proofs),'commit_root_join':'Pinned existing importer revision/root joined to cached GitHub commit response; unsigned commit response is not a signature.',
 'complete_promise_roster':{'files':732,'directories':16,'source_bytes':822354},
 'selected_profile':{'files':232,'modes':458,'async_files':113,'async_modes':222,'sync_modes':236,'auxiliary_blobs':8},
 'contract_review':['Pinned INTERPRETING permits harness overrides and requires async print completion; initial profile explicitly restricts to authenticated $DONE, with print-only cases unsupported.',
 'Pinned doneprintHandle tests truthiness; preserving falsy success and original helper delegation is necessary.',
 'Require exactly one authenticated observer and success print; later errors, duplicate, fatal state and incomplete checkpoint veto provisional success.',
 'Unhandled rejections are a separate adapter policy category. Rejected then handled in the same drain must not stay poisoned. This is not full web rejection notification support.',
 'New request/response are opt-in; existing ERJS1/ERJR2 and prior profile fingerprints remain unchanged.',
 'Feature-disabled Runtime must retain its layout and startup behavior. Selected inline optional session uses the feature-enabled existing max(2048,size_of Runtime) storage allowance once.',
 'Exact fees, private identity routes, framing widths and tests remain pending in concrete hold; no production cleared by this source-plan receipt.'],
 'normative_reference':{'url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-host-promise-rejection-tracker','section':'27.5.1.9','observation':'Host policy can track reject/handle; current private handled state is relevant, historical rejection alone is not proof of final unhandled state.'},
 'execution':'Independent inert file/hash/tree reconstruction only, no project import/compiler/runtime/case execution.', 'findings':[]}
with (OUT/'plan-review-1.json').open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({'status':report['status'],'binding':binding(OUT/'plan-review-1.json')}))
