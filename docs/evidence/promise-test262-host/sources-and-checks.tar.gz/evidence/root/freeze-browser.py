from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess

root = Path(__file__).resolve().parent.parent
inventory = root / "source-2.json"
sources = json.loads(inventory.read_text())["source_sha256"]
for name, sha in sources.items():
    assert hashlib.sha256((root / "worktree" / name).read_bytes()).hexdigest() == sha, name
build = json.loads((root / "validation/browser-final-build-1.json").read_text())
assert build["exit"] == 0
assert hashlib.sha256((root / "validation" / build["log"]).read_bytes()).hexdigest() == build["sha256"]
source = root / "target-1990/debug/eris-browser"
target = root / "eris-browser-final-1"
assert not target.exists()
before = hashlib.sha256(source.read_bytes()).hexdigest()
shutil.copyfile(source, target)
subprocess.run(["strip", "--strip-debug", str(target)], check=True, close_fds=True)
os.chmod(target, 0o555)
record = {"path": str(target), "bytes": target.stat().st_size,
          "sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
          "unstripped_sha256": before, "rust": "1.99.0", "profile": "dev",
          "features": ["vulkan-raster"], "strip_mode": "--strip-debug", "dwarf_debug_sections_removed": True,
          "debugger_autoload_metadata_retained": True,
          "source_inventory": inventory.name,
          "source_inventory_sha256": hashlib.sha256(inventory.read_bytes()).hexdigest(),
          "verified_source_inputs": len(sources), "build": build}
with (root / "root/final-browser.json").open("x") as output:
    json.dump(record, output, indent=2)
    output.write("\n")
print(json.dumps(record))
