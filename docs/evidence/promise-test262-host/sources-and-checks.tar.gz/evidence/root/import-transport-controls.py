from pathlib import Path
import hashlib
import json
import subprocess

A = Path(__file__).resolve().parents[1]
P = Path('/tmp/eris-promise-test262-plan-1/concrete-1/tests-before')
W = A / 'worktree'
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def verify(row):
    assert bind(Path(row['path'])) == row
hold = P / 'transport-source-ready-2.json'
peer = P / 'transport-layout-review-2.json'
assert bind(hold)['sha256'] == '7a6ba76b01783910c8cdf86701653633d9427b6d0c9ece27dee6d34673841bb0'
assert bind(peer)['sha256'] == '15ce4a184c7d5d8d8ebc7af2c7deebba96bff2119bd472eafb7fc30df332ffed'
data = json.loads(hold.read_text())
for key in ['correction', 'original_hold', 'notes']:
    verify(data[key])
for row in data['proposed_contract']:
    verify(row)
for row in data['files']:
    verify(row['raw'])
    assert not (W / row['target']).exists()
runner = W / 'tools/test262_conformance.py'
assert runner.read_bytes() == subprocess.check_output(['git', '-C', str(W), 'show', 'HEAD:tools/test262_conformance.py'])
for row in data['files']:
    (W / row['target']).write_bytes(Path(row['raw']['path']).read_bytes())
result = {'status': 'imported_parent_compatible_controls_only', 'hold': bind(hold), 'peer': bind(peer),
          'runner': bind(runner), 'base': subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip(),
          'files': [bind(W / r['target']) for r in data['files']],
          'scope': 'Runner and Rust remain unchanged parent; separately reviewed importer registration and corpus are already installed.'}
with (A / 'root/transport-test-import-1.json').open('x') as out:
    json.dump(result, out, indent=2); out.write('\n')
print(json.dumps(result))
