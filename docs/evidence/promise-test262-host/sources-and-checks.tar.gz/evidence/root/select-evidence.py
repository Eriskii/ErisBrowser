from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
def read(p): return json.loads(p.read_text())

inventory = A / 'source-2.json'
sources = read(inventory)['source_sha256']
assert len(sources) == 1091
for name, sha in sources.items():
    assert bind(W / name)['sha256'] == sha, name
validation = read(A / 'root/final-validation.json')
assert validation['status'] == 'pass'
peer = A / 'root/final-validation-review.json'
assert peer.exists()
assert 'clear' in read(peer)['status']

# The original source cache is already archived in the selected corpus. Keep
# explicit aliases instead of embedding a second copy of those 240 payloads.
aliases = []
for p in sorted((A / 'plans/primary-cache').rglob('*')):
    if not p.is_file():
        continue
    relative = str(p.relative_to(A / 'plans/primary-cache'))
    target = 'tests/upstream/test262-promise-methods-async/' + relative
    assert p.read_bytes() == (W / target).read_bytes()
    assert target in sources
    aliases.append({'held_path': '/tmp/eris-promise-test262-plan-1/primary-cache/' + relative,
                    'archive_member': 'sources/' + target,
                    'bytes': p.stat().st_size, 'sha256': sources[target]})
assert len(aliases) == 240
with (A / 'root/artifact-aliases.json').open('x') as out:
    json.dump({'primary_cache': aliases}, out, indent=2); out.write('\n')

artifacts = {}
directories = ['plans', 'runtime-production-1', 'legacy-profile-adapters-1',
               'legacy-profile-adapters-2', 'correction-1', 'documentation-1',
               'root', 'validation', 'reftests-final']
for directory in directories:
    for p in sorted((A / directory).rglob('*')):
        assert not p.is_symlink(), p
        if not p.is_file():
            continue
        name = str(p.relative_to(A))
        if name.startswith('plans/primary-cache/'):
            continue
        if p.name in ['selection-final.json', 'publication-verification.json']:
            continue
        assert '__pycache__' not in p.parts
        artifacts[name] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json']:
        artifacts[p.name] = bind(p)
for name in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
             'docs/promise-finally.md', 'docs/promise-test262-host.md']:
    assert 'PENDING_' not in (W / name).read_text()
    artifacts['documentation/' + name] = bind(W / name)

claims = {
    'base': read(inventory)['base'],
    'scope': 'Optional authenticated Test262 completion host, pinned Promise-method corpus and regression gate; ordinary browser builds keep the feature disabled.',
    'source_inputs': len(sources),
    'tests': {'new_rust_groups': 28, 'runtime': 17, 'adapter': 11,
              'new_python_groups': 27, 'python_full': 532},
    'validation': validation,
    'validation_peer': bind(peer),
    'parent_observations': {
        'transport': read(A / 'root/transport-baseline-result.json'),
        'runner': read(A / 'root/runner-baseline-result.json'),
        'private_rust_tests': 'New APIs do not compile on the parent; no parent Runtime or adapter execution result is claimed.'},
    'history': {
        'source_transition': read(A / 'root/source-transition-1.json'),
        'adapter_phase': 'Retained original review finding and corrected new-protocol dynamic Function runtime phase; legacy path unchanged.',
        'lint_correction': 'One equivalent test-only int_plus_one comparison corrected after strict1.99 refusal; original failure retained.',
        'historical_python_witnesses': 'Thirteen explicit new-profile exclusions preserve old profile counts/features/hashes. The first full532-test run failed one historical constructor witness; the corrected full rerun passed.',
        'corpus_run': 'Both final and initial frozen adapters have identical bytes. The final source2 build and second report preserve all74 controls/all458 observations, including8 failures.',
        'full_promise_inventory': 'The plan retains the complete732-file Promise tree inventory; only eight immediate directories/232files are selected. Other500files are not claimed as executed.'},
    'policies': {
        'default_feature': False, 'legacy_protocol': 'ERJS1/ERJR2', 'new_protocol': 'ERJS2/ERJR3',
        'async_completion': 'Exactly one authenticated DONE with one helper success print and no failure evidence.',
        'final_rejection_policy': 'Final quiescent unhandled veto, distinct from upstream assertions and browser rejection events.',
        'no_fresh_final_audit_budget': True,
        'work_limit': 100000, 'heap_limit': 8388608,
        'warm_setup_work': 405, 'bind_work':49, 'arm_work':16, 'done_entry_work':24,
        'finalization_work': '24+3N, N retained Promise records; ordinary calls/jobs remain additionally charged.'},
    'limits': [
        '420passed/30unsupported/8failed is a selected458-mode result, not full Promise/ECMAScript/Test262 conformance.',
        'Six failed modes are the chosen host-policy unhandled veto; two are missing Proxy. No failed or unsupported mode was removed.',
        'Authenticated DONE is narrower than general Test262 print-only completion contracts.',
        'No async/await, combinators, cross-realm execution, timers, full browser event loop, rejection notifications or GC is added.',
        'Resource charges are logical policy accounting, not measured instructions, physical stack frames or resident allocator storage.',
        'Reference rendering uses CPU screenshots from a Vulkan-capable build; this checkpoint makes no new GPU execution or Chromium performance claim.',
        'Build caches are reused. No cold-build timing or complete security/compatibility certification.'
    ]
}
selection = {'source_inventory': bind(inventory), 'artifacts': artifacts,
             'claims': claims, 'max_uncompressed_bytes': 128 * 1024 * 1024}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2); out.write('\n')
print(json.dumps({'sources':len(sources),'artifacts':len(artifacts),
                  'artifact_bytes':sum(x['bytes'] for x in artifacts.values())}))
