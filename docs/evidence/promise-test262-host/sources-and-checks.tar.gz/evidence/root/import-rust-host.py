from pathlib import Path
import difflib
import hashlib
import json
import sys

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
hold = Path(sys.argv[1])
label = sys.argv[2]

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def verify(value):
    if isinstance(value, dict):
        if set(('path', 'bytes', 'sha256')) <= value.keys():
            assert bind(Path(value['path'])) == {k: value[k] for k in ('path', 'bytes', 'sha256')}, value
        for item in value.values():
            verify(item)
    elif isinstance(value, list):
        for item in value:
            verify(item)

data = json.loads(hold.read_text())
verify(data)
pending = []
for row in data['files']:
    target = W / row['target']
    assert target.is_relative_to(W) and '..' not in Path(row['target']).parts
    old = Path(row['before']['path']).read_bytes() if row['before'] else b''
    if row.get('new_file'):
        assert old == b'' and not target.exists(), row['target']
    elif row['before']:
        assert target.read_bytes() == old, row['target']
    else:
        assert not target.exists(), row['target']
    new = Path(row['raw']['path']).read_bytes()
    expected = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                         fromfile='a/' + row['target'], tofile='b/' + row['target']))
    actual = Path(row['diff']['path']).read_text()
    # New-file patches may spell the source /dev/null.
    assert actual == expected or actual == expected.replace('--- a/' + row['target'] + '\n', '--- /dev/null\n', 1), row['target']
    pending.append((target, new))
receipt = A / 'root' / (label + '.json')
assert not receipt.exists()
for target, new in pending:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(new)
result = {'hold': bind(hold), 'files': [bind(p) for p, _ in pending],
          'verification': 'All referenced bindings, before bytes, and complete unified diffs verified before import.'}
with receipt.open('x') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps(result))
