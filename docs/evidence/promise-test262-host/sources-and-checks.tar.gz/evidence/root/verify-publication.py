from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent.parent
published = root / "worktree/docs/evidence/promise-test262-host"
summary_path = published / "summary.json"
summary = json.loads(summary_path.read_text())
selection_path = root / "root/selection-final.json"
selection = json.loads(selection_path.read_text())
inventory = json.loads((root / "source-2.json").read_text())["source_sha256"]
assert summary["claims"] == selection["claims"]
assert summary["source_count"] == len(inventory)
assert summary["selection"]["sha256"] == hashlib.sha256(selection_path.read_bytes()).hexdigest()
archive = published / "sources-and-checks.tar.gz"
payload = archive.read_bytes()
assert len(payload) == summary["archive"]["bytes"]
assert hashlib.sha256(payload).hexdigest() == summary["archive"]["sha256"]
expected = {row["name"]: row for row in summary["members"]}
assert len(expected) == len(summary["members"]) == len(inventory) + len(selection["artifacts"])
seen = set()
with tarfile.open(archive, "r:gz") as stream:
    for member in stream:
        assert member.name not in seen and member.isfile()
        seen.add(member.name)
        row = expected[member.name]
        assert member.size == row["bytes"]
        data = stream.extractfile(member).read()
        assert hashlib.sha256(data).hexdigest() == row["sha256"]
        assert data == Path(row["path"]).read_bytes(), member.name
        if member.name.startswith("sources/"):
            assert inventory[member.name[len("sources/"):]] == row["sha256"]
assert seen == expected.keys()
result = {"status": "pass", "source_inputs": len(inventory), "members": len(seen),
          "archive_sha256": summary["archive"]["sha256"],
          "summary_sha256": hashlib.sha256(summary_path.read_bytes()).hexdigest(),
          "checks": "Every archived member matches its bound current file; inventory and root-authored claims match the selected final records."}
with (root / "root/publication-verification.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps(result))
