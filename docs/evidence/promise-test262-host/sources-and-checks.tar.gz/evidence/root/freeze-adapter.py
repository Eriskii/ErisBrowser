from pathlib import Path
import hashlib
import json
import os
import shutil
import sys

A = Path(__file__).resolve().parents[1]
version, label, inventory_name, build_label = sys.argv[1:]
inventory = A / inventory_name
sources = json.loads(inventory.read_text())['source_sha256']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for name, expected in sources.items():
    assert sha(A / 'worktree' / name) == expected, name
build = json.loads((A / 'validation' / (build_label + '.json')).read_text())
assert build['exit'] == 0
assert sha(A / 'validation' / build['log']) == build['sha256']
target_name = 'target-msrv' if version == '1.88.0' else 'target-' + version.replace('.', '')
source = A / target_name / 'release/eris-js'
target = A / label
assert not target.exists()
before = sha(source)
shutil.copyfile(source, target)
os.chmod(target, 0o555)
assert sha(target) == before
result = {'path': str(target), 'bytes': target.stat().st_size, 'sha256': sha(target),
          'rust': version, 'profile': 'release', 'features': ['test262-host'],
          'source_inventory': inventory_name, 'source_inventory_sha256': sha(inventory),
          'verified_source_inputs': len(sources), 'build': build}
with (A / 'root' / (label + '.json')).open('x') as out:
    json.dump(result, out, indent=2)
    out.write('\n')
print(json.dumps(result))
