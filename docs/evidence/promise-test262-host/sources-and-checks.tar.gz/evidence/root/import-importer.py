from pathlib import Path
import difflib
import hashlib
import json

A = Path(__file__).resolve().parents[1]
P = Path('/tmp/eris-promise-test262-plan-1/importer-1')
W = A / 'worktree'
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
def verify(row):
    assert bind(Path(row['path'])) == row

hold = P / 'source-ready.json'
assert bind(hold)['sha256'] == '8e1038db97978d1e21c866e4767a2b870233a285f91fb1a8a08db95ae2ec0451'
peer = P / 'layout-source-review.json'
assert bind(peer)['sha256'] == 'c61458aec3d84eb403221a8232f132acf28c922d8136a7bd7fcb6b3a57ddc759'
assert json.loads(peer.read_text())['status'] == 'clear'
data = json.loads(hold.read_text())
verify(data['tests_before']); verify(data['notes'])
for row in json.loads(Path(data['tests_before']['path']).read_text())['files']:
    verify(row)
for row in data['files']:
    verify(row['raw'])
    target = W / row['relative']
    assert target.is_relative_to(W)
    if 'before' in row:
        verify(row['before']); verify(row['diff'])
        assert target.read_bytes() == Path(row['before']['path']).read_bytes()
        patch = ''.join(difflib.unified_diff(target.read_text().splitlines(True),
            Path(row['raw']['path']).read_text().splitlines(True),
            fromfile='a/' + row['relative'], tofile='b/' + row['relative']))
        assert patch == Path(row['diff']['path']).read_text()
    else:
        assert not target.exists()
for row in data['files']:
    target = W / row['relative']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(Path(row['raw']['path']).read_bytes())
result = {'status': 'imported_after_independent_source_review', 'hold': bind(hold),
          'peer': bind(peer), 'files': [bind(W / r['relative']) for r in data['files']],
          'execution': 'Root imports only; no network or JS execution.'}
with (A / 'root/importer-import-1.json').open('x') as out:
    json.dump(result, out, indent=2); out.write('\n')
print(json.dumps(result))
