from pathlib import Path
import hashlib
import json
import sys
from unittest.mock import patch

A = Path(__file__).resolve().parents[1]
P = Path('/tmp/eris-promise-test262-plan-1')
W = A / 'worktree'
sys.path.insert(0, str(W / 'tools'))
import import_test262 as importer

oracle = json.loads((W / 'tools/promise-methods-importer-oracle.json').read_text())
expected = oracle['expected_manifest']
source_rows = {r['path']: r for r in expected['files']}
proof_rows = {r['url']: r for r in expected['inventory_proof']['files']}
requests = []
def cached(url):
    raw = f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
    if url in proof_rows:
        row = proof_rows[url]
        route = url.split('/git/', 1)[1]
        if route.startswith('commits/'):
            path = P / 'proof/commit.json'
        else:
            assert route.startswith('trees/')
            path = P / ('proof/tree-' + route[6:] + '.json')
    else:
        assert url.startswith(raw), url
        name = url[len(raw):]
        row = source_rows[name]
        path = P / 'primary-cache' / name
    data = path.read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    requests.append(url)
    return data
output = W / 'tests/upstream/test262-promise-methods-async'
assert not output.exists()
with patch.object(importer, 'fetch', side_effect=cached):
    importer.import_corpus(output, 'promise-methods-async')
assert json.loads((output / 'manifest.json').read_bytes()) == expected
for row in expected['files'] + expected['inventory_proof']['files']:
    data = (output / row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
result = {'status': 'pass', 'network': False, 'test_files': 232, 'auxiliary_files': 8,
          'proof_files': 13, 'proof_bytes': 86344, 'manifest_equals_held_oracle': True,
          'requests': sorted(requests), 'manifest_sha256': hashlib.sha256((output / 'manifest.json').read_bytes()).hexdigest()}
with (A / 'root/importer-replay-1.json').open('x') as out:
    json.dump(result, out, indent=2); out.write('\n')
print(json.dumps({k: v for k, v in result.items() if k != 'requests'}))
