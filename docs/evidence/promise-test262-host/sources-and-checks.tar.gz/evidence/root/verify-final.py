from pathlib import Path
import collections
import hashlib
import json

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def read(name): return json.loads((A / name).read_text())
def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
source = read('source-2.json')
assert len(source['source_sha256']) == 1091
for name, sha in source['source_sha256'].items():
    assert bind(W / name)['sha256'] == sha, name
checks = {}
for label in ['default-full-1', 'host-full-msrv-1', 'host-native-full-stable-1',
              'host-clippy-msrv-2', 'host-native-clippy-stable-2', 'default-clippy-msrv-1',
              'default-clippy-stable-1', 'format-check-1', 'python-full-2',
              'host-runtime-list-1', 'host-adapter-list-1', 'inactive-layout-stack-msrv-1',
              'inactive-layout-stack-stable-1', 'active-layout-stack-msrv-1', 'active-layout-stack-stable-1',
              'adapter-release-build-2', 'browser-final-build-1', 'promise-upstream-2',
              'legacy-upstream-enabled-1', 'references-final-1', 'importer-controls-1',
              'importer-replay-1', 'runner-focused-1']:
    r = read('validation/' + label + '.json')
    assert r['exit'] == 0, label
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256'], label
    checks[label] = r
totals = read('root/full-suite-totals.json')
for label, count in [('default-full-1', 2887), ('host-full-msrv-1', 2914), ('host-native-full-stable-1', 3241)]:
    assert totals[label]['passed'] == count
    assert totals[label]['failed'] == totals[label]['ignored'] == 0
    workers = [r for r in totals[label]['roster'] if r['target'] == 'tests/worker.rs']
    assert len(workers) == 89, (label, len(workers))
report = read('validation/promise-upstream-report-2.json')
prior = read('validation/promise-upstream-report-1.json')
assert report['cases'] == prior['cases']
assert report['harness_preflight'] == prior['harness_preflight']
assert report['harness_preflight_passed'] and len(report['harness_preflight']) == 74
assert all(r['verified'] for r in report['harness_preflight'])
assert len(report['cases']) == 458 and report['counts'] == {'passed': 420, 'unsupported': 30, 'failed': 8}
assert report['regressions'] == report['improvements'] == []
adapter = read('root/eris-js-host-final-1.json')
assert adapter['source_inventory'] == 'source-2.json'
assert adapter['sha256'] == bind(Path(adapter['path']))['sha256'] == report['binary_sha256']
assert adapter['sha256'] == read('root/eris-js-host-1.json')['sha256']
failure_reasons = collections.Counter(
    r['observation'].get('message') for r in report['cases'] if r['status'] == 'failed')
assert failure_reasons == {"'Proxy' is not defined": 2, 'unhandled-rejection': 6}
legacy = read('validation/legacy-upstream-enabled-report-1.json')
assert legacy['counts'] == {'passed': 568, 'unsupported': 84}
assert legacy['regressions'] == legacy['improvements'] == []
assert legacy['harness_preflight_passed'] and len(legacy['harness_preflight']) == 32
assert legacy['binary_sha256'] == adapter['sha256']
for compiler in ['msrv', 'stable']:
    inactive = (A / 'validation' / ('inactive-layout-stack-' + compiler + '-1.log')).read_text()
    active = (A / 'validation' / ('active-layout-stack-' + compiler + '-1.log')).read_text()
    assert 'Runtime bytes=1776 align=16' in inactive
    assert 'Runtime bytes=1840 align=16' in active
    assert 'OptionalSession bytes=64 align=8' in active
    assert 'initial_allocated=4716 header_allowance=2048' in active
    assert 'remaining=5 allocated=1739360 objects=749 capacity=749 native=299 prototypes=25 globals=212' in active
    for test in ['thirty_two_activations_execute_on_small_native_stack_without_parsing_there',
                 'expression_execution_uses_small_native_stack_without_native_depth_charges']:
        assert test + ' ... ok' in active and test + ' ... ok' in inactive
refs = read('root/reference-comparison-final.json')
assert refs['status'] == 'pass' and refs['pairs'] == 102 and refs['unchanged_pngs'] == 204
assert read('root/host-discovery-verification.json')['status'] == 'pass'
result = {'status': 'pass', 'source_inventory': bind(A / 'source-2.json'),
          'checks': checks,
          'full_suites': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k,v in totals.items()},
          'worker_tests_per_suite': 89, 'python_tests': 532,
          'upstream': {'sources':232, 'modes':458, 'preflights':74, 'counts':report['counts'],
                       'failure_reasons':dict(failure_reasons), 'report':bind(A/'validation/promise-upstream-report-2.json'),
                       'baseline':bind(W/'tests/conformance/test262-promise-methods-async-current.json')},
          'legacy_upstream': {'sources':326, 'modes':652, 'preflights':32, 'counts':legacy['counts'],
                              'regressions':0, 'improvements':0},
          'layout': {'compilers':['1.88.0','1.99.0'], 'runtime_disabled':1776, 'runtime_enabled':1840,
                     'session':64, 'optional_session':64, 'observation':12, 'header_allowance':2048,
                     'initial_allocated':4716, 'bootstrap_allocated':1739360, 'bootstrap_remaining_work':5,
                     'small_native_stack_bytes':131072, 'physical_stack_frame_measurement':False},
          'adapter':adapter, 'browser':read('root/final-browser.json'), 'references':refs}
with (A/'root/final-validation.json').open('x') as out:
    json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','full_suites','upstream','layout']}))
