from pathlib import Path
import contextlib
import hashlib
import io
import json
import os
import sys
import textwrap

A = Path(__file__).resolve().parents[1]
workflow = A / 'worktree/.github/workflows/check.yml'
source = workflow.read_text()
marker = '          python3 - "$runtime_listing" "$adapter_listing" <<\'PYGUARD\'\n'
assert source.count(marker) == 1
script = textwrap.dedent(source.split(marker, 1)[1].split('          PYGUARD\n', 1)[0])
listings = [A / 'validation' / (label + '.log') for label in ['host-runtime-list-1', 'host-adapter-list-1']]
for listing in listings:
    receipt = json.loads(listing.with_suffix('.json').read_text())
    assert receipt['exit'] == 0
    assert hashlib.sha256(listing.read_bytes()).hexdigest() == receipt['sha256']
os.chdir(A / 'worktree')
sys.argv = ['workflow-discovery', *map(str, listings)]
output = io.StringIO()
with contextlib.redirect_stdout(output):
    exec(compile(script, str(workflow) + ':host-discovery', 'exec'), {'__name__': '__main__'})
record = {'status': 'pass', 'workflow_sha256': hashlib.sha256(workflow.read_bytes()).hexdigest(),
          'embedded_python_sha256': hashlib.sha256(script.encode()).hexdigest(),
          'output': output.getvalue(),
          'listings': [{'path': str(p), 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in listings]}
with (A / 'root/host-discovery-verification.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
print(json.dumps(record))
