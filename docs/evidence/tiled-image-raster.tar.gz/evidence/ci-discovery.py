from pathlib import Path
import re
import sys

modules = (
    ('src/graphics/raster_bridge/tests.rs', 'graphics::raster_bridge::tests::', 21),
    ('src/graphics/raster_bridge/text/tests.rs', 'graphics::raster_bridge::text::tests::', 7),
    ('src/graphics/raster_bridge/native/tests.rs', 'graphics::raster_bridge::native::tests::', 25),
    ('src/graphics/raster_bridge/native/opacity_tests.rs', 'graphics::raster_bridge::native::tests::opacity_tests::', 17),
    ('src/graphics/raster_bridge/native/scope_accounting_tests.rs', 'graphics::raster_bridge::native::tests::scope_accounting_tests::', 6),
    ('src/graphics/raster_bridge/native/rect_accounting_tests.rs', 'graphics::raster_bridge::native::tests::rect_accounting_tests::', 6),
    ('src/graphics/raster_bridge/native/image_accounting_tests.rs', 'graphics::raster_bridge::native::tests::image_accounting_tests::', 10),
    ('src/graphics/raster_bridge/native/image_loop_differential_tests.rs', 'graphics::raster_bridge::native::tests::image_loop_differential_tests::', 1),
    ('src/graphics/raster_bridge/gradient_tests.rs', 'graphics::raster_bridge::gradient_tests::', 3),
    ('src/graphics/raster_bridge/native/gradient_tests.rs', 'graphics::raster_bridge::native::gradient_tests::', 11),
    ('src/graphics/raster_bridge/background_image_tests.rs', 'graphics::raster_bridge::background_image_tests::', 7),
)
expected = set()
for source, prefix, count in modules:
    names = re.findall(r'(?m)^#\[test\]\s*\nfn ([A-Za-z_]\w*)\(', Path(source).read_text())
    if len(names) != count or len(set(names)) != count:
        raise SystemExit(f'{source}: expected {count} distinct test declarations, got {len(names)}')
    expected.update(prefix + name for name in names)
found = [line.removesuffix(': test') for line in Path(sys.argv[1]).read_text().splitlines()
         if line.endswith(': test')]
if len(found) != 114 or set(found) != expected:
    raise SystemExit(f'bridge test discovery mismatch: found={len(found)}, '
                     f'missing={sorted(expected - set(found))}, extra={sorted(set(found) - expected)}')
print('Verified all 28 relocated, 25 native, 17 opacity, 6 scope-accounting, 6 Rect-accounting, 11 image-accounting, 3 gradient-refusal, 11 native-gradient and 7 background-image bridge tests are discoverable.')
