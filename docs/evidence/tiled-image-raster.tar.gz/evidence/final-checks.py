from pathlib import Path
import json, subprocess, sys

p = Path(__file__).resolve().parent
if sys.argv[1] == '188':
    steps = [
        ['full-native-2', '1.88.0', 'Cargo.toml', 'vulkan-raster', 'test', '--', '--include-ignored', '--test-threads=4'],
        ['native-clippy-188-2', '1.88.0', 'Cargo.toml', 'vulkan-raster', 'clippy', '--all-targets', '--', '-D', 'warnings'],
        ['probe-tests-188-2', '1.88.0', 'tools/vulkan-raster-probe/Cargo.toml', 'browser-bridge', 'test', '--', '--include-ignored', '--test-threads=4'],
        ['candidate-browser-build-2', '1.88.0', 'Cargo.toml', 'vulkan-raster', 'build', '--bin', 'eris-browser'],
    ]
elif sys.argv[1] == '198':
    steps = [
        ['full-default-198-2', '1.98.0', 'Cargo.toml', '-', 'test', '--', '--include-ignored', '--test-threads=4'],
        ['default-clippy-198-2', '1.98.0', 'Cargo.toml', '-', 'clippy', '--all-targets', '--', '-D', 'warnings'],
        ['native-clippy-198-2', '1.98.0', 'Cargo.toml', 'vulkan-raster', 'clippy', '--all-targets', '--', '-D', 'warnings'],
        ['probe-tests-198-2', '1.98.0', 'tools/vulkan-raster-probe/Cargo.toml', 'browser-bridge', 'test', '--', '--include-ignored', '--test-threads=4'],
        ['probe-clippy-198-2', '1.98.0', 'tools/vulkan-raster-probe/Cargo.toml', 'browser-bridge', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ]
else:
    raise SystemExit('unknown final check lane')
for step in steps:
    result = subprocess.run(['python3', str(p / 'run-check.py'), *step], stdout=subprocess.DEVNULL)
    receipt = p / 'validation' / (step[0] + '.json')
    if receipt.exists():
        print(receipt.read_text(), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
