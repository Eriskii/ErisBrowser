from pathlib import Path
r=Path('/tmp/eris-background-layers-1/layout/raw/src/layout')
p=r/'inline_backgrounds.rs';s=p.read_text()
s=s.replace('style.background_image.is_none()','style.backgrounds.image_slots().iter().all(Option::is_none)')
s=s.replace('''        // The opener, three explicit layer slots and closer are one admission.
        // Geometry and prefix were retained before this paint-only decision.
        if self.commands_created + self.open_clips + 5 > MAX_COMMANDS {
            return;
        }
''','''        // Color, authored image slots, border and the balanced clip pair are
        // one admission. None slots preserve authored indexing and geometry.
        let image_count=style.backgrounds.image_slots().len();
        if !self.admit_decoration_slots(image_count+4) { return; }
''')
s=s.replace('            inline_sides: physical_sides,','            inline_sides: physical_sides,\n            background_image_index:0,',1)
start=s.index('        for layer in [InlineLayer::Color');end=s.index('        self.paint_owner.inline_layer = InlineLayer::None;',start)
s=s[:start]+'''        self.paint_owner.inline_layer=InlineLayer::Color;
        self.push(DrawCommand::Rect {rect:geometry.border,color:Color::TRANSPARENT,radius:0.0});
        for image_index in (0..image_count).rev() {
            self.paint_owner.inline_layer=InlineLayer::Image;
            self.paint_owner.background_image_index=image_index as u8;
            self.push(DrawCommand::Rect {rect:geometry.border,color:Color::TRANSPARENT,radius:0.0});
        }
        self.paint_owner.background_image_index=0;
        self.paint_owner.inline_layer=InlineLayer::Border;
        self.push(DrawCommand::Rect {rect:geometry.border,color:Color::TRANSPARENT,radius:0.0});
''' +s[end:]
s=s.replace('''        let pending = self
            .owners
            .iter()
            .filter(|owner| owner.inline_layer != InlineLayer::None)
            .count();''','''        let (pending,extra_images)=self.owners.iter().fold((0usize,0usize),|(pending,extra),owner| {
            (pending+usize::from(owner.inline_layer!=InlineLayer::None),
             extra+usize::from(owner.inline_layer==InlineLayer::Image && owner.background_image_index!=0))
        });''')
s=s.replace('.saturating_add(pending.saturating_mul(background_boxes::SHAPE_WORK));','.saturating_add(pending.saturating_mul(background_boxes::SHAPE_WORK))\n            .saturating_add(extra_images.saturating_mul(background_boxes::LAYER_WORK));')
s=s.replace('        for index in 0..self.commands.len() {','        let mut group_boxes=None;\n        for index in 0..self.commands.len() {',1)
s=s.replace('            if owner.inline_layer == InlineLayer::Clip {\n','            if owner.inline_layer == InlineLayer::Clip {\n                group_boxes=None;\n',1)
start=s.index('            let Some(boxes) = metrics');end=s.index('            let command = match owner.inline_layer',start)
s=s[:start]+'''            let boxes=if let Some(boxes)=group_boxes { boxes } else {
                let Some(boxes)=metrics.get(owner.node).copied().and_then(|metric|
                    metric.boxes(area,owner.inline_prefix,style.border_radius)) else { continue; };
                group_boxes=Some(boxes);boxes
            };
''' +s[end:]
s=s.replace('InlineLayer::Color => background_boxes::color(shape, style.background_color, None),','InlineLayer::Color => background_boxes::color(boxes.select(style.backgrounds.bottom_clip()), style.background_color, None),')
s=s.replace('''                    let origin = boxes.select(style.background_origin).rect;
                    let current_color = style.color;''','''                    let image_index=usize::from(owner.background_image_index);
                    let Some(layer)=style.backgrounds.layer(image_index) else { continue; };
                    let origin=boxes.select(layer.origin).rect;
                    let shape=boxes.select(layer.clip);
                    let current_color=style.color;''')
s=s.replace('''                        owner.node,
                        shape.rect,''','''                        owner.node,
                        image_index,
                        shape.rect,''')
p.write_text(s)
p=r.parent/'layout.rs';s=p.read_text();s=s.replace('''    // This bounded role check precedes no payload allocation or geometry loop.
    let shaped=fragment.commands.iter().take(slots.len()).any(|command|matches!(command,DrawCommand::BoxDecoration(_)));
    let selected=shaped || background_boxes::nondefault(style);''','''    let widths=style.border_width;
    let border=Sides {top:extent(widths.top),right:extent(widths.right),bottom:extent(widths.bottom),left:extent(widths.left)};
    let selected=background_boxes::shape_path(style,border,slots.rounded()) || background_boxes::nondefault(style);''')
p.write_text(s)
