#[test]
fn retile_paint_refusal_preserves_completed_geometry() {
    let doc = Document::parse(&stretch_source("linear-gradient(red,blue)"));
    let styles = crate::css::compute_styles(&doc, &doc.stylesheets(), 32.0, 24.0);
    let id = doc.query_selector("#box").unwrap();
    let fonts = Fonts::new();
    for budget in [16, 17] {
        let mut e = engine(&doc, &styles, &fonts, &[]);
        let mut f = e.fragment(id, 8.0, 8.0, 0);
        assert_eq!(f.boxes.len(), 1);
        let mut work = budget;
        assert_eq!(
            stretch_fragment_background_boxes(&mut f, 10.0, &styles[id], 8.0, None, &mut work),
            budget == 17
        );
        if budget == 16 {
            assert_eq!(work, 16);
            assert_eq!(f.size.height, 10.0);
            assert_eq!(f.hits[0].rect.height, 10.0);
            assert_eq!(f.boxes[0].border.height, 10.0);
            assert_eq!(
                f.commands
                    .iter()
                    .filter_map(image_geometry)
                    .collect::<Vec<_>>(),
                Vec::new()
            );
        } else {
            assert_eq!(work, 0);
            assert_eq!(f.size.height, 10.0);
        }
    }
}
