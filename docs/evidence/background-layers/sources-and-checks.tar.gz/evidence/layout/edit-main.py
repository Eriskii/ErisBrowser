from pathlib import Path
p=Path('/tmp/eris-background-layers-1/layout/raw/src/layout.rs');s=p.read_text()
needle='''pub(crate) struct LoadedBackground<'a> {
    pub(crate) key: &'a str,
    pub(crate) natural: RasterNaturalSize,
}
'''
new=needle+'''
#[derive(Clone, Copy, Default)]
pub(crate) struct BackgroundBindingRange {
    pub(crate) start: u32,
    pub(crate) len: u8,
}
#[derive(Clone, Copy, Default)]
pub(crate) struct BackgroundBindings<'a> {
    pub(crate) ranges: &'a [BackgroundBindingRange],
    pub(crate) slots: &'a [Option<LoadedBackground<'a>>],
}
impl<'a> BackgroundBindings<'a> {
    pub(crate) fn get(self, node: NodeId, image_index: usize) -> Option<LoadedBackground<'a>> {
        let range = self.ranges.get(node)?;
        let start = usize::try_from(range.start).ok()?;
        let len = usize::from(range.len);
        if image_index >= len || start.checked_add(len)? > self.slots.len() { return None; }
        self.slots.get(start.checked_add(image_index)?).copied().flatten()
    }
}

pub(crate) fn canvas_background_owner(styles: &[ComputedStyle], html: Option<NodeId>, body: Option<NodeId>) -> Option<NodeId> {
    let present = |style: &ComputedStyle| style.background_color.a > 0 || !style.backgrounds.is_single_none();
    html.filter(|id| styles.get(*id).is_some_and(present)).or_else(|| {
        body.filter(|id| styles.get(*id).is_some_and(|style| style.display != Display::None && present(style)))
    })
}
'''
assert needle in s;s=s.replace(needle,new,1)
s=s.replace('    inline_sides: u8,\n}\n#[derive(Clone, Copy)]\nstruct BoxGeometry','    inline_sides: u8,\n    background_image_index: u8,\n}\n#[derive(Clone, Copy)]\nstruct BoxGeometry',1)
s=s.replace('    rounded_border: bool,\n    gradient: bool,','    paint_slots: PaintSlots,',1)
s=s.replace('''struct Fragment {''','''struct BoxLayout {
    size: Size,
    paint_slots: PaintSlots,
}

struct Fragment {''',1)
s=s.replace("    backgrounds: &'a [Option<LoadedBackground<'a>>],","    backgrounds: BackgroundBindings<'a>,",1)
s=s.replace('layout_with_backgrounds(doc, styles, width, height, fonts, &[])','layout_with_backgrounds(doc, styles, width, height, fonts, BackgroundBindings::default())',1)
s=s.replace("    backgrounds: &[Option<LoadedBackground<'_>>],","    backgrounds: BackgroundBindings<'_>,",1)
start=s.index('    let canvas_background_node = html\n');end=s.index('    let mut engine = Engine {',start)
s=s[:start]+'''    let canvas_background_node = canvas_background_owner(styles, html, doc.first_html_element("body"));
'''+s[end:]
# Add index in owner constructors, not BoxGeometry constructors.
import re
s=re.sub(r'(inline_layer: InlineLayer::\w+,\n\s+inline_prefix: [^\n]+,\n\s+inline_sides: [^\n]+,)',r'\1\n            background_image_index: 0,',s)
start=s.index('    let mut canvas_gradient = None;');end=s.index('    let size = if doc.nodes.get(doc.root)',start)
s=s[:start]+'''    let mut canvas_paint = None;
    if let Some(id) = canvas_background_node {
        engine.paint_owner.node = html.unwrap_or(id);
        let count = if engine.style(id).backgrounds.is_single_none() { 0 } else { engine.style(id).backgrounds.image_slots().len() };
        if engine.admit_decoration_slots(1 + count) {
            let start = engine.commands.len();
            for _ in 0..1 + count { engine.push(background_boxes::empty()); }
            canvas_paint = Some((start,count));
        }
        engine.paint_owner.node = doc.root;
    }
'''+s[end:]
start=s.index('    if canvas_background_node.is_some()\n');end=s.index('    engine.finish_inline_backgrounds();',start)
s=s[:start]+'''    if let (Some((start,count)), Some(source)) = (canvas_paint, canvas_background_node) {
        engine.commands[start] = DrawCommand::Rect {
            rect: rect(0.0,0.0,viewport.width,content_height),
            color: engine.style(source).background_color, radius:0.0,
        };
        let root = html.unwrap_or(source);
        let work = if count > 1 { background_boxes::layers_work(count) } else { Some(0) };
        if work.is_some_and(|cost| background_boxes::spend(&mut engine.position_work_left,cost)) {
            if let Some(geometry) = engine.canvas_background_geometry(root) {
                for offset in 0..count {
                    let index=count-1-offset;
                    let origin=engine.style(source).backgrounds.layer(index).unwrap().origin;
                    let area=match origin { BackgroundBox::Border=>geometry.border, BackgroundBox::Padding=>geometry.padding, BackgroundBox::Content=>geometry.content };
                    if let Some(command)=engine.background_command(source,index,
                        rect(0.0,0.0,viewport.width,content_height),area,0.0,engine.style(root).color,false) {
                        engine.commands[start+1+offset]=command;
                    }
                }
            }
        }
    }
'''+s[end:]
start=s.index('    fn loaded_background(&self, node: NodeId)');end=s.index('    fn html_tag(',start)
s=s[:start]+'''    fn admit_decoration_slots(&mut self, count: usize) -> bool {
        self.commands_created.checked_add(self.open_clips).and_then(|n| n.checked_add(count)).is_some_and(|n| n <= MAX_COMMANDS)
            && self.commands.try_reserve_exact(count).is_ok()
            && self.owners.try_reserve_exact(count).is_ok()
    }

    fn loaded_background(&self, node: NodeId, image_index: usize) -> Option<LoadedBackground<'_>> {
        self.backgrounds.get(node,image_index).filter(|loaded| loaded.natural.width>0 && loaded.natural.height>0)
    }

    #[allow(clippy::too_many_arguments)]
    fn background_command(&mut self,node:NodeId,image_index:usize,paint:Rect,area:Rect,radius:f32,current_color:Color,allow_pending_tile:bool)->Option<DrawCommand> {
        let layer=self.style(node).backgrounds.layer(image_index)?;
        let (size,position,repeat)=(layer.size,layer.position,layer.repeat);
        match layer.image? {
            BackgroundImage::Gradient(gradient)=> {
                let tile=background_tile(area,size,position);
                if tile.is_none() && !allow_pending_tile { return None; }
                Some(DrawCommand::LinearGradient{rect:paint,tile:tile.unwrap_or_default(),radius,gradient:gradient.clone(),current_color,stop_scale:1.0,repeat})
            }
            BackgroundImage::Url(_)=> {
                let loaded=self.loaded_background(node,image_index)?;
                let tile=background_tile_with_raster(area,size,position,loaded.natural);
                if tile.is_none() && !allow_pending_tile { return None; }
                let key=clone_background_key(loaded.key,&mut self.background_key_bytes_left,&mut self.position_work_left)?;
                Some(DrawCommand::BackgroundImage{rect:paint,tile:tile.unwrap_or_default(),radius,key,repeat})
            }
        }
    }

    fn canvas_background_geometry(&mut self, root:NodeId)->Option<BoxGeometry> {
        if !background_boxes::spend(&mut self.position_work_left,self.boxes.len()) { return None; }
        self.boxes.iter().find(|g|g.node==root && !g.inline).copied()
    }

'''+s[end:]
s=s.replace('self.layout_box_sized(id, x, y, available, (forced_width, None), depth)','self.layout_box_sized(id, x, y, available, (forced_width, None), depth).size',1)
pos=s.index('    fn layout_box_sized(');end=s.index('    fn layout_flow(',pos);block=s[pos:end]
block=block.replace('    ) -> Size {','    ) -> BoxLayout {',1).replace('return Size::default();','return BoxLayout { size:Size::default(),paint_slots:PaintSlots::default() };',1)
start=block.index('        let has_image =');finish=block.index('        self.paint_owner.background = false;',start)
block=block[:start]+'''        let suppressed=self.canvas_background_node==Some(id);
        let planned=if style.backgrounds.image_slots().len()>1 {
            PaintSlots::layers(if suppressed {0}else{style.backgrounds.image_slots().len()},style.border_radius>0.0)
        } else { PaintSlots::new(!suppressed && !style.backgrounds.is_single_none(),self.rounded_border(id)) };
        let mut paint_slots=planned.omitted();
        if self.admit_decoration_slots(planned.len()) {
            paint_slots=planned;
            for _ in 0..planned.len() { self.push(background_boxes::empty()); }
        }
'''+block[finish:]
# Attach own overflow bit after existing opener construction.
needle='''        let tag = self.layout_tag(id).to_owned();''';block=block.replace(needle,'        paint_slots = paint_slots.with_overflow(clip_index.is_some());\n'+needle,1)
block=block.replace('            has_image,','            paint_slots,')
block=block.replace('        Size { width, height }\n','        BoxLayout { size: Size { width,height }, paint_slots }\n',1)
s=s[:pos]+block+s[end:]
s=s.replace('''        let size = self.layout_box_sized(id, 0.0, 0.0, available, (Some(width), height), depth);''','''        let laid_out = self.layout_box_sized(id, 0.0, 0.0, available, (Some(width), height), depth);''',1)
s=s.replace('''        Fragment {
            size,
''','''        Fragment {
            size: laid_out.size,
''',1)
s=s.replace('''            rounded_border: self.rounded_border(id),
            gradient: self.canvas_background_node != Some(id)
                && self.style(id).background_image.is_some(),''','''            paint_slots: laid_out.paint_slots,''',1)
# Old singleton shortcut only applies to one image slot.
pos=s.index('    fn rounded_border(');end=s.index('    fn append_fragment(',pos);block=s[pos:end]
block=block.replace('        let border = self.borders(id);','        let border = self.borders(id);\n        if style.backgrounds.image_slots().len() != 1 { return false; }\n        let layer=style.backgrounds.layer(0).unwrap();')
for field,new in [('background_clip','clip'),('background_size','size'),('background_position','position'),('background_repeat','repeat'),('background_origin','origin')]:block=block.replace('style.'+field,'layer.'+new)
block=block.replace('&style.background_image','layer.image').replace('style.background_image','layer.image')
s=s[:pos]+block+s[end:]
# Table row layer group.
pos=s.index('            self.push(DrawCommand::Rect {\n                rect: row_rect,');end=s.index('            self.paint_owner = saved_owner;',pos)
s=s[:pos]+'''            let count=if style.backgrounds.is_single_none(){0}else{style.backgrounds.image_slots().len()};
            if self.admit_decoration_slots(1+count) {
                self.push(DrawCommand::Rect {rect:row_rect,color:background,radius:0.0});
                let cost=if count>1{background_boxes::layers_work(count)}else{Some(0)};
                if cost.is_some_and(|n|background_boxes::spend(&mut self.position_work_left,n)) {
                    for image_index in (0..count).rev() {
                        let command=self.background_command(id,image_index,row_rect,row_rect,0.0,style.color,false).unwrap_or_else(background_boxes::empty);
                        self.push(command);
                    }
                } else {
                    for _ in 0..count { self.push(background_boxes::empty()); }
                }
            }
'''+s[end:]
start=s.index('            let paint_slots = PaintSlots::new(fragment.gradient, fragment.rounded_border).len();');end=s.index('            translate_fragment_commands',start)
s=s[:start]+'''            let content_start = fragment.paint_slots.len() + usize::from(fragment.paint_slots.overflow());
'''+s[end:]
start=s.index('            let natural = self\n                .loaded_background(cell.node)');end=s.index('            let cell_x =',start)
s=s[:start]+'''            let style=self.styles.get(cell.node).unwrap_or(&self.fallback);
            stretch_fragment_background_boxes(&mut fragment,cell_height,style,cell.available,self.backgrounds,cell.node,&mut self.position_work_left);
'''+s[end:]
# Test module registration.
s+='\n#[cfg(test)]\nmod layers_tests;\n'
p.write_text(s)
