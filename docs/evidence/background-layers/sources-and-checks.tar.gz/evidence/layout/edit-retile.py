from pathlib import Path
p=Path('/tmp/eris-background-layers-1/layout/raw/src/layout.rs');s=p.read_text()
s=s.replace('    paint_slots: PaintSlots,\n}', '    paint_slots: PaintSlots,\n    principal_box: u32,\n}',2)
s=s.replace("impl Engine<'_> {","impl<'a> Engine<'a> {",1)
s=s.replace("fn loaded_background(&self,node:NodeId,index:usize)->Option<LoadedBackground<'_>>", "fn loaded_background(&self,node:NodeId,index:usize)->Option<LoadedBackground<'a>>")
s=s.replace('if let Some(geometry) = engine.canvas_background_geometry(root) {','if count != 0 && let Some(geometry) = engine.canvas_background_geometry(root) {',1)
s=s.replace('return BoxLayout { size:Size::default(),paint_slots:PaintSlots::default() };','return BoxLayout { size:Size::default(),paint_slots:PaintSlots::default(),principal_box:u32::MAX };')
needle='    ) -> BoxLayout {\n';s=s.replace(needle,needle+'        let geometry_start = self.boxes.len();\n',1)
s=s.replace('        self.hits[hit_start].rect.height = height;\n        self.boxes.push(BoxGeometry {','        self.hits[hit_start].rect.height = height;\n        let principal_box = u32::try_from(self.boxes.len() - geometry_start).unwrap_or(u32::MAX);\n        self.boxes.push(BoxGeometry {',1)
s=s.replace('BoxLayout { size: Size { width,height }, paint_slots }','BoxLayout { size: Size { width,height }, paint_slots, principal_box }',1)
s=s.replace('            paint_slots: laid_out.paint_slots,','            paint_slots: laid_out.paint_slots,\n            principal_box: laid_out.principal_box,',1)
s=s.replace('stretch_fragment_background_boxes(&mut fragment,cell_height,style,cell.available,self.backgrounds,cell.node,&mut self.position_work_left);','stretch_fragment_background_layers(&mut fragment,cell_height,style,cell.available,self.backgrounds,cell.node,&mut self.position_work_left);')
start=s.index('fn stretch_fragment_background_with_raster(');end=s.index('\n/// Use binary search',start)
s=s[:start]+'''// The principal index is captured when the root geometry is appended, after
// its descendants. Validate its identity instead of scanning on every stretch.
fn stretch_fragment_geometry(fragment: &mut Fragment, height: f32) -> (f32, Option<BoxGeometry>) {
    let height = extent(height).max(fragment.size.height);
    let delta = height - fragment.size.height;
    let node = fragment.hits.first().map(|hit| hit.node);
    if let Some(hit) = fragment.hits.first_mut() { hit.rect.height = height; }
    let geometry = fragment.boxes.get_mut(fragment.principal_box as usize)
        .filter(|geometry| Some(geometry.node) == node && !geometry.inline)
        .map(|geometry| {
            geometry.border.height += delta;
            geometry.padding.height += delta;
            geometry.content.height += delta;
            *geometry
        });
    if fragment.paint_slots.overflow()
        && let Some(DrawCommand::PushClip { rect }) = fragment.commands.get_mut(fragment.paint_slots.len())
    { rect.height += delta; }
    fragment.size.height = height;
    (delta, geometry)
}

fn stretch_rect_role(command: &mut DrawCommand, role: PaintRole, height: f32, delta: f32) {
    if let DrawCommand::Rect { rect, .. } = command {
        match role {
            PaintRole::Color | PaintRole::Right | PaintRole::Left | PaintRole::RoundOuter => rect.height = height,
            PaintRole::RoundInner => rect.height += delta,
            PaintRole::Bottom => rect.y += delta,
            _ => {}
        }
    }
}

#[cfg(test)]
fn stretch_fragment_background_with_raster(
    fragment: &mut Fragment, height: f32, size: BackgroundSize,
    position: BackgroundPosition, natural: Option<RasterNaturalSize>,
) {
    let (delta, geometry) = stretch_fragment_geometry(fragment,height);
    let padding = geometry.map(|geometry| geometry.padding);
    let slots = fragment.paint_slots;
    for (index,command) in fragment.commands.iter_mut().take(slots.len()).enumerate() {
        match command {
            DrawCommand::LinearGradient { rect, tile, .. } => {
                rect.height += delta;
                *tile = padding.and_then(|area| background_tile(area,size,position)).unwrap_or_default();
            }
            DrawCommand::BackgroundImage { rect, tile, .. } => {
                rect.height += delta;
                *tile = padding.zip(natural).and_then(|(area,n)| background_tile_with_raster(area,size,position,n)).unwrap_or_default();
            }
            _ => stretch_rect_role(command,slots.role(index),fragment.size.height,delta),
        }
    }
}

#[cfg(test)]
fn stretch_fragment_background_boxes(
    fragment: &mut Fragment,height:f32,style:&ComputedStyle,available:f32,
    natural:Option<RasterNaturalSize>,work:&mut usize,
)->bool {
    stretch_fragment_background_layers_with(fragment,height,style,available,|_|natural,work)
}

#[allow(clippy::too_many_arguments)]
fn stretch_fragment_background_layers(
    fragment:&mut Fragment,height:f32,style:&ComputedStyle,available:f32,
    backgrounds:BackgroundBindings<'_>,node:NodeId,work:&mut usize,
)->bool {
    stretch_fragment_background_layers_with(fragment,height,style,available,|index|backgrounds.get(node,index).map(|loaded|loaded.natural),work)
}

// Update layout and overflow independently; only the decoration is omitted on
// work refusal. Keys already paid during initial layout are mutated in place.
#[inline(never)]
fn stretch_fragment_background_layers_with(
    fragment:&mut Fragment,height:f32,style:&ComputedStyle,available:f32,
    natural:impl Fn(usize)->Option<RasterNaturalSize>,work:&mut usize,
)->bool {
    let slots=fragment.paint_slots;
    let (delta,geometry)=stretch_fragment_geometry(fragment,height);
    if slots.len()==0 { return true; }
    // This bounded role check precedes no payload allocation or geometry loop.
    let shaped=fragment.commands.iter().take(slots.len()).any(|command|matches!(command,DrawCommand::BoxDecoration(_)));
    let selected=shaped || background_boxes::nondefault(style);
    let boxes=if selected {
        let shape_work=if slots.layered() { background_boxes::layers_work(slots.images()) } else { Some(background_boxes::SHAPE_WORK) };
        let cost=shape_work.and_then(|cost|fragment.boxes.len().checked_add(cost));
        let prepared=cost.filter(|cost|background_boxes::spend(work,*cost)).and_then(|_|geometry).and_then(|geometry|
            BackgroundBoxes::from_style(crate::graphics::box_decoration::RoundedBox {rect:geometry.border,radii:[[style.border_radius;2];4]},style,available));
        let Some(boxes)=prepared else {
            for command in fragment.commands.iter_mut().take(slots.len()) { *command=background_boxes::empty(); }
            return false;
        };
        Some(boxes)
    } else { None };
    for (index,command) in fragment.commands.iter_mut().take(slots.len()).enumerate() {
        let role=slots.role(index);
        let image_index=match role { PaintRole::Image(index)=>Some(usize::from(index)),_=>None };
        let layer=image_index.and_then(|index|style.backgrounds.layer(index));
        let origin=layer.and_then(|layer|boxes.map(|boxes|boxes.select(layer.origin).rect).or_else(||geometry.map(|geometry|geometry.padding)));
        let tile=|raster:bool|layer.zip(origin).and_then(|(layer,area)|{
            if raster { natural(layer.index).and_then(|n|background_tile_with_raster(area,layer.size,layer.position,n)) }
            else { background_tile(area,layer.size,layer.position) }
        }).unwrap_or_default();
        match command {
            DrawCommand::LinearGradient { rect,tile:target,.. } => { rect.height+=delta;*target=tile(false); }
            DrawCommand::BackgroundImage { rect,tile:target,.. } => { rect.height+=delta;*target=tile(true); }
            DrawCommand::BoxDecoration(shared) => {
                let Some(decoration)=std::sync::Arc::get_mut(shared) else { *command=background_boxes::empty();continue; };
                let Some(boxes)=boxes else { *command=background_boxes::empty();continue; };
                if decoration.cutout.is_some() { decoration.shape=boxes.border;decoration.cutout=Some(boxes.padding); }
                else { decoration.shape=boxes.select(layer.map_or(style.backgrounds.bottom_clip(),|layer|layer.clip)); }
                match &mut decoration.paint {
                    crate::graphics::box_decoration::BoxPaint::LinearGradient { tile:target,.. } => *target=tile(false),
                    crate::graphics::box_decoration::BoxPaint::Image { tile:target,.. } => *target=tile(true),
                    crate::graphics::box_decoration::BoxPaint::Color(_) => {}
                }
            }
            _ => stretch_rect_role(command,role,fragment.size.height,delta),
        }
    }
    true
}
''' +s[end:]
p.write_text(s)
