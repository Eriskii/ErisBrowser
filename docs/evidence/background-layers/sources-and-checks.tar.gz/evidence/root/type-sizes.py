"""Read selected Rust type sizes from DWARF without changing/executing the binary."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

binary, destination = map(Path, sys.argv[1:])
targets = {
    "eris::css::ComputedStyle", "eris::layout::Fragment", "eris::layout::InlineKind",
    "eris::layout::InlineItem", "eris::layout::PaintOwner", "eris::layout::BoxGeometry",
}
header = re.compile(r"\s*<(\d+)><[0-9a-f]+>:.*\((DW_TAG_\w+)\)")
stack = []
found = {}
process = subprocess.Popen(["readelf", "--debug-dump=info", str(binary)],
                           stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
                           text=True, close_fds=True)
try:
    for line in process.stdout:
        match = header.match(line)
        if match:
            depth = int(match[1])
            stack = stack[:depth]
            while len(stack) < depth:
                stack.append({})
            stack.append({"tag": match[2]})
            continue
        if not stack:
            continue
        node = stack[-1]
        if "DW_AT_name" in line:
            node["name"] = line.split("DW_AT_name", 1)[1].strip().lstrip(": ").split(": ")[-1]
        elif "DW_AT_byte_size" in line:
            value = line.split("DW_AT_byte_size", 1)[1].strip().lstrip(": ")
            if re.fullmatch(r"(?:0x[0-9a-f]+|\d+)", value):
                node["size"] = int(value, 0)
        if "name" in node and "size" in node:
            namespace = [item.get("name", "") for item in stack[:-1] if item.get("tag") == "DW_TAG_namespace"]
            name = "::".join(namespace + [node["name"]])
            if name in targets:
                assert found.setdefault(name, node["size"]) == node["size"]
                if found.keys() == targets:
                    break
finally:
    process.stdout.close()
    if process.poll() is None:
        process.terminate()
    process.wait(timeout=10)
assert found.keys() == targets, found
with binary.open("rb") as stream:
    sha = hashlib.file_digest(stream, "sha256").hexdigest()
record = {"binary": str(binary), "binary_sha256": sha, "scope": "DWARF type byte sizes for this compiled target", "sizes": found}
with destination.open("x") as stream:
    json.dump(record, stream, indent=2)
    stream.write("\n")
print(json.dumps(record))
