from pathlib import Path
import subprocess,json,time,hashlib,sys,os
P=Path(__file__).resolve().parent.parent
binary=Path('/tmp/eris-native-background-window-1/target-198/debug/deps/eris-1d97a9c22bcf2d95')
O=P/'date-traces-focused';O.mkdir(exist_ok=False)
results=[]
env=os.environ.copy()
for key in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS'): env.pop(key,None)
for i in range(20):
    trace=O/f'run-{i}.trace';log=O/f'run-{i}.log'
    argv=['strace','-f','-qq','-s','256','-e','trace=execve,clone,clone3','-o',str(trace),str(binary),'date_host::tests::host_eof_before_exit_waits_for_exit_status_or_cancellation_and_deadline','--exact','--test-threads=1']
    start=time.monotonic()
    with log.open('xb') as stream: r=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT,env=env,close_fds=True,timeout=20)
    row={'attempt':i,'exit':r.returncode,'seconds':time.monotonic()-start,'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(row);print(json.dumps(row),flush=True)
    if r.returncode: print(log.read_text()[-6000:]);break
(O/'results.json').write_text(json.dumps(results,indent=2)+'\n')
sys.exit(results[-1]['exit'])
