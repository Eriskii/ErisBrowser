from pathlib import Path
import subprocess,json,time,hashlib,sys,os
A=Path(__file__).resolve().parent.parent
binary=A/'target-msrv/debug/deps/eris-9d04e0b37e5e4068'
O=A/'date-traces-native-1';O.mkdir(exist_ok=False)
trace=O/'exec.trace';log=O/'tests.log'
env=os.environ.copy()
for key in ('CARGO_MAKEFLAGS','MAKEFLAGS','MFLAGS'):env.pop(key,None)
argv=['strace','-f','-qq','-s','256','-e','trace=execve,clone,clone3','-o',str(trace),str(binary),'--include-ignored','--test-threads=4']
start=time.monotonic()
with log.open('xb') as stream:r=subprocess.run(argv,cwd=A/'worktree',stdout=stream,stderr=subprocess.STDOUT,env=env,close_fds=True,timeout=100)
record={'command':argv,'exit':r.returncode,'seconds':time.monotonic()-start,'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'trace_sha256':hashlib.sha256(trace.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
(O/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record));print(log.read_text()[-5000:]);sys.exit(r.returncode)
