from pathlib import Path
import hashlib,json
A=Path(__file__).resolve().parent.parent;W=A/'worktree'
def bind(p):
 data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
source=A/'source-6.json';source_data=json.loads(source.read_text())
for name,digest in source_data['source_sha256'].items():
 assert hashlib.sha256((W/name).read_bytes()).hexdigest()==digest,name
artifacts={}
exclude={'root/selection-final.json','root/selection-prepared.json','root/selection-preparation.json','root/archive-verification.json'}
folders=['css','css-storage','layout','resources','references','plan','tests','docs','validation','date-traces','date-traces-focused','date-traces-native-1','reftests-final','reftests-parent','root']
for folder in folders:
 for p in sorted((A/folder).rglob('*')):
  if not p.is_file():continue
  assert not p.is_symlink(),p
  name=p.relative_to(A).as_posix()
  if name in exclude or '__pycache__' in p.parts or name.startswith('validation/publish-'):continue
  assert name not in artifacts;artifacts[name]=bind(p)
for name in ['parent-source.json','snapshot-source.py','run-check.py','run-tool.py',*[f'source-{i}.json' for i in range(1,7)]]:
 artifacts[name]=bind(A/name)
claims=json.loads((A/'root/claims-final.json').read_text())
selection={'source_inventory':bind(source),'artifacts':dict(sorted(artifacts.items())),'claims':claims,'max_uncompressed_bytes':64*1024*1024}
output=A/'root/selection-final.json';assert not output.exists()
output.write_text(json.dumps(selection,indent=2)+'\n')
print(json.dumps({'path':str(output),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'sources':len(source_data['source_sha256']),'artifacts':len(artifacts),'artifact_bytes':sum(v['bytes'] for v in artifacts.values())}))
