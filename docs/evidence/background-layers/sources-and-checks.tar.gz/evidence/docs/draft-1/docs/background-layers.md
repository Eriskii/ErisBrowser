# Layered backgrounds

Background images now accept up to eight comma-separated `none`, supported
`linear-gradient()` or `url()` values. This extends the existing image, geometry
and box-selection paths; it adds no image kind, paint command or shader.
Try the [layer-order demo](../examples/background-layers.html):

```sh
./run.sh ./examples/background-layers.html
```

The demo places orange bands above a green/blue base, then reverses the images.
An empty middle slot stays part of both lists.

## Lists, shorthand and canvas ownership

The image list determines the number of used layers. Size, position, repeat,
origin and clip keep independent authored lengths, each from one to eight.
Shorter dependent lists repeat during used-value lookup; longer lists retain
unused entries. Inheritance copies those complete values. A `none` or unavailable
image keeps its authored index, so it cannot shift another layer's geometry.
The first image is on top. The single background color paints underneath all
images, using the clip selected for the last image slot.

For example:

```css
.panel {
  background-color: navy;
  background-image: linear-gradient(to right, red 50%, transparent 50%),
                    none, url(tile.png);
  background-size: 16px 100%, auto;
  background-repeat: repeat-x, no-repeat;
  background-origin: content-box, padding-box;
  background-clip: padding-box;
}
```

The third slot uses the first size, repeat and origin values. Each image keeps
its own positioning phase, clip and repeat axes. The existing physical position,
size, border/padding/content box and linear-gradient grammar still applies.

The shorthand expands atomically into seven longhands. Every layer resets its
omitted components; a color is allowed only in the final layer, including when
that color is transparent. Empty layers, a ninth value, malformed nesting or
mixed CSS-wide/list syntax reject the declaration. Token-aware splitting leaves
commas and comment-like bytes inside strings, URLs and nested functions intact.
Variables, CSS-wide values, `all`, inheritance and cascade-layer reversion use
the same stored lists and consuming-declaration URL base rules.

CSSOM keeps explicit longhand cardinalities in `cssText`. Its shorthand getter
uses the image count and returns an empty string for incompatible list lengths,
except a singleton dependent value with the exact canonical initial spelling
may be omitted. Repeated equal entries are not collapsed, and a singleton
`none` image is never expanded to fit a longer geometry list. Equivalent
noncanonical initial spellings can conservatively produce an empty getter.
This is a bounded serialization rule, not complete CSSOM minimization.

Canvas propagation has one shared selector for resource preparation and layout.
A transparent root permits body propagation only when its image list is exactly
one `none`; `none, none` blocks that propagation. An unavailable root URL also
retains root ownership. This follows the selected reading of the CSS background
rule; inspected Gecko behavior agrees and Blink differs, so this is not a
cross-engine agreement claim. Canvas painting retains the existing root
geometry/current-color behavior and ignores the selected layer clip for its
canvas extent. The chosen owner's backgrounds are not painted a second time
on its principal box.

## Geometry and resource preparation

Principal boxes, existing table-row/cell paths and ordinary wrapped inlines
paint the layers in reverse authored order, below their border. Origin and clip
selection remain independent for every layer. Table stretching keeps the final
flow/hit geometry even if retile paint work is refused; accepted keys and
payloads are reused. Inline border/padding/content strip sums and physical end
cuts retain each owner's phase independently of missing or refused commands.
Broader table painting, writing modes, bidi, `box-decoration-break: clone`,
attachment modes, `space`/`round` repetition, blend modes and `background-clip:
text` remain outside this subset.

Page prepares one flat slot table addressed by node and authored image index,
then passes a borrowed view to layout using the same computed styles. Slots and
ranges are admitted before resource work. URL layers use the retained page
fetcher, requested-URL success/failure caches, taint and cumulative decode
allowance. Fragment aliases share an authenticated cached allocation; separate
requested URLs are not merged merely because they redirect to the same final
URL. Failed-cache hits still consume their existing URL/metadata tariffs.
Read-only layout performs no fetch, decoding or key publication.

## Bounds and rendering routes

The 4,096-byte CSS value cap and 20,000,000 style-work allowance remain. Immutable
background records replace six scalar fields; singleton lists are inline in the
record, and longer lists share interned slices. Lists, records, table growth and
gradient/URL atoms consume one cumulative 4 MiB pool. Comparison, copy, clone and
growth work is prepaid; allocation tariffs include aligned headers and named
slack, with target-dependent sizes. Discarded retained intermediates and failed
work are not refunded. Successful singleton parser and atom tariffs remain,
but the added record/list costs can refuse whole styles earlier.

Page preparation retains its 16 MiB temporary-metadata and 16,777,216 work caps,
4 MiB cumulative background metadata, original request/deadline authority and
64 MiB decode/live-image allowances. Checked range and slot totals include all
authored slots of selected URL-bearing nodes, including none/gradient gaps.
There is no fresh allowance per layer or resize.

For multiple image slots, principal groups reserve `5 + N` commands, canvas/row
groups `1 + N`, and inline groups `N + 4`, including inert slots. New principal
shape preparation prepays `16 + 16*N`; inline finalization charges additional
image work alongside its existing owner/geometry scans. Existing 200,000-command,
2,000,000 positioning-work and 4,096-per-key/65,536-total key-byte limits remain.
Group admission precedes key cloning or decoration payloads. Refusal does not
rewind flow or strip phase; later global restacking limits can still truncate
an emitted prefix, so this is not an atomic whole-frame guarantee.

Existing Canvas and experimental Native routes consume the emitted commands.
Native color masks, eligible integer square image/opaque-gradient boxes and
whole-frame fallbacks keep their existing limits and eligibility rules. More
layers can reach those shared limits sooner. No new acquired-window, GPU
comparison, performance or production-security result follows from this change.
These work and storage tariffs are policy bounds, not complete allocator or
instruction measurements.

## Validation record

Pending root validation: selected final source and immutable browser bindings;
focused/full and strict checks; literal/reference pixels and predecessor joins;
measured type sizes and any retained failed attempts. This external draft makes
no passing-result claim. Historical background chapters retain the observations
for their own checkpoints.
