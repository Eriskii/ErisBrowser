import subprocess
from pathlib import Path

H = Path(__file__).resolve().parent
for args in [
    ['clippy-presenter-188-1', '1.88.0', 'Cargo.toml', 'vulkan-presenter', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['full-default-188-1', '1.88.0', 'Cargo.toml', '-', 'test', '--', '--include-ignored', '--test-threads=4'],
    ['full-native-198-1', '1.98.0', 'Cargo.toml', 'vulkan-raster', 'test', '--', '--include-ignored', '--test-threads=4'],
    ['release-adapter-188-1', '1.88.0', 'Cargo.toml', '-', 'build', '--release', '--bin', 'eris-js'],
]:
    result = subprocess.run(['python3', str(H/'check.py'), *args])
    if result.returncode:
        raise SystemExit(result.returncode)
