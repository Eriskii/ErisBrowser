import subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
for label,match in [('bootstrap-188-1','bootstrap'),('constants-188-1','node_constant'),('node-data-188-1','node_data'),('normalize-188-1','node_normalize'),('predicates-188-1','node_predicates'),('root-188-1','node_root'),('equality-188-1','node_equality'),('connected-188-1','node_connected'),('position-188-1','node_position'),('clone-legacy-188-1','dom_clone'),('dom-bindings-188-1','dom_bindings')]:
 r=subprocess.run(['python3',str(H/'check.py'),label,'1.88.0','Cargo.toml','-','test',match,'--','--include-ignored'])
 if r.returncode:raise SystemExit(r.returncode)
