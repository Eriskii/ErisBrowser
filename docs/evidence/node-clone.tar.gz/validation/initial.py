import subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
for args in [
 ['compile-188-1','1.88.0','Cargo.toml','-','test','--no-run'],
 ['clone-188-1','1.88.0','Cargo.toml','-','test','node_clone','--','--include-ignored','--nocapture','--test-threads=1']]:
 r=subprocess.run(['python3',str(H/'check.py'),*args])
 if r.returncode:raise SystemExit(r.returncode)
