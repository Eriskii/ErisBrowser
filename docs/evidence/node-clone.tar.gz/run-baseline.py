"""Run the frozen new fixture against the published predecessor once."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import time

HERE = Path(__file__).resolve().parent
PREP = Path('/tmp/eris-node-clone-preparation-1')
BASE = '0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5'


def binding(path):
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


base = json.loads((PREP / 'root/published-base.json').read_text())
assert base['commit'] == BASE
binary = Path(base['release']['path'])
assert binding(binary)['sha256'] == base['release']['sha256']
assert binary.stat().st_size == base['release']['bytes']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=HERE / 'worktree', text=True).strip() == BASE
assert subprocess.check_output(['git', 'status', '--porcelain'], cwd=HERE / 'worktree') == b''
ready = json.loads((PREP / 'replay/source-ready.json').read_text())
for row in ready['files']:
    actual = binding(Path(row['path']))
    assert actual['sha256'] == row['sha256'] and actual['bytes'] == row['bytes']
argv = ['python3', str(PREP / 'replay/replay.py'), str(binary), base['release']['sha256'], str(HERE / 'clone-before.json')]
started_at = datetime.datetime.now(datetime.timezone.utc).isoformat()
start = time.monotonic()
with (HERE / 'baseline.log').open('xb') as output:
    result = subprocess.run(argv, stdout=output, stderr=subprocess.STDOUT)
record = dict(command=argv, exit=result.returncode, started_at=started_at,
              elapsed_seconds=time.monotonic()-start, log=binding(HERE / 'baseline.log'),
              readiness=binding(PREP / 'replay/source-ready.json'), binary=binding(binary))
with (HERE / 'baseline-execution.json').open('x') as output:
    json.dump(record, output, indent=2)
    output.write('\n')
print(json.dumps(record), flush=True)
raise SystemExit(result.returncode)
