# Clone comparison preparation

This preparation binds published position commit
`0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5` and release
`f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007`.
The `before/` directory retains twenty byte-exact raw reports and four provenance
files. The predecessor's twenty-one source manifest entries were verified against
their published Git objects. Seven historical Node fixture files are also copied
unchanged. No old expectation, source fingerprint, observed failure, stderr,
unknown row field or raw health flag is rewritten.

The retained reports contain 4,396 cases and 540 controls, with 4,298 and 516
healthy respectively. These totals are reconstructed from the actual reports.
The loss policy permits only the two position `represented_complete_key_order`
case modes and its four `represented-node-order-positive`/`wrong` controls. The
complete six before rows are bound in `anticipated-inventory-changes.json`.
Cases must become runtime Error/Error failures; controls must fail their old
prerequisites with TypeError/TypeError and false match, partner and verified
flags. Thirty-six older unhealthy inventory rows are bound separately. Every
other established complete row, including those earlier failures, must remain
exact. There is no historical-health waiver.

The accepted future comparison therefore requires 4,394 exact case rows and
536 exact control rows, with 4,296/512 healthy. The new clone profile must gain
all 34 case modes and twelve feature controls from the actual root-run baseline
of zero matching cases and four healthy common controls. The four common
controls must remain exact, resulting in 34/16 healthy. The new 31-key inventory
case and its same-mode positive/wrong pair must pass independently. These are
acceptance rules, not candidate observations. Seven historical inventory jobs
and the aggregate are expected to retain exit one across twenty-one jobs; no
candidate job has run as part of this preparation.

The comparator preserves complete raw rows. Its ten helper function ASTs are
identical to the published position reader: hashing/read/require, underlying
row, identity, input projection, health, complete comparison, control retrieval
and before-input verification. Changes in the other three functions are only
the new-profile baseline path, output identity and output filename. Profile
population adds established position plus new clone. The classifier retains
exact observation requirements, duplicate and drift refusal, current-report
hash/binary cross-bindings and healthy current-oracle requirements. Original
readers, policy and unified differences are retained under `originals/` and in
the two `.diff` files.

The original execution location remains fixed for replay:
`/tmp/eris-node-clone-preparation-1/replay/replay.py`. The comparator and classifier
remain here; their artifact root is their parent directory. Current report paths
are `../clone-before.json` and future `../clone-after.json`; output paths are
`../clone-comparison.json` and `../inventory-classification.json`. Raw historical
copies are located here in `before/`, not at a prior increment's generic path.

`compare-clone.py` intentionally has the pending sentinel
`PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST`. After root's source review, bind
the complete actual baseline/command/log/review, fixed replay/fixture/history,
scope/base and current preparation inputs in `compare-clone-inputs.json`.
Preserve this pending helper and readiness before replacing exactly its sentinel
with that manifest's actual hash. Record the one-string transformation and run
both final `--verify-before` commands before candidate replay. Candidate release,
source and Runtime group pins remain absent; none has been guessed.

The classifier's current `--verify-before` mode reads only already-frozen policy
and published reports. The generator performs byte copies, JSON arithmetic,
Python AST comparisons and read-only Git checks. Neither imports or invokes a
JavaScript engine, compiler, parser, adapter or replay runner. A later result
auditor must read these actual pending and additive final readiness schemas;
there is no unrelated generic comparison manifest.
