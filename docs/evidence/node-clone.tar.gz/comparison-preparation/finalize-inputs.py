"""Bind real baseline/replay inputs; replace one pending digest, data only."""
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parent
ROOT = P.parent
REPLAY = Path('/tmp/eris-node-clone-preparation-1/replay')
SCOPE = REPLAY.parent
TOKEN = 'PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def record(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def write(path, raw):
    with path.open('xb') as stream:
        stream.write(raw)


def save(path, value):
    write(path, (json.dumps(value, indent=2) + '\n').encode())


hold_path = P / 'source-ready-pending-inputs.json'
assert sha(hold_path.read_bytes()) == '9d43fd29610fcfbd32df1e3f1cbfacce1883af49d624bc5968f6feffa1b716e3'
hold = json.loads(hold_path.read_text())
for row in hold['files']:
    assert record(Path(row['path'])) == row, row['path']
review = SCOPE / 'root/comparison-source-review.json'
assert sha(review.read_bytes()) == '57c1cc953ae4617ec247dee453c2c28182843e02342ae3fa81524947cbdc3457'

# Retain the original hold and every held top-level file before the one change.
# Historical report/source copies remain untouched in their bound subdirectories.
original = P / 'input-manifest-correction/initial'
original.mkdir(parents=True)
write(original / hold_path.name, hold_path.read_bytes())
for row in hold['files']:
    path = Path(row['path'])
    if path.parent == P:
        write(original / path.name, path.read_bytes())
old = (P / 'compare-clone.py').read_bytes()
assert old.count(TOKEN.encode()) == 1
assert sha(old) == '06e22c8a534676016dcc6ac81caab00d67dead88c0dbed45877c7bb730b10fb3'
before_path = ROOT / 'clone-before.json'
before = json.loads(before_path.read_text())
matrix = json.loads((REPLAY / 'replay-matrix.json').read_text())
assert sha(before_path.read_bytes()) == '33c3314f0a83ffebbb4e4b83117b55f74ebaea04916e29d72ff169b26e2e4166'
assert before['binary_sha256'] == 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'
assert not before['binding_failures']
assert len(before['cases']) == 34 and len(before['controls']) == 16
assert sum(row['matches_expectation'] is True for row in before['cases']) == 0
assert sum(row['verified'] is True for row in before['controls']) == 4
assert before['matrix_sha256'] == sha((REPLAY / 'replay-matrix.json').read_bytes())
for key in ['fixture_sha256', 'inventory_sha256', 'replay_sha256', 'runner_sha256', 'bounds', 'bound_inputs']:
    assert before[key] == matrix[key]
actual = {row['id']: row for row in before['cases'] + before['controls']}
assert len(actual) == 50 and set(actual) == {row['id'] for row in matrix['rows']}
for identity in matrix['rows']:
    row = actual[identity['id']]
    assert all(row[key] == value for key, value in identity.items())

paths = [ROOT / name for name in ['base.json', 'run-baseline.py', 'baseline-execution.json',
         'baseline-review.json', 'baseline.log', 'clone-before.json',
         'replay-preparation-1.json', 'replay-preparation-1.log',
         'comparison-preparation-1.json', 'comparison-preparation-1.log']]
paths += [P / name for name in ['before-comparison-inputs.json', 'anticipated-inventory-changes.json',
          'historical-fixtures.json', 'inert-verification.json', 'classifier-verify-before.json',
          'classifier-verify-before.log', 'classify-inventory.py']]
paths += [REPLAY / name for name in ['source-ready.json', 'replay.py', 'replay-inputs.json',
          'replay-matrix.json', 'preparation-history.json', 'driver-transformation.json',
          'inert-verification.json', 'published-source-verification.json']]
paths += [SCOPE / name for name in ['root/comparison-source-review.json', 'root/replay-source-review.json',
          'root/independent-source-review.json', 'root/published-base.json', 'root/selected-scope.md',
          'root/plan-acceptance.json', 'independent/layout-source-review.json',
          'independent/source-ready.json', 'independent/cases.js', 'independent/controls.json',
          'independent/inventory.json']]
ready = json.loads((REPLAY / 'source-ready.json').read_text())
for row in ready['files']:
    assert record(Path(row['path'])) == row
paths += [Path(row['path']) for row in ready['files']]
for row in matrix['bound_inputs']:
    assert record(Path(row['path'])) == row
paths += [Path(row['path']) for row in matrix['bound_inputs']]
paths += [P / 'historical-fixtures' / name for name in [
    'node-constants.js', 'node-normalize.js', 'node-predicates.js', 'node-root.js',
    'node-equality.js', 'node-connected.js', 'node-position.js']]
files = []
for path in dict.fromkeys(paths):
    entry = record(path)
    if path.is_relative_to(ROOT):
        entry['path'] = str(path.relative_to(ROOT))
    files.append(entry)
config = dict(base='0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5',
              baseline_release_sha256=before['binary_sha256'],
              established_cases=4396, established_controls=540, new_cases=34, new_controls=16,
              files=files, candidate_release=None, candidate_source_manifest=None,
              candidate_runtime_group_count=None,
              note='Actual artifact-relative or fixed absolute preparation paths; original replay location retained. No generic inherited manifest or candidate pins presumed.')
save(P / 'compare-clone-inputs.json', config)
new_hash = sha((P / 'compare-clone-inputs.json').read_bytes())
new = old.replace(TOKEN.encode(), new_hash.encode())
assert new.replace(new_hash.encode(), TOKEN.encode()) == old
(P / 'compare-clone.py').write_bytes(new)
receipt = dict(status='Exact one-sentinel comparator binding after actual published baseline; comparison/health logic unchanged',
               before=record(original / 'compare-clone.py'), after=record(P / 'compare-clone.py'),
               original_hold=record(original / 'source-ready-pending-inputs.json'),
               input_manifest=record(P / 'compare-clone-inputs.json'),
               root_source_review=record(review), substitution=dict(before=TOKEN, after=new_hash),
               reverse_byte_exact=True, binding_files=len(files), baseline=record(before_path),
               baseline_counts=dict(cases=34, case_matches=0, controls=16, healthy_controls=4),
               execution=dict(engine=False, compiler=False, js_parser=False, comparator_run=False))
save(P / 'input-manifest-correction/receipt.json', receipt)
print(json.dumps(dict(comparator=record(P / 'compare-clone.py'),
                     manifest=record(P / 'compare-clone-inputs.json'),
                     receipt=record(P / 'input-manifest-correction/receipt.json'),
                     binding_files=len(files)), indent=2))
