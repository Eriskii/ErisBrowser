"""Copy published reports and freeze comparison policy; never run an engine."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
ROOT = OUT.parent
OLD = Path('/tmp/eris-node-position-1')
PRIOR = OLD / 'comparison-preparation'
PREP = Path('/tmp/eris-node-clone-preparation-1')
REPO = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE = '0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5'
RELEASE = 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'
PENDING = 'PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def row(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def write(path, data):
    with path.open('xb') as stream:
        stream.write(data)


def jsave(path, value):
    write(path, (json.dumps(value, indent=2) + '\n').encode())


def controls(report):
    return report.get('controls', report.get('harness_preflight', []))


def health(record):
    if 'result' in record:
        return record.get('verified') is True and record['result'].get('status') == record['expected']
    if 'expected_observation' in record:
        observation = record.get('observation', {})
        return (isinstance(observation, dict)
                and all(observation.get(k) == v for k, v in record['expected_observation'].items())
                and record.get('matches_expectation') is True
                and record.get('verified', True) is True
                and record.get('verified_with_protocol_prerequisite', True) is True)
    return record.get('status') == 'passed'


def identity(record):
    record = record.get('result', record)
    return record['id'], record.get('mode', '')


old_comparator = (PRIOR / 'compare-position.py').read_text()
old_tree = ast.parse(old_comparator)
specs = next(ast.literal_eval(node.value) for node in old_tree.body
             if isinstance(node, ast.Assign)
             and any(isinstance(n, ast.Name) and n.id == 'SPECS' for n in node.targets))
assert len(specs) == 20 and specs[-1] == ('node-position', 'position-after.json', 32, 16, 'new')
(OUT / 'before').mkdir()
(OUT / 'originals').mkdir()
files, reports, totals = [], {}, Counter()
for profile, filename, count, control_count, _ in specs:
    original = OLD / filename
    raw = original.read_bytes()
    report = json.loads(raw)
    assert report['binary_sha256'] == RELEASE and not report.get('binding_failures')
    assert len(report['cases']) == count and len(controls(report)) == control_count
    assert len({identity(r) for r in report['cases']}) == count
    assert len({identity(r) for r in controls(report)}) == control_count
    destination = OUT / 'before' / filename
    write(destination, raw)
    files.append(dict(path=str(destination.relative_to(ROOT)), original=str(original), bytes=len(raw), sha256=sha(raw)))
    reports[profile] = report
    totals.update(cases=count, controls=control_count,
                  healthy_cases=sum(map(health, report['cases'])),
                  healthy_controls=sum(map(health, controls(report))))
assert dict(totals) == dict(cases=4396, controls=540, healthy_cases=4298, healthy_controls=516)
for filename in ['release.json', 'candidate-source-final.json', 'position-comparison.json', 'inventory-classification.json']:
    original = OLD / filename
    raw = original.read_bytes()
    destination = OUT / 'before' / filename
    write(destination, raw)
    files.append(dict(path=str(destination.relative_to(ROOT)), original=str(original), bytes=len(raw), sha256=sha(raw)))
source = json.loads((OLD / 'candidate-source-final.json').read_text())
assert len(source['files']) == 21
for entry in source['files']:
    raw = subprocess.check_output(['git', 'show', BASE + ':' + entry['path']], cwd=REPO)
    assert len(raw) == entry['bytes'] and sha(raw) == entry['sha256']
jsave(OUT / 'before-comparison-inputs.json', dict(
    base=BASE, release_sha256=RELEASE, files=files,
    established_cases=totals['cases'], established_controls=totals['controls'],
    healthy_cases=totals['healthy_cases'], healthy_controls=totals['healthy_controls'],
    source_manifest=dict(path='comparison-preparation/before/candidate-source-final.json',
                         historical_manifest_base=source['base'], public_base=BASE,
                         all21_public_source_paths_verified=True),
    note='20 exact published position raw profiles plus4 provenance files; no row, source or health rewriting'))

old_policy = json.loads((PRIOR / 'anticipated-inventory-changes.json').read_text())
current = reports['node-position']
anticipated = []
for kind, ids in [
    ('cases', ['represented_complete_key_order#sloppy', 'represented_complete_key_order#strict']),
    ('controls', ['represented-node-order-positive#sloppy', 'represented-node-order-positive#strict',
                  'represented-node-order-wrong#sloppy', 'represented-node-order-wrong#strict'])]:
    for ident in ids:
        found = [r for r in current[kind] if r['id'] == ident]
        assert len(found) == 1 and health(found[0])
        before = found[0]
        anticipated.append(dict(kind=kind, id=ident, mode=before['mode'], before=before,
                                expected_after_observation=dict(status='exception', phase='runtime',
                                    error_type='Error' if kind == 'cases' else 'TypeError',
                                    error_identity='Error' if kind == 'cases' else 'TypeError')))
older = []
for previous in old_policy['already_unhealthy_unchanged']:
    actual = [r for r in reports[previous['profile']][previous['kind']]
              if identity(r) == (previous['id'], previous['mode'])]
    assert actual == [previous['before']] and not health(actual[0])
    older.append(previous)
for previous in old_policy['rows']:
    actual = [r for r in reports[old_policy['profile']][previous['kind']]
              if identity(r) == (previous['id'], previous['mode'])]
    assert len(actual) == 1 and not health(actual[0])
    assert all(actual[0]['observation'].get(k) == v for k, v in previous['expected_after_observation'].items())
    older.append(dict(profile=old_policy['profile'], filename='connected-after.json',
                      kind=previous['kind'], id=previous['id'], mode=previous['mode'], before=actual[0]))
assert len(older) == 36 and len(anticipated) == 6
policy = dict(profile='node-position',
              reason='Ordinary cloneNode invalidates the former complete30-key inventory. Preserve exact old expectations, complete observations and raw health; annotate only these six anticipated losses.',
              rows=anticipated, already_unhealthy_unchanged=older)
jsave(OUT / 'anticipated-inventory-changes.json', policy)
policy_sha = sha((OUT / 'anticipated-inventory-changes.json').read_bytes())

comparator = old_comparator
changes = [
    ("INPUTS = HERE / 'comparison-preparation/compare-position-inputs.json'", "INPUTS = HERE / 'comparison-preparation/compare-clone-inputs.json'"),
    ("INPUT_SHA = '2cea0c2c100189b0300acd358bf1706e355140c9424ebdfd9b78162088f428f4'", "INPUT_SHA = '" + PENDING + "'"),
    ("('node-position', 'position-after.json', 32, 16, 'new'),", "('node-position', 'position-after.json', 32, 16, 'established'),\n    ('node-clone', 'clone-after.json', 34, 16, 'new'),"),
    ("if name == 'node-position':", "if name == 'node-clone':"),
    ('complete-node-position-replay-comparison', 'complete-node-clone-replay-comparison'),
    ("HERE / 'position-comparison.json'", "HERE / 'clone-comparison.json'")]
for before, after in changes:
    assert before in comparator
    comparator = comparator.replace(before, after)
write(OUT / 'compare-clone.py', comparator.encode())
old_classifier = (PRIOR / 'classify-inventory.py').read_text()
classifier = old_classifier
class_changes = [
    ("EXPECTED='94c6769ad8b31eaf5c8e1aa36542e65634ff4f93da74f1f1650a213ca1de8496'", "EXPECTED='" + policy_sha + "'"),
    ("comparison-preparation/before/connected-after.json", "comparison-preparation/before/position-after.json"),
    ("len(policy['already_unhealthy_unchanged'])==30", "len(policy['already_unhealthy_unchanged'])==36"),
    ("B/'position-comparison.json'", "B/'clone-comparison.json'"),
    ("['node-constants','node-normalize','node-predicates','node-root','node-equality']", "['node-constants','node-normalize','node-predicates','node-root','node-equality','node-connected']"),
    ("('cases',4268,4266),('controls',504,500)", "('cases',4298,4296),('controls',516,512)"),
    ("('cases',4364,2),('controls',524,4)", "('cases',4396,2),('controls',540,4)"),
    ("('cases',32,0),('controls',16,4)", "('cases',34,0),('controls',16,4)"),
    ("B/'position-after.json'", "B/'clone-after.json'"),
    ("x['profile']=='node-position'", "x['profile']=='node-clone'"),
    ('Six connected inventory assumptions are invalidated by compareDocumentPosition. Older Nodeconstant, Normalize, Predicate, root and equality inventory failures remain unchanged.',
     'Six position inventory assumptions are invalidated by ordinary cloneNode. Older Nodeconstant, Normalize, Predicate, root, equality and connected inventory failures remain unchanged.'),
    ("'new_cases_healthy':32", "'new_cases_healthy':34")]
for before, after in class_changes:
    assert before in classifier
    classifier = classifier.replace(before, after)
write(OUT / 'classify-inventory.py', classifier.encode())
for filename, raw in [('compare-position.py', old_comparator.encode()),
                      ('classify-inventory.py', old_classifier.encode()),
                      ('anticipated-inventory-changes.json', (PRIOR / 'anticipated-inventory-changes.json').read_bytes()),
                      ('prepare-position-comparison.py', (PRIOR / 'prepare-comparison.py').read_bytes())]:
    write(OUT / 'originals' / filename, raw)
for name, old, new in [('comparator', old_comparator, comparator), ('classifier', old_classifier, classifier)]:
    write(OUT / (name + '.diff'), ''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
          fromfile='position/' + name, tofile='clone/' + name)).encode())


def functions(src):
    return {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(src).body if isinstance(n, ast.FunctionDef)}


f0, f1 = functions(old_comparator), functions(comparator)
same = [name for name in f0 if f0[name] == f1[name]]
assert same == ['sha', 'read', 'require', 'underlying', 'identity', 'input_record', 'healthy', 'compare_rows', 'controls', 'verify_before']
assert sorted(name for name in f0 if f0[name] != f1[name]) == ['before_path', 'compare', 'main']
ast.parse(classifier)
baseline = ROOT / 'clone-before.json'
assert sha(baseline.read_bytes()) == '33c3314f0a83ffebbb4e4b83117b55f74ebaea04916e29d72ff169b26e2e4166'
before = json.loads(baseline.read_text())
assert before['binary_sha256'] == RELEASE and not before['binding_failures']
assert len(before['cases']) == 34 and len(before['controls']) == 16
assert sum(map(health, before['cases'])) == 0 and sum(map(health, before['controls'])) == 4
jsave(OUT / 'inert-verification.json', dict(
    status='passed source/JSON/hash checks; no candidate reports exist or were compared',
    counts=dict(totals), established_profiles=20, future_profiles=21,
    exact_report_copies=20, provenance_copies=4, anticipated_new_case_losses=2,
    anticipated_new_unhealthy_controls=4, older_unhealthy_inventory_rows=36,
    identical_comparator_function_asts=same,
    future_exact_rows=dict(cases=4394, controls=536),
    future_healthy_counts=dict(cases=4296, controls=512),
    new_expected=dict(cases=34, controls=16), baseline=row(baseline),
    baseline_actual=dict(cases=34, controls=16, healthy_cases=0, healthy_controls=4),
    files=[row(OUT / name) for name in ['compare-clone.py', 'classify-inventory.py', 'anticipated-inventory-changes.json', 'before-comparison-inputs.json']],
    execution=dict(python_ast=True, json_hash_arithmetic=True, comparator_import_or_run=False,
                   classifier_import_or_run=False, js_parser=False, engine=False, compiler=False)))
known = [OUT / 'before-comparison-inputs.json', OUT / 'anticipated-inventory-changes.json',
         ROOT / 'clone-before.json', ROOT / 'baseline-execution.json', ROOT / 'baseline-review.json']
jsave(OUT / 'compare-clone-inputs-pending.json', dict(
    status='Pending final before-input binding after root source review; not the runnable final manifest',
    base=BASE, baseline_release_sha256=RELEASE, established_cases=4396,
    established_controls=540, new_cases=34, new_controls=16,
    files=[dict(path=str(p.relative_to(ROOT)), bytes=p.stat().st_size, sha256=sha(p.read_bytes())) for p in known],
    candidate_release=None, candidate_source_manifest=None, candidate_runtime_group_count=None,
    pending=['Final baseline command/log/review and original replay readiness/history/peer binding set',
             'Final input manifest SHA replaces the held comparator sentinel once, preserving original source',
             'Candidate release, source and validation results remain absent; do not infer pins or counts']))
print(json.dumps(dict(status='held pending final binding', totals=dict(totals),
                     new_policy_rows=len(anticipated), older_policy_rows=len(older),
                     comparator=row(OUT / 'compare-clone.py'), classifier=row(OUT / 'classify-inventory.py'),
                     policy=row(OUT / 'anticipated-inventory-changes.json')), indent=2))
