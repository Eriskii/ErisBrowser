"""Source-only reader update for the exact held Object.hasOwn addition."""
from pathlib import Path
import json, hashlib, difflib
H=Path(__file__).resolve().parent
B=H.parent
old=(H/'audit-results.py').read_text()
s=old
s=s.replace("        receipt = json.loads(bound(spec['receipt']))\n        if spec['schema'] == 'literal_files':", """        if spec['schema'] == 'object_has_own_scope':
            held = json.loads(bound(spec['hold']))
            require(spec['hold']['sha256'] == '7e1aa00438332fb7343fb4d75b7ce656fc9f2209ff1c3f5d270d3336b6fa20d0',
                    'exact additional production source hold')
            expected = {'src/script.rs', 'src/script/dom_prototypes.rs', 'src/script/object_has_own.rs',
                        'src/script/object_has_own/tests.rs', 'tests/fixtures/object-has-own.js'}
            require(held['source_count'] == 5 and {r['path'] for r in held['files']} == expected,
                    'only five authorized additional-scope source paths')
            for row in held['references']: bound(row)
            before_manifest = json.loads(bound(spec['before']))
            before_rows = {r['path']: r for r in before_manifest['files']}
            for row in before_manifest['files']:
                data = bound(row, B / 'object-has-own/before')
                if row['path'] in staged:
                    require(staged[row['path']] == data, 'scope before image continues existing source')
                if row['path'] not in expected:
                    require(data == raw('worktree/' + row['path']), 'unchanged hasOwn dependency drift')
            require(set(spec['seams']) == {'src/script.rs', 'src/script/dom_prototypes.rs'}, 'exact two changed existing paths')
            for row in held['files']:
                p = row['path']; after = bound({**row, 'path': row['held']})
                if p in spec['seams']:
                    require(p in staged and p in before_rows, 'existing seam is present in original hold')
                    data = staged[p]
                    for change in spec['seams'][p]:
                        left, right = change['before'].encode(), change['after'].encode()
                        require(data.count(left) == 1 and left != right, 'unique exact additional-scope seam')
                        data = data.replace(left, right)
                    require(data == after, 'only reviewed seam bytes differ')
                else:
                    require(p not in staged and p not in before_rows, 'three fresh additional-scope files')
                staged[p] = after; changed.add(p)
            continue
        receipt = json.loads(bound(spec['receipt']))
        if spec['schema'] == 'literal_files':""")
s=s.replace("'storage_focused_label', 'focused_summary', 'full_runs', 'gates',", "'storage_focused_label', 'has_own_focused_label', 'focused_summary', 'full_runs', 'gates',")
s=s.replace("'retained_failure_runs', 'retained_non_test_failures', 'source_corrections', 'bootstrap_diagnostic']", "'retained_failure_runs', 'retained_non_test_failures', 'source_corrections', 'bootstrap_diagnostics', 'has_own_inventory']")
s=s.replace("    all_new = filtered_new | {storage}\n    require(len(filtered_new) == 48 and len(all_new) == 49, '49 new groups, 48 match node_clone')", """    all_clone = filtered_new | {storage}
    require(len(filtered_new) == 48 and len(all_clone) == 49, '49 clone groups, 48 match node_clone')
    own_inventory = json.loads(bound(PLAN['has_own_inventory']))
    own_source = raw('worktree/src/script/object_has_own/tests.rs').decode()
    own_direct = re.findall(r'^#\\[test\\]\\nfn (\\w+)\\(', own_source, re.M)
    own_fixture = read('object-has-own/independent/inventory.json')
    own_macro = re.search(r'^cases!\\((.*?)\\);', own_source, re.M | re.S)
    require(own_direct == own_inventory['direct_names'] and len(own_direct) == own_inventory['direct_groups'] == 9 and
            own_inventory['independent_names'] == own_fixture['cases'] and own_inventory['independent_groups'] == 8 and
            own_inventory['independent_modes'] == 16 and own_inventory['new_groups'] == 17,
            'additional17 Object.hasOwn groups, separate from clone49')
    require(own_macro is not None and [n.strip() for n in own_macro.group(1).split(',') if n.strip()] == own_fixture['cases'],
            'Object.hasOwn exact independent macro names')
    own_names = {'script::object_has_own::tests::' + n for n in own_direct + own_fixture['cases']}
    all_new = all_clone | own_names
    require(len(all_new) == 66 and not all_clone & own_names, 'disjoint49 plus17 group identities')""")
s=s.replace("observed == [1, 0, 0] and '--exact' in rec['command']", "observed == [1, 0, 0] and dom['exact_storage_test'] in rec['command']")
s=s.replace("                    'separate exact-storage test')\n        focus.update", """                    'separate exact-storage test')
        if label == PLAN['has_own_focused_label']:
            require(names == own_names and observed == [17, 0, 0], 'all additional Object.hasOwn groups')
        focus.update""")
s=s.replace("'all49 new groups observed successfully'", "'all66 new groups observed successfully'")
s=s.replace("receipt[summary['new_groups_key']] == 49", "receipt[summary['new_groups_key']] == 66")
s=s.replace("        failures.append(dict(label=spec['label']", "        require(all(literal in _ for literal in spec.get('required_literals', [])), 'retained failure diagnostic')\n        failures.append(dict(label=spec['label']")
# Above tests() assigns its log to _, retaining the exact original bytes as text.
a=s.index("    diagnostic = PLAN['bootstrap_diagnostic']")
z=s.index('    gates = {}',a)
s=s[:a]+"""    diagnostics = PLAN['bootstrap_diagnostics']
    require(diagnostics and any(r['stage'] == 'pre-hasOwn' for r in diagnostics) and
            any(r['stage'] == 'final' for r in diagnostics), 'initial and final bootstrap stages remain distinct')
    for row in diagnostics:
        record, log = command('validation/' + row['label'] + '.json', row['exit'])
        require(row['literal'] in log, 'actual announced diagnostic from its original stage')
"""+s[z:]
s=s.replace("'all49 new groups in each full suite'", "'all66 new groups in each full suite'")
s=s.replace('return dict(full=full, new_groups=49, node_clone_filter_groups=48', 'return dict(full=full, new_groups=66, clone_groups=49, additional_Object_hasOwn_groups=17, node_clone_filter_groups=48')
s=s.replace('bootstrap_diagnostic=diagnostic, serial_status_wraps=wraps', 'bootstrap_diagnostics=diagnostics, serial_status_wraps=wraps')
s=s.replace("        'symbols', 'array-descriptors', 'reflect-construction', 'comparison', 'classification']}\n    actual_commands", "        'symbols', 'array-descriptors', 'reflect-construction', 'comparison', 'classification']}\n    expected_commands.update(Path(r['path']).name for r in PLAN['has_own_replay']['commands'] if Path(r['path']).name.endswith('-command.json'))\n    actual_commands")

extra='''def has_own_replay():
    """Independent separate16/8 result check; never included in clone21-profile totals."""
    directory = B / 'object-has-own/replay'
    readiness = raw(directory / 'source-ready.json')
    require(hashlib.sha256(readiness).hexdigest() ==
            '9af3cd5796b5404073ecc9cfcdbfb211897ddc1c758ea9df10aad06ccc0f45e1', 'frozen standalone replay hold')
    for row in json.loads(readiness)['files']: bound(row)
    fixture = raw(directory / 'independent/cases.js')
    require(fixture == raw('object-has-own/independent/cases.js') == raw('worktree/tests/fixtures/object-has-own.js') and
            hashlib.sha256(fixture).hexdigest() == '4cfdacc069d83792f20d4be1efec38b91ab748114eadef1b04c46e306ce3053f',
            'unchanged global-script standalone fixture')
    inventory = read(directory / 'replay-inputs.json')
    matrix = read(directory / 'replay-matrix.json')
    require(inventory['collection'] == 'objectHasOwnCases' and inventory['case_modes'] == 16 and
            inventory['control_modes'] == 8 and inventory['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True},
            'standalone literal mode contract')
    meta = dict(flags=[], features=[], includes=[], locale=[], negative=None)
    identities = []
    positives = {r['name']: r for r in inventory['controls'] if r['positive']}
    for kind, rows in [('case', inventory['cases']), ('control', inventory['controls'])]:
        for row in rows:
            require(row['modes'] == ['sloppy', 'strict'], 'standalone frozen modes')
            expected = dict(status='complete', phase='runtime', error_type='', error_identity='') if kind == 'case' or row['positive'] else dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
            require(row['expected_observation'] == expected, 'standalone fixed ordinary/wrong expectations')
            if kind == 'control':
                positive = positives[row['pair'] + '-positive']
                require(row['source'] == positive['source'] + ('' if row['positive'] else "throw new Error('deliberately wrong expectation');"),
                        'standalone exact positive prefix')
            for mode in row['modes']:
                body = (fixture + b'\\nif(objectHasOwnCases.' + row['name'].encode() +
                        (b'(true)' if mode == 'strict' else b'(false)') + b' !== true) throw new Error("case did not return true");'
                        if kind == 'case' else row['source'].encode())
                source_sha = hashlib.sha256(body).hexdigest()
                fingerprint = dict(source_sha256=source_sha, mode=mode, metadata=meta, harness=[])
                identity = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind, source_sha256=source_sha,
                                case_sha256=hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=True).encode()).hexdigest(),
                                expected_observation=expected)
                if kind == 'control': identity.update(pair=row['pair'], positive=row['positive'], area=row['area'], partner=row['pair'] + '-positive#' + mode)
                identities.append(identity)
    require(len(identities) == 24 and identities == matrix['rows'], 'standalone independent24-row reconstruction')
    for row in matrix['bound_inputs']: bound(row)
    spec = PLAN['has_own_replay']
    before = json.loads(bound(spec['before'])); after = json.loads(bound(spec['after']))
    for report, binary in [(before, BASE_BINARY), (after, CANDIDATE)]:
        require(report['binary_sha256'] == binary and not report['binding_failures'] and
                report['matrix_sha256'] == hashlib.sha256(raw(directory / 'replay-matrix.json')).hexdigest(),
                'standalone raw binary, matrix and failure binding')
        for field in ['fixture_sha256','inventory_sha256','replay_sha256','runner_sha256','bounds','bound_inputs']:
            require(report[field] == matrix[field], 'standalone raw source/header binding')
        actual = report['cases'] + report['controls']
        require(len(actual) == 24 and [{k:r[k] for k in frozen} for r,frozen in zip(actual,identities)] == identities,
                'standalone complete source-bound rows')
        controls = {r['id']:r for r in report['controls']}
        for row in report['controls']:
            partner = controls[row['partner']]
            require(partner['positive'] is True and partner['mode'] == row['mode'] and partner['pair'] == row['pair'], 'standalone same-mode positive')
            matches = lambda r: isinstance(r.get('observation'),dict) and all(r['observation'].get(k)==v for k,v in r['expected_observation'].items())
            require(row['matches_expectation'] is matches(row) and row['positive_partner_matches'] is matches(partner) and
                    row['verified'] is (matches(row) and matches(partner)), 'standalone independently checked negative health')
    summaries = {}
    for kind, total, before_healthy in [('cases',16,0),('controls',8,4)]:
        stats, changes = complete_rows(before[kind], after[kind])
        require(stats['before_total'] == stats['after_total'] == stats['after_healthy'] == total and
                stats['before_healthy'] == before_healthy and stats['gains'] == total-before_healthy and
                stats['unchanged'] == before_healthy and stats['losses'] == stats['other_changes'] == 0,
                'separate standalone gains and unchanged common controls')
        summaries[kind] = dict(stats=stats, changes=changes)
    require(len(spec['commands']) == 2, 'standalone baseline and candidate commands')
    for row, report, binary, expected_exit in zip(spec['commands'], [before,after], [BASE_BINARY,CANDIDATE], [1,0]):
        bound(row)
        rec, _ = command(row['path'], expected_exit)
        output = spec['before'] if expected_exit else spec['after']
        require(rec['command'] == ['python3', str(directory / 'replay.py'), report['binary'], binary, output['path']],
                'actual standalone fixed-driver command')
    return dict(separate_from_clone_comparison=True, case_modes=16, control_modes=8, summary=summaries)


'''
s=s.replace('def main():',extra+'def main():')
s=s.replace("        report['comparison'] = comparisons()", "        require(PLAN.get('has_own_replay') is not None, 'standalone result plan pending')\n        report['comparison'] = comparisons()\n        report['Object_hasOwn'] = has_own_replay()")
(H/'audit-results.py').write_text(s)
(H/'object-has-own-expansion/reader.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),'held-draft1/audit-results.py','expanded/audit-results.py')))
print(json.dumps(dict(source_sha256=hashlib.sha256(s.encode()).hexdigest(),complete_audit_executed=False)))
