"""Source-only adaptation. No result reader, engine or compiler is invoked."""
from pathlib import Path
import hashlib, json, difflib

HERE = Path(__file__).resolve().parent
B = HERE.parent
P = Path('/tmp/eris-node-clone-preparation-1')
old = (HERE/'inherited/position-audit-results.py').read_text()
s = old.replace('Position preparation derived from the corrected connected audit.',
                'Clone preparation derived from the held position audit.')
s = s.replace("BASE_BINARY = 'd9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'",
              "BASE_BINARY = 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'")
s = s.replace('/tmp/eris-node-position-preparation-1', str(P))

def section(start, end, replacement):
    global s
    a, b = s.index(start), s.index(end, s.index(start))
    s = s[:a] + replacement.rstrip() + '\n\n\n' + s[b:]

frozen = s[s.index('def frozen_inputs():'):s.index('def validation():')]
frozen = frozen.replace("'e72d5ed28b6a2d5f85844221e97d4f17f450a9715b483617e405acf6bb0ee10a'", "'6e995add31fe991143d364fb79b2efab4bd839352a9f3850e735ad3cb624dad0'")
frozen = frozen.replace("'browser/source-ready.json', '8af1582c7dfaffcda0df53dec1d6a38b6353d860e83dd228889597947f1ca7a2'", "'browser/source-ready-2.json', '7afdb720ae1be673a0428983ec1aabf68ab268d5d3aa7e4f4b68c3a4880dd3b6'")
frozen = frozen.replace("'4a5bc81f3f6433d8e1d5c3c33b6a6a79f1891145d89b4dc0c49f7ab75d7d38f7'", "'e29a256d2d737876577b8dad14e3fa1df0258c820832a41aebc0a140043e605b'")
frozen = frozen.replace('97855d380d9a18edbef4fd0c317ac5430265d78d07f9adeb5511542fcbb84575','bf66956a6ca0e1ef138a2d634ab3c31968754415f04c4b2197a2b07e9ec63479')
frozen = frozen.replace('nodePositionCases','nodeCloneCases').replace('node-position','node-clone').replace('node_position','node_clone')
frozen = frozen.replace("'node-equality.js', 'node-connected.js']", "'node-equality.js', 'node-connected.js', 'node-position.js']")
frozen = frozen.replace("len(inv['cases']) == 16", "len(inv['cases']) == 17")
frozen = frozen.replace("inv['literal_prototype_total'] == 30", "inv['literal_prototype_total'] == 31")
frozen = frozen.replace("len(inv['literal_prototype_string_keys']) == 29", "len(inv['literal_prototype_string_keys']) == 30")
frozen = frozen.replace("['literal_prototype_string_keys'][:10]", "['literal_prototype_string_keys'][:11]")
frozen = frozen.replace("'normalize', 'isEqualNode'", "'normalize', 'cloneNode', 'isEqualNode'")
frozen = frozen.replace('len(identities) == 48', 'len(identities) == 50')
frozen = frozen[:frozen.index("    for name in ['node-clone.html'")] + '''    for name in ['node-clone.html', 'node_clone.rs']:
        relative = 'tests/fixtures/' + name if name.endswith('.html') else 'tests/support/' + name
        require(raw(PREP / 'browser' / name) == raw('worktree/' + relative), 'browser source unchanged: ' + name)
    browser = read(PREP / 'browser/source-ready-2.json')
    require(browser['literal_population'] == dict(stable_ids=20, copied_graph_nodes=10,
            click_added_nodes=10, clicks=1, phases=2, worker_generation=216), 'frozen clone browser inventory')
    integration = read('browser-integration.json')
    require(integration['source_hold_sha256'] == hashlib.sha256(raw(PREP / 'browser/source-ready-2.json')).hexdigest(),
            'browser integration source hold')
    for row in integration['files']:
        bound(row, B / 'worktree')
    helper = raw(PREP / 'browser/node_clone.rs').decode()
    require('assert_eq!(stable.len(), 20);' in helper and 'stable.extend(originals);' in helper and
            'assert_eq!(stable, initial.stable);' in helper and 'initial.nodes + 10,' in helper and
            '(initial.nodes..initial.nodes + 10).collect::<Vec<_>>()' in helper,
            'literal stable original and fresh copied identity assertions')
    require('["Clone ready", "Clone done"]' in helper and '[0x008000, 0x0000ff][phase]' in helper and
            'reference_html(phase)' in helper, 'frozen literal canvas and metadata')
    return dict(case_modes=34, control_modes=16, matrix_rows=50, explicit_literal_mode_argument=True,
                prototype_keys=31, constructor_keys=21, browser_retained_ids=20, browser_created_nodes=10,
                historical_fixtures_unchanged='Seven prior sources remain retained in the frozen replay')
'''
section('def frozen_inputs():', 'def validation():', frozen)

validation = '''def correction_chain(initial, final):
    """Reconstruct every authorized stage, anchored to the first source hold."""
    staged = {p: raw(Path(PLAN['initial_directory']) / p) for p in initial}
    changed = set()
    for spec in PLAN['source_corrections']:
        receipt = json.loads(bound(spec['receipt']))
        if spec['schema'] == 'literal_files':
            rows = receipt['files']
            require(len(rows) == spec['file_count'] and sum(len(r['changes']) for r in rows) == spec['literal_count'],
                    'exact literal correction population')
            stages = [dict(path=r['path'], before=dict(path=str(Path(spec['before_directory']) / r['path']),
                       sha256=r['before_sha256']), after=dict(path=str(B / 'worktree' / r['path']),
                       sha256=r['after_sha256']), changes=r['changes']) for r in rows]
        elif spec['schema'] == 'before_after':
            require(set(spec['changes'][0]) == {'before', 'after'} and spec['changes'], 'explicit correction bytes')
            stages = [dict(path=spec['path'], before=receipt['before'], after=receipt['after'], changes=spec['changes'])]
        else:
            raise ValueError('unreviewed correction schema')
        for row in stages:
            p = row['path']; before = bound(row['before']); after = bound(row['after'])
            require(p not in staged or staged[p] == before, 'correction must continue exact initial or prior stage: ' + p)
            if p not in staged:
                require(spec.get('admit_added_paths') == [p] or p in spec.get('admit_added_paths', []),
                        'new source path must be explicitly admitted')
            for change in row['changes']:
                left, right = change['before'].encode(), change['after'].encode()
                require(left != right and before.count(left) == 1, 'unique meaningful exact source correction')
                before = before.replace(left, right)
            require(before == after, 'entire corrected file matches enumerated substitutions')
            staged[p] = after; changed.add(p)
    require(staged.keys() == final.keys(), 'only exact enumerated paths added to source hold')
    for p, data in staged.items():
        require(hashlib.sha256(data).hexdigest() == final[p]['sha256'] and len(data) == final[p]['bytes'] and
                data == raw('worktree/' + p), 'unreported final source drift: ' + p)
    return sorted(changed)


def validation():
    """Actual complete counts and final pins are supplied only in a held final plan."""
    required = ['source_population', 'initial_population', 'initial_directory', 'final_directory',
                'runtime_inventory', 'dom_inventory', 'focused_labels', 'new_focused_label',
                'storage_focused_label', 'focused_summary', 'full_runs', 'gates',
                'retained_failure_runs', 'retained_non_test_failures', 'source_corrections', 'bootstrap_diagnostic']
    require(all(PLAN.get(k) is not None for k in required), 'validation plan has unmeasured pending fields')
    source = read('candidate-source-final.json')
    require(INPUTS[str(B / 'candidate-source-final.json')]['sha256'] == SOURCE, 'final source identity')
    current = {r['path']: r for r in source['files']}
    require(len(current) == len(source['files']) == PLAN['source_population'], 'unique final source population')
    for row in source['files']:
        bound(row, B / 'worktree'); bound(row, B / PLAN['final_directory'])
    initial = read('candidate-source-initial.json')
    old = {r['path']: r for r in initial['files']}
    require(len(old) == len(initial['files']) == PLAN['initial_population'] == 27, 'initial source population')
    for row in initial['files']:
        bound(row, B / PLAN['initial_directory'])
    # The initial manifest must match all three independent owner holds, not just a path count.
    owner_rows = {}
    for spec in PLAN['owner_holds']:
        held = json.loads(bound(spec))
        for row in held['files']:
            require(row['path'] not in owner_rows, 'source owner overlap')
            owner_rows[row['path']] = {k: row[k] for k in ['path', 'bytes', 'sha256']}
            if 'held_copy' in row:
                bound({**row, 'path': row['held_copy']})
        for row in held.get('references', []):
            bound(row)
    require(owner_rows == old, 'initial 17 Runtime, 6 DOM, 4 browser source identities')
    corrected_paths = correction_chain(old, current)
    inventory = json.loads(bound(PLAN['runtime_inventory']))
    dom = json.loads(bound(PLAN['dom_inventory']))
    runtime_text = raw('worktree/src/script/node_clone/tests.rs').decode()
    direct = re.findall(r'^#\\[test\\]\\nfn ([A-Za-z_][A-Za-z0-9_]*)\\(', runtime_text, re.M)
    require(direct == inventory['direct_groups'] and len(direct) == inventory['direct_count'] == 12,
            'actual private Runtime test names')
    independent = read(PREP / 'independent/inventory.json')['cases']
    require(inventory['independent_groups'] == independent and inventory['independent_count'] == 17 and
            inventory['independent_modes'] == 34 and inventory['new_runtime_groups'] == 29 and
            inventory['browser_groups_root_owned'] == 2 and inventory['new_runtime_and_browser_groups'] == 31,
            'actual Runtime inventory, DOM groups remain separate')
    macro = re.search(r'^cases!\\((.*?)\\);', runtime_text, re.M | re.S)
    require(macro is not None and [n.strip() for n in macro.group(1).split(',') if n.strip()] == independent,
            'actual macro population matches independent literal names')
    dom_names = re.findall(r'^#\\[test\\]\\nfn ([A-Za-z_][A-Za-z0-9_]*)\\(',
                           raw('worktree/src/dom/node_clone/tests.rs').decode(), re.M)
    require(dom_names == dom['helper_test_names'] and len(dom_names) == dom['helper_groups'] == 17 and
            dom['exact_storage_groups'] == 1 and dom['new_dom_total'] == 18, 'actual private DOM names')
    storage = 'dom::string::tests::' + dom['exact_storage_test']
    require(dom['exact_storage_test'] in re.findall(r'^    #\\[test\\]\\n    fn (\\w+)\\(',
            raw('worktree/src/dom/string.rs').decode(), re.M), 'separate exact-storage test source')
    runtime_names = {'script::node_clone::tests::' + n for n in independent + direct}
    expected_dom = {'dom::node_clone::tests::' + n for n in dom_names}
    browser_names = {'node_clone_copies_exact_graphs_with_fresh_identities',
                     'confined_node_clone_copies_exact_graphs_with_fresh_identities'}
    filtered_new = runtime_names | expected_dom | browser_names
    all_new = filtered_new | {storage}
    require(len(filtered_new) == 48 and len(all_new) == 49, '49 new groups, 48 match node_clone')
    focus = Counter(); focused_commands = {}; wraps = {}; clone_log = None
    for label in PLAN['focused_labels']:
        rec, rows, log, observed = tests(label, 0)
        require('--include-ignored' in rec['command'], 'focused include ignored: ' + label)
        names = {n for n, _ in rows}
        require(len(names) == len(rows), 'unique names within successful focused command')
        if label == PLAN['new_focused_label']:
            require(names == filtered_new and observed == [48, 0, 0], 'complete exact node_clone filter inventory')
            clone_log = log
        if label == PLAN['storage_focused_label']:
            require(names == {storage} and observed == [1, 0, 0] and '--exact' in rec['command'],
                    'separate exact-storage test')
        focus.update(n for n, _ in rows)
        focused_commands[label] = dict(command=rec['command'], totals=observed, test_names=[n for n, _ in rows])
        if rec['serial_status_wraps']: wraps[label] = rec['serial_status_wraps']
    require(clone_log is not None and all_new <= focus.keys(), 'all49 new groups observed successfully')
    # Summary schema is explicitly supplied after the root summary exists; no inferred aliases.
    summary = PLAN['focused_summary']
    receipt = json.loads(bound(summary['binding']))
    require(receipt[summary['observations_key']] == sum(focus.values()) and
            receipt[summary['unique_key']] == len(focus) and receipt[summary['new_groups_key']] == 49,
            'root focus summary independently counted')
    commands = receipt[summary['commands_key']]
    require(len(commands) == len(focused_commands), 'all successful focus commands summarized')
    seen = set()
    for row in commands:
        require(set(row) == set(summary['row_keys']), 'exact actual summary row schema')
        label = Path(row[summary['row_log_key']]).stem
        require(label in focused_commands and label not in seen, 'unique focus summary log')
        seen.add(label)
        require(row[summary['row_passed_key']] == focused_commands[label]['totals'][0] and
                row[summary['row_sha_key']] == INPUTS[str(B / 'validation' / (label + '.log'))]['sha256'],
                'focus literal names and log binding')
    require(seen == focused_commands.keys(), 'all focused receipts retained')
    failures = []; non_test_failures = []
    for spec in PLAN['retained_failure_runs']:
        rec, rows, _, observed = tests(spec['label'], spec['exit'], spec['totals'])
        require(spec['exit'] != 0 and [n for n, status in rows if status == 'FAILED'] == spec['failed_names'],
                'complete retained failed test identities')
        failures.append(dict(label=spec['label'], command=rec['command'], totals=observed,
                             failed_names=spec['failed_names'], log_sha256=rec['sha256']))
        if rec['serial_status_wraps']: wraps[spec['label']] = rec['serial_status_wraps']
    for spec in PLAN['retained_non_test_failures']:
        rec, log = command('validation/' + spec['label'] + '.json', spec['exit'])
        require(spec['exit'] != 0 and all(t in log for t in spec['required_literals']) and
                not re.search(r'^test result:', log, re.M), 'compiler/gate failure retained without invented test result')
        non_test_failures.append(dict(label=spec['label'], command=rec['command'], exit=rec['exit'],
                                     required_literals=spec['required_literals'], log_sha256=rec['sha256']))
    require(receipt[summary['failures_key']] == sum(r['totals'][1] for r in failures), 'failed test observations retained')
    diagnostic = PLAN['bootstrap_diagnostic']
    require(diagnostic['literal'] in clone_log, 'actual announced bootstrap literal')
    for label in diagnostic['other_logs']:
        require(diagnostic['literal'] in raw('validation/' + label + '.log').decode(), 'additional diagnostic observation')
    gates = {}
    for label in PLAN['gates']:
        rec, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(rec['command'][-2:] == ['-D', 'warnings'] and '--all-targets' in rec['command'], 'strict Clippy')
        if label.startswith('release'):
            require('--release' in rec['command'] and '--bin' in rec['command'] and 'eris-js' in rec['command'], 'release build')
        gates[label] = rec['command']
    full = {}
    for spec in PLAN['full_runs']:
        rec, rows, _, observed = tests(spec['label'], 0, [spec['passed'], 0, 0])
        argv = rec['command']
        require('--include-ignored' in argv and '--test-threads=4' in argv, 'full command flags')
        require(all_new <= {n for n, _ in rows}, 'all49 new groups in each full suite')
        if spec['feature']:
            require('--features' in argv and spec['feature'] in argv, 'native feature')
        else: require('--features' not in argv, 'default feature')
        full[spec['label']] = dict(command=argv, totals=observed)
    require(len(full) == 2 and {r['feature'] for r in PLAN['full_runs']} == {None, 'vulkan-raster'}, 'both full suites')
    permitted = set(PLAN['focused_labels'] + PLAN['gates'] + list(full) +
                    [r['label'] for r in failures + non_test_failures])
    setup = read('validation/source-ready.json')
    require(INPUTS[str(B / 'validation/source-ready.json')]['sha256'] == PLAN['validation_hold_sha256'], 'runner hold')
    for row in setup['files']: bound(row)
    observed_labels = {p.stem for p in (B / 'validation').glob('*.json') if p.name != 'source-ready.json'}
    require(observed_labels == permitted, 'unreviewed validation attempts: ' + repr(observed_labels ^ permitted))
    return dict(full=full, new_groups=49, node_clone_filter_groups=48, separate_storage_test=storage,
                all_new_group_names=sorted(all_new),
                all_attempt_passing_observations=sum(focus.values()) + sum(r['totals'][0] for r in failures),
                all_attempt_failures=sum(r['totals'][1] for r in failures),
                focused_observations=sum(focus.values()), focused_unique=len(focus),
                focused_commands=focused_commands, successful_gates=gates,
                retained_failure_runs=failures, retained_non_test_failures=non_test_failures,
                bootstrap_diagnostic=diagnostic, serial_status_wraps=wraps,
                exact_corrected_paths=corrected_paths, source_manifest_sha256=SOURCE)
'''
section('def validation():', 'OUTCOMES =', validation)

# Complete-row classifiers remain byte-for-byte functions; adapt only profile identities/populations.
c = s[s.index('def comparisons():'):s.index('def main():')]
c = c.replace('compare-position', 'compare-clone').replace('position-comparison', 'clone-comparison')
c = c.replace("'position-before.json'", "'clone-before.json'")
c = c.replace("'position-after.json'", "'clone-after.json'")
c = c.replace("'node-position'", "'node-clone'")
# Reintroduce the preceding position as an established profile in the exact profile roster and reports.
c = c.replace("'node-connected', 'node-clone'", "'node-connected', 'node-position', 'node-clone'")
c = c.replace("'node-connected','node-clone'", "'node-connected','node-position','node-clone'")
c = c.replace("'connected-after.json','clone-after.json'", "'connected-after.json','position-after.json','clone-after.json'")
c = c.replace("row['profile'] == 'node-connected'", "row['profile'] == 'node-position'")
c = c.replace("'node-root', 'node-equality'}", "'node-root', 'node-equality', 'node-connected'}")
c = c.replace("len(comparison['profiles']) == 20", "len(comparison['profiles']) == 21")
c = c.replace("len(policy['already_unhealthy_unchanged']) == 30", "len(policy['already_unhealthy_unchanged']) == 36")
c = c.replace("len(rows) == 48 and len({r['id'] for r in rows}) == 48", "len(rows) == 50 and len({r['id'] for r in rows}) == 50")
c = c.replace('[0, 4, 32, 16]', '[0, 4, 34, 16]')
c = c.replace("('cases', 4364, 4268, 4266, 2), ('controls', 524, 504, 500, 4)", "('cases', 4396, 4298, 4296, 2), ('controls', 540, 516, 512, 4)")
c = c.replace("('cases', 32, 0)", "('cases', 34, 0)")
c = c.replace('len(replay_receipts) == 20', 'len(replay_receipts) == 21')
c = c.replace("'node-connected-replay-command.json'}", "'node-connected-replay-command.json', 'node-position-replay-command.json'}")
c = c.replace('profiles=20', 'profiles=21').replace('preserved_older_unhealthy_rows=30','preserved_older_unhealthy_rows=36')
c = c.replace('all20 individual', 'all21 individual').replace('position raw', 'clone raw').replace('all position source', 'all clone source')
start = c.index('    # Bind the actual pending/final')
end = c.index("    for manifest in ['compare-clone-inputs.json'", start)
c = c[:start] + '''    comparison_dir = B / 'comparison-preparation'
    final_hold_bytes = raw(comparison_dir / 'source-ready-final.json')
    require(hashlib.sha256(final_hold_bytes).hexdigest() ==
            'bf1245140c01801f8e73db67339f3c3c1bbb05e34d54ee415d0174c00c79b6a3', 'final193-input comparison hold')
    final_hold = json.loads(final_hold_bytes)
    for value in final_hold.values():
        if isinstance(value, dict) and {'path', 'sha256'} <= value.keys(): bound(value)
    pending_path = comparison_dir / 'input-manifest-correction/initial/compare-clone.py'
    pending_hold = json.loads(bound(final_hold['original_pending_hold']))
    for row in pending_hold['files']:
        held = {**row, 'path': str(pending_path)} if row['path'] == str(comparison_dir / 'compare-clone.py') else row
        bound(held)
    correction = json.loads(bound(final_hold['one_sentinel_binding_receipt']))
    require(bound(correction['before']) == raw(pending_path) and
            bound(correction['after']) == raw(comparison_dir / 'compare-clone.py'), 'comparator exact images')
    pending = raw(pending_path)
    marker = b"INPUT_SHA='PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'"
    manifest_sha = hashlib.sha256(raw(comparison_dir / 'compare-clone-inputs.json')).hexdigest()
    require(pending.count(marker) == 1 and
            pending.replace(marker, ("INPUT_SHA='" + manifest_sha + "'").encode()) == raw(comparison_dir / 'compare-clone.py'),
            'only exact input digest substitution after pending hold')
    require(len(read(comparison_dir / 'compare-clone-inputs.json')['files']) == 193, 'actual final input population')
    checks = json.loads(bound(final_hold['verification']))['commands']
    require(len(checks) == 3, 'finalizer and both independent before checks retained')
    for helper, record in zip(['finalize-inputs.py', 'compare-clone.py', 'classify-inventory.py'], checks):
        expected = ['python3', str(comparison_dir / helper)] + ([] if helper == 'finalize-inputs.py' else ['--verify-before'])
        require(record['argv'] == expected and record['exit'] == 0, 'actual inert binding command')
        data = bound(record['log'])
        if helper != 'finalize-inputs.py': require(json.loads(data)['verified_before'] is True, 'before-check output')
        COMMANDS['comparison-preparation/final-inert-verification.json#' + helper] = record
''' + c[end:]
section('def comparisons():', 'def main():', c)

# Explicit result bindings are still pending; never execute this generator's product here.
with (HERE/'audit-results.py').open('x') as f: f.write(s)
with (HERE/'reader-adaptation.diff').open('x') as f:
    f.writelines(difflib.unified_diff(old.splitlines(True),s.splitlines(True),
                                  'inherited/position-audit-results.py','audit-results.py'))
print(json.dumps({'reader_sha256':hashlib.sha256(s.encode()).hexdigest(),'complete_audit_executed':False}))
