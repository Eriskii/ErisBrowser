# Clone independent results-reader preparation

This is a data-only reader draft. It does not run an engine, compiler, replay supervisor or comparator. A complete run requires an explicitly final validation plan and independently announced candidate source/release hashes; the current pending plan cannot pass.

The five inherited helpers `key`, `inputs`, `healthy`, `complete_rows`, and `test_rows` remain AST-identical to the position auditor. Full raw rows, unknown input fields, literal test identities, paired-control prerequisites, before/after source bindings and command failures remain part of the audit. Python-only synthetic helper checks do not execute the complete reader.

Actual initial source is the union of17 Runtime,6 DOM and4 browser files. The clone population is29 Runtime +18 DOM +2 browser =49 groups. The `node_clone` filter selects48; exact DomString storage copying contributes the separate remaining group. Counts come from the actual inventories, not from guessed prior schema names. Browser literals retain20 existing IDs and add exactly10 cloned nodes on the click; this is not a no-growth fixture.

The first compiler failure is retained separately from test failures. Exact correction stages must begin at the initial source image or the preceding admitted stage, with no silent reset. Root subsequently found missing `Object.hasOwn` in the unchanged browser fixture and is implementing that API. Its final scope, production changes, tests and final bootstrap have not yet been admitted by this reader draft. They require an additive source-held revision and concrete receipts before any complete audit.

The final comparison preparation has193 bindings and named comparator/classifier/manifest fields. The reader preserves its pending helper and verifies the exact one-sentinel substitution. Established4396 cases/540 controls may change only the six anticipated position inventory rows;36 older unhealthy rows remain unchanged. New clone34 cases/16 controls retain the same positive-partner rules. The original fixed replay path and seven previous JS fixtures remain unchanged.

`draft-correction-1/` retains the initial generated reader before three source-only inspection corrections (sentinel spacing, initial browser integration binding, and nonempty correction-list guard). No complete auditor run or engine execution occurred during preparation. Candidate counts, command histories and final release pins remain pending.
