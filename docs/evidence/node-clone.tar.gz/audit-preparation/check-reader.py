"""Inert parser/helper checks only; does not run the complete results audit."""
import ast,hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parent
new=ast.parse((p/'audit-results.py').read_text())
old=ast.parse((p/'inherited/position-audit-results.py').read_text())
functions=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
f,g=functions(new),functions(old)
for name in ['key','inputs','healthy','complete_rows','test_rows']:
 assert ast.dump(f[name],include_attributes=False)==ast.dump(g[name],include_attributes=False),name
ns={'re':re}
for name in ['require','test_rows']:
 exec(compile(ast.Module(body=[f[name]],type_ignores=[]),'<inert reader function>','exec'),ns)
parse=ns['test_rows']
checks=[]
for label,text,serial,expected in [
 ('flat','test a ... ok\ntest b ... FAILED\n',False,[('a','ok'),('b','FAILED')]),
 ('serial_diagnostic','test a ... SOME_MEASURE 1\nanother measurement\nok\n',True,[('a','ok')]),
 ('serial_panic','test a ... \nthread a panicked\nFAILED\n',True,[('a','FAILED')]),
 ('doctest_label','test src/lib.rs - demo (line 3) ... ok\n',False,[('src/lib.rs - demo (line 3)','ok')])]:
 assert parse(text,serial)[0]==expected,label;checks.append(label)
for label,text,serial in [
 ('orphan','ok\n',True),('unfinished','test a ... diagnostic\n',True),
 ('overlap','test a ... x\ntest b ... ok\n',True),
 ('nonserial_wrap','test a ... x\nok\n',False),
 ('summary_before_status','test a ... x\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n',True)]:
 try:parse(text,serial)
 except ValueError:checks.append(label)
 else:raise AssertionError(label)
# Exercise only isolated pure health/identity helpers against synthetic records.
ns.update(OUTCOMES={'status','observation','reason','stderr','matches_expectation','matches_implementation_policy',
 'verified','verified_with_protocol_prerequisite','positive_partner_matches'})
for name in ['key','inputs','healthy','complete_rows']:
 exec(compile(ast.Module(body=[f[name]],type_ignores=[]),'<inert record function>','exec'),ns)
complete=dict(status='complete',phase='runtime',error_type='',error_identity='')
row=dict(id='probe#strict',mode='strict',source_sha256='held',expected_observation=complete,
 observation=complete,matches_expectation=True)
assert ns['healthy'](row)
for observation in [None,[],{},dict(complete,error_type='TypeError')]:
 assert not ns['healthy'](dict(row,observation=observation))
assert not ns['healthy'](dict(row,verified=False))
assert not ns['healthy'](dict(row,verified_with_protocol_prerequisite=False))
checks.append('absent_wrong_unverified_observations_never_healthy')
assert ns['complete_rows']([row],[row])[0]['unchanged']==1
for label,left,right in [
 ('source_drift',[row],[dict(row,source_sha256='changed')]),
 ('missing_row',[row],[]),('duplicate_identity',[row,row],[row,row])]:
 try:ns['complete_rows'](left,right)
 except ValueError:checks.append(label)
 else:raise AssertionError(label)
# Current known schemas checked as data, without invoking the reader.
b=p.parent
runtime=json.loads((b/'runtime/test-inventory-2.json').read_text())
dom=json.loads((b/'dom/test-inventory.json').read_text())
assert runtime['new_runtime_groups']==29 and dom['new_dom_total']==18
assert runtime['new_runtime_groups']+dom['new_dom_total']+2==49
assert runtime['new_runtime_groups']+dom['helper_groups']+2==48
checks.append('actual_clone_inventories49_filter48')
manifest=json.loads((b/'candidate-source-initial.json').read_text())
union={}
for path in ['runtime/source-ready-3.json','dom/source-ready.json','browser-integration.json']:
 for row in json.loads((b/path).read_text())['files']:
  assert row['path'] not in union
  union[row['path']]={k:row[k] for k in ['path','bytes','sha256']}
assert union=={r['path']:r for r in manifest['files']} and len(union)==27
checks.append('three_owner_holds_match_initial27')
c=b/'comparison-preparation'
pending=(c/'input-manifest-correction/initial/compare-clone.py').read_bytes()
sha=hashlib.sha256((c/'compare-clone-inputs.json').read_bytes()).hexdigest()
marker=b"INPUT_SHA = 'PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'"
assert pending.count(marker)==1 and pending.replace(marker,("INPUT_SHA = '"+sha+"'").encode())==(c/'compare-clone.py').read_bytes()
assert len(json.loads((c/'compare-clone-inputs.json').read_text())['files'])==193
checks.append('actual_comparison193_exact_sentinel')
report={'status':'clear inert reader checks','functions_ast_identical':['key','inputs','healthy','complete_rows','test_rows'],
 'checks':checks,'complete_audit_executed':False,'engine':False,'rust_compiler':False,
 'source_sha256':hashlib.sha256((p/'audit-results.py').read_bytes()).hexdigest()}
with (p/'reader-checks.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps(report,indent=2))
