"""Bind actual source additions and retained attempts; do not run the auditor."""
from pathlib import Path
import json, hashlib, re
H=Path(__file__).resolve().parent
B=H.parent
P=Path('/tmp/eris-node-clone-preparation-1')
def bind(path):
    data=path.read_bytes()
    return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def change(before,after): return dict(before=before,after=after)
def exact(receipt,path,changes):
    return dict(schema='before_after',receipt=bind(B/receipt),path=path,changes=changes)
plan=json.loads((H/'validation-plan.pending.json').read_text())
stages=[exact('compile-correction-1/receipt.json','src/script/node_clone/tests.rs',[
 change('    let runtime = Runtime::uninitialized().finish_bootstrap().unwrap();',
        '    let mut runtime = Runtime::uninitialized().finish_bootstrap().unwrap();')])]
title='        assert_eq!(actual.title(), node_clone_witness::metadata(phase));'
stages.append(exact('browser-correction-1/receipt.json','tests/pipeline.rs',[
 change(title,'        assert!(\n            actual.runtime.console.is_empty(),\n            "{:?}",\n            actual.runtime.console\n        );\n'+title)]))
seams={'src/script.rs':[
 change('mod node_root;\nmod object_integrity;','mod node_root;\nmod object_has_own;\nmod object_integrity;'),
 change('        self.initialize_dom_prototypes()?;\n        Ok(())','        self.initialize_dom_prototypes()?;\n        self.install_object_has_own_intrinsic()'),
 change('        if native.name == "Object.is" {','        if native.name == "Object.hasOwn" {\n            return self.object_has_own(&args, doc);\n        }\n        if native.name == "Object.is" {')],
 'src/script/dom_prototypes.rs':[change('pub(super) const BOOTSTRAP_OBJECTS: usize = 351\n','pub(super) const BOOTSTRAP_OBJECTS: usize = 351\n    + object_has_own::METADATA_OBJECTS\n')]}
stages.append(dict(schema='object_has_own_scope',hold=bind(B/'object-has-own/source-ready.json'),before=bind(B/'object-has-own/before.json'),seams=seams,checkpoint=bind(B/'candidate-source-before-has-own-compiler.json')))
stages.append(dict(schema='image_rows',receipt=bind(B/'bootstrap-correction-1/receipt.json'),file_count=2,
 changes={'src/script/bootstrap_tests.rs':[
  change('    assert_eq!(reference.steps, 6_599);','    assert_eq!(reference.steps, 4_709);'),
  change('    assert_eq!(reference.objects.len(), 689);','    assert_eq!(reference.objects.len(), 690);'),
  change('    assert_eq!(reference.native_properties.len(), 321);','    assert_eq!(reference.native_properties.len(), 320);')],
  'src/script/dom_bindings/identity_tests.rs':[change('    assert_eq!(runtime.objects.len(), 689);','    assert_eq!(runtime.objects.len(), 690);')]},
 admit_added_paths=['src/script/bootstrap_tests.rs'],added_before_bindings={'src/script/bootstrap_tests.rs':bind(P/'replay/history/published-position/held-source-final/src/script/bootstrap_tests.rs')}))
stages.append(exact('legacy-inventory-correction-1/receipt.json','src/script/dom_bindings/identity_tests.rs',[
 change('            .count(),\n        27\n','            .count(),\n        26\n')]))
labels=['clone-188-2','clone-storage-188-1','has-own-188-1','bootstrap-188-1','constants-188-1','node-data-188-1','normalize-188-1','predicates-188-1','root-188-1','equality-188-1','connected-188-1','position-188-1','clone-legacy-188-1','dom-bindings-188-2']
failures=[]
for label in ['clone-188-1','clone-page-diagnostic-188-1','dom-bindings-188-1']:
    r=json.loads((B/'validation'/(label+'.json')).read_text());log=(B/'validation'/r['log']).read_text()
    summaries=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log,re.M)
    names=re.findall(r'^failures:\n((?:    [^\n]+\n)+)\n',log,re.M)
    assert len(names)==1,label
    failed=[n.strip() for n in names[0].splitlines()]
    failures.append(dict(label=label,exit=r['exit'],totals=[sum(int(x[i]) for x in summaries) for i in range(3)],failed_names=failed,
                         required_literals=['Uncaught event listener exception: value is not callable'] if label=='clone-page-diagnostic-188-1' else []))
plan.update(status='pending complete candidate release, full results and root audit authorization',
 source_population=31,final_directory='source-final',observed_source_manifest_sha256=bind(B/'candidate-source-final.json')['sha256'],
 additional_Object_hasOwn_groups=17,has_own_inventory=bind(B/'object-has-own/test-inventory.json'),source_corrections=stages,
 focused_labels=labels,new_focused_label='clone-188-2',storage_focused_label='clone-storage-188-1',has_own_focused_label='has-own-188-1',
 bootstrap_diagnostics=[
 dict(stage='pre-hasOwn',label='clone-188-1',exit=101,literal='NODE_CLONE_BOOTSTRAP steps=6019 allocated=1775064 objects=689 capacity=689 native=320 prototypes=25'),
 dict(stage='final',label='has-own-188-1',exit=0,literal='OBJECT_HAS_OWN_BOOTSTRAP steps=4709 allocated=1782581 objects=690 capacity=690 native=320 prototypes=25')],
 has_own_replay=None,retained_failure_runs=failures,
 retained_non_test_failures=[dict(label='compile-188-1',exit=101,required_literals=['error[E0596]']),
 dict(label='clippy-native-198-1',exit=101,required_literals=['bit-set v0.10.0','File exists (os error 17)'])])
plan.pop('bootstrap_diagnostic',None)
plan['known_history_bindings']=[bind(p) for p in sorted((B/'validation').glob('*.json')) if p.name!='source-ready.json']
plan['supplemental_bindings']=[bind(B/x) for x in ['root-source-review.json','object-has-own/root-source-review.json',
 'object-has-own/root-fixture-replay-review.json','object-has-own/accounting-correction.json','object-has-own/accounting-correction.md',
 'browser-correction-1/pipeline-diagnostic.rs','cache-repair-1/receipt.json','object-has-own/replay/source-ready.json',
 'object-has-own/replay/layout-source-review.json','object-has-own/baseline-execution.json','has-own-before.json','replay-supervisor-ready.json']]
plan['pending_notes']=[
 'Original49 clone groups and additional17 Object.hasOwn groups remain separately counted; all66 names must appear in each full suite.',
 'Five source stages reconstruct initial27 to final31. The only production addition is the held five-path hasOwn change with four exact existing-file seams.',
 'Standalone16/8 results remain separate from clone21-profile totals; the candidate report is absent.',
 'Complete audit remains unexecuted. Root full suites, final successful gates, release and focused-summary binding remain pending.']
with (H/'validation-plan.pending-2.json').open('x') as f:json.dump(plan,f,indent=2);f.write('\n')
print(json.dumps(dict(status='concrete source and attempt history bound; final results still pending',source_population=31,source_stages=len(stages),clone_groups=49,additional_groups=17)))
