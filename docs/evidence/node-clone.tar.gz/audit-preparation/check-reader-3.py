"""Inert parser/helper checks only; does not run the complete results audit."""
import ast,hashlib,json,re
from pathlib import Path
p=Path(__file__).resolve().parent
new=ast.parse((p/'audit-results.py').read_text())
old=ast.parse((p/'inherited/position-audit-results.py').read_text())
functions=lambda tree:{n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
f,g=functions(new),functions(old)
for name in ['key','inputs','healthy','complete_rows','test_rows']:
 assert ast.dump(f[name],include_attributes=False)==ast.dump(g[name],include_attributes=False),name
ns={'re':re}
for name in ['require','test_rows']:
 exec(compile(ast.Module(body=[f[name]],type_ignores=[]),'<inert reader function>','exec'),ns)
parse=ns['test_rows']
checks=[]
for label,text,serial,expected in [
 ('flat','test a ... ok\ntest b ... FAILED\n',False,[('a','ok'),('b','FAILED')]),
 ('serial_diagnostic','test a ... SOME_MEASURE 1\nanother measurement\nok\n',True,[('a','ok')]),
 ('serial_panic','test a ... \nthread a panicked\nFAILED\n',True,[('a','FAILED')]),
 ('doctest_label','test src/lib.rs - demo (line 3) ... ok\n',False,[('src/lib.rs - demo (line 3)','ok')])]:
 assert parse(text,serial)[0]==expected,label;checks.append(label)
for label,text,serial in [
 ('orphan','ok\n',True),('unfinished','test a ... diagnostic\n',True),
 ('overlap','test a ... x\ntest b ... ok\n',True),
 ('nonserial_wrap','test a ... x\nok\n',False),
 ('summary_before_status','test a ... x\ntest result: ok. 1 passed; 0 failed; 0 ignored;\n',True)]:
 try:parse(text,serial)
 except ValueError:checks.append(label)
 else:raise AssertionError(label)
# Exercise only isolated pure health/identity helpers against synthetic records.
ns.update(OUTCOMES={'status','observation','reason','stderr','matches_expectation','matches_implementation_policy',
 'verified','verified_with_protocol_prerequisite','positive_partner_matches'})
for name in ['key','inputs','healthy','complete_rows']:
 exec(compile(ast.Module(body=[f[name]],type_ignores=[]),'<inert record function>','exec'),ns)
complete=dict(status='complete',phase='runtime',error_type='',error_identity='')
row=dict(id='probe#strict',mode='strict',source_sha256='held',expected_observation=complete,
 observation=complete,matches_expectation=True)
assert ns['healthy'](row)
for observation in [None,[],{},dict(complete,error_type='TypeError')]:
 assert not ns['healthy'](dict(row,observation=observation))
assert not ns['healthy'](dict(row,verified=False))
assert not ns['healthy'](dict(row,verified_with_protocol_prerequisite=False))
checks.append('absent_wrong_unverified_observations_never_healthy')
assert ns['complete_rows']([row],[row])[0]['unchanged']==1
for label,left,right in [
 ('source_drift',[row],[dict(row,source_sha256='changed')]),
 ('missing_row',[row],[]),('duplicate_identity',[row,row],[row,row])]:
 try:ns['complete_rows'](left,right)
 except ValueError:checks.append(label)
 else:raise AssertionError(label)
# Current known schemas checked as data, without invoking the reader.
b=p.parent
runtime=json.loads((b/'runtime/test-inventory-2.json').read_text())
dom=json.loads((b/'dom/test-inventory.json').read_text())
assert runtime['new_runtime_groups']==29 and dom['new_dom_total']==18
assert runtime['new_runtime_groups']+dom['new_dom_total']+2==49
assert runtime['new_runtime_groups']+dom['helper_groups']+2==48
checks.append('actual_clone_inventories49_filter48')
manifest=json.loads((b/'candidate-source-initial.json').read_text())
union={}
for path in ['runtime/source-ready-3.json','dom/source-ready.json','browser-integration.json']:
 for row in json.loads((b/path).read_text())['files']:
  assert row['path'] not in union
  union[row['path']]={k:row[k] for k in ['path','bytes','sha256']}
assert union=={r['path']:r for r in manifest['files']} and len(union)==27
checks.append('three_owner_holds_match_initial27')
c=b/'comparison-preparation'
pending=(c/'input-manifest-correction/initial/compare-clone.py').read_bytes()
sha=hashlib.sha256((c/'compare-clone-inputs.json').read_bytes()).hexdigest()
marker=b"INPUT_SHA = 'PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'"
assert pending.count(marker)==1 and pending.replace(marker,("INPUT_SHA = '"+sha+"'").encode())==(c/'compare-clone.py').read_bytes()
assert len(json.loads((c/'compare-clone-inputs.json').read_text())['files'])==193
checks.append('actual_comparison193_exact_sentinel')
# Additional source scope and the complete staged before/after chain, independently as data.
plan=json.loads((p/'validation-plan.pending-2.json').read_text())
staged={r['path']:(b/'source-initial'/r['path']).read_bytes() for r in manifest['files']}
for spec in plan['source_corrections']:
 if spec['schema']=='object_has_own_scope':
  hold=json.loads(Path(spec['hold']['path']).read_text())
  assert len(hold['files'])==5
  for r in hold['files']:
   after=Path(r['held']).read_bytes()
   assert hashlib.sha256(after).hexdigest()==r['sha256']
   if r['path'] in spec['seams']:
    before=staged[r['path']]
    for c in spec['seams'][r['path']]:
     assert before.count(c['before'].encode())==1
     before=before.replace(c['before'].encode(),c['after'].encode())
    assert before==after
   else:assert r['path'] not in staged
   staged[r['path']]=after
  checkpoint=json.loads(Path(spec['checkpoint']['path']).read_text())
  assert {r['path']:r['sha256'] for r in checkpoint['files']}=={name:hashlib.sha256(data).hexdigest() for name,data in staged.items()}
  continue
 receipt=json.loads(Path(spec['receipt']['path']).read_text())
 rows=receipt['changes'] if spec['schema']=='image_rows' else [dict(path=spec['path'],before=receipt['before'],after=receipt['after'])]
 for row in rows:
  before=Path(row['before']['path']).read_bytes();after=Path(row['after']['path']).read_bytes()
  assert hashlib.sha256(before).hexdigest()==row['before']['sha256'] and hashlib.sha256(after).hexdigest()==row['after']['sha256']
  if row['path'] in staged:assert staged[row['path']]==before
  else:assert before==Path(spec['added_before_bindings'][row['path']]['path']).read_bytes()
  changes=spec['changes'][row['path']] if spec['schema']=='image_rows' else spec['changes']
  for c in changes:
   assert before.count(c['before'].encode())==1
   before=before.replace(c['before'].encode(),c['after'].encode())
  assert before==after
  staged[row['path']]=after
final=json.loads((b/'candidate-source-final.json').read_text())
assert len(staged)==31 and {r['path']:r['sha256'] for r in final['files']}=={name:hashlib.sha256(data).hexdigest() for name,data in staged.items()}
checks.append('five_exact_stages_initial27_to_final31')
own=json.loads((b/'object-has-own/test-inventory.json').read_text())
assert own['new_groups']==17 and own['direct_groups']==9 and own['independent_groups']==8 and own['independent_modes']==16
assert own['new_groups']+runtime['new_runtime_groups']+dom['new_dom_total']+2==66
checks.append('additional17_separate_from_clone49')
for spec in plan['retained_failure_runs']:
 rec=json.loads((b/'validation'/(spec['label']+'.json')).read_text());log=(b/'validation'/rec['log']).read_text()
 rows,_=parse(log,'--test-threads=1' in rec['command'])
 assert [sum(status==v for _,status in rows) for v in ['ok','FAILED','ignored']]==spec['totals']
 assert [name for name,status in rows if status=='FAILED']==spec['failed_names']
checks.append('all_three_real_failed_test_logs_parse_complete')
for spec in plan['retained_non_test_failures']:
 log=(b/'validation'/(spec['label']+'.log')).read_text()
 assert all(x in log for x in spec['required_literals']) and not re.search(r'^test result:',log,re.M)
checks.append('compile_and_cache_failures_are_not_test_results')
assert plan['has_own_replay'] is None and plan['status'].startswith('pending')
checks.append('complete_audit_remains_pending')
final_plan=json.loads((p/'validation-plan-final.json').read_text())
assert final_plan['source_population']==31 and len(final_plan['focused_labels'])==14 and len(final_plan['gates'])==5
assert len(final_plan['full_runs'])==2 and len(final_plan['retained_failure_runs'])==3 and len(final_plan['retained_non_test_failures'])==2
assert len(final_plan['known_history_bindings'])==26
assert final_plan['observed_source_manifest_sha256']=='76b82bdfc67a7bc28f364be0caa9cf13c9f8105a707e873fb95db389df018196'
assert final_plan['observed_release_sha256']=='e77a1efcd0b08a2ac570d65e0d0a4579aa55b51f02a4c99188b6bbbf19e7310d'
for row in final_plan['supplemental_bindings']+final_plan['known_history_bindings']:
 data=Path(row['path']).read_bytes()
 assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
checks.append('actual_final_plan26_commands_and_announced_hashes')
report={'status':'clear inert reader checks','functions_ast_identical':['key','inputs','healthy','complete_rows','test_rows'],
 'checks':checks,'complete_audit_executed':False,'engine':False,'rust_compiler':False,
 'source_sha256':hashlib.sha256((p/'audit-results.py').read_bytes()).hexdigest()}
with (p/'reader-checks-3.json').open('x') as stream:json.dump(report,stream,indent=2);stream.write('\n')
print(json.dumps(report,indent=2))
