#!/usr/bin/env python3
"""Read JSON, logs and bytes only; never import a reviewed helper or run an engine.

Clone preparation derived from the held position audit. Requires the final announced
release and all result files; counts come from literal test rows, including
serial nocapture status wraps. No prior SHA-specific log repair is used.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent.parent
SOURCE = None  # Future announced final source manifest; never inferred from results.
BASE_BINARY = 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'
PREP = Path('/tmp/eris-node-clone-preparation-1')
PLAN = None
# Required independently from the eventual root release announcement; no guessed pin.
CANDIDATE = None
INPUTS = {}
COMMANDS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def raw(path):
    path = B / path
    data = path.read_bytes()
    binding = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    require(str(path) not in INPUTS or INPUTS[str(path)] == binding, 'input changed: ' + str(path))
    INPUTS[str(path)] = binding
    return data


def read(path):
    return json.loads(raw(path))


def bound(row, prefix=B):
    data = raw(prefix / row['path'])
    require(hashlib.sha256(data).hexdigest() == row['sha256'], 'hash: ' + row['path'])
    if 'bytes' in row:
        require(len(data) == row['bytes'], 'length: ' + row['path'])
    return data


def command(path, exit_code):
    record = read(path)
    COMMANDS[path] = record
    require(record['exit'] == exit_code, 'command exit: ' + path)
    if isinstance(record['log'], dict):
        data = bound(record['log'])
    else:
        log = Path(path).parent / record['log']
        data = raw(log)
        require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)
    return record, data.decode()


def test_rows(log, serial):
    """Associate a serial bare status with exactly one unfinished test header."""
    names, wraps = [], []
    pending = None
    for number, line in enumerate(log.splitlines(), 1):
        match = re.fullmatch(r'test (.+?) \.\.\. (.*)', line)
        if match:
            require(pending is None, 'new test before prior status at line ' + str(number))
            name, tail = match.groups()
            if tail in {'ok', 'FAILED', 'ignored'}:
                names.append((name, tail))
            else:
                require(serial, 'nonserial wrapped test status at line ' + str(number))
                pending = (name, number)
        elif line in {'ok', 'FAILED', 'ignored'}:
            require(pending is not None and serial, 'orphan test status at line ' + str(number))
            names.append((pending[0], line))
            wraps.append(dict(name=pending[0], header_line=pending[1], status_line=number, status=line))
            pending = None
        elif line.startswith('test result:'):
            require(pending is None, 'missing test status before summary')
    require(pending is None, 'unfinished test status')
    return names, wraps


def tests(path, exit_code, totals=None):
    record, log = command('validation/' + path + '.json', exit_code)
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    require(summaries, 'missing test summary: ' + path)
    observed = [sum(int(row[i]) for row in summaries) for i in range(3)]
    if totals is not None:
        require(observed == totals, 'test summary: ' + path)
    names, wraps = test_rows(log, '--test-threads=1' in record['command'])
    require([sum(status == status_name for _, status in names) for status_name in ['ok', 'FAILED', 'ignored']] == observed,
            'literal test rows: ' + path)
    if exit_code == 0:
        require(observed[0] > 0 and observed[1:] == [0, 0], 'successful complete test run: ' + path)
    record = {**record, 'serial_status_wraps': wraps}
    return record, names, log, observed


def frozen_inputs():
    """Rebuild source identities as data; do not import the supervisor/helpers."""
    holds = [
        ('independent/source-ready.json', '6e995add31fe991143d364fb79b2efab4bd839352a9f3850e735ad3cb624dad0'),
        ('browser/source-ready-2.json', '7afdb720ae1be673a0428983ec1aabf68ab268d5d3aa7e4f4b68c3a4880dd3b6'),
        ('replay/source-ready.json', 'e29a256d2d737876577b8dad14e3fa1df0258c820832a41aebc0a140043e605b'),
    ]
    for name, digest in holds:
        data = raw(PREP / name)
        require(hashlib.sha256(data).hexdigest() == digest, 'frozen preparation hold: ' + name)
        for row in json.loads(data)['files']:
            bound(row, PREP / Path(name).parent)
    fixture = raw(PREP / 'independent/cases.js')
    require(hashlib.sha256(fixture).hexdigest() ==
            'bf66956a6ca0e1ef138a2d634ab3c31968754415f04c4b2197a2b07e9ec63479', 'exact independent fixture')
    require(fixture == raw('worktree/tests/fixtures/node-clone.js'), 'integrated JS fixture unchanged')
    for name in ['node-constants.js', 'node-normalize.js', 'node-predicates.js', 'node-root.js', 'node-equality.js', 'node-connected.js', 'node-position.js']:
        require(raw(PREP / 'replay/history' / name) == raw('worktree/tests/fixtures/' + name),
                'historical JS fixture unchanged: ' + name)
    inv = read(PREP / 'independent/inventory.json')
    require(inv['collection'] == 'nodeCloneCases' and len(inv['cases']) == 17, 'independent case population')
    require(inv['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True}, 'literal mode contract')
    require(inv['literal_prototype_total'] == 31 and len(inv['literal_prototype_string_keys']) == 30 and
            inv['literal_prototype_string_keys'][:11] == [
                'isConnected', 'nodeValue', 'textContent', 'getRootNode', 'hasChildNodes',
                'normalize', 'cloneNode', 'isEqualNode', 'isSameNode', 'compareDocumentPosition', 'contains'] and
            inv['literal_prototype_string_keys'][-1] == 'constructor' and
            inv['literal_prototype_final_symbol'] == 'Symbol.toStringTag' and
            len(inv['literal_constructor_keys']) == 21, 'current represented metadata oracle')
    replay = PREP / 'replay'
    inputs_json = read(replay / 'replay-inputs.json')
    matrix = read(replay / 'replay-matrix.json')
    require(inputs_json['fixture_sha256'] == hashlib.sha256(fixture).hexdigest() and
            inputs_json['collection'] == inv['collection'] and
            inputs_json['case_invocation_argument_by_mode'] == inv['case_invocation_argument_by_mode'],
            'replay invocation/fixture identity')
    require([r['name'] for r in inputs_json['cases']] == inv['cases'], 'ordered case identities')
    require(inputs_json['controls'] == read(PREP / 'independent/controls.json')['controls'], 'unchanged controls')
    complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
    wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
    metadata = dict(flags=[], features=[], includes=[], locale=[], negative=None)
    identities = []
    positive_sources = {r['name']: r for r in inputs_json['controls'] if r['positive']}
    for kind, rows in [('case', inputs_json['cases']), ('control', inputs_json['controls'])]:
        for row in rows:
            require(row['modes'] == ['sloppy', 'strict'], 'frozen modes')
            require(row['expected_observation'] == (complete if kind == 'case' or row['positive'] else wrong),
                    'ordinary/wrong expected observation')
            if kind == 'control':
                positive = positive_sources[row['pair'] + '-positive']
                require(positive['area'] == row['area'] and row['source'] == positive['source'] +
                        ('' if row['positive'] else "throw new Error('deliberately wrong expectation');"),
                        'exact positive prefix and wrong tail')
            for mode in row['modes']:
                body = (fixture + b'\nif(nodeCloneCases.' + row['name'].encode() +
                        (b'(true)' if mode == 'strict' else b'(false)') +
                        b' !== true) throw new Error("case did not return true");'
                        if kind == 'case' else row['source'].encode())
                source_sha = hashlib.sha256(body).hexdigest()
                fingerprint = dict(source_sha256=source_sha, mode=mode, metadata=metadata, harness=[])
                case_sha = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=True).encode()).hexdigest()
                identity = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind,
                                source_sha256=source_sha, case_sha256=case_sha,
                                expected_observation=row['expected_observation'])
                if kind == 'control':
                    identity.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                                    partner=row['pair'] + '-positive#' + mode)
                identities.append(identity)
    require(len(identities) == 50 and identities == matrix['rows'], 'independent complete matrix reconstruction')
    for row in matrix['bound_inputs']:
        bound(row)
    require(matrix['bounds'] == dict(timeout_seconds=3, stdout_limit=96 * 1024,
                                    stderr_limit=64 * 1024, execution='sequential inherited run_case'), 'inherited runner bounds')
    for field, path in [('fixture_sha256', replay / 'independent/cases.js'),
                        ('inventory_sha256', replay / 'replay-inputs.json'),
                        ('replay_sha256', replay / 'replay.py'),
                        ('runner_sha256', replay / 'tools/test262_conformance.py')]:
        require(matrix[field] == hashlib.sha256(raw(path)).hexdigest(), 'matrix header binding: ' + field)
    for name in ['node-clone.html', 'node_clone.rs']:
        relative = 'tests/fixtures/' + name if name.endswith('.html') else 'tests/support/' + name
        require(raw(PREP / 'browser' / name) == raw('worktree/' + relative), 'browser source unchanged: ' + name)
    browser = read(PREP / 'browser/source-ready-2.json')
    require(browser['literal_population'] == dict(stable_ids=20, copied_graph_nodes=10,
            click_added_nodes=10, clicks=1, phases=2, worker_generation=216), 'frozen clone browser inventory')
    integration = read('browser-integration.json')
    require(integration['source_hold_sha256'] == hashlib.sha256(raw(PREP / 'browser/source-ready-2.json')).hexdigest(),
            'browser integration source hold')
    for row in integration['files']:
        bound(row, B / 'worktree')
    helper = raw(PREP / 'browser/node_clone.rs').decode()
    require('assert_eq!(stable.len(), 20);' in helper and 'stable.extend(originals);' in helper and
            'assert_eq!(stable, initial.stable);' in helper and 'initial.nodes + 10,' in helper and
            '(initial.nodes..initial.nodes + 10).collect::<Vec<_>>()' in helper,
            'literal stable original and fresh copied identity assertions')
    require('["Clone ready", "Clone done"]' in helper and '[0x008000, 0x0000ff][phase]' in helper and
            'reference_html(phase)' in helper, 'frozen literal canvas and metadata')
    return dict(case_modes=34, control_modes=16, matrix_rows=50, explicit_literal_mode_argument=True,
                prototype_keys=31, constructor_keys=21, browser_retained_ids=20, browser_created_nodes=10,
                historical_fixtures_unchanged='Seven prior sources remain retained in the frozen replay')


def correction_chain(initial, final):
    """Reconstruct every authorized stage, anchored to the first source hold."""
    staged = {p: raw(Path(PLAN['initial_directory']) / p) for p in initial}
    changed = set()
    for spec in PLAN['source_corrections']:
        receipt = json.loads(bound(spec['receipt']))
        if spec['schema'] == 'literal_files':
            rows = receipt['files']
            require(len(rows) == spec['file_count'] and sum(len(r['changes']) for r in rows) == spec['literal_count'],
                    'exact literal correction population')
            stages = [dict(path=r['path'], before=dict(path=str(Path(spec['before_directory']) / r['path']),
                       sha256=r['before_sha256']), after=dict(path=str(B / 'worktree' / r['path']),
                       sha256=r['after_sha256']), changes=r['changes']) for r in rows]
        elif spec['schema'] == 'before_after':
            require(set(spec['changes'][0]) == {'before', 'after'} and spec['changes'], 'explicit correction bytes')
            stages = [dict(path=spec['path'], before=receipt['before'], after=receipt['after'], changes=spec['changes'])]
        else:
            raise ValueError('unreviewed correction schema')
        for row in stages:
            p = row['path']; before = bound(row['before']); after = bound(row['after'])
            require(p not in staged or staged[p] == before, 'correction must continue exact initial or prior stage: ' + p)
            if p not in staged:
                require(spec.get('admit_added_paths') == [p] or p in spec.get('admit_added_paths', []),
                        'new source path must be explicitly admitted')
            for change in row['changes']:
                left, right = change['before'].encode(), change['after'].encode()
                require(left != right and before.count(left) == 1, 'unique meaningful exact source correction')
                before = before.replace(left, right)
            require(before == after, 'entire corrected file matches enumerated substitutions')
            staged[p] = after; changed.add(p)
    require(staged.keys() == final.keys(), 'only exact enumerated paths added to source hold')
    for p, data in staged.items():
        require(hashlib.sha256(data).hexdigest() == final[p]['sha256'] and len(data) == final[p]['bytes'] and
                data == raw('worktree/' + p), 'unreported final source drift: ' + p)
    return sorted(changed)


def validation():
    """Actual complete counts and final pins are supplied only in a held final plan."""
    required = ['source_population', 'initial_population', 'initial_directory', 'final_directory',
                'runtime_inventory', 'dom_inventory', 'focused_labels', 'new_focused_label',
                'storage_focused_label', 'focused_summary', 'full_runs', 'gates',
                'retained_failure_runs', 'retained_non_test_failures', 'source_corrections', 'bootstrap_diagnostic']
    require(all(PLAN.get(k) is not None for k in required), 'validation plan has unmeasured pending fields')
    source = read('candidate-source-final.json')
    require(INPUTS[str(B / 'candidate-source-final.json')]['sha256'] == SOURCE, 'final source identity')
    current = {r['path']: r for r in source['files']}
    require(len(current) == len(source['files']) == PLAN['source_population'], 'unique final source population')
    for row in source['files']:
        bound(row, B / 'worktree'); bound(row, B / PLAN['final_directory'])
    initial = read('candidate-source-initial.json')
    old = {r['path']: r for r in initial['files']}
    require(len(old) == len(initial['files']) == PLAN['initial_population'] == 27, 'initial source population')
    for row in initial['files']:
        bound(row, B / PLAN['initial_directory'])
    # The initial manifest must match all three independent owner holds, not just a path count.
    owner_rows = {}
    for spec in PLAN['owner_holds']:
        held = json.loads(bound(spec))
        for row in held['files']:
            require(row['path'] not in owner_rows, 'source owner overlap')
            owner_rows[row['path']] = {k: row[k] for k in ['path', 'bytes', 'sha256']}
            if 'held_copy' in row:
                bound({**row, 'path': row['held_copy']})
        for row in held.get('references', []):
            bound(row)
    require(owner_rows == old, 'initial 17 Runtime, 6 DOM, 4 browser source identities')
    corrected_paths = correction_chain(old, current)
    inventory = json.loads(bound(PLAN['runtime_inventory']))
    dom = json.loads(bound(PLAN['dom_inventory']))
    runtime_text = raw('worktree/src/script/node_clone/tests.rs').decode()
    direct = re.findall(r'^#\[test\]\nfn ([A-Za-z_][A-Za-z0-9_]*)\(', runtime_text, re.M)
    require(direct == inventory['direct_groups'] and len(direct) == inventory['direct_count'] == 12,
            'actual private Runtime test names')
    independent = read(PREP / 'independent/inventory.json')['cases']
    require(inventory['independent_groups'] == independent and inventory['independent_count'] == 17 and
            inventory['independent_modes'] == 34 and inventory['new_runtime_groups'] == 29 and
            inventory['browser_groups_root_owned'] == 2 and inventory['new_runtime_and_browser_groups'] == 31,
            'actual Runtime inventory, DOM groups remain separate')
    macro = re.search(r'^cases!\((.*?)\);', runtime_text, re.M | re.S)
    require(macro is not None and [n.strip() for n in macro.group(1).split(',') if n.strip()] == independent,
            'actual macro population matches independent literal names')
    dom_names = re.findall(r'^#\[test\]\nfn ([A-Za-z_][A-Za-z0-9_]*)\(',
                           raw('worktree/src/dom/node_clone/tests.rs').decode(), re.M)
    require(dom_names == dom['helper_test_names'] and len(dom_names) == dom['helper_groups'] == 17 and
            dom['exact_storage_groups'] == 1 and dom['new_dom_total'] == 18, 'actual private DOM names')
    storage = 'dom::string::tests::' + dom['exact_storage_test']
    require(dom['exact_storage_test'] in re.findall(r'^    #\[test\]\n    fn (\w+)\(',
            raw('worktree/src/dom/string.rs').decode(), re.M), 'separate exact-storage test source')
    runtime_names = {'script::node_clone::tests::' + n for n in independent + direct}
    expected_dom = {'dom::node_clone::tests::' + n for n in dom_names}
    browser_names = {'node_clone_copies_exact_graphs_with_fresh_identities',
                     'confined_node_clone_copies_exact_graphs_with_fresh_identities'}
    filtered_new = runtime_names | expected_dom | browser_names
    all_new = filtered_new | {storage}
    require(len(filtered_new) == 48 and len(all_new) == 49, '49 new groups, 48 match node_clone')
    focus = Counter(); focused_commands = {}; wraps = {}; clone_log = None
    for label in PLAN['focused_labels']:
        rec, rows, log, observed = tests(label, 0)
        require('--include-ignored' in rec['command'], 'focused include ignored: ' + label)
        names = {n for n, _ in rows}
        require(len(names) == len(rows), 'unique names within successful focused command')
        if label == PLAN['new_focused_label']:
            require(names == filtered_new and observed == [48, 0, 0], 'complete exact node_clone filter inventory')
            clone_log = log
        if label == PLAN['storage_focused_label']:
            require(names == {storage} and observed == [1, 0, 0] and '--exact' in rec['command'],
                    'separate exact-storage test')
        focus.update(n for n, _ in rows)
        focused_commands[label] = dict(command=rec['command'], totals=observed, test_names=[n for n, _ in rows])
        if rec['serial_status_wraps']: wraps[label] = rec['serial_status_wraps']
    require(clone_log is not None and all_new <= focus.keys(), 'all49 new groups observed successfully')
    # Summary schema is explicitly supplied after the root summary exists; no inferred aliases.
    summary = PLAN['focused_summary']
    receipt = json.loads(bound(summary['binding']))
    require(receipt[summary['observations_key']] == sum(focus.values()) and
            receipt[summary['unique_key']] == len(focus) and receipt[summary['new_groups_key']] == 49,
            'root focus summary independently counted')
    commands = receipt[summary['commands_key']]
    require(len(commands) == len(focused_commands), 'all successful focus commands summarized')
    seen = set()
    for row in commands:
        require(set(row) == set(summary['row_keys']), 'exact actual summary row schema')
        label = Path(row[summary['row_log_key']]).stem
        require(label in focused_commands and label not in seen, 'unique focus summary log')
        seen.add(label)
        require(row[summary['row_passed_key']] == focused_commands[label]['totals'][0] and
                row[summary['row_sha_key']] == INPUTS[str(B / 'validation' / (label + '.log'))]['sha256'],
                'focus literal names and log binding')
    require(seen == focused_commands.keys(), 'all focused receipts retained')
    failures = []; non_test_failures = []
    for spec in PLAN['retained_failure_runs']:
        rec, rows, _, observed = tests(spec['label'], spec['exit'], spec['totals'])
        require(spec['exit'] != 0 and [n for n, status in rows if status == 'FAILED'] == spec['failed_names'],
                'complete retained failed test identities')
        failures.append(dict(label=spec['label'], command=rec['command'], totals=observed,
                             failed_names=spec['failed_names'], log_sha256=rec['sha256']))
        if rec['serial_status_wraps']: wraps[spec['label']] = rec['serial_status_wraps']
    for spec in PLAN['retained_non_test_failures']:
        rec, log = command('validation/' + spec['label'] + '.json', spec['exit'])
        require(spec['exit'] != 0 and all(t in log for t in spec['required_literals']) and
                not re.search(r'^test result:', log, re.M), 'compiler/gate failure retained without invented test result')
        non_test_failures.append(dict(label=spec['label'], command=rec['command'], exit=rec['exit'],
                                     required_literals=spec['required_literals'], log_sha256=rec['sha256']))
    require(receipt[summary['failures_key']] == sum(r['totals'][1] for r in failures), 'failed test observations retained')
    diagnostic = PLAN['bootstrap_diagnostic']
    require(diagnostic['literal'] in clone_log, 'actual announced bootstrap literal')
    for label in diagnostic['other_logs']:
        require(diagnostic['literal'] in raw('validation/' + label + '.log').decode(), 'additional diagnostic observation')
    gates = {}
    for label in PLAN['gates']:
        rec, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(rec['command'][-2:] == ['-D', 'warnings'] and '--all-targets' in rec['command'], 'strict Clippy')
        if label.startswith('release'):
            require('--release' in rec['command'] and '--bin' in rec['command'] and 'eris-js' in rec['command'], 'release build')
        gates[label] = rec['command']
    full = {}
    for spec in PLAN['full_runs']:
        rec, rows, _, observed = tests(spec['label'], 0, [spec['passed'], 0, 0])
        argv = rec['command']
        require('--include-ignored' in argv and '--test-threads=4' in argv, 'full command flags')
        require(all_new <= {n for n, _ in rows}, 'all49 new groups in each full suite')
        if spec['feature']:
            require('--features' in argv and spec['feature'] in argv, 'native feature')
        else: require('--features' not in argv, 'default feature')
        full[spec['label']] = dict(command=argv, totals=observed)
    require(len(full) == 2 and {r['feature'] for r in PLAN['full_runs']} == {None, 'vulkan-raster'}, 'both full suites')
    permitted = set(PLAN['focused_labels'] + PLAN['gates'] + list(full) +
                    [r['label'] for r in failures + non_test_failures])
    setup = read('validation/source-ready.json')
    require(INPUTS[str(B / 'validation/source-ready.json')]['sha256'] == PLAN['validation_hold_sha256'], 'runner hold')
    for row in setup['files']: bound(row)
    observed_labels = {p.stem for p in (B / 'validation').glob('*.json') if p.name != 'source-ready.json'}
    require(observed_labels == permitted, 'unreviewed validation attempts: ' + repr(observed_labels ^ permitted))
    return dict(full=full, new_groups=49, node_clone_filter_groups=48, separate_storage_test=storage,
                all_new_group_names=sorted(all_new),
                all_attempt_passing_observations=sum(focus.values()) + sum(r['totals'][0] for r in failures),
                all_attempt_failures=sum(r['totals'][1] for r in failures),
                focused_observations=sum(focus.values()), focused_unique=len(focus),
                focused_commands=focused_commands, successful_gates=gates,
                retained_failure_runs=failures, retained_non_test_failures=non_test_failures,
                bootstrap_diagnostic=diagnostic, serial_status_wraps=wraps,
                exact_corrected_paths=corrected_paths, source_manifest_sha256=SOURCE)


OUTCOMES = {'status', 'observation', 'reason', 'stderr', 'matches_expectation', 'matches_implementation_policy',
            'verified', 'verified_with_protocol_prerequisite', 'positive_partner_matches'}


def key(row):
    row = row.get('result', row)
    return row['id'], row.get('mode', '')


def inputs(row):
    if 'result' in row:
        return {**{k: v for k, v in row.items() if k not in {'result', 'verified'}}, 'result': inputs(row['result'])}
    return {k: v for k, v in row.items() if k not in OUTCOMES}


def healthy(row):
    if 'result' in row:
        return row.get('verified') is True and row['result'].get('status') == row['expected']
    if 'expected_observation' not in row:
        return row.get('status') == 'passed'
    observation = row.get('observation', {})
    return (isinstance(observation, dict) and all(observation.get(k) == v for k, v in row['expected_observation'].items())
            and row.get('matches_expectation') is True and row.get('verified', True) is True
            and row.get('verified_with_protocol_prerequisite', True) is True)


def complete_rows(before, after):
    old, new = {key(r): r for r in before}, {key(r): r for r in after}
    require(len(old) == len(before) and len(new) == len(after) and old.keys() == new.keys(), 'row identity/population')
    result = dict(before_total=len(before), after_total=len(after), before_healthy=sum(map(healthy, before)),
                  after_healthy=sum(map(healthy, after)), unchanged=0, gains=0, losses=0, other_changes=0)
    changes = []
    for identity, a in old.items():
        b = new[identity]
        require(inputs(a) == inputs(b), 'row inputs changed: ' + repr(identity))
        if a == b:
            result['unchanged'] += 1
            continue
        category = 'gains' if not healthy(a) and healthy(b) else 'losses' if healthy(a) and not healthy(b) else 'other_changes'
        result[category] += 1
        changes.append(dict(id=identity[0], mode=identity[1], classification=category, before=a, after=b))
    return result, changes


def comparisons():
    prior_release = read('comparison-preparation/before/release.json')
    require(prior_release['sha256'] == BASE_BINARY, 'baseline release binding')
    bound(prior_release)
    release = read('release.json')
    require(release['sha256'] == CANDIDATE and release['bytes'] > 0 and release['source_manifest_sha256'] == SOURCE, 'release binding')
    bound(release)
    require(release['source_manifest'] == 'candidate-source-final.json' and release['build_receipt'] == 'validation/release-adapter-188-1.json', 'release source/build')
    comparison_dir = B / 'comparison-preparation'
    final_hold_bytes = raw(comparison_dir / 'source-ready-final.json')
    require(hashlib.sha256(final_hold_bytes).hexdigest() ==
            'bf1245140c01801f8e73db67339f3c3c1bbb05e34d54ee415d0174c00c79b6a3', 'final193-input comparison hold')
    final_hold = json.loads(final_hold_bytes)
    for value in final_hold.values():
        if isinstance(value, dict) and {'path', 'sha256'} <= value.keys(): bound(value)
    pending_path = comparison_dir / 'input-manifest-correction/initial/compare-clone.py'
    pending_hold = json.loads(bound(final_hold['original_pending_hold']))
    for row in pending_hold['files']:
        held = {**row, 'path': str(pending_path)} if row['path'] == str(comparison_dir / 'compare-clone.py') else row
        bound(held)
    correction = json.loads(bound(final_hold['one_sentinel_binding_receipt']))
    require(bound(correction['before']) == raw(pending_path) and
            bound(correction['after']) == raw(comparison_dir / 'compare-clone.py'), 'comparator exact images')
    pending = raw(pending_path)
    marker = b"INPUT_SHA='PENDING_CLONE_FINAL_COMPARISON_INPUT_MANIFEST'"
    manifest_sha = hashlib.sha256(raw(comparison_dir / 'compare-clone-inputs.json')).hexdigest()
    require(pending.count(marker) == 1 and
            pending.replace(marker, ("INPUT_SHA='" + manifest_sha + "'").encode()) == raw(comparison_dir / 'compare-clone.py'),
            'only exact input digest substitution after pending hold')
    require(len(read(comparison_dir / 'compare-clone-inputs.json')['files']) == 193, 'actual final input population')
    checks = json.loads(bound(final_hold['verification']))['commands']
    require(len(checks) == 3, 'finalizer and both independent before checks retained')
    for helper, record in zip(['finalize-inputs.py', 'compare-clone.py', 'classify-inventory.py'], checks):
        expected = ['python3', str(comparison_dir / helper)] + ([] if helper == 'finalize-inputs.py' else ['--verify-before'])
        require(record['argv'] == expected and record['exit'] == 0, 'actual inert binding command')
        data = bound(record['log'])
        if helper != 'finalize-inputs.py': require(json.loads(data)['verified_before'] is True, 'before-check output')
        COMMANDS['comparison-preparation/final-inert-verification.json#' + helper] = record
    for manifest in ['compare-clone-inputs.json', 'before-comparison-inputs.json']:
        for row in read(comparison_dir / manifest)['files']:
            data = bound(row)
            if 'original' in row:
                require(data == raw(row['original']), 'original copy: ' + row['path'])
    comparison = read('clone-comparison.json')
    require(not comparison['validation_failures'] and comparison['candidate']['sha256'] == CANDIDATE, 'comparison status')
    require(bound(comparison['comparator']) == raw(comparison_dir / 'compare-clone.py') and
            bound(comparison['input_manifest']) == raw(comparison_dir / 'compare-clone-inputs.json'),
            'comparison helper and final manifest cross-binding')
    require(len(comparison['profiles']) == 21, 'profile count')
    require({p['profile'] for p in comparison['profiles']} == {
        'dom-method-identity', 'object-is', 'symbols', 'array-descriptors', 'reflect-construction',
        'prior-CharacterData', 'prior-PI', 'prior-production', 'node-original', 'node-exact',
        'append-exact', 'document-title', 'node-constants', 'text-operations', 'node-normalize',
        'node-predicates', 'node-root', 'node-equality', 'node-connected', 'node-position', 'node-clone'}, 'exact profile identities')
    profile_files = dict(zip(
        ['dom-method-identity','object-is','symbols','array-descriptors','reflect-construction',
         'prior-CharacterData','prior-PI','prior-production','node-original','node-exact','append-exact',
         'document-title','node-constants','text-operations','node-normalize','node-predicates','node-root','node-equality','node-connected','node-position','node-clone'],
        ['dom-method-identity-after.json','object-is-after.json','symbols-after.json','array-descriptors-after.json',
         'reflect-construction-after.json','local-after.json','pi-regression-after.json','production-after.json',
         'original-after.json','exact-after.json','append-after.json','title-after.json','node-constants-after.json',
         'text-after.json','normalize-after.json','predicates-after.json','root-after.json','equality-after.json','connected-after.json','position-after.json','clone-after.json']))
    totals = {'established': {'cases': Counter(), 'controls': Counter()}, 'new': {'cases': Counter(), 'controls': Counter()}}
    all_changes = []; reports = {}
    for profile in comparison['profiles']:
        filename = profile_files[profile['profile']]
        before_file = 'clone-before.json' if profile['profile'] == 'node-clone' else 'comparison-preparation/before/' + filename
        require(profile['group'] == ('new' if profile['profile'] == 'node-clone' else 'established'), 'profile group')
        require(raw(before_file) == bound(profile['before']) and raw(filename) == bound(profile['after']), 'canonical profile report cross-binding')
        a = json.loads(bound(profile['before'])); b = json.loads(bound(profile['after']))
        require(a['binary_sha256'] == BASE_BINARY and b['binary_sha256'] == CANDIDATE, 'raw binary binding')
        require(not b.get('binding_failures'), 'raw binding failure')
        require(not profile['header_input_changes'], 'header drift')
        for header in set(a) | set(b):
            if (header.endswith('_sha256') and header != 'binary_sha256') or header in {'bounds', 'harness', 'tool_hashes', 'revision', 'runner_policy', 'mode_cases', 'bound_inputs'}:
                require(a.get(header) == b.get(header), 'raw input header: ' + header)
        reports[profile['profile']] = (a, b)
        for kind in ['cases', 'controls']:
            left = a[kind] if kind in a else a.get('harness_preflight', [])
            right = b[kind] if kind in b else b.get('harness_preflight', [])
            stats, changes = complete_rows(left, right)
            actual = profile[kind]
            unwrap = lambda row: row.get('result', row)
            require(actual['before_status_counts'] == dict(Counter(unwrap(r).get('status') for r in left)) and
                    actual['after_status_counts'] == dict(Counter(unwrap(r).get('status') for r in right)), 'raw status counts')
            require(all(actual[k] == v for k, v in stats.items()) and actual['changes'] == changes, 'complete-row reconstruction')
            require(not actual['added'] and not actual['removed'] and not actual['input_changes'], 'raw population drift')
            totals[profile['group']][kind].update(stats)
            all_changes.extend(dict(profile=profile['profile'], kind=kind, **r) for r in changes)
    require(totals == comparison['summary'], 'summary reconstructed from complete raw rows')
    policy = read('comparison-preparation/anticipated-inventory-changes.json')
    expected = {(r['kind'], r['id'], r['mode']): r for r in policy['rows']}
    historical = [r for r in all_changes if r['profile'] != 'node-clone']
    require(len(historical) == 6, 'exact historical change count')
    for row in historical:
        require(row['profile'] == 'node-position', 'unanticipated established profile')
        expected_row = expected.pop((row['kind'], row['id'], row['mode']))
        require(row['classification'] == 'losses' and row['before'] == expected_row['before'], 'historical identity/health')
        after = row['after']
        require(after['status'] == 'failed' and after['matches_expectation'] is False, 'retained raw failure')
        require(all(after['observation'].get(k) == v for k, v in expected_row['expected_after_observation'].items()), 'Error versus TypeError')
        if row['kind'] == 'controls':
            require(after['verified'] is False and after['positive_partner_matches'] is False, 'no control-health waiver')
    require(not expected, 'all expected historical changes reached')
    require(len(policy['already_unhealthy_unchanged']) == 36, 'older unhealthy population')
    for row in policy['already_unhealthy_unchanged']:
        require(row['profile'] in {'node-constants', 'node-normalize', 'node-predicates', 'node-root', 'node-equality', 'node-connected'}, 'older profile identity')
        old_before, old_after = reports[row['profile']]
        wanted = row['before']
        require([r for r in old_before[row['kind']] if key(r) == key(wanted)] == [wanted], 'older before binding')
        require([r for r in old_after[row['kind']] if key(r) == key(wanted)] == [wanted] and not healthy(wanted), 'older unhealthy row changed')
    new_before, new_after = reports['node-clone']
    frozen = read(PREP / 'replay/replay-matrix.json')
    frozen_rows = {r['id']: r for r in frozen['rows']}
    matrix_sha = INPUTS[str(PREP / 'replay/replay-matrix.json')]['sha256']
    for report in [new_before, new_after]:
        require(report['matrix_sha256'] == matrix_sha and report['bound_inputs'] == frozen['bound_inputs'],
                'clone raw report frozen input/matrix binding')
        for header in ['fixture_sha256', 'inventory_sha256', 'replay_sha256', 'runner_sha256', 'bounds']:
            require(report[header] == frozen[header], 'clone raw header: ' + header)
        rows = report['cases'] + report['controls']
        require(len(rows) == 50 and len({r['id'] for r in rows}) == 50 and
                {r['id'] for r in rows} == frozen_rows.keys(), 'all clone source identities retained')
        for row in rows:
            identity = frozen_rows[row['id']]
            require({k: row[k] for k in identity} == identity, 'raw row literal-mode source binding')
    require([sum(map(healthy, r[k])) for r in [new_before, new_after] for k in ['cases', 'controls']] == [0, 4, 34, 16], 'new ordinary and paired control health')
    current_profile = next(p for p in comparison['profiles'] if p['profile'] == 'node-clone')
    require(raw('clone-after.json') == bound(current_profile['after']), 'current oracle raw report cross-binding')
    require(new_after['binary_sha256'] == CANDIDATE, 'current oracle candidate cross-binding')
    for kind, count, before_health, after_health, losses in [
        ('cases', 4396, 4298, 4296, 2), ('controls', 540, 516, 512, 4)]:
        stats = totals['established'][kind]
        require(stats['before_total'] == stats['after_total'] == count, 'established population')
        require(stats['before_healthy'] == before_health and stats['after_healthy'] == after_health, 'raw established health')
        require(stats['unchanged'] == count-losses and stats['losses'] == losses and
                stats['gains'] == stats['other_changes'] == 0, 'only exact established losses')
    for kind, count, before_health in [('cases', 34, 0), ('controls', 16, 4)]:
        stats = totals['new'][kind]
        require(stats['before_total'] == stats['after_total'] == stats['after_healthy'] == count,
                'new complete population')
        require(stats['before_healthy'] == before_health and stats['gains'] == count-before_health and
                stats['unchanged'] == before_health and stats['losses'] == stats['other_changes'] == 0,
                'new exact gains and unchanged controls')
    for report in [new_before, new_after]:
        controls = {r['id']: r for r in report['controls']}
        for row in report['controls']:
            partner = controls[row['partner']]
            require(partner['positive'] is True and partner['mode'] == row['mode'] and
                    partner['pair'] == row['pair'], 'same-mode positive partner')
            def observation_matches(r):
                observation = r.get('observation', {})
                return isinstance(observation, dict) and all(observation.get(k) == v for k, v in r['expected_observation'].items())
            matches = observation_matches(row)
            partner_matches = observation_matches(partner)
            require(row['matches_expectation'] is matches and row['positive_partner_matches'] is partner_matches,
                    'independent raw control matches')
            require(row['verified'] is (matches and partner_matches), 'independent paired control health')
    for mode in ['sloppy', 'strict']:
        case = next(r for r in new_after['cases'] if r['id'] == 'represented_complete_key_order#' + mode)
        require(healthy(case), 'current pristine inventory')
        for variant in ['positive', 'wrong']:
            control = next(r for r in new_after['controls'] if r['id'] == 'represented-node-order-' + variant + '#' + mode)
            require(healthy(control) and control['positive_partner_matches'] is True, 'current reflected-order pair')
    annotation = read('inventory-classification.json')
    require(annotation['comparison_sha256'] == INPUTS[str(B / 'clone-comparison.json')]['sha256'], 'annotation comparison binding')
    require(annotation['policy_sha256'] == INPUTS[str(B / 'comparison-preparation/anticipated-inventory-changes.json')]['sha256'], 'annotation policy binding')
    require(annotation['expected_case_losses'] == 2 and annotation['expected_unhealthy_controls'] == 4 and annotation['unexpected_established_changes'] == 0, 'annotation totals')
    require(annotation['classifier_sha256'] == hashlib.sha256(raw(comparison_dir / 'classify-inventory.py')).hexdigest(),
            'annotation classifier source binding')
    aggregate = read('replay-execution.json')
    require(aggregate['exit'] == 1 and aggregate['command'] == ['python3', str(B / 'replay-jobs.py')], 'root-observed aggregate exit')
    COMMANDS['replay-execution.json'] = aggregate
    for label, expected_exit in [('comparison', 0), ('classification', 0)]:
        command(label + '-command.json', expected_exit)
    replay_receipts = sorted(B.glob('*-replay-command.json'))
    require(len(replay_receipts) == 21, 'replay command population')
    for path in replay_receipts:
        command(path.name, 1 if path.name in {'node-constants-replay-command.json', 'node-normalize-replay-command.json', 'node-predicates-replay-command.json', 'node-root-replay-command.json', 'node-equality-replay-command.json', 'node-connected-replay-command.json', 'node-position-replay-command.json'} else 0)
    for profile in ['symbols', 'array-descriptors', 'reflect-construction']:
        command(profile + '-command.json', 0)
    baseline_record, _ = command('baseline-execution.json', 1)
    require(baseline_record['command'] == ['python3', str(PREP / 'replay/replay.py'),
            str(Path(prior_release['path'])), BASE_BINARY, str(B / 'clone-before.json')], 'actual baseline command')
    for row in read('replay-supervisor-ready.json')['files']:
        bound(row)
    expected_commands = {p.name for p in replay_receipts} | {p + '-command.json' for p in [
        'symbols', 'array-descriptors', 'reflect-construction', 'comparison', 'classification']}
    actual_commands = {p.name for p in B.glob('*-command.json')}
    require(actual_commands == expected_commands, 'unreviewed command receipt inventory: ' + repr(actual_commands ^ expected_commands))
    return dict(summary=comparison['summary'], profiles=21, complete_historical_changes=historical,
                preserved_older_unhealthy_rows=36, aggregate_exit=1, comparison_exit=0, classifier_exit=0,
                release_sha256=CANDIDATE, aggregate_receipt='replay-execution.json',
                aggregate_capture_limit='Root-observed aggregate exit is retained; complete stdout/stderr hashes belong to all21 individual job logs, not an invented aggregate log.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True, help='Actual announced release SHA256; no engine is run.')
    parser.add_argument('--source-sha256', required=True, help='Actual announced final source manifest SHA256.')
    parser.add_argument('--validation-plan', type=Path, required=True)
    parser.add_argument('--validation-plan-sha256', required=True)
    args = parser.parse_args()
    global CANDIDATE, SOURCE, PLAN
    require(re.fullmatch(r'[0-9a-f]{64}', args.binary_sha256), 'invalid release SHA256')
    CANDIDATE = args.binary_sha256
    require(re.fullmatch(r'[0-9a-f]{64}', args.source_sha256), 'invalid source SHA256')
    SOURCE = args.source_sha256
    require(not args.output.exists(), 'audit output must be new')
    report = dict(status='incomplete', findings=[], execution='Only byte/JSON/log parsing; no engine, compiler, helper import or subprocess.')
    try:
        raw(Path(__file__))
        plan_bytes = raw(args.validation_plan.resolve())
        require(hashlib.sha256(plan_bytes).hexdigest() == args.validation_plan_sha256, 'validation plan binding')
        PLAN = json.loads(plan_bytes)
        require(PLAN['status'] == 'final announced results ready for independent audit', 'validation remains explicitly pending')
        report['frozen_inputs'] = frozen_inputs()
        report['validation'] = validation()
        report['comparison'] = comparisons()
        for path, expected in list(INPUTS.items()):
            data = Path(path).read_bytes()
            require(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) == expected, 'post-audit input drift: ' + path)
        report['status'] = 'clear'
    except Exception as error:
        report['status'] = 'failed'
        report['findings'].append(dict(type=type(error).__name__, message=str(error)))
    report['commands'] = COMMANDS
    report['nonzero_commands'] = {p: r for p, r in COMMANDS.items() if r['exit'] != 0}
    report['inputs'] = [{'path': path, **binding} for path, binding in sorted(INPUTS.items())]
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k not in {'inputs', 'comparison', 'commands'}}, indent=2))
    return 0 if report['status'] == 'clear' else 1


if __name__ == '__main__':
    raise SystemExit(main())
