from pathlib import Path
w=Path('/tmp/eris-node-clone-1/worktree')
def edit(name,old,new,count=1):
 p=w/name;s=p.read_text();assert s.count(old)==count,(name,old,s.count(old));p.write_text(s.replace(old,new))
edit('src/script.rs','mod node_connected;','mod node_clone;\nmod node_connected;')
edit('src/script.rs','                    "cloneNode" => return self.dom_method(key, false),\n','')
p=w/'src/script.rs';s=p.read_text();a=s.index('    fn clone_dom_node(');b=s.index('    // Native callbacks, constructors',a);removed=s[a:b];(Path('/tmp/eris-node-clone-1/runtime')/'removed-legacy-clone.rs.txt').write_text(removed);p.write_text(s[:a]+s[b:])
edit('src/script/node_data.rs','''                if method == "normalize" {
                    return self.node_normalize(receiver, doc);
                }
''','''                if method == "normalize" {
                    return self.node_normalize(receiver, doc);
                }
                self.work(9)?;
                if method == "cloneNode" {
                    return self.node_clone_node(receiver, args, doc);
                }
''')
edit('src/script/dom_prototypes.rs','BOOTSTRAP_OBJECTS: usize = 352','BOOTSTRAP_OBJECTS: usize = 351')
edit('src/script/dom_prototypes.rs','    + node_connected::METADATA_OBJECTS','    + node_clone::METADATA_OBJECTS\n    + node_connected::METADATA_OBJECTS')
edit('src/script/dom_prototypes.rs','"Node" => 10,','"Node" => 11,')
edit('src/script/dom_prototypes.rs','                self.install_node_normalize(prototype)?;','                self.install_node_normalize(prototype)?;\n                self.install_node_clone(prototype)?;')
edit('src/script/dom_prototypes/node_constants.rs','PROTOTYPE_OLD: usize = 11','PROTOTYPE_OLD: usize = 12')
edit('src/script/dom_prototypes/node_constants.rs','N=29 has height','N=30 has height')
edit('src/script/dom_prototypes/node_constants.rs','right leaf has five pairs','right leaf has six pairs')
edit('src/script/dom_prototypes/node_constants.rs','            ExpectedKey::Text("compareDocumentPosition"),','            ExpectedKey::Text("cloneNode"),\n            ExpectedKey::Text("compareDocumentPosition"),',1 if False else 2)
# Above inserted clone before compare in both sorted/order; move order occurrence to required post-normalize slot.
p=w/'src/script/dom_prototypes/node_constants.rs';s=p.read_text();a=s.index('    let order:');head=s[:a];tail=s[a:];tail=tail.replace('            ExpectedKey::Text("cloneNode"),\n','');tail=tail.replace('            ExpectedKey::Text("normalize"),','            ExpectedKey::Text("normalize"),\n            ExpectedKey::Text("cloneNode"),');p.write_text(head+tail)
edit('src/script/dom_bindings.rs','    ("DOM.cloneNode", 0),\n','')
edit('src/script/dom_bindings/identity_tests.rs','        ("DOM.cloneNode", 0),\n','')
edit('src/script/dom_bindings.rs','"appendChild" | "removeChild" | "cloneNode" => node.is_some(),','"appendChild" | "removeChild" => node.is_some(),')
edit('src/script/dom_bindings.rs','"append" | "remove" | "cloneNode" | "createDocumentFragment"','"append" | "remove" | "createDocumentFragment"')
edit('src/script/dom_bindings.rs','''            "cloneNode" => self
                .clone_dom_node(id, arg(0).truthy(), doc)
                .map(Value::Node),
''','')
edit('src/script/dom_prototypes/node_constants/tests.rs','if owner == prototype { 30 } else { 21 }','if owner == prototype { 31 } else { 21 }')
edit('src/script/dom_prototypes/node_constants/tests.rs','if owner == prototype { 11 } else { 3 }','if owner == prototype { 12 } else { 3 }')
edit('src/script/dom_prototypes/node_constants/tests.rs','runtime.objects[prototype].values.len(), 29','runtime.objects[prototype].values.len(), 30')
edit('src/script/node_data/tests.rs',"keys[4]!=='hasChildNodes'||keys[5]!=='normalize'||keys[6]!=='isEqualNode'||\n           keys[7]!=='isSameNode'||keys[8]!=='compareDocumentPosition'||keys[9]!=='contains'||keys[10]!=='ELEMENT_NODE'||", "keys[4]!=='hasChildNodes'||keys[5]!=='normalize'||keys[6]!=='cloneNode'||keys[7]!=='isEqualNode'||\n           keys[8]!=='isSameNode'||keys[9]!=='compareDocumentPosition'||keys[10]!=='contains'||keys[11]!=='ELEMENT_NODE'||")
# Preserve every frozen oracle. Extend each existing disposable inventory wrapper with its own saved clone descriptor.
for name in ['dom_prototypes/node_constants','node_normalize','node_predicates','node_root','node_equality','node_connected']:
 p=w/f'src/script/{name}/tests.rs';s=p.read_text();a=s.index('fn prior_');b=s.index('\n#[test]',a);t=s[a:b]
 start='const clone=Object.getOwnPropertyDescriptor(Node.prototype,\'cloneNode\');\n          if(!clone||typeof clone.value!==\'function\'||!clone.writable||!clone.enumerable||!clone.configurable)throw new Error(\'clone descriptor\');\n          '
 assert t.count('try{{')==1
 t=t.replace('try{{',start+'try{{\n            if(!delete Node.prototype.cloneNode)throw new Error(\'clone delete\');')
 assert t.count('finally{{')==1
 t=t.replace('finally{{',"finally{{\n            Object.defineProperty(Node.prototype,'cloneNode',clone);")
 assert t.count('return true;')==1
 t=t.replace('return true;',"const restoredClone=Object.getOwnPropertyDescriptor(Node.prototype,'cloneNode');\n          if(restoredClone.value!==clone.value||restoredClone.writable!==clone.writable||restoredClone.enumerable!==clone.enumerable||restoredClone.configurable!==clone.configurable)throw new Error('clone restoration');\n          return true;")
 t=t.replace('new position fixture','new clone fixture')
 p.write_text(s[:a]+t+s[b:])
p=w/'tests/fixtures/node-clone.js';p.write_bytes(Path('/tmp/eris-node-clone-preparation-1/independent/cases.js').read_bytes())
