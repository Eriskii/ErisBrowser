# Object.hasOwn measured accounting reconciliation

The original frozen ledger and source hold remain unchanged. The predicted owner insertion subtotal was an addition error: its written terms20key +140search +800movement +1order sum to961, not941. All terms match the source; no fee was missing from the implementation. The corrected total is239+9+20+29+31+21+961=1310work, not1290.

Root first Object.hasOwn run passed all17groups and printed4709remaining/1782581allocated/690objects and capacity/320native/25legacy. Against the actual clone predecessor6019/1775064/689, this is1310work/7517bytes/1object. The original predicted bytes and counts match. Owner entries21/order21/capacity32 confirm the no-order-growth assumption. Types Native56, metadata8, K16, E72, B1472 and ScriptObject216 match the held typed formula.

This is an additive arithmetic correction after observing the first diagnostic. It makes no production, test expectation, bootstrap literal or fixture change. The original4729remaining prediction and1290work total are retained in source-ready.json/ledger.md, along with the peer review that repeated that subtotal. Root owns any measured descriptive snapshot update.
