"""Freeze the separate Object.hasOwn replay; source/data operations only."""
from pathlib import Path
import hashlib, json, difflib, ast

B = Path('/tmp/eris-node-clone-1')
OWN = B/'object-has-own'
HERE = OWN/'replay'
PREVIOUS = Path('/tmp/eris-node-clone-preparation-1/replay')
HERE.mkdir()

def sha(data): return hashlib.sha256(data).hexdigest()
def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('xb') as stream: stream.write(data)
def dump(path, data): write(path, (json.dumps(data, indent=2)+'\n').encode())
def binding(path):
    data=path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

independent=OWN/'independent'
ready=json.loads((independent/'source-ready.json').read_text())
for row in ready['files']:
    data=Path(row['path']).read_bytes()
    assert sha(data)==row['sha256'] and len(data)==row['bytes']
fixture=(independent/'cases.js').read_bytes()
assert sha(fixture)=='4cfdacc069d83792f20d4be1efec38b91ab748114eadef1b04c46e306ce3053f'
inv=json.loads((independent/'inventory.json').read_text())
assert inv['collection']=='objectHasOwnCases' and len(inv['cases'])==8
history=[]
def copy(source, relative):
    data=source.read_bytes();write(HERE/relative,data)
    history.append(dict(origin=str(source),copy=relative,bytes=len(data),sha256=sha(data)))

for name in ['cases.js','inventory.json','README.md','source-ready.json']:
    copy(independent/name,'independent/'+name)
for name in ['test262_conformance.py','html_conformance.py','import_test262.py']:
    copy(PREVIOUS/'tools'/name,'tools/'+name)
for name in ['replay.py','replay-inputs.json','replay-matrix.json','source-ready.json','driver-transformation.json']:
    copy(PREVIOUS/name,'history/clone-'+name)
for name in ['plan.md','ledger.md','before.json','pre-production-ready.json','draft/tests.rs']:
    copy(OWN/name,'history/object-has-own/'+name)
for name in ['base.json','position-ci.json','clone-before.json','baseline-execution.json','baseline-review.json']:
    copy(B/name,'history/clone-context/'+name)
copy(Path('/tmp/eris-node-position-1/release.json'),'history/published-release.json')
copy(B/'object-has-own-layout/assessment.json','history/layout-assessment.json')

complete=dict(status='complete',phase='runtime',error_type='',error_identity='')
wrong=dict(status='exception',phase='runtime',error_type='Error',error_identity='Error')
previous_inputs=json.loads((PREVIOUS/'replay-inputs.json').read_text())
controls=previous_inputs['controls'][:2]
assert all(row['pair']=='literal-units' for row in controls)
positive="var method=Object.hasOwn;if(typeof method!=='function')throw new TypeError('Object.hasOwn callable prerequisite');var parent={inherited:1},target=Object.create(parent),reads=0;target.own=undefined;Object.defineProperty(target,'accessor',{get:function(){reads++;throw new TypeError('getter must not run');},configurable:true});if(method.call(null,target,'own')!==true||method(target,'inherited')!==false||method(target,'missing')!==false||method(target,'accessor')!==true||reads!==0)throw new TypeError('actual own-descriptor prerequisite');"
for yes in [True,False]:
    source=positive+('' if yes else "throw new Error('deliberately wrong expectation');")
    controls.append(dict(name='has-own-descriptor-'+('positive' if yes else 'wrong'),pair='has-own-descriptor',
                         positive=yes,area='feature',modes=['sloppy','strict'],source=source,
                         source_sha256=sha(source.encode()),expected_observation=complete if yes else wrong))
dump(HERE/'controls.json',dict(controls=controls,scope='Separate Object.hasOwn source oracles; never added to clone comparison totals'))
history.append(dict(origin=str(HERE/'controls.json'),copy='controls.json',**{k:v for k,v in binding(HERE/'controls.json').items() if k!='path'}))
inputs=dict(fixture='independent/cases.js',fixture_sha256=sha(fixture),collection='objectHasOwnCases',
            cases=[dict(name=n,modes=['sloppy','strict'],expected_observation=complete) for n in inv['cases']],
            controls=controls,case_modes=16,control_modes=8,
            case_invocation_argument_by_mode=dict(sloppy=False,strict=True))
dump(HERE/'replay-inputs.json',inputs)
dump(HERE/'preparation-history.json',history)

before=(PREVIOUS/'replay.py').read_text()
substitutions=[
 ('Frozen Node clone observations','Frozen Object.hasOwn observations'),
 ('bf66956a6ca0e1ef138a2d634ab3c31968754415f04c4b2197a2b07e9ec63479',sha(fixture)),
 ('nodeCloneCases','objectHasOwnCases'),('node-clone.js','object-has-own.js'),
 ("len(inventory['cases']) == 17 and len(inventory['controls']) == 8", "len(inventory['cases']) == 8 and len(inventory['controls']) == 4"),
 ("(inventory['case_modes'], inventory['control_modes']) == (34, 16)","(inventory['case_modes'], inventory['control_modes']) == (16, 8)"),
 ("len(matrix) == 50 and len({case['id'] for case, _ in matrix}) == 50", "len(matrix) == 24 and len({case['id'] for case, _ in matrix}) == 24"),
 ('Frozen 34 independent case modes and 16 paired controls','Frozen 16 independent case modes and 8 paired controls')]
after=before
counts=[]
for a,z in substitutions:
    assert a in after
    counts.append(dict(before=a,after=z,occurrences=after.count(a)))
    after=after.replace(a,z)
reverse=after
for a,z in reversed(substitutions): reverse=reverse.replace(z,a)
assert reverse==before
ast.parse(after)
write(HERE/'replay.py',after.encode())
write(HERE/'replay.py.diff',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),'clone/replay.py','hasOwn/replay.py')).encode())
dump(HERE/'driver-transformation.json',dict(before=binding(PREVIOUS/'replay.py'),after=binding(HERE/'replay.py'),
     substitutions=counts,reverse_byte_exact=True,literal_boolean_invocations_unchanged=True,
     matcher_health_limits_supervision_unchanged=True,engine=False,compiler=False,javascript_parser=False))
write(HERE/'README.md',b'''# Separate Object.hasOwn replay

Eight frozen independent bodies run in fresh strict/sloppy realms (16 modes), with literal false/true arguments as in the inherited driver. The original fixture ignores that optional argument and remains a global script, preserving its global var/function/lexical distinction. The eight control modes consist of a byte-exact common UTF16 positive/wrong pair and an actual own-descriptor positive/wrong pair. Every negative requires the same-mode healthy positive partner. Missing-feature TypeError cannot satisfy an intentional Error tail.

The fixed driver location is /tmp/eris-node-clone-1/object-has-own/replay/replay.py. Use a fresh /tmp/eris-node-clone-1/has-own-before.json or has-own-after.json output. These24 rows are separate from the21-profile clone comparison. The published baseline adapter is /tmp/eris-node-position-1/eris-js, SHA f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007. Expected baseline common-control health is4; no feature baseline result is claimed here.

Only identities and explicit8/16/8/24 populations differ from the frozen clone supervisor. Reversing the recorded substitutions restores it byte-for-byte. Helpers, observed-row retention, paired-control policy, process limits, exclusive output, before/after input and binary hashing are unchanged. --prepare and --verify are inert; root owns every engine run after source review.
''')
print(json.dumps(dict(status='source prepared; no engine execution',driver=binding(HERE/'replay.py'),history_copies=len(history),case_modes=16,control_modes=8)))
