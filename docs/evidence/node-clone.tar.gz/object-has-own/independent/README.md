# Independent Object.hasOwn expectations

Eight literal bodies, sixteen fresh-realm strict/sloppy observations. This additional scope preserves every frozen clone source. Load this source globally so Window reflection distinguishes the declared var/function properties from the let binding; invoke each named body independently and require literal true. The optional mode Boolean argument may be supplied but is unused.

Each body first establishes genuine own/inherited/absent capability. The construction negative first proves Reflect.construct works on an ordinary constructor. Nullish conversion negatives use a known working method; key exceptions use exact thrown-object identity. Accessor presence never intentionally reads the getter. Expected booleans, Unicode key units, metadata and counts are literals rather than queries to a second implementation of hasOwn.

Covered branches: saved ordinary metadata/deletion/nonconstruction; target-before-key conversion and fresh callback mutation; descriptor presence without getters/target methods; primitive wrappers and UTF16 indices; array holes/accessors; Symbol/nonscalar/NUL keys and function metadata; DOM expandos versus inherited members; Window globals versus lexical bindings and exact keys.

The source does not claim Proxy/BigInt availability, Document.location or Window event-handler descriptor support, or broader reflection accounting repair. Existing explicit Unsupported boundaries belong to private tests and the implementation scope. No JavaScript parser, compiler or engine was invoked during preparation.
