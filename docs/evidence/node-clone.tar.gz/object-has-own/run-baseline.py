import datetime, hashlib, json, subprocess, time
from pathlib import Path

A = Path('/tmp/eris-node-clone-1')
argv = ['python3', str(A/'object-has-own/replay/replay.py'),
        '/tmp/eris-node-position-1/eris-js',
        'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007',
        str(A/'has-own-before.json')]
log = A/'object-has-own/baseline.log'
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
clock = time.monotonic()
with log.open('xb') as stream:
    result = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT)
record = dict(command=argv, started_utc=started, exit=result.returncode,
              elapsed_seconds=time.monotonic()-clock, log=str(log),
              sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (A/'object-has-own/baseline-execution.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record))
print(log.read_text()[:2500])
raise SystemExit(result.returncode)
