# Checked represented cloning: Document-side proposal

This is source-only preparation, not an implementation or measured result. It is
additive to the original `assessment.md` and its connected-base hold. The actual
predecessor here is published `0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`, bound by
`../root/published-base.json`. The selected scope is `../root/selected-scope.md`.
No repository file was changed; no compiler, JavaScript parser, engine, or
benchmark was executed.

## Contract and boundary

Use one internal entry point:

```text
pub(crate) Document::clone_node_checked(
    &mut self, source: NodeId, deep: bool, budget: &mut DomMutationBudget
) -> Result<NodeId, DomDataError>
```

Runtime authenticates the receiver, computes optional ToBoolean, and rejects a
Document explicitly as Unsupported. It prepays the returned Node value before
calling the helper. The agreed Runtime successful prefix is 26 work, separate
from all DOM charges below; Document refusal is 24. The helper defensively
rejects a Document source or a Document encountered through a selected edge.
Invalid selected shape, links or namespace annotations produce InvalidNode or
InvalidData; the clone-specific Runtime mapper treats both as TypeError. Exact
UTF-16 storage is never an Unsupported condition. Resource and allocation
failures remain terminal. Absolute `steps` and `allocated` are copied back on
both outcomes, with no refund or post-publication debit.

The result is a detached graph of fresh IDs in the existing arena. This retains
represented Element reachability, not complete platform cloning. Document
identity/ownership, inert owner Documents, full ordered Attr/prefix/namespace
storage, custom-element reactions, mutation observers, ShadowRoot, CDATA, form
raw/dirty/checkedness state and script already-started state remain absent or
incomplete. Those limits must remain explicit. Existing scalar String attributes
are copied exactly as stored; this does not make legacy attribute producers
exact UTF-16 producers. Runtime properties, listeners and prototype overrides
belong to old IDs and are not copied.

The desired failure contract is stronger than the old incremental helper:
before publication, every ordinary Result refusal leaves the Document, node
arena capacity, source graph, metadata indices and task queue unchanged. The
budget is consumed. This is not recovery from process OOM: BTree allocation is
still infallible in the inherited storage model.

## Why complete staging is tractable

Prepare with an immutable borrow of the Document and retain a wholly owned
`ClonePlan`. The plan contains final `Vec<Node>` values, the result offset, final
retained-byte addition, base/name byte additions, owned fresh group keys, final
toggle/tracker rows and the final sequence counter. Temporary traversal and
visited structures are dropped while preparation is still allowed to refuse.
No plan field borrows `self` at commit.

The selected clone always starts as a new detached ordinary root. Hosted
template contents are separate ordinary roots with fresh IDs. Consequently no
new valid group key shares an ordinary-root ID with an old group, and the clone
cannot change the connected base selection. Those facts eliminate an old-arena
scan and any URL parsing from this operation. They do not eliminate metered
search/insertion/growth against existing metadata maps.

Preparation performs every fallible allocation and every budget check,
including commit work, metadata map growth allowance, cleanup and final arena
growth. Only then call one `nodes.try_reserve_exact(new_count)` if actual spare
capacity is insufficient. It is the final fallible operation. There must be no
Result, callback, allocation through a fallible helper, limit check or budget
debit below it. Move planned Nodes into the reserved arena, insert the prepared
metadata rows, and assign the prepared counters. All fresh references already
contain final IDs. Infallible BTree insertion below this line has been logically
admitted and remains subject to the inherited allocator limitation.

Do not call parser create/set APIs, raw append_child, ordinary attribute
mutation hooks, or details_bulk_change_work during commit. Those paths clamp,
revalidate factory-only syntax, traverse old state, allocate unplanned buffers,
or can silently decline insertion. Do not clone the complete Document or its
old metadata maps to obtain atomicity.

## Selected graph, order and validation

Let `base = self.nodes.len()`. Planned node index `i` has final ID `base + i`,
using checked arithmetic and the existing 100,000-node bound. A cursor stack
stores only active traversal frames, rather than first pushing every child of a
wide node. A frame tracks the source, copy index, copied depth, ordinary root,
phase and next child index. Every source lookup, phase transition and edge is
paid. Node creation order follows the clone algorithm, including its template
hook, rather than the old reversed pending-stack descent.

For each selected node:

1. Validate its local represented kind and copy its own fields into staging.
   Allocate a fresh content fragment immediately for an HTML template, even
   for shallow cloning. Its host is the new template, not the source.
2. For a deep template, process the source content's children into that fresh
   fragment first. This is the template cloning hook.
3. Insert the copy into its planned ordinary parent, if any, and simulate the
   represented details insertion effect. The returned root has no parent.
4. If deep, process ordinary children in their original order. Template
   ordinary children and actual content never share a child vector or root.

The source root's old ancestry is not followed: cloning a descendant creates a
new root, and an unrelated malformed ancestor is outside this selected check.
Reached ordinary edges must have in-range IDs, the exact parent backlink, and
allowed child kinds. They cannot point to a Document or DocumentFragment;
Doctype is allowed as a selected root leaf but not as a child of the supported
non-Document containers. Text, Comment, PI and Doctype must be childless.
Fragments must have no ordinary parent. A fragment selected directly may have
a valid template host; verify that local reciprocal pair but do not follow or
copy the host. Its result is hostless. HTML templates must have a distinct,
in-range content fragment with the exact host backlink and no ordinary parent.
Other Elements must have no template_contents field.

Validate attributes at at most 1,024 entries and each namespace annotation
against the existing fixed mapping and an actual attribute key. Preserve the
stored spelling, scalar value, annotation, namespace, Doctype option fields and
force_quirks value. Do not add creation-time PI target/data validation; a PI
whose data was legally mutated to contain `?>` must still copy. Private
DomString canonical storage is already an invariant, not a reason to decode,
project or reject unmatched units.

Use one paid sparse page-bit map of reached source IDs, using the existing
equality scheme (page = ID / 64, one u64 membership mask). It catches cycles and
same-parent duplicate IDs as well as a selected template/ordinary collision.
Backlinks alone do not catch duplicates. Do not use a whole-arena bitmap or
scan all detached roots. A childless non-template source, or a shallow ordinary
container, needs no visited map or traversal stack. A shallow template can
validate its fixed two-node pair without a general visited map. Unselected
children in shallow mode are not traversed or globally audited.

Copied root depth is zero. Each ordinary edge and each template-to-content
association adds one; a content-to-child edge adds another. Accept depth 256,
refuse an attempted 257th copied edge. A shallow template still needs its empty
fragment at depth one. A directly selected hosted fragment resets to depth
zero. This follows the snapshot edge convention, not raw append_child's older
ancestor-count convention or the old clone helper's 96-level refusal.

## Exact owned data and retained bytes

Do not execute `NodeKind::clone`, String::clone, map.clone or child-vector.clone
before charging. For each borrowed String, admit the exact byte allocation and
copy work, use try_reserve_exact, then copy bytes. For DomString, add a narrow
internal fallible exact-owned-copy method in `dom/string.rs`: after caller
admission it reserves/copies the existing Scalar String or Units Vec directly,
without a canonicalization scan or presentation projection. The method remains
internal and cannot construct a different representation or share mutable data.

Own the copied tag, attribute keys/values, separate namespace keys, Doctype
strings, PI target and character-data buffer. Copy attributes through paid
borrowed iteration and paid BTree insertion; no parser normalization or free
collect/clone shortcut. Each output child vector is reserved once for its exact
selected ordinary child count. Fill it using the newly assigned IDs. No source
ID is retained as a new parent, child, host or template-content reference.

The final retained ledger is old retained bytes plus exact newly retained
payload bytes, less only attributes removed from the staged copies by their
details effects. No old or detached source bytes provide credit. Temporary
payloads later removed from a copy still consume Runtime allocation/work.
The 32 MiB retained limit applies to the final published arena; staging memory
is separately charged to the existing Runtime heap. Do not invent a smaller
per-field limit to replace a formerly truncated parser copy. Snapshot-admitted
large stored fields either copy exactly under the current budgets or refuse;
they do not silently truncate. The DOM method creates no JS String, so the JS
result-string limit is not an additional copied-payload limit.

The helper relies on the existing private Document accounting invariant for
old retained bytes and old private indices. It validates the selected graph
and touched metadata, not every public mutable arena row or all private state.
Private malformed-input tests must distinguish these scopes explicitly.

## Details, groups, toggles and base

Primary-source basis, paraphrased: DOM cloning copies attributes by appending
them, which invokes attribute-change steps with a null old value. HTML details
handles null-namespace open/name changes and insertion; name groups require a
nonempty name in the same tree. Toggle coalescing retains the first old state
and places the updated task at the latest queue position. Sources:
[DOM attribute append](https://dom.spec.whatwg.org/#concept-element-attributes-append)
and [HTML details](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element).

Therefore an `open` attribute with an empty value still queues a new copy's
closed-to-open task. Attribute copying occurs while that fresh details node is
detached and childless. Its subsequent ordinary insertion occurs before its
ordinary descendants are copied. A later copied open member of the same new
group closes itself, leaving an already inserted ancestor/earlier member open.
It can produce a coalesced closed-to-closed task; do not discard that task.

The implementation can avoid constructing transient singleton-root group-map
entries: before insertion the new details node has no ordinary descendants,
and any template content hook belongs to a separate root. Maintain a temporary
paid winner map keyed by (fresh ordinary-root ID, borrowed source name), and
simulate the insertion phases in the order above. Copy group keys into owned
plan rows only for final winners. Close only the copied open attribute on a
later conflict, with paid map removal and exact retained-byte deduction. Name
bytes count all copied HTML details name values, not just group winners.
The namespace mapping cannot annotate plain open/name, but still validate
annotations before applying these rules. BTree attribute order is not a full
ordered Attr model; under the represented hooks, copied open/name order on a
fresh childless node does not change this group result. No custom reaction
ordering claim follows from that narrower proof.

Stage toggle sequence explicitly; final winner maps alone are insufficient.
Each initially copied open contributes one conceptual event; a later insertion
closure contributes another. For each new node keep its initial old=false,
final new state, and latest sequence offset. The final task may be closed to
closed. Check `details_sequence.checked_add(event_count)` before commit rather
than permitting saturating sequence reuse. The resulting rows may leave
sequence gaps where earlier coalesced tasks were removed, matching the existing
queue model. Existing trackers, pending/running tasks and their order remain
unchanged; new final tasks follow them. Preflight the specifically inserted
group/tracker/task keys for unexpected collisions, with paid searches; this is
not a scan of the old maps.

Fresh details IDs have no summary-cache entries. Do not copy cached summary
IDs, clear old cache rows, or eagerly populate fresh caches. Fresh child links
will establish the first summary on the existing lazy lookup. Template content
name groups are independent of their host's ordinary tree.

Add the exact copied HTML base href byte lengths to base_href_bytes, including
detached/template bases as the existing aggregate does. Leave first_base,
document URL, encoding, base_tracking and connected selection unchanged. There
is no URL/encoding/IDNA call here. A later append operation retains responsibility
for its own connected base and details transitions.

## Admission ledger design

The implementation freeze must bind every concrete helper/type and its actual
fee sites. The following rows fix the architecture and reused bounds; they are
not a measured total or an instruction to lower existing successful fees.

| Operation | Required work admission | Required heap admission |
| --- | --- | --- |
| Local source/phase/edge validation | Fixed checks before each access, checked arithmetic and bounded namespace-name scans; each reached cursor transition paid | No whole-arena scratch |
| Exact field copy | Reserve setup plus complete borrowed-byte/unit read and owned write; teardown of staged field prepaid | Exact requested payload bytes; no implicit growth |
| Child vectors | Reserve setup, every new-ID store, eventual staged cleanup | Exact selected child count times size_of(NodeId) |
| Planned Nodes / active frames / final rows | Every push/pop/move and buffer cleanup; each capacity growth relocation paid | Typed requested capacity at each actual growth, not only final length |
| Borrowed BTree iteration | Existing equality bound I(n)=8+8H(n) for creation and every next including EOF; empty fast path avoids iterator | No iterator allocation |
| Attribute and namespace maps | Full-key comparison bound, insertion movement/header/growth and eventual destruction; no free clone/collect | Typed BTree block envelope for each possibly allocating insertion plus exact owned key/value bytes |
| Sparse reached-ID pages | Existing 16 setup, C+8L+4 Entry search, occupied 8, vacant 256L+32 envelope including teardown | A(q) times typed usize/u64 block, below |
| Temporary name winners | Paid searches/comparisons/insertions/iteration/destruction over selected names | Typed borrowed-key map blocks; borrowed names do not imply free comparisons |
| Final metadata commit | Prepay all searches, insertions, key moves, BTree growth, row cleanup, counter writes and Node moves before final arena reservation | Typed possible growth of old group/tracker/toggle maps plus owned group-name buffers |
| Logical published nodes | Existing 128-byte logical fee per new Node | 128 times new_count |
| Actual arena growth | Existing 1+2*old_len growth work when spare capacity is insufficient | (old_len+new_count)*size_of(Node), then one try_reserve_exact(new_count) |

Use checked add/mul everywhere. The tree bound already used by
text_replacement is C(q)=min(q,11H(q)), with H(0)=0 and H for nonempty maps
computed from repeated division of floor((q+1)/2) by six. Its search,
movement, map_nodes and push helpers can be extracted mechanically to a small
shared DOM budget module with their old callers and successful fees unchanged.
Do not equate a String-key movement bound with equality's integer-pair proof
without documenting the handle operations being counted. New typed-map rows
must explicitly include initial headers, growth and consuming cleanup; reuse
the already proved envelope where its key/value operations match, and give a
separate conservative bound otherwise.

For the approved sparse membership map, L=H(q)+1 and
Q=16*(size_of(usize)+size_of(u64))+32*size_of(usize)+64. A(q) is one at q=0,
zero at 1..10, and L thereafter. The existing vacant envelope 256L+32 includes
both split-side and insertion-suffix backlink repairs and eventual destruction.
An occupied page allocates nothing. This keeps bookkeeping selected-page-sized;
it does not promise all sparse selections fit the Runtime budget or make the
whole operation linear independently of payloads and ordered maps.

For a leaf, there is only its owned payload/Node staging and any reached arena
growth. Unrelated DOM size must not cause visited-array initialization or group
scanning. Actual relocation of a full old node arena is the deliberate
exception: it really reaches that allocation and retains its existing charge.

Every staged allocation must have its cleanup work admitted before publication
or a later refusal. Commit work cannot be charged incrementally after the
arena has grown. A test should force each final admission failure to show that
neither arena capacity nor any private metadata changed.

## Review and validation obligations before implementation handoff

Source-review the final typed ledger and prepared/commit boundary before any
compiler. Independently check that no old successful budget helper fees change
through extraction. Bind Runtime's 26-work prefix separately from DOM work.

Required private witnesses include exact shallow/deep Text/Comment/PI/Doctype,
mutated PI data, source/result independence, represented namespace annotations,
large stored fields, new template host/content IDs and hook order, hosted-root
fragment cloning, accepted ordinary and nested-template depth 256, attempted
257th edge, selected duplicates/cycles/backlink/kind failures, and shallow
unreached-tree scope. Use coherent direct links plus from_snapshot for accepted
depth inputs; raw append_child is not an oracle for that boundary.

Check source and Document capacities/retained bytes/groups/tasks/cache/base at
exact measured success and one-short work/heap cuts. Include a small exhaustive
work-cut fixture rather than an unnecessary exhaustive large-tree sweep. A
large unrelated arena with spare capacity must not change the small leaf's
selected traversal scratch; a full arena must charge real growth. Late staged
metadata refusal must still publish no Node. Host snapshots with multiple open
same-name members should preserve the source and close only later copy members.
Check the coalesced closed-to-closed event and sequence, active old task
preservation, independent template name groups, cold fresh summary caches,
unchanged connected base URL/selection and exact href/name accumulators.

Preserve the old private `disclosure_copy_group_work_is_charged_before_allocating_or_replacing_the_target`
text. Its 500-details clone refusal came from a whole-arena bound; parsing has
already closed all but one member. Root explicitly accepted that a justified
selected-graph algorithm may admit it. After concrete source-derived admission
is measured, migrate that branch to actual copied count/identity/details/source
observations and a separate calibrated one-short refusal. Do not add arbitrary
work to force the old failure, silently change expectations, or overwrite its
history. The independent real arena-growth refusal witness remains required.
Any matching old external row stays frozen and its actual change is classified.

No remaining semantic blocker to this atomic architecture was identified.
Concrete allocation/type rows and their source-first peer review remain an
implementation prerequisite, not a claim that the proposed clone is already
implemented, measured or universally standards-complete.
