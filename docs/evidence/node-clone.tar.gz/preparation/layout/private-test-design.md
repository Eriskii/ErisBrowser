# Private Document clone tests: proposed source design

Source-only design for the accepted architecture. No Rust test source,
production implementation, parser, compiler, or engine is executed or authored
by this document. The actual base remains published
`0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`. The eventual owned paths are
`src/dom/node_clone.rs`, its private tests, the internal exact-copy seam in
`src/dom/string.rs`, mechanical DOM budget extraction if needed, and module
declarations in `src/dom.rs`.

Names below are proposed groups, not a claim that an implementation already
contains this number of tests. Final grouping can consolidate shared setup;
the specified independent observations must remain. Runtime owns the separate
brand/Boolean/Document Unsupported/dispatch/metadata/VM tests.

## Common host setup and observation helpers

- `budget()` uses the current 100,000 work and 8 MiB heap limit. Tests may supply
  a nonzero initial allocated value (37) to distinguish absolute counters from
  accidental refunds or resets. Generous private-only overflow fixtures must
  be labelled and do not assert ordinary Runtime quota feasibility.
- `exact(units)` uses the existing exact owned DomString constructor in setup.
  Expected arrays are independent literals. Never compute expected copy data
  using the new clone helper, a serializer, display projection or isEqualNode.
- `admit(nodes, root)` uses Document::from_snapshot to recompute the retained
  ledger and validate coherent host inputs. Direct reciprocal setup is allowed
  before that call. Deliberately malformed variants are introduced only after
  an admitted base, with each changed edge stated explicitly.
- `state(doc)` captures `format!("{doc:?}")` for every logical Document field,
  node-arena capacity, all child-vector capacities and nonempty old payload
  addresses. It must borrow the existing summary map directly, not invoke
  first_summary or any other mutating/cache-populating getter. This is a
  logical-state and arena/child-capacity oracle, not a claim to observe private
  BTree allocator capacity or all process allocations. String capacities for
  directly accessible Element/Doctype/PI String fields can also be retained.
- On success, capture the complete old node prefix before copying, and compare
  it afterward independently of the expected new nodes. Private metadata
  requires old-row equality plus explicit expected added rows, rather than
  whole-Document equality (new nodes and new tasks intentionally exist).
- To force actual node-arena growth, rebuild the existing arena through a
  boxed slice into a Vec and assert `capacity == len`. For spare capacity,
  reserve the exact required additional count outside the measured operation
  and assert available spare space before invoking it. Recreate this condition
  for each run; Document::clone does not preserve Vec spare capacity.
- Measured cost determines an endpoint, not semantics: first assert literal
  successful graph/data/task expectations, then retain consumed work and
  allocated bytes. A fresh equivalent fixture must succeed at that exact cost
  and refuse at one less work or one less heap. All refusal assertions compare
  the full small-fixture state and capacities.

## Proposed groups and fixed semantic expectations

| Proposed test group | Setup and independent observations |
| --- | --- |
| `exact_leaves_are_fresh_and_preserve_representation` | Empty Scalar, Scalar `A🚀B`, Units `[55296,56320,55296]`, Comment `[56320,13,10,0]`, PI target `Build` with mutated data `[63,62,55296,0]`; shallow and deep leaves each add one detached childless node with fresh ID. Nonempty buffers have different addresses, source arrays remain literal, and changing a copied leaf does not change source or another copy. Include Doctype None versus Some(empty) identifiers and force_quirks as stored fields. |
| `stored_element_fields_copy_without_parser_reconstruction` | Snapshot-admitted HTML tag longer than 256 bytes with spelling parser creation would normalize, long scalar attribute/Doctype fields (bounded kilobytes), empty attribute values, SVG adjusted names, MathML namespace and all represented namespace annotations. Inspect NodeKind fields/annotations directly. Original fields and copied fields are byte-exact; invalid annotation cases belong to a separate refusal group. No field is truncated or made into a JS String. |
| `deep_clone_preserves_order_empty_segmentation_and_source_links` | Detached container with Text A, empty Text, Comment, nested Element/Text and PI; move one old child before cloning so source ID order differs from allocation order. Literal expected order, fresh descendants, reciprocal new links, original links, node count and exact retained addition are asserted. Shallow result has copied fields and zero ordinary children. |
| `shallow_template_always_gets_a_fresh_empty_content` | HTML template has both ordinary children and nonempty actual content. Omitted/shallow copies each add exactly two nodes; fresh host/content reciprocal pair; content parent None; both result child vectors empty; original identities and data unchanged. Foreign namespace `template` is an ordinary Element with no content association. |
| `deep_nested_templates_keep_hook_and_ordinary_graphs_separate` | Nested templates with ordinary children plus actual content, exact Units inside the deepest content. Check every fresh host/content link, ordinary backlink and literal child order. Numeric creation order follows the held DFS phase design; a separate toggle-order example below proves the observable content-hook-before-ordinary order rather than relying only on numeric IDs. |
| `selected_hosted_fragment_becomes_a_hostless_root` | Clone a valid hosted content fragment directly, shallow and deep. The copied fragment host is None, ordinary descendants point to the new fragment, and no copied reference names the source host. Source host/content and their children remain unchanged. A detached unhosted Fragment is also fresh even when empty. |
| `relative_depth_accepts_256_and_refuses_257` | Build a detached ordinary-root chain and an alternating template/content chain with direct reciprocal edges, then admit each valid 256-edge graph through from_snapshot. Assert the exact path length before clone. Depth resets at selected root; cloning a deep existing leaf requires no ancestor walk. For 257, add one stated coherent copied edge after snapshot admission and require pre-publication refusal. A template host-to-content association counts one edge and content-to-child counts another; shallow template depth is one. Do not use raw append_child to establish the accepted boundary. |
| `selected_links_reject_duplicates_cycles_and_forbidden_child_kinds` | Table-driven mutations of a small admitted tree: missing source, out-of-range child, wrong backlink, same-parent duplicate ID, self-edge, multi-node cycle with reciprocal links, selected canonical or noncanonical Document, ordinary Fragment child, Doctype child under supported non-Document container, and leaf with children. Require the documented invalid-source error when ample admission reaches that check, unchanged state, and no panic. Work exhaustion before a malformed check may legitimately remain Resource. |
| `template_and_namespace_validation_is_local_and_exact` | Missing/out-of-range/wrong-kind template content, wrong host backlink, hosted fragment with ordinary parent, non-template content pointer, selected content also reached through a conflicting edge, orphan namespace annotation, wrong fixed annotation and attribute count above 1,024. Each scenario states which local invariant fails. Preserve valid annotation and fragment host cases as positive guards. |
| `shallow_copy_ignores_unselected_graph_and_old_ancestry` | A locally valid shallow ordinary container whose unselected descendant edge is invalid still copies its own fields; deep copy refuses that reached edge. A shallow template still validates its own host/content pair but does not descend into content children. A selected valid non-Fragment leaf with a malformed old parent chain can copy because ancestry is outside the selected graph. These are deliberate local-validation boundaries, not certification of the entire malformed Document. |
| `details_copy_uses_fresh_groups_and_keeps_coalesced_tasks` | Snapshot-admitted multiple open same-name details supply independent copy-side conflicts. Source open attributes/groups remain exactly unchanged. New ordinary root has only its earliest copied open member as winner; later copies lose only their own open attribute, each retains a closed-to-closed coalesced task. Assert exact new task IDs, old/new states, trackers, sequence increment, new name-byte count and retained-byte deductions, including empty open values. |
| `template_hook_order_is_visible_in_literal_toggle_sequence` | Use the seven-new-node example below. Verify final queue keys and states independently of final winner maps. Template-content group is distinct from the clone root group. This guards against copying ordinary children before content, or dropping closed-to-closed tasks. |
| `old_active_tasks_base_and_summary_cache_are_preserved` | Prime a source details summary; retain an old active task plus another pending task before cloning a separate graph with details and bases. Existing task/tracker/group/cache rows and active task are unchanged; fresh details keys have no summary-cache entry until explicit first_summary after success, which resolves the fresh summary ID. Connected URL/first_base/encoding/base_tracking remain unchanged while exact copied href/name byte additions are observed. Explicit later insertion is an independent integration effect, not part of clone commit. |
| `sequence_overflow_and_touched_metadata_collision_refuse_atomically` | Set the sequence near u64::MAX in a documented private arithmetic setup. Exact available event count succeeds; insufficient range refuses before any publication. Synthetic old private group/tracker/task keys colliding with the precise planned fresh keys must refuse if those guards are part of the final helper. Do not claim the helper scans every private metadata row. Zero-event leaf copies must not allocate or scan task maps. |
| `every_small_work_cut_preserves_full_document_and_capacities` | One tiny exact Units leaf with forced arena growth and one bounded metadata-bearing fixture cover all consumed work prefixes from zero to success-minus-one. Each result is LimitExceeded with steps zero and complete pre-state preserved. Keep these fixtures small; do not perform exhaustive large-tree or near-node-cap sweeps. Their successful endpoints must first satisfy independent graph/task expectations. |
| `exact_and_one_short_heap_and_work_are_absolute` | For scalar/Units and spare/full arena variants, calibrate only after successful literal assertions. Recreate inputs with allocated=37; exact work and heap succeed with the same new graph, one-short work and one-short heap publish nothing. On heap refusal the absolute allocated counter remains above the supplied limit; on work refusal steps is zero. Include a late metadata/commit-admission fixture, so payload-only staging cannot falsely establish atomicity. |
| `node_capacity_counts_template_content_and_empty_results` | At MAX_NODES-1 an empty ordinary leaf/Fragment still consumes its required one new ID; at MAX_NODES it refuses. A shallow template requires two slots and refuses with only one. Build a real bounded arena of empty detached nodes rather than faking nodes.len; avoid full work-cut sweeps or repeated massive debug strings on this fixture. Document-only refusal is Runtime-owned; helper's defensive kind refusal remains separately checked. |
| `retained_admission_has_no_source_credit_and_only_copy_side_deductions` | Independently calculate exact field bytes and copy-only removed open-key/value bytes on a small details graph. Use a clearly labelled private retained-counter boundary setup for exact MAX_DOM_BYTES and one-byte-over arithmetic, without claiming that its old payload is a fully reconstructed 32 MiB snapshot. Source/detached bytes are never credited. Keep real admitted ordinary copies as the integration proof; add one real near-cap snapshot only if a concern requires it. |
| `unrelated_arena_does_not_become_leaf_traversal_scratch` | Compare the same detached scalar/Units leaf with enough spare node capacity in a small arena and in an arena with thousands of unrelated retained nodes/name groups. Selected payload, node count and DOM body fees must match except any explicitly reached global map operation (a leaf has none). Repeat with the larger arena exactly full: work/heap now include the actual existing arena relocation rule, and a calibrated one-short attempt leaves its capacity and all logical state unchanged. |

## Literal details/template sequence example

An admitted detached source root has ordinary children `[first, template, last]`.
`first` and `last` are HTML details with `name="g"`, `open=""`. The template has
one content details and one ordinary details, both with the same name/open.
Host snapshot setup intentionally retains all four source open attributes;
from_snapshot reconstructs indices without applying insertion closures. Assert
that prerequisite before the new helper is invoked.

Let `b` be the old arena length and `s` the existing sequence after any explicitly
prepared old tasks. The expected new IDs under the held creation order are:

| ID | Kind / relation | Final open state |
| --- | --- | --- |
| b | Detached copied root; children `[b+1,b+2,b+6]` | n/a |
| b+1 | First details, parent b | open |
| b+2 | Template, parent b; content b+3; ordinary child b+5 | n/a |
| b+3 | Hosted fragment, parent None, host b+2; child b+4 | n/a |
| b+4 | Content details, parent b+3 | open |
| b+5 | Ordinary template details, parent b+2 | closed |
| b+6 | Last details, parent b | closed |

Final new group rows are `((b,"g"),b+1)` and `((b+3,"g"),b+4)`. Conceptual
events are first-open at s, content-open at s+1, ordinary-open at s+2,
ordinary-close at s+3, last-open at s+4, last-close at s+5. Final new queue rows:

```text
s   -> node b+1, old=false, new=true
s+1 -> node b+4, old=false, new=true
s+3 -> node b+5, old=false, new=false
s+5 -> node b+6, old=false, new=false
```

Each new tracker points to its listed task with old_open=false, and the final
sequence is s+6. Two removed empty open attributes deduct exactly eight newly
copied retained bytes (two four-byte keys). Four one-byte names add four to
details_name_bytes. Existing queue and active-task rows are compared exactly,
not drained to simplify the oracle. A final-group-only simulation cannot
reconstruct this event sequence; the queue checks are required.

## Coverage boundaries and preserved regressions

Private tests may inspect every current Document field because they are inside
the DOM module. They should not widen production APIs, add a general graph
validator, introduce callbacks into commit, or add an OOM injection seam solely
to manufacture allocator failure. Fallible allocation admission and error
mapping are reviewed at source; exact budget cutpoints are executable witnesses
once root authorizes compilation.

Root authorized an honest accounting migration for the old 500-details coarse
refusal. Preserve its original test text before rewiring. A new selected-tree
algorithm may admit it, but actual Runtime measurement decides its eventual
success/refusal assertion. On admission, assert copied population, fresh
identity, source preservation, final groups/toggles and separate calibrated
refusal. Runtime retains its existing real node-arena growth regression.
Neither test is replaced by a magic expected fee or a claim derived from the
implementation's returned nodes alone.

The String module's new internal copy method should have narrow direct tests
for Scalar/Units/empty behavior, exact representation and independent nonempty
buffers. The DOM tests cover admission before invoking it; no public new
constructor or test-only malformed canonical DomString is necessary.

This inventory has no measured counts, no claimed passing groups and no promise
that every large selection fits ordinary budgets. The concrete source/ledger
freeze will name actual private tests, preserve any setup corrections, and be
reviewed before root's first compiler run.
