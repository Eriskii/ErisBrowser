# Independent browser witness design

Use a real duplicate-card click in both Page and the confined worker. Capture
the original card, its ordered descendants, a template host and its distinct
content graph, and the surrounding stable controls before the click. The click
calls a saved ordinary `Node.prototype.cloneNode` on the card with `true`.

Before modifying the copy, assert exact text/attributes and ordered child kinds,
fresh IDs for every copied node, default intrinsic interfaces, detached root,
reciprocal copied links and the complete unchanged original graph. Include a
Comment and PI separator with exact data, and a nested template whose ordinary
children and content descendants remain separate. Verify that copied hosts
point only to copied content, each content fragment points back to its own
copied host, and both graphs have exactly the predetermined literal population.
An ordinary source expando and assigned event handler must be absent on the copy.

Then give only the copy its distinct label and color, append it beside the
original and update a fixed status/title. The full before and after canvases
must come from independent script-free literal trees. Check nonempty glyphs,
distinct color samples, visible order, fixed base URL and every preserved
original ID. Only the explicitly counted clone nodes may be added on click;
label changes reuse existing copied Text identities. The original must remain
unchanged, while the new root becomes connected by that explicit insertion.

Add a shallow template call through the live ordinary method within the same
event only if its two fresh nodes and detached graph can be kept fully explicit
in the population oracle; otherwise cover it in the independent Runtime cases.
Do not infer the copier's correctness from its own serialization, equality
method, traversal output or dynamically generated reference image.

This is an unexecuted design. Fixture and literal population details will be
authored against the actual published position predecessor before clone
implementation. It does not claim Document ownership or absent HTML form and
script state semantics.
