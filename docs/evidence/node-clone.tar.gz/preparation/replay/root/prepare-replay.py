#!/usr/bin/env python3
"""Freeze clone inputs and run only inherited inert prepare/verify modes."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess

if not __debug__:
    raise RuntimeError('run without Python optimization')
P = Path(__file__).resolve().parents[1]
R = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-node-position-preparation-1/replay')
ART = Path('/tmp/eris-node-position-1')
OUT = P / 'replay'
BASE = '0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5'
RELEASE_SHA = 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'
FIXTURE_SHA = 'bf66956a6ca0e1ef138a2d634ab3c31968754415f04c4b2197a2b07e9ec63479'
INDEPENDENT_SHA = '6e995add31fe991143d364fb79b2efab4bd839352a9f3850e735ad3cb624dad0'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def binding(p):
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))


def verify(row, path=None):
    p = Path(row['path']) if path is None else path
    assert p.is_absolute() and p.is_file() and not p.is_symlink(), str(p)
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes'], str(p)
    return p


def write_json(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


def git_bytes(commit, relative_path):
    return subprocess.check_output(['git', 'show', commit + ':' + relative_path], cwd=R)


assert sha(P / 'independent/source-ready.json') == INDEPENDENT_SHA
for name in ['independent/source-ready.json', 'runtime/source-ready.json',
             'runtime/proposal-ready.json', 'layout/source-ready.json',
             'browser/source-ready-2.json']:
    hold = json.loads((P / name).read_text())
    for row in hold['files']:
        verify(row)
checked = json.loads((P / 'layout/checked-clone-ready.json').read_text())
verify(checked['proposal'])
for row in checked['bindings'] + checked['prior_feasibility_retained_unchanged']:
    verify(row)
base = json.loads((P / 'root/published-base.json').read_text())
assert base['commit'] == BASE
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip() == BASE
assert base['release']['sha256'] == RELEASE_SHA
verify(base['release'])
assert sha(ART / 'candidate-source-final.json') == base['source_manifest_sha256']
for row in base['source_manifest']['files']:
    raw = git_bytes(BASE, row['path'])
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    assert raw == (ART / 'held-source-final' / row['path']).read_bytes()

# Older feasibility remains anchored to connected Git objects; new proposals
# and the selected scope use actual published position. Neither is rewritten.
source_proofs = []
for owner in ['runtime', 'layout']:
    old = json.loads((P / owner / 'source-inputs.json').read_text())
    for row in old['files']:
        retained = P / owner / 'inputs' / row['path']
        verify(row, retained)
        assert retained.read_bytes() == git_bytes(old['base'], row['path'])
        source_proofs.append(dict(base=old['base'], repository_path=row['path'], **binding(retained)))
new = json.loads((P / 'runtime/proposal-source-inputs.json').read_text())
for row in new['files']:
    retained = Path(row['retained'])
    verify(row, retained)
    assert retained.read_bytes() == git_bytes(new['base_commit'], row['path'])
    source_proofs.append(dict(base=new['base_commit'], repository_path=row['path'], **binding(retained)))
concrete = json.loads((P / 'layout/checked-clone-inputs.json').read_text())
for row in concrete['sources']:
    retained = verify(row['copy'])
    assert retained.read_bytes() == git_bytes(row['git_commit'], row['git_path'])
    source_proofs.append(dict(base=row['git_commit'], repository_path=row['git_path'], **binding(retained)))

# Refuse reused output. Any partial preparation and every failed command remain.
OUT.mkdir()
history = []


def copy(p, rel):
    assert p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts
    dest = OUT / rel
    if dest.exists():
        assert dest.read_bytes() == p.read_bytes(), str(dest)
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
    history.append(dict(origin=str(p), copy=str(rel), bytes=dest.stat().st_size, sha256=sha(dest)))


# Snapshot currently held planning history; later peer receipts stay additive.
for directory in ['independent', 'runtime', 'layout', 'browser', 'root']:
    for p in sorted((P / directory).rglob('*')):
        if p.is_file():
            copy(p, p.relative_to(P))
for name in ['test262_conformance.py', 'html_conformance.py', 'import_test262.py']:
    assert (OLD / 'tools' / name).read_bytes() == git_bytes(BASE, 'tools/' + name)
    copy(OLD / 'tools' / name, Path('tools') / name)
for name in ['node-constants.js', 'node-normalize.js', 'node-predicates.js',
             'node-root.js', 'node-equality.js', 'node-connected.js', 'node-position.js']:
    held = P / 'independent/inputs/old-fixtures' / name
    assert held.read_bytes() == git_bytes(BASE, 'tests/fixtures/' + name)
    copy(held, Path('history') / name)
for name in ['source-ready.json', 'replay.py', 'replay-matrix.json', 'replay-inputs.json']:
    copy(OLD / name, Path('history/prior-replay') / name)
copy(Path('/tmp/eris-node-position-preparation-1/independent/inventory.json'),
     Path('history/prior-replay/independent-inventory.json'))
for name in ['candidate-source-final.json', 'release.json', 'published.json',
             'validation/release-adapter-188-1.json']:
    copy(ART / name, Path('history/published-position') / name)
for row in base['source_manifest']['files']:
    copy(ART / 'held-source-final' / row['path'],
         Path('history/published-position/held-source-final') / row['path'])

fixture = OUT / 'independent/cases.js'
assert sha(fixture) == FIXTURE_SHA
inv = json.loads((OUT / 'independent/inventory.json').read_text())
ctrl = json.loads((OUT / 'independent/controls.json').read_text())
assert len(inv['cases']) == 17 and inv['collection'] == 'nodeCloneCases'
assert len(ctrl['controls']) == 8 and inv['case_modes'] == 34
assert inv['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True}
assert re.findall(r'^  ([A-Za-z0-9_]+): function\(\)', fixture.read_text(), re.M) == inv['cases']
inventory = dict(fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA,
                 collection=inv['collection'],
                 cases=[dict(name=name, modes=['sloppy', 'strict'],
                             expected_observation=inv['ordinary_expectation'])
                        for name in inv['cases']],
                 controls=ctrl['controls'], case_modes=34, control_modes=16,
                 case_invocation_argument_by_mode=inv['case_invocation_argument_by_mode'])
write_json(OUT / 'replay-inputs.json', inventory)

original = (OLD / 'replay.py').read_text()
identities = [
    ('Frozen Node position observations', 'Frozen Node clone observations'),
    ('nodePositionCases', 'nodeCloneCases'),
    ('node-position.js', 'node-clone.js'),
    ('97855d380d9a18edbef4fd0c317ac5430265d78d07f9adeb5511542fcbb84575', FIXTURE_SHA)]
population = [
    ("len(inventory['cases']) == 16", "len(inventory['cases']) == 17"),
    ("(inventory['case_modes'], inventory['control_modes']) == (32, 16)",
     "(inventory['case_modes'], inventory['control_modes']) == (34, 16)"),
    ("len(matrix) == 48 and len({case['id'] for case, _ in matrix}) == 48",
     "len(matrix) == 50 and len({case['id'] for case, _ in matrix}) == 50"),
    ('Frozen 32 independent case modes and 16 paired controls',
     'Frozen 34 independent case modes and 16 paired controls')]
driver = original
for before, after in identities + population:
    assert before in driver and after not in driver
    driver = driver.replace(before, after)
reverse = driver
for before, after in reversed(identities + population):
    reverse = reverse.replace(after, before)
assert reverse == original
ast.parse(driver)  # Python supervisor syntax only, not JavaScript parsing.
with (OUT / 'replay.py').open('x') as f:
    f.write(driver)
with (OUT / 'replay.py.diff').open('x') as f:
    f.writelines(difflib.unified_diff(original.splitlines(True), driver.splitlines(True),
                                    fromfile='position/replay.py', tofile='clone/replay.py'))
write_json(OUT / 'driver-transformation.json', dict(
    original=binding(OLD / 'replay.py'), current=binding(OUT / 'replay.py'),
    identity_substitutions=[dict(before=a, after=b) for a, b in identities],
    population_substitutions=[dict(before=a, after=b) for a, b in population],
    reverse_transform_is_byte_exact=True,
    unchanged='Literal Boolean invocation, matcher, healthy positive partner, limits, exception retention, pre/post bindings, exclusive output and engine supervision'))
write_json(OUT / 'published-source-verification.json', dict(status='Git bytes verified', files=source_proofs))
write_json(OUT / 'preparation-history.json', history)

commands = []
for option in ['--prepare', '--verify']:
    args = ['python3', str(OUT / 'replay.py'), option]
    result = subprocess.run(args, capture_output=True, text=True)
    record = dict(command=args, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
    commands.append(record)
    if result.returncode != 0:
        write_json(OUT / 'inert-verification-failure.json', dict(commands=commands))
    assert result.returncode == 0, record
write_json(OUT / 'inert-verification.json', dict(engine_run=False, compiler_run=False,
                                               javascript_parser_run=False, commands=commands))
matrix = json.loads((OUT / 'replay-matrix.json').read_text())
assert len(matrix['rows']) == 50
assert len(matrix['bound_inputs']) == len(history) + 3
assert all((OUT / row['copy']).read_bytes() == Path(row['origin']).read_bytes() for row in history)
result = dict(
    status='Frozen clone expectations; inherited inert matrix verified; no clone engine or JavaScript parser execution',
    location=str(OUT), location_must_remain_fixed=True,
    ordinary_bodies=17, ordinary_modes=34, control_pairs=4, control_modes=16, total_rows=50,
    history_copies=len(history), bound_input_paths=len(matrix['bound_inputs']),
    driver=binding(OUT / 'replay.py'), matrix=binding(OUT / 'replay-matrix.json'),
    fixture_sha256=FIXTURE_SHA,
    invocation='Named cases retain literal false for sloppy and true for strict; bodies ignore that argument',
    supervision='Exact position driver after four reversible identity substitutions and explicit population assertions/message only; ERJS1/ERJR2,3s,96KiB stdout/64KiB stderr,4MiB request, exclusive output, pre/post bindings, raw failures and same-mode positive health unchanged',
    baseline=dict(status='Not executed; root owns published-release baseline after review',
                  published_commit=BASE, binary=base['release']),
    history_policy='Original connected feasibility and position-context planning remain unchanged. Seven old fixture bytes exact; six anticipated position inventory losses separate from36 older unhealthy rows; no health waiver.',
    peer_timing='Root authorized preparation before external fixture peer; later peer receipts are additive and not asserted to precede this freeze.',
    files=[binding(p) for p in sorted(OUT.rglob('*')) if p.is_file()])
write_json(OUT / 'source-ready.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, indent=2))
