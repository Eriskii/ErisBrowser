# Next increment: checked represented Node cloning

Root selects ordinary cached `Node.prototype.cloneNode` and a checked copier
for the currently represented non-Document kinds. This is the next implementation
increment after the position checkpoint is published. Published predecessor and
release bindings will be added after that push; the earlier feasibility notes
remain bound to their original connected predecessor.

The public method retains existing Element reachability and explicitly retains
the current missing form control state, script lifecycle and independent owning
Document semantics. A Document clone must continue to report the unsupported
operation until real document identity and ownership exist. No fragment or
second canonical-root alias may stand in for a distinct Document.

The intended body validates and stages only the selected graph, with exact
stored payload copies, fresh node IDs, fresh template host/content relationships,
ordinary child order and a paid 256-edge boundary. A shallow template still
receives its own fresh empty content fragment. A copied hosted fragment is
hostless. No parser-style create/set API may normalize, clamp or silently refuse
an admitted copied field. Source expandos, listeners and prototype overrides do
not become properties of the new identities.

Prefer complete paid staging and atomic publication of the detached graph.
The concrete design must account for copies, sparse traversal/identity storage,
attribute maps, child vectors, arena growth and fresh details/base bookkeeping.
Applicable details attribute and insertion effects must be modeled within the
copy, without changing old groups or cached connected base selection. All
fallible allocation and budget decisions precede publication; existing
infallible BTree allocation limitations remain explicit. If that contract cannot
be met, document and review an ordered partial-publication alternative before
implementation. Do not claim atomicity from staging payloads alone.

Receiver authentication precedes optional ToBoolean conversion. Missing/false
means shallow; objects are truthy without authored coercion. Argument expression
effects finish first. Remove the old virtual and legacy routes coherently so
ordinary deletion does not resurrect the method. Derive initialization charges
from both the added ordinary function and removed legacy registration; do not
assume a simple positive one-method delta.

Meaningful validation must cover fresh exact leaves, nested template graphs,
actual accepted depth endpoints, namespace annotations, large stored fields,
malformed selected links, independent shallow/deep results, resource cutpoints,
fresh details/base state and a Page/worker visible copy witness. Freeze
independent JavaScript expectations before implementation, record the actual
published baseline and keep established raw regression failures visible.

No new quota, worker privilege, DOM transport format or broad ownership change
belongs to this increment. Full web compatibility, security and Chromium
performance requirements remain outstanding.
