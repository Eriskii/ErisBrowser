# Independent represented clone expectations

These expectations are authored against published position commit
`0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`, before a clone implementation or
baseline run. The root-selected scope is a cached ordinary `Node.cloneNode`
and exact checked copying of represented non-Document nodes. Existing Element
reachability stays available, with missing form state, script lifecycle and
independent owning Documents explicitly outside the success claims.

The DOM algorithm copies one node, runs applicable element cloning hooks, and
then copies ordinary children in their current order when requested. Character
data and PI target/data remain exact. A returned clone is a fresh detached
identity, not a source node with a different wrapper. A template needs a fresh
content fragment even when shallow; deep content and ordinary children are
separate copied graphs. Copying the content fragment itself yields an ordinary
hostless fragment. No public allocation-ID sequence is prescribed here.
[DOM cloning](https://dom.spec.whatwg.org/#concept-node-clone),
[cloneNode](https://dom.spec.whatwg.org/#dom-node-clonenode),
[HTML templates](https://html.spec.whatwg.org/multipage/scripting.html#the-template-element).

The optional Boolean defaults false. False values remain shallow; objects,
including objects with poisoned coercion getters, are true without invoking
those getters. Receiver authentication precedes conversion, while argument
expressions have already completed. The source graph is observed after those
expressions and an expression's thrown object prevents invocation while keeping
earlier expression mutations. The ordinary operation has length zero, is not a
constructor, and remains callable when saved after property replacement or
deletion. [Web IDL Boolean conversion](https://webidl.spec.whatwg.org/#es-boolean),
[regular operations](https://webidl.spec.whatwg.org/#es-operations).

The seventeen named bodies cover metadata, complete represented inventory,
authentic receivers, Boolean conversion, expression order, Text/Comment data,
PI data after legal mutation, shallow Element fields, deep segmentation/order,
foreign namespaces and attribute annotations, Fragment detachment, shallow
templates, nested deep templates, hostless copied content, omitted own state
and default interfaces, fresh details/base behavior, and saved calls/deletion. They use literal data and
identity/link assertions. Namespace annotation has no current direct public
getter; that one part uses saved isEqualNode with an independently constructed
same-key/value but null-namespace negative, in addition to literal namespace,
name, key and value checks. It is not the sole oracle for copied trees.

The prototype inventory is conditional on this selected method installation:
31 keys, with cloneNode between normalize and isEqualNode; constructor inventory
remains 21. Preserve the preceding position fixture and its two full-inventory
modes and four reflected-order controls unchanged. Their anticipated six new
historical failures must be identified separately from the 36 already-unhealthy
older inventory rows. No old expected value or raw health may be rewritten.

Each body is run alone in a fresh realm, strict and sloppy, with inherited
explicit mode invocation: false for sloppy and true for strict. Bodies ignore
that argument. All ordinary expectations require successful completion. Four
paired controls cover common literal UTF-16 syntax, the actual ordinary method
with authentic Boolean conversion, exact deep/template copying, and literal
31-key inventory. Every intentionally wrong tail requires its same-mode healthy
positive partner; TypeError prerequisite failures cannot pass as Error tails.

Private host tests remain necessary for Doctype fields and force_quirks, large
admitted scalar fields, malformed selected links, exact 256-edge setup, node and
retained-byte capacity, work/heap cuts, sparse admission, fresh summary/details/
base metadata, atomic publication, and two simultaneously live Runtime realms.
JavaScript cannot inspect arena capacity, allocator use, unpublished stages,
private host/content backlinks or every cache. Ordinary success must not be
used to infer any of those properties.

The additional details/base body observes detached copies before insertion and
then explicit insertion/removal. It checks that copying alone does not close an
original connected disclosure or replace the active base; later mutations on
the fresh copied identities participate in their new ordinary tree. It does not
assert task timing, cache layout or snapshot internals.
[HTML details](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element).

Document.cloneNode must remain explicitly unsupported within this selected
implementation until separate document identity/ownership exists. That is an
implementation gap, not a successful standard clone or the standard ShadowRoot
NotSupportedError branch. Document method inheritance is tested without calling
its unsupported body. No Attr, CDATA, ShadowRoot, custom element registry/reaction,
Range, observer, arbitrary namespace prefix or cross-document test is implied.
Input/textarea dirty state, script already-started state and inert template
owner Documents remain named gaps. Listener absence is tested through an actual
positive source dispatch followed by clone dispatch, not a property-only guess;
inline handler attributes are stored attribute text and are a separate category.

No fixture parser, Runtime, browser, compiler or engine has been executed for
this preparation. No quota feasibility or measured clone result is claimed.
