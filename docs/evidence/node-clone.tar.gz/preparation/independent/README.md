# Held independent clone expectations

`cases.js` defines `nodeCloneCases`: seventeen independent bodies and thirty-four
strict/sloppy modes. Load its exact bytes and invoke one named body in a fresh
ordinary realm. Use `nodeCloneCases[name](false)` in sloppy mode and
`nodeCloneCases[name](true)` in strict mode, with the literal mode value coming
from frozen metadata; the bodies ignore the argument. The strict directive must
precede both definitions and invocation. Do not concatenate body executions into
one realm or infer a passing result from a thrown prerequisite.

All ordinary modes expect complete/runtime with empty error type and identity.
Every body also returns true. `controls.json` contains four positive/wrong pairs,
sixteen control modes. Wrong controls append only an intentional Error tail to
their exact positive source. Runtime Error/Error is healthy only if the positive
partner in the same language mode completes; prerequisite TypeError, absent
observations, parser failures, Resource or adapter failures cannot pass. The
common literal pair is byte-exact with the prior position pair.

The source was authored before any clone baseline or candidate execution and
before implementation. Its actual published predecessor is position
`0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`, release
`f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007`.
Earlier feasibility notes retain their original connected base and historical
candidate status. This inventory does not replace those records.

`design.md` describes the semantic scope, literal oracles and explicit gaps.
The method length is zero; receiver conversion is authentic; optional Boolean
conversion does not run authored coercion. Exact Text/Comment/PI units, fresh
identity, retained source links, child order and segmentation, namespaces,
template content separation, omitted listeners/expandos/prototype overrides,
post-expression reads, saved calls and no fallback resurrection are tested.
The additional details/base body checks public effects of later explicit
insertion or removal, not private task queues or cached values.

The new pristine Node prototype has thirty-one keys, including the final
Symbol.toStringTag. cloneNode appears between normalize and isEqualNode. The
constructor retains its twenty-one literal keys. Seven older Node fixture files
are copied unchanged under `inputs/old-fixtures/`. The preceding position
inventory's two case modes and four controls are anticipated new historical
losses; the thirty-six older unhealthy inventory rows must remain separately
visible. These are source-derived expectations, not an executed clone result.

The source uses only represented setup APIs. SVG/MathML creation uses parsed
detached scalar markup, with literal namespace/name guards. The namespace side
map has no direct getter; saved isEqualNode is used only for that annotation
check alongside a separately constructed null-namespace negative. All structural
clone cases have independent literal identity, order, data and link assertions.
The event test first proves that source listeners and an assigned handler fire,
then dispatches on the copy, then proves the original registrations remain.

Doctype payload copying, actual host backlinks, all-node population, internal
publication, allocator cuts, exact depth endpoints, malformed selected graphs,
private details/base tasks and independent live Runtime separation require
private host checks. Document cloning remains an explicitly unsupported body;
the ordinary method's inheritance on Document is tested without treating that
body as a standard success. Full form state, script lifecycle, template owner
Documents, Attr/CDATA/ShadowRoot and cross-document ownership remain outside the
selected represented success claims.

No source was parsed as JavaScript, compiled, imported into a Runtime, executed
in an engine, or measured. The static checks inspect bytes, JSON, literal names,
control-prefix identities and published Git objects only. There is no quota or
test outcome claim. Changes before or after review must retain previous held
bytes and a separate correction receipt; expected results cannot be silently
rewritten after observations.
