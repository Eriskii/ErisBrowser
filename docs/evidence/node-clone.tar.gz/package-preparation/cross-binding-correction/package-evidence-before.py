"""Package final reviewed clone/hasOwn evidence; never run an engine or test.

Root must supply package-pins.json after validation, audit and documentation.
This script does not derive or reinterpret result health. All prior failures
remain ordinary evidence payloads; final-publication review stays external.
"""

import gzip
import hashlib
import io
import json
import os
import stat
import tarfile
from pathlib import Path, PurePosixPath

A = Path(__file__).resolve().parent
W = A / 'worktree'
P = Path('/tmp/eris-node-clone-preparation-1')
ARCHIVE_NAME = 'node-clone.tar.gz'
SUMMARY_NAME = 'node-clone.json'
SKIP_DIRS = {'.git', '__pycache__', 'target', 'worktree'}
ARCHIVE_SUFFIXES = ('.tar.gz', '.tgz', '.tar', '.tar.xz', '.tar.zst', '.zip')
EXTERNAL_FINAL = {'final-publication-review.json', 'published.json',
                  'package-execution.json', 'package-execution.log'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def safe_name(name):
    require(isinstance(name, str) and name and '\\' not in name, 'Invalid member name')
    parts = PurePosixPath(name)
    require(not parts.is_absolute() and all(p not in {'', '.', '..'} for p in name.split('/')),
            'Unsafe relative name: ' + name)
    return name


def file_bytes(path):
    # lstat every component: no dangling or live symlink target is ever opened.
    path = Path(path)
    require(path.is_absolute(), 'Expected an absolute evidence path')
    current = Path(path.anchor)
    for part in path.parts[1:]:
        current /= part
        require(not stat.S_ISLNK(current.lstat().st_mode), 'Symlink input: ' + str(current))
    require(stat.S_ISREG(path.lstat().st_mode), 'Nonregular evidence: ' + str(path))
    return path.read_bytes()


def record(path):
    raw = file_bytes(path)
    return {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode()


def checked_input(binding):
    require(set(binding) == {'path', 'sha256'}, 'Unexpected binding schema')
    path = A / safe_name(binding['path'])
    raw = file_bytes(path)
    require(hashlib.sha256(raw).hexdigest() == binding['sha256'],
            'Pinned input drift: ' + str(path))
    return json.loads(raw)


def check_hold(hold, directory):
    names = set()
    for row in hold['files']:
        name = safe_name(row['path'])
        require(name not in names, 'Duplicate held source: ' + name)
        names.add(name)
        expected = {'bytes': row['bytes'], 'sha256': row['sha256']}
        require(record(W / name) == expected, 'Worktree source drift: ' + name)
        require(record(A / directory / name) == expected, 'Frozen source drift: ' + name)
    require(names, 'Empty source/documentation hold')


def inventory():
    included = {}
    omitted = []

    def scan(root, prefix):
        def visit(directory):
            for entry in sorted(os.scandir(directory), key=lambda item: item.name):
                path = Path(entry.path)
                relative = path.relative_to(root).as_posix()
                name = safe_name(prefix + relative)
                mode = entry.stat(follow_symlinks=False).st_mode
                if stat.S_ISLNK(mode):
                    parts = PurePosixPath(relative).parts
                    allowed_cache = (root == A and len(parts) >= 3
                                     and parts[0].startswith('cache-repair-') and parts[1] == 'links')
                    require(allowed_cache, 'Unexpected evidence symlink: ' + str(path))
                    omitted.append({'path': name, 'reason': 'cache symlink; target never followed',
                                    'target': os.readlink(path)})
                    continue
                if stat.S_ISDIR(mode):
                    if entry.name in SKIP_DIRS:
                        omitted.append({'path': name + '/', 'reason': 'worktree, cache or VCS directory'})
                    else:
                        visit(path)
                    continue
                require(stat.S_ISREG(mode), 'Unexpected evidence type: ' + str(path))
                if entry.name.endswith(ARCHIVE_SUFFIXES):
                    omitted.append(dict(path=name, reason='nested archive excluded; raw current evidence retained',
                                        **record(path)))
                    continue
                if root == A and path.parent == A and entry.name in EXTERNAL_FINAL:
                    omitted.append(dict(path=name, reason='external post-package receipt', **record(path)))
                    continue
                # Only the current release executable is a payload. Historical
                # release identities remain in their JSON/log receipts.
                if entry.name == 'eris-js' and path != A / 'eris-js':
                    omitted.append(dict(path=name, reason='duplicate historical executable', **record(path)))
                    continue
                require(name != 'archive-manifest.json' and name not in included,
                        'Archive member collision: ' + name)
                included[name] = dict(source=str(path), **record(path))
        visit(root)

    scan(A, '')
    scan(P, 'preparation/')
    return dict(sorted(included.items())), sorted(omitted, key=lambda row: row['path'])


def main():
    pins_path = A / 'package-pins.json'
    pins_raw = file_bytes(pins_path)
    pins = json.loads(pins_raw)
    require(pins['status'] == 'ready', 'Packaging pins are not final')
    require(set(pins['bindings']) == {'source', 'documentation', 'release', 'audit', 'summary', 'packager'},
            'Missing or unexpected final bindings')
    for field in ['source_directory', 'documentation_directory', 'release_binary']:
        safe_name(pins[field])
    require(pins['release_binary'] == 'eris-js', 'Current release must be eris-js')
    bindings = pins['bindings']
    require(bindings['packager']['path'] == Path(__file__).name, 'Wrong packager binding')
    require(record(Path(__file__).resolve())['sha256'] == bindings['packager']['sha256'], 'Packager changed')
    values = {key: checked_input(binding) for key, binding in bindings.items() if key != 'packager'}
    source, docs, release = values['source'], values['documentation'], values['release']
    audit, summary = values['audit'], values['summary']
    check_hold(source, pins['source_directory'])
    check_hold(docs, pins['documentation_directory'])
    require(audit['status'] == 'clear' and audit.get('findings') == [], 'Independent audit is not clear')
    # Recheck the entire retained audit input roster, including raw failure logs.
    for item in audit['inputs']:
        require(record(Path(item['path'])) == {'bytes': item['bytes'], 'sha256': item['sha256']},
                'Audited input drift: ' + item['path'])
    require(release['source_manifest'] == bindings['source']['path']
            and release['source_manifest_sha256'] == bindings['source']['sha256'],
            'Release does not bind final source')
    require(record(A / 'eris-js') == {'bytes': release['bytes'], 'sha256': release['sha256']},
            'Release binary drift')
    require(summary['source'] == source and summary['release'] == release,
            'Result summary source/release differ')
    require('archive' not in summary, 'Result summary is already packaged')

    files, omitted = inventory()
    require('eris-js' in files and 'package-pins.json' in files, 'Release or pin payload missing')
    rows = [dict(path=name, bytes=item['bytes'], sha256=item['sha256']) for name, item in files.items()]
    manifest = encoded({'format': 'node-clone-evidence-v1', 'files': rows, 'excluded': omitted,
                        'bindings': bindings,
                        'package_pins_sha256': hashlib.sha256(pins_raw).hexdigest()})
    destination = W / 'docs/evidence'
    require(destination.is_dir() and not destination.is_symlink(), 'Evidence destination missing or symlinked')
    archive = destination / ARCHIVE_NAME
    public_summary = destination / SUMMARY_NAME
    require(not os.path.lexists(archive) and not os.path.lexists(public_summary),
            'Publication artifacts already exist; no overwrite permitted')
    # Exclusive creation preserves any failed attempt for review. Timestamp,
    # ownership, permissions and member order are independent of scratch mtimes.
    with archive.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
                for name in sorted([*files, 'archive-manifest.json']):
                    raw = manifest if name == 'archive-manifest.json' else file_bytes(Path(files[name]['source']))
                    if name != 'archive-manifest.json':
                        require({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                                == {k: files[name][k] for k in ('bytes', 'sha256')},
                                'Evidence changed while writing: ' + name)
                    item = tarfile.TarInfo(name)
                    item.size = len(raw)
                    item.mode = 0o755 if name == 'eris-js' else 0o644
                    item.uid = item.gid = item.mtime = 0
                    item.uname = item.gname = ''
                    tar.addfile(item, io.BytesIO(raw))
    with tarfile.open(archive, 'r:gz') as tar:
        members = tar.getmembers()
        require([m.name for m in members] == sorted([*files, 'archive-manifest.json']),
                'Archive population or ordering differs')
        require(all(m.isfile() for m in members), 'Archive contains a nonregular member')
        for item in members:
            safe_name(item.name)
            raw = tar.extractfile(item).read()
            if item.name == 'archive-manifest.json':
                require(raw == manifest, 'Manifest differs')
            else:
                require({'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}
                        == {k: files[item.name][k] for k in ('bytes', 'sha256')},
                        'Archived payload differs: ' + item.name)
    require(inventory() == (files, omitted), 'Evidence inventory changed during packaging')
    require(file_bytes(pins_path) == pins_raw, 'Final pins changed during packaging')
    check_hold(source, pins['source_directory'])
    check_hold(docs, pins['documentation_directory'])
    summary['archive'] = dict(path=ARCHIVE_NAME, **record(archive), files=len(rows),
                              manifest_verified=True,
                              manifest_sha256=hashlib.sha256(manifest).hexdigest(),
                              excluded_entries=len(omitted), reproducible_metadata=True,
                              release_binary_included=True)
    with public_summary.open('xb') as stream:
        stream.write(encoded(summary))
    print(json.dumps(summary['archive'], sort_keys=True))


if __name__ == '__main__':
    main()
