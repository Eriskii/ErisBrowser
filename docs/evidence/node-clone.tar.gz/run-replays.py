import hashlib, json, subprocess, time
from pathlib import Path

A = Path(__file__).resolve().parent
release = json.loads((A/'release.json').read_text())
assert hashlib.sha256((A/'eris-js').read_bytes()).hexdigest() == release['sha256']
argv = ['python3', str(A/'replay-jobs.py')]
start = time.monotonic()
result = subprocess.run(argv)
with (A/'replay-execution.json').open('x') as stream:
    json.dump(dict(command=argv, exit=result.returncode, elapsed_seconds=time.monotonic()-start), stream, indent=2)
    stream.write('\n')
argv = ['python3', str(A/'object-has-own/replay/replay.py'), str(A/'eris-js'), release['sha256'], str(A/'has-own-after.json')]
log = A/'has-own-replay.log'; start = time.monotonic()
with log.open('xb') as stream:
    own = subprocess.run(argv, stdout=stream, stderr=subprocess.STDOUT)
record = dict(command=argv, exit=own.returncode, elapsed_seconds=time.monotonic()-start,
              log=log.name, sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (A/'has-own-command.json').open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(record), flush=True)
if own.returncode: print(log.read_text()[-5000:])
raise SystemExit(own.returncode or result.returncode)
