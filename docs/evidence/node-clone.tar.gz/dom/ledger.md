# Checked clone Document ledger

This records the concrete source held with this file, before compilation or engine execution. The published source base is `0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5`. It is a logical admission schedule, not timing data or a claim of process-OOM recovery. Runtime separately prepays its 26-work successful prefix, passes absolute counters into `clone_node_checked`, and copies both counters back on either result. No Runtime debit follows successful publication.

## Shared primitives and types

`mutation_budget.rs` is a mechanical extraction of the previous replacement primitives. Helper visibility alone expands to `pub(super)`; existing replacement method/test bytes from `MovingDetails` onward are unchanged. `work(w)` subtracts w or sets remaining work to zero on refusal. `charge(b)` adds b to absolute allocated bytes before checking the limit, with no refund. Checked integer overflow is a limit error. The retained extraction proof binds originals, the extracted block and the unchanged remainder.

For map size q, H(0)=0. Otherwise initialize c=(q+1)/2 and H=1, divide c by six and increment H while c>=6. C(q)=min(q,11H), L=H+1, S(q,k)=C(q)(2+k). Key length k is the complete UTF-8 byte length; integer-only keys use k=0. The fixed two operations cover the accompanying integer component and comparison bookkeeping for mixed keys. M(0)=0 and M(q)=64L otherwise. A typed tree block is Q(K,V)=16(sizeof(K)+sizeof(V))+32sizeof(usize)+64. `map_nodes` is L*Q. These are checked formulas using actual compiled type sizes, without substituting prior measurements.

Every new clone map insertion pays S(q,k)+4M(q)+32. At q=0 this is 32; at nonzero q the structural part is 256L+32. Heap is Q at q=0, zero at q=1..10, and L*Q thereafter. This applies to copied attribute and namespace maps, the borrowed-name winner map, and eventual Document group/tracker/task insertions. Winner Entry pays its separate search before this conservative insertion row; that deliberate repeated search allowance is retained.

The version-pinned proof reference is the held equality `stdlib-proof.md` (Rust 1.88/1.98 map, node, entry and navigate paths). It bounds a nonfull insertion by 124 logical handle/key/value/edge operations per reached level, and split plus insertion by 166. Both split-side child backlink repair and subsequent insertion-suffix repair are included. The remaining 90 per admitted level covers navigation, root/header operations and eventual consuming traversal/deallocation; fixed setup is 32. String/tuple keys and values are moved as typed handles here, not copied character buffers or counted as CPU instructions. Their payload allocation/copy/cleanup has a separate row below; all full key comparisons use S. Uninitialized array slots do not require payload destruction. The q=0 row covers root header and single key/value initialization plus eventual root teardown. Q dominates leaf/internal storage and alignment, while L conservatively permits every reached split and a new root. BTree allocation remains infallible.

The initial clone-only draft used 2M; it was preserved and corrected before the first source hold because extra-level slack alone was not a sufficient proof for both repairs. No old replacement charge was changed. Copy-only open removal similarly pays S(q,4)+4M(q)+16 before `remove`; this covers deletion search, movement/rebalancing/root changes and consuming cleanup of removed key/value handles. Copied payload work has already been admitted.

## Payloads, vectors and traversal

| Operation | Work before operation | Heap before operation |
| --- | --- | --- |
| Exact String or DomString payload of B stored bytes | 8+2B, including buffer setup, copy and eventual cleanup | B |
| Optional String discrimination | 2, then the payload row when present | As above |
| Borrowed nonempty map iterator creation and each next, including EOF | I(q)=8+8H(q) | 0 |
| Namespace annotation local check | 32+11*14+S(attribute count,key bytes) | 0 |
| Staged Vec push | 4 for eventual pop/consume/cleanup, then 1 for push | 0 if capacity exists |
| Staged Vec growth at len n/capacity c/maximum m | Extra 1+2n | next*sizeof(T), next=max(n+1,min(2c,m)), clipped to m |
| Fresh child Vec with d selected ordinary children | 8 for reserve/header/cleanup | d*sizeof(NodeId) |
| Clone entry / plan setup | 16 / 16 | 0 |
| Single node validation | 32 | Payload/child/map/vector rows separately |
| Each DFS loop iteration | 8 | 0 |
| Ordinary insertion phase | Extra 8 | Pre-reserved child slot |
| Reached ordinary edge and frame setup | Extra 16, then staged frame push | Reached frame growth only |

The exact DomString helper matches private Scalar/Units storage, fallibly reserves and copies that same buffer. It neither decodes, projects, validates through parser factories, nor re-canonicalizes a value. This preserves independent buffers, lone units, PI data already mutated to `?>`, optional Doctype fields and admitted long host fields. Attribute values remain the existing scalar String representation; this does not introduce an exact full ordered Attr model.

Each new node is staged before traversing descendants. A template's fresh content Fragment is allocated immediately, including for a shallow copy. Only this fixed one-level template-to-Fragment call is recursive. DFS processes content descendants before insertion of the template and then its ordinary children. Ordinary root IDs and host associations are explicitly carried; content roots never join the host's details group. General graph traversal uses a bounded frame Vec, not recursive descent.

Deep selected graphs mark each reached ID in a sparse page-bit map (page=id/64). Each mark pays setup16 and Entry search C+8L+4. An occupied page pays8 for bit test/OR with no allocation; a new page pays256L+32 and typed tree storage under the same first-leaf/split rule. This is the previously reviewed integer-pair sparse-map envelope. It detects same-side duplicates/cycles across ordinary and template-content edges. Leaf/shallow operations allocate no DFS or visited map. Every selected edge rechecks the child backlink and permitted kind. Fragment host pairs are checked locally, even for shallow copying; unread shallow child edges and a selected leaf's old ancestry are deliberately outside validation.

Output root depth is zero. Each ordinary edge and template-to-content association increments depth. Depth256 is allowed,257 refused. This is relative output depth, not an ancestor walk in the old graph. Children/frames/staging are bounded by existing node/depth limits. The implementation does not promise whole-graph linear time: BTree searches, source sibling payloads, actual Vec growth and reached arena growth all retain their explicit charges.

## Details, base and staged metadata

Each reached node's hook discrimination costs16. An HTML base adds8+S(attrs,4) before reading href and accumulates those exact scalar bytes; no URL parse, base selection or base freeze is changed. HTML details adds16+2S(attrs,4) for name/open lookup and counter bookkeeping. Presence of open, including the empty value, starts a conceptual closed-to-open task sequence. Nonempty names search the fresh-root winner map for8+S(winners,name bytes). The first winner pays the insertion row, copies its group name and stages an owned group record. A later open member pays the copy-only removal row, deducts only its copied open key/value from new retained bytes, and advances sequence again. Each final task pays16 plus staged push.

Thus a losing member retains a closed-to-closed coalesced task at the second sequence number. Final winner state alone would not preserve this sequence. Source attributes, old group membership, active/pending tasks and trackers are unchanged. Name bytes count all copied details names; base bytes count all copied HTML base hrefs, including detached/template-contained ones. First-summary cache entries are not copied; fresh IDs start cold.

Metadata admission starts with8. Each group checks its exact fresh key in the old map for8+S(old groups,name bytes), then prepays insertion at old count+staged index. Each task pays16+S(old trackers,0)+S(old tasks,0), checks the fresh ID/sequence and active-task collision, then admits each future tracker/task insertion independently. Sequence additions are checked. No complete old map, cache, group or arena scan occurs for a detached leaf.

## Atomic publication and retained limits

All selected source payloads, nodes, links, group names and coalesced tasks remain in an owned local plan. Retained bytes are old retained plus exact new payload bytes minus copied attributes actually removed during staging. Source payloads are never credited. Node and retained limits are checked before publication; fresh empty nodes and shallow template content consume real slots.

After the plan and metadata are admitted, charge128 logical bytes per new node and pay8+2N+6G+6T for publication. If the arena lacks spare slots, additionally pay1+2*old_len and charge(old_len+N)*sizeof(Node) before its fallible reserve. This is the final fallible operation. After it succeeds, push already-owned nodes, insert already-owned group/task/tracker records and assign the four counters. There is no later Result, callback, quota decision, URL operation or cache mutation. The inherited infallible BTree allocation boundary remains explicit. A quota/fallible-allocation error leaves all old Document logical state, arena/child capacities and payload buffers unchanged; charged work/heap is consumed, not restored. Allocator process failure is outside this result contract.

Real arena growth is the only leaf operation whose copy cost depends on total arena length. A large unrelated arena with spare capacity and unrelated groups has the same leaf scratch schedule. Temporary allocations are charged on each reached allocation and never refunded, even when subsequently dropped or when an error ends staging. Actual allocator rounding and infallible allocation failure are not converted into a universal fallible-OOM guarantee.

## Private witnesses and inherited refusal

The held inventory has17 helper tests and one exact-storage test. Tests use literal IDs/units/queue sequence expectations, snapshot-admitted reciprocal depth256 trees, malformed selected paths, exact source preservation, old active tasks/frozen base/cold summaries, real node-cap states, and explicitly labeled synthetic retained-counter boundaries. Only two small fixtures sweep every work cut. Exact and one-short work/heap boundaries are calibrated from successful equivalent setup, with absolute allocated37, and compare full private Document Debug state, arena/child capacities and payload pointers. No exhaustive large-tree sweep is used; BTree allocator capacity is not exposed or claimed.

The inherited 500-details Runtime refusal remains justified by the new schedule. Each of its499 closed one-attribute details costs at least217 work:32 validation+22 tag+48 iterator creation/next/EOF+16 key+10 value+32 first map insertion+8 children reserve+5 staged node push+16 hook discrimination+28 details lookups. That is108283 before marks, DFS or the remaining nodes, already above100000. This is a source-derived lower bound, not an executed measurement and not an added compatibility fee. The former coarse details fee is removed; its original assertion/source is preserved by Runtime history.

Full form/script cloning state, distinct owner-Document arenas, Document cloning, XML/CDATA/Attr/ShadowRoot and complete custom-element/observer/reaction behavior remain outside this represented scope. All host fields actually present in the selected supported graph copy exactly subject to existing resource limits, without silently reapplying parser truncation.
