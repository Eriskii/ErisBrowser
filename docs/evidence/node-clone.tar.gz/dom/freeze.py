#!/usr/bin/env python3
"""Inert source/hash/extraction binding plus rustfmt --check; no compiler/engine."""
from pathlib import Path
import datetime, difflib, hashlib, json, re, subprocess
A=Path('/tmp/eris-node-clone-1/dom')
W=Path('/tmp/eris-node-clone-1/worktree')
BASE='0df8d80d99412fb701c9ef7d55ab9d9d15b6efb5'
owned=['src/dom.rs','src/dom/mutation_budget.rs','src/dom/node_clone.rs','src/dom/node_clone/tests.rs','src/dom/string.rs','src/dom/text_replacement.rs']
def digest(b): return hashlib.sha256(b).hexdigest()
def info(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def save(name,obj):
 p=A/name
 if p.exists(): raise RuntimeError(f'refuse overwrite {p}')
 p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
# Re-verify retained originals against actual published Git objects.
before=json.loads((A/'before.json').read_text())
for row in before['files']:
 b=Path(row['retained']).read_bytes()
 assert len(b)==row['bytes'] and digest(b)==row['sha256']
 assert subprocess.check_output(['git','show',f'{BASE}:{row["path"]}'],cwd=W)==b
old=(A/'before/src/dom/text_replacement.rs').read_text()
new=(W/'src/dom/text_replacement.rs').read_text()
budget=(W/'src/dom/mutation_budget.rs').read_text()
start=old.index('pub(crate) struct DomMutationBudget')
end=old.index('struct MovingDetails')
old_block=old[start:end]
new_block=budget[budget.index('pub(crate) struct DomMutationBudget'):]
for name in ['add','mul','tree','search','movement','map_nodes','push']:
 new_block=new_block.replace('pub(super) fn '+name,'fn '+name)
assert old_block.rstrip()==new_block.rstrip()
assert old[end:]==new[new.index('struct MovingDetails'):]
# Reverse exact local module/re-export delta and exact-storage additions.
dom=(W/'src/dom.rs').read_text()
dom=dom.replace('mod mutation_budget;\nmod node_clone;\n','',1)
dom=dom.replace('pub(crate) use mutation_budget::DomMutationBudget;\n','',1)
dom=dom.replace('pub use string::{DomScalars, DomString, DomUnits};\n','pub use string::{DomScalars, DomString, DomUnits};\npub(crate) use text_replacement::DomMutationBudget;\n',1)
assert dom==(A/'before/src/dom.rs').read_text()
s=(W/'src/dom/string.rs').read_text()
start=s.index('    /// The caller admits the exact payload allocation')
end=s.index('    pub fn scalar',start)
method=s[start:end]
s=s[:start]+s[end:]
start=s.index('    #[test]\n    fn exact_fallible_copy_preserves_variant_and_independent_buffers')
end=s.index('    #[test]\n    fn owned_scalar_and_nonscalar_buffers_move_without_duplicate_storage',start)
test=s[start:end]
s=s[:start]+s[end:]
assert s==(A/'before/src/dom/string.rs').read_text()
(A/'exact-copy-method.txt').write_text(method)
(A/'exact-copy-test.txt').write_text(test)
for path in owned:
 b=(W/path).read_bytes()
 assert not any(line.rstrip(b' \t')!=line for line in b.splitlines()),path
# Formatter checking only; prior failure and successful formatting are retained explicitly.
formatter='/tmp/eris-vulkan-rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin/rustfmt'
command=[formatter,'--check','--edition','2024','--config','skip_children=true',*owned]
result=subprocess.run(command,cwd=W,capture_output=True)
(A/'format-check.stdout').write_bytes(result.stdout); (A/'format-check.stderr').write_bytes(result.stderr)
save('format-check.json',{'command':command,'cwd':str(W),'exit_code':result.returncode,'created_utc':now(),'stdout':info(A/'format-check.stdout'),'stderr':info(A/'format-check.stderr'),'compiler':False,'engine':False})
assert result.returncode==0
save('formatting-history.json',{'status':'Earlier tool outcomes transcribed; final check has captured output above','earlier_attempts':[{'command':'rustfmt +1.88.0 --edition 2024 src/dom/node_clone.rs src/dom/string.rs src/dom/mutation_budget.rs src/dom/text_replacement.rs','exit_code':1,'output':'info: syncing channel updates for 1.88.0-x86_64-unknown-linux-gnu\nerror: could not create temp file /home/eriskii/.rustup/tmp/9si04k1mzb161gjt_file: Read-only file system (os error 30)\n','effect':'Failed in rustup before source formatting; no compilation or engine.'},{'command':[formatter,'--edition','2024','--config','skip_children=true',*owned],'exit_code':0,'stdout':'','stderr':'','observed_successful_invocations':2,'effect':'Formatting only, including final pre-freeze corrections; prior exact timestamps not reconstructed.'}],'read_only_locator_errors':['Permission denied while listing /opt','zsh unmatched glob while looking for an installed rustfmt'],'final_check':info(A/'format-check.json'),'compiler':False,'engine':False})
save('extraction-proof.json',{'status':'Source-only exact reverse-delta checks passed','created_utc':now(),'base_commit':BASE,'before':info(A/'before.json'),'originals_match_published_git':True,'old_budget_helpers':{'sha256':digest(old_block.rstrip().encode()),'bytes':len(old_block.rstrip().encode()),'comparison':'Exact bytes after removing only newly added pub(super) on seven shared helpers; work/charge visibility retained.'},'replacement_algorithm_tests_from_MovingDetails_byte_exact':True,'dom_module_reexport_delta_reverses_exact':True,'string_new_method_and_test_removal_reverses_exact':True,'preserved_string_method':info(A/'exact-copy-method.txt'),'preserved_string_test':info(A/'exact-copy-test.txt'),'sources':[info(W/p) for p in owned],'compiler':False,'engine':False})
tests=re.findall(r'#\[test\]\s*fn\s+(\w+)\(', (W/'src/dom/node_clone/tests.rs').read_text())
assert len(tests)==17 and len(set(tests))==17
save('test-inventory.json',{'status':'Held uncompiled private tests; no pass claim','helper_groups':17,'exact_storage_groups':1,'new_dom_total':18,'helper_test_names':tests,'exact_storage_test':'exact_fallible_copy_preserves_variant_and_independent_buffers','plan':info('/tmp/eris-node-clone-preparation-1/layout/private-test-design-ready.json'),'design_consolidation':'Nineteen proposed topics consolidated into17 helper groups, plus one representation-copy group; topics covered by named tests, not a claim of19 helper bodies.','cut_scope':'Every work cut on two small fixtures only; exact/one-short work and heap for hooks/no hooks and reached/no arena growth; real node-cap setup without exhaustive large-state sweep.','retained_limit_scope':'Explicit synthetic private counter arithmetic with independent67-byte final copied addition; not a reconstructed32MiB source.','compiler':False,'engine':False})
# Preserve exact patch and six source snapshots.
patch=''
for row in before['files']:
 p=row['path']; patch+=''.join(difflib.unified_diff(Path(row['retained']).read_text().splitlines(True),(W/p).read_text().splitlines(True),fromfile='before/'+p,tofile='held/'+p))
(A/'existing-source.diff').write_text(patch)
files=[]
for p in owned:
 target=A/'source'/p; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes((W/p).read_bytes())
 data=info(target); files.append({'path':p,'bytes':data['bytes'],'sha256':data['sha256'],'held_copy':str(target)})
refs=['before.json','ledger.md','extraction-proof.json','test-inventory.json','formatting-history.json','format-check.json','existing-source.diff','pre-freeze-corrections/receipt.json','pre-freeze-corrections/node_clone.rs','pre-freeze-corrections/tests.rs','freeze.py']
external=['/tmp/eris-node-clone-preparation-1/layout/checked-clone-ready.json','/tmp/eris-node-clone-preparation-1/layout/private-test-design-ready.json','/tmp/eris-node-clone-preparation-1/root/plan-acceptance.json','/tmp/eris-node-clone-preparation-1/root/published-base.json','/tmp/eris-node-equality-preparation-1/runtime/stdlib-proof.md','/tmp/eris-node-clone-1/runtime/dom-extraction-incremental.json']
save('source-ready.json',{'status':'Held checked-clone Document implementation; uncompiled and unexecuted','created_utc':now(),'base_commit':BASE,'worktree':str(W),'file_count':len(files),'files':files,'references':[info(A/p) for p in refs]+[info(p) for p in external],'new_dom_groups':18,'helper_groups':17,'exact_storage_groups':1,'api':'Document::clone_node_checked(source:NodeId, deep:bool, &mut DomMutationBudget)->Result<NodeId,DomDataError>','old_replacement_fees_unchanged':True,'new_clone_general_map_envelope':'S+4M+32; nonempty structural256(H+1)+32','atomic_result_boundary':'All Result errors precede final arena reserve and owned publication; infallible BTree allocator boundary remains.','runtime_prefix_work':26,'compiler':False,'engine':False,'review_required':'Root and peer source/fee review before root compilation; no fresh performance measurements claimed.'})
print(json.dumps({'source_ready':info(A/'source-ready.json'),'ledger':info(A/'ledger.md'),'inventory':info(A/'test-inventory.json'),'extraction':info(A/'extraction-proof.json'),'files':files},indent=2))
