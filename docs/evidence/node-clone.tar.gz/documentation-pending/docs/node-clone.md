# Node.cloneNode

`Node.prototype.cloneNode` is an ordinary method for the represented
non-Document node kinds. It creates detached copies with fresh node identities,
preserves exact stored character data and element fields, and optionally copies
ordinary descendants. Document cloning remains explicitly unsupported.

The cached nonconstructible method has name `cloneNode`, length zero and an
ordinary writable/enumerable/configurable descriptor. Its receiver must be an
authentic node. The optional argument uses Boolean conversion, defaults to false,
and invokes no authored conversion hooks. Argument expressions finish before the
method runs, including ignored additional arguments. Their mutations and thrown
values retain their ordinary effects. Saved methods, own shadows, prototype
replacement and deletion use ordinary property behavior; removing the method
does not expose the former virtual route.

Copies own their payloads and have fresh default interface prototypes. Runtime
expandos, assigned handlers, registered listeners and per-node prototype overrides
are not copied. Text, Comment and processing-instruction data retain unmatched
UTF-16 units. Processing-instruction data that was mutated to contain `?>` copies
as stored. Stored tag, attribute and namespace annotations, and DocumentType
name, optional identifiers and quirks flag, are copied directly. The copier does
not recreate data through parser factories or silently truncate a stored field.

An HTML template always receives a fresh content fragment, including a shallow
copy. Deep cloning processes the content hook before ordinary children, with
separate child vectors and fresh reciprocal host/content references. Cloning a
hosted fragment directly produces a hostless fragment. Template contents retain
separate ordinary roots; independent inert owner Documents remain unfinished.

The [DOM cloning algorithm](https://dom.spec.whatwg.org/#concept-node-clone)
specifies copying and insertion order. The HTML
[template hook](https://html.spec.whatwg.org/multipage/scripting.html#the-template-element)
and [details rules](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element)
define the represented additional effects. Copied open details queue fresh toggle
tasks. Later copied members of the same name group close themselves; coalescing
can retain a closed-to-closed task. Template-content groups are separate. Existing
groups, tasks, active dispatch and summary caches remain unchanged. Detached base
copies contribute their href storage without changing the connected base URL.

## Publication and limits

The checked copier stages the complete selected graph and its metadata before
publication. It admits payload copies, traversal, typed temporary storage,
metadata insertion, cleanup, logical nodes and actual arena growth. A final
fallible arena reservation precedes an admitted commit without further budget
checks. An ordinary helper or native-body Result refusal leaves the document,
source payloads, arena capacity and existing metadata unchanged; consumed budget
is not refunded. The inherited BTree allocator can still abort on process OOM.

This boundary covers the checked copier and native wrapper. Generic VM result
handling or subsequent authored work can exhaust after a successful copy, and
completed argument effects are retained. Whole-evaluation rollback is not claimed.

The root starts at depth zero. Ordinary edges and template-to-content edges each
add one; depth 256 is permitted and an attempted 257th edge refuses. Selected
links, kinds, duplicate visits and template pairs are checked. Shallow copying
does not traverse unselected descendants, and cloning a subtree does not audit
its former ancestry. A leaf with spare arena capacity needs no whole-document
scratch or metadata scan. Real growth of a full node arena is charged separately.
Existing node, retained-byte, work and heap limits remain in force; an allowed
depth does not imply every shape at that depth fits those budgets.

The represented prototype now has 31 keys, placing `cloneNode` after `normalize`
and before `isEqualNode`. The constructor retains 21 keys. Metadata initialization
removes the legacy callable and installs the ordinary method. Numeric quotas,
script/event resets, worker authority and transport formats remain unchanged.

## Remaining platform work

Independent Document identity and ownership, inert template owner Documents,
full ordered Attr/prefix/namespace storage, ShadowRoot, CDATA, mutation observers,
custom-element reactions, form dirty/value/checkedness cloning and script
already-started state remain absent or incomplete. Scalar attribute storage is
copied exactly as represented; this does not make every legacy attribute producer
an exact UTF-16 producer. This increment does not establish complete DOM cloning,
full web compatibility, production security or the requested Chromium performance
threshold.

<!-- Validation and evidence are intentionally absent until actual runs finish. -->
