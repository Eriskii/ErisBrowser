# Root execution handoff

This hold contains source only. No importer, Python test, adapter, JavaScript
parser, compiler or browser was run by the author. The parent updated checkout
HEAD from e0be59b to published formatter 0abcd4a while the owned tool paths were
unchanged; the original source beforeimages remain retained.

The shared importer and conformance runner are now held. HTML's separate local
runner can bind them and run its 86-row baseline. The upstream controls are read
only by this profile's harness_preflight; no eager import reads that JSON.

Run the frozen offline import once (it refuses an existing output directory):

```sh
python3 /tmp/eris-typedarray-foundation-1/conformance/import-frozen.py
cd /tmp/eris-typedarray-foundation-1/worktree
python3 -m unittest discover -s tools -p 'test_test262_typedarray_foundation.py'
python3 -m unittest discover -s tools -p 'test_test262_*.py'
```

The first command executes the real importer using only the 693 previously
bound preparation inputs, no network fallback. It publishes the exact 632
sources, ten helpers, two legal files, seven original proofs and generated
manifest under tests/upstream/test262-typedarray-foundation. Preserve this
manifest and all import/test logs. The eight new test groups mock both adapter
and network, including positive/negative partners and tampered unselected tree
entries; no JavaScript engine is required for those tests.

For the actual before report use the parent's frozen pre-TypedArray adapter
SHA256 0aa0fbc72b6228d2b28b7bb299fe65b23aa111c61cc92fac311e505301ac05b9:

```sh
python3 tools/test262_conformance.py --profile typedarray-foundation \
  --binary /absolute/path/to/held/eris-js-final \
  --output /new/path/to/typedarray-upstream-before.json
```

Expect 1,238 retained mode rows and 64 preflight observations (common32 + new32),
with 766 modes scheduled and 472 excluded by unchanged policy. These are source
population counts, not engine outcome predictions. Preserve the process exit
and complete report even if unhealthy; do not invoke --record-baseline to stand
in for the before report. The local 54 cases + 32 controls remain separate.
