"""Root-only offline import from the exact held original upstream inputs.

This preparation does not execute the helper. No network fallback, overwrite,
source filtering or expected-result generation is permitted.
"""
import hashlib
import json
from pathlib import Path
import sys

Q = Path('/tmp/eris-typedarray-fixtures-1')
A = Path('/tmp/eris-typedarray-foundation-1/conformance')
W = Path('/tmp/eris-typedarray-foundation-1/worktree')
PROFILE = 'typedarray-foundation'
EXPECTED_INPUT_HOLD = '114a35e476e20ab0f5618ffcee536c52e801775eec0296907df1e2ca364e1bbc'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    hold = (Q / 'source-ready.json').read_bytes()
    if sha(hold) != EXPECTED_INPUT_HOLD:
        raise ValueError('frozen fixture hold changed')
    bound = {}
    for row in json.loads(hold)['files']:
        path = Q / row['relative_path']
        if path.is_symlink() or Q.resolve() not in path.resolve().parents:
            raise ValueError('aliased fixture input')
        data = path.read_bytes()
        if len(data) != row['bytes'] or sha(data) != row['sha256']:
            raise ValueError('frozen fixture input changed: ' + str(path))
        bound[row['relative_path']] = data
    source = json.loads((A / 'source-ready.json').read_bytes())
    for row in source['files']:
        if sha((W / row['path']).read_bytes()) != row['sha256']:
            raise ValueError('held profile source changed: ' + row['path'])
    output = W / 'tests/upstream/test262-typedarray-foundation'
    if output.exists():
        raise ValueError('refusing to overwrite existing imported corpus')
    sys.path.insert(0, str(W / 'tools'))
    import import_test262 as importer
    raw = f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
    api = f'https://api.github.com/repos/{importer.REPOSITORY}/git/'

    def read(url):
        if url.startswith(raw):
            key = 'upstream/original/' + url[len(raw):]
        elif url.startswith(api):
            key = 'upstream/proof/' + Path(importer.tree_proof_path(url[len(api):])).name
        else:
            raise ValueError('unbound import URL')
        return bound[key]

    importer.fetch = read
    importer.import_corpus(output, PROFILE)


if __name__ == '__main__':
    main()
