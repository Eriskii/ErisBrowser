# Text runtime concrete ledger, before compilation

The seven held runtime paths implement the reviewed Text proposal against `774c275b229198039a69cc996d0ffd05976dbf02`. No compiler or engine has run on this source. The independent fourteen-case source remains byte-exact (6a7d6f00…), and existing descriptive bootstrap assertions remain unchanged until measurement.

## Eager metadata

Two distinct cached Native bags are installed through the existing paid `install_pi_members` Text arm. Each bag owns `length` and `name`; each Native has Undefined receiver, full private name and its direct property-object ID. `Text.prototype` installs `wholeText`, `splitText`, then the existing `constructor`, retaining the class-string symbol. Its order reservation grows from two to four; the bootstrap object reservation grows from 679 to 681. No global/native registry entry or new interface identity is added.

With existing helper fees, new work is 132 for the getter function, 121 for splitText, 46/57 for their owner properties, 26 more for the later constructor insertion, and four fixed installer units: **386**. The existing interface dispatcher still pays four for its match; no new all-interface scan or fee waiver exists. The measured prior 11,022 remaining work therefore predicts **10,636**, not an observed result.

Incremental charged storage is:

`2687 + 2*sizeof(ScriptObject) + 2*sizeof(Option<AbortSlot>) + 2*sizeof(Option<f64>) + 6*sizeof(PropertyKey) + 2*sizeof(Native) + 2*B`

where `B = 16*(sizeof(PropertyKey)+sizeof(Property)) + 32*sizeof(usize) + 64`. This includes new reserved arena slots, two bag headers, four bag order slots and two extra Text order slots, literal Vec/Rc copies, two fresh metadata leaves, property payload allowances, Native handles and owned names. It makes no actual-type or successful-initialization measurement claim.

## Invocation and conversions

The native bridge prepays `4 + full_name.len()` work and `32 + full_name.len()` bytes before its reached temporary String clone, inside the existing stack-cleanup result expression. Native dispatch prepays `8 + 2*suffix.len()` with checked arithmetic. It brand-checks authentic in-range Text, checks the method's required argument, then uses existing paid Number-hint conversion and modulo unsigned-long conversion. The getter performs no argument coercion. No method reads authored `data`, `length`, `parentNode`, constructors, or public operation properties.

## Split phases

The fresh-data length count costs `1 + old.stored_bytes()`. Bounds failure creates the existing genuine IndexSizeError/code1 using paid strings and exception helpers. No suffix or parent state is published on this path.

Suffix plan retains `old.units().skip(offset)` with source work B (the skip visits the prefix) and exact result count U-offset. Existing `plan_dom_data` charges classification `source + 2R + 8`. Scalar emission charges that pass plus chosen UTF8 bytes and allocates one String; Units emission charges source+R+8, allocates exactly2R bytes, then separately pays2R+1 validation. The DOM fresh check is prepaid eight work; logical node admission uses the existing128 allowance. After emission, eight publication work and actual node-vector growth precede `create_text_node_owned`. Growth remains `1+2N` work and requested `sizeof(Node)` storage only when needed, with the fallible reserve last. No public substring result or MAX_STRING temporary is introduced.

Insertion uses the separately held DOM helper and its ledger. Runtime copies absolute steps and allocated counters back before mapping either result. This stage does not change source data. Prefix then reacquires it and plans `take(offset)` with source bound `min(B, checked4*offset)`. Eight work precede fresh replacement admission; existing emission is followed by eight work and checked owned replacement. There is no quota check after successful final replacement.

All phases remain separate: only callback effects before suffix publication; a detached new suffix after creation; an inserted suffix with original full data after insertion; completed split after replacement. The DOM ledger admits old-full-plus-new-suffix before any future source-byte release. Runtime charged allocations are cumulative, including discarded temporaries. Canonical representation may grow or shrink independently in both outputs.

## WholeText ownership split

DOM owns local sibling discovery, exact output sizing, the second data pass and the returned Vec. It allocates no whole-arena or runtime-string cache. Its contract and checked arithmetic are bound by `../dom/source-ready.json` and `../dom/ledger.md`.

Runtime always copies both DOM counters back, including Resource refusal. Only after success does it prepay `1+U` work and `32+2U` bytes for the separate Vec-to-Rc copy, then returns the exact JsString. A final copy refusal leaves the DOM unchanged. MAX_STRING remains262144units and is passed to the DOM helper; no scalar projection is used.

## Authored private witnesses, not results

Fourteen independent ordinary cases run separately in each mode (28mode expectations). Fourteen additional groups cover raw bootstrap reporting; function-bag isolation/flags/constructibility; suffix exact/one-short work+heap with spare/real arena growth; complete Scalar/Units split boundaries including late inserted prefixes; every work cut across original/detached/inserted states; representation expansion; invalid-ID/other-kind brands before conversion; wholeText exact/one-short including final Rc copy; unrelated-arena cost invariance; callback exhaustion of current node/byte allowance; empty-tail last-slot admission; no future-truncation storage credit; terminal callback cleanup; and saved getter invocation-name cleanup.

Existing raw bootstrap exact/one-short and author-turn tests will remain unchanged except descriptive counts after actual measurement. No production limit, bootstrap reset, author-entry reset, independent fixture expectation or existing success assertion has changed. Standard mutation-observer/range/CDATA facilities and split-pair rendering shape are still separate boundaries.
