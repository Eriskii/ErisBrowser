# Text DOM helper ledger

Concrete source-only ledger for `src/dom/text_operations.rs`, based on `774c275b229198039a69cc996d0ffd05976dbf02`. No compiler, tests, JavaScript, or benchmark has run for these helpers. Rustfmt parsed the three owned files with edition 2024 and child traversal disabled. Numeric runtime/DOM caps and reset behavior are unchanged.

Both APIs take the existing absolute `DomMutationBudget`. Its existing failure semantics remain: work refusal exhausts the remaining work field; allocation charges accumulate before a heap refusal. Runtime must copy both fields back on success and failure. No spent allocation is refunded. Arithmetic uses checked add/multiply before derived costs. No temporary vector, set, map, or DomString clone is used for traversal.

## insert_fresh_text_after

The caller has already created a fresh detached childless Text. This helper never allocates a DOM node or payload and never truncates the original. It returns immediately for a detached original after authentic/local checks. For an attached original it derives the parent and index internally, checks all direct child IDs/backlinks while finding the original exactly once, and walks the bounded host-inclusive ancestor path. A coherent Document parent is accepted, matching existing snapshot/raw-host admission; no public pre-insertion hierarchy check is introduced.

Let L be the parent's current child count, P the original's position, S = L-P-1 the number of shifted IDs, A the number of ancestor nodes reached, and H the number of template-fragment host associations checked.

| Reached operation | Work admitted before it | Allocation admitted |
| --- | --- | --- |
| Entry, bounded arena and two Text/leaf/identity/parent checks | 16 | none |
| Attached parent lookup/kind/length validation | 8 | none |
| Direct-child lookup/backlink/identity/search step | 12 per reached child | none |
| Ancestor lookup/kind/path/depth check | 8 per reached ancestor, including the rejecting depth step | none |
| Template host lookup, namespace/tag/association check | 16 per reached association | none |
| Final index/length setup and two-link publication, including ID shift | 8 + 2S | none |
| Only if L equals actual vector capacity: fallible reserve and old-entry relocation | 1 + 2L | (L+1) * sizeof(NodeId) |

The full newly requested child-vector block is paid while the old block remains in the cumulative ledger. With spare capacity no new block is requested or charged. Fixed fields and moved NodeIds retain the existing logical access/write units. The 16-work template association allowance includes the bounded literal comparison with `template`, whose length is fixed.

The commit cost is admitted before the growth cost; the last fallible action is `try_reserve_exact(1)`. Then Vec::insert has sufficient capacity, shifts the admitted suffix, and the new node receives its parent. There are no callbacks, quota decisions, or fallible allocations below that point. Fresh Text cannot move/change base elements, summary NodeIds, or named-details groups, so no map/cache/URL operations are performed.

Depth follows the existing snapshot edge convention: root at zero, source at at most MAX_DEPTH. A new sibling has that same depth. The ancestor loop admits exactly MAX_DEPTH parent nodes and rejects one more; template-content host edges count normally. Cyclic or excessively deep host graphs stop at the bounded limit, leaving insertion links unchanged. This is not a global graph validator: aliases elsewhere in public Rust fields are outside the fresh-node contract, and arbitrary repeated non-source children are not deduplicated by an allocating set.

## whole_text_units_bounded

Discovery starts with 16 work for arena bound, Text/leaf check and detached/attached setup. A detached receiver uses a borrowed one-ID array. An attached receiver pays 8 for parent lookup/kind/length, 8 per direct-child ID scanned to find the receiver exactly once, and 8 for each left/right boundary probe. A probe validates the child ID/backlink and, for Text, childlessness. Comment, PI, and Element stop the run without inspecting their payloads or descendants. Template host links are never sibling links. No ancestor or unrelated arena traversal occurs on this read path.

For the selected M Text nodes, B is the sum of actual stored payload bytes and U is their exact UTF-16 unit total:

- Planning pays 8 per node lookup/leaf/backlink and checked accumulator setup, then `1 + stored_bytes` before counting that node's units. Check U against the supplied result maximum after each member.
- Before allocation/emission, pay `8 + 8M + B + U` for output/reserve setup, repeated selected-node lookups, repeated source traversal and unit writes.
- Charge `32 + U * sizeof(u16)` for the Vec header/setup allowance and complete requested unit buffer, then fallibly reserve exactly U and extend from the immutable selected payloads. The fixed 32-byte allowance follows the existing string-buffer convention and bounds the 24-byte Vec header on the pinned 64-bit targets; it excludes the separate Rc header.

The helper returns an exact Vec without projection or canonicalization. Runtime separately pays the Rc header, copied units, and copy work before `output.into()`. Therefore Vec and Rc simultaneous storage are accounted independently. If that later Runtime debit refuses, this helper has not modified any node, link, payload, or cache. An empty result still has the Vec header allowance; no unit buffer is requested.

The units iterator may decode Scalar UTF-8 or read Units directly; stored bytes bound both scans. Mixed nodes join exactly, including high/low pairs spanning a node boundary. The helper does not rewrite either original payload. It does not allocate whole-arena scratch or impose a DOM payload canonicalization cap on the JS result; Runtime passes its existing MAX_STRING limit.

## Meaningful private witnesses

Fifteen groups cover: literal insertion order/full original prefix; detached no-op with retained suffix; measured exact/one-short work and heap, including a nonzero prior allocation debit; every insufficient insertion-work cutpoint; invalid IDs/identity/membership/backlinks/leaf children; bounded host cycle; structurally admitted Document-parent Text; accepted MAX_DEPTH and one-beyond; separate template lists/invalid association; unchanged frozen base and cached summary/details state; Text runs stopped by Comment/PI/Element; exact surrogate concatenation and snapshot admission; output size/work/heap refusal without mutation; unrelated-arena independence/empty output; malformed selected/boundary links.

Cutpoint budgets come from the successful real helper operation, not a duplicate formula in tests. Snapshot-depth and expected arrays are literal independent outcomes. Source data remains full after successful insertion, visibly preserving the runtime's later replacement stage. Tests do not claim physical allocator failure recovery, full public graph validation, live Range/observer reactions, or cross-node surrogate shaping by the renderer.
