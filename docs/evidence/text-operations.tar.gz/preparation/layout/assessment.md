# Text operations: source assessment

Source-only assessment against main `bb69700794bde2c0dbda26bd2994f767c3fd0712`. No implementation, compiler, JavaScript, fixture, or benchmark was run. Inspected bytes are bound in `source-inputs.json`.

The existing exact DOM-string builder and replacement admission are sufficient for the payloads. The missing tree primitive is narrowly checked insertion of a freshly allocated Text immediately after an existing Text. Reusing append and then reordering would add mutations and accounting obligations; replacing the parent's children would destroy required identities.

## Required sequence

The standard reads the current length after argument conversion, checks the offset, creates a new Text containing the suffix, captures the parent, inserts before the original next sibling if attached, adjusts live ranges, replaces the original suffix with empty, and returns the new Text. Detached Text is still shortened. `wholeText` concatenates contiguous **Text** siblings in tree order; CDATASection would participate through its Text inheritance. CDATA, live Range adjustment, and mutation-observer reactions are not represented here. [DOM splitText](https://dom.spec.whatwg.org/#dom-text-splittext), [DOM wholeText](https://dom.spec.whatwg.org/#dom-text-wholetext).

Runtime binding should use ordinary Text.prototype members with cached mutable function metadata. Brand checking must require an authentic Text, not the existing wider CharacterData guard. Finish the required unsigned-long conversion before taking any data or parent snapshot. Existing CharacterData conversion is wrapping `to_i32(number_value(...)) as u32`; it is not ToIndex. Retain only the node ID across callbacks. Missing argument and explicit undefined differ. Reuse the paid IndexSizeError construction path through a narrow shared helper if needed.

## splitText staging and admission

1. Reacquire the Text after conversion. Pay the UTF-16 length scan and reject out-of-range offsets before allocating a node. Conversion effects and the original thrown value must remain observable.
2. Plan the exact suffix with `plan_dom_data(old.units().skip(offset), ...)`; source work includes the skipped prefix. Check suffix stored-byte/node admission, emit the payload, and pay the existing logical node charge plus actual Node-vector growth before publishing with `create_text_node_owned`. Do not use the parser's clamping constructor or the JS-producing substring helper: the latter makes an unnecessary Rc copy and imposes the separate script-string output cap.
3. End the borrowed-data plan before mutating the node arena. Capture the original's current parent. If attached, insert the fresh Text directly after the original through the narrow checked core helper described below.
4. Reacquire the original data, plan its exact prefix, check replacement against the now-current retained-byte ledger, emit, and call `replace_character_data`. There are no author callbacks between these internal stages. Do not call an authored `replaceData` property or read authored `data`, `length`, or `parentNode` getters.
5. Return the new node with normal Text intrinsic mapping. Do not clone the original's own properties or alternate prototype. Offset zero, offset equal to length, and empty input still create distinct new Text nodes.

Use `DomMutationBudget` for a checked insertion bridge if helpful. Copy its absolute work/allocation counters back to Runtime on **both** outcomes, as the existing Node/title bridges do. Allocation remains cumulative; dropping a temporary or releasing old DOM payload does not refund Runtime's heap counter. No quotas or reset points need change.

### Narrow insertion contract

A possible core API accepts `(original_text, fresh_text, budget)`, derives the parent and position itself, and permits only a distinct detached childless fresh Text. The source must be childless Text with a valid parent and exactly one occurrence in that parent's child vector. Validate IDs before indexing, bound child lengths and any ancestor walk, and reject inconsistent membership, self/host cycles, or invalid parent kinds. Allow Element, DocumentFragment, and Document parents with coherent links. Ordinary script pre-insertion cannot create direct Document Text, but current raw `append_child` and `from_snapshot` explicitly admit such structurally coherent host trees. The narrow direct-insertion operation should preserve that represented state; an Element/Fragment-only guard would introduce a new host-only limitation.

This is the standard's internal insertion after a newly created node, not a new pre-insertion-validity operation. Do not manufacture ordinary HierarchyRequestError outcomes for malformed host-created Rust graphs. Return an explicit internal invalid-node/data failure (or established terminal bound failure), with no insertion writes. Snapshot admission rejects bad links, duplicate incoming edges, cycles, and leaf children; it does not enforce every Document hierarchy rule. Local checks also protect publicly mutable Rust node fields. The exact public error mapping for malformed host input should be documented separately from normal DOM exceptions.

Find the original once with a paid bounded scan. Prepay the suffix shift `children.len() - position - 1`, fixed pointer/length writes, and any fallible child-vector reserve. When capacity grows, charge the complete requested new block and relocation of existing entries; spare capacity needs no invented allocation fee. Reserve before writing either link. After admission, insert the ID and set its parent with no fallible work left inside that insertion commit. A fresh leaf has the same depth as the original and cannot bring an ancestor subtree or template association with it.

In particular, an accepted snapshot whose original Text is exactly at the admitted edge-depth boundary must remain splittable. Do not copy a new-title/container depth guard with a different depth convention. A bounded host-inclusive validation, if retained for malformed host graphs, must preserve the same accepted edge-depth definition; add that private boundary witness.

Fresh Text insertion does not change any element's order, attributes, or roots. It cannot change the selected base element/frozen URL, the cached first summary's **NodeId**, or named-details membership. Avoid invoking general base reparsing or details-group mutation merely because the raw append helper does so. This scope does not add synchronous Range, observer, slot, or custom-element reactions.

### Required partial-effect witnesses

- Before suffix publication, only author-conversion effects may remain. At node cap, even an empty suffix requires a node and must refuse.
- After publication but before insertion, a refusal may retain a detached suffix node. The original data remains intact.
- After successful insertion but before prefix replacement, a refusal may retain the inserted suffix while the original still contains its full data. Do not claim whole-operation transactionality or pre-credit the original's future byte release.
- Canonical halves can increase retained storage or create a larger intermediate peak. Units `[0xD800, 0x4E00, 0x4E01]` occupy six bytes. Splitting at one creates a six-byte scalar suffix while the original six bytes remain; only later does the original become a two-byte Units prefix. Conversely `[0x4E00, 0x4E01, 0xD800]` has a scalar prefix that grows from its four original unit bytes to six UTF-8 bytes. Final replacement admission is independently meaningful.
- A four-byte scalar astral character split between its surrogates temporarily retains six bytes, then ends with two two-byte Units nodes. Exact units must survive clone and worker snapshot transport.

Small private admission tests can place retained counters near limits without allocating huge fixtures. Cover spare/growing node and child vectors; exact and one-short work/heap at each publication stage; the two canonical-expansion shapes; invalid offset with no new node; empty suffix at node cap; invalid membership/IDs; and absolute failed-budget propagation. Keep expected tree/data outcomes literal rather than deriving them from implementation formulas.

## wholeText algorithm and accounting

Detached Text needs only its own exact data. For an attached Text, locate its position once in the actual `parent.children`, then extend left and right while sibling kinds are Text. Empty Text participates; Comment, PI, and Element stop the run. Do not flatten descendants, use `host_including_parent`, or call `dom_text_units(parent)`. Associated template contents have their own fragment parent; ordinary template children are a separate list.

A borrowed sibling interval avoids whole-arena traversal scratch. Pay position finding, interval bounds, every reached kind/ID check, UTF-16 counting, scalar decoding work for Scalar payloads, and exact unit emission. If defensive validation scans more of the parent vector, admit that scan too. Bound the checked total by the existing `MAX_STRING`; reserve a Vec for exactly that many units and pay the eventual Rc copy under the existing string convention (`64 + 4 * units`, plus actual scan/copy work). Return units directly without a replacement projection. Adjacent high/low surrogates may form a pair in the returned string even though each stored node remains unpaired. The getter must not merge nodes or rewrite data.

Two new metadata functions (splitText and the wholeText getter) add genuine bootstrap work/storage. Measure that installation through existing diagnostics once authorized; do not infer sufficient headroom from the pending Node-constant optimization or reduce existing fees to fit.

## Browser and ownership checks

Use a compact scalar/ASCII connected Text witness split at a word boundary, retain both IDs, then mutate the suffix through a real click. Check exact data and child order, literal wholeText, nonempty text drawing, and a whole-canvas comparison against an independently built **same two-node** scalar reference. The worker should return the same IDs/units in its admitted snapshot and the expected changed pixels. Existing wire encoding needs no version change.

Keep a separate exact-unit case with `[65, 0xD83D, 0xDE80, 66]` split at two. Its prefix is `[65, 0xD83D]`, suffix `[0xDE80, 66]`, and wholeText equals the original four units. Check cloned/snapshotted payloads independently. Current layout projects each Text's `scalar_values()` separately; this split therefore exposes two replacement projections rather than a renderer-wide cross-node surrogate decoder. Do not make pair-shaped pixel equality a passing oracle for this operation. Arbitrary word splits can also expose existing per-node tokenization; a scalar reference with the identical split avoids claiming that separate rendering work is complete.

Page relayout reads the live document. Separate small witnesses can show unchanged aggregate title/style/clean-textarea values after splitting, and refreshed title/style/clean-textarea results after suffix mutation. Inline styles compare exact direct-child text, so splitting alone should not invalidate the semantic CSS source. Preserve the existing worker scalar title cap and URL fallback. Dirty textarea editing, selection/ranges, and synchronous reactions remain outside this increment.

Finally test a Text in template content and one among ordinary template children: each suffix stays in its actual list, wholeText never crosses the template host, and the associated fragment remains unpainted. A base element and a details/summary sibling can establish that their identity/cache/frozen-base behavior is unchanged by insertion of the fresh leaf.

## Independent literal source glance

Read all fourteen current bodies in `../cases.js` without importing or executing them. No concrete expected-unit, callback-order, or exception-prefix defect found. The fresh-data callback expects destination order `[before, after, original, suffix]`; the wrapping-number cases, endpoint distinct-node cases, exact surrogate arrays, saved-member deletion/restoration, and alternate-prototype result checks are internally coherent. The shared prerequisite exercises the actual saved split and getter before expected-error checks. The complete property-order assertion is an intentional Web IDL installation requirement, not an observation of the current missing implementation. This is not a quota-feasibility or pass claim.
