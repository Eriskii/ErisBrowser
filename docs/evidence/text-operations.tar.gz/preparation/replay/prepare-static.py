#!/usr/bin/env python3
"""Author immutable replay files with data-only hashes; never import replay/tools."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREP = HERE.parent
PRIOR = Path('/tmp/eris-node-constants-batch-1/replay-preparation')
FIXTURE_SHA = '6a7d6f008628d4fab814ab380dc1e1590a77a22b6154532ec7a39a4efc0e2363'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


history = []
for origin, relative in [
    (PREP / 'cases.js', 'independent/cases.js'),
    (PREP / 'cases.json', 'independent/cases.json'),
    (PREP / 'source-ready.json', 'independent/source-ready.json'),
    (PREP / 'references.json', 'independent/references.json'),
    (PREP / 'layout/review.json', 'history/layout-review.json'),
    (PRIOR / 'replay.py', 'history/node-constants-replay.py'),
    (PRIOR / 'source-ready.json', 'history/node-constants-source-ready.json'),
    *[(PRIOR / 'tools' / name, 'tools/' + name) for name in (
        'test262_conformance.py', 'html_conformance.py', 'import_test262.py')],
]:
    raw = origin.read_bytes()
    with (HERE / relative).open('xb') as stream:
        stream.write(raw)
    history.append(dict(origin=str(origin), copy=relative, bytes=len(raw), sha256=digest(raw)))
save(HERE / 'preparation-history.json', history)

fixture = (HERE / 'independent/cases.js').read_bytes()
assert digest(fixture) == FIXTURE_SHA
authored = json.loads((HERE / 'independent/cases.json').read_text())
assert authored['ordinary_sources'] == 14 and authored['ordinary_modes'] == 28
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
prefixes = [
    ('utf16-literal', 'common',
     r"const s='A\uD83D\uDE80\uD800';var e=[65,55357,56960,55296];"
     "if(s.length!==4)throw new TypeError('UTF16 literal length');"
     "for(var i=0;i<4;i++){if(s.charCodeAt(i)!==e[i])throw new TypeError('UTF16 literal unit');}"),
    ('saved-text-method-getter', 'feature',
     "if(typeof Text!=='function'||typeof Object.getOwnPropertyDescriptor!=='function')"
     "throw new TypeError('Text descriptor prerequisite');"
     "var m=Object.getOwnPropertyDescriptor(Text.prototype,'splitText'),"
     "g=Object.getOwnPropertyDescriptor(Text.prototype,'wholeText');"
     "if(!m||typeof m.value!=='function'||!g||typeof g.get!=='function'||g.set!==undefined)"
     "throw new TypeError('saved Text functions');"
     "var a=new Text('ab'),b=m.value.call(a,1);"
     "if(!b||a===b||a.data!=='a'||b.data!=='b'||a.parentNode!==null||b.parentNode!==null||"
     "g.get.call(a)!=='a'||g.get.call(b)!=='b')throw new TypeError('working detached split and getter');"),
    ('split-adjacency', 'feature',
     "if(typeof Text!=='function'||typeof DocumentFragment!=='function'||"
     "typeof Object.getOwnPropertyDescriptor!=='function')throw new TypeError('Text adjacency constructors');"
     "var m=Object.getOwnPropertyDescriptor(Text.prototype,'splitText'),"
     "g=Object.getOwnPropertyDescriptor(Text.prototype,'wholeText');"
     "if(!m||typeof m.value!=='function'||!g||typeof g.get!=='function')"
     "throw new TypeError('Text adjacency methods');"
     r"var box=new DocumentFragment(),left=new Text('['),a=new Text('A\uD83D\uDE80B'),right=new Text(']');"
     "if(typeof box.append!=='function')throw new TypeError('fragment append prerequisite');"
     "box.append(left,a,right);"
     "var before=box.childNodes;"
     "if(before.length!==3||before[0]!==left||before[1]!==a||before[2]!==right)"
     "throw new TypeError('fragment append success');"
     "var b=m.value.call(a,2),children=box.childNodes;"
     "if(!b||a===b||children.length!==4||children[0]!==left||children[1]!==a||"
     "children[2]!==b||children[3]!==right||b.parentNode!==box||"
     "a.data.length!==2||a.data.charCodeAt(0)!==65||a.data.charCodeAt(1)!==55357||"
     "b.data.length!==2||b.data.charCodeAt(0)!==56960||b.data.charCodeAt(1)!==66)"
     "throw new TypeError('actual split adjacency and units');"
     "var joined=g.get.call(b),expected=[91,65,55357,56960,66,93];"
     "if(joined.length!==6)throw new TypeError('wholeText adjacency length');"
     "for(var i=0;i<6;i++){if(joined.charCodeAt(i)!==expected[i])"
     "throw new TypeError('wholeText adjacency units');}"),
]
controls = []
for pair, area, prefix in prefixes:
    for positive in (True, False):
        controls.append(dict(name=pair + ('-positive' if positive else '-wrong'),
                             pair=pair, positive=positive, area=area,
                             modes=['sloppy', 'strict'],
                             source=prefix + ('' if positive else "throw new Error('deliberately wrong expectation');"),
                             expected_observation=complete if positive else wrong))
inventory = dict(fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA,
                 collection='textOperationCases',
                 cases=[dict(name=row['id'], modes=['sloppy', 'strict'], expected_observation=complete)
                        for row in authored['ordinary_cases']],
                 controls=controls, case_modes=28, control_modes=12,
                 baseline_binary=None,
                 deferred_cdata=dict(admitted=False, sources=2,
                                     reason='XMLDocument/CDATASection prerequisites not represented; no deferred source is executed'))
save(HERE / 'replay-inputs.json', inventory)

old = (PRIOR / 'replay.py').read_text()
new = old
for before, after in [
    ('Frozen Node constant observations', 'Frozen Text operation observations'),
    ('e3253ef6cdc80310be70fa6975e5bbe41ba9482177ac568e6bc5dc2156685d1a', FIXTURE_SHA),
    ('nodeConstantCases', 'textOperationCases'),
    ("len(inventory['cases']) == 7", "len(inventory['cases']) == 14"),
    ("== (14, 12)", "== (28, 12)"),
    ("file='node-constants.js'", "file='text-operations.js'"),
    ('len(matrix) == 26', 'len(matrix) == 40'),
    ("for case, _ in matrix}) == 26", "for case, _ in matrix}) == 40"),
    ('Frozen 14 independent case modes', 'Frozen 28 independent case modes'),
]:
    assert before in new, before
    new = new.replace(before, after)
assert "len(matrix) == 40" in new
ast.parse(new)
with (HERE / 'replay.py').open('x') as stream:
    stream.write(new)
with (HERE / 'replay.py.diff').open('x') as stream:
    stream.write(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True),
                                           fromfile='held-node-constants/replay.py', tofile='text/replay.py')))

# Reconstruct the established fingerprint formula directly as data. Do not
# import replay.py or a helper module and do not construct any child process.
rows = []
for kind, inputs in [('case', inventory['cases']), ('control', controls)]:
    for row in inputs:
        body = (fixture + b'\nif(textOperationCases.' + row['name'].encode() +
                b'() !== true) throw new Error("case did not return true");'
                if kind == 'case' else row['source'].encode())
        for mode in row['modes']:
            identity = dict(source_sha256=digest(body), mode=mode,
                            metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None),
                            harness=[])
            fingerprint = digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())
            item = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind,
                        source_sha256=digest(body), case_sha256=fingerprint,
                        expected_observation=row['expected_observation'])
            if kind == 'control':
                item.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                            partner=row['pair'] + '-positive#' + mode)
            rows.append(item)
assert len(rows) == len({r['id'] for r in rows}) == 40
paths = [HERE / n for n in ('replay.py', 'replay-inputs.json', 'preparation-history.json')]
paths.extend(HERE / row['copy'] for row in history)
frozen = dict(fixture_sha256=FIXTURE_SHA,
              inventory_sha256=binding(HERE / 'replay-inputs.json')['sha256'],
              replay_sha256=binding(HERE / 'replay.py')['sha256'],
              runner_sha256=binding(HERE / 'tools/test262_conformance.py')['sha256'],
              bounds=dict(timeout_seconds=3, stdout_limit=96*1024, stderr_limit=64*1024,
                          execution='sequential inherited run_case'),
              bound_inputs=[binding(p) for p in paths], rows=rows)
save(HERE / 'replay-matrix.json', frozen)
for row in frozen['bound_inputs']:
    assert binding(Path(row['path'])) == row
for row in controls:
    positive = next(x for x in controls if x['pair'] == row['pair'] and x['positive'])
    assert row['source'] == positive['source'] + ('' if row['positive'] else "throw new Error('deliberately wrong expectation');")
assert r"\uD83D" in prefixes[0][2] and r"\\uD83D" not in prefixes[0][2]
assert all('futureCdataTextCases' not in row.get('source', '') for row in controls)
save(HERE / 'static-validation.json', dict(
    status='passed data-only construction and consistency checks',
    matrix_rows=40, ordinary_modes=28, control_modes=12, bound_files=len(paths),
    python_ast='replay.py parsed, never imported or executed',
    independent_fingerprint='same source/mode/metadata/harness identity serialization as held case_fingerprint',
    controls='three exact-prefix positive/wrong pairs; prerequisite TypeError versus intentional intrinsic Error tail',
    fixtures='all14 names from the held inventory; exact source bytes retained; deferredCDATA absent',
    engine_compiler_or_driver_runs=0, helper_imports=0))
print(json.dumps(dict(driver=binding(HERE / 'replay.py'), matrix=binding(HERE / 'replay-matrix.json'),
                      validation=binding(HERE / 'static-validation.json')), indent=2))
