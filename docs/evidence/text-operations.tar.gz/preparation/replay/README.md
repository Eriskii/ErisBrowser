# Held Text operation replay preparation

This is an inert adaptation of the held Node constant ERJS replay. The 14 independent Text source bodies remain byte-exact, each with a fixed ordinary-success expectation in sloppy and strict mode. The matrix contains 28 case rows and 12 control rows. The two deferred CDATA sketches are excluded: XMLDocument/CDATASection construction is outside the represented prerequisites. The copied original inventory's “external controls not authored” statement describes that earlier preparation; the controls here are additive.

The three control pairs cover UTF-16 source literals; saved `Text.prototype.splitText` and `wholeText` functions with actual detached success; and successful fragment insertion, split adjacency, exact surrogate halves, and wholeText joining. Each negative source has the exact positive source as its prefix, followed only by an intentional intrinsic `Error`. Every explicit prerequisite failure throws `TypeError`. A negative observation counts as verified only if its same-mode positive partner also completes successfully. Before the feature exists, failed feature controls remain failed and retained; they are not relabeled as adapter success.

`replay.py.diff` contains only fixture identity, names, and count changes from the copied prior driver. The copied helpers retain ERJS1 requests, ERJR2 responses, the four-MiB request ceiling, timeout of three seconds per process, 96-KiB stdout and 64-KiB stderr bounds, and sequential owned-child cleanup. This is the inherited direct-child supervisor, not a general descendant supervisor. All rows are retained, including missing observations, caught runner exceptions, and post-run binding failures. Ordinary result classification and control expectation matching are separate: a deliberate negative can have the helper's `failed` classification while matching the explicit intrinsic-Error control expectation.

The matrix binds the replay source, inventory, history, immutable source copies, and copied helper bytes before execution. The driver checks those bindings again afterward, together with the selected binary and matrix hashes, and retains the observed post-run bindings. The output is claimed exclusively before the first child process. Python optimization is rejected. As with the inherited driver, external termination or an output-filesystem failure can prevent final report serialization.

`prepare-static.py` was executed solely to copy bytes, construct data, parse Python AST, and hash inputs. It did not import the runner or execute the replay driver. `static-validation.json` and `static-review.json` record data-only checks. No baseline, candidate, browser, compiler, or JavaScript parser has run for this preparation. The source-ready receipt also binds the intended baseline binary supplied by root; production release/source provenance remains with that build's separate records.

Root may first run the inert verification at this fixed location:

```sh
python3 /tmp/eris-text-operations-preparation-1/replay/replay.py --verify
```

After source review, the authorized baseline command is:

```sh
python3 /tmp/eris-text-operations-preparation-1/replay/replay.py \
  /tmp/eris-node-constants-batch-1/eris-js \
  9e4ee4dc3b9f26c1b2970c72c80e40e31964627c94bd08050aae2aea7fa9257f \
  /tmp/eris-text-operations-preparation-1/replay-baseline-1.json
```

The report path must not exist. Candidate execution later uses the same held driver and matrix, a separately pinned binary, and a different fresh report path. Exit 0 means all ordinary rows and paired controls meet their expectations; exit 1 preserves ordinary/control mismatches; exit 2 reports changed bindings; exit 3 reports a caught runner failure. None of those observations changes the fixed expectations or admits the deferred CDATA sources.
