// Deferred prerequisites: XMLDocument/DOMImplementation and an authentic
// CDATASection node kind are not represented by the current engine.
// These are future ordinary-success sketches, not admitted current cases.
function textOpXmlPrerequisite() {
  if (!document.implementation || typeof document.implementation.createDocument !== 'function') {
    throw new TypeError('prerequisite: XML document factory');
  }
  var xml = document.implementation.createDocument(null, 'root', null);
  if (typeof xml.createCDATASection !== 'function' || typeof xml.createTextNode !== 'function' ||
      !xml.documentElement || typeof xml.documentElement.appendChild !== 'function') {
    throw new TypeError('prerequisite: XML Text/CDATA creation and insertion');
  }
  var cdata = xml.createCDATASection('B');
  if (cdata.nodeType !== 4) throw new TypeError('prerequisite: actual CDATA node');
  return {xml: xml, root: xml.documentElement, cdata: cdata};
}
var futureCdataTextCases = {
  whole_text_includes_cdata: function () {
    var p = textOpPrerequisite(), x = textOpXmlPrerequisite();
    var a = x.xml.createTextNode('A'), c = x.xml.createTextNode('C');
    x.root.appendChild(a); x.root.appendChild(x.cdata); x.root.appendChild(c);
    textOpUnits(p.whole.call(a), [65, 66, 67]);
    textOpUnits(p.whole.call(x.cdata), [65, 66, 67]);
    textOpUnits(p.whole.call(c), [65, 66, 67]);
    textOpCheck(x.cdata.nodeType === 4 && x.root.childNodes.length === 3, 'no normalization');
    return true;
  },
  split_cdata_returns_text: function () {
    var p = textOpPrerequisite(), x = textOpXmlPrerequisite();
    x.cdata.data = 'A\uD83D\uDE80B';
    x.root.appendChild(x.cdata);
    var tail = p.split.call(x.cdata, 2);
    textOpCheck(x.cdata.nodeType === 4 && tail.nodeType === 3 &&
                Object.getPrototypeOf(tail) === Text.prototype, 'result is Text, receiver stays CDATA');
    textOpCheck(x.root.childNodes[0] === x.cdata && x.root.childNodes[1] === tail, 'insertion order');
    textOpUnits(x.cdata.data, [65, 55357]); textOpUnits(tail.data, [56960, 66]);
    textOpUnits(p.whole.call(tail), [65, 55357, 56960, 66]);
    return true;
  }
};
