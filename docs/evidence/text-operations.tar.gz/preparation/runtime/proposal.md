# Text runtime implementation handoff

Source-only proposal against public title checkpoint `bb69700794bde2c0dbda26bd2994f767c3fd0712`, with the separately held Node-constant candidate used only as a prospective bootstrap baseline. No repository edits, compiler, script engine or benchmark executions were performed for this proposal. Independent cases remain unchanged. DOM insertion details belong to the sibling assessment; this note fixes the runtime boundary.

## Public identities and installation

Add `src/script/text_operations.rs` with private namespace `DOM.Text.`, `METADATA_OBJECTS = 2`, and the existing cached `Native.properties` representation. Use these exact identities:

| Owner key | Private suffix | Function name / length | Owner descriptor |
|---|---|---|---|
| Text.prototype.wholeText | getWholeText | get wholeText / 0 | getter; undefined setter; enumerable/configurable |
| Text.prototype.splitText | splitText | splitText / 1 | writable/enumerable/configurable data property |

Each function has its own ordinary two-key bag (`length`, `name`, both nonwritable/nonenumerable/configurable), Function.prototype ancestry, and no own `prototype`. Native receiver is Undefined; the existing construction classifier therefore rejects `new` without another constructor branch. Reuse the paid name/Native allocation pattern from `node_data_function`; preserve the metadata bag through the invocation wrapper. A cleanup-protected `text_operations_call_preflight(full_name)` pays `4 + full_name.len()` work and `32 + full_name.len()` bytes before its temporary name clone.

Install `wholeText`, then `splitText`, before the existing prototype `constructor`. This follows [Web IDL prototype installation](https://webidl.spec.whatwg.org/#es-interface-prototype-object), attributes before operations; function and owner flags follow its [attribute](https://webidl.spec.whatwg.org/#es-attributes) and [operation](https://webidl.spec.whatwg.org/#es-operations) bindings. Increase Text's existing prototype order reservation from two to four; add two function bags to the concrete bootstrap arena count. Do not create new interface globals or unscopables entries. Slottable/assignedSlot remains outside the represented inventory.

A narrow installer seam is a Text arm in the existing paid `install_pi_members(interface, prototype)` dispatch, delegating to `install_text_operations(prototype)`. This avoids a new all-interface traversal. The module name of that existing installer does not require a broad refactor. Add the new prefix before the generic `DOM.` native fallback and a matching invocation preflight branch in machine/calls.rs. Neither name exists in the current virtual get/set inventory; do not add one or classify wholeText as a virtual readonly field. Ordinary prototype lookup already handles getter-only assignment, own shadows, replacement, deletion and saved function calls.

## Receiver and conversion boundary

Suggested private signatures:

```rust
fn text_receiver(receiver: &Value, doc: &Document) -> Result<NodeId>;
fn text_index_error(&mut self) -> Result<ScriptError>;
fn text_operations_native(&mut self, suffix: &str, receiver: Value,
                          args: &[Value], doc: &mut Document) -> Result<Value>;
fn split_text(&mut self, id: NodeId, offset: usize,
              doc: &mut Document) -> Result<Value>;
fn whole_text(&mut self, id: NodeId, doc: &Document) -> Result<Value>;
```

`text_receiver` accepts only an in-range Value::Node whose intrinsic kind is Text. Document, Comment, PI, element and a plain inheritor fail before arity or conversion; an authentic Text with a constructor-supplied alternate prototype remains valid. The getter ignores supplied arguments. The method requires one argument, then uses the existing `number_value(args[0].clone(), doc)` followed by `to_i32(number) as u32 as usize`. Missing and explicitly undefined differ. Reuse existing Number-hint callbacks, exception propagation and cleanup; do not use ToIndex, clamp, string_hint or a native integer cast before conversion. Numeric wrapping and nonfinite behavior follow [Web IDL unsigned long](https://webidl.spec.whatwg.org/#es-unsigned-long).

Pay `8 + 2 * suffix.len()` for the two bounded native-name comparisons and fixed brand/arity decisions before these checks. After number conversion, reacquire all data and parent facts. Construct a genuine IndexSizeError/code 1 through paid `dom_proto_text`, `dom_exception`, `thrown_error`, matching CharacterData's existing error path. A private Text helper avoids widening the unrelated CharacterData helper just for reuse. There is no new error-name mapping.

## splitText phases and exact builder costs

The [DOM splitting algorithm](https://dom.spec.whatwg.org/#concept-text-split) creates a suffix Text, inserts it after the source if parented, then truncates the source. The runtime should retain those phases so a terminal implementation Resource refusal has a precise reached prefix. Successful endpoint splits still create distinct nodes. The source's own properties and explicit prototype survive; the returned Text uses the intrinsic default prototype, with neither copied expandos nor an override entry.

After conversion, pay `1 + B` before counting the current exact units, where B is `old.stored_bytes()` and U is the count. Reject O > U before node/payload publication. Keep checked arithmetic throughout.

1. Plan `old.units().skip(O)` with R = U - O and source_work = B. Skipping consumes the original prefix; charging only R would miss it. Use `plan_dom_data` directly, never public substringData or JsString staging: this result is a DOM node and has no intermediate JS MAX_STRING limit.
2. Pay the fixed fresh DOM check, require `admits_text_node(plan.stored_bytes())`, and pay the existing logical node allowance. Emit the canonical suffix. Pay publication work, then perform `dom_reserve_node_growth(doc, 1)` last and immediately `create_text_node_owned`. All suffix quota decisions precede its final fallible node reserve. No cloned complete old DomString is needed.
3. Drop the old borrow before arena mutation. Call the proposed DOM helper `insert_fresh_text_after(original, fresh, &mut DomMutationBudget)`. Initialize its absolute steps/allocated from Runtime and heap_limit = MAX_HEAP, and copy both counters back before mapping either result. The helper derives the current parent and position, finishes charged preparation/reservation before link writes, and leaves a detached original's fresh Text detached. No extra runtime arena reservation is charged here; the new node already exists.
4. Reacquire the original payload, plan `old.units().take(O)`, check replacement admission, emit, and publish through `replace_character_data`. Its prefix source bound can be `min(B, checked 4 * O)` (zero for take(0)): UTF8 iterator traversal reads at most four bytes per requested UTF16 unit, and this also bounds Units storage traversal. The narrow insertion helper neither runs author code nor changes source data, so the converted O remains applicable. Any future callback in that helper must invalidate this assumption explicitly.
5. Return Value::Node(fresh), with no later fallible author-facing work.

For either retained stream, current builder classification pays P = source_work + 2R + 8. Scalar emission pays P + chosen_bytes and allocates only the chosen String. Units emission pays source_work + R + 8, allocates exactly 2R bytes, and separately pays 2R + 1 for canonicality validation. Preserve these existing passes and cumulative allocations. Source length scanning, fresh checks, logical node charge, actual node-vector growth and insertion child-vector work are additional reached costs, not included in P. Existing node growth is `1 + 2 * nodes.len()` work plus requested capacity times sizeof(Node), charged only when growth is needed.

Admit the new suffix against old-full-plus-suffix storage; do not borrow credit from the future truncation. Then independently check the final prefix representation. For `A + rocket + B`, old Scalar is six bytes, intermediate storage ten, and final two Units payloads eight. Units-to-Scalar transitions can also expand: `[D800,4E00,4E01]` is six bytes, and its suffix `[4E00,4E01]` is six scalar bytes. Preserve parser/snapshot large-scalar admission separately from the existing script MAX_TEXT replacement cap.

Before suffix publication, only numeric-conversion effects survive failure. After creation, a later failure may retain a detached suffix; after insertion it may retain an attached suffix while source data is still full. Do not claim atomic rollback for the complete operation. Live ranges, mutation records and unimplemented reactions remain explicit gaps.

## wholeText collection

Do not call `dom_text_units(parent)`: that joins descendants and noncontiguous Text. A parentless Text can reuse the current paid leaf exact-read helper. For an attached Text, locate the receiver exactly once in its actual parent.children vector, then expand only the contiguous Text interval. Empty Text participates; Comment, PI and Element stop the interval. A template fragment's host is not its sibling parent. CDATA would participate by the standard, but is not represented and is not added by this increment.

Use a borrowed interval descriptor, for example `TextRun<'d> { doc: &'d Document, members: &'d [NodeId] }`, plus a parentless single-node path. No Vec of sibling IDs, whole-arena bitmap, ancestor walk, data cache or repeated previousSibling search is needed. Proposed discovery admission is a fixed 16 work plus 8 per inspected child/boundary, paid before access. Check parent ID/kind, bounded child count, receiver backlink and unique receiver occurrence. For selected nodes, require valid childless Text and the same backlink; validate boundary IDs before reading kinds. Refuse malformed local input explicitly. This is a bounded local check, not a complete graph validator or an all-sibling uniqueness promise.

Allow locally valid Document children too: `Document::from_snapshot` currently permits a Text linked directly below Document, and the splitting algorithm's insertion step is not a public pre-insert hierarchy validation. Inserting a sibling does not increase the source depth; preserve an already admitted depth == MAX_DEPTH.

First output pass: for each selected member, pay fixed node work and `1 + stored_bytes` before counting units; checked-sum U and enforce the existing 262144-unit JS result cap. Retain only scalar counts/source-byte bounds. Second pass: pay interval revisit plus `1 + sum(stored_bytes) + U` before filling exactly reserved Vec<u16>. Separately prepay `1 + U` work and `32 + 2U` bytes for the eventual Rc copy; Vec storage is its own `32 + 2U` debit. These can be one checked `64 + 4U` allocation debit before reserve, with both copy-work terms explicit. All result allocation and copying is admitted; no scalar projection/canonical DOM buffer is produced. No callbacks intervene between passes. Units spanning different nodes concatenate exactly without changing those nodes.

## Bootstrap prediction, not measurement

With the proposed one-time Text installer work4, existing two-key native helper, and exact current property-insertion fees:

| New/reached component | Additional work |
|---|---:|
| wholeText function bag, strings and Native | 132 |
| splitText function bag, strings and Native | 121 |
| wholeText owner key/insertion at count1 | 46 |
| splitText owner key/insertion at count2 | 57 |
| later constructor insertion count1 to count3 | 26 |
| one-time installer debit | 4 |
| Total | 386 |

This assumes the existing fixed interface-dispatch allowance covers its additional Text arm; review that concrete dispatch when implementing. A new charged all-interface installer would add its actual repeated dispatch cost instead. No fee reduction is proposed. Under this shape the title baseline 6280 predicts 5894 remaining, or the measured Node-batch candidate 11022 predicts 10636. Neither is a new bootstrap observation.

The arena and object count become 681; native name registry321 and legacy prototype registry25 stay unchanged. Typed incremental storage is `2687 + 2*sizeof(ScriptObject) + 2*sizeof(Option<AbortSlot>) + 2*sizeof(Option<f64>) + 6*sizeof(PropertyKey) + 2*sizeof(Native) + 2*BtreeNodeBound`, where the current map-node bound is `16*(sizeof(PropertyKey)+sizeof(Property)) + 32*sizeof(usize) + 64`. This includes both new object slots, order blocks, full new metadata leaves, all literal Vec/Rc pairs, native names/handles, owner properties and Text order growth. Existing later constructor payload charge is unchanged. Use actual measured types and raw initialization before changing descriptive snapshots; preserve first refusal if any.

## Paths and acceptance

Runtime changes should be limited to the new module/tests, script.rs module/prefix dispatch, machine/calls.rs preflight, dom_prototypes.rs capacity/count/invocation, and the narrow existing installer Text delegation in processing_instruction.rs. The DOM owner adds the fresh-Text insertion seam. No wire version, constructor prototype map, native own-property classifier or global registry change is required.

Run the original fourteen named cases separately in both modes when authorized. Add private measured exact/one-short cutpoints for every publication phase, real arena/child-vector growth separately from test-owned spare capacity, callback-created node/byte pressure, and complete cleanup. Check wholeText unrelated-arena independence, bounds, exact split-pair concatenation, and no mutation on output refusal. Metadata checks include mutable owner isolation, saved identities, missing setter strict/sloppy behavior, no constructibility, no fallback resurrection, and existing literal Node inventory unchanged. Late prefix/child insertion failures must preserve the reached new node and all earlier author effects, with budgets copied back on both outcomes. Keep deferred CDATA/range/observer/render-shaping cases distinct from represented success coverage.
