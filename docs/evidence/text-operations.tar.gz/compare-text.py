#!/usr/bin/env python3
"""Data-only complete-row comparison; never imports or invokes an engine."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
INPUTS = HERE / 'compare-text-inputs.json'
INPUT_SHA = '5286f79b6716e4b5c80987e04733dc3da73ce567b3c1dec849c856db0737841a'
OUTCOMES = {'status', 'observation', 'reason', 'stderr', 'matches_expectation',
            'matches_implementation_policy', 'verified', 'verified_with_protocol_prerequisite', 'positive_partner_matches'}
SPECS = [
    ('dom-method-identity', 'dom-method-identity-after.json', 58, 44, 'established'),
    ('object-is', 'object-is-after.json', 78, 60, 'established'),
    ('symbols', 'symbols-after.json', 242, 80, 'established'),
    ('array-descriptors', 'array-descriptors-after.json', 3574, 84, 'established'),
    ('reflect-construction', 'reflect-construction-after.json', 38, 96, 'established'),
    ('prior-CharacterData', 'local-after.json', 34, 0, 'established'),
    ('prior-PI', 'pi-regression-after.json', 40, 0, 'established'),
    ('prior-production', 'production-after.json', 24, 8, 'established'),
    ('node-original', 'original-after.json', 16, 0, 'established'),
    ('node-exact', 'exact-after.json', 20, 16, 'established'),
    ('append-exact', 'append-after.json', 14, 16, 'established'),
    ('document-title', 'title-after.json', 24, 16, 'established'),
    ('node-constants', 'node-constants-after.json', 14, 12, 'established'),
    ('text-operations', 'text-after.json', 28, 12, 'new'),
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    raw = path.read_bytes()
    return json.loads(raw), dict(path=str(path), bytes=len(raw), sha256=sha(raw))


def require(value, message):
    if not value:
        raise ValueError(message)


def before_path(name, after):
    if name == 'text-operations':
        return HERE / after.replace('-after.json', '-before.json')
    return HERE / 'comparison-before' / after


def underlying(row):
    return row['result'] if 'result' in row else row


def identity(row):
    r = underlying(row)
    return r['id'], r.get('mode', '')


def input_record(row):
    if 'result' in row:
        return {**{k: v for k, v in row.items() if k not in {'result', 'verified'}},
                'result': input_record(row['result'])}
    return {k: v for k, v in row.items() if k not in OUTCOMES}


def healthy(row):
    if 'result' in row:
        return row.get('verified') is True and row['result'].get('status') == row['expected']
    if 'expected_observation' in row:
        observation = row.get('observation', {})
        matched = isinstance(observation, dict) and all(
            observation.get(k) == v for k, v in row['expected_observation'].items())
        return (matched and row.get('matches_expectation') is True
                and row.get('verified', True) is True
                and row.get('verified_with_protocol_prerequisite', True) is True)
    return row.get('status') == 'passed'


def compare_rows(before, after):
    old = {identity(r): r for r in before}
    new = {identity(r): r for r in after}
    require(len(old) == len(before) and len(new) == len(after), 'duplicate case/control identity')
    result = dict(before_total=len(before), after_total=len(after),
                  before_healthy=sum(map(healthy, before)), after_healthy=sum(map(healthy, after)),
                  before_status_counts=dict(Counter(underlying(r).get('status') for r in before)),
                  after_status_counts=dict(Counter(underlying(r).get('status') for r in after)),
                  unchanged=0, gains=0, losses=0, other_changes=0,
                  input_changes=[], removed=[], added=[], changes=[])
    for key, a in old.items():
        if key not in new:
            result['removed'].append(a)
            continue
        b = new[key]
        if a == b:
            result['unchanged'] += 1
            continue
        inputs_same = input_record(a) == input_record(b)
        if not inputs_same:
            result['input_changes'].append(dict(id=key[0], mode=key[1],
                                                before=input_record(a), after=input_record(b)))
        category = ('gains' if inputs_same and not healthy(a) and healthy(b) else
                    'losses' if inputs_same and healthy(a) and not healthy(b) else 'other_changes')
        result[category] += 1
        # Complete original rows retain expectations, observations, reasons,
        # stderr and all derived verification flags, including unknown fields.
        result['changes'].append(dict(id=key[0], mode=key[1], classification=category,
                                      before=a, after=b))
    result['added'] = [row for key, row in new.items() if key not in old]
    return result


def controls(report):
    return report.get('controls', report.get('harness_preflight', []))


def verify_before():
    config, binding = read(INPUTS)
    require(binding['sha256'] == INPUT_SHA, 'comparator input manifest changed')
    bindings = [binding]
    for row in config['files']:
        raw = (HERE / row['path']).read_bytes()
        require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path'] + ' changed')
        bindings.append(dict(path=str(HERE / row['path']), bytes=len(raw), sha256=sha(raw)))
    historical, _ = read(HERE / 'before-comparison-inputs.json')
    require(historical['release_sha256'] == config['baseline_release_sha256'], 'baseline release mismatch')
    for row in historical['files']:
        raw = (HERE / row['path']).read_bytes()
        require(len(raw) == row['bytes'] and sha(raw) == row['sha256'], row['path'] + ' changed')
        bindings.append(dict(path=str(HERE / row['path']), bytes=len(raw), sha256=sha(raw)))
    totals = Counter()
    for name, filename, cases, checks, group in SPECS:
        report, _ = read(before_path(name, filename))
        require(report['binary_sha256'] == config['baseline_release_sha256'], name + ' baseline binary mismatch')
        require(len(report['cases']) == cases and len(controls(report)) == checks, name + ' baseline population mismatch')
        require(len({identity(r) for r in report['cases']}) == cases, name + ' duplicate case')
        require(len({identity(r) for r in controls(report)}) == checks, name + ' duplicate control')
        totals[group + '_cases'] += cases
        totals[group + '_controls'] += checks
        if group == 'new':
            require(sum(map(healthy, report['cases'])) == 0, name + ' baseline success count changed')
            require(sum(map(healthy, controls(report))) == 4, name + ' baseline controls changed')
    require(all(totals[key] == config[key] for key in totals), 'baseline totals mismatch')
    return config, bindings, dict(totals)


def compare(binary, output):
    config, bindings, populations = verify_before()
    require(not output.exists(), 'comparison output already exists')
    binary_raw = binary.read_bytes()
    binary_binding = dict(path=str(binary), bytes=len(binary_raw), sha256=sha(binary_raw))
    self_binding = dict(path=str(Path(__file__).resolve()), sha256=sha(Path(__file__).read_bytes()))
    failures, profiles = [], []
    for name, filename, cases, checks, group in SPECS:
        old, old_binding = read(before_path(name, filename))
        new, new_binding = read(HERE / filename)
        bindings.extend([old_binding, new_binding])
        if new.get('binary_sha256') != binary_binding['sha256']:
            failures.append(name + ': candidate binary mismatch')
        if new.get('binding_failures'):
            failures.append(name + ': runner reported post-run binding failure')
        binding_keys = {k for k in set(old) | set(new) if k.endswith('_sha256') and k != 'binary_sha256'}
        binding_keys.update({'fixture_sha256', 'bounds', 'harness', 'tool_hashes', 'revision',
                             'runner_policy', 'mode_cases', 'bound_inputs'})
        header_input_changes = {k: {'before': old.get(k), 'after': new.get(k)}
                                for k in sorted(binding_keys) if (k in old) != (k in new) or old.get(k) != new.get(k)}
        if header_input_changes:
            failures.append(name + ': report input binding changed')
        case_result = compare_rows(old['cases'], new['cases'])
        control_result = compare_rows(controls(old), controls(new))
        if len(new['cases']) != cases or len(controls(new)) != checks:
            failures.append(name + ': candidate population mismatch')
        for kind, rows in [('cases', case_result), ('controls', control_result)]:
            if rows['input_changes'] or rows['removed'] or rows['added']:
                failures.append(name + ': ' + kind + ' input/inventory drift')
        profiles.append(dict(profile=name, group=group, before=old_binding, after=new_binding,
                             header_input_changes=header_input_changes,
                             before_header={k: v for k, v in old.items() if k not in {'cases', 'controls', 'harness_preflight'}},
                             after_header={k: v for k, v in new.items() if k not in {'cases', 'controls', 'harness_preflight'}},
                             cases=case_result, controls=control_result))
    summary = {}
    for group in ['established', 'new']:
        summary[group] = {}
        for kind in ['cases', 'controls']:
            summary[group][kind] = {key: sum(p[kind][key] for p in profiles if p['group'] == group)
                                   for key in ['before_total', 'after_total', 'before_healthy', 'after_healthy',
                                               'unchanged', 'gains', 'losses', 'other_changes']}
    for row in bindings + [binary_binding, self_binding]:
        try:
            if sha(Path(row['path']).read_bytes()) != row['sha256']:
                failures.append(row['path'] + ': input changed during comparison')
        except OSError as error:
            failures.append(row['path'] + ': ' + str(error))
    result = dict(kind='complete-text-operations-replay-comparison', comparator=self_binding,
                  input_manifest=bindings[0], baseline_release_sha256=config['baseline_release_sha256'],
                  candidate=binary_binding, populations=populations, validation_failures=failures,
                  classification='Gain/loss means changed declared expectation health; other complete-row changes are separate. Raw statuses remain explicit. Input drift is never counted as a gain.',
                  retention='Unchanged complete rows remain in hash-bound raw before/after reports; changed/added/removed rows are also copied here without field projection.',
                  summary=summary, profiles=profiles)
    with output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(dict(summary=summary, validation_failures=failures), indent=2))
    return 2 if failures else 0


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--verify-before', action='store_true')
    parser.add_argument('--binary', type=Path)
    parser.add_argument('--output', type=Path, default=HERE / 'text-comparison.json')
    args = parser.parse_args()
    if args.verify_before:
        _, _, populations = verify_before()
        print(json.dumps(dict(verified_before=True, populations=populations), indent=2))
        return 0
    if args.binary is None:
        parser.error('--binary is required for comparison')
    return compare(args.binary.resolve(), args.output)


if __name__ == '__main__':
    raise SystemExit(main())
