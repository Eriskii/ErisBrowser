import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def checked(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def totals(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(x[i]) for x in rows) for i in range(3)]
assert totals('full-default-188-1')==[1733,0,0]
assert totals('full-native-198-1')==[1856,0,0]
source=read('candidate-source-final.json');assert len(source['files'])==16
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'held-source-final'/row['path'])
docs=read('documentation-ready.json');assert len(docs['files'])==10
for row in docs['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'documentation-draft'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(BASE/'candidate-source-final.json')
comparison=read('text-comparison.json');assert not comparison['validation_failures']
s=comparison['summary']
for kind,count in [('cases',4176),('controls',432)]:
 row=s['established'][kind];assert row['before_total']==row['after_total']==row['unchanged']==count
 assert row['gains']==row['losses']==row['other_changes']==0
for kind,count,before in [('cases',28,0),('controls',12,4)]:
 row=s['new'][kind];assert row['before_total']==row['after_total']==row['after_healthy']==count
 assert row['before_healthy']==before and row['gains']==count-before and row['unchanged']==before
 assert row['losses']==row['other_changes']==0
focus=read('focused-validation-review.json')
ci=read('node-constants-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
summary=dict(
 kind='Exact Text splitText and wholeText',base_commit=source['base'],
 scope='Ordinary Text prototype operations, authentic receiver checks and unsigned-long offset conversion; exact UTF-16 suffix creation/insertion/prefix replacement and local contiguous Text reads. Retained node identities, partial quota effects and unchanged worker transport.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-1','clippy-native-198-1','clippy-presenter-188-1','full-default-188-1','full-native-198-1','release-adapter-188-1']},
 tests=dict(default=1733,native=1856,new_groups=45,focused=focus,final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False),
 accounting=dict(remaining_bootstrap_work=10636,allocated_bytes=1741271,objects=681,object_capacity=681,native_entries=321,legacy_prototype_entries=25,additional_work=386,additional_charged_bytes=6335,bootstrap_work_limit=100000,author_work_limit=100000,cumulative_heap_limit=8388608,numeric_limits_and_resets_changed=False),
 compatibility=dict(path='text-comparison.json',sha256=sha(BASE/'text-comparison.json'),summary=s),
 retained_history=['Initial all-target compilation and all43 new DOM/runtime groups passed; all28 independent ordinary modes passed within those groups.','Before correction, bootstrap filter retained24 passes/two failures and identity filter20 passes/one failure; two stale tests overlap. Exactly three descriptive literals across two paths changed after measured bootstrap accounting.','Independent replay baseline retains all28 ordinary missing-prerequisite TypeError outcomes and4/12 healthy controls; the nonzero runner exit records unmet expectations, not a passing baseline.'],
 boundaries=['Represented Text only. No CDATASection, XMLDocument, live Range adjustment, MutationObserver records, custom-element reactions or slotting.','Three mutation stages admit cumulative work/storage separately. A late resource refusal can retain detached or attached suffix Text while original data remains full; future truncation credit is never borrowed.','wholeText uses local ordinary siblings, separate template lists, exact UTF16 concatenation and separately charged Vec/Rc copies under existing MAX_STRING.','Insertion validates a local fresh-Text contract and bounded host-inclusive depth; arbitrary public host graph corruption and physical allocator OOM recovery remain outside this validation.','Page and confined-worker witness verifies exact units, retained identities, title/style/clean textarea and literal pixels. Per-node replacement-glyph reference does not claim cross-node shaping equivalence.','No performance or physical-memory measurement. Full web compatibility, complete security and the requested Chromium performance threshold remain unachieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','target','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p.is_symlink() or name in {'eris-js','final-publication-review.json'}:continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/text-operations.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
p=ROOT/'docs/evidence/text-operations.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
