#!/usr/bin/env python3
"""Root-only publisher for explicitly selected background-geometry evidence."""
from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
Q = Path('/tmp/eris-background-followup-1')
BASE = 'c9231785978b6669055fea2684749084ddddec9b'
STEM = 'background-geometry'
LIMIT = 64 * 1024 * 1024

def require(value, message):
    if not value: raise ValueError(message)

def sha(data): return hashlib.sha256(data).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def binding(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and path == path.resolve(), 'canonical regular file required')
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'symlink input')
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(row):
    require(binding(row['path']) == row, 'changed input: ' + row['path'])
    return Path(row['path']).read_bytes()

def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])
def relative(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and path.as_posix() == name, 'relative path')
    return name

def rust_totals(log, expected):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    actual = {'rows': len(rows), 'passed': sum(int(r[1]) for r in rows),
              'failed': sum(int(r[2]) for r in rows), 'ignored': sum(int(r[3]) for r in rows)}
    require(actual == expected, 'raw Rust totals')
    require(all(r[0] == ('ok' if r[2] == '0' else 'FAILED') for r in rows), 'Rust result labels')

def cargo_command(argv):
    if argv and argv[0] == 'env':
        index = 1
        while index < len(argv) and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*=.*', argv[index]): index += 1
        argv = argv[index:]
    require(argv and argv[0] == 'cargo', 'cargo check command')
    return argv

def verify_staged():
    out = W / 'docs/evidence'; summary_path = out / (STEM + '.json')
    summary = json.loads(read(binding(summary_path)))
    require(summary['base'] == BASE and git(W, 'rev-parse', 'HEAD').decode().strip() == BASE, 'staged parent')
    archive = summary['archive']; archive_path = out / archive['path']
    require(archive['path'] == STEM + '.tar.gz', 'archive basename')
    row = binding(archive_path)
    require((row['bytes'], row['sha256']) == (archive['bytes'], archive['sha256']), 'staged archive binding')
    published = dict(summary['published'])
    for path in (summary_path, archive_path):
        current = binding(path); published[path.relative_to(W).as_posix()] = {key: current[key] for key in ('bytes', 'sha256')}
    staged = set(git(W, 'diff', '--cached', '--name-only', '-z').decode().split('\0')) - {''}
    require(staged == set(published), 'exact staged publication roster')
    changed = set((git(W, 'diff', 'HEAD', '--name-only', '-z') + git(W, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')) - {''}
    require(changed == staged, 'no unstaged or unlisted publication paths')
    for name, expected in published.items():
        name = relative(name); live = binding(W / name); indexed = git(W, 'show', ':' + name)
        require({key: live[key] for key in ('bytes', 'sha256')} == expected, 'staged/live binding: ' + name)
        require(len(indexed) == expected['bytes'] and sha(indexed) == expected['sha256'], 'index bytes: ' + name)
    print(json.dumps({'status': 'clear', 'staged_files': len(staged), 'archive': archive}, indent=2))

def main():
    selected = binding(sys.argv[1]); selection = json.loads(read(selected))
    require(git(W, 'rev-parse', 'HEAD').decode().strip() == BASE, 'worktree base')
    source = selection['live_source']; inventory = json.loads(read(source))
    require(inventory['base'] == BASE and len(inventory['source_sha256']) == selection['source_count'] and selection['source_count'] >= 527, 'source identity/population')
    for name, digest in inventory['source_sha256'].items():
        require(binding(W / relative(name))['sha256'] == digest, 'live source changed: ' + name)
    changed = set((git(W, 'diff', 'HEAD', '--name-only', '-z') + git(W, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')) - {''}
    require(changed == set(selection['published']), 'exact changed/publication roster')
    for name, row in selection['published'].items():
        require(row['path'] == str(W / relative(name)), 'published path')
        read(row)
        if not name.endswith('.md'):
            require(inventory['source_sha256'].get(name) == row['sha256'], 'unbound changed runtime input')
    verified = [source]; receipts = {}; logs = {}
    for label, item in selection['checks'].items():
        receipt = json.loads(read(item['receipt'])); raw = read(item['log'])
        require(receipt['command'] == item['command'] and receipt['exit'] == item['expected_exit'], 'check argv/exit: ' + label)
        require(receipt['sha256'] == sha(raw), 'log hash: ' + label)
        require(str(Path(item['receipt']['path']).parent / receipt['log']) == item['log']['path'], 'receipt log path')
        verified.extend([item['receipt'], item['log']]); receipts[label] = receipt; logs[label] = raw.decode()
        if 'source' in item: read(item['source']); verified.append(item['source'])
        if 'rust' in item: rust_totals(logs[label], item['rust'])
    # Preserve every actual failed attempt in the bounded flat validation directory.
    validation_paths = list((P / 'validation').glob('*.json'))
    require(len(validation_paths) <= 512, 'validation receipt population')
    failures = set()
    for path in validation_paths:
        row = binding(path); attempt = json.loads(read(row))
        if 'command' in attempt and 'exit' in attempt and attempt['exit'] != 0: failures.add(str(path))
    included_failures = {item['receipt']['path'] for item in selection['checks'].values() if item['expected_exit'] != 0}
    require(failures == included_failures, 'complete failed-attempt retention')
    require(set(selection['full_suites']) == {'native', 'default'}, 'both full suites required')
    for role, label in selection['full_suites'].items():
        item = selection['checks'][label]; result = item['rust']
        require(receipts[label]['exit'] == 0 and result['rows'] > 0 and result['passed'] > 0 and result['failed'] == result['ignored'] == 0, 'complete successful suite')
        require(item['source'] == source, 'suite/final source join')
        argv = receipts[label]['command']
        expected = ['cargo', '+1.88.0' if role == 'native' else '+1.98.0', 'test', '--locked', '--offline', '--manifest-path', 'Cargo.toml']
        if role == 'native': expected += ['--features', 'vulkan-raster']
        require(argv == expected + ['--', '--include-ignored', '--test-threads=4'], 'full suite command')
    require(set(selection['final_checks']) == {'native_clippy', 'default_clippy', 'format', 'probe'}, 'final strict and probe checks')
    for role, labels in selection['final_checks'].items():
        require(isinstance(labels, list) and labels, 'nonempty final check role')
        for label in labels:
            item = selection['checks'][label]; argv = cargo_command(receipts[label]['command'])
            require(receipts[label]['exit'] == 0 and item['source'] == source, 'final successful source check: ' + role)
            if role.endswith('_clippy'):
                require(argv[2] == 'clippy' and '--all-targets' in argv and argv[-3:] == ['--', '-D', 'warnings'], 'strict all-target clippy')
                require(argv[argv.index('--manifest-path') + 1] == 'Cargo.toml', 'root clippy manifest')
                if role == 'native_clippy': require('--features' in argv and argv[argv.index('--features') + 1] == 'vulkan-raster', 'native clippy feature')
                else: require(argv[1] == '+1.98.0' and '--features' not in argv, 'default clippy toolchain/features')
            elif role == 'format': require(argv[2] == 'fmt' and '--check' in argv, 'format check')
            else:
                require(argv[2] in ('test', 'check', 'clippy') and argv[argv.index('--manifest-path') + 1] == 'tools/vulkan-raster-probe/Cargo.toml', 'probe seam manifest/operation')
                require('--features' in argv and argv[argv.index('--features') + 1] == 'browser-bridge', 'probe browser seam feature')
    item = selection['browser']; record = json.loads(read(item['record']))
    require(binding(record['path']) == {key: record[key] for key in ('path', 'bytes', 'sha256')}, 'immutable browser bytes')
    require((record['source'], record['source_sha256']) == (source['path'], source['sha256']), 'browser/source join')
    build = selection['checks'][item['build']]; strip = selection['checks'][item['strip']]
    require(record['build_receipt'] == build['receipt']['path'] and record['strip_receipt'] == strip['receipt']['path'], 'browser receipt joins')
    require(build['source'] == strip['source'] == source, 'build/source joins')
    require(cargo_command(receipts[item['build']]['command']) == ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser'], 'browser build command')
    require(receipts[item['strip']]['command'] == ['strip', '--strip-debug', record['path']], 'browser strip command')
    require(receipts[item['build']]['exit'] == receipts[item['strip']]['exit'] == 0, 'successful browser preparation')
    verified.append(item['record'])
    report_item = selection['reftests']; report = json.loads(read(report_item['report'])); manifest = json.loads(read(report_item['manifest']))
    require(report['suite'] == 'eris-self-authored-reftests' and report['conformance_claim'] is False, 'reference scope')
    require((report['passed'], report['failed'], report['total']) == (71, 0, 71), 'final references')
    require(len(manifest['cases']) == 71 and [r['name'] for r in report['cases']] == [r['name'] for r in manifest['cases']], 'reference roster')
    require(len({r['name'] for r in report['cases']}) == 71, 'duplicate references')
    require(all(r['status'] == 'pass' and r['different_pixels'] == r['maximum_channel_error'] == 0 for r in report['cases']), 'reference pixels')
    require(report['viewport'] == {'width': manifest['width'], 'height': manifest['height']}, 'reference viewport')
    require(report_item['manifest']['path'] == str(W / 'tests/reftests/manifest.json'), 'reference manifest path')
    previous = json.loads(git(W, 'show', BASE + ':tests/reftests/manifest.json'))
    require(len(previous['cases']) == 68 and manifest['cases'][:68] == previous['cases'], '68 previous reference cases unchanged')
    require({key: value for key, value in manifest.items() if key != 'cases'} == {key: value for key, value in previous.items() if key != 'cases'}, 'reference manifest metadata')
    require([case['name'] for case in manifest['cases'][68:]] == ['background-geometry-position', 'background-geometry-repeat', 'background-geometry-fractional'], 'three exact additions')
    require(inventory['source_sha256']['tests/reftests/manifest.json'] == report_item['manifest']['sha256'], 'manifest/source join')
    for case in previous['cases']:
        for field in ('test', 'reference'):
            name = 'tests/reftests/' + relative(case[field])
            require(binding(W / name)['sha256'] == sha(git(W, 'show', BASE + ':' + name)), 'prior reference body changed')
    frozen = json.loads(read(report_item['hold'])); verified.append(report_item['hold'])
    for row in frozen['files']:
        require(row['sha256'] == binding(W / relative(row['relative']))['sha256'] and row['bytes'] == binding(W / row['relative'])['bytes'], 'frozen reference inputs')
    require({row['relative'] for row in frozen['files']} == {'tests/reftests/manifest.json'} | {'tests/reftests/' + case[field] for case in manifest['cases'][68:] for field in ('test', 'reference')}, 'frozen seven reference paths')
    argv = receipts[report_item['check']]['command']
    require(argv == ['python3', str(W / 'tools/reftest.py'), '--binary', record['path'], '--output-dir', str(Path(report_item['report']['path']).parent)], 'reference command/binary/output')
    require(report['binary'] == record['path'] and receipts[report_item['check']]['exit'] == 0 and selection['checks'][report_item['check']]['source'] == source, 'reference selected binary/source')
    verified.extend([report_item['report'], report_item['manifest']])
    ci = selection['parent_ci']; ci_log = json.loads(logs[ci])
    require(receipts[ci]['exit'] == 0 and receipts[ci]['command'][:3] == ['gh', 'run', 'view'], 'parent CI receipt')
    require(receipts[ci]['command'][receipts[ci]['command'].index('--repo') + 1] == 'Eriskii/ErisBrowser', 'parent CI repository')
    require(ci_log['headSha'] == BASE and ci_log['status'] in ('queued', 'in_progress', 'completed'), 'parent CI identity/status')
    require(ci_log['conclusion'] is None or isinstance(ci_log['conclusion'], str), 'parent CI observed conclusion')
    require({'documentation', 'graphics', 'css', 'layout', 'transport', 'fixtures'} <= set(selection['reviews']), 'mandatory peers')
    for name, row in selection['reviews'].items():
        review = json.loads(read(row)); require(review['status'].startswith('clear'), 'review conclusion: ' + name); verified.append(row)
    docs = json.loads(read(selection['reviews']['documentation'])); reviewed = {r['relative']: r['sha256'] for r in docs['published_files']}
    require(all(reviewed.get(name) == row['sha256'] for name, row in selection['published'].items() if name.endswith('.md')), 'complete documentation review coverage')
    members = {}
    def add(row):
        path = Path(row['path']); require(row['bytes'] <= 8 * 1024 * 1024, 'archive member limit')
        require(not any(x in ('.git', '__pycache__', 'target') or x.startswith('target-') for x in path.parts), 'excluded archive tree')
        data = read(row); require(not data.startswith((b'\x7fELF', b'\x1f\x8b', b'PK\x03\x04', b'BZh', b'\xfd7zXZ')) and data[257:262] != b'ustar', 'ELF or recursive archive')
        require(not path.name.lower().endswith(('.tar', '.tgz', '.gz', '.zip', '.bz2', '.xz', '.7z')), 'recursive archive suffix')
        for root, prefix in ((W, 'worktree'), (P, 'evidence'), (Q, 'preparation')):
            if path.is_relative_to(root): name = prefix + '/' + path.relative_to(root).as_posix(); break
        else: raise ValueError('unlisted archive root')
        require(name not in members or members[name] == data, 'archive collision'); members[name] = data
    add(selected); add(binding(__file__)); add(binding(P / 'package-design.json'))
    for row in verified + selection['archive_inputs'] + list(selection['published'].values()): add(row)
    retained = ['implementation/source-ready.json', 'script-tests/source-ready.json',
                'root/raw-1/source-ready.json', 'root/tests-before/source-ready.json',
                'root/compile-correction-1/before.rs', 'root/compile-correction-1/after.rs', 'root/compile-correction-1/reason.json',
                'css/source-ready.json', 'layout/source-ready.json', 'layout/independent/source-ready.json',
                'root/reftests/source-ready.json', 'root/compile-correction-1/script-review.json',
                'layout/translation-correction-1/source-ready.json', 'layout/translation-correction-1/tests-source-ready.json']
    require(all('evidence/' + name in members for name in retained), 'retained original/corrected source holds')
    members['MANIFEST.json'] = encoded({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())})
    require(sum(map(len, members.values())) <= LIMIT, 'aggregate archive payload cap')
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o644; tar.addfile(info, io.BytesIO(data))
    archive = stream.getvalue(); require(len(archive) <= LIMIT, 'compressed archive cap')
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        require(len(tar.getnames()) == len(members) and set(tar.getnames()) == set(members), 'archive member roster')
        for member in tar: require(member.isfile() and tar.extractfile(member).read() == members[member.name], 'archive readback')
    out = W / 'docs/evidence'; require(out.is_dir() and out == out.resolve(), 'canonical output directory')
    for suffix in ('.json', '.tar.gz'): require(not (out / (STEM + suffix)).exists(), 'exclusive publication output')
    with (out / (STEM + '.tar.gz')).open('xb') as handle: handle.write(archive)
    require((out / (STEM + '.tar.gz')).read_bytes() == archive, 'disk archive readback')
    summary = {**selection['summary'], 'base': BASE, 'source': source, 'source_count': len(inventory['source_sha256']),
               'browser': record, 'checks': selection['checks'], 'reftests': report_item, 'parent_ci': ci,
               'published': {name: {key: row[key] for key in ('bytes', 'sha256')} for name, row in selection['published'].items()},
               'archive': {'path': STEM + '.tar.gz', 'bytes': len(archive), 'sha256': sha(archive), 'members': len(members)}}
    with (out / (STEM + '.json')).open('xb') as handle: handle.write(encoded(summary))
    print(json.dumps({'archive': summary['archive'], 'published_files': len(selection['published']), 'checks': len(receipts)}, indent=2))

if __name__ == '__main__':
    require(len(sys.argv) == 2, 'usage: package.py SELECTION.json | --verify-staged')
    verify_staged() if sys.argv[1] == '--verify-staged' else main()
