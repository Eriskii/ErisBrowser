# Background boxes in a native window

This bounded host check combines the Native color, image and opaque-gradient
box routes in one page loaded through the normal confined renderer and resource
broker. It reuses the existing Vulkan window presenter and compares one acquired
texture against the complete Canvas reference before the compositor. The
optional second case checks ordinary whole-frame CPU fallback for a rounded
image box. Actual host/window validation is pending.

The portable [fixture bundle](../tools/native-background-fixtures/) contains
admitted and rounded HTML, a literal 4×2 PNG, independent geometry/pixel oracles
and their freeze manifest. The host serves exactly `/admitted.html` and
`/two-pixels.png` on its owned loopback listener. The rounded case substitutes
only the document's body class at the same route; no additional URL authority
or renderer capability is introduced.

Each page contains three 4×2 content boxes, with 1px padding and transparent
border. Padding-box positioning and content-box clipping select distinct image
origins and paint shapes. The admitted page has one white canvas command and
three box commands: one color rectangle, one image and one gradient. Their
box-work total is `32 + 61 + 66 = 159`, with no box masks and one 12-byte generated
gradient source. Browser chrome still has its own commands and resources.

The negative case uses outer radius 3px, leaving radius 1px on the image's content
box. Native preparation must refuse phase 0, original command 2 as unsupported;
normal drawing uploads the complete CPU frame. Its independent software oracle
changes pixel `(29, 11)` from blue to `#3030ff`, using 13 of 16 coverage samples.
That negative route makes no acquired-pixel claim.

## Running the controlled check

Use a pinned release binary built with `vulkan-raster`, its recorded SHA-256,
a Vulkan loader directory and a fresh output directory:

```sh
python3 tools/native_background_host.py \
  --binary /absolute/path/to/eris-browser \
  --binary-sha256 YOUR_SHA256 \
  --loader-directory /absolute/path/to/vulkan-loader/lib \
  --fixtures tools/native-background-fixtures \
  --output /absolute/path/to/new-results \
  --with-fallback --allow-experimental-gpu
```

The current controller requires an owned Hyprland window and `hyprctl`, together
with the existing Linux Landlock ABI 6/seccomp confinement prerequisites. It
observes a 1280×880 physical window at scale 1 and zoom 1 before releasing the
document body. Headless `--width`/`--height` do not set this window size.
Non-unit browser zoom still refuses BoxDecoration commands. Existing viewport,
source, work, GPU, output and process deadlines remain unchanged.

The positive route uses `--benchmark-native-check`, which collects no timing
samples. A new check-only diagnostic records the admitted box counters with the
actual frame serial, navigation generation and viewport revision. The host
joins that record to Native presentation, exact acquired-texture verification,
the one-frame check report and positive cleanup. The complete active texture
contains 4,505,600 bytes; the literal page region is checked independently.

The host preserves served-body hashes, the pre-release diagnostic prefix,
canonical EBNI paint inputs, immutable executable/helper/loader bindings and
raw output. Page and broker PIDs are distinct values logged by the trusted
browser; they are not independently authenticated procfs lineage. Owned browser
identity, compositor control and supervised cleanup are checked separately.
A prepared-frame line alone does not prove submission or presentation.

## Validation

The two Rust Page/Native integration tests passed with their frozen literal
frames, four-command inventory, exact 159 box work and rounded fallback edge.
Host protocol tests, the full validation set and actual acquired-window outcomes
remain pending. This check adds no shader or rendering algorithm and makes no
performance, compositor-output or broader compatibility claim.

Final records will be linked from the
[summary](evidence/native-background-window/summary.json) and
[archive](evidence/native-background-window/validation.tar.gz).
