"""Select only the final observed checkpoint results; root runs this once."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

P = Path(__file__).resolve().parent.parent
W = P / 'worktree'


def binding(path):
    path = path.resolve()
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def main():
    docs, review = map(Path, sys.argv[1:])
    source = P / 'compiled-source-7.json'
    source_sha = binding(source)['sha256']
    prior = {n: binding(P / f'compiled-source-{n}.json')['sha256'] for n in (2, 3)}
    roles = [
        ('full_native', 'full-native-1', prior[2]),
        ('clippy_native_current', 'clippy-native-current-1', prior[2]),
        ('clippy_native_msrv', 'clippy-native-msrv-1', prior[3]),
        ('format', 'format-root-1', prior[3]),
        ('host_tests', 'host-python-6', source_sha),
        ('helpers_native', 'helpers-native-4', source_sha),
        ('helpers_supervisor', 'helpers-supervisor-4', source_sha),
        ('browser_build', 'browser-build-4', source_sha),
        ('browser_strip', 'browser-strip-4', source_sha),
        ('window_host', 'window-host-5', source_sha),
    ]
    checks = []
    for role, label, sha in roles:
        path = P / 'validation' / (label + '.json')
        receipt = json.loads(path.read_text())
        assert receipt['exit'] == 0
        row = {'role': role, 'receipt': binding(path), 'command': receipt['command'],
               'exit': 0, 'source_sha256': sha}
        if role == 'full_native':
            log = (path.parent / receipt['log']).read_text()
            results = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
            row['rust'] = {'rows': len(results), 'passed': sum(int(v[1]) for v in results),
                           'failed': sum(int(v[2]) for v in results), 'ignored': sum(int(v[3]) for v in results)}
            assert row['rust'] == {'rows': 36, 'passed': 2902, 'failed': 0, 'ignored': 0}
        checks.append(row)
    names = set()
    for args in (['diff', '--name-only', '-z', 'HEAD'], ['ls-files', '--others', '--exclude-standard', '-z']):
        names.update(subprocess.check_output(['git', *args], cwd=W).decode().split('\0'))
    names.discard('')
    published = [{**binding(W / name), 'path': name} for name in sorted(names)]
    reviews = [
        'root/diagnostic-peer-review.json', 'plan/html-fixture-review.json',
        'host/default-duration-correction-1/root-review.json',
        'host/default-duration-correction-1/html-review.json',
        'host/unit-monitor-control-1/root-review-2.json',
        'host/unit-monitor-control-1/html-review-2.json',
        'host/x11-physical-control-1/html-review-4.json',
        'root/publisher-layout-review-2.json', 'root/source-equivalence-4.json',
        'root/window-final-review.json',
    ]
    result = {
        'source': binding(source), 'source_count': 678,
        'rust_sources': [binding(P / f'compiled-source-{n}.json') for n in (2, 3)],
        'checks': checks, 'browser': binding(P / 'browser-final-4.json'),
        'window': binding(P / 'window-5/background-host-results.json'),
        'docs': binding(docs), 'documentation_review': binding(review),
        'reviews': [binding(P / name) for name in reviews], 'published_files': published,
        'archive_files': [binding(P / name) for name in [
            'run-check.py', 'run-tool.py', 'snapshot-source.py', 'parent-source.json',
            *[f'browser-final-{n}.json' for n in range(1, 5)],
        ]],
    }
    path = P / 'publication-selection.json'
    with path.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps(binding(path)))


if __name__ == '__main__':
    main()
