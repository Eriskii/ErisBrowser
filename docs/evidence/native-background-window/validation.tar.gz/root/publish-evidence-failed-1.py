"""Root-only bounded publication of the acquired background-window checkpoint."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent.parent
W = P / 'worktree'
BASE = '4bd9f8871ca2014ae0ba15b369d98ff06624de65'
D = W / 'docs/evidence/native-background-window'
CAP = 64 * 1024 * 1024
TREES = {'root', 'plan', 'tests', 'host', 'docs', 'validation'}
PYTHON_DELTA = {'tools/native_background_host.py', 'tools/test_native_background_host.py'}
RUST_ROLES = {'full_native', 'clippy_native_msrv', 'clippy_native_current', 'format'}
REQUIRED = RUST_ROLES | {'host_tests', 'helpers_native', 'helpers_supervisor',
                         'browser_build', 'browser_strip', 'window_host'}
FREEZE = '422b8d83a9481834aab6d70695478034ddc9725705482b0ea7bc8aecc413a4c5'
VERIFIED = {}
EXTERNAL = {}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def local(name, root=P):
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path


def binding(path):
    result = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}
    assert VERIFIED.setdefault(path, result) == result, path
    return result


def checked(spec, root=P):
    path = local(spec['path'], root)
    actual = binding(path)
    assert actual['bytes'] == spec['bytes'] and actual['sha256'] == spec['sha256'], path
    return path


def read(spec):
    return json.loads(checked(spec).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return {'rows': len(rows), 'passed': sum(int(x[1]) for x in rows),
            'failed': sum(int(x[2]) for x in rows), 'ignored': sum(int(x[3]) for x in rows)}


def argument(command, flag):
    assert command.count(flag) == 1 and command.index(flag) + 1 < len(command), flag
    return command[command.index(flag) + 1]


def external_file(path, sha, size=None):
    """Authenticate host dependencies without including executable bytes in evidence."""
    path = Path(path)
    assert path.is_absolute() and path == path.resolve() and path.is_file() and not path.is_symlink()
    actual_size = path.stat().st_size
    assert 0 < actual_size <= 128 * 1024 * 1024
    assert size is None or size == actual_size
    assert digest(path) == sha
    record = {'path': str(path), 'bytes': actual_size, 'sha256': sha}
    assert EXTERNAL.setdefault(path, record) == record
    return record


def verify_loader(record, directory_argument):
    directory = Path(record['directory'])
    assert directory.is_absolute() and directory == directory.resolve() and directory.is_dir()
    assert Path(directory_argument).resolve() == directory
    entries = []
    for path in directory.iterdir():
        assert len(entries) < 256
        entries.append(path)
    files = [path for path in sorted(entries) if path.is_file()]
    assert [path.name for path in files] == [row['name'] for row in record['files']]
    assert files and len(files) == len({row['name'] for row in record['files']})
    for path, row in zip(files, record['files']):
        assert str(path.resolve()) == row['resolved']
        external_file(path.resolve(), row['sha256'], row['bytes'])
    environment = record['environment']
    assert set(environment) == {'LD_LIBRARY_PATH', 'VK_DRIVER_FILES', 'VK_ICD_FILENAMES', 'VK_LAYER_PATH'}
    assert type(environment['LD_LIBRARY_PATH']) is str
    assert environment['LD_LIBRARY_PATH'].split(':', 1)[0] == str(directory)
    assert all(value is None or type(value) is str for value in environment.values())
    return record


def verify_x11(record, environment):
    assert set(record) == {'path', 'bytes', 'sha256'}
    directories = environment['LD_LIBRARY_PATH'].split(':')
    assert len(directories) <= 64 and all(len(value) <= 4096 for value in directories)
    candidates = [Path(value) / 'libX11.so.6' for value in directories if value and Path(value).is_absolute()]
    first = next((path.resolve() for path in candidates if path.is_file()), None)
    assert first is not None and str(first) == record['path']
    assert external_file(first, record['sha256'], record['bytes']) == record
    return record


def verify_unit_monitor(control, selected, controller):
    rows = [row for row in control['commands'] if row.get('control_stage') == 'unit-monitor']
    if selected is None:
        assert 'unit_monitor_control' not in control and not rows
        return
    assert type(selected) is int and 0 <= selected <= 255
    proof = control['unit_monitor_control']
    assert set(proof) == {'requested_id', 'monitor', 'owned_before', 'owned_after'}
    assert proof['requested_id'] == selected
    monitor = proof['monitor']
    assert set(monitor) == {'id', 'name', 'width', 'height', 'scale', 'transform', 'disabled', 'active_workspace'}
    assert type(monitor['id']) is int and monitor['id'] == selected
    assert type(monitor['name']) is str and 0 < len(monitor['name']) <= 256
    assert type(monitor['width']) is int and 1280 <= monitor['width'] <= 16384
    assert type(monitor['height']) is int and 880 <= monitor['height'] <= 16384
    assert type(monitor['scale']) in (int, float) and monitor['scale'] == 1
    assert type(monitor['transform']) is int and monitor['transform'] == 0 and monitor['disabled'] is False
    workspace = monitor['active_workspace']
    assert type(workspace) is int and 0 < workspace < 2**31
    pid = control['identity']['pid']
    assert type(pid) is int and 0 < pid < 2**31
    assert 7 <= len(rows) <= len(control['commands']) <= 48
    operations, monitor_rows, client_rows = [], [], []
    for row in rows:
        assert row['argv'][0] == controller and row['status'] == 'exited' and row['returncode'] == 0
        assert row['stderr_bytes'] == 0 and row['stderr'] == ''
        assert row['stderr_sha256'] == hashlib.sha256(b'').hexdigest()
        assert type(row['stdout_bytes']) is int and 0 <= row['stdout_bytes'] <= 256 * 1024
        assert re.fullmatch('[0-9a-f]{64}', row['stdout_sha256'])
        args = row['argv'][1:]
        if args == ['-j', 'monitors']:
            assert row['selected_monitor'] == monitor
            monitor_rows.append(row)
        elif args == ['-j', 'clients']:
            owned = row['owned_client']
            assert set(owned) == {'pid', 'monitor', 'workspace', 'size', 'floating', 'mapped'}
            assert type(owned['pid']) is int and owned['pid'] == pid
            assert owned['floating'] is owned['mapped'] is True
            assert type(owned['monitor']) is int and 0 <= owned['monitor'] <= 255
            assert type(owned['workspace']) is int and 0 < owned['workspace'] < 2**31
            assert type(owned['size']) is list and len(owned['size']) == 2
            assert all(type(value) is int and 0 < value <= 16384 for value in owned['size'])
            client_rows.append(row)
        else:
            stdout = row['stdout'].encode('utf-8')
            assert len(stdout) == row['stdout_bytes'] <= 4096 and hashlib.sha256(stdout).hexdigest() == row['stdout_sha256']
            operations.append(args)
    assert operations == [['dispatch', 'movetoworkspacesilent', f'{workspace},pid:{pid}'],
                          ['dispatch', 'resizewindowpixel', f'exact 1280 880,pid:{pid}']]
    assert len(monitor_rows) == 2 and len(client_rows) >= 3
    assert rows[0] == monitor_rows[0] and rows[-1] == monitor_rows[-1]
    assert client_rows[0]['owned_client'] == proof['owned_before']
    assert client_rows[-1]['owned_client'] == proof['owned_after']
    move_at, resize_at = [index for index, row in enumerate(rows) if row['argv'][1] == 'dispatch']
    assert move_at == 2 and rows[1] == client_rows[0]
    assert move_at + 1 < resize_at < len(rows) - 2
    assert all(row['argv'][1:] == ['-j', 'clients'] for row in rows[move_at + 1:resize_at])
    assert all(row['argv'][1:] == ['-j', 'clients'] for row in rows[resize_at + 1:-1])
    confirmed = rows[resize_at - 1]['owned_client']
    assert confirmed['monitor'] == selected and confirmed['workspace'] == workspace
    after = proof['owned_after']
    assert after['monitor'] == selected and after['workspace'] == workspace and after['size'] == [1280, 880]


def main():
    assert __debug__ and len(sys.argv) == 2, 'usage: python3 publish-evidence.py SELECTION.json; no -O'
    selected_path = local(sys.argv[1]); binding(selected_path)
    s = json.loads(selected_path.read_text())
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    source_path = checked(s['source']); source = read(s['source'])
    assert re.fullmatch(r'compiled-source-\d+\.json', source_path.name) and source['base'] == BASE
    inputs = source['source_sha256']; source_sha = digest(source_path)
    assert len(inputs) == s['source_count'] and len(inputs) > 0
    for name, sha in inputs.items():
        assert digest(local(name, W)) == sha, name
    rust_shas, exceptions = {source_sha}, []
    for spec in s.get('rust_sources', []):
        prior_path = checked(spec); prior = read(spec)
        assert prior['base'] == BASE and re.fullmatch(r'compiled-source-\d+\.json', prior_path.name)
        before = prior['source_sha256']; assert before.keys() == inputs.keys()
        changed = {name for name in inputs if inputs[name] != before[name]}
        assert changed == PYTHON_DELTA, changed
        prior_sha = digest(prior_path); assert prior_sha not in rust_shas
        rust_shas.add(prior_sha)
        exceptions.append({'source': binding(prior_path), 'allowed_roles': sorted(RUST_ROLES),
                           'changed_inputs': [{'path': n, 'before': before[n], 'after': inputs[n]} for n in sorted(changed)],
                           'scope': 'Only the two host Python inputs differ; all Rust and other source bytes are identical.'})

    attempts, window_directories = {}, set()
    for path in sorted((P / 'validation').glob('*.json')):
        record = json.loads(path.read_text())
        if not {'command', 'exit', 'log', 'sha256'} <= record.keys():
            continue
        log = local(record['log'], path.parent)
        assert digest(log) == record['sha256'], path
        text = log.read_text(errors='replace')
        attempts[path.name] = {'receipt': binding(path), 'log': binding(log), 'command': record['command'],
                               'exit': record['exit'], 'rust': totals(text)}
        # Keep every actual new-host output, including partial failed attempts.
        command = record['command']
        if 'tools/native_background_host.py' in command:
            directory = Path(argument(command, '--output'))
            if not directory.is_absolute():
                directory = W / directory
            assert directory == directory.resolve() and directory.parent == P
            assert directory.name not in TREES | {'worktree'} and not directory.name.startswith('target')
            if directory.exists():
                assert directory.is_dir() and not directory.is_symlink()
                window_directories.add(directory)

    roles = {}
    for item in s['checks']:
        path = checked(item['receipt']); assert path.parent == P / 'validation'
        actual = attempts[path.name]
        assert actual['command'] == item['command'] and actual['exit'] == item['exit']
        assert item['role'] not in roles
        if 'rust' in item:
            assert actual['rust'] == item['rust']
        if item.get('final', True):
            assert actual['exit'] == 0
            allowed = rust_shas if item['role'] in RUST_ROLES else {source_sha}
            assert item['source_sha256'] in allowed
        roles[item['role']] = {**actual, 'source_sha256': item.get('source_sha256'), 'final': item.get('final', True)}
    assert REQUIRED <= roles.keys() and all(roles[r]['final'] for r in REQUIRED)
    native = roles['full_native']
    assert native['command'] == ['cargo', '+1.88.0', 'test', '--locked', '--offline', '--manifest-path',
                                  'Cargo.toml', '--features', 'vulkan-raster', '--', '--include-ignored', '--test-threads=4']
    assert native['rust']['rows'] > 0 and native['rust']['passed'] > 0
    assert native['rust']['failed'] == native['rust']['ignored'] == 0
    for role, version in [('clippy_native_msrv', '1.88.0'), ('clippy_native_current', '1.98.0')]:
        assert roles[role]['command'] == ['cargo', '+' + version, 'clippy', '--locked', '--offline',
            '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--all-targets', '--', '-D', 'warnings']
    assert roles['format']['command'][-6:] == ['cargo', '+1.98.0', 'fmt', '--all', '--', '--check']
    for role, directory, pattern, count in [
        ('host_tests', 'tools', 'test_native_background_host.py', 19),
        ('helpers_native', 'tools', 'test_native_raster*.py', 91),
        ('helpers_supervisor', 'tools/vulkan-raster-probe', 'test_*supervisor.py', 19)]:
        role_data = roles[role]
        assert role_data['command'] == ['python3', '-m', 'unittest', 'discover', '-s', directory, '-p', pattern]
        text = Path(role_data['log']['path']).read_text()
        rows = re.findall(r'^Ran (\d+) tests? in [0-9.]+s$', text, re.M)
        assert len(rows) == 1 and int(rows[0]) == count
        assert re.findall(r'^(?:OK|FAILED.*)$', text, re.M) == ['OK']
        role_data['python_tests'] = int(rows[0])

    browser = read(s['browser']); binary = checked(browser)
    assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
    assert local(browser['build_receipt']) == Path(roles['browser_build']['receipt']['path'])
    assert local(browser['strip_receipt']) == Path(roles['browser_strip']['receipt']['path'])
    assert roles['browser_build']['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
    assert roles['browser_strip']['command'] in [['strip', str(binary)], ['strip', '--strip-debug', str(binary)]]
    assert re.fullmatch('[0-9a-f]{64}', browser['unstripped_sha256']) and browser['unstripped_bytes'] >= browser['bytes']

    result_path = checked(s['window']); result = read(s['window']); window = result_path.parent
    assert window in window_directories and result_path.name == 'background-host-results.json'
    assert result['success'] is True and result['binary'] == str(binary) and result['fixture_freeze'] == FREEZE
    assert result['bindings']['binary'] == browser['sha256']
    for name, sha in result['bindings']['source_files'].items():
        path = local(name, W); relative = str(path.relative_to(W))
        assert relative in inputs and inputs[relative] == sha and digest(path) == sha
    fixture_names = {'admitted.html', 'rounded.html', 'two-pixels.png', 'oracles.json', 'freeze.json'}
    assert set(result['bindings']['fixtures']) == fixture_names
    for name, sha in result['bindings']['fixtures'].items():
        assert digest(local('tools/native-background-fixtures/' + name, W)) == sha
        assert digest(local(window / 'fixtures' / name)) == sha
    assert result['bindings']['fixtures']['freeze.json'] == FREEZE
    invocation = roles['window_host']['command']
    backend_prefix = ['env', '-u', 'WAYLAND_DISPLAY', '-u', 'WAYLAND_SOCKET', 'WINIT_X11_SCALE_FACTOR=1']
    launch = invocation[len(backend_prefix):] if invocation[:len(backend_prefix)] == backend_prefix else invocation
    assert launch[:2] == ['python3', 'tools/native_background_host.py']
    controller_binding = external_file(result['controller'], result['bindings']['controller'])
    loader_binding = verify_loader(result['bindings']['loader'], argument(invocation, '--loader-directory'))
    physical = '--x11-physical-size' in invocation
    x11_binding = result['bindings'].get('x11_library')
    if physical:
        assert invocation[:len(backend_prefix)] == backend_prefix and invocation.count('--x11-physical-size') == 1
        display = result['display_environment']
        assert display['DISPLAY'] and not display['WAYLAND_DISPLAY'] and not display['WAYLAND_SOCKET']
        assert display['WINIT_X11_SCALE_FACTOR'] == '1'
        verify_x11(x11_binding, loader_binding['environment'])
    else:
        assert x11_binding is None
    monitor = result.get('unit_scale_monitor')
    assert ('--unit-scale-monitor' in invocation) == (monitor is not None)
    if monitor is not None:
        assert physical and type(monitor) is int and 0 <= monitor <= 255
        assert argument(invocation, '--unit-scale-monitor') == str(monitor)
    assert argument(invocation, '--binary') == str(binary) and argument(invocation, '--binary-sha256') == browser['sha256']
    assert Path(argument(invocation, '--output')) == window
    assert '--with-fallback' in invocation and '--allow-experimental-gpu' in invocation
    assert [r['case'] for r in result['runs']] == ['admitted', 'rounded']
    window_checks = []
    for run in result['runs']:
        case = run['case']; assert run['success'] is True
        supervisor_path = local(window / (case + '.json')); supervisor = json.loads(supervisor_path.read_text())
        assert run['supervision'] == {**supervisor, 'name': case}
        assert supervisor['command'] == run['command']
        owned = run['command']
        assert owned[1:3] == [str(W / 'tools/native_background_host.py'), '--owned-launch']
        assert argument(owned, '--binary') == str(binary) and argument(owned, '--binary-sha256') == browser['sha256']
        assert argument(owned, '--case') == case and argument(owned, '--fixtures') == str(window / 'fixtures')
        assert argument(owned, '--receipt') == str(window / (case + '.window-control.json'))
        assert argument(owned, '--controller') == result['controller']
        assert argument(owned, '--controller-sha256') == result['bindings']['controller']
        assert ('--x11-physical-size' in owned) == physical
        if physical:
            assert owned.count('--x11-physical-size') == 1
            assert argument(owned, '--x11-library') == x11_binding['path']
            assert argument(owned, '--x11-library-sha256') == x11_binding['sha256']
        assert ('--unit-scale-monitor' in owned) == (monitor is not None)
        if monitor is not None:
            assert argument(owned, '--unit-scale-monitor') == str(monitor)
        assert supervisor['status'] == 'exited' and supervisor['returncode'] == 0
        assert supervisor['cleanup']['complete'] is True and supervisor['cleanup']['descendants'] == 0
        assert not supervisor.get('capture_gate_required') and not supervisor.get('capture_gate_granted')
        assert local(window / (case + '.supervisor.stderr.log')).stat().st_size == 0
        stdout_path, stderr_path = local(window / (case + '.stdout.log')), local(window / (case + '.stderr.log'))
        assert digest(stdout_path) == supervisor['stdout_sha256'] and digest(stderr_path) == supervisor['stderr_sha256']
        assert stdout_path.stat().st_size + stderr_path.stat().st_size == supervisor['captured_bytes'] <= 2 * 1024 * 1024
        control_path = local(window / (case + '.window-control.json')); control = json.loads(control_path.read_text())
        assert digest(control_path) == run['control_sha256'] and control == run['control']
        assert control['success'] is control['control_complete'] is control['browser_reaped'] is True
        assert control['browser_returncode'] == 0 and control['controlled_size'] == [1280, 880]
        assert not {'error', 'cleanup_error', 'postcheck_error', 'stderr_drain_error'} & control.keys()
        assert control['binary_sha256'] == browser['sha256'] and control['controller_sha256'] == result['bindings']['controller']
        assert control['fixture_freeze'] == FREEZE and control['case'] == case
        verify_unit_monitor(control, monitor, result['controller'])
        assert control.get('x11_library') == x11_binding
        helpers = [row for row in control['commands'] if '--x11-resize-child' in row['argv']]
        assert len(control['commands']) <= 48
        if physical:
            assert len(helpers) == 1 and helpers[0] == control['commands'][-1]
            helper = helpers[0]
            assert helper['argv'] == [owned[0], str(W / 'tools/native_background_host.py'), '--x11-resize-child',
                '--owned-pid', str(control['identity']['pid']), '--x11-library', x11_binding['path'],
                '--x11-library-sha256', x11_binding['sha256'], '--allow-experimental-gpu']
            assert helper['status'] == 'exited' and helper['returncode'] == 0
            raw_stdout = helper['stdout'].encode('utf-8')
            assert len(raw_stdout) == helper['stdout_bytes'] <= 4096
            assert hashlib.sha256(raw_stdout).hexdigest() == helper['stdout_sha256']
            assert helper['stderr'] == '' and helper['stderr_bytes'] == 0
            assert helper['stderr_sha256'] == hashlib.sha256(b'').hexdigest()
            proof = json.loads(raw_stdout)
            assert proof == control['x11_physical_control'] and proof['library'] == x11_binding
            assert set(proof) == {'library', 'pid', 'window', 'pid_before', 'pid_after', 'client_count',
                'property_reads', 'geometry_reads', 'initial_size', 'requested_size', 'observed_size', 'scope'}
            assert proof['pid'] == proof['pid_before'] == proof['pid_after'] == control['identity']['pid']
            assert all(type(proof[name]) is int and 0 < proof[name] < 2**31 for name in ('pid', 'pid_before', 'pid_after'))
            assert type(proof['window']) is int and 0 < proof['window'] <= 0xffffffff
            assert type(proof['client_count']) is int and 1 <= proof['client_count'] <= 256
            assert type(proof['property_reads']) is int and proof['property_reads'] == proof['client_count'] + 3
            assert type(proof['geometry_reads']) is int and 2 <= proof['geometry_reads'] <= 33
            assert proof['requested_size'] == proof['observed_size'] == [1280, 880]
            assert len(proof['initial_size']) == 2 and all(type(v) is int and 0 < v <= 16384 for v in proof['initial_size'])
            assert control['control_size_space'] == 'x11-physical'
            assert control['logical_controlled_size_before_physical'] == [1280, 880]
            assert proof['scope'] == 'unique X11 PID-property match; parent retains unreaped browser identity'
        else:
            assert not helpers and not {'x11_physical_control', 'control_size_space', 'logical_controlled_size_before_physical'} & control.keys()
        port = control['port']; assert type(port) is int and 1 <= port <= 65535
        assert argument(owned, '--port') == str(port)
        url = f'http://127.0.0.1:{port}/admitted.html'
        command = control['browser_command']
        assert command[:5] == [str(binary), url, '--presenter=vulkan', '--raster=gpu', '--no-scripts']
        assert command[5] == '--exit-after' and 2 <= float(command[6]) <= 20
        assert command[7:] == (['--benchmark-native-check'] if case == 'admitted' else [])
        assert [r['path'] for r in control['requests']] == ['/admitted.html', '/two-pixels.png']
        for row in control['requests']:
            name = ('admitted.html' if case == 'admitted' else 'rounded.html') if row['path'] == '/admitted.html' else 'two-pixels.png'
            body = local(window / 'fixtures' / name).read_bytes()
            mime = 'text/html; charset=utf-8' if row['path'] == '/admitted.html' else 'image/png'
            response = f'HTTP/1.1 200 OK\r\nContent-Type: {mime}\r\nContent-Length: {len(body)}\r\nConnection: close\r\n\r\n'.encode() + body
            assert row['method'] == 'GET' and row['response_complete'] is True
            assert row['body_bytes'] == len(body) and row['body_sha256'] == hashlib.sha256(body).hexdigest()
            assert row['response_bytes'] == len(response) and row['response_sha256'] == hashlib.sha256(response).hexdigest()
        checked_result = run['validation']; assert checked_result['positive_release'] is True
        assert checked_result['page_pid'] != checked_result['broker_pid'] and min(checked_result['page_pid'], checked_result['broker_pid']) > 0
        assert control['identity']['pid'] not in (checked_result['page_pid'], checked_result['broker_pid'])
        stderr = stderr_path.read_text(); stdout = stdout_path.read_bytes()
        assert re.findall(r'^presenter: Vulkan adapter=.*$', stderr, re.M) == [checked_result['adapter']]
        assert checked_result['adapter'].endswith('; raster=native-shaders with complete CPU admission fallback')
        marker = re.findall(r'^native background gate: document released for owned pid=(\d+) size=1280x880 prefix_bytes=(\d+) prefix_sha256=([0-9a-f]{64}) html_sha256=([0-9a-f]{64})$', stderr, re.M)
        assert len(marker) == 1 and int(marker[0][0]) == control['identity']['pid']
        prefix = stderr_path.read_bytes().split(b'native background gate:', 1)[0]
        assert int(marker[0][1]) == len(prefix) and marker[0][2] == hashlib.sha256(prefix).hexdigest()
        assert control['release'] == {'prefix_bytes': len(prefix), 'prefix_sha256': marker[0][2], 'html_sha256': marker[0][3], 'physical_size': [1280, 880]}
        assert marker[0][3] == control['requests'][0]['body_sha256']
        assert re.findall(r'^\[page\] Page process (\d+): Landlock ABI [1-9][0-9]* and seccomp: no direct resource or socket access$', stderr, re.M) == [str(checked_result['page_pid'])]
        assert re.findall(r'^\[page\] Resource broker (\d+): committed URL and fetch policy enforced outside renderer$', stderr, re.M) == [str(checked_result['broker_pid'])]
        released_at = stderr.index('native background gate:')
        snapshot_at = [stderr.index('[page] Page process '), stderr.index('[page] Resource broker ')]
        assert all(position > released_at for position in snapshot_at)
        if case == 'admitted':
            report = json.loads(stdout); assert report == checked_result['report']
            assert report['checked'] is True and report['route'] == 'native-raster' and report['mode'] == 'check'
            assert report['completed_frames'] == report['requested_frames'] == 1
            assert report['failure'] is report['owner_failure'] is report['owner_init_ns'] is None and report['samples'] == []
            assert report['diagnostics'] == 2 and report['edit_sequence'] == 0 and report['scale_factor'] == 1
            scene = local(window / 'scene.ebni'); scene_bytes = bytes.fromhex(report['scene_hex'])
            assert scene.read_bytes() == scene_bytes and digest(scene) == checked_result['identity']['sha256']
            assert checked_result['identity']['url'] == url and checked_result['identity']['commands'] == 4 and checked_result['identity']['images'] == 1
            stats = checked_result['box_stats']; assert len(stats) == 10 and stats[3:] == [1, 0, 1, 1, 159, 1, 12]
            serial, generation, revision = stats[:3]
            assert generation == report['generation'] == 1 and revision == report['viewport_revision'] and min(serial, revision) > 0
            expected = f'native boxes prepared: serial={serial} generation={generation} viewport_revision={revision} box_rectangles=1 box_masks=0 box_background_images=1 box_gradients=1 box_loop_work=159 generated_gradient_sources=1 generated_gradient_bytes=12'
            assert re.findall(r'^native boxes prepared:.*$', stderr, re.M) == [expected]
            assert max(snapshot_at) < stderr.index(expected)
            expected = f'presenter: native shader acquired-texture verified; serial={serial} generation={generation} viewport_revision={revision} size=1280x880 compared_bytes=4505600 exact=true (before compositor)'
            assert re.findall(r'^presenter: native shader acquired-texture verified;.*$', stderr, re.M) == [expected]
            presented = f'presenter: native shader frame presented; size=1280x880 serial={serial} CPU_upload=false reference=true'
            assert re.findall(r'^presenter: native shader frame presented;.*$', stderr, re.M) == [presented]
            expected = f'presenter: Vulkan acquired-texture verification passed; route=native-raster frames=1 compared_bytes=4505600 last_serial={serial} (before compositor)'
            assert re.findall(r'^presenter: Vulkan acquired-texture verification passed;.*$', stderr, re.M) == [expected]
            assert checked_result['verified_frames'] == 1 and checked_result['compared_bytes'] == 4505600 and checked_result['box_loop_work'] == 159
        else:
            reason = 'unsupported-box-decoration at phase 0 original command 2; size=1280x880'
            assert not stdout and checked_result['report'] is None and checked_result['identity'] is None
            assert checked_result['fallbacks'] == [reason] and checked_result['box_stats'] is None
            assert checked_result['verified_frames'] == checked_result['compared_bytes'] == 0
            assert stderr.count('reason=' + reason + '\n') == 1
            assert max(snapshot_at) < stderr.index('reason=' + reason + '\n')
            assert not re.search(r'^(native boxes prepared:|native scene prepared:|presenter: native shader|presenter: Vulkan acquired-texture verification)', stderr, re.M)
        window_checks.append({'case': case, 'supervisor': binding(supervisor_path), 'control': binding(control_path),
                              'stdout': binding(stdout_path), 'stderr': binding(stderr_path), 'validation': checked_result})

    docs = read(s['docs'])['published_files']; review = read(s['documentation_review'])
    assert review['status'] == 'clear' and docs
    coverage = {row['relative']: row['sha256'] for row in review['published_files']}
    assert len(coverage) == len(docs) == len({row['path'] for row in docs})
    for row in docs:
        assert digest(checked(row['draft'])) == digest(local(row['path'], W)) == coverage[row['path']]
    assert s['reviews'] and all(read(spec)['status'] == 'clear' for spec in s['reviews'])
    published = s['published_files']; names = {row['path'] for row in published}
    assert len(names) == len(published)
    for row in published:
        checked(row, W)
    changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    changed.discard(''); assert changed == names, sorted(changed ^ names)
    assert {row['path'] for row in docs} == {name for name in changed if name.endswith('.md')}
    staged = set(git('diff', '--cached', '--name-only', '-z').decode().split('\0')); staged.discard('')
    assert staged <= names
    for name in staged:
        assert git('show', ':' + name) == local(name, W).read_bytes()

    files = {selected_path, source_path, checked(s['browser']), result_path, checked(s['docs']), checked(s['documentation_review']),
             Path(__file__).resolve(), P / 'root/publication-design.json'}
    files.update(checked(spec) for spec in s['reviews'])
    files.update(local(name, W) for name in inputs)
    files.update(checked(row, W) for row in published)
    for root in {P / name for name in TREES} | window_directories:
        assert root.is_dir() and root == root.resolve() and root.parent == P
        for path in root.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_file():
                files.add(path)
    files.update(P.glob('compiled-source-*.json'))
    files.update(checked(spec) for spec in s.get('archive_files', []))
    assert sum(path.stat().st_size for path in files) < CAP
    contents = {}
    for path in sorted(files):
        path = local(path); name = str(path.relative_to(P))
        assert not any(part in {'target', '.git', 'archive', 'archives', '__pycache__'} or part.startswith('target-') for part in Path(name).parts), name
        assert path.suffix not in {'.gz', '.zip', '.tar', '.xz', '.bz2', '.7z', '.zst', '.rlib', '.a', '.so', '.dll', '.dylib', '.pyc'}, name
        with path.open('rb') as stream:
            magic = stream.read(4)
        assert magic != b'\x7fELF' and not magic.startswith(b'MZ') and magic not in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf'), name
        contents[name] = path.read_bytes()
    assert sum(map(len, contents.values())) < CAP
    for path, expected in VERIFIED.items():
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], path
        captured = contents.get(str(path.relative_to(P)))
        if captured is not None:
            assert len(captured) == expected['bytes'] and hashlib.sha256(captured).hexdigest() == expected['sha256']
    for name, sha in inputs.items():
        assert hashlib.sha256(contents['worktree/' + name]).hexdigest() == sha
    for row in published:
        assert hashlib.sha256(contents['worktree/' + row['path']]).hexdigest() == row['sha256']
    for path, expected in EXTERNAL.items():
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256']
    assert verify_loader(loader_binding, argument(invocation, '--loader-directory')) == loader_binding
    if physical:
        assert verify_x11(x11_binding, loader_binding['environment']) == x11_binding
    index = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(contents.items())]
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name, data in sorted(contents.items()):
            info = tarfile.TarInfo(name); info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    assert raw.tell() < CAP
    compressed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0); assert len(compressed) < CAP and D == D.resolve()
    archive_path, summary_path = D / 'validation.tar.gz', D / 'summary.json'
    assert not archive_path.exists() and not summary_path.exists(); D.mkdir(parents=True, exist_ok=True)
    with archive_path.open('xb') as stream:
        stream.write(compressed)
    assert archive_path.read_bytes() == compressed
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert [member.name for member in archive.getmembers()] == sorted(contents)
        for member in archive.getmembers():
            assert member.isfile() and archive.extractfile(member).read() == contents[member.name]
    summary = {'base': BASE, 'scope': 'One actual acquired native background scene before compositor and one ordinary rounded Image fallback; unchanged renderer; no timing claim.',
               'source': binding(source_path), 'source_count': len(inputs), 'rust_source_exceptions': exceptions,
               'checks': attempts, 'selected_roles': roles, 'browser': browser, 'window_result': s['window'],
               'external_dependencies': {'controller': controller_binding, 'loader': loader_binding, 'x11_library': x11_binding,
                   'scope': 'Explicit loader files and selected environment; not a transitive library inventory. Executables excluded from archive.'},
               'window_checks': window_checks, 'reviews': s['reviews'], 'documentation_review': s['documentation_review'],
               'published_bindings': published, 'staged_paths': sorted(staged), 'selection': binding(selected_path),
               'archive': {'path': 'validation.tar.gz', 'bytes': len(compressed), 'sha256': digest(archive_path), 'members': len(index)},
               'archive_inputs': index, 'limits': ['Acquired comparison precedes compositor; not display-output or performance evidence.',
                   'Rounded control has exact fallback diagnostics but no acquired-pixel comparison.',
                   'All attempted runs, failures and source-only corrections are retained.']}
    with summary_path.open('x') as stream:
        json.dump(summary, stream, indent=2); stream.write('\n')
    assert json.loads(summary_path.read_text()) == summary
    print(json.dumps({'summary_sha256': digest(summary_path), 'archive': summary['archive']}, indent=2))


if __name__ == '__main__':
    main()
