
class UnitMonitorTranscriptOrderTests(unittest.TestCase):
    def test_stage_order_and_dispatch_raw_hashes_are_required(self):
        original, _ = UnitMonitorControlTests().run_control()
        for order in ([0, 2, 4, 1, 3, 5, 6], [0, 1, 2, 4, 3, 5, 6], [0, 1, 2, 3, 4, 6, 5]):
            changed = copy.deepcopy(original)
            changed['commands'] = [changed['commands'][index] for index in order]
            with self.assertRaises(ValueError): host.validate_unit_monitor_control(changed, 1)
        for key, value in [('stdout', 'different\n'), ('stdout_bytes', 99), ('stdout_sha256', 'b' * 64)]:
            changed = copy.deepcopy(original); changed['commands'][2][key] = value
            with self.assertRaises(ValueError): host.validate_unit_monitor_control(changed, 1)
        changed = copy.deepcopy(original)
        changed['commands'][3]['owned_client']['monitor'] = 0
        with self.assertRaises(ValueError): host.validate_unit_monitor_control(changed, 1)
