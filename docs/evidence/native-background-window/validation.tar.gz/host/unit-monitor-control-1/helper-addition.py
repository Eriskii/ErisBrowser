

def select_unit_monitor(monitors, requested):
    timing.integer(requested, 0, 255)
    if not isinstance(monitors, list) or len(monitors) > 16 or any(not isinstance(row, dict) for row in monitors):
        raise ValueError('bounded monitor inventory required')
    matches = [row for row in monitors if type(row.get('id')) is int and row['id'] == requested]
    if len(matches) != 1:
        raise ValueError('explicit monitor must exist exactly once')
    row = matches[0]
    try:
        width, height = timing.integer(row['width'], 1280, 16384), timing.integer(row['height'], 880, 16384)
        workspace = timing.integer(row['activeWorkspace']['id'], 1, 2**31 - 1)
        if (row['disabled'] is not False or type(row['transform']) is not int or row['transform'] != 0
                or type(row['scale']) not in (int, float) or row['scale'] != 1
                or type(row['name']) is not str or not 1 <= len(row['name']) <= 256):
            raise ValueError('selected monitor must be enabled, untransformed and unit scale')
        return {'id': requested, 'name': row['name'], 'width': width, 'height': height,
                'scale': row['scale'], 'transform': 0, 'disabled': False, 'active_workspace': workspace}
    except (KeyError, TypeError) as error:
        raise ValueError('selected monitor metadata is incomplete') from error


def unit_owned_client(clients, pid):
    if not isinstance(clients, list) or len(clients) > 256 or any(not isinstance(row, dict) for row in clients):
        raise ValueError('bounded client inventory required')
    matches = [row for row in clients if type(row.get('pid')) is int and row['pid'] == pid]
    if len(matches) != 1:
        raise ValueError('unit-monitor control requires one owned client')
    row = matches[0]
    try:
        monitor = timing.integer(row['monitor'], 0, 255)
        workspace = timing.integer(row['workspace']['id'], 1, 2**31 - 1)
        size = row['size']
        if (not isinstance(size, list) or len(size) != 2 or row['floating'] is not True
                or row['mapped'] is not True or row.get('grouped', []) != []):
            raise ValueError('owned floating ungrouped client required')
        for axis in size:
            timing.integer(axis, 1, 16384)
        return {'pid': pid, 'monitor': monitor, 'workspace': workspace, 'size': size, 'floating': True, 'mapped': True}
    except (KeyError, TypeError) as error:
        raise ValueError('owned client metadata is incomplete') from error


def configure_unit_monitor(identity, controller, env, record, persist, deadline, requested):
    record['control_complete'] = False
    persist()
    timing.integer(requested, 0, 255)
    pid = identity['pid']
    def invoke(arguments):
        base.ensure_live_child(identity)
        remaining = deadline - time.monotonic()
        if remaining < 0.05 or len(record['commands']) >= base.CONTROL_COMMANDS:
            raise ValueError('unit-monitor control deadline/command bound')
        result = base.controller_call(controller, arguments, env, min(0.5, remaining))
        row = {'control_stage': 'unit-monitor', 'argv': [str(controller), *arguments],
               'status': result.record['status'], 'returncode': result.record['returncode'],
               'stdout_bytes': len(result.stdout), 'stdout_sha256': wide.sha(result.stdout),
               'stderr_bytes': len(result.stderr), 'stderr_sha256': wide.sha(result.stderr)}
        query = arguments in (['-j', 'monitors'], ['-j', 'clients'])
        if not query and len(result.stdout) <= 4096:
            row['stdout'] = result.stdout.decode('utf-8', errors='strict')
        if len(result.stderr) <= 4096:
            row['stderr'] = result.stderr.decode('utf-8', errors='strict')
        record['commands'].append(row); persist()
        base.ensure_live_child(identity)
        if (row['status'] != 'exited' or row['returncode'] != 0 or result.stderr
                or len(result.stdout) > (base.CONTROL_BYTES if query else 4096)):
            raise ValueError('unit-monitor controller failed')
        return result.stdout, row
    def monitor_query():
        stdout, row = invoke(['-j', 'monitors'])
        selected = select_unit_monitor(timing.strict_json(stdout, base.CONTROL_BYTES), requested)
        row['selected_monitor'] = selected; persist()
        return selected
    def owned_query():
        stdout, row = invoke(['-j', 'clients'])
        owned = unit_owned_client(timing.strict_json(stdout, base.CONTROL_BYTES), pid)
        row['owned_client'] = owned; persist()
        return owned
    monitor = monitor_query()
    before = owned_query()
    invoke(['dispatch', 'movetoworkspacesilent', f'{monitor["active_workspace"]},pid:{pid}'])
    while True:
        moved = owned_query()
        if moved['monitor'] == requested and moved['workspace'] == monitor['active_workspace']:
            break
        time.sleep(0.01)
    invoke(['dispatch', 'resizewindowpixel', f'exact 1280 880,pid:{pid}'])
    while True:
        after = owned_query()
        if (after['monitor'] == requested and after['workspace'] == monitor['active_workspace']
                and after['size'] == [1280, 880]):
            break
        time.sleep(0.01)
    if monitor_query() != monitor or time.monotonic() >= deadline:
        raise ValueError('selected unit monitor changed or control deadline exhausted')
    record['unit_monitor_control'] = {'requested_id': requested, 'monitor': monitor, 'owned_before': before, 'owned_after': after}
    record['controlled_size'] = [1280, 880]
    persist()


def validate_unit_monitor_control(control, requested, controller=None):
    try:
        rows = [row for row in control['commands'] if row.get('control_stage') == 'unit-monitor']
        if requested is None:
            if rows or 'unit_monitor_control' in control:
                raise ValueError('unit-monitor control reported without opt-in')
            return
        timing.integer(requested, 0, 255)
        proof = control['unit_monitor_control']
        if set(proof) != {'requested_id', 'monitor', 'owned_before', 'owned_after'} or proof['requested_id'] != requested:
            raise ValueError('unit-monitor reply does not match explicit selection')
        selected = proof['monitor']
        if select_unit_monitor([{**selected, 'activeWorkspace': {'id': selected['active_workspace']}}], requested) != selected:
            raise ValueError('unit monitor metadata is invalid')
        pid = timing.integer(control['identity']['pid'], 1, 2**31 - 1)
        for key in ('owned_before', 'owned_after'):
            value = proof[key]
            if unit_owned_client([{**value, 'workspace': {'id': value['workspace']}}], pid) != value:
                raise ValueError('owned unit-monitor metadata differs')
        after = proof['owned_after']
        if after['monitor'] != requested or after['workspace'] != selected['active_workspace'] or after['size'] != [1280, 880]:
            raise ValueError('unit-monitor destination or size differs')
        if not 7 <= len(rows) <= base.CONTROL_COMMANDS or len(control['commands']) > base.CONTROL_COMMANDS:
            raise ValueError('bounded unit-monitor command transcript required')
        if controller is None:
            controller = Path(rows[0]['argv'][0])
        operations = []
        monitor_rows, client_rows = [], []
        for row in rows:
            if (row['argv'][0] != str(controller) or row['status'] != 'exited' or row['returncode'] != 0
                    or row['stderr_bytes'] != 0 or row['stderr_sha256'] != wide.sha(b'') or row.get('stderr') != ''):
                raise ValueError('unit-monitor command binding differs')
            arguments = row['argv'][1:]
            if arguments == ['-j', 'monitors']:
                if row['selected_monitor'] != selected:
                    raise ValueError('monitor changed between queries')
                monitor_rows.append(row)
            elif arguments == ['-j', 'clients']:
                value = row['owned_client']
                if unit_owned_client([{**value, 'workspace': {'id': value['workspace']}}], pid) != value:
                    raise ValueError('intermediate client identity differs')
                client_rows.append(row)
            else:
                operations.append(arguments)
        if (operations != [['dispatch', 'movetoworkspacesilent', f'{selected["active_workspace"]},pid:{pid}'],
                           ['dispatch', 'resizewindowpixel', f'exact 1280 880,pid:{pid}']]
                or len(monitor_rows) != 2 or len(client_rows) < 3
                or rows[0] != monitor_rows[0] or rows[-1] != monitor_rows[-1]
                or client_rows[0]['owned_client'] != proof['owned_before'] or client_rows[-1]['owned_client'] != after):
            raise ValueError('owned unit-monitor query/move/resize sequence differs')
    except (KeyError, TypeError, AttributeError) as error:
        raise ValueError('malformed unit-monitor control receipt') from error
