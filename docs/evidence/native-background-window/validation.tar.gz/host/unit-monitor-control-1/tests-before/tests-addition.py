
class UnitMonitorControlTests(unittest.TestCase):
    def monitor(self, **updates):
        result = dict(id=1, name='unit', width=2560, height=1440, scale=1.0, transform=0,
                      disabled=False, activeWorkspace=dict(id=1, name='1'))
        result.update(updates)
        return result

    def test_explicit_enabled_unit_monitor_selection_is_bounded(self):
        expected = dict(id=1, name='unit', width=2560, height=1440, scale=1.0, transform=0,
                        disabled=False, active_workspace=1)
        self.assertEqual(host.select_unit_monitor([self.monitor(id=0, scale=1.5), self.monitor()], 1), expected)
        for rows in [[], [self.monitor(), self.monitor()], [self.monitor(id=0)], [self.monitor()] * 17,
                     [self.monitor(disabled=True)], [self.monitor(transform=1)], [self.monitor(scale=1.5)],
                     [self.monitor(width=1279)], [self.monitor(height=879)], [self.monitor(activeWorkspace=dict(id=0))]]:
            with self.assertRaises(ValueError): host.select_unit_monitor(rows, 1)
        for selected in (-1, 256, True):
            with self.assertRaises(ValueError): host.select_unit_monitor([self.monitor()], selected)

    def run_control(self, client_pid=100, final_monitor=1):
        from types import SimpleNamespace
        identity = dict(pid=100, parent_pid=99, process_group=99, start_ticks=1000)
        before = dict(pid=client_pid, monitor=0, workspace=dict(id=2), size=[1280, 880], floating=True, mapped=True)
        after = dict(before, monitor=final_monitor, workspace=dict(id=1))
        clients = iter([[before], [after], [after]])
        calls = []
        def call(controller, args, env, timeout):
            calls.append(args)
            self.assertLessEqual(timeout, 0.5)
            if args == ['-j', 'monitors']:
                data = json.dumps([self.monitor()]).encode()
            elif args == ['-j', 'clients']:
                data = json.dumps(next(clients, [after])).encode()
            else:
                self.assertIn(args, [['dispatch', 'movetoworkspacesilent', '1,pid:100'],
                                     ['dispatch', 'resizewindowpixel', 'exact 1280 880,pid:100']])
                data = b'ok\n'
            return SimpleNamespace(record=dict(status='exited', returncode=0), stdout=data, stderr=b'')
        record = dict(identity=identity, commands=[], control_complete=True, controlled_size=[1280, 880])
        with mock.patch.object(host.time, 'monotonic', return_value=1), mock.patch.object(host.time, 'sleep'), mock.patch.object(host.base, 'ensure_live_child'), mock.patch.object(host.base, 'controller_call', side_effect=call):
            host.configure_unit_monitor(identity, Path('/fixed/hyprctl'), {}, record, lambda: None, 4, 1)
        return record, calls

    def test_owned_pid_only_move_and_exact_fixed_resize_receipt(self):
        record, calls = self.run_control()
        self.assertEqual(len(calls), 7)
        self.assertEqual(calls[2], ['dispatch', 'movetoworkspacesilent', '1,pid:100'])
        self.assertEqual(calls[4], ['dispatch', 'resizewindowpixel', 'exact 1280 880,pid:100'])
        proof = record['unit_monitor_control']
        self.assertEqual(proof['requested_id'], 1)
        self.assertEqual(proof['owned_before']['pid'], 100)
        self.assertEqual(proof['owned_after'], dict(pid=100, monitor=1, workspace=1, size=[1280, 880], floating=True, mapped=True))
        self.assertEqual(len([r for r in record['commands'] if 'selected_monitor' in r]), 2)
        self.assertEqual(len([r for r in record['commands'] if 'owned_client' in r]), 3)
        host.validate_unit_monitor_control(record, 1)
        for key, value in [('requested_id', 0), ('owned_after', {**proof['owned_after'], 'pid': 101})]:
            changed = copy.deepcopy(record); changed['unit_monitor_control'][key] = value
            with self.assertRaises(ValueError): host.validate_unit_monitor_control(changed, 1)
        with self.assertRaises(ValueError): host.validate_unit_monitor_control(record, None)
        host.validate_unit_monitor_control(dict(commands=[]), None)

    def test_wrong_pid_wrong_monitor_and_expired_budget_refuse(self):
        with self.assertRaises(ValueError): self.run_control(client_pid=101)
        with self.assertRaises(ValueError): self.run_control(final_monitor=0)
        for commands, deadline in [([], 0), ([{}] * host.base.CONTROL_COMMANDS, 4)]:
            record = dict(commands=commands, control_complete=True)
            with mock.patch.object(host.time, 'monotonic', return_value=1), mock.patch.object(host.base, 'ensure_live_child'), mock.patch.object(host.base, 'controller_call') as call:
                with self.assertRaises(ValueError):
                    host.configure_unit_monitor(dict(pid=100), Path('/fixed/hyprctl'), {}, record, lambda: None, deadline, 1)
                call.assert_not_called()
                self.assertFalse(record['control_complete'])
