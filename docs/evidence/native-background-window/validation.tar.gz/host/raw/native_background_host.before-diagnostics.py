#!/usr/bin/env python3
"""One bounded broker-backed acquired-window background check, plus optional fallback.

This reuses the unchanged owned-window controller, fixed two-route server and
isolated subreaper. The new reader accepts only the independently frozen scene.
"""
from __future__ import annotations

import argparse
import json
import math
import os
from pathlib import Path
import re
import shutil
import signal
import socket
import struct
import subprocess
import sys
import time

import native_raster_host as base
import native_raster_wide_host as wide
import native_raster_timing_host as timing
from native_raster_followup import BROKER, PAGE, drain_stderr
from bridge_supervisor import validate_listener_fds

ROOT = Path(__file__).resolve().parents[1]
FIXTURES = ROOT / 'tools/native-background-fixtures'
FREEZE_SHA = '422b8d83a9481834aab6d70695478034ddc9725705482b0ea7bc8aecc413a4c5'
FILES = ('admitted.html', 'rounded.html', 'two-pixels.png', 'oracles.json', 'freeze.json')
CASES = ('admitted', 'rounded')
STATS = re.compile(r'native boxes prepared: serial=([1-9][0-9]*) generation=([1-9][0-9]*) viewport_revision=([1-9][0-9]*) box_rectangles=([0-9]+) box_masks=([0-9]+) box_background_images=([0-9]+) box_gradients=([0-9]+) box_loop_work=([0-9]+) generated_gradient_sources=([0-9]+) generated_gradient_bytes=([0-9]+)')
RELEASE = re.compile(r'native background gate: document released for owned pid=([1-9][0-9]*) size=1280x880 prefix_bytes=([0-9]+) prefix_sha256=([0-9a-f]{64}) html_sha256=([0-9a-f]{64})')
EXPECTED_STATS = (1, 0, 1, 1, 159, 1, 12)
RGBA = bytes.fromhex('ff0000ff00ff00ff0000ffff00ffffffff00ffffffff00ff000000ffff8000ff')
KEY = 'eris-css-background:0'
FALLBACK = 'unsupported-box-decoration at phase 0 original command 2; size=1280x880'


class FixtureReader(timing.IdentityReader):
    def exact(self, expected):
        if self.take(len(expected)) != expected:
            raise ValueError('scene field differs from frozen literal')

    def values(self, kind, *values):
        # Comparing the finite literal encoding also preserves signed-zero bits.
        self.exact(struct.pack('<' + kind * len(values), *values))

    def string(self, expected):
        if self.text() != expected:
            raise ValueError('scene string differs from frozen literal')

    def shape(self, x):
        self.values('f', x, 10, 4, 2)
        self.values('f', *([0] * 8))
        self.exact(b'\0')  # No cutout, including zero-area cutouts.


def parse_identity(scene_hex, url):
    if (type(scene_hex) is not str or not 2 <= len(scene_hex) <= timing.MAX_SCENE * 2
            or len(scene_hex) % 2 or re.fullmatch('[0-9a-f]+', scene_hex) is None):
        raise ValueError('bounded complete lowercase EBNI hex required')
    data = bytes.fromhex(scene_hex)
    r = FixtureReader(data)
    r.exact(b'EBNI\x01'); r.values('I', 1280, 880); r.values('f', 0, 1)
    r.string('Native background window'); r.string(url)
    r.exact(b'\0'); r.string(''); r.values('I', 0, 0); r.exact(b'\0')
    r.values('f', 779); r.string('Native timing scene'); r.values('I', 4)
    r.exact(b'\x06'); r.values('f', 0, 0, 1280, 779); r.exact(b'\xff' * 4); r.values('f', 0)
    r.exact(b'\x0d'); r.shape(10); r.exact(b'\0\0\xff\0\xff')
    r.exact(b'\x0d'); r.shape(26); r.exact(b'\x01\0')
    r.values('f', 27, 11, 4, 2); r.string(KEY)
    r.exact(b'\x0d'); r.shape(42); r.exact(b'\x02\0')
    r.values('f', 43, 11, 4, 2); r.exact(bytes.fromhex('ff0000ff')); r.values('f', 1)
    r.exact(b'\0'); r.values('d', 90); r.values('I', 2)
    r.exact(b'\x01\x01'); r.values('d', 0, 50)
    r.exact(b'\0\0\0\xff\xff\x01'); r.values('d', 0, 50)
    r.values('I', 1); r.string(KEY); r.values('I', 0, 4, 2)
    r.values('I', 32); r.exact(RGBA)
    if r.at != len(data):
        raise ValueError('trailing scene bytes')
    return {'bytes': len(data), 'sha256': wide.sha(data), 'commands': 4, 'images': 1,
            'rgba_bytes': 32, 'url': url, 'title': 'Native background window'}


def validate_report(data, url):
    if not data.endswith(b'\n'):
        raise ValueError('report framing')
    report = timing.strict_json(data)
    if type(report) is not dict or set(report) != timing.REPORT_KEYS:
        raise ValueError('report schema keys')
    fixed = {'schema': 1, 'requested_frames': 1, 'completed_frames': 1, 'accepted_frames': 0,
             'width': 1280, 'height': 880, 'generation': 1, 'edit_sequence': 0, 'diagnostics': 0}
    for key, value in fixed.items():
        if timing.integer(report[key]) != value:
            raise ValueError('report is not the current complete fixed check')
    timing.integer(report['viewport_revision'], 1)
    if (report['kind'] != 'native-benchmark' or report['mode'] != 'check'
            or report['route'] != 'native-raster' or report['checked'] is not True
            or report['failure'] is not None or report['owner_failure'] is not None
            or report['owner_init_ns'] is not None or report['samples'] != []
            or type(report['scale_factor']) not in (int, float) or report['scale_factor'] != 1):
        raise ValueError('check route, scope, scale or completion mismatch')
    load = report['source_load_ms']
    if load is not None and (type(load) not in (int, float) or not math.isfinite(load) or load < 0):
        raise ValueError('invalid source load metadata')
    return report, parse_identity(report['scene_hex'], url)


def validate_run(stdout, stderr, control, port, bodies, case):
    if case not in CASES:
        raise ValueError('unknown fixed case')
    timing.integer(port, 1, 65535)
    if set(bodies) != set(wide.ROUTES):
        raise ValueError('exact two-route bodies required')
    timing.validate_control(control, port, bodies)
    for name in ('pid', 'parent_pid', 'process_group', 'start_ticks'):
        timing.integer(control['identity'][name], 1)
    if (len(stderr) > base.MAX_OUTPUT or not stderr.endswith(b'\n')):
        raise ValueError('diagnostic byte bound/framing')
    try:
        lines = stderr.decode('utf-8', errors='strict').splitlines(keepends=True)
    except UnicodeError as error:
        raise ValueError('diagnostic UTF-8') from error
    if len(lines) > 4096 or any(len(line.encode()) > 16384 for line in lines):
        raise ValueError('diagnostic line/count bound')
    url = f'http://127.0.0.1:{port}/admitted.html'
    if case == 'admitted':
        report, identity = validate_report(stdout, url)
    elif stdout:
        raise ValueError('ordinary fallback has no stdout report')
    else:
        report, identity = None, None
    prefix = bytearray()
    released, physical = False, False
    adapters, pages, brokers, stats, presentations, verified, summaries, fallbacks, other = [], [], [], [], [], [], [], [], []
    for raw in lines:
        line = raw.rstrip('\n')
        if match := timing.WAITING.fullmatch(line):
            if case != 'admitted' or released:
                raise ValueError('unexpected loaded check restart')
            physical = tuple(map(int, match.groups())) == wide.SIZE
        elif match := RELEASE.fullmatch(line):
            event = dict(prefix_bytes=len(prefix), prefix_sha256=wide.sha(prefix),
                         html_sha256=wide.sha(bodies['/admitted.html']), physical_size=list(wide.SIZE))
            if (released or not physical or int(match[1]) != control['identity']['pid']
                    or int(match[2]) != len(prefix) or match[3] != event['prefix_sha256']
                    or match[4] != event['html_sha256'] or control.get('release') != event):
                raise ValueError('positive document release identity mismatch')
            released = True
        elif match := timing.ADAPTER.fullmatch(line):
            if adapters or summaries or match[2] != 'native-shaders with complete CPU admission fallback':
                raise ValueError('surface adapter/route mismatch')
            adapters.append(line)
        elif match := PAGE.fullmatch(line):
            if pages or summaries:
                raise ValueError('unexpected Page lifecycle')
            pages.append(int(match[1]))
        elif match := BROKER.fullmatch(line):
            if brokers or summaries:
                raise ValueError('unexpected broker lifecycle')
            brokers.append(int(match[1]))
        elif match := STATS.fullmatch(line):
            fields = tuple(timing.integer(int(value)) for value in match.groups())
            if (case != 'admitted' or not released or stats or presentations or verified or summaries
                    or fields[1:3] != (report['generation'], report['viewport_revision'])
                    or fields[3:] != EXPECTED_STATS):
                raise ValueError('background admission stats mismatch')
            stats.append(fields)
        elif match := base.PRESENTED.fullmatch(line):
            width, height, serial, reference = match.groups()
            if (case != 'admitted' or not released or not stats or presentations or verified or summaries
                    or (int(width), int(height)) != wide.SIZE or reference != 'true'
                    or int(serial) != stats[0][0]):
                raise ValueError('native presentation identity mismatch')
            presentations.append(int(serial))
        elif match := base.VERIFIED.fullmatch(line):
            serial, generation, revision, width, height, count = map(int, match.groups())
            if (case != 'admitted' or not released or presentations != [serial] or verified or summaries
                    or (serial, generation, revision) != stats[0][:3]
                    or (width, height) != wide.SIZE or count != wide.PIXEL_BYTES):
                raise ValueError('acquired frame identity mismatch')
            verified.append(serial)
        elif match := timing.SUMMARY.fullmatch(line):
            route, frames, count, serial = match.groups()
            if (case != 'admitted' or not released or summaries or verified != [int(serial)]
                    or route != 'native-raster' or int(frames) != 1 or int(count) != wide.PIXEL_BYTES):
                raise ValueError('acquired completion mismatch')
            summaries.append(int(serial))
        elif match := base.FALLBACK.fullmatch(line):
            if not released and match[1].startswith('native scene awaits a current loaded page; size='):
                if case != 'rounded':
                    raise ValueError('unexpected primary native fallback')
                physical = match[1] == wide.PHYSICAL
            elif case == 'rounded' and released and match[1] == FALLBACK and not fallbacks:
                fallbacks.append(match[1])
            else:
                raise ValueError('unexpected or duplicate whole-frame fallback')
        elif (line.startswith(('native benchmark', 'native background gate:', 'native boxes', 'presenter:',
                               'native scene', '[page]', 'paint:', 'eris-browser:',
                               'Unable to open browser window:', "thread '")) or 'panicked at' in line):
            raise ValueError('unknown or failing proof diagnostic')
        else:
            other.append(line)
        prefix.extend(raw.encode())
    if (not released or len(adapters) != 1 or len(pages) != 1 or len(brokers) != 1
            or pages[0] == brokers[0] or control['identity']['pid'] in pages + brokers):
        raise ValueError('missing owned release/adapter/confined Page/distinct broker')
    if case == 'admitted' and not (len(stats) == len(presentations) == len(verified) == len(summaries) == 1):
        raise ValueError('incomplete native check population')
    if case == 'rounded' and (fallbacks != [FALLBACK] or stats or presentations or verified or summaries):
        raise ValueError('incomplete exact fallback control')
    return {'case': case, 'identity': identity, 'report': report, 'adapter': adapters[0],
            'page_pid': pages[0], 'broker_pid': brokers[0], 'positive_release': True,
            'verified_frames': len(verified), 'compared_bytes': wide.PIXEL_BYTES if verified else 0,
            'box_loop_work': 159 if stats else 0, 'box_stats': list(stats[0]) if stats else None,
            'fallbacks': fallbacks, 'other_diagnostics': other,
            'scope': 'acquired texture versus Canvas before compositor; no performance claim' if verified
                     else 'exact ordinary CPU fallback; no acquired-pixel claim'}


def fixture_data(directory, case):
    directory = directory.resolve()
    if case not in CASES or {p.name for p in directory.iterdir()} != set(FILES):
        raise ValueError('exact five-file fixture bundle required')
    for name in FILES:
        p = directory / name
        if p.is_symlink() or not p.is_file() or p.stat().st_size > 65536:
            raise ValueError('bounded regular fixture files required')
    if base.digest(directory / 'freeze.json', 65536) != FREEZE_SHA:
        raise ValueError('independent fixture freeze changed')
    freeze = timing.strict_json((directory / 'freeze.json').read_bytes(), 65536)
    if ([row['path'] for row in freeze['files']] != list(FILES[:3])
            or freeze['oracles']['path'] != 'oracles.json'):
        raise ValueError('fixture/oracle roster changed')
    for row in [*freeze['files'], freeze['oracles']]:
        path = directory / row['path']
        if path.stat().st_size != row['bytes'] or base.digest(path, 65536) != row['sha256']:
            raise ValueError('fixture or independent oracle changed')
    document = 'admitted.html' if case == 'admitted' else 'rounded.html'
    return {'/admitted.html': (directory / document).read_bytes(),
            '/two-pixels.png': (directory / 'two-pixels.png').read_bytes()}


def launch_owned(args):
    if (args.receipt.exists() or not args.receipt.parent.is_dir() or args.case not in CASES
            or not math.isfinite(args.window_seconds) or not 2 <= args.window_seconds <= 20
            or base.digest(args.binary, base.MAX_BINARY) != args.binary_sha256
            or base.digest(args.controller, base.MAX_BINARY) != args.controller_sha256):
        raise ValueError('fresh receipt, bounded lifetime and immutable inputs required')
    timing.integer(args.port, 1, 65535)
    validate_listener_fds((args.listener_fd,))
    bodies = fixture_data(args.fixtures, args.case)
    listener = socket.socket(fileno=args.listener_fd)
    if listener.getsockname() != ('127.0.0.1', args.port):
        listener.close(); raise ValueError('inherited listener identity mismatch')
    listener.setblocking(False)
    record = {'schema': 1, 'success': False, 'control_complete': False, 'commands': [], 'requests': [],
              'accepted_connections': 0, 'identity': None, 'browser_reaped': False, 'browser_returncode': None,
              'binary_sha256': args.binary_sha256, 'controller_sha256': args.controller_sha256,
              'fixture_freeze': FREEZE_SHA, 'port': args.port, 'case': args.case}
    child, emitted = None, 0
    deadline = time.monotonic() + args.window_seconds + 5
    def persist():
        temp = args.receipt.with_suffix('.tmp')
        temp.write_text(json.dumps(record, indent=2) + '\n'); temp.replace(args.receipt)
    def emit(data):
        nonlocal emitted
        keep = min(len(data), base.MAX_OUTPUT - emitted)
        sys.stderr.buffer.write(data[:keep]); sys.stderr.buffer.flush(); emitted += keep
        if keep != len(data):
            raise ValueError('diagnostic relay bound')
    persist()
    try:
        url = f'http://127.0.0.1:{args.port}/admitted.html'
        command = [str(args.binary), url, '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                   '--exit-after', str(args.window_seconds)]
        if args.case == 'admitted':
            command.append('--benchmark-native-check')
        record['browser_command'] = command; persist()
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stderr=subprocess.PIPE, close_fds=True)
        record['identity'] = base.child_identity(child.pid); persist()
        base.configure_owned(record['identity'], args.controller, dict(os.environ), record, persist,
                             requested_size=wide.SIZE)
        wide.serve_and_relay(child, listener, record, bodies, persist, deadline, emit,
                             waiting_pattern=timing.WAITING if args.case == 'admitted' else None,
                             marker_prefix='native background gate', forbidden_patterns=(STATS, timing.CPU_VERIFIED, timing.SUMMARY))
        record['browser_returncode'] = child.wait(timeout=2); record['browser_reaped'] = True
        record['success'] = record['browser_returncode'] == 0
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, subprocess.SubprocessError, KeyboardInterrupt) as error:
        record['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        listener.close()
        if child is not None:
            if not record['browser_reaped']:
                try:
                    os.waitid(os.P_PID, child.pid, base.WAIT_FLAGS)
                    os.kill(child.pid, signal.SIGKILL)
                    record['browser_returncode'] = child.wait(timeout=2); record['browser_reaped'] = True
                except (OSError, subprocess.SubprocessError) as error:
                    record['cleanup_error'] = str(error)[:4096]
            try:
                drain_stderr(child.stderr, emit)
            except (OSError, ValueError) as error:
                record['success'] = False; record['stderr_drain_error'] = str(error)[:4096]
            child.stderr.close()
        try:
            if (base.digest(args.binary, base.MAX_BINARY) != args.binary_sha256
                    or base.digest(args.controller, base.MAX_BINARY) != args.controller_sha256
                    or fixture_data(args.fixtures, args.case) != bodies):
                raise ValueError('owned launch inputs changed')
        except (OSError, ValueError) as error:
            record['success'] = False; record['postcheck_error'] = str(error)[:4096]
        persist()
    return 0 if record['success'] else 1


def source_binding():
    paths = {str(Path(__file__).resolve()), str(Path(wide.__file__).resolve()),
             str(Path(timing.__file__).resolve()), str(ROOT / 'tools/native_raster_followup.py')}
    return {**base.source_binding(), **{path: base.digest(Path(path), 1024 * 1024) for path in sorted(paths)}}


def run_host(args):
    if (args.output.exists() or not math.isfinite(args.timeout) or not math.isfinite(args.window_seconds)
            or not 2 <= args.window_seconds <= 20 or not args.window_seconds + 10 <= args.timeout <= 120
            or re.fullmatch('[0-9a-f]{64}', args.binary_sha256) is None):
        raise ValueError('new output, bounded lifetime and frozen binary SHA required')
    binary, output = args.binary.resolve(), args.output.resolve()
    fixtures = args.fixtures.resolve()
    if output.is_relative_to(fixtures) or fixtures.is_relative_to(output):
        raise ValueError('output must be separate from fixed fixture bundle')
    env = base.environment(args.loader_directory)
    found = shutil.which('hyprctl', path=env.get('PATH', os.defpath))
    if not found:
        raise ValueError('owned Hyprland compositor control is required')
    controller = Path(found).resolve()
    fixture_data(fixtures, 'admitted')
    def bindings():
        return {'binary': base.digest(binary, base.MAX_BINARY), 'controller': base.digest(controller, base.MAX_BINARY),
                'fixtures': {name: base.digest(fixtures / name, 65536) for name in FILES},
                'source_files': source_binding(), 'loader': base.loader_binding(args.loader_directory, env)}
    frozen = bindings()
    if frozen['binary'] != args.binary_sha256:
        raise ValueError('binary does not match supplied frozen SHA')
    output.mkdir(parents=True)
    copied = output / 'fixtures'; copied.mkdir()
    for name in FILES:
        shutil.copyfile(fixtures / name, copied / name)
    result = {'schema': 1, 'success': False, 'runs': [], 'bindings': frozen, 'binary': str(binary),
              'controller': str(controller), 'fixture_freeze': FREEZE_SHA,
              'display_environment': {key: env.get(key) for key in ('DISPLAY', 'WAYLAND_DISPLAY', 'XDG_RUNTIME_DIR', 'XDG_SESSION_TYPE')},
              'scope': 'one acquired native frame versus Canvas before compositor; optional ordinary fallback; no timing claim'}
    def persist():
        temp = output / 'background-host-results.json.tmp'
        temp.write_text(json.dumps(result, indent=2) + '\n'); temp.replace(output / 'background-host-results.json')
    def unchanged():
        if bindings() != frozen or any(base.digest(copied / name, 65536) != frozen['fixtures'][name] for name in FILES):
            raise ValueError('source/fixture/executable/loader binding changed')
    persist()
    try:
        for case in CASES if args.with_fallback else ('admitted',):
            unchanged()
            bodies = fixture_data(copied, case)
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
                listener.bind(('127.0.0.1', 0)); listener.listen(wide.MAX_ACTIVE_CONNECTIONS); listener.setblocking(False)
                port = listener.getsockname()[1]
                receipt = output / f'{case}.window-control.json'
                command = [sys.executable, str(Path(__file__).resolve()), '--owned-launch', '--binary', str(binary),
                           '--binary-sha256', frozen['binary'], '--receipt', str(receipt), '--controller', str(controller),
                           '--controller-sha256', frozen['controller'], '--listener-fd', str(listener.fileno()),
                           '--port', str(port), '--fixtures', str(copied), '--case', case,
                           '--window-seconds', str(args.window_seconds), '--allow-experimental-gpu']
                attempt = {'case': case, 'command': command, 'success': False}; result['runs'].append(attempt); persist()
                record, stdout = base.run_supervised(command, output, case, env, args.timeout, pass_fds=(listener.fileno(),))
                attempt['supervision'] = record; persist()
                if receipt.is_file():
                    attempt['control_sha256'] = base.digest(receipt, 1024 * 1024)
                    attempt['control'] = timing.strict_json(receipt.read_bytes(), 1024 * 1024); persist()
                base.check_success(record)
                if ((output / f'{case}.supervisor.stderr.log').stat().st_size
                        or record.get('capture_gate_required') or record.get('capture_gate_granted')):
                    raise ValueError('unexpected supervisor diagnostics or gate')
                stderr_path = output / f'{case}.stderr.log'
                if base.digest(stderr_path, base.MAX_OUTPUT) != record['stderr_sha256'] or wide.sha(stdout) != record['stdout_sha256']:
                    raise ValueError('raw output binding mismatch')
                control = attempt['control']
                expected_command = [str(binary), f'http://127.0.0.1:{port}/admitted.html', '--presenter=vulkan',
                                    '--raster=gpu', '--no-scripts', '--exit-after', str(args.window_seconds)]
                if case == 'admitted':
                    expected_command.append('--benchmark-native-check')
                if (control.get('binary_sha256') != frozen['binary'] or control.get('controller_sha256') != frozen['controller']
                        or control.get('fixture_freeze') != FREEZE_SHA or control.get('case') != case
                        or control.get('browser_command') != expected_command):
                    raise ValueError('owned wrapper input mismatch')
                checked = validate_run(stdout, stderr_path.read_bytes(), control, port, bodies, case)
                attempt['validation'] = checked
                if case == 'admitted':
                    (output / 'scene.ebni').write_bytes(bytes.fromhex(checked['report']['scene_hex']))
                try:
                    extra, _ = listener.accept()
                except BlockingIOError:
                    pass
                else:
                    extra.close(); raise ValueError('HTTP connection survived case boundary')
                unchanged(); attempt['success'] = True; persist()
        result['success'] = True
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, KeyboardInterrupt) as error:
        result['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        try:
            unchanged()
        except (OSError, ValueError) as error:
            result['success'] = False; result['postcheck_error'] = str(error)[:4096]
        persist()
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--owned-launch', action='store_true')
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--fixtures', type=Path, default=FIXTURES)
    parser.add_argument('--window-seconds', type=float, default=8)
    parser.add_argument('--allow-experimental-gpu', action='store_true')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--loader-directory', type=Path)
    parser.add_argument('--timeout', type=float, default=30)
    parser.add_argument('--with-fallback', action='store_true')
    parser.add_argument('--receipt', type=Path)
    parser.add_argument('--controller', type=Path)
    parser.add_argument('--controller-sha256')
    parser.add_argument('--listener-fd', type=int)
    parser.add_argument('--port', type=int)
    parser.add_argument('--case', choices=CASES)
    args = parser.parse_args()
    if not args.allow_experimental_gpu:
        parser.error('actual owned window/worker/Vulkan execution requires --allow-experimental-gpu')
    required = ('receipt', 'controller', 'controller_sha256', 'listener_fd', 'port', 'case') if args.owned_launch else ('output', 'loader_directory')
    if any(getattr(args, key) is None for key in required):
        parser.error('missing required host/owned-launch inputs')
    previous = {}
    def interrupted(_signal, _frame):
        raise KeyboardInterrupt
    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            previous[sig] = signal.signal(sig, interrupted)
        if args.owned_launch:
            return launch_owned(args)
        result = run_host(args)
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, KeyboardInterrupt) as error:
        parser.exit(1, f'{type(error).__name__}: {error}\n')
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
    print(json.dumps({'success': result['success'], 'results': str(args.output / 'background-host-results.json')}))
    return 0 if result['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
