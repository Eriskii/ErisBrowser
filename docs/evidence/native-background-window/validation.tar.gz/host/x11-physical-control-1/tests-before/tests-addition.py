
# Frozen before the Xlib control implementation. These fakes do not load Xlib,
# connect to X11, or launch a subprocess.
import ctypes
from unittest import mock


class XFunction:
    def __init__(self, call):
        self.call = call
    def __call__(self, *args):
        return self.call(*args)


class FakeX11:
    def __init__(self, clients=(11,), owners=None):
        self.clients = list(clients)
        self.owners = dict({11: 100} if owners is None else owners)
        self.buffers = []
        self.freed = 0
        self.closed = 0
        self.resizes = []
        self.reads = []
        self.owner_reads = {}
        self.change_before = False
        self.change_after = False
        self.bad_property = None
        self.final_size = (1280, 880)
        self.geometry_calls = 0
        self.XOpenDisplay = XFunction(lambda name: 123)
        self.XCloseDisplay = XFunction(self.close)
        self.XDefaultRootWindow = XFunction(lambda display: 1)
        self.XInternAtom = XFunction(lambda display, name, only: {b'_NET_CLIENT_LIST': 2, b'_NET_WM_PID': 3}[name])
        self.XSetErrorHandler = XFunction(lambda callback: None)
        self.XSync = XFunction(lambda display, discard: 0)
        self.XFree = XFunction(self.free)
        self.XGetWindowProperty = XFunction(self.property)
        self.XResizeWindow = XFunction(self.resize)
        self.XGetGeometry = XFunction(self.geometry)
    def close(self, display):
        self.closed += 1
        return 0
    def free(self, pointer):
        self.freed += 1
        return 0
    @staticmethod
    def put(pointer, kind, value):
        ctypes.cast(pointer, ctypes.POINTER(kind))[0] = value
    def property(self, display, window, atom, offset, length, delete, requested, actual, fmt, count, after, output):
        self.reads.append((window, atom, length))
        assert offset == 0 and delete == 0
        if atom == 2:
            values, kind = self.clients, 33
            assert window == 1 and length == 256 and requested == 33
        else:
            assert atom == 3 and length == 1 and requested == 6
            self.owner_reads[window] = self.owner_reads.get(window, 0) + 1
            owner = self.owners.get(window)
            if window == 11 and ((self.change_before and self.owner_reads[window] >= 2) or (self.change_after and self.resizes)):
                owner = 999
            values, kind = ([] if owner is None else [owner]), (0 if owner is None else 6)
        buffer = (ctypes.c_ulong * max(1, len(values)))(*values)
        self.buffers.append(buffer)
        self.put(actual, ctypes.c_ulong, kind)
        self.put(fmt, ctypes.c_int, 32 if kind else 0)
        self.put(count, ctypes.c_ulong, len(values))
        self.put(after, ctypes.c_ulong, 0)
        ctypes.cast(output, ctypes.POINTER(ctypes.POINTER(ctypes.c_ubyte)))[0] = ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte))
        if atom == 2 and self.bad_property:
            field, value = self.bad_property
            pointer, typ = {'format': (fmt, ctypes.c_int), 'type': (actual, ctypes.c_ulong), 'count': (count, ctypes.c_ulong), 'after': (after, ctypes.c_ulong)}[field]
            self.put(pointer, typ, value)
        return 0
    def resize(self, display, window, width, height):
        self.resizes.append((window, width, height))
        return 1
    def geometry(self, display, window, root, x, y, width, height, border, depth):
        self.geometry_calls += 1
        size = self.final_size if self.resizes else (1920, 1320)
        for pointer, kind, value in [(root, ctypes.c_ulong, 1), (x, ctypes.c_int, 0), (y, ctypes.c_int, 0), (width, ctypes.c_uint, size[0]), (height, ctypes.c_uint, size[1]), (border, ctypes.c_uint, 0), (depth, ctypes.c_uint, 24)]:
            self.put(pointer, kind, value)
        return 1


class X11PhysicalControlTests(unittest.TestCase):
    def run_fake(self, lib):
        with mock.patch.object(host.time, 'sleep'):
            return host.resize_x11(lib, 100)

    def test_unique_owned_window_exact_physical_size_and_release(self):
        lib = FakeX11((10, 11, 12), {10: 9, 11: 100})
        result = self.run_fake(lib)
        self.assertEqual(result['pid'], 100)
        self.assertEqual(result['window'], 11)
        self.assertEqual(result['pid_before'], result['pid_after'])
        self.assertEqual(result['pid_after'], 100)
        self.assertEqual(result['initial_size'], [1920, 1320])
        self.assertEqual(result['requested_size'], [1280, 880])
        self.assertEqual(result['observed_size'], [1280, 880])
        self.assertEqual(lib.resizes, [(11, 1280, 880)])
        self.assertEqual(lib.closed, 1)
        self.assertEqual(lib.freed, len(lib.reads))
        self.assertEqual(lib.geometry_calls, 2)
        self.assertEqual(len(lib.XGetWindowProperty.argtypes), 12)
        self.assertEqual(lib.XResizeWindow.restype, ctypes.c_int)

    def test_bounded_client_list_and_duplicate_or_absent_pid_refuse_before_resize(self):
        for clients, owners in [((), {}), ((10, 11), {10: 100, 11: 100}), ((10,), {10: 999})]:
            lib = FakeX11(clients, owners)
            with self.assertRaises(ValueError): self.run_fake(lib)
            self.assertEqual(lib.resizes, [])
            self.assertEqual(lib.closed, 1)
        for bad in [('format', 8), ('type', 6), ('count', 257), ('after', 4)]:
            lib = FakeX11(); lib.bad_property = bad
            with self.assertRaises(ValueError): self.run_fake(lib)
            self.assertEqual(lib.resizes, [])
            self.assertEqual(lib.freed, 1)
            self.assertEqual(lib.closed, 1)
        lib = FakeX11(tuple(range(1, 257)), {11: 100})
        self.run_fake(lib)
        self.assertEqual(len(lib.reads), 259)  # client list + 256 PID reads + two rechecks
        self.assertEqual(lib.resizes, [(11, 1280, 880)])

    def test_pid_recheck_before_and_after_configuration(self):
        for field, expected_resizes in [('change_before', []), ('change_after', [(11, 1280, 880)])]:
            lib = FakeX11(); setattr(lib, field, True)
            with self.assertRaises(ValueError): self.run_fake(lib)
            self.assertEqual(lib.resizes, expected_resizes)
            self.assertEqual(lib.closed, 1)
            self.assertEqual(lib.freed, len(lib.reads))

    def test_failed_physical_confirmation_is_bounded_and_closes_display(self):
        lib = FakeX11(); lib.final_size = (1279, 880)
        with self.assertRaises(ValueError): self.run_fake(lib)
        self.assertEqual(lib.resizes, [(11, 1280, 880)])
        self.assertEqual(lib.geometry_calls, 33)  # initial plus at most32 confirmations
        self.assertEqual(lib.closed, 1)
        lib = FakeX11(); lib.XOpenDisplay = XFunction(lambda name: None)
        with self.assertRaises(ValueError): self.run_fake(lib)
        self.assertEqual(lib.closed, 0)
        self.assertEqual(lib.resizes, [])

    def test_parent_control_refuses_expired_or_full_command_ledger(self):
        identity = dict(pid=100, parent_pid=99, process_group=99, start_ticks=1000)
        library = dict(path='/fixed/libX11.so.6.4.0', bytes=10, sha256='a' * 64)
        for commands, deadline in [([], 0), ([{}] * host.base.CONTROL_COMMANDS, 10)]:
            record = dict(identity=identity, commands=commands, control_complete=True, controlled_size=[1280, 880])
            with mock.patch.object(host.time, 'monotonic', return_value=1), mock.patch.object(host.base, 'ensure_live_child') as live, mock.patch.object(host.base, 'controller_call') as call:
                with self.assertRaises(ValueError):
                    host.configure_x11_owned(identity, library, {}, record, lambda: None, deadline)
                call.assert_not_called()
                self.assertFalse(record['control_complete'])
