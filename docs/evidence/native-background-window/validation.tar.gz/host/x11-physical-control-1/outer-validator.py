

def validate_x11_control(control, library):
    """Bind the opt-in control to the selected library, owned PID and raw reply."""
    try:
        physical_keys = {'x11_physical_control', 'control_size_space', 'logical_controlled_size_before_physical'}
        if library is None:
            if control.get('x11_library') is not None or physical_keys & control.keys():
                raise ValueError('physical control reported without opt-in')
            return
        if (control['x11_library'] != library or control['control_size_space'] != 'x11-physical'
                or control['logical_controlled_size_before_physical'] != [1280, 880]
                or control['controlled_size'] != [1280, 880]):
            raise ValueError('physical control library/coordinate binding mismatch')
        pid = timing.integer(control['identity']['pid'], 1, 2**31 - 1)
        data = control['x11_physical_control']
        if set(data) != {'library', 'pid', 'window', 'pid_before', 'pid_after', 'client_count', 'property_reads',
                         'geometry_reads', 'initial_size', 'requested_size', 'observed_size', 'scope'}:
            raise ValueError('complete fixed physical-control reply required')
        timing.integer(data['window'], 1, 0xffffffff)
        clients = timing.integer(data['client_count'], 1, 256)
        timing.integer(data['geometry_reads'], 2, 33)
        timing.integer(data['property_reads'], 4, 259)
        if not isinstance(data['initial_size'], list) or len(data['initial_size']) != 2:
            raise ValueError('physical initial size must have two axes')
        for axis in data['initial_size']:
            timing.integer(axis, 1, 16384)
        for key in ('pid', 'pid_before', 'pid_after'):
            if timing.integer(data[key], 1, 2**31 - 1) != pid:
                raise ValueError('physical-control PID differs from owned browser')
        if (data['library'] != library or data['property_reads'] != clients + 3
                or data['requested_size'] != [1280, 880] or data['observed_size'] != [1280, 880]
                or data['scope'] != 'unique X11 PID-property match; parent retains unreaped browser identity'):
            raise ValueError('physical control reply differs from fixed contract')
        rows = [row for row in control['commands'] if '--x11-resize-child' in row.get('argv', [])]
        if len(rows) != 1:
            raise ValueError('one bounded physical helper command required')
        row = rows[0]
        argv = [sys.executable, str(Path(__file__).resolve()), '--x11-resize-child', '--owned-pid', str(pid),
                '--x11-library', library['path'], '--x11-library-sha256', library['sha256'], '--allow-experimental-gpu']
        stdout = row['stdout'].encode('utf-8')
        if (row['argv'] != argv or row['status'] != 'exited' or row['returncode'] != 0
                or len(stdout) > 4096 or row['stdout_bytes'] != len(stdout) or row['stdout_sha256'] != wide.sha(stdout)
                or row['stderr'] != '' or row['stderr_bytes'] != 0 or row['stderr_sha256'] != wide.sha(b'')
                or timing.strict_json(stdout, 4096) != data):
            raise ValueError('physical-control raw helper output binding mismatch')
    except (KeyError, TypeError, AttributeError, UnicodeError) as error:
        raise ValueError('malformed physical control receipt') from error
