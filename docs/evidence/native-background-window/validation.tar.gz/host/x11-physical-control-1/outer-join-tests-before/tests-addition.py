
class X11OuterJoinTests(unittest.TestCase):
    def test_frozen_library_owned_pid_and_physical_receipt_are_bound(self):
        library = dict(path='/fixed/libX11.so.6.4.0', bytes=10, sha256='a' * 64)
        physical = dict(library=library, pid=100, window=11, pid_before=100, pid_after=100,
                        client_count=3, property_reads=6, geometry_reads=2,
                        initial_size=[1920, 1320], requested_size=[1280, 880], observed_size=[1280, 880],
                        scope='unique X11 PID-property match; parent retains unreaped browser identity')
        stdout = json.dumps(physical, sort_keys=True) + '\n'
        argv = [host.sys.executable, str(Path(host.__file__).resolve()), '--x11-resize-child', '--owned-pid', '100',
                '--x11-library', library['path'], '--x11-library-sha256', library['sha256'], '--allow-experimental-gpu']
        row = dict(argv=argv, status='exited', returncode=0, stdout=stdout,
                   stdout_bytes=len(stdout.encode()), stdout_sha256=digest(stdout.encode()),
                   stderr='', stderr_bytes=0, stderr_sha256=digest(b''))
        control = dict(identity=dict(pid=100), x11_library=library, control_size_space='x11-physical',
                       logical_controlled_size_before_physical=[1280, 880], controlled_size=[1280, 880],
                       x11_physical_control=physical, commands=[row])
        host.validate_x11_control(control, library)
        host.validate_x11_control(dict(x11_library=None), None)
        for key in ('x11_library', 'control_size_space', 'x11_physical_control'):
            changed = copy.deepcopy(control); del changed[key]
            with self.assertRaises(ValueError): host.validate_x11_control(changed, library)
        for key, value in [('library', {**library, 'sha256': 'b' * 64}), ('pid', 101), ('pid_before', 101),
                           ('pid_after', 101), ('window', 0), ('observed_size', [1279, 880]),
                           ('requested_size', [1920, 1320]), ('client_count', 257), ('property_reads', 7),
                           ('geometry_reads', 34), ('scope', 'kernel ownership')]:
            changed = copy.deepcopy(control); changed['x11_physical_control'][key] = value
            with self.assertRaises(ValueError): host.validate_x11_control(changed, library)
        for key, value in [('stdout_sha256', 'b' * 64), ('status', 'timeout'), ('stderr_bytes', 1)]:
            changed = copy.deepcopy(control); changed['commands'][0][key] = value
            with self.assertRaises(ValueError): host.validate_x11_control(changed, library)
        changed = copy.deepcopy(control); changed['commands'].append(copy.deepcopy(row))
        with self.assertRaises(ValueError): host.validate_x11_control(changed, library)
        with self.assertRaises(ValueError): host.validate_x11_control(control, None)
