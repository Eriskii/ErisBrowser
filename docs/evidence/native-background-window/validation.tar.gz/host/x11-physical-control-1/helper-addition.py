

def x11_library_binding(env):
    if (not env.get('DISPLAY') or env.get('WAYLAND_DISPLAY') or env.get('WAYLAND_SOCKET')
            or env.get('WINIT_X11_SCALE_FACTOR') != '1'):
        raise ValueError('physical control requires explicit X11 with scale one')
    directories = env.get('LD_LIBRARY_PATH', '').split(':')
    if len(directories) > 64 or any(len(value) > 4096 for value in directories):
        raise ValueError('bounded explicit library search required')
    for value in directories:
        if not value or not Path(value).is_absolute():
            continue
        candidate = Path(value) / 'libX11.so.6'
        if candidate.is_file():
            path = candidate.resolve()
            return {'path': str(path), 'bytes': path.stat().st_size,
                    'sha256': base.digest(path, base.MAX_BINARY)}
    raise ValueError('libX11 must be present in the explicit library path')


def resize_x11(lib, pid):
    """Runs only in the timed helper process. PID is an X11 property attribution.

    The parent separately retains unreaped-child identity. This does not claim
    XRes/kernel ownership, and never enumerates a window tree or reads events.
    """
    timing.integer(pid, 1, 2**31 - 1)
    void, ulong, uint, integer = ctypes.c_void_p, ctypes.c_ulong, ctypes.c_uint, ctypes.c_int
    byte_pointer = ctypes.POINTER(ctypes.c_ubyte)
    signatures = {
        'XOpenDisplay': ([ctypes.c_char_p], void),
        'XCloseDisplay': ([void], integer),
        'XDefaultRootWindow': ([void], ulong),
        'XInternAtom': ([void, ctypes.c_char_p, integer], ulong),
        'XSetErrorHandler': ([void], void),
        'XSync': ([void, integer], integer),
        'XFree': ([void], integer),
        'XGetWindowProperty': ([void, ulong, ulong, ctypes.c_long, ctypes.c_long, integer, ulong,
                               ctypes.POINTER(ulong), ctypes.POINTER(integer), ctypes.POINTER(ulong),
                               ctypes.POINTER(ulong), ctypes.POINTER(byte_pointer)], integer),
        'XResizeWindow': ([void, ulong, uint, uint], integer),
        'XGetGeometry': ([void, ulong, ctypes.POINTER(ulong), ctypes.POINTER(integer),
                         ctypes.POINTER(integer), ctypes.POINTER(uint), ctypes.POINTER(uint),
                         ctypes.POINTER(uint), ctypes.POINTER(uint)], integer),
    }
    for name, (arguments, result) in signatures.items():
        function = getattr(lib, name)
        function.argtypes, function.restype = arguments, result
    errors = []
    @ctypes.CFUNCTYPE(integer, void, void)
    def on_error(_display, _error):
        if not errors:
            errors.append(True)
        return 0
    previous = lib.XSetErrorHandler(ctypes.cast(on_error, void))
    display = None
    property_reads = 0
    geometry_reads = 0
    try:
        display = lib.XOpenDisplay(None)
        if not display:
            raise ValueError('cannot open inherited X11 display')
        root = lib.XDefaultRootWindow(display)
        clients_atom = lib.XInternAtom(display, b'_NET_CLIENT_LIST', 1)
        pid_atom = lib.XInternAtom(display, b'_NET_WM_PID', 1)
        if not root or not clients_atom or not pid_atom:
            raise ValueError('required X11 root/properties unavailable')
        def sync():
            lib.XSync(display, 0)
            if errors:
                raise ValueError('X11 request failed')
        def property_values(window, atom, expected, cap, missing=False):
            nonlocal property_reads
            actual, count, after, fmt = ulong(), ulong(), ulong(), integer()
            pointer = byte_pointer()
            property_reads += 1
            try:
                status = lib.XGetWindowProperty(display, window, atom, 0, cap, 0, expected,
                    ctypes.byref(actual), ctypes.byref(fmt), ctypes.byref(count),
                    ctypes.byref(after), ctypes.byref(pointer))
                if status != 0 or errors:
                    raise ValueError('X11 property read failed')
                if missing and (actual.value, fmt.value, count.value, after.value) == (0, 0, 0, 0):
                    return []
                if (actual.value != expected or fmt.value != 32 or after.value != 0
                        or count.value > cap or (count.value and not pointer)):
                    raise ValueError('bounded typed X11 property required')
                # Xlib expands protocol32 values to native unsigned long slots.
                values = ctypes.cast(pointer, ctypes.POINTER(ulong))
                return [int(values[index]) for index in range(count.value)]
            finally:
                if pointer:
                    lib.XFree(pointer)
        def owner(window):
            values = property_values(window, pid_atom, 6, 1, missing=True)  # XA_CARDINAL
            return values[0] if len(values) == 1 else None
        clients = property_values(root, clients_atom, 33, 256)  # XA_WINDOW
        if len(set(clients)) != len(clients) or any(not 0 < value <= 0xffffffff for value in clients):
            raise ValueError('unique bounded X11 client identifiers required')
        matches = [window for window in clients if owner(window) == pid]
        if len(matches) != 1:
            raise ValueError('exactly one X11 window must report the owned PID')
        window = matches[0]
        def geometry():
            nonlocal geometry_reads
            returned_root, x, y = ulong(), integer(), integer()
            width, height, border, depth = uint(), uint(), uint(), uint()
            geometry_reads += 1
            status = lib.XGetGeometry(display, window, ctypes.byref(returned_root), ctypes.byref(x), ctypes.byref(y),
                ctypes.byref(width), ctypes.byref(height), ctypes.byref(border), ctypes.byref(depth))
            if (not status or errors or returned_root.value != root
                    or not 1 <= width.value <= 16384 or not 1 <= height.value <= 16384
                    or not 1 <= depth.value <= 64):
                raise ValueError('invalid X11 window geometry')
            return [width.value, height.value]
        initial = geometry()
        before = owner(window)
        if before != pid:
            raise ValueError('X11 PID changed before physical resize')
        lib.XResizeWindow(display, window, 1280, 880)
        sync()
        observed = None
        for _ in range(32):
            observed = geometry()
            if observed == [1280, 880]:
                break
            time.sleep(0.01)
            sync()
        if observed != [1280, 880]:
            raise ValueError('X11 physical resize not confirmed')
        after = owner(window)
        if after != pid:
            raise ValueError('X11 PID changed after physical resize')
        return {'pid': pid, 'window': window, 'pid_before': before, 'pid_after': after,
                'client_count': len(clients), 'property_reads': property_reads, 'geometry_reads': geometry_reads,
                'initial_size': initial, 'requested_size': [1280, 880], 'observed_size': observed,
                'scope': 'unique X11 PID-property match; parent retains unreaped browser identity'}
    finally:
        if display:
            lib.XCloseDisplay(display)
        lib.XSetErrorHandler(previous)


def x11_resize_child(args):
    expected = x11_library_binding(dict(os.environ))
    if (args.x11_library is None or str(args.x11_library.resolve()) != expected['path']
            or args.x11_library_sha256 != expected['sha256']):
        raise ValueError('physical helper library binding differs')
    result = resize_x11(ctypes.CDLL(expected['path']), args.owned_pid)
    if x11_library_binding(dict(os.environ)) != expected:
        raise ValueError('X11 library changed during control')
    print(json.dumps({'library': expected, **result}, sort_keys=True))
    return 0


def configure_x11_owned(identity, library, env, record, persist, deadline):
    record['control_complete'] = False
    record['logical_controlled_size_before_physical'] = record.get('controlled_size')
    persist()
    base.ensure_live_child(identity)
    remaining = deadline - time.monotonic()
    if remaining < 0.05 or len(record['commands']) >= base.CONTROL_COMMANDS:
        raise ValueError('owned physical control deadline/command bound')
    command = [str(Path(__file__).resolve()), '--x11-resize-child', '--owned-pid', str(identity['pid']),
               '--x11-library', library['path'], '--x11-library-sha256', library['sha256'], '--allow-experimental-gpu']
    result = base.controller_call(Path(sys.executable), command, env, min(1.5, remaining))
    row = {'argv': [sys.executable, *command], 'status': result.record['status'],
           'returncode': result.record['returncode'], 'stdout_bytes': len(result.stdout),
           'stdout_sha256': wide.sha(result.stdout), 'stderr_bytes': len(result.stderr),
           'stderr_sha256': wide.sha(result.stderr)}
    if len(result.stdout) <= 4096:
        row['stdout'] = result.stdout.decode('utf-8', errors='strict')
    if len(result.stderr) <= 4096:
        row['stderr'] = result.stderr.decode('utf-8', errors='strict')
    record['commands'].append(row); persist()
    base.ensure_live_child(identity)
    if (result.record['status'] != 'exited' or result.record['returncode'] != 0
            or result.stderr or len(result.stdout) > 4096):
        raise ValueError('bounded X11 physical controller failed')
    checked = timing.strict_json(result.stdout, 4096)
    if (checked['library'] != library or checked['pid'] != identity['pid']
            or checked['pid_before'] != identity['pid'] or checked['pid_after'] != identity['pid']
            or checked['requested_size'] != [1280, 880] or checked['observed_size'] != [1280, 880]
            or not 1 <= checked['client_count'] <= 256 or not 1 <= checked['geometry_reads'] <= 33
            or checked['property_reads'] != checked['client_count'] + 3):
        raise ValueError('physical controller did not confirm the owned fixed size')
    if time.monotonic() >= deadline:
        raise ValueError('physical control exhausted original launch deadline')
    record['x11_physical_control'] = checked
    record['control_size_space'] = 'x11-physical'
    record['controlled_size'] = [1280, 880]
    record['control_complete'] = True
    persist()
