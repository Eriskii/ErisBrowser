

class DefaultWindowDurationTests(unittest.TestCase):
    def test_default_and_reparsed_window_duration_have_identical_argv_text(self):
        common = ['native_background_host.py', '--allow-experimental-gpu',
                  '--binary', '/fixed/browser', '--binary-sha256', 'a' * 64]
        top = ['--output', '/fixed/output', '--loader-directory', '/fixed/loader']
        owned = ['--owned-launch', '--receipt', '/fixed/receipt',
                 '--controller', '/fixed/hyprctl', '--controller-sha256', 'b' * 64,
                 '--listener-fd', '9', '--port', '47123', '--case', 'admitted']
        for mode, suffix in [('host', top), ('owned', owned)]:
            for duration in ([], ['--window-seconds', '8'], ['--window-seconds', '8.0']):
                with self.subTest(mode=mode, duration=duration):
                    with mock.patch.object(host.sys, 'argv', common + suffix + duration), \
                         mock.patch.object(host.signal, 'signal'), \
                         mock.patch.object(host, 'run_host', return_value={'success': True}) as run, \
                         mock.patch.object(host, 'launch_owned', return_value=0) as launch, \
                         mock.patch('builtins.print'):
                        self.assertEqual(host.main(), 0)
                    selected, inactive = (run, launch) if mode == 'host' else (launch, run)
                    selected.assert_called_once()
                    inactive.assert_not_called()
                    value = selected.call_args.args[0].window_seconds
                    self.assertIs(type(value), float)
                    self.assertEqual(value, 8.0)
                    self.assertEqual(['--exit-after', str(value)], ['--exit-after', '8.0'])
