#!/usr/bin/env python3
"""Root-run, explicit-input evidence packaging; never runs project code."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
Q = Path('/tmp/eris-object-fit-preparation-1')
BASE = 'ff4f9e354df36129132e60506c7ed7c06603574b'
SOURCE = '1d6e34314f5869c2492aa62097e97aa7821e6851c8543ab909cd87f1fd666bb0'
LIVE = '8c197d1997159f245ca4f5b7540f9a5417c3d7b69759b4cf0ff2c1716241fc2c'
REFERENCE = 'tests/reftests/object-fit-combined-scale-down-ref.html'
OUT = W / 'docs/evidence'
STEM = 'image-fitting'
members = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def path_checked(value):
    p = Path(value)
    require(p.is_absolute() and '..' not in p.parts, f'absolute clean path required: {p}')
    require(not any(q.is_symlink() for q in (p, *p.parents)), f'symlink: {p}')
    require(p.is_file(), f'not a regular file: {p}')
    return p


def member_name(p):
    for root, prefix in ((W, 'worktree'), (P, 'evidence'), (Q, 'preparation')):
        if p.is_relative_to(root):
            return prefix + '/' + p.relative_to(root).as_posix()
    return 'context/' + digest(str(p).encode())[:16] + '/' + p.name


def bound(row, archive=True):
    p = path_checked(row['path'])
    require(p.stat().st_size == row['bytes'], f'byte count: {p}')
    if not archive:  # Binaries are hashed in bounded chunks and never archived.
        h = hashlib.sha256()
        with p.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(chunk)
        require(h.hexdigest() == row['sha256'], f'hash: {p}')
        return None
    require(row['bytes'] <= 8 * 1024 * 1024, f'oversized archive input: {p}')
    require(not any(x in ('.git', '__pycache__', 'node_modules') or x.startswith('target') for x in p.parts), f'excluded tree: {p}')
    require(not p.name.endswith(('.tar', '.tar.gz', '.tgz', '.zip', '.xz', '.gz')), f'recursive archive: {p}')
    data = p.read_bytes()
    require(not data.startswith(b'\x7fELF'), f'ELF archive input: {p}')
    require(not data.startswith((b'\x1f\x8b', b'PK\x03\x04', b'\xfd7zXZ\x00')) and data[257:262] != b'ustar', f'archive input: {p}')
    require(digest(data) == row['sha256'], f'hash: {p}')
    name = member_name(p)
    require(name not in members or members[name] == data, f'colliding archive path: {name}')
    members[name] = data
    return data


def binding(p):
    p = path_checked(str(p))
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': digest(data)}


def load(row):
    return json.loads(bound(row))


def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args])


def main():
    require(len(sys.argv) == 2, 'usage: package.py ABSOLUTE_PACKAGE_SELECTION_JSON')
    require(not any(p.is_symlink() for p in (OUT, *OUT.parents)), 'symlink output directory')
    require(not (OUT / (STEM + '.json')).exists() and not (OUT / (STEM + '.tar.gz')).exists(), 'outputs already exist')
    selection = load(binding(Path(sys.argv[1])))
    bound(binding(Path(__file__)))
    require(git('rev-parse', 'HEAD').decode().strip() == BASE, 'worktree HEAD')
    source_row = selection['source']
    require(source_row['path'] == str(P / 'compiled-source-3.json') and source_row['sha256'] == SOURCE, 'selected source')
    source = load(source_row)
    require(source['base'] == BASE and len(source['source_sha256']) == 433, 'source inventory')
    live_row = selection['live_source']
    require(live_row['path'] == str(P / 'compiled-source-4.json') and live_row['sha256'] == LIVE, 'live source')
    live = load(live_row)
    require(live['base'] == BASE and set(live['source_sha256']) == set(source['source_sha256']), 'live inventory')
    require([n for n in source['source_sha256'] if source['source_sha256'][n] != live['source_sha256'][n]] == [REFERENCE], 'reference-only delta')
    correction_row = binding(P / 'root-reftests/reference-expression-correction-1.json')
    require(correction_row['sha256'] == '506f5955caf17a34e6e4cadbeec7e0ab839afdbf896096a6d8029091be542e6f', 'reference correction')
    correction = load(correction_row)
    require(correction['parent_source'] == source_row and correction['source'] == live_row and correction['changed_paths'] == [REFERENCE] and correction['engine_changes'] is False, 'reference correction joins')
    bound(correction['before'])
    bound(correction['after'])
    require(correction['before']['sha256'] == source['source_sha256'][REFERENCE] and correction['after']['sha256'] == live['source_sha256'][REFERENCE], 'reference before/after')
    for name, sha in live['source_sha256'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'source path')
        require(binding(W / name)['sha256'] == sha, f'compiled source changed: {name}')
    old = load(binding(P / 'compiled-source-2.json'))
    refinement = load(binding(P / 'input-inventory-refinement.json'))
    removed = refinement['removed_nonexecuted_documentation']
    require(len(old['source_sha256']) == 439 and len(removed) == 6 and refinement['engine_changes'] is False, 'source refinement counts')
    require(all(n.startswith('tests/reftests/') and n.endswith('.md') and old['source_sha256'][n] == h for n, h in removed.items()), 'nonexecuted removals')
    require({n: h for n, h in old['source_sha256'].items() if n not in removed} == source['source_sha256'], 'source refinement content')
    require(refinement['parent_manifest_sha256'] == binding(P / 'compiled-source-2.json')['sha256'] and refinement['manifest_sha256'] == SOURCE, 'source refinement joins')
    load(binding(P / 'compiled-source-1.json'))

    published = {}
    for name, row in selection['published'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and not name.startswith('docs/evidence/'), 'published path')
        require(row['path'] == str(W / name), 'published path binding')
        bound(row)
        published[name] = {k: row[k] for k in ('bytes', 'sha256')}
    changed = set(git('diff', 'HEAD', '--name-only', '-z').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    require(changed - {''} == set(published), 'published roster differs from changed files')
    require('documentation' in selection['reviews'] and selection['reviews'], 'documentation review required')
    for name, row in selection['reviews'].items():
        review = load(row)
        require(review['status'].startswith('clear') and review['files'], f'review not clear/bound: {name}')
        for item in review['files']:
            bound(item, archive=False)
        if name == 'documentation':
            reviewed = {item['path']: {k: item[k] for k in ('bytes', 'sha256')} for item in review['files']}
            require(all(reviewed.get(str(W / path)) == meta for path, meta in published.items() if path.endswith('.md')), 'published documentation review coverage')
    for row in selection['evidence']:
        bound(row)

    checks, receipts = {}, {}
    result_re = re.compile(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', re.M)
    for name, spec in selection['checks'].items():
        receipt = load(spec['receipt'])
        log = bound(spec['log'])
        require(receipt['command'] == spec['argv'] and receipt['exit'] == spec['exit'], f'command/exit: {name}')
        require(Path(spec['receipt']['path']).parent / receipt['log'] == Path(spec['log']['path']) and receipt['sha256'] == spec['log']['sha256'], f'log join: {name}')
        load(spec['source'])
        rows = [(int(a), int(b)) for a, b in result_re.findall(log.decode('utf-8', errors='replace'))]
        totals = [sum(a for a, _ in rows), sum(b for _, b in rows), len(rows)] if rows else None
        require(totals == spec['rust_results'], f'raw Rust totals: {name}')
        receipts[name] = receipt
        checks[name] = {'exit': receipt['exit'], 'results': totals, 'source': spec['source'], 'receipt': spec['receipt'], 'log': spec['log']}
    for name, results, exit_code, manifest in (
            ('focused-objects-1', [88, 0, 1], 0, 'compiled-source-1.json'),
            ('full-native-1', [2092, 1, 1], 101, 'compiled-source-2.json'),
            ('date-host-isolated-1', [1, 0, 1], 0, 'compiled-source-2.json')):
        require(checks[name]['results'] == results and checks[name]['exit'] == exit_code, f'required retained attempt: {name}')
        require(checks[name]['source'] == binding(P / manifest), f'historical source: {name}')
    require(set(selection['final_checks']) == {'native', 'default', 'clippy_msrv', 'clippy_198', 'format', 'build', 'reftests'}, 'final check roles')
    for role, name in selection['final_checks'].items():
        allowed_sources = (LIVE,) if role == 'reftests' else (SOURCE, LIVE, binding(P / 'compiled-source-2.json')['sha256'])
        require(checks[name]['exit'] == 0 and checks[name]['source']['sha256'] in allowed_sources, f'final source/success: {role}')

    report_counts = {}
    for name, spec in selection['reports'].items():
        report, manifest = load(spec['report']), load(spec['manifest'])
        command = receipts[spec['check']]['command']
        require(command[0] == 'python3' and command[1] == str(W / 'tools/reftest.py'), f'reftest driver: {name}')
        require(command[command.index('--output-dir') + 1] == str(Path(spec['report']['path']).parent), f'reftest output: {name}')
        actual_manifest = command[command.index('--manifest') + 1] if '--manifest' in command else str(W / 'tests/reftests/manifest.json')
        require(actual_manifest == spec['manifest']['path'], f'reftest manifest: {name}')
        binary = load(spec['binary_record'])
        bound(binary, archive=False)
        require(command[command.index('--binary') + 1] == binary['path'] == report['binary'], f'reftest binary: {name}')
        if name in ('baseline-1', 'baseline-combined-1'):
            require(spec['binary_record'] == {'path': '/tmp/eris-native-image-accounting-1/candidate-binary.json', 'bytes': 1089, 'sha256': 'e524cfa9ab233c8dbd2da313954abdf3254c38161bb7fc5626100856ae94d29b'}, 'retained predecessor record')
            require(binary['path'] == '/tmp/eris-native-image-accounting-1/eris-browser-candidate-1' and binary['bytes'] == 61751032 and binary['sha256'] == 'ddc68b7dc65564c04f363d0fa7030a62b1ffb05a2d479e61c68a59e8802ce6d7', 'retained predecessor binary')
        if binary['path'] == str(P / 'eris-browser-candidate-1'):
            require(binary['compiled_source'] == source_row, 'candidate source join')
            require(binary['build_receipt'] == selection['checks'][selection['final_checks']['build']]['receipt'], 'candidate build join')
            require(any(spec['receipt'] == binary['strip_receipt'] and spec['exit'] == 0 and spec['source'] == source_row for spec in selection['checks'].values()), 'candidate strip receipt/log join')
        cases = report['cases']
        require([r['name'] for r in cases] == [r['name'] for r in manifest['cases']] and len({r['name'] for r in cases}) == len(cases), f'reftest identities: {name}')
        require(report['suite'] == 'eris-self-authored-reftests' and report['conformance_claim'] is False, 'reftest scope')
        require(report['viewport'] == {'width': manifest['width'], 'height': manifest['height']}, 'reftest viewport')
        for row in cases:
            require(row['status'] in ('pass', 'fail', 'error'), 'reftest status')
            if row['status'] != 'error':
                require((row['different_pixels'] == 0) == (row['status'] == 'pass'), 'reftest pixel/status')
        counts = [sum(r['status'] == 'pass' for r in cases), sum(r['status'] != 'pass' for r in cases), len(cases)]
        require(counts == spec['counts'] == [report['passed'], report['failed'], report['total']], f'reftest counts: {name}')
        require(receipts[spec['check']]['exit'] == int(counts[1] != 0), 'reftest exit/counts')
        report_counts[name] = counts
    require(report_counts[selection['final_report']] == [62, 0, 62] and selection['reports'][selection['final_report']]['check'] == selection['final_checks']['reftests'], 'final 62 reftests')
    require(report_counts['baseline-1'] == [0, 4, 4] and report_counts['baseline-combined-1'] == [0, 1, 1], 'failed baselines retained')
    require(report_counts['candidate-1'] == [61, 1, 62] and checks[selection['reports']['candidate-1']['check']]['source'] == source_row, 'first candidate reference failure retained')

    require(sum(map(len, members.values())) <= 32 * 1024 * 1024, 'archive budget')
    index = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())}
    members['index.json'] = encoded(index)
    OUT.mkdir(parents=True, exist_ok=True)
    archive_path = OUT / (STEM + '.tar.gz')
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
                for name, data in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                    archive.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:gz') as archive:
        entries = archive.getmembers()
        require([r.name for r in entries] == sorted(members) and all(r.isfile() for r in entries), 'reopened archive roster/type')
        for entry in entries:
            data = archive.extractfile(entry).read()
            require(data == members[entry.name], f'reopened archive bytes: {entry.name}')
        require(json.loads(archive.extractfile('index.json').read()) == index, 'reopened index')
    archive_data = archive_path.read_bytes()
    summary = {'schema': 'eris-image-fitting-evidence-v1', 'base': BASE, 'compiled_source': source_row, 'live_source': live_row,
               'published_bindings': published, 'archive': archive_path.name, 'archive_bytes': len(archive_data),
               'archive_sha256': digest(archive_data), 'archive_members': len(members), 'checks': checks,
               'reftests': report_counts, 'reviews': selection['reviews'], 'selection': binding(Path(sys.argv[1])),
               'scope': 'Focused loaded-image fitting and positioning evidence; no global conformance, security, GPU-window or performance claim.'}
    with (OUT / (STEM + '.json')).open('xb') as stream:
        stream.write(encoded(summary))
    print(json.dumps({'archive_bytes': len(archive_data), 'archive_sha256': digest(archive_data), 'archive_members': len(members)}))


if __name__ == '__main__':
    main()
