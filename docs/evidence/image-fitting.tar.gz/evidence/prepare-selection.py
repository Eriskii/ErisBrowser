from pathlib import Path
import hashlib,json,re,subprocess
P=Path(__file__).resolve().parent;W=P/'worktree';Q=Path('/tmp/eris-object-fit-preparation-1');N=Path('/tmp/eris-native-image-accounting-1')
def binding(p):
 p=Path(p);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def write(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
checks={}
source_labels={
 'baseline-reftests-1':N/'compiled-source-2.json','baseline-combined-reftest-1':N/'compiled-source-2.json',
 'focused-objects-1':P/'compiled-source-1.json',
 'full-native-1':P/'compiled-source-2.json','date-host-isolated-1':P/'compiled-source-2.json',
 'full-native-2':P/'compiled-source-2.json','clippy-198-1':P/'compiled-source-2.json','full-default-198-1':P/'compiled-source-2.json',
 'candidate-build-1':P/'compiled-source-3.json','candidate-strip-1':P/'compiled-source-3.json','candidate-reftests-1':P/'compiled-source-3.json','clippy-msrv-1':P/'compiled-source-3.json',
 'candidate-reftests-2':P/'compiled-source-4.json','format-check-198-1':P/'compiled-source-4.json'}
for name,source in source_labels.items():
 rp=P/'validation'/f'{name}.json';receipt=json.loads(rp.read_text());lp=rp.parent/receipt['log'];rows=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',lp.read_text(),re.M)
 checks[name]={'receipt':binding(rp),'log':binding(lp),'argv':receipt['command'],'exit':receipt['exit'],'source':binding(source),'rust_results':[sum(int(a) for a,_ in rows),sum(int(b) for _,b in rows),len(rows)] if rows else None}
reports={}
for name,rp,mp,binary,check,counts in [
 ('baseline-1',P/'root-reftests/baseline-1/report.json',P/'root-reftests/only-new.json',N/'candidate-binary.json','baseline-reftests-1',[0,4,4]),
 ('baseline-combined-1',P/'root-reftests/baseline-combined-1/report.json',P/'root-reftests/only-combined.json',N/'candidate-binary.json','baseline-combined-reftest-1',[0,1,1]),
 ('candidate-1',P/'reftests-candidate-1/report.json',W/'tests/reftests/manifest.json',P/'candidate-binary.json','candidate-reftests-1',[61,1,62]),
 ('candidate-2',P/'reftests-candidate-2/report.json',W/'tests/reftests/manifest.json',P/'candidate-binary.json','candidate-reftests-2',[62,0,62])]:
 reports[name]={'report':binding(rp),'manifest':binding(mp),'binary_record':binding(binary),'check':check,'counts':counts}
reviews={
 'css':Q/'css/script-source-review-3.json','layout':Q/'layout/script-source-review.json','browser':Q/'browser/layout-review.json',
 'source_fixtures':P/'root-sources/layout-review.json','original_references':P/'root-reftests/layout-review.json',
 'reference_correction':P/'root-reftests/reference-expression-layout-review.json','diagnosis':P/'root-reftests/layout-diagnosis-1.json',
 'formatted_source':P/'compiled-source-2-layout-review.json','documentation':Q/'docs/layout-review.json','publisher':P/'package-preparation/layout-review.json'}
evidence=[P/x for x in ['prepare-selection.py','run-tool.py','run-check.py','verify-staged.py','base-publication.json','parent-publication.json','parent-ci.json','docs-integration-1.json','fixture-integration-1.json','source-integration-1.json','css-integration-2.json','css-integration-3.json','input-inventory-refinement.json','root-sources/source-ready.json','root-reftests/source-ready-2.json','package-preparation/source-ready-3.json','candidate-unstripped.json']]
evidence += [Q/x for x in ['script-plan.json','script-plan-level4-addendum.json','css/source-ready-3.json','layout/source-ready.json','browser/source-ready.json','docs/source-ready-2.json']]
# Explicit prior failing SVG oracle and the remaining original baseline inputs.
for name in ['object-fit-modes','object-position-physical','object-fit-content-box','object-fit-scopes','object-fit-combined-scale-down']:
 for suffix in ['.html','-ref.html']:
  evidence.append(P/'root-reftests/draft/tests/reftests'/(name+suffix))
for name in ['object-fit-large.png','object-fit-small.png']:
 evidence.append(P/'root-reftests/draft/tests/reftests'/name)
# Keep all PNGs from each failed new reference, and both candidate combined runs.
for folder,names in [('root-reftests/baseline-1',['object-fit-modes','object-position-physical','object-fit-content-box','object-fit-scopes']),('root-reftests/baseline-combined-1',['object-fit-combined-scale-down']),('reftests-candidate-1',['object-fit-combined-scale-down']),('reftests-candidate-2',['object-fit-combined-scale-down'])]:
 for name in names:
  for suffix in ['.png','-ref.png','-diff.png']:
   p=P/folder/(name+suffix)
   if p.is_file():evidence.append(p)
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only','-z'],cwd=W).decode().split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=W).decode().split('\0'));changed.discard('')
selection={'source':binding(P/'compiled-source-3.json'),'live_source':binding(P/'compiled-source-4.json'),'published':{n:binding(W/n) for n in sorted(changed)},'reviews':{n:binding(p) for n,p in reviews.items()},'checks':checks,'final_checks':{'native':'full-native-2','default':'full-default-198-1','clippy_msrv':'clippy-msrv-1','clippy_198':'clippy-198-1','format':'format-check-198-1','build':'candidate-build-1','reftests':'candidate-reftests-2'},'reports':reports,'final_report':'candidate-2','evidence':[binding(p) for p in evidence]}
write(P/'package-selection.json',selection)
print(json.dumps({'published':len(changed),'checks':len(checks),'reviews':len(reviews),'evidence_files':len(evidence)}))
