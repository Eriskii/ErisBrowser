//! Prospective TEST-ONLY layout mirror. No Promise.all operation is implemented.
//! Root may register this file as a cfg(test) child of crate::script::promises.
//! All existing payload/Runtime field types come from the actual parent module.
#![allow(dead_code)] // Inert field-only mirrors are intentionally never constructed.
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy)]
struct AllCaptureId(usize);
enum AllCapture {
    Group {
        resolve: Value,
        values: Arena<Value>,
        remaining: usize,
        input_done: bool,
    },
    Element {
        group: AllCaptureId,
        index: usize,
        called: bool,
    },
}
struct ReadyAllValues {
    resolve: Value,
    values: Vec<Value>,
}
struct AllIterator {
    iterator: Value,
    next: Value,
    done: bool,
}
#[derive(Clone, Copy)]
enum ProposedCallbackKind {
    Resolve(GateId),
    Reject(GateId),
    CapabilityExecutor(CaptureId),
    ThenFinally(FinallyCaptureId),
    CatchFinally(FinallyCaptureId),
    ReturnValue(FinallyCaptureId),
    ThrowReason(FinallyCaptureId),
    AllResolve(AllCaptureId),
}
struct ProposedCallbackRecord {
    object_id: usize,
    kind: ProposedCallbackKind,
}
struct ProposedState {
    promises: Arena<PromiseRecord>,
    gates: Arena<ResolveGate>,
    callbacks: Arena<ProposedCallbackRecord>,
    captures: Arena<CapabilityCapture>,
    jobs: Arena<Option<PromiseJob>>,
    finally_captures: Arena<FinallyCapture>,
    all_captures: Arena<AllCapture>,
    intrinsics: Option<Intrinsics>,
}

// Exact current Runtime field roster with only promises::State replaced above.
struct ProposedRuntime {
    date_host: DateHost,
    environments: Vec<Environment>,
    functions: Vec<Function>,
    arrays: Vec<Vec<Value>>,
    array_properties: Vec<usize>,
    array_holes: Vec<BTreeSet<usize>>,
    array_lengths: Vec<array_properties::ArrayLength>,
    active_array_joins: Vec<Value>,
    array_prototype: Option<usize>,
    objects: Vec<ScriptObject>,
    prototypes: BTreeMap<&'static str, usize>,
    native_properties: BTreeMap<String, usize>,
    symbols: symbols::State,
    iterators: iterators::State,
    array_buffers: array_buffer::State,
    data_views: data_view::State,
    typed_arrays: typed_array::State,
    dom_prototypes: dom_prototypes::State,
    microtasks: microtasks::State,
    promises: ProposedState,
    #[cfg(feature = "test262-host")]
    test262_session: Option<test262_host::Session>,
    host_symbol_objects: BTreeMap<property_keys::HostKey, usize>,
    function_prototype: usize,
    events: Vec<EventState>,
    abort_signals: Vec<AbortState>,
    listeners: Vec<EventListener>,
    event_listeners: BTreeMap<(EventTarget, JsString), Vec<usize>>,
    event_handlers: BTreeMap<(EventTarget, JsString), EventHandler>,
    readiness_fired: bool,
    started: std::time::Instant,
    steps: usize,
    allocated: usize,
    calls: usize,
    // Diagnostic active-expression count; iterative JavaScript uses frame storage.
    eval_depth: usize,
    frames: Vec<machine::Frame>,
    json_depth: usize,
    stack_units: usize,
    pub console: Vec<String>,
    pub last_default_prevented: bool,
    tracked_global_keys: [JsString; 5],
    next_global_order: u64,
    global_non_scalar: BTreeMap<JsString, window::GlobalProperty>,
}

#[test]
fn promise_all_prospective_layout_uses_actual_parent_types() {
    macro_rules! row {
        ($name:literal, $ty:ty) => {
            eprintln!("PROMISE_ALL_PROSPECTIVE {} bytes={} align={}",
                $name, size_of::<$ty>(), align_of::<$ty>());
        };
    }
    row!("Value", Value);
    row!("AllCaptureId", AllCaptureId);
    row!("AllCapture", AllCapture);
    row!("AllCaptureArena", Arena<AllCapture>);
    row!("ReadyAllValues", ReadyAllValues);
    row!("AllIterator", AllIterator);
    row!("CallbackKindCurrent", CallbackKind);
    row!("CallbackKindProposed", ProposedCallbackKind);
    row!("CallbackRecordCurrent", CallbackRecord);
    row!("CallbackRecordProposed", ProposedCallbackRecord);
    row!("PromiseJob", PromiseJob);
    row!("OptionPromiseJob", Option<PromiseJob>);
    row!("QueueJob", QueueJob);
    row!("StateCurrent", State);
    row!("StateProposed", ProposedState);
    row!("RuntimeCurrent", Runtime);
    row!("RuntimeProposed", ProposedRuntime);
    row!("ScriptObject", ScriptObject);
    row!("ArrayValuesRow", Vec<Value>);
    row!("ArrayPropertiesRow", usize);
    row!("ArrayHolesRow", BTreeSet<usize>);
    row!("ArrayLengthRow", array_properties::ArrayLength);
    row!("AbortSlotOption", Option<AbortSlot>);
    row!("DateOption", Option<f64>);
    row!("PropertyKey", PropertyKey);
    row!("Property", Property);
    row!("Native", Native);
    assert_eq!(size_of::<ProposedCallbackKind>(), size_of::<CallbackKind>());
    assert_eq!(align_of::<ProposedCallbackKind>(), align_of::<CallbackKind>());
    assert_eq!(size_of::<ProposedCallbackRecord>(), size_of::<CallbackRecord>());
    assert_eq!(align_of::<ProposedCallbackRecord>(), align_of::<CallbackRecord>());
    eprintln!("PROMISE_ALL_PROSPECTIVE movement_all={} movement_callback={} movement_object={} state_delta={} runtime_delta={} runtime_over_2048={}",
        size_of::<AllCapture>().div_ceil(size_of::<Value>()),
        size_of::<ProposedCallbackRecord>().div_ceil(size_of::<Value>()),
        size_of::<ScriptObject>().div_ceil(size_of::<Value>()),
        size_of::<ProposedState>().saturating_sub(size_of::<State>()),
        size_of::<ProposedRuntime>().saturating_sub(size_of::<Runtime>()),
        size_of::<ProposedRuntime>().saturating_sub(2048));
}
