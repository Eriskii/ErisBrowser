Promise.all old-test migration hold, based on published Node-key prerequisite 8e3db775b176b7fa9cf0aef82c51f8eda6af7f6c. All thirteen before files also exactly match AP formatted source1. The retained selection.json was drafted before the publication notification; ledger.json and rebase-review.json record the now-verified publication join.

No production file, new quota module, cap or isolated host/Node operation tariff is changed here. The method contributes107 work and the seventh arena guard1, so raw bootstrap becomes99975 of100000, leaving25. One additional metadata bag and the32-byte arena header are accounted separately. Typed-array aggregate size_of<State> already includes that header; its new term adds only method+object-slot cost.

All13 patches are explicit test migrations. The two historical State groups remain useful and now expect256. The historical Promise constructor own-name roster gains all. Pointer-sharing metadata checks append the all bag at749, preserving every earlier private ID. New eight-invalid-state control retains the same preallocation refusal assertions.

The feature-enabled host cold-growth fixture now starts at750 objects. Its formula and fixed405 enable charge stay exact; the doubled target becomes1500. The final-enabled Runtime mirror1872 still fits the existing2048 envelope. These are source/mirror predictions, not observed implementation outcomes.

All24 public semantic literals and two integration fixtures are separate held controls. Their parent observations do not authorize changing any literal here. Layout owns the new private controls and actual-layout group. Root owns integration, formatting, compilation, baseline/final execution and publication.
