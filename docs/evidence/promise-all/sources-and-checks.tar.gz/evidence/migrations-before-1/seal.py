from pathlib import Path
import json,hashlib,difflib,re
D=Path('/tmp/eris-promise-all-1/migrations-before-1')
AP=Path('/tmp/eris-node-accessor-keys-1/worktree')
AQ=Path('/tmp/eris-promise-all-1/worktree')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def out(name,v):
 p=D/name;assert not p.exists(),p;p.write_text(json.dumps(v,indent=2)+'\n');return bind(p)
sel=json.loads((D/'selection.json').read_text())
parent=Path('/tmp/eris-promise-all-1/parent-after-node-keys.json')
pi=json.loads(parent.read_text())
assert pi['base']=='8e3db775b176b7fa9cf0aef82c51f8eda6af7f6c'
api=json.loads(Path(sel['base_inventory']['path']).read_text())
rows=[]
for row in sel['paths']:
 p=row['path'];before=(D/'before'/p).read_bytes();raw=(D/'raw'/p).read_bytes()
 for key in ['before','raw','diff']:assert bind(row[key]['path'])==row[key],(p,key)
 h=hashlib.sha256(before).hexdigest()
 assert h==api['source_sha256'][p]==pi['source_sha256'][p]
 assert (AP/p).read_bytes()==before==(AQ/p).read_bytes(),p
 expected=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+p,tofile='b/'+p)).encode()
 assert expected==Path(row['diff']['path']).read_bytes(),p
 # Apply each literal operation and its exact inverse, including simultaneous maps.
 text=before.decode()
 for edit in row['ordered_edits']:
  if 'simultaneous_numeric_mapping' in edit:
   mapping=edit['simultaneous_numeric_mapping'];pat=r'\b('+ '|'.join(map(re.escape,mapping)) +r')\b'
   for a,n in edit['counts'].items():assert len(re.findall(r'\b'+re.escape(a)+r'\b',text))==n
   text=re.sub(pat,lambda m:mapping[m[0]],text)
  else:
   assert text.count(edit['before'])==edit['count'],(p,edit)
   text=text.replace(edit['before'],edit['after'])
 assert text.encode()==raw,p
 for edit in reversed(row['ordered_edits']):
  if 'simultaneous_numeric_mapping' in edit:
   mapping={v:k for k,v in edit['simultaneous_numeric_mapping'].items()};pat=r'\b('+ '|'.join(map(re.escape,mapping)) +r')\b'
   text=re.sub(pat,lambda m:mapping[m[0]],text)
  else:text=text.replace(edit['after'],edit['before'])
 assert text.encode()==before,p
 rows.append({'path':p,'before_sha256':h,'raw_sha256':hashlib.sha256(raw).hexdigest(),'literal_forward_and_inverse':True,'exact_unified_diff':True,'ap_formatted_and_published_aq_parent_match':True})
# Typed equations derived from held source/mirror rather than running Rust.
A=Dv=K=16;N=56;P=56;O=216;V=24;U=8
Bpp=16*(K+P)+32*U+64
method_heap=A+Dv+3*K+Bpp+N+1011
assert (Bpp,method_heap,method_heap+O+32)==(1472,2619,2867)
assert 99867+107+1==99975 and 100000-99975==25
assert (1154+108,1116+108,331+1116+108)==(1262,1224,1555)
assert (8+1500*9,32+1502*216)==(13508,324464)
assert (8+1498*9,32+1500*216)==(13490,324032)
ledger={
 'status':'frozen_source_derived_startup_migrations_before_production',
 'selected_parent':{'commit':pi['base'],'inventory':bind(parent),'ap_source1':sel['base_inventory'],'equivalence':'All13 before files match AP formatted source1, published parent inventory and current AQ worktree exactly. AP source1 base720127cb is ancestor provenance; published prerequisite parent is8e3db775.'},
 'inputs':[bind('/tmp/eris-promise-all-plan-1/startup-review.json'),sel['root_selected_layout'],sel['mirror_results'],bind(AP/'src/script/promises/install.rs'),bind(AP/'src/script/dom_prototypes.rs'),bind(AP/'src/script/test262_host.rs'),bind(AP/'src/script/node_data.rs')],
 'work':{'method_rows':{'bag':9,'text_all':14,'length_name_properties':24,'native_name':19,'four_clones':4,'pool_release':1,'constructor_all_property':34,'shifted_species_property':2},'method_sum':107,'new_arena_guard':1,'total_increment':108,'standalone':[1154,1262],'shared':[1116,1224],'producer_unchanged':331,'combined':[1447,1555],'raw':[99867,99975],'remaining':[133,25],'raw_exact_and_short':[99975,99974],'standalone_exact_and_short':[1262,1261],'shared_exact_and_short':[1224,1223],'combined_exact_and_short':[1555,1554],'fixed_standalone':[19,21],'fixed_shared':[17,19],'body_clone_prepayment':[31,35],'limit_unchanged':100000},
 'heap':{'symbols':{'A':'size_of<Option<AbortSlot>>','D':'size_of<Option<f64>>','K':'size_of<PropertyKey>','N':'size_of<Native>','O':'size_of<ScriptObject>','Bpp':'16*(K+size_of<Property>)+32*size_of<usize>+64','Bsb':'16*(size_of<String>+size_of<Binding>)+32*size_of<usize>+64'},'method_only':'A+D+3K+Bpp+N+1011','method_mirror_bytes':method_heap,'standalone_new':'9A+9D+26K+9Bpp+8N+4Bsb+9356','shared_new':'9A+9D+26K+9Bpp+8N+4Bsb+9188','separate_new_bootstrap_slot':'O','separate_new_state_arena':32,'full_mirror_increment':2867,'typed_array_additive_term':'O+A+D+3K+Bpp+N+1011; existing size_of<promises::State> accounts arena32 once','runtime_envelope':'default fixed2048 unchanged; feature host max(2048,size_of<Runtime>) still2048 for proposed1872. Do not add another Runtime or inline-State allocation.','limit_unchanged':8388608,'scope':'Mirror-derived numerical evaluation only; actual new types/allocation behavior unexecuted.'},
 'counts':{'metadata_objects':[749,750],'promise_installer_bags':[8,9],'global_unchanged':212,'native_registry_unchanged':299,'prototype_registry_unchanged':25,'private_arenas':[6,7],'invalid_states':[7,8],'invalid_state_cases':[28,32],'standalone_replay':{'start':750,'additional_spare':9,'success':759},'shared_replay':{'start':750,'additional_spare':10,'after_producer':751,'success':760},'physical_capacity_qualification':'Existing exact bootstrap capacity witnesses are preserved as count+1. Replay preparations assert only at-least capacity; no allocator rounding guarantee is added.'},
 'prefix_controls':{'standalone':[[21,0],[40,0],[41,88],[56,88],[57,168]],'shared':[[19,0],[40,0],[41,92]],'meaning':'Each original prefix work grows2 for one new pool-handle release and one new arena guard. Guard stays before any standalone key allocation; byte literals unchanged.'},
 'metadata_identity':{'new_function_bag':749,'existing_bags_unchanged':[740,741,742,743,744,745,746,747,748],'constructor_strings':'length,name,prototype,resolve,reject,all','constructor_value_count':[6,7],'prototype_strings_unchanged':'constructor,then,catch,finally','metadata_rows':'New all name/length1 checks; all earlier descriptor, mutability, pointer-sharing and SQV7 assertions unchanged.'},
 'host_cold_growth':{'old_input':[749,749],'new_input':[750,750],'target':[1498,1500],'work_formula':'8+target*ceil(size_of<ScriptObject>/size_of<Value>)','bytes_formula':'32+(target+2)*size_of<ScriptObject>','work':[13490,13508],'bytes':[324032,324464],'full_enable_work':[13895,13913],'spare_input':[750,752],'spare_output':'None,0,2*sizeof(ScriptObject)','unchanged_fixed_enable':405,'qualification':'Only fixture starting object counts change. No host operation fee, observer authority, policy, reporting or failure ordering changes.'},
 'layout':{'state':[224,256],'default_runtime':[1776,1808],'host_runtime':[1840,1872],'new_all_capture':72,'arena':32,'existing_callback_kind':16,'existing_callback_record':24,'existing_promise_job':128,'existing_queue_job':24,'measurement_status':'Prospective root mirror already observed; final production must independently measure. Existing historical layout groups alter State literal only.'},
 'preserved': ['All AP isolated factory98/104, installer503, original-factory127 work/heap/refusal controls byte-exact except object749->750 assertions.','All old microtask callback/job controls unchanged.','Original four-method nonconstructability/refused4 control retained in promise_semantic_tests; only constructor own-name string changes.','All ordinary bootstrap resets, fatal/refusal expectations and caps remain unchanged.','New private quota/layout/probe modules are owned by Layout and not authored in this migration hold.'],
 'execution':False,'production_edits':False,'new_test_groups':0
}
out('ledger.json',ledger)
out('rebase-review.json',{'status':'clear_source_text_only','rows':rows,'source_inputs':[bind(parent),bind('/tmp/eris-promise-all-1/source-tests-after-prerequisite.json'),sel['base_inventory']],'checked':'13 paths, exact forward+inverse literal edits, exact unified diffs, current AP/AQ and both parent inventory joins. All unchanged file content preserved. No project execution.','raw_test_group_count':sum(len(re.findall(r'^#\[test\]',Path(r['raw']['path']).read_text(),re.M)) for r in sel['paths']),'before_test_group_count':sum(len(re.findall(r'^#\[test\]',Path(r['before']['path']).read_text(),re.M)) for r in sel['paths'])})
notes='''Promise.all old-test migration hold, based on published Node-key prerequisite 8e3db775b176b7fa9cf0aef82c51f8eda6af7f6c. All thirteen before files also exactly match AP formatted source1. The retained selection.json was drafted before the publication notification; ledger.json and rebase-review.json record the now-verified publication join.

No production file, new quota module, cap or isolated host/Node operation tariff is changed here. The method contributes107 work and the seventh arena guard1, so raw bootstrap becomes99975 of100000, leaving25. One additional metadata bag and the32-byte arena header are accounted separately. Typed-array aggregate size_of<State> already includes that header; its new term adds only method+object-slot cost.

All13 patches are explicit test migrations. The two historical State groups remain useful and now expect256. The historical Promise constructor own-name roster gains all. Pointer-sharing metadata checks append the all bag at749, preserving every earlier private ID. New eight-invalid-state control retains the same preallocation refusal assertions.

The feature-enabled host cold-growth fixture now starts at750 objects. Its formula and fixed405 enable charge stay exact; the doubled target becomes1500. The final-enabled Runtime mirror1872 still fits the existing2048 envelope. These are source/mirror predictions, not observed implementation outcomes.

All24 public semantic literals and two integration fixtures are separate held controls. Their parent observations do not authorize changing any literal here. Layout owns the new private controls and actual-layout group. Root owns integration, formatting, compilation, baseline/final execution and publication.
'''
(D/'README.txt').write_text(notes)
allpaths=[D/'selection.json',D/'ledger.json',D/'rebase-review.json',D/'README.txt',D/'seal.py']
for row in sel['paths']:
 allpaths.extend(Path(row[k]['path']) for k in ['before','raw','diff'])
out('source-ready.json',{'schema':'eris-external-test-migration-hold-v1','status':'frozen_before_promise_all_production','parent_commit':pi['base'],'selected_paths': [r['path'] for r in sel['paths']],'path_count':13,'new_test_groups':0,'selected_assertion_changes':'Complete before/raw/diff bindings and reasons in selection; source-derived tariff equations and current published-parent join in ledger/rebase-review.','bindings':[bind(p) for p in allpaths],'production':False,'execution':False,'live_edits':False})
print(json.dumps(bind(D/'source-ready.json')))
