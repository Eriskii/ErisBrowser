import difflib
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = Path('/tmp/eris-promise-all-plan-1/tests-before')
manifest_bytes = (H / 'source-ready.json').read_bytes()
assert hashlib.sha256(manifest_bytes).hexdigest() == '08f1f1d709c26b0db3183975e48abc11089c70680d27cdec8e670cec389e848a'
manifest = json.loads(manifest_bytes)
for item in manifest['files'] + [manifest['oracle_source']]:
    data = Path(item['path']).read_bytes()
    assert len(data) == item['bytes'], item['path']
    assert hashlib.sha256(data).hexdigest() == item['sha256'], item['path']
peer = (H / 'html-review.json').read_bytes()
assert hashlib.sha256(peer).hexdigest() == '4dd813e1b6599fda96a7977d9868af7f90acb86ae4d6e0f71496c5c96dc1b2db'
before = (H / 'before/src/script.rs').read_bytes()
raw = (H / 'raw/src/script.rs').read_bytes()
assert (W / 'src/script.rs').read_bytes() == before
assert raw == before + manifest['registration_only_change'].encode()
module = W / 'src/script/promise_all_semantic_tests.rs'
assert not module.exists()
for rel in manifest['raw_paths']:
    (W / rel).write_bytes((H / 'raw' / rel).read_bytes())
snapshot = json.loads((A / 'parent-source.json').read_text())
for rel in manifest['raw_paths']:
    snapshot['source_sha256'][rel] = hashlib.sha256((W / rel).read_bytes()).hexdigest()
snapshot['scope'] = 'Parent-compatible Promise.all semantic tests, before implementation and before formatting.'
(A / 'source-tests-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
receipt = {'manifest_sha256': hashlib.sha256(manifest_bytes).hexdigest(),
           'peer_sha256': hashlib.sha256(peer).hexdigest(),
           'imported': manifest['raw_paths'], 'inputs': len(snapshot['source_sha256']),
           'production_changed': False}
(A / 'root/import-semantic-tests.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
