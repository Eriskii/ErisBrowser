import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def checked(label):
    path = A / 'validation' / (label + '.json')
    receipt = json.loads(path.read_text())
    assert receipt['exit'] == 0, label
    log = path.parent / receipt['log']
    assert bind(log)['sha256'] == receipt['sha256'], label
    return {'receipt': bind(path), 'log': bind(log), 'command': receipt['command']}, log.read_text()

one = json.loads((A / 'source1.json').read_text())
two = json.loads((A / 'source2.json').read_text())
assert one['source_sha256'].keys() == two['source_sha256'].keys()
changed = [p for p in one['source_sha256'] if one['source_sha256'][p] != two['source_sha256'][p]]
assert changed == ['src/script/promises/all_quota_tests.rs']
assert bind(A / 'root/lint-cleanup-before.rs')['sha256'] == one['source_sha256'][changed[0]]
for relative, digest in two['source_sha256'].items():
    assert bind(W / relative)['sha256'] == digest, relative

def rows(text):
    return [list(map(int, r)) for r in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]

def new_roster(text):
    names = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
    return sorted(n for n in names if n.startswith(('script::promise_all_', 'script::promises::all_')) or n in [
        'promise_all_collects_in_order_and_drains_before_the_next_host_listener',
        'promise_all::confined_promise_all_collects_in_order_and_drains_before_the_next_host_listener'])

results = {}
rosters = []
for label, expected in [('default-full-1', 2945), ('host-vulkan-full-1', 3299)]:
    result, text = checked(label)
    parsed = rows(text)
    assert len(parsed) == 49 and all(r[1:] == [0, 0, 0, 0] for r in parsed)
    assert sum(r[0] for r in parsed) == expected
    roster = new_roster(text)
    assert len(roster) == len(set(roster)) == 50, (label, len(roster))
    rosters.append(roster)
    result.update(source='source1.json', passed=expected, result_rows=49, failed=0, ignored=0, new_groups=roster)
    results[label] = result
assert rosters[0] == rosters[1]
for label, source, expected in [
    ('public-focused-1', 'source1.json', 31),
    ('private-focused-1', 'source1.json', 17),
    ('integration-focused-1', 'source1.json', 2),
    ('private-focused-msrv-2', 'source2.json', 17),
    ('private-focused-host-vulkan-2', 'source2.json', 17),
    ('startup-diagnostic-1', 'source2.json', 1),
]:
    result, text = checked(label)
    parsed = rows(text)
    assert sum(r[0] for r in parsed) == expected and all(r[1:4] == [0, 0, 0] for r in parsed)
    result.update(source=source, passed=expected, failed=0, ignored=0)
    results[label] = result
for label in ['clippy-default-2', 'clippy-host-vulkan-2', 'fmt-check-final-1']:
    result, _ = checked(label)
    result['source'] = 'source2.json'
    results[label] = result
_, text = checked('startup-diagnostic-1')
match = re.search(r'TYPED_ARRAY_BOOTSTRAP remaining=(\d+) allocated=(\d+) objects=(\d+) capacity=(\d+) native=(\d+) prototypes=(\d+) globals=(\d+)', text)
assert match and list(map(int, match.groups())) == [25, 1741555, 750, 750, 299, 25, 212]
validation = {
    'status': 'pass', 'final_source_inventory': bind(A / 'source2.json'),
    'full_suite_source_inventory': bind(A / 'source1.json'),
    'source_transition': {'changed_paths': changed, 'reason': 'Current Clippy requested equivalent short-circuit let-chain in one test setup; assertions, production and fees unchanged.', 'diff': bind(A / 'root/lint-cleanup.patch'), 'peer': bind(A / 'root/lint-cleanup-layout-review.json'), 'validation': 'Both final configurations rerun all17 private groups and strict Clippy; full suites remain attributed to source1.'},
    'results': results,
    'raw_default_startup': dict(zip(['remaining_work', 'accounted_heap', 'objects', 'object_capacity', 'native_registry', 'prototype_registry', 'globals'], map(int, match.groups()))),
    'new_groups': {'public_semantic': 24, 'public_abort': 7, 'private_quota': 16, 'actual_layout': 1, 'page_and_worker': 2, 'total': 50},
    'source_inputs': len(two['source_sha256']),
    'scope': 'Custom Promise.all implementation and resource/behavior/rendering regression coverage. Python tooling and existing upstream corpus unchanged and not rerun. New98-source corpus retrieved but not executed. No new GPU-device, production-security or Chromium performance result.',
}
(A / 'root/final-validation.json').write_text(json.dumps(validation, indent=2) + '\n')
print(json.dumps({'status': 'pass', 'source_inputs': validation['source_inputs'], 'full_totals': [2945, 3299], 'new_groups': 50}))
