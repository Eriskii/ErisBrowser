import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'abort-tests-before-1'
data = (H / 'source-ready.json').read_bytes()
assert hashlib.sha256(data).hexdigest() == '4ff1f8e8166da093bd77e1d68918a774e12357e5974cecfa5f2e884235f79c5f'
manifest = json.loads(data)
for row in manifest['bindings']:
    raw = Path(row['path']).read_bytes()
    assert len(raw) == row['bytes'], row['path']
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
before = (H / 'before/src/script.rs').read_bytes()
raw = (H / 'raw/src/script.rs').read_bytes()
assert raw == before + b'#[cfg(test)]\nmod promise_all_abort_tests;\n'
assert (W / 'src/script.rs').read_bytes() == before
assert not (W / 'src/script/promise_all_abort_tests.rs').exists()
snapshot = json.loads((A / 'source-tests-after-prerequisite.json').read_text())
for relative in manifest['selected_paths']:
    raw = (H / 'raw' / relative).read_bytes()
    (W / relative).write_bytes(raw)
    snapshot['source_sha256'][relative] = hashlib.sha256(raw).hexdigest()
snapshot['scope'] = 'All original public Promise.all controls plus additive abort tests, published Node prerequisite, no Promise.all implementation.'
(A / 'source-abort-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'groups_added': 7, 'inputs': len(snapshot['source_sha256']), 'production_changed': False}))
