import difflib
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'integration-tests-before'
raw_manifest = (H / 'source-ready.json').read_bytes()
assert hashlib.sha256(raw_manifest).hexdigest() == '96d956422459ddbfa14b6a86c558080e466d51f6c2ad16e5619871f5516e5c79'
manifest = json.loads(raw_manifest)
for entry in manifest['files'] + [manifest['source_candidate'], manifest['literal_oracles']]:
    data = Path(entry['path']).read_bytes()
    assert len(data) == entry['bytes'], entry['path']
    assert hashlib.sha256(data).hexdigest() == entry['sha256'], entry['path']
assert hashlib.sha256((H / 'html-review.json').read_bytes()).hexdigest() == 'd1677686145b00ce91ab17a8129e04cc7e9662533b07f7e89b134bcc36bf0011'
pending = []
for relative in manifest['raw_paths']:
    target = W / relative
    before_path = H / 'before' / relative
    if before_path.exists():
        before = before_path.read_bytes()
        assert target.read_bytes() == before
    else:
        before = b''
        assert not target.exists()
    raw = (H / 'raw' / relative).read_bytes()
    expected = ''.join(difflib.unified_diff(before.decode().splitlines(True), raw.decode().splitlines(True), fromfile='a/' + relative, tofile='b/' + relative))
    patch = (H / 'diffs' / (relative.replace('/', '__') + '.patch')).read_text()
    assert patch == expected or patch == expected.replace('--- a/' + relative + '\n', '--- /dev/null\n', 1)
    pending.append((target, raw))
for target, raw in pending:
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
snapshot = json.loads((A / 'source-tests-formatted.json').read_text())
for target, _ in pending:
    snapshot['source_sha256'][str(target.relative_to(W))] = hashlib.sha256(target.read_bytes()).hexdigest()
snapshot['scope'] = 'Parent-compatible Promise.all semantic and integration controls; no implementation, before integration rustfmt.'
(A / 'source-integration-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'imported': manifest['raw_paths'], 'inputs': len(snapshot['source_sha256'])}))
