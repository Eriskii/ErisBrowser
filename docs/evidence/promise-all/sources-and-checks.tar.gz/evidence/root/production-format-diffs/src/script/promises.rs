--- raw/src/script/promises.rs
+++ formatted/src/script/promises.rs
@@ -2,14 +2,14 @@
 use super::*;
 use std::mem::size_of;
 
+#[cfg(test)]
+mod all_allocation_probe;
+#[cfg(test)]
+mod all_layout_tests;
+#[cfg(test)]
+mod all_quota_tests;
 mod all_semantics;
 mod all_state;
-#[cfg(test)]
-mod all_allocation_probe;
-#[cfg(test)]
-mod all_layout_tests;
-#[cfg(test)]
-mod all_quota_tests;
 #[cfg(test)]
 use all_semantics::AllIterator;
 mod factories;
