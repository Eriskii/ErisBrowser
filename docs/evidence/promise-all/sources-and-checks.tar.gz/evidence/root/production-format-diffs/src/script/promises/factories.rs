--- raw/src/script/promises/factories.rs
+++ formatted/src/script/promises/factories.rs
@@ -207,12 +207,17 @@
         // Validate the current group and prepare its count before metadata;
         // only scalar IDs/counts survive the reserves below.
         let all_remaining = if let FactoryExtra::AllElement(group, index) = extra {
-            let Some(AllCapture::Group { values, remaining, input_done: false, .. }) =
-                self.promises.all_captures.records.get(group.0)
+            let Some(AllCapture::Group {
+                values,
+                remaining,
+                input_done: false,
+                ..
+            }) = self.promises.all_captures.records.get(group.0)
             else {
                 return Err(invalid());
             };
-            if *remaining == 0 || index >= values.records.len()
+            if *remaining == 0
+                || index >= values.records.len()
                 || values.records.len() > values.admitted_capacity
             {
                 return Err(invalid());
@@ -310,11 +315,14 @@
                 publish_arena(&mut self.promises.finally_captures, extra_plan);
             }
             FactoryExtra::AllElement(group, index) => {
-                self.promises.all_captures.records.push(AllCapture::Element {
-                    group,
-                    index,
-                    called: false,
-                });
+                self.promises
+                    .all_captures
+                    .records
+                    .push(AllCapture::Element {
+                        group,
+                        index,
+                        called: false,
+                    });
                 publish_arena(&mut self.promises.all_captures, extra_plan);
                 let AllCapture::Group { remaining, .. } =
                     &mut self.promises.all_captures.records[group.0]
@@ -402,7 +410,11 @@
         self.observe_microtask_failure(result)
     }
 
-    pub(super) fn new_all_resolve_element(&mut self, group: AllCaptureId, index: usize) -> Result<Value> {
+    pub(super) fn new_all_resolve_element(
+        &mut self,
+        group: AllCaptureId,
+        index: usize,
+    ) -> Result<Value> {
         let element = AllCaptureId(self.promises.all_captures.records.len());
         let result = self
             .build_promise_callbacks(
