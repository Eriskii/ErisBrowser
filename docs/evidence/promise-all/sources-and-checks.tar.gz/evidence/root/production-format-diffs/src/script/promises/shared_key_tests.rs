--- raw/src/script/promises/shared_key_tests.rs
+++ formatted/src/script/promises/shared_key_tests.rs
@@ -323,12 +323,16 @@
             .finally_captures
             .records
             .push(FinallyCapture::Outcome(Value::Undefined)),
-        7 => runtime.promises.all_captures.records.push(AllCapture::Group {
-            resolve: Value::Undefined,
-            values: Arena::default(),
-            remaining: 1,
-            input_done: false,
-        }),
+        7 => runtime
+            .promises
+            .all_captures
+            .records
+            .push(AllCapture::Group {
+                resolve: Value::Undefined,
+                values: Arena::default(),
+                remaining: 1,
+                input_done: false,
+            }),
         _ => unreachable!(),
     }
 }
