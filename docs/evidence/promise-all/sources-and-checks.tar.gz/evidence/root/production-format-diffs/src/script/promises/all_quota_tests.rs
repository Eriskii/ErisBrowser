--- raw/src/script/promises/all_quota_tests.rs
+++ formatted/src/script/promises/all_quota_tests.rs
@@ -10,7 +10,9 @@
     Runtime::native("Object.is", Value::Undefined)
 }
 fn refs(value: &Value) -> usize {
-    let Value::Native(native) = value else { panic!("Native fixture") };
+    let Value::Native(native) = value else {
+        panic!("Native fixture")
+    };
     Rc::strong_count(native)
 }
 fn same(actual: &Value, expected: &Value) {
@@ -32,55 +34,136 @@
     }
 }
 fn warm<T>(arena: &mut Arena<T>, admitted: usize) {
-    arena.records.try_reserve_exact(admitted - arena.records.len()).unwrap();
+    arena
+        .records
+        .try_reserve_exact(admitted - arena.records.len())
+        .unwrap();
     arena.admitted_capacity = admitted;
 }
-fn raw_group(runtime: &mut Runtime, values: Vec<Value>, remaining: usize, done: bool) -> AllCaptureId {
+fn raw_group(
+    runtime: &mut Runtime,
+    values: Vec<Value>,
+    remaining: usize,
+    done: bool,
+) -> AllCaptureId {
     let id = AllCaptureId(runtime.promises.all_captures.records.len());
     let admitted = values.len();
-    runtime.promises.all_captures.records.push(AllCapture::Group {
-        resolve: handler(), values: Arena { records: values, admitted_capacity: admitted },
-        remaining, input_done: done,
-    });
+    runtime
+        .promises
+        .all_captures
+        .records
+        .push(AllCapture::Group {
+            resolve: handler(),
+            values: Arena {
+                records: values,
+                admitted_capacity: admitted,
+            },
+            remaining,
+            input_done: done,
+        });
     runtime.promises.all_captures.admitted_capacity = runtime.promises.all_captures.records.len();
     id
 }
-fn raw_element(runtime: &mut Runtime, group: AllCaptureId, index: usize, called: bool) -> AllCaptureId {
+fn raw_element(
+    runtime: &mut Runtime,
+    group: AllCaptureId,
+    index: usize,
+    called: bool,
+) -> AllCaptureId {
     let id = AllCaptureId(runtime.promises.all_captures.records.len());
-    runtime.promises.all_captures.records.push(AllCapture::Element { group, index, called });
+    runtime
+        .promises
+        .all_captures
+        .records
+        .push(AllCapture::Element {
+            group,
+            index,
+            called,
+        });
     runtime.promises.all_captures.admitted_capacity = runtime.promises.all_captures.records.len();
     id
 }
-fn group(runtime: &Runtime, id: AllCaptureId, expected: &[Value], remaining: usize, done: bool, admitted: usize) {
-    let AllCapture::Group { values, remaining: actual, input_done, .. } =
-        &runtime.promises.all_captures.records[id.0] else { panic!("Group") };
-    assert_eq!((*actual, *input_done, values.admitted_capacity), (remaining, done, admitted));
+fn group(
+    runtime: &Runtime,
+    id: AllCaptureId,
+    expected: &[Value],
+    remaining: usize,
+    done: bool,
+    admitted: usize,
+) {
+    let AllCapture::Group {
+        values,
+        remaining: actual,
+        input_done,
+        ..
+    } = &runtime.promises.all_captures.records[id.0]
+    else {
+        panic!("Group")
+    };
+    assert_eq!(
+        (*actual, *input_done, values.admitted_capacity),
+        (remaining, done, admitted)
+    );
     assert_eq!(values.records.len(), expected.len());
-    for (a, b) in values.records.iter().zip(expected) { same(a, b); }
-}
-fn element(runtime: &Runtime, id: AllCaptureId, expected_group: AllCaptureId, expected_index: usize, expected_called: bool) {
-    let AllCapture::Element { group, index, called } = &runtime.promises.all_captures.records[id.0]
-        else { panic!("Element") };
-    assert_eq!((group.0, *index, *called), (expected_group.0, expected_index, expected_called));
+    for (a, b) in values.records.iter().zip(expected) {
+        same(a, b);
+    }
+}
+fn element(
+    runtime: &Runtime,
+    id: AllCaptureId,
+    expected_group: AllCaptureId,
+    expected_index: usize,
+    expected_called: bool,
+) {
+    let AllCapture::Element {
+        group,
+        index,
+        called,
+    } = &runtime.promises.all_captures.records[id.0]
+    else {
+        panic!("Element")
+    };
+    assert_eq!(
+        (group.0, *index, *called),
+        (expected_group.0, expected_index, expected_called)
+    );
 }
 fn metadata_bytes() -> usize {
-    let leaf = 16 * (size_of::<PropertyKey>() + size_of::<Property>()) + 32 * size_of::<usize>() + 64;
-    904 + size_of::<Option<AbortSlot>>() + size_of::<Option<f64>>()
-        + 2 * size_of::<PropertyKey>() + leaf + size_of::<Native>()
+    let leaf =
+        16 * (size_of::<PropertyKey>() + size_of::<Property>()) + 32 * size_of::<usize>() + 64;
+    904 + size_of::<Option<AbortSlot>>()
+        + size_of::<Option<f64>>()
+        + 2 * size_of::<PropertyKey>()
+        + leaf
+        + size_of::<Native>()
 }
 fn metadata(runtime: &Runtime, value: &Value) -> usize {
-    let Value::Native(native) = value else { panic!("Native callback") };
+    let Value::Native(native) = value else {
+        panic!("Native callback")
+    };
     let id = native.properties.unwrap().get();
     assert_eq!(native.name, "Promise.callback");
     assert_eq!(native.receiver, Value::Object(id));
     let bag = &runtime.objects[id];
-    assert_eq!(bag.prototype, Some(Value::Function(runtime.function_prototype)));
-    assert_eq!(bag.order, [PropertyKey::from("length"), PropertyKey::from("name")]);
+    assert_eq!(
+        bag.prototype,
+        Some(Value::Function(runtime.function_prototype))
+    );
+    assert_eq!(
+        bag.order,
+        [PropertyKey::from("length"), PropertyKey::from("name")]
+    );
     assert_eq!(bag.values.len(), 2);
-    for (key, expected) in [("length", Value::Number(1.0)), ("name", Value::String("".into()))] {
+    for (key, expected) in [
+        ("length", Value::Number(1.0)),
+        ("name", Value::String("".into())),
+    ] {
         let property = &bag.values[&PropertyKey::from(key)];
         assert!(!property.enumerable && property.configurable);
-        let PropertyValue::Data { value, writable } = &property.value else { panic!("data") };
+        let PropertyValue::Data { value, writable } = &property.value else {
+            panic!("data")
+        };
         assert!(!writable);
         assert_eq!(value, &expected);
     }
@@ -107,12 +190,18 @@
     (8 + 2 * len * movement, 32 + target * size_of::<T>())
 }
 fn row_bytes() -> usize {
-    size_of::<Vec<Value>>() + size_of::<usize>() + size_of::<BTreeSet<usize>>()
+    size_of::<Vec<Value>>()
+        + size_of::<usize>()
+        + size_of::<BTreeSet<usize>>()
         + size_of::<array_properties::ArrayLength>()
 }
 fn array_heap(n: usize) -> usize {
-    32 + n * size_of::<Value>() + size_of::<ScriptObject>() + row_bytes()
-        + 72 + size_of::<Option<AbortSlot>>() + size_of::<Option<f64>>()
+    32 + n * size_of::<Value>()
+        + size_of::<ScriptObject>()
+        + row_bytes()
+        + 72
+        + size_of::<Option<AbortSlot>>()
+        + size_of::<Option<f64>>()
 }
 fn array_fixture() -> Runtime {
     let mut runtime = Runtime::try_new().unwrap();
@@ -124,20 +213,33 @@
     runtime
 }
 fn array_lengths(runtime: &Runtime) -> [usize; 5] {
-    [runtime.objects.len(), runtime.arrays.len(), runtime.array_properties.len(),
-        runtime.array_holes.len(), runtime.array_lengths.len()]
+    [
+        runtime.objects.len(),
+        runtime.arrays.len(),
+        runtime.array_properties.len(),
+        runtime.array_holes.len(),
+        runtime.array_lengths.len(),
+    ]
 }
 
 #[test]
 fn all_group18_or26_admits_owned_resolve_only_after_work_heap_and_reserve() {
     for cold in [false, true] {
         let total = if cold { 26 } else { 18 };
-        let bytes = if cold { 32 + 8 * size_of::<AllCapture>() } else { 0 };
+        let bytes = if cold {
+            32 + 8 * size_of::<AllCapture>()
+        } else {
+            0
+        };
         let mut cuts = vec![(total, bytes, true), (total - 1, bytes, false)];
-        if cold { cuts.push((total, bytes - 1, false)); }
+        if cold {
+            cuts.push((total, bytes - 1, false));
+        }
         for (work, heap, success) in cuts {
             let mut runtime = Runtime::try_new().unwrap();
-            if !cold { warm(&mut runtime.promises.all_captures, 8); }
+            if !cold {
+                warm(&mut runtime.promises.all_captures, 8);
+            }
             let resolve = handler();
             let old_objects = runtime.objects.len();
             reset(&mut runtime, work, heap);
@@ -149,8 +251,12 @@
                 let id = result.unwrap();
                 assert_eq!(id.0, 0);
                 group(&runtime, id, &[], 1, false, 0);
-                let AllCapture::Group { resolve: retained, .. } = &runtime.promises.all_captures.records[0]
-                    else { panic!("Group") };
+                let AllCapture::Group {
+                    resolve: retained, ..
+                } = &runtime.promises.all_captures.records[0]
+                else {
+                    panic!("Group")
+                };
                 assert_eq!(retained, &resolve);
                 assert_eq!(refs(&resolve), 2);
                 assert_eq!(runtime.promises.all_captures.admitted_capacity, 8);
@@ -160,8 +266,18 @@
                 resource(result);
                 assert_eq!(refs(&resolve), 1);
                 assert!(runtime.promises.all_captures.records.is_empty());
-                assert_eq!(runtime.promises.all_captures.admitted_capacity, if cold { 0 } else { 8 });
-                assert_eq!(runtime.allocated, if work < total { MAX_HEAP - heap } else { MAX_HEAP + 1 });
+                assert_eq!(
+                    runtime.promises.all_captures.admitted_capacity,
+                    if cold { 0 } else { 8 }
+                );
+                assert_eq!(
+                    runtime.allocated,
+                    if work < total {
+                        MAX_HEAP - heap
+                    } else {
+                        MAX_HEAP + 1
+                    }
+                );
                 assert!(runtime.microtasks_suspended());
             }
         }
@@ -172,19 +288,45 @@
 fn all_group_growth_uses_typed_movement_even_with_physical_spare() {
     let total = 18 + 8 + 16 * size_of::<AllCapture>().div_ceil(size_of::<Value>());
     let bytes = 32 + 16 * size_of::<AllCapture>();
-    for (work, heap, success) in [(total, bytes, true), (total - 1, bytes, false), (total, bytes - 1, false)] {
+    for (work, heap, success) in [
+        (total, bytes, true),
+        (total - 1, bytes, false),
+        (total, bytes - 1, false),
+    ] {
         let mut runtime = Runtime::try_new().unwrap();
-        for _ in 0..8 { raw_group(&mut runtime, Vec::new(), 1, false); }
-        runtime.promises.all_captures.records.try_reserve_exact(32).unwrap();
+        for _ in 0..8 {
+            raw_group(&mut runtime, Vec::new(), 1, false);
+        }
+        runtime
+            .promises
+            .all_captures
+            .records
+            .try_reserve_exact(32)
+            .unwrap();
         assert!(runtime.promises.all_captures.records.capacity() >= 40);
         reset(&mut runtime, work, heap);
         let result = runtime.new_all_group(Value::Null);
         assert_eq!(result.is_ok(), success);
-        for i in 0..8 { group(&runtime, AllCaptureId(i), &[], 1, false, 0); }
-        assert_eq!(runtime.promises.all_captures.records.len(), if success { 9 } else { 8 });
-        assert_eq!(runtime.promises.all_captures.admitted_capacity, if success { 16 } else { 8 });
-        if success { assert_eq!((result.unwrap().0, runtime.steps, runtime.allocated), (8, 0, MAX_HEAP)); }
-        else { resource(result); assert!(runtime.microtasks_suspended()); }
+        for i in 0..8 {
+            group(&runtime, AllCaptureId(i), &[], 1, false, 0);
+        }
+        assert_eq!(
+            runtime.promises.all_captures.records.len(),
+            if success { 9 } else { 8 }
+        );
+        assert_eq!(
+            runtime.promises.all_captures.admitted_capacity,
+            if success { 16 } else { 8 }
+        );
+        if success {
+            assert_eq!(
+                (result.unwrap().0, runtime.steps, runtime.allocated),
+                (8, 0, MAX_HEAP)
+            );
+        } else {
+            resource(result);
+            assert!(runtime.microtasks_suspended());
+        }
     }
     assert!(growth_plan::<AllCapture>(9, 8, 1).is_err());
     assert!(growth_plan::<AllCapture>(usize::MAX, usize::MAX, 1).is_err());
@@ -194,25 +336,49 @@
 #[test]
 fn all_placeholder12_20_or36_preserves_initialized_values_and_logical_admission() {
     for (len, admitted, total, target) in [(0, 8, 12, 8), (0, 0, 20, 8), (8, 8, 36, 16)] {
-        let bytes = if admitted == target { 0 } else { 32 + target * size_of::<Value>() };
+        let bytes = if admitted == target {
+            0
+        } else {
+            32 + target * size_of::<Value>()
+        };
         let mut cuts = vec![(total, bytes, true), (total - 1, bytes, false)];
-        if bytes != 0 { cuts.push((total, bytes - 1, false)); }
+        if bytes != 0 {
+            cuts.push((total, bytes - 1, false));
+        }
         for (work, heap, success) in cuts {
             let mut runtime = Runtime::try_new().unwrap();
             let old = vec![Value::Number(7.0); len];
             let id = raw_group(&mut runtime, old.clone(), 1, false);
             let AllCapture::Group { values, .. } = &mut runtime.promises.all_captures.records[id.0]
-                else { panic!("Group") };
+            else {
+                panic!("Group")
+            };
             values.records.try_reserve_exact(32).unwrap();
             values.admitted_capacity = admitted;
             reset(&mut runtime, work, heap);
             let result = runtime.append_all_placeholder(id);
             assert_eq!(result.is_ok(), success);
             let mut expected = old;
-            if success { expected.push(Value::Undefined); }
-            group(&runtime, id, &expected, 1, false, if success { target } else { admitted });
-            if success { assert_eq!((result.unwrap(), runtime.steps, runtime.allocated), (len, 0, MAX_HEAP)); }
-            else { resource(result); assert!(runtime.microtasks_suspended()); }
+            if success {
+                expected.push(Value::Undefined);
+            }
+            group(
+                &runtime,
+                id,
+                &expected,
+                1,
+                false,
+                if success { target } else { admitted },
+            );
+            if success {
+                assert_eq!(
+                    (result.unwrap(), runtime.steps, runtime.allocated),
+                    (len, 0, MAX_HEAP)
+                );
+            } else {
+                resource(result);
+                assert!(runtime.microtasks_suspended());
+            }
             quiet(&runtime);
         }
     }
@@ -221,11 +387,24 @@
 #[test]
 fn all_element136_or158_keeps_late_metadata_refusal_unpublished() {
     for cold in [false, true] {
-        let grow = if cold { 16 + 2 * size_of::<AllCapture>().div_ceil(size_of::<Value>()) } else { 0 };
+        let grow = if cold {
+            16 + 2 * size_of::<AllCapture>().div_ceil(size_of::<Value>())
+        } else {
+            0
+        };
         let total = 136 + grow;
-        let bytes = metadata_bytes() + size_of::<ScriptObject>()
-            + if cold { 64 + 8 * (size_of::<AllCapture>() + size_of::<CallbackRecord>()) } else { 0 };
-        for (work, heap, success) in [(total, bytes, true), (total - 1, bytes, false), (total, bytes - 1, false)] {
+        let bytes = metadata_bytes()
+            + size_of::<ScriptObject>()
+            + if cold {
+                64 + 8 * (size_of::<AllCapture>() + size_of::<CallbackRecord>())
+            } else {
+                0
+            };
+        for (work, heap, success) in [
+            (total, bytes, true),
+            (total - 1, bytes, false),
+            (total, bytes - 1, false),
+        ] {
             let (mut runtime, id) = factory_fixture(cold);
             let old_objects = runtime.objects.len();
             let old_registry = runtime.native_properties.clone();
@@ -234,7 +413,14 @@
             assert_eq!(result.is_ok(), success);
             assert_eq!(runtime.objects.len(), old_objects + 1);
             assert_eq!(runtime.native_properties, old_registry);
-            group(&runtime, id, &[Value::Undefined], if success { 2 } else { 1 }, false, 1);
+            group(
+                &runtime,
+                id,
+                &[Value::Undefined],
+                if success { 2 } else { 1 },
+                false,
+                1,
+            );
             quiet(&runtime);
             if success {
                 let callback = result.unwrap();
@@ -242,16 +428,38 @@
                 element(&runtime, AllCaptureId(1), id, 0, false);
                 assert_eq!(runtime.promises.callbacks.records.len(), 1);
                 assert_eq!(runtime.promises.callbacks.records[0].object_id, old_objects);
-                assert!(matches!(runtime.promises.callbacks.records[0].kind, CallbackKind::AllResolve(AllCaptureId(1))));
-                assert_eq!((runtime.promises.all_captures.admitted_capacity, runtime.promises.callbacks.admitted_capacity), (8, 8));
+                assert!(matches!(
+                    runtime.promises.callbacks.records[0].kind,
+                    CallbackKind::AllResolve(AllCaptureId(1))
+                ));
+                assert_eq!(
+                    (
+                        runtime.promises.all_captures.admitted_capacity,
+                        runtime.promises.callbacks.admitted_capacity
+                    ),
+                    (8, 8)
+                );
                 assert_eq!((runtime.steps, runtime.allocated), (0, MAX_HEAP));
             } else {
                 resource(result);
                 assert_eq!(runtime.promises.all_captures.records.len(), 1);
                 assert!(runtime.promises.callbacks.records.is_empty());
-                assert_eq!((runtime.promises.all_captures.admitted_capacity, runtime.promises.callbacks.admitted_capacity), if cold { (1, 0) } else { (8, 8) });
+                assert_eq!(
+                    (
+                        runtime.promises.all_captures.admitted_capacity,
+                        runtime.promises.callbacks.admitted_capacity
+                    ),
+                    if cold { (1, 0) } else { (8, 8) }
+                );
                 assert_eq!(runtime.steps, 0);
-                assert_eq!(runtime.allocated, if work < total { MAX_HEAP - size_of::<Native>() - 48 } else { MAX_HEAP + 1 });
+                assert_eq!(
+                    runtime.allocated,
+                    if work < total {
+                        MAX_HEAP - size_of::<Native>() - 48
+                    } else {
+                        MAX_HEAP + 1
+                    }
+                );
                 assert!(runtime.microtasks_suspended());
             }
         }
@@ -266,7 +474,14 @@
         reset(&mut runtime, work, MAX_HEAP);
         resource(runtime.new_all_resolve_element(id, 0));
         assert_eq!(runtime.steps, 0);
-        assert_eq!(runtime.allocated, if work == 35 { size_of::<ScriptObject>() } else { 0 });
+        assert_eq!(
+            runtime.allocated,
+            if work == 35 {
+                size_of::<ScriptObject>()
+            } else {
+                0
+            }
+        );
         assert_eq!(runtime.objects.len(), objects);
         assert_eq!(runtime.promises.all_captures.records.len(), 1);
         assert!(runtime.promises.callbacks.records.is_empty());
@@ -278,11 +493,35 @@
         let mut index = 0;
         match invalid_case {
             0 => requested = AllCaptureId(usize::MAX),
-            1 => runtime.promises.all_captures.records[0] = AllCapture::Element { group: id, index: 0, called: false },
-            2 => if let AllCapture::Group { input_done, .. } = &mut runtime.promises.all_captures.records[0] { *input_done = true; },
+            1 => {
+                runtime.promises.all_captures.records[0] = AllCapture::Element {
+                    group: id,
+                    index: 0,
+                    called: false,
+                }
+            }
+            2 => {
+                if let AllCapture::Group { input_done, .. } =
+                    &mut runtime.promises.all_captures.records[0]
+                {
+                    *input_done = true;
+                }
+            }
             3 => index = 1,
-            4 => if let AllCapture::Group { remaining, .. } = &mut runtime.promises.all_captures.records[0] { *remaining = usize::MAX; },
-            5 => if let AllCapture::Group { remaining, .. } = &mut runtime.promises.all_captures.records[0] { *remaining = 0; },
+            4 => {
+                if let AllCapture::Group { remaining, .. } =
+                    &mut runtime.promises.all_captures.records[0]
+                {
+                    *remaining = usize::MAX;
+                }
+            }
+            5 => {
+                if let AllCapture::Group { remaining, .. } =
+                    &mut runtime.promises.all_captures.records[0]
+                {
+                    *remaining = 0;
+                }
+            }
             _ => unreachable!(),
         }
         let old_objects = runtime.objects.len();
@@ -292,22 +531,42 @@
         assert_eq!(runtime.allocated, 0);
         assert_eq!(runtime.promises.all_captures.records.len(), 1);
         assert!(runtime.promises.callbacks.records.is_empty());
-        assert_eq!((runtime.promises.all_captures.admitted_capacity, runtime.promises.callbacks.admitted_capacity), (8, 8));
+        assert_eq!(
+            (
+                runtime.promises.all_captures.admitted_capacity,
+                runtime.promises.callbacks.admitted_capacity
+            ),
+            (8, 8)
+        );
         assert!(runtime.microtasks_suspended());
     }
 }
 
 #[test]
 fn all_factory_late_reserve_failures_preserve_group_count_and_all_logical_rows() {
-    use all_allocation_probe::{fail_once, ReserveSite};
-    for (failure_index, site) in [ReserveSite::AllCapture, ReserveSite::Callbacks, ReserveSite::Objects].into_iter().enumerate() {
+    use all_allocation_probe::{ReserveSite, fail_once};
+    for (failure_index, site) in [
+        ReserveSite::AllCapture,
+        ReserveSite::Callbacks,
+        ReserveSite::Objects,
+    ]
+    .into_iter()
+    .enumerate()
+    {
         let (mut runtime, id) = factory_fixture(true);
-        for _ in 1..8 { raw_element(&mut runtime, id, 0, true); }
+        for _ in 1..8 {
+            raw_element(&mut runtime, id, 0, true);
+        }
         exact_capacity(&mut runtime.promises.all_captures.records);
         exact_capacity(&mut runtime.objects);
         let old_objects = runtime.objects.len();
-        let AllCapture::Group { resolve: Value::Native(resolve), .. } = &runtime.promises.all_captures.records[0]
-            else { panic!("retained resolve") };
+        let AllCapture::Group {
+            resolve: Value::Native(resolve),
+            ..
+        } = &runtime.promises.all_captures.records[0]
+        else {
+            panic!("retained resolve")
+        };
         let resolve_identity = resolve.clone();
         let (object_work, object_bytes) = full_growth::<ScriptObject>(old_objects);
         let record_work = 8 + 16 * size_of::<AllCapture>().div_ceil(size_of::<Value>());
@@ -321,8 +580,12 @@
         let observation = guard.observation();
         let mut attempts = [0; 7];
         let mut completed = [0; 7];
-        for slot in attempts.iter_mut().take(failure_index + 1) { *slot = 1; }
-        for slot in completed.iter_mut().take(failure_index) { *slot = 1; }
+        for slot in attempts.iter_mut().take(failure_index + 1) {
+            *slot = 1;
+        }
+        for slot in completed.iter_mut().take(failure_index) {
+            *slot = 1;
+        }
         assert_eq!(observation.attempts, attempts);
         assert_eq!(observation.completed, completed);
         assert_eq!((runtime.steps, runtime.allocated), (101, planned_heap));
@@ -332,13 +595,26 @@
         assert!(runtime.promises.callbacks.records.is_empty());
         assert_eq!(runtime.promises.callbacks.admitted_capacity, 0);
         group(&runtime, id, &[Value::Undefined], 1, false, 1);
-        let AllCapture::Group { resolve: Value::Native(resolve), .. } = &runtime.promises.all_captures.records[0]
-            else { panic!("retained resolve") };
+        let AllCapture::Group {
+            resolve: Value::Native(resolve),
+            ..
+        } = &runtime.promises.all_captures.records[0]
+        else {
+            panic!("retained resolve")
+        };
         assert!(Rc::ptr_eq(resolve, &resolve_identity));
         assert_eq!(Rc::strong_count(resolve), 2);
-        for i in 1..8 { element(&runtime, AllCaptureId(i), id, 0, true); }
-        assert_eq!(runtime.promises.all_captures.records.capacity() >= 16, failure_index > 0);
-        assert_eq!(runtime.promises.callbacks.records.capacity() >= 8, failure_index > 1);
+        for i in 1..8 {
+            element(&runtime, AllCaptureId(i), id, 0, true);
+        }
+        assert_eq!(
+            runtime.promises.all_captures.records.capacity() >= 16,
+            failure_index > 0
+        );
+        assert_eq!(
+            runtime.promises.callbacks.records.capacity() >= 8,
+            failure_index > 1
+        );
         assert_eq!(runtime.objects.capacity(), old_objects);
         assert!(runtime.microtasks_suspended());
         quiet(&runtime);
@@ -347,7 +623,7 @@
 
 #[test]
 fn all_reserve_probe_is_fail_once_nested_and_unwind_scoped() {
-    use all_allocation_probe::{before, completed, fail_once, ReserveSite};
+    use all_allocation_probe::{ReserveSite, before, completed, fail_once};
     let outer = fail_once(ReserveSite::Objects);
     before(ReserveSite::AllCapture).unwrap();
     completed(ReserveSite::AllCapture);
@@ -372,7 +648,11 @@
     // Every destination is warm: no actual reserve, no instrumentation event,
     // and the armed failure remains available rather than being consumed.
     let (mut runtime, id) = factory_fixture(false);
-    reset(&mut runtime, 136, metadata_bytes() + size_of::<ScriptObject>());
+    reset(
+        &mut runtime,
+        136,
+        metadata_bytes() + size_of::<ScriptObject>(),
+    );
     let warm_guard = fail_once(ReserveSite::AllCapture);
     runtime.new_all_resolve_element(id, 0).unwrap();
     assert_eq!(warm_guard.observation().attempts, [0; 7]);
@@ -409,10 +689,19 @@
         let callback = raw_element(&mut runtime, AllCaptureId(usize::MAX), usize::MAX, true);
         reset(&mut runtime, work, 0);
         let result = runtime.complete_all_element(callback, &Value::Number(9.0));
-        if work == 12 { assert!(result.unwrap().is_none()); }
-        else { resource(result); }
+        if work == 12 {
+            assert!(result.unwrap().is_none());
+        } else {
+            resource(result);
+        }
         // A duplicate must not access the intentionally invalid/moved group.
-        element(&runtime, callback, AllCaptureId(usize::MAX), usize::MAX, true);
+        element(
+            &runtime,
+            callback,
+            AllCaptureId(usize::MAX),
+            usize::MAX,
+            true,
+        );
         assert_eq!((runtime.steps, runtime.allocated), (0, MAX_HEAP));
     }
 }
@@ -423,18 +712,37 @@
         let total = if duplicate { 22 } else { 38 };
         for work in [total - 1, total] {
             let (mut runtime, id) = factory_fixture(false);
-            let Value::Native(callback) = runtime.new_all_resolve_element(id, 0).unwrap()
-                else { panic!("Native callback") };
+            let Value::Native(callback) = runtime.new_all_resolve_element(id, 0).unwrap() else {
+                panic!("Native callback")
+            };
             if duplicate {
-                if let AllCapture::Element { called, .. } = &mut runtime.promises.all_captures.records[1] { *called = true; }
+                if let AllCapture::Element { called, .. } =
+                    &mut runtime.promises.all_captures.records[1]
+                {
+                    *called = true;
+                }
             }
             let mut document = Document::parse("");
             reset(&mut runtime, work, 0);
             let result = runtime.promise_callback(&callback, &[Value::Number(17.0)], &mut document);
-            if work == total { assert_eq!(result.unwrap(), Value::Undefined); }
-            else { resource(result); }
+            if work == total {
+                assert_eq!(result.unwrap(), Value::Undefined);
+            } else {
+                resource(result);
+            }
             let changed = !duplicate && work == total;
-            group(&runtime, id, &[if changed { Value::Number(17.0) } else { Value::Undefined }], if changed { 1 } else { 2 }, false, 1);
+            group(
+                &runtime,
+                id,
+                &[if changed {
+                    Value::Number(17.0)
+                } else {
+                    Value::Undefined
+                }],
+                if changed { 1 } else { 2 },
+                false,
+                1,
+            );
             element(&runtime, AllCaptureId(1), id, 0, duplicate || changed);
             assert_eq!((runtime.steps, runtime.allocated), (0, MAX_HEAP));
             quiet(&runtime);
@@ -444,7 +752,11 @@
 
 #[test]
 fn all_finish16_consumes_sentinel_once_and_moves_empty_or_completed_values() {
-    for (values, remaining) in [(vec![], 1), (vec![Value::Number(9.0)], 1), (vec![Value::Undefined], 2)] {
+    for (values, remaining) in [
+        (vec![], 1),
+        (vec![Value::Number(9.0)], 1),
+        (vec![Value::Undefined], 2),
+    ] {
         for work in [15, 16] {
             let mut runtime = Runtime::try_new().unwrap();
             let id = raw_group(&mut runtime, values.clone(), remaining, false);
@@ -474,31 +786,64 @@
     values.try_reserve_exact(6).unwrap();
     let pointer = values.as_ptr();
     let id = raw_group(&mut runtime, values, 3, false);
-    if let AllCapture::Group { values, .. } = &mut runtime.promises.all_captures.records[id.0] { values.admitted_capacity = 8; }
+    if let AllCapture::Group { values, .. } = &mut runtime.promises.all_captures.records[id.0] {
+        values.admitted_capacity = 8;
+    }
     let first = raw_element(&mut runtime, id, 0, false);
     let second = raw_element(&mut runtime, id, 1, false);
     let nan = Value::Number(f64::from_bits(0x7ff8_0000_0000_005a));
     let minus_zero = Value::Number(-0.0);
     reset(&mut runtime, 28, 0);
-    assert!(runtime.complete_all_element(second, &minus_zero).unwrap().is_none());
-    group(&runtime, id, &[Value::Undefined, minus_zero.clone()], 2, false, 8);
+    assert!(
+        runtime
+            .complete_all_element(second, &minus_zero)
+            .unwrap()
+            .is_none()
+    );
+    group(
+        &runtime,
+        id,
+        &[Value::Undefined, minus_zero.clone()],
+        2,
+        false,
+        8,
+    );
     reset(&mut runtime, 16, 0);
     assert!(runtime.finish_all_input(id).unwrap().is_none());
-    group(&runtime, id, &[Value::Undefined, minus_zero.clone()], 1, true, 8);
+    group(
+        &runtime,
+        id,
+        &[Value::Undefined, minus_zero.clone()],
+        1,
+        true,
+        8,
+    );
     reset(&mut runtime, 28, 0);
-    let ready = runtime.complete_all_element(first, &nan).unwrap().expect("ready");
+    let ready = runtime
+        .complete_all_element(first, &nan)
+        .unwrap()
+        .expect("ready");
     assert_eq!((runtime.steps, runtime.allocated), (0, MAX_HEAP));
     assert_eq!(ready.values.as_ptr(), pointer);
     same(&ready.values[0], &nan);
     same(&ready.values[1], &minus_zero);
     group(&runtime, id, &[], 0, true, 0);
-    let AllCapture::Group { values, resolve, .. } = &runtime.promises.all_captures.records[id.0]
-        else { panic!("Group") };
+    let AllCapture::Group {
+        values, resolve, ..
+    } = &runtime.promises.all_captures.records[id.0]
+    else {
+        panic!("Group")
+    };
     assert_eq!(values.records.capacity(), 0);
     assert_eq!(resolve, &Value::Undefined);
     for callback in [first, second] {
         reset(&mut runtime, 12, 0);
-        assert!(runtime.complete_all_element(callback, &Value::Number(99.0)).unwrap().is_none());
+        assert!(
+            runtime
+                .complete_all_element(callback, &Value::Number(99.0))
+                .unwrap()
+                .is_none()
+        );
     }
     for operation in 0..3 {
         reset(&mut runtime, 10_000, MAX_HEAP);
@@ -518,29 +863,53 @@
 fn all_array32_owns_dense_data_and_cached_prototype_at_exact_heap_cuts() {
     for n in [0, 2] {
         let bytes = array_heap(n);
-        for (work, heap, success) in [(32, bytes, true), (31, bytes, false), (32, bytes - 1, false)] {
+        for (work, heap, success) in [
+            (32, bytes, true),
+            (31, bytes, false),
+            (32, bytes - 1, false),
+        ] {
             let mut runtime = array_fixture();
             let old = array_lengths(&runtime);
             let intrinsic = runtime.array_prototype.unwrap();
             let poison = Runtime::native("Promise.all.forbidden", Value::Undefined);
-            runtime.environments[0].bindings.get_mut("Array").unwrap().value = poison.clone();
+            runtime.environments[0]
+                .bindings
+                .get_mut("Array")
+                .unwrap()
+                .value = poison.clone();
             let prototype_bag = runtime.array_properties[intrinsic];
-            runtime.objects[prototype_bag].insert_property(PropertyKey::from("0"), Property {
-                value: PropertyValue::Accessor { get: poison.clone(), set: poison },
-                enumerable: true, configurable: true,
-            });
+            runtime.objects[prototype_bag].insert_property(
+                PropertyKey::from("0"),
+                Property {
+                    value: PropertyValue::Accessor {
+                        get: poison.clone(),
+                        set: poison,
+                    },
+                    enumerable: true,
+                    configurable: true,
+                },
+            );
             let value = handler();
-            let values = if n == 0 { vec![] } else { vec![value.clone(), Value::Number(-0.0)] };
+            let values = if n == 0 {
+                vec![]
+            } else {
+                vec![value.clone(), Value::Number(-0.0)]
+            };
             let pointer = values.as_ptr();
             reset(&mut runtime, work, heap);
             let result = runtime.new_all_values_array(values);
             if success {
-                let Value::Array(id) = result.unwrap() else { panic!("Array") };
+                let Value::Array(id) = result.unwrap() else {
+                    panic!("Array")
+                };
                 assert_eq!(id, old[1]);
                 assert_eq!(array_lengths(&runtime), old.map(|length| length + 1));
                 assert_eq!(runtime.arrays[id].as_ptr(), pointer);
                 assert_eq!(runtime.arrays[id].len(), n);
-                if n != 0 { assert_eq!(runtime.arrays[id][0], value); same(&runtime.arrays[id][1], &Value::Number(-0.0)); }
+                if n != 0 {
+                    assert_eq!(runtime.arrays[id][0], value);
+                    same(&runtime.arrays[id][1], &Value::Number(-0.0));
+                }
                 assert!(runtime.array_holes[id].is_empty());
                 assert_eq!(runtime.array_lengths[id].value, n as u32);
                 assert!(runtime.array_lengths[id].writable);
@@ -555,7 +924,10 @@
                 assert_eq!(array_lengths(&runtime), old);
                 assert_eq!(refs(&value), 1);
                 assert!(runtime.microtasks_suspended());
-                assert_eq!(runtime.allocated, if work == 31 { MAX_HEAP } else { MAX_HEAP + 1 });
+                assert_eq!(
+                    runtime.allocated,
+                    if work == 31 { MAX_HEAP } else { MAX_HEAP + 1 }
+                );
             }
             quiet(&runtime);
         }
@@ -564,9 +936,14 @@
 
 #[test]
 fn all_array_five_reserve_failures_leave_parallel_rows_unpublished() {
-    use all_allocation_probe::{fail_once, ReserveSite};
-    let sites = [ReserveSite::Objects, ReserveSite::ArrayValues, ReserveSite::ArrayProperties,
-        ReserveSite::ArrayHoles, ReserveSite::ArrayLengths];
+    use all_allocation_probe::{ReserveSite, fail_once};
+    let sites = [
+        ReserveSite::Objects,
+        ReserveSite::ArrayValues,
+        ReserveSite::ArrayProperties,
+        ReserveSite::ArrayHoles,
+        ReserveSite::ArrayLengths,
+    ];
     for (stage, site) in sites.into_iter().enumerate() {
         let mut runtime = Runtime::try_new().unwrap();
         exact_capacity(&mut runtime.objects);
@@ -576,11 +953,16 @@
         exact_capacity(&mut runtime.array_lengths);
         let old = array_lengths(&runtime);
         assert!(old[1..].iter().all(|len| *len == old[1]));
-        let plans = [full_growth::<ScriptObject>(old[0]), full_growth::<Vec<Value>>(old[1]),
-            full_growth::<usize>(old[2]), full_growth::<BTreeSet<usize>>(old[3]),
-            full_growth::<array_properties::ArrayLength>(old[4])];
+        let plans = [
+            full_growth::<ScriptObject>(old[0]),
+            full_growth::<Vec<Value>>(old[1]),
+            full_growth::<usize>(old[2]),
+            full_growth::<BTreeSet<usize>>(old[3]),
+            full_growth::<array_properties::ArrayLength>(old[4]),
+        ];
         let prefix = 23 + plans.iter().map(|x| x.0).sum::<usize>();
-        let heap_prefix = array_heap(1) - (72 + size_of::<Option<AbortSlot>>() + size_of::<Option<f64>>())
+        let heap_prefix = array_heap(1)
+            - (72 + size_of::<Option<AbortSlot>>() + size_of::<Option<f64>>())
             + plans.iter().map(|x| x.1).sum::<usize>();
         let value = handler();
         reset(&mut runtime, prefix + 9, MAX_HEAP);
@@ -589,14 +971,23 @@
         let observation = guard.observation();
         let mut attempts = [0; 7];
         let mut completed = [0; 7];
-        for slot in attempts.iter_mut().skip(2).take(stage + 1) { *slot = 1; }
-        for slot in completed.iter_mut().skip(2).take(stage) { *slot = 1; }
+        for slot in attempts.iter_mut().skip(2).take(stage + 1) {
+            *slot = 1;
+        }
+        for slot in completed.iter_mut().skip(2).take(stage) {
+            *slot = 1;
+        }
         assert_eq!(observation.attempts, attempts);
         assert_eq!(observation.completed, completed);
         assert_eq!((runtime.steps, runtime.allocated), (9, heap_prefix));
         assert_eq!(array_lengths(&runtime), old);
-        let capacities = [runtime.objects.capacity(), runtime.arrays.capacity(), runtime.array_properties.capacity(),
-            runtime.array_holes.capacity(), runtime.array_lengths.capacity()];
+        let capacities = [
+            runtime.objects.capacity(),
+            runtime.arrays.capacity(),
+            runtime.array_properties.capacity(),
+            runtime.array_holes.capacity(),
+            runtime.array_lengths.capacity(),
+        ];
         for (i, (capacity, length)) in capacities.into_iter().zip(old).enumerate() {
             assert_eq!(capacity > length, i < stage);
         }
@@ -611,7 +1002,9 @@
     for invalid_case in 0..3 {
         let mut runtime = array_fixture();
         match invalid_case {
-            0 => { runtime.array_holes.pop(); },
+            0 => {
+                runtime.array_holes.pop();
+            }
             1 => runtime.array_prototype = None,
             2 => runtime.array_prototype = Some(usize::MAX),
             _ => unreachable!(),
@@ -631,7 +1024,10 @@
     let id = raw_group(&mut runtime, vec![Value::Undefined], 1, true);
     let callback = raw_element(&mut runtime, id, 0, false);
     reset(&mut runtime, 28, 0);
-    let ready = runtime.complete_all_element(callback, &Value::Number(41.0)).unwrap().expect("ready");
+    let ready = runtime
+        .complete_all_element(callback, &Value::Number(41.0))
+        .unwrap()
+        .expect("ready");
     group(&runtime, id, &[], 0, true, 0);
     element(&runtime, callback, id, 0, true);
     let old = array_lengths(&runtime);
@@ -642,7 +1038,12 @@
     group(&runtime, id, &[], 0, true, 0);
     element(&runtime, callback, id, 0, true);
     reset(&mut runtime, 12, MAX_HEAP);
-    assert!(runtime.complete_all_element(callback, &Value::Number(99.0)).unwrap().is_none());
+    assert!(
+        runtime
+            .complete_all_element(callback, &Value::Number(99.0))
+            .unwrap()
+            .is_none()
+    );
     assert!(runtime.microtasks_suspended());
     reset(&mut runtime, 10_000, MAX_HEAP);
     resource(runtime.queue_microtask(&Value::Undefined, &[handler()]));
@@ -658,7 +1059,9 @@
             let other = raw_element(&mut runtime, id, 0, false);
             let requested = if wrong_variant {
                 if operation == 2 { id } else { other }
-            } else { AllCaptureId(usize::MAX) };
+            } else {
+                AllCaptureId(usize::MAX)
+            };
             reset(&mut runtime, 10_000, MAX_HEAP);
             match operation {
                 0 => resource(runtime.append_all_placeholder(requested)),
