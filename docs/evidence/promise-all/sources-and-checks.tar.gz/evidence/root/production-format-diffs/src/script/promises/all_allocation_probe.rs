--- raw/src/script/promises/all_allocation_probe.rs
+++ formatted/src/script/promises/all_allocation_probe.rs
@@ -32,10 +32,12 @@
     previous: Probe,
 }
 pub(super) fn fail_once(site: ReserveSite) -> FaultGuard {
-    let previous = PROBE.with(|cell| cell.replace(Probe {
-        fail: Some(site),
-        observation: Observation::default(),
-    }));
+    let previous = PROBE.with(|cell| {
+        cell.replace(Probe {
+            fail: Some(site),
+            observation: Observation::default(),
+        })
+    });
     FaultGuard { previous }
 }
 impl FaultGuard {
@@ -57,7 +59,13 @@
             state.fail = None;
         }
         cell.set(state);
-        if fail { Err(ScriptError::resource("injected Promise.all reserve refusal")) } else { Ok(()) }
+        if fail {
+            Err(ScriptError::resource(
+                "injected Promise.all reserve refusal",
+            ))
+        } else {
+            Ok(())
+        }
     })
 }
 pub(super) fn completed(site: ReserveSite) {
