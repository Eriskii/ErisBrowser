--- raw/src/script/promises/all_layout_tests.rs
+++ formatted/src/script/promises/all_layout_tests.rs
@@ -9,9 +9,17 @@
     use std::mem::{align_of, size_of};
     macro_rules! row {
         ($name:literal, $ty:ty, $bytes:literal, $align:literal) => {
-            assert_eq!((size_of::<$ty>(), align_of::<$ty>()), ($bytes, $align), $name);
-            println!("PROMISE_ALL_LAYOUT_ACTUAL {} bytes={} align={}",
-                $name, size_of::<$ty>(), align_of::<$ty>());
+            assert_eq!(
+                (size_of::<$ty>(), align_of::<$ty>()),
+                ($bytes, $align),
+                $name
+            );
+            println!(
+                "PROMISE_ALL_LAYOUT_ACTUAL {} bytes={} align={}",
+                $name,
+                size_of::<$ty>(),
+                align_of::<$ty>()
+            );
         };
     }
     row!("Value", Value, 24, 8);
