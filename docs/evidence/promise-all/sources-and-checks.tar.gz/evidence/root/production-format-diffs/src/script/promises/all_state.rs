--- raw/src/script/promises/all_state.rs
+++ formatted/src/script/promises/all_state.rs
@@ -63,8 +63,11 @@
         let result = (|| {
             // Direct lookup, checked index, initialization and eventual release.
             self.work(12)?;
-            let Some(AllCapture::Group { values, input_done: false, .. }) =
-                self.promises.all_captures.records.get(id.0)
+            let Some(AllCapture::Group {
+                values,
+                input_done: false,
+                ..
+            }) = self.promises.all_captures.records.get(id.0)
             else {
                 return Err(invalid());
             };
@@ -78,7 +81,9 @@
                 unreachable!("validated Promise.all group");
             };
             if let Some(target) = plan.target {
-                values.records.try_reserve_exact(target - values.records.len())
+                values
+                    .records
+                    .try_reserve_exact(target - values.records.len())
                     .map_err(|_| ScriptError::resource("Promise.all values allocation failed"))?;
             }
             values.records.push(Value::Undefined);
@@ -97,8 +102,11 @@
     ) -> Result<Option<ReadyAllValues>> {
         let result = (|| {
             self.work(12)?;
-            let Some(AllCapture::Element { group, index, called }) =
-                self.promises.all_captures.records.get(id.0)
+            let Some(AllCapture::Element {
+                group,
+                index,
+                called,
+            }) = self.promises.all_captures.records.get(id.0)
             else {
                 return Err(invalid());
             };
@@ -108,8 +116,12 @@
             }
             let (group, index) = (*group, *index);
             self.work(16)?;
-            let Some(AllCapture::Group { values, remaining, input_done, .. }) =
-                self.promises.all_captures.records.get(group.0)
+            let Some(AllCapture::Group {
+                values,
+                remaining,
+                input_done,
+                ..
+            }) = self.promises.all_captures.records.get(group.0)
             else {
                 return Err(invalid());
             };
@@ -123,14 +135,22 @@
             // The first mutation and its clone are funded. No author call,
             // allocation, fallible lookup or arithmetic remains in this block.
             let ready = {
-                let AllCapture::Group { resolve, values, remaining, .. } =
-                    &mut self.promises.all_captures.records[group.0]
+                let AllCapture::Group {
+                    resolve,
+                    values,
+                    remaining,
+                    ..
+                } = &mut self.promises.all_captures.records[group.0]
                 else {
                     unreachable!("validated Promise.all group");
                 };
                 values.records[index] = value.clone();
                 *remaining = next;
-                if next == 0 { Some(ready_values(resolve, values)) } else { None }
+                if next == 0 {
+                    Some(ready_values(resolve, values))
+                } else {
+                    None
+                }
             };
             let AllCapture::Element { called, .. } = &mut self.promises.all_captures.records[id.0]
             else {
@@ -145,8 +165,12 @@
     pub(super) fn finish_all_input(&mut self, id: AllCaptureId) -> Result<Option<ReadyAllValues>> {
         let result = (|| {
             self.work(16)?;
-            let Some(AllCapture::Group { resolve, values, remaining, input_done }) =
-                self.promises.all_captures.records.get_mut(id.0)
+            let Some(AllCapture::Group {
+                resolve,
+                values,
+                remaining,
+                input_done,
+            }) = self.promises.all_captures.records.get_mut(id.0)
             else {
                 return Err(invalid());
             };
@@ -158,7 +182,11 @@
             // keeps this sentinel so saved callbacks cannot finish the group.
             *input_done = true;
             *remaining = next;
-            Ok(if next == 0 { Some(ready_values(resolve, values)) } else { None })
+            Ok(if next == 0 {
+                Some(ready_values(resolve, values))
+            } else {
+                None
+            })
         })();
         self.observe_microtask_failure(result)
     }
@@ -167,20 +195,25 @@
         let result = (|| {
             self.work(23)?;
             let id = self.arrays.len();
-            if self.array_properties.len() != id || self.array_holes.len() != id
+            if self.array_properties.len() != id
+                || self.array_holes.len() != id
                 || self.array_lengths.len() != id
             {
                 return Err(invalid());
             }
-            let prototype = self.array_prototype.filter(|prototype| *prototype < id)
+            let prototype = self
+                .array_prototype
+                .filter(|prototype| *prototype < id)
                 .ok_or_else(invalid)?;
             let length = u32::try_from(values.len()).map_err(|_| invalid())?;
             let logical = add(32, mul(values.len(), size_of::<Value>())?)?;
-            let objects = factories::object_slot_plan(self.objects.len(), self.objects.capacity(), 1)?;
+            let objects =
+                factories::object_slot_plan(self.objects.len(), self.objects.capacity(), 1)?;
             let arrays = row_plan::<Vec<Value>>(id, self.arrays.capacity())?;
             let properties = row_plan::<usize>(id, self.array_properties.capacity())?;
             let holes = row_plan::<BTreeSet<usize>>(id, self.array_holes.capacity())?;
-            let lengths = row_plan::<array_properties::ArrayLength>(id, self.array_lengths.capacity())?;
+            let lengths =
+                row_plan::<array_properties::ArrayLength>(id, self.array_lengths.capacity())?;
             let mut work = 0;
             let mut bytes = logical;
             for plan in [objects, arrays, properties, holes, lengths] {
@@ -201,7 +234,10 @@
             self.arrays.push(values);
             self.array_properties.push(properties);
             self.array_holes.push(BTreeSet::new());
-            self.array_lengths.push(array_properties::ArrayLength { value: length, writable: true });
+            self.array_lengths.push(array_properties::ArrayLength {
+                value: length,
+                writable: true,
+            });
             Ok(Value::Array(id))
         })();
         self.observe_microtask_failure(result)
