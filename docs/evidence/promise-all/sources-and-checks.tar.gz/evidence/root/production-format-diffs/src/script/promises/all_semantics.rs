--- raw/src/script/promises/all_semantics.rs
+++ formatted/src/script/promises/all_semantics.rs
@@ -66,12 +66,8 @@
                 let index = self.append_all_placeholder(group)?;
                 self.work(2)?;
                 let arguments = self.promise_arguments([value])?;
-                let next_promise = self.call(
-                    promise_resolve.clone(),
-                    arguments,
-                    constructor.clone(),
-                    doc,
-                )?;
+                let next_promise =
+                    self.call(promise_resolve.clone(), arguments, constructor.clone(), doc)?;
                 // This factory revalidates current private state after the
                 // author call and commits the count before any then getter.
                 let fulfilled = self.new_all_resolve_element(group, index)?;
