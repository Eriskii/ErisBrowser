import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

validation = json.loads((A / 'root/final-validation.json').read_text())
assert validation['status'] == 'pass'
for rel in ['root/final-source-review.json', 'root/final-validation-review.json', 'documentation-1/script-review.json', 'documentation-2/script-review.json']:
    data = json.loads((A / rel).read_text())
    assert 'clear' in data['status'], rel

artifacts = {}
folders = ['plans', 'integration-tests-before', 'abort-tests-before-1', 'migrations-before-1', 'semantics-production-1', 'private-production-1', 'install-production-1', 'documentation-1', 'documentation-2', 'root', 'validation']
excluded = {'selection-final.json', 'publication-verification.json'}
for folder in folders:
    for path in sorted((A / folder).rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file() or path.name in excluded or path.name.startswith(('upstream-parent-preservation-', 'host-release-for-upstream-')):
            continue
        assert '__pycache__' not in path.parts
        artifacts[str(path.relative_to(A))] = bind(path)
for path in sorted(A.iterdir()):
    if path.is_file() and path.suffix in ['.py', '.json'] and not path.name.startswith('author-upstream'):
        artifacts[path.name] = bind(path)

# Only the immutable authenticated retrieval inputs belong to this core
# checkpoint. Runner/importer plans and later outcomes are separate work.
upstream = A / 'upstream-plan-1'
for folder in ['primary-cache', 'proof']:
    for path in sorted((upstream / folder).rglob('*')):
        assert not path.is_symlink(), path
        if path.is_file():
            artifacts[str(path.relative_to(A))] = bind(path)
for name in ['inventory.json', 'selected-metadata.json', 'selection-before-fetch.json', 'read-selected-sources.py', 'html-compatibility-review.json', 'html-inventory-scope-review.json']:
    path = upstream / name
    if path.exists():
        artifacts[str(path.relative_to(A))] = bind(path)
for relative in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/promise-all.md']:
    assert 'PENDING_' not in (W / relative).read_text()
    artifacts['documentation/' + relative] = bind(W / relative)

claims = {
    'base': '8e3db775b176b7fa9cf0aef82c51f8eda6af7f6c',
    'scope': 'Custom Promise.all with observable constructor/resolve/iterator/then behavior, ordered intrinsic result Arrays, once-only fulfillment callbacks, sentinel preservation and existing fatal-resource suspension.',
    'tests': {'new_groups': 50, 'public_semantic': 24, 'public_abort': 7, 'private': 17, 'integration': 2, 'existing_migration_files': 13},
    'parent_observations': {'semantic': {'passed': 1, 'failed': 23, 'parent': '720127cb078b9eb671ae1ecf5b16b2d20f3a8d60'}, 'integration': {'passed': 0, 'failed': 2, 'parent': '720127cb078b9eb671ae1ecf5b16b2d20f3a8d60'}, 'abort': {'passed': 0, 'failed': 7, 'parent': '8e3db775b176b7fa9cf0aef82c51f8eda6af7f6c'}, 'limits': 'Failed groups stop at their first failure; later cases/modes are not parent passes. Private helper tests cannot run on parent.'},
    'resource_delta_from_base': {'startup_work': 108, 'accounted_heap_bytes': 2867, 'promise_state_bytes': 32},
    'validation': validation,
    'upstream_retrieval': {'sources': 98, 'planned_modes': 196, 'executed': False, 'revision': '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'},
    'limitations': 'No new Test262 outcome, GPU-device measurement, production-security assurance or Chromium performance result. Other combinators, async/await, classes, multiple realms and complete web compatibility remain unfinished.',
}
selection = {'source_inventory': bind(A / 'source2.json'), 'artifacts': artifacts, 'claims': claims, 'max_uncompressed_bytes': 128 * 1024 * 1024}
(A / 'root/selection-final.json').write_text(json.dumps(selection, indent=2) + '\n')
print(json.dumps({'artifacts': len(artifacts), 'source_inputs': 1104}))
