import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
P = Path('/tmp/eris-promise-all-plan-1')

def digest(data):
    return hashlib.sha256(data).hexdigest()

def checked(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert digest(data) == row['sha256'], row['path']
    return data

def manifest(path, expected):
    data = path.read_bytes()
    assert digest(data) == expected, path
    return json.loads(data)

baseline = json.loads((A / 'validation/abort-parent-baseline-1.json').read_text())
log = (A / 'validation' / baseline['log']).read_bytes()
assert digest(log) == baseline['sha256']
rows = re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$', log.decode(), re.M)
assert len(rows) == 7 and all(status == 'FAILED' for _, status in rows), rows
(A / 'root/abort-parent-baseline.json').write_text(json.dumps({
    'source': 'source-abort-formatted.json', 'receipt': baseline,
    'groups': 7, 'passed': 0, 'failed': 7, 'rows': rows,
    'mode_scope': 'Every group fails in its first sloppy-mode case because Promise.all is absent; later cases and strict-mode rows are unreached.',
    'production_changed': False,
}, indent=2) + '\n')

snapshot = json.loads((A / 'source-abort-formatted.json').read_text())
for relative, expected in snapshot['source_sha256'].items():
    assert digest((W / relative).read_bytes()) == expected, relative
selected = []
holds = [
    ('semantics-production-1', '3385a67d70c160ceff25ec961563125b862db245d4a4d59326c0fbf3ddc38878'),
    ('private-production-1', '322d6c3026c51eda1c1132421bc491f59ec429b73fee1cea7ce76e25c3f5a910'),
]
for name, expected in holds:
    m = manifest(A / name / 'source-ready.json', expected)
    for row in m['files']:
        checked(row['diff'])
        selected.append((row.get('target', row.get('relative')), checked(row['before']) if row['before'] else None, checked(row['raw'])))

m = manifest(A / 'install-production-1/source-ready.json', '4c95de5371e218a56ab1278d9e697787ef024bcc182dc07957b33dc8275ea33a')
for row in m['bindings']:
    checked(row)
for relative in m['selected_paths']:
    selected.append((relative, (A / 'install-production-1/before' / relative).read_bytes(), (A / 'install-production-1/raw' / relative).read_bytes()))

m = manifest(A / 'migrations-before-1/source-ready.json', '2145d77468bfcba3e7b9fd2e9459deece15c90e41d9c2b84d461dd96e9d84aaa')
for row in m['bindings']:
    checked(row)
for row in json.loads((A / 'migrations-before-1/selection.json').read_text())['paths']:
    selected.append((row['path'], checked(row['before']), checked(row['raw'])))

m = manifest(P / 'runtime-tests-before-1/source-ready.json', '121f8c963db8a0241cc02ee401b5aa64c0085fa92ecbbede5046169a1f98d64e')
for row in m['files']:
    selected.append((row['relative'], None, checked(row['source'])))
assert len(selected) == len({r[0] for r in selected}) == 24
for relative, before, raw in selected:
    target = W / relative
    assert (target.read_bytes() == before) if before is not None else not target.exists(), relative
receipt = []
for relative, before, raw in selected:
    target = W / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(raw)
    snapshot['source_sha256'][relative] = digest(raw)
    receipt.append({'path': relative, 'before_sha256': digest(before) if before is not None else None, 'raw_sha256': digest(raw)})
snapshot['scope'] = 'Composite Promise.all implementation and frozen tests, before rustfmt; all 1099 preceding source inputs verified before any production writes.'
(A / 'source-production-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
(A / 'root/production-import-receipt.json').write_text(json.dumps({'files': receipt, 'source_inputs': len(snapshot['source_sha256']), 'prior_public_controls_preserved': True}, indent=2) + '\n')
print(json.dumps({'imported_paths': len(selected), 'source_inputs': len(snapshot['source_sha256'])}))
