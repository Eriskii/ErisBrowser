#!/usr/bin/env python3
"""Root-owned selection of observed CSS URL background validation."""
from pathlib import Path
import hashlib, json, re, subprocess, sys

B = Path(__file__).resolve().parent
W = B / 'worktree'
Q = Path('/tmp/eris-url-background-consumer-plan-1')

def bind(p):
    p = Path(p)
    assert p.is_file() and p == p.resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return dict(rows=len(rows), passed=sum(int(x[1]) for x in rows),
                failed=sum(int(x[2]) for x in rows), ignored=sum(int(x[3]) for x in rows))

def main():
    config = json.loads(Path(sys.argv[1]).read_text())
    source = bind(B / config['source'])
    final = set(config['final_labels'])
    checks = {}
    for path in sorted((B / 'validation').glob('*.json')):
        record = json.loads(path.read_text())
        if not {'command', 'exit', 'log', 'sha256'} <= record.keys():
            continue
        label = path.stem
        log = path.parent / record['log']
        item = dict(receipt=bind(path), log=bind(log), command=record['command'], expected_exit=record['exit'])
        assert item['log']['sha256'] == record['sha256']
        observed = totals(log.read_text())
        if observed['rows']:
            item['rust'] = observed
        if label in final:
            assert record['exit'] == 0, label
            item['source'] = source
        elif label in config.get('historical_source', {}):
            item['source'] = bind(B / config['historical_source'][label])
        checks[label] = item
    assert final <= checks.keys()
    names = set()
    for argv in (['diff', 'HEAD', '--name-only', '-z'], ['ls-files', '--others', '--exclude-standard', '-z']):
        names.update(subprocess.check_output(['git', '-C', str(W), *argv]).decode().split('\0'))
    names.discard('')
    published = {n: bind(W / n) for n in sorted(names)}
    archive = set()
    # Explicit named preparation trees; neither worktree nor target trees are traversed.
    reference_dirs = config['reftest_archive_dirs']
    assert isinstance(reference_dirs, list) and reference_dirs
    assert all(isinstance(n, str) and n.startswith('reftests-') and '/' not in n and n not in ('.', '..') for n in reference_dirs)
    for name in ('css', 'layout', 'root', 'fixtures', 'docs', 'package-preparation', *reference_dirs):
        folder = B / name
        for p in folder.rglob('*'):
            if p.is_file():
                archive.add(p)
    for p in Q.glob('*'):
        if p.is_file():
            archive.add(p)
    archive.update(Q / name for name in ('fixtures-prep/author-fixtures.py', 'fixtures-prep/fixture-plan.json'))
    archive.update(B.glob('compiled-source-*.json'))
    archive.update(B.glob('authored-source-*.json'))
    archive.update(B / n for n in ('run-check.py', 'run-tool.py', 'snapshot-source.py', 'select-evidence.py'))
    archive.add(Path(sys.argv[1]).resolve())
    for name in config.get('extra_archive', []):
        archive.add(B / name)
    selection = dict(
        live_source=source,
        source_count=len(json.loads(Path(source['path']).read_text())['source_sha256']),
        published=published, checks=checks, full_suites=config['full_suites'],
        suite_commands={role: checks[label]['command'] for role,label in config['full_suites'].items()},
        final_checks=config['final_checks'],
        browser=dict(record=bind(B / config['browser_record']), build=config['browser_build'], strip=config['browser_strip']),
        reftests=dict(report=bind(B / config['reftests_report']), manifest=bind(W / 'tests/reftests/manifest.json'),
                      hold=bind(B / config['reftests_hold']), check=config['reftests_check']),
        reftest_archive_dirs=reference_dirs,
        browser_checks=config.get('browser_checks', []),
        holds={k:[bind(B/v) for v in paths] for k,paths in config['holds'].items()},
        parent_ci=config['parent_ci'], reviews={k: bind(B / v) for k, v in config['reviews'].items()},
        archive_inputs=[bind(p) for p in sorted(archive)], summary=config['summary'])
    out = B / config['output']
    with out.open('x') as f:
        json.dump(selection, f, indent=2, sort_keys=True)
        f.write('\n')
    print(json.dumps(dict(selection=bind(out), checks=len(checks), published=len(published), archive_inputs=len(archive)), indent=2))

if __name__ == '__main__':
    main()
