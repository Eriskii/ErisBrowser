# URL-background fixture contract

These are self-authored source fixtures, not WPT or observed results. No engine, compiler, formatter, importer or test runner was executed while authoring them.

Five 320×240 references compare loaded CSS URL backgrounds against literal opaque CSS rectangles. The 4×2 source has rows `RGBC` and `MYKO`; each symbol is an exact RGBA8 color in `oracles.json`. A black pixel and an independent half-alpha/transparent pair exercise the original rounded outline and compositing. Six solid one-pixel PNGs are used only by the HTTP provenance test.

- Sizing: auto/auto, contain, cover, each single auto axis, and independently stretched axes.
- Repetition: both axes, repeat-x, repeat-y, fractional phase, oversized negative positioning, radius and source alpha.
- Canvas: the body URL is positioned against root padding and its local used image is suppressed only when it propagates.
- Presence: an empty root URL is present but unavailable; it prevents propagation while the body still paints locally. It must not trigger a fetch.
- Inline/table: three atomic pieces share a six-pixel virtual strip. A cell stretched from two to six pixels recomputes `auto 100%` with the natural ratio. The existing table spacing is two pixels; this is not a new border-spacing claim.

`tests/url_backgrounds.rs` adds a direct Page HTTP test plus a Linux confined-worker test. The server is loopback-only, joined on drop, has two-second socket timeouts, an 8192-byte header cap and a 32-request guard. Expected request paths are literal: five document/redirect/style requests, four images on first prepare, none on read-only layout/cache reuse, and two new document-base images after a base mutation and explicit prepare. The imported stylesheet's custom-property URL is resolved at the inline consuming declaration; external and imported rules retain their final redirected bases. Full 12×8 pixels, hit tuples and node relationships are checked. The worker independently checks the whole 320×240 sizing frame and uses Render's prepare-before-snapshot route.

All 71 prior manifest rows are retained exactly; five new rows make 76. `manifest.before.json` preserves the original manifest. Root owns execution and any later observed corrections. The authoring helper under the external preparation directory constructs PNG chunks and emits references from the frozen literal rows; it does not call production geometry, decoding, CSS, layout or raster helpers.
