from pathlib import Path
W=Path('/tmp/eris-url-backgrounds-1/worktree');p=W/'src/layout.rs';s=p.read_text()
def replace(old,new,count=1):
 global s
 assert s.count(old)==count,(old[:80],s.count(old),count)
 s=s.replace(old,new)
replace('    BackgroundPosition, BackgroundSize, ComputedStyle, Display, GridBreadth, GridLine, GridTrack,','    BackgroundImage, BackgroundPosition, BackgroundSize, ComputedStyle, Display, GridBreadth, GridLine, GridTrack,')
replace('const MAX_EXTENT: f32 = 1_000_000.0;','''const MAX_EXTENT: f32 = 1_000_000.0;
const MAX_BACKGROUND_KEY_BYTES: usize = 65_536;
const MAX_BACKGROUND_KEY: usize = 4096;

/// Authenticated decoded dimensions supplied by Page, never author attributes.
#[derive(Clone, Copy)]
pub(crate) struct RasterNaturalSize {
    pub(crate) width: u32,
    pub(crate) height: u32,
}

/// Page keeps this key and its verified ImageStore allocation stable for layout.
#[derive(Clone, Copy)]
pub(crate) struct LoadedBackground<'a> {
    pub(crate) key: &'a str,
    pub(crate) natural: RasterNaturalSize,
}''')
replace('struct PaintOwner {\n    node: NodeId,\n    background: bool,\n}', '''struct PaintOwner {
    node: NodeId,
    background: bool,
    // Private inline URL slot. A transparent Rect carries its fragment geometry
    // until the complete sliced strip is known; no fabricated image key escapes.
    inline_raster: bool,
}''')
replace("struct Engine<'a> {\n    doc: &'a Document,", "struct Engine<'a> {\n    backgrounds: &'a [Option<LoadedBackground<'a>>],\n    background_key_bytes_left: usize,\n    doc: &'a Document,")
replace('''    fonts: &Fonts,
) -> LayoutResult {
    let viewport = Size {''','''    fonts: &Fonts,
) -> LayoutResult {
    layout_with_backgrounds(doc, styles, width, height, fonts, &[])
}

/// Resource preparation belongs to Page. This entry only consumes the same
/// computed styles and immutable, node-indexed loaded-image bindings.
pub(crate) fn layout_with_backgrounds(
    doc: &Document,
    styles: &[ComputedStyle],
    width: f32,
    height: f32,
    fonts: &Fonts,
    backgrounds: &[Option<LoadedBackground<'_>>],
) -> LayoutResult {
    let viewport = Size {''')
replace('''    let mut engine = Engine {
        doc,
        styles,
        fonts,''','''    let mut engine = Engine {
        doc,
        styles,
        fonts,
        backgrounds,
        background_key_bytes_left: MAX_BACKGROUND_KEY_BYTES,''')
# Every previous owner starts outside private pending URL state.
import re
s=re.sub(r'(background: (?:true|false),\n)(\s*)(})',r'\1\2    inline_raster: false,\n\2\3',s)
replace('''        if let Some(area) = engine.canvas_gradient_tile(root)
            && let Some(tile) = background_tile(
                area,
                engine.style(source).background_size,
                engine.style(source).background_position,
            )
            && let Some(gradient) = engine.style(source).background_image.clone()
        {
            engine.commands[index] = DrawCommand::LinearGradient {
                rect: rect(0.0, 0.0, viewport.width, content_height),
                tile,
                radius: 0.0,
                gradient,
                current_color: engine.style(root).color,
                stop_scale: 1.0,
                repeat: engine.style(source).background_repeat,
            };
        }''','''        if let Some(area) = engine.canvas_gradient_tile(root)
            && let Some(command) = engine.background_command(
                source,
                rect(0.0, 0.0, viewport.width, content_height),
                area,
                0.0,
                engine.style(root).color,
                false,
            )
        {
            engine.commands[index] = command;
        }''')
replace("impl Engine<'_> {\n    fn canvas_gradient_tile",'''impl Engine<'_> {
    fn loaded_background(&self, node: NodeId) -> Option<LoadedBackground<'_>> {
        self.backgrounds.get(node).copied().flatten().filter(|loaded| {
            loaded.natural.width > 0 && loaded.natural.height > 0
        })
    }

    fn background_command(
        &mut self,
        node: NodeId,
        paint: Rect,
        area: Rect,
        radius: f32,
        current_color: Color,
        allow_pending_tile: bool,
    ) -> Option<DrawCommand> {
        let style = self.style(node);
        let (size, position, repeat) = (
            style.background_size,
            style.background_position,
            style.background_repeat,
        );
        match style.background_image.as_ref()? {
            BackgroundImage::Gradient(gradient) => {
                let tile = background_tile(area, size, position);
                if tile.is_none() && !allow_pending_tile {
                    return None;
                }
                Some(DrawCommand::LinearGradient {
                    rect: paint,
                    tile: tile.unwrap_or_default(),
                    radius,
                    gradient: gradient.clone(),
                    current_color,
                    stop_scale: 1.0,
                    repeat,
                })
            }
            BackgroundImage::Url(_) => {
                let loaded = self.backgrounds.get(node).copied().flatten()?;
                if loaded.natural.width == 0 || loaded.natural.height == 0 {
                    return None;
                }
                let tile = background_tile_with_raster(area, size, position, loaded.natural);
                if tile.is_none() && !allow_pending_tile {
                    return None;
                }
                let key = clone_background_key(
                    loaded.key,
                    &mut self.background_key_bytes_left,
                    &mut self.position_work_left,
                )?;
                Some(DrawCommand::BackgroundImage {
                    rect: paint,
                    tile: tile.unwrap_or_default(),
                    radius,
                    key,
                    repeat,
                })
            }
        }
    }

    fn canvas_gradient_tile''')
replace('''        let gradient = if self.canvas_background_node == Some(id) {
            None
        } else {
            style.background_image.clone()
        };''','''        let has_image = self.canvas_background_node != Some(id)
            && style.background_image.is_some();''')
replace('for _ in 0..5 + usize::from(gradient.is_some()) {','for _ in 0..5 + usize::from(has_image) {')
replace('''        if let Some(gradient) = gradient {
            let area = rect(''','''        if has_image {
            let area = rect(''')
start=s.index('            let command = DrawCommand::LinearGradient {',s.index('        if has_image {'))
end=s.index('            let [background, top, right, bottom, left]',start)
s=s[:start]+'''            let command = self.background_command(
                id,
                if rounded { area } else { rect(x, y, width, height) },
                area,
                if rounded { (style.border_radius - border.top).max(0.0) } else { style.border_radius },
                style.color,
                // Table stretching may give a currently zero-sized tile a
                // positive used area. Real keys remain bounded and paid once.
                true,
            ).unwrap_or(DrawCommand::Rect {
                rect: Rect::default(),
                color: Color::TRANSPARENT,
                radius: 0.0,
            });
'''+s[end:]
replace('''&& if let Some(gradient) = &style.background_image {
                style.border_color.a == 255''','''&& if let Some(BackgroundImage::Gradient(gradient)) = &style.background_image {
                style.border_color.a == 255''')
replace('''                            }))
            } else {
                style.background_color.a == 255
            }''','''                            }))
            } else if matches!(style.background_image, Some(BackgroundImage::Url(_))) {
                // Unknown/transparent URL pixels cannot prove an opaque fill.
                style.border_color.a == 255 && style.background_color.a == 255
            } else {
                style.background_color.a == 255
            }''')
replace('''        let Some(gradient) = style.background_image.clone() else {
            return;
        };''','''        let Some(image) = style.background_image.clone() else {
            return;
        };''')
start=s.index('        self.push(DrawCommand::LinearGradient {',s.index('    fn paint_inline_gradient'))
end=s.index('        self.push(DrawCommand::PopClip);',start)
s=s[:start]+'''        match image {
            BackgroundImage::Gradient(gradient) => {
                self.push(DrawCommand::LinearGradient {
                    rect: area,
                    // Existing private gradient pending state stays unchanged.
                    tile: Rect { width: -1.0, ..Rect::default() },
                    radius,
                    gradient,
                    current_color,
                    stop_scale: 1.0,
                    repeat,
                });
            }
            BackgroundImage::Url(_) => {
                self.paint_owner.inline_raster = true;
                self.push(DrawCommand::Rect {
                    rect: area,
                    color: Color::TRANSPARENT,
                    radius,
                });
                self.paint_owner.inline_raster = false;
            }
        }
'''+s[end:]
replace('''            if let DrawCommand::LinearGradient { rect, tile, .. } = command
                && tile.width < 0.0
                && let Some((width, _)) = metrics.get_mut(owner.node)
            {
                *width += f64::from(rect.width);
            }''','''            let area = match command {
                DrawCommand::LinearGradient { rect, tile, .. } if tile.width < 0.0 => Some(*rect),
                DrawCommand::Rect { rect, .. } if owner.inline_raster => Some(*rect),
                _ => None,
            };
            if let Some(area) = area
                && let Some((width, _)) = metrics.get_mut(owner.node)
            {
                *width += f64::from(area.width);
            }''')
replace('''                DrawCommand::LinearGradient { rect, tile, .. } if tile.width < 0.0 => *rect,
                _ => continue,''','''                DrawCommand::LinearGradient { rect, tile, .. } if tile.width < 0.0 => *rect,
                DrawCommand::Rect { rect, .. } if self.owners[index].inline_raster => *rect,
                _ => continue,''')
replace('''            let style = self.style(self.owners[index].node);
            let resolved = background_tile(strip, style.background_size, style.background_position)
                .unwrap_or_default();
            if let DrawCommand::LinearGradient { rect, tile, .. } = &mut self.commands[index] {
                *rect = strip;
                *tile = resolved;
            }''','''            let node = self.owners[index].node;
            if self.owners[index].inline_raster {
                let radius = match &self.commands[index] {
                    DrawCommand::Rect { radius, .. } => *radius,
                    _ => unreachable!(),
                };
                if let Some(command) = self.background_command(
                    node, strip, strip, radius, self.style(node).color, false,
                ) {
                    self.commands[index] = command;
                }
                self.owners[index].inline_raster = false;
            } else {
                let style = self.style(node);
                let resolved = background_tile(strip, style.background_size, style.background_position)
                    .unwrap_or_default();
                if let DrawCommand::LinearGradient { rect, tile, .. } = &mut self.commands[index] {
                    *rect = strip;
                    *tile = resolved;
                }
            }''')
start=s.index('            if let Some(gradient) = style.background_image.clone()',s.index('        let mut row_y'))
end=s.index('            self.paint_owner = saved_owner;',start)
s=s[:start]+'''            if let Some(command) = self.background_command(
                id, row_rect, row_rect, 0.0, style.color, false,
            ) {
                self.push(command);
            }
'''+s[end:]
replace('''            stretch_fragment_background(
                &mut fragment,
                cell_height,
                style.background_size,
                style.background_position,
            );''','''            if matches!(style.background_image, Some(BackgroundImage::Url(_))) {
                stretch_fragment_background_with_raster(
                    &mut fragment,
                    cell_height,
                    style.background_size,
                    style.background_position,
                    self.loaded_background(cell.node).map(|loaded| loaded.natural),
                );
            } else {
                stretch_fragment_background(
                    &mut fragment,
                    cell_height,
                    style.background_size,
                    style.background_position,
                );
            }''')
replace('''fn stretch_fragment_background(
    fragment: &mut Fragment,
    height: f32,
    size: BackgroundSize,
    position: BackgroundPosition,
) {
    let height''','''fn stretch_fragment_background(
    fragment: &mut Fragment,
    height: f32,
    size: BackgroundSize,
    position: BackgroundPosition,
) {
    stretch_fragment_background_with_raster(fragment, height, size, position, None);
}

fn stretch_fragment_background_with_raster(
    fragment: &mut Fragment,
    height: f32,
    size: BackgroundSize,
    position: BackgroundPosition,
    natural: Option<RasterNaturalSize>,
) {
    let height''')
replace('''                DrawCommand::Rect { rect, .. } if fragment.rounded_border => {''','''                DrawCommand::BackgroundImage { rect, tile, .. } => {
                    rect.height += height - old_height;
                    *tile = padding.zip(natural)
                        .and_then(|(area, natural)| background_tile_with_raster(area, size, position, natural))
                        .unwrap_or_default();
                }
                DrawCommand::Rect { rect, .. } if fragment.rounded_border => {''')
# Existing in-file test Engine literal: only new fields, no assertion changes.
replace('''        Engine {
            doc,
            styles,
            fonts,''','''        Engine {
            doc,
            styles,
            fonts,
            backgrounds: &[],
            background_key_bytes_left: MAX_BACKGROUND_KEY_BYTES,''')
replace('#[cfg(test)]\nmod gradient_tests;','#[cfg(test)]\nmod gradient_tests;\n\n#[cfg(test)]\nmod url_background_tests;')
# Keep the existing gradient resolver itself byte-exact; new raster size route.
pos=s.index('fn background_size_axis(')
s=s[:pos]+'''/// Raster natural dimensions are independent of author img attributes and of
/// gradient auto sizing. Resolve both axes in f64 before the final geometry cap.
fn background_tile_with_raster(
    area: Rect,
    size: BackgroundSize,
    position: BackgroundPosition,
    natural: RasterNaturalSize,
) -> Option<Rect> {
    if natural.width == 0 || natural.height == 0 {
        return None;
    }
    let (aw, ah) = (f64::from(area.width), f64::from(area.height));
    if ![f64::from(area.x), f64::from(area.y), aw, ah].iter().all(|v| v.is_finite())
        || aw < 0.0 || ah < 0.0
    {
        return None;
    }
    let (nw, nh) = (f64::from(natural.width), f64::from(natural.height));
    let (width, height) = match size {
        BackgroundSize::Contain | BackgroundSize::Cover => {
            let scale = if size == BackgroundSize::Contain {
                (aw / nw).min(ah / nh)
            } else {
                (aw / nw).max(ah / nh)
            };
            (nw * scale, nh * scale)
        }
        BackgroundSize::Explicit { width: Length::Auto, height: Length::Auto } => (nw, nh),
        BackgroundSize::Explicit { width: Length::Auto, height } => {
            let height = background_size_axis(height, ah)?;
            (height * nw / nh, height)
        }
        BackgroundSize::Explicit { width, height: Length::Auto } => {
            let width = background_size_axis(width, aw)?;
            (width, width * nh / nw)
        }
        BackgroundSize::Explicit { width, height } => (
            background_size_axis(width, aw)?, background_size_axis(height, ah)?,
        ),
    };
    let x = f64::from(area.x) + object_position_offset(position.x, aw - width)?;
    let y = f64::from(area.y) + object_position_offset(position.y, ah - height)?;
    let limit = f64::from(MAX_EXTENT);
    if ![x, y, width, height].iter().all(|v| v.is_finite())
        || x.abs() > limit || y.abs() > limit || width > limit || height > limit
        || width <= 0.0 || height <= 0.0
    {
        return None;
    }
    let tile = Rect { x: x as f32, y: y as f32, width: width as f32, height: height as f32 };
    (tile.width > 0.0 && tile.height > 0.0).then_some(tile)
}

fn clone_background_key(key: &str, bytes_left: &mut usize, work_left: &mut usize) -> Option<String> {
    let bytes = key.len();
    let work = bytes.checked_add(1)?;
    if bytes == 0 || bytes > MAX_BACKGROUND_KEY || bytes > *bytes_left || work > *work_left {
        return None;
    }
    // Prepay both guards before clone/publication. Subsequent command refusal
    // never restores either allowance, including discarded sizing fragments.
    *bytes_left -= bytes;
    *work_left -= work;
    Some(key.to_owned())
}

'''+s[pos:]
p.write_text(s)
# Mechanical old-test enum/Engine migrations; retain every literal oracle.
for rel in ['src/layout/gradient_tests.rs','src/layout/background_tests.rs','src/layout/tiled_image_tests.rs']:
 p=W/rel;s=p.read_text()
 s=re.sub(r'(background: (?:true|false),\n)(\s*)(})',r'\1\2    inline_raster: false,\n\2\3',s)
 s=s.replace('''        fonts,
        viewport:''','''        fonts,
        backgrounds: &[],
        background_key_bytes_left: MAX_BACKGROUND_KEY_BYTES,
        viewport:''')
 # Match each complete RHS Some expression by balanced parentheses.
 at=0
 while True:
  m=re.search(r'\.background_image = Some\(',s[at:])
  if m is None:break
  begin=at+m.end();depth=1;end=begin
  while depth:
   if s[end]=='(':depth+=1
   elif s[end]==')':depth-=1
   end+=1
  s=s[:begin]+'BackgroundImage::Gradient('+s[begin:end-1]+')'+s[end-1:]
  at=end+len('BackgroundImage::Gradient(')+1
 s=s.replace('let source = styles[body].background_image.as_ref().unwrap();','let Some(BackgroundImage::Gradient(source)) = styles[body].background_image.as_ref() else { panic!("expected gradient") };')
 s=s.replace('gradient: styles[z].background_image.clone().unwrap(),','gradient: match styles[z].background_image.clone().unwrap() { BackgroundImage::Gradient(value) => value, _ => panic!("expected gradient") },')
 p.write_text(s)
(W/'src/layout/url_background_tests.rs').write_bytes((W.parent/'layout/tests-before/url_background_tests.rs').read_bytes())
