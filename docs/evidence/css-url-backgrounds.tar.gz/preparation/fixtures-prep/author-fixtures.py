# Inert fixture authoring only: literal rows -> independent CSS rectangles/PNG bytes.
from pathlib import Path
import json, struct, zlib, hashlib, shutil
W=Path('/tmp/eris-url-backgrounds-1/worktree')
D=Path('/tmp/eris-url-backgrounds-1/fixtures')
T=W/'tests/reftests'
A=T/'url-background-assets'; A.mkdir(exist_ok=True)
colors={'W':0xffffff,'R':0xff0000,'G':0x00ff00,'B':0x0000ff,'C':0x00ffff,'M':0xff00ff,'Y':0xffff00,'K':0x000000,'O':0xff8000,'D':0x9f9f9f,'E':0x151515,'P':0xff7f7f}
def rgba(rows):
 return bytes(c for row in rows for x in row for c in ((*colors[x].to_bytes(3,'big'),255)))
def png(name,w,h,data):
 def chunk(k,d):return struct.pack('>I',len(d))+k+d+struct.pack('>I',zlib.crc32(k+d))
 b=b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',w,h,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(b''.join(b'\0'+data[y*w*4:(y+1)*w*4] for y in range(h)),9))+chunk(b'IEND',b'')
 (A/name).write_bytes(b)
 assets.append({'path':str((A/name).relative_to(W)),'width':w,'height':h,'rgba':list(data)})
assets=[]
png('pattern.png',4,2,rgba(['RGBC','MYKO']))
for name,c in [('black','K'),('red','R'),('green','G'),('blue','B'),('yellow','Y'),('cyan','C'),('magenta','M')]:png(name+'.png',1,1,rgba([c]))
png('alpha.png',2,1,bytes([255,0,0,128,0,0,255,0]))
base='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:white}div{position:absolute}</style>\n'
url='url(url-background-assets/pattern.png)'
cases=[]
def case(name,description,html,boards,notes):
 ref=base
 for x,y,rows in boards:
  assert len({len(r) for r in rows})==1
  for dy,row in enumerate(rows):
   i=0
   while i<len(row):
    j=i+1
    while j<len(row) and row[j]==row[i]:j+=1
    if row[i]!='W':ref+=f'<div style="left:{x+i}px;top:{y+dy}px;width:{j-i}px;height:1px;background:#{colors[row[i]]:06x}"></div>\n'
    i=j
 (T/(name+'.html')).write_text(html)
 (T/(name+'-ref.html')).write_text(ref)
 cases.append({'name':name,'description':description,'test':name+'.html','reference':name+'-ref.html','literal_boards':[{'x':x,'y':y,'rows':rows} for x,y,rows in boards],'notes':notes})
html=base;boards=[]
for x,size,rows in [
 (20,'auto',['WWWWWWWWWWWW']*3+['WWWWRGBCWWWW','WWWWMYKOWWWW']+['WWWWWWWWWWWW']*3),
 (50,'contain',['WWWWWWWWWWWW']+['RRRGGGBBBCCC']*3+['MMMYYYKKKOOO']*3+['WWWWWWWWWWWW']),
 (80,'cover',['RRGGGGBBBBCC']*4+['MMYYYYKKKKOO']*4),
 (110,'8px auto',['WWWWWWWWWWWW']*2+['WWRRGGBBCCWW']*2+['WWMMYYKKOOWW']*2+['WWWWWWWWWWWW']*2),
 (140,'8px 6px',['WWWWWWWWWWWW']+['WWRRGGBBCCWW']*3+['WWMMYYKKOOWW']*3+['WWWWWWWWWWWW']),
 (170,'auto 6px',['WWWWWWWWWWWW']+['RRRGGGBBBCCC']*3+['MMMYYYKKKOOO']*3+['WWWWWWWWWWWW'])]:
 html+=f'<div style="left:{x}px;top:20px;width:12px;height:8px;background-image:{url};background-size:{size};background-position:center;background-repeat:no-repeat"></div>\n';boards.append((x,20,rows))
case('url-background-sizing','Decoded natural ratio, contain/cover and each auto axis against literal CSS rectangles.',html,boards,'Natural tile4x2; contain12x6; cover16x8; single-auto8x4; explicit8x6. Pixel centers choose source texels.')
html=base;boards=[]
for x,extra,rows in [
 (20,'background-repeat:repeat',['RGBCRGBC','MYKOMYKO']*2),
 (40,'background-position:right 1px bottom 1px;background-repeat:repeat-x',['WWWWWWWW','GBCRGBCR','YKOMYKOM','WWWWWWWW']),
 (60,'background-position:25% 75%;background-repeat:repeat-y',['WMYKOWWW','WRGBCWWW']*2),
 (80,'background-size:12px 6px;background-position:center;background-repeat:no-repeat',['RGGGBBBC']*2+['MYYYKKKO']*2)]:
 html+=f'<div style="left:{x}px;top:20px;width:8px;height:4px;background-image:{url};{extra}"></div>\n';boards.append((x,20,rows))
html+='<div style="left:20px;top:50px;width:4px;height:4px;border-radius:2px;background-image:url(url-background-assets/black.png)"></div>\n';boards.append((20,50,['DEED','EKKE','EKKE','DEED']))
html+='<div style="left:40px;top:50px;width:4px;height:2px;background-image:url(url-background-assets/alpha.png)"></div>\n';boards.append((40,50,['PWPW']*2))
case('url-background-repeat-position','Repeat axes, fractional and negative phase, original rounded outline and source alpha use independent pixel rectangles.',html,boards,'Rounded coverage96/234 over white gives159/21. Alpha128 red over white gives ff7f7f; transparent blue leaves white.')
html='<!doctype html><meta charset="utf-8"><style>html{margin:0;width:12px;height:8px;box-sizing:border-box;padding:1px;border:1px solid transparent}body{margin:0;width:2px;height:2px;background-image:'+url+';background-position:2px 1px;background-repeat:no-repeat}</style>'
case('url-background-canvas','Body URL propagates using root padding positioning and suppresses its local used image.',html,[(3,2,['RGBC','MYKO'])],'Root padding (1,1,10,6); tile (3,2,4,2), even outside the tiny body box. No duplicate tile at (4,3).')
html='<!doctype html><meta charset="utf-8"><style>html{margin:0;width:12px;height:8px;box-sizing:border-box;padding:1px;border:1px solid transparent;background-image:url("")}body{margin:0;width:4px;height:2px;background-image:'+url+';background-repeat:no-repeat}</style>'
case('url-background-unavailable-root','An empty root URL retains image presence, blocks body-to-canvas propagation, and leaves the body local image visible.',html,[(2,2,['RGBC','MYKO'])],'Empty URL does not fetch and is not none. Body local content origin is (2,2), while propagating incorrectly would anchor at root padding (1,1).')
html=base+'<div style="left:20px;top:20px;width:4px;font-size:1px;line-height:2px"><span style="background-image:'+url+';background-position:center;background-repeat:no-repeat"><i style="display:inline-block;width:2px;height:2px;vertical-align:top"></i><i style="display:inline-block;width:2px;height:2px;vertical-align:top"></i><i style="display:inline-block;width:2px;height:2px;vertical-align:top"></i></span></div>\n'
html+='<table style="position:absolute;left:20px;top:60px;width:14px"><tr style="height:6px"><td style="width:4px;height:2px;padding:0;vertical-align:bottom;background-image:'+url+';background-size:auto 100%;background-position:center;background-repeat:no-repeat"></td><td style="width:4px;height:2px;padding:0"></td></tr></table>\n'
case('url-background-inline-table','A split inline uses a continuous virtual strip; a stretched table cell recomputes natural-ratio size from its final height.',html,[(20,20,['WRGB','WMYK','CWWW','OWWW']),(22,62,['GGBB']*3+['YYKK']*3)],'Inline virtual6x2 with centered4x2 spans three2x2 fragments. Existing table spacing2 yields cell(22,62,4,6), tile(18,62,12,6).')
manifest=T/'manifest.json';before=manifest.read_bytes();(D/'manifest.before.json').write_bytes(before)
m=json.loads(before);assert len(m['cases'])==71
m['cases'] += [{k:c[k] for k in ['name','description','test','reference']} for c in cases]
manifest.write_text(json.dumps(m,indent=2)+'\n')
plan={'scope':'Self-authored independent fixtures, not WPT. Source/data authoring only; no project execution or observed result.','viewport':[320,240],'palette':{k:f'{v:06x}' for k,v in colors.items()},'assets':assets,'cases':cases,'manifest':{'before':71,'after':76,'old_rows_unchanged':m['cases'][:71]==json.loads(before)['cases']}}
(D/'oracles.json').write_text(json.dumps(plan,indent=2)+'\n')
