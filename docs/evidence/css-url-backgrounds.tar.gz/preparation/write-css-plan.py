from pathlib import Path
import hashlib, json
P=Path('/tmp/eris-url-background-consumer-plan-1')
W=Path('/tmp/eris-page-resources-1/worktree')
def binding(path):
    path=Path(path); data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
plan={
 'status':'Source-only CSS URL-background consumer design. No implementation, project execution, URL-property acceptance, resource fetch, or live edit.',
 'inspection_base':'63eb8ed1cde35d84e2a8d0237552aa158adb680d',
 'current_worktree':str(W),
 'decision':'Use one coherent computed BackgroundImage enum; recover the consuming declaration provenance from existing cascade priority fields, resolve only the winning URL, and share the computed result through a bounded style-computation cache. Ship URL acceptance only together with the Page preparation and paint consumer.',
 'foundation_status':{
  'complete_in_published_parent':'SourceBase, StyleSource.base, Rule.base, final redirected/imported sheet bases, and strict pure css::url decoding/resolution already exist. The historical broad plan statements that these fields are missing are superseded.',
  'frozen_current_page_work':'PageResources retains the actual initial Fetcher, image success/failure caches, decoded-byte total and URL-work remainder. This refactor still introduces no URL-background selection or render-time fetch trigger.',
  'still_missing':'IndexedRule/Candidate do not directly retain base handles, and cascaded_value currently returns only String. CSS accepts only none/linear-gradient images. Page::layout remains read-only and layout receives no authenticated raster-background bindings.'
 },
 'scope':{
  'include':['One url() image or the existing one gradient/none image in the supported five-longhand background shorthand','Quoted/unquoted URL tokens, existing strict CSS escapes and UTF-8 URL resolution','External final-sheet bases, current document base, imports, layers/importance/inline winners, var consumption, pending shorthand and explicit computed inheritance','Existing size, position, repeat and background-color behavior; pure CSS.supports and authored CSSOM serialization'],
  'exclude':['Multiple layers, URL modifiers, image-set/image/cross-fade, additional background longhands','New fetch authority, codecs, dependencies, credentials rules or raised resource quotas','CSS-side fetching, loaded-pixel metadata, DOM natural-size attributes, cascade-token provenance on custom properties','Local SVG fragment selection; local references are retained but unavailable in the first image consumer','Claiming acceptance in supports or CSSOM before Page/paint paths can consume it']
 },
 'normative_basis':[
  {'url':'https://drafts.csswg.org/css-values-4/#relative-urls','rule':'Relative URLs use their containing stylesheet base; embedded styles use the document container base. Computed URLs become absolute where possible; a failure to resolve retains specified text.'},
  {'url':'https://drafts.csswg.org/css-values-4/#urls','rule':'Keep local fragment and empty-resource states separate. Empty url() must not become a request for the document. Use the existing pure UTF-8 resolver rather than the HTML legacy-encoding helper.'},
  {'url':'https://drafts.csswg.org/css-variables-1/#defining-variables','rule':'Custom properties retain uncomputed token streams. A relative URL substituted from a custom property resolves at the consuming ordinary declaration, including a consuming shorthand.'},
  {'url':'https://drafts.csswg.org/css-cascade-5/#inheriting','rule':'Inheritance transfers computed values. Explicit background-image:inherit shares the parent computed absolute URL; it does not resolve the parent spelling under the child declaration base.'},
  {'url':'https://drafts.csswg.org/css-cascade-5/#revert-layer','rule':'A rollback exposes another candidate. URL provenance must follow that exposed candidate, not the revert-layer declaration.'},
  {'url':'https://drafts.csswg.org/css-backgrounds-3/#the-background-image','rule':'Failed, unsupported or empty images draw nothing without turning into an older cascade winner. Initial none and non-inherited background defaults remain distinct from an unavailable selected image.'},
  {'url':'https://drafts.csswg.org/css-backgrounds-3/#special-backgrounds','rule':'Root/body background propagation depends on computed image presence. A selected URL cannot be collapsed to none merely because its resource is unavailable.'},
  {'url':'https://drafts.csswg.org/css-syntax-3/#consume-url-token','rule':'URL payload is a token. Slash-star sequences and punctuation inside a URL token must not be treated as top-level comments/declaration delimiters.'}
 ],
 'minimal_provenance_path':[
  'Keep Rule.base and StyleSource.base unchanged. Do not add any field to IndexedRule, Candidate, Declaration or CustomProperties.',
  'IndexedRule.order is already the original index from rules.iter().enumerate(). Candidate.priority.4 stores it; priority.1 identifies inline candidates. This remains valid after priority sorting and bucket replacement.',
  'Change cascaded_value to return a transient SelectedValue { value: String, source: WinningSource::Document | Rule(u32) }. Derive source only at the return for the surviving candidate, after existing revert-layer handling.',
  'Custom-property collection moves only selected.value into the unchanged token map. Definition-sheet provenance must not attach to tokens or follow their inheritance.',
  'Ordinary collection retains the existing BTreeMap<String,String>. Keep one stack background_image_source local, set only when inserting the selected background-image result; no per-property map growth is needed.',
  'Pending background shorthand expansion stays inside cascaded_value. All five expanded members retain the original shorthand candidate priority; its background-image therefore resolves at the consuming shorthand source.',
  'Apply non-wide background-image after font-size/color as today. Rule(index) uses checked rules.get(index).base; Document uses a local SourceBase::Document and borrows doc.base_url(). An impossible index refuses rather than silently using document base.',
  'Custom-variable substitution, invalid-at-computed-value-time unset, initial/unset/revert and explicit inherit preserve their current order. A syntactically invalid specified URL is rejected before cascade; a valid but unresolved/fetch-failed URL remains selected. No fallback to an older declaration on resource failure.',
  'A source table is unnecessary. Public compute_styles_with_rules admits up to 10,000 rules with potentially distinct bases, so a universal 256-base assumption would be wrong even though the StyleSource wrapper takes at most 256 sources.'
 ],
 'computed_model':{
  'field':'ComputedStyle.background_image: Option<BackgroundImage>',
  'variants':['Gradient(Arc<LinearGradient>)','Url(Arc<css::url::ResolvedUrl>)'],
  'absence':'None remains the initial/none image state. Ordinary unset/initial restore it. Default non-inheritance remains unchanged.',
  'url_states':'Absolute Url retains its complete computed serialization, including fragment. LocalFragment, Empty and Unresolved are preserved in Some(Url), receive no network request in the first consumer, and paint only the underlying color.',
  'inheritance':'copy_property clones the BackgroundImage/Arc. A child inherit from a parent resolved under /a/ remains /a/ even when the inherit declaration is in /b/. Inherited custom tokens consumed by a /b/ declaration instead resolve under /b/.',
  'cssom':'Inline CSSOM keeps the authored/normalized token spelling, never an absolute rewritten URL. Relative URL resolution is a computed-style operation. No getComputedStyle feature is added implicitly.',
  'gradient_compatibility':'Keep CurrentColor marker, gradient interning, units and existing geometry/native eligibility unchanged. Audit every is_some/is_none and gradient dereference caller; URL presence must not enter a gradient-only opacity proof.',
  'style_budget_refusal':'The existing bounded style engine may leave the initial image on resource/work admission exhaustion, as it does for gradients. This is distinct from an admitted URL whose parse/fetch/decode fails. Do not present quota exhaustion as normative URL invalidity.'
 },
 'parser_and_cssom_changes':[
  'Add a borrowed Url(&str) case to the existing ParsedImage path and a shared allocation-free syntax validation entry over the strict css::url cursor/escape scanner. Do not fork a looser URL grammar or run both complete image parsers. None/gradient branches retain their existing work admissions.',
  'background::parts recognizes both Kind::Url and Function named url, including escaped function spelling accepted by the existing tokenizer. It still returns exactly color/image/size/position/repeat, enforces one image, and rejects the whole declaration on a second image/layer/unsupported component.',
  'Route declaration validation, post-var validation, supports and CSSOM through the same image validator. Syntax checks do not resolve bases or allocate retained URL objects; decode/resolve happens only for a selected computed image cache miss.',
  'Replace or bypass character-based strip_comments only where it would touch a background URL payload: parse_declarations_with_limit and cascaded_value currently normalize unquoted URL-internal /*...*/ incorrectly. Use the original token spans; retain strings and Kind::Url bytes. Preserve actual comment token separation and original calc whitespace checks.',
  'The two-argument supports route currently blanket-rejects any backslash in a value token. The condition route additionally scans raw ; ! { } and rejects all escaped values. Give background/image a token-aware path using original value spans, balanced tokens and shared grammar; do not relax unrelated property guards or allow top-level injection.',
  'CSSOM already preserves Kind::Url and String payload case. Retain it, including strict EOF checks; never lowercase paths, percent escapes, fragments or quoted data. Test lowercasing of only the url function identifier separately.',
  'Keep the records() validated background-longhand fast path: once a normalized image was fully validated and storage prepaid, move it directly into Record. Do not restore the duplicate expanded-longhand validation that broke the old global author-budget click witness.',
  'The shorthand remains atomic across five longhands, supplies omitted initial geometry, retains pending var shorthand records, honors important ordering, and serializes empty when any longhand is absent or a mixed CSS-wide set cannot be represented.',
  'all/reset, invalid setter preservation, removeProperty, cssText roundtrip and original-token post-var failure behavior must be covered together with URL acceptance.'
 ],
 'shared_budget_and_cache':{
  'work':'All candidate, token, URL decode/resolve and cache operations debit the existing compute_styles_with_rules 20,000,000 work remainder. Pure validation uses its caller work reference: no per-node, per-property, var, supports or CSSOM reset.',
  'fixed_metadata':'Candidate and IndexedRule representations remain byte-for-byte unchanged. SelectedValue source is temporary and one stack local survives. Do not take fixed metadata from the existing 8MiB authored style text allowance.',
  'pool':'Prefer one shared 4MiB image-admission ceiling covering the unchanged gradient pool charge plus new URL cache nodes, key bytes, Arc/value headers and URL decode/resolve storage reservations. Gradient-only pages retain the existing 4MiB capacity; mixed pages share it instead of adding an unbounded second pool.',
  'key':'A bounded nested BTreeMap<WinningSource, BTreeMap<String,Arc<ResolvedUrl>>> keys the complete substituted URL spelling. Canonicalize any Rule with SourceBase::Document to Document. External rules may keep separate entries; this bounds storage without a new source table or long base-string comparisons.',
  'hits':'Use borrowed str lookup and return only Arc clones. Repeated nodes with the same consuming rule/value do not clone or parse URL strings. All reached map comparisons and Arc publication still pay source-derived work.',
  'misses':'Before allocation, reserve full worst-case map-node/key/header charges, then run css::url::decode and resolve with the SAME remaining work and shared bytes. Always write back both remainders, including error paths. The existing URL tariffs are admission charges, not allocator/instruction instrumentation.',
  'lifetime':'Cache exists for one computation. Returned styles own the Arc values. A later document-base/style/media recomputation uses a new cache; it cannot reuse a stale Document-base result.',
  'no_refund':'No refund of cumulative URL/decode allowance on failed parsing, discarded temporaries or replacement. Existing gradient replacement behavior remains the bound. No new per-node large URL ownership.',
  'limits':'Preserve 4096 raw URL/property bytes, existing URL resolver input/result caps, 8MiB stylesheet input, 10,000-rule, 4096-cascade-bucket, 1MiB per-node cascade-string, 8MiB custom-property retention and CSSOM 64KiB/256-record bounds. Exact new comparison/metadata tariff must be derived and frozen before implementation tests; do not guess it from runtime.',
  'tests':'Literal exact/one-short work and byte cuts must distinguish validation, cache hit, cache miss, unresolved URL, and non-refunded failure. Re-run the existing gradient/background Page+worker click under unchanged author quotas.'
 },
 'page_layout_contract':[
  'CSS returns computed immutable URL identities, not ImageStore keys or natural sizes. It never changes network initiator: sheet base is resolution context only.',
  'Future Page preparation computes one style vector, enumerates selected URLs, uses its retained session/negative cache, and returns one bounded node-indexed prepared binding vector alongside those same styles. Borrow key and Copy dimensions; no per-command raster Arc is needed.',
  'Page deduplicates canonical requested URLs independently of CSS Arc identity. Distinct spellings or consuming rules may share one fetch/cache entry. Keep the full computed fragment in CSS; remove it only for the existing request identity. Do not conflate redirected final URL with the originally requested cache key.',
  'A generated key prefix alone is not authentication because authored raw img aliases can collide. Before publishing a prepared binding, Page must verify that its key maps to the exact cached raster Arc after alias/SVG updates. Consume the prepared styles/map without author callbacks in between.',
  'Unavailable Url still takes a color-preserving image-present layout route. Layout identified an existing inline is_none color branch that must not lose color on an unavailable URL. Root/body presence, six paint slots and table-stretch routes must be updated coherently.',
  'Background URL handles do not create DOM nodes, mutate data-eris-natural-* attributes, or supply natural dimensions from author text. Raster sizing/gradient sizing remain distinct; SVG natural metadata limitations stay explicit.',
  'No new Page::layout fetch behavior is authorized by this design. Root must select the mutable preparation API and all direct/worker/headless call sites before URL acceptance lands.'
 ],
 'independent_regression_groups':[
  {'name':'Final stylesheet bases','literal':'/entry.css redirected to https://assets.test/final/style.css selects /final/Tile.PNG; imported child redirected to /nested/end.css selects /nested/Tile.PNG; parent post-import rules return to /final/. Inline style uses current document base.'},
  {'name':'Winner provenance without candidate growth','literal':'Two rules with identical url(Tile.PNG) and distinct bases exercise specificity, source order, important, layers, anonymous layers and inline rollback. Selected URL follows the actual exposed winner. Assert Candidate/IndexedRule size unchanged and no new URL Arc per candidate.'},
  {'name':'Var consumption','literal':'--tile:url(Tile.PNG) defined in /a/style.css and consumed in /b/style.css resolves /b/Tile.PNG, including inherited tokens, nested vars, fallback and pending background shorthand. No base is attached to custom-property tokens.'},
  {'name':'Computed inheritance','literal':'Parent computed /a/Tile.PNG is shared by child background-image:inherit from /b/. Child background-image:var(--tile) resolves /b/. Initial/unset/all reset to None; inheritance preserves Arc identity.'},
  {'name':'Invalid versus unavailable','literal':'Malformed url syntax leaves an earlier valid declaration. Valid url("")/url()/url(#part)/unresolvable URL/fetch failure remains the selected Url state and does not revive an older gradient. Empty/local/unresolved produce zero requests. Root unavailable URL suppresses body propagation while color still paints.'},
  {'name':'Literal token preservation','literal':'Compare authored stylesheet, inline parser, post-var, supports and CSSOM for url(Tile.PNG), quoted spaces/parens, escaped url identifier/closing paren, non-ASCII, percent escapes, url(a/*b*/c.png), and quoted punctuation/data syntax. References assert exact decoded strings/absolute URL text, not parser-generated expected values.'},
  {'name':'Atomic shorthand and CSSOM','literal':'URL plus center/8px auto/repeat-x updates all five records; omitted geometry resets. Two images, extra layer, unsupported modifiers and top-level injections preserve prior records. Missing/mixed-wide longhands serialize empty. setProperty/cssText/removeProperty/all and pending var remain coherent.'},
  {'name':'Base recomputation','literal':'Mutate the connected base between complete style computations: Document and inline winners follow new base; external sheet winners do not. An inherited computed value shares its parent in that computation. No stale cross-computation resolution memo survives.'},
  {'name':'URL work/storage boundaries','literal':'Freeze new tariff from source, test every relevant admission endpoint, repeated-node hits, separate consuming rules, huge base refusal, maximum raw input, failed resolution, no refund and no allocation before admission. Shared mixed gradient/URL cap remains 4MiB.'},
  {'name':'Existing witnesses','literal':'Keep current none/gradient defaults, root currentColor, gradient alpha/rounding/geometry, and real linear-gradient/background-geometry direct Page and confined-worker click witnesses under unchanged author quotas.'},
  {'name':'Future resource integration','literal':'HTTP counters independently verify selected URL requests only, shared img/background cache Arc, failure dedup, unchanged request/body/decode/URL-work session counters and opaque taint. Fixture includes no data-* natural-size dependency.'}
 ],
 'bounded_implementation_paths':{
  'css.rs':'Transient SelectedValue/origin, unchanged candidate storage, image enum field, post-var raw-token safety, selected URL application and existing copy_property inheritance.',
  'css/gradient.rs and optional css/image.rs':'Borrowed URL parse case and computed image pool facade; retain old gradient math/parser/intern behavior. Avoid broad module refactor.',
  'css/url.rs':'Shared strict syntax-only scanner entry plus unchanged pure decoder/resolver semantics. No fetch or public observability additions.',
  'css/background.rs':'Recognize single URL component and use the common image validation path; retain fixed 11-component/five-output shorthand.',
  'cssom.rs':'Narrow URL-safe token/serialization acceptance; preserve validated-longhand optimization and atomic record behavior.',
  'new private tests':'CSS provenance/URL consumer and CSSOM URL fixtures authored before implementation; root owns integration execution.',
  'other owners':'Page/loader selection, layout geometry, command/worker/CPU fallback and independent HTTP/pixel fixtures must be coordinated before feature acceptance.'
 },
 'open_decisions_before_implementation':[
  'Root chooses Page mutable preparation API and visibility/resource-selection policy, including hidden/detached nodes, before adding URL acceptance.',
  'The shared 4MiB image-admission proposal needs author review against existing gradient tariffs and a literal source-derived cache ledger; no budget increase is implicit.',
  'Keep first-stage local fragments unavailable without fetch. Full SVG fragment and intrinsic sizing semantics require a separate increment.',
  'Measure representation sizes only during root validation; the design intentionally avoids per-candidate growth but ComputedStyle enum size may change within the existing node bound.'
 ],
 'files':[binding(W/p) for p in ['src/css.rs','src/css/gradient.rs','src/css/background.rs','src/css/url.rs','src/cssom.rs','src/page.rs','src/layout.rs','src/document_url.rs','src/dom.rs','src/stylesheet_loading.rs','src/selectors.rs']],
 'support':[binding('/tmp/eris-background-images-plan-1/plan.json'),binding('/tmp/eris-page-resources-1/page/source-ready.json'),binding('/tmp/eris-page-resources-1/compiled-source-1.json')],
 'api_sketch':binding(P/'api-sketch.rs')
}
(P/'css-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
hold={'status':'source-only design held; no implementation or project execution','files':[binding(P/'css-plan.json'),binding(P/'api-sketch.rs')]}
(P/'css-source-ready.json').write_text(json.dumps(hold,indent=2)+'\n')
print(json.dumps(binding(P/'css-source-ready.json')))
print(json.dumps(binding(P/'css-plan.json')))
