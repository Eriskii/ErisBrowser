// SOURCE-ONLY API SKETCH. Not a project source, implementation, or compiled test.
// Current inspection base: /tmp/eris-page-resources-1/worktree.

// css.rs: one computed image value; None retains its existing meaning.
#[derive(Clone, Debug)]
pub enum BackgroundImage {
    Gradient(std::sync::Arc<crate::graphics::gradient::LinearGradient>),
    Url(std::sync::Arc<crate::css::url::ResolvedUrl>),
}
// ComputedStyle.background_image: Option<BackgroundImage>
// copy_property("background-image") continues to clone this field.
// The Url variant owns a COMPUTED value, not a fetch result or a source base.

// NO fields are added to IndexedRule, Candidate, Declaration, or CustomProperties.
// IndexedRule.order already names rules[order]. Candidate.priority.4 retains it;
// Candidate.priority.1 already distinguishes element-attached declarations.
#[derive(Clone, Copy, Debug, Eq, PartialEq, Ord, PartialOrd)]
enum WinningSource {
    Document,
    Rule(u32),
}
struct SelectedValue {
    value: String,
    source: WinningSource,
}
// cascaded_value(...) -> Option<SelectedValue>
// Construct source ONLY for the actual candidate returned after rollback:
// if candidate.priority.1 { Document } else { Rule(candidate.priority.4) }.
// Custom property collection takes only selected.value (tokens stay unresolved).
// Ordinary collection keeps existing BTreeMap<String, String>; one stack local
// background_image_source records selected.source for that property only.
// URL application uses a checked rules.get(order).map(|rule| &rule.base).
// An invalid internal index refuses; it must not silently become Document.

// Pool lifetime is one compute_styles_with_rules invocation; styles keep Arcs.
// Document source contexts canonicalize to Document before lookup. External
// rules may have separate cache entries even if their final sheet URL is equal.
// Page later deduplicates resource requests by canonical requested URL.
struct UrlImagePool {
    by_source: std::collections::BTreeMap<
        WinningSource,
        std::collections::BTreeMap<String, std::sync::Arc<crate::css::url::ResolvedUrl>>,
    >,
}
// UrlImagePool::intern(
//     &mut self, original_complete_url_value: &str, origin: WinningSource,
//     base: &SourceBase, current_document_base: &url::Url,
//     work: &mut usize, shared_image_bytes_left: &mut usize,
// ) -> Result<Option<Arc<css::url::ResolvedUrl>>, selectors::Error>
// Lookup borrows &str: no key clone or URL parse on a hit. A miss prepays both
// tree nodes, owned key, Arc/header, and decode/resolve admissions before alloc.
// The outer and inner comparison/handle costs are paid on hits and misses.
// Map key is the full substituted URL token spelling, not an unescaped string
// assembled from fragments. Cache never survives document/base recomputation.

// Narrow pure syntax seam: share the existing strict URL cursor/escape scanner.
// pub(crate) css::url::valid(value: &str, work: &mut usize)
//     -> Result<bool, selectors::Error>
// It emits no decoded String, resolves no base, and does no fetch. Do not write
// a second independent quoted/unquoted/escape grammar. decode() and valid()
// must share their exact token/body validation, with an output/no-output sink.

// Existing image parser gains a borrowed URL case after strict validation:
// ParsedImage<'s> = None | Gradient(ParsedGradient) | Url(&'s str).
// Keep existing none/gradient parse work paths, including their prepayments;
// charge URL-specific scans only on the URL branch. Do not validate a URL by
// fully running both the old gradient parser and a separate image parser.
// Common background::parts recognizes Kind::Url and Function named url, and
// returns the same five borrowed longhand slices as today.

// Page -> layout boundary (owned by Page/layout authors, not CSS):
// PreparedBackgrounds<'a>: bounded node-indexed Vec<Option<PreparedImage<'a>>>.
// PreparedImage contains an authenticated ImageStore key reference plus Copy
// natural raster dimensions. No CSS-supplied pixel sizes or data-* attributes.
// Page consumes the SAME computed style vector for selection and layout.
// An unresolved/unavailable Url has no prepared image, but remains Some(Url)
// in ComputedStyle so color painting and root/body propagation remain correct.
