from pathlib import Path
import hashlib, json, subprocess, difflib
N=Path('/tmp/eris-promise-any-runtime-plan-1'); W=N/'worktree'; R=N/'production-review-1'
BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def git(rel): return subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
def once(s,a,b=''):
 assert s.count(a)==1, (a[:100],s.count(a)); return s.replace(a,b,1)
def cut(s,start,end):
 a=s.index(start); z=s.index(end,a); return s[:a]+s[z:]
paths=['src/script.rs','src/script/aggregate_error.rs','src/script/dom_prototypes.rs','src/script/machine/calls.rs','src/script/promises.rs','src/script/promises/all_semantics.rs','src/script/promises/factories.rs','src/script/promises/install.rs','src/script/promises/semantics.rs']
actual=subprocess.check_output(['git','diff','--name-only',BASE],cwd=W,text=True).splitlines()
assert sorted(actual)==sorted(paths),actual
parent=json.loads((N/'source-parent.json').read_text())['source_sha256']
rows=[]
for rel in paths:
 old=git(rel); new=(W/rel).read_bytes(); assert sha(old)==parent[rel]
 for label,b in [('before',old),('candidate',new)]:
  p=R/label/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 s=new.decode()
 if rel=='src/script.rs':
  s=once(s,'        self.install_aggregate_error_intrinsics()?;\n        self.install_promise_any_intrinsic()','        self.install_aggregate_error_intrinsics()')
  s=once(s,'\n#[cfg(test)]\nmod promise_any_abort_tests;\n#[cfg(test)]\nmod promise_any_semantic_tests;\n\n#[cfg(test)]\nmod promise_any_input_tests;\n')
 elif rel=='src/script/aggregate_error.rs':
  s=cut(s,'    pub(super) fn intrinsic_aggregate_error_from_list(','    fn aggregate_error_named_get(')
 elif rel=='src/script/dom_prototypes.rs': s=once(s,'    + promises::ANY_METADATA_OBJECTS\n')
 elif rel=='src/script/machine/calls.rs': s=once(s,'                    | "Promise.any"\n')
 elif rel=='src/script/promises.rs':
  s=once(s,'pub(super) const ANY_METADATA_OBJECTS: usize = 1;\n');s=once(s,'    AnyReject(AllCaptureId),\n')
 elif rel=='src/script/promises/all_semantics.rs': s=cut(s,'    pub(super) fn promise_any(','    pub(super) fn promise_race(')
 elif rel=='src/script/promises/factories.rs':
  s=once(s,'                        | CallbackKind::AnyReject(id)\n')
  s=cut(s,'    pub(super) fn new_any_reject_element(','    pub(super) fn new_all_settled_elements(')
 elif rel=='src/script/promises/install.rs': s=cut(s,'    pub(in crate::script) fn install_promise_any_intrinsic(','    fn check_promise_install_state(')
 elif rel=='src/script/promises/semantics.rs':
  s=once(s,'                "Promise.any" => self.promise_any(receiver, args, doc),\n')
  s=once(s,'                CallbackKind::AnyReject(element) => {\n                    return self.run_any_callback(element, args, doc);\n                }\n')
 assert s.encode()==old,rel
 d=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 p=R/'diffs'/f'{rel}.patch';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(d)
 rows.append({'relative_path':rel,'before':bind(R/'before'/rel),'candidate':bind(R/'candidate'/rel),'diff':bind(p),'selected_inverse_recovers_entire_published_file':True})
unchanged=[]
for rel in ['src/script/promises/all_state.rs','src/script/aggregate_error/install.rs','src/script/array_from.rs','src/script/microtasks.rs','src/script/construction.rs','src/script/promises/jobs.rs','src/script/promises/all_allocation_probe.rs']:
 if not (W/rel).exists(): continue
 b=(W/rel).read_bytes();assert b==git(rel);unchanged.append({'relative_path':rel,'bytes':len(b),'sha256':sha(b),'whole_file_published_equal':True})
held=[]
for rel in ['readiness-1/source-ready.json','budget-audit-1/selection-ready.json']:
 x=json.loads((N/rel).read_text())
 for item in x.get('files',x.get('artifacts',[])):
  p=Path(item['path']);b=p.read_bytes();assert sha(b)==item['sha256'];assert len(b)==item['bytes'];held.append(bind(p))
source_bindings=json.loads((N/'readiness-1/source-bindings.json').read_text())
for x in source_bindings['referenced_sources']:
 b=git(x['relative']);assert sha(b)==x['sha256'];assert len(b)==x['bytes']
public=[]
for h,name in [('public-contract-1','promise_any_semantic_tests.rs'),('public-contract-1','promise_any_abort_tests.rs'),('public-review-1','promise_any_input_tests.rs')]:
 p=N/h/'tests-raw/src/script'/name;q=W/'src/script'/name
 assert p.read_bytes()==q.read_bytes();public.append({'held':bind(p),'live':bind(q),'exact':True})
for row in rows: assert (W/row['relative_path']).read_bytes()==Path(row['candidate']['path']).read_bytes()
checks={'base':BASE,'source_parent':bind(N/'source-parent.json'),'changed_source_count':len(rows),'selected_inverse_rows':rows,'unchanged_reused_sources':unchanged,'held_files_checked':held,'readiness_published_source_bindings_checked':len(source_bindings['referenced_sources']),'public_payloads_unchanged':public,'candidate_stable_through_check':True,'execution':'Python standard-library source/hash/Git inspection only; no project imports, tests, compiler, engine, or live writes.'}
(R/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({'changed_paths':len(rows),'old_inverse_exact':True,'readiness_sources':len(source_bindings['referenced_sources']),'public_payloads_exact':len(public),'checks':bind(R/'checks.json')}))
