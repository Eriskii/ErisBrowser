from pathlib import Path
import json,hashlib
N=Path('/tmp/eris-promise-any-runtime-plan-1');R=N/'production-review-1'
def b(p):
 p=Path(p);v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
review={
 'status':'clear',
 'scope':'Independent source-only review of nine candidate production paths, selected admissions/readiness, and preservation of existing helper bodies. Not a compiler, runtime, test-outcome, physical-capacity or layout certification.',
 'base':'30576b1d977a6590099b5c4748abac9f188bc05c',
 'bindings':[b(N/p) for p in ['source-parent.json','root/implementation-selection.json','root/implementation-alignment-2.json','budget-audit-1/selection-ready.json','readiness-1/source-ready.json','public-contract-1/source-ready.json','public-review-1/source-ready.json']]+[b(R/'checks.json'),b(R/'verify.py')],
 'source_preservation':{'changed_paths':9,'all_nine_explicit_selected_inverses_recover_published_bytes':True,'old_all_allSettled_race_iterator_ready_and_array_helpers':'unchanged byte-for-byte; old factories differ only by exhaustive test-only AnyReject validation and the new separate factory','storage':'Only CallbackKind::AnyReject(AllCaptureId) added; State/Group/Element/Ready/Runtime fields unchanged. New ANY_METADATA_OBJECTS=1 leaves old METADATA_OBJECTS=11 exact.','public_tests':'All three frozen payloads exact; no expected literal or helper changes.','readiness':'All eight held artifacts and 26 parent-source bindings verified independently; selected budget artifacts hash-checked.'},
 'semantic_review':[
  'Capability construction and callback validity precede resolve Get; cached callable resolve precedes iterable acquisition. Acquisition publishes AllIterator only after successful next Get. Primitive nextPromise uses ordinary GetV with its original call receiver.',
  'Ordered placeholder precedes cached resolve call. Revalidated N1 AllElement factory publishes remaining count and distinct rejection gate before then Get. Capability resolve is passed unchanged to every then; repeated fulfillment neither consumes a reject gate nor stops iteration.',
  'Existing complete_all_element consumes a first rejection before any allocation/author reject; duplicates return undefined before moved storage and before payload retain. Normal exhaustion consumes the sentinel; abandoned iteration retains it.',
  'EOF invokes reject_any_ready within the ordinary-error closure. Its ordinary reject throw is passed to the outer reject exactly once more; done suppresses close and a second throw escapes. A saved final callback directly propagates its reject return/throw.',
  'Existing all_iterator_step caches next, gets done before value, skips value on done and marks ordinary next/done/value failures done. Post-yield resolve/then errors close acquired unfinished iterators; inherited array_from_close preserves original pending ordinary errors.',
  'Resource/Unsupported bypass outer author rejection/close. Fatal close propagates through exception_value; public operation, callback factory, completion helpers and intrinsic helper retain existing terminal observers. No new queue reset or job policy.',
  'Intrinsic result uses paid saved AggregateError map lookup, range validation, private branded object, unchanged dense Array helper, and writable/configurable nonenumerable errors own data. No public AggregateError/Array constructor, message/cause, species, iterable re-entry or inherited setter is consulted.'
 ],
 'fee_review':{
  'body':'Selected17 admitted first, then constructor clone1; existing capability1 plus constructor tick gives invalid-target20 direct/28 public. Resolve receiver1, items1, iterator receiver1, separate reject-group clone1, per-item resolve/C copies2, then receiver/shared resolve copies2 are admitted before their copies.',
  'reused':'Group18+growth, placeholder12+growth, N1 AllElement136+growth, complete duplicate12/first28, finish16, N1/N2 arguments10/12 retain old bodies/tariffs. Ordered elements fund payload lifetime; Ready transfers without refund.',
  'intrinsic':'Selected8 precedes lookup44 at26 prototypes; old branded object17 + dense array32 + errors-at0 property33 = warm134, with object/row growth additional. Producer-funded incoming list and stored reject lifetime cover failure before the new entry debit; fixed8 does not retroactively pay its own refusal.',
  'installer':'Entry12 scalar guards before texts; texts20+16+14, copies3, unchanged method52, insertion54 spare/72 growth =>171/189. Typed heap A+D+2K+Bpp+N+1179 plus10K on order growth; upfront extra object S. Existing insertion owns paid duplicate detection and physical growth; no unmetered map membership loop.',
  'identity':'Late installation after AggregateError preserves old object IDs and inserts new method bag754; object reservation becomes755. Native/prototype/global registry counts unaffected. Saved Promise Native metadata is used, no global lookup/clone.',
  'physical_qualification':'Both physical constructor-order branches remain conditional in this review. Actual enum/layout and startup measurements belong to root-owned validation.'
 },
 'primary_spec':{'url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-performpromiseany','read_date':'2026-10-15','sections':['27.5.4.3','27.5.4.3.1'],'fresh_primary_read':True,'finding':'Current direct EOF Reject and callback direct-return branches agree with the frozen selection; prior one-call EOF recollection is not used.'},
 'nonblocking_qualification':[{'path':'budget-audit-1/runtime-envelopes-selected.json','field':'intrinsic_helper.sequence[2].stage','wording':'The phrase saved Object prototype is a label error. The surrounding selected contract, readiness and candidate all use the saved AggregateError prototype. No sealed plan was edited; root notified.'}],
 'findings':[],
 'limits':['No project execution or live source edits.','No host decoder/upstream profile, Proxy/realm, cap, or full-compatibility change certified.','Migrations/private controls are separately assigned; this review does not substitute for their peers or root validation.']
}
(R/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(b(R/'review.json')))
