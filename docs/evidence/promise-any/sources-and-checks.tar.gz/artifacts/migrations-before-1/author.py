"""Selected old-test migrations, from published Git only; no project execution."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

H = Path(__file__).resolve().parent
N = H.parent
W = N / 'worktree'
BASE = '30576b1d977a6590099b5c4748abac9f188bc05c'
parent = json.loads((N / 'source-parent.json').read_text())['source_sha256']
manifest = []
edits = []
renames = []

def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(data)

def dump(path, data):
    write(path, json.dumps(data, indent=2) + '\n')

def load(suffix):
    global relative, before, text
    relative = 'src/script/' + suffix
    before = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=W, text=True)
    assert hashlib.sha256(before.encode()).hexdigest() == parent[relative]
    text = before

def replace(old, new, count=1, reason='selected late installer observation'):
    global text
    assert text.count(old) == count, (relative, old, text.count(old), count)
    owners = []
    for m in re.finditer(re.escape(old), text):
        functions = re.findall(r'^fn (\w+)\(', text[:m.start()], re.M)
        owners.append(functions[-1] if functions else '(module)')
    edits.append(dict(relative=relative, old=old, new=new, count=count, owners=owners, reason=reason))
    text = text.replace(old, new)

def objects(count):
    replace('objects.len(), 754', 'objects.len(), 755', count, 'one new late Any bag; old IDs and map counts unchanged')

def pair(count):
    replace('(754, 754)', '(755, 755)', count, 'one additional upfront object slot and one late bag')

def rename(old, new):
    replace('fn '+old+'()', 'fn '+new+'()', reason='test name tracks selected full bootstrap boundary')
    renames.append(dict(relative=relative, before=old, after=new))

def raw_rows():
    replace('(100_797, true, 0),\n        (1_000_000, true, 899_203),',
            '(100_797, false, 0),\n        (100_985, false, 0),\n        (100_986, true, 0),\n        (1_000_000, true, 899_014),',
            reason='retain all former input allowances; former success now refuses; add new one-short/exact and default remainder')

def finish():
    assert before != text
    replay = before
    for edit in [e for e in edits if e['relative'] == relative]:
        assert replay.count(edit['old']) == edit['count']
        replay = replay.replace(edit['old'], edit['new'])
    assert replay == text
    bp = H / 'before' / relative
    rp = H / 'raw' / relative
    dp = H / 'diffs' / (relative + '.patch')
    write(bp, before); write(rp, text)
    write(dp, ''.join(difflib.unified_diff(before.splitlines(True), text.splitlines(True), fromfile='a/'+relative, tofile='b/'+relative)))
    manifest.append(dict(relative=relative, before=binding(bp), raw=binding(rp), diff=binding(dp)))

load('bootstrap_tests.rs')
replace('assert_eq!(reference.steps, 899_203);', '// Late Promise.any adds189 work and one bag; existing installer tariffs remain exact.\n    assert_eq!(reference.steps, 899_014);')
objects(1); finish()

load('dom_bindings/identity_tests.rs'); objects(1); finish()
load('node_data/key_cache_fee_tests.rs'); pair(2); finish()
load('node_data/key_cache_tests.rs'); objects(1); finish()
load('node_data/method_key_tests.rs'); objects(1); finish()

load('processing_instruction/display_key_tests.rs')
rename('startup_headroom_raw_observation_precedes_the_frozen_100797_work_witness', 'startup_headroom_raw_observation_precedes_the_frozen_100986_work_witness')
objects(1); replace('objects.capacity() >= 754', 'objects.capacity() >= 755')
replace('BOOTSTRAP_STEPS - runtime.steps, 100_797', 'BOOTSTRAP_STEPS - runtime.steps, 100_986')
replace('runtime.steps, 899_203', 'runtime.steps, 899_014'); finish()

load('processing_instruction/key_cache_tests.rs')
rename('cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_100797_work_boundary', 'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_100986_work_boundary')
raw_rows(); objects(1); finish()

load('promises/install_tests.rs')
objects(1)
replace('objects.len(), 765', 'objects.len(), 766', 2, 'unchanged eleven-bag standalone replay starts after755 existing bags')
rename('promise_full_raw100797_and_public_reset_preserve_empty_paid_arenas', 'promise_full_raw100986_and_public_reset_preserve_empty_paid_arenas')
raw_rows(); pair(1); finish()

load('promises/shared_key_tests.rs')
# Descending destinations avoid replacing one just-shifted assertion twice.
replace('objects.len(), 766', 'objects.len(), 767', reason='unchanged twelve-bag producer/consumer replay starts after755 bags')
replace('objects.capacity() >= 766', 'objects.capacity() >= 767')
replace('objects.len(), 755', 'objects.len(), 756', 3, reason='unchanged producer adds one bag to new755 fixture base')
replace('objects.len(), 754', 'objects.len(), 755', 2)
replace('assert_eq!(owner, 754);', 'assert_eq!(owner, 755);', reason='new producer replay bag index, not an existing intrinsic ID')
replace('runtime.objects[754].values.len()', 'runtime.objects[755].values.len()', reason='new producer replay bag index')
replace('new100797 boundary', 'new100986 boundary', reason='comment follows full bootstrap witness; replay costs unchanged')
finish()

load('promises/shared_key_identity_tests.rs')
objects(1); replace('objects.capacity(), 754', 'objects.capacity(), 755')
replace("length,name,prototype,resolve,reject,all,race,allSettled'", "length,name,prototype,resolve,reject,all,race,allSettled,any'", reason='actual Promise own-name membership includes the new late method; old method metadata/IDs remain exact')
finish()

load('text_operations/key_cache_tests.rs')
objects(3); replace('objects.capacity(), 754', 'objects.capacity(), 755', 2)
rename('text_metadata_keys_raw_bootstrap_uses_100797_work_and_preserves_public_reset', 'text_metadata_keys_raw_bootstrap_uses_100986_work_and_preserves_public_reset')
replace('// work and two bags; preserve the former raw inputs below as refusals.', '// work and two bags; late Promise.any adds189 work and one bag.\n    // Preserve the former raw inputs below as refusals.')
raw_rows(); finish()

load('typed_array/tests.rs')
replace('    // The cumulative remainder below starts from MAX_STEPS;',
        '    // Late Promise.any preserves both earlier installers and grows the\n    // constructor order from9 to10; its one slot is reserved upfront.\n    let any_added = s + a + d + 12 * k + bpp + n + 1179;\n    // The cumulative remainder below starts from MAX_STEPS;',
        reason='selected typed whole-bootstrap heap delta including10K order growth and upfrontS')
replace('            - 1103\n', '            - 1103\n            - 189\n', reason='selected late installer work in the retained cumulative expression')
replace('            + aggregate_error_added\n', '            + aggregate_error_added\n            + any_added\n', reason='add selected typed late installer heap to retained cumulative expression')
pair(1); finish()

load('test262_host/quota_tests.rs')
replace('runtime.steps, 899_203', 'runtime.steps, 899_014'); objects(1); finish()

for suffix in ['promise_semantic_tests.rs', 'promise_race_semantic_tests.rs']:
    load(suffix)
    replace("length,name,prototype,resolve,reject,all,race,allSettled'", "length,name,prototype,resolve,reject,all,race,allSettled,any'", reason='actual Promise own-name membership includes the new method; every other JS literal remains exact')
    finish()

assert len(manifest) == 15 and len(renames) == 4
dump(H / 'edit-manifest.json', dict(base=BASE, edits=edits, function_renames=renames))
dump(H / 'scope.json', {
    'status': 'source-derived selected migrations only; no project execution or future production source read',
    'base': BASE, 'files': 15, 'renamed_groups': 4,
    'basis': {'work_delta': 189, 'heap_delta': 'S+A+D+12K+Bpp+N+1179', 'raw_work': 100986, 'raw_remaining': 899014, 'objects': 755},
    'capacity_qualification': 'Root selected normal constructor-order growth; exact physical capacity and actual bootstrap totals require root observation. These expected expressions derive from the selected recipe, not measured candidate outputs.',
    'old_explicit_inputs': [99693,99694,100000,100796,100797],
    'new_boundary_inputs': [100985,100986],
    'unchanged': ['all cap constants and public reset100000','old Promise standalone1570/shared1532/pair1863 fees and helper heap equations','old eleven-bag replay admission and all old malformed-state controls','AggregateError prototype752/constructor753 and isolated installer1103/prefix99694 controls','global213/native300/prototype26 counts','old private per-operation work/heap limits','ArrayBuffer/DataView earlier-stage prototype exclusions','all JS payloads except the three explicit Promise own-name membership strings'],
    'census': 'Layout15-path census plus independent published Git search for raw100797/899203/754/replay765/766 and exact own-name strings. Cumulative typed-array arithmetic is explicitly included.',
    'no_live_edits': True
})
seal = {'status': 'source_ready_selected_historical_migrations', 'base': BASE,
        'source_parent': binding(N/'source-parent.json'),
        'implementation_selection': binding(N/'root/implementation-selection.json'),
        'fee_selection': binding(N/'budget-audit-1/selection-ready.json'),
        'scope': binding(H/'scope.json'), 'edit_manifest': binding(H/'edit-manifest.json'),
        'author': binding(H/'author.py'), 'files': manifest,
        'qualification': 'Only15 existing test files; no production/new tests/limits/old helper tariff edits. Root owns import, formatting and execution.'}
dump(H/'source-ready.json', seal)
print(json.dumps(binding(H/'source-ready.json')))
