#!/usr/bin/env python3
"""Inert stdlib source-readiness author; never imports or executes project code."""
import hashlib
import json
from pathlib import Path
import subprocess

H = Path(__file__).resolve().parent
N = H.parent
W = N / "worktree"
O = Path("/tmp/eris-promise-any-plan-1")
BASE = "30576b1d977a6590099b5c4748abac9f188bc05c"
RUST_BASE = "d3efc9aba87102366b538ff69e83c2524a48eb6b"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def record(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": digest(data)}

def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

parent = json.loads((N / "source-parent.json").read_text())
assert parent["base"] == BASE and len(parent["source_sha256"]) == 1730
paths = [
    "Cargo.toml", "Cargo.lock", "src/script.rs", "src/script/promises.rs",
    "src/script/promises/all_semantics.rs", "src/script/promises/all_state.rs",
    "src/script/promises/factories.rs", "src/script/promises/semantics.rs",
    "src/script/promises/install.rs", "src/script/promises/install_tests.rs",
    "src/script/promises/shared_key_tests.rs", "src/script/promises/all_quota_tests.rs",
    "src/script/promises/all_semantics/race_quota_tests.rs",
    "src/script/promises/all_state/all_settled_quota_tests.rs",
    "src/script/promises/all_settled_layout_tests.rs", "src/script/aggregate_error.rs",
    "src/script/aggregate_error/quota_tests.rs", "src/script/aggregate_error/install.rs",
    "src/script/aggregate_error/install/tests.rs", "src/script/machine/calls.rs",
    "src/script/construction.rs", "src/script/array_from.rs", "src/script/microtasks.rs",
    "src/script/bootstrap_tests.rs", "src/script/dom_prototypes.rs",
    "src/script/typed_array/tests.rs", "src/script/dom_prototype_helpers.rs",
]
# Resolve the existing helper filename rather than inventing a second implementation.
if paths[-1] not in parent["source_sha256"]:
    paths.pop()
    matches = subprocess.check_output(["git", "grep", "-l", "fn dom_proto_property(", BASE, "--", "src/script"], cwd=W, text=True).splitlines()
    candidates = [p.split(":", 1)[1] for p in matches]
    assert len(candidates) == 1, candidates
    if candidates[0] not in paths:
        paths.append(candidates[0])
bindings = []
for relative in paths:
    data = subprocess.check_output(["git", "show", f"{BASE}:{relative}"], cwd=W)
    prior = subprocess.check_output(["git", "show", f"{RUST_BASE}:{relative}"], cwd=W)
    assert data == prior
    assert digest(data) == parent["source_sha256"][relative]
    blob = subprocess.check_output(["git", "rev-parse", f"{BASE}:{relative}"], cwd=W, text=True).strip()
    bindings.append({"relative": relative, "bytes": len(data), "sha256": digest(data),
                     "git_blob": blob, "published_and_prior_rust_bytes_equal": True})
changed = subprocess.check_output(["git", "diff", "--name-only", RUST_BASE, BASE], cwd=W, text=True).splitlines()
assert not [p for p in changed if p.endswith(".rs") or p in ("Cargo.toml", "Cargo.lock")]
write("source-bindings.json", {
    "base": BASE, "rust_base": RUST_BASE, "source_parent": record(N / "source-parent.json"),
    "parent_selected_inputs": 1730, "referenced_sources": bindings,
    "tooling_only_intervening_commit": {"changed_paths": len(changed), "rust_or_cargo_changes": []},
    "original_immutable_plan": [record(O / name) for name in (
        "source-ready.json", "plan.json", "architecture.json", "resource-outline.json",
        "semantic-cases.json", "terminal-cases.json", "html-literal-review-1/review.json")],
    "no_claim": "These are published source joins, not candidate compilation, measurement or execution."
})

write("spec-and-selection.json", {
    "date": "2026-10-15",
    "primary_url": "https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.any",
    "perform_url": "https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-performpromiseany",
    "callback_url": "https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.any-reject-element-functions",
    "cache": record(H / "spec-cache/current-primary-web.json"),
    "current_draft_sections": ["27.5.4.3", "27.5.4.3.1", "27.5.4.3.2"],
    "observable_summary": [
        "Construct the generic capability before caching C.resolve and before acquiring the input iterator.",
        "Reserve each ordered error position before calling cached resolve with C; create a distinct once-only rejection function and increment the count before obtaining then. Pass the original capability resolve directly.",
        "Exhaustion consumes the sentinel. If no rejection remains, create the intrinsic AggregateError and call the stored rejection function; otherwise return the capability promise.",
        "A saved final rejection callback completes the ordered list and directly returns or throws its reject call. Duplicates return undefined.",
        "An ordinary exhaustion reject throw reaches the outer rejection once more. The iterator is already done, so no close occurs. A second ordinary reject throw escapes."
    ],
    "spec_check_correction": {
        "initial_root_suggestion": "Create/throw AggregateError at EOF and reject only once in the outer path.",
        "resolution": "Rejected after independent current-primary checks by Script, HTML and root. Select direct EOF Reject call and outer ordinary retry, consistent with the immutable original literal.",
        "original_preserved": "any_empty_custom_reject_throw_is_rejected_again",
        "source_and_expectations_changed": False,
        "terminal_qualification": "ResourceLimit/Unsupported bypass the ordinary outer retry. Saved callbacks never re-enter the outer Promise.any operation."
    },
    "host_boundary": "Existing finite-work/heap terminal stops and unhandled-rejection audit are host policy. The runtime checkpoint does not broaden the seven-name default/ERJR3 decoder or create a Promise.any upstream profile."
})

write("plan.json", {
    "status": "source-only readiness and concrete implementation proposal; no production or execution",
    "base": BASE,
    "scope": ["Promise.any intrinsic metadata and native routing", "one rejection callback tag using existing Group/Element storage", "intrinsic AggregateError creation from an owned ordered reasons vector", "local semantic, terminal, layout and resource tests with explicit installer migrations"],
    "completed_prerequisites": [
        "Published AggregateError construction, saved map-backed intrinsic prototype and private Error branding.",
        "Published dense intrinsic Array publication reusable without public constructor, iterator, setters or species.",
        "Published BOOTSTRAP_STEPS=1000000, with successful Runtime construction restoring author MAX_STEPS=100000 and unchanged MAX_HEAP=8MiB.",
        "Published all/allSettled/race capability, iterator, callback, count/sentinel, FIFO and terminal-observer machinery."
    ],
    "remaining_before_production": [
        "Bind the selected late-installer171/189 conditional tariff to measured constructor-order physical capacity. Preserve existing bags752/753 and old Promise installer tariffs; append new metadata bag754 with upfront capacity755.",
        "Apply selected body17, explicit group reject clone1, and intrinsic error helper8. Preserve producer-funded transferred Vec teardown on admission refusal and all existing helper fees.",
        "Measure a complete source-derived CallbackKind/CallbackRecord mirror with AnyReject(AllCaptureId), plus actual dependent layouts, before relying on unchanged numeric widths.",
        "Public/terminal controls are frozen. Freeze the bounded private resource suite and precise old-test migrations before importing production.",
        "Independent source review and root-owned parent observations, candidate checks and replay comparisons."
    ],
    "architecture": "Reuse Group.resolve to own the reject clone; the historical field name and ReadyAllValues shape remain unchanged. Add CallbackKind::AnyReject(AllCaptureId), with a single immutable native callable per element. No Runtime/State/PromiseJob field or new arena.",
    "installer_choice": {
        "selected": "Separate late install_promise_any_intrinsic(), after AggregateError, using saved Promise intrinsics. This preserves prior installer helper bodies/tariffs and all existing metadata IDs, while admitting one new bag and a constructor property. Total171 without order growth,189 with growth.",
        "earlier_unselected_comparison": "Appending any to the existing Promise installer derives +122work and shifts AggregateError752/753 to753/754. This is not the preferred late recipe and must not be reused as its tariff.",
        "unchanged_limits": {"bootstrap_work": 1000000, "author_work": 100000, "heap_bytes": 8388608},
        "selection": record(N / "root/implementation-selection.json"),
        "independent_ledger": record(N / "budget-audit-1/selection-ready.json")
    },
    "non_goals": ["Promise.any upstream corpus/profile", "host identity or completion-policy changes", "caps or allowance resets", "new parser syntax", "new public AggregateError behavior", "renaming old storage fields", "refactoring old combinator bodies"],
    "preservation": "Keep current five upstream profile case/control arrays (1100/400 total) and their policies/baselines exact. Keep old helper tariff bodies and local semantic expectations exact except explicitly selected installer/whole-bootstrap observations.",
    "no_outcome_prediction": True
})

write("interfaces-and-order.json", {
    "proposed_natural_helpers": [
        {"path": "src/script/promises/all_semantics.rs", "signature": "pub(super) fn promise_any(&mut self, constructor: Value, args: &[Value], doc: &mut Document) -> Result<Value>", "purpose": "generic combinator with existing AllIterator and ordinary-close path"},
        {"path": "src/script/promises/factories.rs", "signature": "pub(super) fn new_any_reject_element(&mut self, group: AllCaptureId, index: usize) -> Result<Value>", "purpose": "existing build_promise_callbacks<N=1>, FactoryExtra::AllElement, AnyReject tag"},
        {"path": "src/script/promises/all_semantics.rs", "signature": "pub(super) fn run_any_callback(&mut self, element: AllCaptureId, args: &[Value], doc: &mut Document) -> Result<Value>", "purpose": "borrow first argument; existing complete_all_element; duplicate/nonfinal undefined, final reject_any_ready"},
        {"path": "src/script/promises/all_semantics.rs", "signature": "fn reject_any_ready(&mut self, ready: ReadyAllValues, doc: &mut Document) -> Result<Value>", "purpose": "move stored reject and reasons; intrinsic error helper; paid N1 arguments; Call(reject, undefined); propagate result"},
        {"path": "src/script/aggregate_error.rs", "signature": "pub(super) fn intrinsic_aggregate_error_from_list(&mut self, values: Vec<Value>) -> Result<Value>", "purpose": "saved prototype, private branded object, dense errors array, hidden own-data errors; terminal observer"}
    ],
    "minimal_runtime_touchpoints": {
        "src/script/promises.rs": "Add AnyReject tag only; installer module/constant separately selected.",
        "src/script/promises/factories.rs": "New one-element factory and exhaustive cfg(test) None validation arm; old factories remain byte-exact apart from necessary exhaustive classification.",
        "src/script/promises/semantics.rs": "Promise.any native branch and AnyReject callback branch; callback_target remains the immutable identity authority.",
        "src/script/promises/all_semantics.rs": "New body/ready/callback helpers; old iterator/combinator helpers unchanged.",
        "src/script/aggregate_error.rs": "New intrinsic-only helper reusing its existing private object/data helpers and already-visible dense array helper.",
        "src/script/machine/calls.rs": "Add Promise.any to the exact native-operation route. Existing constructor classification already makes these method natives nonconstructible."
    },
    "body_order": [
        "Prepay fixed outer body envelope; prepay constructor copy; call new_promise_capability before entering the reject-conversion closure.",
        "Prepay and obtain cached C.resolve, require callable. Only then retain input, Get @@iterator, call with input receiver, require object, retain iterator for cached next Get. Publish acquired AllIterator only after successful next Get.",
        "Prepay one reject clone and pass it to new_all_group. The original reject remains outer-owned; original resolve remains shared into every then.",
        "Use unchanged all_iterator_step: prepaid attempt/copies; cached next with iterator receiver; object check; done Get before value; ordinary step error marks Done; done=true skips value.",
        "For each value, append indexed Undefined placeholder, prepay cached resolve/C copies, allocate paid N1 args and Call cached resolve with C.",
        "Create exactly one AnyReject function via the old N=1 AllElement factory. It revalidates the current Group after author resolve, prepares checked remaining+1 and atomically publishes count/Element/callback only after allocation succeeds.",
        "Prepay two retained copies (Get receiver and shared capability resolve), Get then, build paid N2 args [resolve.clone(), reject_element], then Call with next_promise receiver. A synchronous fulfill does not stop iteration.",
        "On normal exhaustion only, finish_all_input consumes the sentinel and marks input_done. If Ready exists, call reject_any_ready and discard its normal return. Return the original capability promise.",
        "On ordinary closure error, close only a fully acquired unfinished iterator, preserve ordinary pending-error identity, turn completion into a Value, build paid N1 args and call original reject once. A failure in this outer call escapes; no recursion.",
        "Terminal closure or fatal close errors propagate through existing observers without author reject, further close, catch/finally, or queue resumption."
    ],
    "intrinsic_error_order": [
        "Admit the new fixed helper envelope before lookup. Incoming Vec teardown on refusal is already funded by Group/Ready producer provenance.",
        "Charge saved AggregateError prototype lookup, read the saved map key and validate object ID. No global AggregateError, mutable constructor.prototype, species, or author property Get.",
        "Use existing new_aggregate_error_object to admit one object and set private intrinsic_error=AggregateError.",
        "Move reasons into existing new_all_values_array. Preserve its cumulative logical storage charges and terminal observer; no refund for prior Group storage.",
        "Use existing define_aggregate_error_data at count0 to publish hidden writable/configurable errors data. Return the branded object; do not add message/cause or reiterate the already-collected list."
    ],
    "completion_invariants": [
        "Only reject has a per-element once bit. Resolve is shared and repeatable for a generic constructor; fulfillment never consumes the rejection gate.",
        "First rejection preserves exact payload identity in input-index order, consumes its gate and decrements count before any final AggregateError allocation or author reject call.",
        "Duplicates return undefined before touching moved-out Group values and before payload retain/allocation. A final construction/reject failure does not reset the gate.",
        "Aborted iteration does not consume the sentinel, so later saved callbacks cannot finalize that abandoned group.",
        "EOF and callback share reject_any_ready, but only EOF runs inside the outer closure and can cause an ordinary second rejection."
    ],
    "jobs_and_unhandled": "Use existing reaction jobs, FIFO, handled flags and checkpoint boundaries. Input promises acquire rejection handlers through ordinary then. A thrown callback invoked by a native reaction rejects its ordinary derived capability; do not suppress resulting unhandled rejection records. Local catches/handlers should make intended tests healthy. The seven-name ERJR3 decoder and host policy remain unchanged; a future Any upstream profile must handle its capability decision separately."
})

write("resource-facts.json", {
    "status": "exact existing-helper equations plus selected new envelopes; no new measurements",
    "symbols": {
        "S": "size_of::<ScriptObject>()", "V": "size_of::<Value>()", "A": "size_of::<Option<AbortSlot>>()",
        "D": "size_of::<Option<f64>>()", "K": "size_of::<PropertyKey>()", "N": "size_of::<Native>()",
        "Bpp": "16*(size_of::<PropertyKey>()+size_of::<Property>())+32*size_of::<usize>()+64",
        "G_T": "existing growth_plan<T>(len, admitted, append); object and ordinary row plans additionally charge newly retained row bytes"
    },
    "existing_growth": {
        "guards": "width!=0; len<=admitted; checked len+append; need<=MAX_HEAP/width; checked arithmetic",
        "spare": "work0, heap0, no target when need<=admitted",
        "growth_target": "min(MAX_HEAP/width, max(2*admitted,8,next_power_of_two(need)))",
        "growth_work": "8+2*len*ceil(width/V)", "growth_heap": "32+target*width",
        "scope": "No change to old helper validation or cap. Do not apply unrelated call-spread65536 cap or refund previous storage."
    },
    "exact_reused_tariffs": [
        {"stage": "public native wrapper", "work": "8", "heap": "0 before selected body"},
        {"stage": "new_all_group", "work": "18+G_AllCapture.work", "heap": "G_AllCapture.bytes"},
        {"stage": "append placeholder", "work": "12+G_Value.work", "heap": "G_Value.bytes"},
        {"stage": "cached iterator attempt", "work": "8 plus retained copies2 then1, plus old Get/Call fees", "heap": "existing Get/Call only"},
        {"stage": "N1 AllElement callback factory", "work": "136+G_CallbackRecord.work+object_slot_plan(1).work+G_AllCapture.work", "heap": "old metadata+object row+three growth plans; no new typed payload"},
        {"stage": "duplicate rejection element", "work": "12", "heap": "0; no Group read or payload clone"},
        {"stage": "first rejection element", "work": "28 before ready processing", "heap": "0 in complete_all_element itself; funded payload handle copy"},
        {"stage": "finish sentinel", "work": "16 before ready processing", "heap": "0"},
        {"stage": "paid N1/N2 arguments", "work": "10/12", "heap": "32+N*V"},
        {"stage": "saved AggregateError map lookup at26", "work": "44", "heap": "0"},
        {"stage": "branded object", "work": "17+object_slot_plan(1).work", "heap": "object_slot_plan.bytes+72+A+D+3K"},
        {"stage": "dense intrinsic Array", "work": "32+five destination-plan work terms", "heap": "logical32+n*V plus object/four row plan bytes plus bag72+A+D"},
        {"stage": "errors own-data field at0", "work": "33", "heap": "368+Bpp"}
    ],
    "selected_new_envelopes": {
        "body": {"work": 17, "basis": "existing race8-control+9-outer-owner envelope; Any retains resolve and original reject, while Group owns a separate reject copy", "additional_copies": "group reject1; per value cached resolve/C2; Get receiver/shared resolve2; existing acquisition copies unchanged"},
        "intrinsic_error": {"work": 8, "symbol": "F", "basis": "selected four transitions (saved prototype selection, prototype-ID validation, array conversion dispatch, branded-object return) plus four cleanup roles (incoming Vec shell, prototype temporary, object result temporary, array temporary)", "incoming_refusal": "F cannot pay for destruction if its own first work debit fails. Existing Group/Ready producer ownership funds the transferred reasons and stored reject, as in the existing ready-result path.", "selection": record(N / "root/implementation-selection.json")}
    },
    "derived_natural_cuts": {
        "body_invalid_constructor": "20 under selected body17; public native wrapper28. 19/27 must refuse before invalid-constructor ordinary TypeError. Caller-owned input is prepared before measurement.",
        "warm_factory": "135 refuses /136 succeeds when callback, AllCapture and object backing are already admitted; count and callback publication remain atomic.",
        "duplicate": "11 refuses /12 returns undefined without allocation; first valid nonfinal completion27 refuses /28 records value and called bit.",
        "warm_intrinsic_error": "F+44+17+32+33 = F+126; selected F8 =>134. Conditions: two object slots spare, all four Array row vectors spare, coherent saved Array and AggregateError intrinsics, fresh ordered bags.",
        "warm_intrinsic_heap": "2*S+2*A+2*D+3*K+Bpp+n*V+size_of::<Vec<Value>>()+size_of::<usize>()+size_of::<BTreeSet<usize>>()+size_of::<ArrayLength>()+544",
        "final_callback_before_dynamic_call": "28+(F+126)+10 = F+164, plus unchanged callback dispatch and dynamic Call tariffs; selected F8=>172 before those tariffs.",
        "EOF_ready_before_dynamic_call": "16+(F+126)+10 = F+152, plus iterator/end-body/dynamic Call tariffs; selected F8=>160 for this isolated suffix only.",
        "qualification": "These are source-derived staged suffixes, not whole script totals or observed engine results. Growth, setup, native dispatch, dynamic Call and metadata fees must never be silently omitted from a full-operation oracle."
    },
    "layout": {
        "existing_x86_64_linux": {"CallbackKind": 16, "CallbackRecord": 24, "State": 256, "AllCapture": 72, "ReadyAllValues": 48, "PromiseJob": 128, "QueueJob": 24, "Runtime_default": 1808, "Runtime_test262_host": 1872},
        "proposal": "AnyReject(AllCaptureId) has an existing payload class, but enum layout is not guaranteed. Build complete actual-source parent/proposed mirrors and compare all affected rows in root-owned MSRV/default+host and current/default+host-vulkan configurations.",
        "if_unchanged": "Old callback movement1, AllCapture movement3, cold callback backing224 and Runtime header2048 stay literal controls; no existing shape oracle is retuned without independent measurement.",
        "new_measurements": False
    },
    "bootstrap": {"published_consumed": 100797, "published_remaining": 899203, "published_objects": 754, "prospective_new_objects": 755, "selected_late_installer": {"work_no_growth": 171, "work_growth": 189, "heap_no_growth": "A+D+2K+Bpp+N+1179", "heap_growth_extra": "10K", "extra_upfront_slot": "S"}, "derived_consumed": {"no_growth": 100968, "growth": 100986}, "derived_remaining": {"no_growth": 899032, "growth": 899014}, "qualification": "Physical capacity must be observed before selecting either numeric whole-bootstrap branch; +122 only describes the earlier unselected append-to-existing-installer alternative."}
})

write("local-validation-plan.json", {
    "status": "prospective local scope; executable holds and actual outcomes remain separate",
    "public_contract": record(N / "public-contract-1/literal-ready.json"),
    "public_scope": "17 semantic groups/34 modes: original13 exact plus four selected receiver/cache, close-matrix, checkpoint/brand, and EOF retry/second-throw discriminators. Five terminal groups/ten sources/twenty modes are separate.",
    "parent_eligibility": "Public helpers use current Runtime APIs, so root can observe absent-method guard failures before production. New Any private helpers/tags are parent-ineligible; do not claim their parent execution. Complete mirrors can run on parent without production.",
    "private_groups": [
        {"id": "admission", "purpose": "Body and public wrapper exact/one-short controls before getter/iterator/allocation, with caller-owned handle release, unchanged arena lengths and sticky public terminal observer."},
        {"id": "callback_factory", "purpose": "One rejection callable per input, shared resolve identity, exact warm factory debit and selected cold work/heap refusal. Reserve failures leave Element/count/callback publication unchanged; use existing probes without widening them."},
        {"id": "gate_and_sentinel", "purpose": "12 duplicate and28 first cuts, no retained payload copy on duplicate, reverse completion preserves ordered identities, malformed ID/count/index refuses, input_done sentinel blocks post-abort completion, duplicate after moved-out/final-throw remains undefined."},
        {"id": "intrinsic_aggregate", "purpose": "Missing saved prototype fails before object; warm object/Array/errors staged boundaries with source-derived budgets; saved prototype/array/private brand; no public constructors, getters or setters; final errors-field refusal retains only paid internal publication."},
        {"id": "terminal_coupling", "purpose": "Natural final callback and EOF transitions into new helper using old Array allocation probe. Gate/sentinel remains consumed, no author reject/close/finally, queued sentinel remains suspended. Test borrowed state/checkpoint after heap refusal, avoiding execute/reset on allocated>MAX_HEAP."},
        {"id": "layout_and_startup", "purpose": "Complete source mirrors before production, permanent qualified actual layout afterward; selected late-installer guards/exact/one-short and cumulative bootstrap work/heap/one-extra-bag migrations."}
    ],
    "test_constraints": [
        "Freeze scalar/trace/error-kind/identity expectations from source before candidate execution. Keep setup outside the measured operation and precreate all author functions, including iterator methods returned by getters.",
        "Use natural production helpers and current probes; no alternate implementation or fee-mirroring helper.",
        "Do not duplicate the old dense-array five-stage suite; select new Any-to-helper ownership/terminal boundaries and preserve that old suite.",
        "Qualify numeric layout observations to measured x86_64 Linux; keep generic size_of formulas on other targets.",
        "Retain old explicit100000 and earlier raw-work inputs as truthful refusal controls; separately add selected new exact/one-short full-bootstrap rows and default1m remainder."
    ],
    "root_validation": [
        "Read-only baseline inventory, public absent-method observations and complete mirror measurements before production import.",
        "Focused frozen semantic/terminal/private/installer groups and relevant page/worker paths after reviewed implementation.",
        "Both full Rust configurations, strict Clippy configurations, formatter check, release build and required Python controls, using unchanged caps.",
        "Exact case/control array replays of the existing five profiles1100/400 with unchanged policies/baselines; any change requires investigation, not rebasing away a failure."
    ],
    "exclusions": "No upstream Promise.any corpus/gate/baseline, no host-identity extension, no pass-count prediction, no repeated old execution claimed for this planning hold."
})

print(json.dumps({"authored": sorted(p.name for p in H.glob("*.json")), "source_joins": len(bindings)}))
