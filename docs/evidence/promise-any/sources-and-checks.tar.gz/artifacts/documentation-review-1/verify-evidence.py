from pathlib import Path
import json, hashlib, re, collections
N=Path('/tmp/eris-promise-any-runtime-plan-1')
OUT=N/'documentation-review-1'
def read(rel): return json.loads((N/rel).read_text())
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def bind(path):
 p=Path(path);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def bound(x):
 out=[]
 if isinstance(x,dict):
  if {'path','sha256'} <= x.keys():
   p=Path(x['path']);assert sha(p)==x['sha256'],str(p)
   if 'bytes' in x: assert p.stat().st_size==x['bytes'],str(p)
   out.append(bind(p))
  for v in x.values():out.extend(bound(v))
 elif isinstance(x,list):
  for v in x:out.extend(bound(v))
 return out
ledger=read('root/final-validation.json');refs=bound(ledger)
assert ledger['source']==bind(N/'source-final-2.json')
source=read('source-final-2.json')['source_sha256'];assert len(source)==1735
assert all(sha(N/'worktree'/p)==v for p,v in source.items())
roster=read('root/rust-validation.json');bound(roster)
full=[]
for comp in roster['comparisons']:
 for side in ['current','previous']:
  x=comp[side];p=Path(x['log']['path']);s=p.read_text()
  rows=[list(map(int,m)) for m in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s,re.M)]
  assert len(rows)==x['result_rows']==52
  assert [sum(a[i] for a in rows) for i in range(5)]==x['totals']
  assert len(set(x['passed_names']))==len(x['passed_names'])==x['totals'][0]
  r=json.loads(Path(x['receipt']['path']).read_text());assert r['exit']==0 and sha(p)==r['sha256']
 renames={v['before']:v['after'] for v in comp['renames']};assert len(renames)==4
 assert {renames.get(v,v) for v in comp['previous']['passed_names']}|set(roster['new_names'])==set(comp['current']['passed_names'])
 assert len(roster['new_names'])==38
 full.append({'receipt':comp['current']['receipt'],'log':comp['current']['log'],'rows':52,'totals':comp['current']['totals'],'old_names_plus_4_renames_plus_38_new':True})
strict=[]
for rel in ['clippy-default-1','clippy-host-vulkan-1','fmt-check-1','any-release-host-1','any-release-ordinary-1']:
 p=N/'validation'/f'{rel}.json';r=json.loads(p.read_text());log=p.parent/r['log'];assert r['exit']==0 and sha(log)==r['sha256'];strict.append({'receipt':bind(p),'log':bind(log)})
binaries=[]
for label in ['host','ordinary']:
 p=N/f'eris-js-{label}-1.json';b=json.loads(p.read_text());assert sha(b['binary'])==b['sha256'] and Path(b['binary']).stat().st_size==b['bytes'];assert sha(b['source_inventory'])==b['source_sha256'];binaries.append({'receipt':bind(p),'binary':bind(b['binary'])})
profiles=[]
for row in read('root/profile-validation.json')['rows']:
 name=row['profile'];p=N/f'upstream-{name}-1.json';q=N/'replay-parent'/p.name;a=json.loads(p.read_text());b=json.loads(q.read_text())
 assert sha(p)==row['sha256'] and sha(q)==row['parent_sha256']
 for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:assert a[key]==b[key],(name,key)
 assert len(a['cases'])==row['cases'] and len(a['harness_preflight'])==row['controls']
 assert a['regressions']==a['improvements']==[] and a['harness_preflight_passed'] is True
 assert a['binary_sha256']==sha(a['binary'])
 assert collections.Counter(c['status'] for c in a['cases'])==a['counts']
 profiles.append({'profile':name,'report':bind(p),'parent':bind(q),'cases':len(a['cases']),'controls':len(a['harness_preflight']),'counts':a['counts'],'complete_arrays_exact':True})
assert sum(r['cases'] for r in profiles)==1100 and sum(r['controls'] for r in profiles)==400
initial=read('root/full-first-interruption.json');s=(N/'validation/default-full-1.log').read_text();assert sha(N/'validation/default-full-1.log')==initial['log_sha256'];assert 'test result: FAILED. 2848 passed; 9 failed; 0 ignored; 0 measured; 0 filtered out;' in s;assert len(initial['failures'])==9 and initial['not_full_suite_completion']
startup=read('root/startup-observation.json');s=(N/'validation/any-private-1.log').read_text();assert startup['raw_line'] in s and sha(N/'validation/any-private-1.log')==startup['log_sha256']
assert startup['work']==100986 and startup['remaining']==899014 and startup['accounted_heap']==1765018
assert startup['delta']=={'work':189,'accounted_heap':3147,'objects':1}
layouts=[]
for x in read('root/layout-verification.json')['rows']:
 p=N/'validation'/f"{x['label']}.json";r=json.loads(p.read_text());assert sha(p)==x['record_sha256'] and r['exit']==0;assert sha(p.parent/r['log'])==r['sha256'];layouts.append({'label':x['label'],'receipt':bind(p),'runtime':x['layout']['Runtime']['bytes']})
out={'status':'clear','scope':'Independent stdlib evidence checks for documentation claims; no project execution. Source inventory is the selected inventory, not a complete build graph.','ledger':bind(N/'root/final-validation.json'),'source':bind(N/'source-final-2.json'),'source_inputs_checked':len(source),'ledger_references_checked':len(refs),'full_suites':full,'strict_and_builds':strict,'binaries':binaries,'profiles':profiles,'startup':startup,'layouts':layouts,'first_full_interruption':bind(N/'root/full-first-interruption.json'),'first_migration_peer_limitation':'The original peer missed the old scalar count assertion; original hold/review remain unchanged. One assertion correction and the original interrupted output remain retained.'}
(OUT/'evidence-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'clear','source_inputs':len(source),'full_totals':[x['totals'] for x in full],'profiles':len(profiles),'case_records':1100,'control_records':400,'output':bind(OUT/'evidence-checks.json')}))
