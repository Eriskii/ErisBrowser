from pathlib import Path
import json,hashlib,difflib,subprocess
N=Path('/tmp/eris-promise-any-runtime-plan-1');D=N/'documentation-1';O=N/'documentation-review-1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def binding(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check_refs(x):
 if isinstance(x,dict):
  if {'path','sha256'}<=x.keys():
   p=Path(x['path']);assert sha(p)==x['sha256'],p
   if 'bytes' in x:assert p.stat().st_size==x['bytes'],p
  for v in x.values():check_refs(v)
 elif isinstance(x,list):
  for v in x:check_refs(v)
hold=json.loads((D/'source-ready.json').read_text());check_refs(hold)
assert sha(D/'source-ready.json')=='b1cafa961c85f617af246718319f16764a47a072e11017f05f467cafa3aede80'
claims=json.loads(Path(hold['claims_and_checks']['path']).read_text());check_refs(claims)
evidence=json.loads((O/'evidence-checks.json').read_text());assert evidence['ledger']==hold['final_validation'];assert evidence['source']==hold['source_inventory']
rows=[]
for row in hold['files']:
 rel=row['path'];raw=Path(row['raw']['path']).read_bytes();before=Path(row['before']['path']).read_bytes() if row['before'] else b''
 if row['before']:
  git=subprocess.run(['git','show',f"{hold['base']}:{rel}"],cwd=N/'worktree',capture_output=True,check=True).stdout;assert git==before
 else:
  r=subprocess.run(['git','cat-file','-e',f"{hold['base']}:{rel}"],cwd=N/'worktree',capture_output=True);assert r.returncode!=0
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+rel if row['before'] else '/dev/null',tofile='b/'+rel))
 assert patch==Path(row['diff']['path']).read_text();assert 'PENDING_' not in raw.decode()
 rows.append({'relative_path':rel,'before':row['before'],'raw':row['raw'],'diff':row['diff'],'published_before_join':True,'diff_exact':True})
assert len(rows)==7
for h in hold['historical_suffixes']:
 before=(D/'before'/h['path']).read_text();raw=(D/'raw'/h['path']).read_text();a=before[before.index(h['anchor']):];b=raw[raw.index(h['anchor']):];assert a==b and hashlib.sha256(a.encode()).hexdigest()==h['suffix_sha256']
chapter=(D/'raw/docs/promise-any.md').read_text()
assert 'Creating a\nrejection callback costs 136' in chapter
assert 'Allocation failure during a final rejection callback' in chapter
assert '2,848 library passes and nine\nfailures, before later targets' in chapter
assert 'including failed and unsupported outcomes' in chapter
assert 'Later changes after those builds are\ntest-only' in chapter
out={'status':'clear','review_kind':'Independent source/claim/hash peer of final seven-document Promise.any hold','base':hold['base'],'documentation_hold':binding(D/'source-ready.json'),'source':hold['source_inventory'],'final_validation':hold['final_validation'],'evidence_checks':binding(O/'evidence-checks.json'),'evidence_verifier':binding(O/'verify-evidence.py'),'files':rows,'claims_checked':{'semantics':'Generic capability-before-resolve-before-iterator order; cached resolve/next; direct shared resolve and distinct rejection gates; synchronous sentinel/input order; intrinsic branded AggregateError/errors; EOF ordinary rejection retry versus direct saved final callback; unfinished-iterator close and terminal bypass agree with the reviewed production/primary algorithm and frozen authored controls.','selected_tariffs':'Public8/body17 plus reject clone1; callback creation136; first completion28/duplicate12; intrinsic warm134 before growth; actual installer189/3147 and spare171; accounting is logical and target-qualified.','observations':'Source-final-2, startup100986/899014/1765018 and 755/300/26/213 counts; four layout configurations;26 public groups/62 modes,11 private/92 operations,1 coupling group/2 modes/4 readbacks.','full_validation':'3197 default and3551 host-vulkan,52 result rows each; exact parent roster after four selected renames plus38 new groups; zero ignored/filtered/failures. Strict all-target Clippy and fmt receipts pass.','releases_and_replays':'Actual ordinary/host binary bytes and source-binary inventory identities checked. Five complete case/control arrays equal parent:1100/400, including existing failed and unsupported cases. Test-only changes after release builds are explicitly qualified; no claim those binaries were built from source-final-2.','limitations':'No Promise.any upstream outcome/profile, new identity policy, remote CI result, security certification, CPU/RSS/GPU or Chromium performance claim. Existing decoder and final-unhandled policies remain unchanged.'},'historical_suffixes':hold['historical_suffixes'],'retained_history':['First default full attempt stopped after2848 library passes/9 failures before later targets:8 socket/TCP permission preflights and1 missed old property-count assertion.','The scalar9-to10 correction is test-only; original migration hold, first failure and original peer remain retained. This reviewer originally missed that omitted scalar; this later documentation peer does not retroactively clear it.'],'preseal_precision_edits':['Final allocation claim narrowed to final rejection callback gate.','First full interruption now names2848/9 and unreached later targets.','136-unit tariff explicitly describes callback creation.'],'evidence_links':claims['links'],'findings':[],'execution':'Only read-only source/Git and Python stdlib hashing/data/text checks; no project execution, live source edit, archive mutation or publication.','review_script':binding(O/'seal-review.py')}
(O/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(binding(O/'review.json')))
