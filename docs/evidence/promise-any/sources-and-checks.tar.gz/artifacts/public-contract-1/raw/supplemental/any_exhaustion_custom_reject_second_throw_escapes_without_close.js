if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var length=0;length<2;length++){
 var first,second,caught,one={},two={},payload={},calls=0,steps=0,closed=0,holder={};
 function C(ex){ex(function(){throw new Error('fulfill');},function(e){calls++;if(calls===1){first=e;throw one;}second=e;throw two;});return holder;}
 C.resolve=function(v){return {then:function(f,r){check(r(v)===undefined);}};};
 var it={next:function(){steps++;return length===1&&steps===1?{done:false,value:payload}:{done:true};}};
 Object.defineProperty(it,'return',{get:function(){closed++;throw new Error('close after done');}});var items={};items[Symbol.iterator]=function(){return it;};
 try{Promise.any.call(C,items);}catch(e){caught=e;}
 check(calls===2&&first instanceof AggregateError&&first.errors.length===length&&(length===0||first.errors[0]===payload)&&second===one&&caught===two&&closed===0);
 rows.push(length+':'+calls+':'+steps+':'+closed);
}
var result=rows.join(',');
