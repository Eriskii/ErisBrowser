if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var stage=0;stage<2;stage++)for(var closeKind=0;closeKind<4;closeKind++){
 var marker={},other={},seen,gets=0,calls=0,rejects=0;
 function C(ex){ex(function(){throw new Error('fulfill');},function(e){seen=e;rejects++;});}
 C.resolve=function(){return {get then(){if(stage===0)throw marker;return function(){throw marker;};}};};
 var it={next:function(){return {done:false,value:1};}};
 Object.defineProperty(it,'return',{get:function(){gets++;if(closeKind===0)throw other;if(closeKind===1)return 1;return function(){calls++;if(closeKind===2)throw other;return 0;};}});
 var items={};items[Symbol.iterator]=function(){return it;};
 Promise.any.call(C,items);check(seen===marker&&rejects===1);rows.push(''+stage+closeKind+':'+gets+':'+calls);
}
var result=rows.join(',');
