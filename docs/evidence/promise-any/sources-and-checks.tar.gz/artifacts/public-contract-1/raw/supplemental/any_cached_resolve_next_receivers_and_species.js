if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',bad=false,values,holder={},index=0;
function sharedResolve(v){trace+='F'+v;}
function C(ex){trace+='C';ex(sharedResolve,function(e){'use strict';bad=bad||this!==undefined||arguments.length!==1;trace+='J';values=e.errors;});return holder;}
Object.defineProperty(C,Symbol.species,{get:function(){throw new Error('species');}});
Object.defineProperty(C,'resolve',{configurable:true,get:function(){trace+='R';return function(v){'use strict';bad=bad||this!==C||arguments.length!==1;trace+='Q'+v;Object.defineProperty(C,'resolve',{value:function(){throw new Error('uncached resolve');},configurable:true});var returned={then:function(f,r){'use strict';bad=bad||this!==returned||arguments.length!==2||f!==sharedResolve;trace+='T'+v;check(r(v)===undefined);}};return returned;};}});
var it={};Object.defineProperty(it,'next',{configurable:true,get:function(){trace+='N';return function(){'use strict';bad=bad||this!==it||arguments.length!==0;trace+='S';Object.defineProperty(it,'next',{value:function(){throw new Error('uncached next');},configurable:true});return index<2?{done:false,value:++index}:{done:true,get value(){throw new Error('exhausted value');}};};}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';return function(){'use strict';bad=bad||this!==items||arguments.length!==0;trace+='i';return it;};}});
check(Promise.any.call(C,items)===holder);var result=trace+'|'+values.join(',')+'|'+bad;
