if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',A=AggregateError,O=Object;
Promise.any([]).then(function(){throw new Error('empty fulfill');},function(e){var d=O.getOwnPropertyDescriptor(e,'errors');check(O.getPrototypeOf(e)===A.prototype&&O.prototype.toString.call(e)==='[object Error]'&&Array.isArray(e.errors)&&e.errors.length===0&&d.value===e.errors&&d.writable&&!d.enumerable&&d.configurable);trace+='E';});
Promise.any([Promise.reject('no'),Promise.resolve('x')]).then(function(v){check(v==='x');trace+='F'+v;},function(){throw new Error('nonempty reject');});
queueMicrotask(function(){trace+='Q';});trace+='S';
