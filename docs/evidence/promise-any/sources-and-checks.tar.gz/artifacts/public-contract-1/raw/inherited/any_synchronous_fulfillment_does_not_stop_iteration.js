if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var fcount=0,jcount=0,steps=0,holder={};function C(ex){ex(function(){fcount++;},function(){jcount++;});return holder;}C.resolve=function(v){return {then:function(f,r){f(v);f(v);}};};
var it={next:function(){steps++;return steps<=2?{done:false,value:steps}:{done:true};}},items={};items[Symbol.iterator]=function(){return it;};
check(Promise.any.call(C,items)===holder);var result=fcount+':'+steps+':'+jcount;
