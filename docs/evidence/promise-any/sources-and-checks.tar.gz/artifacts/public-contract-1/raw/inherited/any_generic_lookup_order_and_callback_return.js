if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var t='',token={},ret={},holder={},captured,resolve=function(){},error,N=0;
function C(ex){t+='C';ex(resolve,function(e){t+='J';error=e;return ret;});return holder;}
Object.defineProperty(C,'resolve',{get:function(){t+='R';return function(v){check(this===C&&v===token);t+='Q';return {get then(){t+='T';return function(f,r){t+='H';captured=[f,r];};}};};}});
var it={};Object.defineProperty(it,'next',{get:function(){t+='N';return function(){t+='S';if(N++===0)return {get done(){t+='D';return false;},get value(){t+='V';return token;}};return {get done(){t+='D';return true;}};};}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){t+='I';return function(){t+='i';return it;};}});
check(Promise.any.call(C,items)===holder&&captured[0]===resolve);check(captured[1](token)===ret&&error.errors[0]===token);var result=t;
