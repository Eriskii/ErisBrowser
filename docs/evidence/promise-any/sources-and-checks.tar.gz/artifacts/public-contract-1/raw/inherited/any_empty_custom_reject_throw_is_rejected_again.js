if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var token={},holder={},calls=0,first,second,closed=0;function C(ex){ex(function(){},function(e){calls++;if(calls===1){first=e;throw token;}second=e;return 9;});return holder;}C.resolve=function(v){return v;};
var it={next:function(){return {done:true};}};Object.defineProperty(it,'return',{get:function(){closed++;return function(){};}});var items={};items[Symbol.iterator]=function(){return it;};
check(Promise.any.call(C,items)===holder&&calls===2&&first instanceof AggregateError&&first.errors.length===0&&second===token&&closed===0);var result='ok';
