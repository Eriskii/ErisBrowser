if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,Arr=Array,O=Object,proto=A.prototype,a={},b={},r0,r1,result='pending',setter=0;
var p0=new Promise(function(f,r){r0=r;}),p1=new Promise(function(f,r){r1=r;});
Promise.any([p0,p1]).then(function(){result='bad';},function(e){var d=O.getOwnPropertyDescriptor(e,'errors');check(O.getPrototypeOf(e)===proto&&Arr.isArray(e.errors)&&O.getPrototypeOf(e.errors)===Arr.prototype&&e.errors[0]===a&&e.errors[1]===b&&d.writable&&!d.enumerable&&d.configurable&&setter===0);result='ok';});
var descriptor=O.create(null);descriptor.set=function(){setter++;};descriptor.configurable=true;O.defineProperty(proto,'errors',descriptor);
AggregateError=function(){throw new Error('global AggregateError');};Array=function(){throw new Error('global Array');};r1(b);r0(a);
