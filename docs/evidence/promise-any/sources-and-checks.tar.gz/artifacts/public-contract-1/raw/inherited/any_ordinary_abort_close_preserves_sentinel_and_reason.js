if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var token={},other={},saved,seen=[],count=0,closed=0;function C(ex){ex(function(){},function(e){seen.push(e);});}C.resolve=function(v){if(v===1)throw token;return {then:function(f,r){saved=r;}};};
var it={next:function(){return {done:false,value:count++};}};Object.defineProperty(it,'return',{get:function(){closed++;throw other;}});var items={};items[Symbol.iterator]=function(){return it;};
Promise.any.call(C,items);check(count===2&&closed===1&&seen.length===1&&seen[0]===token);check(saved(other)===undefined&&saved(token)===undefined&&seen.length===1);var result='ok';
