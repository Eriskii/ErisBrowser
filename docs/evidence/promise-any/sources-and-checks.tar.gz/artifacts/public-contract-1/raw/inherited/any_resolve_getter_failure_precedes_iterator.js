if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var token={},seen,hit=0;function C(ex){ex(function(){},function(e){seen=e;});}Object.defineProperty(C,'resolve',{get:function(){throw token;}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){hit++;throw new Error('iterator');}});Promise.any.call(C,items);check(seen===token&&hit===0);var result='ok';
