if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var saved,token={},calls=0;function C(ex){ex(function(){},function(){calls++;throw token;});}C.resolve=function(){return {then:function(f,r){saved=r;}};};Promise.any.call(C,[1]);
var n=Object.getOwnPropertyDescriptor(saved,'name'),l=Object.getOwnPropertyDescriptor(saved,'length');check(n.value===''&&!n.writable&&!n.enumerable&&n.configurable&&l.value===1&&!l.writable&&!l.enumerable&&l.configurable);
check(Object.getPrototypeOf(saved)===Function.prototype&&!Object.prototype.hasOwnProperty.call(saved,'prototype')&&Object.isExtensible(saved));
var type=false;try{new saved();}catch(e){type=e instanceof TypeError;}check(type&&calls===0);
var same=false;try{saved(1);}catch(e){same=e===token;}check(same&&calls===1&&saved(2)===undefined&&calls===1);var result='ok';
