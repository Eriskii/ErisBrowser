if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var a={},b={},c={},rejectFirst,result='pending',parts=[];
var p=new Promise(function(resolve,reject){rejectFirst=reject;});
Promise.any([p,Promise.reject(b),Promise.reject(c)]).then(function(){parts.push('bad');},function(e){check(e instanceof AggregateError&&e.errors.length===3&&e.errors[0]===a&&e.errors[1]===b&&e.errors[2]===c);parts.push('ordered');});
Promise.any([]).then(function(){parts.push('bad');},function(e){check(e instanceof AggregateError&&e.errors.length===0);parts.push('empty');});rejectFirst(a);
Promise.resolve().then(function(){}).then(function(){}).then(function(){result=parts.sort().join(',');});
