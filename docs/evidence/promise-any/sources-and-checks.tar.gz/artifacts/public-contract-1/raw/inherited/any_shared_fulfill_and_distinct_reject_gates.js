if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var pairs=[],fcount=0,jcount=0,error,holder={},a={},b={},ret={};function resolve(){fcount++;return ret;}
function C(ex){ex(resolve,function(e){jcount++;error=e;return ret;});return holder;}C.resolve=function(){return {then:function(f,r){pairs.push([f,r]);}};};
check(Promise.any.call(C,[0,1])===holder);check(pairs[0][0]===resolve&&pairs[1][0]===resolve&&pairs[0][1]!==pairs[1][1]);
check(pairs[0][0](1)===ret&&pairs[1][0](2)===ret&&pairs[0][0](3)===ret);
check(pairs[0][1](a)===undefined&&pairs[0][1]({})===undefined&&pairs[1][1](b)===ret&&pairs[1][1]({})===undefined);
check(fcount===3&&jcount===1&&error.errors[0]===a&&error.errors[1]===b);var result='ok';
