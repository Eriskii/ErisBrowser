if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var stage=0;stage<3;stage++){
 var token={},seen,closed=0,it={next:function(){if(stage===0)throw token;return {get done(){if(stage===1)throw token;return false;},get value(){throw token;}};}};
 Object.defineProperty(it,'return',{get:function(){closed++;throw new Error('close');}});var items={};items[Symbol.iterator]=function(){return it;};function C(ex){ex(function(){},function(e){seen=e;});}C.resolve=function(){throw new Error('resolve');};
 Promise.any.call(C,items);check(seen===token&&closed===0);rows.push('0');
}
var result=rows.join(',');
