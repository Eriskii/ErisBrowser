if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var a={},winner={},result='pending';Promise.any([Promise.reject(a),Promise.resolve(winner),new Promise(function(){})]).then(function(v){result=v===winner?'ok':'wrong';},function(){result='rejected';});
