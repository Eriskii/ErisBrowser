if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',error,count=0,holder={};function C(ex){ex(function(){},function(e){trace+='J';error=e;count++;return 7;});return holder;}
C.resolve=function(v){trace+='Q'+v;return {then:function(f,r){check(r(v)===undefined&&r(99)===undefined);trace+='H'+v;}};};
check(Promise.any.call(C,[0,1])===holder&&count===1&&error.errors[0]===0&&error.errors[1]===1);var result=trace;
