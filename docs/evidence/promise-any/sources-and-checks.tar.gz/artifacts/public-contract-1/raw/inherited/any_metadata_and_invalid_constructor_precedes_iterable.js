if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.any,d=Object.getOwnPropertyDescriptor(Promise,'any');check(d.value===f&&d.writable&&!d.enumerable&&d.configurable);
var l=Object.getOwnPropertyDescriptor(f,'length'),n=Object.getOwnPropertyDescriptor(f,'name');check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable&&n.value==='any'&&!n.writable&&!n.enumerable&&n.configurable);
check(!Object.prototype.hasOwnProperty.call(f,'prototype'));var hit=0,items={};Object.defineProperty(items,Symbol.iterator,{get:function(){hit++;}});
var bad=[null,1,{},()=>{}],count=0;for(var i=0;i<bad.length;i++){try{f.call(bad[i],items);}catch(e){check(e instanceof TypeError);count++;}}
try{new f(items);}catch(e){check(e instanceof TypeError);count++;}check(count===5&&hit===0);var result='ok';
