"""External source-only public contract author; no project/JS execution."""
from pathlib import Path
import hashlib
import json
import subprocess

OLD=Path('/tmp/eris-promise-any-plan-1');NEW=Path('/tmp/eris-promise-any-runtime-plan-1');H=NEW/'public-contract-1';W=NEW/'worktree'
BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,d):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
assert not (H/'source-ready.json').exists()
original=[r for r in read(OLD/'semantic-cases.json')['cases'] if r['phase']=='any']
assert len(original)==13
for r in original:assert sha(r['source'].encode())==r['source_sha256']
write(H/'inherited-semantic-cases.json',dict(status='exact13_original_objects_preserved',cases=original,source=bind(OLD/'semantic-cases.json')))
prefix="if(typeof AggregateError!=='function')throw new Error('AggregateError missing');\nif(typeof Promise.any!=='function')throw new Error('Promise.any missing');\nfunction check(v){if(!v)throw new Error('oracle');}\n"
added=[]
def add(name,body,readback,expected,derivation):
 source=prefix+body
 added.append(dict(name=name,phase='any',modes=['sloppy','strict'],source=source,source_sha256=sha(source.encode()),readback=readback,expected=expected,derivation=derivation,basis='Current primary algorithm plus published supported APIs; no engine execution or observed outcome.'))
add('any_cached_resolve_next_receivers_and_species',"""var trace='',bad=false,values,holder={},index=0;
function sharedResolve(v){trace+='F'+v;}
function C(ex){trace+='C';ex(sharedResolve,function(e){'use strict';bad=bad||this!==undefined||arguments.length!==1;trace+='J';values=e.errors;});return holder;}
Object.defineProperty(C,Symbol.species,{get:function(){throw new Error('species');}});
Object.defineProperty(C,'resolve',{configurable:true,get:function(){trace+='R';return function(v){'use strict';bad=bad||this!==C||arguments.length!==1;trace+='Q'+v;Object.defineProperty(C,'resolve',{value:function(){throw new Error('uncached resolve');},configurable:true});var returned={then:function(f,r){'use strict';bad=bad||this!==returned||arguments.length!==2||f!==sharedResolve;trace+='T'+v;check(r(v)===undefined);}};return returned;};}});
var it={};Object.defineProperty(it,'next',{configurable:true,get:function(){trace+='N';return function(){'use strict';bad=bad||this!==it||arguments.length!==0;trace+='S';Object.defineProperty(it,'next',{value:function(){throw new Error('uncached next');},configurable:true});return index<2?{done:false,value:++index}:{done:true,get value(){throw new Error('exhausted value');}};};}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';return function(){'use strict';bad=bad||this!==items||arguments.length!==0;trace+='i';return it;};}});
check(Promise.any.call(C,items)===holder);var result=trace+'|'+values.join(',')+'|'+bad;
""",'result','CRIiNSQ1T1SQ2T2SJ|1,2|false',[
 'Capability C, resolve getter R, iterator getter I/call i and next getter N occur once in that order.',
 'Each of two cached next calls S yields its number, cached resolve Qn returns then receiver Tn, synchronous reject sees the retained sentinel and returns undefined.',
 'Third cached next S sees done before poisoned value, consumes the sentinel, and rejects once J with index-ordered1,2. Species and replacement resolve/next functions are never read/called.',
 'Strict inner functions require constructor receiver for resolve, returned object receiver for then, source receiver for iterator method, iterator receiver for next, and undefined receiver for capability reject.'
])
add('any_then_abrupt_close_preserves_original_throw',"""var rows=[];
for(var stage=0;stage<2;stage++)for(var closeKind=0;closeKind<4;closeKind++){
 var marker={},other={},seen,gets=0,calls=0,rejects=0;
 function C(ex){ex(function(){throw new Error('fulfill');},function(e){seen=e;rejects++;});}
 C.resolve=function(){return {get then(){if(stage===0)throw marker;return function(){throw marker;};}};};
 var it={next:function(){return {done:false,value:1};}};
 Object.defineProperty(it,'return',{get:function(){gets++;if(closeKind===0)throw other;if(closeKind===1)return 1;return function(){calls++;if(closeKind===2)throw other;return 0;};}});
 var items={};items[Symbol.iterator]=function(){return it;};
 Promise.any.call(C,items);check(seen===marker&&rejects===1);rows.push(''+stage+closeKind+':'+gets+':'+calls);
}
var result=rows.join(',');
""",'result','00:1:0,01:1:0,02:1:1,03:1:1,10:1:0,11:1:0,12:1:1,13:1:1',[
 'Both then Get and then Call fail after acquisition with iterator Done false, so return is obtained once.',
 'Return getter throw and noncallable return do not invoke a close function; throwing callable and primitive-return callable each invoke it once.',
 'The already pending marker throw wins every ordinary close failure; outer capability reject receives that same identity exactly once.',
 'This covers ordinary catchable throws only. Host resource/unsupported failures remain in the separate terminal contract.'
])
add('any_empty_and_nonempty_checkpoint_order_and_brand',"""var trace='',A=AggregateError,O=Object;
Promise.any([]).then(function(){throw new Error('empty fulfill');},function(e){var d=O.getOwnPropertyDescriptor(e,'errors');check(O.getPrototypeOf(e)===A.prototype&&O.prototype.toString.call(e)==='[object Error]'&&Array.isArray(e.errors)&&e.errors.length===0&&d.value===e.errors&&d.writable&&!d.enumerable&&d.configurable);trace+='E';});
Promise.any([Promise.reject('no'),Promise.resolve('x')]).then(function(v){check(v==='x');trace+='F'+v;},function(){throw new Error('nonempty reject');});
queueMicrotask(function(){trace+='Q';});trace+='S';
""",'trace','SEQFx',[
 'Empty any rejects before .then attaches, so its rejection reaction is already queued before the two nonempty element reactions and Q.',
 'Source appends S. Empty reaction appends E; internal input rejection is handled and silent; input fulfillment queues the aggregate fulfillment after Q.',
 'Q then appends Q, and the aggregate handler appends Fx. The post-drain readback is SEQFx.',
 'The empty rejection is a branded intrinsic AggregateError with own hidden writable/configurable errors data holding an empty intrinsic Array; no implementation-specific message is asserted.'
])
add('any_exhaustion_custom_reject_second_throw_escapes_without_close',"""var rows=[];
for(var length=0;length<2;length++){
 var first,second,caught,one={},two={},payload={},calls=0,steps=0,closed=0,holder={};
 function C(ex){ex(function(){throw new Error('fulfill');},function(e){calls++;if(calls===1){first=e;throw one;}second=e;throw two;});return holder;}
 C.resolve=function(v){return {then:function(f,r){check(r(v)===undefined);}};};
 var it={next:function(){steps++;return length===1&&steps===1?{done:false,value:payload}:{done:true};}};
 Object.defineProperty(it,'return',{get:function(){closed++;throw new Error('close after done');}});var items={};items[Symbol.iterator]=function(){return it;};
 try{Promise.any.call(C,items);}catch(e){caught=e;}
 check(calls===2&&first instanceof AggregateError&&first.errors.length===length&&(length===0||first.errors[0]===payload)&&second===one&&caught===two&&closed===0);
 rows.push(length+':'+calls+':'+steps+':'+closed);
}
var result=rows.join(',');
""",'result','0:2:1:0,1:2:2:0',[
 'Selected current draft PerformPromiseAny EOF step5.2.2.3 directly calls Reject with a new intrinsic AggregateError after Done is true.',
 'Its first ordinary throw one leaves PerformPromiseAny abruptly; the outer Promise.any abrupt path skips close because Done is true and invokes Reject again with one.',
 'The second ordinary throw two escapes the wrapper. Both empty and synchronously all-rejected inputs therefore call Reject twice, while the saved final callback path is separately covered by inherited any_reject_callback_metadata_and_post_throw_duplicate and propagates directly.',
 'Root confirmed this current-primary/cached-primary reading and withdrew its earlier ThrowCompletion-at-EOF suggestion. No execution was used.'
])
write(H/'supplemental-semantic-cases.json',dict(status='selected_additive_literals_frozen_before_execution',cases=added,groups=len(added),modes=2*len(added),original13_unchanged=True))
terminal=[r for r in read(OLD/'terminal-cases.json')['cases'] if r['stage'].startswith('any_')]
assert len(terminal)==8
for r in terminal:assert sha(r['source'].encode())==r['source_sha256']
extra=[]
for old in terminal:
 if old['stage']=='any_then_get':
  row=dict(old);row['stage']='any_then_call';fatal='while(true){}' if row['error_kind']=='resource' else "eval('0');"
  needle="trace+='G';"+fatal+"return function(f,r){trace+='T';saved=r;};"
  replace="trace+='G';return function(f,r){trace+='T';"+fatal+"saved=r;};"
  assert row['source'].count(needle)==1
  row['source']=row['source'].replace(needle,replace);row['source_sha256']=sha(row['source'].encode());row['expected_readback']='NRGT|0|0|0|0|false'
  row['derivation']='Same immutable then-Get fixture with the terminal operation moved into then Call after T. No close/reject/fulfill/queuedQ/after continuation is allowed.';extra.append(row)
write(H/'terminal-cases.json',dict(status='selected_separate_host_terminal_literals_frozen_before_execution',inherited_cases=terminal,additive_cases=extra,groups=5,sources=10,modes=20,
 classification='Resource and Unsupported are host-terminal errors, not catchable Promise rejection reasons.',
 fixture='Reuse existing allSettled/race fatal_stop helper shape: fresh Runtime per mode, assert terminal classification first and suspended queue, then two existing-API readbacks with suspension and console empty. No counters or queue flags reset; no new quota literals.',
 parent_reachability='At published parent AggregateError exists but Promise.any does not; the presence guard throws ordinary Error before queue setup. Terminal classification fails, so all readbacks and later rows are unreached.',
 limitation='These witnesses cover specified stages and non-resumption. They do not claim exhaustive allocator fault injection or independently test every catch/finally branch.'))
for category,rows in [('inherited',original),('supplemental',added),('terminal',terminal+extra)]:
 for r in rows:
  name=r.get('name',r.get('stage'))+('-'+r['error_kind'] if 'error_kind'in r else '')
  p=H/'raw'/category/(name+'.js');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(r['source'])
  (p.with_suffix('.readback.js')).write_text(r['readback']+'\n')
refs=['src/script.rs','src/script/promises.rs','src/script/promises/all_semantics.rs','src/script/promises/all_state.rs','src/script/promises/semantics.rs','src/script/promise_all_semantic_tests.rs','src/script/promise_all_settled_semantic_tests.rs','src/script/promise_all_settled_abort_tests.rs','src/script/promise_race_semantic_tests.rs','src/script/aggregate_error.rs','src/script/aggregate_error_semantic_tests.rs']
bindings=[]
for relative in refs:
 data=(W/relative).read_bytes();git=subprocess.check_output(['git','-C',str(W),'show',f'{BASE}:{relative}']);assert data==git
 p=H/'source-snapshots'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);bindings.append(dict(relative_path=relative,published_blob=f'{BASE}:{relative}',snapshot=bind(p)))
write(H/'source-bindings.json',dict(base=BASE,current_sources=bindings,parent_inventory=bind(NEW/'source-parent.json'),prior_inputs=[bind(OLD/p) for p in ['source-ready.json','semantic-cases.json','terminal-cases.json','spec-sources.json','spec-cache/primary-web-read-1.txt','spec-cache/primary-web-helpers-1.txt','spec-cache/primary-web-prototype-1.txt']],
 immutable_prior_files_unmodified=True,no_future_production_read=True,no_project_execution=True))
write(H/'plan.json',dict(status='root_selected_literal_contract_before_execution_or_Rust_conversion',base=BASE,
 semantic=dict(inherited_groups=13,additive_groups=4,total_groups=17,planned_modes=34),terminal=dict(groups=5,sources=10,planned_modes=20),
 original13='Every original Any case object is preserved exactly, including source/readback/expectation/hash/basis. No AggregateError-only cases are duplicated.',
 helper='Reuse fresh-runtime strict/sloppy public observe pattern from promise_all_semantic_tests.rs. execute returns after its ordinary job checkpoint; readback uses a separate same-mode execute call. Do not claim a pre-checkpoint observation unless a separate test explicitly obtains it.',
 parent_expected='Each semantic group first reaches the missing Promise.any guard in sloppy mode and fails with ordinary Error; strict mode, assertions and readback are unreached. Each terminal group similarly fails its first terminal-classification assertion before readback. These are source predictions, not observed baselines.',
 rejection_paths='Original capability resolve is passed directly to every then; reject gates are per element and once-only. Ordered errors use input position, not rejection order. Existing ordinary close-error precedence and host-terminal non-resumption remain distinct.',
 eof_discrepancy='Resolved before literal freeze: current primary and immutable cache both directly Call Reject at exhaustion. Root withdrew its initial ThrowCompletion(error)/single-reject recollection and selected direct Reject plus outer ordinary-throw retry, with no close after done. All original13 objects remain exact.',
 no_fee_decisions=True,no_production_or_Rust_module=True,no_any_upstream_or_decoder_changes=True,no_classes_proxy_realms_scope=True,
 nonclaims=['No actual engine outcome','No allocator/private quota oracle','No host decoder eighth-identity expansion for Promise profiles','No new Test262 Promise.any profile','No broad compatibility/security/performance claim']))
write(H/'spec-reading.json',dict(status='current_primary_read_for_concrete_EOF_discrepancy',read_date='2026-10-15',url='https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-performpromiseany',
 cached_source=bind(OLD/'spec-cache/primary-web-read-1.txt'),
 current_algorithm='ECMAScript2027 current TC39 multipage draft, §27.5.4.3.1 step5.2.2.3 calls capability Reject at EOF; Promise.any step8 processes an ordinary throw through outer rejection, skipping close after Done. A saved element callback returns its direct rejection completion.',
 root_initial_alternative='EOF returns ThrowCompletion(aggregateError), then outer Reject exactly once; this does not match the newly read current draft or immutable cache.',
 resolution='Root confirmed the fresh primary reading before literal freeze and withdrew its earlier alternative. EOF direct reject plus one outer ordinary-throw retry is selected; saved callbacks propagate directly; terminal failures bypass retry.',
 exact_short_excerpt='Perform ? Call (resultCapability.[[Reject]], undefined, « aggregateError »).',
 source_lines='Current page3841–3846 and3824–3827; immutable cacheL3841–L3846/L3824–L3827.',
 interpretation='This is source-derived control flow, not an engine observation. Ordinary rejection throw is distinct from Resource/Unsupported terminal completion.',
 no_prior_cache_mutation=True))
print(json.dumps(dict(draft=str(H),semantic_groups=17,terminal_groups=5,original13_exact=read(H/'inherited-semantic-cases.json')['cases']==original)))
