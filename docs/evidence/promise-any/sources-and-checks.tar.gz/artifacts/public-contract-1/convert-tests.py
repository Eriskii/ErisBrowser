"""Convert frozen literal JSON to external Rust payloads; no Rust/JS execution."""
import difflib
import hashlib
import json
from pathlib import Path
import re
U=Path('/tmp/eris-promise-any-runtime-plan-1');H=U/'public-contract-1';W=U/'worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
def dump(p,data):write(p,json.dumps(data,indent=2,sort_keys=True)+'\n')
assert not (H/'source-ready.json').exists()
literal=read(H/'literal-ready.json')
for row in literal['files']:assert bind(Path(row['path']))==row
original=read(H/'inherited-semantic-cases.json')['cases'];added=read(H/'supplemental-semantic-cases.json')['cases'];cases=original+added
term=read(H/'terminal-cases.json');terminal=term['inherited_cases']+term['additive_cases']
assert len(cases)==17 and len(terminal)==10
alltests=(W/'src/script/promise_all_semantic_tests.rs').read_text()
semantic_helper=alltests[alltests.index('fn observe('):alltests.index('\n#[test]')]
aborttests=(W/'src/script/promise_all_settled_abort_tests.rs').read_text()
terminal_helper=aborttests[aborttests.index('fn execute_mode('):aborttests.index('\n#[test]')]
assert semantic_helper.count('fn observe(')==1 and terminal_helper.count('fn fatal_stop(')==1
semantic='//! Promise.any public contracts frozen before production or execution.\n//! Original thirteen literals and separately selected additions remain exact.\nuse super::*;\n\n'+semantic_helper
roster=[];semantic_bindings=[]
for i,row in enumerate(cases):
 assert '"###' not in row['source']+row['readback']
 name='promise_'+row['name']
 semantic+='\n#[test]\nfn '+name+'() {\n    observe(\n        '+json.dumps(row['name'])+',\n        r###"'+row['source']+'"###,\n        r###"'+row['readback']+'"###,\n        Value::String('+json.dumps(row['expected'])+'.into()),\n    );\n}\n'
 roster.append(dict(name=name,kind='semantic',origin='inherited13' if i<13 else 'additive4',modes=['sloppy','strict'],source_sha256=row['source_sha256'],expected=row['expected'],parent='fails first sloppy missing-Promise.any Error; strict/body assertions/readback unreached'))
 semantic_bindings.append(dict(test=name,case=row['name'],source_sha256=row['source_sha256'],readback_sha256=sha(row['readback'].encode()),expected=row['expected']))
semantic_path='src/script/promise_any_semantic_tests.rs';write(H/'tests-raw'/semantic_path,semantic)
abort='//! Promise.any host-terminal cases, distinct from catchable rejection errors.\n//! Existing allSettled fatal helper is unchanged; no in-operation resets.\nuse super::*;\n\n'+terminal_helper
stages=list(dict.fromkeys(r['stage'] for r in terminal));assert len(stages)==5
terminal_bindings=[]
for stage in stages:
 rows=[r for r in terminal if r['stage']==stage];assert len(rows)==2 and [r['error_kind'] for r in rows]==['resource','unsupported']
 assert rows[0]['expected_readback']==rows[1]['expected_readback']
 assert all(r['readback']=="[trace,resolves,rejects,returnGets,returnCalls,after].join('|')" for r in rows)
 name='promise_'+stage+'_terminal_stops_without_later_author_work'
 abort+='\n#[test]\nfn '+name+'() {\n    fatal_stop(\n        [\n'
 for row in rows:
  assert '"###' not in row['source']
  case_id=stage+'_'+row['error_kind'];unsupported='true' if row['error_kind']=='unsupported' else 'false'
  abort+='            (\n                '+json.dumps(case_id)+',\n                '+unsupported+',\n                r###"'+row['source']+'"###,\n            ),\n'
  terminal_bindings.append(dict(test=name,case=case_id,source_sha256=row['source_sha256'],expected_readback=row['expected_readback'],unsupported=row['error_kind']=='unsupported'))
 abort+='        ],\n        '+json.dumps(rows[0]['expected_readback'])+',\n    );\n}\n'
 roster.append(dict(name=name,kind='terminal',origin='inherited4pairs' if stage!='any_then_call' else 'additive_then_call_pair',sources=2,modes_per_source=['sloppy','strict'],expected_readback=rows[0]['expected_readback'],parent='resource/sloppy first gets ordinary missing-Promise.any Error: unsupported false matches, resource true requirement fails; all readbacks and later source/modes unreached'))
abort_path='src/script/promise_any_abort_tests.rs';write(H/'tests-raw'/abort_path,abort)
# Byte extraction checks independently compare generated literal spans to JSON.
sem_literals=re.findall(r'r###"(.*?)"###',semantic,re.S)
assert sem_literals==[text for row in cases for text in (row['source'],row['readback'])]
abort_literals=re.findall(r'r###"(.*?)"###',abort,re.S)
assert abort_literals==["[trace,resolves,rejects,returnGets,returnCalls,after].join('|')"]+[r['source'] for stage in stages for r in terminal if r['stage']==stage]
assert semantic[semantic.index('fn observe('):semantic.index('\n#[test]')]==semantic_helper
assert abort[abort.index('fn execute_mode('):abort.index('\n#[test]')]==terminal_helper
assert len(re.findall(r'^#\[test\]$',semantic,re.M))==17 and len(re.findall(r'^#\[test\]$',abort,re.M))==5
payloads=[]
for relative in (semantic_path,abort_path):
 raw=H/'tests-raw'/relative;assert not (W/relative).exists()
 diff=H/'test-diffs'/(relative+'.patch')
 write(diff,''.join(difflib.unified_diff([],raw.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+relative)))
 payloads.append(dict(relative_path=relative,before_absent=True,raw=bind(raw),diff=bind(diff)))
before=(W/'src/script.rs').read_bytes();assert sha(before)==read(U/'source-parent.json')['source_sha256']['src/script.rs']
fragment='\n#[cfg(test)]\nmod promise_any_abort_tests;\n#[cfg(test)]\nmod promise_any_semantic_tests;\n'
reg_before=H/'registration/before/src/script.rs';reg_raw=H/'registration/raw/src/script.rs';reg_diff=H/'registration/script.rs.patch';reg_fragment=H/'registration/append.txt'
write(reg_before,before.decode());write(reg_raw,before.decode()+fragment);write(reg_fragment,fragment)
write(reg_diff,''.join(difflib.unified_diff(before.decode().splitlines(True),(before.decode()+fragment).splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs')))
registration=dict(relative_path='src/script.rs',before=bind(reg_before),raw=bind(reg_raw),diff=bind(reg_diff),append=bind(reg_fragment),rule='Exact append only: two cfg(test) sibling module declarations, no production edits. Future production composition must preserve these append bytes.')
dump(H/'test-roster.json',dict(status='source_predicted_not_executed',groups=22,semantic_groups=17,terminal_groups=5,semantic_mode_attempts=34,terminal_mode_attempts=20,parent_expected_groups=dict(passed=0,failed=22),rows=roster,qualification='No project compile or engine execution. Each first sloppy presence guard intentionally fails on published30576b1; later assertions/modes cannot be claimed observed.'))
dump(H/'conversion-checks.json',dict(status='clear_source_conversion_only',semantic17_source_readback_literals_exact=True,inherited13_objects_unchanged=True,terminal10_source_literals_exact=True,semantic_helper_exact_to='src/script/promise_all_semantic_tests.rs',terminal_helper_exact_to='src/script/promise_all_settled_abort_tests.rs',registration_append_exact=True,semantic_bindings=semantic_bindings,terminal_bindings=terminal_bindings,execution=False))
files=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
seal=dict(status='source_ready_external_public_tests_no_project_execution',base=literal['base'],literal_hold=bind(H/'literal-ready.json'),semantic_groups=17,terminal_groups=5,total_groups=22,planned_mode_attempts=54,payloads=payloads,registration=registration,roster=bind(H/'test-roster.json'),conversion=bind(H/'conversion-checks.json'),source_bindings=bind(H/'source-bindings.json'),files=files,
 scope='Runtime-only Promise.any public semantics and terminal behavior. No private fee controls, Promise.any upstream profile or host decoder policy change.',
 qualification='Frozen JSON precedes Rust conversion. No future production was read, no live worktree written, and no project/compiler/engine was executed. Root owns import, parent negative execution, formatting and validation.')
dump(H/'source-ready.json',seal)
print(json.dumps(bind(H/'source-ready.json')))
print(json.dumps([bind(H/'tests-raw'/p) for p in (semantic_path,abort_path)]))
