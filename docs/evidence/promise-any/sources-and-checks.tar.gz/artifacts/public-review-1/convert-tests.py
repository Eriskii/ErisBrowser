"""Mechanical conversion after literal freeze; no Rust/JS/project execution."""
from pathlib import Path
import json,hashlib,difflib,re
U=Path('/tmp/eris-promise-any-runtime-plan-1');H=U/'public-review-1';P=U/'public-contract-1'
sha=lambda x:hashlib.sha256(x).hexdigest()
def read(p):return json.loads(p.read_bytes())
def b(p):
 d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=sha(d))
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def dump(p,d):write(p,json.dumps(d,indent=2,sort_keys=True)+'\n')
assert not (H/'source-ready.json').exists()
literal=read(H/'literal-ready.json')
for r in literal['files']:assert b(Path(r['path']))==r
cases=read(H/'cases.json')['cases'];assert len(cases)==4
old=(P/'tests-raw/src/script/promise_any_semantic_tests.rs').read_text();helper=old[old.index('fn observe('):old.index('\n#[test]')]
source='//! Additive Promise.any observable input/capability coverage.\n//! Exact frozen source literals; prior public and terminal modules unchanged.\nuse super::*;\n\n'+helper
roster=[]
for r in cases:
 assert '"###' not in r['source']+r['readback']
 name='promise_'+r['name']
 source+='\n#[test]\nfn '+name+'() {\n    observe(\n        '+json.dumps(r['name'])+',\n        r###"'+r['source']+'"###,\n        r###"'+r['readback']+'"###,\n        Value::String('+json.dumps(r['expected'])+'.into()),\n    );\n}\n'
 roster.append(dict(name=name,modes=['sloppy','strict'],source_sha256=r['source_sha256'],readback_sha256=sha(r['readback'].encode()),expected=r['expected'],parent='first sloppy missing-Promise.any Error; strict and later assertions/readback unreached'))
assert re.findall(r'r###"(.*?)"###',source,re.S)==[x for r in cases for x in (r['source'],r['readback'])]
assert source[source.index('fn observe('):source.index('\n#[test]')]==helper
relative='src/script/promise_any_input_tests.rs';raw=H/'tests-raw'/relative;diff=H/'test-diffs'/(relative+'.patch');write(raw,source);write(diff,''.join(difflib.unified_diff([],source.splitlines(True),fromfile='/dev/null',tofile='b/'+relative)))
prior=read(P/'source-ready.json');before=Path(prior['registration']['raw']['path']).read_bytes();assert sha(before)==prior['registration']['raw']['sha256']
append='\n#[cfg(test)]\nmod promise_any_input_tests;\n';regbefore=H/'registration/before/src/script.rs';regraw=H/'registration/raw/src/script.rs';regdiff=H/'registration/script.rs.patch';fragment=H/'registration/append.txt'
write(regbefore,before.decode());write(regraw,before.decode()+append);write(fragment,append);write(regdiff,''.join(difflib.unified_diff(before.decode().splitlines(True),(before.decode()+append).splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs')))
dump(H/'conversion-checks.json',dict(status='clear_source_conversion_only',groups=4,literal_source_readback_and_expected_exact=True,helper_exact_to_prior_frozen_public_module=True,registration_exact_append_after22_group_hold=True,prior_hold= b(P/'source-ready.json'),project_execution=False))
dump(H/'roster.json',dict(status='source_predicted_not_executed',groups=4,planned_modes=8,parent_expected=dict(passed=0,failed=4),rows=roster,composition=dict(prior_groups=22,additive_groups=4,total_public_groups=26,semantic_groups=21,terminal_groups=5,planned_modes=62),qualification='Counts describe the public composition only. No private-control family or observed engine result is implied.'))
seal=dict(status='source_ready_external_additive_public_tests_no_execution',base=literal['base'],groups=4,planned_modes=8,literal_hold=b(H/'literal-ready.json'),prior_public_hold=b(P/'source-ready.json'),payloads=[dict(relative_path=relative,before_absent=True,raw=b(raw),diff=b(diff))],registration=dict(relative_path='src/script.rs',before=b(regbefore),raw=b(regraw),diff=b(regdiff),append=b(fragment),lineage='Before equals exact prior22-group registration raw. This adds one cfg(test) module only; root may compose the fragment with separately authorized changes.'),roster=b(H/'roster.json'),conversion=b(H/'conversion-checks.json'),files=[b(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json'],qualification='No live worktree edits, project execution or future production inspection. Prior hold remains immutable; this is a separate addition.')
dump(H/'source-ready.json',seal);print(json.dumps(b(H/'source-ready.json')))
