[after,results.length,results.join(','),closed].join('|')
