if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',holder={},returned={},payload={},reason={},out,error,receiver=false,identities=false,ignored=0;
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===payload);trace+='F';return returned;}
function C(ex){trace+='C';ex(resolve,function(e){'use strict';check(this===undefined&&arguments.length===1);trace+='J';error=e;});return holder;}
C.resolve=function(v){'use strict';check(this===C&&arguments.length===1&&v===payload);trace+='Q';return 7;};
Object.defineProperty(Number.prototype,'then',{configurable:true,value:function(f,r){'use strict';receiver=this===7;identities=f===resolve&&typeof r==='function'&&r!==f&&arguments.length===2;trace+='T';check(f(payload)===returned);check(r(reason)===undefined);return {get then(){ignored++;throw new Error('ignored then return');}};}});
out=Promise.any.call(C,[payload]);delete Number.prototype.then;
