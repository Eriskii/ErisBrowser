if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var stage=0;stage<3;stage++){
 var trace='',token={},caught=false,holder={},input={};
 function C(ex){trace+='C';if(stage===0)throw token;if(stage===1)ex(0,function(){});else ex(function(){},0);return holder;}
 Object.defineProperty(C,'resolve',{get:function(){trace+='R';throw new Error('late resolve');}});
 Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw new Error('late iterator');}});
 try{Promise.any.call(C,input);}catch(e){caught=stage===0?e===token:e instanceof TypeError;}
 rows.push(trace+':'+caught);
}
var badValues=[undefined,null,0,{}];
for(var index=0;index<badValues.length;index++){
 var trace='',seen,receiver=false,calls=0,holder={},input={};
 function C(ex){trace+='C';ex(function(){throw new Error('fulfill');},function(e){'use strict';receiver=this===undefined&&arguments.length===1;calls++;trace+='J';seen=e;});return holder;}
 Object.defineProperty(C,'resolve',{get:function(){trace+='R';return badValues[index];}});
 Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw new Error('late iterator');}});
 var out=Promise.any.call(C,input);rows.push(trace+':'+(seen instanceof TypeError&&receiver&&calls===1&&out===holder));
}
var result=rows.join(',');
