[trace,receiver,identities,ignored,out===holder,error instanceof AggregateError&&error.errors[0]===reason].join('|')
