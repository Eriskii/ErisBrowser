if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var text='pending',hole='pending';
Promise.any('𝄞a').then(function(v){text=v;},function(){text='wrong';});
Promise.any([,Promise.reject({})]).then(function(v){hole=v;},function(){hole='wrong';});
