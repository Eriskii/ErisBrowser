[text==='𝄞',text.length,hole===undefined].join('|')
