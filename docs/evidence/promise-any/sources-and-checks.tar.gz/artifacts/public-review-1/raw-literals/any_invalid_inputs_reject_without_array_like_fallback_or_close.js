if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
if(typeof Promise.any!=='function')throw new Error('Promise.any missing');
function check(v){if(!v)throw new Error('oracle');}
var closed=0,results=[],after=false;
var badMethod={};badMethod[Symbol.iterator]=1;
var badIterator={};badIterator[Symbol.iterator]=function(){return 1;};
var malformed={next:1};Object.defineProperty(malformed,'return',{get:function(){closed++;throw new Error('close');}});
var badNext={};badNext[Symbol.iterator]=function(){return malformed;};
var inputs=[undefined,null,1,{},{0:4,length:1},badMethod,badIterator,badNext];
for(var i=0;i<inputs.length;i++)(function(index){var p=Promise.any(inputs[index]);check(p instanceof Promise);p.then(function(){results[index]='fulfilled';},function(e){check(e instanceof TypeError);results[index]='TypeError';});})(i);
after=true;
