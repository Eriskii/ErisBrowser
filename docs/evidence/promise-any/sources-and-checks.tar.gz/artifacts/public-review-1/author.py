"""Source-only additive Promise.any coverage; no project execution/import."""
import hashlib
import json
from pathlib import Path
import subprocess
U=Path('/tmp/eris-promise-any-runtime-plan-1');H=U/'public-review-1';W=U/'worktree';BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def b(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=sha(data))
def write(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2,sort_keys=True)+'\n')
assert not (H/'literal-ready.json').exists()
prefix="if(typeof AggregateError!=='function')throw new Error('AggregateError missing');\nif(typeof Promise.any!=='function')throw new Error('Promise.any missing');\nfunction check(v){if(!v)throw new Error('oracle');}\n"
cases=[]
def add(name,body,expression,expected,gap,reason):
 source=prefix+body;cases.append(dict(name=name,source=source,source_sha256=sha(source.encode()),readback=expression,expected=expected,modes=['sloppy','strict'],gap=gap,derivation=reason))
add('any_primitive_then_receiver_and_ignored_return',"""var trace='',holder={},returned={},payload={},reason={},out,error,receiver=false,identities=false,ignored=0;
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===payload);trace+='F';return returned;}
function C(ex){trace+='C';ex(resolve,function(e){'use strict';check(this===undefined&&arguments.length===1);trace+='J';error=e;});return holder;}
C.resolve=function(v){'use strict';check(this===C&&arguments.length===1&&v===payload);trace+='Q';return 7;};
Object.defineProperty(Number.prototype,'then',{configurable:true,value:function(f,r){'use strict';receiver=this===7;identities=f===resolve&&typeof r==='function'&&r!==f&&arguments.length===2;trace+='T';check(f(payload)===returned);check(r(reason)===undefined);return {get then(){ignored++;throw new Error('ignored then return');}};}});
out=Promise.any.call(C,[payload]);delete Number.prototype.then;
""","[trace,receiver,identities,ignored,out===holder,error instanceof AggregateError&&error.errors[0]===reason].join('|')",'CQTFJ|true|true|0|true|true',
 'Existing Any cases use object nextPromise receivers; they do not distinguish GetV/Invoke on a primitive or prove the return of then is ignored.',[
 'Capability C precedes cached resolver Q; numeric7 inherits Number.prototype.then and strict this remains primitive7.',
 'Then T receives original capability resolve, so direct call F returns the exact custom returned object. Reject-element call stores reason and returns undefined while sentinel remains.',
 'EOF consumes sentinel and custom capability reject J receives the intrinsic aggregate. Generic capability permits both F and J; native Promise settlement once rules are not imposed on these arbitrary callbacks.',
 'The object returned by then is ignored rather than assimilated, leaving its then getter count0. Wrapper returns the capability holder.'
])
add('any_strings_code_points_and_sparse_array_holes',"""var text='pending',hole='pending';
Promise.any('𝄞a').then(function(v){text=v;},function(){text='wrong';});
Promise.any([,Promise.reject({})]).then(function(v){hole=v;},function(){hole='wrong';});
""","[text==='𝄞',text.length,hole===undefined].join('|')",'true|2|true',
 'No frozen Any source uses a primitive string iterable or a sparse array, so code-point iteration and undefined hole admission are not yet witnessed.',[
 'String iterator yields the supplementary code point𝄞 as one string whose UTF-16 length is2, before a. Its first fulfillment wins.',
 'Array iterator yields undefined for the leading hole, rather than skipping it. That fulfillment wins while the other input rejection is handled by its reject element.',
 'Readback occurs after the ordinary job checkpoint, as in the existing Promise.all public fixture; no early synchronous observation is claimed.'
])
add('any_invalid_inputs_reject_without_array_like_fallback_or_close',"""var closed=0,results=[],after=false;
var badMethod={};badMethod[Symbol.iterator]=1;
var badIterator={};badIterator[Symbol.iterator]=function(){return 1;};
var malformed={next:1};Object.defineProperty(malformed,'return',{get:function(){closed++;throw new Error('close');}});
var badNext={};badNext[Symbol.iterator]=function(){return malformed;};
var inputs=[undefined,null,1,{},{0:4,length:1},badMethod,badIterator,badNext];
for(var i=0;i<inputs.length;i++)(function(index){var p=Promise.any(inputs[index]);check(p instanceof Promise);p.then(function(){results[index]='fulfilled';},function(e){check(e instanceof TypeError);results[index]='TypeError';});})(i);
after=true;
""","[after,results.length,results.join(','),closed].join('|')",'true|8|TypeError,TypeError,TypeError,TypeError,TypeError,TypeError,TypeError,TypeError|0',
 'Invalid constructors are covered, but invalid iterable acquisition, no array-like fallback and a noncallable cached next are not covered by the frozen Any inputs.',[
 'Undefined/null/number/plain object/array-like object all fail synchronous iterator acquisition and reject the newly created native promise with TypeError; Promise.any itself returns each promise.',
 'A noncallable iterator method and a primitive iterator result also reject with TypeError before an acquired iterator can be closed.',
 'A noncallable next fails IteratorStepValue and marks Done; its poisoned return getter stays unread. All eight handler rows run at the ordinary checkpoint; after remains true.'
])
add('any_capability_and_noncallable_resolve_precede_iterator',"""var rows=[];
for(var stage=0;stage<3;stage++){
 var trace='',token={},caught=false,holder={},input={};
 function C(ex){trace+='C';if(stage===0)throw token;if(stage===1)ex(0,function(){});else ex(function(){},0);return holder;}
 Object.defineProperty(C,'resolve',{get:function(){trace+='R';throw new Error('late resolve');}});
 Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw new Error('late iterator');}});
 try{Promise.any.call(C,input);}catch(e){caught=stage===0?e===token:e instanceof TypeError;}
 rows.push(trace+':'+caught);
}
var badValues=[undefined,null,0,{}];
for(var index=0;index<badValues.length;index++){
 var trace='',seen,receiver=false,calls=0,holder={},input={};
 function C(ex){trace+='C';ex(function(){throw new Error('fulfill');},function(e){'use strict';receiver=this===undefined&&arguments.length===1;calls++;trace+='J';seen=e;});return holder;}
 Object.defineProperty(C,'resolve',{get:function(){trace+='R';return badValues[index];}});
 Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw new Error('late iterator');}});
 var out=Promise.any.call(C,input);rows.push(trace+':'+(seen instanceof TypeError&&receiver&&calls===1&&out===holder));
}
var result=rows.join(',');
""",'result','C:true,C:true,C:true,CRJ:true,CRJ:true,CRJ:true,CRJ:true',
 'The frozen metadata test covers a nonconstructor this value, and another covers a throwing resolve getter. It does not cover a throwing constructor, invalid executor-provided functions, or a getter returning a noncallable resolve value.',[
 'NewPromiseCapability constructor throw propagates its original token; noncallable executor resolve/reject values produce synchronous TypeError. None reads C.resolve or input iterator, so each trace is onlyC.',
 'For a valid capability, resolve getterR precedes iterator access; each noncallable result creates TypeError and calls the capability rejectJ exactly once with undefined receiver and one argument.',
 'The capability holder is returned after successful rejection, and the poisoned iterator getter never runs. These are catchable ordinary errors, not host-terminal failures.'
])
write(H/'cases.json',dict(status='frozen_source_derived_additive_literals_before_Rust_conversion',groups=4,planned_modes=8,cases=cases))
for row in cases:
 p=H/'raw-literals'/(row['name']+'.js');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(row['source']);p.with_suffix('.readback.js').write_text(row['readback']+'\n')
sourcepaths=['src/script.rs','src/script/promises/all_semantics.rs','src/script/promises/semantics.rs','src/script/promise_all_semantic_tests.rs','src/script/promise_race_semantic_tests.rs','src/script/promise_all_settled_semantic_tests.rs']
source=[]
for relative in sourcepaths:
 data=subprocess.check_output(['git','-C',str(W),'show',f'{BASE}:{relative}']);assert sha(data)==read(U/'source-parent.json')['source_sha256'][relative]
 p=H/'source-snapshots'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);source.append(dict(relative_path=relative,published_blob=f'{BASE}:{relative}',snapshot=b(p)))
write(H/'coverage-review.json',dict(status='four_substantive_additive_groups_source_only',base=BASE,previous_hold=b(U/'public-contract-1/source-ready.json'),previous_literals=b(U/'public-contract-1/literal-ready.json'),
 source_bindings=source,primary_bindings=[b(Path('/tmp/eris-promise-any-plan-1/spec-cache')/n) for n in ['primary-web-read-1.txt','primary-web-helpers-1.txt']],
 gaps=[dict(case=r['name'],gap=r['gap']) for r in cases],
 already_covered=['Invalid this/nonconstructible method metadata','Capability→resolve getter→iterator order for valid capability','Cached object resolve/next and receiver/species control','Original shared resolve, distinct reject once gates, callback metadata/return/throw and duplicates','First fulfillment, ordered errors, empty rejection, synchronous rejection sentinel, no early iteration exit','Global constructor/Array replacement and hidden errors setter bypass','Step abrupt Done behavior, ordinary close-error precedence, EOF retry and direct saved callback throw','Checkpoint order and branded intrinsic empty error','Five separate terminal stage pairs and suspended-queue readback'],
 non_expansion=['No additional terminal family','No additional quota or private state assertion','No Promise.any upstream/host decoder policy','No Proxy/class/multiple-realm implementation'],
 parent_expected='Four groups intentionally fail at the first sloppy missing-Promise.any guard. Strict rows and assertions/readbacks remain unreached until implementation. No observed outcome used.',
 execution=False,prior_hold_mutated=False,future_production_read=False))
files=[b(p) for p in sorted(H.rglob('*')) if p.is_file()]
write(H/'literal-ready.json',dict(status='frozen_before_Rust_conversion_or_execution',base=BASE,groups=4,planned_modes=8,cases=b(H/'cases.json'),coverage=b(H/'coverage-review.json'),files=files))
print(json.dumps(b(H/'literal-ready.json')));print(json.dumps(b(H/'cases.json')))
