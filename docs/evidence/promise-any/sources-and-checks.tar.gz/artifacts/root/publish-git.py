import json
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE = '30576b1d977a6590099b5c4748abac9f188bc05c'
publication = P / 'publication'
publication.mkdir(exist_ok=True)
record_path = P / 'root/github-publication.json'
assert not record_path.exists()
verified = json.loads((P / 'root/publication-verification.json').read_bytes())
assert verified['status'] == 'verified' and verified['path_count'] == 38

def git(directory, *args):
    result = subprocess.run(['git', *args], cwd=directory, text=True,
                            capture_output=True, check=True)
    return result.stdout.strip()

assert git(MAIN, 'branch', '--show-current') == 'main'
assert git(MAIN, 'rev-parse', 'HEAD') == git(W, 'rev-parse', 'HEAD') == BASE
assert git(MAIN, 'status', '--porcelain') == ''
assert git(W, 'diff', '--cached', '--name-only') == ''
paths = verified['expected_commit_paths']
pathspec = publication / 'paths.nul'
pathspec.write_bytes(b'\0'.join(name.encode() for name in paths) + b'\0')
git(W, 'add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul')
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
git(W, 'diff', '--cached', '--check')
message = publication / 'commit-message.txt'
message.write_text('Implement Promise.any with intrinsic AggregateError rejection\n\n'
                   'Preserve cached iterator/resolve order, per-element rejection gates,\n'
                   'ordered errors and terminal resource failures. Install the method\n'
                   'after existing intrinsics with bounded work and heap accounting.\n\n'
                   'Validation: 3197 default and 3551 host/Vulkan Rust tests; 38 new\n'
                   'groups; strict Clippy; exact 1100 cases and 400 controls across\n'
                   'five retained upstream profiles. No full web compatibility claim.\n')
commit_output = git(W, 'commit', '-F', str(message))
(publication / 'commit.log').write_text(commit_output + '\n')
commit = git(W, 'rev-parse', 'HEAD')
assert git(W, 'status', '--porcelain') == ''
assert set(git(W, 'diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines()) == set(paths)
record = dict(status='committed', base=BASE, commit=commit,
              repository='https://github.com/Eriskii/ErisBrowser', paths=len(paths))
record_path.write_text(json.dumps(record, indent=2) + '\n')
merge_output = git(MAIN, 'merge', '--ff-only', 'promise-any-runtime')
(publication / 'merge.log').write_text(merge_output + '\n')
assert git(MAIN, 'rev-parse', 'HEAD') == commit and git(MAIN, 'status', '--porcelain') == ''
push_output = git(MAIN, 'push', 'origin', 'main')
(publication / 'push.log').write_text(push_output + '\n')
remote = git(MAIN, 'ls-remote', 'origin', 'refs/heads/main').split()[0]
assert remote == commit
record.update(status='pushed', remote_head=remote, ci='not yet observed')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
