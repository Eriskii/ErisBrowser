import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def parse(directory, label):
    receipt = directory / (label + '.json')
    record = json.loads(receipt.read_text())
    log = directory / (label + '.log')
    text = log.read_text()
    assert record['exit'] == 0 and record['sha256'] == bind(log)['sha256']
    rows = [tuple(map(int, row)) for row in re.findall(
        r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out', text)]
    totals = [sum(row[i] for row in rows) for i in range(5)]
    assert totals[1:] == [0, 0, 0, 0], (label, totals)
    harness = None
    names = []
    for line in text.splitlines():
        match = re.match(r'\s+Running (?:unittests )?(\S+) \(', line)
        if match:
            harness = match[1]
        if 'Doc-tests ' in line:
            harness = 'Doc-tests ' + line.split('Doc-tests ', 1)[1]
        result = re.match(r'^test (.+) \.\.\. ok$', line)
        if result:
            assert harness is not None
            names.append(harness + '::' + result[1])
    assert len(names) == len(set(names)) == totals[0]
    return dict(receipt=bind(receipt), log=bind(log), result_rows=len(rows),
                totals=totals, passed_names=sorted(names))

parent = json.loads((A / 'source-parent.json').read_text())['source_sha256']
final = json.loads((A / 'source-final-2.json').read_text())['source_sha256']
new_files = sorted(set(final) - set(parent))
assert len(new_files) == 5
new_names = []
for name in new_files:
    data = (W / name).read_bytes()
    assert hashlib.sha256(data).hexdigest() == final[name]
    prefix = 'src/lib.rs::' + name.removeprefix('src/').removesuffix('.rs').replace('/', '::')
    new_names += [prefix + '::' + fn for fn in re.findall(r'#\[test\]\s+fn (\w+)\(', data.decode())]
assert len(new_names) == len(set(new_names)) == 38
renames = json.loads((A / 'migrations-before-1/edit-manifest.json').read_text())['function_renames']
comparisons = []
for old_label, new_label, expected in [
    ('default-full-2', 'default-full-2', 3197),
    ('host-vulkan-full-2', 'host-vulkan-full-1', 3551),
]:
    old = parse(A / 'rust-parent', old_label)
    current = parse(A / 'validation', new_label)
    assert current['totals'] == [expected, 0, 0, 0, 0]
    normalized = set(old['passed_names'])
    applied = []
    for row in renames:
        hits = [name for name in normalized if name.endswith('::' + row['before'])]
        assert len(hits) == 1, (row, hits)
        previous = hits[0]
        replacement = previous.rsplit('::', 1)[0] + '::' + row['after']
        normalized.remove(previous)
        normalized.add(replacement)
        applied.append(dict(before=previous, after=replacement))
    assert not normalized & set(new_names)
    expected_names = normalized | set(new_names)
    actual = set(current['passed_names'])
    assert actual == expected_names, dict(missing=sorted(expected_names-actual), unexpected=sorted(actual-expected_names))
    comparisons.append(dict(current=current, previous=old,
        exact_old_roster_after_selected_renames_plus_new=True, renames=applied))

result = dict(status='pass', source=bind(A / 'source-final-2.json'),
              new_test_groups=38, new_names=sorted(new_names),
              selected_existing_test_renames=renames, comparisons=comparisons)
(A / 'root/rust-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print('Exact parent rosters plus38 new groups pass:3197 default,3551 host/Vulkan.')
