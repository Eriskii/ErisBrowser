from pathlib import Path
import hashlib, json

A = Path(__file__).resolve().parent.parent
W = A / 'worktree'
changes = []

def edit(name, old, new):
    p = W / name
    source = p.read_text()
    assert source.count(old) == 1, (name, source.count(old), old[:100])
    p.write_text(source.replace(old, new, 1))
    changes.append(name)

edit('src/script/promises.rs', 'const METADATA_OBJECTS: usize = 11;', 'const METADATA_OBJECTS: usize = 12;')
edit('src/script/promises.rs', '    AllResolve(AllCaptureId),', '    AllResolve(AllCaptureId),\n    AnyReject(AllCaptureId),')
edit('src/script.rs', '        self.install_aggregate_error_intrinsics()\n', '        self.install_aggregate_error_intrinsics()?;\n        self.install_promise_any_intrinsic()\n')
edit('src/script/machine/calls.rs', '                    | "Promise.allSettled"', '                    | "Promise.allSettled"\n                    | "Promise.any"')
edit('src/script/promises/semantics.rs', '                "Promise.allSettled" => self.promise_all_settled(receiver, args, doc),', '                "Promise.allSettled" => self.promise_all_settled(receiver, args, doc),\n                "Promise.any" => self.promise_any(receiver, args, doc),')
edit('src/script/promises/semantics.rs', '                CallbackKind::AllResolve(element) => {', '                CallbackKind::AnyReject(element) => {\n                    return self.run_any_callback(element, args, doc);\n                }\n                CallbackKind::AllResolve(element) => {')
edit('src/script/promises/factories.rs', '                        CallbackKind::AllResolve(id)\n', '                        CallbackKind::AllResolve(id)\n                        | CallbackKind::AnyReject(id)\n')
edit('src/script/promises/factories.rs', '    pub(super) fn new_all_settled_elements(', '''    pub(super) fn new_any_reject_element(
        &mut self,
        group: AllCaptureId,
        index: usize,
    ) -> Result<Value> {
        let element = AllCaptureId(self.promises.all_captures.records.len());
        let result = self
            .build_promise_callbacks(
                [CallbackKind::AnyReject(element)],
                FactoryExtra::AllElement(group, index),
            )
            .map(|[value]| value);
        self.observe_microtask_failure(result)
    }

    pub(super) fn new_all_settled_elements(''')
edit('src/script/promises/install.rs', '    fn check_promise_install_state(&self) -> Result<()> {', '''    pub(in crate::script) fn install_promise_any_intrinsic(&mut self) -> Result<()> {
        // Eight bounded guards/control roles and four temporary releases.
        // This late installation preserves every existing metadata object ID.
        self.work(12)?;
        let intrinsics = self
            .promises
            .intrinsics
            .as_ref()
            .ok_or_else(|| ScriptError::resource("Promise intrinsics missing"))?;
        let Value::Native(constructor) = &intrinsics.constructor else {
            return Err(ScriptError::resource("invalid Promise constructor"));
        };
        let owner = constructor
            .properties
            .map(NonZeroUsize::get)
            .filter(|id| *id < self.objects.len())
            .ok_or_else(|| ScriptError::resource("Promise metadata missing"))?;
        let length = self.dom_proto_text("length")?;
        let name = self.dom_proto_text("name")?;
        let any = self.dom_proto_text("any")?;
        // Two metadata key copies and the display-name copy.
        self.work(3)?;
        let method = self.promise_intrinsic_method(
            "Promise.any",
            any.clone(),
            1,
            [&length, &name],
        )?;
        // Existing insertion pays physical order growth and duplicate checks.
        self.dom_proto_property(owner, any.into(), Property::data(method, true, false, true))
    }

    fn check_promise_install_state(&self) -> Result<()> {''')
edit('src/script/aggregate_error.rs', '    fn aggregate_error_named_get(', '''    pub(super) fn intrinsic_aggregate_error_from_list(
        &mut self,
        values: Vec<Value>,
    ) -> Result<Value> {
        let result = (|| {
            // Four bounded transitions and four local ownership roles. The
            // producer prepaid the moved list's per-element lifetime costs.
            self.work(8)?;
            let (comparisons, _) = promises::intrinsic_tree(self.prototypes.len());
            self.work(comparisons * (1 + "AggregateError".len() / 8))?;
            let prototype = self
                .prototypes
                .get("AggregateError")
                .copied()
                .filter(|id| *id < self.objects.len())
                .ok_or_else(|| ScriptError::resource("AggregateError prototype missing"))?;
            let object = self.new_aggregate_error_object(Value::Object(prototype))?;
            let array = self.new_all_values_array(values)?;
            self.define_aggregate_error_data(object, "errors", array)?;
            Ok(Value::Object(object))
        })();
        self.observe_microtask_failure(result)
    }

    fn aggregate_error_named_get(''')
edit('src/script/promises/all_semantics.rs', '    pub(super) fn promise_race(', '''    pub(super) fn promise_any(
        &mut self,
        constructor: Value,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        // All's orchestration plus the outer resolve handle retained while
        // the Group owns a separately paid copy of the reject handle.
        self.work(17)?;
        self.work(1)?;
        let Capability {
            promise,
            resolve,
            reject,
        } = self.new_promise_capability(constructor.clone(), doc)?;
        let mut iterator = None;
        let result = (|| {
            self.work(1)?;
            let promise_resolve = self.promise_named_get(constructor.clone(), "resolve", doc)?;
            if !json_callable(&promise_resolve) {
                return Err(ScriptError::type_error("Promise resolve is not callable"));
            }
            self.work(1)?;
            let items = args.first().cloned().unwrap_or(Value::Undefined);
            let method = self
                .array_from_iterator_method(&items, doc)?
                .ok_or_else(|| ScriptError::type_error("Promise.any input is not iterable"))?;
            let object = self.call(method, Vec::new(), items, doc)?;
            if !js_object(&object) {
                return Err(ScriptError::type_error("iterator is not an object"));
            }
            self.work(1)?;
            let next = self.promise_named_get(object.clone(), "next", doc)?;
            iterator = Some(AllIterator {
                iterator: object,
                next,
                done: false,
            });
            self.work(1)?;
            let group = self.new_all_group(reject.clone())?;
            let record = iterator.as_mut().expect("acquired iterator record");
            loop {
                let Some(value) = self.all_iterator_step(record, doc)? else {
                    if let Some(ready) = self.finish_all_input(group)? {
                        self.reject_any_ready(ready, doc)?;
                    }
                    return Ok(());
                };
                let index = self.append_all_placeholder(group)?;
                self.work(2)?;
                let arguments = self.promise_arguments([value])?;
                let next_promise =
                    self.call(promise_resolve.clone(), arguments, constructor.clone(), doc)?;
                // Count publication precedes the author then getter. Each
                // rejection callback has its own once bit; resolve is shared.
                let rejected = self.new_any_reject_element(group, index)?;
                self.work(2)?;
                let fulfilled = resolve.clone();
                let then = self.promise_named_get(next_promise.clone(), "then", doc)?;
                let arguments = self.promise_arguments([fulfilled, rejected])?;
                self.call(then, arguments, next_promise, doc)?;
            }
        })();
        if let Err(mut error) = result {
            if terminal(&error) {
                return Err(error);
            }
            if let Some(record) = iterator.as_ref().filter(|record| !record.done) {
                error = self.array_from_close(&record.iterator, error, doc);
            }
            let reason = self.exception_value(error)?;
            let arguments = self.promise_arguments([reason])?;
            // A throwing EOF reject reaches this outer rejection once. The
            // iterator is already done; a second reject throw escapes directly.
            self.call(reject, arguments, Value::Undefined, doc)?;
        }
        Ok(promise)
    }

    fn reject_any_ready(&mut self, ready: ReadyAllValues, doc: &mut Document) -> Result<Value> {
        let ReadyAllValues { resolve: reject, values } = ready;
        let error = self.intrinsic_aggregate_error_from_list(values)?;
        let arguments = self.promise_arguments([error])?;
        self.call(reject, arguments, Value::Undefined, doc)
    }

    pub(super) fn run_any_callback(
        &mut self,
        element: AllCaptureId,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        let value = args.first().unwrap_or(&Value::Undefined);
        match self.complete_all_element(element, value)? {
            Some(ready) => self.reject_any_ready(ready, doc),
            None => Ok(Value::Undefined),
        }
    }

    pub(super) fn promise_race(''')

receipt = {
    'selection': hashlib.sha256((A / 'root/implementation-selection.json').read_bytes()).hexdigest(),
    'paths': [{'path': n, 'sha256': hashlib.sha256((W/n).read_bytes()).hexdigest()} for n in sorted(set(changes))],
}
(A / 'root/implementation-first.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps(receipt, indent=2))
