import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(name):
    return json.loads((A / name).read_text())

def passed(label):
    path = A / 'validation' / (label + '.json')
    record = json.loads(path.read_text())
    assert record['exit'] == 0
    assert bind(path.parent / record['log'])['sha256'] == record['sha256']
    return bind(path)

final = read('source-final-2.json')['source_sha256']
parent = read('source-parent.json')['source_sha256']
for name, sha in final.items():
    assert bind(W / name)['sha256'] == sha, name
changed = sorted(name for name, sha in final.items() if parent.get(name) != sha)
assert len(final) == 1735 and len(changed) == 29
rust = read('root/rust-validation.json')
assert rust['status'] == 'pass' and rust['new_test_groups'] == 38
replay = read('root/profile-validation.json')
assert replay['status'] == 'pass'
assert sum(r['cases'] for r in replay['rows']) == 1100
assert sum(r['controls'] for r in replay['rows']) == 400
strict = [passed(label) for label in ['clippy-default-1', 'clippy-host-vulkan-1', 'fmt-check-1']]
focused = [passed(label) for label in ['any-candidate-public-2', 'any-private-1', 'any-coupling-1']]
reviews = [
    'production-review-1/review.json',
    'public-contract-1/script-review.json',
    'public-review-script-1/review.json',
    'tests-private-review-1/review.json',
    'tests-private-review-2/review.json',
    'migrations-before-1/html-review.json',
]
ledger = dict(
    status='pass', base=read('source-parent.json')['base'],
    scope='Promise.any runtime in the implemented ECMAScript subset, with intrinsic AggregateError rejection.',
    source=bind(A / 'source-final-2.json'), selected_source_inputs=1735,
    changed_source_paths=changed, production_and_registration_paths=9,
    existing_test_migration_paths=15, original_migration_groups=115,
    selected_existing_test_renames=4, new_test_modules=5, new_test_groups=38,
    public_semantic_groups=21, public_semantic_modes=42,
    public_terminal_groups=5, public_terminal_modes=20,
    private_groups=11, private_selected_operations=92,
    natural_terminal_coupling_groups=1, natural_terminal_coupling_modes=2,
    natural_terminal_sticky_readbacks=4,
    startup_observation=bind(A / 'root/startup-observation.json'),
    layout_validation=bind(A / 'root/layout-verification.json'),
    selected_accounting=bind(A / 'budget-audit-1/selection-ready.json'),
    budgets=dict(bootstrap_work=1000000, author_work=100000, cumulative_heap=8388608),
    parent_public=bind(A / 'validation/any-parent-public-1.json'),
    focused_validation=focused, source_reviews=[bind(A / name) for name in reviews],
    default_passed=3197, host_vulkan_passed=3551,
    result_rows_per_configuration=52, worker_checks_per_configuration=93,
    roster_validation=bind(A / 'root/rust-validation.json'), strict_checks=strict,
    ordinary_release=bind(A / 'eris-js-ordinary-1.json'),
    host_release=bind(A / 'eris-js-host-1.json'),
    release_source_closure=bind(A / 'root/release-source-closure-2.json'),
    replay_validation=bind(A / 'root/profile-validation.json'),
    exact_case_records=1100, exact_harness_records=400, preserved_profiles=5,
    baseline_changes=0, conformance_sources_unchanged=bind(A / 'root/unchanged-conformance-1.json'),
    first_full_interruption=bind(A / 'root/full-first-interruption.json'),
    correction=bind(A / 'migration-correction-1/source-ready.json'),
    qualifications=[
        'Initial public parent execution:22 groups fail at missing Any. The four later input groups were frozen independently and passed in the candidate; their parent absence outcome is source-derived, not an additional parent Rust run.',
        'Initial full default run stopped after2848 passed/9 failed library groups:8 socket/TCP preflights denied by the execution sandbox, plus one omitted historical constructor property count9-to10 assertion. The exact first output is retained. Corrected test-only candidate2 passes both full suites with local fixture sockets permitted; no production or quota change.',
        'The first migration composition peer missed that omitted scalar assertion. Its four declaration-owner labels name preceding functions; the explicit four function_renames entries govern exact roster preservation.',
        'A provisional installer heap ledger double-counted a72-byte bag constant. The corrected selected ledger was frozen before production and both files remain retained. One selected helper-stage label says saved Object prototype; the actual selected lookup and implementation use saved AggregateError prototype.',
        'Current TC39 EOF directly calls reject. An ordinary throw reaches one outer rejection retry after iterator done; saved final callbacks propagate directly. The earlier root suggestion of a different EOF algorithm was rejected by primary-source checks before implementation.',
        'The first inline replay verifier requested a nonexistent results field and stopped before writing; corrected cases field verifies all complete records. No observations or expectations changed.',
        'Release binaries precede only cfg(test) file migrations/modules and their exact registration fragments. Release-source closure verifies unchanged production inputs.',
        'No new Promise.any upstream profile, host envelope change, Proxy, realm or cap increase is included. All existing five selected profiles, including their failed and unsupported cases, remain unchanged.',
        'Selected source inventory is not a complete build graph. Logical work/heap and type sizes are not CPU, RSS, security certification, full web compatibility or Chromium performance measurements.',
    ])
path = A / 'root/final-validation.json'
assert not path.exists()
path.write_text(json.dumps(ledger, indent=2) + '\n')
print(json.dumps(bind(path)))
