from pathlib import Path
import difflib
import hashlib
import json

root = Path('/tmp/eris-promise-any-runtime-plan-1')
dest = root / 'documentation-1'
paths = ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
         'docs/SECURITY.md', 'docs/VALIDATION.md', 'docs/aggregate-error.md']
before = {}
for name in paths:
    snapshot = dest / 'before' / name
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    if not snapshot.exists():
        snapshot.write_bytes((root / 'worktree' / name).read_bytes())
    before[name] = snapshot.read_text()
after = dict(before)

def replace(name, old, new):
    assert after[name].count(old) == 1, (name, old)
    after[name] = after[name].replace(old, new, 1)

replace('README.md',
    'once gate for each input’s two callbacks. `any`, async functions and rejection\nnotifications remain unfinished.',
    'once gate for each input’s two callbacks. [`Promise.any`](docs/promise-any.md)\nfulfills on the first fulfillment and collects ordered rejection reasons into an\nintrinsic AggregateError when every input rejects. Async functions and rejection\nnotifications remain unfinished.')
replace('README.md',
    'Error fallback tag from `Object.prototype.toString`. `Promise.any` remains\nunfinished. The separate [AggregateError upstream profile]',
    'Error fallback tag from `Object.prototype.toString`.\nThe separate [AggregateError upstream profile]')
replace('docs/COMPATIBILITY.md',
    'capabilities and a shared gate for each input’s paired callbacks. `any`, async\nfunctions and rejection notifications remain absent. Authored regressions are\nnot a full ECMAScript conformance result.',
    'capabilities and a shared gate for each input’s paired callbacks.\n[`Promise.any`](promise-any.md) preserves the shared fulfillment callback and\nuses once-only rejection callbacks to collect reasons in input order. Empty or\nall-rejected input uses an intrinsic AggregateError. Async functions and rejection\nnotifications remain absent. These authored regressions are not a full\nECMAScript conformance result; a dedicated Any upstream profile is separate work.')
replace('docs/COMPATIBILITY.md',
    'ordinary fake objects retain their distinctions. `Promise.any` is still absent.',
    'ordinary fake objects retain their distinctions. Promise.any reuses the saved\nintrinsic AggregateError prototype without consulting the mutable global.')
replace('docs/COMPATIBILITY.md',
    '`Promise.all`, `Promise.race` and `Promise.allSettled`, DOM bindings and events',
    '`Promise.all`, `Promise.race`, `Promise.allSettled` and `Promise.any`, DOM bindings and events')
replace('docs/ROADMAP.md',
    '`Promise.any`, wider host identity policy and multiple realms remain separate work.\nRemaining asynchronous work\nincludes `any`, async functions/`await`, rejection notifications, timers,\nMutationObserver delivery and multiple realms.',
    '[`Promise.any`](promise-any.md) now implements generic synchronous iterable\ncollection with shared fulfillment and once-only rejection callbacks. Its\ndedicated pinned upstream profile remains subsequent work; existing profile\nidentity and rejection policies are unchanged. Remaining asynchronous work\nincludes async functions/`await`, rejection notifications, timers,\nMutationObserver delivery and multiple realms.')
replace('docs/ROADMAP.md',
    'accounting remains 8 MiB. This policy headroom does not establish implementation\nor measured admission for the remaining Promise APIs.',
    'accounting remains 8 MiB. The later [Promise.any checkpoint](promise-any.md)\nrecords its own measured installation costs; policy headroom alone does not\nestablish implementation or admission for future APIs.')
replace('docs/SECURITY.md',
    '## Representative limits\n',
    '[`Promise.any`](promise-any.md) reuses existing Group/Element storage and the\nshared job queue. A consumed rejection gate and moved result storage stay\nconsumed if intrinsic AggregateError construction refuses; queued author work\nremains suspended. The late metadata installer preserves earlier object IDs and\nadds no host authority, decoder capability or budget-reset site. Existing work,\nheap, call and stack limits remain unchanged. These controls do not establish\ncomplete allocation coverage, process-memory bounds or production security.\n\n## Representative limits\n')
replace('docs/aggregate-error.md',
    'profile-local ordinary-response identity capability and conformance selection.\n',
    'profile-local ordinary-response identity capability and conformance selection.\nThe later [Promise.any checkpoint](promise-any.md) reuses the saved intrinsic\nprototype and dense-array machinery for ordered rejection reasons; the API\ncheckpoint measurements and limitations below remain historical.\n')
validation = '''## Promise.any runtime

The [Promise.any checkpoint](promise-any.md) adds generic synchronous iterable
collection, shared fulfillment callbacks and ordered once-only rejection
storage. The late installer preserves earlier metadata IDs and isolated fees.
Observed startup consumes 100,986 work units, leaves 899,014 from the finite
trusted allowance and charges 1,765,018 bytes. Author work remains 100,000 and
the shared cumulative heap ceiling remains 8 MiB.

The public controls pass 26 groups across 62 mode attempts. Eleven private
groups pass 92 measured operations. The additive final-callback group passes both modes and four sticky queue
readbacks.
Four existing actual-layout runs retain the prior type widths in both
toolchains and selected ordinary/host configurations.

The first default full-suite attempt stopped after 2,848 library passes and
nine failures, before later targets. Eight socket/TCP fixtures were denied by
the tool sandbox, and one old
constructor-property count still expected nine instead of ten. The retained
correction changes that single assertion; production and quota expectations
are unchanged. A complete rerun uses the required test permissions.

The complete runs pass 3,197 Rust 1.88 default tests and 3,551 Rust 1.99
tests with `test262-host,vulkan-raster`, each across 52 result rows with no
failed, ignored or filtered tests. The parent rosters survive four selected
boundary-name renames and gain all 38 new groups. Strict all-target Clippy passes
in both configurations, and formatting passes.

The rebuilt Rust 1.88 ordinary and host adapters preserve all 1,100 case
records and 400 harness records across the five existing profiles. Complete
arrays match the published parent, including failed and unsupported outcomes;
there are no baseline or policy changes. Later changes after those builds are
test-only, with unchanged production inputs bound in the evidence.
No Promise.any upstream profile or pass count is claimed. The historical
checkpoint sections below retain their original results.

'''
replace('docs/VALIDATION.md', '# Validation record\n\n', '# Validation record\n\n' + validation)
after['docs/promise-any.md'] = '''# Promise.any

`Promise.any` consumes a synchronous iterable and fulfills the built-in Promise
result on the first fulfillment. If every input rejects, it rejects with an
intrinsic AggregateError whose dense `errors` Array preserves input order and
the original rejection values. Empty input rejects with an empty errors Array.
Generic receivers return their capability object. The method has name `any`,
length one and no constructor behavior.

Capability construction precedes a single `C.resolve` lookup, followed by
iterator acquisition and a cached `next`. Each input goes through that resolve
and an observable `then` lookup/call. The original capability resolve is passed
directly to every `then`; custom callbacks retain their return and throw behavior.
Iteration continues after synchronous fulfillment. Each rejection callback has
its own once gate. A sentinel prevents synchronous rejections from completing
the aggregate before normal iterator exhaustion; duplicate callbacks return
`undefined` without inspecting storage that may already have moved.

The all-rejected result uses the saved AggregateError prototype, its private
Error brand and the intrinsic Array machinery. It creates an own writable,
configurable, nonenumerable `errors` property, without own message or cause.
Replacing global constructors or inherited setters does not intercept creation.
A saved final rejection callback returns the custom reject result or propagates
its throw. At normal exhaustion, an ordinary throw from the first reject call
reaches the outer reject once more; a second throw escapes, and the completed
iterator is not closed. Terminal errors bypass this ordinary retry.

Ordinary iterator acquisition and step failures reject without closing. Later
ordinary resolve/then failures close an open iterator before rejection, retaining
the original pending error across ordinary close failures. Resource-limit and
unsupported-operation failures stop author close/reject work and suspend
unstarted jobs. Allocation failure during a final rejection callback leaves
its gate consumed and Group storage moved; later checkpoints do not resume the
queued work.

Existing Group/Element arenas and the shared FIFO are reused. Public dispatch
costs eight work units and the body 17 plus one retained reject copy. Creating a
rejection callback costs 136 before growth; first completion costs 28 and
duplicates 12. Intrinsic
error creation adds an eight-unit envelope before separately charged helpers:
134 units on the tested warm fixture, with growth additional. These logical
tariffs are not CPU instruction counts or bounds on recursive object destruction.

Late installation adds one metadata bag after AggregateError, preserving every
prior ID and the old isolated Promise/AggregateError installer fees. The measured
constructor order grows from length/capacity 9/9 to 10/10. This branch adds
189 work units and 3,147 accounted bytes, including the extra upfront object
slot. A fixture with physical order spare separately exercises the 171-unit
branch. Raw startup consumes 100,986 units and leaves 899,014 of 1,000,000;
accounted allocation is 1,765,018 bytes. There are 755 objects, 300 native entries,
26 prototypes and 213 globals. Successful public construction still supplies
100,000 author units, sharing the unchanged cumulative 8 MiB heap ceiling.

Four actual-layout runs retain the previous enum, record and runtime widths on
the tested x86_64 Linux configurations. No new arena or Runtime field is added.
These observations and logical heap charges are not RSS or native-stack
measurements and do not establish layouts on other targets.

The public controls pass 26 groups across 62 strict/sloppy mode attempts.
Eleven private groups pass 92 measured operations, covering admission, partial
publication, paid payload ownership, reserve failure and duplicate callbacks.
The additive final-callback group passes both modes and four sticky queue
readbacks.

The first full-suite attempt stopped after 2,848 library passes and nine
failures, before later targets: eight socket/TCP permission denials and one
missed old constructor-property count. The latter
receives a single assertion migration from nine to ten; production and selected
quota expectations remain unchanged. The rerun uses the required test permissions.

The complete runs pass 3,197 Rust 1.88 default tests and 3,551 Rust 1.99
tests with `test262-host,vulkan-raster`, each across 52 result rows with no
failed, ignored or filtered tests. The parent rosters survive four selected
boundary-name renames and gain all 38 new groups. Strict all-target Clippy passes
in both configurations, and formatting passes.

The rebuilt Rust 1.88 ordinary and host adapters preserve all 1,100 case
records and 400 harness records across the five existing profiles. Complete
arrays match the published parent, including failed and unsupported outcomes;
there are no baseline or policy changes. Later changes after those builds are
test-only, with unchanged production inputs bound in the evidence.

A dedicated Promise.any upstream selection remains separate work. The current
language subset still excludes classes, Proxy, async functions and multiple
realms. Conformance decoder identities and final-unhandled-rejection policy
remain unchanged; browser rejection notifications are still absent.
This checkpoint makes no full-web-compatibility, security-audit, process-memory,
GPU or Chromium-relative performance claim. Earlier chapter results and evidence
archives remain historical.

The [evidence manifest](evidence/promise-any/manifest.json) and
[source/check archive](evidence/promise-any/sources-and-checks.tar.gz) bind the
selected source, controls, accounting and observed validation records.
'''
for name, text in after.items():
    raw = dest / 'raw' / name
    raw.parent.mkdir(parents=True, exist_ok=True)
    raw.write_text(text)
    diff = dest / 'diffs' / (name + '.patch')
    diff.parent.mkdir(parents=True, exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(before.get(name, '').splitlines(True), text.splitlines(True), fromfile='a/' + name if name in before else '/dev/null', tofile='b/' + name)))
notes = {
    'status': 'Final payload prepared from observed receipts; see source-ready seal',
    'paths': list(after),
    'pending': [],
    'historical_preservation': 'VALIDATION prior body retained as exact suffix; AggregateError original body below the introduction retained; earlier API chapters/archives not changed.',
    'source_counts': 'No source-input or full-suite total inferred.',
    'before_sha256': {name: hashlib.sha256((dest / 'before' / name).read_bytes()).hexdigest() for name in before},
}
(dest / 'draft-status.json').write_text(json.dumps(notes, indent=2) + '\n')
