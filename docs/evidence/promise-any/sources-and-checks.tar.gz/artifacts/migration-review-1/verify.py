from pathlib import Path
import json,hashlib,subprocess,re,difflib,collections
N=Path('/tmp/eris-promise-any-runtime-plan-1');W=N/'worktree';H=N/'migrations-before-1';R=N/'migration-review-1';BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def check(x):
 p=Path(x['path']);b=p.read_bytes();assert sha(b)==x['sha256'],str(p);assert len(b)==x['bytes'];return b
m=json.loads((H/'source-ready.json').read_text());e=json.loads((H/'edit-manifest.json').read_text());parent=json.loads((N/'source-parent.json').read_text())['source_sha256']
assert sha((H/'source-ready.json').read_bytes())=='093ff0d7f642fe1693b4d9becec103f0d5d2c9a334168d0b85e30a997f8c32a2'
for k in ['source_parent','implementation_selection','fee_selection','scope','edit_manifest','author']:check(m[k])
renames={x['before']:x['after'] for x in e['function_renames']};assert len(renames)==4
rows=[];total_groups=0;literal_changes=[]
for row in m['files']:
 rel=row['relative'];old=check(row['before']);new=check(row['raw']);patch=check(row['diff'])
 assert old==subprocess.check_output(['git','show',BASE+':'+rel],cwd=W);assert sha(old)==parent[rel]
 s=old.decode();edits=[x for x in e['edits'] if x['relative']==rel]
 for x in edits:
  assert s.count(x['old'])==x['count'],(rel,x['old'],s.count(x['old']),x['count']);s=s.replace(x['old'],x['new'])
 assert s.encode()==new,(rel,'not exact forward')
 assert ''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)).encode()==patch
 # Whole source reversion using independent opcode reconstruction; verify every replacement remains exactly the declared edit composition.
 assert ''.join(difflib.restore(list(difflib.ndiff(old.decode().splitlines(True),new.decode().splitlines(True))),1)).encode()==old
 pat=r'#\[test\]\s*fn\s+(\w+)';a=re.findall(pat,old.decode());z=re.findall(pat,new.decode());assert [renames.get(x,x) for x in a]==z;total_groups+=len(a)
 # Existing raw string fixtures remain byte exact except the three selected own-name membership insertions.
 rawpat=r'r(#+)"(.*?)"\1';aa=[v for _,v in re.findall(rawpat,old.decode(),re.S)];zz=[v for _,v in re.findall(rawpat,new.decode(),re.S)];assert len(aa)==len(zz)
 for i,(x,y) in enumerate(zip(aa,zz)):
  if x!=y:
   assert x.replace("length,name,prototype,resolve,reject,all,race,allSettled'","length,name,prototype,resolve,reject,all,race,allSettled,any'")==y
   literal_changes.append({'path':rel,'raw_literal_index':i})
 rows.append({'path':rel,'before_sha256':sha(old),'raw_sha256':sha(new),'edits':len(edits),'test_groups':len(a),'declared_replacements_exact':True,'published_parent_equal':True,'raw_strings_checked':len(aa)})
assert len(rows)==15;assert len(literal_changes)==3
for rel in ['src/script/processing_instruction/key_cache_tests.rs','src/script/promises/install_tests.rs','src/script/text_operations/key_cache_tests.rs']:
 s=(H/'raw'/rel).read_text()
 for n in ['99_693','99_694','100_000','100_796','100_797','100_985','100_986','1_000_000']:assert '('+n+',' in s
 assert '(100_797, false, 0)' in s and '(100_985, false, 0)' in s and '(100_986, true, 0)' in s and '(1_000_000, true, 899_014)' in s
for rel in ['src/script/promises/install_tests.rs','src/script/promises/shared_key_tests.rs']:
 s=(H/'raw'/rel).read_text();old=(H/'before'/rel).read_text()
 for number in ['1570','1569','1532','1531','1863','1862','331','330']:
  assert s.count(number)==old.count(number)
for rel in ['src/script/aggregate_error/install.rs','src/script/aggregate_error/install/tests.rs','src/script/array_buffer/tests.rs','src/script/data_view/tests.rs']:
 if (W/rel).exists():assert (W/rel).read_bytes()==subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
checks={'status':'clear','manifest':bind(H/'source-ready.json'),'files':rows,'test_groups_preserved':total_groups,'renames':e['function_renames'],'raw_literal_changes':literal_changes,'all_three_raw_boundary_matrices_preserve_old_inputs_and_add_selected_cuts':True,'old_standalone_shared_pair_fees_literal_counts_preserved':True,'execution':'Read-only Git plus Python stdlib; no project imports/execution or live source edits.'}
(R/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps({'files':len(rows),'retained_groups':total_groups,'edits':sum(x['edits'] for x in rows),'raw_literal_changes':len(literal_changes),'checks':bind(R/'checks.json')}))
