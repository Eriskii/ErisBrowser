"""Read retained artifacts only; no project imports, tests, builds or live edits."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess

H = Path(__file__).resolve().parent
N = H.parent
W = N / 'worktree'
BASE = '30576b1d977a6590099b5c4748abac9f188bc05c'

def sha(data): return hashlib.sha256(data).hexdigest()
def read(path): return json.loads(path.read_text())
def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))
def dump(name, value):
    (H / name).write_text(json.dumps(value, indent=2) + '\n')
def receipt(directory, label, exit_code=0):
    p = directory / (label + '.json')
    r = read(p)
    log = directory / r['log']
    assert r['exit'] == exit_code, (label, r['exit'])
    assert sha(log.read_bytes()) == r['sha256'], label
    return dict(record=bind(p), log=bind(log), command=r['command'], exit=r['exit'])
def test_rows(path, before_failures=False):
    text = path.read_text()
    if before_failures:
        text = text.split('\nfailures:\n', 1)[0]
    return re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored[^\n]*)$', text, re.M)

parent = read(N/'source-parent.json')['source_sha256']
expected_additions = []
raw_modules = [
    ('public-contract-1/tests-raw/src/script/promise_any_semantic_tests.rs', 'script::promise_any_semantic_tests'),
    ('public-contract-1/tests-raw/src/script/promise_any_abort_tests.rs', 'script::promise_any_abort_tests'),
    ('public-review-1/tests-raw/src/script/promise_any_input_tests.rs', 'script::promise_any_input_tests'),
    ('tests-private-1/raw/src/script/promises/any_quota_tests.rs', 'script::promises::any_quota_tests'),
    ('tests-private-2/raw/src/script/promises/any_coupling_tests.rs', 'script::promises::any_coupling_tests'),
]
for path, module in raw_modules:
    names = re.findall(r'^#\[test\]\nfn (\w+)\(', (N/path).read_text(), re.M)
    expected_additions.extend(module+'::'+name for name in names)
assert len(expected_additions) == len(set(expected_additions)) == 38
renames = read(N/'migrations-before-1/edit-manifest.json')['function_renames']
assert len(renames) == 4
expected = {}
parent_receipts = []
resolved_renames = None
for configuration, label, count in [('default', 'default-full-2', 3159), ('host-vulkan', 'host-vulkan-full-2', 3513)]:
    parent_receipts.append(receipt(N/'rust-parent', label))
    rows = test_rows(N/'rust-parent'/(label+'.log'))
    assert len(rows) == len(set(x[0] for x in rows)) == count
    assert {x[1] for x in rows} == {'ok'}
    names = {x[0] for x in rows}
    pairs = []
    for item in renames:
        matching = [x for x in names if x.endswith('::'+item['before'])]
        assert len(matching) == 1, item
        old = matching[0]
        new = old.removesuffix(item['before']) + item['after']
        assert new not in names
        names.remove(old); names.add(new)
        pairs.append(dict(before=old, after=new))
    if resolved_renames is None: resolved_renames = pairs
    else: assert resolved_renames == pairs
    assert not names.intersection(expected_additions)
    names.update(expected_additions)
    assert len(names) == count+38
    expected[configuration] = sorted(names)
dump('expected-final-rosters-2.json', {
    'status': 'source-derived only from retained parent rosters and frozen test sources; candidate logs are not inputs',
    'base': BASE, 'parent_receipts': parent_receipts,
    'new_test_source_bindings': [bind(N/p) for p, _ in raw_modules],
    'exact_four_renames': resolved_renames,
    'renames_qualification': 'Uses the explicit function_renames table; the four ancillary owners labels for declarations are known to refer to the preceding function.',
    'new_groups': sorted(expected_additions), 'new_group_count': 38,
    'expected_counts': {k:len(v) for k,v in expected.items()}, 'expected_rosters': expected,
    'correction': bind(N/'migration-correction-1/source-ready.json'),
    'correction_roster_effect': 'one old assertion only; no additional group or rename'
})

focused = []
for label, selected, fail in [
    ('any-parent-public-1', expected_additions[:22], True),
    ('any-candidate-public-1', expected_additions[:22], False),
    ('any-candidate-public-2', expected_additions[:26], False),
    ('any-private-1', expected_additions[26:37], False),
    ('any-coupling-1', expected_additions[37:], False),
]:
    rec = receipt(N/'validation', label, 101 if fail else 0)
    rows = test_rows(N/'validation'/(label+'.log'), before_failures=fail)
    assert len(rows) == len(selected)
    assert {x[0] for x in rows} == set(selected), label
    assert {x[1] for x in rows} == ({'FAILED'} if fail else {'ok'}), label
    rec.update(groups=len(rows), names=sorted(x[0] for x in rows))
    if fail:
        rec['qualification'] = '22 first sloppy missing-method failures only; strict/assertions/readbacks unreached. No claim of parent execution for four later supplemental public groups.'
    focused.append(rec)

layout_summary = read(N/'root/layout-verification.json')
layouts = []
for row in layout_summary['rows']:
    label = row['label']; rec = receipt(N/'validation', label)
    assert rec['record']['sha256'] == row['record_sha256']
    log = (N/'validation'/(label+'.log')).read_text()
    entries = re.findall(r'^PROMISE_ALL_LAYOUT_ACTUAL (\S+) bytes=(\d+) align=(\d+)$', log, re.M)
    layout = {name:dict(bytes=int(size),align=int(align)) for name,size,align in entries}
    assert len(entries) == len(layout) == 23 and layout == row['layout']
    tests = test_rows(N/'validation'/(label+'.log'))
    assert tests == [('script::promises::all_layout_tests::all_actual_private_layout_matches_four_configuration_prospective_mirror','ok')]
    assert layout['Runtime']['bytes'] == (1872 if 'host' in label else 1808)
    rec.update(layout=layout, qualification='Actual existing-layout test; four configured x86_64 runs, no fresh prospective full-mirror run claimed here.')
    layouts.append(rec)

binaries = {}
for kind in ['ordinary','host']:
    p=N/('eris-js-'+kind+'-1.json'); j=read(p)
    assert sha(Path(j['binary']).read_bytes()) == j['sha256']
    assert len(Path(j['binary']).read_bytes()) == j['bytes']
    assert sha(Path(j['source_inventory']).read_bytes()) == j['source_sha256']
    build = receipt(N/'validation','any-release-'+kind+'-1')
    binaries[kind]=dict(record=bind(p),binary=bind(Path(j['binary'])),build=build)

profile_summary = read(N/'root/profile-validation.json')
profiles = []
for row in profile_summary['rows']:
    profile=row['profile']; p=N/('upstream-'+profile+'-1.json'); old=N/'replay-parent'/p.name
    current=read(p); prior=read(old)
    assert bind(p)['sha256']==row['sha256'] and bind(old)['sha256']==row['parent_sha256']
    for field in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:
        assert current[field]==prior[field], (profile,field)
    assert len(current['cases'])==row['cases'] and len(current['harness_preflight'])==row['controls']
    assert dict(collections.Counter(c['status'] for c in current['cases']))==current['counts']==row['counts']
    assert all(c['verified'] for c in current['harness_preflight']) and current['harness_preflight_passed']
    assert current['regressions']==[] and current['improvements']==[]
    policy=sha(json.dumps(current['runner_policy'],sort_keys=True).encode())
    assert policy==current['runner_policy_sha256']
    kind='ordinary' if profile=='aggregate-error' else 'host'
    assert current['binary_sha256']==binaries[kind]['binary']['sha256']
    matches=[r for r,v in parent.items() if v==current['corpus_manifest_sha256'] and r.endswith('/manifest.json')]
    assert len(matches)==1 and sha((W/matches[0]).read_bytes())==current['corpus_manifest_sha256']
    profiles.append(dict(profile=profile,report=bind(p),parent_report=bind(old),execution=receipt(N/'validation','upstream-'+profile+'-1'),cases=len(current['cases']),controls=len(current['harness_preflight']),full_arrays_equal=True,runner_policy_sha256=policy,corpus=bind(W/matches[0]),binary_kind=kind))
assert sum(x['cases'] for x in profiles)==1100 and sum(x['controls'] for x in profiles)==400

first=receipt(N/'validation','default-full-1',101)
first_log=(N/'validation/default-full-1.log').read_text()
first_rows=test_rows(N/'validation/default-full-1.log',before_failures=True)
assert len(first_rows)==2857 and collections.Counter(x[1] for x in first_rows)=={'ok':2848,'FAILED':9}
assert first_log.count('Os { code: 1, kind: PermissionDenied, message: "Operation not permitted" }')==8
failure_names=[name for name,status in first_rows if status=='FAILED']
missed='script::promises::shared_key_identity_tests::shared_job_key_payloads_preserve_all_eleven_function_bags_and_existing_ids'
assert missed in failure_names
first.update(lib_rows=2857,passed=2848,failed=9,failed_names=sorted(failure_names),qualification='One missed constructor count migration plus eight socket preflight EPERM failures. Cargo stopped after lib; this is not a full passing roster. Nested worker failure text is not double-counted as extra tests.')

source_final=read(N/'source-final.json')['source_sha256']
source_binary=read(N/'source-binary-1.json')['source_sha256']
assert len(parent)==1730 and len(source_final)==1735
changed=sorted(p for p in set(parent)|set(source_final) if parent.get(p)!=source_final.get(p))
assert len(changed)==29
binary_delta=sorted(p for p in set(source_binary)|set(source_final) if source_binary.get(p)!=source_final.get(p))
expected_delta={r['relative'] for r in read(N/'migrations-before-1/source-ready.json')['files']}
expected_delta.update(['src/script/promises.rs','src/script/promises/any_quota_tests.rs','src/script/promises/any_coupling_tests.rs'])
assert set(binary_delta)==expected_delta
# Root's later correction may already be imported. This is the unchanged
# production module; stripping the two exact test-only append fragments
# reconstructs the retained release-source hash without executing a formatter.
promise=(W/'src/script/promises.rs').read_text()
assert sha(promise.encode())==source_final['src/script/promises.rs']
for name in ['any_quota_tests','any_coupling_tests']:
    fragment='\n#[cfg(test)]\nmod '+name+';\n'; assert promise.count(fragment)==1
    promise=promise.replace(fragment,'')
assert sha(promise.encode())==source_binary['src/script/promises.rs']
preserved={}
for root in ['tools','tests/conformance','tests/upstream']:
    differences=subprocess.check_output(['git','diff','--name-only',BASE,'--',root],cwd=W,text=True).splitlines()
    new=subprocess.check_output(['git','ls-files','--others','--exclude-standard','--',root],cwd=W,text=True).splitlines()
    assert differences==[] and new==[]
    preserved[root]=dict(tracked_differences=[],untracked_additions=[])

dump('interim-review.json', {
    'status':'interim clear for retained focused/layout/replay evidence; full corrected suites and final ledger pending',
    'base':BASE,'expected_rosters':bind(H/'expected-final-rosters-2.json'),
    'focused':focused,'layout_summary':bind(N/'root/layout-verification.json'),'layouts':layouts,
    'binary_records':binaries,'profiles':profiles,'profile_totals':dict(cases=1100,controls=400),
    'first_default_failure':first,'selected_correction':bind(N/'migration-correction-1/source-ready.json'),
    'source_final_candidate1':bind(N/'source-final.json'),'source_binary':bind(N/'source-binary-1.json'),
    'source_counts':dict(parent=1730,candidate1=1735,changed_paths=29),'changed_paths':changed,
    'release_to_candidate1_delta':binary_delta,'release_production_closure':'All deltas are15 selected test modules, two new private test modules and two exact cfg(test) registration fragments; removing fragments recovers binary-source promises.rs hash.',
    'old_tooling_corpus_baselines':preserved,
    'qualifications':['Parent Rust logs belong to published AggregateError API checkpoint; the intervening30576b1 tooling commit changed no Rust/Cargo.','Current layout runs execute the existing actual-layout oracle; no fresh full proposed mirror is claimed.','No full current suite passes are asserted until corrected terminal receipts arrive.','Eight initial socket failures require environment rerun; single old count failure requires the explicit retained correction.','No project execution or live writes by reviewer.'],
    'pending':['source-final-2 binding after one-assertion correction','corrected full default and host+vulkan rosters','strict Clippy and formatter receipts','root final-validation ledger']
})
print(json.dumps(dict(interim=bind(H/'interim-review.json'),expected=bind(H/'expected-final-rosters-2.json'))))
