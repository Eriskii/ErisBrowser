"""Independent static receipt/source reconciliation; no project execution."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess

H = Path(__file__).resolve().parent
N = H.parent
W = N / 'worktree'
BASE = '30576b1d977a6590099b5c4748abac9f188bc05c'
def read(p): return json.loads(p.read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p))
def receipt(label):
    p=N/'validation'/(label+'.json'); r=read(p); log=p.parent/r['log']
    assert r['exit']==0 and digest(log)==r['sha256']
    return dict(record=bind(p),log=bind(log),command=r['command'])
def bindings(value):
    if isinstance(value,dict):
        if {'path','sha256'} <= value.keys():
            p=Path(value['path']); assert digest(p)==value['sha256'], str(p)
            if 'bytes' in value: assert p.stat().st_size==value['bytes'], str(p)
        for v in value.values(): bindings(v)
    elif isinstance(value,list):
        for v in value: bindings(v)

interim=read(H/'interim-review.json')
bindings(interim)
expected=read(H/'expected-final-rosters-2.json')
ledger=read(N/'root/final-validation.json')
bindings(ledger)
assert ledger['status']=='pass' and ledger['base']==BASE
assert digest(N/'root/final-validation.json')=='61858a4cb1d0e64fa7616f90ae155810ff975f08b544bb77e5a24e0890e3264d'

parent=read(N/'source-parent.json')['source_sha256']
old=read(N/'source-final.json')['source_sha256']
final=read(N/'source-final-2.json')['source_sha256']
binary=read(N/'source-binary-1.json')['source_sha256']
assert len(parent)==1730 and len(final)==1735 and parent.keys()<=final.keys()
for path,sha in final.items(): assert digest(W/path)==sha,path
changed=sorted(p for p in final if parent.get(p)!=final[p])
assert changed==ledger['changed_source_paths'] and len(changed)==29
assert sorted(p for p in final if old.get(p)!=final[p])==['src/script/promises/shared_key_identity_tests.rs']
correction=read(N/'migration-correction-1/source-ready.json'); bindings(correction)
b=Path(correction['before']['path']).read_bytes(); a=Path(correction['raw']['path']).read_bytes()
before=b'assert_eq!(runtime.objects[constructor].values.len(), 9);'
after=b'assert_eq!(runtime.objects[constructor].values.len(), 10);'
assert b.count(before)==1 and b.replace(before,after)==a
assert hashlib.sha256(b).hexdigest()==old[correction['relative']]
assert hashlib.sha256(a).hexdigest()==final[correction['relative']]
migration_paths={r['relative'] for r in read(N/'migrations-before-1/source-ready.json')['files']}
new_paths=set(final)-set(parent)
production=set(changed)-migration_paths-new_paths
assert len(migration_paths)==15 and len(new_paths)==5 and len(production)==9
assert {p.removeprefix('src/').removesuffix('.rs').replace('/','::') for p in new_paths}=={
    x.rsplit('::',1)[0] for x in expected['new_groups']}
tracked=subprocess.check_output(['git','diff','--name-only',BASE],cwd=W,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
assert set(tracked)|set(untracked)==set(changed)
assert set(untracked)==new_paths and len(tracked)==24
intervening=subprocess.check_output(['git','diff','--name-only',
    'd3efc9aba87102366b538ff69e83c2524a48eb6b',BASE,'--','src','Cargo.toml','Cargo.lock','build.rs','assets'],cwd=W,text=True)
assert intervening==''

closure=read(N/'root/release-source-closure-2.json'); bindings(closure)
delta=sorted(p for p in set(binary)|set(final) if binary.get(p)!=final.get(p))
assert delta==closure['changes_after_release_builds']==interim['release_to_candidate1_delta']
assert set(delta)==migration_paths|{'src/script/promises.rs','src/script/promises/any_quota_tests.rs','src/script/promises/any_coupling_tests.rs'}
promise=(W/'src/script/promises.rs').read_text()
for name in ['any_quota_tests','any_coupling_tests']:
    fragment='\n#[cfg(test)]\nmod '+name+';\n'
    assert promise.count(fragment)==1; promise=promise.replace(fragment,'')
assert hashlib.sha256(promise.encode()).hexdigest()==binary['src/script/promises.rs']

root_rust=read(N/'root/rust-validation.json'); bindings(root_rust)
full=[]
for configuration,label,total in [('default','default-full-2',3197),('host-vulkan','host-vulkan-full-1',3551)]:
    rec=receipt(label); text=Path(rec['log']['path']).read_text()
    results=re.findall(r'^test (\S+) \.\.\. (\S+)$',text,re.M)
    assert len(results)==len({n for n,s in results})==total and {s for n,s in results}=={'ok'}
    names=sorted(n for n,s in results)
    assert names==expected['expected_rosters'][configuration]
    summaries=[list(map(int,m)) for m in re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M)]
    assert len(summaries)==52 and [sum(r[i] for r in summaries) for i in range(5)]==[total,0,0,0,0]
    # Independently retain harness attribution to join root's qualified roster.
    harness=None; qualified=[]; by_harness=collections.Counter()
    for line in text.splitlines():
        match=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
        if match: harness=match[1]
        if 'Doc-tests ' in line: harness='Doc-tests '+line.split('Doc-tests ',1)[1]
        match=re.match(r'^test (\S+) \.\.\. ok$',line)
        if match:
            assert harness is not None
            qualified.append(harness+'::'+match[1]); by_harness[harness]+=1
    comparison=next(r for r in root_rust['comparisons'] if r['current']['log']['sha256']==rec['log']['sha256'])
    assert sorted(qualified)==comparison['current']['passed_names']
    worker={h:n for h,n in by_harness.items() if 'worker' in h}
    assert sum(worker.values())==93,worker
    rec.update(configuration=configuration,passed=total,result_rows=52,worker_checks=93,
        roster_exact=True,worker_harnesses=worker)
    full.append(rec)
assert ledger['default_passed']==3197 and ledger['host_vulkan_passed']==3551
assert ledger['new_test_groups']==38 and ledger['selected_existing_test_renames']==4

strict=[receipt(x) for x in ['clippy-default-1','clippy-host-vulkan-1','fmt-check-1']]
for r in strict[:2]:
    assert '--all-targets' in r['command'] and r['command'][-3:]==['--','-D','warnings']
assert strict[0]['command'][1]=='+1.88.0' and strict[1]['command'][1]=='+1.99.0'
assert strict[1]['command'][strict[1]['command'].index('--features')+1]=='test262-host,vulkan-raster'
assert strict[2]['command'][-2:]==['--','--check']
startup=read(N/'root/startup-observation.json')
assert startup['raw_line'] in (N/'validation/any-private-1.log').read_text()
assert startup['log_sha256']==digest(N/'validation/any-private-1.log')
assert [startup[k] for k in ['work','remaining','accounted_heap','objects','capacity']]==[100986,899014,1765018,755,755]
assert startup['work']+startup['remaining']==1000000
assert ledger['budgets']==dict(bootstrap_work=1000000,author_work=100000,cumulative_heap=8388608)
source=(W/'src/script.rs').read_text()
for declaration in ['const MAX_STEPS: usize = 100_000;','const BOOTSTRAP_STEPS: usize = 1_000_000;','const MAX_HEAP: usize = 8 * 1024 * 1024;']:
    assert declaration in source,declaration
assert (ledger['exact_case_records'],ledger['exact_harness_records'],ledger['preserved_profiles'])==(1100,400,5)
first=read(N/'root/full-first-interruption.json')
assert first['log_sha256']==interim['first_default_failure']['log']['sha256']
assert sorted(first['failures'])==interim['first_default_failure']['failed_names']
assert first['source_inventory_sha256']==digest(N/'source-final.json')

out=dict(status='clear',reviewer='script',scope='Independent static source, receipt, complete roster and replay reconciliation; no project execution or live edits.',
    base=BASE,root_final_validation=bind(N/'root/final-validation.json'),source=bind(N/'source-final-2.json'),
    selected_inventory_inputs=1735,changed_paths=changed,
    source_composition=dict(production_and_registration_paths=sorted(production),existing_test_migrations=15,new_test_modules=5,
        all_selected_current_hashes_match=True,tracked_changes=24,untracked_new_modules=5,no_additional_worktree_changes=True),
    interim_focused_layout_replay_review=bind(H/'interim-review.json'),
    expected_rosters=bind(H/'expected-final-rosters-2.json'),full_suites=full,
    root_roster_ledger=bind(N/'root/rust-validation.json'),strict_checks=strict,
    release_source_closure=bind(N/'root/release-source-closure-2.json'),release_production_matches_final=True,
    startup=bind(N/'root/startup-observation.json'),
    profiles=dict(full_case_records_equal=1100,full_control_records_equal=400,profiles=5,all_controls_verified=True,
        compared_fields=['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts'],old_tools_corpora_baselines_unchanged=True),
    initial_failure=bind(N/'root/full-first-interruption.json'),correction=bind(N/'migration-correction-1/source-ready.json'),
    qualifications=[
        'Original source-final is retained as candidate1. Its first full run stopped after 2848 library passes and nine failures: eight sandbox EPERM socket preflights and one omitted historical constructor-property count. Candidate2 changes only that assertion from nine to ten and passes both complete suites with local fixture sockets allowed.',
        'The original migration authoring and initial source peer were incomplete: they missed the scalar assertion. That prior clear receipt is retained as prior-stage scope. Four ancillary declaration-owner labels also name preceding functions; only the explicit four function_renames govern roster normalization.',
        'Full candidate rosters equal retained parent rosters with exactly four selected renames and 38 frozen new tests. Parent API Rust inputs were unchanged by the intervening tooling-only checkpoint.',
        'Parent public execution observed 22 first sloppy missing-method failures; strict and later checks were unreached. Four additional input groups have no separately executed parent baseline.',
        'The four current layout runs exercise the existing actual-layout oracle, 23 rows each. They are not a newly executed full proposed-type mirror. Observations and physical vector capacities are x86_64-specific evidence.',
        'Release binaries were built before test-only migrations, the two private modules and their cfg(test) registrations. The exact release production closure is reconstructed; no release rebuild after the test count correction is claimed.',
        'The natural terminal coupling is a saved final Any rejection callback allocation refusal, with consumed gate and transferred Group values. It does not establish a separate EOF-path allocation-fault observation.',
        'A retained reviewer verifier attempt used compact JSON when recomputing runner-policy hashes; the corrected inert verifier uses the runner actual sorted default-spacing serialization. No project observations, policies or expectations were edited.',
        'Five existing complete profile records include their prior failed and unsupported cases; this is preservation, not a new Promise.any upstream profile or a claim of full language/browser conformance.',
        'Selected inventory is not a complete build graph. No CPU/RSS/security/whole-browser performance inference or remote current-checkpoint CI result is claimed.'
    ],
    verifier=bind(Path(__file__)),retained_helper_attempt=bind(H/'interim-attempt-1.log'))
target=H/'final-review.json'; assert not target.exists()
target.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(bind(target)))
