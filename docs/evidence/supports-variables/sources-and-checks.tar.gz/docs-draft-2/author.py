from pathlib import Path
import json,hashlib,difflib,subprocess,re
Q=Path('/tmp/eris-supports-var-plan-1');H=Q/'docs-draft-2';PRE=Q/'docs-draft-1';BASE='339b257f3e9e5ac45ab1bd85d00e1a4be36b307f';GIT='/tmp/eris-pointer-events-plan-1/worktree'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_bytes(b if isinstance(b,bytes) else b.encode())
def js(p,j):write(p,json.dumps(j,indent=2)+'\n')
def once(text,old,new):
 assert text.count(old)==1,old;return text.replace(old,new,1)
raw={entry['path']:(PRE/'raw'/entry['path']).read_text() for entry in json.loads((PRE/'draft-ready.json').read_text())['files']}
changes=[]
def replace(path,old,new):
 raw[path]=once(raw[path],old,new);changes.append({'path':path,'before':old,'after':new})
replace('docs/COMPATIBILITY.md','pointer-targeting chapter retains its original validation and scope record.','pointer-targeting chapter retains its original validation totals.')
replace('docs/VALIDATION.md','''20 new groups: 12 semantic, two direct/confined pixel and six private budget
groups. This is the authored roster, not an observed candidate pass count.

**Pending final validation:** [PENDING_Q_FOCUSED_RESULTS],
[PENDING_Q_FULL_RUST_ROSTERS], [PENDING_Q_STRICT_FORMAT_RELEASE],''','''20 new groups: 12 semantic, two direct/confined pixel and six private budget
groups. The focused Rust 1.88 run passes all 20 groups across 63 result rows.
The full Rust 1.88 default suite passes 3,597 tests; Rust 1.99 with
`test262-host,vulkan-raster` passes 3,962. Both full runs include ignored tests
and report zero failures or ignored tests across 64 result rows each.

**Pending final validation:** [PENDING_Q_STRICT_FORMAT_RELEASE],''')
replace('docs/VALIDATION.md','''execution receipts. No final outcome is inferred from the parent run.

Candidate1 currently binds 15,328 selected source/build/test inputs and 11 changed
source paths. Its inventory SHA-256 is''','''execution receipts. No unobserved check is inferred from the completed runs.

The tested Candidate1 inventory binds 15,328 selected source/build/test inputs
and 11 changed source paths. Its SHA-256 is''')
replace('docs/VALIDATION.md','''[PENDING_Q_FINAL_SOURCE_BINDING: confirm this inventory or identify the selected
successor; retain Candidate1 if superseded.]''','''[PENDING_Q_FINAL_SOURCE_BINDING: bind the tested inventory and separate final
documentation delta.] The later `tests/conformance/supports.md` update changes
prose in a path included by that inventory; the final published tree therefore
need not match every tested inventory row. Executable and test-code inputs stay
as tested, and the documentation-only difference is bound separately.''')
replace('docs/VALIDATION.md','''source-level coverage counts until the corresponding tests complete.''','''source-level coverage counts for the completed focused controls, rather than
additional test groups.''')
replace('docs/css-supports-variables.md','''Candidate execution and final checks
remain **pending in this draft**: [PENDING_Q_FOCUSED_RESULTS],
[PENDING_Q_FULL_RUST_ROSTERS], [PENDING_Q_STRICT_FORMAT_RELEASE],''','''The focused candidate run passes all 20 groups. Full Rust 1.88 default and
Rust 1.99 `test262-host,vulkan-raster` runs pass 3,597 and 3,962 tests respectively,
with ignored tests included, zero failures or ignored tests, and 64 result rows
each. Remaining checks are **pending in this draft**:
[PENDING_Q_STRICT_FORMAT_RELEASE],''')
replace('docs/css-supports-variables.md','''[PENDING_Q_FINAL_SOURCE_BINDING_AND_EVIDENCE_LINKS]
[PENDING_Q_PUBLICATION_CI]
No candidate success count, GPU hardware result, new benchmark, Chromium-speed
comparison, whole-browser compatibility or security certification is claimed
by this draft.''','''[PENDING_Q_TESTED_INVENTORY_DOCUMENTATION_BINDING_AND_EVIDENCE_LINKS]
The final evidence distinguishes the tested inventory from later prose changes,
including `tests/conformance/supports.md`; no blanket final-tree equality is
claimed. [PENDING_Q_PUBLICATION_CI]
No GPU hardware result, new benchmark, Chromium-speed comparison, whole-browser
compatibility or security certification is claimed by this draft.''')
for path in ['tests/conformance/supports.md','docs/css-visibility.md','docs/css-pointer-events.md']:
 raw[path]=subprocess.check_output(['git','-C',GIT,'show',BASE+':'+path]).decode()
replace('tests/conformance/supports.md',"Values must consume the supported property's entire standalone value grammar.","Without a valid pending variable, values must consume the supported property's entire standalone value grammar. [Variables in feature queries](../../docs/css-supports-variables.md) adds valid legacy `var()` syntax for the implemented ordinary-name roster, deferring final property grammar without substitution.")
replace('tests/conformance/supports.md',"The helper uses the same conservative positive property/value inventory below. Both overloads intentionally decline custom-property declarations and `var()` values because arbitrary custom-property token-list substitution is not implemented faithfully; the existing renderer's bounded string substitution is a partial feature, not a positive claim for the full grammar.","The helper retains the conservative no-var inventory below. Both overloads now admit syntactically valid legacy `var()` values for the 88 implemented longhands, 29 shorthands and 13 aliases, independently of missing, invalid or cyclic computed custom-property values. Custom-property queries and newer variable-name argument grammar remain excluded; admitting a pending value is not a claim of complete substitution support.")
replace('tests/conformance/supports.md','## Positive declaration inventory\n\nProperty names are ASCII case-insensitive.', '## Legacy no-var declaration inventory\n\nThis table records the legacy ordinary-value subset, not the larger pending-variable name roster. Later property-specific validators can report additional supported values. Property names are ASCII case-insensitive.')
replace('tests/conformance/supports.md','Queries intentionally return false for other properties and values, including','The legacy no-var inventory intentionally returns false for other properties and values, including')
replace('tests/conformance/supports.md','custom-property declarations, `var()`, `calc()`,','custom-property declarations, `calc()`,')
replace('tests/conformance/supports.md','Escaped declaration identifiers/values return false because the current declaration application path does not decode them.', 'Generic escaped declaration identifiers/values still have false negatives in the no-var path; property-specific validators and the pending-variable condition path have their separately documented escape handling.')
replace('docs/css-visibility.md','''property-name rule and rejects escapes in that argument. The existing
conservative feature-query treatment of unresolved `var()` remains unchanged.''','''property-name rule and rejects escapes in that argument. The subsequent
[variable-query slice](css-supports-variables.md) admits valid legacy `var()`
syntax without substitution, superseding this checkpoint's earlier conservative
refusal. The validation results below retain their original checkpoint scope.''')
replace('docs/css-pointer-events.md','''keeps its literal-name rule. Queries containing unresolved `var()` retain Eris's
conservative false result. This is a capability-query limitation, not a claim
that variable references are invalid CSS; valid references defer property
validation under [CSS Variables](https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables).''','''keeps its literal-name rule. The subsequent [variable-query slice](css-supports-variables.md)
admits valid legacy `var()` syntax without substitution, superseding the earlier
conservative false result. Valid references defer final property validation under
[CSS Variables](https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables).
The validation results below retain their original pointer checkpoint scope.''')
entries=[]
for path,after in raw.items():
 before='' if path=='docs/css-supports-variables.md' else subprocess.check_output(['git','-C',GIT,'show',BASE+':'+path]).decode()
 write(H/'before'/path,before);write(H/'raw'/path,after)
 for d,old,new,fr,to in [('diffs/forward',before,after,'a/'+path if before else '/dev/null','b/'+path),('diffs/inverse',after,before,'b/'+path,'a/'+path if before else '/dev/null')]:
  write(H/d/(path+'.patch'),''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=fr,tofile=to)))
 entries.append({'path':path,'operation':'add' if not before else 'targeted edit','before':bind(H/'before'/path),'raw':bind(H/'raw'/path),'forward':bind(H/'diffs/forward'/(path+'.patch')),'inverse':bind(H/'diffs/inverse'/(path+'.patch'))})
# All revisions are invertible to draft1 or to the published source for the three added paths.
for path in raw:
 inv=raw[path]
 for change in reversed(changes):
  if change['path']==path:inv=once(inv,change['after'],change['before'])
 want=(PRE/'raw'/path).read_text() if (PRE/'raw'/path).exists() else (H/'before'/path).read_text()
 assert inv==want,path
before=(H/'before/docs/VALIDATION.md').read_text();after=raw['docs/VALIDATION.md'];anchor='## CSS pointer-events: auto and none\n';assert after[after.index(anchor):]==before[before.index(anchor):]
observed=[]
for label,total,suites in [('candidate-focused-msrv-1',20,63),('candidate-full-msrv-1',3597,64),('candidate-full-host-vulkan-1',3962,64)]:
 receipt=Q/'validation'/(label+'.json');log=Q/'validation'/(label+'.log');j=json.loads(receipt.read_text());assert j['exit']==0 and j['sha256']==bind(log)['sha256']
 rr=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text());assert len(rr)==suites and [sum(int(r[i]) for r in rr) for i in range(3)]==[total,0,0]
 assert '--include-ignored' in j['command'];observed.append({'label':label,'passed':total,'failed':0,'ignored':0,'result_rows':suites,'receipt':bind(receipt),'log':bind(log)})
js(H/'revision-chunks.json',changes)
js(H/'checks.json',{'base':BASE,'superseded_draft':bind(PRE/'draft-ready.json'),'file_count':8,'all_existing_before_files_exact_published_git':True,'revision_inverse_exact':True,'historical_validation_suffix_exact':True,'no_whitespace_normalization':True,'three_added_paths':['tests/conformance/supports.md','docs/css-visibility.md','docs/css-pointer-events.md'],'observed':observed,'test_time_prose_inventory_qualification':'tests/conformance/supports.md is an inventoried prose input. This held correction is a post-validation documentation-only delta; executable/test-code equality is distinct from whole final-tree equality. Root binds the separate documentation delta.','remaining_pending_markers':sorted(set(re.findall(r'PENDING_Q_[A-Z_]+','\n'.join(raw.values())))),'project_execution':False,'live_edits':False})
js(H/'draft-ready.json',{'schema':1,'status':'documentation-draft-awaiting-remaining-root-validation','author':'layout','base':BASE,'files':entries,'revision_chunks':bind(H/'revision-chunks.json'),'checks':bind(H/'checks.json'),'author_script':bind(H/'author.py'),'superseded_draft':bind(PRE/'draft-ready.json'),'file_count':8,'not_final_source_ready':True,'project_execution':False,'live_edits':False})
print(json.dumps(bind(H/'draft-ready.json')))
