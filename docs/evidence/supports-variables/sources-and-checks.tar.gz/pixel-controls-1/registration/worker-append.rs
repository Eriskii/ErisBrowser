
#[path = "worker/supports_var_pixels.rs"]
mod supports_var_pixels;
