from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

Q = Path('/tmp/eris-supports-var-plan-1')
H = Q / 'pixel-controls-1'
P = Path('/tmp/eris-pointer-events-plan-1')
BASE = '3d90bd578f2b17318e3e5831849e0aee526e68c4'

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(value if isinstance(value, bytes) else value.encode())

def json_write(path, value):
    write(path, json.dumps(value, indent=2) + '\n')

contract_path = Q / 'pixel-contract-1/contract.json'
assert binding(contract_path)['sha256'] == '43b6634594a2a3b167bc0d6862f0385db077d86dd2e43c3a2a401beac495b40d'
contract = json.loads(contract_path.read_text())
html_path = Path(contract['html']['path'])
assert binding(html_path) == contract['html']
assert contract['width'] == 8 and contract['height'] == 6 and len(contract['pixels']) == 48

oracle = '''//! Frozen whole-frame oracle; expectations do not inspect the display list.
pub const HTML: &str = include_str!("../fixtures/supports-var.html");
pub const WIDTH: u32 = 8;
pub const HEIGHT: u32 = 6;
pub const EXPECTED: [u32; 48] = [
    0x00ff00, 0x00ff00, 0xff0000, 0xff0000, 0xffff00, 0xffff00, 0x00ffff, 0x00ffff,
    0x00ff00, 0x00ff00, 0xff0000, 0xff0000, 0xffff00, 0xffff00, 0x00ffff, 0x00ffff,
    0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff,
    0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff,
    0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff,
    0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff, 0xff00ff,
];

pub fn assert_pixels(actual: &[u32]) {
    assert_eq!(actual.len(), EXPECTED.len());
    if let Some(i) = actual.iter().zip(EXPECTED).position(|(a, b)| *a != b) {
        panic!(
            "pixel ({},{}) actual={:06x} expected={:06x}",
            i % WIDTH as usize,
            i / WIDTH as usize,
            actual[i],
            EXPECTED[i]
        );
    }
}
'''
direct = '''use eris::{
    graphics::{Canvas, Color, Fonts},
    page::{Page, TaskState},
};
use url::Url;
#[path = "support/supports_var.rs"]
mod oracle;
#[cfg(feature = "raster-bridge")]
#[allow(dead_code)]
#[path = "support/vulkan_backgrounds.rs"]
mod witness;

#[test]
fn supports_var_condition_matches_literal_pixels_direct() {
    let fonts = Fonts::new();
    let page = Page::from_html(
        Url::parse("https://supports-var.invalid/").unwrap(),
        oracle::HTML,
        false,
    );
    let layout = page.layout(oracle::WIDTH as f32, oracle::HEIGHT as f32, &fonts);
    let mut canvas = Canvas::new(oracle::WIDTH, oracle::HEIGHT).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(&layout.commands, &fonts, &page.images, 0.0, 0.0);
    assert!(!canvas.exhausted());
    oracle::assert_pixels(&canvas.pixels);
    assert_eq!(page.task_state(), TaskState::Idle);
    assert!(page.diagnostics.is_empty(), "{:?}", page.diagnostics);
    #[cfg(feature = "raster-bridge")]
    {
        use eris::graphics::raster_bridge::native::{NativePhase, plan_native_scene};
        let frame = eris_raster_core::Frame::new(oracle::WIDTH, oracle::HEIGHT, 0xffffff);
        let scene = plan_native_scene(
            frame,
            &[NativePhase {
                frame,
                commands: &layout.commands,
            }],
            &page.images,
            &fonts,
        )
        .unwrap();
        oracle::assert_pixels(&witness::packed_pixels(scene.plan()));
    }
}
'''
worker = '''use super::*;
use eris::{
    graphics::{Canvas, Color, Fonts},
    page::TaskState,
};
#[path = "../support/supports_var.rs"]
mod oracle;
#[cfg(feature = "raster-bridge")]
use super::raster_witness as witness;

#[test]
#[ignore = "requires Linux Landlock ABI 6; launches a confined renderer and broker"]
fn confined_supports_var_condition_matches_literal_pixels() {
    const GENERATION: u64 = 743;
    let fixture = Fixture::new(oracle::HTML);
    let mut client = fixture.spawn(false, GENERATION);
    load(&mut client, &fixture.navigation);
    let reply = client
        .exchange(
            WorkerCommand::Render {
                width: oracle::WIDTH as f32,
                height: oracle::HEIGHT as f32,
            },
            || false,
        )
        .unwrap();
    assert!(reply.navigation.is_none());
    let snapshot = reply.snapshot.expect("render returns a snapshot");
    assert_eq!(snapshot.generation, GENERATION);
    assert_eq!(snapshot.processed_edit_sequence, 0);
    assert_eq!(snapshot.task_state, TaskState::Idle);
    for prefix in ["Page process ", "Resource broker "] {
        assert_eq!(
            snapshot
                .diagnostics
                .iter()
                .filter(|message| message.starts_with(prefix))
                .count(),
            1
        );
    }
    assert!(
        snapshot
            .diagnostics
            .iter()
            .all(|message| message.starts_with("Page process ")
                || message.starts_with("Resource broker ")),
        "{:?}",
        snapshot.diagnostics
    );
    let fonts = Fonts::new();
    let mut canvas = Canvas::new(oracle::WIDTH, oracle::HEIGHT).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(
        &snapshot.layout.commands,
        &fonts,
        &snapshot.images,
        0.0,
        0.0,
    );
    assert!(!canvas.exhausted());
    oracle::assert_pixels(&canvas.pixels);
    #[cfg(feature = "raster-bridge")]
    {
        use eris::graphics::raster_bridge::native::{NativePhase, plan_native_scene};
        let frame = eris_raster_core::Frame::new(oracle::WIDTH, oracle::HEIGHT, 0xffffff);
        let scene = plan_native_scene(
            frame,
            &[NativePhase {
                frame,
                commands: &snapshot.layout.commands,
            }],
            &snapshot.images,
            &fonts,
        )
        .unwrap();
        oracle::assert_pixels(&witness::packed_pixels(scene.plan()));
    }
}
'''
files = {
    'tests/fixtures/supports-var.html': html_path.read_bytes(),
    'tests/support/supports_var.rs': oracle.encode(),
    'tests/supports_var_pixels.rs': direct.encode(),
    'tests/worker/supports_var_pixels.rs': worker.encode(),
}
entries = []
for name, raw in files.items():
    # Git inspection only: prevent collision with an existing published path.
    result = subprocess.run(['git', '-C', str(P / 'worktree'), 'cat-file', '-e', BASE + ':' + name], capture_output=True)
    assert result.returncode != 0, name
    target = H / 'raw' / name
    write(target, raw)
    before = H / 'before' / name
    write(before, b'')
    forward = H / 'diffs/forward' / (name + '.patch')
    inverse = H / 'diffs/inverse' / (name + '.patch')
    write(forward, ''.join(difflib.unified_diff([], raw.decode().splitlines(True), fromfile='/dev/null', tofile='b/' + name)))
    write(inverse, ''.join(difflib.unified_diff(raw.decode().splitlines(True), [], fromfile='a/' + name, tofile='/dev/null')))
    entries.append({'path': name, 'operation': 'add', 'before_absent_at_published_base': True, 'before': binding(before), 'raw': binding(target), 'forward': binding(forward), 'inverse': binding(inverse)})

registration = '\n#[path = "worker/supports_var_pixels.rs"]\nmod supports_var_pixels;\n'
write(H / 'registration/worker-append.rs', registration)
worker_before = P / 'candidate-source-2/tests/worker.rs'
assert 'mod supports_var_pixels;' not in worker_before.read_text()
json_write(H / 'registration.json', {'path': 'tests/worker.rs', 'operation': 'append', 'fragment': binding(H / 'registration/worker-append.rs'), 'existing_api_reference': binding(worker_before), 'precondition': 'No existing supports_var_pixels module. Retain all existing module registrations and source bytes; append this fragment only.', 'not_full_replacement': True})

apis = []
for name in ['tests/worker.rs', 'tests/pointer_events_dynamic.rs', 'tests/worker/pointer_events_dynamic.rs']:
    source = P / 'candidate-source-2' / name
    target = H / 'api-source' / name
    write(target, source.read_bytes())
    apis.append({'path': name, 'origin': binding(source), 'retained': binding(target)})
name = 'tests/support/vulkan_backgrounds.rs'
source = subprocess.check_output(['git', '-C', str(P / 'worktree'), 'show', BASE + ':' + name])
target = H / 'api-source' / name
write(target, source)
apis.append({'path': name, 'base': BASE, 'git_blob': BASE + ':' + name, 'retained': binding(target)})

pixels = [int(v, 16) for v in re.findall(r'0x[0-9a-f]+', oracle.split('];', 1)[0])]
assert pixels == contract['pixels']
assert files['tests/fixtures/supports-var.html'] == html_path.read_bytes()
assert direct.count('page.layout(') == 1
assert worker.count('WorkerCommand::Render') == 1
assert 'fixture.spawn(false, GENERATION)' in worker
assert direct.count('#[test]') == worker.count('#[test]') == 1
json_write(H / 'checks.json', {
    'contract': binding(contract_path),
    'html_byte_exact': True,
    'expected_pixel_count': 48,
    'pixel_literals_equal_frozen_decimal_array': True,
    'frame': [8, 6],
    'groups': ['supports_var_condition_matches_literal_pixels_direct', 'supports_var_pixels::confined_supports_var_condition_matches_literal_pixels'],
    'frames_per_group': 1,
    'script_policy': False,
    'worker_generation': 743,
    'worker_edit_sequence': 0,
    'worker_task_state': 'Idle',
    'worker_diagnostics': 'Exactly one Page process prefix and one Resource broker prefix; no other messages.',
    'native_witness': 'Conditional raster-bridge CPU packed-plan reconstruction compared to the same exact 48 pixels; no GPU execution or hardware claim.',
    'registration': binding(H / 'registration.json'),
    'independence': 'Frozen HTML and pixel constants predate this adapter. No Q producer inspected; only existing P test API source and published native witness were read. No expected value was selected from an execution.',
    'execution': False,
    'live_edits': False,
})
json_write(H / 'source-ready.json', {
    'schema': 1,
    'status': 'source-ready',
    'author': 'layout',
    'scope': 'Direct and confined-worker pixel controls for pending var() supports conditions, using only existing APIs.',
    'published_api_base': BASE,
    'pending_base_refresh': 'Root will bind the published P checkpoint before Q import; the selected existing APIs are separately hash-bound.',
    'contract': binding(contract_path),
    'html': binding(html_path),
    'files': entries,
    'registration': binding(H / 'registration.json'),
    'checks': binding(H / 'checks.json'),
    'api_sources': apis,
    'author_script': binding(H / 'author.py'),
    'group_count': 2,
    'direct_groups': 1,
    'confined_ignored_groups': 1,
    'project_execution': False,
    'project_imports': False,
    'producer_reads': False,
    'live_edits': False,
})
print(json.dumps(binding(H / 'source-ready.json')))
