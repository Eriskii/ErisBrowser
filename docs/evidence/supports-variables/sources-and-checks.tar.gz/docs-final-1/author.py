from pathlib import Path
from collections import Counter
import json, hashlib, difflib, re, subprocess
Q=Path('/tmp/eris-supports-var-plan-1');H=Q/'docs-final-1';D=Q/'docs-draft-2';P=Path('/tmp/eris-pointer-events-plan-1');BASE='339b257f3e9e5ac45ab1bd85d00e1a4be36b307f'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_bytes(v if isinstance(v,bytes) else v.encode())
def js(p,v):write(p,json.dumps(v,indent=2)+'\n')
def once(text,old,new):
 assert text.count(old)==1,old;return text.replace(old,new,1)
def verify(v):
 assert bind(Path(v['path']))=={k:v[k] for k in ['path','bytes','sha256']},v['path']
ledger=Q/'root/final-validation.json';assert bind(ledger)['sha256']=='dbddb59301e6826989aee8724987cc4bd2f80c6c7c1c5d2724cce6d0ab26c20e';L=json.loads(ledger.read_text());assert L['status']=='pass'
raw={e['path']:(D/'raw'/e['path']).read_text() for e in json.loads((D/'draft-ready.json').read_text())['files']};revisions=[]
def change(path,old,new):
 raw[path]=once(raw[path],old,new);revisions.append({'path':path,'before':old,'after':new})
change('README.md','''[Variables in CSS feature queries](docs/css-supports-variables.md) admits
syntactically valid legacy `var()` values for the existing implemented property
names. Queries defer final value grammar without resolving custom properties;''','''[Variables in CSS feature queries](docs/css-supports-variables.md) are now recognized
through the existing legacy `var()` grammar for implemented property names.
Queries defer final value grammar without resolving custom properties;''')
change('docs/ROADMAP.md','''[Variables in CSS feature queries](css-supports-variables.md) separates''','''The [variable-query slice](css-supports-variables.md) separates''')
change('docs/ROADMAP.md','''grammar and remaining no-var reporting gaps still need separate work. Earlier
pointer/visibility records retain their original query limitations and results;
this slice adds no GPU, Chromium-speed or security result.''','''grammar and remaining no-var reporting gaps still need separate work. Earlier
[validation entries](VALIDATION.md) retain their original query limitations and
results; this slice adds no GPU, Chromium-speed or security result.''')
change('docs/css-supports-variables.md','''that value. Earlier pointer and visibility chapters record their original
conservative variable-query behavior; this chapter supersedes that boundary.''','''that value. Earlier [validation entries](VALIDATION.md) retain the original
conservative variable-query behavior; the current pointer and visibility
chapters link to this subsequent improvement.''')
old_tail='''The frozen contracts define 20 test groups. On the published P parent, one of
the 14 public groups passes and 13 fail. The focused candidate run passes all 20 groups. Full Rust 1.88 default and
Rust 1.99 `test262-host,vulkan-raster` runs pass 3,597 and 3,962 tests respectively,
with ignored tests included, zero failures or ignored tests, and 64 result rows
each. Remaining checks are **pending in this draft**:
[PENDING_Q_STRICT_FORMAT_RELEASE],
[PENDING_Q_VISUAL_RESULTS_AND_IMAGE_CHANGES] and
[PENDING_Q_FAILURE_CORRECTIONS]. The tests distinguish declaration/query forms,
coercion order, computed-value independence, exact budget cuts and whole-frame
pixels. A URL fallback admission row is not instrumentation proving that no
network request occurred. The direct and confined pixel controls share literal
expectations; their optional native-scene witness runs on the CPU.

[PENDING_Q_TESTED_INVENTORY_DOCUMENTATION_BINDING_AND_EVIDENCE_LINKS]
The final evidence distinguishes the tested inventory from later prose changes,
including `tests/conformance/supports.md`; no blanket final-tree equality is
claimed. [PENDING_Q_PUBLICATION_CI]
No GPU hardware result, new benchmark, Chromium-speed comparison, whole-browser
compatibility or security certification is claimed by this draft.
'''
new_tail='''The frozen contracts define 20 test groups. On the published `339b257f` parent,
one of the 14 public groups passes and 13 fail; those observations are retained.
The first candidate passes all 20 focused groups. Full Rust 1.88 default and
Rust 1.99 `test262-host,vulkan-raster` runs pass 3,597 and 3,962 tests respectively,
with ignored tests included, zero failures or ignored tests, and 64 result rows
each. Both preserve the prior passing rosters and add exactly 20 groups. Strict
Clippy passes in both configurations; formatting and release compilation pass.
All 102 existing visual-reference pairs pass, and their 204 PNGs are byte-identical
to the preceding pointer-events checkpoint.

Candidate code, tests and expected outputs needed no correction. A summary
helper initially missed test names with intervening ignored-test attributes;
its census expression was corrected without changing the tests, expectations
or execution commands. The original helper and correction record are retained.
The controls distinguish declaration/query forms, coercion order,
computed-value independence, exact budget cuts and whole-frame pixels. A URL
fallback admission row is not instrumentation proving that no network request
occurred. The direct and confined pixel controls share literal expectations;
their optional native-scene witness reconstructs packed plans on the CPU.

The tested inventory contains 15,328 selected inputs and 11 changed source
paths. The final evidence separately binds the later documentation-only
`tests/conformance/supports.md` update, because that prose path was included in
the tested inventory. Executable and test-code inputs stay as tested; whole-tree
byte equality after documentation updates is not claimed. See the
[validation manifest](evidence/supports-variables/validation.json) and
[source/check archive](evidence/supports-variables/sources-and-checks.tar.gz).
The preceding `339b257f` commit passed all 11 GitHub CI jobs. CI for this
checkpoint is pending at publication.

No GPU hardware result, new benchmark, Chromium-speed comparison, whole-browser
compatibility or security certification is claimed.
'''
change('docs/css-supports-variables.md',old_tail,new_tail)
change('docs/VALIDATION.md','''and report zero failures or ignored tests across 64 result rows each.

**Pending final validation:** [PENDING_Q_STRICT_FORMAT_RELEASE],
[PENDING_Q_VISUAL_RESULTS_AND_IMAGE_CHANGES], [PENDING_Q_FAILURE_CORRECTIONS],
and [PENDING_Q_PUBLICATION_CI]. Root will replace these markers only with retained
execution receipts. No unobserved check is inferred from the completed runs.''','''and report zero failures or ignored tests across 64 result rows each. Both
preserve the prior passing rosters and add exactly 20 groups. Strict Clippy
passes in both configurations; formatting and release compilation pass. All
102 existing visual-reference pairs pass, and their 204 PNGs are byte-identical
to the preceding pointer-events checkpoint.

The first candidate needed no code, test or expected-output correction. The
summary helper initially missed test names with intervening ignored-test
attributes; only its census expression changed. The original helper and
correction record are retained, with no change to execution commands. The
preceding `339b257f` commit passed all 11 GitHub CI jobs. CI for this checkpoint
is pending at publication.''')
change('docs/VALIDATION.md','''[PENDING_Q_FINAL_SOURCE_BINDING: bind the tested inventory and separate final
documentation delta.] The later `tests/conformance/supports.md` update changes
prose in a path included by that inventory; the final published tree therefore
need not match every tested inventory row. Executable and test-code inputs stay
as tested, and the documentation-only difference is bound separately.''','''The later `tests/conformance/supports.md` update changes prose in a path included
by that inventory. Its exact before/after bindings and diff are recorded as a
post-validation documentation-only update. Executable and test-code inputs stay
as tested; final whole-tree equality to every tested inventory row is not
claimed.''')
change('docs/VALIDATION.md','''[PENDING_Q_EVIDENCE_LINKS: bind the final validation manifest and retained source
and check archive after root selects the publication paths.]
These are authored regression controls''','''See the [validation manifest](evidence/supports-variables/validation.json) and
[source/check archive](evidence/supports-variables/sources-and-checks.tar.gz).
These are authored regression controls''')
assert not any('PENDING_Q_' in text for text in raw.values())
entries=[]
for path,after in raw.items():
 before=(D/'before'/path).read_text()
 if before:
  assert subprocess.check_output(['git','-C',str(P/'worktree'),'show',BASE+':'+path])==before.encode()
 write(H/'before'/path,before);write(H/'raw'/path,after)
 for directory,old,new,src,dst in [('diffs/forward',before,after,'a/'+path if before else '/dev/null','b/'+path),('diffs/inverse',after,before,'b/'+path,'a/'+path if before else '/dev/null')]:
  write(H/directory/(path+'.patch'),''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=src,tofile=dst)))
 entries.append({'path':path,'operation':'targeted edit' if before else 'add','before':bind(H/'before'/path),'raw':bind(H/'raw'/path),'forward':bind(H/'diffs/forward'/(path+'.patch')),'inverse':bind(H/'diffs/inverse'/(path+'.patch'))})
 # Final prose changes invert to the selected immutable draft.
 prior=after
 for r in reversed(revisions):
  if r['path']==path:prior=once(prior,r['after'],r['before'])
 assert prior==(D/'raw'/path).read_text()
anchor='## CSS pointer-events: auto and none\n';old=(H/'before/docs/VALIDATION.md').read_text();new=raw['docs/VALIDATION.md'];assert new[new.index(anchor):]==old[old.index(anchor):]
# Recount retained observations without running project code.
attempts=[];logs={}
for a in L['attempts']:
 verify(a['receipt']);verify(a['log']);text=Path(a['log']['path']).read_text();logs[a['label']]=text
 rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)
 total={'passed':sum(int(r[0]) for r in rows),'failed':sum(int(r[1]) for r in rows),'ignored':sum(int(r[2]) for r in rows),'suites':len(rows)};assert total==a['totals']
 attempts.append({'label':a['label'],'exit':a['exit'],'totals':total})
assert all(a['exit']==0 for a in L['attempts'] if a['label'].startswith('candidate-'))
assert len(L['new_test_names'])==20
prior=json.loads((P/'root/final-validation.json').read_text())
for label in ['candidate-full-msrv-1','candidate-full-host-vulkan-1']:
 a=next(a for a in prior['attempts'] if a['label']==label);verify(a['log'])
 old=Counter(re.findall(r'^test (.+) \.\.\. ok$',Path(a['log']['path']).read_text(),re.M));new=Counter(re.findall(r'^test (.+) \.\.\. ok$',logs[label],re.M));assert not old-new and new-old==Counter(L['new_test_names'])
verify(L['reftest_report']);ref=json.loads(Path(L['reftest_report']['path']).read_text());assert ref['passed']==ref['total']==len(ref['cases'])==102 and ref['failed']==0
assert all(c['status']=='pass' and c['different_pixels']==c['maximum_channel_error']==0 for c in ref['cases'])
assert len(L['images'])==204
for im in L['images']:
 verify(im['parent']);verify(im['candidate']);assert im['parent']['sha256']==im['candidate']['sha256'] and im['parent']['bytes']==im['candidate']['bytes']
ci=P/'publication/ci-observation-4.json';assert bind(ci)['sha256']=='6fc8c30b123375295c8b9d4e773cc22d95668077082404fbfcfc67392a87fce9';c=json.loads(ci.read_text());assert c['headSha']==BASE and c['conclusion']=='success' and len(c['jobs'])==11 and all(j['conclusion']=='success' for j in c['jobs'])
verify(L['source_inventory']);inventory=json.loads(Path(L['source_inventory']['path']).read_text());assert len(inventory['files'])==L['inputs']==15328 and len(L['changed_sources'])==11
row=next(e for e in inventory['files'] if e['path']=='tests/conformance/supports.md');before=bind(H/'before/tests/conformance/supports.md');assert all(row[k]==before[k] for k in ['bytes','sha256'])
prose=next(e for e in entries if e['path']=='tests/conformance/supports.md')
js(H/'documentation-only-binding.json',{'kind':'post-validation documentation-only delta for an inventoried prose path','tested_inventory':L['source_inventory'],'tested_entry':row,'published_base':BASE,'before':prose['before'],'after':prose['raw'],'forward':prose['forward'],'inverse':prose['inverse'],'qualification':'This changes prose after validation. The tested inventory hash remains the identity of executed source/test inputs. Final whole-tree byte equality to it is not asserted; root composes the separately bound documentation payload. No Rust or test-code update accompanies this delta.'})
js(H/'revision-chunks.json',revisions)
js(H/'manifest.json',[{'path':e['path'],'bytes':e['raw']['bytes'],'sha256':e['raw']['sha256']} for e in entries])
js(H/'checks.json',{'status':'completed source/evidence authoring checks','final_validation':bind(ledger),'immutable_draft':bind(D/'draft-ready.json'),'no_pending_markers':True,'published_before_joins':7,'new_chapter':True,'historical_validation_suffix_exact':True,'revision_inverse_to_draft2_exact':True,'unrelated_text_and_whitespace_preserved':True,'all_raw_attempt_totals':attempts,'prior_full_rosters_exact_plus20':True,'reftest_pairs':102,'parent_identical_pngs_verified':204,'summary_parser_correction':bind(Q/'root/summary-parser-correction-1.json'),'parent_ci':bind(ci),'documentation_only_delta':bind(H/'documentation-only-binding.json'),'limits_and_scope':'Legacy var grammar, 88+29+13 names, no substitution/custom-query/newdraft grammar, unchanged no-var gaps and caps; CPU witnesses are not GPU hardware or performance/security evidence.','project_execution':False,'live_edits':False})
js(H/'source-ready.json',{'schema':1,'status':'source-ready','author':'layout','base':BASE,'final_validation':bind(ledger),'selected_draft':bind(D/'draft-ready.json'),'files':entries,'manifest':bind(H/'manifest.json'),'revision_chunks':bind(H/'revision-chunks.json'),'checks':bind(H/'checks.json'),'documentation_only_delta':bind(H/'documentation-only-binding.json'),'author_script':bind(H/'author.py'),'file_count':8,'project_execution':False,'producer_reads':False,'live_edits':False})
print(json.dumps(bind(H/'source-ready.json')))
print(json.dumps(bind(H/'manifest.json')))
