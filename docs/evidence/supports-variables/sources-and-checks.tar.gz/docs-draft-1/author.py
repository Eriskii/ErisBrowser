from pathlib import Path
import json,hashlib,difflib,subprocess,re
Q=Path('/tmp/eris-supports-var-plan-1');H=Q/'docs-draft-1';BASE='339b257f3e9e5ac45ab1bd85d00e1a4be36b307f';GIT='/tmp/eris-pointer-events-plan-1/worktree'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists(),p;p.write_bytes(b if isinstance(b,bytes) else b.encode())
def js(p,j):write(p,json.dumps(j,indent=2)+'\n')
readme='''[Variables in CSS feature queries](docs/css-supports-variables.md) admits
syntactically valid legacy `var()` values for the existing implemented property
names. Queries defer final value grammar without resolving custom properties;
missing or cyclic values therefore do not decide support. Custom-property
queries and broader substitution grammar remain outside this slice.

'''
compat='''[Variables in CSS feature queries](css-supports-variables.md) covers the
existing 88 longhands, 29 shorthands and 13 aliases. Valid legacy `var()` syntax
can report support before substitution, including otherwise unrecognized final
value grammar. Unknown names, custom-property queries and newer variable-name
argument syntax remain excluded. Existing no-var false negatives are retained;
this is a bounded feature-query correction, not complete CSS conformance.

'''
old_policy='''Feature queries retain the
existing conservative refusal of unresolved `var()`; that refusal is an
implementation boundary, not invalid variable syntax under the CSS standard.'''
new_policy='''The variable-query slice supersedes
this checkpoint's earlier conservative refusal of unresolved `var()`. The
pointer-targeting chapter retains its original validation and scope record.'''
roadmap='''[Variables in CSS feature queries](css-supports-variables.md) separates
pending value syntax from computed substitution. The selected ordinary-name
roster admits valid legacy `var()` values while preserving shared resource
limits and the no-var paths. Custom-property support queries, newer argument
grammar and remaining no-var reporting gaps still need separate work. Earlier
pointer/visibility records retain their original query limitations and results;
this slice adds no GPU, Chromium-speed or security result.

'''
validation='''## Variables in CSS feature queries

This slice admits valid legacy `var()` syntax for 88 implemented longhands,
29 shorthands and 13 aliases in `@supports` and `CSS.supports()`. Query validation
defers final property grammar without substituting custom properties. Literal
two-argument names, decoded condition names, trailing condition priority and
ordinary-declaration curly-block structure remain distinct. Unknown/custom
property queries and newer variable-name argument grammar remain outside scope.

The published `339b257f` parent was run against the 14 public groups: one passed
and 13 failed. Those raw failures are retained. The independent contracts define
20 new groups: 12 semantic, two direct/confined pixel and six private budget
groups. This is the authored roster, not an observed candidate pass count.

**Pending final validation:** [PENDING_Q_FOCUSED_RESULTS],
[PENDING_Q_FULL_RUST_ROSTERS], [PENDING_Q_STRICT_FORMAT_RELEASE],
[PENDING_Q_VISUAL_RESULTS_AND_IMAGE_CHANGES], [PENDING_Q_FAILURE_CORRECTIONS],
and [PENDING_Q_PUBLICATION_CI]. Root will replace these markers only with retained
execution receipts. No final outcome is inferred from the parent run.

Candidate1 currently binds 15,328 selected source/build/test inputs and 11 changed
source paths. Its inventory SHA-256 is
`bfd1b08f17ca8d5cdf89ceee4a9cdbe81ceda37fe16e9913eb523980127dd4c2`.
[PENDING_Q_FINAL_SOURCE_BINDING: confirm this inventory or identify the selected
successor; retain Candidate1 if superseded.]

The public semantic adapter contains 369 CSS Boolean assertions if all rows
complete, six strict/sloppy Runtime attempts and one CPU pixel frame. The two
additional direct/confined groups use the same 48 literal pixels at 8 by 6;
conditional native-scene checks reconstruct packed plans on the CPU. Six private
groups freeze 30 API invocations, including exact shared-work cuts, typed
Invalid/Limit results and the unchanged 227-unit no-var keyword cut. These are
source-level coverage counts until the corresponding tests complete.

The raw pending-value bound remains 4,096 bytes. Its local oversize refusal is
ordinary false and can be negated; resource exhaustion during token, work or
depth processing aborts the whole query instead. Existing Option syntax callers
and computed substitution keep their previous behavior. No limits are raised.

[PENDING_Q_EVIDENCE_LINKS: bind the final validation manifest and retained source
and check archive after root selects the publication paths.]
These are authored regression controls, not a complete WPT or web-platform
conformance inventory. No new GPU hardware execution, benchmark, Chromium
comparison or security-audit result is claimed. The earlier validation text
below is preserved byte for byte, including the pointer checkpoint's former
conservative `supports(var())` limitation.

'''
chapter='''# Variables in CSS feature queries

`@supports` and `CSS.supports()` admit syntactically valid legacy `var()` values
for the existing implemented ordinary property names. The selected roster has
88 longhands, 29 shorthands and 13 aliases. A query can report support for
`width:var(--missing)` without finding a custom-property value. The final value
is checked after substitution when a declaration is computed; a feature query
does not perform that substitution. This follows the parse-time rule in
[CSS Variables Level 1](https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables)
and the declaration-support model in
[CSS Conditional Rules Level 3](https://www.w3.org/TR/2024/CRD-css-conditional-3-20240815/#support-definition).

The validator recognizes real, case-insensitive function tokens, including
escaped names and nested functions. Text inside a string or comment does not
create a variable reference. It checks the complete existing variable grammar:
the first argument is a literal custom-property name, and every fallback must
be structurally valid. Empty fallbacks and nested fallback blocks are allowed;
an invalid nested reference is still invalid. Valid pending values can contain
final grammar the renderer does not understand, such as
`calc(var(--x) + )` or `var(--x,visiblePainted)`. Accepting their pending syntax
does not implement those final values.

The two-argument form keeps property names literal. For example,
`CSS.supports('w\\\\69 dth','var(--x)')` is false, while the escaped name in
`CSS.supports('(w\\\\69 dth:var(--x))')` is decoded as CSS syntax. These JavaScript
examples contain two source backslashes to pass one CSS backslash. The
one-argument Runtime form also accepts an implied declaration without outer
parentheses. A trailing `!important` is accepted in a declaration-form condition
and rejected as part of the separate value argument. Runtime argument conversion
remains left to right, including conversion of a value for an unknown property;
additional arguments do not acquire extra API conversions. Ordinary thrown
values retain their identity.

The query's ordinary-declaration structure follows
[CSS Syntax Level 3, consume a declaration](https://www.w3.org/TR/2026/CRD-css-syntax-3-20261001/#consume-a-declaration).
A sole top-level curly block such as `{var(--x)}` is allowed. Mixing that block
with another non-whitespace component, as in `{} var(--x)`, is refused. A block
nested inside a fallback, such as `var(--x,{foo:bar;})`, remains allowed. This is
a query-only structural check; existing declaration substitution is unchanged.

Pending-value parsing exposes invalid syntax separately from exhausted resources.
The existing Option-returning syntax callers still map either failure to `None`.
The supports evaluator uses the shared work allowance: resource exhaustion
cannot turn into success through `not` or an earlier true `or` branch. This does
not make every local cap non-negatable. The 4,096-byte raw pending-value guard
returns ordinary false, as do the retained local syntax/name refusals; a
condition may negate such a result. The 256-byte variable-name grammar boundary
and 1,024-byte identifier-decoder resource boundary remain distinct. Existing
work, token, depth and outer-query caps are not raised. A private CSS check can
finish at exactly zero allowance; the Runtime's existing zero-author-step rule
still raises a resource error.

Unknown ordinary properties and custom-property support queries remain excluded,
even though custom-property declarations themselves work. The newer draft's
broader first-argument substitution grammar, `attr()`/`env()` feature admission
and registration are outside this checkpoint. Existing no-var answers stay
unchanged, including false negatives for some implemented values and escaped
ordinary condition names. A false no-var query such as `font-size:12px` remains
a reporting limitation rather than evidence that the browser cannot lay out
that value. Earlier pointer and visibility chapters record their original
conservative variable-query behavior; this chapter supersedes that boundary.

The frozen contracts define 20 test groups. On the published P parent, one of
the 14 public groups passes and 13 fail. Candidate execution and final checks
remain **pending in this draft**: [PENDING_Q_FOCUSED_RESULTS],
[PENDING_Q_FULL_RUST_ROSTERS], [PENDING_Q_STRICT_FORMAT_RELEASE],
[PENDING_Q_VISUAL_RESULTS_AND_IMAGE_CHANGES] and
[PENDING_Q_FAILURE_CORRECTIONS]. The tests distinguish declaration/query forms,
coercion order, computed-value independence, exact budget cuts and whole-frame
pixels. A URL fallback admission row is not instrumentation proving that no
network request occurred. The direct and confined pixel controls share literal
expectations; their optional native-scene witness runs on the CPU.

[PENDING_Q_FINAL_SOURCE_BINDING_AND_EVIDENCE_LINKS]
[PENDING_Q_PUBLICATION_CI]
No candidate success count, GPU hardware result, new benchmark, Chromium-speed
comparison, whole-browser compatibility or security certification is claimed
by this draft.
'''
changes={
 'README.md':[('[CSS pointer targeting](docs/css-pointer-events.md)',readme+'[CSS pointer targeting](docs/css-pointer-events.md)')],
 'docs/COMPATIBILITY.md':[('# Compatibility status\n\n','# Compatibility status\n\n'+compat),(old_policy,new_policy)],
 'docs/ROADMAP.md':[('# Development docket\n\n','# Development docket\n\n'+roadmap)],
 'docs/VALIDATION.md':[('# Validation record\n\n','# Validation record\n\n'+validation)],
}
entries=[];chunks=[]
for path,edits in changes.items():
 before=subprocess.check_output(['git','-C',GIT,'show',BASE+':'+path]).decode();after=before
 for old,new in edits:
  assert after.count(old)==1,(path,old);after=after.replace(old,new,1);chunks.append({'path':path,'before':old,'after':new})
 inverse=after
 for old,new in reversed(edits):assert inverse.count(new)==1;inverse=inverse.replace(new,old,1)
 assert inverse==before
 write(H/'before'/path,before);write(H/'raw'/path,after)
 for d,src,dst,old,new in [('diffs/forward','a','b',before,after),('diffs/inverse','b','a',after,before)]:
  write(H/d/(path+'.patch'),''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=src+'/'+path,tofile=dst+'/'+path)))
 entries.append({'path':path,'operation':'targeted edit','before':bind(H/'before'/path),'raw':bind(H/'raw'/path),'forward':bind(H/'diffs/forward'/(path+'.patch')),'inverse':bind(H/'diffs/inverse'/(path+'.patch'))})
path='docs/css-supports-variables.md';assert subprocess.run(['git','-C',GIT,'cat-file','-e',BASE+':'+path],capture_output=True).returncode!=0
write(H/'before'/path,b'');write(H/'raw'/path,chapter)
for d,old,new,src,dst in [('diffs/forward','',chapter,'/dev/null','b/'+path),('diffs/inverse',chapter,'','a/'+path,'/dev/null')]:
 write(H/d/(path+'.patch'),''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=src,tofile=dst)))
entries.append({'path':path,'operation':'add','before_absent_at_base':True,'before':bind(H/'before'/path),'raw':bind(H/'raw'/path),'forward':bind(H/'diffs/forward'/(path+'.patch')),'inverse':bind(H/'diffs/inverse'/(path+'.patch'))})
old=(H/'before/docs/VALIDATION.md').read_text();new=(H/'raw/docs/VALIDATION.md').read_text();assert new.replace(validation,'',1)==old
parent=json.loads((Q/'validation/parent-controls-1.json').read_text());log=(Q/'validation/parent-controls-1.log').read_bytes();assert hashlib.sha256(log).hexdigest()==parent['sha256']
rows=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.decode());assert [sum(int(r[i]) for r in rows) for i in range(3)]==[1,13,0]
inv=bind(Q/'source-candidate-1.json');assert inv['sha256']=='bfd1b08f17ca8d5cdf89ceee4a9cdbe81ceda37fe16e9913eb523980127dd4c2';assert len(json.loads((Q/'source-candidate-1.json').read_text())['files'])==15328
js(H/'chunks.json',chunks)
checks={'base':BASE,'all_four_before_files_match_published_git':True,'exact_inverse_for_every_targeted_change':True,'entire_historical_validation_preserved':True,'no_blanket_whitespace_normalization':True,'only_existing_current_prose_replacement':'COMPATIBILITY pointer paragraph: former blanket var-query refusal becomes a historical pointer-checkpoint qualification. Other historical chapters remain untouched.','parent_public':{'passed':1,'failed':13,'groups':14,'receipt':bind(Q/'validation/parent-controls-1.json'),'log':bind(Q/'validation/parent-controls-1.log')},'candidate1':inv,'candidate_claim_status':'15,328 inputs and root-reported 11 changed source paths identify current Candidate1 only; selected final inventory remains pending.','authored_roster':{'semantic':12,'direct_confined_pixels':2,'private_budget':6,'total':20,'observed_candidate_total':None},'pending_markers':sorted(set(re.findall(r'PENDING_Q_[A-Z_]+',chapter+validation))),'execution_qualification':'Only read-only Git and Python standard-library authoring/checks. No project imports, producer reads, live edits or project execution.'}
js(H/'checks.json',checks)
js(H/'draft-ready.json',{'schema':1,'status':'documentation-draft-awaiting-root-final-validation','author':'layout','base':BASE,'files':entries,'chunks':bind(H/'chunks.json'),'checks':bind(H/'checks.json'),'author_script':bind(H/'author.py'),'inputs':[bind(Q/'design-1.json'),bind(Q/'design-curly-addendum-1.json'),bind(Q/'semantic-controls-review-1.json'),bind(Q/'budget-controls-1/source-ready.json'),bind(Q/'pixel-controls-1/source-ready.json')],'file_count':5,'not_final_source_ready':True,'live_edits':False,'project_execution':False})
print(json.dumps(bind(H/'draft-ready.json')))
