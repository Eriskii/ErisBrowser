from pathlib import Path
import json,hashlib,re,subprocess
Q=Path('/tmp/eris-supports-var-plan-1');P=Path('/tmp/eris-pointer-events-plan-1');W=P/'worktree';H=Q/'implementation-1';base='339b257f3e9e5ac45ab1bd85d00e1a4be36b307f'
assert not (H/'source-ready.json').exists()
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(rel,b):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b.encode() if isinstance(b,str) else b);return bind(p)
def jp(rel,obj):return put(rel,json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
files=json.loads((H/'files.json').read_text());edits=json.loads((H/'edits.json').read_text());before={r['path']:Path(r['before']['path']).read_text() for r in files};raw={r['path']:Path(r['raw']['path']).read_text() for r in files}
inv=json.loads((P/'source-candidate-2.json').read_text());entries={x['path']:x for x in inv['files']}
for row in files:
 for field in ['before','raw','forward','inverse']:assert bind(Path(row[field]['path']))==row[field]
 path=row['path'];assert entries[path]['sha256']==sha(before[path].encode())
 published=subprocess.check_output(['git','show',f'{base}:{path}'],cwd='/home/eriskii/Documents/Programming/Projects/ErisBrowser');assert published==before[path].encode()
roster=re.findall(r'"([^"]+)"',re.search(r'const SUPPORTED_PROPERTIES: &\[&str\] = &\[(.*?)\n\];',before['src/css.rs'],re.S).group(1));assert len(roster)==len(set(roster))==88
alias_old=re.search(r'fn alias\(name: &str\) -> &str \{.*?\n\}',before['src/cssom.rs'],re.S).group(0)
alias_new=re.search(r'pub\(crate\) fn property_alias\(name: &str\) -> &str \{.*?\n\}',raw['src/css.rs'],re.S).group(0)
assert alias_new.replace('pub(crate) fn property_alias','fn alias',1)==alias_old
aliases=re.findall(r'"([^"]+)" => "([^"]+)"',alias_old);assert len(aliases)==13
short_body=before['src/css.rs'].split('pub(crate) fn shorthand_property_count(',1)[1].split('pub(crate) fn shorthand_properties(',1)[0]
shorts=re.findall(r'"([^"]+)"',short_body);assert len(shorts)==len(set(shorts))==29
old_var_calls=[line.strip() for line in before['src/css.rs'].splitlines() if 'VariableSyntax::parse(' in line]
new_var_calls=[line.strip() for line in raw['src/css.rs'].splitlines() if 'VariableSyntax::parse(' in line]
assert old_var_calls==new_var_calls
for path in before:
 assert re.findall(r'#\[test\]\s*fn\s+(\w+)',before[path])==re.findall(r'#\[test\]\s*fn\s+(\w+)',raw[path])
rec=raw.copy()
for e in reversed(edits):
 if e['new']:assert rec[e['path']].count(e['new'])==1;rec[e['path']]=rec[e['path']].replace(e['new'],e['old'],1)
 else:rec[e['path']]=rec[e['path']].replace('fn name(name: &str)',e['old']+'fn name(name: &str)',1)
assert rec==before
bindings=[]
for path in ['src/selectors.rs','src/script.rs','src/css/visibility_budget_tests.rs','src/css/pointer_events_budget_tests.rs','src/cssom/pending_record_accounting_tests.rs']:
 p=W/path;b=p.read_bytes();assert sha(b)==entries[path]['sha256'];bindings.append({**bind(p),'candidate_entry':entries[path]})
receipt={'schema':1,'published_commit':base,'origin':bind(P/'source-candidate-2.json'),'production_before_git_exact':[{**row['before'],'git_path':row['path']} for row in files],'historical_before_git_exact':[],'prior_holds_unchanged':True}
for r in json.loads((Q/'migrations-1/source-ready.json').read_text())['files']:
 b=subprocess.check_output(['git','show',f'{base}:{r["path"]}'],cwd='/home/eriskii/Documents/Programming/Projects/ErisBrowser');assert b==Path(r['before']['path']).read_bytes();receipt['historical_before_git_exact'].append({'path':r['path'],'sha256':sha(b)})
refresh=Q/'published-base-refresh-1.json';assert not refresh.exists();refresh.write_text(json.dumps(receipt,indent=2)+'\n')
accounting=jp('accounting.json',{
 'method':'Source-derived accounting and storage audit; no project execution, imports, allocator measurements or outcome-derived expected values.',
 'unchanged_caps':{'query_bytes':16384,'two_argument_property_bytes':256,'local_value_bytes':4096,'css_work_ceiling':262144,'runtime_entry_work':100000,'terms':64,'supports_depth':16,'variable_depth':16,'variable_internal_value_bytes':65536,'variable_name_grammar_bytes':256,'identifier_decoder_bytes':1024},
 'new_query_raw_value_bound':'pending_value raw span >4096 is ordinary false before its new name debit. Old no-var condition leaves retain their comment-stripped local value bound. The condition preparation span can include original comments before this new guard.',
 'tariffs':{
 'old_two_argument_prefix':'8*(p+v)+1, property tokenizer 2p+1, value tokenizer 2v+1, evaluator structure T+1: unchanged.',
 'old_condition_prefix':'Existing query, token, condition, leaf, closing, term and 8*clean_declaration+1 charges stay unchanged.',
 'detection':'Read already-owned tokens; the existing 8*declaration/value scan envelope funds this bounded name/token pass. A no-var leaf executes no newly inserted spend.',
 'new_condition_preparation':'2*d+1 tokenizer plus Td+1 scan; CSS identifier decoding and priority span extraction retain original token boundaries. Preparation vector dies before variable parser entry.',
 'new_name_recognition':'1 + (SUPPORTED_PROPERTIES.len()+29+13)*(name.len()+1); currently 1+130*(name.len()+1). Paid before lowercase allocation and finite roster/alias comparisons.',
 'shared_checked_variable_parse':'2*v+1 tokenizer then 4*T+1 planning, same as the old Option parser: total 2*v+4*T+2.',
 'new_query_structure':'T+1 after successful variable parse, before a scalar-depth/component pass. NUL raw-byte scanning remains within the original source scan envelope.',
 'two_argument_width_var_literal':{'property':'width','value':'var(--x)','source_derived_css_total':952,'terms':{'entry':105,'name_tokens':11,'value_tokens':17,'outer_structure':4,'new_name':781,'variable_parse':30,'new_structure':4}},
 'failure':'Failed work spending leaves zero. Limit from token/depth/decoder refusals aborts the Result and marks the evaluator exhausted even when work remains. Invalid remains an ordinary false leaf. Public Runtime retains its existing steps==0 terminal observer.'},
 'scratch':{
 'unchanged_runtime_charge':'256*combined_original_UTF8_bytes + 4096',
 'model':'Conservative requested live temporary storage on selected 64-bit targets; allocator internals/RSS and cumulative allocation-call volume are not claimed.',
 'input_symbol':'B = combined original query/argument bytes; value raw <=4096; full query <=16384.',
 'tokens':'Use a conservative 48-byte Token envelope and doubling capacity <2*T+4. At most two substantial token vectors coexist: outer tokens plus condition preparation OR variable tokens. Two-argument name tokens use the property share of B. Bound 192*B+384.',
 'closes_and_stack':'The checked parser close vector is 8*T <=8*B; its depth-limited tuple stack uses <=256 bytes.',
 'references':'For R valid references, R<=B/8. Insert-only BTree nodes have at least five entries except their root; a conservative 768-byte node envelope yields <=768*(R/5+1) <=19.2*B+768. Decoded referenced names and retained declaration name fit <=9*B+16, including geometric capacity and NUL expansion.',
 'condition_strings':'At most the top normalized query and 16 nested normalized leaf strings coexist; strip_comments reserves exactly source length and never grows it. Bound <=17*B.',
 'failure_temporaries':'Allow an extra 2048 bytes for a checked identifier allocation reaching its old 1024-byte decoder boundary before refusal.',
 'combined':'<=245.2*B+3472, below 256*B+4096. Preparation-token drop is material to this bound. The earlier unchanged Runtime argument conversion allocations are separately charged.',
 'qualification':'Source-model audit only; no new physical-size measurement or performance claim.'},
 'old_exact_cut_scope':'All old no-var spend sites remain on the same paths. CSSOM alias mapping, clone/prepare/summary/accounting and parser Option consumers retain their old operations and debit values.',
 'source_bindings':bindings})
stdlib=Path('/home/eriskii/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/lib/rustlib/src/rust/library/alloc/src')
stdrefs=[bind(stdlib/'collections/btree/node.rs'),bind(stdlib/'raw_vec/mod.rs')]
proof=jp('source-proof.json',{
 'source_only':True,'origin_candidate':bind(P/'source-candidate-2.json'),'published_base_refresh':bind(refresh),
 'implemented_ordinary_names':{'longhands':roster,'shorthands':shorts,'aliases':dict(aliases),'counts':[88,29,13]},
 'old_option_calls_exact':old_var_calls,
 'identifier_wrapper_proof':'Every original success produces the same String and consumed count; each former None/question-mark exit becomes Invalid or Limit and the unchanged Option API maps either back to None. No debit or allocation operation is introduced in the decoder body.',
 'variable_wrapper_proof':'Old tokens, stack, close map, reference construction, fallback checks and spend sites retain their order. Existing Option consumers map either typed refusal to None. Name length >256 remains Invalid; only the existing 1024-byte identifier decoder cap and existing token/work/depth/value resource guards are Limit.',
 'no_var_proof':'Both new branch guards require an actual Function token whose escaped/case-insensitive decoded name is var. False guards preserve every old support branch and spend call. Strings, URL payloads, comments and split names cannot trigger the new branch.',
 'structural_rule':'New var queries alone apply CSS Syntax declaration step 8: a sole top-level curly block is allowed, mixed components with a top-level curly block are refused; nested fallback blocks remain permitted. Existing substitution callers do not acquire this query-specific rule.',
 'primary_sources':[
 {'url':'https://www.w3.org/TR/2026/CRD-css-syntax-3-20261001/#consume-a-declaration','claim':'Section 5.5.6 step 8 permits a sole top-level curly block for an ordinary declaration, but refuses it alongside another non-whitespace component.'},
 {'url':'https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables','claim':'The selected legacy var grammar uses a literal custom-property name and optional fallback; valid pending values defer final property grammar.'},
 {'url':'https://raw.githubusercontent.com/rust-lang/rust/1.88.0/library/alloc/src/collections/btree/node.rs','claim':'B=6, capacity11, post-split minimum5 and 12 child edges match the retained-node envelope.'},
 {'url':'https://raw.githubusercontent.com/rust-lang/rust/1.88.0/library/alloc/src/raw_vec/mod.rs','claim':'Amortized capacity growth and minimum initial capacity support the conservative vector envelope.'}],
 'local_1991_stdlib_sources':stdrefs,
 'preservation':['All old property/variable caps unchanged','Runtime conversion/order/scratch/terminal observer unchanged','No DOM or resource calls','No variable substitution or shorthand expansion in the new query path','No generic custom-property query support','No newer substituted-name grammar','All prior production bytes outside recorded edits exact','All old tests remain exact in the production hold; five migrations are separately sealed'],
 'no_project_execution':True,'no_live_edits':True})
checks=jp('checks.json',{'status':'source checks clear; root execution pending','before_candidate_and_published_git_exact':True,'inverse_all_14_edits_exact':True,'outside_edits_exact':True,'alias_table_inverse_exact':True,'old_option_call_lines_exact':True,'old_test_rosters_and_literals_unchanged_in_production':True,'production_paths':2,'new_test_groups':0,'recognition_counts':[88,29,13],'source_derived_width_var_charge':952,'scope':'production separate from five historical expectation migrations','no_project_execution':True,'no_live_edits':True})
seal=jp('source-ready.json',{'schema':1,'status':'source-ready; root imports and executes','base':base,'origin':bind(P/'source-candidate-2.json'),'published_base_refresh':bind(refresh),'selection':bind(Q/'design-1.json'),'curly_selection':bind(Q/'design-curly-addendum-1.json'),'assessment':bind(Path('/tmp/eris-supports-var-assessment-1.json')),'assessment_peer':bind(Path('/tmp/eris-supports-var-review-1.json')),'files':files,'edits':bind(H/'edits.json'),'accounting':accounting,'source_proof':proof,'checks':checks,'historical_migrations':bind(Q/'migrations-1/source-ready.json'),'path_count':2,'changed_seams':['css_identifier Option wrapper plus checked helper','shared existing aliases and ordinary-name predicate','two supports var dispatch sites','condition original-token handoff','new pending declaration/value helpers','VariableSyntax Option wrapper plus checked helper'],'project_execution':False,'live_edits':False})
print(json.dumps({'source_ready':seal,'base_refresh':bind(refresh),'accounting':accounting,'proof':proof},indent=2))
