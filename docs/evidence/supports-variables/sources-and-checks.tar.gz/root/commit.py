from pathlib import Path
import hashlib, json, subprocess

q = Path(__file__).resolve().parents[1]
w = q / 'worktree'
main = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
publication = q / 'publication'
publication.mkdir(exist_ok=True)
base = '339b257f3e9e5ac45ab1bd85d00e1a4be36b307f'

def git(*args, cwd=w):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()

def load(path):
    return json.loads(path.read_text())

assert git('rev-parse', 'HEAD') == base
assert git('rev-parse', 'HEAD', cwd=main) == base
assert git('status', '--porcelain', cwd=main) == ''
assert git('diff', '--cached', '--name-only') == ''
summary = load(q/'root/final-validation.json')
assert summary['status'] == 'pass'
source = {row['path']: row for row in summary['changed_sources']}
docs = load(q/'docs-final-1/manifest.json')
doc_paths = {row['path'] for row in docs}
doc_rows = {row['path']: row for row in docs}
evidence_paths = {'docs/evidence/supports-variables/validation.json',
                  'docs/evidence/supports-variables/sources-and-checks.tar.gz'}
expected = set(source) | doc_paths | evidence_paths
actual = set(git('diff', '--name-only').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines())
assert actual == expected, (actual-expected, expected-actual)
subprocess.run(['git', 'diff', '--check'], cwd=w, check=True)
rows = []
for path in sorted(expected):
    data = (w/path).read_bytes()
    row = {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    if path in source:
        assert row == source[path]
    if path in doc_rows:
        assert row == doc_rows[path]
    rows.append(row)
with (publication/'commit-inputs.json').open('x') as out:
    json.dump(rows, out, indent=2)
    out.write('\n')
subprocess.run(['git', 'add', '--', *sorted(expected)], cwd=w, check=True)
assert set(git('diff', '--cached', '--name-only').splitlines()) == expected
subprocess.run(['git', 'commit', '-m', 'Recognize pending variable syntax in CSS feature queries'], cwd=w, check=True)
commit = git('rev-parse', 'HEAD')
assert git('rev-parse', 'HEAD^') == base
assert git('status', '--porcelain') == ''
subprocess.run(['git', 'merge', '--ff-only', commit], cwd=main, check=True)
assert git('status', '--porcelain', cwd=main) == ''
record = {'commit': commit, 'base': base, 'paths': len(expected),
          'branch': 'main', 'status': 'committed; push pending'}
with (publication/'commit-result.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
print(json.dumps(record))
