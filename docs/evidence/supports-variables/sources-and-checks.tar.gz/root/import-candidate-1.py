from pathlib import Path
import hashlib, json

q = Path('/tmp/eris-supports-var-plan-1')
w = q / 'worktree'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def verify_refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and value['path'].startswith('/'):
            data = Path(value['path']).read_bytes()
            assert len(data) == value['bytes'] and digest(data) == value['sha256'], value['path']
        for child in value.values():
            verify_refs(child)
    elif isinstance(value, list):
        for child in value:
            verify_refs(child)

holds = {}
for name, expected in [
    ('implementation-1', 'db34a0832da1f5d0704a7d9c4e5e22061a1dfed965f8b9187f75b46a9154fedd'),
    ('migrations-1', 'ea5201ff8d747323a75081f4651915aeb381c89eedd6052a5c6b25a13ed047c7'),
    ('budget-controls-1', 'dfd2c99e709842276741f16cc16cab397f528afa7e75c489439c004d82d3cfbe'),
]:
    manifest = q / name / 'source-ready.json'
    assert digest(manifest.read_bytes()) == expected
    holds[name] = read_json(manifest)
    verify_refs(holds[name])

# Build the composition in memory and check every precondition before live writes.
composed = {}
for row in holds['implementation-1']['files']:
    assert (w / row['path']).read_bytes() == Path(row['before']['path']).read_bytes()
    composed[row['path']] = Path(row['raw']['path']).read_bytes()
for row in holds['migrations-1']['files']:
    assert (w / row['path']).read_bytes() == Path(row['before']['path']).read_bytes()
    composed.setdefault(row['path'], (w / row['path']).read_bytes())
for chunk in read_json(q / 'migrations-1/chunks.json'):
    path = chunk['path']
    old, new = chunk['old'].encode(), chunk['new'].encode()
    assert composed[path].count(old) == 1, chunk
    composed[path] = composed[path].replace(old, new, 1)
for row in holds['budget-controls-1']['files']:
    assert not (w / row['path']).exists()
    composed[row['path']] = Path(row['raw']['path']).read_bytes()
registration = read_json(q / 'budget-controls-1/registration.json')
verify_refs(registration)
fragment = Path(registration['fragment']['path']).read_bytes()
assert b'mod supports_var_budget_tests;' not in composed['src/css.rs']
composed['src/css.rs'] += fragment

receipt = {'holds': {name: digest((q/name/'source-ready.json').read_bytes()) for name in holds},
           'composition': 'production, exact five-row historical migration chunks, separate budget registration',
           'root_review': 'Reviewed complete forward diffs, typed refusal mapping, name recognition, original-token condition preparation, priority and curly rules, scratch source proof, and six independent budget groups.',
           'files': []}
for name, data in sorted(composed.items()):
    out = q / 'candidate-import-1/after' / name
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('xb') as f:
        f.write(data)
    target = w / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    receipt['files'].append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
with (q / 'root/production-import-1.json').open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps(receipt, indent=2))
