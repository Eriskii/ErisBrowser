from pathlib import Path
import json,hashlib,difflib,re
Q=Path('/tmp/eris-supports-var-plan-1');H=Q/'implementation-1';P=Path('/tmp/eris-pointer-events-plan-1');W=P/'worktree'
assert not (H/'source-ready.json').exists()
edits=json.loads((H/'edits.json').read_text());files=json.loads((H/'files.json').read_text())
before={r['path']:(H/'before'/r['path']).read_text() for r in files};raw={r['path']:(H/'raw'/r['path']).read_text() for r in files}
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(rel,b):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b.encode() if isinstance(b,str) else b);return bind(p)
def jp(rel,obj):return put(rel,json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def edit(path,old,new,reason):
 assert raw[path].count(old)==1,(reason,raw[path].count(old));raw[path]=raw[path].replace(old,new,1);edits.append({'path':path,'old':old,'new':new,'reason':reason})
path='src/css.rs';start=raw[path].index('pub(crate) fn css_identifier(rest: &str)');end=raw[path].index('pub fn parse_stylesheet(',start);old=raw[path][start:end]
body=old.replace('pub(crate) fn css_identifier(rest: &str) -> Option<(String, usize)> {','fn css_identifier_checked(rest: &str) -> Result<(String, usize), crate::selectors::Error> {\n    use crate::selectors::Error;',1)
body=body.replace('return None;','return Err(Error::Invalid);')
body=body.replace('if name.len() > 1024 {\n            return Err(Error::Invalid);','if name.len() > 1024 {\n            return Err(Error::Limit);',1)
body=body.replace('rest.chars().next()?','rest.chars().next().ok_or(Error::Invalid)?')
body=body.replace('chars.next()?','chars.next().ok_or(Error::Invalid)?')
body=body.replace('next.to_digit(16)?','next.to_digit(16).ok_or(Error::Invalid)?')
body=body.replace('digit.to_digit(16)?','digit.to_digit(16).ok_or(Error::Invalid)?')
body=body.replace('    (!name.is_empty() && name.len() <= 1024).then_some((name, consumed))','''    if name.len() > 1024 {
        Err(Error::Limit)
    } else if name.is_empty() {
        Err(Error::Invalid)
    } else {
        Ok((name, consumed))
    }''',1)
wrapper='''pub(crate) fn css_identifier(rest: &str) -> Option<(String, usize)> {
    css_identifier_checked(rest).ok()
}
'''
edit(path,old,wrapper+body,'Preserve the existing identifier Option API; expose only the existing 1024-byte internal decoder refusal as Limit.')
edit(path,'css_identifier(name_token.raw).ok_or(Error::Invalid)?','css_identifier_checked(name_token.raw)?','Checked var parsing preserves the decoder resource category without a duplicate decoder.')
edit(path,'''            if name.len() > 256 {
                return Err(Error::Limit);
            }
            at += 1;''','''            if name.len() > 256 {
                return Err(Error::Invalid);
            }
            at += 1;''','Keep the 256-byte variable-name grammar bound ordinary Invalid; only the internal decoder cap is resource.')
edit(path,'''        use crate::selectors::{Error, Kind};
        // The fixed match arms are 29 shorthands plus 13 aliases.''','''        use crate::selectors::{Error, Kind};
        // This new raw-value cap is an ordinary false leaf, like the existing
        // local declaration bounds; it does not change any no-var leaf.
        if value.len() > 4096 {
            return Ok(false);
        }
        // The fixed match arms are 29 shorthands plus 13 aliases.''','Bind the selected new raw pending-value cap without changing existing no-var local cap policy.')
for row in files:
 path=row['path'];b=before[path];r=raw[path]
 row['raw']=put('raw/'+path,r)
 row['forward']=put('diffs/forward/'+path+'.patch',''.join(difflib.unified_diff(b.splitlines(True),r.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
 row['inverse']=put('diffs/inverse/'+path+'.patch',''.join(difflib.unified_diff(r.splitlines(True),b.splitlines(True),fromfile='b/'+path,tofile='a/'+path)))
rec=raw.copy()
for e in reversed(edits):
 if e['new']:
  assert rec[e['path']].count(e['new'])==1,e['reason'];rec[e['path']]=rec[e['path']].replace(e['new'],e['old'],1)
 else:rec[e['path']]=rec[e['path']].replace('fn name(name: &str)',e['old']+'fn name(name: &str)',1)
assert rec==before
jp('edits.json',edits);jp('files.json',files)
print(json.dumps({'chunks':len(edits),'raw':[f['raw'] for f in files]},indent=2))
