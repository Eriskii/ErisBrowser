CSS.supports('width','var(--missing)') &&
CSS.supports('width:var(--missing)') &&
CSS.supports('(width:var(--missing))') &&
CSS.supports('(w\\69 dth:var(--missing))') &&
!CSS.supports('w\\69 dth','var(--missing)') &&
CSS.supports('width:var(--missing) !important') &&
!CSS.supports('width','var(--missing)!important') &&
!CSS.supports('unknown-property','var(--x)') &&
!CSS.supports('--theme','var(--x)');
