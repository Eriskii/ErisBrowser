var trace = '';
function argument(label, value) {
  return {toString:function(){trace += label + ';';return value;}};
}
var extra = {toString:function(){trace += 'extra;';throw 1;}};
var accepted = CSS.supports(argument('property','width'), argument('value','var(--x)'), extra);
var first = accepted && trace === 'property;value;';
trace = '';
var rejected = CSS.supports(argument('property','unknown-property'), argument('value','var(--x)'));
var second = !rejected && trace === 'property;value;';
trace = '';
var sentinel = {};
var caughtFirst = false;
try { CSS.supports({toString:function(){trace += 'first;';throw sentinel;}}, argument('second','var(--x)')); }
catch (error) { caughtFirst = error === sentinel; }
var third = caughtFirst && trace === 'first;';
trace = '';
var caughtValue = false;
try { CSS.supports('unknown-property', {toString:function(){trace += 'value;';throw sentinel;}}); }
catch (error) { caughtValue = error === sentinel; }
first && second && third && caughtValue && trace === 'value;';
