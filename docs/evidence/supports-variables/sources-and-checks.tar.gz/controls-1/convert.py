from pathlib import Path
import json,hashlib,difflib,re,subprocess
H=Path('/tmp/eris-supports-var-plan-1/controls-1');P=Path('/tmp/eris-pointer-events-plan-1')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
def verify(seal):
 for f in seal.get('files',[]):
  b=bind(Path(f['path']));assert b==f
original=json.loads((H/'literal-ready.json').read_bytes());verify(original)
curlyseal=json.loads((H/'curly-literal-ready.json').read_bytes());assert bind(Path(curlyseal['cases']['path']))==curlyseal['cases']
C=json.loads((H/'cases.json').read_bytes());X=json.loads((H/'curly-cases.json').read_bytes())
def rs(s):return json.dumps(s,ensure_ascii=False).replace(chr(92)+'u0000',chr(92)+'0')
def boolean(b):return str(b).lower()
lines=['''//! Selected legacy var() feature-query semantics, frozen before producer inspection.
//! Custom-property queries and newer arbitrary first-argument substitution remain deferred.
use eris::{
    css,
    graphics::{Canvas, Color, Fonts},
    page::Page,
    script::Value,
};
use url::Url;

fn pairs(rows: &[(&str, &str, bool)]) {
    for &(property, value, expected) in rows {
        assert_eq!(
            css::supports_declaration(property, value),
            expected,
            "property={property:?}, value={value:?}"
        );
    }
}

fn conditions(rows: &[(&str, bool)]) {
    for &(query, expected) in rows {
        assert_eq!(css::supports_matches(query), expected, "query={query:?}");
    }
}

#[test]
fn supports_var_complete_implemented_name_roster() {
    // Explicit source-derived 88 longhands, 29 shorthands and 13 existing aliases.
    // This table is independent of the producer's future recognition helper.
    for (property, query) in [
''']
for r in C['roster']:lines.append('        ('+rs(r['property'])+', '+rs(r['condition'])+'),\n')
lines.append('''    ] {
        assert!(css::supports_declaration(property, "var(--missing)"), "{property}");
        assert!(css::supports_matches(query), "{query}");
    }
}
''')
def group(name,g):
 lines.append('\n#[test]\nfn supports_var_'+name+'() {\n    pairs(&[\n')
 for r in g['pairs']:lines.append('        ('+rs(r['property'])+', '+rs(r['value'])+', '+boolean(r['expected'])+'),\n')
 lines.append('    ]);\n    conditions(&[\n')
 for r in g['conditions']:lines.append('        ('+rs(r['query'])+', '+boolean(r['expected'])+'),\n')
 lines.append('    ]);\n}\n')
for name,g in C['groups'].items():group(name,g)
group('top_level_curly_structure',X)
lines.append('''
fn runtime(source: &str) {
    for strict in [false, true] {
        let mut page = Page::from_html(
            Url::parse("https://supports-var.invalid/").unwrap(),
            "<div id=target></div>",
            false,
        );
        let result = if strict {
            page.runtime.execute_strict(source, &mut page.document)
        } else {
            page.runtime.execute(source, &mut page.document)
        };
        assert_eq!(result.unwrap(), Value::Bool(true), "strict={strict}");
        assert!(page.diagnostics.is_empty(), "{:?}", page.diagnostics);
    }
}
''')
raw_literals={}
for name,r in C['runtime'].items():
 source=(H/r['source']).read_text();assert '"###' not in source
 raw_literals['runtime_'+name]=source
 lines.append('\n#[test]\nfn supports_var_runtime_'+name+'() {\n    runtime(r###"'+source+'"###);\n}\n')
scene=C['stylesheet'];html=(H/scene['source']).read_text();assert '"###' not in html;raw_literals['stylesheet']=html
lines.append('\n#[test]\nfn supports_var_stylesheet_condition_selects_literal_pixels() {\n')
lines.append('    let page = Page::from_html(\n        Url::parse("https://supports-var.invalid/").unwrap(),\n        r###"'+html+'"###,\n        false,\n    );\n')
lines.append('''    let fonts = Fonts::new();
    let layout = page.layout(8.0, 6.0, &fonts);
    let mut canvas = Canvas::new(8, 6).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(&layout.commands, &fonts, &page.images, 0.0, 0.0);
    assert!(!canvas.exhausted());
    let mut expected = vec![0xffffff; 8 * 6];
    for row in 0..3 {
        expected[row * 8..row * 8 + 4].fill(0x00ff00);
    }
    assert_eq!(canvas.pixels, expected);
    assert!(page.diagnostics.is_empty(), "{:?}", page.diagnostics);
}
''')
raw=''.join(lines);out=H/'raw/tests/supports_var.rs';out.parent.mkdir(parents=True,exist_ok=True);assert not out.exists();out.write_text(raw)
extract=re.findall(r'r###"([\s\S]*?)"###',raw);assert extract==list(raw_literals.values())
# Independently decode only ordinary generated Rust string tokens; no Rust/project execution.
def unrs(s):return json.loads(s.replace(chr(92)+'0',chr(92)+'u0000'))
for row in C['roster']:assert ('('+rs(row['property'])+', '+rs(row['condition'])+'),') in raw
for g in list(C['groups'].values())+[X]:
 for r in g['pairs']:
  assert ('('+rs(r['property'])+', '+rs(r['value'])+', '+boolean(r['expected'])+'),') in raw
  assert unrs(rs(r['property']))==r['property'] and unrs(rs(r['value']))==r['value']
 for r in g['conditions']:
  assert ('('+rs(r['query'])+', '+boolean(r['expected'])+'),') in raw
  assert unrs(rs(r['query']))==r['query']
assert [scene[k] for k in ['width','height','clear']]==[8,6,0xffffff]
assert scene['rectangles']==[[0,0,4,3,0x00ff00]]
functions=re.findall(r'^fn (supports_var_\w+)\(',raw,re.M);assert len(functions)==raw.count('#[test]')==12
for directory,fromfile,tofile,before,after in [('diff','/dev/null','b/tests/supports_var.rs','',raw),('inverse','a/tests/supports_var.rs','/dev/null',raw,'')]:
 d=H/directory/'tests/supports_var.rs.diff';d.parent.mkdir(parents=True,exist_ok=True);d.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=fromfile,tofile=tofile)))
base='3d90bd578f2b17318e3e5831849e0aee526e68c4';W=P/'worktree';api=[]
for path in ['tests/pointer_events_cssom.rs','tests/visibility.rs','src/page.rs','src/script.rs','src/graphics.rs']:
 snap=P/'candidate-source-1'/path
 b=snap.read_bytes() if snap.exists() else subprocess.run(['git','-C',str(W),'show',base+':'+path],check=True,capture_output=True).stdout
 d=H/'api-before'/path;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b);api.append(bind(d))
paths=subprocess.run(['git','-C',str(W),'ls-tree','-r','--name-only',base],check=True,capture_output=True,text=True).stdout.splitlines();assert 'tests/supports_var.rs' not in paths
save(H/'conversion-checks.json',{'status':'source-only conversion clear; unexecuted','original_literals':bind(H/'literal-ready.json'),'curly_literals':bind(H/'curly-literal-ready.json'),'inspection_clarification':bind(H/'inspection-clarification.json'),'functions':functions,'groups':12,'public_css_boolean_assertions_if_complete':260+sum(len(g['pairs'])+len(g['conditions']) for g in C['groups'].values())+len(X['pairs'])+len(X['conditions']),'runtime_sources':3,'runtime_strict_sloppy_attempts_if_complete':6,'stylesheet_pixel_checks':1,'original_row_literals_exact':True,'raw_js_html_extraction_exact':True,'expected_booleans_changed':False,'new_numeric_work_cuts':False,'api_bindings':api,'limitations':['Counts describe static source paths, not observed tests.','The stylesheet uses a CPU Canvas pixel oracle; no hardware/GPU comparison.','Resource behavior is constrained by design but no new numeric work contract is asserted.','The CSS admission URL row does not by itself instrument network fetches.'],'original_literal_seal_unchanged':True})
verify(original)
artifacts=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
save(H/'source-ready.json',{'status':'source-ready-unexecuted-public-controls','selected_design':bind(H.parent/'design-1.json'),'selected_curly_addendum':bind(H.parent/'design-curly-addendum-1.json'),'literal_seals':[bind(H/'literal-ready.json'),bind(H/'curly-literal-ready.json')],'payload':{'path':'tests/supports_var.rs','before':None,'raw':bind(out),'diff':bind(H/'diff/tests/supports_var.rs.diff'),'inverse':bind(H/'inverse/tests/supports_var.rs.diff')},'registration':'None; Cargo discovers this top-level integration test. No existing file edits.','checks':bind(H/'conversion-checks.json'),'groups':12,'published_base_pending':True,'base_requirement':'Refresh source/API bindings additively to published P before root import. No Q producer source inspected.','artifacts':artifacts,'project_execution':False,'live_edits':False})
print(json.dumps(bind(H/'source-ready.json'),indent=2))
