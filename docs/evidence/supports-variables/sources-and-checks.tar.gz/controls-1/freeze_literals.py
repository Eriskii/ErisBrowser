from pathlib import Path
import json,hashlib,re
Q=Path('/tmp/eris-supports-var-plan-1');H=Q/'controls-1';P=Path('/tmp/eris-pointer-events-plan-1')
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(p,o):p.write_text(json.dumps(o,indent=2)+'\n')
assert not (H/'literal-ready.json').exists()
design=json.loads((Q/'design-1.json').read_bytes());origin=Path(design['origin_candidate']);inv=json.loads(origin.read_bytes());M={r['path']:r for r in inv['files']}
css=(P/'candidate-source-1/src/css.rs').read_bytes();assert sha(css)==M['src/css.rs']['sha256']==design['origin_css_sha256']
cssom=(P/'candidate-source-1/src/cssom.rs').read_bytes()
text=css.decode();roster=re.findall(r'"([^"]+)"',text.split('const SUPPORTED_PROPERTIES:',1)[1].split('];',1)[0]);short=re.findall(r'"([^"]+)"',text.split('pub(crate) fn shorthand_property_count(',1)[1].split('pub(crate) fn shorthand_properties',1)[0]);alias=dict(re.findall(r'"([^"]+)" => "([^"]+)"',cssom.decode().split('fn alias(',1)[1].split('\nfn name(',1)[0]));assert [len(roster),len(short),len(alias)]==[88,29,13]
for p,b in [('src/css.rs',css),('src/cssom.rs',cssom)]:
 d=H/'source-inputs'/p;d.parent.mkdir(parents=True,exist_ok=True);d.write_bytes(b)
roster_rows=[{'category':category,'property':n,'value':'var(--missing)','condition':f'({n}:var(--missing))','expected':True} for category,names in [('longhand',roster),('shorthand',short),('alias',list(alias))] for n in names]
def pairs(rows):return [{'property':p,'value':v,'expected':e} for p,v,e in rows]
def conditions(rows):return [{'query':q,'expected':e} for q,e in rows]
groups={
'names':{'pairs':pairs([
('WIDTH','var(--x)',True),('font-size','var(--x)',True),('inline-size','var(--x)',True),
(' width','var(--x)',False),('width ','var(--x)',False),(r'w\69 dth','var(--x)',False),('width/**/','var(--x)',False),('wi/**/dth','var(--x)',False),
('unknown-property','var(--x)',False),('transform','var(--x)',False),('--theme','var(--x)',False),('--theme','blue',False),('--theme','',False),('--','var(--x)',False),
]),'conditions':conditions([(r'(w\69 dth:var(--x))',True),(r'(pointer\2d events:var(--x))',True),('( WIDTH : var(--x) )',True),('(inline-size:var(--x))',True),('(wi/**/dth:var(--x))',False),('(unknown-property:var(--x))',False),('(transform:var(--x))',False),('(--theme:var(--x))',False),('(--theme:blue)',False),('(--theme:)',False)])},
'real_tokens':{'pairs':pairs([
('width','VAR(--x)',True),('width',r'v\61 r(--x)',True),('width',r'var(--\78)',True),('width','fn(var(--x))',True),('width','/**/var(--x)/**/',True),('width','"var(--x)"',False),('width','/*var(--x)*/',False),('width','/*var(--x)*/1px',True),('width','v/**/ar(--x)',False),('width','var /*gap*/(--x)',False),('width','myvar(--x)',False),('width','var(--x,"var(foo)")',True),
]),'conditions':conditions([(r'(width:v\61 r(--x))',True),('(width:"var(--x)")',False),('(width:v/**/ar(--x))',False)])},
'legacy_fallbacks':{'pairs':pairs([
('color','var(--x,)',True),('color','var(--x, var(--y, red))',True),('color','var(--x, var(--y,))',True),('color','var(--x,,)',True),('color','var(--x,";")',True),('color','var(--x,"!important")',True),('color','var(--x, fn(;))',True),('color','var(--x, {a;b})',True),('color','var(--x, [a;b])',True),
('width','var()',False),('width','var(foo)',False),('width','var(--)',False),('width','var(--x extra)',False),('width','var(--x, var(foo))',False),('width','var(var(--name))',False),('width','var(--x, !important)',False),('width','var(--x, a;b)',False),('width','var(--x])',False),('width','var(--x',False),('width','var(--x)\0',False),
]),'conditions':conditions([('(color:var(--x, fn(;)))',True),('(color:var(--x, {a;b}))',True),('(color:var(--x,";"))',True),('(width:var(--x, var(foo)))',False)])},
'deferred_grammar':{'pairs':pairs([
('width','nonsense var(--x)',True),('width','calc(var(--x) + )',True),('color','future(var(--x))',True),('visibility','var(--x,collapse)',True),('pointer-events','var(--x,visiblePainted)',True),('background-image','var(--x,url("https://no-query-fetch.invalid/a.png"))',True),('border','var(--x,unrecognized)',True),('all','var(--reset)',True),
]),'conditions':conditions([('(width:calc(var(--x) + ))',True),('(pointer-events:var(--x,visiblePainted))',True),('(all:var(--reset))',True)])},
'priority_boolean':{'pairs':pairs([('width','var(--x)!important',False),('width','var(--x) !/**/IMPORTANT',False),('width','var(--x);color:red',False)]),'conditions':conditions([
('(width:var(--x) !important)',True),('(width:var(--x) !/**/IMPORTANT)',True),('(width:var(--x);color:red)',False),('not (width:var(--x))',False),('not (width:var(foo))',True),('(width:var(--x)) and (display:grid)',True),('(width:var(foo)) or (display:grid)',True),('(unknown-property:var(--x)) or (width:var(--x))',True),('not (--theme:var(--x))',True),('not (width:var(--x])',False),('(display:grid) or (width:var(--x])',False),('width:var(--x)',False),
])},
'no_var':{'pairs':pairs([('width','1px',True),('width','1 px',False),('display','grid',True),('visibility','hidden',True),('pointer-events','none',True),('pointer-events','visiblePainted',False),('font-size','12px',False),('unknown-property','inherit',False)]),'conditions':conditions([('(display:grid)',True),('not (position:sticky)',True),(r'(w\69 dth:1px)',False),(r'(visibility:\68 idden)',True)])},
}
js={
'forms':r'''CSS.supports('width','var(--missing)') &&
CSS.supports('width:var(--missing)') &&
CSS.supports('(width:var(--missing))') &&
CSS.supports('(w\\69 dth:var(--missing))') &&
!CSS.supports('w\\69 dth','var(--missing)') &&
CSS.supports('width:var(--missing) !important') &&
!CSS.supports('width','var(--missing)!important') &&
!CSS.supports('unknown-property','var(--x)') &&
!CSS.supports('--theme','var(--x)');''',
'coercion':r'''var trace = '';
function argument(label, value) {
  return {toString:function(){trace += label + ';';return value;}};
}
var extra = {toString:function(){trace += 'extra;';throw 1;}};
var accepted = CSS.supports(argument('property','width'), argument('value','var(--x)'), extra);
var first = accepted && trace === 'property;value;';
trace = '';
var rejected = CSS.supports(argument('property','unknown-property'), argument('value','var(--x)'));
var second = !rejected && trace === 'property;value;';
trace = '';
var sentinel = {};
var caughtFirst = false;
try { CSS.supports({toString:function(){trace += 'first;';throw sentinel;}}, argument('second','var(--x)')); }
catch (error) { caughtFirst = error === sentinel; }
var third = caughtFirst && trace === 'first;';
trace = '';
var caughtValue = false;
try { CSS.supports('unknown-property', {toString:function(){trace += 'value;';throw sentinel;}}); }
catch (error) { caughtValue = error === sentinel; }
first && second && third && caughtValue && trace === 'value;';''',
'computed_independence':r'''var s = document.getElementById('target').style;
var a = CSS.supports('width','var(--x)');
s.setProperty('--x','17px');
var b = CSS.supports('width','var(--x)');
s.setProperty('--x','not-a-width');
var c = CSS.supports('width','var(--x)');
s.setProperty('--x','var(--y)');
s.setProperty('--y','var(--x)');
var d = CSS.supports('width','var(--x)');
s.removeProperty('--x');
var e = CSS.supports('width','var(--x)');
a && b && c && d && e && s.getPropertyValue('--x') === '' && s.getPropertyValue('--y') === 'var(--x)';''',
}
html='''<!doctype html><style>
html,body{margin:0;padding:0}
#target{width:4px;height:3px;background:#ff0000;--loop:var(--loop)}
@supports (visibility:var(--missing)){#target{background:#00ff00}}
@supports not (visibility:var(--missing)){#target{background:#0000ff}}
</style><div id=target></div>\n'''
for name,source in js.items():
 p=H/'literals'/f'{name}.js';p.parent.mkdir(exist_ok=True);p.write_text(source+'\n')
(H/'literals/stylesheet.html').write_text(html)
casebook={'design':bind(Q/'design-1.json'),'origin_inventory':bind(origin),'origin_qualification':'P candidate2 is not a published Q base. An additive final published-base binding is required before integration.','roster':roster_rows,'groups':groups,'runtime':{name:{'source':'literals/'+name+'.js','expected_boolean':True,'strict_modes':[False,True]} for name in js},'stylesheet':{'source':'literals/stylesheet.html','width':8,'height':6,'clear':16777215,'rectangles':[[0,0,4,3,65280]],'expected_target_background_rgb':[0,255,0],'scripts':False},'qualifications':['Select existing literal custom-name var grammar, not current editor-draft arbitrary first-argument substitution.','Custom-property queries, attr/env and registration remain deferred.','No new numeric work cuts. Existing byte/depth/term caps and local-cap false/invertibility policy remain explicit; this finite semantic roster does not prove those resource boundaries.','No query-time DOM lookup/substitution/fetch is necessary. The URL-value boolean is an admission check and alone does not prove no fetch occurred.','No-var answers remain historical, including unsupported font-size value reporting and generic escaped ordinary condition names.']}
save(H/'cases.json',casebook)
save(H/'specification.json',{'sources':[{'url':'https://www.w3.org/TR/2024/CRD-css-conditional-3-20240815/#support-definition','sections':['6.1','7.5'],'use':'Accepted declaration reporting, literal ordinary API names, condition CSS syntax and priority distinction.'},{'url':'https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables','sections':['3','3.2'],'use':'Existing literal custom-name var grammar; valid references defer final property grammar, including empty fallback.'}],'selection':'Q design explicitly preserves current implementation caps/no-var answers and defers custom properties/current editor-draft argument grammar. Tests are a bounded selected compatibility contract, not a full standards conformance claim.','spec_review_reference':bind(Path('/tmp/eris-supports-var-review-1.json'))})
files=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='literal-ready.json']
save(H/'literal-ready.json',{'status':'independent-literals-frozen-before-executable-adapter','design':bind(Q/'design-1.json'),'cases':bind(H/'cases.json'),'files':files,'counts':{'roster':len(roster_rows),'pair_rows':sum(len(v['pairs']) for v in groups.values()),'condition_rows':sum(len(v['conditions']) for v in groups.values()),'runtime_sources':len(js),'runtime_mode_attempts':6,'stylesheet_witnesses':1},'candidate_implementation_inspected':False,'project_execution':False,'live_edits':False})
print(json.dumps(bind(H/'literal-ready.json'),indent=2))
