from pathlib import Path
import json, hashlib, difflib, subprocess

Q=Path('/tmp/eris-supports-var-plan-1')
H=Q/'budget-controls-1'
BASE='339b257f3e9e5ac45ab1bd85d00e1a4be36b307f'
GIT='/tmp/eris-pointer-events-plan-1/worktree'
def bind(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,s):
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists(),p
    p.write_bytes(s if isinstance(s,bytes) else s.encode())
def js(p,v):write(p,json.dumps(v,indent=2)+'\n')
cpath=Q/'budget-contract-1/contract.json'
assert bind(cpath)['sha256']=='b80be48cb7284016220845ee8fe682e0096fff27df7dc79e289c6d72b8b4e12b'
c=json.loads(cpath.read_text())
rows=[]
for row,tokens in zip(c['exact_cases'],[3,3,5,3]):
    m=len(row['property'].encode());v=len(row['value'].encode())
    cost=10*m+12*v+6*tokens+8+130*(m+1)
    assert cost==row['fee']
    rows.append({'property':row['property'],'value':row['value'],'name_bytes':m,'value_bytes':v,'tokens':tokens,'fee':cost})
a=c['max_value'];cap=a['prefix']+a['repeat']*a['repeat_count']+a['suffix']
assert len(cap)==4096 and 10*5+12*4096+6*3+8+130*6==50008
assert 2*8+1+4*3+1==30
local=c['typed_parser']['local_name'];decoder=c['typed_parser']['decoder_cap_name']
assert len(local[4:-1])==257 and len(decoder[4:-1])==1025
raw='''//! Literal cuts frozen by the root contract before producer inspection or execution.
use super::{VariableSyntax, supports_declaration_with_budget, supports_matches_with_budget};
use crate::selectors::Error;

#[test]
fn supports_var_budget_exact_declarations_and_shared_allowance() {
    for (property, value, fee) in [
        ("width", "var(--x)", 952),
        ("width", r"v\61 r(--x)", 988),
        ("width", r#"var(--x,";")"#, 1012),
        ("pointer-events", "var(--x)", 2212),
    ] {
        let mut exact = fee;
        assert!(
            supports_declaration_with_budget(property, value, &mut exact),
            "{property}: {value}"
        );
        assert_eq!(exact, 0);
        let mut short = fee - 1;
        assert!(!supports_declaration_with_budget(property, value, &mut short));
        assert_eq!(short, 0);
    }
    let mut shared = 1903;
    assert!(supports_declaration_with_budget("width", "var(--x)", &mut shared));
    assert_eq!(shared, 951);
    assert!(!supports_declaration_with_budget("width", "var(--x)", &mut shared));
    assert_eq!(shared, 0);
}

#[test]
fn supports_var_budget_raw_value_cap_and_exact_admission() {
    let at_cap = format!("var(--x)/*{}*/", "x".repeat(4084));
    assert_eq!(at_cap.len(), 4096);
    let mut exact = 50008;
    assert!(supports_declaration_with_budget("width", &at_cap, &mut exact));
    assert_eq!(exact, 0);
    let mut short = 50007;
    assert!(!supports_declaration_with_budget("width", &at_cap, &mut short));
    assert_eq!(short, 0);
    let over_cap = format!("{at_cap} ");
    assert_eq!(over_cap.len(), 4097);
    for initial in [0, 1, 100_000] {
        let mut work = initial;
        assert!(!supports_declaration_with_budget("width", &over_cap, &mut work));
        assert_eq!(work, initial);
    }
}

#[test]
fn supports_var_budget_exhaustion_cannot_become_negated_or_short_circuit_success() {
    let mut funded = 100_000;
    assert!(supports_matches_with_budget(
        "not (width:var(foo))",
        false,
        &mut funded
    ));
    let mut late_short = 952;
    assert!(!supports_matches_with_budget(
        "not (width:var(foo))",
        false,
        &mut late_short
    ));
    assert_eq!(late_short, 0);
    let mut or_short = 952;
    assert!(!supports_matches_with_budget(
        "(display:block) or (width:var(--x))",
        false,
        &mut or_short
    ));
    assert_eq!(or_short, 0);
}

#[test]
fn supports_var_budget_typed_parser_cuts_and_legacy_option_wrapper() {
    let mut exact = 30;
    assert!(VariableSyntax::parse_checked("var(--x)", &mut exact).is_ok());
    assert_eq!(exact, 0);
    let mut short = 29;
    assert!(matches!(
        VariableSyntax::parse_checked("var(--x)", &mut short),
        Err(Error::Limit)
    ));
    assert_eq!(short, 0);
    let mut invalid = 30;
    assert!(matches!(
        VariableSyntax::parse_checked("var(foo)", &mut invalid),
        Err(Error::Invalid)
    ));
    assert_eq!(invalid, 0);

    let mut old_exact = 30;
    assert!(VariableSyntax::parse("var(--x)", &mut old_exact).is_some());
    assert_eq!(old_exact, 0);
    let mut old_invalid = 30;
    assert!(VariableSyntax::parse("var(foo)", &mut old_invalid).is_none());
    assert_eq!(old_invalid, 0);
    let mut old_short = 29;
    assert!(VariableSyntax::parse("var(--x)", &mut old_short).is_none());
    assert_eq!(old_short, 0);
}

#[test]
fn supports_var_budget_name_grammar_and_decoder_limits_remain_distinct() {
    const LOCAL_NAME: &str = "__LOCAL_NAME__";
    const DECODER_CAP_NAME: &str = "__DECODER_NAME__";
    assert_eq!(LOCAL_NAME.len(), 262);
    assert_eq!(DECODER_CAP_NAME.len(), 1030);
    assert_eq!(LOCAL_NAME.strip_prefix("var(").unwrap().strip_suffix(')').unwrap().len(), 257);
    assert_eq!(DECODER_CAP_NAME.strip_prefix("var(").unwrap().strip_suffix(')').unwrap().len(), 1025);

    let mut local = 100_000;
    assert!(matches!(
        VariableSyntax::parse_checked(LOCAL_NAME, &mut local),
        Err(Error::Invalid)
    ));
    let mut decoder = 100_000;
    assert!(matches!(
        VariableSyntax::parse_checked(DECODER_CAP_NAME, &mut decoder),
        Err(Error::Limit)
    ));
    let mut old_local = 100_000;
    assert!(VariableSyntax::parse(LOCAL_NAME, &mut old_local).is_none());
    let mut old_decoder = 100_000;
    assert!(VariableSyntax::parse(DECODER_CAP_NAME, &mut old_decoder).is_none());
}

#[test]
fn supports_var_budget_no_var_keyword_preserves_the_old_literal_cut() {
    let mut exact = 227;
    assert!(supports_declaration_with_budget("pointer-events", "none", &mut exact));
    assert_eq!(exact, 0);
    let mut short = 226;
    assert!(!supports_declaration_with_budget("pointer-events", "none", &mut short));
    assert_eq!(short, 0);
}
'''
# The Python source is itself raw for the CSS hexadecimal escape above.
# Replace its single legacy Python octal expansion if present before writing Rust.
# This is an authoring-language guard, never a changed CSS expectation.
assert '\\61' in raw, 'Rust CSS escape must be a literal backslash followed by 61'
raw=raw.replace('__LOCAL_NAME__',local).replace('__DECODER_NAME__',decoder)
name='src/css/supports_var_budget_tests.rs'
assert subprocess.run(['git','-C',GIT,'cat-file','-e',BASE+':'+name],capture_output=True).returncode!=0
write(H/'raw'/name,raw)
write(H/'before'/name,b'')
write(H/'diffs/forward'/f'{name}.patch',''.join(difflib.unified_diff([],raw.splitlines(True),fromfile='/dev/null',tofile='b/'+name)))
write(H/'diffs/inverse'/f'{name}.patch',''.join(difflib.unified_diff(raw.splitlines(True),[],fromfile='a/'+name,tofile='/dev/null')))
append='\n#[cfg(test)]\n#[path = "css/supports_var_budget_tests.rs"]\nmod supports_var_budget_tests;\n'
write(H/'registration/css-append.rs',append)
old_css=subprocess.check_output(['git','-C',GIT,'show',BASE+':src/css.rs'])
assert b'mod supports_var_budget_tests;' not in old_css
old_cuts=subprocess.check_output(['git','-C',GIT,'show',BASE+':src/css/pointer_events_budget_tests.rs'])
assert b'("none", 227)' in old_cuts
js(H/'registration.json',{'path':'src/css.rs','operation':'append','fragment':bind(H/'registration/css-append.rs'),'precondition':'No existing supports_var_budget_tests module. Preserve all production and existing test registration bytes; append only.','not_full_replacement':True,'published_before':{'base':BASE,'git_path':'src/css.rs','bytes':len(old_css),'sha256':hashlib.sha256(old_css).hexdigest()}})
checks={'contract':bind(cpath),'declaration_arithmetic':rows,'max_value':{'bytes':4096,'tokens':3,'fee':50008,'over_cap':4097},'typed_parser_fee':30,'name_bytes':[257,1025],'groups':6,'api_invocations_by_group':[10,5,3,6,4,2],'api_invocations_total':30,'literal_escape_guard':'The Rust raw literal contains one backslash followed by 61; no authoring-language octal byte.','exact_frozen_long_name_literals':True,'no_var_preservation':{'fee':227,'short':226,'published_control':{'base':BASE,'git_path':'src/css/pointer_events_budget_tests.rs','bytes':len(old_cuts),'sha256':hashlib.sha256(old_cuts).hexdigest()}},'qualification':'Private CSS API zero-work completion is tested independently of Runtime zero-author-step refusal. The new typed seam distinguishes Invalid and Limit; old Option wrapper keeps None for either. Root-supplied cuts remain fixed. No Q producer read or project execution.'}
js(H/'checks.json',checks)
js(H/'source-ready.json',{'schema':1,'status':'source-ready','author':'layout','published_api_base':BASE,'contract':bind(cpath),'files':[{'path':name,'operation':'add','before_absent_at_base':True,'before':bind(H/'before'/name),'raw':bind(H/'raw'/name),'forward':bind(H/'diffs/forward'/f'{name}.patch'),'inverse':bind(H/'diffs/inverse'/f'{name}.patch')}],'registration':bind(H/'registration.json'),'checks':bind(H/'checks.json'),'author_script':bind(H/'author.py'),'group_count':6,'api_invocations':30,'new_typed_interface':'VariableSyntax::parse_checked(&str, &mut usize) -> Result<Self, selectors::Error>; only root-selected interface used, no producer inspected.','project_execution':False,'project_imports':False,'producer_reads':False,'live_edits':False})
print(json.dumps(bind(H/'source-ready.json')))
