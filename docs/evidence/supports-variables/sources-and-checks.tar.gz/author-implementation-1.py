from pathlib import Path
import json,hashlib,difflib,re
Q=Path('/tmp/eris-supports-var-plan-1'); P=Path('/tmp/eris-pointer-events-plan-1'); W=P/'worktree'; H=Q/'implementation-1'
assert not H.exists()
H.mkdir()
inv=json.loads((P/'source-candidate-2.json').read_text()); entries={x['path']:x for x in inv['files']}
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(rel,data):
 p=H/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data.encode() if isinstance(data,str) else data);return bind(p)
def jp(rel,obj):return put(rel,json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
before={};raw={};edits=[]
for name in ['src/css.rs','src/cssom.rs']:
 b=(W/name).read_bytes();assert sha(b)==entries[name]['sha256'],name
 before[name]=b.decode();raw[name]=b.decode()
def replace(path,old,new,reason):
 assert raw[path].count(old)==1,(path,reason,raw[path].count(old))
 raw[path]=raw[path].replace(old,new,1);edits.append({'path':path,'old':old,'new':new,'reason':reason})
# Move the one existing alias table; preserve CSSOM normalization behavior.
start=before['src/cssom.rs'].index('fn alias(name: &str) -> &str {')
end=before['src/cssom.rs'].index('fn name(name: &str)',start)
alias=before['src/cssom.rs'][start:end]
replace('src/cssom.rs',alias,'','Move exact alias table to CSS for shared ordinary recognition.')
replace('src/cssom.rs','    let lower = alias(&lower);','    let lower = css::property_alias(&lower);','Call the moved identical alias table.')
shared=alias.replace('fn alias(', 'pub(crate) fn property_alias(',1)+'''// Ordinary names only: custom-property support queries remain a separate slice.
fn supported_ordinary_property(name: &str) -> bool {
    let name = property_alias(name);
    SUPPORTED_PROPERTIES.contains(&name) || shorthand_property_count(name).is_some()
}

'''
anchor='fn keyword_value_property(name: &str) -> Option<&\'static str> {'
replace('src/css.rs',anchor,shared+anchor,'Share the implemented ordinary roster and the existing aliases without expanding shorthands.')
# Detection scans tokens whose source-level scan envelope has already been paid.
old='''        evaluator.tokens(&tokens)?;
        let spacing_property = property.eq_ignore_ascii_case("border-spacing");'''
new='''        evaluator.tokens(&tokens)?;
        if tokens
            .iter()
            .any(|token| token.kind == Kind::Function && token.is_name("var"))
        {
            return evaluator.pending_value(property, value);
        }
        let spacing_property = property.eq_ignore_ascii_case("border-spacing");'''
replace('src/css.rs',old,new,'Route only actual var function tokens before final-value filters; preserve no-var debits.')
replace('src/css.rs','evaluator.declaration(media_trim(&clean), query)','evaluator.declaration(media_trim(&clean), query, &tokens)','Pass already-paid original tokens for implied declarations.')
replace('src/css.rs','self.declaration(clean, raw)?','self.declaration(clean, raw, inner)?','Pass already-paid original tokens for condition leaves.')
old='''    fn declaration(&mut self, source: &str, original: &str) -> Result<bool, ()> {
'''
new='''    fn declaration(
        &mut self,
        source: &str,
        original: &str,
        tokens: &[crate::selectors::Token<'_>],
    ) -> Result<bool, ()> {
'''
replace('src/css.rs',old,new,'Keep condition declaration fees while making original token boundaries available.')
old='''        if name.len() > 256 || value.len() > 4096 {
            return Ok(false);
        }
        let spacing_property = name.eq_ignore_ascii_case("border-spacing");'''
new='''        if name.len() > 256 || value.len() > 4096 {
            return Ok(false);
        }
        // The existing declaration scan envelope covers this borrowed-token
        // detection. No-var leaves retain their former work charges exactly.
        if tokens.iter().any(|token| {
            token.kind == crate::selectors::Kind::Function && token.is_name("var")
        }) {
            return self.pending_declaration(original);
        }
        let spacing_property = name.eq_ignore_ascii_case("border-spacing");'''
replace('src/css.rs',old,new,'Admit pending values before legacy raw-character and final grammar filters; keep local false caps.')
helpers='''    fn pending_declaration(&mut self, original: &str) -> Result<bool, ()> {
        use crate::selectors::{Kind, trim};
        // Preparation tokens are dropped before the variable parser allocates
        // its own token/close/reference storage. All spans still borrow input.
        let (name, value) = {
            let tokens = crate::selectors::tokens(original, &mut self.work).map_err(|_| ())?;
            self.spend(tokens.len() + 1)?;
            let Some(colon) = tokens.iter().position(|token| token.kind == Kind::Delim(':')) else {
                return Ok(false);
            };
            let names = trim(&tokens[..colon]);
            if names.len() != 1 || names[0].kind != Kind::Ident {
                return Ok(false);
            }
            let Some((name, consumed)) = css_identifier(names[0].raw) else {
                return Ok(false);
            };
            if consumed != names[0].raw.len() || name.len() > 256 {
                return Ok(false);
            }
            let mut end = original.len();
            let mut significant = tokens[colon + 1..]
                .iter()
                .rev()
                .filter(|token| token.kind != Kind::Whitespace);
            if let (Some(important), Some(bang)) = (significant.next(), significant.next())
                && important.kind == Kind::Ident
                && important.is_name("important")
                && bang.kind == Kind::Delim('!')
            {
                end = bang.start;
            }
            (name, &original[tokens[colon].end..end])
        };
        self.pending_value(&name, value)
    }
    fn pending_value(&mut self, name: &str, value: &str) -> Result<bool, ()> {
        use crate::selectors::{Error, Kind};
        // The fixed match arms are 29 shorthands plus 13 aliases. Charge each
        // possible name comparison and normalization before name allocation.
        let names = SUPPORTED_PROPERTIES.len() + 29 + 13;
        self.spend(1 + names * (name.len() + 1))?;
        if !supported_ordinary_property(&name.to_ascii_lowercase()) {
            return Ok(false);
        }
        let syntax = match VariableSyntax::parse_checked(value, &mut self.work) {
            Ok(syntax) => syntax,
            Err(Error::Limit) => {
                self.exhausted = true;
                return Err(());
            }
            Err(_) => return Ok(false),
        };
        self.spend(syntax.tokens.len() + 1)?;
        // CSS Syntax declaration rule: a top-level curly block may be the
        // whole value, but cannot be mixed with another component. Blocks
        // nested inside var fallbacks retain the shared variable grammar.
        let mut depth = 0usize;
        let mut components = 0usize;
        let mut curly = false;
        for token in &syntax.tokens {
            if token.raw.contains('\\0') {
                return Ok(false);
            }
            if depth == 0 && token.kind != Kind::Whitespace {
                components += 1;
                curly |= token.kind == Kind::Open('{');
            }
            if token.open().is_some() {
                depth += 1;
            } else if matches!(token.kind, Kind::Close(_)) {
                depth -= 1; // parse_checked already matched every delimiter.
            }
        }
        Ok(!curly || components == 1)
    }
'''
anchor='    fn declaration(\n'
replace('src/css.rs',anchor,helpers+anchor,'New var-only preparation, name debit, typed grammar admission and query-only structure rule.')
# Preserve every existing Option caller by keeping the original public-private seam.
start=raw['src/css.rs'].index("    fn parse(source: &'a str, work: &mut usize) -> Option<Self> {",raw['src/css.rs'].index("impl<'a> VariableSyntax<'a>"))
end=raw['src/css.rs'].index('    fn substitute(',start)
old=raw['src/css.rs'][start:end]
body=old.replace("    fn parse(source: &'a str, work: &mut usize) -> Option<Self> {\n        use crate::selectors::Kind;", "    fn parse_checked(\n        source: &'a str,\n        work: &mut usize,\n    ) -> Result<Self, crate::selectors::Error> {\n        use crate::selectors::{Error, Kind};",1)
body=body.replace('return None;', 'return Err(Error::Invalid);')
body=body.replace('if source.len() > MAX_VARIABLE_VALUE {\n            return Err(Error::Invalid);','if source.len() > MAX_VARIABLE_VALUE {\n            return Err(Error::Limit);',1)
body=body.replace('if stack.len() >= MAX_VARIABLE_DEPTH {\n                    return Err(Error::Invalid);','if stack.len() >= MAX_VARIABLE_DEPTH {\n                    return Err(Error::Limit);',1)
body=body.replace('crate::selectors::tokens(source, work).ok()?','crate::selectors::tokens(source, work)?',1)
body=body.replace('crate::selectors::spend(work, tokens.len().saturating_mul(4) + 1).ok()?','crate::selectors::spend(work, tokens.len().saturating_mul(4) + 1)?',1)
body=body.replace('stack.pop()?','stack.pop().ok_or(Error::Invalid)?',1)
body=body.replace('tokens.get(at)?','tokens.get(at).ok_or(Error::Invalid)?',1)
body=body.replace('css_identifier(name_token.raw)?','css_identifier(name_token.raw).ok_or(Error::Invalid)?',1)
old_name='''                || name == "--"
                || name.len() > 256
            {
                return Err(Error::Invalid);
            }'''
new_name='''                || name == "--"
            {
                return Err(Error::Invalid);
            }
            if name.len() > 256 {
                return Err(Error::Limit);
            }'''
assert old_name in body;body=body.replace(old_name,new_name,1)
body=body.replace('        Some(Self { tokens, references })','        Ok(Self { tokens, references })',1)
wrapper='''    fn parse(source: &'a str, work: &mut usize) -> Option<Self> {
        Self::parse_checked(source, work).ok()
    }
'''
replace('src/css.rs',old,wrapper+body,'Typed query refusal; original Option wrapper keeps all prior callers and debit/grammar behavior.')
files=[]
for name in before:
 b=before[name];r=raw[name]
 files.append({'path':name,'before':put('before/'+name,b),'raw':put('raw/'+name,r),
 'forward':put('diffs/forward/'+name+'.patch',''.join(difflib.unified_diff(b.splitlines(True),r.splitlines(True),fromfile='a/'+name,tofile='b/'+name))),
 'inverse':put('diffs/inverse/'+name+'.patch',''.join(difflib.unified_diff(r.splitlines(True),b.splitlines(True),fromfile='b/'+name,tofile='a/'+name)))})
recovered=raw.copy()
for e in reversed(edits):
 assert recovered[e['path']].count(e['new'])==1 if e['new'] else True
 if e['new']:recovered[e['path']]=recovered[e['path']].replace(e['new'],e['old'],1)
 else:
  # Deleted alias precedes fn name exactly in the original.
  recovered[e['path']]=recovered[e['path']].replace('fn name(name: &str)',e['old']+'fn name(name: &str)',1)
assert recovered==before
jp('edits.json',edits);jp('files.json',files)
jp('draft-checks.json',{'status':'unsealed source-only draft','inverse_all_exact':True,'origin':bind(P/'source-candidate-2.json'),'design':bind(Q/'design-1.json'),'project_execution':False,'live_edits':False})
print(json.dumps({'paths':len(files),'chunks':len(edits),'raw':[f['raw'] for f in files]},indent=2))
