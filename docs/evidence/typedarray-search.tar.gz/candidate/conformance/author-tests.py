from pathlib import Path
W=Path('/tmp/eris-typedarray-search-1/worktree')
s=(W/'tools/test_test262_typedarray_views.py').read_text()
s=s.replace('view/string','relative-index/search').replace('typedarray-views','typedarray-search').replace('TypedArrayViewTests','TypedArraySearchTests')
a=s.index('PAIRS = '); b=s.index('\n\ndef proof_reader',a)
s=s[:a]+'''PAIRS = ['at-relative', 'includes-same-value-zero', 'index-of-strict',
         'last-index-of-direction', 'resize-fresh-bounds', 'metadata-saved-identity']
DIRECTORIES = {'TypedArray/prototype/at': 14, 'TypedArray/prototype/at/BigInt': 1,
               'TypedArray/prototype/includes': 31, 'TypedArray/prototype/includes/BigInt': 14,
               'TypedArray/prototype/indexOf': 28, 'TypedArray/prototype/indexOf/BigInt': 15,
               'TypedArray/prototype/lastIndexOf': 28, 'TypedArray/prototype/lastIndexOf/BigInt': 14}
FEATURES = {'TypedArray', 'ArrayBuffer', 'TypedArray.prototype.at',
            'relative-indexing-method', 'Array.prototype.includes', 'Symbol',
            'Reflect.construct', 'arrow-function', 'resizable-arraybuffer',
            'align-detached-buffer-semantics-with-web-reality'}
'''+s[b:]
s=s.replace('(103, 206, 113, [])','(145, 290, 154, [])')
s=s.replace("        self.assertEqual(manifest['directories']['TypedArray/prototype'], ['toString.js'])\n",'')
s=s.replace('[103, 103]','[145, 145]').replace("len(manifest['inventory_proof']['files']), 12","len(manifest['inventory_proof']['files']), 11")
a=s.index("        self.assertEqual(manifest['inventory_proof']['complete_sources']"); b=s.index("        self.assertEqual({p[8:]",a)
s=s[:a]+s[b:]
s=s.replace("'propertyHelper.js', 'compareArray.js',","'propertyHelper.js',")
s=s.replace('reasons.count(None), 110','reasons.count(None), 158').replace("BigInt'), 74","BigInt'), 88").replace("source check)'), 10","source check)'), 18").replace("TypedArray views policy excludes the complete resizableArrayBufferUtils helper'), 12","TypedArray search policy excludes the complete resizableArrayBufferUtils helper'), 26")
s=s.replace('is None for c in cases), 122','is None for c in cases), 184').replace("in c['file'] for c in cases), 74","in c['file'] for c in cases), 88")
s=s.replace("len(set(runner.PROFILES) - {'typedarray-search'}), 48","len(runner.PROFILES), 49")
s=s.replace("        self.assertEqual(len(runner.PROFILES), 49)\n", "        self.assertEqual(len(runner.PROFILES), 49)\n        for name, features in runner.PROFILE_FEATURES.items():\n            if name != PROFILE:\n                self.assertNotIn('TypedArray.prototype.at', features, name)\n                self.assertNotIn('relative-indexing-method', features, name)\n")
s=s.replace('2839a99c14e8c58d8356ed2249ca4bf0e2f2ea9568e05c636d716a9470eb3d2e','8113c4c13f318cd34ac17bb5d9990f62fec801cc8e021f678f3b2b85030dfc38')
s=s.replace("'test/built-ins/TypedArray/prototype/join/length.js'", "'test/built-ins/TypedArray/prototype/at/length.js'")
s=s.replace("'test/built-ins/TypedArray/prototype/subarray/BigInt/detached-buffer.js'", "'test/built-ins/TypedArray/prototype/includes/BigInt/detached-buffer.js'")
s=s.replace("'test/built-ins/TypedArray/prototype/toString.js'", "'test/built-ins/TypedArray/prototype/lastIndexOf/length.js'")
a=s.index('    def test_selected_sibling_does_not_permit_missing_unselected_proof_entries')
b=s.index('    def test_exact_offline_import_and_auxiliary_corruption_rejection',a)
s=s[:a]+'''    def test_full_roster_requires_unselected_ancestors_and_excluded_bigint_entries(self):
        ancestor = 'trees/37185873f6a6ea631208a82eb48c6c007216dcdd'
        recursive = 'trees/c1f0eae9a0485de57814aeb7e8f45fc0f87f420a?recursive=1'
        for route, name in [(ancestor, 'constructor.js'), (recursive, 'BigInt')]:
            with self.subTest(route=route), self.assertRaises(ValueError):
                importer.profile_tree_inventory(PROFILE, proof_reader(route, lambda d:
                    d['tree'].__setitem__(slice(None), [r for r in d['tree'] if r['path'] != name])))
        _, files, cases, _, _ = runner.load_corpus(CORPUS, PROFILE)
        key = 'test/built-ins/TypedArray/prototype/at/BigInt/return-abrupt-from-this-out-of-bounds.js'
        self.assertIn(key, files)
        retained = [c for c in cases if c['file'] == key]
        self.assertEqual(len(retained), 2)
        self.assertTrue(all(runner.unsupported_reason(c, FEATURES, PROFILE) ==
                            'unimplemented declared features: BigInt' for c in retained))

'''+s[b:]
(W/'tools/test_test262_typedarray_search.py').write_text(s)
