# TypedArray search preparation

This source-only profile adds the complete `at`, `includes`, `indexOf` and `lastIndexOf` Test262 subtrees at revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`. All 145 original bodies are retained in both modes (290 observations), along with seven unchanged harness files, two legal files and eleven complete root-linked Git proof documents. Selection does not depend on implementation outcomes.

The frozen policy schedules 158 modes. It retains 88 BigInt modes as feature exclusions, 26 modes excluded because the complete `resizableArrayBufferUtils.js` helper requires unsupported dependencies, and 18 remaining host-hook modes. Exclusions apply before execution and remain explicit raw rows. The actual pinned `at` feature tag is `TypedArray.prototype.at`; this and `relative-indexing-method` are admitted only in the new profile. Existing profiles, feature sets, defaults and source bodies are unchanged.

Six independently frozen positive/wrong pairs add 24 feature control observations to the existing 32 common controls. They cover relative indexing, SameValueZero versus strict equality, reverse-search omission semantics, resize freshness, and saved metadata/identity. Every wrong partner requires successful same-mode positive evidence and a runtime intrinsic Error, with callable/authentic feature prerequisites preceding the wrong assertion. Frozen controls: `8113c4c13f318cd34ac17bb5d9990f62fec801cc8e021f678f3b2b85030dfc38`. Layout has supplied a source/oracle clear message; no execution is claimed by that review.

The existing recursive inventory verifier is reused unchanged. Registration increases the profile count from 48 to 49. Seventeen historical tests exclude only this added profile so their original counts and hashes remain intact. Nine new mocked protocol groups cover complete inventory, source/control integrity, healthy positive partners, exact Error identity, terminal refusals, policy hashing, no baseline on resource stops, and proof/blob corruption.

## Root execution handoff

From `/tmp/eris-typedarray-search-1/worktree`, first inspect `source-ready.json`, `preservation.json`, `input-proof.json`, the complete source diffs and `offline_import.py` here. The independently reconstructed offline input roster has 165 exact items. Authoring used only inert Python source/data operations; no project importer, parser, adapter, compiler or test has been executed by the author.

Run the strict offline handoff once into a fresh target:

```sh
python3 /tmp/eris-typedarray-search-1/conformance/offline_import.py
python3 -m unittest discover -s tools -p 'test_test262*.py'
```

The ordinary network importer command for the same pinned population is:

```sh
python3 tools/import_test262.py --profile typedarray-search
```

Use one import route, preserving any first failure rather than replacing its records. The offline helper refuses existing output and supplies only retained, authenticated bytes; it never falls back to network. The ordinary importer should likewise be run only after source review.

For the published-adapter observation, supply the retained predecessor binary explicitly (the shell variable below is a placeholder for root's actual immutable path):

```sh
python3 tools/test262_conformance.py --profile typedarray-search --binary "$SEARCH_BEFORE_ADAPTER" --output /tmp/eris-typedarray-search-1/upstream-before.json --jobs 2
```

A missing-method baseline is expected to have unhealthy feature controls. Preserve its full report and exit status; do not create a current baseline or weaken health policy. Candidate outcomes are not known here. Resource, timeout, adapter and harness errors remain unhealthy, and a report with those statuses cannot become a baseline even when controls pass.

The independent control oracles follow the current [TypedArray algorithms](https://tc39.es/ecma262/multipage/indexed-collections.html): initial live receiver validation, captured length, from-index coercion order, fresh indexed access after resize, uncoerced search values, and omitted versus explicit `undefined` in reverse search. This is a bounded Number TypedArray slice, not full Test262 or full JavaScript conformance.
