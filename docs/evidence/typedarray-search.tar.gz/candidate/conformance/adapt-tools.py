"""Source-only profile additions; never imports either project module."""
from pathlib import Path
import json,shutil,hashlib,difflib
R=Path('/tmp/eris-typedarray-search-1');W=R/'worktree';D=R/'conformance';original=D/'original';original.mkdir(exist_ok=True)
paths=[W/'tools/import_test262.py',W/'tools/test262_conformance.py']+sorted((W/'tools').glob('test_test262*.py'))
for path in paths:
 target=original/path.name
 if not target.exists():shutil.copyfile(path,target)
inv=json.loads((D/'discovery/inventory.json').read_text());dirs=inv['directories'];helpers=inv['helpers'];subtrees={'TypedArray/prototype/at':'c1f0eae9a0485de57814aeb7e8f45fc0f87f420a','TypedArray/prototype/includes':'16d1253435098c7ca5278234db6baa1e1675f3dc','TypedArray/prototype/indexOf':'9be33464f6f7515879f69dbf73cb8d397d9dca42','TypedArray/prototype/lastIndexOf':'9cb18b7262c326fd41c564ffec8551492344b7f0'}
p=W/'tools/import_test262.py';s=p.read_text()
s=s.replace('TYPEDARRAY_VIEW_DIRECTORIES =', 'TYPEDARRAY_SEARCH_DIRECTORIES = '+repr(dirs)+'\nTYPEDARRAY_SEARCH_HELPERS = '+repr(set(helpers))+'\nTYPEDARRAY_VIEW_DIRECTORIES =',1)
s=s.replace("ITERATION_SUBTREES = {", "ITERATION_SUBTREES = {\n    'typedarray-search': "+repr(subtrees)+',',1)
s=s.replace("ITERATION_HELPERS = {", "ITERATION_HELPERS = {\n    'typedarray-search': TYPEDARRAY_SEARCH_HELPERS,",1)
s=s.replace("TREE_PROFILES = {'typedarray-views'", "TREE_PROFILES = {'typedarray-search', 'typedarray-views'",1)
s=s.replace("PROFILES = {'typedarray-views':", "PROFILES = {'typedarray-search': TYPEDARRAY_SEARCH_DIRECTORIES, 'typedarray-views':",1)
s=s.replace("PROFILE_ROOTS = {'typedarray-views':", "PROFILE_ROOTS = {'typedarray-search': 'test/built-ins', 'typedarray-views':",1)
s=s.replace("    if profile == 'typedarray-views' and harness != TYPEDARRAY_VIEW_HELPERS:", "    if profile == 'typedarray-search' and harness != TYPEDARRAY_SEARCH_HELPERS:\n        raise ValueError('TypedArray search requested harness differs from the frozen seven helpers')\n    if profile == 'typedarray-views' and harness != TYPEDARRAY_VIEW_HELPERS:",1)
s=s.replace("        'typedarray-views': 'all 102", "        'typedarray-search': 'all 145 original .js files in four complete TypedArray prototype at/includes/indexOf/lastIndexOf trees, including all BigInt originals; full root-linked Git proof; no implementation',\n        'typedarray-views': 'all 102",1)
p.write_text(s)
p=W/'tools/test262_conformance.py';s=p.read_text()
s=s.replace('TYPEDARRAY_VIEW_FEATURES =', "# Both at feature spellings remain local to these four complete TypedArray trees.\nTYPEDARRAY_SEARCH_FEATURES = {'TypedArray', 'ArrayBuffer', 'TypedArray.prototype.at',\n                             'relative-indexing-method', 'Array.prototype.includes', 'Symbol',\n                             'Reflect.construct', 'arrow-function', 'resizable-arraybuffer',\n                             'align-detached-buffer-semantics-with-web-reality'}\nTYPEDARRAY_VIEW_FEATURES =",1)
s=s.replace("PROFILE_FEATURES = {'typedarray-views':", "PROFILE_FEATURES = {'typedarray-search': TYPEDARRAY_SEARCH_FEATURES, 'typedarray-views':",1)
s=s.replace("if profile in {'typedarray-views', 'reflect-properties'", "if profile in {'typedarray-search', 'typedarray-views', 'reflect-properties'")
s=s.replace("    sources = [case['source']] +", "    if (profile == 'typedarray-search'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray search policy excludes the complete resizableArrayBufferUtils helper'\n    sources = [case['source']] +",1)
start=s.index('def typedarray_view_preflight_variants():');end=s.index('\ndef reflect_property_preflight_variants():',start)
helper=s[start:end].replace('typedarray_view_preflight_variants','typedarray_search_preflight_variants').replace('typedarray-views','typedarray-search').replace('TypedArray views','TypedArray search').replace('2839a99c14e8c58d8356ed2249ca4bf0e2f2ea9568e05c636d716a9470eb3d2e','8113c4c13f318cd34ac17bb5d9990f62fec801cc8e021f678f3b2b85030dfc38')
s=s[:start]+helper+'\n'+s[start:]
s=s.replace("    if profile == 'typedarray-views':\n        variants += typedarray_view_preflight_variants()", "    if profile == 'typedarray-search':\n        variants += typedarray_search_preflight_variants()\n    if profile == 'typedarray-views':\n        variants += typedarray_view_preflight_variants()",1)
s=s.replace("            if ((profile == 'typedarray-views'", "            if ((profile == 'typedarray-search' and name.startswith('typedarray-search-'))\n                    or (profile == 'typedarray-views'",1)
start=s.index("    if profile == 'typedarray-views':\n        # Preserve",s.index('def harness_preflight'))
end=s.index("    if profile == 'reflect-properties':",start)
block=s[start:end].replace('typedarray-views','typedarray-search')
s=s[:start]+block+s[start:]
p.write_text(s)
changed=[]
for p in sorted((W/'tools').glob('test_test262*.py')):
 before=p.read_text();lines=[]
 for line in before.splitlines(True):
  if "'typedarray-views'" in line and any(x in line for x in ['excluded=', 'if profile in', 'if name in', 'set(runner.PROFILES)']):
   line=line.replace("'typedarray-views'", "'typedarray-search', 'typedarray-views'")
  if 'self.assertEqual(len(runner.PROFILES), 48)' in line:
   line=line.replace('len(runner.PROFILES)', "len(set(runner.PROFILES) - {'typedarray-search'})")
  lines.append(line)
 after=''.join(lines)
 if after!=before:p.write_text(after);changed.append(str(p.relative_to(W)))
for p in [W/'tools/import_test262.py',W/'tools/test262_conformance.py']+[W/n for n in changed]:
 old=(original/p.name).read_text();new=p.read_text();(D/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='before/'+p.name,tofile=p.name)))
(D/'changed-existing-paths.json').write_text(json.dumps(['tools/import_test262.py','tools/test262_conformance.py']+changed,indent=2)+'\n')
print(json.dumps(dict(changed_existing=2+len(changed),test_registration_exclusions=len(changed))))
