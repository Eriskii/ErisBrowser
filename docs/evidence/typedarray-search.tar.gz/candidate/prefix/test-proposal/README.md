# Proposed dependency endpoint migrations

These are source-only candidate copies, not live edits or measured endpoints.
Root owns integration/formatting/execution. All old source copies and original
54 predecessor rows remain intact. Layout owns the new prefix_tests.rs.

Existing index/tests.rs retains all67 semantic rows and the same success,
one-short, zero-storage, key identity and cleanup assertions. Changed fee
columns follow three rules: empty/>25 length8 unchanged; rejected first unit
16 total; allowed first unit old+8. The latter rule also applies to each
intermediate parser/formatter allocation refusal. Numeric bits and all heap
columns remain unchanged. A short leading surrogate/fullwidth digit becomes
16; an ASCII digit followed by a surrogate becomes24.

The existing SetKey structural tests already independently measure just their
unchanged classifier/record prefix and retain literal token8/reuse4. Their
source needs no edit. The complete operation endpoint suite has54 retained
predecessor rows. Its old immutable-token formula removes1 or3 classifier
invocations, leaving exactly one full classifier for every row. Keep those
old observations unchanged and add the new classifier delta once:

| Key | Old work/heap | New work/heap |
| --- | ---: | ---: |
| 1.0 | 266/1062 | 274/1062 |
| +1 | 235/1060 | 16/0 |
| 1000000000000000000000 | 780/1100 | 788/1100 |
| 0.0000001 | 322/1074 | 330/1074 |
| entries | 88/0 | 16/0 |
| abcdefghijklmnopqrstuvwxyz | 8/0 | 8/0 |

Search metadata independently grew the shared prototype from13 to17 entries.
Only absent-own scenario0 visits that owner. Reflect's existing table tariff
therefore adds4*(1+key_length) once; splice adds4*(1+floor(key_length/8)) once.
Ordinary assignment has no charged owner-size dependency at that point. The
existing writable/readonly own descriptors stop before that owner. No registry
shape, Record count, descriptor shape, callback or body path changes in these
fixtures; root's ordinary snapshot optimization is not called by these Sets.

The proposed expected() preserves BEFORE byte-for-byte, derives old post-token
work/heap first, then adds the one classifier delta and the explicit shared
owner growth row. set-key-54-rows.json lists every resulting prediction. Both
old exact and one-short tests consume that same independently derived expected
pair. +1 legitimately loses its classifier scratch allocations because no
parser or formatter runs. A full route that consequently allocates zero bytes
retains its existing rule to omit an impossible heap-short refusal.

No test input, method result, exception identity, stored property, old captured
observation, token fee, quota or production reset changes. Actual root runs
must confirm the proposal; differences need investigation rather than copying
observed counters into expected values.
