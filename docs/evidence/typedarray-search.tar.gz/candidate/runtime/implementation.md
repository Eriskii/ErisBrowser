# TypedArray search source hold

Four Number TypedArray methods use the existing native guard, authentic copied
Record, scalar codecs and bounded backing store. This draft changes only the
parent module/dispatch and adds search.rs. It adds no State, registry entries,
prototype walk, owned output, buffer write or quota change. Root owns metadata
and independent tests; no compiler, formatter, engine or test was run here.

The current ECMA algorithms are the four indexed-collection entries:
https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.at
https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.includes
https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.indexof
https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.lastindexof

All four validate first and capture the length. at converts even for an empty
view, resolves the relative index against that length, then reads through a
fresh live witness. Empty searches return before fromIndex conversion.
lastIndexOf distinguishes omission from explicit undefined. includes compares
with SameValueZero; the two index searches compare strictly and skip positions
that became absent. No method converts searchElement. A copied Record remains
valid across recursive constructor calls reallocating the records vector.

The optional element helper returns absence for a detached, out-of-bounds or
shortened view before accessing bytes. There is no callback between its live
witness and read; presence is therefore the required integer-indexed
HasProperty decision without a second witness or any prototype lookup. Growth
does not extend the captured loop. The at return can preserve negative zero.

## New-site work and storage

Let X be the existing splice_number coercion work, w the element width and
C the unchanged codec tariff (48+2w). Primitive numeric/undefined X is zero;
string or authored conversion retains all its existing work/storage charges.
Each body helper accepts a Record already authenticated by native dispatch.

| Path | Work, excluding caller/native dispatch |
| --- | ---: |
| Initial search on a valid empty view | 21 |
| Nonempty search prefix, omitted lastIndexOf fromIndex | 35 |
| Other nonempty search prefix | 39+X |
| Each reached present search position | 46+w+C |
| Each reached absent search position | 33 |
| at, captured out-of-range index | 35+X |
| at, captured-valid but now absent index | 52+X |
| at, present index | 65+w+C+X |

The shared live check is existing12 plus metadata tick1. Optional-read setup
adds4; a present read adds existing offset4, buffer tick1 plus8+w, and codec C.
Every reached search position prepays16 for matching/comparison, direction,
advance and return handling. Entry8 pays length/empty/control setup; search6
pays flags and argument selection; search8 pays clamp/start state. at pays4
argument selection and6 relative/range/result handling. Normalization4 is
admitted after coercion callbacks and before integer_or_infinity. No operation
retunes an existing helper's tariff.

Backing storage is bounded by MAX_HEAP=8MiB, so captured lengths and every loop
index are below usize::MAX and exactly representable as binary64. Infinity is
rejected/clamped before integer casts. No new owned heap allocation occurs in
the search bodies themselves. Existing coercion and native-call name-copy
allocation remain; whole calls are not advertised as allocation-free. The
existing native preflight admits4+name.len work and32+name.len bytes, and native
dispatch pays its tick and actual record binary-search work separately.

## Integration

Root's metadata supplies TypedArray.at/includes/indexOf/lastIndexOf. Existing
machine dispatch already routes any TypedArray native through the preserved
guard/preflight. search.rs has no test-module declaration yet; root may add
`#[cfg(test)] mod tests;` after Layout's independent test source is held.
Public exposure, endpoint observations and bootstrap measurements remain
pending root execution; these are source-derived contracts only.
