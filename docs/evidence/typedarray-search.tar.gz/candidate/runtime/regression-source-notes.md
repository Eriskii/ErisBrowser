# Retained prior-pass resource diagnosis

Source inspection only. No engine, compiler, test or altered quota run by this
reviewer, and no production change. Root's prior-pass-1.json/log records the
actual instruction-limit failure; metadata's measured2293 remainder is a
bootstrap observation, not the authored execution allowance (still100000).

The unchanged DefineOwnProperty/key-is-not-numeric-index.js explicitly selects
the passthrough factory. testTypedArray.js therefore invokes ten Number-kind
bodies, not the default80 factory/kind combinations. Each body checks foo and
bar through verifyNotEnumerable; propertyHelper's isEnumerable performs a
complete for-in traversal because neither own name is enumerable. Those two
walks revisit the enlarged shared prototype. This explains why metadata growth
adds work even though this body never calls any of the four new methods; it
does not locate the exact terminal operation without root measurements.

Reflect.defineProperty calls define_property_key, which probes the authentic
TypedArray once before direct ordinary descriptor validation. That ordinary
fallback uses own_property_key and does not reclassify the same key. The failed
foo assignment already uses the per-Set immutable token. Its repeated probes
reuse classification; no new obvious same-operation duplicate remains there.
Descriptor reads, hasOwnProperty, Get, Delete and typed-array own-string/for-in
descriptor paths still independently classify their actual immutable key.
These are different authored operations, so caching a live descriptor across
them would be invalid.

The preferred first candidate is Layout's ordinary own-key snapshot fast path.
For owners without virtual keys, proving every retained string starts outside
ASCII0..9 suffices to retain creation order directly. That removes the OwnKey
staging vector, per-name Array-index parsing, sorting/order check and consume
pass, while keeping later live descriptor and visited-name decisions. Empty
strings and non-ASCII/unpaired first units are safe; any digit prefix can fall
back conservatively. Array and primitive/boxed String virtual keys must retain
the original path, as must Window/Document's existing dedicated behavior.

## Inert alternative, not selected or implemented

CanonicalNumericIndexString accepts -0 or a Number's exact decimal ToString.
Consequently any nonempty canonical key starts with0..9, '-', 'N' or 'I'. A
paid first-unit filter after the existing empty/>25 length guard could reject
all other starts without the current ASCII scan, failed special/integer paths
and later alphabet scan. This is a necessary-prefix test, never acceptance of
a whole numeric spelling. All allowed prefixes would retain the complete old
classifier and every old tariff, plus the new prefix check.

Provisional fee4 was rejected during source reasoning; use8 for one load, two
range comparisons, three literal comparisons and branch/control. foo and bar
currently pay8+12+4+6+8+16+4+10=68; the inert proposal would pay16, removing52
actual logical work per standalone classification. Empty/overlong keys remain8;
numeric/special-candidate keys become old+8. This would require explicit
literal boundary migrations and full numeric/inherited-key regression checks,
and could worsen numeric-heavy resource results. No whole-case saving or
restoration is predicted. Root chose the snapshot candidate first.

Primary definitions read for the prefix proof:
https://tc39.es/ecma262/multipage/abstract-operations.html#sec-canonicalnumericindexstring
https://tc39.es/ecma262/multipage/ecmascript-data-types-and-values.html#sec-numeric-types-number-tostring

The existing temporary Native name copy is real allocation/work. Eliminating
it would require a wider explicit-receiver dispatch change; simply reducing
its fee would be wrong. It is not recommended as this bounded prerequisite.
