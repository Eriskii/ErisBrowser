from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, tarfile

R = Path(__file__).resolve().parent
W = R / 'worktree'
S = Path('/tmp/eris-typedarray-views-1')

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()

adapter = json.loads((R / 'candidate-adapter-1.json').read_bytes())
comparison = json.loads((R / 'comparison.json').read_bytes())
assert comparison['status'] == 'clear' and not comparison['errors']
assert comparison['summary']['prior_pass_losses'] == 0
assert comparison['summary']['all_previous_case_rows'] == comparison['summary']['all_previous_exact_case_rows'] == 17842
assert comparison['summary']['all_previous_control_rows'] == comparison['summary']['all_previous_exact_control_rows'] == 4072
for row in comparison['inputs']:
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
assert sha((R / adapter['binary']).read_bytes()) == adapter['sha256']
sources = json.loads((R / adapter['source_binding']).read_bytes())
assert sha((R / adapter['source_binding']).read_bytes()) == adapter['source_binding_sha256']
changed = [p for p, h in sources['source_sha256'].items() if sha((W / p).read_bytes()) != h]
assert changed == ['tests/typedarray_search.rs'], changed
lint = json.loads((R / 'test-lint/binding.json').read_bytes())
assert lint['before'] == sources['source_sha256'][changed[0]]
assert lint['after'] == sha((W / changed[0]).read_bytes())
checks = {'full-native-1': 2310, 'script-msrv-1': 1305, 'script-198-1': 1305,
          'page-final-1': 1, 'clippy-msrv-2': None, 'clippy-198-1': None,
          'format-check-1': None, 'protocols-1': None, 'regressions-1': None}
for name, count in checks.items():
    receipt = json.loads((R / 'validation' / (name + '.json')).read_bytes())
    assert receipt['exit'] == 0, name
    log = (R / 'validation' / receipt['log']).read_bytes()
    assert sha(log) == receipt['sha256']
    if count is not None:
        assert sum(map(int, re.findall(rb'test result: ok\. (\d+) passed;', log))) == count
report = json.loads((R / 'upstream-1.json').read_bytes())
assert report['counts'] == dict(passed=78, resource=78, failed=2, unsupported=132)
assert report['harness_preflight_passed'] and len(report['harness_preflight']) == 56
assert report['binary_sha256'] == adapter['sha256']
for origin, public in [('upstream-before.json', 'test262-typedarray-search-before.json'),
                       ('upstream-1.json', 'test262-typedarray-search-after.json')]:
    assert (R / origin).read_bytes() == (W / 'tests/conformance' / public).read_bytes()

records = {}
def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in records, name
    records[name] = path.read_bytes()

# Retain source-only decisions, raw failed/successful runs and full reports.
# Next-increment work, compiled executables and target directories are excluded.
for p in sorted(R.iterdir()):
    if p.is_file() and p.suffix in {'.json', '.py'}:
        add(p, 'candidate/' + p.name)
for directory in ['validation', 'runtime', 'metadata', 'prefix', 'ordinary-snapshot',
                  'conformance', 'regressions-candidate-1', 'test-lint']:
    for p in sorted((R / directory).rglob('*')):
        if p.is_file():
            add(p, 'candidate/' + str(p.relative_to(R)))
for relative in ['foundation-final.json', 'upstream-final-2.json', 'local-final.json',
                 'final-adapter.json', 'compiled-source-9.json']:
    add(S / relative, 'prior/' + relative)
for p in sorted((S / 'regressions-final').glob('*.json')):
    add(p, 'prior/regressions-final/' + p.name)
for p in sorted(sources['source_sha256']):
    add(W / p, 'published-source/' + p)
# Bind the exact integrated tools, imported originals, docs and controls too.
paths = subprocess.check_output(['git', 'ls-files', '--modified', '--others',
                                 '--exclude-standard'], cwd=W).decode().splitlines()
for name in sorted(set(paths)):
    if name.startswith('docs/evidence/') or name in sources['source_sha256']:
        continue
    add(W / name, 'published-source/' + name)
index = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(records.items())}
records['MANIFEST.json'] = encoded(index)
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w') as archive:
    for name, data in sorted(records.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        item.mode = 0o644
        item.mtime = 0
        archive.addfile(item, io.BytesIO(data))
out = io.BytesIO()
with gzip.GzipFile(fileobj=out, mode='wb', mtime=0, filename='') as stream:
    stream.write(raw.getvalue())
payload = out.getvalue()
archive_path = W / 'docs/evidence/typedarray-search.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(payload)
summary = {
    'feature': 'Number TypedArray at/includes/indexOf/lastIndexOf',
    'base': sources['base'], 'archive': archive_path.name,
    'archive_bytes': len(payload), 'archive_sha256': sha(payload),
    'manifest_sha256': sha(records['MANIFEST.json']), 'records': len(index),
    'candidate_adapter': adapter,
    'source_change_after_full_suite': lint,
    'validation': {name: json.loads((R / 'validation' / (name + '.json')).read_bytes()) for name in checks},
    'upstream_counts': report['counts'], 'mode_cases': report['mode_cases'],
    'controls': 56, 'harness_preflight_healthy': True,
    'upstream_report_healthy': False, 'baseline_recorded': False,
    'known_gaps': ['78 resource-limited modes', '2 modes need TypedArray.fill',
                   '132 explicit unsupported modes', 'Full web compatibility, security and Chromium performance targets remain unmet'],
    'comparison': comparison,
    'published_bindings': {p: {'bytes': len((W / p).read_bytes()), 'sha256': sha((W / p).read_bytes())}
                           for p in sorted(set(paths)) if not p.startswith('docs/evidence/')},
}
(W / 'docs/evidence/typedarray-search.json').write_bytes(encoded(summary))
with tarfile.open(archive_path) as archive:
    for name, row in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
print(json.dumps({'archive_bytes': len(payload), 'archive_sha256': sha(payload), 'records': len(index)}))
