# Ordinary nonnumeric own-key snapshots

Source-only implementation and focused test hold. Root exclusively owns formatting, compiler, engine and test execution. The first unchanged prior-pass Resource observation remains in validation/prior-pass-1.log. This change neither changes the 100,000 work quota nor removes nonenumerable properties from enumeration.

## Reached source path

The exact pinned key-is-not-numeric-index.js body selects only the passthrough factory for ten Number constructors. verifyNotEnumerable calls isEnumerable twice per constructor (foo then bar). Both hidden names force complete for-in walks; neither body calls sample.toString. Each walk snapshots the instance, concrete TypedArray prototype, shared prototype and later prototype objects, then checks live descriptors and visited names. The added four shared methods increase the shared owner from13 total/11 strings to17 total/15 strings. A complete twenty-walk trace is conditional source arithmetic, not a measured stopping point; the actual first failure reports ten records and zero work remaining.

The old ordinary snapshot always builds OwnKey records, parses each retained name as an Array index, checks sorted ranks, and consumes that temporary vector into a second Vec<JsString>. For a key set with no virtual properties and no digit-leading strings, all those ranks are already creation order and there can be no virtual/stored numeric duplicate. The temporary records, classifier, sortedness comparisons and consuming transfer are unnecessary.

## Concrete implementation

Only own_keys.rs and the new child ordinary_snapshot_tests.rs change. After the existing Window/Document/DOM resolution and virtual-key determination, pay4 control work. Attempt the helper only when virtual_length is false, order_len>=8 and an actual property owner exists. Arrays, including empty Arrays, and primitive/boxed strings have virtual_length=true. The threshold is independent of property names or the regression identity: even an all-symbol eligible order has positive predicted work savings at eight entries. Small/virtual ordinary routes pay4 additional work and otherwise execute the unchanged generic algorithm. The separate TypedArray dense snapshot route remains byte-exact.

The helper pays4 setup then6 before each reached original order entry. The six-unit probe convention covers tag/optional first-unit access, the two digit bounds, retained-string counting and loop/control bookkeeping. Only the first UTF-16 unit is inspected. Empty strings, signs, non-ASCII digits and lone surrogates cannot begin an Array index and are accepted. Any ASCII digit conservatively rejects the fast path, including ordinary names such as01 and4294967295. Rejection allocates nothing and then executes the exact old generic body with its full original fees.

After a complete proof, pay8+4*n+2*s work and s*sizeof(JsString) bytes before the sole allocation. The fixed8 covers checked bounds, reserve/result setup and retirement;4 per original entry covers the second loop/tag/handle access;2 per retained string covers clone/move/retirement operations. These are logical handle/control envelopes, not machine instruction claims. No UTF-16 payload is copied. The second scan skips symbols and clones string Rc handles in the existing creation-order list. No descriptors, values or prototypes are read by the helper, and no author callback can occur between proof and copy. No proof is cached or stored in Runtime, ForInState or a snapshot. The next call repeats the proof on the current order, including after numeric additions/deletion/reinsertion.

All work/storage arithmetic in the new builder is checked. Failed work or heap admission leaves the object map/order untouched; the helper has not allocated when a proof fails or its later admission fails. The existing charge function retains its terminal cumulative accounting semantics. Once allocation succeeds, copy is nonfallible. The caller still performs fresh descriptor reads and visited-name handling after snapshot creation, including hidden shadowing and deletion/redefinition during a loop. Symbol own-key enumeration remains the separate preexisting route.

## Costs and explicit limitations

Let n=all stored order entries and s=string entries. Exclude unchanged preceding brand/host lookup costs.

* Old complete all-nonnumeric snapshot (s>0):13*n+5*s-2 work, from count(n+1), build(12*n+2*s), and ordered rank checks3*(s-1).
* New admitted fast snapshot:16+10*n+2*s work. For s=0, the old cost is13*n+1; the new formula is unchanged.
* Small/virtual/no-owner generic path: old work+4, old bytes unchanged.
* Large candidate rejecting after q entries: old work+8+6*q, old bytes unchanged. No discount is applied to the unchanged generic computation.
* Old complete nonvirtual buffer charge:s*(sizeof(OwnKey)+sizeof(JsString)); new:s*sizeof(JsString). No new retained state/layout storage.

The shared17/15 owner changes294→216, saving78 per complete snapshot or1560 for twenty complete walks. It removes15 OwnKey records each time. This excludes route overhead on every other snapshot and all other operations. No whole-script recovery, universal improvement, measured performance or revised baseline is claimed. Root must measure the unchanged original case and all regressions.

## Independent tests

Seven groups bind literal creation order rather than lexical order; interspersed symbols; hidden/getter properties; empty, NUL, non-ASCII and lone-surrogate names; long-name handle identity and length-independent work; small/empty overhead and all-symbol fast snapshots; digit-leading ordinary names and actual numeric fallback order; real sparse Array/boxed-string virtual properties despite eight stored names; fresh proof after mutation; live for-in descriptor deletion/hidden shadowing; and literal112-work exact/one-short/zero work+heap cuts with unchanged source maps/order. Older own_keys/tests.rs and for_in_tests.rs/singleton_tests.rs are unchanged. No historical expectation is migrated.
