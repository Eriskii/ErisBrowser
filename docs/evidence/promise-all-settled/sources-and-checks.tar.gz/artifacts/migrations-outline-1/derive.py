from pathlib import Path
import hashlib,json,difflib,re,subprocess
P=Path('/tmp/eris-promise-all-settled-plan-1');W=P/'worktree';O=P/'migrations-outline-1';BASE='c97b200c9bddf1527cdbbc5a652beedba27c1d6d'
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(rel,s):
 p=O/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);return bind(p)
def dump(rel,x):return save(rel,json.dumps(x,indent=2)+'\n')
changes=[];identities=[]
def change(rel,reason,fn):
 before=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+rel]).decode();assert (W/rel).read_text()==before,rel
 after=fn(before);assert after!=before,rel
 bp=save('before/'+rel,before);rp=save('raw/'+rel,after)
 dp=save('diffs/'+rel.replace('/','__')+'.patch',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 oldnames=re.findall(r'#\[test\]\nfn (\w+)\(',before);newnames=re.findall(r'#\[test\]\nfn (\w+)\(',after);assert len(oldnames)==len(newnames)
 renames=[dict(before=a,after=b) for a,b in zip(oldnames,newnames) if a!=b]
 changes.append(dict(relative_path=rel,reason=reason,before=bp,raw=rp,diff=dp,group_count_preserved=len(oldnames),renames=renames))
def replace(s,a,b,n=None):
 count=s.count(a);assert count and (n is None or count==n),(a,count,n);return s.replace(a,b)
def counts(s):return re.sub(r'\b751\b','752',s)
def rawcuts(s):
 for a,b in [('99786','99973'),('99785','99972'),('99_786','99_973'),('99_785','99_972'),('(100_000, true, 214)','(100_000, true, 27)')]:
  if a in s:s=s.replace(a,b)
 return counts(s)
change('src/script/bootstrap_tests.rs','Raw work214→27 and reserved bag count751→752; public reset/heap relations unchanged.',lambda s: counts(replace(replace(s,'    assert_eq!(reference.steps, 214);','    assert_eq!(reference.steps, 27);',1),'    // Two Text factories share existing keys, saving60 work and336 bytes.','    // Two Text factories share existing keys, saving60 work and336 bytes.\n    // AllSettled adds187 metadata work and one bag, reusing the existing arenas.',1)))
for rel in ['src/script/dom_bindings/identity_tests.rs','src/script/node_data/method_key_tests.rs','src/script/node_data/key_cache_tests.rs','src/script/node_data/key_cache_fee_tests.rs']:
 change(rel,'Only complete-bootstrap object count/capacity751→752. Existing IDs, descriptors, body traces and isolated Node factory fees stay exact.',counts)
for rel in ['src/script/processing_instruction/key_cache_tests.rs','src/script/text_operations/key_cache_tests.rs']:
 change(rel,'Raw99785/99786/100000→99972/99973/100000 with remaining27; complete object count/capacity752. Existing method key identities/behavior and isolated factories unchanged.',rawcuts)
change('src/script/test262_host/quota_tests.rs','Only raw startup remaining214→27 and full count751→752. Synthetic object_plan(750,750)/(750,752), growth1500 and every host tariff remain exact.',lambda s:counts(replace(s,'assert_eq!(runtime.steps, 214);','assert_eq!(runtime.steps, 27);',1)))
for rel in ['src/script/promise_semantic_tests.rs','src/script/promise_race_semantic_tests.rs']:
 change(rel,'Append only allSettled to the exact current constructor string property roster; preserve all old semantic traces and assertions.',lambda s:replace(s,"length,name,prototype,resolve,reject,all,race'","length,name,prototype,resolve,reject,all,race,allSettled'",1))
def typed(s):
 s=counts(s)
 s=replace(s,'    let race_added = s + a + d + 3 * k + bpp + n + 1020;','    let race_added = s + a + d + 3 * k + bpp + n + 1020;\n    // AllSettled adds one method bag; no further State or arena header.\n    let all_settled_added = s + a + d + 3 * k + bpp + n + 1074;',1)
 s=replace(s,'            + 60\n','            + 60\n            - 187\n',1)
 return replace(s,'            - 336\n','            - 336\n            + all_settled_added\n',1)
change('src/script/typed_array/tests.rs','Append source-derived −187 work and S+A+D+3K+Bpp+N+1074 heap term; count752. Existing State header is charged once and symbolic widths remain actual sizeof.',typed)
def install(s):
 s=rawcuts(s)
 for a,b in [('the ten initial','the eleven initial'),('10 * a + 10 * d + 29 * k + 10 * bpp + 9 * n + 4 * bsb + 10376','11 * a + 11 * d + 32 * k + 11 * bpp + 10 * n + 4 * bsb + 11450'),('reserve ten additional','reserve eleven additional'),('try_reserve_exact(10)','try_reserve_exact(11)'),('runtime.objects.len() + 10','runtime.objects.len() + 11'),('1383','1570'),('1382','1569'),('761','763')]:s=replace(s,a,b)
 return s
change('src/script/promises/install_tests.rs','Standalone1570/1569 and helper typed heap; reserve11 extra bags over752 retained objects yielding763; whole raw99973/rem27; no new state guards.',install)
def shared(s):
 # Simultaneous numeric substitution avoids touching the newly mapped base/producer totals.
 s=re.sub(r'\b(751|752|762|1345|1344|1676|1675)\b',lambda m:{'751':'752','752':'753','762':'764','1345':'1532','1344':'1531','1676':'1863','1675':'1862'}[m.group()],s)
 s=s.replace('exact1345','exact1532').replace('exact1676','exact1863')
 s=replace(s,'10 * a + 10 * d + 29 * k + 10 * l + 9 * n + 4 * b + 10208','11 * a + 11 * d + 32 * k + 11 * l + 10 * n + 4 * b + 11282',1)
 s=replace(s,'try_reserve_exact(11)','try_reserve_exact(12)',1)
 s=replace(s,'migrated99785/99786/100000','migrated99972/99973/100000',1)
 s=replace(s,'let fixed = if shared { 20 } else { 22 };','let fixed = if shared { 21 } else { 23 };',1)
 old='''        (false, 22, 0),
        (false, 41, 0),
        (false, 42, 88),
        (false, 57, 88),
        (false, 58, 168),
        (true, 20, 0),
        (true, 41, 0),
        (true, 42, 92),'''
 new='''        (false, 23, 0),
        (false, 42, 0),
        (false, 43, 88),
        (false, 58, 88),
        (false, 59, 168),
        (true, 21, 0),
        (true, 42, 0),
        (true, 43, 92),'''
 return replace(s,old,new,1)
change('src/script/promises/shared_key_tests.rs','Consumer1532/1531, pair1863/1862, typed heap delta; replay12 bags, base752/producer753/final764, immutable producer331 unchanged. Eight guards fixed21/23 and eight early prefixes each+1, unchanged admitted bytes.',shared)
def identity(s):
 s=counts(s)
 s=replace(s,'all_ten_function_bags','all_eleven_function_bags',1)
 s=replace(s,'749, 750]','749, 750, 751]',2)
 s=replace(s,'runtime.objects[constructor].values.len(), 8','runtime.objects[constructor].values.len(), 9',1)
 s=replace(s,"[P.all,'all',1],[P.race,'race',1]];","[P.all,'all',1],[P.race,'race',1],[P.allSettled,'allSettled',1]];",1)
 return replace(s,"length,name,prototype,resolve,reject,all,race'","length,name,prototype,resolve,reject,all,race,allSettled'",1)
change('src/script/promises/shared_key_identity_tests.rs','Preserve all prior metadata IDs, append allSettled bag751 and descriptor row; constructor count8→9, total752, old SQV7 trace exact.',identity)
assert len(changes)==14
# Independent scalar/polynomial arithmetic from current helper source, not a runtime execution.
def tree(n):
 if not n:return (0,0)
 c=(n+1)//2;h=1
 while c>=6:c//=6;h+=1
 return min(n,11*h),h
def prop(n,l):return tree(n)[0]*(1+l)+(n+8 if n<11 else 28*(tree(n)[1]+1))+1
pool=['length','name','Promise','then','resolve','reject','prototype','constructor','get [Symbol.species]','catch','finally','all','race','allSettled']
native=['Promise.then','Promise.resolve','Promise.reject','Promise.getSpecies','Promise.catch','Promise.finally','Promise.all','Promise.race','Promise.allSettled']
steps=[('standalone fixed releases/guards/publication',23),('fourteen literal texts',sum(8+2*len(x) for x in pool)),('handle clones',43),('species key lookup',tree(15)[0]),('tag key lookup',2*tree(15)[0]),('saved Object prototype lookup',tree(25)[0]),('constructor/prototype bags',18),('constructor initial3 properties',sum(prop(i,n) for i,n in enumerate([6,4,9]))),('constructor native',15),('nine ordinary method bags/metadata/natives',sum(9+prop(0,6)+prop(1,4)+8+len(x) for x in native)),('constructor5 methods plus species',sum(prop(i,n) for i,n in enumerate([7,6,3,4,10,0],3))),('prototype5 properties',sum(prop(i,n) for i,n in enumerate([11,4,5,7,0]))),('global publication count211',8+tree(211)[0]+28*(tree(211)[1]+1)+7)]
assert sum(x[1] for x in steps)==1570
constant=sum(64+4*len(x) for x in pool)+11*72+(32+7)+sum(32+len(x) for x in native)+sum(256+4*n for n in [6,4,9,7,6,3,4,10,0])+sum(256+4*n for n in [11,4,5,7,0])+9*(280+272)+39
assert constant==11450
ledger={'status':'source_derived_selected_installer_and_migrations_before_execution','base':BASE,'selection':bind(P/'root/selection-1.json'),'parent_inventory':bind(P/'parent-source.json'),'current_source_is_published_AY':True,'work':{'component_delta':{'method_bag':9,'allSettled_text':28,'metadata_properties':24,'native_internal_name':26,'handle_clones':4,'pool_release':1,'constructor_property':93,'displaced_species_delta':2},'delta':187,'raw_before':99786,'raw_after':99973,'remaining_before':214,'remaining_after':27,'standalone_before_after':[1383,1570],'shared_before_after':[1345,1532],'producer_unchanged':331,'pair_before_after':[1676,1863],'full_standalone_line_ledger':[dict(stage=a,work=b) for a,b in steps],'shared_equation':'1570 - text(length)20 - text(name)16 - their2 prepaid releases =1532','pair_equation':'331+1532=1863'},'heap':{'symbols':{'A':'sizeof Option<AbortSlot>','D':'sizeof Option<f64>','K':'sizeof PropertyKey','N':'sizeof Native','S':'sizeof ScriptObject','Bpp':'16*(K+sizeof Property)+32*sizeof usize+64','Bsb':'16*(sizeof String+sizeof Binding)+32*sizeof usize+64'},'standalone':'11A+11D+32K+11Bpp+10N+4Bsb+11450','shared':'11A+11D+32K+11Bpp+10N+4Bsb+11282','producer_unchanged':'A+D+2K+Bpp+N+4Bsb+1004','pair':'12A+12D+34K+12Bpp+11N+8Bsb+12286','helper_delta':'A+D+3K+Bpp+N+1074','whole_bootstrap_delta':'S+A+D+3K+Bpp+N+1074','increment_constants':[72,104,280,272,50,296],'initial_object_slots_before_after':[751,752],'qualification':'Actual callback/State/Runtime width observations remain root-owned; selected two-tag proposal has no new field/arena/header. No second State header term is added; symbolic sizeof expressions bind actual compiled types.'},'publication_order':{'old_ids':'queueMicrotask740, Promise741, prototype742, then743, resolve744, reject745, species746, catch747, finally748, all749, race750 unchanged','new_bag':751,'constructor_order_capacity_before_after':[8,9],'constructor_string_names':'length,name,prototype,resolve,reject,all,race,allSettled','internal_final_key':'Symbol.species','pool_length_before_after':[13,14],'pool_new_index':13,'clone_budget_before_after':[39,43],'fixed_standalone_before_after':[22,23],'fixed_shared_before_after':[20,21],'invalid_state_guard_count_unchanged':8,'registry_global_counts_unchanged':{'native':299,'prototype':25,'global':212}},'existing_cuts':{'standalone_work':[1570,1569],'standalone_heap':['H','H-1'],'consumer_work':[1532,1531],'pair_work':[1863,1862],'raw_rows':[[99972,False,0],[99973,True,0],[100000,True,27]],'early_prefix_rows':[[False,23,0],[False,42,0],[False,43,88],[False,58,88],[False,59,168],[True,21,0],[True,42,0],[True,43,92]],'producer_prefix_work_unchanged':[1,2,10,11,47,67,93],'replay_slots':{'base':752,'standalone_extra':11,'standalone_success':763,'pair_extra':12,'producer_owner':752,'after_producer':753,'pair_success':764},'late_refusal':'Final global publication work/heap is still last: one-short work leaves cache/global absent and may retain paid private bags; exact heap consumes H, one-short heap reaches MAX_HEAP+1 before publication. No rollback claim.'},'unselected_controls_preserved':['Text private factory98/87, staged44/36 and installer278; all16 operation expectations byte-exact.','All Node isolated factory/handoff fees, old function IDs, descriptor/mutation/source traces.','Optional host synthetic object_plan(750,750) target1500 and object_plan(750,752); all setup405/bind49/arm16/DONE24/print66/final24+3N tariffs.','Producer331 work/heap and its prefix counters; all8 invalid-state choices.','Existing all/race/finally storage/semantic tests outside explicit metadata roster; old callback metadata and job tariffs.'],'migration_paths':len(changes),'migrations':changes,'test_name_changes':[dict(path=c['relative_path'],**r) for c in changes for r in c['renames']],'execution':'External source extraction from published Git blobs, stdlib literal edits/diff/hash/integer algebra only. No live edits, project Python imports, compiler, engine or tests executed.'}
dump('ledger.json',ledger)
# Freeze all production/helper source anchors used to derive the above.
sources=[]
for rel in ['src/script/promises/install.rs','src/script/promises.rs','src/script/dom_prototypes.rs','src/script/symbols.rs','src/script.rs','src/script/text_operations.rs','src/script/text_operations/key_cache_fee_tests.rs']:
 data=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+rel]);q=O/'source-snapshots'/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(data);sources.append(dict(relative_path=rel,snapshot=bind(q)))
dump('source-bindings.json',{'published_base':BASE,'parent_inventory':bind(P/'parent-source.json'),'sources':sources})
allfiles=[bind(p) for p in sorted(O.rglob('*')) if p.is_file() and p.name not in ['source-ready.json','script-review.json','html-review.json']]
hold={'status':'sealed_source_only_installer_migration_outline','base':BASE,'scope':'14 existing Rust test paths only; exact before/raw/diffs and source-derived selected startup/helper/prefix arithmetic. No production edit.','paths':14,'renamed_groups':len(ledger['test_name_changes']),'ledger':bind(O/'ledger.json'),'source_bindings':bind(O/'source-bindings.json'),'files':allfiles,'import':'Root may import raw only after selection/peer and production. All before bytes must match; no replacement of unrelated live registrations.','execution':ledger['execution']}
dump('source-ready.json',hold)
print(json.dumps({'hold':bind(O/'source-ready.json'),'paths':len(changes),'renames':ledger['test_name_changes'],'work_ledger':steps,'constant_heap':constant},indent=2))
