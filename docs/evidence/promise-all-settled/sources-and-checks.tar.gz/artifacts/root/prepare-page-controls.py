import difflib
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
O = A / 'page-tests-before-1'
assert not O.exists()
O.mkdir()
html = '''<!doctype html>
<html><head><meta charset="utf-8"><title>base</title>
<style>
html,body { margin:0; padding:0; border:0; background:#fff; }
#red,#blue { display:block; position:absolute; top:2px; width:4px; height:4px; box-sizing:content-box; margin:0; padding:0; border:0; }
#red { left:2px; background:#f00; }
#blue { left:20px; background:#00f; }
</style></head><body><div id="red"></div><div id="blue"></div>
<script>
var red=document.getElementById('red'),trace='S',rejectPending,token={offset:8};
var pending=new Promise(function(resolve,reject){rejectPending=reject;});
Promise.allSettled([Promise.resolve(4),pending,3]).then(function(v){
  if(v.length!==3 || v[0].status!=='fulfilled' || v[0].value!==4 ||
     v[1].status!=='rejected' || v[1].reason!==token ||
     v[2].status!=='fulfilled' || v[2].value!==3) throw 'initial snapshots';
  trace+='A';red.style.left=(v[0].value+v[1].reason.offset)+'px';document.title=trace;
});
queueMicrotask(function(){trace+='Q';rejectPending(token);});
red.addEventListener('click',function(){
  trace+='C';
  Promise.allSettled([Promise.reject(token),16]).then(function(v){
    if(v.length!==2 || v[0].status!=='rejected' || v[0].reason!==token ||
       v[1].status!=='fulfilled' || v[1].value!==16) throw 'click snapshots';
    trace+='D';red.style.left=v[1].value+'px';
  });
  queueMicrotask(function(){trace+='K';});
});
red.addEventListener('click',function(){trace+='B';document.title=trace;});
</script></body></html>
'''
files = {'tests/fixtures/promise-all-settled.html': html}
for old, new in [('tests/support/promise_all.rs', 'tests/support/promise_all_settled.rs'),
                 ('tests/promise_all.rs', 'tests/promise_all_settled.rs'),
                 ('tests/worker/promise_all.rs', 'tests/worker/promise_all_settled.rs')]:
    text = (W / old).read_text().replace('Promise.all', 'Promise.allSettled').replace('promise_all', 'promise_all_settled').replace('promise-all', 'promise-all-settled')
    text = text.replace('SQACDKB', 'SQACKDB')
    text = text.replace('collects_in_order_and_drains_before_the_next_host_listener', 'retains_both_outcomes_and_drains_before_the_next_host_listener')
    files[new] = text
fragment = '\n#[path = "worker/promise_all_settled.rs"]\nmod promise_all_settled;\n'
before = (W / 'tests/worker.rs').read_bytes()
(O / 'worker-before.rs').write_bytes(before)
(O / 'worker-registration.txt').write_text(fragment)
files['tests/worker.rs'] = before.decode() + fragment

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

rows = []
for path, text in files.items():
    raw = O / 'raw' / path
    raw.parent.mkdir(parents=True, exist_ok=True)
    raw.write_text(text)
    previous = (W / path).read_text() if (W / path).exists() else ''
    diff = O / (path.replace('/', '__') + '.patch')
    diff.write_text(''.join(difflib.unified_diff(previous.splitlines(True), text.splitlines(True), fromfile='a/' + path, tofile='b/' + path)))
    rows.append(dict(relative_path=path, raw=bind(raw), before=bind(W / path) if (W / path).exists() else None, diff=bind(diff)))
record = dict(status='source_derived_parent_eligible_controls', files=rows,
    groups=2, registration=bind(O / 'worker-registration.txt'),
    oracle=dict(initial_title='SQA', clicked_title='SQACKDB', red_x=[2, 12, 16], blue_x=20,
        boxes='4 by4 pixels at y2; white remaining canvas; widths320/300 and height240',
        derivation='Initial pending rejection completes in the Q microtask; allSettled reaction A follows it. During click, nonempty inputs settle before queued K but enqueue aggregate reaction D behind K. Host checkpoint drains before the next listener B. Disabled scripts keep base/title and x2.'),
    scope='Direct Page and Linux confined worker; two widths, initial/load/task/click/post-task, exact pixels/hits/titles/no extra diagnostics and disabled-script control. Raster bridge checks interpreter plan pixels, not GPU execution.',
    parent_prediction='Enabled initial state cannot reach x12/SQA without missing allSettled; disabled controls precede that failure.',
    execution='Only source reads and external hold writing; no live edits or project execution.')
(O / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print('Authored two parent-compatible Page/worker controls and literal fixture; no live edits.')
