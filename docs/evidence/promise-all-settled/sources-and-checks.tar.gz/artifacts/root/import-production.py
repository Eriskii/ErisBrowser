import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def read(p):
    return json.loads(p.read_bytes())

before = read(A / 'source-parent-pages.json')['source_sha256']
for p, h in before.items():
    assert bind(W / p)['sha256'] == h, p
assert read(A / 'production-review-1/source-review.json')['status'] == 'clear_bounded_source_only_production_review'
production = read(A / 'production-1/source-ready.json')
layout = read(A / 'tests-layout-actual-1/source-ready.json')
for row in layout['files']:
    assert bind(Path(row['path']))['sha256'] == row['sha256']
for row in production['files']:
    for key in ['before', 'raw', 'diff']:
        assert bind(Path(row[key]['path']))['sha256'] == row[key]['sha256']
probe = 'src/script/promises/all_settled_layout_probe.rs'
fragment = (A / 'tests-before-1/registrations/layout-append.txt').read_bytes()
main = W / 'src/script/promises.rs'
assert main.read_bytes().endswith(fragment)
main.write_bytes(main.read_bytes()[:-len(fragment)])
(W / probe).unlink()
for row in production['files']:
    p = W / row['relative_path']
    assert bind(p)['sha256'] == row['before']['sha256'], p
for row in production['files']:
    (W / row['relative_path']).write_bytes(Path(row['raw']['path']).read_bytes())
actual = layout['raw_module']
assert not (W / actual).exists()
(W / actual).write_bytes((A / 'tests-layout-actual-1/raw' / actual).read_bytes())
fragment = (A / 'tests-layout-actual-1' / layout['registration']).read_bytes()
assert fragment not in main.read_bytes()
main.write_bytes(main.read_bytes() + fragment)
paths = set(before) - {probe} | {actual}
source = {p: bind(W / p)['sha256'] for p in sorted(paths)}
assert len(source) == 1547
(A / 'source-candidate-1.json').write_text(json.dumps(dict(source_sha256=source,
    note='Reviewed seven production paths plus frozen public15, actual-layout1 and Page/worker2 groups. Temporary mirror removed. Existing test accounting migrations and private refusal controls are pending.'), indent=2) + '\n')
(A / 'root/production-import.json').write_text(json.dumps(dict(status='imported',
    production_hold=bind(A / 'production-1/source-ready.json'), production_peer=bind(A / 'production-review-1/source-review.json'),
    layout_hold=bind(A / 'tests-layout-actual-1/source-ready.json'), source=bind(A / 'source-candidate-1.json'),
    removed_temporary_probe=probe, retained_public_groups=15, actual_layout_groups=1, page_worker_groups=2), indent=2) + '\n')
print('Imported seven reviewed production paths and permanent actual-layout control; removed temporary mirror.')
