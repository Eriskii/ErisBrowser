import difflib
import hashlib
import json
from pathlib import Path

P = Path(__file__).resolve().parents[1]
W = Path('/tmp/eris-text-metadata-keys-1/worktree')
O = P / 'production-1'
assert not O.exists()
O.mkdir()
files = {}

def edit(path, transform):
    before = (W / path).read_text()
    after = transform(before)
    assert after != before
    files[path] = (before, after)

def replace(text, before, after):
    assert text.count(before) == 1, before
    return text.replace(before, after)

def main(text):
    text = replace(text, 'const METADATA_OBJECTS: usize = 10;', 'const METADATA_OBJECTS: usize = 11;')
    return replace(text, '    AllResolve(AllCaptureId),', '    AllResolve(AllCaptureId),\n    AllSettledFulfill(AllCaptureId),\n    AllSettledReject(AllCaptureId),')
edit('src/script/promises.rs', main)

def installer(text):
    changes = [
        ('fn tree(count:', 'pub(super) fn tree(count:'),
        ('all thirteen\n', 'all fourteen\n'),
        ('self.work(22)?;', 'self.work(23)?;'),
        ('and eleven pool releases.', 'and twelve pool releases.'),
        ('self.work(20)?;', 'self.work(21)?;'),
        ('            self.dom_proto_text("race")?,', '            self.dom_proto_text("race")?,\n            self.dom_proto_text("allSettled")?,'),
        ('// 27 string keys, 9 display names, 1 prototype tag, 2 constructor handles.\n        self.work(39)?;', '// 30 string keys, 10 display names, 1 prototype tag, 2 constructor handles.\n        self.work(43)?;'),
        ('self.dom_proto_object(Some(Value::Function(self.function_prototype)), 8)?;', 'self.dom_proto_object(Some(Value::Function(self.function_prototype)), 9)?;'),
        ('        let race = self.promise_intrinsic_method("Promise.race", pool[12].clone(), 1, keys)?;', '        let race = self.promise_intrinsic_method("Promise.race", pool[12].clone(), 1, keys)?;\n        let all_settled =\n            self.promise_intrinsic_method("Promise.allSettled", pool[13].clone(), 1, keys)?;'),
        ('        self.dom_proto_property(\n            constructor_bag,\n            species,', '        self.dom_proto_property(\n            constructor_bag,\n            pool[13].clone().into(),\n            Property::data(all_settled, true, false, true),\n        )?;\n        self.dom_proto_property(\n            constructor_bag,\n            species,')]
    for before, after in changes:
        text = replace(text, before, after)
    return text
edit('src/script/promises/install.rs', installer)

def factories(text):
    text = replace(text, '                        CallbackKind::AllResolve(id) => matches!(', '                        CallbackKind::AllResolve(id)\n                        | CallbackKind::AllSettledFulfill(id)\n                        | CallbackKind::AllSettledReject(id) => matches!(')
    method = '''    pub(super) fn new_all_settled_elements(
        &mut self,
        group: AllCaptureId,
        index: usize,
    ) -> Result<(Value, Value)> {
        // Both immutable callback identities share one append-only Element.
        // The existing batch factory publishes its count once, after both bags.
        let element = AllCaptureId(self.promises.all_captures.records.len());
        let result = self
            .build_promise_callbacks(
                [
                    CallbackKind::AllSettledFulfill(element),
                    CallbackKind::AllSettledReject(element),
                ],
                FactoryExtra::AllElement(group, index),
            )
            .map(|[fulfilled, rejected]| (fulfilled, rejected));
        self.observe_microtask_failure(result)
    }

'''
    return replace(text, '    pub(super) fn read_finally_finalizer(', method + '    pub(super) fn read_finally_finalizer(')
edit('src/script/promises/factories.rs', factories)

def semantics(text):
    text = replace(text, '                "Promise.race" => self.promise_race(receiver, args, doc),', '                "Promise.race" => self.promise_race(receiver, args, doc),\n                "Promise.allSettled" => self.promise_all_settled(receiver, args, doc),')
    return replace(text, '                CallbackKind::ReturnValue(capture) => return self.read_finally_outcome(capture),', '''                CallbackKind::AllSettledFulfill(element) => {
                    return self.run_all_settled_callback(element, ReactionKind::Fulfill, args, doc);
                }
                CallbackKind::AllSettledReject(element) => {
                    return self.run_all_settled_callback(element, ReactionKind::Reject, args, doc);
                }
                CallbackKind::ReturnValue(capture) => return self.read_finally_outcome(capture),''')
edit('src/script/promises/semantics.rs', semantics)
edit('src/script/machine/calls.rs', lambda t: replace(t, '                    | "Promise.race"', '                    | "Promise.race"\n                    | "Promise.allSettled"'))

def iteration(text):
    start = text.index('    pub(super) fn promise_all(')
    end = text.index('    pub(super) fn promise_race(')
    body = text[start:end]
    body = replace(body, 'fn promise_all(', 'fn promise_all_settled(')
    body = replace(body, 'Promise.all input is not iterable', 'Promise.allSettled input is not iterable')
    body = replace(body, '''                let fulfilled = self.new_all_resolve_element(group, index)?;
                self.work(2)?;
                let rejected = reject.clone();''', '''                let (fulfilled, rejected) = self.new_all_settled_elements(group, index)?;
                self.work(1)?;''')
    text = text[:end] + body + text[end:]
    marker = '\n}\n\n#[cfg(test)]\nmod race_quota_tests;'
    callback = '''

    pub(super) fn run_all_settled_callback(
        &mut self,
        element: AllCaptureId,
        kind: ReactionKind,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        let value = args.first().unwrap_or(&Value::Undefined);
        match self.complete_all_settled_element(element, kind, value)? {
            Some(ready) => self.resolve_all_ready(ready, doc),
            None => Ok(Value::Undefined),
        }
    }'''
    text = replace(text, marker, callback + marker)
    return replace(text, '//! Observable Promise.all and Promise.race iteration over the realm\'s job machinery.', '//! Observable Promise combinator iteration over the realm\'s job machinery.')
edit('src/script/promises/all_semantics.rs', iteration)

def state(text):
    methods = '''    pub(super) fn new_all_settled_snapshot(
        &mut self,
        kind: ReactionKind,
        value: &Value,
    ) -> Result<Value> {
        let result = (|| {
            // Fixed checks/planning, one payload clone and six owner releases.
            // Lookup, object backing and staged bag/text/property fees follow.
            self.work(17)?;
            let (status, payload) = match kind {
                ReactionKind::Fulfill => ("fulfilled", "value"),
                ReactionKind::Reject => ("rejected", "reason"),
            };
            self.work(install::tree(self.prototypes.len()).0)?;
            let prototype = self
                .prototypes
                .get("Object")
                .copied()
                .filter(|id| *id < self.objects.len())
                .ok_or_else(invalid)?;
            let objects =
                factories::object_slot_plan(self.objects.len(), self.objects.capacity(), 1)?;
            self.work(objects.work)?;
            self.charge(objects.bytes)?;
            reserve_all!(self.objects, objects, Objects);
            let bag = self.dom_proto_object(Some(Value::Object(prototype)), 2)?;
            let status_key = self.dom_proto_text("status")?;
            let status_text = self.dom_proto_text(status)?;
            let payload_key = self.dom_proto_text(payload)?;
            self.dom_proto_property(
                bag,
                status_key.into(),
                Property::data(Value::String(status_text), true, true, true),
            )?;
            self.dom_proto_property(
                bag,
                payload_key.into(),
                Property::data(value.clone(), true, true, true),
            )?;
            Ok(Value::Object(bag))
        })();
        self.observe_microtask_failure(result)
    }

    pub(super) fn complete_all_settled_element(
        &mut self,
        id: AllCaptureId,
        kind: ReactionKind,
        value: &Value,
    ) -> Result<Option<ReadyAllValues>> {
        let result = (|| {
            self.work(12)?;
            let Some(AllCapture::Element {
                group,
                index,
                called,
            }) = self.promises.all_captures.records.get(id.0)
            else {
                return Err(invalid());
            };
            // Either callback consumes the same gate. Duplicates do not inspect
            // moved-out Group storage or retain the caller's payload.
            if *called {
                return Ok(None);
            }
            let (group, index) = (*group, *index);
            self.work(14)?;
            let Some(AllCapture::Group {
                values,
                remaining,
                input_done,
                ..
            }) = self.promises.all_captures.records.get(group.0)
            else {
                return Err(invalid());
            };
            if index >= values.records.len() || values.records.len() > values.admitted_capacity {
                return Err(invalid());
            }
            let next = remaining.checked_sub(1).ok_or_else(invalid)?;
            if next == 0 && !*input_done {
                return Err(invalid());
            }
            let AllCapture::Element { called, .. } = &mut self.promises.all_captures.records[id.0]
            else {
                unreachable!("validated Promise.allSettled element");
            };
            *called = true;
            // Snapshot creation has no author call or AllCapture mutation.
            // A terminal refusal leaves this gate consumed and Group untouched.
            let snapshot = self.new_all_settled_snapshot(kind, value)?;
            let AllCapture::Group {
                resolve,
                values,
                remaining,
                ..
            } = &mut self.promises.all_captures.records[group.0]
            else {
                unreachable!("validated Promise.allSettled group");
            };
            // All remaining publication is prepaid and cannot fail.
            values.records[index] = snapshot;
            *remaining = next;
            Ok(if next == 0 {
                Some(ready_values(resolve, values))
            } else {
                None
            })
        })();
        self.observe_microtask_failure(result)
    }

'''
    return replace(text, '    pub(super) fn finish_all_input(', methods + '    pub(super) fn finish_all_input(')
edit('src/script/promises/all_state.rs', state)

def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

rows = []
for name, (before, after) in sorted(files.items()):
    b = O / 'before' / name
    r = O / 'raw' / name
    d = O / 'diffs' / (name.replace('/', '__') + '.patch')
    for p in [b, r, d]:
        p.parent.mkdir(parents=True, exist_ok=True)
    b.write_text(before)
    r.write_text(after)
    d.write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), fromfile='a/' + name, tofile='b/' + name)))
    rows.append(dict(relative_path=name, before=bind(b), raw=bind(r), diff=bind(d)))
(O / 'source-ready.json').write_text(json.dumps(dict(status='authored_external_production_pending_review_and_parent_controls', files=rows,
    selection=bind(P / 'root/selection-1.json'), note='No live source import, compilation or browser execution. Existing all/race bodies retained byte-for-byte; only new routes and installer metadata added.'), indent=2) + '\n')
print('Prepared seven external production paths; no live source changed.')
