import json
import subprocess
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], text=True).strip()

v = json.loads((A / 'root/publication-verification.json').read_bytes())
assert v['status'] == 'verified'
base = 'c97b200c9bddf1527cdbbc5a652beedba27c1d6d'
assert git(W, 'rev-parse', 'HEAD') == git(MAIN, 'rev-parse', 'HEAD') == base
assert not git(MAIN, 'status', '--porcelain') and not git(W, 'diff', '--cached', '--name-only')
paths = v['expected_commit_paths']
actual = set(git(W, 'diff', '--name-only').splitlines()) | set(git(W, 'ls-files', '--others', '--exclude-standard').splitlines())
assert actual == set(paths)
subprocess.run(['git', '-C', str(W), 'diff', '--check'], check=True)
subprocess.run(['git', '-C', str(W), 'add', '--', *paths], check=True)
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
message = A / 'commit-message.txt'
message.write_text('Implement generic Promise.allSettled in the custom runtime\n\nCollect ordered fulfillment and rejection snapshots with shared per-element\ncompletion gates, generic constructor dispatch and iterator-close behavior.\nPreserve terminal resource and unsupported-operation semantics under unchanged\nwork and heap caps, and exercise Page and confined-worker event integration.\n\nValidate 35 new groups, 3,124 default and 3,478 host/Vulkan tests, strict lint\nand formatting. Preserve all 842 existing Promise case records and 254 harness\nrecords on the rebuilt release adapter. Retain source, failure/correction and\nallocation evidence; upstream allSettled corpus coverage follows separately.\n')
subprocess.run(['git', '-C', str(W), 'commit', '-F', str(message)], check=True)
commit = git(W, 'rev-parse', 'HEAD')
assert not git(W, 'status', '--porcelain')
subprocess.run(['git', '-C', str(MAIN), 'merge', '--ff-only', commit], check=True)
subprocess.run(['git', '-C', str(MAIN), 'push', 'origin', 'main'], check=True)
assert git(MAIN, 'rev-parse', 'HEAD') == commit and not git(MAIN, 'status', '--porcelain')
(A / 'root/github-publication.json').write_text(json.dumps(dict(commit=commit,
    remote='https://github.com/Eriskii/ErisBrowser', push='success', ci_status='pending',
    note='Postpublication state intentionally outside the immutable evidence archive.'), indent=2) + '\n')
print('Published ' + commit)
