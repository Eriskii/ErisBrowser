import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def read(p):
    return json.loads(p.read_bytes())

parent = read(A / 'parent-source.json')['source_sha256']
for p, h in parent.items():
    assert bind(W / p)['sha256'] == h, p
holds = [A / 'tests-before-1/source-ready.json', A / 'tests-supplement-1/source-ready.json']
for hold in holds:
    for r in read(hold)['files']:
        assert bind(Path(r['path']))['sha256'] == r['sha256'], r['path']
modules = {
    'src/script/promise_all_settled_semantic_tests.rs': A / 'tests-before-1/raw/src/script/promise_all_settled_semantic_tests.rs',
    'src/script/promises/all_settled_layout_probe.rs': A / 'tests-before-1/raw/src/script/promises/all_settled_layout_probe.rs',
    'src/script/promise_all_settled_supplemental_tests.rs': A / 'tests-supplement-1/raw/src/script/promise_all_settled_supplemental_tests.rs',
}
for p in modules:
    assert not (W / p).exists(), p
for p, raw in modules.items():
    (W / p).write_bytes(raw.read_bytes())
registrations = [
    ('src/script.rs', A / 'tests-before-1/registrations/public-append.txt'),
    ('src/script/promises.rs', A / 'tests-before-1/registrations/layout-append.txt'),
    ('src/script.rs', A / 'tests-supplement-1/registration-append.txt'),
]
for p, fragment in registrations:
    original = (W / p).read_bytes()
    assert fragment.read_bytes() not in original
    (W / p).write_bytes(original + fragment.read_bytes())
paths = set(parent) | set(modules)
source = {p: bind(W / p)['sha256'] for p in sorted(paths)}
assert len(source) == 1543
changed = [p for p, h in source.items() if parent.get(p) != h]
assert len(changed) == 5
(A / 'source-parent-controls.json').write_text(json.dumps(dict(base='c97b200c9bddf1527cdbbc5a652beedba27c1d6d', source_sha256=source,
    qualification='Published parent plus two public test modules and temporary layout mirror. Only two registration append paths differ; production unchanged.'), indent=2) + '\n')
(A / 'root/parent-controls-import.json').write_text(json.dumps(dict(status='imported_before_production', holds=[bind(p) for p in holds],
    source=bind(A / 'source-parent-controls.json'), changed_paths=changed, public_groups=15, public_planned_modes=30,
    temporary_layout_groups=1, layout_rows=18, production_changes=0), indent=2) + '\n')
print('Imported 15 public groups and one temporary18-row layout probe; production unchanged.')
