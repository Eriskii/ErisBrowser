import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(name):
    return json.loads((A / name).read_bytes())
def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args], text=True).strip()

final = read('source-final.json')['source_sha256']
parent = read('parent-source.json')['source_sha256']
changed = sorted(p for p, h in final.items() if parent.get(p) != h)
assert len(final) == 1549 and len(changed) == 32
for p, h in final.items():
    assert digest(W / p) == h, p
docs = [r['destination'] for r in read('documentation-1/source-ready.json')['files']]
for r in read('documentation-1/source-ready.json')['files']:
    assert digest(W / r['destination']) == r['raw']['sha256']
chapter = W / 'docs/promise-all-settled.md'
for link in re.findall(r'\]\(([^)]+)\)', chapter.read_text()):
    if '://' not in link:
        assert (chapter.parent / link.split('#')[0]).exists(), link
evidence = ['docs/evidence/promise-all-settled/summary.json', 'docs/evidence/promise-all-settled/sources-and-checks.tar.gz']
summary = json.loads((W / evidence[0]).read_bytes())
assert digest(W / evidence[1]) == summary['archive']['sha256']
with tarfile.open(W / evidence[1], 'r:gz') as archive:
    assert archive.getnames() == [r['path'] for r in summary['members']]
    for r in summary['members']:
        member = archive.getmember(r['path'])
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert len(data) == r['bytes'] and hashlib.sha256(data).hexdigest() == r['sha256']
        assert digest(Path(r['origin'])) == r['sha256'], r['origin']
expected = sorted(changed + docs + evidence)
assert len(expected) == len(set(expected)) == 38
actual = set(git('diff', '--name-only').splitlines()) | set(git('ls-files', '--others', '--exclude-standard').splitlines())
assert actual == set(expected), actual ^ set(expected)
assert git('rev-parse', 'HEAD') == 'c97b200c9bddf1527cdbbc5a652beedba27c1d6d'
subprocess.run(['git', '-C', str(W), 'diff', '--check'], check=True)
record = dict(status='verified', expected_commit_paths=expected,
    source_count=1549, changed_sources=32, documentation=4, evidence_files=2,
    archive_sha256=summary['archive']['sha256'], archive_members=len(summary['members']),
    source_sha256=digest(A / 'source-final.json'), validation_sha256=digest(A / 'root/final-validation.json'),
    default_passed=3124, host_vulkan_passed=3478, exact_case_records=842, exact_harness_records=254,
    full_web_compatibility=False)
(A / 'root/publication-verification.json').write_text(json.dumps(record, indent=2) + '\n')
print('Verified 38 exact publication paths, archive members, selected source state and chapter links.')
