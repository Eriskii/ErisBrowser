import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(name):
    return json.loads((A / name).read_bytes())


def check(label, passed=None):
    receipt_path = A / 'validation' / (label + '.json')
    receipt = json.loads(receipt_path.read_bytes())
    log_path = receipt_path.with_suffix('.log')
    assert receipt['exit'] == 0, label
    assert bind(log_path)['sha256'] == receipt['sha256'], label
    result = dict(receipt=bind(receipt_path), log=bind(log_path))
    if passed is not None:
        rows = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log_path.read_text(), re.M)
        totals = [sum(int(row[i]) for row in rows) for i in range(5)]
        assert totals[0] == passed and totals[1:4] == [0, 0, 0], (label, totals)
        result.update(passed=passed, failed=0, ignored=0, filtered=totals[4])
    return result


source = read('source-final.json')['source_sha256']
parent = read('parent-source.json')['source_sha256']
assert len(source) == 1549 and len(parent) == 1540
assert set(parent) <= set(source)
changed = sorted(p for p, h in source.items() if parent.get(p) != h)
assert len(changed) == 32
for path, expected in source.items():
    assert bind(W / path)['sha256'] == expected, path
assert read('candidate-source-review-1/source-review.json')['status'] == 'clear'
assert read('final-validation-review-1/rust-review.json')['status'] == 'clear'
replay = read('root/replay-validation.json')
assert replay['status'] == 'pass'
assert replay['exact_cases'] == 842 and replay['exact_controls'] == 254

full = dict(default=check('default-full-2', 3124), host_vulkan=check('host-vulkan-full-1', 3478))
assert all(row['filtered'] == 0 for row in full.values())
strict = {label: check(label) for label in ['clippy-msrv-1', 'clippy-host-vulkan-1', 'format-check-1', 'host-release-1']}
focused = {label: check(label, total) for label, total in [('candidate-public-3', 21), ('candidate-private-1', 12), ('candidate-pages-1', 2)]}
peer_paths = [
    'production-review-1/source-review.json',
    'production-1/layout-resource-source-review.json',
    'migrations-outline-1/layout-review.json',
    'tests-correction-1/html-review.json',
    'tests-layout-actual-1/html-review.json',
    'abort-tests-before-1/layout-review.json',
    'private-tests-outline-2/html-review.json',
    'page-tests-before-1/layout-review.json',
    'candidate-source-review-1/source-review.json',
    'final-validation-review-1/rust-review.json',
]
for name in peer_paths:
    assert read(name)['status'].startswith('clear'), name

ledger = dict(
    status='verified', base='c97b200c9bddf1527cdbbc5a652beedba27c1d6d',
    scope='Implement generic Promise.allSettled with ordered outcome snapshots, shared per-element completion gates, iterator-close semantics and terminal resource/unsupported behavior.',
    source=bind(A / 'source-final.json'), parent_source=bind(A / 'parent-source.json'),
    selected_source_inputs=1549, changed_source_paths=changed,
    production_paths=7, existing_test_migration_paths=14,
    additional_existing_registration_paths=2, new_source_or_fixture_paths=9,
    resource_change=dict(raw_startup_before=99786, raw_startup_after=99973,
        additional_work=187, remaining_before=214, remaining_after=27,
        instruction_limit=100000, heap_limit_bytes=8388608,
        objects_before=751, objects_after=752, native_registry_entries=299,
        prototypes=25, globals=212, standalone_installer_work=1570,
        shared_installer_work=1532, producer_plus_shared_installer_work=1863,
        producer_work=331, method_bag=751,
        qualification='Abstract work and heap accounting, not CPU timing, RSS or Chromium performance. Existing object IDs and registry sizes are preserved; the method adds one metadata object under unchanged caps.'),
    selected_fees=dict(all_settled_body=16, public_wrapper=8, paired_callbacks_warm=252,
        duplicate_gate=12, first_completion_validation=14, snapshot_fixed=17,
        prototype_lookup_current=22, warm_snapshot_fulfill=137,
        warm_snapshot_reject=138, first_completion_fulfill=163, first_completion_reject=164),
    layout=dict(parent_mirror_configurations=4, rows_per_configuration=18,
        permanent_actual_groups=1, state_bytes=256, callback_kind_bytes=16,
        callback_record_bytes=24, runtime_default_bytes=1808, runtime_host_bytes=1872,
        qualification='x86_64 Linux compiler/feature observations and permanent actual-type assertions. No new State field, arena, queue field or runtime-header charge; not a stack/RSS bound.'),
    new_tests=dict(groups=35, public_semantic_groups=15, terminal_groups=5,
        terminal_scripts=12, terminal_mode_attempts=24, terminal_sticky_readbacks=48,
        private_groups=12, private_operation_rows=138, actual_layout_groups=1,
        page_worker_groups=2, page_worker_layout_render_calls=24,
        parent_public_expected_failures=15, parent_page_worker_expected_failures=2,
        parent_temporary_layout_passes=4),
    parent_validation=bind(A / 'root/parent-validation-1.json'),
    page_validation=bind(A / 'root/page-validation-1.json'), focused=focused,
    full_suites=full, new_test_groups=35, existing_renames=7,
    roster_peer=bind(A / 'final-validation-review-1/rust-review.json'),
    strict_checks=strict, source_peers=[bind(A / name) for name in peer_paths],
    release_binary=replay['binary'], replay=bind(A / 'root/replay-validation.json'),
    exact_case_records=842, exact_harness_records=254, baseline_changes=0,
    qualifications=[
        'The 1549-entry selected map preserves all1540 parent inputs and adds nine files. It is not a complete dependency/build-graph inventory.',
        'Each of the15 original public parent groups stopped at its first sloppy-mode failure; strict parent rows were not reached. The original invalid descriptor setup did not reach its setup on the method-absent parent.',
        'Public candidate-public-1 was a misnamed unchanged-parent replay after a pre-mutation importer status-string assertion failed. Actual first imported candidate execution is candidate-public-2. The import-attempt receipt preserves this distinction.',
        'Candidate-public-2 passed15 groups and failed one invalid test fixture: an ordinary accessor descriptor inherited value and correctly triggered TypeError. The selected correction uses a null-prototype descriptor. All expected result strings and the other13 public fixtures are unchanged; original hold/failure and peer correction are retained.',
        'Private hold2 adds one spare object slot after fixture callback allocation, correcting a source-review finding before private execution. All138 selected operation rows and cuts are unchanged. Original hold and exact correction are retained.',
        'The five terminal groups were authored after production import and were not executed on the parent. The twelve private groups depend on new internals and were not parent-executable.',
        'The first default full attempt ran inside the tool sandbox:2776 library groups passed and eight local TCP preflights failed with PermissionDenied; later integration targets were not reached. The unchanged-source escalated default-full-2 and host-vulkan-full-1 execute all tests successfully, including ignored groups.',
        'The first parent Page command stopped before worker after its intended Page failure; the worker was then run separately. Both routes pass on the candidate with disabled-script controls and exact procedural pixel/hit/title/task observations.',
        'Six files changed through formatting after selected raw imports; formatter diffs and pre-format bytes are retained. No expected observation changed through formatting.',
        'Existing profile case and harness arrays are byte-content equivalent to the published parent; binary identity changes. No conformance baseline was edited.',
    ],
    limitations=[
        'No upstream Promise.allSettled corpus/profile result is included in this implementation checkpoint.',
        'The three existing Promise profiles still contain their recorded failed and unsupported cases.',
        'Page/worker packed-plan comparisons execute CPU reference rasterization; no GPU or Chromium-speed claim is made.',
        'Resource-limit and isolation tests are bounded validation, not a general security proof.',
        'Full web compatibility and the overall browser objective remain incomplete.',
    ],
)
destination = A / 'root/final-validation.json'
assert not destination.exists()
destination.write_text(json.dumps(ledger, indent=2) + '\n')
print(json.dumps(dict(status=ledger['status'], changed=len(changed), default=3124,
    host_vulkan=3478, cases=842, controls=254)))
