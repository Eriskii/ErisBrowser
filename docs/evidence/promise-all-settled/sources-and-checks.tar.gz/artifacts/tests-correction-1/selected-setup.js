var setterDescriptor = O.create(null);
setterDescriptor.set = function () { setterCalls++; };
setterDescriptor.configurable = true;
O.defineProperty(op, 'status', setterDescriptor);
O.defineProperty(op, 'value', setterDescriptor);
O.defineProperty(op, 'reason', setterDescriptor);
