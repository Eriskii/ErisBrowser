from pathlib import Path
import hashlib,json,difflib,re
P=Path('/tmp/eris-promise-all-settled-plan-1');D=P/'tests-correction-1'
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def refs(v):
 if isinstance(v,dict):
  if all(k in v for k in ('path','bytes','sha256')):
   x=bind(v['path']);assert (x['bytes'],x['sha256'])==(v['bytes'],v['sha256']),v['path']
  for k,x in v.items():
   if k != 'parent_source':refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
h=json.loads((D/'source-ready.json').read_text());refs(h)
old_setup=(D/'original-setup.js').read_text();new_setup=(D/'selected-setup.js').read_text()
for s in h['selections']:
 old=Path(s['before']['path']).read_text();new=Path(s['raw']['path']).read_text()
 assert old.count(old_setup)==new.count(new_setup)==1 and old.replace(old_setup,new_setup)==new
 assert new.replace(new_setup,old_setup)==old
 assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+h['path'],tofile='b/'+h['path']))==Path(s['diff']['path']).read_text()
 a=re.findall(r'r###"(.*?)"###',old,re.S);b=re.findall(r'r###"(.*?)"###',new,re.S)
 assert len(a)==len(b)==28 and [i for i,(x,y) in enumerate(zip(a,b)) if x!=y]==[24]
 assert re.findall(r'Value::String\("(.*?)"\.into\(\)\)',old)==re.findall(r'Value::String\("(.*?)"\.into\(\)\)',new)
 assert old.count('#[test]')==new.count('#[test]')==14
 assert (s['parent_source']['bytes'],s['parent_source']['sha256'])==(s['before']['bytes'],s['before']['sha256'])
 if s['label']=='original-held':assert old==Path(s['parent_source']['path']).read_text()
 else:assert Path(s['parent_source']['path']).name == Path(s['raw']['path']).name
for ext in ['json','log']:
 assert (D/'retained'/('candidate-public-2.'+ext)).read_bytes()==(P/'validation'/('candidate-public-2.'+ext)).read_bytes()
receipt=json.loads((D/'retained/candidate-public-2.json').read_text());assert receipt['exit']==101
log=(D/'retained/candidate-public-2.log').read_text();assert '15 passed; 1 failed;' in log and 'descriptor cannot contain data and accessors' in log
source=(P/'worktree/src/script.rs').read_text();held=(D/'property_descriptor-source.txt').read_text();assert held in source
review={'status':'clear','scope':'Narrow setup correction with original failure and prior mistaken literal clearance retained.','hold':bind(D/'source-ready.json'),'checker':bind(D/'html-check.py'),'original_review':bind(P/'tests-before-1/html-review.json'),'retained_failure':{'receipt':bind(D/'retained/candidate-public-2.json'),'log':bind(D/'retained/candidate-public-2.log')},'source_mechanism':bind(D/'property_descriptor-source.txt'),'primary_url':'https://tc39.es/ecma262/multipage/ecmascript-data-types-and-values.html#sec-topropertydescriptor','diagnosis':'The third ordinary descriptor inherits Object.prototype.value after the second poison installation. The inherited setter has no getter, but HasProperty still supplies a present value field containing undefined; combining that data field with the own set accessor field requires TypeError before saved callbacks run.','correction':'Reuse a null-prototype object with own set/configurable for all three poison installations. Descriptor conversion has no inherited data field; setters/configuration, subsequent global replacement, callbacks, cleanup and readback are preserved.','checks':{'both_selections_exact_inverse':True,'changed_source_literal_count':1,'other_source_literals_unchanged':13,'all14_readbacks_and_expected_values_unchanged':True,'supplement_unchanged':True,'registration_changes':0,'production_changes':0,'archived_before_matches_recorded_parent_binding':True,'retained_failure_hashes_match':True,'first_failed_group':'promise_all_settled_snapshot_shape_intrinsics_and_undefined','first_failed_mode':'sloppy source setup','later_readback_and_strict_mode_unreached_in_failed_run':True},'prior_review_qualification':'My original source-clear literal receipt missed this inherited-descriptor setup defect. That receipt remains unchanged and is qualified by this additive finding/correction review; the original held fixture and observed first failure remain archived.','live_binding_qualification':'Root imported and formatted the selected correction during review. The candidate-formatted parent-source record is joined to its archived before bytes; current formatted composition is outside this external correction review. Inert checker attempts stopped at stale live-byte assertions before creating a receipt; only the checker was corrected to respect the immutable hold scope.','findings':[],'execution':'Primary standard/source inspection and inert stdlib/hash/diff checks only. Corrected fixture not executed by peer; no project execution or live edits.'}
(D/'html-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(D/'html-review.json'),indent=2))
