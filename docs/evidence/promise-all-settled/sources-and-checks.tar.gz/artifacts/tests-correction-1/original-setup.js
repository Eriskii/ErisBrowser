O.defineProperty(op, 'status', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'value', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'reason', {set:function () { setterCalls++; }, configurable:true});
