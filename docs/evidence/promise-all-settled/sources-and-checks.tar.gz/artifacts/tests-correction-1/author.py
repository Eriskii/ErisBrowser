"""Narrow source-only correction of the poisoned-descriptor test setup."""
from pathlib import Path
import json, hashlib, difflib, re

P=Path('/tmp/eris-promise-all-settled-plan-1')
OUT=P/'tests-correction-1'
REL='src/script/promise_all_settled_semantic_tests.rs'
def put(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(p,o):put(p,json.dumps(o,indent=2)+'\n')
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

old="""O.defineProperty(op, 'status', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'value', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'reason', {set:function () { setterCalls++; }, configurable:true});
"""
new="""var setterDescriptor = O.create(null);
setterDescriptor.set = function () { setterCalls++; };
setterDescriptor.configurable = true;
O.defineProperty(op, 'status', setterDescriptor);
O.defineProperty(op, 'value', setterDescriptor);
O.defineProperty(op, 'reason', setterDescriptor);
"""
expected='0|true|true|true|status,value|status,reason|true|true'
original=P/'tests-before-1/raw'/REL
formatted=P/'worktree'/REL
selections=[]
for label,source in [('original-held',original),('candidate-formatted',formatted)]:
    before=source.read_text()
    assert before.count(old)==1 and before.count(expected)==1
    after=before.replace(old,new)
    assert after.replace(new,old)==before and before.count('#[test]')==after.count('#[test]')==14
    # Every assertion/expected Value, readback and Rust test signature is exact.
    assert re.findall(r'Value::String\([^\n]*',before)==re.findall(r'Value::String\([^\n]*',after)
    assert re.findall(r'^fn promise_all_settled_.*',before,re.M)==re.findall(r'^fn promise_all_settled_.*',after,re.M)
    b=OUT/'before'/label/REL;r=OUT/'raw'/label/REL;d=OUT/'diffs'/(label+'.patch')
    put(b,before);put(r,after)
    put(d,''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+REL,tofile='b/'+REL)))
    selections.append(dict(label=label,parent_source=bind(source),before=bind(b),raw=bind(r),diff=bind(d)))

cases=json.loads((P/'draft-1/semantic-cases.json').read_text())['cases']
target=next(c for c in cases if c['id']=='snapshot_shape_intrinsics_and_undefined')
assert target['source'].count(old)==1 and target['expected']==expected
corrected=dict(target,source=target['source'].replace(old,new))
js(OUT/'selected-case.json',corrected)
js(OUT/'original-case.json',target)
put(OUT/'original-setup.js',old);put(OUT/'selected-setup.js',new)

failed_receipt=P/'validation/candidate-public-2.json';failed_log=P/'validation/candidate-public-2.log'
receipt=json.loads(failed_receipt.read_text());log=failed_log.read_text()
assert receipt['exit']==101 and receipt['sha256']==bind(failed_log)['sha256']
assert '15 passed; 1 failed' in log and 'descriptor cannot contain data and accessors' in log
put(OUT/'retained/candidate-public-2.json',failed_receipt.read_text())
put(OUT/'retained/candidate-public-2.log',log)
script=P/'worktree/src/script.rs';text=script.read_text()
start=text.index('    fn property_descriptor(');end=text.index('    fn define_own(',start)
descriptor=text[start:end]
put(OUT/'property_descriptor-source.txt',descriptor)
assert 'self.find_property_in(&object, &key.into(), doc)?.is_none()' in descriptor
assert 'desc.value = Some(value)' in descriptor and 'desc.accessor() && desc.data()' in descriptor

js(OUT/'reason.json',dict(
    diagnosis='The original fixture setup is invalid under ordinary inherited descriptor conversion; the observed TypeError is required for that setup and is not evidence of an allSettled implementation defect.',
    source_mechanism=[
        'First status accessor installation is valid; it adds no descriptor-named property.',
        'Second value accessor installation is valid, then makes value visible through Object.prototype to every subsequent ordinary descriptor object.',
        'Third reason descriptor has own set/configurable but inherits value. HasProperty(value) is true even though the inherited accessor has no getter, so Get produces undefined and still records a data Value field.',
        'Its own set records an accessor field; mixed data/accessor rejection is therefore mandated before any saved callback executes.',
        'A reusable descriptor whose prototype is null has only own set/configurable. It cannot inherit value after the second installation. Each of the three poison accessors still calls the same setterCalls counter and is configurable; poison coverage and cleanup order are preserved.'
    ],
    primary=dict(url='https://tc39.es/ecma262/multipage/ecmascript-data-types-and-values.html#sec-topropertydescriptor',accessed='2026-10-15',
        synopsis='ToPropertyDescriptor uses HasProperty for descriptor fields, including inherited fields. It records a Value field when value exists, even if Get returns undefined. A simultaneous getter/setter field and Value/Writable field requires TypeError. A null-prototype descriptor avoids inherited fields.'),
    correction_scope='One setup block in one source literal, in both original-held and candidate-formatted module selections. Exact result string, all readbacks/Rust assertions, remaining13 source literals and all15 public group counts unchanged.',
    original_review_qualification='Original author/peer literal review missed this descriptor-inheritance setup edge. Missing-method parent runs failed before it; the candidate reached it. Original hold, original peer and failed receipt remain retained.',
    expected=expected,semantic_oracle_changed=False,production_changed=False,
    public_groups=15,corrected_module_groups=14,
    retained_failure=dict(receipt=bind(failed_receipt),log=bind(failed_log)),
    verification='Read-only source/spec inspection plus exact inverse/literal comparisons. Corrected source has not been executed by this author.'))
js(OUT/'source-bindings.json',dict(
    original_hold=bind(P/'tests-before-1/source-ready.json'),original_peer=bind(P/'tests-before-1/html-review.json'),
    original_cases=bind(P/'draft-1/semantic-cases.json'),original_semantic_peer=bind(P/'draft-1/layout-semantic-review.json'),
    actual_candidate_inputs=bind(P/'source-candidate-1.json'),
    descriptor_source_file=bind(script),descriptor_extraction=bind(OUT/'property_descriptor-source.txt')))
put(OUT/'notes.txt','''Explicit correction of a preexisting test setup defect, not production behavior or an expected outcome adjustment. The old ordinary reason descriptor inherits the value accessor installed immediately before it and necessarily triggers mixed data/accessor TypeError. Original author/peer reviews and reached candidate failure are preserved.
The sole correction prepares one reusable null-prototype accessor descriptor before any poisoning and supplies it to all three existing defineProperty calls. Own set/configurable values match the prior intended descriptors; inherited status/value/reason setters remain in place for both snapshot callbacks. There is no production fix, no weakened assertion and no new fee/budget change. The original frozen expected result remains exact.
Two raw compositions are supplied: original-held for immutable test lineage, candidate-formatted for root's current source import. Their exact inverse differs only in the same setup block. Root should import the candidate-formatted choice only after its before hash matches, preserving all other source. No registration changes.
No engine/compiler/formatter/browser/Git/project execution or live edits; external stdlib hashes/diffs and official primary retrieval only.
''')
js(OUT/'source-ready.json',dict(status='sealed_narrow_fixture_correction_pending_peer_and_execution',
    path=REL,selections=selections,preferred_import='candidate-formatted',changed_groups=1,
    exact_expected=expected,all_prior_expectations_preserved=True,production_edits=0,
    files=[bind(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='source-ready.json'],
    execution='Source/spec review and external stdlib only; no live changes/project execution.'))
print(json.dumps(bind(OUT/'source-ready.json')))
