from pathlib import Path
import json,hashlib
P=Path('/tmp/eris-promise-all-settled-plan-1/draft-2');R=Path('/tmp/eris-text-metadata-keys-1/worktree'); AY=R.parent

def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,v): (P/n).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
proof={
 'status':'concrete_fixed_envelope_proposal_not_yet_selected',
 'basis':'New constants are bounded abstract accounting-policy envelopes tied to explicit source operations, owner moves and direct-handle releases. They are not CPU instruction counts or timings. Existing helper tariffs are exact source facts; later selected tests and production source must corroborate the proposed sequence. No production implementation is authored.',
 'pseudocode':bind(P/'pseudocode.txt'),
 'constants':{'public_operation_existing':8,'body_proposed':16,'duplicate_gate_proposed':12,'first_completion_extra_proposed':14,'snapshot_prefix_proposed':17,'pair_existing_N2_base':252},
 'body16':{
  'control8':{'lines':['B01','B02','B04','B05','B07','B11'],'proof':'Same fixed all orchestration envelope: capability destructure, resolve callability, acquired-object check/record setup, normal done, terminal classification, conditional close and single reject/return. Existing helper/author work is additional. Pair handling adds no branch: replace one callback plus reject clone with an N=2 factory tuple.'},
  'cleanup8':{'charged_at':'B00','roles':['constructor C','items during acquisition','cached promiseResolve','capability.promise','capability.reject','iterator value','cached next value','pending error/rejection completion'],'proof':'Exactly the eight existing all roles. new_all_group18 separately funds transferred capability.resolve and Group/list ownership. Race17 retains resolve and therefore is not this body model. No refund for absent/transferred roles.'},
  'loop':'The unchanged attempt8 owns step result, done value, nextPromise and ignored then return. Factory15 per callback owns each fresh callable temporary; the old capability.reject per-element clone is absent, not silently free.',
  'copy_sites':{'before_capability':1,'before_resolve_Get':1,'before_items':1,'before_next_Get':1,'per_iterator_attempt_cached_next_and_iterator':2,'per_valid_step_done_receiver':1,'per_element_cached_resolve_and_C':2,'per_element_then_Get_receiver':1},
  'refusal':'Incoming C/borrowed args already have existing caller ownership before body admission. Later terminal failures propagate without author cleanup. Existing Call/Construct/Get/exception and argument helper charges remain reached separately.'
 },
 'gate12':{
  'rows':[{'work':8,'lines':['C01'],'covers':'Direct Element ID/variant validation under existing check8 convention.'},{'work':2,'lines':['C03'],'covers':'Copy only group ID/index scalars and end borrow.'},{'work':1,'lines':['C02'],'covers':'Inspect called bit before any Group access.'},{'work':1,'lines':['C02','C12'],'covers':'Bounded branch/result bookkeeping, including duplicate None.'}],
  'proof':'Identical inspection envelope and duplicate ordering to old complete_all_element. No payload retain or snapshot allocation; completed Group may already have empty moved-out values.'
 },
 'first14':{
  'rows':[{'work':8,'lines':['C05','C06'],'covers':'Direct Group/variant/index/admission and checked remaining-1 proof; zero requires input_done; scalar staging before mutation.'},{'work':2,'lines':['C09'],'covers':'Move returned snapshot into reserved slot and release old slot payload.'},{'work':2,'lines':['C07','C10'],'covers':'Publish shared called bit and prepared remaining count, at distinct required phases.'},{'work':2,'lines':['C11'],'covers':'On readiness, move resolve and take/reset the entire values Arena; owner credits transfer to Ready.'}],
  'delta_from_old16':'Old C6 payload clone+eventual release2 is removed from this NEW path because S12/S00 owns it inside the result bag. All other old first-completion operation classes remain. The old all helper still charges16 and is untouched.',
  'ownership':'The snapshot helper returns a funded Value::Object owner; C09 moves it without a clone. Existing Group/placeholder credits plus S00 snapshot/payload credits travel with their owners. No newly fallible work occurs between successful S14 and C09–C12.',
  'gate_timing':'Pay both12 and14 before C07; then consume the bit before all snapshot work. Ordinary spec snapshot creation has no author callback or catchable property failure; host resource refusals after C07 leave it consumed and stop the host.'
 },
 'snapshot17':{
  'rows':[{'work':8,'lines':['S01','S03','S14'],'covers':'Fixed snapshot entry/type branch, saved intrinsic existence/range proof, scalar bag/prototype staging and result plumbing. The B-tree search and helper work are separate.'},{'work':1,'lines':['S04'],'covers':'Construct checked object-slot plan; its variable movement/backing fees remain additional.'},{'work':1,'lines':['S06'],'covers':'One conditional reserve stage and its fixed result handling, including warm branch.'},{'work':1,'lines':['S12'],'covers':'Exactly one payload Value clone, paid before it occurs.'},{'work':6,'lines':['S07','S08','S09','S10','S12','S14'],'covers':'Six direct handle cleanup roles, named below, prepaid before acquisition.'}],
  'cleanup_roles':[{'owner':'prototype Value::Object','acquired':'S07','transfer':'ordinary result bag prototype; scalar conservative cleanup credit'},{'owner':'status key','acquired':'S08','transfer':'S11 consumes it into the existing property helper; helper internal key clones retain their existing tariff'},{'owner':'status string Value','acquired':'S09','transfer':'S11 own data property; early failure drops same handle'},{'owner':'payload key','acquired':'S10','transfer':'S13 consumes into existing property helper; its internal key clones remain charged there'},{'owner':'retained payload Value','acquired':'S12','transfer':'S13 result data property; failed insertion drops it using this credit'},{'owner':'returned record Value::Object','acquired':'S14','transfer':'C09 Group slot then final array; scalar conservative cleanup credit'}],
  'not_double_charged':'S12 clone and retained-payload release replace the removed2 from new first14. Existing text copy, B-tree compare/movement/clone, metadata bag order allocation and slot backing accounting are not replaced or refunded. Scalar Object handles conservatively retain direct cleanup credits, without a claim of resident allocation.',
  'lookup':'L=install::tree(prototypes.len()).0; Object key length6 makes factor1. Private visibility-only access to unchanged tree body is proposed. Use saved map, never mutable global Object or DOM-only interface lookup. Charge L before lookup, check absent/out-of-range ID under S00 check8.',
  'work':'17 + L + object_slot_plan.work +98 fulfilled /99 rejected',
  'heap':'object_slot_plan.bytes + (900 fulfilled /904 rejected) +A+D+2K+Bpp',
  'staging':'Prefix only prepays its fixed owners/checks. Slot work/heap precede reserve; bag/text/property helpers keep their staged work/heap schedule. A later refusal may leave an unexposed empty or status-only object, but never a partially committed Group slot.'
 },
 'pair252':{'formula':'2*15 +20 +2*101 =252, plus existing callback/AllCapture/object-slot growth work; metadata heap twice904+A+D+2K+Bpp+N plus plans','source_fit':'Existing N=2 resolving/finally routes already prepare two scalar kinds. Each callback9 admit/publish envelope covers that callable kind/record handling;6 direct temporary releases remain per callable. Original AllElement20 proof is retained conservatively, including its first-tag preparation wording. No old scalar credit is refunded or relabelled as a machine-instruction count.','state':'One shared Element and one remaining+1, two unique callback metadata bags/records; no new capture field or allocation plan.'},
 'shared_helpers_unchanged':['new_all_group18','append_all_placeholder12','finish_all_input16','all_iterator_step attempt8 plus clones2/1','new_all_values_array23 plus growth and bag9','promise_arguments N1=10/N2=12','callback_target actual8+2*bit_length(records) search','new_promise_capability and ordinary Get/Call/Construct/exception tariffs','observe_microtask_failure sticky state recording'],
 'layout':'AllCapture, State and Runtime fields are unchanged by design; CallbackKind adds two same-ID payload variants. Exact actual CallbackKind/CallbackRecord widths and downstream job/header/stack shapes still require full enum mirror then actual type measurement on supported toolchains/features. No new width or startup heap outcome is frozen here.',
 'cleanup_limit':'Credits cover direct owned Value/Rc handles and existing prepaid container/element teardown. They do not prove arbitrary inherited Native.receiver graphs have constant recursive drop depth. No native stack/RSS claim or allowance increase.'
}
assert sum(r['work'] for r in proof['gate12']['rows'])==12
assert sum(r['work'] for r in proof['first14']['rows'])==14
assert sum(r['work'] for r in proof['snapshot17']['rows'])==17
put('fee-proof.json',proof)
