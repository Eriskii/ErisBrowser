from pathlib import Path
import hashlib,json,re,difflib
B=Path('/tmp/eris-promise-all-settled-plan-1');W=B/'worktree';OUT=B/'candidate-source-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
expected={};origins={}
def use(rel,path):expected[rel]=path.read_bytes();origins[rel]=[binding(path)]
def append(rel,path):expected[rel]+=path.read_bytes();origins[rel].append(binding(path))
prod=json.loads((B/'production-1/source-ready.json').read_text())
for f in prod['files']:
 for k in ['raw','before','diff']:assert binding(Path(f[k]['path']))==f[k]
 use(f['relative_path'],Path(f['raw']['path']))
append('src/script/promises.rs',B/'tests-layout-actual-1/registration-append.txt')
append('src/script/promises/all_state.rs',B/'private-tests-outline-1/registration.txt')
mig=json.loads((B/'migrations-outline-1/ledger.json').read_text())
for row in mig['migrations']:use(row['relative_path'],Path(row['raw']['path']))
use('src/script.rs',B/'tests-before-1/before/src/script.rs')
for rel in ['tests-before-1/registrations/public-append.txt','tests-supplement-1/registration-append.txt','abort-tests-before-1/registration-append.txt']:append('src/script.rs',B/rel)
use('src/script/promise_all_settled_semantic_tests.rs',B/'tests-correction-1/raw/original-held/src/script/promise_all_settled_semantic_tests.rs')
for rel,hold in [('src/script/promise_all_settled_supplemental_tests.rs','tests-supplement-1'),('src/script/promise_all_settled_abort_tests.rs','abort-tests-before-1'),('src/script/promises/all_settled_layout_tests.rs','tests-layout-actual-1'),('src/script/promises/all_state/all_settled_quota_tests.rs','private-tests-outline-2')]:use(rel,B/hold/'raw'/rel)
page=json.loads((B/'page-tests-before-1/source-ready.json').read_text())
for row in page['files']:use(row['relative_path'],Path(row['raw']['path']))
parent=json.loads((B/'parent-source.json').read_text())['source_sha256'];candidate=json.loads((B/'source-candidate-3.json').read_text())['source_sha256']
assert len(parent)==1540 and len(candidate)==1549
assert set(parent)<=set(candidate)
changes={k for k,v in candidate.items() if parent.get(k)!=v};assert changes==set(expected),(changes-set(expected),set(expected)-changes)
assert len(expected)==32
for rel,h in candidate.items():assert sha((W/rel).read_bytes())==h,rel
assert 'src/script/promises/all_settled_layout_probe.rs' not in candidate
assert not (W/'src/script/promises/all_settled_layout_probe.rs').exists()
assert 'mod all_settled_layout_probe;' not in (W/'src/script/promises.rs').read_text()
fmt=json.loads((B/'root/formatting.json').read_text());byfmt={r['path']:r for r in fmt['files']};assert len(byfmt)==6
rows=[]
for rel,b in expected.items():
 actual=(W/rel).read_bytes();same=b==actual
 if not same:
  f=byfmt[rel];assert sha(b)==f['before'];assert sha(actual)==f['after'];assert sha(Path(f['diff']).read_bytes())==f['diff_sha256']
  delta=''.join(difflib.unified_diff(b.decode().splitlines(True),actual.decode().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
  assert delta==Path(f['diff']).read_text(),rel
 rows.append({'path':rel,'selected_sources':origins[rel],'composed_raw_sha256':sha(b),'candidate_sha256':sha(actual),'byte_exact':same})
assert {r['path'] for r in rows if not r['byte_exact']}==set(byfmt)
# Rust lexical view for the six format diffs: retain exact string/character literals,
# identifiers, numbers and punctuation; omit comments and layout whitespace.
TOKEN=re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<h>\#*)".*?"(?P=h)|b?"(?:\\.|[^"\\])*"|b?\'(?:\\.|[^\'\\])\'|[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*|\s+|.',re.S)
def tokens(text):
 result=[]
 for m in TOKEN.finditer(text):
  t=m.group();
  if t.isspace() or t.startswith('//') or t.startswith('/*'):continue
  result.append(t)
 return [t for i,t in enumerate(result) if not (t==',' and i+1<len(result) and result[i+1] in [')',']','}'])]
changes=[]
for rel in byfmt:
 a=tokens(expected[rel].decode());z=tokens((W/rel).read_text())
 delta=[{'tag':tag,'before':a[i:j],'after':z[k:l]} for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=z,autojunk=False).get_opcodes() if tag!='equal']
 changes.append({'path':rel,'token_delta_after_trailing_comma_normalization':delta})
(OUT/'composition.json').write_text(json.dumps({'inventory_count':1549,'changed_paths':32,'new_inputs':len(set(candidate)-set(parent)),'unchanged_parent_inputs':len(candidate)-len(expected),'files':rows,'format_token_changes':changes},indent=2)+'\n')
print(json.dumps(changes,indent=2))

# The only non-trivia formatter edits are expression-block wrappers.
for rel in byfmt:
 a=expected[rel].decode()
 if rel=='src/script/promises/all_semantics.rs':
  a=a.replace('.ok_or_else(|| ScriptError::type_error("Promise.allSettled input is not iterable"))?', '.ok_or_else(|| { ScriptError::type_error("Promise.allSettled input is not iterable") })?')
 if rel=='src/script/promises/all_state/all_settled_quota_tests.rs':
  for label,index in [('1','0'),('3','id.0')]:
   before=f'{label} => runtime.promises.all_captures.records[{index}] = AllCapture::Element {{ group: id, index: 0, called: false }},'
   after=f'{label} => {{ runtime.promises.all_captures.records[{index}] = AllCapture::Element {{ group: id, index: 0, called: false }} }}'
   assert a.count(before)==1
   a=a.replace(before,after)
 assert tokens(a)==tokens((W/rel).read_text()),rel

new_test_paths=['src/script/promise_all_settled_semantic_tests.rs','src/script/promise_all_settled_supplemental_tests.rs','src/script/promise_all_settled_abort_tests.rs','src/script/promises/all_state/all_settled_quota_tests.rs','src/script/promises/all_settled_layout_tests.rs','tests/promise_all_settled.rs','tests/worker/promise_all_settled.rs']
roster=[]
for rel,count in zip(new_test_paths,[14,1,5,12,1,1,1]):
 names=re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn\s+(\w+)',(W/rel).read_text())
 assert len(names)==count,(rel,len(names),count)
 roster.append({'path':rel,'groups':names})
assert sum(len(r['groups']) for r in roster)==35
(OUT/'new-roster.json').write_text(json.dumps({'new_groups':35,'modules':roster},indent=2)+'\n')
