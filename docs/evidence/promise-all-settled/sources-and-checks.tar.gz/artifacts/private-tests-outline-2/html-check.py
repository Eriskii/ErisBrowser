from pathlib import Path
import hashlib,json,re,difflib
P=Path('/tmp/eris-promise-all-settled-plan-1');D=P/'private-tests-outline-2';A=P/'private-tests-outline-1'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
count=0
def check_refs(v):
 global count
 if isinstance(v,dict):
  if all(k in v for k in ('path','bytes','sha256')):
   b=bind(v['path']);assert(b['bytes'],b['sha256'])==(v['bytes'],v['sha256']),v['path'];count+=1
  for x in v.values():check_refs(x)
 elif isinstance(v,list):
  for x in v:check_refs(x)
h=json.loads((D/'source-ready.json').read_text());prior=json.loads((A/'source-ready.json').read_text())
check_refs(h);check_refs(prior);check_refs(json.loads((A/'source-bindings.json').read_text()))
old=Path(h['replacement']['before']['path']).read_text();new=Path(h['replacement']['raw']['path']).read_text()
addition='            // Pair metadata consumed its two reserved slots; this cut measures a warm snapshot.\n            runtime.objects.try_reserve_exact(1).unwrap();\n            assert!(runtime.objects.capacity() > runtime.objects.len());\n'
assert new.count(addition)==1 and new.replace(addition,'')==old
rel=h['replacement']['relative_path']
assert ''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='hold1/'+rel,tofile='hold2/'+rel))==Path(h['replacement']['diff']['path']).read_text()
roster=json.loads((A/'roster.json').read_text());names=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',new)
assert names==[r['name'] for r in roster['rows']]
assert len(names)==roster['groups']==12
assert [r['measured_operations'] for r in roster['rows']]==[12,6,9,3,14,40,16,10,12,8,4,4]
assert sum(r['measured_operations'] for r in roster['rows'])==138
outline=json.loads((A/'literal-outline.json').read_text());ledger=json.loads((A/'ledger.json').read_text())
assert outline['pair']['warm']==50+2*101==252
assert outline['snapshots']['direct_exact']==[17+22+98,17+22+99]
assert outline['snapshots']['completion_exact']==[12+14+137,12+14+138]
assert ledger['cuts']['native_dispatch_at_two_records']==[12+163,12+164]
assert ledger['cuts']['duplicate_dispatch']==12+12
expectedF=[11,12,25,26,42,43,64,65,73,74,93,94,119,120,137,138,146,147,162,163]
expectedR=[11,12,25,26,42,43,64,65,73,74,93,94,117,118,137,138,146,147,163,164]
assert [r['work'] for r in outline['work_rows']['fulfilled']]==expectedF
assert [r['work'] for r in outline['work_rows']['rejected']]==expectedR
assert (A/'registration.txt').read_text()=='\n#[cfg(test)]\nmod all_settled_quota_tests;\n'
review={
 'status':'clear','scope':'Selected hold2 plus inherited hold1: twelve API-dependent private groups and 138 planned measured operations; source-only review, not an execution result.',
 'selected_hold':bind(D/'source-ready.json'),'retained_original_hold':bind(A/'source-ready.json'),'selected_raw':bind(h['replacement']['raw']['path']),'checker':bind(D/'html-check.py'),
 'mechanical_checks':{'verified_binding_occurrences':count,'exact_correction_inverse':True,'exact_diff':True,'exact_group_names_and_operation_counts':True,'unchanged_registration_api_ledger_oracles_source_bindings':True},
 'fixed_finding':{'original_problem':'pair_fixture reserves two object slots, both consumed by new_all_settled_elements; the subsequent measured snapshot had no guaranteed spare slot.','selected_fix':'After pair creation and before the first-dispatch budget reset, reserve and assert one spare object slot. The opposite duplicate branch and all cuts remain unchanged.','prior_hold_retained':True,'no_expectation_changes':True},
 'fee_checks':{'direct_body_and_public_prefixes':'Direct 15/16/17/18 refuse; 19 reaches ordinary TypeError. Public wrapper adds 8, with separate 7/8 cuts; direct helper does not promise wrapper suspension.','pair':'Warm 50+2*101=252; cold costs add existing AllCapture len1 and callback len0 growth. Aggregate slot/growth admission precedes metadata; Element/callback/group publication follows both metadata constructions.','snapshot':'17 envelope +22 saved Object lookup +98 fulfilled or99 rejected existing helpers =137/138. Typed heap includes one object slot, bag/order keys, property leaf and status/payload strings.','completion':'12 gate +14 first-completion +snapshot =163/164. Called flips at 26; group remains untouched until the complete snapshot exists.','dispatch':'At two callback records lookup12 yields175/176 first and24 duplicate. Selected warm-slot fixture now proves the physical precondition.','staged_work':'Forty source-derived prefix rows distinguish gate consumption, slot admission, bag publication, text charges, first property and complete record.','staged_heap':'Sixteen one-short rows bind actual debit points and unexposed partial bags without retaining the borrowed payload.','existing_all':'Existing first28/duplicate12 costs and no-snapshot behavior remain independently covered.'},
 'ownership_and_refusal_checks':['Fresh Runtime for every terminal refusal; budgets are not reset to retry a failed Runtime.','Warm physical capacity and logical admission are explicit; cold exact-capacity fixtures and reserve probes distinguish actual reached allocation sites.','Three pair reserve sites precede callback/Element publication; reserve failures retain old admissions and group state.','Invalid variant/id/group/index/admission/count cases leave called false; valid duplicate calls return before consulting a deliberately invalid group.','Payload strong counts distinguish success retain from refusal; snapshots use saved intrinsic Object prototype and own data descriptors.','Post-exhaustion Ready transfers the entire values Arena, including allocation/admission, and clears the stored group; opposite duplicates remain harmless.','Private parent-child visibility and new API signatures are valid for the selected implementation; this is not a parent-compatible baseline.'],
 'source_scope':{'selected_draft':bind(P/'draft-2/source-ready.json'),'fee_proof':bind(P/'draft-2/fee-proof.json'),'root_selection':bind(P/'root/selection-1.json'),'published_parent_source_bindings':bind(A/'source-bindings.json')},
 'findings':[],'execution':'Only static source review and inert standard-library hash/diff/integer checks. No compiler, engine, project command or live-source edit by peer; candidate output was not used to derive expectations.'}
(D/'html-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(D/'html-review.json'),indent=2))
