"""Independent inert production source review. Does not import project code."""
from pathlib import Path
import json, hashlib, difflib, re

P=Path('/tmp/eris-promise-all-settled-plan-1')
H=P/'production-1'
OUT=P/'production-review-1'
BASE=Path('/tmp/eris-text-metadata-keys-1/worktree')

def binding(p):
    data=p.read_bytes()
    return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def check_binding(b):
    assert binding(Path(b['path']))==b,b['path']
def save(path,obj):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2)+'\n')
def function(text,name):
    m=re.search(r'(?m)^ *(?:pub(?:\([^)]*\))? )?fn '+name+r'(?:\b|<)',text)
    assert m,name
    start=m.start()
    brace=text.index('{',m.end())
    pos=brace+1; depth=1; state='code'
    while depth:
        a=text[pos]; b=text[pos:pos+2]
        if state=='string':
            if a=='\\': pos+=2; continue
            if a=='"': state='code'
        elif state=='line':
            if a=='\n': state='code'
        elif state=='block':
            if b=='*/': state='code'; pos+=2; continue
        else:
            if b=='//': state='line'; pos+=2; continue
            if b=='/*': state='block'; pos+=2; continue
            if a=='"': state='string'
            elif a=='{': depth+=1
            elif a=='}': depth-=1
        pos+=1
    return start,pos,text[start:pos]
def remove_fn(text,name):
    a,b,_=function(text,name)
    assert text[b:b+2]=='\n\n' or text[b:b+2]=='\n}'
    # A final method before impl closure has only one following newline;
    # remove its preceding separator instead.
    if text[b:b+2]=='\n}':
        assert text[a-1]=='\n'
        return text[:a-1]+text[b+1:]
    return text[:a]+text[b+2:]

manifest=json.loads((H/'source-ready.json').read_text())
inventory=json.loads((BASE.parent/'source-candidate-extended.json').read_text())['source_sha256']
scope=[x['relative_path'] for x in manifest['files']]
assert scope==[
 'src/script/machine/calls.rs','src/script/promises.rs','src/script/promises/all_semantics.rs',
 'src/script/promises/all_state.rs','src/script/promises/factories.rs','src/script/promises/install.rs',
 'src/script/promises/semantics.rs']
parent={}; raw={}; joins=[]
for row in manifest['files']:
    for k in ['before','raw','diff']: check_binding(row[k])
    rel=row['relative_path']
    before=Path(row['before']['path']).read_text(); after=Path(row['raw']['path']).read_text()
    assert row['before']['sha256']==inventory[rel],rel
    expected=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
    assert expected==Path(row['diff']['path']).read_text(),rel
    parent[rel]=before;raw[rel]=after
    joins.append(dict(relative_path=rel,before=row['before'],raw=row['raw'],diff=row['diff'],
        candidate_inventory_join=True,exact_patch_reconstruction=True))
check_binding(manifest['selection'])

inverses=[]
rel='src/script/machine/calls.rs'
assert raw[rel].replace('                    | "Promise.allSettled"\n','')==parent[rel]
inverses.append(dict(path=rel,only_delta='one existing dynamic-receiver Promise operation name arm'))
rel='src/script/promises.rs'
t=raw[rel].replace('METADATA_OBJECTS: usize = 11','METADATA_OBJECTS: usize = 10')
t=t.replace('    AllSettledFulfill(AllCaptureId),\n    AllSettledReject(AllCaptureId),\n','')
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='metadata count10→11 and two callback variants; all field bodies unchanged'))
rel='src/script/promises/all_semantics.rs'
t=remove_fn(remove_fn(raw[rel],'promise_all_settled'),'run_all_settled_callback')
t=t.replace('//! Observable Promise combinator iteration over the realm\'s job machinery.',
    '//! Observable Promise.all and Promise.race iteration over the realm\'s job machinery.')
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='two new methods and descriptive header; complete all/race/iterator/resolve-ready/control bytes exact'))
rel='src/script/promises/all_state.rs'
t=remove_fn(remove_fn(raw[rel],'new_all_settled_snapshot'),'complete_all_settled_element')
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='two new methods; complete existing group/placeholder/complete-all/finish/array/probe helpers exact'))
rel='src/script/promises/factories.rs'
t=remove_fn(raw[rel],'new_all_settled_elements')
t=t.replace('CallbackKind::AllResolve(id)\n                        | CallbackKind::AllSettledFulfill(id)\n                        | CallbackKind::AllSettledReject(id) => matches!(',
    'CallbackKind::AllResolve(id) => matches!(')
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='one paired entry and cfg(test) None validation exhaustiveness; production batch factory unchanged'))
rel='src/script/promises/semantics.rs'
t=raw[rel].replace('                "Promise.allSettled" => self.promise_all_settled(receiver, args, doc),\n','')
t=t.replace('''                CallbackKind::AllSettledFulfill(element) => {
                    return self.run_all_settled_callback(element, ReactionKind::Fulfill, args, doc);
                }
                CallbackKind::AllSettledReject(element) => {
                    return self.run_all_settled_callback(element, ReactionKind::Reject, args, doc);
                }
''','')
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='operation arm and two authenticated callback-kind arms; unchanged wrapper8/callback identity/old branches'))
rel='src/script/promises/install.rs'
t=raw[rel]
replacements=[
 ('pub(super) fn tree(', 'fn tree('),
 ('all fourteen','all thirteen'),('self.work(23)?;','self.work(22)?;'),
 ('twelve pool releases','eleven pool releases'),('self.work(21)?;','self.work(20)?;'),
 ('            self.dom_proto_text("allSettled")?,\n',''),
 ('30 string keys, 10 display names','27 string keys, 9 display names'),
 ('self.work(43)?;','self.work(39)?;'),
 ('self.dom_proto_object(Some(Value::Function(self.function_prototype)), 9)?;',
  'self.dom_proto_object(Some(Value::Function(self.function_prototype)), 8)?;'),
 ('        let all_settled =\n            self.promise_intrinsic_method("Promise.allSettled", pool[13].clone(), 1, keys)?;\n',''),
 ('''        self.dom_proto_property(
            constructor_bag,
            pool[13].clone().into(),
            Property::data(all_settled, true, false, true),
        )?;
''',''),
]
for a,b in replacements:
    assert t.count(a)==1,(a,t.count(a))
    t=t.replace(a,b)
assert t==parent[rel]
inverses.append(dict(path=rel,only_delta='explicit method metadata additions, one release, four clones, order reservation8→9 and visibility-only tree; guard roster and all helper bodies preserved'))

# Independently bind the unmodified seams that govern failures, identity and descriptors.
seam_paths=['src/script.rs','src/script/construction.rs','src/script/array_from.rs','src/script/dom_prototypes.rs',
    'src/script/microtasks.rs','src/script/promises/all_allocation_probe.rs','src/script/dom_bindings.rs']
seams=[]
for rel in seam_paths:
    b=binding(BASE/rel);assert b['sha256']==inventory[rel]
    seams.append(dict(relative_path=rel,source=b))
unchanged=[]
for rel,names in {
 'src/script/promises/all_semantics.rs':['promise_all','promise_race','all_iterator_step','resolve_all_ready','run_all_callback'],
 'src/script/promises/all_state.rs':['new_all_group','append_all_placeholder','complete_all_element','finish_all_input','new_all_values_array','ready_values'],
 'src/script/promises/factories.rs':['promise_callback_metadata','new_all_resolve_element','callback_target'],
 'src/script/promises/install.rs':['promise_native','promise_intrinsic_method','check_promise_install_state'],
}.items():
    for name in names:
        old=function(parent[rel],name)[2];new=function(raw[rel],name)[2]
        assert old==new,(rel,name)
        unchanged.append(dict(path=rel,function=name,bytes=len(old.encode()),sha256=hashlib.sha256(old.encode()).hexdigest()))

snapshot=function(raw['src/script/promises/all_state.rs'],'new_all_settled_snapshot')[2]
completion=function(raw['src/script/promises/all_state.rs'],'complete_all_settled_element')[2]
assert re.findall(r'self\.work\((\d+)\)',snapshot)==['17']
assert re.findall(r'self\.work\((\d+)\)',completion)==['12','14']
assert completion.index('if *called') < completion.index('self.work(14)') < completion.index('*called = true') < completion.index('self.new_all_settled_snapshot') < completion.index('values.records[index] = snapshot')
assert snapshot.index('self.work(17)') < snapshot.index('self.work(install::tree') < snapshot.index('.get("Object")')
assert snapshot.count('value.clone()')==1
assert snapshot.index('status_key.into()')<snapshot.index('value.clone()')
assert 'self.call(' not in snapshot and 'all_captures' not in snapshot
pair=function(raw['src/script/promises/factories.rs'],'new_all_settled_elements')[2]
assert pair.count('CallbackKind::AllSettled')==2 and pair.count('FactoryExtra::AllElement')==1
assert 2*15+20+2*101==252
assert 9+20+26+18+9+16==98 and 9+20+24+20+9+17==99
assert 12+14+17+22+98==163 and 12+14+17+22+99==164
assert 9+28+24+26+4+1+93+2==187

review=dict(status='clear_bounded_source_only_production_review',findings=[],
    production_manifest=binding(H/'source-ready.json'),selection=manifest['selection'],
    original_test_holds=[binding(P/'tests-before-1/source-ready.json'),binding(P/'tests-supplement-1/source-ready.json')],
    selected_design=[binding(P/'draft-2/source-ready.json'),binding(P/'draft-2/fee-proof.json'),binding(P/'draft-2/derived-cuts.json'),binding(P/'draft-2/pseudocode.txt'),binding(P/'draft-2/layout-review.json'),binding(P/'startup-review.json')],
    source_joins=joins,exact_additive_inverses=inverses,unchanged_functions=unchanged,unchanged_supporting_seams=seams,
    review=[
      'Generic receiver is forwarded by machine/calls to the unchanged wrapper8, then new body16. NewPromiseCapability precedes resolve Get/check, then iterator method/Get/Call and cached next Get. No species or Promise brand added.',
      'AllIterator becomes live only after next Get succeeds. Existing all_iterator_step marks ordinary next/result/done/value failures done. Open-iterator resolve/then failures close through the same array_from_close helper. ResourceLimit/Unsupported skip author cleanup; terminal close propagates through exception_value without custom reject. These are inherited host-policy decisions, not invented ECMAScript outcomes.',
      'Input placeholder precedes cached resolve Call. Existing pair factory validates Group/index/remaining after that author call; both metadata bags complete before one Element and remaining increment publish. Then Get occurs only after pair publication. No arena borrow crosses author calls.',
      'Body copies are separately prepaid:1 before capability C,1 before resolve Get C,1 before items,1 before next Get receiver; unchanged attempts fund two callable/iterator copies plus one done receiver. Each value prepays2 before cached resolve/C clones and1 before then receiver clone. Newly owned callback pair moves into N2 arguments; no rejection clone is retained.',
      'Callback dispatch uses unchanged immutable native receiver/metadata identity through callback_target. Dynamic author this does not supply a capture ID. Kind selects fulfillment/rejection; both tags carry the same single Element ID. Duplicate gate12 returns before Group inspection, snapshot allocation or payload clone, including after Group values have moved out.',
      'First gate12+14 validates group/index/admission/count before setting called. Snapshot17 follows called=true. It obtains saved Object prototype through metered unchanged tree, checks object ID, pays slot work/bytes, reserves existing Objects hook and keeps staged bag/text/property helpers. No author code or capture mutation intervenes, so Group commit is direct/infallible after snapshot success.',
      'Snapshot status then payload are own writable/enumerable/configurable data properties. Status insertion precedes the only value.clone, paid by17. Snapshot refusal leaves gate consumed, Group slot/count unchanged, with any allocated unexposed bag retained under existing helper policy. No fresh budget, retry or rollback contract is introduced.',
      'Readiness reuses exact ready_values moving the whole Arena to reset logical admission, exact new_all_values_array and N1 Call with Undefined receiver. Last callback returns custom resolve result/throw; duplicates remain inert. Input sentinel is consumed solely by normal exhaustion, so saved callbacks after ordinary abort cannot resolve the aggregate.',
      'Installer appends allSettled display/key and final metadata bag after race, reserves constructor order9, inserts static property after race/before species, retains arity1/non-writable name/length flags and no own prototype. Existing generic construction whitelist is unchanged, keeping method/callback nonconstructable.',
      'State/Runtime/AllCapture/PromiseJob/QueueJob declarations are unchanged. Only CallbackKind gains two AllCaptureId variants. No arena/guard/cap/cache or helper tariff change. Actual widths and full bootstrap behavior still require root observation.'
    ],
    fees=dict(body=16,public_wrapper=8,gate=12,first_extra=14,snapshot_prefix=17,
      snapshot_stages=dict(fulfilled=98,rejected=99),snapshot_heap='900/904 + A + D + 2K + Bpp, plus existing object-slot plan',
      warm_map25_snapshot=dict(fulfilled=137,rejected=138),warm_map25_completion=dict(fulfilled=163,rejected=164),
      pair_base=252,pair_growth='existing callback, object-slot and one AllCapture plan; per-callable101 remains staged',
      installer=dict(delta=187,components=[9,28,24,26,4,1,93,2],standalone=1570,shared=1532,producer_consumer=1863,
          helper_heap='A + D + 3K + Bpp + N + 1074',bootstrap_heap='O + A + D + 3K + Bpp + N + 1074',
          prospective_raw=99973,prospective_remainder=27,prospective_metadata_objects=752)),
    primary=dict(url='https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-performpromiseallsettled',
        accessed='2026-10-15',reviewed_steps='27.5.4.2 and 27.5.4.2.1',
        synopsis='Capability and cached resolve precede iteration. Each input gets two fresh callbacks sharing one called bit. First invocation consumes it before ordinary snapshot creation; status precedes payload. Index order and one initial remaining sentinel govern completion. Final callback returns the aggregate resolve result. Open-iterator abrupt completion closes before rejecting.'),
    qualifications=[
      'This review compares external source to selected policy and held semantic tests; it is not a compiler, test, conformance, startup, type-width or stack observation.',
      'Private quota/refusal controls, layout measurements, old-test migrations and root candidate execution remain separate gates. Public test expectations were not modified.',
      'Cleanup envelopes fund bounded direct handle operations; they do not claim arbitrary nested Native receiver graphs have constant recursive teardown.',
      'Source bindings use AY selected candidate1540 coverage with its documented literal supplement; no claim of complete Cargo dependency closure.'
    ],execution='Only source reads, official primary retrieval and inert stdlib hashing/diff/extraction checks; no live edits, project import/execution, compiler, formatter, browser or Git process.',
    checker=binding(Path(__file__)))
save(OUT/'source-review.json',review)
print(json.dumps(binding(OUT/'source-review.json')))
