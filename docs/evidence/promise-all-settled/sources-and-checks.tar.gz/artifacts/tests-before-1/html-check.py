from pathlib import Path
import hashlib,json,re,difflib,subprocess
P=Path('/tmp/eris-promise-all-settled-plan-1');T=P/'tests-before-1';U=P/'tests-supplement-1';W=P/'worktree';BASE='c97b200c9bddf1527cdbbc5a652beedba27c1d6d'
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(Path(p).read_text())
def verify(v):
 b=bind(v['path']);assert b['bytes']==v['bytes'] and b['sha256']==v['sha256'],v['path']
def decl(s,n):
 m=re.search(r'\b(?:enum|struct) '+n+r'\s*\{',s);assert m,n
 start=m.start();i=m.end()-1;level=0
 for j in range(i,len(s)):
  if s[j]=='{':level+=1
  if s[j]=='}':
   level-=1
   if level==0:return s[start:j+1]
 raise AssertionError(n)
checks=[]
for D in [T,U]:
 h=read(D/'source-ready.json')
 for f in h['files']:verify(f)
 bindings=read(D/'source-bindings.json')
 for row in bindings['sources']:
  verify(row['source']);verify(row['snapshot']);rel=row['relative_path'];assert Path(row['snapshot']['path']).read_bytes()==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+rel]),rel
 checks.append(dict(hold=bind(D/'source-ready.json'),payloads=len(h['files']),source_joins=len(bindings['sources'])))
for rel,append in [('src/script.rs','public-append.txt'),('src/script/promises.rs','layout-append.txt')]:
 old=(T/'before'/rel).read_bytes();new=(T/'registrations'/rel).read_bytes();assert new==old+(T/'registrations'/append).read_bytes()
 patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 assert patch==(T/'diffs'/(rel.replace('/','__')+'.patch')).read_text()
 assert old==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+rel])
assert (U/'before/src/script.rs').read_bytes()==(T/'registrations/src/script.rs').read_bytes()
assert (U/'registrations/src/script.rs').read_bytes()==(U/'before/src/script.rs').read_bytes()+(U/'registration-append.txt').read_bytes()
original=read(P/'draft-1/semantic-cases.json')['cases'];oracle=read(T/'oracle.json')['original_cases'];assert original==oracle and len(oracle)==14
module=(T/'raw/src/script/promise_all_settled_semantic_tests.rs').read_text()
rows=re.findall(r'\#\[test\]\nfn (\w+)\(\) \{\n    observe\(\n        "([^"]+)",\n        r###"(.*?)"###,\n        r###"(.*?)"###,\n        Value::String\("(.*?)"\.into\(\)\),',module,re.S)
assert len(rows)==14
roster=read(T/'roster.json')['public']
for row,c,r in zip(rows,oracle,roster):
 fn,id,source,observation,expected=row
 assert (id,source,observation,expected)==(c['id'],c['source'],c['readback'],c['expected'])
 assert r['rust_test'].endswith('::'+fn) and r['source_sha256']==hashlib.sha256(source.encode()).hexdigest()
 assert r['source_bytes']==len(source.encode()) and r['expected']==expected and r['modes']==['sloppy','strict']
assert (T/'helper-selected.txt').read_text() in module
old_helper=(T/'helper-original.txt').read_text();assert old_helper in (T/'source-snapshots/src/script/promise_all_semantic_tests.rs').read_text()
new_helper=(T/'helper-selected.txt').read_text();assert new_helper.count('case_id == "invalid_constructor_before_inputs"')==1
mirror=(T/'raw/src/script/promises/all_settled_layout_probe.rs').read_text()
source_paths={'Runtime':'src/script.rs','QueueJob':'src/script/promises.rs'}
mirrors=[]
for n in ['CallbackKind','CallbackRecord','State','PromiseJob','QueueJob','AllCapture','ReadyAllValues','Runtime']:
 rel=source_paths.get(n,'src/script/promises.rs');src=(T/'source-snapshots'/rel).read_text();actual=decl(src,n)
 parent=decl(mirror,'Parent'+n).replace('Parent'+n,n,1)
 if n=='CallbackRecord':parent=parent.replace('ParentCallbackKind','CallbackKind')
 if n=='State':parent=parent.replace('ParentCallbackRecord','CallbackRecord')
 if n=='Runtime':parent=parent.replace('ParentState','promises::State')
 assert parent==actual,n
 proposed=decl(mirror,'Proposed'+n).replace('Proposed','Parent')
 if n=='CallbackKind':proposed=proposed.replace('    AllSettledFulfill(AllCaptureId),\n    AllSettledReject(AllCaptureId),\n','')
 assert proposed==decl(mirror,'Parent'+n),n
 mirrors.append(n)
assert len(re.findall(r'^    row!\(',mirror,re.M))==18
assert 'assert_eq!(actual, parent,' in mirror and 'assert_eq!(proposed' not in mirror and 'Runtime::' not in mirror
supp=(U/'raw/src/script/promise_all_settled_supplemental_tests.rs').read_text();suprows=re.findall(r'r###"(.*?)"###',supp,re.S);assert len(suprows)==2 and suprows[0]==(U/'case.js').read_text() and suprows[1]=='out'
assert 'Value::String("true|true|true|true|true|true|true|true".into())' in supp
assert old_helper in supp
for D,rel,diff in [(T,'src/script/promise_all_settled_semantic_tests.rs','diffs/src__script__promise_all_settled_semantic_tests.rs.patch'),(T,'src/script/promises/all_settled_layout_probe.rs','diffs/src__script__promises__all_settled_layout_probe.rs.patch'),(U,'src/script/promise_all_settled_supplemental_tests.rs','diffs/module.patch')]:
 raw=(D/'raw'/rel).read_text();expected=''.join(difflib.unified_diff([],raw.splitlines(True),fromfile='/dev/null',tofile='b/'+rel));assert expected==(D/diff).read_text(),rel
check={'status':'clear','published_base':BASE,'holds':checks,'registration_inverses':3,'public_rows_exact':14,'supplemental_rows_exact':1,'planned_modes':30,'complete_parent_declarations':mirrors,'proposed_only_delta':'Two AllCaptureId callback tags; corresponding record/state/runtime mirror type references.','mirror_measurement_rows':18,'scope':'Inert stdlib/source/Git-blob checks only; no project execution, compiler or live edits.'}
(T/'html-checks.json').write_text(json.dumps(check,indent=2)+'\n')
review={'status':'clear','scope':'Independent literal/API/full-declaration mirror and registration source peer before root baseline; no production/resource test approval.','hold':bind(T/'source-ready.json'),'published_base':BASE,'checks':bind(T/'html-checks.json'),'checker':bind(T/'html-check.py'),'primary_rules_url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-performpromiseallsettled','primary_rules_checked':'2026-10-15','conclusions':['All14 source/readback/expected tuples exactly match the original frozen semantic cases; helper uses fresh Runtime per mode and normal post-drain readback.','Invalid-constructor row has an explicit method-presence prerequisite, preventing absent-method TypeError from satisfying its intended outcome.','Empty versus nonempty job order, generic constructor/resolve/iterator order, shared pair gate, sentinel retention, last callback return/throw, duplicate undefined, saved intrinsic snapshots and payload identity reconcile.','Supplement remains separate; no original literal changes. Expected parent failure applies at the first reached sloppy source/presence check, with later readback/strict unobserved until execution.','All8 parent declarations exactly match source bodies; proposed copy adds only2 callback variants and propagates corresponding record/state/runtime names. Actual neighboring job/capture payloads remain unchanged.','18 probe rows compare actual versus complete parent only and print prospective layouts. No assumed future widths or numeric equality, no Runtime construction, and no production visibility changes.','All bound snapshots join published c97b200c. Three small cfg(test) appends compose exactly; temporary layout probe must be removed after measurements.'],'findings':[],'execution':'Source inspection and inert checks only; no engine/compiler/test execution or live edits.'}
(T/'html-review.json').write_text(json.dumps(review,indent=2)+'\n')
sr={'status':'clear','scope':'Separate supplemental method/callback/snapshot metadata literal peer, without changing original14.','hold':bind(U/'source-ready.json'),'original_hold_review':bind(T/'html-review.json'),'checks':bind(T/'html-checks.json'),'published_base':BASE,'conclusions':['One source and readback are byte-exact to the held standalone case; one group/two fresh-mode rows expect eight true observations.','Ordinary method and four empty-name arity1 callbacks are nonconstructible. Six pairwise distinctness comparisons and configurable metadata edits preserve callable identity.','Both snapshots use saved Object.prototype despite replacing the global constructor. Own status data properties have all three flags, inherited setter remains uncalled, exact token/reason identities remain, and aggregate resolves once.','All accesses use existing public test APIs. Parent absent method fails before later checks; no parent outcome is claimed by this peer.','Registration before is exactly the original14 registered snapshot; adding the58-byte supplemental snippet preserves it.'],'findings':[],'execution':'Source and inert stdlib/read-only Git checks only; no project execution/live edits.'}
(U/'html-review.json').write_text(json.dumps(sr,indent=2)+'\n')
print(json.dumps({'initial_review':bind(T/'html-review.json'),'supplement_review':bind(U/'html-review.json'),'checks':bind(T/'html-checks.json')},indent=2))
