//! Complete source-derived parent/proposed layout probe, not production.
//! Root runs this before implementation; no proposed numeric width is assumed.
//! Remove the module and its registration before final actual-type checks.
#![allow(dead_code)]
use super::*;

enum ParentCallbackKind {
    Resolve(GateId),
    Reject(GateId),
    CapabilityExecutor(CaptureId),
    ThenFinally(FinallyCaptureId),
    CatchFinally(FinallyCaptureId),
    ReturnValue(FinallyCaptureId),
    ThrowReason(FinallyCaptureId),
    AllResolve(AllCaptureId),
}

struct ParentCallbackRecord {
    object_id: usize,
    kind: ParentCallbackKind,
}

struct ParentState {
    promises: Arena<PromiseRecord>,
    gates: Arena<ResolveGate>,
    callbacks: Arena<ParentCallbackRecord>,
    captures: Arena<CapabilityCapture>,
    pub(super) jobs: Arena<Option<PromiseJob>>,
    finally_captures: Arena<FinallyCapture>,
    all_captures: Arena<AllCapture>,
    intrinsics: Option<Intrinsics>,
}

enum ParentPromiseJob {
    Reaction {
        handler: Option<Value>,
        capability: Capability,
        argument: Value,
        kind: ReactionKind,
    },
    ResolveThenable {
        target: PromiseId,
        thenable: Value,
        then: Value,
    },
}

enum ParentQueueJob {
    Callback(Value),
    Promise(JobId),
}

enum ParentAllCapture {
    Group {
        resolve: Value,
        values: Arena<Value>,
        remaining: usize,
        input_done: bool,
    },
    Element {
        group: AllCaptureId,
        index: usize,
        called: bool,
    },
}

struct ParentReadyAllValues {
    resolve: Value,
    values: Vec<Value>,
}

struct ParentRuntime {
    date_host: DateHost,
    environments: Vec<Environment>,
    functions: Vec<Function>,
    arrays: Vec<Vec<Value>>,
    array_properties: Vec<usize>,
    array_holes: Vec<BTreeSet<usize>>,
    array_lengths: Vec<array_properties::ArrayLength>,
    active_array_joins: Vec<Value>,
    array_prototype: Option<usize>,
    objects: Vec<ScriptObject>,
    prototypes: BTreeMap<&'static str, usize>,
    native_properties: BTreeMap<String, usize>,
    symbols: symbols::State,
    iterators: iterators::State,
    array_buffers: array_buffer::State,
    data_views: data_view::State,
    typed_arrays: typed_array::State,
    dom_prototypes: dom_prototypes::State,
    microtasks: microtasks::State,
    promises: ParentState,
    #[cfg(feature = "test262-host")]
    test262_session: Option<test262_host::Session>,
    host_symbol_objects: BTreeMap<property_keys::HostKey, usize>,
    function_prototype: usize,
    events: Vec<EventState>,
    abort_signals: Vec<AbortState>,
    listeners: Vec<EventListener>,
    event_listeners: BTreeMap<(EventTarget, JsString), Vec<usize>>,
    event_handlers: BTreeMap<(EventTarget, JsString), EventHandler>,
    readiness_fired: bool,
    started: std::time::Instant,
    steps: usize,
    allocated: usize,
    calls: usize,
    // Diagnostic active-expression count; iterative JavaScript uses frame storage.
    eval_depth: usize,
    frames: Vec<machine::Frame>,
    json_depth: usize,
    stack_units: usize,
    pub console: Vec<String>,
    pub last_default_prevented: bool,
    tracked_global_keys: [JsString; 5],
    next_global_order: u64,
    global_non_scalar: BTreeMap<JsString, window::GlobalProperty>,
}

enum ProposedCallbackKind {
    Resolve(GateId),
    Reject(GateId),
    CapabilityExecutor(CaptureId),
    ThenFinally(FinallyCaptureId),
    CatchFinally(FinallyCaptureId),
    ReturnValue(FinallyCaptureId),
    ThrowReason(FinallyCaptureId),
    AllResolve(AllCaptureId),
    AllSettledFulfill(AllCaptureId),
    AllSettledReject(AllCaptureId),
}

struct ProposedCallbackRecord {
    object_id: usize,
    kind: ProposedCallbackKind,
}

struct ProposedState {
    promises: Arena<PromiseRecord>,
    gates: Arena<ResolveGate>,
    callbacks: Arena<ProposedCallbackRecord>,
    captures: Arena<CapabilityCapture>,
    pub(super) jobs: Arena<Option<PromiseJob>>,
    finally_captures: Arena<FinallyCapture>,
    all_captures: Arena<AllCapture>,
    intrinsics: Option<Intrinsics>,
}

enum ProposedPromiseJob {
    Reaction {
        handler: Option<Value>,
        capability: Capability,
        argument: Value,
        kind: ReactionKind,
    },
    ResolveThenable {
        target: PromiseId,
        thenable: Value,
        then: Value,
    },
}

enum ProposedQueueJob {
    Callback(Value),
    Promise(JobId),
}

enum ProposedAllCapture {
    Group {
        resolve: Value,
        values: Arena<Value>,
        remaining: usize,
        input_done: bool,
    },
    Element {
        group: AllCaptureId,
        index: usize,
        called: bool,
    },
}

struct ProposedReadyAllValues {
    resolve: Value,
    values: Vec<Value>,
}

struct ProposedRuntime {
    date_host: DateHost,
    environments: Vec<Environment>,
    functions: Vec<Function>,
    arrays: Vec<Vec<Value>>,
    array_properties: Vec<usize>,
    array_holes: Vec<BTreeSet<usize>>,
    array_lengths: Vec<array_properties::ArrayLength>,
    active_array_joins: Vec<Value>,
    array_prototype: Option<usize>,
    objects: Vec<ScriptObject>,
    prototypes: BTreeMap<&'static str, usize>,
    native_properties: BTreeMap<String, usize>,
    symbols: symbols::State,
    iterators: iterators::State,
    array_buffers: array_buffer::State,
    data_views: data_view::State,
    typed_arrays: typed_array::State,
    dom_prototypes: dom_prototypes::State,
    microtasks: microtasks::State,
    promises: ProposedState,
    #[cfg(feature = "test262-host")]
    test262_session: Option<test262_host::Session>,
    host_symbol_objects: BTreeMap<property_keys::HostKey, usize>,
    function_prototype: usize,
    events: Vec<EventState>,
    abort_signals: Vec<AbortState>,
    listeners: Vec<EventListener>,
    event_listeners: BTreeMap<(EventTarget, JsString), Vec<usize>>,
    event_handlers: BTreeMap<(EventTarget, JsString), EventHandler>,
    readiness_fired: bool,
    started: std::time::Instant,
    steps: usize,
    allocated: usize,
    calls: usize,
    // Diagnostic active-expression count; iterative JavaScript uses frame storage.
    eval_depth: usize,
    frames: Vec<machine::Frame>,
    json_depth: usize,
    stack_units: usize,
    pub console: Vec<String>,
    pub last_default_prevented: bool,
    tracked_global_keys: [JsString; 5],
    next_global_order: u64,
    global_non_scalar: BTreeMap<JsString, window::GlobalProperty>,
}

#[test]
fn all_settled_prospective_full_types_measure_parent_and_two_callback_variants() {
    use std::mem::{align_of, size_of};
    macro_rules! row {
        ($name:literal, $actual:ty, $parent:ty, $proposed:ty) => {
            let actual = (size_of::<$actual>(), align_of::<$actual>());
            let parent = (size_of::<$parent>(), align_of::<$parent>());
            let proposed = (size_of::<$proposed>(), align_of::<$proposed>());
            assert_eq!(actual, parent, "{} complete parent mirror", $name);
            println!(
                "ALL_SETTLED_LAYOUT {} actual_bytes={} actual_align={} parent_bytes={} parent_align={} proposed_bytes={} proposed_align={}",
                $name, actual.0, actual.1, parent.0, parent.1, proposed.0, proposed.1
            );
        };
    }
    row!("CallbackKind", CallbackKind, ParentCallbackKind, ProposedCallbackKind);
    row!("CallbackRecord", CallbackRecord, ParentCallbackRecord, ProposedCallbackRecord);
    row!("CallbackArena", Arena<CallbackRecord>, Arena<ParentCallbackRecord>, Arena<ProposedCallbackRecord>);
    row!("State", State, ParentState, ProposedState);
    row!("PromiseJob", PromiseJob, ParentPromiseJob, ProposedPromiseJob);
    row!("OptionPromiseJob", Option<PromiseJob>, Option<ParentPromiseJob>, Option<ProposedPromiseJob>);
    row!("PromiseJobArena", Arena<Option<PromiseJob>>, Arena<Option<ParentPromiseJob>>, Arena<Option<ProposedPromiseJob>>);
    row!("QueueJob", QueueJob, ParentQueueJob, ProposedQueueJob);
    row!("AllCapture", AllCapture, ParentAllCapture, ProposedAllCapture);
    row!("AllCaptureArena", Arena<AllCapture>, Arena<ParentAllCapture>, Arena<ProposedAllCapture>);
    row!("ReadyAllValues", ReadyAllValues, ParentReadyAllValues, ProposedReadyAllValues);
    row!("Runtime", Runtime, ParentRuntime, ProposedRuntime);
    row!("Value", Value, Value, Value);
    row!("ScriptObject", ScriptObject, ScriptObject, ScriptObject);
    row!("MicrotaskState", microtasks::State, microtasks::State, microtasks::State);
    row!("Capability", Capability, Capability, Capability);
    row!("ReactionPair", ReactionPair, ReactionPair, ReactionPair);
    row!("FinallyCapture", FinallyCapture, FinallyCapture, FinallyCapture);
    println!(
        "ALL_SETTLED_LAYOUT_CONTEXT arch={} os={} pointer_bytes={} test262_host={} vulkan_raster={}",
        std::env::consts::ARCH, std::env::consts::OS, size_of::<usize>(),
        cfg!(feature = "test262-host"), cfg!(feature = "vulkan-raster")
    );
    println!(
        "ALL_SETTLED_LAYOUT_DERIVED callback_movement_parent={} callback_movement_proposed={} callback_growth8_parent={} callback_growth8_proposed={} capture_movement={} runtime_header_parent={} runtime_header_proposed={}",
        size_of::<CallbackRecord>().div_ceil(size_of::<Value>()),
        size_of::<ProposedCallbackRecord>().div_ceil(size_of::<Value>()),
        32 + 8 * size_of::<CallbackRecord>(), 32 + 8 * size_of::<ProposedCallbackRecord>(),
        size_of::<AllCapture>().div_ceil(size_of::<Value>()),
        2048usize.max(size_of::<Runtime>()), 2048usize.max(size_of::<ProposedRuntime>())
    );
}
