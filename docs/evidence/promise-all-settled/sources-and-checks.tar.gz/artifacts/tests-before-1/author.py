"""External artifact generator. Reads source; never imports project code."""
from pathlib import Path
import hashlib
import json
import re
import difflib

PLAN = Path('/tmp/eris-promise-all-settled-plan-1')
OUT = PLAN / 'tests-before-1'
BASE = Path('/tmp/eris-text-metadata-keys-1/worktree')
AY = BASE.parent

def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)

def js(path, obj):
    write(path, json.dumps(obj, indent=2) + '\n')

def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())

def block(source, name):
    match = re.search(r'(?m)^(?:pub(?:\(super\))? )?(?:struct|enum) ' + name + r'\b', source)
    assert match, name
    start = match.start()
    # Selected declarations are non-tuple structs/enums; complete braces, not stripped payloads.
    begin = source.index('{', match.end())
    depth = 1
    end = begin + 1
    while depth:
        depth += (source[end] == '{') - (source[end] == '}')
        end += 1
    return source[start:end]

cases = json.loads((PLAN/'draft-1/semantic-cases.json').read_text())['cases']
assert len(cases) == 14
all_test = (BASE/'src/script/promise_all_semantic_tests.rs').read_text()
helper = all_test[all_test.index('fn observe('):all_test.index('\n#[test]')]
guard = '''        if case_id == "invalid_constructor_before_inputs" {
            let present = if strict {
                runtime.execute_strict("typeof Promise.allSettled === 'function'", &mut document)
            } else {
                runtime.execute("typeof Promise.allSettled === 'function'", &mut document)
            }
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} presence: {error:?}"));
            assert_eq!(present, Value::Bool(true), "{case_id} strict={strict} method presence");
        }
'''
needle = '        let mut document = Document::parse("");\n'
assert helper.count(needle) == 1
selected_helper = helper.replace(needle, needle + guard)
public = '''//! Fourteen exact allSettled literals held before implementation.
//! A fresh Runtime is used for each mode. No test counter reset or private API.
use super::*;

''' + selected_helper + '\n'
roster = []
for case in cases:
    assert case['modes'] == ['sloppy', 'strict']
    assert '"###' not in case['source'] + case['readback']
    name = 'promise_all_settled_' + case['id']
    public += '\n#[test]\nfn ' + name + '() {\n    observe(\n'
    public += '        ' + json.dumps(case['id']) + ',\n'
    public += '        r###"' + case['source'] + '"###,\n'
    public += '        r###"' + case['readback'] + '"###,\n'
    public += '        Value::String(' + json.dumps(case['expected']) + '.into()),\n    );\n}\n'
    roster.append(dict(id=case['id'], rust_test='script::promise_all_settled_semantic_tests::'+name,
        modes=case['modes'], expected=case['expected'], source_sha256=hashlib.sha256(case['source'].encode()).hexdigest(),
        source_bytes=len(case['source'].encode()), readback=case['readback'], parent_eligible=True,
        predicted_parent_outcome='fail', predicted_parent_reason=(
            'explicit same-runtime method presence assertion; original TypeError oracle alone is insufficient'
            if case['id']=='invalid_constructor_before_inputs' else
            'source requires absent Promise.allSettled; no observed failure claim'),
        later_mode_qualification='Rust group loops sloppy then strict; first failure prevents strict row from running.'))
public_rel = 'src/script/promise_all_settled_semantic_tests.rs'
write(OUT/'raw'/public_rel, public)
write(OUT/'helper-original.txt', helper + '\n')
write(OUT/'helper-selected.txt', selected_helper + '\n')
write(OUT/'helper-presence.patch', ''.join(difflib.unified_diff((helper+'\n').splitlines(True), (selected_helper+'\n').splitlines(True),fromfile='helper-original.txt',tofile='helper-selected.txt')))

promise_source = (BASE/'src/script/promises.rs').read_text()
runtime_source = (BASE/'src/script.rs').read_text()
names = ['CallbackKind', 'CallbackRecord', 'State', 'PromiseJob', 'QueueJob', 'AllCapture', 'ReadyAllValues']
blocks = {name:block(promise_source,name) for name in names}
blocks['Runtime'] = block(runtime_source,'Runtime')
mirror = '''//! Complete source-derived parent/proposed layout probe, not production.
//! Root runs this before implementation; no proposed numeric width is assumed.
//! Remove the module and its registration before final actual-type checks.
#![allow(dead_code)]
use super::*;

'''
transforms = []
for prefix in ['Parent', 'Proposed']:
    for name, original in blocks.items():
        new = re.sub(r'^(?:pub(?:\(super\))? )?((?:struct|enum) )'+name+r'\b',r'\1'+prefix+name,original)
        changes = ['rename declaration only']
        if name=='CallbackKind' and prefix=='Proposed':
            needle='    AllResolve(AllCaptureId),\n'
            assert new.count(needle)==1
            new = new.replace(needle,needle+'    AllSettledFulfill(AllCaptureId),\n    AllSettledReject(AllCaptureId),\n')
            changes += ['append AllSettledFulfill(AllCaptureId) and AllSettledReject(AllCaptureId)']
        if name=='CallbackRecord':
            new = new.replace('kind: CallbackKind','kind: '+prefix+'CallbackKind')
            changes += ['kind refers to corresponding complete CallbackKind mirror']
        if name=='State':
            new = new.replace('callbacks: Arena<CallbackRecord>','callbacks: Arena<'+prefix+'CallbackRecord>')
            changes += ['callbacks use corresponding CallbackRecord mirror; all other payloads are actual types']
        if name=='Runtime':
            new = new.replace('promises: promises::State','promises: '+prefix+'State')
            changes += ['promises uses corresponding State mirror; cfg(test262-host) and all other actual payloads exact']
        mirror += new+'\n\n'
        transforms.append(dict(name=prefix+name,source_name=name,changes=changes,
            parent_declaration_sha256=hashlib.sha256(original.encode()).hexdigest(),
            mirror_declaration_sha256=hashlib.sha256(new.encode()).hexdigest()))

rows = [
 ('CallbackKind','CallbackKind','ParentCallbackKind','ProposedCallbackKind'),
 ('CallbackRecord','CallbackRecord','ParentCallbackRecord','ProposedCallbackRecord'),
 ('CallbackArena','Arena<CallbackRecord>','Arena<ParentCallbackRecord>','Arena<ProposedCallbackRecord>'),
 ('State','State','ParentState','ProposedState'),
 ('PromiseJob','PromiseJob','ParentPromiseJob','ProposedPromiseJob'),
 ('OptionPromiseJob','Option<PromiseJob>','Option<ParentPromiseJob>','Option<ProposedPromiseJob>'),
 ('PromiseJobArena','Arena<Option<PromiseJob>>','Arena<Option<ParentPromiseJob>>','Arena<Option<ProposedPromiseJob>>'),
 ('QueueJob','QueueJob','ParentQueueJob','ProposedQueueJob'),
 ('AllCapture','AllCapture','ParentAllCapture','ProposedAllCapture'),
 ('AllCaptureArena','Arena<AllCapture>','Arena<ParentAllCapture>','Arena<ProposedAllCapture>'),
 ('ReadyAllValues','ReadyAllValues','ParentReadyAllValues','ProposedReadyAllValues'),
 ('Runtime','Runtime','ParentRuntime','ProposedRuntime'),
 ('Value','Value','Value','Value'),
 ('ScriptObject','ScriptObject','ScriptObject','ScriptObject'),
 ('MicrotaskState','microtasks::State','microtasks::State','microtasks::State'),
 ('Capability','Capability','Capability','Capability'),
 ('ReactionPair','ReactionPair','ReactionPair','ReactionPair'),
 ('FinallyCapture','FinallyCapture','FinallyCapture','FinallyCapture'),
]
mirror += '''#[test]
fn all_settled_prospective_full_types_measure_parent_and_two_callback_variants() {
    use std::mem::{align_of, size_of};
    macro_rules! row {
        ($name:literal, $actual:ty, $parent:ty, $proposed:ty) => {
            let actual = (size_of::<$actual>(), align_of::<$actual>());
            let parent = (size_of::<$parent>(), align_of::<$parent>());
            let proposed = (size_of::<$proposed>(), align_of::<$proposed>());
            assert_eq!(actual, parent, "{} complete parent mirror", $name);
            println!(
                "ALL_SETTLED_LAYOUT {} actual_bytes={} actual_align={} parent_bytes={} parent_align={} proposed_bytes={} proposed_align={}",
                $name, actual.0, actual.1, parent.0, parent.1, proposed.0, proposed.1
            );
        };
    }
'''
for row in rows:
    mirror += '    row!("'+row[0]+'", '+', '.join(row[1:])+');\n'
mirror += '''    println!(
        "ALL_SETTLED_LAYOUT_CONTEXT arch={} os={} pointer_bytes={} test262_host={} vulkan_raster={}",
        std::env::consts::ARCH, std::env::consts::OS, size_of::<usize>(),
        cfg!(feature = "test262-host"), cfg!(feature = "vulkan-raster")
    );
    println!(
        "ALL_SETTLED_LAYOUT_DERIVED callback_movement_parent={} callback_movement_proposed={} callback_growth8_parent={} callback_growth8_proposed={} capture_movement={} runtime_header_parent={} runtime_header_proposed={}",
        size_of::<CallbackRecord>().div_ceil(size_of::<Value>()),
        size_of::<ProposedCallbackRecord>().div_ceil(size_of::<Value>()),
        32 + 8 * size_of::<CallbackRecord>(), 32 + 8 * size_of::<ProposedCallbackRecord>(),
        size_of::<AllCapture>().div_ceil(size_of::<Value>()),
        2048usize.max(size_of::<Runtime>()), 2048usize.max(size_of::<ProposedRuntime>())
    );
}
'''
# Use the actual feature spelling, validated against Cargo.toml; do not invent a cfg.
cargo=(BASE/'Cargo.toml').read_text()
assert re.search(r'(?m)^vulkan-raster\s*=',cargo), 'feature name'
mirror_rel='src/script/promises/all_settled_layout_probe.rs'
write(OUT/'raw'/mirror_rel, mirror)
js(OUT/'mirror-declarations.json',dict(source_declarations=blocks,transforms=transforms,
    rows=[dict(name=r[0],actual=r[1],parent=r[2],proposed=r[3]) for r in rows],
    changes='Only proposed CallbackKind adds two same-ID variants. Full record/state/runtime fields are copied with corresponding mirror substitutions; unrelated neighboring payload types remain actual source types.'))

registrations=[('public','src/script.rs','\n#[cfg(test)]\nmod promise_all_settled_semantic_tests;\n'),
    ('layout','src/script/promises.rs','\n#[cfg(test)]\nmod all_settled_layout_probe;\n')]
for label,rel,append in registrations:
    before=(BASE/rel).read_text()
    write(OUT/'before'/rel,before)
    write(OUT/'registrations'/(label+'-append.txt'),append)
    write(OUT/'registrations'/rel,before+append)
    write(OUT/'diffs'/(rel.replace('/','__')+'.patch'),''.join(difflib.unified_diff(before.splitlines(True),(before+append).splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
for rel in [public_rel,mirror_rel]:
    raw=(OUT/'raw'/rel).read_text()
    write(OUT/'diffs'/(rel.replace('/','__')+'.patch'),''.join(difflib.unified_diff([],raw.splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))

js(OUT/'roster.json',dict(public_groups=14,planned_public_mode_rows=28,public=roster,
    mirror_groups=1,mirror_rows=len(rows),mirror_test='script::promises::all_settled_layout_probe::all_settled_prospective_full_types_measure_parent_and_two_callback_variants',
    mirror_parent_eligible=True,mirror_outcome='Parent mirror equality is checked; proposed widths are observations, not presupposed equalities.',
    runtime_execution='No candidate or parent test has been executed by this author.'))
js(OUT/'oracle.json',dict(original_cases=cases,method_presence_guard=dict(case='invalid_constructor_before_inputs',
    source="typeof Promise.allSettled === 'function'",expected=True,position='same fresh Runtime, before original unchanged case source'),
    public_predicted_parent=dict(passed=0,failed=14,mode_rows_reached='Likely first sloppy row only per failed group; root must record actual reach.'),
    coverage_gaps=['Original metadata does not inspect name/length descriptor flags or callback metadata.',
        'Original snapshot case inspects only first snapshot prototype and no status descriptor flags.',
        'Root separately selected a supplemental group before execution; it does not alter this hold.'],
    no_resource_expectations='These are public semantic tests and inert layout measurements only. No startup/raw budget reset, private fee assertions or cap change.'))

source_rels=['src/script.rs','src/script/promises.rs','src/script/promises/all_state.rs',
    'src/script/promises/factories.rs','src/script/promises/install.rs','src/script/promises/all_semantics.rs',
    'src/script/promises/all_layout_tests.rs','src/script/promises/semantics.rs','src/script/microtasks.rs',
    'src/script/promise_all_semantic_tests.rs','src/script/test262_host.rs','Cargo.toml','Cargo.lock']
inventory=json.loads((AY/'source-candidate-extended.json').read_text())['source_sha256']
sources=[]
for rel in source_rels:
    b=binding(BASE/rel)
    assert b['sha256']==inventory[rel],rel
    saved=OUT/'source-snapshots'/rel
    write(saved,(BASE/rel).read_text())
    sources.append(dict(relative_path=rel,source=b,snapshot=binding(saved)))
js(OUT/'source-bindings.json',dict(baseline='AY candidate, publication pending at authoring; AX published base f3e70ba152fdd3b730b1dd1494963a77f5141161',
    selected_inventory=binding(AY/'source-candidate-extended.json'),sources=sources,
    inherited_inventory_qualification='1540 selected inputs with additive177 literal supplement, not a claim of complete Cargo dependency closure.',
    held_inputs=[binding(PLAN/'draft-1/semantic-cases.json'),binding(PLAN/'draft-1/design-2.json'),
        binding(PLAN/'draft-1/layout-semantic-review.json'),binding(PLAN/'draft-2/source-ready.json'),binding(PLAN/'draft-2/layout-review.json')]))
write(OUT/'notes.txt','''Selected scope: fourteen exact public groups (28 planned strict/sloppy rows), plus a temporary prospective layout measurement group with18 type rows.
The public helper is copied from the existing Promise.all helper, with the held invalid-constructor method-presence prerequisite inserted. Each row uses Runtime::try_new and normal execute/execute_strict calls; no manual counter reset, private state mutation, or fabricated object IDs.
The parent-compatible public module is a durable semantic test. Root may import it independently of the temporary layout probe.
The probe is a child of promises, so it can name the real private payload types without widening production visibility. Full CallbackKind, CallbackRecord, State, PromiseJob, QueueJob, AllCapture, ReadyAllValues and Runtime bodies are copied. All neighboring payloads are actual source types; no guessed stripped representations. Parent and proposed tags differ solely by two AllCaptureId variants. State and Runtime use corresponding mirror records to measure propagation. Unrelated job/capture field structures remain exact.
The probe asserts only that each complete parent mirror agrees with the actual current type. It prints all proposed widths/alignment and derived callback movement/first-growth/header expressions. It does not assert a prospective numeric width or equality and does not construct a Runtime, allocate an arena, or measure stack/RSS. Root should run both the 1.88/default and stable/test262-host+Vulkan configurations, bind architecture/OS/features, then remove the temporary probe and restore the registration before production. Final actual-type tests must be authored separately from these parent measurements and ABI-qualified where numeric.
The default2048 and enabled max(2048,size_of(Runtime)) formula is printed for comparison; it is an accounting envelope, not resident bytes or a new allocation. No production expression is edited.
Original14 source/readback/expectation bytes remain frozen. A separately selected supplement will close concrete metadata/status/prototype gaps without changing this hold.
No live source edits, Rust/project Python import or execution, build, formatter, browser or Git execution occurred. External stdlib extraction/hash/diff authoring only.
''')

# Re-extract each raw literal to prove exact conversion rather than trusting generation.
extracted=re.findall(r'fn promise_all_settled_([a-z_]+)\(\) \{\n    observe\(\n        "([a-z_]+)",\n        r###"([\s\S]*?)"###,\n        r###"([\s\S]*?)"###,\n        Value::String\(("(?:[^"\\]|\\.)*")\.into\(\)\)',public)
assert len(extracted)==14
for raw,case in zip(extracted,cases):
    assert raw[0]==raw[1]==case['id']
    assert raw[2]==case['source'] and raw[3]==case['readback'] and json.loads(raw[4])==case['expected']
assert public.count('#[test]')==14 and mirror.count('#[test]')==1
js(OUT/'conversion-checks.json',dict(exact_source_readback_expected_rows=14,planned_mode_rows=28,
    helper_original_exact=True,helper_only_delta='invalid-constructor presence guard',parent_source_joins=len(sources),
    full_declarations=len(blocks),mirrored_declarations=len(transforms),measurement_rows=len(rows),
    production_files_edited=0,project_execution=False))

manifest=dict(status='sealed_source_only_tests_before_production',scope='14 exact public groups and separate temporary full-enum layout probe',
    groups=dict(public=14,layout_probe=1),parent_eligible=True,baseline='AY candidate; see source-bindings.json',
    public_module=public_rel,layout_probe_module=mirror_rel,
    public_registration='registrations/public-append.txt',layout_registration='registrations/layout-append.txt',
    import_policy='Append each registration once to its bound before bytes; public and temporary mirror may be imported independently. Do not copy registration snapshots over later changes.',
    files=[binding(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='source-ready.json'],
    execution='External source extraction and stdlib checks only; no live edits or project execution.')
js(OUT/'source-ready.json',manifest)
print(json.dumps(binding(OUT/'source-ready.json')))
