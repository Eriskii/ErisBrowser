"""Source-only terminal fixture conversion and independent literal hold."""
from pathlib import Path
import json, hashlib, difflib, re

P=Path('/tmp/eris-promise-all-settled-plan-1')
OUT=P/'abort-tests-before-1'
BASE=Path('/tmp/eris-text-metadata-keys-1/worktree')
def put(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(p,o):put(p,json.dumps(o,indent=2)+'\n')
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

race=(BASE/'src/script/promise_race_abort_tests.rs').read_text()
all_abort=(BASE/'src/script/promise_all_abort_tests.rs').read_text()
helper=race[race.index('fn execute_mode('):race.index('\n#[test]')]
assert 'runtime.steps' not in helper and 'MAX_STEPS' not in helper and 'runtime.allocated' not in helper
readback="[trace,resolves,rejects,returnGets,returnCalls,after].join('|')"
groups=[]
origin=[]
for stage,owner in [('resolve',race),('then_get',all_abort),('then_call',race)]:
    method='race' if owner is race else 'all'
    start=owner.index('fn promise_'+method+'_fatal_'+stage+'_stops_before_later_author_callbacks()')
    end=owner.find('\n#[test]',start)
    chunk=owner[start:end if end!=-1 else len(owner)]
    literals=re.findall(r'r###"([\s\S]*?)"###',chunk)
    assert len(literals)==2
    trace=dict(resolve='NR',then_get='NRG',then_call='NRGT')[stage]
    cases=[]
    for i,literal in enumerate(literals):
        assert literal.count('Promise.'+method+'.call(C,src)')==1
        selected=literal.replace('Promise.'+method+'.call(C,src)','Promise.allSettled.call(C,src)')
        cases.append(dict(id='fatal_'+stage+('_resource' if i==0 else '_unsupported'),unsupported=bool(i),source=selected))
        origin.append(dict(id=cases[-1]['id'],source_method=method,source_sha256=hashlib.sha256(literal.encode()).hexdigest(),
            selected_sha256=hashlib.sha256(selected.encode()).hexdigest(),only_change='Promise.'+method+'→Promise.allSettled at single callsite'))
    groups.append(dict(id='fatal_'+stage+'_stops_before_later_author_callbacks',calls=[dict(cases=cases,expected=trace+'|0|0|0|0|false')],
        derivation='N next yields; '+dict(resolve='R cached resolve enters terminal operation; then is untouched.',then_get='R cached resolve returns, G then getter enters terminal operation; then invocation is untouched.',then_call='R resolve, G then getter, T then invocation enters terminal operation.')[stage]+
        ' Iterator remains open, but neither return getter/call nor aggregate resolve/reject or queuedQ or after executes.'))

prefix="var trace='',after=false,resolves=0,rejects=0,returnGets=0,returnCalls=0,marker={},savedF,savedR,step=0;"
ctor="function C(executor){executor(function(){resolves++;trace+='A';@STOP@},function(){rejects++;trace+='J';});}"
close="Object.defineProperty(it,'return',{get:function(){returnGets++;trace+='C';return function(){returnCalls++;trace+='X';return {};};}});"
iterable="var src={};src[Symbol.iterator]=function(){return it;};queueMicrotask(function(){trace+='Q';});"
iterator="var it={next:function(){trace+='N';return step++===0?{done:false,value:1}:{done:true};}};"
normal=prefix+ctor+"C.resolve=function(x){trace+='R';return {get then(){trace+='G';return function(f,r){trace+='T';f(x);trace+='F';};}};};"+iterator+close+iterable+"Promise.allSettled.call(C,src);after=true;"
saved=prefix+ctor+"C.resolve=function(x){trace+='R';return {get then(){trace+='G';return function(f,r){trace+='T';savedF=f;savedR=r;};}};};"+iterator+close+iterable+"Promise.allSettled.call(C,src);trace+='B';@FINAL@;after=true;"

def terminal_cases(label,template):
    assert template.count('@STOP@')==1
    return [dict(id=label+'_resource',unsupported=False,source=template.replace('@STOP@','while(true){}')),
            dict(id=label+'_unsupported',unsupported=True,source=template.replace('@STOP@',"eval('0');"))]
groups.append(dict(id='fatal_aggregate_resolve_at_normal_exhaustion_stops_without_reject_or_jobs',
    calls=[dict(cases=terminal_cases('fatal_aggregate_exhaustion',normal),expected='NRGTFNA|1|0|0|0|false')],
    derivation='N yields; R/G/T reaches first fulfillment. Sentinel prevents aggregate resolution, so F is reached. Second N exhausts and finish invokes aggregate A exactly once, where terminal error escapes; no close on exhausted iterator, no reject/after/queuedQ.'))
groups.append(dict(id='fatal_saved_final_callback_stops_without_reject_or_jobs',calls=[
    dict(cases=terminal_cases('fatal_saved_fulfill',saved.replace('@FINAL@','savedF(marker)')),expected='NRGTNBA|1|0|0|0|false'),
    dict(cases=terminal_cases('fatal_saved_reject',saved.replace('@FINAL@','savedR(marker)')),expected='NRGTNBA|1|0|0|0|false')],
    derivation='N/R/G/T saves pair without settling it; second N exhausts and allSettled returns still pending. B proves return. Saved fulfillment or rejection creates its snapshot and final aggregate A throws terminal. No aggregate reject, after, return getter/call or queuedQ; two later readbacks preserve identical state and suspension.'))
assert len(groups)==5
all_cases=[c for g in groups for call in g['calls'] for c in call['cases']]
assert len(all_cases)==12
module='''//! Additive allSettled host-terminal controls, frozen before their execution.
//! Existing race abort helper is exact; no in-operation allowance resets.
use super::*;

'''+helper+'\n'
roster=[]
for g in groups:
    name='promise_all_settled_'+g['id']
    module+='\n#[test]\nfn '+name+'() {\n'
    for call in g['calls']:
        module+='    fatal_stop(\n        [\n'
        for case in call['cases']:
            module+='            (\n                '+json.dumps(case['id'])+',\n                '+str(case['unsupported']).lower()+',\n                r###"'+case['source']+'"###,\n            ),\n'
        module+='        ],\n        '+json.dumps(call['expected'])+',\n    );\n'
    module+='}\n'
    roster.append(dict(rust_test='script::promise_all_settled_abort_tests::'+name,
        source_cases=len(g['calls'])*2,planned_mode_attempts=len(g['calls'])*4,post_failure_readbacks=len(g['calls'])*8,
        parent_eligible=True,predicted_absent_method_parent='Failure: TypeError at absent method fails required ResourceLimit classification on first resource/sloppy row; later rows unreached.',
        no_baseline_claim='Parent eligibility describes source API compatibility, not an actual run; root already started production before this supplemental module import.'))
rel='src/script/promise_all_settled_abort_tests.rs'
put(OUT/'raw'/rel,module)
put(OUT/'helper-original.txt',helper+'\n')
before=(P/'tests-supplement-1/registrations/src/script.rs').read_text()
append='\n#[cfg(test)]\nmod promise_all_settled_abort_tests;\n'
put(OUT/'before/src/script.rs',before)
put(OUT/'registration-append.txt',append)
put(OUT/'registrations/src/script.rs',before+append)
put(OUT/'registration.patch',''.join(difflib.unified_diff(before.splitlines(True),(before+append).splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs')))
put(OUT/'diffs/module.patch',''.join(difflib.unified_diff([],module.splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
js(OUT/'oracle.json',dict(status='prospective_terminal_literals_source_derived_before_execution',groups=groups,
    readback=readback,origins=origin,readbacks_per_attempt=2,terminal_bodies=dict(resource='while(true){}',unsupported="eval('0');"),
    scope='Existing bounded host terminal policy, separate from ECMAScript ordinary throw/rejection semantics; no iteration-count or exact fee oracle.',
    qualifications=[
      'Every group uses a fresh Runtime for each resource/unsupported and strict/sloppy row. Normal execute/execute_strict readbacks are separate host entries with their existing budget policy; test code never assigns allowance/counter fields or resets an operation.',
      'First three stages have an open iterator and observable return getter/call. Terminal handling must skip both cleanup hooks and aggregate reject.',
      'Normal-exhaustion aggregate path already has iterator done; saved-final paths have already returned from allSettled. Their zero return counts are state/order controls, not an open-iterator close discriminator.',
      'Saved-final group covers both fulfillment and rejection callback directions. It observes terminal propagation through the aggregate resolver, not injected snapshot allocation refusal; private tests own that gate/refusal cut.',
      'QueuedQ remains present but undrained after terminal failure; identical later trace values plus suspended=true and empty console prove no checkpoint/job resumption in both readbacks.',
      'No candidate output was used to choose these strings. Existing production may execute other frozen tests in parallel; this new module has not been imported or run.'
    ]))
js(OUT/'roster.json',dict(groups=5,source_literals=12,planned_mode_attempts=24,post_failure_readbacks=48,tests=roster))
source_rels=['src/script/promise_race_abort_tests.rs','src/script/promise_all_abort_tests.rs',
    'src/script/promises/all_semantics.rs','src/script/promises/semantics.rs','src/script/array_from.rs',
    'src/script/microtasks.rs','src/script.rs']
inventory=json.loads((BASE.parent/'source-candidate-extended.json').read_text())['source_sha256']
sources=[]
for path in source_rels:
    b=bind(BASE/path);assert b['sha256']==inventory[path]
    saved_path=OUT/'source-snapshots'/path
    put(saved_path,(BASE/path).read_text())
    sources.append(dict(relative_path=path,source=b,snapshot=bind(saved_path)))
js(OUT/'source-bindings.json',dict(published_parent='c97b200c9bddf1527cdbbc5a652beedba27c1d6d',
    sources=sources,registration_parent=bind(P/'tests-supplement-1/registrations/src/script.rs'),
    public_holds=[bind(P/'tests-before-1/source-ready.json'),bind(P/'tests-supplement-1/source-ready.json')],
    reviewed_external_production=bind(P/'production-1/source-ready.json'),
    production_review=bind(P/'production-review-1/source-review.json')))
put(OUT/'notes.txt','''Exactly five groups/twelve source literals/twenty-four planned strict/sloppy attempts/forty-eight post-terminal readbacks. Three stage pairs are exact copies from the established race/all abort fixtures with only the allSettled method call substituted. The new normal-exhaustion and saved-final pairs are independently authored source templates; ResourceLimit comes from while(true), Unsupported from eval, matching the existing fixture policy.
Expected traces are derived from explicit source markers and selected generic/iterator/sentinel/host-terminal rules, not observed results. The normal-exhaustion F proves a synchronous first callback returned without premature aggregate resolution; saved B proves allSettled already returned before the final callback. Saved fulfillment and rejection directions both reach aggregate A. Return getter C/call X, aggregate reject J, queued Q and after=true must remain absent as specified.
The Rust helper execute_mode/fatal_stop is byte-identical to existing Promise.race. Each row uses a fresh Runtime. It checks exact terminal class, microtasks_suspended, then two ordinary readbacks with equal state, persistent suspension and empty console. No steps/allocated/calls mutation or MAX_STEPS allowance reset is introduced. Separate readback entries retain the existing Runtime entry policy, which is not claimed to be continuation with the exhausted turn budget.
Registration is append-only against the frozen original15 public composition. Do not replace current source if production/import formatting or other registrations intervened; root composes the append. Old public15, layouts and old abort fixtures remain untouched.
This hold is source-compatible with the absent-method parent but no new parent execution is claimed. Root may import/run it only after peer clearance. No live edits, project/compiler/formatter/browser/Git execution occurred; inert stdlib authoring/hashes only.
''')
extracted=re.findall(r'r###"([\s\S]*?)"###',module)
assert extracted[0]==readback and extracted[1:]==[c['source'] for c in all_cases]
assert module.count('#[test]')==5
assert module[module.index('fn execute_mode('):module.index('\n#[test]')].rstrip()==helper.rstrip()
for c in all_cases:
    assert c['source'].count('Promise.allSettled.call(C,src)')==1
    assert c['source'].count('while(true){}')==(not c['unsupported'])
    assert c['source'].count("eval('0');")==c['unsupported']
js(OUT/'source-ready.json',dict(status='sealed_additive_terminal_controls_before_execution',groups=5,source_literals=12,
    planned_mode_attempts=24,post_failure_readbacks=48,parent_eligible=True,raw_module=rel,registration='registration-append.txt',
    files=[bind(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='source-ready.json'],
    no_prior_expectation_changes=True,execution='External source-only authoring and stdlib checks; no project execution/live edits.'))
print(json.dumps(bind(OUT/'source-ready.json')))
