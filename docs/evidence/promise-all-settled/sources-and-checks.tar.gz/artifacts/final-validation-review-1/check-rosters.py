from pathlib import Path
import hashlib,json,re,shutil
P=Path('/tmp/eris-promise-all-settled-plan-1');AY=Path('/tmp/eris-text-metadata-keys-1');D=P/'final-validation-review-1';W=P/'worktree'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(name,value):
 p=D/name;p.write_text(json.dumps(value,indent=2)+'\n');return bind(p)
def parse(receipt,expected_exit):
 receipt=Path(receipt);j=json.loads(receipt.read_text());log=receipt.with_suffix('.log');b=bind(log);assert j['exit']==expected_exit and b['sha256']==j['sha256']
 units=[];current=None
 def finish():
  if current is not None:
   assert current['summary'] is not None,current['harness']
   counts=current['summary']['counts'];assert counts[:3]==[len(current['names'][x])for x in ['ok','FAILED','ignored']],current['harness'];units.append(current.copy())
 for line in log.read_text().splitlines():
  run=re.fullmatch(r'\s+Running (?:unittests )?([^ ]+) \(.+\)',line);doc=re.fullmatch(r'\s+Doc-tests (\S+)',line)
  if run or doc:
   finish();current={'harness':run[1]if run else 'Doc-tests '+doc[1],'names':{'ok':[],'FAILED':[],'ignored':[]},'summary':None,'failure_details':False};continue
  if current is None:continue
  if line=='failures:':current['failure_details']=True
  if not current['failure_details']:
   m=re.fullmatch(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?',line)
   if m:current['names'][m[2]].append(current['harness']+'::'+m[1])
  m=re.fullmatch(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+',line)
  if m:current['summary']={'status':m[1],'counts':list(map(int,m.groups()[1:]))}
 finish();names={k:sorted(n for u in units for n in u['names'][k])for k in ['ok','FAILED','ignored']}
 for k,v in names.items():assert len(v)==len(set(v)),(receipt,k)
 return {'receipt':bind(receipt),'log':b,'command':j['command'],'exit':j['exit'],'totals':[sum(u['summary']['counts'][i]for u in units)for i in range(5)],'result_rows':len(units),'rows':[{'harness':u['harness'],**u['summary']}for u in units],'names':names}
def tests(path):return re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn\s+(\w+)\(',Path(path).read_text())
def qualified(relative,name):
 if relative.startswith('src/'):
  module=relative[4:-3].replace('/','::');return 'src/lib.rs::'+module+'::'+name
 if relative.startswith('tests/worker/'):
  return 'tests/worker.rs::'+relative[len('tests/worker/'):-3].replace('/','::')+'::'+name
 return relative+'::'+name
# Retain the actual AY inputs, preserving the ordinary+ignored split.
for label in ['default-full-1','default-ignored-1','host-vulkan-full-1']:
 for suffix in ['json','log']:
  src=AY/'validation'/f'{label}.{suffix}';dst=D/'baseline'/f'{label}.{suffix}'
  if dst.exists():assert dst.read_bytes()==src.read_bytes()
  else:shutil.copyfile(src,dst)
baseline={k:parse(D/'baseline'/f'{label}.json',0)for k,label in [('default','default-full-1'),('default_ignored','default-ignored-1'),('host_vulkan','host-vulkan-full-1')]}
assert baseline['default']['totals']==[2965,0,124,0,0]
assert baseline['default_ignored']['totals']==[124,0,0,0,2965]
assert baseline['host_vulkan']['totals']==[3443,0,0,0,0]
assert all(v['result_rows']==51 for v in baseline.values())
a=set(baseline['default']['names']['ok']);b=set(baseline['default_ignored']['names']['ok']);assert not a&b and b==set(baseline['default']['names']['ignored']);old_default=a|b;assert len(old_default)==3089
old_host=set(baseline['host_vulkan']['names']['ok'])
# Derive seven mappings from the frozen migration ledger; independently match function changes.
ledger=json.loads((P/'migrations-outline-1/ledger.json').read_text());renames={}
for row in ledger['test_name_changes']:
 rel=row['path'];old=(P/'migrations-outline-1/before'/rel);new=(P/'migrations-outline-1/raw'/rel)
 assert row['before']in tests(old)and row['after']in tests(new)
 assert row['before']not in tests(new)and row['after']not in tests(old)
 renames[qualified(rel,row['before'])]=qualified(rel,row['after'])
assert len(renames)==7
migration=json.loads((P/'migrations-outline-1/source-ready.json').read_text())
for entry in migration['files']:
 rel=entry.get('path',entry.get('relative_path'));assert isinstance(rel,str),entry
 old=tests(P/'migrations-outline-1/before'/rel);new=tests(P/'migrations-outline-1/raw'/rel)
 mapping={r['before']:r['after']for r in ledger['test_name_changes']if r['path']==rel}
 assert [mapping.get(x,x)for x in old]==new,rel
 assert tests(W/rel)==new,rel
# All 35 groups come from selected immutable raw modules, never from observed pass lists.
inputs=[
 ('semantic',P/'tests-correction-1/raw/original-held/src/script/promise_all_settled_semantic_tests.rs','src/script/promise_all_settled_semantic_tests.rs',14),
 ('supplement',P/'tests-supplement-1/raw/src/script/promise_all_settled_supplemental_tests.rs','src/script/promise_all_settled_supplemental_tests.rs',1),
 ('abort',P/'abort-tests-before-1/raw/src/script/promise_all_settled_abort_tests.rs','src/script/promise_all_settled_abort_tests.rs',5),
 ('actual_layout',P/'tests-layout-actual-1/raw/src/script/promises/all_settled_layout_tests.rs','src/script/promises/all_settled_layout_tests.rs',1),
 ('private',P/'private-tests-outline-2/raw/src/script/promises/all_state/all_settled_quota_tests.rs','src/script/promises/all_state/all_settled_quota_tests.rs',12),
 ('page',P/'page-tests-before-1/raw/tests/promise_all_settled.rs','tests/promise_all_settled.rs',1),
 ('worker',P/'page-tests-before-1/raw/tests/worker/promise_all_settled.rs','tests/worker/promise_all_settled.rs',1)]
new_groups=set();new_source=[]
for family,raw,rel,n in inputs:
 names=tests(raw);assert len(names)==n,(family,names);assert names==tests(W/rel)
 qualified_names=[qualified(rel,x)for x in names];new_groups.update(qualified_names);new_source.append({'family':family,'groups':n,'raw':bind(raw),'formatted':bind(W/rel),'names':qualified_names})
assert len(new_groups)==35
for old in [old_default,old_host]:assert set(renames)<=old and not new_groups&old
expected_default={renames.get(n,n)for n in old_default}|new_groups
expected_host={renames.get(n,n)for n in old_host}|new_groups
assert len(expected_default)==3124 and len(expected_host)==3478
source=P/'source-candidate-3.json';inv=json.loads(source.read_text())['source_sha256'];assert len(inv)==1549
for rel,h in inv.items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==h,rel
# Retain and qualify the sandbox-limited attempt, including child panic output.
failed=parse(P/'validation/default-full-1.json',101);assert failed['totals']==[2776,8,0,0,0]and failed['result_rows']==1
failedlog=Path(failed['log']['path']).read_text();assert failedlog.count('kind: PermissionDenied')==8
assert all(n=='src/lib.rs::page::css_url_tests::stylesheet_provenance_survives_redirects_imports_and_document_base_changes'or n.startswith('src/lib.rs::page::resource_loading_tests::')or n.startswith('src/lib.rs::worker::sandbox::tests::')for n in failed['names']['FAILED'])
default=parse(P/'validation/default-full-2.json',0);assert default['command']==failed['command'] and '--include-ignored'in default['command']
assert default['totals']==[3124,0,0,0,0]and default['result_rows']==52
assert set(default['names']['ok'])==expected_default
assert set(failed['names']['ok'])|set(failed['names']['FAILED']) <= expected_default
private=parse(P/'validation/candidate-private-1.json',0);assert private['totals'][:4]==[12,0,0,0]
assert set(private['names']['ok'])==set(next(x['names']for x in new_source if x['family']=='private'))
# Host receipt may not exist yet. A pending run is never treated as evidence of a pass.
host_path=P/'validation/host-vulkan-full-1.json';host=None
if host_path.exists():
 host=parse(host_path,0);assert host['totals']==[3478,0,0,0,0]and host['result_rows']==52
 assert set(host['names']['ok'])==expected_host
 assert '--include-ignored'in host['command']
bindings={'source':bind(source),'baseline_root_record':bind(AY/'root/rust-validation.json'),'migration_hold':bind(P/'migrations-outline-1/source-ready.json'),'migration_ledger':bind(P/'migrations-outline-1/ledger.json'),'public_correction_review':bind(P/'tests-correction-1/html-review.json'),'private_review':bind(P/'private-tests-outline-2/html-review.json')}
checks={'status':'complete_rust_rosters_verified'if host else'default_verified_host_pending','bindings':bindings,'baseline_runs':baseline,'baseline_default_union':sorted(old_default),'renames':renames,'new_groups':sorted(new_groups),'new_source':new_source,'expected_default':sorted(expected_default),'expected_host':sorted(expected_host),'sandbox_limited_attempt':failed,'default':default,'private':private,'host_vulkan':host,'qualification':'The original AY default total3089 is the disjoint2965 ordinary +124 explicit ignored-only union. Current default-full-1 stopped after the library target because eight local TCP preflights were denied by the enclosing sandbox; embedded captured child summaries are not extra suite result rows. Identical-source default-full-2 passed all52 harness rows with include-ignored. Host result remains pending until its terminal receipt is read.','execution':'Only inert stdlib log/source/hash review; no project imports, tests, compiler, engine or live-source edits.'}
artifact=dump('rust-checks.json',checks)
review={'status':'clear'if host else'partial_default_clear_host_pending','source':bind(source),'checker':bind(D/'check-rosters.py'),'checks':artifact,'counts':{'published_AY_default':3089,'published_AY_host':3443,'new_groups':35,'renamed_old_groups':7,'current_default':3124,'current_host':3478 if host else None,'expected_host_pending_observation':None if host else 3478,'result_rows_per_current_full_run':52},'families':{x['family']:x['groups']for x in new_source},'old_roster_preservation':'Exact full names after the seven held renames; no old test omitted, no extra/unselected test added.','default_baseline_scope':'AY ordinary2965 + complementary ignored124 are disjoint and exactly cover the prior3089; current successful default3124 is one include-ignored run.','sandbox_attempt':'Retained failed default-full-1 has2776 pass/8 failure in the library target, all at denied local TCP preflights; it is not a successful full run. The source and command match default-full-2.','host_scope':'Observed exact3478 include-ignored passes, zero failures/ignored/filtered, all52 harness rows.'if host else'Awaiting actual terminal host receipt; expected3478 is arithmetic only.','private_scope':'Candidate-private-1 observed all12 groups pass;138 planned helper operations come from frozen test source rather than the test harness group count.','bindings':bindings,'findings':[],'execution':'Independent static source/receipt/raw-log audit only; no project execution by peer.'}
review_name='rust-review.json'if host else'default-review.json';summary=dump(review_name,review)
print(json.dumps({'review':summary,'counts':review['counts'],'status':review['status']},indent=2))
