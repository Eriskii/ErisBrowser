from pathlib import Path
import hashlib,json,re,ast
P=Path('/tmp/eris-promise-all-settled-plan-1');D=P/'final-validation-review-1';W=P/'worktree'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
verified=0
def refs(v):
 global verified
 if isinstance(v,dict):
  if all(k in v for k in ('path','bytes','sha256')):
   b=bind(v['path']);assert(b['bytes'],b['sha256'])==(v['bytes'],v['sha256']),v['path'];verified+=1
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
def receipt(ref):
 r=json.loads(Path(ref['path']).read_text());assert r['exit']==0
 p=Path(ref['path']).with_suffix('.log');assert bind(p)['sha256']==r['sha256'];return r
ledger=json.loads((P/'root/final-validation.json').read_text());refs(ledger)
rust=json.loads((D/'rust-checks.json').read_text());refs(json.loads((D/'rust-review.json').read_text()))
replay=json.loads((D/'replay-checks.json').read_text());refs(replay)
assert ledger['status']=='verified'and ledger['base']=='c97b200c9bddf1527cdbbc5a652beedba27c1d6d'
assert (P/'source-final.json').read_bytes()==(P/'source-candidate-3.json').read_bytes()
source=json.loads((P/'source-final.json').read_text())['source_sha256'];parent=json.loads((P/'parent-source.json').read_text())['source_sha256']
assert len(source)==1549 and len(parent)==1540 and set(parent)<=set(source)
changed=sorted(k for k,v in source.items()if parent.get(k)!=v);assert changed==ledger['changed_source_paths']and len(changed)==32
assert [ledger[k]for k in ['production_paths','existing_test_migration_paths','additional_existing_registration_paths','new_source_or_fixture_paths']]==[7,14,2,9]
for rel,h in source.items():assert bind(W/rel)['sha256']==h,rel
for k in ['default','host_vulkan']:
 q=ledger['full_suites'][k];v=rust[k];assert q['receipt']==v['receipt'] and q['log']==v['log'];assert [q[x]for x in ['passed','failed','ignored','filtered']]==[v['totals'][i]for i in [0,1,2,4]]
assert ledger['new_test_groups']==35 and ledger['existing_renames']==7
# Focused names must equal the frozen new-source family rosters, not merely total counts.
family={x['family']:set(x['names'])for x in rust['new_source']}
expected={'candidate-public-3':family['semantic']|family['supplement']|family['abort']|family['actual_layout'],'candidate-private-1':family['private'],'candidate-pages-1':family['page']|family['worker']}
for label,expected_names in expected.items():
 q=ledger['focused'][label];receipt(q['receipt']);text=Path(q['log']['path']).read_text();harness=None;names=set()
 for line in text.splitlines():
  m=re.fullmatch(r'\s+Running (?:unittests )?([^ ]+) \(.+\)',line)
  if m:harness=m[1]
  m=re.fullmatch(r'test (.+) \.\.\. ok',line)
  if m:assert harness;names.add(harness+'::'+m[1])
 assert names==expected_names and len(names)==q['passed'],label
checks={k:receipt(v['receipt'])for k,v in ledger['strict_checks'].items()}
assert checks['clippy-msrv-1']['command'][1]=='+1.88.0'
assert checks['clippy-host-vulkan-1']['command'][1]=='+1.99.0'
assert checks['clippy-host-vulkan-1']['command'][checks['clippy-host-vulkan-1']['command'].index('--features')+1]=='test262-host,vulkan-raster'
for k in ['clippy-msrv-1','clippy-host-vulkan-1']:
 assert '--all-targets'in checks[k]['command']and checks[k]['command'][-2:]==['-D','warnings']
assert '+1.99.0'in checks['format-check-1']['command']and checks['format-check-1']['command'][-1]=='--check'
assert checks['host-release-1']['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--features','test262-host','--release','--bin','eris-js']
assert ledger['release_binary']==replay['binary'] and ledger['exact_case_records']==replay['total_case_records']==842 and ledger['exact_harness_records']==replay['per_profile_control_records']==254 and ledger['baseline_changes']==0
expected_fee={'all_settled_body':16,'public_wrapper':8,'paired_callbacks_warm':252,'duplicate_gate':12,'first_completion_validation':14,'snapshot_fixed':17,'prototype_lookup_current':22,'warm_snapshot_fulfill':137,'warm_snapshot_reject':138,'first_completion_fulfill':163,'first_completion_reject':164}
assert ledger['selected_fees']==expected_fee
resource=ledger['resource_change'];expected_resource={'raw_startup_before':99786,'raw_startup_after':99973,'additional_work':187,'remaining_before':214,'remaining_after':27,'instruction_limit':100000,'heap_limit_bytes':8388608,'objects_before':751,'objects_after':752,'native_registry_entries':299,'prototypes':25,'globals':212,'standalone_installer_work':1570,'shared_installer_work':1532,'producer_plus_shared_installer_work':1863,'producer_work':331,'method_bag':751}
assert {k:v for k,v in resource.items()if k!='qualification'}==expected_resource
assert ledger['new_tests']['groups']==35 and ledger['new_tests']['private_operation_rows']==138
parent_record=json.loads((P/'root/parent-validation-1.json').read_text());refs(parent_record);assert parent_record['public_groups']==parent_record['public_expected_failures']==15 and len(parent_record['configurations'])==4
assert all(len(c['layouts'])==18 for c in parent_record['configurations'])
page_record=json.loads((P/'root/page-validation-1.json').read_text());refs(page_record)
old=(P/'tests-before-1/raw/src/script/promise_all_settled_semantic_tests.rs').read_text();js=re.findall(r'r###"(.*?)"###',old,re.S)[24];assert js.index('Promise.allSettled.call')<js.index("O.defineProperty(op, 'status'")
fmt=json.loads((P/'root/formatting.json').read_text());assert fmt['changed_count']==6 and fmt['expectation_changes'].startswith('none by formatter')
helper=P/'root/finalize-validation.py';ast.parse(helper.read_text())
review={
 'status':'clear','scope':'Independent final source/ledger, exact Rust rosters, successful checks, release identity and complete existing-profile replay review. Documentation/archive publication is outside this receipt.',
 'ledger':bind(P/'root/final-validation.json'),'finalizer_source':bind(helper),'source':bind(P/'source-final.json'),'source_peer':bind(P/'candidate-source-review-1/source-review.json'),'rust_roster_review':bind(D/'rust-review.json'),'replay_checks':bind(D/'replay-checks.json'),'checker':bind(D/'check-final.py'),'replay_checker':bind(D/'check-replays.py'),
 'source_findings':{'selected_inputs':1549,'retained_parent_inputs':1540,'changed_or_new_paths':32,'new_files':9,'final_equals_reviewed_and_executed_source3':True,'all_current_source_hashes_verified':True,'binding_occurrences_verified':verified},
 'rust':{'default_passed':3124,'host_vulkan_passed':3478,'result_rows_each':52,'failed':0,'ignored':0,'filtered':0,'exact_additions':35,'exact_existing_renames':7,'focused_groups':[21,12,2],'private_operations_source_derived':138,'prior_AY_default':'Disjoint2965 ordinary +124 ignored-only runs; retained raw receipts/logs.','failed_attempt':'default-full-1 retained2776 pass/8 denied TCP preflight failures in the library target; integration targets unreached. Captured child summaries are not extra outer result rows. Successful default-full-2 uses the same source and command.'},
 'strict_and_release':{'clippy':'Rust1.88 default and1.99 test262-host,vulkan-raster; all targets, warnings denied.','format':'Rust1.99 cargo fmt --all --check.','release':'Rust1.88 release eris-js with test262-host.','binary':ledger['release_binary']},
 'replays':{'case_records':842,'per_profile_control_records':254,'distinct_control_name_mode_pairs':106,'full_ordered_arrays_equal_published_AY':True,'regressions':0,'improvements':0,'baseline_changes':0,'profiles':[{'profile':r['profile'],'cases':r['cases'],'controls':r['controls'],'counts':r['counts']}for r in replay['records']],'only_allowed_top_level_report_changes':['seconds','binary','binary_sha256'],'qualification':'Existing failed and unsupported cases remain recorded. Healthy controls and regression-free replay are not full Test262 conformance; this checkpoint has no upstream allSettled corpus result.'},
 'chronology_and_limits':['Method absence stops the original snapshot case at Promise.allSettled.call before its invalid inherited descriptor setup; original parent failures cover first sloppy rows only.','Misnamed candidate-public-1 remains an unchanged-parent replay; actual candidate-public-2 exposes the fixture defect. Null-prototype setup correction retains all expected strings and original evidence.','Private hold2 fixes a warm-capacity fixture before private execution; API-dependent private groups do not claim a parent baseline. Terminal groups were authored after production import and are not described as parent-executed.','Page/worker first parent failures and separately launched worker are qualified; candidate controls use exact procedural frame/hit/title/task checks. CPU packed-plan parity does not claim device GPU execution.','Abstract work/heap, x86_64 Linux representation observations and bounded isolation checks are not CPU-speed/RSS/stack bounds or a general security proof.','The selected1549 map is explicitly not a complete dependency/build graph; old archival inventories remain unchanged.'],
 'findings':[],'execution':'Only own inert standard-library source/hash/JSON/log checks; no root finalizer, project module, compiler, engine, test or live-source edit executed by peer.'}
p=D/'final-review.json';p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(p),indent=2))
