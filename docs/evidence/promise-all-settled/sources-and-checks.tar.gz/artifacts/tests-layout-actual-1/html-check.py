from pathlib import Path
import hashlib,json,re,difflib
P=Path('/tmp/eris-promise-all-settled-plan-1');D=P/'tests-layout-actual-1'
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def rd(p):return json.loads(Path(p).read_text())
def refs(x):
 if isinstance(x,dict):
  if all(k in x for k in ['path','bytes','sha256']):
   b=bind(x['path']);assert b['bytes']==x['bytes'] and b['sha256']==x['sha256'],x['path']
  for v in x.values():refs(v)
 elif isinstance(x,list):
  for v in x:refs(v)
refs(rd(D/'source-ready.json'));refs(rd(D/'source-bindings.json'));o=rd(D/'oracle.json');refs(o)
raw=(D/'raw/src/script/promises/all_settled_layout_tests.rs').read_text(); rows=re.findall(r'row!\("([^"]+)", (.*?), (\d+), (\d+)\);',raw);assert len(rows)==19
values={}
for name,ty,b,a in rows:values.setdefault(name,[]).append((ty,int(b),int(a)))
assert len(values)==18
for r in o['rows']:
 v=values[r['name']]
 if r['name']=='Runtime':assert v==[('Runtime',1808,16),('Runtime',1872,16)]
 else:assert v==[(r['type'],r['bytes'],r['alignment'])]
assert raw.count('#[cfg(all(target_arch = "x86_64", target_os = "linux"))]')==2
assert '#[cfg(not(feature = "test262-host"))]\n    row!("Runtime", Runtime, 1808, 16);' in raw
assert '#[cfg(feature = "test262-host")]\n    row!("Runtime", Runtime, 1872, 16);' in raw
pattern=r'ALL_SETTLED_LAYOUT (\w+) actual_bytes=(\d+) actual_align=(\d+) parent_bytes=(\d+) parent_align=(\d+) proposed_bytes=(\d+) proposed_align=(\d+)'
observations=[]
for ix,r in enumerate(o['observations']):
 receipt=rd(r['receipt']['path']);log=Path(r['log']['path']).read_text();assert receipt['sha256']==r['log']['sha256']
 assert receipt['exit']==(101 if ix==0 else 0)
 parsed=re.findall(pattern,log);assert len(parsed)==18 and len({x[0] for x in parsed})==18
 for name,*ns in parsed:
  nums=list(map(int,ns));v=values[name][-1 if r['enabled_test262'] and name=='Runtime' else 0];assert nums==[v[1],v[2]]*3,(name,nums,v)
 assert 'arch=x86_64 os=linux pointer_bytes=8' in log
 assert 'test262_host='+str(r['enabled_test262']).lower() in log
 assert 'callback_movement_parent=1 callback_movement_proposed=1 callback_growth8_parent=224 callback_growth8_proposed=224 capture_movement=3 runtime_header_parent=2048 runtime_header_proposed=2048' in log
 result=re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log);assert len(result)==1
 assert tuple(map(int,result[0][:4]))==(1,15 if ix==0 else 0,0,0)
 observations.append(dict(receipt=r['receipt'],log=r['log'],rows=18,result=list(map(int,result[0])),toolchain=receipt['command'][1],enabled_test262=r['enabled_test262']))
before=(D/'before/src/script/promises.rs').read_bytes();assert before==(P/'production-1/raw/src/script/promises.rs').read_bytes()
after=(D/'registrations/src/script/promises.rs').read_bytes();assert after==before+(D/'registration-append.txt').read_bytes()
assert 'all_settled_layout_probe' not in after.decode()
for a,b,old,new,diff in [('',raw,'/dev/null','b/src/script/promises/all_settled_layout_tests.rs','diffs/module.patch'),(before.decode(),after.decode(),'a/src/script/promises.rs','b/src/script/promises.rs','registration.patch')]:assert ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=old,tofile=new))==(D/diff).read_text()
review={'status':'clear','scope':'Permanent actual-type source and existing four completed parent-mirror observations; no candidate production result inferred.','hold':bind(D/'source-ready.json'),'original_mirror_peer':bind(P/'tests-before-1/html-review.json'),'checker':bind(D/'html-check.py'),'observations':observations,'rows_per_configuration':18,'conclusions':['Every18 actual/parent/proposed row joins in all4 root-owned logs; complete mirror source was independently reviewed beforehand.','Actual test references genuine types only, with x86_64 Linux imports/function gating and test262-host Runtime split1808/1872. Derived movement1/callback growth224/capture movement3/header2048 follow recorded widths.','Initial combined parent run exit101 is retained:1 mirror passed and15 missing-method public groups failed. Other3 filtered mirror runs each exit0 with1 pass. These are separate from future actual candidate validation.','44-byte registration appends to the exact reviewed external production promises.rs; temporary probe remains excluded from this selected composition. No production field, fee or visibility change.'],'findings':[],'execution':'Inert JSON/hash/diff/log inspection only; no project code, compiler, engine or tests executed; no live source edits.'}
(D/'html-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(D/'html-review.json'),indent=2))
