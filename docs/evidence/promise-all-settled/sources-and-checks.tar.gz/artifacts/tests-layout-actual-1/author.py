"""External permanent-layout test hold from complete source mirrors/receipts."""
from pathlib import Path
import json, hashlib, re, difflib

P=Path('/tmp/eris-promise-all-settled-plan-1')
OUT=P/'tests-layout-actual-1'
def put(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(p,o): put(p,json.dumps(o,indent=2)+'\n')
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

rows=[
 ('CallbackKind','CallbackKind',16,8),('CallbackRecord','CallbackRecord',24,8),
 ('CallbackArena','Arena<CallbackRecord>',32,8),('State','State',256,8),
 ('PromiseJob','PromiseJob',128,8),('OptionPromiseJob','Option<PromiseJob>',128,8),
 ('PromiseJobArena','Arena<Option<PromiseJob>>',32,8),('QueueJob','QueueJob',24,8),
 ('AllCapture','AllCapture',72,8),('AllCaptureArena','Arena<AllCapture>',32,8),
 ('ReadyAllValues','ReadyAllValues',48,8),('Runtime','Runtime',None,16),
 ('Value','Value',24,8),('ScriptObject','ScriptObject',216,8),
 ('MicrotaskState','microtasks::State',56,8),('Capability','Capability',72,8),
 ('ReactionPair','ReactionPair',120,8),('FinallyCapture','FinallyCapture',48,8)]
observations=[]
for stem,enabled,expected_exit in [
 ('parent-all-settled-1',False,101),('parent-mirror-msrv-host-1',True,0),
 ('parent-mirror-stable-default-1',False,0),('parent-mirror-stable-host-vulkan-1',True,0)]:
    receipt=P/'validation'/(stem+'.json');log=P/'validation'/(stem+'.log')
    data=json.loads(receipt.read_text());text=log.read_text()
    assert data['exit']==expected_exit and data['sha256']==bind(log)['sha256']
    found=re.findall(r'ALL_SETTLED_LAYOUT (\w+) actual_bytes=(\d+) actual_align=(\d+) parent_bytes=(\d+) parent_align=(\d+) proposed_bytes=(\d+) proposed_align=(\d+)',text)
    assert len(found)==18
    assert [r[0] for r in found]==[r[0] for r in rows]
    for (name,*numbers),(_,_,size,align) in zip(found,rows):
        if name=='Runtime': size=1872 if enabled else 1808
        assert list(map(int,numbers))==[size,align]*3,(stem,name,numbers)
    assert 'arch=x86_64 os=linux pointer_bytes=8 test262_host='+str(enabled).lower() in text
    assert 'callback_movement_parent=1 callback_movement_proposed=1 callback_growth8_parent=224 callback_growth8_proposed=224 capture_movement=3 runtime_header_parent=2048 runtime_header_proposed=2048' in text
    assert re.search(r'test script::promises::all_settled_layout_probe::all_settled_prospective_full_types_measure_parent_and_two_callback_variants \.\.\. ok',text)
    observations.append(dict(receipt=bind(receipt),log=bind(log),enabled_test262=enabled,rows=18,
        qualification='Combined run exit101 includes15 expected public failures and1 passing mirror.' if expected_exit else 'Filtered mirror run exited0 with1 passing group.'))

module='''//! Actual production layouts checked against the retained complete mirrors.
//! Numeric expectations are measured only on x86_64 Linux, in four root runs.
#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
use super::*;

#[cfg(all(target_arch = "x86_64", target_os = "linux"))]
#[test]
fn all_settled_actual_layout_matches_the_complete_four_configuration_mirrors() {
    use std::mem::{align_of, size_of};
    macro_rules! row {
        ($name:literal, $ty:ty, $bytes:literal, $alignment:literal) => {
            assert_eq!((size_of::<$ty>(), align_of::<$ty>()), ($bytes, $alignment), $name);
            println!(
                "ALL_SETTLED_LAYOUT_ACTUAL {} bytes={} align={}",
                $name, size_of::<$ty>(), align_of::<$ty>()
            );
        };
    }
'''
for name,ty,size,alignment in rows:
    if name=='Runtime':
        module+='''    #[cfg(not(feature = "test262-host"))]
    row!("Runtime", Runtime, 1808, 16);
    #[cfg(feature = "test262-host")]
    row!("Runtime", Runtime, 1872, 16);
'''
    else: module+=f'    row!("{name}", {ty}, {size}, {alignment});\n'
module+='''    assert_eq!(size_of::<CallbackRecord>().div_ceil(size_of::<Value>()), 1);
    assert_eq!(32 + 8 * size_of::<CallbackRecord>(), 224);
    assert_eq!(size_of::<AllCapture>().div_ceil(size_of::<Value>()), 3);
    assert_eq!(2048usize.max(size_of::<Runtime>()), 2048);
}
'''
rel='src/script/promises/all_settled_layout_tests.rs'
put(OUT/'raw'/rel,module)
before=(P/'production-1/raw/src/script/promises.rs').read_text()
append='\n#[cfg(test)]\nmod all_settled_layout_tests;\n'
put(OUT/'before/src/script/promises.rs',before)
put(OUT/'registration-append.txt',append)
put(OUT/'registrations/src/script/promises.rs',before+append)
put(OUT/'registration.patch',''.join(difflib.unified_diff(before.splitlines(True),(before+append).splitlines(True),fromfile='a/src/script/promises.rs',tofile='b/src/script/promises.rs')))
put(OUT/'diffs/module.patch',''.join(difflib.unified_diff([],module.splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
js(OUT/'oracle.json',dict(rows=[dict(name=n,type=t,bytes=b,alignment=a) for n,t,b,a in rows],
    runtime_bytes=dict(default=1808,test262_host=1872),abi=dict(arch='x86_64',os='linux'),
    derived=dict(callback_movement=1,callback_growth8=224,capture_movement=3,runtime_header_envelope=2048),
    observations=observations,
    measurement_claim='All four root-owned completed parent/prospective-mirror runs agree. This permanent test source itself has not been imported or run. No full production type outcome is inferred.'))
js(OUT/'roster.json',dict(groups=1,rows_per_selected_configuration=18,
    rust_test='script::promises::all_settled_layout_tests::all_settled_actual_layout_matches_the_complete_four_configuration_mirrors',
    parent_eligible=True,parent_reason='Only existing actual private types and size/alignment operations; no new helper/variant reference.',
    expected_parent_outcome='Pass on measured ABI, source/parent-mirror derived; this exact permanent test has not run.',
    excluded_targets='No test or imports emitted outside x86_64 Linux.'))
js(OUT/'source-bindings.json',dict(
    original_mirror_hold=bind(P/'tests-before-1/source-ready.json'),
    mirror=bind(P/'tests-before-1/raw/src/script/promises/all_settled_layout_probe.rs'),
    mirror_declarations=bind(P/'tests-before-1/mirror-declarations.json'),
    mirror_peer=bind(P/'tests-before-1/html-review.json'),
    parent_import=bind(P/'root/parent-controls-import.json'),
    parent_inputs=bind(P/'source-parent-controls.json'),
    production_hold=bind(P/'production-1/source-ready.json'),
    production_review=bind(P/'production-review-1/source-review.json'),
    registered_before=bind(P/'production-1/raw/src/script/promises.rs')))
put(OUT/'notes.txt','''One permanent actual-type group,18 rows per measured x86_64 Linux configuration plus four derived accounting relationships. No duplicate enums, records, State or Runtime remain in this module. The numeric values agree across the completed1.88 default/host and1.99 default/host+Vulkan root-owned mirror runs. The initial combined run has exit101 from15 expected missing-method public failures; its mirror group itself passes. The three later filtered runs exit0.
Registration is an append-only proposal against the already reviewed external production promises.rs, not the currently temporary-probe-registered live source. Root must archive/remove all_settled_layout_probe.rs and its cfg(test) registration before final source composition, then apply production and append this permanent registration alongside any independent private modules. Do not overwrite other registrations with the convenience registered snapshot.
Both function and imports are cfg(all(target_arch="x86_64",target_os="linux")); unmeasured ABIs carry no numeric assertions. The conditional Runtime size is1808 without test262-host and1872 with it. The2048 assertion describes the fixed accounting envelope only, not resident memory/stack use or a new allocation.
All source and tests remain external. Author ran only stdlib log parsing/hash/diff checks; no project code, compiler, formatter, browser or Git process, no live edits. Final candidate compilation/type/stack/bootstrap observations are root-owned and still separate.
''')
js(OUT/'source-ready.json',dict(status='sealed_permanent_actual_layout_control_before_production_import',
    groups=1,rows_per_configuration=18,raw_module=rel,registration='registration-append.txt',
    parent_eligible=True,measured_configurations=4,
    files=[bind(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='source-ready.json'],
    execution='Read-only receipt/log inspection and external stdlib authoring only.'))
print(json.dumps(bind(OUT/'source-ready.json')))
