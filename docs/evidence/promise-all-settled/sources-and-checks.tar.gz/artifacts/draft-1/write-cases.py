from pathlib import Path
import json
P=Path('/tmp/eris-promise-all-settled-plan-1/draft-1')
rows=[]
def case(id,source,readback,expected,purpose): rows.append({'id':id,'source':source.strip()+'\n','readback':readback,'expected':expected,'modes':['sloppy','strict'],'purpose':purpose})
case('metadata', '''
var d = Object.getOwnPropertyDescriptor(Promise, 'allSettled');
var f = d.value, error = '';
try { new f([]); } catch (e) { error = e.name; }
var out = f.name + '|' + f.length + '|' + d.writable + '|' + d.enumerable + '|' + d.configurable + '|' + Object.prototype.hasOwnProperty.call(f, 'prototype') + '|' + error;
''','out','allSettled|1|true|false|true|false|TypeError','Ordinary static method descriptor/arity/name, nonconstructable and no own prototype.')
case('mixed_order_identity', '''
var token = {}, out = '';
Promise.allSettled([1, Promise.reject(token), Promise.resolve(3)]).then(function (a) {
  out = a[0].status + ':' + a[0].value + '|' + a[1].status + ':' + (a[1].reason === token) + '|' + a[2].status + ':' + a[2].value;
});
''','out','fulfilled:1|rejected:true|fulfilled:3','Intrinsic rejection becomes exact reason snapshot; aggregate order follows inputs.')
case('empty_job_order', '''
var out = 'S';
Promise.allSettled([]).then(function () { out += 'E'; });
queueMicrotask(function () { out += 'Q'; });
out += 'B';
''','out','SBEQ','Empty result already fulfilled; reaction queued before later host microtask.')
case('nonempty_job_order', '''
var out = 'S';
Promise.allSettled([1]).then(function () { out += 'A'; });
queueMicrotask(function () { out += 'Q'; });
out += 'B';
''','out','SBQA','Nonempty intrinsic reaction produces aggregate reaction behind already queued Q.')
case('generic_empty_order_no_species_or_close', '''
var out = '';
function C(executor) {
  out += 'C';
  executor(function (a) { 'use strict'; out += 'R' + a.length + (this === undefined ? 'U' : 'X'); }, function () { out += 'X'; });
}
Object.defineProperty(C, 'resolve', {get: function () { out += 'G'; return function () { out += 'W'; }; }});
Object.defineProperty(C, Symbol.species, {get: function () { throw 'species'; }});
var iterator = {};
Object.defineProperty(iterator, 'next', {get: function () { out += 'N'; return function () { out += 'D'; return {done:true}; }; }});
Object.defineProperty(iterator, 'return', {get: function () { throw 'close'; }});
var items = {};
Object.defineProperty(items, Symbol.iterator, {get: function () { out += 'I'; return function () { out += 'J'; return iterator; }; }});
var result = Promise.allSettled.call(C, items);
out += '|' + (result instanceof C);
''','out','CGIJNDR0U|true','Capability before resolve before iterator; empty still gets resolve; no per-value resolve/species/close.')
case('paired_gate_synchronous_sentinel', '''
var token = {}, result, calls = 0, pairs = [], out;
function C(executor) { executor(function (a) { result = a; calls++; }, function () { throw 'reject'; }); }
C.resolve = function (v) { return {then:function (f,r) {
  pairs.push([f,r]);
  if (calls !== 0) throw 'premature';
  if (v === 0) { f('A'); r('ignored'); f('ignored'); }
  else { r(token); f('ignored'); r('ignored'); }
  if (calls !== 0) throw 'premature';
}}; };
Promise.allSettled.call(C, [0,1]);
var dup = pairs[0][1]('late');
out = calls + '|' + result[0].status + ':' + result[0].value + '|' + result[1].status + ':' + (result[1].reason === token) + '|' + (dup === undefined) + '|' + (pairs[0][0] !== pairs[0][1]) + '|' + (pairs[0][0] !== pairs[1][0]);
''','out','1|fulfilled:A|rejected:true|true|true|true','Both callback directions share one gate per element, different elements independent; synchronous then cannot consume input sentinel.')
case('saved_callbacks_return_and_order', '''
var pairs = [], marker = {}, token = {}, result, calls = 0;
function C(executor) { executor(function (a) { 'use strict'; if (this !== undefined) throw 'this'; result = a; calls++; return 'RET'; }, function () { throw 'reject'; }); return marker; }
C.resolve = function () { return {then:function (f,r) { pairs.push([f,r]); }}; };
var p = Promise.allSettled.call(C, [0,1]);
var first = pairs[1][1].call({wrong:true}, token);
var last = pairs[0][0].call(null, 7);
var duplicate = pairs[0][1]('ignored');
var out = (p === marker) + '|' + (first === undefined) + '|' + last + '|' + (duplicate === undefined) + '|' + calls + '|' + result[0].status + ':' + result[0].value + '|' + result[1].status + ':' + (result[1].reason === token);
''','out','true|true|RET|true|1|fulfilled:7|rejected:true','Dynamic callback receiver ignored, last callback returns custom resolve result, reverse completion preserves index.')
case('last_resolve_throw_consumes_pair', '''
var f, r, token = {}, seen, calls = 0;
function C(executor) { executor(function () { calls++; throw token; }, function () { throw 'reject'; }); }
C.resolve = function () { return {then:function (a,b) { f = a; r = b; }}; };
Promise.allSettled.call(C, [1]);
try { f(7); } catch (e) { seen = e; }
var duplicate = r('ignored');
var out = (seen === token) + '|' + calls + '|' + (duplicate === undefined);
''','out','true|1|true','Final custom resolve throw escapes exact callback; gate stays consumed and duplicate does not revisit moved-out Group.')
case('ordinary_resolve_abort_retains_sentinel', '''
var f, r, token = {}, other = {}, rejected, calls = 0, closed = 0, index = 0;
function C(executor) { executor(function () { calls++; }, function (x) { rejected = x; }); }
C.resolve = function (v) { if (v === 2) throw token; return {then:function (a,b) { f = a; r = b; }}; };
var iterator = {next:function () { index++; return index <= 2 ? {done:false,value:index} : {done:true}; }, return:function () { closed++; throw other; }};
var items = {}; items[Symbol.iterator] = function () { return iterator; };
Promise.allSettled.call(C, items);
var first = r('reason'), duplicate = f('ignored');
var out = (rejected === token) + '|' + closed + '|' + calls + '|' + (first === undefined) + '|' + (duplicate === undefined);
''','out','true|1|0|true|true','Ordinary close error cannot replace pending resolve error; saved rejection cannot remove unfinished input sentinel.')
case('ordinary_next_abort_does_not_close', '''
var f, r, token = {}, rejected, calls = 0, closed = 0, index = 0;
function C(executor) { executor(function () { calls++; }, function (x) { rejected = x; }); }
C.resolve = function () { return {then:function (a,b) { f = a; r = b; }}; };
var iterator = {next:function () { if (index++) throw token; return {done:false,value:1}; }};
Object.defineProperty(iterator, 'return', {get:function () { closed++; throw 'close'; }});
var items = {}; items[Symbol.iterator] = function () { return iterator; };
Promise.allSettled.call(C, items);
f(1); var duplicate = r('ignored');
var out = (rejected === token) + '|' + closed + '|' + calls + '|' + (duplicate === undefined);
''','out','true|0|0|true','Next failure marks iterator done and leaves sentinel; poisoned return getter makes absence of close observable.')
case('invalid_constructor_before_inputs', '''
var touched = 0, target = {}, items = {}, error = '';
Object.defineProperty(target, 'resolve', {get:function () { touched++; throw 'resolve'; }});
Object.defineProperty(items, Symbol.iterator, {get:function () { touched++; throw 'iterator'; }});
try { Promise.allSettled.call(target, items); } catch (e) { error = e.name; }
var out = error + '|' + touched;
''','out','TypeError|0','Capability validation precedes either getter; missing-method parent TypeError is not a meaningful feature-failure witness without a separate presence guard.')
case('noncallable_resolve_rejects_before_iterator', '''
var out = '', reason;
function C(executor) { out += 'C'; executor(function () { out += 'R'; }, function (x) { reason = x; out += 'X'; }); }
Object.defineProperty(C, 'resolve', {get:function () { out += 'G'; return 1; }});
var items = {}; Object.defineProperty(items, Symbol.iterator, {get:function () { out += 'I'; throw 'iterator'; }});
var p = Promise.allSettled.call(C, items);
out += '|' + reason.name + '|' + (p instanceof C);
''','out','CGX|TypeError|true','Resolve callability ordinary error rejects exact generic capability before iterator access.')
case('snapshot_shape_intrinsics_and_undefined', '''
var O = Object, A = Array, op = Object.prototype, ap = Array.prototype, pairs = [], result, setterCalls = 0;
function C(executor) { executor(function (a) { result = a; }, function () { throw 'reject'; }); }
C.resolve = function () { return {then:function (f,r) { pairs.push([f,r]); }}; };
Promise.allSettled.call(C, [0,1]);
O.defineProperty(op, 'status', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'value', {set:function () { setterCalls++; }, configurable:true});
O.defineProperty(op, 'reason', {set:function () { setterCalls++; }, configurable:true});
Object = function () { throw 'global Object'; }; Array = function () { throw 'global Array'; };
pairs[0][0](); pairs[1][1]();
Object = O; Array = A;
delete op.status; delete op.value; delete op.reason;
var d = O.getOwnPropertyDescriptor(result[0], 'value'), e = O.getOwnPropertyDescriptor(result[1], 'reason');
var out = setterCalls + '|' + (O.getPrototypeOf(result) === ap) + '|' + (O.getPrototypeOf(result[0]) === op) + '|' + (result[0] !== result[1]) + '|' + O.keys(result[0]).join(',') + '|' + O.keys(result[1]).join(',') + '|' + (d.value === undefined && e.value === undefined) + '|' + (d.writable && d.enumerable && d.configurable && e.writable && e.enumerable && e.configurable);
''','out','0|true|true|true|status,value|status,reason|true|true','Fresh intrinsic Object/Array with own ordinary data descriptors bypass inherited setters/global replacements; absent callback args still make own undefined payload properties.')
case('snapshot_payload_is_not_assimilated', '''
var token = {}, reads = 0, result, pairs = [];
Object.defineProperty(token, 'then', {get:function () { reads++; throw 'payload then'; }});
function C(executor) { executor(function (a) { result = a; }, function () { throw 'reject'; }); }
C.resolve = function () { return {then:function (f,r) { pairs.push([f,r]); }}; };
Promise.allSettled.call(C, [0,1]);
pairs[0][0](token); pairs[1][1](token);
var out = reads + '|' + (result[0].value === token) + '|' + (result[1].reason === token);
''','out','0|true|true','Both result payloads retain identity without touching then; this isolates storage from the separate C.resolve algorithm.')
(P/'semantic-cases.json').write_text(json.dumps({'status':'authored_prospective_literals_not_executed','count':len(rows),'mode_rows':2*len(rows),'harness_contract':'Future Rust conversion uses fresh Runtime per row, strict prefix when requested, then existing post-checkpoint readback. No quota reset inside execution. Invalid-constructor row requires explicit method-presence guard in conversion to avoid false parent success. All other rows naturally demand the method. No Rust module or registration is authored in this plan.','cases':rows},indent=2)+'\n')
