"""External source-only supplemental test generation; no project imports."""
from pathlib import Path
import json
import hashlib
import difflib
import re

ROOT=Path('/tmp/eris-promise-all-settled-plan-1')
OUT=ROOT/'tests-supplement-1'
BASE=Path('/tmp/eris-text-metadata-keys-1/worktree')
HOLD=ROOT/'tests-before-1'

def put(path,text):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(text)
def js(path,obj): put(path,json.dumps(obj,indent=2)+'\n')
def bind(path):
    b=path.read_bytes()
    return dict(path=str(path),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

source=(OUT/'case.js').read_text()
expected='true|true|true|true|true|true|true|true'
helper=(HOLD/'helper-original.txt').read_text().rstrip()+'\n'
name='promise_all_settled_supplemental_metadata_status_and_intrinsic_prototypes'
rel='src/script/promise_all_settled_supplemental_tests.rs'
module='''//! Separately selected supplement; original fourteen semantic cases stay exact.
//! Descriptor checks, independent callback metadata, and both snapshot prototypes.
use super::*;

'''+helper+'\n#[test]\nfn '+name+'() {\n    observe(\n        "supplemental_metadata_status_and_intrinsic_prototypes",\n        r###"'+source+'"###,\n        r###"out"###,\n        Value::String('+json.dumps(expected)+'.into()),\n    );\n}\n'
put(OUT/'raw'/rel,module)
before=(HOLD/'registrations/src/script.rs').read_text()
append='\n#[cfg(test)]\nmod promise_all_settled_supplemental_tests;\n'
put(OUT/'before/src/script.rs',before)
put(OUT/'registration-append.txt',append)
put(OUT/'registrations/src/script.rs',before+append)
put(OUT/'registration.patch',''.join(difflib.unified_diff(before.splitlines(True),(before+append).splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs')))
put(OUT/'diffs/module.patch',''.join(difflib.unified_diff([],module.splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
js(OUT/'oracle.json',dict(status='authored_source_derived_before_execution',source=source,readback='out',expected=expected,modes=['sloppy','strict'],
    fields=[
        dict(name='methodMeta',expected=True,derivation='Method name/arity and own name/length non-writable/non-enumerable/configurable descriptors, intrinsic Function prototype, no own prototype, and new rejects TypeError.'),
        dict(name='callbackMeta',expected=True,derivation='All four callbacks across two elements have empty names, arity1 and the same flags, intrinsic Function prototype, no own prototype; new rejects without settling either element.'),
        dict(name='distinct',expected=True,derivation='Every pairwise identity among the four fresh builtin callbacks differs.'),
        dict(name='independent',expected=True,derivation='Redefining first fulfillment name/length and first rejection name does not modify any other callback metadata bag.'),
        dict(name='statuses',expected=True,derivation='Both snapshots own status data properties with fulfilled/rejected values and all writable/enumerable/configurable flags true.'),
        dict(name='prototypes',expected=True,derivation='Both snapshots use saved intrinsic Object.prototype after global Object replacement.'),
        dict(name='payloads',expected=True,derivation='First fulfillment and second rejection retain exact distinct object payload identities in input-index order.'),
        dict(name='onceAndSetter',expected=True,derivation='Two saved callbacks after normal exhaustion invoke custom aggregate resolve once; own status publication bypasses poisoned inherited setter.')],
    parent_eligible=True,predicted_parent_outcome='failure on absent method in metadata helper, not an observed result',
    parent_mode_reach='Sloppy executes first; if it fails, strict is not reached in that group.',
    prior14_unchanged=True,selection='Root explicitly requested this supplemental group before any candidate production or test execution.'))
js(OUT/'roster.json',dict(groups=1,planned_mode_rows=2,tests=['script::promise_all_settled_supplemental_tests::'+name],parent_eligible=True))
source_paths=['src/script/promises.rs','src/script/promises/install.rs','src/script/promises/factories.rs',
    'src/script/promises/all_state.rs','src/script/promises/semantics.rs','src/script/dom_prototypes.rs',
    'src/script/promise_all_semantic_tests.rs']
inventory=json.loads((BASE.parent/'source-candidate-extended.json').read_text())['source_sha256']
bound=[]
for relpath in source_paths:
    b=bind(BASE/relpath)
    assert b['sha256']==inventory[relpath]
    saved=OUT/'source-snapshots'/relpath
    put(saved,(BASE/relpath).read_text())
    bound.append(dict(relative_path=relpath,source=b,snapshot=bind(saved)))
js(OUT/'source-bindings.json',dict(baseline='Same AY candidate as original14; publication pending at authoring.',
    selected_inventory=bind(BASE.parent/'source-candidate-extended.json'),original_hold=bind(HOLD/'source-ready.json'),
    original_public_module=bind(HOLD/'raw/src/script/promise_all_settled_semantic_tests.rs'),
    registration_parent=bind(HOLD/'registrations/src/script.rs'),helper=bind(HOLD/'helper-original.txt'),sources=bound))
put(OUT/'notes.txt','''One new group/two planned modes selected additively by root to close identified descriptor/prototype coverage gaps. Original14 literal sources and expectations remain unchanged and separately held. This module uses an exact copy of the existing Promise.all observe helper; each mode has a fresh Runtime and separate normal source/readback execution. No private API or counter reset.
The source expects eight true observations, independently derived from the ordinary builtin method and per-element callback/result contracts. No outcome was copied from execution. Prototype checks are made for both snapshots while their creation occurs after global Object replacement; status setters on the saved intrinsic are observable but must remain uncalled. All four callback identities and metadata are checked; mutating three configurable metadata properties proves storage independence while the original callback capabilities remain callable.
Registration before bytes compose the exact original14 append over AY script.rs. Root can append both snippets sequentially; never replace a live file containing other later changes. This supplement does not register the temporary mirror or modify its holder.
No build/formatter/compiler/engine/browser/Git/project execution or live source edits. External stdlib generation, hashes and exact extraction only.
''')
raw=re.search(r'r###"([\s\S]*?)"###,\n        r###"out"###,\n        Value::String\(("[^"]*")\.into\(\)\)',module)
assert raw and raw[1]==source and json.loads(raw[2])==expected
assert module.count('#[test]')==1
js(OUT/'source-ready.json',dict(status='sealed_additive_public_test_before_production',groups=1,planned_mode_rows=2,parent_eligible=True,
    raw_module=rel,registration='registration-append.txt',prior_hold=bind(HOLD/'source-ready.json'),
    files=[bind(p) for p in sorted(OUT.rglob('*')) if p.is_file() and p.name!='source-ready.json'],
    execution='External static authoring only; no project execution/live edits.'))
print(json.dumps(bind(OUT/'source-ready.json')))
