from pathlib import Path
import hashlib,json,subprocess,time
p=Path(__file__).resolve().parent;w=p/'worktree';o=p/'conformance';o.mkdir(exist_ok=True)
plan=json.loads((p/'conformance-plan.json').read_text()); rows=[]
for phase,binary in [('before',Path('/tmp/eris-number-format-preparation-1/eris-js-before')),('after',p/'eris-js-after')]:
    for selection in plan['profiles']:
        profile=selection['profile']; baseline=w/'tests/conformance'/selection['baseline']; assert hashlib.sha256(baseline.read_bytes()).hexdigest()==selection['sha256'];label=phase+'-'+profile; report=o/(label+'.json'); log=o/(label+'.log'); assert not report.exists(); argv=['python3',str(w/'tools/test262_conformance.py'),'--binary',str(binary),'--profile',profile,'--baseline',str(baseline),'--output',str(report),'--jobs','4'];start=time.monotonic()
        with log.open('xb') as out: result=subprocess.run(argv,cwd=w,stdout=out,stderr=subprocess.STDOUT,close_fds=True,timeout=180)
        data=json.loads(report.read_text()); row={'phase':phase,'profile':profile,'exit':result.returncode,'elapsed_seconds':time.monotonic()-start,'command':argv,'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'counts':data['counts'],'regressions':len(data['regressions']),'improvements':len(data['improvements']),'harness_preflight_passed':data['harness_preflight_passed']}; rows.append(row); print(json.dumps(row),flush=True)
        (o/(label+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n')
(o/'summary.json').write_text(json.dumps(rows,indent=2)+'\n')
raise SystemExit(int(any(row['exit'] for row in rows)))
