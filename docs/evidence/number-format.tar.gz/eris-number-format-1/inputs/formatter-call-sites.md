# Paid formatting route inventory

Source read: published 56bbcdffce92417bcfdd52b89cbf67e777c00c16; the three-file scalar codec extraction subsequently published as 71e52bf does not change these Number routes. Line numbers refer to the retained 56bbcdf copies. This is a source inventory, not an implementation or execution receipt.

| Site | Current route | Correction obligation |
|---|---|---|
| script.rs:193–196 `Value::js_string` | Immutable helper calls `json_number` for Number. | Cannot itself debit Runtime/compile budgets. Audit every author-reachable caller; do not leave this as an unpaid bypass. |
| script.rs:4126 `addition_text` | Number prepays 128 work and 1024 bytes, then `js_string`. | Preserve old fee and add reached correction work before helper operations. |
| script.rs:5475 `number_to_string` | Radix 10, nonfinite and zero enter `js_string`, then runtime string storage. | Route Number formatting through the paid entry after observable radix conversion; preserve nondecimal behavior. |
| script.rs:6570 `string_hint` | Performs observable ToPrimitive(string); non-string primitives prepay 1024 bytes; immutable `js_string` follows. | Pay reached Number correction after author hooks, including String(), property keys and downstream String arguments. |
| script.rs:6582 `json_text` | Direct Number branch uses `json_number`; boxed primitives recurse through author hooks. | Pay direct Number branch, preserving callback order and recursion accounting. |
| script.rs:6728 `json_stringify` replacer list | Direct Number list entry becomes a property string. | Charge before formatting, including Number-valued replacer entries. Boxed Number entries reach `json_text`. |
| script.rs:6901 `json_emit_inner` | Finite Number formats before `json_append`; nonfinite emits null. | Prepay correction before formatting; output writer debit happens later and is not a substitute. |
| script.rs:6649 `json_text` fallback | Other primitives use `js_string`. | Number already has a preceding explicit branch; preserve that separation. |
| script.rs:8675 primitive method dispatch | Number.toString explicitly enters `number_to_string`; remaining String/Boolean toString uses `js_string`. | Preserve dispatch so this cannot become a Number bypass after refactoring. |
| script.rs:9023 legacy receiver toString | Number takes preceding `number_to_string`; Bool uses `js_string`. | Preserve that explicit Number branch. |
| script/parser.rs:391 `object_key` | Numeric literal key pays compile_allocate(160) and compile work(1), then formats. | Add reached correction to CompileBudget before work, not Runtime budget; propagate compile Resource. |
| script/parser_legacy.rs:877 `object_key` | Numeric literal key directly formats. | If this path remains callable, use its existing CompileBudget to admit correction before it occurs. Being a legacy parser is not by itself a safety argument. |
| script.rs:14454 formatter private cases | Pure helper invoked directly by tests. | This pure use may stay; add literals and separate paid-boundary tests. |

`property_keys.rs::to_property_key` preserves an already-produced Symbol and sends other primitives through string conversion; the classifier receives a completed string key and must not repeat author coercion. Runtime String construction and string/property APIs funnel through `string_hint`/`json_text` in multiple places. A final implementation review should mechanically search all `json_number(` and `js_string(` references again, including new helpers, rather than assuming the above list stays exhaustive after edits.

The added correction is a fixed bounded integer algorithm but its accounting must remain fallible. A suitable implementation contract accepts a work callback returning the caller's existing error type, so a compilation debit is not silently converted into runtime budget state and Runtime Resource remains terminal. Root owns the exact callback API, scalar rows, allocation policy and implementation.
