# Number formatting Page/worker source witness

The four owned new paths are frozen as source only. Root owns compilation and all actual execution. Current predecessor is 71e52bf1732d6c0a629328287729de029fb4920a; the shared formatter candidate remains unvalidated for this new witness.

The example displays a positive 10^15+1/4 amount using String, JSON array output, and a computed object property name returned by Object.keys. A real Change sign click changes to the negative amount. All expected strings end in .2 and are literal in the two independent script-free reference documents. Labels describe the visible result. The example has no external resource dependency.

The direct loaded Page and Linux confined-worker tests share the same check routine. Worker generation219 uses actual Load/Render/Click process exchanges, edit sequence0 and established confinement diagnostic checks. The ignored worker group requires enforced Landlock ABI6 and is not replaced by a direct Page. Fixture directories use create_dir collision checks and owned cleanup; the worker is dropped before directory removal.

Both phases assert exact Text UTF-16 units, metadata, seventeen retained IDs, complete parent/children graph equality, hit testing to the genuine button or its sole Text child, and complete 640x240 Canvas equality against independently parsed literal HTML. Text-run counts and ink in each amount row reject vacuous rendering; literal green/blue and white samples bind the scene separately. No output string or observed DOM subtree is used to construct the references. No GPU route or performance claim is made.

Source formatting only used the already-installed Rust1.88 rustfmt binary. The first ordinary rustup launcher attempt failed before formatting because its default home was read-only; that failure and the unformatted source are retained. No compiler, JavaScript parser, test, browser, renderer or engine was run by the author.
