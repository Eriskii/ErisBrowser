from pathlib import Path
import ast,hashlib,json
N=Path('/tmp/eris-promise-any-upstream-plan-1');D=N/'preservation-1';old=N/'readiness-1/snapshots/tools'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
# Data-only AST interpretation: literal containers, selected named constants,
# set unions and copies. No Python project statement/function is executed.
def constants(p):
 env={}
 def value(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,ast.Set):return {value(x) for x in n.elts}
  if isinstance(n,ast.List):return [value(x) for x in n.elts]
  if isinstance(n,ast.Tuple):return tuple(value(x) for x in n.elts)
  if isinstance(n,ast.Dict):return {value(k):value(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.BitOr):return value(n.left)|value(n.right)
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='copy' and not n.args and not n.keywords:return value(n.func.value).copy()
  raise ValueError(ast.dump(n))
 for node in ast.parse(p.read_text()).body:
  if not isinstance(node,ast.Assign) or len(node.targets)!=1:continue
  try:v=value(node.value)
  except (KeyError,ValueError,TypeError):continue
  target=node.targets[0]
  if isinstance(target,ast.Name):env[target.id]=v
  elif isinstance(target,ast.Subscript) and isinstance(target.value,ast.Name):
   try:env[target.value.id][value(target.slice)]=v
   except (KeyError,ValueError,TypeError):pass
 return env
j=json.loads((D/'promise-any-preservation-oracle.json').read_text());hold=json.loads((D/'source-ready.json').read_text())
for row in hold['files']:
 b=row['raw'];p=Path(b['path']);assert(p.stat().st_size,sha(p.read_bytes()))==(b['bytes'],b['sha256'])
i=constants(old/'import_test262.py');r=constants(old/'test262_conformance.py')
assert j['profiles']==i['PROFILES'] and j['roots']==i['PROFILE_ROOTS']
assert j['tree_profiles']==sorted(i['TREE_PROFILES'])
assert j['features']=={k:sorted(v) for k,v in r['PROFILE_FEATURES'].items()}
assert j['promise_host_profiles']==sorted(r['PROMISE_HOST_PROFILES'])
assert j['intrinsic_errors']==sorted(r['INTRINSIC_ERRORS'])
assert len(j['profiles'])==len(j['policies_at_timeout3'])==58
for profile,held in j['policies_at_timeout3'].items():
 errors=r['INTRINSIC_ERRORS']|({'AggregateError'} if profile=='aggregate-error' else set())
 p=dict(format=2,supported_features=sorted(r['PROFILE_FEATURES'][profile]),negative_intrinsic_errors=sorted(errors),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if profile in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:p['excluded_harness']=['resizableArrayBufferUtils.js']
 if profile in r['PROMISE_HOST_PROFILES']:
  p.update(format=3,async_completion=True,host_hooks=True,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
 assert p==held['policy'],profile
 assert sha(json.dumps(p,sort_keys=True).encode())==held['sha256'],profile
source=(old/'test262_conformance.py').read_text();actual={n.name:sha(ast.get_source_segment(source,n).encode()) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef) and n.name in j['unchanged_runner_functions']}
assert actual==j['unchanged_runner_functions'] and len(actual)==22
receipt=Path(hold['parent_policy_capture']['path']);assert bind(receipt)==hold['parent_policy_capture'];c=json.loads(receipt.read_text());log=receipt.parent/c['log'];assert c['exit']==0 and sha(log.read_bytes())==c['sha256'];assert json.loads(log.read_text())['sha256']==sha((D/'promise-any-preservation-oracle.json').read_bytes())
review=dict(status='clear',scope='Independent source/data peer of two parent-compatible preservation groups',hold=bind(D/'source-ready.json'),checks=dict(old_tables_and_rosters=58,independently_reconstructed_policy_objects_and_hashes=58,unchanged_function_body_hashes=22,parent_capture_log_verified=True,test_groups=2),findings=[],conclusions=['All58 policies/table/feature bindings independently reconstruct from retained parent literal ASTs and the current main policy recipe; original seven default identities and four old host profiles remain exact.','The first test mocks corpus/preflight/dispatch and exercises real main policy construction for each original profile; the selected new profile is excluded only from historical views. No engine or network can execute.','The second test binds exact22 old function source segments, including legacy builders/gates/literals, fingerprint/request helpers, completion predicate and host-reason function. It deliberately excludes the eight selected identity seams.','Both tests use existing parent APIs and source structures; parent compatibility is a source conclusion, not a test execution result.'],sources=[bind(old/'import_test262.py'),bind(old/'test262_conformance.py'),bind(receipt),bind(log)],verification_source=bind(D/'layout-check.py'),execution='Python stdlib AST/data/hash checks only. No project import/execution, live edit, network or candidate inspection.')
(D/'layout-review.json').write_text(json.dumps(review,indent=2)+'\n');print(bind(D/'layout-review.json'))
