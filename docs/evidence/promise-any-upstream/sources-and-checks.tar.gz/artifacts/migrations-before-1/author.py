from pathlib import Path
import ast,difflib,hashlib,json
N=Path('/tmp/eris-promise-any-upstream-plan-1');W=N/'worktree';D=N/'migrations-before-1'
census=json.loads((N/'controls-1/migration-census.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def write(p,j):p.write_text(json.dumps(j,indent=2)+'\n')
by_path={}
for r in census['entries']:by_path.setdefault(r['path'],[]).append(r)
files=[];changes=[]
for rel,rows in sorted(by_path.items()):
 p=W/rel;before=p.read_text();expected=next(x['sha256'] for x in census['bindings'] if x['path']==str(p));assert sha(p.read_bytes())==expected
 lines=before.splitlines(keepends=True); edits=[]
 for r in rows:
  index=r['line']-1;old=lines[index]
  if r['expression']=='runner.PROMISE_HOST_PROFILES':
   assert 'self.assertEqual(runner.PROMISE_HOST_PROFILES,' in old
   new=old.replace('runner.PROMISE_HOST_PROFILES,',"runner.PROMISE_HOST_PROFILES - {'promise-any'},")
  elif 'if k != NEW_PROFILE' in old:
   new=old.replace('if k != NEW_PROFILE',"if k not in {NEW_PROFILE, 'promise-any'}")
  elif 'importer.TREE_PROFILES - {NEW_PROFILE}' in old:
   new=old.replace('importer.TREE_PROFILES - {NEW_PROFILE}',"importer.TREE_PROFILES - {NEW_PROFILE, 'promise-any'}")
  else:
   assert old.count("'aggregate-error'")==1
   new=old.replace("'aggregate-error'","'aggregate-error', 'promise-any'")
  assert old!=new and new.count("'promise-any'")==1
  lines[index]=new;edits.append(dict(line=r['line'],before=old,after=new))
 after=''.join(lines);ast.parse(before);ast.parse(after)
 reverse=after.splitlines(keepends=True)
 for e in edits:
  assert reverse[e['line']-1]==e['after'];reverse[e['line']-1]=e['before']
 assert ''.join(reverse)==before
 bp=D/'before'/rel;rp=D/'raw'/rel;dp=D/'diffs'/(rel+'.patch')
 for q in (bp,rp,dp):q.parent.mkdir(parents=True,exist_ok=True)
 bp.write_text(before);rp.write_text(after);dp.write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)))
 files.append(dict(path=rel,before=bind(bp),raw=bind(rp),diff=bind(dp),exclusion_count=len(edits),exact_inverse=True));changes.append(dict(path=rel,edits=edits))
assert len(files)==18 and sum(x['exclusion_count'] for x in files)==29
write(D/'changes.json',dict(changes=changes,scope='Only promise-any is excluded from historical profile-roster views. Every old numeric total, oracle, feature/policy/hash and diagnostic/identity control remains unchanged.',counts=dict(paths=18,exclusions=29)))
write(D/'source-ready.json',dict(status='sealed external historical test-roster migrations; no execution',base='90c653d813feb62d1d569864bec076c0cc92d8a5',census=bind(N/'controls-1/migration-census.json'),files=files,changes=bind(D/'changes.json'),author=bind(D/'author.py'),checks=dict(paths=18,exclusions=29,ast_parsed=True,exact_reverse=True,oracle_files_changed=0),execution='Only stdlib source/hash/AST/diff processing; no project imports, live edits or tests.'))
print(bind(D/'source-ready.json'))
