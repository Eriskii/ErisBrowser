import base64
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
from pathlib import Path
import re
import subprocess

A = Path(__file__).resolve().parents[1]
R = A / 'fetch-1'
R.mkdir(exist_ok=False)
(R / 'responses').mkdir()
(R / 'sources').mkdir()
tree = json.loads((A / 'root/any-tree-response.json').read_bytes())
entries = tree['tree']
raw = b''.join(row['mode'].lstrip('0').encode() + b' ' + row['path'].encode()
               + b'\0' + bytes.fromhex(row['sha']) for row in entries)
assert hashlib.sha1(b'tree ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == tree['sha'] == 'e2352be158fb0c0625d1ab642330faabc62a2df8'
assert len(entries) == 94 and all(row['type'] == 'blob' for row in entries)

def fetch(row):
    name, sha = row['path'], row['sha']
    assert '/' not in name and name.endswith('.js') and re.fullmatch('[0-9a-f]{40}', sha)
    assert 0 <= row['size'] <= 128 * 1024
    result = subprocess.run(['gh', 'api', 'repos/tc39/test262/git/blobs/' + sha],
                            capture_output=True, check=True, timeout=30)
    response = R / 'responses' / (name + '.json')
    response.write_bytes(result.stdout)
    body = json.loads(result.stdout)
    assert body['sha'] == sha and body['encoding'] == 'base64'
    data = base64.b64decode(''.join(body['content'].split()), validate=True)
    assert len(data) == row['size'] == body['size']
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == sha
    (R / 'sources' / name).write_bytes(data)
    return dict(name=name, git_sha1=sha, bytes=len(data), sha256=hashlib.sha256(data).hexdigest(),
                response_sha256=hashlib.sha256(result.stdout).hexdigest())

with ThreadPoolExecutor(max_workers=4) as pool:
    rows = list(pool.map(fetch, entries))
assert len(rows) == 94 and sum(row['bytes'] for row in rows) < 8 * 1024 * 1024
receipt = dict(status='authenticated', direct_source_count=94, tree_sha1=tree['sha'],
               sources=rows, project_execution=False, live_worktree_changes=False)
(R / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(sources=len(rows), bytes=sum(row['bytes'] for row in rows),
                     receipt_sha256=hashlib.sha256((R/'receipt.json').read_bytes()).hexdigest())))
