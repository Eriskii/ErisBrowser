import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
E = W / 'docs/evidence/promise-any-upstream'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

manifest = json.loads((E / 'manifest.json').read_bytes())
archive_path = E / manifest['archive']['path']
assert bind(archive_path)['sha256'] == manifest['archive']['sha256']
assert bind(archive_path)['bytes'] == manifest['archive']['bytes']
selected = json.loads((P / 'root/evidence-selection.json').read_bytes())['members']
assert manifest['members'] == selected
with tarfile.open(archive_path, 'r:gz') as archive:
    assert archive.getnames() == [row['path'] for row in selected]
    for row in selected:
        member = archive.getmember(row['path'])
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
        assert data == Path(row['origin']).read_bytes(), row['origin']
final = json.loads((P / 'source-final.json').read_bytes())['source_sha256']
parent = json.loads((P / 'source-parent.json').read_bytes())['source_sha256']
for name, sha in final.items():
    assert bind(W / name)['sha256'] == sha, name
source_paths = {name for name, sha in final.items() if parent.get(name) != sha}
docs = json.loads((P / 'documentation-1/source-ready.json').read_bytes())['files']
doc_paths = {row['path'] for row in docs}
for row in docs:
    assert bind(W / row['path'])['sha256'] == row['raw']['sha256']
corpus_oracle = json.loads((W / 'tools/test262-promise-any-import-oracle.json').read_bytes())
corpus_paths = {'tests/upstream/test262-promise-any/' + row['path'] for row in corpus_oracle['all_files']}
assert len(corpus_paths) == 110
expected = source_paths | corpus_paths | doc_paths | {
    'docs/evidence/promise-any-upstream/manifest.json',
    'docs/evidence/promise-any-upstream/sources-and-checks.tar.gz'}
assert len(source_paths) == 30 and len(doc_paths) == 7 and len(expected) == 149
changed = set(subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=W, text=True).splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W, text=True).splitlines())
assert changed == expected, dict(missing=sorted(expected - changed), extra=sorted(changed - expected))
subprocess.run(['git', 'diff', '--check'], cwd=W, check=True)
receipt = dict(status='verified', expected_commit_paths=sorted(expected),
               path_count=149, source_paths=30, corpus_paths=110, documentation_paths=7, evidence_paths=2,
               archive=bind(archive_path), manifest=bind(E / 'manifest.json'),
               members=len(selected), every_archive_member_equals_origin=True,
               every_selected_source_equals_final_inventory=True)
output = P / 'root/publication-verification.json'
assert not output.exists()
output.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: value for key, value in receipt.items() if key != 'expected_commit_paths'}))
