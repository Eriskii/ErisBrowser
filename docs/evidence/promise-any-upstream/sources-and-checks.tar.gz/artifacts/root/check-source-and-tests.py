"""Verify unchanged tracked inputs and the actual verbose Python test roster."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'


def sha(data):
    return hashlib.sha256(data).hexdigest()


selected = json.loads((A / 'source-final.json').read_bytes())
parent = json.loads((A / 'source-parent.json').read_bytes())
for name, expected in selected['source_sha256'].items():
    assert sha((W / name).read_bytes()) == expected, name
changed = set(selected['changed_paths'])
old_changed = changed & parent['source_sha256'].keys()
assert len(changed) == 30 and len(old_changed) == 21
paths = ['.github', 'Cargo.toml', 'Cargo.lock', 'assets', 'src', 'crates', 'tools', 'tests', 'examples']
tree = subprocess.check_output(['git', 'ls-tree', '-rz', '--full-tree', 'HEAD', '--', *paths], cwd=W)
rows = []
for entry in tree.split(b'\0'):
    if not entry:
        continue
    metadata, raw_name = entry.split(b'\t', 1)
    mode, kind, expected = metadata.decode().split()
    name = raw_name.decode()
    assert kind == 'blob' and mode in {'100644', '100755'}, name
    data = (W / name).read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert (actual != expected) == (name in old_changed), name
    rows.append(dict(path=name, parent_git_blob=expected, current_git_blob=actual, bytes=len(data)))
assert old_changed <= {row['path'] for row in rows}
groups = {}
for prefix in ('src/', 'crates/', 'tools/', 'tests/upstream/', 'tests/conformance/'):
    chosen = [row for row in rows if row['path'].startswith(prefix)]
    groups[prefix] = dict(files=len(chosen), unchanged=sum(row['parent_git_blob'] == row['current_git_blob'] for row in chosen),
                          bytes=sum(row['bytes'] for row in chosen),
                          inventory_sha256=sha(json.dumps(chosen, sort_keys=True).encode()))
new_corpus = W / 'tests/upstream/test262-promise-any'
oracle = json.loads((W / 'tools/test262-promise-any-import-oracle.json').read_bytes())
assert {p.relative_to(new_corpus).as_posix() for p in new_corpus.rglob('*') if p.is_file()} == {row['path'] for row in oracle['all_files']}
for row in oracle['all_files']:
    data = (new_corpus / row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']

declared = set()
new = set()
for path in sorted((W / 'tools').glob('test_*.py')):
    for node in ast.parse(path.read_text()).body:
        if isinstance(node, ast.ClassDef):
            for method in node.body:
                if isinstance(method, ast.FunctionDef) and method.name.startswith('test_'):
                    name = f'{path.stem}.{node.name}.{method.name}'
                    assert name not in declared
                    declared.add(name)
                    if 'promise_any' in path.name:
                        new.add(name)
log = (A / 'validation/python-full-1.log').read_text()
found = re.findall(r'^test_[^\s]+ \(([^)]+)\) \.\.\. ok$', log, re.M)
assert len(found) == len(set(found)) == len(declared) == 624
assert set(found) == declared
assert len(new) == 32 and len(declared - new) == 592
assert re.search(r'Ran 624 tests in [\d.]+s\n\nOK\s*$', log)
assert json.loads((A / 'validation/python-full-1.json').read_bytes())['exit'] == 0
parent_log = (A / 'validation/python-parent-1.log').read_text()
assert re.search(r'Ran 592 tests in [\d.]+s\n\nOK\s*$', parent_log)
record = dict(status='pass', tracked_input_count=len(rows), changed_tracked_inputs=sorted(old_changed),
              groups=groups, new_corpus_files=110, new_corpus_bytes=266666,
              selected_inventory_inputs=len(selected['source_sha256']), selected_changed_paths=30,
              publication_source_and_corpus_paths=140,
              python=dict(parent_actual_groups=592, candidate_actual_groups=624, added_groups=32,
                          parent_identity_scope='AST/source preservation; parent run was nonverbose.',
                          candidate_verbose_exact_declared_roster=True,
                          candidate_log_sha256=sha(log.encode()),
                          new_roster=sorted(new), complete_candidate_roster=sorted(declared)),
              runtime_scope='All tracked Rust source, adapter, manifests and lockfile remain unchanged. No new Rust build/test or performance claim.')
with (A / 'root/source-and-test-validation.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status='pass', tracked_inputs=len(rows), selected_changed=30, corpus_added=110,
                      python_groups=624, new_groups=32, groups=groups)))
