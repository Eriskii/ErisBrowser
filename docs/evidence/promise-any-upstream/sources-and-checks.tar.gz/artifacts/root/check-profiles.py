"""Read-only reconciliation of actual reports with frozen source identities."""
from collections import Counter
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    return json.loads(path.read_bytes())


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


old = []
for name in ('aggregate-error', 'existing', 'all', 'race', 'settled'):
    path = A / f'upstream-{name}-1.json'
    report = read(path)
    parent = read(A / 'replay-parent' / path.name)
    for field in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
                  'binary_sha256', 'corpus_manifest_sha256', 'counts', 'mode_cases'):
        assert report[field] == parent[field], (name, field)
    assert report['harness_preflight_passed'] and not report['regressions'] and not report['improvements']
    assert all(row['verified'] is True for row in report['harness_preflight'])
    old.append(dict(name=name, report=bind(path), cases=len(report['cases']),
                    controls=len(report['harness_preflight']), counts=report['counts'],
                    exact_full_case_and_control_arrays=True))
assert sum(row['cases'] for row in old) == 1100
assert sum(row['controls'] for row in old) == 400

report = read(A / 'upstream-any-1.json')
check = read(A / 'upstream-any-check-1.json')
for field in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
              'binary_sha256', 'corpus_manifest_sha256', 'counts', 'mode_cases'):
    assert report[field] == check[field], field
assert report['counts'] == {'passed': 172, 'unsupported': 14, 'failed': 2}
assert report['harness_preflight_passed'] and check['harness_preflight_passed']
assert not check['regressions'] and not check['improvements']
oracle = read(W / 'tools/test262-promise-any-import-oracle.json')
assert [dict(id=row['id'], case_sha256=row['case_sha256']) for row in report['cases']] == oracle['case_identities']
assert report['corpus_manifest_sha256'] == oracle['manifest_sha256']
assert report['mode_cases'] == 188 and report['source_tests'] == report['source_files'] == 94
assert report['negative_source_tests'] == 0
for row in report['cases']:
    assert row['source_sha256'] == digest((W / 'tests/upstream/test262-promise-any' / row['file']).read_bytes())

controls = read(W / 'tools/promise-any-controls-oracle.json')['records']
actual = report['harness_preflight']
assert len(actual) == len(controls) == 102
assert actual[:74] == read(A / 'upstream-existing-1.json')['harness_preflight']
by_identity = {(row['name'], row['mode']): row for row in controls}
for item, expected in zip(actual, controls):
    result = item['result']
    assert item['verified'] is True and item['name'] == expected['name'] and item['expected'] == expected['expected']
    for key in ('id', 'file', 'mode', 'case_sha256', 'source_sha256'):
        assert result[key] == expected[key], (item['name'], key)
    assert result['expected_negative'] is None
    references = []
    for identity in expected['prerequisites']:
        row = by_identity[tuple(identity)]
        references.append(dict(name=row['name'], mode=row['mode'], verified=True,
                               case_sha256=row['case_sha256'], source_sha256=row['source_sha256']))
    assert item['prerequisites'] == references
    if expected['expected'] == 'identity-exception':
        assert result['status'] == 'failed'
        assert result['observation'] == expected['mock_observation']
    if item['name'].startswith('promise-any-'):
        assert result['observation']['completion'] == expected['mock_observation']['completion']
        assert result['observation']['harness'] == ''
assert Counter(item['result']['status'] for item in actual) == dict(passed=42, failed=58, resource=2)

baseline_path = W / 'tests/conformance/test262-promise-any-current.json'
baseline = read(baseline_path)
assert baseline == dict(revision=report['revision'], corpus_manifest_sha256=report['corpus_manifest_sha256'],
                        runner_policy_sha256=report['runner_policy_sha256'], binary_sha256=report['binary_sha256'],
                        cases={row['id']: {key: row[key] for key in ('status', 'case_sha256', 'source_sha256')}
                               for row in report['cases']})
failed = [row for row in report['cases'] if row['status'] == 'failed']
assert all(row['file'].endswith('/returns-promise.js') and row['observation']['status'] == 'host-failure'
           and row['observation']['message'] == 'unhandled-rejection'
           and row['observation']['completion']['unhandled'] == 1 for row in failed)
unsupported = [row for row in report['cases'] if row['status'] == 'unsupported']
assert Counter('metadata' if 'reason' in row else 'parse' for row in unsupported) == dict(metadata=10, parse=4)
setup = read(A / 'root/setup.json')
for binary in setup['binaries']:
    assert digest(Path(binary['path']).read_bytes()) == binary['sha256']
assert report['binary_sha256'] == next(row['sha256'] for row in setup['binaries'] if row['path'].endswith('host-1'))
record = dict(status='pass', old_profiles=old, old_case_count=1100, old_control_count=400,
              any=dict(report=bind(A / 'upstream-any-1.json'), baseline_check=bind(A / 'upstream-any-check-1.json'),
                       baseline=bind(baseline_path), counts=report['counts'], cases=188, sources=94, controls=102,
                       controls_by_expected_result=dict(Counter(item['result']['status'] for item in actual)),
                       exact_common74=True, genuine_and_fake_raw_observations_exact=True,
                       policy=report['runner_policy'], policy_sha256=report['runner_policy_sha256'],
                       unsupported_metadata_modes=10, unsupported_untagged_class_parse_modes=4,
                       failed_source='returns-promise.js: both modes vetoed by unchanged final unhandled-rejection policy'),
              binary_inputs_unchanged=True, no_engine_rebuild=True,
              caveat='Bounded selected corpus and conservative host policy; not complete ECMAScript or browser conformance.')
with (A / 'root/profile-validation.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(status='pass', existing_cases=1100, existing_controls=400,
                      any_cases=188, any_controls=102, counts=report['counts'])))
