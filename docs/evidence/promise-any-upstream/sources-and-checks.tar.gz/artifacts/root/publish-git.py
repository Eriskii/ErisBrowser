import json
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE = '90c653d813feb62d1d569864bec076c0cc92d8a5'
publication = P / 'publication'
publication.mkdir(exist_ok=True)
record_path = P / 'root/github-publication.json'
assert not record_path.exists()
verified = json.loads((P / 'root/publication-verification.json').read_bytes())
assert verified['status'] == 'verified' and verified['path_count'] == 149

def git(directory, *args):
    result = subprocess.run(['git', *args], cwd=directory, text=True,
                            capture_output=True, check=True)
    return result.stdout.strip()

assert git(MAIN, 'branch', '--show-current') == 'main'
assert git(MAIN, 'rev-parse', 'HEAD') == git(W, 'rev-parse', 'HEAD') == BASE
assert git(MAIN, 'status', '--porcelain') == ''
assert git(W, 'diff', '--cached', '--name-only') == ''
paths = verified['expected_commit_paths']
pathspec = publication / 'paths.nul'
pathspec.write_bytes(b'\0'.join(name.encode() for name in paths) + b'\0')
git(W, 'add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul')
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
# Authenticated upstream bytes are preserved verbatim, including whitespace.
# Every allowed corpus path is already bound to the frozen oracle and archive.
assert sum(name.startswith('tests/upstream/test262-promise-any/') for name in paths) == 110
git(W, 'diff', '--cached', '--check', '--', '.', ':(exclude)tests/upstream/test262-promise-any')
upstream_whitespace = subprocess.run(
    ['git', 'diff', '--cached', '--check', '--', 'tests/upstream/test262-promise-any'],
    cwd=W, text=True, capture_output=True)
assert upstream_whitespace.returncode in (0, 2)
(publication / 'upstream-whitespace.log').write_text(upstream_whitespace.stdout + upstream_whitespace.stderr)

message = publication / 'commit-message.txt'
message.write_text('Add complete pinned Promise.any conformance profile\n\n'
                   'Authenticate all 94 upstream sources and six helpers. Require ERJR3\n'
                   'completion evidence and profile-local intrinsic AggregateError identity,\n'
                   'with canonical controls for genuine and forged error objects.\n\n'
                   'Validation: 624 Python tests, 102 controls, and 188 upstream cases\n'
                   '(172 passed, 14 unsupported, 2 conservative host-policy failures).\n'
                   'Preserve all 58 prior policies and exact 1100 cases/400 controls\n'
                   'across five replayed profiles. Rust engine and caps unchanged.\n')
commit_output = git(W, 'commit', '-F', str(message))
(publication / 'commit.log').write_text(commit_output + '\n')
commit = git(W, 'rev-parse', 'HEAD')
assert git(W, 'status', '--porcelain') == ''
assert set(git(W, 'diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines()) == set(paths)
record = dict(status='committed', base=BASE, commit=commit,
              repository='https://github.com/Eriskii/ErisBrowser', paths=len(paths))
record_path.write_text(json.dumps(record, indent=2) + '\n')
merge_output = git(MAIN, 'merge', '--ff-only', 'promise-any-upstream')
(publication / 'merge.log').write_text(merge_output + '\n')
assert git(MAIN, 'rev-parse', 'HEAD') == commit and git(MAIN, 'status', '--porcelain') == ''
push_output = git(MAIN, 'push', 'origin', 'main')
(publication / 'push.log').write_text(push_output + '\n')
remote = git(MAIN, 'ls-remote', 'origin', 'refs/heads/main').split()[0]
assert remote == commit
record.update(status='pushed', remote_head=remote, ci='not yet observed')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
