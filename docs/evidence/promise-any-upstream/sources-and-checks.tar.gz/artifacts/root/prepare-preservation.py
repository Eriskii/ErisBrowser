"""Capture actual parent policies with inert corpus/adapter; no engine execution."""
import ast
import contextlib
import hashlib
import io
import json
from pathlib import Path
import sys
import tempfile
from unittest.mock import patch

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
O = A / 'preservation-1'
O.mkdir(exist_ok=True)
sys.path.insert(0, str(W / 'tools'))
import import_test262 as importer
import test262_conformance as runner


def sha(data):
    return hashlib.sha256(data).hexdigest()


policies = {}
with tempfile.TemporaryDirectory(prefix='eris-any-parent-policy-', dir='/tmp') as temp:
    root = Path(temp)
    binary = root / 'inert-adapter'
    binary.write_bytes(b'never executed')
    output = root / 'report.json'
    for profile in sorted(importer.PROFILES):
        with contextlib.ExitStack() as stack:
            stack.enter_context(patch.object(importer, 'fetch', side_effect=AssertionError('network forbidden')))
            stack.enter_context(patch.object(runner, 'bounded_process', side_effect=AssertionError('adapter forbidden')))
            stack.enter_context(patch.object(runner, 'load_corpus', return_value=(
                dict(repository='fixture', revision='fixture', test_files=0), {}, [], [], '0' * 64)))
            stack.enter_context(patch.object(runner, 'harness_preflight', return_value=[]))
            for health in ('aggregate_error_preflight_healthy', 'promise_preflight_healthy',
                           'promise_all_preflight_healthy', 'promise_race_preflight_healthy',
                           'promise_all_settled_preflight_healthy'):
                stack.enter_context(patch.object(runner, health, return_value=True))
            call = stack.enter_context(patch.object(runner, 'run_case', side_effect=AssertionError('no cases')))
            stack.enter_context(patch('sys.argv', ['test262_conformance.py', '--profile', profile,
                                                  '--binary', str(binary), '--output', str(output)]))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            assert runner.main() == 0, profile
            call.assert_not_called()
        report = json.loads(output.read_bytes())
        assert report['mode_cases'] == 0 and report['counts'] == {}
        policies[profile] = dict(policy=report['runner_policy'], sha256=report['runner_policy_sha256'])

old = json.loads((A / 'identity-plan-1/old-policy-preservation.json').read_bytes())
assert policies == old['policies_at_timeout3']
source = (W / 'tools/test262_conformance.py').read_text()
names = {
    'encode_request', 'case_fingerprint', 'promise_completion_passes', 'promise_host_reason',
    'promise_preflight_variants', 'promise_preflight_healthy', 'promise_harness_preflight',
    'promise_all_preflight_variants', 'promise_all_preflight_healthy', 'promise_all_harness_preflight',
    'promise_race_preflight_variants', 'promise_race_preflight_healthy', 'promise_race_harness_preflight',
    'promise_all_settled_preflight_variants', 'promise_all_settled_preflight_healthy',
    'promise_all_settled_harness_preflight', 'aggregate_error_preflight_variants',
    'aggregate_error_preflight_cases', 'aggregate_error_preflight_reference',
    'aggregate_error_preflight_checks', 'aggregate_error_preflight_healthy',
    'aggregate_error_harness_preflight',
}
functions = {node.name: sha(ast.get_source_segment(source, node).encode())
             for node in ast.parse(source).body
             if isinstance(node, ast.FunctionDef) and node.name in names}
assert functions.keys() == names
oracle = dict(base='90c653d813feb62d1d569864bec076c0cc92d8a5',
              profiles=importer.PROFILES, roots=importer.PROFILE_ROOTS,
              tree_profiles=sorted(importer.TREE_PROFILES),
              features={key: sorted(value) for key, value in runner.PROFILE_FEATURES.items()},
              promise_host_profiles=sorted(runner.PROMISE_HOST_PROFILES),
              intrinsic_errors=sorted(runner.INTRINSIC_ERRORS),
              policies_at_timeout3=policies, unchanged_runner_functions=functions,
              provenance='Actual parent main policy construction, empty mocked corpus and preflight; no engine or network execution.')
with (O / 'promise-any-preservation-oracle.json').open('x') as stream:
    json.dump(oracle, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps(dict(profiles=len(policies), unchanged_functions=len(functions),
                     sha256=sha((O / 'promise-any-preservation-oracle.json').read_bytes()))))
