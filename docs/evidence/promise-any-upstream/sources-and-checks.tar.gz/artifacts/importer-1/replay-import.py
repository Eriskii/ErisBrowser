"""Root-only offline importer execution recipe; author has not executed this file."""
from pathlib import Path
import argparse
import collections
import hashlib
import importlib.util
import json

parser = argparse.ArgumentParser()
parser.add_argument('--importer', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
parser.add_argument('--receipt', type=Path, required=True)
args = parser.parse_args()
hold = Path(__file__).resolve().parent
url_map = json.loads((hold / 'fetch-url-map.json').read_text())
corpus = Path(url_map['corpus_root'])
oracle = json.loads((hold / 'raw/tools/test262-promise-any-import-oracle.json').read_text())
if args.output.exists():
    raise SystemExit('Output must not already exist')
def digest(data):
    return hashlib.sha256(data).hexdigest()
spec = importlib.util.spec_from_file_location('root_selected_importer', args.importer)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
seen = []
def offline_fetch(url):
    row = url_map['urls'][url]
    data = (corpus / row['relative_path']).read_bytes()
    if len(data) != row['bytes'] or digest(data) != row['sha256']:
        raise ValueError('retained URL payload no longer matches the hold')
    seen.append(url)
    return data
module.fetch = offline_fetch
module.import_corpus(args.output, 'promise-any')
expected = {row['path']: row for row in oracle['all_files']}
actual = {p.relative_to(args.output).as_posix() for p in args.output.rglob('*') if p.is_file()}
assert actual == set(expected)
for name, row in expected.items():
    data = (args.output / name).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256'], name
    assert data == (corpus / name).read_bytes(), name
assert collections.Counter(seen) == collections.Counter(url_map['urls'].keys())
record = dict(status='pass', profile='promise-any', files=len(actual), fetches=len(seen),
              importer=dict(path=str(args.importer), sha256=digest(args.importer.read_bytes())),
              oracle_sha256=digest((hold / 'raw/tools/test262-promise-any-import-oracle.json').read_bytes()),
              manifest_sha256=digest((args.output / 'manifest.json').read_bytes()),
              network=False, engine_execution=False, exact_all_bytes=True)
args.receipt.parent.mkdir(parents=True, exist_ok=True)
args.receipt.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
