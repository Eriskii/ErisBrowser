from pathlib import Path
import json,hashlib,difflib,subprocess,ast
U=Path('/tmp/eris-promise-any-upstream-plan-1');W=U/'worktree';H=U/'importer-1';BASE='90c653d813feb62d1d569864bec076c0cc92d8a5';rel='tools/import_test262.py'
before=(W/rel).read_text();published=subprocess.run(['git','show',BASE+':'+rel],cwd=W,check=True,capture_output=True).stdout;assert before.encode()==published
edits=[]
def add(old,new):
 global before
 assert before.count(old)==1,(old,before.count(old));edits.append({'before':old,'after':new})
add("PROMISE_ALL_DIRECTORIES = {'Promise/all': 98}","PROMISE_ANY_DIRECTORIES = {'Promise/any': 94}\nPROMISE_ANY_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js',\n                       'propertyHelper.js', 'isConstructor.js', 'promiseHelper.js'}\nPROMISE_ALL_DIRECTORIES = {'Promise/all': 98}")
for old,new in [("TREE_PROFILES = {'aggregate-error'","TREE_PROFILES = {'promise-any', 'aggregate-error'"),("PROFILES = {'aggregate-error':","PROFILES = {'promise-any': PROMISE_ANY_DIRECTORIES, 'aggregate-error':"),("PROFILE_ROOTS = {'aggregate-error':","PROFILE_ROOTS = {'promise-any': 'test/built-ins', 'aggregate-error':")]:add(old,new)
branch='''def profile_tree_inventory(profile, read=None):
    if profile == 'promise-any':
        expected = {'Promise/any': 94}
        if (PROMISE_ANY_DIRECTORIES != expected or PROFILES[profile] != expected
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.any frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            expected, 'test/built-ins', read, auxiliary_helpers=PROMISE_ANY_HELPERS)
        if any(len(listings[name]) != count for name, count in expected.items()):
            raise ValueError('Promise.any complete directory counts differ')
        # The authenticated pinned Any tree has no child directories.
        # Keep that closure explicit instead of silently selecting only direct files.
        sha = description['directory_trees']['Promise/any']
        tree = json.loads(proof[tree_proof_path('trees/' + sha)])
        if any(entry['type'] == 'tree' for entry in tree['tree']):
            raise ValueError('Promise.any incomplete descendant selection')
        return listings, proof, description
'''
add('def profile_tree_inventory(profile, read=None):\n',branch)
old="    if profile == 'aggregate-error' and harness != AGGREGATE_ERROR_HELPERS:\n"
add(old,"    if profile == 'promise-any' and harness != PROMISE_ANY_HELPERS:\n        raise ValueError('Promise.any requested harness differs from the frozen six helpers')\n"+old)
add("    if profile in {'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views', 'reflect-properties', 'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:","    if profile in {'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views', 'reflect-properties', 'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:")
scope=json.loads((H/'corpus-raw/manifest.json').read_text())['scope'];old="    scope = {\n        'aggregate-error':"
add(old,"    scope = {\n        'promise-any': "+repr(scope)+",\n        'aggregate-error':")
raw=before
for e in edits:assert raw.count(e['before'])==1;raw=raw.replace(e['before'],e['after'],1)
back=raw
for e in reversed(edits):assert back.count(e['after'])==1;back=back.replace(e['after'],e['before'],1)
assert back==before;ast.parse(raw)
for root,text in [('before',before),('raw',raw)]:
 p=H/root/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
p=H/'diffs'/f'{rel}.patch';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(H/'edits.json').write_text(json.dumps({'base':BASE,'path':rel,'sites':edits,'exact_inverse':True},indent=2)+'\n')
for rel in ['tools/test_import_test262_promise_any.py','tools/test262-promise-any-import-oracle.json']:
 p=H/'diffs'/f'{rel}.patch';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(''.join(difflib.unified_diff([], (H/'raw'/rel).read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+rel)))
print('8 additive importer sites, exact inverse and AST parsed; two new test/oracle paths')
