from pathlib import Path
import json,hashlib,ast,subprocess,difflib
U=Path('/tmp/eris-promise-any-upstream-plan-1');W=U/'worktree';H=U/'importer-1';BASE='90c653d813feb62d1d569864bec076c0cc92d8a5'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def save(name,x):(H/name).write_text(json.dumps(x,indent=2)+'\n')
parent=json.loads((U/'source-parent.json').read_text());assert parent['base']==BASE
old=W/'tests/upstream/test262-promise-all-settled';manifest=json.loads((old/'manifest.json').read_text())
source_paths=['tools/import_test262.py','tools/test262_conformance.py','tools/test_import_test262_aggregate_error.py','tests/upstream/test262-promise-all-settled/manifest.json']
source_paths += ['tests/upstream/test262-promise-all-settled/'+r['path'] for r in manifest['inventory_proof']['files'] if 'bb56695b0f924495618e34495079f998fe83581a' not in r['path']]
source_paths += ['tests/upstream/test262-promise-all-settled/'+r['path'] for r in manifest['files'] if not r['path'].startswith('test/')]
sources=[]
for rel in source_paths:
 b=(W/rel).read_bytes();g=subprocess.run(['git','show',BASE+':'+rel],cwd=W,check=True,capture_output=True).stdout;assert b==g;assert parent['source_sha256'][rel]==hashlib.sha256(b).hexdigest();sources.append(dict(relative_path=rel,**bind(W/rel),published_base_exact=BASE))
save('source-bindings.json',dict(base=BASE,parent=bind(U/'source-parent.json'),setup=bind(U/'root/setup.json'),sources=sources,authenticated_fetch=[bind(U/p) for p in ['fetch-1/receipt.json','root/any-tree-authentication.json','root/any-tree-response.json','root/source-census-1.json']]))
test=H/'raw/tools/test_import_test262_promise_any.py';t=ast.parse(test.read_text());groups=[n.name for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(groups)==6
rows=[]
for name in groups:
 passed='metadata_identities' in name
 rows.append(dict(name='PromiseAnyImporterTests.'+name,parent_expected='pass' if passed else 'error',first_parent_boundary='Existing metadata parser, retained bytes and source-derived188 identities only' if passed else 'First selected-profile constant/table access; no later corruption, replay, or preservation assertions observed on parent',parent_api_import_eligible=True))
save('test-roster.json',dict(groups=6,expected_parent_pass=1,expected_parent_error_groups=5,expected_parent_total_errors=5,preconditions='Root imports exact110-file corpus and both new test/oracle paths; importer remains published parent for red run.',rows=rows,expected_candidate='All six groups are intended to pass once independently reviewed importer capability is imported; no execution/outcome claimed.',limitations=['The descendant postcondition test patches only the shared walker return after separately authenticating real proofs; it does not claim the synthetic child has a pinned-root proof.','Metadata identities are prospective load-corpus fingerprints from source/helper bytes, not engine outcomes.']))
save('plan.json',dict(base=BASE,profile='promise-any',owned_paths=['tools/import_test262.py','tools/test_import_test262_promise_any.py','tools/test262-promise-any-import-oracle.json'],importer_sites=8,census=bind(H/'census.json'),corpus=bind(H/'corpus-raw/manifest.json'),oracle=bind(H/'raw/tools/test262-promise-any-import-oracle.json'),fetch_map=bind(H/'fetch-url-map.json'),proof_scope='Pinned commit/root -> test -> built-ins -> Promise -> any, plus root-linked harness. Six inherited proof documents + new Any leaf; every binary Git tree reconstructed independently. No descendants exist in selected leaf.',helper_closure='assert/sta baseline; doneprintHandle for65 async; isConstructor, promiseHelper and propertyHelper declared. Helpers use existing Test262Error/assert and language intrinsics; no additional include file.',preservation='Exactly eight additive source sites; inverse returns published importer bytes. Old profile tables excluding promise-any retain frozen SHA256 values; all shared fetch/auth/parser/writer bodies and old profile branches remain unchanged.',execution_recipe={'status':'Authored but not executed by peer','command':['python3',str(H/'replay-import.py'),'--importer',str(W/'tools/import_test262.py'),'--output',str(U/'root/importer-offline-output-1'),'--receipt',str(U/'root/importer-offline-replay-1.json')],'when':'Root imports reviewed importer then runs this offline recipe; output must not already exist. It compares all110 files and all109 exact fetch URL payloads. No fallback network route.'},feature_selection='Root selected the eight census recommendation tags; importer retains all original class/destructuring-tagged bodies and changes no runner policy.',not_performed=['No project module import or test/compiler/engine execution by author','No fetch/network operation','No live source write','No frozen prior checkpoint mutation']))
paths=['tools/import_test262.py','tools/test_import_test262_promise_any.py','tools/test262-promise-any-import-oracle.json'];payload=[]
for rel in paths:
 raw=H/'raw'/rel;before=H/'before'/rel;diff=H/'diffs'/f'{rel}.patch';b=before.read_text() if before.exists() else '';a=raw.read_text();expected=''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+rel if before.exists() else '/dev/null',tofile='b/'+rel));assert diff.read_text()==expected
 if raw.suffix=='.py':ast.parse(a)
 if not before.exists():assert subprocess.run(['git','cat-file','-e',BASE+':'+rel],cwd=W,capture_output=True).returncode!=0
 payload.append(dict(relative_path=rel,before=bind(before) if before.exists() else None,raw=bind(raw),diff=bind(diff)))
edits=json.loads((H/'edits.json').read_text());a=(H/'raw/tools/import_test262.py').read_text()
for e in reversed(edits['sites']):assert a.count(e['after'])==1;a=a.replace(e['after'],e['before'],1)
assert a==(H/'before/tools/import_test262.py').read_text();assert len(edits['sites'])==8
for p in [H/'derive-corpus.py',H/'author-payload.py',H/'replay-import.py',H/'seal.py']:ast.parse(p.read_text())
save('checks.json',dict(status='source_checks_clear',exact_importer_inverse=True,additive_sites=8,new_test_groups=6,parsed_not_executed=['importer candidate','new tests','root-only offline recipe'],source_base_joins=len(sources),corpus_files=110,source_modes=188,proofs=7,fetch_urls=109,source_metadata_matches_root_census=True,old_profiles_preservation_count=58))
members=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
save('source-ready.json',dict(status='sealed external importer/corpus/test hold; no project execution',base=BASE,payload=payload,source_bindings=bind(H/'source-bindings.json'),plan=bind(H/'plan.json'),roster=bind(H/'test-roster.json'),oracle=bind(H/'raw/tools/test262-promise-any-import-oracle.json'),corpus_manifest=bind(H/'corpus-raw/manifest.json'),fetch_url_map=bind(H/'fetch-url-map.json'),checks=bind(H/'checks.json'),members=members))
print(json.dumps(bind(H/'source-ready.json')))
