from pathlib import Path
import json,hashlib,re,textwrap,collections,ast,subprocess
U=Path('/tmp/eris-promise-any-upstream-plan-1');W=U/'worktree';H=U/'importer-1';D=H/'corpus-raw';BASE='90c653d813feb62d1d569864bec076c0cc92d8a5';REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd';ROOT='91b2052adad1f066ae031e2ff3a1e9bd6d732886';ANY='e2352be158fb0c0625d1ab642330faabc62a2df8'
HELPERS={'assert.js','sta.js','doneprintHandle.js','isConstructor.js','promiseHelper.js','propertyHelper.js'}
SCOPE='all 94 original .js files in the complete Promise/any subtree; root-linked nonrecursive Git proofs and unchanged six-helper closure; all original feature metadata retained; no execution or conformance claim'
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def put(rel,data):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
def git_blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree_doc(data):
 x=json.loads(data);assert x['truncated'] is False;assert len({r['path'] for r in x['tree']})==len(x['tree']);parts=[]
 for r in x['tree']:
  name=r['path'].encode();parts.append((name+(b'/' if r['type']=='tree' else b''),r['mode'].lstrip('0').encode()+b' '+name+b'\0'+bytes.fromhex(r['sha'])))
 b=b''.join(v for _,v in sorted(parts));assert hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()==x['sha'];return {r['path']:r for r in x['tree']}
old=W/'tests/upstream/test262-promise-all-settled';m=json.loads((old/'manifest.json').read_text());proof={}
for row in m['inventory_proof']['files']:
 if 'bb56695b0f924495618e34495079f998fe83581a' in row['path']:continue
 b=(old/row['path']).read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256'];proof[row['path']]=b
proof[f'inventory-proof/tree-{ANY}.json']=(U/'root/any-tree-response.json').read_bytes()
trees={json.loads(b)['sha']:tree_doc(b) for p,b in proof.items() if '/tree-' in p};commit=json.loads(proof['inventory-proof/commit.json']);assert commit['sha']==REV and commit['tree']['sha']==ROOT
sha=ROOT
for part in ['test','built-ins','Promise','any']:sha=trees[sha][part]['sha']
assert sha==ANY;leaf=trees[ANY];assert len(leaf)==94 and all(r['type']=='blob' and r['mode']=='100644' and name.endswith('.js') for name,r in leaf.items())
harness=trees[trees[ROOT]['harness']['sha']];aux={f'harness/{name}':harness[name]['sha'] for name in sorted(HELPERS)};aux.update({name:trees[ROOT][name]['sha'] for name in ['LICENSE','INTERPRETING.md']})
sources={};urlmap={};metadata={};census=json.loads((U/'root/source-census-1.json').read_text());rootrows={r['name']:r for r in census['rows']}
for name in sorted(leaf):
 b=(U/'fetch-1/sources'/name).read_bytes();assert git_blob(b)==leaf[name]['sha'];path=f'test/built-ins/Promise/any/{name}';sources[path]=b
 # Restricted independent frontmatter extraction suffices for these pinned bodies.
 text=b.decode();assert text.count('/*---')==text.count('---*/')==1;front=textwrap.dedent(text.split('/*---')[1].split('---*/')[0]);data={}
 for field in ['flags','includes','features','locale']:
  match=re.search(r'^'+field+r':\s*\[([^\]]*)\]',front,re.M)
  if match:data[field]=[v.strip().strip('"\'') for v in match[1].split(',') if v.strip()]
  else:
   assert not re.search(r'^'+field+':',front,re.M),(name,field);data[field]=[]
 assert not re.search(r'^(negative|timeout):',front,re.M);data['negative']=None;assert data==rootrows[name]['metadata'];assert digest(b)==rootrows[name]['sha256'];metadata[path]=data
for path,expected in aux.items():
 b=(old/path).read_bytes();assert git_blob(b)==expected;sources[path]=b
assert set().union(*(set(x['includes']) for x in metadata.values()))|{'assert.js','sta.js','doneprintHandle.js'}==HELPERS
manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=REV,scope=SCOPE,directories={'Promise/any':sorted(leaf)},test_files=94,files=[])
manifest['inventory_proof']=dict(method='complete-nonrecursive-git-trees',revision=REV,root_tree=ROOT,directory_trees={'Promise/any':ANY},auxiliary_blobs=aux,files=[])
for path,b in sorted(proof.items()):
 route='commits/'+REV if path.endswith('/commit.json') else 'trees/'+Path(path).stem.removeprefix('tree-');url='https://api.github.com/repos/tc39/test262/git/'+route;put(path,b);manifest['inventory_proof']['files'].append(dict(path=path,bytes=len(b),sha256=digest(b),url=url));urlmap[url]=dict(relative_path=path,bytes=len(b),sha256=digest(b))
for path,b in sorted(sources.items()):
 put(path,b);manifest['files'].append(dict(path=path,upstream_path=path,bytes=len(b),sha256=digest(b)));urlmap['https://raw.githubusercontent.com/tc39/test262/'+REV+'/'+path]=dict(relative_path=path,bytes=len(b),sha256=digest(b))
manifest_bytes=(json.dumps(manifest,indent=2)+'\n').encode();put('manifest.json',manifest_bytes)
identities=[]
for path,meta in metadata.items():
 names=['assert.js','sta.js']+(['doneprintHandle.js'] if 'async' in meta['flags'] else [])+meta['includes'];h=[dict(name=k,sha256=digest(sources['harness/'+k])) for k in dict.fromkeys(names)]
 for mode in ['sloppy','strict']:
  identity=dict(source_sha256=digest(sources[path]),mode=mode,metadata=meta,harness=h,completion_policy=int('async' in meta['flags']));identities.append(dict(id=path+':'+mode,case_sha256=digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())))
# Source-data-only AST evaluation of the three existing profile tables.
env={}
def val(x):
 if isinstance(x,ast.Name):return env[x.id]
 if isinstance(x,ast.Dict):return {val(k):val(v) for k,v in zip(x.keys,x.values)}
 if isinstance(x,(ast.List,ast.Tuple,ast.Set)):
  a=[val(v) for v in x.elts];return set(a) if isinstance(x,ast.Set) else a
 return ast.literal_eval(x)
source=(W/'tools/import_test262.py').read_text()
for n in ast.parse(source).body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:env[n.targets[0].id]=val(n.value)
  except (ValueError,KeyError,TypeError):pass
oldtables={k:(sorted(env[k]) if isinstance(env[k],set) else env[k]) for k in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES']};oldhash={k:digest(json.dumps(v,sort_keys=True).encode()) for k,v in oldtables.items()}
allfiles=[dict(path=p.relative_to(D).as_posix(),bytes=p.stat().st_size,sha256=digest(p.read_bytes())) for p in sorted(D.rglob('*')) if p.is_file()];assert len(allfiles)==110
oracle=dict(schema=1,scope='Frozen source-derived Promise.any import/corpus oracle; no project execution or outcomes',expected_manifest=manifest,manifest_sha256=digest(manifest_bytes),all_files=allfiles,metadata=metadata,case_identities=identities,old_tables_sha256=oldhash,old_profile_count=len(env['PROFILES']))
raw=H/'raw/tools';raw.mkdir(parents=True,exist_ok=True);(raw/'test262-promise-any-import-oracle.json').write_text(json.dumps(oracle,indent=2)+'\n');(H/'fetch-url-map.json').write_text(json.dumps(dict(corpus_root=str(D),urls=urlmap),indent=2)+'\n')
counts=dict(source_files=94,source_bytes=sum(len(b) for p,b in sources.items() if p.startswith('test/')),mode_cases=188,async_sources=sum('async' in v['flags'] for v in metadata.values()),sync_sources=sum('async' not in v['flags'] for v in metadata.values()),helpers=sorted(HELPERS),helper_legal_source_files=102,proof_documents=7,total_files=110,total_bytes=sum(x['bytes'] for x in allfiles),features=dict(sorted(collections.Counter(k for v in metadata.values() for k in v['features']).items())),flags=dict(sorted(collections.Counter(k for v in metadata.values() for k in v['flags']).items())),declared_includes=dict(sorted(collections.Counter(k for v in metadata.values() for k in v['includes']).items())),supported_feature_recommendation=['AggregateError','Promise.any','Reflect.construct','Symbol','Symbol.iterator','Symbol.species','arrow-function','computed-property-names'],metadata_refusal_tags=['class','destructuring-binding'])
(H/'census.json').write_text(json.dumps(counts,indent=2)+'\n');print(json.dumps({'census':counts,'oracle':bind(raw/'test262-promise-any-import-oracle.json')}))
