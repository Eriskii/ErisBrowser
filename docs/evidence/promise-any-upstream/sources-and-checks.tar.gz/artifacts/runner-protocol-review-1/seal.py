from pathlib import Path
import json,hashlib,ast,difflib,subprocess
U=Path('/tmp/eris-promise-any-upstream-plan-1');O=U/'runner-protocol-review-1';P=U/'runner-1'
def read(p):return json.loads(Path(p).read_text())
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def check(x):
 if isinstance(x,dict):
  if {'path','sha256'}<=x.keys():
   actual=bind(x['path']);assert actual['sha256']==x['sha256']
   if 'bytes' in x:assert actual['bytes']==x['bytes']
  for v in x.values():check(v)
 elif isinstance(x,list):
  for v in x:check(v)
h1=read(P/'protocol-tests-1/source-ready.json');h2=read(P/'protocol-tests-2/source-ready.json');check(h1);check(h2)
assert bind(P/'protocol-tests-1/source-ready.json')['sha256']=='f3a46d63285c89ba4b3fad905a5449e74ad574faff34a96b40d690338b9274eb'
assert bind(P/'protocol-tests-2/source-ready.json')['sha256']=='c1b310e918b4efe0e5886eae8a95a166ff3b072ecf104d44b2b1650b4534b4c2'
b=Path(h1['raw']['path']).read_text();assert b==Path(h2['before']['path']).read_text();a=Path(h2['raw']['path']).read_text();ast.parse(b);tree=ast.parse(a)
assert ''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+h2['relative'],tofile='b/'+h2['relative']))==Path(h2['diff']['path']).read_text()
start=a.index('            # Selected context alone');end=a.index('        for reason, completion in [',start);assert a[:start]+a[end:]==b
names=[n.name for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert names==h2['groups']==read(h1['roster']['path'])['groups'];assert len(names)==9
base=h1['base'];blob=subprocess.run(['git','show',base+':tools/test262_conformance.py'],cwd=U/'worktree',check=True,capture_output=True).stdout;assert hashlib.sha256(blob).hexdigest()==h1['parent_runner']['sha256'];assert subprocess.run(['git','cat-file','-e',base+':'+h1['relative']],cwd=U/'worktree',capture_output=True).returncode!=0
selection=read(h1['root_selection']['path']);constants={}
for n in tree.body:
 if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name):
  try:constants[n.targets[0].id]=ast.literal_eval(n.value)
  except ValueError:pass
assert constants['FEATURES']==set(selection['features']);assert constants['PROFILE']==selection['profile'];assert set(constants['OLD_HOST'])=={'promise-methods-async','promise-all','promise-race','promise-all-settled'}
review=dict(status='clear',review_kind='Independent source-only peer of selected Promise.any protocol tests',base=base,initial_hold=bind(P/'protocol-tests-1/source-ready.json'),selected_hold=bind(P/'protocol-tests-2/source-ready.json'),selected_raw=h2['raw'],parent_runner=h1['parent_runner'],root_selection=h1['root_selection'],identity_contract=h1['identity_plan'],identity_contract_peer=h1['identity_peer'],groups=names,checks={'all_hold_hashes':True,'new_path_absent_on_parent':True,'parent_runner_published_git_exact':True,'parent_import_eligible':True,'new_profile_calls_only_inside_tests':True,'ast_parsed_not_executed':True,'selected_eight_feature_literals_exact':True,'hold2_exact_addition_only':True,'all_prior_test_expectations_retained':True},coverage=['Any eight-name capability and immutable old seven-name constant; ordinary AggregateError capability remains separate.','Genuine/renamed/fake/unknown raw identities; ordinary ERJR2 and legacy host isolation; selected ERJR3 framing/truncation/UTF8/size/trailer boolean refusals.','Completion schema/types/ranges/contradictions, abrupt and parse evidence, matching policy, host veto and resource classification.','Eight-seam context propagation with legacy positional delegation preserved; run_case request/response routing uses mocked bounded_process only.','Negative/raw/module and class/destructuring refusal before adapter dispatch.','Hold2 makes selected classification authoritative even without case policy or completion evidence; direct ordinary positive/negative fallback is refused while legacy ordinary negative classification remains exact.'],scope_limits=['This is a test source peer, not proof that production implements the contract or that any test passes.','Synthetic raw identity acceptance tests trust the adapter observation and do not themselves prove real engine branding. Separate frozen genuine/fake literals supply that boundary.','Canonical52/102-style control identity, prerequisite and health-gate checks are separately owned; this protocol module does not duplicate them.','The initial hold did not test both markers absent; root identified that gap before execution and hold2 adds seven direct assertions within the existing classification group, without changing old expectations.','Parent imports use existing module APIs; absent capability/signature failures occur during tests. Exact observed parent counts remain root-owned.'],findings=[],execution='Read-only published source/Git, AST/text/hash checks only; no project imports, tests, adapter/compiler execution, network, live edit or frozen hold mutation.',review_script=bind(O/'seal.py'))
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(O/'review.json')))
