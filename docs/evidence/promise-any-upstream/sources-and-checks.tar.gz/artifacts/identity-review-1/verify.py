from pathlib import Path
import json,hashlib,ast,subprocess
U=Path('/tmp/eris-promise-any-upstream-plan-1');P=U/'identity-plan-1';O=U/'identity-review-1';N=Path('/tmp/eris-promise-any-runtime-plan-1')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):
 p=Path(p);return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
def check(x):
 if isinstance(x,dict):
  if {'path','sha256'}<=x.keys():
   p=Path(x['path']);assert sha(p)==x['sha256'],p
   if 'bytes' in x:assert p.stat().st_size==x['bytes'],p
  for v in x.values():check(v)
 elif isinstance(x,list):
  for v in x:check(v)
hold=read(P/'source-ready.json');assert sha(P/'source-ready.json')=='e606ed12026243e68d3822614703171165c213da02fb9981d27b97fa11fca3ea';check(hold)
b=read(P/'source-bindings.json');check(b);selected=read(N/'source-final-2.json')['source_sha256']
for row in b['sources']:
 assert selected[row['relative']]==row['sha256']
 if 'published_base_exact' in row:
  blob=subprocess.run(['git','show',f"{row['published_base_exact']}:{row['relative']}"],cwd=N/'worktree',check=True,capture_output=True).stdout
  assert hashlib.sha256(blob).hexdigest()==row['sha256']
s=(N/'worktree/tools/test262_conformance.py').read_text();tree=ast.parse(s);nodes={n.name:n for n in tree.body if isinstance(n,ast.FunctionDef)}
for row in b['functions']:
 node=nodes[row['name']];assert (node.lineno,node.end_lineno)==(row['line'],row['end_line'])
 text=''.join(s.splitlines(keepends=True)[node.lineno-1:node.end_lineno]);assert len(text.encode())==row['bytes'];assert hashlib.sha256(text.encode()).hexdigest()==row['sha256'];assert ast.unparse(node.args)==row['signature']
api=read(P/'api-propagation.json')['api'];assert {r['name'] for r in api}=={'profile_intrinsic_errors','decode_response','decode_promise_response','validate_promise_observation','classify_promise','classify','run_case','promise_preflight_verified'}
policies=read(P/'old-policy-preservation.json');check(policies);old=read(N/'worktree/tools/aggregate-error-preservation-oracle.json')['old_contract']['policies_at_timeout3'];new=policies['policies_at_timeout3'];assert len(old)==57 and len(new)==58
assert {k:v for k,v in new.items() if k!='aggregate-error'}==old
aggregate=read(N/'upstream-aggregate-error-1.json');assert new['aggregate-error']=={'policy':aggregate['runner_policy'],'sha256':aggregate['runner_policy_sha256']}
for name,row in new.items():assert hashlib.sha256(json.dumps(row['policy'],sort_keys=True).encode()).hexdigest()==row['sha256'],name
plan=read(P/'plan.json');check(plan);fetch=read(U/'fetch-1/receipt.json');census=read(U/'root/source-census-1.json');fm={r['name']:r for r in fetch['sources']};cm={r['name']:r for r in census['rows']};assert set(fm)==set(cm) and len(fm)==94
for name,row in fm.items():
 data=(U/'fetch-1/sources'/name).read_bytes();assert len(data)==row['bytes'];assert hashlib.sha256(data).hexdigest()==row['sha256']==cm[name]['sha256'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_sha1'];assert cm[name]['metadata']['negative'] is None
matrix=read(P/'raw-control-matrix.json');assert len(matrix['matrix'])==18;assert len({r['id'] for r in matrix['matrix']})==18
fixture=matrix['genuine_checked_sync_fixture'];assert fixture['error_identity']=='AggregateError';assert fixture['completion']==dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=256,quiescent=True,audited=True,unhandled=0)
out={'status':'clear','hold':bind(P/'source-ready.json'),'prior_readiness':bind(U/'readiness-1/source-ready.json'),'source_bindings':bind(P/'source-bindings.json'),'source_rows':len(b['sources']),'source_functions':len(b['functions']),'api_seams':len(api),'old_policy_objects':len(new),'old_policy_reconstruction_exact':True,'raw_matrix_families':18,'fetch_hashes_joined':94,'all_fetched_negative_metadata_absent':True,'scope':'Read-only source/Git/AST/hash/data review; no project import or execution. This is a proposal peer, not a new capability implementation, control literal freeze, health observation, runtime result or complete corpus audit.'}
(O/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(bind(O/'checks.json')))
