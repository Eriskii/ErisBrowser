"""Inert independent JSON/source reconciliation; never imports project code."""
from pathlib import Path
import json, hashlib, collections
A=Path(__file__).resolve().parents[1];W=A/'worktree';D=Path(__file__).parent;N=Path('/tmp/eris-promise-any-runtime-plan-1')
def read(p):return json.loads(p.read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def jsonsha(obj):return sha(json.dumps(obj,sort_keys=True,ensure_ascii=True).encode())
reports={n:read(A/f'upstream-{n}-1.json') for n in ['existing','all','race','settled','aggregate-error','any']}
old=[]
for n in ['existing','all','race','settled','aggregate-error']:
 q=A/f'upstream-{n}-1.json';r=reports[n];par=A/'replay-parent'/q.name;original=N/q.name
 assert par.read_bytes()==original.read_bytes()
 parent=read(par)
 for k in ['cases','harness_preflight','runner_policy','runner_policy_sha256','binary_sha256','corpus_manifest_sha256','counts','mode_cases','revision','source_files','source_tests','negative_source_tests','fixture_files']:assert r[k]==parent[k],(n,k)
 assert r['counts']==dict(collections.Counter(x['status'] for x in r['cases']))
 assert len({x['id'] for x in r['cases']})==len(r['cases'])
 assert r['harness_preflight_passed'] is True and all(x['verified'] is True for x in r['harness_preflight'])
 assert r['runner_policy_sha256']==jsonsha(r['runner_policy']) and not r['regressions'] and not r['improvements']
 old.append(dict(profile=n,report=bind(q),parent_copy=bind(par),original_report=bind(original),cases=len(r['cases']),controls=len(r['harness_preflight']),exact_full_arrays=True,policy_sha256=r['runner_policy_sha256']))
assert sum(x['cases'] for x in old)==1100 and sum(x['controls'] for x in old)==400
r=reports['any'];check=read(A/'upstream-any-check-1.json');diffs=[k for k in r if r[k]!=check[k]];assert diffs==['seconds'],diffs
assert r['runner_policy_sha256']==jsonsha(r['runner_policy'])=='49eb48da6d22d28eb01f3129bef7d44e3af2dfb2dbfe56716ef54d49f7b9e705'
selected=['AggregateError','Promise.any','Reflect.construct','Symbol','Symbol.iterator','Symbol.species','arrow-function','computed-property-names']
assert r['runner_policy']['supported_features']==selected
assert r['runner_policy']['negative_intrinsic_errors']==['AggregateError','Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError']
assert r['runner_policy']['unhandled_rejection_policy']=='final-quiescent-veto'
assert r['source_files']==r['source_tests']==94 and r['mode_cases']==188 and r['negative_source_tests']==0
C=W/'tests/upstream/test262-promise-any';o=read(A/'importer-1/raw/tools/test262-promise-any-import-oracle.json');meta=o['metadata'];assert len(meta)==94
assert r['corpus_manifest_sha256']==o['manifest_sha256']==sha((C/'manifest.json').read_bytes())
assert read(C/'manifest.json')==o['expected_manifest']
actualids=[];nonpass=[];modes=collections.Counter();passed=collections.Counter()
for row in r['cases']:
 p=row['file'];m=meta[p];b=(C/p).read_bytes();h=['assert.js','sta.js']+(['doneprintHandle.js'] if 'async' in m['flags'] else [])+m['includes']
 ident=dict(source_sha256=sha(b),mode=row['mode'],metadata=m,harness=[dict(name=n,sha256=sha((C/'harness'/n).read_bytes())) for n in h],completion_policy=int('async' in m['flags']))
 assert row['case_sha256']==jsonsha(ident) and row['source_sha256']==sha(b) and row['id']==p+':'+row['mode'] and row['expected_negative'] is None
 actualids.append(dict(id=row['id'],case_sha256=row['case_sha256']));modes[ident['completion_policy']]+=1
 if row['status']=='passed':
  obs=row['observation'];ev=obs['completion'];assert obs['status']=='complete' and obs['phase']=='runtime' and obs['harness']==obs['error_identity']==obs['error_type']==obs['message']==''
  assert ev==dict(policy=ident['completion_policy'],done_calls=ident['completion_policy'],success_prints=ident['completion_policy'],failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=0)
  passed[ident['completion_policy']]+=1
 else:
  if 'reason' in row:
   assert row['status']=='unsupported' and not set(m['features'])<=set(selected)
   missing=sorted(set(m['features'])-set(selected));assert row['reason']=='unimplemented declared features: '+', '.join(missing)
   category='declared unsupported '+','.join(missing)
  elif row['status']=='unsupported':
   obs=row['observation'];assert obs==dict(status='unsupported',phase='parse',error_type='UnsupportedFeature',error_identity='',message="'class' is not supported",harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=False,audited=False,unhandled=0))
   assert m['features']==[] and b'class BadPromise' in b
   category='untagged class parse refusal'
  else:
   assert row['status']=='failed' and p.endswith('/returns-promise.js')
   assert row['observation']==dict(status='host-failure',phase='host',error_type='',error_identity='',message='unhandled-rejection',harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1))
   assert b'var p = Promise.any([]);' in b and b'.then(' not in b and b'.catch(' not in b
   category='final quiescent unhandled rejection veto'
  nonpass.append(dict(id=row['id'],category=category,raw_result=row,metadata=m,source=bind(C/p)))
assert actualids==o['case_identities'] and len(set(x['id'] for x in actualids))==188
assert modes=={0:58,1:130};print('actual passed policy split',dict(passed))
assert dict(collections.Counter(x['status'] for x in r['cases']))==r['counts']==dict(passed=172,unsupported=14,failed=2)
co=read(A/'controls-1/raw/tools/promise-any-controls-oracle.json')['records'];actual=r['harness_preflight'];assert len(actual)==len(co)==102 and actual[:74]==reports['existing']['harness_preflight']
by={(x['name'],x['mode']):x for x in co};assert len(by)==102
for exp,got in zip(co,actual):
 assert got['name']==exp['name'] and got['expected']==exp['expected'] and got['verified'] is True
 row=got['result'];assert set(row)=={'id','file','mode','case_sha256','source_sha256','expected_negative','status','observation'}
 for k in ['id','file','mode','case_sha256','source_sha256']:assert row[k]==exp[k]
 assert row['expected_negative'] is None
 identity=dict(source_sha256=sha(exp['source'].encode()),mode=exp['mode'],metadata=exp['metadata'],harness=exp['harness'],completion_policy=exp['completion_policy'])
 assert sha(exp['source'].encode())==exp['source_sha256'] and jsonsha(identity)==exp['case_sha256']
 refs=[]
 for name,mode in exp['prerequisites']:
  target=by[name,mode];assert mode==exp['mode'];refs.append(dict(name=name,mode=mode,verified=True,case_sha256=target['case_sha256'],source_sha256=target['source_sha256']))
 assert got['prerequisites']==refs
 obs=row['observation'];assert set(obs)=={'status','phase','error_type','error_identity','message','harness','completion'}
 assert obs['completion']==exp['mock_observation']['completion']
 if exp['expected']=='identity-exception':assert obs==exp['mock_observation']
 if exp['name'].startswith('promise-any-'):
  assert obs['harness']==''
  for key in ['status','phase','error_type','error_identity']:assert obs[key]==exp['mock_observation'][key],(exp['name'],key)
 assert row['status']==('passed' if obs['status']=='complete' else obs['status'] if obs['status'] in ['unsupported','resource','harness-error'] else 'failed')
assert collections.Counter(x['result']['status'] for x in actual)==dict(passed=42,failed=58,resource=2)
assert r['harness_preflight_passed'] is True and check['harness_preflight_passed'] is True and not check['regressions'] and not check['improvements']
baseline=read(W/'tests/conformance/test262-promise-any-current.json');expected={k:r[k] for k in ['revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256']};expected['cases']={x['id']:{k:x[k] for k in ['status','case_sha256','source_sha256']} for x in r['cases']};assert baseline==expected
setup=read(A/'root/setup.json');bs=[]
for x in setup['binaries']:
 p=Path(x['path']);assert sha(p.read_bytes())==x['sha256'] and p.stat().st_size==x['bytes'];bs.append(bind(p))
for name,report in reports.items():assert report['binary_sha256']==next(x['sha256'] for x in setup['binaries'] if x['path']==report['binary'])
assert r['binary'].endswith('host-1')
assert read(A/'source-parent.json')['source_sha256']==read(N/'source-final-2.json')['source_sha256']
po=read(A/'preservation-1/promise-any-preservation-oracle.json');assert len(po['policies_at_timeout3'])==58
for name,x in po['policies_at_timeout3'].items():assert jsonsha(x['policy'])==x['sha256']
for name,prof in [('existing','promise-methods-async'),('all','promise-all'),('race','promise-race'),('settled','promise-all-settled'),('aggregate-error','aggregate-error')]:assert reports[name]['runner_policy']==po['policies_at_timeout3'][prof]['policy']
ci=read(A/'root/prior-ci-observation-2.json');assert ci['headSha']==setup['base'] and ci['conclusion']=='success' and len(ci['jobs'])==11 and all(x['conclusion']=='success' for x in ci['jobs'])
summary=dict(status='clear source-and-actual-report reconciliation',report=bind(A/'upstream-any-1.json'),repeat=bind(A/'upstream-any-check-1.json'),baseline=bind(W/'tests/conformance/test262-promise-any-current.json'),repeat_only_differing_field='seconds',any=dict(sources=94,modes=188,source_policy_modes=dict(modes),passed_policy_modes=dict(passed),counts=r['counts'],controls=102,control_statuses=dict(collections.Counter(x['result']['status'] for x in actual)),policy_sha256=r['runner_policy_sha256']),old_reports=old,old_cases=1100,old_controls=400,old_policy_hashes=58,common74_exact=True,controls_exact_fingerprints_and_prerequisites=True,baseline_exact_report_projection=True,binaries=bs,previous_binary_source_closure=bind(N/'root/release-source-closure-2.json'),prior_ci=bind(A/'root/prior-ci-observation-2.json'),nonpass=nonpass,qualifications=['All94 originals and both modes are retained. Ten metadata-unsupported modes (six class/four destructuring-binding) were excluded before adapter dispatch; four other modes reached class parser refusal.','The untagged not-callable-return source also contains0n; parser class refusal happened first and establishes no separate BigInt result.','The two failed returns-promise modes create an unhandled rejected empty Any promise. Actual host evidence is final quiescent/audited with one unhandled rejection; no failure was relabeled.','The baseline is the exact healthy record-command projection, with a separate actual baseline replay.','The current tooling checkpoint reuses the previously built ordinary/host binaries. No Rust build or full Rust suite was run here.','Prior11-job success belongs to published90c653d8. The added Any CI gate is configured, not claimed remotely executed.'])
(D/'profiles-review.json').write_text(json.dumps(summary,indent=2)+'\n');print(bind(D/'profiles-review.json'))
