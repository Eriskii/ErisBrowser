"""Documentation source and recorded-data review only; no project execution."""
from pathlib import Path
import collections
import difflib
import hashlib
import json
import re
import subprocess

U=Path('/tmp/eris-promise-any-upstream-plan-1');W=U/'worktree';D=U/'documentation-review-1'
BASE='90c653d813feb62d1d569864bec076c0cc92d8a5'
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p):return json.loads(Path(p).read_text())
def checkrefs(x):
 if isinstance(x,dict):
  if all(k in x for k in ('path','bytes','sha256')) and Path(x['path']).is_absolute():
   p=Path(x['path']);b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],str(p)
   refs.add(str(p))
  for v in x.values():checkrefs(v)
 elif isinstance(x,list):
  for v in x:checkrefs(v)
refs=set();seal=read(U/'documentation-1/source-ready.json');ledger=read(U/'root/final-validation.json')
assert sha((U/'root/final-validation.json').read_bytes())=='12895660d81445285b58e549168e433774ac3f1ad5fbb464da2cb3d3e8bfc258'
checkrefs(seal);checkrefs(ledger)
expected={'README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/promise-any.md','docs/promise-any-upstream.md'}
assert {x['path'] for x in seal['files']}==expected
for x in seal['files']:
 if x['before']:
  old=Path(x['before']['path']).read_bytes();assert subprocess.check_output(['git','-C',str(W),'show',BASE+':'+x['path']])==old
 raw=Path(x['raw']['path']).read_text()
 before=Path(x['before']['path']).read_text() if x['before'] else ''
 patch=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+x['path'] if x['before'] else '/dev/null',tofile='b/'+x['path']))
 assert patch==Path(x['diff']['path']).read_text()
 assert '[PENDING' not in raw
# Recover both historical documents exactly from their first preserved anchor.
suffix=[]
for rel,anchor in [('docs/VALIDATION.md','## Promise.any runtime'),('docs/promise-any.md','`Promise.any` consumes')]:
 b=(U/'documentation-1/before'/rel).read_text();a=(U/'documentation-1/raw'/rel).read_text()
 assert a[a.index(anchor):]==b[b.index(anchor):]
 suffix.append(dict(path=rel,anchor=anchor,bytes=len(b[b.index(anchor):].encode()),sha256=sha(b[b.index(anchor):].encode())))
report=read(U/'upstream-any-1.json');replay=read(U/'upstream-any-check-1.json')
assert len(report['cases'])==188 and report['mode_cases']==188 and report['source_tests']==94
assert collections.Counter(x['status'] for x in report['cases'])=={'passed':172,'unsupported':14,'failed':2}
assert len(report['harness_preflight'])==102 and all(x['verified'] is True for x in report['harness_preflight'])
assert collections.Counter(x['result']['status'] for x in report['harness_preflight'])=={'passed':42,'failed':58,'resource':2}
for k in ('cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','binary_sha256'):assert report[k]==replay[k]
assert report['harness_preflight_passed'] is replay['harness_preflight_passed'] is True
failed=[x for x in report['cases'] if x['status']=='failed'];assert len(failed)==2
assert {x['id'] for x in failed}=={'test/built-ins/Promise/any/returns-promise.js:'+mode for mode in ('sloppy','strict')}
assert all(x['observation']==dict(status='host-failure',phase='host',error_type='',error_identity='',message='unhandled-rejection',harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1)) for x in failed)
unsupported=[x for x in report['cases'] if x['status']=='unsupported']
parts=collections.Counter(x.get('reason','parse-class') for x in unsupported)
assert parts=={'unimplemented declared features: class':6,'unimplemented declared features: destructuring-binding':4,'parse-class':4}
assert all(x['observation']['phase']=='parse' and x['observation']['message']=="'class' is not supported" for x in unsupported if 'reason' not in x)
old=[]
for name in ('aggregate-error','existing','all','race','settled'):
 p=U/f'upstream-{name}-1.json';a=read(p);b=read(U/'replay-parent'/p.name)
 for k in ('cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','binary_sha256'):assert a[k]==b[k],(name,k)
 old.append(dict(profile=name,cases=len(a['cases']),controls=len(a['harness_preflight']),report=rec(p),parent=rec(U/'replay-parent'/p.name)))
assert sum(x['cases'] for x in old)==1100 and sum(x['controls'] for x in old)==400
assert report['harness_preflight'][:74]==read(U/'upstream-existing-1.json')['harness_preflight']
logs=[]
for name,count,exit_code in [('python-parent-1',592,0),('python-full-1',624,0),('any-focused-1',32,1),('any-focused-2',32,0)]:
 r=read(U/'validation'/f'{name}.json');p=U/'validation'/r['log'];s=p.read_text()
 assert r['exit']==exit_code and sha(p.read_bytes())==r['sha256']
 assert re.search(r'^Ran '+str(count)+r' tests in [0-9.]+s$',s,re.M)
 if exit_code==0:assert re.search(r'^OK$',s,re.M)
 else:assert 'FAILED (failures=1)' in s and 'AssertionError: True is not false' in s and "'harness'" in s
 if name=='python-full-1':assert len(re.findall(r'^test_.* \.\.\. ok$',s,re.M))==624
 logs.append(dict(name=name,receipt=rec(U/'validation'/f'{name}.json'),log=rec(p),count=count,exit=exit_code))
for binary in ledger['binaries']:
 assert rec(binary['path'])['sha256']==binary['sha256'] and Path(binary['path']).stat().st_size==binary['bytes']
assert report['binary_sha256']==next(x['sha256'] for x in ledger['binaries'] if x['metadata']['features']==['test262-host'])
assert read(U/'upstream-aggregate-error-1.json')['binary_sha256']==next(x['sha256'] for x in ledger['binaries'] if x['metadata']['features']==[])
# Source-final is a selected ledger, with Any corpus authenticated outside it.
source=read(U/'source-final.json')['source_sha256'];assert len(source)==1744
assert all(sha((W/p).read_bytes())==v for p,v in source.items())
assert ledger['source']['new_corpus_paths_separately_verified']==110
assert ledger['source']['source_and_corpus_git_paths']==140
assert 140+7+2==149
# Resolve all newly introduced local links; evidence is intentionally future publication output.
links=[];future={'evidence/promise-any-upstream/manifest.json','evidence/promise-any-upstream/sources-and-checks.tar.gz'}
for entry in seal['files']:
 rel=entry['path'];patch=Path(entry['diff']['path']).read_text()
 added='\n'.join(s[1:] for s in patch.splitlines() if s.startswith('+') and not s.startswith('+++'))
 for target in re.findall(r'\]\(([^)]+)\)',added):
  if '://' in target or target.startswith('#'):continue
  target=target.split('#')[0]
  assert (W/rel).parent.joinpath(target).exists() or (U/'documentation-1/raw'/rel).parent.joinpath(target).exists() or target in future,(rel,target)
  links.append(dict(owner=rel,target=target,publication_artifact=target in future))
chapter=(U/'documentation-1/raw/docs/promise-any-upstream.md').read_text()
assert '--profile promise-any' in chapter and '--baseline tests/conformance/test262-promise-any-current.json' in chapter
assert 'target/release/eris-js' in chapter and '--features test262-host' in chapter
assert 'No success result for this checkpoint' in chapter and 'no new Rust build or full' in chapter
checks=dict(status='clear',method='stdlib reads/hash/regex plus read-only Git; no project execution',source_ready=rec(U/'documentation-1/source-ready.json'),final_ledger=rec(U/'root/final-validation.json'),source_final=rec(U/'source-final.json'),bound_file_checks=len(refs),files=seal['files'],historical_suffixes=suffix,actual=dict(sources=94,modes=188,counts=dict(passed=172,unsupported=14,failed=2),controls=102,control_outcomes=dict(passed=42,failed=58,resource=2),unsupported_partitions=dict(declared_class=6,declared_destructuring=4,untagged_class_parse=4)),new_report=rec(U/'upstream-any-1.json'),new_replay=rec(U/'upstream-any-check-1.json'),old_replays=old,python=logs,links=links,source_scope=dict(selected1744=True,new_corpus_separate110=True,anticipated_publication_paths=149,not_complete_build_graph=True),no_new_rust_build_or_execution=True)
(D/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(rec(D/'checks.json')))
