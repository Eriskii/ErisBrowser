"""Compose frozen external source payloads and prove the selected byte inverse."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

H=Path(__file__).resolve().parent
P=H.parent
RELATIVE='tools/test262_conformance.py'
def sha(data): return hashlib.sha256(data).hexdigest()
def bind(path):
    b=path.read_bytes(); return dict(path=str(path),bytes=len(b),sha256=sha(b))
def read(path): return json.loads(path.read_text())
def put(name,value):
    path=H/name;path.parent.mkdir(parents=True,exist_ok=True)
    assert not path.exists();path.write_text(json.dumps(value,indent=2)+'\n')
def functions(source):
    lines=source.splitlines(keepends=True)
    return {n.name:(n,''.join(lines[n.lineno-1:n.end_lineno])) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
def verify_bindings(value):
    if isinstance(value,dict):
        if {'path','sha256'}<=value.keys():
            path=Path(value['path']);assert sha(path.read_bytes())==value['sha256'],str(path)
            if 'bytes' in value:assert path.stat().st_size==value['bytes']
        for x in value.values():verify_bindings(x)
    elif isinstance(value,list):
        for x in value:verify_bindings(x)

control_manifest=P/'controls-1/source-ready.json'
controls=read(control_manifest);verify_bindings(controls)
payload_path=P/'controls-1/payload/any-preflight.py'
payload=payload_path.read_text()
# Require the manifest to bind the exact payload, not merely exist beside it.
assert bind(payload_path)['sha256'] in json.dumps(controls)
before=(H/'before'/RELATIVE).read_text()
seams=(H/'seams-2-raw'/RELATIVE).read_text()
new_funcs=functions(payload)
assert set(new_funcs)=={'promise_any_preflight_variants','promise_any_preflight_cases',
    'promise_any_preflight_reference','promise_any_preflight_checks',
    'promise_any_preflight_healthy','promise_any_harness_preflight'}
assert not set(new_funcs)&set(functions(before))
marker='def check_baseline(previous, current):\n'
assert seams.count(marker)==1 and payload.endswith('\n')
insertion=payload+'\n\n'
after=seams.replace(marker,insertion+marker)
assert after.replace(insertion,'',1)==seams
old_functions=functions(before);final_functions=functions(after)
selected={x['function'] for x in read(H/'seams-ledger.json')['changed_functions']}
changed={name for name in old_functions if old_functions[name][1]!=final_functions[name][1]}
assert changed==selected and len(changed)==11
assert set(final_functions)-set(old_functions)==set(new_funcs)

# Remove new payload, restore precisely the eleven edited function spans,
# then remove only the new top-level profile definitions/membership addition.
inverse=after.replace(insertion,'',1)
spans=functions(inverse);lines=inverse.splitlines(keepends=True)
for name in sorted(selected,key=lambda n:spans[n][0].lineno,reverse=True):
    node=spans[name][0]
    lines[node.lineno-1:node.end_lineno]=old_functions[name][1].splitlines(keepends=True)
inverse=''.join(lines)
start=inverse.index("PROMISE_ANY_PROFILE = 'promise-any'\n")
end=inverse.index('PROMISE_HOST_PROFILES = ',start)
inverse=inverse[:start]+inverse[end:]
membership='PROMISE_HOST_PROFILES.add(PROMISE_ANY_PROFILE)\n'
assert inverse.count(membership)==1;inverse=inverse.replace(membership,'')
assert inverse==before

raw=H/'raw'/RELATIVE;raw.parent.mkdir(parents=True,exist_ok=True)
assert not raw.exists();raw.write_text(after)
diff=H/'diffs'/(RELATIVE+'.patch');diff.parent.mkdir(parents=True,exist_ok=True)
assert not diff.exists();diff.write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),fromfile='a/'+RELATIVE,tofile='b/'+RELATIVE)))
test_hold=H/'protocol-tests-2/source-ready.json';tests=read(test_hold);verify_bindings(tests)
test_relative=tests['relative'];test_source=Path(tests['raw']['path'])
test_raw=H/'raw'/test_relative;test_raw.parent.mkdir(parents=True,exist_ok=True)
assert not test_raw.exists();test_raw.write_bytes(test_source.read_bytes())
assert sha(test_raw.read_bytes())==tests['raw']['sha256']
test_diff=H/'diffs'/(test_relative+'.patch');test_diff.parent.mkdir(parents=True,exist_ok=True)
test_diff.write_text(''.join(difflib.unified_diff([],test_source.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+test_relative)))
ledger=dict(status='exact byte inverse',modified_existing_functions=[dict(name=name,
    before_sha256=sha(old_functions[name][1].encode()),after_sha256=sha(final_functions[name][1].encode())) for name in sorted(changed)],
    new_functions=[dict(name=name,sha256=sha(final_functions[name][1].encode())) for name in sorted(new_funcs)],
    unchanged_existing_functions=[dict(name=name,sha256=sha(old_functions[name][1].encode())) for name in sorted(set(old_functions)-changed)],
    full_parent_byte_inverse_sha256=sha(inverse.encode()),
    top_level_changes='Only standalone selected Any feature/profile declarations and its host-profile membership.',
    gate_payload=bind(payload_path),gate_bytes_exact=True,
    protocol_test_source_exact=True,no_project_execution=True)
put('changed-function-ledger.json',ledger)
put('source-ready.json',dict(status='source_ready',base='90c653d813feb62d1d569864bec076c0cc92d8a5',
    files=[dict(relative=RELATIVE,new=False,before=bind(H/'before'/RELATIVE),raw=bind(raw),diff=bind(diff)),
           dict(relative=test_relative,new=True,raw=bind(test_raw),diff=bind(test_diff))],
    parent_refresh=bind(H/'published-base-refresh.json'),root_selection=bind(P/'root/selection-1.json'),
    control_hold=bind(control_manifest),control_integration_clarification=bind(P/'controls-1/integration-clarification.json'),protocol_hold1=bind(H/'protocol-tests-1/source-ready.json'),
    selected_protocol_hold2=bind(test_hold),classification_amendment=bind(H/'classification-amendment.json'),
    changed_functions=bind(H/'changed-function-ledger.json'),
    authoring_sources=[bind(H/'author-seams.py'),bind(Path(__file__))],
    scope='New Any profile only. Exact eight selected propagation seams, loader/harness/main dispatch, frozen canonical control payload, and nine independent mocked protocol/routing groups.',
    qualifications=['The initial selected classify plan/draft could fall through ordinary handling without policy/evidence. Root found this before candidate execution; additive tests freeze missing-policy/evidence refusal and final selected dispatch occurs first. Original holds retained.',
                    'Layout owns the independent control tests/oracle and old roster migrations; those remain in their separate frozen holds.',
                    'No runtime, host adapter, wire format, caps, old policy expectations, old case fingerprints, baseline, or corpus source changes.'],
    no_project_execution=True,no_live_edits=True))
print(json.dumps(bind(H/'source-ready.json')))
