"""External textual/AST authoring only; never import or execute the runner."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

H=Path(__file__).resolve().parent
P=H.parent
W=P/'worktree'
BASE='90c653d813feb62d1d569864bec076c0cc92d8a5'
RELATIVE='tools/test262_conformance.py'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
    b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=sha(b))
def put(name,value):
    path=H/name; path.parent.mkdir(parents=True,exist_ok=True)
    assert not path.exists(); path.write_text(json.dumps(value,indent=2)+'\n')

before=(W/RELATIVE).read_bytes()
assert subprocess.check_output(['git','show',BASE+':'+RELATIVE],cwd=W)==before
inventory=json.loads((P/'source-parent.json').read_text())['source_sha256']
assert sha(before)==inventory[RELATIVE]
selection=json.loads((P/'root/selection-1.json').read_text())
features={'AggregateError','Promise.any','Reflect.construct','Symbol','Symbol.iterator',
          'Symbol.species','arrow-function','computed-property-names'}
assert set(selection['features'])==features
source=before.decode()
edits=[]
def edit_function(name,pairs):
    global source
    tree=ast.parse(source)
    node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name)
    lines=source.splitlines(keepends=True)
    start=sum(map(len,lines[:node.lineno-1]));end=sum(map(len,lines[:node.end_lineno]))
    old=source[start:end];new=old
    for a,b,count in pairs:
        assert new.count(a)==count,(name,a,new.count(a))
        new=new.replace(a,b)
    source=source[:start]+new+source[end:]
    edits.append(dict(function=name,before_sha256=sha(old.encode()),after_sha256=sha(new.encode()),
                      change='selected profile-only propagation/dispatch; all other function text retained'))

anchor="PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE, PROMISE_RACE_PROFILE, PROMISE_ALL_SETTLED_PROFILE}\n"
assert source.count(anchor)==1
definitions="""PROMISE_ANY_PROFILE = 'promise-any'
PROMISE_ANY_FEATURES = {'AggregateError', 'Promise.any', 'Reflect.construct', 'Symbol',
                        'Symbol.iterator', 'Symbol.species', 'arrow-function',
                        'computed-property-names'}
PROFILE_FEATURES[PROMISE_ANY_PROFILE] = PROMISE_ANY_FEATURES
"""
source=source.replace(anchor,definitions+anchor+'PROMISE_HOST_PROFILES.add(PROMISE_ANY_PROFILE)\n')
edit_function('profile_intrinsic_errors',[
    ('"""Ordinary AggregateError transport is an explicit profile-local capability."""','"""Additional intrinsic identities require an explicit selected profile."""',1),
    ("profile == AGGREGATE_ERROR_PROFILE else names","profile in {AGGREGATE_ERROR_PROFILE, PROMISE_ANY_PROFILE} else names",1),
])
edit_function('load_corpus',[("{'aggregate-error', 'promise-all-settled'","{'promise-any', 'aggregate-error', 'promise-all-settled'",2)])
edit_function('decode_response',[
    ("    if output.startswith(b'ERJR3'):\n        return decode_promise_response(output)",
     "    if profile == PROMISE_ANY_PROFILE and not output.startswith(b'ERJR3'):\n        raise ValueError('Promise.any profile requires an ERJR3 response')\n    if output.startswith(b'ERJR3'):\n        if profile == PROMISE_ANY_PROFILE:\n            return decode_promise_response(output, profile=profile)\n        return decode_promise_response(output)",1),
])
edit_function('classify',[
    ('def classify(case, observation):','def classify(case, observation, *, profile=None):',1),
    ("    if 'completion_policy' in case or 'completion' in observation:\n        return classify_promise(case, observation)",
     "    if 'completion_policy' in case or 'completion' in observation:\n        if profile == PROMISE_ANY_PROFILE:\n            return classify_promise(case, observation, profile=profile)\n        return classify_promise(case, observation)",1),
])
edit_function('run_case',[
    ("if profile == AGGREGATE_ERROR_PROFILE else decode_response(output)",
     "if profile in {AGGREGATE_ERROR_PROFILE, PROMISE_ANY_PROFILE} else decode_response(output)",1),
    ('        return dict(result, status=classify(case, observation), observation=observation)',
     '        status = (classify(case, observation, profile=profile)\n                  if profile == PROMISE_ANY_PROFILE else classify(case, observation))\n        return dict(result, status=status, observation=observation)',1),
])
edit_function('harness_preflight',[
    ('    if profile == AGGREGATE_ERROR_PROFILE:',
     '    if profile == PROMISE_ANY_PROFILE:\n        return promise_any_harness_preflight(files, binary, timeout)\n    if profile == AGGREGATE_ERROR_PROFILE:',1),
])
edit_function('validate_promise_observation',[
    ('def validate_promise_observation(fields):','def validate_promise_observation(fields, *, profile=None):',1),
    ("    if fields['error_identity'] and fields['error_identity'] not in INTRINSIC_ERRORS:",
     "    identities = profile_intrinsic_errors(profile if profile == PROMISE_ANY_PROFILE else None)\n    if fields['error_identity'] and fields['error_identity'] not in identities:",1),
])
edit_function('decode_promise_response',[
    ('def decode_promise_response(output):\n    offset = 5',
     "def decode_promise_response(output, *, profile=None):\n    if profile == PROMISE_ANY_PROFILE and not output.startswith(b'ERJR3'):\n        raise ValueError('Promise.any profile requires an ERJR3 response')\n    offset = 5",1),
    ('    validate_promise_observation(fields)\n    return fields',
     '    if profile == PROMISE_ANY_PROFILE:\n        validate_promise_observation(fields, profile=profile)\n    else:\n        validate_promise_observation(fields)\n    return fields',1),
])
for name,signature in [('classify_promise','case, observation'),('promise_preflight_verified','case, result, expected')]:
    edit_function(name,[
        (f'def {name}({signature}):',f'def {name}({signature}, *, profile=None):',1),
        ('        validate_promise_observation(observation)',
         '        if profile == PROMISE_ANY_PROFILE:\n            validate_promise_observation(observation, profile=profile)\n        else:\n            validate_promise_observation(observation)',1),
    ])
edit_function('main',[
    ('        preflight_ok = (aggregate_error_preflight_healthy(preflight, files) if args.profile == AGGREGATE_ERROR_PROFILE',
     '        preflight_ok = (promise_any_preflight_healthy(preflight, files) if args.profile == PROMISE_ANY_PROFILE\n                        else aggregate_error_preflight_healthy(preflight, files) if args.profile == AGGREGATE_ERROR_PROFILE',1),
])

def functions(text):
    lines=text.splitlines(keepends=True)
    return {n.name:''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(text).body if isinstance(n,ast.FunctionDef)}
old_funcs=functions(before.decode());new_funcs=functions(source)
changed=sorted(k for k in old_funcs if old_funcs[k]!=new_funcs[k])
assert changed==sorted(x['function'] for x in edits) and len(changed)==11
assert old_funcs.keys()==new_funcs.keys()
assert ast.literal_eval(next(n for n in ast.parse(source).body if isinstance(n,ast.Assign) and
    any(isinstance(t,ast.Name) and t.id=='PROMISE_ANY_FEATURES' for t in n.targets)).value)==features
for directory,data in [('before',before),('seams-raw',source.encode())]:
    path=H/directory/RELATIVE;path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists();path.write_bytes(data)
diff=H/'seams.patch';assert not diff.exists()
diff.write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),source.splitlines(keepends=True),fromfile='a/'+RELATIVE,tofile='b/'+RELATIVE)))
put('seams-ledger.json',dict(status='unsealed integration draft; selected seams complete, Layout gate payload pending',
    base=BASE,before=bind(H/'before'/RELATIVE),raw=bind(H/'seams-raw'/RELATIVE),diff=bind(diff),
    changed_functions=edits,unchanged_function_count=len(old_funcs)-len(changed),
    top_level_changes='Only standalone selected Any profile/features mapping and its addition to host profile membership.',
    pending='Frozen Layout gate payload plus independent source peer; no runner source-ready claim yet.'))
prior=json.loads((P/'identity-plan-1/source-bindings.json').read_text())['sources']
refreshed=[]
for row in prior:
    path=W/row['relative'];data=path.read_bytes()
    assert sha(data)==row['sha256']
    assert subprocess.check_output(['git','show',BASE+':'+row['relative']],cwd=W)==data
    refreshed.append(dict(relative=row['relative'],**bind(path),published_base_exact=BASE))
put('published-base-refresh.json',dict(base=BASE,parent_inventory=bind(P/'source-parent.json'),
    prior_plan=bind(P/'identity-plan-1/source-ready.json'),source_joins=refreshed,
    root_selection=bind(P/'root/selection-1.json'),all_prior_content_exact=True,
    scope='Additive published-base refresh; original identity proposal is retained.'))
print(json.dumps(dict(draft=bind(H/'seams-ledger.json'),refresh=bind(H/'published-base-refresh.json'))))
