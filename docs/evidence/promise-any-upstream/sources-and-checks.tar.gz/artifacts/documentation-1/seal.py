from pathlib import Path
import hashlib,json,re
N=Path('/tmp/eris-promise-any-upstream-plan-1');D=N/'documentation-1';W=N/'worktree'
def sha(data):return hashlib.sha256(data).hexdigest()
def bind(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p.read_bytes()))
def write(name,value):(D/name).write_text(json.dumps(value,indent=2)+'\n')
ledger=N/'root/final-validation.json';assert ledger.exists(),'Final ledger required before documentation seal'
final=json.loads(ledger.read_text())
refs=[]
def check_refs(value):
 if isinstance(value,dict):
  if isinstance(value.get('path'),str) and value['path'].startswith('/') and 'sha256' in value:
   p=Path(value['path']);assert p.is_file(),p;assert sha(p.read_bytes())==value['sha256'],p
   if 'bytes' in value:assert p.stat().st_size==value['bytes'],p
   refs.append(bind(p))
  for v in value.values():check_refs(v)
 elif isinstance(value,list):
  for v in value:check_refs(v)
check_refs(final)
profile=N/'root/profile-validation.json';check_refs(json.loads(profile.read_text()))
metrics=json.loads((D/'metrics.json').read_text());assert not any('[PENDING' in str(v) for v in metrics.values())
# Independently checked complete report arrays, baseline, binary attribution and624
# verbose results are bound separately from the root summary.
observed=json.loads((D/'observations-checks-draft.json').read_text());assert observed['python']['groups']==624 and observed['total_old']==dict(cases=1100,controls=400)
assert observed['counts']==dict(passed=172,unsupported=14,failed=2)
for name in ['any-focused-2','python-full-1']:
 p=N/'validation'/f'{name}.json';j=json.loads(p.read_text());log=p.parent/j['log'];assert j['exit']==0 and sha(log.read_bytes())==j['sha256'];refs.extend([bind(p),bind(log)])
source=N/'source-final.json';s=json.loads(source.read_text());assert len(s['source_sha256'])==1744
for rel,digest in s['source_sha256'].items():assert sha((W/rel).read_bytes())==digest,rel

def apply(before,diff,reverse=False):
 src=before.splitlines(keepends=True);lines=diff.splitlines(keepends=True);out=[];pos=0;i=2
 while i<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@\n',lines[i]);assert m,lines[i]
  start=int(m.group(3 if reverse else 1));count=int(m.group(4 if reverse else 2) or 1);begin=start-1 if count else start
  out.extend(src[pos:begin]);pos=begin;i+=1
  while i<len(lines) and not lines[i].startswith('@@ '):
   code,text=lines[i][0],lines[i][1:];i+=1
   if reverse:code={'+':'-','-':'+',' ':' '}[code]
   if code==' ':assert src[pos]==text;out.append(text);pos+=1
   elif code=='-':assert src[pos]==text;pos+=1
   elif code=='+':out.append(text)
   else:raise AssertionError(code)
 out.extend(src[pos:]);return ''.join(out)
files=[];links=[]
for p in sorted((D/'raw').rglob('*.md')):
 rel=p.relative_to(D/'raw').as_posix();bp=D/'before'/rel;dp=D/'diffs'/(rel+'.patch');before=bp.read_text() if bp.exists() else '';raw=p.read_text();diff=dp.read_text();assert '[PENDING' not in raw
 if bp.exists():assert bp.read_bytes()==(W/rel).read_bytes(),rel
 else:assert not (W/rel).exists(),rel
 assert apply(before,diff)==raw and apply(raw,diff,True)==before,rel
 files.append(dict(path=rel,before=bind(bp) if bp.exists() else None,raw=bind(p),diff=bind(dp),forward_and_inverse_exact=True))
 added='\n'.join(line[1:] for line in diff.splitlines() if line.startswith('+') and not line.startswith('+++'))
 for target in re.findall(r'\]\(([^)]+)\)',added):
  if '://' in target or target.startswith('#'):continue
  target=target.split('#')[0];q=(W/rel).parent/target;future=target in ['evidence/promise-any-upstream/manifest.json','evidence/promise-any-upstream/sources-and-checks.tar.gz']
  held=(D/'raw'/rel).parent/target
  assert q.exists() or held.exists() or future,(rel,target)
  links.append(dict(owner=rel,target=target,publication_artifact=future))
assert len(files)==7
historical=[]
for rel,anchor in [('docs/VALIDATION.md','## Promise.any runtime'),('docs/promise-any.md','`Promise.any` consumes')]:
 b=(D/'before'/rel).read_text();a=(D/'raw'/rel).read_text();bs=b[b.index(anchor):];assert a[a.index(anchor):]==bs
 historical.append(dict(path=rel,anchor=anchor,suffix_sha256=sha(bs.encode()),exact=True))
check_refs(json.loads((N/'root/setup.json').read_text()))
extra=['root/setup.json','root/selection-1.json','root/profile-validation.json','source-parent.json','source-final.json','importer-1/census.json','importer-1/source-ready.json','controls-1/source-ready.json','gate-correction-1/source-ready.json','gate-correction-review-1/review.json','ci-1/source-ready.json','root/prior-ci-observation-2.json']
write('claims-and-checks.json',dict(status='actual claims checked and bound',final_validation=bind(ledger),source_final=bind(source),independent_observations=bind(D/'observations-checks-draft.json'),metric_text=bind(D/'metrics.json'),actual=dict(sources=94,modes=188,counts=observed['counts'],healthy_controls=102,control_outcomes=dict(passed=42,failed=58,resource=2),focused_groups=32,full_python_groups=624,older_cases=1100,older_controls=400),historical=historical,relative_links=links,root_reference_checks=refs,bindings=[bind(N/rel) for rel in extra],qualifications=['First focused31/1 and new-semantic empty-harness correction retained; tests/literals/oracles unchanged.','No new Rust build/full-suite/Clippy result or runtime/cap/wire change; published ordinary/host binaries reused.','New and old complete arrays retain failures and unsupported cases; no full-conformance/security/performance claim.','No remote CI result claimed for this checkpoint; parent CI remains separately bound.','Artifact counts/hashes are deferred to publication to avoid a self-reference cycle.'],execution='Only source/data/stdlib hash/diff/AST checks; no project execution or live edit.'))
write('source-ready.json',dict(status='frozen seven-document hold with actual final validation; external only',base='90c653d813feb62d1d569864bec076c0cc92d8a5',source_inventory=bind(source),final_validation=bind(ledger),files=files,claims_and_checks=bind(D/'claims-and-checks.json'),author=bind(D/'author.py'),seal_source=bind(D/'seal.py'),historical_suffixes=historical,scope='Six narrow existing-document updates plus new Any upstream chapter. Historical runtime/results exact. No live edits or project execution.'))
print(bind(D/'source-ready.json'))
