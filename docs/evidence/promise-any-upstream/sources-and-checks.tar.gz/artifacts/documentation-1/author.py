from pathlib import Path
import difflib,json,textwrap
N=Path('/tmp/eris-promise-any-upstream-plan-1');D=N/'documentation-1';W=N/'worktree'
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/promise-any.md']
for rel in paths:
 p=D/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():p.write_bytes((W/rel).read_bytes())
metric_path=D/'metrics.json'
if not metric_path.exists():metric_path.write_text(json.dumps(dict(status='draft; execution facts pending',result='[PENDING actual mode outcomes]',nonpasses='[PENDING actual nonpass breakdown]',python='[PENDING full Python result]',focused='[PENDING focused result]',replay='[PENDING exact new and old replay comparisons]',attempts='[PENDING retained execution qualifications]'),indent=2)+'\n')
m=json.loads(metric_path.read_text())
result=m['result'];nonpasses=m['nonpasses'];py=m['python'];focused=m['focused'];replay=m['replay'];attempts=m['attempts']
raw={rel:(D/'before'/rel).read_text() for rel in paths}
def replace(rel,old,new):
 assert raw[rel].count(old)==1,(rel,old)
 raw[rel]=raw[rel].replace(old,new)
replace('README.md','notifications remain unfinished.\n',"notifications remain unfinished. Its separate [complete pinned upstream profile](docs/promise-any-upstream.md)\nretains all 94 sources and 188 modes under a 102-control gate.\n"+result+'\n')
replace('docs/COMPATIBILITY.md','ECMAScript conformance result; a dedicated Any upstream profile is separate work.','ECMAScript conformance result. The separate [complete Any upstream selection](promise-any-upstream.md)\nretains all 94 pinned sources and 188 modes, with a 102-control gate.\n'+result)
replace('docs/COMPATIBILITY.md','intrinsic identity in ordinary ERJR2 observations; other profiles and all ERJR3\nvalidators retain their existing identity policy. Its measured result inventory','intrinsic identity in ordinary ERJR2 observations. The Any profile separately\naccepts it in authenticated ERJR3 responses; default decoding and older host\nprofiles retain their seven-name policy. Its measured result inventory')
replace('docs/ROADMAP.md','dedicated pinned upstream profile remains subsequent work; existing profile\nidentity and rejection policies are unchanged. Remaining asynchronous work','dedicated [94-source, 188-mode upstream profile](promise-any-upstream.md)\nuses a canonical 102-control gate and an Any-only ERJR3 AggregateError identity\ncapability. '+result+'\nOlder profile policies remain unchanged. Remaining asynchronous work')
replace('docs/SECURITY.md','responses. It rejects ERJR3 responses before delegation; other profiles and\nPromise-host validators keep the seven-name identity policy. Exact source/helper','responses. It rejects ERJR3 responses before delegation. The separate\n[Any upstream profile](promise-any-upstream.md) admits the eighth identity only\nunder its explicit ERJR3 profile context; default decoding and older host\nprofiles keep seven. Exact source/helper')
replace('docs/SECURITY.md','transport bytes or final-unhandled-rejection policy.\n\n[`Promise.any`]','transport bytes or final-unhandled-rejection policy. The Any gate revalidates\ncanonical nested records and prerequisites and recomputes classification.\nGenuine, renamed and forged-object controls test the diagnostic/identity boundary;\na schema-valid known identity still relies on trusted adapter output and is not\nproof against a compromised adapter.\n\n[`Promise.any`]')
replace('docs/promise-any.md','# Promise.any\n\n','# Promise.any\n\nThis chapter retains the runtime checkpoint and its original validation scope.\nThe subsequent [complete pinned upstream profile](promise-any-upstream.md) adds\nmeasured conformance records and an Any-only host identity capability.\n\n')
validation=f'''## Complete pinned Promise.any selection

The [Any upstream checkpoint](promise-any-upstream.md) retains all 94 sources
and 188 modes, with 102 canonical controls. {result}
{nonpasses}

{focused} {py}
{attempts}

{replay}
All 58 prior policies and the old source/control identities remain unchanged.
Only the selected Any host route gains AggregateError identity acceptance;
ordinary AggregateError remains ERJR2-only and older host/default routes keep
seven identities. The new gate rejects malformed or forged canonical records,
blocks case dispatch and refuses baseline recording when unhealthy.

This checkpoint changes tooling, authenticated corpus data and CI gates. It
reuses the published runtime checkpoint's Rust 1.88 ordinary/host adapters;
Rust execution inputs, wire bytes, runtime caps and build settings are unchanged.
No new Rust full-suite, Clippy or build result is claimed. The prior Promise.any
runtime section and all earlier validation records remain historical.

'''
replace('docs/VALIDATION.md','# Validation record\n\n','# Validation record\n\n'+validation)
raw['docs/promise-any-upstream.md']=f'''# Promise.any upstream results

The complete pinned Test262 `Promise/any` directory contains **94 sources and
188 sloppy/strict modes**: 130 authenticated asynchronous modes and 58 checked
synchronous modes. {result}
Every selected mode remains in the denominator. This is a bounded selection,
not full ECMAScript or Promise conformance.

The [corpus manifest](../tests/upstream/test262-promise-any/manifest.json) binds
all 94 source blobs, six unchanged upstream helpers, two legal/instruction files
and seven complete proof documents. Including the manifest, the corpus has
110 files at revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`.

{nonpasses}

The selected host route uses ERJS2 requests and requires ERJR3 responses.
Only `promise-any` gains the eighth host intrinsic identity, `AggregateError`.
The ordinary `aggregate-error` profile retains its ERJR2-only capability;
default and older host routes retain seven identities. Explicit profile context
reaches decoding, validation, classification and preflight verification.
Diagnostic names remain separate from private identity, and accepting an
AggregateError observation still classifies an ordinary positive case as failed.
Wire bytes, completion/audit rules and final-unhandled-rejection policy do not
change. These checks rely on trusted adapter output; they do not authenticate
a compromised adapter merely because its frame has a valid schema.

The controls have 42 expected passed, 58 expected failed and two expected
resource outcomes; all 102 satisfy their frozen expectations. The gate retains
the original 74 common rows and adds 20 semantic
pair rows plus eight identity rows. It checks method metadata/nonconstruction,
first fulfillment, ordered and empty errors, reusable fulfillment callbacks and
once-only rejection. A custom constructor's reject throws the genuine empty
aggregate twice, exercising its actual escape and outer retry. Separate renamed
and fake constructor/prototype objects distinguish diagnostics from identity.
Handled asynchronous controls assert errors directly; an unhandled-rejection
host record does not identify its rejection value's class.

The gate rebuilds canonical source/helper/mode/metadata fingerprints and exact
prerequisite references, validates raw evidence and recomputes classification.
A supplied verified flag or an unrelated exception cannot satisfy it. Failed
same-mode positives invalidate dependent guards. An unhealthy gate blocks the
selection and baseline recording.

{focused} {py}
{attempts}

{replay}
The [baseline](../tests/conformance/test262-promise-any-current.json) retains the
measured status and identity projection. Successful baseline recording/replay
means the gate is healthy and outcomes agree; it does not mean every case passes.

The published [runtime checkpoint](promise-any.md) at `90c653d813fe` supplies
both Rust 1.88 release adapters unchanged. Any and the older Promise profiles
use its `test262-host` binary; the ordinary AggregateError replay uses its
ordinary binary. This tooling checkpoint performs no new Rust build or full
Rust-suite validation and changes no runtime limit or production Rust input.

The host CI matrix adds this baseline gate to its Rust 1.88/stable jobs.
Reproduce with the existing host build and retained baseline:

```sh
cargo +1.88.0 build --locked --release --features test262-host --bin eris-js
python3 tools/test262_conformance.py --binary target/release/eris-js \\
  --profile promise-any \\
  --baseline tests/conformance/test262-promise-any-current.json \\
  --output artifacts/test262-promise-any-gate.json
```

No success result for this checkpoint's remote CI is claimed here. Classes,
destructured bindings, async functions and multiple realms remain unfinished;
source feature admission is not a claim of complete feature support. These
results establish no production security, process-memory bound or CPU/GPU/
Chromium-relative performance result. The [evidence manifest](evidence/promise-any-upstream/manifest.json)
and [source/check archive](evidence/promise-any-upstream/sources-and-checks.tar.gz)
retain the sources, controls, observations and validation receipts.
'''
chapter = raw['docs/promise-any-upstream.md']
raw['docs/promise-any-upstream.md'] = '\n\n'.join(
    paragraph if paragraph.startswith(('#', '```')) else
    textwrap.fill(' '.join(paragraph.splitlines()), width=79,
                  break_long_words=False, break_on_hyphens=False)
    for paragraph in chapter.strip().split('\n\n')) + '\n'
for rel,body in raw.items():
 p=D/'raw'/rel;q=D/'diffs'/(rel+'.patch');p.parent.mkdir(parents=True,exist_ok=True);q.parent.mkdir(parents=True,exist_ok=True);p.write_text(body)
 before=(D/'before'/rel).read_text() if (D/'before'/rel).exists() else ''
 q.write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True),body.splitlines(keepends=True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel)))
(D/'draft-status.json').write_text(json.dumps(dict(status='unsealed external draft',metrics=m['status'],files=list(raw),pending=[k for k,v in m.items() if isinstance(v,str) and '[PENDING' in v],no_project_execution=True,no_live_writes=True),indent=2)+'\n')
print('draft7; new chapter',len(raw['docs/promise-any-upstream.md'].splitlines()),'lines')
