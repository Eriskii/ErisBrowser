# Compatibility status

[Promise foundations](promise-foundation.md) provide construction, `then`,
`resolve`, `reject`, generic species/capabilities and thenable adoption in one
Window realm. Reactions share the `queueMicrotask` FIFO.
[Generic `catch`](promise-catch.md) preserves observable lookup/call behavior.
[`finally`](promise-finally.md) waits for cleanup and preserves or replaces the
original outcome according to cleanup success or failure, including generic
receivers, constructor/species selection and reusable callbacks.
[`Promise.all`](promise-all.md) collects synchronous iterable inputs in input
order, preserving generic capability, cached resolve and iterator/then behavior.
[`Promise.race`](promise-race.md) preserves generic capability callbacks, cached
resolve/next lookup and ordinary close/reject ordering; empty intrinsic races
remain pending. [`Promise.allSettled`](promise-all-settled.md) collects ordered
fulfilled/rejected records from synchronous iterables, preserving generic
capabilities and a shared gate for each input’s paired callbacks.
[`Promise.any`](promise-any.md) preserves the shared fulfillment callback and
uses once-only rejection callbacks to collect reasons in input order. Empty or
all-rejected input uses an intrinsic AggregateError. Async functions and rejection
notifications remain absent. These authored regressions are not a full
ECMAScript conformance result. The separate [complete Any upstream selection](promise-any-upstream.md)
retains all 94 pinned sources and 188 modes, with a 102-control gate.
It records **172 passed, 14 unsupported and two failed modes**, with all **102
controls verified**.

[`AggregateError`](aggregate-error.md) supports call/new construction, optional
message and cause, cached synchronous iteration and a fresh intrinsic errors
Array. It preserves observable operation order and ordinary thrown values;
iterator failures do not trigger closing. Genuine Error instances now have the
Error fallback `Object.prototype.toString` tag, while string tag overrides and
ordinary fake objects retain their distinctions. Promise.any reuses the saved
intrinsic AggregateError prototype without consulting the mutable global.
The separate [AggregateError upstream profile](aggregate-error-upstream.md) retains
all 25 pinned sources and 50 modes. Only this profile accepts the AggregateError
intrinsic identity in ordinary ERJR2 observations. The Any profile separately
accepts it in authenticated ERJR3 responses; default decoding and older host
profiles retain their seven-name policy. Its measured result inventory
is a bounded selection, not full-standard conformance.
The optional [Promise Test262 host](promise-test262-host.md) runs a separate
232-source, 458-mode selection with authenticated `$DONE` and final unhandled
rejection checks. All retained failures and unsupported modes belong in its
result inventory; this does not add browser rejection notifications or imply
complete Promise conformance. Its separate [complete `Promise.all` selection](promise-all-test262.md)
records **174 passed, 14 failed and 8 unsupported modes out of 196**. The fourteen
failures are final-unhandled host-policy failures. Eight class-bearing modes
remain unsupported. All 90 harness controls pass, and the prior 458-mode selection
retains its exact outcomes. The separate [complete `Promise.race` selection](promise-race-test262.md)
records **170 passed, 10 failed and 8 unsupported modes out of 188**, with all 90
controls verified. Its ten failures are final-unhandled host-policy observations;
eight class-bearing modes remain unsupported.
The separate [complete `Promise.allSettled` selection](promise-all-settled-test262.md)
retains all 104 sources and 208 modes with the same authenticated host policy
and a 94-control gate. It records **188 passed, 12 failed and
8 unsupported**, with all 94 controls verified. The twelve failures are final
unhandled-rejection host vetoes; four modes are class-feature exclusions and
four encounter unsupported class syntax in the parser.
[Call and constructor spread arguments](call-spread.md) close the four prior
parse failures. Mixed, multiple and empty spreads preserve iterator ordering,
receiver identity and argument-before-callability semantics within shared limits.
[Argument grammar contexts](call-argument-in.md) now admit unparenthesized `in`
inside ordinary and spread call/new arguments in `for` initializers. The outer
`for-in` restrictions remain in effect. [Computed keys and conditional
contexts](expression-in.md) also admit comma expressions inside member brackets
and enable `in` inside brackets and the middle of `?:`. Conditional tests and
false operands retain their outer grammar context. Array/object spread and
classes remain unfinished.
The [shared job metadata keys](shared-job-keys.md) reduce startup charges while
preserving function properties and identities; they add no API coverage.
The [Node accessor key-sharing follow-up](node-accessor-keys.md) similarly
reduces startup accounting while preserving the four existing accessors.
The [Node method follow-up](node-method-keys.md) shares the same immutable keys
across nine additional functions. It preserves their independent descriptors,
identities and behavior and adds no new API coverage.
The [Text metadata follow-up](text-metadata-keys.md) preserves the separate
`wholeText` getter and `splitText` method while reusing their immutable metadata
keys. Its startup saving adds no Text or Promise API coverage.
The [startup metadata follow-up](startup-metadata-sharing.md) also shares title
keys and PI/CharacterData owner-name payloads while preserving their descriptors,
identities and behavior. It changes accounting without adding API coverage.
The separate [trusted bootstrap budget](bootstrap-budget.md) grants fixed
intrinsic initialization 1,000,000 work units. Author entries retain 100,000
and cumulative allocation accounting remains 8 MiB. This policy change adds
no language or API support.

[Object.is](../tests/conformance/object-is.md) implements SameValue for existing
runtime values, including NaN, signed zero, exact UTF-16 strings and ordinary
object/symbol identity. All **42 upstream modes pass**, with 80 healthy controls.
The [DOM method follow-up](../tests/conformance/dom-method-identity.md) closes
four Document/Element query-identity failures, bringing the unchanged local
suite to **72/78 verified expectations**, with 60 healthy controls. Proxy,
BigInt and foreign-realm cases remain unmet. Existing query/append
methods now have separate defining-interface identities, function properties
and receiver checks. [Document.append](document-append.md) adds the ninth method
and checked insertion, bringing the unchanged local suite to **54/58 verified
expectations**, with 44 healthy controls. [DOM own properties](dom-own-properties.md)
now support individual string/symbol data, accessors and method replacement.
The frozen replacement case progresses to the missing complete Document
enumeration operation in both modes; its ordinary-success expectation remains
unmet. [DOM interface prototypes](dom-prototypes.md) now provide represented
HTML, SVG and MathML chains, interface metadata, mutable ParentNode operations
and Text, Comment and DocumentFragment construction.
[Processing instructions](processing-instruction.md) add genuine construction,
the Document factory, target and CharacterData data/length accessors.
[Exact data production](dom-production.md) covers Text, Comment and PI
constructors, `createTextNode`, the PI factory and the data setter. Five
[CharacterData methods](character-data.md) preserve exact UTF-16 substring and
splice results, including isolated units and repaired boundaries. The
[DOM string foundation](dom-strings.md) supplies canonical storage, exact
reads/clones and unchanged ERWA snapshots. All eight earlier unmet expectations
now pass, bringing the original CharacterData replay to 34/34; all 24 new modes
also pass. [Node data accessors](node-data.md) add ordinary `nodeValue` and
`textContent`: exact CharacterData and descendant reads, nullable conversion,
and fresh Text replacement that preserves detached old subtrees. Descriptor
shadowing/deletion follows ordinary lookup. [Exact append strings](append-domstrings.md)
retain separate Text identities, unpaired units and completed failure prefixes
for Document, Element and DocumentFragment; all fourteen new modes pass.
[Document.title](document-title.md) adds ordinary prototype accessors, exact
ASCII-whitespace-normalized reads, HTML/SVG selection and staged replacement.
[Text operations](text-operations.md) add ordinary `splitText` and readonly
`wholeText`, exact UTF-16 offsets, fresh post-conversion state and contiguous
ordinary Text reads. [Node normalization](node-normalize.md) removes empty ordinary
Text descendants and merges contiguous runs while retaining detached identities
and exact data. It does not traverse separate template content implicitly.
[Node predicates](node-predicates.md) add ordinary `hasChildNodes`, `isSameNode`
and `contains`, with authentic identity, required nullable arguments and fresh
ordinary ancestry after argument evaluation. Template contents remain separate.
[Node root lookup](node-root.md) adds `getRootNode` for represented trees, with
observable options conversion before following fresh parent links. Both composed
values keep template content separate; ShadowRoot remains unimplemented.
[Connection state](node-connected.md) adds the ordinary readonly `isConnected`
getter for represented nodes. It follows current ordinary ancestry; a template's
content remains disconnected even when its host is connected. Actual ShadowRoot
and independent document ownership remain absent.
[Ordinary position](node-position.md) adds `compareDocumentPosition`: identity
`0`, earlier/later branches `2`/`4`, and ancestor/descendant masks `10`/`20`.
The required Node argument is nonnullable; omitted/null/undefined inputs throw
TypeError without coercion hooks. Disconnected ordinary trees use `35` or `37`,
with a stable original-operand-ID policy within the retained arena. Actual Attr
ordering, ShadowRoot and independent document ownership remain outside this scope.
All 32 new modes and 16 controls pass; the 30-key prototype/21-key constructor
inventory and 22-ID Page/worker witness pass. Historical losses retain their
ordinary Error or unhealthy TypeError observations, without a health waiver.
[Checked cloning](node-clone.md) adds ordinary `cloneNode` for represented
non-Document nodes, detached fresh identities, exact retained payloads and separate
template content. Its 34 release modes and 16 controls pass. `Object.hasOwn` also
passes 16 independent modes and eight controls for represented own descriptors.
Its complete pinned [upstream directory](../tests/conformance/object-has-own.md)
passes all 124 modes, with 64 healthy controls.
Document cloning, complete per-element cloning state and universal host reflection
remain incomplete.

[Structural equality](node-equality.md) adds `isEqualNode` for represented nodes,
including exact character data, the fixed namespace/attribute model and ordered
ordinary children. Template contents are compared only when supplied as operands;
large comparisons can exhaust the unchanged work or storage allowance.
CDATA, live Ranges and cross-node text shaping remain gaps.
PI pseudo-attributes and mutation notifications remain unfinished.
Complete interface members,
Document reflection and host prototype mutation remain incomplete. The unchanged
DOM suite now verifies **56/58 expectations**, with all 44 controls healthy; the
two complete-Document-enumeration expectations remain unmet. The earlier eight-method
checkpoint's complete 44-profile replay preserved all prior formal case/control
observations and all 36 baseline gates.

[ArrayBuffer](../tests/conformance/array-buffer.md) supports nonshared fixed and
resizable buffers, byteLength/maxByteLength/resizable/detached getters, resize,
same-realm species-aware slice, transfer and transferToFixedLength. Ordinary
properties and object freezing do not alter private backing storage. `isView`
recognizes authentic DataView instances, including detached or out-of-bounds
views. Shared buffers, Proxy and foreign realms remain incomplete.
At the original ArrayBuffer checkpoint, the complete 221-source profile recorded
**262 passed, 50 failed and 130 excluded modes**, with all 160 controls verified. The failures retain 48 missing-Uint8Array
observations and two untagged BigInt syntax failures. The independent local
matrix verifies **96 of 104 expectations** after the
[for-in length-bucket follow-up](../tests/conformance/for-in-length-buckets.md)
closes two metadata work stops and DataView closes two prerequisite modes.
Eight prerequisite modes remain unmet.

[DataView](../tests/conformance/data-view.md) supports fixed and tracking views,
three getters and nine Number getter/setter pairs, including Float16. Conversions
run before fresh bounds checks; ordinary properties and freezing do not freeze
backing bytes. The complete 561-source profile records **694 passed, 12 failed
and 416 unsupported modes**, with all 232 controls verified. All twelve failures
require missing BigInt support. The local suite verifies **128/138 expectations**,
including four resource cases, with all 92 controls verified. BigInt codecs,
shared and immutable buffers, Proxy and foreign realms remain gaps.

[Number TypedArray foundations](typedarray-foundation.md) add ten Number kinds,
length/buffer/typed-array/iterable/array-like constructors, metadata getters,
values/keys/entries, authentic isView and live indexed property operations.
Fixed and tracking views observe resize and detachment. Generic Array and JSON
operations use the same indexed property hooks. Static methods, remaining bulk
operations, sorting/copying, BigInt views and shared buffers remain incomplete. The frozen
local matrix passes all 54 modes with 32 verified paired controls; the upstream
profile retains its failures, exclusions and work-limit stops.
The foundation checkpoint records 572 passes, 86 failures, 488 unsupported modes
and 92 work stops. The later [Reflect property increment](reflect-properties.md)
records **588 passes, 44 failures, 488 unsupported modes and 118 work stops**
over the same 1,238 modes. Sixteen former failures pass; 26 advance past an absent
Reflect method and exhaust the unchanged instruction budget. No previous pass
regresses. Both historical reports are retained.
The [views and string conversion follow-up](typedarray-views-test262.md) adds
`subarray`, `join`, and the exact `Array.prototype.toString` alias for Number
TypedArrays. Default subarrays share storage; species callbacks and live buffer
checks preserve their required order. Joined text preserves UTF-16 separators,
and the shared `toString` function honors a replaced `join`.
The [local report](../tests/conformance/typedarray-views-local-current.json)
records **46 passing modes and 24 verified controls**. These 70 local modes form
the views CI gate. The [206-mode upstream report](../tests/conformance/test262-typedarray-views-after.json)
records **46 passed, 64 resource-limited and 96 unsupported modes**, with all
56 controls verified. Resource outcomes make the complete report unhealthy for
baseline recording, despite its healthy controls; it is not an upstream gate.
The [foundation follow-through](../tests/conformance/test262-typedarray-after-views.json)
records **590 passed, 34 failed, 488 unsupported and 126 resource-limited modes**,
with all 64 controls verified. Both modes of the original
`DefineOwnProperty/key-is-not-numeric-index.js` case pass again after a retained
development resource regression. Direct DataView metadata, per-operation key
classification reuse and smaller visited-name storage remove repeated work
under the unchanged quotas. Other failures and resource stops remain recorded.

The [TypedArray search follow-up](typedarray-search.md) adds `at`, `includes`,
`indexOf` and `lastIndexOf` to all ten Number kinds. It validates the initial
receiver and captures its length before index coercion, then checks live buffer
bounds for each reached element. `includes` uses SameValueZero, including NaN;
`indexOf` and `lastIndexOf` use strict equality and skip indices made absent by
resize. Omitted and explicit `undefined` reverse-search indices remain distinct.
The pinned profile retains all 145 original sources and 290 modes; its policy
schedules 158 modes and explicitly excludes 88 BigInt, 26 complete-helper and
18 host-hook modes. The search checkpoint records **78 passes, 78 work-limit stops and two
failures**, with all 56 controls verified. Both failures call the missing `fill`
method before the search. Resource outcomes prevent an upstream baseline.

[`fill`](typedarray-fill.md) now supports Number view ranges, ordered value/start/end
conversion, fresh final bounds and complete scalar writes under the existing
resource limits. Its full profile records **22 passes, 32 work-limit stops and
50 exclusions**, with all 52 controls verified. Both earlier search failures now
pass; the search profile records **80 passes, 78 work-limit stops and 132 exclusions**.
Neither complete report is eligible for an upstream baseline. Direct Page and
confined-worker click tests verify the example's literal text and result pixels.
The [encoding follow-up](typedarray-fill-encoding.md) prepares the scalar once
per nonempty fill and retains every prior case and control result, including
the remaining work-limit stops.

[`reverse`](typedarray-reverse.md) now reverses all ten Number view kinds in
place, validating current bounds and retaining only admitted complete scalar
writes if interrupted. Its complete 44-mode profile records **22 passes, four
work-limit stops and 18 exclusions**, with all 52 controls verified. The resource
outcomes prevent an upstream baseline. Both the direct and confined-worker
example tests verify two clicks and shared-buffer changes. All 43 earlier
reports retain their case and control rows exactly.

[`toReversed`](typedarray-to-reversed.md) now creates a reversed copy of each
Number view kind without changing its source. The result has distinct fixed
storage, including for an empty source. The complete 18-mode profile records
**eight passes, eight work-limit stops and two host exclusions**, with all
52 controls verified. Resource outcomes keep the report unhealthy and prevent
an upstream baseline or gate. Direct Page and confined-worker tests check two
real clicks, literal text and changed result pixels. All 44 earlier reports
retain their 18,280 case rows and 4,232 control rows exactly.

[`copyWithin`](typedarray-copy-within.md) now copies ranges within all ten Number
view kinds, chooses the correct overlap direction and preserves exact scalar
bits. Target, start and defined end arguments convert in order; final buffer
validation and clipping follow those conversions when the initial count is
positive. Its complete 130-mode profile records **20 passes, 46 work-limit stops
and 64 exclusions**, with all 56 controls verified. Resource outcomes keep the
report unhealthy; no upstream baseline or gate is recorded. Direct Page and
confined-worker tests check two real clicks, aliasing, literal text and pixels.
The accompanying visited-name optimization keeps two same-length names inline,
charging the larger outer representation before use and allocating a search
tree only for a third distinct live name.

The TypedArray foundation increment raises the existing ArrayBuffer profile to 310 passes,
two failures and 130 exclusions, and the object-integrity profile to 416 passes,
20 failures and 38 exclusions. All other observations in the 37 replayed
CI-gated profiles remain unchanged; their original baseline files are retained.

[Reflect property operations](reflect-properties.md) add `has`, `get`, `set`,
`deleteProperty`, `getOwnPropertyDescriptor`, `getPrototypeOf`, `setPrototypeOf`,
`isExtensible` and `preventExtensions`. Explicit receivers, supported exotic
properties, descriptor flags and Boolean refusal behavior share the existing
property machinery. The intrinsic Object prototype is immutable. The complete
108-source profile records **200 passed and 16 Proxy exclusions**, with all
52 controls verified; the independent local matrix passes 28 modes and 20 paired
controls. Represented DOM descriptors are supported, while unresolved legacy
DOM string properties explicitly remain unsupported. Proxy, foreign realms and
full platform-object internal methods remain incomplete.

[Array concat](../tests/conformance/array-concat.md) supports generic receivers,
live spreadability and same-realm species results, including ordinary objects,
Arrays, mapped arguments and input aliases. Species construction precedes
spreadability reads; holes advance the result index without deleting existing
keys, and the strict final length write can fail after earlier effects. The
complete 69-source profile records **113 passed, four failed, 18 unsupported
and two resource modes**, with all 96 controls verified. The independent local
matrix verifies **84 of 90 expectations**, including four expected resource
stops. Proxy, typed-array and cross-realm prerequisites remain unmet. Two ordinary
upstream hole scans reach the work limit, so no new baseline or CI gate is added.
Other Array methods' species behavior is unchanged.

[Array splice](../tests/conformance/array-splice.md) supports generic ordinary
receivers, captured safe-integer lengths, live inherited properties and same-realm
species construction. Deleted results preserve holes; source moves and deletes
follow the specified direction, and errors retain earlier effects. Species may
return the source, another Array or a supported ordinary object. The complete
81-source profile records 138 passes and 24 metadata exclusions across 162 modes,
with all 96 controls verified. The local matrix verifies 90 of 96 expectations,
including four expected resource stops; Proxy, typed-array and cross-realm cases
remain unmet. This does not extend custom species handling in map/filter/slice.

[Shared enumeration accounting](../tests/conformance/own-keys.md) preserves all
17,822 historical case observations and 3,900 controls with unchanged quotas and
baselines. String-key snapshots and for-in visited-name work are now charged;
this adds no new conformance passes or unsupported-feature coverage.
The [one-pass own-key snapshot follow-up](own-keys-one-pass.md) removes the
second creation-order scan for the existing ordinary-string path. All 45
reports retain their **18,298 case rows and 4,284 control rows exactly**,
including existing failures and resource stops; all 38 historical gates pass.
Quotas, policies and baselines remain unchanged. It can use more scratch
storage when symbols follow strings. Local timing changes are small and mixed,
with four p95 regressions, so this establishes no general browser speedup.

[Array.from](../tests/conformance/array-from.md) supports synchronous iterable
and array-like inputs, generic constructors, live mapping, own indexed data
properties and iterator closing. Its complete 47-source upstream profile has
86 passing modes and four generator/cross-realm metadata exclusions after the
ArrayBuffer follow-up; all 96 controls verify. The independent
local matrix verifies 388 of 402 expectations, including twelve terminal-resource
cases. Both modes of seven unsupported prerequisites remain unmet: generators,
classes, Set, Map, typed arrays, Proxy and BigInt. These are retained failures or
unsupported observations, not a claim of complete ECMAScript support.

[Synchronous iteration](../tests/conformance/for-of.md) covers identifier/member
`for…of` heads, lexical bindings and custom, Array, String and arguments iterators.
Destructuring, generators and async iteration remain incomplete.

[Date](../tests/conformance/date.md) now has internal time values, ordered
construction and setter conversions, UTC/local fields, ISO parsing/formatting,
required string round trips, JSON and primitive-conversion hooks, and the
legacy year/GMT aliases. Local operations use an explicit host timezone
snapshot with historical transitions, recurring rules and gap/overlap handling.
The complete core Date profile retains 594 sources and 1,188 modes: 1,166 pass,
and 22 retain their metadata exclusions. Synchronous iteration closed the four
previous year-zero parser gaps.
All 340 controls and 406 independently frozen local modes pass. Broader legacy
date parsing, Intl locale formatting, Temporal and cross-realm behavior remain
incomplete. Locale methods currently use the documented
English local-date forms permitted by the core specification without Intl.

Script-enabled browser/CLI/adapter startup captures host rules explicitly.
Missing or unsupported rules produce an initialization error; scripts-disabled
pages remain usable. On systems whose named-zone database is outside
`/usr/share/zoneinfo`, set `TZDIR` to its real location. Library embedders provide
a validated Date host context for local operations; UTC operations do not require
local-zone configuration.

[Array find methods](../tests/conformance/array-find.md) now support `find`,
`findIndex`, `findLast` and `findLastIndex` on ordinary generic receivers.
Their captured range includes holes and deleted indices, with live inherited
property lookup in the required direction. A matching callback returns its
previously read value or index; callback coercion, receiver and abrupt effects
use the existing call path. All 504 frozen local variants and twelve controls
pass.

The [complete profile](../tests/conformance/test262-array-find.md) retains
94 sources and 180 modes. It now records **148 passed and 32 metadata
unsupported**, with all 288 controls verified. The original find checkpoint
added 116 passes; splice closes its eight callback-body prerequisite failures.
Proxy, typed/resizable arrays, general host receivers and complete
`with`/unscopables remain gaps. The regression baseline retains every exclusion.
Two initial lastIndexOf
work-limit regressions were corrected by charging actual decimal-key digits;
stronger property-lookup charges and all quotas remain in force.

[Object integrity](../tests/conformance/object-integrity.md) now supports
`Object.seal`, `Object.freeze`, `Object.isSealed` and `Object.isFrozen` on
supported ECMAScript objects. Arrays retain holes and length flags; accessors
are preserved without getter calls; sealing mapped arguments retains aliases,
while freezing snapshots and detaches them. Operations are shallow and preserve
earlier effects if a later property or resource operation fails. Window/DOM
hosts, Proxy and typed-array behavior remain unsupported.

The [complete new profile](../tests/conformance/test262-object-integrity.md)
retains 239 sources and 474 modes. After the DataView follow-up it records
**398 passed, 38 missing-prerequisite failures and 38 unsupported**, with all 224 controls
verified. All 228 local variants and 12 controls pass. Eight older descriptor
modes gain passes, with no previous pass lost. The new profile has a healthy
regression gate; its 38 failures and 38 unsupported observations remain part of
the baseline. This does not establish complete object or host conformance.

[Array every and some](../tests/conformance/array-predicates.md) now support
generic ordinary receivers, captured length, holes, inherited/indexed accessors
and live callback mutations. They short-circuit using callback truthiness and
preserve callback receiver and abrupt-completion behavior. All 164 frozen local
variants pass. The [complete paired upstream inventory](../tests/conformance/test262-array-predicates.md)
records **847 passed, four work-limit stops and 16
metadata exclusions** across 867 modes. Huge sparse scans remain budgeted;
Proxy and general host receivers remain unsupported. Number TypedArray indices
now use the shared live property hooks. Resource
stops prevent a healthy baseline for this profile.

[Array.lastIndexOf](../tests/conformance/array-last-index-of.md) now supports
ordinary generic receivers, holes, inherited entries, saved length and live
getters. Its complete 395-mode inventory records 385 passed,
two array-setup resource stops and eight unsupported modes. Array descriptor and
sparse-storage gaps remain; this is an observation inventory, not a healthy gate.

[String.lastIndexOf](../tests/conformance/string-last-index-of.md) now handles
ordered conversion, NaN/default positions and reverse UTF-16 search. Its complete
50-mode selection now passes all modes after the Array follow-up. The earlier
String implementation also added 12 match/search passes.

[String and RegExp match/search protocols](../tests/conformance/regexp-match-search.md)
now support custom symbol hooks, raw receivers, observable fallback dispatch,
global match collection and exact search index restoration. The complete new
340-mode selection now records 316 passed, four failed and 20 unsupported.
BigInt, Unicode pattern syntax and replacement/matchAll protocols
remain incomplete.

[RegExp constructor classification and conversion](../tests/conformance/regexp-constructor.md)
now handle Symbol.match-based identity, regexp-like source/flags and observable
allocation/conversion order. The [flat group parser](../tests/conformance/regexp-deep-groups.md)
adds four passes for deeply nested patterns, and [required-literal rejection](../tests/conformance/regexp-required-literals.md)
adds both XML-pattern modes. The complete 976-mode directory now
records 774 passed, 200 unsupported and two resource stops. Unicode regexp
syntax, broader legacy grammar, matching performance, realms and remaining symbol
protocols need work.

[RegExp split and species](../tests/conformance/regexp-split.md) now use a separately
constructed splitter and observable execution, index and capture hooks. The new
96-mode selection records 90 passed and six unsupported
modes. Unicode regexp parsing, realms and other symbol methods remain incomplete;
the constructor follow-up above addresses classification and conversion order.

[String conversion, search and custom splitting](../tests/conformance/string-conversion.md)
now respect ordinary receiver/needle conversion, `Symbol.match` classification
and object separators' `Symbol.split` hooks. The new 484-mode selection records
470 passed, two failed and 12 unsupported modes; the two older slice failures
also pass. The built-in split protocol is covered by the follow-up above;
other String symbol protocols remain incomplete.

[Dynamic ordinary Function construction](../tests/conformance/function-constructor.md)
now uses global scope, separate parameter/body grammar and the caller's remaining
resource budgets. Its new 200-source selection records 241 passed and 50 unsupported
modes; older selections gain 35 passes. Its two exposed string-slice failures
are fixed by the conversion follow-up above. Function source printing, literal unpaired
surrogates in generated source and the wider Function family remain incomplete.

The [Symbol constructor/policy follow-up](../tests/conformance/constructor-policy.md)
accepts Symbol as an alternate constructor target while preserving its throwing
construction behavior. The Symbol profile now records 184 passed, four failed and
54 unsupported modes. Across the existing inventories, 88 additional modes are
admitted and pass; two required this implementation fix, while 86 already passed.

[Constructor targets and Reflect calls](../tests/conformance/construction.md) cover
`new.target`, `Reflect.apply`, `Reflect.construct`, lexical arrows, bound forwarding
and supported ECMAScript allocation prototypes. The two complete pinned selections
now record 58 passed and eight unsupported modes.
classes/super, tagged templates, alternate Web IDL targets and broader native
constructor conformance remain incomplete.

[DOM string conversion and receivers](../tests/conformance/dom-string-conversion.md)
cover the supported creation, query, attribute, tree and class-list operations.
String hooks run in argument order before those operations; borrowed methods use
their actual receiver. Nullable text and Boolean properties retain distinct
conversion rules. [Exact character-data production](dom-production.md) covers
its named constructors, factories, data setter and five methods. Ordinary
[Node data accessors](node-data.md) also preserve exact units through
`nodeValue` and `textContent`. [ParentNode.append](append-domstrings.md) likewise
preserves each string argument after ordered conversion, without coalescing
separate Texts. [Document.title](document-title.md) adds exact raw writes and
normalized direct-Text reads. [Text splitting and adjacent reads](text-operations.md)
preserve exact units and separate node identities. [Node.normalize](node-normalize.md)
uses exact internal streams and preserves the first nonempty Text in each run.
[Node predicates](node-predicates.md) query current children, identity and ordinary
containment without changing the tree or converting objects into Nodes.
[Root lookup](node-root.md) returns the existing ordinary root after one
inherited `composed` member read for object options, preserving getter effects.
[Structural equality](node-equality.md) compares retained data without replacement
projection and without changing either tree. It performs no authored property
lookup or conversion inside the native comparison.
Legacy `innerText`, textarea
setters, attribute and
HTML-parser writes remain separate, alongside
remaining interface members, general XML name handling, live collections and
complete DOM hierarchy semantics.

[Symbol primitives and property keys](../tests/conformance/symbols.md) now include
identity, registry/description behavior, descriptors, computed keys, JSON omission,
`Symbol.toPrimitive`, `Symbol.toStringTag`, `Symbol.hasInstance`,
`Object.getOwnPropertySymbols` and `Reflect.ownKeys`. The complete new profile
originally recorded 168 passed, six failed and 68 unsupported modes. Iteration, RegExp dispatch,
species, other realms and most Reflect methods remain incomplete.

[String.prototype.concat](../tests/conformance/string-concat.md) supports generic
receivers, ordered conversion, shared method identity and exact UTF-16 output.
Its complete pinned directory has 42 passing modes and two metadata exclusions
for Reflect.construct. This does not complete the remaining String methods.

This is an implementation inventory, not a conformance certificate. A feature listed as partial supports specific cases; it does not imply passing that specification's full tests. Unsupported syntax is generally ignored by HTML/CSS or reported by the script interpreter.

| Area | Implemented subset | Missing or incomplete |
|---|---|---|
| HTML | Tokenization, retained comments/doctypes/processing instructions, implied html/head/body, common optional end tags, script escaped states, scripting-aware noscript, table insertion modes and foster parenting, active formatting reconstruction and bounded adoption-agency recovery, named/numeric character references, SVG/MathML foreign-content namespaces and integration points, context-sensitive HTML/SVG/MathML/template fragments, template insertion modes, retained document modes, HTML byte encoding selection/reparse, select/frameset/ruby recovery, parser selectedcontent cloning, basic forms | Complete parsing and custom select behavior, incremental document.write parsing, declarative shadow roots/content patching, complete quirks rendering |
| DOM | Arena tree with character/doctype metadata nodes, textContent, attributes, creation/appending/removal, selector queries, bounded serialization, HTML/SVG/MathML namespace identity and adjusted attributes, context-sensitive innerHTML subset, hosted template DocumentFragments, fragment transfer, bounded cloneNode, classList, document URL and frozen base metadata | Full interfaces and arbitrary XML namespaces, mutation observers, ranges, selections, shadow DOM, custom elements, DOM exceptions, complete live collections |
| CSS selectors | Shared token-aware parsing, comment/whitespace boundaries, type, universal, ID, class, attributes, descendant/child/sibling combinators, selected structural/logical pseudo-classes | Full escaping/namespaces, interaction-state pseudo-classes, generated pseudo-elements, complete Selectors conformance |
| CSS cascade | Specificity, source order, important declarations, inline styles, inherited properties, custom properties, selected media conditions, bounded stylesheet imports, named/anonymous nested cascade layers, normal/important ordering and revert-layer, bounded supports conditions and conditional imports | Scopes, complete invalid-value semantics and feature queries, container queries, font-face |
| CSSOM | Bounded inline style value/priority queries and mutation, cssText, length/item/index reads, supported camel/dashed property aliases and cssFloat, case-sensitive custom names, persistent pending-longhand partial removal/priority replacement | Stylesheet/rule interfaces, computed style, complete value and shorthand serialization, complete prototypes/reflection and expandos |
| CSS calculations | Bounded additive length-percentage `calc()`, nested sums/differences, retained percentage dependency, actual sizing bases and used-value clamping | Products/division, numeric calculations, min/max/clamp and other math functions, complete percentage-radius storage, full intrinsic sizing and required nesting range |
| Media queries | Screen/all/print types, only/not, comma alternatives, grouped and/or/not conditions, width/height lengths and range comparisons, escaped identifiers, orientation and selected fixed environment values; unknown features retain unknown truth through negation | Math functions, aspect ratio/resolution, complete feature inventory and actual system/device preference integration |
| Layout | Block/inline flow, text wrapping, margins/padding/borders, flex rows/columns/reverse/order, scaled shrink and min/max freezing, align-self/auto margins, row/column wrapping and cross-line align-content, Grid lines/spans and dense row/column placement, explicit/implicit tracks, minmax/fr sizing and alignment, tables/spans with inherited [two-axis spacing](table-spacing.md) and [originating-cell row paint](table-row-backgrounds.md), left/right floats, clear, shrink-to-fit, partial formatting contexts, relative/absolute/fixed positioning, padding-box containing blocks and bounded stacking contexts | Complete formatting contexts, intrinsic flex auto minimums, baseline alignment, writing-mode and indefinite-size interactions, full positioned flex behavior, complete Grid intrinsic sizing/named areas/subgrid, full intrinsic table sizing/row-group and column backgrounds/caption placement, empty-cells, border-collapse, float margin-collapse/painting interactions, full inline/static-position geometry, sticky positioning, multicolumn/pagination, transforms, writing modes and bidi |
| Typography | Bundled sans/bold/monospace fonts, basic advances/kerning, synthetic italics, alignment/decoration | Complex text shaping, font fallback/downloads, full Unicode line breaking, hyphenation, variable fonts, complete font selection |
| Paint | CPU display lists, nested rectangular overflow clips, rounded backgrounds/borders, alpha blending, cached glyphs, raster images, up to eight [gradient/URL background layers](background-layers.md) with independent geometry lists and [origin/clip box selection](background-boxes.md), [CPU-prepared opaque Native gradients](native-box-gradient.md), separate viewport-fixed paint/hit coordinates, group opacity with deferred bounded premultiplied RGBA16 surfaces, scrolling and zoom; optional Vulkan compositing with bounded [full-range group opacity](vulkan-full-opacity.md) and selected [large rounded Color backgrounds](vulkan-rounded-core.md) | Full compositor, rounded clipping masks/separate overflow axes, filters, masks, shadows, radial/conic/repeating gradients, gradient hints/modern color spaces, background attachment/blending and space/round repeats, GPU gradient interpolation and Native alpha/rounded/opacity-gradient paths, animations, broader hardware acceleration, color management |
| Images | PNG, JPEG, first-frame GIF/WebP, BMP via image codecs; bounded SVG subset; loaded-img [object-fit and physical object-position](image-fitting.md), including rasterized external SVG | Animated image playback, AVIF, complete SVG, image orientation/media fidelity and full responsive image selection |
| SVG | Basic shapes, paths, fill/stroke, viewBox, transforms, simple text | Full SVG/CSS integration, filters, patterns, gradients, masks, markers, foreignObject, animation, external resource references |
| JavaScript | Primitive values, UTF-16 strings, untagged interpolated templates, computed object keys/methods/accessors and static prototype setters, arrays/objects, lexical initialization and loop scopes, operators including comma expressions, strict directives and reference/receiver rules, control flow including switch and do/while, closures/functions/arrows with identifier default/rest parameters, bounded dynamic ordinary Function construction, constructors/this/instanceof and basic prototypes, ordinary call/new spread arguments and trailing commas, ordinary data/accessor descriptors, for-in enumeration, deletion and bound functions, mapped/unmapped arguments, throw/try/catch/finally, selected builtins, Promise construction/reactions/thenable adoption, `Promise.all`, `Promise.race`, `Promise.allSettled` and `Promise.any`, DOM bindings and events | Full ECMAScript, classes/modules, destructured parameters, dynamic eval, complete Function source/UTF-16 handling, complete Annex B behavior, complete prototypes/exotic descriptors/coercion, async functions and complete Promise APIs, complete Error constructors/prototypes/stacks, tagged templates, complete String methods/generic receivers/property behavior, fractional/large nondecimal Number.toString, JIT and GC |
| RegExp | Custom UTF-16 non-Unicode literals/constructor, d/g/i/m/s/y flags, captures/named groups, alternatives/classes/quantifiers, anchors/boundaries, lookahead/backreferences, exec/test/lastIndex, String match/search/replace/split | Unicode u/v modes and properties/sets, lookbehind, modifier groups, duplicate/non-ASCII group names, several legacy escape forms, Symbol hooks/species and complete RegExp compatibility |
| JSON | Strict JSON grammar, ordered object properties, numeric formatting, UTF-16 strings including lone-surrogate round trips, toJSON, primitive unboxing, replacer callbacks/allowlists, code-unit indentation, cycle errors, postorder reviver with primitive source context | DOM/window serialization, complete source-context semantics, BigInt-related behavior and rawJSON APIs remain unsupported |
| Events | Event/CustomEvent/EventTarget constructors, dispatchEvent, capture/target/bubble phases, fixed paths, listener identity/mutation, once/passive/handleEvent, cancellation and propagation, inline handlers, trusted native and synthetic author events, AbortController/AbortSignal reasons and listener removal, readiness/click/input hooks, ToggleEvent, exact reentrant disclosure tracking, bounded native idle continuation and single-realm microtask checkpoints | Shadow DOM retargeting, AbortSignal.any/timeout and broader cancellation, specialized UI/pointer/touch/keyboard events, complete activation/default actions, complete asynchronous task/event-loop scheduling, full Window/body handler forwarding and event lifecycle |
| Disclosures | HTML details/summary visibility, first-summary and generated-summary activation, exclusive name groups, open/name reflection and coalesced toggle notifications | Full event-loop timing, anonymous content-slot formatting, fragment reveal, keyboard event ordering, accessibility and complete marker styling |
| Forms | Scalar-safe text cursor/selection editing, checkbox/radio toggling, bounded GET and HTTP(S) POST URL-encoded serialization, selected options, submitter method/action/encoding overrides, disabled-fieldset handling | Multipart/text-plain POST and file upload, constraints, complete reset/default behavior, native selection controls, autofill, password management |
| Network | HTTP(S) GET and URL-encoded document POST, verified TLS, gzip, relative URLs, checked redirects (301/302/303 convert POST to GET; 307/308 preserve it), bounded bodies, charset labels, separate native resource broker, authoritative cross-origin document redirects, isolated cross-origin image decoding with redirect taint | Browser HTTP cache, cookies, authentication, full Fetch/CORS/CSP, HSTS persistence, HTTP/2/3, service workers, WebSocket/WebTransport |
| Browser | Single window/document, address entry, history, scrolling, basic keyboard focus, zoom, native text clipboard shortcuts, per-document confined Linux renderers and resource brokers, headless PNG output | Tabs, downloads, permissions UI, devtools, document find/selection, grapheme text editing, complete IME and accessibility |
| Other platform APIs | No broad implementation | Canvas APIs, WebGL/WebGPU, WebAssembly, audio/video, WebRTC, storage/IndexedDB, workers, geolocation, sensors, notifications, payments, credentials, extensions, printing and many others |

The URL parser and encoding libraries are infrastructure libraries, not independent reimplementations of those specifications. There is no claim that every dependency is authored in this repository.

[Table spacing](table-spacing.md) stores an inherited computed horizontal/vertical
pair. CSS initial is zero; the HTML table default is 2px on both axes. One value
duplicates, two select axes independently, and the existing absolute, font and
viewport length units plus additive `calc()` are accepted. Percentages, negative
literal lengths and nonzero unitless values are rejected. Declarations,
`CSS.supports` and inline CSSOM use the same validator; `borderSpacing` and
`border-spacing` address the same longhand. [Row backgrounds](table-row-backgrounds.md)
use final originating-cell rectangles with a shared row positioning area;
colspan interiors and rowspans retain coverage, while gaps and missing slots
expose the table. Explicit empty cells still receive paint. Simplified track
sizing, top-caption and empty-table policies remain. Row-group/column
backgrounds, `empty-cells`, `border-collapse`, `table-layout`, `caption-side`,
`cellspacing` mapping and general relative/rounded-cell clipping remain absent
or incomplete.

[Layered backgrounds](background-layers.md) support up to eight `none`,
`linear-gradient()` or loaded `url()` image slots. Each gradient retains one to
sixteen legacy-color items, at most thirty-two expanded stops, physical
directions/angles, optional `in srgb`, and bounded length/percentage `calc()`.
Size, physical one/two/three/four-component position, repeat axes and
border/padding/content origin/clip lists retain independent lengths; shorter
lists cycle only when used. The first image paints on top, with one color below
the last slot. The shorthand atomically resets seven supported longhands.
Shared validation covers declarations, variables, `CSS.supports` and inline
CSSOM. Its getter conservatively refuses unrepresentable list cardinalities,
except exact canonical singleton initial dependent values may be omitted.
Canvas body propagation requires a transparent root with exactly one `none`;
multiple `none` entries retain root ownership. Principal, table and ordinary
inline paths share existing resource/paint limits. Attachment modes,
`space`/`round`, blend modes, clip-to-text and broader gradient/color syntax
remain unsupported. [Native gradient admission](native-box-gradient.md) accepts
opaque eligible square-corner fragments outside every opacity scope, using
CPU-prepared pixels and the existing GPU image shader. Unsupported gradients
retain whole-scene CPU fallback; interpolation is not performed on the GPU.

[Image fitting](image-fitting.md) supports `fill`, `contain`, `cover`, `none`,
`scale-down`, and the Images 4 contain/cover plus scale-down pairs in either
order. Physical positions use one, two or four components, supported length
units, signed percentages and the existing additive `calc()` subset. Three
components, logical positions and unsupported math remain rejected. Both
properties start from non-inherited defaults; explicit inheritance, variables
and CSS-wide resets follow the cascade. Invalid later declarations and inline
setters preserve valid earlier values, while invalid variable substitution uses
`unset`. Inline CSSOM keeps its existing serialization format rather than full
canonical computed-value serialization. Loaded image paint is clipped to its
content box; unrepresentable fitted geometry is omitted within existing limits.
Inline SVG and video/poster painting are outside this change. A separate
[identity-sampling fix](image-fitting.md#identity-sampling-follow-up) removes
divide/multiply rounding on image axes whose painted extent exactly equals the
source extent. It applies to the software painter and raster-core source-index
tables, including rasterized inline SVG. Scaled-axis sampling, clipping, alpha
blending and resource limits are unchanged; general image fidelity remains open.

[Native image accounting](native-image-accounting.md) refines the optional GPU
route’s CPU preparation estimate to the clipped image sampling loop. It retains
work at fractional clip edges and conservatively charges transparent, missing
and opacity-suppressed images. The original command/source validation and all
CPU, memory and GPU caps remain in force; other limits can still require whole
frame CPU fallback. The forty-image Page and confined-worker witnesses pass
complete pixel comparisons before and after a real click. A separate initial
scene on one NVIDIA adapter matches a full 1200×900 acquired texture against
Canvas before the compositor. This changes admission accounting, not image
formats, sampling, CSS coverage or measured performance.

Ordinary objects support descriptor defaults, writable/enumerable/configurable checks, getters/setters, reflective descriptor queries and deletion. Enumeration visits own keys and inherited enumerable keys while respecting shadowing. Window descriptor queries expose tracked global bindings, including the CSS namespace, with ordered property-key conversion and current flags/values. The replaceable [Window.self accessor](../tests/conformance/window-self.md) supports assignment, deletion, descriptor restoration and author accessors, with global lexical shadowing kept separate. The [global value properties](../tests/conformance/global-values.md) share this handling: globalThis is initially writable/configurable and nonenumerable; undefined, NaN and Infinity are nonwritable, nonconfigurable and nonenumerable. Replacing globalThis preserves private Window/event identity. [Window binding reflection](../tests/conformance/window-reflection.md) now supports own membership, enumerability and ordered string/symbol key enumeration over the supported bindings. [General Window definitions and global bindings](../tests/conformance/window-global-bindings.md) now share data/accessor records, preserve arbitrary UTF-16 key identity, keep execution receivers private, and validate global function declarations across scripts. Event-handler descriptor/deletion behavior, extensibility, complete interfaces and named-property behavior remain incomplete. Arrays support indexed data/accessor descriptors, writable length, sparse u32 logical lengths and nonextensibility. Length reduction deletes own indices in descending order and preserves partial effects when a nonconfigurable index blocks it. Object and Reflect property definitions share the same array rules. Eleven existing Array methods now use live property operations on supported ordinary array-like receivers. Splice supports same-realm custom species; Number TypedArrays now supply live indexed properties to generic Array operations. Map/filter/slice custom species, Proxy and general host reflection remain incomplete. See [array descriptor coverage](../tests/conformance/array-descriptors.md). The unchanged upstream property-helper harness runs directly; no native test assertion shims replace it.

The complete pinned [global-value inventory](../tests/conformance/test262-global-values.md)
retains 88 variants: 70 pass and 18 require
unsupported eval. All 64 preflights verify, but
the regression gate does not imply complete global-object support.

`Object.prototype.isPrototypeOf` checks internal prototype links and object
identity, with the primitive-argument test preceding receiver conversion. It
observes current prototype mutations without reading author `__proto__` or
constructor properties. Traversal shares the existing work and depth limits;
Proxy traps and complete host prototype behavior remain unsupported. See
[prototype membership](../tests/conformance/is-prototype-of.md) and its
[pinned upstream inventory](../tests/conformance/test262-is-prototype-of.md).

`Array.prototype.sort` implements stable sorting for arrays and supported
ordinary array-like receivers. It distinguishes absent entries from undefined,
includes inherited values, compares default strings as UTF-16 code units, and
uses live author comparators and conversion hooks. Collection and comparison
precede ordered strict writes/deletes; exceptions preserve earlier author and
write-back effects. The [bounded sort implementation](../tests/conformance/array-sort.md)
uses the shared array descriptor rules; Proxy, typed-array and
general host receiver support remain incomplete. Its work/heap limits can stop large inputs.
The [complete pinned sort directory](../tests/conformance/test262-array-sort.md)
now records 91 passed, 12 unsupported and four resource stops across 107 modes.
Array descriptor support enables 32 additional modes.
Adding reduce enables the 5- and 11-element stability tests in both modes;
the unchanged 513- and 2,048-element tests reach the shared work/allocation
limits. No healthy sort baseline is recorded.

`Array.prototype.reduce` and `reduceRight` stream over supported ordinary
array-like receivers. They capture length once, distinguish omitted initial
values from explicit undefined, and read sparse/inherited entries live in the
requested direction. Four callback arguments, actual-callee this behavior and
prior author effects survive through page and event execution. Full safe-integer
logical lengths share existing work/allocation limits without allocating from
length. Actual Array indexed/length descriptors use the same live property paths.
Host receivers and Proxy remain unsupported. Number TypedArray indices now use
the shared live property hooks. See the
[implementation scope](../tests/conformance/array-reduce.md) and
[complete paired upstream inventory](../tests/conformance/test262-array-reduce.md).

Strictness follows exact unescaped directive prologues and lexical function inheritance. Supported code checks restricted names, duplicate simple parameters, legacy literals and identifier deletion; strict calls preserve the supplied `this`, and failed writes/deletes throw. Strict arguments and arguments of functions with defaults or rest parameters are unmapped and have a throwing `callee` accessor; supported sloppy functions with simple parameter lists retain aliases until deletion or descriptor changes detach them. Lexical bindings include initialization checks, declaration conflicts and per-iteration loop environments. This does not implement the complete ECMAScript grammar or all Annex B behaviors. Unsupported dynamic eval, tagged templates and destructured parameters are reported explicitly.

Identifier default parameters run left to right for omitted or undefined values,
with all parameter bindings created before initialization. Initializer closures
retain their parameter scope separately from body declarations; function length,
anonymous names, receiver and arguments behavior have focused checks. Ordinary
functions, arrows, methods and setters share this bounded implementation. See
[default-parameter scope](../tests/conformance/default-parameters.md) and the
[complete upstream function inventory](../tests/conformance/test262-functions.md).

JavaScript identifier names use pinned Unicode 18.0.0 `ID_Start`/`ID_Continue`
data with ECMAScript additions. Raw names and valid four-digit or braced Unicode
escapes resolve to the same binding without normalization. Decoded reserved
words remain invalid as bindings/references; property names accept them, while
keywords and accessor introducers require literal spelling. Numeric adjacency,
RegExp flag boundaries and ECMAScript whitespace use their separate lexical
rules. These changes do not implement classes, modules, private fields,
generators, async execution or Unicode RegExp capture names. See
[identifier scope](../tests/conformance/identifiers.md) and
[data provenance](../tests/conformance/unicode-identifiers-data.md).

Identifier rest parameters create fresh dense arrays from the remaining actual
arguments. Ordinary functions, arrows and concise methods support them; accessors
reject rest. Rest-only functions use unmapped arguments without introducing the
separate body scope needed by defaults. See [rest-parameter scope](../tests/conformance/rest-parameters.md)
and the [complete pinned rest directory](../tests/conformance/test262-rest-parameters.md).

Script exception handling preserves explicitly thrown values and exposes ordinary runtime failures as objects with `name` and `message`. Catch bindings have local scope, and `finally` preserves or overrides returns and loop control. Execution, allocation, nesting, and other resource limits terminate the current script entry without running `catch` or `finally`; these host limits cannot be overridden by page code.

The six [compound bitwise assignments](../tests/conformance/compound-assignment.md)
reuse a single evaluated reference, with ordered getter/RHS/conversion/setter
behavior, strict writes and masked 32-bit shifts. Their complete inventory has
606 passes and 180 unsupported modes.
BigInt behavior remains incomplete; Symbol numeric conversion now throws TypeError.

The three [logical assignments](../tests/conformance/logical-assignment.md)
read their reference once and skip both RHS and write when their condition
does not select assignment. Taken identifier assignments infer names for
anonymous function/arrow expressions; member targets retain unnamed functions.
Strict/readonly/const rules apply only to actual writes. The complete profile
retains 78 passes, six class failures and 48 unsupported modes, with
104 verified controls.

[Declaration traversal](../tests/conformance/scope-walk.md) uses bounded borrowed
ancestor cursors for name collection and hoisting. Switch scopes no longer clone
statement trees. It retains a separate 96-ancestor bound alongside the parser
and ordinary execution continuations. [Declaration-name validation](../tests/conformance/scope-names.md)
now charges temporary records, sorting, comparisons and named diagnostics while
preserving duplicate and scope-conflict behavior.

[Flat executable ownership](../tests/conformance/flat-code.md) stores syntax edges
as typed IDs within immutable shared units. Escaping closures and cross-script
callbacks retain their own units. Token pages avoid relocating the accumulated
token prefix. [Shared execution continuations](../tests/conformance/statement-frames.md)
now cover expressions, references and supported statements, including loops and
try/finally. [Ordinary activation and defaults](../tests/conformance/activation-frames.md)
also use the driver: retained shallow ordinary/default probes now complete 32
calls, with call 33 stopped by the existing logical ceiling. Native callback and
constructor bridges remain guarded. [Direct flat parsing](../tests/conformance/flat-parser.md)
now removes the temporary owning AST and second lowering pass. The parser emits
charged record pages and flat lists, preserving cover grammar, early errors and
lexical rescans. [Grammar continuations](../tests/conformance/parser-continuations.md)
also remove native grammar recursion: both modes of the original 32-nested-IIFE
test now pass within the unchanged compile quotas. The complete functions profile
has 515 passes and 616 unsupported variants and now has a healthy CI baseline.
The retained depth probes parse through 40 and run through 32 calls; declaration
traversal, labels, logical calls and native helpers retain independent limits.

[Labeled break and continue](../tests/conformance/labels.md) resolve ordinary
statement/loop targets, propagate through nested loops and switches, and preserve
finally overrides and function boundaries. The complete three-directory profile
retains 100 passes and 25 unsupported modes, with 80 controls. Legacy labeled
functions remain incomplete. [Statement completion values](../tests/conformance/statement-completion.md)
now distinguish empty results from JavaScript `undefined` through the supported
blocks, branches, loops, switches, labels and try/catch/finally. Dynamic eval,
with, destructuring `for…of` heads and other unsupported statement forms remain gaps.

[Loose equality](../tests/conformance/equality.md) follows ordinary primitive
conversion and Boolean/Number/String dispatch. Null and undefined remain unequal
to false and zero; object identity and nullish comparisons skip conversion hooks.
Strict equality remains noncoercing. All four complete upstream directories
retain 190 passes and 96 unsupported variants, with 128 controls. Exotic values
and HTMLDDA remain gaps.

[Relational comparisons](../tests/conformance/relational.md) convert both operands
in source order before choosing UTF-16 string or numeric ordering. Live hooks,
boxed strings, abrupt completion and unordered NaN are covered. The four complete
upstream directories retain 300 passes and 64 unsupported variants, with 128
controls. BigInt and broader exotic conversions remain incomplete. Symbol conversion hooks and numeric rejection now have separate coverage.

[Ordinary addition](../tests/conformance/addition.md) converts both saved operands
left-to-right before selecting numeric addition or UTF-16 concatenation. Live
valueOf/toString hooks, boxed values, exact exceptions and += reference order are
preserved. The complete addition profile has 67 passes
and 28 unsupported modes, with 64 verified controls. Symbol.toPrimitive now participates in conversion and primitive Symbol addition throws TypeError. BigInt addition remains incomplete; the existing profile policy is unchanged.

Object initializers preserve computed-key evaluation/coercion order, UTF-16 names, method/accessor descriptors and the special static `__proto__` form. Symbol keys and inferred method/accessor names now work. Spread, async/generator methods and `super` remain unsupported; see [object literal coverage](../tests/conformance/object-literals.md).

Array reversal uses bounded ordinary property operations, preserving holes, inherited indices, accessor order and abrupt completion on supported receivers. Number radix formatting adds exact finite safe integers for bases 2–36; nondecimal fractions and larger magnitudes remain explicitly unsupported. See [Array/Number method coverage](../tests/conformance/array-number-methods.md).

All eight Number constants now have their standard values and immutable flags.
Number.isFinite, isNaN, isInteger and isSafeInteger classify primitive numbers
without coercion, including subnormal values, negative zero and rounded large
integers. Saved aliases retain native identity through method/global replacement.
Number and the global isFinite/isNaN functions now perform
[ordinary numeric conversion](../tests/conformance/numeric-conversion.md),
preserving live hooks, receiver identity and abrupt effects. Symbol numeric conversion now throws TypeError; BigInt conversion and general constructor infrastructure remain incomplete.
The global parseInt/parseFloat functions use ordinary string-hint conversion,
and [Number parsing aliases](../tests/conformance/numeric-parsing.md) share
the same intrinsic identities. The
[static builtin scope](../tests/conformance/number-statics.md) and
[complete pinned inventory](../tests/conformance/test262-number-statics.md)
record 260 passes and 80 unsupported variants, with all 104
assertion checks verified.

Untagged template literals support nested substitutions, cooked escapes and multiline text. Each substitution uses string-hint conversion before the next expression executes; tagged templates remain unsupported. See [template literal coverage](../tests/conformance/template-literals.md) and the separate [57-source upstream inventory](../tests/conformance/test262-template-literal.md), which retains 82 passing and 32 unsupported variants.

The four [URI encoding/decoding functions](../tests/conformance/uri.md) preserve
ordinary string conversion, strict percent-encoded UTF-8 and reserved-character
behavior. Encoding rejects lone surrogates; decoding preserves raw unescaped
UTF-16 units and throws URIError for malformed escapes. Complete upstream
coverage retains 234 passes and 112 instruction-limit
stops, with 128 controls. Those stops prevent a healthy URI baseline.

JavaScript strings retain UTF-16 code units, including unpaired surrogates. Length, indexed access, `charAt`, `charCodeAt`, `codePointAt`, `slice`, `substring`, string searches, `match`, `search`, `replace`, string/RegExp `split`, array `join`, trimming, selected case conversion and `String.fromCharCode`/`fromCodePoint` operate on this representation. String-to-number conversion recognizes ECMAScript whitespace and decimal, hexadecimal, binary and octal forms. This is a bounded subset: normalization, locale-sensitive operations, Symbol-based RegExp dispatch/species and complete generic receiver/prototype behavior are absent. Each string is limited to 262,144 code units (512 KiB of backing storage), within the cumulative estimated 8 MiB script allocation budget.

RegExp matching uses a custom parser and an explicit backtracking stack over UTF-16 code units. Captures, empty-match progress, greedy/lazy repetition, named groups, numeric/named backreferences and positive/negative lookahead retain their implemented ECMAScript behavior. Case-insensitive non-Unicode matching follows one-code-unit uppercase canonicalization using Rust’s Unicode tables. Pattern literals use the parser’s expression context to distinguish division. Patterns are limited to 8,192 code units, 4,096 syntax nodes and 128 captures; parser/assertion nesting and repetition counts are also bounded. Compilation, backtracking, native output and callbacks consume bounded work/allocation budgets; a costly pattern can terminate with an uncatchable resource error. Unicode flags `u`/`v`, lookbehind and other listed missing syntax are explicitly unsupported. The separate [RegExp corpus](../tests/conformance/test262-regexp.md) is a narrow measurement, not full RegExp conformance.

Text, Comment and PI data now use [canonical DOM string storage](dom-strings.md):
UTF-8 for scalar strings, exact UTF-16 only when unpaired units occur. Existing
data/length accessors, selected text readers and cloning preserve units from
[JavaScript CharacterData production](dom-production.md),
[Node data assignment](node-data.md), [append arguments](append-domstrings.md),
[Document.title](document-title.md),
the host or transport.
Presentation explicitly replaces unmatched units without changing storage.
Attributes, console output and other scalar host boundaries remain separate;
legacy `innerText`, textarea setters and HTML-parser writes can still
replace unpaired units. Inline JavaScript source and JavaScript HTML serialization explicitly
refuse a nonscalar aggregate. This is not complete DOMString support.

`textarea.value` reads exact stored units with CRLF/CR normalization. Its legacy
script setter, editor and form serializer still use scalar boundaries. Native
editing refuses a nonscalar aggregate, including while an acknowledgement is
pending, so a whole-string edit cannot replace preserved units elsewhere. This
is not the complete HTML current/default/dirty-value model: assigning a value
still changes child/default text, and reset semantics remain incomplete.

HTML foreign-content support includes adjusted SVG names, the defined XLink/XML/XMLNS attribute mappings, MathML text and annotation integration points, foreign CDATA, breakout tokens, and namespace-aware selectors/serialization. The namespace enum is deliberately limited to HTML, SVG and MathML; this is not an XML parser, full SVG DOM, or MathML layout engine. SVG script execution and foreignObject painting remain unsupported.

Fragment parsing initializes tokenizer state, the adjusted current node, insertion mode, document mode, encoding and form pointer from the actual context. Templates own separate hosted document fragments; normal document queries and layout exclude their contents. Template innerHTML, fragment queries/transfer and bounded deep cloning preserve nested template and namespace identity. Host ownership participates in mutation and IPC cycle/depth checks. Synchronous parser scripts, declarative shadow roots and content patching remain unsupported. Retaining quirks mode improves parsing but does not implement all quirks rendering behavior.

Fetched HTML, external CSS and classic scripts now choose encodings using BOM/transport/declaration/context precedence. Late accepted HTML declarations can cause one cached-byte reparse before scripts or subresources; POST requests are not repeated. Document encoding metadata survives IPC and is exposed through the characterSet aliases. This is a bounded whole-body loader, without streaming parser-script interaction or an exhaustive encoding conformance suite; see [encoding behavior](ENCODING.md).

Grid supports explicit signed lines and spans, implicit cyclic tracks, row/column auto-placement with dense packing, separate gaps, minmax/fraction track sizing, spanning intrinsic contributions and item/content alignment. Track, occupancy and shared work limits contain adversarial grids. Named areas/lines, subgrid, full intrinsic sizing and writing-mode interactions remain incomplete; see [Grid coverage](../tests/reftests/grid.md).

Flex columns wrap against a definite available height or resolved maximum height and resolve flexible sizes separately per line. Row and column lines support bounded cross-axis distribution, stretch and wrap-reverse; intrinsic automatic minimums, baseline alignment and writing-mode completeness remain missing. See [flex wrapping coverage](../tests/reftests/flex-wrapping.md).

Physical floats shorten complete line bands, use margin boxes and side-specific clearance, and share or isolate exclusions according to the supported formatting contexts. Six additional pixel pairs and bounded-work regressions cover these cases. Complex margin collapse, intrinsic inline-word sizing and overlapping painting order remain partial; see [float coverage](../tests/reftests/floats.md).

Document URL metadata and the first connected HTML base element now control relative resolution while preserving the committed fetch origin. Frozen base URLs survive fragment navigation and validated snapshots. Linked/inline stylesheets support bounded leading imports, redirected response bases, inherited encoding, media conditions and imported cascade layers. CSS imports retain separate parse boundaries; layer identities and media conditions are structured metadata, so malformed source cannot change them. Anonymous imports share one identity across their constituent source segments. Media queries reevaluate on resize; reported color scheme, motion and pointer values are fixed rather than taken from the operating system. Grouped media conditions and width/height ranges share bounded evaluation on every resize; [media-query coverage](../tests/conformance/media-queries.md) records the exact subset. Dynamic loading, base targets, nested-document fallback and complete CSS Syntax remain incomplete; see [URL and stylesheet loading](STYLESHEET_LOADING.md).

Feature queries use a conservative syntax allowlist for implemented declarations and selectors, grouped Boolean conditions, and conditional imports. False import conditions suppress both fetching and layer registration. JavaScript `CSS.supports` exposes condition and property/value overloads through the same bounded evaluator, with ordered author string conversion and separate property/value parsing. Unsupported syntax can still return false even when some related rendering works; custom properties, escaped values and complete selector/CSS syntax remain incomplete. See the [exact positive inventory and bounds](../tests/conformance/supports.md) and [JavaScript API scope](../tests/conformance/css-supports-api.md).

Custom properties compute on the declaring element before inheritance. Token-aware substitution preserves quoted text, complete comma fallbacks and token boundaries; real function names are case-insensitive while custom names retain case. Selected dependency cycles invalidate their participating values, and unused fallbacks are not evaluated. Empty custom values remain distinct from missing values; empty ordinary substitutions use unset behavior. Dynamic variable names, registered properties, animation taint, complete CSSOM serialization and full ordinary-value parsing remain incomplete. See [custom-property behavior and limits](../tests/conformance/custom-properties.md).

Inline style operations now parse tokens instead of splitting at every semicolon.
They preserve quoted delimiters and escaped custom-name identity, separate
priority from value, and commit attribute text with persistent typed declarations
after author argument conversion. Partial pending-shorthand edits preserve other
components and their later variable resolution across script entries and renders. Supported property aliases agree between lookup, assignment and
`in`; invalid writes and missing-property removals do not rewrite the attribute.
This remains a bounded inline CSSOM subset; [the exact scope](../tests/conformance/cssom-inline.md)
records value grammar, shorthand limitations and serialization gaps.

Computed JavaScript property keys use string-hint conversion. Plain assignment
defers conversion until after its right-hand side; compound assignments and
updates retain the key converted for their read. Null/undefined bases fail
before key conversion. Converted symbol keys retain identity. Proxies and broader missing ECMAScript features remain unsupported.

HTML disclosures keep closed content in the DOM, script/style/resource lifecycle and form serialization while excluding it from paint, hits and native editing. Named groups enforce one open member per ordinary tree. The first direct summary and generated default affordance support activation. Toggle delivery uses bounded host checkpoints, exact reentrant task/tracker cleanup, and native idle continuation; complete HTML event-loop timing remains unsupported. Quota failure suspends automatic notification dispatch until reload. See [disclosure behavior](../tests/conformance/details.md).

Absolute boxes resolve against the nearest positioned ancestor's padding box after normal-flow sizing, skipping intervening static boxes. Relative offsets preserve flow space. Fixed boxes use viewport coordinates for painting and hits and do not extend document scroll height. A bounded stacking pass distinguishes real contexts from auto-z paint groups, reconstructs clip scopes and gives hits the same paint order. Full inline fragmentation, hypothetical static positions, sticky/transform rules remain incomplete. Group opacity composites entire contexts with bounded intermediate surfaces; see [opacity coverage](../tests/reftests/opacity.md). See [positioning coverage](../tests/reftests/positioning.md).

Cascade layers preserve first-declaration order across sources, nested and anonymous identities, reversed important precedence, unlayered/inline ordering and bounded rollback candidates. Layered imports declare their layer even after a failed fetch when their media condition matches. CSSOM layer APIs, complete conditional syntax, origin/animation behavior and several property semantics remain incomplete; see [cascade layer coverage](../tests/conformance/cascade-layers.md).

Events retain private state, snapshot propagation paths and listener inventories, and clean dispatch state on exceptions or resource termination. AbortController and AbortSignal support synchronous trusted abort events, reason identity, throwIfAborted and signal-based listener removal; any/timeout and fetch cancellation remain unsupported. Ordinary listener exceptions are reported while later listeners continue. Native input/change events are non-cancelable; click/submit can cancel their host actions. Readiness remains synchronous. See [event behavior and limitations](../tests/conformance/events.md).

## Conformance path

1. A pinned [WPT HTML tree-construction corpus](../tests/conformance/README.md) now exercises 1,959 inputs in 3,876 scripting-flag modes. Current exact-tree results are 3,868 matched, two unchanged expectation-framing mismatches and six unsupported. All 412 fragment-mode cases match, including template contexts; synchronous parser scripts remain unsupported. Parse-error counts and encoding/quirks mode are not certified. Broad WPT testharness coverage remains to be added. A separate pinned [Test262 selection](../tests/conformance/test262.md) retains 326 unchanged sources and all 652 mode variants: 558 passed and 94 unsupported, with no failed or harness-error modes. Both strict and sloppy variants execute; 32 unchanged-harness/strict-semantics preflights pass. A separate [RegExp inventory](../tests/conformance/test262-regexp.md) retains all 145 sources and 290 variants: 262 passed and 28 unsupported, with 44 preflights and no failures or resource/timeout outcomes. These are selected cases, not a full Test262 pass rate; assertion preflights and previously passing cases gate the runner.
2. Implement the required testharness bindings and WebDriver/session interfaces. This engine currently has neither a full WPT harness nor WebDriver.
3. Track individual test outcomes and expected failures by specification; never substitute a hand-selected fixture pass rate for platform-wide conformance.
4. Expand parsing/tree-building before judging rendering failures; then extend CSS used values, layout algorithms, text, and the script language/runtime.
5. Reproduce regressions with reduced fixtures and retain them in the suite.

Normative starting points: [HTML parsing](https://html.spec.whatwg.org/multipage/parsing.html), [DOM](https://dom.spec.whatwg.org/), [CSS visual formatting](https://www.w3.org/TR/CSS2/visuren.html), [ECMAScript](https://tc39.es/ecma262/), and [SVG 2](https://www.w3.org/TR/SVG2/). The included implementation is far short of these complete specifications.
