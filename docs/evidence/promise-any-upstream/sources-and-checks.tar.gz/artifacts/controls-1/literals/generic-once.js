assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var result = {}, first = {}, second = {}, rejects = 0, resolves = 0;
var callbacks = [], resolveCallbacks = [], aggregate;
function sharedResolve(value) { resolves++; return 'R' + value; }
function C(executor) {
  executor(sharedResolve, function (error) { rejects++; aggregate = error; return 'rejected'; });
  return result;
}
C.resolve = function (value) {
  return {then: function (fulfill, reject) {
    resolveCallbacks.push(fulfill);
    callbacks.push(reject);
    assert.sameValue(fulfill, sharedResolve);
    assert.sameValue(fulfill(value), 'R' + value);
    if (value === 1) {
      assert.sameValue(reject(first), undefined);
      assert.sameValue(reject({}), undefined);
    }
    assert.sameValue(rejects, 0);
  }};
};
assert.sameValue(Promise.any.call(C, [1, 2]), result);
assert.sameValue(resolves, 2);
assert.sameValue(rejects, 0);
assert.sameValue(resolveCallbacks[0], resolveCallbacks[1]);
assert.notSameValue(callbacks[0], callbacks[1]);
assert.sameValue(callbacks[1](second), 'rejected');
assert.sameValue(callbacks[1]({}), undefined);
assert.sameValue(callbacks[0]({}), undefined);
assert.sameValue(rejects, 1);
assert.sameValue(Object.getPrototypeOf(aggregate), AggregateError.prototype);
assert.compareArray(aggregate.errors, [first, second]);
