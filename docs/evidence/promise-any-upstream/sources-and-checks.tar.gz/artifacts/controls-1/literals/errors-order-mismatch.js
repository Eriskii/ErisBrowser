assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var first = {}, second = {}, rejectFirst, rejectSecond;
var a = new Promise(function (resolve, reject) { rejectFirst = reject; });
var b = new Promise(function (resolve, reject) { rejectSecond = reject; });
Promise.any([a, b]).then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (error) {
  assert.sameValue(Object.getPrototypeOf(error), AggregateError.prototype);
  assert.sameValue(Object.getPrototypeOf(error.errors), Array.prototype);
  assert.sameValue(error.errors.length, 2);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error.errors, '0'), true);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error.errors, '1'), true);
  assert.compareArray(error.errors, [second, first]);
}).then($DONE, $DONE);
rejectSecond(second);
rejectFirst(first);
