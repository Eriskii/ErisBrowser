assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var rejected = {}, first = {}, later = {};
Promise.any([Promise.reject(rejected), Promise.resolve(first), Promise.resolve(later)]).then(function (value) {
  assert.sameValue(value, later);
}).then($DONE, $DONE);
