assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var method = Promise.any;
verifyProperty(Promise, 'any', {value: method, writable: true, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'name', {value: 'any', writable: false, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'length', {value: 1, writable: false, enumerable: false, configurable: true}, {restore: true});
assert.sameValue(isConstructor(function () {}), true);
assert.sameValue(isConstructor(method), false);
assert.throws(TypeError, function () { new method([]); });
