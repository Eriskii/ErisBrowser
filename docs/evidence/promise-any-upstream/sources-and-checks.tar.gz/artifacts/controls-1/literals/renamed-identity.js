assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var A = AggregateError, calls = 0, firstError;
Object.defineProperty(A, 'name', {value: 'RenamedAggregateError', writable: false, enumerable: false, configurable: true});
function C(executor) {
  executor(function () { throw new Test262Error('unexpected resolution'); }, function (error) {
    calls++;
    assert.sameValue(Object.getPrototypeOf(error), A.prototype);
    assert.sameValue(error.errors.length, 0);
    if (calls === 1) { firstError = error; throw error; }
    assert.sameValue(calls, 2);
    assert.sameValue(error, firstError);
    throw error;
  });
}
C.resolve = function (value) { return value; };
Promise.any.call(C, []);
throw new Test262Error('expected escaped AggregateError');
