assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var fake = Object.create(AggregateError.prototype);
throw fake;
