assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var Fake = function AggregateError() {};
var fake = {constructor: Fake};
throw fake;
