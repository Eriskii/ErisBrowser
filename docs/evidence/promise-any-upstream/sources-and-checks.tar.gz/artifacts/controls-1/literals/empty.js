assert.sameValue(typeof Promise.any, 'function');
assert.sameValue(typeof AggregateError, 'function');
var sync = true;
Promise.any([]).then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (error) {
  assert.sameValue(sync, false);
  assert.sameValue(Object.getPrototypeOf(error), AggregateError.prototype);
  assert.sameValue(Object.getPrototypeOf(error.errors), Array.prototype);
  assert.sameValue(error.errors.length, 0);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error, 'message'), false);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error, 'cause'), false);
  var descriptor = Object.getOwnPropertyDescriptor(error, 'errors');
  assert.sameValue(descriptor.value, error.errors);
  assert.sameValue(descriptor.writable, true);
  assert.sameValue(descriptor.enumerable, false);
  assert.sameValue(descriptor.configurable, true);
}).then($DONE, $DONE);
sync = false;
