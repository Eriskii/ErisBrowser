from pathlib import Path
import ast,difflib,hashlib,json
N=Path('/tmp/eris-promise-any-upstream-plan-1');D=N/'controls-1';W=N/'worktree'
def binding(p):return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
def write(name,j):(D/name).write_text(json.dumps(j,indent=2)+'\n')
contract=json.loads((D/'literal-contract.json').read_text());oracle=json.loads((D/'raw/tools/promise-any-controls-oracle.json').read_text())
payload=D/'payload/any-preflight.py';tree=ast.parse(payload.read_text());fn=tree.body[0]
assert ast.literal_eval(fn.body[1].value)==oracle['variants']
assert len(oracle['records'])==102
assert oracle['common_variants']==contract['common_variants']
for row in contract['variants']:
 assert (D/'literals'/f'{row["name"]}.js').read_text()==row['source']
 assert hashlib.sha256(row['source'].encode()).hexdigest()==row['source_sha256']
helpers=[]
for name,row in oracle['helpers'].items():
 p=N/'importer-1/corpus-raw/harness'/name
 assert (p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest())==(row['bytes'],row['sha256'])
 helpers.append(binding(p))
test=D/'raw/tools/test_test262_promise_any_controls.py';t=ast.parse(test.read_text());tests=[n.name for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(tests)==12
sha=hashlib.sha256((D/'raw/tools/promise-any-controls-oracle.json').read_bytes()).hexdigest();assert f"ORACLE_SHA = '{sha}'" in test.read_text()
files=[]
for rel in ['tools/test_test262_promise_any_controls.py','tools/promise-any-controls-oracle.json']:
 p=D/'raw'/rel;q=D/'diffs'/(rel+'.patch');q.parent.mkdir(parents=True,exist_ok=True)
 q.write_text(''.join(difflib.unified_diff([],p.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+rel)))
 files.append(dict(path=rel,before=None,raw=binding(p),diff=binding(q)))
write('test-roster.json',dict(groups=12,tests=tests,parent_prediction={'passed':['test_common_74_sources_fingerprints_and_prerequisite_records_remain_exact'],'requires_new_seams_or_profile_dispatch':11},qualification='Prediction assumes the authenticated Any corpus and frozen new test files are present. No test was executed. Mock records are prospective gate fixtures, not engine outcomes.',coverage=['exact literals and102 fingerprints','common74 exact source/prerequisite records','Any-context composition','missing/duplicate/extra/forged records','malformed/unhashable nested data','raw schema and completion semantics','genuine/renamed/fake identity isolation','same-mode positive dependency failures','canonical prerequisite fields/order','changed/missing helper bindings','independent selected-context reclassification','main blocks dispatch and baseline creation']))
write('integration.json',dict(payload=binding(payload),insert='Append these seven functions before check_baseline; no existing body is replaced.',functions=[n.name for n in tree.body if isinstance(n,ast.FunctionDef)],requires=['PROMISE_ANY_PROFILE','PROMISE_ANY_FEATURES','Any-only keyword context for classify/validate_promise_observation/promise_preflight_verified','harness_preflight dispatch to promise_any_harness_preflight','main health dispatch promise_any_preflight_healthy(preflight,files)'],preserve='Old builders/gates/37 variants and policy/transport/classification bodies remain unchanged except separately selected Any-only identity seams.',new_gate='Exact canonical102 row union; strict result/prerequisite schemas, hashes and helper-derived identities; raw validation; reclassification; own identity expectations; recursive same-mode prerequisite health; forged verified flags never suffice.',message_scope='Identity rows freeze all seven raw fields. New nonidentity synchronous mismatch diagnostics remain bounded opaque text; exact error type/identity/completion/classification are enforced. Common74 retains its exact prior expectation verifier, with fresh canonical identity and raw-schema/reclassification checks.',trusted_context='A schema-valid known private identity is trusted adapter data. These controls do not authenticate an adversarial/compromised adapter.'))
write('checks.json',dict(status='source/data checks passed; no project execution',literal_factory_ast_equal=True,common37_exact=True,rows102=True,helpers6_exact_to_authenticated_new_corpus=helpers,tests12_ast_parsed=True,oracle_hash_embedded=True,source_fingerprint_algorithm='Independent stdlib SHA256 of sorted ensure_ascii JSON identity; selected source/helper/mode/metadata/completion policy included.',parent_inputs=[binding(W/'tools/test262_conformance.py'),binding(W/'tools/promise-methods-runner-oracle.json'),binding(N/'source-parent.json'),binding(N/'root/selection-1.json'),binding(N/'identity-plan-1/source-ready.json'),binding(N/'identity-review-1/review.json')]))
members=[binding(p) for p in sorted(D.rglob('*')) if p.is_file() and p.name!='source-ready.json']
write('source-ready.json',dict(status='sealed independent Any controls/gate/tests external hold; no project execution',base=contract['base'],literal_hold=binding(D/'literal-ready.json'),payload=binding(payload),new_test_files=files,oracle=binding(D/'raw/tools/promise-any-controls-oracle.json'),roster=binding(D/'test-roster.json'),integration=binding(D/'integration.json'),checks=binding(D/'checks.json'),migration_census=binding(D/'migration-census.json'),members=members,scope='102 controls,12 unit groups, old74 preserved; no live edits or engine outcomes. Script integrates selected APIs; root alone imports/runs.'))
print(binding(D/'source-ready.json'))
