from pathlib import Path
import hashlib,json
D=Path('/tmp/eris-promise-any-upstream-plan-1/controls-1')
contract=json.loads((D/'literal-contract.json').read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
def observation(row):
 if row.get('required_observation') is not None:return row['required_observation']
 expected,policy=row['expected'],row['completion_policy']
 counts=(1,1,0) if policy else (0,0,0)
 e=dict(policy=policy,done_calls=counts[0],success_prints=counts[1],failure_prints=counts[2],flags=0,quiescent=True,audited=True,unhandled=0)
 o=dict(status='complete',phase='runtime',error_type='',error_identity='',message='',harness='',completion=e)
 if expected=='synchronous-exception':o.update(status='exception',error_type='Test262Error',message='marker');e['flags']=256
 elif expected=='resource':o.update(status='resource',error_type='ResourceLimit',message='marker');e.update(flags=264,quiescent=False,audited=False)
 elif expected!='passed':
  o.update(status='host-failure',phase='host',message=expected)
  if expected=='completion-error':
   e.update(success_prints=0,failure_prints=1,flags=1)
   if row['name']=='truthy-error-getter-abrupt':e.update(failure_prints=0,flags=65)
  elif expected=='missing-completion':e.update(done_calls=0,success_prints=0)
  elif expected=='duplicate-completion':e.update(done_calls=2,success_prints=2)
  elif expected=='queued-exception':e['flags']=4
  elif expected=='unhandled-rejection':e['unhandled']=1
  elif expected=='unauthenticated-completion':e.update(done_calls=0,success_prints=0,flags=16)
  elif expected=='completion-protocol-error':e['success_prints']=0
  else:raise AssertionError(expected)
 return o
common=contract['common_variants'];variants=contract['variants'];records=[]
helpers={k:dict(bytes=v['bytes'],sha256=v['sha256']) for k,v in contract['helpers'].items()}
for selected,prefix in ((common,'promise-methods-'),(variants,'promise-any-')):
 for mode in ['sloppy','strict']:
  for row in selected:
   name=prefix+row['name'];policy=row['completion_policy']
   required=[]
   if prefix=='promise-methods-':
    if row['prerequisite']:required.append('promise-methods-'+row['prerequisite'])
    if row['origin']=='original-literal':
     required += ['promise-methods-'+r['name'] for r in common if r['origin']=='new-prerequisite']
     if row['name']!='one-async-completion':required.append('promise-methods-one-async-completion')
   else:
    required=['promise-methods-'+r['name'] for r in common]
    if row['name']!='api':required.append('promise-any-api')
    if row['prerequisite'] and 'promise-any-'+row['prerequisite'] not in required:required.append('promise-any-'+row['prerequisite'])
   metadata=dict(flags=['async'] if policy else [],includes=row['includes'],features=[],locale=[],negative=None)
   hn=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+row['includes']
   source_sha=sha(row['source'].encode()); harness=[dict(name=n,sha256=helpers[n]['sha256']) for n in hn]
   identity=dict(source_sha256=source_sha,mode=mode,metadata=metadata,harness=harness,completion_policy=policy)
   case_sha=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
   records.append(dict(name=name,mode=mode,id='harness-preflight:'+name,file='<preflight>',metadata=metadata,
     source=row['source'],source_sha256=source_sha,case_sha256=case_sha,harness=harness,completion_policy=policy,
     expected=row['expected'],prerequisites=[[n,mode] for n in required],mock_observation=observation(row)))
assert len(records)==102
for row in variants:row.pop('source_sha256')
j=dict(schema=1,status='frozen independent prospective oracle; mock observations are not execution results',base=contract['base'],profile='promise-any',
 variants=variants,common_variants=common,helpers=helpers,records=records,
 counts=dict(common=74,new=28,total=102),source_contract_sha256=sha((D/'literal-contract.json').read_bytes()),
 derivation='Only stdlib literal/source/hash data processing. No candidate functions imported or executed. Case identities recomputed directly from documented JSON fingerprint schema and pinned helper hashes.')
p=D/'raw/tools/promise-any-controls-oracle.json';p.write_text(json.dumps(j,indent=2)+'\n');print(sha(p.read_bytes()),len(p.read_bytes()))
