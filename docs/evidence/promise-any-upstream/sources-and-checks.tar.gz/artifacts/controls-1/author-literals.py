from pathlib import Path
import ast, hashlib, json
N=Path('/tmp/eris-promise-any-upstream-plan-1'); D=N/'controls-1'; W=N/'worktree'
def digest(b): return hashlib.sha256(b).hexdigest()
def binding(p): return dict(path=str(p),bytes=p.stat().st_size,sha256=digest(p.read_bytes()))
def write(p,j): p.write_text(json.dumps(j,indent=2,ensure_ascii=True)+'\n')
guard="assert.sameValue(typeof Promise.any, 'function');\nassert.sameValue(typeof AggregateError, 'function');\n"
rows=[]
def add(name,body,expected='passed',policy=0,includes=(),prerequisite=None,raw=None):
 source=guard+body
 rows.append(dict(name=name,source=source,source_sha256=digest(source.encode()),expected=expected,
 completion_policy=policy,includes=list(includes),origin='promise-any-control',prerequisite=prerequisite,
 required_observation=raw))
 (D/'literals'/f'{name}.js').write_text(source)
api="""var method = Promise.any;
verifyProperty(Promise, 'any', {value: method, writable: true, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'name', {value: 'any', writable: false, enumerable: false, configurable: true}, {restore: true});
verifyProperty(method, 'length', {value: 1, writable: false, enumerable: false, configurable: true}, {restore: true});
assert.sameValue(isConstructor(function () {}), true);
assert.sameValue(isConstructor(method), false);
assert.throws(TypeError, function () { new method([]); });
"""
add('api',api,includes=('propertyHelper.js','isConstructor.js'))
add('api-mismatch',"Promise.any = function any(value) {};\n"+api,'synchronous-exception',includes=('propertyHelper.js','isConstructor.js'),prerequisite='api')
winner="""var rejected = {}, first = {}, later = {};
Promise.any([Promise.reject(rejected), Promise.resolve(first), Promise.resolve(later)]).then(function (value) {
  assert.sameValue(value, first);
}).then($DONE, $DONE);
"""
add('winner',winner,policy=1)
add('winner-mismatch',winner.replace('value, first','value, later'),'completion-error',1,prerequisite='winner')
order="""var first = {}, second = {}, rejectFirst, rejectSecond;
var a = new Promise(function (resolve, reject) { rejectFirst = reject; });
var b = new Promise(function (resolve, reject) { rejectSecond = reject; });
Promise.any([a, b]).then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (error) {
  assert.sameValue(Object.getPrototypeOf(error), AggregateError.prototype);
  assert.sameValue(Object.getPrototypeOf(error.errors), Array.prototype);
  assert.sameValue(error.errors.length, 2);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error.errors, '0'), true);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error.errors, '1'), true);
  assert.compareArray(error.errors, [first, second]);
}).then($DONE, $DONE);
rejectSecond(second);
rejectFirst(first);
"""
add('errors-order',order,policy=1)
add('errors-order-mismatch',order.replace('[first, second]','[second, first]'),'completion-error',1,prerequisite='errors-order')
empty="""var sync = true;
Promise.any([]).then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (error) {
  assert.sameValue(sync, false);
  assert.sameValue(Object.getPrototypeOf(error), AggregateError.prototype);
  assert.sameValue(Object.getPrototypeOf(error.errors), Array.prototype);
  assert.sameValue(error.errors.length, 0);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error, 'message'), false);
  assert.sameValue(Object.prototype.hasOwnProperty.call(error, 'cause'), false);
  var descriptor = Object.getOwnPropertyDescriptor(error, 'errors');
  assert.sameValue(descriptor.value, error.errors);
  assert.sameValue(descriptor.writable, true);
  assert.sameValue(descriptor.enumerable, false);
  assert.sameValue(descriptor.configurable, true);
}).then($DONE, $DONE);
sync = false;
"""
add('empty',empty,policy=1)
add('empty-mismatch',empty.replace('error.errors.length, 0','error.errors.length, 1'),'completion-error',1,prerequisite='empty')
generic="""var result = {}, first = {}, second = {}, rejects = 0, resolves = 0;
var callbacks = [], resolveCallbacks = [], aggregate;
function sharedResolve(value) { resolves++; return 'R' + value; }
function C(executor) {
  executor(sharedResolve, function (error) { rejects++; aggregate = error; return 'rejected'; });
  return result;
}
C.resolve = function (value) {
  return {then: function (fulfill, reject) {
    resolveCallbacks.push(fulfill);
    callbacks.push(reject);
    assert.sameValue(fulfill, sharedResolve);
    assert.sameValue(fulfill(value), 'R' + value);
    if (value === 1) {
      assert.sameValue(reject(first), undefined);
      assert.sameValue(reject({}), undefined);
    }
    assert.sameValue(rejects, 0);
  }};
};
assert.sameValue(Promise.any.call(C, [1, 2]), result);
assert.sameValue(resolves, 2);
assert.sameValue(rejects, 0);
assert.sameValue(resolveCallbacks[0], resolveCallbacks[1]);
assert.notSameValue(callbacks[0], callbacks[1]);
assert.sameValue(callbacks[1](second), 'rejected');
assert.sameValue(callbacks[1]({}), undefined);
assert.sameValue(callbacks[0]({}), undefined);
assert.sameValue(rejects, 1);
assert.sameValue(Object.getPrototypeOf(aggregate), AggregateError.prototype);
assert.compareArray(aggregate.errors, [first, second]);
"""
add('generic-once',generic)
add('generic-once-mismatch',generic.replace('assert.sameValue(rejects, 1);','assert.sameValue(rejects, 2);'),'synchronous-exception',prerequisite='generic-once')
def identity_raw(name,identity):
 return dict(status='exception',phase='runtime',error_type=name,error_identity=identity,
 message='uncaught exception: [object Object]',harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=256,quiescent=True,audited=True,unhandled=0))
genuine="""var A = AggregateError, calls = 0, firstError;
function C(executor) {
  executor(function () { throw new Test262Error('unexpected resolution'); }, function (error) {
    calls++;
    assert.sameValue(Object.getPrototypeOf(error), A.prototype);
    assert.sameValue(error.errors.length, 0);
    if (calls === 1) { firstError = error; throw error; }
    assert.sameValue(calls, 2);
    assert.sameValue(error, firstError);
    throw error;
  });
}
C.resolve = function (value) { return value; };
Promise.any.call(C, []);
throw new Test262Error('expected escaped AggregateError');
"""
add('genuine-identity',genuine,'identity-exception',prerequisite='empty',raw=identity_raw('AggregateError','AggregateError'))
renamed=genuine.replace('var A = AggregateError, calls = 0, firstError;','var A = AggregateError, calls = 0, firstError;\nObject.defineProperty(A, \'name\', {value: \'RenamedAggregateError\', writable: false, enumerable: false, configurable: true});')
add('renamed-identity',renamed,'identity-exception',prerequisite='genuine-identity',raw=identity_raw('RenamedAggregateError','AggregateError'))
add('fake-own-constructor',"function AggregateError() {}\nvar fake = {constructor: AggregateError};\nthrow fake;\n",'identity-exception',prerequisite='genuine-identity',raw=identity_raw('AggregateError',''))
# A function declaration named AggregateError would be hoisted over the guard; use a
# named function expression in a local variable to keep the availability guard real.
rows.pop(); (D/'literals/fake-own-constructor.js').unlink()
add('fake-own-constructor',"var Fake = function AggregateError() {};\nvar fake = {constructor: Fake};\nthrow fake;\n",'identity-exception',prerequisite='genuine-identity',raw=identity_raw('AggregateError',''))
add('fake-prototype',"var fake = Object.create(AggregateError.prototype);\nthrow fake;\n",'identity-exception',prerequisite='genuine-identity',raw=identity_raw('AggregateError',''))
assert len(rows)==14
common=json.loads((W/'tools/promise-methods-runner-oracle.json').read_bytes())['controls']
module=ast.parse((W/'tools/test262_conformance.py').read_text())
f=next(x for x in module.body if isinstance(x,ast.FunctionDef) and x.name=='promise_preflight_variants')
assert ast.literal_eval(f.body[1].value)==common
helpers={}
for name in ['assert.js','sta.js','doneprintHandle.js','isConstructor.js','promiseHelper.js','propertyHelper.js']:
 p=W/'tests/upstream/test262-promise-all-settled/harness'/name
 helpers[name]=binding(p)
write(D/'literal-contract.json',dict(status='frozen prospective controls, not observations',profile='promise-any',base='90c653d813feb62d1d569864bec076c0cc92d8a5',
 count=dict(common_variants=37,common_rows=74,new_variants=14,new_rows=28,total_rows=102),modes=['sloppy','strict'],variants=rows,
 common_variants=common,helpers=helpers,common_oracle=binding(W/'tools/promise-methods-runner-oracle.json'),
 prerequisites='Old common required lists and identities unchanged. Every new row requires all 37 same-mode common rows. All new rows except api additionally require same-mode api. Explicit pair/identity prerequisites append if not already present.',
 identity_rule='Exact complete raw identity observations; known wire identity is trusted adapter data, not cryptographic engine proof.',
 mismatch_rule='Only API constructibility substitution, winner identity, errors order, empty length, or final reject count changes; pair-positive and common/helper prerequisites prevent incidental error false passes.',
 diagnostics='New synchronous Test262Error messages are deliberately unconstrained bounded diagnostics; complete raw schema, identity, exact completion evidence and classification are checked. Async mismatches require authenticated completion-error, not serialized Test262Error.',
 source_bindings=[binding(W/'src/script/throw_metadata.rs'),binding(W/'src/script.rs'),binding(W/'src/script/machine/statements.rs'),binding(W/'src/bin/eris-js.rs'),binding(W/'tools/test262_conformance.py'),binding(N/'identity-plan-1/raw-control-matrix.json'),binding(N/'identity-review-1/review.json')]))
write(D/'literal-ready.json',dict(status='frozen before execution/runner implementation',contract=binding(D/'literal-contract.json'),files=[binding(D/'literals'/f'{r["name"]}.js') for r in rows],author=binding(D/'author-literals.py'),execution='stdlib source/AST/hash only; no project code execution or live edit'))
print(binding(D/'literal-ready.json'))
