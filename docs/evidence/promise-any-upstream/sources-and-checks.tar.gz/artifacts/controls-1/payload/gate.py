def promise_any_preflight_cases(files):
    """Canonical new-profile rows; the original74 case identities stay exact."""
    common = promise_preflight_variants()
    selected = promise_any_preflight_variants()
    definitions = []
    common_names = ['promise-methods-' + row['name'] for row in common]
    for rows, prefix in ((common, 'promise-methods-'), (selected, 'promise-any-')):
        for mode in ('sloppy', 'strict'):
            for held in rows:
                policy = held['completion_policy']
                row = dict(held, name=prefix + held['name'])
                if prefix == 'promise-methods-':
                    required = []
                    if held['prerequisite']:
                        required.append('promise-methods-' + held['prerequisite'])
                    if held['origin'] == 'original-literal':
                        required.extend('promise-methods-' + item['name'] for item in common
                                        if item['origin'] == 'new-prerequisite')
                        if held['name'] != 'one-async-completion':
                            required.append('promise-methods-one-async-completion')
                else:
                    required = common_names.copy()
                    if held['name'] != 'api':
                        required.append('promise-any-api')
                    if held['prerequisite']:
                        prerequisite = 'promise-any-' + held['prerequisite']
                        if prerequisite not in required:
                            required.append(prerequisite)
                row['prerequisites'] = [(name, mode) for name in required]
                names = ['assert.js', 'sta.js'] + (['doneprintHandle.js'] if policy else []) + held['includes']
                case = dict(id='harness-preflight:' + row['name'], file='<preflight>', mode=mode,
                            metadata=dict(flags=['async'] if policy else [], includes=held['includes'],
                                          features=[], locale=[], negative=None),
                            source=held['source'].encode(),
                            harness=[(name, files['harness/' + name]) for name in names],
                            completion_policy=policy)
                case['case_sha256'] = case_fingerprint(case)
                definitions.append((row, case))
    return definitions


def promise_any_preflight_reference(row, case):
    return dict(name=row['name'], mode=case['mode'], verified=True,
                case_sha256=case['case_sha256'], source_sha256=digest(case['source']))


def promise_any_preflight_checks(outcomes, files):
    """Check canonical nested identities, raw evidence and classification afresh."""
    try:
        definitions = promise_any_preflight_cases(files)
        if not isinstance(outcomes, list) or len(outcomes) != 102 or len(definitions) != 102:
            return None
        canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
        if len(canonical) != 102:
            return None
        observed = {}
        for item in outcomes:
            if (not isinstance(item, dict)
                    or set(item) != {'name', 'expected', 'verified', 'result', 'prerequisites'}
                    or not isinstance(item['name'], str)
                    or not isinstance(item['expected'], str)
                    or type(item['verified']) is not bool
                    or not isinstance(item['result'], dict)
                    or not isinstance(item['result'].get('mode'), str)
                    or not isinstance(item['prerequisites'], list)):
                return None
            identity = (item['name'], item['result']['mode'])
            if identity in observed or identity not in canonical:
                return None
            observed[identity] = item
        if observed.keys() != canonical.keys():
            return None
        raw_checks = {}
        for identity, (row, case) in canonical.items():
            item, result = observed[identity], observed[identity]['result']
            expected_status = ('passed' if row['expected'] == 'passed' else
                               'resource' if row['expected'] == 'resource' else 'failed')
            expected_result = {key: case[key] for key in ('id', 'file', 'mode', 'case_sha256')}
            expected_result.update(source_sha256=digest(case['source']),
                                   expected_negative=case['metadata']['negative'], status=expected_status)
            expected_prerequisites = [promise_any_preflight_reference(*canonical[key])
                                      for key in row['prerequisites']]
            prerequisites = item['prerequisites']
            good = (item['expected'] == row['expected']
                    and set(result) == set(expected_result) | {'observation'}
                    and all(result.get(key) == value for key, value in expected_result.items())
                    and len(prerequisites) == len(expected_prerequisites)
                    and all(isinstance(ref, dict)
                            and set(ref) == {'name', 'mode', 'verified', 'case_sha256', 'source_sha256'}
                            and type(ref.get('verified')) is bool
                            and all(isinstance(ref.get(key), str) for key in
                                    ('name', 'mode', 'case_sha256', 'source_sha256'))
                            for ref in prerequisites)
                    and prerequisites == expected_prerequisites
                    and isinstance(result.get('observation'), dict))
            if good:
                observation = result['observation']
                try:
                    validate_promise_observation(observation, profile=PROMISE_ANY_PROFILE)
                    good = (observation['completion']['policy'] == case['completion_policy']
                            and classify(case, observation, profile=PROMISE_ANY_PROFILE) == expected_status)
                    if row['expected'] == 'identity-exception':
                        good = good and observation == row['required_observation']
                    else:
                        good = good and promise_preflight_verified(
                            case, result, row['expected'], profile=PROMISE_ANY_PROFILE)
                        # New successful/mismatched semantic rows freeze completion
                        # counters and flags, without freezing diagnostic messages.
                        if good and row['name'].startswith('promise-any-'):
                            policy = case['completion_policy']
                            counts = (1, 1, 0) if policy else (0, 0, 0)
                            flags = 0
                            if row['expected'] == 'synchronous-exception':
                                flags = 256
                            elif row['expected'] == 'completion-error':
                                counts, flags = (1, 0, 1), 1
                            good = observation['completion'] == dict(
                                policy=policy, done_calls=counts[0], success_prints=counts[1],
                                failure_prints=counts[2], flags=flags,
                                quiescent=True, audited=True, unhandled=0)
                except (KeyError, TypeError, ValueError):
                    good = False
            raw_checks[identity] = good
        checked, visiting = {}, set()

        def healthy(identity):
            if identity in checked:
                return checked[identity]
            if identity in visiting:
                return False
            visiting.add(identity)
            row, _ = canonical[identity]
            value = raw_checks[identity] and all(healthy(key) for key in row['prerequisites'])
            visiting.remove(identity)
            checked[identity] = value
            return value

        for identity in canonical:
            healthy(identity)
        return checked
    except (KeyError, TypeError, ValueError):
        return None


def promise_any_preflight_healthy(outcomes, files):
    checks = promise_any_preflight_checks(outcomes, files)
    return (checks is not None and len(checks) == 102 and all(checks.values())
            and all(item['verified'] is True for item in outcomes))


def promise_any_harness_preflight(files, binary, timeout):
    definitions = promise_any_preflight_cases(files)
    canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
    outcomes = []
    for row, case in definitions:
        result = run_case(case, binary, timeout, PROMISE_ANY_FEATURES, PROMISE_ANY_PROFILE)
        prerequisites = [promise_any_preflight_reference(*canonical[key])
                         for key in row['prerequisites']]
        outcomes.append(dict(name=row['name'], expected=row['expected'], verified=False,
                             result=result, prerequisites=prerequisites))
    checks = promise_any_preflight_checks(outcomes, files)
    if checks is not None:
        for item in outcomes:
            item['verified'] = checks[(item['name'], item['result']['mode'])]
            for prerequisite in item['prerequisites']:
                prerequisite['verified'] = checks[(prerequisite['name'], prerequisite['mode'])]
    return outcomes
