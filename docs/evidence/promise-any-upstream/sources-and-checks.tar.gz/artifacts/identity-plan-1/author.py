"""Author external source-only planning data; never import project modules."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess

H=Path(__file__).resolve().parent
P=H.parent
N=Path('/tmp/eris-promise-any-runtime-plan-1')
W=N/'worktree'
BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
    b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p): return json.loads(p.read_text())
def put(name,value):
    p=H/name; assert not p.exists(); p.write_text(json.dumps(value,indent=2)+'\n')

selected=read(N/'source-final-2.json')['source_sha256']
relative=[
    'tools/test262_conformance.py','tools/import_test262.py',
    'tools/test_test262_async_host.py','tools/test_test262_promise_runner.py',
    'tools/test_test262_promise_all_profile.py','tools/test_test262_promise_race_profile.py',
    'tools/test_test262_promise_all_settled_profile.py',
    'tools/test_test262_aggregate_error_preservation.py',
    'tools/test_test262_aggregate_error_profile.py',
    'tools/aggregate-error-preservation-oracle.json',
    'src/bin/eris-js.rs','src/bin/eris-js/test262_host.rs',
    'src/script.rs','src/script/throw_metadata.rs','src/script/aggregate_error.rs',
]
sources=[]
for r in relative:
    p=W/r; b=p.read_bytes(); assert sha(b)==selected[r]
    row=dict(relative=r,**bind(p))
    if r.startswith('tools/') or r.startswith('src/bin/') or r=='src/script/throw_metadata.rs':
        old=subprocess.check_output(['git','show',BASE+':'+r],cwd=W)
        assert old==b,r
        row['published_base_exact']=BASE
    else:
        row['lineage']='Current selected runtime candidate2, publication refresh pending; no assertion that this changed Rust file equals the older published base.'
    sources.append(row)
runner=(W/'tools/test262_conformance.py').read_text()
tree=ast.parse(runner)
function_names={
    'profile_intrinsic_errors','unsupported_reason','encode_request','decode_response','classify','run_case',
    'promise_completion_passes','validate_promise_observation','decode_promise_response','classify_promise',
    'promise_preflight_verified','promise_host_reason','promise_preflight_variants',
    'promise_harness_preflight','promise_preflight_healthy','promise_all_harness_preflight',
    'promise_all_preflight_healthy','promise_race_harness_preflight','promise_race_preflight_healthy',
    'promise_all_settled_harness_preflight','promise_all_settled_preflight_healthy',
    'aggregate_error_preflight_checks','aggregate_error_harness_preflight','main',
}
functions=[]
for node in tree.body:
    if isinstance(node,ast.FunctionDef) and node.name in function_names:
        text=''.join(runner.splitlines(keepends=True)[node.lineno-1:node.end_lineno])
        functions.append(dict(name=node.name,line=node.lineno,end_line=node.end_lineno,
            bytes=len(text.encode()),sha256=sha(text.encode()),signature=ast.unparse(node.args),
            calls=[dict(function=ast.unparse(x.func),line=x.lineno,positionals=len(x.args),keywords=[k.arg for k in x.keywords])
                   for x in ast.walk(node) if isinstance(x,ast.Call) and isinstance(x.func,ast.Name)
                   and x.func.id in function_names]))
assert len(functions)==len(function_names)
put('source-bindings.json',dict(source_base=BASE,publication_refresh_pending=True,
    selected_candidate=bind(N/'source-final-2.json'),sources=sources,functions=functions,
    source_only=True,project_code_imported=False))

old_oracle=read(W/'tools/aggregate-error-preservation-oracle.json')['old_contract']
old_policies=old_oracle['policies_at_timeout3'].copy()
aggregate=read(N/'upstream-aggregate-error-1.json')
assert sha(json.dumps(aggregate['runner_policy'],sort_keys=True).encode())==aggregate['runner_policy_sha256']
assert 'aggregate-error' not in old_policies
old_policies['aggregate-error']=dict(policy=aggregate['runner_policy'],sha256=aggregate['runner_policy_sha256'])
for name,row in old_policies.items():
    assert sha(json.dumps(row['policy'],sort_keys=True).encode())==row['sha256'],name
put('old-policy-preservation.json',dict(
    status='Existing policy data only; no new Any feature set or policy hash selected',
    policies_at_timeout3=old_policies,
    provenance=[bind(W/'tools/aggregate-error-preservation-oracle.json'),bind(N/'upstream-aggregate-error-1.json')],
    requirements=[
        'Preserve every existing policy object and hash exactly; only the new Any profile has the new host identity capability.',
        'Keep INTRINSIC_ERRORS as the original seven-name set. Return fresh immutable capability sets without mutating that constant.',
        'Keep the existing aggregate-error policy format2/ERJR2-only capability and all four existing Promise format3 policies unchanged.',
        'Use the existing sorted default-spacing JSON serialization for policy SHA256; do not change serializers or format versions.',
        'New Any features and its exact policy hash await authenticated body metadata and root selection.'
    ]))

api=[
 dict(name='profile_intrinsic_errors',signature='profile_intrinsic_errors(profile=None)',
      change='Return original seven plus AggregateError only for aggregate-error and promise-any; original seven for None, unknown and every old Promise profile.',
      guard='This common policy helper alone must not grant ERJR3 to aggregate-error; host validation independently selects only promise-any.'),
 dict(name='decode_response',signature='decode_response(output, *, profile=None)',
      change='Keep aggregate-error ERJR2-only guard exact. Add an Any-only ERJR3 requirement before general decoding. For an ERJR3 Any frame delegate decode_promise_response(output, profile=profile); otherwise retain the exact one-positional delegation.',
      guard='Do not allow an ERJR2 Any fallback even when its status is complete or its private identity is known.'),
 dict(name='decode_promise_response',signature='decode_promise_response(output, *, profile=None)',
      change='For Any only require ERJR3 magic and call validate_promise_observation(fields, profile=profile). Preserve current framing and the original one-positional validator call for every other route.',
      guard='The existing direct decoder does not itself validate magic. Limit the new direct-entry guard to selected Any rather than silently tightening legacy direct callers.'),
 dict(name='validate_promise_observation',signature='validate_promise_observation(fields, *, profile=None)',
      change='Use the eighth identity only when profile == PROMISE_ANY_PROFILE; for all other contexts retain original seven. The selected allowed set may be profile_intrinsic_errors(profile if profile == PROMISE_ANY_PROFILE else None).',
      guard='Keep the exact schema, types, domains, contradictions, status/phase, parse restrictions, abrupt flag and host evidence checks unchanged.'),
 dict(name='classify_promise',signature='classify_promise(case, observation, *, profile=None)',
      change='Thread Any context to its validator, with old one-positional validation for every other path; preserve the rest of classification exactly.',
      guard='Known AggregateError runtime exceptions still classify failed for ordinary positive cases. No async-negative or parse-negative support is added.'),
 dict(name='classify',signature='classify(case, observation, *, profile=None)',
      change='Only the selected Any dispatch adds profile=profile to classify_promise. All previous calls still use classify_promise(case, observation). Leave the ordinary classification body intact.',
      guard='No trusted profile context is read from case source, metadata, observation or error_type.'),
 dict(name='run_case',signature='run_case(case, binary, timeout, supported_features=SUPPORTED_FEATURES, profile=None)',
      change='Keep the existing ordinary AggregateError selected decoder route; add an Any selected decoder route. Only Any uses classify(case, observation, profile=profile); all old calls retain their original arity and keyword behavior.',
      guard='Retain adapter-error on invalid wire, timeout/resource behavior and unsupported_reason before process dispatch.'),
 dict(name='promise_preflight_verified',signature='promise_preflight_verified(case, result, expected, *, profile=None)',
      change='Only Any calls its validator with profile=profile. Preserve old no-keyword calls and every existing expectation branch unchanged.',
      guard='Its synchronous-exception branch requires Test262Error/empty identity; do not relax it to admit genuine AggregateError. New identity controls need a new Any-specific raw expectation branch/gate.'),
]
put('api-propagation.json',dict(status='proposed interfaces, not implementation or selection',api=api,
    new_profile_seams=[
        'Add PROMISE_ANY_PROFILE and independently selected features, then add only that name to PROMISE_HOST_PROFILES. The exact feature list waits for authenticated metadata.',
        'A new Any preflight builder can reconstruct unchanged common literals/metadata/helper order and fingerprints while invoking run_case with the selected Any context. Leave old builders and gates unchanged.',
        'A new promise_any_preflight_healthy(outcomes, files) should reconstruct canonical cases/prerequisites, validate every raw ERJR3 observation with Any context, recompute classification and compare exact required raw fields. verified=true alone is insufficient.',
        'For legacy common controls, call the existing expectation verifier with Any context; for genuine/fake identity cases, use separate exact raw requirements without changing the legacy Test262Error expectation.',
        'Add new-profile-only dispatch to harness_preflight and main health selection. Existing failed-preflight block/baseline refusal and policy format3 framing apply without changing old branches.'
    ],
    deliberately_unchanged=['encode_request payload and bounds','promise_completion_passes','promise_host_reason','old Promise literals and helper order','old Promise gate bodies','ordinary AggregateError gate body','existing classify success criteria','Rust runtime/host/adapter/protocol/caps','old corpus manifests/baselines/fingerprints'],
    author_context_rule='Only the runner selected profile parameter enables identity. Do not infer it from case metadata, a global mutable active-profile variable, helper names, diagnostics, or raw response fields.'))

raw=dict(status='exception',phase='runtime',error_type='AggregateError',error_identity='AggregateError',message='marker',harness='',
    completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=256,quiescent=True,audited=True,unhandled=0))
matrix=[
 dict(id='selected-genuine',input='Exact fixture below, encoded ERJR3 with independent struct packing',context='promise-any',decode='accept',classify_positive='failed',gate='healthy only for its canonical deliberately-failing identity control'),
 dict(id='selected-renamed',input='Same frame, error_type=RenamedAggregateError; identity unchanged',context='promise-any',decode='accept',classify_positive='failed',gate='require exact renamed diagnostic plus canonical identity; never derive identity from diagnostic'),
 dict(id='old-host-rejection',input='Genuine fixture',context='None, unknown, each old Promise profile; direct validator/decoder and main run_case paths',decode='reject unknown intrinsic identity',classify_positive='failed for direct dictionary classification',gate='unhealthy; old defaults remain exact'),
 dict(id='ordinary-profile-isolation',input='Genuine ERJR2 fixture and genuine ERJR3 fixture',context='aggregate-error',decode='ERJR2 remains accepted; decode_response rejects ERJR3 before delegation; direct host validator still has seven names',gate='old ordinary gate still forbids completion records'),
 dict(id='erjr2-downgrade',input='Valid complete or genuine exception ERJR2',context='promise-any',decode='reject wrong protocol',classify_positive='failed for direct completion-less dictionary',gate='unhealthy and baseline refusal'),
 dict(id='legacy-error-and-complete',input='Replace identity with each original known error; also valid checked-sync and authenticated-DONE complete frames',context='default and each old/new selected route',decode='old valid observations unchanged',classify_positive='exceptions failed; clean complete passed with matching case policy'),
 dict(id='unknown-identity',input='error_identity=UnknownIntrinsic',context='all routes',decode='reject',classify_positive='failed',gate='unhealthy'),
 dict(id='fake-own-constructor',input='error_type=AggregateError, error_identity empty, all other abrupt evidence identical',context='promise-any',decode='accept as ordinary unbranded throw',classify_positive='failed',gate='cannot satisfy genuine identity row; can satisfy separately frozen fake row'),
 dict(id='fake-prototype',input='Same independent raw expected observation as fake-own-constructor, separate literal/source/fingerprint',context='promise-any',decode='accept',classify_positive='failed',gate='cannot borrow another row identity or genuine prerequisite'),
 dict(id='malformed-wire',input='Truncation in every length/payload/trailer boundary, trailing byte, bad UTF8, oversized text, wrong magic',context='promise-any plus old regression witnesses',decode='reject',gate='unhealthy'),
 dict(id='malformed-evidence',input='Missing/extra completion keys; bool in integer fields; non-bool booleans; invalid policies/counters/flags/unhandled; audited/nonquiescent, audit/fatal, prints-without-done, checked-sync-with-done contradictions',context='promise-any',decode='reject',classify_positive='failed',gate='unhealthy even if verified=true'),
 dict(id='wrong-policy',input='Valid observation policy differs from canonical case completion_policy',context='promise-any',decode='accept valid transport',classify_positive='failed',gate='unhealthy'),
 dict(id='exception-evidence',input='Runtime exception missing abrupt flag, nonempty harness, empty error_type; parse exception with executed evidence',context='promise-any',decode='reject',classify_positive='failed',gate='unhealthy'),
 dict(id='host-veto',input='Valid missing/duplicate/error completion, queued-exception, unhandled-rejection, nonquiescent/unaudited and resource/unsupported observations',context='promise-any',decode='preserve existing valid-domain acceptance/refusal',classify_positive='preserve failed/resource/unsupported categories; never pass',gate='only dedicated frozen common negative controls can verify their exact expected refusal'),
 dict(id='identity-forbidden-status',input='Add AggregateError identity to a complete or host-failure record',context='promise-any',decode='reject existing consistency violation',classify_positive='failed',gate='unhealthy'),
 dict(id='forged-control-record',input='Correct raw observation with wrong source/case/mode/metadata/helper identity, missing/duplicate/extra row or altered prerequisite; arbitrary verified=true',context='promise-any gate',gate='unhealthy; neither classification nor flags substitute for canonical identity'),
 dict(id='routing-and-call-arity',input='Mock bounded_process only; spy decoder/classifier/validator entry points under every old/default and selected Any context',context='all routes',expected='Only Any gains keyword context; default/old delegates preserve their old argument shape; no nested profile leakage or set mutation'),
 dict(id='old-policy-regression',input='Actual main policy construction with empty mocked case inventory, then retained old case/control fingerprints',context='every existing profile',expected='Exact frozen objects/hashes and old expectations; no engine execution needed for this unit test'),
]
put('raw-control-matrix.json',dict(status='independent prospective tests, not observations or executable test implementation',
    wire='ERJR3 plus six length-prefixed UTF8 fields and struct.pack(<BBBBHBBI, policy, done_calls, success_prints, failure_prints, flags, quiescent, audited, unhandled)',
    genuine_checked_sync_fixture=raw,case=dict(mode='sloppy or strict',completion_policy=0,metadata=dict(flags=[],negative=None)),
    matrix=matrix,
    real_literal_requirements=[
        'Guard Promise.any and AggregateError presence before the discriminator.',
        'Derive genuine aggregate from Promise.any.call(C, []), where C supplies a reject that throws its argument and C.resolve is explicitly a callable identity function, even for empty input. EOF invokes reject, ordinary throw reaches outer retry, and the second throw escapes as the genuine aggregate.',
        'A separate renamed-constructor variant changes saved AggregateError.name with a stored data descriptor and expects renamed diagnostic plus private AggregateError identity.',
        'Separate fake rows throw an object with own constructor/name or Object.create(saved AggregateError.prototype); both retain empty private identity even if diagnostic says AggregateError.',
        'Use handled async assertions for errors-array contents; final host unhandled-rejection observations have no error identity payload and cannot prove its class.',
        'Freeze concrete JS source/helper hashes and exact required observation fields before running the new controls; this matrix does not assign fingerprints or final gate size.'
    ],
    trust_limit='A synthetic frame carrying a known identity is trusted as adapter output once its schema is valid. Python cannot cryptographically distinguish a forged known identity from a compromised adapter. Authentic frozen adapter identity plus genuine/fake engine literals establish the intended boundary; do not claim raw schema checks alone prove engine branding.'))

tree_auth=read(P/'root/any-tree-authentication.json')
assert tree_auth['direct_js_blobs']==tree_auth['entries']==94 and tree_auth['subtrees']==0
fetch=read(P/'fetch-1/receipt.json')
census=read(P/'root/source-census-1.json')
assert fetch['direct_source_count']==census['source_count']==94
assert fetch['tree_sha1']==tree_auth['tree_sha1']
assert census['parser_sha256']==selected['tools/import_test262.py']
fetched={r['name']:r for r in fetch['sources']}
assert len(fetched)==94 and set(fetched)=={r['name'] for r in census['rows']}
for row in census['rows']:
    raw_source=(P/'fetch-1/sources'/row['name']).read_bytes()
    assert sha(raw_source)==row['sha256']==fetched[row['name']]['sha256']
    assert hashlib.sha1(b'blob '+str(len(raw_source)).encode()+b'\0'+raw_source).hexdigest()==fetched[row['name']]['git_sha1']
assert all(row['metadata']['negative'] is None for row in census['rows'])
tagged=[row['name'] for row in census['rows'] if 'AggregateError' in row['metadata']['features']]
assert set(tagged)=={'iter-arg-is-empty-iterable-reject.js','iter-arg-is-empty-string-reject.js','reject-deferred.js'}
put('plan.json',dict(status='source-only proposed capability plan; no implementation or outcomes',
    profile='promise-any',published_tooling_base=BASE,published_runtime_base_refresh_pending=True,
    source_context=bind(N/'source-final-2.json'),
    authenticated_inventory=dict(tree=tree_auth['tree_sha1'],direct_js_blobs=94,subtrees=0,
        authority=bind(P/'root/any-tree-authentication.json'),response=bind(P/'root/any-tree-response.json'),
        fetch=bind(P/'fetch-1/receipt.json'),metadata_census=bind(P/'root/source-census-1.json'),
        all_body_hashes_reconciled=True,all_current_negative_metadata_absent=True,
        aggregate_tagged_sources=tagged,
        tagged_source_observation='The tagged bodies handle their rejected aggregates in JavaScript and finish through authenticated DONE. They do not by themselves exercise an escaped ERJR3 AggregateError identity. Pinned info comments contain the older EOF ThrowCompletion wording; retain raw sources and use current selected semantics for authored controls.',
        not_established=['new policy features/hash','new control count/fingerprints','parser/runtime/host outcomes'],
        count_scope='This identity audit claims only the authenticated 94 direct source inventory; no new mode or outcome totals.'),
    conclusions=[
        'The Rust host already serializes ScriptError private thrown identity through error_outcome and ERJR3. AggregateError object branding and canonical stored-constructor checks exist; no Rust wire or decoder change is indicated.',
        'Changing only profile_intrinsic_errors or decode_response is insufficient: host decoding, classify_promise and promise_preflight_verified each revalidate the observation.',
        'Use explicit Any-only keyword context and preserve all old defaults/delegation arities. Ordinary aggregate-error stays ERJR2-only, while selected Any must require ERJR3.',
        'Preserve all completion/audit/unhandled rules and ordinary positive failure classification. An accepted AggregateError identity is not a passing outcome.',
        'A new canonical Any gate should authenticate full observation and prerequisite identity; retain every old gate verbatim.'
    ],
    old_test_migrations=[
        dict(file='tools/test_test262_aggregate_error_preservation.py',requirement='Explicitly exclude only new promise-any from old table/feature/root comparisons and from the exact old PROMISE_HOST_PROFILES comparison. Preserve all default seven-name rejection assertions and literal policy oracles.'),
        dict(file='tools/test_test262_promise_runner.py',requirement='Its historical profile-set exclusion list needs the new profile entry; old policy assertions remain exact.'),
        dict(file='tools/test_test262_promise_race_profile.py',requirement='Historical table/root/tree exclusions need the new entry; no old oracle or fingerprints change.'),
        dict(file='all earlier profile set fixtures',requirement='The full profile-roster migration census belongs to the corpus/profile checkpoint and must be derived across all tools tests before implementation; this identity audit does not claim those three paths are the complete census.')
    ],
    independence='Source/AST/Git/JSON reads only; no project import, adapter, compiler, tests, network fetch or live write. Frozen runtime checkpoint artifacts remain untouched.',
    pending=['Published runtime commit/source refresh','Final feature/helper selection from the authenticated metadata','Root API/gate selection','Independent literal and executable-test freeze before runner implementation']))
files=[bind(H/x) for x in ['source-bindings.json','old-policy-preservation.json','api-propagation.json','raw-control-matrix.json','plan.json','author.py']]
put('source-ready.json',dict(status='source_ready_proposal',files=files,
    prior_readiness=bind(P/'readiness-1/source-ready.json'),
    no_project_execution=True,no_live_source_edits=True,no_outcome_prediction=True))
print(json.dumps(bind(H/'source-ready.json')))
