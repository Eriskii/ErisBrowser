from pathlib import Path
import json,hashlib
R=Path('/tmp/eris-promise-any-upstream-plan-1/readiness-1')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
plan={
 'status':'source-bound proposal; no profile implementation, corpus fetch, or execution',
 'scope':'A future authenticated Promise.any upstream profile, after the current runtime checkpoint publishes. Existing 58 profiles and host behavior remain preservation controls.',
 'source_base':'30576b1d977a6590099b5c4748abac9f188bc05c',
 'proposed_profile':'promise-any',
 'corpus_evidence':{
  'revision':'7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd','root_tree':'91b2052adad1f066ae031e2ff3a1e9bd6d732886','path':'test/built-ins/Promise/any','subtree_tree':'e2352be158fb0c0625d1ab642330faabc62a2df8',
  'established':'Independent binary Git-tree reconstruction of retained ancestor proofs authenticates this entry. The retained corpus does not include the Any subtree listing or bodies.',
  'unknown':['direct and descendant source counts','fixtures','strict/sloppy/raw/module mode census','async/sync and negative metadata','feature tags and untagged syntax boundaries','include/helper closure','eventual parser/runtime/host outcomes']},
 'authentication_requirements':[
  'Retrieve the complete pinned Any tree and any descendants, reconstruct every tree object, and authenticate every raw body by Git blob SHA1 plus retained SHA256/byte count. Require exact selected child-directory closure; the generic immediate-directory walker alone does not prove omitted descendants absent.',
  'Derive fixed directory counts and names from authenticated inventories before import. Preserve unsupported tagged and untagged bodies in the denominator; never select paths or metadata from observed pass results.',
  'Read all original frontmatter with the existing parser contract. Mode policy is module, then raw, then onlyStrict/noStrict, otherwise both. Do not assume two modes per source. Keep absent timeout absent in fingerprints.',
  'Derive assert/sta plus all requested includes and authenticated doneprintHandle for async sources; inspect helper dependencies and explicitly justify any gate-only helper. Authenticate helpers through the retained harness tree and legal files through the root.',
  'Use existing bounded manifest/proof validation: fixed directory selection, complete hashes, exact source/auxiliary/proof sets, blob joins, safe paths, symlink refusal, unlisted-script refusal, size limits, and reconstruction without network during runner loading. Freeze manifest and case identities independently before candidate implementation.'
 ],
 'host_and_identity':{
  'existing_transport':'ERJS2 accepts only sloppy/strict non-parse-only scripts, policy0 checked-sync or policy1 authenticated-DONE. Every Promise profile case carries completion_policy, including synchronous cases. ERJR3 has six bounded text fields plus the exact eight-field completion record.',
  'existing_bounds':'4MiB request; each source/helper up to2MiB; at most32 distinct harness names; assert.js then sta.js; async doneprintHandle third and byte-identical to compiled pinned helper; checked-sync excludes it. Responses keep16384-byte text bounds and fixed12-byte completion trailer.',
  'identity_gap':'The Rust encoder already serializes intrinsic_error_name into error_identity without a seven-name wire whitelist. The Python ordinary aggregate-error profile admits AggregateError only through ERJR2. ERJR3 decode_promise_response calls validate_promise_observation with seven names; classify_promise and promise_preflight_verified validate again with seven names. Updating only decode_response or profile_intrinsic_errors is insufficient.',
  'recommended_capability':'Select AggregateError as an eighth identity only for the new Any checked-host route, then propagate that trusted profile context through decoding, classification and preflight verification. Preserve default/old Promise ERJR3 seven-name behavior and existing aggregate-error ordinary ERJR2 eight-name behavior. Do not infer identity from diagnostic text or configurable constructor.name.',
  'wire_constraint':'Require authenticated ERJR3 evidence for every Any case; ordinary ERJR2 must never produce a healthy new-profile result. Reuse the existing frame and host session; no protocol version or Rust adapter change is currently indicated by the inspected source.',
  'classification':'Keep completion policy equality, counters, boolean/range/flag checks, parse-evidence restrictions, synchronous exception flag, final quiescent audit and unhandled-rejection veto exact. Adding an identity must not turn an exception into a passed positive test.',
  'negative_metadata':'Existing Promise policy refuses all negative metadata and raw/module modes. Keep those boundaries unless the authenticated Any census reveals a concrete need and root selects a separate supported policy. An AggregateError raw-identity control can be a deliberately failing positive case; no negative-metadata support is necessary merely to prove transport identity.',
  'actual_payload_limit':'Host-failure observations deliberately have empty error_type/error_identity and report flags/count/reason, including unhandled-rejection. They do not authenticate a particular unhandled AggregateError payload. Assert handled asynchronous errors in JavaScript, and use an escaped checked-sync intrinsic AggregateError for a raw identity discriminator.',
  'brand_limit':'Existing diagnostics require both private intrinsic_error branding and the stored canonical Native constructor/receiver. Renaming its display name can preserve identity; fake constructor/prototype shapes must not. Replacing or blocking the stored constructor can leave identity empty under the inherited best-effort policy.'
 },
 'preflight_and_test_plan':[
  'Retain original37 common Promise variants/74 strict-sloppy records, helper bytes, completion policies and fingerprints. Add frozen Any pairs only after source census and root selection; no prospective final count is claimed.',
  'Candidate semantic families: method metadata/nonconstructibility; first fulfillment while rejection/pending siblings are handled; all-rejected input-order errors and empty rejection; generic shared resolve plus distinct once rejection callbacks; iterator-close/EOF retry behavior; any corpus-specific helper positive/poison pair.',
  'Raw identity discriminator should originate from Promise.any itself: generic capability reject throws its supplied intrinsic aggregate, allowing selected EOF retry and final synchronous escape. Compare genuine/renamed branded identity with fake own-constructor/prototype throws; no mutable global lookup or name-string trust. Freeze exact raw fields and completion evidence before execution.',
  'New health gate should reconstruct canonical literal/helper/mode identities and prerequisites, validate complete seven-key observation plus eight completion fields, recompute classification, reject missing/duplicate/extra/altered rows or forged verified bits, and require positive prerequisites for mismatches. The old six-field AggregateError gate cannot be reused unchanged for ERJR3.',
  'Mock tests must prove profile-local eighth identity, old seven-name rejection, malformed/truncated/trailing wire refusal, checked-sync/async evidence contradictions, routing, full loader corruption/deletion/unbound-proof refusal, and failed preflight blocking every retained case and baseline creation.',
  'Preserve all58 old profile tables/features/policies and five recorded baseline maps (1100 combined case entries); preserve old literal controls separately from new gate composition. Narrow any old test roster-exclusion migrations explicitly, with unchanged numerical/hash expectations.',
  'Root-owned validation should baseline parent-compatible preservation controls before candidate tooling, then run selected/full Python checks, healthy real gate, complete corpus measurement and exact replay, plus all existing profile replay records. Record actual failed/unsupported results without forecasting or removing them. Add a separate CI command only after review.'
 ],
 'unresolved_choices':[
  {'choice':'Published runtime base and binary','needed':'Refresh bindings to the completed runtime commit; build/retain the root-owned test262-host binary from that exact source.'},
  {'choice':'Complete corpus selection','needed':'Fetch/authenticate Any tree and bodies; settle descendants, fixtures, exact source/mode counts and helper closure.'},
  {'choice':'Feature/policy set','needed':'Select only implemented declared features after census. Tagged unsupported cases and untagged parser/runtime failures remain distinct.'},
  {'choice':'Profile-local validator API','needed':'Root selects optional trusted profile context versus dedicated Any validator; every decoding/classification/gate path must carry it without broadening old defaults.'},
  {'choice':'Negative/raw/module policy','needed':'Use observed metadata census to decide whether inherited unsupported classification is sufficient; do not silently add parse-only or async-negative support.'},
  {'choice':'Preflight literals and count','needed':'Freeze exact control sources, raw observations, prerequisite graph, helper bindings and fingerprints; current families are an outline only.'},
  {'choice':'Initial baseline policy','needed':'Root chooses first measurement with or without record-baseline; document actual command/exit. Healthy recording may retain failures/unsupported outcomes; no exit/result is predicted.'}
 ],
 'preservation_and_limits':['No old/current-runtime artifacts changed.','No project code imported/executed, no compiler/engine/test run, no network reads or mutations in this readiness task.','No Any corpus count, mode count, health, passing outcome or full compatibility claim.','No new Proxy, realms, host-session behavior, runtime budgets or diagnostic-brand semantics proposed.']
}
(R/'plan.json').write_text(json.dumps(plan,indent=2)+'\n')
# The source-bound plan and original snapshots are immutable after this seal.
paths=sorted(p for p in R.rglob('*') if p.is_file() and p.name!='source-ready.json')
manifest={'status':'sealed source-only readiness proposal','scope':'Future Promise.any authenticated upstream profile; counts and choices explicitly unresolved','base':'30576b1d977a6590099b5c4748abac9f188bc05c','files':[dict(relative=str(p.relative_to(R)),**bind(p)) for p in paths],'no_execution_or_current_checkpoint_mutation':True}
(R/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'plan':bind(R/'plan.json'),'seal':bind(R/'source-ready.json'),'members':len(paths)}))
