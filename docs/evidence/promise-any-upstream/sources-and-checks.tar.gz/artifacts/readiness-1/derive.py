from pathlib import Path
import hashlib,json,ast,subprocess
W=Path('/tmp/eris-promise-any-runtime-plan-1/worktree');R=Path('/tmp/eris-promise-any-upstream-plan-1/readiness-1');BASE='30576b1d977a6590099b5c4748abac9f188bc05c'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(rel,b):
 p=R/'snapshots'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return bind(p)
sources=[]
rels=['tools/import_test262.py','tools/test262_conformance.py','src/bin/eris-js.rs','src/bin/eris-js/test262_host.rs','src/script/throw_metadata.rs','src/script/test262_host.rs','.github/workflows/check.yml']
for rel in rels:
 b=(W/rel).read_bytes();assert b==subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
 sources.append({'relative':rel,'published_bytes_equal':True,'source':bind(W/rel),'snapshot':save(rel,b)})
funcs={}
for rel in rels[:2]:
 b=(W/rel).read_text();tree=ast.parse(b);lines=b.splitlines(True)
 for n in tree.body:
  if isinstance(n,ast.FunctionDef) and n.name in {'git_tree_inventory','profile_tree_inventory','parse_metadata','import_profile','modes','harness_names','load_corpus','case_fingerprint','unsupported_reason','encode_request','decode_response','run_case','profile_intrinsic_errors','validate_promise_observation','decode_promise_response','classify_promise','promise_completion_passes','promise_preflight_variants','promise_preflight_verified','promise_preflight_healthy','promise_harness_preflight','aggregate_error_preflight_checks','aggregate_error_preflight_healthy','main'}:
   bb=''.join(lines[n.lineno-1:n.end_lineno]).encode();funcs[rel+':'+n.name]={'line':n.lineno,'end_line':n.end_lineno,'sha256':sha(bb)}
imp=ast.parse((W/'tools/import_test262.py').read_text())
assign={x.targets[0].id:x.value for x in imp.body if isinstance(x,ast.Assign) and len(x.targets)==1 and isinstance(x.targets[0],ast.Name)}
profiles=[ast.literal_eval(x) for x in assign['PROFILES'].keys];assert len(profiles)==58
REV=ast.literal_eval(assign['REVISION']);ROOT=ast.literal_eval(assign['REVISION_TREE'])
P=W/'tests/upstream/test262-promise-all/inventory-proof';docs={}
for p in P.glob('tree-*.json'):
 j=json.loads(p.read_text());assert j['truncated'] is False
 entries=[];names={}
 for e in j['tree']:
  name=e['path'];mode=e['mode'];kind=e['type'];h=e['sha'];assert name not in names and '/' not in name and '\0' not in name
  assert {'040000':'tree','100644':'blob','100755':'blob','120000':'blob','160000':'commit'}[mode]==kind
  raw=name.encode();entries.append((raw+(b'/' if kind=='tree' else b''),mode.lstrip('0').encode()+b' '+raw+b'\0'+bytes.fromhex(h)));names[name]=e
 body=b''.join(v for k,v in sorted(entries));assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==j['sha']
 docs[j['sha']]=(p,names)
commit=json.loads((P/'commit.json').read_text());assert commit['sha']==REV and commit['tree']['sha']==ROOT
chain=[];cur=ROOT
for name in ['test','built-ins','Promise','any']:
 p,names=docs[cur];e=names[name];assert e['type']=='tree';chain.append({'parent':cur,'name':name,'child':e['sha'],'parent_proof':save('proof/'+p.name,p.read_bytes())});cur=e['sha']
assert cur=='e2352be158fb0c0625d1ab642330faabc62a2df8' and cur not in docs
harness=docs[ROOT][1]['harness'];hp,hnames=docs[harness['sha']]
legal={n:docs[ROOT][1][n]['sha'] for n in ['LICENSE','INTERPRETING.md']}
proof={'revision':REV,'root_tree':ROOT,'commit':save('proof/commit.json',(P/'commit.json').read_bytes()),'chain':chain,'harness_tree':{'sha':harness['sha'],'proof':save('proof/'+hp.name,hp.read_bytes())},'legal_blobs':legal,'candidate_path':'test/built-ins/Promise/any','authenticated_subtree_tree':cur,'subtree_listing_present_in_retained_proofs':False,'source_file_count':None,'mode_count':None,'helper_closure':None,'retained_tree_objects_independently_reconstructed':len(docs),'qualification':'Ancestor entry authenticates the Any tree ID only. No Any tree listing or bodies were fetched; this is not a complete Any corpus proof.'}
(R/'corpus-evidence.json').write_text(json.dumps(proof,indent=2)+'\n')
baselines=[]
for name in ['promise-methods-async','promise-all','promise-race','promise-all-settled','aggregate-error']:
 rel='tests/conformance/test262-'+name+'-current.json';p=W/rel;b=p.read_bytes();assert b==subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
 j=json.loads(b);baselines.append({'profile':name,'source':bind(p),'snapshot':save(rel,b),'recorded_case_entries':len(j['cases'])})
bindings={'status':'source-only','published_tooling_base':BASE,'runtime_publication_base':'pending current runtime checkpoint publication; refresh before implementation','sources':sources,'function_pointers':funcs,'existing_profile_count':len(profiles),'existing_profile_names':sorted(profiles),'baseline_sources':baselines,'existing_five_baseline_case_entries':sum(x['recorded_case_entries'] for x in baselines),'no_runtime_or_upstream_outcome_claim':True}
(R/'source-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
print(json.dumps({'profiles':len(profiles),'pinned_any_tree':cur,'counts':'unresolved','sources':len(sources),'source_bindings':bind(R/'source-bindings.json'),'proof':bind(R/'corpus-evidence.json')}))
