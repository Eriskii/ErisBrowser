"""Independent source/hash/AST inspection only; never imports project modules."""
import ast
import collections
import hashlib
import json
from pathlib import Path
import subprocess

U = Path('/tmp/eris-promise-any-upstream-plan-1')
W = U / 'worktree'
D = U / 'production-review-1'
BASE = '90c653d813feb62d1d569864bec076c0cc92d8a5'

def sha(data):
    return hashlib.sha256(data).hexdigest()
def record(path):
    p = Path(path); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))
def read(rel):
    return json.loads((U / rel).read_text())
def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args])
def functions(text):
    lines = text.splitlines(keepends=True)
    return {n.name: ''.join(lines[n.lineno-1:n.end_lineno]) for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)}
def check_metadata(obj):
    if isinstance(obj, dict):
        if all(k in obj for k in ('path', 'bytes', 'sha256')) and Path(obj['path']).is_absolute():
            p = Path(obj['path']); b = p.read_bytes()
            if p.is_relative_to(W) and (len(b) != obj['bytes'] or sha(b) != obj['sha256']):
                b = git('show', BASE+':'+p.relative_to(W).as_posix())
            assert len(b) == obj['bytes'] and sha(b) == obj['sha256'], str(p)
            checked.add(str(p))
        for v in obj.values(): check_metadata(v)
    elif isinstance(obj,list):
        for v in obj: check_metadata(v)

authorities = [
    'source-parent.json', 'source-final.json', 'root/selection-1.json', 'importer-1/source-ready.json',
    'runner-1/source-ready.json', 'gate-correction-1/source-ready.json',
    'controls-1/source-ready.json', 'preservation-1/source-ready.json',
    'migrations-before-1/source-ready.json', 'loader-tests-1/source-ready.json',
    'ci-1/source-ready.json', 'runner-protocol-review-1/review.json',
    'identity-review-1/review.json', 'controls-1/integration-clarification.json',
]
checked = set()
for rel in authorities: check_metadata(read(rel))
parent = read('source-parent.json')['source_sha256']
assert len(parent) == 1735
assert git('rev-parse','HEAD').decode().strip() == BASE
expected_old = {}
expected_new = {}
def add_file(rel, raw, before=None):
    p = Path(raw['path']); b = p.read_bytes()
    assert (W/rel).read_bytes() == b, ('live mismatch',rel)
    if before:
        old = Path(before['path']).read_bytes()
        assert git('show', BASE+':'+rel) == old, ('git before',rel)
        assert parent[rel] == sha(old)
        expected_old[rel] = sha(b)
    else:
        assert rel not in parent
        expected_new[rel] = sha(b)
for entry in read('importer-1/source-ready.json')['payload']:
    add_file(entry['relative_path'],entry['raw'],entry.get('before'))
for entry in read('runner-1/source-ready.json')['files']:
    raw = read('gate-correction-1/source-ready.json')['raw'] if entry['relative']=='tools/test262_conformance.py' else entry['raw']
    add_file(entry['relative'],raw,entry.get('before'))
for entry in read('controls-1/source-ready.json')['new_test_files']:
    add_file(entry['path'],entry['raw'])
for entry in read('preservation-1/source-ready.json')['files']:
    add_file(entry['relative_path'],entry['raw'])
loader=read('loader-tests-1/source-ready.json');add_file(loader['relative_path'],loader['raw'])
ci=read('ci-1/source-ready.json');add_file(ci['path'],ci['raw'],ci['before'])

# Each migration is an exact source replacement, with all other assertions retained.
migration = read('migrations-before-1/source-ready.json')
changes = read('migrations-before-1/changes.json')['changes']
assert len(migration['files']) == len(changes) == 18
by_path = {e['path']:e for e in changes}
edit_count = 0; test_count = 0
for entry in migration['files']:
    rel=entry['path']; add_file(rel,entry['raw'],entry['before'])
    before=Path(entry['before']['path']).read_text(); after=Path(entry['raw']['path']).read_text()
    edits=by_path[rel]['edits']; current=before
    for edit in edits:
        assert current.count(edit['before']) == 1
        assert 'promise-any' not in edit['before'] and 'promise-any' in edit['after']
        current=current.replace(edit['before'],edit['after'],1)
        edit_count += 1
    assert current == after
    for edit in reversed(edits):
        assert current.count(edit['after']) == 1
        current=current.replace(edit['after'],edit['before'],1)
    assert current == before
    trees=[ast.parse(x) for x in (before,after)]
    names=[[n.name for n in ast.walk(t) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')] for t in trees]
    assert names[0]==names[1];test_count += len(names[0])
    literals=[[n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,(str,int,float)) and n.value!='promise-any'] for t in trees]
    assert collections.Counter((type(v).__name__,repr(v)) for v in literals[0]) == collections.Counter((type(v).__name__,repr(v)) for v in literals[1]), rel
assert edit_count == 29

# Independent function extraction and whole-file byte inverse.
before=(U/'runner-1/before/tools/test262_conformance.py').read_text()
initial=(U/'runner-1/raw/tools/test262_conformance.py').read_text()
final=(U/'gate-correction-1/raw.py').read_text()
oldfunc=functions(before); firstfunc=functions(initial); newfunc=functions(final)
modified=sorted(k for k in oldfunc if oldfunc[k]!=newfunc[k])
added=sorted(set(newfunc)-set(oldfunc));same=sorted(k for k in oldfunc if oldfunc[k]==newfunc[k])
assert len(modified)==11 and len(added)==6 and len(same)==45
ledger=read('runner-1/changed-function-ledger.json')
assert modified==sorted(x['name'] for x in ledger['modified_existing_functions'])
assert added==sorted(x['name'] for x in ledger['new_functions'])
assert same==sorted(x['name'] for x in ledger['unchanged_existing_functions'])
for n in same: assert oldfunc[n]==firstfunc[n]==newfunc[n]
correction_before="good = observation['completion'] == dict("
correction_after="good = observation['harness'] == '' and observation['completion'] == dict("
assert initial.count(correction_before)==1 and initial.replace(correction_before,correction_after,1)==final
assert [n for n in firstfunc if firstfunc[n]!=newfunc[n]] == ['promise_any_preflight_checks']
inv=final
for n in modified: inv=inv.replace(newfunc[n],oldfunc[n],1)
for n in added: inv=inv.replace(newfunc[n]+'\n\n','',1)
new_top="PROMISE_ANY_PROFILE = 'promise-any'\nPROMISE_ANY_FEATURES = {'AggregateError', 'Promise.any', 'Reflect.construct', 'Symbol',\n                        'Symbol.iterator', 'Symbol.species', 'arrow-function',\n                        'computed-property-names'}\nPROFILE_FEATURES[PROMISE_ANY_PROFILE] = PROMISE_ANY_FEATURES\n"
assert inv.count(new_top)==1
inv=inv.replace(new_top,'',1).replace('PROMISE_HOST_PROFILES.add(PROMISE_ANY_PROFILE)\n','',1)
assert inv==before
payload=functions((U/'controls-1/payload/any-preflight.py').read_text())
assert set(payload)==set(added)
assert all(payload[n]==firstfunc[n] for n in added)
node=ast.parse(newfunc['promise_any_preflight_variants']).body[0]
variants=ast.literal_eval(next(n.value for n in node.body if isinstance(n,ast.Return)))
literal=read('controls-1/literal-contract.json')
held=[{k:v for k,v in item.items() if k!='source_sha256'} for item in literal['variants']]
assert variants==held and len(variants)==14
assert newfunc['classify'].index('if profile == PROMISE_ANY_PROFILE:') < newfunc['classify'].index("if 'completion_policy' in case")

# Importer inverse and unchanged authentication/metadata/fetch helpers.
ib=(U/'importer-1/before/tools/import_test262.py').read_text()
ia=(U/'importer-1/raw/tools/import_test262.py').read_text()
ii=ia
for edit in reversed(read('importer-1/edits.json')['sites']):
    assert ii.count(edit['after'])==1
    ii=ii.replace(edit['after'],edit['before'],1)
assert ii==ib
ifb=functions(ib);ifa=functions(ia)
imod=sorted(k for k in ifb if ifb[k]!=ifa[k])
assert imod==['import_corpus','profile_tree_inventory'] and set(ifb)==set(ifa)

# Complete corpus bytes, manifest, six linked tree objects, and all 102 blobs.
corpus=U/'importer-1/corpus-raw'
live=W/'tests/upstream/test262-promise-any'
oracle=read('importer-1/raw/tools/test262-promise-any-import-oracle.json')
manifest=json.loads((corpus/'manifest.json').read_text())
assert manifest==oracle['expected_manifest']
allfiles={x['path']:x for x in oracle['all_files']}
assert len(allfiles)==110
for root in (corpus,live):
    actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file()}
    assert actual==set(allfiles)
    for name,entry in allfiles.items():
        b=(root/name).read_bytes()
        assert not (root/name).is_symlink() and len(b)==entry['bytes'] and sha(b)==entry['sha256']
for name,entry in allfiles.items():expected_new['tests/upstream/test262-promise-any/'+name]=entry['sha256']
assert len(manifest['files'])==102 and manifest['test_files']==94
proof=manifest['inventory_proof'];trees={}
def git_hash(kind,data):return hashlib.sha1(kind+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
for entry in proof['files']:
    b=(corpus/entry['path']).read_bytes(); assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
    value=json.loads(b)
    if '/tree-' not in entry['path']:continue
    assert value['truncated'] is False
    rows=value['tree']; assert len(rows)==len({x['path'] for x in rows})
    rows=sorted(rows,key=lambda x:(x['path']+('/' if x['type']=='tree' else '')).encode())
    encoded=b''.join(x['mode'].lstrip('0').encode()+b' '+x['path'].encode()+b'\0'+bytes.fromhex(x['sha']) for x in rows)
    assert git_hash(b'tree',encoded)==value['sha'];trees[value['sha']]={x['path']:x for x in rows}
commit=json.loads((corpus/'inventory-proof/commit.json').read_text())
assert commit['sha']==manifest['revision']==proof['revision']=='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
assert commit['tree']['sha']==proof['root_tree']=='91b2052adad1f066ae031e2ff3a1e9bd6d732886'
root=trees[proof['root_tree']];test=trees[root['test']['sha']];builtins=trees[test['built-ins']['sha']];promise=trees[builtins['Promise']['sha']];leaf=trees[promise['any']['sha']]
assert promise['any']['sha']==proof['directory_trees']['Promise/any']
assert len(leaf)==94 and all(x['type']=='blob' for x in leaf.values())
for name,entry in leaf.items():assert git_hash(b'blob',(corpus/'test/built-ins/Promise/any'/name).read_bytes())==entry['sha']
harness=trees[root['harness']['sha']]
for name,oid in proof['auxiliary_blobs'].items():
    entry=harness[name.split('/')[1]] if name.startswith('harness/') else root[name]
    assert entry['sha']==oid==git_hash(b'blob',(corpus/name).read_bytes())
assert len(trees)==6 and len(proof['auxiliary_blobs'])==8
assert len(oracle['case_identities'])==188 and len(oracle['metadata'])==94
assert sum('async' in x['flags'] for x in oracle['metadata'].values())==65
assert all(x['negative'] is None for x in oracle['metadata'].values())

# CI is one additive step; all previous byte content is retained.
cb=Path(ci['before']['path']).read_text();ca=Path(ci['raw']['path']).read_text()
step="      - name: Preserve complete pinned Promise.any cases and intrinsic error identity\n        run: python3 tools/test262_conformance.py --binary target/release/eris-js --profile promise-any --baseline tests/conformance/test262-promise-any-current.json --output artifacts/test262-promise-any-gate.json\n"
assert ca.count(step)==1 and ca.replace(step,'',1)==cb
assert 'toolchain: [1.88.0, stable]' in ca[ca.index('  test262-host:'):ca.index('  presenter-variants:')]

# All inherited selected inputs and complete tracked changed-path roster.
actual_changed=[]; unchanged=[]
for rel,digest in parent.items():
    actual=sha((W/rel).read_bytes())
    if actual!=digest:actual_changed.append(rel)
    else:unchanged.append(rel)
assert set(actual_changed)==set(expected_old) and len(expected_old)==21
assert set(git('diff','--name-only',BASE).decode().splitlines())==set(expected_old)
assert len(expected_new)==118
assert all((W/rel).is_file() and sha((W/rel).read_bytes())==digest for rel,digest in expected_new.items())
selected=dict(parent);selected.update(expected_old);selected.update(expected_new)
assert len(selected)==1853
(D/'source-snapshot.json').write_text(json.dumps({'base':BASE,'scope':'Review overlay of inherited 1735 inputs plus eight new tooling files and 110 new corpus files; excludes the separately measured baseline and documentation/evidence','source_sha256':dict(sorted(selected.items()))},indent=2)+'\n')
root_final=read('source-final.json')['source_sha256']
assert len(root_final)==1744
assert set(root_final)-set(parent)==set(rel for rel in expected_new if rel.startswith('tools/'))|{'tests/conformance/test262-promise-any-current.json'}
assert all(sha((W/rel).read_bytes())==digest for rel,digest in root_final.items())
assert all(selected[rel]==digest for rel,digest in root_final.items() if rel in selected)
baseline=record(W/'tests/conformance/test262-promise-any-current.json')
checks={
 'status':'clear','method':'stdlib source/AST/hash reads and read-only Git; no project import, tests, engine, network, or live write',
 'bindings':[record(U/rel) for rel in authorities], 'validated_bound_files':len(checked),
 'runner':{'modified_existing':modified,'new':added,'byte_exact_existing':same,'byte_exact_existing_count':len(same),'full_parent_inverse_sha256':sha(inv.encode()),'factory_variants_exact':14,'correction_only_function':'promise_any_preflight_checks','source_final':record(U/'gate-correction-1/raw.py')},
 'importer':{'changed_functions':imod,'unchanged_function_count':len(ifb)-2,'exact_inverse_sha256':sha(ii.encode()),'additive_sites':8},
 'migrations':{'files':18,'exclusions':edit_count,'test_definitions_retained':test_count,'exact_inverses':True,'old_numeric_and_other_literal_multisets_retained':True},
 'corpus':{'files':110,'bytes':sum(x['bytes'] for x in allfiles.values()),'sources':94,'modes':188,'async_modes':130,'sync_modes':58,'helpers':6,'legal':2,'proofs':7,'reconstructed_trees':6,'authenticated_blobs':102,'manifest_sha256':sha((corpus/'manifest.json').read_bytes()),'commit_root_binding':'retained pinned GitHub commit response; all six Git tree object IDs and 102 leaf blob IDs independently reconstructed'},
 'ci':{'new_steps':1,'old_bytes_inverse':True,'job':'test262-host','toolchains':['1.88.0','stable'],'execution_claim':False,'new_baseline':'Bound by source-final; outcome interpretation excluded from this review'},
 'closure':{'parent_selected':1735,'modified_old':21,'unchanged_old':len(unchanged),'new':118,'selected':1853,'no_dropped_parent_input':True,'rust_cargo_build_adapters_old_corpora_baselines_oracles_unchanged':True,'snapshot':record(D/'source-snapshot.json'),'root_final_selected':1744,'root_final':record(U/'source-final.json'),'root_final_new_tooling_files':8,'root_final_additional_measured_baseline':baseline,'root_final_corpus_separately_bound':110,'root_final_plus_corpus_union':1854,'baseline_scope':'Byte identity/source closure only; no baseline or profile outcome interpretation in this review'},
}
(D/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps({k:v for k,v in checks.items() if k not in ('bindings','runner')},indent=2))
print('runner',len(modified),len(added),len(same))
