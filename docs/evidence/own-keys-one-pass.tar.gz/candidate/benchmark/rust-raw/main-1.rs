use eris::{dom::Document, script::{Runtime, Value}};
use std::{env, process::ExitCode, time::Instant};

const SAMPLES: usize = 21;
const WARMUP: usize = 2;
const REPS: usize = 5;
const BODY: &str = "var benchOut='';for(var benchKey in benchObject){benchOut+=benchKey+',';}benchOut;";

struct Case { name: &'static str, setup: String, expected: String }

fn keys(setup: &mut String, object: &str, prefix: &str, count: usize) -> String {
    let mut expected = String::new();
    for i in 0..count {
        let key = format!("{prefix}{i}");
        setup.push_str(&format!("{object}['{key}']={i};"));
        expected.push_str(&key);
        expected.push(',');
    }
    expected
}

fn cases() -> Vec<Case> {
    let mut result = Vec::new();
    for (name, count) in [("strings8", 8), ("strings20", 20), ("strings64", 64)] {
        let mut setup = "var benchObject={};".to_owned();
        let expected = keys(&mut setup, "benchObject", "k", count);
        result.push(Case { name, setup, expected });
    }
    let mut setup = "var benchObject={};".to_owned();
    let expected = keys(&mut setup, "benchObject", "k", 18);
    setup.push_str("benchObject[Symbol('one')]=1;benchObject[Symbol('two')]=2;");
    result.push(Case { name:"mixed20", setup, expected });
    let mut setup = "var benchObject={};".to_owned();
    for i in 0..20 { setup.push_str(&format!("benchObject[Symbol('s{i}')]=1;")); }
    result.push(Case { name:"symbols20", setup, expected: String::new() });
    for (name, first) in [("digit-first", true), ("digit-last", false)] {
        let mut setup = "var benchObject={};".to_owned();
        if first { setup.push_str("benchObject['2']=99;"); }
        let suffix = keys(&mut setup, "benchObject", "k", 19);
        if !first { setup.push_str("benchObject['2']=99;"); }
        result.push(Case { name, setup, expected: format!("2,{suffix}") });
    }
    let mut setup = "var benchTop={};".to_owned();
    let top = keys(&mut setup, "benchTop", "t", 8);
    setup.push_str("benchTop.shadow=1;var benchMiddle=Object.create(benchTop);");
    let middle = keys(&mut setup, "benchMiddle", "m", 8);
    setup.push_str("Object.defineProperty(benchMiddle,'shadow',{value:2,enumerable:false});var benchObject=Object.create(benchMiddle);");
    let leaf = keys(&mut setup, "benchObject", "l", 8);
    result.push(Case { name:"prototype-chain", setup, expected: format!("{leaf}{middle}{top}") });
    result
}

fn check(value: Result<Value, eris::script::ScriptError>, expected: &str) -> Result<(), String> {
    match value {
        Ok(Value::String(text)) if text == expected => Ok(()),
        other => Err(format!("enumeration mismatch: {other:?}; expected {expected:?}")),
    }
}

fn run() -> Result<(), String> {
    let args: Vec<_> = env::args().skip(1).collect();
    if args.len()!=1 { return Err("expected round number 0..3".into()); }
    let round: usize = args[0].parse().map_err(|_| "invalid round")?;
    if round>=3 { return Err("round number outside 0..3".into()); }
    println!("ERIS_OWN_KEYS_BENCH\t1\t{round}\t{SAMPLES}\t{WARMUP}\t{REPS}");
    let mut rows=0;
    for case in cases() {
        for sample in 0..SAMPLES {
            let mut runtime=Runtime::try_new().map_err(|e| e.to_string())?;
            let mut document=Document::parse("<!doctype html><title>Own keys benchmark</title>");
            runtime.execute(&case.setup,&mut document).map_err(|e| e.to_string())?;
            for _ in 0..WARMUP { check(runtime.execute(BODY,&mut document), &case.expected)?; }
            let mut total=0u128;
            for _ in 0..REPS {
                let start=Instant::now();
                let value=runtime.execute(BODY,&mut document);
                let elapsed=start.elapsed().as_nanos();
                check(value,&case.expected)?;
                if elapsed==0 { return Err("zero timer interval".into()); }
                total=total.checked_add(elapsed).ok_or("timer overflow")?;
            }
            println!("ROW\t{}\t{sample}\t{total}\t{REPS}",case.name);
            rows+=1;
        }
    }
    println!("END\t{rows}\t{}",rows*REPS);
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(())=>ExitCode::SUCCESS,
        Err(error)=>{eprintln!("BENCH_FAIL\t{error}");ExitCode::FAILURE}
    }
}
