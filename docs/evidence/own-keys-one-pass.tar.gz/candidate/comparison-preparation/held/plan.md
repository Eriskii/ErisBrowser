# Own-key enumeration comparison source plan

This runtime optimization has no new conformance population. The immutable
published predecessor is `58431abc392f0e4ee50dcae79ecec902241da009` and its
adapter SHA-256 is `35807b37c8a57554ca44419c98ec61dbb7d4e6adc80af8997c690bd49ee538ac`.
All 45 predecessor reports are frozen under `before/`, with their original
receipts/logs, 38 historical baselines, adapter/source records and runner/local
input dependencies. `before-index.json` binds both originals and copies.
The complete population is 18,298 case rows and 4,284 control rows.

The seven top reports are toReversed, reverse, fill, search, foundation, views
and the independent views-local corpus. `I/upstream-1.json` maps to
`J/to-reversed-1.json`; the other six names remain unchanged. All 38 historical
profiles retain their original baseline bytes. No reports or modes are filtered.

Unlike a new-method comparison, this comparator does not require every existing
observation to be identical. Lower actual work or heap can finish a formerly
resource-limited body or advance it to an assertion failure. It retains full
before/after rows and row hashes for every difference, every status transition,
and separate lists of newly passing cases, resource-to-failure advances, new
resource stops and prior-pass losses. A resource-to-failure advance is never
counted as a pass. Same-status resource diagnostic changes remain visible.
`clear` means the comparison invariants hold; it does not mean every report is
healthy or that every newly exposed failure has been resolved.

The invariant checks require ordered case identity, population, policy and
control-oracle identity to remain unchanged, and every former pass to remain a
pass. Unsupported rows and their explicit policy reasons must remain exact.
Paired controls are reconstructed from actual observations and the same-mode
positive partner. Genuine intrinsic Error checks and the historical expected-
unsupported controls follow the unchanged runner policy. The response classifier
is checked against every observed row, including authored parse negatives.
Module exclusions remain valid. Infrastructure and harness failures are findings.

Both sides' adapter/source/build/full-suite bindings are verified. All top
command/exit/log receipts and all historical baseline/report/receipt/log joins
are checked. Historical improvements are recomputed against each unchanged
baseline, so inherited gains are not attributed to this optimization. Resource
statuses remain unhealthy under the runner policy; a legitimate nonzero top
runner exit is retained, while each historical gate must still pass.

No candidate record name, final source snapshot, test total, report status count
or receipt path is guessed. Root completes a separate selection file from
`selection-template.json` after observations exist, naming the actual adapter
record, seven top validation receipt paths and historical result directory.
Paths are relative to J; all seven report output names are already fixed by the
requested replay mapping. The selected output must be fresh. No candidate report
or baseline is written by this comparator.

After source review, root may run the eight data-only protocol groups:

```sh
python3 /tmp/eris-own-keys-one-pass-1/comparison-preparation/test_compare.py
```

Then root supplies the completed selection explicitly:

```sh
python3 /tmp/eris-own-keys-one-pass-1/comparison-preparation/compare.py --selection /tmp/eris-own-keys-one-pass-1/comparison-selection.json
```

These commands have not been run by the author. Only source AST parsing,
ordinary file copies/hashes and inert JSON/schema inventory reads were performed.
No project module, runner, parser, adapter, compiler or test was executed. The
full candidate comparison remains pending actual root observations and review.
