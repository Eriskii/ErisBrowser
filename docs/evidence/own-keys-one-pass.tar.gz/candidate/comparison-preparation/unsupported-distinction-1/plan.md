# Additive unsupported-observation distinction

Original comparator, tests and source-ready.json remain unchanged. The original
policy guard conflated source-policy exclusions with engine observations.
The complete frozen predecessor has 3,911 cases excluded before execution,
216 parse-unsupported observations and 163 runtime-unsupported observations.

compare-2.py keeps each pre-excluded row exact and keeps all existing case,
policy, control, prior-pass and baseline requirements. Changed engine-observed
unsupported rows are preserved in full changed_rows and status transitions,
listed separately as engine_unsupported_changes and review_findings, and cause
status=findings/exit1 for explicit root review. They are never automatically
called policy drift or newly passing. This includes resource-to-unsupported
progress as well as changed existing engine-unsupported observations. A former
pass that becomes unsupported still triggers the independent fatal loss check.

The original eight protocol test bodies are AST-identical. Two new groups cover
a resource-to-runtime-unsupported finding and actual pre-excluded reason drift.
All ten groups remain unexecuted by the author. Only source AST and inert JSON
classification/count/hash work was performed. No actual candidate rows exist
or are inferred by this correction. The selection template remains unset.

After peer review, root may execute:

    python3 /tmp/eris-own-keys-one-pass-1/comparison-preparation/test_compare-2.py
    python3 /tmp/eris-own-keys-one-pass-1/comparison-preparation/compare-2.py --selection /tmp/eris-own-keys-one-pass-1/comparison-selection.json

The second command requires root's completed observed selection. It is not
ready to run merely because the source correction is held.
