The first actual eleven-group protocol run retained ten passes and one failed
fixture oracle. The existing test read only the for-of report but asserted the
combined four-module population. The complete population is two literal IDs in
for-of and two literal IDs in labels. test_compare-4.py checks both exact ordered
ID lists, the literal unsupported reason and absent engine observation, then
validates all four rows. It preserves the existing expected-unsupported control
checks and the other ten test bodies. compare-3.py is byte-identical; the real
45-report comparison was already clear and needs no rerun for this test-only fix.

The original held test source, failed receipt and complete log are retained.
This is a source/data correction only; no test or comparator was executed by
the author. Root may run test_compare-4.py after peer review.
