"""Source-only protocol tests; root may run these after review. No engines."""
import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('own_keys_report_comparison', ROOT/'compare-2.py')
COMPARATOR = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(COMPARATOR)


def load(name):
    return json.loads((ROOT/'before'/name).read_bytes())


def recount(report):
    report['counts'] = dict(COMPARATOR.Counter(r['status'] for r in report['cases']))


class ComparisonProtocols(unittest.TestCase):
    def setUp(self):
        COMPARATOR.errors.clear()
        COMPARATOR.review_findings.clear()
        COMPARATOR.inputs.clear()
        self.before = load('upstream-1.json')
        self.after = copy.deepcopy(self.before)
        self.entry = dict(name='typedarray-to-reversed', profile='typedarray-to-reversed', local=False)
        self.before_root = Path('/tmp/eris-typedarray-to-reversed-1')

    def compare(self):
        return COMPARATOR.compare(self.entry, self.before, self.after, self.before_root)

    def test_resource_to_pass_is_retained_as_a_new_pass(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row.update(status='passed', observation=dict(status='complete', phase='runtime',
            error_type='', error_identity='', message='', harness=''))
        recount(self.after)
        result = self.compare()
        self.assertEqual(result['newly_passing'], [row['id']])
        self.assertEqual(result['exact_case_rows'], 17)
        self.assertEqual(result['changed_rows'][0]['before']['status'], 'resource')
        self.assertEqual(result['changed_rows'][0]['after'], row)
        self.assertFalse(COMPARATOR.errors)
        self.assertFalse(result['after_health']['report_healthy'])

    def test_resource_detail_change_retains_full_rows_without_a_gain(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row['observation']['message'] += ' synthetic protocol witness'
        result = self.compare()
        self.assertEqual(result['exact_case_rows'], 17)
        self.assertEqual(result['newly_passing'], [])
        self.assertEqual(result['changed_rows'][0]['after'], row)
        self.assertFalse(COMPARATOR.errors)

    def test_resource_to_failure_is_not_counted_as_a_pass(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row.update(status='failed', observation=dict(status='exception', phase='runtime',
            error_type='Test262Error', error_identity='', message='synthetic assertion', harness=''))
        recount(self.after)
        result = self.compare()
        self.assertEqual(result['resource_to_failed'], [row['id']])
        self.assertEqual(result['newly_passing'], [])
        self.assertFalse(COMPARATOR.errors)

    def test_prior_pass_loss_is_an_explicit_finding(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'passed')
        sample = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row.update(status='resource', observation=copy.deepcopy(sample['observation']))
        recount(self.after)
        result = self.compare()
        self.assertEqual(result['prior_pass_losses'], [row['id']])
        self.assertEqual(result['new_resource_stops'], [row['id']])
        self.assertIn(['typedarray-to-reversed', 'prior-pass losses', [row['id']]], COMPARATOR.errors)

    def test_population_and_policy_cannot_be_discounted_as_work_changes(self):
        self.after['cases'][0]['source_sha256'] = '0'*64
        self.after['runner_policy']['synthetic_change'] = True
        self.after['runner_policy_sha256'] = COMPARATOR.sha(json.dumps(
            self.after['runner_policy'], sort_keys=True).encode())
        self.compare()
        self.assertTrue(any('case identity drift' in r for r in COMPARATOR.errors))
        self.assertTrue(any('policy or population drift' in r for r in COMPARATOR.errors))
        self.after['cases'].reverse()
        with self.assertRaises(AssertionError):
            self.compare()

    def test_forged_pass_and_wrong_control_identity_are_rejected(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row['status'] = 'passed'
        with self.assertRaises(AssertionError):
            COMPARATOR.validate_observation(row)
        self.after = copy.deepcopy(self.before)
        control = next(r for r in self.after['harness_preflight']
            if r['name'].startswith('typedarray-to-reversed-') and r['expected'] == 'failed')
        control['result']['observation'].update(error_type='TypeError', error_identity='TypeError')
        with self.assertRaises(AssertionError):
            self.compare()

    def test_existing_module_and_unsupported_control_variants_are_valid(self):
        modules = load('regressions-candidate-1/for-of.json')
        rows = [r for r in modules['cases'] if r['mode'] == 'module']
        self.assertEqual(len(rows), 4)
        for row in rows:
            COMPARATOR.validate_observation(row)
        total = 0
        for profile in ('regexp', 'template-literal'):
            report = load('regressions-candidate-1/'+profile+'.json')
            total += sum(r['expected'] == 'unsupported' for r in report['harness_preflight'])
            self.assertTrue(COMPARATOR.controls_health(report, profile, False))
        self.assertEqual(total, 4)

    def test_resource_to_engine_unsupported_requires_review_without_policy_drift(self):
        row = next(r for r in self.after['cases'] if r['status'] == 'resource')
        row.update(status='unsupported', observation=dict(status='unsupported', phase='runtime',
            error_type='UnsupportedFeature', error_identity='', message='synthetic later feature', harness=''))
        recount(self.after)
        result = self.compare()
        self.assertEqual(result['engine_unsupported_changes'], [row['id']])
        self.assertEqual(result['newly_passing'], [])
        self.assertEqual(result['transitions']['resource -> unsupported'], 1)
        self.assertEqual(result['changed_rows'][0]['before']['status'], 'resource')
        self.assertEqual(result['changed_rows'][0]['after'], row)
        self.assertFalse(COMPARATOR.errors)
        self.assertEqual(COMPARATOR.review_findings, [
            ['typedarray-to-reversed', row['id'], 'engine unsupported observation changed']])

    def test_policy_exclusion_reason_remains_byte_exact(self):
        row = next(r for r in self.after['cases']
                   if r['status'] == 'unsupported' and 'observation' not in r)
        row['reason'] += ' synthetic policy edit'
        result = self.compare()
        self.assertEqual(result['engine_unsupported_changes'], [])
        self.assertEqual(result['newly_passing'], [])
        self.assertEqual(COMPARATOR.errors, [
            ['typedarray-to-reversed', row['id'], 'policy-excluded row changed']])
        self.assertFalse(COMPARATOR.review_findings)

    def test_historical_baseline_improvements_are_reconstructed(self):
        index = load('regression-plan.json')
        entry = next(e for e in index['profiles'] if e['profile'] == 'array-find')
        report = load('regressions-candidate-1/array-find.json')
        baseline = load('worktree/'+entry['baseline'])
        COMPARATOR.baseline_check(report, baseline)
        report['improvements'].append('synthetic unearned pass')
        with self.assertRaises(AssertionError):
            COMPARATOR.baseline_check(report, baseline)


if __name__ == '__main__':
    unittest.main()
