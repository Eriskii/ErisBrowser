The held second version's row validator accepted observation:null like an
absent observation, but its exclusion predicate only checked key absence.
This additive correction aligns both predicates with get('observation') is None.
Exactly two comparator lines change. Engine observations remain dictionaries;
policy-excluded rows remain exact. Resource-to-unsupported with explicit null
now produces a policy-excluded-row finding rather than escaping both branches.

All ten previous test bodies are AST-identical. One added negative protocol
witness requires the null row to be retained in full changed_rows, classified as
a policy-exclusion change, and never counted as a pass or engine observation.
Earlier sources, holds and Layout's finding receipt remain unchanged. No actual
candidate report was read or inferred and no test/comparator was executed.

Root's reviewed commands should now select test_compare-3.py and compare-3.py.
The comparison still needs a separate completed selection JSON naming the
observed final candidate and receipts. No guessed counts were added.
