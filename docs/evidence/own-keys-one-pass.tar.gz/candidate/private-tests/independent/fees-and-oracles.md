# Independent one-pass stored-string tests

The ten groups in `tests.raw.rs` were authored from the revised proposal and
ledger, current published `own_keys.rs`, and the current for-in continuation.
The new production draft was not read. No Rust/JS, project tools, formatter,
compiler, or test was executed. Root owns copying, registration, and execution.

All totals include the unchanged caller route4 unless marked helper-only. N is
the creation-order tag count, S retained strings, j the first accepted string
ordinal, and J `size_of::<JsString>()`.

The revised successful nonempty fee is `16 + 6*N + 4*S`: caller4, helper4,
first reserve8, probe6 for every reached tag, and reacquire2 plus clone/push2 for
every accepted string. Storage is `(N-j)*J`, not S*J. This explicitly retains
unused capacity for later symbols and makes the heap tradeoff testable. The
all-symbol fee is `8+6*N` with no reserve work or output heap. No test assumes
that `try_reserve_exact` guarantees a platform-independent exact capacity;
the requested capacity and charged bytes are exact and actual capacity must be
at least that request.

| Literal shape | Whole work | Charged slots |
| --- | ---: | ---: |
| Eight retained strings | 96 | 8 |
| Eight strings plus two later symbols | 108 | 10 |
| Two leading symbols plus eight strings | 108 | 8 |
| Eight symbols | 56 | 0 |
| Eight strings, for-in snapshot with no TypedArray records | 100 | 8 |
| Same snapshot, one authentic unrelated TypedArray record | 112 | 8 |

The last row keeps the existing4 negative record lookup,4 route selector,8
proof construction and96 ordinary snapshot. It does not change or waive any
descriptor/visited/prototype fee.

Literal accepted strings include empty text, NUL, lone high and low surrogates,
non-ASCII code units, +1 and -0. Eight distinct retained names of lengths2,512,
4096 all use the same96 work and8*J bytes. Success must share the original UTF16
payload pointers. Symbols never enter the string output; source creation order,
descriptors and arena count remain unchanged on success or refusal.

A digit as the first string after j leading symbols costs helper-only `10+6*j`
and allocates nothing. The10 figure is specifically j=0. Conservative rejected
keys include0,01,10,2,4294967295 and a very long digit-leading ordinary name.
Numeric classification remains the old generic builder's responsibility.

For eight strings with an ordinary digit-looking `01`, these are independent
helper and complete-operation endpoints:

| `01` ordinal | Helper work | Whole work | Temporary slots |
| --- | ---: | ---: | ---: |
| 0 | 10 | 156 | 0 |
| 1 | 28 | 174 | 8 |
| 7 | 88 | 234 | 8 |

All three complete generic outputs are already rank-sorted ordinary creation
orders, so the unchanged suffix is count9 + retained-stage112 + seven rank
comparisons21 =142, plus caller4 and the helper. The generic builder also charges
`8*(sizeof(OwnKey)+J)`. The seven-string late rejection is therefore more
expensive than the old proof and retains both cumulative allocations. A separate
mixed numeric case freezes `0,2,10,tail,01,4294967295,alpha,beta` and original Rc
payload identity without generating the oracle from the numeric parser.

For eight accepted strings, the reached stages are caller4, helper8, probe14,
reserve22, reacquire/clone26, then six-plus-four per remaining string through96.
The test tries every whole-operation allowance0..96. Heap is admitted exactly
at22, even if a later work limit retires the private temporary Vec. A failed
heap charge with full96 work leaves74 work. With two leading symbols, reserve
occurs at34 out of108 and also leaves74. With two trailing symbols it occurs
at22 out of108, charges10 slots and leaves86. Source state is never published or
mutated by these scratch operations.

For seven strings then `01`, complete helper exit is92 including caller; the
unchanged count stage ends101 and generic staging admission ends213. The final
seven comparison debits end234. Tests cut work and heap on both sides of the
temporary allocation at22 and generic allocation at213. First-allocation heap
failure leaves212 work; generic heap failure leaves21. Failed charges preserve
the established cumulative counter behavior, including exceeding MAX_HEAP.
The tests do not reset that outcome to manufacture a zero-cost rejection.

Small ordinary orders, Array holes/virtual length, boxed strings and authentic
TypedArray dense keys retain literal output controls. An authored strict/sloppy
for-in case deletes and hides later keys, removes/reinserts a snapshotted name,
adds an unsnapshotted name, replaces the prototype and grows the TypedArray table.
It separately shrinks a tracking view after its first indexed key. These freeze
the existing fresh-descriptor and fresh-prototype/buffer behavior. The proposal
stores no live descriptor or prototype cache.

Existing published tests are not modified here. The earlier seven ordinary
snapshot groups still require separately reviewed fee/storage migrations. No
54-row SetKey table or authored conformance body needs alteration for this
helper experiment. The complete old descriptor-case saving and any timing
change remain unmeasured until root execution; the shared20/18 component alone
predicts44 work saved per snapshot,880 across20, and640 added bytes on16-byte
handles, with no claim of a universal improvement or quota change.

Proposed integration: copy this raw file to a new child such as
`src/script/own_keys/one_pass_tests.rs` and register that child from own_keys.rs.
Keep the raw hold before root formatting. No production draft was consulted to
create these assertions.
