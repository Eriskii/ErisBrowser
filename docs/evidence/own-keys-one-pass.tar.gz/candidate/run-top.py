"""Root-only concurrent replay of unchanged complete TypedArray profiles."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
BINARY = Path(sys.argv[1]).resolve()
DIGEST = hashlib.sha256(BINARY.read_bytes()).hexdigest()
ROWS = [("typedarray-to-reversed", "to-reversed-1"),
        ("typedarray-reverse", "reverse-1"),
        ("typedarray-fill", "fill-1"),
        ("typedarray-search", "search-1"),
        ("typedarray-views", "views-1"),
        ("typedarray-foundation", "foundation-1"),
        (None, "local-1")]


def run(row):
    profile, label = row
    output = ROOT / (label + ".json")
    if profile is None:
        command = ["python3", "tools/typedarray_views_local.py", "--engine", str(BINARY),
                   "--engine-sha256", DIGEST, "--output", str(output)]
    else:
        command = ["python3", "tools/test262_conformance.py", "--profile", profile,
                   "--binary", str(BINARY), "--output", str(output), "--jobs", "2"]
    completed = subprocess.run(["python3", str(ROOT / "run-tool.py"), label, *command],
                               stdout=subprocess.PIPE, stderr=subprocess.STDOUT, close_fds=True)
    (ROOT / "validation" / (label + "-wrapper.log")).write_bytes(completed.stdout)
    assert completed.returncode in (0, 1), (profile, completed.returncode)
    report = json.loads(output.read_bytes())
    assert report["binary_sha256"] == DIGEST
    result = dict(profile=profile or "local", exit=completed.returncode,
                  counts=report.get("counts", report.get("summary")),
                  controls_healthy=report.get("harness_preflight_passed"))
    print(json.dumps(result), flush=True)
    return result


with ThreadPoolExecutor(max_workers=3) as pool:
    results = list(pool.map(run, ROWS))
assert hashlib.sha256(BINARY.read_bytes()).hexdigest() == DIGEST
with (ROOT / "top-replay.json").open("x") as output:
    json.dump(dict(binary=str(BINARY), sha256=DIGEST, results=results), output, indent=2)
    output.write("\n")
