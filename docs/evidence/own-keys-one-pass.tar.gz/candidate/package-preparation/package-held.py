"""Package the reviewed enumeration optimization and test handshake correction.

Root executes this data-only publisher after reviews. Raw attempts are retained;
engine/benchmark binaries, build trees and future-method drafts are excluded.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

J = Path(__file__).resolve().parent
I = Path('/tmp/eris-typedarray-to-reversed-1')
W = J / 'worktree'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return json.loads(path.read_bytes())


def bound(row):
    path = Path(row['path'])
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], path


adapter = read(J/'candidate-adapter-1.json')
binary = J/adapter['binary']
assert binary.stat().st_size == adapter['bytes'] and sha(binary.read_bytes()) == adapter['sha256']
assert adapter['source_binding'] == 'compiled-source-3.json'
source_path = J/adapter['source_binding']
assert sha(source_path.read_bytes()) == adapter['source_binding_sha256']
sources = read(source_path)
assert sources['base'] == '58431abc392f0e4ee50dcae79ecec902241da009'
assert len(sources['source_sha256']) == 284
for name, digest in sources['source_sha256'].items():
    assert sha((W/name).read_bytes()) == digest, name
comparison = read(J/'comparison.json')
assert comparison['status'] == 'clear'
assert comparison['errors'] == comparison['review_findings'] == []
assert comparison['after_adapter_sha256'] == adapter['sha256']
assert comparison['before_adapter_sha256'] == '35807b37c8a57554ca44419c98ec61dbb7d4e6adc80af8997c690bd49ee538ac'
assert comparison['summary'] == dict(profiles=45,historical_profiles=38,case_rows=18298,
    exact_case_rows=18298,control_rows=4284,exact_control_rows=4284,changed_case_rows=0,
    changed_control_rows=0,prior_pass_losses=0,newly_passing=0,resource_to_failed=0,
    new_resource_stops=0,engine_unsupported_changes=0)
for row in comparison['inputs']:
    bound(row)

checks = {'baseline-own-keys-1':52,'one-pass-focused-1':11,'own-keys-all-1':62,
          'full-native-1':2371,'full-default-1':2214,'script-198-1':1359,
          'clippy-msrv-1':None,'clippy-198-1':None,'format-check-1':None,
          'prior-pass-1':1,'top-replays-1':None,'regressions-1':None,'adapter-1':None,
          'comparison-protocols-2':None,'comparison-1':None,
          'benchmark-before-build-1':None,'benchmark-before-preflight-1':None,
          'benchmark-after-build-2':None,'benchmark-run-1':None}
check_records = {}
for label, count in checks.items():
    receipt = read(J/'validation'/(label+'.json'))
    assert receipt['exit'] == 0, label
    log = (J/'validation'/receipt['log']).read_bytes()
    assert sha(log) == receipt['sha256'], label
    if count is not None:
        assert sum(map(int,re.findall(rb'test result: ok\. (\d+) passed;',log))) == count, label
    if label == 'comparison-protocols-2':
        assert re.search(rb'Ran 11 tests in ',log) and re.search(rb'\nOK\s*$',log)
    check_records[label] = receipt
assert adapter['full_suite'] == 'validation/full-native-1.json'
assert adapter['full_suite_passed'] == 2371 and adapter['build'] == 'validation/adapter-1.json'
assert check_records['comparison-1']['command'] == ['python3',str(J/'comparison-preparation/compare-3.py'),
    '--selection',str(J/'comparison-selection.json')]
assert check_records['comparison-protocols-2']['command'] == ['python3',str(J/'comparison-preparation/test_compare-4.py')]

benchmark = read(J/'benchmark/run-1/summary.json')
assert benchmark['status'] == 'complete' and benchmark['rounds'] == 3 and len(benchmark['runs']) == 6
assert [r['label'] for r in benchmark['runs']] == ['before','after','after','before','before','after']
for row in benchmark['runs']:
    assert row['returncode'] == 0 and not row['timed_out']
    bound(row['stdout']); bound(row['stderr'])
    assert row['stderr']['bytes'] == 0
    assert len(row['statistics']) == 8 and all(s['samples'] == 21 for s in row['statistics'])
    lines = Path(row['stdout']['path']).read_text().splitlines()
    assert len(lines) == 170 and lines[-1] == 'END\t168\t840'
assert read(J/'benchmark/run-1/inputs-before.json') == read(J/'benchmark/run-1/inputs-after.json')
for phase in ['before','after']:
    record = read(J/'benchmark'/(phase+'-binary.json'))
    payload = Path(record['binary']).read_bytes()
    assert len(payload) == record['bytes'] and sha(payload) == record['sha256']
    assert sha(Path(record['engine_source']).read_bytes()) == record['engine_source_sha256']
    assert all(r['samples'] == 63 for r in benchmark['statistics'][phase])

diagnostics = dict(before=read(J/'diagnostics/before-observation.json'),
                   after=read(J/'diagnostics/after-observation-1.json'))
assert len(diagnostics['before']['rows']) == len(diagnostics['after']['rows']) == 21
assert len(diagnostics['after']['changes']) == 21
prior_pass = (J/'validation/prior-pass-1.log').read_text()
assert 'strict=false remaining=1241 records=10 allocated=4503410' in prior_pass
assert 'strict=true remaining=1241 records=10 allocated=4501440' in prior_pass
assert (W/'src/date_host.rs').read_bytes() == (J/'date-host-test-fix/date_host.before.rs').read_bytes()

reviews = {}
for name in ['observation-review.json','documentation-review.json']:
    review = read(J/name)
    assert review['status'].startswith('clear'), name
    assert review['files'], name
    for row in review['files']:
        bound(row)
    reviews[name] = dict(bytes=(J/name).stat().st_size,sha256=sha((J/name).read_bytes()))

records = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in records and not name.startswith('/') and '..' not in Path(name).parts, name
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), ('executables excluded',path)
    records[name] = data


for path in sorted(J.iterdir()):
    if path.is_file() and path.suffix in {'.json','.py','.md'} and path.name != 'publication.json':
        add(path,'candidate/'+path.name)
for directory in ['validation','implementation','private-tests','test-migration','diagnostics',
                  'date-host-test-fix','comparison-preparation','docs-preparation',
                  'package-preparation','regressions-candidate-1','benchmark']:
    root = J/directory
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        # A live package wrapper log changes after packaging. Keep publication
        # receipts outside the immutable archive they describe.
        if directory == 'validation' and path.name.startswith('package-'):
            continue
        if directory == 'benchmark' and path.name.startswith('eris-own-keys-'):
            continue
        add(path,'candidate/'+str(path.relative_to(J)))

# The frozen comparison preparation contains all45 predecessor reports and
# their receipts/baselines. Retain both complete selected source trees as well.
before_sources = read(I/'compiled-source-2.json')
for name,digest in sorted(before_sources['source_sha256'].items()):
    assert sha((I/'worktree'/name).read_bytes()) == digest, name
    add(I/'worktree'/name,'prior-source/'+name)
for name in sorted(sources['source_sha256']):
    add(W/name,'published-source/'+name)
changed = subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W).decode().splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W).decode().splitlines()
changed = sorted(set(changed))
for name in changed:
    if name.startswith('docs/evidence/') or name in sources['source_sha256']:
        continue
    assert name == 'README.md' or name.startswith(('docs/','src/','tests/','tools/','examples/')), name
    add(W/name,'published-source/'+name)
for row in comparison['inputs']:
    bound(row)
for name,digest in sources['source_sha256'].items():
    assert sha((W/name).read_bytes()) == digest, name
for name in reviews:
    assert sha((J/name).read_bytes()) == reviews[name]['sha256'], name
    for row in read(J/name)['files']:
        bound(row)
index = {name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(records.items())}
records['MANIFEST.json'] = encoded(index)
raw = io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as archive:
    for name,data in sorted(records.items()):
        entry = tarfile.TarInfo(name)
        entry.size,entry.mode,entry.mtime = len(data),0o644,0
        archive.addfile(entry,io.BytesIO(data))
compressed = io.BytesIO()
with gzip.GzipFile(fileobj=compressed,mode='wb',filename='',mtime=0) as stream:
    stream.write(raw.getvalue())
payload = compressed.getvalue()
destination = W/'docs/evidence/own-keys-one-pass.tar.gz'
summary_path = W/'docs/evidence/own-keys-one-pass.json'
assert not destination.exists() and not summary_path.exists()
summary = dict(feature='One-pass ordinary string-key snapshots and completed EOF test handshake',
    base=sources['base'],archive=destination.name,archive_bytes=len(payload),archive_sha256=sha(payload),
    manifest_sha256=sha(records['MANIFEST.json']),records=len(index),candidate_adapter=adapter,
    source_change_after_validation=None,checks=check_records,comparison_source='comparison-preparation/compare-3.py',
    comparison_protocol_source='comparison-preparation/test_compare-4.py',comparison=comparison,
    benchmark=benchmark,benchmark_table=read(J/'benchmark/derived-table.json'),
    benchmark_samples=1008,benchmark_timed_executes=5040,diagnostics=diagnostics,reviews=reviews,
    baseline_recorded=False,known_limits=[
        'No newly passing upstream cases; all45 prior reports remain exact, including resource limits and unsupported modes',
        'Later symbols reserve unused string slots; late numeric rejection incurs discarded scratch work and storage',
        'Local whole-script timings include small median slowdowns and several higher p95s; no significance or Chromium claim',
        'EOF test race was identified by source review; the original CI failure cause is not established by its log',
        'Full web compatibility, production security and the Chromium performance target remain unproved'],
    published_bindings={name:dict(bytes=(W/name).stat().st_size,sha256=sha((W/name).read_bytes()))
                        for name in changed if not name.startswith('docs/evidence/')})
destination.write_bytes(payload)
summary_path.write_bytes(encoded(summary))
with tarfile.open(destination) as archive:
    assert set(archive.getnames()) == set(records)
    for name,data in records.items():
        assert archive.extractfile(name).read() == data, name
print(json.dumps(dict(archive_bytes=len(payload),archive_sha256=sha(payload),records=len(index))))
