"""Package reviewed reverse source and observations. Root executes after review.

No engine, compiler, formatter or conformance runner is invoked. Existing raw
attempts and both comparator versions are retained; engine binaries are excluded.
"""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

H = Path(__file__).resolve().parent
G = Path('/tmp/eris-typedarray-fill-encoding-1')
W = H / 'worktree'
SELECTED_COMPARISON = 'comparison-2.json'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def read(path):
    assert path.is_file() and not path.is_symlink(), path
    return json.loads(path.read_bytes())


def bound(row):
    path = Path(row['path'])
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], path


adapter = read(H / 'candidate-adapter-1.json')
binary = H / adapter['binary']
assert binary.stat().st_size == adapter['bytes'] and sha(binary.read_bytes()) == adapter['sha256']
source_path = H / adapter['source_binding']
assert sha(source_path.read_bytes()) == adapter['source_binding_sha256']
sources = read(source_path)
assert sources['base'] == 'ee846e00686d63236e7aedb754a89cb2fd5fa9bf'
for name, digest in sources['source_sha256'].items():
    assert sha((W / name).read_bytes()) == digest, name
comparison = read(H / SELECTED_COMPARISON)
assert comparison['status'] == 'clear' and comparison['errors'] == []
assert comparison['after_adapter_sha256'] == adapter['sha256']
assert comparison['before_adapter_sha256'] == '5a88f7f061bc7f64dc9b5003aa4e2a33715932502b5bb8ee51084f3d8104e234'
assert comparison['summary'] == dict(profiles=43,historical_profiles=38,case_rows=18236,
    exact_case_rows=18236,control_rows=4180,exact_control_rows=4180,prior_pass_losses=0)
for row in comparison['inputs']:
    bound(row)
reverse = comparison['reverse']
assert reverse['case_rows'] == 44 and reverse['control_rows'] == 52
assert reverse['before_counts'] == dict(passed=4,failed=22,unsupported=18)
assert reverse['after_counts'] == dict(passed=22,resource=4,unsupported=18)
assert reverse['before_health']['controls_verified'] == 32
assert reverse['after_health']['controls_verified'] == 52
assert reverse['after_health']['preflight_healthy'] is True
assert reverse['after_health']['report_healthy'] is False

# These are actual reported final checks, not predictions. Earlier attempts,
# including the first strict-Clippy failure, are archived below unchanged.
checks = {'reverse-focused-1':12,'metadata-1':8,'full-native-2':2342,'script-198-2':1333,
          'clippy-msrv-1':None,'clippy-198-2':None,'format-check-2':None,
          'protocols-1':None,'import-reverse-1':None,'prior-pass-1':None,
          'regressions-1':None,'adapter-1':None,'comparison-2':None}
check_records = {}
for label, count in checks.items():
    receipt = read(H / 'validation' / (label + '.json'))
    assert receipt['exit'] == 0, label
    log = (H / 'validation' / receipt['log']).read_bytes()
    assert sha(log) == receipt['sha256'], label
    if count is not None:
        assert sum(map(int,re.findall(rb'test result: ok\. (\d+) passed;',log))) == count, label
    if label == 'protocols-1':
        assert re.search(rb'Ran 311 tests in ',log) and re.search(rb'\nOK\s*$',log), label
    check_records[label] = receipt
assert adapter['full_suite'] == 'validation/full-native-2.json'
assert adapter['full_suite_passed'] == 2342 and adapter['build'] == 'validation/adapter-1.json'
assert check_records['comparison-2']['command'] == ['python3',str(H/'compare-2.py')]

reports = {}
for phase, raw_name in [('before','upstream-before.json'),('after','upstream-1.json')]:
    raw = (H / raw_name).read_bytes()
    published = W / 'tests/conformance' / ('test262-typedarray-reverse-' + phase + '.json')
    assert raw == published.read_bytes(), published
    report = json.loads(raw)
    expected_binary = comparison['before_adapter_sha256'] if phase == 'before' else adapter['sha256']
    assert report['binary_sha256'] == expected_binary
    assert report['counts'] == reverse[phase+'_counts']
    reports[phase] = dict(path=str(published.relative_to(W)),bytes=len(raw),sha256=sha(raw),
                         counts=report['counts'],controls=52,
                         verified_controls=sum(r['verified'] for r in report['harness_preflight']))
    if phase == 'after':
        assert [r['id'] for r in report['cases'] if r['status'] == 'resource'] == [
            'test/built-ins/TypedArray/prototype/reverse/'+name+':'+mode
            for name in ['preserves-non-numeric-properties.js','reverts.js']
            for mode in ['sloppy','strict']]

reviews = {}
for name in ['observation-review.json','documentation-review.json']:
    review = read(H / name)
    assert review['status'].startswith('clear'), name
    assert review['files'], name
    for row in review['files']:
        bound(row)
    reviews[name] = dict(bytes=(H/name).stat().st_size,sha256=sha((H/name).read_bytes()))

records = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in records and not name.startswith('/') and '..' not in Path(name).parts, name
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), ('engine/executable excluded',path)
    records[name] = data


for path in sorted(H.iterdir()):
    if path.is_file() and path.suffix in {'.json','.py','.md'}:
        add(path,'candidate/'+path.name)
for directory in ['validation','implementation','private-tests','metadata-migration','browser',
                  'conformance','comparison-preparation','package-preparation','regressions-candidate-1']:
    root = H / directory
    assert root.is_dir(), root
    for path in sorted(root.rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        # The running wrapper creates this log before package execution and
        # finishes it afterward. Publication records stay outside their archive.
        if directory == 'validation' and path.name.startswith('package-'):
            continue
        if '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        add(path,'candidate/'+str(path.relative_to(H)))

# Preserve all compared published reports and their receipts/logs/baselines.
# The predecessor timing experiment is unrelated to this new method and is
# already published in its own closed archive.
prior_names = ['upstream-1.json','search-1.json','foundation-1.json','views-1.json','local-1.json',
               'candidate-adapter-2.json','compiled-source-1.json','regression-plan.json']
for name in prior_names:
    add(G/name,'prior/'+name)
for stem in ['upstream-1','search-1','foundation-1','views-1','local-1','adapter-2','full-native-1']:
    receipt = read(G/'validation'/(stem+'.json'))
    add(G/'validation'/(stem+'.json'),'prior/validation/'+stem+'.json')
    add(G/'validation'/receipt['log'],'prior/validation/'+receipt['log'])
plan = read(H/'regression-plan.json')
for selection in plan['profiles']:
    for suffix in ['.json','.log','-receipt.json']:
        name = selection['profile']+suffix
        add(G/'regressions-candidate-1'/name,'prior/regressions-candidate-1/'+name)
    add(W/selection['baseline'],'preserved-baselines/'+selection['baseline'])

for name in sorted(sources['source_sha256']):
    add(W/name,'published-source/'+name)
changed = subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W).decode().splitlines()
changed += subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W).decode().splitlines()
changed = sorted(set(changed))
allowed_roots = {'README.md','COMPATIBILITY.md','ROADMAP.md','SECURITY.md','Cargo.toml','Cargo.lock'}
for name in changed:
    if name.startswith('docs/evidence/') or name in sources['source_sha256']:
        continue
    assert name in allowed_roots or name.startswith(('.github/','docs/','src/','tests/','tools/','examples/')), name
    add(W/name,'published-source/'+name)
index = {name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(records.items())}
records['MANIFEST.json'] = encoded(index)
raw = io.BytesIO()
with tarfile.open(fileobj=raw,mode='w') as archive:
    for name,data in sorted(records.items()):
        item = tarfile.TarInfo(name)
        item.size,item.mode,item.mtime = len(data),0o644,0
        archive.addfile(item,io.BytesIO(data))
compressed = io.BytesIO()
with gzip.GzipFile(fileobj=compressed,mode='wb',filename='',mtime=0) as stream:
    stream.write(raw.getvalue())
payload = compressed.getvalue()
destination = W/'docs/evidence/typedarray-reverse.tar.gz'
summary_path = W/'docs/evidence/typedarray-reverse.json'
assert not destination.exists() and not summary_path.exists()
summary = dict(feature='Number TypedArray.prototype.reverse',base=sources['base'],
    archive=destination.name,archive_bytes=len(payload),archive_sha256=sha(payload),
    manifest_sha256=sha(records['MANIFEST.json']),records=len(index),candidate_adapter=adapter,
    source_change_after_validation=None,checks=check_records,comparison_source='compare-2.py',
    selected_comparison=SELECTED_COMPARISON,comparison=comparison,reports=reports,reviews=reviews,
    reverse_case_count=44,reverse_control_count=52,upstream_report_healthy=False,baseline_recorded=False,
    benchmark_performed=False,
    known_limits=['Four reverse modes stop at the unchanged resource budget',
                  '18 modes excluded by BigInt/immutable/helper/host policy; originals retained',
                  'Before passes with unhealthy reverse controls do not establish method support',
                  'No full conformance, performance, full-web compatibility or production-security claim'],
    published_bindings={name:dict(bytes=(W/name).stat().st_size,sha256=sha((W/name).read_bytes()))
                        for name in changed if not name.startswith('docs/evidence/')})
destination.write_bytes(payload)
summary_path.write_bytes(encoded(summary))
with tarfile.open(destination) as archive:
    assert set(archive.getnames()) == set(records)
    assert archive.extractfile('MANIFEST.json').read() == records['MANIFEST.json']
    for name,row in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
print(json.dumps(dict(archive_bytes=len(payload),archive_sha256=sha(payload),records=len(index))))
