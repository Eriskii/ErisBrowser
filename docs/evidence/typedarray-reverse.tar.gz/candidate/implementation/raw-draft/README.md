# Reverse source draft and transfer contract

This directory is a future source-only draft. Nothing here has been copied into the current worktree. No compiler, formatter, project import, tests or engine ran. `candidate/` contains exactly three proposed production files; `before/`, `implementation.patch`, `preservation.json` and `ledger.json` make the change reviewable. The current fill optimization remains frozen and independent.

## Production and specification

The proposed `typed_array/reverse.rs` supplies `typed_array_reverse(&mut self, receiver: Value, record: Record) -> Result<Value>`. The parent adds only `mod reverse` and the native dispatch arm. The metadata source appends `TypedArray.reverse`, length0, as bag ordinal38 after all38 current bags. Its shared property is writable/configurable and nonenumerable. No changes to machine dispatch are required: the existing TypedArray native prefix route and temporary-name preflight already handle this native; construction falls through the existing nonconstructor rejection.

The [current reverse algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.reverse), read2026-10-08, validates the receiver, takes its internal length, then reads both elements and writes lower followed by upper for each pair. Empty and one-element receivers still validate. Return the original receiver. There are no body argument conversions, species lookups or author callbacks. Caller-side evaluation of supplied argument expressions remains ordinary JavaScript evaluation.

Initial validation uses the existing copied Record and live-buffer machinery. Each subsequent scalar read/write deliberately retains its existing fresh witness and complete fees. The midpoint is never read or rewritten on odd lengths. Integer wrapping, Uint8Clamped conversion, signed zero, Float16 rounding and current canonical NaN behavior use unchanged helpers. Nonshared storage cannot detach or resize inside this callback-free loop. BigInt/shared/immutable/proxy/realm expansion is outside this draft.

The base body fee is25: setup8, initial live/length13, midpoint/lower setup4. Each pair prepays8 for upper-index arithmetic, loop control and lower-index advance, then executes two scalar reads followed by two scalar writes. The exact width-dependent rows and ordered partial-write boundaries are in `ledger.json`. Both reads finish before the first mutation. A resource refusal can preserve completed earlier pairs and only the lower write of the current pair; it cannot expose a partly written scalar. This follows the unchanged writer and is an explicit test contract, not a promise of pair-atomic mutation.

## Metadata and bootstrap

Append pooled `reverse` at index36 and the new method after the old native-bag sequence. Sorted shared storage inserts `reverse` between `length` and `subarray`; its observable creation-order key is appended after `fill`. The old creation-order prefix, saved identities and Array.toString alias remain exact. `preservation.json` independently reconstructs both orderings and the literal/native prefixes.

The graph becomes39 bags,117 properties and28 direct natives:38 small leaves with98 entries, plus19 shared entries across three nodes. Nineteen stays on the same small-sort path; retain the64-work right-border allowance and all48 scratch pairs. The upfront metadata work increases by170; text, object and native helpers contribute the remaining57. Total startup delta is227 work and2110 bytes including one reserved arena slot. `METADATA_OBJECTS` automatically increases the existing DOM arena reservation by one; no new registry entry, global binding, Runtime field or quota is introduced.

The draft forecasts site8065work/77835bytes, raw1848work/1699225bytes and738objects/capacity, using the existing reported raw2075/1697115/737 baseline. These are source-derived forecasts until root performs a fresh raw diagnostic. The earlier short recommendation's2104-byte forecast is retained unchanged: the detailed ledger corrects it upward by6 because the pooled name pays two UTF16 copies (`64+4*7=92`), not one. Existing native registry299, prototypes25 and public execution-budget reset remain unchanged.

## Planned private validation

Before transfer/execution, freeze independent literal cases and genuine positive/wrong controls. The intended private suite covers:

1. All ten kinds and literal even/odd orders, including empty and one-element identity; a second call restores the numeric contents. No Array.reverse prerequisite is used.
2. Nonzero aligned view offsets with unchanged backing sentinels; independent whole-byte integer, signed-zero and float literals. Preserve the odd midpoint's existing bytes because it is not visited.
3. Initial unbranded, detached and OOB rejection, valid zero-length tracking views, fixed/tracking views after resize, and saved method identity. Preserve ordinary expandos and ignore poisoned public length/constructor/index metadata.
4. Ignored extra argument conversion hooks and poisoned species/constructor accessors. Distinguish ordinary evaluation of argument expressions from forbidden conversion inside reverse.
5. Literal body exact/one-short cuts: base25 for length0/1; loop/each read admission; lower-store exact/one-short and upper-store exact/one-short for every width. For `[1,2,3,4]`, after only the first lower store expect `[4,2,3,4]`; after the first full pair expect `[4,2,3,1]`. Inspect complete backing bytes without altering observed counters.
6. Same-value pair stores must retain their full scalar work. Body allocation remains zero at MAX_HEAP. Existing read/write/codec helpers and their tests keep all old fees.
7. Genuine saved Runtime.call exact/one-short work and50-byte native-name allocation boundaries, call guard cleanup, immutable cached bag contents and unchanged object/record counts. Whole-call totals require root observation; do not invent them from body fees alone.
8. Independent installer full work/heap endpoints, one-short refusal, full old38-bag identity/order preservation, descriptor/name/length/function-prototype metadata and nonconstructibility. Use malformed18-capacity/shared19 fixtures to retain the shape guard's real failure.

## Existing-test migration list

No test file is edited in this draft. Root should retain before-images and make only justified new graph/count/fee changes:

- `typed_array/intrinsics/views_tests.rs`: append reverse metadata and old38 preservation coverage; graph39/117/28, shared19,41 tree blocks and67 staging/scratch pairs. Pool bytes3828 and native name bytes439. Site work8065, heap77835 and total marginal24159 relative to the original31-bag installation including eight new arena slots. Initial precharge5216 replaces5046; all one-short and malformed-shape checks remain meaningful.
- `typed_array/tests.rs`, `bootstrap_tests.rs`, `dom_bindings/identity_tests.rs`: preserve prior raw observations; update only descriptive forecast/count expressions after the fresh raw diagnostic actually matches1848/1699225/738. Keep quotas, public reset, failure categories and one-short boundaries unchanged.
- `array_splice/set_key_fee_tests.rs`: preserve all54 historical BEFORE rows and semantic outcomes. Its absent shared-owner count changes from18 to19; relative to the retained13 baseline, owner-growth factor5 becomes6 only for the same scenario0 Reflect/splice lookup routes. Assignment, own-descriptor scenarios, classifier fees and heap endpoints do not change. Review every affected row algebraically before execution.

## Complete upstream and browser validation plan

The existing pinned complete TypedArray tree lists reverse subtree `cfbd5368520d987e1256f9981c2e587d898f1df7`:22 original bodies,16 direct and6 BigInt. Preserve the complete subtree, required raw helpers/legal files and root-linked proofs in a separate future profile. Modes and exclusions are not yet derived because this draft has not fetched/imported those raw bodies. Keep BigInt, immutable and host/helper limitations explicit; no result-driven filtering or altered original source. Freeze a production-equivalent predecessor and health controls before implementation execution.

Root should run the new semantic/admission tests, existing scalar and metadata tests, supported MSRV/full-native checks and strict Clippy/format checks. Compare complete prior-profile observations, especially the historical TypedArray descriptor/for-in case sensitive to additional shared prototype members; aggregate pass totals cannot hide a prior-pass resource regression. Keep the current fill profile, its controls and the two recovered original lastIndexOf cases unchanged. A Page plus actual confined-worker witness should use independent literal before/after order, a genuine hit/click, original receiver identity and saved method invocation, with existing process cleanup and pixel/text evidence. No current test or benchmark outcome is claimed by this draft.
