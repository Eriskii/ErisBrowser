# Independent reverse private tests

The twelve groups are authored from ECMA-262 23.2.3.25 and the existing scalar
helper contracts. No compiler, formatter, parser, JavaScript, renderer or test
was run by the author. The test module belongs under
`script::typed_array::reverse::tests`; root owns its registration and execution.

The copied-Record body and complete saved native call are separate boundaries.
The body always pays 8 setup + 13 live-length validation + 4 midpoint setup = 25,
including valid empty and singleton views. Each pair pays 8 for loop/index
control, two admitted reads, then lower and upper admitted writes.

| Kinds | Read R | Write W | Pair 8+2R+2W | First lower store, pair-local |
| --- | ---: | ---: | ---: | ---: |
| Int8, Uint8 | 77 | 69 | 300 | 231 |
| Uint8Clamped | 77 | 85 | 332 | 247 |
| Int16, Uint16, Float16 | 80 | 72 | 312 | 240 |
| Int32, Uint32, Float32 | 86 | 78 | 336 | 258 |
| Float64 | 98 | 90 | 384 | 294 |

These rows derive from R = 13 live + 4 offset + (1+8+w) raw read + (48+2w)
decode = 74+3w; W = 13 live + 4 offset + (48+2w) encode + (1+w) raw write,
plus 16 only for clamped = 66+3w+clamp. No reverse observation supplies the rows.
The full body costs 25 + floor(length/2) times the pair charge.

Every read and write endpoint, and its one-short neighbor, is exercised for
all ten kinds over two pairs. The four store endpoints are 25+lower,
25+pair, 25+pair+lower, and 25+2pair. An input [1,2,3,4] must have these successive
literal states: [4,2,3,4], [4,2,3,1], [4,3,3,1], [4,3,2,1]. Both reads precede
the first store. A resource stop is not pair-atomic; every individual scalar
remains atomic. Fixed literal IEEE/integer byte tables supply these expectations.

Aligned subviews include A5/5A backing sentinels, checked on lower-only,
whole-pair and full-loop boundaries. The floating odd midpoint is a raw negative
signaling NaN whose bytes must remain untouched. Visited NaNs instead use the
existing positive canonical encoding; the tests do not require arbitrary NaN
payload restoration after two numeric reversals. Signed zero and infinity are
independent literal bytes. A second reverse restores ordinary finite numeric
contents in the all-kind identity group.

Empty, singleton and equal-value pairs retain their full body charge at an
already full runtime heap. No equal-byte shortcut may skip writes or charges.
Raw inspection uses existing `buffer_view_read`, saves/restores observed work,
and asserts unchanged charged heap. Host test vectors are outside Runtime
accounting. No sibling-private ArrayBuffer record/ID fields are accessed.

Complete saved calls first measure their genuine successful operation boundary
inside the test, verify it exceeds the independently fixed body cost, and assert
the unchanged 50-byte native-name charge (32 + 18 for `TypedArray.reverse`).
Fresh identical fixtures then test exact work/heap, one-short work/heap and zero
work/heap room. Work-one-short leaves precisely the first three stores, whereas
name-heap refusal happens before mutation. Guard, frame, object/record-count and
native metadata checks remain after every outcome. These totals exclude
caller-created Rust argument/receiver handles, identically on both fixtures.

Strict and sloppy source bodies also cover ignored coercion hooks and Symbols,
ordinary argument evaluation/abrupt completion before dispatch, fresh record
growth before the call, authentic brand rejection, detached empty views,
fixed/tracking shrink and recovery, valid empty offset-boundary views and
trailing incomplete elements. Public length/constructor/index prototypes may
be poisoned without observation. Shared metadata, cached identity and
nonconstructibility have successful prerequisite guards.

Source-only status does not predict quota admission for authored JavaScript or
claim a passing compiler/test result. Root must preserve any first failure and
make narrow, separately reviewed corrections if needed.
