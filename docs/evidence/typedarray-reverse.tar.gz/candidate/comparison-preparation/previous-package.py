"""Publish verified source, observations and raw timing evidence, without binaries."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

G = Path(__file__).resolve().parent
F = Path('/tmp/eris-typedarray-fill-1')
W = G / 'worktree'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


adapter = json.loads((G / 'candidate-adapter-2.json').read_bytes())
assert sha((G / adapter['binary']).read_bytes()) == adapter['sha256']
source_path = G / adapter['source_binding']
assert sha(source_path.read_bytes()) == adapter['source_binding_sha256']
sources = json.loads(source_path.read_bytes())
for name, digest in sources['source_sha256'].items():
    assert sha((W / name).read_bytes()) == digest, name
comparison = json.loads((G / 'comparison.json').read_bytes())
assert comparison['status'] == 'clear' and not comparison['errors']
assert comparison['summary'] == {
    'profiles': 43, 'historical_profiles': 38, 'case_rows': 18236,
    'exact_case_rows': 18236, 'control_rows': 4180, 'exact_control_rows': 4180,
    'prior_pass_losses': 0}
for row in comparison['inputs']:
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256']

checks = {'focused-1': 16, 'full-native-1': 2328, 'script-198-1': 1321,
          'clippy-msrv-1': None, 'clippy-198-1': None, 'format-check-1': None,
          'regressions-1': None, 'comparison-1': None,
          'benchmark-before-build-1': None, 'benchmark-before-locked-1': None,
          'benchmark-after-build-1': None, 'benchmark-protocol-1': None,
          'benchmark-run-1': None}
for label, count in checks.items():
    receipt = json.loads((G / 'validation' / (label + '.json')).read_bytes())
    assert receipt['exit'] == 0, label
    data = (G / 'validation' / receipt['log']).read_bytes()
    assert sha(data) == receipt['sha256'], label
    if count is not None:
        assert sum(map(int, re.findall(rb'test result: ok\. (\d+) passed;', data))) == count

timings = json.loads((G / 'benchmark/run-1/summary.json').read_bytes())
assert timings['status'] == 'complete' and len(timings['runs']) == 8
assert (G / 'benchmark/run-1/inputs-before.json').read_bytes() == (G / 'benchmark/run-1/inputs-after.json').read_bytes()
timing_inputs = json.loads((G / 'benchmark/run-1/inputs-before.json').read_bytes())
samples = calls = 0
for index, run in enumerate(timings['runs']):
    round_number, position = divmod(index, 2)
    order = ['before', 'after'] if round_number % 2 == 0 else ['after', 'before']
    label = order[position]
    assert (run['round'], run['position'], run['label']) == (round_number, position, label)
    command = run['command']
    assert len(command) == 4
    assert Path(command[0]).resolve() == Path(timing_inputs['python_executable']['path'])
    assert command[1:] == [timing_inputs['wrapper']['path'],
                           timing_inputs['binaries'][label]['path'], str(round_number)]
    assert run['returncode'] == 0 and not run['timed_out']
    for kind in ['stdout', 'stderr']:
        row = run[kind]
        data = Path(row['path']).read_bytes()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
        if kind == 'stderr':
            assert not data
    raw = Path(run['stdout']['path']).read_text().splitlines()
    assert len(raw) == 842 and raw[-1] == 'END\t840\t3360'
    samples += len(raw) - 2
    calls += 3360
assert (samples, calls) == (6720, 26880)
for label in ['before', 'after']:
    row = json.loads((G / 'benchmark' / (label + '-binary.json')).read_bytes())
    assert timing_inputs['binaries'][label] == {
        'path': row['binary'], 'bytes': row['bytes'], 'sha256': row['sha256']}
    assert sha(Path(row['binary']).read_bytes()) == row['sha256']
    assert sha(Path(row['engine_source_binding']).read_bytes()) == row['engine_source_binding_sha256']
    assert sha(Path(row['harness']['path']).read_bytes()) == row['harness']['sha256']
    assert all(r['samples'] == 84 for r in timings['statistics'][label])

report = json.loads((G / 'upstream-1.json').read_bytes())
assert report['counts'] == dict(passed=22, resource=32, unsupported=50)
assert len(report['harness_preflight']) == 52 and report['harness_preflight_passed']
assert report['binary_sha256'] == adapter['sha256']
assert (G / 'upstream-1.json').read_bytes() == (W / 'tests/conformance/test262-typedarray-fill-after-encoding.json').read_bytes()
for name in ['observation-review-2.json', 'documentation-review.json']:
    review = json.loads((G / name).read_bytes())
    assert review['status'].startswith('clear'), name

records = {}


def add(path, name):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in records, name
    records[name] = path.read_bytes()


for path in sorted(G.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.py', '.md'}:
        add(path, 'candidate/' + path.name)
for directory in ['validation', 'implementation', 'private-tests', 'regressions-candidate-1', 'benchmark']:
    for path in sorted((G / directory).rglob('*')):
        if not path.is_file() or path.is_symlink():
            continue
        if path.name.startswith('package-') or '__pycache__' in path.parts or path.suffix == '.pyc':
            continue
        if directory == 'benchmark' and path.name in {'eris-fill-before-1', 'eris-fill-after-1'}:
            continue
        add(path, 'candidate/' + str(path.relative_to(G)))
for name in ['upstream-1.json', 'search-1.json', 'foundation-1.json', 'views-1.json',
             'local-1.json', 'candidate-adapter-1.json', 'compiled-source-1.json',
             'ci-observation-3.json']:
    add(F / name, 'prior/' + name)
for path in sorted((F / 'regressions-candidate-1').glob('*.json')):
    add(path, 'prior/regressions-candidate-1/' + path.name)
for name in sorted(sources['source_sha256']):
    add(W / name, 'published-source/' + name)
changed = subprocess.check_output(['git', 'diff', '--name-only'], cwd=W).decode().splitlines()
changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W).decode().splitlines()
for name in sorted(set(changed)):
    if name.startswith('docs/evidence/') or name in sources['source_sha256']:
        continue
    add(W / name, 'published-source/' + name)
index = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(records.items())}
records['MANIFEST.json'] = encoded(index)
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w') as archive:
    for name, data in sorted(records.items()):
        item = tarfile.TarInfo(name)
        item.size, item.mode, item.mtime = len(data), 0o644, 0
        archive.addfile(item, io.BytesIO(data))
out = io.BytesIO()
with gzip.GzipFile(fileobj=out, mode='wb', filename='', mtime=0) as stream:
    stream.write(raw.getvalue())
payload = out.getvalue()
destination = W / 'docs/evidence/typedarray-fill-encoding.tar.gz'
assert not destination.exists()
destination.write_bytes(payload)
summary = {
    'feature': 'Encode a Number TypedArray fill scalar once', 'base': sources['base'],
    'archive': destination.name, 'archive_bytes': len(payload), 'archive_sha256': sha(payload),
    'manifest_sha256': sha(records['MANIFEST.json']), 'records': len(index),
    'candidate_adapter': adapter, 'source_change_after_validation': None,
    'checks': {label: json.loads((G / 'validation' / (label + '.json')).read_bytes()) for label in checks},
    'comparison': comparison, 'fill_counts': report['counts'], 'fill_control_count': 52,
    'upstream_report_healthy': False, 'baseline_recorded': False,
    'timing': timings, 'timing_rows': json.loads((G / 'benchmark/derived-table.json').read_bytes()),
    'known_limits': ['32 fill resource-limited modes remain',
                     'Small empty/single-element benchmark medians increased in this run',
                     'Uncontrolled local host; no statistical significance or Chromium parity claim',
                     'Full web compatibility and production security remain unfulfilled'],
    'published_bindings': {name: {'bytes': len((W / name).read_bytes()), 'sha256': sha((W / name).read_bytes())}
                           for name in sorted(set(changed)) if not name.startswith('docs/evidence/')},
}
(W / 'docs/evidence/typedarray-fill-encoding.json').write_bytes(encoded(summary))
with tarfile.open(destination) as archive:
    for name, row in index.items():
        data = archive.extractfile(name).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
print(json.dumps({'archive_bytes': len(payload), 'archive_sha256': sha(payload), 'records': len(index)}))
