import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;o=p/'validation';o.mkdir(exist_ok=True)
label,*argv=sys.argv[1:];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';start=time.monotonic();log=o/(label+'.log')
with log.open('xb') as f:r=subprocess.run(argv,cwd=p/'worktree',env=env,stdout=f,stderr=subprocess.STDOUT,close_fds=True)
record={'command':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
with (o/(label+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True);print(log.read_text()[-6000:]);raise SystemExit(r.returncode)
