# TypedArray reverse preparation

The `typedarray-reverse` profile retains all 22 original JavaScript bodies in the complete `TypedArray/prototype/reverse` subtree at Test262 revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`: 16 direct files and six nested BigInt files, each in sloppy and strict modes. Eight original helpers, two legal files and eight complete Git proof documents accompany the sources. The existing recursive tree verifier authenticates every included source and its ancestors. Runtime outcomes do not determine inclusion.

The frozen policy schedules 26 of 44 modes. All excluded rows remain visible: 12 BigInt, two immutable-arraybuffer, two requiring the complete resizableArrayBufferUtils helper, and two remaining host-hook modes. The helper exclusion and exact supported features are serialized into the policy hash. Existing 50 profile policies and defaults remain unchanged. Registration becomes 51 profiles.

Five independent positive/wrong pairs add 20 observations to the existing 32 common controls. Each source first requires a genuinely working reverse on an authentic view. A wrong partner must throw intrinsic Error and its same-mode positive must succeed. Cases cover all ten Number kinds including Float16, even/odd/empty/singleton inputs, identity and numeric restoration, aligned view offsets, signed zero and NaN values, authentic receiver and resize/detach validation, ignored argument conversion hooks, preserved expandos, metadata and saved method identity. Frozen control SHA256 is `c85cbbe7be55bc264403165a554d3b85de858358bd97583d614b66d766669c28`.

The [primary reverse algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.reverse) supplies independent semantic oracles. Visited NaNs are checked as numeric NaNs, without requiring payload preservation. The explicit byte control binds this runtime's existing little-endian storage contract. Original upstream sources and helpers are unchanged. BigInt and immutable-buffer support remain excluded.

Nine new mocked protocol groups cover inventory and policy, control integrity and false-positive rejection, exact intrinsic Error and same-mode prerequisite checks, unchanged common controls, complete proof/source/helper tampering, omitted excluded BigInt entries, offline import identity, and resource stops preventing baseline creation even when controls pass. Nineteen historical registration tests exclude only the new profile; their original expected counts/hashes remain unchanged. The AST preservation receipt reconstructs all 21 modified original modules by removing the new additions. The 54 historical BEFORE fee rows are outside this tooling change and their original source is bound as context.

The source acquisition retained the first sandbox DNS failure and the successful public-source retry. Both raw receipts are under `discovery/`; no project code participated in retrieval. Inherited helper, legal and ancestor-proof bytes are bound to their previous frozen copies and authenticated again against the pinned Git trees.

## Root handoff

The author performed only inert source/data preparation, raw Git/blob hashing and Python AST inspection. No project tool was imported or executed; no JS parser, adapter, compiler, formatter, test or browser ran. Inspect `source-ready.json`, retained originals/diffs, `policy-inventory.json` and `input-proof.json` before execution.

From `/tmp/eris-typedarray-reverse-1/worktree`, root imports once into a fresh target using the 40 held inputs:

```sh
python3 /tmp/eris-typedarray-reverse-1/conformance/offline_import.py
python3 -m unittest discover -s tools -p 'test_test262*.py'
```

The network equivalent is `python3 tools/import_test262.py --profile typedarray-reverse`. Use one route and retain any failed attempt. The offline handoff refuses an existing target, authenticates the importer and every input before and after, and has no network fallback.

The immutable published predecessor is `/tmp/eris-typedarray-fill-encoding-1/eris-js-candidate-2`, SHA256 `5a88f7f061bc7f64dc9b5003aa4e2a33715932502b5bb8ee51084f3d8104e234`. Root records its report with:

```sh
python3 tools/test262_conformance.py --profile typedarray-reverse --binary /tmp/eris-typedarray-fill-encoding-1/eris-js-candidate-2 --output /tmp/eris-typedarray-reverse-1/upstream-before.json --jobs 2
```

Retain the full report and nonzero exit. Missing-method controls cannot establish a healthy baseline. Candidate statuses remain unobserved here. Resource, timeout and adapter errors remain unhealthy even when controls succeed; no upstream baseline or gate is proposed from unrun observations.
