"""Hash/source-copy handoff only; never import or execute project modules."""
from pathlib import Path
import hashlib
import json
import shutil

C = Path(__file__).resolve().parent
W = C.parent / 'worktree'
def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())
def write(path, value):
    with path.open('x') as output:
        output.write(json.dumps(value, indent=2) + '\n')

paths = json.loads((C / 'changed-existing-paths.json').read_bytes()) + [
    'tools/test_test262_typedarray_reverse.py', 'tools/typedarray-reverse-controls.json']
assert len(paths) == 23
for original in (C / 'original').iterdir():
    assert original.read_bytes() == (W / 'tools' / original.name).read_bytes(), original
for path in paths:
    if not (C / 'original' / Path(path).name).exists():
        assert not (W / path).exists(), path
draft_rows = [dict(relative_path=p, **binding(C / 'draft' / p)) for p in paths]
write(C / 'draft-source-ready.json', dict(status='frozen before worktree installation',
      published_base='ee846e00686d63236e7aedb754a89cb2fd5fa9bf', files=draft_rows,
      preservation=binding(C / 'preservation.json'), controls=binding(C / 'controls/source-ready.json'),
      input_proof=binding(C / 'input-proof.json'), source_execution=False))
project = []
for path in paths:
    source = C / 'draft' / path
    retained = C / 'held' / path
    retained.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, retained)
    shutil.copyfile(source, W / path)
    project.append(dict(relative_path=path, **binding(W / path), held_copy=binding(retained),
                        draft_copy=binding(source)))
write(C / 'installation.json', dict(status='exact held source copies installed',
      draft_hold=binding(C / 'draft-source-ready.json'), project_files=project,
      operations='Source copies only; no project importer, parser, tests, formatter, compiler or engine'))
dependencies = [binding(p) for p in [
    Path('/tmp/eris-typedarray-fill-encoding-1/worktree/src/script/array_splice/set_key_fee_tests.rs'),
    Path('/tmp/eris-typedarray-fill-encoding-1/eris-js-candidate-2'),
    Path('/tmp/eris-typedarray-fill-encoding-1/candidate-adapter-2.json'),
    Path('/tmp/eris-typedarray-fill-encoding-1/next-method/draft/README.md'),
]]
assert dependencies[1]['sha256'] == '5a88f7f061bc7f64dc9b5003aa4e2a33715932502b5bb8ee51084f3d8104e234'
preparation = [binding(p) for p in sorted(C.rglob('*')) if p.is_file()]
write(C / 'source-ready.json', dict(
    status='source-ready; no project importer/protocol/adapter/JS-parser/compiler/formatter execution by author',
    published_base='ee846e00686d63236e7aedb754a89cb2fd5fa9bf', profile='typedarray-reverse',
    upstream_revision='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd',
    test_files=22, mode_cases=44, scheduled=26,
    exclusions=dict(BigInt=12, immutable_arraybuffer=2, complete_helper=2, host=2),
    helper_files=8, proof_files=8, offline_inputs=40,
    controls=dict(common=32, feature=20, total=52, pairs=5), new_protocol_groups=9,
    preserved_existing_profiles=50, registered_profiles=51,
    project_files=project, dependencies=dependencies, preparation_inputs=preparation,
    review=dict(control_peer=binding(C / 'controls/script-review.json'), tooling_peer='pending separate source review'),
    root_execution=dict(cwd=str(W), import_command=['python3', str(C / 'offline_import.py')],
        protocols=['python3','-m','unittest','discover','-s','tools','-p','test_test262*.py'],
        before=['python3','tools/test262_conformance.py','--profile','typedarray-reverse',
                '--binary', dependencies[1]['path'], '--output',str(C.parent / 'upstream-before.json'),'--jobs','2'])))
print(json.dumps(dict(hold=binding(C / 'source-ready.json'), project_files=len(project),
                      preparation_bindings=len(preparation))))
