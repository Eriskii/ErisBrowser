"""Author frozen independent JS bytes; do not parse or execute JavaScript."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
def digest(data):
    return hashlib.sha256(data).hexdigest()

guard = '''var owner = Object.getPrototypeOf(Uint8Array.prototype);
var reverse = owner.reverse;
if (typeof reverse !== 'function') throw new TypeError('reverse prerequisite');
var guard = new Uint8Array([2, 4]);
if (!ArrayBuffer.isView(guard) || reverse.call(guard) !== guard || guard[0] !== 4 || guard[1] !== 2) throw new TypeError('working reverse prerequisite');
'''
pairs = [
('ten-number-kinds', '''var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array];
var even = 0, odd = 0, restored = 0, empty = 0, single = 0;
for (var i = 0; i < kinds.length; i++) {
  var a = new kinds[i]([1, 2, 3, 4]);
  if (reverse.call(a) === a && a[0] === 4 && a[1] === 3 && a[2] === 2 && a[3] === 1) even++;
  reverse.call(a);
  if (a[0] === 1 && a[1] === 2 && a[2] === 3 && a[3] === 4) restored++;
  var b = new kinds[i]([1, 2, 3]);
  if (reverse.call(b) === b && b[0] === 3 && b[1] === 2 && b[2] === 1) odd++;
  var c = new kinds[i](0), d = new kinds[i]([7]);
  if (reverse.call(c) === c && c.length === 0) empty++;
  if (reverse.call(d) === d && d[0] === 7) single++;
}
var actual = [even, odd, restored, empty, single].join(',');
''', '10,10,10,10,10', '10,10,10,10,0'),
('offset-and-special-values', '''var buffer = new ArrayBuffer(10), bytes = new Uint8Array(buffer);
for (var i = 0; i < 10; i++) bytes[i] = 165;
var a = new Uint16Array(buffer, 2, 3); a[0] = 4660; a[1] = 22136; a[2] = 39612;
reverse.call(a);
var raw = [];
for (var j = 0; j < 10; j++) raw.push(bytes[j]);
var h = new Float16Array([-0, NaN, 3.5]); reverse.call(h);
var f = new Float32Array([-0, NaN]); reverse.call(f);
var d = new Float64Array([Infinity, -0, -Infinity]); reverse.call(d);
var actual = raw.join(',') + ';' + [h[0] === 3.5, h[1] !== h[1], Object.is(h[2], -0), f[0] !== f[0], Object.is(f[1], -0), d[0] === -Infinity, Object.is(d[1], -0), d[2] === Infinity].join(',');
''', '165,165,188,154,120,86,52,18,165,165;true,true,true,true,true,true,true,true',
     '165,165,52,18,120,86,188,154,165,165;true,true,true,true,true,true,true,true'),
('initial-validation-and-resize', '''var invalid = [null, undefined, {}, [], Object.create(Uint8Array.prototype), new DataView(new ArrayBuffer(0))];
var rejected = 0;
for (var i = 0; i < invalid.length; i++) {
  try { reverse.call(invalid[i]); } catch (e) { if (e instanceof TypeError) rejected++; }
}
var detachedBuffer = new ArrayBuffer(1), detached = new Uint8Array(detachedBuffer);
if (typeof detachedBuffer.transfer !== 'function') throw new TypeError('transfer prerequisite');
var moved = detachedBuffer.transfer();
if (moved.byteLength !== 1 || detachedBuffer.byteLength !== 0) throw new TypeError('working transfer prerequisite');
var detachedRejected = false;
try { reverse.call(detached); } catch (e) { detachedRejected = e instanceof TypeError; }
var buffer = new ArrayBuffer(6, {maxByteLength:8}), all = new Uint8Array(buffer);
if (typeof buffer.resize !== 'function') throw new TypeError('resize prerequisite');
for (var j = 0; j < 6; j++) all[j] = j + 1;
var tracking = new Uint8Array(buffer, 2), fixed = new Uint8Array(buffer, 2, 3);
reverse.call(tracking);
var first = [all[0], all[1], all[2], all[3], all[4], all[5]].join(',');
buffer.resize(4);
if (buffer.byteLength !== 4) throw new TypeError('working resize prerequisite');
var fixedRejected = false;
try { reverse.call(fixed); } catch (e) { fixedRejected = e instanceof TypeError; }
reverse.call(tracking);
var second = [all[0], all[1], all[2], all[3]].join(',');
buffer.resize(2);
var emptyReturned = reverse.call(tracking) === tracking;
buffer.resize(1);
var trackingRejected = false;
try { reverse.call(tracking); } catch (e) { trackingRejected = e instanceof TypeError; }
buffer.resize(6);
var finalBytes = [all[0], all[1], all[2], all[3], all[4], all[5]].join(',');
var actual = [rejected, detachedRejected, fixedRejected, emptyReturned, trackingRejected].join(',') + ';' + first + ';' + second + ';' + finalBytes;
''', '6,true,true,true,true;1,2,6,5,4,3;1,2,5,6;1,0,0,0,0,0',
     '6,true,false,true,true;1,2,6,5,4,3;1,2,5,6;1,0,0,0,0,0'),
('internal-length-and-ignored-hooks', '''var a = new Uint8Array([1, 2, 3]), hooks = 0, effects = 0;
function poison() { hooks++; throw new Error('unexpected reverse hook'); }
Object.defineProperty(a, 'length', {get:poison});
Object.defineProperty(a, 'constructor', {get:poison});
var ordinary = {};
Object.defineProperty(ordinary, '0', {get:poison});
Object.setPrototypeOf(a, ordinary);
var symbol = Symbol('marker'); a.marker = 17; a[symbol] = 23;
var extra = {valueOf:poison, toString:poison}; extra[Symbol.toPrimitive] = poison;
var returned = reverse.call(a, (effects++, extra), extra);
var actual = [returned === a, a[0], a[1], a[2], hooks, effects, a.marker, a[symbol]].join(',');
''', 'true,3,2,1,0,1,17,23', 'true,3,2,1,1,1,17,23'),
('metadata-saved-identity', '''var descriptor = Object.getOwnPropertyDescriptor(owner, 'reverse');
var nd = Object.getOwnPropertyDescriptor(reverse, 'name');
var ld = Object.getOwnPropertyDescriptor(reverse, 'length');
var metadata = descriptor.value === reverse && descriptor.writable && !descriptor.enumerable && descriptor.configurable &&
  nd.value === 'reverse' && !nd.writable && !nd.enumerable && nd.configurable &&
  ld.value === 0 && !ld.writable && !ld.enumerable && ld.configurable &&
  Object.getPrototypeOf(reverse) === Function.prototype && !Object.prototype.hasOwnProperty.call(reverse, 'prototype');
var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array];
var shared = 0;
for (var i = 0; i < kinds.length; i++) if (kinds[i].prototype.reverse === reverse) shared++;
if (typeof Reflect.construct !== 'function') throw new TypeError('construct prerequisite');
function Constructor() { this.proof = 7; }
if (Reflect.construct(Constructor, []).proof !== 7) throw new TypeError('working construct prerequisite');
var nonconstructor = false;
try { Reflect.construct(reverse, []); } catch (e) { nonconstructor = e instanceof TypeError; }
var deleted = delete owner.reverse;
var a = new Uint8Array([3, 4]), returned = reverse.call(a);
var actual = [metadata, shared, nonconstructor, deleted, owner.reverse === undefined, returned === a, a[0], a[1]].join(',');
''', 'true,10,true,true,true,true,4,3', 'true,10,true,true,true,false,4,3'),
]
controls = []
for name, body, good, bad in pairs:
    prefix = guard + body
    for positive, literal in [(True, good), (False, bad)]:
        source = prefix + 'if (actual !== ' + json.dumps(literal) + ") throw new Error('independent reverse literal mismatch');\n"
        controls.append(dict(name=name + ('-positive' if positive else '-wrong'), pair=name,
                             positive=positive, modes=['sloppy', 'strict'], source=source,
                             source_sha256=digest(source.encode()),
                             common_prefix_sha256=digest(prefix.encode()), expected_literal=literal))
raw = (json.dumps(dict(schema=1, scope='Number TypedArray.reverse independent paired source controls',
                       controls=controls), indent=2) + '\n').encode()
(HERE / 'controls.json').write_bytes(raw)
(HERE.parent / 'draft/tools/typedarray-reverse-controls.json').write_bytes(raw)
ready = dict(status='frozen before reverse conformance execution', source_sha256=digest(raw),
             source_bytes=len(raw), pairs=len(pairs), mode_observations=len(controls)*2,
             guard_sha256=digest(guard.encode()), source=str(HERE / 'controls.json'),
             project_copy='tools/typedarray-reverse-controls.json',
             specification='https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.reverse',
             numeric_scope='Ten nonshared Number kinds; visited NaNs checked numerically, not for payload preservation; byte literals assume this runtime\'s held little-endian storage contract.',
             execution='No JS parser, adapter, importer, compiler, formatter or tests')
(HERE / 'source-ready.json').write_text(json.dumps(ready, indent=2) + '\n')
print(json.dumps(ready))
