"""Adapt the existing mocked protocol tests as source; do not execute them."""
from pathlib import Path
import json
C = Path(__file__).resolve().parent
s = (C / 'original/test_test262_typedarray_fill.py').read_text()
s = s.replace('fill', 'reverse').replace('Fill', 'Reverse')
s = s.replace("PAIRS = ['ordered-clamped-range', 'ten-number-kinds', 'tracking-captured-bounds',\n         'invalid-and-abrupt-order', 'metadata-saved-identity']", "PAIRS = ['ten-number-kinds', 'offset-and-special-values', 'initial-validation-and-resize',\n         'internal-length-and-ignored-hooks', 'metadata-saved-identity']")
s = s.replace("'TypedArray/prototype/reverse': 34, 'TypedArray/prototype/reverse/BigInt': 18", "'TypedArray/prototype/reverse': 16, 'TypedArray/prototype/reverse/BigInt': 6")
s = s.replace('(52, 104, 64, [])', '(22, 44, 32, [])').replace('[52, 52]', '[22, 22]')
s = s.replace("'nans.js', 'byteConversionValues.js', 'compareArray.js'", "'compareArray.js'")
s = s.replace('reasons.count(None), 54', 'reasons.count(None), 26')
s = s.replace("features: BigInt'), 36", "features: BigInt'), 12")
s = s.replace("source check)'), 8", "source check)'), 2")
s = s.replace("resizableArrayBufferUtils helper'), 4", "resizableArrayBufferUtils helper'), 2")
s = s.replace('is None for c in cases), 58', 'is None for c in cases), 28')
s = s.replace("'/BigInt/' in c['file'] for c in cases), 36", "'/BigInt/' in c['file'] for c in cases), 12")
s = s.replace('len(runner.PROFILES), 50', 'len(runner.PROFILES), 51')
s = s.replace('8e7235a2e834a592417cd3f9a562159edb49f948bda1a728432c6a47134059ba', json.loads((C / 'controls/source-ready.json').read_bytes())['source_sha256'])
s = s.replace('5eaac187670caf1fa1256e78d7ae5780de16c47d', 'cfbd5368520d987e1256f9981c2e587d898f1df7')
s = s.replace("[(PROFILE, 54), ('typedarray-search', 158), ('typedarray-views', 110)]", "[(PROFILE, 26), ('typedarray-fill', 54), ('typedarray-search', 158), ('typedarray-views', 110)]")
(C / 'draft/tools/test_test262_typedarray_reverse.py').write_text(s)
print('Wrote nine source-only reverse protocol groups')
