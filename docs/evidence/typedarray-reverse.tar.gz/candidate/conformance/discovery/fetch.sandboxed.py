"""Download pinned original Test262 bytes; no project module imports/execution."""
from pathlib import Path
import hashlib,json,urllib.request,datetime,concurrent.futures
HERE=Path(__file__).resolve().parent; C=HERE.parent; O=C/'offline-inputs'
REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd';TREE='cfbd5368520d987e1256f9981c2e587d898f1df7'
records=[]
def fetch(url,path):
 request=urllib.request.Request(url,headers={'User-Agent':'ErisBrowser-pinned-source-preparation','Accept':'application/vnd.github+json' if 'api.github.com' in url else '*/*'})
 with urllib.request.urlopen(request,timeout=45)as response:
  data=response.read();entry={'url':url,'resolved_url':response.url,'status':response.status,'headers':dict(response.headers),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 path.parent.mkdir(parents=True,exist_ok=True)
 with path.open('xb')as f:f.write(data)
 entry.update(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest());return data,entry
try:
 p=O/'inventory-proof'/('recursive-'+TREE+'.json')
 raw,entry=fetch('https://api.github.com/repos/tc39/test262/git/trees/'+TREE+'?recursive=1',p);records.append(entry)
 (HERE/'reverse-recursive-response.json').write_bytes(raw)
 tree=json.loads(raw);assert tree['sha']==TREE and tree['truncated']is False
 blobs=[r for r in tree['tree']if r['type']=='blob'];assert len(blobs)==22
 def blob(r):
  relative='test/built-ins/TypedArray/prototype/reverse/'+r['path'];url='https://raw.githubusercontent.com/tc39/test262/'+REV+'/'+relative
  data,entry=fetch(url,O/relative)
  assert len(data)==r['size']and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==r['sha']
  return entry
 with concurrent.futures.ThreadPoolExecutor(max_workers=4)as pool:
  futures=[pool.submit(blob,r)for r in blobs]
  for future in futures:records.append(future.result())
 status='complete'
except Exception as error:
 status='failed';records.append({'error':repr(error)});raise
finally:
 (HERE/'fetch-1.json').write_text(json.dumps({'status':status,'revision':REV,'tree':TREE,'records':records,'scope':'Raw public network data only; project tools not imported or run.'},indent=2)+'\n')
print(json.dumps({'status':status,'requests':len(records),'bodies':22}))
