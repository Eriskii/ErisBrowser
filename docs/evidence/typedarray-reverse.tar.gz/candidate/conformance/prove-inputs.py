"""Independent inert Git/data audit; does not import any project modules."""
import hashlib, json
from pathlib import Path
R = Path(__file__).resolve().parent
C = R / 'offline-inputs'
REV = '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
ROOT = '91b2052adad1f066ae031e2ff3a1e9bd6d732886'
roots = {'reverse':'cfbd5368520d987e1256f9981c2e587d898f1df7'}
used = {'inventory-proof/commit.json'}
def sha(data): return hashlib.sha256(data).hexdigest()
def tree(entries, expected):
    parts = [(e['path'].encode()+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha'])) for e in entries]
    body=b''.join(v for _,v in sorted(parts))
    assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==expected
    return {e['path']:e for e in entries}
def load(ident, recursive=False):
    path='inventory-proof/'+('recursive-' if recursive else 'tree-')+ident+'.json'
    used.add(path); data=json.loads((C/path).read_bytes())
    assert data['sha']==ident and data['truncated'] is False
    if not recursive: tree(data['tree'],ident)
    return data['tree']
commit=json.loads((C/'inventory-proof/commit.json').read_bytes())
assert commit['sha']==REV and commit['tree']['sha']==ROOT
root={r['path']:r for r in load(ROOT)}
source_rows=[]
for method, ident in roots.items():
    current=ROOT
    for part in ('test/built-ins/TypedArray/prototype/'+method).split('/'):
        current={r['path']:r for r in load(current)}[part]['sha']
    assert current==ident
    recursive=load(ident,True)
    dirs={'':ident,**{r['path']:r['sha'] for r in recursive if r['type']=='tree'}}
    for directory, child in dirs.items():
        children=[dict(r,path=r['path'].rsplit('/',1)[-1]) for r in recursive if r['path'].rpartition('/')[0]==directory]
        tree(children,child)
    for row in recursive:
        if row['type']=='tree': continue
        path='test/built-ins/TypedArray/prototype/'+method+'/'+row['path']
        data=(C/path).read_bytes()
        assert len(data)==row['size'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['sha']
        used.add(path); source_rows.append(dict(path=path,git_blob=row['sha'],sha256=sha(data),bytes=len(data)))
harness={r['path']:r for r in load(root['harness']['sha'])}
for name in ['assert.js', 'compareArray.js', 'detachArrayBuffer.js', 'isConstructor.js', 'propertyHelper.js', 'resizableArrayBufferUtils.js', 'sta.js', 'testTypedArray.js']:
    data=(C/'harness'/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==harness[name]['sha']
    used.add('harness/'+name)
for name in ['LICENSE','INTERPRETING.md']:
    data=(C/name).read_bytes()
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==root[name]['sha']
    used.add(name)
proofs=[p for p in used if p.startswith('inventory-proof/')]
assert len(source_rows)==22 and len(proofs)==8 and len(used)==40
files=[dict(path=p,bytes=len((C/p).read_bytes()),sha256=sha((C/p).read_bytes())) for p in sorted(used)]
(R/'offline-inventory.json').write_text(json.dumps(dict(profile='typedarray-reverse',revision=REV,source_count=22,proof_count=8,auxiliary_count=10,files=files),indent=2)+'\n')
(R/'input-proof.json').write_text(json.dumps(dict(status='clear',scope='inert Python Git-tree reconstruction and exact raw blob hashing; no project import/parser/engine',revision=REV,root_tree=ROOT,subtrees=roots,source_count=len(source_rows),proof_count=len(proofs),input_count=len(used),source_rows=sorted(source_rows,key=lambda r:r['path'])),indent=2)+'\n')
print(json.dumps(dict(status='clear',sources=len(source_rows),proofs=len(proofs),inputs=len(used))))
