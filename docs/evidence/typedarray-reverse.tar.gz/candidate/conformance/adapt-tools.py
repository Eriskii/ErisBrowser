"""Source transformations only; never import or execute project modules."""
from pathlib import Path
import difflib
import json

C = Path(__file__).resolve().parent
D = C / 'draft/tools'
O = C / 'original'
inventory = json.loads((C / 'discovery/inventory.json').read_bytes())
control_hash = json.loads((C / 'controls/source-ready.json').read_bytes())['source_sha256']

def replace_once(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new, 1)

p = D / 'import_test262.py'
s = (O / p.name).read_text()
s = replace_once(s, 'TYPEDARRAY_FILL_DIRECTORIES =',
                 'TYPEDARRAY_REVERSE_DIRECTORIES = ' + repr(inventory['directories']) + '\n' +
                 'TYPEDARRAY_REVERSE_HELPERS = ' + repr(set(inventory['helpers'])) + '\nTYPEDARRAY_FILL_DIRECTORIES =')
s = replace_once(s, 'ITERATION_SUBTREES = {', "ITERATION_SUBTREES = {\n    'typedarray-reverse': {'TypedArray/prototype/reverse': 'cfbd5368520d987e1256f9981c2e587d898f1df7'},")
s = replace_once(s, 'ITERATION_HELPERS = {', "ITERATION_HELPERS = {\n    'typedarray-reverse': TYPEDARRAY_REVERSE_HELPERS,")
s = replace_once(s, "TREE_PROFILES = {'typedarray-fill'", "TREE_PROFILES = {'typedarray-reverse', 'typedarray-fill'")
s = replace_once(s, "PROFILES = {'typedarray-fill':", "PROFILES = {'typedarray-reverse': TYPEDARRAY_REVERSE_DIRECTORIES, 'typedarray-fill':")
s = replace_once(s, "PROFILE_ROOTS = {'typedarray-fill':", "PROFILE_ROOTS = {'typedarray-reverse': 'test/built-ins', 'typedarray-fill':")
anchor = "    if profile == 'typedarray-fill' and harness != TYPEDARRAY_FILL_HELPERS:"
s = replace_once(s, anchor, "    if profile == 'typedarray-reverse' and harness != TYPEDARRAY_REVERSE_HELPERS:\n        raise ValueError('TypedArray reverse requested harness differs from the frozen eight helpers')\n" + anchor)
s = replace_once(s, '    scope = {', "    scope = {\n        'typedarray-reverse': 'all 22 original .js files in the complete TypedArray prototype reverse tree, including all BigInt originals; full root-linked Git proof; no implementation',")
p.write_text(s)

p = D / 'test262_conformance.py'
s = (O / p.name).read_text()
s = replace_once(s, 'TYPEDARRAY_FILL_FEATURES =', "TYPEDARRAY_REVERSE_FEATURES = {'TypedArray', 'ArrayBuffer', 'Symbol', 'Reflect.construct',\n                              'arrow-function', 'resizable-arraybuffer'}\nTYPEDARRAY_FILL_FEATURES =")
s = replace_once(s, "PROFILE_FEATURES = {'typedarray-fill':", "PROFILE_FEATURES = {'typedarray-reverse': TYPEDARRAY_REVERSE_FEATURES, 'typedarray-fill':")
assert s.count("profile in {'typedarray-fill', 'typedarray-search', 'typedarray-views'") == 2
s = s.replace("profile in {'typedarray-fill', 'typedarray-search', 'typedarray-views'", "profile in {'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views'")
anchor = "    if (profile == 'typedarray-fill'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray fill policy excludes the complete resizableArrayBufferUtils helper'"
s = replace_once(s, anchor, anchor + "\n    if (profile == 'typedarray-reverse'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray reverse policy excludes the complete resizableArrayBufferUtils helper'")
a = s.index('def typedarray_fill_preflight_variants():')
b = s.index('\ndef typedarray_search_preflight_variants():', a)
copied = s[a:b].replace('typedarray_fill', 'typedarray_reverse').replace('typedarray-fill', 'typedarray-reverse').replace('TypedArray fill', 'TypedArray reverse').replace('8e7235a2e834a592417cd3f9a562159edb49f948bda1a728432c6a47134059ba', control_hash)
s = s[:a] + copied + '\n' + s[a:]
s = replace_once(s, "    if profile == 'typedarray-fill':\n        variants += typedarray_fill_preflight_variants()", "    if profile == 'typedarray-reverse':\n        variants += typedarray_reverse_preflight_variants()\n    if profile == 'typedarray-fill':\n        variants += typedarray_fill_preflight_variants()")
s = replace_once(s, "            if ((profile == 'typedarray-fill'", "            if ((profile == 'typedarray-reverse' and name.startswith('typedarray-reverse-'))\n                    or (profile == 'typedarray-fill'")
a = s.index("    if profile == 'typedarray-fill':\n        # Preserve")
b = s.index("    if profile == 'typedarray-search':\n        # Preserve", a)
s = s[:a] + s[a:b].replace('typedarray-fill', 'typedarray-reverse') + s[a:]
s = replace_once(s, "if args.profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill'}:", "if args.profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill', 'typedarray-reverse'}:")
p.write_text(s)

# Only exclude the newly registered profile from historical population contracts.
for source in sorted(O.glob('test_test262*.py')):
    lines = source.read_text().splitlines(True)
    for i, line in enumerate(lines):
        if "'typedarray-fill'" in line and any(x in line for x in ['excluded=', 'excluded =', 'if profile in', 'if name in', 'set(runner.PROFILES)']):
            lines[i] = line.replace("'typedarray-fill'", "'typedarray-reverse', 'typedarray-fill'", 1)
    s = ''.join(lines)
    if source.name == 'test_test262_typedarray_fill.py':
        s = replace_once(s, 'len(runner.PROFILES), 50', "len(set(runner.PROFILES) - {'typedarray-reverse'}), 50")
    (D / source.name).write_text(s)

changed = []
for old in sorted(O.iterdir()):
    after = D / old.name
    if old.read_bytes() != after.read_bytes():
        changed.append('tools/' + old.name)
        (C / (old.name + '.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True), after.read_text().splitlines(True), fromfile='before/tools/' + old.name, tofile='tools/' + old.name)))
(C / 'changed-existing-paths.json').write_text(json.dumps(changed, indent=2) + '\n')
print(json.dumps(dict(changed_existing_paths=len(changed))))
