from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,sys,time
T=Path(__file__).resolve().parent;W=T/'worktree';phase,binary=sys.argv[1:];binary=Path(binary);O=T/('regressions-'+phase);O.mkdir();plan=json.loads((T/'regression-plan.json').read_text());binary_hash=hashlib.sha256(binary.read_bytes()).hexdigest()
def run(selection):
 profile=selection['profile'];baseline=W/selection['baseline'];assert hashlib.sha256(baseline.read_bytes()).hexdigest()==selection['sha256'];report=O/(profile+'.json');log=O/(profile+'.log');argv=['python3',str(W/'tools/test262_conformance.py'),'--binary',str(binary),'--profile',profile,'--baseline',str(baseline),'--output',str(report),'--jobs','2'];start=time.monotonic()
 with log.open('xb') as stream:r=subprocess.run(argv,cwd=W,stdout=stream,stderr=subprocess.STDOUT,close_fds=True,timeout=600,env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1'))
 d=json.loads(report.read_text());row={'phase':phase,'profile':profile,'command':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'binary_sha256':binary_hash,'report_sha256':hashlib.sha256(report.read_bytes()).hexdigest(),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'counts':d['counts'],'mode_cases':d['mode_cases'],'regressions':len(d['regressions']),'improvements':len(d['improvements']),'harness_preflight_passed':d['harness_preflight_passed']};(O/(profile+'-receipt.json')).write_text(json.dumps(row,indent=2)+'\n');print(json.dumps({k:row[k] for k in ['profile','exit','counts','regressions','improvements']}),flush=True);return row
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:rows=list(pool.map(run,plan['profiles']))
assert hashlib.sha256(binary.read_bytes()).hexdigest()==binary_hash
(O/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');raise SystemExit(int(any(row['exit'] for row in rows)))
