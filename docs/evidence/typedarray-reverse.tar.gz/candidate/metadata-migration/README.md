# Reverse metadata test migrations

Five existing test files only. Before and raw after copies and unified diffs are retained. The ledger adds the appended reverse metadata without changing quotas, production fees, old native identities, the original 31-bag expression, or the 54 historical BEFORE rows. Shared creation order explicitly checks the original 18-key prefix before the new final reverse entry; method bag ordinals 31 through 37 are unchanged and reverse is 38 with length zero.

The site contract forecasts 8065 work and 77835 bytes, plus the already reserved arena slot: raw bootstrap forecasts 1848 remaining work, 1699225 allocated bytes and 738 objects/capacity. These are source-derived expectations, not observed results. Root should run the existing raw diagnostic first and independently compare those values before the broad suite. Native registry 299, prototypes 25 and globals 210 stay unchanged.

The SetKey table preserves all 54 historical rows. Only 12 reached absent-owner lookup work endpoints gain the exact new per-entry tariff; all heap endpoints and all semantic inputs stay unchanged. The remaining 42 work endpoints stay unchanged. No project imports, Rust formatting, compiler, tests, or engine were run by this author.
