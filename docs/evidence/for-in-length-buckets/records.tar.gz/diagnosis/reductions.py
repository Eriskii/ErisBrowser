exec((__import__('pathlib').Path(__file__).parent/'run.py').read_text().split('cases=[')[0])
cases=[]
for n in (1,2,3): cases.append((f'full-first-{n}-methods',src.replace('j<ms.length',f'j<{n}'),'sloppy'))
cases.append(('prototype-own-keys',"var f=ArrayBuffer.prototype.transferToFixedLength,p=f,out=[];while(p!==null){out.push(Object.getOwnPropertyNames(p));p=Object.getPrototypeOf(p);}throw new Error(JSON.stringify(out));",'sloppy'))
for name,frag in [('without-getter-enumeration',setup+"var oldIE=isEnumerable;isEnumerable=function(o,n){return __hasOwnProperty(o,n)&&__propertyIsEnumerable(o,n);};"+getbody+"isEnumerable=oldIE;"+methods),('without-method-enumeration',setup+getbody+"isEnumerable=function(o,n){return __hasOwnProperty(o,n)&&__propertyIsEnumerable(o,n);};"+methods)]:cases.append((name,frag,'sloppy'))
result=[]
for name,source,mode in cases:
 case=dict(source=source.encode(),mode=mode,metadata=dict(negative=None),harness=harness);request=runner.encode_request(case)
 (D/(name+'.js')).write_bytes(source.encode());(D/(name+'.request')).write_bytes(request)
 start=time.monotonic();p=subprocess.run([str(binary)],input=request,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=3)
 (D/(name+'.stdout')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr)
 observation=runner.decode_response(p.stdout);result.append(dict(name=name,source_sha256=sha(source.encode()),request_sha256=sha(request),returncode=p.returncode,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr),elapsed=time.monotonic()-start,observation=observation));print(name,observation,flush=True)
assert sha(binary.read_bytes())==expected
(D/'reductions.json').write_text(json.dumps(dict(binary_sha256=expected,cases=result),indent=2)+'\n')
