from pathlib import Path
import sys,hashlib,json,subprocess,time
sys.dont_write_bytecode=True
D=Path(__file__).parent; R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser'); F=Path('/tmp/eris-array-buffer-local')
sys.path.insert(0,str(F/'tools'));import test262_conformance as runner
binary=Path('/tmp/eris-array-buffer-candidate-2/eris-js'); expected='57eae22986e13bd11fe031716a9bd3554b74b31dc8a86c717fea9176ef06c18b'
sha=lambda b:hashlib.sha256(b).hexdigest()
assert sha(binary.read_bytes())==expected
matrix=json.loads((R/'tests/conformance/array-buffer-matrix.json').read_bytes())
rows=matrix['cases'];row=next(r for r in rows if r['id']=='getter-method-flags-and-nonconstructability#sloppy');src=row['source']
assert sha(src.encode())==row['source_sha256']
harness=[(n,(F/'harness'/n).read_bytes()) for n in ('assert.js','sta.js','propertyHelper.js')]
setup,body=src.split("var names=['byteLength'",1);body="var names=['byteLength'"+body
getbody,methods=body.split("var ms=['resize'",1);methods="var ms=['resize'"+methods
cases=[('exact-sloppy',src,'sloppy'),('exact-strict',src,'strict'),('getters-only',setup+getbody,'sloppy'),('methods-only',setup+methods,'sloppy'),('metadata-without-enumeration-probe',"isEnumerable=function(o,n){return __hasOwnProperty(o,n)&&__propertyIsEnumerable(o,n);};\n"+src,'sloppy')]
for n in (8,16,24,32): cases.append((f'for-in-native-{n}',f'var f=ArrayBuffer.prototype.transferToFixedLength;for(var n=0;n<{n};n++){{for(var k in f){{throw new Error(k);}}}}','sloppy'))
result=[]
for name,source,mode in cases:
 case=dict(source=source.encode(),mode=mode,metadata=dict(negative=None),harness=harness);request=runner.encode_request(case)
 (D/(name+'.js')).write_bytes(source.encode());(D/(name+'.request')).write_bytes(request)
 start=time.monotonic();p=subprocess.run([str(binary)],input=request,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=3)
 (D/(name+'.stdout')).write_bytes(p.stdout);(D/(name+'.stderr')).write_bytes(p.stderr)
 observation=runner.decode_response(p.stdout)
 item=dict(name=name,mode=mode,source_sha256=sha(source.encode()),request_sha256=sha(request),returncode=p.returncode,stdout_sha256=sha(p.stdout),stderr_sha256=sha(p.stderr),elapsed=time.monotonic()-start,observation=observation);result.append(item);print(name,observation,flush=True)
assert sha(binary.read_bytes())==expected
(D/'results.json').write_text(json.dumps(dict(binary=str(binary),binary_sha256=expected,frozen_row=row['id'],frozen_source_sha256=row['source_sha256'],matrix_sha256=sha((R/'tests/conformance/array-buffer-matrix.json').read_bytes()),harness=[dict(name=n,sha256=sha(b)) for n,b in harness],cases=result,scope='Two exact frozen modes plus diagnostic reductions only; no oracle/baseline or repository modification.'),indent=2)+'\n')
