assert.sameValue(typeof ArrayBuffer,'function','ArrayBuffer availability');
var $AB=ArrayBuffer,$bp=$AB.prototype,$bd=Object.getOwnPropertyDescriptor($bp,'byteLength');assert.sameValue(typeof $bd.get,'function','genuine buffer getter');var $bl=$bd.get,$g=new $AB(2);assert.sameValue($bl.call($g),2);assert.sameValue(Object.getPrototypeOf($g),$bp);
function own(o,k){return Object.prototype.hasOwnProperty.call(o,k);}
function sameThrow(t,f){var seen=false;try{f();}catch(e){seen=true;assert.sameValue(e,t);}assert.sameValue(seen,true);}
function get(name){var d=Object.getOwnPropertyDescriptor($bp,name);assert.sameValue(typeof d.get,'function');return d.get;}
function meta(b,n,max,res,det){assert.sameValue($bl.call(b),n);assert.sameValue(get('maxByteLength').call(b),max);assert.sameValue(get('resizable').call(b),res);assert.sameValue(get('detached').call(b),det);}
function method(name){var f=$bp[name];assert.sameValue(typeof f,'function',name+' availability');return f;}
function resizeMethod(){var f=method('resize'),b=new $AB(1,{maxByteLength:2});assert.sameValue(f.call(b,2),undefined);assert.sameValue($bl.call(b),2);return f;}
function sliceMethod(){var f=method('slice'),b=new $AB(2),r=f.call(b,1);assert.sameValue($bl.call(r),1);assert.notSameValue(r,b);return f;}
function transferMethod(name){var f=method(name),b=new $AB(2),r=f.call(b);assert.sameValue($bl.call(r),2);assert.sameValue($bl.call(b),0);assert.sameValue(get('detached').call(b),true);return f;}
function species(b,C){var holder={};holder[Symbol.species]=C;b.constructor=holder;}
var names=['byteLength','maxByteLength','resizable','detached'];for(var i=0;i<names.length;i++){var f=get(names[i]);verifyProperty($bp,names[i],{get:f,set:undefined,enumerable:false,configurable:true},{restore:true});verifyProperty(f,'name',{value:'get '+names[i],writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(f,'length',{value:0,writable:false,enumerable:false,configurable:true},{restore:true});assert.sameValue(own(f,'prototype'),false);assert.throws(TypeError,function(){new f();});}