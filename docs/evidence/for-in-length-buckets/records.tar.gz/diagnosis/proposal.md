# ArrayBuffer metadata resource diagnosis — source held

The two frozen ordinary-success modes are not fixed yet. No repository file,
quota, oracle, baseline or harness was changed in this investigation.

## Reproduction and cause

The preserved ArrayBuffer candidate-2 `eris-js` was checked against its release
manifest: SHA256 `57eae22986e13bd11fe031716a9bd3554b74b31dc8a86c717fea9176ef06c18b`.
The relevant current sources (`script.rs`, `own_keys.rs`, machine statements,
ArrayBuffer and the adapter) are byte-identical to that candidate's source.tar.
`runtime-bindings.json` records the individual hashes.

Two exact requests replay the unchanged frozen metadata source with the three
unchanged harness files in original order, once in each mode. Both reproduce
`resource/runtime/ResourceLimit: script instruction limit exceeded`. Every
request, stdout, stderr, process status and source is retained here. Other runs
are explicitly diagnostic reductions, not replacement expectations:

- The getter-only half and method-only half each complete.
- Four getters followed by one, two or three methods complete; adding the fourth
  method is the original resource case.
- The full case completes when the harness's `isEnumerable` is replaced only in
  the diagnostic request by its direct own-property/propertyIsEnumerable check.
  Separately bypassing only getter-side or method-side enumeration also completes.
- Repeated bare enumeration of the native function completes at 8, 16, 24 and 32
  repetitions. The failure is cumulative with the remaining metadata-helper work,
  not an infinite enumeration or an ArrayBuffer constructor loop.

`propertyHelper.js:149` checks even a false enumerable descriptor with `for-in`.
The fixture calls `verifyProperty` 24 times: eight prototype properties, and the
name and length of each of the eight functions. The functions enumerate their
own name/length, Function.prototype's eight names and Object.prototype's six
names; ArrayBuffer.prototype has nine names and the same six inherited names.
These names are nonenumerable, but must still enter the visited set to shadow
inherited duplicates correctly.

`src/script/own_keys.rs:248` bounds each reached text search as
`1 + nodes + comparisons * (query_utf16_length + 1)`, where comparisons is up to
11 per B=6 node. This is safe but charges a full queried-name scan for each
possible comparison, including unrelated builtin names whose actual comparison
usually stops earlier. `for_in_visit` also pays handle/node insertion costs.
The exact empty/native prototype chains were queried once in a diagnostic
request; their raw result is retained in prototype-keys.json.

A source-derived calculation accounts for **43,624 visited-tree work units and
6,640 snapshot units (50,264 total)** over the complete 24-enumeration path, using
the helper's delete/restore order. This is a calculation of existing explicit
charges, not instrumented runtime telemetry; it excludes machine ticks, helper
calls and ordinary property work. The terminal source limit remains 100,000.
The runtime stops during the final method's combined checks, so not every charge
in that complete-path calculation necessarily executes in the failing run.

## One proposed correction

Use a private visited-name container with an outer `BTreeMap<usize, ...>` keyed
by **UTF-16 length**, and a full `BTreeMap<JsString, ()>` within each length bucket.
Length is available without scanning/copying string contents. Equality implies
equal length; the visitation set has no externally observable sort order. This
removes actual text comparisons between different-length names while preserving
full equality, arbitrary UTF-16 and bounded logarithmic lookup within a bucket.
It avoids an unbounded quadratic sorted-vector insertion alternative.

Charge the reached outer integer search separately with the same B=6 bound;
only charge the existing text-search bound for a reached same-length bucket.
Keep cached entry search, live own-descriptor read, and insertion ordering:

1. Charge/find the integer bucket and, if present, the full text entry.
2. Existing full name returns immediately without live descriptor lookup.
3. Missing own descriptor leaves all buckets and names unchanged.
4. For a present descriptor, precharge all reached insertion movement and both
   possible node-allocation allowances before creating a new bucket/name.
5. Insert hidden properties too, before the caller checks enumerability.

A vacant outer entry need not create a bucket until the live property exists.
No author callback occurs across either cached entry borrow. Keep `own_keys`
snapshot ordering/dedup/caller buffers and all ArrayBuffer code unchanged.
Existing in-bucket worst-case text accounting stays intact. This is a real data
structure/search change, not a lower cap, free ignored work or policy exception.
Any extra outer-tree storage must be paid under the existing cumulative heap
cap; BTreeMap allocation remains the existing prepaid/infallible allocator
boundary. Do not claim the revised whole fixture passes until implemented and
measured against the untouched oracle.

Owned implementation scope, after root authorization: `src/script/own_keys.rs`,
its private tests, and the `ForInState` type/initialization in
`src/script/machine/statements.rs`; a narrow reexport only if Rust module privacy
requires it. No ArrayBuffer implementation or public fixture edits.

## Meaningful regression and cutpoint coverage

- Run the exact existing metadata source in both modes with repository-owned
  frozen assert/sta/propertyHelper bytes and unchanged ordinary-success results.
  Retain this investigation's two original failures.
- Equal contents suppress duplicates; different same-length strings stay distinct;
  include empty keys, embedded NUL and unpaired UTF-16 units. Retain Rc payload
  identity and avoid copying retained name contents.
- Show different-length misses need only bounded integer lookup, including a long
  common textual prefix; show long same-length common-prefix searches and larger
  same-length trees still consume increasing text work. Independently test outer
  tree counts around 1/12/72 keys and checked arithmetic.
- Occupied, missing-descriptor, existing-bucket insertion and new-bucket insertion
  branches each get measured exact/one-short work and heap cuts. Failed admission
  leaves the visited state unchanged; missing descriptors allocate no bucket.
- Check nonenumerable shadowing, deleted-own then inherited names, prototype
  mutation/lazy future levels, prior author-body effects and terminal cleanup.
  Retain existing own-keys semantic fixture and ArrayBuffer controls unchanged.
- Replay current formal/local inventories and existing baseline gates after the
  scoped source freeze. Report any genuine resource changes rather than editing
  expectations to absorb them. No need to rerun them during this investigation.

All execution was bounded to one existing hash-checked adapter, one request per
process, three-second timeout per request, its existing 512 MiB address-space
cap, and unchanged engine quotas. No builds, full suites or GPU work occurred.

## Explicit accounting seam

Use the existing `tree_bound(count) -> (comparisons, nodes)` for both trees,
without changing its pinned B=6 proof. Debit one unit for reading UTF-16 slice
length (constant-time metadata, no text scan). For the reached outer `entry`,
debit `1 + outer_nodes + outer_comparisons` fixed-width integer work. If its
bucket exists, debit exactly the retained conservative inner search model:
`1 + inner_nodes + inner_comparisons * (length + 1)`, saturating safely. A missing
bucket has no inner search or text comparison. Even an empty-string key uses its
ordinary zero-length bucket; no sentinel collision is needed.

For each reached cached vacant insertion, separately debit the retained
handle/edge movement bound `1 + (nodes + 1) * 24`. New-bucket insertion needs
both an inner-root insertion and the outer cached insertion; existing-bucket
insertion needs only the inner one. The outer value is a BTreeMap header, larger
than the old unit value, so its node allowance must be derived from that actual
key/value layout rather than blindly reusing the old inner-node amount. A
conservative prepaid allowance of
`16 * (size_of::<usize>() + size_of::<InnerTree>()) + 32 * size_of::<usize>() + 64`
per newly inserted length covers outer keys, map headers, edges and metadata;
the existing inner per-name allowance remains
`16 * size_of::<JsString>() + 32 * size_of::<usize>() + 64`.
Both allowances are cumulative bounds, not allocator telemetry. Check arithmetic
and charge all needed work/storage before either insertion; a refusal may consume
budget, but must leave the visited data structure unchanged. Same-length hostile
names retain their arbitrary UTF-16 comparison budget; length bucketing grants
no free text comparison. This concrete formulation still needs independent
layout review and private boundary tests before implementation acceptance.
