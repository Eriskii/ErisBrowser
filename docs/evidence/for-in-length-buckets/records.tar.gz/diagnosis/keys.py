exec((__import__('pathlib').Path(__file__).parent/'run.py').read_text().split('cases=[')[0])
source="var targets=[ArrayBuffer.prototype.transferToFixedLength,ArrayBuffer.prototype],all=[];for(var i=0;i<targets.length;i++){var p=targets[i],out=[];while(p!==null){out.push(Object.getOwnPropertyNames(p));p=Object.getPrototypeOf(p);}all.push(out);}throw JSON.stringify(all);"
case=dict(source=source.encode(),mode='sloppy',metadata=dict(negative=None),harness=harness);request=runner.encode_request(case);(D/'prototype-keys.js').write_text(source);(D/'prototype-keys.request').write_bytes(request)
p=subprocess.run([str(binary)],input=request,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=3)
(D/'prototype-keys.stdout').write_bytes(p.stdout);(D/'prototype-keys.stderr').write_bytes(p.stderr)
obs=runner.decode_response(p.stdout);(D/'prototype-keys.json').write_text(json.dumps(dict(returncode=p.returncode,observation=obs),indent=2)+'\n');print(obs)
