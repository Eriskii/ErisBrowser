import subprocess, sys
from pathlib import Path
out = Path(__file__).resolve().parent
tc = sys.argv[1]
tag = '188' if tc == '1.88.0' else '198'
tasks = []
if tag == '188':
    tasks.append(('full-default', '-', 'test', '--', '--include-ignored'))
else:
    tasks.append(('full-native', 'vulkan-raster', 'test', '--', '--include-ignored'))
for label, feature in [('default','-'),('presenter','vulkan-presenter'),('native','vulkan-raster')]:
    if tag == '198' and label == 'native': continue
    tasks.append(('clippy-'+label, feature, 'clippy', '--all-targets', '--', '-D', 'warnings'))
if tag == '188': tasks.append(('format','-','fmt','--all','--','--check'))
for label, feature, action, *args in tasks:
    # fmt has no --locked/--offline flags, so preserve its separate raw output.
    if action == 'fmt':
        import hashlib, json, os
        env = os.environ.copy()
        env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
        command = ['cargo','+'+tc,'fmt',*args]
        log = out/('format-'+tag+'-1.log')
        with log.open('xb') as f: result = subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
        record = dict(command=command,exit=result.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
        with (out/('format-'+tag+'-1.json')).open('x') as f: json.dump(record,f,indent=2);f.write('\n')
        print(record,flush=True)
        if result.returncode: raise SystemExit(result.returncode)
    else:
        subprocess.run([sys.executable,str(out/'check.py'),label+'-'+tag+'-1',tc,'Cargo.toml',feature,action,*args],check=True)
