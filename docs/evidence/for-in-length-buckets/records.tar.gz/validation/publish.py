import collections, gzip, hashlib, io, json, subprocess, tarfile
from pathlib import Path

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
WORK = Path(__file__).resolve().parent
DEST = ROOT/'docs/evidence/for-in-length-buckets'
PARENT = '45dd387375a95d2bfd89412f35cdb55739e07503'
sha = lambda data: hashlib.sha256(data).hexdigest()
read = lambda p: json.loads(p.read_bytes())
def write(p, data):
    with p.open('x') as f: json.dump(data,f,indent=2);f.write('\n')

formal = read(WORK/'formal-replay-1/profiles-comparison.json')
local = read(WORK/'locals-1/comparison.json')
ab = read(WORK/'locals-1/array-buffer.json')
assert formal['complete'] and formal['counts'] == dict(profiles=42,cases=18563,controls=4252,
    improvements=0,regressions=0,other_changes=0,control_changes=0,baseline_gates_checked=34,baseline_gates_passed=34)
assert sum(d['changed_complete_records'] for d in local['suites'].values()) == 2
assert local['suites']['array-buffer']['raw_pass_gains'] == [
    'getter-method-flags-and-nonconstructability#sloppy',
    'getter-method-flags-and-nonconstructability#strict']
assert ab['counts'] == dict(passed=90,failed=8,unsupported=2,resource=4)
assert ab['fixture_expectations_verified'] == 94 and ab['controls_verified'] == 76

# Verify the complete held archive against committed parent + the three reviewed overlays.
overlay = {'src/script/own_keys.rs','src/script/own_keys/tests.rs','src/script/machine/statements.rs'}
inventory = read(WORK/'candidate/archive-inputs.json')['files']
for r in inventory:
    p = ROOT/r['path']
    assert sha(p.read_bytes()) == r['sha256'], r['path']
    data = p.read_bytes() if r['path'] in overlay else subprocess.check_output(['git','show',PARENT+':'+r['path']],cwd=ROOT)
    assert sha(data) == r['sha256'], ('parent reconstruction',r['path'])

files = {}
def add(name, path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink(),path
    assert not name.startswith('/') and '..' not in Path(name).parts and name not in files,name
    files[name] = path
for p in sorted(WORK.iterdir()):
    if p.is_file() and p.suffix in ('.json','.log','.py','.txt'):
        add('validation/'+p.name,p)
for directory in ('candidate','locals-1','formal-replay-1','formal-preparation','replay-preparation'):
    for p in sorted((WORK/directory).rglob('*')):
        if p.is_file() and p.suffix in ('.json','.log','.py','.md','.txt'):
            add(directory+'/'+str(p.relative_to(WORK/directory)),p)
for name in sorted(overlay): add('source-overlay/'+name,ROOT/name)
for p in sorted(Path('/tmp/eris-array-buffer-metadata-diagnosis-1').rglob('*')):
    if p.is_file() and p.suffix in ('.json','.log','.py','.md','.js','.txt','.request','.stdout','.stderr'):
        add('diagnosis/'+str(p.relative_to('/tmp/eris-array-buffer-metadata-diagnosis-1')),p)
for p in [Path('/tmp/eris-for-in-length-buckets-source-ready.json'),
          Path('/tmp/eris-for-in-length-buckets-layout-review.json'),
          Path('/tmp/eris-array-buffer-metadata-layout-premise-review.md'),
          Path('/tmp/eris-array-buffer-metadata-layout-arithmetic.json'),
          Path('/tmp/eris-for-in-length-buckets-local-glue-layout-review.json'),
          Path('/tmp/eris-for-in-length-bucket-validation-plan.md')]:
    add('reviews/'+p.name,p)
# Preserve earlier observations and text-only helper dependencies referenced by the
# frozen wrappers. Historical executable builds and tar archives are identified
# by their original receipts, never copied into this public evidence package.
prior = set()
lm = read(WORK/'replay-preparation/inputs.json')
prior |= {Path(p) for p in lm['files'] if p.startswith('/tmp/')}
fm = read(WORK/'formal-preparation/inputs.json')
prior |= {Path(p['before_report']['path']) for p in fm['profiles']}
prior |= {Path(p['path']) for p in fm['prior_provenance']}
already = {p.resolve() for p in files.values()}
for p in sorted(prior):
    if p.resolve() not in already and p.suffix in ('.json','.log','.diff','.py','.js','.md','.txt'):
        if p.is_relative_to('/tmp'):
            add('retained-inputs/'+str(p.relative_to('/tmp')),p)
        else:
            add('retained-repository/'+str(p.relative_to(ROOT)),p)

DEST.mkdir(exist_ok=False)
records = []
total = 0
archive_path = DEST/'records.tar.gz'
with archive_path.open('xb') as raw, gzip.GzipFile(filename='',fileobj=raw,mode='wb',mtime=0,compresslevel=9) as gz, tarfile.open(fileobj=gz,mode='w|') as t:
    for name,p in sorted(files.items()):
        data=p.read_bytes();total+=len(data)
        assert len(data)<=32*1024**2 and total<=128*1024**2
        info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0
        t.addfile(info,io.BytesIO(data))
        records.append(dict(path=name,original_path=str(p),bytes=len(data),sha256=sha(data)))
index = dict(schema=1,archive=dict(path='records.tar.gz',bytes=archive_path.stat().st_size,
    sha256=sha(archive_path.read_bytes())),payload_count=len(records),payload_bytes=total,files=records,
    source_reconstruction=dict(parent=PARENT,overlay=sorted(overlay),complete_inventory='candidate/archive-inputs.json',
        files=len(inventory),all_reconstructed_hashes_verified=True),
    omitted='Executable builds and original source tar files; their hashes are preserved. Candidate source reconstructs from the public parent plus the three overlays. Replay drivers retain original machine paths.')
write(DEST/'index.json',index)
counts=collections.Counter()
for p in formal['profiles']: counts.update(p['after_counts'])
summary=dict(schema=1,parent=PARENT,scope='For-in visited-name length buckets; unchanged limits, fixtures, helpers, policies and baselines',
    source_overlay=sorted(overlay),source_input_sha256=read(WORK/'candidate/inputs.json')['input_sha256'],
    binary_sha256=read(WORK/'candidate/default-binaries.json')['eris-js'],
    implementation=dict(outer='BTreeMap<UTF16 length, NameBucket>',inner='BTreeMap<JsString, ()>',
        semantics='Full UTF16 equality, live descriptor checks, hidden shadowing, lazy prototypes and snapshot order preserved',
        work='Constant metadata + integer outer search; conservative full-text inner search only for reached equal-length bucket; cached prepaid insertion',
        storage='Prepaid cumulative inner nodes plus larger outer nodes including inner-map headers; additional heap cost for distinct lengths',
        quotas_increased=False),
    local=dict(suites=8,modes=1482,controls=392,verified_controls=392,changed_records=2,unchanged_records=1872,
        explicit_terminal_resource_modes_unchanged=36,changed_ids=local['suites']['array-buffer']['raw_pass_gains'],
        array_buffer=dict(counts=ab['counts'],expectations_verified=94,total_expectations=104,controls_verified=76,
            expected_terminal_resource_modes=4),
        raw_report='locals-1/array-buffer.json',comparison='locals-1/comparison.json',independent_review='replay-preparation/result-review.json'),
    formal=dict(**formal['counts'],raw_counts=dict(counts),verified_controls=4252,observations_unchanged=True,
        baselines_written=False,comparison='formal-replay-1/profiles-comparison.json',independent_review='formal-preparation/result-review.json'),
    validation=dict(toolchains=['1.88.0','1.98.0'],default_tests_each=1287,native_tests_each=1404,
        focused_own_key_groups=26,focused_metadata_remaining_work_each=12200,strict_clippy_configurations=6,format_passed=True,
        failed_first_native_188='Existing Date helper subprocess returned Unavailable; isolated unchanged test and one unchanged full rerun passed. Cause remains undetermined; all logs retained.',
        source_and_log_records='validation/validation-summary.json',
        preparation_errors='Local-wrapper expectation field, summary-only log-hash schema, and publication before-report path classification errors retained; no engine inputs altered'),
    evidence=dict(index='../../docs/evidence/for-in-length-buckets/index.json',index_sha256=sha((DEST/'index.json').read_bytes()),
        archive='../../docs/evidence/for-in-length-buckets/records.tar.gz',archive_sha256=index['archive']['sha256'],
        payloads=len(records),uncompressed_bytes=total),
    limitations=['No elapsed-time or Chromium comparison','No complete web compatibility or production security claim',
        'General property accounting and fallible allocation remain outside this change','Existing view/shared/Proxy/foreign-realm gaps remain',
        'No fresh GPU, pixel, HTML or mutation-smoke execution is attributed to this JavaScript increment'])
write(ROOT/'tests/conformance/for-in-length-buckets.json',summary)
print(json.dumps(dict(payloads=len(records),bytes=total,archive_bytes=archive_path.stat().st_size,index_sha256=summary['evidence']['index_sha256'])))
