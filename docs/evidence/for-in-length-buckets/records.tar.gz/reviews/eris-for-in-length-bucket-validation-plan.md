# For-in UTF-16-length buckets: bounded validation preparation

Source-only review. No repository, fixture, helper, quota or baseline changes;
no compiler, engine, conformance or GPU executions. The implementation and its
ordinary-success gains remain unproven. Script's independently retained
diagnostic reductions are explanatory inputs, not new expectations.

## Exact outcomes to preserve or improve

The two `getter-method-flags-and-nonconstructability` modes share source SHA256
`73e4c798e4b9ef329a7cb0f8e1bbee3c8abc032cb72625a5b77583274b6a8630`.
Their frozen expectation is ordinary completion. The current published report
records `resource/runtime/ResourceLimit: script instruction limit exceeded`.
The script agent's preserved original-binary requests reproduce that outcome.
The source calls unchanged `verifyProperty` 24 times, whose `isEnumerable`
walks for-in even for nonenumerable descriptors. Removing work in diagnostic
requests does not authorize editing this source or propertyHelper.

| Frozen row | Required expectation |
| --- | --- |
| `getter-method-flags-and-nonconstructability#sloppy` | `complete` / `runtime` |
| `getter-method-flags-and-nonconstructability#strict` | `complete` / `runtime` |
| `recursive-length-conversion-terminal-resource#sloppy` | `resource` / `runtime` |
| `recursive-length-conversion-terminal-resource#strict` | `resource` / `runtime` |
| `repeated-tiny-buffer-allocation-terminal-resource#sloppy` | `resource` / `runtime` |
| `repeated-tiny-buffer-allocation-terminal-resource#strict` | `resource` / `runtime` |

The latter four are terminal engine-policy cases. Recursive conversion must
still stop on the nesting limit; repeated allocation must still stop under
cumulative work/heap policy. Their `catch` and `finally` throw Test262Error if
termination becomes catchable or runs author cleanup. Keep those bodies and
expectations exactly; do not replace a resource with a catchable RangeError or
treat any completion as a pass. Retain their full observed error messages even
though the frozen expectation matches only resource/runtime.

The local population stays 104 cases + 76 controls. Currently 88 pass, eight
fail prerequisites, two are host-source unsupported and six hit resources;
92/104 expectations and all 76 controls verify. If only the intended two modes
gain ordinary completion, the result would be 90 raw passes, four resources,
94/104 expected results and the same 76 controls. This is an acceptance target,
not an observed result. Genuine views/shared/Proxy/foreign-realm gaps are not
part of this data-structure change. `preflight-property-metadata` positive/wrong
pairs and the common descriptor controls must keep their original success and
Test262Error outcomes in each mode.

## Minimum meaningful private regression scope

Retain all 19 own-keys groups and the existing machine/general for-in regressions
where their original semantics still apply; adapt only their visited-container
setup and newly real costs. Do not preserve obsolete one-tree numeric charges
by undercharging the new outer tree. The smallest useful additions/changes are:

1. **Exact original failure reproducer.** Execute the complete frozen metadata
   source in both modes using the original assert/sta/propertyHelper bytes and
   their established order. Check completion and clean runtime stacks. Keep
   the source whole and unchanged, with no fixture-specific branch or cap bump.
   Retain the Number-statics positive/wrong raw literals already embedded in
   `own_keys_number_constant_controls_keep_original_success_and_failure`.
2. **Identity and order across buckets.** Different same-length strings remain
   distinct; equal UTF-16 content suppresses duplicates across prototype levels.
   Include empty string, embedded NUL, lone high/low surrogates and an astral
   pair versus two BMP units. Verify shared payload pointer identity after
   insertion. An enumeration mixing lengths in creation order must retain that
   order (and numeric-key/prototype precedence), never outer length order.
   Keep symbol omission and no accessor-value evaluation.
3. **Independent outer versus inner work.** With an empty receiver, a missing descriptor and heap
   already full, absent-length misses must not allocate a bucket or scan text;
   equal outer population and different query lengths should cost the same.
   Existing-length misses/occupied names still pay the inner text/tree bound.
   Exercise outer counts 1/12/72 and same-length inner counts 1/12/72 separately;
   extend the existing long-common-prefix widths 16/512 check to show that
   same-length adversarial text work remains charged. Test exact measured work
   and one-short refusal without baking in the previous empty-map cost of 1.
4. **All-or-nothing two-tree insertion.** Separate occupied, absent descriptor
   in an existing bucket, absent descriptor in an absent bucket, present name
   in an existing bucket, and first name in a new bucket. For both insertion
   paths measure exact work/storage and refuse one unit short at each relevant
   preflight. A refused new bucket must leave no empty outer map entry. Both
   outer-header/node and inner-node allowances must be prepaid before either
   insert, including hidden descriptors. Budget debits may persist on failure;
   visited entries and object properties must not partially mutate.
5. **Cumulative heap and reached effects.** Extend the existing cumulative test
   with same-length and different-length insertion; both inner and outer charges
   accumulate and dropping an iteration grants no quota refund. Retain live
   nonenumerable shadowing, deleted-own then inherited-name behavior and lazy
   future prototypes. Keep early break before a huge unused prototype, body/
   target-setter effects before a resource cut, terminal catch/finally bypass,
   clean continuation stacks, host-unsupported and bounded prototype-cycle cases.

Existing semantic coverage is already concrete: the 86-mode `own-keys.js`
fixture includes prototype order, hidden shadows, no getter reads/symbols,
deleted-own fallthrough, added-own snapshot behavior, lazy added/replaced
prototypes and nullish target suppression. The three mutation cases retain
implementation-preservation status; do not relabel them universal spec guarantees.
`for_in_handles_prototypes_shadowing_deletions_and_per_iteration_bindings` and
`suspended_iteration_retains_closures_and_live_for_in_state` cover lexical
iteration state and machine continuations. Existing cleanup and cycle tests
must retain terminal semantics even when the new costs move a cutoff.

Implementation-review checks: UTF-16 length is metadata, not UTF-8/scalar count;
outer integer search uses the pinned B=6 bound independently of inner text
search. The outer node stores an InnerTree header and needs its own layout-sized
allowance. Hold cached outer/inner entries only across nontrapping own-descriptor
reads, never author code. Missing properties create neither names nor buckets;
nonenumerable present names still shadow. No change is needed to snapshot key
ordering, ArrayBuffer algorithms, general property lookup or existing quotas.

## Exact later commands (not executed)

Use the newly frozen candidate binary, source archive and hashes, a fresh output
directory and the existing bounded owner/supervisor. Priority private groups:

```sh
cargo +1.88.0 test --locked --lib script::own_keys::tests
cargo +1.88.0 test --locked --lib for_in
cargo +1.88.0 test --locked --lib unchanged_property_helper
cargo +1.88.0 test --locked --lib script::array_buffer::tests
```

Repeat these with 1.98 as part of the root's normal full default/feature matrix,
not as a substitute for it. The frozen local replay command interface is:

```sh
python3 -B /tmp/eris-array-buffer-local-candidate-replay.py \
  --candidate-directory "$CANDIDATE_DIR" \
  --production-input-sha256 "$CANDIDATE_INPUT_SHA256" \
  --binary-sha256 "$CANDIDATE_JS_SHA256" \
  --output-directory /tmp/eris-for-in-buckets-array-buffer-local-1 \
  --execute-authorized
```

That retained wrapper expects its original archive inventory (Cargo root,
src/assets/examples) and compares to pre-ArrayBuffer BEFORE. Before using it
with a new candidate, check archive-schema compatibility without execution;
if the new freeze includes additional core files, root should prepare a separate
hash-bound wrapper accepting that exact inventory, retaining this one. Do not
weaken source checks ad hoc. Also compare every resulting case/control row to
the published `array-buffer-final.json`, so only the new incremental changes
are credited. The unchanged inner command is:

```sh
python3 -B /tmp/eris-array-buffer-local/run.py \
  --binary "$CANDIDATE_JS" --sha256 "$CANDIDATE_JS_SHA256" \
  --output /tmp/eris-for-in-buckets-array-buffer-local-1/report.json
```

Run that inner command only under the reviewed bounded supervisor; it is not an
alternative way to bypass candidate/archive ownership checks. Preserve all 180
rows and positive-partner gating. Replay the unchanged own-keys local 86+24
population and the root's retained historical locals with their current frozen
runners; the Rust fixture test alone does not replay the 24 controls.

Focused formal commands (fresh output paths; retained baseline files unchanged):

```sh
python3 -B tools/test262_conformance.py --binary "$CANDIDATE_JS" --profile array-buffer --baseline tests/conformance/test262-array-buffer-current.json --output "$OUT/array-buffer.json"
python3 -B tools/test262_conformance.py --binary "$CANDIDATE_JS" --profile number-statics --baseline tests/conformance/test262-number-statics-current.json --output "$OUT/number-statics.json"
python3 -B tools/test262_conformance.py --binary "$CANDIDATE_JS" --profile labels --baseline tests/conformance/test262-labels-current.json --output "$OUT/labels.json"
```

The number-statics profile specifically keeps `number-statics-property-constants`
and `number-statics-property-constants-mismatch` in both modes: ordinary success
and deliberate Test262Error, not resource. Labels exercises for-in control flow.
ArrayBuffer's formal inventory is 442 modes /160 verified controls, currently
262 passed/50 failed/130 unsupported and no resources. Formal health cannot replace
the independent local metadata check.

All **42** formal profiles are affected at least through the shared
`property-success`/`property-enumerable` preflights and unchanged propertyHelper,
regardless of whether a selected source literally contains `for-in`. A complete
observation replay therefore uses this exact profile list (the three priority
profiles above need not run twice):

```sh
for profile in array-buffer array-concat array-splice array-from for-of core-iterators date \
  array-find object-integrity array-predicates array-descriptors array-last-index-of string-last-index-of regexp-match-search \
  regexp-constructor regexp-split string-search string-concat symbols string-json regexp \
  function-constructor reflect-construction new-target template-literal functions rest-parameters is-prototype-of \
  global-values array-sort identifiers array-reduce number-statics numeric-conversion numeric-parsing \
  compound-assignment addition logical-assignment uri relational equality labels; do
  python3 -B tools/test262_conformance.py --binary "$CANDIDATE_JS" \
    --profile "$profile" --output "$OUT/$profile.json"
  status=$?
  printf '%s\t%s\n' "$profile" "$status" >> "$OUT/status.tsv"
done
```

Retain nonzero observation statuses; do not stop after a pre-existing failed or
unsupported case and silently omit later profiles. Root's bounded historical
replay can execute these equivalent invocations once and preserve every full
observation/control field. Expected catalog is 18,563 modes and 4,252 controls.
No new filtering, policy/corpus/hash changes, baseline updates or gate additions
are part of this proposal. Keep all 34 existing baselines byte-identical during
replay, then evaluate their projections against those same completed reports
without a duplicate engine run. `.github/workflows/check.yml` binds the exact
34 current gate mappings. Each uses `tests/conformance/test262-PROFILE-current.json`
except `string-json`, which uses `tests/conformance/test262-current.json`.

Any ordinary resource-to-success gain elsewhere is a separately attributable
observation, not permission to change expected-resource policies. Explicit
terminal controls must retain their terminal phase/class; missing prerequisite
sources and formal exclusions remain visible. A new resource in an old passing
mode or positive/wrong control is a regression needing diagnosis, not rebaselining.

## Source/input bindings

- `src/script/own_keys.rs`: `0eb0d6480acd36518a9d5207a5928b6108db24bdbcd1a20b6a4a66f71f844104`
- `src/script/own_keys/tests.rs`: `2bf6f01a33af53ec38c1d979cc48779490d817f1f906a9238a9a68f6c919ced8`
- `src/script/machine/statements.rs`: `244089b98d946c3cf043b1e0e0d6debd2a935abb8c69f2d8e1f50064abf06eac`
- `src/script.rs`: `dd09f360f3b7633904de5b6892969b71c2e52fd52f0f30476f4a296829f3eb99`
- `tests/conformance/array-buffer-matrix.json`: `d291a4f68073316924d94f32038dbfffd440078e11f57b1a686d70b8b19b6874`
- `tests/conformance/array-buffer-final.json`: `f96264d5bb3eb5464458710d7db90a4180d7139c43042f3778d66d93f8f07ae0`
- `tests/conformance/array-buffer.js`: `f0fa6fded781ed80e20ee382367a34ea49f75258d75e66e29af24010ab50c2b3`
- `tests/conformance/array-buffer-preflights.json`: `fcb8fe944f2695a0398c00ca437ea411524aaaf04e14d6da9e6fa039ce6196a9`
- `tests/conformance/own-keys.js`: `1cf4cc23989831f50a06f135581bae6e2f5e6bbc3b79c2950a97063ef67a03c1`
- `tests/conformance/own-keys-final.json`: `019384dd871c148cc51916bb4d0884318d11c84b349e580efb39ac80a60a8520`
- `tools/test262_conformance.py`: `8bb09032cdf03406173f01e8a0ce0b8463e423800babacc65506c3a456b4b4f0`
- `tools/import_test262.py`: `8031ecd640e08b6ddad74d06684e4f435529b149d8a44a7e17da4615b8b29a4a`
- `.github/workflows/check.yml`: `94d0623def1413ba713d382e696e7aee373f855dbb9bb705e8e8c9130f1061db`
- `/tmp/eris-array-buffer-local/run.py`: `84f415035c96fd3a3e4abb09bcdcf375388c3675b31eb00b16a1600c6b8afc9b`
- `/tmp/eris-array-buffer-local-candidate-replay.py`: `1786a944ee4cc3872da6f12a17dbc8bd9bc832f0b625b32ccc3e76bcba7bdd7d`
- `/tmp/eris-array-buffer-metadata-diagnosis-1/proposal.md`: `aa0939d41cab01ab2bb0396aaddccdfa6684ab6225fb75bbf3a465c95f1f0d81`
