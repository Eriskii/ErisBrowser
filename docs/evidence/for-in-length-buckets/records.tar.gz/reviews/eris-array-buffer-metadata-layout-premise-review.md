# Length-bucketed for-in visited names: independent accounting review

Read-only proposal and draft review. No compiler, JavaScript engine, browser, GPU or runtime test was executed; no repository file was edited. Final source/test bindings will be recorded after the implementation owner releases them.

The sealed proposal is `/tmp/eris-array-buffer-metadata-diagnosis-1/proposal.md`, SHA256 `aa0939d41cab01ab2bb0396aaddccdfa6684ab6225fb75bbf3a465c95f1f0d81`.

No concrete semantic or allocation defect was found in the proposal or first production draft.

- `JsString` contains an immutable `Rc<[u16]>`; `len()` reads slice metadata. It neither scans nor clones code units. Equal arbitrary UTF-16 strings necessarily have equal lengths; bucketing does not equate different same-length strings, empty strings, embedded zero units or unpaired surrogates.
- `VisitedNames` retains a single BTreeMap header in the machine state. BTreeMap's header is independent of key/value size; the additional per-length NameBucket headers are stored within outer nodes and explicitly included in their separate allowance.
- Both supported Rust implementations use11 key/value positions and12 child edges. For these pointer-aligned types, the outer allowance `16*(size_of::<usize>()+size_of::<NameBucket>())+32*size_of::<usize>()+64` exceeds a complete internal node's keys, map headers, parent/child pointers, counters and alignment. The unchanged inner allowance covers the unit-valued tree. No name payload is copied. This is a conservative cumulative allocation allowance, not exact allocator telemetry or fallible reservation.
- Both trees start empty and never remove nodes. Each allocated node ultimately retains at least one key; cumulative allocations are bounded by inserted distinct lengths for the outer tree and inserted names across the inner trees. All new-node allowances are charged before either tree changes, so work/heap refusal leaves the visited structure unchanged even though consumed budget need not roll back. Allocator abort/panic recovery remains outside the existing prepaid BTreeMap boundary.
- `tree_bound(n)` preserves the pinned B=6 structural bound. Height h requires at least `2*6^h-1` keys; one search reaches at most h+1 nodes and compares at most `min(n,11*(h+1))` entries. The safe bound changes at counts11 and71, so10/11 and70/71 are useful boundary pairs alongside12/72. Saturating arithmetic cannot create cheap wrapped work; reading lengths and both reached searches are charged separately.
- Same-length comparisons retain the queried UTF-16 length-plus-one cost. Long common-prefix hostile strings still pay the full conservative text bound in that bucket, and more same-length nodes increase the search charge. Different-length absence avoids actual text comparisons and pays the integer outer search only.
- The retained24-per-level insertion model counts fixed-size key/value-entry moves and child-edge/backlink updates; it does not assert a bound on individual machine-word copies or CPU instructions. Split plus insertion has at most12 entry movements and12 edge updates per reached level, with the extra root-level allowance retained. Moving a map header never traverses its stored names. This interpretation should be explicit in the code comment.
- `entry()` itself does not allocate, including the empty map. An occupied full name returns before descriptor lookup. A missing descriptor leaves both maps unchanged. Existing buckets hold a cached inner vacant entry; new lengths hold a cached outer vacant entry and allocate the first inner root only after all admission succeeds. Present nonenumerable properties enter visited before enumerability filtering.
- The current `own_property` path is a direct descriptor/value-record lookup, without author callbacks. It may perform its existing Window conversion or boxed-string virtual-property allocation; those unchanged paths are not made free or newly accounted by this scoped change. Ordinary live descriptor/mapped-binding costs and global own-property accounting remain explicitly separate.
- ForIn snapshot order, prototype progression, binding/body sequencing and depth handling remain unchanged. Only membership topology changes; iteration output never walks the visited map.

Primary implementation references inspected:

- [Rust1.88 node layout and insertion](https://raw.githubusercontent.com/rust-lang/rust/1.88.0/library/alloc/src/collections/btree/node.rs)
- [Rust1.98 node layout and insertion](https://raw.githubusercontent.com/rust-lang/rust/1.98.0/library/alloc/src/collections/btree/node.rs)
- [Rust1.88 map header and cached entry](https://raw.githubusercontent.com/rust-lang/rust/1.88.0/library/alloc/src/collections/btree/map.rs)
- [Rust1.98 map header and cached entry](https://raw.githubusercontent.com/rust-lang/rust/1.98.0/library/alloc/src/collections/btree/map.rs)

Private tests and unchanged frozen fixture observations remain necessary; this source review does not claim that the original metadata fixture now passes.
