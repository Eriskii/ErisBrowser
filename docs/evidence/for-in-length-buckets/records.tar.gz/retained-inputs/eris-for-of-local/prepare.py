#!/usr/bin/env python3
"""Independent for-of oracle sources. This preparation script never executes JavaScript."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
CASES=[]
COMPLETE={'status':'complete','phase':'runtime','error_identity':'','error_type':''}
SYNTAX={'status':'exception','phase':'parse','error_identity':'SyntaxError','error_type':'SyntaxError'}
RESOURCE={'status':'resource','phase':'runtime'}
GUARD=r'''assert.sameValue(typeof Symbol,'function','Symbol prerequisite');
assert.sameValue(typeof Symbol.iterator,'symbol','well-known iterator key prerequisite');
var $foGuardSource={},$foGuardCount=0,$foGuardSum=0,$foGuardSteps=0;
$foGuardSource[Symbol.iterator]=function(){return {next:function(){var n=$foGuardSteps++;return n<2?{done:false,value:n+2}:{done:true};}};};
for(var $foGuardValue of $foGuardSource){$foGuardCount++;$foGuardSum+=$foGuardValue;}
assert.sameValue($foGuardCount,2,'successful protocol prerequisite');assert.sameValue($foGuardSum,5);assert.sameValue($foGuardSteps,3);
'''
HELPERS=r'''function sequence(values,trace){var index=0,source={},it={next:function(){if(trace)trace.push('next'+index);return index<values.length?{value:values[index++],done:false}:{done:true};}};source[Symbol.iterator]=function(){return it;};return {source:source,it:it};}
function text(a){var s='';for(var i=0;i<a.length;i++){if(i)s+=',';s+=a[i];}return s;}
'''
def case(name,source,area='protocol',prerequisites=(),expected=None,modes=('sloppy','strict'),guard=True):
 CASES.append(dict(name=name,source=(GUARD+HELPERS if guard else '')+source.strip()+'\n',area=area,prerequisites=list(prerequisites),expected=expected or COMPLETE,modes=list(modes)))
def syntax(name,source):case('syntax-'+name,source,'early-errors',expected=SYNTAX,guard=False)

def j(x):return json.dumps(x,separators=(',',':'))
# Minimal loop forms are tested independently; no array lowering is assumed.
for decl in ['var','let','const']:
 case('basic-'+decl,'var out=[];for('+decl+' x of sequence([2,4]).source)out.push(x);assert.sameValue(text(out),"2,4");','binding')
case('assignment-existing-binding','var x=9,out=[];for(x of sequence([2,4]).source)out.push(x);assert.sameValue(x,4);assert.sameValue(text(out),"2,4");','assignment')
case('empty-preserves-assignment-target','var x=9;for(x of sequence([]).source)throw "body";assert.sameValue(x,9);','assignment')
case('rhs-evaluated-once','var calls=0;function rhs(){calls++;return sequence([1,2]).source;}var sum=0;for(var x of rhs())sum+=x;assert.sameValue(calls,1);assert.sameValue(sum,3);')
case('rhs-throw-identity','var reason={},caught;function rhs(){throw reason;}try{for(var x of rhs())throw "body";}catch(e){caught=e;}assert.sameValue(caught,reason);')
case('iterable-method-zero-args-and-receiver','var o={},count=0,it={next:function(){assert.sameValue(this,it);assert.sameValue(arguments.length,0);return {done:true};}};o[Symbol.iterator]=function(){assert.sameValue(this,o);assert.sameValue(arguments.length,0);count++;return it;};for(var x of o)throw "body";assert.sameValue(count,1);')
case('inherited-iterator-accessor-receiver','var o={},p={},reads=0,it={next:function(){return {done:true};}};Object.defineProperty(p,Symbol.iterator,{get:function(){assert.sameValue(this,o);reads++;return function(){assert.sameValue(this,o);return it;};}});Object.setPrototypeOf(o,p);for(var x of o)throw "body";assert.sameValue(reads,1);')
case('primitive-iterator-method-receives-unboxed-value','var seen=0;Number.prototype[Symbol.iterator]=function(){"use strict";assert.sameValue(this,17);seen++;return {next:function(){return {done:true};}};};for(var x of 17)throw "body";assert.sameValue(seen,1);')
case('only-symbol-iterator-is-consulted','var reads=0,o={},s=sequence([5]);function poison(){reads++;throw "wrong property";}Object.defineProperty(o,"length",{get:poison});Object.defineProperty(o,"iterator",{get:poison});Object.defineProperty(o,"@@iterator",{get:poison});o[Symbol.iterator]=s.source[Symbol.iterator];var n=0;for(var x of o)n+=x;assert.sameValue(n,5);assert.sameValue(reads,0);')
case('async-iterator-is-not-a-sync-fallback','assert.sameValue(typeof Symbol.asyncIterator,"symbol");var o={},calls=0;o[Symbol.asyncIterator]=function(){calls++;return {next:function(){return {done:true};}};};assert.throws(TypeError,function(){for(var x of o){}});assert.sameValue(calls,0);',prerequisites=['Symbol.asyncIterator'])
for label,value in [('undefined','undefined'),('null','null'),('number','2'),('boolean','true'),('symbol','Symbol("x")'),('ordinary','({length:0})')]:
 case('noniterable-'+label,'assert.throws(TypeError,function(){for(var x of '+value+'){}});')
for label,value in [('missing','undefined'),('null','null'),('number','4'),('object','({})')]:
 case('iterator-method-'+label,'var o={};o[Symbol.iterator]='+value+';assert.throws(TypeError,function(){for(var x of o){}});')
case('iterator-getter-throw-before-next','var reason={},caught,reads=0,o={};Object.defineProperty(o,Symbol.iterator,{get:function(){reads++;throw reason;}});try{for(var x of o){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(reads,1);')
case('iterator-call-throw','var reason={},caught,o={};o[Symbol.iterator]=function(){throw reason;};try{for(var x of o){}}catch(e){caught=e;}assert.sameValue(caught,reason);')
for label,value in [('undefined','undefined'),('null','null'),('number','3'),('string','"it"'),('boolean','true'),('symbol','Symbol("it")')]:
 case('iterator-result-must-be-object-'+label,'var o={};o[Symbol.iterator]=function(){return '+value+';};assert.throws(TypeError,function(){for(var x of o){}});')
case('callable-iterator-object-is-accepted','var o={},it=function(){throw "iterator called";};it.next=function(){return {done:true};};o[Symbol.iterator]=function(){return it;};for(var x of o)throw "body";')
case('next-getter-once-cached-call','var reads=0,calls=0,log=[],it={},o={};Object.defineProperty(it,"next",{configurable:true,get:function(){reads++;return function(){assert.sameValue(this,it);assert.sameValue(arguments.length,0);var n=calls++;Object.defineProperty(it,"next",{value:function(){throw "late next";},configurable:true});return n<2?{value:n}:{done:true};};}});o[Symbol.iterator]=function(){return it;};for(var x of o)log.push(x);assert.sameValue(reads,1);assert.sameValue(calls,3);assert.sameValue(text(log),"0,1");')
case('next-getter-abrupt-does-not-close','var reason={},caught,closes=0,it={},o={};Object.defineProperty(it,"next",{get:function(){throw reason;}});Object.defineProperty(it,"return",{get:function(){closes++;return function(){return {};};}});o[Symbol.iterator]=function(){return it;};try{for(var x of o){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,0);')
for label,value in [('undefined','undefined'),('null','null'),('number','3'),('object','({})')]:
 case('noncallable-next-no-close-'+label,'var closes=0,it={next:'+value+',return:function(){closes++;return {};}},o={};o[Symbol.iterator]=function(){return it;};assert.throws(TypeError,function(){for(var x of o){}});assert.sameValue(closes,0);')
case('next-call-abrupt-does-not-close','var reason={},caught,closes=0,it={next:function(){throw reason;},return:function(){closes++;return {};}},o={};o[Symbol.iterator]=function(){return it;};try{for(var x of o){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,0);')
for label,value in [('undefined','undefined'),('null','null'),('number','3'),('boolean','true'),('string','"result"'),('symbol','Symbol("r")')]:
 case('nonobject-step-does-not-close-'+label,'var closes=0,s=sequence([]);s.it.next=function(){return '+value+';};s.it.return=function(){closes++;return {};};assert.throws(TypeError,function(){for(var x of s.source){}});assert.sameValue(closes,0);')
for field in ['done','value']:
 case(field+'-getter-abrupt-does-not-close','var reason={},caught,closes=0,r={done:false},s=sequence([]);Object.defineProperty(r,"'+field+'",{get:function(){throw reason;}});s.it.next=function(){return r;};s.it.return=function(){closes++;return {};};try{for(var x of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,0);')
case('done-true-skips-value-lhs-and-close','var reads=0,r={done:true},s=sequence([]);Object.defineProperty(r,"value",{get:function(){throw "value";}});s.it.next=function(){return r;};Object.defineProperty(s.it,"return",{get:function(){throw "close";}});function base(){reads++;throw "lhs";}for(base().x of s.source)throw "body";assert.sameValue(reads,0);')
case('done-toboolean-does-not-coerce','var poison={valueOf:function(){throw "valueOf";},toString:function(){throw "toString";}},s=sequence([]);poison[Symbol.toPrimitive]=function(){throw "primitive";};s.it.next=function(){return {done:poison,get value(){throw "value";}};};for(var x of s.source)throw "body";')
case('missing-done-and-value-mean-false-and-undefined','var s=sequence([]),calls=0,body=0;s.it.next=function(){calls++;return calls===1?{}:{done:true};};for(var x of s.source){body++;assert.sameValue(x,undefined);}assert.sameValue(body,1);assert.sameValue(calls,2);')
case('result-inherited-accessors-use-result-receiver','var p={},r=Object.create(p),log=[],s=sequence([]),calls=0;Object.defineProperty(p,"done",{get:function(){assert.sameValue(this,r);log.push("D");return calls>1;}});Object.defineProperty(p,"value",{get:function(){assert.sameValue(this,r);log.push("V");return 7;}});s.it.next=function(){calls++;return r;};for(var x of s.source){log.push(x);}assert.sameValue(text(log),"D,V,7,D");')
case('done-getter-can-replace-value-before-read','var s=sequence([]),r={},calls=0;Object.defineProperty(r,"done",{get:function(){r.value=8;return false;}});s.it.next=function(){return calls++?{done:true}:r;};var out;for(var x of s.source)out=x;assert.sameValue(out,8);')
case('reused-result-object-read-live','var r={done:false,value:0},s=sequence([]),i=0,out=[];s.it.next=function(){r.done=i===3;r.value=i++;return r;};for(var x of s.source)out.push(x);assert.sameValue(text(out),"0,1,2");')
# Normal completion and IteratorClose error precedence.
case('normal-exhaustion-never-reads-return','var s=sequence([1]);Object.defineProperty(s.it,"return",{get:function(){throw "return";}});for(var x of s.source)assert.sameValue(x,1);','close')
case('break-close-receiver-zero-args-once','var trace=[],s=sequence([1,2],trace);Object.defineProperty(s.it,"return",{get:function(){assert.sameValue(this,s.it);trace.push("getReturn");return function(){assert.sameValue(this,s.it);assert.sameValue(arguments.length,0);trace.push("return");return {};};}});for(var x of s.source){trace.push("body");break;}assert.sameValue(text(trace),"next0,body,getReturn,return");','close')
case('close-result-object-fields-ignored','var s=sequence([1]),calls=0;s.it.return=function(){calls++;return {get done(){throw "done";},get value(){throw "value";}};};for(var x of s.source)break;assert.sameValue(calls,1);','close')
for close_kind in ['absent','undefined','null','noncallable','getter-throw','call-throw','primitive','object']:
 for completion in ['break','return','throw']:
  definition={'absent':'','undefined':'s.it.return=undefined;','null':'s.it.return=null;','noncallable':'s.it.return=7;','getter-throw':'Object.defineProperty(s.it,"return",{get:function(){reads++;throw closeError;}});','call-throw':'s.it.return=function(){calls++;throw closeError;};','primitive':'s.it.return=function(){calls++;return 3;};','object':'s.it.return=function(){calls++;return {};};'}[close_kind]
  body={'break':'break;','return':'return bodyToken;','throw':'throw bodyToken;'}[completion]
  expect_throw=completion=='throw' or close_kind in ['noncallable','getter-throw','call-throw','primitive']
  wanted='bodyToken' if completion=='throw' else ('closeError' if close_kind in ['getter-throw','call-throw'] else None)
  checks='assert.sameValue(didThrow,'+str(expect_throw).lower()+');'
  if wanted:checks+='assert.sameValue(caught,'+wanted+');'
  elif expect_throw:checks+='assert.sameValue(caught.constructor,TypeError);'
  elif completion=='return':checks+='assert.sameValue(result,bodyToken);'
  else:checks+='assert.sameValue(result,"finished");'
  checks+='assert.sameValue(reads,'+('1' if close_kind=='getter-throw' else '0')+');assert.sameValue(calls,'+('1' if close_kind in ['call-throw','primitive','object'] else '0')+');'
  case('close-'+completion+'-'+close_kind,'var bodyToken={},closeError={},s=sequence([1]),reads=0,calls=0,result,caught,didThrow=false;'+definition+'function run(){for(var x of s.source){'+body+'}return "finished";}try{result=run();}catch(e){didThrow=true;caught=e;}'+checks,'close')
case('live-return-lookup-after-body-mutation','var s=sequence([1]),trace=[];s.it.return=function(){throw "old";};for(var x of s.source){s.it.return=function(){trace.push("new");return {};};break;}assert.sameValue(text(trace),"new");','close')
case('live-inherited-return-after-own-delete','var s=sequence([1]),p={},calls=0;s.it.return=function(){throw "old";};p.return=function(){assert.sameValue(this,s.it);calls++;return {};};for(var x of s.source){delete s.it.return;Object.setPrototypeOf(s.it,p);break;}assert.sameValue(calls,1);','close')
case('return-value-is-saved-before-close','var token={},replacement={},value=token,s=sequence([1]);s.it.return=function(){value=replacement;return {};};function run(){for(var x of s.source)return value;}assert.sameValue(run(),token);assert.sameValue(value,replacement);','close')
case('body-finally-runs-before-iterator-close','var trace=[],s=sequence([1]);s.it.return=function(){trace.push("close");return {};};for(var x of s.source){try{trace.push("body");break;}finally{trace.push("finally");}}assert.sameValue(text(trace),"body,finally,close");','control-flow')
case('outer-finally-runs-after-iterator-close','var trace=[],s=sequence([1]);s.it.return=function(){trace.push("close");return {};};try{for(var x of s.source)break;}finally{trace.push("finally");}assert.sameValue(text(trace),"close,finally");','control-flow')
case('finally-overrides-body-throw-with-break-before-close','var bodyError={},closeError={},caught,s=sequence([1]);s.it.return=function(){throw closeError;};try{for(var x of s.source){try{throw bodyError;}finally{break;}}}catch(e){caught=e;}assert.sameValue(caught,closeError);','control-flow')
case('same-loop-continue-does-not-close','var closes=0,s=sequence([1,2]),seen=[];s.it.return=function(){closes++;return {};};for(var x of s.source){seen.push(x);continue;}assert.sameValue(text(seen),"1,2");assert.sameValue(closes,0);','control-flow')
case('labeled-same-loop-continue-does-not-close','var closes=0,s=sequence([1,2]),seen=[];s.it.return=function(){closes++;return {};};again:for(var x of s.source){seen.push(x);continue again;}assert.sameValue(text(seen),"1,2");assert.sameValue(closes,0);','control-flow',['labels'])
case('outward-continue-closes-inner-only','var trace=[],outerSeq=sequence([1,2]);outerSeq.it.return=function(){trace.push("outer");return {};};outer:for(var x of outerSeq.source){var innerSeq=sequence([3,4]);innerSeq.it.return=function(){trace.push("inner"+x);return {};};for(var y of innerSeq.source)continue outer;}assert.sameValue(text(trace),"inner1,inner2");','control-flow',['labels'])
case('outward-break-closes-inner-before-outer','var trace=[],a=sequence([1]),b=sequence([2]);a.it.return=function(){trace.push("outer");return {};};b.it.return=function(){trace.push("inner");return {};};outer:for(var x of a.source){for(var y of b.source)break outer;}assert.sameValue(text(trace),"inner,outer");','control-flow',['labels'])
case('nested-close-error-replaces-break-then-outer-throw-precedence','var trace=[],first={},second={},caught,a=sequence([1]),b=sequence([2]);a.it.return=function(){trace.push("outer");throw second;};b.it.return=function(){trace.push("inner");throw first;};try{outer:for(var x of a.source){for(var y of b.source)break outer;}}catch(e){caught=e;}assert.sameValue(caught,first);assert.sameValue(text(trace),"inner,outer");','control-flow',['labels'])
case('break-enclosing-block-closes-loop','var calls=0,s=sequence([1]);s.it.return=function(){calls++;return {};};block:{for(var x of s.source)break block;throw "after loop";}assert.sameValue(calls,1);','control-flow',['labels'])
case('switch-break-does-not-close-loop','var calls=0,s=sequence([1,2]),sum=0;s.it.return=function(){calls++;return {};};for(var x of s.source){switch(x){case 1:sum+=1;break;default:sum+=2;break;}}assert.sameValue(sum,3);assert.sameValue(calls,0);','control-flow',['switch'])
# Lexical environments: head TDZ is separate from each initialized iteration.
for kind in ['let','const']:
 case('fresh-closure-'+kind,'var closures=[];for('+kind+' x of sequence([3,4,5]).source)closures.push(function(){return x;});assert.sameValue(closures[0](),3);assert.sameValue(closures[1](),4);assert.sameValue(closures[2](),5);','binding')
 case('head-tdz-'+kind,'var x=sequence([1]).source;assert.throws(ReferenceError,function(){for('+kind+' x of x){}});assert.sameValue(typeof x,"object");','binding')
 case('head-typeof-tdz-'+kind,'var x=1;assert.throws(ReferenceError,function(){for('+kind+' x of (typeof x,sequence([]).source)){}});assert.sameValue(x,1);','binding')
 case('head-captured-tdz-survives-loop-'+kind,'var f,count=0;for('+kind+' x of (f=function(){return x;},sequence([1]).source)){count++;assert.sameValue(x,1);}assert.sameValue(count,1);assert.throws(ReferenceError,f);','binding')
case('var-closures-share-final-binding','var closures=[];for(var x of sequence([3,4,5]).source)closures.push(function(){return x;});assert.sameValue(x,5);assert.sameValue(closures[0](),5);assert.sameValue(closures[1](),5);','binding')
case('let-body-mutation-does-not-seed-next-binding','var closures=[];for(let x of sequence([1,2]).source){x+=10;closures.push(function(){return x;});}assert.sameValue(closures[0](),11);assert.sameValue(closures[1](),12);','binding')
case('const-write-closes-and-restores-outer-binding','var x=9,s=sequence([1]),closes=0;s.it.return=function(){closes++;assert.sameValue(x,9);return {};};assert.throws(TypeError,function(){for(const x of s.source)x=2;});assert.sameValue(closes,1);assert.sameValue(x,9);','binding')
case('body-shadow-does-not-alter-loop-binding','var out=[];for(let x of sequence([1,2]).source){{let x=8;out.push(x);}out.push(x);}assert.sameValue(text(out),"8,1,8,2");','binding')
case('var-is-hoisted-before-rhs','function run(){assert.sameValue(x,undefined);var rhs=function(){assert.sameValue(x,undefined);return sequence([8]).source;};for(var x of rhs()){}return x;}assert.sameValue(run(),8);','binding')
case('outer-environment-observed-by-next-and-close','var x=99,trace=[],s=sequence([1,2]);var next=s.it.next;s.it.next=function(){trace.push(x);return next.call(this);};s.it.return=function(){trace.push(x);return {};};for(let x of s.source){trace.push(x);if(x===2)break;}assert.sameValue(text(trace),"99,1,99,2,99");','binding')
case('lexical-binding-restored-after-thrown-body','var x=77,token={},caught;try{for(let x of sequence([2]).source)throw token;}catch(e){caught=e;assert.sameValue(x,77);}assert.sameValue(caught,token);assert.sameValue(x,77);','binding')
case('lexical-binding-restored-before-close-throw','var x=77,token={},caught,s=sequence([2]);s.it.return=function(){assert.sameValue(x,77);throw token;};try{for(let x of s.source)break;}catch(e){caught=e;}assert.sameValue(caught,token);assert.sameValue(x,77);','binding')
case('const-of-binding-name','var out=[];for(const of of sequence([1,2]).source)out.push(of);assert.sameValue(text(out),"1,2");','binding')
case('let-of-binding-name','var out=[];for(let of of sequence([1,2]).source)out.push(of);assert.sameValue(text(out),"1,2");','binding')
case('for-of-function-callback-retains-iteration-binding','var handlers=[];for(let x of sequence([1,2]).source){handlers.push(function(v=x){return v;});}assert.sameValue(handlers[0](),1);assert.sameValue(handlers[1](),2);','binding',['default-parameters'])
# References are evaluated after the next value has been fetched.
case('member-lhs-after-value-and-before-body','var trace=[],s=sequence([]),calls=0,target={};Object.defineProperty(target,"x",{set:function(v){trace.push("set"+v);}});function base(){trace.push("base");return target;}function key(){trace.push("key-expression");return {toString:function(){trace.push("key-string");return "x";}};}s.it.next=function(){trace.push("next");return calls++?{done:true}:{get done(){trace.push("done");return false;},get value(){trace.push("value");return 7;}};};for(base()[key()] of s.source)trace.push("body");assert.sameValue(text(trace),"next,done,value,base,key-expression,key-string,set7,body,next");','assignment')
case('member-base-reevaluated-per-iteration','var targets=[{},{}],i=0;for(targets[i++].x of sequence([3,4]).source){}assert.sameValue(i,2);assert.sameValue(targets[0].x,3);assert.sameValue(targets[1].x,4);','assignment')
case('computed-symbol-target-key','var target={},key=Symbol("k");for(target[key] of sequence([3]).source){}assert.sameValue(target[key],3);','assignment')
case('computed-key-string-hint','var seen=[],target={},key={};key[Symbol.toPrimitive]=function(h){seen.push(h);return "x";};for(target[key] of sequence([4,5]).source){}assert.sameValue(target.x,5);assert.sameValue(text(seen),"string,string");','assignment')
case('lhs-base-throw-closes','var reason={},caught,closes=0,s=sequence([1]);s.it.return=function(){closes++;return {};};function base(){throw reason;}try{for(base().x of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,1);','assignment')
case('lhs-key-evaluation-throw-closes','var reason={},caught,closes=0,s=sequence([1]),target={};s.it.return=function(){closes++;return {};};function key(){throw reason;}try{for(target[key()] of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,1);','assignment')
case('lhs-key-coercion-throw-closes','var reason={},caught,closes=0,s=sequence([1]),target={},key={toString:function(){throw reason;}};s.it.return=function(){closes++;return {};};try{for(target[key] of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,1);','assignment')
case('null-base-evaluates-key-expression-but-not-key-coercion','var trace=[],s=sequence([1]);s.it.return=function(){trace.push("close");return {};};function key(){trace.push("key");return {toString:function(){throw "coercion";}};}assert.throws(TypeError,function(){for(null[key()] of s.source){}});assert.sameValue(text(trace),"key,close");','assignment')
case('setter-throw-original-outweighs-close-throw','var reason={},second={},caught,s=sequence([1]),target={};Object.defineProperty(target,"x",{set:function(){throw reason;}});s.it.return=function(){throw second;};try{for(target.x of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);','assignment')
case('setter-sees-original-receiver-and-value','var proto={},target=Object.create(proto),token={},calls=0;Object.defineProperty(proto,"x",{set:function(v){assert.sameValue(this,target);assert.sameValue(v,token);calls++;}});for(target.x of sequence([token]).source){}assert.sameValue(calls,1);','assignment')
case('strict-readonly-target-closes','var target={},calls=0,s=sequence([1]);Object.defineProperty(target,"x",{value:9});s.it.return=function(){calls++;return {};};function run(){"use strict";for(target.x of s.source){}}assert.throws(TypeError,run);assert.sameValue(calls,1);assert.sameValue(target.x,9);','assignment')
case('sloppy-readonly-target-ignores-write-and-exhausts','var target={},calls=0,s=sequence([1,2]);Object.defineProperty(target,"x",{value:9});s.it.return=function(){calls++;return {};};var run=Function("target","source","var n=0;for(target.x of source)n++;return n;");assert.sameValue(run(target,s.source),2);assert.sameValue(calls,0);assert.sameValue(target.x,9);','assignment',['Function'])
case('value-captured-before-lhs-author-mutation','var token={},replacement={},result={done:false,value:token},target={},s=sequence([]),n=0;s.it.next=function(){return n++?{done:true}:result;};function base(){result.value=replacement;return target;}for(base().x of s.source){}assert.sameValue(target.x,token);assert.sameValue(result.value,replacement);','assignment')
# Native array iteration must remain a live protocol path.
case('array-values-and-iterator-alias','assert.sameValue(typeof Array.prototype.values,"function");assert.sameValue(Array.prototype[Symbol.iterator],Array.prototype.values);var out=[];for(var x of [1,2])out.push(x);assert.sameValue(text(out),"1,2");','array',['array-iterator'])
case('array-iterator-override-wins-over-dense-storage','var a=[1,2],s=sequence([8]);a[Symbol.iterator]=s.source[Symbol.iterator];var out=[];for(var x of a)out.push(x);assert.sameValue(text(out),"8");','array',['array-iterator'])
case('array-holes-are-visited-as-undefined','var a=new Array(3),out=[];for(var x of a)out.push(x);assert.sameValue(out.length,3);assert.sameValue(out[0],undefined);assert.sameValue(out[1],undefined);assert.sameValue(out[2],undefined);','array',['array-iterator'])
case('array-inherited-hole-getter-live','var a=new Array(2),p=Object.create(Array.prototype),reads=0,out=[];Object.defineProperty(p,"0",{get:function(){assert.sameValue(this,a);reads++;return 7;}});Object.setPrototypeOf(a,p);a[1]=8;for(var x of a)out.push(x);assert.sameValue(text(out),"7,8");assert.sameValue(reads,1);','array',['array-iterator'])
case('array-growth-after-first-value','var a=[1],out=[];for(var x of a){out.push(x);if(x===1)a.push(2);}assert.sameValue(text(out),"1,2");','array',['array-iterator'])
case('array-shrink-stops-next-step','var a=[1,2,3],out=[];for(var x of a){out.push(x);a.length=0;}assert.sameValue(text(out),"1");','array',['array-iterator'])
case('array-deleted-later-index-becomes-hole','var a=[1,2],out=[];for(var x of a){out.push(x);delete a[1];}assert.sameValue(out.length,2);assert.sameValue(out[0],1);assert.sameValue(out[1],undefined);','array',['array-iterator'])
case('array-later-descriptor-mutation-is-live','var a=[1,2],out=[];for(var x of a){out.push(x);if(out.length===1)Object.defineProperty(a,"1",{get:function(){return 9;}});}assert.sameValue(text(out),"1,9");','array',['array-iterator'])
case('array-iterator-length-not-cached','var calls=0,o={0:1,1:2,get length(){calls++;return calls===1?2:1;}};o[Symbol.iterator]=Array.prototype.values;var out=[];for(var x of o)out.push(x);assert.sameValue(text(out),"1");assert.sameValue(calls,2);','array',['array-iterator'])
case('array-iterator-next-error-does-not-close','var reason={},caught,closes=0,o={get length(){throw reason;}};var it=Array.prototype.values.call(o);it.return=function(){closes++;return {};};var iterable={};iterable[Symbol.iterator]=function(){return it;};try{for(var x of iterable){}}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(closes,0);','array',['array-iterator'])
case('array-max-u32-first-value-with-break','var a=new Array(4294967295),n=0;for(var x of a){assert.sameValue(x,undefined);n++;break;}assert.sameValue(n,1);','array',['array-iterator'])
case('array-values-huge-generic-range-first-value','var o={length:Infinity,0:9};o[Symbol.iterator]=Array.prototype.values;var n=0;for(var x of o){assert.sameValue(x,9);n++;break;}assert.sameValue(n,1);','array',['array-iterator'])
case('arguments-iterator-alias-and-mapped-live-value','var f=Function("var out=[],a=arguments;for(var x of a){out.push(x);if(out.length===1)a[1]=9;}return out;");var out=f(1,2);assert.sameValue(text(out),"1,9");','array',['arguments-iterator','Function'])
case('array-iterator-stays-completed-after-growth','var a=[],it=a[Symbol.iterator]();assert.sameValue(it.next().done,true);a.push(1);assert.sameValue(it.next().done,true);','array',['array-iterator'])
case('array-iterator-self-iterable','var it=[1,2][Symbol.iterator]();assert.sameValue(it[Symbol.iterator](),it);var out=[];for(var x of it)out.push(x);assert.sameValue(text(out),"1,2");','array',['array-iterator'])
# Unicode scalar iteration preserves unpaired code units and does not normalize.
for label,src,want in [
 ('empty','""',[]),('ascii','"ab"',['a','b']),('supplementary','"A\\uD83D\\uDE00B"',['A','\U0001f600','B']),
 ('isolated-high','"\\uD800x"',['\ud800','x']),('isolated-low','"x\\uDC00"',['x','\udc00']),
 ('high-high-low','"\\uD800\\uD801\\uDC00"',['\ud800','\U00010400']),
 ('no-normalization','"e\\u0301\\u00e9"',['e','\u0301','\u00e9']),
 ('nul','"a\\u0000b"',['a','\u0000','b'])]:
 case('string-'+label,'var out=[];for(var x of '+src+')out.push(x);var want='+j(want)+';assert.sameValue(out.length,want.length);for(var i=0;i<want.length;i++)assert.sameValue(out[i],want[i]);','string',['string-iterator'])
case('boxed-string-iteration','var out=[];for(var x of Object("ab"))out.push(x);assert.sameValue(text(out),"a,b");','string',['string-iterator'])
case('string-iterator-converts-once-at-acquisition','var calls=0,obj={toString:function(){calls++;return "ab";}};var it=String.prototype[Symbol.iterator].call(obj);assert.sameValue(calls,1);obj.toString=function(){throw "late conversion";};var out=[];for(var x of it)out.push(x);assert.sameValue(text(out),"a,b");assert.sameValue(calls,1);','string',['string-iterator'])
case('string-iterator-nullish-brand-and-symbol-conversion','assert.sameValue(typeof String.prototype[Symbol.iterator],"function");assert.sameValue(String.prototype[Symbol.iterator].call("a").next().value,"a");assert.throws(TypeError,function(){String.prototype[Symbol.iterator].call(null);});assert.throws(TypeError,function(){String.prototype[Symbol.iterator].call(undefined);});assert.throws(TypeError,function(){String.prototype[Symbol.iterator].call(Symbol("x"));});','string',['string-iterator'])
case('string-iterator-override-on-prototype','var old=String.prototype[Symbol.iterator],s=sequence([9]);String.prototype[Symbol.iterator]=s.source[Symbol.iterator];var out=[];for(var x of "ab")out.push(x);assert.sameValue(text(out),"9");String.prototype[Symbol.iterator]=old;','string',['string-iterator'])
case('string-iterator-next-brand','var it="a"[Symbol.iterator](),next=it.next;assert.throws(TypeError,function(){next.call({});});assert.sameValue(next.call(it).value,"a");assert.sameValue(next.call(it).done,true);','string',['string-iterator'])
# Additional iterator and environment traps, independent of the future implementation.
case('var-loop-resolves-current-catch-binding','function run(){var x=1,seen;try{throw 7;}catch(x){for(var x of sequence([9]).source)seen=x;assert.sameValue(x,9);}assert.sameValue(x,1);return seen;}assert.sameValue(run(),9);','binding')
case('regex-and-template-rhs-rescan','var out=[];for(var x of (/[}]/.test("}")?sequence([`v${1}`]).source:sequence([]).source))out.push(x);assert.sameValue(text(out),"v1");','grammar')
case('labeled-loop-double-label-current-continue','var out=[],s=sequence([1,2]),closes=0;s.it.return=function(){closes++;return {};};first:second:for(var x of s.source){out.push(x);continue first;}assert.sameValue(text(out),"1,2");assert.sameValue(closes,0);','control-flow',['labels'])
case('array-element-getter-reenters-next-after-index-advance','var a=[0,2,3],it=a.values(),nested;Object.defineProperty(a,"0",{get:function(){nested=it.next();return 1;}});var first=it.next();assert.sameValue(first.value,1);assert.sameValue(nested.value,2);assert.sameValue(it.next().value,3);assert.sameValue(it.next().done,true);','array',['array-iterator'])
case('array-element-getter-throw-still-advances-index','var reason={},caught,a=[1,2],it=a.values();Object.defineProperty(a,"0",{get:function(){throw reason;}});try{it.next();}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(it.next().value,2);assert.sameValue(it.next().done,true);','array',['array-iterator'])
case('array-length-getter-throw-does-not-advance-index','var reason={},caught,calls=0,o={0:8,get length(){if(calls++===0)throw reason;return 1;}},it=Array.prototype.values.call(o);try{it.next();}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(it.next().value,8);','array',['array-iterator'])
case('array-values-creation-does-not-read-length','var calls=0,o={get length(){calls++;return 0;}},it=Array.prototype.values.call(o);assert.sameValue(calls,0);assert.sameValue(it.next().done,true);assert.sameValue(calls,1);assert.sameValue(it.next().done,true);assert.sameValue(calls,1);','array',['array-iterator'])
case('array-result-descriptors-and-fresh-identity','var it=[7].values(),a=it.next(),b=it.next(),c=it.next();verifyProperty(a,"value",{value:7,writable:true,enumerable:true,configurable:true},{restore:true});verifyProperty(a,"done",{value:false,writable:true,enumerable:true,configurable:true},{restore:true});assert.sameValue(Object.getPrototypeOf(a),Object.prototype);assert.sameValue(b.value,undefined);assert.sameValue(b.done,true);assert.notSameValue(a,b);assert.notSameValue(b,c);','array',['array-iterator'])
case('array-next-rejects-fake-prototype-object','var it=[1].values(),next=it.next;assert.sameValue(next.call(it).value,1);assert.throws(TypeError,function(){next.call(Object.create(Object.getPrototypeOf(it)));});assert.throws(TypeError,function(){next.call(null);});','array',['array-iterator'])
case('freezing-native-iterator-does-not-freeze-progress','var it=[1,2].values();Object.freeze(it);assert.sameValue(it.next().value,1);assert.sameValue(it.next().value,2);assert.sameValue(it.next().done,true);var str="ab"[Symbol.iterator]();Object.freeze(str);assert.sameValue(str.next().value,"a");assert.sameValue(str.next().value,"b");','array',['array-iterator','string-iterator'])
case('array-values-alias-remains-after-property-replacement','var values=Array.prototype.values,iterator=Array.prototype[Symbol.iterator];Array.prototype.values=1;var out=[];for(var x of [4])out.push(x);assert.sameValue(text(out),"4");assert.sameValue(iterator,values);assert.sameValue(values.call([9]).next().value,9);','array',['array-iterator'])
case('arguments-own-iterator-descriptor','function f(){verifyProperty(arguments,Symbol.iterator,{value:Array.prototype.values,writable:true,enumerable:false,configurable:true},{restore:true});var out=[];for(var x of arguments)out.push(x);return out;}assert.sameValue(text(f(2,3)),"2,3");','array',['arguments-iterator','array-iterator'])
case('strict-arguments-iteration','function f(a){"use strict";var out=[];for(var x of arguments){out.push(x);a=9;}return out;}assert.sameValue(text(f(2,3)),"2,3");','array',['arguments-iterator'])
case('mapped-parameter-mutation-is-observed-by-iterator','var f=Function("a","b","var out=[];for(var x of arguments){out.push(x);b=9;}return out;");assert.sameValue(text(f(1,2)),"1,9");','array',['arguments-iterator','Function'])
for family in ['Array','String']:
 factory='[1].values()' if family=='Array' else '"x"[Symbol.iterator]()'
 expected_name='values' if family=='Array' else '[Symbol.iterator]'
 method='Array.prototype.values' if family=='Array' else 'String.prototype[Symbol.iterator]'
 owner='Array.prototype' if family=='Array' else 'String.prototype'
 key='"values"' if family=='Array' else 'Symbol.iterator'
 case(family.lower()+'-iterator-native-metadata','var m='+method+',it='+factory+',proto=Object.getPrototypeOf(it),next=it.next;assert.sameValue(typeof m,"function");assert.sameValue(next.call(it).done,false);verifyProperty('+owner+','+key+',{value:m,writable:true,enumerable:false,configurable:true},{restore:true});verifyProperty(m,"name",{value:'+j(expected_name)+',writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(m,"length",{value:0,writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(proto,"next",{value:next,writable:true,enumerable:false,configurable:true},{restore:true});verifyProperty(next,"name",{value:"next",writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(next,"length",{value:0,writable:false,enumerable:false,configurable:true},{restore:true});assert.sameValue(Object.getOwnPropertyDescriptor(m,"prototype"),undefined);assert.throws(TypeError,function(){new m();});assert.throws(TypeError,function(){new next();});verifyProperty(proto,Symbol.toStringTag,{value:"'+family+' Iterator",writable:false,enumerable:false,configurable:true},{restore:true});assert.sameValue(Object.prototype.toString.call(it),"[object '+family+' Iterator]");','metadata',[family.lower()+'-iterator'])
case('common-iterator-prototype-self-method-is-generic','var a=[1].values(),s="a"[Symbol.iterator](),ap=Object.getPrototypeOf(Object.getPrototypeOf(a)),sp=Object.getPrototypeOf(Object.getPrototypeOf(s));assert.sameValue(ap,sp);var m=ap[Symbol.iterator],token={};assert.sameValue(m.call(token),token);assert.sameValue(m.call(null),null);assert.sameValue(m.call(3),3);assert.sameValue(a[Symbol.iterator](),a);assert.sameValue(s[Symbol.iterator](),s);','metadata',['array-iterator','string-iterator'])
# Visible prerequisites remain in the same denominator, never metadata-excluded.
case('array-destructuring-binding','var out=[];for(const [a,b] of sequence([[1,2],[3,4]]).source)out.push(a+b);assert.sameValue(text(out),"3,7");','prerequisite',['destructuring'])
case('object-destructuring-binding','var out=[];for(let {x:y} of sequence([{x:1},{x:2}]).source)out.push(y);assert.sameValue(text(out),"1,2");','prerequisite',['destructuring'])
case('destructuring-assignment','var a,b;for([a,b] of sequence([[1,2]]).source){}assert.sameValue(a,1);assert.sameValue(b,2);','prerequisite',['destructuring'])
case('destructuring-default-tdz-closes','var closes=0,s=sequence([[undefined]]);s.it.return=function(){closes++;return {};};assert.throws(ReferenceError,function(){for(let [x=x] of s.source){}});assert.sameValue(closes,1);','prerequisite',['destructuring','array-iterator'])
case('generator-return-finally-on-break','var log=[];function* gen(){try{yield 1;yield 2;}finally{log.push("finally");}}for(var x of gen()){assert.sameValue(x,1);break;}assert.sameValue(text(log),"finally");','prerequisite',['generators'])
case('async-for-of-parser-prerequisite','async function f(source){for await(const x of source){return x;}}assert.sameValue(typeof f,"function");','prerequisite',['async-functions','for-await-of'])
# Early errors stand alone; passing them is insufficient without the successful protocol preflight.
for name,src in [
 ('raw-async-target','var async;for(async of []){}'),('lexical-let-binding','for(let let of []){}'),('ordinary-const-needs-value','const x;'),('classic-for-const-needs-value','for(const x;false;){}'),
 ('const-initializer','for(const x=1 of []){}'),('let-initializer','for(let x=1 of []){}'),('var-initializer','for(var x=1 of []){}'),
 ('multiple-var-bindings','for(var x,y of []){}'),('multiple-let-bindings','for(let x,y of []){}'),('multiple-const-bindings','for(const x,y of []){}'),
 ('escaped-of-separator',r'for(var x o\u0066 []){}'),('comma-rhs','for(var x of [],[]){}'),
 ('invalid-assignment-binary','for(a+b of []){}'),('duplicate-lexical-in-body','for(let x of []){var x;}'),
 ('continue-undefined-label','for(var x of []){continue missing;}'),('break-undefined-label','for(var x of []){break missing;}'),
 ('duplicate-label','again:again:for(var x of []){}'),('continue-noniteration-label','block:{for(var x of [])continue block;}')]:syntax(name,src)
case('parenthesized-async-target-is-valid','var async=0;for((async) of sequence([7]).source){}assert.sameValue(async,7);','grammar')
case('declared-async-binding-is-valid','var out=[];for(var async of sequence([7]).source)out.push(async);assert.sameValue(text(out),"7");','grammar')
case('parenthesized-comma-rhs-is-valid','var out=[];for(var x of (0,sequence([4]).source))out.push(x);assert.sameValue(text(out),"4");','grammar')
# These are Eris bounded-execution assertions, not ECMAScript exception claims.
case('budget-infinite-iterator-is-terminal','var s=sequence([]);s.it.next=function(){return {value:1,done:false};};try{for(var x of s.source){}}catch(e){throw "resource was catchable";}throw "infinite loop completed";','budget',expected=RESOURCE)
case('budget-next-callback-infinite-is-terminal','var s=sequence([]);s.it.next=function(){while(true){}};try{for(var x of s.source){}}catch(e){throw "resource was catchable";}','budget',expected=RESOURCE)
case('budget-close-callback-infinite-is-terminal','var s=sequence([1]);s.it.return=function(){while(true){}};try{for(var x of s.source)break;}catch(e){throw "resource was catchable";}','budget',expected=RESOURCE)
case('budget-recursive-next-is-terminal','var s=sequence([]);s.it.next=function(){for(var x of s.source){}};try{for(var x of s.source){}}catch(e){throw "resource was catchable";}','budget',expected=RESOURCE)
case('budget-retained-lexical-closures-is-terminal','var out=[],s=sequence([]),n=0;s.it.next=function(){return {value:n++};};try{for(let x of s.source)out.push(function(){return x;});}catch(e){throw "resource was catchable";}','budget',expected=RESOURCE)
case('budget-large-array-hole-range-is-terminal','try{for(var x of new Array(4294967295)){}}catch(e){throw "resource was catchable";}','budget',['array-iterator'],expected=RESOURCE)

# Paired preflights are authored before any adapter run. Wrong partners change only a final expected value.
PAIRS=[]
def pair(name,setup,expression,correct,wrong):
 PAIRS.append(dict(name=name,setup=GUARD+HELPERS+setup,expression=expression,correct=correct,wrong=wrong))
pair('protocol-values','var out=[];for(var x of sequence([2,3]).source)out.push(x);','text(out)','"2,3"','"3,2"')
pair('next-cache','var n=0,reads=0,o={},it={};Object.defineProperty(it,"next",{get:function(){reads++;return function(){return n++?{done:true}:{value:4};};}});o[Symbol.iterator]=function(){return it;};for(var x of o){}','reads','1','2')
pair('close-break','var count=0,s=sequence([1]);s.it.return=function(){count++;return {};};for(var x of s.source)break;','count','1','0')
pair('no-close-step-error','var count=0,reason={},caught,s=sequence([]);s.it.next=function(){throw reason;};s.it.return=function(){count++;return {};};try{for(var x of s.source){}}catch(e){caught=e;}assert.sameValue(caught,reason);','count','0','1')
pair('throw-precedence','var original={},closing={},caught,s=sequence([1]);s.it.return=function(){throw closing;};try{for(var x of s.source)throw original;}catch(e){caught=e;}','caught','original','closing')
pair('lexical-closures','var f=[];for(let x of sequence([1,2]).source)f.push(function(){return x;});','f[0]()','1','2')
pair('tdz','var caught=false;try{for(let x of x){}}catch(e){assert.sameValue(e.constructor,ReferenceError);caught=true;}','caught','true','false')
pair('assignment-order','var n=0,target={},s=sequence([1]);function base(){n++;return target;}for(base().x of s.source){}','n','1','2')
pair('unicode','var out=[];for(var x of "A\\uD83D\\uDE00B")out.push(x);','out.length','3','4')
pair('array-live-growth','var a=[1],out=[];for(var x of a){out.push(x);if(x===1)a.push(2);}','text(out)','"1,2"','"1"')
pair('same-loop-continue','var closes=0,s=sequence([1,2]);s.it.return=function(){closes++;return {};};for(var x of s.source)continue;','closes','0','2')
pair('outward-label-close','var count=0,a=sequence([1]),b=sequence([2]);b.it.return=function(){count++;return {};};outer:for(var x of a.source){for(var y of b.source)continue outer;}','count','1','0')

if __name__=='__main__':
 assert len({r['name'] for r in CASES})==len(CASES)
 for name in ('for-of.js','freeze.json','preflights.json'):
  if (HERE/name).exists():raise SystemExit('refusing to overwrite frozen '+name)
 data=''.join('// CASE: '+r['name']+'\n'+r['source'] for r in CASES).encode()
 (HERE/'for-of.js').write_bytes(data)
 (HERE/'preflights.json').write_text(json.dumps(PAIRS,indent=2)+'\n')
 record={'fixture_sha256':hashlib.sha256(data).hexdigest(),'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'source_cases':len(CASES),'mode_cases':sum(len(r['modes']) for r in CASES),'cases':[{k:v for k,v in r.items() if k!='source'} for r in CASES],'preflight_pairs':len(PAIRS),'preflights_sha256':hashlib.sha256((HERE/'preflights.json').read_bytes()).hexdigest(),'preparation_never_executed_an_engine':True}
 (HERE/'freeze.json').write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps({k:v for k,v in record.items() if k!='cases'},indent=2))
