#!/usr/bin/env python3
"""Freeze/replay independent for-of cases. --prepare never starts an engine."""
import argparse,collections,hashlib,json,resource,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'tools'))
import test262_conformance as runner

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def fingerprint(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
COMPLETE=dict(status='complete',phase='runtime',error_identity='',error_type='')
WRONG=dict(status='exception',phase='runtime',error_identity='',error_type='Test262Error')

def make_case(name,source,mode,expected,harness,filename='for-of.js'):
 negative=dict(phase='parse',type='SyntaxError') if expected.get('phase')=='parse' else None
 c=dict(id=name+'#'+mode,file=filename,source=source,mode=mode,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=negative),harness=harness)
 c['case_sha256']=runner.case_fingerprint(c)
 return c

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--prepare',action='store_true');ap.add_argument('--binary',type=Path);ap.add_argument('--sha256');ap.add_argument('--output',type=Path);args=ap.parse_args()
 freeze=json.loads((HERE/'freeze.json').read_text());fixture=HERE/'for-of.js'
 assert sha(fixture)==freeze['fixture_sha256'] and sha(HERE/'prepare.py')==freeze['generator_sha256']
 assert sha(HERE/'preflights.json')==freeze['preflights_sha256']
 harness=[(n,(HERE/'harness'/n).read_bytes()) for n in ('assert.js','sta.js','propertyHelper.js')]
 records={r['name']:r for r in freeze['cases']};matrix=[];seen=set()
 for block in fixture.read_bytes().split(b'// CASE: ')[1:]:
  raw_name,source=block.split(b'\n',1);name=raw_name.decode();assert name not in seen;seen.add(name)
  item=records[name]
  for mode in item['modes']:
   c=make_case(name,source,mode,item['expected'],harness)
   matrix.append((c,item['expected'],dict(category='fixture',area=item['area'],prerequisites=item['prerequisites'])))
 assert seen==set(records) and len(seen)==freeze['source_cases']
 pairs=json.loads((HERE/'preflights.json').read_text())
 for pair in pairs:
  for mode in ('sloppy','strict'):
   for positive in (True,False):
    name='preflight-'+pair['name']+('-positive' if positive else '-wrong')
    source=(pair['setup']+'\nassert.sameValue('+pair['expression']+','+pair['correct' if positive else 'wrong']+');\n').encode()
    expected=COMPLETE if positive else WRONG
    c=make_case(name,source,mode,expected,harness,'preflight-controls')
    matrix.append((c,expected,dict(category='preflight-control',positive=positive,partner='preflight-'+pair['name']+'-positive#'+mode)))
 harness_pairs=[('samevalue','assert.sameValue(NaN,NaN);assert.notSameValue(0,-0);','assert.sameValue(0,-0);'),('error-identity','assert.throws(TypeError,function(){throw new TypeError();});','assert.throws(TypeError,function(){throw new RangeError();});'),('property-flags',"verifyProperty({x:1},'x',{value:1,writable:true,enumerable:true,configurable:true});","verifyProperty({x:1},'x',{value:1,writable:false,enumerable:true,configurable:true});")]
 for name,good,bad in harness_pairs:
  for mode in ('sloppy','strict'):
   for positive,source in [(True,good),(False,bad)]:
    label='harness-'+name+('-positive' if positive else '-wrong');expected=COMPLETE if positive else WRONG
    c=make_case(label,source.encode(),mode,expected,harness,'harness-controls')
    matrix.append((c,expected,dict(category='harness-control',positive=positive,partner='harness-'+name+'-positive#'+mode)))
 identities=[]
 for c,e,extra in matrix:
  identities.append(dict(id=c['id'],mode=c['mode'],case_sha256=c['case_sha256'],source_sha256=hashlib.sha256(c['source']).hexdigest(),source=c['source'].decode(),expected=e,expectation_sha256=fingerprint(e),**extra))
 record=dict(fixture_sha256=sha(fixture),freeze_sha256=sha(HERE/'freeze.json'),runner_sha256=sha(__file__),tool_hashes={p.name:sha(p) for p in sorted((HERE/'tools').glob('*.py'))},harness=[dict(name=n,sha256=hashlib.sha256(b).hexdigest()) for n,b in harness],cases=identities)
 if args.prepare:
  if (HERE/'matrix.json').exists():ap.error('refusing to replace frozen matrix')
  assert len({r['id'] for r in identities})==len(identities)
  (HERE/'matrix.json').write_text(json.dumps(record,indent=2)+'\n')
  print('FROZEN',len(seen),'source cases;',freeze['mode_cases'],'fixture modes;',4*len(pairs),'preflights;',4*len(harness_pairs),'harness controls')
  return 0
 if args.binary is None or args.sha256 is None or args.output is None:ap.error('--binary, --sha256 and --output required')
 if args.output.exists():ap.error('refusing to overwrite observations')
 assert record==json.loads((HERE/'matrix.json').read_text()),'frozen inputs changed'
 binary=args.binary.resolve();assert sha(binary)==args.sha256,'binary hash mismatch'
 resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024));resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 started=time.monotonic();observed=[]
 for (case,expected,extra),identity in zip(matrix,identities):
  result=runner.run_case(case,binary,3)
  result.update(extra,source=identity['source'],expected_observation=expected,expectation_sha256=identity['expectation_sha256'])
  result['matches_expectation']=all(result.get('observation',{}).get(k)==v for k,v in expected.items())
  observed.append(result)
  print(result['id'],result['status'],result.get('observation',{}).get('message',''),flush=True)
 by_id={r['id']:r for r in observed}
 controls=[r for r in observed if r['category']!='fixture']
 for r in controls:
  r['verified']=r['matches_expectation'] and by_id[r['partner']]['matches_expectation']
 fixtures=[r for r in observed if r['category']=='fixture']
 protocol_ok=all(by_id['preflight-protocol-values-positive#'+m]['matches_expectation'] for m in ('sloppy','strict'))
 for r in fixtures:
  r['verified_with_protocol_prerequisite']=r['matches_expectation'] and protocol_ok
 assert sha(binary)==args.sha256 and sha(fixture)==freeze['fixture_sha256']
 report=dict(binary=str(binary),binary_sha256=args.sha256,fixture_sha256=sha(fixture),matrix_sha256=sha(HERE/'matrix.json'),runner_sha256=sha(__file__),tool_hashes=record['tool_hashes'],harness=record['harness'],bounds=dict(per_case_wall_seconds=3,address_space_bytes=512*1024*1024,per_process_cpu_seconds=30,core_bytes=0,adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024),counts=dict(collections.Counter(r['status'] for r in fixtures)),areas={area:dict(collections.Counter(r['status'] for r in fixtures if r['area']==area)) for area in sorted({r['area'] for r in fixtures})},cases=fixtures,controls=controls,protocol_prerequisite_verified=protocol_ok,controls_verified=sum(r['verified'] for r in controls),fixture_expectations_matched=sum(r['matches_expectation'] for r in fixtures),fixture_expectations_verified=sum(r['verified_with_protocol_prerequisite'] for r in fixtures),resource_expectations_are_engine_policy_not_ecmascript_errors=True,elapsed_seconds=round(time.monotonic()-started,4))
 with args.output.open('x') as f:f.write(json.dumps(report,indent=2)+'\n')
 print('RESULT',len(fixtures),report['counts'],'CONTROLS',report['controls_verified'],'/',len(controls))
 return 0
if __name__=='__main__':raise SystemExit(main())
