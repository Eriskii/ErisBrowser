# Independent for-of preparation

This scratch fixture was authored from the current ECMAScript algorithms before
any baseline or candidate execution. No JavaScript engine, browser, Cargo build,
production edit, corpus import or baseline update was performed during preparation.
The separately collected pinned upstream inventory is not selected or filtered by
this local fixture.

The frozen source contains 202 independent cases, each run in sloppy and strict
mode (404 fixture modes): 356 ordinary-success expectations, 36 parse SyntaxError
expectations and twelve explicit terminal-resource expectations. Twelve paired
feature checks produce 48 preflights; three paired assertion-helper checks produce
12 additional controls. Every wrong assertion changes only its final expected
value and requires its successful positive partner before verification. The exact
assert.js, sta.js and propertyHelper.js bytes match the pinned Test262 Date corpus.

The cases cover custom protocol acquisition, cached next, done/value getters,
no-close step failures, assignment/body exits, all 24 break/return/throw versus
closing-result combinations, labels/finally, head TDZ and captured environments,
member references, live array/arguments values, Unicode string iteration and
native iterator metadata/reentrancy. The malformed-head cases preserve contextual
`of`/`async` rules and the normal const-initializer restriction.

Every runtime semantic case begins with a successful custom-iterator guard. An
incorrect early SyntaxError cannot verify a parse-negative case unless both
positive protocol modes run successfully. Raw statuses and full adapter
observations remain recorded separately from this verification decision.

Prerequisite annotations are descriptive and never metadata exclusions. The
six destructuring/generator/async-declaration cases keep ordinary success
expectations; unsupported or failed results remain visible. The async case only
checks parsing/declaration, not asynchronous iteration or job scheduling. Other
selected cases also retain their explicit Symbol.asyncIterator, native iterator,
arguments iterator, Function, labels, switch and default-parameter dependencies.
This is a selected local behavior matrix, not a complete language corpus. It does
not claim Proxy, typed arrays, Map/Set, keys/entries, iterator helpers, disposal,
spread, Array.from, cross-realm behavior or asynchronous execution coverage.

The six budget cases expect Eris runtime resource termination, not an ECMAScript
exception. They cover infinite next/loop/close execution, recursive stepping,
retained iteration closures and a huge sparse logical range. The framed adapter
cannot inspect private state after terminal failure: exact counter restoration,
no author closing/finally after resource exhaustion, precharge failure boundaries
and cumulative quota behavior still need private Runtime tests. No exact failure
message, step count or allocation count is guessed here.

`prepare.py` materializes the source and fixed expected records; `run.py --prepare`
freezes every source/mode/harness/expectation fingerprint. Both refuse to replace
existing frozen records. `run.py --binary PATH --sha256 HASH --output NEW_PATH`
will later use the copied runner modules with 3 seconds wall time per case,
512 MiB address space, 30 CPU seconds per process, no core file, and bounded
96 KiB stdout / 64 KiB stderr. It checks the supplied adapter hash before and after
replay and refuses to replace prior observations. No adapter path or result is
part of the pre-execution oracle.

Primary sources consulted on 2026-09-29:

- [For-in/of grammar, head and body algorithms](https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-for-in-and-for-of-statements)
- [GetIterator and IteratorClose](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-operations-on-iterator-objects)
- [Array iterator objects](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-array-iterator-objects)
- [String iteration](https://tc39.es/ecma262/multipage/text-processing.html#sec-string.prototype-%symbol.iterator%)
- [Common iterator self method](https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-iterator.prototype-%symbol.iterator%)

The coordinated read-only architecture plan is `/tmp/eris-for-of-plan.md`.
