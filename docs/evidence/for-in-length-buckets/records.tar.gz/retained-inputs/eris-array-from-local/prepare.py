#!/usr/bin/env python3
"""Independent Array.from expectations; never imports or executes an engine."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
CASES=[]
COMPLETE={'status':'complete','phase':'runtime','error_identity':'','error_type':''}
RESOURCE={'status':'resource','phase':'runtime'}
GUARD=r'''assert.sameValue(typeof Array.from,'function','Array.from availability');
var $afLike=Array.from({0:3,length:1});assert.sameValue($afLike.length,1);assert.sameValue($afLike[0],3);
var $afSource={},$afNext=0;$afSource[Symbol.iterator]=function(){return {next:function(){return $afNext++===0?{value:5,done:false}:{done:true};}};};
var $afResult=Array.from($afSource);assert.sameValue($afResult.length,1);assert.sameValue($afResult[0],5);assert.sameValue($afNext,2);
'''
HELPERS=r'''function sequence(values){var n=0,it={next:function(){return n<values.length?{value:values[n++],done:false}:{done:true};}},o={};o[Symbol.iterator]=function(){return it;};return {source:o,it:it};}
function sameList(a,b){assert.sameValue(a.length,b.length);for(var j=0;j<b.length;j++)assert.sameValue(a[j],b[j]);}
function traceText(a){var s='';for(var j=0;j<a.length;j++){if(j)s+=',';s+=a[j];}return s;}
'''
def case(name,source,area='protocol',prerequisites=(),expected=None):
 assert name not in {x['name'] for x in CASES},name
 CASES.append(dict(name=name,source=GUARD+HELPERS+source.strip()+'\n',area=area,prerequisites=list(prerequisites),expected=expected or COMPLETE,modes=['sloppy','strict']))
def j(x):return json.dumps(x,ensure_ascii=True,separators=(',',':'))
# Admission and ordering. A successful availability guard precedes every error assertion.
case('array-like-basic','sameList(Array.from({0:2,1:4,length:2}),[2,4]);','array-like')
case('custom-iterable-basic','sameList(Array.from(sequence([2,4]).source),[2,4]);')
case('iterable-wins-over-length','var s=sequence([7]),reads=0;Object.defineProperty(s.source,"length",{get:function(){reads++;throw "length";}});sameList(Array.from(s.source),[7]);assert.sameValue(reads,0);')
for label,expr in [('absent','undefined'),('null','null')]:
 case('iterator-'+label+'-array-like','var o={0:8,length:1};o[Symbol.iterator]='+expr+';sameList(Array.from(o),[8]);')
for label,expr in [('number','1'),('boolean','false'),('string','"x"'),('object','({})'),('symbol','Symbol("x")')]:
 case('noncallable-iterator-'+label,'var o={length:1},reads=0;o[Symbol.iterator]='+expr+';Object.defineProperty(o,"length",{get:function(){reads++;return 1;}});assert.throws(TypeError,function(){Array.from(o);});assert.sameValue(reads,0);')
for label,expr in [('null','null'),('number','1'),('boolean','true'),('string','"map"'),('object','({})'),('symbol','Symbol("map")')]:
 case('invalid-mapper-before-items-'+label,'var o={},reads=0;Object.defineProperty(o,Symbol.iterator,{get:function(){reads++;throw "iterator";}});Object.defineProperty(o,"length",{get:function(){reads++;throw "length";}});assert.throws(TypeError,function(){Array.from(o,'+expr+');});assert.sameValue(reads,0);','mapper')
for label,expr in [('null','null'),('undefined','undefined')]:
 case('nullish-items-'+label,'assert.throws(TypeError,function(){Array.from('+expr+');});')
case('undefined-mapper-does-not-call-thisarg','var o={toString:function(){throw "coerce";},valueOf:function(){throw "coerce";}};sameList(Array.from(sequence([9]).source,undefined,o),[9]);','mapper')
case('ignored-extra-arguments','var o={toString:function(){throw "coerce";},valueOf:function(){throw "coerce";}};sameList(Array.from({0:3,length:1},undefined,undefined,o,o),[3]);','mapper')
case('only-symbol-iterator','var o={0:3,length:1};Object.defineProperty(o,"iterator",{get:function(){throw "wrong";}});Object.defineProperty(o,"@@iterator",{get:function(){throw "wrong";}});sameList(Array.from(o),[3]);')
case('async-iterator-is-not-sync-fallback','assert.sameValue(typeof Symbol.asyncIterator,"symbol");var n=0,o={0:4,length:1};o[Symbol.asyncIterator]=function(){n++;throw "async";};sameList(Array.from(o),[4]);assert.sameValue(n,0);',prerequisites=['Symbol.asyncIterator'])
case('iterator-getter-original-receiver','var reads=0,p={},o=Object.create(p),s=sequence([6]);Object.defineProperty(p,Symbol.iterator,{get:function(){assert.sameValue(this,o);reads++;return s.source[Symbol.iterator];}});sameList(Array.from(o),[6]);assert.sameValue(reads,1);')
case('primitive-iterator-getter-and-call-unboxed','var seen=0;Object.defineProperty(Number.prototype,Symbol.iterator,{get:function(){"use strict";assert.sameValue(this,7);seen++;return function(){"use strict";assert.sameValue(this,7);seen++;return {next:function(){return {done:true};}};};}});sameList(Array.from(7),[]);assert.sameValue(seen,2);')
case('iterable-order-construction-before-method-call','var t=[],o={},it={next:function(){t.push("next");return {done:true};}};Object.defineProperty(o,Symbol.iterator,{get:function(){t.push("get-iterator");return function(){assert.sameValue(this,o);assert.sameValue(arguments.length,0);t.push("call-iterator");return it;};}});function C(){t.push("construct"+arguments.length);assert.sameValue(new.target,C);}var a=Array.from.call(C,o);assert.sameValue(traceText(t),"get-iterator,construct0,call-iterator,next");assert.sameValue(a.length,0);','construction')
case('array-like-order-length-before-construction','var t=[],o={get length(){t.push("length");return {valueOf:function(){t.push("convert");return 1;}};},get 0(){t.push("index");return 8;}};Object.defineProperty(o,Symbol.iterator,{get:function(){t.push("iterator");return null;}});function C(n){t.push("construct"+n);assert.sameValue(arguments.length,1);}var a=Array.from.call(C,o,function(v,i){t.push("map"+i);return v;});sameList(a,[8]);assert.sameValue(traceText(t),"iterator,length,convert,construct1,index,map0");','construction')
case('cached-iterator-method-survives-constructor-mutation','var s=sequence([6]),calls=0;function C(){s.source[Symbol.iterator]=function(){throw "late iterator";};calls++;}sameList(Array.from.call(C,s.source),[6]);assert.sameValue(calls,1);','construction')
case('constructor-mutation-before-iterator-start','var a=[2];function C(){a.push(4);}sameList(Array.from.call(C,a),[2,4]);','construction',['array-iterator'])
# Acquisition and IteratorStepValue failures do not close.
case('iterator-getter-throw-skips-construction','var token={},got,o={},n=0;Object.defineProperty(o,Symbol.iterator,{get:function(){throw token;}});function C(){n++;}try{Array.from.call(C,o);}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,0);')
case('iterable-constructor-throw-skips-acquisition','var token={},got,n=0,s=sequence([1]);s.source[Symbol.iterator]=function(){n++;return s.it;};function C(){throw token;}try{Array.from.call(C,s.source);}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,0);','construction')
case('array-like-constructor-throw-skips-index','var token={},got,o={length:1,get 0(){throw "index";}};function C(){throw token;}try{Array.from.call(C,o);}catch(e){got=e;}assert.sameValue(got,token);','construction')
case('iterator-call-throw-identity','var token={},got,o={};o[Symbol.iterator]=function(){throw token;};try{Array.from(o);}catch(e){got=e;}assert.sameValue(got,token);')
for label,expr in [('null','null'),('undefined','undefined'),('number','3'),('boolean','false'),('string','"x"'),('symbol','Symbol("x")')]:
 case('nonobject-iterator-'+label,'var o={};o[Symbol.iterator]=function(){return '+expr+';};assert.throws(TypeError,function(){Array.from(o);});')
case('function-is-object-iterator-and-step','var it=function(){},r=function(){};r.value=7;r.done=false;var n=0;it.next=function(){return n++?{done:true}:r;};var o={};o[Symbol.iterator]=function(){return it;};sameList(Array.from(o),[7]);')
case('cached-next-getter-and-call-receiver','var n=0,reads=0,s=sequence([]);Object.defineProperty(s.it,"next",{configurable:true,get:function(){reads++;return function(){assert.sameValue(this,s.it);assert.sameValue(arguments.length,0);Object.defineProperty(s.it,"next",{value:function(){throw "late next";},configurable:true});return n++<2?{value:n}:{done:true};};}});sameList(Array.from(s.source),[1,2]);assert.sameValue(reads,1);assert.sameValue(n,3);')
for stage in ['next-get','next-call','done-get','value-get']:
 setup={'next-get':'Object.defineProperty(s.it,"next",{get:function(){throw token;}});','next-call':'s.it.next=function(){throw token;};','done-get':'s.it.next=function(){return {get done(){throw token;}};};','value-get':'s.it.next=function(){return {done:false,get value(){throw token;}};};'}[stage]
 case('no-close-'+stage,'var token={},got,n=0,s=sequence([]);Object.defineProperty(s.it,"return",{get:function(){n++;return function(){return {};};}});'+setup+'try{Array.from(s.source);}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,0);','close')
for label,expr in [('undefined','undefined'),('null','null'),('number','1'),('object','({})')]:
 case('no-close-noncallable-next-'+label,'var n=0,s=sequence([]);s.it.next='+expr+';s.it.return=function(){n++;return {};};assert.throws(TypeError,function(){Array.from(s.source);});assert.sameValue(n,0);','close')
for label,expr in [('undefined','undefined'),('null','null'),('number','3'),('string','"x"'),('boolean','false'),('symbol','Symbol("x")')]:
 case('no-close-nonobject-step-'+label,'var n=0,s=sequence([]);s.it.next=function(){return '+expr+';};s.it.return=function(){n++;return {};};assert.throws(TypeError,function(){Array.from(s.source);});assert.sameValue(n,0);','close')
case('done-before-value-and-no-coercion','var s=sequence([]),done={valueOf:function(){throw "coerce";},toString:function(){throw "coerce";}};s.it.next=function(){return {done:done,get value(){throw "value";}};};sameList(Array.from(s.source),[]);')
case('missing-done-is-false-missing-value-is-undefined','var s=sequence([]),n=0;s.it.next=function(){return n++?{done:true}:{};};var a=Array.from(s.source);sameList(a,[undefined]);assert.sameValue(Object.prototype.hasOwnProperty.call(a,"0"),true);')
case('normal-exhaustion-never-gets-return','var s=sequence([1]);Object.defineProperty(s.it,"return",{get:function(){throw "return";}});sameList(Array.from(s.source),[1]);','close')
# Mapper receiver/arguments, observable sequencing and live effects.
for branch,src in [('iterable','sequence([3,5]).source'),('array-like','({0:3,1:5,length:2})')]:
 case('mapper-value-index-two-arguments-'+branch,'var ctx={},calls=0;var a=Array.from('+src+',function(v,k){"use strict";assert.sameValue(this,ctx);assert.sameValue(arguments.length,2);assert.sameValue(k,calls++);return v+k;},ctx);sameList(a,[3,6]);assert.sameValue(calls,2);','mapper')
 case('mapper-strict-undefined-this-'+branch,'var a=Array.from('+src+',function(v){"use strict";assert.sameValue(this,undefined);return v;});sameList(a,[3,5]);','mapper')
 case('mapper-strict-null-this-'+branch,'sameList(Array.from('+src+',function(v){"use strict";assert.sameValue(this,null);return v;},null),[3,5]);','mapper')
 case('mapper-sloppy-global-this-'+branch,'var f=Function("v","assert.sameValue(this,globalThis);return v;");sameList(Array.from('+src+',f,null),[3,5]);','mapper',['Function'])
 case('mapper-sloppy-boxed-this-'+branch,'var f=Function("v",'+j('assert.sameValue(typeof this,"object");assert.sameValue(this.valueOf(),7);return v;')+');sameList(Array.from('+src+',f,7),[3,5]);','mapper',['Function'])
 case('mapper-bound-this-'+branch,'var ctx={};function f(v,k){assert.sameValue(this,ctx);return v+k;}sameList(Array.from('+src+',f.bind(ctx),{}),[3,6]);','mapper')
 case('mapper-arrow-lexical-this-'+branch,'var ctx={};function f(){return Array.from('+src+',v=>{assert.sameValue(this,ctx);return v;},{});}sameList(f.call(ctx),[3,5]);','mapper')
case('mapper-native-callable','sameList(Array.from({0:"2",1:"3",length:2},Number),[2,3]);','mapper')
case('mapper-value-captured-before-mutation','var item={},other={},r={value:item,done:false},s=sequence([]),n=0;s.it.next=function(){return n++?{done:true}:r;};var a=Array.from(s.source,function(v){r.value=other;assert.sameValue(v,item);return v;});assert.sameValue(a[0],item);','mapper')
case('mapper-returns-undefined-and-negative-zero','var a=Array.from(sequence([1,2]).source,function(v){return v===1?undefined:-0;});assert.sameValue(a[0],undefined);assert.sameValue(a[1],-0);','mapper')
case('mapper-output-defined-before-next-step','var out={},n=0,s=sequence([]);function C(){return out;}s.it.next=function(){if(n===1)assert.sameValue(out[0],8);return n++?{done:true}:{value:4};};assert.sameValue(Array.from.call(C,s.source,function(v){return v*2;}),out);assert.sameValue(out[0],8);','mapper')
case('mapper-reentrant-array-from','var calls=0;var a=Array.from(sequence([2,3]).source,function(v){calls++;return Array.from({0:v+1,length:1})[0];});sameList(a,[3,4]);assert.sameValue(calls,2);','mapper')
case('mapper-native-iterator-growth-live','var a=[2];sameList(Array.from(a,function(v){if(v===2)a.push(4);return v;}),[2,4]);','mapper',['array-iterator'])
case('mapper-native-iterator-shrink-live','var a=[2,4];sameList(Array.from(a,function(v){a.length=0;return v;}),[2]);','mapper',['array-iterator'])
case('mapper-next-replacement-does-not-replace-cache','var s=sequence([2,4]);sameList(Array.from(s.source,function(v){s.it.next=function(){throw "replacement";};return v;}),[2,4]);','mapper')
# Ordinary construction: exactly zero or one argument, original newTarget, and returned objects.
for branch,src,nargs,arg in [('iterable','sequence([2,4]).source',0,'undefined'),('array-like','({0:2,1:4,length:2})',1,'2')]:
 case('constructor-args-newtarget-'+branch,'var seen=0;function C(n){seen++;assert.sameValue(arguments.length,'+str(nargs)+');assert.sameValue(n,'+arg+');assert.sameValue(new.target,C);}var a=Array.from.call(C,'+src+');assert.sameValue(seen,1);assert.sameValue(Object.getPrototypeOf(a),C.prototype);sameList(a,[2,4]);','construction')
 case('constructor-return-existing-object-'+branch,'var out={keep:9};function C(){return out;}var a=Array.from.call(C,'+src+');assert.sameValue(a,out);assert.sameValue(a.keep,9);sameList(a,[2,4]);','construction')
 case('constructor-return-primitive-ignored-'+branch,'function C(){this.keep=8;return 3;}var a=Array.from.call(C,'+src+');assert.sameValue(a.keep,8);assert.sameValue(Object.getPrototypeOf(a),C.prototype);sameList(a,[2,4]);','construction')
 case('bound-constructor-'+branch,'var seen=0;function C(prefix,n){assert.sameValue(prefix,"p");assert.sameValue(arguments.length,'+str(nargs+1)+');assert.sameValue(n,'+arg+');assert.sameValue(new.target,C);seen++;}var bound=C.bind({ignored:true},"p");var a=Array.from.call(bound,'+src+');assert.sameValue(seen,1);assert.sameValue(Object.getPrototypeOf(a),C.prototype);sameList(a,[2,4]);','construction')
 case('native-Object-constructor-'+branch,'var a=Array.from.call(Object,'+src+');assert.sameValue(Array.isArray(a),false);sameList(a,[2,4]);','construction')
for label,ctor in [('null','null'),('undefined','undefined'),('object','({})'),('number','4'),('arrow','(()=>{throw "called";})'),('native-nonconstructor','Math.abs')]:
 case('nonconstructor-receiver-intrinsic-fallback-'+label,'var a=Array.from.call('+ctor+',sequence([7]).source);assert.sameValue(Array.isArray(a),true);assert.sameValue(Object.getPrototypeOf(a),Array.prototype);sameList(a,[7]);','construction')
case('source-constructor-species-not-observed','assert.sameValue(typeof Symbol.species,"symbol");var a=[3];Object.defineProperty(a,"constructor",{get:function(){throw "constructor";}});Object.defineProperty(a,Symbol.species,{get:function(){throw "species";}});sameList(Array.from(a),[3]);','construction')
case('receiver-species-not-observed','assert.sameValue(typeof Symbol.species,"symbol");function C(){}Object.defineProperty(C,Symbol.species,{get:function(){throw "species";}});sameList(Array.from.call(C,sequence([2]).source),[2]);','construction')
case('saved-from-and-intrinsic-array-survive-global-replacement','var from=Array.from,proto=Array.prototype;Array=function(){throw "global";};var a=from.call(null,{0:5,length:1});assert.sameValue(Object.getPrototypeOf(a),proto);sameList(a,[5]);','construction')
case('constructor-mutates-arraylike-after-length-capture','var o={0:2,1:4,length:2};function C(n){assert.sameValue(n,2);o.length=0;o[1]=9;}sameList(Array.from.call(C,o),[2,9]);','construction')
case('constructor-output-can-be-source','var o={0:1,1:2,length:2};function C(){return o;}var a=Array.from.call(C,o,function(v,k){if(k===0)o[1]=9;return v*2;});assert.sameValue(a,o);sameList(a,[2,18]);','construction')
case('constructor-returns-mapped-arguments','var captured;var f=Function("a","b","captured=arguments;function C(){return captured;}var r=Array.from.call(C,{0:7,1:8,length:2});assert.sameValue(a,7);assert.sameValue(b,8);return r;");var r=f(1,2);sameList(r,[7,8]);','construction',['Function','mapped-arguments'])
# Array-like length is captured once; every index is read, including holes.
for label,length,want in [('missing','undefined',0),('zero','0',0),('negative-zero','-0',0),('negative','-2',0),('nan','NaN',0),('negative-infinity','-Infinity',0),('fraction','2.9',2),('string','"2"',2),('null','null',0),('boolean','true',1)]:
 case('to-length-'+label,'var a=Array.from({0:3,1:4,length:'+length+'});assert.sameValue(a.length,'+str(want)+');if(a.length)assert.sameValue(a[0],3);','array-like')
case('to-length-number-hint-once','var log=[],o={0:7,get length(){log.push("length");return {valueOf:function(){log.push("valueOf");return {};},toString:function(){log.push("toString");return "1";}};}};sameList(Array.from(o),[7]);assert.sameValue(traceText(log),"length,valueOf,toString");','array-like')
case('length-get-throw-before-constructor','var token={},got,n=0,o={get length(){throw token;}};function C(){n++;}try{Array.from.call(C,o);}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,0);','array-like')
case('symbol-length-rejected-before-constructor','var n=0;function C(){n++;}assert.throws(TypeError,function(){Array.from.call(C,{length:Symbol("n")});});assert.sameValue(n,0);','array-like')
case('arraylike-length-once-indices-live','var reads=0,o={0:2,1:4,get length(){reads++;return 2;}};var a=Array.from(o,function(v,k){if(k===0){o[1]=9;Object.defineProperty(o,"length",{value:0});}return v;});sameList(a,[2,9]);assert.sameValue(reads,1);','array-like')
case('arraylike-growth-does-not-extend','var o={0:1,length:1};sameList(Array.from(o,function(v){o[1]=8;o.length=2;return v;}),[1]);','array-like')
case('arraylike-deletion-becomes-undefined-own-data','var o={0:1,1:2,length:2};var a=Array.from(o,function(v,k){if(k===0)delete o[1];return v;});sameList(a,[1,undefined]);assert.sameValue(Object.prototype.hasOwnProperty.call(a,"1"),true);','array-like')
case('holes-inherited-getter-original-receiver','var p={},o=Object.create(p),n=0;o.length=2;Object.defineProperty(p,"1",{get:function(){assert.sameValue(this,o);n++;return 8;}});var a=Array.from(o);sameList(a,[undefined,8]);assert.sameValue(n,1);verifyProperty(a,"0",{value:undefined,writable:true,enumerable:true,configurable:true},{restore:true});','array-like')
case('arraylike-index-getter-mutates-next','var o={length:2,get 0(){o[1]=9;return 2;}};sameList(Array.from(o),[2,9]);','array-like')
case('arraylike-mapper-abrupt-keeps-prefix','var out={},token={},got,o={0:1,1:2,length:2};function C(){return out;}try{Array.from.call(C,o,function(v,k){if(k===1)throw token;return v*3;});}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(out[0],3);assert.sameValue(Object.prototype.hasOwnProperty.call(out,"1"),false);assert.sameValue(Object.prototype.hasOwnProperty.call(out,"length"),false);','array-like')
# Own data definitions bypass inherited indexed setters, but final length is a strict Set.
for branch,src in [('iterable','sequence([7]).source'),('array-like','({0:7,length:1})')]:
 case('output-own-data-bypasses-inherited-setter-'+branch,'var n=0,p={};Object.defineProperty(p,"0",{set:function(){n++;throw "setter";}});function C(){}C.prototype=p;var a=Array.from.call(C,'+src+');assert.sameValue(n,0);verifyProperty(a,"0",{value:7,writable:true,enumerable:true,configurable:true},{restore:true});','definitions')
 case('output-shadow-inherited-nonwritable-'+branch,'var p={};Object.defineProperty(p,"0",{value:1});function C(){}C.prototype=p;var a=Array.from.call(C,'+src+');verifyProperty(a,"0",{value:7,writable:true,enumerable:true,configurable:true},{restore:true});','definitions')
 case('output-replaces-configurable-accessor-'+branch,'var out={};Object.defineProperty(out,"0",{get:function(){throw "getter";},set:function(){throw "setter";},configurable:true});function C(){return out;}assert.sameValue(Array.from.call(C,'+src+'),out);verifyProperty(out,"0",{value:7,writable:true,enumerable:true,configurable:true},{restore:true});','definitions')
 case('output-length-inherited-setter-'+branch,'var seen=0,p={};Object.defineProperty(p,"length",{set:function(v){seen++;assert.sameValue(v,1);assert.sameValue(this[0],7);}});function C(){}C.prototype=p;var a=Array.from.call(C,'+src+');assert.sameValue(seen,1);assert.sameValue(Object.prototype.hasOwnProperty.call(a,"length"),false);','definitions')
 case('output-length-nonwritable-same-value-throws-'+branch,'var out={};Object.defineProperty(out,"length",{value:1});function C(){return out;}assert.throws(TypeError,function(){Array.from.call(C,'+src+');});assert.sameValue(out[0],7);','definitions')
 case('output-length-getter-only-throws-'+branch,'var out={get length(){return 1;}};function C(){return out;}assert.throws(TypeError,function(){Array.from.call(C,'+src+');});assert.sameValue(out[0],7);','definitions')
 case('nonextensible-output-cannot-add-index-'+branch,'var out=Object.preventExtensions({});function C(){return out;}assert.throws(TypeError,function(){Array.from.call(C,'+src+');});assert.sameValue(Object.prototype.hasOwnProperty.call(out,"0"),false);','definitions')
 case('nonconfigurable-output-index-cannot-redefine-'+branch,'var out={};Object.defineProperty(out,"0",{value:7,writable:true,enumerable:true,configurable:false});function C(){return out;}assert.throws(TypeError,function(){Array.from.call(C,'+src+');});assert.sameValue(out[0],7);','definitions')
case('output-definition-sees-mapper-frozen-property','var out={},s=sequence([1]),n=0;function C(){return out;}s.it.return=function(){n++;return {};};assert.throws(TypeError,function(){Array.from.call(C,s.source,function(v){Object.defineProperty(out,"0",{value:v});return v;});});assert.sameValue(n,1);','definitions')
case('boxed-string-output-index-rejects','var out=Object("x"),s=sequence(["x"]),n=0;function C(){return out;}s.it.return=function(){n++;return {};};assert.throws(TypeError,function(){Array.from.call(C,s.source);});assert.sameValue(n,1);','definitions')
case('iterable-final-length-throw-no-close','var token={},got,n=0,out={},s=sequence([1]);Object.defineProperty(out,"length",{set:function(v){assert.sameValue(v,1);throw token;}});s.it.return=function(){n++;return {};};function C(){return out;}try{Array.from.call(C,s.source);}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,0);assert.sameValue(out[0],1);','close')
case('empty-iterable-final-length-throw-no-close','var n=0,out={},s=sequence([]);Object.defineProperty(out,"length",{value:0,writable:false});s.it.return=function(){n++;return {};};function C(){return out;}assert.throws(TypeError,function(){Array.from.call(C,s.source);});assert.sameValue(n,0);','close')
# Required close boundaries, with pending author error precedence over close failures.
CLOSES=[('missing','',0),('undefined','s.it.return=undefined;',0),('null','s.it.return=null;',0),('noncallable','s.it.return=1;',0),('getter-throw','Object.defineProperty(s.it,"return",{get:function(){closes++;throw closeToken;}});',1),('call-throw','s.it.return=function(){closes++;throw closeToken;};',1),('primitive','s.it.return=function(){closes++;return 2;};',1),('object','s.it.return=function(){closes++;assert.sameValue(this,s.it);assert.sameValue(arguments.length,0);return {};};',1)]
for origin in ['mapper','definition']:
 for label,setup,count in CLOSES:
  prefix='var token={},closeToken={},got,closes=0,s=sequence([7]),out={};function C(){return out;}'
  action='try{Array.from.call(C,s.source,function(){throw token;});}catch(e){got=e;}assert.sameValue(got,token);' if origin=='mapper' else 'Object.preventExtensions(out);assert.throws(TypeError,function(){Array.from.call(C,s.source);});'
  case('close-'+origin+'-'+label,prefix+setup+action+'assert.sameValue(closes,'+str(count)+');','close')
case('mapper-mutates-live-return-before-throw','var token={},got,n=0,s=sequence([1]);s.it.return=function(){throw "old";};try{Array.from(s.source,function(){s.it.return=function(){n++;return {};};throw token;});}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,1);','close')
case('close-preserves-output-prefix-and-stops-next','var token={},got,n=0,closes=0,out={},s=sequence([]);function C(){return out;}s.it.next=function(){return {value:++n};};s.it.return=function(){closes++;assert.sameValue(out[0],2);assert.sameValue(Object.prototype.hasOwnProperty.call(out,"1"),false);return {};};try{Array.from.call(C,s.source,function(v,k){if(k===1)throw token;return v*2;});}catch(e){got=e;}assert.sameValue(got,token);assert.sameValue(n,2);assert.sameValue(closes,1);','close')
# Real native sources, strings, sparse arrays and arguments.
case('sparse-array-becomes-dense-undefined','var a=Array.from(new Array(2));sameList(a,[undefined,undefined]);assert.sameValue(Object.prototype.hasOwnProperty.call(a,"0"),true);assert.sameValue(Object.prototype.hasOwnProperty.call(a,"1"),true);','native')
case('array-custom-iterator-override','var a=[1,2],s=sequence([9]);a[Symbol.iterator]=s.source[Symbol.iterator];sameList(Array.from(a),[9]);','native')
case('array-null-iterator-uses-arraylike','var a=[1,2];a[Symbol.iterator]=null;sameList(Array.from(a),[1,2]);','native')
for label,src,want in [('empty','""',[]),('ascii','"ab"',['a','b']),('supplementary','"A\\uD83D\\uDE00B"',['A','\U0001f600','B']),('high','"\\uD800x"',['\ud800','x']),('low','"x\\uDC00"',['x','\udc00']),('high-high-low','"\\uD800\\uD801\\uDC00"',['\ud800','\U00010400']),('combining','"e\\u0301\\u00e9"',['e','\u0301','\u00e9'])]:
 case('string-'+label,'sameList(Array.from('+src+'),'+j(want)+');','native',['string-iterator'])
case('disabled-string-iterator-uses-codeunits','String.prototype[Symbol.iterator]=null;var a=Array.from("A\\uD83D\\uDE00B");sameList(a,["A","\\uD83D","\\uDE00","B"]);','native',['string-iterator'])
case('mapped-arguments-mutation-live','var f=Function("a","b","return Array.from(arguments,function(v,k){if(k===0)b=9;return v;});");sameList(f(1,2),[1,9]);','native',['Function','mapped-arguments'])
case('strict-arguments-are-unmapped','function f(a,b){"use strict";return Array.from(arguments,function(v,k){if(k===0)b=9;return v;});}sameList(f(1,2),[1,2]);','native')
case('arguments-disabled-iterator-arraylike','function f(){arguments[Symbol.iterator]=undefined;return Array.from(arguments);}sameList(f(2,3),[2,3]);','native')
for label,expr in [('number','7'),('boolean','true'),('symbol','Symbol("x")')]:
 case('primitive-arraylike-empty-'+label,'sameList(Array.from('+expr+'),[]);','array-like')
# Native array length is u32; custom construction can observe the full ToLength.
for label,length,want in [('u32plus','4294967296','4294967296'),('safe-max','9007199254740991','9007199254740991'),('above-safe','9007199254740992','9007199254740991'),('infinity','Infinity','9007199254740991')]:
 case('huge-length-custom-ctor-first-'+label,'var token={},got,o={get 0(){throw "index";},length:'+length+'};function C(n){assert.sameValue(n,'+want+');throw token;}try{Array.from.call(C,o);}catch(e){got=e;}assert.sameValue(got,token);','bounds')
 case('huge-length-native-array-range-'+label,'var reads=0,o={length:'+length+',get 0(){reads++;throw "index";}};assert.throws(RangeError,function(){Array.from(o);});assert.sameValue(reads,0);','bounds')
case('huge-custom-range-first-getter-before-resource','var token={},got;function C(){return {};}try{Array.from.call(C,{length:Infinity,get 0(){throw token;}});}catch(e){got=e;}assert.sameValue(got,token);','bounds')
case('huge-custom-range-first-mapper-before-resource','var token={},got;function C(){return {};}try{Array.from.call(C,{0:7,length:Infinity},function(v,k){assert.sameValue(v,7);assert.sameValue(k,0);throw token;});}catch(e){got=e;}assert.sameValue(got,token);','bounds')
# Metadata and aliases; propertyHelper restoration prevents the verifier becoming a mutation.
case('metadata','var from=Array.from;verifyProperty(Array,"from",{value:from,writable:true,enumerable:false,configurable:true},{restore:true});verifyProperty(from,"name",{value:"from",writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(from,"length",{value:1,writable:false,enumerable:false,configurable:true},{restore:true});assert.sameValue(Object.prototype.hasOwnProperty.call(from,"prototype"),false);assert.throws(TypeError,function(){new from({length:0});});','metadata')
case('saved-alias-call-apply-bind','var from=Array.from;Array.from=3;sameList(from.call(null,{0:1,length:1}),[1]);sameList(from.apply(null,[{0:2,length:1}]),[2]);sameList(from.bind(null)({0:3,length:1}),[3]);','metadata')
case('reflect-apply','sameList(Reflect.apply(Array.from,null,[{0:5,length:1}]),[5]);','metadata',['Reflect.apply'])
# Standard successes with unavailable prerequisites remain in the ordinary denominator.
case('prerequisite-generator','function* g(){yield 2;yield 4;}sameList(Array.from(g()),[2,4]);','prerequisite',['generators'])
case('prerequisite-class-subclass','class C extends Array{}var a=C.from([2,4]);assert.sameValue(a instanceof C,true);sameList(a,[2,4]);','prerequisite',['class'])
case('prerequisite-Set','sameList(Array.from(new Set([2,2,4])),[2,4]);','prerequisite',['Set'])
case('prerequisite-Map','var a=Array.from(new Map([["a",2],["b",4]]));sameList(a[0],["a",2]);sameList(a[1],["b",4]);','prerequisite',['Map'])
case('prerequisite-TypedArray','sameList(Array.from(new Uint8Array([2,4])),[2,4]);','prerequisite',['TypedArray'])
case('prerequisite-Proxy-definition-order','var log=[],target={},proxy=new Proxy(target,{defineProperty:function(o,k,d){log.push(k+":"+d.value);return Reflect.defineProperty(o,k,d);}});function C(){return proxy;}sameList(Array.from.call(C,sequence([7]).source),[7]);assert.sameValue(log[0],"0:7");assert.sameValue(log[1],"length:1");','prerequisite',['Proxy'])
case('prerequisite-BigInt-length-rejected','assert.throws(TypeError,function(){Array.from({length:BigInt(1)});});','prerequisite',['BigInt'])
# Terminal engine-policy expectations are explicit, not ECMAScript exception claims.
for name,source in [
 ('infinite-iterator','var s=sequence([]);s.it.next=function(){return {value:1,done:false};};Array.from(s.source);'),
 ('infinite-mapper','Array.from(sequence([1]).source,function(){while(true){}});'),
 ('infinite-close','var s=sequence([1]);s.it.return=function(){while(true){}};Array.from(s.source,function(){throw 1;});'),
 ('recursive-mapper','function f(){return Array.from(sequence([1]).source,f);}f();'),
 ('retained-results','var kept=[];while(true)kept.push(Array.from({0:1,length:1}));'),
 ('huge-custom-arraylike','function C(){return {};}Array.from.call(C,{length:Infinity});')]:
 case('budget-'+name,source,'budget',expected=RESOURCE)
# New feature controls: exact common setup plus one final true/wrong assertion.
PAIRS=[]
def pair(name,setup,expression,correct,wrong):PAIRS.append(dict(name=name,setup=GUARD+HELPERS+setup,expression=expression,correct=correct,wrong=wrong))
pair('smoke','var result=Array.from({0:2,length:1});','result[0]','2','3')
pair('custom-protocol','var result=Array.from(sequence([3,5]).source);','result.length+result[1]','7','8')
pair('iterator-precedence','var s=sequence([9]);Object.defineProperty(s.source,"length",{get:function(){throw "length";}});var result=Array.from(s.source);','result[0]','9','8')
pair('null-fallback','var o={0:7,length:1};o[Symbol.iterator]=null;var result=Array.from(o);','result[0]','7','8')
pair('mapper-validation','var reads=0,o={};Object.defineProperty(o,Symbol.iterator,{get:function(){reads++;throw "read";}});assert.throws(TypeError,function(){Array.from(o,null);});','reads','0','1')
pair('mapper-arguments','var ctx={},n=0;var result=Array.from(sequence([4]).source,function(v,k){"use strict";assert.sameValue(this,ctx);assert.sameValue(arguments.length,2);n++;return v+k;},ctx);','result[0]+n','5','6')
pair('constructor-iterable','var count;function C(){count=arguments.length;assert.sameValue(new.target,C);}var result=Array.from.call(C,sequence([1]).source);','count','0','1')
pair('constructor-arraylike','var count;function C(n){count=arguments.length;assert.sameValue(n,1);}var result=Array.from.call(C,{0:1,length:1});','count','1','0')
pair('create-data','var calls=0,p={};Object.defineProperty(p,"0",{set:function(){calls++;}});function C(){}C.prototype=p;var result=Array.from.call(C,sequence([8]).source);assert.sameValue(result[0],8);','calls','0','1')
pair('mapper-close','var token={},caught,n=0,s=sequence([1]);s.it.return=function(){n++;throw 9;};try{Array.from(s.source,function(){throw token;});}catch(e){caught=e;}assert.sameValue(caught,token);','n','1','0')
pair('step-no-close','var token={},caught,n=0,s=sequence([]);s.it.next=function(){throw token;};s.it.return=function(){n++;return {};};try{Array.from(s.source);}catch(e){caught=e;}assert.sameValue(caught,token);','n','0','1')
pair('final-length-no-close','var out={},n=0,s=sequence([]);Object.defineProperty(out,"length",{value:0,writable:false});function C(){return out;}s.it.return=function(){n++;return {};};assert.throws(TypeError,function(){Array.from.call(C,s.source);});','n','0','1')
pair('live-indices','var o={0:1,1:2,length:2};var result=Array.from(o,function(v,k){if(k===0)o[1]=9;return v;});','result[1]','9','2')
pair('unicode','var result=Array.from("A\\uD83D\\uDE00B");','result.length','3','4')
pair('property-metadata','verifyProperty(Array.from,"name",{value:"from",writable:false,enumerable:false,configurable:true},{restore:true});verifyProperty(Array.from,"length",{value:1,writable:false,enumerable:false,configurable:true},{restore:true});assert.throws(TypeError,function(){new Array.from({length:0});});','Array.from.length','1','2')
pair('native-range','var reads=0;assert.throws(RangeError,function(){Array.from({length:4294967296,get 0(){reads++;}});});','reads','0','1')
if __name__=='__main__':
 fixture='// Independent Array.from oracle; expectations frozen before any adapter execution.\n\n'+''.join('// CASE: '+c['name']+'\n'+c['source'] for c in CASES)
 freeze=dict(fixture_sha256=hashlib.sha256(fixture.encode()).hexdigest(),generator_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),source_cases=len(CASES),mode_cases=sum(len(c['modes']) for c in CASES),cases=[{k:v for k,v in c.items() if k!='source'} for c in CASES],preflight_pairs=len(PAIRS),preparation_never_executed_an_engine=True)
 raw=(json.dumps(PAIRS,indent=2)+'\n').encode();freeze['preflights_sha256']=hashlib.sha256(raw).hexdigest()
 for name,body in [('array-from.js',fixture.encode()),('preflights.json',raw),('freeze.json',(json.dumps(freeze,indent=2)+'\n').encode())]:
  with (HERE/name).open('xb') as f:f.write(body)
 print(len(CASES),'sources;',freeze['mode_cases'],'modes;',len(PAIRS)*4,'feature controls')
