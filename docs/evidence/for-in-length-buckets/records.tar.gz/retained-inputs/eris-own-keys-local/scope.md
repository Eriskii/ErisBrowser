# Own-key accounting: actionable scope supplement

Read-only, 2026-09-29. The Array.from sources remain frozen. Prior design: `/tmp/eris-own-keys-work-design.json`, SHA-256 `c256ad6c8710fdab3785c20354b04652ebf4774f2eff9d629f8eb5a5d9043db6`. No repository edits, engine execution, Cargo, oracle creation or quota changes occurred.

## Concrete findings and exact seams

| Path | Confirmed operation | Minimal correction seam |
|---|---|---|
| `src/script.rs:4557–4614`, `own_keys` | Stable numeric sorting followed by `BTreeSet<JsString>` insertion compares complete UTF-16 names. Current work charge is count/log based, after dense formatting, hole checks and metadata scans have already occurred. | Replace only this snapshot implementation with precharged ranked entries, or retain it and precharge full-name comparisons before materialization. Preserve its return type and Window branch. |
| `src/script/machine/statements.rs:849–869`, `for_in_next` | `visited.contains` and `visited.insert` compare arbitrary full names against a growing tree. `1 + key.len()/8` has no visited-tree-depth factor. | Put a charged membership helper immediately before `contains`; put a separately charged insertion helper after the live own-descriptor existence check, immediately before `insert`. No eager prototype traversal. |
| `src/script.rs:8393–8417`, Object keys/values/names | The caller's `Vec<Value>` grows through `push`; its eventual `array(result)` charge occurs afterward. It has no dedicated fallible capacity reservation before those pushes. | After the key snapshot, precharge/reserve at most `keys.len()` Value slots before processing values. Do not pre-read descriptors/getters to calculate an exact result count. |
| `src/script.rs:4874–4903`, `define_properties` | Descriptor records have a pre-push `256 + key.byte_len()` allowance, but the growing Vec has no explicit capacity reservation. | Bind the key snapshot to a local; reserve a checked upper bound for `(PropertyKey, PropertyDescriptor)` records before filling it, preserving collection-before-definition and each live descriptor read. Audit the existing 256-byte allowance against actual record/capacity costs before adding a second charge. |

These are source-level ledger/timing facts. They are **not** a demonstrated process-memory escape, allocator failure, or timeout. For descriptor staging, the existing per-record allowance may already cover total capacity amortization; the confirmed issue is the missing explicit/fallible reservation seam, not a proved insufficient total byte allowance. Do not describe every temporary vector as an independently demonstrated heap-cap bypass.

`own_property_keys` and `own_symbol_keys` in `property_keys.rs:200–241` already charge and fallibly reserve their result vectors. Reflect.ownKeys then independently charges/reserves its Value output. Do not add blanket duplicate caller storage charges there.

## Recommended snapshot correction

The source audit still finds exactly one stored-order append site (`ScriptObject::insert_property`, line 1405), guarded by absence from the map, and one removal site (`remove`, line 1411), which removes matching map/order entries together. No alternate map insertion/removal or order mutation was found. Thus valid stored order contains each PropertyKey once; updating a descriptor keeps its ordinal, while deletion/reinsertion assigns a new ordinal.

Actual snapshot duplicates arise from dense or boxed-string virtual indices overlapping stored descriptors, and virtual `length` overlapping a compatible stored property. Canonical numeric spellings are uniquely determined by `json_array_index`; `01`, `-0` and `4294967295` remain distinct non-index strings. This supports a local `(rank, index, ordinal, JsString)` vector with integer-only in-place sorting, adjacent numeric deduplication, and fixed-six-unit suppression of a stored virtual `length`. Other retained strings need no full-name deduplication. This is a proved current-container optimization, not an assumption that arbitrary private Vec contents are unique.

Precharge metadata visits before scanning order; then precharge actual dense-hole checks, virtual decimal formatting, short index classification, sort/dedup/output movement and both vector capacities before materialization. Reserve fallibly with checked arithmetic. Charge newly formatted UTF-16 text and headers; retained JsString clones only copy Rc handles. A sparse Array's logical length must not cause gap allocation or work. An empty ordinary snapshot need not allocate. Keep all existing data/getter/prototype observations outside the snapshot.

If the runtime intends to support internally forged duplicate nonnumeric order records, retain the full-name set instead: charge `(sum candidate UTF-16 lengths + count) × bounded tree depth` plus enumeration, stable-sort scratch and set-node storage before it runs. That alternative preserves malformed-state tolerance but retains avoidable comparisons and can create new resource stops. Do not claim a numeric-only optimization handles malformed states that violate the audited invariant.

## For-in operation and storage bounds

Use helpers that perform the actual operations, not a standalone guessed charge later in the caller:

- `for_in_visited_contains(runtime, visited, key) -> Result<bool>` charges a conservative number of full UTF-16 comparisons based on **current** `visited.len()` before the lookup. A model such as `(key.len()+1) * 4 * ceil(log2(n+1))`, with fixed call overhead and saturating/checked arithmetic, follows existing bounded tree-lookup conventions. Empty trees need no text comparison allowance.
- After a current own descriptor exists, `for_in_visited_insert(...)` separately charges the corresponding insertion comparison work and node allocation allowance before insertion. Nonenumerable keys must still enter the visited set; deleted keys must not. The existing `32 + key.byte_len()` is not an explicit proof of node/split allocation coverage: derive a conservative bound for the supported standard-library representation or preserve a documented conservative cumulative allowance. Do not invent an exact allocator-node size without checking it.

No callback occurs between these two operations and the descriptor read, but the descriptor is deliberately checked after membership. Preserve that order. Current own names and prototype names can share arbitrary prefixes, so cross-prototype visited-name comparison cannot be replaced by numeric-only deduplication. No iterator-return call belongs to for-in cleanup, and terminal resource errors retain existing uncatchable cleanup behavior.

## Boundary that must not be hidden

There is another concrete comparison path after the snapshot: `Object.keys/values`, `define_properties` and `for_in_next` call `own_property`/`own_property_key`. Those pure helpers read the full-key property tree and, for mapped arguments, a retained binding-name tree. Their callers' one-key tick does not account for arbitrary name length times tree depth. The own_keys rewrite does not charge these operations, and snapshot charges cannot be assumed to cover later live reads after author mutations.

If the next checkpoint is described as fixing **all work on these public enumeration routes**, add a narrowly scoped, charged own-descriptor/flags wrapper at these exact call sites, covering current property/parameter-map tree sizes, mapped-name work when a value is actually fetched, and virtual-string snapshot scratch. Do not generalize or replace the entire property system. If that wrapper is deferred, retain this as a separate explicit open comparison gap and describe the implemented fix as snapshot + visited-set accounting only. `Object.values`' subsequent live Get/prototype walk and unrelated `json_keys` are likewise not automatically fixed by this design.

Keep Window's existing snapshot, own-symbol enumeration and integrity_keys as separate implementations. Any array-shrink follow-up must leave the two length conversions, refreshed old length, readonly/non-shrink fast paths and descending deletion effects in their current order. After shared snapshot accounting is complete, remove only Array.from's now-duplicated enumeration/sort/dedup allowances; keep its strict-Set and deletion-specific allowances unless their actual operations become charged centrally.

## Minimal private/public checks before replay

1. Independent literal order oracle for ordinary keys, delete/reinsert, canonical and noncanonical numeric strings, symbols, dense holes/overrides and compatible boxed-string index/length materialization. Do not compare only two implementation helpers.
2. Direct snapshot boundary-minus-one work/heap tests: no getter, mutation or key-buffer publication before failure. Same-shape long-prefix names should not incur full-name comparison work under numeric-only dedup; retain the earlier full-name resource observation as historical evidence of removed operations.
3. Isolated visited helpers: hold key length fixed and increase set depth; hold set depth fixed and increase UTF-16 common-prefix length. Include hit/miss, nonenumerable shadow, and insertion shortage before loop assignment/body. Malformed prototype cycles keep the existing guard.
4. Object.values/defineProperties caller capacity shortage before unstarted getters; after earlier getter effects, later errors retain those effects. Definitions still wait until descriptor collection completes. Any descriptor-wrapper test should separately cover long numeric-mapped names and boxed virtual strings.
5. Sparse max-u32 length depends on stored shape. Shrink snapshot failure follows conversion effects but precedes deletions; readonly/non-shrink cases skip enumeration. Partial failed deletion order stays unchanged.
6. Lazy for-in: body changes a later prototype before it is reached; hidden shadows suppress inherited names; deleted own names are skipped. Resource failure must not preempt earlier bodies by precharging an entire future chain.
7. Repeated snapshots share cumulative budgets. Replay the complete published Array.from and other existing local contracts, all 39 formal profiles, controls and baseline gates without policy/expectation changes. Report new resources or resource-phase changes, never increase limits to force old outcomes.

## Source bindings

```
9874ddb47e01dce2de06cea58d961f1d227a3a7eb910d2e3e7136449adb3110e  src/script.rs
a6387ed2d4bb4a06832f52b5ec27bf03036467bdec7644045078f4756a9b839c  src/script/machine/statements.rs
7bd4055f08eb2d05b798b16b02c0ddf6e03a5a3fce2c269633e2967f92c665a3  src/script/property_keys.rs
8ebcc4a711e1607417f45d906119e468b0e230b67bc5abe7ad5fd6e3c77678c2  src/script/array_from.rs
```

Current code matches the original design's source bindings. No source change is requested during Array.from publication; implementation scope remains a parent decision for the subsequent checkpoint.
