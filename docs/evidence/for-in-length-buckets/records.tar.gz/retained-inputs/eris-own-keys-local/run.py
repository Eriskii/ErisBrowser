#!/usr/bin/env python3
"""Own-key oracle preparation/replay. No engine runs without --execute-authorized."""
import argparse,collections,datetime,hashlib,json,os,resource,signal,subprocess,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE/'tools'))
import test262_conformance as runner
from run import launch_environment
COMPLETE=dict(status='complete',phase='runtime',error_identity='',error_type='')
WRONG=dict(status='exception',phase='runtime',error_identity='',error_type='Test262Error')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def path_for(name,draft):return HERE/(name.replace('.', '.draft.',1) if draft else name)
def assemble(draft=False):
 meta=json.loads(path_for('expectations.json',draft).read_bytes())
 assert meta['generator_sha256']==sha(HERE/'prepare.py')
 harness=[(n,(HERE/'harness'/n).read_bytes()) for n in ('assert.js','sta.js')]
 cases=[];seen=set();records={r['name']:r for r in meta['cases']}
 def add(name,source,mode,expected,extra,filename):
  c=dict(id=name+'#'+mode,file=filename,source=source,mode=mode,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=harness)
  c['case_sha256']=runner.case_fingerprint(c)
  identity=dict(id=c['id'],file=filename,mode=mode,source=source.decode(),source_sha256=hashlib.sha256(source).hexdigest(),case_sha256=c['case_sha256'],expected=expected,expectation_sha256=digest(expected),**extra)
  cases.append((c,identity))
 for block in path_for('own-keys.js',draft).read_bytes().split(b'// CASE: ')[1:]:
  raw_name,source=block.split(b'\n',1);name=raw_name.decode();assert name not in seen;seen.add(name);r=records[name]
  for mode in r['modes']:add(name,source,mode,r['expected'],dict(category='fixture',area=r['area'],oracle_kind=r['oracle_kind'],note=r['note']),'own-keys.js')
 assert seen==set(records) and len(cases)==meta['mode_cases']
 for pair in json.loads(path_for('preflights.json',draft).read_bytes()):
  for mode in ('sloppy','strict'):
   for positive in (True,False):
    name='preflight-'+pair['name']+('-positive' if positive else '-wrong')
    source=(pair['setup']+'\nassert.sameValue('+pair['expression']+','+pair['correct' if positive else 'wrong']+');\n').encode()
    add(name,source,mode,COMPLETE if positive else WRONG,dict(category='feature-control',positive=positive,partner='preflight-'+pair['name']+'-positive#'+mode),'preflight-controls')
 common=[('samevalue','assert.sameValue(NaN,NaN);assert.notSameValue(0,-0);','assert.sameValue(0,-0);'),('error-identity','assert.throws(TypeError,function(){throw new TypeError();});','assert.throws(TypeError,function(){throw new RangeError();});')]
 for name,good,bad in common:
  for mode in ('sloppy','strict'):
   for positive,source in ((True,good),(False,bad)):
    add('harness-'+name+('-positive' if positive else '-wrong'),source.encode(),mode,COMPLETE if positive else WRONG,dict(category='harness-control',positive=positive,partner='harness-'+name+'-positive#'+mode),'harness-controls')
 ids=[identity for _,identity in cases];assert len(set(r['id'] for r in ids))==len(ids)
 matrix=dict(format=1,fixture_sha256=sha(path_for('own-keys.js',draft)),expectations_sha256=sha(path_for('expectations.json',draft)),preflights_sha256=sha(path_for('preflights.json',draft)),generator_sha256=sha(HERE/'prepare.py'),runner_sha256=sha(__file__),license_sha256=sha(HERE/'TEST262-LICENSE'),tool_hashes={p.name:sha(p) for p in sorted((HERE/'tools').glob('*.py'))},harness=[dict(name=n,sha256=hashlib.sha256(b).hexdigest()) for n,b in harness],source_cases=len(records),fixture_modes=meta['mode_cases'],feature_controls=16,harness_controls=8,metadata_exclusions=False,resource_expectations=False,cases=ids)
 return cases,matrix

def verify():
 ledger=json.loads((HERE/'freeze.json').read_bytes())
 for f in ledger['files']:assert sha(HERE/f['path'])==f['sha256'],f['path']
 cases,matrix=assemble();assert matrix==json.loads((HERE/'matrix.json').read_bytes()),'matrix changed'
 return cases,matrix,ledger

def worker(binary,expected_hash,output):
 cases,matrix,_=verify();assert sha(binary)==expected_hash
 observed=[];started=time.monotonic()
 for case,identity in cases:
  r=runner.run_case(case,binary,3)
  r.update({k:v for k,v in identity.items() if k not in ('id','file','mode','case_sha256','source_sha256')})
  r['matches_expectation']=all(r.get('observation',{}).get(k)==v for k,v in identity['expected'].items())
  observed.append(r);print(r['id'],r['status'],r.get('observation',{}).get('message',''),flush=True)
 by_id={r['id']:r for r in observed};controls=[r for r in observed if r['category']!='fixture'];fixtures=[r for r in observed if r['category']=='fixture']
 for r in controls:r['verified']=r['matches_expectation'] and by_id[r['partner']]['matches_expectation']
 for r in fixtures:r['guarded_verified']=r['matches_expectation'] and by_id['preflight-smoke-positive#'+r['mode']]['matches_expectation']
 verify();assert sha(binary)==expected_hash
 report=dict(format=1,binary=str(binary),binary_sha256=expected_hash,matrix_sha256=sha(HERE/'matrix.json'),freeze_sha256=sha(HERE/'freeze.json'),runner_sha256=sha(__file__),counts=dict(collections.Counter(r['status'] for r in fixtures)),fixture_modes=len(fixtures),fixture_expectations_matched=sum(r['matches_expectation'] for r in fixtures),fixture_expectations_verified=sum(r['guarded_verified'] for r in fixtures),controls_verified=sum(r['verified'] for r in controls),control_count=len(controls),cases=fixtures,controls=controls,no_filtering=True,no_retries=True,elapsed_seconds=round(time.monotonic()-started,4),bounds=dict(case_wall_seconds=3,outer_wall_seconds=450,address_space_bytes=512*1024**2,cpu_seconds=60,per_output_file_bytes=32*1024**2,adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024))
 with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
 print('RESULT',report['counts'],'CONTROLS',report['controls_verified'],'/',len(controls),flush=True)

def limits():
 for kind,value in [(resource.RLIMIT_AS,512*1024**2),(resource.RLIMIT_CPU,60),(resource.RLIMIT_FSIZE,32*1024**2),(resource.RLIMIT_CORE,0)]:resource.setrlimit(kind,(value,value))
def kill_then_reap(p,owner):
 try:os.killpg(p.pid,signal.SIGKILL)
 except ProcessLookupError:pass
 owner['reap_started']=True
 return p.wait(timeout=5)
def supervise(binary,expected_hash,out):
 _,matrix,ledger=verify();assert sha(binary)==expected_hash
 assert not out.exists(),'output directory must be fresh'
 assert out!=HERE and HERE not in out.parents,'output must be outside frozen fixture directory'
 out.mkdir();env=launch_environment();env['PYTHONDONTWRITEBYTECODE']='1';report=out/'report.json'
 cmd=[sys.executable,str(HERE/'run.py'),'--execute-authorized','--worker','--binary',str(binary),'--sha256',expected_hash,'--output-directory',str(out)]
 record=dict(format=1,started_utc=utc(),command=cmd,binary_sha256=expected_hash,freeze_sha256=sha(HERE/'freeze.json'),matrix_sha256=sha(HERE/'matrix.json'),environment={k:env.get(k) for k in ('TZ','LANG','LC_ALL','LD_LIBRARY_PATH')},retries=False,normalization=False,baseline_written=False)
 with (out/'start.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 p=None;owner={'reap_started':False};reaped=False
 try:
  with (out/'stdout.log').open('xb') as stdout,(out/'stderr.log').open('xb') as stderr:
   p=subprocess.Popen(cmd,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,cwd=HERE,env=env,close_fds=True,start_new_session=True,preexec_fn=limits)
   record['pid']=p.pid;deadline=time.monotonic()+450
   while True:
    status=os.waitid(os.P_PID,p.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
    if status is not None:
     record['exit_observed_unreaped']=dict(pid=status.si_pid,code=status.si_code,status=status.si_status)
     record['returncode']=kill_then_reap(p,owner);reaped=True;break
    left=deadline-time.monotonic()
    if left<=0:raise subprocess.TimeoutExpired(cmd,450)
    time.sleep(min(.05,left))
  assert record['returncode']==0,'worker did not complete; raw logs retained'
  r=json.loads(report.read_bytes());assert len(r['cases'])==86 and len(r['controls'])==24
  assert r['binary_sha256']==expected_hash and r['matrix_sha256']==sha(HERE/'matrix.json')
  actual={x['id']:x for x in r['cases']+r['controls']}
  for identity in matrix['cases']:
   for key in ('file','mode','source','source_sha256','case_sha256','expected','expectation_sha256'):assert actual[identity['id']][key]==identity[key],(identity['id'],key)
  verify();assert sha(binary)==expected_hash
  record.update(all_inputs_unchanged=True,counts=r['counts'],controls_verified=r['controls_verified'],control_count=24)
 except BaseException as error:
  record['failure']=dict(type=type(error).__name__,message=str(error))
  if p is not None and not reaped:
   try:record['cleanup_returncode']=p.wait(timeout=5) if owner['reap_started'] else kill_then_reap(p,owner);reaped=True
   except BaseException as cleanup:record['cleanup_failure']=dict(type=type(cleanup).__name__,message=str(cleanup))
  raise
 finally:
  record.update(ended_utc=utc(),leader_reaped=reaped,files={p.name:dict(bytes=p.stat().st_size,sha256=sha(p)) for p in [out/'stdout.log',out/'stderr.log',report] if p.exists()})
  with (out/'execution.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print('EXECUTION',sha(out/'execution.json'))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--draft',action='store_true');ap.add_argument('--prepare',action='store_true');ap.add_argument('--execute-authorized',action='store_true');ap.add_argument('--worker',action='store_true',help=argparse.SUPPRESS);ap.add_argument('--binary',type=Path);ap.add_argument('--sha256');ap.add_argument('--output-directory',type=Path);args=ap.parse_args()
 if args.draft or args.prepare:
  if args.execute_authorized or args.worker or args.binary or args.sha256 or args.output_directory:ap.error('preparation and execution are separate')
  _,matrix=assemble(args.draft);dest=path_for('matrix.json',args.draft)
  with dest.open('x') as f:json.dump(matrix,f,indent=2);f.write('\n')
  print('PREPARED',matrix['fixture_modes'],'fixture modes / 24 controls; no engine execution');return
 if not args.execute_authorized:
  if args.worker or args.binary or args.sha256 or args.output_directory:ap.error('--execute-authorized required')
  verify();print('VERIFIED, no engine execution');return
 if not args.binary or not args.sha256 or not args.output_directory:ap.error('binary, SHA and fresh output directory required')
 binary=args.binary.resolve();out=args.output_directory.resolve()
 if len(args.sha256)!=64 or any(c not in '0123456789abcdef' for c in args.sha256):ap.error('invalid SHA256')
 if args.worker:worker(binary,args.sha256,out/'report.json')
 else:supervise(binary,args.sha256,out)
if __name__=='__main__':main()
