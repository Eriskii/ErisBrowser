# Independent own-key preparation

Status: frozen after root and independent static reviews, before implementation or adapter execution. No JavaScript engine has been executed. Only scratch files under this directory are owned by this preparation. The final ledger is freeze.json; prefreeze.json and review-v1 preserve historical draft provenance.

`prepare.py --draft` produces 43 independently spelled semantic cases in `own-keys.draft.js`, 86 strict/sloppy modes, and four positive/wrong feature-control pairs. `run.py --draft` binds those cases plus 16 feature controls and eight common harness controls into `matrix.draft.json`. Only the original pinned `assert.js` and `sta.js` are loaded. They and the Test262 license are unchanged copies from revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`.

Coverage includes mixed numeric/string/symbol ordering, exact UTF-16/NUL name identity, deletion and reinsertion, dense/hole/sidecar/sparse arrays, virtual boxed/primitive strings, getters observed after snapshots, descriptor collection versus partial definition, array length conversion effects and descending deletion, and reached for-in prototypes/shadows. The long-prefix case checks exact semantic output only. It asserts no resource threshold. No cases have metadata exclusions or guessed resource expectations, and all failures remain in the result inventory.

Three cases are explicitly `implementation-preservation` rather than universal ECMAScript expectations: deletion allowing an inherited name, adding a prototype property during enumeration, and replacing a prototype during enumeration. They preserve this engine's lazy reached-prototype behavior. The specification relaxes its mandatory CreateForInIterator-equivalence rule after these mutations. These labels do not filter or forgive failures.

The descriptor-atomicity control was corrected during root's prefreeze review: it inspects `Object.getOwnPropertyNames(target).length`, since a wrongly early applied `a: {value: 1}` would be nonenumerable. Its 0/1 expected pair is unchanged. `review-v1` retains the original draft and generator. No engine result prompted the correction.

## Primary references

- [OrdinaryOwnPropertyKeys](https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ordinaryownpropertykeys) and [String exotic own keys](https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-string-exotic-objects-ownpropertykeys): numeric indices first, then other strings and symbols by creation; string virtual indices use UTF-16 code units.
- [EnumerableOwnProperties](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-enumerableownproperties): collect keys, then consult each current own descriptor before a value read.
- [ObjectDefineProperties](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-objectdefineproperties): descriptor conversion finishes before target definitions begin.
- [ArraySetLength](https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-arraysetlength): separate conversions precede the current length check; shrink deletion proceeds in descending order and can preserve a partially deleted prefix with final readonly length.
- [EnumerateObjectProperties](https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-enumerate-object-properties): symbol omission, name suppression including nonenumerable shadows, and the explicitly qualified iteration-order guarantee.

## Eventual replay contract

Preparation is inert. The reviewed `finalize.py --freeze-authorized` creates final files byte-identical to the corrected draft and writes `freeze.json` without replacing existing files. Every execution verifies that ledger and the exact matrix before and after. Default `run.py` verifies only. Execution additionally requires explicit `--execute-authorized`, `--binary`, `--sha256`, and a fresh `--output-directory` outside the fixture directory. No default engine is selected.

The runner preserves every raw result, source, mode, expected status/error identity, fingerprints and control partner. Wrong controls verify only alongside a successful same-mode positive, so an incidental TypeError cannot pass one. Semantic cases are expected to complete after their assertions; their successful smoke control is separately retained.

Each adapter call is bounded to three seconds and 96 KiB stdout / 64 KiB stderr. The entire sequential run uses a 450-second deadline, 512 MiB process address-space limit, 60-second CPU limit and 32 MiB per output file; core dumps are disabled. A supervisor creates an owned process group, observes leader exit with waitid NOWAIT, signals that group before the first reaping wait, and records bounded cleanup. Once reaping begins it never signals that numeric PID again. The five-second reaping deadline is a bound on waiting, not a guarantee of kernel task termination. The group cannot contain a descendant that deliberately creates a separate session; the controlled adapter's own bounded host-helper lifecycle remains responsible for its helpers.

Output directories are exclusive and retain start/end records, stdout, stderr, all observations and post-run hash verification. There is no retry, normalization or baseline publication. A mismatch remains a mismatch, including any unexpected resource or unsupported outcome.
