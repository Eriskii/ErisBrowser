#!/usr/bin/env python3
"""Freeze the reviewed local oracle without starting an engine or subprocess."""
import argparse,hashlib,importlib.util,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(name,file):
 spec=importlib.util.spec_from_file_location(name,HERE/file);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--freeze-authorized',action='store_true');args=ap.parse_args()
 if not args.freeze_authorized:ap.error('review approval required before final freeze')
 for name in ['own-keys.js','expectations.json','preflights.json','matrix.json','freeze.json']:
  assert not (HERE/name).exists(),name
 prepare=load('own_keys_prepare','prepare.py');run=load('own_keys_runner','run.py')
 prepare.output(False)
 for name in ['own-keys.js','expectations.json','preflights.json']:
  assert (HERE/name).read_bytes()==run.path_for(name,True).read_bytes(),name
 _,matrix=run.assemble(False)
 assert matrix==json.loads((HERE/'matrix.draft.json').read_bytes())
 with (HERE/'matrix.json').open('x') as f:json.dump(matrix,f,indent=2);f.write('\n')
 files=sorted(p for p in HERE.rglob('*') if p.is_file())
 assert not any('__pycache__' in p.parts for p in files)
 record=dict(format=1,phase='Final semantic/control/runner freeze before any engine execution',engine_execution=False,source_cases=43,fixture_modes=86,feature_controls=16,common_controls=8,complete_matrix_variants=110,resource_expectations=0,metadata_exclusions=0,case_file_label='own-keys.js',implementation_preservation_modes=6,exact_draft_to_final_sources=True,exact_draft_to_final_matrix=True,files=[dict(path=str(p.relative_to(HERE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files],primary_sources=['https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ordinaryownpropertykeys','https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-string-exotic-objects-ownpropertykeys','https://tc39.es/ecma262/multipage/abstract-operations.html#sec-enumerableownproperties','https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-objectdefineproperties','https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-arraysetlength','https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-enumerate-object-properties'],resource_tests='Private runtime counters are required for exact resource boundaries; this public semantic fixture makes no guessed resource expectation.')
 with (HERE/'freeze.json').open('x') as f:json.dump(record,f,indent=2,sort_keys=True);f.write('\n')
 run.verify()
 print('FROZEN',len(files),'files; freeze SHA',sha(HERE/'freeze.json'))
if __name__=='__main__':main()
