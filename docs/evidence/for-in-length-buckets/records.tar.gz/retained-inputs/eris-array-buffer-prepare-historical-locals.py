#!/usr/bin/env python3
"""Freeze seven original local contracts using completed observations; no engine execution."""
from pathlib import Path
import ast,hashlib,json
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
read=lambda p:json.loads(Path(p).read_bytes())
record=lambda p:dict(bytes=Path(p).stat().st_size,sha256=sha(p))
old_path=Path('/tmp/eris-array-concat-historical-local-replay-inputs.json');old=read(old_path)
files={str(old_path):record(old_path)};changes=[]
for path,row in old['files'].items():
 current=record(path)
 if current!=row:
  assert path in [str(ROOT/'tools/test262_conformance.py'),str(ROOT/'tools/import_test262.py')],path
  changes.append(dict(path=path,before=row,current=current))
 files[path]=current
historical=Path('/tmp/eris-array-concat-historical-local-candidate-1');receipt=read(historical/'execution.json')
assert receipt['completed'] and receipt['all_inputs_unchanged']
assert receipt['binary_sha256']=='64667259eff3ccec0c2ef98370a60a1dea71560def07574dc59db1bbb3fff3c0'
for path,row in receipt['captured_files'].items():
 p=historical/path;assert sha(p)==row['sha256'];files[str(p)]=record(p)
files[str(historical/'execution.json')]=record(historical/'execution.json')
suites=old['suites']
for s in suites:s['report']=str(historical/('own-keys/report.json' if s['name']=='own-keys' else s['name']+'.json'))
local=Path('/tmp/eris-array-concat-local');local_observed=Path('/tmp/eris-array-concat-local-candidate-1')
suites.append(dict(name='array-concat',runner=str(local/'run.py'),runner_kind='standard',fixture=str(local/'array-concat.js'),matrix=str(local/'matrix.json'),report=str(local_observed/'report.json'),pointer=[],modes=90,controls=68,cpu_seconds=30,wall_seconds=180))
for p in local.rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:files[str(p)]=record(p)
for name in ('report.json','execution.json'):
 p=local_observed/name;files[str(p)]=record(p)
local_receipt=read(local_observed/'execution.json')
assert local_receipt['returncode']==0 and local_receipt['all_inputs_unchanged'] and local_receipt['post_input_checks_passed']
assert local_receipt['binary_sha256']==receipt['binary_sha256']
for s in suites:
 d=read(s['report']);assert d['binary_sha256']==receipt['binary_sha256']
 assert len(d['cases'])==s['modes'] and len(d.get('controls',d.get('harness_controls',[])))==s['controls']
 assert sha(s['runner'])==d['runner_sha256']
 if s['matrix']:assert sha(s['matrix'])==d['matrix_sha256']
prior=Path('/tmp/eris-array-concat-local/tools/test262_conformance.py');current=ROOT/'tools/test262_conformance.py'
def functions(p):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(p.read_text()).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
a,b=functions(prior),functions(current)
for name in ('run_case','case_fingerprint'):assert a[name]==b[name],name
html_prior=prior.with_name('html_conformance.py');assert functions(html_prior)['bounded_process']==functions(ROOT/'tools/html_conformance.py')['bounded_process']
files[str(prior)]=record(prior);files[str(html_prior)]=record(html_prior)
before=Path('/tmp/eris-array-buffer-before')
for name in ('provenance.json','parent-ci-final.json','inputs.json','eris-js'):files[str(before/name)]=record(before/name)
ci=read(before/'parent-ci-final.json');assert ci['headSha']=='77866e93f4d8486807aa843667619ea4ccccccfa' and ci['conclusion']=='success' and len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
source_driver=Path('/tmp/eris-array-concat-historical-local-replay.py')
driver=Path('/tmp/eris-array-buffer-historical-local-replay.py');driver.write_bytes(source_driver.read_bytes())
files[str(source_driver)]=record(source_driver);files[str(driver)]=record(driver);files[str(Path(__file__))]=record(__file__)
data=dict(format=1,before=dict(commit=ci['headSha'],runtime_checkpoint='f65c666ffd22ed80759445e3af13531384b53f7c',directory=str(before),binary_sha256=receipt['binary_sha256'],input_sha256=receipt['production_input_sha256']),counts=dict(suites=7,fixture_modes=1378,controls=316),suites=suites,files=files,live_tool_changes=changes,runner_primitives_AST_identical=['run_case','case_fingerprint','bounded_process'],notes=['Reuse completed published concat observations for BEFORE; no new historical before execution.','All seven original source/helper/runner/mode/expectation byte contracts retained, including prior resource/prerequisite outcomes.','Descriptor runner imports live tools; shared runner primitives independently AST-identical to the frozen local bundle.','Future replay requires explicit candidate directory, production-input SHA, binary SHA, manifest SHA and fresh output directory. No engine execution or normalization during preparation.'])
assert sum(s['modes'] for s in suites)==1378 and sum(s['controls'] for s in suites)==316
out=Path('/tmp/eris-array-buffer-historical-local-replay-inputs.json')
with out.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
print(out,sha(out),data['counts'],len(files),len(changes))
