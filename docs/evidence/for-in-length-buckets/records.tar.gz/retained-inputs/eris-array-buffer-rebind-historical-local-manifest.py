#!/usr/bin/env python3
"""Inert delta: authenticate only new-profile tool additions; retain all old observations."""
from pathlib import Path
import ast,copy,difflib,hashlib,json,subprocess
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE=Path('/tmp/eris-array-buffer-historical-local-replay-inputs.json')
OUT=Path('/tmp/eris-array-buffer-historical-local-manifest-delta');assert not OUT.exists();OUT.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
record=lambda p:dict(bytes=Path(p).stat().st_size,sha256=sha(Path(p).read_bytes()))
assert sha(BASE.read_bytes())=='e3190405609f5046cc79385cfdf70763e3b8c7619cb8b585583ac4db75fba061'
original=json.loads(BASE.read_bytes());changed=[]
for path,row in original['files'].items():
 current=record(path)
 if row!=current:changed.append((path,row,current))
assert {p for p,_,_ in changed}=={str(ROOT/'tools/import_test262.py'),str(ROOT/'tools/test262_conformance.py')}
proof=[]
for absolute,before,current_record in changed:
 rel=str(Path(absolute).relative_to(ROOT));name=Path(rel).name
 completed=subprocess.run(['git','show','HEAD:'+rel],cwd=ROOT,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=10,check=True)
 old=completed.stdout;new=Path(absolute).read_bytes();assert sha(old)==before['sha256'] and len(old)==before['bytes']
 (OUT/('old-'+name)).write_bytes(old);(OUT/('new-'+name)).write_bytes(new)
 text=new.decode()
 if name=='import_test262.py':
  lines=text.splitlines(True)
  removed=[line for line in lines if line.startswith('ARRAY_BUFFER_DIRECTORIES = ') or line.startswith("    'array-buffer': ") or line.startswith("        'array-buffer': ")]
  assert len(removed)==4
  text=''.join(line for line in lines if line not in removed)
  assert text.count("'array-buffer', ")==1
  text=text.replace("'array-buffer', ",'')
  assert text.count("'array-buffer': ARRAY_BUFFER_DIRECTORIES, ")==1
  text=text.replace("'array-buffer': ARRAY_BUFFER_DIRECTORIES, ",'')
  assert text.count("'array-buffer': 'test/built-ins', ")==1
  text=text.replace("'array-buffer': 'test/built-ins', ",'')
  description='Only new ArrayBuffer directory inventory, subtree/helper/profile/root maps, TREE_PROFILES membership and new profile scope string added.'
 else:
  lines=text.splitlines(True);removed=[line for line in lines if line.startswith('ARRAY_BUFFER_FEATURES = ')];assert len(removed)==1
  text=''.join(line for line in lines if line not in removed)
  assert text.count("'array-buffer': ARRAY_BUFFER_FEATURES, ")==1
  text=text.replace("'array-buffer': ARRAY_BUFFER_FEATURES, ",'')
  assert text.count("'array-buffer', ")==3
  text=text.replace("'array-buffer', ",'')
  begin=text.index('def array_buffer_preflight_variants():\n');end=text.index('def array_concat_preflight_variants():\n',begin)
  text=text[:begin]+text[end:]
  branch="    if profile == 'array-buffer':\n        variants += array_buffer_preflight_variants()\n"
  assert text.count(branch)==1;text=text.replace(branch,'')
  description='Only ArrayBuffer feature/profile entry, inherited proof/positive-partner memberships, independent new control function and exact profile dispatch added.'
  def functions(raw):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(raw).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
  a,b=functions(old.decode()),functions(new.decode())
  for f in ('run_case','case_fingerprint'):assert a[f]==b[f],f
 assert text.encode()==old,'remaining non-ArrayBuffer delta: '+name
 patch=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='HEAD/'+rel,tofile='working/'+rel))
 patchfile=OUT/(name+'.diff');patchfile.write_text(patch)
 proof.append(dict(path=absolute,before=before,after=current_record,classification=description,old_bytes_from_git_HEAD_sha256=sha(old),reverse_only_new_profile_additions_reproduces_old_bytes=True,diff=dict(path=str(patchfile),**record(patchfile))))
updated=copy.deepcopy(original)
for absolute,_,current in changed:updated['files'][absolute]=current
updated['manifest_delta']={'original_manifest':{'path':str(BASE),**record(BASE)},'bound_files_checked':len(original['files']),'unchanged_bound_files':len(original['files'])-len(changed),'changes':proof,'original_suites_before_counts_and_observations_unchanged':True,'no_execution':True}
assert updated['suites']==original['suites'] and updated['before']==original['before'] and updated['counts']==original['counts']
updated['files'][str(BASE)]=record(BASE)
for p in sorted(OUT.iterdir()):updated['files'][str(p)]=record(p)
updated['files']['/tmp/eris-array-buffer-historical-local-preflight-attempt-1.json']=record('/tmp/eris-array-buffer-historical-local-preflight-attempt-1.json')
updated['files'][str(Path(__file__))]=record(__file__)
p=Path('/tmp/eris-array-buffer-historical-local-replay-inputs-2.json')
with p.open('x') as f:json.dump(updated,f,indent=2);f.write('\n')
receipt={'phase':'Inert reviewed-input candidate manifest delta, awaiting root authorization','original_manifest':{'path':str(BASE),**record(BASE)},'candidate_manifest':{'path':str(p),**record(p)},'changed_files':proof,'unchanged_original_file_count':263,'original_file_count':265,'new_bound_file_count':len(updated['files']),'counts':updated['counts'],'source_helper_runner_expected_control_before_report_bytes_unchanged':True,'shared_run_case_and_case_fingerprint_AST_identical':True,'all_changes_are_new_ArrayBuffer_profile_additions':True,'first_refusal_receipt':record('/tmp/eris-array-buffer-historical-local-preflight-attempt-1.json'),'engine_runs':0}
q=Path('/tmp/eris-array-buffer-historical-local-manifest-delta-review.json');q.write_text(json.dumps(receipt,indent=2)+'\n')
print('manifest',record(p));print('receipt',record(q))
