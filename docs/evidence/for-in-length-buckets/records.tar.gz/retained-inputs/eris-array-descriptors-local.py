#!/usr/bin/env python3
"""Execute each frozen local descriptor case in a fresh bounded Eris runtime."""
import argparse,collections,hashlib,json,resource,sys,time
from pathlib import Path
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
FIXTURE=ROOT/'tests/conformance/array-descriptors.js'
FIXTURE_SHA='32537a09fbc2f87052e183e2467cdbf4f1128bc2b2a7ec817c776ef61c44400d'
def main():
 p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--sha256',required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
 binary=args.binary.resolve();assert sha(binary)==args.sha256;assert sha(FIXTURE)==FIXTURE_SHA
 resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
 resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
 names=('assert.js','sta.js','propertyHelper.js')
 harness=[(n,(ROOT/'tests/upstream/test262/harness'/n).read_bytes()) for n in names]
 seen=set();results=[];started=time.monotonic()
 for fixture in FIXTURE.read_text().split('// CASE: ')[1:]:
  name,source=fixture.split('\n',1);assert name not in seen;seen.add(name)
  for mode in ('sloppy','strict'):
   c=dict(id=name+'#'+mode,file='tests/conformance/array-descriptors.js',source=source.encode(),mode=mode,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=harness)
   c['case_sha256']=runner.case_fingerprint(c)
   result=runner.run_case(c,binary,3)
   expected=dict(status='complete',phase='runtime',error_type='',error_identity='')
   result['expected_observation']=expected
   result['expectation_sha256']=hashlib.sha256(json.dumps(expected,sort_keys=True).encode()).hexdigest()
   result['source']=source
   result['matches_expectation']=all(result.get('observation',{}).get(k)==v for k,v in expected.items())
   results.append(result);print(result['id'],result['status'],result.get('observation',{}).get('message',''),flush=True)
 assert sha(binary)==args.sha256;assert sha(FIXTURE)==FIXTURE_SHA
 report=dict(binary_sha256=args.sha256,fixture_sha256=FIXTURE_SHA,runner_sha256=sha(__file__),harness=[dict(name=n,sha256=hashlib.sha256(b).hexdigest()) for n,b in harness],bounds=dict(per_case_wall_seconds=3,inherited_address_space_bytes=512*1024*1024,per_process_cpu_seconds=30,core_bytes=0,adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024),counts=dict(collections.Counter(c['status'] for c in results)),cases=results,elapsed_seconds=round(time.monotonic()-started,4))
 args.output.write_text(json.dumps(report,indent=2)+'\n');print('RESULT',len(results),report['counts'])
if __name__=='__main__':main()
