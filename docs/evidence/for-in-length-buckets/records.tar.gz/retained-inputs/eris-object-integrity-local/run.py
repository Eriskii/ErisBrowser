#!/usr/bin/env python3
"""Replay immutable Object integrity fixtures; preparation never starts an adapter."""
import argparse, collections, hashlib, json, resource, sys, time
from pathlib import Path
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE / 'tools'))
import test262_conformance as runner

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--prepare',action='store_true')
    parser.add_argument('--binary',type=Path)
    parser.add_argument('--sha256')
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    freeze=json.loads((HERE/'freeze.json').read_text())
    fixture=HERE/'object-integrity.js'
    assert sha(fixture)==freeze['fixture_sha256'], 'fixture changed'
    assert sha(HERE/'prepare.py')==freeze['generator_sha256'], 'generator changed'
    harness=[(name,(HERE/'harness'/name).read_bytes()) for name in ('assert.js','sta.js','propertyHelper.js')]
    expected=freeze['expected_observation']; matrix=[]; names=set()
    for block in fixture.read_bytes().split(b'// CASE: ')[1:]:
        raw_name, source=block.split(b'\n',1);name=raw_name.decode();assert name not in names;names.add(name)
        for mode in ('sloppy','strict'):
            case=dict(id=name+'#'+mode,file='object-integrity.js',source=source,mode=mode,
                metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=harness)
            case['case_sha256']=runner.case_fingerprint(case)
            matrix.append((case,expected,'semantic'))
    controls=[
        ('positive-samevalue','assert.sameValue(NaN,NaN);assert.notSameValue(0,-0);',True),
        ('negative-samevalue','assert.sameValue(0,-0);',False),
        ('positive-error-identity','assert.throws(TypeError,function(){throw new TypeError();});',True),
        ('negative-error-identity','assert.throws(TypeError,function(){throw new RangeError();});',False),
        ('positive-property-flags',"verifyProperty({x:1},'x',{value:1,writable:true,enumerable:true,configurable:true});",True),
        ('negative-property-flags',"verifyProperty({x:1},'x',{value:1,writable:false,enumerable:true,configurable:true});",False),
    ]
    for name, source, positive in controls:
        for mode in ('sloppy','strict'):
            case=dict(id='harness-'+name+'#'+mode,file='harness-controls',source=source.encode(),mode=mode,
                metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=harness)
            case['case_sha256']=runner.case_fingerprint(case)
            observation=expected if positive else dict(status='exception',phase='runtime',error_identity='',error_type='Test262Error')
            matrix.append((case,observation,'harness-control'))
    identities=[]
    for case,observation,category in matrix:
        identities.append(dict(id=case['id'],category=category,mode=case['mode'],case_sha256=case['case_sha256'],
            source_sha256=hashlib.sha256(case['source']).hexdigest(),source=case['source'].decode(),expected=observation,
            expectation_sha256=hashlib.sha256(json.dumps(observation,sort_keys=True).encode()).hexdigest()))
    record=dict(fixture_sha256=sha(fixture),runner_sha256=sha(__file__),
        tool_hashes={p.name:sha(p) for p in sorted((HERE/'tools').glob('*.py'))},
        harness=[dict(name=n,sha256=hashlib.sha256(b).hexdigest()) for n,b in harness],cases=identities)
    if args.prepare:
        if (HERE/'matrix.json').exists():parser.error('refusing to replace frozen matrix')
        assert len(names)==freeze['source_cases']
        (HERE/'matrix.json').write_text(json.dumps(record,indent=2)+'\n')
        print('Frozen',len(names),'source cases;',2*len(names),'semantic modes;',len(controls)*2,'controls')
        return 0
    if args.binary is None or args.sha256 is None or args.output is None:
        parser.error('--binary, --sha256 and --output are required')
    if args.output.exists():parser.error('refusing to overwrite an existing observation report')
    assert record==json.loads((HERE/'matrix.json').read_text()),'matrix, tool or harness changed'
    binary=args.binary.resolve();assert sha(binary)==args.sha256,'binary hash differs'
    resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
    resource.setrlimit(resource.RLIMIT_CPU,(30,30));resource.setrlimit(resource.RLIMIT_CORE,(0,0))
    started=time.monotonic();semantic=[];observed_controls=[]
    for (case,observation,category),identity in zip(matrix,identities):
        result=runner.run_case(case,binary,3)
        result.update(category=category,source=identity['source'],expected_observation=observation,
            expectation_sha256=identity['expectation_sha256'])
        result['matches_expectation']=all(result.get('observation',{}).get(k)==v for k,v in observation.items())
        (semantic if category=='semantic' else observed_controls).append(result)
        print(result['id'],result['status'],result.get('observation',{}).get('message',''),flush=True)
    assert sha(binary)==args.sha256 and sha(fixture)==freeze['fixture_sha256']
    report=dict(binary=str(binary),binary_sha256=args.sha256,fixture_sha256=sha(fixture),matrix_sha256=sha(HERE/'matrix.json'),
        runner_sha256=sha(__file__),tool_hashes=record['tool_hashes'],harness=record['harness'],
        bounds=dict(per_case_wall_seconds=3,address_space_bytes=512*1024*1024,per_process_cpu_seconds=30,core_bytes=0,
            adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024),
        counts=dict(collections.Counter(x['status'] for x in semantic)),cases=semantic,harness_controls=observed_controls,
        harness_controls_verified=sum(x['matches_expectation'] for x in observed_controls),
        elapsed_seconds=round(time.monotonic()-started,4))
    with args.output.open('x') as handle:handle.write(json.dumps(report,indent=2)+'\n')
    print('RESULT',len(semantic),report['counts'],'CONTROLS',report['harness_controls_verified'],'/',len(observed_controls))
    return 0
if __name__=='__main__':
    raise SystemExit(main())
