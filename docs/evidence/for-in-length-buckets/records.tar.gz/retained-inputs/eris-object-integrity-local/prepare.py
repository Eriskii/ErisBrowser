#!/usr/bin/env python3
"""Independently authored Object integrity sources; no adapter execution."""
from pathlib import Path
import hashlib, json
HERE = Path(__file__).resolve().parent
METHODS = ('seal', 'freeze', 'isSealed', 'isFrozen')
CASES = []
def case(name, source, methods=METHODS):
    for method in methods:
        CASES.append((method + '-' + name, method, source.strip()))
MUTATORS = ('seal', 'freeze')
QUERIES = ('isSealed', 'isFrozen')

case('intrinsic-metadata-and-not-a-constructor', r'''
var d=Object.getOwnPropertyDescriptor(Object,name);
assert.sameValue(d.value,m);assert.sameValue(d.writable,true);assert.sameValue(d.enumerable,false);assert.sameValue(d.configurable,true);
var n=Object.getOwnPropertyDescriptor(m,'name'),l=Object.getOwnPropertyDescriptor(m,'length');
assert.sameValue(n.value,name);assert.sameValue(n.writable,false);assert.sameValue(n.enumerable,false);assert.sameValue(n.configurable,true);
assert.sameValue(l.value,1);assert.sameValue(l.writable,false);assert.sameValue(l.enumerable,false);assert.sameValue(l.configurable,true);
assert.sameValue(Object.getPrototypeOf(m),Function.prototype);assert.sameValue(Object.getOwnPropertyDescriptor(m,'prototype'),undefined);
assert.throws(TypeError,function(){new m({});});
assert.notSameValue(Object.seal,Object.freeze);assert.notSameValue(Object.isSealed,Object.isFrozen);
''')
case('all-supported-primitives-and-omitted-argument', r'''
var s=Symbol('primitive'),values=[undefined,null,false,true,0,-0,1,-2,NaN,Infinity,-Infinity,'','abc','\ud800',s];
for(var i=0;i<values.length;i++){assert.sameValue(m(values[i]),isQuery?true:values[i]);}
assert.sameValue(m(),isQuery?true:undefined);
''')
case('ignored-receivers-call-apply-bind', r'''
var receivers=[undefined,null,0,false,'receiver',Symbol('receiver'),{}];
for(var i=0;i<receivers.length;i++){var o={x:1};assert.sameValue(m.call(receivers[i],o),isQuery?false:o);}
var a={},b={};assert.sameValue(m.apply(null,[a]),isQuery?false:a);assert.sameValue(m.bind(7,b)(),isQuery?false:b);
''')
case('method-lookup-and-argument-evaluation-order', r'''
var log='',o={x:1},holder={get method(){log+='M';return m;}},extra={get valueOf(){throw 'unused';},get toString(){throw 'unused';}};
function first(){log+='A';return o;}function second(){log+='B';o.x=2;return extra;}
assert.sameValue(holder.method(first(),second()),isQuery?false:o);assert.sameValue(log,'MAB');assert.sameValue(o.x,2);
assert.sameValue(Object.isExtensible(o),isQuery);
''')
case('abrupt-argument-prevents-operation', r'''
var reason={},caught,log='',o={x:1};function first(){log+='A';return o;}function extra(){log+='B';throw reason;}
try{m(first(),extra());}catch(e){caught=e;}
assert.sameValue(caught,reason);assert.sameValue(log,'AB');assert.sameValue(Object.isExtensible(o),true);
assert.sameValue(Object.getOwnPropertyDescriptor(o,'x').configurable,true);
''')
case('internal-descriptors-never-call-author-hooks', r'''
var reads=0,o={};function poison(){reads++;throw 'unexpected author call';}
Object.defineProperty(o,'valueOf',{get:poison,configurable:true});Object.defineProperty(o,'toString',{get:poison,configurable:true});
Object.defineProperty(o,'constructor',{get:poison,configurable:true});Object.defineProperty(o,'length',{get:poison,configurable:true});
Object.defineProperty(o,Symbol.toPrimitive,{get:poison,configurable:true});
assert.sameValue(m(o),isQuery?false:o);assert.sameValue(reads,0);
if(isQuery){Object.preventExtensions(o);assert.sameValue(m(o),false);assert.sameValue(reads,0);}
''')
case('saved-alias-after-property-replacement-and-deletion', r'''
Object[name]=null;var a={};assert.sameValue(m(a),isQuery?false:a);
delete Object[name];var b={};assert.sameValue(m(b),isQuery?false:b);
Object.defineProperty(m,'name',{value:'renamed'});assert.sameValue(m(7),isQuery?true:7);
''')
case('primitive-input-does-not-read-wrapper-hooks', r'''
var calls=0;function poison(){calls++;throw 'coercion';}
Object.defineProperty(Number.prototype,'valueOf',{get:poison,configurable:true});
Object.defineProperty(String.prototype,'toString',{get:poison,configurable:true});
Object.defineProperty(Boolean.prototype,Symbol.toPrimitive,{get:poison,configurable:true});
assert.sameValue(m(-0),isQuery?true:-0);assert.sameValue(m('x'),isQuery?true:'x');assert.sameValue(m(false),isQuery?true:false);assert.sameValue(calls,0);
''')
case('data-descriptor-flags-and-values', r'''
var o={visible:1},child={};Object.defineProperty(o,'hidden',{value:child,writable:false,enumerable:false,configurable:true});
Object.defineProperty(o,'fixed',{value:NaN,writable:true,enumerable:false,configurable:false});
assert.sameValue(m(o),o);assert.sameValue(Object.isExtensible(o),false);
var a=Object.getOwnPropertyDescriptor(o,'visible'),b=Object.getOwnPropertyDescriptor(o,'hidden'),c=Object.getOwnPropertyDescriptor(o,'fixed');
assert.sameValue(a.value,1);assert.sameValue(a.writable,!freezing);assert.sameValue(a.enumerable,true);assert.sameValue(a.configurable,false);
assert.sameValue(b.value,child);assert.sameValue(b.writable,false);assert.sameValue(b.enumerable,false);assert.sameValue(b.configurable,false);
assert.sameValue(c.value,NaN);assert.sameValue(c.writable,!freezing);assert.sameValue(c.enumerable,false);assert.sameValue(c.configurable,false);
assert.sameValue(Object.isSealed(o),true);assert.sameValue(Object.isFrozen(o),freezing);
''', MUTATORS)
case('idempotent-return-identity-and-existing-restrictions', r'''
var o={x:1};Object.defineProperty(o,'r',{value:-0,writable:false,configurable:false});Object.preventExtensions(o);
assert.sameValue(m(o),o);assert.sameValue(m(o),o);assert.sameValue(m(o),o);
assert.sameValue(Object.getOwnPropertyDescriptor(o,'r').value,-0);assert.sameValue(Object.getOwnPropertyDescriptor(o,'r').writable,false);
assert.sameValue(Object.isSealed(o),true);assert.sameValue(Object.isFrozen(o),freezing);
''', MUTATORS)
case('writes-to-existing-data-follow-caller-mode', r'''
var o={x:1};m(o);var caught=false;try{o.x=2;}catch(e){assert.sameValue(e instanceof TypeError,true);caught=true;}
assert.sameValue(caught,freezing&&strictMode);assert.sameValue(o.x,freezing?1:2);
function strictWrite(){'use strict';o.x=3;}
if(freezing){assert.throws(TypeError,strictWrite);}else{strictWrite();assert.sameValue(o.x,3);}
''', MUTATORS)
case('new-properties-refused-without-changing-value', r'''
var o={},s=Symbol('new');m(o);var caught=false;try{o.x=1;}catch(e){assert.sameValue(e instanceof TypeError,true);caught=true;}
assert.sameValue(caught,strictMode);assert.sameValue(Object.getOwnPropertyDescriptor(o,'x'),undefined);
assert.throws(TypeError,function(){'use strict';o[s]=2;});assert.sameValue(Object.getOwnPropertyDescriptor(o,s),undefined);
assert.throws(TypeError,function(){Object.defineProperty(o,'y',{value:3});});assert.sameValue(Object.isExtensible(o),false);
''', MUTATORS)
case('deletion-follows-caller-mode-without-getter', r'''
var calls=0,o={};Object.defineProperty(o,'x',{get:function(){calls++;throw 'getter';},configurable:true});m(o);
var caught=false,result;try{result=delete o.x;}catch(e){assert.sameValue(e instanceof TypeError,true);caught=true;}
assert.sameValue(caught,strictMode);if(!strictMode)assert.sameValue(result,false);
assert.throws(TypeError,function(){'use strict';delete o.x;});assert.sameValue(calls,0);
assert.sameValue(delete o.absent,true);assert.notSameValue(Object.getOwnPropertyDescriptor(o,'x'),undefined);
''', MUTATORS)
case('accessor-identity-and-setter-survive', r'''
var calls=0,stored=0,o={},getter=function(){calls++;return stored;},setter=function(v){assert.sameValue(this,o);stored=v;};
Object.defineProperty(o,'x',{get:getter,set:setter,enumerable:true,configurable:true});
assert.sameValue(m(o),o);assert.sameValue(calls,0);assert.sameValue(Object.isFrozen(o),true);assert.sameValue(calls,0);
var d=Object.getOwnPropertyDescriptor(o,'x');assert.sameValue(d.get,getter);assert.sameValue(d.set,setter);assert.sameValue(d.configurable,false);assert.sameValue(d.enumerable,true);
assert.sameValue(Object.getOwnPropertyDescriptor(d,'value'),undefined);assert.sameValue(Object.getOwnPropertyDescriptor(d,'writable'),undefined);
o.x=9;assert.sameValue(stored,9);assert.sameValue(o.x,9);assert.sameValue(calls,1);
Object.defineProperty(o,'x',{get:getter,set:setter});assert.throws(TypeError,function(){Object.defineProperty(o,'x',{get:function(){}});});
''', MUTATORS)
case('undefined-accessors-remain-accessors', r'''
var o={};Object.defineProperty(o,'x',{get:undefined,set:undefined,enumerable:false,configurable:true});m(o);
var d=Object.getOwnPropertyDescriptor(o,'x');assert.sameValue(d.get,undefined);assert.sameValue(d.set,undefined);assert.sameValue(d.enumerable,false);assert.sameValue(d.configurable,false);
assert.sameValue(Object.getOwnPropertyDescriptor(d,'writable'),undefined);assert.sameValue(Object.isFrozen(o),true);
assert.throws(TypeError,function(){'use strict';o.x=1;});assert.sameValue(o.x,undefined);
''', MUTATORS)
case('descriptor-redefinition-compatible-and-rejected', r'''
var o={x:1};m(o);Object.defineProperty(o,'x',{value:1});
assert.throws(TypeError,function(){Object.defineProperty(o,'x',{configurable:true});});
assert.throws(TypeError,function(){Object.defineProperty(o,'x',{enumerable:false});});
assert.throws(TypeError,function(){Object.defineProperty(o,'x',{get:function(){return 1;}});});
if(freezing){assert.throws(TypeError,function(){Object.defineProperty(o,'x',{value:2});});assert.throws(TypeError,function(){Object.defineProperty(o,'x',{writable:true});});}
else{Object.defineProperty(o,'x',{value:2,writable:false});assert.sameValue(o.x,2);assert.sameValue(Object.isFrozen(o),true);}
''', MUTATORS)
case('symbols-including-nonenumerable-and-same-description', r'''
var a=Symbol('same'),b=Symbol('same'),o={};o[a]=1;Object.defineProperty(o,b,{value:2,writable:true,enumerable:false,configurable:true});m(o);
var da=Object.getOwnPropertyDescriptor(o,a),db=Object.getOwnPropertyDescriptor(o,b);
assert.sameValue(da.value,1);assert.sameValue(db.value,2);assert.sameValue(da.enumerable,true);assert.sameValue(db.enumerable,false);
assert.sameValue(da.configurable,false);assert.sameValue(db.configurable,false);assert.sameValue(da.writable,!freezing);assert.sameValue(db.writable,!freezing);
assert.sameValue(Object.getOwnPropertySymbols(o).length,2);assert.sameValue(Object.isSealed(o),true);assert.sameValue(Object.isFrozen(o),freezing);
''', MUTATORS)
case('symbol-accessor-with-no-author-invocation', r'''
var k=Symbol('key'),o={},reads=0,stored=0,g=function(){reads++;return stored;},s=function(v){stored=v;};
Object.defineProperty(o,k,{get:g,set:s,configurable:true});m(o);assert.sameValue(reads,0);assert.sameValue(Object.isFrozen(o),true);
var d=Object.getOwnPropertyDescriptor(o,k);assert.sameValue(d.get,g);assert.sameValue(d.set,s);assert.sameValue(d.configurable,false);o[k]=7;assert.sameValue(stored,7);assert.sameValue(reads,0);
''', MUTATORS)
case('own-only-shallow-and-inherited-setter', r'''
var child={x:1},calls=0,p={inherited:2,set accepted(v){assert.sameValue(this,o);calls+=v;}},o=Object.create(p);o.child=child;m(o);
child.x=3;child.newValue=4;p.inherited=5;o.accepted=7;
assert.sameValue(o.child,child);assert.sameValue(child.x,3);assert.sameValue(child.newValue,4);assert.sameValue(o.inherited,5);assert.sameValue(calls,7);
assert.sameValue(Object.isExtensible(child),true);assert.sameValue(Object.isExtensible(p),true);assert.sameValue(Object.getOwnPropertyDescriptor(o,'accepted'),undefined);
''', MUTATORS)
case('null-prototype-and-exact-utf16-keys', r'''
var o=Object.create(null);o['\ud800']=1;o['\udfff']=2;o['\u0000']=3;o['__proto__']=4;m(o);
assert.sameValue(Object.getPrototypeOf(o),null);assert.sameValue(Object.getOwnPropertyNames(o).length,4);
assert.sameValue(Object.getOwnPropertyDescriptor(o,'\ud800').value,1);assert.sameValue(Object.getOwnPropertyDescriptor(o,'\udfff').value,2);
assert.sameValue(Object.getOwnPropertyDescriptor(o,'\u0000').value,3);assert.sameValue(Object.getOwnPropertyDescriptor(o,'__proto__').value,4);
assert.sameValue(Object.isSealed(o),true);assert.sameValue(Object.isFrozen(o),freezing);
''', MUTATORS)
case('prototype-lock-retains-same-prototype', r'''
var p={},o=Object.create(p);m(o);assert.sameValue(Object.setPrototypeOf(o,p),o);
assert.throws(TypeError,function(){Object.setPrototypeOf(o,{});});assert.throws(TypeError,function(){Object.setPrototypeOf(o,null);});
assert.sameValue(Object.getPrototypeOf(o),p);p.x=7;assert.sameValue(o.x,7);
''', MUTATORS)
case('ordinary-self-cycle-is-shallow', r'''
var o={};o.self=o;m(o);assert.sameValue(o.self,o);assert.sameValue(Object.isSealed(o),true);assert.sameValue(Object.isFrozen(o),freezing);
''', MUTATORS)
case('dense-array-descriptors-and-length', r'''
var a=[1,undefined,3];a.extra=4;assert.sameValue(m(a),a);assert.sameValue(a.length,3);assert.sameValue(a[0],1);assert.sameValue(a[1],undefined);
for(var i=0;i<3;i++){var d=Object.getOwnPropertyDescriptor(a,''+i);assert.sameValue(d.configurable,false);assert.sameValue(d.writable,!freezing);assert.sameValue(d.enumerable,true);}
var l=Object.getOwnPropertyDescriptor(a,'length');assert.sameValue(l.value,3);assert.sameValue(l.enumerable,false);assert.sameValue(l.configurable,false);assert.sameValue(l.writable,!freezing);
assert.sameValue(Object.getOwnPropertyDescriptor(a,'extra').writable,!freezing);assert.sameValue(Object.isSealed(a),true);assert.sameValue(Object.isFrozen(a),freezing);
''', MUTATORS)
case('sparse-max-length-array-does-not-create-holes', r'''
var a=new Array(4294967295),s=Symbol('tail');a[0]=1;a[4294967294]=2;a['4294967295']=3;a['01']=4;a[s]=5;m(a);
assert.sameValue(a.length,4294967295);assert.sameValue(Object.getOwnPropertyDescriptor(a,'1'),undefined);assert.sameValue(Object.getOwnPropertyDescriptor(a,'4294967293'),undefined);
assert.sameValue(Object.getOwnPropertyNames(a).length,5);assert.sameValue(Object.getOwnPropertySymbols(a).length,1);
assert.sameValue(Object.getOwnPropertyDescriptor(a,'4294967294').value,2);assert.sameValue(Object.getOwnPropertyDescriptor(a,'4294967294').writable,!freezing);
assert.sameValue(Object.getOwnPropertyDescriptor(a,'4294967295').value,3);assert.sameValue(Object.getOwnPropertyDescriptor(a,'01').configurable,false);
assert.sameValue(Object.getOwnPropertyDescriptor(a,s).configurable,false);assert.sameValue(Object.isSealed(a),true);assert.sameValue(Object.isFrozen(a),freezing);
''', MUTATORS)
case('array-holes-prototypes-and-failed-fill', r'''
var p={1:8},a=[1,,3];Object.setPrototypeOf(a,p);m(a);assert.sameValue(a[1],8);assert.sameValue(Object.getOwnPropertyDescriptor(a,'1'),undefined);
assert.throws(TypeError,function(){'use strict';a[1]=9;});assert.sameValue(a[1],8);assert.sameValue(Object.getOwnPropertyDescriptor(a,'1'),undefined);
p[1]=10;assert.sameValue(a[1],10);assert.sameValue(Object.getOwnPropertyDescriptor(p,'1').configurable,true);
''', MUTATORS)
case('indexed-array-accessor-survives', r'''
var a=[1],reads=0,stored=2,g=function(){reads++;return stored;},s=function(v){assert.sameValue(this,a);stored=v;};
Object.defineProperty(a,'0',{get:g,set:s,enumerable:false,configurable:true});m(a);assert.sameValue(reads,0);
var d=Object.getOwnPropertyDescriptor(a,'0');assert.sameValue(d.get,g);assert.sameValue(d.set,s);assert.sameValue(d.configurable,false);assert.sameValue(d.enumerable,false);assert.sameValue(Object.getOwnPropertyDescriptor(d,'writable'),undefined);
a[0]=7;assert.sameValue(stored,7);assert.sameValue(reads,0);assert.sameValue(a[0],7);assert.sameValue(reads,1);
assert.sameValue(Object.isFrozen(a),freezing);
''', MUTATORS)
case('readonly-array-length-remains-readonly', r'''
var a=[1];Object.defineProperty(a,'length',{writable:false});m(a);
assert.sameValue(Object.getOwnPropertyDescriptor(a,'length').writable,false);assert.sameValue(Object.isFrozen(a),freezing);
assert.throws(TypeError,function(){'use strict';a.length=1;});assert.sameValue(a.length,1);
''', MUTATORS)
case('string-wrapper-intrinsic-properties-and-extra', r'''
var s=new String('A\ud800');s.extra=7;m(s);assert.sameValue(s.valueOf(),'A\ud800');assert.sameValue(s.length,2);
for(var i=0;i<2;i++){var d=Object.getOwnPropertyDescriptor(s,''+i);assert.sameValue(d.value,i===0?'A':'\ud800');assert.sameValue(d.writable,false);assert.sameValue(d.enumerable,true);assert.sameValue(d.configurable,false);}
var l=Object.getOwnPropertyDescriptor(s,'length');assert.sameValue(l.value,2);assert.sameValue(l.writable,false);assert.sameValue(l.enumerable,false);assert.sameValue(l.configurable,false);
assert.sameValue(Object.getOwnPropertyDescriptor(s,'extra').writable,!freezing);assert.sameValue(Object.isSealed(s),true);assert.sameValue(Object.isFrozen(s),freezing);
''', MUTATORS)
case('string-wrapper-with-no-extra-is-frozen-when-sealed', r'''
var values=['','xy','\ud800'];for(var i=0;i<values.length;i++){var o=new String(values[i]);assert.sameValue(m(o),o);assert.sameValue(Object.isFrozen(o),true);assert.sameValue(Object.isSealed(o),true);assert.sameValue(o.valueOf(),values[i]);}
''', MUTATORS)
case('number-boolean-symbol-wrappers-remain-usable', r'''
var sym=Symbol('wrapped'),values=[new Number(-0),new Boolean(false),Object(sym)];
for(var i=0;i<values.length;i++){var o=values[i];m(o);assert.sameValue(Object.isFrozen(o),true);assert.sameValue(Object.isSealed(o),true);}
assert.sameValue(values[0].valueOf(),-0);assert.sameValue(values[1].valueOf(),false);assert.sameValue(values[2].valueOf(),sym);
''', MUTATORS)
case('ordinary-function-call-and-prototype-remain-live', r'''
function f(v){return v+1;}f.extra=3;var p=f.prototype;m(f);assert.sameValue(f(4),5);assert.sameValue(f.prototype,p);
assert.sameValue(Object.getOwnPropertyDescriptor(f,'extra').writable,!freezing);assert.sameValue(Object.getOwnPropertyDescriptor(f,'length').configurable,false);
p.member=9;assert.sameValue(f.prototype.member,9);assert.sameValue(Object.isExtensible(p),true);assert.sameValue(Object.isSealed(f),true);assert.sameValue(Object.isFrozen(f),freezing);
''', MUTATORS)
case('frozen-native-method-still-calls', r'''
var callable=Number.isFinite;m(callable);assert.sameValue(callable(1),true);assert.sameValue(callable('1'),false);assert.sameValue(Object.isFrozen(callable),true);
''', MUTATORS)
case('data-descriptor-truth-table', r'''
for(var ext=0;ext<2;ext++){for(var config=0;config<2;config++){for(var writable=0;writable<2;writable++){for(var enumerable=0;enumerable<2;enumerable++){
var o={};Object.defineProperty(o,'x',{value:1,writable:!!writable,enumerable:!!enumerable,configurable:!!config});if(!ext)Object.preventExtensions(o);
assert.sameValue(m(o),!ext&&!config&&(!frozenQuery||!writable));
var d=Object.getOwnPropertyDescriptor(o,'x');assert.sameValue(d.writable,!!writable);assert.sameValue(d.enumerable,!!enumerable);assert.sameValue(d.configurable,!!config);assert.sameValue(Object.isExtensible(o),!!ext);
}}}}
''', QUERIES)
case('accessor-truth-table-without-invocation', r'''
var calls=0;function poison(){calls++;throw 'getter';}
for(var ext=0;ext<2;ext++){for(var config=0;config<2;config++){for(var enumerable=0;enumerable<2;enumerable++){
var o={};Object.defineProperty(o,'x',{get:poison,set:poison,enumerable:!!enumerable,configurable:!!config});if(!ext)Object.preventExtensions(o);
assert.sameValue(m(o),!ext&&!config);assert.sameValue(calls,0);
}}}
''', QUERIES)
case('empty-and-inherited-properties-do-not-count', r'''
var calls=0,p={x:1,get inherited(){calls++;throw 'inherited';}},o=Object.create(p);
assert.sameValue(m(o),false);Object.preventExtensions(o);assert.sameValue(m(o),true);assert.sameValue(calls,0);assert.sameValue(Object.isExtensible(p),true);
assert.sameValue(m(Object.preventExtensions(Object.create(null))),true);
''', QUERIES)
case('all-properties-not-just-first-or-enumerable', r'''
var o={};Object.defineProperty(o,'first',{value:1});Object.defineProperty(o,'hidden',{value:2,writable:true,configurable:true,enumerable:false});Object.preventExtensions(o);
assert.sameValue(m(o),false);Object.defineProperty(o,'hidden',{configurable:false});assert.sameValue(m(o),!frozenQuery);
Object.defineProperty(o,'hidden',{writable:false});assert.sameValue(m(o),true);
''', QUERIES)
case('symbol-only-state-is-observed', r'''
var k=Symbol('hidden'),o={};Object.defineProperty(o,k,{value:1,writable:true,configurable:true});Object.preventExtensions(o);
assert.sameValue(m(o),false);Object.defineProperty(o,k,{configurable:false});assert.sameValue(m(o),!frozenQuery);Object.defineProperty(o,k,{writable:false});assert.sameValue(m(o),true);
''', QUERIES)
case('sparse-array-length-counts-as-data-property', r'''
var a=new Array(4294967295);Object.preventExtensions(a);assert.sameValue(m(a),!frozenQuery);
Object.defineProperty(a,'length',{writable:false});assert.sameValue(m(a),true);assert.sameValue(Object.getOwnPropertyDescriptor(a,'0'),undefined);assert.sameValue(a.length,4294967295);
''', QUERIES)
case('array-element-flags-are-independent-from-length', r'''
var a=[1];Object.defineProperty(a,'length',{writable:false});Object.preventExtensions(a);assert.sameValue(m(a),false);
Object.defineProperty(a,'0',{configurable:false});assert.sameValue(m(a),!frozenQuery);Object.defineProperty(a,'0',{writable:false});assert.sameValue(m(a),true);
''', QUERIES)
case('string-wrapper-empty-and-nonempty', r'''
var values=['','ab','\ud800'];for(var i=0;i<values.length;i++){var o=new String(values[i]);assert.sameValue(m(o),false);Object.preventExtensions(o);assert.sameValue(m(o),true);}
''', QUERIES)
case('sealed-array-length-can-grow-and-shrink-holes', r'''
var a=new Array(5);a[1]=7;m(a);a.length=9;assert.sameValue(a.length,9);a.length=2;assert.sameValue(a.length,2);assert.sameValue(a[1],7);assert.sameValue(Object.isSealed(a),true);assert.sameValue(Object.isFrozen(a),false);
var caught=false;try{a.length=0;}catch(e){assert.sameValue(e instanceof TypeError,true);caught=true;}assert.sameValue(caught,strictMode);assert.sameValue(a.length,2);assert.sameValue(a[1],7);
Object.defineProperty(a,'length',{writable:false});assert.sameValue(Object.isFrozen(a),false);Object.defineProperty(a,'1',{writable:false});assert.sameValue(Object.isFrozen(a),true);
''', ('seal',))
case('freeze-locks-empty-array-length', r'''
var a=[];m(a);assert.sameValue(Object.isFrozen(a),true);assert.sameValue(Object.getOwnPropertyDescriptor(a,'length').writable,false);
assert.throws(TypeError,function(){'use strict';a.length=0;});assert.throws(TypeError,function(){a.push(1);});assert.sameValue(a.length,0);
''', ('freeze',))
case('frozen-data-redefinition-uses-samevalue', r'''
var child={},o={zero:-0,nan:NaN,child:child};m(o);
Object.defineProperty(o,'zero',{value:-0});Object.defineProperty(o,'nan',{value:NaN});Object.defineProperty(o,'child',{value:child});
assert.throws(TypeError,function(){Object.defineProperty(o,'zero',{value:0});});assert.throws(TypeError,function(){Object.defineProperty(o,'child',{value:{}});});
assert.sameValue(o.zero,-0);assert.sameValue(o.nan,NaN);assert.sameValue(o.child,child);
''', ('freeze',))
case('sealing-a-frozen-object-does-not-thaw', r'''
var o=Object.freeze({x:1});assert.sameValue(m(o),o);assert.sameValue(Object.isFrozen(o),true);assert.sameValue(Object.getOwnPropertyDescriptor(o,'x').writable,false);
''', ('seal',))
case('freezing-a-sealed-object-tightens-writability', r'''
var o=Object.seal({x:1});assert.sameValue(Object.isFrozen(o),false);assert.sameValue(m(o),o);assert.sameValue(Object.isFrozen(o),true);assert.sameValue(Object.getOwnPropertyDescriptor(o,'x').writable,false);
''', ('freeze',))

case('mapped-arguments-capture-current-value-and-aliasing', r"""
var fn=Function('a','applyIntegrity','frozen','a=2;var args=arguments;applyIntegrity(args);assert.sameValue(args[0],2);a=3;assert.sameValue(args[0],frozen?2:3);args[0]=4;assert.sameValue(a,frozen?3:4);return [a,args[0],Object.getOwnPropertyDescriptor(args,"0").writable];');
var result=fn(1,m,freezing);assert.sameValue(result[0],freezing?3:4);assert.sameValue(result[1],freezing?2:4);assert.sameValue(result[2],!freezing);
""", MUTATORS)
case('sealed-mapping-survives-then-explicit-readonly-severs', r"""
var fn=Function('a','applyIntegrity','var args=arguments;applyIntegrity(args);a=5;assert.sameValue(args[0],5);Object.defineProperty(args,"0",{writable:false});a=6;assert.sameValue(args[0],5);return a;');
assert.sameValue(fn(1,m),6);
""", ('seal',))
case('strict-arguments-restricted-accessor-not-invoked', r"""
function f(a){'use strict';var args=arguments,d=Object.getOwnPropertyDescriptor(args,'callee');assert.sameValue(m(args),args);assert.sameValue(Object.isSealed(args),true);assert.sameValue(Object.isFrozen(args),freezing);var after=Object.getOwnPropertyDescriptor(args,'callee');assert.sameValue(after.get,d.get);assert.sameValue(after.set,d.set);assert.sameValue(after.configurable,false);assert.throws(TypeError,function(){return args.callee;});return args[0];}
assert.sameValue(f(7),7);
""", MUTATORS)
case('regexp-global-lastindex-respects-data-lock', r"""
var r=/a/g;r.lastIndex=1;assert.sameValue(m(r),r);var d=Object.getOwnPropertyDescriptor(r,'lastIndex');
assert.sameValue(d.value,1);assert.sameValue(d.writable,!freezing);assert.sameValue(d.enumerable,false);assert.sameValue(d.configurable,false);
if(freezing){assert.throws(TypeError,function(){r.exec('ba');});assert.sameValue(r.lastIndex,1);}else{var match=r.exec('ba');assert.sameValue(match[0],'a');assert.sameValue(match.index,1);assert.sameValue(r.lastIndex,2);}
""", MUTATORS)
case('regexp-nonglobal-exec-does-not-need-lastindex-write', r"""
var r=/a/;r.lastIndex=7;m(r);assert.sameValue(r.exec('a')[0],'a');assert.sameValue(r.lastIndex,7);assert.sameValue(Object.isSealed(r),true);assert.sameValue(Object.isFrozen(r),freezing);
""", MUTATORS)
case('regexp-lastindex-counts-in-integrity-query', r"""
var r=/a/g;Object.preventExtensions(r);assert.sameValue(m(r),!frozenQuery);Object.defineProperty(r,'lastIndex',{writable:false});assert.sameValue(m(r),true);
""", QUERIES)
case('ordinary-constructor-still-constructs', r"""
function F(value){this.x=value;}var prototype=F.prototype;m(F);prototype.y=9;var o=new F(4);assert.sameValue(o.x,4);assert.sameValue(o.y,9);assert.sameValue(Object.getPrototypeOf(o),prototype);assert.sameValue(Object.isExtensible(o),true);
""", MUTATORS)

GUARD = '''assert.sameValue(typeof Object.seal,'function','seal prerequisite');
assert.sameValue(typeof Object.freeze,'function','freeze prerequisite');
assert.sameValue(typeof Object.isSealed,'function','isSealed prerequisite');
assert.sameValue(typeof Object.isFrozen,'function','isFrozen prerequisite');
var guardSealed={x:1},guardFrozen={x:1};
assert.sameValue(Object.seal(guardSealed),guardSealed);assert.sameValue(Object.isSealed(guardSealed),true);assert.sameValue(Object.isFrozen(guardSealed),false);
assert.sameValue(Object.freeze(guardFrozen),guardFrozen);assert.sameValue(Object.isFrozen(guardFrozen),true);assert.sameValue(Object.isSealed(guardFrozen),true);
assert.sameValue(Object.isSealed({}),false);assert.sameValue(Object.isFrozen({}),false);
'''
blocks=[]
for label,method,source in CASES:
    preamble=GUARD+'var name='+json.dumps(method)+',m=Object[name],isQuery='+str(method.startswith('is')).lower()+',freezing='+str(method=='freeze').lower()+',frozenQuery='+str(method=='isFrozen').lower()+',strictMode=(function(){return this;})()===undefined;\n'
    blocks.append('// CASE: '+label+'\n'+preamble+source+'\n')
assert len({name for name,_,_ in CASES})==len(CASES)
fixture=''.join(blocks).encode()
for path in ('object-integrity.js','freeze.json'):
    if (HERE/path).exists():raise SystemExit('refusing to overwrite frozen '+path)
(HERE/'object-integrity.js').write_bytes(fixture)
record={'fixture_sha256':hashlib.sha256(fixture).hexdigest(),'source_cases':len(CASES),'mode_cases':2*len(CASES),'methods':{name:sum(m==name for _,m,_ in CASES) for name in METHODS},'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'expected_observation':{'status':'complete','phase':'runtime','error_identity':'','error_type':''}}
(HERE/'freeze.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
