# Frozen local Object integrity preparation

This independent scratch inventory contains **52 semantic groups**, expanded
across the applicable `Object.seal`, `Object.freeze`, `Object.isSealed` and
`Object.isFrozen` methods into **114 source cases / 228 strict-sloppy variants**.
Twelve separate positive/wrong assertion controls cover SameValue, intrinsic
error identity and property flags. The sources and expectations were frozen
before any adapter execution; no implementation has been exercised.

Every semantic case first checks availability of all four methods, then performs
successful seal/freeze operations and true/false integrity queries on fresh
objects. Missing methods therefore cannot make a negative TypeError assertion
pass. All semantic cases expect complete runtime execution after their assertions.
Unsupported/resource/error results stay visible and never count as semantic
successes. Strictness is an adapter mode, not a source rewrite.

The supplied published before adapter at commit
`ff48c9391af1bfd9775b77ccf83047a5abf7856c`, SHA-256
`c5cb23f3fdb36a848937fdb2a8853987a91b2ea874dfec2a15b525b94eec04b4`,
records **228 failed semantic variants**. All are runtime `Test262Error`
observations at the availability guards. All **12 assertion controls** match
their expectations. These observations are retained in `before.json` and
`before.log`; they do not validate code after the guards. The bounded run took
about 0.70 seconds. The checkpoint CI run `36521631349` was still pending when
the parent supplied its publication record; no later CI result is inferred here.

Coverage includes:

- Primitive identity, NaN and signed zero; query defaults; arbitrary receivers;
  call/apply/bind, method metadata, nonconstructability and retained aliases.
- Ordinary data/accessor descriptor flags without invoking getters, preservation
  of accessors/setters, nonenumerable keys, distinct symbols and UTF-16 keys.
- Prevent-extensions versus sealing/freezing, shallow child/prototype behavior,
  cycles, strict/sloppy writes and deletion, idempotence and compatible or
  rejected redefinition (including SameValue).
- Dense and maximum-logical-length sparse arrays, holes, inherited indices,
  accessors and writable length; sealing permits length growth/shrink across
  holes, while freezing makes length readonly.
- String wrappers and virtual UTF-16 indices, other primitive wrappers,
  ordinary functions/constructors and native callable metadata.
- Sloppy mapped arguments: sealing preserves aliases; freezing captures the
  current parameter value and severs mapping. A `Function` constructor creates
  the deliberately sloppy function in both outer modes. Strict arguments test
  that the restricted `callee` getter is not invoked by integrity operations.
- RegExp `lastIndex`: global execution respects a frozen readonly property;
  nonglobal execution does not require a `lastIndex` write.
- Predicate truth tables for extensibility, data/accessor flags, symbols and
  array length, including late nonenumerable properties.

The primary algorithms are [Object.seal](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.seal),
[Object.freeze](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.freeze),
[Object.isSealed](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.issealed),
[Object.isFrozen](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.isfrozen),
[SetIntegrityLevel](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-setintegritylevel)
and [TestIntegrityLevel](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-testintegritylevel).
This is a focused independently authored fixture set, not an imported upstream
suite or a complete conformance/security assessment. Proxy, host objects
(Window/Document/DOM), typed arrays, BigInt and cross-realm semantics are
explicitly outside this inventory; they are not represented by passing stubs.
No resource-exhaustion threshold or partial-failure oracle is asserted here.

`object-integrity.js` retains the exact `// CASE:` blocks. `matrix.json` binds
each source, mode, expected observation, expectation fingerprint and unchanged
helper bytes. `freeze.json` binds the generator and fixture. The pre-execution
`freeze-provenance.json` remains unchanged. `provenance.json` additionally binds
the before observations and the parent's supplied publication provenance.
Copied helpers are unchanged Test262 bytes at revision
`7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`; their license is `TEST262-LICENSE`.
The three copied runner modules under `tools/` are frozen to prevent later
repository edits from changing replay semantics.

To replay after a candidate binary is supplied:

```sh
timeout 45s python3 -B /tmp/eris-object-integrity-local/run.py \
  --binary /absolute/path/to/eris-js \
  --sha256 CANDIDATE_SHA256 \
  --output /tmp/eris-object-integrity-local/candidate.json
```

The runner refuses changed frozen inputs and an existing report path. Each
adapter uses a three-second wall deadline, bounded output, inherited 512 MiB
address-space and 30 CPU-second limits, with core files disabled. Supply a
45-second outer deadline as shown. Retain every observation and fingerprint;
do not regenerate fixtures or change expectations to fit candidate behavior.
Preparation and the before run touched only this `/tmp` directory. No repository
edits, builds, native/GPU runs or candidate execution were performed.
