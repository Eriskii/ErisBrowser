#!/usr/bin/env python3
"""Inert by default. Replay four unchanged local contracts only with explicit authorization."""
import argparse
from collections import Counter
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import tarfile
import time

sys.dont_write_bytecode = True
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
MANIFEST = Path('/tmp/eris-own-keys-historical-local-replay-inputs.json')
MANIFEST_SHA = '1de71b260c48f161025061de0ba4dc0f9c89edf16b1d429f5582201ff0653b05'
PREPARATION = Path('/tmp/eris-own-keys-historical-local-replay-preparation.json')
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative',
            'source', 'expected_observation', 'expectation_sha256', 'category',
            'area', 'prerequisites', 'positive', 'partner')
MAX_JSON = 32 * 1024**2

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read(path):
    p = Path(path)
    require(p.is_file() and p.stat().st_size <= MAX_JSON, f'oversized/missing JSON: {p}')
    return json.loads(p.read_bytes())

def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=True)
        f.write('\n')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def file_record(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def valid_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)

def controls(report):
    return report.get('controls', report.get('harness_controls', []))

def original(suite):
    value = read(suite['report'])
    for key in suite['pointer']:
        value = value[key]
    return value

def identities(rows):
    return [{k: r[k] for k in IDENTITY if k in r} for r in rows]

def verify_report(suite, report, binary_sha=None):
    old = original(suite)
    require(len(report['cases']) == suite['modes'], f'{suite["name"]}: case count')
    require(len(controls(report)) == suite['controls'], f'{suite["name"]}: control count')
    require(report['counts'] == dict(Counter(r['status'] for r in report['cases'])), 'raw count mismatch')
    if binary_sha is not None:
        require(report['binary_sha256'] == binary_sha, 'report binary drift')
    for key in ('fixture_sha256', 'matrix_sha256', 'runner_sha256', 'tool_hashes', 'harness', 'bounds'):
        require(report.get(key) == old.get(key), f'{suite["name"]}: original report input {key} drift')
    for label, a, b in [('cases', old['cases'], report['cases']), ('controls', controls(old), controls(report))]:
        require(identities(a) == identities(b), f'{suite["name"]}: {label} identity/expectation drift')
        require(len({r['id'] for r in b}) == len(b), 'duplicate identities')
        for row in b:
            require(hashlib.sha256(row['source'].encode()).hexdigest() == row['source_sha256'], 'source drift')
    return dict(counts=report['counts'], modes=len(report['cases']), controls=len(controls(report)),
                controls_verified=sum(bool(r.get('verified', r.get('matches_expectation', False))) for r in controls(report)),
                original_report_identity_verified=True)

def verify_static():
    require(sha(MANIFEST) == MANIFEST_SHA, 'manifest changed')
    manifest = read(MANIFEST)
    preparation = read(PREPARATION)
    require(preparation['driver_sha256'] == sha(__file__), 'driver changed')
    require(preparation['manifest_sha256'] == MANIFEST_SHA, 'preparation changed')
    for path, value in manifest['files'].items():
        p = Path(path)
        require(not p.is_symlink() and p.is_file(), f'input not a regular retained file: {p}')
        require(p.stat().st_size == value['bytes'] and sha(p) == value['sha256'], f'input changed: {p}')
    for suite in manifest['suites']:
        old = original(suite)
        verify_report(suite, old)
        require(sha(suite['runner']) == old['runner_sha256'], 'original runner hash')
        require(sha(suite['fixture']) == old['fixture_sha256'], 'original fixture hash')
        if suite['matrix']:
            matrix = read(suite['matrix'])
            require(sha(suite['matrix']) == old['matrix_sha256'], 'original matrix hash')
            actual = old['cases'] + controls(old)
            require([r['id'] for r in actual] == [r['id'] for r in matrix['cases']], 'matrix order')
            for r, m in zip(actual, matrix['cases']):
                for key in ('id', 'mode', 'source', 'source_sha256', 'case_sha256', 'expectation_sha256'):
                    require(r[key] == m[key], 'matrix identity drift')
                require(r['expected_observation'] == m['expected'], 'matrix expected drift')
    return manifest

def verify_binary(directory, expected_input, expected_binary):
    require(valid_hash(expected_input) and valid_hash(expected_binary), 'invalid binary/input digest')
    require(directory.is_dir() and not directory.is_symlink(), 'binary directory missing/symlink')
    before_files = [directory / n for n in ('inputs.json', 'default-binaries.json', 'source.tar', 'eris-js')]
    for p in before_files:
        require(not p.is_symlink() and p.is_file(), f'not a regular release file: {p}')
    inputs = read(directory / 'inputs.json')
    bins = read(directory / 'default-binaries.json')
    require(inputs['input_sha256'] == expected_input and bins['eris-js'] == expected_binary, 'release manifest identity')
    require(sha(directory / 'eris-js') == expected_binary, 'binary hash differs')
    require(0 < len(inputs['files']) <= 1024, 'input count limit')
    mapping = {}
    for item in inputs['files']:
        name = item['path']; p = Path(name)
        require(not p.is_absolute() and p.parts and all(x not in ('.', '..') for x in p.parts)
                and str(p) == name and name not in mapping and valid_hash(item['sha256']), 'input path/digest')
        mapping[name] = item['sha256']
    # Check the preserved archive, not the concurrently changing working tree.
    require((directory / 'source.tar').stat().st_size <= 64 * 1024**2, 'archive byte limit')
    with tarfile.open(directory / 'source.tar', 'r:') as archive:
        members = archive.getmembers()
        require(len(members) <= 2048, 'archive member limit')
        names = {}; total = 0
        for member in members:
            p = Path(member.name)
            require(not p.is_absolute() and p.parts and '..' not in p.parts and member.name not in names,
                    'archive name/duplicate')
            require(member.isfile() or member.isdir(), 'archive link/special member rejected')
            require(0 <= member.size <= 16 * 1024**2, 'archive member byte limit')
            total += member.size; require(total <= 64 * 1024**2, 'archive total byte limit')
            names[member.name] = member
        production_names = {n for n, m in names.items() if m.isfile() and
                            (n in ('Cargo.toml', 'Cargo.lock') or n.startswith(('src/', 'assets/', 'examples/')))}
        require(production_names == set(mapping), 'archive/input production inventory differs')
        digest = hashlib.sha256()
        for name in sorted(mapping, key=Path):
            with archive.extractfile(names[name]) as f:
                data = f.read(16 * 1024**2 + 1)
            require(hashlib.sha256(data).hexdigest() == mapping[name], f'archive source differs: {name}')
            digest.update(name.encode()); digest.update(b'\0'); digest.update(data); digest.update(b'\0')
        require(digest.hexdigest() == expected_input, 'computed production input differs')
    return {p.name: file_record(p) for p in before_files}

def compare(old, new):
    changed = []; unchanged = 0; transitions = Counter(); lost = []; gains = []
    for group, a, b in [('cases', old['cases'], new['cases']), ('controls', controls(old), controls(new))]:
        require(identities(a) == identities(b), 'comparison identity drift')
        for x, y in zip(a, b):
            if x == y:
                unchanged += 1
            else:
                changed.append(dict(group=group, id=x['id'], before=x, after=y))
            if group == 'cases':
                transitions[x['status'] + ' -> ' + y['status']] += 1
                if x['status'] == 'passed' and y['status'] != 'passed': lost.append(x['id'])
                if x['status'] != 'passed' and y['status'] == 'passed': gains.append(x['id'])
    return dict(unchanged_complete_records=unchanged, changed_complete_records=len(changed),
                transitions=dict(transitions), raw_pass_gains=gains, raw_pass_losses=lost,
                changes=changed, no_observation_normalization=True)

def verify_before_reports(directory, expected_execution, manifest):
    require(valid_hash(expected_execution), 'before execution SHA required')
    require(sha(directory / 'execution.json') == expected_execution, 'before execution receipt differs')
    receipt = read(directory / 'execution.json')
    require(receipt.get('completed') is True and receipt['phase'] == 'before', 'before did not complete')
    require(receipt['manifest_sha256'] == MANIFEST_SHA and receipt['driver_sha256'] == sha(__file__), 'before contract/driver drift')
    require(receipt['binary_sha256'] == manifest['before']['binary_sha256'], 'before binary drift')
    for name, file in receipt['captured_files'].items():
        require(Path(name).name == name and sha(directory / name) == file['sha256'], 'before captured artifact differs')
    for suite in manifest['suites']:
        verify_report(suite, read(directory / (suite['name'] + '.json')), manifest['before']['binary_sha256'])
    return receipt

def limits():
    for kind, amount in ((resource.RLIMIT_AS, 512*1024**2), (resource.RLIMIT_CPU, 30),
                         (resource.RLIMIT_FSIZE, 32*1024**2), (resource.RLIMIT_CORE, 0)):
        resource.setrlimit(kind, (amount, amount))

def interrupt(signum, frame):
    raise KeyboardInterrupt(f'signal {signum}')

def cleanup(process, state):
    # Do not poll()/wait() before group cleanup. The unreaped leader retains the PID/PGID identity.
    if not state['reap_started']:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        state['reap_started'] = True
    code = process.wait(timeout=5)
    state['reaped'] = True
    return code

def run_suite(command, out, name, env, deadline):
    record = dict(command=command, started_utc=utc(), timeout_seconds=min(180, max(0, deadline-time.monotonic())))
    state = {'reap_started': False, 'reaped': False}; process = None
    try:
        with (out/(name+'.stdout.log')).open('xb') as stdout, (out/(name+'.stderr.log')).open('xb') as stderr:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                       env=env, cwd=ROOT, close_fds=True, start_new_session=True, preexec_fn=limits)
            record['pid'] = process.pid
            end = min(deadline, time.monotonic()+180)
            while True:
                status = os.waitid(os.P_PID, process.pid, os.WEXITED|os.WNOHANG|os.WNOWAIT)
                if status is not None:
                    record['exit_observed_unreaped'] = dict(pid=status.si_pid, code=status.si_code, status=status.si_status)
                    record['returncode'] = cleanup(process, state)
                    break
                remaining = end-time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(command, record['timeout_seconds'])
                time.sleep(min(.05, remaining))
        require(record['returncode'] == 0, f'{name}: runner failed; raw logs/report retained')
    except BaseException as error:
        record['failure'] = dict(type=type(error).__name__, message=str(error))
        if process is not None and not state['reaped']:
            try:
                record['cleanup_returncode'] = cleanup(process, state)
            except BaseException as cleanup_error:
                record['cleanup_failure'] = dict(type=type(cleanup_error).__name__, message=str(cleanup_error))
        raise
    finally:
        record.update(ended_utc=utc(), leader_reaped=state['reaped'])
        write_new(out/(name+'.execution.json'), record)
    return record

def main():
    p = argparse.ArgumentParser()
    p.add_argument('--execute-authorized', action='store_true')
    p.add_argument('--phase', choices=('before', 'candidate'))
    p.add_argument('--binary-directory', type=Path)
    p.add_argument('--production-input-sha256')
    p.add_argument('--binary-sha256')
    p.add_argument('--output-directory', type=Path)
    p.add_argument('--before-directory', type=Path)
    p.add_argument('--before-execution-sha256')
    args = p.parse_args()
    manifest = verify_static()
    supplied = (args.phase, args.binary_directory, args.production_input_sha256, args.binary_sha256, args.output_directory)
    if not args.execute_authorized:
        require(not any(supplied) and not args.before_directory and not args.before_execution_sha256,
                'execution arguments require --execute-authorized')
        verify_binary(Path(manifest['before']['directory']), manifest['before']['input_sha256'], manifest['before']['binary_sha256'])
        print('Verified 4 unchanged contracts: 1,106 modes / 148 controls. No engine executed.')
        return
    require(all(supplied), 'explicit phase, binary directory, input SHA, binary SHA, output required')
    directory = args.binary_directory.resolve(); out = args.output_directory.resolve()
    require(not args.output_directory.exists() and not args.output_directory.is_symlink(), 'fresh output directory required')
    protected = [ROOT, directory] + [Path(s['runner']).parent for s in manifest['suites'] if s['name'] != 'array-descriptors']
    require(all(out != path and path not in out.parents and out not in path.parents for path in protected),
            'output overlaps protected input directory')
    before_dir = args.before_directory.resolve() if args.before_directory else None
    before_receipt = None
    if args.phase == 'before':
        require(directory == Path(manifest['before']['directory']) and args.binary_sha256 == manifest['before']['binary_sha256']
                and args.production_input_sha256 == manifest['before']['input_sha256'], 'before selection differs')
        require(before_dir is None and args.before_execution_sha256 is None, 'before cannot compare another before')
    else:
        require(before_dir is not None and out != before_dir and before_dir not in out.parents and out not in before_dir.parents,
                'candidate requires separate before directory')
        before_receipt = verify_before_reports(before_dir, args.before_execution_sha256, manifest)
    binary_files = verify_binary(directory, args.production_input_sha256, args.binary_sha256)
    out.mkdir()
    # The only imported launcher has no top-level process execution; bind its bytes in the manifest.
    spec = importlib.util.spec_from_file_location('historical_local_launcher', ROOT/'tools/run.py')
    launcher = importlib.util.module_from_spec(spec); spec.loader.exec_module(launcher)
    env = launcher.launch_environment(); env['PYTHONDONTWRITEBYTECODE'] = '1'
    for key in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME'):
        env.pop(key, None)
    record = dict(format=1, phase=args.phase, started_utc=utc(), driver_sha256=sha(__file__), manifest_sha256=MANIFEST_SHA,
                  production_input_sha256=args.production_input_sha256, binary_sha256=args.binary_sha256,
                  release_files=binary_files, before_execution_sha256=args.before_execution_sha256,
                  environment={k:env.get(k) for k in ('TZ','LANG','LC_ALL','LD_LIBRARY_PATH')},
                  bounds=manifest['bounds'], retries=False, normalization=False, baseline_written=False, completed=False)
    write_new(out/'start.json', record)
    for sig in (signal.SIGINT, signal.SIGTERM): signal.signal(sig, interrupt)
    deadline = time.monotonic()+750; summaries={}; comparisons={}
    try:
        for suite in manifest['suites']:
            require(time.monotonic() < deadline, 'whole replay deadline reached')
            verify_static()
            require(verify_binary(directory, args.production_input_sha256, args.binary_sha256) == binary_files, 'release changed')
            name=suite['name']; target=out/(name+'.json')
            require(not target.exists(), 'report must be fresh')
            command=[sys.executable, '-B', suite['runner'], '--binary', str(directory/'eris-js'),
                     '--sha256', args.binary_sha256, '--output', str(target)]
            run_suite(command, out, name, env, deadline)
            result=read(target); summaries[name]=verify_report(suite, result, args.binary_sha256)
            older=read(before_dir/(name+'.json')) if before_dir else original(suite)
            comparisons[name]=compare(older, result)
        verify_static()
        require(verify_binary(directory, args.production_input_sha256, args.binary_sha256) == binary_files, 'release changed')
        if before_dir:
            require(verify_before_reports(before_dir, args.before_execution_sha256, manifest) == before_receipt, 'before changed')
        write_new(out/'comparison.json', dict(reference='preserved aa22523 before replay' if before_dir else 'original published local reports',
                                            suites=comparisons, no_filters=True, no_normalization=True))
        require(sum(s['modes'] for s in summaries.values())==1106 and sum(s['controls'] for s in summaries.values())==148,
                'complete selected inventory mismatch')
        record.update(completed=True, all_inputs_unchanged=True, summaries=summaries)
    except BaseException as error:
        record['failure']=dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        record['ended_utc']=utc()
        record['captured_files']={x.name:file_record(x) for x in sorted(out.iterdir()) if x.is_file()}
        write_new(out/'execution.json', record)
    print('Completed exact 1,106 cases / 148 controls; execution SHA', sha(out/'execution.json'))

if __name__ == '__main__':
    main()
