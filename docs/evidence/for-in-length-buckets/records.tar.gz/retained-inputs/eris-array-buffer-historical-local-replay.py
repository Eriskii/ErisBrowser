#!/usr/bin/env python3
"""Replay preserved local contracts against one explicit frozen candidate."""
import argparse, datetime, hashlib, importlib.util, json, os, resource, signal, subprocess, sys, tarfile, time
from pathlib import Path
from collections import Counter
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
MAX_JSON=32*1024**2
IDENTITY=('id','file','mode','case_sha256','source_sha256','expected_negative','source','expected_observation','expectation_sha256','category','area','prerequisites','positive','partner','expected','oracle_kind','note')
def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read(path):
    p = Path(path)
    require(p.is_file() and p.stat().st_size <= MAX_JSON, f'oversized/missing JSON: {p}')
    return json.loads(p.read_bytes())

def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as f:
        json.dump(value, f, indent=2, ensure_ascii=True)
        f.write('\n')

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def file_record(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def valid_hash(value):
    return isinstance(value, str) and len(value) == 64 and all(c in '0123456789abcdef' for c in value)

def controls(report):
    return report.get('controls', report.get('harness_controls', []))

def original(suite):
    value = read(suite['report'])
    for key in suite['pointer']:
        value = value[key]
    return value

def identities(rows):
    return [{k: r[k] for k in IDENTITY if k in r} for r in rows]

def verify_report(suite, report, binary_sha=None):
    old = original(suite)
    require(len(report['cases']) == suite['modes'], f'{suite["name"]}: case count')
    require(len(controls(report)) == suite['controls'], f'{suite["name"]}: control count')
    require(report['counts'] == dict(Counter(r['status'] for r in report['cases'])), 'raw count mismatch')
    if binary_sha is not None:
        require(report['binary_sha256'] == binary_sha, 'report binary drift')
    for key in ('fixture_sha256', 'matrix_sha256', 'freeze_sha256', 'runner_sha256', 'tool_hashes', 'harness', 'bounds'):
        require(report.get(key) == old.get(key), f'{suite["name"]}: original report input {key} drift')
    for label, a, b in [('cases', old['cases'], report['cases']), ('controls', controls(old), controls(report))]:
        require(identities(a) == identities(b), f'{suite["name"]}: {label} identity/expectation drift')
        require(len({r['id'] for r in b}) == len(b), 'duplicate identities')
        for row in b:
            require(hashlib.sha256(row['source'].encode()).hexdigest() == row['source_sha256'], 'source drift')
    return dict(counts=report['counts'], modes=len(report['cases']), controls=len(controls(report)),
                controls_verified=sum(bool(r.get('verified', r.get('matches_expectation', False))) for r in controls(report)),
                original_report_identity_verified=True)

def verify_binary(directory, expected_input, expected_binary):
    require(valid_hash(expected_input) and valid_hash(expected_binary), 'invalid binary/input digest')
    require(directory.is_dir() and not directory.is_symlink(), 'binary directory missing/symlink')
    before_files = [directory / n for n in ('inputs.json', 'default-binaries.json', 'source.tar', 'eris-js')]
    for p in before_files:
        require(not p.is_symlink() and p.is_file(), f'not a regular release file: {p}')
    inputs = read(directory / 'inputs.json')
    bins = read(directory / 'default-binaries.json')
    require(inputs['input_sha256'] == expected_input and bins['eris-js'] == expected_binary, 'release manifest identity')
    require(sha(directory / 'eris-js') == expected_binary, 'binary hash differs')
    require(0 < len(inputs['files']) <= 1024, 'input count limit')
    mapping = {}
    for item in inputs['files']:
        name = item['path']; p = Path(name)
        require(not p.is_absolute() and p.parts and all(x not in ('.', '..') for x in p.parts)
                and str(p) == name and name not in mapping and valid_hash(item['sha256']), 'input path/digest')
        mapping[name] = item['sha256']
    # Check the preserved archive, not the concurrently changing working tree.
    require((directory / 'source.tar').stat().st_size <= 64 * 1024**2, 'archive byte limit')
    with tarfile.open(directory / 'source.tar', 'r:') as archive:
        members = archive.getmembers()
        require(len(members) <= 2048, 'archive member limit')
        names = {}; total = 0
        for member in members:
            p = Path(member.name)
            require(not p.is_absolute() and p.parts and '..' not in p.parts and member.name not in names,
                    'archive name/duplicate')
            require(member.isfile() or member.isdir(), 'archive link/special member rejected')
            require(0 <= member.size <= 16 * 1024**2, 'archive member byte limit')
            total += member.size; require(total <= 64 * 1024**2, 'archive total byte limit')
            names[member.name] = member
        production_names = {n for n, m in names.items() if m.isfile() and
                            (n in ('Cargo.toml', 'Cargo.lock') or n.startswith(('src/', 'assets/', 'examples/')))}
        require(production_names == set(mapping), 'archive/input production inventory differs')
        digest = hashlib.sha256()
        for name in sorted(mapping, key=Path):
            with archive.extractfile(names[name]) as f:
                data = f.read(16 * 1024**2 + 1)
            require(hashlib.sha256(data).hexdigest() == mapping[name], f'archive source differs: {name}')
            digest.update(name.encode()); digest.update(b'\0'); digest.update(data); digest.update(b'\0')
        require(digest.hexdigest() == expected_input, 'computed production input differs')
    return {p.name: file_record(p) for p in before_files}

def compare(old, new):
    changed = []; unchanged = 0; transitions = Counter(); lost = []; gains = []
    for group, a, b in [('cases', old['cases'], new['cases']), ('controls', controls(old), controls(new))]:
        require(identities(a) == identities(b), 'comparison identity drift')
        for x, y in zip(a, b):
            if x == y:
                unchanged += 1
            else:
                changed.append(dict(group=group, id=x['id'], before=x, after=y))
            if group == 'cases':
                transitions[x['status'] + ' -> ' + y['status']] += 1
                if x['status'] == 'passed' and y['status'] != 'passed': lost.append(x['id'])
                if x['status'] != 'passed' and y['status'] == 'passed': gains.append(x['id'])
    return dict(unchanged_complete_records=unchanged, changed_complete_records=len(changed),
                transitions=dict(transitions), raw_pass_gains=gains, raw_pass_losses=lost,
                changes=changed, no_observation_normalization=True)

def limits(cpu_seconds):
    for kind, amount in ((resource.RLIMIT_AS, 512*1024**2), (resource.RLIMIT_CPU, cpu_seconds),
                         (resource.RLIMIT_FSIZE, 32*1024**2), (resource.RLIMIT_CORE, 0)):
        resource.setrlimit(kind, (amount, amount))

def interrupt(signum, frame):
    raise KeyboardInterrupt(f'signal {signum}')

def cleanup(process, state):
    # Do not poll()/wait() before group cleanup. The unreaped leader retains the PID/PGID identity.
    if not state['reap_started']:
        try:
            os.killpg(process.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass
        state['reap_started'] = True
    code = process.wait(timeout=5)
    state['reaped'] = True
    return code

def run_suite(command, out, name, env, deadline, suite):
    record = dict(command=command, started_utc=utc(), timeout_seconds=min(suite['wall_seconds'], max(0, deadline-time.monotonic())))
    state = {'reap_started': False, 'reaped': False}; process = None
    try:
        with (out/(name+'.stdout.log')).open('xb') as stdout, (out/(name+'.stderr.log')).open('xb') as stderr:
            process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr,
                                       env=env, cwd=ROOT, close_fds=True, start_new_session=True, preexec_fn=lambda: limits(suite['cpu_seconds']))
            record['pid'] = process.pid
            end = min(deadline, time.monotonic()+suite['wall_seconds'])
            while True:
                status = os.waitid(os.P_PID, process.pid, os.WEXITED|os.WNOHANG|os.WNOWAIT)
                if status is not None:
                    record['exit_observed_unreaped'] = dict(pid=status.si_pid, code=status.si_code, status=status.si_status)
                    record['returncode'] = cleanup(process, state)
                    break
                remaining = end-time.monotonic()
                if remaining <= 0:
                    raise subprocess.TimeoutExpired(command, record['timeout_seconds'])
                time.sleep(min(.05, remaining))
        require(record['returncode'] == 0, f'{name}: runner failed; raw logs/report retained')
    except BaseException as error:
        record['failure'] = dict(type=type(error).__name__, message=str(error))
        if process is not None and not state['reaped']:
            try:
                record['cleanup_returncode'] = cleanup(process, state)
            except BaseException as cleanup_error:
                record['cleanup_failure'] = dict(type=type(cleanup_error).__name__, message=str(cleanup_error))
        raise
    finally:
        record.update(ended_utc=utc(), leader_reaped=state['reaped'])
        write_new(out/(name+'.execution.json'), record)
    return record

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--manifest',type=Path,required=True);p.add_argument('--manifest-sha256',required=True)
 p.add_argument('--candidate-directory',type=Path,required=True);p.add_argument('--production-input-sha256',required=True)
 p.add_argument('--binary-sha256',required=True);p.add_argument('--output-directory',type=Path,required=True)
 p.add_argument('--execute',action='store_true');a=p.parse_args()
 require(sha(a.manifest)==a.manifest_sha256,'manifest changed');manifest=read(a.manifest)
 def verify():
  require(sha(a.manifest)==a.manifest_sha256,'manifest changed')
  for path,row in manifest['files'].items():require(sha(path)==row['sha256'],'input drift: '+path)
  for s in manifest['suites']:verify_report(s,original(s),manifest['before']['binary_sha256'])
 verify();release=verify_binary(a.candidate_directory,a.production_input_sha256,a.binary_sha256)
 if not a.execute:print('INERT inputs verified; no execution');return
 out=a.output_directory.resolve();require(Path('/tmp') in out.parents and not out.exists(),'fresh scratch output required')
 protected=[ROOT,a.candidate_directory.resolve(),Path(manifest['before']['directory'])]
 protected += [Path(s['runner']).parent for s in manifest['suites'] if s['name']!='array-descriptors']
 require(all(out!=q and q not in out.parents and out not in q.parents for q in protected),'output overlaps protected inputs')
 out.mkdir();sys.path.insert(0,str(ROOT/'tools'));from run import launch_environment
 env=launch_environment();env['PYTHONDONTWRITEBYTECODE']='1'
 for k in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME'):env.pop(k,None)
 record=dict(format=1,phase='candidate',started_utc=utc(),driver_sha256=sha(__file__),manifest_sha256=a.manifest_sha256,production_input_sha256=a.production_input_sha256,binary_sha256=a.binary_sha256,release_files=release,completed=False)
 write_new(out/'start.json',record)
 for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,interrupt)
 deadline=time.monotonic()+1200;comparisons={};summaries={}
 try:
  for s in manifest['suites']:
   verify();require(verify_binary(a.candidate_directory,a.production_input_sha256,a.binary_sha256)==release,'release changed')
   name=s['name'];target=out/(name+'.json')
   if s['runner_kind']=='own-keys-worker':
    directory=out/name;directory.mkdir();target=directory/'report.json'
    command=[sys.executable,'-B',s['runner'],'--execute-authorized','--worker','--binary',str(a.candidate_directory/'eris-js'),'--sha256',a.binary_sha256,'--output-directory',str(directory)]
   else:command=[sys.executable,'-B',s['runner'],'--binary',str(a.candidate_directory/'eris-js'),'--sha256',a.binary_sha256,'--output',str(target)]
   run_suite(command,out,name,env,deadline,s);result=read(target)
   summaries[name]=verify_report(s,result,a.binary_sha256);comparisons[name]=compare(original(s),result)
   verify();require(verify_binary(a.candidate_directory,a.production_input_sha256,a.binary_sha256)==release,'release changed')
   print(name,summaries[name],comparisons[name]['changed_complete_records'],flush=True)
  require(sum(s['modes'] for s in summaries.values())==manifest['counts']['fixture_modes'],'mode count')
  require(sum(s['controls'] for s in summaries.values())==manifest['counts']['controls'],'control count')
  write_new(out/'comparison.json',dict(suites=comparisons,no_filters=True,no_normalization=True))
  record.update(completed=True,all_inputs_unchanged=True,summaries=summaries)
 except BaseException as error:
  record['failure']=dict(type=type(error).__name__,message=str(error));raise
 finally:
  record['ended_utc']=utc();record['captured_files']={str(x.relative_to(out)):file_record(x) for x in sorted(out.rglob('*')) if x.is_file()}
  write_new(out/'execution.json',record)
 print('Complete',manifest['counts'],sha(out/'execution.json'))

if __name__=='__main__':main()
