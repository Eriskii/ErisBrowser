# Eight-local replay preparation

Preparation only: no engine/compiler execution. Complete inert candidate and input
verification passed. The original source-only preparation failure is retained in
`preparation-attempt-1.json` and `replay.preparation-attempt-1.py.txt`: own-keys uses
its original `expected` key, while other reports use `expected_observation`.
Only the checker adapted; no source, expected outcome, old runner or cap changed.

## Exact invocation

Inert verification (no child and no output directory creation):

```sh
python3 -B /tmp/eris-for-in-length-buckets-1/replay-preparation/replay.py \
  --manifest /tmp/eris-for-in-length-buckets-1/replay-preparation/inputs.json \
  --manifest-sha256 dae884aa8019b47e41ce304c81356fefc32c34d63b08ce0d3f4c7fefc4ed4419 \
  --candidate-directory /tmp/eris-for-in-length-buckets-1/candidate \
  --production-input-sha256 d02f2e6cd1aca614a5e90db3b79059c99d7b8626e287eae86991171aed0e8a10 \
  --binary-sha256 650c0860141ec576ddbad348af53fc125b6399d9087f8ae9c9b20992aa5975e7 \
  --archive-inputs-sha256 83e52db96ab89521eb8db4cb87c4716519ba1f8dd085837cf3ad74d985e70c38 \
  --output-directory /tmp/eris-for-in-length-buckets-1/local-candidate-1
```

After root authorization, run this command **once with `--execute` appended**.
The output directory must not exist. It runs eight populations sequentially:
array-from, array-descriptors, object-integrity, for-of, own-keys, array-splice,
array-concat and array-buffer: 1,482 cases + 392 controls = 1,874 records.

Each unchanged original runner gets the same source/helper/matrix order and
expected outcomes. The outer supervisor and source archive verifier are imported
unchanged from the hash-pinned historical-local driver. Bounds stay 1,200 seconds
for the whole replay, existing suite wall times (180 seconds, own-keys 450),
existing suite CPU allowances (30 seconds, own-keys 60), 512 MiB address space,
32 MiB output-file cap and three seconds per engine case. SIGINT/SIGTERM route
through original cleanup; exited leader remains unreaped until group signal.
No retry, expectation filter, baseline write or source mismatch exception exists.

## Candidate/archive contract

- `inputs.json`: unchanged legacy `{input_sha256,files:[{path,sha256}]}` schema.
  Exact Cargo.toml/Cargo.lock/src/assets/examples production subset and digest;
  digest sorts with `key=Path` and hashes path + NUL + bytes + NUL.
- `default-binaries.json`: ordinary binary-name to SHA256 object; `eris-js` is
  checked against the explicit command-line SHA and actual executable bytes.
- `source.tar`: regular files/directories only, no links or specials, at most
  2,048 members, 16 MiB per member and 64 MiB archive/total file bytes. The old
  production verifier remains unchanged and verifies its exact subset.
- `archive-inputs.json`: `{files:[{path,sha256}]}` for **every regular member**,
  pinned by its explicit SHA. The additional verifier requires exact names and
  each byte hash, including crates and archived verification sources. Current
  candidate has 407 regular members. Nothing is extracted or executed.
- Optional provenance/verification-inputs/pixel-inputs receipts are byte-bound
  across replay when present; their schema is not silently substituted for the
  legacy production digest or complete archive inventory.

The wrapper does not require live runtime bytes to match archived candidate
sources: the preserved source archive is the authority. Current tooling, original
runners/assets and all 34 existing baseline files remain hash-locked throughout.
This is intentional archive verification, not a source mismatch exemption.

## Outputs and comparison

Each suite has raw stdout/stderr, an owned-process execution receipt, its complete
raw report and a complete-row comparison. Own-keys keeps report.json in its own
subdirectory as required by the unchanged worker interface. Aggregate comparison
and execution receipts retain every changed row, raw pass gains/losses, control
observations and unchanged counts. Summary fields are recomputed, including exact
partner and protocol prerequisite gating. Existing expected-resource cases remain
visible; no outcome is forced by the wrapper.

The comparison reference is the latest completed ArrayBuffer candidate-2 local
observations, checked equal to **current published complete case/control rows**.
It does not credit historical pre-ArrayBuffer gains again. Failures preserve
available raw artifacts and post-input checks. Process metadata/timing are retained
in the raw report/receipt; case/control observation fields are never normalized.
