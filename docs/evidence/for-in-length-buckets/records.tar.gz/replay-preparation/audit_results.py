#!/usr/bin/env python3
"""Independent read/hash/JSON audit only; no engine or replay imports."""
import collections
import hashlib
import json
from pathlib import Path
P = Path('/tmp/eris-for-in-length-buckets-1/replay-preparation')
OUT = Path('/tmp/eris-for-in-length-buckets-1/locals-1')
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
bind = lambda p: dict(path=str(p), bytes=Path(p).stat().st_size, sha256=sha(p))

def require(value, message):
    if not value:
        raise ValueError(message)

require(sha(P/'inputs.json') == 'dae884aa8019b47e41ce304c81356fefc32c34d63b08ce0d3f4c7fefc4ed4419', 'manifest hash')
require(sha(OUT/'execution.json') == '5c99478340468b58623935b57f529a9fa46fdfd0a4388fee87987e8e24bd2727', 'completed receipt hash')
man = read(P/'inputs.json'); execution = read(OUT/'execution.json'); aggregate = read(OUT/'comparison.json')
require(execution['completed'] and execution['all_inputs_unchanged'] and execution['post_input_checks_passed'], 'completion')
require(not any(k in execution for k in ('failure','post_input_failure','cleanup_failure')), 'execution failure')
require(execution['retries'] is False and execution['baseline_written'] is False, 'retries or baseline writes')
for path,row in man['files'].items():
    require(Path(path).stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'bound input drift: '+path)
for name,row in execution['captured_files'].items():
    path=OUT/name
    require(path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], 'captured artifact drift: '+name)
for row in execution['release_files'].values():
    require(bind(row['path']) == row, 'release artifact drift')
controls = lambda d:d.get('controls',d.get('harness_controls',[]))
all_changes=[]; suites=[]; all_resources=[]
for suite in man['suites']:
    name=suite['name']
    before=read(suite['report'])
    for key in suite['pointer']:before=before[key]
    report_path=OUT/('own-keys/report.json' if name=='own-keys' else name+'.json')
    after=read(report_path)
    require(after['binary_sha256']==execution['binary_sha256'], 'report binary')
    require(after['counts']==dict(collections.Counter(r['status'] for r in after['cases'])), 'raw counts')
    require(len(after['cases'])==suite['modes'] and len(controls(after))==suite['controls'], 'population count')
    for key in ('fixture_sha256','matrix_sha256','freeze_sha256','runner_sha256','tool_hashes','harness','bounds'):
        require(before.get(key)==after.get(key), 'report identity field '+key)
    c=[]
    for group,a,b in [('cases',before['cases'],after['cases']),('controls',controls(before),controls(after))]:
        require([r['id'] for r in a]==[r['id'] for r in b], 'row order')
        for x,y in zip(a,b):
            require(hashlib.sha256(y['source'].encode()).hexdigest()==y['source_sha256'], 'source hash')
            for k in ('id','file','mode','case_sha256','source_sha256','expected_negative','source','expected_observation','expected','expectation_sha256','category','area','prerequisites','positive','partner','oracle_kind','note'):
                require(x.get(k)==y.get(k) and (k in x)==(k in y), 'row identity '+y['id']+' '+k)
            expected=y.get('expected_observation',y.get('expected'))
            require(y['matches_expectation']==all(y.get('observation',{}).get(k)==v for k,v in expected.items()), 'expected match')
            if x!=y:c.append(dict(group=group,id=x['id'],before=x,after=y))
            if group=='cases' and expected.get('status')=='resource':
                require(x==y and y['matches_expectation'] and y['status']=='resource', 'terminal policy changed')
                all_resources.append(dict(suite=name,id=y['id'],observation=y['observation']))
    disk=read(OUT/(name+'.comparison.json'))
    require(disk==aggregate['suites'][name] and disk['changes']==c, 'full comparison rows')
    require(disk['changed_complete_records']==len(c) and disk['unchanged_complete_records']==suite['modes']+suite['controls']-len(c), 'comparison counts')
    by_id={r['id']:r for r in after['cases']+controls(after)}
    verified=0
    for row in controls(after):
        if 'verified' in row:
            require(row['verified']==(row['matches_expectation'] and by_id[row['partner']]['matches_expectation']), 'partner gating')
        verified+=bool(row.get('verified',row['matches_expectation']))
    require(verified==suite['controls'], 'control health')
    receipt=read(OUT/(name+'.execution.json'))
    require(receipt['returncode']==0 and receipt['leader_reaped'], 'runner failure/reap')
    require(not any(k in receipt for k in ('failure','cleanup_failure')), 'runner cleanup failure')
    observed=receipt['exit_observed_unreaped']
    require(observed['pid']==receipt['pid'] and observed['code']==1 and observed['status']==0, 'unreaped exit')
    require('--sha256' in receipt['command'] and execution['binary_sha256'] in receipt['command'], 'command binary')
    require((OUT/(name+'.stderr.log')).read_bytes()==b'', 'runner stderr')
    require((OUT/(name+'.stdout.log')).stat().st_size>0, 'missing runner stdout')
    all_changes.extend(dict(suite=name,**row) for row in c)
    suites.append(dict(name=name,cases=suite['modes'],controls=suite['controls'],controls_verified=verified,
        counts=after['counts'],changed_complete_rows=len(c),report=bind(report_path),
        process_receipt=bind(OUT/(name+'.execution.json')),stdout=bind(OUT/(name+'.stdout.log')),stderr=bind(OUT/(name+'.stderr.log'))))
require(len(suites)==8 and sum(s['cases'] for s in suites)==1482 and sum(s['controls'] for s in suites)==392, 'complete totals')
require([(x['suite'],x['group'],x['id']) for x in all_changes]==[
 ('array-buffer','cases','getter-method-flags-and-nonconstructability#sloppy'),
 ('array-buffer','cases','getter-method-flags-and-nonconstructability#strict')], 'exact changed inventory')
for row in all_changes:
    require(row['before']['status']=='resource' and row['after']['status']=='passed'
            and row['after']['matches_expectation'] and row['after']['verified_with_protocol_prerequisite'], 'ordinary gain')
ab=read(OUT/'array-buffer.json')
require(ab['counts']==dict(passed=90,failed=8,unsupported=2,resource=4), 'ArrayBuffer counts')
require(ab['controls_verified']==76 and ab['fixture_expectations_matched']==94
        and ab['fixture_expectations_verified']==94, 'ArrayBuffer expectations')
terminal=[x for x in all_resources if x['suite']=='array-buffer']
require(len(terminal)==4, 'ArrayBuffer terminal resource population')
result=dict(schema=1,scope='Independent completed eight-local replay consistency audit',
    engine_execution=False,rerun=False,source_oracle_quota_baseline_edits=False,findings=[],
    inputs=bind(P/'inputs.json'),driver=bind(P/'replay.py'),execution=bind(OUT/'execution.json'),
    aggregate_comparison=bind(OUT/'comparison.json'),audit_source=bind(__file__),
    totals=dict(suites=8,cases=1482,controls=392,controls_verified=392,complete_rows=1874,
                unchanged_complete_rows=1872,changed_complete_rows=2,raw_pass_gains=2,raw_pass_losses=0,
                changed_controls=0,changed_other_observations=0),
    checked=dict(bound_inputs=367,retained_artifact_bindings=len(execution['captured_files']),
                 candidate_release_bindings=len(execution['release_files']),
                 full_case_control_order_source_and_expectation_identity=True,
                 eight_unreaped_exit_then_leader_reap_receipts=True,all_runner_stderr_empty=True,
                 all_expected_resource_rows_across_eight_suites_unchanged=len(all_resources)),
    suites=suites,exact_changes=[dict(suite=x['suite'],id=x['id'],before=x['before']['observation'],after=x['after']['observation']) for x in all_changes],
    array_buffer=dict(counts=ab['counts'],expectations_matched=94,expectations_total=104,controls_verified=76,
                      terminal_resource_rows=terminal,missing_prerequisite_and_crossrealm_rows_unchanged=True),
    qualification='Process receipts establish owned leader cleanup via the reviewed group-signal-before-reap path; no independent escaped-descendant census or private Rust cutpoint execution is claimed by this read-only audit.')
with (P/'result-review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(sha(P/'result-review.json'),result['totals'], 'terminal policy rows',len(all_resources))
