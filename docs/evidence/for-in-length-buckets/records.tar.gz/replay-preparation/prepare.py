#!/usr/bin/env python3
"""Data-only preparation; never calls a runner, engine, compiler or subprocess."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-array-buffer-historical-local-replay-inputs-2.json')
HIST = Path('/tmp/eris-array-buffer-historical-local-candidate-2')
LOCAL = Path('/tmp/eris-array-buffer-local')
BUFFER = Path('/tmp/eris-array-buffer-local-candidate-2')
BEFORE_BINARY = '57eae22986e13bd11fe031716a9bd3554b74b31dc8a86c717fea9176ef06c18b'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
read = lambda p: json.loads(Path(p).read_bytes())
record = lambda p: dict(bytes=Path(p).stat().st_size, sha256=sha(p))

def require(value, message):
    if not value:
        raise ValueError(message)

spec = importlib.util.spec_from_file_location('new_local_replay', HERE/'replay.py')
replay = importlib.util.module_from_spec(spec)
spec.loader.exec_module(replay)
old = read(OLD)
files = dict(old['files'])
for p, row in files.items():
    require(record(p) == row, 'previous locked input changed: ' + p)
files[str(OLD)] = record(OLD)
for directory in (HIST, BUFFER):
    receipt = read(directory/'execution.json')
    require(receipt['binary_sha256'] == BEFORE_BINARY and receipt['all_inputs_unchanged'], 'before receipt')
    require(receipt.get('completed', receipt.get('returncode') == 0), 'incomplete before receipt')
    files[str(directory/'execution.json')] = record(directory/'execution.json')
    captures = receipt.get('captured_files', receipt.get('artifacts', {}))
    for relative, row in captures.items():
        p = directory/relative
        require(sha(p) == row['sha256'], 'before artifact changed: ' + str(p))
        files[str(p)] = record(p)
suites = old['suites']
for suite in suites:
    suite['report'] = str(HIST/('own-keys/report.json' if suite['name'] == 'own-keys' else suite['name']+'.json'))
    suite['pointer'] = []
    if 'published_report' not in suite:
        suite['published_report'] = dict(path=str(ROOT/'tests/conformance'/(suite['name']+'-final.json')), pointer=[])
suites.append(dict(name='array-buffer', runner=str(LOCAL/'run.py'), runner_kind='standard',
    fixture=str(LOCAL/'array-buffer.js'), matrix=str(LOCAL/'matrix.json'),
    report=str(BUFFER/'report.json'), pointer=[], modes=104, controls=76,
    cpu_seconds=30, wall_seconds=180,
    published_report=dict(path=str(ROOT/'tests/conformance/array-buffer-final.json'),pointer=[])))
for p in LOCAL.rglob('*'):
    if p.is_file() and '__pycache__' not in p.parts:
        files[str(p)] = record(p)
for suite in suites:
    before = replay.old.original(suite)
    replay.old.verify_report(suite, before, BEFORE_BINARY)
    replay.verify_health(before)
    public = read(suite['published_report']['path'])
    for part in suite['published_report']['pointer']:
        public = public[part]
    require(before['cases'] == public['cases'] and replay.old.controls(before) == replay.old.controls(public),
            'current public observations differ: ' + suite['name'])
    for p in (suite['report'], suite['published_report']['path'], suite['runner'], suite['fixture']):
        files[str(p)] = record(p)
    if suite['matrix']:
        files[suite['matrix']] = record(suite['matrix'])
        require(sha(suite['matrix']) == before['matrix_sha256'], 'matrix hash')
    require(sha(suite['runner']) == before['runner_sha256'], 'runner hash')
for p in [HERE/'replay.py', HERE/'prepare.py', replay.LEGACY, ROOT/'tools/run.py',
          ROOT/'tools/html_conformance.py', ROOT/'tools/test262_conformance.py', ROOT/'tools/import_test262.py']:
    files[str(p)] = record(p)
# These files are not changed or projected by local replay; locking also protects
# them against unrelated mutation while observations are collected.
baselines = sorted((ROOT/'tests/conformance').glob('test262*-current.json'))
# string-json's established mapping predates the profile-specific spelling.
baselines.append(ROOT/'tests/conformance/test262-current.json') if ROOT/'tests/conformance/test262-current.json' not in baselines else None
require(len(baselines) == 34, 'current baseline count')
for p in baselines:
    files[str(p)] = record(p)
data = dict(format=1, before=dict(directory='/tmp/eris-array-buffer-candidate-2',
    binary_sha256=BEFORE_BINARY, production_input_sha256='7cc8ea1321f029c705898aa7dd480e7a79bb878f454c342aeacfcba3f84274bf',
    observations='Latest completed ArrayBuffer-era local reports; exact current public case/control rows'),
    counts=dict(suites=8, fixture_modes=1482, controls=392), suites=suites,
    files=dict(sorted(files.items())), baselines_locked=34,
    reused_unchanged_helpers=['verify_binary','verify_report','compare','run_suite','cleanup','limits'],
    notes=['No engine or compiler execution during preparation.',
        'Eight original runners, sources, matrices, helper files and expectations remain byte-identical.',
        'Every full changed case/control row is retained; no observation normalization or baseline writes.',
        'New complete archive inventory is additional to the unchanged legacy production digest verifier.',
        'All original per-runner wall/CPU/address-space/output limits are retained; total driver wall cap stays 1200 seconds.',
        'No inference from old BEFORE results; comparisons use the latest completed reports and public rows.'])
require(sum(s['modes'] for s in suites) == 1482 and sum(s['controls'] for s in suites) == 392, 'total rows')
with (HERE/'inputs.json').open('x') as handle:
    json.dump(data, handle, indent=2); handle.write('\n')
print(HERE/'inputs.json', sha(HERE/'inputs.json'), data['counts'], 'bound files', len(files))
