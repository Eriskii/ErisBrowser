#!/usr/bin/env python3
"""Read-only complete observation/gate audit; no runner imports or child executions."""
from pathlib import Path
from collections import Counter
import hashlib,json,tarfile
PREP=Path('/tmp/eris-for-in-length-buckets-1/formal-preparation')
OUT=Path('/tmp/eris-for-in-length-buckets-1/formal-replay-1')

def sha(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def bind(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=sha(d))
def verify(row):
 p=Path(row['path']);assert p.is_file() and not p.is_symlink() and bind(p)==row,p
manifest=read(PREP/'inputs.json');summary=read(OUT/'profiles-comparison.json');start=read(OUT/'start.json')
assert bind(PREP/'inputs.json')['sha256']=='97fd70e92a98361a02689a09bad71dc178d4181eb1914095da1457e119217981'
assert bind(PREP/'replay.py')['sha256']=='b2de4293b854359179931f5a793093b4b3432fe5f410c262db7ec084a9d437c2'
assert summary['complete'] and summary['all_inputs_unchanged']
assert summary['infrastructure_failure'] is None and summary['postcheck_failure'] is None
assert summary['baselines_written'] is False and summary['retries'] is False
for key in ('manifest','driver'):
 verify(summary[key]);assert start[key]==summary[key]
for row in start['candidate'].values():verify(row)
for row in manifest['static_files']+list(manifest['helpers'].values())+manifest['prior_provenance']+[manifest['contracts'],manifest['candidate_verifier']]:verify(row)
contracts=read(manifest['contracts']['path'])['profiles']
assert set(contracts)=={r['name'] for r in manifest['profiles']}
assert len(manifest['profiles'])==42 and [r['profile'] for r in summary['profiles']]==[r['name'] for r in manifest['profiles']]
allcases=Counter();allcontrols=Counter();unverified=Counter();exitcodes=Counter();exceptions=[];proofs=[];gates=0
identities=('id','file','mode','case_sha256','source_sha256','expected_negative')
for profile,result in zip(manifest['profiles'],summary['profiles']):
 name=profile['name'];contract=contracts[name]
 assert result==read(OUT/(name+'.comparison.json'))
 assert profile['before_report']==result['before'];verify(result['before']);verify(result['after']);verify(result['execution'])
 before=read(result['before']['path']);after=read(result['after']['path']);ex=read(result['execution']['path'])
 assert before['cases']==after['cases'],name
 assert before['harness_preflight']==after['harness_preflight'],name
 assert after['binary_sha256']==summary['binary_sha256']==manifest['candidate_binary_sha256']
 assert before['binary_sha256']=='57eae22986e13bd11fe031716a9bd3554b74b31dc8a86c717fea9176ef06c18b'
 for k in ('revision','corpus_manifest_sha256','runner_policy_sha256','runner_policy','source_files','source_tests','negative_source_tests','fixture_files','mode_cases','counts','harness_preflight_passed'):
  assert before[k]==after[k],(name,k)
 assert after['runner_policy_sha256']==contract['runner_policy_sha256'] and after['runner_policy']==contract['policy']
 assert after['corpus_manifest_sha256']==contract['manifest_sha256'] and after['revision']==contract['revision']
 case_ids=[r['id'] for r in after['cases']];assert len(case_ids)==len(set(case_ids))==len(contract['cases'])
 assert set(case_ids)==set(contract['cases'])
 for row in after['cases']:
  c=contract['cases'][row['id']]
  for k in ('file','mode','case_sha256','source_sha256'):assert row[k]==c[k],(name,row['id'],k)
  assert row['expected_negative']==c['metadata']['negative']
  if c['unsupported_reason']:assert row['status']=='unsupported' and row['reason']==c['unsupported_reason']
 controls=after['harness_preflight'];assert len(controls)==len(contract['preflights'])
 for row,c in zip(controls,contract['preflights']):
  assert row['name']==c['name'] and row['expected']==c['expected']
  for k in ('id','mode','case_sha256','source_sha256'):assert row['result'][k]==c[k],(name,row['name'],k)
  assert row['result']['expected_negative']==c['metadata']['negative']
 assert result['complete_changed_case_records']==[] and result['complete_changed_control_records']==[]
 assert result['unchanged_case_records']==len(after['cases'])==profile['cases']==result['cases']
 assert result['unchanged_control_records']==len(controls)==profile['controls']==result['controls']
 counts=Counter(r['status'] for r in after['cases']);ccounts=Counter(r['result']['status'] for r in controls)
 assert dict(counts)==after['counts']==result['after_counts']==result['before_counts']
 assert result['controls_verified']==sum(bool(r['verified']) for r in controls)
 assert after['harness_preflight_passed']==all(r['verified'] for r in controls)
 allcases.update(counts);allcontrols.update(ccounts)
 bad=sum(not r['verified'] for r in controls)
 if bad:unverified[name]=bad
 for r in profile['files']:verify(r)
 actual={str(p) for p in Path(profile['corpus']).rglob('*') if p.is_file()}
 assert actual=={r['path'] for r in profile['files']}
 healthy=after['harness_preflight_passed'] and not any(counts[k] for k in ('adapter-error','timeout','resource'))
 gate=result['current_baseline_gate']
 if profile['baseline']:
  verify(profile['baseline']);baseline=read(profile['baseline']['path'])
  assert gate['baseline']==profile['baseline']
  for k in ('revision','corpus_manifest_sha256','runner_policy_sha256'):assert baseline[k]==after[k]
  current={r['id']:r for r in after['cases']};assert baseline['cases'].keys()==current.keys()
  losses=[];gains=[]
  for key,old in baseline['cases'].items():
   new=current[key];assert old['case_sha256']==new['case_sha256']
   if old['status']=='passed' and new['status']!='passed':losses.append(key)
   if old['status']!='passed' and new['status']=='passed':gains.append(key)
  assert gate==dict(baseline=profile['baseline'],passed=healthy and not losses,healthy=healthy,regressions=losses,improvements=gains)
  assert gate['passed'];gates+=1
 else:assert gate is None
 assert ex['leader_reaped'] is True and ex['reap_started'] is True
 assert not ex.get('failure') and not ex.get('cleanup_failure')
 assert ex['exit_observed_without_reaping']==dict(si_pid=ex['pid'],si_code=1,si_status=ex['returncode'])
 assert 0<=ex['elapsed_seconds']<ex['timeout_seconds']<=600
 assert ex['command'][1:]==[str(Path(manifest['repository'])/'tools/test262_conformance.py'),'--profile',name,'--binary',str(Path(manifest['candidate_directory'])/'eris-js'),'--output',str(OUT/(name+'.json')),'--jobs','4','--timeout','3']
 for key in ('stdout_log','stderr_log','json'):verify(ex[key])
 assert Path(ex['stderr_log']['path']).read_bytes()==b''
 expected_exit=0 if healthy and counts.get('passed',0)==len(after['cases']) else 1
 assert ex['returncode']==expected_exit
 exitcodes[ex['returncode']]+=1
 proofs.append(dict(profile=name,report_sha256=result['after']['sha256'],execution_sha256=result['execution']['sha256'],comparison_sha256=bind(OUT/(name+'.comparison.json'))['sha256']))
 if counts['resource'] or counts['adapter-error'] or counts['timeout'] or bad:
  exceptions.append(dict(profile=name,counts=dict(counts),controls_unverified=bad,baseline_gate=gate))
assert allcases.total()==18563 and allcontrols.total()==4252 and gates==34
assert summary['counts']==dict(profiles=42,cases=18563,controls=4252,improvements=0,regressions=0,other_changes=0,control_changes=0,baseline_gates_checked=34,baseline_gates_passed=34)
candidate=Path(manifest['candidate_directory']);inventory=read(candidate/'archive-inputs.json')['files'];mapping={r['path']:r['sha256'] for r in inventory};assert len(mapping)==len(inventory)==407
inputs=read(candidate/'inputs.json');production={r['path']:r['sha256'] for r in inputs['files']}
with tarfile.open(candidate/'source.tar','r:') as archive:
 members=archive.getmembers();assert len({m.name for m in members})==len(members)
 regular={m.name:m for m in members if m.isfile()};assert regular.keys()==mapping.keys()
 assert all(m.isfile() or m.isdir() for m in members)
 data={}
 for name,m in regular.items():
  assert not Path(name).is_absolute() and '..' not in Path(name).parts
  d=archive.extractfile(m).read();assert sha(d)==mapping[name];data[name]=d
 digest=hashlib.sha256()
 for name in sorted(production,key=Path):
  assert sha(data[name])==production[name]
  digest.update(name.encode());digest.update(b'\0');digest.update(data[name]);digest.update(b'\0')
 assert digest.hexdigest()==inputs['input_sha256']==summary['production_input_sha256']==manifest['candidate_input_sha256']
# No profile omitted, duplicated, rerun or represented only by aggregate counts.
expected={'start.json','profiles-comparison.json'}|{p['name']+'.'+s for p in manifest['profiles'] for s in ['json','stdout.log','stderr.log','execution.json','comparison.json']}
assert {p.name for p in OUT.iterdir() if p.is_file()}==expected
record=dict(schema=1,status='clear; complete raw observations and all34 current gates independently verified',scope='Read-only completed-result audit; no runner, engine, compiler, GPU or subprocess execution',
 bindings=dict(summary=bind(OUT/'profiles-comparison.json'),start=bind(OUT/'start.json'),manifest=bind(PREP/'inputs.json'),driver=bind(PREP/'replay.py'),contracts=bind(PREP/'contracts.json'),candidate= start['candidate']),
 counts=dict(profiles=42,case_rows=18563,control_rows=4252,current_gates=34,corpus_files=10022,archive_members=407,source_identity_rows=len(production)),
 case_statuses=dict(allcases),control_statuses=dict(allcontrols),unverified_controls=dict(unverified),retained_nonhealthy_profiles=exceptions,
 process_results=dict(leaders_reaped=42,exit_codes={str(k):v for k,v in exitcodes.items()},empty_stderr_logs=42,cleanup_failures=0,infrastructure_failures=0),
 observation_comparison='Every full case and harness-control row equals its pinned latest ArrayBuffer candidate2 observation, preserving identities, statuses, errors, phases, unsupported reasons, stderr and guarded control outcomes. Zero gains/losses/other/control changes.',
 gate_review='Independently rebuilt each baseline projection; exact inventory/case/policy hashes, pass preservation and unchanged BAD_RUN_STATUSES/control-health test agree with all34 successful recorded gates; baseline bytes remain unchanged.',
 profile_proof_ledger_sha256=sha(json.dumps(proofs,sort_keys=True,separators=(',',':')).encode()),
 preserved_limits='Existing3-second case timeout,4 jobs, per-profile600-second outer deadline,1GiB address space,300 CPU seconds,32MiB file caps and5-second reap limit; no policy normalization, retry or baseline write.',
 limitations=['42 profile runner leaders were observed exited with waitid WNOWAIT and reaped after owned-group cleanup under the frozen helper; this is not an independent kernel-wide descendant census.','Returncode1 is expected without --baseline when a raw profile contains unsupported/failed/resource rows; these raw outcomes are preserved, while34 offline gate projections pass.','No general conformance or performance claim; existing failing/excluded/terminal observations remain visible.'],findings=[])
p=PREP/'result-review.json';p.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(review=bind(p),case_statuses=dict(allcases),control_statuses=dict(allcontrols),unverified_controls=dict(unverified),exit_codes=dict(exitcodes),retained_nonhealthy_profiles=exceptions),indent=2))
