#!/usr/bin/env python3
"""Data-only manifest preparation; all run_case calls are replaced by static capture."""
import hashlib,importlib.util,json,re,sys
from pathlib import Path
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUT=Path('/tmp/eris-for-in-length-buckets-1/formal-preparation')
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def bind(p):
 p=Path(p);return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def read(p):return json.loads(Path(p).read_bytes())
def save(p,d):
 with Path(p).open('x') as f:json.dump(d,f,indent=2);f.write('\n')
def load(p,name):
 s=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
old_path=Path('/tmp/eris-array-buffer-historical-replay.py')
old=load(old_path,'prior_replay')
contract_path=Path('/tmp/eris-array-buffer-contracts-before.json')
new_path=Path('/tmp/eris-array-buffer-tooling-stage/source-mode-helper-ledger.json')
contracts=read(contract_path)['profiles']|read(new_path)['profiles']
assert set(contracts)==set(runner.PROFILES) and len(contracts)==42
history_path=Path('/tmp/eris-array-buffer-candidate-2/profiles-comparison.json')
history=read(history_path);assert history['complete'] and history['counts']['profiles']==41
before={x['profile']:(Path(x['report_path']),x['report_sha256']) for x in history['profiles']}
p=Path('/tmp/eris-array-buffer-formal-candidate-2/array-buffer.json')
assert p.read_bytes()==(ROOT/'tests/conformance/test262-array-buffer-final.json').read_bytes()
before['array-buffer']=(p,sha(p));assert set(before)==set(contracts)
baselines={}
for line in (ROOT/'.github/workflows/check.yml').read_text().splitlines():
 if 'python3 tools/test262_conformance.py ' not in line:continue
 match=re.search(r'--baseline (\S+)',line)
 if not match:continue
 profile=re.search(r'--profile (\S+)',line);name=profile.group(1) if profile else 'string-json'
 assert name not in baselines
 path=ROOT/match.group(1);baselines[name]=bind(path)
assert len(baselines)==34
profiles=[]
for name in sorted(contracts):
 path,expected=before[name];assert sha(path)==expected
 report=read(path)
 assert report['binary_sha256']=='57eae22986e13bd11fe031716a9bd3554b74b31dc8a86c717fea9176ef06c18b'
 contract=contracts[name]
 old.verify_static_contract(runner,ROOT,name,contract,report)
 old.compare(name,report,report)
 assert report['runner_policy_sha256']==contract['runner_policy_sha256'] and report['runner_policy']==contract['policy']
 corpus=ROOT/'tests/upstream'/runner.corpus_name(name)
 files=[bind(p) for p in sorted(corpus.rglob('*')) if p.is_file()]
 assert all(not Path(x['path']).is_symlink() for x in files)
 profiles.append(dict(name=name,before_report=bind(path),cases=len(report['cases']),controls=len(report['harness_preflight']),
  counts=report['counts'],controls_verified=sum(x['verified'] for x in report['harness_preflight']),
  corpus=str(corpus),files=files,baseline=baselines.get(name)))
assert sum(p['cases'] for p in profiles)==18563 and sum(p['controls'] for p in profiles)==4252
save(OUT/'contracts.json',dict(schema=1,profiles=contracts,origins=[bind(contract_path),bind(new_path)]))
for source,name in [(old_path,'historical-helper.py'),(Path('/tmp/eris-array-buffer-formal-before-driver.py'),'supervision-helper.py')]:
 with (OUT/name).open('xb') as f:f.write(source.read_bytes())
manifest=dict(schema=1,preparation_only=True,repository=str(ROOT),profiles=profiles,
 counts=dict(profiles=42,cases=18563,controls=4252,baseline_gates=34,corpus_files=sum(len(p['files']) for p in profiles)),
 contracts=bind(OUT/'contracts.json'),helpers=dict(historical=bind(OUT/'historical-helper.py'),supervision=bind(OUT/'supervision-helper.py')),
 helper_origins=[bind(old_path),bind('/tmp/eris-array-buffer-formal-before-driver.py')],
 prior_provenance=[bind(history_path),bind('/tmp/eris-array-buffer-formal-candidate-2/execution.json'),bind(ROOT/'tests/conformance/test262-array-buffer-final.json')],
 static_files=[bind(ROOT/p) for p in ['tools/test262_conformance.py','tools/import_test262.py','tools/html_conformance.py','tools/run.py','.github/workflows/check.yml']],
 candidate_directory='/tmp/eris-for-in-length-buckets-1/candidate',
 candidate_input_sha256='d02f2e6cd1aca614a5e90db3b79059c99d7b8626e287eae86991171aed0e8a10',
 candidate_archive_inventory=bind('/tmp/eris-for-in-length-buckets-1/candidate/archive-inputs.json'),
 candidate_inputs=bind('/tmp/eris-for-in-length-buckets-1/candidate/inputs.json'),
 candidate_supplemental=bind('/tmp/eris-for-in-length-buckets-1/candidate/verification-inputs.json'),
 limits=dict(profile_seconds=600,case_seconds=3,jobs=4,address_space=1024**3,cpu_seconds=300,file_bytes=32*1024**2,reap_seconds=5),
 notes=['All42 profiles run once; no filter, retry or new baseline.','Exact current34 baseline bytes retained; existing runner comparator evaluates new reports offline.','Complete raw reports retained, plus complete changed before/after rows; old failed/unsupported/resource controls remain observations.','Zero case execution during preparation: generated controls captured by replacing run_case.'])
save(OUT/'inputs.json',manifest)
print(json.dumps(dict(manifest=bind(OUT/'inputs.json'),counts=manifest['counts'])))
