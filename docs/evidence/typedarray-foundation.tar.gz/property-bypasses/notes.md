# TypedArray bypass integration

Four authorized production paths only; no fixture, baseline, compiler, test,
formatter, importer, engine or renderer work in this subtask. Root owns central
property routers and final integration. Beforeimages are retained under before/.

`array_splice.rs` retains the ordinary `splice_own` body and its exact charges.
The public `splice_property` is used only as presence by splice/concat and now
selects a no-byte-read TypedArray descriptor. `splice_get` selects scalar reads.
At every prototype hop a handled numeric absence returns immediately.

Splice Set now carries the reached target and original Receiver through the
same paid walk. Same-receiver numeric Set finishes in the core helper, including
conversion on invalid indices. A distinct receiver with an invalid canonical
index returns success without conversion; a valid one obtains the writable
indexed descriptor, then defines on the original receiver. Ordinary accessor
calls still receive that receiver. The existing own-budget/definition tail is
unchanged. Delete bypasses configurable=true for genuine live indices and uses
the exotic Boolean result instead.

Splice and Array.from dispatch branded definitions before any cached ordinary
insertion budget/table state. Numeric conversion may resize/detach a buffer or
append more view records; the core then refreshes backing bounds. An ordinary
key falls through to the existing definition path. No definition callback is
introduced between an ordinary insertion snapshot and its operation.

`iterators.rs` checks the saved iterated object's TypedArray brand before the
observable generic length Get. This includes borrowed Array iterator methods.
The already-done return remains before that check. A detached/OOB failure occurs
before state mutation, so it does not close or exhaust the iterator; a later
regrow can resume an OOB view. Numeric element Get remains in the central paid
reader. Generic Array iterators keep their original observable length behavior.

`object_integrity.rs` includes live dense TypedArray indices without a virtual
own length. Existing key preflight accounts for key storage, loop/sort work and
numeric string creation; backing limits keep those indices below2^32. Genuine
numeric keys cannot have sidecar overrides. Flags use the no-byte-read helper.
PreventExtensions is checked before setting non_extensible: RAB refusal makes
no bit change. Fixed-buffer nonempty views can become non-extensible before a
later numeric flag definition refuses, preserving the required partial effect.
The exotic definition route precedes the ordinary cached metadata work.

No fixed work/heap tariff was repriced. New routes use core brand, classifier,
live-witness, conversion, codec and byte helpers. With an empty record table the
new probes debit zero and the original ordinary tariff calls stay in the same
order. Once view records exist, the newly required brand searches are paid by
the core, including ordinary objects searched among those records. New typed
integrity key counts feed the existing bounded preflight; no old limit grows.

Parent validation should include inherited numeric prototype poison in
splice/concat; same/distinct receiver writes including conversion-driven
resize/detach; Array.from custom constructors returning fixed views and mapper
reentrancy; freeze/seal empty/nonempty fixed views and RAB refusal; and borrowed
Array iterator next with poisoned own length, shrink/regrow/detach and sticky
done. Exact/one-short scalar write admission must keep target bytes unchanged,
while already completed callback effects remain. These are required integration
checks, not claimed executions in this hold.
