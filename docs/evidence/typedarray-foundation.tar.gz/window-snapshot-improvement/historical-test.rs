    #[test]
    fn snapshots_preserve_index_creation_and_symbol_order_across_live_changes() {
        check(
            r#"
            window.zz=1;window.aa=2;window['4294967295']=3;
            window[4294967294]=4;window[10]=5;window[2]=6;window['01']=7;
            var a=Object.getOwnPropertyNames(window);
            assert.sameValue(a[0],'2');assert.sameValue(a[1],'10');assert.sameValue(a[2],'4294967294');
            assert(a.indexOf('zz')<a.indexOf('aa'));
            assert(a.indexOf('aa')<a.indexOf('4294967295'));
            assert(a.indexOf('4294967295')<a.indexOf('01'));
            window.zz=9;
            var b=Object.getOwnPropertyNames(window);assert.sameValue(b.join('|'),a.join('|'));
            delete window.zz;window.zz=10;
            b=Object.getOwnPropertyNames(window);assert(b.indexOf('01')<b.indexOf('zz'));
            var before=b.indexOf('globalThis');
            Object.defineProperty(window,'globalThis',{value:window});
            b=Object.getOwnPropertyNames(window);assert.sameValue(b.indexOf('globalThis'),before);
            delete window.globalThis;window.globalThis=window;
            b=Object.getOwnPropertyNames(window);assert.sameValue(b[b.length-1],'globalThis');
            var s1=Symbol('1'),s2=Symbol('2');window[s1]=1;window[s2]=2;
            delete window[s1];window[s1]=3;
            var all=Reflect.ownKeys(window);
            assert.sameValue(all[all.length-2],s2);assert.sameValue(all[all.length-1],s1);
            assert.sameValue(Object.getOwnPropertyNames(window).length,all.length-2);
        "#,
        );
    }

