# Candidate 1 resource rows

All 92 resource observations are runtime instruction-limit refusals, across **49 original files**: 43 files in both modes and six single-mode files. None reports heap exhaustion. The report binds adapter `3136076e8937ec836ecc442200d8b88b001006bee5bccaefe0ab87d9736af7da` and corpus manifest `886b81f9c933ead09109c77d840398aca44cf8bc96397f1ccda88b49254b6744`. Every resource body's source hash was checked against its report row. The original bodies, harness and policies remain unchanged. This assessment used source/data reads and arithmetic only, with no engine or test execution.

The frozen harness is a large matrix even for a short test. Ten Number constructors are present, including Float16, and eight argument factories are enabled: passthrough, Array, array-like, iterable, fixed ArrayBuffer, resizable, grown and shrunk. Immutable is absent. A default `testWithTypedArrayConstructors` therefore calls the body 80 times and creates 80 bound argument-factory functions. An explicit `arraybuffer` filter selects four factories and 40 calls; `passthrough` selects ten calls. The three float kinds select 24 calls. These are intended full-script counts, not claims about how far an aborted row progressed.

| Matrix family | Resource modes | Original files |
| --- | ---: | ---: |
| Ten kinds × eight factories | 62 | 33 |
| Ten kinds × four buffer factories | 4 | 2 |
| Ten kinds, passthrough only | 14 | 8 |
| Three floats × eight factories | 6 | 3 |
| Ten kinds × 56 conversion values | 6 | 3 |

`resource-roster.json` lists each path, mode, original SHA and selected family. All 49 bodies were read, including the longer descriptor and ToIndex tails. All resource files include `testTypedArray.js`; only one also uses `propertyHelper.js`. Consequently descriptor verification cannot explain the entire set.

## Source-proved quota lower bounds

The selected ten element widths sum to 29 bytes. For a primitive argument n, `makeGrownArrayBuffer` and `makeShrunkArrayBuffer` each execute their initial primitive branch and then **fall through** into `makeArrayBuffer`, fresh buffer creation and `copyIntoArrayBuffer`. The initial primitive-branch buffer is not returned. Each copy creates two Uint8Array views and uses an authored byte loop. Across the ten kinds these two factories require `2*n*29` byte iterations if the script completes. No host bulk-copy shortcut may replace that authored loop: its getters, conversions and assignments remain observable.

A reached valid Uint8 index read pays at least 142 work: classifier 44, validity 8+13, repeated live read 13, offset 4, byte read 10 and codec 50. A corresponding write pays at least 134: classifier 44, validity 8+13, repeated live read 13, offset 4, codec 50 and byte write 2. This **276 per copied byte** excludes brand searches, Number-to-property-key formatting, receiver/property routing, the live `.length` condition, all VM instructions, function calls and constructors. Larger decimal indices cost more; 44 is the minimum safe-integer classifier fee.

| Original body | Mandatory byte iterations | Scalar/index work lower bound |
| --- | ---: | ---: |
| `ctors/length-arg/init-zeros.js`, n=9 | 522 | 144,072 |
| `prototype/length/return-length.js`, n=42 | 2,436 | 672,336 |
| `prototype/byteLength/return-bytelength.js`, n=42 | 2,436 | 672,336 |

These cannot complete under 100,000 work with the current operations and fees. Removing only the duplicate live read would save 26 per byte, leaving n=9 at 130,500 and n=42 at `2436*250 = 609,000`. Thus that narrow optimization still cannot admit these scripts. No cap increase or harness/factory exclusion is justified by this assessment.

Each of the three `conversion-operation.js` bodies uses all 56 immutable conversion values for ten kinds: 560 scalar rows. Each row constructs a one-element view and reads its element; DefineOwnProperty and Set variants do additional work. Ignoring that extra work, a constructor write costs at least `66+3*w`, and the indexed read costs at least `139+3*w`, where w is the selected element width. Summing gives `(205*10+6*29)*56 = 124,544`, before any VM/constructor/harness overhead. Uint8Clamped's extra 16-work clamp is also omitted from this lower bound. These three scripts likewise inherently exceed the current accounting contract; eliminating one duplicate live read from each indexed read still leaves 117,264.

Short tests are not necessarily cheap. `return-typedarrayname.js` calls its zero-length factory 80 times. If completed, it creates 150 TypedArray records: eight target views, three intermediate views from `makeArrayBuffer`, and four copy-helper Uint8 views per kind. It also creates 120 ArrayBuffers and 80 bound functions. Zero length removes the byte loops but not this construction/activation matrix. This explains why source length is a poor cost estimate; without a reached-operation trace this assessment does not attribute its exact stopping point or prove a complete 100,000-work lower bound.

## Bounded optimization candidates

1. **Reuse a just-validated live view inside one callback-free element operation.** `typed_array_valid_index` discards a paid Live, then `typed_array_read_number`/`typed_array_write_number` immediately obtains it again. Returning `(index, Live)` to private read/write helpers can remove the second 13-work snapshot and its actual operations. Preserve the initial Define validity check and the new check after value conversion. Never carry a Live across ToNumber, a getter, a VM statement or any authored callback; detached/resized views must still be reacquired. Existing no-shared-buffer scope is important. Scalar constructors that have not already validated must retain their own live check. This is a small real optimization, not enough to make the above lower-bound scripts pass.

2. **Carry one Set classification into ordinary fallback.** Both `set_property_lookup` and `splice_assign` call `typed_array_set`, then probe the same target/key again with `typed_array_own_property(false)` when it returns Ordinary. For ordinary string keys this repeats the brand/classifier; for the valid numeric/distinct-Receiver case it repeats validity as well. A result that distinguishes ordinary fallback from an already-resolved writable indexed descriptor can avoid that work. It must preserve invalid numeric/distinct-Receiver success without conversion and same-Receiver conversion before validity. In particular, returning only Ordinary and blindly skipping the second probe is incorrect for a valid numeric index with a distinct Receiver.

3. **Avoid a second completed absent Get traversal.** `get_key` performs `lookup_property`; on absent scalar keys it calls `get`, which performs the lookup again. For receivers for which the legacy `get` path necessarily returns Undefined after this lookup (`property_object(receiver).is_some()`), a verified direct Undefined return can eliminate the repeated traversal and temporary UTF-8/key conversion. Keep all host fallback behavior separate. This is inherited behavior exposed by the new exotic classifier, and needs ordinary/host regression coverage if selected.

The last two are particularly relevant to the frozen noncanonical-key tests (`1.0`, `+1`, `1000000000000000000000`, `0.0000001`). These keys pass the alphabet filter and invoke primitive parsing plus the admitted 1024-byte formatter scratch on each repeated classification. The five original files covering these four keys account for eight resource modes. A grammar-specific rejection shortcut could be proved separately, but hard-coding these test strings or weakening roundtrip semantics is not recommended.

The 80 factory binds target ordinary Functions with direct property bags; concrete TypedArray natives also carry direct Native.properties. Script independently confirmed that these paths do not expose a new native-registry name scan to remove. Existing function activation and argument-object allocation are real work and cannot simply be uncharged.

Routine metadata/expandos already have the paid alphabet rejection and allocate no parse/formatter storage (`length`/`buffer` 74 work, `constructor` 94). Further first-unit rejection can reduce this work but would require an independently metered rewrite and updated exact cuts; it is secondary to eliminating duplicate whole operations. `getTag` creates a new JsString on each call; reusing an internal immutable name would require new retained bootstrap state/fees or a proved existing immutable slot. Reading mutable public `.name` as a cache is incorrect. No such optimization is proposed for this increment.

## Validation and limits

Prefer the first callback-free Live reuse, then independently consider the duplicate Set/Get traversal changes. Preserve current 100,000 work and cumulative heap limits. Keep all frozen bodies, harness factories and exclusions. Root should use the existing full reports to observe which resource rows become reachable, and retain remaining resources honestly. A newly reached semantic failure is useful evidence, not an optimization regression by itself; existing passing rows and all controls must remain healthy.

For a selected change, retain measured exact/one-short operation tests plus resize/detach during value conversion, distinct Receiver, inherited TypedArray target, ordinary noncanonical keys, descriptor presence without reading bytes, and old ordinary/host fallback cases. This document provides conservative lower bounds and identified duplicate operations, not a full execution profile or a prediction that all 92 resource rows can pass.
