# TypedArray candidate1 failure triage

All86 failed modes are43 strict/sloppy source pairs. The source read found dependency/scope explanations for each family; none demonstrates a defect in the selected foundation. This does not convert failures into passes.

| Cause | Files | Modes |
| --- | ---: | ---: |
| missing reflect has | 12 | 24 |
| missing reflect set | 9 | 18 |
| missing reflect descriptor | 1 | 2 |
| excluded subarray | 3 | 6 |
| excluded tostring | 1 | 2 |
| unguarded bigint | 10 | 20 |
| subclass helper | 7 | 14 |

The subclass family is a static inference: the original helper catches unsupported dynamic class syntax, then appends undefined subclasses to its constructor list. Root can confirm that exact stop point with a separate small reproduction. The BigInt family is stronger: raw diagnostics explicitly name the missing BigInt64Array binding.

Reflect.defineProperty already exists. The non-extensible test fails later at absent Reflect.getOwnPropertyDescriptor. The three own-key tests contain excluded subarray calls; the lone toString body requires excluded stringification metadata. Keep the full corpus and unchanged policy, with all failures visible.

The92 instruction-budget refusals and488 unsupported modes are separate from this86-mode map. No new execution was performed. Complete raw rows,43 body hashes/copies and relevant helper/source bindings are in failure-families.json.
