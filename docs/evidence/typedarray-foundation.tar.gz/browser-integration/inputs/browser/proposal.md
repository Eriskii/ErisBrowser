# Page and confined-worker candidate

The held HTML is an independently authored 320×160 scene. Load it through the
existing Page API with scripting, then run the same scene through the confined
worker. Use the existing real layout hit at (20,20) and dispatch the returned
node; do not call the handler directly. The target is an empty div, so no text
hit ambiguity or button focus outline is expected.

Before the click, require title `TypedArray ready`, phase `0`, word `Ready`,
status `2,1 | 5,258,0 | detached` and green [16,80)×[16,48). After the click,
require title `TypedArray changed`, phase `1`, word `Changed`, status
`1,2 | 3,258,513 | detached` and blue in the same rectangle. All other background
pixels are white. Word begins (96,16), status (16,72), black 16px monospace.
Construct an independent script-free reference document with these exact
literal words/colors/statuses and compare the complete Canvas. Also require
the marker's literal interior pixels and nonwhite pixels inside both text bands
and matching DrawCommand::Text strings to prevent an empty render from passing.

Capture body, title Text, three divs and both visible Text nodes and their
parent/child links before click. Require the exact same NodeIds and document
arena length afterward. The click allocates no DOM nodes. ArrayBuffer and view
objects survive in the page closure; detached originals and the transferred
buffer are independently checked again inside the handler. No network assets,
native renderer requirement, WPT host API, complete TypedArray API or worker
cross-realm sharing claim is made.

The initial script performs aliasing, fixed-view OOB shrink, regrowth and
transfer. The event performs another shrink and an out-of-bounds indexed store
whose ToNumber callback grows the buffer before the fresh element check.
Literal byte order is the selected implementation's little-endian policy.
The helper/runner integration and actual Page/worker executions remain pending.
