# TypedArray intrinsic draft integration

This is source-only work. `intrinsics.rs` and `dom_prototypes.proposed.rs` are
unregistered drafts. No compiler, test, Rust formatter, engine or importer ran
for this draft. The earlier profile/baseline task is separate; its parent-run
results are not evidence of a working TypedArray implementation.

The accepted root API is `Runtime.typed_arrays: typed_array::State`:

```rust
#[derive(Default)]
pub(super) struct State {
    records: Vec<Record>,
    intrinsic: Option<Value>,
    prototype: Option<usize>,
    pub(super) constructors: [Option<Value>; 10],
    prototypes: [Option<usize>; 10],
}
```

These are five named fields: records plus four saved-handle fields; the earlier
coordination phrase “six fields” was a counting typo, not an extra state member.
Root owns Record and Kind. Kind is Copy, `#[repr(usize)]`, with const `index()`,
`name()`, `width()`, and `ALL` in this exact order:

| Index | Kind | Public name | Width |
|---:|---|---|---:|
| 0 | Int8 | Int8Array | 1 |
| 1 | Uint8 | Uint8Array | 1 |
| 2 | Uint8Clamped | Uint8ClampedArray | 1 |
| 3 | Int16 | Int16Array | 2 |
| 4 | Uint16 | Uint16Array | 2 |
| 5 | Int32 | Int32Array | 4 |
| 6 | Uint32 | Uint32Array | 4 |
| 7 | Float16 | Float16Array | 2 |
| 8 | Float32 | Float32Array | 4 |
| 9 | Float64 | Float64Array | 8 |

In root-owned `typed_array.rs`, add `mod intrinsics;` and:

```rust
pub(super) use intrinsics::{GLOBAL_COUNT, GLOBAL_NAME_MAX, METADATA_OBJECTS};
```

The child's three constants and installer are `pub(in crate::script)`. Only the
constructors field is exposed to sibling DOM publication. The Record Vec is
untouched by installation. Native names are the exact ten public constructor
names, `TypedArray`, six `TypedArray.get*` names and three `TypedArray.*` iterator
names from L. Root's dispatch must distinguish the shared constructor, concrete
constructors, six getters and three methods without a new legacy registry scan
or extra bootstrap identity. `@@iterator` is the same Value as `values`.

## Raw bootstrap integration

1. Initialize `typed_arrays: State::default()` with the other private Runtime
   fields. Charge `size_of::<typed_array::State>()` once in the raw bootstrap
   storage initializer, as agreed with root. The child deliberately does not
   charge T. Preserve the existing public successful-bootstrap budget reset.
2. Add `typed_array::METADATA_OBJECTS` to the initial object reservation via the
   proposed DOM diff: 690→721 slots. Its existing reservation work is unchanged;
   storage rises by 31×size_of::<ScriptObject>().
3. Immediately after Window.self definition and before
   `initialize_dom_prototypes()`, call
   `self.initialize_typed_array_intrinsics()?;`. Leave the native discovery loop
   and Object.hasOwn installer placement and fees unchanged.
4. Apply/review `dom-publication.diff`. It contains only the reservation, const
   maximum, joined capacity/order/storage changes and three emission hooks. It
   does not run on the current worktree automatically.

The const maximum uses both the actual DOM roster/HTMLDocument alias and all
Kind names. Only dynamic old global keys are scanned at runtime. Original DOM
creation ordinals and construction stay unchanged. TypedArray ordinals start
one after the HTMLDocument alias, in Kind order; the next global order advances
by ten. Staging is lexicographic: Float16/32/64 before interface index9,
Int16/32/8 before index80, Uint16/32/8/8Clamped after the existing loop. The final
strict-order/collision checks and single merged-map publication remain intact.

The source diff adds no new tree lookup for the saved constructors. Its helper
uses one fixed array index, Option check, Value clone, checked ordinal, existing
owned-name creation, Binding assembly and Vec push. The caller prepays eight
logical units per row plus the declared hook/setup row. It is a private fixed
bootstrap helper, not a newly unmetered general publication API.

## Concrete accounting and publication boundary

No row amount changed from L. Metadata is **4,742** work:
31 fresh maps/92 properties/130 comparisons =2,870; bag/order helpers279;
28 pooled strings/306 units836;20 Native identities/300 name bytes460;
three well-known key lookups75; Object.prototype search/setup30; fixed state,
handles/control/cleanup192. The installer prepays the full map and fixed-state
rows before any property assembly. Map tree bytes are prepaid at the same point.
Existing helper charges then precede each actual bag/string/native allocation.
This changes only admission placement within the new initializer, not an old
body's fees. No callback or author-visible object can escape while it runs.

Sorted insertion uses one Entry lookup per property and no suffix move, second
lookup or sort. A separate literal permutation builds creation order in the
already reserved Vec. Each bag has at most ten entries and remains one leaf.
The String keys are pooled Rc UTF-16 handles. The symbols are the existing
well-known identities, whose `iterator`5 sorts before `toStringTag`13.

The joined publication adds418 staging work,124 owned-name work and372 existing
bulk-plan work: **5,656 new work after the published scan prerequisite**. From
its measured raw5,941 remainder, prediction remains **285**, unmeasured for this
candidate. No residual headroom has been reassigned. Additional installation
operations must be priced before integration or compilation.

The allocation expression remains
`T + 31S + 31(72+A+D) + 92K + 31Bpp + 3016 + 20(N+32) + 300 + 30G + Bsb + 10 BindingBytes + 114`.
T and31S are integration debits; all other metadata storage appears in the child
or existing joined helpers. The prospective total is1,849,867+T only under the
old conditional type assumptions. No type or raw counter is newly measured.

Saved State handles are assigned only after every new metadata admission and
fallible reserve succeeds. The subsequent DOM merge and existing Object.hasOwn
installation can still fail the private whole bootstrap. This is atomic public
realm construction, not rollback of a reusable partially initialized Runtime.
Rc/BTree infallible allocator behavior remains an inherited limitation.

## Root diagnostic and meaningful tests

Before migrating raw snapshots, print remaining steps, cumulative allocated,
objects len/capacity, native/prototype registry lengths and global binding count.
Print S=ScriptObject, A=Option<AbortSlot>, D=Option<f64>, K=PropertyKey, N=Native,
G=(String,Binding), T=typed_array::State, BINDING_BYTES, and both conservative
node-block expressions. Expected counts are721 objects/requested slots,
320 registry natives,25 registry prototypes and210 globals; all are predictions.

Measure the installer alone at its real bootstrap seam, including exact and
one-short work/heap endpoints. Keep original constructor/reset and old direct
native fee boundaries intact. Check literal31/92/20 inventory; all descriptor
flags, pooled values, saved native identities, graph parents and creation-order
permutations; strict sorted staging/collision checks and exact old global
ordinals; no State saved-handle publication on admission failure. Raw whole
bootstrap and measured typed sizes must reconcile before snapshot updates.
