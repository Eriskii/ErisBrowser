# Canonical numeric index draft

This draft targets `script::typed_array::index` after the published formatter
`0abcd4a19a1a8e20aa484b2df019ee75cc1fec02`. The original scratch hold is retained unchanged under index-alphabet-correction-1/initial. Root copied that draft into the worktree before this additive revision. This revision updates the authorized draft and its two tracked copies only; no compiler, JavaScript parser, engine, test or renderer was executed. Rustfmt was used on the source.

`Runtime::typed_array_index(&JsString) -> Result<Index>` accepts an already
converted string key. `Index::Ordinary` is distinct from `Index::Numeric(f64)`.
Numeric results preserve negative zero and NaN, as well as negative, fractional,
infinite and large values. Element validity and current buffer state belong to
the operation consuming the result. Symbol routing remains outside this string
classifier. The function has no Document, callback or property lookup path.

The largest canonical binary64 string is 25 UTF-16 units. Empty or longer keys
are rejected without scanning. A bounded borrowed scan rejects non-ASCII units
without any lossy projection. Distinct lengths select at most one comparison
against `-0`, `NaN`, `Infinity` or `-Infinity`. A normalized decimal integer
through 2^53-1 has an exact nearest spelling and needs no formatter or storage.
After those fast paths, an alphabet-only scan rejects any unit outside digits, period, lowercase e, plus and minus before storage admission. The remaining larger integers, fractions and bounded decimal-alphabet names use one primitive String parse followed by the corrected Number formatter and exact comparison. All finite canonical Number spellings use this alphabet; the four exceptions were already handled. This filter intentionally does not validate a numeric grammar or replace the exact roundtrip.

Every new debit precedes the reached operations it covers. Iterator advances
produce borrowed references; the code-unit/byte loads occur after the debit.
The rows are conservative logical operation envelopes, not machine-cycle
claims. Existing parser/formatter base tariffs are retained, not re-proved or
reduced here.

| Reached stage | Work | Charged storage |
| --- | ---: | ---: |
| Entry, length, range rejection, borrowed slice | 8 | 0 |
| Each ASCII unit reached (load/check/branch/advance) | 4 | 0 |
| Special length selection | 4 | 0 |
| Each special literal pair reached, including mismatch | 6 | 0 |
| Matched special result | 2 | 0 |
| Integer sign/start/normalization/slice setup | 8 | 0 |
| Each integer candidate digit reached | 16 | 0 |
| Completed safe-integer cast/sign/result | 4 | 0 |
| Decimal-alphabet slice/loop setup | 4 | 0 |
| Each reached decimal-alphabet unit including mismatch | 10 | 0 |
| Slow primitive dispatch and Rc clone/retirement | 4 | 0 |
| Existing primitive String parse, length L <= 25 | 1 + floor(6L/8) | 32 + 2L |
| Existing Number formatter base admission | 128 | 1024 |
| Actual shared decimal correction | Existing `number_text` callbacks | Existing callbacks |
| Result length comparison and byte slice | 4 | 0 |
| Each final exact unit/byte pair reached, including mismatch | 6 | 0 |
| Matched numeric result | 2 | 0 |

The 16-unit digit row covers the borrowed load, two range comparisons, branch,
subtraction/widening, checked multiplication/addition and their checks, safe
magnitude comparison, accumulator/result-state update and iteration. No input
digit is accumulated beyond 2^53-1: exceeding it switches to the bounded slow
path. Checked arithmetic still prevents a host overflow if this invariant is
changed later. The alphabet row covers load, two digit-range comparisons, up to four punctuation comparisons, branch, and iteration/early result. It occurs only after the safe-integer path fails, preserving all original successful fast-path fees. The fixed setup rows include result construction and early
returns not listed separately. There is no cache, collection, per-object state
or arena-dependent work.

Exact source-derived fast endpoints (work/bytes), before root execution:

| Input | Work | Bytes |
| --- | ---: | ---: |
| empty or length > 25 | 8 | 0 |
| one non-ASCII unit | 12 | 0 |
| `1` followed by a lone surrogate | 16 | 0 |
| `0`, `7` | 44 | 0 |
| `12` | 70 | 0 |
| `-1` | 60 | 0 |
| `-0` | 34 | 0 |
| `NaN` | 44 | 0 |
| `Infinity` | 94 | 0 |
| `-Infinity` | 104 | 0 |
| `4294967295` | 224 | 0 |
| `9007199254740991` | 344 | 0 |

Exact source-derived slow endpoints use the published formatter's independently
held callback rows: 23/0 for the exponent-mismatch cases, 7/0 for the even last
digit, and 174/32 for each corrected midpoint.

| Input | Classification | Work | Bytes |
| --- | --- | ---: | ---: |
| `1.25` | Numeric | 301 | 1064 |
| `1.0` | Ordinary | 266 | 1062 |
| `9007199254740992` | Numeric | 758 | 1088 |
| `1000000000000000.2` | Numeric | 982 | 1124 |
| `1000000000000000.3` | Ordinary | 980 | 1124 |
| `-1000000000000000.2` | Numeric | 1003 | 1126 |
| `-1000000000000000.3` | Ordinary | 1001 | 1126 |

The positive midpoint reaches three separate storage admissions: parse 68 at
work 566; formatter base 1024 at work 694; correction 32 at work 868. A completed
exact comparison consumes work 982. The existing allocation counter records a
refused admission before returning Resource; no runtime object or key is
modified. Tests deliberately distinguish those semantics from successful heap
admission and do not assert that a failed counter remains under its limit.

Six draft test groups bind all 67 original UTF-16/classification/length-four
expectations, independently derived numeric bits, literal fast/slow exact and
one-short endpoints, a 262,144-unit key rejected by length, lone surrogates and
non-ASCII rejection, the three separate storage cut points, and allocation-free metadata/expando alphabet rejection with literal exact/one-short work cuts. The original
frozen JSON is unchanged. The additional numeric-bit table is computed from
exact decimal fractions by integer quotient/remainder ties-even, independently
of both candidate parsing and formatting. NaN payload bits are not a semantic
requirement; tests check NaN identity by `is_nan()`.

This does not implement integer-indexed Get/Set/Has/Define/Delete/ownKeys or live
view validity. Those routes must treat Numeric-invalid as terminal, preserve
required value-conversion order, and recheck bounds after callbacks. The
classifier has no knowledge of those callbacks and does not authorize caching
buffer validity across them.

The seven slow endpoint additions are exactly 4+10L. Storage is unchanged. Ordinary metadata names stop without allocation: length/buffer/values 74 work, constructor 94, x 54, byteLength/byteOffset 90, entries 78, keys 66. The eX and 1eX witnesses (74 and 104) exercise an allowed first prefix followed by rejection. Both draft and live Rust literal tables retain the original 67 semantic rows byte-for-byte.

The four midpoint exact-fee rows still bind Rust 1.88's inherited shortest generator choosing the odd candidate and reaching the 174-work/32-byte correction. A future generator returning even digits directly preserves semantics but can change those fee endpoints; the original HTML peer records this toolchain limitation. No measured result is claimed by this revision.
