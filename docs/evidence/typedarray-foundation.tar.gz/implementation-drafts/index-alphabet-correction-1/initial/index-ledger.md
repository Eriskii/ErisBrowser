# Canonical numeric index draft

This draft targets `script::typed_array::index` after the published formatter
`0abcd4a19a1a8e20aa484b2df019ee75cc1fec02`. Only scratch files were written.
No module was registered and no compiler, JavaScript parser, engine, test or
renderer was executed. Rustfmt was used on the draft source.

`Runtime::typed_array_index(&JsString) -> Result<Index>` accepts an already
converted string key. `Index::Ordinary` is distinct from `Index::Numeric(f64)`.
Numeric results preserve negative zero and NaN, as well as negative, fractional,
infinite and large values. Element validity and current buffer state belong to
the operation consuming the result. Symbol routing remains outside this string
classifier. The function has no Document, callback or property lookup path.

The largest canonical binary64 string is 25 UTF-16 units. Empty or longer keys
are rejected without scanning. A bounded borrowed scan rejects non-ASCII units
without any lossy projection. Distinct lengths select at most one comparison
against `-0`, `NaN`, `Infinity` or `-Infinity`. A normalized decimal integer
through 2^53-1 has an exact nearest spelling and needs no formatter or storage.
Larger integers, fractions and other bounded ASCII names use one primitive
String parse followed by the corrected Number formatter and exact comparison.

Every new debit precedes the reached operations it covers. Iterator advances
produce borrowed references; the code-unit/byte loads occur after the debit.
The rows are conservative logical operation envelopes, not machine-cycle
claims. Existing parser/formatter base tariffs are retained, not re-proved or
reduced here.

| Reached stage | Work | Charged storage |
| --- | ---: | ---: |
| Entry, length, range rejection, borrowed slice | 8 | 0 |
| Each ASCII unit reached (load/check/branch/advance) | 4 | 0 |
| Special length selection | 4 | 0 |
| Each special literal pair reached, including mismatch | 6 | 0 |
| Matched special result | 2 | 0 |
| Integer sign/start/normalization/slice setup | 8 | 0 |
| Each integer candidate digit reached | 16 | 0 |
| Completed safe-integer cast/sign/result | 4 | 0 |
| Slow primitive dispatch and Rc clone/retirement | 4 | 0 |
| Existing primitive String parse, length L <= 25 | 1 + floor(6L/8) | 32 + 2L |
| Existing Number formatter base admission | 128 | 1024 |
| Actual shared decimal correction | Existing `number_text` callbacks | Existing callbacks |
| Result length comparison and byte slice | 4 | 0 |
| Each final exact unit/byte pair reached, including mismatch | 6 | 0 |
| Matched numeric result | 2 | 0 |

The 16-unit digit row covers the borrowed load, two range comparisons, branch,
subtraction/widening, checked multiplication/addition and their checks, safe
magnitude comparison, accumulator/result-state update and iteration. No input
digit is accumulated beyond 2^53-1: exceeding it switches to the bounded slow
path. Checked arithmetic still prevents a host overflow if this invariant is
changed later. The fixed setup rows include result construction and early
returns not listed separately. There is no cache, collection, per-object state
or arena-dependent work.

Exact source-derived fast endpoints (work/bytes), before root execution:

| Input | Work | Bytes |
| --- | ---: | ---: |
| empty or length > 25 | 8 | 0 |
| one non-ASCII unit | 12 | 0 |
| `1` followed by a lone surrogate | 16 | 0 |
| `0`, `7` | 44 | 0 |
| `12` | 70 | 0 |
| `-1` | 60 | 0 |
| `-0` | 34 | 0 |
| `NaN` | 44 | 0 |
| `Infinity` | 94 | 0 |
| `-Infinity` | 104 | 0 |
| `4294967295` | 224 | 0 |
| `9007199254740991` | 344 | 0 |

Exact source-derived slow endpoints use the published formatter's independently
held callback rows: 23/0 for the exponent-mismatch cases, 7/0 for the even last
digit, and 174/32 for each corrected midpoint.

| Input | Classification | Work | Bytes |
| --- | --- | ---: | ---: |
| `1.25` | Numeric | 257 | 1064 |
| `1.0` | Ordinary | 232 | 1062 |
| `9007199254740992` | Numeric | 594 | 1088 |
| `1000000000000000.2` | Numeric | 798 | 1124 |
| `1000000000000000.3` | Ordinary | 796 | 1124 |
| `-1000000000000000.2` | Numeric | 809 | 1126 |
| `-1000000000000000.3` | Ordinary | 807 | 1126 |

The positive midpoint reaches three separate storage admissions: parse 68 at
work 382; formatter base 1024 at work 510; correction 32 at work 684. A completed
exact comparison consumes work 798. The existing allocation counter records a
refused admission before returning Resource; no runtime object or key is
modified. Tests deliberately distinguish those semantics from successful heap
admission and do not assert that a failed counter remains under its limit.

Five draft test groups bind all 67 original UTF-16/classification/length-four
expectations, independently derived numeric bits, literal fast/slow exact and
one-short endpoints, a 262,144-unit key rejected by length, lone surrogates and
non-ASCII rejection, and the three separate storage cut points. The original
frozen JSON is unchanged. The additional numeric-bit table is computed from
exact decimal fractions by integer quotient/remainder ties-even, independently
of both candidate parsing and formatting. NaN payload bits are not a semantic
requirement; tests check NaN identity by `is_nan()`.

This does not implement integer-indexed Get/Set/Has/Define/Delete/ownKeys or live
view validity. Those routes must treat Numeric-invalid as terminal, preserve
required value-conversion order, and recheck bounds after callbacks. The
classifier has no knowledge of those callbacks and does not authorize caching
buffer validity across them.
