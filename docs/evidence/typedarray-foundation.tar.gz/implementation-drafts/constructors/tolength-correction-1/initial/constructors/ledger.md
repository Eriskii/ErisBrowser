# Constructor draft charges and state boundaries

This is source accounting before compilation or measurements. MAX_STEPS and
MAX_HEAP remain unchanged. The formulas cover logical work and requested typed
storage, not allocator rounding or a CPU instruction guarantee. Existing object,
property, conversion, callback, scalar and ArrayBuffer fees remain payable.

| Reached draft operation | Additional work | Additional cumulative heap |
| --- | --- | --- |
| Constructor entry and primitive/object discrimination | 4 | 0 |
| Prototype classification/saved prototype selection | 4 after paid Get | 0 |
| Record capacity check | 1 | 0 |
| Record growth | `1 + 2*ceil(moved_record_bytes/8)` | full requested `new_capacity*sizeof(Record)` |
| Shell prototype/None-record publication | 8 | 0 beyond ordinary object and reserved record |
| Checked element-to-byte multiplication | 4 | 0 |
| Existing record kind read before fresh backing allocation | 1 | 0 |
| Backing-slot publication and copied return Record | 8 | 0 |
| Buffer-view argument/width setup and final bound selection | 8 each | 0 |
| Typed-source copy setup | 4 | 0 |
| Each different-kind element copy | 4 plus paid core read/write | 0 |
| Iterable acquisition setup | 4 plus paid Call/Get | 0 |
| Each iterator step, including completion | 8 plus paid Call/Get | 0 |
| Append one retained Value handle | 4, including its eventual disposal | 0 unless growth |
| Staging-list growth | `1 + 2*ceil(moved_value_bytes/8)` | full requested `new_capacity*sizeof(Value)` |
| Each collected-value conversion/write | 4 plus paid ToNumber/core write | 0 |
| Each array-like Get/conversion/write | 4 plus paid key/Get/ToNumber/core write | existing decimal key allowance |

Both vectors start without allocation. At a full capacity, the requested new
capacity is `max(2*old_capacity, 4)` with checked multiplication. The complete new
typed block and movement are charged before `try_reserve_exact`; released old
capacity receives no refund. The list moves Value handles rather than cloning
string payloads. Per-append disposal payment covers destruction on later early
return as well as normal iteration; the step payment covers a current temporary
that cannot be appended after a reservation refusal.

The new ArrayBuffer probe pays one entry tick and one tick per binary-search
probe. Intrinsic fixed allocation pays one tick, the existing Object-prototype
lookup allowance, ordinary object creation, the existing zero-block and record
reservation fees, and four work units for its final record append. It uses the
existing absolute host-capacity RangeError and cumulative-heap resource policy.
Raw clone pays four work units for its source/range checks, the complete intrinsic
allocation, then `1 + 2*byte_work(length)` before the existing byte copy, where
`byte_work(0)=0` and otherwise `1+ceil(length/8)`. Thus zeroing and copying both
remain paid, with no double-encoding of float elements.

Primitive length conversion precedes shell creation. Object sources run the
NewTarget prototype Get before brand or iterator inspection. After ordinary
object creation there are no callbacks before its None record is appended;
subsequent callbacks can append recursive views without breaking object-ID
ordering. A copied record index remains stable through those appends. Failed
unescaped shells, records and buffers remain cumulatively charged.

The buffer path checks alignment before explicit length conversion, and checks
current detachment/length after that conversion. Tracking RAB views permit an
incomplete trailing element; fixed buffers with omitted length must have a
byte length divisible by the element width. All casts follow successful bounds
or absolute capacity admission.

Same-kind construction validates the source after the prototype callback, then
copies its selected byte range with no user callbacks. Different-kind copying
uses a temporary backed Record for its unescaped destination and publishes the
record backing only after the callback-free loop. List/array-like paths publish
the allocated fixed backing before element conversions, while the object itself
still cannot escape. The list is exhausted before any ToNumber; array-like
properties are instead read and converted one at a time. Neither step failures
nor conversion failures after exhaustion introduce IteratorClose.

Primary algorithms were read directly for ordering and bounds:

- [TypedArray constructor and initialization operations](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-typedarray)
- [IteratorToList](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-iteratortolist)

Review/testing should pin at least: prototype/source access order; recursive
record search; offset/alignment/length callback effects and final buffer state;
all ten kinds and direct Float16 ties; raw NaN payload and signed-zero copying;
iterator exhaustion before conversion with no late close; array-like interleave;
and exact/one-short record/list allocation and representative scalar/copy fees.
The existing independently frozen 27 bodies and paired controls remain unchanged.
