# TypedArray constructor draft interface

Root approved this interface before source authoring. The draft is intended as
the `typed_array::constructors` child module; it is not registered or compiled.

Root owns `Kind` in the order Int8, Uint8, Uint8Clamped, Int16, Uint16, Int32,
Uint32, Float16, Float32, Float64, with `index`, `name`, `width` and `ALL`.
`Runtime.typed_arrays.records` is a sorted append-only `Vec<Record>`;
`prototypes` is `[Option<usize>; 10]`. The copied record fields are `object_id`,
`kind` and `backing: Option<Backing>`. Backing contains copied `BufferId`, byte
`offset` and `ViewLength::Fixed(element_count)` or `Tracking`.

Root supplies the following callback-free, paid core operations:

```text
typed_array_record(&Value) -> Result<Option<Record>>
typed_array_length(Record) -> Result<usize>
typed_array_read_number(Record, usize) -> Result<f64>
typed_array_write_number(Record, usize, f64) -> Result<()>
```

The lookup distinguishes an absent brand from resource refusal. Length rejects
uninitialized, detached and OOB views. Scalar reads reject invalid bounds;
scalar writes recheck live bounds and silently skip invalid indices to support
the shared Set semantics. Constructor destinations are fresh unescaped fixed
buffers, so source callbacks cannot invalidate them. Kind conversion, clamp,
codec work and byte I/O fees belong to these core scalar operations.

This draft owns shell/record reservation, backing initialization, the five
constructor paths and their staging storage. It exports
`typed_array_constructor(Kind, &[Value], Value, &mut Document) -> Result<Value>`
with visibility through `crate::script`. The entry rejects undefined NewTarget;
the dispatch owner still must reject ordinary calls and the abstract constructor.

The separate ArrayBuffer addition provides:

```text
buffer_probe(&Value) -> Result<Option<BufferId>>
buffer_allocate_intrinsic(u64) -> Result<BufferId>
buffer_clone_range_intrinsic(BufferId, usize, usize) -> Result<BufferId>
```

These helpers use existing private record/storage operations. They invoke no
author code and use the saved intrinsic prototype, independently of globals,
species or ordinary constructor properties. Existing ArrayBuffer/DataView
entry points and their fees are not rewritten.

The constructor delegates observable string/symbol property access to existing
`splice_named_get`, `splice_symbol_get`, `reduce_get` and `reduce_index_key`;
ToIndex uses `buffer_index`, Number conversion uses `splice_number`. Existing
host-symbol lookup limitations remain explicit. No new SharedArrayBuffer,
BigInt, class, Proxy, cross-realm or later TypedArray API is introduced.
