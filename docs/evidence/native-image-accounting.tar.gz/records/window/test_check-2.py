"""Synthetic log-only checks; no window, process, project engine or GPU launch."""
import importlib.util
from pathlib import Path
import unittest
from unittest.mock import patch
from types import SimpleNamespace

spec = importlib.util.spec_from_file_location('icon_window_check', Path(__file__).with_name('check-2.py'))
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)


class WindowProtocol(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.host = check.load_host()

    def log(self, width=1200, height=900):
        conversion = ((width + 7) // 8) * ((height + 7) // 8) * 64
        raster = conversion + 50000
        count = width * height * 4
        return ('presenter: Vulkan adapter="test" type=Cpu driver="test" format=Bgra8Unorm color_space=Srgb alpha=Opaque mode=Fifo; raster=native-shaders with complete CPU admission fallback\n'
                f'native scene prepared: serial=7 snapshot_generation=3 page_commands=40 images=1 loading=false phases=3 lowered_commands=110 rounded_masks=2 raster_invocations={raster} total_invocations={raster + conversion} reference=true\n'
                f'presenter: native shader frame presented; size={width}x{height} serial=7 CPU_upload=false reference=true\n'
                f'presenter: native shader acquired-texture verified; serial=7 generation=3 viewport_revision=2 size={width}x{height} compared_bytes={count} exact=true (before compositor)\n'
                f'presenter: Vulkan acquired-texture verification passed; route=native-raster frames=1 compared_bytes={count} last_serial=7 (before compositor)\n').encode()

    def rejected(self, log, controlled=False):
        with self.assertRaises(ValueError):
            check.validate_run(self.host, b'', log, controlled)

    def test_complete_chain_accepts_observed_bounded_dimensions(self):
        for width, height in [(1180, 880), (640, 480), (1280, 1024)]:
            result = check.validate_run(self.host, b'', self.log(width, height), False)
            self.assertEqual(result['verified']['compared_bytes'], width * height * 4)
            self.assertEqual(result['verified']['viewport_revision'], 2)
            self.assertFalse(result['presented']['CPU_upload'])

    def test_every_required_record_and_loaded_fixture_identity(self):
        lines = self.log().splitlines(keepends=True)
        for index in range(5):
            self.rejected(b''.join(lines[:index] + lines[index + 1:]))
        for before, after in [(b'page_commands=40', b'page_commands=39'), (b'images=1', b'images=0'),
                              (b'loading=false', b'loading=true'), (b'CPU_upload=false', b'CPU_upload=true'),
                              (b'reference=true', b'reference=false')]:
            self.rejected(self.log().replace(before, after))

    def test_serial_generation_viewport_and_complete_bytes(self):
        for before, after in [(b'generation=3 viewport', b'generation=4 viewport'),
                              (b'viewport_revision=2', b'viewport_revision=0'),
                              (b'last_serial=7', b'last_serial=8'),
                              (b'frames=1', b'frames=2'),
                              (b'compared_bytes=4320000', b'compared_bytes=4319999'),
                              (b'exact=true', b'exact=false')]:
            self.rejected(self.log().replace(before, after))
        self.rejected(self.log().replace(b'size=1200x900 serial=7', b'size=1200x899 serial=7'))
        self.rejected(self.log(1281, 880))

    def test_order_duplicates_and_truncated_diagnostics(self):
        lines = self.log().splitlines(keepends=True)
        for index in range(5): self.rejected(b''.join(lines[:index] + [lines[index]] + lines[index:]))
        self.rejected(b''.join([lines[0], lines[2], lines[1], *lines[3:]]))
        self.rejected(self.log()[:-1])
        self.rejected(self.log() + b'paint: failed\n')
        with self.assertRaises(ValueError): check.validate_run(self.host, b'unexpected', self.log(), False)

    def test_startup_and_owned_controller_are_not_pixel_proof(self):
        waiting = b'presenter: native raster admission fallback; complete CPU upload; reason=native scene awaits a current loaded page; size=1180x880\n'
        oversized = b'presenter: native raster admission fallback; complete CPU upload; reason=viewport-budget; size=1500x1100\n'
        result = check.validate_run(self.host, b'', waiting + oversized + self.log(), True)
        self.assertEqual(len(result['startup_fallbacks']), 2)
        self.rejected(oversized + self.log())
        self.rejected(waiting)
        self.rejected(self.log(640, 480), True)
        self.rejected(self.log() + waiting)

    def test_cpu_refusal_and_page_errors_cannot_pass(self):
        refusal = b'presenter: native raster admission fallback; complete CPU upload; reason=cpu-paint-budget; size=1180x880\n'
        self.rejected(refusal + self.log())
        self.rejected(self.log() + b'[page] resource failed\n')
        self.rejected(self.log() + b'presenter: unknown record\n')


    def test_controlled_physical_size_is_exact_and_unscaled_size_refuses(self):
        result = check.validate_run(self.host, b'', self.log(), True)
        self.assertEqual(result['verified']['compared_bytes'], 4_320_000)
        self.rejected(self.log(1180, 880), True)
        self.rejected(self.log(800, 600), True)
        self.rejected(self.log(1200, 899), True)

    def test_owned_adapter_reuses_exact_function_body_and_fixed_target(self):
        original = self.host.configure_owned
        fake = SimpleNamespace(configure_owned=original)
        def inspect_adapter():
            configured = fake.configure_owned
            self.assertEqual(configured.keywords, {'requested_size': (800, 600)})
            self.assertIs(configured.func.__code__, original.__code__)
            self.assertEqual(configured.func.__globals__['SIZE'], (800, 600))
            for key, value in original.__globals__.items():
                if key != 'SIZE': self.assertIs(configured.func.__globals__[key], value)
            self.assertEqual(original.__globals__['SIZE'], (1180, 880))
            return 23
        fake.owned_main = inspect_adapter
        with patch.object(check, 'load_host', return_value=fake):
            self.assertEqual(check.owned_main_800(), 23)


if __name__ == '__main__':
    unittest.main()
