#!/usr/bin/env python3
"""One root-run acquired-texture check of the frozen small-images fixture."""
from __future__ import annotations
import argparse
import hashlib
import functools
import importlib.util
import json
import re
import signal
import sys
import types
from pathlib import Path

HERE = Path(__file__).resolve().parent
N = HERE.parent
WORKTREE = N / 'worktree'
FIXTURE = N / 'browser/draft/examples/vulkan-small-images.html'
PNG = FIXTURE.with_suffix('.png')
FIXTURE_SHA = '51cccf1617d3af4d470b7fc9b5230beee11837234cabcaa773fe61daac3caf7d'
PNG_SHA = 'f6b373ee62d8abe053e1decceb83b38627e0ce3df932ce72729f10a2e6e8fc58'
MAX_BINARY = 128 * 1024 * 1024  # Existing Native host bound, unchanged.
MAX_OUTPUT = 2 * 1024 * 1024
LOGICAL_SIZE = (800, 600)
PHYSICAL_SIZE = (1200, 900)  # Observed 1.5x compositor scale; exact checker2 target.


def binding(path: Path, limit: int = 1024 * 1024) -> dict:
    path = path.resolve()
    if not path.is_file() or path.stat().st_size > limit:
        raise ValueError(f'missing or oversized binding: {path}')
    with path.open('rb') as source:
        sha = hashlib.file_digest(source, 'sha256').hexdigest()
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}


def checked(row: dict, limit: int = 1024 * 1024) -> dict:
    actual = binding(Path(row['path']), limit)
    if any(actual[key] != row[key] for key in ('path', 'bytes', 'sha256')):
        raise ValueError(f'input binding changed: {row["path"]}')
    return actual


def load_host():
    # These existing imports define functions only. Only run_supervised launches
    # the established isolated subreaper; no new process controller is authored.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(WORKTREE / 'tools'))
    path = WORKTREE / 'tools/native_raster_host.py'
    spec = importlib.util.spec_from_file_location('image_native_host', path)
    host = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(host)
    return host


def owned_main_800() -> int:
    host = load_host()
    original = host.configure_owned
    # Reuse the complete existing ownership/query/resize/deadline body. Only
    # its SIZE guard resolves to the single authorized logical target here;
    # a partial always supplies that target, never arbitrary caller dimensions.
    configured = types.FunctionType(original.__code__, {**original.__globals__, 'SIZE': LOGICAL_SIZE},
                                    original.__name__, original.__defaults__, original.__closure__)
    configured.__kwdefaults__ = dict(original.__kwdefaults__ or {})
    host.configure_owned = functools.partial(configured, requested_size=LOGICAL_SIZE)
    # The unchanged owned_main/owned_launch code still owns, signals and reaps
    # only its direct unreaped browser child inside the existing subreaper.
    return host.owned_main()


def validate_run(host, stdout: bytes, stderr: bytes, controlled: bool) -> dict:
    if stdout or len(stderr) > MAX_OUTPUT:
        raise ValueError('unexpected stdout or oversized diagnostic stream')
    text = stderr.decode('utf-8', errors='strict')
    if not text.endswith('\n'):
        raise ValueError('unterminated diagnostic stream')
    lines = text.splitlines()
    if len(lines) > 4096 or any(len(line) > 16384 for line in lines):
        raise ValueError('diagnostic line bounds')
    scenes, presents, verified, summaries, adapters, fallbacks, other = {}, [], [], [], [], [], []
    for line in lines:
        if match := host.SCENE.fullmatch(line):
            serial, generation, commands, images, loading, phases, lowered, rounded, raster, total, reference = match.groups()
            row = dict(zip(('serial', 'generation', 'page_commands', 'images', 'phases', 'lowered_commands', 'rounded_masks', 'raster_invocations', 'total_invocations'), map(int, (serial, generation, commands, images, phases, lowered, rounded, raster, total))))
            row['reference'] = reference == 'true'
            if (summaries or row['serial'] <= 0 or row['serial'] in scenes or row['generation'] <= 0
                    or loading != 'false' or row['page_commands'] != 40 or row['images'] != 1
                    or row['phases'] != 3 or not 40 <= row['lowered_commands'] <= 256
                    or not 0 <= row['rounded_masks'] <= row['lowered_commands']
                    or not 0 < row['raster_invocations'] < row['total_invocations'] <= 4_000_000):
                raise ValueError('loaded icon scene identity or existing admission bound')
            scenes[row['serial']] = row
        elif match := host.PRESENTED.fullmatch(line):
            width, height, serial, reference = match.groups()
            width, height, serial = map(int, (width, height, serial))
            if (summaries or presents or serial not in scenes or reference != 'true'
                    or not scenes[serial]['reference'] or not 1 <= width <= 1280 or not 1 <= height <= 1024):
                raise ValueError('unique Native reference presentation must follow its loaded scene')
            if controlled and (width, height) != PHYSICAL_SIZE:
                raise ValueError('presentation does not match owned controlled dimensions')
            conversion = ((width + 7) // 8) * ((height + 7) // 8) * 64
            scene = scenes[serial]
            if scene['total_invocations'] - scene['raster_invocations'] != conversion:
                raise ValueError('scene/presentation conversion dimensions disagree')
            presents.append({'serial': serial, 'width': width, 'height': height, 'CPU_upload': False, 'reference': True})
        elif match := host.VERIFIED.fullmatch(line):
            serial, generation, revision, width, height, count = map(int, match.groups())
            if (summaries or verified or len(presents) != 1 or serial != presents[0]['serial']
                    or generation != scenes[serial]['generation'] or revision <= 0
                    or (width, height) != (presents[0]['width'], presents[0]['height'])
                    or count != width * height * 4):
                raise ValueError('acquired verification identity/dimensions/complete byte count')
            verified.append({'serial': serial, 'generation': generation, 'viewport_revision': revision,
                             'width': width, 'height': height, 'compared_bytes': count, 'exact': True})
        elif match := host.SUMMARY.fullmatch(line):
            frames, count, serial = map(int, match.groups())
            if summaries or len(verified) != 1 or frames != 1 or count != verified[0]['compared_bytes'] or serial != verified[0]['serial']:
                raise ValueError('final verification summary does not match actual acquired record')
            summaries.append({'frames': frames, 'compared_bytes': count, 'last_serial': serial})
        elif match := host.FALLBACK.fullmatch(line):
            reason = match.group(1)
            startup = re.fullmatch(r'native scene awaits a current loaded page; size=\d+x\d+', reason)
            resized = re.fullmatch(r'viewport-budget; size=(\d+)x(\d+)', reason)
            outside_caps = resized and (int(resized[1]) > 1280 or int(resized[2]) > 1024)
            if scenes or summaries or not (startup or (controlled and outside_caps)):
                raise ValueError('non-startup Native admission fallback: ' + reason)
            fallbacks.append(reason)  # Retained, never counted as verification.
        elif host.ADAPTER.fullmatch(line):
            adapters.append(line)
        elif (line.startswith(('presenter:', 'native scene', 'native zoom', 'native opacity', 'paint:', 'eris-browser:', 'Unable to open browser window:', "thread '")) or 'panicked at' in line):
            raise ValueError('unrecognized or failed browser diagnostic: ' + line)
        elif line.startswith('[page] ') and not line.startswith(('[page] Page process ', '[page] Resource broker ')):
            raise ValueError('unexpected page diagnostic: ' + line)
        else:
            other.append(line)
    if len(adapters) != 1 or len(presents) != 1 or len(verified) != 1 or len(summaries) != 1:
        raise ValueError('missing complete adapter/Native/acquired/final-summary chain')
    return {'adapter': adapters[0], 'scenes': list(scenes.values()), 'presented': presents[0],
            'verified': verified[0], 'summary': summaries[0], 'startup_fallbacks': fallbacks,
            'other_diagnostic_lines': other,
            'identity_scope': 'Serial joins scene and presentation to the acquired FrameStamp; generation is repeated by scene/acquired logs. Viewport revision is recorded by acquired log only, whose packet propagation is source-bound.',
            'scope': 'One actual acquired Native texture versus Canvas, before compositor; no click/input, screenshot, timing or general compatibility claim.'}


def run(args) -> dict:
    output = args.output.resolve()
    if output.exists() or output.is_relative_to((N / 'browser').resolve()) or output.is_relative_to(WORKTREE.resolve()):
        raise ValueError('output must be new and outside frozen fixture/worktree')
    output.mkdir(parents=True)
    result = {'schema': 1, 'success': False, 'runs': [], 'timeout_seconds': 30,
              'window_seconds': 6, 'controller_requested': args.controller is not None,
              'logical_size': list(LOGICAL_SIZE), 'expected_physical_size': list(PHYSICAL_SIZE),
              'scale_basis': 'run-1 controlled1180x880 but presented only viewport fallbacks at1770x1320; observed1.5x',
              'scope': 'Optional root-run single real-window acquired-texture check; no automatic retry.'}
    def persist():
        temporary = output / 'result.json.tmp'
        temporary.write_text(json.dumps(result, indent=2) + '\n')
        temporary.replace(output / 'result.json')
    persist()
    unchanged = None
    try:
        host = load_host()
        record_path = args.binary_record.resolve()
        binary_record = json.loads(record_path.read_bytes())
        binary = checked(binary_record, MAX_BINARY)
        compiled = checked(binary_record['compiled_source'])
        build = checked(binary_record['build_receipt'])
        manifest = json.loads(Path(compiled['path']).read_bytes())
        source_table = manifest['source_sha256']
        if not isinstance(source_table, dict) or not source_table:
            raise ValueError('empty compiled source table')
        source_rows = []
        for name, sha in source_table.items():
            relative = Path(name)
            if relative.is_absolute() or '..' in relative.parts:
                raise ValueError('compiled source path escape')
            source = binding(WORKTREE / relative, MAX_BINARY)
            if source['sha256'] != sha:
                raise ValueError('selected compiled source changed: ' + name)
            source_rows.append(source)
        required_sources = {'src/browser.rs', 'src/browser/native_scene.rs', 'src/presenter.rs', 'src/presenter/vulkan.rs', 'src/presenter/vulkan/native.rs', 'src/presenter/vulkan/control.rs', 'src/graphics/raster_bridge/native.rs', 'src/graphics.rs'}
        if not required_sources <= set(source_table):
            raise ValueError('compiled source misses selected scene/stamp/renderer paths')
        build_data = json.loads(Path(build['path']).read_bytes())
        expected_build = ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
        if build_data['exit'] != 0 or build_data['command'] != expected_build:
            raise ValueError('selected build receipt is not a successful Cargo invocation')
        if Path(build_data['log']).name != build_data['log']:
            raise ValueError('build log path must be a sibling filename')
        log = Path(build['path']).parent / build_data['log']
        build_log = binding(log, 16 * 1024 * 1024)
        if build_log['sha256'] != build_data['sha256']:
            raise ValueError('selected build log changed')
        strip = checked(binary_record['strip_receipt'])
        strip_data = json.loads(Path(strip['path']).read_bytes())
        if strip_data['exit'] != 0 or strip_data['command'] != ['/run/current-system/sw/bin/strip', '--strip-debug', binary['path']]:
            raise ValueError('unexpected immutable candidate strip receipt')
        if Path(strip_data['log']).name != strip_data['log']:
            raise ValueError('strip log path must be a sibling filename')
        strip_log = binding(Path(strip['path']).parent / strip_data['log'])
        if strip_log['sha256'] != strip_data['sha256']:
            raise ValueError('strip log changed')
        unstripped_record = checked(binary_record['unstripped'])
        # Hash-only provenance: this large debug artifact is never launched.
        unstripped = checked(json.loads(Path(unstripped_record['path']).read_bytes()), 512 * 1024 * 1024)
        fixtures = [binding(FIXTURE), binding(PNG)]
        if [row['sha256'] for row in fixtures] != [FIXTURE_SHA, PNG_SHA]:
            raise ValueError('frozen icon fixture changed')
        sources = host.source_binding()
        sources[str(Path(__file__).resolve())] = binding(Path(__file__))['sha256']
        env = host.environment(args.loader_directory)
        loader = host.loader_binding(args.loader_directory, env)
        if not loader['files']:
            raise ValueError('explicit loader directory has no bound files')
        controller = binding(args.controller, MAX_BINARY) if args.controller else None
        result.update(binary_record=binding(record_path), binary=binary, compiled_source=compiled,
                      compiled_inputs=source_rows, build_receipt=build, build_log=build_log,
                      strip_receipt=strip, strip_log=strip_log, unstripped_record=unstripped_record, unstripped=unstripped,
                      fixture_bindings=fixtures, source_bindings=sources, loader=loader, controller=controller,
                      display_environment={key: env.get(key) for key in ('DISPLAY', 'WAYLAND_DISPLAY', 'XDG_RUNTIME_DIR', 'XDG_SESSION_TYPE')})
        fixed = [result['binary_record'], binary, compiled, build, build_log, strip, strip_log, unstripped_record, *fixtures, *source_rows]
        if controller: fixed.append(controller)
        def unchanged():
            for row in fixed: checked(row, MAX_BINARY)
            checked(unstripped, 512 * 1024 * 1024)
            if host.loader_binding(args.loader_directory, env) != loader:
                raise ValueError('explicit loader binding changed')
            for path, sha in sources.items():
                if binding(Path(path))['sha256'] != sha:
                    raise ValueError('checker/supervisor source changed')
        command = [binary['path'], str(FIXTURE), '--presenter=vulkan', '--raster=gpu', '--vulkan-verify-frames', '1', '--exit-after', '6']
        browser_command = command[:]
        control_receipt = output / 'native.window-control.json'
        if controller:
            command = [sys.executable, str(Path(__file__).resolve()), '--owned-launch', '--receipt', str(control_receipt),
                       '--controller', controller['path'], '--controller-sha256', controller['sha256'],
                       '--binary-sha256', binary['sha256'], '--window-seconds', '6', '--allow-experimental-gpu', '--', *command]
        result.update(command=command, browser_command=browser_command)
        persist()
        unchanged()
        record, stdout = host.run_supervised(command, output, 'native', env, 30)
        result['runs'].append(record)
        persist()
        host.check_success(record)
        if (output / 'native.supervisor.stderr.log').stat().st_size or record.get('capture_gate_required') or record.get('capture_gate_granted'):
            raise ValueError('unexpected supervisor output or worker capture gate')
        if controller:
            result['control_receipt'] = binding(control_receipt)
            control = json.loads(control_receipt.read_bytes())
            result['control'] = control
            if (control.get('success') is not True or control.get('control_complete') is not True
                    or control.get('browser_reaped') is not True or control.get('browser_returncode') != 0
                    or control.get('controlled_size') != list(LOGICAL_SIZE) or control.get('browser_command') != browser_command
                    or control.get('binary_sha256') != binary['sha256'] or control.get('controller_sha256') != controller['sha256']):
                raise ValueError('owned window control was incomplete or identities changed')
        stderr_path = output / 'native.stderr.log'
        stderr = stderr_path.read_bytes()
        if (len(stdout) + len(stderr) > MAX_OUTPUT or hashlib.sha256(stdout).hexdigest() != record['stdout_sha256']
                or hashlib.sha256(stderr).hexdigest() != record['stderr_sha256']):
            raise ValueError('captured stream changed')
        result['validation'] = validate_run(host, stdout, stderr, controller is not None)
        unchanged()
        result['success'] = True
    except (OSError, ValueError, RuntimeError, KeyError, TypeError, ImportError, KeyboardInterrupt) as error:
        result['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        if unchanged is not None:
            try: unchanged()
            except (OSError, ValueError, RuntimeError, KeyError, TypeError) as error:
                result['success'] = False
                result['postcheck_error'] = f'{type(error).__name__}: {error}'[:4096]
        persist()
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary-record', type=Path, required=True)
    parser.add_argument('--loader-directory', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--controller', type=Path)
    parser.add_argument('--allow-experimental-gpu', action='store_true')
    args = parser.parse_args()
    if not args.allow_experimental_gpu:
        parser.error('root-run actual window/worker/Vulkan execution needs --allow-experimental-gpu')
    previous = {}
    def interrupted(_signum, _frame): raise KeyboardInterrupt
    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            previous[sig] = signal.signal(sig, interrupted)
        result = run(args)
    finally:
        for sig, handler in previous.items(): signal.signal(sig, handler)
    print(json.dumps({'success': result['success'], 'result': str(args.output.resolve() / 'result.json')}))
    return 0 if result['success'] else 1


if __name__ == '__main__':
    raise SystemExit(owned_main_800() if sys.argv[1:2] == ['--owned-launch'] else main())
