from pathlib import Path
import hashlib, json, subprocess, sys
H = Path(__file__).resolve().parent
W = H / 'worktree'
summary_path = W / 'docs/evidence/native-image-accounting.json'
summary = json.loads(summary_path.read_bytes())
archive_path = W / 'docs/evidence' / summary['archive']
assert archive_path == W / 'docs/evidence/native-image-accounting.tar.gz'
archive_bytes = archive_path.read_bytes()
assert len(archive_bytes) == summary['archive_bytes']
assert hashlib.sha256(archive_bytes).hexdigest() == summary['archive_sha256']
expected = dict(summary['published_bindings'])
for name in ['docs/evidence/native-image-accounting.json', 'docs/evidence/native-image-accounting.tar.gz']:
    data = (W / name).read_bytes()
    expected[name] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
actual = subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=W).decode().split('\0')[:-1]
assert len(actual) == len(set(actual)) and set(actual) == set(expected), (set(actual)-set(expected),set(expected)-set(actual))
for name, row in expected.items():
    data = subprocess.check_output(['git','show',':'+name],cwd=W)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], name
    assert data == (W/name).read_bytes(), name
subprocess.run(['git','diff','--cached','--check','--','.'],cwd=W,check=True)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=W)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W)
print(json.dumps({'staged_files':len(actual), 'all_staged_bytes_match_reviewed_evidence':True}))
