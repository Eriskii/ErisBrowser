# Root-only image-accounting publisher

`../package.py` is source-only preparation. The author has not imported or run it.
It creates exactly `docs/evidence/native-image-accounting.json` and
`docs/evidence/native-image-accounting.tar.gz`, using the existing staged verifier's
archive/archive_bytes/archive_sha256/published_bindings schema.

The final root-created `../publication-selection.json` selects three independent
clear review receipts and optional window evidence:

```
{
  "schema": 1,
  "documentation_review": {"path": "ABSOLUTE JSON PATH", "bytes": 0, "sha256": "ACTUAL SHA"},
  "observation_review": {"path": "ABSOLUTE JSON PATH", "bytes": 0, "sha256": "ACTUAL SHA"},
  "package_review": {"path": "ABSOLUTE JSON PATH", "bytes": 0, "sha256": "ACTUAL SHA"},
  "window": null
}
```

This is schema guidance, not a runnable selection or fabricated receipt. Each
review must have `status` starting with `clear`, no findings, and a flat `files`
list with actual absolute path/bytes/sha256 bindings. All selected files must
remain under this increment's root. An optional binary row can name only the
selected before/candidate executables; their bytes are hashed but excluded.

Documentation review must bind the four final worktree docs. Observation review
must bind compiled-source-2, baseline-source, candidate-binary and the final
full-native, focused-native, baseline-browser and candidate-browser receipts.
Package review must bind package.py, verify-staged.py and expected-receipts.json.
A window selection uses `{review, records, summary}`: all records are bound files
and the separate clear review must bind each one. The explicit summary has
status `verified` or `failed` and retains the relevant scope/counts. It is copied
only after exact equality with the selected window review’s top-level `summary`
field. The publisher does not independently reinterpret those observations. All
window attempts, including failed scaling attempts, are archived regardless.
Root must not select null while documentation claims a window result.

The publisher independently rechecks all 13 fixed receipt command vectors,
exits/log hashes and exact Rust result totals from expected-receipts.json. The
first64-pass/1-failure result remains required. The two Page/worker phase records
must occur exactly twice each, with fixed expected refusal/admission and plan
numbers. Rust1.98 has24 total result rows (65pass plus23zero rows); full Rust1.88
has25 rows/2420pass. These are separate populations.

It rehashes all297 candidate compiled inputs and extracts all291 parent inputs
using `git show` of the published parent. The entire baseline295 and first
candidate297 inventories are reconstructable through exact indexed source
members, with only their differing payloads retained separately. No guessed
parent checkout bytes are used. Changed candidate paths are restricted to the
one production file, three old test/registration paths, two new private test
files and four browser paths. The four final docs join the publication list.

Archive inputs come only from nine named small artifact directories, explicit
root records and selected-review bindings. Worktree/target/prior archives and
ELF payloads cannot enter by recursive discovery. All validation attempts remain;
`validation/package-*` logs/receipts are excluded because the root runner creates
and later rewrites them around publishing. Publication receipts remain external.
The complete manifest is in `index.json`; every archive member is reread and
hashed, and every input is rechecked before exclusive output creation. The summary
binds the final archive bytes/hash and the exact published worktree paths.

Source guards intentionally stop on stale docs/reviews, changed source, unknown
retained source deltas or an already-existing output. Root alone runs the
publisher after final documentation/observations and its independent source peer.
