# Small images: frozen browser witness and root-only validation

This source-only preparation creates no observations. The page is 512×512, with forty absolute 24×24 images in an eight-column/five-row grid. All images reference the same local 77-byte PNG: four opaque pixels, red/green over blue/yellow. A genuine hit on the first image changes its width to32, its title Text and body phase, preserving the complete node graph and all image resources. It can be clicked again to restore the initial state.

## Source and independent oracles

Install the four files under draft/ at their relative repository paths. The baseline wrapper under baseline/tests/ replaces only the corresponding integration-test file: EXPECT_NATIVE=false instead of true. It uses the identical support source, HTML and PNG. The baseline assertion requires CpuPaintBudget with no phase/command index; it never accepts arbitrary refusal or either outcome. Do not install production accounting until the parent run is retained.

Both Page::load and the real Linux confined Worker load the HTML and PNG. Their two phases require exactly40 Image commands, one decoded2×2 source with the literal16 RGBA bytes, no text or scopes, forty actual image nodes with natural dimensions2×2, a real image hit and44 retained IDs. After clicking, all parent/child relationships must remain identical. The CPU Canvas output and packed-plan decoder are each compared to a complete independent262,144-pixel literal quadrant array;288 pixels change. Opaque red/green/blue/yellow and white sentinel samples prevent blank/dropped-image witnesses.

An independent core Native plan is constructed from literal image rectangles and literal source bytes, not from the loaded display list or bridge. It must fit on both versions. The admitted bridge's complete ordered draws, packed parameters and input arena must match that core plan. Its CPU decoder reads the packed source words and sampling LUTs; it is not GPU execution.

Exact source-derived ledger:

| Item | Initial | After click |
|---|---:|---:|
| Original/lowered Image commands |40|40|
| Unique/referenced decoded sources and bytes |1 /16|1 /16|
| Clipped Image loop area |23,040|23,232|
| Parent Image reservation |10,485,760|10,485,760|
| Unchanged CPU limit |4,194,304|4,194,304|
| Draws (including clear) |41|41|
| Core invocations (including clear and conversion) |547,328|547,520|
| Input arena bytes |7,696|7,728|
| Core GPU buffer bytes |2,115,360|2,115,392|
| Masks/row tables/opacity scratch |0|0|

Derivation:40×512² parent pixels;40×24² initial loops, then39×24²+32×24. Each source is packed once (16 bytes). LUTs have40×48 words initially, then39×48+56; GPU storage is two512²×4 surfaces plus the16-byte conversion uniform,41×256 parameter bytes and the input arena. Every image dimension is a multiple of8, so padded image invocations equal loop area. Clear plus conversion contribute2×512² invocations. These predictions require root's observed results before publication.

## Root-only execution order

1. Preserve parent source/binary bindings. Install frozen assets, support and the baseline wrapper into the parent checkout (or isolated parent worktree). Run `cargo +1.88.0 test --locked --features raster-bridge --test vulkan_small_images loaded_small_images_click_preserves_ids_and_complete_native_pixels -- --exact --nocapture`. Keep complete receipt/log, even on failure. It must report both explicit whole-scene CPU refusals while Canvas/literal/core-plan comparisons pass.
2. Build the matching browser worker and run the ignored `confined_small_images_click_preserves_ids_and_complete_native_pixels` with `--ignored --exact --nocapture` in the existing permitted Landlock environment. Use the same package feature selection as the prior small-box integration; do not weaken worker confinement. Both phases must retain exact pixels and the predecessor refusal. The test reaps the owned worker/broker before removing assets.
3. Install the reviewed accounting change and candidate wrapper (EXPECT_NATIVE=true), preserving all other inputs. Run the same two tests and retain the two actual admission/stat records. The candidate must have the exact CPU and unchanged-core-plan data above. No command, source, pixel, scope, GPU, font or preparation cap increases are requested.
4. Formatting/build/lint and existing native scene regressions are root-owned. Retain initial failures and any source corrections additively; do not rewrite asset holds or claim unexecuted groups.

## Optional actual acquired-texture check

The Page/worker tests deliberately need no desktop window. They establish loaded-resource fidelity, actual admission, CPU output and packed-plan fidelity, not driver execution. Once these pass, the existing native presentation path can verify the same initial HTML/PNG against Canvas with `--presenter=vulkan --raster=gpu --vulkan-verify-frames 1 --exit-after 6`. A matching `--raster=cpu` run can exercise acquired CPU-upload pixels. Use root's existing bounded subreaper/owned-window helpers and retain binary, loader, adapter, surface format, exact fixture hashes, argv, exit, logs and cleanup. No new broad host framework is needed.

The existing tools/native_raster_host.py parser is bound to different fixed fixtures/command and rounded-mask counts; it must not be reused unchanged or its result called valid for this icon page. Any small external harness/parser must bind these assets and require the actual loaded scene record with40 page commands/one image, the matching serial/generation/viewport revision, native presentation with CPU_upload=false, reference=true, one exact acquired-texture record and its final summary. A fallback alone is not an acquired pixel result. Compare the entire actual physical surface (width×height×4 bytes), before the desktop compositor; chrome and document offsets make that distinct from the512² Page oracle.

The current native scene composes page, overlay and chrome phases. Its actual total commands, masks, fonts and GPU invocations must be checked with the unchanged caps before claiming the window is feasible. At1180×880 the old Image subtotal alone is41,536,000 (>16,614,400 CPU allowance); the candidate icon subtotal stays23,040 if fully visible, but chrome/text are additional. Do not substitute these predictions for observed scene preparation. Root can use an owned fixed-size window if available; do not manipulate unrelated windows. The Page click/after-phase is already witnessed in the confined worker; an acquired check of the clicked state additionally requires a bounded owned input route and the resulting scene identity, not a CLI `--click` assumption. No screenshot, benchmark, performance or Chromium comparison is claimed.
