"""Root-run, source-bound Native image evidence publisher; no project imports.

The root supplies publication-selection.json only after final documentation and
observation reviews. Outputs are exclusive; packaging receipts remain external.
"""
from collections import Counter
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

N = Path(__file__).resolve().parent
W = N / 'worktree'
BASE = '4a5f184340c66874b9ff3383689aef504a819e7e'
SOURCE_SHA = '2d5f607053dd186e011ae20023cc2844733b93c56b28b76f3f3aec4d4e99babd'
RECEIPTS_SHA = '060d5c3c48a867991d11a674e05225dc1b3c487a588ad60ecd4c76e148e0d134'
DOCS = ('README.md', 'docs/ROADMAP.md', 'docs/COMPATIBILITY.md', 'docs/native-image-accounting.md')
DIRS = ('implementation', 'tests', 'root-tests', 'migration', 'browser',
        'docs-preparation', 'package-preparation', 'validation', 'window')
ROOT_FILES = ('parent-publication.json', 'parent-ci.json', 'parent-source.json',
              'baseline-source.json', 'compiled-source-1.json', 'compiled-source-2.json',
              'before-binary.json', 'candidate-binary.json', 'candidate-unstripped.json',
              'integration-1.json', 'formatting-1.diff', 'validation-counts-1.json',
              'run-tool.py', 'run-check.py', 'package.py', 'verify-staged.py',
              'staged-verifier-source.json', 'publication-selection.json')
BINARY_PATHS = {N / 'eris-browser-before-1', N / 'eris-browser-candidate-1'}
inputs, records = {}, {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def safe(root, name):
    assert isinstance(name, str) and name
    p = PurePosixPath(name)
    assert not p.is_absolute() and '..' not in p.parts and str(p) == name
    path = root / name
    assert not any(p.is_symlink() for p in (path, *path.parents))
    return path


def payload(path):
    assert path.is_file() and not path.is_symlink(), path
    assert path.stat().st_size <= 16 * 1024 * 1024, path
    data = path.read_bytes()
    row = {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
    assert inputs.setdefault(str(path), row) == row, ('changed input', path)
    return data


def read(path):
    return json.loads(payload(path))


def bound(row):
    path = Path(row['path'])
    assert path.is_absolute() and path.is_relative_to(N), path
    data = payload(path)
    assert sha(data) == row['sha256'], path
    if 'bytes' in row:
        assert len(data) == row['bytes'], path
    return path


def archive(name, data):
    safe(N, name)
    assert name != 'index.json' and not data.startswith(b'\x7fELF'), name
    assert not name.endswith(('.tar.gz', '.tar', '.zip', '.pyc')), name
    assert records.setdefault(name, data) == data, ('archive collision', name)


def check_binary(row):
    path = Path(row['path'])
    assert path in BINARY_PATHS and path.is_file() and not path.is_symlink()
    assert path.stat().st_size == row['bytes'] <= 512 * 1024 * 1024
    with path.open('rb') as source:
        actual = hashlib.file_digest(source, 'sha256').hexdigest()
    assert actual == row['sha256'], path
    inputs[str(path)] = {key: row[key] for key in ('path', 'bytes', 'sha256')}


def check_review(row, required):
    path = bound(row)
    review = read(path)
    assert review['status'].startswith('clear') and not review.get('findings'), path
    assert isinstance(review.get('files'), list) and review['files'], path
    checked = set()
    for item in review['files']:
        item_path = Path(item['path'])
        if item_path in BINARY_PATHS:
            check_binary(item)
        else:
            bound(item)
        checked.add(str(item_path))
    assert set(map(str, required)) <= checked, ('review missing selected inputs', path)
    return review


def validate_receipts():
    p = N / 'package-preparation/expected-receipts.json'
    assert sha(payload(p)) == RECEIPTS_SHA
    expected = read(p)
    observed = {}
    for name, spec in expected.items():
        path = N / 'validation' / (name + '.json')
        assert sha(payload(path)) == spec['receipt_sha256'], path
        receipt = read(path)
        assert receipt['command'] == spec['command'] and receipt['exit'] == spec['exit'], path
        assert receipt['log'] == spec['log'] and receipt['sha256'] == spec['log_sha256']
        log = payload(safe(path.parent, receipt['log']))
        assert sha(log) == receipt['sha256'], path
        if spec['results'] is not None:
            rows = re.findall(rb'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log, re.M)
            assert rows and [sum(int(row[0]) for row in rows), sum(int(row[1]) for row in rows), len(rows)] == spec['results'], name
            assert all(int(row[2]) == 0 and int(row[3]) == 0 for row in rows), name
        observed[name] = dict(exit=receipt['exit'], results=spec['results'], source=spec['source'])
    baseline = payload(N / 'validation/baseline-browser-1.log').decode()
    candidate = payload(N / 'validation/candidate-browser-1.log').decode()
    before = [f'small-images phase={phase} native=cpu-paint-budget commands=40 sources=1 old_cpu=10485760 limit=4194304 core_invocations={work} core_gpu_bytes={size} exact_pixels=262144'
              for phase, work, size in ((0, 547328, 2115360), (1, 547520, 2115392))]
    after = [f'small-images phase={phase} native=admitted commands=40 sources=1 cpu={cpu} invocations={work} gpu_bytes={size} exact_pixels=262144'
             for phase, cpu, work, size in ((0, 23040, 547328, 2115360), (1, 23232, 547520, 2115392))]
    for text, expected_lines in ((baseline, before), (candidate, after)):
        assert Counter(line for line in text.splitlines() if line.startswith('small-images ')) == Counter(expected_lines * 2)
        for name in ('loaded_small_images_click_preserves_ids_and_complete_native_pixels',
                     'confined_small_images_click_preserves_ids_and_complete_native_pixels'):
            assert text.count('test ' + name + ' ... ok') == 1
    focused = payload(N / 'validation/focused-native-2.log')
    assert b'image_loop_differential_tests::native_image_reservation_matches_the_actual_canvas_loop_debit ... ok' in focused
    return observed


def source_trees():
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == BASE
    assert read(N / 'parent-publication.json')['commit'] == BASE
    parent = read(N / 'parent-source.json')['source_sha256']
    candidate_record = read(N / 'compiled-source-2.json')
    assert sha(payload(N / 'compiled-source-2.json')) == SOURCE_SHA
    assert candidate_record['base'] == BASE
    candidate = candidate_record['source_sha256']
    assert len(parent) == 291 and len(candidate) == 297 and set(parent) <= set(candidate)
    parent_bytes = {}
    for name, digest in parent.items():
        safe(W, name)
        data = subprocess.check_output(['git', 'show', BASE + ':' + name], cwd=W)
        assert sha(data) == digest, name
        parent_bytes[name] = data
        archive('sources/parent/' + name, data)
    candidate_bytes = {}
    for name, digest in candidate.items():
        data = payload(safe(W, name))
        assert sha(data) == digest, name
        candidate_bytes[name] = data
        archive('sources/candidate/' + name, data)
    # Preserve complete prior source manifests with only their differing payloads;
    # the index specifies which parent/candidate archive tree supplies other bytes.
    delta_sources = {
        'baseline-source.json': (295, {
            'tests/vulkan_small_images.rs': N / 'browser/baseline/tests/vulkan_small_images.rs',
            'tests/support/vulkan_small_images.rs': N / 'browser/draft/tests/support/vulkan_small_images.rs',
        }),
        'compiled-source-1.json': (297, {
            'src/graphics/raster_bridge/native/scope_accounting_tests.rs': N / 'migration/scope-fixture-2/before.rs',
        }),
    }
    snapshots = {}
    for manifest, (count, overrides) in delta_sources.items():
        values = read(N / manifest)['source_sha256']
        assert len(values) == count
        if manifest == 'baseline-source.json':
            assert all(values[name] == digest for name, digest in parent.items())
        resolved = {}
        for name, digest in values.items():
            if name in parent_bytes and sha(parent_bytes[name]) == digest:
                member = 'sources/parent/' + name
            elif name in candidate_bytes and sha(candidate_bytes[name]) == digest:
                member = 'sources/candidate/' + name
            else:
                assert name in overrides, ('unresolved retained source', manifest, name)
                data = payload(overrides[name]); assert sha(data) == digest
                member = 'sources/deltas/' + manifest.removesuffix('.json') + '/' + name
                archive(member, data)
            resolved[name] = member
        snapshots[manifest] = resolved
    changed = {name: {'bytes': len(candidate_bytes[name]), 'sha256': digest}
               for name, digest in candidate.items() if parent.get(name) != digest}
    assert set(changed) == {
        'src/graphics/raster_bridge/native.rs', 'src/graphics/raster_bridge/native/tests.rs',
        'src/graphics/raster_bridge/native/rect_accounting_tests.rs',
        'src/graphics/raster_bridge/native/scope_accounting_tests.rs',
        'src/graphics/raster_bridge/native/image_accounting_tests.rs',
        'src/graphics/raster_bridge/native/image_loop_differential_tests.rs',
        'tests/vulkan_small_images.rs', 'tests/support/vulkan_small_images.rs',
        'examples/vulkan-small-images.html', 'examples/vulkan-small-images.png'}
    return changed, snapshots


def main():
    output = W / 'docs/evidence'
    summary_path = output / 'native-image-accounting.json'
    archive_path = output / 'native-image-accounting.tar.gz'
    assert not summary_path.exists() and not archive_path.exists()
    selected = read(N / 'publication-selection.json')
    assert selected['schema'] == 1
    published, snapshots = source_trees()
    checks = validate_receipts()
    before = read(N / 'before-binary.json'); after = read(N / 'candidate-binary.json')
    check_binary(before); check_binary(after)
    assert before['source']['path'] == str(N / 'parent-source.json')
    assert before['source']['sha256'] == sha(payload(N / 'parent-source.json'))
    assert before['build'] == 'validation/baseline-native-build-1.json'
    assert bound(after['compiled_source']) == N / 'compiled-source-2.json'
    assert bound(after['build_receipt']) == N / 'validation/candidate-native-build-1.json'
    assert bound(after['strip_receipt']) == N / 'validation/candidate-strip-1.json'
    bound(after['unstripped'])
    docs = [W / name for name in DOCS]
    check_review(selected['documentation_review'], docs)
    required = [N / 'compiled-source-2.json', N / 'baseline-source.json', N / 'candidate-binary.json',
                N / 'validation/full-native-1.json', N / 'validation/focused-native-2.json',
                N / 'validation/baseline-browser-1.json', N / 'validation/candidate-browser-1.json']
    check_review(selected['observation_review'], required)
    check_review(selected['package_review'], [N / 'package.py', N / 'verify-staged.py', N / 'package-preparation/expected-receipts.json'])
    for name in DOCS:
        data = payload(W / name)
        assert b'PENDING' not in data and b'**Draft:' not in data, name
        published[name] = {'bytes': len(data), 'sha256': sha(data)}
        archive('sources/publication/' + name, data)
    window = selected['window']
    if window is None:
        window_summary = {'status': 'not claimed', 'scope': 'No acquired-texture result selected.'}
    else:
        assert set(window) == {'review', 'records', 'summary'} and window['records']
        window_paths = [bound(row) for row in window['records']]
        window_review = check_review(window['review'], window_paths)
        assert window['summary']['status'] in ('verified', 'failed')
        assert window['summary'] == window_review['summary'], 'window summary was not reviewed'
        window_summary = window['summary']
    # Explicit directories only. No worktree, target, prior archive or binary recursion.
    for dirname in DIRS:
        directory = N / dirname
        if not directory.exists():
            continue
        for path in sorted(directory.rglob('*')):
            relative = path.relative_to(N)
            assert not path.is_symlink(), path
            if any(part in ('__pycache__', '.git', 'target', 'before-engine') or part.startswith('target-') for part in relative.parts):
                continue
            if not path.is_file() or path.suffix == '.pyc':
                continue
            if dirname == 'validation' and path.name.startswith('package-'):
                continue
            archive('records/' + relative.as_posix(), payload(path))
    for name in ROOT_FILES:
        archive('records/' + name, payload(N / name))
    # Selected reviews and their current input bindings may live at the root.
    for path_string in list(inputs):
        path = Path(path_string)
        if path in BINARY_PATHS or path.is_relative_to(W):
            continue
        assert path.is_relative_to(N), path
        archive('records/' + path.relative_to(N).as_posix(), payload(path))
    assert len(records) <= 2500 and sum(map(len, records.values())) <= 64 * 1024 * 1024
    manifest = {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(records.items())}
    index = {'schema': 1, 'base': BASE, 'source': SOURCE_SHA, 'records': manifest,
             'source_snapshots': snapshots, 'inputs': list(inputs.values()),
             'exclusions': ['ELF binaries (hash-bound separately)', 'build targets', 'prior evidence archives',
                            'Python caches', 'validation/package-* receipts and logs', 'post-publication records']}
    index_data = encoded(index)
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode='wb', mtime=0, filename='') as stream:
        with tarfile.open(fileobj=stream, mode='w', format=tarfile.PAX_FORMAT) as bundle:
            for name, data in [('index.json', index_data), *sorted(records.items())]:
                info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
                bundle.addfile(info, io.BytesIO(data))
    archive_data = compressed.getvalue()
    with tarfile.open(fileobj=io.BytesIO(archive_data), mode='r:gz') as bundle:
        assert bundle.getnames() == ['index.json', *sorted(records)]
        assert bundle.extractfile('index.json').read() == index_data
        for name, row in manifest.items():
            member = bundle.getmember(name); assert member.isfile() and member.size == row['bytes']
            assert sha(bundle.extractfile(member).read()) == row['sha256'], name
    # No snapshot is silently refreshed after admission.
    for row in list(inputs.values()):
        if Path(row['path']) in BINARY_PATHS:
            check_binary(row)
        else:
            bound(row)
    summary = {'schema': 1, 'status': 'validated native image accounting evidence',
               'base': BASE, 'compiled_source_sha256': SOURCE_SHA,
               'archive': archive_path.name, 'archive_bytes': len(archive_data), 'archive_sha256': sha(archive_data),
               'index_sha256': sha(index_data), 'archive_members': len(records) + 1,
               'payload_bytes': sum(map(len, records.values())), 'published_bindings': published,
               'source_files': {'parent': 291, 'baseline': 295, 'candidate': 297},
               'checks': checks, 'window': window_summary,
               'scene': {'images': 40, 'sources': 1, 'source_bytes': 16, 'width': 512, 'height': 512,
                         'parent_cpu': 10485760, 'cpu_limit': 4194304, 'candidate_cpu': [23040, 23232],
                         'core_invocations': [547328, 547520], 'core_gpu_bytes': [2115360, 2115392],
                         'pixels_per_state': 262144, 'changed_pixels': 288, 'retained_ids': 44},
               'scope': 'Admission precision under unchanged caps. CPU plan decoding is not GPU execution. No timing or Chromium-relative claim.'}
    output.mkdir(parents=True, exist_ok=True)
    with archive_path.open('xb') as target:
        target.write(archive_data)
    with summary_path.open('xb') as target:
        target.write(encoded(summary))
    print(json.dumps({'archive': str(archive_path), 'summary': str(summary_path),
                      'members': len(records) + 1, 'sha256': sha(archive_data)}))


if __name__ == '__main__':
    main()
