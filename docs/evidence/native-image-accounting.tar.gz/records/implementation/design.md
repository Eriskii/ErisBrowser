# Native image CPU-work accounting

This source-only draft replaces Native's full-viewport CPU pixel reservation for
each Image command with the destination-loop area used by `Canvas::image`. It
does not change image sampling, blending, rendering commands, shaders, fallback
ownership, or any resource limit. The intended benefit is admitting more small
image scenes to the existing Native route. No speedup or actual admission result
is claimed before root execution.

## Exact change

Only `src/graphics/raster_bridge/native.rs` changes. Its complete predecessor is
retained under `before/`; the proposed full file is under `candidate/`.

1. `preflight` still validates every original command and scope and counts every
   Image operation, key and image-command slot. Only Image is removed from
   `full_area_commands`. Line and both opacity markers retain their full-area
   reservations.
2. The existing rectangle coordinate pass becomes `geometry_pixel_work` and
   visits phases containing either Rect or Image. Its original Rect arm and
   every scope transition remain unchanged. Each phase creates a fresh
   `CoordinateState`, preserving caller clips, document/fixed offsets, nested
   fixed escape and restoration, opacity nesting, and final scope validation.
3. The new private `image_loop_work` receives the translated browser rectangle
   and current clip. It uses the same public browser `Rect::intersect` and f32
   operation order as `Canvas::image`. Nonpositive rectangle or intersection
   extents cost zero. The four loop bounds are:

   ```text
   x0 = floor(visible.x).max(0) as i32
   y0 = floor(visible.y).max(0) as i32
   x1 = ceil(visible.x + visible.width).min(target.width) as i32
   y1 = ceil(visible.y + visible.height).min(target.height) as i32
   work = max(x1 - x0, 0) * max(y1 - y0, 0)
   ```

   Images do not apply the rectangle helper's additional `ceil(clip.x/y)` lower
   bound. Their sampling loops can visit pixels subsequently discarded by
   `blend`, and that reached work must remain admitted. GPU draw coverage, final
   changed pixels and rectangle mask coverage are not valid substitutes.
4. Image work is checked into the same total as Rect work. The existing global
   CPU comparison runs before image table, glyph or coverage allocation.

## Admission and storage

The old nontext estimate was

```text
viewport_area * (image_commands + line_commands + opacity_markers) + rect_work
```

The candidate estimate is

```text
viewport_area * (line_commands + opacity_markers) + rect_work + image_loop_work
```

The unchanged limit is `(viewport_area * 16).clamp(1_000_000, 32_000_000)`.
Existing text preparation receives the remaining allowance, as before. A
missing image, transparent source, or zero-opacity ancestor still receives its
geometric upper bound: the new pass neither looks up source keys nor inspects
image alpha or layer suppression. The later complete source validation remains
unchanged, including malformed and unreferenced resources. Thus the estimate
does not attempt to equal actual executed work in cases the painter skips.

All target dimensions, command geometry and offsets have already passed the
unchanged preflight. CoordinateState normalizes active clips to the viewport.
Translated origins are within +/-2,000,000 and extents within +/-1,000,000;
intermediate integer differences fit i32. Every positive loop spans at most
1280 by 1024 target pixels. Its u64 product is therefore at most 1,310,720;
the cumulative addition remains checked. At most 256 original commands and four
phases can reach the pass. No increased limit or skipped validation is needed.

The scalar helper allocates nothing. An image-only phase now also constructs the
bounded MAX_SCOPES CoordinateState Vec used by rectangle accounting. This is new
reached preparation work and can fail with the existing phase-local
AllocationFailure. Only one such state is live at a time and it is dropped before
later image/glyph/lowering allocations. `preparation_peak_bytes` already reserves
a second complete core structural allowance for this state unconditionally;
the same allocation overlaps no additional retained payload. Its formula is
unchanged. There is no per-image cache, copied key, new image lookup, mask, row
table or command allocation in this pass.

## Preservation and failure boundaries

- Full original-command validation precedes geometry and remains byte-identical
  apart from the Image full-area membership decision. Hidden invalid tails still
  refuse the whole scene.
- Missing-image lookup behavior, Arc alias deduplication, source validation,
  lookup-table reservations, rendering/lowering, packed GPU data, invocation
  admission, and all-or-nothing plan ownership remain unchanged.
- Rect loop admission is unchanged. Lines and opacity markers retain their
  old reservations. The Probe APIs and their source files are untouched.
- The new estimate never exceeds the previous full-area Image estimate for
  already validated inputs. This does not promise successful Native admission:
  all other CPU, source, GPU and allocation limits still apply.
- For formerly admitted scenes, packed plans and reference pixels must remain
  exact. CPU-work stats and the remaining text allowance intentionally differ.
  Actual allocator failure in the newly reached bounded pass can still cause
  complete CPU fallback; no partially prepared plan is returned.

## Independent validation and integration

Root alone formats, builds, imports or executes the candidate. Script is authoring
independent tests from the predecessor painter and public plan/stat APIs without
reading this draft before its own hold. HTML owns the real Page/confined-worker
image-grid witness. No test module registration or existing-test edits are part
of this production hold.

Required checks include literal fractional lower/upper clips, negative/offscreen
and empty rectangles, finite boundary geometry, fixed escape and restoration,
phase reset, nested opacity, transparent/missing/aliased images, malformed hidden
source tails, unchanged full-area Line/opacity behavior, exact and over-by-one
CPU boundaries, and remaining glyph work. Previously admitted fixtures must keep
their full packed plans and pixels. A separately frozen icon grid should show
actual predecessor CPU refusal and candidate admission under the unchanged
limits, with a full CPU reference and acquired GPU output when supported.

One identified historical expectation needs an explicit separate migration:
`native_rect_accounting_keeps_exact_cpu_limit_and_one_pixel_refusal` groups a
missing 1x1 Image with a Line under the old 512x512 full-area debit. The Image's
new geometric debit is 1; the Line stays 262,144 and the paired opacity markers
stay 524,288. All unrelated semantic assertions must remain. Additional old
expectations must be diagnosed from retained root test results, not deleted.

Integration must first verify the current target file equals the held before
image. The draft is based on K's compiled-source-2 Native file; later publication
does not authorize silently merging a conflicting implementation. Root may add
independent test registration and formatting only with additive source bindings.
