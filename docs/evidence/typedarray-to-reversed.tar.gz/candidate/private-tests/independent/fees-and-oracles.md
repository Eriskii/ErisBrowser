# Independent toReversed private tests

`tests.raw.rs` contains fifteen groups authored from the current ECMA algorithms,
the corrected plan, and existing constructor/scalar/call helpers. The production
toReversed draft was deliberately not read before this hold. Nothing here has
been compiled, formatted, or executed. Root owns integration and execution.

The primary algorithms are [TypedArray.prototype.toReversed](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.toreversed)
and [TypedArrayCreateSameType](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-typedarray-create-same-type).
They require initial authentic/live validation, same-kind intrinsic allocation,
descending numeric reads, and ascending numeric writes. Receiver constructor,
species, and global bindings are not consulted. Every index is visited, including
an odd midpoint; source NaN payload bytes remain unchanged while newly encoded
result NaNs follow the existing scalar codec's canonical representation.

## Literal semantics

The table fixes little-endian bytes for 1, 2, 3, and 4 in all ten Number kinds.
Separate float tables use negative signaling NaNs, negative zero, positive
infinity, and fixed positive canonical NaNs for Float16/32/64. No candidate helper
or codec produces expected bytes. Aligned views retain A5/5A sentinels. Empty and
nonempty results must have distinct objects and buffers, fixed nonresizable
backing, offset zero, and the original concrete prototype.

Authored JS bodies independently cover integer extrema; poisoned source
length/constructor/prototype, concrete constructor species/name, and renamed
global bindings; argument evaluation before entry without argument coercion;
authentic detached and OOB receivers including empty cases; tracking/fixed resize
and recovery; partial trailing Uint16 elements; descriptor flags, shared saved
identity, deletion, and nonconstructibility. Genuine successful controls precede
expected error observations. Each authored body runs strict and sloppy when root
executes the tests.

## Work and heap oracles

The body contract is `46 + A + D + n*E`: fixed stages 8 + 13 + 8 + 13 + 4,
existing constructor A, and separately paid authentic target-record lookup D.
The independent allocation control calls only the old constructor. It does not
call toReversed. Stable source-only fixtures have two records after allocation,
so D is 4. Dynamic record growth and constructor expandos retain the actual old
constructor's charges, independently observed by that control during the eventual
root execution.

| Kind | Width | Read R | Write W | Element E = 8+R+W |
| --- | ---: | ---: | ---: | ---: |
| Int8 / Uint8 | 1 | 77 | 69 | 154 |
| Uint8Clamped | 1 | 77 | 85 | 170 |
| Int16 / Uint16 / Float16 | 2 | 80 | 72 | 160 |
| Int32 / Uint32 / Float32 | 4 | 86 | 78 | 172 |
| Float64 | 8 | 98 | 90 | 196 |

With no record growth or constructor expandos, A is `107 + Z`, where Z is zero
for zero bytes and otherwise `1 + ceil(n*w/8)`. Constructor heap is
`118 + 2*fields + n*w`, with fields derived from the existing object expression
`72 + sizeof(Option<AbortSlot>) + sizeof(Option<f64>)`; this is `326+n*w` on the
held 64-bit source target. The prototype key owns 118 bytes. All backing zeroing
and real record growth fees remain inherited. There is no new body allocation.

The independently reconstructed stable constructor work sequence, including the
body's initial 29 work, reaches these publication points:

| Cumulative work | Reached state |
| ---: | --- |
| 61 | prototype-key work and its 118-byte charge complete |
| 82 | saved concrete constructor's own prototype lookup complete |
| 86 | typed result ordinary shell allocated |
| 87 | free typed record slot admitted |
| 95 | authentic result record published with no backing |
| 100 | checked byte-length work complete |
| 123 | intrinsic buffer prototype lookup and buffer shell allocation complete |
| 123+Z | zeroed byte block complete |
| 124+Z | free buffer record slot admitted |
| 128+Z | intrinsic buffer record published |
| 136+Z | typed backing published |
| 140+Z | authentic target lookup complete |
| 157+Z | fresh target validation and shape checks complete |

The source remains exact at all these resource cuts. No realm rollback is
claimed: an unreturned shell or record may remain after its admission. Tests
inspect only private runtime state and require Err instead of an escaped result.
The inherited writer admits its full byte copy before mutation, so copy cuts
retain exactly complete reversed-prefix elements and a zero tail. Equal values
and clamped kinds retain their full fees.

Heap cuts cover the temporary key, typed shell, buffer shell, zero block, and
dynamic-growth endpoint. A rejected charge increases the cumulative counter
past MAX_HEAP; work rejection sets remaining work to zero. Tests do not rewrite
these established semantics. Inspection temporarily restores only work, asserts
no heap allocation, and restores the observed remaining work afterward.

Full saved calls separately require the existing `TypedArray.toReversed` name
preflight of 25 work and 53 bytes. Their outer machine/native overhead is captured
by a genuine successful saved call, then exact and one-short full-call limits are
replayed on identical fresh states. The inner operation is already checked
against the independent A/D/E arithmetic, so this outer capture does not generate
the semantic or body-fee oracle. Frame/call/stack/eval/JSON/active-join cleanup and
saved native metadata are asserted on success and terminal resource errors.

## Integration

Copy only `tests.raw.rs` to `src/script/typed_array/to_reversed/tests.rs` and add
the normal cfg(test) child declaration to the new production module. Root may
format it after retaining these raw bytes. Run the fresh raw-bootstrap diagnostic
and focused new tests before broader validation; any observed failure must retain
the original source and log before a narrow correction. No old tests, fixtures,
quotas, or expected conformance outcomes are changed by this source hold.
