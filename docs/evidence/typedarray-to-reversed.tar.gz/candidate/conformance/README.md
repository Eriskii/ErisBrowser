# Number TypedArray toReversed preparation

The proposed `typedarray-to-reversed` profile retains the complete pinned `TypedArray/prototype/toReversed` tree at Test262 revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`. Tree `81dd62f1e66f16a0265e31a328517c598feaea67` contains nine direct JavaScript bodies and no BigInt child directory. All originals are retained. Seven original helpers, two legal files and eight selected Git proof documents give 26 exact offline inputs. Extra inherited discovery proofs remain distinguishable from this selected roster.

All nine bodies have ordinary sloppy/strict scheduling: 18 modes. The source-only policy schedules 16 and excludes both modes of `this-value-invalid.js` for its detach host helper. That excluded original also contains unflagged BigInt and Object.entries dependencies; it is retained whole. `immutable.js` checks that the source remains unchanged, so it is scheduled rather than misclassified as an immutable-ArrayBuffer feature. The `change-array-by-copy` feature is admitted only in this profile. Existing 51 profile feature sets, exclusions, defaults and harness behavior remain exact.

Five independently authored positive/wrong pairs supply 20 feature observations alongside the unchanged 32 common controls. Every source first requires a working authentic copying reverse, a distinct result/backing and an unchanged source. Wrong partners throw intrinsic Error after those prerequisites, and verification requires a successful positive in the same mode. The controls cover all ten Number kinds, fresh empty/singleton results, nonaliasing between repeated copies, aligned offsets, float values and unchanged source NaN payload, intrinsic construction despite poisoned properties/global bindings, ignored conversion hooks, argument-expression resize before entry, partial trailing Uint16 bytes, invalid live bounds/detachment, and saved metadata/receiver behavior. Control JSON SHA256: `4ee0fa10856baf96b8a676766650dc91e0ebb27e83d574b48b1f8d7285d96ebc`.

The [toReversed algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.toreversed) validates the source, captures its length, creates a fresh same-kind result, and copies numeric elements in reversed order. [TypedArrayCreateSameType](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-typedarraycreatesametype) uses the intrinsic constructor rather than observable source constructor/species properties. Destination NaNs are checked numerically; no general canonical payload is required. Explicit byte literals use this runtime's already held little-endian storage contract. These controls make no shared-buffer, BigInt, complete ECMAScript conformance or performance claim.

Nine mocked protocol groups cover the complete inventory, profile-local feature admission, original host-excluded body, exact helper/proof/body hashes, paired-control identity and mode gating, protocol errors, unchanged common controls, resource health and offline import identity. Removing only the new profile additions from the AST reconstructs all 22 changed original modules: two shared tools plus 20 historical registration-test exclusions. Their prior population/count/hash oracles remain unchanged.

The author performed inert raw source retrieval, Git-tree/blob reconstruction, literal/header inspection and Python AST/source transformations only. No project importer, parser, test, formatter, compiler, engine or browser was executed. All drafts remain under this preparation directory until peer review and root-authorized copying to the new worktree.

## Root handoff

Target worktree: `/tmp/eris-typedarray-to-reversed-1/worktree`, base `73cae21cc9d469f28165d9cbb0901ed067fa7275`. After copying the held 24 tooling paths, root may run from that worktree:

```sh
python3 /tmp/eris-typedarray-reverse-1/next-method/conformance/offline_import.py
python3 -m unittest discover -s tools -p 'test_test262*.py'
python3 tools/test262_conformance.py --profile typedarray-to-reversed --binary /tmp/eris-typedarray-reverse-1/eris-js-candidate-1 --output /tmp/eris-typedarray-to-reversed-1/upstream-before.json --jobs 2
```

The published predecessor binary SHA256 is `d80f59a112cdf4fa3d5879f1b35da16d3c133e5a6ecd358f714b5276be86e121`. The offline handoff refuses an existing target, authenticates importer and all 26 inputs before/after, and has no network fallback. The network equivalent is `python3 tools/import_test262.py --profile typedarray-to-reversed`; choose one route and retain all attempts.

Before and candidate outcomes are unknown in this preparation. Preserve every mode and nonzero exit. Healthy controls do not make a report healthy when resource, timeout or adapter-error rows remain. No baseline or CI gate is proposed from unrun observations.
