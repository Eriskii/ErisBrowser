"""Root-only importer execution handoff; author has not imported project code."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WORKTREE = Path('/tmp/eris-typedarray-to-reversed-1/worktree')
TARGET = WORKTREE / 'tests/upstream/test262-typedarray-to-reversed'
if TARGET.exists():
    raise ValueError('fresh import output required')
roster_path = HERE / 'offline-inventory.json'
roster_raw = roster_path.read_bytes()
roster = json.loads(roster_raw)
pins = json.loads((HERE / 'execution-inputs.json').read_bytes())
importer_path = WORKTREE / 'tools/import_test262.py'
def digest(data):
    return hashlib.sha256(data).hexdigest()
if digest(importer_path.read_bytes()) != pins['importer_sha256'] or digest(roster_raw) != pins['offline_inventory_sha256']:
    raise ValueError('held importer or input roster changed')
files = {}
for row in roster['files']:
    path = HERE / 'offline-inputs' / row['path']
    if path.is_symlink():
        raise ValueError('offline source symlink')
    data = path.read_bytes()
    if len(data) != row['bytes'] or digest(data) != row['sha256']:
        raise ValueError('offline source changed: ' + row['path'])
    files[row['path']] = data
sys.dont_write_bytecode = True
spec = importlib.util.spec_from_file_location('held_to_reversed_importer', importer_path)
importer = importlib.util.module_from_spec(spec)
spec.loader.exec_module(importer)
requests = []
raw = f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
api = f'https://api.github.com/repos/{importer.REPOSITORY}/git/'
def fetch(url):
    if url.startswith(api):
        path = importer.tree_proof_path(url[len(api):])
    elif url.startswith(raw):
        path = url[len(raw):]
    else:
        raise ValueError('unbound offline URL: ' + url)
    if path not in files:
        raise ValueError('unbound offline input: ' + path)
    requests.append(path)
    return files[path]
importer.fetch = fetch
importer.import_corpus(TARGET, 'typedarray-to-reversed')
if len(requests) != 26 or set(requests) != files.keys():
    raise ValueError('offline request inventory differs from 9 sources, 9 auxiliaries, 8 proofs')
for path, data in files.items():
    if (HERE / 'offline-inputs' / path).read_bytes() != data:
        raise ValueError('offline input changed during import: ' + path)
if digest(importer_path.read_bytes()) != pins['importer_sha256'] or roster_path.read_bytes() != roster_raw:
    raise ValueError('held source/roster changed during import')
print(json.dumps(dict(profile='typedarray-to-reversed', offline_requests=len(requests),
                      network=False, engine=False, bodies=9, modes=18), sort_keys=True))
