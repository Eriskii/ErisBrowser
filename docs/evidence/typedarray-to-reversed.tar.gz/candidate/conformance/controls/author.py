"""Author independent JavaScript source bytes only; never parse or execute them."""
from pathlib import Path
import hashlib
import json

C = Path(__file__).resolve().parent
def sha(data):
    return hashlib.sha256(data).hexdigest()

guard = '''var owner = Object.getPrototypeOf(Uint8Array.prototype);
var copy = owner.toReversed;
if (typeof copy !== 'function') throw new TypeError('toReversed prerequisite');
var guard = new Uint8Array([2, 4]), proof = copy.call(guard);
if (!ArrayBuffer.isView(proof) || proof === guard || proof.buffer === guard.buffer || proof[0] !== 4 || proof[1] !== 2 || guard[0] !== 2 || guard[1] !== 4) throw new TypeError('working copying reverse prerequisite');
'''
pairs = [
('ten-kinds-and-fresh-results', '''var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array];
var reversed = 0, original = 0, authentic = 0, fresh = 0;
for (var i = 0; i < kinds.length; i++) {
  var a = new kinds[i]([1, 2, 3]), b = copy.call(a);
  if (b.length === 3 && b[0] === 3 && b[1] === 2 && b[2] === 1) reversed++;
  if (a[0] === 1 && a[1] === 2 && a[2] === 3) original++;
  if (ArrayBuffer.isView(b) && Object.getPrototypeOf(b) === kinds[i].prototype) authentic++;
  if (b !== a && b.buffer !== a.buffer && b.byteOffset === 0 && b.buffer.resizable === false) fresh++;
}
var empty = new Uint8Array(0), e = copy.call(empty);
var single = new Uint8Array([7]), s = copy.call(single);
var four = new Uint8Array([1, 2, 3, 4]), first = copy.call(four), second = copy.call(four);
first[0] = 9; four[0] = 8;
var actual = [reversed, original, authentic, fresh, e !== empty, e.buffer !== empty.buffer, e.length,
  s !== single, s.buffer !== single.buffer, s[0], single[0], first !== second, first.buffer !== second.buffer,
  first[0], first[3], second[0], second[3], four[0], four[3]].join(',');
''', '10,10,10,10,true,true,0,true,true,7,7,true,true,9,1,4,1,8,4',
     '10,10,10,10,true,true,0,true,true,7,7,true,true,9,8,4,8,8,4'),
('offset-and-floating-copy', '''var buffer = new ArrayBuffer(10), raw = new Uint8Array(buffer);
for (var i = 0; i < 10; i++) raw[i] = 165;
var source = new Uint16Array(buffer, 2, 3); source[0] = 4660; source[1] = 22136; source[2] = 39612;
var copied = copy.call(source), result = [copied[0], copied[1], copied[2]].join(',');
copied[0] = 7;
var bytes = [];
for (var j = 0; j < 10; j++) bytes.push(raw[j]);
var hb = new ArrayBuffer(6), hu = new Uint8Array(hb);
hu[0] = 0; hu[1] = 60; hu[2] = 1; hu[3] = 124; hu[4] = 0; hu[5] = 128;
var h = new Float16Array(hb), hc = copy.call(h);
var f = new Float32Array([-0, Infinity, -Infinity, NaN]), fc = copy.call(f);
var d = new Float64Array([NaN, -0]), dc = copy.call(d);
var actual = result + ';' + bytes.join(',') + ';' +
  [copied.byteOffset, copied.buffer.byteLength, Object.is(hc[0], -0), hc[1] !== hc[1], hc[2] === 1,
   hu[2], hu[3], fc[0] !== fc[0], fc[1] === -Infinity, fc[2] === Infinity, Object.is(fc[3], -0),
   Object.is(dc[0], -0), dc[1] !== dc[1], Object.is(d[1], -0)].join(',');
''', '39612,22136,4660;165,165,52,18,120,86,188,154,165,165;0,6,true,true,true,1,124,true,true,true,true,true,true,true',
     '39612,22136,4660;165,165,52,18,120,86,7,0,165,165;0,6,true,true,true,1,124,true,true,true,true,true,true,true'),
('intrinsic-allocation-and-ignored-hooks', '''var Original = Uint8Array, prototype = Original.prototype;
var source = new Original([1, 2, 3]), hooks = 0, effects = 0;
function poison() { hooks++; throw new Error('unexpected copying reverse hook'); }
Object.defineProperty(source, 'length', {get:poison});
Object.defineProperty(source, 'constructor', {get:poison});
Object.defineProperty(Original, Symbol.species, {get:poison, configurable:true});
var ordinary = {};
Object.defineProperty(ordinary, '0', {get:poison});
Object.setPrototypeOf(source, ordinary);
source.note = 17;
var extra = {valueOf:poison, toString:poison}; extra[Symbol.toPrimitive] = poison;
globalThis.Uint8Array = poison;
var result = copy.call(source, (effects++, extra), extra);
var actual = [Object.getPrototypeOf(result) === prototype, ArrayBuffer.isView(result),
  result[0], result[1], result[2], source[0], source[1], source[2], hooks, effects,
  source.note, Object.prototype.hasOwnProperty.call(result, 'note')].join(',');
''', 'true,true,3,2,1,1,2,3,0,1,17,false', 'true,true,3,2,1,1,2,3,1,1,17,false'),
('resize-and-initial-validation', '''var buffer = new ArrayBuffer(10, {maxByteLength:12});
if (typeof buffer.resize !== 'function') throw new TypeError('resize prerequisite');
var tracking = new Uint16Array(buffer, 2);
tracking[0] = 258; tracking[1] = 772; tracking[2] = 1286; tracking[3] = 1800;
var hooks = 0, extra = {valueOf:function(){hooks++; return 1;}};
var result = copy.call(tracking, (buffer.resize(7), extra));
if (buffer.byteLength !== 7) throw new TypeError('working resize prerequisite');
var first = [result.length, result[0], result[1], result.byteOffset, result.buffer.byteLength, result.buffer.resizable, hooks].join(',');
buffer.resize(12);
var grown = [tracking.length, tracking[0], tracking[1], tracking[2], tracking[3], tracking[4], result.length, result[0], result[1]].join(',');
var fixed = new Uint16Array(buffer, 2, 3);
buffer.resize(5);
var outOfBounds = false;
try { copy.call(fixed); } catch (e) { outOfBounds = e instanceof TypeError; }
var end = new Uint16Array(buffer, 4), empty = copy.call(end);
buffer.resize(3);
var invalidEnd = false;
try { copy.call(end); } catch (e) { invalidEnd = e instanceof TypeError; }
var detachedBuffer = new ArrayBuffer(1), detached = new Uint8Array(detachedBuffer);
if (typeof detachedBuffer.transfer !== 'function') throw new TypeError('transfer prerequisite');
var moved = detachedBuffer.transfer();
if (moved.byteLength !== 1 || detachedBuffer.byteLength !== 0) throw new TypeError('working transfer prerequisite');
var invalidDetached = false;
try { copy.call(detached); } catch (e) { invalidDetached = e instanceof TypeError; }
var actual = first + ';' + grown + ';' + [outOfBounds, empty.length, empty !== end,
  empty.buffer !== buffer, invalidEnd, invalidDetached].join(',');
''', '2,772,258,0,4,false,0;5,258,772,6,0,0,2,772,258;true,0,true,true,true,true',
     '2,772,258,0,4,false,0;5,258,772,6,0,0,5,772,258;true,0,true,true,true,true'),
('metadata-saved-identity-and-receiver', '''var descriptor = Object.getOwnPropertyDescriptor(owner, 'toReversed');
var nd = Object.getOwnPropertyDescriptor(copy, 'name'), ld = Object.getOwnPropertyDescriptor(copy, 'length');
var metadata = descriptor.value === copy && descriptor.writable && !descriptor.enumerable && descriptor.configurable &&
  nd.value === 'toReversed' && !nd.writable && !nd.enumerable && nd.configurable &&
  ld.value === 0 && !ld.writable && !ld.enumerable && ld.configurable &&
  Object.getPrototypeOf(copy) === Function.prototype && !Object.prototype.hasOwnProperty.call(copy, 'prototype');
if (typeof Reflect.construct !== 'function') throw new TypeError('construct prerequisite');
function Constructor() { this.proof = 7; }
if (Reflect.construct(Constructor, []).proof !== 7) throw new TypeError('working construct prerequisite');
var nonconstructor = false;
try { Reflect.construct(copy, []); } catch (e) { nonconstructor = e instanceof TypeError; }
var invalid = [null, undefined, true, 12, 'abc', {}, [], Object.create(Uint8Array.prototype), new ArrayBuffer(0), new DataView(new ArrayBuffer(0))];
var rejected = 0;
for (var i = 0; i < invalid.length; i++) {
  try { copy.call(invalid[i]); } catch (e) { if (e instanceof TypeError) rejected++; }
}
var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array], shared = 0;
for (var j = 0; j < kinds.length; j++) if (kinds[j].prototype.toReversed === copy) shared++;
var deleted = delete owner.toReversed, source = new Uint8Array([3, 4]), result = copy.call(source);
var actual = [metadata, nonconstructor, rejected, shared, deleted, owner.toReversed === undefined,
  result !== source, result.buffer !== source.buffer, result[0], result[1], source[0], source[1]].join(',');
''', 'true,true,10,10,true,true,true,true,4,3,3,4', 'true,true,10,10,true,true,false,false,4,3,3,4'),
]
rows = []
for name,body,good,bad in pairs:
    prefix = guard + body
    for positive,literal in [(True,good),(False,bad)]:
        source = prefix + 'if (actual !== '+json.dumps(literal)+") throw new Error('independent toReversed literal mismatch');\n"
        rows.append(dict(name=name+('-positive' if positive else '-wrong'),pair=name,positive=positive,
            modes=['sloppy','strict'],source=source,source_sha256=sha(source.encode()),
            common_prefix_sha256=sha(prefix.encode()),expected_literal=literal))
raw = (json.dumps(dict(schema=1,scope='Number TypedArray.toReversed independent paired source controls',controls=rows),indent=2)+'\n').encode()
(C/'controls.json').write_bytes(raw)
(C.parent/'draft/tools/typedarray-to-reversed-controls.json').write_bytes(raw)
receipt = dict(status='frozen source-only before any toReversed conformance execution',source=str(C/'controls.json'),
    source_bytes=len(raw),source_sha256=sha(raw),pairs=5,mode_observations=20,guard_sha256=sha(guard.encode()),
    specification='https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.toreversed',
    scope='Ten Number kinds; little-endian byte literals match retained runtime storage contract; destination NaNs checked numerically, source NaN payload remains exact.',
    execution='No JS parser, project importer, compiler, tests, engine or browser')
(C/'source-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
