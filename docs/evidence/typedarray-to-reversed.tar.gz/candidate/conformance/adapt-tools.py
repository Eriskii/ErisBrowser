"""Source transformations only; never import or execute project modules."""
from pathlib import Path
import difflib
import json

C = Path(__file__).resolve().parent
D = C / 'draft/tools'
O = C / 'original'
inventory = json.loads((C / 'discovery/inventory.json').read_bytes())
control_hash = json.loads((C / 'controls/source-ready.json').read_bytes())['source_sha256']

def replace_once(source, old, new):
    assert source.count(old) == 1, (old, source.count(old))
    return source.replace(old, new, 1)

p = D / 'import_test262.py'
s = (O / p.name).read_text()
s = replace_once(s, 'TYPEDARRAY_REVERSE_DIRECTORIES =',
                 'TYPEDARRAY_TO_REVERSED_DIRECTORIES = ' + repr(inventory['directories']) + '\n' +
                 'TYPEDARRAY_TO_REVERSED_HELPERS = ' + repr(set(inventory['helpers'])) + '\nTYPEDARRAY_REVERSE_DIRECTORIES =')
s = replace_once(s, 'ITERATION_SUBTREES = {', "ITERATION_SUBTREES = {\n    'typedarray-to-reversed': {'TypedArray/prototype/toReversed': '81dd62f1e66f16a0265e31a328517c598feaea67'},")
s = replace_once(s, 'ITERATION_HELPERS = {', "ITERATION_HELPERS = {\n    'typedarray-to-reversed': TYPEDARRAY_TO_REVERSED_HELPERS,")
s = replace_once(s, "TREE_PROFILES = {'typedarray-reverse'", "TREE_PROFILES = {'typedarray-to-reversed', 'typedarray-reverse'")
s = replace_once(s, "PROFILES = {'typedarray-reverse':", "PROFILES = {'typedarray-to-reversed': TYPEDARRAY_TO_REVERSED_DIRECTORIES, 'typedarray-reverse':")
s = replace_once(s, "PROFILE_ROOTS = {'typedarray-reverse':", "PROFILE_ROOTS = {'typedarray-to-reversed': 'test/built-ins', 'typedarray-reverse':")
anchor = "    if profile == 'typedarray-reverse' and harness != TYPEDARRAY_REVERSE_HELPERS:"
s = replace_once(s, anchor, "    if profile == 'typedarray-to-reversed' and harness != TYPEDARRAY_TO_REVERSED_HELPERS:\n        raise ValueError('TypedArray toReversed requested harness differs from the frozen seven helpers')\n" + anchor)
s = replace_once(s, '    scope = {', "    scope = {\n        'typedarray-to-reversed': 'all 9 original .js files in the complete TypedArray prototype toReversed tree, which has no BigInt child directory; full root-linked Git proof; no implementation',")
p.write_text(s)

p = D / 'test262_conformance.py'
s = (O / p.name).read_text()
s = replace_once(s, 'TYPEDARRAY_REVERSE_FEATURES =', "TYPEDARRAY_TO_REVERSED_FEATURES = {'TypedArray', 'Symbol.species', 'Reflect.construct',\n                                  'change-array-by-copy'}\nTYPEDARRAY_REVERSE_FEATURES =")
s = replace_once(s, "PROFILE_FEATURES = {'typedarray-reverse':", "PROFILE_FEATURES = {'typedarray-to-reversed': TYPEDARRAY_TO_REVERSED_FEATURES, 'typedarray-reverse':")
assert s.count("profile in {'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views'") == 2
s = s.replace("profile in {'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views'", "profile in {'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views'")
a = s.index('def typedarray_reverse_preflight_variants():')
b = s.index('\ndef typedarray_fill_preflight_variants():', a)
copied = s[a:b].replace('typedarray_reverse', 'typedarray_to_reversed').replace('typedarray-reverse', 'typedarray-to-reversed').replace('TypedArray reverse', 'TypedArray toReversed').replace('c85cbbe7be55bc264403165a554d3b85de858358bd97583d614b66d766669c28', control_hash)
s = s[:a] + copied + '\n' + s[a:]
s = replace_once(s, "    if profile == 'typedarray-reverse':\n        variants += typedarray_reverse_preflight_variants()", "    if profile == 'typedarray-to-reversed':\n        variants += typedarray_to_reversed_preflight_variants()\n    if profile == 'typedarray-reverse':\n        variants += typedarray_reverse_preflight_variants()")
s = replace_once(s, "            if ((profile == 'typedarray-reverse'", "            if ((profile == 'typedarray-to-reversed' and name.startswith('typedarray-to-reversed-'))\n                    or (profile == 'typedarray-reverse'")
a = s.index("    if profile == 'typedarray-reverse':\n        # Preserve")
b = s.index("    if profile == 'typedarray-fill':\n        # Preserve", a)
s = s[:a] + s[a:b].replace('typedarray-reverse', 'typedarray-to-reversed') + s[a:]
p.write_text(s)

# Only exclude the newly registered profile from historical population contracts.
for source in sorted(O.glob('test_test262*.py')):
    lines = source.read_text().splitlines(True)
    for i, line in enumerate(lines):
        if "'typedarray-reverse'" in line and any(x in line for x in ['excluded=', 'excluded =', 'if profile in', 'if name in', 'set(runner.PROFILES)']):
            lines[i] = line.replace("'typedarray-reverse'", "'typedarray-to-reversed', 'typedarray-reverse'", 1)
    s = ''.join(lines)
    if source.name == 'test_test262_typedarray_reverse.py':
        s = replace_once(s, 'len(runner.PROFILES), 51', "len(set(runner.PROFILES) - {'typedarray-to-reversed'}), 51")
    (D / source.name).write_text(s)

changed = []
for old in sorted(O.iterdir()):
    after = D / old.name
    if old.read_bytes() != after.read_bytes():
        changed.append('tools/' + old.name)
        (C / (old.name + '.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True), after.read_text().splitlines(True), fromfile='before/tools/' + old.name, tofile='tools/' + old.name)))
(C / 'changed-existing-paths.json').write_text(json.dumps(changed, indent=2) + '\n')
print(json.dumps(dict(changed_existing_paths=len(changed))))
