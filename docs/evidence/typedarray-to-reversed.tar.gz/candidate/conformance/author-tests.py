"""Adapt mocked protocol source only; never import or execute project modules."""
from pathlib import Path
import json
C = Path(__file__).resolve().parent
s = (C/'original/test_test262_typedarray_reverse.py').read_text()
s = s.replace('typedarray-reverse','typedarray-to-reversed').replace('TypedArrayReverseTests','TypedArrayToReversedTests')
s = s.replace('TypedArray/prototype/reverse','TypedArray/prototype/toReversed')
s = s.replace('Pinned reverse inputs','Pinned toReversed inputs')
s = s.replace("PAIRS = ['ten-number-kinds', 'offset-and-special-values', 'initial-validation-and-resize',\n         'internal-length-and-ignored-hooks', 'metadata-saved-identity']",
              "PAIRS = ['ten-kinds-and-fresh-results', 'offset-and-floating-copy',\n         'intrinsic-allocation-and-ignored-hooks', 'resize-and-initial-validation',\n         'metadata-saved-identity-and-receiver']")
s = s.replace("DIRECTORIES = {'TypedArray/prototype/toReversed': 16, 'TypedArray/prototype/toReversed/BigInt': 6}",
              "DIRECTORIES = {'TypedArray/prototype/toReversed': 9}")
s = s.replace("FEATURES = {'TypedArray', 'ArrayBuffer', 'Symbol', 'Reflect.construct',\n            'arrow-function', 'resizable-arraybuffer'}",
              "FEATURES = {'TypedArray', 'Symbol.species', 'Reflect.construct', 'change-array-by-copy'}")
s = s.replace('(22, 44, 32, [])','(9, 18, 18, [])').replace('[22, 22]','[9, 9]')
s = s.replace("'testTypedArray.js', 'detachArrayBuffer.js', 'resizableArrayBufferUtils.js',", "'testTypedArray.js', 'detachArrayBuffer.js',")
s = s.replace('reasons.count(None), 26','reasons.count(None), 16')
s = s.replace("features: BigInt'), 12","features: BigInt'), 0")
s = s.replace("features: immutable-arraybuffer'), 2","features: immutable-arraybuffer'), 0")
s = '\n'.join(line for line in s.split('\n') if 'reasons.count(\'TypedArray reverse policy' not in line)
s = s.replace('is None for c in cases), 28','is None for c in cases), 16')
s = s.replace("'/BigInt/' in c['file'] for c in cases), 12", "'/BigInt/' in c['file'] for c in cases), 0")
s = s.replace('len(runner.PROFILES), 51', "len(runner.PROFILES), 52)\n        self.assertTrue(all('change-array-by-copy' not in features for profile, features in runner.PROFILE_FEATURES.items() if profile != PROFILE)")
s = s.replace('c85cbbe7be55bc264403165a554d3b85de858358bd97583d614b66d766669c28',json.loads((C/'controls/source-ready.json').read_bytes())['source_sha256'])
s = s.replace('test/built-ins/TypedArray/prototype/toReversed/BigInt/detached-buffer.js','test/built-ins/TypedArray/prototype/toReversed/this-value-invalid.js')
s = s.replace('test/built-ins/TypedArray/prototype/toReversed/immutable-buffer.js','test/built-ins/TypedArray/prototype/toReversed/immutable.js')
s = s.replace("'harness/resizableArrayBufferUtils.js'", "'harness/compareArray.js'")
a = s.index('    def test_full_roster_requires_unselected_ancestors_and_excluded_bigint_entries(self):')
b = s.index('    def test_serialized_helper_policy_and_resource_health_are_bound(self):',a)
s = s[:a] + '''    def test_full_roster_requires_ancestors_and_excluded_host_body(self):
        ancestor = 'trees/37185873f6a6ea631208a82eb48c6c007216dcdd'
        recursive = 'trees/81dd62f1e66f16a0265e31a328517c598feaea67?recursive=1'
        for route, name in [(ancestor, 'constructor.js'), (recursive, 'this-value-invalid.js')]:
            with self.subTest(route=route), self.assertRaises(ValueError):
                importer.profile_tree_inventory(PROFILE, proof_reader(route, lambda d:
                    d['tree'].__setitem__(slice(None), [r for r in d['tree'] if r['path'] != name])))
        _, files, cases, _, _ = runner.load_corpus(CORPUS, PROFILE)
        key = 'test/built-ins/TypedArray/prototype/toReversed/this-value-invalid.js'
        self.assertIn(key, files)
        self.assertIn(b"'1n': 1n", files[key])
        retained = [c for c in cases if c['file'] == key]
        self.assertEqual(len(retained), 2)
        self.assertTrue(all(runner.unsupported_reason(c, FEATURES, PROFILE) ==
                            'Test262 host hooks are not implemented (conservative source check)' for c in retained))
        # immutable.js tests nonmutation of the source, not immutable ArrayBuffers.
        immutable = [c for c in cases if c['file'].endswith('/immutable.js')]
        self.assertEqual(len(immutable), 2)
        self.assertTrue(all(runner.unsupported_reason(c, FEATURES, PROFILE) is None for c in immutable))

''' + s[b:]
s = s.replace("[(PROFILE, 26), ('typedarray-fill', 54), ('typedarray-search', 158), ('typedarray-views', 110)]",
              "[(PROFILE, 16), ('typedarray-reverse', 26), ('typedarray-fill', 54), ('typedarray-search', 158), ('typedarray-views', 110)]")
s = s.replace("timeout_seconds=3.0, excluded_harness=['resizableArrayBufferUtils.js'])", "timeout_seconds=3.0)\n                if profile != PROFILE:\n                    expected['excluded_harness'] = ['resizableArrayBufferUtils.js']")
(C/'draft/tools/test_test262_typedarray_to_reversed.py').write_text(s)
print('Wrote nine source-only toReversed protocol groups')
