"""Data-only full-row comparison. Root executes after source review.

The 44 established reports must remain exact. New toReversed observations are
reported separately, including unhealthy statuses and unguarded before passes.
No project runner, parser or adapter is imported or executed.
"""
from collections import Counter
from pathlib import Path
import hashlib
import json

I = Path(__file__).resolve().parent
H = Path('/tmp/eris-typedarray-reverse-1')
inputs = {}
errors = []
BAD_RUN_STATUSES = {'adapter-error', 'timeout', 'resource'}
IDENTITY = ['id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative']
POLICY = ['suite', 'full_test262_conformance', 'repository', 'revision',
          'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256',
          'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def payload(path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    row = dict(path=str(path), bytes=len(data), sha256=sha(data))
    assert inputs.setdefault(str(path), row) == row, ('input changed', path)
    return data


def read(path):
    return json.loads(payload(path))


def row_hash(rows):
    return sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())


def bound_adapter(root, name):
    adapter = read(root / name)
    binary = root / adapter['binary']
    data = payload(binary)
    assert len(data) == adapter['bytes'] and sha(data) == adapter['sha256'], binary
    source_path = root / adapter['source_binding']
    source = read(source_path)
    assert inputs[str(source_path)]['sha256'] == adapter['source_binding_sha256']
    for path, digest in source['source_sha256'].items():
        assert sha(payload(root / 'worktree' / path)) == digest, path
    for key in ['build', 'full_suite']:
        receipt = read(root / adapter[key])
        assert receipt['exit'] == 0, (name, key)
        log = payload(root / 'validation' / receipt['log'])
        assert sha(log) == receipt['sha256'], (name, key)
    return adapter


def report_health(report, local=False):
    cases = report['cases']
    assert len({r['id'] for r in cases}) == len(cases)
    # Module exclusions exist in the inherited for-of corpus.
    assert all(r['mode'] in {'sloppy', 'strict', 'module'} for r in cases)
    counts = dict(Counter(r['status'] for r in cases))
    assert set(counts) <= {'passed', 'failed', 'unsupported', 'resource', 'timeout', 'adapter-error'}
    if local:
        controls = report['controls']
        assert report['binding_failures'] == []
        assert report['observed_after'] == report['inputs'] + [dict(
            path=report['binary'], bytes=report['binary_bytes'], sha256=report['binary_sha256'])]
        for row in report['observed_after']:
            data = payload(Path(row['path']))
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
        assert all(r['matches_expectation'] for r in cases)
        assert all(r['verified'] for r in controls)
        return dict(counts=counts, controls=len(controls), controls_verified=len(controls),
                    preflight_healthy=True, report_healthy=True)
    assert report['counts'] == counts and report['mode_cases'] == len(cases)
    assert report['runner_policy_sha256'] == sha(json.dumps(report['runner_policy'], sort_keys=True).encode())
    controls = report['harness_preflight']
    assert len({(r['name'], r['result']['mode']) for r in controls}) == len(controls)
    preflight = all(r['verified'] for r in controls)
    assert report['harness_preflight_passed'] == preflight
    return dict(counts=counts, controls=len(controls),
                controls_verified=sum(r['verified'] for r in controls),
                preflight_healthy=preflight,
                report_healthy=preflight and not any(counts.get(s) for s in BAD_RUN_STATUSES))


def compare_rows(name, before, after, local=False, established=True):
    policy_keys = ['matrix_sha256', 'schema', 'scope'] if local else POLICY
    for key in policy_keys:
        if before[key] != after[key]:
            errors.append([name, 'policy or population changed', key])
    b_rows, a_rows = before['cases'], after['cases']
    assert [r['id'] for r in b_rows] == [r['id'] for r in a_rows], name
    b_health, a_health = report_health(before, local), report_health(after, local)
    if established:
        assert b_health['preflight_healthy'] and a_health['preflight_healthy'], name
    changes, losses, transitions = [], [], Counter()
    for b, a in zip(b_rows, a_rows):
        for key in IDENTITY:
            if b[key] != a[key]:
                errors.append([name, b['id'], 'case identity changed', key])
        transitions[b['status'] + ' -> ' + a['status']] += 1
        if b['status'] == 'passed' and a['status'] != 'passed':
            losses.append(a['id'])
        if b != a:
            changes.append(dict(id=a['id'], before=b, after=a,
                changed_fields=sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k)),
                before_sha256=row_hash(b), after_sha256=row_hash(a)))
    ck = 'controls' if local else 'harness_preflight'
    b_controls, a_controls = before[ck], after[ck]
    assert len(b_controls) == len(a_controls), name
    if established:
        if changes:
            errors.append([name, 'established case rows changed', len(changes)])
        if losses:
            errors.append([name, 'prior pass losses', losses])
        if b_controls != a_controls:
            errors.append([name, 'established control rows changed'])
        if local:
            assert before['summary'] == after['summary']
    else:
        for b, a in zip(b_controls, a_controls):
            assert (b['name'], b['expected']) == (a['name'], a['expected'])
            assert all(b['result'][key] == a['result'][key] for key in IDENTITY)
            assert ('prerequisite' in b) == ('prerequisite' in a)
            if 'prerequisite' in b:
                assert {k:v for k,v in b['prerequisite'].items() if k != 'verified'} == {
                    k:v for k,v in a['prerequisite'].items() if k != 'verified'}
    return dict(report=name, case_rows=len(a_rows), exact_case_rows=len(a_rows)-len(changes),
        control_rows=len(a_controls), exact_control_rows=sum(a == b for a,b in zip(a_controls,b_controls)),
        before_rows_sha256=row_hash(b_rows), after_rows_sha256=row_hash(a_rows),
        before_controls_sha256=row_hash(b_controls), after_controls_sha256=row_hash(a_controls),
        before_counts=b_health['counts'], after_counts=a_health['counts'],
        before_health=b_health, after_health=a_health, transitions=dict(sorted(transitions.items())),
        prior_pass_losses=losses, changed_rows=changes,
        changed_controls=[dict(before=b, after=a) for b,a in zip(b_controls,a_controls) if b != a])


def to_reversed_controls(report, frozen, harness):
    rows = report['harness_preflight']
    assert len(rows) == 52
    expected = [(c, mode) for c in frozen['controls'] for mode in c['modes']]
    assert len(expected) == 20
    indexed = {(r['name'], r['result']['mode']):r for r in rows}
    for row, (control, mode) in zip(rows[32:], expected):
        result = row['result']
        name = 'typedarray-to-reversed-' + control['name']
        source_hash = sha(control['source'].encode())
        assert source_hash == control['source_sha256'] == result['source_sha256']
        identity = dict(source_sha256=source_hash, mode=mode,
            metadata=dict(flags=[],includes=[],features=[],locale=[],negative=None), harness=harness)
        assert result['case_sha256'] == sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
        assert (row['name'], result['id'], result['file'], result['mode'], result['expected_negative']) == (
            name, 'harness-preflight:'+name, '<preflight>', mode, None)
        assert row['expected'] == ('passed' if control['positive'] else 'failed')
        correct = result['status'] == row['expected']
        if not control['positive']:
            observation = result.get('observation', {})
            correct = correct and all(observation.get(k) == v for k,v in dict(
                status='exception',phase='runtime',error_type='Error',error_identity='Error').items())
            partner = indexed[('typedarray-to-reversed-'+control['pair']+'-positive', mode)]
            pr = partner['result']
            assert row['prerequisite'] == dict(name=partner['name'], mode=mode,
                case_sha256=pr['case_sha256'], source_sha256=pr['source_sha256'],
                expected='passed', verified=partner['verified'])
            correct = correct and partner['verified']
        assert row['verified'] == correct


def top_receipt(root, label, report_name, report, binary, profile=None):
    receipt = read(root / 'validation' / (label + '.json'))
    log = payload(root / 'validation' / receipt['log'])
    assert sha(log) == receipt['sha256'], label
    if profile is None:
        command = ['python3','tools/typedarray_views_local.py','--engine',str(binary),
            '--engine-sha256',report['binary_sha256'],'--output',str(root/report_name)]
        expected_exit = int(not report_health(report, local=True)['report_healthy'])
    else:
        command = ['python3','tools/test262_conformance.py','--profile',profile,
            '--binary',str(binary),'--output',str(root/report_name),'--jobs','2']
        health = report_health(report)
        expected_exit = int(not health['report_healthy'] or bool(report['regressions']) or
                            report['counts'].get('passed',0) != report['mode_cases'])
    assert receipt['command'] == command, (label, receipt['command'])
    assert receipt['exit'] == expected_exit, (label, receipt['exit'], expected_exit)


before_adapter = bound_adapter(H, 'candidate-adapter-1.json')
after_adapter = bound_adapter(I, 'candidate-adapter-1.json')
assert before_adapter['sha256'] == 'd80f59a112cdf4fa3d5879f1b35da16d3c133e5a6ecd358f714b5276be86e121'
assert before_adapter['source_binding'] == after_adapter['source_binding'] == 'compiled-source-2.json'
assert before_adapter['full_suite'] == 'validation/full-native-2.json'
assert after_adapter['full_suite'] == 'validation/full-native-1.json'
plan = read(I / 'regression-plan.json')
assert plan['profiles'] == read(H / 'regression-plan.json')['profiles']
assert len(plan['profiles']) == len({p['profile'] for p in plan['profiles']}) == 38
pairs = [('upstream-1.json', 'reverse-1.json'), ('fill-1.json', 'fill-1.json'),
         ('search-1.json', 'search-1.json'),
         ('foundation-1.json', 'foundation-1.json'), ('views-1.json', 'views-1.json'),
         ('local-1.json', 'local-1.json')]
pairs += [('regressions-candidate-1/'+p['profile']+'.json',)*2 for p in plan['profiles']]
comparisons = []
for before_name, after_name in pairs:
    before, after = read(H / before_name), read(I / after_name)
    assert before['binary_sha256'] == before_adapter['sha256'], before_name
    assert after['binary_sha256'] == after_adapter['sha256'], after_name
    row = compare_rows(after_name, before, after, local=after_name == 'local-1.json')
    row.update(before_report=str(H / before_name), after_report=str(I / after_name))
    comparisons.append(row)
    if '/' not in after_name:
        profile = {'reverse-1.json':'typedarray-reverse','fill-1.json':'typedarray-fill','search-1.json':'typedarray-search',
            'foundation-1.json':'typedarray-foundation','views-1.json':'typedarray-views',
            'local-1.json':None}[after_name]
        top_receipt(H,Path(before_name).stem,before_name,before,H/before_adapter['binary'],profile)
        top_receipt(I,Path(after_name).stem,after_name,after,I/after_adapter['binary'],profile)

for p in plan['profiles']:
    for root, adapter in [(H, before_adapter), (I, after_adapter)]:
        baseline = root / 'worktree' / p['baseline']
        assert sha(payload(baseline)) == p['sha256'], p['profile']
        directory = root / 'regressions-candidate-1'
        report = read(directory / (p['profile'] + '.json'))
        receipt = read(directory / (p['profile'] + '-receipt.json'))
        assert receipt['binary_sha256'] == adapter['sha256']
        expected_command = ['python3',str(root/'worktree/tools/test262_conformance.py'),
            '--binary',str(root/adapter['binary']),'--profile',p['profile'],'--baseline',str(baseline),
            '--output',str(directory/(p['profile']+'.json')),'--jobs','2']
        assert receipt['command'] == expected_command
        for key in ['counts','mode_cases','harness_preflight_passed']:
            assert receipt[key] == report[key]
        for key in ['regressions','improvements']:
            assert receipt[key] == len(report[key])
        # Historical improvements already existed versus older frozen baselines.
        assert receipt['exit'] == int(not report_health(report)['report_healthy'] or bool(report['regressions'])) == 0
        for kind, extension in [('report','.json'),('log','.log')]:
            assert sha(payload(directory/(p['profile']+extension))) == receipt[kind+'_sha256']

before, after = read(I / 'upstream-before.json'), read(I / 'upstream-1.json')
assert before['binary_sha256'] == before_adapter['sha256']
assert after['binary_sha256'] == after_adapter['sha256']
to_reversed = compare_rows('typedarray-to-reversed', before, after, established=False)
top_receipt(I,'to-reversed-before-1','upstream-before.json',before,H/before_adapter['binary'],'typedarray-to-reversed')
top_receipt(I,'upstream-1','upstream-1.json',after,I/after_adapter['binary'],'typedarray-to-reversed')
corpus = I / 'worktree/tests/upstream/test262-typedarray-to-reversed'
manifest = read(corpus / 'manifest.json')
policy = read(I / 'conformance/policy-inventory.json')
assert manifest['test_files'] == before['source_files'] == after['source_files'] == 9
assert len(before['cases']) == len(after['cases']) == policy['modes'] == 18
assert before['corpus_manifest_sha256'] == sha(payload(corpus/'manifest.json'))
assert before['runner_policy'] == policy['policy']
assert before['runner_policy_sha256'] == policy['runner_policy_sha256']
for source in manifest['files']:
    data = payload(corpus / source['path'])
    assert len(data) == source['bytes'] and sha(data) == source['sha256']
frozen_path = I / 'conformance/controls/controls.json'
frozen = read(frozen_path)
assert payload(frozen_path) == payload(I/'worktree/tools/typedarray-to-reversed-controls.json')
assert sha(payload(frozen_path)) == '4ee0fa10856baf96b8a676766650dc91e0ebb27e83d574b48b1f8d7285d96ebc'
harness = [dict(name=n,sha256=sha(payload(corpus/'harness'/n))) for n in ['assert.js','sta.js']]
for report in [before,after]:
    to_reversed_controls(report,frozen,harness)
    # These are exactly the unchanged common controls, independently retained
    # with the previous reverse report; require their complete observed rows.
    assert report['harness_preflight'][:32] == read(H/'upstream-1.json')['harness_preflight'][:32]
    by_id = {r['id']:r for r in report['cases']}
    assert len(by_id) == 18
    for source in policy['rows']:
        for mode in source['modes']:
            row = by_id[source['path']+':'+mode]
            assert (row['file'],row['mode'],row['source_sha256']) == (source['path'],mode,source['sha256'])
            # All nine retained headers have ordinary strict/sloppy scheduling,
            # inline feature/include order, no locales or negative metadata.
            # Reconstruct from the frozen source-only inventory and exact helpers.
            metadata = source['metadata']
            assert set(metadata) == {'flags','includes','features','locale','negative'}
            assert metadata['flags'] == metadata['locale'] == [] and metadata['negative'] is None
            case_identity = dict(source_sha256=source['sha256'],mode=mode,metadata=metadata,
                harness=[dict(name=n,sha256=sha(payload(corpus/'harness'/n)))
                         for n in ['assert.js','sta.js',*metadata['includes']]])
            assert row['expected_negative'] is None
            assert row['case_sha256'] == sha(json.dumps(case_identity,sort_keys=True,ensure_ascii=True).encode())
            if source['reason']:
                assert (row['status'],row['reason']) == ('unsupported',source['reason'])
            else:
                assert row['status'] != 'unsupported'
if not to_reversed['after_health']['preflight_healthy']:
    errors.append(['typedarray-to-reversed','candidate controls unhealthy'])
to_reversed['before_passes_establish_support'] = to_reversed['before_health']['preflight_healthy']
to_reversed['before_pass_note'] = 'Passes with unhealthy method controls do not establish working toReversed support; all raw before rows are retained.'

summary = dict(profiles=len(comparisons),historical_profiles=len(plan['profiles']),
    case_rows=sum(r['case_rows'] for r in comparisons),
    exact_case_rows=sum(r['exact_case_rows'] for r in comparisons),
    control_rows=sum(r['control_rows'] for r in comparisons),
    exact_control_rows=sum(r['exact_control_rows'] for r in comparisons),
    prior_pass_losses=sum(len(r['prior_pass_losses']) for r in comparisons))
assert (summary['profiles'],summary['case_rows'],summary['control_rows']) == (44,18280,4232)
# Rehash every consumed artifact once more before publishing a fresh result.
for row in inputs.values():
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
result = dict(status='clear' if not errors else 'findings',
    scope='Full ordered case/control rows, source/binary and policy bindings; established population separate from new toReversed evidence.',
    before_commit='73cae21cc9d469f28165d9cbb0901ed067fa7275',
    before_adapter_sha256=before_adapter['sha256'],after_adapter_sha256=after_adapter['sha256'],
    summary=summary,errors=errors,comparisons=comparisons,to_reversed=to_reversed,inputs=list(inputs.values()))
with (I/'comparison.json').open('x') as output:
    json.dump(result,output,indent=2,sort_keys=True)
    output.write('\n')
print(json.dumps(dict(status=result['status'],summary=summary,
                     to_reversed_counts=to_reversed['after_counts'],to_reversed_health=to_reversed['after_health'],errors=errors)))
raise SystemExit(bool(errors))
