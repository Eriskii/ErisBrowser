from pathlib import Path
import hashlib, json, subprocess, sys
H = Path(__file__).resolve().parent
W = H / 'worktree'
summary_path = W / 'docs/evidence/typedarray-to-reversed.json'
summary = json.loads(summary_path.read_bytes())
expected = dict(summary['published_bindings'])
for name in ['docs/evidence/typedarray-to-reversed.json', 'docs/evidence/typedarray-to-reversed.tar.gz']:
    data = (W / name).read_bytes()
    expected[name] = {'bytes':len(data), 'sha256':hashlib.sha256(data).hexdigest()}
actual = subprocess.check_output(['git','diff','--cached','--name-only','-z'],cwd=W).decode().split('\0')[:-1]
assert len(actual) == len(set(actual)) and set(actual) == set(expected), (set(actual)-set(expected),set(expected)-set(actual))
for name, row in expected.items():
    data = subprocess.check_output(['git','show',':'+name],cwd=W)
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256'], name
    assert data == (W/name).read_bytes(), name
subprocess.run(['git','diff','--cached','--check','--','.',':(exclude)tests/upstream/test262-typedarray-to-reversed/**'],cwd=W,check=True)
assert not subprocess.check_output(['git','diff','--name-only'],cwd=W)
assert not subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W)
print(json.dumps({'staged_files':len(actual), 'all_staged_bytes_match_reviewed_evidence':True}))
