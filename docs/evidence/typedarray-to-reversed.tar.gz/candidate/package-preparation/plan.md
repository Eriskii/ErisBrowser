This is a source-only adaptation of the final reverse packager. Root executes it.

The selected observation is comparison.json, produced by validation/comparison-2
using unchanged compare.py. All 44 earlier reports (18,280 case rows and 4,232
control rows) remain exact. The new profile is separate: 8 passed, 8 resource,
2 unsupported, 52 verified controls, unhealthy report and no baseline/gate.

The two exact public raw reports, all compiled source copies, changed published
sources, all current validation attempts, predecessor reports/receipts/baselines,
source holds and peer reviews are retained. verify-staged.py is included through
the root-file selector. The nonexistent alternate-comparator attempt and its
root audit remain unchanged. Unrelated next-optimization work, build trees,
engine binaries, caches and the currently running package wrapper's own logs
and receipts are excluded. Packaging/publication receipts remain external.

Both observation-review.json and documentation-review.json must exist, start
with a clear status, and have every file binding rehashed. Current source and
comparison input bindings are checked again before publication. The archive is
sorted with fixed timestamps and accompanied by a manifest and summary. It
refuses existing output destinations. No comparator or package module has been
imported/executed by this author; only Python AST and retained-data/hash reads.
