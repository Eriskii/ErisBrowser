"""Author external documentation from sealed evidence; never writes the checkout."""
import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
W = B / 'worktree'
D = B / 'documentation-1'
BASE = '33ddb14aea0b8a20b7e340c4a5900abda3062f6f'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(relative, data):
    path = D / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data, str) else data)
    return path


def json_save(relative, value):
    return save(relative, json.dumps(value, indent=2, ensure_ascii=True) + '\n')


ledger_path = B / 'root/final-validation.json'
assert sha(ledger_path.read_bytes()) == 'b795ad3ecdfdc0174f7e8a4d5624157f599e4dd78b70fb63d1753e329819c4b4'
ledger = json.loads(ledger_path.read_bytes())
assert ledger['status'] == 'pass' and ledger['base'] == BASE
assert ledger['candidate']['new_groups'] == ledger['candidate']['first_execution_passed'] == 24
assert ledger['candidate']['failed_candidate_attempts'] == 0
assert ledger['parent_public']['passed'] == 0 and ledger['parent_public']['failed'] == 15
assert ledger['parent_public']['ordinary_Error_at_first_sloppy_mode'] is True
assert ledger['profiles']['cases'] == 1288 and ledger['profiles']['controls'] == 502
assert ledger['startup']['work'] == 101312 and ledger['startup']['remaining'] == 898688
assert ledger['startup']['accounted_heap'] == 1768271 and ledger['startup']['objects'] == 756
assert ledger['startup']['delta'] == dict(work=326, accounted_heap=3253, objects=1)

bound_records = []


def verify_bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and value['path'].startswith('/'):
            actual = bind(Path(value['path']))
            assert all(actual[k] == value[k] for k in actual), value['path']
            bound_records.append(actual)
        for child in value.values():
            verify_bindings(child)
    elif isinstance(value, list):
        for child in value:
            verify_bindings(child)


verify_bindings(ledger)
assert (B / 'source-final.json').read_bytes() == (B / 'source-candidate-1.json').read_bytes()
rust_checks = []
for row, total in zip(ledger['rust']['runs'], (3221, 3575)):
    log = Path(row['log']['path']).read_text()
    matches = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log)
    totals = [sum(int(values[i]) for values in matches) for i in range(5)]
    assert len(matches) == 52 and totals == [total, 0, 0, 0, 0] == row['totals']
    receipt = json.loads(Path(row['receipt']['path']).read_bytes())
    assert receipt['exit'] == 0 and '--include-ignored' in receipt['command']
    rust_checks.append(dict(configuration=row['configuration'], rows=52, totals=totals,
                            log=row['log'], receipt=row['receipt']))
for name in ('clippy-default-1', 'clippy-host-vulkan-1', 'fmt-check-1'):
    receipt = json.loads((B / 'validation' / (name + '.json')).read_bytes())
    assert receipt['exit'] == 0
    if name.startswith('clippy'):
        assert '--all-targets' in receipt['command'] and receipt['command'][-2:] == ['-D', 'warnings']

profile_checks = []
for row in ledger['profiles']['profiles']:
    name = row['name']
    current_path = B / ('upstream-' + name + '-1.json')
    parent_path = B / 'replay-parent' / current_path.name
    current = json.loads(current_path.read_bytes())
    parent = json.loads(parent_path.read_bytes())
    assert sha(current_path.read_bytes()) == row['sha256']
    for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256', 'corpus_manifest_sha256'):
        assert current[key] == parent[key], (name, key)
    assert len(current['cases']) == row['cases']
    assert len(current['harness_preflight']) == row['controls']
    assert current['counts'] == row['counts']
    assert current['regressions'] == current['improvements'] == []
    assert current['harness_preflight_passed'] is True
    assert all(item['verified'] is True for item in current['harness_preflight'])
    profile_checks.append(dict(name=name, current=bind(current_path), parent=bind(parent_path),
                               complete_arrays_exact=True, policies_and_corpus_exact=True,
                               cases=row['cases'], controls=row['controls'], counts=row['counts']))
assert sum(r['cases'] for r in profile_checks) == 1288
assert sum(r['controls'] for r in profile_checks) == 502
for row in ledger['binaries']:
    binary = Path(row['binary']).read_bytes()
    assert len(binary) == row['bytes'] and sha(binary) == row['sha256']
    assert row['source_sha256'] == sha((B / 'source-final.json').read_bytes())
assert ledger['startup']['raw_line'] in (B / 'validation/with-resolvers-candidate-1.log').read_text()

chapter = '''# Promise.withResolvers

`Promise.withResolvers()` returns a fresh ordinary object containing `promise`,
`resolve` and `reject`, in that property order. Each is an own writable,
enumerable and configurable data property. The method has name `withResolvers`,
length zero and no constructor behavior.

The operation first creates a capability using its dynamic receiver as the
constructor. A custom constructor can return an arbitrary object and supply any
callable resolve/reject values; their exact identities move into the result.
The result uses the saved intrinsic Object prototype and own data properties,
so replacing the global Object or installing inherited setters does not
intercept publication. The method performs no `C.resolve`, species or iterator
lookup and does not invoke the returned callbacks. Extra arguments are ignored
after ordinary argument evaluation.

With the intrinsic Promise constructor, the returned callbacks retain existing
first-settlement, thenable assimilation and shared FIFO behavior. Ordinary
constructor throws propagate synchronously, preserving the thrown value.
Invalid constructors, missing callbacks and noncallable callbacks throw
TypeError. Resource and unsupported-operation failures retain terminal
suspension: author catch/finally work and queued jobs do not resume through a
later checkpoint.

The implementation reuses existing capabilities and adds no Runtime field,
state type or callback variant. Public dispatch retains its eight-unit charge;
the outer operation adds three units for capability ownership. The result
factory costs 156 on the tested warm fixture, with capability creation and
growth charged separately. These are logical work tariffs, not CPU instruction
counts or process-memory measurements.

Late installation adds one metadata bag after `Promise.any`, preserving prior
IDs and isolated helper fees. The measured constructor order grows from
length/capacity 10/10 to 11/11. That branch adds 326 work units and 3,253 accounted
bytes, including the extra upfront object slot; a spare-order fixture covers
the 306-unit branch. Raw startup consumes 101,312 units, leaves 898,688 and
accounts for 1,768,271 bytes in the recorded x86_64 run. There are 756 objects,
300 native entries, 26 prototypes and 213 globals. Trusted initialization stays
bounded at 1,000,000 work units; successful public construction still supplies
100,000 author units under the cumulative 8 MiB heap ceiling.

The published parent fails all 15 new public groups at the missing-method guard
in their first sloppy attempt. Later semantic phases, strict attempts and
terminal readbacks are unreached there. All 24 new groups pass on the first
candidate run: 12 semantic groups, three terminal groups and nine private
groups covering 67 measured operations. No candidate expectation correction is
needed.

Complete `--include-ignored` runs pass 3,221 Rust 1.88 default tests and 3,575
Rust 1.99 tests with `test262-host,vulkan-raster`. Each has 52 result rows and no
failed, ignored or filtered tests. The full parent rosters survive four boundary
renames and gain the 24 new groups. Strict all-target Clippy passes in both
configurations, and formatting passes.

Rebuilt Rust 1.88 ordinary and host adapters retain all 1,288 case records and
502 harness records across the six existing upstream profiles. Complete arrays,
policies and corpus identities match the parent, including existing failed and
unsupported outcomes; no baseline changes are made. Tooling and CI gates are
unchanged, and no full Python-suite rerun is claimed.

There is no dedicated withResolvers upstream profile in this checkpoint. Six
pinned sources were authenticated as references only. Classes, async functions
and multiple realms remain outside the current language subset. The evidence
binds 1,747 selected inputs plus a separate tracked-source census; this is not a
complete build-graph inventory or a full-conformance, security or performance
result. Earlier chapters and validation sections retain their historical scope.

The [evidence manifest](evidence/promise-with-resolvers/manifest.json) and
[source/check archive](evidence/promise-with-resolvers/sources-and-checks.tar.gz)
bind the selected source, controls, accounting and observed validation records.
'''

validation = '''## Promise.withResolvers runtime

The [withResolvers checkpoint](promise-with-resolvers.md) adds generic capability
creation followed by a fresh ordinary result with own `promise`, `resolve` and
`reject` data properties. Callback identities and ordinary constructor throws
are preserved; terminal failures retain queue suspension.

All 15 public groups fail on the published parent at the missing-method guard
in their first sloppy attempt; later phases, strict attempts and terminal
readbacks are unreached. The first candidate run passes all 24 new groups:
12 semantic, three terminal and nine private groups, with 67 measured private
operations. No candidate source or expectation correction follows execution.

Complete `--include-ignored` runs pass **3,221 Rust 1.88 default tests** and
**3,575 Rust 1.99 tests with `test262-host,vulkan-raster`**, each across 52 result
rows with no failed, ignored or filtered tests. Every parent identity survives
four selected boundary-name renames, and all 24 groups are added. Strict
all-target Clippy passes in both configurations, and formatting passes.

Observed raw startup consumes 101,312 units, leaves 898,688 and accounts for
1,768,271 bytes on the recorded x86_64 configuration. The added late metadata
bag brings the object count to 756; constructor order length/capacity grows
from 10/10 to 11/11. This branch adds 326 work and 3,253 accounted bytes.
Trusted work remains 1,000,000, author work 100,000 and cumulative heap 8 MiB.

Rebuilt Rust 1.88 ordinary and host adapters preserve the complete **1,288 case
and 502 harness record arrays** across all six existing upstream profiles,
including failed and unsupported outcomes. Policies, corpus identities and
baselines remain unchanged. Tooling and CI gates are unchanged; there is no
full Python-suite rerun or dedicated withResolvers upstream profile. Six pinned
sources are retained only as authenticated references. The selected input
inventory and separate tracked-source census do not claim a complete build
graph. Historical sections below remain byte-exact.

'''

inserts = {
    'README.md': ('[`AggregateError`](docs/aggregate-error.md)', '''[`Promise.withResolvers`](docs/promise-with-resolvers.md) returns a fresh
`{promise, resolve, reject}` result using a generic constructor and the exact
capability callbacks. Ordinary constructor errors remain synchronous; existing
settlement and terminal queue behavior are preserved. A dedicated upstream
profile remains separate work.

'''),
    'docs/COMPATIBILITY.md': ('[`AggregateError`](aggregate-error.md)', '''[`Promise.withResolvers`](promise-with-resolvers.md) creates a generic
capability and returns its exact promise/resolve/reject values as own writable,
enumerable and configurable data properties. The result uses the saved Object
prototype; constructor throws remain synchronous. The runtime controls cover
deferred settlement, callback identity and terminal suspension. No dedicated
withResolvers upstream profile is claimed.

'''),
    'docs/ROADMAP.md': ('Older profile policies remain unchanged.', '''[`Promise.withResolvers`](promise-with-resolvers.md) now returns a generic
capability's exact values in a fresh ordinary object under the existing limits.
Its runtime controls and six older profile replays pass their selected checks;
a dedicated withResolvers upstream profile remains separate work.
'''),
    'docs/SECURITY.md': ('## Representative limits\n', '''[`Promise.withResolvers`](promise-with-resolvers.md) creates the capability
before admitting the result object and its three own data fields. Existing
capability charges and fallible growth remain in force; partial admission does
not roll back spent work or heap accounting. Resource and unsupported-operation
failures retain sticky queue suspension. The late metadata bag uses the existing
trusted allowance without changing author-entry resets, host authority or
decoder policy. These logical charges do not establish process-memory bounds.

'''),
    'docs/VALIDATION.md': ('## Complete pinned Promise.any selection\n', validation),
}
files = []
edit_manifest = []
for relative, (anchor, insertion) in inserts.items():
    original = (W / relative).read_bytes()
    published = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=W)
    assert original == published, relative
    text = original.decode()
    assert text.count(anchor) == 1, relative
    updated = text.replace(anchor, insertion + anchor, 1)
    edits = [dict(before='', after=insertion, anchor=anchor, operation='insert-before')]
    if relative == 'docs/COMPATIBILITY.md':
        old = '`Promise.all`, `Promise.race`, `Promise.allSettled` and `Promise.any`, DOM bindings'
        new = '`Promise.all`, `Promise.race`, `Promise.allSettled`, `Promise.any` and `Promise.withResolvers`, DOM bindings'
        assert updated.count(old) == 1
        updated = updated.replace(old, new, 1)
        edits.append(dict(before=old, after=new, operation='replace'))
    restored = updated
    for edit in reversed(edits):
        assert restored.count(edit['after']) == 1
        restored = restored.replace(edit['after'], edit['before'], 1)
    assert restored.encode() == original
    before = save('before/' + relative, original)
    raw = save('raw/' + relative, updated)
    diff = save('diffs/' + relative + '.patch', ''.join(difflib.unified_diff(
        text.splitlines(True), updated.splitlines(True), fromfile='a/' + relative, tofile='b/' + relative)))
    files.append(dict(path=relative, relative_path=relative, before=bind(before), raw=bind(raw),
                      diff=bind(diff), forward_and_inverse_exact=True, published_parent_exact=True))
    edit_manifest.append(dict(relative_path=relative, edits=edits))

relative = 'docs/promise-with-resolvers.md'
assert not (W / relative).exists()
raw = save('raw/' + relative, chapter)
diff = save('diffs/' + relative + '.patch', ''.join(difflib.unified_diff(
    [], chapter.splitlines(True), fromfile='/dev/null', tofile='b/' + relative)))
files.append(dict(path=relative, relative_path=relative, before=None, raw=bind(raw),
                  diff=bind(diff), forward_and_inverse_exact=True))
edit_path = json_save('edits.json', edit_manifest)

before_validation = (D / 'before/docs/VALIDATION.md').read_bytes()
after_validation = (D / 'raw/docs/VALIDATION.md').read_bytes()
header = b'# Validation record\n\n'
assert after_validation == header + validation.encode() + before_validation[len(header):]
assert after_validation.endswith(before_validation[len(header):])
historical = []
for name in ('promise-any.md', 'promise-any-upstream.md', 'aggregate-error.md',
             'aggregate-error-upstream.md', 'promise-all.md', 'promise-race.md',
             'promise-all-settled.md', 'bootstrap-budget.md'):
    p = W / 'docs' / name
    assert p.read_bytes() == subprocess.check_output(['git', 'show', BASE + ':docs/' + name], cwd=W)
    historical.append(bind(p))

links = []
allowed_future = {
    'docs/evidence/promise-with-resolvers/manifest.json',
    'docs/evidence/promise-with-resolvers/sources-and-checks.tar.gz',
}
new_targets = {row['relative_path'] for row in files}
for row in files:
    if row['relative_path'] != 'docs/promise-with-resolvers.md':
        continue
    for target in re.findall(r'\[[^\]]+\]\(([^)]+)\)', Path(row['raw']['path']).read_text()):
        normalized = str(Path(row['relative_path']).parent / target)
        assert normalized in allowed_future or normalized in new_targets or (W / normalized).exists()
        links.append(dict(from_path=row['relative_path'], target=target,
                          target_path=normalized, future_root_publication=normalized in allowed_future))
link_path = json_save('links.json', dict(links=links, future_evidence_paths=sorted(allowed_future)))

checks = {
    'status': 'pass; documentation author readback, not independent peer',
    'final_validation': bind(ledger_path),
    'source_final': bind(B / 'source-final.json'),
    'source_final_equals_candidate1': True,
    'ledger_bindings_verified': bound_records,
    'rust_raw_totals': rust_checks,
    'profile_complete_arrays': profile_checks,
    'profile_totals': dict(cases=1288, controls=502, baselines_changed=0),
    'startup': ledger['startup'],
    'accounting': ledger['accounting'],
    'binaries': ledger['binaries'],
    'semantic_and_accounting_sources': [bind(B / p) for p in (
        'root/selection-1.json', 'production-review-1/review.json',
        'public-contract-1/source-ready.json', 'public-review-1/review.json',
        'private-contract-1/source-ready.json', 'private-review-1/review.json',
        'migrations-review-1/review.json', 'upstream-reference-1/receipt.json')],
    'historical_validation_suffix_exact': True,
    'historical_chapters_untouched': historical,
    'six_docs_only': [row['relative_path'] for row in files],
    'chapter_words': len(chapter.split()),
    'all_before_files_git_base_exact': True,
    'all_edits_forward_inverse_exact': True,
    'qualification': 'Existing failed and unsupported replay outcomes remain; no dedicated withResolvers profile, full Python rerun, remote CI result, security or performance claim. Selected inventory is not the complete build graph.',
    'execution': 'Only external documentation authoring and stdlib/hash/read-only Git evidence inspection. No project import, compiler, test, engine or live checkout write.',
}
checks_path = json_save('claims-and-checks.json', checks)
seal = dict(status='frozen six-document hold with actual final validation; external only',
            base=BASE, source_inventory=bind(B / 'source-final.json'),
            final_validation=bind(ledger_path), files=files,
            claims_and_checks=bind(checks_path), edits=bind(edit_path), links=bind(link_path),
            author=bind(Path(__file__)), publication='Root imports reviewed raw files and packages the two selected evidence paths.')
ready = json_save('source-ready.json', seal)
print(json.dumps(bind(ready)))
print(json.dumps(bind(checks_path)))
print('chapter_words', len(chapter.split()))
