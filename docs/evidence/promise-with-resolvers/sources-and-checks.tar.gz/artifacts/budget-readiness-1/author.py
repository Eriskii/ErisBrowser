from pathlib import Path
import hashlib
import json
import re

B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
D = B / 'budget-readiness-1'
W = Path('/tmp/eris-promise-any-upstream-plan-1/worktree')
P = Path('/tmp/eris-promise-any-runtime-plan-1')
parent = Path('/tmp/eris-promise-any-upstream-plan-1/source-parent.json')
inventory = json.loads(parent.read_text())

def bound(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, obj):
    path = D / name
    assert not path.exists(), str(path)
    path.write_text(json.dumps(obj, indent=2) + '\n')
    return bound(path)

symbols = {
    'S': 'sizeof(ScriptObject)', 'A': 'sizeof(Option<AbortSlot>)',
    'D': 'sizeof(Option<f64>)', 'K': 'sizeof(PropertyKey)',
    'P': 'sizeof(Property)', 'N': 'sizeof(Native)', 'U': 'sizeof(usize)',
    'V': 'sizeof(Value)', 'Bpp': '16*(K+P)+32*U+64',
}
sources = [
    'src/script.rs', 'src/script/promises.rs', 'src/script/promises/install.rs',
    'src/script/promises/semantics.rs', 'src/script/promises/factories.rs',
    'src/script/promises/all_state.rs', 'src/script/dom_prototypes.rs',
    'src/script/dom_bindings.rs', 'src/script/microtasks.rs',
    'src/script/construction.rs', 'src/script/aggregate_error.rs',
    'src/script/promises/any_quota_tests.rs',
]
source_rows = []
for rel in sources:
    row = bound(W / rel)
    assert row['sha256'] == inventory['source_sha256'][rel], rel
    row['relative'] = rel
    source_rows.append(row)

startup = json.loads((P / 'root/startup-observation.json').read_text())
raw_log = P / 'validation/any-private-1.log'
assert bound(raw_log)['sha256'] == startup['log_sha256']
assert startup['raw_line'] in raw_log.read_text()
layout = json.loads((P / 'root/layout-verification.json').read_text())
assert len(layout['rows']) == 4
for row in layout['rows']:
    expected = {'ScriptObject': 216, 'AbortSlotOption': 16, 'DateOption': 16,
                'PropertyKey': 16, 'Property': 56, 'Native': 56, 'Value': 24}
    assert all(row['layout'][k]['bytes'] == v for k, v in expected.items())

source_receipt = write('source-bindings.json', {
    'status': 'source-only exact retained-parent bindings',
    'rust_base': '90c653d813feb62d1d569864bec076c0cc92d8a5',
    'next_publication_base': 'Any upstream publication pending; its Rust inputs are unchanged',
    'parent_inventory': bound(parent), 'sources': source_rows,
    'provided_spec_paraphrase': bound(B / 'root/spec-readiness.json'),
    'retained_actual_startup': bound(P / 'root/startup-observation.json'),
    'retained_actual_startup_log': bound(raw_log),
    'retained_actual_layout': bound(P / 'root/layout-verification.json'),
    'qualification': 'The prior raw log and layout receipt are observations from their recorded targets. No withResolvers candidate, build, test, importer or engine was executed. No network or Git command was used.',
})

installer = {
    'status': 'proposed source-derived late installer; new envelope not selected',
    'symbols': symbols,
    'placement': 'Append install_promise_with_resolvers_intrinsic after install_promise_any_intrinsic. Add separate WITH_RESOLVERS_METADATA_OBJECTS=1 to upfront bootstrap capacity, leaving old constants/helpers/fees intact.',
    'identity': {
        'existing_ids': 'Preserve all prior IDs, including AggregateError prototype752/constructor753 and Promise.any bag754.',
        'new_bag': 755, 'final_objects': 756,
        'maps_unchanged': {'native': 300, 'prototype': 26, 'global': 213},
        'owner': 'Saved promises.intrinsics.constructor Native metadata ID, without cloning constructor or consulting global Promise.',
        'method': 'Distinct Native; name withResolvers, length0, Function.prototype; owner data W=true/E=false/C=true; method name/length W=false/E=false/C=true.',
        'new_property_order': 'Append after any; preexisting Symbol.species order and old property identities remain exact.',
    },
    'proposed_entry12': {
        'controls8': ['intrinsics present', 'constructor Native kind', 'metadata ID present', 'owner ID in range', 'values length10', 'order length10', 'order physical capacity >= length', 'publication/return handoff'],
        'owners4': ['length text', 'name text', 'withResolvers text', 'fresh method Value'],
        'ordering': 'Pay12 before guards and before all text allocations. Do not add an uncharged map membership query. Existing charged final Entry rejects a duplicate.',
    },
    'stages': [
        {'name': 'entry/guards', 'work': 12, 'cumulative': 12},
        {'name': 'length text, len6', 'work': 20, 'heap': 88, 'cumulative': 32},
        {'name': 'name text, len4', 'work': 16, 'heap': 80, 'cumulative': 48},
        {'name': 'withResolvers text, len13', 'work': 34, 'heap': 116, 'cumulative': 82},
        {'name': 'prepaid immutable clones: length/name key and display', 'work': 3, 'heap': 0, 'cumulative': 85},
        {'name': 'method bag header', 'work': 8, 'heap': '72+A+D', 'cumulative': 93},
        {'name': 'method order2', 'work': 1, 'heap': '2K', 'cumulative': 94},
        {'name': 'length property at count0', 'work': 9, 'heap': '280+Bpp', 'cumulative': 103},
        {'name': 'name property at count1', 'work': 15, 'heap': 272, 'cumulative': 118},
        {'name': 'Native Promise.withResolvers, len21', 'work': 29, 'heap': 'N+53', 'cumulative': 147},
        {'name': 'owner property at count10, keylen13', 'work_spare': 159, 'work_grow': 179, 'heap_spare': 308, 'heap_grow': '308+11K', 'cumulative_spare': 306, 'cumulative_grow': 326,
         'derivation': 'tree(10)=10 comparisons; 10*(1+13)=140; moves(10)=18; insertion1 or growth1+2*10=21. count10<11 means no extra BTree node charge.'},
    ],
    'totals': {
        'work_spare': 306, 'work_grow': 326,
        'helper_heap_spare': 'A+D+2K+Bpp+N+1269',
        'helper_heap_grow': 'A+D+13K+Bpp+N+1269',
        'startup_heap_extra': 'S plus applicable helper heap; the additional initial slot does not add reserve work at zero initial length.',
        'constant_sum': [88, 80, 116, 72, 280, 272, 53, 308],
    },
    'measured_parent_branch': {
        'parent_order': [10, 10], 'parent_objects': [755, 755],
        'basis': bound(P / 'root/startup-observation.json'),
        'projection_only': {'work_delta': 326, 'work': 101312, 'remaining_of_1000000': 898688, 'heap_delta_using_retained_target_widths': 3253, 'heap_total': 1768271, 'final_objects': 756},
        'qualification': 'Requested capacities are not guaranteed exact by Rust allocation APIs. Future candidate must record actual constructor order len/cap and object len/cap. Keep both branch formulas; projected observed-target numbers are not new measurements.',
    },
    'partial_state': [
        'Entry/shape refusal before text allocations changes no objects, owner map or order.',
        'Fresh method bag can remain allocated after a later text/property/Native/final-publication refusal; old owner remains unchanged until final insertion.',
        'Final work refusal leaves heap at the pre-final stage; final heap refusal records the attempted charge, possibly over MAX_HEAP, but does not reserve or publish.',
        'Order reserve failure is after its work/heap admission and before Entry/order mutation; successful reserve followed by duplicate refusal can retain physical capacity/charges but does not overwrite the existing property.',
        'Bootstrap failure is never published as a public Runtime. Successful public construction resets work to MAX_STEPS100000; shared heap8MiB and finite BOOTSTRAP_STEPS1000000 stay unchanged.',
    ],
}
assert sum(installer['totals']['constant_sum']) == 1269
assert 12+70+3+62+159 == 306 and 12+70+3+62+179 == 326
assert 216+16+16+13*16+(16*(16+56)+32*8+64)+56+1269 == 3253
installer_receipt = write('late-installer-proposal.json', installer)

result = {
    'status': 'proposed result factory and ownership split; new fees await root selection',
    'symbols': symbols,
    'interfaces_proposed': [
        'promise_with_resolvers(constructor: Value, doc: &mut Document) -> Result<Value> in semantics.rs',
        'new_promise_capability_result(capability: Capability) -> Result<Value> in factories.rs, pub(super)',
    ],
    'algorithm': [
        'Enter through unchanged promise_native_operation public8 envelope. Proposed outer3 debit occurs before NewPromiseCapability; no result-object construction before the capability succeeds.',
        'Call unchanged new_promise_capability(constructor, doc). It already pays constructor clone1, IsConstructor, executor factory, owned argument vector, Construct and capture-read12; preserve every existing charge/error path.',
        'Move the entire Capability into the new factory. Proposed factory9 precedes all result work. The outer3 credits travel with the three owned Values and pay their cleanup if this first debit refuses.',
        'Pay tree(prototypes.len()).comparisons*(1+len(Object)/8), then read the saved Object ID and range-check it. Current26 prototypes gives22work; never consult global Object or a mutable constructor property.',
        'Recompute object_slot_plan after capability construction/reentrancy. Admit work and bytes, then reuse private reserve_promise_objects. No object allocation/publication precedes the applicable reserve.',
        'Call dom_proto_object(Some(Value::Object(saved)),3), creating a fresh ordinary unbranded bag with its existing9work and header/order charges.',
        'Allocate all three fixed texts in order promise,resolve,reject. Move each key and corresponding capability Value through dom_proto_property with data flags true,true,true in that order.',
        'Return Value::Object(bag). No new Value or JsString clones, no additional callbacks, no C.resolve/species/iterator/then access, and no inherited setter invocation occur in result creation.',
        'Wrap factory/method result with existing observe_microtask_failure so ResourceLimit/Unsupported suspend the shared queue even for direct helper callers. Ordinary constructor errors propagate without conversion to Promise rejection.',
    ],
    'proposed_new_fixed_envelopes': {
        'outer3': ['returned promise cleanup', 'returned resolve cleanup', 'returned reject cleanup'],
        'factory9_controls4': ['saved-prototype/range check', 'object-slot plan', 'conditional reserve', 'ordered publication and return handoff'],
        'factory9_owners5': ['prototype scalar Value', 'result Value token', 'promise text key', 'resolve text key', 'reject text key'],
        'qualification': 'Logical bounded envelopes, not instruction counts. Public8 is unchanged and is not refunded. Producer-funded triple cleanup remains required for direct factory fixtures. The retained source already pays key.clone inside dom_proto_property and all NPC copies; no duplicate new clone fee is proposed.',
    },
    'warm_stages_excluding_NPC_and_public8_and_outer3': [
        {'name': 'proposed factory envelope', 'work': 9, 'cumulative': 9},
        {'name': 'saved Object lookup at26', 'work': 22, 'cumulative': 31},
        {'name': 'object_slot_plan warm', 'work': 0, 'heap': 'S', 'cumulative': 31},
        {'name': 'bag header', 'work': 8, 'heap': '72+A+D', 'cumulative': 39},
        {'name': 'order3', 'work': 1, 'heap': '3K', 'cumulative': 40},
        {'name': 'promise text len7', 'work': 22, 'heap': 92, 'cumulative': 62},
        {'name': 'resolve text len7', 'work': 22, 'heap': 92, 'cumulative': 84},
        {'name': 'reject text len6', 'work': 20, 'heap': 88, 'cumulative': 104},
        {'name': 'promise property count0', 'work': 9, 'heap': '284+Bpp', 'cumulative': 113},
        {'name': 'resolve property count1', 'work': 18, 'heap': 284, 'cumulative': 131},
        {'name': 'reject property count2', 'work': 25, 'heap': 280, 'cumulative': 156},
    ],
    'totals': {
        'existing_warm_stages': 147, 'factory_with_proposed9': 156,
        'outer_plus_result': '159 + unchanged NPC charges + object growth work; existing public8 and caller costs additional',
        'heap': 'S+A+D+3K+Bpp+1192 plus object growth bytes; existing capability allocations additional',
        'retained_target_warm_heap_substitution': 2960,
        'qualification': 'These numbers do not include arbitrary author constructor execution, retained executor/capture work, construction/getter costs, or growth in existing Promise arenas. No whole-public-operation total is inferred.',
    },
    'growth': {
        'source': 'unchanged growth_plan<ScriptObject> and object_slot_plan',
        'validity': 'len<=physical_capacity; checked need=len+1 <= MAX_HEAP/S',
        'warm': 'need<=physical capacity: growthwork0/growthbytes0; count*S still charged',
        'cold_target': 'min(MAX_HEAP/S, max(2*capacity,8,next_power_of_two(len+1)))',
        'cold_work': '8+2*len*ceil(S/V)', 'cold_growth_bytes': '32+target*S',
        'qualification': 'Read the actual live arena only after NPC; do not cache len/cap or borrows across author construction. Earlier work/heap admission and successful reserves are never refunded.',
    },
    'failure_order': [
        'Outer3 refusal precedes NPC and all author effects; incoming constructor cleanup remains with existing public-operation/caller ownership.',
        'NPC ordinary throw or invalid callbacks produces no result bag. Its already-reached constructor/executor effects and existing captured values remain as dictated by unchanged helpers.',
        'Factory first-debit or lookup refusal discards the owned capability triple using prepaid producer credits. Missing or out-of-range private Object ID is ResourceLimit, not an author lookup.',
        'Slot work/heap/reserve failure creates no result bag. A successful slot reserve can remain physically enlarged after later refusal.',
        'Bag header/order admission failure precedes bag push. Once pushed, a later text/property refusal can retain an unreturned partial bag; do not roll back charged heap or earlier author effects.',
        'All three texts are reached before first property in the proposed sequence. Property publication is promise then resolve then reject; inherited setters/accessors are bypassed by existing direct own Entry insertion.',
        'Partial bag contents own any Values already moved; remaining locals are dropped once. No full Capability clone, replayed constructor, retry, or fallback object creation is permitted.',
        'ResourceLimit/Unsupported mark sticky suspension; queued sentinel jobs remain queued and cannot resume after budget reset. Ordinary TypeError/thrown Value uses existing error behavior and does not itself mark terminal suspension.',
    ],
    'test_outline_only': [
        'Parent-compatible public metadata/order/prototype/data-descriptor/setter-poison and generic custom-C identity cases; capability failure before result construction.',
        'Explicit factory incoming-triple ownership prepayment; exact/one-short warm156 work and typed heap; each staged boundary leaves the declared partial bag/key state.',
        'Spare/cold arena fixtures whose len/cap is asserted; deterministic scoped reserve failure before result push, and natural final caller with a queued sentinel.',
        'Constructor reentrancy mutates arena/global Object; factory rereads arena and uses private saved Object prototype; callbacks and returned promise are exact capability identities.',
        'Installer12 admission/shape guards before allocation; exact/one-short306/326 and typed heap in both capacity branches; old IDs/descriptor order/native maps unchanged.',
        'Actual startup prints constructor order len/cap and objects len/cap; retain old raw100985/100986 inputs as refusals, append derived101311/101312 and default1m/publicreset controls if the measured growth branch matches.',
    ],
}
assert 22+9+22+22+20+9+18+25 == 147
assert 216+16+16+3*16+(16*(16+56)+32*8+64)+1192 == 2960
result_receipt = write('result-bag-proposal.json', result)

pattern = re.compile(r'100_986|100986|899_014|899014|1_765_018|1765018|allSettled,any|\b755\b')
migrations = []
for path in sorted((W / 'src/script').rglob('*.rs')):
    relative = str(path.relative_to(W))
    if 'test' not in relative:
        continue
    hits = [{'line': i, 'text': s.strip()} for i, s in enumerate(path.read_text().splitlines(), 1) if pattern.search(s)]
    if hits:
        record = bound(path)
        assert record['sha256'] == inventory['source_sha256'][relative]
        migrations.append({'relative': relative, 'source': record, 'hits': hits})
assert len(migrations) == 16
migration_receipt = write('migration-touchpoints.json', {
    'status': 'bounded source census; no migrations authored and no complete future test roster claimed',
    'files': migrations,
    'required_distinctions': [
        'Final raw startup totals/counts and initial-reservation heap gain one slot plus installer delta; isolated old Promise1570/1532 and Any171/189 and AggregateError1103 helper tariffs stay unchanged.',
        'Existing Any before_any prefix work100797 and intermediate len754/755 remain historical stages; final finish_bootstrap observations must now include the new late installer. Preserve the old isolated Any assertion by separating prefix and completed-bootstrap observations.',
        'The initial reserve is now756 before any installer, so early-prefix physical capacities may increase without any additional old-stage work. Do not rewrite old per-stage object IDs.',
        'Existing full-bootstrap inputs99693/99694/100000/100796/100797/100985/100986 remain explicit refusals. Add projected101311/101312 boundaries after target evidence/fee selection; never silently enlarge old inputs.',
        'Three public own-name lists append withResolvers; the shared-key constructor count10 becomes11. Old eleven shared-key bags remain exactly eleven, independent of the two late method bags.',
        'Private replay helpers starting after full Runtime initialization must advance append positions755 to756 where appropriate; exclude the additional late method in old eleven-bag replay membership rather than changing old installer cuts.',
        'typed_array/tests.rs cumulative work and typed heap equations require the additional late installer term; retain previous arithmetic order to avoid usize underflow.',
        'The broad search is only a bounded starting census. Final migration authors must inspect transitive fixture assumptions and exact all-target test rosters before freezing changes.',
    ],
})

ready = write('source-ready.json', {
    'status': 'source-only budget readiness; proposals await root selection',
    'rust_base': '90c653d813feb62d1d569864bec076c0cc92d8a5',
    'source_bindings': source_receipt, 'installer': installer_receipt,
    'result': result_receipt, 'migration_touchpoints': migration_receipt,
    'author': bound(D / 'author.py'),
    'preserved': [
        'No proposed new CallbackKind variant, field, capture arena, Runtime State field or queue representation.',
        'Existing NewPromiseCapability, public8, all/race/allSettled/any helpers, metadata helpers and tariffs unchanged.',
        'No cap/host-rejection policy/public-budget changes; bootstrap1m/author100k/sharedheap8MiB retained.',
    ],
    'unknowns_for_selection': [
        'Root must select or refine outer3/result9 and late-installer12 envelopes before quota tests or implementation.',
        'API names/module placement are proposals, shared with Script; result sequence intentionally creates all three keys before properties.',
        'Future actual startup must confirm physical growth branch, exact counters and ABI-specific typed substitution. No future numeric result claimed.',
        'No new shape-affecting type declaration is needed, but this source assessment is not a measurement of native stack or whole-process memory.',
    ],
    'execution': 'Only filesystem reads and stdlib hash/JSON/arithmetic generation. No project imports, engine, builds, tests, network, Git commands, production or test payloads, or live-source edits.',
})
print(json.dumps(ready))
