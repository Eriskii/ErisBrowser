"""Independent held-source and published Git census review; no project execution."""
from pathlib import Path
import hashlib,json,re,difflib,subprocess,collections
B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1');D=B/'migrations-review-1';W=B/'worktree'
BASE='33ddb14aea0b8a20b7e340c4a5900abda3062f6f'
def sha(x):return hashlib.sha256(x).hexdigest()
def rec(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(rel):return json.loads((B/rel).read_text())
def git(*args):return subprocess.check_output(['git','-C',str(W),*args])
def refs(x):
 if isinstance(x,dict):
  if all(k in x for k in ('path','bytes','sha256')) and Path(x['path']).is_absolute():
   p=Path(x['path']);b=p.read_bytes();assert len(b)==x['bytes'] and sha(b)==x['sha256'],str(p)
  for v in x.values():refs(v)
 elif isinstance(x,list):
  for v in x:refs(v)
hold=read('migrations-1/source-ready.json');manifest=read('migrations-1/edit-manifest.json');census=read('migrations-1/census.json');ext=read('migrations-census-extension-1/review.json');roster=read('migrations-1/test-roster.json')
refs(hold);refs(ext)
assert len(hold['files'])==16 and len(manifest['function_renames'])==4
checks=[];allgroups=0
for row in hold['files']:
 rel=row['relative_path'];b=Path(row['before']['path']).read_text();a=Path(row['raw']['path']).read_text()
 assert git('show',BASE+':'+rel)==b.encode(),rel
 assert ''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))==Path(row['diff']['path']).read_text()
 current=b;edits=[x for x in manifest['edits'] if x['path']==rel]
 for e in edits:
  if 'mapping' in e:
   m=e['mapping'];pattern=r'\b(?:'+'|'.join(map(re.escape,m))+r')\b'
   current=re.sub(pattern,lambda z:m[z.group()],current)
  else:
   assert current.count(e['before'])==e['occurrences'],(rel,e['kind'])
   current=current.replace(e['before'],e['after'])
 assert current==a,rel
 for e in reversed(edits):
  if 'mapping' in e:
   m={v:k for k,v in e['mapping'].items()};pattern=r'\b(?:'+'|'.join(map(re.escape,m))+r')\b';current=re.sub(pattern,lambda z:m[z.group()],current)
  else:
   assert current.count(e['after'])==e['occurrences'];current=current.replace(e['after'],e['before'])
 assert current==b
 names=lambda s:re.findall(r'#\[test\]\s*fn (\w+)\(',s)
 renames={x['before']:x['after'] for x in manifest['function_renames'] if x['path']==rel}
 old,new=names(b),names(a);assert [renames.get(n,n) for n in old]==new
 for oldname,newname in renames.items():assert old.count(oldname)==new.count(newname)==1
 allgroups+=len(old)
 checks.append(dict(path=rel,groups=len(old),before=rec(row['before']['path']),raw=rec(row['raw']['path']),exact_inverse=True,renames=renames))
assert allgroups==126
# Three authored JS identity strings change only the final method membership.
raw_re=re.compile(r'r(#+)"(.*?)"\1',re.S)
js_changes=[]
for row in hold['files']:
 b=Path(row['before']['path']).read_text();a=Path(row['raw']['path']).read_text()
 rb=[m.group(2) for m in raw_re.finditer(b)];ra=[m.group(2) for m in raw_re.finditer(a)]
 assert len(rb)==len(ra)
 for old,new in zip(rb,ra):
  if old!=new:
   assert old.count('allSettled,any\'')==1 and old.replace("allSettled,any'","allSettled,any,withResolvers'")==new
   js_changes.append(row['relative_path'])
assert len(js_changes)==3
# Full tracked Rust scope uses original exact search expression, not project code.
names=git('ls-tree','-r','--name-only',BASE).decode().splitlines();rust=[p for p in names if p.endswith('.rs')];assert len(rust)==595
original=[p for p in rust if p.split('/')[0] in {'src','crates','tools'}];other=sorted(set(rust)-set(original));assert len(original)==464 and len(other)==131
# Use git cat-file --batch as inert byte reads.
proc=subprocess.run(['git','-C',str(W),'cat-file','--batch'],input=''.join(BASE+':'+p+'\n' for p in rust).encode(),stdout=subprocess.PIPE,check=True)
data=proc.stdout;pos=0;source={}
for name in rust:
 end=data.index(b'\n',pos);header=data[pos:end].split();assert header[1]==b'blob';size=int(header[2]);pos=end+1;blob=data[pos:pos+size];pos+=size;assert data[pos:pos+1]==b'\n';pos+=1;source[name]=blob
assert pos==len(data)
pat=re.compile(r'100_986|100986|899_014|899014|1_765_018|1765018|\b755\b|\b766\b|\b767\b|any_added|allSettled,any|Runtime::uninitialized\(|finish_bootstrap\(')
hits=[];raw=[]
for name in original:
 s=source[name].decode();rows=[dict(line=i,text=l) for i,l in enumerate(s.splitlines(),1) if pat.search(l)]
 if rows:hits.append(dict(path=name,sha256=sha(source[name]),selected=name in census['selected_paths'],hits=rows))
 if 'Runtime::uninitialized(' in s or 'finish_bootstrap(' in s:raw.append(dict(path=name,sha256=sha(source[name])))
assert hits==census['candidate_hit_files'] and raw==census['raw_bootstrap_files']
assert [x['path'] for x in ext['files']]==other
for row in ext['files']:
 b=source[row['path']];assert len(b)==row['bytes'] and sha(b)==row['sha256']
 assert not pat.search(b.decode()) and row['hits']==[]
# Supplementary context scan for fixed owner/count arithmetic omitted by mere 755 searches.
context_hits=[]
for name in original:
 lines=source[name].decode().splitlines()
 for i,line in enumerate(lines):
  if re.search(r'(?:constructor|owner).*values\.len\(\).*\b10\b|length,name,prototype,resolve,reject,all,race,allSettled,any|899_?014|100_?986',line):
   context_hits.append(dict(path=name,line=i+1,text=line))
assert {x['path'] for x in context_hits} <= set(census['selected_paths'])
# Selected source-derived accounting; no observed candidate startup is used.
assert sum([12,20,16,34,3,8,1,9,15,29])==147
assert 10*(1+13)+18+1==159
assert 10*(1+13)+18+1+2*10==179
assert 147+159==306 and 147+179==326
assert sum([88,80,116,72,280,272,53,308])==1269
assert 100986+326==101312 and 1000000-101312==898688
# Old Any per-operation inputs and full-group body prefix before new composition remain exact.
aold=(B/'migrations-1/before/src/script/promises/any_quota_tests.rs').read_text();anew=(B/'migrations-1/raw/src/script/promises/any_quota_tests.rs').read_text()
anchor='fn any_raw_startup_observes_physical_order_branch_and_keeps_public_reset()'
assert aold[:aold.index(anchor)]==anew[:anew.index(anchor)]
assert aold[aold.index('fn warm_destinations'):]==anew[anew.index('fn warm_destinations'):]
result=dict(status='clear',base=BASE,source_ready=rec(B/'migrations-1/source-ready.json'),census_extension=rec(B/'migrations-census-extension-1/review.json'),selection=rec(B/'root/selection-1.json'),files=checks,groups=126,new_removed_groups=0,function_renames=manifest['function_renames'],raw_js_literal_changes=js_changes,census=dict(full_tracked_rust=595,original_roots=464,extension=131,extension_hits=0,original_hit_files=len(hits),raw_bootstrap_files=len(raw),supplemental_owner_or_total_hits=context_hits),fee_derivation=dict(entry_to_native=147,owner_spare=159,owner_grow=179,total_spare=306,total_grow=326,helper_heap_constant=1269,full_startup_typed_delta='S+A+D+13K+Bpp+N+1269 on growth; extra initial S is counted once',projected_work=101312,projected_remaining=898688,projected_objects=756,unchanged_registry_prototype_global_counts=[300,26,213]),qualification='All numeric candidate startup totals are source-derived projections bound to selected physical growth; no execution or observed candidate output was read for this review.',no_project_execution=True,no_live_edits=True)
(D/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(rec(D/'checks.json')))
