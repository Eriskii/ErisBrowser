"""Author external migration payloads from published source; no project execution."""
from pathlib import Path
import json,hashlib,difflib,re,subprocess
D=Path(__file__).resolve().parent;B=D.parent;R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');BASE='33ddb14aea0b8a20b7e340c4a5900abda3062f6f'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,obj):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n')
paths=[x['path'] for x in json.loads((B/'readiness-1/historical-impact-outline.json').read_text())['paths']]
before={p:subprocess.check_output(['git','-C',str(R),'show',BASE+':'+p]).decode() for p in paths};raw=before.copy();edits=[]
def replace(path,old,new,count=1,kind='structural'):
 assert raw[path].count(old)==count,(path,old,raw[path].count(old),count)
 positions=[m.start() for m in re.finditer(re.escape(old),raw[path])]
 owners=[]
 for at in positions:
  found=list(re.finditer(r'(?m)^(?:pub\([^\n]+\) )?fn (\w+)\(',raw[path][:at+len(old)]))
  owners.append(found[-1].group(1) if found else None)
 edits.append(dict(path=path,kind=kind,before=old,after=new,occurrences=count,owners=owners))
 raw[path]=raw[path].replace(old,new)
def nums(path, mapping):
 old=raw[path]
 for a,b in mapping.items():assert re.search(r'\b'+a+r'\b',old),(path,a)
 pattern=r'\b(?:'+ '|'.join(mapping)+r')\b'
 # One simultaneous substitution avoids cascading shifted offsets.
 matches=list(re.finditer(pattern,old));out=re.sub(pattern,lambda m:mapping[m.group()],old)
 edits.append(dict(path=path,kind='structural-offset-map',mapping=mapping,sites=[dict(line=old.count('\n',0,m.start())+1,before=m.group(),after=mapping[m.group()]) for m in matches]))
 raw[path]=out
# Full final-realm object counts; every selected site in these files is cumulative.
for p in paths:
 if p not in ['src/script/promises/any_quota_tests.rs','src/script/promises/install_tests.rs','src/script/promises/shared_key_tests.rs']:
  if re.search(r'\b755\b',raw[p]):nums(p,{'755':'756'})
nums('src/script/promises/install_tests.rs',{'755':'756','766':'767'})
nums('src/script/promises/shared_key_tests.rs',{'755':'756','756':'757','767':'768'})
# The explicit old raw inputs remain, including the previously successful100986.
for p in ['src/script/processing_instruction/key_cache_tests.rs','src/script/text_operations/key_cache_tests.rs','src/script/promises/install_tests.rs']:
 replace(p,'        (100_986, true, 0),\n        (1_000_000, true, 899_014),','        (100_986, false, 0),\n        (101_311, false, 0),\n        (101_312, true, 0),\n        (1_000_000, true, 898_688),',kind='selected-startup326-boundaries')
renames=[]
for p in ['src/script/processing_instruction/display_key_tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/text_operations/key_cache_tests.rs','src/script/promises/install_tests.rs']:
 matches=re.findall(r'(?m)^fn (\w*100986\w*)\(',raw[p]);assert len(matches)==1
 old=matches[0];new=old.replace('100986','101312');replace(p,'fn '+old+'(','fn '+new+'(',kind='selected-startup-function-rename');renames.append(dict(path=p,before=old,after=new))
for p in ['src/script/bootstrap_tests.rs','src/script/processing_instruction/display_key_tests.rs','src/script/test262_host/quota_tests.rs']:
 replace(p,'899_014','898_688',kind='selected-startup326-remainder')
p='src/script/processing_instruction/display_key_tests.rs';replace(p,'assert_eq!(BOOTSTRAP_STEPS - runtime.steps, 100_986);','assert_eq!(BOOTSTRAP_STEPS - runtime.steps, 101_312);',kind='selected-startup326-total')
p='src/script/bootstrap_tests.rs';replace(p,'    // Late Promise.any adds189 work and one bag; existing installer tariffs remain exact.','    // Late Promise.any adds189 work and one bag; existing installer tariffs remain exact.\n    // Later withResolvers adds326 work and one bag on the selected order-growth path.',kind='selected-startup-comment')
p='src/script/promises/shared_key_tests.rs';replace(p,'    // the retained99693/99694/100000 refusals and new100986 boundary, not this replay.','    // the retained99693/99694/100000/100986 refusals and new101312 boundary, not this replay.',kind='selected-startup-comment')
# Three literal edits only: new static method appends after existingany.
for p in ['src/script/promise_semantic_tests.rs','src/script/promise_race_semantic_tests.rs','src/script/promises/shared_key_identity_tests.rs']:
 replace(p,"length,name,prototype,resolve,reject,all,race,allSettled,any'","length,name,prototype,resolve,reject,all,race,allSettled,any,withResolvers'",kind='new-method-own-name-membership')
p='src/script/promises/shared_key_identity_tests.rs';replace(p,'assert_eq!(runtime.objects[constructor].values.len(), 10);','assert_eq!(runtime.objects[constructor].values.len(), 11);',kind='new-method-owner-scalar-count')
# Preserve cumulative typed work/heap equation history and append the independent new term.
p='src/script/typed_array/tests.rs';replace(p,'    let any_added = s + a + d + 12 * k + bpp + n + 1179;','    let any_added = s + a + d + 12 * k + bpp + n + 1179;\n    // withResolvers appends after Any, growing owner order from10 to11.\n    let with_resolvers_added = s + a + d + 13 * k + bpp + n + 1269;',kind='selected-startup-typed-heap')
replace(p,'            - 189\n','            - 189\n            - 326\n',kind='selected-startup326-cumulative-work')
replace(p,'            + any_added\n','            + any_added\n            + with_resolvers_added\n',kind='selected-startup-typed-heap')
# Existing Any prefix fixtures remain untouched. Extend only its completed-startup comparison.
p='src/script/promises/any_quota_tests.rs'
old='''    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();
    let raw_id = owner(&raw);
    // The retained capacity observation selects the formula; no allocator ABI is guessed.
    assert_eq!(raw.steps, BOOTSTRAP_STEPS - 100_797 - work);
    assert_eq!(raw.allocated, runtime.allocated);
    assert_eq!((raw.objects.len(), raw.objects.capacity()), (755, 755));'''
new='''    // Any remains independently measured above. Complete the later installer
    // before comparing with whole bootstrap; all old IDs and Any fees stay exact.
    let with_resolvers_grow = after_order.0 == after_order.1;
    let with_resolvers_work = if with_resolvers_grow { 326 } else { 306 };
    let with_resolvers_heap = size_of::<Option<AbortSlot>>()
        + size_of::<Option<f64>>()
        + (if with_resolvers_grow { 13 } else { 2 }) * size_of::<PropertyKey>()
        + node_bytes()
        + size_of::<Native>()
        + 1269;
    let before_later_heap = runtime.allocated;
    // Inert Rust fixture counters isolate each real installer; no author work resumes.
    runtime.steps = with_resolvers_work;
    runtime.install_promise_with_resolvers_intrinsic().unwrap();
    assert_eq!(runtime.steps, 0);
    assert_eq!(runtime.allocated - before_later_heap, with_resolvers_heap);
    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();
    let raw_id = owner(&raw);
    // Both retained order observations select fees without guessing allocator capacity.
    assert_eq!(raw.steps, BOOTSTRAP_STEPS - 100_797 - work - with_resolvers_work);
    assert_eq!(raw.allocated, runtime.allocated);
    assert_eq!((raw.objects.len(), raw.objects.capacity()), (756, 756));'''
replace(p,old,new,kind='structural-any-prefix-versus-final-composition')
# Inverse each raw payload mechanically, while preserving source before and exact edit ledger.
rows=[];testrows=[]
for p in paths:
 b=before[p];a=raw[p];assert b!=a,p
 # Undo edits in reverse, including simultaneous offset maps.
 inv=a
 for e in reversed([x for x in edits if x['path']==p]):
  if 'mapping' in e:
   mapping={v:k for k,v in e['mapping'].items()};pattern=r'\b(?:'+ '|'.join(mapping)+r')\b';inv=re.sub(pattern,lambda m:mapping[m.group()],inv)
  else:
   assert inv.count(e['after'])==e['occurrences'],(p,e['after']);inv=inv.replace(e['after'],e['before'])
 assert inv==b,p
 bp=D/'before'/p;rp=D/'raw'/p;dp=D/'diffs'/(p+'.patch')
 for q in [bp,rp,dp]:q.parent.mkdir(parents=True,exist_ok=True)
 bp.write_text(b);rp.write_text(a);dp.write_text(''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
 def tests(s):return re.findall(r'#\[test\]\s*fn (\w+)\(',s)
 old_tests=tests(b);new_tests=tests(a);rename={x['before']:x['after'] for x in renames if x['path']==p};assert [rename.get(x,x) for x in old_tests]==new_tests
 testrows.append(dict(path=p,before=old_tests,after=new_tests,groups=len(old_tests)))
 rows.append(dict(relative_path=p,before=bind(bp),raw=bind(rp),diff=bind(dp),new=False))
write(D/'edit-manifest.json',dict(base=BASE,edits=edits,function_renames=renames,groups_added=0,groups_removed=0,old_semantic_literal_changes='Exactly3 existing own-name strings append withResolvers; no expected traces/results retuned.'))
write(D/'test-roster.json',dict(paths=16,groups=sum(x['groups'] for x in testrows),function_renames=renames,files=testrows))
# Exhaustive filename/text census against published Rust, without executing any project function.
allnames=subprocess.check_output(['git','-C',str(R),'ls-tree','-r','--name-only',BASE,'--','src','crates','tools']).decode().splitlines();rust=[p for p in allnames if p.endswith('.rs')];scan=[];rawcall=[]
pat=re.compile(r'100_986|100986|899_014|899014|1_765_018|1765018|\b755\b|\b766\b|\b767\b|any_added|allSettled,any|Runtime::uninitialized\(|finish_bootstrap\(')
for p in rust:
 s=subprocess.check_output(['git','-C',str(R),'show',BASE+':'+p]).decode();hits=[dict(line=i,text=l) for i,l in enumerate(s.splitlines(),1) if pat.search(l)]
 if hits:scan.append(dict(path=p,sha256=sha(s.encode()),selected=p in paths,hits=hits))
 if 'Runtime::uninitialized(' in s or 'finish_bootstrap(' in s:rawcall.append(dict(path=p,sha256=sha(s.encode())))
write(D/'census.json',dict(status='complete published tracked Rust text/fixture census for selected historical migrations',base=BASE,rust_files_scanned=len(rust),candidate_hit_files=scan,raw_bootstrap_files=rawcall,selected_paths=paths,exact_edit_manifest=bind(D/'edit-manifest.json'),distinctions=['Any before_any uses100797 early refusal, not removal from a completed realm; its original guard/fee/layout-prefix assertions remain byte-exact. Only the whole-bootstrap comparison group composes the new real installer afterward.','Standalone/shared original Promise replay retains all old bags and allocates11 or12 new bags; only starting offsets advance. No old metadata helper membership/fees are enlarged.','The additional initial reserved slot is already present in both compared Any prefix/final fixtures, so the later isolated helper delta excludes S. Full-startup typed_array delta includes S exactly once.','Every retained old explicit work input remains;100986 changes expected success to refusal and101311/101312 boundaries are appended. Default1m remainder898688 is prospective selected growth branch.','Unrelated PI heap_constant766, raster767 and typed-array numeric index766 are preserved.','No caps, public operation budgets, host setup/teardown fees, old exact1570/1532/1863 or Any171/189 rows changed.']))
write(D/'source-ready.json',dict(status='frozen external selected historical migration payload; no candidate execution',base=BASE,selection=bind(B/'root/selection-1.json'),budget=bind(B/'budget-readiness-1/source-ready.json'),budget_peer=bind(B/'budget-review-1/review.json'),base_refresh=bind(B/'readiness-base-refresh-1/source-ready.json'),files=rows,edit_manifest=bind(D/'edit-manifest.json'),census=bind(D/'census.json'),roster=bind(D/'test-roster.json'),author=bind(Path(__file__)),checks=dict(paths=16,groups=sum(x['groups'] for x in testrows),new_groups=0,function_renames=4,exact_inverse=True,old_any171_189_preserved=True,old_metadata_ids_preserved=True),numeric_qualification='Selected source-derived normal growth326, startup101312, remaining898688 and typed deltaS+A+D+13K+Bpp+N+1269. Actual physical branch and startup counters pending root observation; no result inferred.',scope='Only16 existing test files. No production/live source edits, project imports, build, test, engine, network or Git mutation.'))
print(bind(D/'source-ready.json'));print('groups',sum(x['groups'] for x in testrows),'edits',len(edits),'rustscan',len(rust))
