"""Independent data-only audit. Uses stdlib; never imports or executes project code."""
import collections
import base64
import hashlib
import json
from pathlib import Path
import re

B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
A = Path('/tmp/eris-promise-any-upstream-plan-1')
P = Path('/tmp/eris-promise-any-runtime-plan-1')
W = B / 'worktree'
OUT = B / 'validation-review-1'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_text())

def ref(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))

def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(',', ':')).encode()).hexdigest()

ledger_path = B / 'root/final-validation.json'
assert ledger_path.stat().st_size == 22586
assert sha(ledger_path) == 'b795ad3ecdfdc0174f7e8a4d5624157f599e4dd78b70fb63d1753e329819c4b4'
L = read(ledger_path)
bindings = {}

def verify_refs(value):
    if isinstance(value, dict):
        if all(k in value for k in ('path', 'bytes', 'sha256')):
            p = Path(value['path'])
            assert p.is_file(), p
            assert p.stat().st_size == value['bytes'], p
            assert sha(p) == value['sha256'], p
            bindings[str(p)] = ref(p)
        for child in value.values():
            verify_refs(child)
    elif isinstance(value, list):
        for child in value:
            verify_refs(child)

verify_refs(L)
final = read(B / 'source-final.json')
parent = read(B / 'source-parent.json')
assert final['base'] == parent['base'] == L['base'] == '33ddb14aea0b8a20b7e340c4a5900abda3062f6f'
assert (B / 'source-final.json').read_bytes() == (B / 'source-candidate-1.json').read_bytes()
assert len(parent['source_sha256']) == 1744 and len(final['source_sha256']) == 1747
for rel, expected in final['source_sha256'].items():
    assert sha(W / rel) == expected, rel
selected_changed = sorted(p for p, h in final['source_sha256'].items() if parent['source_sha256'].get(p) != h)
assert len(selected_changed) == 26
new = sorted(set(final['source_sha256']) - set(parent['source_sha256']))
assert new == ['src/script/promises/with_resolvers_quota_tests.rs', 'src/script/with_resolvers_abort_tests.rs', 'src/script/with_resolvers_semantics_tests.rs']
tracked = read(B / 'root/tracked-parent.json')
assert tracked['base'] == final['base'] and len(tracked['files']) == 15179
tracked_changed = sorted(p for p, h in tracked['files'].items() if sha(W / p) != h)
assert tracked_changed == L['source']['tracked_changed_paths']
assert len(tracked_changed) == 23 and len(tracked['files']) - len(tracked_changed) == 15156
assert sorted(tracked_changed + new) == selected_changed
assert all(p.startswith('src/') for p in tracked_changed)
preserved_by_prefix = {prefix: sum(p.startswith(prefix) for p in tracked['files']) for prefix in ('src/', 'crates/', 'tools/', 'tests/upstream/', 'tests/conformance/')}

checks = []
for c in L['checks']:
    receipt = read(c['receipt']['path'])
    log = Path(c['log']['path'])
    assert receipt['exit'] == c['exit']
    assert receipt['sha256'] == sha(log)
    assert receipt['log'] == log.name
    checks.append(dict(label=c['label'], command=receipt['command'], exit=receipt['exit'], receipt=c['receipt'], log=c['log']))

def rust_log(path):
    text = Path(path).read_text()
    rows = re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)
    results = re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)$', text, re.M)
    totals = [sum(int(row[i]) for row in rows) for i in range(5)]
    return text, rows, results, totals

public = read(B / 'public-contract-1/roster.json')
private = read(B / 'private-contract-1/roster.json')
public_names = {'script::' + r['module'] + '::' + r['test'] for r in public['groups']}
private_names = {'script::promises::with_resolvers_quota_tests::' + r['name'] for r in private['rows']}
assert len(public_names) == 15 and len(private_names) == 9
assert sum(r.get('modes', 0) for r in public['groups']) == L['candidate']['semantic_mode_rows'] == 24
assert sum(r.get('modes', 0) * r.get('source_phases', 0) for r in public['groups']) == L['candidate']['semantic_source_phase_attempts'] == 30
assert sum(r.get('terminal_attempts', 0) for r in public['groups']) == L['candidate']['public_terminal_mode_attempts'] == 12
assert sum(r['operations'] for r in private['rows']) == L['candidate']['private_measured_operations'] == 67
assert private['terminal_mode_attempts'] == L['candidate']['private_terminal_modes'] == 2
assert private['sticky_readbacks'] == L['candidate']['private_sticky_readbacks'] == 4

pt, pr, pn, ps = rust_log(B / 'validation/with-resolvers-parent-public-1.log')
ct, cr, cn, cs = rust_log(B / 'validation/with-resolvers-candidate-1.log')
assert len(pr) == len(cr) == 1
assert ps[:4] == [0, 15, 0, 0] and cs[:4] == [24, 0, 0, 0]
assert set(n for n, s in pn) == public_names == set(L['parent_public']['groups_observed'])
assert all(s == 'FAILED' for n, s in pn)
assert len(pn) == 15 and len(cn) == 24
assert set(n for n, s in cn) == public_names | private_names
assert all(s == 'ok' for n, s in cn)
assert pt.count('strict=false') == 15 and 'strict=true' not in pt
assert pt.count('intrinsic_name: Some("Error")') == 15
assert pt.count('phase=0 source:') == 12
for rel in new:
    text = (W / rel).read_text()
    source_tests = re.findall(r'#\[test\]\s*fn (\w+)\(', text)
    prefix = 'script::' + ('promises::' if '/promises/' in rel else '') + Path(rel).stem + '::'
    names = {prefix + name for name in source_tests}
    assert names <= public_names | private_names
    assert len(names) == {'with_resolvers_quota_tests': 9, 'with_resolvers_abort_tests': 3, 'with_resolvers_semantics_tests': 12}[Path(rel).stem]

renames = read(B / 'migrations-1/test-roster.json')['function_renames']
rename_map = {r['before']: r['after'] for r in renames}
assert len(rename_map) == 4
rust = []
for candidate, prior, total, prior_total in [('default-full-1', 'default-full-2', 3221, 3197), ('host-vulkan-full-1', 'host-vulkan-full-1', 3575, 3551)]:
    pp = B / 'rust-parent' / (prior + '.log')
    assert pp.read_bytes() == (P / 'validation' / pp.name).read_bytes()
    p_receipt = read(B / 'rust-parent' / (prior + '.json'))
    assert p_receipt['exit'] == 0 and p_receipt['sha256'] == sha(pp)
    cp = B / 'validation' / (candidate + '.log')
    ptext, prows, pnames, ptotals = rust_log(pp)
    ctext, crows, cnames, ctotals = rust_log(cp)
    assert len(prows) == len(crows) == 52
    assert ptotals == [prior_total, 0, 0, 0, 0] and ctotals == [total, 0, 0, 0, 0]
    assert len(pnames) == prior_total and len(cnames) == total
    assert all(s == 'ok' for n, s in pnames + cnames)
    old = collections.Counter(n for n, s in pnames)
    transformed = collections.Counter()
    used = collections.Counter()
    for name, count in old.items():
        prefix, leaf = name.rsplit('::', 1) if '::' in name else ('', name)
        if leaf in rename_map:
            used[leaf] += count
            name = prefix + '::' + rename_map[leaf]
        transformed[name] += count
    assert dict(used) == {name: 1 for name in rename_map}
    actual = collections.Counter(n for n, s in cnames)
    assert actual == transformed + collections.Counter(public_names | private_names)
    layout_name = 'script::promises::all_layout_tests::all_actual_private_layout_matches_four_configuration_prospective_mirror'
    assert actual[layout_name] == 1 and old[layout_name] == 1
    rust.append(dict(configuration=candidate, parent=ref(pp), candidate=ref(cp), parent_total=prior_total, total=total,
                     parent_result_rows=len(prows), candidate_result_rows=len(crows), complete_multiset_equal_after_four_renames_and_24_additions=True,
                     parent_roster_sha256=digest(sorted(old.items())), expected_final_roster_sha256=digest(sorted(actual.items())),
                     layout_group_passed=True))

parent_profile = read(A / 'root/profile-validation.json')
parent_reports = {r['name']: r['report'] for r in parent_profile['old_profiles']}
parent_reports['any'] = parent_profile['any']['report']
verify_refs(list(parent_reports.values()))
profiles = []
for spec in L['profiles']['profiles']:
    name = spec['name']
    rp = B / ('upstream-' + name + '-1.json')
    pp = Path(parent_reports[name]['path'])
    current, prior = read(rp), read(pp)
    assert sha(rp) == spec['sha256']
    assert set(current) == set(prior)
    changes = sorted(k for k in current if current[k] != prior[k])
    assert changes == ['binary', 'binary_sha256', 'seconds'], (name, changes)
    assert current['cases'] == prior['cases'] and current['harness_preflight'] == prior['harness_preflight']
    assert len(current['cases']) == spec['cases'] and len(current['harness_preflight']) == spec['controls']
    counts = dict(collections.Counter(c['status'] for c in current['cases']))
    assert counts == current['counts'] == prior['counts'] == spec['counts']
    assert current['harness_preflight_passed'] and all(c['verified'] is True for c in current['harness_preflight'])
    assert current['regressions'] == current['improvements'] == []
    assert hashlib.sha256(json.dumps(current['runner_policy'], sort_keys=True).encode()).hexdigest() == current['runner_policy_sha256']
    assert sha(current['binary']) == current['binary_sha256'] == spec['binary_sha256']
    receipt = read(B / 'validation' / ('upstream-' + name + '-1.json'))
    command = receipt['command']
    assert receipt['exit'] == 0 and command[command.index('--binary') + 1] == current['binary']
    assert command[command.index('--output') + 1] == str(rp)
    baseline = command[command.index('--baseline') + 1]
    assert sha(W / baseline) == tracked['files'][baseline]
    report = dict(name=name, parent=ref(pp), candidate=ref(rp), cases=spec['cases'], controls=spec['controls'], counts=counts,
                  all_nested_case_and_control_records_identical=True, report_differences_only=changes,
                  policy_sha256=current['runner_policy_sha256'], corpus_sha256=current['corpus_manifest_sha256'],
                  baseline=ref(W / baseline), all_controls_verified=True, no_regressions_or_improvements=True)
    if name == 'any':
        failed = [c for c in current['cases'] if c['status'] == 'failed']
        assert len(failed) == 2 and all(c['file'].endswith('/returns-promise.js') for c in failed)
        report['retained_failed_records'] = failed
    profiles.append(report)
assert sum(r['cases'] for r in profiles) == 1288
assert sum(r['controls'] for r in profiles) == 502

binaries = []
for binary in L['binaries']:
    assert read(binary['binary'] + '.json') == binary
    assert Path(binary['binary']).stat().st_size == binary['bytes'] and sha(binary['binary']) == binary['sha256']
    assert sha(binary['source_inventory']) == binary['source_sha256'] == sha(B / 'source-final.json')
    build = read(binary['build'])
    command = build['command']
    assert build['exit'] == 0 and command[:3] == ['cargo', '+1.88.0', 'build']
    assert '--release' in command and command[command.index('--bin') + 1] == 'eris-js'
    features = command[command.index('--features') + 1].split(',') if '--features' in command else []
    assert features == binary['features']
    log = B / 'validation' / build['log']
    assert sha(log) == build['sha256'] and 'Finished `release` profile [optimized]' in log.read_text()
    binaries.append(dict(binary=ref(binary['binary']), provenance=ref(binary['binary'] + '.json'), build=ref(binary['build']),
                         source_inventory=ref(binary['source_inventory']), toolchain='1.88.0', features=features))

for label, toolchain, features in [('clippy-default-1', '+1.88.0', []), ('clippy-host-vulkan-1', '+1.99.0', ['test262-host', 'vulkan-raster'])]:
    c = read(B / 'validation' / (label + '.json'))
    cmd = c['command']
    assert c['exit'] == 0 and cmd[:3] == ['cargo', toolchain, 'clippy']
    assert '--all-targets' in cmd and cmd[-3:] == ['--', '-D', 'warnings']
    assert (cmd[cmd.index('--features') + 1].split(',') if '--features' in cmd else []) == features
    assert 'Finished `dev` profile' in (B / 'validation' / c['log']).read_text()
fmt = read(B / 'validation/fmt-check-1.json')
assert fmt['exit'] == 0 and fmt['command'][-4:] == ['fmt', '--all', '--', '--check']
assert (B / 'validation/fmt-check-1.log').read_bytes() == b''

startup = L['startup']
assert ct.splitlines().count(startup['raw_line']) == 1
match = re.fullmatch(r'withResolvers startup: before_order=\((\d+), (\d+)\) after_order=\((\d+), (\d+)\) before_objects=\((\d+), (\d+)\) raw_objects=\((\d+), (\d+)\) work=(\d+) remaining=(\d+) allocated=(\d+) maps=\((\d+), (\d+), (\d+)\)', startup['raw_line'])
assert match is not None
observed = list(map(int, match.groups()))
assert observed[:2] == startup['prior_order'] and observed[2:4] == startup['final_order']
assert observed[4:6] == [755, 756]
assert observed[6:] == [startup['objects'], startup['capacity'], startup['work'], startup['remaining'], startup['accounted_heap'], startup['maps']['native'], startup['maps']['prototype'], startup['maps']['global']]
old_startup = read(P / 'root/startup-observation.json')
old_log = P / 'validation/any-private-1.log'
assert sha(old_log) == old_startup['log_sha256']
assert old_startup['raw_line'] in old_log.read_text()
assert startup['work'] + startup['remaining'] == startup['budgets']['bootstrap_work'] == 1_000_000
assert startup['work'] - old_startup['work'] == startup['delta']['work'] == 326
assert startup['accounted_heap'] - old_startup['accounted_heap'] == startup['delta']['accounted_heap'] == 3253
assert startup['objects'] - old_startup['objects'] == startup['delta']['objects'] == 1
assert startup['maps'] == old_startup['maps']
runtime = (W / 'src/script.rs').read_text()
assert 'const MAX_STEPS: usize = 100_000;' in runtime
assert 'const BOOTSTRAP_STEPS: usize = 1_000_000;' in runtime
assert 'const MAX_HEAP: usize = 8 * 1024 * 1024;' in runtime
assert 'runtime.initialize_bootstrap()?;\n        runtime.steps = MAX_STEPS;\n        Ok(runtime)' in runtime
assert sha(B / 'readiness-1/parent/src/script.rs') == parent['source_sha256']['src/script.rs']
before_runtime = (B / 'readiness-1/parent/src/script.rs').read_text()
for name in ['MAX_SOURCE','MAX_TOKENS','MAX_DEPTH','MAX_CALLS','MAX_STACK_UNITS','MAX_STEPS','BOOTSTRAP_STEPS','MAX_HEAP','MAX_STRING','MAX_NODES']:
    pattern = r'const ' + name + r': usize = [^;]+;'
    assert re.search(pattern, runtime).group() == re.search(pattern, before_runtime).group()
layout_text = (W / 'src/script/promises/all_layout_tests.rs').read_text()
assert len(re.findall(r'^    row!\(', layout_text, re.M)) == 24  # two mutually exclusive Runtime rows: 23 execute
assert 'Runtime, 1808, 16' in layout_text and 'Runtime, 1872, 16' in layout_text
assert sha(W / 'src/script/promises/all_layout_tests.rs') == parent['source_sha256']['src/script/promises/all_layout_tests.rs']

ci = read(L['prior_ci']['receipt']['path'])
assert ci['headSha'] == L['base'] and ci['databaseId'] == L['prior_ci']['id']
assert ci['status'] == 'completed' and ci['conclusion'] == 'success'
assert len(ci['jobs']) == 11 and all(j['status'] == 'completed' and j['conclusion'] == 'success' for j in ci['jobs'])

reference_receipt = read(B / 'upstream-reference-1/receipt.json')
directory = read(B / 'root/upstream-directory.json')
assert len(reference_receipt['rows']) == len(directory['tree']) == 6
tree_bytes = b''.join(r['mode'].encode() + b' ' + r['path'].encode() + b'\0' + bytes.fromhex(r['sha']) for r in directory['tree'])
assert hashlib.sha1(b'tree ' + str(len(tree_bytes)).encode() + b'\0' + tree_bytes).hexdigest() == directory['sha'] == reference_receipt['tree']
for row, entry in zip(reference_receipt['rows'], directory['tree']):
    path = B / 'upstream-reference-1' / row['path']
    payload = path.read_bytes()
    response = read(str(path) + '.response.json')
    assert len(payload) == row['bytes'] == entry['size'] == response['size'] and sha(path) == row['sha256']
    assert base64.b64decode(response['content']) == payload
    assert hashlib.sha1(b'blob ' + str(len(payload)).encode() + b'\0' + payload).hexdigest() == row['git_blob'] == entry['sha'] == response['sha']
legal = read(B / 'upstream-reference-legal-1/provenance.json')
assert sha(B / 'upstream-reference-legal-1/LICENSE') == legal['sha256'] == sha(legal['source'])
assert sha(B / 'upstream-reference-1/receipt.json') == legal['reference_receipt_sha256']

result = dict(status='clear', method='stdlib-only independent recomputation from retained bytes and logs; no project execution or live writes',
              final_ledger=ref(ledger_path), embedded_bound_files_verified=list(bindings.values()),
              source=dict(final=ref(B/'source-final.json'), parent=ref(B/'source-parent.json'), tracked_parent=ref(B/'root/tracked-parent.json'),
                          selected=1747, parent_selected=1744, new=new, changed=selected_changed, tracked_files=15179,
                          tracked_changed=23, tracked_unchanged=15156, counted_prefixes=preserved_by_prefix,
                          source_candidate_equals_final=True, scope=final['scope']),
              parent_focused=dict(passed=0, failed=15, all_first_sloppy=True, later_phases_unreached=True),
              candidate_focused=dict(passed=24, failed=0, names=sorted(public_names | private_names), private_operations=67),
              renames=renames, rust=rust, profiles=profiles, binaries=binaries, checks=checks,
              startup=dict(actual=startup, prior=ref(P/'root/startup-observation.json'), prior_log=ref(old_log), limits_unchanged=True),
              prior_ci=dict(receipt=L['prior_ci']['receipt'], jobs=11, head=ci['headSha'], current_checkpoint_ci_not_claimed=True),
              upstream_reference_only=dict(sources=6, receipt=ref(B/'upstream-reference-1/receipt.json'), tree=ref(B/'root/upstream-directory.json'), legal=ref(B/'upstream-reference-legal-1/provenance.json'), no_new_profile=True),
              qualifications=['Source closure is selected inputs plus tracked src/crates/tools/tests and root manifests/workflow, not a complete build graph.',
                              'Parent failures stop at the first sloppy mode; candidate successful group loops establish the remaining planned rows.',
                              'Accounting and observed vector/type sizes are not native-stack, whole-process RSS, security, browser-conformance or performance evidence.',
                              'No full Python rerun and no dedicated withResolvers upstream profile are claimed.',
                              'This reviewer authored the budget/private contract and prior source-closure review; the final result/log/hash comparison is independent of root\'s aggregation.'])
(OUT / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(dict(status='clear', checks=ref(OUT/'checks.json'), source=1747, tracked=15179,
                      rust=[r['total'] for r in rust], cases=1288, controls=502), indent=2))
