from pathlib import Path
import subprocess,sys,json
B=Path(__file__).resolve().parents[1]
profiles=[('aggregate-error','aggregate-error'),('existing','promise-methods-async'),('all','promise-all'),('race','promise-race'),('settled','promise-all-settled'),('any','promise-any')]
for short,profile in profiles:
 kind='ordinary' if short=='aggregate-error' else 'host'
 command=[sys.executable,'-B',str(B/'run-tool.py'),'upstream-'+short+'-1',sys.executable,'-B','tools/test262_conformance.py','--binary',str(B/f'eris-js-{kind}-1'),'--profile',profile,'--output',str(B/f'upstream-{short}-1.json'),'--baseline',f'tests/conformance/test262-{profile}-current.json']
 subprocess.run(command,check=True)
subprocess.run([sys.executable,'-B',str(B/'root/check-profiles.py')],check=True)
