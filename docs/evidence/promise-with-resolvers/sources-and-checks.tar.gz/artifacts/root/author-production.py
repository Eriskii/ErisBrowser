from pathlib import Path
import hashlib,json,difflib
B=Path(__file__).resolve().parents[1]; W=B/'worktree'; H=B/'production-1'; records=[]
def edit(path,replacements):
 old=(W/path).read_text(); new=old
 for before,after in replacements:
  assert new.count(before)==1,(path,before)
  new=new.replace(before,after)
 out=H/'raw'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(new)
 diff=H/'diff'/f'{path}.diff';diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
 records.append({'path':path,'before':hashlib.sha256(old.encode()).hexdigest(),'after':hashlib.sha256(new.encode()).hexdigest(),'raw':str(out),'diff':str(diff)})
edit('src/script.rs',[('        self.install_promise_any_intrinsic()\n','        self.install_promise_any_intrinsic()?;\n        self.install_promise_with_resolvers_intrinsic()\n')])
edit('src/script/dom_prototypes.rs',[('    + promises::ANY_METADATA_OBJECTS\n','    + promises::ANY_METADATA_OBJECTS\n    + promises::WITH_RESOLVERS_METADATA_OBJECTS\n')])
edit('src/script/promises.rs',[('pub(super) const ANY_METADATA_OBJECTS: usize = 1;','pub(super) const ANY_METADATA_OBJECTS: usize = 1;\npub(super) const WITH_RESOLVERS_METADATA_OBJECTS: usize = 1;')])
edit('src/script/machine/calls.rs',[('                    | "Promise.any"\n','                    | "Promise.any"\n                    | "Promise.withResolvers"\n')])
method='''    fn promise_with_resolvers(
        &mut self,
        constructor: Value,
        doc: &mut Document,
    ) -> Result<Value> {
        // Fund the three returned capability handles before author construction,
        // including their cleanup if the result factory's first debit refuses.
        self.work(3)?;
        let capability = self.new_promise_capability(constructor, doc)?;
        self.new_promise_capability_result(capability)
    }

'''
edit('src/script/promises/semantics.rs',[('    pub(in crate::script) fn promise_native_operation(',method+'    pub(in crate::script) fn promise_native_operation('),('                "Promise.any" => self.promise_any(receiver, args, doc),','                "Promise.any" => self.promise_any(receiver, args, doc),\n                "Promise.withResolvers" => self.promise_with_resolvers(receiver, doc),')])
factory='''    pub(super) fn new_promise_capability_result(&mut self, capability: Capability) -> Result<Value> {
        let result = (|| {
            // Four bounded control roles and five local owners: prototype,
            // result and three keys. The producer prepaid capability cleanup.
            self.work(9)?;
            self.work(intrinsic_tree(self.prototypes.len()).0 * (1 + "Object".len() / 8))?;
            let prototype = self
                .prototypes
                .get("Object")
                .copied()
                .filter(|id| *id < self.objects.len())
                .ok_or_else(|| ScriptError::resource("Promise result Object prototype missing"))?;
            // NewPromiseCapability may have run arbitrary author construction.
            // Recompute the physical arena plan after all of those effects.
            let plan = object_slot_plan(self.objects.len(), self.objects.capacity(), 1)?;
            self.work(plan.work)?;
            self.charge(plan.bytes)?;
            self.reserve_promise_objects(plan)?;
            let bag = self.dom_proto_object(Some(Value::Object(prototype)), 3)?;
            let promise = self.dom_proto_text("promise")?;
            let resolve = self.dom_proto_text("resolve")?;
            let reject = self.dom_proto_text("reject")?;
            self.dom_proto_property(
                bag,
                promise.into(),
                Property::data(capability.promise, true, true, true),
            )?;
            self.dom_proto_property(
                bag,
                resolve.into(),
                Property::data(capability.resolve, true, true, true),
            )?;
            self.dom_proto_property(
                bag,
                reject.into(),
                Property::data(capability.reject, true, true, true),
            )?;
            Ok(Value::Object(bag))
        })();
        self.observe_microtask_failure(result)
    }

'''
edit('src/script/promises/factories.rs',[('    pub(super) fn new_pending_promise(',factory+'    pub(super) fn new_pending_promise(')])
installer='''    pub(in crate::script) fn install_promise_with_resolvers_intrinsic(&mut self) -> Result<()> {
        // Eight bounded guards/control roles and four temporary releases.
        // Append after Any so all earlier intrinsic object IDs stay stable.
        self.work(12)?;
        let intrinsics = self
            .promises
            .intrinsics
            .as_ref()
            .ok_or_else(|| ScriptError::resource("Promise intrinsics missing"))?;
        let Value::Native(constructor) = &intrinsics.constructor else {
            return Err(ScriptError::resource("invalid Promise constructor"));
        };
        let owner = constructor
            .properties
            .map(NonZeroUsize::get)
            .filter(|id| *id < self.objects.len())
            .ok_or_else(|| ScriptError::resource("Promise metadata missing"))?;
        let bag = &self.objects[owner];
        if bag.values.len() != 10 || bag.order.len() != 10 || bag.order.capacity() < bag.order.len() {
            return Err(ScriptError::resource("invalid Promise metadata shape"));
        }
        let length = self.dom_proto_text("length")?;
        let name = self.dom_proto_text("name")?;
        let key = self.dom_proto_text("withResolvers")?;
        // Two metadata key copies and the display-name copy.
        self.work(3)?;
        let method = self.promise_intrinsic_method(
            "Promise.withResolvers",
            key.clone(),
            0,
            [&length, &name],
        )?;
        self.dom_proto_property(owner, key.into(), Property::data(method, true, false, true))
    }

'''
edit('src/script/promises/install.rs',[('    fn check_promise_install_state(',installer+'    fn check_promise_install_state(')])
record={'base':'33ddb14aea0b8a20b7e340c4a5900abda3062f6f','selection_sha256':hashlib.sha256((B/'root/selection-1.json').read_bytes()).hexdigest(),'files':records,'status':'root production candidate; not imported or executed','new_types_or_fields':0}
with (H/'source-ready.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(len(records),hashlib.sha256((H/'source-ready.json').read_bytes()).hexdigest())
