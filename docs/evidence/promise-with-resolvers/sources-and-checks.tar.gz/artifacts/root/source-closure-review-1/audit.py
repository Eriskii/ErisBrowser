from pathlib import Path
import hashlib
import json
import re
import difflib

B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
W = B / 'worktree'
D = B / 'root/source-closure-review-1'

def bound(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def sha(s):
    return hashlib.sha256(s.encode()).hexdigest()

def write(name, value):
    p = D / name
    assert not p.exists()
    p.write_text(json.dumps(value, indent=2) + '\n')
    return bound(p)

def verify_refs(x):
    if isinstance(x, dict):
        if isinstance(x.get('path'), str) and x['path'].startswith('/') and 'sha256' in x:
            row = bound(Path(x['path']))
            assert row['sha256'] == x['sha256'], x['path']
            if 'bytes' in x:
                assert row['bytes'] == x['bytes'], x['path']
        for v in x.values(): verify_refs(v)
    elif isinstance(x, list):
        for v in x: verify_refs(v)

parent = json.loads((B / 'source-parent.json').read_text())
candidate_path = B / 'source-candidate-1.json'
assert bound(candidate_path)['sha256'] == '7a87b1ae32d9e5a9f606c1301c5846c6518cb2271429b0291ef78ed5d282ce9c'
candidate = json.loads(candidate_path.read_text())
old = parent['source_sha256']
new = candidate['source_sha256']
assert len(old) == 1744 and len(new) == 1747
holds = {name: json.loads((B / name / 'source-ready.json').read_text()) for name in ['production-1', 'migrations-1', 'public-contract-1', 'private-contract-1']}
for hold in holds.values(): verify_refs(hold)
expected = {}
origins = {}
for row in holds['production-1']['files']:
    p = Path(row['raw'])
    assert bound(p)['sha256'] == row['after']
    assert old[row['path']] == row['before']
    expected[row['path']] = p.read_text()
    origins[row['path']] = [bound(p)]
for row in holds['migrations-1']['files']:
    rel = row['relative_path']
    assert rel not in expected
    assert old[rel] == row['before']['sha256']
    expected[rel] = Path(row['raw']['path']).read_text()
    origins[rel] = [row['raw']]
for row in holds['public-contract-1']['files']:
    if row['relative_path'] == 'src/script.rs': continue
    expected[row['relative_path']] = Path(row['raw']['path']).read_text()
    origins[row['relative_path']] = [row['raw']]
public_fragment = B / 'public-contract-1/registration-append.txt'
private_fragment = B / 'private-contract-1/registration/fragment.txt'
expected['src/script.rs'] += public_fragment.read_text()
origins['src/script.rs'].append(bound(public_fragment))
expected['src/script/promises.rs'] += private_fragment.read_text()
origins['src/script/promises.rs'].append(bound(private_fragment))
private_module = B / 'private-contract-1/raw/src/script/promises/with_resolvers_quota_tests.rs'
expected['src/script/promises/with_resolvers_quota_tests.rs'] = private_module.read_text()
origins['src/script/promises/with_resolvers_quota_tests.rs'] = [bound(private_module)]
assert len(expected) == 26
changed = {r for r in old if old[r] != new[r]}
added = set(new) - set(old)
assert len(changed) == 23 and len(added) == 3
assert changed | added == set(expected)
for rel, digest in new.items(): assert bound(W / rel)['sha256'] == digest, rel

# Lexical read only. Strings/chars remain indivisible exact byte tokens; no Rust
# parser/compiler is imported or executed. Comments are separately retained.
char = re.compile(r"'(?:[^\\'\n]|\\(?:[\\'\"nrt0]|x[0-9A-Fa-f]{2}|u\{[0-9A-Fa-f_]+\}))'")
raw_string = re.compile(r'(?:br|cr|r)(#*)"')
word_token = re.compile(r'[A-Za-z_0-9]+')
def tokens(s):
    out = []
    literals = []
    comments = []
    i = 0
    while i < len(s):
        if s[i].isspace(): i += 1; continue
        if s.startswith('//', i):
            j = s.find('\n', i)
            if j < 0: j = len(s)
            comments.append(s[i:j]); i = j; continue
        if s.startswith('/*', i):
            j = i + 2; depth = 1
            while depth:
                if s.startswith('/*', j): depth += 1; j += 2
                elif s.startswith('*/', j): depth -= 1; j += 2
                else: j += 1
                assert j <= len(s)
            comments.append(s[i:j]); i = j; continue
        raw = raw_string.match(s, i)
        if raw:
            ending = '"' + raw.group(1)
            j = s.index(ending, raw.end()) + len(ending)
            token = s[i:j]; out.append(token); literals.append(token); i = j; continue
        prefix = 1 if s[i:i+2] in ['b"', 'c"'] else 0
        if s[i+prefix:i+prefix+1] == '"':
            j = i + prefix + 1
            while s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            j += 1
            token = s[i:j]; out.append(token); literals.append(token); i = j; continue
        cm = char.match(s, i + (1 if s.startswith("b'", i) else 0))
        if cm:
            j = cm.end(); token = s[i:j]
            out.append(token); literals.append(token); i = j; continue
        word = word_token.match(s, i)
        if word:
            j = word.end(); out.append(s[i:j]); i = j; continue
        out.append(s[i]); i += 1
    return out, literals, comments

rows = []
punctuation = []
format_changed = []
for rel, composition in expected.items():
    actual = (W / rel).read_text()
    unmodified_composition = composition
    module_sort = False
    if rel == 'src/script.rs':
        old_fragment = public_fragment.read_text()
        sorted_fragment = '\n#[cfg(test)]\nmod with_resolvers_abort_tests;\n#[cfg(test)]\nmod with_resolvers_semantics_tests;\n'
        assert composition.endswith(old_fragment)
        composition = composition[:-len(old_fragment)] + sorted_fragment
        module_sort = True
    t1, l1, c1 = tokens(composition)
    t2, l2, c2 = tokens(actual)
    assert l1 == l2, ('literal', rel)
    assert c1 == c2, ('comment', rel)
    edits = []
    opcodes = [] if t1 == t2 else difflib.SequenceMatcher(a=t1, b=t2).get_opcodes()
    for kind, i, j, a, b in opcodes:
        if kind == 'equal': continue
        left, right = t1[i:j], t2[a:b]
        strip_optional = lambda seq: [x for x in seq if x not in {',', '{', '}'}]
        assert strip_optional(left) == strip_optional(right), (rel, kind, left, right)
        edits.append({'kind': kind, 'before': left, 'after': right,
                      'left_context': t1[max(0,i-10):i], 'right_context': t1[j:j+10]})
    if actual != unmodified_composition:
        format_changed.append(rel)
        (D / 'format-diffs').mkdir(exist_ok=True)
        filename = rel.replace('/', '__') + '.diff'
        (D / 'format-diffs' / filename).write_text(''.join(difflib.unified_diff(unmodified_composition.splitlines(True),actual.splitlines(True),fromfile='composed/'+rel,tofile='formatted/'+rel)))
    if edits: punctuation.append({'relative': rel, 'edits': edits})
    rows.append({'relative': rel, 'origins': origins[rel], 'composed_sha256': sha(unmodified_composition), 'formatted': bound(W/rel), 'exact_after_optional_module_sort': composition == actual,
                 'literal_count': len(l1), 'literal_vector_sha256': sha(json.dumps(l1,ensure_ascii=False)), 'comment_vector_exact': True, 'module_sort': module_sort, 'punctuation_edits': len(edits)})

# Independently undo exactly the selected production deltas, restoring every
# old helper body/type declaration byte for byte in the unformatted hold.
inverse = []
for row in holds['production-1']['files']:
    rel = row['path']; raw = Path(row['raw']).read_text(); restored = raw
    if rel == 'src/script.rs':
        restored = restored.replace('        self.install_promise_any_intrinsic()?;\n        self.install_promise_with_resolvers_intrinsic()\n', '        self.install_promise_any_intrinsic()\n', 1)
    elif rel == 'src/script/dom_prototypes.rs':
        restored = restored.replace('    + promises::WITH_RESOLVERS_METADATA_OBJECTS\n', '', 1)
    elif rel == 'src/script/promises.rs':
        restored = restored.replace('pub(super) const WITH_RESOLVERS_METADATA_OBJECTS: usize = 1;\n', '', 1)
    elif rel == 'src/script/machine/calls.rs':
        restored = restored.replace('                    | "Promise.withResolvers"\n', '', 1)
    else:
        name = {'src/script/promises/semantics.rs': 'promise_with_resolvers', 'src/script/promises/factories.rs': 'new_promise_capability_result', 'src/script/promises/install.rs': 'install_promise_with_resolvers_intrinsic'}[rel]
        match = re.search(r'^    (?:pub\([^\n]+?\) )?fn '+name+r'\(', restored, re.M)
        assert match
        end = restored.index('\n    }\n\n', match.start()) + len('\n    }\n\n')
        restored = restored[:match.start()] + restored[end:]
        if rel.endswith('semantics.rs'):
            restored = restored.replace('                "Promise.withResolvers" => self.promise_with_resolvers(receiver, doc),\n', '', 1)
    assert sha(restored) == row['before'] == old[rel], ('production inverse', rel)
    inverse.append({'relative': rel, 'parent_sha256': sha(restored), 'exact': True})

checks = write('checks.json', {'status': 'data checks passed; punctuation contexts retained for human source review', 'selected_input_count': len(new), 'existing_changed': len(changed), 'new_modules': len(added), 'composition_paths': rows, 'format_changed_paths': format_changed, 'production_inverse': inverse, 'all_other_selected_inputs_exact_parent': len(old)-len(changed), 'literal_vectors_exact': True, 'unchanged_type_declarations': 'Exact seven-file production inverses leave every prior struct/enum/Runtime declaration unchanged; the only declaration addition is a usize metadata-count constant.'})
punct = write('punctuation-contexts.json', punctuation)
print(json.dumps({'checks': checks, 'punctuation': punct, 'format_changed_paths': format_changed, 'punctuation_contexts': sum(len(x['edits']) for x in punctuation)}))
