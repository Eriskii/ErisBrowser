import json
from pathlib import Path
import subprocess
B=Path(__file__).resolve().parents[1];W=B/'worktree';MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE='33ddb14aea0b8a20b7e340c4a5900abda3062f6f';P=B/'publication';P.mkdir(exist_ok=True);record_path=B/'root/github-publication.json';assert not record_path.exists()
verified=json.loads((B/'root/publication-verification.json').read_bytes());assert verified['status']=='verified' and verified['path_count']==34

def git(directory,*args):
 r=subprocess.run(['git',*args],cwd=directory,text=True,capture_output=True,check=True);return r.stdout.strip()

assert git(MAIN,'branch','--show-current')=='main'
assert git(MAIN,'rev-parse','HEAD')==git(W,'rev-parse','HEAD')==BASE
assert git(MAIN,'status','--porcelain')=='' and git(W,'diff','--cached','--name-only')==''
paths=verified['expected_commit_paths'];pathspec=P/'paths.nul';pathspec.write_bytes(b'\0'.join(p.encode() for p in paths)+b'\0')
git(W,'add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul')
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
git(W,'diff','--cached','--check')
message=P/'commit-message.txt';message.write_text('Implement custom Promise.withResolvers\n\nCreate capabilities through the dynamic constructor and return a fresh ordinary\nobject with exact promise, resolve and reject identities. Use the saved Object\nprototype and preserve terminal queue suspension and existing resource limits.\n\nValidate 24 new test groups, full Rust suites (3221 default and 3575 host/Vulkan),\nstrict Clippy and formatting. Rebuilt adapters preserve all 1288 existing\nconformance cases and 502 harness controls across six profiles.\n')
(P/'commit.log').write_text(git(W,'commit','-F',str(message))+'\n');commit=git(W,'rev-parse','HEAD')
assert git(W,'status','--porcelain')==''
assert set(git(W,'diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())==set(paths)
record={'status':'committed','base':BASE,'commit':commit,'repository':'https://github.com/Eriskii/ErisBrowser','paths':len(paths)};record_path.write_text(json.dumps(record,indent=2)+'\n')
(P/'merge.log').write_text(git(MAIN,'merge','--ff-only','promise-with-resolvers-runtime')+'\n')
assert git(MAIN,'rev-parse','HEAD')==commit and git(MAIN,'status','--porcelain')==''
(P/'push.log').write_text(git(MAIN,'push','origin','main')+'\n');remote=git(MAIN,'ls-remote','origin','refs/heads/main').split()[0];assert remote==commit
record.update(status='pushed',remote_head=remote,ci='not yet observed');record_path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
