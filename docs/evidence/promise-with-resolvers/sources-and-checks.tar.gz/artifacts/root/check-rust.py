"""Reconcile real Rust result rows and old/new test identity multisets."""
from pathlib import Path
from collections import Counter
import json,re,hashlib
B=Path(__file__).resolve().parents[1]
def load(p):return json.loads((B/p).read_bytes())
def bind(p):
 data=(B/p).read_bytes();return {'path':str(B/p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
renames=load('migrations-1/test-roster.json')['function_renames']
added=Counter('script::'+r['module']+'::'+r['test'] for r in load('public-contract-1/roster.json')['groups'])
added.update('script::promises::with_resolvers_quota_tests::'+r['name'] for r in load('private-contract-1/roster.json')['rows'])
assert sum(added.values())==24
records=[]
for name,parent,expected in [('default-full-1','default-full-2',3221),('host-vulkan-full-1','host-vulkan-full-1',3575)]:
 s=(B/'validation'/f'{name}.log').read_text();old=(B/'rust-parent'/f'{parent}.log').read_text()
 report=load('validation/'+name+'.json');assert report['exit']==0 and report['sha256']==hashlib.sha256(s.encode()).hexdigest()
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s)
 totals=[sum(int(r[i]) for r in rows) for i in range(5)];assert len(rows)==52 and totals==[expected,0,0,0,0],(name,totals,len(rows))
 now=Counter(re.findall(r'^test (\S+) \.\.\. ok$',s,re.M));before=Counter(re.findall(r'^test (\S+) \.\.\. ok$',old,re.M))
 assert sum(now.values())==expected and sum(before.values())==expected-24
 for rename in renames:
  keys=[k for k in before if k.endswith('::'+rename['before'])];assert len(keys)==1
  key=keys[0];count=before.pop(key);before[key[:-len(rename['before'])]+rename['after']]=count
 assert now==before+added,(name,now-before-added,before+added-now)
 records.append({'configuration':name,'totals':totals,'result_rows':len(rows),'parent_tests':expected-24,'new_groups':24,'old_renames':4,'complete_test_identity_multiset_preserved':True,'log':bind('validation/'+name+'.log'),'receipt':bind('validation/'+name+'.json')})
record={'status':'pass','runs':records,'caveat':'Selected configurations and unchanged runtime limits; no complete standards/security/Chromium performance conclusion.'}
with (B/'root/rust-validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
