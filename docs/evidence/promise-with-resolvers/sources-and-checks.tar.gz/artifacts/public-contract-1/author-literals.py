"""Freeze source-derived public literals without importing or executing Eris."""
from pathlib import Path
import hashlib,json,subprocess,textwrap
B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1');D=B/'public-contract-1'
BASE='33ddb14aea0b8a20b7e340c4a5900abda3062f6f'
REPO=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(name,obj):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2)+'\n');return rec(p)
def clean(s):return textwrap.dedent(s).strip()+'\n'
GUARD="if(typeof Promise.withResolvers!=='function')throw new Error('Promise.withResolvers missing');\n"
CHECK="function check(v){if(!v)throw new Error('oracle');}\n"
cases=[]
def add(name,body,expected,derivation,observation='result',steps=None):
 rows=[dict(source=GUARD+CHECK+clean(body),observation=observation,expected=dict(type='string',value=expected))]
 if steps:
  for source,expr,value in steps:rows.append(dict(source=clean(source),observation=expr,expected=dict(type='string',value=value)))
 cases.append(dict(id=name,steps=rows,derivation=derivation))
add('metadata_and_detached_nonconstruction',r'''
var f=Promise.withResolvers,O=Object,has=O.prototype.hasOwnProperty,d=O.getOwnPropertyDescriptor(Promise,'withResolvers');
check(d.value===f&&d.writable&&!d.enumerable&&d.configurable);
var n=O.getOwnPropertyDescriptor(f,'name'),l=O.getOwnPropertyDescriptor(f,'length');
check(n.value==='withResolvers'&&!n.writable&&!n.enumerable&&n.configurable);
check(l.value===0&&!l.writable&&!l.enumerable&&l.configurable);
check(O.getPrototypeOf(f)===Function.prototype&&!has.call(f,'prototype'));
var count=0;
try{f();}catch(e){check(e instanceof TypeError);count++;}
try{f.bind(undefined)();}catch(e){check(e instanceof TypeError);count++;}
try{new f();}catch(e){check(e instanceof TypeError);count++;}
try{Reflect.construct(f,[]);}catch(e){check(e instanceof TypeError);count++;}
check(count===4);var result='metadata:4';
''','metadata:4','Method arity0/name/descriptor and Function prototype follow builtin metadata. A detached receiver is not a constructor; the method itself has no construction capability.')
add('genuine_pending_then_deferred_first_settlement',r'''
var P=Promise,cap=P.withResolvers(),winner={},reason={},trace='S';
check(cap.promise instanceof P&&Object.getPrototypeOf(cap.promise)===P.prototype);
check(typeof cap.resolve==='function'&&typeof cap.reject==='function'&&cap.resolve!==cap.reject);
cap.promise.then(function(v){trace+=v===winner?'F':'x';},function(){trace+='J';});
queueMicrotask(function(){trace+='Q';});check(trace==='S');
''','SQ','First checkpoint leaves the capability pending. The next source resolves it; handlers run only after the source, and later resolve/reject calls have no effect.',observation='trace',steps=[(r'''
trace+='A';check(cap.resolve.call({ignored:true},winner)===undefined);check(trace==='SQA');
check(cap.reject(reason)===undefined&&cap.resolve(reason)===undefined);trace+='B';
''','trace','SQABF'),("check(cap.resolve(reason)===undefined&&cap.reject(reason)===undefined);",'trace','SQABF')])
add('genuine_reject_and_missing_resolution_argument',r'''
var a=Promise.withResolvers(),b=Promise.withResolvers(),reason={},trace='S';
a.promise.then(function(v){trace+=v===undefined?'U':'x';},function(){trace+='x';});
b.promise.then(function(){trace+='x';},function(v){trace+=v===reason?'R':'x';});
check(a.resolve()===undefined&&b.reject(reason)===undefined);
check(a.reject(reason)===undefined&&b.resolve(9)===undefined&&trace==='S');
''','SUR','The no-argument resolve supplies undefined. Exact rejection identity is preserved; both callbacks share each capability first-settlement state. Reactions retain enqueue order.',observation='trace')
add('thenable_assimilation_and_self_resolution',r'''
var cap=Promise.withResolvers(),winner={},trace='';
var thenable={get then(){trace+='G';return function(resolve,reject){check(this===thenable);trace+='T';resolve(winner);reject(1);resolve(2);};}};
cap.promise.then(function(v){trace+=v===winner?'F':'x';},function(){trace+='x';});
check(cap.resolve(thenable)===undefined&&trace==='G');trace+='S';
queueMicrotask(function(){trace+='Q';});
''','GSTQF','Then lookup is synchronous; the thenable job runs before the queued sentinel and schedules the fulfillment reaction after it. A separate self-resolution rejects with TypeError.',observation='trace',steps=[(r'''
var self=Promise.withResolvers();self.promise.then(function(){trace+='x';},function(e){trace+=e instanceof TypeError?'E':'x';});
check(self.resolve(self.promise)===undefined);trace+='A';
''','trace','GSTQFAE')])
add('generic_constructor_executor_and_exact_callback_identity',r'''
var f=Promise.withResolvers,holder=Object.create(null),receiver={},token={},ret={},trace='',calls=0;
function resolve(v){check(this===receiver&&v===token);calls++;trace+='R';return ret;}
function reject(v){check(this===receiver&&v===token);calls++;trace+='J';return ret;}
function C(ex){
 check(new.target===C&&arguments.length===1&&typeof ex==='function');trace+='C';
 check(ex.length===2&&ex.name===''&&!Object.prototype.hasOwnProperty.call(ex,'prototype'));
 var bad=false;try{new ex();}catch(e){check(e instanceof TypeError);bad=true;}check(bad);
 check(ex.call(receiver,resolve,reject)===undefined);trace+='E';return holder;
}
var resultObject=f.call(C);check(trace==='CE'&&calls===0);
check(resultObject.promise===holder&&resultObject.resolve===resolve&&resultObject.reject===reject);
check(resultObject.resolve.call(receiver,token)===ret&&resultObject.reject.call(receiver,token)===ret);
check(calls===2);var result=trace;
''','CERJ','Construct receives exactly one native capability executor with arity2. Arbitrary returned object and both callable values retain identity. No callback runs until the test calls it, preserving receiver and return value.')
add('bound_constructor_and_shared_callable_values',r'''
var f=Promise.withResolvers,prefix={},receiver={},token={},ret={},trace='',calls=0;
function callback(v){check(this===receiver&&v===token);calls++;trace+='R';return ret;}
var shared=callback.bind(receiver);
function C(first,ex){check(new.target===C&&first===prefix&&arguments.length===2);this.marker=prefix;trace+='C';ex(shared,shared);}
var Bound=C.bind({unused:true},prefix),run=f.bind(Bound),box=run();
check(box.promise.marker===prefix&&Object.getPrototypeOf(box.promise)===C.prototype);
check(box.resolve===shared&&box.reject===shared&&calls===0&&trace==='C');
check(box.resolve(token)===ret&&box.reject(token)===ret&&calls===2);var result=trace;
''','CRR','Bound constructor semantics supply its prebound argument and target NewTarget; identical callable resolve/reject values are valid and remain unwrapped.')
add('saved_object_intrinsic_and_own_data_descriptors',r'''
var P=Promise,O=Object,OP=O.prototype,f=P.withResolvers,holder={},trace='',setters=0;
function resolve(){}function reject(){}
var descriptor=O.create(null);descriptor.set=function(){setters++;};descriptor.configurable=true;
function C(ex){trace+='C';ex(resolve,reject);
 O.defineProperty(OP,'promise',descriptor);O.defineProperty(OP,'resolve',descriptor);O.defineProperty(OP,'reject',descriptor);
 Object=function(){throw new Error('global Object used');};Object.prototype={wrong:true};
 Promise=function(){throw new Error('global Promise used');};return holder;
}
var box=f.call(C);check(O.getPrototypeOf(box)===OP&&O.isExtensible(box));
check(Reflect.ownKeys(box).join(',')==='promise,resolve,reject'&&O.keys(box).join(',')==='promise,resolve,reject');
var names=['promise','resolve','reject'],values=[holder,resolve,reject];
for(var i=0;i<3;i++){var d=O.getOwnPropertyDescriptor(box,names[i]);check(d.value===values[i]&&d.writable&&d.enumerable&&d.configurable&&!('get' in d)&&!('set' in d));}
check(setters===0&&trace==='C');var result='C|promise,resolve,reject|0';
''','C|promise,resolve,reject|0','Result allocation follows capability construction but uses the saved realm Object prototype, not either replaced global. CreateDataProperty defines three own W/E/C data properties in order and bypasses inherited setters. Null-prototype setup descriptors prevent inherited-field ambiguity.')
add('fresh_results_mutation_and_resolver_metadata',r'''
var a=Promise.withResolvers(),b=Promise.withResolvers(),p=a.promise,r=a.resolve,j=a.reject,x={},y={},trace='S';
check(a!==b&&a.promise!==b.promise&&a.resolve!==b.resolve&&a.reject!==b.reject&&a.resolve!==b.reject&&a.reject!==b.resolve);
var functions=[a.resolve,a.reject,b.resolve,b.reject];
for(var i=0;i<functions.length;i++){var f=functions[i],l=Object.getOwnPropertyDescriptor(f,'length'),n=Object.getOwnPropertyDescriptor(f,'name');
 check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable&&n.value===''&&!n.writable&&!n.enumerable&&n.configurable);
 check(Object.getPrototypeOf(f)===Function.prototype&&!Object.prototype.hasOwnProperty.call(f,'prototype'));
 var caught=false;try{Reflect.construct(f,[]);}catch(e){check(e instanceof TypeError);caught=true;}check(caught);
}
a.promise={};check(delete a.resolve);Object.defineProperty(a,'reject',{value:17});a.extra=true;
check(a.promise!==p&&!Object.prototype.hasOwnProperty.call(a,'resolve')&&a.reject===17&&b.resolve!==undefined);
p.then(function(v){trace+=v===x?'A':'x';},function(){trace+='x';});
b.promise.then(function(){trace+='x';},function(v){trace+=v===y?'B':'x';});
check(r(x)===undefined&&j(y)===undefined&&b.reject(y)===undefined&&trace==='S');
''','SAB','Each call creates a fresh result and distinct genuine capability functions. Own fields are ordinary mutable/configurable data; deleting/replacing them does not affect saved callbacks, pending Promise identity, or another capability.',observation='trace')
add('invalid_receivers_and_missing_noncallable_capabilities',r'''
var f=Promise.withResolvers,count=0,bad=[undefined,null,true,1,'x',Symbol('x'),{},()=>{},Promise.resolve];
for(var i=0;i<bad.length;i++){var caught=false;try{f.call(bad[i]);}catch(e){check(e instanceof TypeError);caught=true;count++;}check(caught);}
function Missing(ex){}function Empty(ex){ex();}function BadResolve(ex){ex(1,function(){});}
function BadReject(ex){ex(function(){},1);}function Nulls(ex){ex(null,null);}function Returned(ex){return {};}
var constructors=[Missing,Empty,BadResolve,BadReject,Nulls,Returned];
for(var k=0;k<constructors.length;k++){var seen=false;try{f.call(constructors[k]);}catch(e){check(e instanceof TypeError);seen=true;count++;}check(seen);}
check(count===15);var result='type-errors:15';
''','type-errors:15','IsConstructor rejects nine receivers. Six actual constructors fail capability capture/callability validation after construction; all errors remain synchronous TypeError and cannot pass via incidental absent-method failure.')
add('ordinary_constructor_abrupt_identity_and_no_reject_conversion',r'''
var f=Promise.withResolvers,one={},two={},trace='',calls=0,returned=false;
function resolve(){calls++;}function reject(){calls++;}
function Before(ex){trace+='B';throw one;}function After(ex){trace+='A';ex(resolve,reject);trace+='E';throw two;}
function Primitive(ex){trace+='P';throw 7;}
try{f.call(Before);returned=true;}catch(e){check(e===one);trace+='1';}finally{trace+='f';}
try{f.call(After);returned=true;}catch(e){check(e===two);trace+='2';}finally{trace+='f';}
try{f.call(Primitive);returned=true;}catch(e){check(e===7);trace+='3';}finally{trace+='f';}
check(!returned&&calls===0);var result=trace;
''','B1fAE2fP3f','Construct abrupt completion propagates the exact object/primitive synchronously both before and after capture. Neither capability callback is invoked to convert the throw into settlement; ordinary catch/finally runs.')
add('executor_repeat_uses_stored_values_not_once_flag',r'''
var f=Promise.withResolvers,trace='',resolve=function(){},reject=function(){},other=function(){};
function Valid(ex){check(ex()===undefined&&ex(undefined,undefined)===undefined);trace+='U';check(ex(resolve,reject)===undefined);trace+='V';
 var caught=false;try{ex(other,other);}catch(e){check(e instanceof TypeError);caught=true;trace+='D';}check(caught);}
var box=f.call(Valid);check(box.resolve===resolve&&box.reject===reject);
var pairs=[[resolve,undefined],[undefined,reject],[null,undefined],[undefined,null]],outer=0,inner=0;
for(var i=0;i<pairs.length;i++){
 function Partial(ex){ex(pairs[i][0],pairs[i][1]);try{ex(resolve,reject);}catch(e){check(e instanceof TypeError);inner++;}}
 var caught=false;try{f.call(Partial);}catch(e){check(e instanceof TypeError);caught=true;outer++;}check(caught);
}
check(inner===4&&outer===4);var result=trace+'|'+inner+'|'+outer;
''','UVD|4|4','Repeated undefined/undefined captures are permitted. Once either stored slot is non-undefined the executor rejects repeats; a caught duplicate preserves the first pair. Partial captures still fail final callability checks.')
add('ignored_arguments_evaluate_without_unrelated_gets',r'''
var f=Promise.withResolvers,trace='',holder={},resolve=function(){},reject=function(){},poison={};
function trap(){trace+='X';throw new Error('unrelated access');}
Object.defineProperty(poison,Symbol.iterator,{get:trap});Object.defineProperty(poison,'then',{get:trap});
poison.valueOf=trap;poison.toString=trap;
function C(ex){trace+='C';ex(resolve,reject);return holder;}
Object.defineProperty(C,'resolve',{get:trap});Object.defineProperty(C,Symbol.species,{get:trap});
function argument(){trace+='A';return poison;}
var box=f.call(C,argument(),argument());check(box.promise===holder&&trace==='AAC');
var caught=false;try{f.call({},argument());}catch(e){check(e instanceof TypeError);caught=true;trace+='T';}
check(caught&&trace==='AACAT');var result=trace;
''','AACAT','Call argument evaluation precedes capability validation. withResolvers ignores the resulting values and never gets C.resolve, species, an iterator or then/coercion hooks.')

terminal=[]
for stage in ['before_capture','after_capture','queued_before_capture']:
 rows=[]
 for unsupported,action in [(False,'while(true){}'),(True,"eval('0');")]:
  head="var trace='',captures=0,fulfills=0,rejects=0,after=false;function resolve(){fulfills++;}function reject(){rejects++;}\n"
  code="trace+='C';"
  if stage!='after_capture':code+=action
  code+="ex(resolve,reject);captures++;trace+='E';"
  if stage=='after_capture':code+=action
  constructor='function C(ex){'+code+'}\n'
  operation="try{Promise.withResolvers.call(C);after=true;}catch(e){trace+='X';}finally{trace+='F';}trace+='Z';"
  if stage=='queued_before_capture':tail='queueMicrotask(function(){'+operation+"});queueMicrotask(function(){trace+='Q';});trace+='S';\n"
  else:tail="queueMicrotask(function(){trace+='Q';});"+operation+'\n'
  rows.append(dict(id=stage+('_unsupported' if unsupported else '_resource'),unsupported=unsupported,source=GUARD+head+constructor+tail))
 prefix='CE' if stage=='after_capture' else 'SC' if stage=='queued_before_capture' else 'C'
 terminal.append(dict(id=stage,cases=rows,observation="[trace,captures,fulfills,rejects,after].join('|')",expected=prefix+('|1' if stage=='after_capture' else '|0')+'|0|0|false',derivation='Host terminal abort bypasses author catch/finally, later statements, callback invocation and queued sentinel. Capture effects before the terminal remain visible. Repeated checkpoint readback must preserve suspension.'))

bindings=[]
paths=['src/script.rs','src/script/promises.rs','src/script/promises/semantics.rs','src/script/promises/factories.rs','src/script/construction.rs','src/script/machine/calls.rs','src/script/promise_any_semantic_tests.rs','src/script/promise_any_abort_tests.rs','src/script/promise_all_settled_semantic_tests.rs']
for rel in paths:
 data=subprocess.check_output(['git','-C',str(REPO),'show',BASE+':'+rel]);p=D/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);bindings.append(dict(relative_path=rel,published_git_blob=subprocess.check_output(['git','-C',str(REPO),'rev-parse',BASE+':'+rel]).decode().strip(),snapshot=rec(p)))
write('source-bindings.json',dict(base=BASE,files=bindings,readiness=rec(B/'readiness-1/source-ready.json'),root_spec=rec(B/'root/spec-readiness.json'),root_selection=rec(B/'root/selection-1.json')))
write('semantic-cases.json',dict(base=BASE,modes=['sloppy','strict'],status='Frozen source-derived literals before production/execution; no outcomes observed',cases=cases))
write('terminal-cases.json',dict(base=BASE,modes=['sloppy','strict'],status='Frozen public host-terminal contracts; no selected private numeric admission cuts',cases=terminal,fresh_control=dict(source="var trace='S';queueMicrotask(function(){trace+='Q';});",observation='trace',expected='SQ')))
write('spec-review.json',dict(primary_urls=['https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.withresolvers','https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-newpromisecapability','https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-createresolvingfunctions'],reviewed_date='2026-10-15',paraphrase='withResolvers creates a capability using its receiver before allocating the result. The result has the intrinsic Object prototype and own writable/enumerable/configurable promise, resolve and reject data properties in that order. Capability construction requires a constructor, passes one executor, preserves abrupt completion, and validates both captured values callable. The executor permits repeats only while both stored values are undefined. Genuine resolving functions share settlement state; resolution reads then synchronously and queues callable then assimilation. Host terminal policy is an Eris constraint, not an ECMAScript catchable exception.',scope='No classes, Proxy, realms, Promise.try, upstream profile, decoder changes, new limits, production inspection or project execution.'))
write('literal-ready.json',dict(status='sealed public literals and source-derived expectations; Rust conversion follows',base=BASE,semantic_groups=len(cases),semantic_mode_rows=2*len(cases),semantic_source_phase_attempts=2*sum(len(x['steps']) for x in cases),terminal_groups=len(terminal),terminal_mode_attempts=4*len(terminal),members=[rec(D/x) for x in ['semantic-cases.json','terminal-cases.json','spec-review.json','source-bindings.json']],parent_prediction='All15 groups fail at first sloppy absent-method guard (ordinary Error), before semantic readbacks or terminal-classification success; remaining strict/phase/readback/control rows are unreached. This is source-predicted only.'))
print(json.dumps(rec(D/'literal-ready.json')))
