"""Mechanical literal-to-Rust conversion; no project code import/execution."""
from pathlib import Path
import hashlib,json,difflib,re
B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1');D=B/'public-contract-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def rec(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(rel,text):
 p=D/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);return p
literal=json.loads((D/'literal-ready.json').read_text())
for item in literal['members']:
 p=Path(item['path']);assert p.stat().st_size==item['bytes'] and sha(p.read_bytes())==item['sha256']
semantic=json.loads((D/'semantic-cases.json').read_text())['cases']
terminal_doc=json.loads((D/'terminal-cases.json').read_text());terminal=terminal_doc['cases']
def raw(s):assert '"###' not in s;return 'r###"'+s+'"###'
common='''use super::*;

fn execute_mode(runtime: &mut Runtime, document: &mut Document, strict: bool, source: &str) -> Result<Value> {
    if strict { runtime.execute_strict(source, document) } else { runtime.execute(source, document) }
}
'''
s='//! Public Promise.withResolvers source-derived contracts, frozen before production.\n'+common+'''
fn observe(case_id: &str, phases: &[(&str, &str, Value)]) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        for (phase, (source, expression, expected)) in phases.iter().enumerate() {
            execute_mode(&mut runtime, &mut document, strict, source)
                .unwrap_or_else(|error| panic!("{case_id} strict={strict} phase={phase} source: {error:?}"));
            let observed = execute_mode(&mut runtime, &mut document, strict, expression)
                .unwrap_or_else(|error| panic!("{case_id} strict={strict} phase={phase} observation: {error:?}"));
            assert_eq!(&observed, expected, "{case_id} strict={strict} phase={phase}");
        }
    }
}
'''
roster=[]
for case in semantic:
 name='promise_with_resolvers_'+case['id'];s+='\n#[test]\nfn '+name+'() {\n    observe('+json.dumps(case['id'])+', &[\n'
 for step in case['steps']:
  assert step['expected']['type']=='string'
  s+='        ('+raw(step['source'])+', '+raw(step['observation'])+', Value::String('+json.dumps(step['expected']['value'])+'.into())),\n'
 s+='    ]);\n}\n'
 roster.append(dict(module='with_resolvers_semantics_tests',test=name,modes=2,source_phases=len(case['steps']),parent_first='first sloppy missing-method Error; observation and remaining phases/strict are unreached'))
p=write('raw/src/script/with_resolvers_semantics_tests.rs',s)
expected_literals=[v for case in semantic for step in case['steps'] for v in (step['source'],step['observation'])]
assert re.findall(r'r###"(.*?)"###',s,re.S)==expected_literals
fresh=terminal_doc['fresh_control']
a='//! withResolvers host-terminal contracts; no manual budget or queue reset.\n'+common+'''
fn fatal_stop(cases: &[(&str, bool, &str)], expression: &str, expected: &str) {
    for &(case_id, unsupported, source) in cases {
        for strict in [false, true] {
            let mut runtime = Runtime::try_new().unwrap();
            let mut document = Document::parse("");
            let error = execute_mode(&mut runtime, &mut document, strict, source).unwrap_err();
            assert_eq!(error.is_unsupported(), unsupported, "{case_id} strict={strict}: {error:?}");
            assert_eq!(error.is_resource_limit(), !unsupported, "{case_id} strict={strict}: {error:?}");
            assert!(runtime.microtasks_suspended(), "{case_id} strict={strict}");
            for _ in 0..2 {
                let observed = execute_mode(&mut runtime, &mut document, strict, expression).unwrap();
                assert_eq!(observed, Value::String(expected.into()), "{case_id} strict={strict}");
                assert!(runtime.microtasks_suspended());
                assert!(runtime.console.is_empty());
            }
        }
    }
    // Fresh runtime proves ordinary queued work still drains; the suspended
    // runtimes above are never reset or reused for this preservation control.
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, '''+raw(fresh['source'])+''').unwrap();
        let value = execute_mode(&mut runtime, &mut document, strict, '''+raw(fresh['observation'])+''').unwrap();
        assert_eq!(value, Value::String('''+json.dumps(fresh['expected'])+'''.into()));
        assert!(!runtime.microtasks_suspended());
    }
}
'''
for case in terminal:
 name='promise_with_resolvers_'+case['id']+'_terminal';a+='\n#[test]\nfn '+name+'() {\n    fatal_stop(&[\n'
 for row in case['cases']:a+='        ('+json.dumps(row['id'])+', '+str(row['unsupported']).lower()+', '+raw(row['source'])+'),\n'
 a+='    ], '+raw(case['observation'])+', '+json.dumps(case['expected'])+');\n}\n'
 roster.append(dict(module='with_resolvers_abort_tests',test=name,terminal_attempts=4,repeated_readbacks_per_attempt=2,fresh_queue_controls=2,parent_first='first sloppy Resource row returns missing-method ordinary Error; resource assertion fails before suspension/readbacks; all later rows/strict/fresh controls unreached'))
q=write('raw/src/script/with_resolvers_abort_tests.rs',a)
expected_abort=[fresh['source'],fresh['observation']]+[v for case in terminal for v in [*(r['source'] for r in case['cases']),case['observation']]]
assert re.findall(r'r###"(.*?)"###',a,re.S)==expected_abort
append='\n#[cfg(test)]\nmod with_resolvers_semantics_tests;\n#[cfg(test)]\nmod with_resolvers_abort_tests;\n'
reg_before=D/'parent/src/script.rs';before=reg_before.read_text();assert 'mod with_resolvers_' not in before
write('registration-append.txt',append);reg=write('raw/src/script.rs',before+append)
assert reg.read_text().removesuffix(append)==before
files=[]
for rel in ['src/script.rs','src/script/with_resolvers_semantics_tests.rs','src/script/with_resolvers_abort_tests.rs']:
 r=D/'raw'/rel;b=reg_before if rel=='src/script.rs' else None;old=b.read_text() if b else ''
 patch=''.join(difflib.unified_diff(old.splitlines(True),r.read_text().splitlines(True),fromfile='a/'+rel if b else '/dev/null',tofile='b/'+rel))
 dp=write('diffs/'+rel+'.patch',patch)
 files.append(dict(relative_path=rel,before=rec(b) if b else None,raw=rec(r),diff=rec(dp)))
write('roster.json',json.dumps(dict(groups=roster,semantic_groups=12,semantic_modes=24,semantic_source_phases=30,terminal_groups=3,terminal_attempts=12,terminal_readbacks=24,fresh_queue_controls=6,total_groups=15,parent_prediction=dict(pass_groups=0,fail_groups=15,reachability='source-predicted absent-method failures only; no project/compiler/engine execution')),indent=2)+'\n')
checks=dict(status='source conversion exact',json_and_rust_literal_equality=True,semantic_raw_literals=len(expected_literals),abort_raw_literals=len(expected_abort),registration_exact_append=True,registration_inverse_sha256=sha(reg_before.read_bytes()),parent_apis=['Runtime::try_new','Runtime::execute','Runtime::execute_strict','Document::parse','Value::String','ScriptError::is_unsupported','ScriptError::is_resource_limit','Runtime::microtasks_suspended','Runtime::console child-module visibility'],no_project_execution=True,no_live_edits=True,no_private_numeric_cuts=True)
write('conversion-checks.json',json.dumps(checks,indent=2)+'\n')
seal=dict(status='sealed external public15 tests; source-derived expectations frozen before production execution',base=literal['base'],literal_ready=rec(D/'literal-ready.json'),files=files,registration=rec(D/'registration-append.txt'),roster=rec(D/'roster.json'),checks=rec(D/'conversion-checks.json'),source_bindings=rec(D/'source-bindings.json'),authoring_scripts=[rec(D/'author-literals.py'),rec(D/'convert.py')],scope='Two new script child modules and exact small test-only append. No production, fee assertions, unsupported syntax implementation, Promise.try or host-profile changes. Parent predicted0/15 and unreached later rows are explicit; no observed outcome.')
write('source-ready.json',json.dumps(seal,indent=2)+'\n');print(json.dumps(rec(D/'source-ready.json')))
