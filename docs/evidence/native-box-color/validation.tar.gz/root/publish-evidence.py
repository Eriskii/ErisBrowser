"""Root-only bounded publication of selected Native Color BoxDecoration evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent.parent
W = P / 'worktree'
BASE = 'c9d4e5effdb82f0b7a5518cc541583e09a89aea9'
D = W / 'docs/evidence/native-box-color'
CAP = 64 * 1024 * 1024
TREES = {'plan', 'root', 'helper', 'tests', 'prepass', 'gpu', 'docs', 'validation'}
VERIFIED = {}
REQUIRED = {'full_native', 'full_default', 'clippy_native_msrv', 'clippy_native_current',
            'clippy_default_current', 'format', 'probe_cpu', 'browser_build', 'browser_strip', 'reftests'}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def local(name, root=P):
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path


def binding(path):
    result = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}
    assert VERIFIED.setdefault(path, result) == result, path
    return result


def checked(spec, root=P):
    path = local(spec['path'], root)
    actual = binding(path)
    assert actual['bytes'] == spec['bytes'] and actual['sha256'] == spec['sha256'], path
    return path


def read(spec):
    return json.loads(checked(spec).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return {'rows': len(rows), 'passed': sum(int(x[1]) for x in rows),
            'failed': sum(int(x[2]) for x in rows), 'ignored': sum(int(x[3]) for x in rows)}


def main():
    assert __debug__ and len(sys.argv) == 2, 'usage: python3 publish-evidence.py SELECTION.json; no -O'
    selected_path = local(sys.argv[1])
    s = json.loads(selected_path.read_text())
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    source_path = checked(s['source'])
    gpu_source_path = checked(s['gpu']['source'])
    assert source_path.name == 'compiled-source-4.json' and gpu_source_path.name == 'compiled-source-3.json'
    source, gpu_source = read(s['source']), read(s['gpu']['source'])
    assert source['base'] == gpu_source['base'] == BASE
    inputs, gpu_inputs = source['source_sha256'], gpu_source['source_sha256']
    assert len(inputs) == s['source_count'] and len(inputs) > 0
    for name, sha in inputs.items():
        assert digest(local(name, W)) == sha, name
    source_sha, gpu_source_sha = digest(source_path), digest(gpu_source_path)

    # The GPU run belongs to source3. Independently prove the selected runtime delta.
    runtime = read(s['runtime_review'])
    assert runtime['status'] == 'clear' and runtime['runtime_source_equal'] is True
    assert checked(runtime['source3']) == gpu_source_path and checked(runtime['source4']) == source_path
    delta = sorted(k for k in inputs.keys() | gpu_inputs.keys() if inputs.get(k) != gpu_inputs.get(k))
    assert delta == sorted(runtime['changed_files']) == [
        '.github/workflows/check.yml', 'src/graphics/raster_bridge/native.rs',
        'src/graphics/raster_bridge/native/box_prepass_tests.rs']
    assert gpu_inputs.keys() < inputs.keys()
    suffix = b'\n#[cfg(test)]\nmod box_prepass_tests;\n'
    native = local('src/graphics/raster_bridge/native.rs', W).read_bytes()
    assert native.endswith(suffix)
    assert hashlib.sha256(native[:-len(suffix)]).hexdigest() == gpu_inputs['src/graphics/raster_bridge/native.rs']
    for item in runtime['files']:
        checked(item)

    # Preserve every actual attempt; selected successes do not erase failed/partial runs.
    attempts = {}
    for path in sorted((P / 'validation').glob('*.json')):
        record = json.loads(path.read_text())
        if not {'command', 'exit', 'log', 'sha256'} <= record.keys():
            continue
        log = local(record['log'], path.parent)
        assert digest(log) == record['sha256'], path
        attempts[path.name] = {'receipt': binding(path), 'log': binding(log),
            'command': record['command'], 'exit': record['exit'],
            'rust': totals(log.read_text(errors='replace'))}

    def attempt(spec):
        path = checked(spec)
        assert path.parent == P / 'validation'
        return attempts[path.name]

    roles = {}
    for item in s['checks']:
        assert item['role'] not in roles
        actual = attempt(item['receipt'])
        assert actual['command'] == item['command'] and actual['exit'] == item['exit']
        if 'rust' in item:
            assert actual['rust'] == item['rust']
        if item.get('final'):
            assert actual['exit'] == 0 and item['source_sha256'] == source_sha
        roles[item['role']] = {**actual, 'final': item.get('final', False)}
    assert REQUIRED <= roles.keys() and all(roles[k]['final'] for k in REQUIRED)
    for role, version, features in [('full_native', '1.88.0', ['--features', 'vulkan-raster']),
                                    ('full_default', '1.98.0', [])]:
        assert roles[role]['command'] == ['cargo', '+' + version, 'test', '--locked', '--offline',
            '--manifest-path', 'Cargo.toml', *features, '--', '--include-ignored', '--test-threads=4']
        rust = roles[role]['rust']
        assert rust['rows'] > 0 and rust['passed'] > 0 and rust['failed'] == rust['ignored'] == 0
    for role, version, features in [('clippy_native_msrv', '1.88.0', ['--features', 'vulkan-raster']),
                                    ('clippy_native_current', '1.98.0', ['--features', 'vulkan-raster']),
                                    ('clippy_default_current', '1.98.0', [])]:
        assert roles[role]['command'] == ['cargo', '+' + version, 'clippy', '--locked', '--offline',
            '--manifest-path', 'Cargo.toml', *features, '--all-targets', '--', '-D', 'warnings']
    assert roles['format']['command'][-6:] == ['cargo', '+1.98.0', 'fmt', '--all', '--', '--check']
    probe = roles['probe_cpu']
    assert probe['command'][:3] in [['cargo', '+1.88.0', 'test'], ['cargo', '+1.98.0', 'test']]
    assert ['--manifest-path', 'tools/vulkan-raster-probe/Cargo.toml'] == probe['command'][5:7]
    assert probe['command'][3:5] == ['--locked', '--offline']
    assert ['--features', 'browser-bridge'] == probe['command'][7:9]
    assert probe['rust']['passed'] > 0 and probe['rust']['failed'] == probe['rust']['ignored'] == 0

    # Authenticate immutable artifacts without adding executable payloads to the archive.
    browser = read(s['browser'])
    binary = checked(browser)
    assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
    assert local(browser['build_receipt']) == Path(roles['browser_build']['receipt']['path'])
    assert roles['browser_build']['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
    assert roles['browser_strip']['command'] in [['strip', str(binary)], ['strip', '--strip-debug', str(binary)]]
    gpu = read(s['gpu']['binary'])
    gpu_binary = checked(gpu)
    assert gpu['source'] == gpu_source_path.name and gpu['source_sha256'] == gpu_source_sha
    gpu_build = attempt(s['gpu']['build'])
    assert local(gpu['build_receipt']) == checked(s['gpu']['build']) and gpu_build['exit'] == 0
    assert gpu_build['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
        '--manifest-path', 'tools/vulkan-raster-probe/Cargo.toml', '--features', 'browser-bridge',
        '--bin', 'eris-vulkan-native-box-check']
    assert gpu.get('strip') == 'none' and gpu['unstripped_sha256'] == gpu['sha256']

    # Fixed frozen inventory; references are verified files, not GPU encoder inputs.
    oracle = read(s['gpu']['oracles'])
    cases = oracle['cases']
    assert len(cases) == 10 and len({c['name'] for c in cases}) == 10
    assert sum(c['frame'][0] * c['frame'][1] for c in cases) == 2756
    for row in read(s['gpu']['literal_hold'])['files']:
        checked(row)
    expected_passes = [(c['name'], fmt, c['frame'][0] * c['frame'][1] * 4)
        for c in cases for fmt in ['Bgra8Unorm', 'Rgba8Unorm']]
    listing = attempt(s['gpu']['list'])
    prefix = ['env', s['gpu']['loader_environment'], str(gpu_binary)]
    assert s['gpu']['loader_environment'].startswith('LD_LIBRARY_PATH=')
    assert listing['exit'] == 0 and listing['command'] == prefix + ['--list']
    listing_text = Path(listing['log']['path']).read_text()
    inventory = re.findall(r'^ADAPTER (\d+) (.+)$', listing_text, re.M)
    assert len(inventory) == 3 and [int(i) for i,_ in inventory] == [0, 1, 2]
    assert all('backend=Vulkan ' in details for _, details in inventory)
    assert not re.search(r'^(PASS|COMPLETE|FAIL)\b', listing_text, re.M)
    adapters = []
    assert len(s['gpu']['adapters']) == 3 and {v['index'] for v in s['gpu']['adapters']} == {0, 1, 2}
    pattern = r'^PASS (\S+) format=(Bgra8Unorm|Rgba8Unorm) draws=(\d+) compared_bytes=(\d+) exact=true reference=literal canvas=true packed_native=true color_box_masks=true$'
    for item in s['gpu']['adapters']:
        actual = attempt(item['receipt'])
        assert actual['exit'] == 0 and actual['command'] == prefix + ['--adapter', str(item['index'])]
        text = Path(actual['log']['path']).read_text()
        assert re.findall(r'^ADAPTER (\d+) (.+)$', text, re.M) == inventory
        rows = re.findall(pattern, text, re.M)
        assert [(name, fmt, int(size)) for name,fmt,draws,size in rows] == expected_passes
        assert all(int(draws) > 0 for _,_,draws,_ in rows)
        assert len(re.findall(r'^PASS\b', text, re.M)) == 20 and sum(int(row[3]) for row in rows) == 22048
        completion = f'COMPLETE adapter={item["index"]} fixtures=10 frames=20 compared_bytes=22048 exact=true color_box_masks=true custom_glyph_shader=true offscreen=true acquired_surface=false'
        assert re.findall(r'^COMPLETE.*$', text, re.M) == [completion]
        assert not re.search(r'^FAIL\b', text, re.M)
        adapters.append({'index': item['index'], 'receipt': actual['receipt'], 'log': actual['log'],
            'frames': 20, 'compared_bytes': 22048, 'adapter': dict(inventory)[str(item['index'])]})

    # This milestone changes no reftest definition, source or asset.
    parent_refs = git('ls-tree', '-r', '--name-only', BASE, '--', 'tests/reftests').decode().splitlines()
    for name in parent_refs:
        assert local(name, W).read_bytes() == git('show', BASE + ':' + name), name
    assert not git('ls-files', '--others', '--exclude-standard', '--', 'tests/reftests').strip()
    manifest = json.loads(local('tests/reftests/manifest.json', W).read_text())
    names = {row['name'] for row in manifest['cases']}
    assert len(names) == len(manifest['cases']) == 90
    report_path = checked(s['report'])
    report = read(s['report'])
    assert (report['passed'], report['failed'], report['total']) == (90, 0, 90)
    assert len(report['cases']) == 90 and {c['name'] for c in report['cases']} == names
    assert all(c['status'] == 'pass' and c['different_pixels'] == c['maximum_channel_error'] == 0 for c in report['cases'])
    assert report['binary'] == str(binary)
    assert roles['reftests']['command'] == ['python3', 'tools/reftest.py', '--binary', str(binary), '--output-dir', str(report_path.parent)]

    docs = read(s['docs'])['published_files']
    assert docs and len({row['path'] for row in docs}) == len(docs)
    doc_review = read(s['documentation_review'])
    assert doc_review['status'] == 'clear'
    coverage = {r['relative']: r['sha256'] for r in doc_review['published_files']}
    assert len(coverage) == len(docs)
    for row in docs:
        assert digest(checked(row['draft'])) == digest(local(row['path'], W)) == coverage[row['path']]
    reviews = [read(spec) for spec in s['reviews']]
    assert reviews and all(review['status'] == 'clear' for review in reviews)
    published = s['published_files']
    assert len({row['path'] for row in published}) == len(published)
    for row in published:
        checked(row, W)
    changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    changed.discard('')
    assert changed == {row['path'] for row in published}, sorted(changed ^ {row['path'] for row in published})
    assert {row['path'] for row in docs} == {name for name in changed if name.endswith('.md')}

    # Explicit bounded owned trees only: no traversal of U/worktree or U itself.
    files = {selected_path, source_path, gpu_source_path, checked(s['browser']), checked(s['gpu']['binary']), report_path,
        checked(s['runtime_review']), checked(s['docs']), checked(s['documentation_review']), Path(__file__).resolve(),
        P / 'root/publication-design.json'}
    files.update(checked(v) for v in s['reviews'])
    files.update(local(name, W) for name in inputs)
    files.update(checked(v, W) for v in published)
    reports = set(s.get('report_directories', [])) | {report_path.parent.name}
    assert all(re.fullmatch(r'reftests-[A-Za-z0-9_-]+', name) for name in reports)
    for dirname in TREES | reports:
        root = P / dirname
        assert root.is_dir() and root == root.resolve() and root.parent == P
        for path in root.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_file():
                files.add(path)
    files.update(P.glob('compiled-source-*.json'))
    files.update(checked(v) for v in s.get('archive_files', []))
    assert sum(path.stat().st_size for path in files) < CAP
    contents = {}
    for path in sorted(files):
        path = local(path)
        name = str(path.relative_to(P))
        assert not any(part in {'target', '.git', 'archive', 'archives', '__pycache__'} or part.startswith('target-') for part in Path(name).parts), name
        assert path.suffix not in {'.gz', '.zip', '.tar', '.xz', '.bz2', '.7z', '.rlib', '.so', '.pyc'}, name
        with path.open('rb') as stream:
            assert stream.read(4) != b'\x7fELF', name
        contents[name] = path.read_bytes()
    assert sum(map(len, contents.values())) < CAP
    for path, expected in VERIFIED.items():
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], path
        captured = contents.get(str(path.relative_to(P)))
        if captured is not None:
            assert len(captured) == expected['bytes'] and hashlib.sha256(captured).hexdigest() == expected['sha256'], path
    for name, sha in inputs.items():
        assert digest(local(name, W)) == sha and hashlib.sha256(contents['worktree/' + name]).hexdigest() == sha
    for row in published:
        assert hashlib.sha256(contents['worktree/' + row['path']]).hexdigest() == row['sha256']
    index = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name,data in sorted(contents.items())]
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name,data in sorted(contents.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    assert raw.tell() < CAP
    compressed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
    assert len(compressed) < CAP and D == D.resolve()
    archive_path, summary_path = D / 'validation.tar.gz', D / 'summary.json'
    assert not archive_path.exists() and not summary_path.exists()
    D.mkdir(parents=True, exist_ok=True)
    with archive_path.open('xb') as stream:
        stream.write(compressed)
    assert archive_path.read_bytes() == compressed
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert [m.name for m in archive.getmembers()] == sorted(contents)
        for member in archive.getmembers():
            assert member.isfile() and archive.extractfile(member).read() == contents[member.name]
    summary = {'base': BASE, 'scope': 'Native Color BoxDecoration coverage masks and existing custom Vulkan glyph kernels; image/gradient decorations retain fallback.',
        'source': binding(source_path), 'source_count': len(inputs), 'gpu_source': binding(gpu_source_path),
        'runtime_source_review': s['runtime_review'], 'checks': attempts, 'selected_roles': roles,
        'browser': browser, 'reftests': s['report'], 'gpu_binary': gpu, 'gpu_adapters': adapters,
        'gpu_totals': {'adapters': 3, 'frames': 60, 'compared_bytes': 66144},
        'documentation_review': s['documentation_review'], 'reviews': s['reviews'],
        'published_bindings': published, 'selection': binding(selected_path),
        'archive': {'path': 'validation.tar.gz', 'bytes': len(compressed), 'sha256': digest(archive_path), 'members': len(index)},
        'archive_inputs': index, 'limits': ['GPU observations belong to the source3 binary; source4 runtime equality is separately reviewed.',
            'Offscreen comparisons do not establish acquired-surface behavior or performance.',
            'Unsuccessful attempts retain their original exit codes and partial totals.']}
    with summary_path.open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    assert json.loads(summary_path.read_text()) == summary
    print(json.dumps({'summary_sha256': digest(summary_path), 'archive': summary['archive']}, indent=2))


if __name__ == '__main__':
    main()
