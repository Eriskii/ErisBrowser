from pathlib import Path
import difflib
p=Path('/tmp/eris-native-box-color-1/tests/old-refusal-migration')
before=(p/'before.rs').read_text();s=before
helper='''// Native now admits Color only; both Probe routes retain their old refusal.
fn probe_routes(commands: &[DrawCommand], images: &ImageStore, kind: FallbackKind, index: usize) {
    let frame = Frame::new(4, 2, 0xffffff);
    let fonts = Fonts::new();
    let expected = FallbackReason { kind, command_index: Some(index) };
    assert_eq!(plan_display_list(commands, images, frame).unwrap_err(), expected);
    assert_eq!(plan_display_list_with_fonts(commands, images, frame, &fonts).unwrap_err(), expected);
    assert!(fonts.cache.borrow().is_empty());
}
fn native_color_admitted(commands: &[DrawCommand]) {
    let frame = Frame::new(4, 2, 0xffffff);
    let fonts = Fonts::new();
    native::plan_native_scene(frame, &[native::NativePhase { frame, commands }], &ImageStore::new(), &fonts).unwrap();
    assert!(fonts.cache.borrow().is_empty());
}

'''
s=s.replace('fn all_routes(',helper+'fn all_routes(',1)
start=s.index('    for command in &commands {');end=s.index('    assert_eq!(Arc::strong_count',start)
s=s[:start]+'''    probe_routes(&commands[..1], &images, FallbackKind::UnsupportedBoxDecoration, 0);
    native_color_admitted(&commands[..1]);
    for command in &commands[1..] {
        all_routes(std::slice::from_ref(command), &images, FallbackKind::UnsupportedBoxDecoration, 0);
    }
'''+s[end:]
# Migrate exact selected calls only, leaving invalid-geometry calls unchanged.
old='''        all_routes(
            &commands,
            &poison(),
            FallbackKind::UnsupportedBoxDecoration,
            2,
        );'''
new='''        probe_routes(&commands, &poison(), FallbackKind::UnsupportedBoxDecoration, 2);
        native_color_admitted(&commands);
        // Hidden unsupported image payload still refuses before poison validation.
        let mut unsupported = commands.clone();
        let DrawCommand::BoxDecoration(payload) = &commands[2] else { unreachable!() };
        unsupported[2] = DrawCommand::BoxDecoration(Arc::new(BoxDecoration {
            shape: payload.shape, cutout: payload.cutout,
            paint: BoxPaint::Image { tile: rect(0.0, 0.0, 1.0, 1.0), repeat: [true; 2], key: "bad".into() },
        }));
        all_routes(&unsupported, &poison(), FallbackKind::UnsupportedBoxDecoration, 2);'''
assert old in s;s=s.replace(old,new,1)
old='''        all_routes(
            &[command],
            &poison(),
            FallbackKind::UnsupportedBoxDecoration,
            0,
        );'''
new='''        probe_routes(std::slice::from_ref(&command), &poison(), FallbackKind::UnsupportedBoxDecoration, 0);
        native_color_admitted(&[command]);'''
assert old in s;s=s.replace(old,new,1)
start=s.index('        all_routes(',s.index('fn box_decoration_adapter_coordinate'))
end=s.index('        let beyond',start)
block=s[start:end]
assert 'shape: edge' in block
s=s[:start]+'''        let edge_command = DrawCommand::BoxDecoration(Arc::new(BoxDecoration {
            shape: edge, cutout: None, paint: BoxPaint::Color(Color::BLACK),
        }));
        probe_routes(std::slice::from_ref(&edge_command), &poison(), FallbackKind::UnsupportedBoxDecoration, 0);
        native_color_admitted(&[edge_command]);
'''+s[end:]
# Cold preflight remains unsupported Native Image, while original Probe commands stay exact.
start=s.index('fn box_decoration_preceding_text');end=s.index('\n#[test]',start)
block=s[start:end];needle='''    assert_eq!(
        native::plan_native_scene('''
assert needle in block
block=block.replace(needle,'''    let native_commands = [commands[0].clone(), commands[1].clone(), image("bad")];
    assert_eq!(
        native::plan_native_scene(''',1).replace('commands: &commands','commands: &native_commands',1)
s=s[:start]+block+s[end:]
old='''    all_routes(
        &commands,
        &poison(),
        FallbackKind::UnsupportedBoxDecoration,
        255,
    );'''
assert old in s;s=s.replace(old,'''    probe_routes(&commands, &poison(), FallbackKind::UnsupportedBoxDecoration, 255);
    native_color_admitted(&commands);''',1)
start=s.index('fn box_decoration_preserves_earlier_geometry');end=s.index('\n#[test]',start)
block=s[start:end]
block=block.replace("// Native's existing structural pass precedes the cheap store guard.","// Accepted Native Color reaches the unchanged cheap store guard.")
old='''            kind: FallbackKind::UnsupportedBoxDecoration,
            phase_index: Some(0),
            command_index: Some(0)'''
assert old in block;block=block.replace(old,'''            kind: FallbackKind::ImageStoreLimit,
            phase_index: None,
            command_index: None''',1)
idx=block.rfind('\n}')
block=block[:idx]+'''
    // Unsupported paints still stop in structural preflight, before that guard.
    let unsupported = [image("missing")];
    assert_eq!(native::plan_native_scene(frame, &[native::NativePhase { frame, commands: &unsupported }], &images, &fonts).unwrap_err(),
        native::NativeFallback { kind: FallbackKind::UnsupportedBoxDecoration, phase_index: Some(0), command_index: Some(0) });
'''+block[idx:]
s=s[:start]+block+s[end:]
(p/'after.rs').write_text(s)
(p/'migration.patch').write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/src/graphics/raster_bridge/box_decoration_tests.rs',tofile='b/src/graphics/raster_bridge/box_decoration_tests.rs')))
