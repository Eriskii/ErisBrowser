from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent

def bind(path):
 data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

inventory=root/'source-1.json'
sources=json.loads(inventory.read_text())['source_sha256']
assert len(sources)==767
for name,sha in sources.items(): assert bind(root/'worktree'/name)['sha256']==sha,name
checks={}
for label in ['focused-runtime-1','focused-integration-1','native-full-1','default-full-1','strict-msrv-1','strict-current-1','format-check-1','browser-final-build-1','references-final-1']:
 r=json.loads((root/'validation'/(label+'.json')).read_text()); assert r['exit']==0
 assert bind(root/'validation'/r['log'])['sha256']==r['sha256'];checks[label]=r
for name in ['final-source-review.json','validation-review.json']:
 assert json.loads((root/'root'/name).read_text())['status'] in ('clear','clear_source_only')
totals=json.loads((root/'root/full-suite-totals.json').read_text())
assert totals['native-full-1']['passed']==3103 and totals['default-full-1']['passed']==2799
parent_ci=json.loads((root/'validation/parent-ci-final-1.log').read_text())
assert parent_ci['headSha']=='8599c2ea42ace2eda773886305ea94817e33bb68'
assert parent_ci['conclusion']=='success' and len(parent_ci['jobs'])==9
assert all(j['conclusion']=='success' for j in parent_ci['jobs'])
reference=json.loads((root/'root/reference-comparison-final.json').read_text())
assert reference['status']=='pass' and reference['pairs']==102 and reference['unchanged_pngs']==204
artifacts={}
for directory in ['tests-before','production-1','integration','validation','reftests-final','root']:
 for path in sorted((root/directory).rglob('*')):
  if path.is_file():
   assert not path.is_symlink()
   assert path.name not in ('selection-final.json','publication-verification.json')
   artifacts[str(path.relative_to(root))]=bind(path)
for path in sorted(root.glob('*')):
 if path.is_file() and path.suffix in ('.json','.py'): artifacts[path.name]=bind(path)
for name in ['README.md','docs/ROADMAP.md','docs/throw-completion.md']:
 artifacts['documentation/'+name]=bind(root/'worktree'/name)
selection={'source_inventory':bind(inventory),'artifacts':artifacts,'max_uncompressed_bytes':128*1024*1024,'claims':{
 'base':parent_ci['headSha'],
 'scope':'Preserve original JavaScript throw values with bounded diagnostic inspection of stored data descriptors; no author getter invocation during labeling.',
 'source_inputs':767,
 'new_test_groups':{'runtime_semantic':7,'private_budget':1,'page':1,'confined_worker':1,'total':10},
 'parent_baselines':{'public_groups':9,'compiled':9,'passed_control':1,'failed_as_predicted':8,
  'private_budget_baseline':'One new private API group was not compiled on the parent; no parent failure claimed.',
  'integration_failure_stage':'Both disabled controls pass before enabled initial pixel comparison fails; later enabled assertions are not parent observations.'},
 'history':{'preproduction_selections':'Diagnostic name and canonical identity are independent. Math/JSON use their prepaid registry bags; missing legacy Native metadata has no cached Function-prototype fallback. These policies and exact resource rows were frozen before production.',
  'old_test_migrations':0,'source_inventory_sha256':bind(inventory)['sha256']},
 'checks':checks,
 'full_suite_totals':{key:{field:val[field] for field in ['passed','failed','ignored','result_rows','log_sha256']} for key,val in totals.items()},
 'integration_oracles':{'unique_literal_rgba_frames':12,'literal_rgba_bytes':1802496,'page_worker_layout_or_render_calls':20,
  'count_scope':'Per successful execution of the two integration groups; focused and full suites repeat them.',
  'checkpoint_title':'CFMN','after_click_title':'CFMNABQD',
  'interpretation':'Page and confined worker CPU pixels plus packed native-plan CPU interpretation; no new GPU execution claim.'},
 'references':{key:reference[key] for key in ['pairs','unchanged_pngs','parent_archive_sha256','report_sha256']},
 'browser':json.loads((root/'root/final-browser.json').read_text()),
 'parent_ci':{'head':parent_ci['headSha'],'url':parent_ci['url'],'conclusion':'success','jobs':9,'raw':bind(root/'validation/parent-ci-final-1.log')},
 'resource_policy':{'bootstrap_work':100000,'raw_bootstrap_remaining':793,'author_work':100000,'cumulative_heap_bytes':8388608,'prototype_walk_limit':96,'unchanged_numeric_caps':True,'bootstrap_and_runtime_fields_unchanged':True,
  'measurement_scope':'Logical prepaid charges; no physical allocator or processor-work guarantee.'},
 'limits':['Authored local tests, not imported WPT conformance results.','Best-effort stored diagnostic names; unsupported host metadata and missing bags use generic labels.','Resource refusal remains the existing terminal host policy.','No Promise implementation or expanded event-loop surface.','No Chromium performance comparison, full web compatibility, or production-security claim.','No new GPU or acquired-window observation; existing Vulkan backend unchanged.','Build caches reused; times are not cold-build measurements.']}}
with (root/'root/selection-final.json').open('x') as out:json.dump(selection,out,indent=2);out.write('\n')
print(json.dumps({'sources':len(sources),'artifacts':len(artifacts)}))
