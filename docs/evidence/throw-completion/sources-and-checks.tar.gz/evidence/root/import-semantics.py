from pathlib import Path
import json,hashlib
r=Path(__file__).resolve().parent.parent;w=r/'worktree';h=r/'tests-before/semantic-source-ready.json';m=json.loads(h.read_text())
def verify(b):
 d=Path(b['path']).read_bytes();assert len(d)==b['bytes'] and hashlib.sha256(d).hexdigest()==b['sha256'];return d
raw=verify(m['file']);before=verify(m['base_source']);p=w/'src/script/throw_completion_tests.rs';assert not p.exists()
s=w/'src/script.rs';assert s.read_bytes()==before
registration=b'\n#[cfg(test)]\nmod throw_completion_tests;\n';assert registration not in before
p.write_bytes(raw);s.write_bytes(before+registration)
record={'status':'semantic_tests_only_imported','hold_sha256':hashlib.sha256(h.read_bytes()).hexdigest(),'groups':len(m['groups']),'base_src_sha256':hashlib.sha256(before).hexdigest(),'registered_src_sha256':hashlib.sha256(s.read_bytes()).hexdigest(),'test_sha256':hashlib.sha256(raw).hexdigest()}
with (r/'root/import-semantics.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
