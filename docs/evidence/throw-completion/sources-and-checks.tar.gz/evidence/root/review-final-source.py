from pathlib import Path
import hashlib,json,re,difflib
p=Path('/tmp/eris-throw-completion-1');w=p/'worktree'
def binding(q):
 b=q.read_bytes();return {'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read_json(q):return json.loads(q.read_text())
def validate(b):
 actual=binding(Path(b['path']));assert all(actual[k]==b[k] for k in ['bytes','sha256']),b['path']
# Inert lexical comparison for this finite overlay; no project code is imported.
# Strings (including raw JS bodies) and comments are retained byte-for-byte.
def tokens(s):
 out=[];comments=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   e=s.find('\n',i);e=len(s) if e<0 else e;comments.append(s[i:e]);i=e;continue
  if s.startswith('/*',i):
   start=i;i+=2;level=1
   while level:
    if s.startswith('/*',i):level+=1;i+=2
    elif s.startswith('*/',i):level-=1;i+=2
    else:i+=1;assert i<=len(s)
   comments.append(s[start:i]);continue
  m=re.match(r'r(#+)?"',s[i:])
  if m:
   start=i;hashes=m.group(1) or '';i+=len(m.group(0));e=s.find('"'+hashes,i);assert e>=0;i=e+1+len(hashes);out.append(s[start:i]);continue
  if s[i]=='"':
   start=i;i+=1
   while True:
    assert i<len(s)
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:i+=1
   out.append(s[start:i]);continue
  m=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+(?:\.[0-9]+)?[A-Za-z_0-9]*',s[i:])
  if m:out.append(m.group(0));i+=len(m.group(0));continue
  out.append(s[i]);i+=1
 # Only optional trailing punctuation is ignored; separators between elements remain.
 out=[v for j,v in enumerate(out) if not (v==',' and j+1<len(out) and out[j+1] in [')',']','}'])]
 return out,comments
parent=read_json(p/'parent-source.json')['source_sha256']; final=read_json(p/'source-1.json')['source_sha256']
assert len(parent)==760 and len(final)==767
for name,digest in final.items():
 q=w/name;assert not q.is_symlink();assert hashlib.sha256(q.read_bytes()).hexdigest()==digest,name
added=sorted(final.keys()-parent.keys());removed=sorted(parent.keys()-final.keys());changed=sorted(k for k in parent.keys()&final.keys() if parent[k]!=final[k]);unchanged=sorted(k for k in parent.keys()&final.keys() if parent[k]==final[k])
assert removed==[]
assert changed==['src/script.rs','src/script/machine/statements.rs','tests/worker.rs']
assert added==['src/script/throw_completion_tests.rs','src/script/throw_metadata.rs','src/script/throw_metadata_budget_tests.rs','tests/fixtures/throw-completion.html','tests/support/throw_completion.rs','tests/throw_completion.rs','tests/worker/throw_completion.rs']
hold=read_json(p/'production-1/source-ready.json');overlay=[]
for entry in hold['files']:
 validate(entry['raw']);validate(entry['diff'])
 if entry['before']:validate(entry['before'])
 name=entry['target'];a=Path(entry['raw']['path']).read_text();b=(w/name).read_text();admitted=[]
 if name=='src/script.rs':assert a.rstrip()==b.rstrip();admitted=['final blank-line removal only']
 elif name=='src/script/machine/statements.rs':assert a==b;admitted=['byte exact']
 else:
  if name.endswith('/throw_completion_tests.rs'):
   replacements=[
    ('(Value::Number(expected), Value::Number(actual)) if expected.is_nan() => assert!(actual.is_nan()),','(Value::Number(expected), Value::Number(actual)) if expected.is_nan() => { assert!(actual.is_nan()) }'),
    ('(Value::Number(expected), Value::Number(actual)) => assert_eq!(expected.to_bits(), actual.to_bits()),','(Value::Number(expected), Value::Number(actual)) => { assert_eq!(expected.to_bits(), actual.to_bits()) }')]
   for old,new in replacements:assert a.count(old)==1;a=a.replace(old,new)
   admitted.append('two existing diverging macro match arms enclosed in blocks')
  if name.endswith('/throw_metadata.rs'):
   old='Value::Function(id) => return Ok(self.functions.get(*id).map(|function| function.properties)),'
   assert a.count(old)==1;a=a.replace(old,'Value::Function(id) => { return Ok(self.functions.get(*id).map(|function| function.properties)); }')
   assert a.count('return Ok(None) };')==2;a=a.replace('return Ok(None) };','return Ok(None); };')
   admitted.extend(['Function arm return enclosed in block with explicit semicolon','two let-else return expressions gain optional semicolon'])
  assert tokens(a)==tokens(b),name
  admitted.append('whitespace and optional trailing commas only otherwise; string/comment tokens exact')
 overlay.append({'target':name,'held':entry['raw'],'installed':binding(w/name),'formatting_changes':admitted})
# Parent reverse bindings of changed existing paths, without invoking git.
s=(p/'production-1/before/src/script.rs').read_bytes();suffix=b'\n#[cfg(test)]\nmod throw_completion_tests;\n';assert s.endswith(suffix)
assert hashlib.sha256(s[:-len(suffix)]).hexdigest()==parent['src/script.rs']
assert binding(p/'production-1/before/src/script/machine/statements.rs')['sha256']==parent['src/script/machine/statements.rs']
worker=(w/'tests/worker.rs').read_bytes();suffix=b'\n#[path = "worker/throw_completion.rs"]\nmod throw_completion;\n';assert worker.endswith(suffix)
assert hashlib.sha256(worker[:-len(suffix)]).hexdigest()==parent['tests/worker.rs']
integration=[]
for entry in read_json(p/'integration/source-ready.json')['files']:
 validate(entry['root_authored']);validate(entry['frozen']);assert entry['root_authored']['sha256']==entry['frozen']['sha256'];name=entry['target'];a=Path(entry['root_authored']['path']).read_text();b=(w/name).read_text()
 if name.endswith('.rs'):assert tokens(a)==tokens(b),name
 else:assert a==b
 integration.append({'target':name,'held':entry['frozen'],'installed':binding(w/name),'comparison':'literal/token equivalent; optional formatting only' if name.endswith('.rs') else 'byte exact'})
# Recheck held inventory after all reads to bind the completed audit to this snapshot.
assert binding(p/'source-1.json')['sha256']=='2c5657b1addcf96b55b659e54afbb187556f06e1db3d672af52cc4c813779df0'
for name,digest in final.items():assert hashlib.sha256((w/name).read_bytes()).hexdigest()==digest,name
review={'status':'clear_source_only','source_snapshot':binding(p/'source-1.json'),'parent_inventory':binding(p/'parent-source.json'),'production_hold':binding(p/'production-1/source-ready.json'),'production_peer':binding(p/'production-1/html-review.json'),'inventory':{'parent_inputs':760,'final_inputs':767,'all_final_file_hashes_rechecked':True,'unchanged_parent_inputs':len(unchanged),'changed_parent_inputs':changed,'added_inputs':added,'removed_inputs':removed},'production_overlay':overlay,'integration_frozen_files':integration,'registration_reverse_checks':['Production before/src/script.rs minus sole appended frozen semantic test registration equals parent inventory hash.','Production before/statements.rs equals parent inventory hash.','Installed tests/worker.rs minus sole appended integration registration equals parent inventory hash.'],'semantic_conclusion':['Only the selected throw diagnostic metadata observer changes runtime behavior; existing thrown_error/reporters, Runtime/Value/Native layouts, caps, bootstrap and other parent production bytes remain unchanged.','Formatting changed no numeric/string/JS/HTML literal, test assertion, budget cut or source branch. The explicit finite block/semicolon transformations listed above preserve each original return/macro arm.','All eight Runtime groups remain the frozen semantic/accounting tests; both separately frozen Page/worker groups and literal fixture remain intact. No old test migration was introduced.'],'scope_limit':'Read-only hashing and inert lexical/diff/source review only. No compiler, tests, formatter, browser, project imports, git or live edits. This does not claim runtime outcomes.','review_helper':binding(p/'root/review-final-source.py'),'format_diffs':[binding(q) for q in sorted((p/'root/final-source-review-diffs').rglob('*.patch'))]}
(p/'root/final-source-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(binding(p/'root/final-source-review.json')))
