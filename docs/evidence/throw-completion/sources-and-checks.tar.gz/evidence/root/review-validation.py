from pathlib import Path
import ast,hashlib,json,re,struct,tarfile
p=Path('/tmp/eris-throw-completion-1');w=p/'worktree';v=p/'validation'
def digest(q):
 h=hashlib.sha256()
 with q.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
def bind(q):return {'path':str(q),'bytes':q.stat().st_size,'sha256':digest(q)}
def load(q):return json.loads(q.read_text())
def bound(b):
 q=Path(b['path']);assert q.stat().st_size==b['bytes'] and digest(q)==b['sha256'];return q
pattern=re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',re.M)
labels=['baseline-page-1','baseline-worker-1','baseline-semantics-1','focused-runtime-1','focused-integration-1','native-full-1','default-full-1','strict-msrv-1','strict-current-1','format-check-1','browser-final-build-1','references-final-1']
observed={}
for label in labels:
 record=load(v/(label+'.json'));log=v/record['log'];assert digest(log)==record['sha256'];text=log.read_text();rows=pattern.findall(text)
 totals={key:sum(int(row[i]) for row in rows) for i,key in enumerate(['status','passed','failed','ignored','measured','filtered']) if i}
 observed[label]={'receipt':bind(v/(label+'.json')),'log':bind(log),'command':record['command'],'exit':record['exit'],'rows':len(rows),'totals':totals}
 if label.startswith('baseline'):assert record['exit']==101
 else:assert record['exit']==0
 if label in ['native-full-1','default-full-1']:
  expected=3103 if label=='native-full-1' else 2799
  assert totals==dict(passed=expected,failed=0,ignored=0,measured=0,filtered=0) and len(rows)==44
  assert all(row[0]=='ok' for row in rows)
  roster=re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored[^\n]*)$',text,re.M)
  assert len(roster)==expected and all(state=='ok' for _,state in roster)
  authored=load(p/'root/full-suite-totals.json')[label]
  assert all(authored[k]==totals[k] for k in ['passed','failed','ignored'])
  assert authored['result_rows']==44 and authored['log_sha256']==digest(log)
  assert sorted((r['test'],r['status']) for r in authored['roster'])==sorted(roster)
  assert sum(r['passed'] for r in authored['per_target'])==expected and len(authored['per_target'])==44
  assert record['command'][1]=='+1.88.0' and '--include-ignored' in record['command']
  assert ('vulkan-raster' in record['command'])==(label=='native-full-1')
assert observed['baseline-semantics-1']['totals']['passed']==1 and observed['baseline-semantics-1']['totals']['failed']==6
for label in ['baseline-page-1','baseline-worker-1']:
 assert observed[label]['totals']['passed']==0 and observed[label]['totals']['failed']==1
 assert 'pixel (2,2) actual=ff0000 expected=ffffff' in (v/(label+'.log')).read_text()
assert observed['focused-runtime-1']['totals']==dict(passed=8,failed=0,ignored=0,measured=0,filtered=2674)
assert observed['focused-integration-1']['totals']==dict(passed=2,failed=0,ignored=0,measured=0,filtered=85)
for label,version in [('strict-msrv-1','+1.88.0'),('strict-current-1','+1.98.0')]:
 c=observed[label]['command'];assert c==['cargo',version,'clippy','--locked','--offline','--manifest-path','Cargo.toml','--features','vulkan-raster','--all-targets','--','-D','warnings']
 assert 'Finished `dev` profile' in (v/(label+'.log')).read_text()
source=load(p/'source-1.json');inventory=source['source_sha256'];assert len(inventory)==767
assert digest(p/'source-1.json')=='2c5657b1addcf96b55b659e54afbb187556f06e1db3d672af52cc4c813779df0'
for name,sha in inventory.items():assert digest(w/name)==sha,name
source_review=load(p/'root/final-source-review.json');assert source_review['status']=='clear_source_only';assert source_review['source_snapshot']['sha256']==digest(p/'source-1.json')
# The command supervisor is read as source, never imported or run here.
runner=(p/'run-check.py').read_text();assert "W=A/'worktree'" in runner and 'cwd=W' in runner
browser=load(p/'root/final-browser.json');binary=bound(browser)
assert browser['source_inventory_sha256']==digest(p/'source-1.json') and browser['verified_source_inputs']==767
assert browser['source_inventory']=='source-1.json' and browser['build']==load(v/'browser-final-build-1.json')
assert browser['rust']=='1.88.0' and browser['features']==['vulkan-raster']
assert browser['strip_mode']=='--strip-debug' and browser['dwarf_debug_sections_removed'] is True and browser['debugger_autoload_metadata_retained'] is True
assert digest(p/'target-msrv/debug/eris-browser')==browser['unstripped_sha256']
assert binary.stat().st_mode&0o222==0
# Inspect ELF section-name metadata inertly to substantiate stripped debug sections.
b=binary.read_bytes();assert b[:6]==b'\x7fELF\x02\x01'
section_offset=struct.unpack_from('<Q',b,40)[0];entry_size,count,string_index=struct.unpack_from('<HHH',b,58)
assert entry_size==64 and string_index<count
string_entry=section_offset+string_index*entry_size
string_offset,string_size=struct.unpack_from('<QQ',b,string_entry+24)
strings=b[string_offset:string_offset+string_size];section_names=[]
for i in range(count):
 name_offset=struct.unpack_from('<I',b,section_offset+i*entry_size)[0];end=strings.find(b'\0',name_offset);assert end>=0;section_names.append(strings[name_offset:end].decode())
debug_names=[x for x in section_names if x.startswith(('.debug','.zdebug'))]
assert debug_names==['.debug_gdb_scripts']
# Reconstruct each independent literal byte array from its frozen rectangles.
oracles=load(p/'integration/tests-before/oracles.json');assert len(oracles['frames'])==12
literal_total=0
for frame in oracles['frames']:
 width,height=frame['width'],frame['height'];rgba=bytearray(bytes([255,255,255,255])*(width*height));state=frame['state'];red={'disabled':2,'initial':6,'clicked':10}[state]
 assert frame['rectangles']==[{'xywh':[red,2,4,4],'rgba':[255,0,0,255]},{'xywh':[20,2,4,4],'rgba':[0,0,255,255]}]
 for left,color in [(red,bytes([255,0,0,255])),(20,bytes([0,0,255,255]))]:
  for y in range(2,6):
   for x in range(left,left+4):rgba[(y*width+x)*4:(y*width+x+1)*4]=color
 q=bound(frame['rgba']);assert q.read_bytes()==rgba;literal_total+=len(rgba)
assert literal_total==1802496 and oracles['unique_rgba_bytes']==literal_total
assert oracles['invocations']['combined']==20
# All actual reference images are byte-identical within their pairs and to parent.
report_path=p/'reftests-final/report.json';report=load(report_path);comparison=load(p/'root/reference-comparison-final.json')
assert report['binary']==str(binary) and report['passed']==102 and report['failed']==0 and report['total']==102 and report['conformance_claim'] is False
assert len(report['cases'])==102
all_names=set()
for case in report['cases']:
 assert case['status']=='pass' and case['different_pixels']==case['maximum_channel_error']==0
 test=Path(case['test_image']);reference=Path(case['reference_image']);assert test.parent==reference.parent==p/'reftests-final';assert test.read_bytes()==reference.read_bytes();all_names.update([test.name,reference.name])
assert len(all_names)==204
assert comparison['status']=='pass' and comparison['pairs']==102 and comparison['unchanged_pngs']==204
assert comparison['report_sha256']==digest(report_path)==observed['references-final-1']['log']['sha256']
parent_dir=w/'docs/evidence/microtasks';summary=load(parent_dir/'summary.json');archive=parent_dir/'sources-and-checks.tar.gz'
assert archive.stat().st_size==summary['archive']['bytes'];assert digest(archive)==summary['archive']['sha256']==comparison['parent_archive_sha256']
seen=set();image_rows={r['name']:r for r in comparison['images']};assert set(image_rows)==all_names
with tarfile.open(archive,'r:gz') as stream:
 for member in stream:
  prefix='evidence/reftests-final/'
  if member.name.startswith(prefix) and member.name.endswith('.png'):
   name=member.name[len(prefix):];assert '/' not in name and name not in seen and member.isfile() and 0<member.size<=4*1024*1024;seen.add(name)
   old=stream.extractfile(member).read();now=(p/'reftests-final'/name).read_bytes();assert old==now and len(old)==member.size
   assert image_rows[name]=={'name':name,'bytes':len(now),'sha256':hashlib.sha256(now).hexdigest()}
assert seen==all_names
ci_receipt=load(v/'parent-ci-final-1.json');ci_log=v/ci_receipt['log'];assert ci_receipt['exit']==0 and digest(ci_log)==ci_receipt['sha256'];ci=load(ci_log)
assert ci['headSha']=='8599c2ea42ace2eda773886305ea94817e33bb68' and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
# Parse publisher author source inertly; do not execute its claim-selection code.
selector=p/'root/select-evidence.py';ast.parse(selector.read_text());selector_text=selector.read_text()
assert "'count_scope':" in selector_text and 'per successful execution' in selector_text.lower()
assert "'old_test_migrations':0" in selector_text and "'total':10" in selector_text
assert "'passed_control':1,'failed_as_predicted':8" in selector_text
assert "'unique_literal_rgba_frames':12,'literal_rgba_bytes':1802496" in selector_text
review={'status':'clear','scope':'Independent read-only audit of actual logs, source/binary bindings, frozen literal data and evidence-selector claims. No project execution.','source_inventory':bind(p/'source-1.json'),'final_source_review':bind(p/'root/final-source-review.json'),'observed_checks':observed,'full_totals_binding':bind(p/'root/full-suite-totals.json'),'baseline_interpretation':{'public_groups':9,'passed_control':1,'intended_failed':8,'private_accounting_parent_execution':False,'integration':'Both failures are at the first enabled (2,2) comparison after successful disabled controls according to the frozen sequential test source. Later enabled assertions are not parent observations.'},'integration_oracles':{'hold':bind(p/'integration/source-ready.json'),'oracles':bind(p/'integration/tests-before/oracles.json'),'unique_frames':12,'rgba_bytes':literal_total,'all_literal_bytes_independently_reconstructed':True,'calls_per_successful_pair_of_groups':20,'actual_coverage':'Focused and full tests pass Page and actual confined-worker CPU pixel/hit/title checks; native-feature runs also execute packed native-plan CPU comparison. No actual GPU or acquired-window execution inferred.'},'browser':{'record':bind(p/'root/final-browser.json'),'binary':bind(binary),'unstripped_hash_rechecked':True,'build_log_join':True,'source_inventory_join':True,'ELF_DWARF_sections_absent':True,'retained_debugger_metadata':'.debug_gdb_scripts (34 bytes); strip --strip-debug does not remove this auto-load metadata'},'references':{'receipt':bind(v/'references-final-1.json'),'report':bind(report_path),'comparison':bind(p/'root/reference-comparison-final.json'),'parent_archive':bind(archive),'pairs':102,'test_reference_png_bytes_equal':102,'current_parent_png_bytes_equal':204},'parent_ci':{'record':bind(v/'parent-ci-final-1.json'),'raw':bind(ci_log),'head':ci['headSha'],'jobs':9,'conclusion':'success'},'selector':{'source':bind(selector),'review':'Fixed claims reconcile with independently parsed observations.20 requested layout/render calls explicitly refer to one successful execution of both groups; repeated suite runs remain distinct. Selection script was only read/AST-parsed, never executed.','claim_corrections':'Count-scope wording clarified by root. Original browser debug_sections_removed replaced with explicit strip_mode, dwarf_debug_sections_removed and debugger_autoload_metadata_retained fields, preserving original record. No numeric test/reference correction.','browser_wording_correction':bind(p/'root/browser-wording-correction.json')},'provenance_limits':'Cargo receipts bind argv/log hashes; the read supervisor fixes cwd to the source worktree. Final inventory/hash review and root-held source1 validation sequence provide the source join; no separate fresh per-command source snapshot is asserted. Build caches were reused. This review does not turn source-derived fixture counts into hardware observations.','review_helper':bind(p/'root/review-validation.py')}
(p/'root/validation-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(p/'root/validation-review.json')))
