from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parent.parent;w=r/'worktree';hold=r/'integration/source-ready.json'
m=json.loads(hold.read_text());review=json.loads((r/'integration/layout-review.json').read_text());assert review['status']=='clear'
def verify(b):
 p=Path(b['path']);d=p.read_bytes();assert len(d)==b['bytes'] and hashlib.sha256(d).hexdigest()==b['sha256'];return d
for row in m['files']:
 assert verify(row['root_authored'])==verify(row['frozen'])
 assert not (w/row['target']).exists()
verify(m['oracles']);verify(m['review'])
worker=w/'tests/worker.rs';before=worker.read_bytes();bound=next(v for v in review['context'] if v['path']==str(worker));assert before==verify(bound)
registration=b'\n#[path = "worker/throw_completion.rs"]\nmod throw_completion;\n';assert registration not in before
for row in m['files']:
 p=w/row['target'];p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(verify(row['root_authored']))
worker.write_bytes(before+registration)
receipt={'status':'imported_tests_only','hold_sha256':hashlib.sha256(hold.read_bytes()).hexdigest(),'files':[row['target'] for row in m['files']], 'worker_before_sha256':hashlib.sha256(before).hexdigest(),'worker_after_sha256':hashlib.sha256(worker.read_bytes()).hexdigest()}
(r/'root/import-integration.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
