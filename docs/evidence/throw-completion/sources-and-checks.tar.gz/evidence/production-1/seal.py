from pathlib import Path
import hashlib,json
out=Path('/tmp/eris-throw-completion-1/production-1'); base=out.parent/'worktree'; frozen=out.parent/'tests-before'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
# Inert byte comparisons only; do not import or execute any project helper.
for name in ['src/script/throw_completion_tests.rs','src/script/throw_metadata_budget_tests.rs']:
 assert (out/'raw'/name).read_bytes()==(frozen/name).read_bytes()
old=(out/'before/src/script.rs').read_text();new=(out/'raw/src/script.rs').read_text()
start='    fn thrown_error(';end='    fn thrown_name('
a=old[old.index(start):old.index(end)]
b=new[new.index(start):new.index('    #[cfg(test)]\n    fn eval(',new.index(start))]
assert a==b
# Complete exact inverse, including relocated test-only registration.
reversed_source=new.replace('mod text_operations;\n#[cfg(test)]\nmod throw_completion_tests;\nmod throw_metadata;\n#[cfg(test)]\nmod throw_metadata_budget_tests;\n','mod text_operations;\n',1)
removed=old[old.index('    fn thrown_name('):old.index('    #[cfg(test)]\n    fn eval(',old.index('    fn thrown_name('))]
reversed_source=reversed_source.replace('    #[cfg(test)]\n    fn eval(',removed+'    #[cfg(test)]\n    fn eval(',1)
reversed_source+='#[cfg(test)]\nmod throw_completion_tests;\n'
assert reversed_source==old
raw_stmt=(out/'raw/src/script/machine/statements.rs').read_text()
raw_stmt=raw_stmt.replace('''            let metadata = runtime.throw_metadata(&value)?;
            let mut error = runtime.thrown_error(value)?;
            error.thrown_name = metadata.name;
            error.intrinsic_name = metadata.intrinsic;''','''            let name = runtime.thrown_name(&value, doc)?;
            let intrinsic = runtime.thrown_intrinsic_name(&value, doc)?;
            let mut error = runtime.thrown_error(value)?;
            error.thrown_name = name;
            error.intrinsic_name = intrinsic;''',1)
assert raw_stmt==(out/'before/src/script/machine/statements.rs').read_text()
review={'status':'author_source_review_before_project_execution','scope':'Three production paths plus unchanged public semantic file/new frozen private file, five overlay paths total. No old test migration.','checks':['Complete script.rs and statements.rs inverses reconstruct held before bytes.','thrown_error function byte-identical; exception_value, native direct thrown_error callers, reporter source, caps, Runtime/Native/Value layouts and bootstrap installers unchanged.','Semantic and private test files byte-identical to frozen hold, eight groups. Existing public registration moved to module area; new production/private-test declarations are also there.','One constructor snapshot, fixed keys materialized once, paid edge/registry/property searches, accessor terminal, supported stored prototype domain and MAX_DEPTH guard.','Math/JSON registry bags supported. Missing legacy Native bag generic is explicit root selection, not an unmetered Function.prototype fallback.','Canonical brand comparison is independent of optional name result, contains no allocation/author callback and ignores mutable metadata/global binding.','Private tariff rows map directly to header/key/edge/search/copy/comparison phases; prior proportional name-copy fee and existing final thrown_error fee retained.','No project imports/compiler/tests/formatter/browser/git executed.'], 'limitations':'Source review only; Rust compilation and all actual outcomes remain root-owned. Logical work/heap charges are not measured CPU instructions or allocator memory.', 'frozen_hold':bind(frozen/'source-ready.json'),'decisions':[bind(out.parent/'root'/f) for f in ['production-selection.json','native-missing-bag-selection.json','ledger-selection.json']]}
(out/'source-review.json').write_text(json.dumps(review,indent=2)+'\n')
files=[]
for p in sorted((out/'raw').rglob('*.rs')):
 rel=p.relative_to(out/'raw');before=out/'before'/rel;live=base/rel
 if before.exists():assert live.read_bytes()==before.read_bytes()
 else:assert not live.exists()
 files.append({'target':str(rel),'before':bind(before) if before.exists() else None,'raw':bind(p),'diff':bind(out/'diffs'/Path(str(rel)+'.patch')),'frozen_test':str(rel).endswith('_tests.rs')})
hold={'status':'external_production_source_ready_for_independent_peer_and_root_import','base':'Published microtask checkpoint8599c2ea plus root tests-only registrations; exact before bindings below.','files':files,'frozen_tests_api_ledger':bind(frozen/'source-ready.json'),'source_review':bind(out/'source-review.json'),'authoring_script':bind(out/'seal.py'),'execution':'No project import/compiler/test/formatter/browser/git execution. Root owns live installation and all validation.'}
(out/'source-ready.json').write_text(json.dumps(hold,indent=2)+'\n')
print(json.dumps(bind(out/'source-ready.json')))
