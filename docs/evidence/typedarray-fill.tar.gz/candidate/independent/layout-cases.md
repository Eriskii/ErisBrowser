# Independent Number TypedArray fill cases

Source-only plan, authored before execution. The semantic oracles come from the
[current fill algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.fill)
and the literal setups below. Existing storage helpers supply the separate cost
contract; candidate output must not become a semantic oracle.

The initial receiver check and length capture precede value conversion, then
start conversion, then a defined end conversion. Both indices use the captured
length. A second bounds check is unconditional, including empty ranges; only
after it does the current length shorten the end. An earlier abrupt conversion
wins over that final bounds error. No author callback occurs during the writes.

## Literal semantic matrix

1. **Ten kinds and identity.** Fill positions1..3 in a four-element view with
   257.75, retaining sentinels11 and44. Expected middle values are1 for Int8/Uint8,
   255 for Uint8Clamped,257 for the four wider integer kinds, and257.75 for the
   three float kinds. Return the same view. A second alias observes the bytes.
   Test negative wrapping with-1.75, and floating signed zero/NaN/infinities.
   Uint8Clamp ties0.5,1.5,2.5,3.5,254.5,255.5 map to0,2,2,4,254,255.
   Float16 ties1+2^-11 and1+3*2^-11 map to1 and1+2^-9; Float32 analogues use
   2^-24 and2^-22. Omitted value becomes integer0 or floating NaN.

2. **Captured ranges.** Fresh Uint8[1,2,3,4], value9: omitted/undefined start and
   end fill all; start1,end undefined produces[1,9,9,9]; start null,end null leaves
   input unchanged; start-3,end-1 and start1.9,end3.9 produce[1,9,9,4];
   start-1.9,end Infinity produces[1,2,3,9]; start NaN,end2 produces[9,9,3,4].
   Empty ranges include start>=end, start Infinity, end-Infinity, and length0.

3. **Callbacks, including length0.** Separate value/start/end hooks append v/s/e
   and record the number hint; they run once in that order even when length0 or
   the final range is empty. A conversion returning an object falls through to
   its next ordinary primitive method; a thrown marker retains exact identity.
   Value failure prevents start/end; start failure prevents end. Symbol value
   or index throws TypeError even for an empty requested range.

4. **Initial invalidity.** Ordinary object, DataView, an object merely inheriting
   a real view, detached view, and initially OOB fixed/tracking views reject
   before any argument hook. A genuine successful fill guards the intrinsic
   before tests catch TypeError. The shared function itself is not constructible.

5. **Unconditional final invalidity.** Detach from value, start, or end conversion
   with an empty range: later hooks still run, then TypeError. Fixed-length4
   shrunk to2 during conversion also throws despite start=end=4. A tracking view
   beginning at byteOffset2 is valid-empty when the buffer becomes2 bytes, but
   OOB when it becomes1 byte. Detached value hook followed by a marker-throwing
   start hook must expose the marker, not the deferred bounds TypeError.

6. **Fresh tracking bounds.** Tracking Uint8[1,2,3,4] shrunk to2 in value hook:
   start0/end omitted yields[9,9]; start-3 yields[1,9]; start-2 yields[1,2].
   Negative indices still use captured4. Grow4->8 in value or end hook; fill
   from-2 through Infinity changes only original positions2/3. Newly added tail
   sentinels survive. For Uint16 tracking with byteOffset2, shrink an8-byte
   buffer to5: floor((5-2)/2)=1 live element; only its two bytes may change and
   trailing byte4 must survive. No whole-backing or rounded-up write.

7. **Temporary OOB recovery.** Fixed Uint8[1,2,3,4]: value hook shrinks to2 and
   returns9; start hook regrows4 and returns-2; end undefined. Result is the same
   receiver with[1,2,9,9]. This fails if validation is inserted between hooks.
   A later growth beyond4 still cannot extend the fixed view or captured range.

8. **Identity and direct elements.** Saved fill remains the same shared function
   across all ten constructors and works after its prototype property is
   replaced. Poison own length/constructor and inherited numeric setters/getters;
   no property fallback, length Get, species construction or repeated value
   conversion occurs. A value hook allocates enough new views/buffers to force
   record growth, changes the target prototype, and returns9. The original
   target/backing alias still gets the literal result.

## Independent resource matrix

The proposed body boundary takes an already authenticated copied Record. No
record lookup or native binding is included in these numbers. Existing helper
charges remain live13, offset4, codec48+2w, buffer tick1 plus w copied bytes;
Uint8Clamped adds16. The new loop adds8. Per complete element E is therefore77
for byte integers,93 for Uint8Clamped,80 for width2,86 for width4,98 for width8.
The proposed prelude P is58 with omitted/undefined end,62 with a defined numeric
end. Coercion costs are separate. These are source-derived contracts, pending
the concrete implementation review, not measured predictions of a whole script.

9. **Exact scalar admissions.** All ten kinds, both end branches, three writes:
   body work P+3E and zero new heap. Check exact success,0/P-1/P/P+E-1/P+E/
   P+2E-1/P+2E/P+3E-1 failures. At each failure, complete earlier elements remain
   written and the next element's entire bytes remain unchanged, for every
   width. Inspect retained raw bytes without spending the exhausted VM budget.
   Include source/value equal bytes: identical stores still pay every element.
   A valid empty range pays P, no per-element fee, and returns identity.

10. **Whole saved-call admissions.** Separately measure the complete saved
    Runtime.call boundary on a fresh equivalent fixture, then replay its exact
    work/heap, one-short work, one-short heap, zero-work and zero-heap budgets.
    Also assert the independently known47-byte temporary native name admission
    for TypedArray.fill; the fill body adds no heap. Verify literal bytes,
    identity, unchanged object/record counts and metadata, plus empty frames,
    calls/eval_depth/stack_units/json_depth and active join guards. Caller-created
    Vec/Value handles and fixture compilation remain outside the measured call.

11. **Callback effects and terminal errors.** A conversion writes a visible
    marker/sentinel, then returns normally. A final-scalar one-short cut retains
    that effect and prior complete fill elements. A callback exhausting work
    inside authored try/catch/finally bypasses those handlers under the existing
    terminal-resource policy; no fill store has started. A callback allocation
    failing its admitted heap is also terminal. Use independently completed
    setup and measured reached costs, never a quota increase. Retain exact
    Resource identity and clean interpreter guards.

12. **Frozen upstream follow-through.** Preserve the two published lastIndexOf
    rows which call missing fill. Run the exact original sources/helpers only
    after a real fill implementation. No body substitution, prerequisite
    exclusion or prediction that filling alone guarantees all upstream passes.

Keep the Rust groups compact: combine related literals in tables, retain strict
and sloppy semantic bodies, and keep the body-boundary fee proof separate from
full saved-call measurements. No parser, compiler, test, engine, formatter,
browser or GPU has run while authoring this plan.
