"""Author independent JS bytes only; never parse or execute them."""
from pathlib import Path
import hashlib,json
HERE=Path(__file__).resolve().parent
W=HERE.parents[1]/'worktree'
def digest(b):return hashlib.sha256(b).hexdigest()
guard='''var owner = Object.getPrototypeOf(Uint8Array.prototype);
var fill = owner.fill;
if (typeof fill !== 'function') throw new TypeError('fill prerequisite');
var guard = new Uint8Array([2, 4]);
if (!ArrayBuffer.isView(guard) || fill.call(guard, 7, 1) !== guard || guard[0] !== 2 || guard[1] !== 7) throw new TypeError('working fill prerequisite');
'''
pairs=[
('ordered-clamped-range', '''var a = new Uint8ClampedArray([10, 20, 30, 40]);
var trace = '', calls = 0;
var result = fill.call(a,
  {valueOf:function(){trace += 'V'; calls++; return 2.5;}},
  {valueOf:function(){trace += 'S'; return -3.8;}},
  {valueOf:function(){trace += 'E'; return -1.2;}});
var actual = [result === a, trace, calls, a[0], a[1], a[2], a[3]].join(',');
''','true,VSE,1,10,2,2,40','true,VSE,1,10,3,3,40'),
('ten-number-kinds', '''var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array];
var values = [], identities = 0;
for (var i = 0; i < kinds.length; i++) {
  var a = new kinds[i](2);
  if (fill.call(a, 1.5) === a) identities++;
  values.push(a[0] + ':' + a[1]);
}
var z = new Float64Array(2); fill.call(z, -0);
var n = new Float32Array(2); fill.call(n, NaN);
var actual = values.join(',') + ';' + identities + ';' + Object.is(z[0], -0) + ';' + Object.is(z[1], -0) + ';' + (n[0] !== n[0] && n[1] !== n[1]);
''','1:1,1:1,2:2,1:1,1:1,1:1,1:1,1.5:1.5,1.5:1.5,1.5:1.5;10;true;true;true','1:1,1:1,1:1,1:1,1:1,1:1,1:1,1.5:1.5,1.5:1.5,1.5:1.5;10;true;true;true'),
('tracking-captured-bounds', '''var buffer = new ArrayBuffer(4, {maxByteLength:6});
var a = new Uint8Array(buffer); a[0]=10; a[1]=20; a[2]=30; a[3]=40;
if (typeof buffer.resize !== 'function') throw new TypeError('resize prerequisite');
var trace = '';
var result = fill.call(a,
  {valueOf:function(){trace += 'V'; buffer.resize(6); return 9;}},
  {valueOf:function(){trace += 'S'; return -3;}},
  {valueOf:function(){trace += 'E'; buffer.resize(2); return 4;}});
buffer.resize(5);
var first = [result === a, trace, a[0], a[1], a[2], a[3], a[4]].join(',');
var growth = new ArrayBuffer(2, {maxByteLength:4});
var b = new Uint8Array(growth); b[0]=1; b[1]=2;
var returned = fill.call(b, {valueOf:function(){growth.resize(4); return 6;}});
var actual = first + ';' + [returned === b, b[0], b[1], b[2], b[3]].join(',');
''','true,VSE,10,9,0,0,0;true,6,6,0,0','true,VSE,9,9,0,0,0;true,6,6,6,6'),
('invalid-and-abrupt-order', '''var buffer = new ArrayBuffer(4, {maxByteLength:4});
var a = new Uint8Array(buffer, 0, 4); a[0]=1; a[1]=2; a[2]=3; a[3]=4;
if (typeof buffer.resize !== 'function') throw new TypeError('resize prerequisite');
var trace = '', late = false;
try {
  fill.call(a,
    {valueOf:function(){trace += 'V'; buffer.resize(2); return 9;}},
    {valueOf:function(){trace += 'S'; return 0;}},
    {valueOf:function(){trace += 'E'; return 0;}});
} catch (e) { late = e instanceof TypeError; }
var calls = 0, initial = false;
try { fill.call(a, {valueOf:function(){calls++; return 8;}}); }
catch (e) { initial = e instanceof TypeError; }
buffer.resize(4);
var sentinel = {}, abrupt = false, order = '';
try { fill.call(a,
  {valueOf:function(){order += 'V'; throw sentinel;}},
  {valueOf:function(){order += 'S'; return 0;}},
  {valueOf:function(){order += 'E'; return 4;}}); }
catch (e) { abrupt = e === sentinel; }
var actual = [late, trace, initial, calls, abrupt, order, a[0], a[1], a[2], a[3]].join(',');
''','true,VSE,true,0,true,V,1,2,0,0','false,VSE,true,0,true,V,1,2,0,0'),
('metadata-saved-identity', '''var descriptor = Object.getOwnPropertyDescriptor(owner, 'fill');
var nd = Object.getOwnPropertyDescriptor(fill, 'name');
var ld = Object.getOwnPropertyDescriptor(fill, 'length');
var metadata = descriptor.value === fill && descriptor.writable && !descriptor.enumerable && descriptor.configurable &&
  nd.value === 'fill' && !nd.writable && !nd.enumerable && nd.configurable &&
  ld.value === 1 && !ld.writable && !ld.enumerable && ld.configurable &&
  Object.getPrototypeOf(fill) === Function.prototype && !Object.prototype.hasOwnProperty.call(fill, 'prototype');
if (typeof Reflect.construct !== 'function') throw new TypeError('construct prerequisite');
function Constructor() { this.proof = 7; }
if (Reflect.construct(Constructor, []).proof !== 7) throw new TypeError('working construct prerequisite');
var nonconstructor = false;
try { Reflect.construct(fill, []); } catch (e) { nonconstructor = e instanceof TypeError; }
var deleted = delete owner.fill;
var a = new Uint8Array([3,4]);
var returned = fill.call(a, 5);
var actual = [metadata, nonconstructor, deleted, owner.fill === undefined, returned === a, a[0], a[1]].join(',');
''','true,true,true,true,true,5,5','true,true,true,true,false,5,5')]
controls=[]
for name,body,good,bad in pairs:
 prefix=guard+body
 for positive,literal in [(True,good),(False,bad)]:
  source=prefix+'if (actual !== '+json.dumps(literal)+") throw new Error('independent fill literal mismatch');\n"
  controls.append(dict(name=name+('-positive' if positive else '-wrong'),pair=name,positive=positive,modes=['sloppy','strict'],source=source,source_sha256=digest(source.encode()),common_prefix_sha256=digest(prefix.encode()),expected_literal=literal))
raw=(json.dumps(dict(schema=1,scope='Number TypedArray.fill independent paired source controls',controls=controls),indent=2)+'\n').encode()
(HERE/'controls.json').write_bytes(raw);(W/'tools/typedarray-fill-controls.json').write_bytes(raw)
ready=dict(status='frozen before fill runtime execution',source_sha256=digest(raw),source_bytes=len(raw),pairs=len(pairs),mode_observations=len(controls)*2,guard_sha256=digest(guard.encode()),source=str(HERE/'controls.json'),project_copy='tools/typedarray-fill-controls.json',specification='https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.fill',execution='No JS parser, adapter, importer, compiler or tests')
(HERE/'source-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps(ready))
