# TypedArray fill preparation

The new `typedarray-fill` profile retains all 52 original JavaScript bodies in the complete `TypedArray/prototype/fill` subtree at Test262 revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`: 34 direct files and 18 nested BigInt files, each in sloppy and strict modes. Ten original helpers, two legal files and eight complete Git proof documents accompany the sources. The existing recursive tree verifier authenticates every included source and its ancestors. No runtime outcome determines inclusion.

The frozen policy schedules 54 of 104 modes. All excluded rows remain visible: 36 BigInt, two immutable-arraybuffer, four requiring the complete resizableArrayBufferUtils helper, and eight remaining host-hook modes. The immutable feature is not admitted. The helper exclusion and exact supported features are part of the serialized policy hash. Existing 49 profile policies and defaults remain unchanged.

Five independently authored positive/wrong pairs add 20 control observations to the existing 32 common controls. Each source first requires a genuine callable working fill on an authentic view; wrong partners must throw intrinsic Error after that prerequisite. Same-mode successful positive evidence is mandatory. Cases cover ordered one-time conversion and clamping, all ten Number element kinds including Float16, captured versus refreshed resize bounds, late invalidity even for an empty range, initially invalid receivers, abrupt callback identity, metadata and saved method identity. Frozen control SHA256 is `8e7235a2e834a592417cd3f9a562159edb49f948bda1a728432c6a47134059ba`.

The [primary fill algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.fill) supplies the independent source oracles. Original upstream sources/helpers are unmodified. This is a bounded Number TypedArray increment, not full ECMAScript conformance, immutable-buffer support or BigInt support.

Nine new mocked protocol groups cover complete inventory and policy, control integrity and false-positive rejection, exact intrinsic Error and same-mode prerequisite checks, unchanged common controls, full proof/source/helper tampering, omitted excluded BigInt entries, offline import identity, and resource stops preventing baseline creation even when controls pass. Eighteen historical registration tests exclude only the new fiftieth profile; their old expected counts/hashes remain unchanged. The AST-only preservation receipt reconstructs all 20 modified original modules by removing the new additions.

## Root handoff

The author executed only inert source/data preparation, raw Git/blob hashing and Python AST inspection. No project tool was imported or executed; no parser, adapter, compiler, test or browser ran. Inspect source-ready.json, the retained before/diffs, policy-inventory.json and input-proof.json before execution.

From `/tmp/eris-typedarray-fill-1/worktree`, import once into a fresh target using the retained 72 exact inputs:

```sh
python3 /tmp/eris-typedarray-fill-1/conformance/offline_import.py
python3 -m unittest discover -s tools -p 'test_test262*.py'
```

The ordinary network importer for the identical pin and population is `python3 tools/import_test262.py --profile typedarray-fill`. Use one import route and retain any failed attempt. The offline handoff refuses existing output, authenticates the importer and every input before/after, and never falls back to network.

For the published-adapter report, root supplies its actual immutable binary path:

```sh
python3 tools/test262_conformance.py --profile typedarray-fill --binary "$FILL_BEFORE_ADAPTER" --output /tmp/eris-typedarray-fill-1/upstream-before.json --jobs 2
```

Retain the full report and nonzero exit. Missing-method controls cannot establish a healthy baseline. Future candidate statuses and control health are unknown here; resource, timeout and adapter errors remain unhealthy even with successful controls. No current upstream baseline or gate is proposed from unrun observations.
