"""Source transformation only; never import project tools."""
from pathlib import Path
import json,shutil,difflib
F=Path('/tmp/eris-typedarray-fill-1');C=F/'conformance';W=F/'worktree';O=C/'original';O.mkdir(exist_ok=True)
for p in [W/'tools/import_test262.py',W/'tools/test262_conformance.py',*sorted((W/'tools').glob('test_test262*.py'))]:shutil.copyfile(p,O/p.name)
inv=json.loads((C/'discovery/inventory.json').read_bytes())
p=W/'tools/import_test262.py';s=p.read_text()
s=s.replace('TYPEDARRAY_SEARCH_DIRECTORIES =', 'TYPEDARRAY_FILL_DIRECTORIES = '+repr(inv['directories'])+'\nTYPEDARRAY_FILL_HELPERS = '+repr(set(inv['helpers']))+'\nTYPEDARRAY_SEARCH_DIRECTORIES =',1)
s=s.replace('ITERATION_SUBTREES = {',"ITERATION_SUBTREES = {\n    'typedarray-fill': {'TypedArray/prototype/fill': '5eaac187670caf1fa1256e78d7ae5780de16c47d'},",1)
s=s.replace('ITERATION_HELPERS = {',"ITERATION_HELPERS = {\n    'typedarray-fill': TYPEDARRAY_FILL_HELPERS,",1)
s=s.replace("TREE_PROFILES = {'typedarray-search'", "TREE_PROFILES = {'typedarray-fill', 'typedarray-search'",1)
s=s.replace("PROFILES = {'typedarray-search':", "PROFILES = {'typedarray-fill': TYPEDARRAY_FILL_DIRECTORIES, 'typedarray-search':",1)
s=s.replace("PROFILE_ROOTS = {'typedarray-search':", "PROFILE_ROOTS = {'typedarray-fill': 'test/built-ins', 'typedarray-search':",1)
anchor="    if profile == 'typedarray-search' and harness != TYPEDARRAY_SEARCH_HELPERS:"
s=s.replace(anchor,"    if profile == 'typedarray-fill' and harness != TYPEDARRAY_FILL_HELPERS:\n        raise ValueError('TypedArray fill requested harness differs from the frozen ten helpers')\n"+anchor,1)
s=s.replace("    scope = {", "    scope = {\n        'typedarray-fill': 'all 52 original .js files in the complete TypedArray prototype fill tree, including all BigInt originals; full root-linked Git proof; no implementation',",1)
p.write_text(s)
p=W/'tools/test262_conformance.py';s=p.read_text()
s=s.replace('TYPEDARRAY_SEARCH_FEATURES =',"TYPEDARRAY_FILL_FEATURES = {'TypedArray', 'ArrayBuffer', 'Symbol', 'Reflect.construct',\n                           'arrow-function', 'resizable-arraybuffer'}\nTYPEDARRAY_SEARCH_FEATURES =",1)
s=s.replace("PROFILE_FEATURES = {'typedarray-search':", "PROFILE_FEATURES = {'typedarray-fill': TYPEDARRAY_FILL_FEATURES, 'typedarray-search':",1)
s=s.replace("profile in {'typedarray-search', 'typedarray-views'", "profile in {'typedarray-fill', 'typedarray-search', 'typedarray-views'")
anchor="    if (profile == 'typedarray-search'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray search policy excludes the complete resizableArrayBufferUtils helper'"
assert s.count(anchor)==1
s=s.replace(anchor,anchor+"\n    if (profile == 'typedarray-fill'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray fill policy excludes the complete resizableArrayBufferUtils helper'",1)
a=s.index('def typedarray_search_preflight_variants():');b=s.index('\ndef typedarray_view_preflight_variants():',a)
copy=s[a:b].replace('typedarray_search','typedarray_fill').replace('typedarray-search','typedarray-fill').replace('TypedArray search','TypedArray fill').replace('8113c4c13f318cd34ac17bb5d9990f62fec801cc8e021f678f3b2b85030dfc38','8e7235a2e834a592417cd3f9a562159edb49f948bda1a728432c6a47134059ba')
s=s[:a]+copy+'\n'+s[a:]
s=s.replace("    if profile == 'typedarray-search':\n        variants += typedarray_search_preflight_variants()", "    if profile == 'typedarray-fill':\n        variants += typedarray_fill_preflight_variants()\n    if profile == 'typedarray-search':\n        variants += typedarray_search_preflight_variants()",1)
s=s.replace("            if ((profile == 'typedarray-search'", "            if ((profile == 'typedarray-fill' and name.startswith('typedarray-fill-'))\n                    or (profile == 'typedarray-search'",1)
a=s.index("    if profile == 'typedarray-search':\n        # Preserve")
b=s.index("    if profile == 'typedarray-views':\n        # Preserve",a)
copy=s[a:b].replace('typedarray-search','typedarray-fill');s=s[:a]+copy+s[a:]
s=s.replace("if args.profile in {'typedarray-views', 'typedarray-search'}:", "if args.profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill'}:",1)
p.write_text(s)
# Historical contracts keep their original populations. No source/policy oracles broaden.
for p in sorted((W/'tools').glob('test_test262*.py')):
 s=p.read_text();lines=s.splitlines(True)
 for i,line in enumerate(lines):
  if "'typedarray-search'" in line and any(x in line for x in ['excluded=', 'excluded =', 'if profile in', 'if name in', 'set(runner.PROFILES)']):
   lines[i]=line.replace("'typedarray-search'", "'typedarray-fill', 'typedarray-search'",1)
 s=''.join(lines)
 if p.name=='test_test262_typedarray_search.py':
  assert s.count('len(runner.PROFILES), 49')==1
  s=s.replace('len(runner.PROFILES), 49',"len(set(runner.PROFILES) - {'typedarray-fill'}), 49",1)
 p.write_text(s)
changed=[]
for p in sorted(O.iterdir()):
 actual=W/'tools'/p.name
 if actual.read_bytes()!=p.read_bytes():
  changed.append('tools/'+p.name)
  (C/(p.name+'.diff')).write_text(''.join(difflib.unified_diff(p.read_text().splitlines(True),actual.read_text().splitlines(True),fromfile='before/tools/'+p.name,tofile='tools/'+p.name)))
(C/'changed-existing-paths.json').write_text(json.dumps(changed,indent=2)+'\n')
print(json.dumps(dict(changed_existing_paths=len(changed))))
