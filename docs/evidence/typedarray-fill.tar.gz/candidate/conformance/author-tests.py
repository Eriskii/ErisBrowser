from pathlib import Path
F=Path('/tmp/eris-typedarray-fill-1');C=F/'conformance';W=F/'worktree'
s=(C/'original/test_test262_typedarray_search.py').read_text()
s=s.replace('relative-index/search','fill').replace('typedarray-search','typedarray-fill').replace('TypedArraySearchTests','TypedArrayFillTests')
a=s.index('PAIRS = ');b=s.index('\n\ndef proof_reader',a)
s=s[:a]+'''PAIRS = ['ordered-clamped-range', 'ten-number-kinds', 'tracking-captured-bounds',
         'invalid-and-abrupt-order', 'metadata-saved-identity']
DIRECTORIES = {'TypedArray/prototype/fill': 34, 'TypedArray/prototype/fill/BigInt': 18}
FEATURES = {'TypedArray', 'ArrayBuffer', 'Symbol', 'Reflect.construct',
            'arrow-function', 'resizable-arraybuffer'}
'''+s[b:]
s=s.replace('(145, 290, 154, [])','(52, 104, 64, [])').replace('[145, 145]','[52, 52]').replace("len(manifest['inventory_proof']['files']), 11","len(manifest['inventory_proof']['files']), 8")
s=s.replace("{'assert.js', 'sta.js', 'propertyHelper.js',\n                          'isConstructor.js', 'testTypedArray.js', 'detachArrayBuffer.js',\n                          'resizableArrayBufferUtils.js'}", "{'assert.js', 'sta.js', 'propertyHelper.js', 'isConstructor.js',\n                          'testTypedArray.js', 'detachArrayBuffer.js', 'resizableArrayBufferUtils.js',\n                          'nans.js', 'byteConversionValues.js', 'compareArray.js'}")
s=s.replace('reasons.count(None), 158','reasons.count(None), 54').replace("BigInt'), 88","BigInt'), 36").replace("source check)'), 18","source check)'), 8").replace("TypedArray search policy excludes the complete resizableArrayBufferUtils helper'), 26","TypedArray fill policy excludes the complete resizableArrayBufferUtils helper'), 4")
s=s.replace("        self.assertNotIn('BigInt', FEATURES)","        self.assertNotIn('BigInt', FEATURES)\n        self.assertNotIn('immutable-arraybuffer', FEATURES)")
s=s.replace("        self.assertEqual(reasons.count('unimplemented declared features: BigInt'), 36)","        self.assertEqual(reasons.count('unimplemented declared features: BigInt'), 36)\n        self.assertEqual(reasons.count('unimplemented declared features: immutable-arraybuffer'), 2)")
s=s.replace('is None for c in cases), 184','is None for c in cases), 58').replace("in c['file'] for c in cases), 88","in c['file'] for c in cases), 36")
s=s.replace('len(runner.PROFILES), 49','len(runner.PROFILES), 50')
a=s.index('        for name, features in runner.PROFILE_FEATURES.items():');b=s.index('\n    def test_controls_',a);s=s[:a]+s[b:]
s=s.replace('8113c4c13f318cd34ac17bb5d9990f62fec801cc8e021f678f3b2b85030dfc38','8e7235a2e834a592417cd3f9a562159edb49f948bda1a728432c6a47134059ba')
s=s.replace('(56, 56)','(52, 52)').replace("outcomes[32:]), 12","outcomes[32:]), 10").replace('len(results), 56','len(results), 52')
s=s.replace('TypedArray/prototype/at/length.js','TypedArray/prototype/fill/length.js').replace('TypedArray/prototype/includes/BigInt/detached-buffer.js','TypedArray/prototype/fill/BigInt/detached-buffer.js').replace('TypedArray/prototype/lastIndexOf/length.js','TypedArray/prototype/fill/immutable-buffer.js')
s=s.replace('c1f0eae9a0485de57814aeb7e8f45fc0f87f420a','5eaac187670caf1fa1256e78d7ae5780de16c47d').replace('TypedArray/prototype/at/BigInt/return-abrupt-from-this-out-of-bounds.js','TypedArray/prototype/fill/BigInt/return-abrupt-from-this-out-of-bounds.js')
s=s.replace("[(PROFILE, 158), ('typedarray-views', 110)]", "[(PROFILE, 54), ('typedarray-search', 158), ('typedarray-views', 110)]")
(W/'tools/test_test262_typedarray_fill.py').write_text(s)
