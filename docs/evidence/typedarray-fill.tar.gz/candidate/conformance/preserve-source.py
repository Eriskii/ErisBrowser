"""AST/data comparisons only: never import or execute project code."""
import ast, hashlib, json, difflib
from pathlib import Path
R=Path(__file__).resolve().parent; W=R.parent/'worktree'
def dump(n): return ast.dump(n,include_attributes=False)
def sha(b): return hashlib.sha256(b).hexdigest()
def is_search(n): return isinstance(n,ast.Constant) and n.value=='typedarray-fill'
def search_eq(n):
    return isinstance(n,ast.Compare) and len(n.ops)==1 and isinstance(n.ops[0],ast.Eq) and any(is_search(c) for c in n.comparators)
class Revert(ast.NodeTransformer):
    def visit_Assign(self,n):
        if any(isinstance(t,ast.Name) and t.id.startswith('TYPEDARRAY_FILL_') for t in n.targets): return None
        return self.generic_visit(n)
    def visit_FunctionDef(self,n):
        if n.name=='typedarray_fill_preflight_variants': return None
        return self.generic_visit(n)
    def visit_Dict(self,n):
        keep=[i for i,k in enumerate(n.keys) if not is_search(k)]
        n.keys=[n.keys[i] for i in keep];n.values=[n.values[i] for i in keep]
        return self.generic_visit(n)
    def visit_Set(self,n):
        n.elts=[e for e in n.elts if not is_search(e)]
        return self.generic_visit(n)
    def visit_Tuple(self,n):
        n.elts=[e for e in n.elts if not is_search(e)]
        return self.generic_visit(n)
    def visit_BinOp(self,n):
        n=self.generic_visit(n)
        if isinstance(n.op,ast.Sub) and isinstance(n.right,ast.Set) and not n.right.elts:
            return n.left.args[0] if isinstance(n.left,ast.Call) and isinstance(n.left.func,ast.Name) and n.left.func.id=='set' else n.left
        return n
    def visit_If(self,n):
        if search_eq(n.test) or (isinstance(n.test,ast.BoolOp) and isinstance(n.test.op,ast.And) and any(search_eq(v) for v in n.test.values)): return None
        n=self.generic_visit(n)
        if isinstance(n.test,ast.Compare) and isinstance(n.test.left,ast.Attribute) and n.test.left.attr=='profile' and len(n.test.ops)==1 and isinstance(n.test.ops[0],ast.In) and isinstance(n.test.comparators[0],ast.Set) and [e.value for e in n.test.comparators[0].elts]==['typedarray-views']:
            n.test.ops=[ast.Eq()]; n.test.comparators=[ast.Constant(value='typedarray-views')]
        return n
    def visit_BoolOp(self,n):
        if isinstance(n.op,ast.Or):
            n.values=[v for v in n.values if not (isinstance(v,ast.BoolOp) and isinstance(v.op,ast.And) and any(search_eq(x) for x in v.values))]
        n=self.generic_visit(n)
        return n.values[0] if len(n.values)==1 else n
rows=[]
for path in json.loads((R/'changed-existing-paths.json').read_bytes()):
    before=(R/'original'/Path(path).name).read_bytes();after=(W/path).read_bytes()
    old=ast.parse(before); new=ast.parse(after)
    equal=dump(old)==dump(Revert().visit(new))
    assert equal,path
    old_funcs={n.name:dump(n) for n in old.body if isinstance(n,ast.FunctionDef)}
    new_funcs={n.name:dump(n) for n in ast.parse(after).body if isinstance(n,ast.FunctionDef)}
    changed=[name for name,body in old_funcs.items() if new_funcs.get(name)!=body]
    unchanged=[name for name,body in old_funcs.items() if new_funcs.get(name)==body]
    rows.append(dict(path=path,before_sha256=sha(before),after_sha256=sha(after),normalized_old_ast_exact=equal,changed_functions=changed,unchanged_function_count=len(unchanged)))
    (R/(Path(path).name+'.diff')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='before/'+path,tofile=path)))
newtests=ast.parse((W/'tools/test_test262_typedarray_fill.py').read_bytes())
groups=[n.name for n in ast.walk(newtests) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(groups)==9
(R/'preservation.json').write_text(json.dumps(dict(scope='AST-only removal of new profile additions reconstructs all 20 original modules; old profile policies/defaults and assertion values unchanged',old_modules=rows,new_protocol_groups=groups,project_modules_imported=False,project_code_executed=False),indent=2)+'\n')
print(json.dumps(dict(status='clear',old_modules=len(rows),new_groups=len(groups))))
