Source-only review: clear on the held constructor and test delta.

`Runtime::try_new` now obtains the complete realm through `uninitialized().finish_bootstrap()?` before assigning `MAX_STEPS`. Every checked bootstrap failure returns before that assignment; the partial realm is consumed and dropped. `finish_bootstrap`, its initial 100,000-unit work allowance, and all reached bootstrap debits remain unchanged. The author allowance is also still 100,000. No allocation counter is reset: the returned realm retains exactly the raw bootstrap's cumulative heap debit and storage.

`new`, `Default`, and both Date-host constructors funnel through this one successful boundary. Date-host installation is a move after successful construction and neither repeats the reset nor reads the host clock. This intentionally changes the initial allowance seen by private/direct helpers from the bootstrap remainder to the full author allowance; it does not make those helpers reset on subsequent calls.

Production callers were traced through `Page::unexecuted`, the adapter's `evaluate_with_runtime`, and the stress adapter. Page script execution, strict/non-strict adapter scripts and harnesses, and stress scripts already enter `execute_program`, which keeps source/compiled-storage heap admission before its existing work reset. Readiness, host click/submit/input dispatch, and the host details checkpoint retain their existing reset sites and prior validation. Worker operations use these Page/runtime entry points. No Page, adapter, worker, or host-event code changed in this delta.

Ordinary calls, accessors, coercion callbacks, and author `dispatchEvent` retain the same `&mut Runtime`; author event dispatch enters private `dispatch_event_object`, not the host reset method. The machine/call paths neither construct another Runtime nor enter `try_new` to refresh the same realm. The remaining non-test steps assignment outside these entry points copies back the already-debited regexp sub-budget, not a fresh allowance.

The test updates preserve the original raw 70,656-unit bootstrap remainder, exact/one-short late work and heap witnesses, early/partial initialization failures, and unchanged resource-error identity. Constructor variants now assert a full author allowance, a four-unit direct-helper debit, and heap/capacity/intrinsic equality with raw bootstrap. The existing execute-before-heap-failure/reset test remains intact. The two added groups compare the first public script's result/work/heap under both constructor paths in both strict modes, and exercise terminal shared work through getters, ToPrimitive, and nested event callbacks with cleanup assertions.

Reviewed source bindings (SHA-256):

- `src/script.rs`: `2fa74366a4f689e2ded15a6d9f86ff88fe1dd13389bdf5eb5bbc2bb158f8ffb0`
- `src/script/bootstrap_tests.rs`: `6e40959519d6ab56864c45d2bd510a664c4b1b55a16a79a4cc283dc2cd5eebdc`
- `src/page.rs`: `421c03f700b17211bde053f1b60582786d67c51b1d606f4003cdbefcc34f7ee3`
- `src/worker.rs`: `91967f670b4ad8f51215aa56d656d053c8274d5f905aae04ebf181c61a1fac85`
- `src/bin/eris-js.rs`: `60b28bdf235a53111921de5da9ce83cfe7a57ee0acdd023492d20ef19e75fe9a`
- `src/bin/eris-stress.rs`: `6a725a859fdf803c7e227d29a2d70cf7299b998da9856ef1754004fc7d6e160e`
- `src/script/machine.rs`: `fc9a52352a5f2ef4a7a5bb5709e37b2b54e8f5ffdb5d16c2490bfa42b6fe1b8e`
- `src/script/machine/calls.rs`: `cb4bbac7aa665f55a08a88708dbc3557317a6ef852268112289b56d0994a6aa0`

No concrete defect found. No compiler, engine, or test execution by this reviewer; this receipt establishes source reasoning, not validation results. No repository files were changed by the reviewer.
