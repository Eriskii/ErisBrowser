# Bootstrap and author-turn work boundary

Source inspection at parent c33e6294bf0c6010b0d2378ec7fee7ef6a407853. The implementation described below was subsequently authorized; focused validation is recorded separately. No changed conformance result is claimed here.

## Recommended and implemented placement

Keep `uninitialized().finish_bootstrap()` as the raw, bounded initializer. In `try_new`, bind its successful result with `?`, then assign `runtime.steps = MAX_STEPS` and return it. This is the only production behavior change. `new`, `Default`, `try_with_date_host` and `with_date_host` already delegate through this path. Their panicking/fallible distinction remains unchanged.

`finish_bootstrap` still reserves the object arena, initializes machine storage, then initializes intrinsics in exactly that order. Every initialization refusal returns before the new assignment; no partially initialized runtime escapes. The private raw initializer still exposes actual initialization work to internal tests. Its current remainder is 70,656 of the unchanged 100,000 units: initialization consumed 29,344. The public constructor result starts with 100,000 execution units. Heap accounting stays cumulative, with the same 8 MiB bound and no refund or allocation change. Calls, frames, stack, parser budgets and resource-error handling are untouched.

Putting the assignment inside `finish_bootstrap` would unnecessarily erase the raw success boundary used by admission tests. A new reset helper, state machine, quota override or constructor injection is unnecessary. `finish_bootstrap(self)` consumes an unpublished runtime and public construction creates a fresh runtime; there is no author callback at this boundary.

## Complete public execution inventory

| Public route | Reset and checks before it | Production callers |
| --- | --- | --- |
| `execute` / `execute_strict` | Parse using the parser's separate bounded budget; `execute_program` charges source and compiled storage, then sets `steps = MAX_STEPS` before evaluation. | `Page::run_scripts`; each eris-js harness file and test source; eris-stress script cases. |
| `dispatch_dom_content_loaded` | Already-fired readiness returns without reset; otherwise readiness is marked fired, then the budget resets. DOMContentLoaded and load share that allowance. | `Page::run_scripts`, eris-stress. |
| `dispatch_click` | Delegates to `dispatch_event`. | Page click/default-summary handling, eris-stress. |
| `dispatch_event` | Rejects event names over 128 bytes and checks target validity, neither of which consumes runtime work or invokes author code; then resets before event creation/dispatch. | Page submit, worker input editing, the click wrapper; also public Rust embeddings. |
| `dispatch_details_toggles` | Rejects a running checkpoint before reset; otherwise resets once, then processes at most 64 tasks sharing that allowance. | `Page::disclosure_checkpoint`, including pending-task, script, input and click checkpoints. |
| `parse_only` / `parse_only_strict` | Static parser APIs; no Runtime or author evaluation. | eris-js parse admission. |

The remaining public Runtime methods are construction. Its only public fields are `console` and `last_default_prevented`; steps/allocated and native helpers are private. `Page.runtime` is public, but it only exposes those same public operations. The main command-line page path reads its console, not private interpreter helpers.

The worker's input route is `apply_edit -> dispatch_event(node, "input")`; it does not bypass the reset. Parser, dynamic Function compilation and RegExp use separate bounded parser/temporary ledgers where already implemented; copying their remaining work back is a debit handback, not a fresh allowance.

## First-entry observable behavior

For a successfully parsed first script with enough cumulative heap, both the old raw remainder and the new returned allowance are overwritten at exactly the existing point, before author evaluation. Initial objects, identities, descriptors, heap debit and evaluation state are equal. Therefore successful values, side effects, remaining evaluation work and cumulative allocation should match exactly; the new paired private test compares both modes using getter and conversion effects, console output, work and heap.

For parse failure, source/compiled-storage heap refusal, invalid host event target/name, duplicate readiness or an already-running details checkpoint, the existing result and side effects are unchanged. A path that returns before resetting can retain a different private `steps` value after construction; that field is not a public observation, and the next accepted author entry resets as before. The charge-before-reset order remains important: failing source admission must not grant a turn. The existing test retains its 123-step witness for that refusal.

This does not grant an additional public source evaluation. The constructor's ready allowance is discarded at the existing next author-entry reset, not added to it. It deliberately removes initialization-cost coupling for private direct-helper use. The old exhaustive UTF-16 JSON round-trip and maximum-string concat tests exercise that private path and should remain byte-exact. Their algorithms and quotas do not change.

## Nested execution remains one turn

JavaScript cannot call the reset-bearing Rust entry methods. Ordinary functions, getters, setters, ToPrimitive, native callbacks and constructors use the active interpreter state. `EventTarget.dispatchEvent` calls private `dispatch_event_object`, as do nested abort notifications; that helper does not reset work. Native dispatch retains its existing cleanup on error. Dynamic Function compilation borrows remaining work via `regexp_budget` and writes the remainder back. Global JavaScript `eval` is explicitly Unsupported; the private `eval` method evaluates an already compiled expression without a reset. DateHost is stored clock/zone data, not a reentrant application callback.

The new terminal test enters an already compiled author computation with 2,000 remaining units, reaches a getter, conversion hook and synthetic event listener, then exhausts work before its finite 200-iteration body completes. Catch/finally markers remain false and event/call/frame state is cleaned. This tests the absence of callback grants without changing any production limit.

## Exact test-witness changes

- Keep every raw reserve/machine/intrinsic error and exact/one-short assertion. Only the reference runtime in the two late-boundary tests changes from `try_new` to `uninitialized().finish_bootstrap()`, so measured initialization debits and the exact raw zero remainder remain meaningful.
- The convenience-constructor test uses a raw reference, retains the 70,656 initialization snapshot, compares all metadata/capacity/cumulative allocation, and checks that each public wrapper starts at 100,000 and a direct Object.is call consumes four units.
- The injected DateHost test expects the ready allowance and still proves construction consumes no clock samples.
- Three descriptive diagnostics in DataView, Object.is and DOM parent-method tests use a raw initializer witness; their original remaining-work assertions and output retain their initialization meaning. Root owns these three one-statement changes.
- Existing execute admission/reset, exhaustive JSON, concat, quota and callback semantic tests remain unchanged. Added coverage is the first-public-entry equivalence and shared-callback terminal groups above.

Documentation should distinguish fixed 100,000 initialization work from fixed 100,000 author-entry work while retaining cumulative heap and existing per-entry definitions. Any before/after conformance observations require the normal frozen replay; source inspection alone is not a measured preservation claim.
