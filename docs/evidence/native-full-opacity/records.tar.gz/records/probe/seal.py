from pathlib import Path
import ast, json, hashlib, shutil, difflib
A=Path('/tmp/eris-vulkan-full-opacity-1/probe');W=Path('/tmp/eris-vulkan-full-opacity-1/worktree');P=W/'tools/vulkan-raster-probe'
sha=lambda b:hashlib.sha256(b).hexdigest()
write=lambda p,v:p.write_text(json.dumps(v,indent=2)+'\n')
def function(s,signature):
 a=s.index(signature);b=s.index('{',a);depth=1;i=b+1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[a:i]
old=(A/'before/src/opacity_fixtures.rs').read_text();new=(P/'src/opacity_fixtures.rs').read_text()
proof={'status':'Source/data checks only; no reviewed module imported or executed','preserved_rust_functions':[]}
for signature in ['pub fn reuse_fixtures()', 'fn transparent_literals(', 'pub fn transparent_reuse_fixtures()']:
 a=function(old,signature);b=function(new,signature);assert a==b
 proof['preserved_rust_functions'].append({'signature':signature,'sha256':sha(a.encode()),'bytes':len(a.encode())})
prefix='pub fn fixtures()'
marker='    {\n        let frame = Frame {\n            width: 1,\n            height: 1,\n            clear: 0x000000,'
a=old.index(prefix);end=old.index(marker,old.index('name: "zero-scope-suppresses'))
b=new.index(prefix);bend=new.index(marker,new.index('name: "zero-scope-suppresses'))
assert old[a:end]==new[b:bend]
proof['first_11_positive_blocks']={'sha256':sha(old[a:end].encode()),'bytes':end-a}
proof['old_positive_count']=17
proof['unchanged_dependencies']=[]
for rel in ['src/reuse_gpu.rs','opacity-fixtures/literal-fixtures.json','opacity-fixtures/transparent-fixtures.json']:
 a=(A/'before'/rel).read_bytes();b=(P/rel).read_bytes();assert a==b
 proof['unchanged_dependencies'].append({'path':rel,'sha256':sha(b)})
surf=(P/'src/surface_gpu.rs').read_text();assert surf.replace('const MAX_CASES: usize = 29;','const MAX_CASES: usize = 17;')==(A/'before/src/surface_gpu.rs').read_text()
proof['surface_cap_only']='17 to 29; byte-exact reversal'
oldhost=ast.parse((A/'before/run_opacity_host.py').read_text());host=ast.parse((P/'run_opacity_host.py').read_text());tests=ast.parse((P/'test_opacity_host.py').read_text())
def named(tree,name):return next(n for n in tree.body if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.name==name)
proof['unchanged_host_functions']=[]
for name in ['main','validate_listing','expected_reuse_sequence']:
 assert ast.dump(named(oldhost,name))==ast.dump(named(host,name));proof['unchanged_host_functions'].append(name)
# The process driver differs only by the additive immutable JSON dependency.
oldrun=ast.dump(named(oldhost,'run_host'))
newsrc=ast.get_source_segment((P/'run_opacity_host.py').read_text(),named(host,'run_host'))
newsrc=newsrc.replace("'opacity-fixtures/transparent-fixtures.json', 'opacity-fixtures/full-fixtures.json')", "'opacity-fixtures/transparent-fixtures.json')")
newsrc=newsrc.replace("    if bindings['opacity-fixtures/full-fixtures.json'] != FULL_SHA256:\n        raise ValueError('independent full opacity fixture changed')\n",'')
assert ast.dump(ast.parse(newsrc).body[0])==oldrun
proof['supervision']='run_host AST exact after removing only new fixture binding and its digest check; runner, cleanup, deadlines, output bounds, exception retention and hash pre/post checks unchanged'
roster=ast.literal_eval(next(n.value for n in host.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='LITERALS' for t in n.targets)))
testfn=named(tests,'transcript');testroster=ast.literal_eval(next(n.value for n in testfn.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='cases' for t in n.targets)))
assert roster==testroster and len(roster)==29 and sum(r[2] for r in roster)*2==608
assert len({r[0] for r in roster})==29
assert 4*16+58+3*(8+14)+1==189
proof['population']={'cases':29,'literal_frames':58,'literal_bytes':608,'full_max_records':189,'host_cap':192,'parser_test_groups':len([n for n in named(tests,'OpacityProtocolTests').body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')])}
assert proof['population']['parser_test_groups']==5
full=json.loads((P/'opacity-fixtures/full-fixtures.json').read_text());held=json.loads(Path(full['held_raw_literals']['path']).read_text())
assert [{k:v for k,v in r.items() if k!='scratch_bytes'} for r in full['cases'][1:9]]==held['cases']
assert len(full['reuse_cases'])==4 and len(full['cases'])==12
proof['held_8_raw_cases_exact']=True
proof['no_execution']='ast.parse/literal_eval, hashes, copying and source comparison only; no parser import, test execution, compiler, engine, planner or GPU'
write(A/'preservation.json',proof)
write(A/'inventory.json',{'status':'Prospective held source, execution pending','case_order':[{'name':n,'scratch_bytes':s,'pixel_bytes':b} for n,s,b in roster],'per_adapter':full['totals_per_adapter'],'formats':{'literal':{'Bgra8Unorm':29,'Rgba8Unorm':29},'each_reuse':{'Bgra8Unorm':8,'Rgba8Unorm':6},'total':{'Bgra8Unorm':53,'Rgba8Unorm':47}},'maximum_log_records':189,'record_cap':192,'retained_scope':'All 17 old positives and both reuse corpora unchanged. Last historical nongrid refusal replaced by explicit positive white-over-black; invalid input tests remain in core. Cancellation leases excluded from 21 allocation/reuse/eviction schedule counts.','parser_test_groups':5})
(A/'README.md').write_text('''# Full finite-opacity offscreen source hold

Six owned files extend the closed transparent-opacity corpus. No candidate or parser test was executed by this author. Root owns compilation, parser tests and Vulkan runs.

The 29 literal cases run in two formats (58 frames, 608 bytes). Three separate reuse corpora each retain the existing 14-frame, 448-byte schedule, eight cancellation cuts and seven allocations/reuses/evictions. Total prospective work per adapter is 100 compared frames, 1952 bytes and 24 cancellation cuts; the latter are not counted as reusable allocation events. No acquired-window claim follows from these checks.

The first 17 positive blocks, both old reuse functions and both historical JSON inputs are unchanged. The former 0.1 refusal is explicitly replaced with white255 over black, expected 1a1a1a. Eight previously held raw-bit literals and three independently checked nested literals add exact binary32 coverage. Positive subnormal groups retain scratch admission; their unchanged final pixels do not permit suppressing preparation.

The new full reuse corpus preserves transparent geometry and inputs, changing only opacity bits and literal arrays. The existing GPU reuse runner is byte-exact. Surface MAX_CASES changes only 17 to 29; browser quotas are unchanged. The host retains all ordered observations, inventories, byte totals, cancellation obligations, deadlines, cleanup and pre/post bindings. Four inventories of at most16 adapters plus58 literal, three times22 reuse/cancellation, and one completion require at most189 lines; the bound is192. The five existing parser test groups cover the enlarged population and false-health mutations; their execution remains pending.

Preservation is recorded by source/AST/data checks in preservation.json. It does not attest numerical execution. The authoring scripts and original source copies are retained, as are final held source copies and diffs. Script's independent algebra check confirmed f6f6f6,606060,f9f9f9 and the new partial-alpha/opaque reuse channel literals before execution; its final source receipt is additive.
''')
owned=['src/opacity_fixtures.rs','src/bin/opacity-check.rs','src/surface_gpu.rs','run_opacity_host.py','test_opacity_host.py','opacity-fixtures/full-fixtures.json']
source_rows=[]
for rel in owned:
 p=P/rel;q=A/'held'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 source_rows.append({'path':str(p),'relative_path':'tools/vulkan-raster-probe/'+rel,'held_copy':str(q),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
 before=A/'before'/rel
 diff=''.join(difflib.unified_diff(before.read_text().splitlines(True) if before.exists() else [],p.read_text().splitlines(True),fromfile='before/'+rel,tofile='after/'+rel))
 d=A/'diffs'/(rel+'.diff');d.parent.mkdir(parents=True,exist_ok=True);d.write_text(diff)
deps=['src/reuse_gpu.rs','opacity-fixtures/literal-fixtures.json','opacity-fixtures/transparent-fixtures.json','run_browser_host.py','run_glyph_host.py','run_host.py','bridge_supervisor.py','browser_protocol.py','glyph_protocol.py']
dep_rows=[{'path':str(P/p),'sha256':sha((P/p).read_bytes()),'bytes':(P/p).stat().st_size} for p in deps]
aux=[]
for name in ['before.json','preservation.json','inventory.json','README.md','author.py','author-protocol.py','seal.py']:
 p=A/name;aux.append({'path':str(p),'sha256':sha(p.read_bytes()),'bytes':p.stat().st_size})
write(A/'source-ready.json',{'schema':1,'status':'held source only; ready for independent review before root execution','base_commit':'d25c5d407eb398b4819450d719c4aef42377bed6','owned_files':source_rows,'unchanged_dependencies':dep_rows,'auxiliary_inputs':aux,'executions':'Rust 1.88 rustfmt source formatting; source/data checks only. No compiler, fixture/parser tests, planner, engine or GPU.','prospective_counts':full['totals_per_adapter']})
print('source-ready.json '+sha((A/'source-ready.json').read_bytes()))
print('full-fixtures.json '+sha((P/'opacity-fixtures/full-fixtures.json').read_bytes()))
