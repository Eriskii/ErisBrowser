# Full finite-opacity offscreen source hold

Six owned files extend the closed transparent-opacity corpus. No candidate or parser test was executed by this author. Root owns compilation, parser tests and Vulkan runs.

The 29 literal cases run in two formats (58 frames, 608 bytes). Three separate reuse corpora each retain the existing 14-frame, 448-byte schedule, eight cancellation cuts and seven allocations/reuses/evictions. Total prospective work per adapter is 100 compared frames, 1952 bytes and 24 cancellation cuts; the latter are not counted as reusable allocation events. No acquired-window claim follows from these checks.

The first 17 positive blocks, both old reuse functions and both historical JSON inputs are unchanged. The former 0.1 refusal is explicitly replaced with white255 over black, expected 1a1a1a. Eight previously held raw-bit literals and three independently checked nested literals add exact binary32 coverage. Positive subnormal groups retain scratch admission; their unchanged final pixels do not permit suppressing preparation.

The new full reuse corpus preserves transparent geometry and inputs, changing only opacity bits and literal arrays. The existing GPU reuse runner is byte-exact. Surface MAX_CASES changes only 17 to 29; browser quotas are unchanged. The host retains all ordered observations, inventories, byte totals, cancellation obligations, deadlines, cleanup and pre/post bindings. Four inventories of at most16 adapters plus58 literal, three times22 reuse/cancellation, and one completion require at most189 lines; the bound is192. The five existing parser test groups cover the enlarged population and false-health mutations; their execution remains pending.

Preservation is recorded by source/AST/data checks in preservation.json. It does not attest numerical execution. The authoring scripts and original source copies are retained, as are final held source copies and diffs. Script's independent algebra check confirmed f6f6f6,606060,f9f9f9 and the new partial-alpha/opaque reuse channel literals before execution; its final source receipt is additive.
