from pathlib import Path
import json, hashlib, shutil
A=Path('/tmp/eris-vulkan-full-opacity-1/probe'); W=Path('/tmp/eris-vulkan-full-opacity-1/worktree'); P=W/'tools/vulkan-raster-probe'
paths=['src/opacity_fixtures.rs','src/bin/opacity-check.rs','src/surface_gpu.rs','run_opacity_host.py','test_opacity_host.py','opacity-fixtures/literal-fixtures.json','opacity-fixtures/transparent-fixtures.json','src/reuse_gpu.rs']
assert not (A/'before.json').exists()
rows=[]
for rel in paths:
 p=P/rel; q=A/'before'/rel;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
 rows.append({'path':str(p),'copy':str(q),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
(A/'before.json').write_text(json.dumps({'files':rows},indent=2)+'\n')
held_path=Path('/tmp/eris-next-opacity-values-assessment-1/literal-candidates.json')
held=json.loads(held_path.read_text())['cases']
rect=lambda rgba:{'op':'rect','rect':[0,0,1,1],'rgba':rgba,'radius':0}
push=lambda bits:{'op':'push_opacity','f32_bits_hex':bits}
pop={'op':'pop_opacity'}
converted={'name':'non-grid-point-one-white-over-black','frame':{'width':1,'height':1,'clear':'000000'},'commands':[push('3dcccccd'),rect([255,255,255,255]),pop],'expected_pixels':['1a1a1a'],'scratch_bytes':8}
nested=[
 {'name':'raw-nested-point-one-over-point-seven','frame':{'width':1,'height':1,'clear':'ffffff'},'commands':[push('3dcccccd'),push('3f333333'),rect([0,0,0,128]),pop,pop],'expected_pixels':['f6f6f6'],'scratch_bytes':16},
 {'name':'raw-inner-point-one-under-grid-half','frame':{'width':1,'height':1,'clear':'2c2c2c'},'commands':[push('3f000000'),rect([151,151,151,255]),push('3dcccccd'),rect([0,0,0,38]),pop,pop],'expected_pixels':['606060'],'scratch_bytes':16},
 {'name':'grid-inner-half-under-raw-point-one','frame':{'width':1,'height':1,'clear':'ffffff'},'commands':[push('3dcccccd'),push('3f000000'),rect([0,0,0,128]),pop,pop],'expected_pixels':['f9f9f9'],'scratch_bytes':16},
]
reuse=[
 ('a','3dcccccd',[0,0,4,1],[65,0,0,128],[1,0,1,1],[0,65,0,255],2,0,[0,0,65,255],['030000','000700','000007','030000','000000','000000','000000','000000'],32),
 ('b','3f333333',[0,1,4,1],[0,0,65,128],[3,1,1,1],[0,65,0,255],2,1,[65,0,0,255],['000000','000000','000000','000000','000017','000017','2e0000','002e00'],32),
 ('c','3e99999a',[1,0,2,2],[65,65,65,128],[1,1,1,1],[0,0,0,255],2,0,[65,0,0,255],['000000','0a0a0a','140000','000000','000000','000000','0a0a0a','000000'],32),
 ('resized','3f333333',[0,0,3,2],[65,65,65,128],[0,1,1,1],[0,0,0,255],2,0,[65,0,0,255],['171717','171717','2e0000','000000','000000','171717','171717','000000'],48),
]
reuse_json=[]
for name,bits,rr,rgba,ir,img,row,y,glyph,expected,scratch in reuse:
 reuse_json.append({'name':'opacity-full-reuse-'+name,'frame':{'width':4,'height':2,'clear':'000000'},'opacity_bits_hex':bits,'rect':rr,'rgba':rgba,'image_rect':ir,'image_rgba':img,'glyph_row':row,'glyph_y':y,'glyph_rgba':glyph,'glyph_coverage':255,'expected_pixels':expected,'scratch_bytes':scratch})
record={'schema':1,'status':'Static source/algebra expectations; no candidate execution','coordinate_rules':'Integer geometry; full-frame caller clip; zero offsets; row-major RGB hexadecimal pixels.','arithmetic':'Canvas separate binary32 stages and final half-away rounding; no candidate or shader-derived expected pixels.','predecessors':[{'path':r['path'],'sha256':r['sha256']} for r in rows if r['path'].endswith('.json')],'held_raw_literals':{'path':str(held_path),'sha256':hashlib.sha256(held_path.read_bytes()).hexdigest()},'cases':[converted]+[{**r,'scratch_bytes':8} for r in held]+nested,'reuse_cases':reuse_json,'totals_per_adapter':{'literal_cases':29,'literal_frames':58,'literal_bytes':608,'reuse_corpora':3,'reuse_frames_per_corpus':14,'reuse_bytes_per_corpus':448,'frames':100,'bytes':1952,'cancellations':24,'allocations':21,'reuses':21,'evictions':21},'history':'The old two JSON sources remain exact historical records. Their non-grid refusal is superseded by the positive white-on-black case here; invalid-value coverage remains in core tests.'}
(P/'opacity-fixtures/full-fixtures.json').write_text(json.dumps(record,indent=2)+'\n')
s=(P/'src/opacity_fixtures.rs').read_text();old=s
s=s.replace('//! and the additive opacity-fixtures/transparent-fixtures.json.','//! and the additive transparent-fixtures.json and full-fixtures.json.')
start=s.index('    {\n        let frame = Frame {\n            width: 1,\n            height: 1,\n            clear: 0x000000,',s.index('name: "zero-scope-suppresses'))
end=s.index('    transparent_literals(&mut cases)?;',start)
block=s[start:end].replace('Command::PushOpacity(0.1)','Command::PushOpacity(f32::from_bits(0x3dcccccd))').replace('rgba: [255, 0, 0, 255]','rgba: [255, 255, 255, 255]')
beg=block.index('        if plan.as_ref()')
block=block[:beg]+'''        let plan = plan?;
        if plan.group_scratch_bytes() != 8 {
            return Err("non-grid literal scratch mismatch".into());
        }
        cases.push(Fixture {
            name: "non-grid-point-one-white-over-black",
            plan,
            expected: vec![0x1a1a1a],
        });
    }
'''
s=s[:start]+block+s[end:]
s=s.replace('    transparent_literals(&mut cases)?;','    transparent_literals(&mut cases)?;\n    full_literals(&mut cases)?;')
lines=['','/// Exact raw binary32 literals, including positive subnormal groups.','fn full_literals(cases: &mut Vec<Fixture>) -> Result<()> {','    let rect = |rgba| Command::Rect { rect: Rect::new(0.0, 0.0, 1.0, 1.0), rgba, radius: 0.0 };','    let descriptions = [']
for case in [{**r,'scratch_bytes':8} for r in held]+nested:
 f=case['frame'];cmds=[]
 for c in case['commands']:
  if c['op']=='push_opacity':cmds.append('Command::PushOpacity(f32::from_bits(0x'+c['f32_bits_hex']+'))')
  elif c['op']=='pop_opacity':cmds.append('Command::PopOpacity')
  else:cmds.append('rect('+str(c['rgba'])+')')
 lines.extend([f'        ("{case["name"]}", Frame::new(1, 1, 0x{f["clear"]}),', '         vec!['+', '.join(cmds)+'],',f'         vec![0x{case["expected_pixels"][0]}], {case["scratch_bytes"]}),'])
lines+=['    ];','    for (name, frame, commands, expected, scratch) in descriptions {','        let plan = plan_with_masks_for_profile(Profile::Native, frame, &commands, &[], &[], &[])?;','        if plan.group_scratch_bytes() != scratch {','            return Err("full-opacity literal scratch mismatch".into());','        }','        cases.push(Fixture { name, plan, expected });','    }','    Ok(())','}','']
s+='\n'.join(lines)
full=old[old.index('pub fn transparent_reuse_fixtures()'):]
full=full.replace('transparent_reuse_fixtures','full_reuse_fixtures').replace('opacity-transparent-reuse','opacity-full-reuse')
for name,bits,rr,rgba,ir,img,row,y,glyph,expected,scratch in reuse:
 marker='"opacity-full-reuse-'+name+'",';a=full.index(marker);b=full.index('        ),',a)
 chunk=full[a:b];parts=chunk.splitlines();parts[2]='            f32::from_bits(0x'+bits+'),';parts[-1]='            ['+', '.join('0x'+x for x in expected)+'],'
 full=full[:a]+'\n'.join(parts)+'\n'+full[b:]
s+='\n/// Raw opacity changes retain the same geometry, inputs and reuse schedule.\n'+full
(P/'src/opacity_fixtures.rs').write_text(s)
p=P/'src/surface_gpu.rs';s=p.read_text();assert 'const MAX_CASES: usize = 17;' in s;p.write_text(s.replace('const MAX_CASES: usize = 17;','const MAX_CASES: usize = 29;'))
p=P/'src/bin/opacity-check.rs';s=p.read_text().replace('cases.len() != 17','cases.len() != 29').replace('frames != 34 || compared != 512','frames != 58 || compared != 608').replace('refusals=1','refusals=0');s=s.replace('        println!(\n            "COMPLETE','        let full = opacity_fixtures::full_reuse_fixtures()?;\n        let full_counts = reuse_gpu::run_opacity(Some(adapter), &full)?;\n        println!(\n            "COMPLETE');s=s.replace('transparent_evictions={} offscreen','transparent_evictions={} full_reuse_frames={} full_reuse_bytes={} full_allocations={} full_reuses={} full_evictions={} offscreen').replace('            transparent_counts.evictions\n','            transparent_counts.evictions,\n            full_counts.frames,\n            full_counts.compared_bytes,\n            full_counts.allocations,\n            full_counts.reuses,\n            full_counts.evictions\n');p.write_text(s)
print('Saved original source, additive literal JSON, Rust fixtures/checker and case cap. No reviewed-code execution.')
