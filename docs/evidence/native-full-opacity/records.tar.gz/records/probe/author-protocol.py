from pathlib import Path
import json, hashlib
P=Path('/tmp/eris-vulkan-full-opacity-1/worktree/tools/vulkan-raster-probe')
data=json.loads((P/'opacity-fixtures/full-fixtures.json').read_text())
new=data['cases'];converted=new[0];tail=new[1:]
for path in ['run_opacity_host.py','test_opacity_host.py']:
 p=P/path;s=p.read_text();indent='    ' if path.startswith('run_') else '        '
 marker=indent+"('zero-scope-suppresses-pixels-and-restores-root', 0, 8),"
 s=s.replace(marker,marker+'\n'+indent+"('non-grid-point-one-white-over-black', 8, 4),")
 marker=indent+"('zero-alpha-image-preserves-root', 8, 8),"
 s=s.replace(marker,marker+'\n'+'\n'.join(indent+f"('{r['name']}', {r['scratch_bytes']}, 4)," for r in tail))
 s=s.replace("('opacity-reuse', 'opacity-transparent-reuse')","('opacity-reuse', 'opacity-transparent-reuse', 'opacity-full-reuse')")
 s=s.replace('literal_frames=34 literal_bytes=512 refusals=1','literal_frames=58 literal_bytes=608 refusals=0')
 s=s.replace("'transparent_reuses=7 transparent_evictions=7 '\n", "'transparent_reuses=7 transparent_evictions=7 '\n"+('                  ' if path.startswith('run_') else '                ')+"'full_reuse_frames=14 full_reuse_bytes=448 full_allocations=7 '\n"+('                  ' if path.startswith('run_') else '                ')+"'full_reuses=7 full_evictions=7 '\n")
 if path.startswith('run_'):
  s=s.replace("EMPTY_SHA256 =", "FULL_SHA256 = '"+hashlib.sha256((P/'opacity-fixtures/full-fixtures.json').read_bytes()).hexdigest()+"'\nEMPTY_SHA256 =")
  s=s.replace('opacity-reuse|opacity-transparent-reuse)', 'opacity-reuse|opacity-transparent-reuse|opacity-full-reuse)')
  s=s.replace('# At most16 adapters are listed by each of3 sessions, plus34 literal,\n    # 2*(8 cancellation+14 reuse) and1 completion records:127 lines.\n    if len(lines) > 128', '# At most16 adapters are listed by each of4 sessions, plus58 literal,\n    # 3*(8 cancellation+14 reuse) and1 completion records:189 lines.\n    if len(lines) > 192')
  s=s.replace('rows[:34]','rows[:58]').replace('rows[34:]','rows[58:]').replace('2 * per_reuse + 1','3 * per_reuse + 1')
  s=s.replace('# both enumerations and every cut, including the transparent corpus.', '# all three enumerations and every cut, including both additive corpora.')
  s=s.replace("'literal_frames': 34, 'literal_bytes': 512, 'literal_cases': 17", "'literal_frames': 58, 'literal_bytes': 608, 'literal_cases': 29")
  s=s.replace("            'planner_refusals': 1", "            'full_reuse_frames': 14, 'full_reuse_bytes': 448,\n            'full_allocations': 7, 'full_reuses': 7, 'full_evictions': 7,\n            'full_cancellation_checkpoints': CANCEL_CHECKPOINTS,\n            'planner_refusals': 0")
  s=s.replace('refusal assertions run before Vulkan; ', '')
  s=s.replace("'opacity-fixtures/transparent-fixtures.json')", "'opacity-fixtures/transparent-fixtures.json', 'opacity-fixtures/full-fixtures.json')")
  marker="        raise ValueError('independent transparent opacity fixture changed')"
  s=s.replace(marker,marker+"\n    if bindings['opacity-fixtures/full-fixtures.json'] != FULL_SHA256:\n        raise ValueError('independent full opacity fixture changed')")
 else:
  s=s.replace("result['transparent_reuse_bytes']), (512, 448, 448)", "result['transparent_reuse_bytes'], result['full_reuse_bytes']), (608, 448, 448, 448)")
  s=s.replace("rows[:36] + rows[37:], rows[:59] + rows[60:],\n                    rows[:58] + rows[81:]", "rows[:60] + rows[61:], rows[:83] + rows[84:],\n                    rows[:106] + rows[107:], rows[:82] + rows[105:],\n                    rows[:105] + rows[128:]")
  s=s.replace("(b'refusals=1', b'refusals=2')", "(b'refusals=0', b'refusals=1')")
  marker="            (b'PASS reuse-opacity-transparent-reuse-a', b'PASS reuse-opacity-reuse-a'),"
  s=s.replace(marker,marker+"\n            (b'full_reuse_frames=14', b'full_reuse_frames=13'),\n            (b'full_reuse_bytes=448', b'full_reuse_bytes=447'),\n            (b'full_allocations=7', b'full_allocations=6'),\n            (b'full_reuses=7', b'full_reuses=6'),\n            (b'full_evictions=7', b'full_evictions=6'),\n            (b'PASS reuse-opacity-full-reuse-a', b'PASS reuse-opacity-transparent-reuse-a'),")
  s=s.replace('test_second_enumeration_cannot_change_device_or_add_unlisted_adapters','test_reuse_enumerations_cannot_change_device_or_add_unlisted_adapters').replace('for index in (35, 58):','for index in (59, 82, 105):')
  s=s.replace('test_three_full_adapter_enumerations_fit','test_four_full_adapter_enumerations_fit').replace('len(full.splitlines()), 127','len(full.splitlines()), 189')
  s=s.replace("result['transparent_reuse_frames']), (34, 14, 14)","result['transparent_reuse_frames'], result['full_reuse_frames']), (58, 14, 14, 14)")
  s=s.replace("b'PASS extra\\nPASS extra\\n', adapters, 15", "b'PASS extra\\nPASS extra\\nPASS extra\\nPASS extra\\n', adapters, 15")
 p.write_text(s)
print('Protocol and negative fixtures authored; no parser/test import or execution.')
