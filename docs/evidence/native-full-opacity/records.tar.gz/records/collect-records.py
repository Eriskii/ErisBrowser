from pathlib import Path
import shutil,json,re,hashlib
C=Path(__file__).resolve().parent;W=C/'worktree'
for source,dest in [('/tmp/eris-full-opacity-arithmetic-1','arithmetic/standalone'),('/tmp/eris-next-opacity-values-assessment-1','assessment'),('/tmp/eris-next-opacity-values-integration-1','integration')]:
 src=Path(source);dst=C/dest;dst.mkdir(parents=True,exist_ok=False)
 for p in src.rglob('*'):
  if p.is_file() and p.suffix in {'.rs','.json','.md','.log','.wgsl'}:
   q=dst/p.relative_to(src);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
for source,dest in [('/tmp/eris-next-opacity-values-proof-review.json','assessment/proof-review.json'),('/tmp/eris-vulkan-transparent-opacity-publication-review.json','transparent-opacity-publication-review.json')]:
 dst=C/dest;assert not dst.exists();shutil.copy2(source,dst)
modules=[('src/graphics/raster_bridge/tests.rs','graphics::raster_bridge::tests::',21),('src/graphics/raster_bridge/text/tests.rs','graphics::raster_bridge::text::tests::',7),('src/graphics/raster_bridge/native/tests.rs','graphics::raster_bridge::native::tests::',25),('src/graphics/raster_bridge/native/opacity_tests.rs','graphics::raster_bridge::native::tests::opacity_tests::',17),('src/graphics/raster_bridge/native/scope_accounting_tests.rs','graphics::raster_bridge::native::tests::scope_accounting_tests::',6)]
expected=set()
for source,prefix,count in modules:
 names=re.findall(r'(?m)^#\[test\]\s*\nfn ([A-Za-z_]\w*)\(', (W/source).read_text());assert len(names)==len(set(names))==count;expected.update(prefix+n for n in names)
log=C/'validation/bridge-188-1.log';found=re.findall(r'(?m)^test (graphics::raster_bridge::\S+) \.\.\. ok$',log.read_text());assert len(found)==76 and set(found)==expected
(C/'validation/discovery.json').write_text(json.dumps({'source':'actual successful filtered bridge test log','log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'distinct_tests':len(found),'expected':sorted(expected),'all_executed_and_passed':True},indent=2)+'\n')
p=W/'docs/vulkan-full-opacity.md';s=p.read_text();needle='The final execution results are recorded with the\n[evidence package](evidence/vulkan-full-opacity.json).';assert needle in s
s=s.replace(needle,'''Rust 1.88 passes 2,153 browser tests with `vulkan-raster`, including the confined
worker checks; 146 GPU-feature and 114 default core tests; seven probe tests;
98 Python host tests; strict Clippy and formatting. The 76 bridge tests include
17 opacity groups. Page and confined-worker witnesses each cover four scenes
before and after a real click. The release browser also builds successfully.

The offscreen checker passes on NVIDIA RTX 4070 SUPER, AMD RADV and llvmpipe.
Each adapter compares 58 literal frames (608 bytes) and three reuse corpora of
14 frames (448 bytes) each, across BGRA8 and RGBA8: **300 frames and 5,856 bytes
in total**. Per adapter, successful frames record 21 allocations, 21 reuse hits
and 21 evictions; 24 separate cancellation checks are excluded from those
allocation counts. All owned child processes exit and are reaped. The offline
case limit grows from17 to29 and the host log-record limit from128 to192 solely
to admit the expanded corpus; renderer limits are unchanged.

The first browser test run exposed a test assumption: removing two empty
opacity markers also changes the status text and hence glyph work. The corrected
assertion subtracts each independently reported text debit, preserving an exact
two-frame-area opacity charge. The original failure and a later module-order
formatting correction are retained in the
[evidence package](evidence/vulkan-full-opacity.json).''')
s=s.replace('all65,536','all 65,536').replace('of30','of 30').replace('patterns:1,966,080','patterns: 1,966,080').replace('performs4,778,616','performs 4,778,616').replace('and2,256,815','and 2,256,815').replace('including262,144','including 262,144').replace('and1,567','and 1,567').replace('earlier17','earlier 17').replace('from17 to29','from 17 to 29').replace('from128 to192','from 128 to 192').replace('within30%','within 30%')
p.write_text(s)
print('Copied independent evidence without name collisions; verified 76 actual bridge test identities; completed documentation counts.')
