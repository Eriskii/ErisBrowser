# Full-f32 opacity integration plan

This is source-only preparation against published `d25c5d407eb398b4819450d719c4aef42377bed6`. No repository source was changed while preparing this plan, and no compiler, test, JavaScript parser, browser, or GPU was run. The implementation checkout is `/tmp/eris-vulkan-full-opacity-1/worktree`. The arithmetic review is separately retained at `/tmp/eris-next-opacity-values-proof-review.json`; acceptance of this integration design does not claim that a future implementation has passed validation.

## Representation and stable grid ABI

Rename the existing u32 `opacity` field of `opacity::Group` and `Parameters` to `opacity_bits`, storing the validated original f32 bits. This adds no field or CPU allocation. A private integer-only classifier recognizes exact partial k/256 values: sign zero, biased exponent E in 119..=126, M=(fraction|2^23), shift=142-E, and all low `shift` significand bits zero; the numerator is M>>shift in 1..=255.

The final four source-parameter words remain `[height, k, 0, 0]` for every existing grid composite. For non-grid partial opacity they become `[height, 0, 1, raw_bits]`. These are words 28..31 of the current 32-word window. Words 0..28, the 128-byte binding window, 256-byte record stride, buffers, and all admission limits stay unchanged. Clear and primitive source metadata remain zero. The explicit route flag uses word 30; word 31 carries bits without a shader float conversion, preserving subnormal identity semantics.

`Draw::opacity_numerator()` returns Some(k) only for grid composites. New `Draw::opacity_bits()` returns Some(bits) for every composite, grid or non-grid, and None for clears/primitives/root draws. Tests must distinguish the two contracts.

## Planning and shader boundary

Remove only `State::push`'s grid refusal. CoordinateState continues complete finite/range/profile/mixed-scope validation. Zero (including negative zero) suppresses as before, one flattens as before, and every strictly positive partial value—including subnormal and <=2^-25—creates and pays for a group whenever its effective bounds are nonempty. Empty/suppressed groups still validate all source commands. Tiny values are an identity only at the final compositing operation, never a planning shortcut. Cropped union, group count, work, scratch, source validation, allocation and failure boundaries remain unchanged.

The shader keeps route 0's old k validation and existing grid computation. Route 1 validates k==0 and raw positive finite bits strictly below 1. Raw alpha=65535 still requires the full-f32 arithmetic; the opaque grid shortcut is not valid there. Root owns the new integer helper, exponent alignment and rounded operations. Tiny <=0x33000000 can skip the final output write after the region/route gates while all CPU/GPU planning and clear/paint/pop records remain present. Unknown flags or inconsistent fields return defensively. No f32 bitcast should be used for the raw subnormal path.

Probe still refuses PushOpacity for every value, including zero and one, before ordinary native handling. No text-profile expansion is implied. The existing primitive integer blending and GPU region ownership/alias guards remain unchanged.

## Browser diagnostics

The current diagnostic counts `opacity_numerator()` results, which would silently omit raw composites. Count all composites through `opacity_bits()` instead. For all-grid plans preserve the exact current line `native opacity prepared: serial=... groups=... scratch_bytes=... opacity_sum=...` and numerator sum. For a plan containing any non-grid composite, emit a distinct `native opacity f32 prepared` line with serial, total groups, scratch bytes and all ordered raw bit values (draw/pop order). Do not present a partial grid numerator sum as the scene opacity.

At most 128 groups follow from the existing 256-command limit. A Display wrapper over the borrowed draw slice can stream the comma-separated eight-hex-digit values into one log call without an additional heap buffer. The frozen grid host parser/fixture remain compatible; a future non-grid window protocol would be explicit, separate work. The benchmark identity already uses original f32 bits and requires no migration.

## Tests and limited migrations

Core, native bridge and Page reference decoders should dispatch on words 30/31: flag 0 validates k in 1..=255 and raw==0 then computes k/256; flag 1 validates k==0 and reconstructs f32 from raw bits. The independent Canvas oracle must perform every original f32 multiplication, inverse, addition, division and final rounding, including tiny inputs; it must not borrow the shader identity optimization. Primitive blending remains integer.

Add complete 255-value grid classification/record preservation, getters for each draw kind, raw route bytes and unchanged binding/stride tests. Check positive tiny group shape, work and scratch equality to an ordinary partial group, rather than only identical output pixels. Test min/max subnormals, min normal, cutoff and neighbors, 0.1, 0.7, previous-one, exact one/zero and invalid inputs. Keep hidden invalid source validation and Probe refusal tests. Add mixed grid/raw/tiny reuse to catch stale parameters without removing either retained grid reuse corpus.

Existing grid-refusal tests require honest migration: core's empty/hidden non-grid rejection becomes successful metadata validation; bridge's unbacked positive/non-grid-refusal group becomes general positive; the browser zoom test's empty .3 scope becomes successful empty preparation while geometry/loading checks remain; probe's last .1 refusal becomes a positive literal. Preserve original test bodies and old literal JSON as history. Existing old pixel literals remain exact. The probe currently has MAX_CASES=17 and a 128-line host cap; derive actual inventory before changing those offline harness bounds. Renderer quotas are never raised to accommodate new fixtures.

Arithmetic test boundaries include R24 discard widths 31/32/33..40 with sticky/carry, alpha normalization across powers of two, inverse ties, root threshold 8421376±1, and separate source/product/sum rounding. The .1 gray232 case yields23 rather than quantized24; .7 gray5 yields4 rather than end-only rational3. Literal expectations and portable integer-vs-f32 checks are distinct from actual GPU coverage.

## Ownership and handoff

Root confirmed layout ownership of `crates/raster-core/src/{opacity.rs,lib.rs,opacity_tests.rs,gpu/group_tests.rs}` plus the narrow browser diagnostic and its tests. Root owns WGSL and all actual execution. HTML owns bridge/Page/probe migrations once assigned; Script owns its standalone arithmetic/verifier preparation. The existing browser zoom expectation must be assigned explicitly to avoid overlap. No other renderer/framework expansion is required.

Before compiler handoff, preserve exact before images, freeze changed source and a ledger of unchanged admission paths, independently review the new arithmetic and ABI, and count new groups/cases. Report actual validation later; this plan contains no new measured performance, correctness or allocation results.
