# Full finite opacity bridge and Page witnesses

Source-only preparation against published d25c5d4. The four owned paths extend the independent direct Canvas f32 packed-plan decoder to the explicit raw-bit ABI. Grid records retain their original numerator and zero reserved words. No shader arithmetic is used as a pixel oracle.

The seventeen bridge groups include three new groups: all eight preheld static literals plus the threshold-minus-one neighbor; raw/raw and grid/raw transparent nesting; and positive-subnormal validation, allocation and refusal costs. The inherited0.1 refusal is deliberately migrated to a positive full-Canvas check. Invalid values and Probe refusals remain. Twelve other old group bodies are byte-exact.

The existing Page and confined-worker groups each retain their three prior scenes and add the new public full-opacity example. Outer opacity changes0.1 to0.7 by real click; inner opacity stays0.7. The same image, rounded shape, text, transparent holes, original graph and IDs are checked. Nine nontext commands, two materialized groups and139904 scratch bytes remain expected. No window/GPU claim is made.

Before images, exact held copies, diffs, literal ledger and source-formatting receipt are retained here. No compiler, tests, renderer or GPU has been run by this author. Counts and pixels are prospective assertions until root validation.
