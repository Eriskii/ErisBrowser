from pathlib import Path
import hashlib,json,os,subprocess,time,sys,shutil
C=Path(__file__).resolve().parent;W=C/'worktree';O=C/'validation';O.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def run(label,args,env=None):
 log=O/(label+'.log');start=time.monotonic()
 with log.open('xb') as f:r=subprocess.run(args,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT,close_fds=True)
 data={'command':args,'exit':r.returncode,'seconds':time.monotonic()-start,'log':log.name,'log_sha256':sha(log)}
 return data,log
mode=sys.argv[1]
if mode=='python':
 data,log=run('probe-python-1',['python3','-m','unittest','discover','-s','tools/vulkan-raster-probe','-p','test_*.py'])
 (O/'probe-python-1.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data));print(log.read_text()[-5000:]);sys.exit(data['exit'])
if mode=='build':
 kind=sys.argv[2];label=kind+'-build-1';binary='eris-browser' if kind=='browser' else 'eris-vulkan-opacity-check'
 manifest='Cargo.toml' if kind=='browser' else 'tools/vulkan-raster-probe/Cargo.toml'
 env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR='/tmp/eris-vulkan-raster-prototype/target-msrv',CARGO_BUILD_JOBS='4')
 paths=[]
 for root in ([W/'src',W/'crates/raster-core'] if kind=='browser' else [W/'crates/raster-core',W/'tools/vulkan-raster-probe']):
  paths += [p for p in root.rglob('*') if p.is_file() and p.suffix in {'.rs','.wgsl'} and not any(x in p.parts for x in ['target','evidence'])]
 paths += [W/'Cargo.toml',W/'Cargo.lock',W/'crates/raster-core/Cargo.toml',W/'crates/raster-core/Cargo.lock']
 if kind!='browser':paths += [W/'tools/vulkan-raster-probe/Cargo.toml',W/'tools/vulkan-raster-probe/Cargo.lock']
 paths=sorted(set(paths));before={str(p.relative_to(W)):sha(p) for p in paths}
 args=['cargo','+1.88.0','build','--locked','--offline','--release','--manifest-path',manifest,'--bin',binary]
 if kind=='browser':args+=['--features','vulkan-raster']
 data,log=run(label,args,env);data['sources']=before;data['sources_unchanged']=before=={str(p.relative_to(W)):sha(p) for p in paths}
 if data['exit']==0:
  dst=C/(binary+'-full-opacity-1');assert not dst.exists();shutil.copy2(Path(env['CARGO_TARGET_DIR'])/'release'/binary,dst);data['binary']={'path':str(dst),'bytes':dst.stat().st_size,'sha256':sha(dst)}
 with (O/(label+'.json')).open('x') as f:json.dump(data,f,indent=2);f.write('\n')
 print(json.dumps({k:v for k,v in data.items() if k!='sources'}));print(log.read_text()[-4000:]);assert data['sources_unchanged'];sys.exit(data['exit'])
if mode=='fmt':
 env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
 data=[]
 for i,manifest in enumerate(['Cargo.toml','crates/raster-core/Cargo.toml','tools/vulkan-raster-probe/Cargo.toml']):
  rec,log=run('fmt-2-'+str(i),['cargo','+1.88.0','fmt','--manifest-path',manifest,'--all','--','--check'],env);data.append(rec);print(log.read_text())
 (O/'fmt-2.json').write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(data));sys.exit(int(any(r['exit'] for r in data)))
