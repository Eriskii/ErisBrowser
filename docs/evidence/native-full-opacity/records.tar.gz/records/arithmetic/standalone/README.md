# Full binary32 opacity arithmetic verifier

This standalone source has not been compiled or executed by its author. Root owns the first build/run. It imports no project code, renderer, shader, GPU API or dependencies. The algorithm is in `integer.rs`; `main.rs` contains an independent staged-binary32 oracle and verifier-only wider arithmetic.

Suggested root-owned build and run, with separate retained logs:

```sh
rustc +1.88.0 --edition=2024 -O -C overflow-checks=yes main.rs -o full-opacity-verifier
./full-opacity-verifier
```

All helpers intended for a direct WGSL port use only `u32`, Boolean logic and a pair of `u32` words. Low-word addition is explicitly wrapping. Left/right shifts have separate zero, below-32, exactly-32, below-64 and at-least-64 branches. R24 examines discarded bits through shift 40, with nearest-even ties and significand carry. `round24_parts` can represent an arbitrary input rounding to mathematical 2^64; reconstructing a pair has the explicit fit precondition proved for valid channel sums. The corpus tests that otherwise-unrepresentable carry without invoking the fitting-only helper outside its domain.

Opacity arrives as raw host binary32 bits. Signed zero is classified as zero; positive finite values below one use either tiny or general arithmetic. One is classified separately because the existing renderer does not create an opacity intermediate for a unit scope. Negative nonzero values, values above one, infinities and NaNs are rejected by this classifier. This standalone program checks that boundary contract; it does not implement scene admission or reinterpret the renderer's existing clamp policy.

For `0 < opacity <= 2^-25`, the proposed optimization is only final-pop identity. The source group must still be planned, validated, allocated and charged in the eventual renderer. Intermediate binary32 channel bits need not equal the destination bits; the tiny branch compares final parent integers and final RGB8 integers instead. General values use the proposal's 2^-48 representation and separate source product, destination product and addition rounding. Each general channel call checks inverse bits, channel bits and the final parent integer; a root call also checks division bits before final RGB8 rounding.

The oracle uses separate non-inlined `f32` division, multiplication, subtraction and addition functions, then the existing positive `round` behavior. It does not call the integer implementation or use an ideal-rational blend as its oracle. Wider `u64`/`u128` and `f64` occur only in the driver for independent product/shift expectations and exactly representable test inputs. The portable module uses none of them.

The fixed coverage schedule is:

| Group | Planned observations |
| --- | ---: |
| Classifier boundaries | 18 |
| Two-word products / additions / directional shifts | 184 / 64 / 272 |
| Scalar nearest-even shifts / R24 cases | 328 / 807 |
| Every alpha 0..65535 at 30 opacity patterns | 1,966,080 inverse pairs |
| Two selected channels per exhaustive pair | 3,932,160 channels, including 1,966,080 roots |
| Targeted channel boundaries | 60,000 channels, including 27,000 roots |
| Root half-threshold and normalization boundaries | 1,567 |
| Deterministic premultiplied samples | 262,144; three channels and one root per sample |
| Frozen static literal cases | 8 RGB pixels / 24 channel and root calls |

Totals asserted by the source are 4,778,616 channel calls and 2,256,815 root calls. These split into 3,453,884 general channel/inverse bit comparisons and 1,324,732 tiny/zero final-channel checks; 1,660,679 general root bit comparisons (including standalone boundaries) and 596,136 tiny/zero final-root checks. Counts describe observations, including deliberate duplicate endpoint values, rather than unique inputs. A successful run prints the actual counters and must equal the fixed expected record. The first mismatch prints its stage and concrete operands, then exits nonzero.

The 30 literal opacity bit patterns include zero, smallest/largest subnormal, smallest normal and its neighbor, the tiny threshold and adjacent values, 2^-24 neighbors, common stored decimals (.001, .002, .01, .05, .1, .2, .3, .7 and .9), an approximation to one third, .5 neighbors, and the two largest values below one. The seeded sample corpus is evenly divided between the complete tiny bit interval and the complete general bit interval. It is deterministic sampling, not exhaustion of every alpha/channel/opacity combination. The root normalization cases intentionally exercise a slightly broader arithmetic range than valid premultiplied scene output; they make no admission claim.

All eight prospective literals are copied as named scalar data from the held assessment. In particular, stored 0.1 over gray 232 must produce 23 instead of nearest-grid 24; stored 0.7 over gray 5 must produce 4 instead of ideal-rational 3. The source-root one-pixel construction is opaque and uses exact `channel8 * 257` conversion. Transparent sources and destinations are exercised by the exhaustive/boundary/sample corpus. No literal is computed by the tested algorithm to generate its expected value.

This verifier establishes no shader execution, renderer admission, GPU performance, device portability or unchanged-resource claim by itself. The held proposal and independent proof supply the algebraic bounds; actual compilation/execution and the eventual shader correspondence remain separate evidence.
