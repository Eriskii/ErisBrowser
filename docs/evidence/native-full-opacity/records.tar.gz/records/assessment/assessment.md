# Exact non-grid opacity values

Source/algebra assessment only. The current transparent `k/256` worktree is an anticipated predecessor undergoing root validation, not an asserted published baseline. No project source, compiler, tests, renderer or GPU was run or changed for this assessment.

**Recommendation:** support every finite binary32 opacity in `[0,1]`, preserving its stored bits. Use an exact final-pop identity for `0 < opacity <= 2^-25`; for larger values, extend staged integer emulation to a `2^-48` fixed scale with two-u32 temporaries. This covers small normals and all subnormals without implementing subnormal shader arithmetic. It requires more integer instructions, not larger buffers, more dispatches or raised limits. This is a constructive proposal, not measured admission.

## Why rounding or a decimal whitelist is the wrong shortcut

The input is the actual `f32` carried by `DrawCommand::PushOpacity`, not its original decimal spelling. CSS parsing stores `f32`; Canvas validates finite `[0,1]`, uses exact zero for suppression and exact one for the no-layer case, and composites other values with separate binary32 operations.

Two one-pixel prospective witnesses:

- Opaque gray232 over black at CSS `0.1` (bits `3dcccccd`) produces gray23. Quantizing to the nearest current grid value, `26/256`, produces gray24.
- Opaque gray5 over black at CSS `0.7` (bits `3f333333`) produces gray4. Stored opacity is `11744051/16777216`; multiplying source channel1285 rounds to899.5, dividing by257 yields3.5 and Canvas rounds to4. Treating the stored opacity as an exact rational and rounding only at the end gives `5*11744051/16777216 < 3.5`, hence3.

Thus even an opaque source needs the multiplication rounding for non-grid opacity. The old opaque-source weighted-sum shortcut is valid for the old grid, not for arbitrary binary32 inputs. A whitelist of `.1`, `.2`, `.3`, `.7` still requires essentially this same arithmetic machinery and does not define all ordinary CSS numeric spellings.

Rust specifies nearest-even for primitive f32 operations and halfway-away for `round`; the current source uses separate operations, not `mul_add`. [Rust f32](https://doc.rust-lang.org/std/primitive.f32.html). GPU float division/rounding cannot supply that portable contract directly. [WGSL numerical accuracy](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#floating-point-accuracy).

## Tiny positive values: exact output identity

Let `t <= 2^-25`, source alpha A, premultiplied channel S and integer destination D all bounded by65535. With R denoting binary32 nearest-even:

```
Q = R(A/65535) <= 1
P = R(Q*t) <= t <= 2^-25
I = R(1-P) = 1
F = R(S*t) <= 65535/2^25 < 1/512
C = R(D+F)
```

At the worst channel magnitude, addition contributes at most `2^-9` rounding error, so `0 <= C-D < 1/256`, far below a final half-integer. Parent rounding therefore returns D. For the root, D=257*d; the subsequent division and its rounding still stay much less than half a unit from integer d. This proves unchanged stored RGBA16 channels and unchanged RGB8 output. It includes the largest subnormal, smallest normal, every smaller positive float, and the exact threshold (`33000000`). Zero-alpha source remains identity independently.

This optimization is only **the final pop write**. Do not treat positive tiny opacity as zero/no-layer during planning: validate descendants, retain scope/coordinate behavior, allocate and charge whatever the admitted nonempty group requires, and keep its clear/paint/pop records under existing limits. Intermediate source calculations may differ from the skipped identity write; the proof concerns the exact externally stored result, not equality of unobserved temporary bits. An empty or genuine zero group keeps its existing behavior.

## Normal non-grid values: preserve every stage

For `2^-25 < t < 1`, decode the raw bits as:

```
E = exponent field                        # 102..126
M_t = 2^23 | fraction                     # 24 bits
r = 150-E                                 # 24..48
t = M_t / 2^r
```

No shader float conversion is needed. A=0 skips the write. For A=65535, Q=1 so P=t exactly. Otherwise reuse the current normalized alpha quotient `M_q * 2^(h-39)`, where h=floor(log2(A)) and `M_q = X + nearest(X/65535)`, X=A<<(23-h).

Form `T=M_q*M_t` (less than2^48), round it to a 24-bit significand U, and retain the rounding shift s (23 or24, including a carried significand). Then:

```
r_p = 39+r-h-s                            # 24..64
P = U / 2^r_p
J = 2^24 - nearest_even(U / 2^(r_p-24))
I = J / 2^24
```

The current inverse-lattice argument still holds: for P<1/2, inverse rounding uses the `2^-24` lattice; for P>=1/2, subtraction is already exact on it. Since U<=2^24, shifts25 and above always round to zero, including the exact halfway case U=2^24 at shift25. Explicitly branch before shifts32 or larger. For the opaque-alpha branch use the same formula directly with U=M_t and r_p=r. Unlike the old grid, J ranges from1 through2^24.

For each source/destination channel, let R24 keep an integer's scale while rounding to24 significant bits:

```
source48 = R24(S*M_t) << (48-r)            # source multiply rounding retained
 dest48 = R24(D*J) << 24                   # destination multiply rounding retained
     V  = R24(source48 + dest48)           # addition rounding retained
     C  = V / 2^48
```

Both products before rescaling need at most40 bits; alpha/opacity multiplication needs48. Two-u32 multiplication using16-bit pieces suffices. Channel values stay below65536, so the valid fixed representation and sum fit64 bits. General R24 now drops up to40 low bits and needs separate below32/equal32/above32 shift-and-sticky cases; the previous17-bit helper must not be reused unchanged. Its significand carry must survive. A rounding carry to2^64 is unreachable under the channel bound and must be documented as a helper precondition, not silently wrapped.

The ideal source-over result is <=65535. Compared with it, the inverse contributes less than `3*65535*2^-25`, and the source multiply, destination multiply and add each contribute at most `2^-9`. Total error is less than `6/512 < 1/64`; final parent rounding cannot exceed65535. Monotone operations preserve premultiplied channel<=alpha. All nonzero values in this branch are normal floats: source channel weighting exceeds2^-25, and the smallest inverse-weighted nonzero destination is2^-24. No NaN, infinity or underflow emulation is needed after the tiny-value branch.

Parent rounding is now `floor((V+2^47)/2^48)`. For root division, normalize C exactly as before; its mantissa threshold8421376 and odd-divisor257 identity are unchanged. Only the fixed-scale exponent changes: with L=bit_length(V), the final root shift is `72 + t_norm - L`, with t_norm8 or9. Preserve the rounded division before final integer rounding and branch on large shifts. Parent/root alpha semantics and each nested pop remain unchanged; no flattening or product of nested opacities is justified.

## Useful scope choice and costs

| Choice | Arithmetic change | Remaining limitation |
| --- | --- | --- |
| Decimal whitelist | Full significand product and source rounding still needed | Other numeric spellings and small values still refuse |
| Every t>=2^-9 | A `2^-32` scale and at most48-bit channel values | Common `.001` and the entire smaller interval still refuse |
| Full finite binary32 `[0,1]` | Tiny-pop identity plus the bounded64-bit construction above | Existing scene/resource limits still apply |

The full range is the useful next increment. Retain the current k/256 fast route if desired, and encode non-grid raw bits in an existing reserved u32 metadata word with an explicit route flag. That preserves existing grid records and the128-byte binding; never overload the old numerator silently. No new storage resources are required. Cropped regions,8 bytes/pixel, clear/composite passes, command/scope/source caps, padded invocation charges, CPU preparation accounting and GPU/readback byte caps remain unchanged. More ALU and register use per non-grid pixel is a real unmeasured cost, so an unchanged dispatch count is not a speed claim.

Before code, extend the independent arithmetic verifier design to cover these new two-word shifts, source multiplication rounding, the inverse threshold, tiny identity, and the1-adjacent input. Derive literals before execution. Preserve current grid tests and the opaque/transparent counterexamples. Selected exhaustive alpha sweeps for decimal and boundary bit patterns plus deterministic bit-pattern samples are useful; they cannot substitute for the full-domain algebra. No implementation or execution is authorized by this assessment itself.
