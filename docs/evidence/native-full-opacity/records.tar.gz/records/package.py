from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
C=Path(__file__).resolve().parent;W=C/'worktree';D=W/'docs/evidence/native-full-opacity'
def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(data):return (json.dumps(data,indent=2)+'\n').encode()
def record(path):return json.loads((C/path).read_text())
checks=['bridge-188-1','native-full-188-2','core-gpu-188-1','core-default-188-1','core-clippy-188-1','native-clippy-188-1','probe-tests-188-1','probe-clippy-188-1']
for name in checks:
 r=record('validation/'+name+'.json');assert r['exit']==0;assert sha((C/'validation'/r['log']).read_bytes())==r['sha256']
for name,total in [('native-full-188-2',2153),('bridge-188-1',76),('core-gpu-188-1',146),('core-default-188-1',114),('probe-tests-188-1',7)]:
 assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',(C/'validation'/(name+'.log')).read_text())))==total
for r in record('validation/fmt-2.json'):assert r['exit']==0
for name in ['probe-python-1','browser-build-1','checker-build-1','offscreen-run-1']:
 r=record('validation/'+name+'.json');assert r['exit']==0
 if 'sources' in r:
  assert r['sources_unchanged'];assert all(sha((W/p).read_bytes())==h for p,h in r['sources'].items())
 assert sha((C/'validation'/Path(r['log']).name).read_bytes())==r['log_sha256']
gpu=record('offscreen-1/host-results.json');assert gpu['success'] and gpu['adapter_count']==3
assert gpu['binary_sha256']==record('validation/checker-build-1.json')['binary']['sha256']
for run in gpu['runs']:
 assert run['returncode']==0 and run['cleanup']['complete'] and run['cleanup']['descendants']==0
 if run['name']=='enumeration':continue
 v=run['validation'];assert (v['literal_frames'],v['literal_bytes'])==(58,608)
 for prefix in ['','transparent_','full_']:
  assert (v[prefix+'reuse_frames'],v[prefix+'reuse_bytes'])==(14,448)
  assert (v[prefix+'allocations'],v[prefix+'reuses'],v[prefix+'evictions'],v[prefix+'cancellation_checkpoints'])==(7,7,7,8)
 assert v['planner_refusals']==0 and not v['acquired_surface']
assert (C/'offscreen-result-review.json').is_file()
D.mkdir(exist_ok=False)
paths=sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()))
paths=[p for p in paths if not p.startswith('docs/evidence/')]
entries={};sources=[]
for p in paths:
 data=(W/p).read_bytes();sources.append({'path':p,'bytes':len(data),'sha256':sha(data)});entries['source/'+p]=data
(C/'final-source.json').write_bytes(encoded(sources))
for p in sorted(C.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(C)
 if rel.parts[0]=='worktree' or '__pycache__' in rel.parts:continue
 if p.suffix not in {'.json','.log','.rs','.wgsl','.md','.py','.diff'}:continue
 entries['records/'+str(rel)]=p.read_bytes()
items=[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(entries.items())]
archive=D/'records.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;tar.addfile(info,io.BytesIO(data))
index={'schema':1,'base_commit':record('base.json')['base_commit'],'archive':{'path':'records.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'files':len(items),'payload_bytes':sum(i['bytes'] for i in items),'members':items}
(D/'index.json').write_bytes(encoded(index))
summary={
 'schema':1,'checkpoint':'Native Vulkan opacity across the finite binary32 range',
 'base_commit':index['base_commit'],
 'scope':'All finite binary32 opacity in [0,1], preserving stored bits and staged Canvas arithmetic. Existing k/256 path retained; positive tiny values retain allocation and charges with exact final-pop identity.',
 'renderer_limits_raised':False,
 'harness_inventory_changes':{'surface_cases':[17,29],'host_records':[128,192]},
 'package':{'path':'native-full-opacity/index.json','sha256':sha((D/'index.json').read_bytes()),'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes']},
 'record_paths':'records/ and source/ members inside the archive; absolute paths identify original local inputs',
 'validation':{'rust':'1.88.0','full_native_tests':2153,'ignored_confinement_tests_included':True,'bridge_groups':76,'opacity_bridge_groups':17,'core_gpu_tests':146,'core_default_tests':114,'probe_tests':7,'probe_python_tests':98,'strict_clippy':['validation/native-clippy-188-1.json','validation/core-clippy-188-1.json','validation/probe-clippy-188-1.json'],'formatting':'validation/fmt-2.json'},
 'arithmetic':{'standalone':'arithmetic/standalone/run-1.json','inverse_pairs':1966080,'selected_opacity_patterns':30,'alpha_values_per_pattern':65536,'channel_checks':4778616,'root_checks':2256815,'root_boundary_checks':1567,'seeded_premultiplied_samples':262144,'held_literals':8,'six_new_core_groups':True,'old_grid_suite_unchanged':True,'all_opacity_channel_combinations_exhausted':False,'domain_argument':'assessment/assessment.md','independent_proof_review':'assessment/proof-review.json','general_intermediate_bits_checked':True,'tiny_final_storage_checked':True},
 'offscreen':{'record':'offscreen-1/host-results.json','review':'offscreen-result-review.json','binary':record('validation/checker-build-1.json')['binary'],'adapters':gpu['runs'][0]['validation']['adapters'],'frames_per_adapter':100,'bytes_per_adapter':1952,'total_frames':300,'total_compared_bytes':5856,'per_adapter':{'literal':[58,608],'opaque_reuse':[14,448],'transparent_reuse':[14,448],'full_reuse':[14,448],'formats':{'BGRA8':53,'RGBA8':47},'successful_allocations':21,'successful_reuses':21,'successful_evictions':21,'separate_cancellation_checks':24},'unique_planner_refusals':0,'acquired_surface':False,'all_owned_children_cleaned_up':True},
 'browser':{'release_build':'validation/browser-build-1.json','binary':record('validation/browser-build-1.json')['binary'],'new_example':'examples/vulkan-full-opacity.html','Page_and_worker_each_test_four_scenes_before_and_after_real_click':True,'new_window_execution':False},
 'retained_failures':[{'record':'validation/native-full-188-1.json','cause':'Test removed two opacity commands, also changing chrome status text and glyph debit.','correction':'layout/correction-1/receipt.json','scope':'Test isolates exact nontext two-frame-area opacity charge; no production change.'},{'record':'validation/fmt-final.json','cause':'Rustfmt requires new test module before gpu module.','correction':'formatting-correction/receipt.json'}],
 'preceding_checkpoint':{'commit':index['base_commit'],'all_nine_CI_jobs_successful':True,'CI':'transparent-opacity-ci.json','publication_review':'transparent-opacity-publication-review.json'},
 'remaining':'Broader native scene admission, complete CSS compositing and web compatibility, production security and Chromium-relative performance remain unfinished.',
 'security_or_performance_claim':False}
(W/'docs/evidence/vulkan-full-opacity.json').write_bytes(encoded(summary))
print(json.dumps({'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes'],'source_paths':len(sources),'summary_sha256':sha((W/'docs/evidence/vulkan-full-opacity.json').read_bytes())}))
