import hashlib,json,os,subprocess,sys,time
from pathlib import Path
A=Path(__file__).resolve().parent;W=A/'worktree';O=A/'validation';O.mkdir(exist_ok=True)
label,version,manifest,features,action,*tail=sys.argv[1:]
env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR='/tmp/eris-vulkan-raster-prototype/target-'+('msrv' if version=='1.88.0' else '198'),CARGO_BUILD_JOBS='4')
env['CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUNNER']='python3 '+str(W/'tools/ci_test_runner.py')
argv=['cargo','+'+version,action,'--locked','--offline','--manifest-path',manifest]
if features!='-':argv+=['--features',features]
argv+=tail
log=O/(label+'.log');start=time.monotonic()
with log.open('xb') as stream:r=subprocess.run(argv,cwd=W,env=env,stdout=stream,stderr=subprocess.STDOUT,close_fds=True)
record={'command':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
with (O/(label+'.json')).open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record),flush=True);print(log.read_text()[-5000:]);raise SystemExit(r.returncode)
