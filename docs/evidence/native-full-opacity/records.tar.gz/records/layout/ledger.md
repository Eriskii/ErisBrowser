# Core full-f32 opacity source ledger

Base: published d25c5d407eb398b4819450d719c4aef42377bed6. This hold contains six layout-owned paths; Root owns group.wgsl and actual validation. Formatting used installed rustfmt1.88 only. No compiler, test, browser or GPU was run by this author.

## Production changes

`opacity::Group` and `Parameters` retain exactly the same field types/order/count; the existing u32 now stores original opacity bits. `grid_numerator` performs only bounded integer operations: biased exponent119..126 gives shift16..23; sign/invalid/zero/unit/subnormal values cannot enter that range. Exact low-bit divisibility yields precisely k1..255. Both getters borrow/copy existing Draw data and allocate nothing.

Composite encoding retains the old 128-byte window and 256-byte stride. Grid words28..31 are `[height,k,0,0]`; non-grid words are `[height,0,1,bits]`. Primitive/Clear source fields and padding remain zero. Word0..28 geometry and destination/source address conventions do not change. Non-grid source bits are not converted through another floating-point representation. `opacity_numerator` is grid-only and `opacity_bits` covers all composites.

The sole admission restriction removed is the k/256 check. CoordinateState's finite/range/profile/mixed stack validation is unchanged and precedes State::push. Zero suppression and unit flattening stay numeric equality decisions. Every other positive partial value retains State's group allocation, saved scope, placeholders, bounds propagation and materialization. Tiny values are never treated as zero by the planner.

No allocation or work limit changes. The group limit remains original command_count/2, mixed scopes32, original commands256, framebuffer1280×1024, work4M and total GPU16MiB. Group capacity admission, pending command vectors and conservative metadata_peak_bytes remain unchanged. Each materialized region contributes width×height×8 scratch and two padded raster work charges for clear/pop; all primitive/source/phase/conversion charges are retained. New per-composite classification is fixed integer work within the existing bounded record loop; this is not a CPU instruction accounting claim. No new CPU scratch surface, GPU buffer, pipeline binding or uniform allocation is introduced.

The browser diagnostic uses two bounded borrowed scans. The first counts every composite and determines whether all are grid; the second only formats ordered bits for a mixed/raw plan. At most command_count/2<=128 composites can be present. No group list/String allocation is introduced by the formatter. The old all-grid diagnostic is byte-identical. The mixed/raw prefix is distinct and does not claim a partial numerator sum is complete.

## Source-only test inventory

Core opacity tests:16→18 declarations. Two new groups cover nine literal root cases (including .1/.7 rounding counterexamples and tiny boundaries), plus tiny nested identity with unchanged work/storage and mixed nested rounding. Existing grid group is replaced with full255 numerator/record/getter coverage and empty/hidden raw admission; finite/range errors stay errors even hidden. Existing exact4M boundary now also uses tiny/raw opacities and one extra primitive refuses; Probe refusal covers raw/subnormal as well. The reference decoder uses separate f32 Canvas stages for every raw value, including tiny, and does not copy the shader shortcut.

GPU group tests:6→7 declarations. New raw ABI group checks complete records differ only in words29..31, all accounting matches grid, and the binding limit remains128 bytes with127 rejected. Existing old-grid literal layout test remains byte-exact.

Browser: one new diagnostic group requires exact old320 numerator line and ordered mixed/tiny bits with both composites counted. The existing zoom group migrates only its empty .3 refusal: successful zero-scratch output, identical .5 plan/stats, independent full Canvas comparison, and exact retained +2 original/lowered commands and +2 framebuffer-area CPU charge against bare input. Malformed geometry and loading refusal checks stay intact.

Four new declaration groups total (2 core +1 GPU +1 browser); the zoom and prior admission groups are changes to existing tests. Expected values remain prospective until Root executes them. No claim of GPU verification is made by these CPU decoders.

## Dependencies and remaining validation

Root's explicit flag shader must retain the old grid route and validate raw metadata, then implement the separately reviewed full-f32 arithmetic. HTML owns independent bridge/Page and probe migrations. Actual compilation, strict lints, full suites, root's arithmetic verifier, probe inventory/parser checks and GPU adapter runs remain Root-owned. This source ledger does not predict their observed counts/results.
