from pathlib import Path
import hashlib,json,difflib
H=Path(__file__).resolve().parent
p=H/'before/src/script/machine.rs';s=p.read_text()
def replace(old,new):
    global s
    assert s.count(old)==1,old[:100]
    s=s.replace(old,new)
replace('mod calls;','mod call_spread;\nmod calls;')
replace('''        arguments: Vec<Value>,
    },
}
enum Output''','''        arguments: Vec<Value>,
    },
    SpreadArguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: call_spread::Arguments,
    },
}
enum Output''')
replace('''                arguments,
                doc,
            )
        }
    }
}

fn start''','''                arguments,
                doc,
            )
        }
        Phase::SpreadArguments { index, function, receiver, mut arguments } => {
            // Scheduling prepaid descriptor read/classification and receipt.
            let incoming = call_spread::receive_prepaid(value(output));
            let (code::Expr::CallSpread(_, items) | code::Expr::NewSpread(_, items)) = unit.expr(id)
            else { unreachable!("spread continuation owner") };
            if matches!(unit.expr(items[index]), code::Expr::SpreadArgument(_)) {
                arguments.spread_received(runtime, incoming, doc)?;
            } else {
                arguments.append_received(runtime, incoming)?;
            }
            spread_arguments_next(runtime, frame, index + 1, function, receiver, arguments, doc)
        }
    }
}

fn start''')
replace('''    let env = frame.env;
    if frame.reference {''','''    let env = frame.env;
    // Markers belong only to an argument-list continuation. Reject malformed
    // internal records before the reference fast path as well as value paths.
    if matches!(unit.expr(id), code::Expr::SpreadArgument(_)) {
        return Err(ScriptError::resource("spread marker outside argument list"));
    }
    if frame.reference {''')
replace('''        code::Expr::New(callee, _) => eval_child(runtime, frame, Phase::Callee, *callee),
        code::Expr::Function''','''        code::Expr::New(callee, _) => eval_child(runtime, frame, Phase::Callee, *callee),
        code::Expr::CallSpread(callee, _) => {
            call_spread::prepay_entry(runtime)?;
            if matches!(unit.expr(*callee), code::Expr::Member(..)) {
                reference_child(runtime, frame, Phase::MemberCallee, *callee)
            } else {
                eval_child(runtime, frame, Phase::Callee, *callee)
            }
        }
        code::Expr::NewSpread(callee, _) => {
            call_spread::prepay_entry(runtime)?;
            eval_child(runtime, frame, Phase::Callee, *callee)
        }
        code::Expr::SpreadArgument(_) => unreachable!("marker rejected before reference routing"),
        code::Expr::Function''')
replace('''    let unit = frame.unit.clone();
    let (code::Expr::Call(_, items) | code::Expr::New(_, items)) = unit.expr(frame.expression)
    else {
        unreachable!()
    };
    let arguments = reserve_values''','''    let unit = frame.unit.clone();
    if matches!(unit.expr(frame.expression), code::Expr::CallSpread(..) | code::Expr::NewSpread(..)) {
        return spread_arguments_next(runtime, frame, 0, function, receiver, call_spread::Arguments::empty_prepaid(), doc);
    }
    let (code::Expr::Call(_, items) | code::Expr::New(_, items)) = unit.expr(frame.expression)
    else {
        unreachable!()
    };
    let arguments = reserve_values''')
replace('''
#[cfg(test)]
mod tests {''','''
fn spread_arguments_next(
    runtime: &mut Runtime,
    frame: ExprFrame,
    index: usize,
    function: Value,
    receiver: Value,
    arguments: call_spread::Arguments,
    doc: &mut Document,
) -> Result<Option<Output>> {
    let unit = frame.unit.clone();
    let (code::Expr::CallSpread(_, items) | code::Expr::NewSpread(_, items)) = unit.expr(frame.expression)
    else { unreachable!("spread continuation owner") };
    if index < items.len() {
        call_spread::prepay_item(runtime)?;
        let item = items[index];
        let expression = match unit.expr(item) {
            code::Expr::SpreadArgument(operand) => *operand,
            _ => item,
        };
        return eval_child(runtime, frame, Phase::SpreadArguments { index, function, receiver, arguments }, expression);
    }
    let arguments = arguments.into_values();
    // Final callability/constructability is checked only after every argument
    // and iterator has completed, using the existing guarded dispatch paths.
    if matches!(unit.expr(frame.expression), code::Expr::NewSpread(..)) {
        return runtime.construct(function, arguments, doc).map(|value| Some(Output::Value(value)));
    }
    let mut frame = frame;
    frame.phase = Phase::Identity;
    push(runtime, Frame::Expression(frame))?;
    enter_frame(runtime, Frame::Call(calls::Frame::new(function, arguments, receiver, false)))?;
    Ok(None)
}

#[cfg(test)]
mod tests {''')
out=H/'raw/src/script/machine.rs';out.write_text(s)
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
files=[]
for p in sorted((H/'raw').rglob('*.rs')):
    r=p.relative_to(H/'raw');before=H/'before'/r
    row={'relative':str(r),'raw':bind(p)}
    if before.exists():
        d=H/'diffs'/str(r).replace('/','__');d.parent.mkdir(exist_ok=True)
        d.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),p.read_text().splitlines(True),fromfile=str(r),tofile=str(r))))
        row.update(before=bind(before),diff=bind(d))
    files.append(row)
(H/'source-ready.json').write_text(json.dumps({'status':'held-before-production-import','files':files,'selection':bind(H.parent/'root/plan-selection-2.json'),'source_before':bind(H.parent/'source-before-production.json'),'scope':'machine routing, streaming collector and test-only thread-scoped reserve probe. No live imports or execution.'},indent=2)+'\n')
print(json.dumps(bind(H/'source-ready.json')))
