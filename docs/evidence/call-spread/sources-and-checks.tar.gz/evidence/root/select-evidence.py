import hashlib,json
from pathlib import Path
T=Path(__file__).resolve().parents[1];W=T/'worktree'
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
validation=json.loads((T/'root/final-validation.json').read_bytes());assert validation['status']=='pass'
for r in ['root/final-source-review.json','root/format-review.json','root/final-validation-review.json','baseline-update/html-review.json']:
    assert 'clear' in json.loads((T/r).read_bytes())['status'],r
artifacts={};excluded={'selection-final.json','publication-verification.json','github-publication.json'}
folders=['plans','resource-selection-1','resource-selection-2','layout-probe-1','tests-integration-1','tests-public-1','tests-public-2','tests-private-1','tests-private-2','tests-review-1','production-machine-1','production-code-1','production-parser-1','baseline-update','unformatted','root','validation']
for folder in folders:
    for p in sorted((T/folder).rglob('*')):
        assert not p.is_symlink(),p
        if not p.is_file() or p.name in excluded:continue
        assert '__pycache__' not in p.parts,p
        artifacts[str(p.relative_to(T))]=bind(p)
for p in sorted(T.iterdir()):
    if p.is_file() and p.suffix in ['.json','.py','.md']:
        artifacts[p.name]=bind(p)
for r in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/call-spread.md','docs/promise-all.md','docs/promise-all-test262.md']:
    artifacts['documentation/'+r]=bind(W/r)
claims={'base':validation['base'],'scope':'Ordinary call/new spread arguments with synchronous iteration, trailing commas and checked logical argument admission; unchanged old paths, limits and bootstrap. Four pinned Promise.all modes newly pass.','validation':validation,'peer':bind(T/'root/final-validation-review.json'),'limitations':'Selected language coverage only. Inherited argument +In grammar gap, array/object spread, classes and broader web standards remain unfinished. No full-web/production-security/native-stack/RSS/Chromium-speed claim.'}
selection={'source_inventory':bind(T/'source2.json'),'artifacts':artifacts,'claims':claims,'max_uncompressed_bytes':128*1024*1024}
(T/'root/selection-final.json').write_text(json.dumps(selection,indent=2)+'\n')
print(json.dumps({'artifacts':len(artifacts),'source_inputs':1236}))
