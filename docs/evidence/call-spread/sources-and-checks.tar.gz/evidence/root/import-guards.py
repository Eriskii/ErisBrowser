import hashlib
import json
import re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
W=A/'worktree'
H=A/'tests-public-2'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(H/'source-ready.json')=='fcc0e6ab6171d47f35fefe974cec35a3bbde93eacdb3c62421a078127c4e67c9'
hold=json.loads((H/'source-ready.json').read_bytes())
for b in hold['files']:
    p=Path(b['path'])
    assert p.stat().st_size==b['bytes'] and sha(p)==b['sha256'],p
parent=json.loads((A/'source-parent-public.json').read_bytes())
for r,h in parent['source_sha256'].items():
    assert sha(W/r)==h,r
registration=json.loads((H/'registration.json').read_bytes())
target=W/registration['target']
prior=json.loads((A/'tests-public-1/registration.json').read_bytes())
assert target.read_bytes()==(H/'before/src/script.rs').read_bytes()+prior['text'].encode()
text=target.read_text()
assert registration['text'] not in text
new=registration['new_file']
assert not (W/new).exists()
raw=Path(registration['new_file_source']['path'])
names=re.findall(r'#\[test\]\s*fn (\w+)\(',raw.read_text())
assert names==hold['rust_test_roster'] and len(names)==3
(W/new).write_bytes(raw.read_bytes())
target.write_text(text+registration['text'])
sources=parent['source_sha256'].copy()
for r in [new,registration['target']]:
    sources[r]=sha(W/r)
out={'base':parent['base'],'scope':'Parent plus frozen18public groups and two Page/worker integrations only; no production change.','source_sha256':sources}
(A/'source-parent-guards.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'source_inputs':len(sources),'public_groups':18,'integration_groups':2}))
