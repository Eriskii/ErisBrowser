"""Source-only lexical preservation check; never imports or executes project code."""
from pathlib import Path
import json, hashlib, re, difflib
BASE=Path('/tmp/eris-call-spread-plan-1')
ROOT=BASE/'worktree'
def sha(data): return hashlib.sha256(data).hexdigest()
def binding(path):
    path=Path(path); data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def lex(s):
    tokens=[]; literals=[]; comments=[]; i=0
    while i<len(s):
        if s[i].isspace(): i+=1; continue
        if s.startswith('//',i):
            j=s.find('\n',i)
            if j<0:j=len(s)
            comments.append(s[i:j]);i=j;continue
        if s.startswith('/*',i):
            j=i+2;depth=1
            while depth:
                if s.startswith('/*',j):depth+=1;j+=2
                elif s.startswith('*/',j):depth-=1;j+=2
                else:j+=1
                assert j<=len(s)
            comments.append(s[i:j]);i=j;continue
        m=re.match(r'(?:br|cr|r)(#*)"',s[i:])
        if m:
            end='"'+m.group(1);j=s.find(end,i+len(m.group(0)));assert j>=0
            j+=len(end);v=s[i:j];tokens.append(v);literals.append(v);i=j;continue
        m=re.match(r'(?:b|c)?"',s[i:])
        if m:
            j=i+len(m.group(0))
            while j<len(s):
                if s[j]=='\\':j+=2
                elif s[j]=='"':j+=1;break
                else:j+=1
            else:raise AssertionError('unterminated string')
            v=s[i:j];tokens.append(v);literals.append(v);i=j;continue
        m=re.match(r"b?'(?:[^'\\\n]|\\(?:x[0-9a-fA-F]{2}|u\{[0-9a-fA-F_]+\}|.))'",s[i:])
        if m:
            v=m.group(0);tokens.append(v);literals.append(v);i+=len(v);continue
        m=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*',s[i:])
        if m:
            v=m.group(0);tokens.append(v);i+=len(v);continue
        tokens.append(s[i]);i+=1
    return tokens,literals,comments
old=json.loads((BASE/'source-unformatted.json').read_text())['source_sha256']
new=json.loads((BASE/'source1.json').read_text())['source_sha256']
assert old.keys()==new.keys() and len(new)==1236
paths=json.loads((BASE/'root/format-paths.json').read_text())
assert set(x['path'] for x in paths)=={p for p in old if old[p]!=new[p]}
for path,h in new.items(): assert sha((ROOT/path).read_bytes())==h,path
rows=[]
for info in paths:
    p=info['path'];a=(BASE/'unformatted'/p).read_bytes();b=(ROOT/p).read_bytes()
    assert sha(a)==old[p]==info['old'];assert sha(b)==new[p]==info['new']
    at,al,ac=lex(a.decode());bt,bl,bc=lex(b.decode())
    assert al==bl,('literal',p)
    assert ac==bc,('comments',p)
    changes=[]
    sm=difflib.SequenceMatcher(None,at,bt,autojunk=False)
    for tag,aa,az,ba,bz in sm.get_opcodes():
        if tag!='equal': changes.append({'tag':tag,'old':at[aa:az],'new':bt[ba:bz],'before':at[max(0,aa-8):aa],'after':at[az:az+8]})
    rows.append({'path':p,'old_sha256':old[p],'new_sha256':new[p],'tokens_before':len(at),'tokens_after':len(bt),'literal_count':len(al),'literal_sequence_sha256':sha(json.dumps(al,ensure_ascii=False).encode()),'comment_count':len(ac),'token_changes':changes,'diff':binding(info['diff'])})
result={'inventory_files':len(new),'format_paths':len(paths),'unchanged_files':len(new)-len(paths),'all_current_hashes_match_source1':True,'all_raw_hashes_match_unformatted_inventory':True,'rows':rows}
out=BASE/'root/format-lexical-observations.json';out.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(binding(out)))
for r in rows:
 print(r['path'],r['literal_count'],'literals',len(r['token_changes']),'token edits')
 for d in r['token_changes']:print(json.dumps(d))
# Narrow, source-read equivalences; do not erase arbitrary braces or sort tokens.
reorders={
 'src/script/code.rs': [('mod records;\n#[cfg(test)]\nmod call_spread_layout_tests;', '#[cfg(test)]\nmod call_spread_layout_tests;\nmod records;')],
 'src/script/machine.rs': [('mod calls;\nmod statements;\n#[cfg(test)]\nmod call_spread_phase_tests;', '#[cfg(test)]\nmod call_spread_phase_tests;\nmod calls;\nmod statements;')],
 'src/script/parser.rs': [('mod driver;\n#[cfg(test)]\nmod call_spread_cut_tests;', '#[cfg(test)]\nmod call_spread_cut_tests;\nmod driver;')],
 'src/script/parser/driver.rs': [('mod expressions;\nmod functions;\nmod statements;\n#[cfg(test)]\nmod call_spread_layout_tests;', '#[cfg(test)]\nmod call_spread_layout_tests;\nmod expressions;\nmod functions;\nmod statements;')],
 'src/script/machine/call_spread.rs': [('#[cfg(test)]\nmod quota_tests;\n#[cfg(test)]\nmod allocation_probe;', '#[cfg(test)]\nmod allocation_probe;\n#[cfg(test)]\nmod quota_tests;')],
 'src/script/code/call_spread_layout_tests.rs': [('use std::mem::size_of;\n#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;', '#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;\nuse std::mem::size_of;')],
 'src/script/machine/call_spread_phase_tests.rs': [('use call_spread::{Arguments, prepay_entry, prepay_item, receive_prepaid};\nuse crate::script::{MAX_STACK_UNITS, MAX_STEPS, parser::Parser, regexp};\nuse std::mem::size_of;\n#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;', 'use crate::script::{MAX_STACK_UNITS, MAX_STEPS, parser::Parser, regexp};\nuse call_spread::{Arguments, prepay_entry, prepay_item, receive_prepaid};\n#[cfg(all(target_arch = "x86_64", target_os = "linux"))]\nuse std::mem::align_of;\nuse std::mem::size_of;')]
}
arm_old='E::NewSpread(head, args) => {\n                Expr::NewSpread(self.expr(head)?, self.expressions(args)?)\n            }'
arm_new='E::NewSpread(head, args) => Expr::NewSpread(self.expr(head)?, self.expressions(args)?),'
comma_total=0
for row in rows:
    p=row['path'];a=(BASE/'unformatted'/p).read_text();b=(ROOT/p).read_text()
    for orig,replacement in reorders.get(p,[]):
        assert a.count(orig)==1,(p,'reorder');a=a.replace(orig,replacement,1)
    if p=='src/script/code.rs':
        assert a.count(arm_old)==1;a=a.replace(arm_old,arm_new,1)
    at,al,ac=lex(a);bt,bl,bc=lex(b)
    edits=[]
    for tag,aa,az,ba,bz in difflib.SequenceMatcher(None,at,bt,autojunk=False).get_opcodes():
        if tag=='equal':continue
        x,y=at[aa:az],bt[ba:bz]
        assert (x==[','] and y==[]) or (x==[] and y==[',']),(p,tag,x,y)
        # Source-read each location: closing lists/calls/structs/match-last-arm,
        # or optional separators after braced match arms. Never singleton tuples.
        trailing=(az<len(at) and at[az] in [')',']','}'])
        block_arm=(aa>0 and at[aa-1]=='}' and az<len(at))
        assert trailing or block_arm,(p,'nonoptional comma',at[aa-8:az+8])
        edits.append({'tag':tag,'before':at[max(0,aa-8):aa],'after':at[az:az+8]})
    assert [t for t in at if t!=',']==[t for t in bt if t!=',']
    assert [t for t in at if t[:1].isdigit()]==[t for t in bt if t[:1].isdigit()]
    comma_total+=len(edits)
    row['approved_optional_comma_changes']=len(edits)
    row['approved_reorder_blocks']=len(reorders.get(p,[]))
    row['approved_single_expression_match_arm_unwrap']=(p=='src/script/code.rs')
# Bind exact held source material, selecting hold2 replacements over hold1.
origin_dirs=['tests-public-1','tests-public-2','tests-integration-1','tests-private-1','tests-private-2','production-parser-1','production-code-1','production-machine-1']
origins={}
for name in origin_dirs:
    for fp in (BASE/name/'raw').rglob('*'):
        if fp.is_file():
            rel=str(fp.relative_to(BASE/name/'raw'))
            if rel in old:origins[rel]=fp
origin_joins=[]
for rel,fp in sorted(origins.items()):
    assert sha(fp.read_bytes())==old[rel],('frozen raw join',rel,fp)
    origin_joins.append({'relative':rel,'held_raw':binding(fp),'unformatted_sha256':old[rel],'formatted_sha256':new[rel]})
# Optional assertion-token literals/integers are protected by complete ordered
# lexical comparison above, not by merely scanning expected-value lines.
public_paths=['src/script/call_spread_tests.rs','src/script/call_spread_guard_tests.rs']
private_paths=[r['path'] for r in rows if '/call_spread_' in r['path'] and r['path'] not in public_paths and r['path'].endswith('_tests.rs')]+['src/script/machine/call_spread/quota_tests.rs']
assert len(set(private_paths))==5
hold_names=['tests-public-1/source-ready.json','tests-public-2/source-ready.json','tests-integration-1/source-ready.json','tests-private-1/source-ready.json','tests-private-2/source-ready.json','tests-private-2/eligibility-addendum.json','production-parser-1/source-ready.json','production-code-1/source-ready.json','production-machine-1/source-ready.json','root/plan-selection-2.json']
review={
 'schema':'eris-call-spread-format-source-review-v1','status':'clear_source_only','findings':[],
 'inventory_bindings':[binding(BASE/'source-unformatted.json'),binding(BASE/'source1.json'),binding(BASE/'root/format-paths.json')],
 'inventory_counts':{'source1':1236,'before_formatting':1236,'format_changed':14,'byte_unchanged':1222,'added_or_removed_by_formatting':0},
 'all_source1_live_hashes_independently_verified':True,
 'format_lexical_observations':binding(BASE/'root/format-lexical-observations.json'),
 'check_source':binding(BASE/'root/format-review-check.py'),
 'held_contracts':[binding(BASE/x) for x in hold_names],
 'held_raw_joins':origin_joins,
 'lexical_method':'A standalone inert Python source scanner preserves each raw/cooked string and character literal as an exact token, handles nested comments, identifiers/numbers and punctuation, and compares ordered streams. Every literal and comment stream is byte-exact. Exact named module/import blocks are reordered explicitly; exactly one single-expression match arm is unwrapped. All remaining token differences are individually enumerated optional commas, source-read in their list/call/struct/match-arm context. No arbitrary brace removal, assertion filtering, whitespace stripping inside literals, or project import/execution.',
 'literal_tokens_unchanged':sum(r['literal_count'] for r in rows),
 'optional_comma_edits':comma_total,
 'sorting':{'module_blocks':5,'use_blocks':2,'review':'All cfg attributes remain attached to the same declaration/import. No macro_use, statement initializer, runtime evaluation or Rust module body order is moved.'},
 'match_arm':'Only code::Lower E::NewSpread changes from a block containing a single tail expression to that same expression plus the required arm comma. No locals, unsafe boundary, statement, temporary binding or side effect is introduced or removed.',
 'test_preservation':{'public_groups':18,'private_groups':26,'integration_groups':2,'total':46,'review':'All selected test raw files join the unformatted inventory exactly; four ABI-qualified private replacements take precedence over hold1. All JS/expected string bytes, integer/fee constants, comparisons, loop rows, frame/guard/refusal assertions, cfg gates and imported symbols survive formatting. Integration fixture/Rust files and worker registration are byte-exact through formatting.'},
 'production_preservation':'Entry8/item6, acquisition/clone/attempt/append and full-buffer heap debits, marker-before-reference handling, reservation order, fail-once scope, ordinary-path dispatch and parser/code semantics remain those of the independently reviewed held files. Formatting adds no work/heap calls, branch, source literal or field.',
 'rows':[{k:v for k,v in r.items() if k!='token_changes'} for r in rows],
 'limits':['Source-format preservation only; no candidate execution or compile claim from this review.','The lexer is an inert preservation aid, not a Rust parser or a substitute for root compilation. Each non-whitespace edit class was source-read.','Inventory scope is the frozen1236 paths; no claim about unrelated untracked files or generated build outputs.'],
 'project_execution':False,'live_edits':False
}
out=BASE/'root/format-review.json';out.write_text(json.dumps(review,indent=2)+'\n')
print('FINAL',json.dumps(binding(out)))
print('JOINED',len(origin_joins),'LITERALS',review['literal_tokens_unchanged'],'COMMAS',comma_total)
