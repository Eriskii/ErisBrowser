import hashlib
import json
from pathlib import Path
A=Path(__file__).resolve().parents[1]
W=A/'worktree'
H=A/'tests-integration-1'
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
hold=json.loads((H/'source-ready.json').read_bytes())
assert sha(H/'source-ready.json')=='36cec7599625a92a4ff66f41aaed5655e4714cf09ff03d77804887ae4f7bdebf'
for b in hold['files']:
    p=Path(b['path'])
    assert p.stat().st_size==b['bytes'] and sha(p)==b['sha256'],p
parent=json.loads((A/'parent-source-2.json').read_bytes())
for r,h in parent['source_sha256'].items():
    assert sha(W/r)==h,r
new={str(p.relative_to(H/'raw')):p for p in (H/'raw').rglob('*') if p.is_file()}
assert len(new)==4
assert all(not (W/r).exists() for r in new)
assert (W/'tests/worker.rs').read_bytes()==(H/'before/tests/worker.rs').read_bytes()
for r,p in new.items():
    (W/r).parent.mkdir(parents=True,exist_ok=True)
    (W/r).write_bytes(p.read_bytes())
(W/'tests/worker.rs').write_bytes((H/'registration/tests/worker.rs').read_bytes())
sources=parent['source_sha256'].copy()
for r in [*new,'tests/worker.rs']:
    sources[r]=sha(W/r)
out={'base':parent['base'],'scope':'Parent plus frozen Page/worker integration tests only; no production change.','source_sha256':sources}
(A/'source-parent-integration.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'source_inputs':len(sources),'new_paths':list(new),'changed_existing':['tests/worker.rs']}))
