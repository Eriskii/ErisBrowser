from pathlib import Path
T=Path(__file__).resolve().parents[1];W=T/'worktree'
def change(path,old,new):
    p=W/path;s=p.read_text();assert s.count(old)==1,(path,old[:80]);p.write_text(s.replace(old,new))
change('README.md','''records 170 passed, 18 failed and 8 unsupported modes out of 196, with all 90
harness controls passing. Its failures include missing call-spread syntax and
the host's final-unhandled-rejection policy.''','''records 174 passed, 14 failed and 8 unsupported modes out of 196, with all 90
harness controls passing. The remaining failures reflect the host's
final-unhandled-rejection policy.

[Spread arguments](docs/call-spread.md) now work in ordinary calls and `new`,
including mixed, multiple and empty spreads and trailing commas. Iterator reads
preserve evaluation order and share the existing resource limits. This closes
four upstream Promise modes; array/object spread and classes remain unfinished.''')
change('docs/COMPATIBILITY.md','''records **170 passed, 18 failed and 8 unsupported modes out of 196**. Four failures
are parse errors at call-spread syntax; fourteen are final-unhandled host-policy
failures. Eight class-bearing modes remain unsupported. All 90 harness controls
pass, and the prior 458-mode selection retains its exact outcomes.''','''records **174 passed, 14 failed and 8 unsupported modes out of 196**. The fourteen
failures are final-unhandled host-policy failures. Eight class-bearing modes
remain unsupported. All 90 harness controls pass, and the prior 458-mode selection
retains its exact outcomes.
[Call and constructor spread arguments](call-spread.md) close the four prior
parse failures. Mixed, multiple and empty spreads preserve iterator ordering,
receiver identity and argument-before-callability semantics within shared limits.
Array/object spread, classes and the inherited unparenthesized argument `in`
grammar gap inside `for` initializers remain unfinished.''')
change('docs/COMPATIBILITY.md','constructors/this/instanceof and basic prototypes,','constructors/this/instanceof and basic prototypes, ordinary call/new spread arguments and trailing commas,')
change('docs/ROADMAP.md','''selection now [records 170 passed, 18 failed and 8 unsupported modes](promise-all-test262.md),
with all 90 harness controls passing. Call-spread syntax, classes and the
distinction between host rejection policy and language conformance remain visible
in this result. The existing 458-mode profile has no regressions.''','''selection now [records 174 passed, 14 failed and 8 unsupported modes](promise-all-test262.md),
with all 90 harness controls passing. [Call/new spread arguments](call-spread.md)
close four prior syntax failures. Classes and the distinction between host
rejection policy and language conformance remain visible in this result.
The existing 458-mode profile has no regressions.''')
change('docs/ROADMAP.md','''1,512 accounted heap bytes, leaving 275 units. Call/new spread syntax is the next
selected language gap; existing Promise failures remain in the upstream baseline.''','''1,512 accounted heap bytes, leaving 275 units. Call/new spread now uses the same
startup allowance and runtime limits. The next parser correction is restoring
the `+In` grammar context inside argument lists nested in a `for` initializer,
while preserving the surrounding `for-in` grammar. Array/object spread remains
separate unfinished work.''')
change('docs/promise-all.md','reports 170 passed, 18 failed and 8 unsupported modes, with all 90 harness controls','reports 174 passed, 14 failed and 8 unsupported modes after [call spread](call-spread.md), with all 90 harness controls')
change('docs/promise-all-test262.md','Eris records **170 passed, 18 failed and 8 unsupported**.','Eris records **174 passed, 14 failed and 8 unsupported** after [call spread](call-spread.md).')
change('docs/promise-all-test262.md','| Passed | 170 |','| Passed | 174 |')
change('docs/promise-all-test262.md','| Parse SyntaxError: call-spread syntax | 4 |\n','')
change('docs/promise-all-test262.md','''The two `invoke-resolve-on-*-every-iteration-of-promise.js` sources reach
unsupported call-spread syntax in `boundPromiseResolve(...args)`, which currently
produces a parse `SyntaxError`. All four modes remain failed. Four class-bearing
sources remain unsupported:''','''The two `invoke-resolve-on-*-every-iteration-of-promise.js` sources now pass in
both modes: `boundPromiseResolve(...args)` executes through the custom engine's
spread argument path. These are the only four changed case records; all 192
other observations and all 90 harness records match the preceding checkpoint.
Four class-bearing sources remain unsupported:''')
change('docs/promise-all-test262.md','''case and policy identities remain unchanged. This checkpoint changes Python
tools, corpus, baseline and CI; it makes no Rust runtime changes. The release
adapter was built from the published `Promise.all` implementation at `5dc150e2`.
No new browser, GPU-device, production-security or Chromium performance claim
follows from this run.''','''case and policy identities remain unchanged. The initial selection checkpoint
changed Python tools, corpus, baseline and CI using a release adapter built from
the published `Promise.all` implementation at `5dc150e2`. The current replay uses
the release adapter recorded by the [call-spread evidence](evidence/call-spread/summary.json).
The baseline changes only the four observed failed-to-passed statuses and the
adapter identity. No GPU-device, production-security or Chromium performance
claim follows from these results.''')
draft=(T/'call-spread-doc-draft.md').read_text()
validation='''All 46 groups pass. Complete suites pass **2,999 tests on Rust 1.88** and
**3,353 with `test262-host,vulkan-raster` on Rust 1.99**, each across 50 result
rows with no failed, ignored or filtered tests. Strict Clippy passes for all
targets in both configurations, and formatting passes. No old tests were migrated.
The page and confined-worker checks compare complete literal pixels and callback
ordering; the optional raster bridge is checked without a GPU-device measurement.

Actual x86_64 Linux sizes match the prospective mirrors: expression records stay
48 bytes, parser expression frames 72, parser transitions 224 and outer execution
frames 184. The new argument phase increases the phase from 88 to 96 bytes and
its expression frame from 120 to 128, without changing the outer frame or its
limit. Runtime sizes stay 1,808 bytes by default and 1,872 with Test262 hosting.
Bootstrap remains 99,725 work units and 1,740,043 accounted heap bytes, leaving
275 work units under the unchanged limit. These measurements are ABI-specific.

The release adapter improves the pinned `Promise.all` selection to **174 passed,
14 failed and 8 unsupported across 196 modes**, with all 90 harness controls
passing. The only four changed observations are the strict/sloppy modes of the
two `invoke-resolve-on-*-every-iteration-of-promise.js` sources, which previously
failed at `boundPromiseResolve(...args)`. All other case and harness records are
unchanged. The older 458-mode profile remains 420 passed, 8 failed and 30
unsupported, with all 74 controls passing and no changed case records.'''
assert draft.count('VALIDATION_PENDING')==1
(W/'docs/call-spread.md').write_text(draft.replace('VALIDATION_PENDING',validation))
print('Updated six documentation paths')
