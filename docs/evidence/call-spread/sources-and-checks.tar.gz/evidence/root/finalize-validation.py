import hashlib,json,re
from collections import Counter
from pathlib import Path
T=Path(__file__).resolve().parents[1];W=T/'worktree'
def read(p):return json.loads(p.read_bytes())
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
source=read(T/'source2.json');built=read(T/'source1.json')
assert len(source['source_sha256'])==1236
for r,h in source['source_sha256'].items():assert bind(W/r)['sha256']==h,r
baseline_path='tests/conformance/test262-promise-all-current.json'
delta=[r for r,h in source['source_sha256'].items() if built['source_sha256'][r]!=h]
assert delta==[baseline_path]
assert bind(T/'baseline-update/before.json')['sha256']==built['source_sha256'][baseline_path]
assert bind(T/'baseline-update/after.json')['sha256']==source['source_sha256'][baseline_path]
peer=read(T/'root/final-source-review.json');assert peer['status']=='clear' and peer['final_source']==bind(T/'source1.json')
checks={}
for p in sorted((T/'validation').glob('*.json')):
    r=read(p);log=T/'validation'/r['log'];assert bind(log)['sha256']==r['sha256']
    expected=101 if p.stem.startswith('parent-') else 0
    assert r['exit']==expected,(p,r['exit'])
    checks[p.stem]={'receipt':bind(p),'log':bind(log),'exit':r['exit']}
pattern=r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
def results(name):
    text=(T/'validation'/f'{name}.log').read_text()
    return text,[(s,*map(int,n)) for s,*n in re.findall(pattern,text,re.M)]
public=read(T/'tests-public-1/source-ready.json')['rust_test_roster']+read(T/'tests-public-2/source-ready.json')['rust_test_roster']
private=[r['name'] for r in read(T/'tests-private-1/roster.json')['rows']]
lib=public+private
integrations=['call_spread_updates_literal_pixels_and_survives_host_callbacks','confined_call_spread_updates_literal_pixels_and_survives_host_callbacks']
assert len(lib)==len(set(lib))==44 and len(public)==18 and len(private)==26
for name,total in [('default-full-1',2999),('host-vulkan-full-1',3353)]:
    text,rows=results(name)
    assert len(rows)==50 and sum(r[1] for r in rows)==total
    assert all(r[0]=='ok' and r[2:]==(0,0,0,0) for r in rows)
    names=[s.rsplit('::',1)[-1] for s in re.findall(r'^test (\S+) \.\.\. ok$',text,re.M)]
    assert len(names)==total
    assert all(names.count(n)==1 for n in lib+integrations)
    checks[name].update(passed=total,result_rows=50,failed=0,ignored=0,filtered=0,new_groups=46)
text,rows=results('focused-spread-1')
assert len(rows)==1 and rows[0][:5]==('ok',44,0,0,0)
assert set(s.rsplit('::',1)[-1] for s in re.findall(r'^test (\S+) \.\.\. ok$',text,re.M))==set(lib)
checks['focused-spread-1'].update(passed=44,roster=lib)
assert read(T/'root/parent-public-baseline.json')['passed']==3
assert read(T/'root/parent-public-baseline.json')['failed']==15
for name,passed,failed in [('parent-public-1',3,12),('parent-public-guards-1',0,3),('parent-integration-page-1',0,1),('parent-integration-worker-1',0,1)]:
    _,rows=results(name);assert len(rows)==1 and rows[0][:5]==('FAILED',passed,failed,0,0)
diag=(T/'validation/startup-diagnostic-1.log').read_text()
assert 'TYPED_ARRAY_BOOTSTRAP remaining=275 allocated=1740043 objects=750 capacity=750 native=299 prototypes=25 globals=212' in diag
binary=read(T/'binary.json');assert bind(Path(binary['path']))=={k:binary[k] for k in ['path','bytes','sha256']}
assert binary['source_inventory']==str(T/'source1.json') and binary['build_receipt']==str(T/'validation/host-release-1.json')
reports={}
for name,baseline,total,guards,counts,improvements in [
    ('promise-all-report.json','test262-promise-all-current.json',196,90,{'passed':174,'failed':14,'unsupported':8},4),
    ('promise-existing-report.json','test262-promise-methods-async-current.json',458,74,{'passed':420,'failed':8,'unsupported':30},0),
]:
    report=read(T/name);old=read(Path('/tmp/eris-node-method-keys-1')/name);base=read(W/'tests/conformance'/baseline)
    assert report['counts']==counts==dict(Counter(c['status'] for c in report['cases']))
    assert report['mode_cases']==len(report['cases'])==total and len({c['id'] for c in report['cases']})==total
    assert len(report['harness_preflight'])==guards and report['harness_preflight_passed']
    assert all(c['verified'] for c in report['harness_preflight']) and report['harness_preflight']==old['harness_preflight']
    assert not report['regressions'] and len(report['improvements'])==improvements
    assert report['binary_sha256']==binary['sha256']
    assert base['cases']=={c['id']:{k:c[k] for k in ['status','case_sha256','source_sha256']} for c in report['cases']}
    changes=[]
    for a,b in zip(old['cases'],report['cases'],strict=True):
        assert all(a[k]==b[k] for k in ['id','source_sha256','case_sha256'])
        if a!=b:
            assert a['status']=='failed' and b['status']=='passed';changes.append(b['id'])
    assert changes==report['improvements']
    for key in ['revision','corpus_manifest_sha256','runner_policy_sha256']:
        assert report[key]==old[key]==base[key]
    reports[name]={'report':bind(T/name),'baseline':bind(W/'tests/conformance'/baseline),'counts':counts,'mode_cases':total,'verified_controls':guards,'changed_observations':changes,'unchanged_case_records':total-len(changes),'all_harness_records_exact_parent':True,'regressions':0}
out={'status':'pass','base':source['base'],'source_inventory':bind(T/'source2.json'),'build_test_source':bind(T/'source1.json'),'source_inputs':1236,'post_build_delta':'Only four observed failed-to-passed Promise.all baseline statuses and release binary identity; Rust/test/tool/corpus bytes unchanged.','source_peer':bind(T/'root/final-source-review.json'),'baseline_update':bind(T/'baseline-update/source-ready.json'),'format_peer':bind(T/'root/format-review.json'),'checks':checks,'new_groups':{'public':18,'private':26,'integration':2,'total':46},'old_test_migrations':0,'startup':{'raw_work':99725,'remaining_work':275,'accounted_heap':1740043,'objects':750,'capacity':750,'natives':299,'prototypes':25,'globals':212,'change':0},'actual_shapes':{'qualification':'x86_64 Linux; default Rust1.88 and host+Vulkan Rust1.99','expression':48,'parser_expression_frame':72,'parser_transition':224,'phase':96,'expression_frame':128,'outer_execution_frame':184,'runtime_default':1808,'runtime_host':1872,'frame_limit':45590},'binary':binary,'replays':reports,'parent_baselines':{'public':bind(T/'root/parent-public-baseline.json'),'integration':bind(T/'root/parent-integration-baseline.json'),'private_eligibility':bind(T/'tests-private-2/eligibility-addendum.json')},'limitations':['Selected ordinary call/new spread only; array/object spread, classes, async iteration and other ECMAScript gaps remain.','Inherited +In grammar gap inside for initializers remains explicitly queued.','No new full Python-suite or GPU-device run; unchanged tool/corpus bytes.','No native-stack/RSS/Chromium-performance or full-web-compatibility/production-security claim.']}
(T/'root/final-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'pass','source_inputs':1236,'default':2999,'host_vulkan':3353,'new_groups':46,'promise_all':reports['promise-all-report.json']['counts']}))
