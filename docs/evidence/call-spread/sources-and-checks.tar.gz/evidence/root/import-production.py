import hashlib,json
from pathlib import Path
T=Path(__file__).resolve().parents[1];W=T/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
inv=json.loads((T/'source-before-production.json').read_text())
for r,h in inv['source_sha256'].items():assert sha(W/r)==h,r
holds=[('production-machine-1','eb8195c26bead6dc39b4d3fa85cc61df58a95f7cd870d265777e6b8ce4f720de'),('production-code-1','31bf36a778a704dd2e3503b2da20312322260e2cab43aaae1a164c0bdc283018'),('production-parser-1','01cefd9b2e0d70db230a4c4f130c0d315f4b39fa1784fc801d5c7426b0fdb395')]
selected=[]
for name,h in holds:
    path=T/name/'source-ready.json';assert sha(path)==h
    hold=json.loads(path.read_text())
    records=hold.get('files',hold.get('changes',hold.get('owned_files')))
    expected={m['relative']:m['raw'] for m in records}
    for raw in sorted((T/name/'raw').rglob('*.rs')):
        r=str(raw.relative_to(T/name/'raw'));before=T/name/'before'/r
        assert bind(raw)==expected[r],r
        if before.exists():assert sha(W/r)==sha(before),r
        else:assert not (W/r).exists(),r
        selected.append((r,raw))
assert len({r for r,p in selected})==8
# All preconditions are checked before the first production write.
for r,p in selected:
    (W/r).parent.mkdir(parents=True,exist_ok=True);(W/r).write_bytes(p.read_bytes())
    inv['source_sha256'][r]=sha(W/r)
inv['scope']='Selected call/new spread implementation and46 frozen groups, before formatting; no execution yet.'
(T/'source-unformatted.json').write_text(json.dumps(inv,indent=2)+'\n')
snapshot=T/'unformatted'
base=json.loads((T/'parent-source-2.json').read_text())['source_sha256']
for r in inv['source_sha256']:
    # Retain new/modified Rust for independent formatting-token comparison.
    if r.endswith('.rs') and base.get(r)!=inv['source_sha256'][r]:
        p=snapshot/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/r).read_bytes())
(T/'root/production-import.json').write_text(json.dumps({'holds':[bind(T/n/'source-ready.json') for n,h in holds],'paths':[{'relative':r,'raw':bind(p)} for r,p in selected],'source':bind(T/'source-unformatted.json')},indent=2)+'\n')
print(json.dumps({'source_inputs':len(inv['source_sha256']),'production_paths':len(selected)}))
