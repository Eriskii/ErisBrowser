//! Inert prospective layout measurement only; no runtime implementation.
//! Complete parent definitions retain field/variant order. Proposed deltas are
//! enumerated in source-map.json. Nonconstructed mirrors intentionally have
//! dead variants/fields; this allowance is confined to this test-only module.
#![allow(dead_code)]
use super::*;
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "CALL_SPREAD_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn baseline<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}

pub(super) enum BaselineExpr {
    Literal(Value),
    RegExp(Rc<RegExp>),
    Ident(String),
    NewTarget,
    Array(Vec<Option<ExprId>>),
    Object(Vec<(PropertyName, ObjectEntry)>),
    Unary(String, ExprId),
    BinaryChain(ExprId, Vec<(String, ExprId)>),
    Conditional(ExprId, ExprId, ExprId),
    Assign(String, ExprId, ExprId),
    Update(ExprId, f64, bool),
    Member(ExprId, ExprId),
    Call(ExprId, Vec<ExprId>),
    New(ExprId, Vec<ExprId>),
    Function(FunctionId),
    Sequence(Vec<ExprId>),
    Template(JsString, Vec<(ExprId, JsString)>),
}

pub(super) enum ProposedExpr {
    Literal(Value),
    RegExp(Rc<RegExp>),
    Ident(String),
    NewTarget,
    Array(Vec<Option<ExprId>>),
    Object(Vec<(PropertyName, ObjectEntry)>),
    Unary(String, ExprId),
    BinaryChain(ExprId, Vec<(String, ExprId)>),
    Conditional(ExprId, ExprId, ExprId),
    Assign(String, ExprId, ExprId),
    Update(ExprId, f64, bool),
    Member(ExprId, ExprId),
    Call(ExprId, Vec<ExprId>),
    New(ExprId, Vec<ExprId>),
    CallSpread(ExprId, Vec<ExprId>),
    NewSpread(ExprId, Vec<ExprId>),
    SpreadArgument(ExprId),
    Function(FunctionId),
    Sequence(Vec<ExprId>),
    Template(JsString, Vec<(ExprId, JsString)>),
}

#[test]
fn prospective_call_spread_layout_code() {
    baseline::<Expr, BaselineExpr>();
    pair::<Expr, ProposedExpr>("code.Expr");
    pair::<ExprId, ExprId>("code.ExprId");
    pair::<Vec<ExprId>, Vec<ExprId>>("code.argument_vector");
    pair::<PropertyName, PropertyName>("code.PropertyName");
    pair::<ObjectEntry, ObjectEntry>("code.ObjectEntry");
    println!(
        "CALL_SPREAD_DERIVED_V1 name=code.expression_page current={} proposed={}",
        128 * size_of::<Expr>() + 32,
        128 * size_of::<ProposedExpr>() + 32
    );
}
