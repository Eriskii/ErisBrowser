//! Inert prospective layout measurement only; no runtime implementation.
//! Complete parent definitions retain field/variant order. Proposed deltas are
//! enumerated in source-map.json. Nonconstructed mirrors intentionally have
//! dead variants/fields; this allowance is confined to this test-only module.
#![allow(dead_code)]
use super::*;
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "CALL_SPREAD_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn baseline<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}

struct Arguments {
    values: Vec<Value>,
    admitted_capacity: usize,
}

enum BaselinePhase {
    Start,
    ReferenceObject,
    ReferenceKey(Value),
    Unary,
    Delete,
    BinaryHead,
    BinaryRight {
        index: usize,
        left: Value,
    },
    Conditional,
    Identity,
    Sequence(usize),
    Array {
        index: usize,
        values: Vec<Value>,
        holes: BTreeSet<usize>,
    },
    ObjectKey {
        index: usize,
        object: Value,
    },
    ObjectValue {
        index: usize,
        object: Value,
        key: PropertyKey,
    },
    ObjectPrototype {
        index: usize,
        object: Value,
    },
    Template {
        index: usize,
        output: Vec<u16>,
    },
    AssignReference,
    AssignValue {
        reference: Reference,
        old: Option<Value>,
        logical: bool,
    },
    Update,
    Callee,
    MemberCallee,
    Arguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: Vec<Value>,
    },
}

enum ProposedPhase {
    Start,
    ReferenceObject,
    ReferenceKey(Value),
    Unary,
    Delete,
    BinaryHead,
    BinaryRight {
        index: usize,
        left: Value,
    },
    Conditional,
    Identity,
    Sequence(usize),
    Array {
        index: usize,
        values: Vec<Value>,
        holes: BTreeSet<usize>,
    },
    ObjectKey {
        index: usize,
        object: Value,
    },
    ObjectValue {
        index: usize,
        object: Value,
        key: PropertyKey,
    },
    ObjectPrototype {
        index: usize,
        object: Value,
    },
    Template {
        index: usize,
        output: Vec<u16>,
    },
    AssignReference,
    AssignValue {
        reference: Reference,
        old: Option<Value>,
        logical: bool,
    },
    Update,
    Callee,
    MemberCallee,
    Arguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: Vec<Value>,
    },
    SpreadArguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: Arguments,
    },
}

pub(super) struct BaselineExprFrame {
    unit: Rc<code::Unit>,
    expression: code::ExprId,
    env: usize,
    reference: bool,
    phase: BaselinePhase,
}

pub(super) struct ProposedExprFrame {
    unit: Rc<code::Unit>,
    expression: code::ExprId,
    env: usize,
    reference: bool,
    phase: ProposedPhase,
}

pub(super) enum BaselineFrame {
    Expression(BaselineExprFrame),
    Statement(statements::Frame),
    Call(calls::Frame),
}

pub(super) enum ProposedFrame {
    Expression(ProposedExprFrame),
    Statement(statements::Frame),
    Call(calls::Frame),
}

#[test]
fn prospective_call_spread_layout_machine() {
    baseline::<Phase, BaselinePhase>();
    baseline::<ExprFrame, BaselineExprFrame>();
    baseline::<Frame, BaselineFrame>();
    assert_eq!(MAX_FRAMES, MAX_HEAP / size_of::<Frame>());
    pair::<Phase, ProposedPhase>("machine.Phase");
    pair::<ExprFrame, ProposedExprFrame>("machine.ExprFrame");
    pair::<Frame, ProposedFrame>("machine.Frame");
    pair::<statements::Frame, statements::Frame>("machine.statements.Frame");
    pair::<calls::Frame, calls::Frame>("machine.calls.Frame");
    pair::<Value, Value>("Value");
    pair::<Vec<Value>, Vec<Value>>("argument_values_vector");
    pair::<Reference, Reference>("Reference");
    pair::<PropertyKey, PropertyKey>("PropertyKey");
    pair::<Runtime, Runtime>("Runtime_unchanged_field_roster");
    pair::<Vec<Frame>, Vec<ProposedFrame>>("Runtime.frames_vector_header");
    println!(
        "CALL_SPREAD_NEW_LAYOUT_V1 name=Arguments size={} align={}",
        size_of::<Arguments>(),
        align_of::<Arguments>()
    );
    println!(
        "CALL_SPREAD_DERIVED_V1 name=machine.initial_frames current={} proposed={}",
        INITIAL_FRAMES * size_of::<Frame>() + 32,
        INITIAL_FRAMES * size_of::<ProposedFrame>() + 32
    );
    println!(
        "CALL_SPREAD_DERIVED_V1 name=machine.max_frames current={} proposed={}",
        MAX_FRAMES,
        MAX_HEAP / size_of::<ProposedFrame>()
    );
}
