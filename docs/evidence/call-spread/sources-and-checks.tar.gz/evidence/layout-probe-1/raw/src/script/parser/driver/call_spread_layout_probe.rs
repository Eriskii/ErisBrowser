//! Inert prospective layout measurement only; no runtime implementation.
//! Complete parent definitions retain field/variant order. Proposed deltas are
//! enumerated in source-map.json. Nonconstructed mirrors intentionally have
//! dead variants/fields; this allowance is confined to this test-only module.
#![allow(dead_code)]
use super::*;
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "CALL_SPREAD_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn baseline<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}
use super::expressions::{Array, Binary, Cover, NewState, Object, Postfix};

pub(super) enum BaselineParserFrame {
    Assignment,
    AssignmentHead,
    ConditionalYes(ExprId),
    ConditionalNo(ExprId, ExprId),
    AssignmentRight(String, ExprId),
    Sequence,
    SequenceHead,
    SequenceNext(Vec<ExprId>),
    Binary(u8),
    BinaryHead(u8),
    BinaryRight(Binary, &'static str),
    Unary,
    Prefix(&'static str),
    PrefixUpdate(f64),
    Base(bool),
    PostfixResume(Postfix),
    Computed(Postfix),
    Arguments(Postfix, Vec<ExprId>),
    New,
    NewHead,
    NewComputed(NewState),
    NewArguments(ExprId, Vec<ExprId>),
    Primary,
    CoverItem(Cover, bool),
    ArrayItem(Array),
    ObjectKey(Object, bool, bool),
    AccessorKey(Object, bool),
    ObjectFunction(Object, PropertyName, Option<bool>),
    ObjectValue(Object, PropertyName, bool),
    NamedFunction(Option<String>),
    Key,
    ComputedKey(bool),
    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
    Pass,
}

pub(super) enum ProposedParserFrame {
    Assignment,
    AssignmentHead,
    ConditionalYes(ExprId),
    ConditionalNo(ExprId, ExprId),
    AssignmentRight(String, ExprId),
    Sequence,
    SequenceHead,
    SequenceNext(Vec<ExprId>),
    Binary(u8),
    BinaryHead(u8),
    BinaryRight(Binary, &'static str),
    Unary,
    Prefix(&'static str),
    PrefixUpdate(f64),
    Base(bool),
    PostfixResume(Postfix),
    Computed(Postfix),
    Arguments(Postfix, Vec<ExprId>, bool, bool),
    New,
    NewHead,
    NewComputed(NewState),
    NewArguments(ExprId, Vec<ExprId>, bool, bool),
    Primary,
    CoverItem(Cover, bool),
    ArrayItem(Array),
    ObjectKey(Object, bool, bool),
    AccessorKey(Object, bool),
    ObjectFunction(Object, PropertyName, Option<bool>),
    ObjectValue(Object, PropertyName, bool),
    NamedFunction(Option<String>),
    Key,
    ComputedKey(bool),
    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
    Pass,
}

enum BaselineKind {
    Expression(BaselineParserFrame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
}

enum ProposedKind {
    Expression(ProposedParserFrame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
}

enum BaselineTransition {
    Done(Output),
    Again(BaselineKind),
    Child(BaselineKind, BaselineKind),
}

enum ProposedTransition {
    Done(Output),
    Again(ProposedKind),
    Child(ProposedKind, ProposedKind),
}

#[test]
fn prospective_call_spread_layout_parser() {
    baseline::<expressions::Frame, BaselineParserFrame>();
    baseline::<Kind, BaselineKind>();
    baseline::<Transition, BaselineTransition>();
    pair::<expressions::Frame, ProposedParserFrame>("parser.expressions.Frame");
    pair::<Kind, ProposedKind>("parser.driver.Kind");
    pair::<Transition, ProposedTransition>("parser.driver.Transition");
    pair::<Output, Output>("parser.driver.Output");
    pair::<Binary, Binary>("parser.expressions.Binary");
    pair::<Postfix, Postfix>("parser.expressions.Postfix");
    pair::<NewState, NewState>("parser.expressions.NewState");
    pair::<Cover, Cover>("parser.expressions.Cover");
    pair::<Array, Array>("parser.expressions.Array");
    pair::<Object, Object>("parser.expressions.Object");
    println!(
        "CALL_SPREAD_DERIVED_V1 name=parser.initial_kind_buffer current={} proposed={}",
        4 * size_of::<Kind>() + 32,
        4 * size_of::<ProposedKind>() + 32
    );
    println!(
        "CALL_SPREAD_DERIVED_V1 name=parser.kind_heap_ceiling current={} proposed={}",
        MAX_HEAP / size_of::<Kind>(),
        MAX_HEAP / size_of::<ProposedKind>()
    );
}
