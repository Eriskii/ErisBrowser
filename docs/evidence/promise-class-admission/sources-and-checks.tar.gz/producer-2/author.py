import ast, difflib, hashlib, json
from pathlib import Path
P=Path(__file__).resolve().parent; H=P.parent; O=H/'producer-1'; rel=Path('tools/test262_conformance.py')
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(p,x):put(p,json.dumps(x,indent=2)+'\n')
a=(O/'raw'/rel).read_text();before=(O/'before'/rel).read_text()
old="or any(type(value) is not str for value in edge) or edge[1] != key[1] for edge in required)"
new="or any(type(value) is not str for value in edge)\n                    or (len(ordered) > count and edge[1] != key[1]) for edge in required)"
assert a.count(old)==1
b=a.replace(old,new);ast.parse(b)
assert b.replace(new,old)==a
put(P/'before'/rel,before);put(P/'raw'/rel,b)
put(P/'correction.diff',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='producer-1/'+str(rel),tofile='producer-2/'+str(rel))))
put(P/'diffs'/(str(rel)+'.diff'),''.join(difflib.unified_diff(before.splitlines(True),b.splitlines(True),fromfile='a/'+str(rel),tofile='b/'+str(rel))))
chunks=json.loads((O/'chunks.json').read_text());n=0
for c in chunks:
 if old in c['after']:c['after']=c['after'].replace(old,new);n+=1
assert n==1
rebuilt=before
for c in chunks:
 assert rebuilt.count(c['before'])==1
 rebuilt=rebuilt.replace(c['before'],c['after'])
assert rebuilt==b
js(P/'chunks.json',chunks)
fn=lambda s:{n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
f0,f1=fn(before),fn(b);preserved=[n for n in f0 if n!='main'];assert len(preserved)==73 and all(f0[n]==f1[n] for n in preserved)
js(P/'correction.json',{'status':'source-only additive correction; unexecuted','finding':'Legacy withResolvers semantic prerequisites intentionally include both modes. Same-mode restriction applies only to the new class suffix.','predicate':'ordered already includes current row; len(ordered) > count means the current row is new. Canonical old edge equality, existence, duplicate and cycle checks remain unchanged.','preserved_old_functions':preserved,'inverse_exact':True,'original_hold':binding(O/'source-ready.json'),'controls':binding(H/'control-contract-1/source-ready.json'),'no_literal_or_expectation_change':True,'project_execution':False})
files=[p for p in P.rglob('*') if p.is_file() and p.name!='source-ready.json']
js(P/'source-ready.json',{'status':'source-ready additive correction; unexecuted','base':'315300e6324fd4232fa53cb8d6a5b46a2c906dc5','supersedes_payload_only':binding(O/'source-ready.json'),'files':[binding(p) for p in sorted(files)],'interfaces':binding(O/'interfaces.json'),'controls':binding(H/'control-contract-1/source-ready.json'),'project_execution':False,'live_edits':False})
print(json.dumps(binding(P/'source-ready.json')))
