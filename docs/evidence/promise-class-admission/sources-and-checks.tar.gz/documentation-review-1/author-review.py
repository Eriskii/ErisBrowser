from pathlib import Path,PurePosixPath
from collections import Counter
import hashlib,json,re,difflib,subprocess,posixpath
H=Path('/tmp/eris-promise-class-admission-plan-1');D=H/'documentation-2';O=Path(__file__).resolve().parent;W=H/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p):return json.loads(Path(p).read_bytes())
def bound_read(r):
 assert bind(Path(r['path']))==r
 return read(r['path'])
seal=read(D/'source-ready.json')
for r in seal['files']:assert bind(Path(r['path']))==r
ledger=bound_read(seal['final_validation']);assert ledger['status']=='pass'
source=bound_read(seal['source_inventory']);assert ledger['source_inventory']==seal['source_inventory']
assert len(source['source_sha256'])==1840
paths=seal['paths'];assert set(paths)=={'README.md','docs/ROADMAP.md','docs/VALIDATION.md','docs/classes.md','docs/promise-class-admission.md'}
assert {str(p.relative_to(D/'raw')) for p in (D/'raw').rglob('*') if p.is_file()}==set(paths)
doc_checks=[]
for rel in paths:
 before=D/'before'/rel;old=before.read_bytes() if before.exists() else b'';new=(D/'raw'/rel).read_bytes()
 if before.exists():assert subprocess.check_output(['git','show',seal['base']+':'+rel],cwd=W)==old
 else:
  probe=subprocess.run(['git','cat-file','-e',seal['base']+':'+rel],cwd=W,capture_output=True);assert probe.returncode!=0
 diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 assert diff==(D/'diffs'/(rel+'.diff')).read_text()
 doc_checks.append(dict(path=rel,before=bind(before) if before.exists() else None,after=bind(D/'raw'/rel),diff=bind(D/'diffs'/(rel+'.diff')),published_before_join=True))
for rel in ['docs/VALIDATION.md','docs/classes.md']:
 old=(D/'before'/rel).read_bytes();new=(D/'raw'/rel).read_bytes();body=old.split(b'\n',1)[1]
 assert new.endswith(body),rel
 # Exactly one insertion after heading; entire prior body remains contiguous.
 assert new.count(body)==1
parent=read(H/'root/profile-parent-1.json');candidate=read(H/'root/profile-candidate-1.json');gates=read(H/'root/baseline-gates-1.json')
assert parent['status']==candidate['status']==gates['status']=='pass'
reports={};bindings=[];counts=Counter();changes=[];controls=0;old_controls=0
for p,c,g in zip(parent['profiles'],candidate['profiles'],gates['profiles']):
 assert p['profile']==c['profile']==g['profile']
 old=bound_read(p['report']);new=bound_read(c['report']);gate=bound_read(g['report'])
 for row in [p,c,g]:
  receipt=bound_read(row['receipt']);assert bind(Path(row['log']['path']))==row['log']
  assert receipt['sha256']==row['log']['sha256']
  bindings.extend([row['report'],row['receipt'],row['log']])
 assert g['exit']==0 and bound_read(g['receipt'])['exit']==0 and not g['errors']
 assert {k:v for k,v in gate.items() if k!='seconds'}=={k:v for k,v in new.items() if k!='seconds'}
 assert gate['regressions']==gate['improvements']==[]
 assert new['harness_preflight_passed'] is True and all(x['verified'] is True for x in new['harness_preflight'])
 assert new['harness_preflight'][:len(old['harness_preflight'])]==old['harness_preflight']
 controls+=len(new['harness_preflight']);old_controls+=len(old['harness_preflight'])
 assert len(new['cases'])==len(old['cases'])
 actual=Counter(x['status'] for x in new['cases']);assert actual==Counter(new['counts']);counts.update(actual)
 for a,b in zip(old['cases'],new['cases']):
  assert all(a[k]==b[k] for k in ['id','file','mode','case_sha256','source_sha256','expected_negative'])
  assert not(a['status']=='passed' and b['status']!='passed')
  if a!=b:changes.append(dict(profile=c['profile'],before=a,after=b))
 reports[c['profile']]=new
assert controls==724 and old_controls==640 and counts==Counter(passed=1258,failed=64,unsupported=8)
assert len(changes)==40 and Counter(x['after']['status'] for x in changes)==Counter(passed=36,failed=4)
assert all(x['before']['status']=='unsupported' for x in changes)
failed=[x for x in changes if x['after']['status']=='failed']
assert {x['after']['file'] for x in failed}=={'test/built-ins/Promise/reject/ctx-ctor.js','test/built-ins/Promise/any/ctx-ctor.js'}
for x in failed:
 obs=x['after']['observation'];assert obs['status']=='host-failure' and obs['message']=='unhandled-rejection' and obs['completion']['unhandled']==1
assert Counter(x.get('reason') for r in reports.values() for x in r['cases'] if x['status']=='unsupported')==Counter({'unimplemented declared features: cross-realm':4,'unimplemented declared features: destructuring-binding':4})
chapter=(D/'raw/docs/promise-class-admission.md').read_text()
labels={'Promise methods':'promise-methods-async','Promise.all':'promise-all','Promise.race':'promise-race','Promise.allSettled':'promise-all-settled','Promise.any':'promise-any','Promise.withResolvers':'promise-with-resolvers','Promise.try':'promise-try','AggregateError, unchanged':'aggregate-error'}
for line in chapter.splitlines():
 if not line.startswith('| '):continue
 parts=[s.strip() for s in line.strip('|').split('|')]
 if parts[0] not in labels:continue
 r=reports[labels[parts[0]]];expected=[len(r['cases']),r['counts'].get('passed',0),r['counts'].get('failed',0),r['counts'].get('unsupported',0),len(r['harness_preflight'])]
 assert [int(x) for x in parts[1:]]==expected
py_records={};rosters={}
for label,number,exitcode in [('parent-python-1',683,0),('candidate-python-1',696,1),('candidate-python-2',696,0),('parent-class-controls-1',13,1),('candidate-class-controls-1',13,0)]:
 rp=H/'validation'/(label+'.json');r=read(rp);lp=H/'validation'/r['log'];text=lp.read_text()
 assert r['exit']==exitcode and sha(lp.read_bytes())==r['sha256']
 assert re.findall(r'^Ran (\d+) tests in .+$',text,re.M)==[str(number)]
 ids=re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. (?:ok|FAIL|ERROR|skipped)',text,re.M)
 assert len(ids)==len(set(ids))==number
 rosters[label]=set(ids);py_records[label]=dict(receipt=bind(rp),log=bind(lp),tests=number,exit=exitcode)
 assert '... skipped' not in text
assert rosters['parent-python-1']<rosters['candidate-python-2']
assert rosters['candidate-python-2']-rosters['parent-python-1']==rosters['candidate-class-controls-1']
assert (H/'validation/candidate-python-1.log').read_text().rstrip().endswith('FAILED (failures=1)')
assert (H/'validation/parent-class-controls-1.log').read_text().rstrip().endswith('FAILED (failures=12)')
assert (H/'validation/candidate-python-2.log').read_text().rstrip().endswith('OK')
updates=read(H/'root/baseline-update-1.json');assert updates['status']=='pass' and len(updates['written'])==7
baseline_counts=Counter()
for row in updates['written']:
 before=bound_read(row['before']);after=bound_read(row['after']);profile=read(H/'baseline-update-1/contract.json')['projections'][row['path']]['profile'];r=reports[profile]
 projected=dict(revision=r['revision'],corpus_manifest_sha256=r['corpus_manifest_sha256'],runner_policy_sha256=r['runner_policy_sha256'],binary_sha256=r['binary_sha256'],cases={x['id']:{k:x[k] for k in ['status','case_sha256','source_sha256']} for x in r['cases']})
 assert after==projected
 for k,a in before['cases'].items():
  b=after['cases'][k]
  if a['status']!=b['status']:baseline_counts[a['status']+'->'+b['status']]+=1
assert baseline_counts==Counter({'unsupported->passed':56,'unsupported->failed':14})
source2=read(H/'source-candidate-2.json')['source_sha256'];final=source['source_sha256'];parent_source=read(H/'source-parent.json')['source_sha256']
assert source2.keys()==final.keys()
assert sorted(k for k in final if final[k]!=source2[k])==sorted(r['path'] for r in updates['written'])
overlay=read(H/'root/workflow-overlay-1.json');assert overlay['paths']==['.github/workflows/check.yml'] and overlay['to']==seal['base']
assert sha(subprocess.check_output(['git','show',seal['base']+':.github/workflows/check.yml'],cwd=W))==overlay['new_workflow_sha256']==final['.github/workflows/check.yml']
comparison_parent=dict(parent_source);comparison_parent['.github/workflows/check.yml']=overlay['new_workflow_sha256']
changed=sorted(k for k,v in final.items() if comparison_parent.get(k)!=v);assert changed==ledger['changed_source_test_baseline_paths'] and len(changed)==25
for k,v in parent_source.items():
 if k.startswith(('src/','crates/','assets/','shaders/')) or k in ('Cargo.toml','Cargo.lock','build.rs'):assert final.get(k)==v
# Only newly added links, including the two future packaging outputs, are in this bounded check.
links=[]
for rel in paths:
 old=(D/'before'/rel).read_text() if (D/'before'/rel).exists() else ''
 new=(D/'raw'/rel).read_text();old_links=set(re.findall(r'\]\(([^)]+)\)',old))
 for link in sorted(set(re.findall(r'\]\(([^)]+)\)',new))-old_links):
  if '://' in link or link.startswith('#'):continue
  target=posixpath.normpath(str(PurePosixPath(rel).parent/link.split('#')[0]))
  future=target in ['docs/evidence/promise-class-admission/manifest.json','docs/evidence/promise-class-admission/sources-and-checks.tar.gz']
  assert future or (D/'raw'/target).exists() or (W/target).exists(),(rel,link)
  links.append(dict(document=rel,target=link,resolved=target,future_packaging_output=future))
assert not any(re.search(r'\b(TODO|TBD|PLACEHOLDER)\b',(D/'raw'/p).read_text()) for p in ['docs/promise-class-admission.md'])
review=dict(status='clear',scope='Independent source/documentation and actual-report peer of final five-document hold; no project execution or live edits.',documentation_hold=bind(D/'source-ready.json'),final_validation=seal['final_validation'],source_inventory=seal['source_inventory'],published_workflow_overlay=bind(H/'root/workflow-overlay-1.json'),docs=doc_checks,actual=dict(profiles=8,modes=1330,selected_modes=1280,counts=dict(counts),healthy_controls=724,old_control_records_exact=640,new_controls=84,changed_class_modes=40,new_passes=36,new_host_audit_failures=4,prior_pass_regressions=0,python_parent=683,python_final=696,python_new=13,baseline_writes=7,baseline_gate_exits=[0]*8,cumulative_baseline_transitions=dict(baseline_counts)),python=py_records,baseline_update=bind(H/'root/baseline-update-1.json'),baseline_gates=bind(H/'root/baseline-gates-1.json'),raw_report_receipt_log_bindings=bindings,checks=['All five docs and sixteen held payload/author/check bindings match the seal.','Four published-before byte joins at4538e99a and all five exact unified diffs independently reconstructed.','Entire historical VALIDATION and classes chapter bodies remain byte-exact as contiguous suffixes.','Every profile table cell, complete parent/candidate case/control arrays, new failure identities and eight fresh gate reports independently reconciled. Only elapsed seconds differ between measured/gated reports.','Complete verbose Python rosters retain683 parent identities plus13 new IDs; first full695/1 failure and parent controls1/12 failure remain accurately qualified.','Seven compact baselines equal exact report projections;70 cumulative status changes preserve56 passes/14 reached failures, with40 belonging to this admission and30 carried from runtime.','Sourcefinal1840 inputs changes25 selected source/test/baseline paths relative to published4538e99a after the explicitly bound workflow-only overlay from315300. Only seven baseline files differ from Python-tested source2. Selected runtime/build hashes remain exact.','New links resolve to held/current docs or the two explicitly future evidence outputs.'],links=links,qualifications=['Full Python696 was run on source2 before baseline recording; the subsequent seven compact baseline mutations were verified by eight fresh baseline gates.','Adapters were rebuilt/frozen before parent/candidate and reused byte-exact; no new full Rust suite or GPU result claimed.','Scope is bounded profiles/selected inventory, not full Test262/web compatibility or a full build graph; no security audit or Chromium-relative performance claim.','Packaging outputs are pending root execution, not claimed to exist by this review.','Inert peer checks initially assumed a policy hash uniquely identified a profile and that the original parent inventory already included the workflow-only4538e99a fast-forward. Those checks stopped before sealing. Exact baseline-path joins and the retained workflow overlay now resolve both; no document, report or producer bytes changed.','Reviewer authored the held baseline recipe and previous migration/source peers; documentation was independently authored, and numerical claims were re-derived from retained actual reports/logs here.'],findings=[],project_execution=False,live_edits=False)
with (O/'review.json').open('x') as f:json.dump(review,f,indent=2);f.write('\n')
print(json.dumps(bind(O/'review.json')))
