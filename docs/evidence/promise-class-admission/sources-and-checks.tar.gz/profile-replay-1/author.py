"""Stdlib-only construction of a held replay contract; no project import or execution."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path

P=Path(__file__).resolve().parent;H=P.parent;W=H/'worktree';F=Path('/tmp/eris-class-runtime-plan-1');R=Path('/tmp/eris-promise-class-admission-readiness-1')
def sha(b):return hashlib.sha256(b).hexdigest()
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(p.read_bytes())
def dump(p,x):
 with p.open('x') as f:json.dump(x,f,indent=2);f.write('\n')
identity_keys=('id','file','mode','case_sha256','source_sha256','expected_negative')
identity=lambda c:{k:c[k] for k in identity_keys}
policies=load(H/'migration-plan-1/policies.json');policy_by={p['profile']:p for p in policies['profiles']}
changed={p['profile'] for p in policies['profiles'] if p['changed']}
assert len(changed)==7
for p in policies['profiles']:
 a,b=p['before'].copy(),p['after'].copy()
 assert sha(json.dumps(a,sort_keys=True).encode())==p['before_sha256']
 assert sha(json.dumps(b,sort_keys=True).encode())==p['after_sha256']
 if p['changed']:
  assert set(b['supported_features'])-set(a['supported_features'])=={'class'}
  assert not set(a['supported_features'])-set(b['supported_features'])
  a.pop('supported_features');b.pop('supported_features');assert a==b
 else:assert a==b
census=load(R/'census.json');census_by={p['profile']:p for p in census['profiles']}
new=load(H/'control-contract-1/cases.json');prefix=load(H/'control-contract-1/old-prefix-identities.json');prefix_by={p['profile']:p for p in prefix}
assert len(new)==84 and sum(p['count'] for p in prefix)==588
# Independently recompute all new fingerprints directly from frozen source/helper metadata.
for c in new:
 assert sha(c['source'].encode())==c['source_sha256']
 frozen=dict(source_sha256=c['source_sha256'],mode=c['mode'],metadata=c['metadata'],harness=c['harness'])
 if 'completion_policy' in c:frozen['completion_policy']=c['completion_policy']
 assert sha(json.dumps(frozen,sort_keys=True,ensure_ascii=True).encode())==c['case_sha256']
 for helper in c['harness']:
  p=W/'tests/upstream'/('test262-'+c['profile'])/'harness'/helper['name']
  assert sha(p.read_bytes())==helper['sha256']
 assert all(ref['mode']==c['mode'] for ref in c['prerequisites'])
profiles=[];trees={};bindings=[]
for prior in load(F/'profile-replay-1/contract.json')['profiles']:
 name,profile=prior['name'],prior['profile'];rp=F/('upstream-'+name+'-1.json');r=load(rp)
 bindings.append(bound(rp))
 pp=policy_by[profile];assert r['runner_policy']==pp['before'] and r['runner_policy_sha256']==pp['before_sha256']
 ids=[identity(c) for c in r['cases']]
 old=[dict(name=c['name'],expected=c['expected'],**identity(c['result']),prerequisites=c['prerequisites']) for c in r['harness_preflight']]
 if profile in census_by:
  cp=census_by[profile];assert cp['candidate_report']==bound(rp)
  ci=[dict(id=c['id'],file=c['file'],mode=c['mode'],case_sha256=c['case_sha256'],source_sha256=c['source_sha256'],expected_negative=c['metadata']['negative']) for c in cp['cases']]
  assert ci==ids
  assert old==prefix_by[profile]['ordered_rows']
  tagged=[c['id'] for c in cp['cases'] if c['class_tagged']]
 else:assert profile=='aggregate-error';tagged=[]
 rel='tests/upstream/test262-'+profile;directory=W/rel
 manifest=load(directory/'manifest.json')
 assert sha((directory/'manifest.json').read_bytes())==r['corpus_manifest_sha256']
 for file in manifest['files']:
  data=(directory/file['path']).read_bytes();assert len(data)==file['bytes'] and sha(data)==file['sha256']
 trees[rel]={str(p.relative_to(W)):sha(p.read_bytes()) for p in sorted(directory.rglob('*')) if p.is_file()}
 suffix=[c for c in new if c['profile']==profile]
 assert len(suffix)==(12 if profile in changed else 0)
 profiles.append(dict(name=name,profile=profile,binary_kind=prior['binary_kind'],reference_report=bound(rp),
                      cases=len(ids),controls=len(old),case_identities=ids,old_control_identities=old,
                      new_controls=suffix,class_case_ids=tagged,policy=pp))
assert sum(p['cases'] for p in profiles)==1330
assert sum(p['cases'] for p in profiles if p['profile'] in changed)==1280
assert sum(p['controls'] for p in profiles)==640
assert sum(len(p['new_controls']) for p in profiles)==84
assert sum(len(p['class_case_ids']) for p in profiles)==40
# Preserve every existing baseline byte, rather than only the eight replay baselines.
rel='tests/conformance';trees[rel]={str(p.relative_to(W)):sha(p.read_bytes()) for p in sorted((W/rel).rglob('*')) if p.is_file()}
for p in [H/'source-parent.json',H/'migration-plan-1/policies.json',H/'control-contract-1/source-ready.json',H/'control-contract-1/cases.json',H/'control-contract-1/old-prefix-identities.json',H/'gate-design-1/helper-pins.json',H/'producer-2/source-ready.json',H/'producer-2/raw/tools/test262_conformance.py',H/'producer-1/before/tools/test262_conformance.py',R/'census.json',H/'run-tool.py',H/'root/freeze-binary.py',H/'root/run-config-2.py']:
 bindings.append(bound(p))
contract=dict(status='held source-derived replay contract; no execution',base='315300e6324fd4232fa53cb8d6a5b46a2c906dc5',
              source_parent=bound(H/'source-parent.json'),bindings=bindings,
              runner_sha256=dict(parent=sha((H/'producer-1/before/tools/test262_conformance.py').read_bytes()),candidate=sha((H/'producer-2/raw/tools/test262_conformance.py').read_bytes())),
              profiles=profiles,preserved_trees=trees,preserved_files=[],
              totals=dict(profiles=8,cases=1330,selected_cases=1280,unselected_cases=50,old_controls=640,new_controls=84,candidate_controls=724,class_tagged_modes=40),
              commands=['python3 -B profile-replay-1/replay.py parent --attempt 1','python3 -B profile-replay-1/replay.py candidate --attempt 1 --parent-attempt 1 --source-inventory /absolute/path/to/candidate-inventory.json'],
              result_policy=['Serial jobs=1, timeout=3.0, all eight profiles attempted even after a report failure.',
                             'No --baseline or --record-baseline. Exit 1 is expected for healthy inventories containing failed/unsupported rows.',
                             'Bad source/binary/corpus bindings stop dispatch immediately. Measurement errors retain output and continue.',
                             'Complete ordered identities, full 640 old control rows and all 84 new raw schema/fingerprint/prerequisite/classification records checked.',
                             'No old passed case may regress. Nonpass-to-failed and raw-only changes remain explicit full before/after records.',
                             'AggregateError policy/cases/control rows stay exact. Seven other policies add only class.',
                             'Parent inventory315 remains immutable. Candidate may name later workflow-only base overlay in its own inventory; runtime/build inputs stay exact.'])
dump(P/'contract.json',contract)
ast.parse((P/'replay.py').read_text())
checks=dict(status='stdlib source checks only',new_fingerprints_recomputed=84,old_control_identities_joined=640,census_case_identities_joined=1280,additional_aggregate_cases=50,
            policies_changed=sorted(changed),other_policies_unchanged=len(policies['profiles'])-7,
            baseline_files=len(trees['tests/conformance']),preserved_corpus_files=sum(len(v) for k,v in trees.items() if k!='tests/conformance'),
            runner_ast_valid=True,project_execution=False,live_edits=False)
dump(P/'author-checks.json',checks)
dump(P/'source-ready.json',dict(status='source-ready held runner/checker; unexecuted',files=[bound(P/n) for n in ('author.py','replay.py','contract.json','author-checks.json')],
                               parent_controls=640,candidate_controls=724,cases=1330,baseline_writes=False,project_execution=False,live_edits=False))
print(json.dumps(bound(P/'source-ready.json')))
