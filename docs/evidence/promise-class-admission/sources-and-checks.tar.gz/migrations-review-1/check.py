"""Independent source/hash/AST audit. Never imports or executes project code."""
import ast, collections, copy, difflib, hashlib, json, pathlib, re, subprocess
H=pathlib.Path('/tmp/eris-promise-class-admission-plan-1'); W=H/'worktree'; O=H/'migrations-review-1'
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
selected={'promise-methods-async','promise-all','promise-race','promise-all-settled','promise-any','promise-with-resolvers','promise-try'}
def sha(b): return hashlib.sha256(b).hexdigest()
def read(r): return json.loads((H/r).read_bytes())
def bind(p):
 b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=sha(b))
def git(p): return subprocess.check_output(['git','show',BASE+':'+p],cwd=W)
def dump(n): return ast.dump(n,include_attributes=False)
validated={}
def bindings(d):
 if isinstance(d,dict):
  if {'path','bytes','sha256'} <= d.keys() and str(d['path']).startswith('/'):
   p=pathlib.Path(d['path']); assert bind(p)=={k:d[k] for k in ('path','bytes','sha256')},d['path'];validated[str(p)]=d['sha256']
  for v in d.values(): bindings(v)
 elif isinstance(d,list):
  for v in d:bindings(v)
m=read('migrations-1/source-ready.json');plan=read('migration-plan-1/source-ready.json')
assert m['base']==plan['base']==BASE
bindings(m);bindings(plan)
edits=read('migrations-1/edits.json')['edits']; assert len(edits)==46
file_checks=[]; raws={}; before_trees={}; raw_trees={}; changed=[]; unchanged=[]
def methods(t):
 return {c.name+'.'+n.name:n for c in t.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
def assigns(t):
 return {x.id:dump(n.value) for n in t.body if isinstance(n,ast.Assign) for x in n.targets if isinstance(x,ast.Name)}
def calls(t):
 return collections.Counter(dump(n) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'run_case','unsupported_reason'})
for p in m['payloads']:
 rel=p['path']; a=pathlib.Path(p['before']['path']).read_bytes(); b=pathlib.Path(p['raw']['path']).read_bytes(); assert git(rel)==a
 s=a.decode(); z=b.decode(); e=[x for x in edits if x['path']==rel]; reconstructed=s
 for x in e:
  assert reconstructed.count(x['before'])==x['count'],(rel,'forward count'); reconstructed=reconstructed.replace(x['before'],x['after'])
 assert reconstructed==z
 for x in reversed(e):
  assert reconstructed.count(x['after'])==x['count'],(rel,'inverse count'); reconstructed=reconstructed.replace(x['after'],x['before'])
 assert reconstructed==s
 assert ''.join(difflib.unified_diff(s.splitlines(True),z.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))==pathlib.Path(p['diff']['path']).read_text()
 at,bt=ast.parse(s),ast.parse(z);before_trees[rel]=at;raw_trees[rel]=bt;raws[rel]=b
 def signatures(node,prefix=''):
  result={}
  for x in getattr(node,'body',[]):
   if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef)):
    name=prefix+x.name
    if not isinstance(x,ast.ClassDef):result[name]=dump(x.args)
    result.update(signatures(x,name+'.'))
  return result
 old_sig,new_sig=signatures(at),signatures(bt);assert all(new_sig[k]==v for k,v in old_sig.items())
 am,bm=methods(at),methods(bt);assert set(am)==set(bm) and len(am)==p['retained_groups']
 for k in am:
  assert dump(am[k].args)==dump(bm[k].args)
  target=unchanged if dump(am[k])==dump(bm[k]) else changed;target.append(pathlib.Path(rel).stem+'.'+k)
 aa,ba=assigns(at),assigns(bt);assert all(ba[k]==v for k,v in aa.items())
 assert set(ba)-set(aa)==({'CLASS_ADMISSION_PROFILES'} if rel.endswith('/test_test262_promise_runner.py') else set())
 ah={n.name:ast.get_source_segment(s,n) for n in at.body if isinstance(n,ast.FunctionDef)};bh={n.name:ast.get_source_segment(z,n) for n in bt.body if isinstance(n,ast.FunctionDef)}
 assert all(bh[k]==v for k,v in ah.items())
 assert set(bh)-set(ah)==({'class_admitted_features','class_admitted_policy'} if rel.endswith('/test_test262_promise_runner.py') else set())
 ac,bc=calls(at),calls(bt);assert not ac-bc
 extra=bc-ac
 if rel.endswith('/test_test262_promise_runner.py'):
  assert extra==collections.Counter({dump(ast.parse('runner.unsupported_reason(case, runner.PROFILE_FEATURES[PROFILE], PROFILE)',mode='eval').body):1})
 else: assert not extra
 # Byte/string values containing script punctuation or syntax must remain exact.
 def scripts(t):
  return collections.Counter(n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,(str,bytes)) and any(w in (n.value.decode(errors='replace') if isinstance(n.value,bytes) else n.value) for w in ['/*---','function ','throw ','class ',';']))
 assert scripts(at)==scripts(bt)
 file_checks.append(dict(path=rel,before_sha256=sha(a),after_sha256=sha(b),edits=len(e),groups=len(am),old_assignments=len(aa),old_helpers=len(ah),old_caller_sites=sum(ac.values()),additive_current_eligibility_calls=sum(extra.values()),exact_inverse=True))
assert len(file_checks)==15 and len(changed)==28 and len(unchanged)==88
# Reconstruct all published test IDs, using Git bytes rather than the working candidate.
r=read('migration-plan-1/python-roster.json'); ids=[]; after_ids=[]; modules=[]
for mod in r['modules']:
 if not mod['top_level_discovery']:continue
 rel=mod['path'];b=git(rel);assert len(b)==mod['bytes'] and sha(b)==mod['sha256']
 a=methods(ast.parse(b));z=methods(ast.parse(raws.get(rel,b)));assert set(a)==set(z)
 ids += [pathlib.Path(rel).stem+'.'+k for k in a];after_ids += [pathlib.Path(rel).stem+'.'+k for k in z];modules.append(rel)
assert len(modules)==68 and len(ids)==len(set(ids))==683 and set(ids)==set(after_ids)==set(r['retained_actual_ids'])
p=read('migrations-1/parent-roster-binding.json');bindings(p)
observed=re.findall(r'^test_\S+ \((test_[^)]+)\) \.\.\. ok$',pathlib.Path(p['log']['path']).read_text(),re.M)
assert len(observed)==len(set(observed))==683 and set(observed)==set(ids)==set(p['actual_unique_group_ids'])
# Evaluate only inert literal/name/set expression nodes from published module assignments.
s=git('tools/test262_conformance.py').decode(); t=ast.parse(s); env={}
def literal(n):
 if isinstance(n,ast.Constant):return n.value
 if isinstance(n,ast.Name):return env[n.id]
 if isinstance(n,ast.Set):return {literal(x) for x in n.elts}
 if isinstance(n,(ast.List,ast.Tuple)):return [literal(x) for x in n.elts]
 if isinstance(n,ast.Dict):return {literal(k):literal(v) for k,v in zip(n.keys,n.values)}
 if isinstance(n,ast.BinOp) and isinstance(n.op,ast.BitOr):return literal(n.left)|literal(n.right)
 if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='copy' and not n.args and not n.keywords:return copy.copy(literal(n.func.value))
 raise ValueError(type(n).__name__)
for n in t.body:
 if isinstance(n,ast.Assign):
  try:v=literal(n.value)
  except (ValueError,KeyError,TypeError):continue
  for x in n.targets:
   if isinstance(x,ast.Name):env[x.id]=v
   elif isinstance(x,ast.Subscript) and isinstance(x.value,ast.Name) and x.value.id=='PROFILE_FEATURES':env['PROFILE_FEATURES'][literal(x.slice)]=v
 elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call):
  q=n.value
  if isinstance(q.func,ast.Attribute) and isinstance(q.func.value,ast.Name) and q.func.value.id=='PROMISE_HOST_PROFILES' and q.func.attr=='add':env['PROMISE_HOST_PROFILES'].add(literal(q.args[0]))
pol=read('migration-plan-1/policies.json');assert set(env['PROFILE_FEATURES'])=={q['profile'] for q in pol['profiles']} and len(pol['profiles'])==61
assert sorted(env['SUPPORTED_FEATURES'])==pol['generic_default']
policy_checks=[]
for q in pol['profiles']:
 name=q['profile']; errors=set(env['INTRINSIC_ERRORS'])|({'AggregateError'} if name in {'aggregate-error','promise-any'} else set())
 expected=dict(format=2,supported_features=sorted(env['PROFILE_FEATURES'][name]),negative_intrinsic_errors=sorted(errors),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if name in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:expected['excluded_harness']=['resizableArrayBufferUtils.js']
 if name in env['PROMISE_HOST_PROFILES']:expected.update(format=3,async_completion=True,host_hooks=True,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
 assert expected==q['before'],name
 after=copy.deepcopy(expected)
 if name in selected:after['supported_features']=sorted(set(after['supported_features'])|{'class'})
 assert after==q['after'] and q['changed']==(name in selected)
 for k in ['before','after']:assert sha(json.dumps(q[k],sort_keys=True).encode())==q[k+'_sha256']
 policy_checks.append(dict(profile=name,changed=name in selected,before_sha256=q['before_sha256'],after_sha256=q['after_sha256']))
# All retained historical JSON blobs are Git-exact in the census; none belongs to this payload.
historical=[]
for rel,key in [('migration-plan-1/historical-oracles.json','oracles'),('migration-plan-1/conformance-json-preservation.json','files')]:
 for q in read(rel)[key]:
  b=git(q['path']);assert sha(b)==q['sha256'] and len(b)==q['bytes'];assert q['path'] not in raws
  historical.append(dict(path=q['path'],bytes=len(b),sha256=sha(b)))
contexts=read('migration-plan-1/reviewed-contexts.json');caller_checks=[];fixture_checks=[]
for q in contexts['contexts']:
 assert sha(q['source'].encode())==q['source_sha256']
 source=git(q['path']).decode();nodes=[n for n in ast.walk(ast.parse(source)) if isinstance(n,ast.FunctionDef) and n.name==q['function']]
 assert any(ast.get_source_segment(source,n)==q['source'] for n in nodes),(q['path'],q['function'])
for q in contexts['explicit_caller_fixtures']:
 rel=q['path'];bt=raw_trees.get(rel,ast.parse(git(rel)));nodes=[n for n in ast.walk(bt) if isinstance(n,ast.FunctionDef) and n.name==q['function']];assert len(nodes)==1
 present=calls(nodes[0])
 for source in q['calls']:assert present[dump(ast.parse(source,mode='eval').body)]>0
 caller_checks.append(dict(path=rel,function=q['function'],calls=q['calls']))
assert len(caller_checks)==18
for q in contexts['main_fixtures']:
 rel=q['path'];b=raws[rel].decode();nodes=[n for n in ast.walk(raw_trees[rel]) if isinstance(n,ast.FunctionDef) and n.name==q['function']];assert len(nodes)==1
 text=ast.get_source_segment(b,nodes[0]);assert "'promise_class_harness_preflight'" in text and "'promise_class_preflight_healthy'" in text
 fixture_checks.append(dict(path=rel,function=q['function'],sha256=sha(text.encode())))
assert len(fixture_checks)==9
out=dict(base=BASE,manifest=bind(H/'migrations-1/source-ready.json'),census=bind(H/'migration-plan-1/source-ready.json'),checked_binding_count=len(validated),file_checks=file_checks,changed_test_ids=changed,unchanged_test_ids=unchanged,parent_group_count=len(ids),parent_log=bind(pathlib.Path(p['log']['path'])),retained_complete_ids=sorted(ids),policies=policy_checks,historical_json=historical,explicit_callers=caller_checks,main_fixtures=fixture_checks,execution='Only this independent stdlib audit and read-only git show. No project import, test, producer execution or live edit.')
(O/'checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(status='clear',paths=len(file_checks),edits=len(edits),changed=len(changed),unchanged=len(unchanged),all_ids=len(ids),policy_changes=sum(q['changed'] for q in policy_checks),bindings=len(validated),historical_json=len(historical),checks=bind(O/'checks.json')),indent=2))
