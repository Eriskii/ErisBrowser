from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import subprocess

H = Path(__file__).resolve().parents[1]
W = H / 'worktree'

def bound(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(rel):
    return json.loads((H / rel).read_bytes())

def receipt(label, code):
    path = H / 'validation' / (label + '.json')
    record = json.loads(path.read_bytes())
    assert record['exit'] == code
    log = H / 'validation' / record['log']
    assert bound(log)['sha256'] == record['sha256']
    return dict(receipt=bound(path), log=bound(log), command=record['command'], exit=code)

final = read('source-final.json')['source_sha256']
second = read('source-candidate-2.json')['source_sha256']
first = read('source-candidate-1.json')['source_sha256']
base = read('source-parent-2.json')['source_sha256']
assert first.keys() == second.keys() == final.keys()
assert [p for p in first if first[p] != second[p]] == ['tools/test_test262_with_resolvers_controls.py']
update = read('root/baseline-update-1.json')
baseline_paths = {row['path'] for row in update['written']}
assert len(baseline_paths) == 7
assert {p for p in second if second[p] != final[p]} == baseline_paths
for path, digest in final.items():
    assert bound(W / path)['sha256'] == digest, path
changed = {p for p in final if p not in base or base[p] != final[p]}
git_changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=W).decode().splitlines())
git_changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W).decode().splitlines())
assert git_changed == changed and len(changed) == 25
assert all(p.startswith(('tools/', 'tests/conformance/')) for p in changed)
assert (W / 'tools/test262_conformance.py').read_bytes() == (H / 'producer-2/raw/tools/test262_conformance.py').read_bytes()
python = {label:receipt(label, code) for label, code in [
    ('parent-python-1', 0), ('parent-class-controls-1', 1),
    ('candidate-class-controls-1', 0), ('candidate-python-1', 1), ('candidate-python-2', 0)]}
def roster(label, expected, ok):
    text = Path(python[label]['log']['path']).read_text()
    rows = re.findall(r'^(test_\w+) \(([^\n]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$', text, re.M)
    assert len(rows) == expected and len({(name, group) for name, group, _ in rows}) == expected
    assert sum(status == 'ok' for _, _, status in rows) == ok
    return {(name, group) for name, group, _ in rows}
old = roster('parent-python-1', 683, 683)
new = roster('candidate-python-2', 696, 696)
focused = roster('candidate-class-controls-1', 13, 13)
assert new - old == focused and old <= new
roster('candidate-python-1', 696, 695)
assert roster('parent-class-controls-1', 13, 1) == focused
parent, candidate, gates = [read('root/' + name) for name in
                            ('profile-parent-1.json', 'profile-candidate-1.json', 'baseline-gates-1.json')]
assert all(row['status'] == 'pass' and len(row['profiles']) == 8 for row in (parent, candidate, gates))
assert candidate['counts'] == dict(passed=1258, failed=64, unsupported=8)
assert candidate['transition_counts'] == dict(case_record_changes=40, control_record_changes=0,
    prior_pass_regressions=0, newly_passed=36, nonpass_status_changes=4, raw_only_changes=0,
    outside_class_tag_changes=0)
totals = Counter()
case_count = control_count = 0
for measured, gate in zip(candidate['profiles'], gates['profiles']):
    assert measured['profile'] == gate['profile'] and not measured['errors'] and not gate['errors']
    for row in (measured, gate):
        for key in ('report', 'receipt', 'log'):
            assert bound(row[key]['path']) == row[key]
    before = json.loads(Path(measured['report']['path']).read_bytes())
    after = json.loads(Path(gate['report']['path']).read_bytes())
    assert {k:v for k,v in before.items() if k != 'seconds'} == {k:v for k,v in after.items() if k != 'seconds'}
    assert gate['exit'] == 0 and after['harness_preflight_passed'] is True
    assert after['regressions'] == after['improvements'] == []
    assert all(item['verified'] is True for item in after['harness_preflight'])
    assert after['counts'] == dict(Counter(item['status'] for item in after['cases']))
    totals.update(after['counts']); case_count += len(after['cases']); control_count += len(after['harness_preflight'])
assert (case_count, control_count) == (1330, 724) and dict(totals) == candidate['counts']
for item in candidate['binaries'].values():
    for key in ('binary', 'sidecar', 'build_log'):
        assert bound(item[key]['path']) == item[key]
reviews = ['producer-review-2/review.json', 'migrations-review-1/review.json',
           'migration-correction-review-1/review.json', 'profile-review-1/review.json']
record = dict(status='pass', scope='Promise class metadata admission in seven existing profiles; full browser goal remains incomplete',
    source_inventory=bound(H / 'source-final.json'), source_candidate_1=bound(H / 'source-candidate-1.json'),
    source_candidate_2=bound(H / 'source-candidate-2.json'), base=read('source-parent-2.json')['base'],
    selected_inputs=len(final), changed_source_test_baseline_paths=sorted(changed),
    source_qualification='Selected-input inventory, not a complete build graph; runtime/build/protocol source unchanged',
    python=python, python_counts=dict(parent=683, final=696, new=13, first_candidate_passed=695, first_candidate_failed=1),
    roster_preservation='All 683 original IDs retained plus exact 13 new IDs, no skips; parent new-test run 1 passed/12 missing-API failures',
    binaries=candidate['binaries'], parent_capture=bound(H / 'root/profile-parent-1.json'),
    candidate_capture=bound(H / 'root/profile-candidate-1.json'), profile_counts=candidate['counts'],
    mode_cases=case_count, controls=control_count, old_controls=640, new_controls=84,
    admission_transitions=candidate['transition_counts'],
    baseline_update=bound(H / 'root/baseline-update-1.json'), baseline_gates=bound(H / 'root/baseline-gates-1.json'),
    cumulative_baseline_transitions=dict(new_passes=56, newly_reached_failures=14, carried_runtime_passes=20, carried_runtime_failures=10),
    independent_reviews=[bound(H / p) for p in reviews],
    corrections=['producer-1 same-mode restriction rejected legacy cross-mode edges; corrected before execution in producer-2',
                 'full Python candidate1 missed one legacy selected-feature expectation; one assertion corrected and full696 rerun passed'],
    validation_limits=['No Rust semantics, parser, protocol, helper or corpus change; no new full Rust suite or hardware run',
                       '696 Python tests bind source2; final differs only by seven measured compact baselines, validated by all eight fresh baseline-gate runs',
                       '1258/1330 is a bounded eight-profile result, not full Test262 or web compatibility',
                       'Full browser standards support, security audit and Chromium-relative performance remain unverified and incomplete'])
destination = H / 'root/final-validation.json'
with destination.open('x') as stream:
    json.dump(record, stream, indent=2); stream.write('\n')
print(json.dumps(bound(destination)))
