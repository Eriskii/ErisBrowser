from pathlib import Path
import hashlib
import json
import shutil
import sys

hold = Path(__file__).resolve().parents[1]
kind = sys.argv[1]
assert kind in ('ordinary', 'host')
source = hold / 'source-parent.json'
for name, sha in json.loads(source.read_bytes())['source_sha256'].items():
    assert hashlib.sha256((hold / 'worktree' / name).read_bytes()).hexdigest() == sha, name
label = 'parent-release-' + kind + '-1'
build = hold / 'validation' / (label + '.json')
environment = hold / 'validation' / (label + '-environment.json')
assert json.loads(build.read_bytes())['exit'] == 0
target = 'target-msrv' if kind == 'ordinary' else 'target-1990'
binary = hold / 'binaries' / ('eris-js-' + kind + '-1')
assert not binary.exists()
shutil.copy2(hold / target / 'release' / 'eris-js', binary)
binary.chmod(0o555)
def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
record = dict(binary=str(binary), bytes=binary.stat().st_size,
              sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
              source_inventory=bound(source), build=bound(build), environment=bound(environment),
              features=[] if kind == 'ordinary' else ['test262-host'],
              toolchain='1.88.0' if kind == 'ordinary' else '1.99.0')
with binary.with_suffix('.json').open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
print(json.dumps(record))
