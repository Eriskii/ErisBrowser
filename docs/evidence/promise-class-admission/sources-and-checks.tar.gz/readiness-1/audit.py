"""Source-only published-byte/AST census. Does not import repository modules."""
import ast
import collections
import copy
import hashlib
import json
from pathlib import Path
import re
import subprocess

BASE = '315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
H = Path('/tmp/eris-promise-class-admission-plan-1')
W = H / 'worktree'
R = H / 'readiness-1'
M = H / 'migration-plan-1'
OLD = Path('/tmp/eris-promise-class-admission-readiness-1')
SELECTED = ['promise-methods-async', 'promise-all', 'promise-race', 'promise-all-settled', 'promise-any', 'promise-with-resolvers', 'promise-try']
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))
def dump(p, obj): p.write_text(json.dumps(obj, indent=2, ensure_ascii=True) + '\n')
def canonical(obj): return json.dumps(obj, sort_keys=True).encode()

assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD'], text=True).strip() == BASE
entries = subprocess.check_output(['git', '-C', str(W), 'ls-tree', '-rz', BASE]).split(b'\0')
tracked = {}
for entry in entries:
    if not entry: continue
    meta, path = entry.split(b'\t', 1)
    mode, kind, blob = meta.decode().split()
    if kind == 'blob': tracked[path.decode()] = blob
def source(path):
    data = (W / path).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == tracked[path], path
    return data
def source_bind(path):
    data = source(path)
    return dict(path=path, git_blob=tracked[path], bytes=len(data), sha256=sha(data))

# Retained proposal authentication and additive comparison of the full old bound union.
ready = json.loads((OLD / 'source-ready.json').read_text())
for item in ready['artifacts']:
    assert bind(Path(item['path'])) == item
prior = json.loads((OLD / 'published-joins.json').read_text())
joins = []
for row in prior['files']:
    now = source_bind(row['path'])
    joins.append(dict(**now, prior_sha256=row['sha256'], identical=now['sha256'] == row['sha256']))
differences = [row for row in joins if not row['identical']]
dump(R / 'published-joins.json', dict(base=BASE, prior_base=prior['commit'], files=joins,
    differences=differences, scope='The prior 1,937-path bound union, not the full graph.'))

# Literal-only AST interpreter. No compile/exec or project module import.
env = {}
def literal(n):
    if isinstance(n, ast.Constant): return n.value
    if isinstance(n, ast.Name): return env[n.id]
    if isinstance(n, (ast.List, ast.Set, ast.Tuple)):
        xs = [literal(x) for x in n.elts]
        return set(xs) if isinstance(n, ast.Set) else tuple(xs) if isinstance(n, ast.Tuple) else xs
    if isinstance(n, ast.Dict): return {literal(k): literal(v) for k, v in zip(n.keys, n.values)}
    if isinstance(n, ast.BinOp) and isinstance(n.op, ast.BitOr): return literal(n.left) | literal(n.right)
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'copy' and not n.args:
        return literal(n.func.value).copy()
    raise ValueError(type(n).__name__)
runner = source('tools/test262_conformance.py').decode()
tree = ast.parse(runner)
for node in tree.body:
    if isinstance(node, ast.Assign):
        try: value = literal(node.value)
        except (ValueError, KeyError): continue
        for target in node.targets:
            if isinstance(target, ast.Name): env[target.id] = value
            elif isinstance(target, ast.Subscript): literal(target.value)[literal(target.slice)] = value
    elif isinstance(node, ast.Expr) and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Attribute) and node.value.func.attr == 'add':
        try: literal(node.value.func.value).add(literal(node.value.args[0]))
        except (ValueError, KeyError): pass
features = env['PROFILE_FEATURES']
assert len(features) == 61 and len(set(features) - set(SELECTED)) == 54
assert 'class' not in env['SUPPORTED_FEATURES']
intrinsics = sorted(env['INTRINSIC_ERRORS'])
def policy(profile, feats):
    p = dict(format=2, supported_features=sorted(feats), negative_intrinsic_errors=sorted(set(intrinsics) | ({'AggregateError'} if profile in {'promise-any', 'aggregate-error'} else set())), strict=True, modules=False, async_completion=False, host_hooks=False, timeout_seconds=3.0)
    if profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill', 'typedarray-reverse', 'typedarray-copy-within'}: p['excluded_harness'] = ['resizableArrayBufferUtils.js']
    if profile in env['PROMISE_HOST_PROFILES']:
        p.update(format=3, async_completion=True, host_hooks=True, request_protocol='ERJS2', response_protocol='ERJR3', adapter_feature='test262-host', completion_policy={'sync':'checked-sync','async':'authenticated-done'}, unhandled_rejection_policy='final-quiescent-veto', print_only_completion=False)
    return p
policies = []
for profile, feats in features.items():
    old = policy(profile, feats)
    new = policy(profile, feats | {'class'} if profile in SELECTED else feats)
    policies.append(dict(profile=profile, before=old, after=new, before_sha256=sha(canonical(old)), after_sha256=sha(canonical(new)), changed=old != new))
assert sum(x['changed'] for x in policies) == 7
prior_policy = json.loads((OLD / 'policy-proposal.json').read_text())
for item in prior_policy['selected']:
    row = next(x for x in policies if x['profile'] == item['profile'])
    assert row['before'] == item['old_policy'] and row['after'] == item['proposed_policy']
    assert row['after_sha256'] == item['proposed_sha256']
dump(M / 'policies.json', dict(base=BASE, interpretation='Only supported_features changes; timeout 3.0 and canonical JSON spacing retained.', profiles=policies, generic_default=sorted(env['SUPPORTED_FEATURES'])))

# Corpus bytes, complete ordered mode fingerprints, retained raw report/control bindings.
census = json.loads((OLD / 'census.json').read_text())
refreshed = []
for p in census['profiles']:
    profile = p['profile']; prefix = 'tests/upstream/test262-' + profile + '/'
    manifest = json.loads(source(prefix + 'manifest.json'))
    for entry in manifest['files'] + manifest['inventory_proof']['files']:
        b = source(prefix + entry['path'])
        assert len(b) == entry['bytes'] and sha(b) == entry['sha256']
    cases = sorted(p['cases'], key=lambda c: (c['file'], 0 if c['mode'] == 'sloppy' else 1))
    for c in cases:
        assert sha(source(prefix + c['file'])) == c['source_sha256']
        for helper in c['harness']:
            assert sha(source(prefix + 'harness/' + helper['name'])) == helper['sha256']
        identity = {key:c[key] for key in ('source_sha256','mode','metadata','harness')}
        if 'completion_policy' in c: identity['completion_policy'] = c['completion_policy']
        assert sha(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode()) == c['case_sha256']
    report_path = Path(p['candidate_report']['path']); report = json.loads(report_path.read_text())
    assert bind(report_path) == p['candidate_report']
    assert [c['id'] for c in cases] == [c['id'] for c in report['cases']]
    guards = report['harness_preflight']
    assert len(guards) == p['existing_controls']
    guard_identity = [dict(name=g['name'], expected=g['expected'], id=g['result']['id'], mode=g['result']['mode'], case_sha256=g['result']['case_sha256'], source_sha256=g['result']['source_sha256']) for g in guards]
    baseline_path = 'tests/conformance/test262-' + profile + '-current.json'
    baseline = json.loads(source(baseline_path)); pr = next(x for x in policies if x['profile']==profile)
    assert baseline['runner_policy_sha256'] == pr['before_sha256']
    assert list(baseline['cases']) == [c['id'] for c in cases]
    assert all(baseline['cases'][c['id']]['case_sha256'] == c['case_sha256'] for c in cases)
    refreshed.append(dict(profile=profile, originals=p['source_tests'], modes=len(cases), old_controls=len(guards), class_originals=p['class_sources'], class_modes=p['class_modes'], manifest=source_bind(prefix+'manifest.json'), baseline=source_bind(baseline_path), baseline_schema=sorted(baseline), old_policy_sha256=pr['before_sha256'], proposed_policy_sha256=pr['after_sha256'], cases=cases, ordered_case_digest=sha(canonical(cases)), controls=guard_identity, ordered_control_identity_digest=sha(canonical(guard_identity)), retained_full_report=bind(report_path), baseline_status_counts=dict(collections.Counter(x['status'] for x in baseline['cases'].values())), outcome_selection='Pending measured parent/candidate replay; no baseline status changes authorized here.'))
assert sum(x['originals'] for x in refreshed)==643 and sum(x['modes'] for x in refreshed)==1280 and sum(x['old_controls'] for x in refreshed)==588
dump(R / 'corpus-and-identity-refresh.json', dict(base=BASE, profiles=refreshed, totals=census['totals'], qualification='Identities refreshed from authenticated unchanged bytes; retained F observations are historical, not new executions.'))

# Complete static unittest method roster, and all relevant AST reference contexts.
test_paths = sorted(p for p in tracked if p.startswith('tools/') and Path(p).name.startswith('test_') and p.endswith('.py'))
roster = []; modules=[]; contexts=[]; main_fixtures=[]; caller_fixtures=[]
for path in test_paths:
    s = source(path).decode(); t=ast.parse(s); count=0
    top = '/' not in path[len('tools/'):]
    for cls in t.body:
        if not isinstance(cls, ast.ClassDef): continue
        for n in cls.body:
            if isinstance(n, ast.FunctionDef) and n.name.startswith('test'):
                body=ast.get_source_segment(s,n); count+=1
                roster.append(dict(id=Path(path).stem+'.'+cls.name+'.'+n.name, path=path, line=n.lineno, end_line=n.end_lineno, source_sha256=sha(body.encode()), top_level_discovery=top))
    modules.append(dict(**source_bind(path), groups=count, top_level_discovery=top))
    for n in ast.walk(t):
        if not isinstance(n, ast.FunctionDef):continue
        b=ast.get_source_segment(s,n)
        if any(k in b for k in ['PROFILE_FEATURES','PROMISE_FEATURES','runner_policy','supported_features','FEATURES','class_excluded']):
            contexts.append(dict(path=path, function=n.name, line=n.lineno, source_sha256=sha(b.encode()), source=b))
        if 'runner.main()' in b and any(k in path for k in ['promise','with_resolvers','aggregate_error_preservation']):
            main_fixtures.append(dict(path=path,function=n.name,line=n.lineno,source_sha256=sha(b.encode()),source=b))
        calls=[ast.get_source_segment(s,call) for call in ast.walk(n) if isinstance(call,ast.Call) and isinstance(call.func,ast.Attribute) and call.func.attr in {'unsupported_reason','run_case'} and any((isinstance(a,ast.Name) and a.id=='FEATURES') or "oracle['features']" in ast.get_source_segment(s,a) for a in call.args)]
        if calls and n.name.startswith('test_') and any(k in path for k in ['promise','with_resolvers']):caller_fixtures.append(dict(path=path,function=n.name,line=n.lineno,calls=calls,rule='Retain these explicit caller-supplied feature arguments and their class exclusions; they are not current profile defaults.'))
top_roster=[r for r in roster if r['top_level_discovery']]
assert len(top_roster)==683 and sum(x['top_level_discovery'] for x in modules)==68
log=Path('/tmp/eris-promise-try-upstream-plan-1/validation/python-full-1.log')
receipt=log.with_suffix('.json'); rr=json.loads(receipt.read_text());assert sha(log.read_bytes())==rr['sha256'] and rr['exit']==0
ids=re.findall(r'^test\w+ \(([^)]+)\) \.\.\. ok$',log.read_text(),re.M)
assert len(ids)==683 and len(set(ids))==683 and set(ids)=={r['id'] for r in top_roster}
dump(M / 'python-roster.json',dict(base=BASE,discovery="python3 -m unittest discover -s tools -p 'test_*.py'",top_level_modules=68,top_level_groups=683,modules=modules,methods=roster,other_discoveries='Nested Vulkan probe modules listed separately; not included in 683.',retained_execution_receipt=bind(receipt),retained_log=bind(log),retained_actual_ids=ids,exact_actual_static_roster_equality=True,claim='Historical execution only; no project execution performed by this audit.'))
dump(M / 'reviewed-contexts.json',dict(base=BASE,contexts=contexts,main_fixtures=main_fixtures,explicit_caller_fixtures=caller_fixtures))

# Historical oracle and helper-body seals remain immutable. Current policy overlays are additive.
oracle_names=['promise-methods-runner-oracle.json','promise-all-profile-oracle.json','promise-race-profile-oracle.json','promise-all-settled-profile-oracle.json','aggregate-error-preservation-oracle.json','promise-any-preservation-oracle.json','with-resolvers-preservation-oracle.json','promise-try-preservation-oracle.json']
oracles=[]
policy_seal_checks=[]
for name in oracle_names:
    path='tools/'+name; data=json.loads(source(path)); sealed=[]
    for profile, held in data.get('policies_at_timeout3',{}).items():
        expected=next(x for x in policies if x['profile']==profile)
        assert held['policy']==expected['before'] and held['sha256']==expected['before_sha256']
        policy_seal_checks.append(dict(oracle=path,profile=profile,before_sha256=held['sha256'],selected_class_overlay=expected['changed']))
    for filename, funcs in data.get('unchanged_functions',{}).items():
        body_source=source(filename).decode(); nodes={n.name:n for n in ast.parse(body_source).body if isinstance(n,ast.FunctionDef)}
        for fn, expected in funcs.items():
            assert sha(ast.get_source_segment(body_source,nodes[fn]).encode())==expected
            sealed.append(dict(path=filename,function=fn,sha256=expected))
    for fn, expected in data.get('unchanged_runner_functions',{}).items():
        n=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==fn)
        assert sha(ast.get_source_segment(runner,n).encode())==expected
        sealed.append(dict(path='tools/test262_conformance.py',function=fn,sha256=expected))
    oracles.append(dict(**source_bind(path),keys=list(data),unchanged_function_seals=sealed,action='Keep bytes and historical SHA constant exact; transform a separate expected current feature/policy copy for selected profiles only.'))
dump(M / 'historical-oracles.json',dict(oracles=oracles,policy_seal_checks=policy_seal_checks,rule='Do not exclude entire selected profiles from old preservation checks. Compare every nonfeature field exactly and require the sole selected class addition.'))
baseline_targets={'tests/conformance/test262-'+p+'-current.json' for p in SELECTED}
conformance_json=[dict(**source_bind(p),selected_baseline_target=p in baseline_targets) for p in sorted(tracked) if p.startswith('tests/conformance/') and p.endswith('.json')]
assert len(conformance_json)==290 and sum(x['selected_baseline_target'] for x in conformance_json)==7
dump(M/'conformance-json-preservation.json',dict(base=BASE,scope='Every tracked JSON below tests/conformance; includes historical expected data, not all are baseline reports.',files=conformance_json,selected_baselines=7,other_json_files_to_preserve=283))
print(json.dumps(dict(base=BASE,prior_union=len(joins),changed_prior_paths=[x['path'] for x in differences],top_modules=68,top_groups=683,nested_groups=len(roster)-683,policy_changes=7,other_profiles=54,explicit_caller_methods=len(caller_fixtures),main_fixtures=len(main_fixtures)),indent=2))
