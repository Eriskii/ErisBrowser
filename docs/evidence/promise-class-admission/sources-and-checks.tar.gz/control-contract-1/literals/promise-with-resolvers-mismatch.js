class SubPromise extends Promise {}
var record = SubPromise.withResolvers();
assert.sameValue(Object.getPrototypeOf(record), Object.prototype);
assert.sameValue(Object.getPrototypeOf(record.promise), SubPromise.prototype);
assert.sameValue(Promise.resolve.call(SubPromise, record.promise), record.promise);
assert.sameValue(typeof record.resolve, 'function');
assert.sameValue(typeof record.reject, 'function');
assert.notSameValue(record.resolve, record.reject);
var names = ['promise', 'resolve', 'reject'];
for (var i = 0; i < names.length; i++) {
  var descriptor = Object.getOwnPropertyDescriptor(record, names[i]);
  assert.sameValue(descriptor.value, record[names[i]]);
  assert.sameValue(descriptor.writable, true);
  assert.sameValue(descriptor.enumerable, true);
  assert.sameValue(descriptor.configurable, true);
}
record.resolve(7);
record.reject({});
assert.sameValue(Object.keys(record).join(','), 'resolve,promise,reject');
