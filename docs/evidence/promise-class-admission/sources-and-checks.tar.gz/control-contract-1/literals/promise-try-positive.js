var trace = '', recordConstruction = false, value = {}, sentinel = {};
class SubPromise extends Promise {
  constructor(executor) {
    if (recordConstruction) { trace += 'C'; }
    super(executor);
  }
}
var seed = new SubPromise(function (resolve) { resolve(value); });
recordConstruction = true;
var same = SubPromise.try(function () { trace += 'N'; return seed; });
assert.sameValue(same, seed);
assert.sameValue(trace, 'N');
var rejected = SubPromise.try(function () { trace += 'T'; throw sentinel; });
assert.sameValue(Object.getPrototypeOf(rejected), SubPromise.prototype);
assert.sameValue(trace, 'NTC');
recordConstruction = false;
rejected.then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (reason) {
  assert.sameValue(reason, sentinel);
  trace += 'R';
  assert.sameValue(trace, 'NTCR');
}).then($DONE, $DONE);
