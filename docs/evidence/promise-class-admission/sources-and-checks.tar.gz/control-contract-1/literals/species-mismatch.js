var token = {}, captured, alternateCalls = 0, resolveCalls = 0, rejectCalls = 0;
function resolve(value) { resolveCalls++; }
function reject(reason) { rejectCalls++; }
class NativePromise extends Promise {}
var promise = new NativePromise(function () {});
assert.sameValue(Promise.resolve.call(NativePromise, promise), promise);
class Alternate extends Promise {
  constructor(executor) {
    alternateCalls++;
    captured = executor;
    executor(resolve, reject);
    return token;
  }
}
Object.defineProperty(NativePromise, Symbol.species, {value: Alternate, configurable: true});
var result = promise.then(function (value) { return value; });
assert.sameValue(typeof captured, 'function');
assert.sameValue(result, token);
assert.sameValue(resolveCalls, 0);
assert.sameValue(rejectCalls, 0);
assert.throws(TypeError, function () { captured(resolve, reject); });
class InvalidCapture extends Promise {
  constructor(executor) { executor(0, 0); return {}; }
}
Object.defineProperty(NativePromise, Symbol.species, {value: InvalidCapture, configurable: true});
assert.throws(TypeError, function () { promise.then(); });
assert.sameValue(alternateCalls, 2);
