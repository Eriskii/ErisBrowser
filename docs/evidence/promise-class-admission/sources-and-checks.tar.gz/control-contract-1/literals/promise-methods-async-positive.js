var trace = '';
class SubError extends Error {}
class SubPromise extends Promise {}
var sentinel = new SubError('class sentinel');
assert.sameValue(Object.getPrototypeOf(sentinel), SubError.prototype);
assert.sameValue(sentinel instanceof Error, true);
var rejected = SubPromise.reject(sentinel);
assert.sameValue(Object.getPrototypeOf(rejected), SubPromise.prototype);
var recovered = rejected.catch(function (reason) {
  assert.sameValue(reason, sentinel);
  trace += 'R';
  return 7;
});
assert.sameValue(Object.getPrototypeOf(recovered), SubPromise.prototype);
var finished = recovered.finally(function () { trace += 'F'; });
assert.sameValue(Object.getPrototypeOf(finished), SubPromise.prototype);
assert.notSameValue(finished, recovered);
finished.then(function (value) {
  assert.sameValue(value, 7);
  trace += 'V';
  assert.sameValue(trace, 'RFV');
}).then($DONE, $DONE);
