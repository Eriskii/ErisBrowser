var trace = '', defaults = 0, captured, savedResolve;
class Base {
  constructor(value = (defaults++, 7)) { trace += 'B'; this.value = value; }
  method() { return this.value; }
}
class Derived extends Base {}
var object = new Derived(7);
assert.sameValue(Object.getPrototypeOf(Derived), Base);
assert.sameValue(Object.getPrototypeOf(Derived.prototype), Base.prototype);
assert.sameValue(Object.getPrototypeOf(object), Derived.prototype);
assert.sameValue(object.method(), 7);
assert.throws(TypeError, function () { Base(); });
assert.throws(TypeError, function () { new object.method(); });
assert.sameValue(defaults, 0);
class SubPromise extends Promise {
  constructor(executor) { captured = executor; trace += 'P'; super(executor); }
}
class LeafPromise extends SubPromise {}
var executor = function (resolve) { savedResolve = resolve; };
var promise = new LeafPromise(executor);
assert.sameValue(captured, executor);
assert.sameValue(typeof savedResolve, 'function');
assert.sameValue(Object.getPrototypeOf(SubPromise), Promise);
assert.sameValue(Object.getPrototypeOf(LeafPromise), SubPromise);
assert.sameValue(Object.getPrototypeOf(LeafPromise.prototype), SubPromise.prototype);
assert.sameValue(Object.getPrototypeOf(promise), LeafPromise.prototype);
assert.sameValue(Promise.resolve.call(LeafPromise, promise), promise);
assert.sameValue(trace, 'BPP');
