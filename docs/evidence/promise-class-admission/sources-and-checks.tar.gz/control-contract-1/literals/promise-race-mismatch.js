var trace = '', reads = 0, calls = 0, sentinel = {};
class SubPromise extends Promise {}
Object.defineProperty(SubPromise, 'resolve', {
  configurable: true,
  get: function () {
    reads++;
    trace += 'G';
    return function (value) {
      assert.sameValue(this, SubPromise);
      calls++;
      trace += 'r';
      if (calls === 1) {
        Object.defineProperty(SubPromise, 'resolve', {
          configurable: true,
          value: function () { throw new Test262Error('uncached resolve'); }
        });
      }
      return Promise.resolve(value);
    };
  }
});
var result = SubPromise.race([3, 4]);
assert.sameValue(Object.getPrototypeOf(result), SubPromise.prototype);
assert.sameValue(reads, 1);
assert.sameValue(calls, 2);
assert.sameValue(trace, 'Grr');
result.then(function (value) {
  assert.sameValue(value, 3);
  trace += 'V';
  assert.sameValue(trace, 'GrrV!');
}).then($DONE, $DONE);
