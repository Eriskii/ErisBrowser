from pathlib import Path
import ast, difflib, hashlib, json, subprocess
H=Path('/tmp/eris-promise-class-admission-plan-1'); W=H/'worktree'; D=H/'control-contract-1'; R=Path('/tmp/eris-promise-class-admission-readiness-1')
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,v):
 p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def emit(n,s):
 p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s);return bind(p)
assert not (D/'source-ready.json').exists()
profiles=['promise-methods-async','promise-all','promise-race','promise-all-settled','promise-any','promise-with-resolvers','promise-try']
sources={}
sources['construction']='''var trace = '', defaults = 0, captured, savedResolve;
class Base {
  constructor(value = (defaults++, 7)) { trace += 'B'; this.value = value; }
  method() { return this.value; }
}
class Derived extends Base {}
var object = new Derived(7);
assert.sameValue(Object.getPrototypeOf(Derived), Base);
assert.sameValue(Object.getPrototypeOf(Derived.prototype), Base.prototype);
assert.sameValue(Object.getPrototypeOf(object), Derived.prototype);
assert.sameValue(object.method(), 7);
assert.throws(TypeError, function () { Base(); });
assert.throws(TypeError, function () { new object.method(); });
assert.sameValue(defaults, 0);
class SubPromise extends Promise {
  constructor(executor) { captured = executor; trace += 'P'; super(executor); }
}
class LeafPromise extends SubPromise {}
var executor = function (resolve) { savedResolve = resolve; };
var promise = new LeafPromise(executor);
assert.sameValue(captured, executor);
assert.sameValue(typeof savedResolve, 'function');
assert.sameValue(Object.getPrototypeOf(SubPromise), Promise);
assert.sameValue(Object.getPrototypeOf(LeafPromise), SubPromise);
assert.sameValue(Object.getPrototypeOf(LeafPromise.prototype), SubPromise.prototype);
assert.sameValue(Object.getPrototypeOf(promise), LeafPromise.prototype);
assert.sameValue(Promise.resolve.call(LeafPromise, promise), promise);
assert.sameValue(trace, 'BP');
'''
sources['species']='''var token = {}, captured, alternateCalls = 0, resolveCalls = 0, rejectCalls = 0;
function resolve(value) { resolveCalls++; }
function reject(reason) { rejectCalls++; }
class NativePromise extends Promise {}
var promise = new NativePromise(function () {});
assert.sameValue(Promise.resolve.call(NativePromise, promise), promise);
class Alternate extends Promise {
  constructor(executor) {
    alternateCalls++;
    captured = executor;
    executor(resolve, reject);
    return token;
  }
}
Object.defineProperty(NativePromise, Symbol.species, {value: Alternate, configurable: true});
var result = promise.then(function (value) { return value; });
assert.sameValue(typeof captured, 'function');
assert.sameValue(result, token);
assert.sameValue(resolveCalls, 0);
assert.sameValue(rejectCalls, 0);
assert.throws(TypeError, function () { captured(resolve, reject); });
class InvalidCapture extends Promise {
  constructor(executor) { executor(0, 0); return {}; }
}
Object.defineProperty(NativePromise, Symbol.species, {value: InvalidCapture, configurable: true});
assert.throws(TypeError, function () { promise.then(); });
assert.sameValue(alternateCalls, 1);
'''
sources['promise-methods-async']='''var trace = '';
class SubError extends Error {}
class SubPromise extends Promise {}
var sentinel = new SubError('class sentinel');
assert.sameValue(Object.getPrototypeOf(sentinel), SubError.prototype);
assert.sameValue(sentinel instanceof Error, true);
var rejected = SubPromise.reject(sentinel);
assert.sameValue(Object.getPrototypeOf(rejected), SubPromise.prototype);
var recovered = rejected.catch(function (reason) {
  assert.sameValue(reason, sentinel);
  trace += 'R';
  return 7;
});
assert.sameValue(Object.getPrototypeOf(recovered), SubPromise.prototype);
var finished = recovered.finally(function () { trace += 'F'; });
assert.sameValue(Object.getPrototypeOf(finished), SubPromise.prototype);
assert.notSameValue(finished, recovered);
finished.then(function (value) {
  assert.sameValue(value, 7);
  trace += 'V';
  assert.sameValue(trace, 'RFV');
}).then($DONE, $DONE);
'''
for profile,method,inputs,checks in [
 ('promise-all','all','[3, 4]',"  assert.sameValue(value.length, 2);\n  assert.sameValue(value[0], 3);\n  assert.sameValue(value[1], 4);\n"),
 ('promise-race','race','[3, 4]',"  assert.sameValue(value, 3);\n"),
 ('promise-all-settled','allSettled','[3, Promise.reject(sentinel)]',"  assert.sameValue(value.length, 2);\n  assert.sameValue(value[0].status, 'fulfilled');\n  assert.sameValue(value[0].value, 3);\n  assert.sameValue(value[1].status, 'rejected');\n  assert.sameValue(value[1].reason, sentinel);\n"),
 ('promise-any','any','[Promise.reject(sentinel), 4]',"  assert.sameValue(value, 4);\n")]:
 sources[profile]="""var trace = '', reads = 0, calls = 0, sentinel = {};
class SubPromise extends Promise {}
Object.defineProperty(SubPromise, 'resolve', {
  configurable: true,
  get: function () {
    reads++;
    trace += 'G';
    return function (value) {
      assert.sameValue(this, SubPromise);
      calls++;
      trace += 'r';
      if (calls === 1) {
        Object.defineProperty(SubPromise, 'resolve', {
          configurable: true,
          value: function () { throw new Test262Error('uncached resolve'); }
        });
      }
      return Promise.resolve(value);
    };
  }
});
"""+f"var result = SubPromise.{method}({inputs});\n"+"""assert.sameValue(Object.getPrototypeOf(result), SubPromise.prototype);
assert.sameValue(reads, 1);
assert.sameValue(calls, 2);
assert.sameValue(trace, 'Grr');
result.then(function (value) {
"""+checks+"""  trace += 'V';
  assert.sameValue(trace, 'GrrV');
}).then($DONE, $DONE);
"""
sources['promise-with-resolvers']='''class SubPromise extends Promise {}
var record = SubPromise.withResolvers();
assert.sameValue(Object.getPrototypeOf(record), Object.prototype);
assert.sameValue(Object.getPrototypeOf(record.promise), SubPromise.prototype);
assert.sameValue(Promise.resolve.call(SubPromise, record.promise), record.promise);
assert.sameValue(typeof record.resolve, 'function');
assert.sameValue(typeof record.reject, 'function');
assert.notSameValue(record.resolve, record.reject);
var names = ['promise', 'resolve', 'reject'];
for (var i = 0; i < names.length; i++) {
  var descriptor = Object.getOwnPropertyDescriptor(record, names[i]);
  assert.sameValue(descriptor.value, record[names[i]]);
  assert.sameValue(descriptor.writable, true);
  assert.sameValue(descriptor.enumerable, true);
  assert.sameValue(descriptor.configurable, true);
}
record.resolve(7);
record.reject({});
assert.sameValue(Object.keys(record).join(','), 'promise,resolve,reject');
'''
sources['promise-try']='''var trace = '', recordConstruction = false, value = {}, sentinel = {};
class SubPromise extends Promise {
  constructor(executor) {
    if (recordConstruction) { trace += 'C'; }
    super(executor);
  }
}
var seed = new SubPromise(function (resolve) { resolve(value); });
recordConstruction = true;
var same = SubPromise.try(function () { trace += 'N'; return seed; });
assert.sameValue(same, seed);
assert.sameValue(trace, 'N');
var rejected = SubPromise.try(function () { trace += 'T'; throw sentinel; });
assert.sameValue(Object.getPrototypeOf(rejected), SubPromise.prototype);
assert.sameValue(trace, 'NTC');
recordConstruction = false;
rejected.then(function () {
  throw new Test262Error('unexpected fulfillment');
}, function (reason) {
  assert.sameValue(reason, sentinel);
  trace += 'R';
  assert.sameValue(trace, 'NTCR');
}).then($DONE, $DONE);
'''
changes={
 'construction':("assert.sameValue(trace, 'BP');","assert.sameValue(trace, 'BPP');"),
 'species':('assert.sameValue(alternateCalls, 1);','assert.sameValue(alternateCalls, 2);'),
 'promise-methods-async':("  assert.sameValue(trace, 'RFV');","  assert.sameValue(trace, 'RFV!');"),
 'promise-with-resolvers':("assert.sameValue(Object.keys(record).join(','), 'promise,resolve,reject');","assert.sameValue(Object.keys(record).join(','), 'resolve,promise,reject');"),
 'promise-try':("  assert.sameValue(trace, 'NTCR');","  assert.sameValue(trace, 'NTCR!');")}
for p in profiles[1:5]: changes[p]=("  assert.sameValue(trace, 'GrrV');","  assert.sameValue(trace, 'GrrV!');")
variants=[]; lookup={}
for family,source in sources.items():
 old,new=changes[family]; assert source.count(old)==1
 mismatch=source.replace(old,new)
 assert mismatch.replace(new,old)==source
 for variant,s in [('positive',source),('mismatch',mismatch)]:
  b=emit(f'literals/{family}-{variant}.js',s)
  row={'family':family,'variant':variant,'source':s,'source_binding':b,'source_sha256':sha(s.encode())}
  variants.append(row); lookup[(family,variant)]=row
 emit(f'diffs/{family}.patch',''.join(difflib.unified_diff(source.splitlines(True),mismatch.splitlines(True),fromfile=family+'-positive.js',tofile=family+'-mismatch.js')))
write('variants.json',variants)
# Published exact source snapshots and function bindings; never import or evaluate project code.
source=W/'tools/test262_conformance.py'; code=source.read_bytes()
published=subprocess.run(['git','show',BASE+':tools/test262_conformance.py'],cwd=W,check=True,stdout=subprocess.PIPE).stdout
assert code==published
emit('source-snapshots/test262_conformance.py',code.decode())
tree=ast.parse(code); funcs=[]
for n in tree.body:
 if isinstance(n,ast.FunctionDef) and (('preflight' in n.name and any(v in n.name for v in ['promise','with_resolvers'])) or n.name in ['harness_names','case_fingerprint','run_case','classify','classify_promise','validate_promise_observation','decode_response','profile_intrinsic_errors','unsupported_reason']):
  s=ast.get_source_segment(code.decode(),n).encode(); funcs.append({'name':n.name,'line':n.lineno,'bytes':len(s),'sha256':sha(s)})
write('published-function-bindings.json',{'base':BASE,'source':bind(source),'snapshot':bind(D/'source-snapshots/test262_conformance.py'),'functions':funcs})
census=json.loads((R/'census.json').read_text()); old_prefix=[]; old_lookup={}; helper_bindings={}; report_bindings=[]
for entry in census['profiles']:
 p=entry['profile']; report=Path(entry['candidate_report']['path']); rb=report.read_bytes(); assert sha(rb)==entry['candidate_report']['sha256']
 data=json.loads(rb); controls=data['harness_preflight']; assert len(controls)==entry['existing_controls']
 rows=[]
 for item in controls:
  r=item['result']; row={'name':item['name'],'expected':item['expected'],'id':r['id'],'file':r['file'],'mode':r['mode'],'case_sha256':r['case_sha256'],'source_sha256':r['source_sha256'],'expected_negative':r['expected_negative'],'prerequisites':item['prerequisites']}
  rows.append(row);old_lookup[(p,item['name'],r['mode'])]=row
 old_prefix.append({'profile':p,'count':len(rows),'ordered_rows':rows,'source_report':bind(report),'qualification':'Existing immutable identity/prerequisite prefix only. New expected control observations are not derived from prior report outcomes.'})
 report_bindings.append(bind(report))
 corpus=W/'tests/upstream'/('test262-'+p)
 for name in ['assert.js','sta.js']+([] if p=='promise-with-resolvers' else ['doneprintHandle.js']):
  hp=corpus/'harness'/name; b=hp.read_bytes()
  parent=subprocess.run(['git','show',BASE+':'+str(hp.relative_to(W))],cwd=W,check=True,stdout=subprocess.PIPE).stdout
  assert b==parent
  recorded=next(x for x in entry['authenticated_manifest_files'] if x['path']=='harness/'+name)
  assert sha(b)==recorded['sha256']
  helper_bindings[(p,name)]=bind(hp)
assert sum(x['count'] for x in old_prefix)==588
write('old-prefix-identities.json',old_prefix)
def reference(row): return {k:row[k] for k in ['name','mode','id','case_sha256','source_sha256','expected']}
def newname(p,f,v): return 'class-'+p+'-'+f+'-'+v
records=[]; index={}
for p in profiles:
 ordinary=p=='promise-with-resolvers'
 for mode in ['sloppy','strict']:
  for family in ['construction','species',p]:
   f='subclass' if family==p else family
   policy=0 if ordinary or family in ['construction','species'] else 1
   for variant in ['positive','mismatch']:
    source_row=lookup[(family,variant)]; positive=variant=='positive'; name=newname(p,f,variant)
    expected='passed' if positive else 'failed' if ordinary else 'completion-error' if policy else 'synchronous-exception'
    metadata={'flags':['async'] if policy else [],'includes':[],'features':['class'],'locale':[],'negative':None}
    names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])
    helpers=[{'name':n,'sha256':helper_bindings[(p,n)]['sha256']} for n in names]
    fingerprint={'source_sha256':source_row['source_sha256'],'mode':mode,'metadata':metadata,'harness':helpers}
    if not ordinary: fingerprint['completion_policy']=policy
    case_hash=sha(json.dumps(fingerprint,sort_keys=True,ensure_ascii=True).encode())
    observation={'status':'complete','phase':'runtime','error_type':'','error_identity':'','message':'','harness':''}
    message_rule={'kind':'exact','value':''}
    if not positive:
     if policy:
      observation.update(status='host-failure',phase='host',message='completion-error');message_rule={'kind':'exact','value':'completion-error'}
     else:
      observation.update(status='exception',error_type='Test262Error');del observation['message'];message_rule={'kind':'bounded-diagnostic','type':'str','max_utf8_bytes':16384,'qualification':'Helper assertion wording is not an oracle; all other raw fields are exact.'}
    if not ordinary:
     counts=(1,1,0) if policy else (0,0,0); flags=0
     if not positive:
      if policy:counts=(1,0,1);flags=1
      else:flags=256
     observation['completion']={'policy':policy,'done_calls':counts[0],'success_prints':counts[1],'failure_prints':counts[2],'flags':flags,'quiescent':True,'audited':True,'unhandled':0}
    old_names=['strict-success' if mode=='strict' else 'success','with-resolvers-genuine'] if ordinary else ['promise-methods-promise-api-positive']
    if policy:old_names+=['promise-methods-one-async-completion']
    refs=[reference(old_lookup[(p,n,mode)]) for n in old_names]
    if f in ['species','subclass']:refs.append(reference(index[(p,mode,'construction','positive')]))
    if f=='subclass':refs.append(reference(index[(p,mode,'species','positive')]))
    if not positive:refs.append(reference(index[(p,mode,f,'positive')]))
    row={'profile':p,'family':f,'literal_family':family,'variant':variant,'name':name,'mode':mode,'id':'harness-preflight:'+name,'file':'<preflight>','source':source_row['source'],'source_binding':source_row['source_binding'],'source_sha256':source_row['source_sha256'],'metadata':metadata,'harness':helpers,'case_sha256':case_hash,'expected':expected,'expected_status':'passed' if positive else 'failed','expected_negative':None,'required_observation':observation,'message_rule':message_rule,'prerequisites':refs,'request_protocol':'ERJS1' if ordinary else 'ERJS2','response_protocol':'ERJR2' if ordinary else 'ERJR3'}
    if not ordinary:row['completion_policy']=policy
    records.append(row);index[(p,mode,f,variant)]=row
assert len(records)==84
for row in records:
 assert len({(x['name'],x['mode']) for x in row['prerequisites']})==len(row['prerequisites'])
 assert all(r['mode']==row['mode'] for r in row['prerequisites'])
write('cases.json',records)
counts=[{'profile':p,'old':next(x['count'] for x in old_prefix if x['profile']==p),'new':12,'total':next(x['count'] for x in old_prefix if x['profile']==p)+12} for p in profiles]
write('derivations.json',{
 'authorship':'Independent standard/source derivations before new producer changes; no runtime results were read for the new literals.',
 'shared_construction':'Explicit Base construction appends B; default Derived forwards 7. Calling Base without new rejects before parameter defaults, and a method has no [[Construct]]. Default Leaf forwards the exact executor to explicit SubPromise, appending P and creating native Promise state with Leaf prototype. PromiseResolve with Leaf returns that exact genuine Promise. The final trace is BP. The promise remains pending, so the synchronous mismatch has no queued reaction work.',
 'shared_species':'A pending genuine NativePromise has a class Alternate species. NewPromiseCapability calls its executor once, accepts callable resolve/reject and returns the exact alternate object without requiring super. Reusing captured executor throws TypeError; InvalidCapture with numeric resolve/reject is rejected. Pending source Promise schedules no jobs, so the final one-to-two call-count mismatch is a synchronous assertion, not an unhandled job.',
 'methods':'SubError identity is preserved through SubPromise.reject and catch; catch returns 7, finally preserves it, the final handler appends V after R then F. All produced rejections are handled in the same source; the final paired assertion routes to authenticated $DONE via the following then.',
 'combinators':'NewPromiseCapability uses SubPromise; GetPromiseResolve reads its getter once, and the returned function is reused for both inputs despite replacing SubPromise.resolve on the first call. The receiver remains SubPromise, trace Grr before jobs. All preserves [3,4], race first fulfills 3, allSettled preserves fulfilled 3 and exact rejection sentinel, Any fulfills 4 after a handled rejection. Final handler appends V, yielding GrrV.',
 'with_resolvers':'The inherited static method constructs a native SubPromise capability and returns an ordinary Object-prototype record with own enumerable/writable/configurable promise, resolve, reject in order. PromiseResolve confirms genuine same-constructor identity. Resolving then rejecting the same capability leaves no rejected promise; no async completion policy is introduced.',
 'try':'Same-constructor genuine seed is returned directly after callback N without construction. A callback appends T then throws; capability construction appends C afterwards. Later observation constructors are excluded from this deliberate measurement by disabling the flag, and the rejection handler sees the exact sentinel and appends R: NTCR. Its paired last assertion flows through the authenticated $DONE rejection handler.',
 'pairs':{k:{'positive_terminal_assertion':v[0],'mismatch_terminal_assertion':v[1],'single_line_inverse_exact':True} for k,v in changes.items()},
 'expected_raw':'Success and asynchronous mismatch observations are fully exact. Synchronous Test262Error diagnostic text is explicitly bounded UTF-8, not wording-frozen; all other fields and every completion member are exact.',
 'legacy':'The old 588 controls are exact ordered prefixes. Their existing raw validation criteria, source/case/helper identities, prerequisites and status conventions are unchanged. New metadata features are class only; no upstream metadata or negative expansion.',
 'parent_prediction':'With the published old feature sets, all 84 new controls are metadata-unsupported before any adapter invocation (reason: unimplemented declared features: class). This predicts dispatch eligibility only; the actual run is root-owned.'})
write('gate-contract.json',{
 'outer_keys':['name','expected','verified','result','prerequisites'],'result_keys':['id','file','mode','case_sha256','source_sha256','expected_negative','status','observation'],
 'new_reference_keys':['name','mode','id','case_sha256','source_sha256','expected'],
 'canonical_order':'Per profile: preserve complete existing prefix in its existing order; append cases.json rows for that profile in their listed mode/family/variant order.',
 'existing_prefix_count':588,'new_rows':84,'selected_total':672,'with_unchanged_aggregate_error_controls':724,
 'profiles':counts,'requirements':[
 'Require both unchanged existing profile health gate and the canonical class gate before any original case dispatch or baseline mutation.',
 'Reconstruct canonical identities from held source literals, exact metadata and authenticated helper bytes; reject missing/extra/duplicate/wrong-order rows and malformed exact outer/result/reference schemas.',
 'Recheck every old prefix row using its canonical identity and existing profile-selected raw verifier/classifier semantics; preserve its old prerequisite representation and order. Do not treat supplied verified flags as evidence.',
 'New rows use exact required_observation fields and declared message_rule; host dictionaries include the full exact completion object, ordinary dictionaries have exactly six fields and no completion. Empty harness attribution is mandatory.',
 'Require result classification from the unchanged selected decoder/validator/classifier, exact expected status and expected_negative null, plus exact supplied canonical reference identity/order.',
 'Check all prerequisites recursively against their own revalidated rows, refusing missing references, forged positive evidence, cross-mode substitutions and cycles. Verify True is necessary only after these checks.',
 'Any alone retains the eighth intrinsic AggregateError identity. Other profiles retain seven; custom SubError diagnostic names do not extend private identities.',
 'Existing arbitrary feature-set callers, host fatal/Unhandled rejection audit, ordinary ERJR3 refusal, and all case/baseline bytes remain unchanged except the selected measured seven baseline updates later.'
 ],'helper_closure':{'new_sources':['assert.js','sta.js'],'async_only_addition':'doneprintHandle.js','includes':[],'new_helper_files':0},
 'raw_field_bounds':'Every ordinary field is str and <=16384 UTF-8 bytes. Host numeric completion types are exact int (not bool); audited/quiescent exact bool. Legacy validators remain authoritative in addition to the frozen exact new evidence.',
 'open_design_issues':['Producer may choose compact implementation storage and public wrapper names, but must preserve the frozen source/metadata/helper/prerequisite order and identities.','Actual outcomes for newly eligible original 40 modes and all controls remain unmeasured; no positive runtime result or baseline total is selected.']})
inputs=[R/'readiness.json',R/'source-ready.json',R/'census.json',H/'root/selection-provisional.json',H/'root/selection-1.json',H/'root/setup.json',H/'source-parent.json',Path('/tmp/eris-class-runtime-plan-1/public-contract-1/spec-basis.json'),Path('/tmp/eris-promise-try-runtime-plan-1/root/spec-observation-1.json')]
assert sha((H/'source-parent.json').read_bytes())=='4e1e68153ca84772cba682f56c08b302c412205cf7de42fe2bc73520ece35619'
# All helper source objects already exist and remain Git-exact; the new rows add no bytes.
write('helper-bindings.json',{'base':BASE,'bindings':[{'profile':p,'name':n,**b} for (p,n),b in helper_bindings.items()]})
write('input-bindings.json',{'base':BASE,'selected_inputs':[bind(p) for p in inputs],'published_runner':bind(source),'legacy_identity_reports':report_bindings,'qualification':'Local frozen official-spec paraphrases and published helper/runner text supplied the standards/protocol basis. No new project or adapter execution and no remote fetch.'})
checks={
 'status':'source checks passed','base':BASE,'source_literals':18,'logical_pairs':9,'new_profile_rows':84,'old_prefix_rows':588,'selected_total':672,'all_eight_profile_total':724,
 'per_profile':counts,'new_host_rows':72,'new_ordinary_rows':12,'new_async_host_rows':24,'new_checked_sync_host_rows':48,
 'new_positive_rows':42,'new_mismatch_rows':42,'single_terminal_line_pairs':9,'canonical_prerequisite_edges':sum(len(r['prerequisites']) for r in records),
 'published_runner_bytes_exact':True,'new_helpers':0,'helper_bindings_git_and_manifest_exact':True,'all_prerequisites_same_mode':True,
 'no_project_import_execution_or_live_edit':True,'no_new_runtime_observations':True,
 'qualification':'This is a source-derived literal/oracle contract, not an assertion that the unexecuted candidate or originals pass. Legacy reports provide only immutable old identity prefixes.'}
write('checks.json',checks)
files=[p for p in sorted(D.rglob('*')) if p.is_file() and p.name not in ['source-ready.json','literal-ready.json']]
literal={'status':'frozen literals and canonical expected evidence before producer changes','base':BASE,'variants':bind(D/'variants.json'),'cases':bind(D/'cases.json'),'derivations':bind(D/'derivations.json'),'gate_contract':bind(D/'gate-contract.json'),'checks':bind(D/'checks.json'),'literal_files':[bind(p) for p in sorted((D/'literals').glob('*.js'))],'single_terminal_line_diffs':[bind(p) for p in sorted((D/'diffs').glob('*.patch'))]}
write('literal-ready.json',literal)
manifest={'status':'source-ready independent literal/control contract','base':BASE,'scope':'Class admission guards for seven existing Promise profiles; no implementation or observed health claim.','literal_seal':bind(D/'literal-ready.json'),'files':[bind(p) for p in files],'counts':checks,'open_design_issues':json.loads((D/'gate-contract.json').read_text())['open_design_issues'],'no_project_execution_or_live_edits':True}
write('source-ready.json',manifest)
print(json.dumps({'source_ready':bind(D/'source-ready.json'),'literal_ready':bind(D/'literal-ready.json'),'cases':bind(D/'cases.json'),'counts':checks},indent=2))
