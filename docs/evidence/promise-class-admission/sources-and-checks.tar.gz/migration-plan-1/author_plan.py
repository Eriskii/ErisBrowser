"""Write source-derived migration instructions only; no repository edits/imports."""
import ast, hashlib, json
from pathlib import Path
H=Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';M=H/'migration-plan-1';R=H/'readiness-1'
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
matrix={
'test_test262_promise_runner.py':{
'test_complete_corpus_modes_helpers_and_policy_identity':'Current PROFILE_FEATURES equals old oracle features plus class. The current-profile refusal loop must retain cross-realm and permit class-only metadata; keep all source/helper/mode/protocol identities exact.',
'test_failed_preflight_blocks_all_modes_and_refuses_baseline':'Overlay only class onto expected new_policy.supported_features and independently recompute its hash; keep all 458 blocked cases and existing bad-guard fixtures.',
'test_healthy_report_preserves_host_policy_reason_and_unsupported_denominator':'Overlay only current serialized policy/hash. Preserve explicit set(self.oracle[features]) in observed(), all 458 synthetic calls and historical class/cross-realm exclusions.'},
'test_test262_promise_all_profile.py':{
'test_runner_load_retains_196_exact_identities_and_four_class_modes':'Only current PROFILE_FEATURES expectation gains class. Retain explicit oracle-feature unsupported_reason calls, four historical class refusals and case identities including class_excluded metadata labels.',
'test_bad_preflight_blocks_all_196_without_dropping_exclusions_or_recording_baseline':'Overlay only expected policy/hash. Preserve 196 blocked cases and bad legacy gate assertions.',
'test_mock_healthy_report_keeps_host_policy_failure_and_all_modes_in_denominator':'Overlay only current policy/hash. Keep frozen explicit oracle features and synthetic failed192/unsupported4 result.',
'test_existing_232_458_profile_bytes_identities_guards_and_policy_are_unchanged':'Overlay class only in expected current methods policy/hash; old manifest/case/control bytes and 74 guard rows remain exact.'},
'test_test262_promise_race_profile.py':{
'test_loader_keeps_188_exact_identities_ordered_harness_and_integer_policies':'Only current PROFILE_FEATURES expectation gains class; explicit oracle-feature exclusions remain four and all identities/protocol refusals stay exact.',
'test_bad_gate_blocks_all_188_without_case_execution_or_baseline':'Overlay only expected current policy/hash; preserve all bad legacy gate fixtures and blocked188.',
'test_synthetic_reporting_retains_host_veto_and_refuses_bad_run_baselines':'Overlay only expected current policy/hash; retain explicit old features and failed184/unsupported4 synthetic result plus infrastructure refusals.',
'test_existing_55_tables_and_both_promise_profiles_remain_exact':'Overlay only selected current policies/hashes for methods/all. Retain all55 importer tables, old manifests, 458/196 case identities and 74/90 guard identities.'},
'test_test262_promise_all_settled_profile.py':{
'test_loader_keeps_208_exact_identities_ordered_harness_and_integer_policies':'Only current PROFILE_FEATURES expectation gains class; preserve explicit oracle-feature refusals for four modes and all metadata/fingerprints.',
'test_bad_gate_blocks_all_208_without_case_execution_or_baseline':'Overlay only expected current policy/hash, keep blocked208 and every bad old-gate fixture.',
'test_synthetic_reporting_retains_host_veto_and_refuses_bad_run_baselines':'Overlay only expected current policy/hash; preserve explicit old feature set and failed204/unsupported4 synthetic result.',
'test_existing_56_tables_and_all_three_promise_profiles_remain_exact':'Apply class only to expected current features and policies for methods/all/race; keep all56 importer tables and 74/90/90 old controls/cases/manifests exact.'},
'test_test262_aggregate_error_preservation.py':{'test_all_57_old_tables_features_and_actual_report_policies_remain_exact':'Overlay class for the four selected historical Promise profiles in expected feature/policy copies; retain all57 profiles, importer tables, all other fields/hashes and empty-case policy construction.'},
'test_test262_promise_any_preservation.py':{'test_all_58_old_tables_features_and_actual_main_policies_remain_exact':'Overlay class for the four selected historical Promise profiles only; retain all58 entries and22 unchanged runner-body seals.'},
'test_test262_with_resolvers_preservation.py':{'test_all_59_old_tables_features_and_actual_main_policies_remain_exact':'Overlay class for methods/all/race/allSettled/Any only; retain all59 profiles and unchanged-function seals.'},
'test_test262_promise_try_preservation.py':{'test_all_60_old_tables_features_and_actual_main_policies_remain_exact':'Overlay class for the six selected historical Promise profiles including withResolvers only; retain all60 entries and all74 unchanged function seals.'},
'test_test262_promise_any_protocol.py':{'test_any_capability_is_local_and_old_sets_are_not_mutated':'Compare current PROFILE_FEATURES to FEATURES | {class}; leave module FEATURES and every explicit caller feature/identity/negative/completion refusal unchanged.'},
'test_test262_with_resolvers_protocol.py':{'test_feature_identity_and_host_sets_remain_separate':'Both current feature-set expectations gain class; module FEATURES stays exactly {promise-with-resolvers}, including caller class refusals and completion-policy early rejection.'},
'test_test262_promise_try_protocol.py':{'test_selected_features_host_family_and_seven_identity_boundary':'Both current feature-set expectations gain class; module FEATURES remains {Reflect.construct,promise-try}, preserving explicit class/async/unknown refusal fixtures and decoder/classifier arities.'},
'test_test262_with_resolvers_controls.py':{
'test_frozen_44_literals_metadata_helpers_modes_and_references_are_exact':'Only current profile features expectation gains class. Preserve all44 old variants/cases/expectations/prerequisites/helpers byte/value exact.',
'test_healthy_gate_allows_mocked_dispatch_and_baseline_without_host_policy':'The main-to-run_case feature argument now includes class. Preserve all12 synthetic dispatches, ordinary policy fields and baseline/schema assertions; wire only the independent new class-gate mock as needed.'},
'test_test262_promise_try_loader.py':{'test_actual_loader_admits_all_30_host_identities_and_exact_helper_bytes':'Only final current PROFILE_FEATURES expectation gains class. Preserve all30 ordered identities, six class-tagged metadata modes, eight async modes and unchanged helper bytes.'},
}
rows=[]
for filename,changes in matrix.items():
 p=W/'tools'/filename;s=p.read_text();t=ast.parse(s);methods={n.name:n for n in ast.walk(t) if isinstance(n,ast.FunctionDef)}
 out=[]
 for name,action in changes.items():
  n=methods[name];body=ast.get_source_segment(s,n)
  out.append(dict(function=name,line=n.lineno,end_line=n.end_lineno,source_sha256=sha(body.encode()),action=action))
 rows.append(dict(path='tools/'+filename,before=bind(p),groups_total=sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for c in t.body if isinstance(c,ast.ClassDef) for n in c.body),affected_groups=out))
assert len(rows)==13 and sum(len(x['affected_groups']) for x in rows)==25
contexts=json.loads((M/'reviewed-contexts.json').read_text())
policies=json.loads((M/'policies.json').read_text())
identities=json.loads((R/'corpus-and-identity-refresh.json').read_text())
plan=dict(status='Sealed source-only exact feature/policy migration census; no payload or baseline update',base=BASE,
 counts=dict(deterministic_test_paths=13,deterministic_test_groups=25,retained_groups_in_those_paths=sum(x['groups_total'] for x in rows),explicit_caller_methods=len(contexts['explicit_caller_fixtures']),main_fixture_definitions=len(contexts['main_fixtures']),current_profiles=61,changed_policies=7,unchanged_policies=54,baseline_paths=7),
 deterministic_test_migrations=rows,
 expected_overlay_recipe=[
  'Keep all historical oracle JSON bytes and their hardcoded ORACLE_SHA values. Use a copied expected feature list/set: add only class if the explicit profile name is in the fixed seven-profile selection.',
  'For expected current policy, deep-copy the historical policy, set supported_features to sorted(old supported_features union {class}) only for selected profiles, retain every other field, then SHA-256 json.dumps(policy, sort_keys=True).encode(). Never derive expected policy from production constants or actual reports.',
  'Never remove selected profile entries from old preservation loops or accept arbitrary hash changes. Seven exact new policies/hashes are independently frozen in policies.json; all other54 remain identical.',
  'No test group deletion/rename is required for this migration. Keep metadata labels such as class_excluded in historical identity records; they record old metadata, not new runner admission.',
  'Historical explicit caller FEATURES and set(self.oracle[features]) stay unchanged. Add separate current-profile admission coverage rather than changing the caller contract.'
 ],
 main_fixture_wiring=dict(status='Exact source callsite census; adapter change is conditional on selected producer interfaces',fixtures=[{k:v for k,v in row.items() if k!='source'} for row in contexts['main_fixtures']],
  obligations=[
   'Shared PromiseRunnerTests.report supplies legacy-only mocked preflight; its healthy uses must supply/mock the new class gate separately. All/allSettled/race call this helper, so avoid duplicating changes in every test.',
   'Four empty-case historical policy tests must mock the new selected class gate healthy for their selected profile rows, while retaining no-run_case assertions and all actual policy construction.',
   'withResolvers healthy main fixture must satisfy the new gate independently, update only current feature argument, and retain12 synthetic dispatches. Its bad legacy gate fixture must still prove exact raw preflight preservation and no baseline mutation.',
   'Any/Try bad-main fixtures contain poisoned old raw evidence and run_case sentinels. A new entrypoint must not evade them: preserve old bad-gate refusal, blocked1/30 counts, order and baseline sentinels. If main still consumes the same mocked generic preflight and short-circuits old failure, no edit is necessary.',
   'Keep all legacy factory/health helper calls direct so their74/90/90/94/102/44/94 rows and tests remain unchanged. Only the selected outer wrapper may append new class rows. No legacy guard oracle/count retuning.'
  ],qualification='Names and exact patch expressions await root-selected wrapper/gate interfaces. This census does not claim an already reviewed executable migration payload.'),
 baseline_migration=[dict(profile=p['profile'],before=p['baseline'],schema=p['baseline_schema'],old_policy_sha256=p['old_policy_sha256'],new_policy_sha256=p['proposed_policy_sha256'],ordered_case_identity_digest=p['ordered_case_digest'],modes=p['modes'],class_modes_newly_eligible=p['class_modes'],prior_status_counts=p['baseline_status_counts'],action='Record only after measured full replay and independent transition review. Keep case/source hashes, revision and manifest hash exact; status and binary provenance come from actual observations.') for p in identities['profiles']],
 unchanged_scope=[
  'All643 original sources/1280 ordered modes, all588 old controls and every helper byte/order; importers, manifests, metadata and corpus proofs remain unchanged.',
  'Generic SUPPORTED_FEATURES, all54 other profile feature sets/policies, default arities, decoders, validators, classifiers, request formats, identity policies and host audit remain unchanged.',
  'The prior74 importer/runner function seals and Any22 seal remain exact. New class wrappers must be additive around those old functions.',
  'All68 top-level Python test modules/683 group identities retained. Separate13 Vulkan-probe modules/115 groups remain outside this migration.',
  'All other baseline files remain byte exact, including AggregateError50-mode ordinary profile. Existing CI has seven profile invocations; no workflow command addition is necessary.'
 ],
 source_review_qualification='No importer/runner implementation or new class-control payload is authored/reviewed by this census. Only existing published code, prior immutable evidence and provisional scope are interpreted; measured outcomes remain pending.')
dump(M/'migration-plan.json',plan)
joins=json.loads((R/'published-joins.json').read_text())
readiness=dict(status='clear additive published-base readiness refresh',base=BASE,prior=bind(Path('/tmp/eris-promise-class-admission-readiness-1/source-ready.json')),prior_published_refresh=bind(Path('/tmp/eris-promise-class-admission-readiness-1/published-base-refresh-1.json')),
 prior_bound_union=dict(paths=1937,unchanged=1931,changed=6,changes=joins['differences'],qualification='Only native Line implementation/test paths changed. This is the prior bound union, not the complete graph or current entire source inventory.'),
 source_claims=['Every Promise/class runtime, runner/importer, selected corpus/helper/proof/manifest and baseline byte used by prior readiness remains published-byte identical.',
 'Seven profiles contain643 originals/1280 ordered modes and588 existing guards;20 originals/40 modes become metadata-eligible only through class. Eligibility is not an outcome.',
 'Four feature declarations suffice: PROMISE_FEATURES propagates to methods/all/race/allSettled; Any/withResolvers/Try have standalone sets. Generic defaults and54 other profiles remain exact.',
 'Six profiles retain ERJS2/ERJR3 and existing completion/unhandled policy; withResolvers remains ordinary ERJS1/ERJR2. Any alone keeps the AggregateError eighth identity among these seven.',
 'Methods cross-realm2 and Any destructuring4 metadata exclusions remain; the implemented subset still excludes fields/private/static blocks/super properties/async/generator methods.',
 'Previous class-runtime changes to untagged source outcomes are historical comparison facts, not predicted effects of this admission. Seven actual compact baseline updates await measured replay.'],
 identity_refresh=bind(R/'corpus-and-identity-refresh.json'),policy_census=bind(M/'policies.json'),migration_plan=bind(M/'migration-plan.json'),python_roster=bind(M/'python-roster.json'),
 proposed_code_seams=['Four class feature-set additions; additive selected-profile class preflight wrapper and fail-closed outer health gate; main-selected routing; no change to legacy factories/gates/validator/classifier bodies.'],
 independent_controls='Root owns selection of separately frozen new class literals/contracts and raw gate tests. This readiness does not replace their independent peer.',
 validation_limits='Read-only Git/filesystem and stdlib AST/JSON/hash analysis only. No project modules imported, no test/build/engine/adapter/network execution, no live source or baseline edits; old F/G plans untouched.')
dump(R/'readiness.json',readiness)
print(json.dumps(plan['counts'],indent=2))
