"""Independent retained-report audit; no project imports/execution or baseline writes."""
import collections,hashlib,json,pathlib
H=pathlib.Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';O=H/'profile-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def exact(a,b):return type(a) is type(b) and json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
verified={}
def walk(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys() and str(x['path']).startswith('/'):
   p=pathlib.Path(x['path']);assert bind(p)=={k:x[k] for k in ['path','bytes','sha256']},p;verified[str(p)]=x['sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
summary=load(H/'root/profile-candidate-1.json');parent=load(H/'root/profile-parent-1.json');contract=load(H/'profile-replay-2/contract.json');new_oracle=load(H/'control-contract-1/cases.json')
walk(summary);walk(parent);walk(contract);walk(new_oracle)
assert summary['status']=='pass' and summary['phase']=='candidate' and summary['baseline_writes'] is False
assert summary['parent_capture']==bind(H/'root/profile-parent-1.json')
assert summary['binaries']==parent['binaries'] and summary['contract']==parent['contract'] and summary['runner']==parent['runner']
inventory=load(summary['source_inventory']['path']);old_inventory=load(parent['source_inventory']['path'])
for rel,expected in inventory['source_sha256'].items():assert sha((W/rel).read_bytes())==expected,rel
for rel,expected in old_inventory['source_sha256'].items():
 if rel.startswith(('src/','shaders/','assets/')) or rel in {'Cargo.toml','Cargo.lock','build.rs'}:assert inventory['source_sha256'][rel]==expected,rel
assert inventory['source_sha256']['tools/test262_conformance.py']==contract['runner_sha256']['candidate']
for tree,expected in contract['preserved_trees'].items():
 assert {str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/tree).rglob('*') if p.is_file()}==expected,tree
identity=('id','file','mode','case_sha256','source_sha256','expected_negative')
raw_fields={'status','phase','error_type','error_identity','message','harness'}
int_fields={'policy','done_calls','success_prints','failure_prints','flags','unhandled'}
def raw_schema(raw,host):
 assert type(raw) is dict and set(raw)==raw_fields|({'completion'} if host else set())
 for k in raw_fields:assert type(raw[k]) is str and len(raw[k].encode('utf-8'))<=16384
 if host:
  c=raw['completion'];assert type(c) is dict and set(c)==int_fields|{'quiescent','audited'}
  for k in int_fields:assert type(c[k]) is int and c[k]>=0
  assert type(c['quiescent']) is bool and type(c['audited']) is bool
profiles=[];transitions=[];new_controls=[];cases_total=collections.Counter();failure_reasons=collections.Counter();failure_records=[];baseline_rows=[];cumulative=collections.Counter();carried=collections.Counter();new=collections.Counter();edges=0;old_control_count=0
bmap={p['profile']:p for p in load(O/'baseline-parent-comparison.json')['profiles']}
for row,prior,p in zip(summary['profiles'],parent['profiles'],contract['profiles']):
 assert row['profile']==prior['profile']==p['profile'] and row['errors']==[] and row['before']==prior['report']
 r=load(row['report']['path']);a=load(prior['report']['path']);receipt=load(row['receipt']['path']);host=p['binary_kind']=='host'
 assert set(r)==set(a)
 for key in ['suite','full_test262_conformance','repository','revision','corpus_manifest_sha256','source_files','source_tests','negative_source_tests','fixture_files','mode_cases','binary','binary_sha256']:
  assert exact(r[key],a[key]),(p['profile'],key)
 assert r['full_test262_conformance'] is False and r['harness_preflight_passed'] is True
 assert r['regressions']==r['improvements']==[]
 assert r['runner_policy']==p['policy']['after'] and r['runner_policy_sha256']==p['policy']['after_sha256']==sha(json.dumps(r['runner_policy'],sort_keys=True).encode())
 expected=dict(a['runner_policy'])
 if p['profile']!='aggregate-error':expected['supported_features']=sorted(set(expected['supported_features'])|{'class'})
 assert r['runner_policy']==expected
 assert [{k:x[k] for k in identity} for x in r['cases']]==p['case_identities']
 assert len({x['id'] for x in r['cases']})==len(r['cases'])==p['cases']
 assert r['counts']==dict(collections.Counter(x['status'] for x in r['cases']))==row['counts'];cases_total.update(r['counts'])
 command=receipt['command'];assert command[1:]==['-B','tools/test262_conformance.py','--binary',r['binary'],'--profile',p['profile'],'--output',row['report']['path'],'--jobs','1','--timeout','3.0']
 assert not any('baseline' in x for x in command);assert receipt['exit']==row['observed_exit']==(0 if all(x['status']=='passed' for x in r['cases']) else 1)
 assert receipt['sha256']==row['log']['sha256'];log=pathlib.Path(row['log']['path']).read_text();assert str(r['counts']) in log and 'Upstream harness preflight: passed' in log
 old=r['harness_preflight'][:p['controls']];suffix=r['harness_preflight'][p['controls']:];frozen=[x for x in new_oracle if x['profile']==p['profile']]
 assert exact(old,a['harness_preflight']) and exact(frozen,p['new_controls']) and len(suffix)==len(frozen)
 assert all(x['verified'] is True for x in r['harness_preflight'])
 keys=[(x['name'],x['result']['mode']) for x in r['harness_preflight']];assert len(set(keys))==len(keys);lookup=dict(zip(keys,r['harness_preflight']))
 old_control_count+=len(old)
 for actual,oracle in zip(suffix,frozen):
  assert set(actual)=={'name','expected','verified','result','prerequisites'}
  assert actual['name']==oracle['name'] and actual['expected']==oracle['expected']
  q=actual['result'];assert set(q)==set(identity)|{'status','observation'};assert {k:q[k] for k in identity}=={k:oracle[k] for k in identity}
  assert exact(actual['prerequisites'],oracle['prerequisites'])
  raw=q['observation'];raw_schema(raw,host);assert raw['harness']==''
  required=oracle['required_observation'];assert all(exact(raw[k],v) for k,v in required.items())
  rule=oracle['message_rule'];assert (raw['message']==rule['value']) if rule['kind']=='exact' else (rule['kind']=='bounded-diagnostic' and len(raw['message'].encode('utf-8'))<=rule['max_utf8_bytes'])
  assert q['status']==oracle['expected_status']==('passed' if raw['status']=='complete' else 'failed')
  fp=dict(source_sha256=sha(oracle['source'].encode()),mode=oracle['mode'],metadata=oracle['metadata'],harness=oracle['harness'])
  if 'completion_policy' in oracle:fp['completion_policy']=oracle['completion_policy']
  assert sha(json.dumps(fp,sort_keys=True,ensure_ascii=True).encode())==q['case_sha256']
  for helper in oracle['harness']:
   path=W/'tests/upstream'/('test262-'+p['profile'])/'harness'/helper['name'];assert sha(path.read_bytes())==helper['sha256']
  for ref in actual['prerequisites']:
   target=lookup[(ref['name'],ref['mode'])];assert target['verified'] is True and target['result']['status']=='passed'
   assert ref==dict(name=target['name'],mode=target['result']['mode'],id=target['result']['id'],case_sha256=target['result']['case_sha256'],source_sha256=target['result']['source_sha256'],expected=target['expected'])
   assert ref['mode']==q['mode'];edges+=1
  new_controls.append(dict(profile=p['profile'],name=actual['name'],mode=q['mode'],expected=actual['expected'],status=q['status'],case_sha256=q['case_sha256'],source_sha256=q['source_sha256'],required_observation=raw,prerequisites=actual['prerequisites']))
 changed=[]
 for before,after in zip(a['cases'],r['cases']):
  if not exact(before,after):
   assert after['id'] in p['class_case_ids'] and before['status']=='unsupported' and after['status'] in {'passed','failed'}
   assert before['reason']=='unimplemented declared features: class'
   raw_schema(after['observation'],host)
   changed.append(dict(profile=p['profile'],id=after['id'],before=before,after=after));new[before['status']+'->'+after['status']]+=1
   if after['status']=='passed':
    assert after['observation']['status']=='complete' and after['observation']['phase']=='runtime' and after['observation']['harness']==''
    if host:assert after['observation']['completion']['audited'] is True and after['observation']['completion']['quiescent'] is True and after['observation']['completion']['unhandled']==0
   else:
    assert after['file'] in {'test/built-ins/Promise/reject/ctx-ctor.js','test/built-ins/Promise/any/ctx-ctor.js'}
    assert after['observation']==dict(status='host-failure',phase='host',error_type='',error_identity='',message='unhandled-rejection',harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1))
  if after['status']!='passed':
   raw=after.get('observation',{});reason=(after['status'],raw.get('status'),raw.get('phase'),raw.get('error_type'),raw.get('message'),after.get('reason'));failure_reasons[reason]+=1;failure_records.append(dict(profile=p['profile'],record=after))
 assert {x['id'] for x in changed}==set(p['class_case_ids']);transitions.extend(changed)
 assert len(changed)==len(row['case_record_changes']) and not row['control_record_changes'] and not row['prior_pass_regressions'] and not row['raw_only_changes'] and not row['outside_class_tag_changes']
 if p['profile'] in bmap:
  retained=bmap[p['profile']]['retained_before'];b=load(retained['path']);walk(retained);assert (W/bmap[p['profile']]['tracked_path']).read_bytes()==pathlib.Path(retained['path']).read_bytes()
  actual={x['id']:x for x in r['cases']};previous={x['id']:x for x in a['cases']};delta=[]
  assert b['revision']==r['revision'] and b['corpus_manifest_sha256']==r['corpus_manifest_sha256'] and set(b['cases'])==set(actual)
  for ident,bc in b['cases'].items():
   ac=actual[ident];pc=previous[ident];assert bc['case_sha256']==ac['case_sha256'] and bc['source_sha256']==ac['source_sha256']
   if bc['status']!=ac['status']:
    assert bc['status']!='passed';category='H class admission' if ident in p['class_case_ids'] else 'carried-forward prior runtime'
    cumulative[bc['status']+'->'+ac['status']]+=1
    if category.startswith('carried'):assert exact(pc,ac);carried[bc['status']+'->'+ac['status']]+=1
    delta.append(dict(id=ident,category=category,baseline=bc,parent_status=pc['status'],candidate=ac))
  baseline_rows.append(dict(profile=p['profile'],retained_baseline=retained,tracked_path=bmap[p['profile']]['tracked_path'],case_count=len(actual),policy_before=b['runner_policy_sha256'],policy_after=r['runner_policy_sha256'],binary_before=b['binary_sha256'],binary_after=r['binary_sha256'],changes=delta,no_baseline_pass_regressions=True))
 profiles.append(dict(profile=p['profile'],report=row['report'],parent_report=prior['report'],receipt=row['receipt'],log=row['log'],counts=r['counts'],case_count=len(r['cases']),old_controls=len(old),new_controls=len(suffix),class_transitions=len(changed),unchanged_cases=len(r['cases'])-len(changed),policy_sha256=r['runner_policy_sha256'],binary_sha256=r['binary_sha256']))
assert len(profiles)==8 and sum(x['case_count'] for x in profiles)==1330 and old_control_count==640 and len(new_controls)==84 and edges==246
assert dict(cases_total)==summary['counts']=={'passed':1258,'failed':64,'unsupported':8}
assert len(transitions)==40 and dict(new)=={'unsupported->passed':36,'unsupported->failed':4}
assert dict(carried)=={'unsupported->passed':20,'unsupported->failed':10} and dict(cumulative)=={'unsupported->passed':56,'unsupported->failed':14}
out=dict(status='clear',parent_review=bind(O/'parent-review.json'),candidate_summary=bind(H/'root/profile-candidate-1.json'),contract=bind(H/'control-contract-1/source-ready.json'),source_inventory=summary['source_inventory'],source_inventory_entries=len(inventory['source_sha256']),verified_bindings=len(verified),profiles=profiles,counts=dict(cases_total),total_cases=1330,unchanged_case_records=1290,unchanged_old_control_records=640,new_verified_controls=84,new_reference_edges=246,new_controls=new_controls,newly_eligible_transitions=transitions,newly_eligible_transition_counts=dict(new),cumulative_baseline_transition_counts=dict(cumulative),carried_forward_transition_counts=dict(carried),baselines=baseline_rows,nonpass_reasons=[dict(status=k[0],raw_status=k[1],phase=k[2],error_type=k[3],message=k[4],reason=k[5],modes=v) for k,v in failure_reasons.items()],nonpass_records=failure_records,baseline_writes=False,execution='Independent stdlib retained-report/source/hash analysis only; no project imports/execution or live edits.')
(O/'candidate-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='clear',counts=dict(cases_total),new=dict(new),carried=dict(carried),cumulative=dict(cumulative),checks=bind(O/'candidate-checks.json')),indent=2))
