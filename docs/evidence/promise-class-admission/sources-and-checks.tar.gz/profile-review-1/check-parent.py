"""Source/record audit only; no project imports or execution."""
import collections,hashlib,json,pathlib,re,subprocess
H=pathlib.Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';O=H/'profile-review-1';BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def exact(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
verified={}
def walk(d):
 if isinstance(d,dict):
  if {'path','bytes','sha256'}<=d.keys() and str(d['path']).startswith('/'):
   p=pathlib.Path(d['path']);assert bind(p)=={k:d[k] for k in ['path','bytes','sha256']},p;verified[str(p)]=d['sha256']
  for v in d.values():walk(v)
 elif isinstance(d,list):
  for v in d:walk(v)
summary=load(H/'root/profile-parent-1.json');contract=load(summary['contract']['path']);walk(summary);walk(contract)
assert summary['status']=='pass' and summary['phase']=='parent' and summary['baseline_writes'] is False
inventory=load(summary['source_inventory']['path']);assert inventory['base']==contract['base']==BASE
# Read authenticated published source inventory through one read-only Git batch.
paths=list(inventory['source_sha256']);request=''.join(BASE+':'+p+'\n' for p in paths).encode()
raw=subprocess.check_output(['git','cat-file','--batch'],cwd=W,input=request);position=0
for rel in paths:
 stop=raw.index(b'\n',position);header=raw[position:stop].split();assert header[1]==b'blob';size=int(header[2]);body=raw[stop+1:stop+1+size];position=stop+1+size+1
 assert sha(body)==inventory['source_sha256'][rel],rel
assert position==len(raw)
assert contract['runner_sha256']['parent']==inventory['source_sha256']['tools/test262_conformance.py']
# Parent capture reuses these exact copied builds; source binding is partial inventory, not a complete build graph.
for kind,item in summary['binaries'].items():
 record=load(item['sidecar']['path']);assert exact(record,item['record']);assert record['source_inventory']==summary['source_inventory']
 assert record['sha256']==item['binary']['sha256'] and record['bytes']==item['binary']['bytes'] and record['binary']==item['binary']['path']
 receipt=load(record['build']['path']);env=load(record['environment']['path']);assert receipt['exit']==0
 version='1.88.0' if kind=='ordinary' else '1.99.0';features=[] if kind=='ordinary' else ['test262-host']
 command=['cargo','+'+version,'build','--locked','--offline']+([] if not features else ['--features','test262-host'])+['--release','--bin','eris-js']
 assert receipt['command']==command and record['features']==features and record['toolchain']==version
 assert env['toolchain']==version and env['features']==([] if not features else ['--features','test262-host'])
 assert receipt['sha256']==item['build_log']['sha256'] and receipt['log']==pathlib.Path(item['build_log']['path']).name
 assert 'Finished' in pathlib.Path(item['build_log']['path']).read_text()
# Corpus/proof/helper and pre-mutation baseline trees are byte-exact to the frozen contract.
preserved=[]
for tree,expected in contract['preserved_trees'].items():
 actual={str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/tree).rglob('*') if p.is_file()};assert actual==expected,tree
 preserved.append(dict(tree=tree,files=len(actual),mapping_sha256=sha(json.dumps(actual,sort_keys=True).encode())))
identity=('id','file','mode','case_sha256','source_sha256','expected_negative');totals=collections.Counter();profiles=[];class_sources=[];class_modes=[]
immutable=('suite','full_test262_conformance','repository','revision','corpus_manifest_sha256','source_files','source_tests','negative_source_tests','fixture_files','mode_cases')
for row,p in zip(summary['profiles'],contract['profiles']):
 assert row['profile']==p['profile'] and row['errors']==[]
 report=load(row['report']['path']);before=load(row['before']['path']);receipt=load(row['receipt']['path'])
 assert row['before']==p['reference_report'];assert exact(report['cases'],before['cases']) and exact(report['harness_preflight'],before['harness_preflight'])
 assert all(exact(report[k],before[k]) for k in immutable)
 assert [{k:x[k] for k in identity} for x in report['cases']]==p['case_identities']
 assert len({x['id'] for x in report['cases']})==p['cases']==len(report['cases'])
 assert report['counts']==dict(collections.Counter(x['status'] for x in report['cases']))==row['counts'];totals.update(report['counts'])
 assert report['runner_policy']==p['policy']['before'] and report['runner_policy_sha256']==p['policy']['before_sha256']==sha(json.dumps(report['runner_policy'],sort_keys=True).encode())
 assert report['harness_preflight_passed'] is True and all(x['verified'] is True for x in report['harness_preflight'])
 assert len(report['harness_preflight'])==p['controls']
 assert [dict(name=x['name'],expected=x['expected'],**{k:x['result'][k] for k in identity},prerequisites=x['prerequisites']) for x in report['harness_preflight']]==p['old_control_identities']
 binary=summary['binaries'][p['binary_kind']]['binary'];assert report['binary']==binary['path'] and report['binary_sha256']==binary['sha256']
 command=receipt['command'];assert command[1:]==['-B','tools/test262_conformance.py','--binary',binary['path'],'--profile',p['profile'],'--output',row['report']['path'],'--jobs','1','--timeout','3.0']
 assert not any('baseline' in x for x in command);assert receipt['exit']==row['observed_exit']==(0 if all(x['status']=='passed' for x in report['cases']) else 1)
 assert receipt['sha256']==row['log']['sha256'];assert report['regressions']==report['improvements']==[]
 log=pathlib.Path(row['log']['path']).read_text();assert 'Upstream harness preflight: passed' in log and str(report['counts']) in log
 host=p['binary_kind']=='host';assert report['runner_policy']['async_completion']==host and report['runner_policy']['host_hooks']==host
 if host:assert report['runner_policy']['response_protocol']=='ERJR3' and report['runner_policy']['unhandled_rejection_policy']=='final-quiescent-veto'
 else:assert 'response_protocol' not in report['runner_policy']
 by_id={x['id']:x for x in report['cases']};source_paths=sorted({x.rsplit(':',1)[0] for x in p['class_case_ids']})
 corpus=W/'tests/upstream'/('test262-'+p['profile'])
 # Discover all class-tagged original sources independently from retained source headers.
 discovered=[]
 for js in (corpus/'test').rglob('*.js'):
  source=js.read_text();header=source.split('/*---',1)[1].split('---*/',1)[0] if '/*---' in source else ''
  features=re.search(r'^features:\s*\[([^\]]*)\]',header,re.M)
  if features and 'class' in [x.strip() for x in features[1].split(',')]:discovered.append(str(js.relative_to(corpus)))
 assert sorted(discovered)==source_paths,p['profile']
 for rel in source_paths:
  path=corpus/rel;b=path.read_bytes();s=b.decode();header=s.split('/*---',1)[1].split('---*/',1)[0]
  def field(name):
   q=re.search(r'^'+name+r':\s*\[([^\]]*)\]',header,re.M);return [x.strip() for x in q[1].split(',')] if q else []
  modes=[by_id[rel+':'+mode] for mode in ['sloppy','strict']]
  assert all(x['source_sha256']==sha(b) and x['status']=='unsupported' and x['reason']=='unimplemented declared features: class' and 'observation' not in x for x in modes)
  assert sha(b)==contract['preserved_trees'][str(corpus.relative_to(W))][str(path.relative_to(W))]
  class_sources.append(dict(profile=p['profile'],file=rel,binding=bind(path),features=field('features'),flags=field('flags'),includes=field('includes'),parent_modes=modes))
  class_modes.extend(x['id'] for x in modes)
 profiles.append(dict(profile=p['profile'],report=row['report'],prior_report=row['before'],receipt=row['receipt'],log=row['log'],cases=len(report['cases']),old_controls=len(report['harness_preflight']),counts=report['counts'],binary_kind=p['binary_kind'],binary_sha256=binary['sha256'],policy_sha256=report['runner_policy_sha256'],class_modes=len(p['class_case_ids']),full_case_array_exact=True,full_old_control_array_exact=True))
assert len(profiles)==8 and sum(p['cases'] for p in profiles)==1330 and sum(p['old_controls'] for p in profiles)==640
assert dict(totals)==summary['counts']=={'passed':1222,'failed':60,'unsupported':48}
assert len(class_sources)==20 and len(class_modes)==40 and sum('async' in s['flags'] for s in class_sources)==8
out=dict(status='clear-parent-capture',base=BASE,parent_summary=bind(H/'root/profile-parent-1.json'),replay_contract=summary['contract'],replay_source=summary['runner'],source_inventory=summary['source_inventory'],source_inventory_entries=len(paths),verified_input_bindings=len(verified),binaries=summary['binaries'],profiles=profiles,counts=dict(totals),total_cases=1330,total_old_controls=640,class_source_count=20,class_modes=40,async_class_modes=16,synchronous_class_modes=24,preserved_trees=preserved,class_sources=class_sources,baseline_writes=False,candidate_results='Not read; no inferred outcome.',execution='Only independent stdlib read/hash/JSON and read-only git cat-file. No project execution/imports or live edits.')
(O/'parent-checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='clear',source_entries=len(paths),bindings=len(verified),counts=dict(totals),class_sources=len(class_sources),checks=bind(O/'parent-checks.json')),indent=2))
