"""Independent final retained-evidence audit; no project imports/execution."""
import ast,collections,hashlib,json,pathlib,re,subprocess
H=pathlib.Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';O=H/'validation-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(pathlib.Path(p).read_bytes())
def exact(a,b):return json.dumps(a,sort_keys=True,separators=(',',':'))==json.dumps(b,sort_keys=True,separators=(',',':'))
verified={}
def walk(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys() and str(x['path']).startswith('/'):
   p=pathlib.Path(x['path']);assert bind(p)=={k:x[k] for k in ['path','bytes','sha256']},p;verified[str(p)]=x['sha256']
  for v in x.values():walk(v)
 elif isinstance(x,list):
  for v in x:walk(v)
ledger=load(H/'root/final-validation.json');assert bind(H/'root/final-validation.json')['sha256']=='a53c5cfc7348ec5fbfa9892a951e3ac18dae4ebea51c5f55fb5ccca59bb32965';walk(ledger)
parent=load(ledger['parent_capture']['path']);candidate=load(ledger['candidate_capture']['path']);gates=load(ledger['baseline_gates']['path']);update=load(ledger['baseline_update']['path'])
for x in [parent,candidate,gates,update]:walk(x)
for ref in ledger['independent_reviews']:
 review=load(ref['path']);walk(review);assert review['status'].startswith('clear')
source=load(ledger['source_inventory']['path']);first=load(ledger['source_candidate_1']['path']);second=load(ledger['source_candidate_2']['path']);base=load(H/'source-parent-2.json');original=load(H/'source-parent.json')
assert ledger['status']=='pass' and source['base']==base['base']==ledger['base']=='4538e99adb5023721ec6eeb120698919a3803a8e'
assert set(source['source_sha256'])==set(first['source_sha256'])==set(second['source_sha256']) and len(source['source_sha256'])==1840
assert {p for p in first['source_sha256'] if first['source_sha256'][p]!=second['source_sha256'][p]}=={'tools/test_test262_with_resolvers_controls.py'}
changed_baselines={r['path'] for r in update['written']};assert len(changed_baselines)==7
assert {p for p in source['source_sha256'] if source['source_sha256'][p]!=second['source_sha256'][p]}==changed_baselines
assert {p for p in original['source_sha256'] if original['source_sha256'][p]!=base['source_sha256'][p]}=={'.github/workflows/check.yml'}
assert set(base['source_sha256'])==set(original['source_sha256']) and len(base['source_sha256'])==1838
# Authenticate all refreshed published inventory inputs directly through read-only Git.
paths=list(base['source_sha256']);raw=subprocess.check_output(['git','cat-file','--batch'],cwd=W,input=''.join(base['base']+':'+p+'\n' for p in paths).encode());pos=0
for p in paths:
 end=raw.index(b'\n',pos);head=raw[pos:end].split();assert head[1]==b'blob';n=int(head[2]);body=raw[end+1:end+1+n];pos=end+1+n+1;assert sha(body)==base['source_sha256'][p]
assert pos==len(raw)
for p,digest in source['source_sha256'].items():assert sha((W/p).read_bytes())==digest,p
changed={p for p in source['source_sha256'] if p not in base['source_sha256'] or source['source_sha256'][p]!=base['source_sha256'][p]}
assert changed==set(ledger['changed_source_test_baseline_paths']) and len(changed)==25
actual=set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines())|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines());assert actual==changed
assert all(p.startswith(('tools/','tests/conformance/')) for p in changed)
runtime=[p for p in base['source_sha256'] if p.startswith(('src/','shaders/','assets/','crates/')) or p in {'Cargo.lock','Cargo.toml','build.rs'}];assert all(source['source_sha256'][p]==base['source_sha256'][p] for p in runtime)
# Final payload lineage: producer2, independent new tests, old migrations plus one exact follow-up.
assert (W/'tools/test262_conformance.py').read_bytes()==(H/'producer-2/raw/tools/test262_conformance.py').read_bytes()
for r in load(H/'adversarial-tests-1/source-ready.json')['files']:assert (W/r['relative_path']).read_bytes()==pathlib.Path(r['raw']['path']).read_bytes()
for r in load(H/'migrations-1/source-ready.json')['payloads']:
 expected=H/'migration-correction-1/after.py' if r['path']=='tools/test_test262_with_resolvers_controls.py' else pathlib.Path(r['raw']['path']);assert (W/r['path']).read_bytes()==expected.read_bytes()
# All published top-level runner functions except main remain exact source and signature.
published=subprocess.check_output(['git','show',base['base']+':tools/test262_conformance.py'],cwd=W,text=True);current=(W/'tools/test262_conformance.py').read_text()
def functions(s):return {n.name:(ast.get_source_segment(s,n),ast.dump(n.args,include_attributes=False)) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=functions(published),functions(current);assert set(a)<=set(b)
changed_functions=[k for k in a if a[k]!=b[k]];assert changed_functions==['main']
new_functions=sorted(set(b)-set(a));assert len(new_functions)==6 and all(k.startswith('promise_class_') for k in new_functions)
assert all(a[k]==b[k] for k in ['decode_response','decode_promise_response','validate_promise_observation','classify','classify_promise','profile_intrinsic_errors','run_case','check_baseline'])
# Complete original corpus/helper/proof trees and all other conformance JSON files.
contract=load(H/'profile-replay-2/contract.json');corpora=[]
for tree,expected in contract['preserved_trees'].items():
 actual={str(p.relative_to(W)):sha(p.read_bytes()) for p in (W/tree).rglob('*') if p.is_file()}
 if tree=='tests/conformance':
  assert set(actual)==set(expected) and len(expected)==450
  assert sum(p.endswith('.json') for p in expected)==290
  differences={p for p in expected if expected[p]!=actual[p]};assert differences==changed_baselines
 else:assert actual==expected;corpora.append(dict(path=tree,files=len(actual)))
# Parse every observed Python group; summary counts never substitute for rosters.
rosters={};python_rows=[];execution_receipts=set()
for label,item in ledger['python'].items():
 receipt=load(item['receipt']['path']);log=pathlib.Path(item['log']['path']).read_text();assert receipt['command']==item['command'] and receipt['exit']==item['exit'] and receipt['sha256']==item['log']['sha256']
 rows=re.findall(r'^(test_\w+) \(([^\n]+)\) \.\.\. (ok|FAIL|ERROR|skipped[^\n]*)$',log,re.M)
 ids=[group for name,group,status in rows];assert len(ids)==len(set(ids)) and all(group.endswith('.'+name) for name,group,status in rows)
 count=collections.Counter(status for _,_,status in rows);rosters[label]=set(ids);execution_receipts.add(item['receipt']['path'])
 expected={'parent-python-1':(683,{'ok':683},0),'parent-class-controls-1':(13,{'ok':1,'FAIL':12},1),'candidate-class-controls-1':(13,{'ok':13},0),'candidate-python-1':(696,{'ok':695,'FAIL':1},1),'candidate-python-2':(696,{'ok':696},0)}[label]
 assert len(rows)==expected[0] and dict(count)==expected[1] and receipt['exit']==expected[2]
 assert re.search(r'Ran '+str(expected[0])+r' tests in [0-9.]+s',log)
 if expected[2]==0:assert log.rstrip().endswith('OK')
 if label=='parent-class-controls-1':assert log.count('AssertionError: False is not true : selected class gate API is absent: promise_class_preflight_variants')==12
 if label=='candidate-python-1':assert 'FAIL: test_healthy_builder_uses_selected_route_and_independently_checks_raw_rows' in log
 python_rows.append(dict(label=label,counts=dict(count),ids=sorted(ids),receipt=item['receipt'],log=item['log']))
assert rosters['candidate-python-2']-rosters['parent-python-1']==rosters['candidate-class-controls-1']==rosters['parent-class-controls-1']
assert rosters['parent-python-1']<=rosters['candidate-python-2'] and rosters['candidate-python-1']==rosters['candidate-python-2']
static_ids=[]
for p in W.glob('tools/test_*.py'):
 for c in ast.parse(p.read_bytes()).body:
  if isinstance(c,ast.ClassDef):
   static_ids.extend(p.stem+'.'+c.name+'.'+n.name for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'))
assert len(static_ids)==696 and set(static_ids)==rosters['candidate-python-2']
# Two retained builds plus all 24 profile measurements and baseline gates.
assert ledger['binaries']==parent['binaries']==candidate['binaries']
for kind,item in ledger['binaries'].items():
 record=load(item['sidecar']['path']);assert record==item['record'];assert record['source_inventory']==parent['source_inventory']
 build=load(record['build']['path']);env=load(record['environment']['path']);execution_receipts.add(record['build']['path']);assert build['exit']==0 and build['sha256']==item['build_log']['sha256']
 version='1.88.0' if kind=='ordinary' else '1.99.0';features=[] if kind=='ordinary' else ['test262-host'];assert record['toolchain']==env['toolchain']==version and record['features']==features
 assert build['command']==['cargo','+'+version,'build','--locked','--offline']+([] if not features else ['--features','test262-host'])+['--release','--bin','eris-js']
 assert bind(pathlib.Path(record['binary']))==item['binary']
for capture in [parent,candidate]:
 for row in capture['profiles']:
  receipt=load(row['receipt']['path']);execution_receipts.add(row['receipt']['path']);assert receipt['sha256']==row['log']['sha256'] and receipt['exit']==row['observed_exit']
  assert '--baseline' not in receipt['command'] and '--record-baseline' not in receipt['command']
  report=load(row['report']['path']);assert receipt['exit']==(0 if all(x['status']=='passed' for x in report['cases']) else 1)
assert update['status']==gates['status']=='pass' and update['independent_review']==bind(H/'profile-review-1/review.json')
assert update['source_before']==ledger['source_candidate_2'] and update['measured_candidate']==ledger['candidate_capture'] and gates['update_receipt']==ledger['baseline_update']
profiles=[];counts=collections.Counter();projected=[]
for gate,measured in zip(gates['profiles'],candidate['profiles']):
 assert gate['profile']==measured['profile'] and gate['errors']==[]
 receipt=load(gate['receipt']['path']);execution_receipts.add(gate['receipt']['path']);assert receipt['command']==gate['command'] and receipt['exit']==gate['exit']==0 and receipt['sha256']==gate['log']['sha256']
 assert gate['command'][-2:]==['--baseline',gate['baseline']['path']] and '--record-baseline' not in gate['command']
 before=load(measured['report']['path']);after=load(gate['report']['path']);assert exact({k:v for k,v in before.items() if k!='seconds'},{k:v for k,v in after.items() if k!='seconds'})
 assert after['regressions']==after['improvements']==[] and after['harness_preflight_passed'] is True and all(x['verified'] is True for x in after['harness_preflight'])
 assert after['counts']==dict(collections.Counter(x['status'] for x in after['cases']));counts.update(after['counts'])
 baseline=load(gate['baseline']['path']);projection=dict(revision=after['revision'],corpus_manifest_sha256=after['corpus_manifest_sha256'],runner_policy_sha256=after['runner_policy_sha256'],binary_sha256=after['binary_sha256'],cases={x['id']:{k:x[k] for k in ['status','case_sha256','source_sha256']} for x in after['cases']})
 assert set(baseline)==set(projection) and baseline['cases']==projection['cases']
 if gate['profile']!='aggregate-error':
  assert exact(baseline,projection);assert pathlib.Path(gate['baseline']['path']).read_bytes()==(json.dumps(projection,indent=2)+'\n').encode();projected.append(gate['baseline'])
 else:
  assert {k:v for k,v in baseline.items() if k!='binary_sha256'}=={k:v for k,v in projection.items() if k!='binary_sha256'}
  assert gate['baseline']['sha256']==base['source_sha256']['tests/conformance/test262-aggregate-error-current.json']
 profiles.append(dict(profile=gate['profile'],report=gate['report'],receipt=gate['receipt'],log=gate['log'],baseline=gate['baseline'],cases=len(after['cases']),controls=len(after['harness_preflight']),counts=after['counts'],exit=0,full_report_exact_except_seconds=True))
assert len(profiles)==8 and len(projected)==7 and sum(p['cases'] for p in profiles)==1330 and sum(p['controls'] for p in profiles)==724
assert dict(counts)==ledger['profile_counts']=={'passed':1258,'failed':64,'unsupported':8}
all_receipts={str(p) for p in (H/'validation').glob('*.json') if not p.name.endswith('-environment.json')};assert execution_receipts==all_receipts and len(execution_receipts)==31
# Recompute cumulative baseline deltas from retained original compact rows against final gates.
old_baselines={p['profile']:p for p in load(H/'profile-review-1/baseline-parent-comparison.json')['profiles']};class_by={p['profile']:set(p['class_case_ids']) for p in contract['profiles']};new=collections.Counter();carried=collections.Counter()
for p in profiles:
 if p['profile'] not in old_baselines:continue
 old=load(old_baselines[p['profile']]['retained_before']['path']);now=load(p['baseline']['path']);assert set(old['cases'])==set(now['cases'])
 for ident,bc in old['cases'].items():
  ac=now['cases'][ident];assert bc['case_sha256']==ac['case_sha256'] and bc['source_sha256']==ac['source_sha256']
  if bc['status']!=ac['status']:
   assert bc['status']!='passed';which=new if ident in class_by[p['profile']] else carried;which[bc['status']+'->'+ac['status']]+=1
assert dict(new)=={'unsupported->passed':36,'unsupported->failed':4} and dict(carried)=={'unsupported->passed':20,'unsupported->failed':10}
assert ledger['cumulative_baseline_transitions']==dict(new_passes=56,newly_reached_failures=14,carried_runtime_passes=20,carried_runtime_failures=10)
# Original failed producer/test evidence remains retained and bound; no rewritten failure history.
for rel in ['producer-1/source-ready.json','producer-2/source-ready.json','producer-review-1/review.json','producer-review-2/review.json','migration-correction-review-1/review.json']:
 walk(load(H/rel))
out=dict(status='clear',ledger=bind(H/'root/final-validation.json'),verified_bindings=len(verified),source_inventory=ledger['source_inventory'],base=ledger['base'],changed_paths=sorted(changed),unchanged_runtime_build_inputs=len(runtime),unchanged_old_runner_functions=len(a)-1,new_runner_functions=new_functions,changed_old_runner_functions=changed_functions,corpora=corpora,unchanged_conformance_json=283,updated_baselines=projected,python=python_rows,all_execution_receipts=sorted(execution_receipts),execution_receipt_count=len(execution_receipts),profiles=profiles,counts=dict(counts),new_admission_transitions=dict(new),carried_forward_transitions=dict(carried),old_baseline_pass_regressions=0,qualifications=['696 Python groups bind source2; final changes only seven measured baselines, covered by eight fresh full report comparisons.','AggregateError baseline is byte-exact and retains its historical binary hash; actual candidate/gate reports bind the newly rebuilt ordinary adapter. Its policy, corpus and complete compact cases match.','Source inventory has1840 selected inputs and is not a complete build graph. No new full Rust suite or hardware run is claimed.'],execution='Read-only stdlib AST/JSON/hash/Git evidence checks only. No project imports/execution or live edits.')
(O/'checks.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='clear',bindings=len(verified),execution_receipts=len(execution_receipts),python_groups=696,paths=len(changed),old_functions=len(a)-1,checks=bind(O/'checks.json')),indent=2))
