from pathlib import Path
import ast,hashlib,json,stat
H=Path('/tmp/eris-promise-class-admission-plan-1');T=H/'evidence-tools-1';P=Path(__file__).resolve().parent

def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
seal=json.loads((T/'source-ready.json').read_text())
for r in seal['files']:assert bind(Path(r['path']))==r
for p in T.glob('*.py'):ast.parse(p.read_text())
constants={n.targets[0].id:ast.literal_eval(n.value) for n in ast.parse((T/'evidence_common.py').read_text()).body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'EXCLUDED_TOP','EXCLUDED_DIRS','EXCLUDED_PATHS','DOCS'}}
rows=[];skipped=[]
def walk(d):
 for p in sorted(d.iterdir()):
  rel=p.relative_to(H).as_posix();top=rel.split('/')[0]
  if p.is_symlink():skipped.append(dict(path=rel,reason='symlink'));continue
  if top in constants['EXCLUDED_TOP'] or top.startswith('target') or rel in constants['EXCLUDED_PATHS'] or (p.is_dir() and p.name in constants['EXCLUDED_DIRS']):skipped.append(dict(path=rel,reason='explicit policy exclusion'));continue
  if p.is_dir():walk(p);continue
  assert stat.S_ISREG(p.stat().st_mode)
  if top=='binaries' and p.suffix!='.json':skipped.append(dict(path=rel,reason='binary bytes; provenance retained'));continue
  rows.append(dict(path=rel,bytes=p.stat().st_size))
walk(H)
required=['producer-1/source-ready.json','producer-2/source-ready.json','producer-review-1/review.json','producer-review-2/review.json','profile-replay-1/source-ready.json','profile-replay-2/source-ready.json','validation/parent-class-controls-1.json','validation/parent-class-controls-1.log','validation/candidate-python-1.json','validation/candidate-python-1.log','validation/candidate-python-2.json','validation/candidate-python-2.log','root/migration-correction-1.json','migration-correction-1/before.py','migration-correction-1/after.py','migration-correction-1/correction.diff','root/baseline-update-1.json','root/baseline-gates-1.json','source-candidate-1.json','source-candidate-2.json','source-final.json','root/final-validation.json','profile-review-1/review.json']
paths={r['path'] for r in rows};assert all(p in paths for p in required)
result=dict(status='findings',scope='Source-only review of held evidence-tools-1. Tools were not imported or executed; no archive produced or extracted.',hold=bind(T/'source-ready.json'),inputs=seal['files'],findings=[
 dict(id='documentation-ledger-join',path='evidence_common.py',function='preconditions',finding='Selected documentation peer binds selected hold, but neither is required to bind the selected final-validation ledger. A stale reviewed documentation pair can therefore satisfy this join.',correction='Require selected final ledger SHA in both documentation hold and documentation peer, in addition to the existing peer-to-hold join. Final doc peer must explicitly record both bindings.',actual_state='Final documentation and validation peers were pending during the first read; no stale archive or incorrect publication was observed.'),
 dict(id='output-ancestor-before-write',path='package.py',function='main',finding='OUTPUT.mkdir and archive.open occur before any regular()/binding() rejection of a symlinked output-directory ancestor. A pre-existing symlink can redirect output writes; the final binding check would only reject after writing.',correction='Validate every existing output-directory ancestor by lstat before creation, then recheck the complete created directory chain before opening either output. Do not follow symlinks.',actual_state='Read-only inspection found ordinary worktree/docs/evidence ancestors and no existing checkpoint output directory; no redirected write was observed.')],clear_source_checks=[
 'No extract/extractall calls or project/network/subprocess execution. extractfile reads a checked regular member into memory only.',
 'Origin scan uses sorted H-relative paths, does not follow links, excludes worktree/publication/build/cache/binary payload outputs and exact four root publication receipts. Manifest/archive inside worktree cannot include themselves.',
 'Required source/ledger/review options use normalized H-relative paths without absolute paths or ..; current source inventory is hashed against worktree. Source scope explicitly says selected inputs, not a full build graph.',
 'Package uses exclusive output creation and zeroed USTAR uid/gid/mtime/names, fixed mode0644 and gzip timestamp/name/level. Failures preserve partial output instead of replacing it.',
 'Verifier requires exact sorted origin membership, unique regular member type/name/size/hash/bytes, no owner/link/PAX metadata, current selected receipts and hashes, bounded member count/bytes and decompression expansion.',
 'Canonical in-memory re-encoding and complete gzip trailer read reject extra tar tails, concatenated streams, changed metadata, corruption or truncation; no filesystem extraction is used.',
 'Pre/post scans and repeated preconditions reject eligible artifact or selected input drift. Frozen directory and same-runtime gzip assumptions remain necessary; this is not a defense against a concurrent filesystem adversary.',
 'All23 specifically inspected failure-history/source/baseline/peer receipts remain eligible, including both producer holds, both replay holds, parent control failures and both full Python runs plus correction.'],history_bindings=[bind(H/p) for p in required],inventory_observation=dict(eligible_regular_files_at_read=len(rows),uncompressed_bytes_at_read=sum(r['bytes'] for r in rows),longest_path=max(rows,key=lambda r:len(r['path']))['path'],skipped=skipped,qualification='Interim read-only census only: final docs and review artifacts are still being authored. Not a final archive member count.'),qualifications=['Hold1 findings must remain preserved when an additive corrected hold is reviewed.','The first inert review helper used ast.literal_eval on a multiplication expression and stopped before scanning; the corrected helper only reads literal exclusion sets. This was not execution or failure of a held packager.','No evidence of actual extraction, redirected output or archive publication is claimed.'])
with (P/'review.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(bind(P/'review.json')))
