"""Source-only draft; final validation fields deliberately remain pending."""
from pathlib import Path
import difflib, hashlib, json, subprocess
P=Path(__file__).resolve().parent;H=P.parent;W=H/'worktree';BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def js(p,x):put(p,json.dumps(x,indent=2)+'\n')
names=['README.md','docs/ROADMAP.md','docs/VALIDATION.md','docs/classes.md']
before={n:subprocess.check_output(['git','show',BASE+':'+n],cwd=W).decode() for n in names}
for n,s in before.items():assert (W/n).read_text()==s;put(P/'before'/n,s)
raw=before.copy()
old='''remain unsupported. This runtime change does not enable the `class` feature in
upstream profile policies; earlier profile counts below retain their checkpoint
scope. Final checks pass 80 public groups across 164 mode attempts, with the
complete Rust suites and eight existing profile replays recorded in the chapter.
'''
new='''remain unsupported. The separate [Promise class-admission checkpoint](docs/promise-class-admission.md)
now enables declared `class` metadata in seven existing Promise profiles, with
1,330 modes across eight replays: **1,258 passed, 64 failed and eight unsupported**,
and **724 healthy controls**. This changes profile admission and its gate;
Rust semantics and limits are unchanged. Earlier API/profile totals below belong
to their original checkpoints; the linked table records the current selection.
'''
assert raw['README.md'].count(old)==1;raw['README.md']=raw['README.md'].replace(old,new)
raw['README.md']=raw['README.md'].replace('The two class-tagged modes remain excluded;','At that checkpoint, the two class-tagged modes were excluded;').replace('The six class-tagged modes remain excluded;','At that checkpoint, the six class-tagged modes were excluded;')
anchor='# Development docket\n\n'
addition='''[Promise class metadata admission](promise-class-admission.md) now runs the
previously excluded class-tagged sources in seven existing Promise profiles.
Eight complete replays retain 1,330 modes: **1,258 passed, 64 failed and eight
unsupported**, under **724 healthy controls**. Of 40 newly dispatched modes,
36 pass and four reach the unchanged final-unhandled-rejection host veto.
No previously passing case regresses. This is a tooling/gate change; the class
runtime and all limits are unchanged. The older runtime/profile summaries below
retain their original checkpoint results and policy scope.

'''
assert raw['docs/ROADMAP.md'].startswith(anchor);raw['docs/ROADMAP.md']=anchor+addition+raw['docs/ROADMAP.md'][len(anchor):]
anchor='# JavaScript classes\n\n'
addition='''The subsequent [Promise class-admission checkpoint](promise-class-admission.md)
enables declared class metadata in seven bounded Promise profiles without
changing this runtime. The remainder of this chapter records the original
class-runtime checkpoint: its validation totals and statements about unchanged
upstream policies remain historical.

'''
assert raw['docs/classes.md'].startswith(anchor);raw['docs/classes.md']=anchor+addition+raw['docs/classes.md'][len(anchor):]
validation='''## Class metadata admission in Promise profiles

The [class-admission checkpoint](promise-class-admission.md) adds only `class` to
seven existing profile feature sets, with 84 independently frozen control rows.
All eight complete replays retain **1,330 modes** and **724 healthy controls**:
**1,258 passed, 64 failed and eight unsupported**. All 640 previous control rows
remain exact. The 40 changed case rows are precisely the previously excluded
class-tagged modes: **36 now pass**, while **four now fail** at the existing
final-unhandled-rejection host audit. No other raw case row changes and no
previously passing case regresses.

The four newly reached failures are both modes of `Promise/reject/ctx-ctor.js`
and `Promise/any/ctx-ctor.js`; each retains a genuine `unhandled-rejection`
observation with one outstanding rejection. They are not converted into passes
or described as proved Promise algorithm failures. The withResolvers profile
now passes all 12 modes, and Try all 30; those are complete bounded selections,
not full language or browser conformance.

[[PENDING_FULL_PYTHON_VALIDATION]]

[[PENDING_BASELINE_VALIDATION]]

The ordinary Rust 1.88 and host Rust 1.99 release adapters were rebuilt and
frozen before parent/candidate measurements. The candidate uses those exact
binaries. Rust runtime source, corpus originals/helpers, completion protocols,
resource limits and negative-error identity boundaries are unchanged; 54 other
profile policy maps are exact. No new full Rust suite result is claimed here.
A source review corrected the new graph check to preserve 192 existing
cross-mode prerequisite edges; only the 246 new class edges require the same
mode. The original producer and the additive correction remain retained.

See the [evidence manifest](evidence/promise-class-admission/manifest.json) and
[source/check archive](evidence/promise-class-admission/sources-and-checks.tar.gz).
The complete prior validation body below remains byte-exact.

'''
anchor='# Validation record\n\n';assert raw['docs/VALIDATION.md'].startswith(anchor);raw['docs/VALIDATION.md']=anchor+validation+raw['docs/VALIDATION.md'][len(anchor):]
raw['docs/promise-class-admission.md']='''# Class metadata admission in Promise profiles

Seven existing Promise profiles now admit their declared `class` feature after
the [class runtime](classes.md) checkpoint. This changes metadata admission and
the prerequisite gate; it adds no Rust semantics, syntax or resource allowance.
The complete original corpora and their source/helper fingerprints are retained.
Earlier profile chapters preserve the results and policies of their own
checkpoints; this table records the subsequent admission measurement.

| Profile | Modes | Passed | Failed | Unsupported | Healthy controls |
| --- | ---: | ---: | ---: | ---: | ---: |
| Promise methods | 458 | 444 | 12 | 2 | 86 |
| Promise.all | 196 | 180 | 16 | 0 | 102 |
| Promise.race | 188 | 176 | 12 | 0 | 102 |
| Promise.allSettled | 208 | 194 | 14 | 0 | 106 |
| Promise.any | 188 | 178 | 6 | 4 | 114 |
| Promise.withResolvers | 12 | 12 | 0 | 0 | 56 |
| Promise.try | 30 | 30 | 0 | 0 | 106 |
| AggregateError, unchanged | 50 | 44 | 4 | 2 | 52 |
| **Total** | **1,330** | **1,258** | **64** | **8** | **724** |

The seven selected profiles retain 1,280 modes. Exactly 40 previously excluded
class-tagged modes reach the adapter: 36 pass and four reach the unchanged
final-unhandled-rejection audit. The latter are both modes of
`Promise/reject/ctx-ctor.js` and `Promise/any/ctx-ctor.js`, each reporting
`unhandled-rejection` with one outstanding rejection. Those failures remain in
the denominator and raw reports; they are neither hidden nor treated as proof
of an algorithm defect. All other case records and all 640 old control records
are exact, with no previously passing case regression. The remaining eight
metadata exclusions concern cross-realm support and destructuring. Passing all
12 withResolvers modes or all 30 Try modes establishes only these bounded
selections.

Each selected profile adds three positive/mismatch pairs in both modes: class
construction/call guards, species/alternate returns, and that profile's
subclass behavior. The 84 new rows use independent source, helper, mode and
fingerprint oracles. The canonical gate authenticates raw schemas, recomputes
classifications and verifies the ordered prerequisite graph, including exact
old references. Duplicate/missing rows, forged results, malformed fields and
cycles refuse the gate. A failed gate blocks the entire loaded case inventory
before adapter dispatch or a baseline update. Synchronous assertion diagnostic
text is bounded rather than used as an oracle; its raw error type/identity and
all completion fields remain checked.

withResolvers retains ordinary **ERJS1/ERJR2** transport. The other six selected
profiles retain **ERJS2/ERJR3**, authenticated completion and the final unhandled
rejection audit. Existing negative-error identity boundaries, including the
Any-specific AggregateError capability, remain unchanged. All 54 other profile
policy maps are exact. Author work remains 100,000 units, trusted initialization
1,000,000 and cumulative accounted heap 8 MiB.

The ordinary Rust 1.88 and host Rust 1.99 adapters were rebuilt and frozen before
parent and candidate measurements; both phases use the same binary bytes.
[[PENDING_FULL_PYTHON_VALIDATION]]
[[PENDING_BASELINE_VALIDATION]]
A source-review correction retained the old cross-mode prerequisites while
restricting only new class edges to the same mode. No runtime change or full
Rust suite rerun belongs to this admission checkpoint.

For a measurement without baseline writes, use the ordinary adapter for
withResolvers and AggregateError, and the host adapter for the other profiles:

```sh
python3 tools/test262_conformance.py --profile promise-with-resolvers \\
  --binary /path/to/ordinary/eris-js --jobs 1 --output /tmp/with-resolvers.json
python3 tools/test262_conformance.py --profile promise-try \\
  --binary /path/to/test262-host/eris-js --jobs 1 --output /tmp/promise-try.json
```

Without a baseline flag, a retained nonpassing case produces a nonzero exit;
the raw report still distinguishes ordinary failures from unsupported cases.
The evidence runner records all eight profiles serially and preserves every
before/after transition. See the [manifest](evidence/promise-class-admission/manifest.json)
and [source/check archive](evidence/promise-class-admission/sources-and-checks.tar.gz)
for exact bindings and commands. Full JavaScript/web compatibility, measured
full-browser correctness, a security audit and a Chromium-relative performance
result remain open. Fields, private elements, static blocks, `super` properties
and async/generator methods retain the class subset's documented exclusions.
'''
for n,s in raw.items():
 put(P/'raw'/n,s);put(P/'diffs'/(n+'.diff'),''.join(difflib.unified_diff(before.get(n,'').splitlines(True),s.splitlines(True),fromfile='a/'+n,tofile='b/'+n)))
for n,title in [('docs/VALIDATION.md','# Validation record\n\n'),('docs/classes.md','# JavaScript classes\n\n')]:assert raw[n].endswith(before[n][len(title):])
profile=json.loads((H/'root/profile-candidate-1.json').read_text());assert profile['status']=='pass' and profile['counts']==dict(passed=1258,failed=64,unsupported=8)
assert profile['transition_counts']==dict(case_record_changes=40,control_record_changes=0,prior_pass_regressions=0,newly_passed=36,nonpass_status_changes=4,raw_only_changes=0,outside_class_tag_changes=0)
js(P/'draft-ready.json',dict(status='draft only; final Python/baseline receipts pending',base=BASE,files=[bound(P/'raw'/n) for n in raw],actual_profile=bound(H/'root/profile-candidate-1.json'),historical_validation_and_runtime_bodies_exact=True,pending=['full Python result','seven baseline updates and checks','final root ledger'],project_execution=False,live_edits=False))
print(json.dumps(bound(P/'draft-ready.json')))
