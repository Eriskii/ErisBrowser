"""Inert AST/hash author checks only; never imports or executes held packagers."""
import ast,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent
files=['evidence_common.py','package.py','verify.py']
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(name,value):
 with (P/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
for name in files:
 tree=ast.parse((P/name).read_text())
 assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) and ('subprocess' in ast.get_source_segment((P/name).read_text(),n) or 'tools.test262' in ast.get_source_segment((P/name).read_text(),n)) for n in ast.walk(tree))
contract=dict(status='held source-only recipe; not executed',checkpoint='promise-class-admission',
 execution=['Freeze H eligible artifacts and import final documentation before packaging.',
 'Run package.py then verify.py with the same explicit final inventory/ledger/peer/doc-hold arguments. Defaults are illustrative receipt locations and fail closed if absent.',
 'Capture stdout/stderr only under publication/ or an explicit excluded root output. Do not wrap these commands in run-tool.py, because validation/ is included and frozen.',
 'After packaging mutate only publication/ or the four exact excluded root output paths. Any other new, removed or changed eligible artifact makes verification fail.'],
 commands=['python3 -B evidence-tools-1/package.py --documentation-hold documentation-1/source-ready.json',
           'python3 -B evidence-tools-1/verify.py --documentation-hold documentation-1/source-ready.json'],
 outputs=['worktree/docs/evidence/promise-class-admission/sources-and-checks.tar.gz','worktree/docs/evidence/promise-class-admission/manifest.json'],
 selection='All sorted regular H artifacts except worktree, publication, target-prefixed top paths, cache/git/target directories, symlinks, non-JSON binaries/ files and exact excluded root output receipts.',
 excluded_root_outputs=['root/evidence-selection.json','root/publication-verification.json','root/github-publication.json','root/git-publication.json'],
 retention='Original failures, superseded holds, corrections, raw logs, parent/candidate/baseline reports, binary JSON provenance, author scripts, control/oracle/review files, inventories and final docs remain eligible.',
 verification='Required pass/clear receipts and their source/peer hashes; imported docs exact to sealed raw files; every selected source hash; sorted unique regular USTAR members with origin byte/SHA equality and no extras; deterministic gzip re-encoding to reject tails/extra streams; no archive extraction.',
 bounds=dict(members=20000,uncompressed_member_bytes=134217728),
 scope='Selected evidence, not a complete self-contained build graph. No runtime binary payloads, performance/security claim or new project execution.',
 project_execution=False,live_edits=False)
dump('execution-contract.json',contract)
dump('author-checks.json',dict(ast_parsed=files,held_scripts_executed=False,project_imports=False,archive_created=False,live_writes=False))
dump('source-ready.json',dict(status='source-ready held evidence tooling; unexecuted',files=[bound(P/n) for n in files+['author-seal.py','execution-contract.json','author-checks.json']],project_execution=False,live_edits=False))
print(json.dumps(bound(P/'source-ready.json')))
