"""Stdlib-only authoring of held projections/contract; never runs held recipes."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path

P=Path(__file__).resolve().parent
H=P.parent
W=H/'worktree'

def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def get(p):return json.loads(Path(p).read_bytes())
def put(p,j):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((json.dumps(j,indent=2)+'\n').encode())

candidate=get(H/'root/profile-candidate-1.json');parent=get(H/'root/profile-parent-1.json')
peer=get(H/'profile-review-1/review.json');checks=get(H/'profile-review-1/candidate-checks.json')
prior=get(H/'profile-review-1/baseline-parent-comparison.json')
replay=get(H/'profile-replay-2/contract.json')
source1=get(H/'source-candidate-1.json');source2=get(H/'source-candidate-2.json')
assert peer['status']=='clear' and not peer['findings']
assert candidate['counts']=={'passed':1258,'failed':64,'unsupported':8}
assert list(source1['source_sha256'])==list(source2['source_sha256'])
assert [p for p in source1['source_sha256'] if source1['source_sha256'][p]!=source2['source_sha256'][p]]==['tools/test_test262_with_resolvers_controls.py']
projections={};baseline_paths={'aggregate-error':'tests/conformance/test262-aggregate-error-current.json'}
reports={p['profile']:get(p['report']['path']) for p in candidate['profiles']}
projection_notes=[]
for row in checks['baselines']:
 profile=row['profile'];rel=row['tracked_path'];report=reports[profile]
 old=Path(row['retained_baseline']['path']).read_bytes()
 assert (W/rel).read_bytes()==old
 assert sha(old)==row['retained_baseline']['sha256']
 result=dict(revision=report['revision'],corpus_manifest_sha256=report['corpus_manifest_sha256'],
             runner_policy_sha256=report['runner_policy_sha256'],binary_sha256=report['binary_sha256'],
             cases={x['id']:{k:x[k] for k in ('status','case_sha256','source_sha256')} for x in report['cases']})
 put(P/'raw'/rel,result)
 new=(P/'raw'/rel).read_bytes()
 diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile=rel+' (published before)',tofile=rel+' (measured projection)'))
 target=P/'diffs'/(Path(rel).name+'.diff');target.parent.mkdir(exist_ok=True);target.write_text(diff)
 projections[rel]=dict(profile=profile,before=row['retained_baseline'],after=bind(P/'raw'/rel),diff=bind(target))
 baseline_paths[profile]=rel
 projection_notes.append(dict(profile=profile,path=rel,cases=len(result['cases']),counts=dict(Counter(x['status'] for x in result['cases'].values())),changes=len(row['changes'])))
assert len(projections)==7
runner=(W/'tools/test262_conformance.py').read_text();tree=ast.parse(runner)
main=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='main')
assignment=next(n for n in ast.walk(main) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='current' for t in n.targets))
assert isinstance(assignment.value,ast.Call) and assignment.value.func.id=='dict'
assert [k.arg for k in assignment.value.keywords]==['revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256','cases']
case_expr=assignment.value.keywords[-1].value
assert isinstance(case_expr,ast.DictComp) and isinstance(case_expr.value,ast.DictComp)
assert [x.value for x in case_expr.value.generators[0].iter.elts]==['status','case_sha256','source_sha256']
recipe=(P/'baselines.py').read_text();recipe_ast=ast.parse(recipe)
assert not any(isinstance(n,(ast.Import,ast.ImportFrom)) and (getattr(n,'module','') or '').startswith('tools') for n in ast.walk(recipe_ast))
put(P/'projection-checks.json',dict(status='source-only projection checks',main_projection=ast.get_source_segment(runner,assignment),main_source=bind(W/'tools/test262_conformance.py'),projections=projection_notes,python_ast_parsed=True,held_recipe_executed=False,project_imports=False,project_execution=False,live_baseline_writes=False,retained_initial_python_failure=bind(H/'validation/candidate-python-1.json')))
# Final seal intentionally waits for the actual passing corrected full-suite receipt.
py_path=H/'validation/candidate-python-2.json'
if not py_path.exists():
 print('Projections and source checks prepared; final seal waits for actual candidate-python-2 receipt.')
 raise SystemExit(0)
py=get(py_path)
assert py['exit']==0, 'corrected full Python suite must pass before sealing'
pylog=H/'validation'/py['log'];assert sha(pylog.read_bytes())==py['sha256']
assert 'Ran 696 tests in ' in pylog.read_text() and pylog.read_text().rstrip().endswith('OK')
contract=dict(format=1,status='held root-only recipe; no baseline mutation or gate execution during authoring',
 source_candidate_1=bind(H/'source-candidate-1.json'),source_candidate_2=bind(H/'source-candidate-2.json'),
 correction_path='tools/test_test262_with_resolvers_controls.py',correction=bind(H/'root/migration-correction-1.json'),
 correction_before=bind(H/'migration-correction-1/before.py'),correction_after=bind(H/'migration-correction-1/after.py'),
 profile_review=bind(H/'profile-review-1/review.json'),candidate=bind(H/'root/profile-candidate-1.json'),parent=bind(H/'root/profile-parent-1.json'),
 candidate_checks=bind(H/'profile-review-1/candidate-checks.json'),baseline_parent_comparison=bind(H/'profile-review-1/baseline-parent-comparison.json'),
 replay_contract=bind(H/'profile-replay-2/contract.json'),python_receipt=bind(py_path),python_log=bind(pylog),
 python_first_receipt=bind(H/'validation/candidate-python-1.json'),run_tool=bind(H/'run-tool.py'),
 baseline_paths=baseline_paths,projections=projections)
contract['inputs']=[v for v in contract.values() if type(v) is dict and set(v)=={'path','bytes','sha256'}]
contract['inputs'].append(bind(H/'migration-correction-1/correction.diff'))
put(P/'contract.json',contract)
put(P/'usage.json',dict(status='root review required before execution',commands=[['python3','-B',str(P/'baselines.py'),'update','--execute'],['python3','-B',str(P/'baselines.py'),'gates','--execute','--attempt','1']],write_scope=list(projections),update_receipt=str(H/'root/baseline-update-1.json'),gate_receipt=str(H/'root/baseline-gates-1.json'),qualifications=['The seven frozen raw files are compact measured projections, not complete raw reports.','All before bytes remain bound to independent profile-review-1/baseline-before. AggregateError and every other baseline stay exact.','Source2 differs from measured source1 at one exact old unit-test feature literal only; producer, corpus, policy, adapters and raw measured reports remain pinned.','Initial full suite 695 passed/1 failed is retained; actual corrected 696-test success is required by the runtime guard.','Gate execution is serial with existing root run-tool retention and per-case timeout 3.0; no builds and no --record-baseline.','Gate equality excludes only measured elapsed seconds; all classifications, observations, policy, controls, order and identities must equal retained candidate reports.']))
files=[]
for p in sorted(P.rglob('*')):
 if p.is_file() and p.name!='source-ready.json':files.append(bind(p))
put(P/'source-ready.json',dict(status='source-ready held baseline updater and gate runner; unexecuted',files=files,project_execution=False,live_edits=False,baseline_writes=False,selected_baselines=7,profiles=8,cases=1330,controls=724,measured_counts=candidate['counts'],source_candidate_2=contract['source_candidate_2'],profile_review=contract['profile_review'],full_python=contract['python_receipt']))
print(json.dumps(bind(P/'source-ready.json'),indent=2))
