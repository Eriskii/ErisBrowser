#!/usr/bin/env python3
"""Root-only measured baseline projection and serial baseline-gate replay.

This held program is not run during authoring. Only `update --execute` writes
seven preselected baseline files. `gates --execute` dispatches repository code.
"""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path
import re
import subprocess
import sys

P = Path(__file__).resolve().parent
H = P.parent
W = H / 'worktree'
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
SELECTED = ('promise-methods-async', 'promise-all', 'promise-race', 'promise-all-settled',
            'promise-any', 'promise-with-resolvers', 'promise-try')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def check_binding(item):
    require(binding(item['path']) == item, 'binding changed: ' + item['path'])


def read(item):
    check_binding(item)
    return json.loads(Path(item['path']).read_bytes())


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(equal(a[k], b[k]) for k in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def encode(value):
    return (json.dumps(value, indent=2) + '\n').encode('utf-8')


def exclusive(path, value):
    with Path(path).open('xb') as stream:
        stream.write(encode(value))


def compact(report):
    # Exact key/insertion order and default ensure_ascii of main's `current`.
    return dict(revision=report['revision'],
                corpus_manifest_sha256=report['corpus_manifest_sha256'],
                runner_policy_sha256=report['runner_policy_sha256'],
                binary_sha256=report['binary_sha256'],
                cases={item['id']: {key: item[key] for key in
                       ('status', 'case_sha256', 'source_sha256')} for item in report['cases']})


def selected_source(contract, recorded):
    first = read(contract['source_candidate_1'])
    second = read(contract['source_candidate_2'])
    a, b = first['source_sha256'], second['source_sha256']
    require(a.keys() == b.keys(), 'source inventory roster changed')
    changed = [key for key in a if a[key] != b[key]]
    require(changed == [contract['correction_path']], 'source2 must change only the selected mock')
    correction = read(contract['correction'])
    old = Path(contract['correction_before']['path']).read_bytes()
    new = Path(contract['correction_after']['path']).read_bytes()
    require(correction['path'] == changed[0] and sha(old) == a[changed[0]] == correction['before_sha256']
            and sha(new) == b[changed[0]] == correction['after_sha256'], 'correction source joins')
    require(old.count(correction['old'].encode()) == 1
            and old.replace(correction['old'].encode(), correction['new'].encode(), 1) == new, 'exact one-literal correction')
    for rel, expected in b.items():
        if recorded and rel in contract['projections']:
            expected = contract['projections'][rel]['after']['sha256']
        require(sha((W / rel).read_bytes()) == expected, 'selected source drift: ' + rel)
    replay = read(contract['replay_contract'])
    # Full retained corpus and baseline trees, not just the selected inventory.
    for tree, expected in replay['preserved_trees'].items():
        after = dict(expected)
        if recorded:
            for rel, row in contract['projections'].items():
                if rel in after:
                    after[rel] = row['after']['sha256']
        actual = {str(p.relative_to(W)): sha(p.read_bytes())
                  for p in (W / tree).rglob('*') if p.is_file()}
        require(actual == after, 'preserved tree drift: ' + tree)
    for item in replay['preserved_files']:
        require(sha((W / item['path']).read_bytes()) == item['sha256'],
                'preserved file drift: ' + item['path'])


def context(recorded):
    seal = json.loads((P / 'source-ready.json').read_bytes())
    for item in seal['files']:
        check_binding(item)
    contract = json.loads((P / 'contract.json').read_bytes())
    for item in contract['inputs']:
        check_binding(item)
    selected_source(contract, recorded)
    review = read(contract['profile_review'])
    require(review['status'] == 'clear' and review['findings'] == [], 'profile peer is not clear')
    for item in review['inputs'] + review['evidence']:
        check_binding(item)
    candidate = read(contract['candidate'])
    parent = read(contract['parent'])
    require(candidate['status'] == parent['status'] == 'pass', 'profile captures not healthy')
    require(candidate['phase'] == 'candidate' and parent['phase'] == 'parent', 'capture phases')
    require(candidate['source_inventory'] == contract['source_candidate_1'], 'original measured source binding')
    require(candidate['parent_capture'] == contract['parent'], 'parent capture binding')
    require(equal(candidate['binaries'], parent['binaries']), 'different parent/candidate adapters')
    for item in candidate['binaries'].values():
        for part in ('binary', 'sidecar', 'build_log'):
            check_binding(item[part])
        sidecar = read(item['sidecar'])
        require(equal(sidecar, item['record']), 'adapter sidecar payload')
        for part in ('source_inventory', 'build', 'environment'):
            check_binding(sidecar[part])
        require(read(sidecar['build'])['exit'] == 0, 'adapter build failed')
    python = read(contract['python_receipt'])
    require(type(python['exit']) is int and python['exit'] == 0, 'full Python receipt failed')
    require(python['command'] == ['python3', '-B', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_*.py', '-v'], 'full Python command')
    check_binding(contract['python_log'])
    require(python['log'] == Path(contract['python_log']['path']).name
            and python['sha256'] == contract['python_log']['sha256'], 'Python log join')
    text = Path(contract['python_log']['path']).read_text()
    require(re.findall(r'^Ran (\d+) tests in .+$', text, re.M) == ['696']
            and re.search(r'^OK\s*\Z', text, re.M) is not None, '696-test success summary')
    # The prior failure is retained as evidence, never used to authorize writes.
    require(read(contract['python_first_receipt'])['exit'] == 1, 'initial failure evidence changed')
    checked = read(contract['candidate_checks'])
    prior = read(contract['baseline_parent_comparison'])
    require(checked['status'] == 'pass' or checked['status'] == 'clear', 'candidate peer checks status')
    require(tuple(row['profile'] for row in checked['baselines']) == SELECTED, 'seven selected baseline scope')
    before_by = {row['profile']: row for row in parent['profiles']}
    profiles = read(contract['replay_contract'])['profiles']
    require([p['profile'] for p in profiles] == ['aggregate-error', *SELECTED], 'eight-profile order')
    reports, old_reports = {}, {}
    changed_total, old_pass_regressions = 0, 0
    expected_admission = Counter()
    for profile, row in zip(profiles, candidate['profiles']):
        require(row['profile'] == profile['profile'] and row['errors'] == [], 'candidate profile errors/order')
        old_row = before_by[row['profile']]
        for evidence in (row, old_row):
            for part in ('report', 'receipt', 'log', 'before'):
                check_binding(evidence[part])
        report, old = read(row['report']), read(old_row['report'])
        reports[row['profile']], old_reports[row['profile']] = report, old
        require(report['harness_preflight_passed'] is True and report['regressions'] == [], 'candidate gate/regression')
        require(all(c['verified'] is True for c in report['harness_preflight']), 'unhealthy control')
        require(len(report['cases']) == profile['cases'], 'case denominator')
        require([{k:c[k] for k in IDENTITY} for c in report['cases']] == profile['case_identities'], 'case identity/order')
        require(equal(report['runner_policy'], profile['policy']['after']), 'selected policy')
        require(report['runner_policy_sha256'] == sha(json.dumps(report['runner_policy'], sort_keys=True).encode()), 'policy digest')
        require(equal(report['harness_preflight'][:len(old['harness_preflight'])], old['harness_preflight']), 'old controls changed')
        changes = []
        for a, b in zip(old['cases'], report['cases']):
            require(equal({k:a[k] for k in IDENTITY}, {k:b[k] for k in IDENTITY}), 'changed identity')
            if not equal(a, b):
                changes.append(b['id'])
                require(a['status'] == 'unsupported', 'admission did not start unsupported')
                expected_admission[a['status'] + '->' + b['status']] += 1
            old_pass_regressions += a['status'] == 'passed' and b['status'] != 'passed'
        require(changes == profile['class_case_ids'], 'changes outside exact class scope/order')
        changed_total += len(changes)
    require(changed_total == 40 and old_pass_regressions == 0, '40 class-only modes/no prior-pass regression')
    require(expected_admission == Counter({'unsupported->passed':36, 'unsupported->failed':4}), 'admission transition counts')
    require(candidate['counts'] == {'passed':1258, 'failed':64, 'unsupported':8}, 'measured total counts')
    require(sum(len(r['cases']) for r in reports.values()) == 1330
            and sum(len(r['harness_preflight']) for r in reports.values()) == 724, 'complete measured denominators')
    expected_baselines = {r['profile']:r for r in checked['baselines']}
    previous_rows = {r['profile']:r for r in prior['profiles']}
    cumulative, carried = Counter(), Counter()
    for profile in SELECTED:
        row = expected_baselines[profile]
        rel = row['tracked_path']; plan = contract['projections'][rel]
        before = read(plan['before'])
        require(plan['before'] == row['retained_baseline'], 'retained original baseline join')
        require(row['no_baseline_pass_regressions'] is True, 'baseline peer found regression')
        projection = compact(reports[profile])
        require(encode(projection) == Path(plan['after']['path']).read_bytes(), 'held projection differs from actual report')
        require(list(before['cases']) == list(projection['cases']), 'compact baseline case order')
        changes = []; carried_changes = []
        old_by = {r['id']:r for r in old_reports[profile]['cases']}
        for name, a in before['cases'].items():
            b = projection['cases'][name]
            require(a['case_sha256'] == b['case_sha256'] and a['source_sha256'] == b['source_sha256'], 'compact identity changed')
            require(not (a['status'] == 'passed' and b['status'] != 'passed'), 'old baseline pass regressed')
            if a['status'] != b['status']:
                changes.append(name); cumulative[a['status']+'->'+b['status']] += 1
            old = old_by[name]
            if a['status'] != old['status']:
                carried_changes.append(name); carried[a['status']+'->'+old['status']] += 1
        require(changes == [r['id'] for r in row['changes']], 'cumulative transition identities')
        require(carried_changes == [r['id'] for r in previous_rows[profile]['carried_forward_changes']], 'carried F transition identities')
    require(cumulative == Counter({'unsupported->passed':56,'unsupported->failed':14}), '70 cumulative changes')
    require(carried == Counter({'unsupported->passed':20,'unsupported->failed':10}), '30 carried runtime changes')
    return contract, reports


def update():
    contract, reports = context(False)
    destination = H / 'root' / 'baseline-update-1.json'
    require(not destination.exists(), 'update receipt already exists')
    targets = list(contract['projections'])
    require(len(targets) == 7, 'only seven baseline writes')
    before = {rel:(W/rel).read_bytes() for rel in targets}
    for rel in targets:
        require(before[rel] == Path(contract['projections'][rel]['before']['path']).read_bytes(), 'original baseline differs')
    written = []
    try:
        for rel in targets:
            written.append(rel)
            (W/rel).write_bytes(Path(contract['projections'][rel]['after']['path']).read_bytes())
        selected_source(contract, True)
    except Exception:
        for rel in written:
            (W/rel).write_bytes(before[rel])
        raise
    result = dict(status='pass', operation='seven measured compact baseline projections',
                  contract=binding(P/'contract.json'), runner=binding(Path(__file__)),
                  source_before=contract['source_candidate_2'], python=contract['python_receipt'],
                  independent_review=contract['profile_review'], measured_candidate=contract['candidate'],
                  written=[dict(path=rel,before=contract['projections'][rel]['before'],after=binding(W/rel)) for rel in targets],
                  only_baseline_mutations=True, prior_pass_regressions=0,
                  admission_modes=40, carried_runtime_modes=30, cumulative_status_changes=70)
    exclusive(destination,result)
    print(json.dumps(binding(destination)),flush=True)


def gates(attempt):
    contract, reports = context(True)
    updated = H/'root'/'baseline-update-1.json'
    receipt = json.loads(updated.read_bytes())
    require(receipt['status']=='pass' and receipt['contract']==binding(P/'contract.json')
            and receipt['runner']==binding(Path(__file__)), 'missing matching update receipt')
    require([row['path'] for row in receipt['written']] == list(contract['projections']), 'exact seven update targets')
    for row in receipt['written']:
        check_binding(row['after'])
    destination=H/'root'/('baseline-gates-'+str(attempt)+'.json')
    require(not destination.exists(),'gate summary exists')
    profiles=read(contract['replay_contract'])['profiles']
    paths=[]
    for profile in profiles:
        label='class-baseline-'+profile['name']+'-'+str(attempt)
        report=H/('upstream-'+label+'.json')
        require(all(not p.exists() for p in (report,H/'validation'/(label+'.json'),H/'validation'/(label+'.log'))),'gate output already exists')
        paths.append((profile,label,report))
    rows=[]
    for profile,label,report_path in paths:
        selected_source(contract,True)
        candidate=read(contract['candidate'])
        binary=candidate['binaries'][profile['binary_kind']]
        check_binding(binary['binary']);check_binding(binary['sidecar']);check_binding(contract['run_tool'])
        baseline=contract['baseline_paths'][profile['profile']]
        command=[sys.executable,'-B','tools/test262_conformance.py','--binary',binary['binary']['path'],
                 '--profile',profile['profile'],'--output',str(report_path),'--jobs','1','--timeout','3.0',
                 '--baseline',str(W/baseline)]
        subprocess.run([sys.executable,'-B',str(H/'run-tool.py'),label,*command],check=False)
        row=dict(profile=profile['profile'],command=command,errors=[])
        try:
            measured=binding(report_path); report=read(measured)
            rb=binding(H/'validation'/(label+'.json')); run=read(rb)
            lb=binding(H/'validation'/(label+'.log'))
            require(run['command']==command and run['log']==label+'.log' and run['sha256']==lb['sha256'],'gate receipt/log join')
            require(type(run['exit']) is int and run['exit']==0,'baseline gate exit not zero')
            require(report.keys()==reports[profile['profile']].keys(),'full report schema changed')
            require(type(report['seconds']) in (int,float) and math.isfinite(report['seconds']) and report['seconds']>=0,'elapsed scalar')
            require(equal({k:v for k,v in report.items() if k!='seconds'},
                          {k:v for k,v in reports[profile['profile']].items() if k!='seconds'}),'complete raw/control/policy/case report differs')
            require(report['regressions']==[] and report['improvements']==[],'post-record comparisons are not empty')
            require(report['harness_preflight_passed'] is True,'post-record gate unhealthy')
            row.update(report=measured,receipt=rb,log=lb,counts=report['counts'],cases=len(report['cases']),
                       controls=len(report['harness_preflight']),baseline=binding(W/baseline),exit=run['exit'],
                       complete_report_equal_except_elapsed=True)
        except (OSError,KeyError,TypeError,ValueError,UnicodeError) as error:
            row['errors'].append(str(error))
            row['retained']=[binding(p) for p in (report_path,H/'validation'/(label+'.json'),H/'validation'/(label+'.log')) if p.is_file()]
        rows.append(row)
        selected_source(contract,True)
        check_binding(binary['binary']);check_binding(binary['sidecar'])
        print(json.dumps(dict(profile=profile['profile'],errors=row['errors'])),flush=True)
    result=dict(status='pass' if all(not r['errors'] for r in rows) else 'fail',attempt=attempt,
                contract=binding(P/'contract.json'),runner=binding(Path(__file__)),update_receipt=binding(updated),
                profiles=rows,expected_cases=1330,expected_controls=724,baseline_writes=False,
                comparison='Full measured report equality, excluding only elapsed seconds; all eight baseline gates require exit zero and no improvements/regressions.')
    exclusive(destination,result)
    print(json.dumps(binding(destination)),flush=True)
    return 0 if result['status']=='pass' else 1


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('operation',choices=('update','gates'))
    parser.add_argument('--execute',action='store_true',help='explicit root-only authorization to mutate baselines or dispatch project runner')
    parser.add_argument('--attempt',type=int,default=1)
    args=parser.parse_args()
    require(args.execute,'held recipe requires explicit --execute')
    require(args.attempt>0,'positive gate attempt')
    if args.operation=='update':
        update();return 0
    return gates(args.attempt)


if __name__=='__main__':
    try:
        raise SystemExit(main())
    except (OSError,KeyError,TypeError,ValueError,UnicodeError) as error:
        print('Baseline recipe refusal: '+str(error),file=sys.stderr)
        raise SystemExit(2)
