#!/usr/bin/env python3
"""Package frozen H artifacts. Root-only execution after independent reviews."""
import argparse
import gzip
import json
from pathlib import Path
import tarfile
from evidence_common import H, OUTPUT, binding, check_output_ancestors, digest, options, policy, preconditions, require, scan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options(parser)
    args = parser.parse_args()
    receipts = preconditions(args)
    members, excluded = scan()
    require(all(row['path'] not in {'manifest.json', 'sources-and-checks.tar.gz'} for row in members), 'unexpected recursive evidence output')
    for row in receipts['inputs'].values():
        require(str(Path(row['path']).relative_to(H)) in {m['origin'] for m in members}, 'selected receipt excluded')
    check_output_ancestors(allow_missing=True)
    OUTPUT.mkdir(parents=True, exist_ok=True)
    check_output_ancestors(allow_missing=False)
    archive = OUTPUT / 'sources-and-checks.tar.gz'
    manifest = OUTPUT / 'manifest.json'
    require(not archive.exists() and not manifest.exists(), 'evidence outputs already exist')
    # O_EXCL prevents replacing any retained failed or published output.
    with archive.open('xb') as output:
        with gzip.GzipFile(filename='', mode='wb', compresslevel=9, mtime=0, fileobj=output) as zipped:
            with tarfile.open(mode='w|', format=tarfile.USTAR_FORMAT, fileobj=zipped) as tar:
                for row in members:
                    path = H / row['origin']
                    require(binding(path) == dict(path=str(path), bytes=row['bytes'], sha256=row['sha256']), 'origin changed during archive: ' + row['origin'])
                    info = tarfile.TarInfo(row['path'])
                    info.size = row['bytes']; info.mode = 0o644
                    info.uid = info.gid = info.mtime = 0
                    info.uname = info.gname = ''
                    with path.open('rb') as source:
                        tar.addfile(info, source)
    require(scan()[0] == members, 'frozen eligible artifacts changed during packaging')
    require(preconditions(args) == receipts, 'selected receipts/source/docs changed during packaging')
    record = dict(format=1, checkpoint='promise-class-admission', origin_root=str(H),
                  archive=dict(path=archive.name, bytes=archive.stat().st_size, sha256=digest(archive.read_bytes())),
                  member_count=len(members), member_bytes=sum(row['bytes'] for row in members),
                  members=members, excluded_at_packaging=excluded, selection_policy=policy(),
                  receipts=receipts, deterministic=dict(tar='USTAR', uid=0, gid=0, mode='0644', mtime=0, gzip_mtime=0, gzip_level=9),
                  scope='Frozen selected implementation, controls, tests, logs, reports and review artifacts; not a complete self-contained build graph. Runtime binaries are represented by retained provenance records.')
    with manifest.open('x') as stream:
        json.dump(record, stream, indent=2); stream.write('\n')
    print(json.dumps(dict(manifest=binding(manifest), archive=binding(archive), members=len(members))))


if __name__ == '__main__':
    main()
