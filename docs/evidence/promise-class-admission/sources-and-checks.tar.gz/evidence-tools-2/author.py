"""Additive source-only evidence-tool safeguards; no packager execution."""
import ast,difflib,hashlib,json
from pathlib import Path
P=Path(__file__).resolve().parent;O=P.parent/'evidence-tools-1'
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,text):
 with (P/name).open('x') as f:f.write(text)
def dump(name,value):write(name,json.dumps(value,indent=2)+'\n')
changes={
'evidence_common.py':[
("    require(contains_hash(loaded['documentation_review'], selected['documentation_hold']['sha256']), 'documentation peer does not bind selected hold')\n",
 "    require(contains_hash(loaded['documentation_review'], selected['documentation_hold']['sha256']), 'documentation peer does not bind selected hold')\n    for name in ('documentation_hold', 'documentation_review'):\n        require(contains_hash(loaded[name], selected['final_validation']['sha256']),\n                name + ' does not bind selected final ledger')\n"),
("\ndef scan():\n", """
def check_output_ancestors(allow_missing):
    # Inspect lexical paths with lstat: never resolve through an existing link.
    for path in reversed((OUTPUT, *OUTPUT.parents)):
        try:
            mode = path.lstat().st_mode
        except FileNotFoundError:
            require(allow_missing, 'missing output directory: ' + str(path))
            continue
        require(stat.S_ISDIR(mode) and not stat.S_ISLNK(mode),
                'output ancestor is a symlink or non-directory: ' + str(path))


def scan():
""")],
'package.py':[
("from evidence_common import H, OUTPUT, binding, digest, options, policy, preconditions, require, scan",
 "from evidence_common import H, OUTPUT, binding, check_output_ancestors, digest, options, policy, preconditions, require, scan"),
("    OUTPUT.mkdir(parents=True, exist_ok=True)\n", "    check_output_ancestors(allow_missing=True)\n    OUTPUT.mkdir(parents=True, exist_ok=True)\n    check_output_ancestors(allow_missing=False)\n")],
'verify.py':[]}
rows=[]
for name,replacements in changes.items():
 a=(O/name).read_text();b=a
 for old,new in replacements:
  assert b.count(old)==1,(name,old)
  b=b.replace(old,new)
 inverse=b
 for old,new in reversed(replacements):inverse=inverse.replace(new,old)
 assert inverse==a
 ast.parse(b);write(name,b)
 if a!=b:write(name+'.diff',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='evidence-tools-1/'+name,tofile='evidence-tools-2/'+name)))
 rows.append(dict(path=name,before=bound(O/name),after=bound(P/name),exact_inverse=True,changed=a!=b))
contract=json.loads((O/'execution-contract.json').read_text())
contract['commands']=[s.replace('evidence-tools-1/','evidence-tools-2/').replace('documentation-1/source-ready.json','documentation-2/source-ready.json') for s in contract['commands']]
contract['additional_safeguards']=['Both selected documentation hold and documentation peer must bind selected final ledger SHA.',
 'Output path and every ancestor must be a directory, never a symlink, before directory creation; missing paths allowed only at this first check. Require all created directories again before opening archive/manifest.']
dump('execution-contract.json',contract)
dump('delta.json',dict(status='source-only additive safeguards; unexecuted',original=bound(O/'source-ready.json'),files=rows,
 changes=['Two documentation-to-final-ledger hash requirements.','Output ancestor lstat checks before mkdir and after mkdir, before output opens.'],
 preserved=['No-extraction verifier bytes unchanged.','Selection/origin/hash policy and deterministic tar/gzip construction unchanged.','Hold1 and selected documentation hold unchanged.'],project_execution=False,live_edits=False))
files=[p for p in sorted(P.iterdir()) if p.is_file()]
dump('source-ready.json',dict(status='source-ready additive evidence safeguards; unexecuted',supersedes=bound(O/'source-ready.json'),files=[bound(p) for p in files],project_execution=False,live_edits=False))
print(json.dumps(bound(P/'source-ready.json')))
