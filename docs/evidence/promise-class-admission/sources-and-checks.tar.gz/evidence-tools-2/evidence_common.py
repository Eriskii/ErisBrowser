"""Evidence selection and preconditions. Only root executes this held tool."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import stat

TOOLS = Path(__file__).resolve().parent
H = TOOLS.parent
W = H / 'worktree'
OUTPUT = W / 'docs/evidence/promise-class-admission'
EXCLUDED_TOP = {'worktree', 'publication'}
EXCLUDED_DIRS = {'__pycache__', '.git', 'target'}
EXCLUDED_PATHS = {'root/evidence-selection.json', 'root/publication-verification.json',
                  'root/github-publication.json', 'root/git-publication.json'}
DOCS = {'README.md', 'docs/ROADMAP.md', 'docs/VALIDATION.md', 'docs/classes.md',
        'docs/promise-class-admission.md'}
MAX_MEMBERS = 20000
MAX_BYTES = 128 * 1024 * 1024


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    require(stat.S_ISREG(path.lstat().st_mode), 'not a regular file: ' + str(path))
    for ancestor in path.parents:
        require(not ancestor.is_symlink(), 'symlink ancestor: ' + str(ancestor))
        if ancestor == H:
            break


def binding(path):
    regular(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def read_json(path):
    regular(path)
    return json.loads(path.read_bytes())


def relative_file(value):
    rel = PurePosixPath(value)
    require(not rel.is_absolute() and str(rel) == value and '..' not in rel.parts,
            'expected normalized H-relative path: ' + value)
    path = H.joinpath(*rel.parts)
    regular(path)
    return path


def contains_hash(value, expected):
    if isinstance(value, dict):
        return any(contains_hash(v, expected) for v in value.values())
    if isinstance(value, list):
        return any(contains_hash(v, expected) for v in value)
    return value == expected


def options(parser):
    parser.add_argument('--source-inventory', default='source-final.json')
    parser.add_argument('--final-validation', default='root/final-validation.json')
    parser.add_argument('--validation-review', default='validation-review-1/final-review.json')
    parser.add_argument('--documentation-hold', default='documentation-1/source-ready.json')
    parser.add_argument('--documentation-review', default='documentation-review-1/review.json')


def preconditions(args):
    selected = {name: binding(relative_file(getattr(args, name))) for name in
                ('source_inventory', 'final_validation', 'validation_review', 'documentation_hold', 'documentation_review')}
    loaded = {name: read_json(Path(row['path'])) for name, row in selected.items()}
    require(loaded['final_validation'].get('status') == 'pass', 'final validation must pass')
    for name in ('validation_review', 'documentation_review'):
        require(loaded[name].get('status') == 'clear', name + ' must be clear')
    require(contains_hash(loaded['final_validation'], selected['source_inventory']['sha256']), 'final ledger does not bind source inventory')
    require(contains_hash(loaded['validation_review'], selected['final_validation']['sha256']), 'validation peer does not bind final ledger')
    require(contains_hash(loaded['documentation_review'], selected['documentation_hold']['sha256']), 'documentation peer does not bind selected hold')
    for name in ('documentation_hold', 'documentation_review'):
        require(contains_hash(loaded[name], selected['final_validation']['sha256']),
                name + ' does not bind selected final ledger')
    hashes = loaded['source_inventory']['source_sha256']
    require(type(hashes) is dict and hashes, 'selected source inventory empty')
    for rel, sha in hashes.items():
        path = W / rel
        regular(path)
        require(digest(path.read_bytes()) == sha, 'selected worktree source differs: ' + rel)
    raw = Path(selected['documentation_hold']['path']).parent / 'raw'
    documents = {str(p.relative_to(raw)): p for p in raw.rglob('*') if p.is_file()}
    require(set(documents) == DOCS, 'selected five documentation paths differ')
    doc_bindings = {}
    for rel, path in sorted(documents.items()):
        row = binding(path)
        require(contains_hash(loaded['documentation_hold'], row['sha256']), 'raw documentation not sealed: ' + rel)
        regular(W / rel)
        require((W / rel).read_bytes() == path.read_bytes(), 'imported documentation differs: ' + rel)
        doc_bindings[rel] = row
    return dict(inputs=selected, documents=doc_bindings, selected_source_count=len(hashes),
                qualification='Cumulative selected source inventory, not a self-contained complete build graph.')


def check_output_ancestors(allow_missing):
    # Inspect lexical paths with lstat: never resolve through an existing link.
    for path in reversed((OUTPUT, *OUTPUT.parents)):
        try:
            mode = path.lstat().st_mode
        except FileNotFoundError:
            require(allow_missing, 'missing output directory: ' + str(path))
            continue
        require(stat.S_ISDIR(mode) and not stat.S_ISLNK(mode),
                'output ancestor is a symlink or non-directory: ' + str(path))


def scan():
    members = []
    skipped = []
    total = 0
    def walk(directory):
        nonlocal total
        for entry in sorted(os.scandir(directory), key=lambda e: e.name):
            path = Path(entry.path)
            rel = path.relative_to(H).as_posix()
            top = rel.split('/')[0]
            if entry.is_symlink():
                skipped.append(dict(path=rel, reason='symlink; never followed'))
                continue
            if (top in EXCLUDED_TOP or top.startswith('target') or rel in EXCLUDED_PATHS
                    or (entry.is_dir(follow_symlinks=False) and entry.name in EXCLUDED_DIRS)):
                skipped.append(dict(path=rel, reason='explicit publication/worktree/build exclusion'))
                continue
            if entry.is_dir(follow_symlinks=False):
                walk(path)
                continue
            require(entry.is_file(follow_symlinks=False), 'unsupported filesystem object: ' + rel)
            if top == 'binaries' and path.suffix != '.json':
                skipped.append(dict(path=rel, reason='runtime binary bytes excluded; JSON provenance retained'))
                continue
            require(entry.name not in {'.env', 'id_rsa', 'id_ed25519', 'credentials', 'credentials.json'}
                    and path.suffix not in {'.pem', '.p12', '.key'}, 'credential-shaped artifact requires separate review: ' + rel)
            data = path.read_bytes()
            require(not data.startswith((b'\x7fELF', b'MZ')), 'unexpected executable outside excluded binaries: ' + rel)
            total += len(data)
            members.append(dict(path=rel, origin=rel, bytes=len(data), sha256=digest(data)))
            require(len(members) <= MAX_MEMBERS and total <= MAX_BYTES, 'evidence selection exceeds safety bound')
    walk(H)
    members.sort(key=lambda row: row['path'])
    skipped.sort(key=lambda row: row['path'])
    return members, skipped


def policy():
    return dict(excluded_top=sorted(EXCLUDED_TOP), excluded_top_prefixes=['target'],
                excluded_directories=sorted(EXCLUDED_DIRS), excluded_paths=sorted(EXCLUDED_PATHS),
                symlinks='never followed', binaries='binaries/**/*.json retained; all other binary directory files excluded',
                max_members=MAX_MEMBERS, max_uncompressed_member_bytes=MAX_BYTES)
