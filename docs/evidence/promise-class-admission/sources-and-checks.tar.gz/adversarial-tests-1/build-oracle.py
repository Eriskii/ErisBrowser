from pathlib import Path
import copy, hashlib, json
H=Path('/tmp/eris-promise-class-admission-plan-1');D=H/'adversarial-tests-1';C=H/'control-contract-1'
def read(p):return json.loads(Path(p).read_text())
def sha(b):return hashlib.sha256(b).hexdigest()
assert not (D/'source-ready.json').exists()
refs=[]; ref_index={}; observations=[]; obs_index={}; old=[]; old_index={}
def intern(value,pool,index):
 key=json.dumps(value,sort_keys=True,ensure_ascii=True)
 if key not in index:index[key]=len(pool);pool.append(copy.deepcopy(value))
 return index[key]
legacy={};reports=[]
for prefix in read(C/'old-prefix-identities.json'):
 p=prefix['profile'];report=prefix['source_report'];b=Path(report['path']).read_bytes();assert sha(b)==report['sha256']
 rows=read(report['path'])['harness_preflight'];indices=[]
 for row,expected in zip(rows,prefix['ordered_rows']):
  r=row['result'];assert all(r[k]==expected[k]for k in ['id','file','mode','case_sha256','source_sha256','expected_negative'])
  item=copy.deepcopy(row);item['prerequisites']=[intern(x,refs,ref_index)for x in item['prerequisites']]
  item['result']['observation']=intern(item['result']['observation'],observations,obs_index)
  indices.append(intern(item,old,old_index))
 assert len(indices)==prefix['count'];legacy[p]=indices;reports.append(report)
variants=read(C/'variants.json');literals=[{'family':x['family'],'variant':x['variant'],'source':x['source'],'sha256':x['source_sha256']}for x in variants]
literal_index={(x['family'],x['variant']):i for i,x in enumerate(literals)}
new={p:[]for p in legacy}
for r in read(C/'cases.json'):
 row=copy.deepcopy(r);row['literal']=literal_index[(row.pop('literal_family'),row['variant'])]
 assert row.pop('source')==literals[row['literal']]['source'];row.pop('source_binding')
 row['prerequisites']=[intern(x,refs,ref_index)for x in row['prerequisites']]
 new[row['profile']].append(row)
census=read('/tmp/eris-promise-class-admission-readiness-1/census.json')
inventories={p['profile']:[[r['id'],r['case_sha256'],r['source_sha256']]for r in p['cases']]for p in census['profiles']}
helpers=read(H/'gate-design-1/helper-pins.json')['profiles']
oracle={'schema':1,'base':'315300e6324fd4232fa53cb8d6a5b46a2c906dc5','profiles':list(legacy),'literals':literals,'references':refs,'legacy_observations':observations,'legacy_rows':old,'legacy_prefixes':legacy,'new_rows':new,'helpers':helpers,'inventory_identities':inventories,'counts':{'old':588,'new':84,'combined':672,'inventory':1280},'provenance':{'legacy':'Exact retained pre-existing report observations, with identity/prerequisite joins to the frozen control contract. These are fixtures for the unchanged controls only.','new':'Source-derived expectations from independent control-contract-1, never observed candidate results.','main':'Healthy dispatch replies are deliberately synthetic plumbing fixtures, not predictions for upstream source outcomes.'}}
p=D/'raw/tools/promise-class-controls-oracle.json';p.write_text(json.dumps(oracle,separators=(',',':'),ensure_ascii=True)+'\n')
print(json.dumps({'bytes':p.stat().st_size,'sha256':sha(p.read_bytes()),'unique_legacy_rows':len(old),'unique_legacy_observations':len(observations),'unique_references':len(refs),'literals':len(literals),'legacy':sum(map(len,legacy.values())),'new':sum(map(len,new.values())),'inventory':sum(map(len,inventories.values()))},indent=2))
