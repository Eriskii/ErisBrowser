from pathlib import Path
import ast,copy,difflib,hashlib,json,subprocess
H=Path('/tmp/eris-promise-class-admission-plan-1');D=H/'adversarial-tests-1';C=H/'control-contract-1';W=H/'worktree'
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(p):return json.loads(Path(p).read_text())
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(p,v):p.write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
assert not(D/'source-ready.json').exists()
assert sha((C/'source-ready.json').read_bytes())=='79bd0708684c0b0b3b15028f72450e1aac4c37a072366eaa34d85fbae91a8328'
O=D/'raw/tools/promise-class-controls-oracle.json';oracle=load(O);module=D/'raw/tools/test_test262_promise_class_controls.py';code=module.read_text();tree=ast.parse(code)
assert sha(O.read_bytes())=='c1d75f68d8b49e8eebe4dee1627fce658c6a632ef462d15d381cb31d8263bb2e'
assert sha(O.read_bytes()) in code
classes=[n for n in tree.body if isinstance(n,ast.ClassDef)];assert len(classes)==1
methods={n.name:n for n in classes[0].body if isinstance(n,ast.FunctionDef)}
tests=[n for n in methods if n.startswith('test_')];assert len(tests)==13
for name in tests:
 if name!='test_frozen_oracle_retains_eighteen_sources_and_single_assertion_pairs':
  assert ast.unparse(methods[name].body[0])=='self.require_class()',name
snapshot=(C/'source-snapshots/test262_conformance.py').read_bytes()
assert subprocess.run(['git','show',BASE+':tools/test262_conformance.py'],cwd=W,check=True,stdout=subprocess.PIPE).stdout==snapshot
parent_names={n.name for n in ast.parse(snapshot).body if isinstance(n,ast.FunctionDef)}
assert 'promise_class_preflight_variants' not in parent_names
# Lossless compact oracle readback, without importing/executing test or project code.
variants=load(C/'variants.json');assert len(oracle['literals'])==18
for row,held in zip(oracle['literals'],variants):
 assert row['source']==held['source'] and sha(row['source'].encode())==held['source_sha256']==row['sha256']
def refs(ids):return [copy.deepcopy(oracle['references'][i])for i in ids]
legacy_reports=[];legacy_total=0;cross_mode=0
for prefix in load(C/'old-prefix-identities.json'):
 profile=prefix['profile'];report=prefix['source_report'];data=Path(report['path']).read_bytes();assert sha(data)==report['sha256']
 original=json.loads(data)['harness_preflight'];restored=[]
 for i in oracle['legacy_prefixes'][profile]:
  item=copy.deepcopy(oracle['legacy_rows'][i]);item['prerequisites']=refs(item['prerequisites']);item['result']['observation']=copy.deepcopy(oracle['legacy_observations'][item['result']['observation']]);restored.append(item)
 assert restored==original
 for item in restored:
  cross_mode+=sum(r['mode']!=item['result']['mode']for r in item['prerequisites'])
 legacy_total+=len(restored);legacy_reports.append(report)
assert legacy_total==588 and cross_mode>0
held_cases=load(C/'cases.json');all_new=[r for p in oracle['profiles']for r in oracle['new_rows'][p]];assert len(all_new)==84
edges=0
for held,row in zip(held_cases,all_new):
 restored=copy.deepcopy(row);literal=oracle['literals'][restored.pop('literal')];restored['literal_family']=literal['family'];restored['source']=literal['source'];restored['prerequisites']=refs(restored['prerequisites'])
 expected={k:v for k,v in held.items()if k!='source_binding'};assert restored==expected
 edges+=len(restored['prerequisites']);assert all(r['mode']==restored['mode']for r in restored['prerequisites'])
 identity={'source_sha256':restored['source_sha256'],'mode':restored['mode'],'metadata':restored['metadata'],'harness':restored['harness']}
 if 'completion_policy'in restored:identity['completion_policy']=restored['completion_policy']
 assert sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())==restored['case_sha256']
assert edges==246
assert oracle['helpers']==load(H/'gate-design-1/helper-pins.json')['profiles']
census=load('/tmp/eris-promise-class-admission-readiness-1/census.json')
for p in census['profiles']:
 assert oracle['inventory_identities'][p['profile']]==[[r['id'],r['case_sha256'],r['source_sha256']]for r in p['cases']]
assert sum(map(len,oracle['inventory_identities'].values()))==1280
paths=['tools/test_test262_promise_class_controls.py','tools/promise-class-controls-oracle.json'];files=[]
for rel in paths:
 absent=subprocess.run(['git','ls-tree','--name-only',BASE,'--',rel],cwd=W,check=True,stdout=subprocess.PIPE).stdout
 assert not absent,rel
 p=D/'raw'/rel;patch=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+rel))
 dest=D/'diff'/(rel+'.patch');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(patch)
 files.append({'relative_path':rel,'before':None,'raw':bind(p),'diff':bind(dest)})
roster={'test_class':classes[0].name,'groups':13,'names':tests,
 'parent_prediction':{'passed_groups':1,'failed_groups':12,'first_failure':'require_class: selected class gate API promise_class_preflight_variants is absent','unreached':'All new canonical/gate/wrapper/main assertions are after this guard. Only the frozen-oracle local byte/pair group reaches its assertions on the parent.','qualification':'Source-derived expected parent reachability, not an observed execution.'},
 'selected_scope':{'new_rows':84,'old_rows':588,'literals':18,'new_edges':246,'legacy_cross_mode_edges_preserved':cross_mode,'original_case_modes':1280,'profiles':7,'helper_entries':sum(map(len,oracle['helpers'].values()))},
 'main_paths':{'failed_gate':{'profiles':7,'baseline_states':['absent','existing'],'calls':14,'raw_forgery':'Nonempty harness on final mismatch with all verified flags still True','inventory_adapter_calls_expected':0},'healthy_dispatch':{'profiles':7,'calls':7,'case_calls_total':1280,'qualification':'Deliberately synthetic pass responses prove routing/record plumbing only, not upstream outcomes.'}},
 'coverage':['Exact complete canonical prefix/suffix source and case fingerprints, literal bytes, helper order and old/new prerequisite orders','Wrapper preserves old records and their verified flags, invokes old producer once and only12 new adapter calls per profile','Malformed/extra/missing/reordered/unhashable identities, exact schemas, bool/int substitutions and verified/raw disagreement','Host completion and ordinary raw dictionaries, exact harness/identity/phase, UTF-8 limits including surrogate rejection and boundary acceptance','Exact six-field new references, failed-positive propagation, canonical self/two-node cycles with matching forged references','All42 pinned helper entries missing/corrupt/wrong-type before producer, plus self-consistent forged helper fingerprints','Oldest four unchanged weak health predicates contrasted with new raw rejection; preserved old-gate failure still blocks','Ordinary completion field/policy and valid ERJR3 response refused under old API','Complete original1280 inventory block, untouched absent/existing record baselines, healthy synthetic protocol dispatch'],
 'independence':'No producer source/implementation was read. Tests bind the frozen independent literal contract and prior legacy reports; retained legacy observations are never used to infer new control or upstream outcomes.'}
write(D/'test-contract.json',roster)
inputs=[C/'source-ready.json',C/'cases.json',C/'variants.json',C/'old-prefix-identities.json',C/'gate-contract.json',H/'gate-design-1/source-ready.json',H/'gate-design-1/design.json',H/'gate-design-1/helper-pins.json',H/'root/selection-1.json',H/'source-parent.json']
write(D/'checks.json',{'status':'source-only checks passed','base':BASE,'ast_parse':True,'module_groups':13,'parent_apis_absent':True,'literal_byte_readbacks':18,'legacy_row_readbacks':588,'new_case_readbacks':84,'new_case_fingerprints_recomputed':84,'new_prerequisite_edges':246,'legacy_cross_mode_edges_preserved':cross_mode,'full_inventory_identities':1280,'unique_legacy_rows':len(oracle['legacy_rows']),'unique_legacy_observations':len(oracle['legacy_observations']),'unique_references':len(oracle['references']),'oracle_bytes':O.stat().st_size,'exact_new_file_diffs':2,'new_paths_absent_in_published_parent':True,'inputs':[bind(p)for p in inputs],'legacy_report_bindings':legacy_reports,'no_project_execution_imports_or_live_edits':True,'producer_inspected':False})
write(D/'source-ready.json',{'status':'source-ready independent adversarial tests','base':BASE,'files':files,'contract':bind(D/'test-contract.json'),'checks':bind(D/'checks.json'),'literal_source_ready':bind(C/'source-ready.json'),'gate_design':bind(H/'gate-design-1/source-ready.json'),'authoring':[bind(D/'build-oracle.py'),bind(D/'seal.py')],'test_groups':13,'new_paths':2,'parent_prediction':roster['parent_prediction'],'qualification':'External held source only. Runtime tests, imports, adapters, engines and all project commands remain root-owned and unexecuted by this author. No Rust or live source changes.'})
print(json.dumps({'source_ready':bind(D/'source-ready.json'),'tests':bind(module),'oracle':bind(O),'groups':13,'legacy_cross_mode_edges':cross_mode},indent=2))
