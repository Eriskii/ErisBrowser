#!/usr/bin/env python3
"""Root-only serial measurement; stdlib only, never writes a baseline."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

P = Path(__file__).resolve().parent
H = P.parent
W = H / 'worktree'
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
RAW_STRINGS = ('status', 'phase', 'error_type', 'error_identity', 'message', 'harness')
COMPLETION_INTS = ('policy', 'done_calls', 'success_prints', 'failure_prints', 'flags', 'unhandled')
STATUSES = {'passed', 'failed', 'unsupported'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bound(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def read_bound(binding):
    require(bound(binding['path']) == binding, 'binding changed: ' + binding['path'])
    return json.loads(Path(binding['path']).read_bytes())


def strict_equal(left, right):
    if type(left) is not type(right):
        return False
    if type(left) is dict:
        return left.keys() == right.keys() and all(strict_equal(left[k], right[k]) for k in left)
    if type(left) is list:
        return len(left) == len(right) and all(strict_equal(a, b) for a, b in zip(left, right))
    return left == right


def identity(row):
    return {key: row[key] for key in IDENTITY}


def exclusive_json(path, data):
    with Path(path).open('x') as stream:
        json.dump(data, stream, indent=2)
        stream.write('\n')


def static_checks(contract, inventory, inventory_binding, phase):
    require(bound(inventory_binding['path']) == inventory_binding, 'selected source inventory changed')
    for item in contract['bindings']:
        require(bound(item['path']) == item, 'contract input changed: ' + item['path'])
    for rel, expected in inventory['source_sha256'].items():
        require(sha((W / rel).read_bytes()) == expected, 'selected source changed: ' + rel)
    parent = read_bound(contract['source_parent'])
    for rel, expected in parent['source_sha256'].items():
        if rel.startswith(('src/', 'shaders/', 'assets/')) or rel in ('Cargo.toml', 'Cargo.lock', 'build.rs'):
            require(sha((W / rel).read_bytes()) == expected, 'runtime/build input changed: ' + rel)
    require(sha((W / 'tools/test262_conformance.py').read_bytes()) == contract['runner_sha256'][phase],
            'runner does not match selected ' + phase + ' payload')
    for root, expected_files in contract['preserved_trees'].items():
        directory = W / root
        actual = {str(p.relative_to(W)): sha(p.read_bytes()) for p in directory.rglob('*') if p.is_file()}
        require(actual == expected_files, 'preserved tree changed: ' + root)
    for item in contract['preserved_files']:
        require(sha((W / item['path']).read_bytes()) == item['sha256'], 'preserved file changed: ' + item['path'])


def freeze_binary(kind, contract):
    path = H / 'binaries' / ('eris-js-' + kind + '-1')
    sidecar = bound(path.with_suffix('.json'))
    record = read_bound(sidecar)
    require(set(record) == {'binary', 'bytes', 'sha256', 'source_inventory', 'build', 'environment', 'features', 'toolchain'}, 'binary record schema')
    require(record['binary'] == str(path), 'binary path')
    require(bound(path) == dict(path=str(path), bytes=record['bytes'], sha256=record['sha256']), 'binary content')
    require(record['source_inventory'] == contract['source_parent'], 'binary was not built from selected parent')
    read_bound(record['source_inventory'])
    build = read_bound(record['build'])
    environment = read_bound(record['environment'])
    expected_features = [] if kind == 'ordinary' else ['test262-host']
    expected_version = '1.88.0' if kind == 'ordinary' else '1.99.0'
    label = 'parent-release-' + kind + '-1'
    require(record['features'] == expected_features and record['toolchain'] == expected_version, 'binary feature/toolchain')
    require(record['build']['path'] == str(H / 'validation' / (label + '.json')), 'build receipt path')
    require(record['environment']['path'] == str(H / 'validation' / (label + '-environment.json')), 'environment receipt path')
    command = ['cargo', '+' + expected_version, 'build', '--locked', '--offline']
    if expected_features:
        command += ['--features', 'test262-host']
    command += ['--release', '--bin', 'eris-js']
    require(build['command'] == command and type(build['exit']) is int and build['exit'] == 0, 'successful release build command')
    require(build['log'] == label + '.log', 'build log path')
    log = bound(H / 'validation' / build['log'])
    require(log['sha256'] == build['sha256'], 'build log hash')
    require(environment['toolchain'] == expected_version and environment['features'] == ([] if kind == 'ordinary' else ['--features', 'test262-host']), 'build environment')
    require(environment['config'] == ('msrv' if kind == 'ordinary' else 'host'), 'build configuration')
    return dict(binary=bound(path), sidecar=sidecar, record=record, build_log=log)


def binary_checks(binaries):
    for item in binaries.values():
        for binding in (item['binary'], item['sidecar'], item['record']['source_inventory'],
                        item['record']['build'], item['record']['environment'], item['build_log']):
            require(bound(binding['path']) == binding, 'binary provenance changed: ' + binding['path'])


def raw_schema(raw, host):
    require(type(raw) is dict and set(raw) == set(RAW_STRINGS) | ({'completion'} if host else set()), 'raw observation schema')
    for name in RAW_STRINGS:
        require(type(raw[name]) is str and len(raw[name].encode('utf-8')) <= 16384, 'bounded raw string ' + name)
    if host:
        c = raw['completion']
        require(type(c) is dict and set(c) == set(COMPLETION_INTS) | {'quiescent', 'audited'}, 'completion schema')
        require(all(type(c[name]) is int and c[name] >= 0 for name in COMPLETION_INTS), 'completion scalar types')
        require(type(c['quiescent']) is bool and type(c['audited']) is bool, 'completion boolean types')


def check_new_control(actual, expected, by_identity):
    require(type(actual) is dict and set(actual) == {'name', 'expected', 'verified', 'result', 'prerequisites'}, 'new control schema')
    require(actual['name'] == expected['name'] and actual['expected'] == expected['expected'] and actual['verified'] is True, 'new control header')
    result = actual['result']
    require(type(result) is dict and set(result) == set(IDENTITY) | {'status', 'observation'}, 'new result schema')
    require(strict_equal(identity(result), identity(expected)), 'new control identity')
    require(strict_equal(actual['prerequisites'], expected['prerequisites']), 'new canonical prerequisites')
    require(result['status'] == expected['expected_status'], 'new recomputed result classification')
    raw = result['observation']
    raw_schema(raw, 'completion_policy' in expected)
    required = expected['required_observation']
    require(all(strict_equal(raw[key], value) for key, value in required.items()), 'new canonical raw observation')
    rule = expected['message_rule']
    if rule['kind'] == 'exact':
        require(raw['message'] == rule['value'], 'new exact message')
    else:
        require(rule['kind'] == 'bounded-diagnostic' and len(raw['message'].encode('utf-8')) <= rule['max_utf8_bytes'], 'new bounded diagnostic')
    # This independent reclassification has no negative tests: complete succeeds;
    # the frozen runtime Test262Error/host-completion mismatch observations fail.
    classification = 'passed' if raw['status'] == 'complete' else 'failed'
    require(classification == result['status'], 'new independent classification')
    for ref in actual['prerequisites']:
        target = by_identity[(ref['name'], ref['mode'])]
        require(target['verified'] is True and target['result']['status'] == 'passed', 'new positive prerequisite health')
        canonical = dict(name=target['name'], mode=target['result']['mode'], id=target['result']['id'],
                         case_sha256=target['result']['case_sha256'], source_sha256=target['result']['source_sha256'], expected=target['expected'])
        require(strict_equal(ref, canonical), 'new prerequisite joins')


def transition(before, after):
    return dict(id=after['id'], before_status=before['status'], after_status=after['status'],
                before=before, after=after)


def compare_report(profile, before, report, binary, phase, record, command):
    errors = []
    def check(condition, label):
        if not condition:
            errors.append(label)
    result = dict(profile=profile['profile'], name=profile['name'], errors=errors,
                  case_record_changes=[], control_record_changes=[], prior_pass_regressions=[],
                  newly_passed=[], nonpass_status_changes=[], raw_only_changes=[], outside_class_tag_changes=[])
    check(type(report) is dict and set(report) == set(before), 'report schema changed')
    for key in ('suite', 'full_test262_conformance', 'repository', 'revision', 'corpus_manifest_sha256',
                'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases'):
        check(strict_equal(report[key], before[key]), 'immutable report field: ' + key)
    check(report['full_test262_conformance'] is False, 'full conformance overclaim')
    policy = profile['policy']['before' if phase == 'parent' else 'after']
    policy_sha = profile['policy']['before_sha256' if phase == 'parent' else 'after_sha256']
    check(strict_equal(report['runner_policy'], policy), 'canonical profile policy')
    check(report['runner_policy_sha256'] == policy_sha == sha(json.dumps(policy, sort_keys=True).encode()), 'canonical policy digest')
    check(report['binary'] == binary['binary']['path'] and report['binary_sha256'] == binary['binary']['sha256'], 'report binary binding')
    check(report['regressions'] == [] and report['improvements'] == [], 'unexpected baseline-derived comparisons')
    cases, controls = report['cases'], report['harness_preflight']
    check(type(cases) is list and len(cases) == profile['cases'], 'complete case denominator')
    check([identity(row) for row in cases] == profile['case_identities'], 'ordered case identities')
    check(len({row['id'] for row in cases}) == len(cases), 'duplicate cases')
    check(all(type(row.get('status')) is str and row['status'] in STATUSES for row in cases), 'case status schema')
    check(strict_equal(report['counts'], dict(Counter(row['status'] for row in cases))), 'case counts')
    check(report['harness_preflight_passed'] is True, 'preflight not healthy')
    suffix = profile['new_controls'] if phase == 'candidate' else []
    check(type(controls) is list and len(controls) == profile['controls'] + len(suffix), 'complete control denominator')
    old = controls[:profile['controls']]
    before_old = before['harness_preflight'][:profile['controls']]
    check(all(row.get('verified') is True for row in controls), 'unverified control')
    check(strict_equal(old, before_old), 'old complete control rows changed')
    for a, b in zip(before_old, old):
        if not strict_equal(a, b):
            result['control_record_changes'].append(dict(name=b.get('name'), before=a, after=b))
    keys = [(row['name'], row['result']['mode']) for row in controls]
    check(len(set(keys)) == len(keys), 'duplicate control identities')
    by_identity = dict(zip(keys, controls))
    for actual, expected in zip(controls[profile['controls']:], suffix):
        try:
            check_new_control(actual, expected, by_identity)
        except (KeyError, TypeError, ValueError, UnicodeError) as error:
            errors.append('new control ' + expected['name'] + '/' + expected['mode'] + ': ' + str(error))
    check([dict(name=r['name'], expected=r['expected'], **identity(r['result']), prerequisites=r['prerequisites']) for r in old] == profile['old_control_identities'], 'old canonical identity/reference order')
    for a, b in zip(before['cases'], cases):
        if not strict_equal(a, b):
            t = transition(a, b)
            result['case_record_changes'].append(t)
            if a['status'] == 'passed' and b['status'] != 'passed':
                result['prior_pass_regressions'].append(t)
            elif a['status'] != 'passed' and b['status'] == 'passed':
                result['newly_passed'].append(t)
            elif a['status'] != b['status']:
                result['nonpass_status_changes'].append(t)
            else:
                result['raw_only_changes'].append(t)
            if b['id'] not in profile['class_case_ids']:
                result['outside_class_tag_changes'].append(t)
    check(not result['prior_pass_regressions'], 'prior passed case regressed')
    if profile['profile'] == 'aggregate-error':
        check(strict_equal(cases, before['cases']), 'unselected AggregateError case rows changed')
    # No --baseline or --record-baseline: a healthy report with any nonpass returns 1.
    expected_exit = 0 if all(row['status'] == 'passed' for row in cases) and report['harness_preflight_passed'] is True else 1
    check(type(record['exit']) is int and record['exit'] == expected_exit, 'report/exit mismatch')
    check(record['command'] == command and not any('baseline' in arg for arg in command), 'measurement command')
    check(all(row['status'] in STATUSES for row in cases), 'case status outside healthy replay set')
    result.update(counts=report['counts'], cases=len(cases), old_controls=len(old), new_controls=len(suffix),
                  controls=len(controls), observed_exit=record['exit'], policy_sha256=policy_sha)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('phase', choices=('parent', 'candidate'))
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--parent-attempt', type=int, default=1)
    parser.add_argument('--source-inventory', type=Path)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    require(args.attempt > 0 and args.parent_attempt > 0, 'positive attempt numbers')
    contract = json.loads((P / 'contract.json').read_bytes())
    inventory_path = args.source_inventory or H / 'source-parent.json'
    require(args.phase == 'parent' or args.source_inventory is not None, 'candidate requires explicit source inventory')
    inventory_binding = bound(inventory_path.resolve())
    inventory = read_bound(inventory_binding)
    if args.phase == 'parent':
        require(inventory_binding == contract['source_parent'], 'parent inventory must be the published source')
    static_checks(contract, inventory, inventory_binding, args.phase)
    binaries = {kind: freeze_binary(kind, contract) for kind in ('ordinary', 'host')}
    parent_summary_binding = None
    parent_summary = None
    if args.phase == 'candidate':
        parent_summary_binding = bound(H / 'root' / ('profile-parent-' + str(args.parent_attempt) + '.json'))
        parent_summary = read_bound(parent_summary_binding)
        require(parent_summary['status'] == 'pass' and parent_summary['phase'] == 'parent', 'candidate requires healthy completed parent capture')
        require(parent_summary['contract'] == bound(P / 'contract.json'), 'parent contract changed')
        require(parent_summary['runner'] == bound(Path(__file__)), 'parent replay runner changed')
        require(parent_summary['binaries'] == binaries, 'candidate must use exact parent frozen binaries')
    destination = H / 'root' / ('profile-' + args.phase + '-' + str(args.attempt) + '.json')
    require(not destination.exists(), 'summary already exists')
    rows = []
    for index, profile in enumerate(contract['profiles']):
        static_checks(contract, inventory, inventory_binding, args.phase)
        binary_checks(binaries)
        before_binding = profile['reference_report'] if parent_summary is None else parent_summary['profiles'][index]['report']
        before = read_bound(before_binding)
        report_path = H / ('upstream-class-' + args.phase + '-' + profile['name'] + '-' + str(args.attempt) + '.json')
        label = 'class-' + args.phase + '-' + profile['name'] + '-' + str(args.attempt)
        command = [sys.executable, '-B', 'tools/test262_conformance.py', '--binary', binaries[profile['binary_kind']]['binary']['path'],
                   '--profile', profile['profile'], '--output', str(report_path), '--jobs', '1', '--timeout', '3.0']
        if not args.check_only:
            require(not report_path.exists() and not (H / 'validation' / (label + '.json')).exists()
                    and not (H / 'validation' / (label + '.log')).exists(), 'attempt output already exists')
            subprocess.run([sys.executable, '-B', str(H / 'run-tool.py'), label, *command], check=False)
        try:
            receipt_path = H / 'validation' / (label + '.json')
            receipt_binding = bound(receipt_path)
            record = read_bound(receipt_binding)
            require(record['command'] == command and record['log'] == label + '.log', 'retained command/log path mismatch')
            log_binding = bound(H / 'validation' / record['log'])
            require(log_binding['sha256'] == record['sha256'], 'retained log hash mismatch')
            report_binding = bound(report_path)
            report = read_bound(report_binding)
            row = compare_report(profile, before, report, binaries[profile['binary_kind']], args.phase, record, command)
            row.update(report=report_binding, receipt=receipt_binding, log=log_binding, before=before_binding)
        except (OSError, KeyError, TypeError, ValueError, UnicodeError) as error:
            row = dict(name=profile['name'], profile=profile['profile'], errors=['retained measurement invalid: ' + str(error)],
                       before=before_binding, attempted_command=command,
                       retained=[bound(p) for p in (report_path, H / 'validation' / (label + '.json'), H / 'validation' / (label + '.log')) if p.is_file()])
        rows.append(row)
        # Runtime/source binding failures stop dispatch; a measurement failure does not.
        static_checks(contract, inventory, inventory_binding, args.phase)
        binary_checks(binaries)
        print(json.dumps(dict(profile=profile['profile'], counts=row.get('counts'), errors=row['errors'])), flush=True)
    require(len(rows) == 8, 'eight profile attempts required')
    summary = dict(status='pass' if all(not row['errors'] for row in rows) else 'fail', phase=args.phase,
                   attempt=args.attempt, contract=bound(P / 'contract.json'), runner=bound(Path(__file__)),
                   source_inventory=inventory_binding, binaries=binaries, parent_capture=parent_summary_binding,
                   expected_cases=1330, expected_selected_cases=1280, expected_unselected_cases=50,
                   expected_old_controls=640, expected_new_controls=84 if args.phase == 'candidate' else 0,
                   profiles=rows, baseline_writes=False,
                   qualification='All measured rows retained. Nonpass-to-failed and raw-only changes are reported, never relabelled as improvements. No previous pass regression is admitted.')
    summary['counts'] = dict(sum((Counter(row.get('counts', {})) for row in rows), Counter()))
    summary['transition_counts'] = {key: sum(len(row.get(key, [])) for row in rows) for key in
                                    ('case_record_changes', 'control_record_changes', 'prior_pass_regressions', 'newly_passed', 'nonpass_status_changes', 'raw_only_changes', 'outside_class_tag_changes')}
    exclusive_json(destination, summary)
    print(json.dumps(bound(destination)), flush=True)
    return 0 if summary['status'] == 'pass' else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, KeyError, TypeError, ValueError, UnicodeError) as error:
        print('Replay binding refusal: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
