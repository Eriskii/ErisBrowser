"""Additive held replay correction. Stdlib source checks only."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
P=Path(__file__).resolve().parent
O=P.parent/'profile-replay-1'
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(name,text):
 with (P/name).open('x') as f:f.write(text)
def dump(name,value):write(name,json.dumps(value,indent=2)+'\n')
a=(O/'replay.py').read_text()
changes=[
("STATUSES = {'passed', 'failed', 'unsupported', 'resource', 'harness-error', 'timeout', 'crash', 'protocol-error', 'blocked'}", "STATUSES = {'passed', 'failed', 'unsupported'}"),
("    check(not any(row['status'] in {'harness-error', 'timeout', 'crash', 'protocol-error', 'blocked'} for row in cases), 'adapter/gate infrastructure failure')", "    check(all(row['status'] in STATUSES for row in cases), 'case status outside healthy replay set')"),
("        require(parent_summary['contract'] == bound(P / 'contract.json'), 'parent contract changed')", "        require(parent_summary['contract'] == bound(P / 'contract.json'), 'parent contract changed')\n        require(parent_summary['runner'] == bound(Path(__file__)), 'parent replay runner changed')")]
b=a
for old,new in changes:
 assert b.count(old)==1
 b=b.replace(old,new)
ast.parse(b)
inverse=b
for old,new in reversed(changes):
 assert inverse.count(new)==1
 inverse=inverse.replace(new,old)
assert inverse==a
write('replay.py',b)
write('correction.diff',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='profile-replay-1/replay.py',tofile='profile-replay-2/replay.py')))
c=json.loads((O/'contract.json').read_text());d=json.loads(json.dumps(c))
d['commands']=[command.replace('profile-replay-1/replay.py','profile-replay-2/replay.py') for command in c['commands']]
assert d['bindings']==c['bindings']
for key in c:
 if key!='commands':assert c[key]==d[key]
dump('contract.json',d)
dump('correction.json',{'status':'source-ready additive correction; unexecuted','original':bound(O/'source-ready.json'),
 'healthy_case_statuses':['passed','failed','unsupported'],
 'retention':'Every observation/report remains retained. A resource, adapter-error, timeout or any other case status makes this replay fail; remaining profiles are still attempted unless an input binding fails.',
 'same_runner':'Candidate checks exact parent summary runner binding in addition to existing contract and binary bindings.',
 'exact_inverse':True,'contract_change':'Only two illustrative commands point to profile-replay-2; all contract evidence/input bindings are byte-for-byte identical values.',
 'project_execution':False,'live_edits':False})
dump('source-ready.json',{'status':'source-ready held additive replay correction; unexecuted','supersedes':bound(O/'source-ready.json'),
 'files':[bound(P/name) for name in ('author.py','replay.py','contract.json','correction.diff','correction.json')],
 'cases':1330,'old_controls':640,'new_controls':84,'baseline_writes':False,'project_execution':False,'live_edits':False})
print(json.dumps(bound(P/'source-ready.json')))
