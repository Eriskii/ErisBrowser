"""Independent inert source check; does not import project modules."""
import ast,collections,difflib,hashlib,json,pathlib,re,subprocess
H=pathlib.Path('/tmp/eris-promise-class-admission-plan-1');O=H/'migration-correction-review-1';C=H/'migration-correction-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads(p.read_bytes())
def dump(n):return ast.dump(n,include_attributes=False)
r=load(H/'root/migration-correction-1.json');a=(C/'before.py').read_bytes();b=(C/'after.py').read_bytes();rel=r['path']
assert bind(C/'before.py')['sha256']==r['before_sha256'] and bind(C/'after.py')['sha256']==r['after_sha256']
assert a==(H/'migrations-1/raw'/rel).read_bytes()
s=a.decode();z=b.decode();assert s.count(r['old'])==1 and z.count(r['new'])==1
assert s.replace(r['old'],r['new'])==z and z.replace(r['new'],r['old'])==s
assert ''.join(difflib.unified_diff(s.splitlines(True),z.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))==(C/'correction.diff').read_text()
i1=load(H/'source-candidate-1.json');i2=load(H/'source-candidate-2.json');assert i1['base']==i2['base'] and set(i1['source_sha256'])==set(i2['source_sha256'])
changed=[x for x in i1['source_sha256'] if i1['source_sha256'][x]!=i2['source_sha256'][x]];assert changed==[rel]
assert i1['source_sha256'][rel]==r['before_sha256'] and i2['source_sha256'][rel]==r['after_sha256']
assert (H/'worktree'/rel).read_bytes()==b
at,bt=ast.parse(s),ast.parse(z)
def methods(t):return {c.name+'.'+x.name:x for c in t.body if isinstance(c,ast.ClassDef) for x in c.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')}
am,bm=methods(at),methods(bt);assert set(am)==set(bm) and len(am)==9
changed_methods=[k for k in am if dump(am[k])!=dump(bm[k])];assert changed_methods==['WithResolversControlTests.test_healthy_builder_uses_selected_route_and_independently_checks_raw_rows']
for k in am:assert dump(am[k].args)==dump(bm[k].args)
for n in at.body:
 if isinstance(n,(ast.Assign,ast.FunctionDef)):assert dump(n) in [dump(x) for x in bt.body]
def calls(t):return collections.Counter(dump(x) for x in ast.walk(t) if isinstance(x,ast.Call) and isinstance(x.func,ast.Attribute) and x.func.attr in {'unsupported_reason','run_case'})
assert calls(at)==calls(bt)
# Source-derived route: this existing builder supplies selected features itself.
published=subprocess.check_output(['git','show','315300e6324fd4232fa53cb8d6a5b46a2c906dc5:tools/test262_conformance.py'],cwd=H/'worktree',text=True)
node=next(n for n in ast.parse(published).body if isinstance(n,ast.FunctionDef) and n.name=='with_resolvers_harness_preflight')
route=ast.get_source_segment(published,node);assert 'PROMISE_WITH_RESOLVERS_FEATURES, PROMISE_WITH_RESOLVERS_PROFILE' in route
current=(H/'worktree/tools/test262_conformance.py').read_text();newnode=next(n for n in ast.parse(current).body if isinstance(n,ast.FunctionDef) and n.name==node.name);assert ast.get_source_segment(current,newnode)==route
receipt=load(H/'validation/candidate-python-1.json');log=(H/'validation/candidate-python-1.log').read_text();assert bind(H/'validation/candidate-python-1.log')['sha256']==receipt['sha256'] and receipt['exit']==1
assert re.search(r'Ran 696 tests in [0-9.]+s\n\nFAILED \(failures=1\)',log)
assert len(re.findall(r'^FAIL:',log,re.M))==1 and 'FAIL: test_healthy_builder_uses_selected_route_and_independently_checks_raw_rows' in log
print(json.dumps(dict(status='clear',changed_paths=changed,retained_groups=len(am),changed_group=changed_methods[0],exact_inverse=True,selected_route_source_sha256=hashlib.sha256(route.encode()).hexdigest()),indent=2))
