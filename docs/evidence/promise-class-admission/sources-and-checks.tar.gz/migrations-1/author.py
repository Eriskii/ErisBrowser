"""External historical-test migration; stdlib only, never imports project code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

H=Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';O=H/'migrations-1'
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
before={};after={};edits=[]
def load(name):
 path='tools/'+name
 if path not in before:
  b=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+path]);before[path]=b.decode();after[path]=b.decode()
 return path
def edit(path,old,new,why,count=1):
 assert old!=new and after[path].count(old)==count,(path,old[:100],after[path].count(old),count)
 after[path]=after[path].replace(old,new)
 edits.append(dict(path=path,before=old,after=new,count=count,reason=why))

p=load('test_test262_promise_runner.py')
anchor="\ndef fixture_case():\n"
helpers='''
# Expected current policies are derived only from the immutable historical
# oracles and the explicit seven-profile class admission selection.
CLASS_ADMISSION_PROFILES = {
    'promise-methods-async', 'promise-all', 'promise-race',
    'promise-all-settled', 'promise-any', 'promise-with-resolvers', 'promise-try',
}


def class_admitted_features(profile, features):
    return sorted(set(features) | ({'class'} if profile in CLASS_ADMISSION_PROFILES else set()))


def class_admitted_policy(profile, policy, policy_sha256):
    assert digest(json.dumps(policy, sort_keys=True).encode()) == policy_sha256
    if profile not in CLASS_ADMISSION_PROFILES:
        return policy, policy_sha256
    current = copy.deepcopy(policy)
    current['supported_features'] = class_admitted_features(profile, policy['supported_features'])
    return current, digest(json.dumps(current, sort_keys=True).encode())

'''
edit(p,anchor,helpers+anchor,'Add test-only expected class overlay; retain exact historical hashes for all unselected profiles.')
edit(p,"self.assertEqual(runner.PROFILE_FEATURES[PROFILE], set(self.oracle['features']))","self.assertEqual(runner.PROFILE_FEATURES[PROFILE], set(class_admitted_features(PROFILE, self.oracle['features'])))",'Current selected feature map gains class; frozen caller oracle features unchanged.')
edit(p,"            if {'class', 'cross-realm'} & set(case['metadata']['features']):\n                self.assertIsNotNone(runner.unsupported_reason(case, runner.PROFILE_FEATURES[PROFILE], PROFILE))","            if 'cross-realm' in case['metadata']['features']:\n                self.assertIsNotNone(runner.unsupported_reason(case, runner.PROFILE_FEATURES[PROFILE], PROFILE))\n            elif 'class' in case['metadata']['features']:\n                self.assertIsNone(runner.unsupported_reason(case, runner.PROFILE_FEATURES[PROFILE], PROFILE))",'Only current profile class-only metadata becomes eligible; cross-realm refusal retained.')
edit(p,"        with tempfile.TemporaryDirectory() as temporary:\n            path = Path(temporary)","        # This fixture tests the old guard and reporting contract. The separate\n        # class-gate suite supplies full combined rows and raw class evidence.\n        def old_health(outcomes, files, selected):\n            return {\n                'promise-methods-async': runner.promise_preflight_healthy,\n                'promise-all': runner.promise_all_preflight_healthy,\n                'promise-race': runner.promise_race_preflight_healthy,\n                'promise-all-settled': runner.promise_all_settled_preflight_healthy,\n            }[selected](outcomes)\n\n        with tempfile.TemporaryDirectory() as temporary:\n            path = Path(temporary)",'Preserve genuine legacy gate evaluation for shared main fixtures without claiming old rows satisfy new class gate.')
edit(p,"                    return_value=preflight), patch.object(runner, 'run_case', side_effect=execute), contextlib.redirect_stdout(io.StringIO()):","                    return_value=preflight), patch.object(runner, 'promise_class_harness_preflight',\n                    return_value=preflight), patch.object(runner, 'promise_class_preflight_healthy',\n                    side_effect=old_health), patch.object(runner, 'run_case', side_effect=execute), contextlib.redirect_stdout(io.StringIO()):",'Route selected main through explicit old-scope wrapper and health mocks.')
for indent in ['                ','        ']:
 old=indent+"self.assertEqual(report['runner_policy'], self.oracle['new_policy'])\n"+indent+"self.assertEqual(report['runner_policy_sha256'], self.oracle['new_policy_sha256'])"
 new=indent+"self.assertEqual((report['runner_policy'], report['runner_policy_sha256']),\n"+indent+"                 class_admitted_policy(PROFILE, self.oracle['new_policy'], self.oracle['new_policy_sha256']))"
 edit(p,old,new,'Only expected current policy supported_features gains class; all other fields and old oracle seal retained.')

for name in ['test_test262_promise_all_profile.py','test_test262_promise_race_profile.py','test_test262_promise_all_settled_profile.py']:
 p=load(name)
 edit(p,"self.assertEqual(runner.PROFILE_FEATURES[PROFILE], set(self.oracle['features']))","self.assertEqual(runner.PROFILE_FEATURES[PROFILE], set(legacy.class_admitted_features(PROFILE, self.oracle['features'])))",'Current feature assertion gains class while explicit caller oracle features and four exclusions remain exact.')
 if name=='test_test262_promise_all_profile.py':
  for indent in ['            ','        ']:
   edit(p,indent+"self.assertEqual(report['runner_policy'], self.oracle['policy'])\n"+indent+"self.assertEqual(report['runner_policy_sha256'], self.oracle['policy_sha256'])",indent+"self.assertEqual((report['runner_policy'], report['runner_policy_sha256']),\n"+indent+"                 legacy.class_admitted_policy(PROFILE, self.oracle['policy'], self.oracle['policy_sha256']))",'Class-only expected current policy migration; explicit synthetic192/4 counts preserved.')
  edit(p,"(old['policy'], old['policy_sha256']))","legacy.class_admitted_policy(OLD_PROFILE, old['policy'], old['policy_sha256']))",'Keep all old methods identities/guards, explicitly admit class in current methods policy only.')
 else:
  edit(p,"(self.oracle['policy'], self.oracle['policy_sha256']))","legacy.class_admitted_policy(PROFILE, self.oracle['policy'], self.oracle['policy_sha256']))",'Class-only expected policy migration, preserving synthetic historical counts.',count=2)
  edit(p,"(old['policy'], old['policy_sha256']))","legacy.class_admitted_policy(profile, old['policy'], old['policy_sha256']))",'Only selected old Promise policy feature lists change; all identities and controls remain exact.')
  if name=='test_test262_promise_all_settled_profile.py':
   edit(p,"                         self.oracle['old_features'])","                         {k: legacy.class_admitted_features(k, v) for k, v in self.oracle['old_features'].items()})",'Overlay class only for selected profiles in old56 current feature comparison.')

for name in ['test_test262_aggregate_error_preservation.py','test_test262_promise_any_preservation.py','test_test262_with_resolvers_preservation.py','test_test262_promise_try_preservation.py']:
 p=load(name)
 edit(p,'import test262_conformance as runner\n','import test262_conformance as runner\nimport test_test262_promise_runner as legacy\n','Reuse independent historical expected-policy overlay; no extra test class imported.')
 held="self.old" if name=='test_test262_aggregate_error_preservation.py' else 'old'
 edit(p,", "+held+"['features'])",", {k: legacy.class_admitted_features(k, v) for k, v in "+held+"['features'].items()})",'Retain every historical profile entry; only seven selected feature lists may gain class.')
 edit(p,"                                 (expected['policy'], expected['sha256']), profile)","                                 legacy.class_admitted_policy(profile, expected['policy'], expected['sha256']), profile)",'Check actual main policy against independently overlaid frozen expected policy, not production-derived expectations.')
 old="                    stack.enter_context(patch.object(runner, 'harness_preflight', return_value=[]))"
 new=old+"\n                    # Empty-inventory policy fixture; class raw evidence is tested separately.\n                    stack.enter_context(patch.object(runner, 'promise_class_harness_preflight', return_value=[]))\n                    stack.enter_context(patch.object(runner, 'promise_class_preflight_healthy', return_value=True))"
 edit(p,old,new,'Preserve empty-case policy-only scope and no-adapter assertion under new selected main entry points.')

for name,attrs in [
 ('test_test262_promise_any_protocol.py',['runner.PROFILE_FEATURES[PROFILE]']),
 ('test_test262_with_resolvers_protocol.py',['runner.PROMISE_WITH_RESOLVERS_FEATURES','runner.PROFILE_FEATURES[PROFILE]']),
 ('test_test262_promise_try_protocol.py',['runner.PROMISE_TRY_FEATURES','runner.PROFILE_FEATURES[PROFILE]'])]:
 p=load(name)
 for attr in attrs:edit(p,'self.assertEqual('+attr+', FEATURES)','self.assertEqual('+attr+", FEATURES | {'class'})",'Change only current profile expectation; local FEATURES stays frozen and caller class refusals remain exact.')

p=load('test_test262_promise_try_loader.py')
edit(p,"self.assertEqual(runner.PROFILE_FEATURES[PROFILE], {'Reflect.construct', 'promise-try'})","self.assertEqual(runner.PROFILE_FEATURES[PROFILE], {'Reflect.construct', 'promise-try', 'class'})",'Current selected profile adds class; all30 identities/eight async/six class metadata modes unchanged.')
p=load('test_test262_with_resolvers_controls.py')
edit(p,"self.assertEqual(runner.PROMISE_WITH_RESOLVERS_FEATURES, {'promise-with-resolvers'})","self.assertEqual(runner.PROMISE_WITH_RESOLVERS_FEATURES, {'promise-with-resolvers', 'class'})",'Current feature set only; all44 legacy control records stay exact.')
edit(p,"(binary, 3.0, {'promise-with-resolvers'}, PROFILE)","(binary, 3.0, {'promise-with-resolvers', 'class'}, PROFILE)",'Main passes newly admitted selected feature set to the synthetic dispatcher.')
for indent,rows in [('                            ','preflight'),('                ','self.good')]:
 old=indent+"stack.enter_context(patch.object(runner, 'harness_preflight', return_value="+rows+"))"
 new=old+'\n'+indent+"# Preserve this fixture's legacy44 gate scope; new class evidence has independent tests.\n"+indent+"stack.enter_context(patch.object(runner, 'promise_class_harness_preflight', return_value="+rows+"))\n"+indent+"stack.enter_context(patch.object(runner, 'promise_class_preflight_healthy',\n"+indent+"    side_effect=lambda outcomes, files, profile: runner.with_resolvers_preflight_healthy(outcomes, files)))"
 edit(p,old,new,'Use original withResolvers canonical health on the same held44 raw rows; no unconditional acceptance of bad old evidence.')

for name,rows,health in [
 ('test_test262_promise_any_controls.py','outcomes','promise_any_preflight_healthy'),
 ('test_test262_promise_try_controls.py','outcomes','promise_try_preflight_healthy')]:
 p=load(name)
 line=next(line for line in after[p].splitlines() if "patch.object(runner, 'harness_preflight', return_value=outcomes)" in line)
 indent=line[:len(line)-len(line.lstrip())]
 new=line+'\n'+indent+"patch.object(runner, 'promise_class_harness_preflight', return_value=outcomes), \\\n"+indent+"patch.object(runner, 'promise_class_preflight_healthy',\n"+indent+"             side_effect=lambda rows, files, profile: runner."+health+"(rows, files)), \\"
 edit(p,line,new,'Route selected main to held old raw evidence and original canonical gate; preserve poisoned-evidence refusal/no-dispatch/baseline tests.')

assert len(before)==15
files=[];changed_methods=[];unchanged_methods=[]
for path in before:
 a=before[path];b=after[path]
 # Exact inverse proves this hold adds no other bytes.
 inverse=b
 for e in reversed([e for e in edits if e['path']==path]):
  assert inverse.count(e['after'])==e['count'],(path,'inverse',e['after'][:80])
  inverse=inverse.replace(e['after'],e['before'])
 assert inverse==a
 at=ast.parse(a);bt=ast.parse(b)
 def methods(text,tree):
  return {c.name+'.'+n.name:ast.get_source_segment(text,n) for c in tree.body if isinstance(c,ast.ClassDef) for n in c.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
 am=methods(a,at);bm=methods(b,bt);assert am.keys()==bm.keys()
 for name in am:
  row=dict(path=path,name=name,before_sha256=sha(am[name].encode()),after_sha256=sha(bm[name].encode()))
  (unchanged_methods if am[name]==bm[name] else changed_methods).append(row)
 for folder,text in [('before',a),('raw',b)]:
  p=O/folder/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 diff=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/'+path,tofile='b/'+path))
 dp=O/'diffs'/(path.replace('/','__')+'.diff');dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(diff)
 files.append(dict(path=path,before=bind(O/'before'/path),raw=bind(O/'raw'/path),diff=bind(dp),retained_groups=len(am),inverse=True))
dump(O/'edits.json',dict(base=BASE,edits=edits))
dump(O/'source-checks.json',dict(base=BASE,files=files,changed_test_methods=changed_methods,unchanged_test_methods=unchanged_methods,retained_test_groups=len(changed_methods)+len(unchanged_methods),renames=[],added_groups=[],deleted_groups=[],scope='Only15 existing Python test files; no project execution or live edits.',mock_contract='Nine main fixture definitions route held old rows through new wrapper mocks; legacy health evaluation is preserved, except existing empty-inventory policy fixtures explicitly mock healthy. New class gate tested independently.'))
print(json.dumps(dict(paths=len(files),edit_entries=len(edits),retained_groups=len(changed_methods)+len(unchanged_methods),changed_group_bodies=len(changed_methods),unchanged_group_bodies=len(unchanged_methods)),indent=2))
