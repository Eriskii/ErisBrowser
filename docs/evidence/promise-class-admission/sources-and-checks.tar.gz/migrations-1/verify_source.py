"""Inert source checks only; no candidate or repository module execution."""
import ast,collections,hashlib,json
from pathlib import Path
H=Path('/tmp/eris-promise-class-admission-plan-1');O=H/'migrations-1';W=H/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
checks=json.loads((O/'source-checks.json').read_text())
before_roster=json.loads((H/'migration-plan-1/python-roster.json').read_text())
plan=json.loads((H/'migration-plan-1/migration-plan.json').read_text())
contexts=json.loads((H/'migration-plan-1/reviewed-contexts.json').read_text())
selected={x['profile'] for x in json.loads((H/'migration-plan-1/policies.json').read_text())['profiles'] if x['changed']}
records=[]
for row in checks['files']:
 path=row['path'];a=(O/'before'/path).read_text();b=(O/'raw'/path).read_text();at=ast.parse(a);bt=ast.parse(b)
 def assigns(t):
  return {target.id:ast.dump(n.value,include_attributes=False) for n in t.body if isinstance(n,ast.Assign) for target in n.targets if isinstance(target,ast.Name)}
 aa=assigns(at);ba=assigns(bt)
 assert all(ba[k]==v for k,v in aa.items()),path
 extra=set(ba)-set(aa)
 assert extra==({'CLASS_ADMISSION_PROFILES'} if path.endswith('/test_test262_promise_runner.py') else set())
 if extra:
  n=next(n for n in bt.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='CLASS_ADMISSION_PROFILES' for t in n.targets))
  assert ast.literal_eval(n.value)==selected
 def calls(t):
  return collections.Counter(ast.dump(n,include_attributes=False) for n in ast.walk(t) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr in {'unsupported_reason','run_case'})
 old_calls,new_calls=calls(at),calls(bt)
 added_calls=new_calls-old_calls
 assert not old_calls-new_calls,path
 if path.endswith('/test_test262_promise_runner.py'):
  expected=ast.dump(ast.parse('runner.unsupported_reason(case, runner.PROFILE_FEATURES[PROFILE], PROFILE)',mode='eval').body,include_attributes=False)
  assert added_calls==collections.Counter({expected:1}),path
 else:assert not added_calls,path
 def old_helpers(t,s):return {n.name:ast.get_source_segment(s,n) for n in t.body if isinstance(n,ast.FunctionDef)}
 ah=old_helpers(at,a);bh=old_helpers(bt,b)
 assert all(bh[k]==v for k,v in ah.items()),path
 def js_literals(t):
  return collections.Counter(n.value for n in ast.walk(t) if isinstance(n,ast.Constant) and isinstance(n.value,(str,bytes)) and any(x in (n.value.decode(errors='replace') if isinstance(n.value,bytes) else n.value) for x in ['/*---','function ', 'throw ', 'class ', ';']))
 assert js_literals(at)==js_literals(bt),path
 records.append(dict(path=path,old_module_assignments=len(aa),old_top_helpers=len(ah),retained_run_case_and_unsupported_call_sites=sum(old_calls.values()),added_current_profile_class_eligibility_assertion=sum(added_calls.values()),existing_javascript_literal_multiset_exact=True))
fixture_checks=[]
for row in contexts['main_fixtures']:
 path=row['path'];s=(O/'raw'/path).read_text();nodes=[n for n in ast.walk(ast.parse(s)) if isinstance(n,ast.FunctionDef) and n.name==row['function']];assert len(nodes)==1
 n=nodes[0];text=ast.get_source_segment(s,n)
 assert "'promise_class_harness_preflight'" in text and "'promise_class_preflight_healthy'" in text
 fixture_checks.append(dict(path=path,function=n.name,source_sha256=sha(text.encode()),scope='Old gate/raw/reporting scope retained by explicit selected-main mocks.'))
assert len(fixture_checks)==9
retained_ids=[]
for mod in before_roster['modules']:
 if not mod['top_level_discovery']:continue
 path=mod['path'];p=(O/'raw'/path) if (O/'raw'/path).exists() else W/path
 s=p.read_text();t=ast.parse(s)
 for c in t.body:
  if isinstance(c,ast.ClassDef):
   for n in c.body:
    if isinstance(n,ast.FunctionDef) and n.name.startswith('test_'):retained_ids.append(Path(path).stem+'.'+c.name+'.'+n.name)
assert len(retained_ids)==683 and set(retained_ids)==set(before_roster['retained_actual_ids'])
oracle_bindings=[]
for item in json.loads((H/'migration-plan-1/historical-oracles.json').read_text())['oracles']:
 p=W/item['path'];assert sha(p.read_bytes())==item['sha256'];oracle_bindings.append(bind(p))
report=dict(status='source-clear; candidate tests not executed',base=checks['base'],paths=15,edit_entries=46,retained_groups_in_payload=116,changed_test_bodies=28,unchanged_test_bodies=88,complete_retained_top_level_groups=683,no_group_renames_additions_deletions=True,
 exact_scope={'feature_policy_migration_paths':13,'additional_main_mock_paths':2,'main_fixtures':9,'explicit_caller_methods_kept':18},files=records,main_fixture_checks=fixture_checks,oracle_bindings=oracle_bindings,
 policy_expected_source='Two new test-only helpers derive class-only expected copies from frozen historical oracles and the literal seven-profile set. Old hashes are asserted before overlay; unselected profiles return the original policy/hash. No current production constant or report is used as the expected policy.',
 mock_qualification='The new class gate is intentionally mocked in historical main fixtures. Shared four-profile and Any/Try/withResolvers mocks delegate to unchanged genuine legacy health predicates. Four empty-case policy-only fixtures mock healthy, as their old health fixtures already did. These are not new class gate coverage; separately frozen independent tests own it.',
 unchanged=['Every original module assignment including all caller FEATURES and ORACLE_SHA values','Every original top-level test helper body','All existing explicit unsupported_reason and run_case call ASTs; one additional current-profile class eligibility assertion is recorded separately','All existing JavaScript literal values','All historical JSON oracle bytes and baseline files'],
 inert_check_qualification='The first source-check attempt rejected an additional current-profile unsupported_reason call introduced by the selected class eligibility assertion. The checker was narrowed to allow exactly that added call; payload bytes and expectations did not change.',
 execution='Only AST/stdlib/hash/Git-source analysis; no project imports, tests, adapters, builds, network or live writes.')
(O/'review-report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','paths','retained_groups_in_payload','complete_retained_top_level_groups','exact_scope']},indent=2))
