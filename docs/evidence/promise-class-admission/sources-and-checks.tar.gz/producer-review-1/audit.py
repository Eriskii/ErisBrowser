"""Independent inert source review: no project imports or producer execution."""
import ast,copy,difflib,hashlib,json,subprocess
from pathlib import Path
H=Path('/tmp/eris-promise-class-admission-plan-1');O=H/'producer-review-1';P=H/'producer-1';C=H/'control-contract-1'
BASE='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def dump(name,value):(O/name).write_text(json.dumps(value,indent=2)+'\n')
for directory in [P,C,H/'gate-design-1']:
 seal=json.loads((directory/'source-ready.json').read_text())
 for f in seal['files']:assert bind(Path(f['path']))==f
a=(P/'before/tools/test262_conformance.py').read_text();b=(P/'raw/tools/test262_conformance.py').read_text()
assert a.encode()==subprocess.check_output(['git','-C',str(H/'worktree'),'show',BASE+':tools/test262_conformance.py'])
forward=a
chunks=json.loads((P/'chunks.json').read_text())
for chunk in chunks:
 assert forward.count(chunk['before'])==1,chunk['name']
 forward=forward.replace(chunk['before'],chunk['after'])
assert forward==b
inverse=b
for chunk in reversed(chunks):
 assert inverse.count(chunk['after'])==1,chunk['name']
 inverse=inverse.replace(chunk['after'],chunk['before'])
assert inverse==a
diff=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile='a/tools/test262_conformance.py',tofile='b/tools/test262_conformance.py'))
assert diff==(P/'diffs/tools/test262_conformance.py.diff').read_text()
at=ast.parse(a);bt=ast.parse(b)
af={n.name:ast.get_source_segment(a,n) for n in at.body if isinstance(n,ast.FunctionDef)}
bf={n.name:ast.get_source_segment(b,n) for n in bt.body if isinstance(n,ast.FunctionDef)}
assert len(af)==74 and [name for name in af if af[name]!=bf[name]]==['main']
assert set(bf)-set(af)=={'promise_class_preflight_variants','promise_class_preflight_cases','promise_class_preflight_reference','promise_class_preflight_checks','promise_class_preflight_healthy','promise_class_harness_preflight'}
constants={}
for n in bt.body:
 if isinstance(n,ast.Assign):
  for target in n.targets:
   if isinstance(target,ast.Name) and target.id.startswith('PROMISE_CLASS_'):constants[target.id]=ast.literal_eval(n.value)
variants=json.loads((C/'variants.json').read_text());cases=json.loads((C/'cases.json').read_text());prefix=json.loads((C/'old-prefix-identities.json').read_text())
assert constants['PROMISE_CLASS_LITERALS']=={(r['family'],r['variant']):r['source'] for r in variants}
pins=json.loads((H/'gate-design-1/helper-pins.json').read_text())['profiles']
for profile,files in pins.items():
 assert constants['PROMISE_CLASS_HELPERS'][profile]==tuple(x['path'].removeprefix('harness/') for x in files)
 for row in files:
  name=row['path'].removeprefix('harness/')
  assert constants['PROMISE_CLASS_HELPER_PINS'][name]==(row['bytes'],row['sha256'])
old={p['profile']:p['ordered_rows'] for p in prefix}
assert constants['PROMISE_CLASS_COUNTS']=={p['profile']:p['count'] for p in prefix}
identity={}
for profile,rows in old.items():
 for r in rows:identity[(profile,r['name'],r['mode'])]={k:r[k] for k in ['name','mode','id','case_sha256','source_sha256','expected']}
for r in cases:identity[(r['profile'],r['name'],r['mode'])]={k:r[k] for k in ['name','mode','id','case_sha256','source_sha256','expected']}
new_rows=[]
for profile in constants['PROMISE_CLASS_COUNTS']:
 ordinary=profile=='promise-with-resolvers'
 for mode in ['sloppy','strict']:
  for family in ['construction','species','subclass']:
   for variant in ['positive','mismatch']:
    # Independently derive the frozen contract fields from the selected branch table.
    policy=1 if family=='subclass' and not ordinary else 0
    mismatch=variant=='mismatch'
    name='class-'+profile+'-'+family+'-'+variant
    literal=profile if family=='subclass' else family
    source=constants['PROMISE_CLASS_LITERALS'][(literal,variant)]
    metadata=dict(flags=['async'] if policy else [],includes=[],features=['class'],locale=[],negative=None)
    helpers=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])
    harness=[dict(name=k,sha256=constants['PROMISE_CLASS_HELPER_PINS'][k][1]) for k in helpers]
    payload=dict(source_sha256=sha(source.encode()),mode=mode,metadata=metadata,harness=harness)
    if not ordinary:payload['completion_policy']=policy
    case_sha=sha(json.dumps(payload,sort_keys=True,ensure_ascii=True).encode())
    expected='passed' if not mismatch else ('failed' if ordinary else 'completion-error' if policy else 'synchronous-exception')
    refs=(['strict-success' if mode=='strict' else 'success','with-resolvers-genuine'] if ordinary else ['promise-methods-promise-api-positive'])
    if policy:refs+=['promise-methods-one-async-completion']
    if family in ['species','subclass']:refs+=['class-'+profile+'-construction-positive']
    if family=='subclass':refs+=['class-'+profile+'-species-positive']
    if mismatch:refs+=['class-'+profile+'-'+family+'-positive']
    observed=dict(status='complete',phase='runtime',error_type='',error_identity='',message='',harness='')
    rule=dict(kind='exact',value='')
    if mismatch:
     if policy:observed.update(status='host-failure',phase='host',message='completion-error');rule['value']='completion-error'
     else:
      observed.update(status='exception',error_type='Test262Error');del observed['message']
      rule=dict(kind='bounded-diagnostic',type='str',max_utf8_bytes=16384,qualification='Helper assertion wording is not an oracle; all other raw fields are exact.')
    if not ordinary:observed['completion']=dict(policy=policy,done_calls=policy,success_prints=1 if policy and not mismatch else 0,failure_prints=1 if policy and mismatch else 0,flags=1 if policy and mismatch else 256 if mismatch else 0,quiescent=True,audited=True,unhandled=0)
    row=dict(profile=profile,name=name,mode=mode,id='harness-preflight:'+name,file='<preflight>',source=source,source_sha256=payload['source_sha256'],metadata=metadata,harness=harness,case_sha256=case_sha,expected=expected,expected_status='passed' if not mismatch else 'failed',expected_negative=None,required_observation=observed,message_rule=rule,prerequisites=[identity[(profile,k,mode)] for k in refs])
    if not ordinary:row['completion_policy']=policy
    frozen=cases[len(new_rows)]
    assert all(frozen[k]==v for k,v in row.items()),(name,mode)
    assert ('completion_policy' in frozen)==(not ordinary)
    new_rows.append(row)
assert len(new_rows)==84 and sum(len(r['prerequisites']) for r in new_rows)==246
cross=[]
for profile,rows in old.items():
 for index,row in enumerate(rows):
  for edge in row['prerequisites']:
   if edge['mode']!=row['mode']:cross.append(dict(profile=profile,index=index,row=row['name'],mode=row['mode'],target=edge['name'],target_mode=edge['mode']))
assert len(cross)==192 and {r['profile'] for r in cross}=={'promise-with-resolvers'}
assert len({(r['row'],r['mode']) for r in cross})==12
line=next(i for i,x in enumerate(b.splitlines(),1) if "edge[1] != key[1]" in x)
dump('graph-finding.json',dict(status='blocking source finding in frozen producer-1',file='tools/test262_conformance.py',line=line,condition="edge[1] != key[1] for edge in required",legacy_cross_mode_edges=cross,affected_rows=12,description='Canonical old withResolvers semantic rows intentionally depend on all common32 controls across both modes. The unconditional same-mode rule therefore returns None for every combined ordinary control set, regardless of genuine raw outcomes.',recommendation='Preserve all canonical legacy edges. Restrict added same-mode rule to the 12 new class rows; still validate exact old edge identities/order, missing targets, duplicate edges and cycles. No control source/metadata/oracle/fee/runtime change.',execution='Derived from frozen literals, retained ordered references and source condition only; no producer invocation.'))
dump('source-checks.json',dict(base=BASE,producer=bind(P/'source-ready.json'),controls=bind(C/'source-ready.json'),gate_design=bind(H/'gate-design-1/source-ready.json'),parent_git_join=True,full_forward_inverse_and_diff=True,preserved_old_functions=73,changed_old_function='main only two routing seams',new_functions=sorted(set(bf)-set(af)),exact_literals=18,new_expansion_rows=84,new_references=246,new_case_fingerprints_equal=True,helper_pins_and_closure_equal=True,old_controls=588,canonical_legacy_cross_mode_edges=192,finding=bind(O/'graph-finding.json')))
print(json.dumps(dict(old_functions_preserved=73,literals=18,new_rows=84,new_edges=246,old_cross_mode_edges=192,finding_line=line),indent=2))
