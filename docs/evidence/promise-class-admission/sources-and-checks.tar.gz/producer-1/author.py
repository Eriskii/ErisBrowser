from pathlib import Path
import ast,difflib,hashlib,json,pprint,subprocess
H=Path('/tmp/eris-promise-class-admission-plan-1');O=H/'producer-1';W=H/'worktree';C=H/'control-contract-1';B='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
control=json.loads((C/'source-ready.json').read_bytes());assert bind(C/'source-ready.json')['sha256']=='79bd0708684c0b0b3b15028f72450e1aac4c37a072366eaa34d85fbae91a8328'
for r in control['files']:assert bind(Path(r['path']))==r
source_path='tools/test262_conformance.py';before=subprocess.check_output(['git','show',B+':'+source_path],cwd=W).decode();assert before==(W/source_path).read_text()
variants=json.loads((C/'variants.json').read_bytes());cases=json.loads((C/'cases.json').read_bytes());pins=json.loads((H/'gate-design-1/helper-pins.json').read_bytes())['profiles'];old=json.loads((C/'old-prefix-identities.json').read_bytes());profiles=[r['profile'] for r in old]
counts={r['profile']:r['count'] for r in old};helper_names={k:tuple(r['path'][8:] for r in v) for k,v in pins.items()};helper_pins={}
for values in pins.values():
 for r in values:
  value=(r['bytes'],r['sha256']);name=r['path'][8:];assert name not in helper_pins or helper_pins[name]==value;helper_pins[name]=value
constants='# Profile-scoped class admission; existing preflight bodies remain unchanged.\n'
for name,value in [('PROMISE_CLASS_COUNTS',counts),('PROMISE_CLASS_HELPERS',helper_names),('PROMISE_CLASS_HELPER_PINS',helper_pins)]:constants+=name+' = '+pprint.pformat(value,width=100,sort_dicts=False)+'\n'
constants+='PROMISE_CLASS_LITERALS = {\n'
for r in variants:
 text=r['source'];assert '"""' not in text and not '\\' in text;assert sha(text.encode())==r['source_sha256']
 constants+='    '+repr((r['family'],r['variant']))+': """'+text+'""",\n'
constants+='}\n\n\n'
addition=constants+(O/'gate-body.txt').read_text();ast.parse(addition)
chunks=[];after=before
def change(name,a,b):
 global after
 assert after.count(a)==1,(name,after.count(a));after=after.replace(a,b,1);chunks.append({'name':name,'before':a,'after':b})
tree=ast.parse(before)
for name in ['PROMISE_FEATURES','PROMISE_ANY_FEATURES','PROMISE_WITH_RESOLVERS_FEATURES','PROMISE_TRY_FEATURES']:
 n=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));a=ast.get_source_segment(before,n);assert a.endswith('}');change('feature-'+name,a,a[:-1]+", 'class'}")
change('new-class-gate','def check_baseline(previous, current):',addition+'def check_baseline(previous, current):')
change('main-preflight-wrapper','        preflight = harness_preflight(files, binary, args.timeout, args.profile)',"        preflight = (promise_class_harness_preflight(files, binary, args.timeout, args.profile)\n                     if args.profile in PROMISE_CLASS_COUNTS\n                     else harness_preflight(files, binary, args.timeout, args.profile))")
change('main-preflight-health','        preflight_ok = (promise_try_preflight_healthy(preflight, files) if args.profile == PROMISE_TRY_PROFILE',"        preflight_ok = (promise_class_preflight_healthy(preflight, files, args.profile)\n                        if args.profile in PROMISE_CLASS_COUNTS\n                        else promise_try_preflight_healthy(preflight, files) if args.profile == PROMISE_TRY_PROFILE")
newtree=ast.parse(after);inverse=after
for c in reversed(chunks):assert inverse.count(c['after'])==1;inverse=inverse.replace(c['after'],c['before'],1)
assert inverse==before
original={n.name:ast.get_source_segment(before,n) for n in tree.body if isinstance(n,ast.FunctionDef)};current={n.name:ast.get_source_segment(after,n) for n in newtree.body if isinstance(n,ast.FunctionDef)};assert len(original)==74 and all(original[n]==current[n] for n in original if n!='main')
new_names=[n for n in current if n not in original];assert len(new_names)==6
# Inert literal extraction, independent expectation expansion and hash arithmetic.
newassigns={n.targets[0].id:n.value for n in newtree.body if isinstance(n,ast.Assign) and len(n.targets)==1 and isinstance(n.targets[0],ast.Name)}
assert ast.literal_eval(newassigns['PROMISE_CLASS_LITERALS'])=={(r['family'],r['variant']):r['source'] for r in variants}
assert ast.literal_eval(newassigns['PROMISE_CLASS_COUNTS'])==counts
expanded=[]
for profile in profiles:
 ordinary=profile=='promise-with-resolvers';known={(r['name'],r['mode']):r for r in next(v['ordered_rows'] for v in old if v['profile']==profile)}
 for mode in ['sloppy','strict']:
  for family in ['construction','species','subclass']:
   for variant in ['positive','mismatch']:
    mismatch=variant=='mismatch';policy=int(family=='subclass' and not ordinary);name=f'class-{profile}-{family}-{variant}';literal=profile if family=='subclass' else family
    src=next(v['source'] for v in variants if v['family']==literal and v['variant']==variant);metadata={'flags':['async'] if policy else [],'includes':[],'features':['class'],'locale':[],'negative':None};harness=[{'name':n,'sha256':helper_pins[n][1]} for n in ['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])]
    identity={'source_sha256':sha(src.encode()),'mode':mode,'metadata':metadata,'harness':harness}
    if not ordinary:identity['completion_policy']=policy
    fingerprint=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode());status='passed' if not mismatch else 'failed';expected='passed' if not mismatch else 'failed' if ordinary else 'completion-error' if policy else 'synchronous-exception'
    required=(['strict-success' if mode=='strict' else 'success','with-resolvers-genuine'] if ordinary else ['promise-methods-promise-api-positive'])
    if policy:required.append('promise-methods-one-async-completion')
    if family!='construction':required.append(f'class-{profile}-construction-positive')
    if family=='subclass':required.append(f'class-{profile}-species-positive')
    if mismatch:required.append(f'class-{profile}-{family}-positive')
    refs=[{k:known[(ref,mode)][k] for k in ['name','mode','id','case_sha256','source_sha256','expected']} for ref in required]
    required_raw={'status':'complete','phase':'runtime','error_type':'','error_identity':'','message':'','harness':''};rule={'kind':'exact','value':''}
    if mismatch and policy:required_raw.update(status='host-failure',phase='host',message='completion-error');rule['value']='completion-error'
    elif mismatch:required_raw.update(status='exception',error_type='Test262Error');del required_raw['message'];rule={'kind':'bounded-diagnostic','type':'str','max_utf8_bytes':16384,'qualification':'Helper assertion wording is not an oracle; all other raw fields are exact.'}
    if not ordinary:required_raw['completion']={'policy':policy,'done_calls':policy,'success_prints':int(policy and not mismatch),'failure_prints':int(policy and mismatch),'flags':(1 if policy else 256) if mismatch else 0,'quiescent':True,'audited':True,'unhandled':0}
    row={'profile':profile,'name':name,'mode':mode,'id':'harness-preflight:'+name,'file':'<preflight>','source':src,'source_sha256':sha(src.encode()),'metadata':metadata,'harness':harness,'case_sha256':fingerprint,'expected':expected,'expected_status':status,'expected_negative':None,'required_observation':required_raw,'message_rule':rule,'prerequisites':refs}
    if not ordinary:row['completion_policy']=policy
    frozen=cases[len(expanded)];assert all(row[k]==frozen[k] for k in row),(profile,mode,family,variant)
    assert ('completion_policy' in row)==('completion_policy' in frozen)
    expanded.append(row);known[(name,mode)]=row
assert len(expanded)==84 and sum(len(r['prerequisites']) for r in expanded)==246
for name in ['PROMISE_FEATURES','PROMISE_ANY_FEATURES','PROMISE_WITH_RESOLVERS_FEATURES','PROMISE_TRY_FEATURES']:
 oldn=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets));assert ast.literal_eval(newassigns[name])==ast.literal_eval(oldn.value)|{'class'}
for sub in ['before/tools','raw/tools','diffs/tools']:(O/sub).mkdir(parents=True,exist_ok=True)
(O/'before'/source_path).write_text(before);(O/'raw'/source_path).write_text(after)
(O/'diffs'/ (source_path+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+source_path,tofile='b/'+source_path)))
write('chunks.json',chunks)
write('checks.json',{'status':'source-derived checks passed; no project execution','base':B,'full_inverse_exact':True,'old_top_level_functions':74,'preserved_old_bodies':73,'changed_old_body':'main (two selection seams only)','new_functions':new_names,'changed_feature_declarations':4,'selected_feature_delta':'class only; existing unions/copies propagate to seven profiles','literal_dictionary':{'entries':18,'all_bytes_equal_independent_variants':True},'independent_expansion':{'rows':84,'references':246,'all_projected_fields_equal_frozen_cases':True,'method':'AST literal extraction plus stdlib source-independent expansion equations; no new or existing project function invoked'},'all_helper_pins_equal_design':True,'schemas':'Canonical type/key/order identity check, bounded UTF8 fields, old reference shapes, immutable new six-field refs, complete new raw observation contracts and existing legacy validators retained.','graph':'Fixed-size iterative topology before outcome parsing; missing/cross-mode/duplicate/self/cyclic canonical edges fail closed.','production_not_executed':True})
write('interfaces.json',{'functions':[{ 'name':n,'arguments':[a.arg for a in next(x for x in newtree.body if isinstance(x,ast.FunctionDef) and x.name==n).args.args]} for n in new_names],'case_rows':'uniform prerequisites:list[(name,mode)] for old and new canonical definitions','checks':'None malformed inputs; otherwise recomputed {(name,mode): bool}','healthy':'canonical checks + all observed verifiedTrue + preserved old prefix gate','wrapper':'old prefix unchanged plus new12;[] malformed preparation','main':'only preflight wrapper/health selection; existing all-case block and baseline predicates exact'})
write('input-bindings.json',{'base':B,'parent':bind(O/'before'/source_path),'controls':bind(C/'source-ready.json'),'cases':bind(C/'cases.json'),'variants':bind(C/'variants.json'),'old_prefix':bind(C/'old-prefix-identities.json'),'design':bind(H/'gate-design-1/source-ready.json'),'helper_pins':bind(H/'gate-design-1/helper-pins.json')})
write('source-ready.json',{'status':'source-ready held producer; unexecuted','base':B,'scope':'One runner file; class-only four feature declarations, six new functions/constants and two main seams. No Rust/corpus/importer/host/policy format changes.','files':[bind(O/n) for n in ['author.py','gate-body.txt','before/'+source_path,'raw/'+source_path,'diffs/'+source_path+'.diff','chunks.json','checks.json','interfaces.json','input-bindings.json']],'controls':bind(C/'source-ready.json'),'project_execution':False,'live_edits':False})
print(json.dumps(bind(O/'source-ready.json')))
