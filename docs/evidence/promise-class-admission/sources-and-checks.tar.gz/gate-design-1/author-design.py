from pathlib import Path
import ast,hashlib,json,subprocess
H=Path('/tmp/eris-promise-class-admission-plan-1');W=H/'worktree';O=H/'gate-design-1';B='315300e6324fd4232fa53cb8d6a5b46a2c906dc5'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(n,x):
 (O/n).write_text(json.dumps(x,indent=2)+'\n')
runner=W/'tools/test262_conformance.py';raw=runner.read_bytes();assert raw==subprocess.check_output(['git','show',B+':tools/test262_conformance.py'],cwd=W)
s=raw.decode();tree=ast.parse(s);funcs=[]
for node in tree.body:
 if isinstance(node,ast.FunctionDef):
  body=ast.get_source_segment(s,node).encode();funcs.append({'name':node.name,'line':node.lineno,'end_line':node.end_lineno,'bytes':len(body),'sha256':sha(body),'preserve_body_exact':node.name!='main'})
profiles=['promise-methods-async','promise-all','promise-race','promise-all-settled','promise-any','promise-with-resolvers','promise-try'];counts=[74,90,90,94,102,44,94];helpers={};corpora=[]
for profile,count in zip(profiles,counts,strict=True):
 root=W/'tests/upstream'/('test262-'+profile);m=json.loads((root/'manifest.json').read_bytes());rows=[]
 for row in m['files']:
  if row['path'].startswith('harness/'):
   p=root/row['path'];b=p.read_bytes();assert sha(b)==row['sha256'] and len(b)==row['bytes'];assert b==subprocess.check_output(['git','show',B+':'+str(p.relative_to(W))],cwd=W)
   rows.append({'path':row['path'],'bytes':len(b),'sha256':sha(b)})
 helpers[profile]=rows;corpora.append({'profile':profile,'old_control_rows':count,'manifest':bind(root/'manifest.json'),'helper_count':len(rows)})
write('source-bindings.json',{'base':B,'runner':bind(runner),'prior_readiness':bind(Path('/tmp/eris-promise-class-admission-readiness-1/source-ready.json')),'prior_design':bind(Path('/tmp/eris-promise-class-admission-readiness-1/readiness.json')),'root_provisional_selection':bind(H/'root/selection-provisional.json'),'corpora':corpora,'method':'Read-only Git and stdlib AST/hash extraction; no project imports/execution or network.'})
write('helper-pins.json',{'purpose':'Proposed exact published helper byte pins for all seven selected profiles; case ordering still follows each unchanged producer or independently frozen new row. All retained corpus helper files are authenticated, even when a particular guard does not use one.','profiles':helpers})
write('preserved-functions.json',{'runner':bind(runner),'existing_functions':len(funcs),'preserved_function_bodies':73,'only_existing_function_with_selected_seams':'main','functions':funcs})
write('design.json',{
 'status':'source-design-ready; not implementation authorization',
 'base':B,'scope':'Profile-scoped class prerequisite gate for seven existing Promise profiles; design only. Independent class literal/raw control seal and root approval must precede producer authoring.',
 'profile_rows':[{'profile':p,'old_rows':n,'proposed_new_rows':12,'proposed_total':n+12} for p,n in zip(profiles,counts)],
 'counts':{'old_rows':588,'new_rows_proposed_by_independent_author':84,'selected_total_if_approved':672,'other_aggregate_error_rows_unchanged':52,'new_counts_status':'84 proposed by HTML; exact literals/metadata/raw expectations are not authored or selected here.'},
 'minimal_seams':[
  'Add only class to PROMISE_FEATURES, PROMISE_ANY_FEATURES, PROMISE_WITH_RESOLVERS_FEATURES and PROMISE_TRY_FEATURES. Existing derived copies/unions propagate to All/Race/AllSettled. All54 other profile maps and generic SUPPORTED_FEATURES stay exact.',
  'Append new definitions/builders/checks/wrapper after existing functions. All73 existing top-level functions other than main remain byte-exact, including harness_preflight, old health predicates, decoders, classifiers, case_fingerprint and check_baseline.',
  'In main select promise_class_harness_preflight for the seven selected profiles, otherwise retain existing harness_preflight call. This wrapper calls the unchanged old producer exactly once via unchanged harness_preflight, preventing recursive routing.',
  'In main select promise_class_preflight_healthy for those seven profiles, otherwise retain the entire old health expression. Existing withResolvers/host blocking branches stay exact and consume combined gate health before ThreadPool/case dispatch.',
  'No change to baseline comparison or write predicates. Failed class gate makes healthy false and never writes/creates a baseline; all loaded cases become blocked before unsupported-feature or adapter dispatch. Existing --baseline policy mismatch may still abort report writing and must not be bypassed or rewritten.'
 ],
 'proposed_interfaces':[
  'promise_class_preflight_variants(profile) -> independently frozen new literal definitions only',
  'promise_class_preflight_cases(files, profile) -> complete ordered (row, case) list, old prefix then new suffix',
  'promise_class_preflight_reference(row, case) -> six-string reference for NEW class prerequisite edges',
  'promise_class_preflight_checks(outcomes, files, profile) -> None for invalid canonical/schema/helper/graph input, otherwise identity-to-recomputed-health dict',
  'promise_class_preflight_healthy(outcomes, files, profile) -> bool; requires all canonical checks, all reported verified flags True and preserved old prefix gate',
  'promise_class_harness_preflight(files, binary, timeout, profile) -> unmodified old producer prefix plus new rows in exact frozen order'
 ],
 'canonical_builder':{
  'helpers':'Before any producer call or case construction, require files mapping, each selected helper value of exact bytes type, and exact bytes/SHA256 from helper-pins.json. Missing/wrong-type/corrupt helpers fail closed, even if a caller also recomputes outcome fingerprints. Other corpus entries remain loader-owned; no helper/source additions or reordering.',
  'old_methods_all_race_settled':'Reconstruct canonical cases from unchanged literal functions using EXACT existing loop order, id prefix, metadata {flags,includes,features:[],locale:[],negative:None}, helper order and completion policy. Common74 first; method-specific suffix next. Copy prerequisite edge derivation exactly, including allSettled additional_prerequisites and the common original-literal helper guards.',
  'old_any_try_withResolvers':'Reuse existing *_preflight_cases(files) builders byte-exact. Do not synthesize different metadata or old refs.',
  'new_rows':'Read only independently frozen selected literal definitions. New metadata/includes/features/completion policy and ordered helper bytes are fixed by that hold. withResolvers has no completion_policy/async flag; six host profiles have exact integer0/1 policy agreeing with flags.',
  'fingerprints':'Compute source SHA256 from canonical UTF-8 literal bytes and case_fingerprint from canonical metadata/mode/ordered helper byte hashes/policy. Never use supplied outcome identities to construct expected cases.',
  'definition_checks':'Require unique canonical (name,mode), canonical id/file, exact expected counts/order and legal finite same-mode dependency lists. Reject duplicate edges, missing targets, self-links/cycles, cross-mode edges and malformed identity types before visiting outcomes.'
 },
 'schema':{
  'outer_exact':['name','expected','verified','result','prerequisites'],
  'outer_types':'Plain dict, name/expected str, verified exact bool, result plain dict, prerequisites list. outcomes is a list of exact canonical length/order. Validate strings before using any field in a tuple/set/dict lookup; nested list/dict identities must return unhealthy, never crash.',
  'result_exact':['id','file','mode','case_sha256','source_sha256','expected_negative','status','observation'],
  'result_types':'Identity/digest/status fields str; expected_negative exact canonical None or exact old ordinary negative dict with phase/type str. New class controls use None. No reason/stderr/completion_policy/extra fields. Every identity/status/negative field equals the reconstructed canonical value.',
  'new_reference_exact':['name','mode','id','case_sha256','source_sha256','expected'],
  'new_reference_types':'All six values str; exact ordered list equals canonical references. No verified field and no caller-chosen graph. Referenced row must independently be healthy.',
  'old_references':'Preserve original exact five-field host refs (name,mode,verified,case_sha256,source_sha256; verified exact bool) and six-field ordinary refs. Do not rewrite old rows. Healthy gate requires the old expected verified=True references, plus independently recomputed target health.',
  'host_observation_exact':['status','phase','error_type','error_identity','message','harness','completion'],
  'ordinary_observation_exact':['status','phase','error_type','error_identity','message','harness'],
  'text_bounds':'Exact str values and UTF-8 length<=16384; Unicode encoding failures reject. New semantic rows require empty harness. withResolvers refuses any completion field or host shape.',
  'completion_exact':['policy','done_calls','success_prints','failure_prints','flags','quiescent','audited','unhandled'],
  'completion_types':'Existing validator exact int/bool/ranges/invariants unchanged; bool never accepted as integer. New rows additionally require their complete independently frozen completion record, not merely permitted flag bits.'
 },
 'raw_validation':{
  'all_old_rows':'Every one of588 old prefix rows is canonically rechecked under its existing raw criteria, not just the few named new prerequisites. Old raw diagnostic-message allowances remain allowances; no claim that all old bytes are frozen beyond existing criteria. Common controls retain original identities/helper order/prerequisite order.',
  'old_host_four':'Run unchanged validate_promise_observation, classify_promise and promise_preflight_verified using canonical case/expected; exact canonical result fields and reference graph checked anew. Preserve original common/verifier semantics; do not merely trust existing verified flags.',
  'old_any_try_ordinary':'Use existing canonical *_preflight_checks and old health predicate unchanged on exact original prefix. Also enforce shared outer/result/reference type-and-identity schema. Any context alone retains AggregateError eighth identity.',
  'new_host':'Use unchanged validate_promise_observation (profile=Any only where selected), unchanged classify_promise/profile-aware classify and unchanged promise_preflight_verified where applicable. Require canonical expected status AND frozen raw field/completion contract. Exact messages or explicit bounded-message rules belong to independent control hold, not producer inference.',
  'new_ordinary':'Strict six-field ordinary raw dictionary with canonical required observation and recomputed classify result; no host completion marker or policy. Keep run_case ERJS1/ERJR2 and existing selected ordinary guard exact.',
  'claimed_status':'Recompute status and semantic control health from observation. A forged passed/failed status, verified flag, mismatched error identity, completion shape or harness attribution cannot establish health.',
  'positive_mismatch':'Each mismatch requires its exact same-mode positive; shared species positive requires shared construction positive; profile-specific positive also requires selected old positive assertion/API and host-done witnesses as frozen by HTML. Global health additionally requires every old row, so a dependency subset never permits an unhealthy old control.',
  'graph':'Build only from canonical definitions and exact reference equality. Use explicit tri-color traversal/stack bounded by fixed canonical row count; a gray-node encounter rejects. Never traverse caller-supplied arbitrary graphs. Propagate any raw/target failure through dependants.',
  'failure_contract':'All malformed input failures return None/False for the new checks/health API. Catch only anticipated KeyError/TypeError/ValueError/Unicode encoding failures after explicit bounded shape checks; avoid recursion-dependent failure and arbitrary hashability assumptions.'
 },
 'producer_flow':[
  'Validate helper pins and construct full canonical ordered definitions before calling adapters. If preparation is invalid, wrapper returns an unhealthy empty list, so selected main blocks all case identities and cannot record baseline.',
  'Call unchanged harness_preflight once for the selected profile; preserve returned old prefix rows and all their fields/ordering exactly. Do not edit old verified/prerequisite fields.',
  'Run only new canonical class cases with existing run_case and selected profile/features/protocol. Construct new outer records with verified=False and immutable six-field canonical references.',
  'Recompute combined checks; assign only new row verified values. Final health additionally requires all reported flags True and old prefix gate True. No invented success rows or repair of failing old records.',
  'Any failed/missing/forged class or legacy prerequisite keeps preflight_ok false before any inventory ThreadPool call. Report all inventory identities blocked, including class-independent exclusions; baseline record path remains untouched.'
 ],
 'preservation':{
  'functions':'All73 old functions except main preserved byte-exact; only two main selection seams proposed. Old default arities unchanged.',
  'host':'ERJS2/ERJR3, checked-sync/authenticated-done, fatal/queued/unhandled-final-audit behavior unchanged; no new swallowed rejection or source handler.',
  'ordinary':'withResolvers remains ERJS1/ERJR2 with no completion_policy; direct guard/decoder refusal untouched.',
  'identity':'Any retains its existing eighth AggregateError identity; every other selected profile remains seven. Diagnostics/class names do not grant intrinsic identity.',
  'corpus':'All643 originals/1280 modes, metadata, helpers, fingerprints and corpus hashes retained.40 class-only excluded modes newly eligible; no outcome selected. Existing untagged class changes belong to prior runtime, not this admission.',
  'other_profiles':'All54 unrelated maps/policies, AggregateError52 controls, generic default features, Rust, importer, host code, workflow commands and caps unchanged.',
  'baselines':'Only seven selected compact baselines may later be regenerated after actual healthy gates/full measured replay and root review. Existing policy hash comparison remains exact; no update before observation.'
 },
 'adversarial_matrix':[
  'Delete/add/duplicate/reorder old or new row; same name other mode; malformed/unhashable identity and nested fields; bool/int substitution and missing/extra raw/result keys.',
  'Wrong id/file/source/case digest/expected/negative; forged status/verified; changed helper bytes with and without recomputed fingerprint; missing/helper wrong type; helper order swap.',
  'Forged prerequisite target/hash/expected/id/mode, missing/extra/duplicate/reordered edge, failed positive with healthy mismatch, canonical-definition cycle/self-link; no RecursionError or hashability exception.',
  'Host missing completion, malformed counters/flags/quiescent/audited/unhandled, nonempty harness, forged error identity, complete observation with wrong classification; preserve old common accepted observations.',
  'Ordinary completion/policy insertion and ERJR3 rejection; verify no changes to old decode/classify/default arities.',
  'Fail one new control per profile with a healthy old prefix: zero inventory adapter calls; every inventory identity blocked; pre-existing baseline bytes unchanged and absent baseline remains absent. Healthy mocked control path proves all inventory modes dispatched with correct profile/protocol.',
  'For oldest four profiles forge an old raw observation while keeping old verified flags True: new gate rejects independently although preserved old predicate alone would accept.',
  'Exactold588 row equality and prefix order under mocked unchanged raw runs; all73 old body hashes and54 policy maps exact; exactly seven class feature deltas.'
 ],
 'unresolved_before_production':['HTML literal/metadata/raw contracts and exact84-row seal require root approval; this design does not authorize implementation.','Exact new prefix/name/API-prerequisite spellings and messages must be taken from that independent hold.','Root may select these proposed six API names or refine them additively before tests/producer.','Actual newly admitted40 mode outcomes and seven new compact baselines remain unmeasured.']
})
write('source-ready.json',{'status':'sealed-source-design','base':B,'files':[bind(O/n) for n in ['design.json','source-bindings.json','helper-pins.json','preserved-functions.json','author-design.py']],'production_authorized':False,'execution':'stdlib source/Git/hash/AST reads only; no project module imports, tests, adapter invocation or live edits. No G/F writes.'})
print(json.dumps(bind(O/'source-ready.json')))
