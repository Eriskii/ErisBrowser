"""Finalize a new documentation hold from retained measured receipts; no project execution."""
from pathlib import Path
from collections import Counter
import difflib,hashlib,json,re,subprocess
P=Path(__file__).resolve().parent;H=P.parent;D=H/'documentation-1';W=H/'worktree'
def bound(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(binding):
 assert bound(Path(binding['path']))==binding,binding
 return json.loads(Path(binding['path']).read_bytes())
def load(p):return json.loads(p.read_bytes())
def put(p,text):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(text)
def dump(p,data):put(p,json.dumps(data,indent=2)+'\n')
ledger_path=H/'root/final-validation.json';ledger=load(ledger_path)
assert bound(ledger_path)['sha256']=='a53c5cfc7348ec5fbfa9892a951e3ac18dae4ebea51c5f55fb5ccca59bb32965'
assert ledger['status']=='pass' and ledger['selected_inputs']==1840 and len(ledger['changed_source_test_baseline_paths'])==25
source=read(ledger['source_inventory']);assert len(source['source_sha256'])==1840
candidate=read(ledger['candidate_capture']);parent=read(ledger['parent_capture'])
assert candidate['counts']==dict(passed=1258,failed=64,unsupported=8)
assert candidate['transition_counts']==dict(case_record_changes=40,control_record_changes=0,prior_pass_regressions=0,newly_passed=36,nonpass_status_changes=4,raw_only_changes=0,outside_class_tag_changes=0)
assert ledger['python_counts']==dict(parent=683,final=696,new=13,first_candidate_passed=695,first_candidate_failed=1)
logs={}
for label,row in ledger['python'].items():
 receipt=read(row['receipt']);p=Path(row['log']['path']);assert bound(p)==row['log'];assert receipt['sha256']==row['log']['sha256'];logs[label]=p.read_text()
assert re.search(r'Ran 696 tests in [^\n]+\n\nOK\s*$',logs['candidate-python-2'])
assert re.search(r'Ran 696 tests in [^\n]+\n\nFAILED \(failures=1\)\s*$',logs['candidate-python-1'])
assert not re.search(r'\.\.\. skipped ',logs['candidate-python-2'])
# All complete measured arrays are read and joined, not just aggregate totals.
counts=Counter();tables=[];unhandled=[]
for cp,pp in zip(candidate['profiles'],parent['profiles']):
 cr=read(cp['report']);pr=read(pp['report'])
 assert cr['harness_preflight'][:len(pr['harness_preflight'])]==pr['harness_preflight']
 assert all(c['verified'] is True for c in cr['harness_preflight'])
 counts.update(cr['counts'])
 tables.append(dict(profile=cp['profile'],modes=len(cr['cases']),counts=cr['counts'],controls=len(cr['harness_preflight'])))
 for change in cp['nonpass_status_changes']:
  obs=change['after']['observation'];assert obs['status']=='host-failure' and obs['message']=='unhandled-rejection' and obs['completion']['unhandled']==1
  unhandled.append(change['id'])
assert dict(counts)==candidate['counts'] and len(unhandled)==4
assert sum(row['modes'] for row in tables)==1330 and sum(row['controls'] for row in tables)==724
update=read(ledger['baseline_update']);gates=read(ledger['baseline_gates'])
assert update['status']==gates['status']=='pass' and len(update['written'])==7 and len(gates['profiles'])==8
for gate,cp in zip(gates['profiles'],candidate['profiles']):
 r=read(gate['report']);c=read(cp['report']);r.pop('seconds');c.pop('seconds');assert r==c
 receipt=read(gate['receipt']);assert receipt['exit']==gate['exit']==0 and gate['errors']==[]
 assert bound(Path(gate['log']['path']))==gate['log'] and receipt['sha256']==gate['log']['sha256']
assert ledger['cumulative_baseline_transitions']==dict(new_passes=56,newly_reached_failures=14,carried_runtime_passes=20,carried_runtime_failures=10)
for role,record in ledger['binaries'].items():
 sidecar=read(record['sidecar']);assert bound(Path(record['binary']['path']))==record['binary'];assert sidecar==record['record']
 assert read(sidecar['build'])['exit']==0
paths=['README.md','docs/ROADMAP.md','docs/VALIDATION.md','docs/classes.md','docs/promise-class-admission.md']
raw={n:(D/'raw'/n).read_text() for n in paths}
before={n:(D/'before'/n).read_text() for n in paths if (D/'before'/n).exists()}
for n,s in before.items():
 assert subprocess.check_output(['git','show',ledger['base']+':'+n],cwd=W).decode()==s
 put(P/'before'/n,s)
python_validation='''The complete Python suite passes **696 tests with no skips**, preserving all
683 parent test identities plus 13 new adversarial groups. The focused candidate
passes all 13 groups; against the parent they recorded one pass and 12
missing-API failures. The first full candidate recorded 695 passes and one
failure: an old mocked withResolvers route still expected its former feature
set. A single expected-set addition of `class` corrected that fixture, without
changing the producer, independent control oracle or runtime. The failed run,
original payload and additive source review remain retained.'''
baseline_validation='''After independent review, seven compact baselines were updated from the healthy
measurements. All eight fresh `--baseline` runs exit zero and reproduce the
complete measured reports except elapsed time, retaining every failed and
unsupported outcome. Relative to the older baselines, 56 new passes and 14 newly
reached failures include the earlier class-runtime checkpoint's 20 passes and
ten failures; this admission change contributes only 36 and four. AggregateError
and all other unselected baselines are unchanged.'''
raw['docs/VALIDATION.md']=raw['docs/VALIDATION.md'].replace('[[PENDING_FULL_PYTHON_VALIDATION]]',python_validation).replace('[[PENDING_BASELINE_VALIDATION]]',baseline_validation)
anchor='A source review corrected the new graph check to preserve 192 existing\n'
assert raw['docs/VALIDATION.md'].count(anchor)==1
raw['docs/VALIDATION.md']=raw['docs/VALIDATION.md'].replace(anchor,'The final inventory covers 1,840 selected inputs and 25 changed source, test or\nbaseline paths; it is not a complete build graph.\nA source review corrected the new graph check to preserve 192 existing\n')
chapter_python='''The complete Python suite passes **696 tests with no skips**, retaining all 683
parent identities plus 13 new adversarial groups. The first full run's 695
passes and one failure are retained: a legacy withResolvers mock needed the
selected `class` feature in its expected set. That one-set fixture correction
changed no producer, oracle or runtime behavior.'''
chapter_baseline='''Seven baselines were updated after independent review. All eight fresh baseline
gates exit zero, with complete reports equal to the measurements except elapsed
time. Their cumulative 56 new passes and 14 newly reached failures include the
prior runtime checkpoint's 20 and ten; this admission adds only 36 and four.
Failed and unsupported rows remain recorded; unselected baselines are unchanged.'''
raw['docs/promise-class-admission.md']=raw['docs/promise-class-admission.md'].replace('[[PENDING_FULL_PYTHON_VALIDATION]]',chapter_python).replace('[[PENDING_BASELINE_VALIDATION]]',chapter_baseline)
raw['docs/promise-class-admission.md']=raw['docs/promise-class-admission.md'].replace('No runtime change or full\nRust suite rerun belongs to this admission checkpoint.','No runtime change, full\nRust suite rerun or GPU validation belongs to this admission checkpoint.')
for n,s in raw.items():
 assert '[[PENDING_' not in s
 put(P/'raw'/n,s)
 put(P/'diffs'/(n+'.diff'),''.join(difflib.unified_diff(before.get(n,'').splitlines(True),s.splitlines(True),fromfile='a/'+n,tofile='b/'+n)))
historical={}
for n,title in [('docs/VALIDATION.md','# Validation record\n\n'),('docs/classes.md','# JavaScript classes\n\n')]:
 suffix=before[n][len(title):];assert raw[n].endswith(suffix)
 historical[n]=dict(bytes=len(suffix.encode()),sha256=hashlib.sha256(suffix.encode()).hexdigest(),preserved=True)
# All local links newly introduced by this hold resolve to existing/final raw docs,
# except the two deliberately future evidence destinations owned by publication.
future={'docs/evidence/promise-class-admission/manifest.json','docs/evidence/promise-class-admission/sources-and-checks.tar.gz'}
links=[]
for n in paths:
 old=before.get(n,'');newlinks=set(re.findall(r'\]\(([^)]+)\)',raw[n]))-set(re.findall(r'\]\(([^)]+)\)',old))
 for link in sorted(newlinks):
  if '://' in link or link.startswith('#'):continue
  rel=(Path(n).parent/link).as_posix();assert rel in future or (P/'raw'/rel).exists() or (W/rel).exists(),rel
  links.append(dict(document=n,target=link,resolved=rel,future_evidence=rel in future))
inputs=[bound(ledger_path),ledger['source_inventory'],ledger['candidate_capture'],ledger['parent_capture'],ledger['baseline_update'],ledger['baseline_gates'],bound(H/'root/migration-correction-1.json'),bound(H/'migration-correction-review-1/review.json'),bound(D/'draft-ready.json')]
dump(P/'claim-checks.json',dict(status='actual receipts joined; documentation author check',inputs=inputs,table=tables,new_unhandled_failure_ids=unhandled,
 python_counts=ledger['python_counts'],raw_transition_counts=candidate['transition_counts'],cumulative_baseline_transitions=ledger['cumulative_baseline_transitions'],
 historical_bodies=historical,links=links,project_execution=False,live_edits=False))
files=[p for p in sorted(P.rglob('*')) if p.is_file()]
dump(P/'source-ready.json',dict(status='source-ready final five-document hold; actual receipts bound',base=ledger['base'],preserves_draft=bound(D/'draft-ready.json'),
 files=[bound(p) for p in files],final_validation=bound(ledger_path),source_inventory=ledger['source_inventory'],paths=paths,project_execution=False,live_edits=False))
print(json.dumps(bound(P/'source-ready.json')))
print('chapter words',len(raw['docs/promise-class-admission.md'].split()),'lines',len(raw['docs/promise-class-admission.md'].splitlines()))
