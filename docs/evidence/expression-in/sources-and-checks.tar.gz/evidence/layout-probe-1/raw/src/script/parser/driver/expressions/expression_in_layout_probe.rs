//! Prospective computed/middle +In layout; no production implementation.
//! Full enums preserve AU source2 variant and field ordering. Neighboring
//! payloads are actual types. Proposed owners append only saved_in bools.
#![allow(dead_code)]
use super::*;
use super::super::{Body, Kind, Output, Transition, functions, statements};
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "EXPRESSION_IN_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn same<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}

enum BaselineExpressionFrame {
    Assignment,
    AssignmentHead,
    ConditionalYes(ExprId),
    ConditionalNo(ExprId, ExprId),
    AssignmentRight(String, ExprId),
    Sequence,
    SequenceHead,
    SequenceNext(Vec<ExprId>),
    Binary(u8),
    BinaryHead(u8),
    BinaryRight(Binary, &'static str),
    Unary,
    Prefix(&'static str),
    PrefixUpdate(f64),
    Base(bool),
    PostfixResume(Postfix),
    Computed(Postfix),
    // Argument flags are (any spread, current operand is spread, saved allow_in).
    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
    New,
    NewHead,
    NewComputed(NewState),
    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
    Primary,
    CoverItem(Cover, bool),
    ArrayItem(Array),
    ObjectKey(Object, bool, bool),
    AccessorKey(Object, bool),
    ObjectFunction(Object, PropertyName, Option<bool>),
    ObjectValue(Object, PropertyName, bool),
    NamedFunction(Option<String>),
    Key,
    ComputedKey(bool),
    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
    Pass,
}

enum ProposedExpressionFrame {
    Assignment,
    AssignmentHead,
    ConditionalYes(ExprId, bool),
    ConditionalNo(ExprId, ExprId),
    AssignmentRight(String, ExprId),
    Sequence,
    SequenceHead,
    SequenceNext(Vec<ExprId>),
    Binary(u8),
    BinaryHead(u8),
    BinaryRight(Binary, &'static str),
    Unary,
    Prefix(&'static str),
    PrefixUpdate(f64),
    Base(bool),
    PostfixResume(Postfix),
    Computed(Postfix, bool),
    // Argument flags are (any spread, current operand is spread, saved allow_in).
    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
    New,
    NewHead,
    NewComputed(NewState, bool),
    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
    Primary,
    CoverItem(Cover, bool),
    ArrayItem(Array),
    ObjectKey(Object, bool, bool),
    AccessorKey(Object, bool),
    ObjectFunction(Object, PropertyName, Option<bool>),
    ObjectValue(Object, PropertyName, bool),
    NamedFunction(Option<String>),
    Key,
    ComputedKey(bool),
    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
    Pass,
}

enum BaselineKind {
    Expression(BaselineExpressionFrame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
}

enum ProposedKind {
    Expression(ProposedExpressionFrame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
}

enum BaselineTransition {
    Done(Output),
    Again(BaselineKind),
    Child(BaselineKind, BaselineKind),
}

enum ProposedTransition {
    Done(Output),
    Again(ProposedKind),
    Child(ProposedKind, ProposedKind),
}

#[test]
fn prospective_expression_in_parser_layout() {
    // Validate full baseline mirrors before observing the proposed layouts.
    // No proposed equality or guessed byte count is asserted.
    same::<Frame, BaselineExpressionFrame>();
    same::<Kind, BaselineKind>();
    same::<Transition, BaselineTransition>();
    pair::<Frame, ProposedExpressionFrame>("parser.expressions.Frame");
    pair::<Kind, ProposedKind>("parser.driver.Kind");
    pair::<Transition, ProposedTransition>("parser.driver.Transition");
    pair::<Output, Output>("parser.driver.Output");
    pair::<Body, Body>("parser.driver.Body");
    pair::<Binary, Binary>("parser.expressions.Binary");
    pair::<Postfix, Postfix>("parser.expressions.Postfix");
    pair::<NewState, NewState>("parser.expressions.NewState");
    pair::<Cover, Cover>("parser.expressions.Cover");
    pair::<Array, Array>("parser.expressions.Array");
    pair::<Object, Object>("parser.expressions.Object");
    pair::<statements::Frame, statements::Frame>("parser.statements.Frame");
    pair::<statements::BodyFrame, statements::BodyFrame>("parser.statements.BodyFrame");
    pair::<functions::Frame, functions::Frame>("parser.functions.Frame");
    pair::<functions::State, functions::State>("parser.functions.State");
    println!(
        "EXPRESSION_IN_DERIVED_V1 name=parser.initial_kind_buffer current={} proposed={}",
        4 * size_of::<Kind>() + 32,
        4 * size_of::<ProposedKind>() + 32
    );
    println!(
        "EXPRESSION_IN_DERIVED_V1 name=parser.kind_heap_ceiling current={} proposed={}",
        MAX_HEAP / size_of::<Kind>(),
        MAX_HEAP / size_of::<ProposedKind>()
    );
}
