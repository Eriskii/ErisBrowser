from pathlib import Path
import hashlib,json,difflib
B=Path('/tmp/eris-expression-in-followup-1');D=B/'layout-probe-1';AU=Path('/tmp/eris-call-argument-in-1');W=AU/'worktree'
assert not (D/'source-ready.json').exists()
def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha_bytes(p.read_bytes())}
def write(name,data):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(data if isinstance(data,str) else json.dumps(data,indent=2)+'\n');return p
inventory=json.loads((AU/'source2.json').read_text())
rels=['src/script/parser/driver/expressions.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','src/script/parser.rs','src/script/code.rs','src/script.rs','Cargo.toml','Cargo.lock']
rows=[]
for r in rels:
 src=W/r;assert sha_bytes(src.read_bytes())==inventory['source_sha256'][r],r
 dst=D/'before'/r;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(src.read_bytes())
 rows.append({'relative':r,'snapshot':ref(dst),'source2_sha256':inventory['source_sha256'][r]})
expr=(D/'before'/rels[0]).read_text();driver=(D/'before'/rels[1]).read_text()
def extract(text,prefix):
 start=text.index(prefix);end=text.index('\n}',start)+2
 return text[start:end],text[:start].count('\n')+1,text[:end].count('\n')+1
f,fs,fe=extract(expr,'pub(super) enum Frame {');k,ks,ke=extract(driver,'enum Kind {');t,ts,te=extract(driver,'enum Transition {')
bf=f.replace('pub(super) enum Frame {','enum BaselineExpressionFrame {',1)
pf=bf.replace('enum BaselineExpressionFrame {','enum ProposedExpressionFrame {',1)
deltas=[('    Computed(Postfix),','    Computed(Postfix, bool),'),('    NewComputed(NewState),','    NewComputed(NewState, bool),'),('    ConditionalYes(ExprId),','    ConditionalYes(ExprId, bool),')]
for old,new in deltas:
 assert pf.count(old)==1;pf=pf.replace(old,new)
rev=pf.replace('enum ProposedExpressionFrame {','enum BaselineExpressionFrame {',1)
for old,new in deltas:rev=rev.replace(new,old)
assert rev==bf
bk=k.replace('enum Kind {','enum BaselineKind {',1).replace('expressions::Frame','BaselineExpressionFrame')
pk=k.replace('enum Kind {','enum ProposedKind {',1).replace('expressions::Frame','ProposedExpressionFrame')
bt=t.replace('enum Transition {','enum BaselineTransition {',1).replace('Kind','BaselineKind')
pt=t.replace('enum Transition {','enum ProposedTransition {',1).replace('Kind','ProposedKind')
header='''//! Prospective computed/middle +In layout; no production implementation.
//! Full enums preserve AU source2 variant and field ordering. Neighboring
//! payloads are actual types. Proposed owners append only saved_in bools.
#![allow(dead_code)]
use super::*;
use super::super::{Body, Kind, Output, Transition, functions, statements};
use std::mem::{align_of, size_of};

fn pair<Current, Proposed>(name: &str) {
    println!(
        "EXPRESSION_IN_LAYOUT_V1 name={} current_size={} current_align={} proposed_size={} proposed_align={}",
        name,
        size_of::<Current>(),
        align_of::<Current>(),
        size_of::<Proposed>(),
        align_of::<Proposed>()
    );
}
fn same<Actual, Mirror>() {
    assert_eq!(size_of::<Actual>(), size_of::<Mirror>());
    assert_eq!(align_of::<Actual>(), align_of::<Mirror>());
}

'''
test='''#[test]
fn prospective_expression_in_parser_layout() {
    // Validate full baseline mirrors before observing the proposed layouts.
    // No proposed equality or guessed byte count is asserted.
    same::<Frame, BaselineExpressionFrame>();
    same::<Kind, BaselineKind>();
    same::<Transition, BaselineTransition>();
    pair::<Frame, ProposedExpressionFrame>("parser.expressions.Frame");
    pair::<Kind, ProposedKind>("parser.driver.Kind");
    pair::<Transition, ProposedTransition>("parser.driver.Transition");
    pair::<Output, Output>("parser.driver.Output");
    pair::<Body, Body>("parser.driver.Body");
    pair::<Binary, Binary>("parser.expressions.Binary");
    pair::<Postfix, Postfix>("parser.expressions.Postfix");
    pair::<NewState, NewState>("parser.expressions.NewState");
    pair::<Cover, Cover>("parser.expressions.Cover");
    pair::<Array, Array>("parser.expressions.Array");
    pair::<Object, Object>("parser.expressions.Object");
    pair::<statements::Frame, statements::Frame>("parser.statements.Frame");
    pair::<statements::BodyFrame, statements::BodyFrame>("parser.statements.BodyFrame");
    pair::<functions::Frame, functions::Frame>("parser.functions.Frame");
    pair::<functions::State, functions::State>("parser.functions.State");
    println!(
        "EXPRESSION_IN_DERIVED_V1 name=parser.initial_kind_buffer current={} proposed={}",
        4 * size_of::<Kind>() + 32,
        4 * size_of::<ProposedKind>() + 32
    );
    println!(
        "EXPRESSION_IN_DERIVED_V1 name=parser.kind_heap_ceiling current={} proposed={}",
        MAX_HEAP / size_of::<Kind>(),
        MAX_HEAP / size_of::<ProposedKind>()
    );
}
'''
raw=header+'\n\n'.join([bf,pf,bk,pk,bt,pt])+'\n\n'+test
relative='src/script/parser/driver/expressions/expression_in_layout_probe.rs'
p=write('raw/'+relative,raw)
block='\n#[cfg(test)]\nmod expression_in_layout_probe;\n'
assert expr.startswith('use super::*;\n') and 'mod expression_in_layout_probe;' not in expr
registered=expr.replace('use super::*;\n','use super::*;\n'+block,1)
assert registered.replace(block,'',1)==expr
reg=write('raw-registration/'+rels[0],registered)
patch=write('diffs/src__script__parser__driver__expressions.rs.patch',''.join(difflib.unified_diff(expr.splitlines(True),registered.splitlines(True),fromfile='a/'+rels[0],tofile='b/'+rels[0])))
maps=[]
for name,src,start,end,original,baseline,proposed in [('Frame',rels[0],fs,fe,f,bf,pf),('Kind',rels[1],ks,ke,k,bk,pk),('Transition',rels[1],ts,te,t,bt,pt)]:
 maps.append({'type':name,'source':src,'source_start_line':start,'source_end_line':end,'original_bytes':len(original.encode()),'original_sha256':sha_bytes(original.encode()),'baseline_mirror_start_line':raw[:raw.index(baseline)].count('\n')+1,'proposed_mirror_start_line':raw[:raw.index(proposed)].count('\n')+1})
source_map=write('source-map.json',{
 'baseline_status':'Provisional final AU source2, not yet a published-commit binding. Published commit refresh and exact relevant-source match required before root import.',
 'au_candidate_inventory':ref(AU/'source2.json'),'files':rows,'extracted_definitions':maps,
 'construction':'Complete Frame variants/order copied. Proposed adds saved_in only after Postfix in Computed, NewState in NewComputed and ExprId in ConditionalYes. Complete Kind substitutes only its Expression payload; complete Transition substitutes only Kind. All actual neighboring payloads and existing AU Arguments/NewArguments third bools are retained.',
 'new_runtime_or_parser_fields':False,'repr_changes':False,'placeholder_payloads':False,
 'registration_inverse':'Remove exactly the single cfg(test) expression_in_layout_probe block to recover the full before expressions.rs bytes.'
})
observation=write('observation-contract.json',{
 'test':'script::parser::driver::expressions::expression_in_layout_probe::prospective_expression_in_parser_layout',
 'groups':1,'layout_rows':15,'derived_rows':2,
 'baseline_assertions':'Actual and complete baseline mirror sizes/alignments must agree for Frame, Kind and Transition.',
 'proposed_assertions':'None; root observes actual proposed size/alignment values rather than assuming unchanged layouts.',
 'derived_formulas':{'initial_kind_buffer':'32 + 4 * sizeof(Kind)','kind_heap_ceiling':'MAX_HEAP / sizeof(Kind)'},
 'fee_selection':'None in this hold. Shape evidence informs later root selection; Sequence adds existing dispatch/depth even if type widths remain unchanged.',
 'claims_excluded':['Production behavior','Actual final production layout','Universal ABI sizes','Native stack or RSS','Timing/performance','Compile/runtime outcomes'],
 'required_execution_owner':'Root only, on an isolated next-checkpoint branch after published-parent refresh.'
})
instructions=write('import-instructions.txt','''Root-owned temporary probe only.
1. Refresh the provisional AU source2 binding to the published AU commit. Verify each relevant source hash against source-map.json; if any differs, stop and reconcile the mirror before importing.
2. Check before/expressions.rs, copy the single raw module to its relative path, and apply the one cfg(test) registration patch. Preserve the existing argument_in_context_tests registration. No other source changes.
3. Run only prospective_expression_in_parser_layout with output retained on root-selected compiler/feature configurations. Record all 15 layout rows and 2 derived rows. Do not require proposed equality; do require the three baseline mirror equality checks.
4. Retain observed platform/toolchain/source provenance. Remove temporary module and registration; prove exact restoration against before bytes. No implementation or tariff is selected by this probe.
''')
manifest={
 'schema':'eris-expression-in-layout-probe-v1','status':'source-ready-prospective-only',
 'baseline':'Provisional AU final source2; published commit refresh required before execution.',
 'au_source2':ref(AU/'source2.json'),'scope_proposal':ref(B/'findings.json'),
 'module':{'relative':relative,'raw':ref(p),'groups':1},
 'registration':{'relative':rels[0],'before':ref(D/'before'/rels[0]),'raw':ref(reg),'diff':ref(patch)},
 'support':[ref(source_map),ref(observation),ref(instructions),ref(D/'author.py')],
 'expected_delta':'Only three saved-context bools in the proposed enum. No production path, Runtime field, repr, allocator policy or fixed fee change.',
 'project_execution':False,'live_edits':False,'measurements':[],'production_authored':False
}
seal=write('source-ready.json',manifest);print(json.dumps(ref(seal),indent=2))
