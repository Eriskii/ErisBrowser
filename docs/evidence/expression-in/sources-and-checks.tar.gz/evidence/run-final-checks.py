import hashlib, json, shutil, subprocess
from pathlib import Path

A = Path(__file__).resolve().parent
commands = [
    ['run-check.py', 'default-full-1', '1.88.0', 'Cargo.toml', '-', 'test', '--', '--include-ignored'],
    ['run-check.py', 'host-vulkan-full-1', '1.99.0', 'Cargo.toml', 'test262-host,vulkan-raster', 'test', '--', '--include-ignored'],
    ['run-check.py', 'clippy-msrv-1', '1.88.0', 'Cargo.toml', '-', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['run-check.py', 'clippy-host-vulkan-1', '1.99.0', 'Cargo.toml', 'test262-host,vulkan-raster', 'clippy', '--all-targets', '--', '-D', 'warnings'],
    ['run-tool.py', 'format-check-1', 'env', 'CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home', 'RUSTUP_HOME=/tmp/eris-vulkan-rustup', 'cargo', '+1.99.0', 'fmt', '--all', '--', '--check'],
    ['run-check.py', 'host-release-1', '1.88.0', 'Cargo.toml', 'test262-host', 'build', '--release', '--bin', 'eris-js'],
]
for command in commands:
    subprocess.run(['python3', *command], cwd=A, check=True)
binary = A / 'eris-js-host-final-1'
assert not binary.exists()
shutil.copyfile(A / 'target-msrv/release/eris-js', binary)
binary.chmod(0o755)
record = {'path': str(binary), 'bytes': binary.stat().st_size,
          'sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
          'source_inventory': str(A / 'source-final.json'),
          'build_receipt': str(A / 'validation/host-release-1.json')}
(A / 'binary.json').write_text(json.dumps(record, indent=2) + '\n')
for label, profile, baseline, output in [
    ('upstream-all-1', 'promise-all', 'test262-promise-all-current.json', 'promise-all-report.json'),
    ('upstream-existing-1', 'promise-methods-async', 'test262-promise-methods-async-current.json', 'promise-existing-report.json'),
]:
    subprocess.run(['python3', 'run-tool.py', label, 'python3', 'tools/test262_conformance.py',
                    '--binary', str(binary), '--profile', profile, '--baseline',
                    'tests/conformance/' + baseline, '--output', str(A / output)], cwd=A, check=True)
