import hashlib, json, re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
PREVIOUS = Path('/tmp/eris-call-argument-in-1')
def read(p): return json.loads(p.read_bytes())
def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def tests(log):
    text = log.read_text()
    pattern = r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
    rows = [(status, *map(int, numbers)) for status, *numbers in re.findall(pattern, text, re.M)]
    found = re.findall(r'^test (\S+) \.\.\. ok$', text, re.M)
    assert rows and sum(row[1] for row in rows) == len(found) == len(set(found))
    assert all(row[0] == 'ok' and row[2:5] == (0, 0, 0) for row in rows)
    return rows, set(found)

source = read(A / 'source-final.json')
parent = read(A / 'parent-source.json')
for relative, digest in source['source_sha256'].items():
    assert bind(W / relative)['sha256'] == digest, relative
changed = {path for path, digest in source['source_sha256'].items()
           if parent['source_sha256'].get(path) != digest}
assert len(changed) == 5, changed
assert len(source['source_sha256']) == len(parent['source_sha256']) + 2 == 1240
roster = read(A / 'root/final-roster.json')
names = set(roster['public'] + roster['private'])
assert len(roster['public']) == 21
assert len(names) == len(roster['public']) + len(roster['private'])
checks = {}
labels = ['focused-expression-in-1', 'default-full-1', 'host-vulkan-full-1',
          'clippy-msrv-1', 'clippy-host-vulkan-1', 'format-check-1',
          'host-release-1', 'upstream-all-1', 'upstream-existing-1']
for label in labels:
    receipt = A / 'validation' / (label + '.json')
    record = read(receipt)
    log = A / 'validation' / record['log']
    assert record['exit'] == 0 and bind(log)['sha256'] == record['sha256']
    checks[label] = {'receipt': bind(receipt), 'log': bind(log)}
    if label in ['focused-expression-in-1', 'default-full-1', 'host-vulkan-full-1']:
        rows, found = tests(log)
        assert names <= found
        if label == 'focused-expression-in-1':
            assert len(rows) == 1 and found == names
        else:
            old_log = PREVIOUS / 'validation' / (label + '.log')
            old_rows, old_names = tests(old_log)
            assert len(rows) == len(old_rows) == 50
            assert all(row[5] == 0 for row in rows)
            assert not (names & old_names)
            assert found == old_names | names
            checks[label]['previous_log'] = bind(old_log)
        checks[label].update(passed=len(found), result_rows=len(rows), failed=0, ignored=0)

binary = read(A / 'binary.json')
assert bind(Path(binary['path'])) == {k: binary[k] for k in ['path', 'bytes', 'sha256']}
assert binary['source_inventory'] == str(A / 'source-final.json')
reports = {}
for name, total, guards in [('promise-all-report.json', 196, 90), ('promise-existing-report.json', 458, 74)]:
    report = read(A / name)
    parent_report = A / 'replay-parent' / name
    assert parent_report.read_bytes() == (PREVIOUS / name).read_bytes()
    previous = read(parent_report)
    assert report['cases'] == previous['cases']
    assert report['harness_preflight'] == previous['harness_preflight']
    assert report['mode_cases'] == len(report['cases']) == total
    assert len(report['harness_preflight']) == guards and report['harness_preflight_passed']
    assert all(case['verified'] for case in report['harness_preflight'])
    assert not report['regressions'] and not report['improvements']
    assert report['binary_sha256'] == binary['sha256']
    for key in ['revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'counts']:
        assert report[key] == previous[key]
    reports[name] = {'report': bind(A / name), 'parent_report': bind(parent_report),
                     'counts': report['counts'], 'modes': total, 'harness_controls': guards,
                     'all_case_and_harness_records_unchanged': True}

out = {'status': 'pass', 'base': source['base'], 'source': bind(A / 'source-final.json'),
       'source_review': bind(A / 'root/final-source-review.json'),
       'source_inputs': len(source['source_sha256']), 'changed_build_inputs': sorted(changed),
       'new_groups': {'public': len(roster['public']), 'private': len(roster['private']), 'total': len(names)},
       'roster': bind(A / 'root/final-roster.json'), 'checks': checks, 'binary': binary, 'replays': reports,
       'parent_public': bind(A / 'root/parent-public-baseline.json'),
       'parent_private': bind(A / 'root/parent-private-baseline.json'),
       'preservation': 'Existing tests remain unchanged. Actual x86_64 Linux types and three conditional full-compile tariff pairs corroborated in both selected configurations. New Sequence dispatch/storage work is charged through existing paths; no universal +2 or unchanged-heap claim.',
       'limitations': ['Selected computed-member and conditional-middle grammar correction only; full web compatibility remains unfinished.',
                       'No GPU-device, physical-memory, native-stack or Chromium-speed measurement at this checkpoint.',
                       'Error cleanup restores invocation-entry In flag, not full failed-parser state.']}
(A / 'root/final-validation.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'status': 'pass', 'new_groups': len(names), 'default': checks['default-full-1']['passed'],
                  'host_vulkan': checks['host-vulkan-full-1']['passed']}))
