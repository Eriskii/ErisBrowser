from pathlib import Path
import json
A=Path(__file__).resolve().parents[1];W=A/'worktree'
v=json.loads((A/'root/final-validation.json').read_text());assert v['status']=='pass'
assert v['checks']['default-full-1']['passed']==3055
assert v['checks']['host-vulkan-full-1']['passed']==3409
p=W/'README.md';t=p.read_text();old='the surrounding `for-in` grammar.\n';new=old+'''[Computed keys and conditional contexts](docs/expression-in.md) now admit
comma expressions inside brackets and `in` inside brackets or the middle of
`?:`, including in `for` initializers. Evaluation order and outer restrictions
are covered by interpreter and parser regressions.
''';assert t.count(old)==1;p.write_text(t.replace(old,new))
p=W/'docs/COMPATIBILITY.md';t=p.read_text();old='''`for-in` restrictions remain in effect. Array/object spread and classes remain
unfinished.
''';new='''`for-in` restrictions remain in effect. [Computed keys and conditional
contexts](expression-in.md) also admit comma expressions inside member brackets
and enable `in` inside brackets and the middle of `?:`. Conditional tests and
false operands retain their outer grammar context. Array/object spread and
classes remain unfinished.
''';assert t.count(old)==1;p.write_text(t.replace(old,new))
p=W/'docs/ROADMAP.md';t=p.read_text();old='''preserving the surrounding `for-in` grammar. Computed member expressions and the
true branch of conditional expressions still need their own grammar-context
follow-up. Array/object spread remains separate unfinished work.
''';new='''preserving the surrounding `for-in` grammar. [Computed member keys and
conditional middle operands](expression-in.md) now handle their own `+In`
contexts; brackets also admit comma expressions with ordered evaluation.
Existing parser work and storage charges cover the added sequence parsing.
Array/object spread remains separate unfinished work.
''';assert t.count(old)==1;p.write_text(t.replace(old,new))
p=W/'docs/call-argument-in.md';t=p.read_text();old='''production security or the Chromium-relative performance target. Computed
member and conditional-expression contexts remain separate follow-ups.
''';new='''production security or the Chromium-relative performance target. The later
[computed-member and conditional-expression follow-up](expression-in.md) handles
their separate grammar contexts and comma expressions inside brackets.
''';assert t.count(old)==1;p.write_text(t.replace(old,new))
t=(A/'documentation-draft-1/expression-in.md').read_text()
validation='''All **31 new regression groups** pass: 21 interpreter/differential-parser
groups and ten internal context, error and accounting groups. The public groups
cover both strict modes. Before the fix, the public baseline had seven passes
and fourteen failures; the private baseline had four passes and six failures.
No frozen expectation or existing test needed adjustment.

The complete suites pass **3,055 tests on Rust 1.88** and **3,409 with
`test262-host,vulkan-raster` on Rust 1.99**, each across 50 result rows with no
failed, ignored or filtered tests. Strict Clippy passes for all targets in both
configurations, and formatting passes. Actual x86_64 Linux expression-frame,
driver-kind and transition sizes remain 72, 112 and 224 bytes. Three
conditional-only full-compile work/heap pairs remain exact in both modes and
configurations. Computed-key costs use the existing Sequence charges and are
not asserted unchanged.

The release adapter preserves all case and harness records in the pinned
196-mode `Promise.all` and 458-mode Promise profiles, with all 90 and 74 harness
controls passing. These replays check preservation; no conformance baseline is
changed. The new grammar cases are covered by the focused tests.'''
assert t.count('VALIDATION_PENDING')==1
p=W/'docs/expression-in.md';assert not p.exists();p.write_text(t.replace('VALIDATION_PENDING',validation))
print('Updated five documentation files from verified final results.')
