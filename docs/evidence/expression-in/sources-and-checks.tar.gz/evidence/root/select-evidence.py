import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
final=read(A/'source-final.json');parent=read(A/'parent-source.json')
changed={r:h for r,h in final['source_sha256'].items() if parent['source_sha256'].get(r)!=h}
assert len(changed)==5
assert set(parent['source_sha256'])<=set(final['source_sha256'])
inventory={'base':final['base'],'scope':'Changed build inputs only; reconstruct full1240-input source from parent commit plus these five files. Complete source-final inventory retained.','source_sha256':changed}
(A/'evidence-source.json').write_text(json.dumps(inventory,indent=2)+'\n')
validation=read(A/'root/final-validation.json');assert validation['status']=='pass'
peer=read(A/'root/final-validation-review.json');assert 'clear' in peer['status']
artifacts={};excluded={'selection-final.json','publication-verification.json','github-publication.json'}
for directory in ['plans','published-base-1','compile-accounting-audit-1','layout-probe-1',
                  'tariff-probe-1','private-outline-1','tests-public-1','tests-private-1',
                  'production-parser-1','unformatted','documentation-draft-1',
                  'root','validation','replay-parent']:
 for p in sorted((A/directory).rglob('*')):
  assert not p.is_symlink(),p
  if not p.is_file() or p.name in excluded:continue
  assert '__pycache__' not in p.parts,p
  artifacts[str(p.relative_to(A))]=bind(p)
for p in sorted(A.iterdir()):
 if p.is_file() and p.suffix in ['.json','.py','.md']:artifacts[p.name]=bind(p)
for relative in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md',
                 'docs/call-argument-in.md','docs/expression-in.md']:
 artifacts['documentation/'+relative]=bind(W/relative)
selection={'source_inventory':bind(A/'evidence-source.json'),'artifacts':artifacts,
           'claims':{'scope':'Computed member Expression[+In] via existing Sequence and conditional middle AssignmentExpression[+In], with scoped restoration.',
                     'base':final['base'],'complete_build_inventory':bind(A/'source-final.json'),
                     'complete_build_input_count':1240,'changed_build_inputs':5,
                     'validation':validation,'peer':bind(A/'root/final-validation-review.json'),
                     'limitations':'No full-web compatibility, production security, GPU-device or Chromium-relative performance claim.'},
           'max_uncompressed_bytes':32*1024*1024}
(A/'root/selection-final.json').write_text(json.dumps(selection,indent=2)+'\n')
print(json.dumps({'changed_source_inputs':5,'full_build_inputs':1240,'artifacts':len(artifacts)}))
