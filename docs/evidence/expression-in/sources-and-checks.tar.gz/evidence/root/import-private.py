import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1]; W=A/'worktree'; H=A/'tests-private-1'
def bind(p):
 data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def verify(value):
 if isinstance(value,dict):
  if set(value)=={'path','bytes','sha256'}: assert bind(Path(value['path']))==value,value['path']
  else:
   for sub in value.values():verify(sub)
 elif isinstance(value,list):
  for sub in value:verify(sub)
ready=json.loads((H/'source-ready.json').read_text());verify(ready)
source=json.loads((A/'source-parent-public.json').read_text())
for relative,digest in source['source_sha256'].items():assert bind(W/relative)['sha256']==digest,relative
registration=ready['registration'];r=registration['relative']
assert (W/r).read_bytes()==Path(registration['before']['path']).read_bytes()
test=Path(ready['test_module']['path']);relative=str(test.relative_to(H/'raw'))
assert not (W/relative).exists()
(W/relative).write_bytes(test.read_bytes());(W/r).write_bytes(Path(registration['raw']['path']).read_bytes())
source['scope']='Published AU plus frozen21 public and10 private groups; registrations only, before AV production.'
for name in [relative,r]:source['source_sha256'][name]=bind(W/name)['sha256']
source['source_sha256']=dict(sorted(source['source_sha256'].items()))
assert len(source['source_sha256'])==1240
(A/'source-parent-private.json').write_text(json.dumps(source,indent=2)+'\n')
(A/'root/private-import.json').write_text(json.dumps({'status':'verified_import','hold':bind(H/'source-ready.json'),'source':bind(A/'source-parent-private.json'),'test':bind(W/relative),'registration':bind(W/r)},indent=2)+'\n')
print('Imported frozen10 private groups; all1240 source inputs bound.')
