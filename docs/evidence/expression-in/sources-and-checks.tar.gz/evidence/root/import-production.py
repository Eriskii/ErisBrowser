import hashlib,json,shutil
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'production-parser-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:assert bind(Path(v['path']))==v,v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
source=json.loads((A/'source-parent-private.json').read_text())
for path,digest in source['source_sha256'].items():assert bind(W/path)['sha256']==digest,path
ready=json.loads((H/'source-ready.json').read_text());verify(ready)
assert {r['relative'] for r in ready['paths']}=={'src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs'}
for row in ready['paths']:
 path=row['relative'];assert (W/path).read_bytes()==Path(row['before']['path']).read_bytes()
 (W/path).write_bytes(Path(row['raw']['path']).read_bytes())
for relative in ['src/script.rs','src/script/expression_in_tests.rs','src/script/parser/driver/expressions.rs','src/script/parser/driver/expressions/expression_in_context_tests.rs','src/script/parser_legacy.rs']:
 p=A/'unformatted'/relative;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/relative,p)
(A/'root/production-import.json').write_text(json.dumps({'status':'verified_two_file_import','hold':bind(H/'source-ready.json'),'parent_private_baseline':bind(A/'root/parent-private-baseline.json'),'scope':'Only selected three saved flags, computed Sequence dispatch, and matching legacy scopes; run cleanup and all other source unchanged.'},indent=2)+'\n')
print('Imported two-file production hold and retained unformatted inputs.')
