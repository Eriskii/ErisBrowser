from pathlib import Path
import json,hashlib,re,difflib
B=Path('/tmp/eris-expression-in-1');W=B/'worktree'
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
def read(p):return json.loads(p.read_text())
def verify(x):
 if isinstance(x,dict):
  if set(('path','bytes','sha256'))<=x.keys():assert ref(Path(x['path']))=={k:x[k] for k in ('path','bytes','sha256')}
  for v in x.values():verify(v)
 elif isinstance(x,list):
  for v in x:verify(v)
parent=read(B/'parent-source.json')['source_sha256'];final=read(B/'source-final.json')['source_sha256']
assert len(parent)==1238 and len(final)==1240 and set(parent)<=set(final)
public='src/script/expression_in_tests.rs';private='src/script/parser/driver/expressions/expression_in_context_tests.rs'
expected={'src/script.rs','src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs',public,private}
assert set(r for r in final if parent.get(r)!=final[r])==expected
assert set(final)-set(parent)=={public,private}
for r,v in final.items():assert h(W/r)==v,r
prod=read(B/'production-parser-1/source-ready.json');verify(prod)
pub=read(B/'tests-public-1/source-ready-published.json');verify(pub)
priv=read(B/'tests-private-1/source-ready.json');verify(priv)
for row in prod['paths']:
 r=row['relative'];assert h(B/'unformatted'/r)==row['raw']['sha256']==final[r]
assert h(B/'unformatted'/public)==pub['files'][0]['sha256']
assert h(B/'unformatted'/private)==priv['test_module']['sha256']
assert h(B/'unformatted/src/script.rs')==pub['files'][2]['sha256']==final['src/script.rs']
rawreg=(B/'unformatted/src/script.rs').read_bytes();before=Path(pub['files'][1]['path']).read_bytes();insert=Path(pub['files'][3]['path']).read_bytes()
assert len(insert)==39 and before+insert==rawreg and hashlib.sha256(before).hexdigest()==parent['src/script.rs']
assert set(str(p.relative_to(B/'unformatted')) for p in (B/'unformatted').rglob('*.rs'))==expected
assert priv['registration']['before']['sha256']==parent['src/script/parser/driver/expressions.rs']
assert prod['paths'][0]['before']['sha256']==priv['registration']['raw']['sha256']
assert prod['paths'][1]['before']['sha256']==parent['src/script/parser_legacy.rs']
# Lexical comparison preserves all source literal bytes. Only manually reviewed
# use sorting and optional final commas are accepted, not arbitrary punctuation.
pat=re.compile(r'(?P<space>\s+)|(?P<comment>//[^\n]*|/\*[\s\S]*?\*/)|(?P<raw>r(?P<hashes>\#*)"[\s\S]*?"(?P=hashes))|(?P<string>b?"(?:\\[\s\S]|[^"\\])*")|(?P<char>\'(?:\\.|[^\'\\\n])\')|(?P<ident>[A-Za-z_][A-Za-z_0-9]*)|(?P<number>\d[\w.]*)|(?P<other>.)')
def tokens(s):return[(m.lastgroup,m.group())for m in pat.finditer(s)if m.lastgroup not in('space','comment')]
format_checks=[]
for r in [public,private]:
 a=(B/'unformatted'/r).read_text();z=(W/r).read_text();notes=[]
 if r==private:
  ah,a=a.split('fn setup',1);zh,z=z.split('fn setup',1)
  assert ah=='//! Frozen owner, Sequence and restoration controls through existing parser APIs.\nuse super::*;\nuse super::super::{enter, run, Kind, Output, Transition};\nuse std::mem::size_of;\n\n'
  assert zh=='//! Frozen owner, Sequence and restoration controls through existing parser APIs.\nuse super::super::{Kind, Output, Transition, enter, run};\nuse super::*;\nuse std::mem::size_of;\n\n'
  notes.append('Two existing use declarations reordered and five imported names sorted; identical binding set, no macro-use or cfg change.')
  a='fn setup'+a;z='fn setup'+z
 x=tokens(a);y=tokens(z);literal=lambda t:[v for k,v in t if k in ('raw','string','char','number')]
 assert literal(x)==literal(y)
 commas=[]
 for tag,i,j,k,l in difflib.SequenceMatcher(a=x,b=y,autojunk=False).get_opcodes():
  if tag=='equal':continue
  assert tag=='insert' and y[k:l]==[('other',',')] and y[l][1] in (')',']','}'),(r,tag,x[i:j],y[k:l])
  commas.append({'before_closer':y[l][1],'preceding_tokens':[v for _,v in y[max(0,k-7):k]]})
 assert len(commas)==(17 if r==private else 0)
 # Added commas occur only in multi-item calls/patterns/arrays/match arms;
 # none forms a singleton tuple. Complete visual diff independently read.
 names=lambda s:re.findall(r'#\[test\]\s*fn\s+(\w+)',s)
 assert names(a)==names(z) and len(names(a))==(10 if r==private else 21)
 format_checks.append({'relative':r,'unformatted':ref(B/'unformatted'/r),'final':ref(W/r),'literal_tokens_preserved':len(literal(x)),'new_test_groups':len(names(a)),'optional_trailing_commas':commas,'notes':notes})
roster=read(B/'root/final-roster.json')
for r,key,prefix in [(public,'public','script::expression_in_tests::'),(private,'private','script::parser::driver::expressions::expression_in_context_tests::')]:
 assert [prefix+n for n in re.findall(r'#\[test\]\s*fn\s+(\w+)',(W/r).read_text())]==roster[key]
review={
 'status':'clear_source_only','reviewer':'script','parent':ref(B/'parent-source.json'),'final':ref(B/'source-final.json'),'counts':{'parent_inputs':1238,'final_inputs':1240,'existing_modified':3,'new_test_files':2,'unchanged_parent_inputs':1235},
 'changed_or_added':sorted(expected),
 'production_hold':ref(B/'production-parser-1/source-ready.json'),'production_peer':ref(B/'production-parser-1/script-review.json'),
 'test_holds':[ref(B/'tests-public-1/source-ready-published.json'),ref(B/'tests-private-1/source-ready.json')],
 'production_and_registration':['All1240 current input hashes equal source-final. No parent input removed; exactly three modified existing files and two added test modules.','The two production files remain byte-exact reviewed raw hold after formatting. Their registered before composition is exact private hold + parent; the independent full-file inverse proof already binds every production edit.','script.rs remains byte-exact held public registration: original parent plus39-byte cfg(test) declaration only. No Runtime field, implementation, old test, budget, Cargo or unrelated source change.','All five retained unformatted files equal the corresponding held raw/registration bytes. Both new test modules retain their complete literal token streams, all assertions/control flow and the exact21+10 test roster after the explicitly enumerated formatting.'],
 'formatting':format_checks,
 'roster':ref(B/'root/final-roster.json'),
 'actual_layout_scope':'No shape equality is inferred from formatting. Final actual-layout test is retained with x86_64 Linux gate; root owns its execution and validation.',
 'method':ref(Path(__file__)),
 'findings':[],
 'limits':'Static source inventory, byte inverse, lexical and manual diff review only. No compiler/formatter/test/browser/project execution or live edit by reviewer. Focused/full results are separate root evidence.'}
p=B/'root/final-source-review.json';assert not p.exists();p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(ref(p)))
