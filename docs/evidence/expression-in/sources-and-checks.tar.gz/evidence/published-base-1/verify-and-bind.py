from pathlib import Path
import difflib
import hashlib
import json
import subprocess

PLAN = Path('/tmp/eris-expression-in-followup-1')
OUT = PLAN / 'published-base-1'
AU = Path('/tmp/eris-call-argument-in-1')
WORKTREE = Path('/tmp/eris-expression-in-1/worktree')
COMMIT = '57d0a47d7802f3ad26816747a409ff729c853a42'


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')
    return binding(path)


def git(*args, input=None):
    # Read-only object lookup only. No project code, compiler or test execution.
    return subprocess.run(['git', '-C', str(WORKTREE), *args],
                          input=input, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE, check=True).stdout


assert git('rev-parse', 'HEAD').decode().strip() == COMMIT
inventory_path = AU / 'source2.json'
inventory = json.loads(inventory_path.read_text())['source_sha256']
assert len(inventory) == 1238
tree = {}
for record in git('ls-tree', '-r', '-z', COMMIT).split(b'\0'):
    if not record:
        continue
    meta, raw_path = record.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    tree[raw_path.decode()] = (mode, kind, oid)
paths = sorted(inventory)
for relative in paths:
    assert tree[relative][1] == 'blob'
    assert tree[relative][0] in ('100644', '100755')
request = ''.join(tree[p][2] + '\n' for p in paths).encode()
payload = git('cat-file', '--batch', input=request)
cursor = 0
blobs = {}
joins = []
for relative in paths:
    end = payload.index(b'\n', cursor)
    oid, kind, size = payload[cursor:end].decode().split()
    size = int(size)
    cursor = end + 1
    data = payload[cursor:cursor + size]
    cursor += size
    assert payload[cursor:cursor + 1] == b'\n'
    cursor += 1
    assert oid == tree[relative][2] and kind == 'blob'
    sha = hashlib.sha256(data).hexdigest()
    assert sha == inventory[relative], relative
    assert (WORKTREE / relative).read_bytes() == data, relative
    blobs[relative] = data
    joins.append({'relative': relative, 'git_blob': oid, 'bytes': size,
                  'sha256': sha, 'worktree_matches': True})
assert cursor == len(payload)
assert 'src/script/expression_in_tests.rs' not in tree
inventory_join = write_json(OUT / 'published-source-joins.json', {
    'commit': COMMIT, 'au_final_inventory': binding(inventory_path),
    'count': len(joins), 'rows': joins,
})

public_hold = PLAN / 'tests-public-1/source-ready.json'
public_bindings = json.loads((PLAN / 'tests-public-1/source-bindings.json').read_text())
public_joins = []
for row in public_bindings['sources']:
    relative = row['relative']
    snapshot = Path(row['snapshot']['path'])
    assert binding(snapshot) == row['snapshot']
    assert snapshot.read_bytes() == blobs[relative]
    public_joins.append({'relative': relative, 'snapshot': row['snapshot'],
                         'git_blob': tree[relative][2], 'unchanged': True})
before = PLAN / 'tests-public-1/before/src/script.rs'
after = PLAN / 'tests-public-1/registration-after/src/script.rs'
registration = PLAN / 'tests-public-1/registration.txt'
assert before.read_bytes() == blobs['src/script.rs']
assert after.read_bytes() == before.read_bytes() + registration.read_bytes()
assert registration.read_text() == '\n#[cfg(test)]\nmod expression_in_tests;\n'

proposal = json.loads((PLAN / 'source-bindings.json').read_text())
proposal_joins = []
changes = []
for row in proposal['files']:
    relative = row['relative']
    old = Path(row['snapshot']['path']).read_bytes()
    new = blobs[relative]
    target = OUT / 'source-inputs' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(new)
    if old != new:
        assert relative == 'src/script/parser/driver/expressions.rs'
        unformatted = b'            Frame::NewArguments(state.value, Vec::new(), current_spread, current_spread, saved_in),'
        formatted = (b'            Frame::NewArguments(\n'
                     b'                state.value,\n'
                     b'                Vec::new(),\n'
                     b'                current_spread,\n'
                     b'                current_spread,\n'
                     b'                saved_in,\n'
                     b'            ),')
        assert old.count(unformatted) == 1
        assert old.replace(unformatted, formatted) == new
        diff = OUT / 'proposal-to-published.patch'
        diff.write_text(''.join(difflib.unified_diff(
            old.decode().splitlines(True), new.decode().splitlines(True),
            fromfile='proposal-raw/' + relative,
            tofile='published/' + relative,
        )))
        changes.append({'relative': relative, 'kind': 'One rustfmt line wrap and optional trailing comma only.',
                        'exact_replacement_verified': True, 'diff': binding(diff)})
    proposal_joins.append({'relative': relative, 'retained_snapshot': row['snapshot'],
                           'published_snapshot': binding(target),
                           'git_blob': tree[relative][2], 'byte_identical': old == new})
assert len(changes) == 1

review = write_json(OUT / 'review.json', {
    'schema': 'eris-expression-in-published-base-refresh-v1',
    'status': 'clear', 'published_base_commit': COMMIT,
    'au_final_inventory': binding(inventory_path),
    'published_source_join': inventory_join,
    'all_1238_inventory_inputs_match_published_blobs_and_AV_checkout': True,
    'retained_proposal_hold': binding(PLAN / 'source-ready.json'),
    'retained_public_hold': binding(public_hold),
    'public_snapshot_joins': public_joins,
    'proposal_snapshot_joins': proposal_joins,
    'proposal_format_only_changes': changes,
    'exact_registration_before_after_inverse': True,
    'unchanged': [binding(PLAN / name) for name in [
        'cases.json', 'cases-2.json', 'findings.json',
        'tests-public-1/raw/src/script/expression_in_tests.rs',
        'tests-public-1/oracle.json', 'tests-public-1/registration.txt',
        'tests-public-1/registration.patch',
    ]],
    'meaning': 'Closes only the provisional published-base requirement. Original holds, source cases, expected values, Runtime/canonical helper text and registration bytes remain unchanged. No fee selection, baseline result or production approval is implied.',
    'method': 'Python standard-library hashing/diff and read-only git rev-parse/ls-tree/cat-file. No compiler, parser, engine, tests, formatter, network or live mutations.',
    'authoring_helper': binding(__file__),
})
selected_public = json.loads(public_hold.read_text())
selected_public.update({
    'status': 'tests-frozen-published-base-bound',
    'published_base_commit': COMMIT, 'base_refresh_required': False,
    'retained_provisional_hold': binding(public_hold),
    'published_base_refresh': review,
})
public_seal = write_json(PLAN / 'tests-public-1/source-ready-published.json', selected_public)
seal = write_json(OUT / 'source-ready.json', {
    'schema': 'eris-expression-in-published-base-refresh-hold-v1',
    'status': 'source-ready', 'published_base_commit': COMMIT,
    'review': review, 'published_public_hold': public_seal,
    'inventory_join': inventory_join,
    'new_proposal_source_snapshots': [row['published_snapshot'] for row in proposal_joins],
    'cases_unchanged': True, 'tests_unchanged': True,
    'execution': False, 'live_edits': False,
})
print(json.dumps({'refresh': seal, 'published_public_hold': public_seal}))
