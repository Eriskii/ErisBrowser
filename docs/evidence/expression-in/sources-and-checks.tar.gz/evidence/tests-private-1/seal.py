import json, hashlib, pathlib, difflib, re
D=pathlib.Path('/tmp/eris-expression-in-1/tests-private-1')
AV=D.parent
P=pathlib.Path('/tmp/eris-expression-in-followup-1')
def sha(b): return hashlib.sha256(b).hexdigest()
def binding(p):
 p=pathlib.Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(name,value):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n');return binding(p)
parent=json.loads((AV/'parent-source.json').read_text())
paths=['src/script/parser/driver/expressions.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','src/script/parser.rs','src/script/code.rs','src/script/code/records.rs','src/script/parser_legacy.rs','src/regexp.rs']
sources=[]
for rel in paths:
 q=P/'published-base-1/source-inputs'/rel
 if not q.exists(): q=AV/'worktree'/rel
 b=q.read_bytes();assert sha(b)==parent['source_sha256'][rel],rel
 out=D/'sources'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 sources.append({'relative':rel,'snapshot':binding(out),'parent_sha256':parent['source_sha256'][rel]})
rel='src/script/parser/driver/expressions.rs'
b=(D/'sources'/rel).read_bytes(); marker=b'#[cfg(test)]\nmod argument_in_context_tests;\n'; assert b.count(marker)==1
registration=b.replace(marker,marker+b'\n#[cfg(test)]\nmod expression_in_context_tests;\n')
for sub,data in [('before',b),('registration',registration)]:
 p=D/sub/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
patch=''.join(difflib.unified_diff(b.decode().splitlines(True),registration.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
p=D/'diffs'/f'{rel}.patch';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(patch)
raw=D/'raw/src/script/parser/driver/expressions/expression_in_context_tests.rs'
rawtext=raw.read_text(); names=re.findall(r'#\[test\]\nfn ([a-z0-9_]+)\(',rawtext); assert len(names)==10
eligibility=[
(8,'intentional_parent_failure','First computed_owner sees Assignment rather than selected Sequence before the later flag assertion.'),
(20,'intentional_parent_failure','First computed_owner child-kind assertion; later exact work cuts remain unobserved on parent.'),
(8,'intentional_parent_failure','First computed_owner child-kind assertion; page setup and cuts remain unobserved on parent.'),
(4,'intentional_parent_failure','First false-entry middle leaves allow_in=false; later colon/cut rows remain unobserved.'),
(12,'intentional_parent_failure','First false-context computed in expression cannot reach closing bracket; later rows remain unobserved.'),
(14,'preservation_expected_pass','AU run-Err cleanup and existing error kinds/messages already implement these observations.'),
(16,'preservation_expected_pass','Calls unchanged Sequence/list/record helpers with authentic paid owner/output setup.'),
(18,'intentional_parent_failure','First four prefix rows pass; work7 parent succeeds at6 rather than refusing the new eighth-work Member append. Later extra-head rows remain unobserved.'),
(1,'preservation_expected_pass','Existing and prospective exact mirrors agree; qualified x86_64 Linux only.'),
(6,'preservation_expected_pass','Three conditional-only complete compile totals from both parent toolchains/modes; qualified x86_64 Linux only.'),
]
roster=[]
for name,(rows,outcome,why) in zip(names,eligibility):
 roster.append({'rust_test':name,'planned_rows':rows,'parent_api_eligible':True,'parent_expected':outcome,'reason':why,'abi_gate':'x86_64 Linux' if 'layout' in name or 'full_compile' in name else 'symbolic sizeof controls; growth test asserts actual initial physical capacity4'})
assert sum(r['planned_rows'] for r in roster)==107
write('roster.json',{'groups':10,'planned_rows_on_selected_abi':107,'predicted_parent_groups':{'pass':4,'fail':6},'qualification':'Source predictions only; no project execution by author. A failed group does not observe its later rows. Every group uses current parent APIs and pattern .. rather than proposed tuple arity. Outside measured ABI the two gated groups are absent, leaving8 groups/100 planned rows.','tests':roster})
write('api.json',{
 'new_production_api':None,
 'natural_apis':['Parser::start','Parser::parse_context','Parser::emit_expr','Unit::expr','Unit::finish','driver::run','driver::enter','expressions::step','parser::push'],
 'fixture_payment':'paid_step prepays the same work1 as run immediately before calling the actual production step. It does not implement a continuation loop. All owners obtained by real existing Base/NewHead/AssignmentHead/SequenceHead transitions; the spare-list row retains the natural owner payload and prepays existing push before fixture pop.',
 'reset_scope':'Only isolated quota fixture setup resets compile_budget steps/allocated. It does not reset live Runtime or grant fallback budget. The full compile preservation test uses the original ledger without reset.',
 'privacy':'No Unit.expressions access, no new getter/accessor, no implementation clone. Record-page setup uses source-derived known base+literal count2 plus126 paid emits.',
 'token_domain':'Number checked with TokenKind::Number guard; is only used for punctuation/words. Offsets use actual source offsets.',
 'production_registration':'Only cfg(test) child module addition after existing argument_in_context_tests in expressions.rs. Root imports before production; production must bind that registered form.',
 'old_controls':'AU Dynamic success/error handoff, existing driver continuation cap/growth, existing records cap and AU full compile tariffs stay untouched.'})
write('ledger.json',{
 'symbols':{'K':'size_of::<driver::Kind>()','I':'size_of::<ExprId>()','E':'size_of::<Expr>()','R':'32+4*K','G':'32+8*K','P':'32+128*E','L1':'32+I','L2':'32+2*I'},
 'selected_zero_extra_scalar_fee':'Existing bounded step/cleanup convention covers saved_in capture/enable/restore; all Sequence steps and actual allocation rules retained.',
 'warm_close':{'computed':{'work':2,'heap':0,'stages':['dispatch1','Member append1']},'new_computed':{'work':3,'heap':0,'stages':['dispatch1','Member append1','New append1']},'cuts':['work1 refuses Member for both','new work2 refuses New after Member','exact2/3 completes'], 'flag':'Restored after ] before either append; ] consumed even when append refuses.'},
 'page_close':{'setup':'base+single literal2; 126 further paid emits fill original logical128-record page. Existing directory has capacity>=4 so no second-page directory growth. No sibling-private counts read.','work_exact':'3+construct','heap_exact':'P','heap_one_short':'P-1 with work3; page allocation raises allocated to MAX_HEAP+1 before any New append','stages':['dispatch1','Member append1','new page1','New append1 only on construct success']},
 'conditional':{'entry':'paid AssignmentHead dispatch recognizes ? then enables +In, child Assignment','colon_resume':{'work':1,'heap':0,'effect':'consume colon, restore saved flag, return ConditionalNo + Assignment'},'false_child':{'work':3,'heap':'R','stages':['initial enter1','terminated literal Assignment1','literal append1']},'false_child_refusal':'work0 before initial enter, offset3 and restored flag retained','final_conditional':{'work':2,'heap':0,'stages':['dispatch1','Conditional append1']}},
 'sequence':{'no_comma_head':{'work':1,'heap':0,'effect':'return same first ExprId'},'cold_head':{'work':3,'heap':'L1','stages':['dispatch1','push1','cold growth1'],'work_cut':2,'heap_cut':'L1-1'},'second_final':{'work':'3+2*grows','heap':'L2 if grows else0','stages':['dispatch1','push1','growth2 only when physical len1==capacity1','Sequence append1'],'work_cut':'exact-1 refuses final Sequence record after list append','physical':'Natural first list has len1/capacity>=1. Compute grows from actual physical capacity, without imposing capacity1. Spare fixture pays existing push then pops second before reset; capacity>len verified.'}},
 'run':{'physical_precondition':'Real driver::enter on a fresh vector asserts len1/capacity4 before the frozen whole-run growth cuts. Numeric heap formulas remain sizeof-dependent; no new cap fixture.','simple_source':'[0]','simple_setup':'real paid base emit and PostfixResume root; warm first record page; reset occurs only after setup','simple_parent_work':6,'simple_candidate_work':8,'simple_heap':'R','simple_stages':['enter1','Postfix1','Sequence1','Assignment1','literal append1','SequenceHead1','Computed1','Member append1'],'simple_one_short':{'work':7,'pos':3,'effect':'Member work refusal after ] restoration'},'prefix_rows':[{'work':0,'heap':'R','pos':0,'allocated':'MAX_HEAP-R'},{'work':1,'heap':'R','pos':0,'allocated':'MAX_HEAP'},{'work':2,'heap':'R','pos':1,'allocated':'MAX_HEAP'},{'work':1,'heap':'R-1','pos':0,'allocated':'MAX_HEAP+1'}],'growth_source':'[!k]','growth_stages':['initial enter1','Postfix1 pushes Computed','Sequence1 pushes SequenceHead','Assignment1 pushes AssignmentHead','Binary1 pushes BinaryHead','enter Unary sees len4/cap4 and pays growth5 then G'],'growth_work_before_heap_refusal':10,'growth_position':{'token':'!','offset':1},'growth_rows':[{'work':9,'heap':'R+G','remaining':0,'allocated':'MAX_HEAP-G'},{'work':'MAX_STEPS','heap':'R','remaining':'MAX_STEPS-10','allocated':'MAX_HEAP+G'},{'work':'MAX_STEPS','heap':'R+G-1','remaining':'MAX_STEPS-10','allocated':'MAX_HEAP+1'}],'qualification':'Existing run-Err cleanup restores run-entry allow_in at every refusal. No universal computed +2 or unchanged-heap claim: extra pending head changes growth timing. Parent reaches Unary and consumes ! before its corresponding growth refusal.'},
 'layout':{'abi':'x86_64 Linux only','Frame':[72,8],'Kind':[112,8],'Transition':[224,8],'Output':[88,8],'initial_buffer':480,'kind_heap_ceiling':74898},
 'complete_compile_preservation':[{'source':'true?1:2','work':43,'heap':23716},{'source':'f(true?1:2)','work':69,'heap':25726},{'source':'for(var x=true?1:2;false;){}','work':76,'heap':24265}],
 'complete_compile_qualification':'Both strict modes, exact parent measurements through Unit::finish; x86_64 Linux only. The seven observed computed source totals remain diagnostics, not new fixed candidate oracles.',
 'refusal_semantics':'regexp::Budget.work saturates remaining steps to0 on short work; compile_allocate retains cumulative over-limit attempted bytes. No rollback or fresh cleanup budget.'})
(D/'notes.txt').write_text('External prospective private test freeze, no production and no execution.\n\nAll10 groups compile against the published parent APIs; predicted4 preservation passes and6 intended failures, not observed results. Two actual-shape/full-compile groups are x86_64 Linux only. There are107 planned rows on that ABI; a failing group does not reach later rows. The exact rule for an initial four-slot physical continuation vector is asserted before the isolated growth test. Existing cap and Dynamic handoff groups remain unchanged; no new large cap-filling fixture is authored.\n\nAll private source joins are from published parent inventory or retained published snapshots. Temporary probe registrations are not used. Root public registration in script.rs is outside the sole private registration path. No historical test migrations are needed for this selected scope.\n\nThe parent conditional totals are measured; the computed run and staged Sequence totals are source-derived. No candidate execution influenced them. The ledger deliberately does not convert all computed full-compile rows by +2.\n')
refs=[AV/'parent-source.json',AV/'source-parent-public.json',AV/'root/selection-1.json',AV/'root/layout-observations.json',AV/'root/parent-tariff-observations.json',AV/'root/selection-parent-html-review.json',P/'private-outline-1/source-ready.json',P/'tests-public-1/source-ready-published.json',P/'tests-public-1/script-review.json']
refs=[x for x in refs if x.exists()]
hold={'status':'frozen_source_only_before_candidate_production','base':parent['base'],'scope':'Ten bounded private groups, existing parent APIs, no production or old migrations.','test_module':binding(raw),'registration':{'relative':rel,'before':binding(D/'before'/rel),'raw':binding(D/'registration'/rel),'patch':binding(p)},'contracts':[binding(D/x) for x in ['api.json','ledger.json','roster.json','notes.txt']],'sources':sources,'evidence':[binding(x) for x in refs],'execution':'No Rust/compiler/formatter/browser/project execution by author. Root owns import and baseline.'}
# p was last bound to registration patch above; retain explicit path regardless of future locals.
hold['registration']['patch']=binding(D/'diffs'/f'{rel}.patch')
write('source-ready.json',hold)
print(json.dumps(binding(D/'source-ready.json')))
