import pathlib,json,hashlib
D=pathlib.Path('/tmp/eris-expression-in-1/production-parser-1')
def replace_once(text,a,b):
 assert text.count(a)==1,(a,text.count(a));return text.replace(a,b,1)
def binding(p):
 p=pathlib.Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rel='src/script/parser/driver/expressions.rs'
before=(D/'before'/rel).read_text();raw=(D/'raw'/rel).read_text();t=raw
for a,b in [('ConditionalYes(ExprId, bool),','ConditionalYes(ExprId),'),('Computed(Postfix, bool),','Computed(Postfix),'),('NewComputed(NewState, bool),','NewComputed(NewState),')]:t=replace_once(t,a,b)
t=replace_once(t,'''                let saved_in = p.allow_in;
                p.allow_in = true;
                child(Frame::ConditionalYes(left, saved_in), Frame::Assignment)''','''                child(Frame::ConditionalYes(left), Frame::Assignment)''')
t=replace_once(t,'''        Frame::ConditionalYes(left, saved_in) => {
            let yes = expression(output);
            p.expect(":")?;
            p.allow_in = saved_in;''','''        Frame::ConditionalYes(left) => {
            let yes = expression(output);
            p.expect(":")?;''')
for variant,name in [('Computed','property'),('NewComputed','key')]:
 t=replace_once(t,f'''        Frame::{variant}(mut state, saved_in) => {{
            let {name} = expression(output);
            p.expect("]")?;
            p.allow_in = saved_in;''',f'''        Frame::{variant}(mut state) => {{
            let {name} = expression(output);
            p.expect("]")?;''')
 t=replace_once(t,f'''            let saved_in = p.allow_in;
            p.allow_in = true;
            return child(Frame::{variant}(state, saved_in), Frame::Sequence);''',f'''            return child(Frame::{variant}(state), Frame::Assignment);''')
assert t==before
registration=pathlib.Path('/tmp/eris-expression-in-1/tests-private-1/registration')/rel
assert before==registration.read_text()
active={'before':binding(D/'before'/rel),'raw':binding(D/'raw'/rel),'exact_selected_inverse':True,'registration_before_exact':binding(registration),'selected_replacements':9}
rel='src/script/parser_legacy.rs';before=(D/'before'/rel).read_text();t=(D/'raw'/rel).read_text()
for indent,name,child,delim in [(12,'yes','expression',':'),(16,'property','sequence',']'),(16,'key','sequence',']')]:
 sp=' '*indent
 a=f'''{sp}let saved_in = self.allow_in;
{sp}self.allow_in = true;
{sp}let result: Result<Expr> = (|| {{
{sp}    let {name} = self.{child}()?;
{sp}    self.expect("{delim}")?;
{sp}    Ok({name})
{sp}}})();
{sp}self.allow_in = saved_in;
{sp}let {name} = result?;'''
 b=f'''{sp}let {name} = self.expression()?;
{sp}self.expect("{delim}")?;'''
 t=replace_once(t,a,b)
assert t==before
parent=json.loads(pathlib.Path('/tmp/eris-expression-in-1/parent-source.json').read_text())
assert hashlib.sha256(before.encode()).hexdigest()==parent['source_sha256'][rel]
legacy={'before':binding(D/'before'/rel),'raw':binding(D/'raw'/rel),'exact_selected_inverse':True,'parent_before_exact':True,'selected_replacements':3}
print(json.dumps({'active':active,'legacy':legacy},indent=2))
