from pathlib import Path
import hashlib,json,difflib,re
B=Path('/tmp/eris-expression-in-1');D=B/'production-parser-1';W=B/'worktree'
assert not (D/'source-ready.json').exists()
def h(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':h(p)}
def write(name,obj):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(obj if isinstance(obj,str) else json.dumps(obj,indent=2)+'\n');return p
parent=json.loads((B/'source-parent-private.json').read_text())
rels=['src/script/parser/driver/expressions.rs','src/script/parser_legacy.rs']
rows=[]
for r in rels:
 before=D/'before'/r;raw=D/'raw'/r
 assert h(before)==parent['source_sha256'][r]==h(W/r),r
 a=before.read_text();z=raw.read_text()
 # No explicit existing charge expression is replaced, added or removed.
 pattern=r'\b(?:compile_budget|budget)\.(?:work|allocate|heap|reserve)\([^\n]*'
 assert re.findall(pattern,a)==re.findall(pattern,z)
 patch=write('diffs/'+r.replace('/','__')+'.patch',''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='a/'+r,tofile='b/'+r)))
 rows.append({'relative':r,'before':ref(before),'raw':ref(raw),'diff':ref(patch)})
e=(D/'raw'/rels[0]).read_text();l=(D/'raw'/rels[1]).read_text()
assert e.count('mod argument_in_context_tests;')==e.count('mod expression_in_context_tests;')==1
assert h(D/'before'/rels[0])==h(B/'tests-private-1/registration'/rels[0])
def enum(text,start):
 at=text.index(start);end=text.index('\n}',at)+2;return text[at:end]
actual=enum(e,'pub(super) enum Frame {').replace('pub(super) enum Frame {','enum ProposedExpressionFrame {',1)
mirror=(B/'layout-probe-1/raw/src/script/parser/driver/expressions/expression_in_layout_probe.rs').read_text()
assert actual==enum(mirror,'enum ProposedExpressionFrame {')
for parent_frame in ['Computed','NewComputed']:
 assert f'return child(Frame::{parent_frame}(state, saved_in), Frame::Sequence);' in e
assert 'p.expect(":")?;\n            p.allow_in = saved_in;\n            child(Frame::ConditionalNo(left, yes), Frame::Assignment)' in e
for name in ['property','key']:
 assert 'p.expect("]")?;\n            p.allow_in = saved_in;\n            state.value = p.emit_expr(Expr::Member(state.value, '+name+'))?;' in e
assert l.count('let result: Result<Expr> = (|| {')-(D/'before'/rels[1]).read_text().count('let result: Result<Expr> = (|| {')==3
for name in ['yes','property','key']:
 assert 'self.allow_in = saved_in;\n'+('            ' if name=='yes' else '                ')+f'let {name} = result?;' in l
assert 'let yes = result?;\n            let no = self.expression()?;' in l
notes=write('notes.json',{
 'active':'Computed/NewComputed/ConditionalYes append one saved bool each, exactly matching the selected complete prospective Frame. Computed entries consume [ then enable +In and schedule Sequence. Both bracket resumes consume ] then restore before Member emission. Conditional ? enables only its Assignment middle; colon resume restores before false Assignment scheduling.',
 'legacy':'Three local Result<Expr> closures cover sequence()+] for the two bracket paths and expression()+: for the middle arm. Restore saved flag before propagating result. False arm and Member construction remain outside the temporary context.',
 'error_contract':'Existing AU driver::run Err restoration supplies active failure cleanup before owner close, including delimiter or child-storage refusal. This hold does not edit driver.rs or claim panic/general parser rollback. Successful Dynamic handoff and spent budgets remain unchanged.',
 'resource':'Zero additional fixed bool/cleanup debit per root selection. Existing Sequence dispatch/list/record charges stay authoritative. One-operand keys add two dispatches if continuation growth is unchanged; the extra pending head can cause existing growth/cap refusal. No universal +2 or unchanged heap claim.',
 'preservation':'No Runtime/AST/visitor/cap/startup change, no old-test migration, no object-computed-key or conditional-middle comma widening. All AU argument paths and helpers remain outside the diff.',
 'checks':['Both before snapshots equal the current registered worktree and source-parent-private inventory.','Frame bytes exactly equal the selected proposed mirror after enum name/visibility normalization.','Both existing test registrations retained; no test bodies included or changed.','Restore-before-publication sequences and all three legacy restore-before-propagate scopes checked.','Explicit existing charge-call text is unchanged.'],
 'validation':'Source/hash/diff inspection only. No Rust/compiler/formatter/test/browser/git execution or live source mutation; root owns validation and final actual layout observation.'
})
manifest={
 'status':'source-ready','schema':'eris-expression-in-parser-production-v1','base':parent['base'],
 'selection':ref(B/'root/selection-1.json'),
 'before_inventory':ref(B/'source-parent-private.json'),
 'private_tests':ref(B/'tests-private-1/source-ready.json'),
 'public_tests':ref(B/'tests-public-1/source-ready-published.json'),
 'prospective_layout':ref(B/'root/layout-observations.json'),
 'paths':rows,'support':[ref(notes),ref(D/'seal.py')],
 'integration':'Replace exactly the two raw relative paths after before-hash verification. The expression file retains both selected private test registrations. Import no other source from this hold; no driver edit is needed.',
 'old_test_migrations':[],'test_body_changes':[],'project_execution':False,'live_edits':False
}
p=write('source-ready.json',manifest);print(json.dumps(ref(p),indent=2))
