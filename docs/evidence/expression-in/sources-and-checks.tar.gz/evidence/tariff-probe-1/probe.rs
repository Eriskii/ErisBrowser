//! Published-parent compile observations; no candidate execution or counter reset.
use super::*;

#[test]
fn parent_expression_in_compile_tariffs() {
    for (id, source) in [
        ("computed_literal", "o[0]"),
        ("computed_identifier", "o[k]"),
        ("computed_call", "f()[0]"),
        ("computed_new", "new C[0]"),
        ("computed_new_arguments", "new C[k](1)"),
        ("conditional", "true?1:2"),
        ("conditional_argument", "f(true?1:2)"),
        ("computed_for_in", "for(o[0] in {a:1}){}"),
        ("conditional_for", "for(var x=true?1:2;false;){}"),
        ("computed_for", "for(var x=o[0];false;){}"),
    ] {
        for strict in [false, true] {
            let parser = Parser::parse_context(source, false, strict).unwrap();
            assert!(parser.done());
            assert!(parser.allow_in);
            let mut ledger = parser.compile_budget;
            let _unit = parser.unit.finish(&mut ledger).unwrap();
            println!("EXPRESSION_IN_PARENT_TARIFF_V1 id={} strict={} work={} heap={}", id, strict, MAX_STEPS - ledger.steps, ledger.allocated);
        }
    }
}
