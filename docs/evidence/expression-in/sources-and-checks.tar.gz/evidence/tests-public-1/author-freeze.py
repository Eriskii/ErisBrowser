from pathlib import Path
import difflib
import hashlib
import json
import re

PLAN = Path('/tmp/eris-expression-in-followup-1')
HOLD = PLAN / 'tests-public-1'
AU = Path('/tmp/eris-call-argument-in-1')
WORKTREE = AU / 'worktree'
MODULE = 'src/script/expression_in_tests.rs'
REGISTRATION = '\n#[cfg(test)]\nmod expression_in_tests;\n'


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def write(path, text):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return binding(path)


def write_json(path, value):
    return write(path, json.dumps(value, indent=2) + '\n')


cases = json.loads((PLAN / 'cases-2.json').read_text())['cases']
assert len(cases) == 21
style_path = AU / 'tests-public-1/raw/src/script/call_argument_in_tests.rs'
style = style_path.read_text()
helpers = style[style.index('use super::*;'):style.index('\n#[test]')]
chunks = [
    '//! Computed Expression[+In] and conditional-middle Assignment[+In] controls.\n'
    '//! Reviewed literals frozen before follow-up production; existing APIs only.\n'
    + helpers
]
roster = []
for case in cases:
    ident = case['id']
    assert re.fullmatch('[a-z][a-z0-9_]*', ident)
    assert '"###' not in case['source']
    name = 'expression_in_' + ident
    positive = case['expected']['kind'] == 'String'
    call = 'succeeds' if positive else 'syntax_error'
    chunk = '\n#[test]\nfn ' + name + '() {\n    ' + call + '(\n'
    chunk += '        ' + json.dumps(ident) + ',\n'
    chunk += '        r###"' + case['source'] + '"###,\n'
    if positive:
        chunk += '        ' + json.dumps(case['expected']['value']) + ',\n'
    chunk += '    );\n}\n'
    chunks.append(chunk)
    gap = case['source_predicted_current'].startswith('missing-')
    roster.append({
        'test': name, 'case_id': ident, 'source': case['source'],
        'expected': case['expected'], 'modes': [False, True],
        'expected_parent_group': 'fail' if gap else 'pass',
        'first_parent_failure': 'First sloppy Runtime parse; later assertions and strict row unreached.' if gap else None,
        'reason': case['reason'],
    })
module_text = ''.join(chunks)
raw = write(HOLD / 'raw' / MODULE, module_text)

# Inert literal extraction only: no parser, compiler or engine is invoked.
extracted = re.findall(
    r'#\[test\]\nfn (\w+)\(\) \{\n    (succeeds|syntax_error)\(\n'
    r'        "([a-z0-9_]+)",\n        r###"(.*?)"###,\n'
    r'(?:        "([^"\n]*)",\n)?    \);\n\}',
    module_text, re.S,
)
assert len(extracted) == 21
for case, row in zip(cases, extracted):
    name, call, ident, source, expected = row
    assert name == 'expression_in_' + case['id']
    assert ident == case['id'] and source == case['source']
    if case['expected']['kind'] == 'String':
        assert call == 'succeeds' and expected == case['expected']['value']
    else:
        assert call == 'syntax_error' and not expected
assert module_text[module_text.index('use super::*;'):module_text.index('\n#[test]')] == helpers

inventory_path = AU / 'source2.json'
inventory = json.loads(inventory_path.read_text())['source_sha256']
before_data = (WORKTREE / 'src/script.rs').read_bytes()
assert hashlib.sha256(before_data).hexdigest() == inventory['src/script.rs']
assert b'mod expression_in_tests;' not in before_data
before = write(HOLD / 'before/src/script.rs', before_data.decode())
after_text = before_data.decode() + REGISTRATION
after = write(HOLD / 'registration-after/src/script.rs', after_text)
registration = write(HOLD / 'registration.txt', REGISTRATION)
patch = write(HOLD / 'registration.patch', ''.join(difflib.unified_diff(
    before_data.decode().splitlines(True), after_text.splitlines(True),
    fromfile='a/src/script.rs', tofile='b/src/script.rs',
)))
assert after_text.removesuffix(REGISTRATION) == before_data.decode()

snapshots = []
for relative in [
    'src/script.rs', 'src/script/parser.rs', 'src/script/parser_legacy.rs',
    'src/script/code.rs', 'src/script/parser/driver/expressions.rs',
    'src/script/parser/driver.rs', 'src/script/call_argument_in_tests.rs',
]:
    source = WORKTREE / relative
    data = source.read_bytes()
    assert hashlib.sha256(data).hexdigest() == inventory[relative]
    target = HOLD / 'source-inputs' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    snapshots.append({'relative': relative, 'snapshot': binding(target),
                      'au_source2_sha256': inventory[relative]})

source_bindings = write_json(HOLD / 'source-bindings.json', {
    'published_base_commit': None,
    'base_status': 'Provisional AU source2; await AU publication and an additive base-binding receipt before final import.',
    'au_inventory': binding(inventory_path),
    'cases': binding(PLAN / 'cases-2.json'),
    'literal_peer': binding(PLAN / 'script-literal-review.json'),
    'harness_origin': binding(style_path),
    'helper_text_sha256': hashlib.sha256(helpers.encode()).hexdigest(),
    'sources': snapshots,
})
oracle = write_json(HOLD / 'oracle.json', {
    'groups': 21, 'planned_mode_rows': 42,
    'positive_groups': 16, 'negative_groups': 5,
    'expected_parent_groups': {'pass': 7, 'fail': 14},
    'roster': roster,
    'order': 'Runtime result/error first, then cleanup and active/legacy canonical comparison for successes. Negatives require Runtime, active and legacy SyntaxError, is_parse_error and not Unsupported.',
    'isolation': 'Every mode uses a fresh Runtime and Document. No budget resets, Runtime reuse, skips or expected values learned from candidate output.',
    'reachability': 'These are source predictions. Failing Runtime-first groups stop at the first sloppy row; strict and canonical checks are then unreached. Successful parent controls must complete both modes.',
    'no_execution': True,
})
checks = write_json(HOLD / 'literal-checks.json', {
    'groups_extracted': len(extracted), 'sources_exact': True,
    'expected_values_exact': True, 'case_order_exact': True,
    'helpers_byte_identical_to_bound_AU_style': True,
    'registration_inverse_exact': True, 'parent_source_joins': len(snapshots),
    'method': 'Independent literal extraction, hashing and diff only; no project import or execution.',
})
instructions = write_json(HOLD / 'import-instructions.json', {
    'base_refresh_required': 'After AU publication, retain this provisional hold and add a receipt binding its snapshots/registration before bytes to the published commit and final source inventory. Do not change the module or expected literals.',
    'new_module': {'relative': MODULE, 'raw': raw},
    'registration': {'relative': 'src/script.rs', 'before': before,
                     'after': after, 'exact_insertion': registration, 'patch': patch},
    'registration_instruction': 'Append registration.txt exactly once after verifying the before hash. The full before/after and patch encode this one cfg(test) declaration.',
    'production_changes': [], 'historical_test_migrations': [],
    'owner': 'Root owns live import, formatting, compiler and all baseline/candidate execution.',
})
files = [raw, before, after, registration, patch, source_bindings, oracle, checks, instructions]
hold = write_json(HOLD / 'source-ready.json', {
    'schema': 'eris-expression-in-public-tests-before-v1',
    'status': 'tests-frozen-for-source-peer-provisional-AU-base',
    'published_base_commit': None,
    'base_refresh_required': True,
    'groups': 21, 'planned_modes': 42,
    'expected_parent_groups': {'pass': 7, 'fail': 14},
    'files': files,
    'scope': 'One new public test module and one cfg(test) registration. Exact reviewed sources and literals; existing Runtime and canonical parser APIs only.',
    'fee_decisions': [], 'production_authored': False,
    'live_edits': False, 'project_execution': False,
    'authoring_helper': binding(__file__),
})
print(json.dumps(hold))
