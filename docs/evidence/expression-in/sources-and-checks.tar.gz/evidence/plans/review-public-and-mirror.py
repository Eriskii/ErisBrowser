from pathlib import Path
import hashlib,json,re,difflib

base=Path('/tmp/eris-expression-in-followup-1')
worktree=Path('/tmp/eris-expression-in-1/worktree')
def read(p):return json.loads(p.read_text())
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(obj, collected):
    if isinstance(obj,dict):
        if {'path','bytes','sha256'}<=obj.keys():
            b=bind(Path(obj['path']));assert all(b[k]==obj[k] for k in b);collected.append(b)
        else:
            for v in obj.values():verify(v,collected)
    elif isinstance(obj,list):
        for v in obj:verify(v,collected)
def patch_exact(path,before,after):
    patch=path.read_text();lines=patch.splitlines()
    assert patch==''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=lines[0][4:],tofile=lines[1][4:]))

parent_path=Path('/tmp/eris-expression-in-1/parent-source.json')
parent=read(parent_path)
p=base/'tests-public-1';manifest=read(p/'source-ready-published.json'); bindings=[];verify(manifest,bindings)
cases=read(base/'cases-2.json')['cases'];oracle=read(p/'oracle.json')
raw=(p/'raw/src/script/expression_in_tests.rs').read_text()
functions=re.findall(r'#\[test\]\nfn (\w+)\(\) \{\n(.*?)\n\}',raw,re.S)
assert len(functions)==21==len(cases)==len(oracle['roster'])
for (name,body),case,row in zip(functions,cases,oracle['roster']):
    parsed=re.fullmatch(r'    (succeeds|syntax_error)\(\s*"([^"]+)",\s*r###"(.*?)"###,\s*(?:"([^"]*)",\s*)?\);',body,re.S)
    assert parsed,name
    helper,identifier,source,value=parsed.groups()
    assert identifier==case['id']==row['case_id']
    assert name=='expression_in_'+identifier==row['test']
    assert source==case['source']==row['source']
    expected={'kind':'SyntaxError','unsupported':False} if helper=='syntax_error' else {'kind':'String','value':value}
    assert expected==case['expected']==row['expected']
    assert row['modes']==[False,True]
assert sum(c['expected']['kind']=='SyntaxError' for c in cases)==5
assert sum(r['expected_parent_group']=='pass' for r in oracle['roster'])==7
assert sum(r['expected_parent_group']=='fail' for r in oracle['roster'])==14
helpers=raw[raw.index('use super::*;'):raw.index('\n#[test]')]
orig=Path('/tmp/eris-call-argument-in-1/tests-public-1/raw/src/script/call_argument_in_tests.rs').read_text()
assert helpers==orig[orig.index('use super::*;'):orig.index('\n#[test]')]
provenance=read(p/'source-bindings.json')
assert hashlib.sha256(helpers.encode()).hexdigest()==provenance['helper_text_sha256']
source_join=[]
for row in provenance['sources']:
    assert bind(Path(row['snapshot']['path']))['sha256']==parent['source_sha256'][row['relative']]
    source_join.append({'relative':row['relative'],'sha256':parent['source_sha256'][row['relative']]})
before=(p/'before/src/script.rs').read_text();after=(p/'registration-after/src/script.rs').read_text();registration=(p/'registration.txt').read_text()
assert registration=='\n#[cfg(test)]\nmod expression_in_tests;\n'
assert after==before+registration
assert before.encode()==(worktree/'src/script.rs').read_bytes()
patch_exact(p/'registration.patch',before,after)
review={
    'status':'clear_source_only',
    'hold':bind(p/'source-ready-published.json'),
    'literal_peer':bind(base/'script-literal-review.json'),
    'checks':{'all_manifest_bindings':len(bindings),'literal_sources_and_results_exact':21,'mode_rows':42,'success_groups':16,'syntax_nonunsupported_groups':5,'complete_AU_helper_block_byte_exact':True,'registration_append_and_inverse_exact':True,'current_published_worktree_source_joins':source_join},
    'api_review':'Fresh Runtime::try_new and Document per mode; existing execute/execute_strict, public Parser context and cfg(test) code canonical/compile APIs. Runtime private cleanup fields are visible in the script descendant module. Syntax paths require actual SyntaxError, parse classification and not Unsupported. No new production signature or private field access outside visibility.',
    'parent_eligibility':'All21 groups compile using existing AU parent APIs. Seven complete preservation groups are source-predicted passes, fourteen gap groups first fail at sloppy Runtime parse; later strict/canonical assertions are not claimed reached. No execution by this reviewer.',
    'base_qualification':'Published AU57d0a47d is bound by the additive refresh and root parent-source inventory. All seven held public snapshots match that inventory. The temporary layout-probe registration in live expressions.rs is deliberately not used as the parent binding.',
    'parent_inventory':bind(parent_path),
    'base_refresh':bind(base/'published-base-1/source-ready.json'),
    'findings':[],'production_authored':False,'project_execution':False,'live_edits':False,
    'review_helper':bind(base/'review-public-and-mirror.py')
}
(p/'script-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(p/'script-review.json')))

p=base/'layout-probe-1';manifest=read(p/'source-ready.json');bindings=[];verify(manifest,bindings)
probe=Path(manifest['module']['raw']['path']).read_text()
expression=(p/'before/src/script/parser/driver/expressions.rs').read_text()
driver=(p/'before/src/script/parser/driver.rs').read_text()
def enum(text,name):
    return re.search(r'(?:pub\(super\) )?enum '+name+r' \{\n(.*?)\n\}',text,re.S).group(1)
actual=enum(expression,'Frame')
assert enum(probe,'BaselineExpressionFrame')==actual
proposed=actual.replace('ConditionalYes(ExprId),','ConditionalYes(ExprId, bool),').replace('Computed(Postfix),','Computed(Postfix, bool),').replace('NewComputed(NewState),','NewComputed(NewState, bool),')
assert enum(probe,'ProposedExpressionFrame')==proposed
for variant in ['Baseline','Proposed']:
    assert enum(probe,variant+'Kind')==enum(driver,'Kind').replace('expressions::Frame',variant+'ExpressionFrame')
    assert enum(probe,variant+'Transition')==re.sub(r'\bKind\b',variant+'Kind',enum(driver,'Transition'))
assert probe.count('    same::<')==3 and probe.count('    pair::<')==15
assert 'same::<Frame, BaselineExpressionFrame>()' in probe and 'same::<Kind, BaselineKind>()' in probe and 'same::<Transition, BaselineTransition>()' in probe
assert '4 * size_of::<ProposedKind>() + 32' in probe and 'MAX_HEAP / size_of::<ProposedKind>()' in probe
assert '#[repr' not in probe
source_map=read(p/'source-map.json')
for row in source_map['files']:
    assert bind(Path(row['snapshot']['path']))['sha256']==parent['source_sha256'][row['relative']]
registration=manifest['registration']
before=Path(registration['before']['path']).read_text();after=Path(registration['raw']['path']).read_text()
extra='\n#[cfg(test)]\nmod expression_in_layout_probe;\n'
assert after.count(extra)==1 and after.replace(extra,'',1)==before
patch_exact(Path(registration['diff']['path']),before,after)
review={
    'status':'clear_source_only','hold':bind(p/'source-ready.json'),
    'verified_bindings':len(bindings),
    'checks':['Complete baseline Frame/Kind/Transition bodies match source with type-name substitutions only.','Proposed Frame adds only the three selected owner bools; all AU argument flags and variant order stay exact.','Kind/Transition use those complete enums; all neighboring payload types are actual enclosing types. No stripped substitute or repr is introduced.','Three baseline equality assertions, fifteen observation pairs and two derived formulas have no guessed proposed value or equality assumption.','All nine source snapshots match the published-parent inventory; sole cfg(test) registration reverses exactly.'],
    'parent_inventory':bind(parent_path),
    'published_refresh':bind(p/'published-base-refresh.json'),
    'eligibility':'Existing private types are accessible from the child expressions module. Only test observation code; root must import/run/remove the probe and bind actual toolchain/ABI measurements. No final layout or fee claim.',
    'findings':[],'project_execution':False,'live_edits':False,
    'review_helper':bind(base/'review-public-and-mirror.py')
}
(p/'script-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(p/'script-review.json')))
