from pathlib import Path
import hashlib, json

folder=Path('/tmp/eris-expression-in-followup-1')
def binding(path):
    data=Path(path).read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
first=json.loads((folder/'cases.json').read_text())
selected=json.loads((folder/'cases-2.json').read_text())
assert len(first['cases'])==15 and len(selected['cases'])==21
assert selected['cases'][:15]==first['cases']
assert binding(folder/'cases-2.json')['sha256']=='8c616b7f442b16a5b0390108f31440012787759c0f253483e4bf371f38945192'
expected=['T','C','N','V','a','T','7','T','T',None,None,None,None,'TTT','T','KV','BLKC','LKANV','a',None,'1V']
derivations=[
    'The present x property makes the computed key true; table.true is T.',
    'f returns the table whose true property is C; the computed key is true.',
    'The computed constructor is table.true; its body assigns instance.v=N.',
    'The inner true key yields k; the outer k lookup yields V.',
    'One enumeration key a is assigned to target.true; the body reads that same slot.',
    'The selected true arm evaluates x in o to true, yielding T.',
    'The middle arm still must parse, but the false branch evaluates to number7, then string7.',
    'Right association places false?0:(x in o) in the outer true arm. The inner false arm inherits +In and yields true, hence T.',
    'The outer middle context and nested computed context compose; table.true yields T. This is a composition control, not an isolated proof of each fix.',
    'After bracket close, outer in begins a for-in header; its semicolon tail is invalid.',
    'The outer false arm retains NoIn. It cannot absorb the following in into a classic initializer; the resulting header is invalid.',
    'The conditional test retains NoIn; the following in cannot become a classic-initializer relational operator and the header is invalid.',
    'A conditional middle AssignmentExpression cannot contain an unparenthesized top-level comma.',
    'Existing parenthesized in is valid in all three positions; each selected result appends T.',
    'Ordinary outer context is +In, so the false arm yields true and T.',
    'key appends K; the final comma operand is true and selects V: KV.',
    'Base call appends B, first key operand L, last key call K; selected value C gives BLKC.',
    'Key operands append L then K; constructor argument appends A; constructor body appends N; instance value V gives LKANV.',
    'The last key operand is true; the outer enumeration key a is stored and read from target.true.',
    'A comma operator requires another AssignmentExpression; a closing bracket immediately afterward is invalid.',
    'First key operand assigns n=1, final operand selects k and V; string addition yields 1V.',
]
rows=[]
for case, value, derivation in zip(selected['cases'],expected,derivations):
    want={'kind':'SyntaxError','unsupported':False} if value is None else {'kind':'String','value':value}
    assert case['expected']==want
    rows.append({'id':case['id'],'expected':want,'derivation':derivation,'status':'clear_source_only'})
review={
    'status':'clear_source_only',
    'scope':'Twenty-one proposed literal cases only, including the exact retained first fifteen and six additive computed-sequence cases. No implementation or resource-fee approval.',
    'bindings':[binding(folder/'cases.json'),binding(folder/'cases-2.json')],
    'original_prefix_exact':True,
    'primary_sources':[
        {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#prod-MemberExpression','read_date':'2026-10-15','supports':'MemberExpression and CallExpression computed brackets take Expression with +In.'},
        {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#prod-ConditionalExpression','read_date':'2026-10-15','supports':'The conditional middle takes AssignmentExpression with +In; its test and false arm inherit In. Runtime evaluates only the selected arm.'},
    ],
    'cases':rows,
    'source_findings':[],
    'qualification':'Strict/sloppy outcomes are manually derived language expectations, not parser or engine observations. Source-predicted current outcomes remain unexecuted predictions. The corpus is still a proposal, not frozen executable tests; this receipt does not establish layout, tariffs or final implementation behavior.',
    'au_scope':'No AU file edits; current AU call/new arguments remain a separate checkpoint.',
    'execution':False,
    'live_edits':False,
    'authoring_helper':binding(folder/'write-script-literal-review.py'),
}
(folder/'script-literal-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(binding(folder/'script-literal-review.json')))
