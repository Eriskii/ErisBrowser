from pathlib import Path
import json, hashlib, difflib
P=Path('/tmp/eris-shared-job-keys-plan-1')
A=Path('/tmp/eris-shared-job-keys-1')
W=A/'worktree'
D=A/'production-1'

def binding(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def write(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f: f.write(data if isinstance(data,bytes) else data.encode())
def js(path,data): write(path,json.dumps(data,indent=2)+'\n')
def replace_once(text,before,after):
    assert text.count(before)==1, before[:100]
    return text.replace(before,after,1)

def verify(item):
    assert binding(Path(item['path']))==item, item['path']
hold=json.loads((P/'tests-before/source-ready.json').read_text())
for item in [hold['source_context'],*hold['files'],hold['migrations']]: verify(item)
peer=json.loads((P/'tests-before/html-review.json').read_text())
assert peer['status']=='clear_source_only' and not peer['findings']
verify(peer['hold'])
plan={'status':'selected_tests_API_ledger_peer_clear_before_production','parent':hold['published_parent'],
      'selected_tests':binding(P/'tests-before/source-ready.json'),
      'final_peer':binding(P/'tests-before/html-review.json'),
      'prior_API_peer':binding(P/'tests-before/html-api-review.json'),
      'migrations':binding(P/'migrations-before-1/source-ready.json'),
      'source_context':binding(P/'source-context.json'),
      'scope':'Share only two immutable job metadata keys; unchanged caps, fields, identities, public behavior and standalone installer cuts. No finally implementation.',
      'execution':'Source-only authoring and peer. Actual parent baseline is root-owned and bound separately in production receipt.'}
js(P/'source-ready.json',plan)

raw={}
p='src/script/microtasks.rs'; text=(W/p).read_text()
text=replace_once(text,'''    pub(super) fn install_microtask_intrinsic(&mut self) -> Result<()> {
        let properties =''','''    pub(super) fn install_microtask_intrinsic(&mut self) -> Result<[JsString; 2]> {
        // Retained handles may be dropped by any later producer/consumer error.
        self.work(2)?;
        let properties =''')
text=replace_once(text,'''        self.dom_proto_named(
            properties,
            "length",
            Property::data(Value::Number(1.0), false, false, true),
        )?;
        self.dom_proto_named(
            properties,
            "name",
            Property::data(Value::String(display), false, false, true),
        )?;''','''        let length_key = self.dom_proto_text("length")?;
        self.work(1)?;
        self.dom_proto_property(
            properties,
            length_key.clone().into(),
            Property::data(Value::Number(1.0), false, false, true),
        )?;
        let name_key = self.dom_proto_text("name")?;
        self.work(1)?;
        self.dom_proto_property(
            properties,
            name_key.clone().into(),
            Property::data(Value::String(display), false, false, true),
        )?;''')
text=replace_once(text,'''        self.next_global_order = next_order;
        Ok(())
    }

    pub fn microtasks_suspended''','''        self.next_global_order = next_order;
        Ok([length_key, name_key])
    }

    pub fn microtasks_suspended''')
raw[p]=text.encode()

p='src/script/promises/install.rs'; text=(W/p).read_text()
text=replace_once(text,'// These two immutable-key clones were prepaid by install_promise_intrinsics.','// These two immutable-key clones were prepaid by the installer body.')
text=replace_once(text,'''    pub(in crate::script) fn install_promise_intrinsics(&mut self) -> Result<()> {
        // Five empty arena guards, absent-intrinsics guard, final publication,
        // and ten temporary literal-handle releases. No author calls occur.
        self.work(17)?;
        if !self.promises.promises.records.is_empty()''','''    #[cfg(test)]
    pub(in crate::script) fn install_promise_intrinsics(&mut self) -> Result<()> {
        // Preserve standalone guard-before-allocation ordering and all ten
        // temporary handle releases, including the two keys created here.
        self.work(17)?;
        self.check_promise_install_state()?;
        let keys = [self.dom_proto_text("length")?, self.dom_proto_text("name")?];
        self.install_promise_intrinsics_body(keys)
    }

    pub(in crate::script) fn install_promise_intrinsics_with_keys(
        &mut self,
        keys: [JsString; 2],
    ) -> Result<()> {
        // The producer prepaid both supplied handles' releases, including
        // refusal of this debit. Pay guards, publication and eight pool releases.
        self.work(15)?;
        self.check_promise_install_state()?;
        self.install_promise_intrinsics_body(keys)
    }

    fn check_promise_install_state(&self) -> Result<()> {
        if !self.promises.promises.records.is_empty()''')
text=replace_once(text,'''            return Err(ScriptError::resource("Promise state already initialized"));
        }
        let pool = [
            self.dom_proto_text("length")?,
            self.dom_proto_text("name")?,''','''            return Err(ScriptError::resource("Promise state already initialized"));
        }
        Ok(())
    }

    fn install_promise_intrinsics_body(&mut self, keys: [JsString; 2]) -> Result<()> {
        let [length, name] = keys;
        let pool = [
            length,
            name,''')
raw[p]=text.encode()

p='src/script.rs'; text=(W/p).read_text()
text=replace_once(text,'''        self.install_microtask_intrinsic()?;
        self.install_promise_intrinsics()''','''        let keys = self.install_microtask_intrinsic()?;
        self.install_promise_intrinsics_with_keys(keys)''')
raw[p]=text.encode()

p='src/script/promises.rs'; text=(W/p).read_text()
assert text.count('mod shared_key_identity_tests;')==1
text=replace_once(text,'mod install_tests;\n','mod install_tests;\n#[cfg(test)]\nmod shared_key_tests;\n')
raw[p]=text.encode()

migration=json.loads((P/'migrations-before-1/source-ready.json').read_text())
for row in migration['files']:
    verify(row['before']); verify(row['raw']); verify(row['diff'])
    assert (W/row['target']).read_bytes()==Path(row['before']['path']).read_bytes()
    raw[row['target']]=Path(row['raw']['path']).read_bytes()
for name in ['shared_key_tests.rs','shared_key_identity_tests.rs']:
    p='src/script/promises/'+name
    raw[p]=(P/'tests-before'/p).read_bytes()
rows=[]
for p,data in raw.items():
    before=(W/p).read_bytes() if (W/p).exists() else None
    if before is not None: write(D/'before'/p,before)
    write(D/'raw'/p,data)
    diff=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+p if before is not None else '/dev/null',tofile='b/'+p))
    write(D/'diffs'/(p+'.patch'),diff)
    rows.append({'target':p,'status':'new' if before is None else ('selected_unchanged' if before==data else 'changed'),
      'before':binding(D/'before'/p) if before is not None else None,
      'raw':binding(D/'raw'/p),'diff':binding(D/'diffs'/(p+'.patch'))})
notes={'status':'author_source_review_complete_no_execution',
 'production_scope':['src/script/microtasks.rs','src/script/promises/install.rs','src/script.rs','src/script/promises.rs (test registration only)'],
 'API':binding(P/'tests-before/api.txt'),'ledger':binding(P/'tests-before/ledger.json'),
 'checks':[
 'Producer entry cleanup2 precedes any allocation. Its two key text calls retain original points; each additional metadata clone pays1 before clone. Global publication and all existing Native/property charges are unchanged.',
 'Shared consumer15 includes six original state guards, publication and eight remaining pool releases. Supplied keys move through argument, destructuring and pool without clone or allocation. Producer cleanup2 covers even an initial15-work refusal.',
 'Standalone cfg(test) wrapper17 preserves guards before text20/16 and directly enters body. No double debit or guard; old1032/1031 and helper heap tests stay exact.',
 'Original remaining Promise pool text,27 handle clones, metadata construction, property order and final publication tail are unchanged. Private method IDs and shared Native callable identities remain unchanged.',
 'Only initialize_intrinsics final two calls change; borrowed bootstrap/error propagation and author-budget reset after success remain unchanged. Partial q-only realm is never returned by public constructors.',
 'Exactly four pre-frozen test migrations are copied without editing. Both new test modules are copied verbatim. Root-installed identity registration remains exact; new quota registration is near existing module declarations.',
 'No finally, new cache, fields, limits, count changes or lazy author work. Logical deltas are34 less work and168 less heap; physical backing sharing is independently witnessed.'
 ],
 'expected_cuts':{'producer':331,'shared_consumer':994,'standalone_consumer':1032,'combined':1325,'raw_bootstrap':99873,'remaining':127},
 'caveats':'No Rust/compiler/formatter/project tests/browser/git ran here. Allocator failures and runtime success remain root verification; unexposed partial metadata is not rolled back.',
 'parent_baseline':{'record':binding(A/'validation/identity-parent-1.json'),'log':binding(A/'validation/identity-parent-1.log'),'root_report':'Physical sharing fails at owner741 length as expected; public descriptor/mutation/SQV7 controls pass both strict modes.'}}
js(D/'source-review-notes.json',notes)
selection={'status':'source_ready_external_unexecuted','parent':hold['published_parent'],
 'plan':binding(P/'source-ready.json'),'tests_hold':binding(P/'tests-before/source-ready.json'),
 'tests_peer':binding(P/'tests-before/html-review.json'),'migrations_hold':binding(P/'migrations-before-1/source-ready.json'),
 'source_review':binding(D/'source-review-notes.json'),'files':rows,
 'import_instructions':'Compare each existing live file to before; raw identity test is already identical live. Import raw entries only. Root owns formatting/compilation/tests. Preserve all frozen assertions.',
 'totals':{'production_files':3,'registration_file':1,'migration_files':4,'new_API_test_files':1,'already_imported_existing_API_test_files':1,'frozen_groups':8},
 'execution':'Source-only external draft; no live edit/import, Rust, formatter, browser, project execution or git.'}
js(D/'source-ready.json',selection)
print(json.dumps({'plan':binding(P/'source-ready.json'),'production':binding(D/'source-ready.json')},indent=2))
