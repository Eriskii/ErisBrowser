from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]


def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inventory = A / 'source-1.json'
sources = json.loads(inventory.read_text())['source_sha256']
assert len(sources) == 790
for name, sha in sources.items():
    assert bind(A / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['native-full-2', 'default-full-2', 'strict-stable-1', 'strict-msrv-1',
              'format-check-1', 'browser-final-build-1', 'references-final-1']:
    r = json.loads((A / 'validation' / (label + '.json')).read_text())
    assert r['exit'] == 0
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256']
    checks[label] = r
for name in ['formatted-source-review.json', 'validation-review.json']:
    assert json.loads((A / 'root' / name).read_text())['status'] in ['clear', 'clear_source_only']
totals = json.loads((A / 'root/full-suite-totals.json').read_text())
assert totals['native-full-2']['passed'] == 3165
assert totals['default-full-2']['passed'] == 2861
reference = json.loads((A / 'root/reference-comparison-final.json').read_text())
assert reference['status'] == 'pass' and reference['pairs'] == 102 and reference['unchanged_pngs'] == 204
ci = json.loads((A / 'validation/parent-ci-final.json').read_text())
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 9
assert all(j['conclusion'] == 'success' for j in ci['jobs'])
artifacts = {}
for directory in ['plans', 'production-1', 'validation', 'root', 'reftests-final']:
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and p.name not in ['selection-final.json', 'publication-verification.json']:
            assert not p.is_symlink() and '__pycache__' not in p.parts
            artifacts[str(p.relative_to(A))] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json']:
        artifacts[p.name] = bind(p)
for name in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/shared-job-keys.md']:
    artifacts['documentation/' + name] = bind(A / 'worktree' / name)
selection = {
    'source_inventory': bind(inventory), 'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': json.loads(inventory.read_text())['base'],
        'parent_ci': {'status': 'success', 'jobs': 9, 'receipt': bind(A / 'validation/parent-ci-final.json')},
        'scope': 'Share immutable length/name key storage between adjacent queueMicrotask and Promise installers, preserving independent metadata and callable identities.',
        'source_inputs': 790,
        'new_test_groups': {'existing_API_identity_and_behavior': 2, 'private_API_resource_boundaries': 6, 'total': 8},
        'baseline': json.loads((A / 'baseline-result.json').read_text()),
        'history': {
            'old_test_migrations': 'Four explicit startup work/heap expectation migrations; standalone installer boundary unchanged.',
            'initial_full_commands': 'native-full-1 and default-full-1 passed their ordinary Cargo selection but omitted --include-ignored. Both receipts are retained; final full-2 commands explicitly include the confined tests.',
            'initial_format_command': 'format-apply-1 rejected cargo fmt flags before formatting; format-apply-2 used the supported invocation.',
            'final_source': bind(inventory)
        },
        'checks': checks,
        'full_suite_totals': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k, v in totals.items()},
        'references': {k: reference[k] for k in ['pairs', 'unchanged_pngs', 'parent_archive_sha256', 'report_sha256']},
        'reference_baseline': 'Published Promise.catch archive at c3d31939.',
        'browser': json.loads((A / 'root/final-browser.json').read_text()),
        'resource_policy': {'bootstrap_allowance': 100000, 'raw_bootstrap_work': 99873, 'remaining': 127,
                            'producer_work': 331, 'shared_consumer_work': 994, 'standalone_consumer_work': 1032,
                            'combined_work': 1325, 'net_saved_work': 34, 'saved_accounted_heap': 168,
                            'objects': 748, 'globals': 212, 'native_registry': 299, 'prototypes': 25,
                            'unchanged_limits': True, 'author_work': 100000, 'cumulative_heap_bytes': 8388608},
        'limits': ['Resource fees are logical accounting, not measured instructions or resident allocator bytes.',
                   'Local authored tests, not new imported WPT/Test262 conformance results.',
                   'No new web API or GPU rendering behavior is added by this checkpoint.',
                   'No Chromium performance comparison, complete compatibility or production-security claim.',
                   'Build caches reused; elapsed times are not cold-build measurements.']
    }
}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2)
    out.write('\n')
print(json.dumps({'sources': len(sources), 'artifacts': len(artifacts)}))
