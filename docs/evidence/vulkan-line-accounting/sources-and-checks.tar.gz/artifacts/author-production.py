import difflib
import hashlib
import json
from pathlib import Path
import subprocess

G=Path('/tmp/eris-vulkan-line-accounting-plan-1')
W=G/'worktree'
H=G/'production-1'
BASE='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
PATH='src/graphics/raster_bridge/native.rs'
METRIC_SHA='92bee6b5648c1bf381d21a875f086dad7a64ef8ba7ef152c09e32a53fac879ee'
sha=lambda data:hashlib.sha256(data).hexdigest()
metric_bytes=(G/'public-tests-1/metric-ready.json').read_bytes()
assert sha(metric_bytes)==METRIC_SHA
metric=json.loads(metric_bytes)
contract_bytes=(G/metric['contract']['path']).read_bytes()
assert sha(contract_bytes)==metric['contract']['sha256']
assert len(contract_bytes)==metric['contract']['bytes']
assert metric['status']=='frozen' and metric['no_execution'] and metric['no_production_read']
H.mkdir(exist_ok=False)

def put(path,data):
    p=H/path
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists()
    p.write_bytes(data)
    return {'path':str(p.relative_to(G)),'bytes':len(data),'sha256':sha(data)}
def js(path,data): return put(path,(json.dumps(data,indent=2,ensure_ascii=False)+'\n').encode())
def bound(path):
    data=(G/path).read_bytes()
    return {'path':path,'bytes':len(data),'sha256':sha(data)}

before=subprocess.check_output(['git','show',f'{BASE}:{PATH}'],cwd=W)
assert before==(W/PATH).read_bytes()
text=before.decode()
edits=[
 ('line_not_full_frame', '''            // Preserve every operation/parameter slot. Rects and Images get a
            // separate pre-blend geometry reservation after this complete
            // preflight; Line and opacity retain their full-frame allowance.
            if !matches!(
                command,
                DrawCommand::Rect { .. }
                    | DrawCommand::Image { .. }
''','''            // Preserve every operation/parameter slot. Rects, Lines and Images
            // get a pre-blend geometry reservation after complete preflight;
            // opacity markers retain their full-frame allowance.
            if !matches!(
                command,
                DrawCommand::Rect { .. }
                    | DrawCommand::Line { .. }
                    | DrawCommand::Image { .. }
'''),
 ('line_only_phase_geometry', '''        if !input.commands.iter().any(|command| {
            matches!(
                command,
                DrawCommand::Rect { .. }
                    | DrawCommand::Image { .. }
''','''        if !input.commands.iter().any(|command| {
            matches!(
                command,
                DrawCommand::Rect { .. }
                    | DrawCommand::Line { .. }
                    | DrawCommand::Image { .. }
'''),
 ('shared_zero_radius_rectangle_work', '''                DrawCommand::Rect { rect, .. } => {
                    let offset = state.offset();
''','''                DrawCommand::Rect { .. } | DrawCommand::Line { .. } => {
                    let rect = match command {
                        DrawCommand::Rect { rect, .. } => convert_rect(*rect),
                        DrawCommand::Line {
                            x1,
                            y1,
                            x2,
                            y2,
                            width,
                            ..
                        } => line_rect(*x1, *y1, *x2, *y2, *width, index)
                            .map_err(|error| NativeFallback::leaf(error, Some(phase)))?,
                        _ => unreachable!(),
                    };
                    let offset = state.offset();
'''),
 ('text_only_ignored', '                DrawCommand::Text { .. } | DrawCommand::Line { .. } => continue,\n','                DrawCommand::Text { .. } => continue,\n'),
]
chunks=[]
for label,old,new in edits:
    assert text.count(old)==1,(label,text.count(old))
    text=text.replace(old,new,1)
    chunks.append({'label':label,'before':old,'after':new})
raw=text.encode()
inverse=text
for c in reversed(chunks):
    assert inverse.count(c['after'])==1,c['label']
    inverse=inverse.replace(c['after'],c['before'],1)
assert inverse.encode()==before

def section(source,start,end):
    assert source.count(start)==1,start
    return source[source.index(start):source.index(end,source.index(start))]
preserved=[]
for name,start,end in [
 ('all_original_preflight_validation','fn preflight(target: Frame, phases:', '            counts.nontext += 1;'),
 ('rectangle_offset_and_work','                    let translated = Rect::new(\n                        rect.x + offset.0,', '                DrawCommand::Image { rect, .. } => {\n                    let offset = state.offset();'),
 ('checked_geometry_debit','fn charge_geometry(', '#[derive(Clone, Copy, Debug, PartialEq, Eq)]\nstruct Ledger'),
 ('preparation_peak_formula','pub fn preparation_peak_bytes(', 'pub fn plan_native_scene('),
 ('entire_native_later_pipeline','pub fn plan_native_scene(', '\n#[cfg(test)]'),
]:
    a=section(before.decode(),start,end)
    b=section(text,start,end)
    assert a==b,name
    preserved.append({'name':name,'bytes':len(a.encode()),'sha256':sha(a.encode())})

refs=[put('before/'+PATH,before),put('raw/'+PATH,raw)]
patch=''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/'+PATH,tofile='b/'+PATH))
refs.append(put('diff/'+PATH+'.patch',patch.encode()))
chunk_ref=js('chunks.json',{'schema':1,'base':BASE,'path':PATH,'chunks':chunks,'full_inverse_exact':True})
preserve_ref=js('preservation.json',{'schema':1,'full_inverse_exact':True,'exact_sections':preserved,
 'all_other_paths':'No other production payload is authored. Canvas, line_rect, raster-core, shaders, limits and presenter stay published bytes.',
 'rect_route':'convert_rect copies the same four f32 fields; the existing translation and zero-radius work body is byte-exact.',
 'new_interfaces':[], 'new_struct_or_enum_fields':[], 'new_per_line_allocation':False,
 'intentional_change':'Line is charged at its original position in geometry_pixel_work instead of globally before all geometry. Box-before-Line may perform funded work before a later global CpuPaintBudget diagnostic.'})
seal=js('source-ready.json',{'schema':1,'status':'sealed production hold; source only, unexecuted','author':'/root/layout','base':BASE,
 'prerequisites':[bound('root/selection-1.json'),bound('source-plan-1/source-ready.json'),bound('public-tests-1/metric-ready.json'),bound('public-tests-1/contract.json')],
 'files':[{'path':PATH,'artifacts':refs}],'chunks':chunk_ref,'preservation':preserve_ref,
 'separate_migrations':bound('migrations-1/source-ready.json'),
 'author_script_sha256':sha(Path(__file__).read_bytes()),
 'scope':'One production file, four selected chunks. Existing final lowering, core/shaders/caps/preparation storage formula/native ownership untouched.',
 'verification':'Published-before byte match, four exact unique replacements, complete source inverse, original input validation and downstream pipeline byte equality. No compiler, rustfmt or project execution.',
 'checks':{'metric_contract_preceded_payload':True,'live_edits':False,'project_execution':False,'test_registration_authored':False}})
print(json.dumps(seal,indent=2))
