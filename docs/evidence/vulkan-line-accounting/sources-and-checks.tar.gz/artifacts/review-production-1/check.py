from pathlib import Path
import json, hashlib, subprocess, re, difflib
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');R=G/'review-production-1';W=G/'worktree';base='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(G)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
seen={}
def visit(v):
 if isinstance(v,dict):
  if isinstance(v.get('path'),str) and v.get('sha256'):
   p=G/v['path'];got=bind(p);assert got['sha256']==v['sha256'],str(p)
   if 'bytes' in v:assert got['bytes']==v['bytes']
   seen[str(p.relative_to(G))]=got
  for x in v.values():visit(x)
 elif isinstance(v,list):
  for x in v:visit(x)
for rel in ['implementation-1/source-ready.json','migrations-1/source-ready.json','public-tests-1/source-ready.json','root/selection-1.json']:
 p=G/rel;seen[rel]=bind(p);visit(json.loads(p.read_text()))
prod=json.loads((G/'implementation-1/chunks.json').read_text())
b=(G/'implementation-1/before'/prod['path']).read_text();a=(G/'implementation-1/raw'/prod['path']).read_text()
assert b.encode()==subprocess.check_output(['git','show',f'{base}:{prod["path"]}'],cwd=W)
forward=b
for r in prod['chunks']:
 assert forward.count(r['before'])==1
 forward=forward.replace(r['before'],r['after'],1)
assert forward==a
inverse=a
for r in reversed(prod['chunks']):
 assert inverse.count(r['after'])==1
 inverse=inverse.replace(r['after'],r['before'],1)
assert inverse==b
patch=''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+prod['path'],tofile='b/'+prod['path']))
assert patch==(G/'implementation-1/diff'/f'{prod["path"]}.patch').read_text()
# Preserve exact source spans independently of the producer's preservation ledger.
def span(s,lo,hi):
 start=s.index(lo);end=s.index(hi,start);return s[start:end]
sections={}
for name,lo,hi in [
 ('complete_original_validation','fn preflight(', '            counts.nontext += 1;'),
 ('geometry_translation_debit','                    let offset = state.offset();\n                    let translated = Rect::new(\n                        rect.x + offset.0,','                DrawCommand::Image { rect, .. } => {'),
 ('checked_geometry_debit','fn charge_geometry(', '#[derive(Clone, Copy, Debug, PartialEq, Eq)]\nstruct Ledger'),
 ('storage_formula','pub fn preparation_peak_bytes(', 'pub fn plan_native_scene('),
]:
 if name=='storage_formula' and lo not in b:lo='fn preparation_peak_bytes('
 old=span(b,lo,hi);new=span(a,lo,hi);assert old==new,name
 sections[name]={'bytes':len(old.encode()),'sha256':hashlib.sha256(old.encode()).hexdigest()}
lo='pub fn plan_native_scene(';old=b[b.index(lo):];new=a[a.index(lo):];assert old==new
sections['entire_planning_lowering_and_output_pipeline']={'bytes':len(old.encode()),'sha256':hashlib.sha256(old.encode()).hexdigest()}
# Test bodies are compared by brace-balanced spans after masking comments/strings.
def tests(s):
 masked=re.sub(r'"(?:\\.|[^"\\])*"|//[^\n]*|/\*.*?\*/',lambda m:' '*len(m.group()),s,flags=re.S)
 out={}
 for m in re.finditer(r'#\[test\]\s*fn\s+(\w+)\s*\(',masked):
  start=m.start();k=masked.index('{',m.end());depth=1;j=k+1
  while depth:
   if masked[j]=='{':depth+=1
   if masked[j]=='}':depth-=1
   j+=1
  out[m.group(1)]=s[start:j]
 return out
migrations=json.loads((G/'migrations-1/chunks.json').read_text());migration_rows=[];retained=[]
rename={'full_area_line_debt_is_global_before_any_box_window_preparation':'full_area_opacity_debt_is_global_before_any_box_window_preparation'}
for f in migrations['files']:
 rel=f['path'];bp=G/'migrations-1/before'/rel;ap=G/'migrations-1/raw'/rel;old=bp.read_text();new=ap.read_text()
 assert bp.read_bytes()==subprocess.check_output(['git','show',f'{base}:{rel}'],cwd=W)
 cur=old
 for r in f['chunks']:
  assert cur.count(r['before'])==1,(rel,r['label']);cur=cur.replace(r['before'],r['after'],1)
 assert cur==new
 for r in reversed(f['chunks']):
  assert cur.count(r['after'])==1;cur=cur.replace(r['after'],r['before'],1)
 assert cur==old
 patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 assert patch==(G/'migrations-1/diff'/f'{rel}.patch').read_text()
 ot,nt=tests(old),tests(new);assert [rename.get(n,n)for n in ot]==list(nt)
 changed=[]
 for n,body in ot.items():
  nn=rename.get(n,n)
  if body==nt[nn]:retained.append({'path':rel,'test':n,'sha256':hashlib.sha256(body.encode()).hexdigest()})
  else:changed.append({'before':n,'after':nn})
 assert len(changed)==1
 migration_rows.append({'path':rel,'chunks':len(f['chunks']),'retained_groups':len(ot)-1,'changed':changed,'before':bind(bp),'after':bind(ap)})
assert len(retained)==20
# Fixed helpers/caps/shaders are not part of the one-file production hold.
production_files=json.loads((G/'implementation-1/source-ready.json').read_text())['files'];assert [x['path']for x in production_files]==['src/graphics/raster_bridge/native.rs']
checks={'status':'clear','production_unique_chunks':4,'production_forward_inverse_and_patch_exact':True,'production_before_git_exact':True,'preserved_source_sections':sections,'migration_files':migration_rows,'all_migration_forward_inverse_patch_and_git_joins_exact':True,'retained_test_bodies':retained,'all_24_old_test_names_preserved_except_one_selected_rename':True,'bindings':list(seen.values()),'execution':'Independent stdlib text/hash/Git-blob audit only; no project modules, Rust, engine, tests or formatter execution.'}
put(R/'checks.json',checks)
review={'status':'clear','base':base,'reviewer':'/root/html_css','production':bind(G/'implementation-1/source-ready.json'),'migrations':bind(G/'migrations-1/source-ready.json'),'selected_contract':bind(G/'root/selection-1.json'),'independent_test_hold':bind(G/'public-tests-1/source-ready.json'),'checks':bind(R/'checks.json'),'findings':[],
 'source_assessment':[
 'Exactly four selected production replacements; all original structural/raw geometry validation is byte-exact and completes before any debit. NaN, excessive width and excessive derived extent remain invalid even under empty clips/zero opacity and after an excessive earlier Line workload.',
 'Line retains original f32 line_rect subtraction/min/max, then one active phase/fixed translation. Existing zero-radius Rect clip/intersection/floor/ceil work body is byte-exact. Rect conversion copies the same four f32 fields. Line-only phases now enter that pass, so their clip/fixed state is visited.',
 'Every original Line retains its command/parameter slot, loses only global full-frame precharge, and receives exactly one original-order geometry debit. Alpha/opacity does not discount the debit. Empty inner loops cost0; independent256-command/1024-height caps bound empty outer-row iterations to262144, without modeling total CPU instructions.',
 'charge_geometry retains atomic checked subtraction and unindexed CpuPaintBudget. Box-specific debits retain indexed errors. Accordingly Box then16 full Lines fails at the final Line without an index;16 full Lines then Box fails at Box index16. Later original invalid geometry still wins because preflight is complete first.',
 'No per-Line heap allocation, lookup, mask preparation or callback is added. A Line-only phase now uses the existing bounded CoordinateState allocation, which is released per phase and reports its existing allocation failure. Existing preparation storage formula is byte-exact.',
 'The entire plan_native_scene pipeline, final Line-to-Rect lowering, shaders/core, all limits, text/source ledgers and presenter ownership are outside the changed span or outside the sole production file. No GPU execution/performance inference.'
 ],
 'migration_assessment':[
 'Empty transparent coincident width0 Line changes262144 to0; the surrounding exact Rect boundary, missing Image and opacity rows remain exact.',
 'Mixed8-pixel-frame scene changes27 to20: unchanged16 opacity +1 image +1 Line +2 Rect. The independent GPU-cap refusal remains exact.',
 'Scope quota Line endpoints change to250x200, preserving each50000 debit, total1000000,100 original commands, phase sharing and one-more refusal; no old assertion changes.',
 'Box global-precharge regression now uses balanced unit-opacity markers:8 pairs charge4224000 and9 pairs charge4752000, preserving every Box shape and fallback assertion. Its one rename accurately describes retained non-Line ordering. New Line ordering is explicitly tested by the independent hold.',
 'All four before files join published Git; exact selected substitutions and inverses reconstruct all bytes;20 unaffected test bodies and23 of24 names are identical, with only the selected Box test rename.'
 ],
 'limits':'This is source-only review of held payloads. It does not assert compilation, test outcomes, runtime performance, shader execution or actual GPU behavior. Root owns import/format/execution.'}
put(R/'review.json',review)
print(json.dumps(bind(R/'review.json')))
