from pathlib import Path
from collections import Counter
import hashlib,json,re
p=Path(__file__).resolve().parents[1]; prior=Path('/tmp/eris-class-runtime-plan-1')
def binding(f):
 b=f.read_bytes();return {'path':str(f),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(folder,label,full=True):
 f=folder/'validation'/(label+'.json');r=json.loads(f.read_text());l=folder/'validation'/r['log'];assert r['exit']==0 and binding(l)['sha256']==r['sha256'];t=l.read_text()
 results=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',t,re.M)
 roster=re.findall(r'^test ([^\n]+?) \.\.\. (ok|FAILED|ignored).*$',t,re.M)
 assert results and all(x[0]=='ok' and all(int(n)==0 for n in x[2:5]) and (not full or int(x[5])==0) for x in results)
 assert len(roster)==sum(int(x[1]) for x in results) and all(s=='ok' for _,s in roster)
 counts=Counter(n for n,_ in roster);assert all(n==1 for n in counts.values())
 return {'receipt':binding(f),'log':binding(l),'passed':len(roster),'result_rows':len(results)},set(counts)
source=json.loads((p/'source-candidate-2.json').read_text())
for rel,sha in source['source_sha256'].items():assert binding(p/'worktree'/rel)['sha256']==sha,rel
rename_a='graphics::raster_bridge::native::box_prepass_tests::full_area_line_debt_is_global_before_any_box_window_preparation'
rename_b='graphics::raster_bridge::native::box_prepass_tests::full_area_opacity_debt_is_global_before_any_box_window_preparation'
rows=[]
for config,oldlabel,count,extra in [('default','class-default-full-2',3344,0),('host-vulkan','class-host-vulkan-full-1',3698,10)]:
 old,oldnames=check(prior,oldlabel);new,newnames=check(p,config+'-full-2');assert old['passed']==count
 if extra:
  assert rename_a in oldnames and rename_b in newnames;oldnames.remove(rename_a);oldnames.add(rename_b)
 assert oldnames<=newnames,sorted(oldnames-newnames)
 added=sorted(newnames-oldnames);assert len(added)==extra and all('native_line_' in n for n in added);assert new['passed']==count+extra
 rows.append({'config':config,'parent':old,'candidate':new,'added':added,'historical_rename':[rename_a,rename_b] if extra else None,'all_other_parent_tests_preserved':True})
focused,names=check(p,'candidate-lines-2',False);assert focused['passed']==10
record={'status':'pass','source':binding(p/'source-candidate-2.json'),'configurations':rows,'focused_msrv_bridge':focused,'qualifications':'Rust test results verify CPU planning/pixels; no GPU execution or timing inference. Selected-input inventory is not the full build graph.'}
f=p/'root/full-suite-validation-2.json'
with f.open('x') as o:json.dump(record,o,indent=2);o.write('\n')
print(json.dumps(binding(f)))
