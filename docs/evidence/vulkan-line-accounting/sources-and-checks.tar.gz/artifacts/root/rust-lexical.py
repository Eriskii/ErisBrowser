import re
char = re.compile(r"'(?:[^\\'\n]|\\(?:[\\'\"nrt0]|x[0-9A-Fa-f]{2}|u\{[0-9A-Fa-f_]+\}))'")
raw_string = re.compile(r'(?:br|cr|r)(#*)"')
word_token = re.compile(r'[A-Za-z_0-9]+')
def tokens(s):
    out = []
    literals = []
    comments = []
    i = 0
    while i < len(s):
        if s[i].isspace(): i += 1; continue
        if s.startswith('//', i):
            j = s.find('\n', i)
            if j < 0: j = len(s)
            comments.append(s[i:j]); i = j; continue
        if s.startswith('/*', i):
            j = i + 2; depth = 1
            while depth:
                if s.startswith('/*', j): depth += 1; j += 2
                elif s.startswith('*/', j): depth -= 1; j += 2
                else: j += 1
                assert j <= len(s)
            comments.append(s[i:j]); i = j; continue
        raw = raw_string.match(s, i)
        if raw:
            ending = '"' + raw.group(1)
            j = s.index(ending, raw.end()) + len(ending)
            token = s[i:j]; out.append(token); literals.append(token); i = j; continue
        prefix = 1 if s[i:i+2] in ['b"', 'c"'] else 0
        if s[i+prefix:i+prefix+1] == '"':
            j = i + prefix + 1
            while s[j] != '"':
                j += 2 if s[j] == '\\' else 1
            j += 1
            token = s[i:j]; out.append(token); literals.append(token); i = j; continue
        cm = char.match(s, i + (1 if s.startswith("b'", i) else 0))
        if cm:
            j = cm.end(); token = s[i:j]
            out.append(token); literals.append(token); i = j; continue
        word = word_token.match(s, i)
        if word:
            j = word.end(); out.append(s[i:j]); i = j; continue
        out.append(s[i]); i += 1
    return out, literals, comments

