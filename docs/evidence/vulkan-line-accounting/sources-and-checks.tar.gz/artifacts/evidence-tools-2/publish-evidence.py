"""Root-executed native Line evidence publisher; this held source is not an execution receipt."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
E = W / 'docs/evidence/vulkan-line-accounting'
RAW_CAP = 64 * 1024 * 1024
GZIP_CAP = 8 * 1024 * 1024
DOC_PATHS = {'README.md', 'docs/ROADMAP.md', 'docs/SECURITY.md',
             'docs/VALIDATION.md', 'docs/vulkan-native-window.md',
             'docs/vulkan-line-accounting.md'}
EXCLUDED_TOP = {'worktree', 'publication', 'target-msrv', 'target-1990'}
EXCLUDED_DIRS = {'__pycache__', '.git', 'target'}
ROOT_OUTPUTS = {'root/evidence-selection.json', 'root/publication-verification.json',
                'root/github-publication.json'}
BINARY_SUFFIXES = {'.pyc', '.pyo', '.o', '.obj', '.a', '.so', '.dylib', '.dll',
                   '.exe', '.rlib', '.rmeta', '.wasm', '.bin'}
BINARY_MAGIC = (b'\x7fELF', b'MZ', b'\x00asm', b'!<arch>\n',
                b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    relative = path.relative_to(P)
    current = P
    assert not P.is_symlink()
    for part in relative.parts:
        current /= part
        assert not current.is_symlink(), current
    assert stat.S_ISREG(path.stat(follow_symlinks=False).st_mode), path
    return path.read_bytes()


def bind(path):
    data = regular(path)
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def read(name):
    return json.loads(regular(P / name))


def safe_name(name):
    p = PurePosixPath(name)
    assert isinstance(name, str) and name and not p.is_absolute()
    assert '..' not in p.parts and '.' not in p.parts and str(p) == name, name
    return name


def documentation():
    rows = read('documentation-1/source-ready.json')['files']
    names = [safe_name(r.get('relative', r.get('relative_path', r.get('path')))) for r in rows]
    assert len(rows) == len(set(names)) == 6 and set(names) == DOC_PATHS
    for name, row in zip(names, rows):
        held = row['raw']
        verify_binding(held)
        actual = bind(W / name)
        assert (actual['bytes'], actual['sha256']) == (held['bytes'], held['sha256']), name
    return list(zip(names, rows))


SOURCE_HOLDS = ('implementation-1/source-ready.json',
                'migrations-1/source-ready.json',
                'public-tests-1/source-ready.json',
                'browser-witness-1/source-ready.json')


def held_path(name):
    assert isinstance(name, str) and name
    path = Path(name)
    path = path if path.is_absolute() else P / path
    relative = path.relative_to(P)
    assert '..' not in relative.parts
    return path


def verify_binding(record):
    path = held_path(record['path'])
    data = regular(path)
    assert sha(data) == record['sha256'], path
    if 'bytes' in record:
        assert len(data) == record['bytes'], path
    return data


def validate_source_holds():
    # Verify frozen source/test payload references, without executing/importing
    # their scripts or the project. Semantic/format joins are final-peer work.
    def visit(value):
        if isinstance(value, dict):
            if 'path' in value and 'sha256' in value:
                verify_binding(value)
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    for name in SOURCE_HOLDS:
        visit(read(name))
    assert read('review-production-1/review.json')['status'] == 'clear'
    assert read('review-tests-1/compiler-correction-review.json')['status'].startswith('clear')


def external_files():
    """Walk without following any symlink, including symlinked parent directories."""
    accepted, skipped = [], []

    def visit(directory):
        with os.scandir(directory) as entries:
            ordered = sorted(entries, key=lambda e: e.name)
        for entry in ordered:
            path = Path(entry.path)
            relative = path.relative_to(P).as_posix()
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                skipped.append(dict(path=relative, reason='symlink; target not followed'))
            elif stat.S_ISDIR(info.st_mode):
                if (directory == P and entry.name in EXCLUDED_TOP) or entry.name in EXCLUDED_DIRS:
                    skipped.append(dict(path=relative + '/', reason='worktree, publication output or build cache'))
                else:
                    visit(path)
            elif stat.S_ISREG(info.st_mode):
                if relative in ROOT_OUTPUTS:
                    skipped.append(dict(path=relative, reason='self-dependent or subsequent publication receipt'))
                    continue
                with path.open('rb') as stream:
                    prefix = stream.read(16)
                if path.suffix.lower() in BINARY_SUFFIXES or prefix.startswith(BINARY_MAGIC):
                    skipped.append(dict(path=relative, reason='compiled binary'))
                    continue
                accepted.append(path)
            else:
                skipped.append(dict(path=relative, reason='nonregular file'))
    visit(P)
    return accepted, skipped


def main():
    # The source freeze is final only after the unchanged candidate2 receipts.
    assert regular(P / 'source-candidate-2.json') == regular(P / 'source-final.json')
    final_record, parent_record = read('source-final.json'), read('source-parent.json')
    assert final_record['base'] == parent_record['base']
    final, parent = final_record['source_sha256'], parent_record['source_sha256']
    assert set(parent) <= set(final), 'unexpected selected-input deletion'
    changed = sorted(name for name, value in final.items() if parent.get(name) != value)
    assert len(changed) == 10
    for name, value in final.items():
        assert sha(regular(W / safe_name(name))) == value, name
    validate_source_holds()
    docs = documentation()
    assert not set(changed) & DOC_PATHS
    ledger = read('root/final-validation.json')
    peer = read('validation-review-1/final-review.json')
    docpeer = read('documentation-review-1/review.json')
    assert ledger['status'] == 'pass' and peer['status'] == 'clear' and docpeer['status'] == 'clear'
    authority = {name: bind(P / path) for name, path in {
        'ledger': 'root/final-validation.json',
        'peer': 'validation-review-1/final-review.json',
        'documentation_peer': 'documentation-review-1/review.json',
        'documentation_hold': 'documentation-1/source-ready.json',
        'implementation_hold': 'implementation-1/source-ready.json',
        'migration_hold': 'migrations-1/source-ready.json',
        'public_test_hold': 'public-tests-1/source-ready.json',
        'browser_test_hold': 'browser-witness-1/source-ready.json',
        'production_peer': 'review-production-1/review.json',
        'test_peer': 'review-tests-1/review.json',
        'test_compile_correction_peer': 'review-tests-1/compiler-correction-review.json',
        'format_review': 'format-review-1/review.json',
    }.items()}
    selection_path = P / 'root/evidence-selection.json'
    output, manifest_path = E / 'sources-and-checks.tar.gz', E / 'manifest.json'
    assert not any(p.exists() or p.is_symlink() for p in [selection_path, output, manifest_path])
    directory = P
    for part in E.relative_to(P).parts:
        directory /= part
        assert not directory.is_symlink(), directory
    members = {}

    def add(name, path, role):
        safe_name(name)
        assert name not in members
        members[name] = dict(data=regular(path), origin=str(path), role=role)

    for name in changed:
        add('sources/' + name, W / name, 'changed-source')
    for name, _ in docs:
        add('documentation/' + name, W / name, 'published-documentation')
    files, skipped = external_files()
    for path in files:
        relative = path.relative_to(P).as_posix()
        add('artifacts/' + relative, path, 'root-receipt-or-script' if relative.startswith('root/') else 'validation-artifact')
    selection = [dict(path=name, bytes=len(row['data']), sha256=sha(row['data']),
                      origin=row['origin'], role=row['role']) for name, row in sorted(members.items())]
    assert sum(row['bytes'] for row in selection) < RAW_CAP
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
        for name, row in sorted(members.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(row['data']), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ''
            archive.addfile(info, io.BytesIO(row['data']))
    assert len(raw.getvalue()) < RAW_CAP, 'raw tar including headers exceeds cap'
    packed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
    assert len(packed) < GZIP_CAP
    # Validate constructed bytes and freeze origins before any publication output.
    with tarfile.open(fileobj=io.BytesIO(packed), mode='r:gz') as archive:
        assert archive.getnames() == [row['path'] for row in selection]
        for row in selection:
            member = archive.getmember(row['path'])
            assert member.isfile() and not member.issym() and not member.islnk()
            data = archive.extractfile(member).read()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert data == regular(Path(row['origin'])), row['origin']
    frozen = dict(status='frozen', members=selection, observed_exclusions=skipped,
                  exclusion_rules=dict(top_directories=sorted(EXCLUDED_TOP), cache_directories=sorted(EXCLUDED_DIRS),
                      root_outputs=sorted(ROOT_OUTPUTS), binary_suffixes=sorted(BINARY_SUFFIXES), symlinks='never followed'),
                  qualification='All eligible external G holds/receipts, including superseded and failed attempts. Selected input inventory is not a complete build graph.')
    with selection_path.open('x') as stream:
        json.dump(frozen, stream, indent=2); stream.write('\n')
    E.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as stream:
        stream.write(packed)
    summary = dict(schema=1, status='verified', archive=dict(path=output.name, bytes=len(packed),
        sha256=sha(packed), uncompressed_tar_bytes=len(raw.getvalue()), member_bytes=sum(r['bytes'] for r in selection)),
        source_count=10, documentation_count=6, artifact_count=len(selection)-16,
        source_inventory=bind(P / 'source-final.json'), candidate_inventory=bind(P / 'source-candidate-2.json'),
        claims=ledger, claims_authority=authority, selection=bind(selection_path), members=selection,
        caps=dict(raw_bytes=RAW_CAP, gzip_bytes=GZIP_CAP), inventory_scope=final_record['scope'])
    with manifest_path.open('x') as stream:
        json.dump(summary, stream, indent=2); stream.write('\n')
    print(json.dumps(dict(members=len(selection), sources=10, docs=6, archive=bind(output))))


if __name__ == '__main__':
    main()
