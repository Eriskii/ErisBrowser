from pathlib import Path
import json, hashlib, re, difflib, subprocess
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');H=G/'public-tests-1';W=G/'worktree';base='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(G)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
c=json.loads((H/'contract.json').read_text());ready=json.loads((H/'metric-ready.json').read_text())
for row in ready['inputs']:
 p=G/row['path'];assert bind(p)['sha256']==row['sha256']
 assert p.read_bytes()==subprocess.check_output(['git','show',f'{base}:{row["relative_path"]}'],cwd=W)
assert bind(H/'contract.json')==ready['contract']
p=H/'raw/src/graphics/raster_bridge/native/line_accounting_tests.rs';src=p.read_text();names=re.findall(r'#\[test\]\s*fn (\w+)\(',src)
assert names==[r['test']for r in c['groups']]
assert len(names)==len(set(names))==9
for x in ['line_rect(', 'RoundedTiles', 'RoundedShape', 'geometry_pixel_work(', 'charge_geometry(']:assert x not in src,x
for r in c['groups'][1]['rows']:
 def ar(xs):return '['+', '.join(repr(float(x))for x in xs)+']'
 needle=f'Case {{ name: "{r["id"]}", line: {ar(r["line"])}, rect: {ar(r["literal_rect"])}, work: {r["work"]}, red: &{r["red_indices"]} }}'
 assert src.count(needle)==1
assert src.count('fn checked_scene(')==1 and src.count('fn same_packed_plan(')==1
before=H/'parent/src/graphics/raster_bridge/native/tests.rs'; append=H/'registration-append.txt'
registration_after=H/'registration-after/src/graphics/raster_bridge/native/tests.rs'; registration_after.parent.mkdir(parents=True,exist_ok=True);registration_after.write_bytes(before.read_bytes()+append.read_bytes())
diff=''.join(difflib.unified_diff(before.read_text().splitlines(True),registration_after.read_text().splitlines(True),fromfile='a/src/graphics/raster_bridge/native/tests.rs',tofile='b/src/graphics/raster_bridge/native/tests.rs'))
(H/'registration.diff').write_text(diff)
newdiff=''.join(difflib.unified_diff([],src.splitlines(True),fromfile='/dev/null',tofile='b/src/graphics/raster_bridge/native/line_accounting_tests.rs'))
(H/'new-module.diff').write_text(newdiff)
roster={'status':'planned source-derived counts; not execution','groups':[{'test_name':r['test'],'contract_group':r['id'],'parent_first':r['parent_first']}for r in c['groups']],'counts':{'rust_groups':9,'planned_native_scene_calls':59,'planned_successful_line_scene_and_literal_canvas_pixel_comparisons':28,'planned_packed_plan_rect_comparisons':15,'planned_native_refusals':16},'parent_prediction':{'passing_groups':2,'failing_groups':7,'qualification':'Source-derived only; an early assertion stops later rows within a group. No candidate outcome claim.'}}
put(H/'roster.json',roster)
checks={'status':'source-only checks clear','published_parent_snapshots':len(ready['inputs']),'literal_geometry_rows_exact':14,'test_names_exact_and_unique':names,'expected_work_oracle_uses_producer_helper':False,'registration_append_inverse_exact':registration_after.read_bytes()[:-len(append.read_bytes())]==before.read_bytes(),'scope':'one new test module plus separate append-only existing test-module registration','fee_and_render_oracles':'Frozen literal arithmetic; Canvas/Rect packed plans are independent secondary behavior comparisons, never the expected work oracle.','addenda':['Opaque repetition preserves zero-pixel-work but actually reaches Canvas empty inner loops.','One overlap scene adds a draw-order discriminator to the existing geometry group.'],'no_project_import_execution_or_formatter':True,'production_source_not_read':True,'compile_caveat':'Static API/source checks only; root owns compilation, formatting and execution.'}
put(H/'checks.json',checks)
files=[{'relative_path':'src/graphics/raster_bridge/native/line_accounting_tests.rs','before':None,'raw':bind(p),'diff':bind(H/'new-module.diff')}]
manifest={'status':'sealed independent public tests; parent eligible; unexecuted','base':base,'metric_ready':bind(H/'metric-ready.json'),'contract':bind(H/'contract.json'),'contract_addenda':[bind(H/'contract-addendum-1.json'),bind(H/'contract-addendum-2.json')],'files':files,'registration':{'relative_path':'src/graphics/raster_bridge/native/tests.rs','before':bind(before),'append':bind(append),'raw':bind(registration_after),'diff':bind(H/'registration.diff'),'composition':'Root owns append import; producer hold does not include this registration.'},'roster':bind(H/'roster.json'),'checks':bind(H/'checks.json'),'source_inputs':ready['inputs'],'selection':bind(G/'root/selection-1.json'),'source_parent':bind(G/'source-parent.json'),'execution':'none; no project modules imported, tests run, Rust compiler/formatter invoked or live source edited','producer_independence':'Metric contract froze before producer authoring; test conversion and two additive literal refinements remained source-blind after producer seal.'}
put(H/'source-ready.json',manifest)
print(json.dumps(bind(H/'source-ready.json')))
