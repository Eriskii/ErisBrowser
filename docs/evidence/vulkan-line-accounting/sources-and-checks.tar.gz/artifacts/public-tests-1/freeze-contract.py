from pathlib import Path
import json, hashlib, subprocess
G=Path('/tmp/eris-vulkan-line-accounting-plan-1'); H=G/'public-tests-1'; W=G/'worktree'; base='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
def put(p,v):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(G)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
paths=['src/graphics/raster_bridge/native.rs','src/graphics/raster_bridge.rs','src/graphics/raster_bridge/native/tests.rs','src/graphics/raster_bridge/native/rect_accounting_tests.rs','src/graphics/raster_bridge/native/box_prepass_tests.rs','src/graphics.rs','crates/raster-core/src/rounded.rs','crates/raster-core/src/scope.rs','crates/raster-core/src/lib.rs','crates/raster-core/src/profile.rs']
inputs=[]
for rel in paths:
 b=subprocess.check_output(['git','show',f'{base}:{rel}'],cwd=W);p=H/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 assert (W/rel).read_bytes()==b
 inputs.append({'relative_path':rel,**bind(p),'git_blob':subprocess.check_output(['git','rev-parse',f'{base}:{rel}'],cwd=W,text=True).strip()})
rows=[
 ('horizontal',[1,1,3,1,1],2,[5,6],[1,1,2,1]),
 ('reversed',[3,1,1,1,1],2,[5,6],[1,1,2,1]),
 ('vertical',[1,1,1,3,1],2,[5,9],[1,1,1,2]),
 ('diagonal_bounds',[1,1,3,3,0],4,[5,6,9,10],[1,1,2,2]),
 ('point_width',[1,1,1,1,2],4,[5,6,9,10],[1,1,2,2]),
 ('minimum_width',[1,1,2,1,2],4,[5,6,9,10],[1,1,2,2]),
 ('negative_width',[1,1,3,2,-2],2,[5,6],[1,1,2,1]),
 ('zero_height',[1,1,3,1,0],0,[],[1,1,2,0]),
 ('negative_point_width',[1,1,1,1,-1],0,[],[1,1,0,0]),
 ('fractional',[.25,.25,1.75,1.75,.25],4,[0,1,4,5],[.25,.25,1.5,1.5]),
 ('offscreen',[5,0,7,1,0],0,[],[5,0,2,1]),
 ('partly_visible',[-1,-1,1,1,0],1,[0],[-1,-1,2,2]),
 ('f32_cancel_to_zero',[-500000,0,.015625,1,0],0,[],[-500000,0,500000,1]),
 ('f32_one_ulp_visible',[-500000,0,.03125,1,0],1,[0],[-500000,0,500000.03125,1]),
]
groups=[
 {'id':'small_lines','test':'native_line_accounting_forty_small_lines_are_960_pixels','frame':[512,512],'commands':'40 opaque red horizontal Lines (0,i)->(24,i), width1, i=0..39','work':960,'old_full_frame_work':10485760,'pixels':'white except x=0..23,y=0..39 red','original_commands':40,'parent_first':'unwrap refuses CpuPaintBudget'},
 {'id':'literal_geometry','test':'native_line_accounting_literal_geometry_and_rect_plans','frame':[4,4],'rows':[{'id':i,'line':l,'work':n,'red_indices':p,'literal_rect':r}for i,l,n,p,r in rows],'comparison':'literal pixels first, published Canvas pixels, literal ordinary Rect packed-plan fields; no helper-derived expected work','parent_first':'first work assertion:16 versus2'},
 {'id':'clip_and_translation','test':'native_line_accounting_fractional_clip_and_translation','frame':[4,4],'rows':[{'id':'fractional_caller','line':[0,0,3,3,0],'caller_clip':[.25,.25,1.5,1.5],'offset':[0,0],'work':1,'red_indices':[5]},{'id':'fractional_offset','line':[.25,.25,1.25,.25,.5],'caller_clip':[0,0,4,4],'offset':[.5,.5],'work':4,'red_indices':[0,1,4,5]},{'id':'translated_once','line':[2,1,4,1,1],'caller_clip':[0,0,4,4],'offset':[-1,1],'work':2,'red_indices':[9,10]}],'parent_first':'first work assertion:16 versus1'},
 {'id':'phase_fixed','test':'native_line_accounting_phases_restore_fixed_and_clip_state','frame':[8,4],'phase0':'document(-3,0),viewport(1,0): empty clip, fixed, Line(0,0,2,2,width0) red, popfixed, Line(0,0,8,4,width0) blue, popclip, Line(3,2,5,2,width1) green','phase1':'caller clip(4,0,2,4),viewport(4,0): fixed, Line(0,0,4,0,width1) blue,popfixed','work':8,'original_commands':10,'pixels':{'red':[1,2,9,10],'green':[16,17],'blue':[4,5]},'parent_first':'work128 versus8'},
 {'id':'alpha','test':'native_line_accounting_transparency_and_zero_opacity_keep_debt','frame':[4,4],'line':[.25,.25,1.75,1.75,0],'rows':[{'alpha':0,'work':4,'pixel':'white'},{'alpha':128,'work':4,'pixel':'0xff7f7f at0,1,4,5'},{'opacity':0,'line_alpha':255,'work':36,'pixel':'white','group_scratch_bytes':0}],'parent_first':'work16 versus4'},
 {'id':'cpu_boundary','test':'native_line_accounting_exact_shared_cpu_boundary_and_one_over','frame':[512,512],'phases':'two phases each8 transparent full512x512 Lines','work':4194304,'extra':'third phase one transparent1x1 Line','refusal':{'kind':'CpuPaintBudget','phase':None,'command':None},'expected_pixels':'all white','parent_first':'passes; boundary and one-over are unchanged actual limits'},
 {'id':'structural_bound','test':'native_line_accounting_empty_inner_loops_keep_structural_caps','frame':[1,1024],'caller_clip':[.25,0,.25,1024],'line':[0,0,1,1024,0],'line_alpha':0,'exact_commands':256,'work':0,'derivation':'x lower=ceil(.25)=1, upper=ceil(.5)=1; zero inner visits although up to1024 outer-y iterations per command; independent structural maximum256*1024=262144','extra_command_refusal':{'kind':'CommandLimit','phase':0,'command':None},'four_phases':'64 commands each admitted,0work','five_phases_refusal':{'kind':'CommandLimit','phase':None,'command':None},'height1025_refusal':{'kind':'ViewportLimit','phase':None,'command':None},'parent_first':'work262144 versus0'},
 {'id':'validation_priority','test':'native_line_accounting_validates_hidden_geometry_before_debit','frame':[512,512],'phase0':'17 full-frame transparent Lines, projected excessive debt','phase1':'PushOpacity0, emptyPushClip, invalidLine,PopClip,PopOpacity','invalids':'NaN in each of five geometric fields; width+infinity; width1000001; endpointsx=-1000000,+1000000 producing invalidextent2000000','refusal':{'kind':'InvalidGeometry','phase':1,'command':2},'scope_variant':'17 full Lines then PopFixed =>InvalidScope at0,17','parent_first':'all rows pass because complete input validation precedes debt in both versions'},
 {'id':'box_order','test':'native_line_accounting_original_order_controls_box_budget_location','frame':[512,512],'line_work':262144,'box':'zero-radius1x1 Color box, no cutout, old allowance8+3*1=11','rows':[{'sequence':'16 full Lines then box','refusal':{'kind':'CpuPaintBudget','phase':0,'command':16}},{'sequence':'box then16 full Lines','refusal':{'kind':'CpuPaintBudget','phase':None,'command':None}}],'parent_first':'first row passes; second row returns old indexed box0 instead of new aggregate Line refusal'}]
contract={'status':'frozen independent source-derived public metric contract; no project execution or producer read','base':base,'selection':bind(G/'root/selection-1.json'),'source_parent':bind(G/'source-parent.json'),'inputs':inputs,'scope':'Native Line accounting only, same f32 rectangle geometry/translation/clip rounding and old lowering. Pixel counter covers inner pixel visits, not all CPU instructions. No shader or GPU evidence.','oracle_method':'Explicit numeric rows and packed RGB pixels derived by arithmetic from published code. No expected work uses line_rect, RoundedTiles, RoundedShape, geometry_pixel_work, Canvas output, or measured candidate. Canvas/core plans are secondary behavior controls only.','f32_derivation':'At500000, one f32 ULP=0.03125; 500000+0.015625 ties to even500000, then -500000+500000=0. At+0.03125 endpoint reconstruction is0.03125, admitting one pixel. All literals exactly binary-representable.','groups':groups,'counts':{'rust_groups':9,'literal_geometry_rows':14,'clip_rows':3,'invalid_geometry_rows':8},'parent_prediction':'2pass/7fail groups; early failing assertions leave later rows unreached, not measured. Group cpu_boundary and validation_priority pass. No outcome inference for candidate.'}
put(H/'contract.json',contract)
put(H/'metric-ready.json',{'status':'frozen','base':base,'contract':bind(H/'contract.json'),'inputs':inputs,'no_execution':True,'no_production_read':True})
print(json.dumps(bind(H/'metric-ready.json')))
