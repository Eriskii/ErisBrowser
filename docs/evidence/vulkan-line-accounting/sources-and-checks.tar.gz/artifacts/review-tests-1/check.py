import hashlib,json,math,re,struct,subprocess
from pathlib import Path
G=Path('/tmp/eris-vulkan-line-accounting-plan-1')
W=G/'worktree'
O=G/'review-tests-1'
BASE='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
sha=lambda b:hashlib.sha256(b).hexdigest()
refs={}
def verify_refs(value):
    if isinstance(value,dict):
        if 'path' in value and 'sha256' in value:
            p=Path(value['path'])
            if not p.is_absolute():p=G/p
            data=p.read_bytes()
            assert sha(data)==value['sha256'],p
            if 'bytes' in value:assert len(data)==value['bytes'],p
            refs[str(p)]={'bytes':len(data),'sha256':sha(data)}
        for v in value.values():verify_refs(v)
    elif isinstance(value,list):
        for v in value:verify_refs(v)

seals={}
for name,expected in [('public-tests-1/source-ready.json','fd3a34ca773052a4e92643812e6844c6ba1b055a4465282c5fecf46f60801a48'),('browser-witness-1/source-ready.json',None)]:
    b=(G/name).read_bytes()
    if expected:assert sha(b)==expected
    seals[name]={'bytes':len(b),'sha256':sha(b)}
    d=json.loads(b)
    assert d['base']==BASE
    verify_refs(d)
pub=json.loads((G/'public-tests-1/source-ready.json').read_bytes())
browser=json.loads((G/'browser-witness-1/contract.json').read_bytes())
verify_refs(browser)
source_joins={}
for src in pub['source_inputs']+browser['source_inputs']:
    name=src.get('relative_path',src.get('relative'))
    b=subprocess.check_output(['git','show',f'{BASE}:{name}'],cwd=W)
    assert sha(b)==src['sha256'] and len(b)==src['bytes'],name
    source_joins[name]={'bytes':len(b),'sha256':sha(b)}
registration=pub['registration']
r_before=(G/registration['before']['path']).read_bytes()
r_append=(G/registration['append']['path']).read_bytes()
r_raw=(G/registration['raw']['path']).read_bytes()
assert r_before+r_append==r_raw
assert r_append==b'\n#[path = "line_accounting_tests.rs"]\nmod line_accounting_tests;\n'
assert r_before==subprocess.check_output(['git','show',f'{BASE}:'+registration['relative_path']],cwd=W)
rust=(G/pub['files'][0]['raw']['path']).read_text()
tests=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',rust)
contract=json.loads((G/'public-tests-1/contract.json').read_bytes())
assert tests==[x['test'] for x in contract['groups']]
assert len(tests)==9
# Transcription check only: the expected metrics/pixels remain the frozen literal
# contract; this checker does not import or run the candidate estimator.
rows=re.findall(r'Case \{ name: "([^"]+)", line: \[([^]]+)\], rect: \[([^]]+)\], work: (\d+), red: &\[([^]]*)\] \}',rust)
literal=contract['groups'][1]['rows']
assert len(rows)==len(literal)==14
for row,item in zip(rows,literal):
    name,line,rect,work,red=row
    assert name==item['id']
    assert [float(x) for x in line.split(',')]==item['line']
    assert [float(x) for x in rect.split(',')]==item['literal_rect']
    assert int(work)==item['work']
    assert [int(x) for x in red.split(',') if x.strip()]==item['red_indices']

# Independent stdlib TrueType inspection: cmap4/hmtx/loca, no font or browser API.
font_name='assets/DejaVuSansMono.ttf'
font=subprocess.check_output(['git','show',f'{BASE}:{font_name}'],cwd=W)
u16=lambda o:struct.unpack_from('>H',font,o)[0]
s16=lambda o:struct.unpack_from('>h',font,o)[0]
u32=lambda o:struct.unpack_from('>I',font,o)[0]
tables={}
for i in range(u16(4)):
    p=12+i*16
    tables[font[p:p+4].decode()]=(u32(p+8),u32(p+12))
cmap=tables['cmap'][0]
matches=[]
for i in range(u16(cmap+2)):
    p=cmap+4+8*i
    platform,encoding=u16(p),u16(p+2)
    sub=cmap+u32(p+4)
    if u16(sub)!=4:continue
    count=u16(sub+6)//2
    ends=sub+14
    starts=ends+2*count+2
    deltas=starts+2*count
    ranges=deltas+2*count
    for j in range(count):
        if u16(starts+2*j)<=0xa0<=u16(ends+2*j):
            off=u16(ranges+2*j)
            glyph=u16(ranges+2*j+off+2*(0xa0-u16(starts+2*j))) if off else 0xa0
            glyph=(glyph+s16(deltas+2*j))&65535 if glyph or not off else 0
            matches.append({'platform':platform,'encoding':encoding,'glyph':glyph})
            break
assert matches==browser['font_proof']['cmap_format4_matches']
gid=matches[0]['glyph']
head=tables['head'][0]
hhea=tables['hhea'][0]
metrics=u16(hhea+34)
advance=u16(tables['hmtx'][0]+4*min(gid,metrics-1))
loca=tables['loca'][0]
offsets=[u32(loca+4*i) if s16(head+50)==1 else u16(loca+2*i)*2 for i in (gid,gid+1)]
proof={'glyph':gid,'units_per_em':u16(head+18),'ascent':s16(hhea+4),'descent':s16(hhea+6),'number_hmetrics':metrics,'advance':advance,'glyph_offsets':offsets}
for k in proof:
    if k!='glyph':assert proof[k]==browser['font_proof'][k],k
assert offsets[0]==offsets[1]
f=lambda x:struct.unpack('<f',struct.pack('<f',x))[0]
bits=lambda x:struct.unpack('<I',struct.pack('<f',x))[0]
height=proof['ascent']-proof['descent']
scale=f(f(16*height)/proof['units_per_em'])
advance16=f(f(scale/height)*advance)
assert advance16==9.6328125==browser['font_proof']['derived_advance_at_16px']
expected=bytearray(b'\xff\xff\xff'*(512*512))
work=0
geometry=[]
for i,row in enumerate(browser['rows']):
    baseline=f(16*f(.95))
    text_y=f(f(f(16+32*i)+baseline)-baseline)
    assert text_y==16+32*i==row['text_position'][1]
    pair=[f(text_y+f(16*f(factor))) for factor in (1.12,.65)]
    assert [bits(y) for y in pair]==row['y_bits']
    rectangles=[]
    for y in pair:
        # Chosen exact input has x=16, right25.6328125: integer columns16..25.
        top=math.floor(y)
        bottom=math.ceil(f(y+1))
        assert bottom-top==2
        rectangles.append([16,top,10,2])
        work+=20
        for py in range(top,bottom):
            for px in range(16,26):
                off=(py*512+px)*3
                expected[off:off+3]=bytes([192,32,64])
    assert rectangles==row['pixel_rectangles']
    geometry.append({'row':i,'y_bits':[bits(y) for y in pair],'rectangles':rectangles})
oracle=json.loads((G/'browser-witness-1/pixel-oracle.json').read_bytes())
assert sha(expected)==oracle['sha256'] and len(expected)==oracle['bytes']
assert sum(expected[i:i+3]==bytes([192,32,64]) for i in range(0,len(expected),3))==360
assert work==360 and work+9==369
assert 512*512*2+18*(2*1*64)==526592
support=(G/'browser-witness-1/raw/tests/support/vulkan_lines.rs').read_text()
for symbol,column in [('UNDERLINE_Y',0),('STRIKE_Y',1)]:
    segment=re.search(r'const '+symbol+r': \[u32; 9\] = \[([^]]+)\]',support,re.S).group(1)
    assert [int(x,16) for x in re.findall(r'0x[0-9a-f]+',segment)]==[x['y_bits'][column] for x in browser['rows']]
assert 'assert_eq!(stats.cpu_pixel_upper_bound, 369);' in support
assert 'assert_eq!(plan.invocations(), 526_592);' in support
assert 'assert_eq!(plan.draws().len(), 19);' in support
test=(G/'browser-witness-1/raw/tests/vulkan_lines.rs').read_text()
assert '#![cfg(feature = "raster-bridge")]' in test
assert re.findall(r'#\[test\]\s*fn\s+(\w+)\(',test)==['native_line_loaded_decorations_admit_exact_plan_and_literal_pixels']
cargo=subprocess.check_output(['git','show',f'{BASE}:Cargo.toml'],cwd=W).decode()
assert 'raster-bridge = ["dep:eris-raster-core"]' in cargo
assert 'vulkan-raster = ["vulkan-presenter", "raster-bridge", "eris-raster-core/gpu"]' in cargo

report={
 'schema':1,'status':'clear for selected source contract; execution pending root',
 'reviewer':'/root/layout','authorship':'Independent review of HTML public tests and Script browser witness; reviewer authored selected implementation and historical migrations, not these new tests.',
 'base':BASE,'seals':seals,'checked_references':refs,'published_source_joins':source_joins,
 'public':{'groups':9,'literal_rows':14,'registration_append_exact':True,'metric_to_rust_rows_exact':True,'semantics':'Literal work and pixel tables reconcile with published f32 Line rectangle lowering, Canvas pre-blend boundaries and existing scope state. ULP cancellation, width sign, fixed restore, alpha, unchanged cap/priority and Line/Box ordering checked. Added opaque zero-inner-loop case and overlapping ordered colors are bound separately.','parent_qualification':'2 passing/7 failing groups is a source prediction only. No later subcase execution inferred after first failure.'},
 'browser':{'groups':1,'font':proof,'font_advance16':advance16,'geometry':geometry,'lines':18,'line_work':360,'empty_glyph_occurrences':9,'cold_requests_per_native_session':1,'cpu_work':369,'original_and_lowered_commands':27,'draws':19,'padded_invocations':526592,'changed_pixels':360,'pixel_sha256':sha(expected),'packing':'Published parameter_bytes places bounds at words0..3, frame dimensions4..5, opaque RGBA6. Clear plus18 ordered rectangles;9 validated empty glyph commands yield no core draw/input/coverage, but retain their one-pixel occurrence fees. Both native calls create fresh Sessions; Canvas may use its own cache.','feature':'One normal Cargo integration group under raster-bridge; included transitively by vulkan-raster, no Cargo edit needed.'},
 'qualifications':[
  'No project import, compilation, test, live source edit or GPU execution by reviewer. All arithmetic/font checks are independent stdlib reads.',
  'This source review does not itself establish parent/candidate results or allocation-fault coverage. Newly reached coordinate-state allocation failure follows the selected existing error path; these10 groups do not inject that allocation refusal.',
  'Browser witness is Page-only; no worker/click witness and no new font-outline rasterization oracle. The font outline is intentionally empty.',
  'Packed browser witness checks every ordered rectangle, its bounds/color/target parameter fields and complete pixels. It does not assert every zero padding byte of parameter records. Public same_packed_plan compares complete parameters/input on its selected literal controls.',
  'The structural zero-work case separately permits up to256*1024 empty outer rows; pixel work is not all CPU instructions. All existing caps stay exact.',
 ],'findings':[]
}
data=(json.dumps(report,indent=2,ensure_ascii=False)+'\n').encode()
(O/'review.json').write_bytes(data)
print(json.dumps({'path':str(O/'review.json'),'bytes':len(data),'sha256':sha(data)},indent=2))
