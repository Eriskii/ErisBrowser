from pathlib import Path
from collections import Counter
import difflib, hashlib, json, re, subprocess
G=Path('/tmp/eris-vulkan-line-accounting-plan-1'); W=G/'worktree'; D=G/'documentation-1'
BASE='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
def digest(b): return hashlib.sha256(b).hexdigest()
def load(p): return json.loads(Path(p).read_text())
def bind(p):
 p=Path(p); b=p.read_bytes()
 return {'path':str(p.relative_to(G)) if p.is_relative_to(G) else str(p),'bytes':len(b),'sha256':digest(b)}
def resolve(p):
 p=Path(p); return p if p.is_absolute() else G/p
seen={}
def verify_tree(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():
   p=resolve(v['path']); b=p.read_bytes(); assert len(b)==v['bytes'] and digest(b)==v['sha256'],str(p); seen[str(p)]=bind(p)
  for a in v.values(): verify_tree(a)
 elif isinstance(v,list):
  for a in v: verify_tree(a)
def write(p,obj): p.write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
assert not (D/'source-ready.json').exists(), 'Seal already exists; do not mutate.'
ledger=load(G/'root/final-validation.json'); draft=load(D/'draft-status.json')
assert bind(G/'root/final-validation.json')['sha256']=='9c79b04ce06f25d45e23633bf16be67672e76b389eb4fdc00127d01f3edd6e66'
assert ledger['base']==BASE and ledger['status']=='pass'
verify_tree(ledger); ledger_bindings=len(seen)
verify_tree(draft)
peer=load(G/'validation-review-1/final-review.json'); assert peer['status']=='clear'
assert bind(G/'validation-review-1/final-review.json')['sha256']=='5437618bba6be2ff327bcf0a9f6854a10328b724e581a6c6e5a822d4e57c4391'
verify_tree(peer)
source=load(G/'source-final.json'); assert source['base']==BASE
assert (G/'source-final.json').read_bytes()==(G/'source-candidate-2.json').read_bytes()
assert len(source['source_sha256'])==1838==ledger['selected_inputs']
for name,h in source['source_sha256'].items(): assert digest((W/name).read_bytes())==h,name
assert len(draft['files'])==6 and not draft['pending']
links=[]; future={'docs/evidence/vulkan-line-accounting/manifest.json','docs/evidence/vulkan-line-accounting/sources-and-checks.tar.gz'}
for row in draft['files']:
 name=row['relative_path']; raw=resolve(row['raw']['path']).read_bytes()
 assert not re.search(rb'PENDING|\bTBD\b|\bTODO\b',raw)
 if row['before']:
  old=resolve(row['before']['path']).read_bytes()
  actual=subprocess.run(['git','show',BASE+':'+name],cwd=W,check=True,stdout=subprocess.PIPE).stdout
  assert old==actual,name
 else: old=b''
 patch=''.join(difflib.unified_diff(old.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+name if old else '/dev/null',tofile='b/'+name))
 assert patch.encode()==resolve(row['diff']['path']).read_bytes(),name
 additions='\n'.join(line[1:] for line in patch.splitlines() if line.startswith('+') and not line.startswith('+++'))
 for target in re.findall(r'\]\(([^)]+)\)',additions):
  if re.match(r'[a-z]+://',target) or target.startswith('#'): continue
  clean=target.split('#')[0]
  dest=(W/name).parent/clean
  relative=dest.resolve().relative_to(W.resolve()).as_posix()
  state='selected future evidence' if relative in future else 'existing or held'
  assert relative in future or (D/'raw'/relative).is_file() or (W/relative).is_file(),(name,target)
  links.append({'document':name,'target':target,'resolved':relative,'status':state})
header=b'# Validation record\n\n'
before=(D/'before/docs/VALIDATION.md').read_bytes(); final=(D/'raw/docs/VALIDATION.md').read_bytes()
assert before.startswith(header) and final.startswith(header) and final.endswith(before[len(header):])
summary_re=re.compile(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',re.M)
def summaries(path):
 rows=summary_re.findall(Path(path).read_text()); assert rows,path
 return {'rows':len(rows),'passed':sum(int(x[1]) for x in rows),'failed':sum(int(x[2]) for x in rows),'ignored':sum(int(x[3]) for x in rows),'filtered':sum(int(x[5]) for x in rows),'all_ok':all(x[0]=='ok' for x in rows)}
def roster(path): return Counter(re.findall(r'^test (.+) \.\.\. ok$',Path(path).read_text(),re.M))
rosters=[]
for cfg,total in zip(ledger['full_suites']['configurations'],[3344,3708]):
 oldp=resolve(cfg['parent']['log']['path']); newp=resolve(cfg['candidate']['log']['path'])
 got=summaries(newp); assert got=={'rows':54,'passed':total,'failed':0,'ignored':0,'filtered':0,'all_ok':True},got
 before_roster=roster(oldp); after_roster=roster(newp); expected=before_roster.copy()
 rename=cfg['historical_rename']
 if rename:
  a,b=rename; assert expected[a]==1; del expected[a]; expected[b]+=1
 expected.update(cfg['added']); assert expected==after_roster
 rosters.append({'config':cfg['config'],'raw':got,'old_roster_plus_selected_rename_and_additions_exact':True,'additions':cfg['added'],'rename':rename})
focused=summaries(G/'validation/candidate-lines-2.log'); assert focused['passed']==10 and focused['failed']==0 and focused['all_ok']
first=summaries(G/'validation/candidate-lines-1.log'); assert first['passed']==10 and first['failed']==0 and first['all_ok']
parent=load(G/'root/parent-results-1.json'); assert (parent['passed'],parent['failed'])==(2,8)
parent_rows=re.findall(r'^test (.+) \.\.\. (ok|FAILED)$',(G/'validation/parent-lines-2.log').read_text(),re.M)
assert Counter(parent_rows)==Counter(map(tuple,parent['groups']))
for name,row in ledger['checks'].items():
 receipt=load(resolve(row['receipt']['path'])); assert receipt['exit']==0,name
 assert receipt['command']==row['command']
 assert receipt['sha256']==row['log']['sha256']
hardware=[]
assert ledger['hardware']['status']=='unverified' and ledger['hardware']['hardware_claim'] is False
for i in [1,2]:
 folder=G/f'hardware-check-{i}'; report=load(folder/'native-check.stdout.log'); result=load(folder/'result.json')
 assert report['completed_frames']==0 and report['checked'] is False and report['scene_hex']=='' and report['samples']==[]
 assert (report['width'],report['height'])==(3825,2085)
 assert report['failure']=='Vulkan target exceeds the four-megapixel/8192-axis budget'
 cleanup=result['supervisor']['cleanup']; assert cleanup['complete'] is True and cleanup['descendants']==0
 assert result['hardware_claim'] is False and result['supervisor']['returncode']==1
 stderr=(folder/'native-check.stderr.log').read_text(); assert '4070 SUPER' in stderr and 'Bgra8Unorm' in stderr
 hardware.append({'attempt':i,'completed_native_check_frames':0,'checked':False,'width':3825,'height':2085,'cleanup_complete':True,'remaining_descendants':0})
control=load(G/'hardware-check-2/owned-control.json')
assert control['success'] is False and control['control_complete'] is False and control['requests']==[] and control['accepted_connections']==0
assert control['browser_reaped'] is True
chapter=(D/'raw/docs/vulkan-line-accounting.md').read_text()
assert 'before\ncompleting a native check frame' in chapter and 'zero native check frames' in chapter
assert 'correctness for this\ncheckpoint remains unverified' in chapter
claims={
 'status':'checked','method':'Read-only Git and Python standard-library byte/hash/JSON/log/source inspection; no project code imports, project execution, live edits or hardware execution.',
 'base':BASE,'final_ledger':bind(G/'root/final-validation.json'),'validation_peer':bind(G/'validation-review-1/final-review.json'),
 'source_final':bind(G/'source-final.json'),'source_final_equals_candidate2':True,'selected_inputs_checked':1838,'selected_inventory_is_not_full_build_graph':True,
 'ledger_unique_file_bindings_checked':ledger_bindings,'all_checked_bindings':list(seen.values()),
 'documentation_files':draft['files'],'exact_published_before_paths':5,'exact_diff_reconstructions':6,
 'historical_validation_suffix':{'bytes':len(before)-len(header),'sha256':digest(before[len(header):]),'exact':True},
 'links':links,'future_evidence_paths':sorted(future),'pending_placeholders':False,
 'parent':{'groups':10,'passed':2,'failed':8,'raw_roster_exact':True,'qualification':'Each failed group stops at its first assertion; later table rows and repetitions are not claimed as parent observations.'},
 'first_candidate':first,'final_focused':focused,'full_suites':rosters,
 'strict_and_build':'All eight final ledger receipts have exit zero, matching command and raw log hash; includes three strict Clippy configurations, formatting, Vulkan-only release.',
 'hardware':hardware,'owned_retry':{'window_control_complete':False,'html_requests':0,'accepted_connections':0,'html_body_released':False},
 'hardware_qualification':'GPU correctness remains unverified. Device/format detection is observed. No acquired-texture comparison occurred; accepted_frames is not used to rule out an earlier startup CPU frame.',
 'geometry_claims':{'small_lines':{'count':40,'size':[24,1],'work':960,'old_work':10485760,'allowance':4194304},'page':ledger['observed_page'],'metric':'inner pixel visits and opaque span elements; empty outer y rows separately bounded by 256 commands times 1024 rows; not a general instruction/time bound'},
 'retained_attempts':ledger['retained_attempts'],
 'scope':'Native Line admission only; existing rendering/lowering/shaders/caps retained. No JavaScript profile rerun, new CI result, performance/security/full compatibility or GPU correctness claim.',
 'findings':[]}
write(D/'claims-and-checks.json',claims)
manifest={'status':'source-ready','scope':'Final six-document Native Line accounting hold; actual CPU planning/test evidence and explicitly unsuccessful GPU verification attempts.',
 'base':BASE,'files':draft['files'],'final_ledger':bind(G/'root/final-validation.json'),'source_final':bind(G/'source-final.json'),'validation_peer':bind(G/'validation-review-1/final-review.json'),'claims_and_checks':bind(D/'claims-and-checks.json'),
 'audit_script':bind(D/'seal.py'),'actual_bindings':draft['actual_bindings'],
 'historical_validation_suffix_exact':True,'five_published_before_joins_exact':True,'six_diffs_exact':True,
 'selected_future_evidence_paths':sorted(future),'pending':[],
 'qualifications':['Hardware correctness remains unverified after two actual surface-cap refusals; CPU-plan and Rust checks passed.','The 1,838 selected source inputs are not a full build graph.','Historical validation suffix is exact; current native accounting paragraph updates Rect, Line, Image and opacity distinctions.','No JavaScript profiles were rerun, and no current remote CI, security, rendering-speed or full-compatibility outcome is claimed.'],
 'no_project_execution_or_live_edits':True}
write(D/'source-ready.json',manifest)
print(json.dumps({'seal':bind(D/'source-ready.json'),'claims':bind(D/'claims-and-checks.json'),'checked_unique_ledger_bindings':ledger_bindings,'all_checked_unique_bindings':len(seen),'source_inputs':1838,'files':6,'links':len(links)},indent=2))
