from pathlib import Path
import subprocess,hashlib,json,difflib
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');H=G/'documentation-1';W=G/'worktree';base='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
paths=['README.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/vulkan-native-window.md']
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(G)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(rel,s):
 p=H/'raw'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
before={}
for rel in paths:
 b=subprocess.check_output(['git','show',f'{base}:{rel}'],cwd=W);p=H/'before'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);assert (W/rel).read_bytes()==b;before[rel]=b.decode()
readme=before['README.md'];anchor='The [rendering docket](docs/vulkan-rendering.md) tracks broader admission,\n'
assert readme.count(anchor)==1
readme=readme.replace(anchor,'''
[Native Line accounting](docs/vulkan-line-accounting.md) now reserves each
Line's clipped rectangle loop area. Forty 24×1 Lines at 512×512 use 960 pixel
work units instead of 10,485,760, within the unchanged allowance. The existing
pixels, shaders and whole-scene fallback remain in place.

'''+anchor)
put('README.md',readme)
roadmap=before['docs/ROADMAP.md'];old='''clip work and fixed-scope restoration under the same CPU allowance. Line and
opacity reservations, source/mask limits and GPU admission remain unchanged.
''';new='''clip work and fixed-scope restoration under the same CPU allowance.
[Native Lines](vulkan-line-accounting.md) now use the existing clipped rectangle
loop bound in original command order. Both opacity markers retain full-frame
reservations; command/source/mask limits and GPU admission remain unchanged.
''';assert roadmap.count(old)==1;put('docs/ROADMAP.md',roadmap.replace(old,new))
security=before['docs/SECURITY.md'];anchor='- [Native raster backgrounds]';i=security.index(anchor)
security=security[:i]+'''- [Native Line accounting](vulkan-line-accounting.md) charges the existing clipped zero-radius rectangle loop bound after complete input validation, including transparent colors and zero-opacity descendants. Original command order now determines which geometry debit refuses; no partial scene is presented. The counter covers inner pixel visits, not all CPU instructions. Empty outer rows remain bounded separately by 256 commands and 1024 frame rows. Command, scope, coordinate, pixel-work, storage and GPU limits are unchanged; there is no new per-Line allocation or renderer authority.
'''+security[i:];put('docs/SECURITY.md',security)
native=before['docs/vulkan-native-window.md'];old='''[Rectangles](native-rect-accounting.md) reserve their clipped pre-blend CPU loop
area before glyph preparation. Image, Line and both opacity markers retain one
full framebuffer area each, including empty groups. A bounded coordinate pass
accounts for every phase before font work, preserving fixed-position escape and
restoration. This admits more small-shape scenes without increasing pixel-work
limits. Cropped GPU scratch does not replace the full-viewport CPU opacity
reservation.
''';new='''[Rectangles](native-rect-accounting.md) and [Lines](vulkan-line-accounting.md)
reserve their clipped pre-blend rectangle loop area before glyph preparation.
[Images](native-image-accounting.md) reserve their own clipped sampling-loop
area, including its distinct fractional lower-bound rules. Both opacity markers
retain one full framebuffer area each, including empty groups. The bounded
coordinate pass charges geometry in original command order across every phase,
preserving fixed-position escape and restoration. These changes admit more
small-shape scenes without increasing pixel-work limits. The metric counts
inner pixel visits; empty outer rows have separate command/height bounds.
Cropped GPU scratch does not replace the full-viewport CPU opacity reservation.
''';assert native.count(old)==1;put('docs/vulkan-native-window.md',native.replace(old,new))
chapter='''# Native Line work accounting

The optional native raster route now reserves each `Line` command's clipped
rectangle loop area instead of one full framebuffer. Forty 24×1 Lines in a
512×512 frame reserve **960 pixel work units**, down from **10,485,760**, and fit
the unchanged **4,194,304** allowance. This changes admission precision while
preserving the existing drawing operation, packed plans, shaders and limits.

## Geometry and admission

The existing [Line conversion](../src/graphics/raster_bridge.rs) forms an
axis-aligned rectangle: its origin is the endpoint minimum and each extent is
the larger of the absolute endpoint difference and width. It retains `f32`
operation order. The active document or fixed offset is added once, then the
existing zero-radius Rect helper intersects the active clip and derives integer
loop bounds. Lower bounds use the visible origin's floor, the clip origin's
ceiling and zero; upper bounds use the reconstructed endpoint's ceiling and
framebuffer extent. The nonnegative span product is the reserved work.

This is the renderer's existing Line behavior, including reversed endpoints,
fractional coordinates and finite nonpositive widths. It adds no new stroke
semantics. Transparent colors and zero-opacity descendants still pay geometry;
empty or fully clipped inner loops cost zero. Complete original geometry and
scope validation runs first, including hidden commands and invalid later input.

The [native geometry pass](../src/graphics/raster_bridge/native.rs) now includes
Line-only phases. It reuses the bounded coordinate state, preserving fixed-scope
escape, restoration and independent phase clips. There is no per-Line allocation
or mask. One existing scope vector is live per visited phase; its fallible
allocation and conservative storage reservation remain bounded as before.

Line work is now debited in original command order alongside other geometry.
For example, at 512×512, sixteen full-frame Lines exhaust the allowance before
a following one-pixel Box and report that Box's indexed refusal. With the Box
first, its existing 11-unit charge precedes the Lines, and the last Line reports
the aggregate unindexed pixel-budget refusal. Both refuse the complete scene.
Opacity markers retain their global full-frame precharge.

The CPU allowance remains `(framebuffer_area * 16).clamp(1_000_000, 32_000_000)`.
The counter covers inner pixel visits and opaque span elements, not every CPU
instruction. A fractional clip can leave no inner x visits but nonempty outer y
iterations; the independent 256-command and 1024-height limits bound those rows
to 262,144 across a scene. The four-phase, scope, source, mask, GPU-buffer and
invocation limits are unchanged. More precise CPU admission does not guarantee
that a scene passes the later GPU checks.

## Literal controls and loaded page

Nine independent unit groups cover small Lines, literal pixels and Rect packed
plans, `f32` cancellation, clips and offsets, phase/fixed restoration, alpha,
exact/one-over pixel admission, structural caps, hidden invalid input and
ordered Box refusals. Their expected work comes from frozen numeric literals,
not the implementation helper or observed candidate output.

The [loaded-page witness](../tests/vulkan_lines.rs) uses the
[decoration example](../examples/vulkan-lines.html) at 512×512 with scripts
disabled. Its nine nonbreaking spaces produce nine empty glyph occurrences and
18 underline/strike-through Lines, preserving all 27 display commands. The
literal pixel oracle has 360 colored pixels. Two passes on the same loaded
layout verify Canvas and decoded packed-plan pixels, exact draw order and a
**369-unit** total: 360 Line visits plus nine existing glyph charges. The chosen
bundled glyph has an empty outline; this does not test font-outline rasterization.

## Validation and retained attempts

The published parent runs all ten new groups: **two pass and eight fail** at
the expected admission or work assertions. Failed groups stop at their first
assertion; later rows are not claimed as parent observations. The first compiled
candidate passes all **ten groups** on Rust 1.88 with `raster-bridge`, preserving
the frozen oracles. Before the parent measurement, a page-helper compile failure
required an explicit `usize` closure argument and removal of an unused `mut`.
Those test-only fixes, the failed compile and the parent failures are retained.
The first full suites also passed before strict Clippy flagged the exact binary32
literals `25.6328125` and `500000.03125`. Narrow function-level lint allowances
retain those values and all assertions; the initial lint failure remains recorded.

Final complete runs pass **3,344 default Rust 1.88 tests** and **3,708 Rust 1.99 tests
with `test262-host,vulkan-raster`**. Both have 54 result rows and no failed,
ignored or filtered tests. The default roster is unchanged; the feature roster
preserves its parent plus ten groups and one selected historical rename.
Strict all-target Clippy passes for Rust 1.88 default and `raster-bridge`, and
Rust 1.99 with `test262-host,vulkan-raster`; formatting also passes.

The Vulkan-only release build passes. Both actual window checks exited before
completing a native check frame: the compositor supplied a 3825×2085 tile, exceeding the
presenter's existing four-megapixel surface limit. This is distinct from the
Native profile's 1280×1024 limit. The retry's owned-process controller could not
resize the window before startup exited and released no HTML response. Both
runs recognized an NVIDIA GeForce RTX 4070 SUPER with `Bgra8Unorm`, but completed
zero native check frames with no acquired-texture comparison. Both cleanups finished with
zero descendants. The attempts are retained; actual GPU correctness for this
checkpoint remains unverified.

The final source inventory equals candidate 2 and binds **1,838 selected
inputs**; it is not a complete build graph. Existing JavaScript conformance
profiles were not rerun for this native-only change.

The CPU packed-plan decoder is not shader execution. Existing rectangle/image
chapters retain their earlier checkpoint observations. This accounting change
establishes no browser compatibility, general rendering-speed or security claim.
The [evidence manifest](evidence/vulkan-line-accounting/manifest.json) and
[source/check archive](evidence/vulkan-line-accounting/sources-and-checks.tar.gz)
retain the contracts, source reviews, corrections and observed runs.
''';put('docs/vulkan-line-accounting.md',chapter)
validation='''## Native Line accounting

[Native Lines](vulkan-line-accounting.md) now reserve their existing clipped
zero-radius rectangle loop work in original command order. Forty 24×1 Lines at
512×512 cost **960** rather than **10,485,760** pixel work units under the same
**4,194,304** allowance. Lowering, shaders and all resource limits are unchanged;
the metric covers inner pixel visits, with empty outer rows bounded separately.

All **ten new groups pass** in the first compiled Rust 1.88 `raster-bridge`
candidate run. Nine unit groups include literal pixels/packed plans and exact
admission/refusal boundaries. The loaded-page group repeats its complete
512×512 literal pixel and packed-plan checks twice, observing **369** work units
for 18 Lines and nine empty glyph occurrences. These checks do not execute a
Vulkan shader.

The parent records **two passing and eight failing groups**, with later rows
unreached after each first failure. Its initial E0271 helper compile refusal and
unused-`mut` correction remain retained; neither changed an expected value.
Strict Clippy later flagged two exact binary32 literals after the first full
suites passed. Narrow function-level allowances preserve both literal oracles
and all assertions; the original lint failure is retained.
Four historical groups retain their earlier non-Line assertions through narrow
fixture/fee migrations, including one selected opacity-test rename.

Final complete runs pass **3,344 default Rust 1.88 tests** and **3,708 Rust 1.99 tests
with `test262-host,vulkan-raster`**. Both have 54 result rows and no failed,
ignored or filtered tests. The default roster is unchanged; the feature roster
preserves its parent plus ten groups and one selected historical rename.
Strict all-target Clippy passes for Rust 1.88 default and `raster-bridge`, and
Rust 1.99 with `test262-host,vulkan-raster`; formatting also passes.

The Vulkan-only release build passes. Both hardware attempts refused the same
3825×2085 compositor tile at the presenter's existing four-megapixel surface
cap, before a selected native scene or correctness frame. The second attempt
could not complete owned-window control before startup exited and released no
HTML body. Both left zero descendants. NVIDIA RTX 4070 SUPER / `Bgra8Unorm`
recognition is observed; actual GPU correctness remains unverified here.

The final source inventory is byte-exact with candidate 2 and covers **1,838
selected inputs**, not a complete build graph. Existing JavaScript conformance
profiles were not rerun for this native-only change.

See the [evidence manifest](evidence/vulkan-line-accounting/manifest.json) and
[source/check archive](evidence/vulkan-line-accounting/sources-and-checks.tar.gz).
The complete prior validation body below remains byte-exact.

'''
old=before['docs/VALIDATION.md'];header='# Validation record\n\n';assert old.startswith(header);put('docs/VALIDATION.md',header+validation+old[len(header):])
files=[]
for rel in paths+['docs/vulkan-line-accounting.md']:
 raw=H/'raw'/rel;old=before.get(rel,'');patch=''.join(difflib.unified_diff(old.splitlines(True),raw.read_text().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel));p=H/'diff'/(rel+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(patch)
 files.append({'relative_path':rel,'before':bind(H/'before'/rel)if old else None,'raw':bind(raw),'diff':bind(p)})
assert (H/'raw/docs/VALIDATION.md').read_text().endswith(before['docs/VALIDATION.md'][len(header):])
status={'status':'final documentation content; exact source-ready seal is separate','base':base,'files':files,'actual_bindings':[bind(G/r)for r in ['root/parent-results-1.json','root/compiler-correction-1/receipt.json','validation/candidate-lines-1.json','public-tests-1/source-ready.json','browser-witness-1/source-ready.json','review-production-1/review.json','source-candidate-1.json','source-candidate-2.json','root/full-suite-validation-1.json','root/literal-lint-correction-1/receipt.json','root/full-suite-validation-2.json','validation/candidate-lines-2.json','validation/default-clippy-1.json','validation/msrv-bridge-clippy-1.json','validation/host-vulkan-clippy-2.json','validation/format-check-1.json','validation/vulkan-release-build-1.json','hardware-check-1/result.json','hardware-check-1/native-check.stdout.log','hardware-check-1/native-check.stderr.log','hardware-check-2/result.json','hardware-check-2/native-check.stdout.log','hardware-check-2/native-check.stderr.log','hardware-check-2/owned-control.json','root/final-validation.json','source-final.json']],'pending':[],'historical_validation_suffix_exact':True,'source_reads':'Published parent Git bytes for all five existing documentation paths; source/metric contracts and actual focused receipts only','no_live_edits_or_project_execution':True}
(H/'draft-status.json').write_text(json.dumps(status,indent=2)+'\n')
print('draft six paths; chapter words',len(chapter.split()))
