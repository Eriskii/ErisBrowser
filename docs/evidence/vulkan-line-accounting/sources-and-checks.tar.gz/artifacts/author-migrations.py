import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

G=Path('/tmp/eris-vulkan-line-accounting-plan-1')
W=G/'worktree'
BASE='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
H=G/'migrations-1'
P=G/'source-plan-1'
H.mkdir(exist_ok=False)
P.mkdir(exist_ok=False)

def sha(data): return hashlib.sha256(data).hexdigest()
def put(root,path,data):
    p=root/path
    p.parent.mkdir(parents=True,exist_ok=True)
    assert not p.exists(),p
    p.write_bytes(data)
    return {'path':str(p.relative_to(G)), 'bytes':len(data),'sha256':sha(data)}
def js(root,path,value): return put(root,path,(json.dumps(value,indent=2,ensure_ascii=False)+'\n').encode())
def published(path):
    data=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=W)
    assert data==(W/path).read_bytes(),path
    return data

all_chunks=[]
files=[]
rosters=[]
def migrate(path,edits,reason):
    before=published(path)
    text=before.decode()
    chunks=[]
    for label,old,new in edits:
        assert old!=new and text.count(old)==1,(path,label,text.count(old))
        text=text.replace(old,new,1)
        chunks.append({'label':label,'before':old,'after':new})
    raw=text.encode()
    inverse=text
    for c in reversed(chunks):
        assert inverse.count(c['after'])==1,(path,c['label'])
        inverse=inverse.replace(c['after'],c['before'],1)
    assert inverse.encode()==before
    before_tests=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',before.decode())
    after_tests=re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(',text)
    rosters.append({'path':path,'before':before_tests,'after':after_tests})
    refs=[put(H,'before/'+path,before),put(H,'raw/'+path,raw)]
    patch=''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    refs.append(put(H,'diff/'+path+'.patch',patch.encode()))
    files.append({'path':path,'reason':reason,'artifacts':refs,'exact_inverse':True})
    all_chunks.append({'path':path,'chunks':chunks})

prefix='src/graphics/raster_bridge/native/'
migrate(prefix+'rect_accounting_tests.rs',[
 ('fee_comment','    // Line and opacity markers retain their existing full-frame fees.\n','    // Empty Line geometry costs zero; opacity markers retain full-frame fees.\n'),
 ('zero_line_geometry', '''                width: 0.0,
            },
            262_144,
''','''                width: 0.0,
            },
            0,
'''),
], 'Only empty Line work262144->0; full Rect exact/excess, missing Image and all opacity assertions remain exact.')

migrate(prefix+'image_accounting_tests.rs',[
 ('literal_sum','    assert_eq!(scene.stats().cpu_pixel_upper_bound, 27); // 2*8 opacity + 1 image + 8 line + 2 rect\n','    assert_eq!(scene.stats().cpu_pixel_upper_bound, 20); // 2*8 opacity + 1 image + 1 line + 2 rect\n'),
], 'One-pixel Line now1 instead of8; all other command quantities and independent GPU refusal remain exact.')

migrate(prefix+'scope_accounting_tests.rs',[
 ('full_frame_line_quota_fixture','''        DrawCommand::Line {
            x1: 0.0,
            y1: 0.0,
            x2: 0.0,
            y2: 0.0,
            color: Color::TRANSPARENT,
            width: 0.0,
        },
''','''        // Line uses its full-frame bounding rectangle for the same quota.
        DrawCommand::Line {
            x1: 0.0,
            y1: 0.0,
            x2: 250.0,
            y2: 200.0,
            color: Color::TRANSPARENT,
            width: 0.0,
        },
'''),
], 'Preserve50000 per quota primitive,1000000 shared across phases,100 original commands and21st primitive refusal. Only Line fixture endpoints change.')

box_edits=[
 ('global_fee_fixture','''fn line_commands(first: DrawCommand, lines: usize) -> Vec<DrawCommand> {
    let mut commands = vec![first];
    for _ in 0..lines {
        commands.push(DrawCommand::Line {
            x1: 0.0,
            y1: 0.0,
            x2: 1.0,
            y2: 0.0,
            width: 1.0,
            color: Color::BLACK,
        });
    }
    commands
}
''','''fn opacity_commands(first: DrawCommand, pairs: usize) -> Vec<DrawCommand> {
    let mut commands = vec![first];
    for _ in 0..pairs {
        commands.push(DrawCommand::PushOpacity { opacity: 1.0 });
        commands.push(DrawCommand::PopOpacity);
    }
    commands
}
'''),
 ('test_name','fn full_area_line_debt_is_global_before_any_box_window_preparation() {','fn full_area_opacity_debt_is_global_before_any_box_window_preparation() {'),
 ('exact_debt','line_commands(box_command(0.0, 0.0, [[0.0; 2]; 4]), 16)','opacity_commands(box_command(0.0, 0.0, [[0.0; 2]; 4]), 8)'),
 ('no_remainder_debt','line_commands(box_command(4.0, 2.0, [[2.0, 1.0]; 4]), 16)','opacity_commands(box_command(4.0, 2.0, [[2.0, 1.0]; 4]), 8)'),
 ('order_comment','''    // sixteen Lines leave no work for its first debit. All samples stay inside.
    // One extra Line still fails globally before visiting the first Box command.
''','''    // sixteen opacity markers leave no work for its first debit. All samples stay inside.
    // An extra balanced pair fails globally before visiting the first Box command.
'''),
 ('mask_debt','line_commands(box_command(1000.0, 264.0, [[0.125; 2]; 4]), 16)','opacity_commands(box_command(1000.0, 264.0, [[0.125; 2]; 4]), 8)'),
 ('forced_mask_debt','line_commands(forced_mask, 16)','opacity_commands(forced_mask, 8)'),
 ('excess_debt','line_commands(box_command(1000.0, 264.0, [[0.125; 2]; 4]), 17)','opacity_commands(box_command(1000.0, 264.0, [[0.125; 2]; 4]), 9)'),
]
migrate(prefix+'box_prepass_tests.rs',box_edits,
 'Preserve global non-Line precharge and every original Box shape/assertion/fallback location.8 balanced unit-opacity pairs charge16*264000=4224000 globally;9 pairs charge4752000 and reject globally before Box. Original Line-before/after-Box behavior is intentionally selected to change and receives independent new controls. No cap or production change.')

js(H,'chunks.json',{'schema':1,'base':BASE,'files':all_chunks})
old_name='full_area_line_debt_is_global_before_any_box_window_preparation'
new_name='full_area_opacity_debt_is_global_before_any_box_window_preparation'
all_before=[n for r in rosters for n in r['before']]
all_after=[n for r in rosters for n in r['after']]
assert sorted(new_name if n==old_name else n for n in all_before)==sorted(all_after)
js(H,'roster.json',{'schema':1,'new_tests':0,'removed_tests':0,'renames':[{'path':prefix+'box_prepass_tests.rs','before':old_name,'after':new_name}],'all_other_test_names_exact':True,'files':rosters})
selection=(G/'root/selection-1.json').read_bytes()
manifest=js(H,'source-ready.json',{'schema':1,'status':'sealed historical migrations; unexecuted','author':'/root/layout','base':BASE,'selection_sha256':sha(selection),'affected_files':4,'affected_groups':4,'new_groups':0,'renamed_groups':1,'files':files,'chunks':{'path':'migrations-1/chunks.json','sha256':sha((H/'chunks.json').read_bytes())},'roster':{'path':'migrations-1/roster.json','sha256':sha((H/'roster.json').read_bytes())},'checks':{'all_before_git_exact':True,'all_inverses_exact':True,'non_line_assertion_bytes_preserved_except_mixed_sum':True,'project_execution':False,'live_edits':False},'qualification':'Box global-order fixture is intentionally moved to unchanged opacity fees. New original-order Line accounting is separate, and its frozen independent tests precede production.'})

native='src/graphics/raster_bridge/native.rs'
native_data=published(native)
plan=js(P,'plan.json',{
 'schema':1,'status':'production plan only; wait for independent metric/public seal before source authoring',
 'base':BASE,'native_source':{'path':native,'bytes':len(native_data),'sha256':sha(native_data)},
 'selection_sha256':sha(selection),
 'edits':[
  'Exclude Line from full_area_commands only; preserve original scalar/derived geometry validation, original/nontext counters and opacity precharge.',
  'Add Line to geometry_pixel_work relevant-phase predicate so Line-only phases replay existing CoordinateState.',
  'Share the existing Rect geometry arm with Line by selecting its core Rect: existing Rect converts its fields unchanged, Line calls existing line_rect with original index and phase-mapped errors. Then keep the existing offset-once/zero-radius RoundedTiles/checked charge body unchanged.',
  'Remove Line from the later ignored Text arm; Text remains ignored by this nontext geometry pass. Update only directly stale comments.',
 ],
 'unchanged':['final Line lowering','line_rect body','Canvas and raster-core helpers','preparation_peak_bytes formula','all caps','shaders','presenter and buffer ownership','non-Line ordering and tariffs'],
 'new_interfaces':[],
 'ordering':'Line moves from global precharge to original-order scalar geometry debit; retain one total budget before fonts. A preceding Box may perform its already-funded preparation before a later Line refusal. Disclose/test this selected change.',
 'temporary_storage':'Reuse one existing bounded CoordinateState vector per relevant phase, drop before lowering; no per-Line allocation/cache or mask. Newly reached Line-only reserve refusal remains whole-scene.',
 'migration_hold':manifest,
 'gates':['Independent metric/public literal contract seal from HTML before production payload authoring','Root source peer/import/execution only'],
})
js(P,'source-ready.json',{'schema':1,'status':'sealed source/migration plan, not implementation','base':BASE,'plan':plan,'migrations':manifest,'author_script_sha256':sha(Path(__file__).read_bytes()),'project_execution':False,'live_edits':False})
print(json.dumps({'migrations':manifest,'plan_seal_sha256':sha((P/'source-ready.json').read_bytes())},indent=2))
