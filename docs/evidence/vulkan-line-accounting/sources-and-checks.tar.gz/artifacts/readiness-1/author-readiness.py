import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUT = Path('/tmp/eris-vulkan-next-readiness-1')
BASE = '058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
INITIAL_BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def write(name, value):
    path = OUT / name
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

def digest(path):
    data = path.read_bytes()
    return {'path': str(path.relative_to(OUT)), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

paths = [
    'src/presenter.rs', 'src/presenter/vulkan.rs', 'src/presenter/vulkan/native.rs',
    'src/presenter/vulkan/control.rs', 'src/presenter/vulkan/transfer.rs',
    'src/browser.rs', 'src/browser/native_scene.rs', 'src/browser/native_benchmark.rs',
    'src/browser/native_benchmark_identity.rs', 'src/browser/native_benchmark_report.rs',
    'src/graphics.rs', 'src/layout.rs', 'src/graphics/raster_bridge.rs',
    'src/graphics/raster_bridge/native.rs', 'src/graphics/gradient.rs',
    'src/graphics/box_decoration/native.rs', 'src/graphics/box_decoration/native/core.rs',
    'src/graphics/raster_bridge/native/tests.rs',
    'src/graphics/raster_bridge/native/rect_accounting_tests.rs',
    'src/graphics/raster_bridge/native/image_accounting_tests.rs',
    'src/graphics/raster_bridge/native/image_loop_differential_tests.rs',
    'src/graphics/raster_bridge/native/scope_accounting_tests.rs',
    'src/graphics/raster_bridge/native/box_prepass_tests.rs',
    'crates/raster-core/src/lib.rs', 'crates/raster-core/src/profile.rs',
    'crates/raster-core/src/scope.rs', 'crates/raster-core/src/rounded.rs',
    'crates/raster-core/src/gpu.rs', 'crates/raster-core/src/gpu/reuse.rs',
    'crates/raster-core/src/surface/reuse.rs', 'crates/raster-core/README.md',
    'docs/vulkan-rendering.md', 'docs/vulkan-native-window.md',
    'docs/vulkan-gradients.md', 'docs/vulkan-full-opacity.md',
    'docs/vulkan-rounded-core.md', 'docs/native-rect-accounting.md',
    'docs/native-image-accounting.md', 'docs/native-render-benchmark.md',
    'docs/evidence/vulkan-native-buffer-reuse.json',
]
bindings = []
for name in paths:
    data = (ROOT / name).read_bytes()
    original = subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT)
    assert data == original, name
    assert original == subprocess.check_output(['git', 'show', f'{INITIAL_BASE}:{name}'], cwd=ROOT), name
    git_blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    published = subprocess.check_output(['git', 'rev-parse', f'{BASE}:{name}'], cwd=ROOT).decode().strip()
    assert git_blob == published
    bindings.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'git_blob': git_blob})
write('source-bindings.json', {
    'schema': 1, 'base_commit': BASE, 'initial_inspection_base': INITIAL_BASE, 'checked_files': len(bindings),
    'base_refresh': 'All bound renderer and historical evidence bytes are unchanged between the initial f311 inspection and published class checkpoint 058b4c5f.',
    'method': 'Read-only Git show and byte comparison, SHA-256 and independently formed Git blob SHA-1; no project import or execution.',
    'files': bindings,
})

geometry = {
    'schema': 1, 'status': 'source-derived proposal; unimplemented and unexecuted',
    'original_semantics': {
        'sources': ['src/graphics/raster_bridge.rs:244', 'src/graphics.rs:930'],
        'shape': 'Line is currently a zero-radius bounding rectangle, including diagonal lines. It is not a geometric stroked segment.',
        'f32_order': ['x = min(x1,x2)', 'y = min(y1,y2)', 'width = max(abs(x2-x1), stroke_width)', 'height = max(abs(y2-y1), stroke_width)', 'add active offset to x and y exactly once, after deriving the rectangle'],
        'width_edges': 'Finite negative stroke_width is accepted under the existing scalar cap: abs endpoint differences dominate it. A zero extent then makes the rectangle empty. Coincident endpoints with positive width produce a square. Preserve signed-zero/min/max behavior by reusing the existing helper.',
        'validation': 'All five original scalars must be finite and abs <= 1,000,000. Validate all four derived rectangle scalars under the same cap before translation. Opposite endpoints may individually pass but their difference exceed the cap; this remains InvalidGeometry at the original command/phase, including hidden input.',
    },
    'coordinate_state': {
        'source': 'crates/raster-core/src/scope.rs:26',
        'initial': 'Validate frame, normalize caller clip against [0,width) x [0,height), use document_offset.',
        'clip': 'PushClip validates original geometry, intersects current clip with the rectangle translated by the active offset, then normalizes against the viewport. PopClip restores the old clip.',
        'fixed': 'PushFixed saves both clip and offset, resets clip to caller and offset to viewport_offset; PopFixed restores both. Fixed scope escapes the enclosing document clip exactly as the existing state does.',
        'opacity': 'Opacity changes no coordinate geometry; retain typed scope checks, finite [0,1] validation and existing full-frame fees for both markers, including empty/zero/unit groups.',
        'phase': 'Fresh state per phase; <=4 phases and <=256 original commands across all phases, not 256 per phase. One fallible MAX_SCOPES=32 vector lives at a time.',
    },
    'pixel_loop_bound': {
        'sources': ['src/graphics.rs:569', 'crates/raster-core/src/rounded.rs:112', 'src/graphics/raster_bridge/native.rs:927'],
        'reuse': 'Reuse RoundedTiles::prepare_native(target, translated_line_rect, state.clip(), 0.0), exactly as Rect accounting. Radius zero returns Empty/ZeroRadius and creates no coverage payload.',
        'validated_range': 'Translated positions admit abs <=2,000,000 and extents abs <=1,000,000. Clips retain the existing geometry validation. All values are finite before emptiness tests.',
        'intersection': 'vx=max(rect.x,clip.x); vy=max(rect.y,clip.y); vw=max(min(rect.x+rect.width,clip.x+clip.width),vx)-vx; vh analogously. Preserve binary32 operation order and reconstructed endpoints.',
        'empty': 'If rect or clip width/height <=0, or visible width/height <=0, reserve zero after validation.',
        'integer_bounds': ['x0 = floor(vx).max(ceil(clip.x)).max(0) as i32', 'y0 = floor(vy).max(ceil(clip.y)).max(0) as i32', 'x1 = ceil(vx+vw).min(frame.width as f32) as i32', 'y1 = ceil(vy+vh).min(frame.height as f32) as i32'],
        'work': 'checked u64 product max(x1-x0,0) * max(y1-y0,0); debit the single shared remaining allowance with checked_sub, before later box classification, masks or glyph preparation.',
        'saturation': 'No new saturating accounting is proposed. Existing float-to-i32 casts remain in the reused helper; admitted finite coordinate ranges stay far inside i32 range, so NaN/saturation cannot hide accepted work. Nonnegative span clipping is the existing max(0), not overflow forgiveness. Preserve the existing allowance clamp and checked integer operations.',
        'conservative': 'Charge geometry even for transparent colors and suppressed zero-opacity descendants. Canvas may return before painting these, so its actual pixel visits are <= the reservation. The reservation precedes blend upper-clip rejection and is not changed-pixel or cropped-mask area.',
    },
    'security_invariant': {
        'pixel': 'Every inner rectangle pixel visit and every opaque span element is covered by the same pre-blend Rect loop_work tariff. For unsuppressed nontransparent valid geometry, the loop span is the same as Canvas; omitted work only lowers actual visits.',
        'not_all_instructions': 'Pixel work is not a bound on every CPU instruction or every outer-y iteration. A fractional clip can give x0==x1 while Canvas still iterates empty rows.',
        'row_bound': {'max_original_commands_total': 256, 'native_max_width': 1280, 'native_max_height': 1024, 'max_empty_outer_row_iterations_per_scene': 262144, 'derivation': 'At most viewport height outer rows per rectangle-like command; at most 256 original commands total. This is an existing structural bound, not a new pixel debit.'},
        'quota': 'cpu_limit=(u64(width)*u64(height)*16).clamp(1_000_000,32_000_000), shared across all phases and glyph work, unchanged. No cap increase, reset per phase, double debit, or alpha-dependent omission.',
        'whole_scene': 'Original complete preflight still validates hidden/malformed tail commands before preparation. Every refusal drops the pending native plan and falls back as a whole; no partially admitted scene is presented.',
    },
    'literal_geometry_examples_for_independent_tests': [
        {'frame': [512,512], 'line': [8,8,32,8,1], 'clip': [0,0,512,512], 'integer_bounds': [8,8,32,9], 'work': 24},
        {'frame': [16,16], 'line': [8,6,2,3,1], 'clip': [0,0,16,16], 'integer_bounds': [2,3,8,6], 'work': 18},
        {'frame': [16,16], 'line': [1,1,4,3,1], 'clip': [0,0,16,16], 'integer_bounds': [1,1,4,3], 'work': 6, 'qualification': 'Current diagonal bounding rectangle behavior.'},
        {'frame': [16,16], 'line': [4,5,4,5,2], 'clip': [0,0,16,16], 'integer_bounds': [4,5,6,7], 'work': 4},
        {'frame': [16,16], 'line': [3,3,3,6,-2], 'clip': [0,0,16,16], 'work': 0, 'qualification': 'Derived width zero; preserve current accepted negative width.'},
        {'frame': [4,4], 'line': [0,0,2,2,0], 'clip': [0.25,0.25,1,1], 'integer_bounds': [1,1,2,2], 'work': 1},
        {'frame': [4,4], 'line': [0,0,2,3,0], 'clip': [0.25,0,0.25,3], 'integer_bounds': [1,0,1,3], 'work': 0, 'canvas_empty_outer_rows': 3},
    ],
    'expected_order_change': 'Line debt moves from global full-area precharge to original-order geometry debit. A Box before a Line may now perform its funded classification before the later Line exhausts the allowance. This is an intentional admission/order difference and must be disclosed; old non-Line order stays exact.',
}
write('geometry-contract.json', geometry)

migrations = [
    {'path': 'src/graphics/raster_bridge/native/rect_accounting_tests.rs', 'function': 'native_rect_accounting_keeps_exact_cpu_limit_and_one_pixel_refusal', 'line': 249, 'change': 'Only zero-size Line expected work262144 ->0 and stale Line-fee comment. Keep all full-Rect exact/one-pixel-over, missing Image=1 and opacity524288 assertions unchanged.'},
    {'path': 'src/graphics/raster_bridge/native/image_accounting_tests.rs', 'function': 'image_accounting_preserves_other_command_fees_and_gpu_limit', 'line': 457, 'change': 'Literal total27 ->20: 2*8 opacity +1 image +1 one-pixel Line +2 Rect. Keep independent GPU-limit refusal and every non-Line quantity unchanged.'},
    {'path': 'src/graphics/raster_bridge/native/scope_accounting_tests.rs', 'function': 'native_scope_accounting_keeps_full_rect_image_line_charges_across_phases', 'line': 144, 'change': 'Change only quota-consumer Line from zero-size to endpoints(0,0)->(250,200), width0. This remains a full-frame bounding rectangle and preserves work50000 per Line,1000000 across two phases,100 original commands and21st-command refusal. Separate new tests preserve the zero-Line semantics.'},
    {'path': 'src/graphics/raster_bridge/native/box_prepass_tests.rs', 'function': 'full_area_line_debt_is_global_before_any_box_window_preparation', 'line': 104, 'change': 'The original contract specifically tests globally prepaid Line debt; it cannot truthfully retain that premise after this change. Preserve its non-Line Box geometry, quota and diagnostics with a separately reviewed replacement debt fixture using8 balanced empty unit-opacity pairs (=16 full-area markers), then9 pairs for aggregate excess. Keep Box first; preserve exact4224000/Box-indexed CpuPaintBudget/forced MaskPreparation/global aggregate refusal. Add independent Line-before/after-Box tests for the selected new order. Rename only with explicit roster mapping; freeze original historical fixture. This migration strategy is proposed, not executed.'},
]
write('migration-census.json', {
    'schema': 1, 'status': 'proposed migrations only; no tests or assertions edited',
    'census_method': 'Source search of DrawCommand::Line and full-area debt through native test modules, then direct function reads.',
    'affected_groups': migrations,
    'preserve_explicitly': ['native_invalid_hidden_geometry_is_not_omitted and its derived-width overflow Line refusal', 'all old pixel literals and core lowering', 'all non-Line fees, independent cap checks, scope rules and fallback diagnostics except the expressly selected Line ordering premise'],
    'documentation': 'Historical native-rect/image/window chapters retain their historical claims. Add a new checkpoint/cross-link and current summary; do not silently rewrite old evidence or numeric results.',
})

evidence = json.loads((ROOT/'docs/evidence/vulkan-native-buffer-reuse.json').read_bytes())
assert evidence['offscreen']['frames'] == 84 and evidence['offscreen']['successful_frame_reuses'] == 45
assert evidence['comparison']['total_timed_frames'] == 96
assert evidence['comparison']['checked_bytes_each'] == 4505600
readiness = {
    'schema': 1, 'title': 'Native Vulkan Line admission readiness',
    'status': 'source-bound proposal; no implementation, new tests, build, execution or benchmark',
    'authored_date': '2026-10-15', 'base_commit': BASE,
    'base_refresh': 'All bound renderer/evidence inputs are byte-exact to initial f311 inspection and published class checkpoint058b4c5f. Root selected Line geometry accounting as the next focus; no implementation/test authoring or execution is claimed here. No frozen class artifacts were edited.',
    'recommendation': 'Replace the full-frame CPU reservation per display-list Line with the existing clipped zero-radius rectangle-loop bound. This is a small admission improvement with a concrete source-derived refusal witness; it is not a demonstrated performance optimization.',
    'why_this_feature': 'Canvas and native lowering already draw Line as the same bounding rectangle. Text underline and line-through generate Line per text fragment (src/layout.rs:3540). The coarse full-frame reserve can therefore reject many small decorations before a bounded native plan is prepared.',
    'unexecuted_witness': {'frame': [512,512], 'lines': 40, 'each_integer_visible_rect': [24,1], 'old_cpu_reservation': 10485760, 'unchanged_cpu_allowance': 4194304, 'proposed_line_reservation': 960, 'derivation': '40*512*512 versus40*24*1; no fonts or opacity in the minimal fixture.', 'limits': 'Admission of the complete core/window scene remains unobserved. Other command, invocation, source, glyph, storage and viewport limits still apply. No GPU byte/pixel/timing result is inferred.'},
    'current_renderer': [
        {'capability': 'Optional Linux custom WGSL raster/composite/conversion into the acquired Vulkan window texture', 'source': 'docs/vulkan-rendering.md:3', 'limit': 'Software remains default and headless; --presenter=vulkan alone uploads CPU pixels. Native selection requires vulkan-raster plus --raster=gpu. Whole-scene CPU fallback on refusal.'},
        {'capability': 'Ordered rectangles, nearest-neighbor images/background images, glyph masks, typed clip/fixed scopes and finite [0,1] group opacity', 'source': 'crates/raster-core/src/lib.rs; src/graphics/raster_bridge/native.rs', 'limit': 'Fonts and rounded coverage are CPU prepared; native normal frames have no full CPU target/readback. No full CSS/compositing/shaping claim.'},
        {'capability': 'Rounded color rectangles and box decorations with bounded masks/core decomposition', 'source': 'src/graphics/box_decoration/native.rs; native/core.rs', 'limit': 'Image/gradient BoxDecoration requires an existing full rectangular-coverage proof; generic rounded background images remain unsupported.'},
        {'capability': 'Opaque linear gradients', 'source': 'src/graphics/raster_bridge/native.rs:349; src/graphics/gradient.rs', 'limit': 'Regular gradient radius0, opaque stops, outside retained opacity scope. CPU evaluates the fragment and GPU copies/composites it; this is not GPU gradient evaluation.'},
        {'capability': 'One exact-size retired-buffer lease reuse', 'source': 'src/presenter/vulkan/native.rs; crates/raster-core/src/gpu/reuse.rs', 'limit': 'Positive completion/scopes/presentation needed before reuse. Each frame still prepares a fresh plan, rewrites inputs and performs clear/draw/conversion; no retained coverage/plan cache.'},
    ],
    'minimal_production_seams': [
        'src/graphics/raster_bridge/native.rs::preflight: exclude Line from full_area_commands while preserving complete original validation, nontext/original slot counts and line_rect checks.',
        'geometry_pixel_work: include Line in relevant-phase detection and visit it in original order through existing CoordinateState. Derive with line_rect, translate once, reuse zero-radius RoundedTiles bound, checked shared charge_geometry.',
        'Keep final Line -> Command::Rect lowering, Canvas, raster-core helpers, shaders, presenter, all limits and preparation_peak_bytes formula byte-exact unless a concrete independently reviewed defect requires separate selection.',
    ],
    'allocation_and_refusal': 'A Line-only phase newly reaches the existing fallible MAX_SCOPES coordinate vector. It is released before lowering and no Line cache/mask is created. preparation_peak_bytes already reserves a second complete core metadata allowance for this state and vector (native.rs:1287). Keep formula exact, test this newly reached refusal as whole-scene fallback. Scalar validation remains before omission; one shared quota remains across phases/glyphs.',
    'unchanged_caps': {'native_viewport': [1280,1024], 'original_commands_total': 256, 'phases': 4, 'scopes': 32, 'padded_gpu_invocations': 4000000, 'gpu_buffers_bytes': 16777216, 'native_with_readback_bytes': 25165824, 'presenter_bytes': 134217728, 'qualification': 'Explicit resource budgets, not complete RSS/VRAM/driver-allocation bounds; see source bindings.'},
    'existing_evidence': {
        'tests': ['native_rect_accounting_uses_preblend_bounds_and_preserves_fractional_pixels', 'native_rect_accounting_tracks_scopes_phases_and_validates_hidden_tails', 'native_rect_accounting_keeps_exact_cpu_limit_and_one_pixel_refusal', 'native_rect_accounting_shares_exact_remaining_glyph_work_between_phases', 'native_image_reservation_matches_the_actual_canvas_loop_debit'],
        'historical_measurements': 'Retained native-buffer-reuse evidence has84 offscreen frames on3 adapters,45 successful reuses,18 cancellation guards and4680 literal comparison bytes. Its acquired-window comparison has2 separate correctness processes comparing4505600 bytes each and6 timing processes/96 frames on one NVIDIA surface. These are historical observations for buffer reuse, not Line outcomes or a current benchmark.',
        'measurement_limits': evidence['limits'],
        'bottleneck_qualification': 'Source shows per-draw compute passes, full input rewrites and an exact-submission wait. Existing records do not isolate them as the present dominant cost. Do not remove ordering/synchronization or assert a bottleneck from source alone.',
    },
    'required_validation_before_claims': [
        'Freeze independent literal geometry/work/pixel oracles before producer execution; derive expected spans from hand-selected inputs, not by calling or copying the producer estimator. Compare actual Canvas pixel debit as a secondary differential witness. Cover fractional clips including zero-pixel/nonzero-row case.',
        'Cover reversed/diagonal/coincident endpoints, positive/zero/negative widths, binary32 reconstruction, translation only once, nested fixed/clip restore, multiple phases and zoom; validate NaN/infinities/over-limit original scalars and derived width even when hidden.',
        'Prove exact allowance and one-pixel excess, same remaining glyph quota, alpha/zero-opacity conservative fees, hidden malformed tails, Line-only state reserve refusal and full fallback. Preserve non-Line tests and explicitly review original-order Line versus Box reservation.',
        'Run parent refusal and candidate admission on the frozen forty-Line fixture; compare literal pixels, Canvas and CPU-decoded complete ordered packed plans. For previously admitted inputs compare full plan parameter/input bytes, not just an aggregate hash/count.',
        'Add a small real underline/strike-through Page and confined-worker scene with fixed identities, hit/click behavior and complete pixels. Record actual emitted Lines and all browser/font/chrome contributions instead of assuming the minimal synthetic reservation predicts the full scene.',
        'Run appropriate default/native-feature Rust suites, existing raster-core/bridge tests, strict Clippy and formatting; retain all failed attempts, selected narrow migration inverses and exact source/binary bindings. Root owns execution.',
        'If claiming GPU/window operation for the new scene, perform independent offscreen literal comparison and acquired-window readback with current rebuilt release, separate from reference-free normal native run. No screenshot substitution for GPU evidence.',
        'Only after correctness, optionally select a controlled release A/B with equivalent scene identity, viewport/scale, adapter/format/mode and retained raw failures/tails. Label changed CPU-fallback/native routes explicitly. Separate correctness from timing and first/subsequent samples.',
    ],
    'chromium_target': 'Unfulfilled. Existing host timestamps are not GPU timestamps, compositor latency or throughput. A Chromium comparison needs a separately selected matched workload/output/behavior harness, same hardware and assets/fonts/viewport/scale, explicit cold/warm boundaries, releases and raw distributions across representative pages. This readiness makes no Chromium-relative speed, production-security or full-web-compatibility claim.',
    'linked_details': ['geometry-contract.json', 'migration-census.json', 'source-bindings.json'],
}
write('readiness.json', readiness)
files = [digest(OUT / p) for p in ['author-readiness.py','source-bindings.json','geometry-contract.json','migration-census.json','readiness.json']]
write('source-ready.json', {
    'schema': 1, 'status': 'sealed source-only readiness', 'author': '/root/layout',
    'base_commit': BASE, 'files': files,
    'checks': {'published_bytes_exact': len(bindings), 'project_execution': False, 'production_authored': False, 'new_tests_authored': False, 'live_source_writes': False, 'frozen_F_writes': False, 'new_benchmark_or_admission_observations': False},
    'selection': 'Root selected Line geometry accounting as the next implementation focus after publishing058b4c5f. Numeric source-derived witness and proposed migrations remain unexecuted; independent tests and production will be separate holds.',
})
print(json.dumps(digest(OUT/'source-ready.json')))
