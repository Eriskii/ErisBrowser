import ast,difflib,hashlib,json
from pathlib import Path
G=Path('/tmp/eris-vulkan-line-accounting-plan-1')
F=Path('/tmp/eris-class-runtime-plan-1/evidence-tools-1')
H=G/'evidence-tools-1';H.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
DOCS="DOC_PATHS = {'README.md', 'docs/ROADMAP.md', 'docs/SECURITY.md',\n             'docs/VALIDATION.md', 'docs/vulkan-native-window.md',\n             'docs/vulkan-line-accounting.md'}"
OLD_DOCS="DOC_PATHS = {'README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',\n             'docs/SECURITY.md', 'docs/VALIDATION.md', 'docs/classes.md'}"
common='''SOURCE_HOLDS = ('implementation-1/source-ready.json',
                'migrations-1/source-ready.json',
                'public-tests-1/source-ready.json',
                'browser-witness-1/source-ready.json')


def held_path(name):
    assert isinstance(name, str) and name
    path = Path(name)
    path = path if path.is_absolute() else P / path
    relative = path.relative_to(P)
    assert '..' not in relative.parts
    return path


def verify_binding(record):
    path = held_path(record['path'])
    data = regular(path)
    assert sha(data) == record['sha256'], path
    if 'bytes' in record:
        assert len(data) == record['bytes'], path
    return data


def validate_source_holds():
    # Verify frozen source/test payload references, without executing/importing
    # their scripts or the project. Semantic/format joins are final-peer work.
    def visit(value):
        if isinstance(value, dict):
            if 'path' in value and 'sha256' in value:
                verify_binding(value)
            for child in value.values():
                visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)
    for name in SOURCE_HOLDS:
        visit(read(name))
    assert read('review-production-1/review.json')['status'] == 'clear'
    assert read('review-tests-1/compiler-correction-review.json')['status'].startswith('clear')


'''
files=[]
for name in ['publish-evidence.py','verify-publication.py']:
 before=(F/name).read_bytes();s=before.decode()
 for old,new in [
  ('classes evidence publisher','native Line evidence publisher'),
  ('classes checkpoint evidence','native Line checkpoint evidence'),
  ("'docs/evidence/classes'","'docs/evidence/vulkan-line-accounting'"),
  ('docs/evidence/classes/','docs/evidence/vulkan-line-accounting/'),
  (OLD_DOCS,DOCS),
  ("EXCLUDED_TOP = {'worktree', 'publication'}","EXCLUDED_TOP = {'worktree', 'publication', 'target-msrv', 'target-1990'}"),
  ('documentation-2/source-ready.json','documentation-1/source-ready.json'),
  ('source-candidate-2.json','source-candidate-1.json'),
  ('unchanged candidate2 receipts','unchanged candidate1 receipts'),
  ('source_final_equals_candidate2_bytes','source_final_equals_candidate1_bytes'),
  ('All eligible external F holds/receipts','All eligible external G holds/receipts'),
  ('len(changed) == 30','len(changed) == 10'),
  ('len(sources) == 30','len(sources) == 10'),
  ('source_count=30','source_count=10'),
  ('sources=30','sources=10'),
  ('source_paths=30','source_paths=10'),
  ("manifest['source_count'] == 30","manifest['source_count'] == 10"),
  ('len(selection)-36','len(selection)-16'),
  ('len(selected) - 36','len(selected) - 16'),
  ('len(expected_paths) == 38','len(expected_paths) == 18'),
  ('path_count=38','path_count=18'),
 ]:s=s.replace(old,new)
 anchor='def external_files():'
 assert s.count(anchor)==1;s=s.replace(anchor,common+anchor)
 if name=='publish-evidence.py':
  s=s.replace("        assert bind(Path(held['path'])) == held", "        verify_binding(held)")
  s=s.replace("    docs = documentation()", "    validate_source_holds()\n    docs = documentation()")
  anchor="        'documentation_hold': 'documentation-1/source-ready.json',\n"
  extra="        'implementation_hold': 'implementation-1/source-ready.json',\n        'migration_hold': 'migrations-1/source-ready.json',\n        'public_test_hold': 'public-tests-1/source-ready.json',\n        'browser_test_hold': 'browser-witness-1/source-ready.json',\n        'production_peer': 'review-production-1/review.json',\n        'test_peer': 'review-tests-1/review.json',\n        'test_compile_correction_peer': 'review-tests-1/compiler-correction-review.json',\n        'format_review': 'format-review-1/review.json',\n"
  assert s.count(anchor)==1;s=s.replace(anchor,anchor+extra)
 else:
  s=s.replace("    docs = read('documentation-1/source-ready.json')['files']", "    validate_source_holds()\n    docs = read('documentation-1/source-ready.json')['files']")
  s=s.replace("        assert bind(Path(row['raw']['path'])) == row['raw']", "        verify_binding(row['raw'])")
  anchor="                   'documentation_hold': 'documentation-1/source-ready.json'}"
  extra="                   'documentation_hold': 'documentation-1/source-ready.json',\n                   'implementation_hold': 'implementation-1/source-ready.json',\n                   'migration_hold': 'migrations-1/source-ready.json',\n                   'public_test_hold': 'public-tests-1/source-ready.json',\n                   'browser_test_hold': 'browser-witness-1/source-ready.json',\n                   'production_peer': 'review-production-1/review.json',\n                   'test_peer': 'review-tests-1/review.json',\n                   'test_compile_correction_peer': 'review-tests-1/compiler-correction-review.json',\n                   'format_review': 'format-review-1/review.json'}"
  assert s.count(anchor)==1;s=s.replace(anchor,extra)
 ast.parse(s)
 assert 'source-candidate-2' not in s and 'documentation-2' not in s and 'docs/evidence/classes' not in s
 raw=s.encode();(H/name).write_bytes(raw)
 (H/(name+'.before')).write_bytes(before)
 diff=''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='F/'+name,tofile='G/'+name))
 (H/(name+'.diff')).write_text(diff)
 files.append({'path':name,'bytes':len(raw),'sha256':sha(raw),'ancestor':{'path':str(F/name),'bytes':len(before),'sha256':sha(before)},'diff_sha256':sha(diff.encode())})

contract={'status':'held recipe; never executed by author','base':'058b4c5f8c0cd2ce197a64ee262c127c959cf1ed','commands':['python3 /tmp/eris-vulkan-line-accounting-plan-1/evidence-tools-1/publish-evidence.py','python3 /tmp/eris-vulkan-line-accounting-plan-1/evidence-tools-1/verify-publication.py'],
 'preconditions':['Root final ledger status pass; independent final validation peer and documentation peer status clear. All source holds/references verified.','source-final.json byte-identical to source-candidate-1.json; all1838 selected worktree bytes match their final hashes.','Exactly10 changed selected paths and6 selected documentation files; imported docs exactly match documentation-1 raw bindings.','Freeze all eligible G artifacts before execution. Later publication logs/state go only under publication/ or explicit excluded root outputs.','No prior evidence-selection/output files/publication-verification; exclusive writes. Verifier runs before commit with HEAD at published parent.'],
 'evidence':'worktree/docs/evidence/vulkan-line-accounting/{manifest.json,sources-and-checks.tar.gz}',
 'counts':{'sources':10,'docs':6,'evidence':2,'git_paths':18},
 'exclusions':{'top':['worktree','publication','target-msrv','target-1990'],'directories':['__pycache__','.git','target'],'root_outputs':['root/evidence-selection.json','root/publication-verification.json','root/github-publication.json'],'symlinks':'Never followed, including parent directories; accepted files must be regular.','binaries':'Inherited extension/magic exclusions; source/JSON/log/script files including failed/superseded artifacts retained.'},
 'caps':{'raw_bytes':67108864,'gzip_bytes':8388608},
 'verification':'Deterministic sorted USTAR with uid/gid/mtime0,0644 regular members; gzip mtime0. Independently reconstruct membership, verify every origin/byte/hash/role, require exact18 Git paths and git diff --check. No extracting archive entries.',
 'scope':'Selected-input inventory is not the complete build graph. Scripts package actual final claims only; no new execution, GPU, performance, security or CI claim.'}
(H/'execution-contract.json').write_text(json.dumps(contract,indent=2)+'\n')
checks={'status':'source checks clear; no publisher/verifier execution','python_ast_parse':True,'base_scripts_read_only':True,'files':files,'notes':['Retains all eligible external attempts, not merely latest passing receipts.','New source-hold reference validation reads bytes only. Both scripts bind identical twelve authority paths.','Relative and absolute held document paths under G accepted without weakening byte checks.','Explicit G target directory exclusions prevent scanning build trees even if symlinks become real directories.','All artifact inputs must stop changing before packing; verifier rejects late eligible files or drift.']}
(H/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
members=[]
for p in sorted(H.iterdir()):
 b=p.read_bytes();members.append({'path':str(p.relative_to(G)),'bytes':len(b),'sha256':sha(b)})
seal={'schema':1,'status':'sealed held evidence scripts; unexecuted','author':'/root/layout','base':contract['base'],'files':members,'source_checks':'evidence-tools-1/source-checks.json','execution_contract':'evidence-tools-1/execution-contract.json','author_script_sha256':sha(Path(__file__).read_bytes()),'no_live_edits':True,'no_project_or_publisher_execution':True}
(H/'source-ready.json').write_text(json.dumps(seal,indent=2)+'\n')
print(json.dumps({'path':str(H/'source-ready.json'),'sha256':sha((H/'source-ready.json').read_bytes())},indent=2))
