#!/usr/bin/env python3
"""Root-only evidence checker. No project imports, builds, tests or hardware launch."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import math
import re
import sys

P = Path(__file__).resolve().parents[1]
MAX_OUTPUT = 2 * 1024 * 1024
SOURCE_SHA = '30058ce5e45580fcb791372895e6e6898764b229c327011c233301fcf688066c'
GATE_SHA = 'deb7729114c368a86027a5939d6297afdfaf332e676ec8a048e602cf189653a7'
POSTCHECK = 'all selected source, helper, binary, fixture, loader and ICD bindings exact'


def require(value, message):
    if not value:
        raise ValueError(message)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def unique(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def decode(raw):
    def invalid(value):
        raise ValueError('nonfinite JSON constant: ' + value)
    return json.loads(raw, object_pairs_hook=unique, parse_constant=invalid)


def read(path, cap=4 * 1024 * 1024):
    require(path.is_file() and path.stat().st_size <= cap, 'missing/oversized JSON: ' + str(path))
    return decode(path.read_bytes())


def same(left, right):
    # JSON canonical comparison distinguishes bool from int and preserves null/types.
    return json.dumps(left, sort_keys=True, allow_nan=False) == json.dumps(right, sort_keys=True, allow_nan=False)


def bind(path):
    require(path.is_file() and path.stat().st_size <= 128 * 1024 * 1024, 'file bound: ' + str(path))
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}


def verify(row):
    require(type(row) is dict and same(bind(Path(row['path'])), row), 'binding differs: ' + str(row))
    return Path(row['path'])


def receipt(label):
    path = P / 'validation' / (label + '.json')
    row = read(path)
    require(type(row['exit']) is int and row['exit'] == 0, 'unsuccessful receipt: ' + label)
    log = path.with_name(row['log'])
    require(bind(log)['sha256'] == row['sha256'], 'log hash: ' + label)
    return {'receipt': bind(path), 'log': bind(log), 'command': row['command']}


def roster(log, full):
    text = log.read_text()
    results = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    tests = re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:[^\n]*)$', text, re.M)
    require(results and all(row[0] == 'ok' and all(int(n) == 0 for n in row[2:5]) and (not full or int(row[5]) == 0) for row in results), 'nonpassing result row')
    names = [name for name, status in tests]
    require(all(status == 'ok' for _, status in tests) and len(names) == sum(int(row[1]) for row in results), 'roster/result count')
    require(all(count == 1 for count in Counter(names).values()), 'duplicate roster identity')
    return set(names), len(results)


def failed_hardware(number, binary, source, manifest):
    folder = P / ('hardware-check-' + str(number))
    held = P / ('hardware-runner-' + str(number))
    sealed = read(held / 'source-ready.json')
    if number == 2:
        require(bind(held / 'source-ready.json')['sha256'] == GATE_SHA, 'selected gate seal')
    for row in sealed['files']:
        verify(row)
    inputs = read(folder / 'inputs.json')
    result = read(folder / 'result.json')
    supervisor = read(folder / 'native-check.json')
    contract = read(held / 'contract.json')
    require(same(inputs['source']['inventory'], bind(source)), 'hardware source inventory')
    require(inputs['source']['selected_inputs'] == len(manifest['source_sha256']) and inputs['source']['qualification'] == manifest['scope'], 'hardware source scope')
    require(same(inputs['source']['unchanged_helper_sha256'], contract['unchanged_helper_sha256']), 'helper set')
    require(contract['base'] == manifest['base'], 'hardware base')
    for name, digest in contract['unchanged_helper_sha256'].items():
        require(bind(P / 'worktree' / name)['sha256'] == digest, 'helper bytes')
    for key in ('binary', 'fixture', 'runner', 'contract'):
        verify(inputs[key])
    require(Path(inputs['binary']['path']).resolve() == Path(binary['binary']['path']).resolve(), 'executable resolved path')
    require(inputs['binary']['sha256'] == binary['binary']['sha256'] and inputs['binary']['bytes'] == binary['binary']['bytes'], 'executable provenance')
    require(same(inputs['fixture'], bind(P / 'worktree/examples/vulkan-lines.html')) and inputs['fixture']['sha256'] == contract['fixture_sha256'], 'fixture provenance')
    require(same(inputs['runner'], bind(held / 'run-hardware.py')) and same(inputs['contract'], bind(held / 'contract.json')), 'held runner/contract')
    require(same(inputs['runtime_files'], contract['runtime_files']), 'runtime list')
    for row in contract['runtime_files']:
        verify(row)
    recipe = read(verify(contract['hardware_command']))
    require(same(inputs['environment_overrides'], recipe['run_environment']), 'environment recipe')
    require(same(inputs['timeout_seconds'], 45) and same(inputs['output_limit_bytes'], MAX_OUTPUT) and same(inputs['cleanup_seconds'], 5), 'selected hardware limits')
    require(result['status'] == 'failed' and result['hardware_claim'] is False and result['postcheck'] == POSTCHECK, 'failed attempt qualification/postcheck')
    require('postcheck_error' not in result and 'evidence' not in result and 'owned_control' not in result, 'no success evidence')
    require(same(result['supervisor'], dict(supervisor, name='native-check')), 'result/raw supervisor equality')
    require(supervisor['status'] == 'exited' and same(supervisor['returncode'], 1), 'expected process refusal')
    require(supervisor['cleanup']['complete'] is True and same(supervisor['cleanup']['descendants'], 0) and same(supervisor['cleanup']['checker_returncode'], 1) and supervisor['cleanup']['error'] is None, 'clean refusal teardown')
    require(supervisor['error'] is None and supervisor['cancellation_signal'] is None, 'supervisor error/cancellation')
    require(same(supervisor['command'], inputs['command']) and supervisor['timeout_seconds'] == 45.0 and supervisor['cleanup_seconds'] == 5.0, 'supervisor command/limits')
    stdout = (folder / 'native-check.stdout.log').read_bytes()
    stderr = (folder / 'native-check.stderr.log').read_bytes()
    require(sha(stdout) == supervisor['stdout_sha256'] and sha(stderr) == supervisor['stderr_sha256'], 'captured output hashes')
    total = len(stdout) + len(stderr)
    require(type(supervisor['captured_bytes']) is int and type(supervisor['observed_bytes']) is int and total == supervisor['captured_bytes'] == supervisor['observed_bytes'] <= MAX_OUTPUT, 'captured output bound')
    require(same(supervisor['output_limit_bytes'], MAX_OUTPUT), 'supervisor output cap')
    require((folder / 'native-check.supervisor.stderr.log').read_bytes() == b'', 'outer supervisor stderr')
    require(stdout.endswith(b'\n') and stdout.count(b'\n') == 1, 'one complete report')
    report = decode(stdout)
    expected = {'schema': 1, 'kind': 'native-benchmark', 'mode': 'check', 'route': 'native-raster', 'requested_frames': 1, 'completed_frames': 0, 'accepted_frames': 0, 'scene_hex': '', 'width': 3825, 'height': 2085, 'generation': 1, 'viewport_revision': 3, 'scale_factor': 1, 'source_load_ms': None, 'edit_sequence': 0, 'diagnostics': 0, 'checked': False, 'failure': 'Vulkan target exceeds the four-megapixel/8192-axis budget', 'owner_failure': None, 'owner_init_ns': None, 'samples': []}
    require(same(report, expected), 'retained actual refusal report/types differ')
    text = stderr.decode('utf-8', errors='strict')
    require(text.endswith('\n') and len(text.splitlines()) <= 4096 and all(len(line) <= 16384 for line in text.splitlines()), 'stderr framing')
    require(text.count('presenter: Vulkan adapter=') == 1 and 'type=DiscreteGpu' in text and expected['failure'] in text, 'adapter/refusal diagnostic')
    require('acquired-texture verified;' not in text and 'verification passed;' not in text and 'native line gate: document released' not in text, 'no verification or document release')
    records = {name: bind(folder / name) for name in ['inputs.json', 'result.json', 'native-check.json', 'native-check.stdout.log', 'native-check.stderr.log', 'native-check.supervisor.stderr.log']}
    if number == 1:
        command = [inputs['binary']['path'], inputs['fixture']['path'], '--presenter=vulkan', '--raster=gpu', '--no-scripts', '--benchmark-native-check', '--exit-after', '15']
        require(same(inputs['command'], command), 'first direct invocation')
    else:
        launch = read(verify(inputs['owned_launch']))
        require(Path(inputs['owned_launch']['path']) == folder / 'launch.json', 'owned launch path')
        verify(contract['controller']); verify(contract['owned_wrapper']); verify(contract['previous_attempt'])
        require(launch['worktree'] == str(P / 'worktree') and launch['binary'] == inputs['binary']['path'] and launch['fixture'] == inputs['fixture']['path'] and launch['receipt'] == str(folder / 'owned-control.json'), 'launch path joins')
        require(launch['binary_sha256'] == inputs['binary']['sha256'] and launch['fixture_sha256'] == inputs['fixture']['sha256'] and launch['controller_sha256'] == contract['controller']['sha256'] and launch['controller'] == contract['controller']['path'], 'launch content joins')
        pins = {str(P / 'worktree' / name): digest for name, digest in contract['unchanged_helper_sha256'].items()}
        pins.update({launch['binary']: launch['binary_sha256'], launch['fixture']: launch['fixture_sha256'], launch['controller']: launch['controller_sha256'], contract['owned_wrapper']['path']: contract['owned_wrapper']['sha256']})
        require(same(pins, launch['pinned_files']), 'complete launch pins')
        for path, digest in pins.items():
            require(bind(Path(path))['sha256'] == digest, 'launch pin bytes')
        require(len(inputs['command']) == 4 and inputs['command'][1:] == [contract['owned_wrapper']['path'], '--launch', str(folder / 'launch.json')], 'wrapper command')
        control = read(folder / 'owned-control.json')
        require(control['success'] is False and control['control_complete'] is False and control['browser_reaped'] is True and same(control['browser_returncode'], 1), 'owned refusal state')
        require(control['error'] == 'ValueError: owned browser exited before window control completed' and not any(k in control for k in ('release', 'controlled_size', 'cleanup_error', 'postcheck_error', 'stderr_drain_error')), 'owned refusal cause')
        require(same(control['requests'], []) and same(control['accepted_connections'], 0), 'no fixture request/release')
        require(len(control['commands']) == 3 and all(row['argv'] == [launch['controller'], '-j', 'clients'] and row['status'] == 'exited' and same(row['returncode'], 0) for row in control['commands']), 'only retained read-only controller queries')
        for key in ('binary_sha256', 'fixture_sha256', 'controller_sha256'):
            require(control[key] == launch[key], 'control input identity')
        require(type(control['port']) is int and 1 <= control['port'] <= 65535, 'loopback port')
        command = [launch['binary'], f"http://127.0.0.1:{control['port']}/admitted.html", '--presenter=vulkan', '--raster=gpu', '--no-scripts', '--benchmark-native-check', '--exit-after', '15']
        require(same(control['browser_command'], command), 'owned browser command')
        records.update({name: bind(folder / name) for name in ('launch.json', 'owned-control.json')})
    return {'status': 'unverified', 'hardware_claim': False, 'records': records, 'runner_hold': bind(held / 'source-ready.json'), 'report': report, 'cleanup_complete': True, 'adopted_descendants': 0, 'verified_frames': 0, 'verified_active_bytes': 0, 'timing_samples': 0}


def main():
    if len(sys.argv) > 1:
        require(len(sys.argv) == 2 and (P / sys.argv[1]).resolve() == (P / 'hardware-check-2').resolve(), 'only selected second attempt argument allowed')
    source = P / 'source-candidate-2.json'
    require(bind(source)['sha256'] == SOURCE_SHA, 'selected candidate2 inventory')
    manifest = read(source)
    require(len(manifest['source_sha256']) == 1838, 'selected input count')
    for name, digest in manifest['source_sha256'].items():
        file = (P / 'worktree' / name).resolve()
        require(file.is_relative_to((P / 'worktree').resolve()) and bind(file)['sha256'] == digest, 'selected source bytes: ' + name)
    checks = {key: receipt(key) for key in ['candidate-lines-2', 'default-full-2', 'host-vulkan-full-2', 'host-vulkan-clippy-2', 'msrv-bridge-clippy-1', 'default-clippy-1', 'format-check-1', 'vulkan-release-build-1']}
    suite = read(P / 'root/full-suite-validation-2.json')
    require(suite['status'] == 'pass' and same(suite['source'], bind(source)), 'suite selected source')
    scaffold = read(P / 'validation-review-1/scaffold-1.json')
    require(bind(P / 'validation-review-1/scaffold-1.json')['sha256'] == '7ac0876a7622ea31201dda171e80d3d2e0fec5159859d05661d755cce78e0193', 'independent expected roster seal')
    for row, previous, label, expected in zip(suite['configurations'], scaffold['parent_rust'], ['default-full-2', 'host-vulkan-full-2'], [3344, 3708], strict=True):
        for side in ('parent', 'candidate'):
            verify(row[side]['receipt']); verify(row[side]['log'])
        require(same(row['candidate']['receipt'], checks[label]['receipt']), 'suite actual receipt')
        old, _ = roster(Path(row['parent']['log']['path']), True)
        new, count = roster(Path(row['candidate']['log']['path']), True)
        require(old == set(previous['names']) and len(new) == expected and count == 54, 'exact full count')
        if label.startswith('host'):
            old.remove(scaffold['rename']['before']); old.add(scaffold['rename']['after'])
            require(new == old | set(scaffold['new_tests']) and not(old & set(scaffold['new_tests'])), 'host exact additions/rename')
        else:
            require(new == old, 'default retained roster')
    focused, _ = roster(Path(checks['candidate-lines-2']['log']['path']), False)
    require(focused == set(scaffold['new_tests']) and len(focused) == 10, 'exact focused names')
    binary = read(P / 'root/release-binary-1.json')
    for key in ('source', 'binary', 'build_receipt', 'build_environment'):
        verify(binary[key])
    require(same(binary['source'], bind(source)) and same(binary['build_receipt'], checks['vulkan-release-build-1']['receipt']), 'release source/build joins')
    require(binary['features'] == ['vulkan-raster'] and binary['profile'] == 'release' and binary['toolchain'] == '1.99.0', 'release config')
    require(checks['vulkan-release-build-1']['command'] == ['cargo', '+1.99.0', 'build', '--locked', '--offline', '--features', 'vulkan-raster', '--release', '--bin', 'eris-browser'], 'exact Vulkan-only build command')
    environment = read(Path(binary['build_environment']['path']))
    require(environment['toolchain'] == '1.99.0' and environment['features'] == ['--features', 'vulkan-raster'], 'build environment config')
    attempts = [failed_hardware(n, binary, source, manifest) for n in (1, 2)]
    final_source = P / 'source-final.json'; ledger = P / 'root/final-validation.json'
    require(not final_source.exists() and not ledger.exists(), 'final outputs must be new')
    final_binding = dict(bind(source), path=str(final_source))
    record = {'status': 'pass', 'scope': 'Tested Native Line CPU planning/accounting checkpoint; hardware correctness remains unverified and the overall browser/performance goal is incomplete.', 'base': manifest['base'], 'source': final_binding, 'selected_inputs': 1838, 'source_final_equals_candidate2': True, 'full_suites': suite, 'checks': checks, 'release_binary': binary, 'hardware': {'status': 'unverified', 'hardware_claim': False, 'attempts': attempts, 'verified_frames': 0, 'verified_active_bytes': 0, 'timing_samples': 0, 'reason': 'Both actual attempts refused compositor size3825x2085 before verification under unchanged target caps; owned-window retry exited before control/document release.'}, 'parent_controls': read(P / 'root/parent-results-1.json'), 'preservation': {'production_files': 1, 'production_chunks': 4, 'limits_lowering_shaders_core_unchanged': True, 'historical_test_migrations': 4, 'historical_test_renames': 1, 'new_public_groups': 9, 'new_loaded_page_groups': 1, 'literal_oracles_preserved': True}, 'observed_page': {'viewport': [512, 512], 'commands': 27, 'text': 9, 'lines': 18, 'line_pixel_work': 360, 'glyph_work': 9, 'total_work': 369, 'old_line_reservation': 4718592, 'unchanged_cpu_limit': 4194304, 'packed_draws': 19, 'padded_invocations': 526592, 'colored_pixels': 360, 'repeated_checks': 2}, 'retained_attempts': ['Parent compile E0271 and unused_mut correction.', 'Observed parent2pass8fail; failed table groups stop at first assertion.', 'Strict lint excessive_precision resolved by scoped attributes without literal changes.', 'Checker rename path correction caught before execution.', 'Both hardware attempts refused oversized compositor tile; complete process teardown, no verified frame.', 'Unexecuted finalizer draft1 assumed hardware success; additive finalizer2 checks actual failures and publishes an explicitly unverified hardware status.'], 'qualifications': ['Pixel work counts inner pixel visits/span elements, not all CPU instructions; structural caps bound empty outer rows.', 'Line/Box refusal attribution now follows original geometry order; complete malformed-input validation still precedes debit.', 'The512x512 CPU-plan/pixel witness is separate from hardware attempts. No successful GPU/readback/compositor correctness claim is made.', 'Source inventory is cumulative selected inputs, not a complete build graph.', 'No Chromium performance comparison, full web compatibility or production-security claim. Unchanged JavaScript conformance profiles were not rerun for this native-only change.'], 'finalizer': bind(Path(__file__).resolve())}
    raw = (json.dumps(record, indent=2, allow_nan=False) + '\n').encode()
    # All selected evidence and serialized ledger are validated before either exclusive output.
    with final_source.open('xb') as output:
        output.write(source.read_bytes())
    with ledger.open('xb') as output:
        output.write(raw)
    print(json.dumps(bind(ledger)))


if __name__ == '__main__':
    main()
