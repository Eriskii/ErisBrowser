import hashlib,json,re,subprocess
from pathlib import Path
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');W=G/'worktree';O=G/'validation-review-1'
F=Path('/tmp/eris-class-runtime-plan-1')
BASE='058b4c5f8c0cd2ce197a64ee262c127c959cf1ed'
sha=lambda b:hashlib.sha256(b).hexdigest()
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def save(name,d):
 p=O/name;assert not p.exists();p.write_text(json.dumps(d,indent=2)+'\n');return binding(p)
def lex(s):
 # Independent limited Rust lexer sufficient for the selected existing/new files.
 # Comments and quoted contents are preserved verbatim; only exterior spacing
 # and optional trailing commas before closing delimiters are normalized.
 tokens=[];comments=[];literals=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   end=s.find('\n',i);end=len(s) if end<0 else end
   comments.append(s[i:end]);i=end;continue
  if s.startswith('/*',i):
   start=i;i+=2;depth=1
   while depth:
    assert i<len(s)
    if s.startswith('/*',i):depth+=1;i+=2
    elif s.startswith('*/',i):depth-=1;i+=2
    else:i+=1
   comments.append(s[start:i]);continue
  raw=re.match(r'(?:br|r)(#*)"',s[i:])
  if raw:
   endmark='"'+raw.group(1);end=s.find(endmark,i+len(raw.group(0)));assert end>=0
   end+=len(endmark);t=s[i:end];tokens.append(t);literals.append(t);i=end;continue
  string=re.match(r'(?:b)?"(?:\\.|[^"\\])*"',s[i:],re.S)
  char=re.match(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'",s[i:])
  m=string or char
  if m:
   t=m.group();tokens.append(t);literals.append(t);i+=len(t);continue
  m=re.match(r"(?:r#)?[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*|::|=>|->|\.\.=|\.\.|==|!=|<=|>=|&&|\|\||<<|>>|[+*/%-]=",s[i:])
  t=m.group() if m else s[i];tokens.append(t);i+=len(t)
 tokens=[t for k,t in enumerate(tokens) if not(t==',' and k+1<len(tokens) and tokens[k+1] in (')',']','}'))]
 return tokens,comments,literals

candidate=json.loads((G/'source-candidate-1.json').read_bytes())['source_sha256']
parent=json.loads((G/'source-parent.json').read_bytes())['source_sha256']
assert len(candidate)==1838 and len(parent)==1834
for p,h in candidate.items():assert sha((W/p).read_bytes())==h,p
old_changed=sorted(p for p in parent if candidate[p]!=parent[p])
new=sorted(set(candidate)-set(parent))
assert not(set(parent)-set(candidate))
expected={}
for h in ['implementation-1','migrations-1']:
 for f in json.loads((G/h/'source-ready.json').read_bytes())['files']:
  expected[f['path']]=(G/h/'raw'/f['path']).read_bytes()
pub=json.loads((G/'public-tests-1/source-ready.json').read_bytes())
for f in pub['files']:expected[f['relative_path']]=(G/f['raw']['path']).read_bytes()
expected[pub['registration']['relative_path']]=(G/pub['registration']['raw']['path']).read_bytes()
browse=json.loads((G/'browser-witness-1/source-ready.json').read_bytes())
for f in browse['files']:expected[f['relative']]=Path(f['raw']['path']).read_bytes()
correction=json.loads((G/'root/compiler-correction-1/receipt.json').read_bytes())
for f in correction['files']:
 p=f['path'];assert sha(expected[p])==f['before_sha256']
 expected[p]=expected[p].replace(f['old'].encode(),f['new'].encode(),1)
 assert sha(expected[p])==f['after_sha256']
assert sorted(expected)==sorted(old_changed+new)
format_record=json.loads((G/'format-review-1/review.json').read_bytes())
formatted=[]
for f in format_record['files']:
 p=f['path'];before=expected[p];after=(W/p).read_bytes()
 assert sha(before)==f['before_sha256'] and sha(after)==f['after_sha256']
 assert before==(G/'before-format-1'/p).read_bytes()
 if p.endswith('.rs'):
  b,c,l=lex(before.decode());a,d,m=lex(after.decode())
  assert b==a and c==d and l==m,p
 else:assert before==after
 formatted.append({'path':p,'before_sha256':sha(before),'after_sha256':sha(after),'format_only':True})
tracked=subprocess.check_output(['git','diff','--name-only',BASE,'--'],cwd=W).decode().splitlines()
assert sorted(tracked)==old_changed,(tracked,old_changed)
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W).decode().splitlines()
assert sorted(untracked)==new,(untracked,new)
new_names=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',expected['src/graphics/raster_bridge/native/line_accounting_tests.rs'].decode())
new_names=['graphics::raster_bridge::native::tests::line_accounting_tests::'+n for n in new_names]+['native_line_loaded_decorations_admit_exact_plan_and_literal_pixels']
assert len(new_names)==10
rename={'before':'graphics::raster_bridge::native::tests::box_prepass_tests::full_area_line_debt_is_global_before_any_box_window_preparation','after':'graphics::raster_bridge::native::tests::box_prepass_tests::full_area_opacity_debt_is_global_before_any_box_window_preparation'}
def log_records(folder,label):
 r=json.loads((folder/'validation'/(label+'.json')).read_bytes());p=folder/'validation'/r['log'];b=p.read_bytes();assert sha(b)==r['sha256']
 t=b.decode();rows=re.findall(r'^test ([^\n]+?) \.\.\. (ok|FAILED|ignored).*$',t,re.M)
 summaries=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',t,re.M)
 assert len(rows)==len(set(x[0] for x in rows))
 assert len(rows)==sum(sum(int(x[i]) for i in (1,2,3)) for x in summaries)
 return r,rows,summaries,binding(p)
parents=[]
for label,count,extra in [('class-default-full-2',3344,0),('class-host-vulkan-full-1',3698,10)]:
 r,rows,summaries,b=log_records(F,label)
 assert r['exit']==0 and len(rows)==count and all(x[1]=='ok' for x in rows)
 assert len(summaries)==53
 names={x[0] for x in rows}
 assert not names.intersection(new_names)
 assert (rename['before'] in names)==bool(extra)
 parents.append({'label':label,'log':b,'roster_size':count,'result_rows':53,'expected_candidate_size':count+extra,'expected_additions':new_names if extra else [],'rename':rename if extra else None,'names':sorted(names)})
r,rows,summaries,pbind=log_records(G,'parent-lines-2')
assert r['exit']==101 and len(rows)==10 and {x[0] for x in rows}==set(new_names)
assert sum(s=='ok' for n,s in rows)==2 and sum(s=='FAILED' for n,s in rows)==8
root_parent=json.loads((G/'root/parent-results-1.json').read_bytes())
assert sorted(rows)==sorted(tuple(x) for x in root_parent['groups'])
r,crows,csummaries,cbind=log_records(G,'candidate-lines-1')
assert r['exit']==0 and len(crows)==10 and all(s=='ok' for n,s in crows)
assert {n for n,s in crows}==set(new_names)
source=save('source-checks-1.json',{'status':'clear source closure and source-format review; final validation pending','source':binding(G/'source-candidate-1.json'),'parent':binding(G/'source-parent.json'),'selected_inputs':1838,'changed_existing':old_changed,'new_paths':new,'exact_hold_composition':True,'format':formatted,'git_scope_exact':True,'authoring_note':'Reviewer authored implementation and historical migration holds; comparison is independent of root formatting/composition checker, not an independent producer correctness peer. HTML production peer is retained separately.','limits':'Selected-input census is not a full build graph. No live writes or project execution.'})
scaffold=save('scaffold-1.json',{'status':'awaiting final full/strict/build/hardware receipts and root final ledger','source_checks':source,'parent_rust':parents,'focused_parent':{'log':pbind,'rows':rows,'passed':2,'failed':8,'qualification':'Initial compiler refusal retained separately; later rows in failed groups need not have run.'},'focused_candidate':{'log':cbind,'rows':crows,'passed':10,'failed':0},'new_tests':new_names,'rename':rename,'remaining':['full default3344 and host/Vulkan3708 exact frozen rosters','strict and formatting receipts on final source','source-bound release and hardware results if run, without inferring unrun work','root final ledger/source-final equality and final review seal'],'root_checker_source_review':'check-full-suites.py verifies log hashes, exit/status/count uniqueness, source hashes, old roster subset and selected rename. This review additionally fixes the exact10 names from frozen test payloads, rather than accepting any ten names containing native_line_. No execution of the checker.'})
print(json.dumps({'source':source,'scaffold':scaffold},indent=2))
