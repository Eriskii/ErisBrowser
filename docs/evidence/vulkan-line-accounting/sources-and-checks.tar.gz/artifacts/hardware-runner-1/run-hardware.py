#!/usr/bin/env python3
"""Root-only, one-page Vulkan correctness capture. No builds or timing runs."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import sys

HERE = Path(__file__).resolve().parent
MAX_OUTPUT = 2 * 1024 * 1024
MAX_FILE = 128 * 1024 * 1024


def require(condition, reason):
    if not condition:
        raise ValueError(reason)


def file_hash(path, cap=MAX_FILE):
    require(path.is_file() and path.stat().st_size <= cap, f'missing/oversized file: {path}')
    with path.open('rb') as source:
        return hashlib.file_digest(source, 'sha256').hexdigest()


def bound(path, cap=MAX_FILE):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': file_hash(path, cap)}


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, 'duplicate JSON key')
        result[key] = value
    return result


def decode(raw):
    def invalid(value):
        raise ValueError(f'nonfinite JSON constant: {value}')
    return json.loads(raw, object_pairs_hook=unique_object, parse_constant=invalid)


def integer(value, low, high):
    require(type(value) is int and low <= value <= high, 'integer type/range')
    return value


def source_state(worktree, inventory, inventory_sha256, contract):
    require(file_hash(inventory, 4 * 1024 * 1024) == inventory_sha256, 'source inventory pin changed')
    manifest = decode(inventory.read_bytes())
    require(manifest['base'] == contract['base'], 'unexpected source base')
    rows = manifest['source_sha256']
    require(type(rows) is dict and 1 <= len(rows) <= 10000, 'source inventory shape')
    for name, expected in rows.items():
        require(type(name) is str and type(expected) is str, 'source entry type')
        path = (worktree / name).resolve()
        require(path.is_relative_to(worktree), 'source path escapes worktree')
        require(file_hash(path) == expected, f'source differs from selected inventory: {name}')
    for name, expected in contract['unchanged_helper_sha256'].items():
        require(file_hash(worktree / name) == expected, f'held helper changed: {name}')
    return {'inventory': bound(inventory), 'selected_inputs': len(rows),
            'qualification': manifest['scope'], 'unchanged_helper_sha256': contract['unchanged_helper_sha256']}


def parse_check(stdout, stderr):
    require(len(stdout) + len(stderr) <= MAX_OUTPUT, 'combined output exceeds bound')
    require(stdout.endswith(b'\n') and stdout.count(b'\n') == 1, 'expected exactly one complete JSON report')
    report = decode(stdout.decode('utf-8', errors='strict'))
    fixed = {'schema': 1, 'kind': 'native-benchmark', 'mode': 'check', 'route': 'native-raster',
             'requested_frames': 1, 'completed_frames': 1, 'accepted_frames': 0,
             'checked': True, 'failure': None, 'owner_failure': None, 'owner_init_ns': None, 'samples': []}
    other = {'scene_hex', 'width', 'height', 'generation', 'viewport_revision', 'scale_factor',
             'source_load_ms', 'edit_sequence', 'diagnostics'}
    require(type(report) is dict and set(report) == set(fixed) | other, 'report fields differ')
    for key, value in fixed.items():
        require(type(report[key]) is type(value) and report[key] == value, f'incomplete/invalid check: {key}')
    width = integer(report['width'], 1, 1280)
    height = integer(report['height'], 1, 1024)
    integer(report['generation'], 1, 2**64 - 1)
    integer(report['viewport_revision'], 1, 2**64 - 1)
    integer(report['edit_sequence'], 0, 2**64 - 1)
    integer(report['diagnostics'], 0, 0)
    for key in ('scale_factor', 'source_load_ms'):
        value = report[key]
        require(type(value) in (int, float) and math.isfinite(value), f'invalid {key}')
        require(value > 0 if key == 'scale_factor' else value >= 0, f'negative/zero {key}')
    scene = report['scene_hex']
    require(type(scene) is str and 0 < len(scene) <= 128 * 1024 and len(scene) % 2 == 0
            and re.fullmatch('[0-9a-f]+', scene), 'invalid bounded scene identity')
    text = stderr.decode('utf-8', errors='strict')
    require(text.endswith('\n'), 'missing terminal diagnostic newline')
    lines = text.splitlines()
    require(len(lines) <= 4096 and all(len(line) <= 16384 for line in lines), 'diagnostic bounds')
    quoted = r'"(?:\\.|[^"\\])*"'
    adapter = re.compile(r'presenter: Vulkan adapter=(' + quoted + r') type=(DiscreteGpu|IntegratedGpu) driver=('
                         + quoted + r') format=(Bgra8Unorm|Rgba8Unorm) color_space=Srgb alpha=Opaque mode=Fifo; raster=native-shaders with complete CPU admission fallback')
    verified = re.compile(r'presenter: native shader acquired-texture verified; serial=(\d+) generation=(\d+) viewport_revision=(\d+) size=(\d+)x(\d+) compared_bytes=(\d+) exact=true \(before compositor\)')
    summary = re.compile(r'presenter: Vulkan acquired-texture verification passed; route=native-raster frames=(\d+) compared_bytes=(\d+) last_serial=(\d+) \(before compositor\)')
    adapters = [m for line in lines if (m := adapter.fullmatch(line))]
    frames = [m for line in lines if (m := verified.fullmatch(line))]
    summaries = [m for line in lines if (m := summary.fullmatch(line))]
    require(len(adapters) == len(frames) == len(summaries) == 1, 'missing/repeated hardware or verification diagnostics')
    require(not any('native raster admission fallback;' in line or 'native benchmark admission refused:' in line
                    or 'route=cpu-upload' in line for line in lines), 'fallback/CPU route observed')
    serial, generation, revision, got_width, got_height, compared = map(int, frames[0].groups())
    count, total, last_serial = map(int, summaries[0].groups())
    require(serial > 0 and (generation, revision) == (report['generation'], report['viewport_revision']), 'frame stamp differs')
    require((got_width, got_height, compared) == (width, height, width * height * 4), 'active byte comparison differs')
    require((count, total, last_serial) == (1, compared, serial), 'summary differs from verified frame')
    return {'report': report, 'adapter_diagnostic': adapters[0].group(0),
            'verified_diagnostic': frames[0].group(0), 'summary_diagnostic': summaries[0].group(0),
            'active_bytes': compared, 'scope': 'one acquired native texture against full Canvas, before compositor; no timing samples'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worktree', type=Path, required=True)
    parser.add_argument('--binary', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True)
    parser.add_argument('--source-inventory', type=Path, required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    worktree, binary, inventory = (p.resolve() for p in (args.worktree, args.binary, args.source_inventory))
    output = args.output.resolve()
    require(not output.exists(), 'output directory must be new')
    output.mkdir(parents=True)
    result = {'status': 'failed', 'hardware_claim': False, 'error': None}
    contract = decode((HERE / 'contract.json').read_bytes())
    before = None
    try:
        require(sys.platform.startswith('linux'), 'Linux subreaper/display required')
        before = source_state(worktree, inventory, args.source_sha256, contract)
        require(file_hash(binary) == args.binary_sha256, 'binary pin differs')
        fixture = worktree / 'examples/vulkan-lines.html'
        require(file_hash(fixture, 1024 * 1024) == contract['fixture_sha256'], 'fixture pin differs')
        command = [str(binary), str(fixture), '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                   '--benchmark-native-check', '--exit-after', '15']
        readiness_path = Path(contract['hardware_command']['path'])
        require(file_hash(readiness_path) == contract['hardware_command']['sha256'], 'hardware recipe changed')
        recipe = decode(readiness_path.read_bytes())
        env = dict(os.environ)
        for key in recipe['unset_environment'] + ['WGPU_BACKEND', 'WGPU_ADAPTER_NAME', 'VK_INSTANCE_LAYERS']:
            env.pop(key, None)
        env.update(recipe['run_environment'])
        env['PYTHONDONTWRITEBYTECODE'] = '1'
        sys.dont_write_bytecode = True
        sys.path.insert(0, str(worktree / 'tools/vulkan-raster-probe'))
        # Root execution only: imports are inert; the child CLI creates its own subreaper.
        from run_browser_host import run_supervised, check_success
        inputs = {'source': before, 'binary': bound(binary), 'fixture': bound(fixture),
                  'runner': bound(Path(__file__).resolve()), 'contract': bound(HERE / 'contract.json'),
                  'command': command, 'environment_overrides': recipe['run_environment'],
                  'timeout_seconds': 45, 'output_limit_bytes': MAX_OUTPUT,
                  'cleanup_seconds': 5, 'outer_watchdog': 'existing run_supervised: timeout+15s, TERM then10s, KILL then2s; interruption never counts as success'}
        for row in contract['runtime_files']:
            require(file_hash(Path(row['path'])) == row['sha256'], 'loader/ICD binding changed')
        inputs['runtime_files'] = contract['runtime_files']
        (output / 'inputs.json').write_text(json.dumps(inputs, indent=2) + '\n')
        record, stdout = run_supervised(command, output, 'native-check', env, timeout=45)
        result['supervisor'] = record
        check_success(record)
        require(record.get('error') is None and record.get('cancellation_signal') is None, 'supervisor error/interruption')
        stderr = (output / 'native-check.stderr.log').read_bytes()
        result['evidence'] = parse_check(stdout, stderr)
        result['status'] = 'passed'
        result['hardware_claim'] = True
    except (Exception, KeyboardInterrupt) as error:
        result['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        if before is not None:
            try:
                require(source_state(worktree, inventory, args.source_sha256, contract) == before, 'source postcheck differs')
                require(file_hash(binary) == args.binary_sha256, 'binary changed during run')
                require(file_hash(worktree / 'examples/vulkan-lines.html') == contract['fixture_sha256'], 'fixture changed during run')
                for row in contract['runtime_files']:
                    require(file_hash(Path(row['path'])) == row['sha256'], 'runtime file changed during run')
                result['postcheck'] = 'all selected source, helper, binary, fixture, loader and ICD bindings exact'
            except Exception as error:
                result.update(status='failed', hardware_claim=False, postcheck_error=f'{type(error).__name__}: {error}'[:4096])
        result['qualification'] = 'One correctness attempt; not timing, compositor output, general rendering coverage, or proof of build provenance. Root joins the pinned executable to its separate build/source receipt.'
        (output / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({'status': result['status'], 'result': str(output / 'result.json'), 'error': result.get('error')}))
    return 0 if result['status'] == 'passed' else 1


if __name__ == '__main__':
    raise SystemExit(main())
