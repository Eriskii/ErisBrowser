from pathlib import Path
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');O=G/'hardware-runner-2'
s=(G/'hardware-runner-1/run-hardware.py').read_text()
s=s.replace("height = integer(report['height'], 1, 1024)","height = integer(report['height'], 1, 1024)\n    require((width, height) == (1280, 880), 'owned physical viewport differs')")
old="""        command = [str(binary), str(fixture), '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                   '--benchmark-native-check', '--exit-after', '15']"""
new="""        owned = HERE / 'owned-window.py'
        controller = Path(contract['controller']['path'])
        require(file_hash(controller) == contract['controller']['sha256'], 'controller changed')
        require(file_hash(owned) == contract['owned_wrapper']['sha256'], 'held owned wrapper changed')
        control_path = output / 'owned-control.json'
        pinned = {str(worktree / name): value for name, value in contract['unchanged_helper_sha256'].items()}
        pinned.update({str(binary): args.binary_sha256, str(fixture): contract['fixture_sha256'],
                       str(controller): contract['controller']['sha256'], str(owned): contract['owned_wrapper']['sha256']})
        launch = {'worktree': str(worktree), 'binary': str(binary), 'binary_sha256': args.binary_sha256,
                  'fixture': str(fixture), 'fixture_sha256': contract['fixture_sha256'],
                  'receipt': str(control_path), 'controller': str(controller),
                  'controller_sha256': contract['controller']['sha256'], 'pinned_files': pinned}
        launch_path = output / 'launch.json'
        launch_path.write_text(json.dumps(launch, indent=2) + '\\n')
        command = [sys.executable, str(owned), '--launch', str(launch_path)]"""
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace("'command': command, 'environment_overrides': recipe['run_environment'],", "'command': command, 'owned_launch': bound(launch_path), 'environment_overrides': recipe['run_environment'],")
s=s.replace("        result['evidence'] = parse_check(stdout, stderr)\n", "        result['evidence'] = parse_check(stdout, stderr)\n        control = decode(control_path.read_bytes())\n        result['owned_control'] = validate_control(control, stderr, launch, fixture.read_bytes())\n        require(decode(launch_path.read_bytes()) == launch, 'owned launch changed during run')\n")
validate='''def validate_control(control, stderr, launch, body):
    require(type(control) is dict and control.get('success') is True
            and control.get('control_complete') is True and control.get('browser_reaped') is True
            and type(control.get('browser_returncode')) is int and control['browser_returncode'] == 0,
            'owned control/browser exit failed')
    require(not any(k in control for k in ('error', 'cleanup_error', 'postcheck_error', 'stderr_drain_error')),
            'owned wrapper error')
    require(control.get('controlled_size') == [1280, 880], 'compositor size differs')
    identity = control['identity']
    pid = integer(identity['pid'], 2, 2**31 - 1)
    port = integer(control['port'], 1, 65535)
    expected_command = [launch['binary'], f'http://127.0.0.1:{port}/admitted.html',
                        '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                        '--benchmark-native-check', '--exit-after', '15']
    require(control['browser_command'] == expected_command, 'owned browser command differs')
    for key in ('binary_sha256', 'fixture_sha256', 'controller_sha256'):
        require(control[key] == launch[key], 'owned input identity differs')
    commands = control['commands']
    require(type(commands) is list and 2 <= len(commands) <= 48, 'controller command bound')
    changes = []
    for row in commands:
        argv = row['argv']
        require(argv[0] == launch['controller'] and row['status'] == 'exited'
                and type(row['returncode']) is int and row['returncode'] == 0, 'controller failed')
        if argv[1:] == ['-j', 'clients']:
            continue
        changes.append(argv[1:])
    require(changes == [['dispatch', 'setfloating', f'pid:{pid}'],
                        ['dispatch', 'resizewindowpixel', f'exact 1280 880,pid:{pid}']],
            'unexpected/unowned compositor operation')
    marker = re.compile(rb'^native line gate: document released for owned pid=([1-9][0-9]*) size=1280x880 prefix_bytes=(\\d+) prefix_sha256=([0-9a-f]{64}) html_sha256=([0-9a-f]{64})\\n', re.MULTILINE)
    matches = list(marker.finditer(stderr))
    require(len(matches) == 1, 'one document release marker required')
    match = matches[0]
    prefix = stderr[:match.start()]
    prefix_sha = hashlib.sha256(prefix).hexdigest()
    body_sha = hashlib.sha256(body).hexdigest()
    require((int(match[1]), int(match[2]), match[3].decode(), match[4].decode())
            == (pid, len(prefix), prefix_sha, body_sha), 'document release binding differs')
    require(control['release'] == {'prefix_bytes': len(prefix), 'prefix_sha256': prefix_sha,
                                  'html_sha256': body_sha, 'physical_size': [1280, 880]},
            'physical release receipt differs')
    waiting = re.findall(rb'^native benchmark waiting: size=(\\d+)x(\\d+) loaded=false$', prefix, re.MULTILINE)
    require(waiting and waiting[-1] == (b'1280', b'880'), 'missing final physical loaded=false proof')
    require(b'acquired-texture verified;' not in prefix and b'verification passed;' not in prefix,
            'GPU proof precedes document release')
    requests = control['requests']
    require(type(requests) is list and len(requests) == 1 and control['accepted_connections'] == 1,
            'unexpected HTTP request count')
    request = requests[0]
    response = (f'HTTP/1.1 200 OK\\r\\nContent-Type: text/html; charset=utf-8\\r\\nContent-Length: {len(body)}\\r\\nConnection: close\\r\\n\\r\\n'.encode() + body)
    require(request['path'] == '/admitted.html' and request['method'] == 'GET'
            and request['body_bytes'] == len(body) and request['body_sha256'] == body_sha
            and request['response_complete'] is True and request['response_bytes'] == len(response)
            and request['response_sha256'] == hashlib.sha256(response).hexdigest(),
            'exact held HTML response differs')
    return {'receipt': control, 'physical_gate': '1280x880 loaded=false before exact HTML release',
            'transport': 'one bounded loopback GET; no external network; original body bytes unchanged'}


'''
s=s.replace('def main():\n',validate+'def main():\n',1)
(O/'run-hardware.py').write_text(s)
