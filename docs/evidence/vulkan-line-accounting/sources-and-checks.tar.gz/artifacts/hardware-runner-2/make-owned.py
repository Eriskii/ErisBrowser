from pathlib import Path
import ast
G=Path('/tmp/eris-vulkan-line-accounting-plan-1');W=G/'worktree';O=G/'hardware-runner-2'
s=(W/'tools/native_raster_wide_host.py').read_text();tree=ast.parse(s);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='serve_and_relay');old=''.join(s.splitlines(True)[node.lineno-1:node.end_lineno])
new=old.replace("len(record['requests']) != 2", "len(record['requests']) != 1").replace("document gate and both fixed responses must complete", "document gate and the fixed response must complete")
assert new!=old and new.replace("len(record['requests']) != 1", "len(record['requests']) != 2").replace("document gate and the fixed response must complete", "document gate and both fixed responses must complete")==old
preamble='''#!/usr/bin/env python3
"""Root-only owned-window wrapper; exact one-route delayed document gate."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import socket
import subprocess
import sys
import time

# Same fixed physical gate and resource bounds as the existing wide host.
SIZE = (1280, 880)
MAX_HEADER = 8192
MAX_CONNECTIONS = 8
MAX_ACTIVE_CONNECTIONS = 4
ROUTES = {'/admitted.html': ('vulkan-lines.html', 'text/html; charset=utf-8')}
WAITING = re.compile(r'native benchmark waiting: size=([1-9][0-9]*)x([1-9][0-9]*) loaded=false')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse_request(header, port):
    path = wide.parse_request(header, port)
    if path != '/admitted.html':
        raise ValueError('only the exact held Line document may be requested')
    return path


def response_for(path, bodies):
    return wide.response_for(path, bodies)


'''
post='''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch', type=Path, required=True)
    args = parser.parse_args()
    spec = json.loads(args.launch.read_text())
    worktree, binary, fixture, receipt, controller = (Path(spec[k]) for k in
        ('worktree', 'binary', 'fixture', 'receipt', 'controller'))
    if receipt.exists() or not receipt.parent.is_dir():
        raise ValueError('fresh owned-control receipt required')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(worktree / 'tools'))
    global base, wide
    import native_raster_host as base
    import native_raster_wide_host as wide
    for path, expected in spec['pinned_files'].items():
        if base.digest(Path(path), base.MAX_BINARY) != expected:
            raise ValueError('held owned-launch input differs')
    body = fixture.read_bytes()
    if len(body) > 1024 * 1024 or sha(body) != spec['fixture_sha256']:
        raise ValueError('held document differs')
    bodies = {'/admitted.html': body}
    record = {'schema': 1, 'success': False, 'control_complete': False, 'commands': [],
              'requests': [], 'accepted_connections': 0, 'identity': None,
              'browser_reaped': False, 'browser_returncode': None,
              'binary_sha256': spec['binary_sha256'], 'fixture_sha256': spec['fixture_sha256'],
              'controller_sha256': spec['controller_sha256'],
              'scope': 'only the owned unreaped browser PID; exact withheld loopback body; no global window rules'}
    child = listener = None
    deadline = time.monotonic() + 20
    emitted = 0
    def persist():
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\\n')
        temporary.replace(receipt)
    def emit(data):
        nonlocal emitted
        keep = min(len(data), base.MAX_OUTPUT - emitted)
        sys.stderr.buffer.write(data[:keep]); sys.stderr.buffer.flush()
        emitted += keep
        if keep != len(data):
            raise ValueError('owned relay output limit')
    persist()
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.bind(('127.0.0.1', 0)); listener.listen(MAX_ACTIVE_CONNECTIONS)
        listener.setblocking(False)
        record['port'] = listener.getsockname()[1]
        url = f"http://127.0.0.1:{record['port']}/admitted.html"
        command = [str(binary), url, '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                   '--benchmark-native-check', '--exit-after', '15']
        record['browser_command'] = command
        persist()
        # Browser and wrapper share the outer supervisor's process group. Only
        # this wrapper waits for its direct browser child until the final reap.
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stderr=subprocess.PIPE, close_fds=True)
        record['identity'] = base.child_identity(child.pid)
        persist()
        base.configure_owned(record['identity'], controller, dict(os.environ), record, persist,
                             requested_size=SIZE)
        serve_and_relay(child, listener, record, bodies, persist, deadline, emit,
                        waiting_pattern=WAITING, marker_prefix='native line gate',
                        forbidden_patterns=(re.compile(r'presenter: .*verified.*'),
                                            re.compile(r'presenter: .*verification passed.*')))
        record['browser_returncode'] = child.wait(timeout=2)
        record['browser_reaped'] = True
        record['success'] = record['browser_returncode'] == 0
    except (OSError, ValueError, RuntimeError, KeyError, subprocess.SubprocessError, KeyboardInterrupt) as error:
        record['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        if listener is not None:
            listener.close()
        if child is not None:
            if not record['browser_reaped']:
                try:
                    os.waitid(os.P_PID, child.pid, base.WAIT_FLAGS)
                    os.kill(child.pid, signal.SIGKILL)
                    record['browser_returncode'] = child.wait(timeout=2)
                    record['browser_reaped'] = True
                except (OSError, subprocess.SubprocessError) as error:
                    record['cleanup_error'] = str(error)[:4096]
            try:
                wide.drain_stderr(child.stderr, emit)
            except (OSError, ValueError, RuntimeError) as error:
                record['success'] = False
                record['stderr_drain_error'] = str(error)[:4096]
            child.stderr.close()
        try:
            for path, expected in spec['pinned_files'].items():
                if base.digest(Path(path), base.MAX_BINARY) != expected:
                    raise ValueError('owned-launch postbinding differs')
        except (OSError, ValueError) as error:
            record['success'] = False
            record['postcheck_error'] = str(error)[:4096]
        persist()
    return 0 if record['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
'''
(O/'owned-window.py').write_text(preamble+new+post)
(O/'relay-before.txt').write_text(old)
(O/'relay-after.txt').write_text(new)
