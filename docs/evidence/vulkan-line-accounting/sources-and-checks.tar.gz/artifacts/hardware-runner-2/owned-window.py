#!/usr/bin/env python3
"""Root-only owned-window wrapper; exact one-route delayed document gate."""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import selectors
import signal
import socket
import subprocess
import sys
import time

# Same fixed physical gate and resource bounds as the existing wide host.
SIZE = (1280, 880)
MAX_HEADER = 8192
MAX_CONNECTIONS = 8
MAX_ACTIVE_CONNECTIONS = 4
ROUTES = {'/admitted.html': ('vulkan-lines.html', 'text/html; charset=utf-8')}
WAITING = re.compile(r'native benchmark waiting: size=([1-9][0-9]*)x([1-9][0-9]*) loaded=false')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def parse_request(header, port):
    path = wide.parse_request(header, port)
    if path != '/admitted.html':
        raise ValueError('only the exact held Line document may be requested')
    return path


def response_for(path, bodies):
    return wide.response_for(path, bodies)


def serve_and_relay(child, listener, record: dict, bodies: dict[str, bytes], persist,
                    deadline: float, emit, *, waiting_pattern=None, marker_prefix='native wide gate',
                    forbidden_patterns=()) -> None:
    """One selector, fixed routes, fixed admission gate, one original deadline."""
    stream = child.stderr
    os.set_blocking(stream.fileno(), False)
    browser_prefix = bytearray()
    pending = bytearray()
    connections = {}
    physical = False
    released = False
    stderr_open = True
    selector = selectors.DefaultSelector()
    selector.register(listener, selectors.EVENT_READ, 'listener')
    selector.register(stream, selectors.EVENT_READ, 'stderr')

    def close_connection(connection):
        selector.unregister(connection)
        connection.close()
        del connections[connection]

    def drain_browser():
        nonlocal physical, stderr_open
        # Before opening the gate, consume every already-readable byte. A proof
        # following the size line in the same read must remain pre-release.
        while stderr_open:
            if time.monotonic() >= deadline:
                raise ValueError('original wide-window lifetime expired')
            try:
                chunk = os.read(stream.fileno(), 16384)
            except BlockingIOError:
                return
            if not chunk:
                selector.unregister(stream)
                stderr_open = False
                if pending:
                    raise ValueError('unterminated browser diagnostic')
                return
            if len(browser_prefix) + len(pending) + len(chunk) > base.MAX_OUTPUT - 512:
                room = max(0, base.MAX_OUTPUT - 512 - len(browser_prefix) - len(pending))
                pending.extend(chunk[:room])
                raise ValueError('wide browser stderr bound')
            pending.extend(chunk)
            while (end := pending.find(b'\n')) != -1:
                line = bytes(pending[:end + 1])
                del pending[:end + 1]
                browser_prefix.extend(line)
                emit(line)
                text = line.decode('utf-8').rstrip('\n')
                if not released and (base.SCENE.fullmatch(text) or base.PRESENTED.fullmatch(text)
                                     or base.VERIFIED.fullmatch(text) or base.SUMMARY.fullmatch(text)
                                     or any(pattern.fullmatch(text) for pattern in forbidden_patterns)):
                    raise ValueError('native proof preceded delayed-document release')
                if waiting_pattern is None:
                    if match := base.FALLBACK.fullmatch(text):
                        physical = match[1] == PHYSICAL
                elif match := waiting_pattern.fullmatch(text):
                    physical = tuple(map(int, match.groups())) == SIZE
            if len(pending) > 16384:
                raise ValueError('wide browser diagnostic line bound')

    def release_document():
        nonlocal released
        if not stderr_open or pending or not physical or not record.get('control_complete') or released:
            return
        waiting = [(c, s) for c, s in connections.items() if s.get('path') == '/admitted.html']
        if not waiting:
            return
        base.ensure_live_child(record['identity'])
        prefix = bytes(browser_prefix)
        event = {'prefix_bytes': len(prefix), 'prefix_sha256': sha(prefix),
                 'html_sha256': sha(bodies['/admitted.html']), 'physical_size': list(SIZE)}
        marker = (f"{marker_prefix}: document released for owned pid={record['identity']['pid']} size=1280x880 "
                  f"prefix_bytes={event['prefix_bytes']} prefix_sha256={event['prefix_sha256']} html_sha256={event['html_sha256']}\n").encode()
        record['release'] = event
        emit(marker)
        released = True
        persist()
        connection, state = waiting[0]
        state['response'] = response_for('/admitted.html', bodies)
        if state.pop('unregistered', False):
            selector.register(connection, selectors.EVENT_WRITE, 'http')
        else:
            selector.modify(connection, selectors.EVENT_WRITE, 'http')

    try:
        while stderr_open or connections:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                raise ValueError('original wide-window lifetime expired')
            for key, _ in selector.select(min(remaining, 0.025)):
                if key.data == 'listener':
                    connection, peer = listener.accept()
                    connection.setblocking(False)
                    if (peer[0] != '127.0.0.1' or record['accepted_connections'] >= MAX_CONNECTIONS
                            or len(connections) >= MAX_ACTIVE_CONNECTIONS):
                        connection.close()
                        raise ValueError('owned HTTP connection bound')
                    record['accepted_connections'] += 1
                    connections[connection] = {'header': bytearray(), 'offset': 0}
                    selector.register(connection, selectors.EVENT_READ, 'http')
                    persist()
                elif key.data == 'stderr':
                    drain_browser()
                else:
                    connection = key.fileobj
                    state = connections[connection]
                    if 'response' in state:
                        try:
                            sent = connection.send(state['response'][state['offset']:])
                        except BlockingIOError:
                            continue
                        if sent <= 0:
                            raise ValueError('HTTP response write stopped')
                        state['offset'] += sent
                        if state['offset'] == len(state['response']):
                            state['request']['response_complete'] = True
                            state['request']['response_bytes'] = state['offset']
                            state['request']['response_sha256'] = sha(state['response'])
                            close_connection(connection)
                            persist()
                    else:
                        try:
                            chunk = connection.recv(MAX_HEADER + 1 - len(state['header']))
                        except BlockingIOError:
                            continue
                        if not chunk:
                            raise ValueError('HTTP request ended before its bounded header')
                        state['header'].extend(chunk)
                        if len(state['header']) > MAX_HEADER:
                            raise ValueError('HTTP request header exceeded bound')
                        end = state['header'].find(b'\r\n\r\n')
                        if end != -1:
                            if end + 4 != len(state['header']):
                                raise ValueError('HTTP request body/pipelining is unsupported')
                            path = parse_request(bytes(state['header']), record['port'])
                            if any(r['path'] == path for r in record['requests']) or len(record['requests']) >= len(ROUTES):
                                raise ValueError('duplicate or excess HTTP request')
                            if path != '/admitted.html' and not released:
                                raise ValueError('image requested before document release')
                            request = {'path': path, 'method': 'GET', 'header_bytes': len(state['header']),
                                       'header_sha256': sha(bytes(state['header'])), 'body_bytes': len(bodies[path]),
                                       'body_sha256': sha(bodies[path]), 'response_complete': False}
                            state.update(path=path, request=request)
                            record['requests'].append(request)
                            state['header'].clear()
                            persist()
                            if path == '/admitted.html':
                                # A parsed request waits without read/write readiness.
                                selector.unregister(connection)
                                state['unregistered'] = True
                            else:
                                state['response'] = response_for(path, bodies)
                                selector.modify(connection, selectors.EVENT_WRITE, 'http')
            if not released:
                drain_browser()
                release_document()
            if not stderr_open and connections:
                raise ValueError('browser stderr ended with incomplete HTTP responses')
        if not released or len(record['requests']) != 1 or not all(r['response_complete'] for r in record['requests']):
            raise ValueError('document gate and the fixed response must complete')
        while os.waitid(os.P_PID, child.pid, base.WAIT_FLAGS) is None:
            if time.monotonic() >= deadline:
                raise ValueError('original browser exit deadline expired')
            time.sleep(0.025)
    finally:
        try:
            if pending:
                emit(bytes(pending))
        finally:
            for connection in connections:
                connection.close()
            selector.close()



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch', type=Path, required=True)
    args = parser.parse_args()
    spec = json.loads(args.launch.read_text())
    worktree, binary, fixture, receipt, controller = (Path(spec[k]) for k in
        ('worktree', 'binary', 'fixture', 'receipt', 'controller'))
    if receipt.exists() or not receipt.parent.is_dir():
        raise ValueError('fresh owned-control receipt required')
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(worktree / 'tools'))
    global base, wide
    import native_raster_host as base
    import native_raster_wide_host as wide
    for path, expected in spec['pinned_files'].items():
        if base.digest(Path(path), base.MAX_BINARY) != expected:
            raise ValueError('held owned-launch input differs')
    body = fixture.read_bytes()
    if len(body) > 1024 * 1024 or sha(body) != spec['fixture_sha256']:
        raise ValueError('held document differs')
    bodies = {'/admitted.html': body}
    record = {'schema': 1, 'success': False, 'control_complete': False, 'commands': [],
              'requests': [], 'accepted_connections': 0, 'identity': None,
              'browser_reaped': False, 'browser_returncode': None,
              'binary_sha256': spec['binary_sha256'], 'fixture_sha256': spec['fixture_sha256'],
              'controller_sha256': spec['controller_sha256'],
              'scope': 'only the owned unreaped browser PID; exact withheld loopback body; no global window rules'}
    child = listener = None
    deadline = time.monotonic() + 20
    emitted = 0
    def persist():
        temporary = receipt.with_suffix('.tmp')
        temporary.write_text(json.dumps(record, indent=2) + '\n')
        temporary.replace(receipt)
    def emit(data):
        nonlocal emitted
        keep = min(len(data), base.MAX_OUTPUT - emitted)
        sys.stderr.buffer.write(data[:keep]); sys.stderr.buffer.flush()
        emitted += keep
        if keep != len(data):
            raise ValueError('owned relay output limit')
    persist()
    try:
        listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        listener.bind(('127.0.0.1', 0)); listener.listen(MAX_ACTIVE_CONNECTIONS)
        listener.setblocking(False)
        record['port'] = listener.getsockname()[1]
        url = f"http://127.0.0.1:{record['port']}/admitted.html"
        command = [str(binary), url, '--presenter=vulkan', '--raster=gpu', '--no-scripts',
                   '--benchmark-native-check', '--exit-after', '15']
        record['browser_command'] = command
        persist()
        # Browser and wrapper share the outer supervisor's process group. Only
        # this wrapper waits for its direct browser child until the final reap.
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stderr=subprocess.PIPE, close_fds=True)
        record['identity'] = base.child_identity(child.pid)
        persist()
        base.configure_owned(record['identity'], controller, dict(os.environ), record, persist,
                             requested_size=SIZE)
        serve_and_relay(child, listener, record, bodies, persist, deadline, emit,
                        waiting_pattern=WAITING, marker_prefix='native line gate',
                        forbidden_patterns=(re.compile(r'presenter: .*verified.*'),
                                            re.compile(r'presenter: .*verification passed.*')))
        record['browser_returncode'] = child.wait(timeout=2)
        record['browser_reaped'] = True
        record['success'] = record['browser_returncode'] == 0
    except (OSError, ValueError, RuntimeError, KeyError, subprocess.SubprocessError, KeyboardInterrupt) as error:
        record['error'] = f'{type(error).__name__}: {error}'[:4096]
    finally:
        if listener is not None:
            listener.close()
        if child is not None:
            if not record['browser_reaped']:
                try:
                    os.waitid(os.P_PID, child.pid, base.WAIT_FLAGS)
                    os.kill(child.pid, signal.SIGKILL)
                    record['browser_returncode'] = child.wait(timeout=2)
                    record['browser_reaped'] = True
                except (OSError, subprocess.SubprocessError) as error:
                    record['cleanup_error'] = str(error)[:4096]
            try:
                wide.drain_stderr(child.stderr, emit)
            except (OSError, ValueError, RuntimeError) as error:
                record['success'] = False
                record['stderr_drain_error'] = str(error)[:4096]
            child.stderr.close()
        try:
            for path, expected in spec['pinned_files'].items():
                if base.digest(Path(path), base.MAX_BINARY) != expected:
                    raise ValueError('owned-launch postbinding differs')
        except (OSError, ValueError) as error:
            record['success'] = False
            record['postcheck_error'] = str(error)[:4096]
        persist()
    return 0 if record['success'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
