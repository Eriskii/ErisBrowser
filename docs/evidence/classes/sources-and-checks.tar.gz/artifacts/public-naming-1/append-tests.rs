#[test]
fn class_public_naming_identifier_and_logical_assignment() {
    observe(
        "naming_identifier_and_logical_assignment",
        r###"function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var trace='',assigned,andName=1,orName=0,nullName=null;
 var first=(assigned=class {[(trace+='A','m')](){}});
 var second=(andName&&=class {[(trace+='B','m')](){}});
 var third=(orName||=class {[(trace+='C','m')](){}});
 var fourth=(nullName??=class {[(trace+='D','m')](){}});
 check(first===assigned&&second===andName&&third===orName&&fourth===nullName);
 check(assigned.name==='assigned'&&andName.name==='andName'&&orName.name==='orName'&&nullName.name==='nullName');
 var skipAnd=0,marker={},skipOr=marker,skipNull=false;
 check((skipAnd&&=class {[(trace+='X','m')](){}})===0);
 check((skipOr||=class {[(trace+='Y','m')](){}})===marker);
 check((skipNull??=class {[(trace+='Z','m')](){}})===false);
 check(skipAnd===0&&skipOr===marker&&skipNull===false);
 var hinted;hinted=class {static read(){return hinted;}};
 var saved=hinted;check(saved.name==='hinted');hinted=7;check(saved.read()===7);
 var explicit;explicit=class Inner {};check(explicit.name==='Inner');
 return trace+'|names';
})();
"###,
        r###"result
"###,
        Value::String("ABCD|names".into()),
    );
}

#[test]
fn class_public_naming_parameter_defaults() {
    observe(
        "naming_parameter_defaults",
        r###"function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 function ordinary(Param=class {}){return Param;}
 var arrow=(Arrow=(class {}))=>Arrow;
 class Holder {
  constructor(Ctor=class {}){this.C=Ctor;}
  method(Method=class {}){return Method;}
  static take(Static=class {}){return Static;}
 }
 var p=ordinary(),a=arrow(),h=new Holder(),m=h.method(),s=Holder.take();
 check(p.name==='Param'&&a.name==='Arrow'&&h.C.name==='Ctor'&&m.name==='Method'&&s.name==='Static');
 var marker={},count=0;
 function optional(Skip=class {[(count++,'m')](){}}){return Skip;}
 check(optional(marker)===marker&&count===0);
 check(optional().name==='Skip'&&count===1);
 var d=Object.getOwnPropertyDescriptor(p,'name');
 check(d.value==='Param'&&!d.writable&&!d.enumerable&&d.configurable);
 return p.name+'|'+a.name+'|'+h.C.name+'|'+m.name+'|'+s.name+'|'+count;
})();
"###,
        r###"result
"###,
        Value::String("Param|Arrow|Ctor|Method|Static|1".into()),
    );
}

#[test]
fn class_public_naming_object_data_property_keys() {
    observe(
        "naming_object_data_property_keys",
        r###"function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var trace='',key={toString:function(){trace+='K';return 'computed';}},sym=Symbol('slot'),empty=Symbol();
 var o={
  plain:class {},
  'spaced key':(class {}),
  [key]:class {[(trace+='C','m')](){}},
  [(trace+='S',sym)]:class {[(trace+='D','m')](){}},
  [empty]:class {}
 };
 check(o.plain.name==='plain'&&o['spaced key'].name==='spaced key'&&o.computed.name==='computed');
 check(o[sym].name==='[slot]'&&o[empty].name==='');
 var d=Object.getOwnPropertyDescriptor(o[sym],'name');
 check(d.value==='[slot]'&&!d.writable&&!d.enumerable&&d.configurable);
 check(Object.getOwnPropertyDescriptor(o,sym).value===o[sym]);
 return trace+'|'+o.plain.name+'|'+o['spaced key'].name+'|'+o.computed.name+'|'+o[sym].name+'|'+o[empty].name;
})();
"###,
        r###"result
"###,
        Value::String("KCSD|plain|spaced key|computed|[slot]|".into()),
    );
}

#[test]
fn class_public_naming_parentheses_comma_conditional_boundaries() {
    observe(
        "naming_parentheses_comma_conditional_boundaries",
        r###"function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var Wrapped=(((class {}))),Comma=(0,class {}),Conditional=(true?class {}:class {}),Alternative=(false?class {}:class {});
 var Assigned;Assigned=((class {}));
 var o={wrapped:(class {}),comma:(0,class {}),conditional:(true?class {}:class {})};
 check(Wrapped.name==='Wrapped'&&Assigned.name==='Assigned'&&o.wrapped.name==='wrapped');
 check(Comma.name===''&&Conditional.name===''&&Alternative.name===''&&o.comma.name===''&&o.conditional.name==='');
 return Wrapped.name+'|'+Assigned.name+'|'+o.wrapped.name+'|empty';
})();
"###,
        r###"result
"###,
        Value::String("Wrapped|Assigned|wrapped|empty".into()),
    );
}

#[test]
fn class_public_naming_hints_preserve_static_name_and_length() {
    observe(
        "naming_hints_preserve_static_name_and_length",
        r###"function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var reads=0,Assigned;Assigned=class {static name(){return 1;} static get length(){reads++;return 2;}};
 var Logical=0;Logical||=class {static get name(){reads++;return 3;} static length(){return 4;}};
 function defaults(Default=class {static name(){return 5;} static length(){return 6;}}){return Default;}
 var Default=defaults(),o={field:class {static name(){return 7;} static length(){return 8;}}};
 var Wrapped=(class {static name(){return 9;} static length(){return 10;}});
 check(reads===0);
 var n=Object.getOwnPropertyDescriptor(Assigned,'name'),l=Object.getOwnPropertyDescriptor(Assigned,'length');
 check(n.value===Assigned.name&&n.writable&&!n.enumerable&&n.configurable);
 check(typeof l.get==='function'&&l.get.name==='get length'&&!l.enumerable&&l.configurable);
 check(Assigned.name()===1&&Assigned.length===2&&Logical.name===3&&Logical.length()===4);
 check(Default.name()===5&&Default.length()===6&&o.field.name()===7&&o.field.length()===8);
 check(Wrapped.name()===9&&Wrapped.length()===10&&reads===2);
 return 'members:'+reads;
})();
"###,
        r###"result
"###,
        Value::String("members:2".into()),
    );
}

