from pathlib import Path
import hashlib
import json
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-naming-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2) + '\n').encode())

prefix = "function check(v){if(!v)throw new Error('class naming oracle');}\n"
drafts = [
    ('naming_identifier_and_logical_assignment', '''var result=(function(){
 var trace='',assigned,andName=1,orName=0,nullName=null;
 var first=(assigned=class {[(trace+='A','m')](){}});
 var second=(andName&&=class {[(trace+='B','m')](){}});
 var third=(orName||=class {[(trace+='C','m')](){}});
 var fourth=(nullName??=class {[(trace+='D','m')](){}});
 check(first===assigned&&second===andName&&third===orName&&fourth===nullName);
 check(assigned.name==='assigned'&&andName.name==='andName'&&orName.name==='orName'&&nullName.name==='nullName');
 var skipAnd=0,marker={},skipOr=marker,skipNull=false;
 check((skipAnd&&=class {[(trace+='X','m')](){}})===0);
 check((skipOr||=class {[(trace+='Y','m')](){}})===marker);
 check((skipNull??=class {[(trace+='Z','m')](){}})===false);
 check(skipAnd===0&&skipOr===marker&&skipNull===false);
 var hinted;hinted=class {static read(){return hinted;}};
 var saved=hinted;check(saved.name==='hinted');hinted=7;check(saved.read()===7);
 var explicit;explicit=class Inner {};check(explicit.name==='Inner');
 return trace+'|names';
})();
''', 'ABCD|names',
     'Identifier assignment and each taken logical assignment use NamedEvaluation with the identifier. Skipped logical assignments do not evaluate class keys. The inferred display name creates no inner lexical class binding; an explicit class name wins.'),
    ('naming_parameter_defaults', '''var result=(function(){
 function ordinary(Param=class {}){return Param;}
 var arrow=(Arrow=(class {}))=>Arrow;
 class Holder {
  constructor(Ctor=class {}){this.C=Ctor;}
  method(Method=class {}){return Method;}
  static take(Static=class {}){return Static;}
 }
 var p=ordinary(),a=arrow(),h=new Holder(),m=h.method(),s=Holder.take();
 check(p.name==='Param'&&a.name==='Arrow'&&h.C.name==='Ctor'&&m.name==='Method'&&s.name==='Static');
 var marker={},count=0;
 function optional(Skip=class {[(count++,'m')](){}}){return Skip;}
 check(optional(marker)===marker&&count===0);
 check(optional().name==='Skip'&&count===1);
 var d=Object.getOwnPropertyDescriptor(p,'name');
 check(d.value==='Param'&&!d.writable&&!d.enumerable&&d.configurable);
 return p.name+'|'+a.name+'|'+h.C.name+'|'+m.name+'|'+s.name+'|'+count;
})();
''', 'Param|Arrow|Ctor|Method|Static|1',
     'A default initializer is evaluated only for undefined. Anonymous class defaults receive the binding identifier as the name in ordinary functions, arrows, constructors and methods; the display property retains ordinary function-name attributes.'),
    ('naming_object_data_property_keys', '''var result=(function(){
 var trace='',key={toString:function(){trace+='K';return 'computed';}},sym=Symbol('slot'),empty=Symbol();
 var o={
  plain:class {},
  'spaced key':(class {}),
  [key]:class {[(trace+='C','m')](){}},
  [(trace+='S',sym)]:class {[(trace+='D','m')](){}},
  [empty]:class {}
 };
 check(o.plain.name==='plain'&&o['spaced key'].name==='spaced key'&&o.computed.name==='computed');
 check(o[sym].name==='[slot]'&&o[empty].name==='');
 var d=Object.getOwnPropertyDescriptor(o[sym],'name');
 check(d.value==='[slot]'&&!d.writable&&!d.enumerable&&d.configurable);
 check(Object.getOwnPropertyDescriptor(o,sym).value===o[sym]);
 return trace+'|'+o.plain.name+'|'+o['spaced key'].name+'|'+o.computed.name+'|'+o[sym].name+'|'+o[empty].name;
})();
''', 'KCSD|plain|spaced key|computed|[slot]|',
     'Object data definitions evaluate and convert the key before class evaluation. Anonymous classes receive string or Symbol property keys; a described Symbol yields a bracketed name, while an undescribed Symbol yields the empty name. Parentheses preserve the naming context.'),
    ('naming_parentheses_comma_conditional_boundaries', '''var result=(function(){
 var Wrapped=(((class {}))),Comma=(0,class {}),Conditional=(true?class {}:class {}),Alternative=(false?class {}:class {});
 var Assigned;Assigned=((class {}));
 var o={wrapped:(class {}),comma:(0,class {}),conditional:(true?class {}:class {})};
 check(Wrapped.name==='Wrapped'&&Assigned.name==='Assigned'&&o.wrapped.name==='wrapped');
 check(Comma.name===''&&Conditional.name===''&&Alternative.name===''&&o.comma.name===''&&o.conditional.name==='');
 return Wrapped.name+'|'+Assigned.name+'|'+o.wrapped.name+'|empty';
})();
''', 'Wrapped|Assigned|wrapped|empty',
     'Parentheses delegate anonymous-function detection and NamedEvaluation. Comma and conditional expressions are not anonymous function definitions; their evaluated anonymous classes retain the empty name, even when their resulting values enter a binding or data property.'),
    ('naming_hints_preserve_static_name_and_length', '''var result=(function(){
 var reads=0,Assigned;Assigned=class {static name(){return 1;} static get length(){reads++;return 2;}};
 var Logical=0;Logical||=class {static get name(){reads++;return 3;} static length(){return 4;}};
 function defaults(Default=class {static name(){return 5;} static length(){return 6;}}){return Default;}
 var Default=defaults(),o={field:class {static name(){return 7;} static length(){return 8;}}};
 var Wrapped=(class {static name(){return 9;} static length(){return 10;}});
 check(reads===0);
 var n=Object.getOwnPropertyDescriptor(Assigned,'name'),l=Object.getOwnPropertyDescriptor(Assigned,'length');
 check(n.value===Assigned.name&&n.writable&&!n.enumerable&&n.configurable);
 check(typeof l.get==='function'&&l.get.name==='get length'&&!l.enumerable&&l.configurable);
 check(Assigned.name()===1&&Assigned.length===2&&Logical.name===3&&Logical.length()===4);
 check(Default.name()===5&&Default.length()===6&&o.field.name()===7&&o.field.length()===8);
 check(Wrapped.name()===9&&Wrapped.length()===10&&reads===2);
 return 'members:'+reads;
})();
''', 'members:2',
     'Class naming and constructor length precede static member definitions. NamedEvaluation must not apply a post-evaluation rewrite or invoke these static getters. Assignment, logical assignment, parameter, object and parenthesized hints preserve the own static methods/accessors.')
]

rows = []
for case_id, body, expected, derivation in drafts:
    source = prefix + body
    source_ref = put(D / 'literals' / (case_id + '.js'), source.encode())
    observation_ref = put(D / 'readbacks' / (case_id + '.js'), b'result\n')
    rows.append({'id': case_id, 'kind': 'semantic', 'source': source,
                 'observation': 'result\n', 'expected': {'type': 'string', 'value': expected},
                 'modes': ['sloppy', 'strict'], 'timing': 'readback after successful public execution',
                 'derivation': derivation, 'source_file': source_ref,
                 'observation_file': observation_ref})

cases = obj(D / 'cases.json', rows)
published = []
for relative_path in ['src/script.rs', 'src/script/parser.rs']:
    b = subprocess.check_output(['git', 'show', f'{BASE}:{relative_path}'], cwd=F / 'worktree')
    published.append({'relative_path': relative_path, 'base': BASE, 'bytes': len(b), 'sha256': sha(b)})
spec = obj(D / 'spec-basis.json', {
    'checked_date': '2026-10-15', 'basis': 'Current official ECMAScript2027 algorithms, read independently; no engine observations.',
    'references': [
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-assignment-operators-runtime-semantics-evaluation', 'sections': ['13.15.2'], 'application': 'Identifier = and three logical assignments supply naming hints only on evaluated anonymous RHS forms.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-object-initializer-runtime-semantics-propertydefinitionevaluation', 'sections': ['13.2.5.6'], 'application': 'The evaluated data property key is the naming hint.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-statements-and-declarations.html#sec-runtime-semantics-iteratorbindinginitialization', 'sections': ['14.3.3.7'], 'application': 'Single-name defaults initialize only undefined arguments and supply the parameter identifier.'},
        {'url': 'https://tc39.es/ecma262/multipage/syntax-directed-operations.html#sec-isanonymousfunctiondefinition', 'sections': ['8.4.2', '8.4.3', '8.4.5'], 'application': 'Parentheses preserve anonymous definition status, unlike comma/conditional wrappers; a hint is not an inner lexical binding.'},
        {'url': 'https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-setfunctionname', 'sections': ['10.2.9'], 'application': 'Symbol descriptions determine the display name and its descriptor.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-classdefinitionevaluation', 'sections': ['15.7.14'], 'application': 'Naming precedes member definitions, which may replace own name/length properties.'}
    ], 'published_source_bindings': published,
    'source_feasibility': 'Published lexer/tests already cover &&=, ||= and ??=; parameters, arrows, descriptors and computed object keys use established public syntax. New class syntax is the selected checkpoint surface. No future producer source inspected.'
})
scope = obj(D / 'contract.json', {
    'base': BASE, 'additive_to': bind(F / 'public-contract-2/source-ready.json'),
    'prior_payload': bind(F / 'public-tests-1/source-ready.json'),
    'scope': 'Five independently authored naming-context rows; all original62 rows and payload bytes remain unchanged.',
    'counts': {'new_groups': 5, 'new_modes': 10, 'maximum_new_public_calls': 20, 'composed_groups': 67, 'composed_modes': 134},
    'interface': 'Append tests to the existing class_semantics_tests module and reuse its observe helper; no extra registration or private APIs.',
    'expected_parent_reachability': 'Each new test first executes its sloppy source. Published parent has no class syntax support; it should refuse before readback and before strict mode. This is a source-derived prediction, not an observed run.',
    'limits': 'No budgets, new unsupported syntax scope, producer-shaped assertions, project execution or baseline/policy changes.'
})
seal = obj(D / 'literals-ready.json', {
    'status': 'frozen independent source-derived literals, before Rust conversion', 'base': BASE,
    'cases': cases, 'contract': scope, 'spec_basis': spec, 'author': bind(Path(__file__)),
    'literal_files': [v for row in rows for v in [row['source_file'], row['observation_file']]],
    'new_groups': 5, 'planned_modes': 10, 'project_execution': False
})
print(json.dumps(seal))
