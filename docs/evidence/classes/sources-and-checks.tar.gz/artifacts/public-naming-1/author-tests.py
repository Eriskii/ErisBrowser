from pathlib import Path
import difflib
import hashlib
import json
import re

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-naming-1'
RELATIVE = 'src/script/class_semantics_tests.rs'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, v):
    return put(p, (json.dumps(v, indent=2) + '\n').encode())

literal_seal = bind(D / 'literals-ready.json')
assert literal_seal['sha256'] == '54f5c7a1a3098e95797727c53079bb2f33b6fe5d206e1729409f18e48601e5c0'
rows = json.loads((D / 'cases.json').read_bytes())
assert len(rows) == 5
prior = F / 'public-tests-1/raw' / RELATIVE
before = prior.read_bytes()
assert sha(before) == 'a7d5f5103c69f00db9fac062f4f087e2c82c060cb995a90a785831bc99e50469'
old_names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', before.decode(), re.M)
assert len(old_names) == len(set(old_names)) == 62
blocks = []
roster = []
for row in rows:
    assert row['kind'] == 'semantic'
    for key in ['source_file', 'observation_file']:
        assert bind(Path(row[key]['path'])) == row[key]
    source = Path(row['source_file']['path']).read_text()
    observation = Path(row['observation_file']['path']).read_text()
    assert source == row['source'] and observation == row['observation']
    assert '"###' not in source and '"###' not in observation
    name = 'class_public_' + row['id']
    assert name not in old_names
    expected = json.dumps(row['expected']['value'])
    block = ('#[test]\nfn ' + name + '() {\n    observe(\n        ' + json.dumps(row['id']) + ',\n'
             + '        r###"' + source + '"###,\n        r###"' + observation + '"###,\n'
             + '        Value::String(' + expected + '.into()),\n    );\n}\n\n')
    assert re.findall(r'r###"(.*?)"###', block, re.S) == [source, observation]
    assert re.findall(r'Value::String\(("[^\n]*")\.into\(\)\)', block) == [expected]
    blocks.append(block)
    roster.append({'test_name': name, 'case_id': row['id'], 'modes': row['modes'],
                   'source': row['source_file'], 'observation': row['observation_file'],
                   'expected': row['expected'], 'helper': 'unchanged observe from public-tests-1'})

suffix = ''.join(blocks).encode()
after = before + suffix
assert after[:len(before)] == before
names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', after.decode(), re.M)
assert len(names) == len(set(names)) == 67 and names[:62] == old_names
before_ref = put(D / 'before' / RELATIVE, before)
raw_ref = put(D / 'raw' / RELATIVE, after)
append_ref = put(D / 'append-tests.rs', suffix)
diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                   fromfile='before/' + RELATIVE, tofile='raw/' + RELATIVE))
diff_ref = put(D / 'diffs' / (RELATIVE + '.diff'), diff.encode())
roster_ref = obj(D / 'roster.json', {'new_tests': roster, 'original_test_names': old_names,
                                    'composed_test_names': names, 'new_groups': 5,
                                    'new_mode_attempts': 10, 'maximum_new_public_calls': 20,
                                    'composed_groups': 67, 'composed_mode_attempts': 134,
                                    'maximum_composed_public_calls': 300,
                                    'qualification': 'Attempts and maximum calls are planned, not executed; an assertion stops later readback/mode phases.'})
checks = obj(D / 'checks.json', {
    'literal_conversion': 'All ten JS/readback byte strings independently extracted from Rust raw strings and matched exactly; five Value string expressions matched fixed expectations.',
    'original_preservation': 'The first 32186 bytes of the full module equal the immutable public-tests-1 module; inverse removes only the appended suffix.',
    'unchanged_literal_contract': bind(F / 'public-contract-2/source-ready.json'),
    'unchanged_test_contract': bind(F / 'public-tests-1/source-ready.json'),
    'prior_literal_peer': bind(F / 'public-contract-review-1/review.json'),
    'root_module_selection': bind(F / 'root/public-test-selection-1.json'),
    'registration': 'No change. The existing class_semantics_tests declaration covers all 67 rows. Root may apply the append fragment if its imported module has formatting changes.',
    'private_state': 'No fields, counters, limits, queues or resets accessed; the unchanged public observe helper creates fresh Runtime/Document per mode.',
    'execution': 'Only this standalone stdlib author/transcription checker ran. No project import, compiler, JS engine, test or live file edit.'
})
seal = obj(D / 'source-ready.json', {
    'status': 'ready for independent source peer and root additive import',
    'base': 'f3118ae5787c410648657f7c822efb7014201dd1',
    'frozen_literals': literal_seal, 'cases': bind(D / 'cases.json'),
    'spec_basis': bind(D / 'spec-basis.json'), 'contract': bind(D / 'contract.json'),
    'files': [{'relative_path': RELATIVE, 'before': before_ref, 'raw': raw_ref, 'diff': diff_ref}],
    'append': append_ref, 'roster': roster_ref, 'checks': checks,
    'authors': [bind(D / 'author-literals.py'), bind(Path(__file__))],
    'new_groups': 5, 'new_mode_attempts': 10, 'composed_groups': 67,
    'registration_changes': 0,
    'qualification': 'Independent spec-derived additive contract. Prior62 and all frozen literals remain unchanged; no future producer read or project execution.'
})
print(json.dumps(seal))
