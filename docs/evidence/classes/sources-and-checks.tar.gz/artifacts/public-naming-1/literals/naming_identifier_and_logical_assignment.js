function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var trace='',assigned,andName=1,orName=0,nullName=null;
 var first=(assigned=class {[(trace+='A','m')](){}});
 var second=(andName&&=class {[(trace+='B','m')](){}});
 var third=(orName||=class {[(trace+='C','m')](){}});
 var fourth=(nullName??=class {[(trace+='D','m')](){}});
 check(first===assigned&&second===andName&&third===orName&&fourth===nullName);
 check(assigned.name==='assigned'&&andName.name==='andName'&&orName.name==='orName'&&nullName.name==='nullName');
 var skipAnd=0,marker={},skipOr=marker,skipNull=false;
 check((skipAnd&&=class {[(trace+='X','m')](){}})===0);
 check((skipOr||=class {[(trace+='Y','m')](){}})===marker);
 check((skipNull??=class {[(trace+='Z','m')](){}})===false);
 check(skipAnd===0&&skipOr===marker&&skipNull===false);
 var hinted;hinted=class {static read(){return hinted;}};
 var saved=hinted;check(saved.name==='hinted');hinted=7;check(saved.read()===7);
 var explicit;explicit=class Inner {};check(explicit.name==='Inner');
 return trace+'|names';
})();
