function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var trace='',key={toString:function(){trace+='K';return 'computed';}},sym=Symbol('slot'),empty=Symbol();
 var o={
  plain:class {},
  'spaced key':(class {}),
  [key]:class {[(trace+='C','m')](){}},
  [(trace+='S',sym)]:class {[(trace+='D','m')](){}},
  [empty]:class {}
 };
 check(o.plain.name==='plain'&&o['spaced key'].name==='spaced key'&&o.computed.name==='computed');
 check(o[sym].name==='[slot]'&&o[empty].name==='');
 var d=Object.getOwnPropertyDescriptor(o[sym],'name');
 check(d.value==='[slot]'&&!d.writable&&!d.enumerable&&d.configurable);
 check(Object.getOwnPropertyDescriptor(o,sym).value===o[sym]);
 return trace+'|'+o.plain.name+'|'+o['spaced key'].name+'|'+o.computed.name+'|'+o[sym].name+'|'+o[empty].name;
})();
