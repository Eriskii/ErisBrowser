function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var Wrapped=(((class {}))),Comma=(0,class {}),Conditional=(true?class {}:class {}),Alternative=(false?class {}:class {});
 var Assigned;Assigned=((class {}));
 var o={wrapped:(class {}),comma:(0,class {}),conditional:(true?class {}:class {})};
 check(Wrapped.name==='Wrapped'&&Assigned.name==='Assigned'&&o.wrapped.name==='wrapped');
 check(Comma.name===''&&Conditional.name===''&&Alternative.name===''&&o.comma.name===''&&o.conditional.name==='');
 return Wrapped.name+'|'+Assigned.name+'|'+o.wrapped.name+'|empty';
})();
