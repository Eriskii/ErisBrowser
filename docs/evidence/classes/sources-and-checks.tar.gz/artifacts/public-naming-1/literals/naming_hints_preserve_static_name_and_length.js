function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 var reads=0,Assigned;Assigned=class {static name(){return 1;} static get length(){reads++;return 2;}};
 var Logical=0;Logical||=class {static get name(){reads++;return 3;} static length(){return 4;}};
 function defaults(Default=class {static name(){return 5;} static length(){return 6;}}){return Default;}
 var Default=defaults(),o={field:class {static name(){return 7;} static length(){return 8;}}};
 var Wrapped=(class {static name(){return 9;} static length(){return 10;}});
 check(reads===0);
 var n=Object.getOwnPropertyDescriptor(Assigned,'name'),l=Object.getOwnPropertyDescriptor(Assigned,'length');
 check(n.value===Assigned.name&&n.writable&&!n.enumerable&&n.configurable);
 check(typeof l.get==='function'&&l.get.name==='get length'&&!l.enumerable&&l.configurable);
 check(Assigned.name()===1&&Assigned.length===2&&Logical.name===3&&Logical.length()===4);
 check(Default.name()===5&&Default.length()===6&&o.field.name()===7&&o.field.length()===8);
 check(Wrapped.name()===9&&Wrapped.length()===10&&reads===2);
 return 'members:'+reads;
})();
