function check(v){if(!v)throw new Error('class naming oracle');}
var result=(function(){
 function ordinary(Param=class {}){return Param;}
 var arrow=(Arrow=(class {}))=>Arrow;
 class Holder {
  constructor(Ctor=class {}){this.C=Ctor;}
  method(Method=class {}){return Method;}
  static take(Static=class {}){return Static;}
 }
 var p=ordinary(),a=arrow(),h=new Holder(),m=h.method(),s=Holder.take();
 check(p.name==='Param'&&a.name==='Arrow'&&h.C.name==='Ctor'&&m.name==='Method'&&s.name==='Static');
 var marker={},count=0;
 function optional(Skip=class {[(count++,'m')](){}}){return Skip;}
 check(optional(marker)===marker&&count===0);
 check(optional().name==='Skip'&&count===1);
 var d=Object.getOwnPropertyDescriptor(p,'name');
 check(d.value==='Param'&&!d.writable&&!d.enumerable&&d.configurable);
 return p.name+'|'+a.name+'|'+h.C.name+'|'+m.name+'|'+s.name+'|'+count;
})();
