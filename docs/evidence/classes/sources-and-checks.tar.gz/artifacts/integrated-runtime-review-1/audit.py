from pathlib import Path
import hashlib, json, re, subprocess, difflib

F=Path('/tmp/eris-class-runtime-plan-1')
W=F/'worktree'
D=F/'integrated-runtime-review-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def digest(b): return hashlib.sha256(b).hexdigest()
def binding(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def write(n,v):
    p=D/n;p.write_text(json.dumps(v,indent=2)+'\n');return binding(p)

# Lexical source inspection only: no Rust or repository Python is executed.
RAW=re.compile(r'(?:br|r)(#*)"')
CHAR=re.compile(r"(?:b)?'(?:\\(?:u\{[^}]*\}|x[0-9a-fA-F]{2}|.)|[^'\\])'")
WORD=re.compile(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+')
def tokens(s):
    i=0
    while i<len(s):
        if s[i].isspace(): i+=1;continue
        if s.startswith('//',i):
            k=s.find('\n',i);i=len(s) if k<0 else k;continue
        if s.startswith('/*',i):
            depth=1;i+=2
            while depth:
                if s.startswith('/*',i):depth+=1;i+=2
                elif s.startswith('*/',i):depth-=1;i+=2
                else:i+=1
            continue
        start=i
        m=RAW.match(s,i)
        if m:
            end='"'+m.group(1);i=s.index(end,i+len(m.group(0)))+len(end)
        elif s[i]=='"' or s.startswith('b"',i):
            i+=2 if s.startswith('b"',i) else 1
            while s[i]!='"':i+=2 if s[i]=='\\' else 1
            i+=1
        else:
            m=CHAR.match(s,i)
            if m:i+=len(m.group(0))
            else:
                m=WORD.match(s,i);i+=len(m.group(0)) if m else 1
        yield (s[start:i],start,i)

def function(s,name):
    ts=list(tokens(s));idx=next(i for i,t in enumerate(ts[:-1]) if t[0]=='fn' and ts[i+1][0]==name)
    j=idx
    while ts[j][0]!='{':j+=1
    depth=1;k=j+1
    while depth:
        depth+=(ts[k][0]=='{')-(ts[k][0]=='}');k+=1
    return s[ts[idx][1]:ts[k-1][2]], s[ts[j][1]:ts[k-1][2]]

runtime_paths=['src/script.rs','src/script/classes.rs','src/script/construction.rs','src/script/machine.rs','src/script/machine/calls.rs','src/script/machine/classes.rs','src/script/machine/statements.rs']
source={p:(W/p).read_bytes() for p in runtime_paths}
current={p:b.decode() for p,b in source.items()}
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==BASE
old={}
def base(p):
    if p not in old:old[p]=subprocess.check_output(['git','show',BASE+':'+p],cwd=W).decode()
    return old[p]

unchanged=[]
for p,names in {
 'src/script/construction.rs':['is_constructor','construct_with_target','constructor_prototype','constructed_prototype'],
 'src/script.rs':['function_value','charge_function_code_copy','define_own_key'],
 'src/script/machine.rs':['reserve_values'],
 'src/script/machine/call_spread.rs':['prepay_entry','prepay_item'],
 'src/script/dom_prototypes.rs':['dom_proto_text','dom_proto_object'],
 'src/script/symbols.rs':['set_key_function_name'],
 'src/script/promises.rs':['growth_plan'],
 'src/script/promises/factories.rs':['object_slot_plan'],
}.items():
    now=(W/p).read_text()
    for name in names:
        prior_body=function(base(p),name)[1];now_body=function(now,name)[1]
        assert prior_body==now_body,(p,name)
        unchanged.append({'path':p,'function':name,'body_sha256':digest(now_body.encode()),'exact_body_equal':True})

construct=current['src/script/construction.rs']
dispatch='''            Value::Function(id) if self.functions[*id].code.class_kind.is_some() => {
                self.construct_class(*id, arguments, new_target, doc)
            }
'''
assert construct.count(dispatch)==1
assert construct.replace(dispatch,'').replace('pub(super) fn constructed_prototype','fn constructed_prototype')==base('src/script/construction.rs')

classes=current['src/script/classes.rs']
validation=function(classes,'class_validate_superclass')[1]
assert validation.index('self.work(1)?')<validation.index('self.is_constructor(superclass.clone())?')<validation.index('ScriptError::type_error')
assert not any(t in validation for t in ['self.charge','construct_with_target','self.calls','enter_stack'])
finish=function(current['src/script/machine.rs'],'finish_super')[1]
assert finish.index('class_validate_superclass')<finish.index('construct_with_target')<finish.index('class_bind_this')
class_start=function(current['src/script/machine/calls.rs'],'class_start')[1]
default=class_start[class_start.index('if kind == code::ClassKind::DefaultDerived'):class_start.index('// Retain the unbound')]
assert default.index('.prototype')<default.index('class_validate_superclass')<default.index('construct_with_target')
assert {'new_array','argument_list','spread_start'}.isdisjoint(t[0] for t in tokens(default))

correction=json.loads((F/'root/bound-superclass-correction-1/receipt.json').read_text())
correction_matches=[]
for row in correction['source_changes']:
    p=row['path'];now=source[p]
    # A subsequently appended test declaration is not a production-body change.
    exact=digest(now)==row['after_sha256']
    correction_matches.append({'path':p,'receipt_after_sha256':row['after_sha256'],'current_sha256':digest(now),'exact_file_match':exact})

# E0716 repair: exact expected Value is retained; formatting is lexically inert.
prior=(F/'private-tests-2/raw/src/script/classes/quota_tests.rs').read_text()
live=(W/'src/script/classes/quota_tests.rs').read_text()
fixed=live.replace('            let expected_constructor = Value::Function(old_functions);\n','').replace('Some(&expected_constructor)','Some(&Value::Function(old_functions))')
prior_tokens=[t[0] for t in tokens(prior)];fixed_tokens=[t[0] for t in tokens(fixed)]
format_edits=[]
for tag,i,j,k,l in difflib.SequenceMatcher(None,prior_tokens,fixed_tokens,autojunk=False).get_opcodes():
    if tag=='equal':continue
    assert tag=='insert' and fixed_tokens[k:l]==[','] and fixed_tokens[l] in [')',']','}']
    format_edits.append({'token_offset':k,'insert':',','before':fixed_tokens[l],'prior_context':prior_tokens[max(0,i-5):j+5]})

inputs=[
 'root/selection-1.json','root/class-accounting-selection-1.json',
 'accounting-proposal-1/source-ready.json','accounting-proposal-1/proposal.json','accounting-proposal-1/measurement-addendum-1.json',
 'accounting-review-1/review.json','runtime-implementation-1/source-ready.json','runtime-implementation-1/accounting-addendum.json',
 'root-implementation-1/source-ready.json','root-implementation-1/chunks.json',
 'root/compiler-correction-1.json','root/private-compiler-correction-1.json',
 'root/bound-superclass-correction-1/receipt.json',
 'private-tests-2/source-ready.json','private-tests-review-1/review.json',
 'super-validation-tests-1/source-ready.json','public-superclass-regression-1/source-ready.json',
 'constructor-design-1/primary-tool-readback.txt',
]
snap=[]
for p,b in source.items():
    q=D/'source'/p;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
    snap.append({'relative_path':p,'snapshot':binding(q),'live_path':str(W/p)})
assert all((W/p).read_bytes()==b for p,b in source.items()),'live source changed while snapshotting'
checks=write('checks.json',{
 'git_base':BASE,'runtime_snapshot':snap,'published_joins':[{'path':p,'bytes':len(s.encode()),'sha256':digest(s.encode())} for p,s in old.items()],
 'exact_unchanged_helper_bodies':unchanged,
 'construction_inverse':'Removing the sole class dispatch branch and reversing the one visibility widening gives exact published construction.rs bytes.',
 'super_validation':{'helper_order':True,'explicit_after_arguments_before_construct':True,'default_live_capture_before_validation_before_construct':True,'no_helper_heap_stack_or_callback':True,'receipt_joins':correction_matches},
 'private_compile_correction':'Removing expected_constructor local and restoring its inline Value reference leaves only formatter-inserted trailing commas; their contexts were inspected as call/array/struct/multielement-tuple punctuation, not a new singleton tuple. Strings/numbers/assertions unchanged.',
 'private_format_punctuation':format_edits,
 'project_execution':False,'live_edits':False,
})
report={
 'status':'clear within scoped class runtime review after one accepted source correction',
 'base':BASE,'scope':'Seven integrated runtime source files; class-only additions and their selected legacy helper seams. This is not a complete parser, repository inventory, validation or conformance audit.',
 'checks':checks,'inputs':[binding(F/p) for p in inputs],
 'finding':{
  'id':'bound-superclass-before-Construct','state':'addressed in inspected source',
  'original':'The selected direct super transfer reached the legacy bound dispatcher before IsConstructor. A bound arrow could therefore consume bound argument storage and produce a terminal resource failure instead of the required ordinary TypeError.',
  'chronology':'This was an independent integrated-source finding against an expressly selected bridge. Earlier proposal/review and the superseded accounting-addendum remain unchanged. No test outcome was used to derive the finding or new expectations.',
  'correction':'class_validate_superclass pays one input-copy work before unchanged per-hop IsConstructor and maps false to TypeError; no heap or call/stack admission. Explicit super calls it after all arguments; default-derived calls it after live parent capture and before forwarding.',
  'source_pointers':['src/script/classes.rs::class_validate_superclass','src/script/machine.rs::finish_super','src/script/machine/calls.rs::class_start'],
  'independent_regressions':'One private group/four exact work rows with zero available heap; one public group/two modes checking both constructor paths and EATDT effects. Source holds are sealed; this review makes no execution claim.',
  'primary_sources':['https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword-runtime-semantics-evaluation','https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-runtime-semantics-classdefinitionevaluation'],
 },
 'reviewed_invariants':[
  {'area':'Definition ordering','result':'Name/strict TDZ environment precedes heritage. Nonnull heritage pays each retained copy at its reached stage; constructability precedes observable prototype Get. Prototype and constructor allocation begin after that Get returns. Computed key evaluation and ToPropertyKey precede fresh method/property capacity plans.'},
  {'area':'Physical capacity and publication','result':'Environment, object, function and property-order plans use current lengths/capacities; work and heap admissions precede reserve/push. No author call occurs between planning and physical reserve/publication. Already admitted partial arena rows may remain on a later metadata refusal; this is an explicit tested prefix, not transactional rollback. Inner/outer class binding initialization stays after completed definition and all fallible lookup work.'},
  {'area':'Helper ownership','result':'New name conversion accounts UTF-8 scan, UTF-16 units and retained backing allocation. Constructor/method owner envelopes, legacy code metadata, both arena plans, descriptor lookup/order storage and ordinary define charges follow the frozen selected order. Getter/setter descriptors use own definition and preserve compatible counterpart fields; false ordinary definition becomes TypeError.'},
  {'area':'Construction and activation','result':'Class Call rejects before activation/default/body; base prototype Get/allocation precedes defaults. Explicit derived activation retains uninitialized this, active constructor and original NewTarget; parameter/body children preserve lexical ownership. Default-derived forwards the existing arguments list directly without Array iterator lookup. Escaped arrow ownership is retained in arena environments.'},
  {'area':'Terminal unwind','result':'machine::drive returns ResourceLimit/Unsupported before statement catch/finally dispatch, truncates the owned frame suffix and restores eval depth, stack units and calls. construct_class restores its separately owned call/stack4 guard on every returned Result. Terminal cleanup performs no author callback or new allocation. Sticky suspension is supplied by existing public execution/observer boundaries, not promised by raw private helpers.'},
  {'area':'Legacy preservation','result':'Fifteen reached legacy helper bodies independently match published bytes. construction.rs inverse is exact apart from class dispatch and the selected visibility widening. No old helper tariff or resource-limit adjustment is required by the corrected validation helper.'},
 ],
 'limitations':['No project, Rust, JavaScript or tests executed by this reviewer; no execution outcome claims.','Source snapshot is scoped and may predate later registration/formatting-only edits; final inventory must bind its own exact bytes.','Original private hold had an E0716 temporary reference error; root retained it and added a local expected_constructor binding. Its inverse leaves only inspected formatter trailing commas, with unchanged oracle.','Parser grammar, broader builtin semantics and complete security/conformance remain outside this bounded review.'],
 'unresolved_findings':[],
}
assert len(unchanged)==15
print(json.dumps(write('review.json',report)))
