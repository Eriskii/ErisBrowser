before+'|'+trace+'|'+(resolved===token)+'|'+(receiver===undefined)
