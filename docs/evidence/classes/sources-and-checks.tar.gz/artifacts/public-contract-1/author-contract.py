from pathlib import Path
import hashlib
import json
import subprocess
import textwrap

F=Path('/tmp/eris-class-runtime-plan-1');D=F/'public-contract-1'
E=Path('/tmp/eris-promise-try-upstream-plan-1');W=E/'worktree'
BASE='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
R=E/'next-class-readiness-1/readiness.json'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return bind(p)
def obj(p,v):return put(p,(json.dumps(v,indent=2)+'\n').encode())
def clean(s):return textwrap.dedent(s).strip()+'\n'
assert sha(R.read_bytes())=='f900530de436786b9be3acc5ac4f6972c934176a758611bd66bdd2cbe137151d'
readiness=json.loads(R.read_bytes());selection=json.loads((F/'root/selection-provisional.json').read_bytes())
assert selection['included']==readiness['first_slice']['included']
assert selection['explicitly_unsupported']==readiness['first_slice']['explicitly_unsupported']
cases=[]
def semantic(name,family,body,expected,reason,observe='result',timing='after public execution checkpoint'):
 source="function check(v){if(!v)throw new Error('class oracle');}\n"+clean(body)
 cases.append({'id':name,'family':family,'kind':'semantic','source':source,
               'observation':observe,'expected':{'type':'string','value':expected},
               'timing':timing,'derivation':reason})

semantic('lexical_names_and_tdz','lexical',r'''
var result=(function(){
  var t='';
  try { typeof Later; class Later {} } catch(e){check(e instanceof ReferenceError);t+='T';}
  try { class Self extends Self {} } catch(e){check(e instanceof ReferenceError);t+='H';}
  try { class Key { [Key](){} } } catch(e){check(e instanceof ReferenceError);t+='K';}
  class Outer { static identity(){return Outer;} static write(){Outer=7;} }
  var saved=Outer;Outer=9;check(saved.identity()===saved&&Outer===9);
  try { saved.write(); } catch(e){check(e instanceof TypeError);t+='I';}
  var Expr=class Inner {static identity(){return Inner;}};
  check(Expr.identity()===Expr&&typeof Inner==='undefined');
  var Inferred=class {};var Shadow=class {static name(){return 3;} static length(){return 4;}};
  check(Inferred.name==='Inferred'&&Shadow.name()===3&&Shadow.length()===4);
  return t;
})();
''','THKI','Outer declaration binding is mutable; its separate immutable inner class name survives reassignment. Heritage and computed names run before inner initialization.')

semantic('global_and_block_lexical','lexical',r'''
class ClassScopeWitness {}
var result=(function(){
  check(window.ClassScopeWitness===undefined);
  var first=ClassScopeWitness,read;
  { class ClassScopeWitness {static value(){return 4;}} read=()=>ClassScopeWitness; }
  check(read()!==first&&read().value()===4&&ClassScopeWitness===first);
  ClassScopeWitness=7;check(ClassScopeWitness===7);return 'lexical';
})();
''','lexical','Global class declaration is lexical, block capture retains its own class, and outer assignment remains permitted.')

semantic('constructor_and_method_metadata','shape',r'''
var result=(function(){
  var O=Object,H=O.prototype.hasOwnProperty;
  class Base {constructor(a,b=2,...rest){} m(a,b){} get x(){return 1;} set x(v){} static s(a){} }
  class Default extends Base {}
  var p=O.getOwnPropertyDescriptor(Base,'prototype'),n=O.getOwnPropertyDescriptor(Base,'name'),l=O.getOwnPropertyDescriptor(Base,'length');
  var c=O.getOwnPropertyDescriptor(Base.prototype,'constructor'),m=O.getOwnPropertyDescriptor(Base.prototype,'m'),x=O.getOwnPropertyDescriptor(Base.prototype,'x');
  check(p.value===Base.prototype&&!p.writable&&!p.enumerable&&!p.configurable);
  check(n.value==='Base'&&!n.writable&&!n.enumerable&&n.configurable);
  check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable&&Default.length===0);
  check(c.value===Base&&c.writable&&!c.enumerable&&c.configurable);
  check(m.writable&&!m.enumerable&&m.configurable&&m.value.length===2&&!H.call(m.value,'prototype'));
  check(!x.enumerable&&x.configurable&&x.get.name==='get x'&&x.set.name==='set x');
  check(O.getPrototypeOf(Base)===Function.prototype&&O.getPrototypeOf(Base.prototype)===O.prototype);
  check(O.getPrototypeOf(Default)===Base&&O.getPrototypeOf(Default.prototype)===Base.prototype);
  var errors=0;try{new m.value();}catch(e){check(e instanceof TypeError);errors++;}
  try{new x.get();}catch(e){check(e instanceof TypeError);errors++;}
  check(errors===2);return 'metadata:2';
})();
''','metadata:2','Class prototype and back-reference attributes differ; ordinary methods/accessors are nonconstructible and non-enumerable; default derived length stays zero.')

semantic('public_keys_accessors_and_name_disambiguation','members',r'''
var result=(function(){
 var sym=Symbol('tag'),writes=0;
 class C { ; static(){return 's';} get(){return 'g';} set(){return 't';}
   ['constructor'](){return 'ordinary';} [sym](){return this;} 'x-y'(){return 2;} 7(){return 7;}
   get pair(){return this.v;} set pair(v){writes++;this.v=v;}
   m(){return 1;} m(){return 2;} static constructor(){return 3;}
 }
 var x=new C();x.pair=9;var d=Object.getOwnPropertyDescriptor(C.prototype,'pair');
 check(x.static()==='s'&&x.get()==='g'&&x.set()==='t'&&x.constructor()==='ordinary');
 check(x[sym]()===x&&C.prototype[sym].name==='[tag]'&&x['x-y']()===2&&x[7]()===7);
 check(x.pair===9&&writes===1&&typeof d.get==='function'&&typeof d.set==='function');
 check(x.m()===2&&C.constructor()===3&&Object.keys(C.prototype).length===0);
 return 'members';
})();
''','members','Computed constructor is an ordinary member, while the literal constructor grammar is special; accessors pair and duplicate methods overwrite in source order.')

semantic('computed_key_order_and_abrupt_identity','members',r'''
var result=(function(){
 var trace='',token={},key={toString:function(){trace+='C';return 'm';}};
 function mark(s,k){trace+=s;return k;}
 class C { [mark('A',key)](){} static [mark('B','s')](){} [mark('D','n')](){} }
 check(trace==='ACBD');
 try { class Fail {[(trace+='E',key)](){} [(trace+='F',function(){throw token;}())](){} [(trace+='X','late')](){} } }
 catch(e){check(e===token);trace+='T';}
 check(typeof C.prototype.m==='function'&&typeof C.s==='function');return trace;
})();
''','ACBDE CFT'.replace(' ',''),'Each computed expression and key conversion precedes the next member; an exact thrown value stops later keys.')

semantic('heritage_validation_order','heritage',r'''
var result=(function(){
 var trace='',token={};function B(v){this.v=v;}
 var Bound=B.bind(null);Object.defineProperty(Bound,'prototype',{get:function(){trace+='P';return B.prototype;}});
 function heritage(){trace+='H';return Bound;}
 class C extends heritage(){[(trace+='K','m')](){} }
 var x=new C(7);check(x.v===7&&Object.getPrototypeOf(C)===Bound&&Object.getPrototypeOf(C.prototype)===B.prototype);
 try{class Bad extends (trace+='N',{}) {[(trace+='X','x')](){}}}catch(e){check(e instanceof TypeError);trace+='T';}
 var Throwing=B.bind(null);Object.defineProperty(Throwing,'prototype',{get:function(){trace+='G';throw token;}});
 try{class Bad extends Throwing {[(trace+='Y','y')](){}}}catch(e){check(e===token);trace+='I';}
 B.prototype=3;try{class Bad extends B {[(trace+='Z','z')](){}}}catch(e){check(e instanceof TypeError);trace+='V';}
 return trace;
})();
''','HPKNTGIV','Heritage value validation precedes prototype Get and member keys; a bound constructor provides an observable prototype getter without Proxy.')

semantic('intrinsic_parents_and_setter_bypass','shape',r'''
var result=(function(){
 var O=Object,F=Function,hits=0;
 O.defineProperty(O.prototype,'classMember',{set:function(){hits++;},configurable:true});
 O.defineProperty(F.prototype,'classStatic',{set:function(){hits++;},configurable:true});
 Object=function(){throw 1;};Function=function(){throw 2;};
 var C=class {classMember(){return 1;} static classStatic(){return 2;}};
 check(O.getPrototypeOf(C)===F.prototype&&O.getPrototypeOf(C.prototype)===O.prototype);
 check(new C().classMember()===1&&C.classStatic()===2&&hits===0);
 Object=O;Function=F;delete O.prototype.classMember;delete F.prototype.classStatic;return 'intrinsics:0';
})();
''','intrinsics:0','Saved intrinsic parents and own descriptor creation bypass replaced globals and inherited setters.')

semantic('class_call_guard_precedes_parameters','call',r'''
var result=(function(){
 var trace='';class C {constructor(x=(trace+='D',7)){trace+='B';this.x=x;}}
 function rejected(f){try{f();throw 'miss';}catch(e){check(e instanceof TypeError);trace+='T';}}
 rejected(()=>C((trace+='A',undefined)));rejected(()=>C.call(null));
 rejected(()=>C.apply(null,[]));rejected(()=>C.bind(null)());
 var x=new C();check(x.x===7&&typeof C==='function');return trace;
})();
''','ATTTTDB','Argument evaluation precedes Call; the class Call guard prevents parameter defaults/body for direct, call, apply and bound calls.')

semantic('class_strictness_and_detached_receiver','call',r'''
var result=(function(){
 class C {m(){return this;} nested(){return function(){return this;};} write(){ClassMissingWitness=1;}}
 var x=new C(),m=x.m,n=x.nested();check(m()===undefined&&n()===undefined);
 var strict=false;try{x.write();}catch(e){strict=e instanceof ReferenceError;}
 check(strict&&typeof ClassMissingWitness==='undefined');return 'strict';
})();
''','strict','Method code and nested ordinary code are strict even with a sloppy outer script.')

semantic('base_return_and_alternate_newtarget','construction',r'''
var result=(function(){
 var token={},seen;class B {constructor(v){seen=new.target;this.v=v;return v;}}
 var a=new B(3);check(a.v===3&&seen===B);check(new B(token)===token);
 function N(){}var proto={};N.prototype=proto;
 var b=Reflect.construct(B,[4],N);check(seen===N&&Object.getPrototypeOf(b)===proto&&b.v===4);
 var Bound=B.bind({bad:true},5),c=new Bound();check(seen===B&&Object.getPrototypeOf(c)===B.prototype&&c.v===5);
 return 'base-and-newtarget';
})();
''','base-and-newtarget','Base primitive return substitutes allocated this; object return wins. Alternate NewTarget and bound-target substitution preserve existing Construct rules.')

semantic('derived_return_and_this_states','construction',r'''
var result=(function(){
 var trace='',token={};function B(){trace+='B';this.ok=true;}
 function error(C,T){try{new C();throw 'miss';}catch(e){check(e instanceof T);trace+=T===ReferenceError?'R':'T';}}
 error(class extends B {constructor(){this.x=1;}},ReferenceError);
 error(class extends B {constructor(a=this){}},ReferenceError);
 error(class extends B {constructor(){}},ReferenceError);
 error(class extends B {constructor(){return undefined;}},ReferenceError);
 error(class extends B {constructor(){return 1;}},TypeError);
 error(class extends B {constructor(){super();return null;}},TypeError);
 var C=class extends B {constructor(){return token;}};check(new C()===token);
 var D=class extends B {constructor(){super();return undefined;}};check(new D().ok);
 return trace;
})();
''','RRRRTBTB','Derived missing/uninitialized this gives ReferenceError, non-undefined primitive return gives TypeError, and object return may precede super.')

semantic('repeated_super_and_retry_after_throw','super',r'''
var result=(function(){
 var trace='',count=0,token={};function B(){count++;trace+='B';this.n=count;}
 class D extends B {constructor(){super();try{super();}catch(e){check(e instanceof ReferenceError);trace+='R';}check(this.n===1);}}
 new D();check(count===2);
 function ThrowOnce(){trace+='X';if(count++===2)throw token;this.ok=true;}
 class Retry extends ThrowOnce {constructor(){try{super();}catch(e){check(e===token);trace+='C';}super();check(this.ok);}}
 new Retry();return trace;
})();
''','BBRXCX','The second super performs superclass effects before duplicate-this failure; an ordinary superclass throw leaves this available for retry.')

semantic('dynamic_super_capture_before_arguments','super',r'''
var result=(function(){
 var trace='';function A(v){trace+='A';this.v=v;}function B(v){trace+='B';this.v=v;}
 class D extends A {constructor(){super((trace+='X',Object.setPrototypeOf(D,A),7));}}
 Object.setPrototypeOf(D,B);var a=new D(),b=new D();
 check(a.v===7&&b.v===7&&Object.getPrototypeOf(a)===D.prototype&&Object.getPrototypeOf(D.prototype)===A.prototype);
 Object.setPrototypeOf(D,{});try{new D();}catch(e){check(e instanceof TypeError);trace+='T';}
 return trace;
})();
''','XBXAXT','super captures the active constructor parent before argument effects, but validates constructibility afterwards; this is independent of the instance-prototype chain.')

semantic('lexical_arrow_super_and_escaped_owner','super',r'''
var result=(function(){
 var trace='',saved,later,token={};function B(v){trace+='B'+v;this.v=v;}
 class D extends B {constructor(){var get=()=>this;try{get();}catch(e){check(e instanceof ReferenceError);trace+='R';}
   var call=()=>super(4);call();check(get()===this);saved=()=>[this,new.target];}}
 var d=new D(),pair=saved.call({});check(pair[0]===d&&pair[1]===D);
 class Late extends B {constructor(){later=()=>super(8);return token;}}
 check(new Late()===token);var x=later();check(x.v===8&&Object.getPrototypeOf(x)===Late.prototype);
 try{later();}catch(e){check(e instanceof ReferenceError);trace+='R';}return trace;
})();
''','RB4B8B8R','Arrows retain this/NewTarget/active constructor state, including an initially unbound activation that outlives an object-returning constructor.')

semantic('default_forwarding_without_array_iteration','construction',r'''
var result=(function(){
 var token={},seen,old=Array.prototype[Symbol.iterator],hits=0;
 function B(a,b){seen=[a,b,arguments.length,new.target];}
 class D extends B {}var d;
 Array.prototype[Symbol.iterator]=function(){hits++;throw token;};
 try{d=new D(token,9);}finally{Array.prototype[Symbol.iterator]=old;}
 check(seen[0]===token&&seen[1]===9&&seen[2]===2&&seen[3]===D&&hits===0&&D.length===0);
 class E extends B {constructor(a=token,...rest){super(a,...rest);}}
 new E(undefined,6);check(seen[0]===token&&seen[1]===6&&seen[2]===2&&seen[3]===E);
 return 'forward:0';
})();
''','forward:0','Synthetic default derived forwarding does not create an observable rest array iterator; explicit rest/spread retains its ordinary path.')

semantic('extends_null_and_new_class_expression','heritage',r'''
var result=(function(){
 class N extends null {}var caught=false;
 check(Object.getPrototypeOf(N)===Function.prototype&&Object.getPrototypeOf(N.prototype)===null);
 try{new N();}catch(e){caught=e instanceof TypeError;}check(caught);
 var x=new class extends null {constructor(v){var o=Object.create(new.target.prototype);o.v=v;return o;}}(7);
 check(x.v===7&&Object.getPrototypeOf(Object.getPrototypeOf(x))===null);return 'null:TypeError|object:7';
})();
''','null:TypeError|object:7','extends null is still derived; default super target is not constructible, while an explicit object return succeeds without super.')

semantic('computed_static_prototype_stops_at_runtime','members',r'''
var result=(function(){
 var trace='';try{class C {static [(trace+='A','ok')](){} static [(trace+='B','prototype')](){} [(trace+='X','late')](){}}}
 catch(e){check(e instanceof TypeError);trace+='T';}return trace;
})();
''','ABT','A computed static prototype key reaches nonconfigurable-property refusal at runtime; later computed keys do not run. Literal static prototype is separately an early error.')

semantic('outer_this_and_newtarget_in_class_evaluation','lexical',r'''
var result=(function(){
 var marker={},seen=0;function B(){}
 function make(){var self=this,target=new.target;class C extends (check(this===self),check(new.target===target),seen++,B) {
   [(check(this===self),check(new.target===target),seen++,'m')](){return this;}}
   return C;}
 var C=make.call(marker),D=new make();check(seen===4&&new C().m() instanceof C&&new D().m() instanceof D);
 return 'outer-context:4';
})();
''','outer-context:4','Heritage and computed-name evaluation do not create a constructor this/NewTarget binding; method bodies later use their own receiver.')

semantic('promise_default_subclass_withresolvers_and_try','promise',r'''
class P extends Promise {}
var c=P.withResolvers(),token={},trace='S';
check(c.promise instanceof P&&c.promise instanceof Promise&&Object.getPrototypeOf(c.promise)===P.prototype);
check(P.try(()=>c.promise)===c.promise);
c.promise.then(function(v){check(v===token);trace+='F';});
queueMicrotask(function(){trace+='Q';});c.resolve(token);trace+='E';
''','SEQF','Inherited withResolvers creates a branded subclass promise; Try returns the identical genuine promise. The earlier queued microtask precedes the fulfillment reaction.',observe='trace')

semantic('promise_explicit_super_executor_order','promise',r'''
var trace='',token={},seenTarget,done=false;
class P extends Promise {constructor(executor){trace+='C';seenTarget=new.target;super(executor);trace+='D';}}
var p=new P(function(resolve){trace+='E';resolve(token);}),first=trace;
check(seenTarget===P&&p instanceof P&&p instanceof Promise);
p.then(function(v){check(v===token);done=true;});
''','CED|true','Native Promise construction invokes its executor synchronously inside super and forwards the derived NewTarget. A later then capability may call the subclass again, so the initial trace is captured before then.',observe="first+'|'+done")

semantic('promise_combinators_inherited_statics','promise',r'''
class P extends Promise {}
var a={},b={},seen=['0','0','0','0','0','0','0'];
var ps=[P.resolve(a),P.reject(b),P.all([a]),P.race([a]),P.allSettled([P.reject(b)]),P.any([P.reject(b),a]),P.any([])];
for(var i=0;i<ps.length;i++)check(ps[i] instanceof P&&ps[i] instanceof Promise);
ps[0].then(v=>{check(v===a);seen[0]='1';});
ps[1].then(undefined,v=>{check(v===b);seen[1]='1';});
ps[2].then(v=>{check(v.length===1&&v[0]===a);seen[2]='1';});
ps[3].then(v=>{check(v===a);seen[3]='1';});
ps[4].then(v=>{check(v.length===1&&v[0].status==='rejected'&&v[0].reason===b);seen[4]='1';});
ps[5].then(v=>{check(v===a);seen[5]='1';});
ps[6].then(undefined,v=>{check(v instanceof AggregateError&&v.errors.length===0);seen[6]='1';});
''','1111111','All seven inherited static operations create genuinely branded subclass instances; every rejection is handled, without asserting a new host audit policy.',observe="seen.join('')")

semantic('promise_species_object_return_without_super','promise',r'''
var trace='',holder={},token={},resolved,receiver;
class P extends Promise {}
class C extends P {constructor(executor){trace+='C';executor(function(v){'use strict';trace+='R';resolved=v;receiver=this;},function(){throw 'unexpected';});return holder;}}
var p=Promise.resolve(token);p.constructor={get [Symbol.species](){trace+='G';return C;}};
var out=p.then(function(v){check(v===token);trace+='H';return token;}),before=trace;
check(out===holder);
''','GC|GCHR|true|true','A species constructor may capture capability callbacks and return an arbitrary object without super; the fulfillment reaction later calls the exact resolve callback.',observe="before+'|'+trace+'|'+(resolved===token)+'|'+(receiver===undefined)")

semantic('class_is_callable_but_rejects_invocation','promise',r'''
var entered=0,tryRejected=false,executorRejected=false;
class Callback {constructor(x=(entered++,1)){entered++;}}
Promise.try(Callback).then(undefined,e=>{check(e instanceof TypeError);tryRejected=true;});
new Promise(Callback).then(undefined,e=>{check(e instanceof TypeError);executorRejected=true;});
''','true|true|0','Class functions satisfy IsCallable, so Promise.try and Promise executors reach Call and reject from the class guard; no constructor default or body executes.',observe="tryRejected+'|'+executorRejected+'|'+entered")

semantic('aggregateerror_native_brand_through_default_super','native',r'''
var result=(function(){
 class E extends AggregateError {}var token={},reason={},e=new E([token],'message',{cause:reason});
 check(e instanceof E&&e instanceof AggregateError&&e instanceof Error&&Object.getPrototypeOf(e)===E.prototype);
 check(e.errors.length===1&&e.errors[0]===token&&e.message==='message'&&e.cause===reason);
 check(Object.prototype.toString.call(e)==='[object Error]');return 'native-brand';
})();
''','native-brand','The existing explicit NewTarget AggregateError route supplies private Error branding and derived prototype; no broad native/WebIDL subclass claim is made.')

early=[
 ('duplicate_constructor','class C {constructor(){} constructor(){}}'),
 ('getter_constructor','class C {get constructor(){}}'),
 ('setter_constructor','class C {set constructor(v){}}'),
 ('literal_static_prototype','class C {static prototype(){}}'),
 ('quoted_static_prototype','class C {static "prototype"(){}}'),
 ('base_super_call','class C {constructor(){super();}}'),
 ('method_super_call','class C extends Object {m(){super();}}'),
 ('static_super_call','class C extends Object {static m(){super();}}'),
 ('nested_function_super_call','class C extends Object {constructor(){function f(){super();}}}'),
 ('duplicate_constructor_parameters','class C {constructor(a,a){}}'),
 ('duplicate_method_parameters','class C {m(a,a){}}'),
 ('getter_arity','class C {get x(a){}}'),
 ('setter_no_argument','class C {set x(){}}'),
 ('setter_two_arguments','class C {set x(a,b){}}'),
 ('setter_rest_argument','class C {set x(...a){}}'),
 ('strict_with','class C {m(){with({}){}}}'),
 ('strict_delete_identifier','class C {m(){var x;delete x;}}'),
 ('strict_class_binding','class eval {}'),
 ('controlled_statement_class','if(true) class C {}'),
 ('labelled_class','label: class C {}'),
 ('lexical_collision','let C;class C {}'),
 ('var_collision','var C;class C {}'),
 ('parameter_collision','function f(C){class C {}}'),
 ('catch_collision','try{}catch(C){class C {}}'),
 ('switch_collision','switch(0){case 0:class C {}break;default:class C {}}'),
 ('anonymous_declaration','class {}'),
]
for name,source in early:
 cases.append({'id':name,'family':'early-errors','kind':'early-error','setup':'var touched=0;\n',
               'source':'touched=1;\n'+source+'\n','expected_error':'SyntaxError',
               'observation':'touched','expected':{'type':'number','value':0},
               'derivation':'Whole-source early error in admitted grammar; a prior setup realm provides the untouched sentinel. No eval or Function source compiler is used.'})
deferred=[
 ('public_field','class C {x=1;}'),('static_field','class C {static x=1;}'),
 ('private_field','class C {#x;}'),('private_method','class C {#m(){}}'),
 ('static_block','class C {static {}}'),('generator_method','class C {*m(){}}'),
 ('async_method','class C {async m(){}}'),('async_generator_method','class C {async *m(){}}'),
 ('super_named_property','class C {m(){return super.x;}}'),
 ('super_computed_assignment','class C {m(k,v){super[k]=v;}}'),
]
for name,source in deferred:
 cases.append({'id':name,'family':'explicitly-deferred','kind':'unsupported','source':source+'\n',
               'expected_error':'Unsupported','observation':None,
               'derivation':'Valid ECMAScript form outside the selected class slice. This is an explicit implementation boundary, not a SyntaxError or a complete deferred-grammar parser claim.'})

for row in cases:
 row['modes']=['sloppy','strict']
 row['source_file']=put(D/'literals'/(row['id']+'.js'),row['source'].encode())
 if row.get('observation') is not None:
  row['observation_file']=put(D/'readbacks'/(row['id']+'.js'),(row['observation']+'\n').encode())
 if row.get('setup'):
  row['setup_file']=put(D/'setups'/(row['id']+'.js'),row['setup'].encode())
assert len({x['id'] for x in cases})==len(cases)
payload=obj(D/'cases.json',cases)
counts={k:sum(x['kind']==k for x in cases) for k in ['semantic','early-error','unsupported']}
bindings=[]
for rel in ['src/script/try_semantics_tests.rs','src/script/with_resolvers_semantics_tests.rs',
            'src/script/promise_semantic_tests.rs','src/script/aggregate_error_semantic_tests.rs']:
 b=subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
 assert b==(W/rel).read_bytes()
 bindings.append({'relative_path':rel,'published_base':BASE,'snapshot':put(D/'parent'/rel,b)})
specs=obj(D/'spec-basis.json',{
 'checked_date':'2026-10-15','source':'Current official ECMAScript2027 pages read directly; source-derived cases, no engine execution.',
 'references':readiness['primary_spec'],
 'additional_discriminators':['Class Call guard before defaults/body, but after call-site arguments.',
 'Class name TDZ during heritage and computed keys; mutable outer declaration differs from immutable inner binding.',
 'Derived object return does not require super. Repeated super constructs first, then duplicate binding fails.',
 'super captures active constructor parent before explicit arguments and checks constructibility afterwards.',
 'Default derived forwarding does not perform Array iterator lookup. Class methods remain strict and nonconstructible.'],
 'wording':'Expectations are authored derivations, not copied upstream test bodies or observed results.'})
roster=obj(D/'roster.json',{
 'cases':[{k:r[k] for k in ['id','family','kind','modes']} for r in cases],
 'counts':counts,'source_literals':len(cases),'planned_mode_attempts':2*len(cases),
 'qualification':'These are literal rows, not selected Rust test-group counts. Root will select helper/module interfaces and group composition later. Early-error setup/readbacks and semantic post-checkpoint observations are separate operations, not extra source modes.'})
contract=obj(D/'contract.json',{
 'status':'frozen independent public literal/expected-outcome roster; no executable Rust payload',
 'runtime_read_base':BASE,'publication_refresh':'pending profile publication; additively bind before integration',
 'readiness':bind(R),'selection':bind(F/'root/selection-provisional.json'),
 'included':selection['included'],'excluded':selection['explicitly_unsupported'],
 'observations':'Each row uses a fresh Runtime per sloppy/strict mode. Semantic readbacks occur after the public execute checkpoint, matching held published helper conventions. Early errors are tested as separate source submissions after setup; Unsupported probes do not assert later readbacks.',
 'parent_reachability':'Current published class grammar is Unsupported. Semantic class-containing bodies therefore do not establish their intended successful traces on the parent. Early-error and deferred categories are retained separately; no pass count is predicted.',
 'scope':'No producer source reads, live edits, project execution/imports, numeric fees or Rust test authoring. Runtime-only profile policies/baselines remain unchanged; future replay outcomes may legitimately change and must be recorded honestly.',
 'followups':['Root chooses execution/helper/module interfaces before conversion.',
 'Independent semantic peer may identify a literal correction; preserve this frozen hold if so.',
 'Resource/terminal controls require selected ownership/observer boundaries and will be authored separately without resetting counters.'],
 'cases':payload,'roster':roster,'spec_basis':specs,'published_conventions':bindings})
seal=obj(D/'source-ready.json',{'status':'ready for independent literal review and root contract selection',
 'contract':contract,'cases':payload,'roster':roster,'spec_basis':specs,
 'author':bind(D/'author-contract.py'),'counts':counts,'source_literals':len(cases),
 'planned_mode_attempts':2*len(cases),'execution_claim':False,'rust_payload_authored':False})
print(json.dumps(seal))
