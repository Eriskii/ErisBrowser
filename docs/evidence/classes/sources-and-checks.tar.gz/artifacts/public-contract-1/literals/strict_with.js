touched=1;
class C {m(){with({}){}}}
