touched=1;
switch(0){case 0:class C {}break;default:class C {}}
