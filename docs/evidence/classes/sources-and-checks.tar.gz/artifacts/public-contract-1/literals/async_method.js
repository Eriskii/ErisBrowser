class C {async m(){}}
