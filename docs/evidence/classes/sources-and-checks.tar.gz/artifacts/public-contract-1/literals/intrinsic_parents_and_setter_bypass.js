function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var O=Object,F=Function,hits=0;
 O.defineProperty(O.prototype,'classMember',{set:function(){hits++;},configurable:true});
 O.defineProperty(F.prototype,'classStatic',{set:function(){hits++;},configurable:true});
 Object=function(){throw 1;};Function=function(){throw 2;};
 var C=class {classMember(){return 1;} static classStatic(){return 2;}};
 check(O.getPrototypeOf(C)===F.prototype&&O.getPrototypeOf(C.prototype)===O.prototype);
 check(new C().classMember()===1&&C.classStatic()===2&&hits===0);
 Object=O;Function=F;delete O.prototype.classMember;delete F.prototype.classStatic;return 'intrinsics:0';
})();
