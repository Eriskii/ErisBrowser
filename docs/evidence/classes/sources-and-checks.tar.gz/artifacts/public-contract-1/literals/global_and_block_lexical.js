function check(v){if(!v)throw new Error('class oracle');}
class ClassScopeWitness {}
var result=(function(){
  check(window.ClassScopeWitness===undefined);
  var first=ClassScopeWitness,read;
  { class ClassScopeWitness {static value(){return 4;}} read=()=>ClassScopeWitness; }
  check(read()!==first&&read().value()===4&&ClassScopeWitness===first);
  ClassScopeWitness=7;check(ClassScopeWitness===7);return 'lexical';
})();
