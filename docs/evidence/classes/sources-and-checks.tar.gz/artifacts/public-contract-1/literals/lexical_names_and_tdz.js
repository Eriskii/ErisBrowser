function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
  var t='';
  try { typeof Later; class Later {} } catch(e){check(e instanceof ReferenceError);t+='T';}
  try { class Self extends Self {} } catch(e){check(e instanceof ReferenceError);t+='H';}
  try { class Key { [Key](){} } } catch(e){check(e instanceof ReferenceError);t+='K';}
  class Outer { static identity(){return Outer;} static write(){Outer=7;} }
  var saved=Outer;Outer=9;check(saved.identity()===saved&&Outer===9);
  try { saved.write(); } catch(e){check(e instanceof TypeError);t+='I';}
  var Expr=class Inner {static identity(){return Inner;}};
  check(Expr.identity()===Expr&&typeof Inner==='undefined');
  var Inferred=class {};var Shadow=class {static name(){return 3;} static length(){return 4;}};
  check(Inferred.name==='Inferred'&&Shadow.name()===3&&Shadow.length()===4);
  return t;
})();
