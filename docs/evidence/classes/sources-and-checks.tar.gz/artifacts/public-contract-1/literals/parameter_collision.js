touched=1;
function f(C){class C {}}
