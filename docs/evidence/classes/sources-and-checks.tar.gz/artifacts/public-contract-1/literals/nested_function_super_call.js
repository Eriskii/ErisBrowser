touched=1;
class C extends Object {constructor(){function f(){super();}}}
