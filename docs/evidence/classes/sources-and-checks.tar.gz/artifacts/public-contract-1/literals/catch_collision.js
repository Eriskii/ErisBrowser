touched=1;
try{}catch(C){class C {}}
