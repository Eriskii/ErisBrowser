class C {static {}}
