touched=1;
let C;class C {}
