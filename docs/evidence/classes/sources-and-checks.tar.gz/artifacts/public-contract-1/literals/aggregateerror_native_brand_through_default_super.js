function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 class E extends AggregateError {}var token={},reason={},e=new E([token],'message',{cause:reason});
 check(e instanceof E&&e instanceof AggregateError&&e instanceof Error&&Object.getPrototypeOf(e)===E.prototype);
 check(e.errors.length===1&&e.errors[0]===token&&e.message==='message'&&e.cause===reason);
 check(Object.prototype.toString.call(e)==='[object Error]');return 'native-brand';
})();
