function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var marker={},seen=0;function B(){}
 function make(){var self=this,target=new.target;class C extends (check(this===self),check(new.target===target),seen++,B) {
   [(check(this===self),check(new.target===target),seen++,'m')](){return this;}}
   return C;}
 var C=make.call(marker),D=new make();check(seen===4&&new C().m() instanceof C&&new D().m() instanceof D);
 return 'outer-context:4';
})();
