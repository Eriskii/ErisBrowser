touched=1;
class C {static "prototype"(){}}
