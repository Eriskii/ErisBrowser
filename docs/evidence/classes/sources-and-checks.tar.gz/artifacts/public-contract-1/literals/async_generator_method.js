class C {async *m(){}}
