function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='',count=0,token={};function B(){count++;trace+='B';this.n=count;}
 class D extends B {constructor(){super();try{super();}catch(e){check(e instanceof ReferenceError);trace+='R';}check(this.n===1);}}
 new D();check(count===2);
 function ThrowOnce(){trace+='X';if(count++===2)throw token;this.ok=true;}
 class Retry extends ThrowOnce {constructor(){try{super();}catch(e){check(e===token);trace+='C';}super();check(this.ok);}}
 new Retry();return trace;
})();
