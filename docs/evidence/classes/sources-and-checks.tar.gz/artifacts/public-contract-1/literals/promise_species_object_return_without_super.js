function check(v){if(!v)throw new Error('class oracle');}
var trace='',holder={},token={},resolved,receiver;
class P extends Promise {}
class C extends P {constructor(executor){trace+='C';executor(function(v){'use strict';trace+='R';resolved=v;receiver=this;},function(){throw 'unexpected';});return holder;}}
var p=Promise.resolve(token);p.constructor={get [Symbol.species](){trace+='G';return C;}};
var out=p.then(function(v){check(v===token);trace+='H';return token;}),before=trace;
check(out===holder);
