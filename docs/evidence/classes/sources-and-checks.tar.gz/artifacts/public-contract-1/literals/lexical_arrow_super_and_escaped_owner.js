function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='',saved,later,token={};function B(v){trace+='B'+v;this.v=v;}
 class D extends B {constructor(){var get=()=>this;try{get();}catch(e){check(e instanceof ReferenceError);trace+='R';}
   var call=()=>super(4);call();check(get()===this);saved=()=>[this,new.target];}}
 var d=new D(),pair=saved.call({});check(pair[0]===d&&pair[1]===D);
 class Late extends B {constructor(){later=()=>super(8);return token;}}
 check(new Late()===token);var x=later();check(x.v===8&&Object.getPrototypeOf(x)===Late.prototype);
 try{later();}catch(e){check(e instanceof ReferenceError);trace+='R';}return trace;
})();
