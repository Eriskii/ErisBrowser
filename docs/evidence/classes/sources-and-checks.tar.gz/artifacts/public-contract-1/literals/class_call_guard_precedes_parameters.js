function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='';class C {constructor(x=(trace+='D',7)){trace+='B';this.x=x;}}
 function rejected(f){try{f();throw 'miss';}catch(e){check(e instanceof TypeError);trace+='T';}}
 rejected(()=>C((trace+='A',undefined)));rejected(()=>C.call(null));
 rejected(()=>C.apply(null,[]));rejected(()=>C.bind(null)());
 var x=new C();check(x.x===7&&typeof C==='function');return trace;
})();
