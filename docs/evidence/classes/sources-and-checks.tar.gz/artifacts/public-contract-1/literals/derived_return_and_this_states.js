function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='',token={};function B(){trace+='B';this.ok=true;}
 function error(C,T){try{new C();throw 'miss';}catch(e){check(e instanceof T);trace+=T===ReferenceError?'R':'T';}}
 error(class extends B {constructor(){this.x=1;}},ReferenceError);
 error(class extends B {constructor(a=this){}},ReferenceError);
 error(class extends B {constructor(){}},ReferenceError);
 error(class extends B {constructor(){return undefined;}},ReferenceError);
 error(class extends B {constructor(){return 1;}},TypeError);
 error(class extends B {constructor(){super();return null;}},TypeError);
 var C=class extends B {constructor(){return token;}};check(new C()===token);
 var D=class extends B {constructor(){super();return undefined;}};check(new D().ok);
 return trace;
})();
