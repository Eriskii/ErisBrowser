function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
  var O=Object,H=O.prototype.hasOwnProperty;
  class Base {constructor(a,b=2,...rest){} m(a,b){} get x(){return 1;} set x(v){} static s(a){} }
  class Default extends Base {}
  var p=O.getOwnPropertyDescriptor(Base,'prototype'),n=O.getOwnPropertyDescriptor(Base,'name'),l=O.getOwnPropertyDescriptor(Base,'length');
  var c=O.getOwnPropertyDescriptor(Base.prototype,'constructor'),m=O.getOwnPropertyDescriptor(Base.prototype,'m'),x=O.getOwnPropertyDescriptor(Base.prototype,'x');
  check(p.value===Base.prototype&&!p.writable&&!p.enumerable&&!p.configurable);
  check(n.value==='Base'&&!n.writable&&!n.enumerable&&n.configurable);
  check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable&&Default.length===0);
  check(c.value===Base&&c.writable&&!c.enumerable&&c.configurable);
  check(m.writable&&!m.enumerable&&m.configurable&&m.value.length===2&&!H.call(m.value,'prototype'));
  check(!x.enumerable&&x.configurable&&x.get.name==='get x'&&x.set.name==='set x');
  check(O.getPrototypeOf(Base)===Function.prototype&&O.getPrototypeOf(Base.prototype)===O.prototype);
  check(O.getPrototypeOf(Default)===Base&&O.getPrototypeOf(Default.prototype)===Base.prototype);
  var errors=0;try{new m.value();}catch(e){check(e instanceof TypeError);errors++;}
  try{new x.get();}catch(e){check(e instanceof TypeError);errors++;}
  check(errors===2);return 'metadata:2';
})();
