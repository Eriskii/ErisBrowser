class C {m(k,v){super[k]=v;}}
