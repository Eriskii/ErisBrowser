function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='',token={};function B(v){this.v=v;}
 var Bound=B.bind(null);Object.defineProperty(Bound,'prototype',{get:function(){trace+='P';return B.prototype;}});
 function heritage(){trace+='H';return Bound;}
 class C extends heritage(){[(trace+='K','m')](){} }
 var x=new C(7);check(x.v===7&&Object.getPrototypeOf(C)===Bound&&Object.getPrototypeOf(C.prototype)===B.prototype);
 try{class Bad extends (trace+='N',{}) {[(trace+='X','x')](){}}}catch(e){check(e instanceof TypeError);trace+='T';}
 var Throwing=B.bind(null);Object.defineProperty(Throwing,'prototype',{get:function(){trace+='G';throw token;}});
 try{class Bad extends Throwing {[(trace+='Y','y')](){}}}catch(e){check(e===token);trace+='I';}
 B.prototype=3;try{class Bad extends B {[(trace+='Z','z')](){}}}catch(e){check(e instanceof TypeError);trace+='V';}
 return trace;
})();
