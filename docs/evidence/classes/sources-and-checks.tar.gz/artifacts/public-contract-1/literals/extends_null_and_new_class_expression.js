function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 class N extends null {}var caught=false;
 check(Object.getPrototypeOf(N)===Function.prototype&&Object.getPrototypeOf(N.prototype)===null);
 try{new N();}catch(e){caught=e instanceof TypeError;}check(caught);
 var x=new class extends null {constructor(v){var o=Object.create(new.target.prototype);o.v=v;return o;}}(7);
 check(x.v===7&&Object.getPrototypeOf(Object.getPrototypeOf(x))===null);return 'null:TypeError|object:7';
})();
