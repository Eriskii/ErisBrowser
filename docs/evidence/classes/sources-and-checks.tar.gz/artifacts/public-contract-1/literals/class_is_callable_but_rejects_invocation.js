function check(v){if(!v)throw new Error('class oracle');}
var entered=0,tryRejected=false,executorRejected=false;
class Callback {constructor(x=(entered++,1)){entered++;}}
Promise.try(Callback).then(undefined,e=>{check(e instanceof TypeError);tryRejected=true;});
new Promise(Callback).then(undefined,e=>{check(e instanceof TypeError);executorRejected=true;});
