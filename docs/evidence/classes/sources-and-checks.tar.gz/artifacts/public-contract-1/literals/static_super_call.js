touched=1;
class C extends Object {static m(){super();}}
