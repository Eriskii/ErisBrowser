function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var token={},seen,old=Array.prototype[Symbol.iterator],hits=0;
 function B(a,b){seen=[a,b,arguments.length,new.target];}
 class D extends B {}var d;
 Array.prototype[Symbol.iterator]=function(){hits++;throw token;};
 try{d=new D(token,9);}finally{Array.prototype[Symbol.iterator]=old;}
 check(seen[0]===token&&seen[1]===9&&seen[2]===2&&seen[3]===D&&hits===0&&D.length===0);
 class E extends B {constructor(a=token,...rest){super(a,...rest);}}
 new E(undefined,6);check(seen[0]===token&&seen[1]===6&&seen[2]===2&&seen[3]===E);
 return 'forward:0';
})();
