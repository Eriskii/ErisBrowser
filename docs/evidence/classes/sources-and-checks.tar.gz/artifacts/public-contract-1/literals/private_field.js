class C {#x;}
