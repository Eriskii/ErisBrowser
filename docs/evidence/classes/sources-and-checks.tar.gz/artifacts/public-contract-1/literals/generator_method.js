class C {*m(){}}
