touched=1;
class C {set x(){}}
