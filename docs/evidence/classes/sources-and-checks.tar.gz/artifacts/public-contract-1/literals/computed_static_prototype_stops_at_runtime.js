function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='';try{class C {static [(trace+='A','ok')](){} static [(trace+='B','prototype')](){} [(trace+='X','late')](){}}}
 catch(e){check(e instanceof TypeError);trace+='T';}return trace;
})();
