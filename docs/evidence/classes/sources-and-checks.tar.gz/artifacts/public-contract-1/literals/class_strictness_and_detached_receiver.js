function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 class C {m(){return this;} nested(){return function(){return this;};} write(){ClassMissingWitness=1;}}
 var x=new C(),m=x.m,n=x.nested();check(m()===undefined&&n()===undefined);
 var strict=false;try{x.write();}catch(e){strict=e instanceof ReferenceError;}
 check(strict&&typeof ClassMissingWitness==='undefined');return 'strict';
})();
