touched=1;
class C {m(){var x;delete x;}}
