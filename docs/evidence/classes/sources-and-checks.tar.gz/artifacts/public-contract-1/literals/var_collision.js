touched=1;
var C;class C {}
