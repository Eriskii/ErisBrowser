touched=1;
class C {constructor(a,a){}}
