function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='',token={},key={toString:function(){trace+='C';return 'm';}};
 function mark(s,k){trace+=s;return k;}
 class C { [mark('A',key)](){} static [mark('B','s')](){} [mark('D','n')](){} }
 check(trace==='ACBD');
 try { class Fail {[(trace+='E',key)](){} [(trace+='F',function(){throw token;}())](){} [(trace+='X','late')](){} } }
 catch(e){check(e===token);trace+='T';}
 check(typeof C.prototype.m==='function'&&typeof C.s==='function');return trace;
})();
