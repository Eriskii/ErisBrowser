class C {m(){return super.x;}}
