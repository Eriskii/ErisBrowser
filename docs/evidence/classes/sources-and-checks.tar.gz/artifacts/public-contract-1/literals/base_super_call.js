touched=1;
class C {constructor(){super();}}
