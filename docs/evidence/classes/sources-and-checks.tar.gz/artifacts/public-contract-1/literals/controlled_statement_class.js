touched=1;
if(true) class C {}
