touched=1;
label: class C {}
