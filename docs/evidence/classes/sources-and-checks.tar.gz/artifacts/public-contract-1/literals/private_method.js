class C {#m(){}}
