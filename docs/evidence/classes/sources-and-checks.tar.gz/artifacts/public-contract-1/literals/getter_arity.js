touched=1;
class C {get x(a){}}
