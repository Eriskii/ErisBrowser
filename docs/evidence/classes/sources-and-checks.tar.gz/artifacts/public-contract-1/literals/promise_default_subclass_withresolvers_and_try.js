function check(v){if(!v)throw new Error('class oracle');}
class P extends Promise {}
var c=P.withResolvers(),token={},trace='S';
check(c.promise instanceof P&&c.promise instanceof Promise&&Object.getPrototypeOf(c.promise)===P.prototype);
check(P.try(()=>c.promise)===c.promise);
c.promise.then(function(v){check(v===token);trace+='F';});
queueMicrotask(function(){trace+='Q';});c.resolve(token);trace+='E';
