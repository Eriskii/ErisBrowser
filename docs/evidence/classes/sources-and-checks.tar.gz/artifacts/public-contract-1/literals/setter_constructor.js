touched=1;
class C {set constructor(v){}}
