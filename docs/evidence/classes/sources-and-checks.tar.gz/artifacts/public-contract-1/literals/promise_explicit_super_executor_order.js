function check(v){if(!v)throw new Error('class oracle');}
var trace='',token={},seenTarget,done=false;
class P extends Promise {constructor(executor){trace+='C';seenTarget=new.target;super(executor);trace+='D';}}
var p=new P(function(resolve){trace+='E';resolve(token);}),first=trace;
check(seenTarget===P&&p instanceof P&&p instanceof Promise);
p.then(function(v){check(v===token);done=true;});
