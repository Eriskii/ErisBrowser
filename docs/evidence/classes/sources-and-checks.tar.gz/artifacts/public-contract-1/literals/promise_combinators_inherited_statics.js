function check(v){if(!v)throw new Error('class oracle');}
class P extends Promise {}
var a={},b={},seen=['0','0','0','0','0','0','0'];
var ps=[P.resolve(a),P.reject(b),P.all([a]),P.race([a]),P.allSettled([P.reject(b)]),P.any([P.reject(b),a]),P.any([])];
for(var i=0;i<ps.length;i++)check(ps[i] instanceof P&&ps[i] instanceof Promise);
ps[0].then(v=>{check(v===a);seen[0]='1';});
ps[1].then(undefined,v=>{check(v===b);seen[1]='1';});
ps[2].then(v=>{check(v.length===1&&v[0]===a);seen[2]='1';});
ps[3].then(v=>{check(v===a);seen[3]='1';});
ps[4].then(v=>{check(v.length===1&&v[0].status==='rejected'&&v[0].reason===b);seen[4]='1';});
ps[5].then(v=>{check(v===a);seen[5]='1';});
ps[6].then(undefined,v=>{check(v instanceof AggregateError&&v.errors.length===0);seen[6]='1';});
