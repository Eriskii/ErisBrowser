function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var trace='';function A(v){trace+='A';this.v=v;}function B(v){trace+='B';this.v=v;}
 class D extends A {constructor(){super((trace+='X',Object.setPrototypeOf(D,A),7));}}
 Object.setPrototypeOf(D,B);var a=new D(),b=new D();
 check(a.v===7&&b.v===7&&Object.getPrototypeOf(a)===D.prototype&&Object.getPrototypeOf(D.prototype)===A.prototype);
 Object.setPrototypeOf(D,{});try{new D();}catch(e){check(e instanceof TypeError);trace+='T';}
 return trace;
})();
