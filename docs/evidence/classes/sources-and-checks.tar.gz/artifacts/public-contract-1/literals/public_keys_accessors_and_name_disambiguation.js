function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var sym=Symbol('tag'),writes=0;
 class C { ; static(){return 's';} get(){return 'g';} set(){return 't';}
   ['constructor'](){return 'ordinary';} [sym](){return this;} 'x-y'(){return 2;} 7(){return 7;}
   get pair(){return this.v;} set pair(v){writes++;this.v=v;}
   m(){return 1;} m(){return 2;} static constructor(){return 3;}
 }
 var x=new C();x.pair=9;var d=Object.getOwnPropertyDescriptor(C.prototype,'pair');
 check(x.static()==='s'&&x.get()==='g'&&x.set()==='t'&&x.constructor()==='ordinary');
 check(x[sym]()===x&&C.prototype[sym].name==='[tag]'&&x['x-y']()===2&&x[7]()===7);
 check(x.pair===9&&writes===1&&typeof d.get==='function'&&typeof d.set==='function');
 check(x.m()===2&&C.constructor()===3&&Object.keys(C.prototype).length===0);
 return 'members';
})();
