function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var token={},seen;class B {constructor(v){seen=new.target;this.v=v;return v;}}
 var a=new B(3);check(a.v===3&&seen===B);check(new B(token)===token);
 function N(){}var proto={};N.prototype=proto;
 var b=Reflect.construct(B,[4],N);check(seen===N&&Object.getPrototypeOf(b)===proto&&b.v===4);
 var Bound=B.bind({bad:true},5),c=new Bound();check(seen===B&&Object.getPrototypeOf(c)===B.prototype&&c.v===5);
 return 'base-and-newtarget';
})();
