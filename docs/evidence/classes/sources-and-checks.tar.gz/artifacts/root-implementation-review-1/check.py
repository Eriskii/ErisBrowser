"""Independent inert checks; reads Git blobs and bytes, never imports project code."""
import hashlib
import json
import difflib
from pathlib import Path
import re
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'
ROOT = F / 'root-implementation-1'
RUNTIME = F / 'runtime-implementation-1'

def binding(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def old(path):
    return subprocess.check_output(['git', 'show', BASE + ':' + path], cwd=F / 'worktree')

def apply(source, chunks):
    for chunk in chunks:
        before, after = chunk['before'].encode(), chunk['after'].encode()
        count = chunk.get('occurrences', 1)
        assert source.count(before) == count, (chunk['path'], 'forward', source.count(before), count)
        source = source.replace(before, after)
    return source

def inverse(source, chunks):
    for chunk in reversed(chunks):
        before, after = chunk['before'].encode(), chunk['after'].encode()
        count = chunk.get('occurrences', 1)
        assert source.count(after) == count, (chunk['path'], 'inverse', source.count(after), count)
        source = source.replace(after, before)
    return source

def check_binding(row):
    assert binding(row['path']) == row, row['path']

root_chunks = json.loads((ROOT / 'chunks.json').read_text())
runtime_chunks = json.loads((RUNTIME / 'chunks.json').read_text())
root_manifest = json.loads((ROOT / 'source-ready.json').read_text())
runtime_manifest = json.loads((RUNTIME / 'source-ready.json').read_text())
assert len(root_chunks) == root_manifest['chunks'] == 21
assert len(runtime_chunks) == 18
root_results = []
for item in root_manifest['files']:
    path = item['path']
    before = old(path)
    raw = (ROOT / 'raw' / path).read_bytes()
    chunks = [c for c in root_chunks if c['path'] == path]
    assert apply(before, chunks) == raw
    assert inverse(raw, chunks) == before
    assert len(raw) == item['bytes'] and hashlib.sha256(raw).hexdigest() == item['sha256']
    root_results.append({'path': path, 'chunks': len(chunks), 'parent_sha256': hashlib.sha256(before).hexdigest(), 'raw': binding(ROOT / 'raw' / path), 'exact_forward_and_inverse': True})

runtime_results = []
for item in runtime_manifest['files']:
    path = item['relative']
    check_binding(item['raw'])
    check_binding(item['diff'])
    raw = (RUNTIME / 'raw' / path).read_bytes()
    before_for_diff = b'' if item['new'] else old(path)
    diff = ''.join(difflib.unified_diff(before_for_diff.decode().splitlines(True), raw.decode().splitlines(True), fromfile='a/' + path, tofile='b/' + path))
    assert diff.encode() == Path(item['diff']['path']).read_bytes()
    if item['new']:
        assert raw == (RUNTIME / 'new' / path).read_bytes() if (RUNTIME / 'new' / path).exists() else True
    else:
        check_binding(item['before'])
        before = old(path)
        assert before == (RUNTIME / 'before' / path).read_bytes()
        chunks = [c for c in runtime_chunks if c['path'] == path]
        assert apply(before, chunks) == raw
        assert inverse(raw, chunks) == before
        original_literals = re.findall(rb'r(#+)"(.*?)"\1', before, re.S)
        assert original_literals == re.findall(rb'r(#+)"(.*?)"\1', raw, re.S)
    runtime_results.append({'path': path, 'new': item['new'], 'raw': item['raw'], 'published_parent_join_and_inverse': None if item['new'] else True})
for row in runtime_manifest['inputs'] + runtime_manifest['authoring']:
    check_binding(row)
for key in ('chunks', 'accounting_addendum', 'integration_check', 'source_checks'):
    check_binding(runtime_manifest[key])

composition = []
for path in sorted({c['path'] for c in root_chunks + runtime_chunks}):
    before = old(path)
    root = [c for c in root_chunks if c['path'] == path]
    runtime = [c for c in runtime_chunks if c['path'] == path]
    first = apply(apply(before, root), runtime)
    second = apply(apply(before, runtime), root)
    assert first == second
    assert inverse(inverse(first, runtime), root) == before
    composition.append({'path': path, 'bytes': len(first), 'sha256': hashlib.sha256(first).hexdigest(), 'both_orders_equal': True, 'exact_combined_inverse': True})

root_script = (ROOT / 'raw/src/script.rs').read_text()
assert root_script.count('active_constructor: None,') == 3
assert root_script.count('+ 2 * ENVIRONMENT_CLASS_BYTES') == 2
assert '+ ENVIRONMENT_CLASS_BYTES)?;' in root_script
assert 'if !matches!(self.environments[cursor].this_binding, ThisBinding::Lexical)' in root_script
assert 'return self.class_this_value(env);' in root_script
root_machine = (ROOT / 'raw/src/script/machine.rs').read_text()
logical_return = root_machine.index('return Ok(Some(Output::Value(old.unwrap())));')
name_hint = root_machine.index('let hint = if (op == "=" || logical)')
assert logical_return < name_hint
assert 'if let Reference::CodeName' in root_machine[name_hint:name_hint+600]
assert root_machine.count('if unit.anonymous(*expression)') == old('src/script/machine.rs').decode().count('if unit.anonymous(*expression)')
assert 'unit.anonymous(*right)' in root_machine

out = {'status': 'clear: inert independent byte/Git checks passed', 'base': BASE,
       'root_hold': binding(ROOT / 'source-ready.json'), 'runtime_hold': binding(RUNTIME / 'source-ready.json'),
       'root_files': root_results, 'runtime_files': runtime_results, 'composition': composition,
       'scope': 'No project code imported or executed, no compiler, tests, live-source edits or candidate outcome inspection.'}
correction_path = F / 'root/compiler-correction-1.json'
correction = json.loads(correction_path.read_text())
construction = (RUNTIME / 'raw/src/script/construction.rs').read_bytes()
old_visibility = b'    fn constructed_prototype(&mut self, object: Value, prototype: Value) -> Value {'
new_visibility = b'    pub(super) fn constructed_prototype(&mut self, object: Value, prototype: Value) -> Value {'
assert construction.count(old_visibility) == 1
corrected = construction.replace(old_visibility, new_visibility)
assert hashlib.sha256(construction).hexdigest() == correction['before_sha256']
assert hashlib.sha256(corrected).hexdigest() == correction['after_sha256']
assert corrected.replace(new_visibility, old_visibility) == construction
out['runtime_visibility_correction'] = {'receipt': binding(correction_path), 'exact_one_visibility_insertion': True, 'original_hold_is_not_standalone_buildable': True}
(F / 'root-implementation-review-1/checks.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({'root_files': len(root_results), 'runtime_files': len(runtime_results), 'composed_paths': len(composition), 'status': out['status']}))
