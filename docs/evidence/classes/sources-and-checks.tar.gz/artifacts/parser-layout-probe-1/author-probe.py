from pathlib import Path
import json,re,hashlib,subprocess,difflib
N=Path('/tmp/eris-class-runtime-plan-1');O=N/'parser-layout-probe-1';S=N/'parser-shapes-1';R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');B='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(name,x):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
def read(version,group):
 text=(S/version/(group+'.rs')).read_text();return text.split('\n\n',1)[1]
def decl_names(text):return re.findall(r'(?m)^(?:pub(?:\([^\n]*?\))?\s+)?(?:struct|enum)\s+(\w+)',text)
def indent(text):return '\n'.join('    '+line if line else '' for line in text.splitlines())+'\n'
row_specs={
'code':[(n,n) for n in ['ExprId','StmtId','FunctionId','Parameter','Function','Unit','FunctionRef','Expr','PropertyName','ObjectEntry','Stmt','ForBinding','CatchClause']]+[('Records<Expr>','Records<Expr>'),('Records<Function>','Records<Function>')],
'parser':[('PropertyName','PropertyName'),('ActiveLabel','ActiveLabel'),('Parser',"Parser<'static>")],
'driver':[(n,n) for n in ['Output','Body','Kind','Transition']],
'expressions':[(n,n) for n in ['Frame','Binary','Postfix','NewState','Cover','Array','Object']],
'functions':[(n,n) for n in ['Frame','State','Context']],
'statements':[(n,n) for n in ['Frame','Switch','BodyFrame','BodyState','Before']],
'classes':[(n,n) for n in ['Frame','State','Header','Context']],
}
links=[]
def fragment(version,group):
 text=read(version,group);links.append({'version':version,'group':group,'held':bind(S/version/(group+'.rs')),'declaration_payload_sha256':sha(text.encode())});return text

def rows_fn(prefix,specs,children=()):
 body='pub(super) fn rows() -> Vec<LayoutRow> {\n    let mut rows = vec![\n'
 for label,ty in specs:body+='        row::<'+ty+'>('+json.dumps(prefix+'::'+label)+'),\n'
 body+='    ];\n'
 for child in children:body+='    rows.extend('+child+'::rows());\n'
 body+='    rows\n}\n';return body

def emit_fn(actions,children=()):
 text='pub(super) fn observe_allocations(version: &str) {\n'
 for ty,label,requests in actions:text+='    observe_capacity::<'+ty+'>(version, '+json.dumps(label)+', &'+str(requests)+');\n'
 for child in children:text+='    '+child+'::observe_allocations(version);\n'
 return text+'}\n'

def module(version,group,children=None):
 data='use super::*;\n\n'+fragment(version,group)+'\n'
 specs=list(row_specs[group]);children=children or []
 if group=='code':
  data+=fragment(version,'records')+'\n'
  if version=='proposed':specs += [(n,n) for n in ['ClassId','ClassKind','ClassElementKind','Class','ClassElement']]+[('Records<Class>','Records<Class>')]
 elif group=='driver' and version=='proposed':specs += [('EntryContext','EntryContext')]
 for name,body in children:data+='mod '+name+' {\n'+indent(body)+'}\n\n'
 data+=rows_fn('parser::'+group if group not in ['code','parser'] else group,specs,[name for name,_ in children])+'\n'
 if group=='code':
  actions=[('Expr','code::Expr pages',[128]),('Stmt','code::Stmt pages',[128]),('Function','code::Function pages',[128]),('Vec<Expr>','code::Expr page directory',[4,8])]
  if version=='proposed':actions += [('Class','code::Class pages',[128]),('ClassElement','code::ClassElement list',[1,2,4,8]),('Vec<Class>','code::Class page directory',[4,8])]
  data+=emit_fn(actions)
  data+='pub(super) fn formulas(version: &str) {\n'
  for label,expr in [('unit_rc','size_of::<Unit>() + 2 * size_of::<usize>()'),('expression_page','128 * size_of::<Expr>() + 32'),('statement_page','128 * size_of::<Stmt>() + 32'),('function_page','128 * size_of::<Function>() + 32'),('expression_directory4','4 * size_of::<Vec<Expr>>() + 32')]:data+='    emit_formula(version, '+json.dumps(label)+', '+expr+');\n'
  if version=='proposed':data+='    emit_formula(version, "class_page", 128 * size_of::<Class>() + 32);\n    emit_formula(version, "class_directory4", 4 * size_of::<Vec<Class>>() + 32);\n    emit_formula(version, "class_elements4", 4 * size_of::<ClassElement>() + 32);\n'
  data+='}\n'
 elif group=='driver':
  data+=emit_fn([('Kind','parser::driver::Kind continuation',[4,8,16])])
  data+='pub(super) fn formulas(version: &str) {\n    emit_formula(version, "parser_frames4", 4 * size_of::<Kind>() + 32);\n    emit_formula(version, "parser_frames8", 8 * size_of::<Kind>() + 32);\n    emit_formula(version, "parser_frame_limit", MAX_HEAP / size_of::<Kind>());\n}\n'
 elif group=='parser':
  data+=emit_fn([],['driver'])+'pub(super) fn formulas(version: &str) { driver::formulas(version); }\n'
 return data

def graph(version):
 children=[(g,module(version,g)) for g in ['expressions','functions','statements']]
 if version=='proposed':children.append(('classes',module(version,'classes')))
 driver=module(version,'driver',children)
 grammar=module(version,'parser',[('driver',driver)])
 grammar=grammar.replace('use super::*;\n','use super::*;\nuse code::{CatchClause, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId'+(', ClassId' if version=='proposed' else '')+'};\n',1)
 code=module(version,'code')
 return 'use super::*;\n\nmod code {\n'+indent(code)+'}\n\nmod parser {\n'+indent(grammar)+'}\n\npub(super) fn rows() -> Vec<LayoutRow> { let mut rows=code::rows(); rows.extend(parser::rows()); rows }\npub(super) fn observe_allocations(version: &str) { code::observe_allocations(version); parser::observe_allocations(version); }\npub(super) fn formulas(version: &str) { code::formulas(version); parser::formulas(version); }\n'
header='''//! Inert full class parser/code layout mirrors. No parser or runtime methods run.
#![allow(dead_code, unused_mut, unused_imports)]
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct LayoutRow {
    name: &'static str,
    size: usize,
    align: usize,
}
fn row<T>(name: &'static str) -> LayoutRow {
    LayoutRow { name, size: size_of::<T>(), align: align_of::<T>() }
}
fn observe_capacity<T>(version: &str, name: &str, requests: &[usize]) {
    let mut values: Vec<T> = Vec::new();
    for requested in requests {
        let before = values.capacity();
        values.try_reserve_exact(*requested).unwrap();
        assert!(values.capacity() >= *requested);
        assert_eq!(values.len(), 0);
        eprintln!("CLASS_PARSER_CAPACITY version={version} type={name:?} len=0 requested_additional={requested} before={before} after={}", values.capacity());
    }
}
fn emit_formula(version: &str, name: &str, value: usize) {
    eprintln!("CLASS_PARSER_FORMULA version={version} name={name} value={value}");
}
'''
raw=header+'\nmod before {\n'+indent(graph('before'))+'}\n\nmod proposed {\n'+indent(graph('proposed'))+'}\n\n'
actual=[]
for name in ['ExprId','StmtId','FunctionId','Parameter','Function','Unit','FunctionRef','Expr','PropertyName','ObjectEntry','Stmt','ForBinding','CatchClause']:actual.append(('code::'+name,'code::'+name))
for name in ['PropertyName','ActiveLabel','Parser']:actual.append(('parser::'+name,'super::super::'+name+("<'static>" if name=='Parser' else '')))
for name in ['Output','Body','Kind','Transition']:actual.append(('parser::driver::'+name,'super::'+name))
for group in ['expressions','functions','statements']:
 for name,_ in row_specs[group]:
  if group=='functions' and name=='Context':continue
  actual.append(('parser::'+group+'::'+name,'super::'+group+'::'+name))
raw+='fn actual_rows() -> Vec<LayoutRow> {\n    vec![\n'+''.join('        row::<'+ty+'>('+json.dumps(label)+'),\n' for label,ty in actual)+'    ]\n}\n\n'
raw+='''#[test]
fn class_layout_parser_code_complete_shapes() {
    let before = before::rows();
    let proposed = proposed::rows();
    let actual = actual_rows();
    for live in &actual {
        let held = before.iter().find(|row| row.name == live.name).unwrap();
        assert_eq!(held, live, "complete published mirror differs: {}", live.name);
    }
    for (version, rows) in [("before", &before), ("proposed", &proposed)] {
        let mut seen = std::collections::BTreeSet::new();
        for row in rows {
            assert!(seen.insert(row.name), "duplicate layout row");
            eprintln!("CLASS_PARSER_LAYOUT version={version} type={} size={} align={}", row.name, row.size, row.align);
        }
    }
    eprintln!("CLASS_PARSER_LAYOUT_COUNTS actual={} before={} proposed={}", actual.len(), before.len(), proposed.len());
    before::observe_allocations("before");
    proposed::observe_allocations("proposed");
    before::formulas("before");
    proposed::formulas("proposed");
}
'''
path=O/'raw/src/script/parser/driver/class_layout_probe.rs';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(raw)
# Exact declaration containment checks; this is source comparison, not Rust execution.
for link in links:
 payload=Path(link['held']['path']).read_text().split('\n\n',1)[1]
 assert sha(payload.encode())==link['declaration_payload_sha256']
 # Every normalized declaration block remains whole after indentation only.
 for name in decl_names(payload):
  assert re.search(r'(?m)^\s*(?:pub(?:\([^\n]*?\))?\s+)?(?:struct|enum)\s+'+name+r'\b',raw),name
reg='\n#[cfg(test)]\nmod class_layout_probe;\n';(O/'registration-append.txt').write_text(reg)
p='src/script/parser/driver.rs';before=subprocess.check_output(['git','show',B+':'+p],cwd=R);assert b'mod class_layout_probe;' not in before
bp=O/'before'/p;bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(before)
# Registration is an append-only proposed composition; source bodies stay unchanged.
after=before+reg.encode();ap=O/'registration-raw'/p;ap.parent.mkdir(parents=True,exist_ok=True);ap.write_bytes(after)
diff=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p));(O/'registration.patch').write_text(diff)
put('source-checks.json',{'base':B,'declaration_fragments':links,'whole_old_variants_preserved':True,'baseline_live_comparisons':len(actual),'baseline_rows':sum(len(v) for k,v in row_specs.items() if k!='classes'),'proposed_rows':sum(len(v) for k,v in row_specs.items())+7,'typed_record_notes':'Records<T> complete declaration is copied inside code mirrors; Token/Budget/Value/JsString/RegExp leaves use genuine published crate types. No inferred size stand-ins. Private functions::Context is fully mirrored and contributes to the actual State/Frame comparisons; no production visibility widening.','registration_inverse_exact':after[:-len(reg)]==before,'project_execution':False})
put('contract.json',{'status':'Frozen inert parser/code probe for root import and four-configuration execution; no observed measurements.','base':B,'shapes':bind(S/'source-ready.json'),'location':'src/script/parser/driver/class_layout_probe.rs','registration':'Append registration-append.txt to src/script/parser/driver.rs, or compose the exact two-line cfg(test) declaration in root registration. registration-raw and patch show the published-parent append only. Do not replace a later live parent file blindly.','test_name':'script::parser::driver::class_layout_probe::class_layout_parser_code_complete_shapes','test_groups':1,'scope':'Size/alignment, complete published baseline equivalence, typed formula output and zero-length Vec reserve capacity observations only. No parser methods, Runtime initialization, script execution, API/fee oracles or source lowering.','rows':'source-checks.json binds exact declaration fragments. Source normalized indentation only when nesting the full before/proposed type graphs. All original variants remain.','actual_type_access':'The probe is a descendant of parser::driver, so all accessible current code/parser/frame types use their genuine definitions. Full private Context/Records copies are source-bound; their containing actual State/Frame/Unit are compared. No visibility edits.','capacity_qualification':'Observed try_reserve_exact capacities concern zero-length Vecs of the actual mirror element types and explicit requested additions. They do not establish every future parser fixture capacity or startup allocation. Never assert capacity equals its request.','formulas':'Output reuses only existing source formulas: Unit Rc allowance, 128-record page charges, page-directory four slots, parser continuation four/eight slots, and MAX_HEAP/Kind bound. New Class/List formulas remain typed; outputs are measurements, not selected new fixed fees.','configs':['Rust 1.88 ordinary','Rust 1.88 host','current stable ordinary','current stable host+Vulkan'],'preservation':'No live edits, execution or new limits; source/checkpoint baselines remain unchanged. Root executes and retains raw output before selecting numerical expectations.'})
files=[]
for f in sorted(O.rglob('*')):
 if f.is_file() and f.name!='source-ready.json':
  b=f.read_bytes();files.append({'path':str(f.relative_to(O)),'bytes':len(b),'sha256':sha(b)})
put('source-ready.json',{'status':'sealed inert parser/code probe payload; unexecuted','base':B,'contract':bind(O/'contract.json'),'raw':bind(path),'registration':bind(O/'registration-append.txt'),'source_checks':bind(O/'source-checks.json'),'files':files,'production_changes':False,'project_execution':False})
print(json.dumps(bind(O/'source-ready.json')))
