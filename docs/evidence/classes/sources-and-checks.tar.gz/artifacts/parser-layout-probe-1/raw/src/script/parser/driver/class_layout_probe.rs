//! Inert full class parser/code layout mirrors. No parser or runtime methods run.
#![allow(dead_code, unused_mut, unused_imports)]
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct LayoutRow {
    name: &'static str,
    size: usize,
    align: usize,
}
fn row<T>(name: &'static str) -> LayoutRow {
    LayoutRow { name, size: size_of::<T>(), align: align_of::<T>() }
}
fn observe_capacity<T>(version: &str, name: &str, requests: &[usize]) {
    let mut values: Vec<T> = Vec::new();
    for requested in requests {
        let before = values.capacity();
        values.try_reserve_exact(*requested).unwrap();
        assert!(values.capacity() >= *requested);
        assert_eq!(values.len(), 0);
        eprintln!("CLASS_PARSER_CAPACITY version={version} type={name:?} len=0 requested_additional={requested} before={before} after={}", values.capacity());
    }
}
fn emit_formula(version: &str, name: &str, value: usize) {
    eprintln!("CLASS_PARSER_FORMULA version={version} name={name} value={value}");
}

mod before {
    use super::*;

    mod code {
        use super::*;

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ExprId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct StmtId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct FunctionId(usize);

        #[derive(Debug)]
        pub(super) struct Parameter {
            pub name: String,
            pub initializer: Option<ExprId>,
            pub rest: bool,
        }

        #[derive(Debug)]
        pub(super) struct Function {
            pub params: Vec<Parameter>,
            pub body: Vec<StmtId>,
            pub name: Option<String>,
            pub arrow: bool,
            pub self_name: bool,
            pub constructable: bool,
            pub strict: bool,
        }

        #[derive(Debug)]
        pub(super) struct Unit {
            expressions: Records<Expr>,
            statements: Records<Stmt>,
            functions: Records<Function>,
            pub body: Vec<StmtId>,
            pub strict: bool,
            pub compiled_storage: usize,
        }

        #[derive(Clone, Debug)]
        pub(super) struct FunctionRef {
            pub unit: Rc<Unit>,
            id: FunctionId,
        }

        #[derive(Debug)]
        pub(super) enum Expr {
            Literal(Value),
            RegExp(Rc<RegExp>),
            Ident(String),
            NewTarget,
            Array(Vec<Option<ExprId>>),
            Object(Vec<(PropertyName, ObjectEntry)>),
            Unary(String, ExprId),
            BinaryChain(ExprId, Vec<(String, ExprId)>),
            Conditional(ExprId, ExprId, ExprId),
            Assign(String, ExprId, ExprId),
            Update(ExprId, f64, bool),
            Member(ExprId, ExprId),
            Call(ExprId, Vec<ExprId>),
            New(ExprId, Vec<ExprId>),
            CallSpread(ExprId, Vec<ExprId>),
            NewSpread(ExprId, Vec<ExprId>),
            SpreadArgument(ExprId),
            Function(FunctionId),
            Sequence(Vec<ExprId>),
            Template(JsString, Vec<(ExprId, JsString)>),
        }

        #[derive(Debug)]
        pub(super) enum PropertyName {
            Literal(JsString),
            Computed(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum ObjectEntry {
            Data(ExprId),
            Method(FunctionId),
            Accessor(FunctionId, bool),
            Prototype(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum Stmt {
            Empty,
            Label(usize, StmtId),
            Expr(ExprId),
            Var(Vec<(String, Option<ExprId>)>, DeclarationKind),
            Block(Vec<StmtId>),
            If(ExprId, StmtId, Option<StmtId>),
            While(ExprId, StmtId),
            DoWhile(ExprId, StmtId),
            For(Option<StmtId>, Option<ExprId>, Option<ExprId>, StmtId),
            ForIn(ForBinding, ExprId, StmtId),
            ForOf(ForBinding, ExprId, StmtId),
            Switch(ExprId, Vec<(Option<ExprId>, Vec<StmtId>)>),
            Function(String, FunctionId),
            Return(Option<ExprId>),
            Throw(ExprId),
            Try(StmtId, Option<CatchClause>, Option<StmtId>),
            Break(Option<usize>),
            Continue(Option<usize>),
        }

        #[derive(Debug)]
        pub(super) enum ForBinding {
            Declaration(String, DeclarationKind),
            Target(ExprId),
        }

        #[derive(Debug)]
        pub(super) struct CatchClause {
            pub binding: Option<String>,
            pub body: Vec<StmtId>,
        }

        #[derive(Debug)]
        pub(super) struct Records<T> {
            pages: Vec<Vec<T>>,
            length: usize,
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<ExprId>("code::ExprId"),
                row::<StmtId>("code::StmtId"),
                row::<FunctionId>("code::FunctionId"),
                row::<Parameter>("code::Parameter"),
                row::<Function>("code::Function"),
                row::<Unit>("code::Unit"),
                row::<FunctionRef>("code::FunctionRef"),
                row::<Expr>("code::Expr"),
                row::<PropertyName>("code::PropertyName"),
                row::<ObjectEntry>("code::ObjectEntry"),
                row::<Stmt>("code::Stmt"),
                row::<ForBinding>("code::ForBinding"),
                row::<CatchClause>("code::CatchClause"),
                row::<Records<Expr>>("code::Records<Expr>"),
                row::<Records<Function>>("code::Records<Function>"),
            ];
            rows
        }

        pub(super) fn observe_allocations(version: &str) {
            observe_capacity::<Expr>(version, "code::Expr pages", &[128]);
            observe_capacity::<Stmt>(version, "code::Stmt pages", &[128]);
            observe_capacity::<Function>(version, "code::Function pages", &[128]);
            observe_capacity::<Vec<Expr>>(version, "code::Expr page directory", &[4, 8]);
        }
        pub(super) fn formulas(version: &str) {
            emit_formula(version, "unit_rc", size_of::<Unit>() + 2 * size_of::<usize>());
            emit_formula(version, "expression_page", 128 * size_of::<Expr>() + 32);
            emit_formula(version, "statement_page", 128 * size_of::<Stmt>() + 32);
            emit_formula(version, "function_page", 128 * size_of::<Function>() + 32);
            emit_formula(version, "expression_directory4", 4 * size_of::<Vec<Expr>>() + 32);
        }
    }

    mod parser {
        use super::*;
        use code::{CatchClause, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId};

        enum PropertyName {
            Literal(JsString, bool),
            Computed(ExprId),
        }

        struct ActiveLabel {
            name: String,
            target: usize,
            iteration: bool,
        }

        pub(super) struct Parser<'source> {
            tokens: tokens::Tokens,
            source: &'source str,
            lex_work: usize,
            compile_budget: regexp::Budget,
            unit: code::Unit,
            pos: usize,
            function_depth: usize,
            new_target_allowed: bool,
            loop_depth: usize,
            switch_depth: usize,
            labels: Vec<ActiveLabel>,
            next_label: usize,
            allow_in: bool,
            strict: bool,
        }

        mod driver {
            use super::*;

            enum Output {
                Expression(ExprId),
                Statement(StmtId),
                Body(Body),
                Function(FunctionCode),
                Parameters(functions::State),
                Key(PropertyName),
                Declaration(Stmt),
            }

            struct Body {
                statements: Vec<StmtId>,
                own_strict: bool,
                has_lexical: bool,
            }

            enum Kind {
                Expression(expressions::Frame),
                Statement(statements::Frame),
                Function(functions::Frame),
                Body(statements::BodyFrame),
            }

            enum Transition {
                Done(Output),
                Again(Kind),
                Child(Kind, Kind),
            }

            mod expressions {
                use super::*;

                pub(super) enum Frame {
                    Assignment,
                    AssignmentHead,
                    ConditionalYes(ExprId, bool),
                    ConditionalNo(ExprId, ExprId),
                    AssignmentRight(String, ExprId),
                    Sequence,
                    SequenceHead,
                    SequenceNext(Vec<ExprId>),
                    Binary(u8),
                    BinaryHead(u8),
                    BinaryRight(Binary, &'static str),
                    Unary,
                    Prefix(&'static str),
                    PrefixUpdate(f64),
                    Base(bool),
                    PostfixResume(Postfix),
                    Computed(Postfix, bool),
                    // Argument flags are (any spread, current operand is spread, saved allow_in).
                    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
                    New,
                    NewHead,
                    NewComputed(NewState, bool),
                    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
                    Primary,
                    CoverItem(Cover, bool),
                    ArrayItem(Array),
                    ObjectKey(Object, bool, bool),
                    AccessorKey(Object, bool),
                    ObjectFunction(Object, PropertyName, Option<bool>),
                    ObjectValue(Object, PropertyName, bool),
                    NamedFunction(Option<String>),
                    Key,
                    ComputedKey(bool),
                    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
                    Pass,
                }

                pub(super) struct Binary {
                    left: ExprId,
                    operations: Vec<(String, ExprId)>,
                    min: u8,
                    chain: usize,
                }

                pub(super) struct Postfix {
                    value: ExprId,
                    chain: usize,
                    async_call: bool,
                }

                pub(super) struct NewState {
                    value: ExprId,
                }

                pub(super) struct Cover {
                    items: Vec<(ExprId, bool)>,
                    saved_in: bool,
                }

                pub(super) struct Array {
                    items: Vec<Option<ExprId>>,
                    saved_in: bool,
                }

                pub(super) struct Object {
                    items: Vec<(code::PropertyName, ObjectEntry)>,
                    saved_in: bool,
                    prototype: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::expressions::Frame"),
                        row::<Binary>("parser::expressions::Binary"),
                        row::<Postfix>("parser::expressions::Postfix"),
                        row::<NewState>("parser::expressions::NewState"),
                        row::<Cover>("parser::expressions::Cover"),
                        row::<Array>("parser::expressions::Array"),
                        row::<Object>("parser::expressions::Object"),
                    ];
                    rows
                }

            }

            mod functions {
                use super::*;

                pub(super) enum Frame {
                    Start(bool),
                    Dynamic,
                    Default(State, String),
                    Body(State),
                    Arrow(Vec<Parameter>),
                    ArrowExpression(State),
                }

                pub(super) struct State {
                    params: Vec<Parameter>,
                    saved: Context,
                    unique: bool,
                    arrow: bool,
                    dynamic: bool,
                }

                struct Context {
                    loop_depth: usize,
                    switch_depth: usize,
                    allow_in: bool,
                    strict: bool,
                    labels: Vec<ActiveLabel>,
                    new_target_allowed: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::functions::Frame"),
                        row::<State>("parser::functions::State"),
                        row::<Context>("parser::functions::Context"),
                    ];
                    rows
                }

            }

            mod statements {
                use super::*;

                pub(super) enum Frame {
                    Start { declarations: bool },
                    Controlled,
                    ControlledDone,
                    Expression,
                    Declaration(bool),
                    DeclarationDone,
                    DeclarationDefault(Vec<(String, Option<ExprId>)>, DeclarationKind, String, bool),
                    Function(String),
                    Block,
                    Label(usize, usize),
                    SwitchExpression,
                    SwitchCase(Switch),
                    SwitchNext(Switch),
                    SwitchStatement(Switch, Option<ExprId>, Vec<StmtId>),
                    IfCondition,
                    IfYes(ExprId),
                    IfNo(ExprId, StmtId),
                    WhileCondition,
                    WhileBody(ExprId),
                    DoBody,
                    DoCondition(StmtId),
                    ForDeclaration(bool),
                    ForExpression(bool, bool),
                    ForTest(Option<Stmt>),
                    ForUpdate(Option<Stmt>, Option<ExprId>),
                    ForBody(Option<Stmt>, Option<ExprId>, Option<ExprId>),
                    ForInObject(ForBinding),
                    ForInBody(ForBinding, ExprId),
                    ForOfObject(ForBinding),
                    ForOfBody(ForBinding, ExprId),
                    Return,
                    Throw,
                    TryBody,
                    CatchBody(StmtId, Option<String>),
                    FinallyBody(StmtId, Option<CatchClause>),
                }

                pub(super) struct Switch {
                    value: ExprId,
                    cases: Vec<(Option<ExprId>, Vec<StmtId>)>,
                    default: bool,
                    lexical: bool,
                }

                pub(super) enum BodyFrame {
                    Start { block: bool, directive: bool },
                    Waiting(BodyState, Before),
                }

                pub(super) struct BodyState {
                    block: bool,
                    directive: bool,
                    start: usize,
                    prologue: bool,
                    body: Body,
                }

                pub(super) struct Before {
                    pos: usize,
                    string: bool,
                    strict: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::statements::Frame"),
                        row::<Switch>("parser::statements::Switch"),
                        row::<BodyFrame>("parser::statements::BodyFrame"),
                        row::<BodyState>("parser::statements::BodyState"),
                        row::<Before>("parser::statements::Before"),
                    ];
                    rows
                }

            }

            pub(super) fn rows() -> Vec<LayoutRow> {
                let mut rows = vec![
                    row::<Output>("parser::driver::Output"),
                    row::<Body>("parser::driver::Body"),
                    row::<Kind>("parser::driver::Kind"),
                    row::<Transition>("parser::driver::Transition"),
                ];
                rows.extend(expressions::rows());
                rows.extend(functions::rows());
                rows.extend(statements::rows());
                rows
            }

            pub(super) fn observe_allocations(version: &str) {
                observe_capacity::<Kind>(version, "parser::driver::Kind continuation", &[4, 8, 16]);
            }
            pub(super) fn formulas(version: &str) {
                emit_formula(version, "parser_frames4", 4 * size_of::<Kind>() + 32);
                emit_formula(version, "parser_frames8", 8 * size_of::<Kind>() + 32);
                emit_formula(version, "parser_frame_limit", MAX_HEAP / size_of::<Kind>());
            }
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<PropertyName>("parser::PropertyName"),
                row::<ActiveLabel>("parser::ActiveLabel"),
                row::<Parser<'static>>("parser::Parser"),
            ];
            rows.extend(driver::rows());
            rows
        }

        pub(super) fn observe_allocations(version: &str) {
            driver::observe_allocations(version);
        }
        pub(super) fn formulas(version: &str) { driver::formulas(version); }
    }

    pub(super) fn rows() -> Vec<LayoutRow> { let mut rows=code::rows(); rows.extend(parser::rows()); rows }
    pub(super) fn observe_allocations(version: &str) { code::observe_allocations(version); parser::observe_allocations(version); }
    pub(super) fn formulas(version: &str) { code::formulas(version); parser::formulas(version); }
}

mod proposed {
    use super::*;

    mod code {
        use super::*;

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ExprId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct StmtId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct FunctionId(usize);

        #[derive(Debug)]
        pub(super) struct Parameter {
            pub name: String,
            pub initializer: Option<ExprId>,
            pub rest: bool,
        }

        #[derive(Debug)]
        pub(super) struct Function {
            pub params: Vec<Parameter>,
            pub body: Vec<StmtId>,
            pub name: Option<String>,
            pub arrow: bool,
            pub self_name: bool,
            pub constructable: bool,
            pub strict: bool,
            pub class_kind: Option<ClassKind>,
        }

        #[derive(Debug)]
        pub(super) struct Unit {
            expressions: Records<Expr>,
            statements: Records<Stmt>,
            functions: Records<Function>,
            pub body: Vec<StmtId>,
            pub strict: bool,
            pub compiled_storage: usize,
            classes: Records<Class>,
        }

        #[derive(Clone, Debug)]
        pub(super) struct FunctionRef {
            pub unit: Rc<Unit>,
            id: FunctionId,
        }

        #[derive(Debug)]
        pub(super) enum Expr {
            Literal(Value),
            RegExp(Rc<RegExp>),
            Ident(String),
            NewTarget,
            Array(Vec<Option<ExprId>>),
            Object(Vec<(PropertyName, ObjectEntry)>),
            Unary(String, ExprId),
            BinaryChain(ExprId, Vec<(String, ExprId)>),
            Conditional(ExprId, ExprId, ExprId),
            Assign(String, ExprId, ExprId),
            Update(ExprId, f64, bool),
            Member(ExprId, ExprId),
            Call(ExprId, Vec<ExprId>),
            New(ExprId, Vec<ExprId>),
            CallSpread(ExprId, Vec<ExprId>),
            NewSpread(ExprId, Vec<ExprId>),
            SpreadArgument(ExprId),
            Function(FunctionId),
            Sequence(Vec<ExprId>),
            Template(JsString, Vec<(ExprId, JsString)>),
            Class(ClassId),
            SuperCall(Vec<ExprId>),
            SuperCallSpread(Vec<ExprId>),
        }

        #[derive(Debug)]
        pub(super) enum PropertyName {
            Literal(JsString),
            Computed(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum ObjectEntry {
            Data(ExprId),
            Method(FunctionId),
            Accessor(FunctionId, bool),
            Prototype(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum Stmt {
            Empty,
            Label(usize, StmtId),
            Expr(ExprId),
            Var(Vec<(String, Option<ExprId>)>, DeclarationKind),
            Block(Vec<StmtId>),
            If(ExprId, StmtId, Option<StmtId>),
            While(ExprId, StmtId),
            DoWhile(ExprId, StmtId),
            For(Option<StmtId>, Option<ExprId>, Option<ExprId>, StmtId),
            ForIn(ForBinding, ExprId, StmtId),
            ForOf(ForBinding, ExprId, StmtId),
            Switch(ExprId, Vec<(Option<ExprId>, Vec<StmtId>)>),
            Function(String, FunctionId),
            Return(Option<ExprId>),
            Throw(ExprId),
            Try(StmtId, Option<CatchClause>, Option<StmtId>),
            Break(Option<usize>),
            Continue(Option<usize>),
            Class(ClassId),
        }

        #[derive(Debug)]
        pub(super) enum ForBinding {
            Declaration(String, DeclarationKind),
            Target(ExprId),
        }

        #[derive(Debug)]
        pub(super) struct CatchClause {
            pub binding: Option<String>,
            pub body: Vec<StmtId>,
        }

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ClassId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassKind {
            ExplicitBase,
            ExplicitDerived,
            DefaultBase,
            DefaultDerived,
        }

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassElementKind {
            Method,
            Getter,
            Setter,
        }

        #[derive(Debug)]
        pub(super) struct Class {
            pub name: Option<String>,
            pub heritage: Option<ExprId>,
            pub constructor: FunctionId,
            pub elements: Vec<ClassElement>,
        }

        #[derive(Debug)]
        pub(super) struct ClassElement {
            pub name: PropertyName,
            pub function: FunctionId,
            pub kind: ClassElementKind,
            pub is_static: bool,
        }

        #[derive(Debug)]
        pub(super) struct Records<T> {
            pages: Vec<Vec<T>>,
            length: usize,
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<ExprId>("code::ExprId"),
                row::<StmtId>("code::StmtId"),
                row::<FunctionId>("code::FunctionId"),
                row::<Parameter>("code::Parameter"),
                row::<Function>("code::Function"),
                row::<Unit>("code::Unit"),
                row::<FunctionRef>("code::FunctionRef"),
                row::<Expr>("code::Expr"),
                row::<PropertyName>("code::PropertyName"),
                row::<ObjectEntry>("code::ObjectEntry"),
                row::<Stmt>("code::Stmt"),
                row::<ForBinding>("code::ForBinding"),
                row::<CatchClause>("code::CatchClause"),
                row::<Records<Expr>>("code::Records<Expr>"),
                row::<Records<Function>>("code::Records<Function>"),
                row::<ClassId>("code::ClassId"),
                row::<ClassKind>("code::ClassKind"),
                row::<ClassElementKind>("code::ClassElementKind"),
                row::<Class>("code::Class"),
                row::<ClassElement>("code::ClassElement"),
                row::<Records<Class>>("code::Records<Class>"),
            ];
            rows
        }

        pub(super) fn observe_allocations(version: &str) {
            observe_capacity::<Expr>(version, "code::Expr pages", &[128]);
            observe_capacity::<Stmt>(version, "code::Stmt pages", &[128]);
            observe_capacity::<Function>(version, "code::Function pages", &[128]);
            observe_capacity::<Vec<Expr>>(version, "code::Expr page directory", &[4, 8]);
            observe_capacity::<Class>(version, "code::Class pages", &[128]);
            observe_capacity::<ClassElement>(version, "code::ClassElement list", &[1, 2, 4, 8]);
            observe_capacity::<Vec<Class>>(version, "code::Class page directory", &[4, 8]);
        }
        pub(super) fn formulas(version: &str) {
            emit_formula(version, "unit_rc", size_of::<Unit>() + 2 * size_of::<usize>());
            emit_formula(version, "expression_page", 128 * size_of::<Expr>() + 32);
            emit_formula(version, "statement_page", 128 * size_of::<Stmt>() + 32);
            emit_formula(version, "function_page", 128 * size_of::<Function>() + 32);
            emit_formula(version, "expression_directory4", 4 * size_of::<Vec<Expr>>() + 32);
            emit_formula(version, "class_page", 128 * size_of::<Class>() + 32);
            emit_formula(version, "class_directory4", 4 * size_of::<Vec<Class>>() + 32);
            emit_formula(version, "class_elements4", 4 * size_of::<ClassElement>() + 32);
        }
    }

    mod parser {
        use super::*;
        use code::{CatchClause, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId, ClassId};

        enum PropertyName {
            Literal(JsString, bool),
            Computed(ExprId),
        }

        struct ActiveLabel {
            name: String,
            target: usize,
            iteration: bool,
        }

        pub(super) struct Parser<'source> {
            tokens: tokens::Tokens,
            source: &'source str,
            lex_work: usize,
            compile_budget: regexp::Budget,
            unit: code::Unit,
            pos: usize,
            function_depth: usize,
            new_target_allowed: bool,
            loop_depth: usize,
            switch_depth: usize,
            labels: Vec<ActiveLabel>,
            next_label: usize,
            allow_in: bool,
            strict: bool,
            super_call_allowed: bool,
            in_class: bool,
        }

        mod driver {
            use super::*;

            enum Output {
                Expression(ExprId),
                Statement(StmtId),
                Body(Body),
                Function(FunctionCode),
                Parameters(functions::State),
                Key(PropertyName),
                Declaration(Stmt),
                Class(ClassId),
            }

            struct Body {
                statements: Vec<StmtId>,
                own_strict: bool,
                has_lexical: bool,
            }

            enum Kind {
                Expression(expressions::Frame),
                Statement(statements::Frame),
                Function(functions::Frame),
                Body(statements::BodyFrame),
                Class(classes::Frame),
            }

            enum Transition {
                Done(Output),
                Again(Kind),
                Child(Kind, Kind),
            }

            struct EntryContext {
                allow_in: bool,
                strict: bool,
                super_call_allowed: bool,
                in_class: bool,
            }

            mod expressions {
                use super::*;

                pub(super) enum Frame {
                    Assignment,
                    AssignmentHead,
                    ConditionalYes(ExprId, bool),
                    ConditionalNo(ExprId, ExprId),
                    AssignmentRight(String, ExprId),
                    Sequence,
                    SequenceHead,
                    SequenceNext(Vec<ExprId>),
                    Binary(u8),
                    BinaryHead(u8),
                    BinaryRight(Binary, &'static str),
                    Unary,
                    Prefix(&'static str),
                    PrefixUpdate(f64),
                    Base(bool),
                    PostfixResume(Postfix),
                    Computed(Postfix, bool),
                    // Argument flags are (any spread, current operand is spread, saved allow_in).
                    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
                    New,
                    NewHead,
                    NewComputed(NewState, bool),
                    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
                    Primary,
                    CoverItem(Cover, bool),
                    ArrayItem(Array),
                    ObjectKey(Object, bool, bool),
                    AccessorKey(Object, bool),
                    ObjectFunction(Object, PropertyName, Option<bool>),
                    ObjectValue(Object, PropertyName, bool),
                    NamedFunction(Option<String>),
                    Key,
                    ComputedKey(bool),
                    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
                    Pass,
                    LeftHandSide,
                    LeftHandSideBase(bool),
                    ClassDone,
                    // Flags: any spread, current spread, saved allow_in, permit postfix update.
                    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),
                }

                pub(super) struct Binary {
                    left: ExprId,
                    operations: Vec<(String, ExprId)>,
                    min: u8,
                    chain: usize,
                }

                pub(super) struct Postfix {
                    value: ExprId,
                    chain: usize,
                    async_call: bool,
                    allow_update: bool,
                }

                pub(super) struct NewState {
                    value: ExprId,
                }

                pub(super) struct Cover {
                    items: Vec<(ExprId, bool)>,
                    saved_in: bool,
                }

                pub(super) struct Array {
                    items: Vec<Option<ExprId>>,
                    saved_in: bool,
                }

                pub(super) struct Object {
                    items: Vec<(code::PropertyName, ObjectEntry)>,
                    saved_in: bool,
                    prototype: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::expressions::Frame"),
                        row::<Binary>("parser::expressions::Binary"),
                        row::<Postfix>("parser::expressions::Postfix"),
                        row::<NewState>("parser::expressions::NewState"),
                        row::<Cover>("parser::expressions::Cover"),
                        row::<Array>("parser::expressions::Array"),
                        row::<Object>("parser::expressions::Object"),
                    ];
                    rows
                }

            }

            mod functions {
                use super::*;

                pub(super) enum Frame {
                    Start(bool),
                    Dynamic,
                    Default(State, String),
                    Body(State),
                    Arrow(Vec<Parameter>),
                    ArrowExpression(State),
                    // true only for a derived literal constructor; class methods use false.
                    ClassMethod(bool),
                }

                pub(super) struct State {
                    params: Vec<Parameter>,
                    saved: Context,
                    unique: bool,
                    arrow: bool,
                    dynamic: bool,
                }

                struct Context {
                    loop_depth: usize,
                    switch_depth: usize,
                    allow_in: bool,
                    strict: bool,
                    labels: Vec<ActiveLabel>,
                    new_target_allowed: bool,
                    super_call_allowed: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::functions::Frame"),
                        row::<State>("parser::functions::State"),
                        row::<Context>("parser::functions::Context"),
                    ];
                    rows
                }

            }

            mod statements {
                use super::*;

                pub(super) enum Frame {
                    Start { declarations: bool },
                    Controlled,
                    ControlledDone,
                    Expression,
                    Declaration(bool),
                    DeclarationDone,
                    DeclarationDefault(Vec<(String, Option<ExprId>)>, DeclarationKind, String, bool),
                    Function(String),
                    Block,
                    Label(usize, usize),
                    SwitchExpression,
                    SwitchCase(Switch),
                    SwitchNext(Switch),
                    SwitchStatement(Switch, Option<ExprId>, Vec<StmtId>),
                    IfCondition,
                    IfYes(ExprId),
                    IfNo(ExprId, StmtId),
                    WhileCondition,
                    WhileBody(ExprId),
                    DoBody,
                    DoCondition(StmtId),
                    ForDeclaration(bool),
                    ForExpression(bool, bool),
                    ForTest(Option<Stmt>),
                    ForUpdate(Option<Stmt>, Option<ExprId>),
                    ForBody(Option<Stmt>, Option<ExprId>, Option<ExprId>),
                    ForInObject(ForBinding),
                    ForInBody(ForBinding, ExprId),
                    ForOfObject(ForBinding),
                    ForOfBody(ForBinding, ExprId),
                    Return,
                    Throw,
                    TryBody,
                    CatchBody(StmtId, Option<String>),
                    FinallyBody(StmtId, Option<CatchClause>),
                    ClassDone,
                }

                pub(super) struct Switch {
                    value: ExprId,
                    cases: Vec<(Option<ExprId>, Vec<StmtId>)>,
                    default: bool,
                    lexical: bool,
                }

                pub(super) enum BodyFrame {
                    Start { block: bool, directive: bool },
                    Waiting(BodyState, Before),
                }

                pub(super) struct BodyState {
                    block: bool,
                    directive: bool,
                    start: usize,
                    prologue: bool,
                    body: Body,
                }

                pub(super) struct Before {
                    pos: usize,
                    string: bool,
                    strict: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::statements::Frame"),
                        row::<Switch>("parser::statements::Switch"),
                        row::<BodyFrame>("parser::statements::BodyFrame"),
                        row::<BodyState>("parser::statements::BodyState"),
                        row::<Before>("parser::statements::Before"),
                    ];
                    rows
                }

            }

            mod classes {
                use super::*;

                pub(super) enum Frame {
                    Start { declaration: bool },
                    Heritage(State),
                    Elements(State),
                    Key(State, Header),
                    Member(State, PropertyName, Header),
                }

                pub(super) struct State {
                    name: Option<String>,
                    heritage: Option<ExprId>,
                    constructor: Option<FunctionId>,
                    elements: Vec<code::ClassElement>,
                    saved: Context,
                }

                pub(super) struct Header {
                    kind: code::ClassElementKind,
                    is_static: bool,
                    is_constructor: bool,
                }

                struct Context {
                    strict: bool,
                    allow_in: bool,
                    in_class: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("parser::classes::Frame"),
                        row::<State>("parser::classes::State"),
                        row::<Header>("parser::classes::Header"),
                        row::<Context>("parser::classes::Context"),
                    ];
                    rows
                }

            }

            pub(super) fn rows() -> Vec<LayoutRow> {
                let mut rows = vec![
                    row::<Output>("parser::driver::Output"),
                    row::<Body>("parser::driver::Body"),
                    row::<Kind>("parser::driver::Kind"),
                    row::<Transition>("parser::driver::Transition"),
                    row::<EntryContext>("parser::driver::EntryContext"),
                ];
                rows.extend(expressions::rows());
                rows.extend(functions::rows());
                rows.extend(statements::rows());
                rows.extend(classes::rows());
                rows
            }

            pub(super) fn observe_allocations(version: &str) {
                observe_capacity::<Kind>(version, "parser::driver::Kind continuation", &[4, 8, 16]);
            }
            pub(super) fn formulas(version: &str) {
                emit_formula(version, "parser_frames4", 4 * size_of::<Kind>() + 32);
                emit_formula(version, "parser_frames8", 8 * size_of::<Kind>() + 32);
                emit_formula(version, "parser_frame_limit", MAX_HEAP / size_of::<Kind>());
            }
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<PropertyName>("parser::PropertyName"),
                row::<ActiveLabel>("parser::ActiveLabel"),
                row::<Parser<'static>>("parser::Parser"),
            ];
            rows.extend(driver::rows());
            rows
        }

        pub(super) fn observe_allocations(version: &str) {
            driver::observe_allocations(version);
        }
        pub(super) fn formulas(version: &str) { driver::formulas(version); }
    }

    pub(super) fn rows() -> Vec<LayoutRow> { let mut rows=code::rows(); rows.extend(parser::rows()); rows }
    pub(super) fn observe_allocations(version: &str) { code::observe_allocations(version); parser::observe_allocations(version); }
    pub(super) fn formulas(version: &str) { code::formulas(version); parser::formulas(version); }
}

fn actual_rows() -> Vec<LayoutRow> {
    vec![
        row::<code::ExprId>("code::ExprId"),
        row::<code::StmtId>("code::StmtId"),
        row::<code::FunctionId>("code::FunctionId"),
        row::<code::Parameter>("code::Parameter"),
        row::<code::Function>("code::Function"),
        row::<code::Unit>("code::Unit"),
        row::<code::FunctionRef>("code::FunctionRef"),
        row::<code::Expr>("code::Expr"),
        row::<code::PropertyName>("code::PropertyName"),
        row::<code::ObjectEntry>("code::ObjectEntry"),
        row::<code::Stmt>("code::Stmt"),
        row::<code::ForBinding>("code::ForBinding"),
        row::<code::CatchClause>("code::CatchClause"),
        row::<super::super::PropertyName>("parser::PropertyName"),
        row::<super::super::ActiveLabel>("parser::ActiveLabel"),
        row::<super::super::Parser<'static>>("parser::Parser"),
        row::<super::Output>("parser::driver::Output"),
        row::<super::Body>("parser::driver::Body"),
        row::<super::Kind>("parser::driver::Kind"),
        row::<super::Transition>("parser::driver::Transition"),
        row::<super::expressions::Frame>("parser::expressions::Frame"),
        row::<super::expressions::Binary>("parser::expressions::Binary"),
        row::<super::expressions::Postfix>("parser::expressions::Postfix"),
        row::<super::expressions::NewState>("parser::expressions::NewState"),
        row::<super::expressions::Cover>("parser::expressions::Cover"),
        row::<super::expressions::Array>("parser::expressions::Array"),
        row::<super::expressions::Object>("parser::expressions::Object"),
        row::<super::functions::Frame>("parser::functions::Frame"),
        row::<super::functions::State>("parser::functions::State"),
        row::<super::statements::Frame>("parser::statements::Frame"),
        row::<super::statements::Switch>("parser::statements::Switch"),
        row::<super::statements::BodyFrame>("parser::statements::BodyFrame"),
        row::<super::statements::BodyState>("parser::statements::BodyState"),
        row::<super::statements::Before>("parser::statements::Before"),
    ]
}

#[test]
fn class_layout_parser_code_complete_shapes() {
    let before = before::rows();
    let proposed = proposed::rows();
    let actual = actual_rows();
    for live in &actual {
        let held = before.iter().find(|row| row.name == live.name).unwrap();
        assert_eq!(held, live, "complete published mirror differs: {}", live.name);
    }
    for (version, rows) in [("before", &before), ("proposed", &proposed)] {
        let mut seen = std::collections::BTreeSet::new();
        for row in rows {
            assert!(seen.insert(row.name), "duplicate layout row");
            eprintln!("CLASS_PARSER_LAYOUT version={version} type={} size={} align={}", row.name, row.size, row.align);
        }
    }
    eprintln!("CLASS_PARSER_LAYOUT_COUNTS actual={} before={} proposed={}", actual.len(), before.len(), proposed.len());
    before::observe_allocations("before");
    proposed::observe_allocations("proposed");
    before::formulas("before");
    proposed::formulas("proposed");
}
