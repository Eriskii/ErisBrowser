from pathlib import Path
import hashlib,json,re,subprocess,difflib
F=Path('/tmp/eris-class-runtime-plan-1'); O=F/'runtime-shapes-review-1'; W=F/'worktree'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(x): return hashlib.sha256(x).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(Path(p).read_text())
def git(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=W)
def verify(d):
 if isinstance(d,dict):
  if all(k in d for k in ('path','bytes','sha256')):
   p=Path(d['path']);assert bind(p)=={k:d[k] for k in ('path','bytes','sha256')},str(p)
  for v in d.values():verify(v)
 elif isinstance(d,list):
  for v in d:verify(v)
def block(s,pattern):
 m=re.search(pattern,s,re.M);assert m,pattern
 start=s.index('{',m.start());n=1;i=start+1
 while n:
  n+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[m.start():i]
def decl(s,kind,name):
 return block(s,r'^(?:pub(?:\([^\n]*?\))? )?'+kind+' '+re.escape(name)+r' \{')
def visible(s):return re.sub(r'^(?:pub(?:\([^\n]*?\))? )?(struct|enum) ',r'pub(super) \1 ',s)
def ren(s,m):return re.sub(r'\b(?:'+'|'.join(map(re.escape,m))+r')\b',lambda x:m[x.group()],s)
def body(s,name):
 b=block(s,r'^mod '+name+r' \{');return '\n'.join(line[4:] if line.startswith('    ') else line for line in b.splitlines()[1:-1])
r1=load(F/'runtime-shapes-1/source-ready.json');r2=load(F/'runtime-shapes-2/source-ready.json')
verify(r1);verify(r2)
p1=(F/'runtime-shapes-1/raw/src/script/machine/statements/class_layout_probe.rs').read_text();p2=(F/'runtime-shapes-2/raw/src/script/machine/statements/class_layout_probe.rs').read_text()
assert p1.replace('vulkan={}','vulkan_raster={}').replace('cfg!(feature = "vulkan")','cfg!(feature = "vulkan-raster")')==p2
assert p1.count('vulkan={} ')==1 and p1.count('cfg!(feature = "vulkan")')==1
cargo=git('Cargo.toml').decode();assert re.search(r'^vulkan-raster\s*=',cargo,re.M);assert not re.search(r'^vulkan\s*=',cargo,re.M)
proof=load(F/'runtime-shapes-1/declaration-proof.json');sources={}
for row in proof['source_bindings']:
 b=git(row['relative']);assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['git_blob_sha1'];sources[row['relative']]=b.decode()
base=body(p2,'baseline');prop=body(p2,'proposed')
spec=[('Environment','src/script.rs','struct','Environment',{}),('Activation','src/script/machine/calls.rs','struct','Activation',{}),('CallFrame','src/script/machine/calls.rs','struct','Frame',{'Frame':'CallFrame','Phase':'CallPhase'}),('CallPhase','src/script/machine/calls.rs','enum','Phase',{'Phase':'CallPhase'}),('ExprFrame','src/script/machine.rs','struct','ExprFrame',{'Phase':'ExprPhase'}),('ExprPhase','src/script/machine.rs','enum','Phase',{'Phase':'ExprPhase'}),('StatementFrame','src/script/machine/statements.rs','struct','Frame',{'Frame':'StatementFrame','Phase':'StatementPhase'}),('StatementPhase','src/script/machine/statements.rs','enum','Phase',{'Phase':'StatementPhase'}),('Frame','src/script/machine.rs','enum','Frame',{})]
baselines={}
for name,path,kind,old,mapping in spec:
 source=decl(sources[path],kind,old)
 if mapping:source=ren(source,mapping)
 if name=='Frame':source=source.replace('statements::Frame','StatementFrame').replace('calls::Frame','CallFrame')
 source=visible(source);actual=decl(base,kind,name);assert source==actual,name;baselines[name]=actual
 assert proof['baseline_declarations'][name]==actual
# Independently selected addition strings, rather than relying on producer's inverse.
adds={
'CallPhase':'    ClassStart {\n        id: usize,\n        arguments: Vec<Value>,\n    },\n    ClassBody {\n        environment: usize,\n        kind: ClassKind,\n    },\n',
'ExprPhase':'    NamedStart(PropertyKey),\n    SuperArguments {\n        owner: usize,\n        new_target: Value,\n        superclass: Value,\n        index: usize,\n        arguments: Vec<Value>,\n    },\n    SuperSpreadArguments {\n        owner: usize,\n        new_target: Value,\n        superclass: Value,\n        index: usize,\n        arguments: call_spread::Arguments,\n    },\n',
'StatementPhase':'    ClassInitialize {\n        binding_environment: usize,\n    },\n','Frame':'    Class(ClassFrame),\n'}
checks=[]
for name,path,kind,old,mapping in spec:
 actual=decl(prop,kind,name);restored=actual
 if name=='Environment':
  assert restored.count('    this_binding: ThisBinding,\n')==1 and restored.count('    active_constructor: Option<usize>,\n')==1
  restored=restored.replace('    this_binding: ThisBinding,\n','    this_binding: Option<Value>,\n').replace('    active_constructor: Option<usize>,\n','')
 elif name in adds:
  assert restored.count(adds[name])==1;restored=restored.replace(adds[name],'')
 assert restored==baselines[name],name
 checks.append({'name':name,'published':path,'before_sha256':sha(baselines[name].encode()),'proposed_sha256':sha(actual.encode()),'exact_inverse':True})
expected_new={
 'ThisBinding':('enum','pub(super) enum ThisBinding {\n    Lexical,\n    Uninitialized,\n    Initialized(Value),\n}'),
 'ClassKind':('enum','pub(super) enum ClassKind {\n    ExplicitBase,\n    ExplicitDerived,\n    DefaultBase,\n    DefaultDerived,\n}'),
 'ClassFrame':('struct','pub(super) struct ClassFrame {\n    unit: Rc<code::Unit>,\n    class_id: ClassId,\n    outer_environment: usize,\n    phase: ClassPhase,\n}'),
 'ClassPhase':('enum','pub(super) enum ClassPhase {\n    Start {\n        inferred_name: Option<PropertyKey>,\n    },\n    Heritage {\n        class_environment: usize,\n        inferred_name: Option<PropertyKey>,\n    },\n    ComputedKey {\n        class_environment: usize,\n        constructor: usize,\n        prototype: usize,\n        element_index: usize,\n    },\n    Vacant,\n}')}
for name,(kind,want) in expected_new.items():assert decl(prop,kind,name)==want,name
assert 'pub(super) struct ClassId(usize);' in prop
code_shapes=(F/'parser-shapes-1/proposed/code.rs').read_text()
assert decl(code_shapes,'enum','ClassKind').split('{',1)[1]==expected_new['ClassKind'][1].split('{',1)[1]
assert re.search(r'struct ClassId\(usize\);',code_shapes)
assert len(re.findall(r'^    row!\(',p2,re.M))==42
assert len(re.findall(r'^    same!\(',p2,re.M))==7
assert not re.search(r'^    (?:let .*Runtime|.*Runtime::)',p2,re.M)
registration='\n#[cfg(test)]\nmod class_layout_probe;\n'
for row in r2['files']:
 before=Path(row['before']['path']).read_bytes() if row['before'] else b''
 raw=Path(row['raw']['path']).read_bytes()
 if not row['new']:
  assert before==git(row['relative']);assert raw==before+registration.encode()
 diff=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+row['relative'],tofile='b/'+row['relative']))
 actual_diff=Path(row['diff']['path']).read_text()
 # Exact diff body/hunks independently recomputed; new file uses /dev/null old label.
 assert actual_diff.splitlines(True)[2:]==diff.splitlines(True)[2:]
results={'status':'clear','base':BASE,'baseline_complete_declarations':9,'unchanged_complete_declarations':4,'selected_modified_declarations':5,'new_complete_declarations':5,'source_git_joins':len(sources),'baseline_size_alignment_comparisons':7,'type_rows':42,'configuration_rows':1,'formula_rows':2,'declaration_checks':checks,'correction':'Exactly two diagnostic lines: vulkan label and cfg feature become vulkan_raster / vulkan-raster. Cargo.toml declares vulkan-raster.','registration':'Exact append-only cfg(test) child; all published statements.rs bytes preserved.','genuine_neighbors':['Value','Binding','Reference','Flow','PropertyKey','code::FunctionRef','Rc<code::Unit>','call_spread::Arguments','statements::Kind','ForInState','ForOfState'],'qualifications':['The actual code Unit and FunctionRef appear behind fixed-width Rc/IDs; proposed code allocation sizes are covered by the separate parser/code probe, not guessed here.','Complete private Activation/CallPhase are source-joined and indirectly enclosed by the actual CallFrame comparison; no visibility widening.','No compiler, engine, project import or test execution in this review; no ABI or observed capacity claim.','Original hold1 feature-name issue remains retained; only hold2 is source-clear for the declared feature.']}
(O/'checks.json').write_text(json.dumps(results,indent=2)+'\n')
review={'status':'clear','scope':'Independent source-only review of complete runtime inert mirrors and config-only correction; no functional or measured layout claim.','base':BASE,'inputs':[bind(F/p) for p in ['runtime-shapes-2/source-ready.json','runtime-shapes-1/source-ready.json','runtime-shapes-1/declaration-proof.json','root/representation-selection-1.json','constructor-design-1/source-ready.json','constructor-design-1/interfaces.txt','constructor-design-1/coordination-addendum-1.json','constructor-design-1/strict-environment-addendum-1.json','parser-shapes-1/source-ready.json']],'checks':bind(O/'checks.json'),'checker':bind(O/'check.py'),'findings':[],'activity':{'project_execution':False,'live_edits':False,'production_authored':False},'result':'All nine baseline declarations independently reconstruct published source; all selected modified declarations invert exactly, four unchanged mirror declarations remain exact, and five new selected shapes agree. Both diff payloads and all receipt hashes match. No source finding.'}
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(O/'review.json')))
