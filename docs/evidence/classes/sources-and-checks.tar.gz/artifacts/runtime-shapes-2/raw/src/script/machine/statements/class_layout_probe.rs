//! Inert complete class runtime layout mirrors. No class operations execute.
//! Baseline declarations are mechanically joined to the published parent;
//! proposed declarations add only the selected representation fields/variants.
use super::{ForInState, ForOfState, Kind};
use crate::script::{Binding, Flow, PropertyKey, Reference, Result, Value, code};
use crate::script::machine::call_spread;
use std::collections::{BTreeMap, BTreeSet};
use std::rc::Rc;

#[allow(dead_code)]
mod baseline {
    use super::*;

    pub(super) struct Environment {
        bindings: BTreeMap<String, Binding>,
        // Execution receiver, never an author-visible property or lexical name.
        this_binding: Option<Value>,
        new_target_binding: Option<Value>,
        parent: Option<usize>,
        function_scope: bool,
        strict: bool,
    }

    pub(super) struct Activation {
        code: code::FunctionRef,
        env: usize,
        arguments: Vec<Value>,
        arguments_binding: bool,
        parameter_expressions: bool,
    }

    pub(super) struct CallFrame {
        owns_call: bool,
        new_target: Value,
        phase: CallPhase,
    }

    pub(super) enum CallPhase {
        Start {
            function: Value,
            arguments: Vec<Value>,
            receiver: Value,
            native_guarded: bool,
        },
        Default {
            activation: Activation,
            index: usize,
        },
        Body,
        Forward,
        Vacant,
    }

    pub(super) struct ExprFrame {
        unit: Rc<code::Unit>,
        expression: code::ExprId,
        env: usize,
        reference: bool,
        phase: ExprPhase,
    }

    pub(super) enum ExprPhase {
        Start,
        ReferenceObject,
        ReferenceKey(Value),
        Unary,
        Delete,
        BinaryHead,
        BinaryRight {
            index: usize,
            left: Value,
        },
        Conditional,
        Identity,
        Sequence(usize),
        Array {
            index: usize,
            values: Vec<Value>,
            holes: BTreeSet<usize>,
        },
        ObjectKey {
            index: usize,
            object: Value,
        },
        ObjectValue {
            index: usize,
            object: Value,
            key: PropertyKey,
        },
        ObjectPrototype {
            index: usize,
            object: Value,
        },
        Template {
            index: usize,
            output: Vec<u16>,
        },
        AssignReference,
        AssignValue {
            reference: Reference,
            old: Option<Value>,
            logical: bool,
        },
        Update,
        Callee,
        MemberCallee,
        Arguments {
            index: usize,
            function: Value,
            receiver: Value,
            arguments: Vec<Value>,
        },
        SpreadArguments {
            index: usize,
            function: Value,
            receiver: Value,
            arguments: call_spread::Arguments,
        },
    }

    pub(super) struct StatementFrame {
        unit: Rc<code::Unit>,
        env: usize,
        kind: Kind,
        phase: StatementPhase,
    }

    pub(super) enum StatementPhase {
        Start,
        ListNext {
            index: usize,
            last: Option<Value>,
        },
        Identity,
        Expression,
        Return,
        Throw,
        Label,
        If,
        UpdateEmpty,
        Declare(usize),
        WhileTest(Value),
        DoTest(Value),
        LoopBody(Value),
        ForInit(usize),
        ForTest {
            child: usize,
            last: Value,
        },
        ForBody {
            child: usize,
            last: Value,
        },
        ForUpdate {
            child: usize,
            last: Value,
        },
        SwitchValue,
        SwitchTest {
            child: usize,
            value: Value,
            index: usize,
            default: Option<usize>,
        },
        SwitchBody {
            child: usize,
            case: usize,
            index: usize,
            last: Value,
        },
        TryBody,
        TryCatch,
        TryFinally(Result<Flow>),
        ForInValue,
        ForInTarget {
            state: ForInState,
            key: Value,
        },
        ForInBody(ForInState),
        ForOfValue,
        ForOfIterator,
        ForOfNext(ForOfState),
        ForOfTarget {
            state: ForOfState,
            value: Value,
        },
        ForOfBody(ForOfState),
        ForOfClose(Result<Flow>),
    }

    pub(super) enum Frame {
        Expression(ExprFrame),
        Statement(StatementFrame),
        Call(CallFrame),
    }
}

#[allow(dead_code)]
mod proposed {
    use super::*;

    pub(super) struct ClassId(usize);

    pub(super) enum ClassKind {
        ExplicitBase,
        ExplicitDerived,
        DefaultBase,
        DefaultDerived,
    }

    pub(super) enum ThisBinding {
        Lexical,
        Uninitialized,
        Initialized(Value),
    }

    pub(super) struct ClassFrame {
        unit: Rc<code::Unit>,
        class_id: ClassId,
        outer_environment: usize,
        phase: ClassPhase,
    }

    pub(super) enum ClassPhase {
        Start {
            inferred_name: Option<PropertyKey>,
        },
        Heritage {
            class_environment: usize,
            inferred_name: Option<PropertyKey>,
        },
        ComputedKey {
            class_environment: usize,
            constructor: usize,
            prototype: usize,
            element_index: usize,
        },
        Vacant,
    }

    pub(super) struct Environment {
        bindings: BTreeMap<String, Binding>,
        // Execution receiver, never an author-visible property or lexical name.
        this_binding: ThisBinding,
        new_target_binding: Option<Value>,
        active_constructor: Option<usize>,
        parent: Option<usize>,
        function_scope: bool,
        strict: bool,
    }

    pub(super) struct Activation {
        code: code::FunctionRef,
        env: usize,
        arguments: Vec<Value>,
        arguments_binding: bool,
        parameter_expressions: bool,
    }

    pub(super) struct CallFrame {
        owns_call: bool,
        new_target: Value,
        phase: CallPhase,
    }

    pub(super) enum CallPhase {
        Start {
            function: Value,
            arguments: Vec<Value>,
            receiver: Value,
            native_guarded: bool,
        },
        Default {
            activation: Activation,
            index: usize,
        },
        Body,
        Forward,
        Vacant,
        ClassStart {
            id: usize,
            arguments: Vec<Value>,
        },
        ClassBody {
            environment: usize,
            kind: ClassKind,
        },
    }

    pub(super) struct ExprFrame {
        unit: Rc<code::Unit>,
        expression: code::ExprId,
        env: usize,
        reference: bool,
        phase: ExprPhase,
    }

    pub(super) enum ExprPhase {
        Start,
        ReferenceObject,
        ReferenceKey(Value),
        Unary,
        Delete,
        BinaryHead,
        BinaryRight {
            index: usize,
            left: Value,
        },
        Conditional,
        Identity,
        Sequence(usize),
        Array {
            index: usize,
            values: Vec<Value>,
            holes: BTreeSet<usize>,
        },
        ObjectKey {
            index: usize,
            object: Value,
        },
        ObjectValue {
            index: usize,
            object: Value,
            key: PropertyKey,
        },
        ObjectPrototype {
            index: usize,
            object: Value,
        },
        Template {
            index: usize,
            output: Vec<u16>,
        },
        AssignReference,
        AssignValue {
            reference: Reference,
            old: Option<Value>,
            logical: bool,
        },
        Update,
        Callee,
        MemberCallee,
        Arguments {
            index: usize,
            function: Value,
            receiver: Value,
            arguments: Vec<Value>,
        },
        SpreadArguments {
            index: usize,
            function: Value,
            receiver: Value,
            arguments: call_spread::Arguments,
        },
        NamedStart(PropertyKey),
        SuperArguments {
            owner: usize,
            new_target: Value,
            superclass: Value,
            index: usize,
            arguments: Vec<Value>,
        },
        SuperSpreadArguments {
            owner: usize,
            new_target: Value,
            superclass: Value,
            index: usize,
            arguments: call_spread::Arguments,
        },
    }

    pub(super) struct StatementFrame {
        unit: Rc<code::Unit>,
        env: usize,
        kind: Kind,
        phase: StatementPhase,
    }

    pub(super) enum StatementPhase {
        Start,
        ListNext {
            index: usize,
            last: Option<Value>,
        },
        Identity,
        Expression,
        Return,
        Throw,
        Label,
        If,
        UpdateEmpty,
        Declare(usize),
        WhileTest(Value),
        DoTest(Value),
        LoopBody(Value),
        ForInit(usize),
        ForTest {
            child: usize,
            last: Value,
        },
        ForBody {
            child: usize,
            last: Value,
        },
        ForUpdate {
            child: usize,
            last: Value,
        },
        SwitchValue,
        SwitchTest {
            child: usize,
            value: Value,
            index: usize,
            default: Option<usize>,
        },
        SwitchBody {
            child: usize,
            case: usize,
            index: usize,
            last: Value,
        },
        TryBody,
        TryCatch,
        TryFinally(Result<Flow>),
        ForInValue,
        ForInTarget {
            state: ForInState,
            key: Value,
        },
        ForInBody(ForInState),
        ForOfValue,
        ForOfIterator,
        ForOfNext(ForOfState),
        ForOfTarget {
            state: ForOfState,
            value: Value,
        },
        ForOfBody(ForOfState),
        ForOfClose(Result<Flow>),
        ClassInitialize {
            binding_environment: usize,
        },
    }

    pub(super) enum Frame {
        Expression(ExprFrame),
        Statement(StatementFrame),
        Call(CallFrame),
        Class(ClassFrame),
    }
}

#[test]
fn class_runtime_complete_layout_probe() {
    use std::mem::{align_of, size_of};
    macro_rules! same {
        ($mirror:ty, $actual:ty) => {
            assert_eq!(size_of::<$mirror>(), size_of::<$actual>());
            assert_eq!(align_of::<$mirror>(), align_of::<$actual>());
        };
    }
    macro_rules! row {
        ($label:literal, $ty:ty) => {
            println!(
                "CLASS_RUNTIME_LAYOUT {} bytes={} align={}",
                $label,
                size_of::<$ty>(),
                align_of::<$ty>()
            );
        };
    }
    // Exact parent aggregates independently constrain the mechanically copied
    // complete baselines. No proposed numeric size is embedded in this probe.
    same!(baseline::Environment, crate::script::Environment);
    same!(baseline::CallFrame, crate::script::machine::calls::Frame);
    same!(baseline::ExprFrame, crate::script::machine::ExprFrame);
    same!(baseline::ExprPhase, crate::script::machine::Phase);
    same!(baseline::StatementFrame, super::Frame);
    same!(baseline::StatementPhase, super::Phase);
    same!(baseline::Frame, crate::script::machine::Frame);

    println!(
        "CLASS_RUNTIME_LAYOUT_CONFIG test262_host={} vulkan_raster={} pointer_bytes={}",
        cfg!(feature = "test262-host"),
        cfg!(feature = "vulkan-raster"),
        size_of::<usize>()
    );
    row!("Value", Value);
    row!("OptionValue", Option<Value>);
    row!("OptionUsize", Option<usize>);
    row!("PropertyKey", PropertyKey);
    row!("OptionPropertyKey", Option<PropertyKey>);
    row!("Reference", Reference);
    row!("Binding", Binding);
    row!("Function", crate::script::Function);
    row!("BoundFunction", crate::script::BoundFunction);
    row!("ScriptObject", crate::script::ScriptObject);
    row!("Runtime", crate::script::Runtime);
    row!("FunctionRef", code::FunctionRef);
    row!("CodeFunction.parent", code::Function);
    row!("CodeUnit.parent", code::Unit);
    row!("CallSpreadArguments", call_spread::Arguments);
    row!("StatementKind", Kind);
    row!("ForInState", ForInState);
    row!("ForOfState", ForOfState);
    row!("baseline.Environment", baseline::Environment);
    row!("baseline.Activation", baseline::Activation);
    row!("baseline.CallPhase", baseline::CallPhase);
    row!("baseline.CallFrame", baseline::CallFrame);
    row!("baseline.ExprPhase", baseline::ExprPhase);
    row!("baseline.ExprFrame", baseline::ExprFrame);
    row!("baseline.StatementPhase", baseline::StatementPhase);
    row!("baseline.StatementFrame", baseline::StatementFrame);
    row!("baseline.Frame", baseline::Frame);
    row!("proposed.ThisBinding", proposed::ThisBinding);
    row!("proposed.Environment", proposed::Environment);
    row!("proposed.ClassId", proposed::ClassId);
    row!("proposed.ClassKind", proposed::ClassKind);
    row!("proposed.OptionClassKind", Option<proposed::ClassKind>);
    row!("proposed.ClassPhase", proposed::ClassPhase);
    row!("proposed.ClassFrame", proposed::ClassFrame);
    row!("proposed.Activation", proposed::Activation);
    row!("proposed.CallPhase", proposed::CallPhase);
    row!("proposed.CallFrame", proposed::CallFrame);
    row!("proposed.ExprPhase", proposed::ExprPhase);
    row!("proposed.ExprFrame", proposed::ExprFrame);
    row!("proposed.StatementPhase", proposed::StatementPhase);
    row!("proposed.StatementFrame", proposed::StatementFrame);
    row!("proposed.Frame", proposed::Frame);
    println!(
        "CLASS_RUNTIME_FRAME_FORMULAS baseline_initial={} proposed_initial={} baseline_max={} proposed_max={}",
        8 * size_of::<baseline::Frame>() + 32,
        8 * size_of::<proposed::Frame>() + 32,
        crate::script::MAX_HEAP / size_of::<baseline::Frame>(),
        crate::script::MAX_HEAP / size_of::<proposed::Frame>()
    );
    println!(
        "CLASS_RUNTIME_ENVIRONMENT_FORMULAS legacy={} proposed={} two_initial_delta={}",
        128 + 2 * size_of::<Option<Value>>(),
        128 + 2 * size_of::<Option<Value>>()
            + size_of::<proposed::Environment>().saturating_sub(size_of::<baseline::Environment>()),
        2 * size_of::<proposed::Environment>().saturating_sub(size_of::<baseline::Environment>())
    );
}
