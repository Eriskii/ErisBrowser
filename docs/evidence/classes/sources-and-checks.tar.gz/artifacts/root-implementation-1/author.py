from pathlib import Path
import subprocess,json,hashlib
f=Path('/tmp/eris-class-runtime-plan-1');out=f/'root-implementation-1';repo=f/'worktree'
files={};chunks=[]
def original(rel):return subprocess.check_output(['git','show','f3118ae5787c410648657f7c822efb7014201dd1:'+rel],cwd=repo).decode()
def edit(rel,before,after,count=1):
 s=files.setdefault(rel,original(rel));assert s.count(before)==count,(rel,before[:100],s.count(before));files[rel]=s.replace(before,after);chunks.append({'path':rel,'before':before,'after':after,'occurrences':count})
s='src/script.rs'
edit(s,'struct Environment {','''enum ThisBinding {
    Lexical,
    Uninitialized,
    Initialized(Value),
}
// Retain the existing conservative environment allowance and account for
// the complete added state, including the active constructor ID.
const ENVIRONMENT_CLASS_BYTES: usize = std::mem::size_of::<Option<usize>>()
    + std::mem::size_of::<ThisBinding>()
        .saturating_sub(std::mem::size_of::<Option<Value>>());
struct Environment {''')
edit(s,'    this_binding: Option<Value>,','    this_binding: ThisBinding,\n    active_constructor: Option<usize>,')
edit(s,'                    this_binding: Some(Value::Window),','                    this_binding: ThisBinding::Initialized(Value::Window),\n                    active_constructor: None,')
edit(s,'                    this_binding: None,','                    this_binding: ThisBinding::Lexical,\n                    active_constructor: None,')
edit(s,'                + 4 * std::mem::size_of::<Option<Value>>()','                + 4 * std::mem::size_of::<Option<Value>>()\n                + 2 * ENVIRONMENT_CLASS_BYTES',2)
edit(s,'        self.charge(128 + 2 * std::mem::size_of::<Option<Value>>())?;','        self.charge(128 + 2 * std::mem::size_of::<Option<Value>>() + ENVIRONMENT_CLASS_BYTES)?;')
edit(s,'            this_binding: None,','            this_binding: ThisBinding::Lexical,\n            active_constructor: None,')
edit(s,'                if self.environments[cursor].this_binding.is_some() {','                if !matches!(self.environments[cursor].this_binding, ThisBinding::Lexical) {')
edit(s,'''            return self.environments[env]
                .this_binding
                .clone()
                .ok_or_else(|| ScriptError::reference("missing execution receiver"));''','''            return self.class_this_value(env);''')
# Class names are lexical bindings; nested class syntax is a scope-walk leaf.
needle='''        for statement in body {
            if let code::Stmt::Var(bindings, kind) = unit.stmt(*statement)
                && *kind != DeclarationKind::Var
            {'''
assert files[s].count(needle)==2
# First occurrence is validation; second is instantiation.
old=files[s];pos=old.index(needle)
before=old[pos:old.index('        Ok(())',pos)]
after=before.replace(needle,'''        for statement in body {
            if let code::Stmt::Class(id) = unit.stmt(*statement) {
                let name = unit.class(*id).name.as_ref().expect("named class declaration");
                if self.environments[env].bindings.contains_key(name)
                    || env == 1
                        && self.environments[0].bindings.get(name).is_some_and(|b| !b.deletable)
                {
                    return Err(ScriptError::syntax(format!(
                        "duplicate lexical binding '{name}'"
                    )));
                }
            }
            if let code::Stmt::Var(bindings, kind) = unit.stmt(*statement)
                && *kind != DeclarationKind::Var
            {''')
edit(s,before,after)
pos=files[s].index('    fn instantiate_lexical(');start=files[s].index(needle,pos);before=files[s][start:files[s].index('        Ok(())',start)]
after=before.replace(needle,'''        for statement in body {
            if let code::Stmt::Class(id) = unit.stmt(*statement) {
                let name = unit.class(*id).name.as_ref().expect("named class declaration");
                self.charge(name.len() + BINDING_BYTES)?;
                self.environments[env].bindings.insert(
                    name.clone(),
                    Binding {
                        value: Value::Undefined,
                        accessor: None,
                        mutable: true,
                        initialized: false,
                        strict_immutable: false,
                        global_property: false,
                        global_order: 0,
                        enumerable: true,
                        deletable: false,
                    },
                );
            }
            if let code::Stmt::Var(bindings, kind) = unit.stmt(*statement)
                && *kind != DeclarationKind::Var
            {''')
edit(s,before,after)
edit(s,'    fn var_scope(&self, mut env: usize) -> usize {','''    fn initialize_class_declaration(
        &mut self,
        environment: usize,
        name: &str,
        constructor: Value,
    ) -> Result<()> {
        self.work(6)?;
        let bindings = self.environments.get(environment)
            .ok_or_else(|| ScriptError::resource("invalid class declaration environment"))?
            .bindings.len();
        let width = name.len().checked_add(1)
            .ok_or_else(|| ScriptError::resource("class binding lookup overflow"))?;
        let work = promises::intrinsic_tree(bindings).0.checked_mul(width)
            .ok_or_else(|| ScriptError::resource("class binding lookup overflow"))?;
        self.work(work)?;
        let binding = self.environments[environment].bindings.get_mut(name)
            .ok_or_else(|| ScriptError::resource("missing class declaration binding"))?;
        if !binding.mutable || binding.global_property || binding.initialized {
            return Err(ScriptError::resource("invalid class declaration binding"));
        }
        binding.value = constructor;
        binding.initialized = true;
        Ok(())
    }
    fn var_scope(&self, mut env: usize) -> usize {''')
c='src/script/machine/calls.rs'
edit(c,'runtime.environments[env].this_binding = Some(receiver);','runtime.environments[env].this_binding = crate::script::ThisBinding::Initialized(receiver);')
edit(c,'''            let next = Job::Expression(ExprFrame {
                unit: code.unit.clone(),
                expression: initializer,
                env: activation.env,
                reference: false,
                phase: ExprPhase::Start,
            });''','''            let expression = if code.unit.anonymous_class(initializer).is_some() {
                let hint = runtime.class_identifier_name_hint(&parameter.name)?;
                ExprFrame::named_class(code.unit.clone(), initializer, activation.env, hint)
            } else {
                ExprFrame {
                    unit: code.unit.clone(),
                    expression: initializer,
                    env: activation.env,
                    reference: false,
                    phase: ExprPhase::Start,
                }
            };
            let next = Job::Expression(expression);''')
st='src/script/machine/statements.rs'
edit(st,'    Declare(usize),','    Declare(usize),\n    ClassInitialize { binding_environment: usize },')
edit(st,'        Phase::Declare(index) => {','''        Phase::ClassInitialize { binding_environment } => {
            let code::Stmt::Class(id) = unit.stmt(frame.id()) else {
                unreachable!("class declaration continuation")
            };
            let name = unit.class(*id).name.as_deref().expect("named class declaration");
            runtime.initialize_class_declaration(binding_environment, name, value(output))?;
            done(Flow::Normal(None))
        }
        Phase::Declare(index) => {''')
edit(st,'        code::Stmt::Var(..) => declaration_next(runtime, frame, 0, doc),','''        code::Stmt::Var(..) => declaration_next(runtime, frame, 0, doc),
        code::Stmt::Class(id) => {
            let next = Job::Class(super::classes::Frame::new(unit.clone(), *id, env, None));
            schedule(runtime, frame, Phase::ClassInitialize { binding_environment: env }, next)
        }''')
edit(st,'''    while let Some((_, initializer)) = bindings.get(index) {
        if let Some(initializer) = initializer {
            let env = frame.env;
            return expression(runtime, frame, Phase::Declare(index), *initializer, env);
        }''','''    while let Some((name, initializer)) = bindings.get(index) {
        if let Some(initializer) = initializer {
            let env = frame.env;
            if unit.anonymous_class(*initializer).is_some() {
                let hint = runtime.class_identifier_name_hint(name)?;
                let next = Job::Expression(ExprFrame::named_class(
                    unit.clone(), *initializer, env, hint,
                ));
                return schedule(runtime, frame, Phase::Declare(index), next);
            }
            return expression(runtime, frame, Phase::Declare(index), *initializer, env);
        }''')
m='src/script/machine.rs'
# A paid hint is consumed before evaluating a direct anonymous class.
edit(m,'fn reference_child(','按'.replace('按','''fn named_class_child(
    runtime: &mut Runtime,
    mut frame: ExprFrame,
    phase: Phase,
    expression: code::ExprId,
    hint: PropertyKey,
) -> Result<Option<Output>> {
    let next = ExprFrame::named_class(frame.unit.clone(), expression, frame.env, hint);
    frame.phase = phase;
    push(runtime, Frame::Expression(frame))?;
    enter(runtime, next)?;
    Ok(None)
}
fn reference_child('''))
edit(m,'''    eval_child(
        runtime,
        frame,
        Phase::AssignValue {
            reference,
            old: if logical { None } else { old },
            logical,
        },
        *right,
    )''','''    let hint = if (op == "=" || logical) && unit.anonymous_class(*right).is_some() {
        if let Reference::CodeName { unit: owner, expression, .. } = &reference {
            let code::Expr::Ident(name) = owner.expr(*expression) else {
                unreachable!("identifier assignment reference")
            };
            Some(runtime.class_identifier_name_hint(name)?)
        } else {
            None
        }
    } else {
        None
    };
    let phase = Phase::AssignValue {
        reference,
        old: if logical { None } else { old },
        logical,
    };
    if let Some(hint) = hint {
        named_class_child(runtime, frame, phase, *right, hint)
    } else {
        eval_child(runtime, frame, phase, *right)
    }''')
edit(m,'''            code::ObjectEntry::Data(expression) => {
                return eval_child(''','''            code::ObjectEntry::Data(expression) => {
                if unit.anonymous_class(*expression).is_some() {
                    let hint = runtime.class_name_hint(&key)?;
                    return named_class_child(
                        runtime, frame, Phase::ObjectValue { index, object, key },
                        *expression, hint,
                    );
                }
                return eval_child(''')
# Raw source and exact composable chunks, never imported implicitly.
manifest=[]
for rel,content in files.items():
 path=out/'raw'/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_text(content)
 b=path.read_bytes();manifest.append({'path':rel,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(out/'chunks.json').write_text(json.dumps(chunks,indent=2)+'\n')
(out/'source-ready.json').write_text(json.dumps({'base':'f3118ae5787c410648657f7c822efb7014201dd1','files':manifest,'chunks':len(chunks),'status':'root integration source, no live import or project execution'},indent=2)+'\n')
print(json.dumps(manifest,indent=2))
