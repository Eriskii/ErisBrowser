function check(v){if(!v)throw new Error('class oracle');}
var trace='',token={},done=false;
class Q extends Promise {}
class P extends Promise {static get [Symbol.species](){trace+='G';return Q;}}
var p=new P(resolve=>resolve(token));
var q=p.then(v=>{check(v===token);trace+='R';done=true;return v;});
check(p instanceof P&&q instanceof Q&&q instanceof Promise&&!(q instanceof P));
