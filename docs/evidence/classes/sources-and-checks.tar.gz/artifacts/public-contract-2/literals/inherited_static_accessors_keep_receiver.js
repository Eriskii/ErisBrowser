function check(v){if(!v)throw new Error('class oracle');}
var result=(function(){
 var sym=Symbol('tag'),token={},writes=0;
 class C {static get x(){return this.v;} static set x(v){writes++;this.v=v;}
   static get [sym](){return this;} static set [sym](v){this.saved=v;}}
 class D extends C {}
 C.x=7;D.x=8;D[sym]=token;
 var d=Object.getOwnPropertyDescriptor(C,'x'),s=Object.getOwnPropertyDescriptor(C,sym);
 check(C.x===7&&D.x===8&&writes===2&&D[sym]===D&&D.saved===token&&!Object.prototype.hasOwnProperty.call(C,'saved'));
 check(!d.enumerable&&d.configurable&&d.get.name==='get x'&&d.set.name==='set x');
 check(!s.enumerable&&s.configurable&&s.get.name==='get [tag]'&&s.set.name==='set [tag]');
 return 'static-receivers:2';
})();
