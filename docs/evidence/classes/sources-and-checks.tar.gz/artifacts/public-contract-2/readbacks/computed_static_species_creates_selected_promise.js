trace+'|'+done
