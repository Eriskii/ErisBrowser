from pathlib import Path
import hashlib
import json
import subprocess
import textwrap

F=Path('/tmp/eris-class-runtime-plan-1');D=F/'public-contract-2';OLD=F/'public-contract-1';W=F/'worktree'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return bind(p)
def obj(p,v):return put(p,(json.dumps(v,indent=2)+'\n').encode())
def load(p):return json.loads(p.read_bytes())
original=load(OLD/'source-ready.json');oldcases=load(OLD/'cases.json')
assert bind(OLD/'source-ready.json')['sha256']=='74ec852db5b326286f2d1c4b43ab02864f723d7d78eb34e2cf2579da291eb309'
selection=load(F/'root/selection-1.json')
assert bind(F/'root/selection-1.json')['sha256']=='8e61332ac67c2835beb67450a2767dbbf38b2882074bbcf9340f0a86e8f9a5f1'
readiness=load(Path(load(OLD/'contract.json')['readiness']['path']))
joins=[]
for row in readiness['source_bindings']:
 rel=row['path'];b=(W/rel).read_bytes()
 assert (len(b),sha(b))==(row['bytes'],row['sha256'])
 assert b==subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
 joins.append({'relative_path':rel,'bytes':len(b),'sha256':sha(b),'published_git_exact':True})
assert len(joins)==27
refresh=obj(D/'published-base-refresh.json',{
 'base':BASE,'original_literal_runtime_base':load(OLD/'contract.json')['runtime_read_base'],
 'selection':bind(F/'root/selection-1.json'),'root_readiness_refresh':bind(F/'root/readiness-base-refresh.json'),
 'runtime_sources':joins,'original_first_slice_exact':selection['included']==readiness['first_slice']['included'],
 'qualification':'The original60 literal rows and outcomes are unchanged; all27 published runtime reads remain byte-exact at f311. No future production or outcomes were inspected.'})
new=[]
def add(name,body,observation,expected,why):
 source="function check(v){if(!v)throw new Error('class oracle');}\n"+textwrap.dedent(body).strip()+'\n'
 row={'id':name,'family':'static-accessors','kind':'semantic','source':source,'observation':observation,
      'expected':{'type':'string','value':expected},'timing':'after public execution checkpoint',
      'derivation':why,'modes':['sloppy','strict']}
 row['source_file']=put(D/'literals'/(name+'.js'),source.encode())
 row['observation_file']=put(D/'readbacks'/(name+'.js'),(observation+'\n').encode());new.append(row)
add('inherited_static_accessors_keep_receiver',r'''
var result=(function(){
 var sym=Symbol('tag'),token={},writes=0;
 class C {static get x(){return this.v;} static set x(v){writes++;this.v=v;}
   static get [sym](){return this;} static set [sym](v){this.saved=v;}}
 class D extends C {}
 C.x=7;D.x=8;D[sym]=token;
 var d=Object.getOwnPropertyDescriptor(C,'x'),s=Object.getOwnPropertyDescriptor(C,sym);
 check(C.x===7&&D.x===8&&writes===2&&D[sym]===D&&D.saved===token&&!Object.prototype.hasOwnProperty.call(C,'saved'));
 check(!d.enumerable&&d.configurable&&d.get.name==='get x'&&d.set.name==='set x');
 check(!s.enumerable&&s.configurable&&s.get.name==='get [tag]'&&s.set.name==='set [tag]');
 return 'static-receivers:2';
})();
''','result','static-receivers:2','Static getter/setter pairs are own non-enumerable accessors; inherited access keeps the derived constructor receiver, including Symbol keys.')
add('computed_static_species_creates_selected_promise',r'''
var trace='',token={},done=false;
class Q extends Promise {}
class P extends Promise {static get [Symbol.species](){trace+='G';return Q;}}
var p=new P(resolve=>resolve(token));
var q=p.then(v=>{check(v===token);trace+='R';done=true;return v;});
check(p instanceof P&&q instanceof Q&&q instanceof Promise&&!(q instanceof P));
''',"trace+'|'+done",'GR|true','A class static computed getter participates in existing Promise species lookup. The selected Q capability is genuinely branded; its fulfillment handler runs at the checkpoint.')
cases=oldcases+new
assert cases[:60]==oldcases and len(cases)==62 and len({r['id'] for r in cases})==62
for row in oldcases:
 assert bind(Path(row['source_file']['path']))==row['source_file']
 assert Path(row['source_file']['path']).read_text()==row['source']
payload=obj(D/'cases.json',cases)
counts={k:sum(r['kind']==k for r in cases) for k in ['semantic','early-error','unsupported']}
roster=obj(D/'roster.json',{'cases':[{k:r[k] for k in ['id','family','kind','modes']} for r in cases],
 'counts':counts,'source_literals':62,'planned_mode_attempts':124,
 'qualification':'Literal rows, not Rust group counts. The two additions cover selected static accessor semantics; execution interfaces and numeric fees remain unselected.'})
contract=obj(D/'contract.json',{'status':'frozen published-base public literal composition; no Rust payload',
 'base':BASE,'original_contract':bind(OLD/'source-ready.json'),'published_refresh':refresh,
 'selected_scope':bind(F/'root/selection-1.json'),'cases':payload,'roster':roster,
 'composition':'Original60 JSON objects and all source/readback/setup bytes exact, then two independent static-accessor semantic rows.',
 'addition_reason':'The first roster covered instance accessors and static methods but lacked a direct static accessor pair and class static computed species getter.',
 'preserved_boundaries':'No fields/private/static blocks/async-generator methods/super properties added. No producer code, execution, live edits, numeric budgets or Rust test authoring.',
 'outcomes':'Source-derived expectations only. Existing profile policies/baselines remain unchanged; future observed runtime outcomes are not frozen.'})
seal=obj(D/'source-ready.json',{'status':'ready for independent semantic peer and root selection',
 'base':BASE,'original_hold':bind(OLD/'source-ready.json'),'contract':contract,'cases':payload,'roster':roster,
 'published_refresh':refresh,'author':bind(D/'author-addendum.py'),'counts':counts,
 'source_literals':62,'planned_mode_attempts':124,'rust_payload_authored':False,'project_execution':False})
print(json.dumps(seal))
