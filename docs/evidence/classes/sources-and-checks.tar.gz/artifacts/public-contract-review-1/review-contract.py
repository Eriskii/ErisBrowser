from pathlib import Path
import json,hashlib,subprocess,collections
N=Path('/tmp/eris-class-runtime-plan-1');O=N/'public-contract-review-1';B='f3118ae5787c410648657f7c822efb7014201dd1'
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def verify(b):
 p=Path(b['path']);v=p.read_bytes();assert len(v)==b['bytes'] and sha(v)==b['sha256'],str(p)
def load(p):return json.loads(Path(p).read_text())
def put(name,x): (O/name).write_text(json.dumps(x,indent=2,ensure_ascii=False)+'\n')
s=load(N/'public-contract-2/source-ready.json')
for name in ['original_hold','contract','cases','roster','published_refresh','author']:verify(s[name])
c=load(s['cases']['path']);old=load(N/'public-contract-1/cases.json');assert c[:60]==old and len(old)==60 and len(c)==62
roster=load(s['roster']['path']);assert roster['cases']==[{k:x[k] for k in ['id','family','kind','modes']} for x in c]
counts=collections.Counter(x['kind'] for x in c);assert counts=={'semantic':26,'early-error':26,'unsupported':10}
assert len({x['id'] for x in c})==62
refs=[]
for x in c:
 assert x['modes']==['sloppy','strict']
 for k,field,newline in [('source_file','source',False),('observation_file','observation',True),('setup_file','setup',False)]:
  if k in x:
   verify(x[k]);data=Path(x[k]['path']).read_text();assert data==x[field]+('\n' if newline else ''),(x['id'],k)
   refs.append(x[k])
 assert x['source_file']['sha256']==sha(x['source'].encode())
assert len(refs)==140
semantic={
'lexical_names_and_tdz':'THKI','global_and_block_lexical':'lexical','constructor_and_method_metadata':'metadata:2',
'public_keys_accessors_and_name_disambiguation':'members','computed_key_order_and_abrupt_identity':'ACBDECFT',
'heritage_validation_order':'HPKNTGIV','intrinsic_parents_and_setter_bypass':'intrinsics:0',
'class_call_guard_precedes_parameters':'ATTTTDB','class_strictness_and_detached_receiver':'strict',
'base_return_and_alternate_newtarget':'base-and-newtarget','derived_return_and_this_states':'RRRRTBTB',
'repeated_super_and_retry_after_throw':'BBRXCX','dynamic_super_capture_before_arguments':'XBXAXT',
'lexical_arrow_super_and_escaped_owner':'RB4B8B8R','default_forwarding_without_array_iteration':'forward:0',
'extends_null_and_new_class_expression':'null:TypeError|object:7','computed_static_prototype_stops_at_runtime':'ABT',
'outer_this_and_newtarget_in_class_evaluation':'outer-context:4','promise_default_subclass_withresolvers_and_try':'SEQF',
'promise_explicit_super_executor_order':'CED|true','promise_combinators_inherited_statics':'1111111',
'promise_species_object_return_without_super':'GC|GCHR|true|true','class_is_callable_but_rejects_invocation':'true|true|0',
'aggregateerror_native_brand_through_default_super':'native-brand','inherited_static_accessors_keep_receiver':'static-receivers:2',
'computed_static_species_creates_selected_promise':'GR|true'}
errors={
'constructor-special-form':['duplicate_constructor','getter_constructor','setter_constructor','literal_static_prototype','quoted_static_prototype'],
'super-context':['base_super_call','method_super_call','static_super_call','nested_function_super_call'],
'parameter-grammar':['duplicate_constructor_parameters','duplicate_method_parameters','getter_arity','setter_no_argument','setter_two_arguments','setter_rest_argument'],
'strict-code':['strict_with','strict_delete_identifier','strict_class_binding'],
'declaration-position':['controlled_statement_class','labelled_class','anonymous_declaration'],
'lexical-conflicts':['lexical_collision','var_collision','parameter_collision','catch_collision','switch_collision']}
assert set(sum(errors.values(),[]))=={x['id'] for x in c if x['kind']=='early-error'}
unsupported={'public_field','static_field','private_field','private_method','static_block','generator_method','async_method','async_generator_method','super_named_property','super_computed_assignment'}
assert unsupported=={x['id'] for x in c if x['kind']=='unsupported'}
for x in c:
 if x['kind']=='semantic': assert x['expected']=={'type':'string','value':semantic[x['id']]}
 elif x['kind']=='early-error':
  assert x['setup']=='var touched=0;\n' and x['source'].startswith('touched=1;\n')
  assert x['expected_error']=='SyntaxError' and x['observation']=='touched' and x['expected']=={'type':'number','value':0}
 else: assert x['expected_error']=='Unsupported' and x['observation'] is None and 'setup' not in x
refresh=load(s['published_refresh']['path']);assert refresh['base']==B
for row in refresh['runtime_sources']:
 b=subprocess.check_output(['git','show',B+':'+row['relative_path']],cwd=R)
 assert len(b)==row['bytes'] and sha(b)==row['sha256'],row['relative_path']
verify(refresh['selection']);verify(refresh['root_readiness_refresh'])
checks={'status':'clear','case_count':62,'planned_modes':124,'counts':dict(counts),'exact_original_prefix':60,'added_rows':[x['id'] for x in c[60:]],'literal_readback_setup_bindings':140,'all_binding_hashes_exact':True,'all_strings_match_json':True,'roster_projection_exact':True,'published_runtime_hash_joins':len(refresh['runtime_sources']),'semantic_expectations_independently_reconciled':semantic,'early_error_categories':errors,'unsupported_ids':sorted(unsupported),'no_project_imports_or_execution':True,'no_implementation_inspection':True}
put('checks.json',checks)
review={
'status':'clear','reviewer':'/root/layout','task':'Independent source-only public class literal semantics, early-error and selected Unsupported review.',
'base':B,'hold':bind(N/'public-contract-2/source-ready.json'),'original_hold':s['original_hold'],
'inputs':{k:s[k] for k in ['contract','cases','roster','published_refresh']},'selection':bind(N/'root/selection-1.json'),'checks':bind(O/'checks.json'),
'counts':{'semantic_sources':26,'early_error_sources':26,'unsupported_sources':10,'source_literals':62,'planned_sloppy_strict_attempts':124,'executed_attempts':0},
'findings':[],
'reconciled_observations':[
'THKI separates outer mutable declaration from inner immutable class binding and both heritage/key TDZ failures; inferred names precede static name/length replacement.',
'ACBDECFT includes conversion after A and E, then exact-token throw at F; HPKNTGIV separates constructor validation, prototype getter and invalid prototype paths.',
'ATTTTDB pays the first call argument effect A, rejects all four Call routes before constructor defaults/body, then admits D/B on construction.',
'RRRRTBTB distinguishes uninitialized reads/completion, primitive return and successful superclass effects; BBRXCX includes the second superclass call before duplicate-this failure and retry after an ordinary throw.',
'XBXAXT captures the dynamic parent before each X argument effect; RB4B8B8R retains active constructor/this/NewTarget through an escaped arrow, including the second late superclass effect before ReferenceError.',
'forward:0 binds default forwarding without array iteration while the separate explicit rest/spread call uses its normal path. extends-null and computed-static-prototype rows distinguish runtime refusal from early errors.',
'SEQF, CED|true and seven completion bits use handled Promise outcomes and post-checkpoint readbacks. Species return GC|GCHR|true|true preserves the arbitrary capability object and undefined callback receiver.',
'The two appended accessor rows preserve inherited constructor receivers and Symbol accessor names; the selected species getter runs G synchronously and R at the reaction checkpoint.',
'All 26 SyntaxError rows compile as whole source before touched=1, with setup/readback as separate submissions in the same fresh mode realm. All 10 Unsupported rows are valid forms expressly deferred by selection.'
],
'primary_sources':[
{'url':'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-class-definitions','sections':'15.7.1, 15.7.13–16; 15.4','checked':'2026-10-15','use':'Class early errors, strictness, member/name order, default construction and declaration initialization.'},
{'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword','sections':'13.3.7','checked':'2026-10-15','use':'Superclass capture, argument evaluation and derived this binding.'},
{'url':'https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ecmascript-function-objects-call-thisargument-argumentslist','sections':'10.2.1, 10.2.2','checked':'2026-10-15','use':'Class Call guard and base/derived return completion.'},
{'url':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.try','sections':'27.5.4.7.1, 27.5.4.8–10, 27.5.5.4','checked':'2026-10-15','use':'Current callback-first Promise.try followed by PromiseResolve; same-constructor promise identity, capabilities and species.'}
],
'qualifications':[
'This clears the frozen literal expectations, not a future Rust conversion, implementation or measured outcome. It does not claim exhaustive class grammar, resource or terminal coverage.',
'Unsupported is a selected implementation boundary, not a normative ECMAScript exception. The deferred rows do not assert a sticky-runtime readback after Unsupported.',
'Fresh Runtime per mode and public checkpoint timing are part of the frozen contract. Promise handlers must remain attached as written; no host unhandled-rejection policy change is proposed.',
'Existing profile admission policies and baseline bytes remain unchanged. Newly admitted untagged class sources may change observed outcomes and must be reported honestly.',
'Hash-only read-only Git checks join 27 published runtime inputs; no candidate implementation was read or executed.'
],
'method':'Manual derivation of every source and expectation, official current primary-spec reads, stdlib JSON/hash comparisons and read-only Git blob hashing. No JavaScript/Rust/project execution, project imports, builds, tests, live edits or literal edits.'}
put('review.json',review)
print(json.dumps(bind(O/'review.json')))
