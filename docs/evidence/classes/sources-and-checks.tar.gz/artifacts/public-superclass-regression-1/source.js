function check(v){if(!v)throw new Error('class superclass oracle');}
var result=(function(){
 var trace='',called=0;
 function Base(){trace+='B';called++;}
 var target=()=>{trace+='X';called++;return {};};
 var bad=target.bind(null,7);
 class Explicit extends Base {constructor(){
  trace+='E';super((trace+='A',Object.setPrototypeOf(Explicit,Base),1));trace+='L';
 }}
 class Default extends Base {}
 Object.setPrototypeOf(Explicit,bad);
 try{new Explicit();throw 'missing explicit TypeError';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try{new Default((trace+='D',Object.setPrototypeOf(Default,bad),2));throw 'missing default TypeError';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 check(called===0&&Object.getPrototypeOf(Explicit)===Base&&Object.getPrototypeOf(Default)===bad);
 return trace;
})();
