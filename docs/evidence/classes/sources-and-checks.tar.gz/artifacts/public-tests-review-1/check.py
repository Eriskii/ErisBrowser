from pathlib import Path
import json,hashlib,re,subprocess
N=Path('/tmp/eris-class-runtime-plan-1');O=N/'public-tests-review-1';B='f3118ae5787c410648657f7c822efb7014201dd1';R='/home/eriskii/Documents/Programming/Projects/ErisBrowser'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def verify(v):assert bind(v['path'])==v,v['path']
s=json.loads((N/'public-tests-1/source-ready.json').read_text());c=json.loads((N/'public-contract-2/cases.json').read_text());roster=json.loads((N/'public-tests-1/roster.json').read_text())['tests']
for k in ['literal_contract','design','registration','registration_lineage','roster','author']:verify(s[k])
verify(s['files'][0]['raw']);raw=Path(s['files'][0]['raw']['path']).read_text();prefix,body=raw.split('#[test]',1);body='#[test]'+body
expected=[];strings=0
for row,r in zip(c,roster,strict=True):
 kind=row['kind'];helper={'semantic':'observe','early-error':'early_error','unsupported':'unsupported'}[kind];name='class_public_'+row['id'];assert r['test_name']==name and r['case_id']==row['id'] and r['helper']==helper
 fields=['source','observation'] if kind=='semantic' else ['setup','source','observation'] if kind=='early-error' else ['source'];args=['        '+json.dumps(row['id'])+',']
 for key in fields:
  text=row[key]+ ('\n' if key=='observation' else '');args.append('        r###"'+text+'"###,');strings+=1
 if kind!='unsupported':
  value='Value::String('+json.dumps(row['expected']['value'])+'.into())' if kind=='semantic' else 'Value::Number(0.0)';args.append('        '+value+',');assert r['expected']==row['expected']
 expected.append('#[test]\nfn '+name+'() {\n    '+helper+'(\n'+'\n'.join(args)+'\n    );\n}\n')
assert body=='\n'.join(expected)+'\n';assert strings==140
assert re.findall(r'^fn (\w+)\(',prefix,re.M)==['execute_mode','observe','early_error','unsupported']
reg=(N/'public-tests-1/registration-append.txt').read_text();assert reg=='#[cfg(test)] mod class_semantics_tests;\n'
parent=subprocess.check_output(['git','show',B+':src/script.rs'],cwd=R);lineage=json.loads((N/'public-tests-1/registration-lineage.json').read_text());assert sha(parent)==lineage['parent_script']['sha256'];assert b'mod class_semantics_tests;' not in parent
assert subprocess.run(['git','cat-file','-e',B+':src/script/class_semantics_tests.rs'],cwd=R,capture_output=True).returncode!=0
out={'status':'clear','hold':bind(N/'public-tests-1/source-ready.json'),'literal_peer':bind(N/'public-contract-review-1/review.json'),'raw':s['files'][0]['raw'],'findings':[],'checks':{'exact_generated_test_bodies':62,'exact_literal_strings':140,'planned_modes':124,'maximum_public_api_calls':280,'complete_module_helper_prefix_manually_reviewed':True,'helper_prefix_sha256':sha(prefix.encode()),'roster_binding':s['roster'],'registration':s['registration'],'published_parent_absence_and_registration_join':True},'helper_review':['Each mode starts a fresh Runtime::try_new and Document; no private field access, budget reset or hidden executor.','Semantic helper requires successful source execution before its checkpoint readback and exact Value comparison.','Early-error helper performs separate setup then asserts intrinsic SyntaxError and is_parse_error before untouched readback.','Unsupported helper stops after is_unsupported without a later readback.'],'orchestration_note':'The initial standalone transcription checker assumed a different final blank line and multiline registration spelling. This corrected checker verifies the actual exact serialization; no payload or expectation changed and no project code ran.','qualification':'Source-only conversion clearance. No implementation inspected, project imported/executed, build/test run or parent/candidate outcome inferred. Root-reported parent execution is outside this receipt.'}
(O/'review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(bind(O/'review.json')))
