"""Stdlib-only source binding and design authoring; never imports project code."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/tmp/eris-class-runtime-plan-1')
OUT = ROOT / 'constructor-design-1'
WORK = ROOT / 'worktree'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}

def write(name, data):
    path = OUT / name
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
    return bind(path)

paths = {
 'src/script.rs': ['struct Environment {', 'struct Function {', 'fn environment(', 'fn resolve_binding_in(', 'fn binding_value(', 'fn validate_lexical(', 'fn instantiate_lexical(', 'fn function_value(', 'fn charge_function_code_copy(', 'fn call_with_new_target(', 'fn prototype_of('],
 'src/script/code.rs': ['pub(super) struct Function {', 'pub(super) struct Unit {', 'pub fn anonymous(', 'pub(super) enum Expr', 'pub(super) enum Stmt'],
 'src/script/code/records.rs': ['pub fn reserve(', 'pub fn append(', 'pub fn singleton('],
 'src/script/construction.rs': ['pub(super) fn new_target(', 'pub(super) fn is_constructor(', 'pub(super) fn constructor_prototype(', 'pub(super) fn construct(', 'pub(super) fn construct_with_target(', 'fn construct_inner('],
 'src/script/machine.rs': ['pub(super) enum Frame {', 'enum Phase {', 'fn enter_frame(', 'pub(super) fn invoke_preentered(', 'fn drive(', 'fn object_entry(', 'fn arguments_next(', 'fn spread_arguments_next('],
 'src/script/machine/calls.rs': ['pub(in crate::script) struct Frame {', 'struct Activation {', 'fn setup(', 'fn forward(', 'fn parameters(', 'fn body('],
 'src/script/machine/statements.rs': ['pub(in crate::script) enum ListOwner {', 'pub(super) fn step(', 'fn declaration_value(', 'fn declaration_next('],
 'src/script/machine/call_spread.rs': ['pub(super) fn prepay_entry(', 'pub(super) fn prepay_item(', 'pub(super) fn append_received(', 'pub(super) fn spread_received('],
 'src/script/parser.rs': ['struct Parser', 'fn check_scope(', 'fn check_parameter_lexicals('],
 'src/script/parser/driver.rs': ['enum Kind {', 'enum Transition {', 'fn reserve('],
 'src/script/parser/driver/functions.rs': ['struct State', 'struct Context', 'fn enter(', 'fn finish('],
 'src/script/parser/driver/expressions.rs': [],
 'src/script/parser/driver/statements.rs': [],
 'src/script/dom_prototypes.rs': ['pub(super) fn dom_proto_object(', 'pub(super) fn dom_proto_property('],
 'src/script/promises.rs': ['pub(super) struct GrowthPlan {', 'pub(super) fn growth_plan'],
 'src/script/promises/factories.rs': ['pub(in crate::script) fn object_slot_plan(', 'pub(super) fn new_promise_capability_result('],
 'src/script/promises/semantics.rs': ['pub(in crate::script) fn promise_construct('],
 'src/script/aggregate_error.rs': ['pub(super) fn intrinsic_aggregate_error_from_list('],
 'src/script/microtasks.rs': ['fn observe_microtask_failure', 'fn with_author_entry', 'fn microtask_checkpoint'],
 'src/script/code/call_spread_layout_tests.rs': [],
 'src/script/parser/driver/call_spread_layout_tests.rs': [],
 'src/script/promises/layout_tests.rs': [],
}
bindings = []
for relative, needles in paths.items():
    disk = (WORK / relative).read_bytes()
    published = subprocess.check_output(['git', 'show', f'{BASE}:{relative}'], cwd=WORK)
    assert disk == published, relative
    lines = disk.decode().splitlines()
    anchors = []
    for needle in needles:
        hits = [i + 1 for i, line in enumerate(lines) if needle in line]
        # Some parent declarations have visibility/multiline prefixes. Preserve
        # missing labels as explicit audit notes rather than invented locations.
        anchors.append({'text': needle, 'lines': hits})
    bindings.append({'relative': relative, 'bytes': len(disk), 'sha256': digest(disk),
                     'git_blob_sha1': hashlib.sha1(b'blob ' + str(len(disk)).encode() + b'\0' + disk).hexdigest(),
                     'published_join': True, 'anchors': anchors})
source_receipt = write('source-bindings.json', {'base': BASE, 'bindings': bindings,
 'method': 'Read-only git show versus current published worktree bytes; no project import, compilation or execution.',
 'inventory_qualification': 'This is a selected 22-file runtime/design support set, not a complete project graph.'})

interfaces = '''DESIGN ONLY — these are proposed interfaces and state shapes, not production code.

code::ClassKind = ExplicitBase | ExplicitDerived | DefaultBase | DefaultDerived
code::Function.class_kind: Option<ClassKind> // None for every old function/method.
code::Class { name: Option<String>, heritage: Option<ExprId>, constructor: FunctionId,
              elements: Vec<ClassElement> }
code::ClassElement { name: PropertyName, function: FunctionId, kind: Method|Getter|Setter,
                     is_static: bool }
code::Unit.classes: Records<Class>; Expr::Class(ClassId); Stmt::Class(ClassId).
  A declaration's Class.name is Some(source name); do not duplicate the owned name.
Expr::SuperCall(Vec<ExprId>); Expr::SuperCallSpread(Vec<ExprId>) // existing spread markers.
Default constructors receive real empty Function records with the appropriate tag.

ThisBinding = Lexical | Uninitialized | Initialized(Value)
Environment.this_binding: ThisBinding // replaces Option<Value>.
Environment.active_constructor: Option<usize> // stable runtime.functions ID, not a Value clone.
Environment.new_target_binding: Option<Value> // existing field retained.
Runtime Function, BoundFunction, Value and ScriptObject fields remain unchanged.

Runtime::this_environment(env: usize) -> Result<usize>
Runtime::class_bind_this(owner: usize, object: Value) -> Result<Value>
Runtime::class_super_target(env: usize) -> Result<(usize, Value, Value)>
  Returns owner ID, original NewTarget handle and captured current superclass handle.
Runtime::construct_class(id: usize, arguments: Vec<Value>, new_target: Value,
                         doc: &mut Document) -> Result<Value>
  Called only by the selected class arm of existing construct_inner.
machine::invoke_class_preentered(runtime, id, arguments, new_target, doc) -> Result<Value>
calls::Frame::class_constructor(id, arguments, new_target, preentered)
calls::Phase::ClassStart { id, arguments }
calls::Phase::ClassBody { environment: usize, kind: ClassKind }
  Existing Frame::new, Phase::Body and ordinary/native dispatch remain their old route.

machine::Frame::Class(classes::Frame)
classes::Frame {
  unit: Rc<code::Unit>, class_id: code::ClassId, outer_environment: usize,
  phase: classes::Phase
}
classes::Phase =
  Start { inferred_name: Option<PropertyKey> }
  | Heritage { class_environment: usize, inferred_name: Option<PropertyKey> }
  | ComputedKey { class_environment: usize, constructor: usize,
                  prototype: usize, element_index: usize }
  | Vacant
  Constructor and prototype are stable arena IDs; materialize Value handles only at
  existing helper boundaries with explicit retention/publication accounting. No
  duplicated owned Class/element Vec, ambient current-class pointer or runtime stack
  slot is kept. Literal-key iteration is a charged loop; each computed key suspends
  in ComputedKey. Heritage output is validated before constructor/prototype allocation.
classes::Frame::new(unit, class_id, outer_environment, inferred_name: Option<PropertyKey>)
classes::step(runtime, frame, child_output, doc) -> Result<Option<Output>>
  Class frame does not own an additional logical call. Its expression parent retains
  the existing expression weight; statement declaration has an explicit initialization
  continuation. Heritage and computed names are scheduled Expression children.
ExprPhase::NamedClassStart(PropertyKey) // alternative to enlarging every ExprFrame.
  Only direct anonymous Class expressions accept this hint; ordinary function inference
  retains its existing code and callbacks. No hint propagates through comma/conditional
  expressions merely because their resulting Value happens to be a class.
ExprPhase::SuperArguments { owner: usize, new_target: Value, superclass: Value,
                           index: usize, arguments: Vec<Value> }
ExprPhase::SuperSpreadArguments { owner: usize, new_target: Value, superclass: Value,
                                 index: usize, arguments: call_spread::Arguments }
  Super does not need an after-Construct continuation in this proposal: the existing
  guarded bridge returns the parent result synchronously to the resumed expression
  step, which performs the already-admitted bind and returns its Value. A nested drive
  preserves the outer frame suffix and counters using its existing saved base.
statements::Phase::ClassInitialize { binding_environment: usize }
  Statement ID supplies the declaration name; successful class child output initializes
  the existing outer binding, then returns Flow::Normal(None). Ordinary throw propagates.

Runtime::class_constructor_value(code, class_env, constructor_parent, prototype,
                                  display_name) -> Result<Value>
  Dedicated new factory; never create/discard an ordinary function's extra prototype.
Runtime::class_method_value(code, class_env, key, accessor_prefix) -> Result<Value>
  Existing strict/nonconstructible function metadata path may be reused unchanged if its
  complete charges suffice; publication uses ordinary descriptor semantics.
Runtime::class_define_element(target, key, function, kind) -> Result<()>
  Uses define_own_key, never vacant-only dom_proto_property for author class elements.

All names and enum layouts are proposals awaiting root selection. No numeric fee is set.
'''
(OUT / 'interfaces.txt').write_text(interfaces)

specs = [
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-runtime-semantics-classdefinitionevaluation',
  'sections':['15.7.13','15.7.14','15.7.15','15.7.16'],
  'checked':'Official ECMAScript 2027 page read during this source-only design; inherited readiness also binds the same algorithms.',
  'relevance':'Class environment, heritage, constructor/prototype creation, method order, name initialization and declaration completion.'},
 {'url':'https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ecmascript-function-objects-construct-argumentslist-newtarget',
  'sections':['10.2.1','10.2.2','10.2.5','10.2.6','10.2.7','10.2.8'],
  'checked':'Official ECMAScript 2027 page read during this design.',
  'relevance':'Class Call rejection, construction completion, method/constructor descriptors.'},
 {'url':'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword-runtime-semantics-evaluation',
  'sections':['13.3.7.1','13.3.7.2','13.3.8.1'],
  'checked':'Official ECMAScript 2027 page read during this design.',
  'relevance':'Capture superclass before arguments; construct before duplicate-this check; spread remains existing iterator semantics.'},
 {'url':'https://tc39.es/ecma262/multipage/executable-code-and-execution-contexts.html#sec-function-environment-records',
  'sections':['9.1.1.3','9.1.1.3.1','9.1.1.3.2','9.1.1.3.3','9.1.2.4'],
  'checked':'Official ECMAScript 2027 page read during this design.',
  'relevance':'Three this states, retained function identity and NewTarget, lexical arrows.'},
]

design = {
 'status':'Source-only concrete proposal; public scope is selected, but these representations, interface names and new fees are not selected. No production authored or project execution performed.',
 'base':BASE,
 'inputs':[bind(ROOT/'root/selection-1.json'), bind(ROOT/'root/readiness-base-refresh.json'), bind(ROOT/'source-parent.json'), bind(ROOT/'readiness-1/readiness.json'), bind(ROOT/'parser-design-1/source-ready.json'), bind(OUT/'primary-tool-readback.txt'), source_receipt],
 'spec_sources':specs,
 'scope':'Selected public class declarations/expressions, ordinary/accessor instance/static methods, explicit/default base/derived constructors and lexical super() only. No fields, private elements, static blocks, async/generator methods, super properties, Proxy, realm or host expansion.',
 'source_findings':[
  {'source':'src/script/machine/calls.rs:Phase::Body/body','finding':'Body currently discards the activation environment and maps normal completion to undefined. Derived construction requires a distinct continuation retaining the parameter/this environment ID, even when body declarations use a child environment.'},
  {'source':'src/script.rs:Environment/resolve_binding_in','finding':'None currently means lexical inheritance. It cannot also represent an owned uninitialized this; an explicit state must stop lookup and throw before super rather than escape to a parent receiver.'},
  {'source':'src/script/construction.rs:construct_inner','finding':'The old ordinary user-function path allocates this before Call and replaces every primitive return with it. Applying that path to derived classes would violate both missing-super and primitive-return rules.'},
  {'source':'src/script.rs:function_value','finding':'Ordinary constructor creation eagerly creates its own mutable prototype. A class factory must create the correct two linked bags directly, preserving its nonwritable own prototype and avoiding a discarded extra object.'},
  {'source':'src/script/dom_prototypes.rs:dom_proto_property','finding':'Vacant-only insertion rejects duplicates as ResourceLimit. Class author elements need ordinary DefineOwnProperty semantics for replacement, accessor merging and the static computed-prototype TypeError.'},
  {'source':'src/script/machine.rs:ObjectValue/AssignValue; calls.rs:Default','finding':'Existing inferred function naming after evaluation cannot simply be generalized to class Values: it would overwrite a static name method already installed during evaluation.'},
  {'source':'src/script/machine.rs:drive; construction.rs:construct_with_target','finding':'Existing new expressions use a guarded constructor bridge and nested drive; ordinary Calls use flat continuations. Preserve this bounded distinction rather than silently flattening old constructors or granting more call/stack budget.'},
  {'source':'src/script/promises/semantics.rs:promise_construct','finding':'Native Promise constructs its own branded object with the passed NewTarget, including executor validation before prototype Get. A derived class must adopt that returned object, not wrap or replace it with a generic object.'},
 ],
 'representation':{
  'code':'Use the four ClassKind tags on code::Function proposed in interfaces.txt. Keep old arrow/self_name/constructable/strict fields and old values. Class constructors are strict, constructable, non-arrow, and do not use the ordinary self_name environment branch. Methods/accessors are strict, nonconstructible, class_kind=None. Default constructors are tagged empty code records, not parsed synthetic bodies.',
  'runtime_function':'Keep code/environment/properties/bound fields exactly. Class behavior comes from immutable shared code; the live internal constructor prototype remains in its existing property bag. No global constructor-name lookup or identity inferred from the public constructor property.',
  'environment':'Replace this Option with explicit Lexical/Uninitialized/Initialized(Value); add active_constructor Option<usize>. Global environment is Initialized(Window), global lexical/block/class-name/body-child/arrow environments are Lexical; normal calls initialize their own receiver and retain Some(undefined) NewTarget as before. Explicit constructor activation owns its receiver state, original NewTarget and stable class function ID.',
  'escaped_arrows':'Functions/environments already live in runtime-owned vectors and closures capture the environment index. Do not clear constructor this/NewTarget/active ID on return, throw or object-return-without-super. An escaped arrow still resolves that owner; subsequent super uses the live class function prototype and the original NewTarget. A second successful parent construction then fails BindThisValue while preserving the first receiver.',
  'home_object':'No HomeObject field is proposed in this slice: super property references are rejected by the parser, direct super uses active constructor identity, and eval is unsupported. This is a scoped representation decision, not support for method super property semantics.',
  'machine':'Dedicated class factory frame plus class-only call phases. Do not add a second logical call for class-factory frames. Super argument continuations hold scalar owner, captured superclass, original NewTarget, index and existing argument buffer. All frames remain flat and bounded by MAX_HEAP/size_of<Frame>.',
 },
 'class_evaluation_order':[
  'Before executing a class declaration, ordinary lexical instantiation creates an uninitialized mutable outer binding. Extend lexical conflict, switch/block/catch/function parameter conflict and global restricted-binding checks; do not hoist class execution as a function declaration.',
  'Class evaluation admits its continuation/owners, creates a new lexical class environment, and creates a separate strict immutable uninitialized inner binding for a source name. Anonymous inferred names do not create an inner lexical binding. Class environment inherits outer this/NewTarget/super context; strict parsing/evaluation does not invent a function context.',
  'Evaluate heritage in class environment. If absent use saved Object.prototype and saved Function.prototype. If null choose null instance prototype parent and saved Function.prototype constructor parent. Otherwise perform IsConstructor before the observable prototype Get; accept object or null prototype only. Preserve thrown identity and stop later keys.',
  'Allocate the class prototype bag, then a class constructor metadata bag/function record whose internal prototype is the captured constructor parent. Define length and name, the nonwritable/nonenumerable/nonconfigurable own prototype, and writable/nonenumerable/configurable prototype.constructor. Do not invoke inherited setters.',
  'Process nonconstructor elements in source order. Evaluate a computed key in class environment, perform ToPropertyKey once, create the strict nonconstructible method/accessor, set its string/Symbol name with get/set prefix as needed, then define on constructor or prototype with enumerable=false/configurable=true; methods writable=true. Getter/setter definition omits the other accessor field so existing counterpart survives.',
  'Duplicate ordinary keys follow ordinary property replacement, including computed instance constructor. Literal static prototype is an early error; computed static prototype reaches ordinary descriptor rejection. Static name/length overwrite the initial configurable metadata and are never subsequently replaced by inferred naming.',
  'Only after all selected elements finish initialize the inner class binding to the constructor. A declaration then initializes its already-created outer binding and completes with empty completion. Expression returns the constructor. On ordinary failure prior author effects remain, leaked closures keep the uninitialized inner environment, and the outer declaration binding stays TDZ.',
 ],
 'name_inference':{
  'transport':'Propose a NamedClassStart(PropertyKey) expression phase or equivalent class-only constructor argument. Avoid a new field on every expression frame. Selection must measure the union layout before claiming no size change.',
  'sites':['var/let/const direct anonymous-class initializer','simple identifier assignment direct anonymous-class RHS','taken logical identifier assignment direct anonymous-class RHS','parameter default direct anonymous-class initializer','object data property direct anonymous-class value using its already-computed key'],
  'exclusions':'Do not infer through comma/conditional results or arbitrary Value identity. Do not create an inner name binding from an inferred name. Named source class uses its source name regardless of hint. Preserve every old anonymous-function inference path/tariff; existing Unit::anonymous remains function-specific or callers split explicitly.',
  'timing':'Hint is supplied before heritage and method evaluation, used for initial name publication before static elements. It does not require additional author key conversion: object property hint is the already-canonical PropertyKey.'
 },
 'call_and_construct':{
  'ordinary_call':'After ordinary call argument evaluation and existing invocation admission, reject an unbound class constructor with TypeError before receiver coercion, parameter defaults, arguments object or body. Bound Call follows its old forwarding route and eventually reaches that guard. IsCallable remains true for a class Value; callback validation must not be rewritten to classify it as noncallable.',
  'dispatch':'Add class arm after existing bound-constructor arm and before ordinary constructable Function arm. Existing construct_with_target retains its four stack units; construct_class owns the same tick/MAX_CALLS/four-stack entry shape as call_with_new_target, then invokes the class-only machine entry. Cleanup restores counters on every result. Native and ordinary constructor branches stay behaviorally and fee-equivalent.',
  'explicit_base':'Get NewTarget.prototype using existing constructor_prototype with saved Object fallback and create this before any parameter initializer. Initialize this environment and original NewTarget, then use strict parameter/default/rest/body scheduling. Object return wins; any primitive or undefined/fallthrough returns the retained initialized receiver.',
  'explicit_derived':'Allocate no generic instance and do not read NewTarget.prototype before super. Create owned Uninitialized this and original NewTarget before parameters, permitting lexical-arrow/direct super in selected default contexts. After body/finalizers, object return wins even without super; a non-undefined primitive throws TypeError; undefined/fallthrough obtains the initialized this or throws ReferenceError.',
  'default_base':'Tagged branch creates an ordinary instance from original NewTarget and saved Object fallback. No synthetic parameters, body, rest array or arguments object. Its function length is zero.',
  'default_derived':'Tagged branch reads the live class constructor internal prototype at construction time, validates it, and moves the incoming argument Vec directly to Construct with unchanged original NewTarget. No array/rest/spread/iterator operation. Extends-null default initially targets Function.prototype and fails as nonconstructor; mutating the class constructor prototype can change later parent construction.',
  'bound_and_alternate':'Keep existing bound argument order, 65536 bound, and NewTarget substitution only when newTarget equals the bound wrapper. Capture the actual unbound class function ID for active_constructor; Reflect.construct target/NewTarget validation remains existing. Native Promise receives original NewTarget and returns its own branded object.',
  'completion':'ClassBody carries the original activation environment ID, not a frame index or the optional parameter-expression body child. No GetThis occurs on a thrown body completion or object return. Normal body completion is treated as undefined. Returned object/receiver ownership is released or moved exactly once; environment-owned receiver remains for escaped closures.',
 },
 'super_sequence':[
  'Find the nearest nonlexical this owner; do not require this to be initialized. Validate its retained class-function ID/original NewTarget as internal invariants. Prepay owned capture/continuation cleanup before cloning NewTarget and the current class constructor internal prototype. None internal prototype represents null, never a saved fallback.',
  'Capture the superclass before evaluating any argument. Evaluate ordinary arguments left-to-right, or reuse the existing call_spread Arguments storage/receipt/iterator helpers unchanged. Argument effects may mutate the class constructor prototype but cannot replace this captured parent for the current super call.',
  'Only after argument evaluation test IsConstructor on the captured value. Even a null/nonconstructor parent permits earlier argument effects before TypeError. Invoke existing construct_with_target with the original NewTarget, preserving native Promise/other constructor behavior.',
  'After successful construction, perform BindThisValue. Do not check for already-initialized this before constructing the parent. If already initialized, reject with ReferenceError after all second-parent effects; if that parent throws first, propagate that throw instead.',
  'On first binding, move the returned object into Environment.this_binding and return one explicitly paid handle copy as the super expression result. Any final admission needed for this ownership transfer must be prepaid before parent construction; do not insert a new fallible quota debit between the final initialized-state check and publication.',
  'No field/private initializer step exists in this selected slice. An escaped arrow can invoke this same sequence after constructor return; a default-derived constructor has no escapable synthetic activation.'
 ],
 'ownership_stages':[
  {'stage':'class-entry','incoming':'borrowed Unit/ClassId and outer environment; optional already-owned name key supplied by parent','admission':'fixed control/cleanup roles before new retains; class frame capacity before scheduling author heritage','owners':['Unit Rc handle','optional name key','heritage result while validating','constructor-parent handle','prototype-parent handle'],'refusal':'Inherited input ownership must already be releasable at first debit. No author heritage/key executes if entry/frame admission fails.'},
  {'stage':'class-environment','incoming':'outer environment ID and optional borrowed source-name bytes','admission':'typed Environment slot/growth plus existing binding name/map storage; explicit state-field delta','owners':['new environment row','owned inner binding name if present'],'refusal':'No inner binding is initialized; any reserved capacity/charged bytes stay charged. Never refund or truncate published environments retained by escaped closures.'},
  {'stage':'heritage-validation','incoming':'child output Value','admission':'capture/lookup/classification control before owned copy and before author prototype getter','owners':['heritage Value','canonical prototype key if allocated','Get result'],'refusal':'Preserve exact ordinary thrown Value; no class constructor/object or later key is published yet. Recompute later allocation plans after the getter.'},
  {'stage':'constructor-factory','incoming':'borrowed FunctionRef plus class-env ID, owned constructor/prototype parent and name','admission':'new fixed orchestration envelope; original immutable-code metadata allowance if reused; typed object/function slot plans and fallible reserves before publication; text/property costs','owners':['class prototype bag token','constructor metadata bag token','FunctionRef Rc','display name','length/name/prototype/constructor keys','constructor back-reference handle'],'refusal':'No discarded ordinary prototype and no public global replacement. Already appended inert rows remain charged; unpublished locals have prepaid release. All old IDs retain append-only identity.'},
  {'stage':'class-element','incoming':'element ID and retained class/prototype tokens','admission':'per-element control/cleanup before computed child; key conversion via existing helper; method metadata/slot/name charges; ordinary descriptor definition cost','owners':['computed key input','PropertyKey','method Function handle','optional descriptor get/set value'],'refusal':'Earlier element definitions and key effects remain; no later element evaluation. Duplicate keys are semantic replacement, not resource error. No cached collection capacity plan spans author key conversion.'},
  {'stage':'name-publication','incoming':'fully initialized constructor plus retained class-env and outer declaration binding','admission':'any necessary final clone/lookup/release paid before binding publication','owners':['constructor return handle','inner binding handle','optional outer binding handle'],'refusal':'Do not publish the outer binding if class evaluation failed. Publication after admission contains no author callback and no intervening allocation.'},
  {'stage':'class-invocation-entry','incoming':'owned existing Construct arguments Vec, original NewTarget, scalar function ID','admission':'existing guarded bridge plus new bounded class-dispatch/cleanup roles; producer ownership of original Vec remains inherited and is not refunded','owners':['arguments Vec and retained Values','NewTarget handle','optional base prototype/receiver'],'refusal':'First tick/call/stack failure releases existing inputs through their producer lifetime allowance. Any extra clone is paid before cloning. Raw helper failure alone does not imply sticky queue suspension.'},
  {'stage':'explicit-activation','incoming':'function code/environment and argument list; base this if any','admission':'preserve old parameter metadata/default/rest/arguments costs; add only typed environment representation and class-owned identity/this handoff costs','owners':['FunctionRef','arguments until parameters finish','NewTarget in environment','initialized base this or uninitialized state'],'refusal':'No defaults before direct-Call rejection or base prototype creation. Failure after a default preserves its effects; activation env persists if escaped. Ordinary helper tariff cannot be silently raised to fund class-only work.'},
  {'stage':'super-capture-and-arguments','incoming':'owner environment index','admission':'fixed owner/capture/check/cleanup roles; paid NewTarget and parent handle clones; existing plain/spread argument receipts and capacity costs','owners':['captured parent','original NewTarget','argument Vec','reached argument/iterator values'],'refusal':'No parent construction until all args completed and IsConstructor passed. Terminal spread failure does not invoke author return/close. Do not adopt unrelated spread limits for class method count.'},
  {'stage':'super-bind','incoming':'newly constructed object; owner retained across callbacks','admission':'result-release and environment-copy lifetime prepaid before Construct; scalar validation/conditional bind has no late quota debit','owners':['parent result','environment receiver','super result copy'],'refusal':'On duplicate bind release second object handle while keeping first this. No rollback of parent effects. Incoming object release must remain funded if publication is rejected.'},
  {'stage':'constructor-completion','incoming':'ClassBody environment ID and return/normal completion','admission':'return classification, possible receiver clone, and dropped primitive cleanup funded before body execution','owners':['completion Value','returned receiver copy when needed'],'refusal':'Ordinary derived TypeError/ReferenceError is produced only after body/finalizers. Terminal child error bypasses this semantic completion entirely.'},
  {'stage':'default-forward','incoming':'class ID, original NewTarget, existing owned argument Vec','admission':'bounded dispatch/live-prototype capture/validation and retained parent release; no per-element clone or synthetic array cost','owners':['captured parent','moved argument Vec','NewTarget moved to parent'],'refusal':'Use the existing constructor bridge, no new argument iteration or budget reset. Parent/native errors retain their classification.'},
 ],
 'resource_and_layout_obligations':{
  'numeric_status':'No new numeric work fee, observed size, success total or quota threshold is claimed. Stage role lists are ownership obligations, not chosen instruction counts. Root must select concrete formulas and freeze independent private controls before production.',
  'preserved_limits':{'source_bytes':262144,'tokens':32768,'prototype_depth':96,'calls':32,'stack_units':96,'author_steps':100000,'bootstrap_steps':1000000,'heap_bytes':8388608,'existing_call_spread_arguments':65536},
  'existing_formulas_to_reuse_exact':[
   'Records<T> append/page-directory/page tariffs and MAX_TOKENS bound; class records use actual Class width and source-ordered element vectors use actual element width.',
   'machine initial storage = 8*size_of<Frame>+32; subsequent whole-target capacity charges and relocation work remain existing. MAX_FRAMES remains MAX_HEAP/size_of<Frame>.',
   'Existing object_slot_plan(len, physical_capacity, count) includes count*size_of<ScriptObject> plus actual growth; use after author effects. A fresh class function slot also needs an explicit typed reservation plan; reusing growth_plan<Function> is a proposal with its old body unchanged, not a selected fee.',
   'Existing call_spread entry/item/attempt/append/growth and iterator helper bodies remain exact. No alternate spread implementation for super.',
   'Existing constructor_prototype, ordinary function metadata/activation, parameter/rest/arguments, bound-construction, native Promise and AggregateError helper tariffs retain their meanings. Class-only adapters pay any additional ownership separately.'
  ],
  'measure_actual_types':['ThisBinding','Environment','Option<usize>','code::ClassKind/Option<ClassKind>','code::Function','code::Class','code::ClassElement','Records<code::Class>','code::Unit','code::Expr','code::Stmt','parser class continuation/Kind/Transition/Output','machine class frame/call phases/ExprPhase/Frame','runtime Function','Value','ScriptObject','Runtime'],
  'unconditional_heap_sites':[
   'Both cfg variants of Runtime::uninitialized currently charge 4*sizeof<Option<Value>> for two environments. Replace only the this/active-ID representation contribution with a transparent two-environment delta; retain existing NewTarget contribution and base reserve.',
   'Runtime::environment currently charges 128+2*sizeof<Option<Value>> for every environment. Its selected formula must account for new ThisBinding plus active ID and the retained NewTarget; a size increase affects ordinary scripts too and cannot be hidden in class-only charges.',
   'initialize_intrinsics_before_typed_array charges sizeof<code::Unit>+sizeof<code::Function>+64 for the intrinsic empty function. New empty classes record table and code-kind layout must be included even with no class source.',
   'Parser Unit::finish and records page charges already use sizeof; actual shape changes propagate to every script. machine::initialize similarly propagates Frame changes to startup.',
   'Runtime Function/Value/ScriptObject/Runtime are intended unchanged in field shape. Verify their real layouts on supported feature/toolchain configurations rather than asserting padding or enum-niche outcomes.'
  ],
  'new_storage':'No class global constructor, intrinsic map entry, metadata reservation, Runtime arena or state field is needed. Class records live in compiled Unit, runtime functions/environments/objects in existing arenas. Source-order element storage is flat and charged. Existing bootstrap object/constructor IDs remain unchanged.',
  'cleanup':'No charged cleanup runs after terminal refusal. Prepay bounded local roles before callbacks/retains and dynamic per-element/argument lifetimes before their production; release by ordinary flat Rust drops. Do not recursively own syntax, refund cumulative charges, or remove environment/function/object rows that escaped. Native helper observers stay exact.',
  'guard_behavior':'A class constructor uses the existing four-stack construct guard plus class-only four-stack invocation admission and one logical-call entry. Nested native construction retains its existing bridge. No claim that a 32-class chain succeeds: the unchanged stack limit may bind first. Counter restoration must be checked for ordinary throw, resource and Unsupported.'
 },
 'terminal_contract':[
  'No class-specific work/heap/call/stack limit reset. Runtime execute/strict/event/host entry points keep their current author-budget and checkpoint policy.',
  'machine::drive immediately terminates resource/Unsupported before catch/finally/iterator-close handlers, truncates only frame suffix and restores saved call/depth/stack counters. Extend the new Class frame match arm without changing this rule.',
  'with_author_entry/execute and existing native helper observers remain the suspension boundaries. A direct private class helper returning ResourceLimit is not automatically sticky unless it deliberately calls an existing observer; private tests must identify which path was exercised.',
  'Natural public failure tests should use a queued sentinel and borrowed retained state after heap refusal. Do not execute another script or reset budgets merely to read a terminal state.',
  'Ordinary heritage/prototype/key/parameter/parent/body errors remain catchable, preserve thrown object identity, and run applicable author finally code. Derived return validation occurs after the constructor body finally. Unsupported features are parser refusals before author execution.'
 ],
 'independent_private_contract_outline':[
  'Measure real selected record/frame/environment layouts first, including cfg test262-host and ordinary builds; freeze typed formulas and selected fee cuts before producer implementation.',
  'Class record/page and element-vector cold/spare/growth refusals leave prior flat record IDs stable; extreme nesting terminates with existing parser limits and bounded destruction.',
  'Class factory work/heap refusal before heritage, after heritage getter, before first computed key, after a prior key/method, and before inner/outer binding publication. Verify no later callbacks, retained charges and correct TDZ/partial side effects.',
  'Direct Call rejection with poisoned defaults/body and bound wrappers; verify no parameters/arguments object/receiver coercion. Preserve old ordinary/nonconstructor method call paths.',
  'Base instance admission before defaults; derived no eager object allocation/NewTarget.prototype Get; object/undefined/primitive return matrix and exceptional completion with initialized/uninitialized this.',
  'Super capture before argument mutation; malformed captured parent still runs arguments; repeated/nested super constructs parent before duplicate bind; parent ordinary throw outranks duplicate error.',
  'Escaped arrow after object return and after exceptional construction: original NewTarget, live parent changed between construction and later call, first later bind then repeated failure. This is a source-derived required discriminator, not a new public literal authored by this hold.',
  'Default derived moves exact argument identities with no Array iterator read, including poisoned Array prototype; explicit rest/spread remains the existing observable iterator route.',
  'Natural terminal during superclass/native Promise invocation or computed key/parameter: queue sentinel does not resume through the public boundary, and all frame/call/stack counters restore without losing already-captured environment identity.',
  'Old ordinary function/arrow/bound/default/rest/method/native Promise behaviors and helper fee suites remain independently checked; any unavoidable sizeof-based startup/parser accounting migrations are explicit and source-derived.'
 ],
 'migration_and_review_census':{
  'semantic_witnesses':['src/script/parser.rs legacy/flat CORPUS class refusal: root selected class A{field;} while preserving Unsupported diagnostic "\'class\' is not supported" and offset None for complete Debug-error equality','src/script.rs identifiers_valid_unavailable_grammars_stay_explicit','label/controlled-statement class Syntax tests remain errors','object-method super property Unsupported tests remain unsupported','construction.rs new.target parse contexts remain preserved'],
  'shape_witnesses':['code/call_spread_layout_tests.rs actual Expr and marker page widths','parser/driver/call_spread_layout_tests.rs actual unions/heap-derived depth','machine initialization and call/frame quota tests','bootstrap_tests and cumulative typed-array startup heap ledger','test262_host setup and raw bootstrap quota witnesses','all direct Environment initializer/type fixtures','test-only legacy code compiler/canonical/reconstruction exhaustive matches'],
  'scope_qualification':'This is a concrete seam/tariff obligation list, not the final exact edit census. After record/continuation shapes are selected, root must derive all actual numeric/expression witnesses from the full tracked Rust tree. No assertion is silently updated by this hold.',
  'profiles':'Do not change old feature policies, corpora or baselines in this runtime checkpoint. Newly accepted untagged class bodies may change measured old report outcomes; report actual differences and remaining parser/host boundaries rather than requiring stale outcomes or predicting pass counts.'
 },
 'alternatives_and_selection_points':[
  {'choice':'Explicit ThisBinding enum + active constructor ID','recommendation':'Prefer it over encoding uninitialized as None paired with NewTarget presence or using a sentinel Value. It prevents accidental parent receiver lookup and states escaped-arrow ownership directly. Measure actual width before selecting charges.'},
  {'choice':'Class kind in immutable code versus runtime Function field','recommendation':'Prefer code::Function Option<ClassKind>; all evaluations of the same class syntax share its constructor kind. No per-instance mutable brand is required. Assert that existing code flags and bound wrappers cannot bypass the Call guard.'},
  {'choice':'Existing guarded constructor bridge versus new fully flat construction driver','recommendation':'Retain the old bridge for this slice. A fully flat Construct frame would need a separate budget/ordinary native reentry migration and is not required for selected semantics.'},
  {'choice':'Fresh class constructor factory versus refactoring all function factories','recommendation':'New dedicated factory, sharing only unchanged helpers with valid preconditions. Ordinary function factory must not allocate a throwaway prototype or acquire class-only fees.'},
  {'choice':'Property insertion helper','recommendation':'Use existing define_own_key for author elements. Fresh fixed metadata may use dom_proto_* only with reserved arena capacity and complete own-property invariants; no vacant-only path for duplicate or accessor updates.'},
  {'choice':'General environment/function reserve hardening','recommendation':'Any new class-only reservation planner must name physical/logical capacity and per-row charges. Do not silently retrofit every old environment/function allocation. A global hardening change is separate unless concrete layout accounting requires it.'},
  {'choice':'Numeric tariffs','recommendation':'Unselected. First select the precise field/frame/factory recipe, measure actual layouts in root-owned probes, then independently freeze ownership formulas and boundary tests before production.'},
 ],
 'coordination':{'parser':'Layout owns parser-design-1 and agrees ClassId/FunctionId/ClassKind/flat source-ordered element interface. Its private-token/strict/super parser design is not reviewed or implemented by this hold.',
                 'public':'HTML independently froze public-contract-2 with 62 literal rows/124 modes before this hold; this design does not modify or claim to review those literals.',
                 'root':'Root owns concrete representation/fee selection, future private control assignments, all live source imports, project execution and publication.'},
}
public_path = ROOT/'public-contract-2/source-ready.json'
if public_path.exists():
    design['inputs'].append(bind(public_path))
design_receipt = write('design.json', design)
ready = {'status':'ready-for-independent-source-review-and-root-selection',
 'base':BASE, 'design':design_receipt, 'interfaces':bind(OUT/'interfaces.txt'),
 'source_bindings':source_receipt, 'authoring_script':bind(OUT/'author.py'),
 'scope':'Source-only constructor/class-factory/machine/Environment proposal. No production, new tests, numeric fee selection, project execution or live edit.',
 'checks':{'selected_runtime_files':len(bindings),'all_files_match_published_git':True,
           'old_helpers_are_references_not_edits':True,'old_artifacts_untouched':True},
 'qualifications':['Shared record/frame/environment layout may change unconditional heap accounting even without class execution. No measured ABI or startup total is predicted.',
                   'The public semantic slice is root-selected; interface shapes and accounting remain proposed. Existing profile policies remain unchanged, but actual newly-admitted untagged outcomes may change.']}
write('source-ready.json', ready)
print(json.dumps({'source_ready':bind(OUT/'source-ready.json'),'design':design_receipt,'source_files':len(bindings)},indent=2))
