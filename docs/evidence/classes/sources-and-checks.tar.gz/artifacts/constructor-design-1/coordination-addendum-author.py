"""Design-only ownership split; no implementation or project imports."""
import hashlib
import json
from pathlib import Path

F = Path('/tmp/eris-class-runtime-plan-1')
O = F / 'constructor-design-1'
def b(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

data = {
 'status':'Additive proposed interface/ownership clarification; original design seal unchanged. Root selection still required for concrete fields, fees and production.',
 'base':'f3118ae5787c410648657f7c822efb7014201dd1',
 'original_design':b(O/'source-ready.json'),
 'parser_design':b(F/'parser-design-1/source-ready.json'),
 'name_only_refinement':{'original':'ExprPhase::NamedClassStart(PropertyKey)', 'proposed':'ExprPhase::NamedStart(PropertyKey)',
  'reason':'Use root-proposed concise name. Same class-only phase shape and ordering; no added ExprFrame field.'},
 'file_ownership':{
  'layout':['code Class/ClassKind/element arena and flat IDs','parser grammar continuations/context/early errors/scope walks','Unit::anonymous_class query'],
  'script':['new class constructor factory/runtime helper module','machine::classes frame and scheduling','class construct arm and guarded class invocation wrapper','ThisBinding enum/this-owner and super capture/bind helpers','calls.rs class entry, constructor completion and ordinary Call guard','ExprPhase::NamedStart implementation and SuperCall/SuperCallSpread scheduling'],
  'root':['Runtime Environment field/init/environment() formula composition in script.rs','runtime lexical admission/conflict/TDZ class binding integration','Stmt::Class scheduling/outer initialization continuation','direct anonymous-class name handoffs in declarations, identifier assignment/logical RHS, object data values and parameter defaults','shared parent-file composition, exact migrations and all execution'],
  'qualification':'This is a proposed fragment ownership map, not permission for live edits. Calls.rs and machine.rs parent files require root composition of disjoint regions; a module filename is not exclusive ownership of every existing callsite.'
 },
 'shared_apis':[
  {'owner':'Layout','signature':'code::Unit::anonymous_class(&self, expression: ExprId) -> Option<ClassId>',
   'contract':'Some only for the direct Expr::Class record whose syntactic Class.name is None. Keep Unit::anonymous unchanged for existing functions. No inference through value-producing wrapper expressions.'},
  {'owner':'Script','signature':'ExprFrame::named_class(unit: Rc<code::Unit>, expression: ExprId, environment: usize, name: PropertyKey) -> ExprFrame',
   'contract':'Consumes already-retained Unit/name; reference=false; phase=NamedStart(name). No allocation, callback or extra clone in the constructor. Caller uses only after anonymous_class is Some. Normal frame admission still pays expression weight/storage.'},
  {'owner':'Script','signature':'Runtime::class_name_hint(&mut self, source: &PropertyKey) -> Result<PropertyKey>',
   'contract':'New class-only preflight and immutable-handle copy for an already canonical key; no ToPropertyKey and no global/user lookup. Exact envelope unselected. It funds the copied key lifetime through NamedStart even if later admission refuses.'},
  {'owner':'Script','signature':'Runtime::class_identifier_name_hint(&mut self, source: &str) -> Result<PropertyKey>',
   'contract':'New class-only bounded key allocation/preflight from a direct identifier/default binding name; reuse dom_proto_text unchanged if selected. No author conversion. String length/work/heap and cleanup charged before allocation. Exact envelope unselected.'},
  {'owner':'Script','signature':'classes::Frame::new(unit: Rc<code::Unit>, class_id: ClassId, outer_environment: usize, inferred_name: Option<PropertyKey>) -> classes::Frame',
   'contract':'Consumes paid handles, starts at Phase::Start. New Frame::Class weights=(0,0); expression callers retain their original Expression frame for accounting; declaration callers retain Statement initialization frame. Source Class.name determines an explicit name, regardless of hint.'},
  {'owner':'Root','signature':'Runtime::initialize_class_declaration(&mut self, environment: usize, name: &str, constructor: Value) -> Result<()>',
   'contract':'Initialize the already-admitted mutable lexical binding in the declaration environment. No write_name/global-property behavior, inherited setter or new binding on fallback. Validate internal TDZ state. Any lookup/control/owned-value release admission is explicit and selected before production. This helper does not perform late SetFunctionName.'},
  {'owner':'Script','signature':'Runtime::this_environment(&mut self, environment: usize) -> Result<usize>',
   'contract':'Walk with existing per-environment tick to the first nonlexical state. Owned Uninitialized is a match, not a request to continue to parent. Used by super; root can preserve the old this-reference walk inline with the same state predicate.'},
  {'owner':'Script','signature':'Runtime::class_this_value(&self, owner: usize) -> Result<Value>',
   'contract':'Initialized copies its Value; Uninitialized throws ReferenceError; Lexical owner is an internal misuse. No new budget debit inside this leaf: ordinary binding_value retains its old receiver-copy accounting; constructor completion prepays the extra return copy before body. Selection must keep these provenance rules explicit.'},
  {'owner':'Script','signature':'Runtime::class_super_target(&mut self, environment: usize) -> Result<(usize, Value, Value)>',
   'contract':'Paid capture returns this owner ID, original NewTarget and live superclass. It does not read this value or check already-initialized state. Parent capture precedes arguments; constructability check follows arguments.'},
  {'owner':'Script','signature':'Runtime::class_bind_this(&mut self, owner: usize, constructed: Value) -> Result<Value>',
   'contract':'Caller prepays result and environment retention before Construct. Final scalar check/one retained copy/publication is callback-free, allocation-free and has no new quota debit. If already initialized, throw after parent construction; preserve old receiver.'},
 ],
 'named_handoff_rules':[
  'Root checks anonymous_class before constructing any hint; ordinary function paths and their existing fee order remain exact.',
  'Identifier declaration and direct identifier assignment/default contexts use the source identifier hint. Object data values use the key already computed for that object entry. Logical assignments create/evaluate the hint only on the taken RHS path.',
  'Use NamedStart before class evaluation. Skip all old post-value function name setters for classes; a later setter would erase an own static name method.',
  'Declaration Stmt::Class has an explicit syntactic name and can pass None inferred hint. Its statement completion is empty, not the constructor Value. Class expression normal evaluation also uses None unless a specific named-evaluation context supplied a hint.',
  'The key hint is metadata only: it does not create a class inner binding. No inference for member assignment, comma/conditional wrappers or a previously created class Value.'
 ],
 'environment_charge_clarification':{
  'old_runtime_formula':'128 + 2*sizeof<Option<Value>>',
  'new_runtime_formula_proposal':'old_runtime_formula + measured_nonnegative_environment_representation_delta',
  'delta_definition':'Account for replacing the old this Option<Value> by ThisBinding and adding active_constructor Option<usize>, using actual target layout and preserving the legacy allowance. Do not absorb a new field in the old 128 reserve and do not reduce the old allowance if padding makes the real delta smaller or zero.',
  'bootstrap':'Apply the corresponding two-initial-environment representation delta to both ordinary and test262-host uninitialized accounting. NewTarget representation remains unchanged. Any allocator capacity reservation charge is separately named, not hidden in this field delta.',
  'other_unconditional_terms':'New Unit::classes, code::Function tag and machine Frame shape retain existing sizeof-based charges. Actual layout probes and independent private fee contracts precede implementation. No numeric delta is claimed.'
 },
 'preservation':['No change to native Promise helper bodies/fees or current constructor IDs.','No new Runtime/Function/Value/ScriptObject field in this proposal.','The mutable lexical declaration binding and immutable inner class binding remain distinct.','The historical field-class parser differential keeps Unsupported text and offset exactly as root selected.'],
 'authoring_script':b(O/'coordination-addendum-author.py'),
}
path = O/'coordination-addendum-1.json'
path.write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(b(path), indent=2))
