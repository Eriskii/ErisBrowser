from pathlib import Path
import json, hashlib, subprocess, difflib
F=Path('/tmp/eris-class-runtime-plan-1')
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def b(p):
    z=p.read_bytes();return {'path':str(p),'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()}
def verify(r):assert b(Path(r['path']))==r
P=F/'parser-implementation-1';m=json.loads((P/'source-ready.json').read_text());rows=[]
for r in m['files']:
    for k in ['before','raw','diff']:
        if r.get(k):verify(r[k])
    rel=r['relative'];new=Path(r['raw']['path']).read_bytes();old=b''
    if not r['new']:
        old=subprocess.check_output(['git','show',BASE+':'+rel],cwd=F/'worktree')
        assert old==Path(r['before']['path']).read_bytes()
    diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),
        fromfile='/dev/null' if r['new'] else 'a/'+rel,tofile='b/'+rel))
    assert diff==Path(r['diff']['path']).read_text(),rel
    rows.append({'relative':rel,'new':r['new'],'published_before':not r['new'],'exact_diff':True})
review={
 'status':'clear','scope':'Independent source-only parser/code review; no candidate execution or validation-log inspection',
 'base':BASE,'implementation':b(P/'source-ready.json'),'interfaces':b(P/'interfaces.json'),
 'selected_shapes':b(F/'parser-shapes-1/source-ready.json'),'public_contract':b(F/'public-contract-2/source-ready.json'),
 'files':rows,'findings':[],
 'semantic_checks':[
  'The existing declarations guard rejects class declarations in single-statement positions. Statement-list classes join lexical conflict, parameter and catch-name checks.',
  'Class heritage and computed keys are strict while retaining enclosing super/new.target permissions. Derived literal constructors enable direct super in parameters/body; arrows inherit; ordinary functions and methods reset it. Class/function completion restores outer context.',
  'Literal constructor and static prototype names are distinguished from computed keys. Duplicate constructors, accessor constructors and invalid accessor arities reject. Source-free default functions carry the correct constructor tag; ordinary class methods remain strict and nonconstructible.',
  'Heritage uses LeftHandSideExpression including calls/members/new, without consuming postfix updates. Direct super enters CallExpression continuation; new super() is rejected, and super-property access stays explicitly Unsupported.',
  'Class elements remain source ordered. Fields, private members, static blocks, async and generator methods do not silently enter the selected slice. Private token refusal uses the lexer Invalid token exact source offset.',
  'Class records and element vectors retain existing paid append helpers. Old function records receive class_kind=None; class-only canonical inversion is explicitly unavailable, while the selected historical field fixture retains its complete Unsupported diagnostic.',
  'Both old expression fixture changes add only allow_update:true to Postfix construction. Their JavaScript literals and assertions remain exact.'
 ],
 'qualifications':[
  'This review does not itself compile or execute source. Actual composed types, numeric migrations and semantic/resource behavior remain root validation obligations.',
  'A first inert diff-check attempt incorrectly assumed a/src for the new-file header; the held diff correctly uses /dev/null. Only the checker convention was corrected; no producer bytes changed.',
  'Root supplied focused outcome status during review; no result logs were opened and no held source or expectation changed.'
 ]}
out=F/'parser-implementation-review-1/review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(b(out)))
B=F/'browser-tests-1';bm=json.loads((B/'source-ready.json').read_text())
for r in bm['files']:
    z=(B/'raw'/r['path']).read_bytes();assert len(z)==r['bytes'] and hashlib.sha256(z).hexdigest()==r['sha256']
assert bm['expected']=={'disabled':{'left':2,'title':'base'},'initial':{'left':12,'title':'SBDTQR'},'clicked':{'left':16,'title':'SBDTQRCTRL'}}
support=[]
for rel in bm['derived_helpers']:
    z=subprocess.check_output(['git','show',BASE+':'+rel],cwd=F/'worktree')
    support.append({'relative':rel,'bytes':len(z),'sha256':hashlib.sha256(z).hexdigest()})
review={
 'status':'clear','scope':'Independent browser fixture/API/oracle source review; traces below are manual expectations, not execution claims',
 'hold':b(B/'source-ready.json'),'payloads':[b(B/'raw'/r['path']) for r in bm['files']],
 'registration':b(B/'registration-append.txt'),'published_helper_bindings':support,'findings':[],
 'manual_derivation':{
  'disabled':'Script disabled preserves title base and red left2 after clicks/task drain.',
  'initial':'S; Marker constructor B; Swatch constructor D; synchronous Promise.try T; earlier queued Q; fulfilled reaction R gives SBDTQR. The reaction checks returned identity through both prototypes and paints red at12.',
  'click':'First listener C and synchronous callback T; existing event-listener checkpoint runs R before next listener L, giving SBDTQRCTRL and red left16.',
  'pixels':'White background; red[x,x+4), blue[20,24), both y[2,6), at widths320/300. Final red right edge20 is exclusive, so it does not overlap blue. Hit tests use interior points.'
 },
 'checks':[
  'Page and confined Worker cover disabled/enabled load, click and later task drain, with title/task/diagnostic and unchanged blue assertions.',
  'Canvas and optional raster-bridge native-plan pixels use the independent literal rectangle oracle. No hardware Vulkan or performance behavior is inferred.',
  'Worker registration is an exact separate module-path append. Its ignored test explicitly requires Landlock ABI6.',
  'The oracle uses neither mutable runtime state nor an observed rendered image.'
 ],
 'qualification':'This reviewer authored the runtime producer, but these browser tests were independently root-authored before candidate execution. The receipt concerns fixture semantics/transcription and existing API usage. No browser result log was inspected.'}
out=F/'browser-tests-review-1/review.json';assert not out.exists();out.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(b(out)))
