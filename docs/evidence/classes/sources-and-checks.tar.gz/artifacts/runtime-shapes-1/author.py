"""Build inert complete type mirrors from published declarations; stdlib only."""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import difflib

F = Path('/tmp/eris-class-runtime-plan-1')
W = F/'worktree'
O = F/'runtime-shapes-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def sha(data): return hashlib.sha256(data).hexdigest()
def bind(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def put(relative,data):
    p=O/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);return bind(p)
def js(relative,data): return put(relative,(json.dumps(data,indent=2)+'\n').encode())
def decl(text,kind,name):
    match=re.search(r'(?m)^(?:pub\([^\n]*\) )?'+kind+r' '+re.escape(name)+r' \{',text)
    assert match,(kind,name)
    start=match.start();depth=1;end=text.index('{',match.start())+1
    # All selected declaration bodies contain no brace-bearing text literals.
    while depth:
        if text[end]=='{':depth+=1
        elif text[end]=='}':depth-=1
        end+=1
    return text[start:end]
def rename(text,mapping):
    return re.sub(r'\b('+'|'.join(map(re.escape,mapping))+r')\b',lambda m:mapping[m.group()],text)
def visible(text):
    return re.sub(r'^(?:pub\([^\n]*\) )?(struct|enum) ',r'pub(super) \1 ',text)
def append_variant(text,variant):
    assert text.endswith('}')
    return text[:-1]+variant+'}'

support=['src/script.rs','src/script/machine.rs','src/script/machine/calls.rs',
         'src/script/machine/statements.rs','src/script/machine/call_spread.rs',
         'src/script/code.rs','src/script/own_keys.rs']
sources={}
bindings=[]
for p in support:
    raw=subprocess.check_output(['git','show',f'{BASE}:{p}'],cwd=W)
    disk=(W/p).read_bytes()
    sources[p]=raw.decode()
    bindings.append({'relative':p,'bytes':len(raw),'sha256':sha(raw),'live_worktree_equal_at_read':disk==raw,
      'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()})

declarations={
 'Environment':decl(sources['src/script.rs'],'struct','Environment'),
 'Activation':decl(sources['src/script/machine/calls.rs'],'struct','Activation'),
 'CallFrame':rename(decl(sources['src/script/machine/calls.rs'],'struct','Frame'),{'Frame':'CallFrame','Phase':'CallPhase'}),
 'CallPhase':rename(decl(sources['src/script/machine/calls.rs'],'enum','Phase'),{'Phase':'CallPhase'}),
 'ExprFrame':rename(decl(sources['src/script/machine.rs'],'struct','ExprFrame'),{'Phase':'ExprPhase'}),
 'ExprPhase':rename(decl(sources['src/script/machine.rs'],'enum','Phase'),{'Phase':'ExprPhase'}),
 'StatementFrame':rename(decl(sources['src/script/machine/statements.rs'],'struct','Frame'),{'Frame':'StatementFrame','Phase':'StatementPhase'}),
 'StatementPhase':rename(decl(sources['src/script/machine/statements.rs'],'enum','Phase'),{'Phase':'StatementPhase'}),
 'Frame':'''pub(super) enum Frame {
    Expression(ExprFrame),
    Statement(StatementFrame),
    Call(CallFrame),
}''',
}
original_top=decl(sources['src/script/machine.rs'],'enum','Frame')
assert declarations['Frame']==original_top.replace('statements::Frame','StatementFrame').replace('calls::Frame','CallFrame')
baseline={k:visible(v) for k,v in declarations.items()}
proposed=dict(baseline)

new_types={
 'ClassId':'pub(super) struct ClassId(usize);',
 'ClassKind':'''pub(super) enum ClassKind {
    ExplicitBase,
    ExplicitDerived,
    DefaultBase,
    DefaultDerived,
}''',
 'ThisBinding':'''pub(super) enum ThisBinding {
    Lexical,
    Uninitialized,
    Initialized(Value),
}''',
 'ClassFrame':'''pub(super) struct ClassFrame {
    unit: Rc<code::Unit>,
    class_id: ClassId,
    outer_environment: usize,
    phase: ClassPhase,
}''',
 'ClassPhase':'''pub(super) enum ClassPhase {
    Start {
        inferred_name: Option<PropertyKey>,
    },
    Heritage {
        class_environment: usize,
        inferred_name: Option<PropertyKey>,
    },
    ComputedKey {
        class_environment: usize,
        constructor: usize,
        prototype: usize,
        element_index: usize,
    },
    Vacant,
}''',
}
environment_old='    this_binding: Option<Value>,\n'
environment_new='    this_binding: ThisBinding,\n'
active='    active_constructor: Option<usize>,\n'
proposed['Environment']=proposed['Environment'].replace(environment_old,environment_new)
proposed['Environment']=proposed['Environment'].replace('    new_target_binding: Option<Value>,\n','    new_target_binding: Option<Value>,\n'+active)
assert proposed['Environment'].replace(environment_new,environment_old).replace(active,'')==baseline['Environment']
additions={
 'CallPhase':'''    ClassStart {
        id: usize,
        arguments: Vec<Value>,
    },
    ClassBody {
        environment: usize,
        kind: ClassKind,
    },
''',
 'ExprPhase':'''    NamedStart(PropertyKey),
    SuperArguments {
        owner: usize,
        new_target: Value,
        superclass: Value,
        index: usize,
        arguments: Vec<Value>,
    },
    SuperSpreadArguments {
        owner: usize,
        new_target: Value,
        superclass: Value,
        index: usize,
        arguments: call_spread::Arguments,
    },
''',
 'StatementPhase':'''    ClassInitialize {
        binding_environment: usize,
    },
''',
 'Frame':'    Class(ClassFrame),\n',
}
for name,addition in additions.items():
    proposed[name]=append_variant(proposed[name],addition)
    assert proposed[name].replace(addition,'')==baseline[name]
for name in ['Activation','CallFrame','ExprFrame','StatementFrame']:
    assert proposed[name]==baseline[name]

header='''//! Inert complete class runtime layout mirrors. No class operations execute.
//! Baseline declarations are mechanically joined to the published parent;
//! proposed declarations add only the selected representation fields/variants.
use super::{ForInState, ForOfState, Kind};
use crate::script::{Binding, Flow, PropertyKey, Reference, Result, Value, code};
use crate::script::machine::call_spread;
use std::collections::{BTreeMap, BTreeSet};
use std::rc::Rc;

'''
def module(name,parts):
    text='\n\n'.join(parts.values())
    return '#[allow(dead_code)]\nmod '+name+' {\n    use super::*;\n\n'+''.join('    '+line+'\n' if line else '\n' for line in text.splitlines())+'}\n\n'

test='''#[test]
fn class_runtime_complete_layout_probe() {
    use std::mem::{align_of, size_of};
    macro_rules! same {
        ($mirror:ty, $actual:ty) => {
            assert_eq!(size_of::<$mirror>(), size_of::<$actual>());
            assert_eq!(align_of::<$mirror>(), align_of::<$actual>());
        };
    }
    macro_rules! row {
        ($label:literal, $ty:ty) => {
            println!(
                "CLASS_RUNTIME_LAYOUT {} bytes={} align={}",
                $label,
                size_of::<$ty>(),
                align_of::<$ty>()
            );
        };
    }
    // Exact parent aggregates independently constrain the mechanically copied
    // complete baselines. No proposed numeric size is embedded in this probe.
    same!(baseline::Environment, crate::script::Environment);
    same!(baseline::CallFrame, crate::script::machine::calls::Frame);
    same!(baseline::ExprFrame, crate::script::machine::ExprFrame);
    same!(baseline::ExprPhase, crate::script::machine::Phase);
    same!(baseline::StatementFrame, super::Frame);
    same!(baseline::StatementPhase, super::Phase);
    same!(baseline::Frame, crate::script::machine::Frame);

    println!(
        "CLASS_RUNTIME_LAYOUT_CONFIG test262_host={} vulkan={} pointer_bytes={}",
        cfg!(feature = "test262-host"),
        cfg!(feature = "vulkan"),
        size_of::<usize>()
    );
    row!("Value", Value);
    row!("OptionValue", Option<Value>);
    row!("OptionUsize", Option<usize>);
    row!("PropertyKey", PropertyKey);
    row!("OptionPropertyKey", Option<PropertyKey>);
    row!("Reference", Reference);
    row!("Binding", Binding);
    row!("Function", crate::script::Function);
    row!("BoundFunction", crate::script::BoundFunction);
    row!("ScriptObject", crate::script::ScriptObject);
    row!("Runtime", crate::script::Runtime);
    row!("FunctionRef", code::FunctionRef);
    row!("CodeFunction.parent", code::Function);
    row!("CodeUnit.parent", code::Unit);
    row!("CallSpreadArguments", call_spread::Arguments);
    row!("StatementKind", Kind);
    row!("ForInState", ForInState);
    row!("ForOfState", ForOfState);
    row!("baseline.Environment", baseline::Environment);
    row!("baseline.Activation", baseline::Activation);
    row!("baseline.CallPhase", baseline::CallPhase);
    row!("baseline.CallFrame", baseline::CallFrame);
    row!("baseline.ExprPhase", baseline::ExprPhase);
    row!("baseline.ExprFrame", baseline::ExprFrame);
    row!("baseline.StatementPhase", baseline::StatementPhase);
    row!("baseline.StatementFrame", baseline::StatementFrame);
    row!("baseline.Frame", baseline::Frame);
    row!("proposed.ThisBinding", proposed::ThisBinding);
    row!("proposed.Environment", proposed::Environment);
    row!("proposed.ClassId", proposed::ClassId);
    row!("proposed.ClassKind", proposed::ClassKind);
    row!("proposed.OptionClassKind", Option<proposed::ClassKind>);
    row!("proposed.ClassPhase", proposed::ClassPhase);
    row!("proposed.ClassFrame", proposed::ClassFrame);
    row!("proposed.Activation", proposed::Activation);
    row!("proposed.CallPhase", proposed::CallPhase);
    row!("proposed.CallFrame", proposed::CallFrame);
    row!("proposed.ExprPhase", proposed::ExprPhase);
    row!("proposed.ExprFrame", proposed::ExprFrame);
    row!("proposed.StatementPhase", proposed::StatementPhase);
    row!("proposed.StatementFrame", proposed::StatementFrame);
    row!("proposed.Frame", proposed::Frame);
    println!(
        "CLASS_RUNTIME_FRAME_FORMULAS baseline_initial={} proposed_initial={} baseline_max={} proposed_max={}",
        8 * size_of::<baseline::Frame>() + 32,
        8 * size_of::<proposed::Frame>() + 32,
        crate::script::MAX_HEAP / size_of::<baseline::Frame>(),
        crate::script::MAX_HEAP / size_of::<proposed::Frame>()
    );
    println!(
        "CLASS_RUNTIME_ENVIRONMENT_FORMULAS legacy={} proposed={} two_initial_delta={}",
        128 + 2 * size_of::<Option<Value>>(),
        128 + 2 * size_of::<Option<Value>>()
            + size_of::<proposed::Environment>().saturating_sub(size_of::<baseline::Environment>()),
        2 * size_of::<proposed::Environment>().saturating_sub(size_of::<baseline::Environment>())
    );
}
'''
payload=header+module('baseline',baseline)+module('proposed',{**new_types,**proposed})+test
relative='src/script/machine/statements/class_layout_probe.rs'
newrow={'relative':relative,'new':True,'raw':put('raw/'+relative,payload.encode()),'before':None}
newrow['diff']=put('diff/'+relative+'.diff',''.join(difflib.unified_diff([],payload.splitlines(True),fromfile='/dev/null',tofile=relative)).encode())
parent='src/script/machine/statements.rs'
before=sources[parent]
addition='\n#[cfg(test)]\nmod class_layout_probe;\n'
after=before+addition
assert after[:-len(addition)]==before
row={'relative':parent,'new':False,'before':put('before/'+parent,before.encode()),'raw':put('raw/'+parent,after.encode())}
row['diff']=put('diff/'+parent+'.diff',''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=parent,tofile=parent)).encode())
declaration_proof=js('declaration-proof.json',{
 'base':BASE,'source_bindings':bindings,
 'method':'Balanced-brace source extraction of declarations only, exact token-name substitutions, complete old neighbor retention, exact selected-addition inverse. No project module import or Rust execution.',
 'baseline_declarations':baseline,
 'proposed_declarations':{**new_types,**proposed},
 'inverses':{'Environment':{'old_this':environment_old,'new_this':environment_new,'remove':active},**{n:{'remove':v} for n,v in additions.items()}},
 'unchanged_complete_mirrors':['Activation','CallFrame','ExprFrame','StatementFrame'],
 'genuine_unchanged_payloads':['Binding','Value','PropertyKey','Reference','Flow','Result<Flow>','code::FunctionRef','Rc<code::Unit>','ExprId','StmtId','call_spread::Arguments','statements::Kind','statements::ForInState','statements::ForOfState','BTreeSet<usize>','Vec<Value>'],
 'privacy':'Probe is a child of machine::statements, so genuine private Kind/ForInState/ForOfState are visible without production visibility changes. Calls complete declarations are mirrored, not accessed through private sibling fields.',
 'source_function_bodies_changed':0,
 'authoring_qualification':'Initial stdlib authoring stopped before output because current script.rs has root-imported public-test registrations. The retry reads exact git-show published bytes directly; no live source or class payload changed and no project code ran.',
 'no_measurement_claim':True,
})
ready={'status':'sealed inert complete runtime layout probe; not executed',
 'base':BASE,
 'inputs':[bind(F/'root/representation-selection-1.json'),bind(F/'constructor-design-1/source-ready.json'),bind(F/'constructor-design-1/coordination-addendum-1.json'),bind(F/'parser-shapes-1/source-ready.json')],
 'files':[newrow,row],
 'declaration_proof':declaration_proof,'authoring_script':bind(O/'author.py'),
 'registration':'Append-only cfg(test) child of machine::statements; parent snapshot is publication lineage. Root composes any other test-only registration additions.',
 'test':'script::machine::statements::class_layout_probe::class_runtime_complete_layout_probe',
 'planned_output':{'type_rows':42,'configuration_rows':1,'derived_formula_rows':2},
 'qualifications':['No source production behavior, constructor algorithm or test outcome is implemented or predicted.',
 'All old enum neighbors remain present, including the full StatementPhase plus new ClassInitialize.',
 'New ClassId/ClassKind are local inert copies of the selected parser declarations; unchanged leaf types are genuine production types.',
 'The baseline assertions are intended for the published parent plus inert test modules, before production representation changes.',
 'Displayed environment formula preserves the old allowance plus nonnegative complete measured struct delta; root selects the final tariff after measurement and independent review.']}
js('source-ready.json',ready)
print(json.dumps({'source_ready':bind(O/'source-ready.json'),'raw_bytes':len(payload.encode()),'planned_type_rows':len(re.findall(r'row!\(',test))},indent=2))
