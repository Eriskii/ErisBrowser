import collections,difflib,hashlib,json,pathlib,subprocess
P=pathlib.Path('/tmp/eris-class-runtime-plan-1'); O=P/'documentation-2'; D=P/'documentation-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
ledger=json.loads((P/'root/final-validation.json').read_text()); profiles=json.loads((P/'root/profile-validation-1.json').read_text())
assert digest((P/'root/final-validation.json').read_bytes())=='847cd92bd77b1e0ce2cca9ed434a5c4ad171e6956f2c99de7b845bb2b9f6b1ac'
assert ledger['status']==profiles['status']=='pass'
assert ledger['source']['selected_inputs']==1834 and len(ledger['source']['changed_paths'])==30
assert sum(x['cases'] for x in profiles['profiles'])==1330 and sum(x['controls'] for x in profiles['profiles'])==640
counts=collections.Counter()
for row in profiles['profiles']:counts.update(row['counts'])
assert counts=={'passed':1222,'failed':60,'unsupported':48}
files=[x['relative'] for x in json.loads((D/'source-ready.json').read_text())['files']]
texts={f:(D/'raw'/f).read_text() for f in files}; edits=[]
def replace(f,old,new):
 assert texts[f].count(old)==1,(f,old[:80],texts[f].count(old))
 texts[f]=texts[f].replace(old,new);edits.append({'relative':f,'old':old,'new':new})
replace('README.md','scope. The first focused run passes 79 public groups across 162 mode attempts;\nremaining checkpoint validation is pending.','scope. Final checks pass 80 public groups across 164 mode attempts, with the\ncomplete Rust suites and eight existing profile replays recorded in the chapter.')
replace('docs/ROADMAP.md','The first 79 public groups pass in 162 mode attempts. Final quota, full-suite,\nbrowser and replay validation remains pending for this checkpoint.','Final validation passes 80 public groups in 164 mode attempts, 16 private groups\nand two browser witnesses. Complete Rust suites pass 3,344/3,698 groups; eight\nunchanged profile replays retain 1,330 cases and 640 healthy controls. Their 20\nnew passes and ten newly reached failures are recorded in the chapter; no\npreviously passing case regressed.')
replace('docs/COMPATIBILITY.md','class-profile results. The 79-group public check passes; final checkpoint\nvalidation remains pending.','class-profile results. Final checks pass 80 public groups in 164 mode attempts.\nEight unchanged profile replays retain 1,330 cases and 640 healthy controls:\n1,222 passed, 60 failed and 48 unsupported. Twenty formerly unsupported modes\nnow pass; ten others reach existing BigInt syntax or host-audit failures. No\npreviously passing case regressed, and no baseline was changed.')
replace('docs/SECURITY.md','The selected representation adds accounted environment storage, with final candidate quota and full-suite validation pending.','The representation adds accounted environment and compiled-code storage. Final quota controls and complete Rust suites pass; the [class checkpoint](classes.md) records the measured layouts, retained corrections and limits.')
replace('docs/classes.md','arguments. Parent construction happens before the duplicate-`super()` binding\ncheck, so a second parent call can perform effects or throw first. Default\nderived constructors forward the incoming argument list directly without reading','arguments, then checks that the captured value is a constructor before generic\nbound forwarding. Parent construction happens before the duplicate-`super()`\nbinding check, so a second parent call can perform effects or throw first.\nDefault derived constructors validate the live parent before forwarding the\nincoming argument list directly without reading')
replace('docs/classes.md','are recorded target layouts and logical charges, not process-memory or speed\nmeasurements; final candidate shape and startup checks are pending. Author work','are recorded target layouts and logical charges, not process-memory or speed\nmeasurements. Final private controls confirm the production environment, Unit\nand frame layouts; the cumulative startup witness includes both the 32-byte\nenvironment addition and the 32-byte empty class-record container. Author work')
old=texts['docs/classes.md'][texts['docs/classes.md'].index('The first compiled candidate passes all **79'):]
new='''Final validation passes **80 public groups / 164 mode attempts**, **16 private
groups** covering 114 measured helper/parser operations plus one raw/layout
observation, and **two browser witnesses**. The direct Page and confined-worker
checks cover disabled, initial, repeated and click states at two viewport sizes
with exact pixels. The feature build also checks native raster-plan pixels;
this checkpoint did not execute hardware Vulkan.

The complete default Rust 1.88 suite passes **3,344 groups** and the Rust 1.99
`test262-host,vulkan-raster` suite passes **3,698**, preserving their complete
prior rosters plus 98 new groups. Strict Clippy checks for both configurations
and formatting pass. Rebuilt ordinary and host release adapters replay all eight
existing profiles: **1,330 case rows / 640 healthy controls**, with **1,222
passed, 60 failed and 48 unsupported**. Twenty formerly unsupported modes now
pass. Ten other modes become failures: eight reach unimplemented BigInt literal
syntax, and two `finally` subclass modes reach the existing final-unhandled-
rejection host audit. No previously passing case regressed. All raw changes are
retained; profile policies, original corpora and baselines are unchanged.

The retained attempts distinguish fixes from completed validation:

- The original 79 public groups passed in 162 mode attempts after the compiler
  found a sibling-visibility error. Widening `constructed_prototype` to
  `pub(super)` preserved its body and tariff. A separate private fixture compiler
  error required only a longer-lived expected-value binding.
- Later source review found that a bound nonconstructor superclass could enter
  generic argument forwarding before rejection. A class-only validation helper
  now charges one handle copy plus the existing constructor-check work after
  explicit arguments, or before default forwarding. One independent public group
  and one private group cover this correction; the original public expectations
  remain unchanged.
- The first full attempt had 2,993 passing and nine failing library groups:
  eight outer-sandbox socket refusals and one missed cumulative startup ledger.
  The ledger gained the derived 64 bytes described above, preserving its earlier
  terms, work and object counts. The final suites use that correction; the
  successful default rerun was allowed to create its required local sockets.

The final source receipt covers 1,834 selected inputs and 30 changed or new
paths. It is a cumulative selected inventory, not a complete build graph. No
Cargo/build inputs or conformance policies, corpora or baselines changed. These
results do not establish complete ECMAScript/web compatibility, production
security, process-memory use or a Chromium performance comparison.

The [evidence manifest](evidence/classes/manifest.json) and
[source/check archive](evidence/classes/sources-and-checks.tar.gz) retain the
source bindings, independent contracts, corrections and complete run records.
'''
replace('docs/classes.md',old,new)
head='# Validation record\n\n';before=(D/'before/docs/VALIDATION.md').read_text();assert before.startswith(head)
block='''## JavaScript class runtime

The [class subset](classes.md) adds strict declarations/expressions, public
methods/accessors and base/derived construction, including direct `super()`,
retained arrows and native Promise subclasses. Fields, private elements, static
blocks, `super` properties and async/generator methods remain unsupported.
Upstream feature policies are unchanged; this checkpoint does not admit the
`class` feature to those profiles.

The final default Rust 1.88 suite passes **3,344 groups**, and Rust 1.99 with
`test262-host,vulkan-raster` passes **3,698**. Each produces 53 result rows and
preserves the complete prior roster plus **98 new groups**: **80 public / 164
mode attempts**, **16 private** and **two browser witnesses**. Private coverage
contains 114 measured helper/parser operations plus one raw/layout observation.
Strict Clippy checks for both configurations and formatting pass. Direct Page
and confined-worker witnesses verify two viewports, disabled/initial/repeated/
click states and exact pixels. The feature suite also checks native raster-plan
pixels; no hardware Vulkan run was performed for this checkpoint.

Rebuilt ordinary and host release adapters replay eight existing profiles with
**1,330 case rows and 640 healthy controls**. Results are **1,222 passed, 60
failed and 48 unsupported**. Twenty formerly unsupported modes now pass. Ten
other formerly unsupported modes become failures: eight expose BigInt literal
syntax that remains unimplemented, and two `finally` subclass modes reach the
existing final-unhandled-rejection host audit. No previously passing case
regressed. Complete ordered identities and raw transitions are retained; no
policy, original corpus or baseline was changed. Earlier profile totals below
retain their original checkpoint scope.

Four complete-shape probes and final production checks bind Environment
96→112, its retained allowance 176→192, compiled Unit 136→168 and parser frame
112→120. The 184-byte runtime frame remains unchanged. The two initial
environments add 32 accounted bytes, and the empty Unit class-record container
adds another 32. These are recorded target layouts and logical charges, not
process-memory or timing measurements. Author 100,000, bootstrap 1,000,000 and
cumulative 8 MiB limits are unchanged.

Retained corrections and failed attempts are part of the evidence:

- The first compiled candidate passed the original 79 public groups / 162
  modes. Compilation first required sibling visibility for
  `constructed_prototype`, with its body and tariff unchanged. A separate
  private-fixture compile error needed only an expected-value lifetime fix.
- Source review then found missing superclass validation before generic bound
  forwarding. The class-only check now runs after explicit arguments or before
  default forwarding, paying one retained handle plus existing constructor-check
  work. An independent public group and private group were added; the original
  79-group parent comparison does not include that late supplement.
- The initial full default attempt reported 2,993 passing and nine failing
  library groups: eight sandbox socket refusals and a missed cumulative
  typed-array startup heap witness. A single derived +64-byte term preserves
  its earlier terms, work and counts. The successful final default rerun had
  permission for the tests' local sockets. The initial failure remains retained.

The final candidate is the second source inventory: **1,834 selected inputs**
and **30 changed/new paths** (16 existing, 14 new), not a complete build graph.
Cargo/build inputs and conformance tooling, policies, corpora and baselines are
unchanged. No new remote CI result, complete compatibility, security
certification or performance claim is made here. See the [evidence manifest](evidence/classes/manifest.json)
and [source/check archive](evidence/classes/sources-and-checks.tar.gz). The
complete prior validation body below remains byte-exact.

'''
texts['docs/VALIDATION.md']=head+block+before[len(head):]
edits.append({'relative':'docs/VALIDATION.md','old':(D/'raw/docs/VALIDATION.md').read_text(),'new':texts['docs/VALIDATION.md']})
rows=[]
for f in files:
 raw=O/'raw'/f;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_text(texts[f]);new=f=='docs/classes.md'
 prior=b'' if new else (D/'before'/f).read_bytes()
 if not new:
  git=subprocess.check_output(['git','show',BASE+':'+f],cwd=P/'worktree');assert git==prior
  bp=O/'before'/f;bp.parent.mkdir(parents=True,exist_ok=True);bp.write_bytes(prior)
 dp=O/'diff'/(f+'.diff');dp.parent.mkdir(parents=True,exist_ok=True)
 diff=''.join(difflib.unified_diff(prior.decode().splitlines(True),texts[f].splitlines(True),fromfile='/dev/null' if new else 'a/'+f,tofile='b/'+f));dp.write_text(diff)
 fp=O/'from-draft-diff'/(f+'.diff');fp.parent.mkdir(parents=True,exist_ok=True)
 fp.write_text(''.join(difflib.unified_diff((D/'raw'/f).read_text().splitlines(True),texts[f].splitlines(True),fromfile='documentation-1/'+f,tofile='documentation-2/'+f)))
 rows.append({'relative':f,'new':new,'before':None if new else bind(bp),'raw':bind(raw),'diff':bind(dp),'from_draft_diff':bind(fp)})
assert texts['docs/VALIDATION.md'].endswith(before[len(head):])
for f in files:
 reverse=texts[f]
 for e in reversed(edits):
  if e['relative']==f:
   assert reverse.count(e['new'])==1
   reverse=reverse.replace(e['new'],e['old'])
 assert reverse==(D/'raw'/f).read_text()
for f in ['README.md','docs/ROADMAP.md','docs/COMPATIBILITY.md']:
 assert 'pending' not in '\n'.join(texts[f].splitlines()[:17])
assert 'pending' not in texts['docs/classes.md'] and 'pending' not in block
refs=['root/final-validation.json','root/profile-validation-1.json','root/full-suite-validation-1.json','root/layout-measurements-1.json','source-final.json','source-candidate-1.json','source-candidate-2.json','documentation-1/source-ready.json','root/compiler-correction-1.json','root/private-compiler-correction-1.json','root/bound-superclass-correction-1/receipt.json','typed-ledger-migration-1/source-ready.json','root/full-suite-attempt-1-findings-2.json','worktree/src/script/classes/quota_tests.rs','worktree/src/script/typed_array/tests.rs']
# Verify every explicit file binding retained by the final ledger, without executing project code.
checked=[]
def walk(v):
 if isinstance(v,dict):
  if all(k in v for k in ['path','bytes','sha256']):
   p=pathlib.Path(v['path']);b=p.read_bytes();assert len(b)==v['bytes'] and digest(b)==v['sha256'];checked.append(v)
  for q in v.values():walk(q)
 elif isinstance(v,list):
  for q in v:walk(q)
walk(ledger)
claims={'status':'source and evidence joins clear','ledger':bind(P/'root/final-validation.json'),'evidence_inputs':[bind(P/x) for x in refs],'verified_ledger_file_bindings':checked,'totals':{'profiles':8,'case_rows':1330,'controls':640,**dict(counts),'full_default':3344,'full_host_vulkan':3698,'public_groups':80,'public_modes':164,'private_groups':16,'private_operations':114,'raw_layout_observation_groups':1,'browser_groups':2,'new_groups':98},'profile_summaries':[{k:r[k] for k in ['profile','cases','controls','counts','parent_counts']} for r in profiles['profiles']],'historical_validation_suffix_exact':True,'five_published_before_joins':True,'all_six_draft_inverses_exact':True,'old_other_chapters_unmodified':True,'scope':'Only six external documentation payloads; no live edits or project execution. Numeric summaries join retained actual receipts. Complete published historical suffix and every prior draft edit remain preserved. No later remote CI result claimed.','anticipated_evidence':['docs/evidence/classes/manifest.json','docs/evidence/classes/sources-and-checks.tar.gz']}
dump(O/'claims-and-checks.json',claims);dump(O/'edits-from-draft.json',edits);dump(O/'rows.json',rows)
ready={'status':'Sealed final six-document hold for independent peer and root import','base':BASE,'files':rows,'claims':bind(O/'claims-and-checks.json'),'edits_from_draft':bind(O/'edits-from-draft.json'),'author':bind(O/'author.py'),'prior_draft':bind(D/'source-ready.json'),'final_validation':bind(P/'root/final-validation.json'),'historical_validation_suffix_exact':True,'anticipated_evidence':claims['anticipated_evidence'],'qualification':'documentation-1 remains immutable. No source or outcome changes; final prose preserves all compiler/source/ledger corrections and first full failure. Evidence links are intended publication paths.'}
dump(O/'source-ready.json',ready)
print(json.dumps(bind(O/'source-ready.json')));print('classes words',len(texts['docs/classes.md'].split()),'ledger bindings',len(checked))
