"""Independent source bindings and literal arithmetic only; no project imports."""
from pathlib import Path
import json
import hashlib
import re
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
O = F / 'private-tests-review-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def bound(path):
    data = Path(path).read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def check(row):
    got = bound(row['path'])
    assert got['bytes'] == row['bytes'] and got['sha256'] == row['sha256'], row['path']

old = json.loads((F / 'private-tests-1/source-ready.json').read_text())
new = json.loads((F / 'private-tests-2/source-ready.json').read_text())
for hold in (old, new):
    for row in hold['files']:
        check(row)
    for key in ('roster', 'oracle', 'bindings', 'published_sources'):
        check(hold[key])
    for row in hold['registrations']:
        check(row['append'])
for row in json.loads(Path(old['bindings']['path']).read_text())['contracts']:
    check(row)
git_rows = json.loads(Path(old['published_sources']['path']).read_text())
for row in git_rows:
    data = subprocess.check_output(['git', 'show', BASE + ':' + row['relative_path']], cwd=F / 'worktree')
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
roster = json.loads(Path(new['roster']['path']).read_text())
extracted = []
for row in new['raw']:
    path = row['relative_path']
    before = Path(row['before']['path']).read_text()
    after = Path(row['raw']['path']).read_text()
    if path.endswith('parser/class_tests.rs'):
        assert after.replace('assert!(unit.anonymous_class(*anonymous).is_some());', 'assert!(unit.anonymous_class(*anonymous));') == before
    elif path.endswith('code/class_storage_tests.rs'):
        assert after.replace('use crate::script::{MAX_STEPS, Native};\n', '') == before
    else:
        assert before == after
    extracted += [{'relative_path': path, 'test': name} for name in re.findall(r'#\[test\]\s*fn ([a-zA-Z0-9_]+)\(', after)]
assert sorted(extracted, key=lambda r:r['test']) == sorted(roster, key=lambda r:r['test'])
assert len(extracted) == 15 and len({r['test'] for r in extracted}) == 15
operations = [4, 15, 18, 6, 8, 8, 16, 4, 8, 5, 4, 3, 8, 3]
assert sum(operations) == new['counts']['measured_helper_or_parser_operations'] == 110
constructor_work = 20 + 2 + 9 + sum(8 + 2*n for n in (6,4,9,11)) + 9 + 14 + 30 + 1 + 10
constructor_extra_heap = 128 + sum(64 + 4*n for n in (6,4,9,11)) + sum(256 + 4*n for n in (6,4,9,11))
assert (constructor_work, constructor_extra_heap) == (187,1648)
assert 10 + 2 + 1 == 13 and 128 + 280 + 272 == 680
assert 8 + 8 + 1 == 17 and 8 + 8 + 8 + 1 == 25
assert 12 + 3 + 2 == 17
for source, first, second, heap in [('',8,0,64),('A',9,2,68),('Café',13,8,80),('𐐀',12,4,72)]:
    units = len(source.encode('utf-16-le'))//2
    assert (8+len(source.encode()), 2*units, 64+4*units) == (first,second,heap)
result = dict(status='clear: inert source checks passed', hold=bound(F/'private-tests-2/source-ready.json'),
              old_hold=bound(F/'private-tests-1/source-ready.json'), git_source_joins=len(git_rows),
              groups=15, operations=110, raw_layout_observation_groups=1,
              two_exact_correction_inverses=True, runtime_test_bytes_unchanged=True,
              independently_derived=dict(constructor_work=constructor_work, constructor_extra_heap=constructor_extra_heap,
                                          method_work=13, method_extra_heap=680, prototype_warm=17, prototype_cold=25,
                                          super_two_hops=17),
              scope='No compiler, project import, test or adapter execution; no candidate test result used.')
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
