from pathlib import Path
import hashlib
import json
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-unicode-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode())

source = r'''function check(v){if(!v)throw new Error('class Unicode oracle');}
var result=(function(){
 function units(s,a){check(s.length===a.length);for(var i=0;i<a.length;i++){check(s.charCodeAt(i)===a[i]);}}
 class Café {}
 var π;π=class {};
 function defaults(字=class {}){return 字;}
 var parameter=defaults(),explicit=class 𐐀 {},é=class {};
 check(Café.name==='Caf\u00E9'&&π.name==='\u03C0'&&parameter.name==='\u5B57');
 check(explicit.name==='\u{10400}'&&é.name==='e\u0301'&&é.name!=='\u00E9');
 units(Café.name,[67,97,102,233]);units(π.name,[960]);units(parameter.name,[23383]);
 units(explicit.name,[55297,56320]);units(é.name,[101,769]);
 var key='雪😀',symbol=Symbol('λ\uD800'),values={[key]:class {},[symbol]:class {}};
 class Methods {[key](){} static [symbol](){}}
 check(values[key].name===key&&Methods.prototype[key].name===key);
 check(values[symbol].name==='[λ\uD800]'&&Methods[symbol].name==='[λ\uD800]');
 units(values[key].name,[38634,55357,56832]);units(Methods.prototype[key].name,[38634,55357,56832]);
 units(values[symbol].name,[91,955,55296,93]);units(Methods[symbol].name,[91,955,55296,93]);
 return 'utf16-names';
})();
'''
# The author source uses raw Python text, with JavaScript escapes written once.
source = source.replace('\\\\u', '\\u')
assert '\\uD800' in source and '\ud800' not in source
case_id = 'naming_unicode_identifiers_and_computed_keys'
row = {
    'id': case_id, 'kind': 'semantic', 'source': source, 'observation': 'result\n',
    'expected': {'type': 'string', 'value': 'utf16-names'}, 'modes': ['sloppy', 'strict'],
    'derivation': 'Declaration, identifier-assignment/default hints and explicit class names retain identifier code points without normalization. String property names retain UTF-16 code units; SetFunctionName brackets a Symbol description without replacing its lone surrogate. Anonymous object-data class values and class method names both preserve those units.',
    'source_file': put(D / 'literals' / (case_id + '.js'), source.encode('utf-8')),
    'observation_file': put(D / 'readbacks' / (case_id + '.js'), b'result\n')
}
cases = obj(D / 'cases.json', [row])
bindings = []
for relative_path in ['src/script.rs', 'src/script/symbols.rs']:
    b = subprocess.check_output(['git', 'show', f'{BASE}:{relative_path}'], cwd=F / 'worktree')
    bindings.append({'base': BASE, 'relative_path': relative_path, 'bytes': len(b),
                     'sha256': hashlib.sha256(b).hexdigest()})
basis = obj(D / 'source-basis.json', {
    'published_bindings': bindings,
    'published_identifier_controls': 'src/script.rs:10382 accepts Unicode ID_Start/Continue including U+10400 and preserves composed/decomposed distinctions.',
    'published_utf16_controls': 'src/script.rs:9180 charCodeAt reads stored code units; :13563 checks UTF-16 escapes and surrogate pairs. src/script/symbols.rs:533 preserves a lone surrogate in Symbol descriptions.',
    'primary_basis': bind(F / 'public-naming-1/spec-basis.json'),
    'source_urls': [
        'https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-setfunctionname',
        'https://tc39.es/ecma262/multipage/syntax-directed-operations.html#sec-runtime-semantics-namedevaluation'
    ],
    'literal_encoding': 'The JS file is valid UTF-8. Lone surrogates occur only as JavaScript ASCII escape text; assertions compare values and individual UTF-16 units.',
    'oracle': 'Source-derived standard semantics and integer code-unit constants; no measured runtime output or production conversion-helper assumptions.'
})
contract = obj(D / 'contract.json', {
    'base': BASE, 'prior_hold': bind(F / 'public-context-1/source-ready.json'),
    'scope': 'One additional public naming row only; existing73 rows remain byte-exact.',
    'counts': {'new_groups': 1, 'new_modes': 2, 'maximum_new_public_calls': 4,
               'composed_groups': 74, 'composed_modes': 148, 'maximum_composed_public_calls': 332},
    'interface': 'Append to existing class_semantics_tests and reuse unchanged observe helper; no registration change.',
    'execution': 'No project commands, JS engine, candidate/producer reads or live edits.'
})
seal = obj(D / 'literals-ready.json', {
    'status': 'frozen independent Unicode naming row before Rust conversion',
    'base': BASE, 'cases': cases, 'source_basis': basis, 'contract': contract,
    'literal_files': [row['source_file'], row['observation_file']], 'author': bind(Path(__file__)),
    'new_groups': 1, 'new_modes': 2, 'project_execution': False
})
print(json.dumps(seal))
