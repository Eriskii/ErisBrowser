function check(v){if(!v)throw new Error('class Unicode oracle');}
var result=(function(){
 function units(s,a){check(s.length===a.length);for(var i=0;i<a.length;i++){check(s.charCodeAt(i)===a[i]);}}
 class Café {}
 var π;π=class {};
 function defaults(字=class {}){return 字;}
 var parameter=defaults(),explicit=class 𐐀 {},é=class {};
 check(Café.name==='Caf\u00E9'&&π.name==='\u03C0'&&parameter.name==='\u5B57');
 check(explicit.name==='\u{10400}'&&é.name==='e\u0301'&&é.name!=='\u00E9');
 units(Café.name,[67,97,102,233]);units(π.name,[960]);units(parameter.name,[23383]);
 units(explicit.name,[55297,56320]);units(é.name,[101,769]);
 var key='雪😀',symbol=Symbol('λ\uD800'),values={[key]:class {},[symbol]:class {}};
 class Methods {[key](){} static [symbol](){}}
 check(values[key].name===key&&Methods.prototype[key].name===key);
 check(values[symbol].name==='[λ\uD800]'&&Methods[symbol].name==='[λ\uD800]');
 units(values[key].name,[38634,55357,56832]);units(Methods.prototype[key].name,[38634,55357,56832]);
 units(values[symbol].name,[91,955,55296,93]);units(Methods[symbol].name,[91,955,55296,93]);
 return 'utf16-names';
})();
