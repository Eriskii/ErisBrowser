from pathlib import Path
import difflib
import hashlib
import json
import re

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-unicode-1'
RELATIVE = 'src/script/class_semantics_tests.rs'

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2, ensure_ascii=True) + '\n').encode())

literal_seal = bind(D / 'literals-ready.json')
assert literal_seal['sha256'] == '40be0d49e5cfc69e88dc1cbd7a26a64883752d596f926df129818ecbb930b238'
rows = json.loads((D / 'cases.json').read_bytes())
assert len(rows) == 1
row = rows[0]
before = (F / 'public-context-1/raw' / RELATIVE).read_bytes()
prior_seal = json.loads((F / 'public-context-1/source-ready.json').read_bytes())
assert hashlib.sha256(before).hexdigest() == prior_seal['files'][0]['raw']['sha256']
old_names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', before.decode(), re.M)
assert len(old_names) == len(set(old_names)) == 73
for key in ['source_file', 'observation_file']:
    assert bind(Path(row[key]['path'])) == row[key]
source = Path(row['source_file']['path']).read_text()
observation = Path(row['observation_file']['path']).read_text()
assert source == row['source'] and observation == row['observation']
assert '"###' not in source and '"###' not in observation
name = 'class_public_' + row['id']
assert name not in old_names
assert row['expected'] == {'type': 'string', 'value': 'utf16-names'}
block = ('#[test]\nfn ' + name + '() {\n    observe(\n        ' + json.dumps(row['id']) + ',\n'
         + '        r###"' + source + '"###,\n        r###"' + observation + '"###,\n'
         + '        Value::String("utf16-names".into()),\n    );\n}\n\n')
assert re.findall(r'r###"(.*?)"###', block, re.S) == [source, observation]
suffix = block.encode('utf-8')
after = before + suffix
assert after[:len(before)] == before
names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', after.decode(), re.M)
assert len(names) == len(set(names)) == 74 and names[:73] == old_names
before_ref = put(D / 'before' / RELATIVE, before)
raw_ref = put(D / 'raw' / RELATIVE, after)
append_ref = put(D / 'append-tests.rs', suffix)
diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                   fromfile='before/' + RELATIVE, tofile='raw/' + RELATIVE))
diff_ref = put(D / 'diffs' / (RELATIVE + '.diff'), diff.encode())
roster = obj(D / 'roster.json', {
    'new_test': {'test_name': name, 'case_id': row['id'], 'modes': row['modes'],
                 'helper': 'unchanged observe', 'source': row['source_file'],
                 'observation': row['observation_file'], 'expected': row['expected']},
    'original_test_names': old_names, 'composed_test_names': names,
    'new_groups': 1, 'new_mode_attempts': 2, 'maximum_new_public_calls': 4,
    'composed_groups': 74, 'composed_modes': 148, 'maximum_composed_public_calls': 332
})
units = {}
for text, expected in [
    ('Café', [67,97,102,233]), ('π', [960]), ('字', [23383]),
    ('𐐀', [55297,56320]), ('é', [101,769]), ('雪😀', [38634,55357,56832]),
    ('[λ\ud800]', [91,955,55296,93])
]:
    encoded = text.encode('utf-16-le', 'surrogatepass')
    actual = [encoded[i] + 256 * encoded[i + 1] for i in range(0, len(encoded), 2)]
    assert actual == expected
    units[text] = expected
checks = obj(D / 'checks.json', {
    'literal_conversion': 'Both frozen JS/readback UTF-8 strings extracted exactly from Rust raw strings; ASCII Value result expectation unchanged.',
    'utf16_constant_derivation': units,
    'original_preservation': 'Removing the single appended test restores the full prior73-row module byte-for-byte.',
    'prior_hold': bind(F / 'public-context-1/source-ready.json'),
    'registration': 'No new registration; root may use the exact append fragment against its formatted prefix.',
    'execution': 'Only external stdlib transcription/encoding checks; no project import, JS/compiler/test commands, live edits or future producer read.'
})
seal = obj(D / 'source-ready.json', {
    'status': 'ready for independent source peer and root additive tests-only import',
    'base': 'f3118ae5787c410648657f7c822efb7014201dd1',
    'frozen_literals': literal_seal, 'cases': bind(D / 'cases.json'),
    'source_basis': bind(D / 'source-basis.json'), 'contract': bind(D / 'contract.json'),
    'files': [{'relative_path': RELATIVE, 'before': before_ref, 'raw': raw_ref, 'diff': diff_ref}],
    'append': append_ref, 'roster': roster, 'checks': checks,
    'authors': [bind(D / 'author-literals.py'), bind(Path(__file__))],
    'new_groups': 1, 'new_mode_attempts': 2, 'composed_groups': 74,
    'registration_changes': 0, 'project_execution': False
})
print(json.dumps(seal))
