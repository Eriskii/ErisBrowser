from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

F=Path('/tmp/eris-class-runtime-plan-1');D=F/'migration-review-1';W=F/'worktree';H=F/'migrations-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_bytes())
def checked(row):
 p=Path(row['path']);assert bind(p)==row;return p.read_bytes()
def put(name,v):
 p=D/name;assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');return bind(p)
hold=load(H/'source-ready.json');assert hold['base']==BASE
checked(hold['selection']);assert len(hold['files'])==2
files=[]
for row in hold['files']:
 rel=row['relative_path'];before=checked(row['before']);raw=checked(row['raw']);diff=checked(row['diff'])
 assert before==subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)==(W/rel).read_bytes()
 old=row['before_literal'].encode();new=row['after_literal'].encode()
 assert before.count(old)==1 and raw.count(new)==1
 assert raw==before.replace(old,new,1) and raw.replace(new,old,1)==before
 expected=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),
                                     fromfile='before/'+rel,tofile='after/'+rel)).encode()
 assert diff==expected
 names=lambda b:re.findall(rb'#\[test\]\s*fn\s+(\w+)',b)
 assert names(before)==names(raw)
 files.append({'relative_path':rel,'before':row['before'],'raw':row['raw'],'diff':row['diff'],
               'published_exact':True,'only_one_literal_replacement':True,'inverse_exact':True,
               'unchanged_test_names':[x.decode() for x in names(raw)]})
script=(W/'src/script.rs').read_text();parser=(W/'src/script/parser.rs').read_text()
legacy=(W/'src/script/parser_legacy.rs').read_text()
assert '"L:class C{}"' in script and '"if(false)class C{}"' in script
assert 'fn direct_parser_matches_frozen_grammar_payloads_and_early_errors' in parser
assert 'format!("{new:?}"),' in parser and 'format!("{old:?}"),' in parser
assert '"\'{unsupported}\' is not supported"' in legacy
cases=load(F/'public-contract-2/cases.json');byid={x['id']:x for x in cases}
assert 'class ClassScopeWitness {}' in byid['global_and_block_lexical']['source']
assert 'var Inferred=class {};' in byid['lexical_names_and_tdz']['source']
assert byid['public_field']['expected_error']=='Unsupported'
assert all(byid[x]['expected_error']=='SyntaxError' for x in ['labelled_class','controlled_statement_class'])
review=put('review.json',{
 'status':'clear for the bounded two-literal migration; future parser diagnostic compatibility remains an integration obligation',
 'findings':[],'hold':bind(H/'source-ready.json'),'selection':hold['selection'],'files':files,
 'independent_public_contract':bind(F/'public-contract-2/source-ready.json'),
 'rationale':['Empty class declarations/expressions are now in the selected supported surface and have independent successful semantic literals.',
              'An uninitialized public field is valid ECMAScript and explicitly deferred, so the replacement preserves the historical Unsupported intent.',
              'Only the two selected literal strings change. Both inverse reconstructions, all old test names, remaining literals/assertions and published source joins are exact.',
              'Labelled and controlled-statement class declarations remain SyntaxError probes; constructor/new.target restrictions and old resource assertions are untouched.'],
 'integration_condition':{
    'test':'parser::tests::direct_parser_matches_frozen_grammar_payloads_and_early_errors',
    'comparison':'Complete Debug-form ScriptError equality, not only error category.',
    'legacy_class_field_error':{'message':"'class' is not supported",'offset':None,'kind':'Unsupported','thrown_name':None,'intrinsic_name':None},
    'obligation':'The new selected field boundary must satisfy the unchanged exact differential assertion, or root must select a separate justified test-only amendment. This review has not read producer code and does not claim that future assertion will pass.'},
 'supporting_sources':[bind(W/'src/script/parser_legacy.rs'),bind(W/'src/script/construction.rs')],
 'execution':'None. Static source/Git/hash inspection only; no live writes, project imports or tests.',
 'audit':bind(D/'audit.py')})
print(json.dumps(review))
