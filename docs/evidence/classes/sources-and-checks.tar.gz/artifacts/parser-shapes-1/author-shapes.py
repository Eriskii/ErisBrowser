from pathlib import Path
import json, hashlib, re, subprocess
N=Path('/tmp/eris-class-runtime-plan-1');O=N/'parser-shapes-1';R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(name,v):
 p=O/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
def declaration(s,name):
 m=re.search(r'(?m)^(?:pub(?:\([^\n]*?\))?\s+)?(?:struct|enum)\s+'+re.escape(name)+r"(?:\b|(?=<))",s);assert m,name
 start=m.start();brace=s.find('{',m.end());semi=s.find(';',m.end())
 if semi!=-1 and (brace==-1 or semi<brace):end=semi+1
 else:
  depth=0;end=None
  for i in range(brace,len(s)):
   if s[i]=='{':depth+=1
   elif s[i]=='}':
    depth-=1
    if depth==0:end=i+1;break
  assert end is not None,name
 while start>0:
  prev=s.rfind('\n',0,start-1)+1;line=s[prev:start].strip()
  if line.startswith('#[') and line.endswith(']'):start=prev
  else:break
 return s[start:end]
def append_fields(s,text):
 assert s.endswith('}');return s[:-1]+text+'}'
specs={
'code':('src/script/code.rs',['ExprId','StmtId','FunctionId','Parameter','Function','Unit','FunctionRef','Expr','PropertyName','ObjectEntry','Stmt','ForBinding','CatchClause']),
'records':('src/script/code/records.rs',['Records']),
'parser':('src/script/parser.rs',['PropertyName','ActiveLabel','Parser']),
'driver':('src/script/parser/driver.rs',['Output','Body','Kind','Transition']),
'expressions':('src/script/parser/driver/expressions.rs',['Frame','Binary','Postfix','NewState','Cover','Array','Object']),
'functions':('src/script/parser/driver/functions.rs',['Frame','State','Context']),
'statements':('src/script/parser/driver/statements.rs',['Frame','Switch','BodyFrame','BodyState','Before']),
'tokens':('src/script/tokens.rs',['Tokens']),
'unchanged_script_leaves':('src/script.rs',['IdentifierToken','TokenKind','Token','DeclarationKind']),
'unchanged_budget':('src/regexp.rs',['Budget'])}
base={};proposed={};source_rows=[];extracted=[]
for group,(path,names) in specs.items():
 b=subprocess.check_output(['git','show',BASE+':'+path],cwd=R);s=b.decode()
 source_rows.append({'path':path,'bytes':len(b),'sha256':sha(b)})
 base[group]={name:declaration(s,name) for name in names};proposed[group]=dict(base[group])
 for name,v in base[group].items():extracted.append({'module':group,'name':name,'source':path,'declaration_sha256':sha(v.encode()),'full_declaration':True})
changes=[]
def add(group,name,text):
 old=proposed[group][name];new=append_fields(old,text);assert new.replace(text+'}', '}',1)==old
 proposed[group][name]=new;changes.append({'module':group,'name':name,'old_declaration_sha256':sha(old.encode()),'new_declaration_sha256':sha(new.encode()),'added_text':text,'inverse':'Delete exactly the appended text immediately before the final declaration brace.'})
add('code','Function','    pub class_kind: Option<ClassKind>,\n')
add('code','Unit','    classes: Records<Class>,\n')
add('code','Expr','    Class(ClassId),\n    SuperCall(Vec<ExprId>),\n    SuperCallSpread(Vec<ExprId>),\n')
add('code','Stmt','    Class(ClassId),\n')
proposed['code']['ClassId']='#[derive(Clone, Copy, Debug, PartialEq, Eq)]\npub(super) struct ClassId(usize);'
proposed['code']['ClassKind']='''#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ClassKind {
    ExplicitBase,
    ExplicitDerived,
    DefaultBase,
    DefaultDerived,
}'''
proposed['code']['ClassElementKind']='''#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ClassElementKind {
    Method,
    Getter,
    Setter,
}'''
proposed['code']['Class']='''#[derive(Debug)]
pub(super) struct Class {
    pub name: Option<String>,
    pub heritage: Option<ExprId>,
    pub constructor: FunctionId,
    pub elements: Vec<ClassElement>,
}'''
proposed['code']['ClassElement']='''#[derive(Debug)]
pub(super) struct ClassElement {
    pub name: PropertyName,
    pub function: FunctionId,
    pub kind: ClassElementKind,
    pub is_static: bool,
}'''
add('parser','Parser','    super_call_allowed: bool,\n    in_class: bool,\n')
add('driver','Output','    Class(ClassId),\n')
add('driver','Kind','    Class(classes::Frame),\n')
proposed['driver']['EntryContext']='''struct EntryContext {
    allow_in: bool,
    strict: bool,
    super_call_allowed: bool,
    in_class: bool,
}'''
add('expressions','Frame','    LeftHandSide,\n    LeftHandSideBase(bool),\n    ClassDone,\n    // Flags: any spread, current spread, saved allow_in, permit postfix update.\n    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),\n')
add('expressions','Postfix','    allow_update: bool,\n')
add('functions','Frame','    // true only for a derived literal constructor; class methods use false.\n    ClassMethod(bool),\n')
add('functions','Context','    super_call_allowed: bool,\n')
add('statements','Frame','    ClassDone,\n')
proposed['classes']={
'Frame':'''pub(super) enum Frame {
    Start { declaration: bool },
    Heritage(State),
    Elements(State),
    Key(State, Header),
    Member(State, PropertyName, Header),
}''',
'State':'''pub(super) struct State {
    name: Option<String>,
    heritage: Option<ExprId>,
    constructor: Option<FunctionId>,
    elements: Vec<code::ClassElement>,
    saved: Context,
}''',
'Header':'''pub(super) struct Header {
    kind: code::ClassElementKind,
    is_static: bool,
    is_constructor: bool,
}''',
'Context':'''struct Context {
    strict: bool,
    allow_in: bool,
    in_class: bool,
}'''}
for version,groups in [('before',base),('proposed',proposed)]:
 for group,decls in groups.items():
  p=O/version/(group+'.rs');p.parent.mkdir(parents=True,exist_ok=True)
  header='// Declaration-only layout contract for '+group+'. No implementations or tests.\n// Names resolve within the corresponding before/proposed type graph.\n\n'
  p.write_text(header+'\n\n'.join(decls.values())+'\n')
for change in changes:
 group,name=change['module'],change['name'];old=base[group][name];new=proposed[group][name]
 assert new.replace(change['added_text']+'}', '}',1)==old
unchanged=[]
for group,decls in base.items():
 for name,old in decls.items():
  if not any(x['module']==group and x['name']==name for x in changes):
   assert proposed[group][name]==old
   unchanged.append(group+'::'+name)
put('declaration-inverse.json',{'base':BASE,'source_bindings':source_rows,'extracted_full_declarations':extracted,'changed_existing_declarations':changes,'unchanged_existing_declarations':unchanged,'new_declarations':[group+'::'+name for group,decls in proposed.items() for name in decls if name not in base.get(group,{})],'complete_old_variants_preserved':True,'all_selected_inverses_exact':True,'project_execution':False})
contract={
'format':1,'status':'Concrete parser/code declaration contract for inert typed layout mirrors, pending root shape acceptance; no implementation or measured sizes.',
'base':BASE,'bindings':{k:bind(N/p) for k,p in [('parser_design','parser-design-1/source-ready.json'),('root_parser_resolutions','root/parser-review-1.json'),('runtime_design','constructor-design-1/source-ready.json'),('public_literal_peer','public-contract-review-1/review.json')]},
'files':'before/*.rs and proposed/*.rs are full declaration-only fragments, not compilable production units. declaration-inverse.json binds every existing declaration and append-only change.',
'graph_rules':[
'Use one consistent before/proposed code graph per mirror. Driver Output::Function is code::Function via the FunctionCode alias, not cfg(test) legacy FunctionCode.',
'Statement Frame::ForTest/ForUpdate/ForBody carry the same-version code::Stmt; retaining this neighbor is essential when Stmt gains Class.',
'Parser and class Frame::Member use parser::PropertyName (Literal includes bool), while code::ClassElement uses code::PropertyName. These are distinct actual types.',
'Function State uses same-version code::Parameter and functions::Context. Driver Kind includes every expression/statement/function/body variant plus the proposed classes::Frame.',
'Keep actual Rc, Vec, String, JsString, Value, RegExp, ScriptError, regexp::Budget, DeclarationKind and typed ID shapes. Do not replace a payload with a guessed byte array or usize surrogate.',
'Records<T>, Tokens, TokenKind, Token, IdentifierToken and Budget are provided unchanged. Mirror actual leaf types not reproduced here through published crate declarations, including their full enums.',
'No repr attributes are introduced. Field and enum order shown is the proposed source declaration order; target ABI remains to be measured.',
'ClassId and child IDs remain private, same-Unit, nonowning edges. Class and functions own only flat vectors/text; no new recursive syntax edge appears.'
],
'state_transitions':[
{'entry':'Expression LeftHandSide','shape':'LeftHandSide computes existing async-call lookahead and uses LeftHandSideBase(bool) around New; its Postfix has allow_update=false. Existing Base(bool) produces allow_update=true. Computed/call resumptions carry the same Postfix without dropping the flag.'},
{'entry':'SuperCall','shape':'Recognize direct super at Unary or LeftHandSide entry before ordinary New parsing. Enter SuperArguments with the four recorded flags, then emit ordinary/spread SuperCall and resume Postfix with the retained update mode. Bare new super() still reaches New/Primary and is a syntax error; parenthesized super() is evaluated through the ordinary cover grammar. No fake callee ExprId.'},
{'entry':'Class primary/declaration','shape':'Expression ClassDone and statement ClassDone consume a driver ClassId output and emit their corresponding flat record. Class State does not duplicate the statement name or store a declaration flag after Start has required the name.'},
{'entry':'Class Context','shape':'Save strict, allow_in and in_class; enable strict/in_class and +In heritage. Heritage/key evaluation preserves outer super/new.target/function/loop/label context. Restore allow_in at the heritage/body boundary and all three flags before ClassId output. The named class lexical environment is runtime state, not a Parser environment.'},
{'entry':'Elements/Key/Member','shape':'Elements handles one semicolon or element per charged continuation transition. Header discriminates static/accessor kind, then sets is_constructor only after a noncomputed literal instance constructor key. Key retains State/Header while existing Key parser evaluates its syntax; Member retains State/PropertyName/Header while the function parser runs. Publish each method FunctionId before storing the element; constructor publication fills State.constructor. Closing brace emits source-free tagged default Function if constructor is None, then code::Class.'},
{'entry':'Function ClassMethod(bool)','shape':'Uses the existing State with unique=true, arrow=false and dynamic=false. The bool sets direct-super permission before parameters; Context saves/restores prior permission. A finished code::Function initially has class_kind=None; Class Member completion applies explicit base/derived tag and constructability to its literal constructor. Ordinary class methods stay None/nonconstructable. Default constructors are emitted directly with their selected tags.'},
{'entry':'Ordinary/arrow/dynamic functions','shape':'Existing Frame variants and State fields remain unchanged. Ordinary/dynamic/object-method entries set super permission false; arrow entry inherits. Class in_class marker is lexical parse containment and remains true through nested functions solely for deferred-private token classification.'},
{'entry':'Driver error cleanup','shape':'EntryContext replaces the old single entry_in scalar snapshot with exactly four flags. On an error, restore those four fields only, without quota refunds or a claim that moved label vectors are reconstructed. Successful dynamic-parameter context handoff stays intentional.'}
],
'root_resolutions':{
'private':'While in_class, convert a current Invalid token beginning at exact source # offset to Unsupported. No successful lexer/token changes or private grammar parsing.',
'legacy':'Add explicit diagnostic panic arms for Class and both SuperCall variants only in the cfg(test) legacy canonical inverse. New tests inspect flat code. Preserve complete old Unsupported error, including message and offset, for root-owned class A{field;} / class C{field;} historical literal migrations.',
'named_evaluation':'Unit::anonymous remains function-only. A separate anonymous_class(ExprId)->Option<ClassId> query may support the runtime hint; it returns Some only for direct Expr::Class with Class.name None. No new code record field is needed for an inferred runtime PropertyKey.'},
'measurement_scope':{
'old_and_new':'Measure full selected code types plus all parser graphs and neighboring payloads, not just the new Class variants. Include size/alignment, initial/grown continuation capacity formulas, Records page/directory formulas and Unit Rc header charge.',
'runtime_join':'Root must combine these with constructor-design complete machine/environment declarations before runtime mirrors and numerical quotas. No numeric resource expectation is selected here.',
'configs':['Rust 1.88 ordinary','Rust 1.88 host','current stable ordinary','current stable host+Vulkan'],
'limits':'Preserve existing source/token/author-work/bootstrap-work/heap/call/stack/prototype ceilings. Shape-driven formula changes require measured migration, not cap changes.'},
'activity':{'implementation_authored':False,'test_payload_authored':False,'project_import_or_execution':False,'build_or_layout_probe_run':False,'live_edits':False},
'qualification':'The fragments freeze record/enum shapes and transitions needed to construct an inert mirror. They do not select all future helper names or implement parser behavior.'}
put('contract.json',contract)
files=[]
for p in sorted(O.rglob('*')):
 if p.is_file() and p.name!='source-ready.json':
  b=p.read_bytes();files.append({'path':str(p.relative_to(O)),'bytes':len(b),'sha256':sha(b)})
put('source-ready.json',{'status':'sealed concrete parser/code shapes for root review and later inert mirrors','base':BASE,'contract':bind(O/'contract.json'),'inverse':bind(O/'declaration-inverse.json'),'files':files,'no_project_execution':True,'no_production_or_tests':True})
print(json.dumps(bind(O/'source-ready.json')))
