// Declaration-only layout contract for records. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

#[derive(Debug)]
pub(super) struct Records<T> {
    pages: Vec<Vec<T>>,
    length: usize,
}
