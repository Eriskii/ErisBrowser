// Declaration-only layout contract for driver. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

enum Output {
    Expression(ExprId),
    Statement(StmtId),
    Body(Body),
    Function(FunctionCode),
    Parameters(functions::State),
    Key(PropertyName),
    Declaration(Stmt),
}

struct Body {
    statements: Vec<StmtId>,
    own_strict: bool,
    has_lexical: bool,
}

enum Kind {
    Expression(expressions::Frame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
}

enum Transition {
    Done(Output),
    Again(Kind),
    Child(Kind, Kind),
}
