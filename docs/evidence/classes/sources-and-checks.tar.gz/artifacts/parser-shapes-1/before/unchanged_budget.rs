// Declaration-only layout contract for unchanged_budget. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

pub(crate) struct Budget {
    pub steps: usize,
    pub allocated: usize,
    pub heap_limit: usize,
    pub stack_limit: usize,
}
