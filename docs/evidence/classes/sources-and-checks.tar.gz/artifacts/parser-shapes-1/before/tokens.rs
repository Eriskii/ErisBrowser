// Declaration-only layout contract for tokens. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

#[derive(Debug, Default)]
pub(super) struct Tokens {
    pages: Vec<Vec<Token>>,
    length: usize,
}
