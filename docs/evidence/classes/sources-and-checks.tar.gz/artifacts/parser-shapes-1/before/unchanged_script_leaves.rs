// Declaration-only layout contract for unchanged_script_leaves. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

#[derive(Clone, Debug)]
struct IdentifierToken {
    value: Rc<str>,
    escaped: bool,
}

#[derive(Clone, Debug)]
enum TokenKind {
    Word(IdentifierToken),
    Number(f64),
    String(JsString),
    Symbol(String),
    RegExp(Rc<RegExp>),
    TemplateStart,
    Invalid(Rc<ScriptError>),
    End,
}

#[derive(Clone, Debug)]
struct Token {
    kind: TokenKind,
    offset: usize,
    line_break_before: bool,
    string_literal: bool,
    use_strict: bool,
    legacy_literal: bool,
}

#[derive(Clone, Copy, Debug, PartialEq)]
enum DeclarationKind {
    Var,
    Let,
    Const,
}
