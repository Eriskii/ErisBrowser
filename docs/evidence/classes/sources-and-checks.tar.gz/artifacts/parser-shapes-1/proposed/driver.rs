// Declaration-only layout contract for driver. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

enum Output {
    Expression(ExprId),
    Statement(StmtId),
    Body(Body),
    Function(FunctionCode),
    Parameters(functions::State),
    Key(PropertyName),
    Declaration(Stmt),
    Class(ClassId),
}

struct Body {
    statements: Vec<StmtId>,
    own_strict: bool,
    has_lexical: bool,
}

enum Kind {
    Expression(expressions::Frame),
    Statement(statements::Frame),
    Function(functions::Frame),
    Body(statements::BodyFrame),
    Class(classes::Frame),
}

enum Transition {
    Done(Output),
    Again(Kind),
    Child(Kind, Kind),
}

struct EntryContext {
    allow_in: bool,
    strict: bool,
    super_call_allowed: bool,
    in_class: bool,
}
