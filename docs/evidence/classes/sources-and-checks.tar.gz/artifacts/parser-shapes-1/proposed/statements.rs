// Declaration-only layout contract for statements. No implementations or tests.
// Names resolve within the corresponding before/proposed type graph.

pub(super) enum Frame {
    Start { declarations: bool },
    Controlled,
    ControlledDone,
    Expression,
    Declaration(bool),
    DeclarationDone,
    DeclarationDefault(Vec<(String, Option<ExprId>)>, DeclarationKind, String, bool),
    Function(String),
    Block,
    Label(usize, usize),
    SwitchExpression,
    SwitchCase(Switch),
    SwitchNext(Switch),
    SwitchStatement(Switch, Option<ExprId>, Vec<StmtId>),
    IfCondition,
    IfYes(ExprId),
    IfNo(ExprId, StmtId),
    WhileCondition,
    WhileBody(ExprId),
    DoBody,
    DoCondition(StmtId),
    ForDeclaration(bool),
    ForExpression(bool, bool),
    ForTest(Option<Stmt>),
    ForUpdate(Option<Stmt>, Option<ExprId>),
    ForBody(Option<Stmt>, Option<ExprId>, Option<ExprId>),
    ForInObject(ForBinding),
    ForInBody(ForBinding, ExprId),
    ForOfObject(ForBinding),
    ForOfBody(ForBinding, ExprId),
    Return,
    Throw,
    TryBody,
    CatchBody(StmtId, Option<String>),
    FinallyBody(StmtId, Option<CatchClause>),
    ClassDone,
}

pub(super) struct Switch {
    value: ExprId,
    cases: Vec<(Option<ExprId>, Vec<StmtId>)>,
    default: bool,
    lexical: bool,
}

pub(super) enum BodyFrame {
    Start { block: bool, directive: bool },
    Waiting(BodyState, Before),
}

pub(super) struct BodyState {
    block: bool,
    directive: bool,
    start: usize,
    prologue: bool,
    body: Body,
}

pub(super) struct Before {
    pos: usize,
    string: bool,
    strict: bool,
}
