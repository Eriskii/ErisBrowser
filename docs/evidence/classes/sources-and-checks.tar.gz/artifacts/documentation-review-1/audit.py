"""Independent documentation source/evidence checks, using only stdlib and read-only Git."""
from pathlib import Path, PurePosixPath
from collections import Counter
import difflib, hashlib, json, re, subprocess

F=Path('/tmp/eris-class-runtime-plan-1')
W=F/'worktree'
D=F/'documentation-review-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
DOCS={'README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/classes.md'}
EVIDENCE={'docs/evidence/classes/manifest.json','docs/evidence/classes/sources-and-checks.tar.gz'}
def bind(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(n):return json.loads((F/n).read_bytes())
def write(n,value):
    p=D/n;p.write_text(json.dumps(value,indent=2)+'\n');return bind(p)

verified={}
def bindings(value):
    if isinstance(value,dict):
        if {'path','bytes','sha256'}<=value.keys() and str(value['path']).startswith('/'):
            p=Path(value['path']);actual=bind(p)
            assert all(actual[k]==value[k] for k in actual),p
            verified[str(p)]=actual
        for child in value.values():bindings(child)
    elif isinstance(value,list):
        for child in value:bindings(child)

seal=load('documentation-2/source-ready.json')
bindings(seal)
bindings(load('documentation-2/claims-and-checks.json'))
rows=seal['files'];assert len(rows)==6
names=[r.get('relative',r.get('relative_path')) for r in rows];assert set(names)==DOCS
texts={};history=[];links=[]
for name,row in zip(names,rows):
    raw=Path(row['raw']['path']).read_bytes();texts[name]=raw.decode()
    if name!='docs/classes.md':
        before=Path(row['before']['path']).read_bytes()
        published=subprocess.check_output(['git','show',BASE+':'+name],cwd=W)
        assert before==published,name
    else:before=b''
    diff=Path(row['diff']['path']).read_text()
    # The held diff is an inspectable exact unified replacement, not a second oracle.
    content=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='/dev/null' if row.get('new') else 'a/'+name,tofile='b/'+name))
    assert diff==content,(name,'diff')
    if name=='docs/VALIDATION.md':
        suffix=before.split(b'\n',1)[1]
        assert raw.endswith(suffix)
        history.append({'path':name,'previous_body_without_title_bytes':len(suffix),'sha256':hashlib.sha256(suffix).hexdigest(),'exact_suffix':True})
    added='\n'.join(line[1:]for line in diff.splitlines()if line.startswith('+')and not line.startswith('+++'))
    assert not re.search(r'PENDING|PLACEHOLDER|TODO|TBD|final validation pending|publication is pending',added,re.I),name
    for target in re.findall(r'\]\(([^)]+)\)',added):
        target=target.split('#',1)[0]
        if not target or '://' in target:continue
        resolved=Path(name).parent/target
        # Normalize lexical ../ links without following live filesystem symlinks.
        parts=[]
        for part in PurePosixPath(resolved.as_posix()).parts:
            if part=='..':parts.pop()
            elif part!='.':parts.append(part)
        resolved='/'.join(parts)
        assert resolved in DOCS or resolved in EVIDENCE or (W/resolved).is_file(),(name,target)
        links.append({'source':name,'target':target,'resolved':resolved,'future_evidence':resolved in EVIDENCE})

inverse=dict(texts)
for edit in reversed(load('documentation-2/edits-from-draft.json')):
    name=edit['relative'];assert inverse[name].count(edit['new'])==1
    inverse[name]=inverse[name].replace(edit['new'],edit['old'],1)
for name,text in inverse.items():assert text==(F/'documentation-1/raw'/name).read_text(),name

ledger=load('root/final-validation.json');peer=load('validation-review-1/final-review.json')
assert ledger['status']=='pass'and peer['status']=='clear'
bindings(ledger);bindings(peer)
final=load('source-final.json');parent=load('source-parent.json')
assert (F/'source-final.json').read_bytes()==(F/'source-candidate-2.json').read_bytes()
assert final['base']==BASE
assert len(final['source_sha256'])==1834
changed={p for p,h in final['source_sha256'].items()if parent['source_sha256'].get(p)!=h}
assert len(changed)==30 and changed==set(ledger['source']['changed_paths'])
for path,h in final['source_sha256'].items():assert bind(W/path)['sha256']==h,path
assert all(parent['source_sha256'].get(p)==h for p,h in final['source_sha256'].items()if p.startswith('tools/')or p.startswith('tests/conformance/')or p.startswith('tests/upstream/'))

suite_rows=[]
for row in ledger['suites']['configurations']:
    raw=Path(row['candidate']['log']['path']).read_text()
    totals=re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',raw,re.M)
    values=[sum(int(t[i])for t in totals)for i in range(3)]
    assert len(totals)==53 and values==[row['candidate']['passed'],0,0]
    assert row['candidate']['passed']-row['parent']['passed']==98
    assert len(row['added'])==len(set(row['added']))==98
    assert row['public_groups']==80 and row['public_mode_attempts']==164
    assert row['private_groups']==16 and row['private_measured_operations']==114
    assert row['browser_groups']==2 and row['private_raw_layout_observation_groups']==1
    suite_rows.append({'config':row['config'],'result_rows':53,'passed':values[0],'failed':0,'ignored':0,'new_groups':98})
assert [r['passed']for r in suite_rows]==[3344,3698]

profiles=load('root/profile-validation-1.json');bindings(profiles)
profile_rows=[];transitions=[];counts=Counter();case_count=control_count=0
for row in profiles['profiles']:
    before=json.loads(Path(row['parent']['path']).read_bytes())
    after=json.loads(Path(row['report']['path']).read_bytes())
    assert after['full_test262_conformance'] is False
    assert after['harness_preflight_passed'] is True
    assert after['harness_preflight']==before['harness_preflight']
    assert all(r['verified'] is True for r in after['harness_preflight'])
    assert len(after['cases'])==len(before['cases'])==row['cases']
    assert len(after['harness_preflight'])==row['controls']
    for field in ['runner_policy','runner_policy_sha256','corpus_manifest_sha256']:
        assert before[field]==after[field],(row['name'],field)
    assert 'class' not in after['runner_policy']['supported_features']
    observed=Counter(c['status']for c in after['cases']);assert dict(observed)==after['counts']==row['counts']
    for old,new in zip(before['cases'],after['cases']):
        for key in ['id','file','mode','case_sha256','source_sha256','expected_negative']:
            assert old[key]==new[key],(row['name'],key)
        assert not(old['status']=='passed'and new['status']!='passed')
        if old!=new:
            transitions.append({'profile':row['name'],'id':new['id'],'before':old,'after':new})
    counts.update(observed);case_count+=len(after['cases']);control_count+=len(after['harness_preflight'])
    profile_rows.append({'profile':row['name'],'cases':row['cases'],'controls':row['controls'],'counts':dict(observed),'policies_corpus_controls_exact':True})
assert case_count==1330 and control_count==640 and len(profile_rows)==8
assert dict(counts)=={'passed':1222,'failed':60,'unsupported':48}
assert len(transitions)==30
assert Counter((r['before']['status'],r['after']['status'])for r in transitions)=={('unsupported','passed'):20,('unsupported','failed'):10}
failed=[r for r in transitions if r['after']['status']=='failed']
assert sum(r['after']['observation']['error_type']=='SyntaxError'for r in failed)==8
assert sum('subclass-species-constructor-reject-count.js' in r['id']for r in failed)==2

checks=write('checks.json',{'status':'source/evidence checks complete; no project execution','doc_seal':bind(F/'documentation-2/source-ready.json'),'verified_bindings':list(verified.values()),'historical_validation':history,'all_six_draft_inverses_exact':True,'links':links,'source_inputs':1834,'changed_sources':30,'source_final_equals_candidate2':True,'suites':suite_rows,'profiles':profile_rows,'profile_totals':dict(cases=case_count,controls=control_count,counts=dict(counts),changed_records=30,unsupported_to_passed=20,unsupported_to_failed=10,previous_pass_regressions=0),'transitions':transitions,'raw_log_checks':'53 successful result rows in each complete full-suite log; counts recomputed rather than inferred from summaries.'})
print(json.dumps(checks))
