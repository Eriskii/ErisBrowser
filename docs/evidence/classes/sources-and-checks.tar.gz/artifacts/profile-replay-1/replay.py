"""Root-run serial validation against frozen parents; standard library only.

Authoring this file does not execute it. It deliberately never records baselines.
Use --check-only to inspect already completed reports without invoking adapters.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HOLD = Path(__file__).resolve().parent
F = HOLD.parent
W = F / 'worktree'
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
IMMUTABLE = ('suite', 'full_test262_conformance', 'repository', 'revision',
             'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256',
             'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def require(condition, message):
    if not condition:
        raise ValueError(message)


def read_binding(row):
    path = Path(row['path'])
    require(bound(path) == row, f'changed frozen input: {path}')
    return json.loads(path.read_bytes())


def check_sources(contract):
    for row in contract['preserved_files']:
        path = W / row['path']
        data = path.read_bytes()
        require(len(data) == row['bytes'] and digest(data) == row['sha256'],
                f'preserved source/corpus/baseline changed: {row["path"]}')
    for directory in contract['corpus_directories']:
        expected = {row['path'] for row in contract['preserved_files']
                    if row['path'].startswith(directory + '/')}
        actual = {p.relative_to(W).as_posix() for p in (W / directory).rglob('*') if p.is_file()}
        require(actual == expected, f'corpus path set changed: {directory}')
    require(bound(F / 'run-tool.py') == contract['run_tool'], 'run-tool wrapper changed')


def case_identity(row):
    return {key: row[key] for key in IDENTITY}


def control_identity(row):
    result = {key: value for key, value in row.items() if key not in ('verified', 'result')}
    result['result'] = case_identity(row['result'])
    return result


def compare_report(profile, parent, report, binary, returncode, command, receipt):
    errors = []
    def check(condition, message):
        if not condition:
            errors.append(message)

    check(set(report) == set(parent), 'report field schema changed')
    for key in IMMUTABLE:
        check(report.get(key) == parent[key], f'immutable report field changed: {key}')
    check(report.get('binary_sha256') == binary['sha256'], 'report binary hash is not frozen candidate')
    check(Path(report.get('binary', '')).resolve() == Path(binary['path']).resolve(), 'report binary path differs')
    policy = report.get('runner_policy')
    check(isinstance(policy, dict) and digest(json.dumps(policy, sort_keys=True).encode()) == report.get('runner_policy_sha256'), 'policy digest does not recompute')
    cases = report.get('cases', [])
    controls = report.get('harness_preflight', [])
    check(type(cases) is list and type(controls) is list, 'case/control arrays are not lists')
    if type(cases) is not list or type(controls) is not list:
        return dict(name=profile['name'], errors=errors)
    check([case_identity(row) for row in cases] == [case_identity(row) for row in parent['cases']],
          'complete ordered case identities differ (including missing/extra/duplicate cases)')
    check([control_identity(row) for row in controls] == [control_identity(row) for row in parent['harness_preflight']],
          'complete ordered control identities/expectations/prerequisites differ')
    check(report.get('harness_preflight_passed') is True, 'canonical preflight gate is unhealthy')
    check(all(row.get('verified') is True for row in controls), 'unverified control')
    check([row['result'].get('status') for row in controls] == [row['result']['status'] for row in parent['harness_preflight']],
          'control classification differs from healthy retained parent')
    control_map = {(row['name'], row['result']['mode']): row for row in controls}
    check(len(control_map) == len(controls), 'duplicate control identity')
    for row in controls:
        for prerequisite in row['prerequisites']:
            target = control_map.get((prerequisite['name'], prerequisite['mode']))
            check(target is not None and target.get('verified') is True, 'prerequisite target is missing or unverified')
            if target is None:
                continue
            if 'verified' in prerequisite:
                check(prerequisite['verified'] is True, 'unverified prerequisite reference')
            for key in ('case_sha256', 'source_sha256', 'id'):
                if key in prerequisite:
                    check(prerequisite[key] == target['result'][key], 'prerequisite result identity mismatch')
            if 'expected' in prerequisite:
                check(prerequisite['expected'] == target['expected'], 'prerequisite expectation mismatch')
    counts = dict(Counter(row['status'] for row in cases))
    check(report.get('counts') == counts, 'case counts do not recompute')
    check(report.get('mode_cases') == len(cases) == profile['cases'], 'mode count differs')
    check(len(controls) == profile['controls'], 'control count differs')
    check(not (set(counts) - {'passed', 'failed', 'unsupported'}), 'bad or unknown case status reached')
    old_cases = {row['id']: row for row in parent['cases']}
    regressions, improvements, changes = [], [], []
    for row in cases:
        old = old_cases.get(row['id'])
        if old is None:
            continue
        if old != row:
            kind = 'raw-record-only' if old['status'] == row['status'] else 'nonpass-transition'
            if old['status'] == 'passed' and row['status'] != 'passed':
                regressions.append(row['id'])
                kind = 'regression'
            elif old['status'] != 'passed' and row['status'] == 'passed':
                improvements.append(row['id'])
                kind = 'improvement'
            changes.append(dict(id=row['id'], change=kind, before=old, after=row))
    control_changes = [dict(index=index, before=old, after=new)
                       for index, (old, new) in enumerate(zip(parent['harness_preflight'], controls)) if old != new]
    baseline = json.loads((W / profile['baseline']).read_bytes())
    current_cases = {row['id']: row for row in cases}
    baseline_regressions = [name for name, old in baseline['cases'].items()
                            if name in current_cases and old['status'] == 'passed' and current_cases[name]['status'] != 'passed']
    baseline_improvements = [name for name, old in baseline['cases'].items()
                             if name in current_cases and old['status'] != 'passed' and current_cases[name]['status'] == 'passed']
    check(report.get('regressions') == baseline_regressions, 'reported baseline regressions do not recompute')
    check(report.get('improvements') == baseline_improvements, 'reported baseline improvements do not recompute')
    check(not regressions and not baseline_regressions, 'new regression against parent or preserved baseline')
    check(returncode == 0, f'profile command exited {returncode}')
    return dict(name=profile['name'], profile=profile['profile'], cases=len(cases), controls=len(controls),
                counts=counts, parent_counts=parent['counts'], command=command, receipt=receipt,
                regressions=regressions, improvements=improvements,
                other_status_changes=[row['id'] for row in changes if row['change'] == 'nonpass-transition'],
                case_record_changes=changes, control_record_changes=control_changes,
                complete_cases_equal=cases == parent['cases'], complete_controls_equal=controls == parent['harness_preflight'],
                errors=errors)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    require(args.attempt > 0, 'attempt must be positive')
    contract = json.loads((HOLD / 'contract.json').read_bytes())
    check_sources(contract)
    parents = {p['name']: read_binding(p['parent']) for p in contract['profiles']}
    binaries = {kind: bound(F / f'eris-js-{kind}-1') for kind in ('ordinary', 'host')}
    paths = [F / f'upstream-{p["name"]}-{args.attempt}.json' for p in contract['profiles']]
    summary_path = F / 'root' / f'profile-validation-{args.attempt}.json'
    require(not summary_path.exists(), 'summary already exists; choose a new attempt')
    if not args.check_only:
        for profile, path in zip(contract['profiles'], paths):
            label = f'upstream-{profile["name"]}-{args.attempt}'
            require(not path.exists() and not (F / 'validation' / f'{label}.json').exists()
                    and not (F / 'validation' / f'{label}.log').exists(), 'run output already exists: ' + label)
    rows = []
    for profile, path in zip(contract['profiles'], paths):
        check_sources(contract)
        binary = binaries[profile['binary_kind']]
        require(bound(Path(binary['path'])) == binary, 'binary changed before profile')
        label = f'upstream-{profile["name"]}-{args.attempt}'
        command = [sys.executable, '-B', 'tools/test262_conformance.py', '--binary', binary['path'],
                   '--profile', profile['profile'], '--output', str(path), '--baseline', profile['baseline'],
                   '--jobs', '1']
        if not args.check_only:
            subprocess.run([sys.executable, '-B', str(F / 'run-tool.py'), label, *command], check=False)
        record_path = F / 'validation' / f'{label}.json'
        try:
            record = json.loads(record_path.read_bytes())
            require(record['command'] == command, 'unexpected recorded command')
            require(record['log'] == f'{label}.log', 'unexpected log path')
            require(digest((F / 'validation' / record['log']).read_bytes()) == record['sha256'], 'log hash mismatch')
            report = json.loads(path.read_bytes())
            row = compare_report(profile, parents[profile['name']], report, binary, record['exit'], command, bound(record_path))
            row['report'] = bound(path)
            row['parent'] = profile['parent']
        except (OSError, ValueError, KeyError, TypeError) as error:
            row = dict(name=profile['name'], errors=[f'incomplete or malformed retained evidence: {error}'])
        rows.append(row)
        require(bound(Path(binary['path'])) == binary, 'binary changed during profile')
        print(json.dumps(dict(name=profile['name'], counts=row.get('counts'), changes=len(row.get('case_record_changes', [])), errors=row['errors'])), flush=True)
    check_sources(contract)
    require(all(bound(Path(row['path'])) == row for row in binaries.values()), 'binary changed after replays')
    cases = sum(row.get('cases', 0) for row in rows)
    controls = sum(row.get('controls', 0) for row in rows)
    healthy = cases == contract['cases'] and controls == contract['controls'] and not any(row['errors'] for row in rows)
    result = dict(status='pass' if healthy else 'fail', contract=bound(HOLD / 'contract.json'),
                  script=bound(Path(__file__)), binaries=binaries, profiles=rows, cases=cases, controls=controls,
                  expected_cases=contract['cases'], expected_controls=contract['controls'],
                  policy_corpus_baseline_source_preservation=True,
                  comparison='Complete ordered identities and all raw records compared with retained parents. Candidate binary hashes are frozen for this run; equality to old binaries is intentionally not required. All record/status changes retained; no baseline written.',
                  regression_rule='A previously passed case becoming nonpassed is a regression. Every other nonpass status transition remains explicit, never relabeled as an improvement.')
    with summary_path.open('x') as handle:
        json.dump(result, handle, indent=2)
        handle.write('\n')
    print(json.dumps(bound(summary_path)), flush=True)
    return 0 if healthy else 1


if __name__ == '__main__':
    sys.exit(main())
