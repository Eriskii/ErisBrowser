"""Freeze a stdlib-only replay contract from published Git and retained reports."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
H = F / 'profile-replay-1'
W = F / 'worktree'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'
PROFILES = [('aggregate-error', 'aggregate-error', 'ordinary'),
            ('existing', 'promise-methods-async', 'host'),
            ('all', 'promise-all', 'host'), ('race', 'promise-race', 'host'),
            ('settled', 'promise-all-settled', 'host'), ('any', 'promise-any', 'host'),
            ('with-resolvers', 'promise-with-resolvers', 'ordinary'), ('try', 'promise-try', 'host')]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def write(name, value):
    p = H / name
    assert not p.exists()
    p.write_text(json.dumps(value, indent=2) + '\n')
    return bound(p)

profiles = []
corpus_directories = []
paths = ['tools/test262_conformance.py', 'tools/import_test262.py', 'tools/html_conformance.py']
for name, profile, binary_kind in PROFILES:
    parent_path = F / 'replay-parent' / f'upstream-{name}-1.json'
    parent = json.loads(parent_path.read_bytes())
    baseline_path = f'tests/conformance/test262-{profile}-current.json'
    baseline = json.loads((W / baseline_path).read_bytes())
    assert parent['harness_preflight_passed'] is True
    assert all(row['verified'] is True for row in parent['harness_preflight'])
    assert len({row['id'] for row in parent['cases']}) == len(parent['cases'])
    assert dict(Counter(row['status'] for row in parent['cases'])) == parent['counts']
    compact = {row['id']: {k: row[k] for k in ('status', 'case_sha256', 'source_sha256')} for row in parent['cases']}
    assert compact == baseline['cases']
    for field in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256'):
        assert parent[field] == baseline[field]
    assert sha(json.dumps(parent['runner_policy'], sort_keys=True).encode()) == parent['runner_policy_sha256']
    corpus = f'tests/upstream/test262-{profile}'
    manifest = (W / corpus / 'manifest.json').read_bytes()
    assert sha(manifest) == parent['corpus_manifest_sha256']
    corpus_directories.append(corpus)
    paths += [baseline_path, corpus]
    profiles.append(dict(name=name, profile=profile, binary_kind=binary_kind, baseline=baseline_path,
                         parent=bound(parent_path), cases=len(parent['cases']), controls=len(parent['harness_preflight']),
                         parent_counts=parent['counts'], policy_sha256=parent['runner_policy_sha256'],
                         corpus_manifest_sha256=parent['corpus_manifest_sha256']))
tree = subprocess.check_output(['git', 'ls-tree', '-rz', BASE, '--', *paths], cwd=W)
files = []
for item in tree.split(b'\0'):
    if not item:
        continue
    header, raw_path = item.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    assert kind == 'blob' and mode == '100644'
    path = raw_path.decode()
    data = (W / path).read_bytes()
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == oid
    files.append(dict(path=path, bytes=len(data), sha256=sha(data), published_git_blob=oid))
files.sort(key=lambda row: row['path'])
for corpus in corpus_directories:
    assert {p.relative_to(W).as_posix() for p in (W / corpus).rglob('*') if p.is_file()} == {row['path'] for row in files if row['path'].startswith(corpus + '/')}
assert sum(row['cases'] for row in profiles) == 1330
assert sum(row['controls'] for row in profiles) == 640
contract = write('contract.json', dict(
    status='Frozen source-only replay contract; no candidate outcomes observed or assumed', base=BASE,
    cases=1330, controls=640, profiles=profiles, corpus_directories=corpus_directories,
    preserved_files=files, run_tool=bound(F / 'run-tool.py'),
    result_policy='Retain all full case/control record changes. Reject missing/extra/reordered identities, unhealthy controls, changed policies/corpus/baselines and any passed-to-nonpassed regression. Improvements and other nonpass transitions are reported without baseline rewrites.',
    binaries='Root builds/freezes F/eris-js-ordinary-1 and F/eris-js-host-1. Runner binds actual new file bytes before execution and verifies stable hashes throughout; no equality to old adapter hashes.',
    execution='Root only: eight serial unchanged runner commands, jobs1, existing baselines read-only. No project module import by checker. Full report and raw log retained for every attempted profile.'))
ast.parse((H / 'replay.py').read_text())
source = (H / 'replay.py').read_text()
assert '--record-baseline' not in source and 'import test262' not in source
checks = write('author-checks.json', dict(
    status='Source and artifact checks passed; replay script not executed',
    profiles=8, parent_cases=1330, parent_controls=640, preserved_files=len(files),
    exact_parent_baseline_compact_rows=True, parent_policy_digests_recomputed=True,
    all_published_git_blob_joins=True, full_selected_corpus_paths_exact=True,
    ast_syntax_valid=True, no_record_baseline_argument=True,
    note='Ordinary and host prerequisite schemas are distinct and are resolved against all verified target rows. Host expected labels such as completion-error are semantic labels rather than result.status; retained healthy result classifications are compared separately. Expected future case counts by status or outcome changes are not selected.'))
ready = write('source-ready.json', dict(
    status='External replay runner/checker ready for root source review and later serial execution',
    base=BASE, script=bound(H / 'replay.py'), contract=contract, checks=checks,
    authoring=bound(H / 'author.py'),
    inputs=[bound(F / 'root/selection-1.json'), bound(F / 'root/setup.json'),
            bound(Path('/tmp/eris-promise-try-upstream-plan-1/root/replay-profiles.py'))],
    run='python3 -B /tmp/eris-class-runtime-plan-1/profile-replay-1/replay.py --attempt 1',
    check_only='python3 -B /tmp/eris-class-runtime-plan-1/profile-replay-1/replay.py --attempt 1 --check-only',
    outputs='F/upstream-{short}-{attempt}.json; F/validation/upstream-{short}-{attempt}.{json,log}; F/root/profile-validation-{attempt}.json. No existing output is overwritten.',
    limitations='No project code, adapters, tests or builds were executed by author. Parent records establish the denominator only; root must inspect actual changed outcomes and final candidate evidence.'))
print(json.dumps(ready))
