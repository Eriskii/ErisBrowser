# JavaScript classes

The interpreter now supports a bounded class subset: named declarations, named
and anonymous expressions, base and derived constructors, public instance and
static methods, getters and setters, and literal or computed string/Symbol
keys. Class syntax uses flat compiled records and parser/runtime continuations.
The behavior follows the selected [class definition](https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-runtime-semantics-classdefinitionevaluation)
and [constructor](https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ecmascript-function-objects-construct-argumentslist-newtarget)
algorithms; this is not complete class or ECMAScript conformance.

Class declarations have a mutable outer lexical binding. An explicit class name
also has a distinct immutable inner binding, which remains in its temporal dead
zone while heritage and computed member names are evaluated. Anonymous classes
receive their own strict lexical environment too. Named evaluation supplies
inferred constructor names before static members are defined, so a later static
`name` or `length` definition is preserved. Methods are strict and cannot be used
as constructors. Member definitions preserve source order and ordinary data or
accessor descriptor behavior, including paired getters/setters and computed
Symbol keys.

Calling a class without `new` throws before parameter defaults or its body.
Base construction reads the original `new.target` prototype and allocates the
receiver before parameter evaluation. Derived construction starts with
uninitialized `this`: returning an object without calling `super()` is valid;
returning a non-undefined primitive throws, and falling through without an
initialized receiver throws ReferenceError.

Direct `super()` captures the current internal superclass before evaluating its
arguments. Parent construction happens before the duplicate-`super()` binding
check, so a second parent call can perform effects or throw first. Default
derived constructors forward the incoming argument list directly without reading
an Array iterator. Explicit rest/spread constructors use the existing iterable
machinery. Bound constructors and alternate `new.target` retain their existing
rules. An escaped arrow keeps the constructor activation, original `new.target`
and uninitialized receiver even after an object was returned; a later `super()`
uses the then-current internal superclass.

Native Promise subclasses keep genuine Promise state and existing capability,
species, reaction and microtask behavior. This adds no new Promise host protocol
or upstream feature admission. Existing class-tagged upstream rows remain
excluded by unchanged profile policies; results in older chapters belong to
their recorded checkpoints.

Fields, private elements, static blocks, `super` property access, generator and
async methods remain explicitly unsupported. Modules, decorators, async
functions, multiple realms and the other documented language gaps remain
outside this slice.

The selected accounting preserves existing helper tariffs and adds class-only
admission for names, environments, factories, member publication and constructor
state. UTF-16 name storage and arena/order-vector growth are prepaid. Earlier
author effects remain when later admission refuses. Public terminal failures
stop catch/finally work and leave unstarted jobs suspended under the existing
observer; a private helper alone does not create that observer boundary.

Four complete-shape probes observed an Environment increase from 96 to 112 bytes.
Its retained logical allowance rises from 176 to 192 bytes, adding 32 accounted
bytes for the two initial environments. The compiled Unit grows from 136 to 168
bytes and the parser continuation union from 112 to 120 bytes. The runtime
Function, Value, ScriptObject and 184-byte machine frame are unchanged. These
are recorded target layouts and logical charges, not process-memory or speed
measurements; final candidate shape and startup checks are pending. Author work
stays at 100,000 units, trusted initialization at 1,000,000 and cumulative heap
accounting at 8 MiB.

The first compiled candidate passes all **79 public class groups**, covering
**162 mode attempts** across semantic, syntax-error, unsupported and terminal
cases. Initial compilation found a sibling-visibility error: the existing
`constructed_prototype` helper was private to its module. Widening it to
`pub(super)` preserved its body and tariff; no public expectation changed.

**Final validation pending:** private quota controls, complete Rust suites,
strict checks, actual production layouts/startup, browser/worker witnesses,
upstream replay comparisons and final source closure will be recorded here
after root verification. The focused result does not establish those checks,
full compatibility, production security, hardware Vulkan execution or a
Chromium performance result.

The final [evidence manifest](evidence/classes/manifest.json) and
[source/check archive](evidence/classes/sources-and-checks.tar.gz) are reserved
for the completed checkpoint; their publication is pending.
