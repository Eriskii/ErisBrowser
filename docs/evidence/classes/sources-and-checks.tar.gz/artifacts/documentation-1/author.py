from pathlib import Path
import subprocess,json,hashlib,difflib,re
F=Path('/tmp/eris-class-runtime-plan-1');O=F/'documentation-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def bound(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
old={};raw={};edits=[]
def read(path):
 if path not in old:
  old[path]=subprocess.check_output(['git','show',BASE+':'+path],cwd=F/'worktree').decode();raw[path]=old[path]
 return raw[path]
def edit(path,before,after):
 s=read(path);assert s.count(before)==1,(path,before[:70]);raw[path]=s.replace(before,after,1);edits.append({'relative':path,'before':before,'after':after})
readme='''[JavaScript classes](docs/classes.md) now support declarations and expressions,
base/derived construction, public methods/accessors and native Promise
subclasses. Strict lexical bindings, `super()` ordering, alternate `new.target`
and retained arrow activations share the existing runtime limits. Fields,
private elements, static blocks, `super` properties and async/generator methods
remain unsupported. This runtime change does not enable the `class` feature in
upstream profile policies; earlier profile counts below retain their checkpoint
scope. The first focused run passes 79 public groups across 162 mode attempts;
remaining checkpoint validation is pending.

'''
anchor='[Promise construction and reactions](docs/promise-foundation.md)'
edit('README.md',anchor,readme+anchor)
edit('README.md','four upstream Promise modes; array/object spread and classes remain unfinished.','four upstream Promise modes; array/object spread remains unfinished.')
roadmap='''[The class runtime slice](classes.md) now covers declarations/expressions,
strict lexical names, public methods/accessors and base/derived construction,
including direct `super()`, alternate `new.target`, escaped arrows and native
Promise subclasses. Fields, private elements, static blocks, `super` properties
and async/generator methods remain future work. Upstream class feature admission
is a separate step; the profile results below retain their historical scope.
The first 79 public groups pass in 162 mode attempts. Final quota, full-suite,
browser and replay validation remains pending for this checkpoint.

'''
anchor='[Promise construction and reactions](promise-foundation.md)'
edit('docs/ROADMAP.md',anchor,roadmap+anchor)
compat='''[JavaScript classes](classes.md) now include named declarations, named/anonymous
expressions, public methods/accessors, strict lexical bindings and base/derived
constructors. Direct `super()`, alternate `new.target`, retained arrows and
native Promise subclasses are covered by the selected slice. Fields, private
elements, static blocks, `super` property access and async/generator methods
remain unsupported. Profile feature policies are unchanged; older recorded
class exclusions and parser outcomes below are checkpoint evidence, not new
class-profile results. The 79-group public check passes; final checkpoint
validation remains pending.

'''
s=read('docs/COMPATIBILITY.md');first=s.find('\n\n')+2
edit('docs/COMPATIBILITY.md',s[:first],s[:first]+compat)
edit('docs/COMPATIBILITY.md','false operands retain their outer grammar context. Array/object spread and\nclasses remain unfinished.','false operands retain their outer grammar context. Array/object spread remains\nunfinished; the later class subset is described above.')
edit('docs/COMPATIBILITY.md','constructors/this/instanceof and basic prototypes, ordinary call/new spread arguments','constructors/this/instanceof and basic prototypes, class declarations/expressions with public methods/accessors and base/derived super construction, ordinary call/new spread arguments')
edit('docs/COMPATIBILITY.md','Full ECMAScript, classes/modules, destructured parameters','Full ECMAScript, modules, class fields/private elements/static blocks/super properties/async and generator methods, destructured parameters')
security='''- [Classes](classes.md) use flat syntax/execution records and retain bounded constructor bridges, work and cumulative heap accounting. Persistent constructor environments keep escaped-arrow receiver/NewTarget state; they do not reset an author allowance. Strict class semantics are not an isolation boundary. The selected representation adds accounted environment storage, with final candidate quota and full-suite validation pending.
'''
anchor='- Script code cannot call host filesystem'
edit('docs/SECURITY.md',anchor,security+anchor)
validation='''## JavaScript class runtime — final validation pending

The [class subset](classes.md) adds strict declarations/expressions, public
methods/accessors and base/derived constructor behavior, including direct
`super()`, retained arrows and native Promise subclasses. The first compiled
candidate passes all **79 public groups**, covering **162 mode attempts**.
The initial compiler check reported a private-helper visibility error;
`constructed_prototype` was widened to `pub(super)` without changing its body,
signature or tariff. No public expectation changed.

Four independently retained complete-shape probes observed Environment 96→112,
its preserved allowance 176→192, compiled Unit 136→168 and parser frame 112→120.
The 184-byte runtime frame is unchanged. These are proposed-shape observations;
actual candidate layout/startup and historical witness checks remain pending.
Author 100,000, bootstrap 1,000,000 and cumulative 8 MiB limits are unchanged.

**Pending final ledger:** private quota controls; complete Rust rosters and
strict checks; browser/worker results; actual production sizes/startup; complete
upstream case/control comparisons; and final selected/tracked source closure.
No class feature admission, hardware Vulkan execution, performance result or
new remote CI success is claimed. Evidence links are reserved in the chapter.
The complete prior validation body below remains byte-exact.

'''
edit('docs/VALIDATION.md','# Validation record\n\n','# Validation record\n\n'+validation)
raw['docs/classes.md']=(O/'classes-draft.md').read_text()
rows=[]
for relative,text in raw.items():
 p=O/'raw'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 before=old.get(relative,'');q=O/'before'/relative
 if relative in old:q.parent.mkdir(parents=True,exist_ok=True);q.write_text(before)
 d=O/'diff'/(relative+'.diff');d.parent.mkdir(parents=True,exist_ok=True)
 d.write_text(''.join(difflib.unified_diff(before.splitlines(True),text.splitlines(True),fromfile='a/'+relative if relative in old else '/dev/null',tofile='b/'+relative)))
 rows.append({'relative':relative,'new':relative not in old,'before':bound(q) if relative in old else None,'raw':bound(p),'diff':bound(d)})
for relative,before in old.items():
 text=raw[relative]
 for e in reversed([e for e in edits if e['relative']==relative]):assert text.count(e['after'])==1;text=text.replace(e['after'],e['before'],1)
 assert text==before
assert raw['docs/VALIDATION.md'].endswith(old['docs/VALIDATION.md'][len('# Validation record\n\n'):])
(O/'edits.json').write_text(json.dumps(edits,indent=2)+'\n')
print(json.dumps({'files':rows,'historical_validation_suffix_exact':True,'before_inverses':len(old)}))
