from pathlib import Path
import hashlib,json,re,collections
F=Path('/tmp/eris-class-runtime-plan-1');H=F/'validation-review-1';root=json.loads((F/'root/full-suite-validation-1.json').read_text())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def checkbinding(b):assert bind(Path(b['path']))==b
rows=[]
for config in root['configurations']:
 sets=[];details=[]
 for role in ['parent','candidate']:
  r=config[role];checkbinding(r['receipt']);checkbinding(r['log']);jr=json.loads(Path(r['receipt']['path']).read_text());txt=Path(r['log']['path']).read_text();assert jr['exit']==0 and jr['sha256']==r['log']['sha256']
  outcomes=re.findall(r'^test (\S+) \.\.\. (ok|FAILED|ignored)\s*$',txt,re.M)
  counts=collections.Counter(n for n,s in outcomes);assert all(v==1 for v in counts.values());assert all(s=='ok' for n,s in outcomes)
  totals=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',txt,re.M)
  assert len(totals)==r['result_rows'];assert all(st=='ok' and set([fail,ign,meas,filt])=={'0'} for st,passed,fail,ign,meas,filt in totals)
  assert sum(int(t[1]) for t in totals)==len(outcomes)==r['passed'];sets.append(set(counts));details.append({'role':role,'receipt':r['receipt'],'log':r['log'],'passed':len(outcomes),'result_rows':len(totals)})
 assert sets[0] <= sets[1];added=sorted(sets[1]-sets[0]);assert added==config['added'] and len(added)==98
 assert len([n for n in added if '::class_public_' in n])==80
 assert len([n for n in added if '::class_private_' in n])==16
 assert len([n for n in added if n.startswith('classes_') or n.startswith('classes::')])==2
 assert not any('layout_probe' in n or 'shape_probe' in n for n in added)
 rows.append({'config':config['config'],'runs':details,'parent_roster_exact_subset':True,'removed_or_renamed':[],'added':added})
source=json.loads((H/'source-checks-1.json').read_text());print(source['counts'])
report={'status':'Rust raw record and roster comparisons clear; final receipt remains pending','source':bind(F/'source-candidate-2.json'),'root_ledger':bind(F/'root/full-suite-validation-1.json'),'configurations':rows,'qualifications':['80 public groups execute164 planned mode rows; the Rust logs prove all group loops complete, not independent mode-level Rust names.','16 private groups include114 measured operations and one separate raw/layout observation group, as frozen source contracts derive.','Two browser groups cover direct Page and confined worker; Vulkan feature build does not establish hardware Vulkan execution.','Old promise_layout_probe test remains unchanged. Temporary class mirrors are absent from added roster.'],'project_execution_by_reviewer':False}
(H/'rust-checks-1.json').write_text(json.dumps(report,indent=2)+'\n');print(bind(H/'rust-checks-1.json'))
