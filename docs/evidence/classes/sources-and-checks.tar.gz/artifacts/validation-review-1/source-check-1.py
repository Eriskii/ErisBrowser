from pathlib import Path
import hashlib,json,re,subprocess,difflib
F=Path('/tmp/eris-class-runtime-plan-1');W=F/'worktree';H=F/'validation-review-1';BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def git(p):return subprocess.check_output(['git','show',BASE+':'+p],cwd=W).decode()
def read(p):return json.loads((F/p).read_text())
def checked(row):
 p=Path(row['path']);b=p.read_bytes();assert len(b)==row['bytes'] and sha(b)==row['sha256'],str(p);return b.decode()
parent=read('source-parent.json')['source_sha256'];cand=read('source-candidate-2.json')['source_sha256'];first=read('source-candidate-1.json')['source_sha256']
for p,s in cand.items():assert sha((W/p).read_bytes())==s,p
assert [p for p in cand if cand[p]!=first[p]]==['src/script/typed_array/tests.rs']
changed=sorted(p for p in cand if parent.get(p)!=cand[p]);assert len(changed)==30
expected={}
for row in read('parser-implementation-1/source-ready.json')['files']:
 p=row['relative'];expected[p]=checked(row['raw'])
 if row['before']:assert checked(row['before'])==git(p)
for hold in ['root-implementation-1/chunks.json','runtime-implementation-1/chunks.json','root/historical-migration-chunks-1.json']:
 for r in read(hold):
  p=r['path'];s=expected.get(p)
  if s is None:s=git(p)
  assert s.count(r['before'])==r['occurrences'],(hold,p)
  expected[p]=s.replace(r['before'],r['after'])
for r in read('runtime-implementation-1/source-ready.json')['files']:
 if r['new']:expected[r['relative']]=checked(r['raw'])
expected['src/script/construction.rs']=expected['src/script/construction.rs'].replace('    fn constructed_prototype(', '    pub(super) fn constructed_prototype(')
for hold in ['public-unicode-1','public-terminal-1']:
 for r in read(hold+'/source-ready.json')['files']:expected[r['relative_path']]=checked(r['raw'])
expected['src/script.rs']+='\n'+(F/'public-tests-1/registration-append.txt').read_text()+(F/'public-terminal-1/registration-append.txt').read_text()
for r in read('private-tests-2/source-ready.json')['raw']:expected[r['relative_path']]=checked(r['raw'])
for r in read('private-tests-2/source-ready.json')['registrations']:expected[r['owner']]+=checked(r['append'])
for r in read('browser-tests-1/source-ready.json')['files']:
 p=r['path'];b=(F/'browser-tests-1/raw'/p).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'];expected[p]=b.decode()
expected['tests/worker.rs']=git('tests/worker.rs')+(F/'browser-tests-1/registration-append.txt').read_text()
pre=[]
for r in read('root/private-import-format-inputs-1.json')['files']:
 p=r['path'];b=(F/'before-format-1'/p).read_bytes();assert sha(b)==r['sha256'];
 if expected[p]!=b.decode():print(''.join(difflib.unified_diff(expected[p].splitlines(True),b.decode().splitlines(True))))
 assert expected[p]==b.decode(),p;pre.append(p)
assert set(pre)==set(expected)
# The additive bound-superclass correction is applied to the held, unformatted composition.
helper='''    pub(super) fn class_validate_superclass(&mut self, superclass: &Value) -> Result<()> {
        // Keep a separate captured superclass for Construct. Reject bound
        // nonconstructors before the generic bound dispatcher copies arguments.
        self.work(1)?;
        if !self.is_constructor(superclass.clone())? {
            return Err(ScriptError::type_error("superclass is not a constructor"));
        }
        Ok(())
    }

'''
needle='    pub(super) fn construct_class(';assert expected['src/script/classes.rs'].count(needle)==1;expected['src/script/classes.rs']=expected['src/script/classes.rs'].replace(needle,helper+needle)
old='''    // Transfer the captured parent into the existing guarded constructor
    // dispatch after arguments. Its rejection preserves all argument effects.
''';new='''    // Validate only after all argument effects, before bound forwarding can
    // reserve storage. The captured parent and original NewTarget stay owned.
    runtime.class_validate_superclass(&superclass)?;
''';assert expected['src/script/machine.rs'].count(old)==1;expected['src/script/machine.rs']=expected['src/script/machine.rs'].replace(old,new)
old='        return runtime.construct_with_target(parent, arguments, frame.new_target, doc)';new='        runtime.class_validate_superclass(&parent)?;\n'+old;assert expected['src/script/machine/calls.rs'].count(old)==1;expected['src/script/machine/calls.rs']=expected['src/script/machine/calls.rs'].replace(old,new)
for hold in ['super-validation-tests-1','public-superclass-regression-1']:
 r=read(hold+'/source-ready.json');rows=r.get('raw',[])
 if isinstance(rows,dict):rows=[rows]
 for row in rows:expected[row['relative_path']]=checked(row['raw'])
 reg=r['registration'];expected[reg['owner']]+=checked(reg['append'])
# E0716 test-only correction retains the exact Value expression.
p='src/script/classes/quota_tests.rs';s=expected[p];old='            assert_eq!(runtime.objects[prototype_id].get("constructor"),'
assert s.count(old)==1;s=s.replace(old,'            let expected_constructor = Value::Function(old_functions);\n'+old);assert s.count('Some(&Value::Function(old_functions))')==1;expected[p]=s.replace('Some(&Value::Function(old_functions))','Some(&expected_constructor)')
r=read('typed-ledger-migration-1/source-ready.json');assert checked(r['before'])==git('src/script/typed_array/tests.rs');expected['src/script/typed_array/tests.rs']=checked(r['raw'])
assert set(expected)==set(changed),(set(expected)-set(changed),set(changed)-set(expected))
# Independent lexical scanner: preserve literals/comments exactly, permit whitespace and
# rustfmt's comma/block punctuation only; structural punctuation diffs retained separately.
def lex(s):
 out=[];literal=[];comments=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  start=i
  if s.startswith('//',i):
   end=s.find('\n',i);i=len(s) if end<0 else end;comments.append(s[start:i]);continue
  if s.startswith('/*',i):
   i+=2;depth=1
   while depth:
    assert i<len(s),("unterminated block",start)
    if s.startswith('/*',i):depth+=1;i+=2
    elif s.startswith('*/',i):depth-=1;i+=2
    else:i+=1
   comments.append(s[start:i]);continue
  m=re.compile(r'(?:b|c)?r(#+)?"').match(s,i)
  if m:
   close='"'+(m[1] or '');i=s.index(close,i+len(m[0]))+len(close);literal.append(s[start:i]);out.append(s[start:i]);continue
  m=re.compile(r'(?:b|c)?"').match(s,i)
  if m:
   i+=len(m[0])
   while True:
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:i+=1
   literal.append(s[start:i]);out.append(s[start:i]);continue
  m=re.compile(r"b?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'").match(s,i)
  if m:i+=len(m[0]);literal.append(s[start:i]);out.append(s[start:i]);continue
  m=re.compile(r'[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*').match(s,i)
  if m:i+=len(m[0]);out.append(s[start:i]);continue
  out.append(s[i]);i+=1
 return out,literal,comments
rows=[]
for p,s in expected.items():
 print('lexical',p,flush=True)
 actual=(W/p).read_text()
 if p=='src/script.rs':
  s=s.replace('mod code;\nmod construction;\nmod classes;','mod classes;\nmod code;\nmod construction;')
  s=s.replace('#[cfg(test)] mod class_semantics_tests;\n#[cfg(test)] mod class_abort_tests;','#[cfg(test)] mod class_abort_tests;\n#[cfg(test)] mod class_semantics_tests;')
  # final rustfmt sorts the newly appended sibling superclass test registration beside others.
  s=s.replace((F/'public-superclass-regression-1/registration-append.txt').read_text(),'')
  actual=actual.replace('#[cfg(test)]\nmod class_superclass_tests;\n','')
 if p.endswith('.rs'):
  a,al,ac=lex(s);b,bl,bc=lex(actual);assert al==bl,(p,'literals');assert ac==bc,(p,'comments')
  norm=lambda x:[v for v in x if v not in {',','{','}'}]
  assert norm(a)==norm(b),(p,'tokens')
  rows.append(dict(path=p,nonformat_tokens_exact=True,literal_vector_exact=True,comment_vector_exact=True,literal_count=len(al)))
 else:assert s==actual;rows.append(dict(path=p,byte_exact=True))
# Published tree audit computes Git blob hashes directly from current bytes.
tree=subprocess.check_output(['git','ls-tree','-r','-z',BASE],cwd=W);oldpaths=set();unmodified=0;git_changes=[]
for entry in tree.split(b'\0'):
 if not entry:continue
 meta,name=entry.split(b'\t');mode,kind,oid=meta.split();assert kind==b'blob';p=name.decode();oldpaths.add(p);b=(W/p).read_bytes();blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
 if blob==oid.decode():unmodified+=1
 else:git_changes.append(p)
newpaths=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=W).decode().rstrip('\0').split('\0'))-{''}
assert set(git_changes)|newpaths==set(changed)
checks={'status':'source closure checks pass; final validation pending','source':bind(F/'source-candidate-2.json'),'parent':bind(F/'source-parent.json'),'counts':{'selected':len(cand),'parent_selected':len(parent),'changed_paths':len(changed),'changed_existing':len(git_changes),'new':len(newpaths),'published_tracked':len(oldpaths),'unchanged_tracked':unmodified},'changed_paths':changed,'exact_27_path_preformat_composition':pre,'postformat_composition':rows,'historical_migrations':{'selected_chunks':len(read('root/historical-migration-chunks-1.json')),'ten_old_compile_work_expectations_preserved':True,'additional_typed_bootstrap_formula':True,'candidate1_to2_only_typed_test':True},'qualification':'Literal/comment vectors and every nonformat token exact. Comma/brace formatting and selected sibling-module order normalized; no claim that arbitrary punctuation changes are semantically equivalent. Existing source peers and root retained formatting diffs bound separately. Own parser production and typed migration authored by reviewer, independently peered elsewhere.','project_execution':False,'live_edits':False}
(H/'source-checks-1.json').write_text(json.dumps(checks,indent=2)+'\n');print(bind(H/'source-checks-1.json'))
