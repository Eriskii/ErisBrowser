from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
F=Path('/tmp/eris-class-runtime-plan-1');H=F/'validation-review-1';W=F/'worktree'
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def read(p):return json.loads((F/p).read_bytes())
checked=set()
def bindings(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=set(x):
   p=Path(x['path']);assert bind(p)=={k:x[k] for k in ['path','bytes','sha256']},str(p);checked.add(str(p))
  for v in x.values():bindings(v)
 elif isinstance(x,list):
  for v in x:bindings(v)
ledger=read('root/final-validation.json');bindings(ledger)
assert ledger['status']=='pass' and ledger['base']=='f3118ae5787c410648657f7c822efb7014201dd1'
assert (F/'source-final.json').read_bytes()==(F/'source-candidate-2.json').read_bytes()
source=read('source-final.json')['source_sha256']
for p,s in source.items():assert digest((W/p).read_bytes())==s,p
sc=read('validation-review-1/source-checks-1.json');rc=read('validation-review-1/rust-checks-1.json');assert sc['changed_paths']==ledger['source']['changed_paths'];assert len(source)==1834
assert ledger['suites']==read('root/full-suite-validation-1.json')
# Source-limit declarations remain exact published bytes.
current=(W/'src/script.rs').read_text();parent=subprocess.check_output(['git','show',ledger['base']+':src/script.rs'],cwd=W).decode()
for name in ['MAX_SOURCE','MAX_TOKENS','MAX_DEPTH','MAX_CALLS','MAX_STACK_UNITS','MAX_STEPS','BOOTSTRAP_STEPS','MAX_HEAP','MAX_STRING','MAX_NODES']:
 pattern=rf'^const {name}:.*?;$';assert re.findall(pattern,current,re.M)==re.findall(pattern,parent,re.M)
# Fresh independent profile comparison does not execute/import the replay checker.
contract=read('profile-replay-1/contract.json');summary=read('root/profile-validation-1.json');assert ledger['profiles']==summary
for row in contract['preserved_files']:
 b=(W/row['path']).read_bytes();assert len(b)==row['bytes'] and digest(b)==row['sha256']
for d in contract['corpus_directories']:
 assert {p.relative_to(W).as_posix() for p in (W/d).rglob('*') if p.is_file()}=={x['path'] for x in contract['preserved_files'] if x['path'].startswith(d+'/')}
profiles=[];allchanges=[];total=Counter();oldtotal=Counter();controls=0
identity=['id','file','mode','case_sha256','source_sha256','expected_negative']
for plan,claimed in zip(contract['profiles'],summary['profiles']):
 bindings(plan['parent']);old=json.loads(Path(plan['parent']['path']).read_bytes());now=read(f'upstream-{plan["name"]}-1.json')
 assert claimed['name']==plan['name'];assert bind(F/f'upstream-{plan["name"]}-1.json')==claimed['report']
 assert set(old)==set(now)
 for key in ['suite','full_test262_conformance','repository','revision','corpus_manifest_sha256','runner_policy','runner_policy_sha256','source_files','source_tests','negative_source_tests','fixture_files','mode_cases']:
  assert old[key]==now[key],(plan['name'],key)
 assert digest(json.dumps(now['runner_policy'],sort_keys=True).encode())==now['runner_policy_sha256']
 assert now['cases'] and len(now['cases'])==plan['cases']
 assert len({r['id'] for r in now['cases']})==len(now['cases'])
 assert [[r[k] for k in identity] for r in old['cases']]==[[r[k] for k in identity] for r in now['cases']]
 assert old['harness_preflight']==now['harness_preflight']
 assert len(now['harness_preflight'])==plan['controls'] and now['harness_preflight_passed'] is True and all(r['verified'] is True for r in now['harness_preflight'])
 count=dict(Counter(r['status'] for r in now['cases']));assert count==now['counts']==claimed['counts'];total.update(count);oldtotal.update(old['counts']);controls+=len(now['harness_preflight'])
 changes=[];improvements=[];nonpass=[]
 for a,b in zip(old['cases'],now['cases']):
  assert not(a['status']=='passed' and b['status']!='passed')
  if a!=b:
   kind='improvement' if b['status']=='passed' and a['status']!='passed' else 'nonpass-transition' if a['status']!=b['status'] else 'raw-record-only'
   row=dict(id=b['id'],change=kind,before=a,after=b);changes.append(row);allchanges.append(dict(profile=plan['name'],**row))
   if kind=='improvement':improvements.append(b['id'])
   if kind=='nonpass-transition':nonpass.append(b['id'])
 assert changes==claimed['case_record_changes'] and improvements==claimed['improvements'] and nonpass==claimed['other_status_changes'];assert not claimed['errors'] and not claimed['regressions'] and not claimed['control_record_changes']
 assert claimed['complete_cases_equal']==(old['cases']==now['cases']) and claimed['complete_controls_equal'] is True
 baseline=json.loads((W/plan['baseline']).read_bytes());cases={r['id']:r for r in now['cases']};assert set(baseline['cases'])==set(cases)
 improves=[n for n,a in baseline['cases'].items() if a['status']!='passed' and cases[n]['status']=='passed'];regresses=[n for n,a in baseline['cases'].items() if a['status']=='passed' and cases[n]['status']!='passed'];assert now['improvements']==improves and now['regressions']==regresses==[]
 rec=read(f'validation/upstream-{plan["name"]}-1.json');assert rec['exit']==0;assert digest((F/'validation'/rec['log']).read_bytes())==rec['sha256'];assert rec['command']==claimed['command']
 binary=summary['binaries'][plan['binary_kind']];assert now['binary_sha256']==binary['sha256'] and now['binary']==binary['path']
 profiles.append(dict(name=plan['name'],cases=len(now['cases']),controls=len(now['harness_preflight']),parent_counts=old['counts'],counts=count,improvements=improvements,other_status_changes=nonpass,all_controls_exact=True,report=bind(F/f'upstream-{plan["name"]}-1.json')))
assert total==Counter(passed=1222,failed=60,unsupported=48) and sum(total.values())==1330 and controls==640
assert len(allchanges)==30 and sum(x['change']=='improvement' for x in allchanges)==20
nonpass=[r for r in allchanges if r['change']=='nonpass-transition'];assert len(nonpass)==10 and all(r['before']['status']=='unsupported' and r['after']['status']=='failed' for r in nonpass)
syntax=[r for r in nonpass if r['after']['observation']['phase']=='parse'];host=[r for r in nonpass if r['after']['observation']['phase']=='host'];assert len(syntax)==8 and len(host)==2
for r in syntax:
 o=r['after']['observation'];assert o['status']=='exception' and o['error_identity']=='SyntaxError' and o['message']=='identifier immediately follows numeric literal'
for r in host:
 o=r['after']['observation'];assert o['status']=='host-failure' and o['message']=='unhandled-rejection' and o['completion']['unhandled']==1
# Authenticate source of newly reached BigInt parser errors separately from algorithm outcomes.
for r in syntax:
 plan=next(p for p in contract['profiles'] if p['name']==r['profile']);corpus=Path(plan['baseline']).name
 # Corresponding source is located by exact frozen source hash, never by executing metadata parsing.
 candidates=[x for x in contract['preserved_files'] if x['path'].endswith(r['after']['file']) and x['sha256']==r['after']['source_sha256']]
 assert len(candidates)==1,(r['profile'],candidates)
 body=(W/candidates[0]['path']).read_text();assert re.search(r'\b\d+n\b',body)
# Every declared success receipt authenticates its log and exact command.
for group in ['checks','focused']:
 for label,entry in ledger[group].items():
  rec=json.loads(Path(entry['receipt']['path']).read_bytes());assert rec['exit']==0 and rec['command']==entry['command'];assert rec['sha256']==entry['log']['sha256']
for kind in ['ordinary','host']:
 b=ledger['builds'][kind];side=read(f'eris-js-{kind}-1.json');assert b['binary']==bind(Path(side['binary']))==summary['binaries'][kind]
 assert side['toolchain']=='1.88.0' and side['source_sha256']==digest((F/'source-candidate-2.json').read_bytes())
 assert side['source_inventory']==str(F/'source-candidate-2.json') and side['features']==([] if kind=='ordinary' else ['test262-host'])
 label=f'class-release-{kind}-1';rec=read('validation/'+label+'.json');env=read('validation/'+label+'-environment.json')
 expected=['cargo','+1.88.0','build','--locked','--offline']+([] if kind=='ordinary' else ['--features','test262-host'])+['--release','--bin','eris-js']
 assert rec['command']==expected==b['build']['command'] and rec['exit']==0 and env['toolchain']=='1.88.0'
 assert env['features']==([] if kind=='ordinary' else ['--features','test262-host'])
 assert env['target_dir']==str(F/'target-msrv')
for label,version,features in [('class-clippy-default-2','1.88.0',[]),('class-clippy-host-vulkan-1','1.99.0',['--features','test262-host,vulkan-raster'])]:
 rec=read('validation/'+label+'.json');env=read('validation/'+label+'-environment.json');assert rec['command']==['cargo','+'+version,'clippy','--locked','--offline',*features,'--all-targets','--','-D','warnings'];assert env['features']==features and env['toolchain']==version
assert read('validation/class-format-check-1.json')['command']==['cargo','+1.88.0','fmt','--all','--','--check']
# Parent public outcomes: complete final failure roster plus intact successes avoids interleaved progress-line loss.
parent_reports=['root/public-parent-result-1.json','root/public-parent-result-2.json','root/public-parent-terminal-result-1.json']
for p in parent_reports:bindings(read(p))
parent_rows=[]
for label,passed,failed in [('class-parent-public-1',12,50),('class-parent-naming-1',0,6),('class-parent-context-1',0,6),('class-parent-terminal-1',0,5)]:
 rec=read('validation/'+label+'.json');txt=(F/'validation'/rec['log']).read_text();assert rec['exit']==101 and digest(txt.encode())==rec['sha256'];assert f'test result: FAILED. {passed} passed; {failed} failed;' in txt
 failures=txt.rsplit('\nfailures:\n',1)[1].split('\ntest result:',1)[0];names=[x.strip() for x in failures.splitlines() if x.strip()];assert len(names)==failed and len(set(names))==failed
 oks=re.findall(r'test .*?::(class_public_\w+) \.\.\. ok',txt);assert len(set(oks))==passed
 parent_rows.append(dict(label=label,passed=passed,failed=failed,receipt=bind(F/'validation'/f'{label}.json'),log=bind(F/'validation'/rec['log'])))
assert sum(r['passed'] for r in parent_rows)==12 and sum(r['failed'] for r in parent_rows)==67
focused_counts={}
for label in ledger['focused']:
 txt=(F/'validation'/f'{label}.log').read_text();results=re.findall(r'^test result: ok\. (\d+) passed; 0 failed;',txt,re.M);focused_counts[label]=sum(map(int,results))
assert focused_counts=={'class-public-candidate-1':79,'class-browser-candidate-1':2,'class-private-candidate-2':15,'class-super-validation-1':1}
startup=(F/'validation/class-default-full-1.log').read_text();assert 'remaining=898420 allocated=1775930 objects=757 capacity=757 native=300 prototypes=26 globals=213' in startup
report=dict(status='all final evidence checks clear',ledger=bind(F/'root/final-validation.json'),bindings_checked=len(checked),source=bind(F/'source-final.json'),profiles=profiles,total_counts=dict(total),parent_total_counts=dict(oldtotal),cases=1330,controls=640,full_case_changes=allchanges,regressions=0,improvements=20,unsupported_to_failed=10,new_failures_by_cause=dict(bigint_syntax=8,finally_host_unhandled=2),parent_public=dict(groups=79,passed=12,failed=67,planned_modes=162,reached_modes=91,runs=parent_rows),focused=focused_counts,limits=ledger['limits'],startup=dict(raw_log='validation/class-default-full-1.log',remaining=898420,consumed=101580,allocated=1775930,objects=757,capacity=757,native=300,prototypes=26,globals=213,qualification='Raw counters printed in retained candidate1 full failure; candidate2 changes only the expectation formula, and final suites pass its unchanged assertions.'),project_execution_by_reviewer=False)
(H/'final-checks-1.json').write_text(json.dumps(report,indent=2)+'\n');print(bind(H/'final-checks-1.json'))
