from pathlib import Path
import subprocess, json, hashlib, difflib

PLAN = Path('/tmp/eris-class-runtime-plan-1')
OUT = PLAN / 'runtime-implementation-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'
REPO = PLAN / 'worktree'
chunks = []
before = {}
raw = {}

def get(path):
    if path not in before:
        before[path] = subprocess.check_output(['git','show',f'{BASE}:{path}'], cwd=REPO).decode()
        raw[path] = before[path]
    return raw[path]

def edit(path, old, new, purpose):
    source = get(path)
    assert source.count(old) == 1, (path,purpose,source.count(old))
    raw[path] = source.replace(old,new,1)
    chunks.append({'path':path,'before':old,'after':new,'occurrences':1,'purpose':purpose})

edit('src/script.rs','mod construction;','mod construction;\nmod classes;','register new class-only runtime helpers')

p='src/script/construction.rs'
old='            Value::Function(id) if self.functions[*id].code.constructable => {'
edit(p,old,'''            Value::Function(id) if self.functions[*id].code.class_kind.is_some() => {
                self.construct_class(*id, arguments, new_target, doc)
            }
'''+old,'route unbound class constructors before ordinary receiver allocation')

p='src/script/machine/calls.rs'
edit(p,'    Vacant,\n}\nstruct Activation {','''    Vacant,
    ClassStart { id: usize, arguments: Vec<Value> },
    ClassBody { environment: usize, kind: code::ClassKind },
}
struct Activation {''','add selected class-only phases without widening Activation')
old='    pub(super) fn with_new_target(mut self, new_target: Value) -> Self {'
edit(p,old,'''    pub(super) fn class_constructor(
        id: usize, arguments: Vec<Value>, new_target: Value, preentered: bool,
    ) -> Self {
        Self { owns_call: !preentered, new_target, phase: Phase::ClassStart { id, arguments } }
    }
'''+old,'construct preentered class invocation frame')
old='        Phase::Forward => Ok(output),'
edit(p,old,'''        Phase::ClassStart { id, arguments } => class_start(runtime, frame, id, arguments, doc),
        Phase::ClassBody { environment, kind } => class_completion(runtime, environment, kind, output),
'''+old,'dispatch class setup and original-activation completion')
old='    // Keep the conservative legacy activation allowance while sharing all code.'
edit(p,old,'''    if runtime.functions[id].bound.is_none() && runtime.functions[id].code.class_kind.is_some() {
        runtime.work(4)?;
        return Err(ScriptError::type_error("class constructor requires new"));
    }
'''+old,'reject direct class Call before legacy metadata and parameter defaults')
old='    schedule(runtime, frame, Phase::Body, next)\n}'
edit(p,old,'''    let phase = match code.class_kind {
        Some(kind) => Phase::ClassBody { environment: env, kind },
        None => Phase::Body,
    };
    schedule(runtime, frame, phase, next)
}''','retain original activation for constructor result selection')
old='fn forward(\n'
edit(p,old,(OUT/'new/class-call-functions.rs').read_text()+'\n'+old,'add separate class activation and completion helpers')

p='src/script/machine.rs'
edit(p,'mod calls;','mod calls;\nmod classes;','register class-definition frame driver')
edit(p,'    Call(calls::Frame),\n}','    Call(calls::Frame),\n    Class(classes::Frame),\n}','add selected top-level class frame')
old='''    SpreadArguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: call_spread::Arguments,
    },
}
enum Output'''
new=old.replace('\n}\nenum Output','''
    NamedStart(PropertyKey),
    SuperArguments {
        owner: usize, new_target: Value, superclass: Value,
        index: usize, arguments: Vec<Value>,
    },
    SuperSpreadArguments {
        owner: usize, new_target: Value, superclass: Value,
        index: usize, arguments: call_spread::Arguments,
    },
}
enum Output''')
edit(p,old,new,'add exact named and captured-super phases')
old='enum Phase {\n'
edit(p,old,'''impl ExprFrame {
    pub(in crate::script) fn named_class(
        unit: Rc<code::Unit>, expression: code::ExprId, env: usize, name: PropertyKey,
    ) -> Self {
        Self { unit, expression, env, reference: false, phase: Phase::NamedStart(name) }
    }
}
'''+old,'owned named-evaluation handoff consumed by root integration')
old='fn drive(runtime: &mut Runtime, root: Frame, doc: &mut Document) -> Result<Output> {'
edit(p,old,'''pub(super) fn invoke_class_preentered(
    runtime: &mut Runtime, id: usize, arguments: Vec<Value>,
    new_target: Value, doc: &mut Document,
) -> Result<Value> {
    match drive(runtime, Frame::Call(calls::Frame::class_constructor(
        id, arguments, new_target, true,
    )), doc)? {
        Output::Value(value) => Ok(value),
        _ => unreachable!("class invocation root"),
    }
}
'''+old,'guarded nested drive without resetting counters or author limits')
old='                Frame::Statement(frame) => statements::step(runtime, frame, output.take(), doc),'
edit(p,old,old+'''
                Frame::Class(frame) => match output.take().transpose() {
                    Ok(output) => classes::step(runtime, frame, output, doc),
                    Err(error) => Err(error),
                },''','propagate class errors through existing terminal/ordinary unwind')
old='        Phase::Start => start(runtime, frame, doc),'
edit(p,old,old+'''
        Phase::NamedStart(name) => {
            runtime.tick()?;
            let Some(class_id) = unit.anonymous_class(id) else {
                return Err(ScriptError::resource("named class continuation requires an anonymous class"));
            };
            class_expression(runtime, frame, class_id, Some(name))
        },''','named anonymous-class entry before metadata/static elements')
old='''    }
}

fn start(runtime: &mut Runtime, frame: ExprFrame, doc: &mut Document) -> Result<Option<Output>> {'''
new='''        Phase::SuperArguments { owner, new_target, superclass, index, mut arguments } => {
            arguments.push(value(output));
            super_arguments_next(runtime, frame, (owner, new_target, superclass), index + 1, arguments, doc)
        }
        Phase::SuperSpreadArguments { owner, new_target, superclass, index, mut arguments } => {
            let incoming = call_spread::receive_prepaid(value(output));
            let code::Expr::SuperCallSpread(items) = unit.expr(id) else { unreachable!() };
            if matches!(unit.expr(items[index]), code::Expr::SpreadArgument(_)) {
                arguments.spread_received(runtime, incoming, doc)?;
            } else {
                arguments.append_received(runtime, incoming)?;
            }
            super_spread_next(runtime, frame, (owner, new_target, superclass), index + 1, arguments, doc)
        }
'''+old
edit(p,old,new,'resume super argument values under prepaid ownership')
old='        code::Expr::Function(id) => runtime\n'
edit(p,old,'''        code::Expr::Class(id) => class_expression(runtime, frame, *id, None),
        code::Expr::SuperCall(_) => super_arguments_start(runtime, frame, false, doc),
        code::Expr::SuperCallSpread(_) => super_arguments_start(runtime, frame, true, doc),
'''+old,'new expression dispatch; ordinary function route unchanged')
old='fn binary_next(\n'
edit(p,old,(OUT/'new/class-expression-functions.rs').read_text()+'\n'+old,'source-ordered super evaluation and final bind using existing guarded bridge')

for path in ['src/script/classes.rs','src/script/machine/classes.rs']:
    raw[path]=(OUT/'new'/path).read_text()

for path,source in raw.items():
    out=OUT/'raw'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_text(source)
    if path in before:
        old=OUT/'before'/path;old.parent.mkdir(parents=True,exist_ok=True);old.write_text(before[path])
    diff=''.join(difflib.unified_diff(before.get(path,'').splitlines(True),source.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
    out=OUT/'diffs'/(path+'.diff');out.parent.mkdir(parents=True,exist_ok=True);out.write_text(diff)
    inverted=source
    for chunk in reversed([c for c in chunks if c['path']==path]):
        assert inverted.count(chunk['after'])==1,(path,chunk['purpose'])
        inverted=inverted.replace(chunk['after'],chunk['before'],1)
    if path in before:assert inverted==before[path]
(OUT/'chunks.json').write_text(json.dumps(chunks,indent=2)+'\n')
print(json.dumps({'changed_existing':len(before),'new_files':len(raw)-len(before),'chunks':len(chunks),'inverse':'all exact'}))
