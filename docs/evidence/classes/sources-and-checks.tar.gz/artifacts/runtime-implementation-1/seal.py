from pathlib import Path
import subprocess, json, hashlib, re

F=Path('/tmp/eris-class-runtime-plan-1')
O=F/'runtime-implementation-1'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def bound(p):
    b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,value):
    p=O/name; assert not p.exists(), name
    p.write_text(json.dumps(value,indent=2)+'\n');return bound(p)

chunks=json.loads((O/'chunks.json').read_text())
files=[]
for p in sorted((O/'raw').rglob('*.rs')):
    relative=p.relative_to(O/'raw').as_posix();before=O/'before'/relative
    row={'relative':relative,'new':not before.exists(),'before':bound(before) if before.exists() else None,
         'raw':bound(p),'diff':bound(O/'diffs'/(relative+'.diff'))}
    if before.exists():
        original=subprocess.check_output(['git','show',BASE+':'+relative],cwd=F/'worktree')
        assert before.read_bytes()==original
        restored=p.read_text()
        for c in reversed([x for x in chunks if x['path']==relative]):
            assert restored.count(c['after'])==1
            restored=restored.replace(c['after'],c['before'],1)
        assert restored.encode()==original
        row['inverse_exact']=True
    files.append(row)

root_chunks=json.loads((F/'root-implementation-1/chunks.json').read_text())
composition={}
for c in chunks+root_chunks:
    relative=c['path']
    if relative not in composition:
        composition[relative]=subprocess.check_output(['git','show',BASE+':'+relative],cwd=F/'worktree').decode()
    assert composition[relative].count(c['before'])==c['occurrences'],(relative,c['before'][:80])
    composition[relative]=composition[relative].replace(c['before'],c['after'],c['occurrences'])
composition_receipt=write('integration-check.json',{
    'status':'Read-only exact string composition succeeds; no composed project file written or executed',
    'root_chunks':bound(F/'root-implementation-1/chunks.json'),
    'runtime_chunks':bound(O/'chunks.json'),'composed_files':len(composition),
    'ownership':{'root':'Environment declarations/initializers/formula and existing this references; outer lexical instantiation/initialization; statement ClassInitialize; anonymous-class named-evaluation callsites',
                 'runtime':'New runtime classes module, flat class-definition frame, class constructor activation/completion, expression class/super stages and guarded bridge'},
    'interfaces':{'named_class':'ExprFrame::named_class(Rc<code::Unit>,code::ExprId,usize,PropertyKey)->ExprFrame',
                  'class_frame':'classes::Frame::new(Rc<code::Unit>,code::ClassId,usize,Option<PropertyKey>)->Frame'},
    'unchanged_runtime_shapes':['Function','Value','ScriptObject','calls::Activation'],
    'production_shape_obligation':'Existing selected mirrors bind all added class/call/expression variants. Actual candidate types must later match the independently observed complete mirrors.'})

addendum=write('accounting-addendum.json',{
    'status':'Three narrow additions explicitly selected by root during source authoring; no test or result informed them',
    'base_contract':bound(F/'accounting-proposal-1/source-ready.json'),
    'selection':bound(F/'root/class-accounting-selection-1.json'),
    'reached_stages':[
        {'branch':'nonnull heritage','stage':'Immediately before is_constructor(heritage.clone())','work':1,'heap':0,'reason':'Consuming legacy IsConstructor needs its own retained handle while the constructor remains available for class publication.'},
        {'branch':'nonnull heritage after successful IsConstructor','stage':'Immediately before get(heritage.clone(), "prototype", doc)','work':1,'heap':0,'reason':'Observable Get consumes its receiver; retain the original constructor for the class internal prototype. No debit on failed IsConstructor.'},
        {'branch':'absent heritage only','stage':'Before saved Object prototype map read','work':'intrinsic_tree(prototypes.len()).0 * (1 + "Object".len()/8)','heap':0,'reason':'Existing saved-intrinsic lookup tariff; saved Function prototype is a scalar field.'}],
    'super_parent_transfer':'After argument evaluation, move the captured superclass into unchanged construct_with_target/construct_inner dispatch. This checks the callable constructor routes without a new is_constructor clone or debit. Root explicitly selected this bridge; do not describe it as invoking is_constructor. Existing outer stack admission may refuse before its dispatch.',
    'name_placeholder':'Dedicated constructor metadata retains the old code-metadata allowance, including its empty JsString name value, before applying the existing set_key_function_name. Four fresh metadata keys remain separately charged.',
    'cleanup':'Incoming descriptor/key/heritage/list owners have producer admission before helper entry. Terminal refusal preserves earlier author effects and stops subsequent elements/defaults/arguments; raw private helpers do not claim an implicit author-entry observer.'})

proof=write('source-checks.json',{
    'status':'Source checks only; no compiler, formatter, engine, project import or tests executed',
    'published_base':BASE,'existing_file_inverses':4,'new_files':2,'chunks':len(chunks),
    'old_helper_preservation':'Every changed old file returns byte-exact to its published parent under the retained selected inverses. All other old files are absent from this hold. Ordinary setup/body routes change only through the selected class guards/completion branch; their activation and inherited helper charge statements remain exact.',
    'old_paths_unchanged':['src/script/promises.rs','src/script/promises/factories.rs','src/script/machine/call_spread.rs','src/script/dom_prototypes.rs','src/script/symbols.rs'],
    'old_limits_unchanged':True,'new_runtime_state_fields':'none beyond root-selected Environment representation',
    'terminal_observation':'Existing drive propagates ResourceLimit/Unsupported without author catch/finally/close; public author entry owns queue suspension. No new observer reset or global budget allowance.',
    'semantic_checks':['Call rejection before metadata/defaults/body','Base prototype Get/allocation before explicit activation','Derived object return before super succeeds; primitive nonundefined return fails','Original activation and NewTarget persist for escaped arrows','Super captures current internal parent before argument evaluation; duplicate binding follows parent construction','Default derived moves incoming arguments without Array iterator/rest/arguments allocation','Class name metadata is installed before source-ordered static members','Computed keys use one existing ToPropertyKey; descriptors preserve getter/setter counterparts and false becomes TypeError','Fresh strict class lexical environment exists for named and anonymous definitions; inner immutable TDZ initializes after members']})

inputs=[
 'source-parent.json','root/selection-1.json','root/representation-selection-1.json',
 'root/representation-accounting-selection-1.json','root/class-accounting-selection-1.json',
 'accounting-proposal-1/source-ready.json','accounting-proposal-1/measurement-addendum-1.json',
 'constructor-design-1/source-ready.json','constructor-design-1/coordination-addendum-1.json',
 'constructor-design-1/strict-environment-addendum-1.json','parser-implementation-1/source-ready.json',
 'parser-implementation-1/interfaces.json','public-contract-2/source-ready.json',
 'runtime-shapes-2/source-ready.json']
ready=write('source-ready.json',{
 'status':'External runtime production hold ready for independent source review; no live edits or project execution',
 'base':BASE,'inputs':[bound(F/p) for p in inputs],'files':files,
 'chunks':bound(O/'chunks.json'),'accounting_addendum':addendum,'integration_check':composition_receipt,
 'source_checks':proof,'authoring':[bound(O/'author.py'),bound(O/'seal.py'),bound(O/'new/class-call-functions.rs'),bound(O/'new/class-expression-functions.rs')],
 'dependency':'Root composes its held Environment/lexical/name chunks and Layout parser/code hold; this raw payload is intentionally not a standalone buildable source tree.',
 'private_controls':'Independently authored; not read, derived or executed by this producer.'})
print(json.dumps(ready))
