fn class_expression(
    runtime: &mut Runtime, mut frame: ExprFrame, class_id: code::ClassId,
    name: Option<PropertyKey>,
) -> Result<Option<Output>> {
    let next = classes::Frame::new(frame.unit.clone(), class_id, frame.env, name);
    frame.phase = Phase::Identity;
    push(runtime, Frame::Expression(frame))?;
    enter_frame(runtime, Frame::Class(next))?;
    Ok(None)
}

fn super_arguments_start(
    runtime: &mut Runtime, frame: ExprFrame, spread: bool, doc: &mut Document,
) -> Result<Option<Output>> {
    let (owner, new_target, superclass) = runtime.class_super_target(frame.env)?;
    if spread {
        call_spread::prepay_entry(runtime)?;
        return super_spread_next(runtime, frame, (owner, new_target, superclass), 0,
            call_spread::Arguments::empty_prepaid(), doc);
    }
    let code::Expr::SuperCall(items) = frame.unit.expr(frame.expression) else { unreachable!() };
    let arguments = reserve_values(runtime, items.len(), false)?;
    super_arguments_next(runtime, frame, (owner, new_target, superclass), 0, arguments, doc)
}

fn super_arguments_next(
    runtime: &mut Runtime, frame: ExprFrame, capture: (usize, Value, Value), index: usize,
    arguments: Vec<Value>, doc: &mut Document,
) -> Result<Option<Output>> {
    let (owner, new_target, superclass) = capture;
    let unit = frame.unit.clone();
    let code::Expr::SuperCall(items) = unit.expr(frame.expression) else { unreachable!() };
    if let Some(expression) = items.get(index) {
        call_spread::prepay_item(runtime)?;
        return eval_child(runtime, frame, Phase::SuperArguments {
            owner, new_target, superclass, index, arguments,
        }, *expression);
    }
    finish_super(runtime, owner, new_target, superclass, arguments, doc)
}

fn super_spread_next(
    runtime: &mut Runtime, frame: ExprFrame, capture: (usize, Value, Value), index: usize,
    arguments: call_spread::Arguments, doc: &mut Document,
) -> Result<Option<Output>> {
    let (owner, new_target, superclass) = capture;
    let unit = frame.unit.clone();
    let code::Expr::SuperCallSpread(items) = unit.expr(frame.expression) else { unreachable!() };
    if let Some(item) = items.get(index) {
        call_spread::prepay_item(runtime)?;
        let expression = match unit.expr(*item) {
            code::Expr::SpreadArgument(expression) => *expression,
            _ => *item,
        };
        return eval_child(runtime, frame, Phase::SuperSpreadArguments {
            owner, new_target, superclass, index, arguments,
        }, expression);
    }
    finish_super(runtime, owner, new_target, superclass, arguments.into_values(), doc)
}

fn finish_super(
    runtime: &mut Runtime, owner: usize, new_target: Value, superclass: Value,
    arguments: Vec<Value>, doc: &mut Document,
) -> Result<Option<Output>> {
    // Transfer the captured parent into the existing guarded constructor
    // dispatch after arguments. Its rejection preserves all argument effects.
    let constructed = runtime.construct_with_target(superclass, arguments, new_target, doc)?;
    runtime.class_bind_this(owner, constructed).map(|value| Some(Output::Value(value)))
}
