import hashlib
import json
import pathlib
import re
import subprocess

F = pathlib.Path('/tmp/eris-class-runtime-plan-1')
P = F / 'private-tests-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def binding(path):
    path = pathlib.Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    (P / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

paths = [
    'src/script/classes/quota_tests.rs',
    'src/script/parser/class_tests.rs',
    'src/script/code/class_storage_tests.rs',
]
counts = [10, 3, 2]
groups = []
for relative, count in zip(paths, counts):
    source = (P / 'raw' / relative).read_text()
    names = re.findall(r'#\[test\]\s*fn (class_private_\w+)\(\)', source)
    assert len(names) == count
    groups.extend({'relative_path': relative, 'test': name} for name in names)
assert len({x['test'] for x in groups}) == 15

register = [
    ('src/script/classes.rs', 'quota_tests'),
    ('src/script/parser.rs', 'class_tests'),
    ('src/script/code.rs', 'class_storage_tests'),
]
registrations = []
for relative, name in register:
    fragment = P / ('registration-' + name + '.txt')
    fragment.write_text('#[cfg(test)]\nmod ' + name + ';\n')
    registrations.append({'owner': relative, 'append': binding(fragment)})

inputs = [
    'root/selection-1.json',
    'root/class-accounting-selection-1.json',
    'root/representation-accounting-selection-1.json',
    'accounting-proposal-1/source-ready.json',
    'accounting-proposal-1/proposal.json',
    'accounting-proposal-1/measurement-addendum-1.json',
    'accounting-review-1/review.json',
    'parser-design-1/source-ready.json',
    'parser-shapes-1/source-ready.json',
    'parser-shapes-1/proposed/code.rs',
    'parser-shapes-1/proposed/parser.rs',
    'parser-accounting-1/source-ready.json',
    'parser-accounting-1/checklist.json',
    'parser-accounting-1/selection-binding-1.json',
    'public-terminal-1/source-ready.json',
]
write('bindings.json', {'base': BASE, 'contracts': [binding(F / x) for x in inputs]})

source_paths = [
    'src/script.rs', 'src/script/code.rs', 'src/script/code/records.rs',
    'src/script/parser.rs', 'src/script/parser/driver.rs',
    'src/script/promises.rs', 'src/script/promises/factories.rs',
    'src/script/promises/install.rs', 'src/script/dom_prototypes.rs',
    'src/script/symbols.rs', 'src/script/property_keys.rs',
    'src/script/microtasks.rs', 'src/script/machine.rs',
    'src/script/machine/calls.rs', 'src/script/parser/call_spread_cut_tests.rs',
    'src/script/code/call_spread_layout_tests.rs',
]
source_bindings = []
for relative in source_paths:
    data = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=F / 'worktree')
    source_bindings.append({'relative_path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
write('published-source-bindings.json', source_bindings)

ledger = {
    'status': 'Independent fixed source-derived expectations; no project execution or producer implementation read',
    'base': BASE,
    'chronology': 'Selected accounting preceded these controls. Producer source and public executions may exist before this final seal; neither was read or used to derive expectations. This is not a claim that executable private payload predates all production authorship.',
    'runtime_groups': [
        {'suffix': 'name_hint', 'operations': 4, 'work': '3 refuses, 4 returns one canonical-key clone', 'heap': 0, 'observations': 'String backing pointer and Symbol identity preserved; no output allocation.'},
        {'suffix': 'identifier_utf16', 'operations': 15, 'fixed_rows': [['', 8, 0, 64, []], ['A', 9, 2, 68, [65]], ['Café', 13, 8, 80, [67, 97, 102, 233]], ['𐐀', 12, 4, 72, [55297, 56320]]], 'cuts': 'First debit minus one, second debit minus one where nonzero, heap minus one, exact. No runtime arena changes.'},
        {'suffix': 'environment', 'operations': 18, 'work': '8 + growth work + named UTF8 byte 1', 'heap': 'growth + 128+2*sizeof(Option<Value>)+selected environment delta + named(BINDING_BYTES+1)', 'cold_fixture': 'Published raw len/capacity2; checked physical equality. Growth target8, work8+4*ceil(Environment/Value), heap32+8*Environment.', 'warm_fixture': 'Real precharged old growth_plan reservation, physical spare asserted before measured budgets.', 'prefixes': 'Entry/growth-work refusal publishes nothing; row-heap refusal publishes nothing; named-work or binding-heap refusal retains strict lexical empty row; exact adds immutable TDZ binding.'},
        {'suffix': 'inner_outer_publication', 'operations': 6, 'work': 'Inner9/outer8 for one-entry name x; anonymous inner6; missing outer in empty map6.', 'heap': 0, 'observations': 'Inner copy vs outer move, no early publication, no fallback binding allocation.'},
        {'suffix': 'prototype', 'operations': 8, 'work': 'Warm17, cold25', 'heap': 'sizeof(ScriptObject)+growth +72+sizeof(Option<AbortSlot>)+sizeof(Option<f64>)+sizeof(PropertyKey)', 'prefixes': 'Entry refusal0 bytes; final-work refusal has charged slot and bag header only; final heap refusal no object publication; exact null parent and spare order.'},
        {'suffix': 'constructor_method', 'operations': 8, 'work': {'constructor': 187, 'method': 13}, 'constructor_work_derivation': '20 fixed +2 legacy empty code +9 bag +92 four ASCII keys +9 length +14 name +30 prototype +1 old name replacement +10 prototype.constructor.', 'constructor_heap': 'Function+ScriptObject+bag_header+3*PropertyKey+1648, where1648=128 old code +376 four keys +1144 four fresh properties.', 'method_heap': 'Function+ScriptObject+bag_header+680, where680=128 old code +280 length +272 name.', 'prefixes': 'Entry19/9 refuses before storage; constructor186 retains row/three metadata properties/name but no prototype.constructor; method12 retains named-empty row before final name replacement. Method heap-one-short fails before metadata object/function publication with one work unit remaining. Constructor heap-one-short fails at final link after all work.'},
        {'suffix': 'fresh_descriptor', 'operations': 16, 'work': 'Warm9 / cold17 for empty map, string x or Symbol.', 'heap': '256+4*u plus cold32+8*PropertyKey; u1 string /u0 Symbol.', 'prefixes': 'Fixed debit, final ordinary define debit, final heap charge, exact. Order/map remain empty on refusal; key identity retained on success.'},
        {'suffix': 'descriptor_replacement', 'operations': 4, 'work': 'Accessor key x at n1:11; nonconfigurable prototype at n1:20; malformed order/map fixed8.', 'heap': 0, 'observations': 'Getter survives setter merge; false becomes ordinary TypeError; malformed invariant refuses as Resource before mutation.'},
        {'suffix': 'super', 'operations': 8, 'work': '12+3+2 environment ticks=17;14 and16 refuse. Two successful captures fund two bind leaf calls at zero remaining work.', 'heap': 0, 'observations': 'Live primitive parent returned without premature constructibility test; original NewTarget retained; initialized this does not prevent capture; no late bind debit; duplicate ReferenceError retains old receiver.'},
        {'suffix': 'raw_and_layout', 'observations': 1, 'expected': 'All inherited raw terms with fixed43 bindings,34 natives,tracked text allowance524, plus2*selected delta. Actual x86_64 Linux ThisBinding24,Environment112,runtime Function104,machine Frame184,code Function80,Unit168,delta16,row192,raw addition32.'},
    ],
    'parser_groups': [
        {'suffix': 'flags_and_edges', 'operations': 5, 'observations': 'Four class constructor kinds; default empty code; strict/nonconstructible member flags; source member order/kinds; computed key ID; SuperCallSpread and SpreadArgument edges; ordinary context preserved; anonymous class recognition distinct from old anonymous-function helper.'},
        {'suffix': 'context', 'operations': 4, 'observations': 'Two SyntaxErrors, one valid deferred field Unsupported, and bounded 200-semicolon terminal work source restore precisely allow_in/strict/super_call_allowed/in_class. No rollback of consumed work/heap asserted.', 'resource_bound': '64 available work cannot execute200 individually charged semicolon transitions. This is a semantic lower bound, not a measured implementation threshold.'},
        {'suffix': 'element_push', 'operations': 3, 'work': 2, 'heap': '32+sizeof(ClassElement)', 'observations': 'One-short work/heap leaves vector empty and referenced function stable; exact retains one static method edge.'},
    ],
    'storage_groups': [
        {'suffix': 'class_records', 'operations': 8, 'rows': [{'existing': 0, 'work': 3, 'heap': '4*sizeof(Vec<Class>)+32+128*sizeof(Class)+32'}, {'existing': 1, 'work': 1, 'heap': 0}, {'existing': 128, 'work': 2, 'heap': '128*sizeof(Class)+32'}], 'observations': 'Exact/one-short work and relevant heap; stable earlier address/IDs; failed append leaves length unchanged.'},
        {'suffix': 'unit_finish_drop', 'operations': 3, 'work': 1, 'heap': 'sizeof(Unit)+2*sizeof(usize)', 'observations': '4096 flat Class/Expr ID edges, marker released on failed Unit publication; FunctionRef retains successful Unit; final drop releases marker. Actual Class72/ClassElement32/Unit168/publication184 x86_64 Linux.'},
    ],
    'totals': {'test_groups': 15, 'measured_helper_or_parser_operations': 110, 'raw_layout_observation_groups': 1},
    'ownership_and_scope': [
        'Fixtures perform setup before resetting the measured private budget. Warm vector reservations use unchanged growth_plan and actual work/heap admission; physical spare is asserted.',
        'Expected fees are literal selected formulas; no helper-under-test is called to measure an expected amount. Typed layout terms remain portable; literal layouts are platform-gated.',
        'Setup may use existing helpers and explicitly synthesized flat records; it does not execute JS. No terminal-state promise is made for raw private helper Result.',
        'Public terminal hold remains separate and immutable, with no counter reset or post-terminal script/checkpoint.',
        'The broad existing public class semantics and ordinary helper tests are preserved; these controls target selected new storage/publication invariants rather than every fee permutation.',
    ],
}
write('oracle.json', ledger)
write('roster.json', groups)

# Check terminal source facts without executing or importing project code.
terminal = F / 'public-terminal-1/raw/src/script/class_abort_tests.rs'
terminal_source = terminal.read_text()
write('terminal-source-review.json', {
    'status': 'source-clear', 'binding': binding(terminal),
    'checks': ['Five groups/seven frozen sources/14 planned modes remain bound by original terminal seal.',
               'Fresh Runtime per mode; one public execute or execute_strict per source, then borrowed state inspection.',
               'Resource classification precedes trace/counter observations; no private quota refill, queue reset, checkpoint or second script entry.',
               'Queued callback is compared to borrowed retained binding; no callback invocation or author getter.',
               'Frame/call/eval/stack/author-depth restoration and sticky suspension are end-to-end public observations.'],
    'project_execution': False,
})

files = []
for path in sorted(P.rglob('*')):
    if path.is_file() and path.name != 'source-ready.json':
        files.append({'relative_path': str(path.relative_to(P)), **binding(path)})
write('source-ready.json', {
    'status': 'sealed independent private controls; unexecuted', 'base': BASE,
    'raw': [{'relative_path': relative, 'raw': binding(P / 'raw' / relative)} for relative in paths],
    'registrations': registrations, 'roster': binding(P / 'roster.json'),
    'oracle': binding(P / 'oracle.json'), 'bindings': binding(P / 'bindings.json'),
    'published_sources': binding(P / 'published-source-bindings.json'),
    'counts': ledger['totals'], 'files': files,
    'qualification': 'No live edits, project imports/execution, future producer reads, candidate output or measured oracle. Final sealing follows root public execution chronology but expectations derive solely from previously selected contracts and published source.',
})
print(json.dumps(binding(P / 'source-ready.json')))
