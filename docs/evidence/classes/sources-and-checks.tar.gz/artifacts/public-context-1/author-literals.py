from pathlib import Path
import hashlib
import json

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-context-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2) + '\n').encode())

prefix = "function check(v){if(!v)throw new Error('class context oracle');}\n"
drafts = [
    ('context_strict_heritage_and_computed_keys', '''var result=(function(){
 var trace='',box={};Object.defineProperty(box,'x',{value:0,writable:false,configurable:true});
 try {class H extends (trace+='H',box.x=1,Object) {}trace+='X';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class K {[(trace+='K',box.x=2,'m')](){}}trace+='Y';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class S {static [(trace+='S',box.x=3,'m')](){}}trace+='Z';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 check(box.x===0);return trace+'|'+box.x;
})();
''', 'HTKTST|0',
     'All class syntax is strict, including heritage and both instance/static computed keys. Each write to a nonwritable property throws TypeError even under sloppy outer execution; the write never changes box.x and later source markers are unreached.'),
    ('context_nested_class_evaluation_uses_outer_super', '''var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;}
 class H extends B {constructor(){
  class Inner extends (trace+='H',super(1),Object) {method(){return [this,new.target];}}
  check(this.value===1);this.Inner=Inner;trace+='h';
 }}
 var h=new H(),hi=new h.Inner(),hp=hi.method();
 check(hp[0]===hi&&hp[1]===undefined&&Object.getPrototypeOf(h)===H.prototype);
 class K extends B {constructor(){
  class Inner {
   [(trace+='K',super(2),'m')](){return [this,new.target];}
   static [(check(new.target===K),trace+='S','s')](){return [this,new.target];}
  }
  check(this.value===2);this.Inner=Inner;trace+='k';
 }}
 var k=new K(),ki=new k.Inner(),kp=ki.m(),sp=k.Inner.s();
 check(kp[0]===ki&&kp[1]===undefined&&sp[0]===k.Inner&&sp[1]===undefined);
 check(Object.getPrototypeOf(k)===K.prototype);return trace;
})();
''', 'HB1hKB2Sk',
     'Nested class heritage and computed names evaluate through the surrounding derived constructor activation. Their super calls initialize the outer this; no inner constructor is invoked by class definition. Newly called instance/static methods have their own receiver and undefined NewTarget.'),
    ('context_escaped_super_after_throw_preserves_owner', '''var result=(function(){
 var trace='',saved,read,token={};
 function A(v){trace+='A'+v;this.value=v;this.target=new.target;}
 function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 function Alternate(){}
 class D extends A {constructor(){
  trace+='D';saved=(v)=>super(v);read=()=>[this,new.target];throw token;
 }}
 try{Reflect.construct(D,[],Alternate);trace+='X';}catch(e){check(e===token);trace+='T';}
 try{read();trace+='Y';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 Object.setPrototypeOf(D,B);var first=saved.call({},7),pair=read.call({});
 check(first.value===7&&first.target===Alternate&&Object.getPrototypeOf(first)===Alternate.prototype);
 check(pair[0]===first&&pair[1]===Alternate);
 Object.setPrototypeOf(D,A);
 try{saved(8);trace+='Z';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 check(read()[0]===first);return trace;
})();
''', 'DTRB7A8R',
     'An escaped arrow retains the function environment after an ordinary thrown completion. It retains original alternate NewTarget and uninitialized this, but reads its original class constructor live parent at each super call. A second call constructs through the newly selected parent before duplicate this binding throws ReferenceError.'),
    ('context_derived_default_super_before_body', '''var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 class D extends B {constructor(x=(trace+='P',super(4)),same=(trace+='Q',this)){
  trace+='D';check(x===this&&same===this&&this.value===4);
 }}
 var d=new D();check(d.target===D&&Object.getPrototypeOf(d)===D.prototype);
 try{new D({});trace+='X';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 return trace;
})();
''', 'PB4QDQR',
     'The first default initializes derived this through super before the second parameter and constructor body execute. Providing that first argument skips its default; the second default then records Q and throws ReferenceError while reading uninitialized this, before the body.')
]

rows = []
for case_id, body, expected, derivation in drafts:
    source = prefix + body
    rows.append({'id': case_id, 'kind': 'semantic', 'source': source,
                 'observation': 'result\n', 'expected': {'type': 'string', 'value': expected},
                 'modes': ['sloppy', 'strict'], 'derivation': derivation,
                 'source_file': put(D / 'literals' / (case_id + '.js'), source.encode()),
                 'observation_file': put(D / 'readbacks' / (case_id + '.js'), b'result\n')})

early = [
    ('context_nested_base_constructor_rejects_outer_super',
     'class Outer extends Object {constructor(){class Inner {constructor(){super();}}super();}}',
     'A nested base constructor does not inherit the enclosing derived constructor permission for super().'),
    ('context_nested_method_arrow_rejects_outer_super',
     'class Outer extends Object {constructor(){class Inner extends Object {m(){return ()=>super();}}super();}}',
     'A nested ordinary method resets constructor context; its arrow cannot capture super-call permission from the more distant outer derived constructor.')
]
for case_id, form, derivation in early:
    setup = 'var touched=0;\n'
    source = 'touched=1;\n' + form + '\n'
    rows.append({'id': case_id, 'kind': 'early-error', 'setup': setup, 'source': source,
                 'expected_error': 'SyntaxError', 'observation': 'touched\n',
                 'expected': {'type': 'number', 'value': 0}, 'modes': ['sloppy', 'strict'],
                 'derivation': derivation,
                 'setup_file': put(D / 'setups' / (case_id + '.js'), setup.encode()),
                 'source_file': put(D / 'literals' / (case_id + '.js'), source.encode()),
                 'observation_file': put(D / 'readbacks' / (case_id + '.js'), b'touched\n')})

cases = obj(D / 'cases.json', rows)
spec = obj(D / 'spec-basis.json', {
    'checked_date': '2026-10-15',
    'basis': 'Current official ECMAScript2027 algorithms read independently. No alternate-engine or candidate execution; no producer source.',
    'references': [
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-source-code.html#sec-strict-mode-code', 'section': '11.2.2', 'application': 'All parts of class declarations and expressions are strict, including evaluation-time expressions.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-class-definitions-static-semantics-early-errors', 'sections': ['15.7.1', '15.4.3'], 'application': 'Base constructors and nonconstructor methods reject direct super calls. Arrows preserve their nearest containing function context; computed keys are evaluated separately.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-classdefinitionevaluation', 'section': '15.7.14', 'application': 'Heritage and method keys run with the surrounding function environment under a temporary class lexical environment; new method bodies establish new function contexts.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword-runtime-semantics-evaluation', 'sections': ['13.3.7.1', '13.3.7.2'], 'application': 'super reads NewTarget and the original active constructor parent, constructs, then binds this. Duplicate binding fails only after construction.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-runtime-semantics-instantiatearrowfunctionexpression', 'section': '15.3.4', 'application': 'Arrows capture their lexical environment, retaining the enclosing function state even after the function exits.'},
        {'url': 'https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-ecmascript-function-objects-construct-argumentslist-newtarget', 'sections': ['10.2.2', '10.2.11'], 'application': 'Derived this starts uninitialized; parameter initialization precedes body evaluation and uses the same function environment.'}
    ]
})
contract = obj(D / 'contract.json', {
    'base': BASE, 'prior_hold': bind(F / 'public-naming-1/source-ready.json'),
    'root_scope': bind(F / 'root/selection-1.json'),
    'scope': 'Four semantic context rows plus two minimal nested-context early-error discriminators, separately appended after67 unchanged public rows.',
    'counts': {'semantic': 4, 'early_error': 2, 'new_groups': 6, 'new_modes': 12,
               'maximum_new_public_calls': 28, 'composed_groups': 73, 'composed_modes': 146,
               'maximum_composed_public_calls': 328},
    'interfaces': 'Reuse unchanged observe and early_error helpers in class_semantics_tests. Fresh Runtime per row/mode; no eval, parser-only path, private quotas or resets.',
    'reachability': 'Counts are prospective. Parent class syntax refusal prevents semantic readbacks; early-error rows require SyntaxError and untouched sentinel, rather than accepting Unsupported. Failed assertions prevent later mode execution.',
    'preservation': 'No earlier hold, published source, baseline or policy changes. Ordinary catchable errors are identity/type checked in JS; no new terminal family.'
})
seal = obj(D / 'literals-ready.json', {
    'status': 'frozen independent context literals before Rust conversion', 'base': BASE,
    'cases': cases, 'contract': contract, 'spec_basis': spec, 'author': bind(Path(__file__)),
    'literal_files': [row[key] for row in rows for key in ['setup_file', 'source_file', 'observation_file'] if key in row],
    'counts': {'semantic': 4, 'early_error': 2, 'groups': 6, 'modes': 12},
    'project_execution': False
})
print(json.dumps(seal))
