#[test]
fn class_public_context_strict_heritage_and_computed_keys() {
    observe(
        "context_strict_heritage_and_computed_keys",
        r###"function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='',box={};Object.defineProperty(box,'x',{value:0,writable:false,configurable:true});
 try {class H extends (trace+='H',box.x=1,Object) {}trace+='X';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class K {[(trace+='K',box.x=2,'m')](){}}trace+='Y';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class S {static [(trace+='S',box.x=3,'m')](){}}trace+='Z';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 check(box.x===0);return trace+'|'+box.x;
})();
"###,
        r###"result
"###,
        Value::String("HTKTST|0".into()),
    );
}

#[test]
fn class_public_context_nested_class_evaluation_uses_outer_super() {
    observe(
        "context_nested_class_evaluation_uses_outer_super",
        r###"function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;}
 class H extends B {constructor(){
  class Inner extends (trace+='H',super(1),Object) {method(){return [this,new.target];}}
  check(this.value===1);this.Inner=Inner;trace+='h';
 }}
 var h=new H(),hi=new h.Inner(),hp=hi.method();
 check(hp[0]===hi&&hp[1]===undefined&&Object.getPrototypeOf(h)===H.prototype);
 class K extends B {constructor(){
  class Inner {
   [(trace+='K',super(2),'m')](){return [this,new.target];}
   static [(check(new.target===K),trace+='S','s')](){return [this,new.target];}
  }
  check(this.value===2);this.Inner=Inner;trace+='k';
 }}
 var k=new K(),ki=new k.Inner(),kp=ki.m(),sp=k.Inner.s();
 check(kp[0]===ki&&kp[1]===undefined&&sp[0]===k.Inner&&sp[1]===undefined);
 check(Object.getPrototypeOf(k)===K.prototype);return trace;
})();
"###,
        r###"result
"###,
        Value::String("HB1hKB2Sk".into()),
    );
}

#[test]
fn class_public_context_escaped_super_after_throw_preserves_owner() {
    observe(
        "context_escaped_super_after_throw_preserves_owner",
        r###"function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='',saved,read,token={};
 function A(v){trace+='A'+v;this.value=v;this.target=new.target;}
 function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 function Alternate(){}
 class D extends A {constructor(){
  trace+='D';saved=(v)=>super(v);read=()=>[this,new.target];throw token;
 }}
 try{Reflect.construct(D,[],Alternate);trace+='X';}catch(e){check(e===token);trace+='T';}
 try{read();trace+='Y';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 Object.setPrototypeOf(D,B);var first=saved.call({},7),pair=read.call({});
 check(first.value===7&&first.target===Alternate&&Object.getPrototypeOf(first)===Alternate.prototype);
 check(pair[0]===first&&pair[1]===Alternate);
 Object.setPrototypeOf(D,A);
 try{saved(8);trace+='Z';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 check(read()[0]===first);return trace;
})();
"###,
        r###"result
"###,
        Value::String("DTRB7A8R".into()),
    );
}

#[test]
fn class_public_context_derived_default_super_before_body() {
    observe(
        "context_derived_default_super_before_body",
        r###"function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 class D extends B {constructor(x=(trace+='P',super(4)),same=(trace+='Q',this)){
  trace+='D';check(x===this&&same===this&&this.value===4);
 }}
 var d=new D();check(d.target===D&&Object.getPrototypeOf(d)===D.prototype);
 try{new D({});trace+='X';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 return trace;
})();
"###,
        r###"result
"###,
        Value::String("PB4QDQR".into()),
    );
}

#[test]
fn class_public_context_nested_base_constructor_rejects_outer_super() {
    early_error(
        "context_nested_base_constructor_rejects_outer_super",
        r###"var touched=0;
"###,
        r###"touched=1;
class Outer extends Object {constructor(){class Inner {constructor(){super();}}super();}}
"###,
        r###"touched
"###,
        Value::Number(0.0),
    );
}

#[test]
fn class_public_context_nested_method_arrow_rejects_outer_super() {
    early_error(
        "context_nested_method_arrow_rejects_outer_super",
        r###"var touched=0;
"###,
        r###"touched=1;
class Outer extends Object {constructor(){class Inner extends Object {m(){return ()=>super();}}super();}}
"###,
        r###"touched
"###,
        Value::Number(0.0),
    );
}

