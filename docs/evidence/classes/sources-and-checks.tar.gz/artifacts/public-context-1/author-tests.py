from pathlib import Path
import difflib
import hashlib
import json
import re

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-context-1'
RELATIVE = 'src/script/class_semantics_tests.rs'

def sha(b):
    return hashlib.sha256(b).hexdigest()

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': sha(b)}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2) + '\n').encode())

literal_seal = bind(D / 'literals-ready.json')
assert literal_seal['sha256'] == '3dc49e78b810805bf7fc16a56b64e9ddf1a7a08df489e48714a19e510cb802df'
rows = json.loads((D / 'cases.json').read_bytes())
assert len(rows) == 6
prior = F / 'public-naming-1/raw' / RELATIVE
before = prior.read_bytes()
assert sha(before) == '3263b156c168d4e7644e2603c7898968fc76ba17fc29642d055ff2d5de7a72d2'
old_names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', before.decode(), re.M)
assert len(old_names) == len(set(old_names)) == 67
blocks = []
roster = []
for row in rows:
    for key in ['setup_file', 'source_file', 'observation_file']:
        if key in row:
            assert bind(Path(row[key]['path'])) == row[key]
    source = Path(row['source_file']['path']).read_text()
    observation = Path(row['observation_file']['path']).read_text()
    assert source == row['source'] and observation == row['observation']
    name = 'class_public_' + row['id']
    assert name not in old_names
    if row['kind'] == 'semantic':
        helper = 'observe'
        literals = [source, observation]
        expected = 'Value::String(' + json.dumps(row['expected']['value']) + '.into())'
    else:
        assert row['kind'] == 'early-error' and row['expected_error'] == 'SyntaxError'
        helper = 'early_error'
        setup = Path(row['setup_file']['path']).read_text()
        assert setup == row['setup']
        literals = [setup, source, observation]
        assert row['expected'] == {'type': 'number', 'value': 0}
        expected = 'Value::Number(0.0)'
    assert all('"###' not in literal for literal in literals)
    args = [json.dumps(row['id'])] + ['r###"' + literal + '"###' for literal in literals] + [expected]
    block = '#[test]\nfn ' + name + '() {\n    ' + helper + '(\n        ' + ',\n        '.join(args) + ',\n    );\n}\n\n'
    assert re.findall(r'r###"(.*?)"###', block, re.S) == literals
    assert expected in block
    blocks.append(block)
    roster.append({'test_name': name, 'case_id': row['id'], 'kind': row['kind'],
                   'modes': row['modes'], 'helper': helper,
                   'literals': [row[key] for key in ['setup_file', 'source_file', 'observation_file'] if key in row],
                   'expected': row['expected'], 'expected_error': row.get('expected_error')})

suffix = ''.join(blocks).encode()
after = before + suffix
assert after[:len(before)] == before
names = re.findall(r'^fn (class_public_[a-z0-9_]+)\(\)', after.decode(), re.M)
assert len(names) == len(set(names)) == 73 and names[:67] == old_names
before_ref = put(D / 'before' / RELATIVE, before)
raw_ref = put(D / 'raw' / RELATIVE, after)
append_ref = put(D / 'append-tests.rs', suffix)
diff = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True),
                                   fromfile='before/' + RELATIVE, tofile='raw/' + RELATIVE))
diff_ref = put(D / 'diffs' / (RELATIVE + '.diff'), diff.encode())
roster_ref = obj(D / 'roster.json', {
    'new_tests': roster, 'original_test_names': old_names, 'composed_test_names': names,
    'new_semantic_groups': 4, 'new_early_error_groups': 2,
    'new_mode_attempts': 12, 'maximum_new_public_calls': 28,
    'composed_groups': 73, 'composed_mode_attempts': 146, 'maximum_composed_public_calls': 328,
    'qualification': 'Counts are planned. Failed assertions stop the current Rust test and make subsequent readbacks or modes unreached.'
})
checks = obj(D / 'checks.json', {
    'literal_conversion': 'All14 JS/setup/readback byte strings were extracted from raw Rust strings and matched the frozen contract; four string and two numeric expectations match.',
    'original_preservation': 'The first37944 bytes equal the immutable public-naming-1 full module; removing the suffix restores the entire67-row payload byte-for-byte.',
    'prior_hold': bind(F / 'public-naming-1/source-ready.json'),
    'original_test_hold': bind(F / 'public-tests-1/source-ready.json'),
    'original_conversion_peer': bind(F / 'public-tests-review-1/review.json'),
    'interfaces': 'Unchanged observe/early_error helpers; public execute/execute_strict, fresh runtime each mode, no private quotas/resets/terminal recovery.',
    'registration': 'No new module or registration. Root may append the exact fragment after an independently formatted67-row prefix.',
    'execution': 'Only this external stdlib author/checker ran. No project imports/compiler/JS/test commands or live edits.'
})
seal = obj(D / 'source-ready.json', {
    'status': 'ready for independent peer and root additive tests-only import',
    'base': 'f3118ae5787c410648657f7c822efb7014201dd1',
    'frozen_literals': literal_seal, 'cases': bind(D / 'cases.json'),
    'contract': bind(D / 'contract.json'), 'spec_basis': bind(D / 'spec-basis.json'),
    'files': [{'relative_path': RELATIVE, 'before': before_ref, 'raw': raw_ref, 'diff': diff_ref}],
    'append': append_ref, 'roster': roster_ref, 'checks': checks,
    'authors': [bind(D / 'author-literals.py'), bind(Path(__file__))],
    'new_groups': 6, 'new_mode_attempts': 12, 'composed_groups': 73,
    'registration_changes': 0,
    'qualification': 'Frozen expectations precede Rust conversion. Earlier67 literals/test bodies remain exact; no candidate or producer reads and no project execution.'
})
print(json.dumps(seal))
