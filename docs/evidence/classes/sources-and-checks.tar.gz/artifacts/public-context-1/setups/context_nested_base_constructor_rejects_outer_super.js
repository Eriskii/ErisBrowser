var touched=0;
