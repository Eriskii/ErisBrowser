touched=1;
class Outer extends Object {constructor(){class Inner {constructor(){super();}}super();}}
