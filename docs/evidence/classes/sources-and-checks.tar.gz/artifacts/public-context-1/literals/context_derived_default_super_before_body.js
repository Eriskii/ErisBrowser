function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 class D extends B {constructor(x=(trace+='P',super(4)),same=(trace+='Q',this)){
  trace+='D';check(x===this&&same===this&&this.value===4);
 }}
 var d=new D();check(d.target===D&&Object.getPrototypeOf(d)===D.prototype);
 try{new D({});trace+='X';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 return trace;
})();
