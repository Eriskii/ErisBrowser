function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='';function B(v){trace+='B'+v;this.value=v;}
 class H extends B {constructor(){
  class Inner extends (trace+='H',super(1),Object) {method(){return [this,new.target];}}
  check(this.value===1);this.Inner=Inner;trace+='h';
 }}
 var h=new H(),hi=new h.Inner(),hp=hi.method();
 check(hp[0]===hi&&hp[1]===undefined&&Object.getPrototypeOf(h)===H.prototype);
 class K extends B {constructor(){
  class Inner {
   [(trace+='K',super(2),'m')](){return [this,new.target];}
   static [(check(new.target===K),trace+='S','s')](){return [this,new.target];}
  }
  check(this.value===2);this.Inner=Inner;trace+='k';
 }}
 var k=new K(),ki=new k.Inner(),kp=ki.m(),sp=k.Inner.s();
 check(kp[0]===ki&&kp[1]===undefined&&sp[0]===k.Inner&&sp[1]===undefined);
 check(Object.getPrototypeOf(k)===K.prototype);return trace;
})();
