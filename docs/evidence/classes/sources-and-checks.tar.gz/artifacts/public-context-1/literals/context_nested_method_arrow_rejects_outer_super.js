touched=1;
class Outer extends Object {constructor(){class Inner extends Object {m(){return ()=>super();}}super();}}
