function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='',box={};Object.defineProperty(box,'x',{value:0,writable:false,configurable:true});
 try {class H extends (trace+='H',box.x=1,Object) {}trace+='X';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class K {[(trace+='K',box.x=2,'m')](){}}trace+='Y';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 try {class S {static [(trace+='S',box.x=3,'m')](){}}trace+='Z';}
 catch(e){check(e instanceof TypeError);trace+='T';}
 check(box.x===0);return trace+'|'+box.x;
})();
