function check(v){if(!v)throw new Error('class context oracle');}
var result=(function(){
 var trace='',saved,read,token={};
 function A(v){trace+='A'+v;this.value=v;this.target=new.target;}
 function B(v){trace+='B'+v;this.value=v;this.target=new.target;}
 function Alternate(){}
 class D extends A {constructor(){
  trace+='D';saved=(v)=>super(v);read=()=>[this,new.target];throw token;
 }}
 try{Reflect.construct(D,[],Alternate);trace+='X';}catch(e){check(e===token);trace+='T';}
 try{read();trace+='Y';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 Object.setPrototypeOf(D,B);var first=saved.call({},7),pair=read.call({});
 check(first.value===7&&first.target===Alternate&&Object.getPrototypeOf(first)===Alternate.prototype);
 check(pair[0]===first&&pair[1]===Alternate);
 Object.setPrototypeOf(D,A);
 try{saved(8);trace+='Z';}catch(e){check(e instanceof ReferenceError);trace+='R';}
 check(read()[0]===first);return trace;
})();
