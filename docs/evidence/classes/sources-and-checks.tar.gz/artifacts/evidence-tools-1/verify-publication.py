"""Root-executed, pre-commit verifier for the classes checkpoint evidence."""
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
E = W / 'docs/evidence/classes'
RAW_CAP = 64 * 1024 * 1024
GZIP_CAP = 8 * 1024 * 1024
DOC_PATHS = {'README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
             'docs/SECURITY.md', 'docs/VALIDATION.md', 'docs/classes.md'}
EXCLUDED_TOP = {'worktree', 'publication'}
EXCLUDED_DIRS = {'__pycache__', '.git', 'target'}
ROOT_OUTPUTS = {'root/evidence-selection.json', 'root/publication-verification.json',
                'root/github-publication.json'}
BINARY_SUFFIXES = {'.pyc', '.pyo', '.o', '.obj', '.a', '.so', '.dylib', '.dll',
                   '.exe', '.rlib', '.rmeta', '.wasm', '.bin'}
BINARY_MAGIC = (b'\x7fELF', b'MZ', b'\x00asm', b'!<arch>\n',
                b'\xfe\xed\xfa\xce', b'\xce\xfa\xed\xfe',
                b'\xfe\xed\xfa\xcf', b'\xcf\xfa\xed\xfe', b'\xca\xfe\xba\xbe')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def regular(path):
    relative = path.relative_to(P)
    current = P
    assert not P.is_symlink()
    for part in relative.parts:
        current /= part
        assert not current.is_symlink(), current
    assert stat.S_ISREG(path.stat(follow_symlinks=False).st_mode), path
    return path.read_bytes()


def bind(path):
    data = regular(path)
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def read(name):
    return json.loads(regular(P / name))


def safe_name(name):
    p = PurePosixPath(name)
    assert isinstance(name, str) and name and not p.is_absolute()
    assert '..' not in p.parts and '.' not in p.parts and str(p) == name, name
    return name


def external_files():
    accepted = []

    def visit(directory):
        with os.scandir(directory) as entries:
            ordered = sorted(entries, key=lambda e: e.name)
        for entry in ordered:
            path = Path(entry.path)
            relative = path.relative_to(P).as_posix()
            info = entry.stat(follow_symlinks=False)
            if stat.S_ISLNK(info.st_mode):
                continue
            if stat.S_ISDIR(info.st_mode):
                if (directory == P and entry.name in EXCLUDED_TOP) or entry.name in EXCLUDED_DIRS:
                    continue
                visit(path)
            elif stat.S_ISREG(info.st_mode):
                if relative in ROOT_OUTPUTS:
                    continue
                with path.open('rb') as stream:
                    prefix = stream.read(16)
                if path.suffix.lower() in BINARY_SUFFIXES or prefix.startswith(BINARY_MAGIC):
                    continue
                accepted.append(path)
    visit(P)
    return accepted


def git_paths(arguments):
    output = subprocess.check_output(['git', *arguments], cwd=W)
    return {os.fsdecode(path) for path in output.split(b'\0') if path}


def main():
    assert regular(P / 'source-candidate-2.json') == regular(P / 'source-final.json')
    final_record, parent_record = read('source-final.json'), read('source-parent.json')
    assert final_record['base'] == parent_record['base']
    assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == final_record['base'], 'run this verifier before committing'
    final, parent = final_record['source_sha256'], parent_record['source_sha256']
    assert set(parent) <= set(final)
    for path, digest in final.items():
        assert sha(regular(W / safe_name(path))) == digest, path
    sources = {p for p, digest in final.items() if parent.get(p) != digest}
    assert len(sources) == 30
    docs = read('documentation-2/source-ready.json')['files']
    doc_names = [safe_name(r.get('relative', r.get('relative_path', r.get('path')))) for r in docs]
    assert len(docs) == len(set(doc_names)) == 6 and set(doc_names) == DOC_PATHS
    assert not sources & DOC_PATHS
    for name, row in zip(doc_names, docs):
        assert bind(Path(row['raw']['path'])) == row['raw']
        actual = bind(W / name)
        assert (actual['bytes'], actual['sha256']) == (row['raw']['bytes'], row['raw']['sha256'])
    manifest = json.loads(regular(E / 'manifest.json'))
    assert manifest['schema'] == 1 and manifest['status'] == 'verified'
    assert manifest['archive']['path'] == 'sources-and-checks.tar.gz'
    archive_path = E / 'sources-and-checks.tar.gz'
    packed = regular(archive_path)
    assert len(packed) == manifest['archive']['bytes'] < GZIP_CAP
    assert sha(packed) == manifest['archive']['sha256']
    with gzip.GzipFile(fileobj=io.BytesIO(packed), mode='rb') as stream:
        raw = stream.read(RAW_CAP + 1)
    assert len(raw) == manifest['archive']['uncompressed_tar_bytes'] < RAW_CAP
    selection = read('root/evidence-selection.json')
    assert selection['status'] == 'frozen'
    selected = selection['members']
    assert manifest['members'] == selected
    assert manifest['selection'] == bind(P / 'root/evidence-selection.json')
    assert manifest['source_inventory'] == bind(P / 'source-final.json')
    assert manifest['candidate_inventory'] == bind(P / 'source-candidate-2.json')
    assert manifest['caps'] == dict(raw_bytes=RAW_CAP, gzip_bytes=GZIP_CAP)
    assert manifest['inventory_scope'] == final_record['scope']
    authorities = {'ledger': 'root/final-validation.json',
                   'peer': 'validation-review-1/final-review.json',
                   'documentation_peer': 'documentation-review-1/review.json',
                   'documentation_hold': 'documentation-2/source-ready.json'}
    assert manifest['claims_authority'] == {name: bind(P / path) for name, path in authorities.items()}
    assert manifest['claims'] == read('root/final-validation.json')
    assert manifest['claims']['status'] == 'pass'
    assert read(authorities['peer'])['status'] == read(authorities['documentation_peer'])['status'] == 'clear'

    # Reconstruct the complete expected membership instead of trusting the tar index.
    expected_members = {}
    for name in sources:
        expected_members['sources/' + name] = (W / name, 'changed-source')
    for name in doc_names:
        expected_members['documentation/' + name] = (W / name, 'published-documentation')
    for path in external_files():
        relative = path.relative_to(P).as_posix()
        expected_members['artifacts/' + relative] = (path, 'root-receipt-or-script' if relative.startswith('root/') else 'validation-artifact')
    assert [r['path'] for r in selected] == sorted(expected_members), 'omitted, duplicate or extra evidence member'
    assert manifest['source_count'] == 30 and manifest['documentation_count'] == 6
    assert manifest['artifact_count'] == len(selected) - 36
    assert sum(r['bytes'] for r in selected) == manifest['archive']['member_bytes'] < RAW_CAP
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
        assert archive.getnames() == [r['path'] for r in selected]
        for row in selected:
            safe_name(row['path'])
            origin, role = expected_members[row['path']]
            assert row['origin'] == str(origin) and row['role'] == role
            member = archive.getmember(row['path'])
            assert member.isfile() and not member.issym() and not member.islnk()
            assert member.size == row['bytes'] and member.mode == 0o644
            assert (member.mtime, member.uid, member.gid, member.uname, member.gname) == (0, 0, 0, '', '')
            data = archive.extractfile(member).read()
            assert len(data) == row['bytes'] and sha(data) == row['sha256']
            assert data == regular(origin), row['origin']
    evidence = {'docs/evidence/classes/manifest.json', 'docs/evidence/classes/sources-and-checks.tar.gz'}
    expected_paths = sources | DOC_PATHS | evidence
    assert len(expected_paths) == 38
    changed = git_paths(['diff', '--name-only', '-z', 'HEAD'])
    changed.update(git_paths(['ls-files', '--others', '--exclude-standard', '-z']))
    assert changed == expected_paths, {'extra': sorted(changed - expected_paths), 'missing': sorted(expected_paths - changed)}
    subprocess.run(['git', 'diff', '--check'], cwd=W, check=True)
    record = dict(status='verified', expected_commit_paths=sorted(expected_paths), path_count=38,
        source_paths=30, documentation_paths=6, evidence_paths=2, members=len(selected),
        archive=bind(archive_path), manifest=bind(E / 'manifest.json'),
        source_final_equals_candidate2_bytes=True, every_member_equals_origin=True,
        complete_external_membership_reconstructed=True, every_selected_source_equals_final_inventory=True,
        claims_authority=manifest['claims_authority'])
    with (P / 'root/publication-verification.json').open('x') as stream:
        json.dump(record, stream, indent=2); stream.write('\n')
    print(json.dumps({k: v for k, v in record.items() if k != 'expected_commit_paths'}))


if __name__ == '__main__':
    main()
