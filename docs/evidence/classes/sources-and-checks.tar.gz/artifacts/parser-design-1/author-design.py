from pathlib import Path
import hashlib, json, subprocess
N=Path('/tmp/eris-class-runtime-plan-1')
O=N/'parser-design-1'
REPO=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
OLD='15db31c76f5a2f259deffadbf0f95e212a5fa61c'
def digest(b): return hashlib.sha256(b).hexdigest()
def bind(p):
    p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def put(name,data):
    p=O/name; p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n')
paths=[
'src/script.rs','src/script/code.rs','src/script/code/records.rs',
'src/script/parser.rs','src/script/parser/driver.rs','src/script/parser/driver/expressions.rs',
'src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs',
'src/script/names.rs','src/script/parser_legacy.rs','src/script/tokens.rs',
'src/script/machine.rs','src/script/machine/calls.rs','src/script/machine/statements.rs',
'src/script/machine/call_spread.rs','src/script/construction.rs','src/script/property_keys.rs',
'src/script/code/call_spread_layout_tests.rs','src/script/parser/driver/call_spread_layout_tests.rs',
'src/script/parser/driver/expressions/argument_in_context_tests.rs',
'src/script/parser/driver/expressions/expression_in_context_tests.rs',
'src/script/parser/call_spread_cut_tests.rs','src/script/machine/call_spread_phase_tests.rs']
sources=[]
for path in paths:
    b=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=REPO)
    old=subprocess.check_output(['git','show',f'{OLD}:{path}'],cwd=REPO)
    assert b==old,path
    p=O/'inputs'/path; p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    sources.append({'path':path,'bytes':len(b),'sha256':digest(b),'blob_oid':hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(),'same_as_previous_runtime_base':True})
put('source-bindings.json',{'base':BASE,'previous_runtime_base':OLD,'read_method':'Read-only git show; no module imports, project execution or working-tree writes.','source_count':len(sources),'sources':sources})
selection=json.loads((N/'root/selection-1.json').read_text())
refs=[
('class-grammar','https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-class-definitions','15.7, 15.4, 15.3'),
('contains-boundaries','https://tc39.es/ecma262/multipage/syntax-directed-operations.html#sec-static-semantics-contains','8.5.1'),
('super-call','https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword','13.3.7')]
put('primary-rules.json',{'read_date':'2026-10-15','source':'Official current TC39 multipage ECMA-262, displayed as ECMAScript 2027 draft; current pages, not a pinned revision.','references':[{'id':a,'url':b,'sections':c} for a,b,c in refs], 'paraphrase':{
'class-grammar':'Heritage uses LeftHandSideExpression. Class code is strict. Only one literal instance constructor is allowed; it cannot be an accessor/async/generator method. Literal static prototype is forbidden. Super calls belong only to a derived constructor, including its lexical arrows. Computed constructor/prototype keys follow ordinary runtime key semantics.',
'contains-boundaries':'Class containment observes heritage and computed member names, excluding member bodies. Arrow containment carries lexical super, this and new.target. These boundaries require class keys to inherit the surrounding function context while member parameters and bodies establish their own.',
'super-call':'Read NewTarget and capture the current active constructor superclass before evaluating explicit arguments. Check constructibility after argument evaluation, construct using that NewTarget, then bind the derived this value. Default derived construction forwards the existing argument list without invoking an iterator.'},'qualification':'The record layout and parser algorithm below are repository design inferences; no TC39 text is copied verbatim.'})
record_text='''DESIGN ONLY — not a Rust implementation or a measured ABI.

ClassId(usize)                                      // Copy, private to one Unit
ClassKind { ExplicitBase, ExplicitDerived, DefaultBase, DefaultDerived }
ClassElementKind { Method, Getter, Setter }
Class {
    name: Option<String>,                          // syntactic binding only
    heritage: Option<ExprId>,                       // Some(null expression) is derived
    constructor: FunctionId,
    elements: Vec<ClassElement>,                    // all non-constructor members, source order
}
ClassElement {
    name: code::PropertyName,                       // Literal(JsString) | Computed(ExprId)
    function: FunctionId,
    kind: ClassElementKind,
    is_static: bool,
}
Unit { ...existing fields..., classes: Records<Class> }
code::Function { ...existing fields..., class_kind: Option<ClassKind> }
Expr additions: Class(ClassId), SuperCall(Vec<ExprId>), SuperCallSpread(Vec<ExprId>)
Stmt addition: Class(ClassId)                       // requires Class.name == Some(...)

No Box<Expr/Stmt/Class>, child Rc<Unit>, recursive function body ownership, or
runtime values are stored in Class records. ClassId, FunctionId, ExprId and
StmtId belong to the same Unit. Existing spread markers remain ExprId edges.
FunctionId always exists, including a default constructor's empty tagged code.
A default constructor has no synthetic parameter/body source; runtime dispatch
uses its tag rather than treating an empty derived body as implicit success.
'''
(O/'record-shape.txt').write_text(record_text)
design={
'format':1,
'status':'Frozen design proposal for root/constructor reconciliation; not selected implementation, numeric fees, tests or measured layout.',
'base':BASE,'prior_runtime_base':OLD,
'authority':{key:bind(N/path) for key,path in [('selection','root/selection-1.json'),('provisional_selection','root/selection-provisional.json'),('readiness','readiness-1/readiness.json'),('base_refresh','root/readiness-base-refresh.json'),('source_parent','source-parent.json'),('separate_historical_migrations','migrations-1/source-ready.json')]},
'boundary':{'included':selection['included'],'unsupported':selection['explicitly_unsupported'],'limits':selection['limits'],'old_profile_rule':selection['constraints'][3]},
'representation':{
'declarations':'record-shape.txt',
'publish':'add_class mirrors add_expr/add_function: derive ID from current length, charge/reserve/push through Records<Class>, publish the ID only after append succeeds. Finish the whole unpublished Unit only after syntax/scope checks.',
'constructor':'Store its FunctionId once, outside elements. A literal nonstatic constructor has no evaluated key and is identified during parsing. Its source position does not create a runtime key effect. All other members, including computed constructor and static constructor, stay in source order.',
'default':'At closing brace without a constructor, emit a strict, non-arrow, constructable Function with empty params/body and a DefaultBase or DefaultDerived tag. Its length is zero. Do not synthesize rest/spread or read arguments.',
'explicit':'Explicit constructor params/body receive the appropriate ClassKind. Class member methods/accessors have class_kind=None, arrow=false, self_name=false, constructable=false, strict=true. All existing Function factories/empty/lowering initializers explicitly receive None.',
'names':'Class.name owns the optional syntactic name. The Stmt::Class edge reuses that name for the outer declaration; the runtime creates separate outer and inner bindings. Runtime inferred names are PropertyKeys passed to evaluation, never written into immutable source records.',
'ownership':'Class owns only its nonrecursive element vector, strings/JsStrings and flat IDs. Methods own the existing flat Function record. Partial parse failure drops a flat forest; escaped closures retain their Unit through the existing FunctionRef.',
'no_new_class_element_arena':'Element positions are bounded usize indexes into Class.elements; no extra ClassElementId arena or global registry is needed.',
'function_runtime_boundary':'The proposal adds only a code::Function discriminator; runtime Function storage need not change. Environment/activation changes remain constructor-design ownership and require their own source/ABI proof.'},
'parser_continuations':{
'new_module':'src/script/parser/driver/classes.rs; Kind::Class(classes::Frame), Output::Class(ClassId), conversion/extraction and dispatch. Pending class State owns scalar restoration flags, optional name/heritage/constructor IDs and its charged element vector.',
'phases':[
{'phase':'Start(declaration_or_expression)','action':'Save strict/allow_in/in_class; set strict=true and in_class=true before the binding name. Require a binding name for declarations; permit anonymous expressions. Preserve function_depth, new.target, super-call permission, loops and labels. If extends occurs, set allow_in=true and enter LeftHandSide; otherwise expect body brace.'},
{'phase':'Heritage(State)','action':'Capture ExprId, restore outer allow_in before consuming class body; do not evaluate anything. No binary/assignment/unparenthesized sequence or postfix update is admitted as bare heritage.'},
{'phase':'Elements(State)','action':'Skip semicolons. At }, emit a default tagged constructor if needed and append Class only after validations. Otherwise classify static/get/set/async/* versus ordinary key using unescaped contextual tokens and bounded lookahead.'},
{'phase':'Key(State, member_header)','action':'Use existing Key continuation: literal IdentifierName/string/numeric or [AssignmentExpression +In]. The computed expression inherits the enclosing super/new.target permission and class strictness. Parenthesized sequences remain possible; a bare comma between brackets is not newly admitted.'},
{'phase':'Member(State, key, kind, is_static)','action':'Classify literal constructor/static prototype before entering method parameters. Enter a distinct function mode for ordinary class method, base constructor or derived constructor; method parameters and body use existing explicit Function continuations.'},
{'phase':'MemberDone(State, key, kind, is_static)','action':'Validate accessor arity/rest prohibition, force strict non-arrow method flags, add Function, then store ctor ID or append element with parser::push. Continue source order.'},
{'phase':'Finish(State)','action':'Consume closing brace, restore class strict/allow_in/in_class flags before returning ClassId to the expression/statement parent. Parent emits Expr::Class or Stmt::Class through existing charged record append.'}],
'function_entry':'Extend functions::Context with saved super_call_allowed. A distinct start mode sets it true only for explicit derived literal constructors, false for base constructors/ordinary functions/dynamic functions/object and class methods; arrow entry inherits it. Save/restore uses the existing owned labels transfer, not a clone. Function contexts are installed before parameter initializers.',
'left_hand_side':'Introduce an explicit LeftHandSide entry or equivalent update-permission mode carried through every Postfix/Computed/Arguments resume. It admits calls/member access/new/class and stops before postfix ++/--. Keep existing normal expression behavior unchanged. A SuperCall entry is valid in CallExpression position; never admit bare new super() by treating super as an unrestricted Primary/New operand.',
'super_arguments':'Use two explicit output forms for ordinary and spread super arguments, with the same existing Assignment/+In/comma/trailing-comma grammar and saved allow_in discipline. No fake callee expression or implicit this argument. Super property tokens . or [ are Unsupported; a bare super is a syntax error.',
'error_cleanup':'On errors, restore entry scalar grammar flags including new strict/super/in_class state while keeping all spent quota. Normal function/class restoration remains ownership-based; successful dynamic parameter parsing keeps its intentional handoff. Do not claim an error unwind restores moved labels without an explicit cleanup design. No parser state from a failed compilation is published.',
'private_boundary':'The current lexer stores a terminal Invalid token at #, so token_is("#") cannot detect private syntax. Proposed minimal classification: while in_class, Parser::error recognizes a current Invalid token whose exact source offset starts # and reports Unsupported. The flag survives nested methods/functions and is restored at class exit. This covers a private declaration or access encountered before its later declaration without changing successful lexing or global token allocation. Invalid # outside a class retains current rejection. Decorator lexing remains out of scope; no valid decorator form is admitted.',
'no_preparse_rewrite':'No source scan that strips class syntax, alternate parser, synthetic source, recursive parser call or private-name parser is proposed.'},
'context_matrix':[
{'region':'program or ordinary function','strict':'existing enclosing rules','super_call':'false','new_target':'existing rules'},
{'region':'class name, heritage and computed member key','strict':'true','super_call':'inherit enclosing lexical permission','new_target':'inherit enclosing lexical permission'},
{'region':'explicit base constructor params/body','strict':'true','super_call':'false','new_target':'true'},
{'region':'explicit derived constructor params/body','strict':'true','super_call':'true','new_target':'true'},
{'region':'ordinary instance/static method or accessor params/body','strict':'true','super_call':'false','new_target':'true, with ordinary method-call value undefined'},
{'region':'arrow params/body','strict':'inherit','super_call':'inherit nearest non-arrow function context','new_target':'inherit'},
{'region':'nested ordinary/dynamic function','strict':'existing inherited/directive rules','super_call':'false','new_target':'true'}],
'early_errors_and_deferred':{
'errors':[
'Class declaration has no name; class declaration in a controlled statement/label position that does not admit declarations; invalid/strict binding names.',
'Duplicate literal instance constructors, including equivalent IdentifierName/string spelling; a literal instance constructor accessor is invalid. Static constructor is an ordinary static method.',
'Literal static method/accessor named prototype is invalid; computed static prototype is not an early error and reaches runtime property definition.',
'SuperCall in base constructor, method/accessor, ordinary function or top-level context is a syntax error. Derived constructor parameter initializers and lexical arrows are permitted. Nested class heritage/computed names inherit this permission; nested method bodies do not.',
'All class methods/constructors have unique parameters. Existing non-simple/use-strict, getter zero/setter one non-rest parameter, strict binding, strict delete and strict legacy literal rules continue.',
'Lexical duplicate/conflict rules include class declarations across a statement list, switch case list, parameter/body boundary and catch binding/body boundary; a nested class body is not an outer scope declaration walk.'],
'unsupported_boundaries':[
'A property name not followed by method parentheses, including =, ;, } or line-separated field continuation, selects the deferred field boundary; never lower it to an empty method.',
'Static { selects deferred static block; * or async method production selects deferred generator/async method; async(), get(), set(), static() remain ordinary method names where grammar says so.',
'Private # syntax in class context and all super property forms select Unsupported before author execution.',
'Unsupported production boundaries need not implement every early-error precedence rule of the deferred grammar. Admitted forms must enforce all applicable early errors.']},
'scope_and_evaluation_interfaces':{
'compile_walk':'Stmt::is_lexical_declaration includes Stmt::Class. check_scope and check_parameter_lexicals borrow Class.name through its ID and feed existing charged Names logic. StatementWalk treats Class as a leaf, as it does Function; method/constructor variables never hoist into surrounding scopes.',
'body_flags':'Body.has_lexical observes Class so program/block/switch/function scope checks run. Class declaration dispatch occurs only where declarations are permitted; existing bare if/loop/label refusal remains.',
'runtime_lexicals':'validate_lexical/instantiate_lexical create a mutable outer class-declaration binding, uninitialized and not a global object property. The class evaluation creates a distinct immutable strict inner binding for a syntactic name before heritage; it stays uninitialized through computed names/method creation. Initialize inner binding on successful definition completion, then initialize outer binding in the statement continuation. A failed definition leaves the outer TDZ binding uninitialized.',
'class_job':'Propose a dedicated machine class-evaluation frame, retaining Unit/ClassId, class environment, constructor/prototype handles, element index and an optional inferred-name key. Heritage and each computed key yield through existing expression machinery. Never recursively execute class syntax in a native helper.',
'class_order':'Constructor/prototype allocation follows heritage validation. Define constructor name before processing static elements, so static name/length methods can replace configurable metadata. Evaluate/convert each computed key exactly once in source order and define that element before moving on. Getter/setter pair and overwrite behavior use ordinary own-property descriptor operations; no inherited setter call.',
'inferred_name':'Introduce a pre-evaluation named-class hint at syntactically anonymous Class expressions in simple variable/lexical initializers, identifier = and logical assignment, parameter defaults and object property value evaluation. Keep parenthesized anonymous-class detection consistent with the current flat grammar. The hint is a runtime PropertyKey for computed object keys and a paid name value for bindings. Do not extend Unit::anonymous and apply the existing post-value rename to classes: it can overwrite a static name method. Existing function name behavior stays on its old paths; no unrelated function-name conformance expansion is proposed.',
'constructor_handoff':'Class factory gives the constructor its class environment and tagged FunctionRef. SuperCall runtime captures active constructor and NewTarget before argument evaluation, constructs with that NewTarget, and binds this once. Persistent lexical this/super ownership, native subclass return paths and default-derived original-list forwarding are constructor-design responsibilities.',
'default_constructability':'No heritage is base; any heritage syntax, including null, is derived. A default-derived tagged Function must not run the empty source body as an ordinary derived constructor. Both default variants retain length zero and source-free behavior.'},
'accounting_and_layout':{
'existing_charged_primitives':[
'Parser driver dispatch retains its work(1) per transition. Pending continuation reserve uses existing len+1 relocation work, geometric capacity from at least four, and capacity*sizeof(Kind)+32 before try_reserve_exact/push.',
'parser::push retains work(1), MAX_TOKENS, len+1 relocation work and capacity*sizeof(T)+32 before vector reserve. Class elements and super argument IDs use it; scalar flags/IDs do not hide an uncharged vector.',
'Records<T> retains work(1) append, paged storage of 128 records, charged directory growth, MAX_TOKENS and reserve-before-length/publication. Classes use a new instantiation of this helper.',
'Unit::finish retains work(1) and sizeof(Unit)+2*sizeof(usize) allocation before Rc publication. New classes header affects every Unit, including empty/intrinsic FunctionRef units, even when no class syntax is present.',
'Identifier copying, PropertyName key construction, Names conflict checks, string limits and code-copy allowances keep their existing formulas. Any new comparison scan or name/value clone must appear in a later ownership/work proof before production.',
'Runtime frame reserve/stack accounting remain existing mechanisms; any Frame growth changes typed charges and MAX_HEAP/sizeof(Frame) and must be measured and migrated, never silently compensated by raising a ceiling.'],
'unknown_numeric_values':'No ABI size, new fixed fee, startup delta or exact class work quota is selected or guessed in this design.',
'measure_required':[
'Complete old/proposed code::Expr, Stmt, Function, Unit, Class, ClassElement and all neighboring payload types; both size and alignment.',
'Complete parser expressions/functions/classes/statements Frame and State, Output, Kind, Transition, Parser scalar/context records; do not omit old enum variants in mirrors.',
'Complete runtime machine Frame/ExprFrame/Phase/Activation, class frame, Environment and any constructor records chosen by Script, plus Runtime and affected retained-arena envelopes.',
'Four actual configurations after selection: Rust 1.88 ordinary/host and current stable ordinary/host+Vulkan; physical vector capacity behavior must be observed rather than inferred from try_reserve_exact.'],
'required_proof_before_private_quota_contract':'Map each newly owned name/key/environment/function/object/value/list and each refusal point to paid cleanup; checked arithmetic and charge precede reserve/mutation. Terminal ResourceLimit/Unsupported must remain sticky and must not be materialized as ordinary catchable errors. No public or private test payload is authored here.',
'limits':'All selected ceilings are preserved; token-bounded lists and explicit continuation frames bound parser nesting. New record types do not introduce a separate user-visible class count or depth cap.'},
'likely_touchpoints':{
'parser_and_code':['src/script/code.rs','src/script/parser.rs','src/script/parser/driver.rs','src/script/parser/driver/expressions.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','new src/script/parser/driver/classes.rs'],
'runtime_interfaces':['src/script.rs lexical initialization/Function factories','src/script/machine.rs class dispatch and pre-evaluation name hints','src/script/machine/statements.rs class completion and binding initialization','src/script/machine/calls.rs parameter default name hint/constructor activation','src/script/construction.rs constructor contract','new class runtime continuation module, placement to reconcile with Script'],
'historical_source_qualification':'Root migrations-1 owns only two old unavailable-class literal substitutions. Do not duplicate them in production. Published cfg(test) recursive legacy parser remains an unsupported-class reference; production stays direct flat. Exhaustive cfg(test) lowering/canonical matches need an explicit new-variant policy, and new class structural inspection must not depend on recursive legacy parsing.',
'existing_layout_and_quota_witnesses':['src/script/code/call_spread_layout_tests.rs','src/script/parser/driver/call_spread_layout_tests.rs','src/script/parser/driver/expressions/argument_in_context_tests.rs','src/script/parser/driver/expressions/expression_in_context_tests.rs','src/script/parser/call_spread_cut_tests.rs','src/script/machine/call_spread_phase_tests.rs','inline code/parser/driver/machine/call/statement layout and allocation witnesses'],
'census_status':'This is an affected-source map, not a complete numeric test migration census. That census follows selected full layouts and measured old-target effects.'},
'pending_root_decisions':[
'Confirm the proposed Class arena and Option<ClassKind> code field after constructor-design reconciliation; no runtime field shape is selected here.',
'Choose exact runtime class-frame and named-evaluation handoff APIs, including retained key/value ownership and terminal cleanup.',
'Accept the parser-only Invalid-# Unsupported boundary or select another explicit deferred-private classification path; do not silently assume # is tokenized.',
'Select the cfg(test) canonical representation handling for new flat Class/SuperCall variants while keeping the legacy reference parser out of production.',
'Freeze complete layouts and ownership/accounting contracts, then author independent behavioral/quota controls before production. Old profile outcomes may improve/change when untagged class bodies run; preserve policies/baselines and report observations.'
],
'activity':{'production_authored':False,'tests_authored':False,'project_imports_or_execution':False,'builds_or_tests_run':False,'live_source_edits':False,'stdlib_read_only_git_and_external_writes_only':True}
}
put('design.json',design)
files=[]
for p in sorted(O.rglob('*')):
    if p.is_file() and p.name!='source-ready.json':
        b=p.read_bytes();files.append({'path':str(p.relative_to(O)),'bytes':len(b),'sha256':digest(b)})
put('source-ready.json',{'status':'sealed source-only parser and flat-record design proposal','base':BASE,'previous_runtime_base':OLD,'inputs_same_on_both_bases':True,'design':'design.json','record_shape':'record-shape.txt','primary_rules':'primary-rules.json','source_bindings':'source-bindings.json','files':files,'qualification':'No implementation, test payload, measured ABI, numeric fee selection or execution result is represented. Root/constructor reconciliation and later independently frozen controls remain required.'})
print(json.dumps(bind(O/'source-ready.json')))
