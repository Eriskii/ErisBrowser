from pathlib import Path
import hashlib
import json
import re
import subprocess

F=Path('/tmp/eris-class-runtime-plan-1');D=F/'public-tests-1';P=F/'public-test-design-1';W=F/'worktree'
BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(p.read_bytes())
def put(p,b):
 assert not p.exists(),p;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return bind(p)
def obj(p,v):return put(p,(json.dumps(v,indent=2)+'\n').encode())
hold=load(F/'public-contract-2/source-ready.json');cases=load(F/'public-contract-2/cases.json')
assert bind(F/'public-contract-2/source-ready.json')['sha256']=='817c6e9c41632087ffb7d4d2d9e70cd096f456cc3ea6f2b2f11e00e87380ca85'
assert len(cases)==62
source_before=(W/'src/script.rs').read_bytes()
assert source_before==subprocess.check_output(['git','show',f'{BASE}:src/script.rs'],cwd=W)
assert b'mod class_semantics_tests;' not in source_before

design=obj(P/'design.json',{
 'status':'root-selected public test interface; supersedes unselected grouping ideas',
 'base':BASE,'frozen_contract':bind(F/'public-contract-2/source-ready.json'),
 'module':'src/script/class_semantics_tests.rs','test_groups':62,
 'grouping':'Exactly one #[test] per frozen literal row; each loops sloppy then strict with a fresh Runtime and Document per mode.',
 'helpers':{
   'execute_mode':'Use Runtime::execute or execute_strict on exact source bytes; no textual strict prefix.',
   'observe':'Execute source successfully, then evaluate exact observation source after the public checkpoint and compare its Value.',
   'early_error':'Execute exact setup, execute separate erroneous source, assert intrinsic SyntaxError and is_parse_error, then evaluate exact untouched-sentinel readback.',
   'unsupported':'Execute in a fresh Runtime and require is_unsupported; no readback or reset after terminal refusal.'},
 'maximum_completed_calls':{'semantic':104,'early_error':156,'unsupported':20,'total':280},
 'qualification':'124 row/mode attempts are distinct from280 possible public API calls. A Rust assertion failure stops that test; later modes/readbacks are unreached. No parent or candidate pass count predicted.',
 'exclusions':'No private fees, counter/heap/queue resets, parse-only shortcuts, future producer APIs or Rust execution.',
 'registration':'Root composes the separate cfg(test) module declaration; no live edits.'})

header='''//! Public class contracts frozen independently before production.
use super::*;

fn execute_mode(
    runtime: &mut Runtime,
    document: &mut Document,
    strict: bool,
    source: &str,
) -> Result<Value> {
    if strict {
        runtime.execute_strict(source, document)
    } else {
        runtime.execute(source, document)
    }
}

fn observe(case_id: &str, source: &str, expression: &str, expected: Value) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, source)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} source: {error:?}"));
        let observed = execute_mode(&mut runtime, &mut document, strict, expression)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} observation: {error:?}"));
        assert_eq!(&observed, &expected, "{case_id} strict={strict}");
    }
}

fn early_error(case_id: &str, setup: &str, source: &str, expression: &str, expected: Value) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, setup)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} setup: {error:?}"));
        let error = execute_mode(&mut runtime, &mut document, strict, source)
            .expect_err("class early-error source unexpectedly completed");
        assert_eq!(error.intrinsic_error_name(), Some("SyntaxError"), "{case_id} strict={strict}: {error:?}");
        assert!(error.is_parse_error(), "{case_id} strict={strict}: {error:?}");
        let observed = execute_mode(&mut runtime, &mut document, strict, expression)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} observation: {error:?}"));
        assert_eq!(&observed, &expected, "{case_id} strict={strict}");
    }
}

fn unsupported(case_id: &str, source: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let error = execute_mode(&mut runtime, &mut document, strict, source)
            .expect_err("deferred class source unexpectedly completed");
        assert!(error.is_unsupported(), "{case_id} strict={strict}: {error:?}");
    }
}

'''
def raw(s):
 assert '"###' not in s
 return 'r###"'+s+'"###'
def value(v):
 if v['type']=='string':return 'Value::String('+json.dumps(v['value'])+'.into())'
 assert v=={'type':'number','value':0}
 return 'Value::Number(0.0)'
blocks=[];roster=[]
for row in cases:
 name='class_public_'+row['id'];assert re.fullmatch('[a-z0-9_]+',name)
 source_path=Path(row['source_file']['path']);assert bind(source_path)==row['source_file']
 assert source_path.read_text()==row['source']
 source=source_path.read_text();args=[json.dumps(row['id'])]
 if row['kind']=='semantic':
  readback=Path(row['observation_file']['path']).read_text()
  assert readback==row['observation']+'\n'
  helper='observe';args += [raw(source),raw(readback),value(row['expected'])]
 elif row['kind']=='early-error':
  setup=Path(row['setup_file']['path']).read_text();assert setup==row['setup']
  readback=Path(row['observation_file']['path']).read_text();assert readback==row['observation']+'\n'
  helper='early_error';args += [raw(setup),raw(source),raw(readback),value(row['expected'])]
 else:
  assert row['kind']=='unsupported';helper='unsupported';args += [raw(source)]
 block='#[test]\nfn '+name+'() {\n    '+helper+'(\n        '+',\n        '.join(args)+',\n    );\n}\n\n'
 literal_values=re.findall(r'r###"(.*?)"###',block,re.S)
 expected_literals=([row['setup']] if row['kind']=='early-error' else [])+[source]+([row['observation']+'\n'] if row['kind']!='unsupported' else [])
 assert literal_values==expected_literals
 blocks.append(block)
 roster.append({'test_name':name,'case_id':row['id'],'kind':row['kind'],'helper':helper,
                'modes':['sloppy','strict'],'source':row['source_file'],
                'setup':row.get('setup_file'),'observation':row.get('observation_file'),
                'expected':row.get('expected'),'expected_error':row.get('expected_error'),
                'raw_string_extraction_exact':True})
module=put(D/'raw/src/script/class_semantics_tests.rs',(header+''.join(blocks)).encode())
assert len(re.findall(r'^#\[test\]\nfn ',(header+''.join(blocks)),re.M))==62
registration=put(D/'registration-append.txt',b'#[cfg(test)] mod class_semantics_tests;\n')
roster_binding=obj(D/'roster.json',{'tests':roster,'test_groups':62,'modes':124,
 'semantic_rows':26,'early_error_rows':26,'unsupported_rows':10,
 'maximum_public_calls':280,'diagnostics':'Each test name maps one-to-one to a frozen row. First failed source/assertion stops that test, including any later strict attempt/readback.'})
before=obj(D/'registration-lineage.json',{
 'base':BASE,'parent_script':bind(W/'src/script.rs'),'module_absent':True,
 'registration':registration,'scope':'Proposed append only. Root must compose it with separately owned production and historical migrations; no main-source replacement supplied.'})
seal=obj(D/'source-ready.json',{
 'status':'ready for independent source peer and root tests-only import',
 'base':BASE,'literal_contract':bind(F/'public-contract-2/source-ready.json'),
 'design':design,'files':[{'relative_path':'src/script/class_semantics_tests.rs','raw':module,'parent_absent':True}],
 'registration':registration,'registration_lineage':before,'roster':roster_binding,
 'author':bind(D/'author-tests.py'),'test_groups':62,'planned_mode_attempts':124,
 'maximum_public_calls':280,'exact_literal_conversion':True,
 'qualification':'No producer design inspected, project imports/tests run, live edits, private fees or resets. Frozen contracts stay immutable; peer findings require additive follow-up.'})
print(json.dumps(seal))
