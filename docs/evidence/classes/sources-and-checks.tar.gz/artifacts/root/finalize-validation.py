from pathlib import Path
import hashlib, json, subprocess

f = Path(__file__).resolve().parents[1]
w = f / 'worktree'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(path):
    return json.loads((f / path).read_bytes())

def receipt(label):
    path = f / 'validation' / (label + '.json')
    row = json.loads(path.read_bytes())
    assert row['exit'] == 0
    log = f / 'validation' / row['log']
    assert bind(log)['sha256'] == row['sha256']
    return dict(receipt=bind(path), log=bind(log), command=row['command'])

source = read('source-candidate-2.json')['source_sha256']
parent = read('source-parent.json')['source_sha256']
assert set(parent) <= set(source)
for name, sha in source.items():
    assert bind(w / name)['sha256'] == sha, name
changed = {name for name, sha in source.items() if parent.get(name) != sha}
assert len(changed) == 30
assert len(set(source) - set(parent)) == 14
actual = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=w, text=True).splitlines())
actual.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=w, text=True).splitlines())
actual_source = {name for name in actual if not name.startswith('docs/') and name not in {'README.md', 'SECURITY.md'}}
assert actual_source == changed, (actual_source - changed, changed - actual_source)
final = f / 'source-final.json'
assert not final.exists()
final.write_bytes((f / 'source-candidate-2.json').read_bytes())
suites = read('root/full-suite-validation-1.json')
profiles = read('root/profile-validation-1.json')
assert suites['status'] == profiles['status'] == 'pass'
assert (profiles['cases'], profiles['controls']) == (1330, 640)
builds = {}
for kind in ('ordinary', 'host'):
    sidecar = read('eris-js-' + kind + '-1.json')
    binary = bind(Path(sidecar['binary']))
    assert binary['sha256'] == sidecar['sha256'] and binary['bytes'] == sidecar['bytes']
    assert sidecar['source_sha256'] == bind(f / 'source-candidate-2.json')['sha256']
    assert sidecar['features'] == ([] if kind == 'ordinary' else ['test262-host'])
    build = receipt('class-release-' + kind + '-1')
    expected = ['cargo', '+1.88.0', 'build', '--locked', '--offline']
    if kind == 'host':
        expected += ['--features', 'test262-host']
    expected += ['--release', '--bin', 'eris-js']
    assert build['command'] == expected
    assert profiles['binaries'][kind] == binary
    builds[kind] = dict(binary=binary, sidecar=bind(f / ('eris-js-' + kind + '-1.json')), build=build)

row = dict(
    status='pass', scope='Bounded custom JavaScript class runtime checkpoint; complete browser goal remains unfinished',
    base=read('source-parent.json')['base'],
    source=dict(parent=bind(f / 'source-parent.json'), first_candidate=bind(f / 'source-candidate-1.json'),
                final_candidate=bind(f / 'source-candidate-2.json'), final=bind(final), selected_inputs=len(source),
                changed_paths=sorted(changed), changed_existing=16, added=14,
                qualification='Cumulative selected-input inventory, not complete build graph; all current runtime/test changes are enumerated. Final bytes equal candidate2. No Cargo/build inputs or conformance policy/corpus/baseline changed.'),
    suites=suites, profiles=profiles, builds=builds,
    checks={label:receipt(label) for label in ('class-clippy-default-2', 'class-clippy-host-vulkan-1', 'class-format-check-1')},
    focused={label:receipt(label) for label in ('class-public-candidate-1', 'class-browser-candidate-1', 'class-private-candidate-2', 'class-super-validation-1')},
    qualifications=[
        'First 79 public groups/162 modes passed before the bound-superclass correction; final suites include one additional group/two modes and the correction.',
        'Original parent public comparison is79groups,12passing/67failing,162planned/91reached; the late corrective public supplement was not run on the parent.',
        'Independent private cost contracts preceded production; final private source sealing followed initial public execution. Final private16groups cover114 measured helper/parser operations plus one raw/layout observation group.',
        'Initial compile E0624 fixed only constructed_prototype sibling visibility; private compile E0716 fixed only expected-value temporary lifetime. All attempts retained.',
        'Source review found missing superclass IsConstructor validation before generic bound forwarding; new class-only helper charges1 plus existing per-hop work after explicit arguments or before default forwarding. Original addendum retained as superseded.',
        'First full default attempt had2993passing/9failing library groups: eight outer sandbox socket restrictions and one missed historical startup ledger migration. Escalated second run uses derived+64bytes (32 initial environments+32 retained Unit), preserving every old term/work/count.',
        'Browser direct and confined-worker witnesses pass two viewport cases, disabled/initial/repeated/click states and exact pixels. Feature suite also checks native raster plan pixels; no hardware Vulkan execution performed for this checkpoint.',
        'Eight unchanged conformance profiles retain1330 cases/640 healthy controls:1222 passed,60 failed,48 unsupported. Twenty formerly unsupported modes now pass. Ten other formerly unsupported modes remain nonpassing: eight expose unimplemented BigInt literal syntax; two reach the existing unhandled-rejection host audit. No previously passed case regressed; all raw transitions remain retained and no baseline was changed.',
        'No complete ECMAScript/web conformance, production security certification, process-memory measurement or Chromium performance comparison is claimed.'
    ],
    corrections={name:bind(f / name) for name in ('root/compiler-correction-1.json', 'root/private-compiler-correction-1.json', 'root/bound-superclass-correction-1/receipt.json', 'typed-ledger-migration-1/source-ready.json', 'root/full-suite-attempt-1-findings-2.json')},
    limits=read('root/selection-1.json')['limits'])
out = f / 'root/final-validation.json'
with out.open('x') as handle:
    json.dump(row, handle, indent=2)
    handle.write('\n')
print(json.dumps(bind(out)))
