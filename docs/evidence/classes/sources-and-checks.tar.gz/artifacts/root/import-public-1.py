from pathlib import Path
import json,re,hashlib,subprocess
f=Path('/tmp/eris-class-runtime-plan-1');w=f/'worktree';h=f/'public-tests-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
d=json.loads((h/'source-ready.json').read_text())
assert bind(h/'source-ready.json')['sha256']=='6b15738bcce73b413a2789420f27f394490eb803d93fba3b767f3547012193e1'
assert bind(f/'public-contract-review-1/review.json')['sha256']=='9d198b54ec6055c566f751aad7d980f6fd0d6b63ee4e4b3a7f8d3f6e3e6cd9fc'
cases=json.loads((f/'public-contract-2/cases.json').read_text())
source=Path(d['files'][0]['raw']['path']);assert bind(source)==d['files'][0]['raw']
text=source.read_text();parts=re.split(r'^#\[test\]\nfn (class_public_[a-z0-9_]+)\(\) \{\n',text,flags=re.M)
assert len(parts)==125
assert parts[0].count('for strict in [false, true]')==3
assert 'Runtime::try_new().unwrap()' in parts[0]
assert 'runtime.execute_strict(source, document)' in parts[0]
assert 'runtime.execute(source, document)' in parts[0]
assert 'error.intrinsic_error_name(), Some("SyntaxError")' in parts[0]
assert 'error.is_parse_error()' in parts[0] and 'error.is_unsupported()' in parts[0]
assert not any(x in text for x in ['runtime.steps','runtime.allocated','runtime.microtasks','Parser::','parse_only'])
rows=[]
for row,(name,body) in zip(cases,zip(parts[1::2],parts[2::2]),strict=True):
 assert name=='class_public_'+row['id']
 helper={'semantic':'observe','early-error':'early_error','unsupported':'unsupported'}[row['kind']]
 assert body.lstrip().startswith(helper+'(')
 expected=[]
 if row['kind']=='early-error':expected.append(row['setup'])
 expected.append(row['source'])
 if row['kind']!='unsupported':expected.append(row['observation']+'\n')
 assert re.findall(r'r###"(.*?)"###',body,re.S)==expected,name
 for kind in ['source_file','setup_file','observation_file']:
  if kind in row:assert bind(Path(row[kind]['path']))==row[kind]
 if row['kind']!='unsupported':
  val=row['expected']
  if val['type']=='string':
   matches=re.findall(r'Value::String\(("(?:[^"\\]|\\.)*")\.into\(\)\)',body)
   assert len(matches)==1 and json.loads(matches[0])==val['value']
  else:assert val=={'type':'number','value':0} and 'Value::Number(0.0)' in body
 rows.append({'test':name,'case':row['id'],'kind':row['kind'],'exact':True})
registration=Path(d['registration']['path']);assert bind(registration)==d['registration']
assert registration.read_bytes()==b'#[cfg(test)] mod class_semantics_tests;\n'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=w).decode().strip()==d['base']
assert not subprocess.check_output(['git','status','--porcelain'],cwd=w)
p=w/'src/script.rs';before=p.read_bytes();assert before==subprocess.check_output(['git','show',d['base']+':src/script.rs'],cwd=w)
target=w/d['files'][0]['relative_path'];assert not target.exists()
review={'status':'clear; root independent transcription and public helper review','hold':bind(h/'source-ready.json'),'literal_peer':bind(f/'public-contract-review-1/review.json'),'group_count':len(rows),'raw_js_strings':sum(len(re.findall(r'r###"(.*?)"###',b,re.S)) for b in parts[2::2]),'rows':rows,'qualification':'No production changes, private state resets or executable oracle. Parent test results remain unobserved.'}
with (f/'root/public-tests-review-1.json').open('x') as out:json.dump(review,out,indent=2);out.write('\n')
target.write_bytes(source.read_bytes());p.write_bytes(before+b'\n'+registration.read_bytes())
assert p.read_bytes()[:len(before)]==before
record={'base':d['base'],'review':bind(f/'root/public-tests-review-1.json'),'imports':[bind(target),bind(p)],'main_script_change':'Append blank line plus exact 40-byte registration only.','production_changes':False}
with (f/'root/public-parent-import-1.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(bind(f/'root/public-parent-import-1.json')))
