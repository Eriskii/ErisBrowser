from pathlib import Path
import json,re,hashlib
f=Path('/tmp/eris-class-runtime-plan-1');w=f/'worktree'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
imports=json.loads((f/'root/layout-probes-import-1.json').read_text())['imports'];removed=[]
for record in imports:
 p=Path(record['path']);assert bind(p)==record
 if p.name=='class_layout_probe.rs':p.unlink();removed.append({'path':str(p),'removed_new_inert_file':True})
 else:
  data=p.read_bytes();suffix=b'\n#[cfg(test)]\nmod class_layout_probe;\n';assert data.endswith(suffix);p.write_bytes(data[:-len(suffix)]);removed.append({'restored':bind(p)})
with (f/'root/layout-probes-removal-1.json').open('x') as out:json.dump({'measurement':bind(f/'root/layout-measurements-1.json'),'removed':removed,'qualification':'All frozen probe payloads and observed logs retained outside live sources. No production edits.'},out,indent=2);out.write('\n')
reviews=[]
for name,seal,count in [('public-context-1','ecb6f0e6bb04ecfc6c49cd01ee6500ff70a3e1c6d7780957b2ce0c2a948698dd',6),('public-unicode-1','318c8a10839e384942b99985e992930720b7a6beb06768e59a91e467390ce7bc',1)]:
 h=f/name;assert bind(h/'source-ready.json')['sha256']==seal;d=json.loads((h/'source-ready.json').read_text());cases=json.loads((h/'cases.json').read_text());assert len(cases)==count
 row=d['files'][0];target=w/row['relative_path'];before=Path(row['before']['path']);raw=Path(row['raw']['path']);frag=Path(d['append']['path'])
 assert bind(raw)==row['raw'] and bind(before)==row['before'] and bind(frag)==d['append']
 assert target.read_bytes()==before.read_bytes() and raw.read_bytes()==before.read_bytes()+frag.read_bytes()
 parts=re.split(r'^#\[test\]\nfn (class_public_[a-z0-9_]+)\(\) \{\n',frag.read_text(),flags=re.M);assert parts[0]=='' and len(parts)==1+count*2
 for c,(test,body) in zip(cases,zip(parts[1::2],parts[2::2]),strict=True):
  assert test=='class_public_'+c['id']
  expected=([c['setup']] if c['kind']=='early-error' else [])+[c['source'],c['observation']]
  assert re.findall(r'r###"(.*?)"###',body,re.S)==expected
  assert body.lstrip().startswith('early_error(' if c['kind']=='early-error' else 'observe(')
  if c['expected']['type']=='string':
   value=re.findall(r'Value::String\(("(?:[^"\\]|\\.)*")\.into\(\)\)',body);assert len(value)==1 and json.loads(value[0])==c['expected']['value']
  else:assert c['expected']=={'type':'number','value':0} and 'Value::Number(0.0)' in body
  for k in ['source_file','setup_file','observation_file']:
   if k in c:assert bind(Path(c[k]['path']))==c[k]
 target.write_bytes(raw.read_bytes());reviews.append({'hold':bind(h/'source-ready.json'),'groups':count,'exact_original_prefix_bytes':len(before.read_bytes()),'imported':bind(target)})
record={'status':'root independent semantic and exact transcription review clear; additive imports only','reviews':reviews,'semantic_derivation':['Class heritage/keys are strict in both outer modes, so readonly assignment throws before later effects.', 'Nested class heritage/keys retain outer super/new.target; nested method and base constructor contexts reset.', 'Thrown constructor retains escaped arrow owner; alternate original NewTarget and later live superclass remain distinct; second parent effects precede duplicate bind error.', 'First derived parameter default super initializes this before later defaults/body; explicit first argument skips super and later this read throws.', 'Unicode names preserve UTF-16 code units including supplementary pairs, combining sequence and lone surrogate Symbol description; metadata-only hints do not normalize identifiers.'],'production_changes':False,'groups_total':74,'planned_modes_total':148}
with (f/'root/context-unicode-review-import-1.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(bind(f/'root/context-unicode-review-import-1.json')))
