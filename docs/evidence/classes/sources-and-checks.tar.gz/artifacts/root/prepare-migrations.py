import difflib
import hashlib
import json
import subprocess
from pathlib import Path

F = Path(__file__).resolve().parents[1]
W = F / 'worktree'
H = F / 'migrations-1'
H.mkdir(exist_ok=True)
base = 'f3118ae5787c410648657f7c822efb7014201dd1'
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
specs = [
    ('src/script.rs', '"class C{}",', '"class C{field;}",',
     'Retain valid-but-deferred grammar coverage using a public field. Empty classes move to independent supported public contracts.'),
    ('src/script/parser.rs', '"class A{}",', '"class A{field;}",',
     'Keep the old/new parser differential corpus in the common admitted/refused subset; class fields remain explicitly unsupported in both.')
]
rows = []
for rel, before, after, reason in specs:
    original = subprocess.check_output(['git', 'show', base + ':' + rel], cwd=W)
    assert original == (W / rel).read_bytes()
    text = original.decode()
    assert text.count(before) == 1
    modified = text.replace(before, after, 1)
    assert modified.count(after) == 1 and modified.replace(after, before, 1) == text
    paths = {}
    for kind, data in [('before', original), ('raw', modified.encode())]:
        p = H / kind / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        with p.open('xb') as f:
            f.write(data)
        paths[kind] = bind(p)
    diff = H / 'diffs' / (rel.replace('/', '__') + '.diff')
    diff.parent.mkdir(exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(text.splitlines(True), modified.splitlines(True), fromfile='before/' + rel, tofile='after/' + rel)))
    rows.append(dict(relative_path=rel, **paths, diff=bind(diff), before_literal=before,
                     after_literal=after, exact_inverse=True, rationale=reason))
record = dict(status='frozen two-literal historical expectation migration; not imported', base=base,
    selection=bind(F / 'root/selection-1.json'), files=rows,
    qualification='Independent new public class tests must cover the newly admitted empty-class behavior. All other historical literals and assertions remain exact. Constructor/new.target restrictions and invalid class declarations under labels/controlled statements are not migrated. Production in these shared files must compose this exact separate payload; no test result claimed.')
(H / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(bind(H / 'source-ready.json')))
