from pathlib import Path
from collections import Counter
import hashlib, json, re

f = Path(__file__).resolve().parents[1]
parent = Path('/tmp/eris-promise-try-runtime-plan-1/validation')

def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read_run(directory, label):
    receipt = json.loads((directory / (label + '.json')).read_bytes())
    log = directory / receipt['log']
    assert receipt['exit'] == 0 and binding(log)['sha256'] == receipt['sha256']
    text = log.read_text()
    results = re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    roster = re.findall(r'^test ([^\n]+?) \.\.\. (ok|FAILED|ignored).*$', text, re.M)
    assert results and all(row[0] == 'ok' and all(int(n) == 0 for n in row[2:]) for row in results)
    assert len(roster) == sum(int(row[1]) for row in results)
    assert all(status == 'ok' for name, status in roster)
    counts = Counter(name for name, status in roster)
    assert all(count == 1 for count in counts.values())
    return dict(receipt=binding(directory / (label + '.json')), log=binding(log), result_rows=len(results), passed=len(roster)), set(counts)

inputs = json.loads((f / 'source-candidate-2.json').read_bytes())['source_sha256']
for path, sha in inputs.items():
    assert binding(f / 'worktree' / path)['sha256'] == sha, path

rows = []
for config, old_count in [('default', 3246), ('host-vulkan', 3600)]:
    old, old_roster = read_run(parent, config + '-full-1')
    new, new_roster = read_run(f / 'validation', 'class-' + config + ('-full-2' if config == 'default' else '-full-1'))
    assert old['passed'] == old_count and old['result_rows'] == 52
    assert old_roster <= new_roster, sorted(old_roster - new_roster)
    added = sorted(new_roster - old_roster)
    public = [name for name in added if '::class_public_' in name]
    private = [name for name in added if '::class_private_' in name]
    browser = [name for name in added if name.startswith('classes_') or name.startswith('classes::')]
    assert (len(added), len(public), len(private), len(browser)) == (98, 80, 16, 2)
    assert set(added) == set(public + private + browser)
    assert new['passed'] == old_count + 98 and new['result_rows'] == 53
    rows.append(dict(config=config, parent=old, candidate=new, all_parent_tests_preserved=True, added=added,
                     public_groups=len(public), public_mode_attempts=164, private_groups=len(private),
                     private_measured_operations=114, private_raw_layout_observation_groups=1, browser_groups=len(browser)))
out = f / 'root' / 'full-suite-validation-1.json'
with out.open('x') as handle:
    json.dump(dict(status='pass', source=binding(f / 'source-candidate-2.json'), configurations=rows,
                   qualifications='Public modes and private operation totals are derived from reviewed fixture contracts; per-group Rust pass records prove every loop completed. No hardware Vulkan or Chromium performance result.'), handle, indent=2)
    handle.write('\n')
print(json.dumps(binding(out)))
