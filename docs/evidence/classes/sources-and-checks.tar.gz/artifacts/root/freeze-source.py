from pathlib import Path
import json,hashlib,subprocess,sys
f=Path(__file__).resolve().parents[1];w=f/'worktree'
label=sys.argv[1]
parent=json.loads((f/'source-parent.json').read_text());old=parent['source_sha256'];new=dict(old)
tracked=subprocess.check_output(['git','diff','--name-only'],cwd=w).decode().splitlines()
added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w).decode().splitlines()
changed=sorted(set(tracked+added)-{p for p in tracked+added if p.startswith('docs/') or p in {'README.md','SECURITY.md'}})
for rel in changed:
 path=w/rel
 assert path.is_file(),rel
 new[rel]=hashlib.sha256(path.read_bytes()).hexdigest()
for rel,sha in new.items():
 assert hashlib.sha256((w/rel).read_bytes()).hexdigest()==sha,rel
record={'base':parent['base'],'scope':'Cumulative selected-input inventory for the custom class runtime checkpoint, including every changed/new runtime/test input; not the complete build graph. Documentation and evidence are reviewed separately.','source_sha256':dict(sorted(new.items()))}
out=f/('source-'+label+'.json');assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'path':str(out),'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'selected_inputs':len(new),'changed_existing':sum(old[k]!=new[k] for k in old),'added':len(set(new)-set(old)),'changed_paths':changed},indent=2))
