import hashlib
import json
import shutil
import subprocess
from pathlib import Path

F = Path(__file__).resolve().parents[1]
E = Path('/tmp/eris-promise-try-upstream-plan-1')
D = Path('/tmp/eris-promise-try-runtime-plan-1')
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
W = F / 'worktree'
def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=MAIN, text=True).strip()
publication = json.loads((E / 'root/github-publication.json').read_bytes())
base = publication['commit']
assert publication['status'] == 'pushed'
assert base == 'f3118ae5787c410648657f7c822efb7014201dd1'
assert git('rev-parse', 'HEAD') == base and git('status', '--porcelain') == ''
assert not W.exists()
subprocess.run(['git', 'worktree', 'add', '-b', 'class-runtime', str(W), base], cwd=MAIN, check=True)
source = json.loads((E / 'source-final.json').read_bytes())
source['base'] = base
source['scope'] = 'Published Try upstream selected inputs before custom class runtime changes. Cumulative selected-input inventory, not the complete build graph. Runtime baseline remains the previously validated15db implementation.'
for rel, sha in source['source_sha256'].items():
    assert bind(W / rel)['sha256'] == sha, rel
(F / 'source-parent.json').write_text(json.dumps(source, indent=2) + '\n')
(F / 'readiness-1').mkdir()
shutil.copyfile(E / 'next-class-readiness-1/readiness.json', F / 'readiness-1/readiness.json')
for name in ('run-tool.py', 'run-check.py'):
    shutil.copyfile(E / name, F / name)
for name in ('target-msrv', 'target-1990'):
    (F / name).symlink_to((E / name).resolve(), target_is_directory=True)
(F / 'validation').mkdir()
(F / 'replay-parent').mkdir()
for short in ('aggregate-error', 'existing', 'all', 'race', 'settled', 'any', 'with-resolvers', 'try'):
    shutil.copyfile(E / f'upstream-{short}-1.json', F / 'replay-parent' / f'upstream-{short}-1.json')
selection = json.loads((F / 'root/selection-provisional.json').read_bytes())
selection['publication_base'] = base
selection['readiness'] = bind(F / 'readiness-1/readiness.json')
selection['runtime_read_base'] = base
selection['status'] = 'Public semantic scope selected on published base; representation and numeric accounting remain under independent design.'
(F / 'root/selection-1.json').write_text(json.dumps(selection, indent=2) + '\n')
record = dict(base=base, branch='class-runtime', source=bind(F / 'source-parent.json'),
    readiness=bind(F / 'readiness-1/readiness.json'), scope=bind(F / 'root/selection-1.json'),
    prior_runtime_validation=bind(D / 'root/final-validation.json'),
    prior_profile_validation=bind(E / 'root/final-validation.json'),
    qualifications='No class candidate code or tests imported. Prior Rust source bytes unchanged by profile checkpoint. Runtime outcomes and any selected layout/charge deltas require new validation; no class feature policy or baseline migration selected.')
(F / 'root/setup.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
