from pathlib import Path
import json,hashlib,sys,shutil
f=Path(__file__).resolve().parents[1];kind=sys.argv[1];assert kind in ('ordinary','host')
source=f/'source-candidate-1.json';inputs=json.loads(source.read_bytes())['source_sha256']
for name,sha in inputs.items():assert hashlib.sha256((f/'worktree'/name).read_bytes()).hexdigest()==sha,name
label='class-release-'+kind+'-1';receipt=json.loads((f/'validation'/f'{label}.json').read_bytes());assert receipt['exit']==0
p=f/('eris-js-'+kind+'-1');assert not p.exists();shutil.copy2(f/'target-msrv/release/eris-js',p)
record={'binary':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'source_inventory':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'build':str(f/'validation'/f'{label}.json'),'features':[] if kind=='ordinary' else ['test262-host'],'toolchain':'1.88.0'}
with (f/(p.name+'.json')).open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(record))
