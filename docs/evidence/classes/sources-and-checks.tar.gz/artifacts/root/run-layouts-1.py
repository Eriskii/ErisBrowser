from pathlib import Path
import os,subprocess,json,hashlib
f=Path('/tmp/eris-class-runtime-plan-1')
configs=[('msrv-ordinary','1.88.0','target-msrv',[]),('msrv-host','1.88.0','target-msrv',['--features','test262-host']),('1990-ordinary','1.99.0','target-1990',[]),('1990-host-vulkan','1.99.0','target-1990',['--features','test262-host,vulkan-raster'])]
for label,version,target,features in configs:
 env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR=str(f/target),CARGO_BUILD_JOBS='4')
 rustc=subprocess.check_output(['rustc','+'+version,'--version','--verbose'],env=env).decode()
 info={'label':label,'toolchain':version,'rustc':rustc,'features':features,'target_dir':str(f/target)}
 with (f/'validation'/('layout-'+label+'-environment-1.json')).open('x') as out:json.dump(info,out,indent=2);out.write('\n')
 args=['cargo','+'+version,'test','--locked','--offline','--manifest-path','Cargo.toml',*features,'--lib','class_layout_probe','--','--nocapture','--test-threads=1']
 result=subprocess.run(['python3',str(f/'run-tool.py'),'layout-'+label+'-1',*args],env=env)
 if result.returncode:raise SystemExit(result.returncode)
