from pathlib import Path
import json,hashlib,runpy,difflib
f=Path(__file__).resolve().parents[1];w=f/'worktree';out=f/'format-review-1';out.mkdir()
tokens=runpy.run_path(str(f/'root/rust-lexical.py'))['tokens'];rows=[]
for r in json.load(open(f/'root/private-import-format-inputs-1.json'))['files']:
 rel=r['path'];p=f/'before-format-1'/rel;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
 before=b.decode();after=(w/rel).read_text();row={'path':rel,'before_sha256':r['sha256'],'after_sha256':hashlib.sha256(after.encode()).hexdigest()}
 if rel.endswith('.rs'):
  a,al,ac=tokens(before);z,zl,zc=tokens(after);assert al==zl and ac==zc,rel
  assert [v for v in a if v not in {',','{','}'}]==[v for v in z if v not in {',','{','}'}],rel
  row.update(literal_vector_exact=True,comments_exact=True,nonformat_tokens_exact=True)
 else:assert before==after,rel
 if before!=after:
  (out/(rel.replace('/','__')+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='composed/'+rel,tofile='formatted/'+rel)))
 rows.append(row)
record={'status':'All literal/comment vectors and nonformat tokens preserved; only whitespace/comma/block punctuation changes','files':rows}
(out/'review.json').write_text(json.dumps(record,indent=2)+'\n');print('verified',len(rows),'source files')
