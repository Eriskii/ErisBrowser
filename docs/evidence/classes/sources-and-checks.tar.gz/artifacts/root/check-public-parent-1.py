from pathlib import Path
import re,json,hashlib
f=Path('/tmp/eris-class-runtime-plan-1');v=f/'validation';p=v/'class-parent-public-1.log';s=p.read_text()
cases=json.loads((f/'public-contract-2/cases.json').read_text());roster={'class_public_'+r['id'] for r in cases}
fail_summary=s.split('\nfailures:\n')[-1].split('\ntest result:')[0]
failed=set(re.findall(r'^    script::class_semantics_tests::(class_public_[a-z0-9_]+)$',fail_summary,re.M))
passed=set(re.findall(r'test script::class_semantics_tests::(class_public_[a-z0-9_]+) \.\.\. ok',s))
assert len(failed)==50 and len(passed)==12 and not failed&passed and failed|passed==roster
assert 'test result: FAILED. 12 passed; 50 failed; 0 ignored; 0 measured; 2906 filtered out;' in s
results={name:('ok' if name in passed else 'FAILED') for name in sorted(roster)}
counts={}
for c in cases:
 status=results['class_public_'+c['id']];group=counts.setdefault(c['kind'],{'passed':0,'failed':0});group['passed' if status=='ok' else 'failed']+=1
assert counts=={'semantic':{'passed':0,'failed':26},'early-error':{'passed':2,'failed':24},'unsupported':{'passed':10,'failed':0}}
assert {k for k in passed if not any(c['id']==k.removeprefix('class_public_') and c['kind']=='unsupported' for c in cases)}=={'class_public_labelled_class','class_public_controlled_statement_class'}
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
d={'base':'f3118ae5787c410648657f7c822efb7014201dd1','receipt':bind(v/'class-parent-public-1.json'),'log':bind(p),'test_import':bind(f/'root/public-parent-import-1.json'),'groups':62,'passed':12,'failed':50,'by_kind':counts,'roster':results,'planned_modes':124,'reached_modes':74,'reached_modes_derivation':'Each passing group completed both modes; every failed group stopped in its first sloppy attempt. This is not the number of API calls.','qualification':'Tests-only parent; class runtime implementation has not been imported. Unsupported rows and existing controlled/labelled syntax checks pass already. No candidate outcome inferred.','orchestration':'An initial root anchored single-line result parser stopped at assert(len==62), before writing a receipt: concurrent panic output split one result line. This checker reconciles the complete final50-name failure summary plus12 intact success markers and cargo summary. No rerun, source change or expectation change.'}
assert s.count('strict=true')==0
out=f/'root/public-parent-result-1.json'
with out.open('x') as h:json.dump(d,h,indent=2);h.write('\n')
print(json.dumps(bind(out)));print(json.dumps(counts))
