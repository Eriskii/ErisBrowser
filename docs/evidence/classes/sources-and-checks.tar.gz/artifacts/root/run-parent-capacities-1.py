from pathlib import Path
import os,subprocess
f=Path('/tmp/eris-class-runtime-plan-1')
for label,version,target,features in [('msrv','1.88.0','target-msrv',[]),('1990-host-vulkan','1.99.0','target-1990',['--features','test262-host,vulkan-raster'])]:
 env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR=str(f/target),CARGO_BUILD_JOBS='4')
 args=['cargo','+'+version,'test','--locked','--offline',*features,'--lib','full_compile_tariffs','--','--nocapture','--test-threads=1']
 r=subprocess.run(['python3',str(f/'run-tool.py'),'parent-capacities-'+label+'-1',*args],env=env)
 if r.returncode:raise SystemExit(r.returncode)
