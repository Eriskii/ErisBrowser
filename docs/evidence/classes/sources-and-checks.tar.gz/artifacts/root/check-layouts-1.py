from pathlib import Path
import json,re,hashlib
f=Path('/tmp/eris-class-runtime-plan-1');v=f/'validation'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
configs=[]
for label in ['msrv-ordinary','msrv-host','1990-ordinary','1990-host-vulkan']:
 p=v/('layout-'+label+'-1.log');s=p.read_text();r=v/('layout-'+label+'-1.json');receipt=json.loads(r.read_text());assert receipt['exit']==0 and receipt['sha256']==bind(p)['sha256']
 assert 'test result: ok. 2 passed; 0 failed;' in s and 'warning:' not in s
 runtime={k:{'bytes':int(b),'align':int(a)} for k,b,a in re.findall(r'CLASS_RUNTIME_LAYOUT (\S+) bytes=(\d+) align=(\d+)',s)};assert len(runtime)==42
 parser={kind:{k:{'bytes':int(b),'align':int(a)} for version,k,b,a in re.findall(r'CLASS_PARSER_LAYOUT version=(\S+) type=(\S+) size=(\d+) align=(\d+)',s) if version==kind} for kind in ['before','proposed']}
 assert len(parser['before'])==37 and len(parser['proposed'])==48
 assert 'CLASS_PARSER_LAYOUT_COUNTS actual=34 before=37 proposed=48' in s
 formulas={kind:{k:int(value) for version,k,value in re.findall(r'CLASS_PARSER_FORMULA version=(\S+) name=(\S+) value=(\d+)',s) if version==kind} for kind in ['before','proposed']}
 capacities=[]
 for version,typ,req,bef,aft in re.findall(r'CLASS_PARSER_CAPACITY version=(\S+) type="([^"]+)" len=0 requested_additional=(\d+) before=(\d+) after=(\d+)',s):
  assert int(aft)>=int(req);capacities.append({'version':version,'type':typ,'requested':int(req),'before':int(bef),'after':int(aft)})
 assert len(capacities)==23
 frames=re.search(r'CLASS_RUNTIME_FRAME_FORMULAS baseline_initial=(\d+) proposed_initial=(\d+) baseline_max=(\d+) proposed_max=(\d+)',s);assert frames
 envs=re.search(r'CLASS_RUNTIME_ENVIRONMENT_FORMULAS legacy=(\d+) proposed=(\d+) two_initial_delta=(\d+)',s);assert envs
 config=re.search(r'CLASS_RUNTIME_LAYOUT_CONFIG test262_host=(true|false) vulkan_raster=(true|false) pointer_bytes=(\d+)',s);assert config
 assert (config[1]=='true')==('host' in label) and (config[2]=='true')==('vulkan' in label) and config[3]=='8'
 configs.append({'label':label,'environment':bind(v/('layout-'+label+'-environment-1.json')),'receipt':bind(r),'log':bind(p),'runtime':runtime,'parser':parser,'parser_formulas':formulas,'capacity_observations':capacities,'frame_formula':list(map(int,frames.groups())),'environment_formula':list(map(int,envs.groups()))})
for c in configs[1:]:
 assert c['parser']==configs[0]['parser'] and c['parser_formulas']==configs[0]['parser_formulas']
 assert c['capacity_observations']==configs[0]['capacity_observations']
 assert {k:v for k,v in c['runtime'].items() if k!='Runtime'}=={k:v for k,v in configs[0]['runtime'].items() if k!='Runtime'}
 assert c['frame_formula']==configs[0]['frame_formula'] and c['environment_formula']==configs[0]['environment_formula']
c=configs[0];deltas={k:{'before':b['bytes'],'proposed':c['parser']['proposed'][k]['bytes'],'delta':c['parser']['proposed'][k]['bytes']-b['bytes']} for k,b in c['parser']['before'].items() if k in c['parser']['proposed'] and b!=c['parser']['proposed'][k]}
runtime_deltas={k:{'before':b['bytes'],'proposed':c['runtime']['proposed.'+k.removeprefix('baseline.')]['bytes'],'delta':c['runtime']['proposed.'+k.removeprefix('baseline.')]['bytes']-b['bytes']} for k,b in c['runtime'].items() if k.startswith('baseline.') and 'proposed.'+k.removeprefix('baseline.') in c['runtime'] and b!=c['runtime']['proposed.'+k.removeprefix('baseline.')]}
record={'status':'four configurations passed both inert complete-shape probes','import':bind(f/'root/layout-probes-import-1.json'),'configs':configs,'parser_deltas':deltas,'runtime_deltas':runtime_deltas,'qualification':'Measured inert proposed declarations, not candidate production types. Actual candidate types must later match selected shapes. Capacity observations apply only to the recorded zero-length reserve requests. Runtime total differs by host feature; unchanged-type rows otherwise match across configurations. No class execution or startup-total measurement occurred.'}
out=f/'root/layout-measurements-1.json'
with out.open('x') as h:json.dump(record,h,indent=2);h.write('\n')
print(json.dumps(bind(out)));print(json.dumps({'parser_deltas':deltas,'runtime_deltas':runtime_deltas,'frame_formula':c['frame_formula'],'environment_formula':c['environment_formula']}))
