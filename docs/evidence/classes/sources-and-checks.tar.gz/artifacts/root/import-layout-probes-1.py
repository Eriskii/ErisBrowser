from pathlib import Path
import json,hashlib,subprocess
f=Path('/tmp/eris-class-runtime-plan-1');w=f/'worktree';base='f3118ae5787c410648657f7c822efb7014201dd1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(r):assert bind(Path(r['path']))==r,r['path']
r=f/'runtime-shapes-2';rd=json.loads((r/'source-ready.json').read_text());assert bind(r/'source-ready.json')['sha256']=='9316037d5c9f2268cf694dabca165d22926f8fba689b4680890d6eb90e098818'
p=f/'parser-layout-probe-1';pd=json.loads((p/'source-ready.json').read_text());assert bind(p/'source-ready.json')['sha256']=='9181fdcddde2f57a0f2e4a504365415dcfbe4fe701030efaa3ec28f65d23f746'
proof=json.loads((f/'runtime-shapes-1/declaration-proof.json').read_text())
for row in proof['source_bindings']:
 b=subprocess.check_output(['git','show',base+':'+row['relative']],cwd=w)
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
old=(f/'runtime-shapes-1/raw/src/script/machine/statements/class_layout_probe.rs').read_text();new=Path(rd['files'][0]['raw']['path']).read_text()
assert new==old.replace('vulkan={} pointer_bytes','vulkan_raster={} pointer_bytes').replace('cfg!(feature = "vulkan")','cfg!(feature = "vulkan-raster")')
assert new.count('row!(')==42 and 'fn class_runtime_complete_layout_probe()' in new
for row in json.loads((p/'source-checks.json').read_text())['declaration_fragments']:check(row['held'])
for row in pd['files']:
 b=(p/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
imports=[]
for row in rd['files']:
 check(row['raw']);target=w/row['relative']
 if row['new']:assert not target.exists()
 else:
  check(row['before']);before=Path(row['before']['path']).read_bytes();assert target.read_bytes()==before
  assert before==subprocess.check_output(['git','show',base+':'+row['relative']],cwd=w)
  assert Path(row['raw']['path']).read_bytes()==before+b'\n#[cfg(test)]\nmod class_layout_probe;\n'
 target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(row['raw']['path']).read_bytes());imports.append(bind(target))
check(pd['raw']);check(pd['registration']);target=w/'src/script/parser/driver/class_layout_probe.rs';assert not target.exists()
target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(Path(pd['raw']['path']).read_bytes());imports.append(bind(target))
target=w/'src/script/parser/driver.rs';before=(p/'before/src/script/parser/driver.rs').read_bytes();assert target.read_bytes()==before
assert before==subprocess.check_output(['git','show',base+':src/script/parser/driver.rs'],cwd=w)
reg=Path(pd['registration']['path']).read_bytes();assert reg==b'\n#[cfg(test)]\nmod class_layout_probe;\n'
target.write_bytes(before+reg);imports.append(bind(target))
record={'base':base,'runtime_hold':bind(r/'source-ready.json'),'parser_hold':bind(p/'source-ready.json'),'imports':imports,'review':'Complete mirrored baseline/proposed type graphs and all old variants reviewed against selected shapes; baseline aggregate assertions will run before trusting measurements. Only declaration/print/assert/reserve tests and append-only cfg(test) registrations are imported.','runtime_feature_correction_exact':True,'source_bindings_verified':len(proof['source_bindings']),'production_edits':False,'temporary':'Remove inert probes and registrations after observation; their parent-equivalence assertions deliberately apply only before production changes. Frozen payloads/results remain in evidence.'}
out=f/'root/layout-probes-import-1.json'
with out.open('x') as h:json.dump(record,h,indent=2);h.write('\n')
print(json.dumps(bind(out)))
