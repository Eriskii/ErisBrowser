from pathlib import Path
import json,hashlib,runpy,difflib
f=Path(__file__).resolve().parents[1];w=f/'worktree';out=f/'format-review-2';out.mkdir()
tokens=runpy.run_path(str(f/'root/rust-lexical.py'))['tokens'];rows=[]
for r in json.load(open(f/'root/private-import-format-inputs-1.json'))['files']:
 rel=r['path'];p=f/'before-format-1'/rel;b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==r['sha256']
 before=b.decode();after=(w/rel).read_text();row={'path':rel,'before_sha256':r['sha256'],'after_sha256':hashlib.sha256(after.encode()).hexdigest()}
 if rel.endswith('.rs'):
  a,al,ac=tokens(before);z,zl,zc=tokens(after);assert al==zl and ac==zc,rel
  if rel == 'src/script.rs':
   # Two inspected rustfmt module-order moves, with no macro-order dependencies.
   first='mod code;\nmod construction;\nmod classes;'
   second='#[cfg(test)] mod class_semantics_tests;\n#[cfg(test)] mod class_abort_tests;'
   assert before.count(first)==before.count(second)==1
   normalized=before.replace(first,'mod classes;\nmod code;\nmod construction;').replace(second,'#[cfg(test)] mod class_abort_tests;\n#[cfg(test)] mod class_semantics_tests;')
   a,_,_=tokens(normalized)
   row['reviewed_module_order_moves']=2
  assert [v for v in a if v not in {',','{','}'}]==[v for v in z if v not in {',','{','}'}],rel
  row.update(literal_vector_exact=True,comments_exact=True,nonformat_tokens_exact=True)
 else:assert before==after,rel
 if before!=after:
  (out/(rel.replace('/','__')+'.diff')).write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='composed/'+rel,tofile='formatted/'+rel)))
 rows.append(row)
record={'status':'All literal/comment vectors and nonformat tokens preserved; whitespace/comma/block punctuation and two independently inspected module-order moves; first checker refusal retained','files':rows}
(out/'review.json').write_text(json.dumps(record,indent=2)+'\n');print('verified',len(rows),'source files')
