from pathlib import Path
import hashlib,json,re,subprocess,difflib
F=Path('/tmp/eris-class-runtime-plan-1');O=F/'parser-implementation-1';W=F/'worktree';BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(name,value):
 p=O/name;p.write_text(json.dumps(value,indent=2)+'\n');return bind(p)
def declaration(s,kind,name):
 m=re.search(r'(?m)^(?:pub\([^\n]*\) )?'+kind+' '+re.escape(name)+r"(?:<'source>)? \{",s);assert m,(kind,name)
 i=s.index('{',m.start())+1;depth=1
 while depth:depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[m.start():i]
raw={p.relative_to(O/'raw').as_posix():p.read_text() for p in (O/'raw').rglob('*.rs')};before={p.relative_to(O/'before').as_posix():p.read_text() for p in (O/'before').rglob('*.rs')}
files=[]
for rel,s in raw.items():
 old=before.get(rel,'')
 if rel in before:assert subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)==old.encode()
 diff=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+rel if rel in before else '/dev/null',tofile='b/'+rel));assert diff==(O/'diff'/(rel+'.diff')).read_text()
 # Every old JavaScript raw string remains verbatim and in order.
 oldjs=re.findall(r'r(#+)"([\s\S]*?)"\1',old);newjs=re.findall(r'r(#+)"([\s\S]*?)"\1',s);assert oldjs==newjs,rel
 files.append({'relative':rel,'new':rel not in before,'before':bind(O/'before'/rel) if rel in before else None,'raw':bind(O/'raw'/rel),'diff':bind(O/'diff'/(rel+'.diff')),'retained_raw_string_literals':len(oldjs)})
checks=[]
for fragment,rel,items in [
 ('code.rs','src/script/code.rs',[('struct','Function'),('struct','Unit'),('enum','Expr'),('enum','Stmt'),('enum','ClassKind'),('enum','ClassElementKind'),('struct','Class'),('struct','ClassElement')]),
 ('parser.rs','src/script/parser.rs',[('struct','Parser')]),
 ('driver.rs','src/script/parser/driver.rs',[('enum','Output'),('enum','Kind'),('enum','Transition'),('struct','EntryContext')]),
 ('expressions.rs','src/script/parser/driver/expressions.rs',[('enum','Frame'),('struct','Postfix')]),
 ('functions.rs','src/script/parser/driver/functions.rs',[('enum','Frame'),('struct','State'),('struct','Context')]),
 ('statements.rs','src/script/parser/driver/statements.rs',[('enum','Frame')]),
 ('classes.rs','src/script/parser/driver/classes.rs',[('enum','Frame'),('struct','State'),('struct','Header'),('struct','Context')])]:
 held=(F/'parser-shapes-1/proposed'/fragment).read_text()
 for kind,name in items:
  a=declaration(raw[rel],kind,name);b=declaration(held,kind,name);assert a==b,(rel,name);checks.append({'path':rel,'name':name,'declaration_sha256':sha(a.encode()),'selected_shape_equal':True})
# Methods bracketed by their next sibling retain exact bytes; these old helpers
# contain no replaced declarations or new variants.
protected=[]
def exact_range(rel,start,end):
 a=before[rel];b=raw[rel];x=a[a.index(start):a.index(end,a.index(start))];y=b[b.index(start):b.index(end,b.index(start))];assert x==y,(rel,start);protected.append({'path':rel,'start':start,'end':end,'bytes':len(x.encode()),'sha256':sha(x.encode())})
for a,b in [('    pub fn add_expr(', '    pub fn add_stmt('),('    pub fn add_stmt(','    pub fn add_function('),('    pub fn finish(mut self','    pub fn expr(')]:exact_range('src/script/code.rs',a,b)
for a,b in [('    fn copy_identifier(','    fn binding_identifier('),('    fn object_key(','    fn identifier_key('),('    fn identifier_key(','    fn parameter('),('    fn contiguous_ellipsis(','    fn argument_ellipsis('),('    fn argument_ellipsis(','    fn rest_parameter('),('    fn rest_parameter(','    fn rescan_suffix('),('fn push<T>(','fn check_declaration(')]:exact_range('src/script/parser.rs',a,b)
exact_range('src/script/parser/driver.rs','fn reserve(','pub(super) fn parse(')
for a,b in [('fn argument_spread(','fn call_done('),('fn call_done(','fn new_done('),('fn new_done(','fn new_members('),('fn new_members(','fn primary(')]:exact_range('src/script/parser/driver/expressions.rs',a,b)
# No numeric or assertion changes in the two shared test files.
fixtures=[]
for rel in ['src/script/parser/driver/expressions/argument_in_context_tests.rs','src/script/parser/driver/expressions/expression_in_context_tests.rs']:
 assert raw[rel].replace('        allow_update: true,\n','')==before[rel];fixtures.append(rel)
assert '"class A{}"' in raw['src/script/parser.rs']
assert 'ScriptError::unsupported("\'class\' is not supported")' in raw['src/script/parser/driver/classes.rs']
assert raw['src/script/parser/driver/expressions.rs'].count('child(Frame::Base(async_call), Frame::New)')==1
assert raw['src/script/parser/driver/classes.rs'].count('Expression::LeftHandSide')==1
assert 'while ' not in raw['src/script/parser/driver/classes.rs'] and 'loop {' not in raw['src/script/parser/driver/classes.rs']
summary={'status':'source checks pass; not compiled or executed','selected_declarations':checks,'unchanged_old_helper_ranges':protected,'fixture_only_paths':fixtures,'new_class_orchestration':'No local class loop; every semicolon/member returns Again or Child and consumes the next existing driver work1. Record/list/name allocations use old charged helpers.','old_paths':'Ordinary Unary still enters Base->New; heritage alone selects LeftHandSide. Root ten numeric migrations are absent.','limits':'No cap, work helper, allocation helper, Records body, lexer/token or runtime source edits.','ownership':'Class.name owns the sole syntactic name; class vector has only nonowning IDs and property handles. Constructors/methods have FunctionIds; defaults are empty tagged Function records.','historical_diagnostic':'Field class rejection uses unchanged message/type/None offset from the prior statement-level Unsupported. Root-owned class A{} / class C{} fixture substitutions remain unapplied.','qualifications':['Actual candidate type/layout and grammar behavior require root compilation/tests; sealed source checks are not those outcomes.','Only two existing fixture shape fields are edited; numeric/layout assertions remain parent literals for root separate composition.','This hold contains no runtime lexical admission, constructor behavior or inferred-name callsite changes.']}
put('checks.json',summary)
interfaces={'new_code_types':['ClassId(usize)','ClassKind::{ExplicitBase,ExplicitDerived,DefaultBase,DefaultDerived}','ClassElementKind::{Method,Getter,Setter}','Class{name:Option<String>,heritage:Option<ExprId>,constructor:FunctionId,elements:Vec<ClassElement>}','ClassElement{name:PropertyName,function:FunctionId,kind:ClassElementKind,is_static:bool}'],'new_code_apis':['Unit::add_class(&mut self,Class,&mut regexp::Budget)->Result<ClassId>','Unit::class(&self,ClassId)->&Class','Unit::anonymous_class(&self,ExprId)->Option<ClassId>'],'changed_existing_types':['Function.class_kind: Option<ClassKind>','Unit.classes: Records<Class>','Expr::Class / SuperCall / SuperCallSpread','Stmt::Class','Parser.super_call_allowed / in_class','driver::Output::Class / Kind::Class / EntryContext','expressions LeftHandSide / LeftHandSideBase / ClassDone / SuperArguments and Postfix.allow_update','functions Frame::ClassMethod and Context.super_call_allowed','statements Frame::ClassDone'],'visibility':'Exact selected declaration visibility. No widened old helper visibility. No new test registration.','root_composition':['Runtime exhaustive matches for new Expr/Stmt and class_kind use belong to root/Script.','Compose two Postfix allow_update fixture fields with separate ten-row and layout numeric migrations.','Compose root historical class-field fixture substitutions separately.','Root adds independent class parser/code test modules and final formatting.']}
put('interfaces.json',interfaces)
seal={'status':'external parser/code production hold ready for independent source review; no project execution','base':BASE,'inputs':[bind(F/p) for p in ['parser-design-1/source-ready.json','parser-shapes-1/source-ready.json','root/parser-review-1.json','root/representation-selection-1.json','root/class-accounting-selection-1.json','root/representation-accounting-selection-1.json','parser-accounting-1/source-ready.json','parser-accounting-1/selection-binding-1.json']],'files':files,'checks':bind(O/'checks.json'),'interfaces':bind(O/'interfaces.json'),'authors':[bind(O/'author.py'),bind(O/'classes.rs'),bind(O/'seal.py')],'scope':{'production_paths':7,'existing_fixture_shape_paths':2,'new_test_paths':0,'numeric_test_migrations':0,'live_edits':False,'project_execution':False},'registration':'Production mod classes is inside the held driver.rs; independent test registrations remain root-owned.'}
put('source-ready.json',seal);print(json.dumps(bind(O/'source-ready.json')))
