from pathlib import Path
import subprocess,re,hashlib,json,difflib
F=Path('/tmp/eris-class-runtime-plan-1');O=F/'parser-implementation-1';W=F/'worktree';BASE='f3118ae5787c410648657f7c822efb7014201dd1'
paths=['src/script/code.rs','src/script/parser.rs','src/script/parser/driver.rs','src/script/parser/driver/expressions.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/statements.rs','src/script/parser/driver/expressions/argument_in_context_tests.rs','src/script/parser/driver/expressions/expression_in_context_tests.rs']
sources={p:subprocess.check_output(['git','show',BASE+':'+p],cwd=W).decode() for p in paths};out=dict(sources)
def replace(p,a,b,n=1):
 assert out[p].count(a)==n,(p,a[:80],out[p].count(a),n);out[p]=out[p].replace(a,b)
def declaration(s,kind,name):
 m=re.search(r'(?m)^(?:pub\([^\n]*\) )?'+kind+' '+re.escape(name)+r"(?:<'source>)? \{",s);assert m,(kind,name)
 i=s.index('{',m.start())+1;depth=1
 while depth:
  depth+=(s[i]=='{')-(s[i]=='}');i+=1
 return s[m.start():i]
def shape(p,fragment,items):
 new=(F/'parser-shapes-1/proposed'/fragment).read_text()
 for kind,name in items:
  replace(p,declaration(out[p],kind,name),declaration(new,kind,name))
p='src/script/code.rs'
shape(p,'code.rs',[('struct','Function'),('struct','Unit'),('enum','Expr'),('enum','Stmt')])
new=(F/'parser-shapes-1/proposed/code.rs').read_text();new=new[new.index('#[derive(Clone, Copy, Debug, PartialEq, Eq)]\npub(super) struct ClassId'):]
replace(p,'#[derive(Debug)]\npub(super) struct Parameter',new+'\n#[derive(Debug)]\npub(super) struct Parameter')
replace(p,'            strict: true,\n        }\n    }\n}', '            strict: true,\n            class_kind: None,\n        }\n    }\n}')
replace(p,'            compiled_storage: 0,\n','            compiled_storage: 0,\n            classes: Records::new(),\n')
replace(p,'            strict: code.strict,\n','            strict: code.strict,\n            class_kind: None,\n')
replace(p,'    // Used only while reinterpreting', '''    pub fn add_class(&mut self, value: Class, budget: &mut regexp::Budget) -> Result<ClassId> {
        let id = ClassId(self.classes.len());
        self.classes.append(value, budget)?;
        Ok(id)
    }
    pub fn class(&self, id: ClassId) -> &Class {
        &self.classes[id.0]
    }
    pub fn anonymous_class(&self, id: ExprId) -> Option<ClassId> {
        match self.expr(id) {
            Expr::Class(id) if self.class(*id).name.is_none() => Some(*id),
            _ => None,
        }
    }
    // Used only while reinterpreting''')
replace(p,'            Self::Var(_, DeclarationKind::Let | DeclarationKind::Const)\n','            Self::Var(_, DeclarationKind::Let | DeclarationKind::Const) | Self::Class(_)\n')
replace(p,'            Expr::Literal(v) => E::Literal(v.clone()),','''            Expr::Class(_) | Expr::SuperCall(_) | Expr::SuperCallSpread(_) => {
                panic!("class syntax has no legacy canonical inverse")
            }
            Expr::Literal(v) => E::Literal(v.clone()),''')
replace(p,'            Stmt::Empty => S::Empty,','''            Stmt::Class(_) => panic!("class syntax has no legacy canonical inverse"),
            Stmt::Empty => S::Empty,''')
replace(p,'        let f = unit.function(id);\n','''        let f = unit.function(id);
        assert!(f.class_kind.is_none(), "class constructor has no legacy canonical inverse");
''')
p='src/script/parser.rs'
shape(p,'parser.rs',[('struct','Parser')])
replace(p,'    CatchClause, Expr, ExprId,','    CatchClause, ClassId, Expr, ExprId,')
replace(p,'            strict,\n        })\n    }\n    fn parse_body','            strict,\n            super_call_allowed: false,\n            in_class: false,\n        })\n    }\n    fn parse_body')
replace(p,'            strict: parser.strict,\n','            strict: parser.strict,\n            class_kind: None,\n')
replace(p,'    fn done(&self) -> bool {','''    fn emit_class(&mut self, value: code::Class) -> Result<ClassId> {
        self.unit.add_class(value, &mut self.compile_budget)
    }
    fn done(&self) -> bool {''')
replace(p,'        if let TokenKind::Invalid(error) = &self.tokens[self.pos].kind {\n            return (**error).clone();\n','''        if let TokenKind::Invalid(error) = &self.tokens[self.pos].kind {
            if self.in_class && self.source.as_bytes().get(self.tokens[self.pos].offset) == Some(&b'#') {
                return ScriptError::unsupported("private class elements are not implemented");
            }
            return (**error).clone();
''')
replace(p,'            Stmt::Function(name, _) if block_functions => {','''            Stmt::Class(id) => {
                let name = unit.class(*id).name.as_deref().expect("class declaration name");
                lexical.push(name, false, budget)?;
            }
            Stmt::Function(name, _) if block_functions => {''')
needle='''        if let Stmt::Var(bindings, kind) = unit.stmt(*statement)
            && *kind != DeclarationKind::Var
        {
            for (name, _) in bindings {
                if params.contains(name, budget)? {
                    return Err(ScriptError::at(
                        "parameter conflicts with lexical declaration",
                        0,
                    ));
                }
            }
        }
'''
replace(p,needle,needle+'''        if let Stmt::Class(id) = unit.stmt(*statement)
            && params.contains(unit.class(*id).name.as_deref().expect("class declaration name"), budget)?
        {
            return Err(ScriptError::at("parameter conflicts with lexical declaration", 0));
        }
''')
p='src/script/parser/driver.rs'
shape(p,'driver.rs',[('enum','Output'),('enum','Kind')])
replace(p,'mod expressions;','mod classes;\nmod expressions;')
replace(p,'impl From<expressions::Frame> for Kind {','''struct EntryContext {
    allow_in: bool,
    strict: bool,
    super_call_allowed: bool,
    in_class: bool,
}
impl From<classes::Frame> for Kind {
    fn from(frame: classes::Frame) -> Self {
        Self::Class(frame)
    }
}
impl From<expressions::Frame> for Kind {''')
replace(p,'fn declaration(output: Option<Output>) -> Stmt {','''fn class(output: Option<Output>) -> ClassId {
    let Some(Output::Class(id)) = output else {
        unreachable!("class grammar output")
    };
    id
}
fn declaration(output: Option<Output>) -> Stmt {''')
replace(p,'    let entry_in = parser.allow_in;','''    let entry = EntryContext {
        allow_in: parser.allow_in,
        strict: parser.strict,
        super_call_allowed: parser.super_call_allowed,
        in_class: parser.in_class,
    };''')
replace(p,'                Kind::Body(state) => statements::body_step(parser, state, output.take()),','''                Kind::Body(state) => statements::body_step(parser, state, output.take()),
                Kind::Class(state) => classes::step(parser, state, output.take()),''')
replace(p,"    // On errors, restore only this invocation's grammar flag; quotas stay spent.\n    if result.is_err() {\n        parser.allow_in = entry_in;\n",'''    // Restore this invocation's scalar grammar flags on error; quotas stay spent.
    if result.is_err() {
        parser.allow_in = entry.allow_in;
        parser.strict = entry.strict;
        parser.super_call_allowed = entry.super_call_allowed;
        parser.in_class = entry.in_class;
''')
p='src/script/parser/driver/functions.rs'
shape(p,'functions.rs',[('enum','Frame'),('struct','Context')])
replace(p,'            new_target_allowed: p.new_target_allowed,','            new_target_allowed: p.new_target_allowed,\n            super_call_allowed: p.super_call_allowed,')
replace(p,'        p.new_target_allowed |= !arrow;','''        p.new_target_allowed |= !arrow;
        if !arrow {
            p.super_call_allowed = false;
        }''')
replace(p,'        p.new_target_allowed = self.new_target_allowed;','        p.new_target_allowed = self.new_target_allowed;\n        p.super_call_allowed = self.super_call_allowed;')
replace(p,'        Frame::Dynamic => {','''        Frame::ClassMethod(derived_constructor) => {
            p.expect("(")?;
            let saved = Context::enter(p, false);
            p.super_call_allowed = derived_constructor;
            let state = State {
                params: Vec::new(), saved, unique: true, arrow: false, dynamic: false,
            };
            if p.eat(")") { function_body(p, state) } else { parameters(p, state) }
        }
        Frame::Dynamic => {''')
replace(p,'        strict,\n    };','        strict,\n        class_kind: None,\n    };')
p='src/script/parser/driver/expressions.rs'
shape(p,'expressions.rs',[('enum','Frame'),('struct','Postfix')])
replace(p,'            let async_call = p.is("async")','''            if p.is("super") {
                return super_start(p, true);
            }
            let async_call = p.is("async")''')
replace(p,'                async_call,\n            },','                async_call,\n                allow_update: true,\n            },')
replace(p,'        Frame::PostfixResume(state) => postfix(p, state),','''        Frame::LeftHandSide => {
            if p.is("super") {
                return super_start(p, false);
            }
            let async_call = p.is("async") && p.token_is(p.pos + 1, "(")
                && !p.tokens[p.pos + 1].line_break_before;
            child(Frame::LeftHandSideBase(async_call), Frame::New)
        }
        Frame::LeftHandSideBase(async_call) => postfix(p, Postfix {
            value: expression(output), chain: 0, async_call, allow_update: false,
        }),
        Frame::ClassDone => done_expr(p, Expr::Class(class(output))),
        Frame::SuperArguments(mut arguments, has_spread, current_spread, saved_in, allow_update) => {
            let mut item = expression(output);
            if current_spread {
                item = p.emit_expr(Expr::SpreadArgument(item))?;
            }
            push(&mut arguments, item, &mut p.compile_budget)?;
            if p.eat(")") {
                p.allow_in = saved_in;
                super_done(p, arguments, has_spread, allow_update)
            } else {
                p.expect(",")?;
                if p.eat(")") {
                    p.allow_in = saved_in;
                    super_done(p, arguments, has_spread, allow_update)
                } else {
                    let current_spread = argument_spread(p)?;
                    child(Frame::SuperArguments(arguments, has_spread || current_spread,
                        current_spread, saved_in, allow_update), Frame::Assignment)
                }
            }
        }
        Frame::PostfixResume(state) => postfix(p, state),''')
replace(p,'    if !p.tokens[p.pos].line_break_before && p.eat("++") {','    if state.allow_update && !p.tokens[p.pos].line_break_before && p.eat("++") {')
replace(p,'    } else if !p.tokens[p.pos].line_break_before && p.eat("--") {','    } else if state.allow_update && !p.tokens[p.pos].line_break_before && p.eat("--") {')
replace(p,'fn argument_spread(p:', '''fn super_start(p: &mut Parser<'_>, allow_update: bool) -> Result<Transition> {
    p.expect("super")?;
    if p.is(".") || p.is("[") {
        return Err(ScriptError::unsupported("super property references are not implemented"));
    }
    if !p.super_call_allowed {
        return Err(p.error("super call outside a derived constructor"));
    }
    p.expect("(")?;
    if p.eat(")") {
        return super_done(p, Vec::new(), false, allow_update);
    }
    let current_spread = argument_spread(p)?;
    let saved_in = p.allow_in;
    p.allow_in = true;
    child(Frame::SuperArguments(Vec::new(), current_spread, current_spread, saved_in, allow_update),
        Frame::Assignment)
}
fn super_done(p: &mut Parser<'_>, arguments: Vec<ExprId>, has_spread: bool,
              allow_update: bool) -> Result<Transition> {
    let value = p.emit_expr(if has_spread { Expr::SuperCallSpread(arguments) }
                           else { Expr::SuperCall(arguments) })?;
    Ok(Transition::Again(Frame::PostfixResume(Postfix {
        value, chain: 0, async_call: false, allow_update,
    }).into()))
}
fn argument_spread(p:''')
replace(p,'fn primary(p: &mut Parser<\'_>) -> Result<Transition> {','''fn primary(p: &mut Parser<'_>) -> Result<Transition> {
    if p.is("class") {
        return child(Frame::ClassDone, classes::Frame::Start { declaration: false });
    }
    if p.in_class && matches!(p.tokens[p.pos].kind, TokenKind::Invalid(_))
        && p.source.as_bytes().get(p.tokens[p.pos].offset) == Some(&b'#')
    {
        return Err(p.error("expected expression"));
    }''')
replace(p,'''        TokenKind::Word(s) if !s.escaped && &*s.value == "super" => Err(ScriptError::unsupported(
            "super property and constructor references are not implemented",
        )),''','''        TokenKind::Word(s) if !s.escaped && &*s.value == "super" => {
            if p.is(".") || p.is("[") {
                Err(ScriptError::unsupported("super property references are not implemented"))
            } else {
                Err(ScriptError::at("invalid super expression", offset))
            }
        }''')
p='src/script/parser/driver/statements.rs'
shape(p,'statements.rs',[('enum','Frame')])
replace(p,'        Frame::Block => done_stmt(p, Stmt::Block(body(output).statements)),','''        Frame::ClassDone => done_stmt(p, Stmt::Class(class(output))),
        Frame::Block => done_stmt(p, Stmt::Block(body(output).statements)),''')
replace(p,'    if p.eat("function") {','''    if p.is("class") {
        return child(Frame::ClassDone, classes::Frame::Start { declaration: true });
    }
    if p.eat("function") {''')
# Root composes numeric migrations into these same two parent test files.
for p in paths[-2:]:
 replace(p,'        async_call: false,\n','        async_call: false,\n        allow_update: true,\n')
# This new module is authored independently below, with no generated logic.
newpath='src/script/parser/driver/classes.rs'
out[newpath]=(O/'classes.rs').read_text()
for p,s in out.items():
 raw=O/'raw'/p;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_text(s)
 if p in sources:
  before=O/'before'/p;before.parent.mkdir(parents=True,exist_ok=True);before.write_text(sources[p])
 diff=O/'diff'/(p+'.diff');diff.parent.mkdir(parents=True,exist_ok=True)
 diff.write_text(''.join(difflib.unified_diff(sources.get(p,'').splitlines(True),s.splitlines(True),fromfile='a/'+p if p in sources else '/dev/null',tofile='b/'+p)))
print('authored',len(out),'external files; not sealed or executed')
