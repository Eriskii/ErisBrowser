from pathlib import Path
import hashlib
import json
import re
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-terminal-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'
RELATIVE = 'src/script/class_abort_tests.rs'

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2) + '\n').encode())

literal_seal = bind(D / 'literals-ready.json')
assert literal_seal['sha256'] == '1236e3140fb40b6fbfeaf3ba4386ff1798f31171ef5a225e42019c29d0154500'
rows = json.loads((D / 'cases.json').read_bytes())
contract = json.loads((D / 'contract.json').read_bytes())
assert len(rows) == 7 and len(contract['groups']) == 5
assert not subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, RELATIVE], cwd=F / 'worktree')

header = '''//! Natural class work exhaustion; retained-state inspection never re-enters JS.
use super::*;

fn execute_mode(
    runtime: &mut Runtime,
    document: &mut Document,
    strict: bool,
    source: &str,
) -> Result<Value> {
    if strict {
        runtime.execute_strict(source, document)
    } else {
        runtime.execute(source, document)
    }
}

fn retained<'a>(runtime: &'a Runtime, name: &str) -> &'a Value {
    &runtime.environments[0].bindings[name].value
}

fn terminal(cases: &[(&str, &str, &str, f64)]) {
    for &(case_id, source, expected_trace, expected_constructors) in cases {
        for strict in [false, true] {
            let mut runtime = Runtime::try_new().unwrap();
            let mut document = Document::parse("");
            let error = execute_mode(&mut runtime, &mut document, strict, source)
                .expect_err("infinite author loop unexpectedly completed");
            // Parent syntax refusal must fail here, before any retained-state
            // assertions. The loop must reach the natural work-limit path.
            assert!(error.is_resource_limit(), "{case_id} strict={strict}: {error:?}");
            assert!(!error.is_unsupported(), "{case_id} strict={strict}: {error:?}");
            assert_eq!(error.message, "script instruction limit exceeded", "{case_id} strict={strict}");
            assert_eq!(runtime.steps, 0, "{case_id} strict={strict}");
            assert!(runtime.microtasks_suspended(), "{case_id} strict={strict}");
            assert!(runtime.console.is_empty(), "{case_id} strict={strict}");
            assert_eq!(
                (runtime.frames.len(), runtime.calls, runtime.eval_depth, runtime.stack_units),
                (0, 0, 0, 0),
                "{case_id} strict={strict}"
            );
            assert_eq!(runtime.microtasks.author_depth, 0, "{case_id} strict={strict}");
            assert!(!runtime.microtasks.performing_checkpoint, "{case_id} strict={strict}");
            // Only borrowed reads follow the terminal public entry. No script
            // readback, checkpoint, callback call, counter or allowance reset.
            assert_eq!(retained(&runtime, "trace"), &Value::String(expected_trace.into()), "{case_id} strict={strict}");
            assert_eq!(retained(&runtime, "entered"), &Value::Number(1.0), "{case_id} strict={strict}");
            assert_eq!(retained(&runtime, "constructors"), &Value::Number(expected_constructors), "{case_id} strict={strict}");
            for name in ["base", "body", "caught", "finalized", "queuedRan"] {
                assert_eq!(retained(&runtime, name), &Value::Number(0.0), "{case_id} strict={strict} {name}");
            }
            assert_eq!(retained(&runtime, "after"), &Value::Bool(false), "{case_id} strict={strict}");
            assert_eq!(runtime.microtasks.queue.len(), 1, "{case_id} strict={strict}");
            let Some(promises::QueueJob::Callback(callback)) = runtime.microtasks.queue.front() else {
                panic!("{case_id} strict={strict}: saved sentinel missing");
            };
            assert_eq!(callback, retained(&runtime, "queued"), "{case_id} strict={strict}");
        }
    }
}

'''
blocks = []
roster = []
for group, ids in contract['groups'].items():
    selected = [row for row in rows if row['id'] in ids]
    assert [row['id'] for row in selected] == ids
    name = group.replace('class_terminal_', 'class_public_terminal_')
    entries = []
    for row in selected:
        assert bind(Path(row['source_file']['path'])) == row['source_file']
        source = Path(row['source_file']['path']).read_text()
        assert source == row['source'] and '"###' not in source
        expected = row['expected_retained']
        assert expected == {'trace': expected['trace'], 'entered': 1,
                            'constructors': expected['constructors'], 'base': 0, 'body': 0,
                            'caught': 0, 'finalized': 0, 'queuedRan': 0, 'after': False}
        assert expected['constructors'] in [0, 1]
        entry = ('        (\n            ' + json.dumps(row['id']) + ',\n            r###"' + source + '"###,\n'
                 + '            ' + json.dumps(expected['trace']) + ',\n            ' + str(expected['constructors']) + '.0,\n        ),\n')
        assert re.findall(r'r###"(.*?)"###', entry, re.S) == [source]
        entries.append(entry)
    blocks.append('#[test]\nfn ' + name + '() {\n    terminal(&[\n' + ''.join(entries) + '    ]);\n}\n\n')
    roster.append({'test_name': name, 'group_id': group, 'case_ids': ids,
                   'planned_mode_attempts': len(ids) * 2,
                   'expected': [row['expected_retained'] for row in selected]})

payload = header + ''.join(blocks)
assert len(re.findall(r'^#\[test\]', payload, re.M)) == 5
assert re.findall(r'r###"(.*?)"###', payload, re.S) == [row['source'] for row in rows]
for forbidden in ['runtime.steps =', 'runtime.allocated =', '.microtask_checkpoint(', '.clone()']:
    assert forbidden not in payload
assert payload.count('execute_mode(&mut runtime') == 1
raw = put(D / 'raw' / RELATIVE, payload.encode())
registration = put(D / 'registration-append.txt', b'#[cfg(test)] mod class_abort_tests;\n')
parent_script = subprocess.check_output(['git', 'show', f'{BASE}:src/script.rs'], cwd=F / 'worktree')
assert b'mod class_abort_tests;' not in parent_script
lineage = obj(D / 'registration-lineage.json', {
    'base': BASE, 'parent_script': {'relative_path': 'src/script.rs', 'bytes': len(parent_script),
                                   'sha256': hashlib.sha256(parent_script).hexdigest()},
    'new_module_absent': True, 'registration': registration,
    'scope': 'Root composes this separate module declaration with other held edits; no main-source replacement or live write supplied.'
})
roster_ref = obj(D / 'roster.json', {
    'groups': roster, 'test_groups': 5, 'source_literals': 7, 'planned_mode_attempts': 14,
    'maximum_public_execute_calls': 14, 'post_terminal_script_calls': 0,
    'qualification': 'One assertion failure ends the current Rust group, making later rows/modes unreached. No observed parent/candidate results claimed.'
})
checks = obj(D / 'checks.json', {
    'transcription': 'All seven Rust raw-string sources were extracted and compared byte-exact with the previously frozen JS literals. Trace/constructor expectations plus common retained counters match each frozen row.',
    'natural_failure': 'Each source has an unconditional empty author loop under the existing finite work budget; no injected quota values or measured threshold oracle.',
    'public_entry': 'Only execute/execute_strict runs author code. Resource/message assertions precede retained-state reads.',
    'borrowed_observation': 'Global values and queued callback identity are borrowed; no cloning, private calls, resets, checkpoint or script readback follows the terminal entry.',
    'prior_public_hold': bind(F / 'public-unicode-1/source-ready.json'),
    'source_policy': bind(D / 'source-basis.json'),
    'execution': 'Only this external stdlib author/checker ran; no project imports/compilation/engine/tests/live edits or future producer reads.'
})
seal = obj(D / 'source-ready.json', {
    'status': 'ready for independent peer and root tests-only import', 'base': BASE,
    'frozen_literals': literal_seal, 'cases': bind(D / 'cases.json'),
    'contract': bind(D / 'contract.json'), 'source_basis': bind(D / 'source-basis.json'),
    'files': [{'relative_path': RELATIVE, 'raw': raw, 'parent_absent': True}],
    'registration': registration, 'registration_lineage': lineage, 'roster': roster_ref,
    'checks': checks, 'authors': [bind(D / 'author-literals.py'), bind(Path(__file__))],
    'test_groups': 5, 'source_literals': 7, 'planned_modes': 14,
    'project_execution': False
})
print(json.dumps(seal))
