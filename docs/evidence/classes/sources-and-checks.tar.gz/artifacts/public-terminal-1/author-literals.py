from pathlib import Path
import hashlib
import json
import subprocess

F = Path('/tmp/eris-class-runtime-plan-1')
D = F / 'public-terminal-1'
BASE = 'f3118ae5787c410648657f7c822efb7014201dd1'

def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def put(p, b):
    assert not p.exists(), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_bytes(b)
    return bind(p)

def obj(p, value):
    return put(p, (json.dumps(value, indent=2) + '\n').encode())

prefix = '''var trace='',entered=0,constructors=0,base=0,body=0,caught=0,finalized=0,queuedRan=0,after=false;
var queued=()=>{queuedRan++;trace+='Q';console.log('late');};
queueMicrotask(queued);
function exhaust(mark){trace+=mark;entered++;while(true){}}
'''
tail = "catch(e){caught++;trace+='X';}finally{finalized++;trace+='F';}\nafter=true;trace+='Z';\n"
drafts = [
    ('heritage', 'class_terminal_heritage', '''try{
 class C extends exhaust('H') {constructor(){constructors++;super();body++;}static [(trace+='L','later')](){}}
 after=true;
}''', 'H', 0,
     'Heritage author work exhausts before the later computed key, any constructor body, outer catch/finally or queued callback.'),
    ('computed_instance', 'class_terminal_computed_keys', '''try{
 class C {[(trace+='P','first')](){}[exhaust('K')](){}[(trace+='L','later')](){}constructor(){constructors++;body++;}}
 after=true;
}''', 'PK', 0,
     'The first computed-name side effect persists; the next instance key exhausts and the later key remains unreached.'),
    ('computed_static', 'class_terminal_computed_keys', '''try{
 class C {static [(trace+='P','first')](){}static [exhaust('S')](){}static [(trace+='L','later')](){}constructor(){constructors++;body++;}}
 after=true;
}''', 'PS', 0,
     'The first static computed-name side effect persists; a later static key exhausts before subsequent definitions and author epilogues.'),
    ('derived_parameter_default', 'class_terminal_parameter_default', '''function B(){base++;trace+='B';}
class D extends B {constructor(x=exhaust('P')){constructors++;trace+='C';super();body++;trace+='D';}}
try{new D();after=true;}''', 'P', 0,
     'The derived constructor parameter initializer exhausts before its body, super construction or ordinary exception handling.'),
    ('explicit_super_argument', 'class_terminal_super_argument', '''function B(){base++;trace+='B';}
class D extends B {constructor(){constructors++;trace+='C';super(exhaust('A'));body++;trace+='D';}}
try{new D();after=true;}''', 'CA', 1,
     'The explicit derived constructor starts, then a super argument exhausts before base construction and the later body.'),
    ('promise_default_derived_executor', 'class_terminal_native_promise_executor', '''function executor(resolve,reject){
 if(typeof resolve!=='function'||typeof reject!=='function')throw new Error('executor callbacks');
 try{exhaust('E');body++;trace+='e';}finally{finalized++;trace+='f';}
}
class P extends Promise {}
try{new P(executor);after=true;}''', 'E', 0,
     'Default-derived forwarding reaches the genuine native Promise executor. Terminal work failure must escape that native boundary without conversion to an ordinary rejection or running either finally block.'),
    ('promise_explicit_derived_executor', 'class_terminal_native_promise_executor', '''function executor(resolve,reject){
 if(typeof resolve!=='function'||typeof reject!=='function')throw new Error('executor callbacks');
 try{exhaust('E');body++;trace+='e';}finally{finalized++;trace+='f';}
}
class P extends Promise {constructor(executor){constructors++;trace+='C';super(executor);body++;trace+='D';}}
try{new P(executor);after=true;}''', 'CE', 1,
     'Explicit derived construction reaches the genuine native executor after its constructor marker. Terminal failure prevents post-super body, native rejection conversion, catch/finally and queue draining.')
]
rows = []
groups = {}
for case_id, group, middle, trace, constructors, derivation in drafts:
    source = prefix + middle + tail
    expected = {'trace': trace, 'entered': 1, 'constructors': constructors, 'base': 0,
                'body': 0, 'caught': 0, 'finalized': 0, 'queuedRan': 0, 'after': False}
    rows.append({'id': case_id, 'group': group, 'kind': 'natural-work-terminal',
                 'source': source, 'modes': ['sloppy', 'strict'], 'expected_retained': expected,
                 'expected_error': {'resource': True, 'unsupported': False,
                                    'message': 'script instruction limit exceeded'},
                 'derivation': derivation,
                 'source_file': put(D / 'literals' / (case_id + '.js'), source.encode())})
    groups.setdefault(group, []).append(case_id)
assert len(groups) == 5 and len(rows) == 7
cases = obj(D / 'cases.json', rows)
sources = []
for relative_path in [
    'src/script.rs', 'src/script/microtasks.rs', 'src/script/machine.rs',
    'src/script/machine/statements.rs', 'src/script/promises.rs',
    'src/script/promises/semantics.rs', 'src/script/promises/aggregate_error_coupling_tests.rs'
]:
    b = subprocess.check_output(['git', 'show', f'{BASE}:{relative_path}'], cwd=F / 'worktree')
    sources.append({'base': BASE, 'relative_path': relative_path, 'bytes': len(b),
                    'sha256': hashlib.sha256(b).hexdigest()})
source_basis = obj(D / 'source-basis.json', {
    'published_sources': sources,
    'terminal_policy': 'Existing work() exhausts its finite author allowance and returns the instruction-limit Resource error. The machine bypasses author exception/finally processing for terminal failures and restores saved frame/call/evaluation/stack state. Public execute observes failure and makes queue suspension sticky.',
    'native_boundary': 'Published Promise construction propagates Resource/Unsupported executor errors instead of treating them as ordinary reject reasons. New class construction must preserve that established policy.',
    'borrowed_inspection': 'Published aggregate_error_coupling_tests borrows environments[0].bindings, checks frames/calls/eval_depth/stack_units, queue retention and suspension. This new helper uses only its borrowed inspection convention; no reserve injection, allowance edits, checkpoint calls or post-terminal execute.',
    'standards_scope': 'Class evaluation, argument/parameter order and native constructor delegation follow the independently selected public class contracts. Host terminal behavior is the repository policy, not an ECMAScript catchable-error oracle.',
    'read_limits': 'Only published source and frozen public holds were read; no future producer source or observed candidate outcomes.'
})
contract = obj(D / 'contract.json', {
    'base': BASE, 'root_scope': bind(F / 'root/selection-1.json'),
    'prior_public_hold': bind(F / 'public-unicode-1/source-ready.json'),
    'module': 'src/script/class_abort_tests.rs', 'groups': groups,
    'counts': {'test_groups': 5, 'source_literals': 7, 'planned_mode_attempts': 14,
               'maximum_public_execute_calls': 14, 'post_terminal_script_calls': 0},
    'retained_state': {'queue_length': 1, 'queue_front': 'Callback with exact borrowed global queued value',
                       'suspended': True, 'console_empty': True, 'frames_calls_eval_stack': [0,0,0,0],
                       'author_depth': 0, 'performing_checkpoint': False, 'work_remaining': 0},
    'interface': 'One fresh Runtime/Document per source/mode. Execute exact source once, assert instruction-limit Resource first, then borrow retained state. No script readback, host checkpoint, reset or numerical admission threshold.',
    'parent_reachability': 'Published class syntax refusal should fail the Resource assertion at the first sloppy source in each group; no retained-state assertion or later source/mode is then reached. This is predicted from source, not measured.',
    'preservation': 'All earlier74 groups remain immutable. Separate one-line cfg(test) module registration is proposed for root composition.'
})
seal = obj(D / 'literals-ready.json', {
    'status': 'frozen independent natural terminal contract before Rust conversion',
    'base': BASE, 'cases': cases, 'contract': contract, 'source_basis': source_basis,
    'source_files': [row['source_file'] for row in rows], 'author': bind(Path(__file__)),
    'test_groups': 5, 'sources': 7, 'planned_modes': 14, 'project_execution': False
})
print(json.dumps(seal))
