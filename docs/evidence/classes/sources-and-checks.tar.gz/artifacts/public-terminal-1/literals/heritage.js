var trace='',entered=0,constructors=0,base=0,body=0,caught=0,finalized=0,queuedRan=0,after=false;
var queued=()=>{queuedRan++;trace+='Q';console.log('late');};
queueMicrotask(queued);
function exhaust(mark){trace+=mark;entered++;while(true){}}
try{
 class C extends exhaust('H') {constructor(){constructors++;super();body++;}static [(trace+='L','later')](){}}
 after=true;
}catch(e){caught++;trace+='X';}finally{finalized++;trace+='F';}
after=true;trace+='Z';
