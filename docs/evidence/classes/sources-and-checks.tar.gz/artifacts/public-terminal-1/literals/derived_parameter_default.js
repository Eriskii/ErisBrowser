var trace='',entered=0,constructors=0,base=0,body=0,caught=0,finalized=0,queuedRan=0,after=false;
var queued=()=>{queuedRan++;trace+='Q';console.log('late');};
queueMicrotask(queued);
function exhaust(mark){trace+=mark;entered++;while(true){}}
function B(){base++;trace+='B';}
class D extends B {constructor(x=exhaust('P')){constructors++;trace+='C';super();body++;trace+='D';}}
try{new D();after=true;}catch(e){caught++;trace+='X';}finally{finalized++;trace+='F';}
after=true;trace+='Z';
