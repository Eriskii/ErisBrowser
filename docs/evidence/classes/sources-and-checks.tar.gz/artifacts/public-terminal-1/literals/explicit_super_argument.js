var trace='',entered=0,constructors=0,base=0,body=0,caught=0,finalized=0,queuedRan=0,after=false;
var queued=()=>{queuedRan++;trace+='Q';console.log('late');};
queueMicrotask(queued);
function exhaust(mark){trace+=mark;entered++;while(true){}}
function B(){base++;trace+='B';}
class D extends B {constructor(){constructors++;trace+='C';super(exhaust('A'));body++;trace+='D';}}
try{new D();after=true;}catch(e){caught++;trace+='X';}finally{finalized++;trace+='F';}
after=true;trace+='Z';
