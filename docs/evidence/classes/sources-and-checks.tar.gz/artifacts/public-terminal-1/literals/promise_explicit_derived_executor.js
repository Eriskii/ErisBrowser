var trace='',entered=0,constructors=0,base=0,body=0,caught=0,finalized=0,queuedRan=0,after=false;
var queued=()=>{queuedRan++;trace+='Q';console.log('late');};
queueMicrotask(queued);
function exhaust(mark){trace+=mark;entered++;while(true){}}
function executor(resolve,reject){
 if(typeof resolve!=='function'||typeof reject!=='function')throw new Error('executor callbacks');
 try{exhaust('E');body++;trace+='e';}finally{finalized++;trace+='f';}
}
class P extends Promise {constructor(executor){constructors++;trace+='C';super(executor);body++;trace+='D';}}
try{new P(executor);after=true;}catch(e){caught++;trace+='X';}finally{finalized++;trace+='F';}
after=true;trace+='Z';
