from pathlib import Path
import hashlib,json,re,subprocess,difflib
F=Path('/tmp/eris-class-runtime-plan-1');W=F/'worktree';BASE='f3118ae5787c410648657f7c822efb7014201dd1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def load(p):return json.loads(Path(p).read_text())
def verify(d):
 if isinstance(d,dict):
  if all(x in d for x in ('path','bytes','sha256')):assert bind(d['path'])=={x:d[x] for x in ('path','bytes','sha256')}
  if all(x in d for x in ('relative_path','base','bytes','sha256')):
   b=subprocess.check_output(['git','show',d['base']+':'+d['relative_path']],cwd=W);assert (len(b),sha(b))==(d['bytes'],d['sha256'])
  for v in d.values():verify(v)
 elif isinstance(d,list):
  for v in d:verify(v)
expected={
'naming_identifier_and_logical_assignment':'ABCD|names','naming_parameter_defaults':'Param|Arrow|Ctor|Method|Static|1','naming_object_data_property_keys':'KCSD|plain|spaced key|computed|[slot]|','naming_parentheses_comma_conditional_boundaries':'Wrapped|Assigned|wrapped|empty','naming_hints_preserve_static_name_and_length':'members:2',
'context_strict_heritage_and_computed_keys':'HTKTST|0','context_nested_class_evaluation_uses_outer_super':'HB1hKB2Sk','context_escaped_super_after_throw_preserves_owner':'DTRB7A8R','context_derived_default_super_before_body':'PB4QDQR','context_nested_base_constructor_rejects_outer_super':0,'context_nested_method_arrow_rejects_outer_super':0,
'naming_unicode_identifiers_and_computed_keys':'utf16-names'}
notes={
'naming':[
 'Evaluated identifier/logical RHS forms receive hints; skipped RHS forms produce no key effects. An inferred name creates no inner binding; explicit names remain explicit.',
 'Undefined parameter defaults and evaluated object data keys supply names. Parentheses preserve anonymous-definition status, while comma/conditional wrappers do not.',
 'Symbol descriptions are bracketed (missing description produces empty name). Naming precedes class member definitions, preserving static name/length overrides.'
],
'context':[
 'Class heritage and computed keys are strict while retaining enclosing lexical this, NewTarget and super permissions. New method bodies establish fresh function contexts.',
 'Escaped arrows retain the derived activation after throw; super uses its live constructor parent and original alternate NewTarget. A second super constructs before duplicate-bind failure.',
 'Parameter defaults run before the body with derived this uninitialized. Nested base constructors and nonconstructor method arrows cannot inherit outer direct-super permission.'
],
'unicode':[
 'Identifier spelling retains code points without normalization. U+10400 encodes as UTF-16 [55297,56320]; decomposed e+acute remains [101,769].',
 'String keys preserve [38634,55357,56832]; Symbol description lambda plus lone-surrogate produces bracketed [91,955,55296,93]. Both class and method naming use those units.'
]}
prior=F/'public-tests-1/raw/src/script/class_semantics_tests.rs';prior_count=62
for name,count,strings in [('naming',5,10),('context',6,14),('unicode',1,2)]:
 H=F/f'public-{name}-1';O=F/f'public-{name}-review-1';O.mkdir(exist_ok=True)
 seal=load(H/'source-ready.json');verify(seal);verify(load(H/'literals-ready.json'))
 cases=load(H/'cases.json');verify(cases)
 for b in ['spec-basis.json','source-basis.json']:
  if (H/b).exists():verify(load(H/b))
 assert len(cases)==count
 generated=[];literal_count=0
 for c in cases:
  assert c['modes']==['sloppy','strict'];assert c['expected']['value']==expected[c['id']],c['id']
  assert c['expected']['type']==('number' if isinstance(expected[c['id']],int) else 'string')
  pieces=['#[test]\nfn class_public_'+c['id']+'() {\n']
  if c['kind']=='semantic':
   pieces+=['    observe(\n','        '+json.dumps(c['id'])+',\n'];fields=['source','observation']
  else:
   assert c['kind']=='early-error' and c['expected_error']=='SyntaxError';pieces+=['    early_error(\n','        '+json.dumps(c['id'])+',\n'];fields=['setup','source','observation']
  for field in fields:
   assert '"###' not in c[field]
   assert Path(c[field+'_file']['path']).read_bytes()==c[field].encode()
   pieces+=['        r###"'+c[field]+'"###,\n'];literal_count+=1
  value=expected[c['id']]
  oracle='Value::Number(0.0)' if isinstance(value,int) else 'Value::String('+json.dumps(value,ensure_ascii=False)+'.into())'
  pieces+=['        '+oracle+',\n','    );\n','}\n\n'];generated.append(''.join(pieces))
 assert literal_count==strings
 append=''.join(generated).encode();assert append==(H/'append-tests.rs').read_bytes()
 row=seal['files'][0];before=Path(row['before']['path']).read_bytes();raw=Path(row['raw']['path']).read_bytes()
 assert before==prior.read_bytes();assert raw==before+append
 assert len(re.findall(rb'^#\[test\]$',raw,re.M))==prior_count+count
 want=''.join(difflib.unified_diff(before.decode().splitlines(True),raw.decode().splitlines(True),fromfile='a/'+row['relative_path'],tofile='b/'+row['relative_path']))
 assert Path(row['diff']['path']).read_text().splitlines(True)[2:]==want.splitlines(True)[2:]
 assert seal['registration_changes']==0
 checks={'status':'clear','base':BASE,'groups':count,'planned_mode_attempts':2*count,'literal_strings':strings,'prior_groups_preserved':prior_count,'composed_groups':prior_count+count,'exact_prior_prefix':bind(prior),'expectations':[{'id':c['id'],'expected':c['expected'],'source_sha256':sha(c['source'].encode())} for c in cases],'manual_semantic_findings':[],'manual_reasoning':notes[name],'conversion':'Each entire Rust test body independently reconstructed from frozen source/setup/observation and independently selected expected result. Exact append and diff verified; old helpers and registration retained.','observations':'This review predicts no execution result and does not use any candidate or alternate engine.'}
 (O/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
 refs=['https://tc39.es/ecma262/multipage/syntax-directed-operations.html#sec-isanonymousfunctiondefinition','https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-setfunctionname','https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-classdefinitionevaluation']
 if name=='context':refs+=['https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword','https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-class-definitions-static-semantics-early-errors','https://tc39.es/ecma262/multipage/ecmascript-language-source-code.html#sec-strict-mode-code']
 review={'status':'clear','scope':'Independent source/literal semantics and exact additive Rust conversion peer; no implementation or execution review.','base':BASE,'hold':bind(H/'source-ready.json'),'frozen_literals':bind(H/'literals-ready.json'),'prior_original_helper_review':bind(F/'public-tests-review-1/review.json'),'checks':bind(O/'checks.json'),'checker':bind(F/'public-naming-review-1/check-supplements.py'),'primary_spec':{'checked_date':'2026-10-15','urls':refs},'findings':[],'activity':{'candidate_production_read':False,'project_execution':False,'live_edits':False},'result':f'{count} appended groups / {2*count} planned modes / {strings} frozen strings reconcile; exact previous {prior_count}-group prefix remains unchanged.'}
 (O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(O/'review.json')))
 prior=Path(row['raw']['path']);prior_count+=count
