# Proposed Node.getRootNode browser witness

Source only, based on published predicates commit
`6834288f9ef68d26ebbae4016802219cc606eacd`. The fixture has not been parsed or
executed and the helper has not been compiled. Ordinary success and feasibility
under the unchanged author allowance remain required, not observed.

The only proposed repository paths are `tests/fixtures/node-root.html` and
`tests/support/node_root.rs`. Root owns later Page/worker integration. The helper
uses only existing public Rust APIs and exports `HTML`, `State`,
`metadata(phase)` and `check(doc, layout, images, fonts, phase, previous)`.
Use a 320 by 240 viewport, phase 0 after load and phase 1 after one actual
`#change` click in the same page/worker realm. Expected titles are `Roots ready`
and `Roots done`. Page title and worker snapshot metadata should be checked
separately through `metadata`; no worker generation is reserved here.

## Observable contract

The script first saves `Node.prototype.getRootNode`, proves it callable, and
successfully invokes it on the genuine Document. There are no expected-error
catches that could turn a missing prerequisite into success. All visual success
classes are assigned only after native/root checks complete.

At load the visible `Same root` branch is in the left column. The script also
retains an old hidden subtree, ordinary template Text, actual template content,
and an independent unhosted DocumentFragment containing literal `fragment`.
Root checks distinguish canonical Document, a detached ordinary fragment and
template content; `composed:true` must not follow the template host. A branch
own-property shadow leaves the saved native function usable.

One click performs three native calls with inherited `composed` accessors:

1. Move the receiver Text from its visible branch into actual template content,
   return false, and require the result to be that content fragment. Inspect the
   completed move, then restore the same Text to the same branch.
2. Move the branch ancestor into content, return a truthy object with poisoned
   coercion hooks, and require the result for the descendant Text to be content.
   Inspect the completed move, then attach the same branch to the right column.
3. Empty the left container, detaching the old hidden ancestor. Require the
   result for its retained descendant Text to be the old ancestor.

All accessors check original `this`. The cumulative read count is exactly three
and the trace is the literal `rad`. These moves are performed inside dictionary
Get callbacks: reading a root before conversion gives a wrong result. No root
is inferred from the final screenshot. The inherited truthy member must undergo
noncoercive ToBoolean; no hook should run. JS option/function objects may be
allocated during the click, but **no DOM nodes** are created then.

The final visible branch is in the right column; the old subtree is parentless
with all descendants, payloads and own marker retained. Title/status update by
changing existing Text.data, not replacing children. Both phases recheck saved
method identity/shadowing, canonical Document and template boundaries.

## Independent public helper oracle

The helper records twenty distinct node IDs and total arena length at phase 0,
then requires all of them and the count to remain unchanged. It checks literal
child vectors, reciprocal links, Text kinds/units, detached old nodes and both
fragment kinds. A unique literal `fragment` Text identifies the intentional
unhosted fragment through the public node arena; it cannot be reached using a
connected-tree selector. This test-side scan is not a runtime implementation or
budget claim. The helper cannot inspect JavaScript-only handles or own bags in
a worker snapshot; successful script checks cover those.

The canvas reference is independently authored, script-free scalar markup. It
does not clone the observed Document or derive expected text/colors from its
output. Full-canvas equality is supplemented by green/blue marker pixels, an
exclusive nonempty glyph band in the expected column, exact one-time `Same`
and `root` DrawCommand words, and phase status text. Hidden/template/detached
bookkeeping has no visible reference counterpart and is checked structurally.

Root's Page integration should require no script diagnostics, retain State
across the actual click and compare both layouts. Worker integration should do
the same across load/event snapshots, validate response/generation using the
existing protocol and perform normal owned-process cleanup. No cache priming,
new engine hook, protocol extension or synthetic second load is needed.

## Limits

No ShadowRoot, composed-shadow rendering, event retargeting, cross-document
adoption, Proxy, BigInt, XML or missing DOM method is a prerequisite. The fixture
does not claim callback rollback, malformed-host coverage, private quota
boundaries or physical allocator recovery. Those belong to the separate runtime
tests and scope. Browser success remains an ordinary-success expectation.

Normative basis is the reviewed root scope and layout assessment: DOM
[getRootNode](https://dom.spec.whatwg.org/#dom-node-getrootnode), ordinary
[root](https://dom.spec.whatwg.org/#concept-tree-root), and Web IDL
[dictionary conversion](https://webidl.spec.whatwg.org/#es-dictionary).
