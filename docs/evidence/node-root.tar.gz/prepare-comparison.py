from pathlib import Path
import ast,hashlib,json,re,shutil,subprocess
B=Path(__file__).resolve().parent
P=Path('/tmp/eris-node-root-preparation-1')
OLD=Path('/tmp/eris-node-predicates-1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 with (B/name).open('x') as f:json.dump(value,f,indent=2);f.write('\n')
def binding(name):
 p=B/name;return dict(path=name,bytes=p.stat().st_size,sha256=sha(p))
baseline=json.loads((B/'root-before.json').read_text())
assert len(baseline['cases'])==32 and len(baseline['controls'])==16 and not baseline['binding_failures']
assert all(x['observation']['status']=='exception' and x['observation']['phase']=='runtime' and x['observation']['error_type']==x['observation']['error_identity']=='TypeError' for x in baseline['cases'])
assert sum(x['verified'] for x in baseline['controls'])==4
shutil.copytree(P,B/'preparation',ignore=shutil.ignore_patterns('browser','__pycache__'))
files=['base.json','base-after-probe-fix.json','before-comparison-inputs.json','root-before.json','root-baseline-command.json','root-baseline.log','root-verify-command.json','root-verify.log','preparation/replay/source-ready.json','preparation/replay/replay.py','preparation/replay/replay-inputs.json','preparation/replay/replay-matrix.json','preparation/replay/preparation-history.json','preparation/replay/inert-verification.json','preparation/replay/html-source-review.json','preparation/independent/cases.js','preparation/independent/controls.json','preparation/root/plan-review.json']
config=dict(base='066435fb0682449c62be6ecb999ca457653af7a1',baseline_release_sha256=baseline['binary_sha256'],established_cases=4268,established_controls=476,new_cases=32,new_controls=16,files=[binding(n) for n in files])
write('compare-root-inputs.json',config)
s=(OLD/'compare-predicates.py').read_text()
s=s.replace('compare-predicates-inputs.json','compare-root-inputs.json')
s=re.sub(r"INPUT_SHA = '[0-9a-f]{64}'", "INPUT_SHA = '"+sha(B/'compare-root-inputs.json')+"'",s)
old="('node-predicates', 'predicates-after.json', 32, 16, 'new'),";assert s.count(old)==1
s=s.replace(old,"('node-predicates', 'predicates-after.json', 32, 16, 'established'),\n    ('node-root', 'root-after.json', 32, 16, 'new'),")
s=s.replace("if name == 'node-predicates':","if name == 'node-root':").replace('complete-node-predicates-replay-comparison','complete-node-root-replay-comparison').replace("'predicates-comparison.json'","'root-comparison.json'")
(B/'compare-root.py').write_text(s)
# Classification helpers remain exactly the previous complete-row semantics.
def funcs(s):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a=funcs((OLD/'compare-predicates.py').read_text());c=funcs(s)
for name in ['underlying','identity','input_record','healthy','compare_rows','controls']:assert a[name]==c[name]
previous=json.loads((B/'comparison-before/predicates-after.json').read_text())
policy=dict(profile='node-predicates',reason='One new ordinary getRootNode method invalidates the former complete26-key inventory. Exact previously declared sources/expectations remain; classify only anticipated raw losses.',rows=[],already_unhealthy_unchanged=[])
for kind in ['cases','controls']:
 for row in previous[kind]:
  if row['id'].startswith('represented_complete_key_order#') or row['id'].startswith('represented-node-order-'):
   assert row['matches_expectation'] is True
   policy['rows'].append(dict(kind=kind,id=row['id'],mode=row['mode'],before=row,expected_after_observation=dict(status='exception',phase='runtime',error_type='Error' if kind=='cases' else 'TypeError',error_identity='Error' if kind=='cases' else 'TypeError')))
assert len(policy['rows'])==6
for profile,filename in [('node-constants','node-constants-after.json'),('node-normalize','normalize-after.json')]:
 report=json.loads((B/'comparison-before'/filename).read_text());count=0
 for kind in ['cases','controls']:
  for row in report[kind]:
   if row.get('matches_expectation') is False:
    policy['already_unhealthy_unchanged'].append(dict(profile=profile,filename=filename,kind=kind,id=row['id'],mode=row['mode'],before=row));count+=1
 assert count==6
write('anticipated-inventory-changes.json',policy)
s=(OLD/'classify-inventory.py').read_text()
s=re.sub(r"EXPECTED='[0-9a-f]{64}'", "EXPECTED='"+sha(B/'anticipated-inventory-changes.json')+"'",s)
s=s.replace("B/'comparison-before/normalize-after.json'","B/'comparison-before/predicates-after.json'")
start=s.index("older=json.loads(");end=s.index("if sys.argv[1:]==['--verify-before']:",start)
s=s[:start]+'''assert len(policy['already_unhealthy_unchanged'])==12
for row in policy['already_unhealthy_unchanged']:
 older=json.loads((B/'comparison-before'/row['filename']).read_text())
 assert [x for x in older[row['kind']] if x['id']==row['id'] and x['mode']==row['mode']]==[row['before']]
 assert row['before']['matches_expectation'] is False
 if row['kind']=='controls':assert row['before']['verified'] is False
'''+s[end:]
s=s.replace("'predicates-comparison.json'","'root-comparison.json'")
start=s.index('older_profile=next(');end=s.index('for kind,before,after',start)
s=s[:start]+'''for older_name in ['node-constants','node-normalize']:
 older_profile=next(x for x in result['profiles'] if x['profile']==older_name)
 for kind in ['cases','controls']:
  assert not older_profile[kind]['changes']
'''+s[end:]
s=s.replace("('cases',4148,4146),('controls',456,452)","('cases',4178,4176),('controls',468,464)").replace("('cases',4236,2),('controls',460,4)","('cases',4268,2),('controls',476,4)")
s=s.replace("current_path=B/'predicates-after.json'","current_path=B/'root-after.json'").replace("x['profile']=='node-predicates'","x['profile']=='node-root'")
s=s.replace('Six Normalize inventory assumptions are invalidated by the three new Node methods. Older Node inventory failures remain unchanged. Raw losses and unhealthy controls retain their health; no waiver.','Six predicate inventory assumptions are invalidated by getRootNode. Older Node and Normalize inventory failures remain unchanged. Raw losses and unhealthy controls retain their health; no waiver.')
(B/'classify-inventory.py').write_text(s)
s=(OLD/'replay-jobs.py').read_text();marker='def run(job):';assert s.count(marker)==1
s=s.replace(marker,"jobs.append(('node-root',['python3','/tmp/eris-node-root-preparation-1/replay/replay.py',str(BINARY),sha,str(OUT/'root-after.json')]))\n"+marker)
(B/'replay-jobs.py').write_text(s)
s=(OLD/'formal-check.py').read_text().replace('/tmp/eris-node-predicates-1','/tmp/eris-node-root-1');(B/'formal-check.py').write_text(s)
for label,script in [('compare-before','compare-root.py'),('classify-before','classify-inventory.py')]:
 log=B/(label+'.log');args=['python3',str(B/script),'--verify-before']
 with log.open('xb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 write(label+'-command.json',dict(command=args,exit=r.returncode,log=log.name,sha256=sha(log)))
 assert r.returncode==0,log.read_text()
files=['before-comparison-inputs.json','compare-root-inputs.json','compare-root.py','replay-jobs.py','formal-check.py','anticipated-inventory-changes.json','classify-inventory.py','prepare-comparison.py','root-before.json','compare-before-command.json','compare-before.log','classify-before-command.json','classify-before.log']
ready=dict(phase='Prepared after single bound predicate-release baseline; no getRootNode compiler/candidate engine',files=[binding(n) for n in files],established_cases=4268,established_controls=476,new_cases=32,new_controls=16,baseline_healthy_cases=4178,baseline_healthy_controls=468,expected_new_historical_losses=dict(cases=2,controls=4),older_unhealthy_unchanged=dict(cases=4,controls=8),profile_count=17,runner_path='Original absolute preparation driver paths required; copies are archival only',aggregate_runner='Expect1 from olderNode/Normalize and newly stalepredicate inventory profiles; retain raw nonzero exits and independently classify exact differences')
write('comparison-preparation-ready.json',ready);print('Prepared17profiles; before checks passed')
