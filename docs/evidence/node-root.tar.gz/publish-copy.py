import hashlib,json,subprocess,shutil
from pathlib import Path
A=Path(__file__).resolve().parent;R=A/'worktree';M=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
assert subprocess.check_output(['git','status','--porcelain'],cwd=M)==b''
s=json.loads((A/'candidate-source-final.json').read_text());d=json.loads((A/'documentation-ready-2.json').read_text())
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=M,text=True).strip()==s['base']
rows=s['files']+d['files'];assert len(rows)==30 and len({r['path']for r in rows})==30
for r in rows:
 p=R/r['path'];assert hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256'] and p.stat().st_size==r['bytes']
for r in rows:
 p=M/r['path'];p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R/r['path'],p)
with (A/'publication-copy.json').open('x')as f:json.dump(dict(base=s['base'],files=rows),f,indent=2);f.write('\n')
print('Copied30heldsource/documentationpaths; evidence package still separate.')
