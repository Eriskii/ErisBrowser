import hashlib,json,subprocess,time
from pathlib import Path
B=Path(__file__).resolve().parent
def run(label,args):
 p=B/(label+'.log');start=time.monotonic()
 with p.open('xb') as f:r=subprocess.run(args,cwd=B,stdout=f,stderr=subprocess.STDOUT)
 record=dict(command=args,exit=r.returncode,elapsed_seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 with (B/(label+'-command.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record),flush=True)
 return r.returncode
assert run('replay-jobs',['python3',str(B/'replay-jobs.py')])==1
assert run('comparison',['python3',str(B/'compare-root.py'),'--binary',str(B/'eris-js')])==0
assert run('inventory-classification',['python3',str(B/'classify-inventory.py')])==0
