# Independent getRootNode cases and controls

These are unexecuted, independently authored expectations for the selected ordinary-root slice in `../root/scope.md`. No candidate implementation or runtime output was used as an oracle. `../layout/assessment.md` binds the source/spec assessment. Main and the predicate implementation checkout are untouched.

Load `cases.js` and invoke exactly one `nodeRootCases[name]()` in each fresh Runtime/Document and mode. Sixteen bodies give 32 ordinary-success modes. Each returns the literal boolean true. Do not invoke all bodies in one realm or increase a quota to fit an aggregate. The source size is not a claim of measured runtime feasibility; retain any genuine work/allocation refusal with its original ordinary-success expectation.

Every body first calls `rootPrerequisite`, which checks a callable cached method and successful authentic detached Text/DocumentFragment roots, then a linked Text root for both default and composed:true. A missing function or broken positive route cannot accidentally satisfy later TypeError catches. Metadata's nonconstruction test separately checks that Reflect.construct is callable and successfully constructs a Text with literal data and an authentic saved-method root. Negative receiver/options tests use the same already-working saved function. Ordinary assertions throw Error and are not expected exceptions.

`inventory.json` freezes the sixteen names and a literal 27-key represented prototype inventory: two current attributes, getRootNode/hasChildNodes/normalize/isSameNode/contains, eighteen constants, constructor, and the final Symbol.toStringTag. This is the selected implementation's represented subset, not a claim that standards Node has only these members. The independent literal 21-key constructor remains unchanged. Earlier 22/23/26-key sources, controls and ordinary expectations are not modified by these files.

`controls.json` contains four positive/wrong pairs in both modes (16 modes). The wrong member is exactly its positive source followed by one intentional intrinsic Error. All prerequisites throw TypeError. Negative health requires the same-mode positive to succeed AND the wrong member to report runtime exception/Error/Error. Missing/null observations, other error identities and unhealthy positives cannot become passing negative controls. The common pair tests exact literal UTF-16; the three feature pairs test authentic roots/metadata, dictionary conversion plus post-callback root, and the literal current inventory. No baseline pass count is assumed.

Coverage is deliberately separated into small fresh-realm bodies:

* Ordinary descriptors, inherited/saved identity, replacement/deletion/shadows and no fallback resurrection.
* Connected Document identity, detached ancestor roots, fragment moves and retained old links, distinct leaves with exact unpaired data.
* Ordinary template children versus actual nested content fragments, including composed:true without a host jump.
* Missing/undefined/null defaults versus explicit objects with an inherited Object.prototype getter; one ordinary inherited/non-enumerable Get and original accessor receiver.
* Array/function/DOM object dictionaries, noncoercive member ToBoolean, rejection of non-null primitive dictionaries, and authentic receiver checking before options access.
* Receiver/ancestor moves and detach during conversion; thrown-value identity with completed mutation retained; argument-expression order and ignored extra conversion.
* Internal links unaffected by authored parent/host/shadowRoot properties; finite nested calls and genuine alternate-prototype Text branding.

The stored literal payload checks are `[55296,120]` for Text and `[56320]` for Comment. Their identity/root calls must not rewrite data. The dictionary trace is exactly `ABC` (first argument expression, ignored extra expression that moves the node, then composed getter), followed by `X` from a later argument throw before native brand checking.

ShadowRoot construction and open/closed/nested shadow trees, slotting, Proxy traps, BigInt primitives, independent Document construction, cross-document adoption and absent Attr/CDATA/XML nodes are separate unmet prerequisites. These tests neither emulate them with template hosts nor label their absence passing. Doctype root handling and malformed/raw host trees belong in private setup tests because this fixture does not add missing Document enumeration/getter prerequisites. Resource cuts, depth256 and wide-parent scan accounting are private implementation tests, not inferred from these ordinary cases.

Primary references: [DOM Node/getRootNode](https://dom.spec.whatwg.org/#dom-node-getrootnode), [Node IDL and options](https://dom.spec.whatwg.org/#interface-node), [ordinary root](https://dom.spec.whatwg.org/#concept-tree-root), [shadow-including root](https://dom.spec.whatwg.org/#concept-shadow-including-root), [Web IDL dictionary conversion](https://webidl.spec.whatwg.org/#es-dictionary), [boolean conversion](https://webidl.spec.whatwg.org/#es-boolean), [operation binding](https://webidl.spec.whatwg.org/#es-operations). Contemporary specification revisions are retained in `../layout/spec-inputs.json`.

Preparation checks were only Python JSON/text/hash operations: sixteen unique named bodies, four exact positive/tail pairs, literal array lengths, fixed expected records and source hashes. No JS parser, interpreter, browser, compiler, oracle or test was invoked.
