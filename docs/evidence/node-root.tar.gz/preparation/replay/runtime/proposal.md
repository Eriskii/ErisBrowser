# Represented Node.getRootNode: Runtime implementation proposal

Source-only preparation against the sixteen-path predicate final manifest
`a4ae87eeeacd46964f1f8b193f45412bf2e11a9bcca1f10358aae741336cf9ef`.
`source-inputs.json` binds the exact inspected sources, root scope and layout
assessment. The additive `../root/published-base.json` now binds the subsequently
published predicate commit `6834288f9ef68d26ebbae4016802219cc606eacd`; the earlier
source context remains separately identified. No implementation, compiler, engine,
fixture execution or benchmark is part of this preparation.

## Narrow module and helper sharing

Add `src/script/node_root.rs` and its private tests, with one
`METADATA_OBJECTS` slot. Add the module declaration to script.rs. Expose only
the existing predicate `node_id` and `local_node` functions as `pub(super)`;
leave their bodies and existing predicate callers unchanged. Import those two
checks into node_root. Keep its result-producing parent loop local instead of
extracting a generic tree walker or changing contains. No DOM API, data builder,
host-parent helper or storage structure is needed.

Proposed entry points:

```text
Runtime::install_node_root(&mut self, prototype: usize) -> Result<()>
Runtime::node_get_root_node(&mut self, receiver: Value,
                           args: &[Value], doc: &mut Document) -> Result<Value>
Runtime::node_root_options(&mut self, args: &[Value],
                          doc: &mut Document) -> Result<bool>   // private
```

Install one `DOM.Node.getRootNode` native through `node_data_function`, with
display name `getRootNode`, length zero and the existing cached metadata bag.
Its Node owner property is writable/enumerable/configurable; name/length keep
the existing nonwritable/nonenumerable/configurable flags. The function is not
constructible. Saved calls, own shadows, property deletion and ordinary
prototype replacement use the established route, without a virtual fallback.
An authentic node constructed with an alternate prototype retains its brand;
this is not a promise to support changing an existing host node's prototype.

Add the unique eleven-byte suffix arm to `node_data_native`. Retain its one
length-discriminator unit and pay eleven units before comparing `getRootNode`.
No existing suffix has length eleven, so accessors, normalize and predicate
routes keep their current costs. The unchanged invocation bridge pays 24 work
and 52 bytes for the actual twenty-byte full-name copy, inside stack cleanup.
The scoped dispatch/name-copy cost is therefore 36 work and 52 bytes, in
addition to ordinary VM call admission and the body below.

## Receiver, dictionary and fresh state

Pay sixteen before `node_id(receiver, doc)`. Retain only that ID across options
conversion. A forged, nullish or out-of-range receiver fails before inspecting
the dictionary. `Value::Document` must identify the genuine current Document
root. JavaScript argument expressions, including ignored extras, have already
run; the method itself does not convert extra arguments.

Pay eight for first-argument/default/type discrimination. Omission, undefined
and null select the default dictionary without any Get or key allocation.
Reject every other represented primitive with TypeError, without string or
number conversion. Accept every represented object-like Value admitted by
`js_object`, including ordinary objects, arrays, functions, Native values,
Document/Node, Window, Console, Math, JSON, Style and ClassList.

For an object, construct exactly one fixed `composed` JsString through the
existing `dom_proto_text("composed")`: 24 work and 96 charged bytes, with exact
Vec reservation followed by the separately covered Rc copy. Reuse the helper
without renaming or changing it; it accepts static ASCII and has no bootstrap
state dependency. No key cache or retained field is added. Then perform one
`lookup_property(&options, &key, doc)?.unwrap_or(Value::Undefined)`. Its existing
ordinary property search and accessor invocation are retained, with the original
options value as accessor receiver. A missing property and an undefined member
both choose false. Pay two before default/Boolean selection; all other members
use `Value::truthy`, which cannot call ToPrimitive or authored hooks. A thrown
getter value propagates without replacement. No boolean or traversal work is
charged after an abrupt Get, because those stages were not reached.

For default dictionaries the same two units pay selecting false; they are not
a fictitious property lookup. The local composed result is intentionally
accepted for both true and false. All represented roots are ordinary roots;
there is no ShadowRoot kind. Do not reject true and do not follow a template
fragment's host. Add a comment tying this equivalence to the absent ShadowRoot
representation so a future ShadowRoot implementation must revisit the path.

No node or parent reference survives Get. Even for a detached Text or Document,
finish dictionary conversion first, then reacquire current local state. A
getter can move the receiver or an ancestor, detach an old root, replace or
delete the public method, recurse through a saved function, or throw after a
move. Completed effects remain; this read operation adds no rollback.

## Why the constant-key lookup is sufficient here

This is a proof for the literal member `composed`, not a generalized Web IDL
Get implementation or a claim that every legacy host property is ordinary.
`lookup_property` uses document-aware prototype resolution, snapshots the first
own descriptor found, and either returns data/undefined or invokes its getter
once with the original receiver. The returned descriptor is resolved before
author code, and no lookup is repeated afterward. The prototype bound of 96 is
distinct from the DOM ancestor bound of 256.

The bound script.rs paths establish the represented cases:

* Object, Function and Array own bags and Native cached/name bags are handled by
  `own_property`; parameter mappings remain the existing implementation. The
  fixed key is neither array/string `length` nor an index. Math/JSON use their
  ordinary bags. Native fallback members have other names.
* Document/Node own descriptors go through `read_own_property` and their ordinary
  inherited interface prototypes. `composed` is not an unforgeable/HTML attribute,
  event-handler name, or virtual DOM field. Window uses the existing global
  binding lookup and its ordinary prototype path. Console and ClassList have no
  native fallback named `composed`; their ordinary prototype lookup remains.
* Event's `composed` is installed as an ordinary native accessor on
  Event.prototype. The lookup calls it just as an authored getter, rather than
  reading an event slot directly or substituting a default. An incompatible
  Event-prototype inheritor preserves its native getter's TypeError.
* Style's `style_get` handles methods, parentRule, cssText, length, numeric indices
  and recognized CSS properties before ordinary lookup. The literal composed
  matches none. `style_property_name` leaves the lowercase spelling unchanged;
  cssom aliases and css.rs supported/shorthand rosters contain no composed
  property. Thus this key has only ordinary lookup behavior. Bind cssom.rs and
  css.rs as proof dependencies and add direct Style/host dictionary witnesses.

Using raw `get` would introduce an implicit unreserved UTF-16 key collect;
`get_key` repeats lookup after absence and converts to UTF-8; splice's named
lookup excludes hosts. The proposed path removes those actual unnecessary
steps while keeping the one ordinary observable member Get. If composed later
gains any special host behavior, this proof and its witnesses must be revisited.

Existing non-host own-property and native-name searches in `find_property_in`
do not all have separately complete table accounting. This plan does not
silently claim to fix that inherited generic property layer. Its existing
charges, native callback charges and allocation limitations remain, and the
new literal-key materialization is explicitly paid. Do not waive any reached
charge or introduce an uncharged alternate lookup implementation.

## Paid ordinary-root traversal

After conversion, set `current = receiver_id` and `edges = 0`. Each loop pays
twelve before `local_node(doc, current)`. This covers fresh ID, arena/vector
bound, leaf/container shape and parent/edge decisions. The shared helper rejects
parented Fragments and nonroot or parented Documents. No character data is read.

If parent is absent, pay four before canonicalizing the return value. Return
`Value::Document` only for the genuine Document at `doc.root`; return
`Value::Node(current)` for other roots. If malformed host data makes doc.root
refer to a non-Document node, explicitly refuse rather than manufacture the
public Document value. The canonical result copies an existing small value and
creates no wrapper, bag or payload allocation.

If a parent exists, reject a self-parent or an attempt to follow a 257th edge.
Pay twelve before validating the parent with local_node and requiring a
Document, Element or Fragment container. Compute checked `1 + 4*s` for its
child-ID count s, pay it before the scan, and require exactly one occurrence of
current. The scan compares IDs only, without dereferencing other siblings.
Missing/duplicate membership or invalid IDs/shapes produce TypeError. On
success advance one edge. The endpoint at exactly 256 edges is still visited
and may return. Reciprocal cycles that do not encounter another refusal are
bounded by the same counter; Resource can win first. Do not return a guessed
root on either refusal.

No root cache, depth cache, ancestry set, vector, arena scan or host-inclusive
link is used. Validate only reached local links; this is not a full validator
for arbitrary Rust host mutation or cross-document ID ownership. Ordinary
fragment/template boundaries, coherent Document-parent Text and the accepted
snapshot edge-depth all remain supported. The original Runtime/Document pairing
limitation remains explicit.

## Exact scoped body ledger

For successful calls, let V be reached DOM nodes, s_i each followed parent's
child count, and G_W/G_H the actual existing ordinary-Get and callback work/heap.

| Stage | Work | Charged bytes |
| --- | ---: | ---: |
| Receiver ID admission | 16 | 0 |
| First argument/default/object discrimination | 8 | 0 |
| Default/Boolean selection after successful conversion | 2 | 0 |
| Each reached node | 12 | 0 |
| Each followed parent, including membership scan | 13 + 4*s_i | 0 |
| Final canonical return | 4 | 0 |
| Object dictionary only: literal key Vec and Rc | 24 | 96 |
| Object dictionary only: ordinary Get and callback | G_W | G_H |

Default-dictionary body work is `30 + 12*V + sum(13 + 4*s_i)`, with zero owned
body storage. A detached root costs 42. A unary 256-edge path costs 7,466; the
scoped dispatch/copy raises these to 78 and 7,502, with 52 copied-name bytes,
before common VM-call costs. An object dictionary adds `24 + G_W` and
`96 + G_H`. Invalid receiver needs the reached sixteen; a valid receiver with
primitive options reaches twenty-four. Every failure retains already admitted
work/bytes; no post-failure debit is invented.

G_W is not an assumed constant: the current eight-unit key causes one work unit
per reached prototype value, plus existing DOM own-bag search/Document-key
checks, Window lookup, document-aware prototype mapping and any getter call.
Window lookup retains its existing `32 + 6*8` storage charge. DOM own-property
lookup retains full key-comparison charges; cached natives keep their existing
direct metadata route. Authored getter code and nested calls share the same
steps, heap and call/stack counters. There is no nested execute, finish_bootstrap,
reset or allowance refresh. G_H includes reached VM/native allocations, not a
claim that diagnostic Strings, Rc allocation or every legacy table operation
are completely admitted/recoverable. Graph traversal itself owns no storage;
object options do allocate the explicitly charged temporary key.

## Metadata and complete bootstrap ledger

Install getRootNode after nodeValue/textContent and before hasChildNodes. Keep
normalize, isSameNode and contains in order. Add one object to initial arena
reservation and one key slot to Node prototype order capacity. Final own-key
inventory is 27: two attributes, five operations, eighteen constants,
constructor, then tag under Reflect.ownKeys grouping. Physical preconstant
order is tag, nodeValue, textContent, getRootNode, hasChildNodes, normalize,
isSameNode, contains. Sorted preconstant keys are contains, getRootNode,
hasChildNodes, isSameNode, nodeValue, normalize, textContent, tag.

Constant guards become exact eight/three owners, completed maps 26/21, order
capacities 27/21. Keep valid distinct owner IDs, exact borrowed key/order checks,
all original descriptors and Native handles, current eighteen-key sorted
permutation, strict actual-key checks and direct unadvanced Vec collection.
Quota/refusal stages remain before both mem::take calls. Both completed maps
remain local until success; post-consumption invariant failure discards the
private initializer. No reusable rollback or recoverable BTree/sort OOM claim.

N26 remains height one with two overflows (items 12 and 24) and four allocated
nodes. The rightmost leaf now has two entries, so final repair transfers three
pairs instead of N25's four, with no allocation. Retain the existing 64 repair
bound, 32 navigation, 32 headers and full 48-entry sort scratch. Three passes
of 25 comparisons at full 42-unit keys cost 3,150; structure costs 624. Map cost
is 3,774; owner guard is 740. Constructor remains 3,030 + 300. Prototype's
increase over 3,630 + 652 is 232; total constant batch becomes 9,428 work. Typed
batch storage becomes `14820 + 18K + 143E + 7B`, one E above N25. The pinned
proof is specific to Rust 1.88/1.98 and these guarded ascending sizes.

The function factory costs 127: object/order 9, name text 30, length key/property
29, name key/property 31, full native name 28. Owner getRootNode insertion at
old count three costs 78: text 30 plus property 48. Moving later operations by
one slot adds 15 for hasChildNodes, 11 for normalize, 12 for isSameNode and 10
for contains. The new installer pays four. Constructor insertion at old count
25 versus 26 retains the same comparison/movement/node bounds and adds zero.
Total bootstrap increment is `127 + 78 + 48 + 4 + 232 = 489` work.

Use K=sizeof(PropertyKey), E=sizeof((PropertyKey,Property)),
B=16*(K+sizeof(Property))+32*sizeof(usize)+64, S=sizeof(ScriptObject),
A=sizeof(Option<AbortSlot>), D=sizeof(Option<f64>), N=sizeof(Native).
The new function costs `952 + A+D+N + 2K+B`; its owner key/property costs 408.
Initial object arena adds S; prototype order adds K; constant buffer adds E.
All other old allocations remain cumulative. Added bootstrap bytes are exactly
`1360 + (S+A+D+N) + 3K+B+E` under the unchanged helper formulas.

The predicate context actually measured 8,807 remaining work and 1,755,715
charged bytes, with 685 objects/capacity. This plan conditionally predicts 8,318
remaining work and 686 objects/capacity. Previous 64-bit type observations
K=16, E=72, B=1472, S+A+D+N=304 imply 3,256 additional charged bytes and a
predicted 1,758,971 total. These candidate values are hypotheses, not observed
counters. Native registry 321 and legacy prototypes 25 should remain unchanged.
Measure before modifying descriptive assertions. Numeric quotas, reset sites,
native representation, wire formats and process authority remain unchanged.

## Private and independent witnesses

Freeze independent literal cases/control pairs before execution; their author
owns their expectations. The current plan requires these private witnesses:

1. Dynamic raw bootstrap report; exact/one-short installer admission, updated
   eight/three guards and identity/order tests for all five moved operations.
   A full N26 batch refusal must not consume either old map.
2. Measured default body work cuts, including all cuts of a multilevel tree;
   Document debug snapshot, node capacities and metadata stay unchanged. With
   no options object the direct body must need no heap, including a full arena
   with a small unrelated path.
3. Invocation-level measured work/heap exact and one-short checks, preserving
   saved Native identity and cleaning frames/calls/eval_depth/stack_units. An
   object dictionary adds the real key allocation; default calls do not.
4. Invalid receiver before poisoned dictionary Get; valid receiver with every
   primitive versus omitted/nullish options. No coercion hooks run. An abrupt
   options getter wins over a malformed parent link that traversal has not read.
5. All represented object-like dictionary paths: inherited getter with original
   receiver and one invocation, function/array/native, DOM host, Window, Style,
   ClassList and Event native composed accessor. No own-only shortcut or
   enumeration. Explicit `{}` observes Object.prototype.composed; omitted,
   undefined and null do not. Restore descriptors in disposable realms.
6. Noncoercive Boolean values, especially objects with throwing conversion
   hooks. Both true/false traverse ordinary roots; default/undefined selection
   and ignored extra expression effects remain exact.
7. Getter moves source, moves an ancestor, clears a former parent, or replaces
   the method; the result uses fresh links. A getter moves then throws an
   identity marker; both identity and movement survive.
8. Nested saved root calls inside a getter share current author budget. Measure
   cuts during Get, after mutation before Boolean/traversal and at final return.
   Retain completed callback effects; terminal Resource suppresses catch/finally
   according to the existing entry policy. No work/heap reset or rollback.
9. Fresh Document/public parent alias and private Node(root) return canonical
   Value::Document; all leaf roots return retained IDs without allocating.
   Connected, detached, fragment, coherent Document-parent Text, ordinary
   template children and nested separate content fragments remain distinct.
10. Build reciprocal snapshot links directly to prove accepted 256-edge depth;
    raw append has a stricter setup boundary. Assert actual edges before the
    snapshot. Add a genuine 257th malformed host edge separately.
11. Dangling IDs, missing/duplicate membership, self-parent, reciprocal cycle,
    childful leaf, parented fragment/Document, wrong Document ID and corrupt
    non-Document root-ID return each refuse explicitly without method mutation.
    A wide-parent scan terminally refuses without returning a partial root.
12. Unrelated arena count/payload growth leaves local costs unchanged except
    explicit structural bounds. Poisoned public parent/host/shadowRoot getters
    remain untouched; no template host-inclusive ancestry leaks through true.
13. Two live realms retain independent method metadata and mutable prototype
    bags. Browser Page/worker witnesses remain independently authored; root
    reads cause no dirty/layout hook, while explicit existing moves do.

## Historical inventories and affected paths

Keep node-constants.js, node-normalize.js and node-predicates.js byte-exact.
Extend the disposable old constants wrapper to remove five later operations
and the old Normalize wrapper to remove four. Replace only the current private
predicate full-inventory registration with a clearly named disposable wrapper
that removes getRootNode, invokes the unchanged body and restores the saved
descriptor. Restoration preserves value/flags but not creation order; discard
that realm. New independently authored cases must check pristine 27-key order.
Update the small source-authored Node-data order assertion explicitly.

The held predicate fixture has one two-mode full-inventory body and one
two-mode positive/wrong order-control pair. Their source predicts two additional
case losses and four unhealthy controls when getRootNode is installed; preserve
actual raw outcomes and verify them rather than assigning success. Existing
Node and Normalize inventory failures remain historical, without broad control
health claims. No other old case is wrapped or silently edited.

Anticipated runtime changes: script.rs module; new node_root.rs and tests;
node_predicates.rs helper visibility plus its one private inventory wrapper;
node_data.rs dispatch; dom_prototypes.rs reservation/order/install;
node_constants.rs and tests; node_normalize/tests.rs and node_data/tests.rs;
exact new independent fixture. Bootstrap descriptive files change only after
measurement. DOM production, machine/calls.rs and cssom/css logic need no edits.
ShadowRoot construction/composed host traversal, Proxy/BigInt, Attr/CDATA/XML
trees, adoption across documents and broad allocation/realm correctness remain
unavailable prerequisites, not passing coverage.
