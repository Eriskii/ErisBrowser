from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
P=Path(__file__).resolve().parents[1]
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD=Path('/tmp/eris-node-predicates-preparation-1/replay')
OUT=P/'replay'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ready=json.loads((P/'independent/source-ready-2.json').read_text())
for row in ready['files']:
 p=Path(row['path']);assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
assert (P/'root/plan-review.json').is_file()
OUT.mkdir();history=[]
def copy(p,rel):
 dest=OUT/rel;assert not dest.exists();dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 history.append(dict(origin=str(p),copy=str(rel),bytes=dest.stat().st_size,sha256=sha(dest)))
for directory in ['independent','root','runtime','layout']:
 for p in sorted((P/directory).rglob('*')):
  if p.is_file() and not p.is_symlink() and '__pycache__' not in p.parts:
   copy(p,p.relative_to(P))
for name in ['test262_conformance.py','html_conformance.py','import_test262.py']:
 assert (R/'tools'/name).read_bytes()==(OLD/'tools'/name).read_bytes()
 copy(OLD/'tools'/name,Path('tools')/name)
for rel in ['tests/fixtures/node-constants.js','tests/fixtures/node-normalize.js','tests/fixtures/node-predicates.js']:
 copy(R/rel,Path('history')/Path(rel).name)
for name in ['source-ready.json','replay.py','replay-matrix.json','replay-inputs.json']:
 copy(OLD/name,Path('history/prior-replay')/name)
# Retain the exact production and helper inputs named in the proposals, including
# source paths that the eventual implementation may change. Data only.
manifest=json.loads((P/'runtime/source-inputs.json').read_text())
for row in manifest['source_files']:
 p=Path(row['path']);assert sha(p)==row['sha256']
 source_root=Path('/tmp/eris-node-predicates-1/worktree') if p.is_relative_to(Path('/tmp/eris-node-predicates-1/worktree')) else R
 rel=p.relative_to(source_root);assert sha(R/rel)==row['sha256']
 copy(p,Path('history/base-source')/rel)
fixture=OUT/'independent/cases.js';fixture_sha=sha(fixture)
assert fixture_sha=='65e3b34ac5b80a095d59505ab8693ec22b26225ae9d7f3408163070593ed6af3'
inv=json.loads((OUT/'independent/inventory.json').read_text());ctrl=json.loads((OUT/'independent/controls.json').read_text())
assert len(inv['cases'])==16 and inv['collection']=='nodeRootCases' and len(ctrl['controls'])==8
assert set(re.findall(r'^  ([A-Za-z0-9_]+): function\(\)',fixture.read_text(),re.M))==set(inv['cases'])
inventory=dict(fixture='independent/cases.js',fixture_sha256=fixture_sha,collection=inv['collection'],cases=[dict(name=name,modes=['sloppy','strict'],expected_observation=inv['ordinary_expectation']) for name in inv['cases']],controls=ctrl['controls'],case_modes=32,control_modes=16)
(OUT/'replay-inputs.json').write_text(json.dumps(inventory,indent=2)+'\n')
original=(OLD/'replay.py').read_text()
changes=[('Frozen Node predicate observations','Frozen Node root observations'),('nodePredicateCases','nodeRootCases'),('node-predicates.js','node-root.js'),('119b41f4a50a0a3de691c172ffe053d80f88ec6a7339764603e19b9dd02bf909',fixture_sha)]
driver=original
for before,after in changes:
 assert before in driver;driver=driver.replace(before,after)
reverse=driver
for before,after in reversed(changes):reverse=reverse.replace(after,before)
assert reverse==original
(OUT/'replay.py').write_text(driver)
(OUT/'preparation-history.json').write_text(json.dumps(history,indent=2)+'\n')
commands=[]
for option in ['--prepare','--verify']:
 args=['python3',str(OUT/'replay.py'),option];x=subprocess.run(args,capture_output=True,text=True)
 record=dict(command=args,exit=x.returncode,stdout=x.stdout,stderr=x.stderr);commands.append(record)
 assert x.returncode==0,record
(OUT/'inert-verification.json').write_text(json.dumps(dict(engine_run=False,compiler_run=False,commands=commands),indent=2)+'\n')
result=dict(status='Frozen source-reviewed ordinary root replay; inert matrix checks passed, no engine',location=str(OUT),location_must_remain_fixed=True,ordinary_bodies=16,ordinary_modes=32,control_pairs=4,control_modes=16,total_rows=48,history_copies=len(history),driver=dict(path=str(OUT/'replay.py'),sha256=sha(OUT/'replay.py')),matrix=dict(path=str(OUT/'replay-matrix.json'),sha256=sha(OUT/'replay-matrix.json')),fixture_sha256=fixture_sha,supervision='Exact previous driver except four reversible identity substitutions; ERJS1/ERJR2,3s,96KiBstdout/64KiBstderr,4MiBrequest,exclusivefreshreport,pre/postbindings,same-mode positive controls. Inherited directchild supervision; no new whole-process-tree claim.',baseline='Root has not executed baseline or any candidate engine.',files=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.rglob('*')) if p.is_file()])
(OUT/'source-ready.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='files'},indent=2))
