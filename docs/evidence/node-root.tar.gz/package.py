import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((BASE/p).read_text())
def checked(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def totals(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(x[i]) for x in rows) for i in range(3)]
assert totals('full-default-188-1')==[1837,0,0]
assert totals('full-native-198-1')==[1960,0,0]
source=read('candidate-source-final.json');assert len(source['files'])==18
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'held-source-final'/row['path'])
docs=read('documentation-ready-2.json');assert len(docs['files'])==12
for row in docs['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'documentation-final'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(BASE/'candidate-source-final.json')
comparison=read('root-comparison.json');assert not comparison['validation_failures'];s=comparison['summary']
for kind,count,unchanged,losses in [('cases',4268,4266,2),('controls',476,472,4)]:
 row=s['established'][kind];assert row['before_total']==row['after_total']==count and row['unchanged']==unchanged and row['losses']==losses
 assert row['gains']==row['other_changes']==0
for kind,count,before in [('cases',32,0),('controls',16,4)]:
 row=s['new'][kind];assert row['before_total']==row['after_total']==row['after_healthy']==count
 assert row['before_healthy']==before and row['gains']==count-before and row['unchanged']==before
 assert row['losses']==row['other_changes']==0
classification=read('inventory-classification.json')
assert classification['comparison_sha256']==sha(BASE/'root-comparison.json')
ci=read('probe-fix-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
assert read('independent-results-review-2.json')['status']=='clear'
summary=dict(
 kind='Represented ordinary Node roots after observable options conversion',base_commit=source['base'],
 scope='Ordinary cached Node.prototype.getRootNode; authentic receiver, optional dictionary with one composed Get for object options, fresh ordinary parent links after callbacks, canonical Document identity and separate template roots. No ShadowRoot representation.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-1','clippy-native-198-1','clippy-presenter-188-1','full-default-188-1','full-native-198-1','release-adapter-188-1']},
 tests=dict(default=1837,native=1960,new_groups=32,focused=read('focused-validation-review.json'),final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False,full_test_threads=4),
 accounting=dict(remaining_bootstrap_work=8318,allocated_bytes=1758971,objects=686,object_capacity=686,native_entries=321,legacy_prototype_entries=25,additional_work=489,additional_charged_bytes=3256,bootstrap_work_limit=100000,author_work_limit=100000,cumulative_heap_limit=8388608,numeric_limits_and_resets_changed=False),
 compatibility=dict(path='root-comparison.json',sha256=sha(BASE/'root-comparison.json'),summary=s,inventory_classification=dict(path='inventory-classification.json',sha256=sha(BASE/'inventory-classification.json'),report=classification)),
 retained_history=[
 'Initial all-target compilation and all32newgroups passed. Initial bootstrap filter retained27passes/two stale descriptive snapshot failures. Exactly three literals across two test files changed after measurement; initial16implementation paths remain unchanged.',
 'Data-only correction preparation first named raw instead of the actual reference local; assertion stopped before any source change or compiler. The error and original first file remain retained.',
 'Initial data audit could not count two interleaved nocapture status lines. The failed audit remains retained; the corrected reader reassembles only two exact fragments under the immutable raw-log SHA, preserving all raw bytes and both failures. No engine rerun.',
 'Before baseline execution, independent fixture metadata case gained a successful authentic alternate-constructor prerequisite. Original and final fixtures, readiness and exact correction remain retained; controls and expected inventory unchanged. Candidate baseline then retained32missing-method TypeErrors and4/16healthy controls. No candidate compiler had run.',
 'Candidate retains nonzero Nodeconstant, Normalize and Predicate historical profile exits and aggregate exit. Twelve older Node/Normalize unhealthy inventory observations remain byte-exact; two Predicate inventory cases newly fail with Error and four controls become unhealthy with TypeError. No fixture rewrite or health waiver.',
 'The predecessor predicate commit6834288 had8successfulCIjobs/1Vulkanprobe failure from reading a disappeared proc entry. Separate Python test-helper correction066435f has9successfulCIjobs; Runtime source unchanged. Both receipts remain retained.'],
 boundaries=[
 'Represented ordinary node tree only; no ShadowRoot/composed ancestry, cross-document adoption, XMLDocument/CDATA construction or remaining Node methods.',
 'Options getter mutations and throws preserve completed effects. The walk validates reached local shapes and reciprocal ordinary parent membership up to256edges/257visits. It does not validate the whole graph or traverse template hosts.',
 'Default traversal owns no heap storage; object options separately allocate a paid24work/96byte literal composed key and retain actual lookup/callback charges. Existing invocation name-copy, generic VM and diagnostic String allocation remain; no complete allocation or physical allocator recovery claim.',
 'Page and confined-worker real-click witnesses retain20IDs without new click nodes, follow receiver/ancestor moves and retained detachment, and check literal whole-canvas/style/text results with distinct template and unhosted fragment trees.',
 'No page/GPU/physical-memory performance measurement. Full web compatibility, production security and requested Chromium performance threshold remain unachieved.'])
with (BASE/'result.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','target','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p.is_symlink() or name in {'eris-js','final-publication-review.json'}:continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/node-root.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
p=ROOT/'docs/evidence/node-root.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
