import hashlib,json,os,subprocess,time
from pathlib import Path
H=Path(__file__).resolve().parent
R=H.parent/'worktree'
env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
label='format-198-1';args=['cargo','+1.98.0','fmt','--all','--','--check'];p=H/(label+'.log');start=time.monotonic()
with p.open('xb') as f:r=subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT)
record=dict(command=args,exit=r.returncode,elapsed_seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
with (H/(label+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True)
if r.returncode:print(p.read_text()[-10000:]);raise SystemExit(r.returncode)
for args in [
 ['clippy-native-198-1','1.98.0','Cargo.toml','vulkan-raster','clippy','--all-targets','--','-D','warnings'],
 ['clippy-presenter-188-1','1.88.0','Cargo.toml','vulkan-presenter','clippy','--all-targets','--','-D','warnings'],
 ['full-default-188-1','1.88.0','Cargo.toml','-','test','--','--include-ignored','--test-threads=4'],
 ['full-native-198-1','1.98.0','Cargo.toml','vulkan-raster','test','--','--include-ignored','--test-threads=4'],
 ['release-adapter-188-1','1.88.0','Cargo.toml','-','build','--release','--bin','eris-js']]:
 r=subprocess.run(['python3',str(H/'check.py'),*args],cwd=R,env=env)
 if r.returncode:raise SystemExit(r.returncode)
