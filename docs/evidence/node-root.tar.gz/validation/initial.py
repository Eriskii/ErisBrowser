import subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
for args in [
 ['compile-188-1','1.88.0','Cargo.toml','-','test','--no-run'],
 ['root-188-1','1.88.0','Cargo.toml','-','test','node_root','--','--include-ignored','--nocapture']]:
 r=subprocess.run(['python3',str(H/'check.py'),*args])
 if r.returncode:raise SystemExit(r.returncode)
