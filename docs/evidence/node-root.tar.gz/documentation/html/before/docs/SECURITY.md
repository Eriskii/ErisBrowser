# Security boundary

**This is experimental software. It has not had a professional security audit and should not be used for sensitive browsing.** Native browsing uses a fresh confined Linux renderer per document and a separate resource broker when resources are needed. This is a concrete isolation layer, not evidence of production security, complete site isolation, or a complete web-origin model. The `--render` and `--benchmark` CLI modes, conformance adapters and public library API do not install this sandbox. `--benchmark-worker` exercises the confined renderer/broker and validated snapshot path, with the same fail-closed Linux requirements as native browsing.

The optional Linux Vulkan presenter runs a graphics driver on a dedicated thread
inside the privileged native browser process. This is not GPU process isolation.
The upload route accepts completed CPU pixel frames; the optional native raster
route accepts bounded plans prepared from validated display lists. It receives
no page shader source. It limits active/pending frames and counts application pixel-buffer
capacities, while driver staging, swapchains and internal allocation remain
outside that ledger. A five-second application deadline cannot interrupt a
native call or destructor. Timeout or thread panic never authorizes a competing
software surface; fallback requires an acknowledgment after actual resource
drops return. Feature-enabled worker launches use an isolated exec-only stage
that marks all non-stdio descriptors close-on-exec before replacing itself with
the worker. It validates the internal role, requires single-thread startup and
handles no page data. Parent descriptors remain unchanged. This handles both
transient loader files and retained driver handles; a graphics/spawn mutex was
insufficient. Worker startup still rejects every unexpected descriptor that
survives exec before handling page content. Driver crashes
can still affect the browser process. The renderer,
broker and image-decoder sandbox policies are unchanged. See the
[Vulkan boundary](vulkan-rendering.md#isolation-resource-ownership-and-recovery).

## Native process boundary

The UI retains the window, address bar, clipboard, trusted bundled fonts and software painter. A renderer child runs HTML/CSS parsing, scripting, same-origin image decoding and layout. A separate broker child performs resource loading; the parent relays its bounded responses and records the broker's final document URL. Each cross-origin image is decoded in a fresh third child which exits after one response. All children start with a cleared environment and reject inherited descriptors other than stdin/stdout/stderr and the temporary procfs inspection handle. Inspection failure rejects startup.

The renderer, broker and image decoder require fully enforced Landlock ABI 6 and `no_new_privs` before processing page data. **The renderer has no filesystem read/write/execute grants and cannot create any socket.** TCP connect/bind is also denied by its Landlock policy. It receives document and authorized resource bytes only through the parent-controlled pipe. Cross-origin image decoders use the same zero-file-grant, zero-socket policy. Metadata observations such as some pathname/stat operations are not fully mediated by these filesystem access rules.

Date timezone discovery uses a separate helper with parent-supplied host
configuration, no page input, a cleared environment, inherited-descriptor
checks, and CPU/address-space/descriptor/core limits. This helper has host
filesystem authority and is not the confined renderer. It pins a regular file,
checks identity and metadata around a bounded read, and returns at most 1 MiB of
timezone data. Named zones stay beneath the selected zone root. The renderer
revalidates the payload after confinement and before author scripts; it gains
no filesystem capability. Unsupported, missing, unspecified or leap-bearing
rules cause an initialization error rather than an invented UTC offset.

A persistent supervisor owns at most one pending spawn, active helper or
unreaped helper. Capture has a one-second caller deadline; worker discovery
also bounds contention waiting to one second and checks navigation cancellation.
Cleanup kills the owned process group before releasing PID identity. A blocked
OS spawn or uninterruptible cleanup can outlive the caller deadline, but retains
the busy state and prevents another helper from accumulating. This is a bounded
ownership policy, not a guarantee that the kernel terminates a process promptly.
Normalized zone parsing has separate work and 4 MiB storage budgets. Date
conversion, inverse-timezone searches and formatting use shared script work and
allocation accounting; budget errors remain uncatchable by author code.

The broker grants read access to the explicitly opened local document's canonical parent directory (if any), exact resolver files, and system library trees (`/lib`, `/lib64`, `/usr/lib`, `/nix/store`). It grants no filesystem write or execute rights, and remote documents receive no local directory grant. General outbound IP access remains available to this process for DNS and HTTP/TLS; TCP listeners and Unix sockets are denied. Broker compromise is therefore a different, broader boundary than renderer compromise. The broker does not parse HTML, run scripts, or decode images.

A shared seccomp denylist blocks process/thread creation, new executables, io_uring, namespace/process-group changes, socket pairs, System V shared memory/semaphores/message queues, POSIX message queues, selected process-inspection/privileged interfaces, changes to process scheduling/limits, and filesystem metadata mutations that Landlock does not mediate. Limit queries remain allowed. `ioctl` is limited to nonblocking-mode and bytes-available requests. Wrong syscall architectures and x86-64 x32 are rejected. Signals outside the sandbox and external abstract Unix sockets are additionally scoped by Landlock. This is not a complete syscall allowlist. Procfs must be mounted; unsupported setup fails closed, with no in-process native fallback.

The broker accepts exactly one parent-authorized document URL and form body. Subresources use the committed response URL as their initiator; the renderer cannot supply or broaden it. Scripts and styles are restricted to that origin, with the same check at every redirect. Cross-origin images pass through a fresh confined decoder; the renderer receives validated pixels, the originally requested URL and an origin-taint flag. Raw response bodies, headers, status and final redirect URLs are withheld. All native image-load failures use a fixed generic error, including failures after redirects. A decoder is never reused between images, so a compromised decoder cannot retain state to inspect a later response from another origin. The trusted broker records taint across every redirect hop; returning to the document origin does not remove it. Data images remain supported. This boundary does not implement full Fetch/CORS or Canvas security APIs; no script API currently exposes image pixels. HTTP(S) document redirects can cross origins, while HTTPS downgrades remain blocked. The UI checks snapshot URLs against the broker's exact committed document URL, allowing fragment changes.

The versioned, length-prefixed IPC protocol checks counts, frame sizes, UTF-8, aggregate text/raster storage, DOM namespaces and attribute bindings, parent links, detached subtrees, cycles, depth, hit targets, finite geometry and raster dimensions before a snapshot reaches the UI. ERWA preserves reciprocal template/fragment ownership and includes those edges in cycle/depth checks. Text, Comment and PI data now carry a tag for scalar UTF-8 or exact UTF-16; the decoder checks counts, checked byte sizes, remaining frame, shared DOM allowance and canonicality before payload allocation. Fully scalar content in a UTF-16 payload and older protocol versions are rejected. PI targets remain UTF-8. The independent EWB1 raster format is unchanged. Document modes, canonical encoding names, selected base nodes and frozen base URLs are also validated. Clip, fixed-coordinate and opacity commands share a typed scope stack: cross-kind closures, unclosed scopes and combined depth above 128 are rejected. Opacity values must be finite and between zero and one. Hit regions carry validated document/fixed-coordinate flags and typed ordinary/generated-summary actions. Generated-summary hints require an active, visible HTML details element without a direct authored summary; forged activation commands fail the worker channel closed. Namespace metadata must name existing attributes before its entries are allocated. Image aliases share one transmitted raster. Resource response headers, status and byte lengths have separate bounds. Decoder response frames are limited to the remaining aggregate image budget before allocation; geometry and exact RGBA length are checked again. Raster and SVG dimensions are checked against the remaining pixel budget before allocating their output. The request queue holds at most 64 items and the UI mailbox one snapshot. Task state is a validated three-value enum; the parent rejects pending or suspended task metadata when it authorized scripts to be disabled. Idle task continuation waits at least 16 ms after its previous rendered snapshot and gives queued native input priority; cancellation and transaction deadlines apply to task commands too. Nonblocking pipe I/O has deadlines; navigation/shutdown cancellation also reaches a stalled broker exchange. Cleanup kills and reaps renderer, broker and any active image decoder. Image decoders are also reaped after each successful response.

Linux address-space, descriptor and core-dump limits apply separately to every child. The UI has no global hard memory cap. Its painter still handles untrusted validated drawing commands and pixels, with its own work limits. The broker uses synchronous DNS because thread creation is denied; the parent deadline can terminate a stalled lookup. Headless/library fetches retain the HTTP library's timed resolver. There is no complete private-network protection or independent sandbox audit.

## Implemented controls

The standalone [Vulkan development probe](../tools/vulkan-probe/README.md) uses
host device/driver access with fixed synthetic pixels and no page content. It
does not change the browser's dependency graph or renderer authority. Its finite
process deadlines and output bounds are test controls, not a GPU sandbox or a
hard limit on driver allocations. Native driver calls and teardown can outlast
application waits. The optional browser presenter has the additional ownership
and launch controls described above; neither path is a GPU sandbox.

The separate [custom raster probe](../tools/vulkan-raster-probe/README.md)
accepts only its fixed synthetic rectangle/image fixtures. It validates the
whole input before Vulkan initialization, owns immutable planned data, and
checks every source's dimensions and exact RGBA length even when unused or
hidden. Source count and aggregate bytes are checked before packing, which occurs
once per source; bounded axis tables preserve CPU sampling. Source alpha blends
in ordered GPU passes over opaque RGB. Transparent images still consume their
planned dispatch and sampling-table budgets, and no CPU alpha scan skips them.
The output, readback, metadata and optional image arena share a 1 MiB explicit
GPU-buffer limit. Ordered passes and shader range checks protect this bounded
subset; driver/device/pipeline allocations and upload staging are outside that
sum. Its offscreen pixel checks establish neither GPU process isolation nor
production browser security, and it changes no browser renderer authority.

- The application forbids unsafe Rust. Parser, layout, interpreter, and software-paint code are custom Rust. Platform/codec/crypto dependencies have their own security surface and may use unsafe code.
- Script code cannot call host filesystem, networking, process, clipboard, native eval, or FFI APIs. Native clipboard access is initiated only by explicit user keyboard shortcuts. Unsupported features produce errors. Scripts have DOM access within the current page.
- The script interpreter bounds source, tokens, grammar continuation storage/work, logical calls, native recursion, instructions and allocation accounting. Per-page script count/source are also capped. Template text scanning, parser-directed rescans, substitution coercion and output copying consume compile/runtime budgets; template expressions use the shared execution driver and coercion callbacks retain native guards. Owned executable names and parser lists are charged during direct flat construction; functions share immutable code and retain conservative activation metadata allowances. Generic array reversal and radix conversion retain shared work/heap/coercion limits. Long-lived pages can exhaust its arena; there is no garbage collector. Quota termination is a distinct, uncatchable error and cannot be bypassed by finally blocks. Native callbacks, constructors, events and JSON traversal share a weighted nesting budget. Iterative JavaScript uses precharged continuation storage, with all invocations sharing the logical-call ceiling.
- HTML and DOM operations bound source/node count, depth, text/attribute storage and mutation. Script-driven moves charge host-inclusive subtree and ancestor traversal, sibling scans and fragment transfers before mutation; removals charge sibling scans. Selectors and style resolution have explicit work limits to contain pathological matching and expansion.
- HTML encoding changes use at most one cached-byte reparse before author execution or subresource requests. Template contents stay outside document queries/resource discovery until inserted; fragment transfer and cloning share DOM depth/storage limits. Neither templates nor strict JavaScript are security isolation boundaries.
- Layout bounds visits, depth, measured text, output commands and coordinate extents. Grid shares and interns computed track lists, with a cap on unique retained track data. Whitespace scans and tokenization consume a source-work budget that discarded measurements cannot refund. Fragments share one hit-allocation budget. Deferred positioning and stacking share a work limit; reconstruction reserves scope closures and removes hits for commands beyond its paint cutoff. Paint limits cumulative raster work and rejects invalid geometry and image buffers.
- Stylesheet imports retain the committed document authority, preserve separate parse boundaries and bound recursion, count, source bytes, repeated scan work, URL resolution and cache storage. Media conditions and imported layer identities are separate metadata, so stylesheet contents cannot close a generated wrapper. Anonymous layer identities cannot collide with authored names. URL accounting includes repeated cache lookups and failed-resource keys. Media evaluation bounds input, alternatives, leaf terms and delimiter nesting, with recursive conditions consuming both a local work cap and shared stylesheet parsing work. Every valid branch is checked even when its truth value could short-circuit. Cascade layer names, depth and rollback candidates have explicit limits. Script base mutations charge scanning and URL work before mutation. Frozen base metadata never grants an origin or local directory.
- Event paths, listener traversal/snapshots, inline handler compilation and recursive dispatch consume script work/allocation/stack budgets. Readonly event state is stored in private slots; synthetic dispatch cannot make an event trusted. AbortSignal state and listener IDs share allocation limits; abort reserves complete listener-removal work before changing observable state. Ordinary listener exceptions are reported; resource termination remains uncatchable and clears dispatch state.
- Feature queries use bounded grammar and a conservative positive syntax inventory; invalid condition syntax and exhausted query budgets remain invalid through negation. False import conditions are checked before fetching or registering a layer. Matching and selector queries share bounded token grammar, preserving comment and whitespace distinctions. Undeclared named namespace prefixes and exhausted query budgets invalidate the complete condition. Compiled selector/index records have an 8 MiB accounted storage cap; byte scans and recursive serialization consume shared work before growth.
- JavaScript `CSS.supports` shares script instruction, allocation and coercion limits. UTF-16 conversion and parser scratch reserve proportional work/storage before allocation. The two-argument overload parses its value separately from its literal property name, preventing argument text from becoming a different condition. Extra arguments are not coerced by this API; selected author conversions run before query-size rejection. Resource failures remain uncatchable, and repeated probes consume the existing cumulative arena.
- Custom-property substitution tokenizes before expansion, bounds active resolution and fallback nesting, and charges output copies before growth. Computed maps share inherited values and retain an aggregate storage cap. Cycles invalidate active participants, while unused fallbacks are not traversed. After a result becomes invalid, later references still perform bounded dependency lookup without repeatedly scanning discarded cached values. These bounds contain expansion and repeated-scan costs; incomplete ordinary-property parsing remains a compatibility limitation.
- Window property-descriptor queries read tracked global binding records without invoking their getters or exposing lexical bindings. Definition of self, globalThis, undefined, NaN and Infinity uses ordinary descriptor compatibility checks; other host definitions remain unsupported. Key conversion retains author side effects and exceptions, while property lookup, storage and accessor calls share the script budgets. Exact UTF-16 matching prevents malformed keys from aliasing those five names. Replacing public globalThis does not change the runtime's private Window identity or event targets. These operations add no cross-origin WindowProxy or host access authority.
- Inline CSSOM operations finish ordered author conversions before parsing current DOM state. They reserve parser/serialization scratch, share script work and allocation limits, and stage one final attribute write. Escaped names and value-token boundaries prevent a serialized record from injecting or consuming adjacent declarations. Recursive calc validation consumes shared work. Resource failures terminate the entry before the staged write; earlier author side effects are retained. This is bounded parser/runtime behavior, not complete CSSOM conformance.
- Computed property references retain raw keys until their specified read/write point, then use bounded string-hint conversion and cache the resulting UTF-16 key. Compound operations cannot repeat author key conversion during their final write; exceptions and quota failures retain the existing execution limits.
- Functions and defaults share flat executable units across closures and calls, while retaining conservative per-closure/per-activation metadata allowances and charging environment bindings. Initialization and body execution share the same driver, work, logical-call and cumulative allocation allowances; native helpers retain the weighted stack guard. A default cannot reset those limits; resource termination stops later initializers and body execution. Parameter/lexical conflict checks use a charged name set instead of repeated full parameter scans.
- Additive length-percentage calculations retain finite coefficients and percentage dependency without per-style syntax trees. Original tokens are validated before comment normalization and after variable substitution; consumed arithmetic tokens spend shared work. Context-specific clamping happens after resolution. Grid track interning includes both coefficients and the dependency flag, and accounts for the larger track representation.
- The parser directly builds flat executable expression, statement and function records with typed IDs. Record pages, parser lists, names/operators, copied payloads and publication share the compile ledger and use checked reservations. Completed and partial syntax have no owning child links; abandoned cover-grammar records remain charged tombstones. Closures retain their whole unit, including otherwise unreachable code, and carry it across callbacks. The old owning AST/lowering path is test-only. Supported JavaScript grammar uses precharged flat continuations, including saved function contexts and pending defaults/templates. Frame slots derive from the shared compile storage budget; source, token and work limits remain. The old grammar-depth and member/constructor chain guards are removed; active labels, declaration traversal and the separate RegExp compiler retain their own limits. The ledger is cumulative without refunds and is not a proof of total process memory: diagnostic formatting, allocator overhead, runtime arenas and native helpers still need broader accounting. This stage does not establish production security.
- Expressions, references, statements, ordinary activation, defaults and bound forwarding use one runtime-owned continuation vector. Frame capacity and relocation work are precharged; the slot ceiling derives from the existing 8 MiB allowance divided by the record size. Queued invocations acquire their logical count after a successful push; native callback roots preserve their externally owned count and guard. Cleanup restores the current frame boundary and counters without allocating or running author code. Ordinary exceptions reach try continuations; resource/unsupported host errors bypass catch/finally. Code handles avoid copying identifier names and body lists, while array/argument payloads and bound forwarding buffers are precharged. Constructors and native callback bridges retain weighted recursion guards. Fully iterative JavaScript no longer consumes native-depth units; all calls still share the 32-call ceiling. Refused charges remain in the cumulative ledger. These controls do not establish complete runtime allocation accounting or production security.
- Declaration-name collection and runtime hoisting use a fixed array of 96 borrowed ancestor cursors. Cursor movement and empty switch-case lists consume shared work, and traversal errors are terminal. This removes their native recursion and switch-body syntax cloning without raising parser or execution limits. Declaration-name validation now precharges borrowed record growth, merge scratch, copies, UTF-8 comparisons and named diagnostics. This covers scope, for-head, parameter and catch-name validation; it is not complete parser or runtime map accounting.
- Identifier lexing uses static Unicode tables with two bounded table reads. Initial scanning and parser-directed suffix rescans share one cumulative compile ledger; token pages, decoded names, provisional diagnostics and charged syntax copies consume that allowance. Page descriptors may move during growth; existing token pages do not. The parser borrows source only during compilation; executable units own flat records and string data. Escapes cannot turn a decoded name into a literal keyword terminal. Compile resource failures remain uncatchable, and discarded provisional tokens do not refund work or storage. These lexical rules add no runtime authority and do not establish a security audit.
- Identifier rest parameters reserve copying work and estimated array/bookkeeping storage before allocating or retaining the remaining actual values. They create ordinary interpreter arrays without invoking author iterators, global constructors or inherited setters. Empty rest arrays also consume the cumulative runtime allowance; defaults and rest construction share the calling entry's limits.
- Prototype membership reads internal links iteratively, charging each visit against shared work and the existing 96-link guard. It invokes no author getters or coercion hooks to discover a chain. Primitive arguments return before receiver boxing; cyclic or overlong internal graphs terminate with an uncatchable resource error.
- Array sorting uses a bounded value list and iterative merge over precharged index buffers. Every collection, comparison and copy consumes the caller's work/heap allowance; author comparators and conversions retain shared recursion guards. Inconsistent comparators cannot prevent cursor progress. Sorting writes begin after collection/comparison, while later write/delete failures preserve earlier successful effects. Callback mutations are not rolled back. The existing 65,536 array-like length cap does not promise completion below that size.
- Disclosure groups and coalesced toggle records are bounded by the DOM node inventory. Group/tree mutation work is charged before script-driven changes. One host checkpoint dispatches at most 64 toggle records under a shared instruction budget. Exact reentrant tracking permits at most two live records per element, counting the single active task, with a separately bounded tracker map. Checkpoint failure preserves unstarted tasks and suspends automatic retry until document replacement, so an exhausted persistent script arena cannot cause idle polling. Ordinary listener exceptions retain existing reporting behavior. Closed content retains document activity but cannot receive native editing; snapshots revoke newly hidden edit focus. This is a rendering/input policy, not an origin or script isolation boundary.
- Opacity surfaces are deferred until a clipped nonzero-alpha pixel needs them, then allocated under separate peak/cumulative byte caps. Initialization and compositing consume shared paint work; unfinished surfaces are dropped on invalid streams, allocation failure or quota exhaustion. Opacity never disables hit testing by itself.
- RegExp parsing and matching share script work/allocation budgets. Backtracking uses an explicit bounded stack; assertions and callbacks retain nesting guards. Quota failures remain uncatchable.
- Network loading checks every redirect, caps redirects, has request/page time budgets, limits resource counts and both encoded and decompressed response sizes. TLS certificate validation stays enabled.
- HTTPS downgrade redirects and HTTPS-to-HTTP subresources are rejected. URL credentials and unsupported schemes are rejected.
- Remote pages cannot read or navigate to local files. Explicitly opened local documents may load files only beneath their canonical parent directory; symlinks escaping that directory are rejected. The native broker additionally receives the OS filesystem policy above; the renderer cannot open files directly. Headless/library paths use application checks only, and neither path is certified against every concurrent local filesystem race.
- Styles and scripts are conservatively restricted to the document origin. Script/style MIME types are checked. Cross-origin native images use the isolated opaque-pixel path described above; headless/library fetches decode them in the calling process. There is no credential store.
- When a Content-Security-Policy header or meta policy is present, scripts, author styles and external resources are disabled. Header CSP is also enforced by the broker for subresources; meta policies and script/style execution are enforced in the renderer. This intentionally conservative fallback is **not a CSP implementation**. It rejects content that a compliant browser would permit.
- Decoded raster images have dimension limits and a retained pixel budget. PNG metadata limits are installed before decoder construction. WebP preflight checks container/frame dimensions before the codec can allocate inner VP8 planes. Codec scratch storage is not fully described by the retained pixel budget; native process memory caps remain part of the boundary. SVG has separate source, element, geometry, work and image bounds; SVG scripts/external resource references are not executed.
- Page-worker requests and pending snapshots are bounded. Navigation generations prevent stale page results from receiving new user input. Edit acknowledgements keep old results from overwriting newer typing. Password fields are masked and native copy/cut shortcuts do not expose their values.

The [shared enumeration follow-up](../tests/conformance/own-keys.md) replaces
full-name snapshot deduplication with integer ranks and the object's existing
unique-name creation order. Virtual keys, dense-hole searches, sorting and caller
buffers now consume shared work/storage allowances. For-in visited names now use
[UTF-16 length buckets](../tests/conformance/for-in-length-buckets.md): a charged
integer lookup selects the inner tree, whose full-text work remains bounded by
its reached size. Cached entries preserve live descriptor checks and hidden-property
shadowing. Node movement and cumulative storage are prepaid, including the extra
outer nodes and inner-map headers. Shapes with many distinct lengths can consume
more heap allowance. Both insertions are charged before publishing a new bucket;
refusal leaves membership unchanged. No quota is raised.
The [original finding](../tests/conformance/array-from-enumeration-followup.json)
and four first-candidate control regressions remain recorded.

This closes the identified shared string-key snapshot/visited-tree accounting
work, not every property path. General live own-descriptor/map/Get/prototype,
mapped-binding and JSON accounting remain open. Window, symbol-key and integrity
snapshots use separate unchanged paths. Standard-library tree insertion still
has no fallible reservation API; the cumulative node charge is not whole-allocator
OOM recovery or a proof of total process memory. Existing quotas do not establish
complete accounting or production security.

[Splice](../tests/conformance/array-splice.md) adds scoped precharges for its
live string/symbol/native lookups, parameter maps and borrowed formal-name
environment searches. Bounds derive from the reached tree size and the supported
B=6 tree layouts. Dense and creation-order vector growth pays relocation work
and full new-buffer storage before mutation. Short numeric deletion keys bound
comparisons against retained names; Array shrink reuses the shared charged key
snapshot and pays its remaining deletion/retention work. No logical-length
output buffer is reserved, and no quota changes. Partial writes remain visible
on failure; terminal limits bypass author catch/finally and restore internal
call/frame state. These are scoped logical charges, not allocator telemetry.
Shared constructor/callback internals, general property/JSON accounting and
whole-allocator failure recovery remain separate work. See the
[unchanged limits](../tests/conformance/array-splice-limits.json) and
[validation evidence](../tests/conformance/array-splice-integration-validation.json).

[Concat](../tests/conformance/array-concat.md) reuses the scoped charged species,
symbol/named-property, Has/Get, definition and strict length paths. It borrows
arguments and keeps constant-size loop state; every reached item and index,
including holes, consumes shared work. Its thirteen private groups check lookup
precharges, mutation prefixes, heap cutpoints, cumulative work, host boundaries,
cycles and terminal cleanup. The public >2^32 hole walk reaches the existing
budget before the final Array length RangeError; private seeded-state tests
cover that later boundary. Two ordinary upstream 4,000-hole modes also reach
the work limit and remain reported as resources. No limit or policy was relaxed,
and no new regression gate masks these outcomes. General constructor/callback/
property/JSON accounting and allocator recovery remain separate work. See the
[unchanged limits](../tests/conformance/array-concat-limits.json) and
[validation record](../tests/conformance/array-concat-validation.json).

[ArrayBuffer](../tests/conformance/array-buffer.md) stores non-shared backing
bytes in private records separate from ordinary object properties. Numeric
record lookup, metadata growth, zero initialization and copying consume the
existing script budgets. Reservations pay full new storage and relocation work;
shrinking, replacement and detachment do not refund cumulative allocation.
Record indices survive author callbacks, but no backing borrow crosses one.
Resize prepares growth before publishing it, slice validates both buffers before
writing its surviving source range, and transfer detaches only after destination
allocation and copying succeed. Earlier author effects remain visible on error.

Absolute backing feasibility reuses the unchanged 8 MiB heap ceiling. An initial
length above it throws `RangeError` after prototype lookup and object creation,
before attempting allocation or charging nonexistent zero-fill work. Resizable
maximum feasibility is checked after initial backing allocation; storing a
maximum does not allocate that capacity. Otherwise feasible requests still face
the unchanged terminal work and cumulative heap limits. Twenty-four private
groups cover byte contents, reentrant callbacks, allocation/copy boundaries and
cleanup. DataView now uses narrow copied-metadata and at-most-eight-byte backing
operations. Stable opaque buffer handles cross callbacks; backing borrows do not.
View bounds are rechecked after conversions, and complete writes are prepaid
before their first byte changes. Record growth pays full requested new storage
and movement. Intrinsic installation builds final descriptors with cached vacant
entries, retaining explicit search, structural, node and order-buffer charges.
Twenty-eight private DataView groups cover codec literals, exhaustive binary16
boundaries, callback effects and exact/one-short work/storage admission.
Typed-array access, BigInt codecs, shared memory, foreign realms and host
detachment remain absent. These scoped checks do not establish general arena
accounting, allocator recovery, total process-memory bounds or production security.

[Object.is](../tests/conformance/object-is.md) compares borrowed operands without
property access or conversion callbacks. Equal-length UTF-16 comparisons prepay
their traversal; native identity keys are compared iteratively under the same
work budget. Its early dispatch avoids scanning ignored receiver/extra-value
payloads, while ordinary evaluation and forwarding keep their own charges.
The scoped installer prepays node and order-buffer costs before publication,
retaining the existing ordinary allocation charges. Twenty private groups check
exact/one-short admission, full-heap comparisons and terminal cleanup. Existing
limits and maximum-string regressions are unchanged. Generic infallible allocator
boundaries remain explicit. The later [DOM follow-up](../tests/conformance/dom-method-identity.md)
addresses defining-interface methods; complete host identity and Web IDL
conformance remain unestablished.

[Checked script insertion](document-append.md) now validates appendChild and
Document/Element/DocumentFragment.append before their raw DOM mutations. Invalid
hierarchies throw DOMException; implementation depth, work and storage refusals
terminate script execution. [Exact append strings](append-domstrings.md) admit
the chosen scalar or exact-unit storage before creating nodes, preventing silent
truncation on this path. Conversion callbacks and
earlier temporary-fragment moves remain observable after later failures.
All argument conversions complete before append materializes separate Texts.
Each canonical payload, logical node and actual typed arena growth is paid before
its publication; fragment growth remains after Text materialization. Later
refusals retain earlier detached Texts and completed fragment moves. Removed
lossy temporaries are not allocated, and cumulative charges are not refunded.
The raw insertion child vectors, B-trees and base URL/encoding/IDNA internals
retain their existing infallible-allocation and temporary-accounting limits.
[Document.title](document-title.md) separately prepays incremental selection,
normalized direct-Text reads and narrow empty-title creation/insertion. A later
refusal preserves the completed creation/insertion prefix. Host projection has
a finite bound derived from document limits; author quotas and reset points are
unchanged. Existing-target replacement retains the Node helper's allocation
limitations.
The parser's internal insertion path is unchanged. This does not add arbitrary
cross-document adoption, mutation observers or complete DOM allocation recovery.

[DOM own properties](dom-own-properties.md) share lazy string/symbol storage keyed
by the actual host identity. Reads and missing deletions allocate no bag. New
descriptors and bag entries become visible only after work/storage admission and
reservation; descriptor conversion runs before live validation. Accessors receive
the original host object after internal borrows end. The private storage object
does not expose a new prototype or admit host integrity operations. These checks
cover the reached own-property paths, not general host allocation recovery.


[DOM interface prototypes](dom-prototypes.md) use eagerly admitted interface
records and ordinary mutable metadata bags. Private cached bag IDs do not alter
native function identity. Node brands still depend on authentic node identity
and kind, independently of mutable prototype membership. Text, Comment and
DocumentFragment constructors finish argument conversion and new-target
prototype access before checking live document capacity and reserving retained
storage. An alternate prototype is published only with its successful node;
ordinary own-property bags remain separate. Text and Comment now use the
[exact data builder](dom-production.md) after conversion and prototype callbacks,
then move one admitted canonical payload into checked owned storage. Work limits
and cumulative heap limits are unchanged; the existing bootstrap object
reservation remains charged in full.

[ProcessingInstruction and CharacterData](processing-instruction.md) accessors
check genuine receivers before conversion. Creation validates converted targets
and data after new-target callbacks, then checks live document limits before
publishing nodes or alternate prototypes. The scoped JavaScript data producers
classify the complete UTF-16 stream and allocate either one scalar UTF-8 payload
or one exact UTF-16 payload. PI targets keep their separate XML Name validation
and scalar storage. Replacement admission subtracts the previous payload and
refuses excess input without truncation or an outer data write. Existing
infallible Rc and B-tree allocations remain.

The five [CharacterData methods](character-data.md) finish argument conversion
before reading live node data. Substring traverses only the reached code units
and admits the selected UTF-16 result before allocation. Mutations prepay the
old-length pass and complete-splice classification, then reserve and emit the
chosen scalar or exact-unit payload. The Units path also pays its separate
canonicality validation. Fresh replacement admission precedes allocation and is
rechecked at publication. A terminal refusal leaves the outer write unpublished;
earlier author effects and cumulative temporary-allocation charges remain.

[Node data accessors](node-data.md) check authentic receivers before nullable
conversion, including setters whose node kind ignores the converted value.
Container replacement takes the runtime's actual remaining-work and cumulative
heap counters; both counters return on success and failure, retaining every
consumed charge. No nested allowance or temporary-allocation refund is granted.
The replacement validates current children, stages affected base/details work
and admits its final child vector and arena growth before detaching anything.
No callback, fallible reservation or Resource decision follows the start of
commit. A refused outer write preserves earlier conversion effects.

Detached children and their descendants remain retained, so their bytes are not
credited to a new Text. Empty assignment requires no new node slot, while its
actual removal costs still apply. Map operations have conservative logical
charges, but B-tree allocation remains infallible. Existing URL/encoding/IDNA
internals also allocate infallibly; their inherited work allowance and
retained-result charge do not meter every temporary allocation. Staging these
operations before tree mutation does not establish process-OOM recovery or
exact process-wide memory accounting.

The [DOM string foundation](dom-strings.md) retains one canonical payload, with
UTF-8 byte charges for scalar strings and two bytes per stored UTF-16 unit for
nonscalar strings. Detached nodes count toward the unchanged 32 MiB DOM ledger;
snapshot admission recomputes it. Exact reads prepay traversal and output copies;
empty and single-Text containers avoid arena-sized scratch. Display replacement
is explicit and does not mutate storage. Nonscalar inline script and JavaScript
HTML serialization fail explicitly; oversized HTML output now reports resource
failure instead of silently omitting later pieces. A textarea with nonscalar
aggregate data cannot enter or retain the scalar native editor, including during
a pending acknowledgement. These are bounded interfaces, not universal
allocation recovery or complete exact-string browser support.

## Representative limits

[Runtime construction](runtime-budget-boundary.md) has a separate fixed work
allowance. A successful bootstrap grants the returned runtime one fresh author
allowance; failure grants none. Heap accounting remains cumulative. Existing
script and host-event entry resets are unchanged, and nested callbacks share
the current allowance.

| Resource | Bound |
|---|---:|
| Individual fetched/decompressed resource | 8 MiB |
| Aggregate fetched page data | 32 MiB |
| Resource fetches | 48 |
| Redirects per fetch | 8 |
| Encoded form request body | 1 MiB |
| HTTP request timeout | 12 seconds; native DNS also bounded by the parent transaction deadline |
| Entire fetch sequence | 30-second page budget, including redirects |
| DOM nodes / parsed nesting | 100,000 / 256 |
| DOM retained text/attribute accounting | 32 MiB |
| Unique computed Grid track data | 4 MiB per style computation, plus shared defaults and bounded interning metadata |
| Additive calculation input / nesting / terms | 4 KiB / 16 / 256, within shared token and work budgets |
| Script source / tokens | 256 KiB / 32,768 |
| Script entry instructions / hard call-depth cap | 100,000 / 32 |
| Runtime bootstrap instructions | 100,000, separately charged before author execution |
| Shared execution nesting | 96 weighted units; calls cost 4, other guarded nesting costs 1 |
| Script cumulative allocation accounting | 8 MiB |
| ArrayBuffer absolute backing/max-length feasibility | 8 MiB; remaining script work and cumulative allocation limits also apply |
| Disclosure notifications per host checkpoint | 64, sharing one 100,000-step budget |
| Individual script string | 262,144 UTF-16 code units / 512 KiB backing units |
| Script tags / aggregate script source | 64 / 1 MiB |
| RegExp pattern units / syntax nodes / captures | 8,192 / 4,096 / 128 |
| Stylesheet decoded / constructed / repeatedly scanned source | 8 / 8 / 32 MiB per load |
| Supports condition bytes / terms / nesting | 16 KiB / 64 / 16 |
| Supports local work / shared import-query work | 256 KiB / 8 MiB |
| CSS.supports combined UTF-8 argument bytes / property bytes / value bytes | 16 KiB / 256 / 4,096, also subject to shared script limits |
| Inline CSSOM source/serialized allowance / declaration records | 64 KiB / 256, also subject to shared script limits |
| Inline CSSOM property-name bytes / value bytes / component depth | 256 / 4,096 / 16 |
| Retained custom-property names per element / name bytes / authored value bytes | 128 / 256 / 4,096 |
| Expanded custom value / active resolution or component nesting | 64 KiB / 16 |
| Aggregate retained custom-property maps | 8 MiB accounted names, values and entry overhead; inherited maps/strings share storage |
| Stylesheet import attempts / retained segments / depth | 256 / 256 / 16 |
| Inline stylesheet collection: count / copied text / direct-child visits | 256 / 8 MiB / 200,000 per collection |
| Import prelude / media condition delimiter nesting | 128 |
| Media-query input / alternatives / conjunctive features / nesting | 64 KiB / 64 / 64 per query / 16 |
| Stylesheet URL work / retained URL cache data | 32 / 32 MiB per load |
| Page subresource URL resolution work | 32 MiB per load |
| Frozen base URL metadata | 32 MiB, separate from general IPC string limit |
| Image dimensions / image decode allocation | 4096 per axis / 64 MiB |
| Retained decoded page images | 64 MiB |
| Emitted layout text / font size | 500,000 Unicode scalars / 512 CSS pixels |
| Layout whitespace scanning and text tokenization | 500,000 shared, non-refundable scalar visits |
| Grid tracks per axis / participating items | 256 / 4,096 |
| Shared Grid placement and sizing work | 2,000,000 charged operations per layout |
| Shared positioning/stacking work | 2,000,000 charged operations per layout |
| Layout hit inventory / final commands / combined clip-fixed-opacity depth | 100,000 / 200,000 / 128 |
| Opacity offscreen peak / cumulative allocated pixels | 64 / 128 MiB (8,388,608 / 16,777,216 RGBA16 pixels) per paint |
| Event path targets | 258, with shared script work/allocation/nesting limits |
| CSS layers / layer depth / registered names | 1,024 / 16 / 64 KiB |
| Expanded stylesheet declarations / direct declaration list | 16 / 1 MiB of names and values |
| Cascade candidate entries / text per element | 4,096 / 1 MiB, with shared cascade work |
| Headless or window framebuffer | 16 megapixels, 8192 per axis |
| Pending page-worker requests / snapshots | 64 / 1 |
| Native IPC request / response frame | 18 MiB / 128 MiB |
| Native startup / load / other transaction deadlines | 5 / 40 / 15 seconds |
| Each native child: address space / open descriptors / core dump | 1.5 GiB / 128 / 0 bytes |

Limits can reject valid documents, and not every allocation is covered by exact accounting. Only native renderer, broker and image-decoder children have these OS address-space limits. User-supplied public library structures can be mutated outside the checked APIs; incoming native snapshots undergo separate validation.

## Symbol storage and callbacks

Symbol identities use retained safe-Rust handles; descriptions do not identify keys.
Registry lookup/scans, key lists, descriptive strings, function names and custom
object tags share the existing work/allocation ledger. Refused registry entries
and property insertions are not published. Primitive/instance hooks share native
and script guards; looping or recursive callbacks cannot catch quota exhaustion.
Diagnostic console formatting charges Symbol description scanning and UTF-8
storage before formatting. Supported DOM operations use checked JavaScript string
conversion separately.

The [Symbol validation record](../tests/conformance/symbol-properties.json)
includes exhaustion and unwind checks. Quotas are unchanged. The registry belongs
to the current page Runtime; shared multi-realm behavior is unimplemented.
This remains estimated accounting, without an independent security audit.

## DOM conversion callbacks

Supported DOM methods check their receiver and required arguments before invoking
author conversion hooks. Variadic append/class-list arguments are converted before
their operation; callbacks may themselves mutate the DOM. Title and class-list
lookups observe that live state. Host conversion charges scans and worst-case
UTF-8 storage before decoding. Staged arguments, token parsing/deduplication,
vector growth, serialization, query scratch and native method handles share the
existing ledger. No quota increased.

Eight defining-interface query/append methods reject a mismatched receiver before
required arguments or conversion hooks. Their metadata, getter wrappers, row
searches and temporary native call-name copies are prepaid. A refused name copy
still releases the call's stack ownership; prior author effects remain on later
conversion failure. Distinct mutable metadata bags share only immutable strings.
The earlier method checkpoint prepaid a 512-slot object-arena reservation.
The interface installer now prepays 673 slots before initialization, avoiding
later bootstrap growth. This is reserved capacity, not a new object
limit. Logical requested-byte accounting excludes allocator rounding and retains
the existing infallible B-tree/Rc allocation boundaries.

The browser, adapter and stress tool now use [fallible runtime construction](runtime-initialization.md).
Checked bootstrap failures discard the partial realm and propagate to the host.
Worker initialization errors bypass error-page construction, emit one bounded
error reply when the channel is writable, and terminate. Ordinary document
errors still get one fallible error-page attempt. Convenience constructors remain
panicking APIs, and existing infallible allocator paths are not converted into
recoverable errors. Successful initialization accounting and execution reset
points are unchanged.

The [focused validation](../tests/conformance/dom-string-conversion.json) includes
allocation refusals and looping/recursive callbacks that cannot catch resource
exhaustion, with execution-state cleanup checked afterward. These checks do not
establish full DOM operation atomicity or exact process-wide memory accounting.
Some legacy conversion paths covered by that historical record still replace
unpaired units. [Exact character-data production](dom-production.md) migrates the
named constructors, factories, data setter and five methods.
[Node data assignment](node-data.md) also preserves exact units through
`nodeValue`/`textContent`, and [append](append-domstrings.md) preserves separate
string arguments. [Document.title](document-title.md) uses the same exact
builder and checked replacement after conversion and current-tree selection.
Legacy `innerText`, textarea setters, attribute and
HTML-parser writes and scalar host boundaries
remain separate work.

## Window binding reflection

Window binding reflection now precharges snapshots, name scans, UTF-16 key copies,
both output vectors and sorting work. Sorting allocates no additional buffer;
vector reservations are fallible. The binding ledger includes each creation serial,
and serial exhaustion rejects a new property before publication. Descriptor and
membership queries do not invoke author getters or expose global lexical bindings.
The [reflection checks](../tests/conformance/window-reflection.json) cover refused
storage/work and counter exhaustion; quotas remain unchanged. The later
[general binding work](../tests/conformance/window-global-bindings.md) also charges
private receiver slots, declaration selection maps, UTF-16 property records and
key conversions. Author `this` properties cannot replace execution receivers.
Getter/setter callbacks share existing limits and unwind on uncatchable resource
errors. Event-handler descriptor/deletion behavior, full interface reflection and
WindowProxy semantics remain incomplete.

## String concatenation

[String.prototype.concat](../tests/conformance/string-concat.md) precharges a
fallibly reserved fragment vector, copying work, output buffer and Rc conversion
storage. Cumulative UTF-16 length is checked after each argument conversion;
callbacks share existing instruction, allocation and recursion limits. Abrupt
conversions retain earlier author effects, and resource failures unwind without
running catch/finally recovery. This changes no script authority or quota. The
ledger remains estimated; the checks do not establish production security.

## Constructor execution state

[Constructor targets](../tests/conformance/construction.md) use private environment
slots charged to the existing heap ledger. Array-like and bound argument storage
is checked and prepaid before reservation/copying; the argument cap and native
stack guards remain in force. Getter callbacks and construction share runtime
work, heap and recursion limits. Resource failures bypass script recovery and
unwind continuation/call counters. These changes add no filesystem, network or
GPU authority. The [Symbol target correction](../tests/conformance/constructor-policy.md)
allows Symbol as an allocation target without installing Symbol value slots on
an ordinary object. Argument callbacks still share the existing limits, and
Symbol construction throws before description conversion. The ledger remains
an estimate, and no independent audit is claimed.

## Remaining work

Stronger syscall confinement and complete opaque-response semantics; headless and cross-platform process isolation; complete origin/opaque-origin handling; Fetch/CORS/CSP and navigation policy; cookie/storage partitioning; mixed-content/private-network protection; permissions; verified dependency vulnerability monitoring; continuous coverage-guided fuzzing; sanitizers and cross-platform hardening; independent audit. The [CSP standard](https://www.w3.org/TR/CSP3/) describes substantially more behavior than the fallback above.

The current syscall filter targets little-endian x86-64, AArch64 and RISC-V64 Linux; only x86-64 has been validated here. Native startup fails on other architectures. System resolver configurations requiring Unix-socket services may be incompatible; ordinary DNS over IP remains available. The `seccompiler` wrapper is an additional dependency and its [upstream repository](https://github.com/rust-vmm/seccompiler) is archived; it has not been independently audited here.

The [Linux Landlock documentation](https://docs.kernel.org/userspace-api/landlock.html) describes both enforcement and remaining syscall/metadata limitations. These controls must be evaluated together with the implementation and its actual regression tests; an enabled sandbox is not a security audit.

Report reproducible issues with a minimized local fixture and command. Avoid including real cookies, passwords, private URLs, or other secrets in reports.

Dynamic ordinary Function compilation parses parameter and body inputs separately
and charges the active runtime's remaining work and cumulative allocation budget
on success and failure. No dynamic compile calls the top-level entry point that
resets instructions. Generated closures use the global environment; conversion
callbacks and prototype getters retain existing nesting guards. The existing CSP
fallback still disables all scripts for a policy-bearing page. Literal unpaired
UTF-16 source surrogates are explicitly unsupported pending lossless parser input;
no lossy replacement is used. See the [tests and limits](../tests/conformance/function-constructor.md).

Generic String conversion, `Symbol.match` classification and custom `Symbol.split`
dispatch invoke ordinary getters/callbacks under the existing shared runtime
limits. Split-hook argument storage is charged before calling author code.
Recursive getter/conversion/hook regressions verify resource exhaustion and
counter/frame cleanup; a heap-exhausted split cannot invoke the hook. No quotas,
dependencies or process authorities change. See the [coverage and limits](../tests/conformance/string-conversion.md).

The [RegExp split follow-up](../tests/conformance/regexp-split.md) runs species,
flags, execution and capture callbacks under the same resource guards. It charges
flag assembly, constructor arguments, substring copies and result growth; the
private result array cannot expose intermediate values to inherited setters.
Tests cover recursive callbacks, unbounded capture lengths, backward-moving match
indices, heap refusal and frame cleanup. No complete allocation-accounting or
independent security-audit claim follows from these checks.

The [RegExp constructor follow-up](../tests/conformance/regexp-constructor.md)
keeps classification, prototype lookup and ordinary conversion callbacks within
the current runtime guards. Object/index-property allocation is charged before
conversion; successful and failed parses retain their compiler charges. Tests
cover work cutoffs, exact charge transfer, recursive getters and construction,
caught syntax-error loops, heap refusal and cleanup.

The [flat regexp parser](../tests/conformance/regexp-deep-groups.md) replaces native
group/prefix recursion with budgeted heap frames. Pattern, node, repetition,
shared work and cumulative heap limits remain; capture storage is bounded by
these limits instead of a separate 128-capture ceiling. Frame and list backing
allocations are charged before reservation, including replacement allocations.
The separate native lookahead execution guard remains enforced. Tests cover
2,000 nested groups on a 128 KiB thread stack and failure/cleanup paths. Four
deep-group resource modes now pass; four work-budget stops remain visible.

[Required-literal rejection](../tests/conformance/regexp-required-literals.md)
now avoids backtracking when the input lacks necessary literal occurrences.
Its temporary analysis records have four fixed entries per bounded AST node,
charged before allocation. Scanning uses fixed storage and the shared work
budget; arithmetic saturates and assertions/backreferences add no requirements.
Tests preserve full captures against the unfiltered VM and exercise allocation
refusal, scan exhaustion and zero VM allocation for rejected inputs. Two XML
modes now pass; two full-UTF-16 script-loop stops remain. This optimization does
not remove the need for budgets or establish complete allocation accounting.

The [match/search protocols](../tests/conformance/regexp-match-search.md) keep
custom hooks, flags/input conversion, execution and index access within the
existing callback guards. Invocation arguments and private result-array growth
are charged; inherited setters cannot intercept own match-result elements.
Tests cover recursive callbacks, unbounded custom exec results, allocation
refusal before the first global exec, and clean frame unwinding. Array.prototype indexed descriptors now use the shared property implementation. These
checks do not establish complete allocation accounting or audited security.

[String lastIndexOf](../tests/conformance/string-last-index-of.md) searches borrowed
UTF-16 slices without allocating a search buffer. Every candidate comparison is
charged before matching. Receiver/search/position callbacks retain the shared
work, allocation and recursion guards. Tests verify comparison refusal, adversarial
work exhaustion and cleanup after recursive conversion. The naive scan can stop
at the existing work limit; no quota is raised and no new process authority is
granted. This does not establish linear-time search or complete allocation accounting.

[Array lastIndexOf](../tests/conformance/array-last-index-of.md) reuses bounded
property lookup and safe-integer key creation. It allocates no collection from
logical length, charges each visited index/prototype edge and uses strict
equality with charged string comparisons. Author getters and conversion hooks
share the existing guards. Recursive callbacks, huge sparse scans, refusal before
index getters and cleanup are tested. Sparse array storage now separates logical length from occupied elements;
no quota or process authority changes.


[Array descriptors and methods](../tests/conformance/array-descriptors.md) store
logical u32 lengths independently of dense cached elements and sparse property
records. A length increase allocates no absent elements; shrinking visits actual
own indices and preserves valid length/storage after an uncatchable resource
stop. Indexed getters, length conversion and method callbacks use the existing
work, cumulative allocation and recursion budgets. Tests cover refusal before
storage changes, interrupted shrink invariants, recursive conversion, method
callback allocation, cyclic-join cleanup and persistent document suspension.
JSON key snapshots still preflight storage proportional to logical length;
sort/reverse retain their 65,536-element limits. No quota or process authority
was increased. Bounded independent code inspection found no concrete defect;
it does not constitute a security audit or complete allocation accounting.

[Array every and some](../tests/conformance/array-predicates.md) reuse the live
array-method property path. Each visited index and prototype edge consumes
shared work and scratch allowance; callback arguments are precharged before
invocation. They create no result array or collection proportional to logical
length. Length conversion, indexed getters and callbacks retain the existing
recursion and cumulative allocation guards. Focused tests check refusal after
getter effects but before callback execution, recursive paths, terminal sparse
scan exhaustion and frame cleanup. Four retained upstream sparse-scan modes
reach the work limit. No quota, exception policy or process authority is
broadened, and earlier author effects are retained on failure. These checks
do not establish complete allocation accounting or production security.

[Object integrity operations](../tests/conformance/object-integrity.md) use a
dedicated own-key snapshot with work and heap charges before key materialization,
vector allocation and in-place sorting. Sparse logical gaps do not create keys.
Flag inspection avoids accessor calls, mapped-value reads and allocation of
virtual boxed-string character values. Already-compatible flags need no new
descriptor record. Changed properties use the shared definition path; mapped
argument binding names are borrowed and their actual scan lengths are charged.
The initial nonextensibility change precedes key collection, and successful
property changes remain visible if a later definition or quota check fails.
There is no rollback promise for the whole operation. Queries and repeated
calls share the caller's existing cumulative limits, and unsupported host
receivers are rejected explicitly. Quotas, exception policy and process
authority are unchanged. Fifteen private test groups cover exact refusal before
allocation, partial array and argument updates, actual binding-name work,
sparse logical lengths, virtual-string flags, host sidecars and terminal
shared-budget cleanup. Both supported Rust toolchains and release configurations
pass the integrated checks; 15,000 mutation cases report no caught panic or
invariant failure. These checks do not establish complete allocation accounting
or a security audit.

[Array find methods](../tests/conformance/array-find.md) stream captured logical
indices without allocating a proportional list. Holes still cause live reads
and predicate calls. Index keys, per-edge scratch and the three callback
arguments are precharged before allocation or invocation. The shared array
property walker now accounts for comparisons against retained property,
parameter and hole trees, plus intrinsic-name lookup. Mapped argument reads
borrow the binding name and charge its actual length and environment lookup
bound before reading its value. These changes also protect existing consumers
of that walker.

Getters and callbacks run after the property read releases its storage borrow.
They share cumulative work, heap and recursion guards; completed author effects
remain when a later check fails. Huge sparse receivers can return on their
first visit, while long scans terminate at the existing budgets. A fixed
sixteen-digit index-formatting charge initially caused two older work-limit
regressions. Formatting now precharges actual digit work and fills that many
stack slots; the 64-byte allocation charge, lookup charges and all quotas
remain unchanged. Both older cases pass, with their initial records retained.

All 504 guarded local variants, thirteen private test groups and the final
integrated checks pass. Private tests cover refusal before callback storage,
completed getter effects, long mapped names, tree comparisons, lazy host/depth
boundaries and terminal cleanup. The 15,000-case mutation smoke reports no
caught panic or invariant failure. Exception rules and process authority
are unchanged. Bounded independent code inspection found no concrete defect. These
checks do not establish complete allocation accounting or a security audit;
the Vulkan driver boundary is unchanged.

The [Node constant batch initializer](node-constants-bootstrap.md) checks both
owners' exact shape and order capacity, prepays both completed maps and all
fallible vector reservations, then moves the existing descriptors. Both maps
remain private until completion. Quota failure precedes map consumption;
internal ordering failure afterward discards the private initializer without
publishing a reusable realm. Existing tree/order charges remain cumulative;
removing unperformed insertion allocations lowers bootstrap charges under the
same 8 MiB ceiling. Standard BTree/sort allocator failure is still outside
recoverable errors. The renderer's authority and execution reset sites do not
change.

[Text splitting](text-operations.md) validates its authentic receiver before
offset conversion, then reacquires current data and parent. Suffix creation,
local sibling insertion and original-prefix replacement admit work and storage
separately. Later refusal retains completed stages; future truncation is never
credited to suffix admission. Checked vector growth precedes link publication.
The local insertion helper preserves the existing maximum depth, Document-parent
snapshot admission and summary NodeId caches without broad metadata rebuilding.
`wholeText` pays bounded local sibling discovery and both exact-data passes, then
separately admits its temporary Vec and final Rc storage. Both helper outcomes
copy spent counters back. Numeric quotas, execution resets, IPC protocol and
process authority are unchanged. The tests cover quota refusals, not physical
allocator failure, a comprehensive graph validator or complete browser security.

[Node.normalize](node-normalize.md) validates authentic receivers, traverses
ordinary descendants and ignores extra arguments without coercion. It pays for
a bounded depth-first cursor, a reached-ID map and exact canonical run output;
unrelated arena entries are not scanned. Duplicate/link checks precede current
run replacement. The reached map includes prepaid comparison, growth and
cleanup allowances, but its standard BTree allocation still has an infallible
physical allocator boundary.

Survivor replacement and tail removal are separately admitted stages. Resource
termination can retain earlier removals, completed runs, or a merged survivor
with its tails still attached; final bookkeeping can refuse after all mutations
are complete. The removal helper prepays local validation, every detach and
the actual suffix compaction before a commit with no remaining allocation or
quota check. Both outcomes copy absolute spent counters back. Removed nodes and
their exact payloads remain in the arena and provide no future allocation
credit. Even a singleton nonempty run pays for its canonical replacement.

The operation creates no nodes, does not enter template content through a host,
and preserves base/summary Element identities without rebuilding metadata.
Each separate suffix shift is charged; overall linear complexity is not claimed.
The runtime supplies uniqueness immediately before the internal removal helper;
that helper is not a complete validator for arbitrary public Rust mutations.
Numeric limits, reset sites, process authority and wire formats are unchanged.
CDATASection/XMLDocument, live Range adjustments, observer records and custom
reactions remain missing; neither quota tests nor this implementation establish
complete memory accounting or production security.

[Node predicates](node-predicates.md) authenticate their receiver before checking
required nullable Node arguments. `isSameNode` and `contains` throw TypeError for
a missing argument; explicit null or undefined produces false. Non-node values
are rejected without authored
coercion hooks or property reads. JavaScript argument expressions still run before
invocation, and their tree effects are visible to these read-only methods. Saved
methods use internal IDs and links regardless of authored property shadows.

`contains` follows ordinary parent links, without entering template content
through its host. Each reached node and parent check is admitted before use;
each followed parent's complete child-ID membership scan is prepaid. Work grows
with reached ancestors and scanned siblings. A valid match at 256 edges is
accepted. Invalid local IDs, backlinks, duplicate membership, malformed leaves
or overlong chains refuse explicitly; self and null results need not audit
unreached links. This is a bounded local policy, not a general validator for
arbitrary Rust host mutation or ownership across unrelated Documents.

The three method bodies allocate no owned traversal or payload storage and do
not mutate the Document on success or refusal. Existing invocation-name copying,
VM allocations and diagnostic-string allocation remain separate; zero body
heap charge is not a whole-call allocation or recoverable-OOM guarantee. Wide
sibling scans can terminate on work admission, and the existing terminal
Resource behavior applies. Limits, reset sites, authority and wire formats stay
unchanged.

The adjusted constant initializer guards seven existing prototype entries and
three constructor entries. Its 25-entry prototype build admits two overflows
and four typed tree nodes on both pinned Rust versions, including all comparison,
sort-scratch and map-buffer charges. Both replacement maps remain local until
complete; quota refusals precede consumption, and a later invariant failure
discards the private initializer. Standard BTree/sort allocation remains
infallible at the process allocator boundary. Measured initialization consumes
1,392 additional work units and 11,214 charged bytes under unchanged quotas.
Full suites and admission tests pass. The release comparison retains the exact
historical inventory losses and unhealthy controls separately. These checks do
not establish complete allocation accounting or production security.
