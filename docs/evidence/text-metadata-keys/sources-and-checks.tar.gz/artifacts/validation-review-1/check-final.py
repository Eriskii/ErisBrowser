from pathlib import Path
import hashlib,json,difflib,subprocess
A=Path('/tmp/eris-text-metadata-keys-1'); W=A/'worktree'; O=A/'validation-review-1'
def bind(p):
 p=Path(p); d=p.read_bytes(); return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
def read(p):return json.loads(Path(p).read_bytes())
seen={}
def verify_refs(x):
 if isinstance(x,dict):
  if all(k in x for k in ('path','bytes','sha256')) and isinstance(x['path'],str) and x['path'].startswith('/'):
   v=bind(x['path']);assert v['bytes']==x['bytes'] and v['sha256']==x['sha256'],x['path'];seen[x['path']]=v
  for v in x.values():verify_refs(v)
 elif isinstance(x,list):
  for v in x:verify_refs(v)
ledger=read(A/'root/final-validation.json'); docs=read(A/'documentation-1/source-ready.json'); replay=read(O/'replay-checks.json')
verify_refs(ledger);verify_refs(docs);verify_refs(replay)
assert ledger['status']=='verified' and read(O/'rust-review.json')['status']=='clear'
assert ledger['resource_change']['native_registry_entries']==299 and 'native_metadata_bags' not in ledger['resource_change']
s=read(A/'source-final.json')['source_sha256'];p=read(A/'parent-source-extended.json')['source_sha256']
assert len(s)==1540 and len(p)==1538 and set(p)<=set(s)
assert sorted(k for k,v in s.items() if p.get(k)!=v)==ledger['changed_source_paths']
for k,h in s.items():assert bind(W/k)['sha256']==h,k
assert (A/'source-final.json').read_bytes()==(A/'source-candidate-extended.json').read_bytes()
assert len(ledger['changed_source_paths'])==10 and ledger['production_files']==2 and ledger['existing_test_migration_files']==6 and ledger['new_test_modules']==2
checked_docs=[]
for f in docs['files']:
 rel=f['relative_path'];old=Path(f['before']['path']).read_text() if f['before'] else '';new=Path(f['raw']['path']).read_text()
 patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if f['before'] else '/dev/null',tofile='b/'+rel))
 assert patch==Path(f['diff']['path']).read_text(),rel
 assert (W/rel).read_bytes()==Path(f['raw']['path']).read_bytes(),rel
 if f['before']:
  base=subprocess.check_output(['git','-C',str(W),'show',docs['base']+':'+rel]);assert base==Path(f['before']['path']).read_bytes(),rel
 assert 'PENDING_' not in new
 checked_docs.append(dict(path=rel,live=bind(W/rel),exact_selected_diff=True,published_before_join=bool(f['before'])))
assert len(checked_docs)==4
for r in ledger['retained_prior_rust_records']:assert Path(r['original']['path']).read_bytes()==Path(r['retained']['path']).read_bytes()
checks={'status':'clear','source':bind(A/'source-final.json'),'parent':bind(A/'parent-source-extended.json'),'ledger':bind(A/'root/final-validation.json'),'helper':bind(A/'root/finalize-validation.py'),'documentation_hold':bind(A/'documentation-1/source-ready.json'),'documents':checked_docs,'verified_bound_records':len(seen),'references':list(seen.values()),'execution':'Only inert stdlib file/hash/JSON/diff inspection and read-only git show. No project script, binary, compiler, engine or test executed.'}
(O/'final-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
rr={'status':'clear','scope':'Independent source-bound release and three-profile replay evidence review; no reruns.','source':bind(A/'source-final.json'),'replay_record':bind(A/'root/replay-validation.json'),'binary':replay['binary'],'checks':bind(O/'replay-checks.json'),'checker':bind(O/'check-replays.py'),'conclusions':{'complete_case_records_equal_parent':842,'complete_per_profile_harness_records_equal_parent':254,'distinct_control_name_mode_pairs':replay['distinct_control_name_mode_pairs'],'baseline_changes':0,'profile_results':[{'profile':v['profile'],'cases':v['cases'],'controls':v['controls'],'counts':v['counts']} for v in replay['records']],'only_report_differences':['seconds','binary','binary_sha256'],'corpus_manifests_and_files_unchanged':True,'frozen_binary_equals_built_release':True},'qualifications':['254 counts per-profile control records; shared controls recur across profiles.','All controls verify and baseline comparison has no regression or improvement; existing failed and unsupported modes remain. This is not all-case conformance success.','Thirty failed modes are final-unhandled host-policy vetoes; two existing-profile modes report missing Proxy. No assertion-failure reinterpretation.','Build and replay observations belong to root execution; peer performed only inert evidence inspection.'],'findings':[]}
(O/'replay-review.json').write_text(json.dumps(rr,indent=2)+'\n')
fr={'status':'clear','scope':'Final AY source/ledger/release/replay/documentation review before evidence packaging and publication.','ledger':bind(A/'root/final-validation.json'),'finalization_helper':bind(A/'root/finalize-validation.py'),'source':bind(A/'source-final.json'),'source_peer':bind(A/'candidate-source-review-1/source-review.json'),'rust_peer':bind(O/'rust-review.json'),'replay_peer':bind(O/'replay-review.json'),'documentation_hold':bind(A/'documentation-1/source-ready.json'),'checks':bind(O/'final-checks.json'),'checker':bind(O/'check-final.py'),'documents':checked_docs,'conclusions':{'source_inputs':1540,'extended_parent_inputs':1538,'changed_paths':10,'production_files':2,'existing_test_migration_files':6,'new_test_modules':2,'new_groups':5,'private_operations':16,'parent_groups':{'passed':1,'intended_failures':2},'default_distinct_passed':3089,'default_ordinary_passed':2965,'default_ordinary_ignored':124,'default_complement_passed':124,'default_complement_filtered':2965,'host_vulkan_include_ignored_passed':3443,'full_result_rows_each':51,'selected_old_test_renames':2,'strict_and_format_receipts_clear':True,'work_saved':60,'accounted_heap_saved':336,'raw_startup':99786,'remaining_startup_work':214,'native_registry_entries':299,'exact_case_records':842,'exact_per_profile_harness_records':254,'baseline_changes':0,'live_docs_equal_frozen_raw':True},'resolved_findings':[{'finding':'The first final ledger labelled the 299-entry native registry as native metadata bags.','resolution':'Regenerated selected ledger and helper use native_registry_entries; value and production source unchanged.'}],'qualifications':['Default 3089 is the disjoint union of the ordinary and explicitly ignored-only commands, not one zero-ignored invocation. Host/Vulkan uses include-ignored.','All five new groups and two selected old boundary-name changes reconcile with the preserved old harness rosters; held assertions and 16 private operation expectations remain unchanged.','Finalization helper is a ledger assembler, not an independent replacement for the bound source, raw-log/roster and complete-report checks. Its corrected clippy-msrv-1 filename is bound; root reports its initial wrong-filename attempt stopped before ledger creation.','The initial formatting inventory expected two changed files; actual three formatting-only files are retained and explained without changing implementation or assertions.','The 177-input inventory extension binds unchanged published-parent literal inputs. Two Text fixtures were bound before baseline; remaining175 were retrospective evidence-only. The selected1540 map is not a complete build graph; earlier ledgers/archives remain unchanged.','The three release replay arrays preserve failed and unsupported outcomes. Authenticated completion and final-unhandled host policy remain distinct; no new upstream cases or full compatibility claim.','Four imported documents accurately describe mechanism, accounting, split-run validation and inventory limits. Their evidence-summary link is intended for the subsequent root-owned packaging step; this review does not verify an archive that has not yet been built.','No project execution or live source/documentation edits by reviewer. No timing, RSS, GPU, general security or Chromium comparison result inferred.'],'findings':[]}
(O/'final-review.json').write_text(json.dumps(fr,indent=2)+'\n')
print(json.dumps({'replay_review':bind(O/'replay-review.json'),'final_review':bind(O/'final-review.json'),'final_ledger':bind(A/'root/final-validation.json'),'verified_references':len(seen)},indent=2))
