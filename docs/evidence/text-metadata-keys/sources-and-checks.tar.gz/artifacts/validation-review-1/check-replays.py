from pathlib import Path
from collections import Counter
import hashlib,json
A=Path('/tmp/eris-text-metadata-keys-1');AX=Path('/tmp/eris-promise-race-upstream-1');W=A/'worktree';O=A/'validation-review-1'
def b(p):
 x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()}
def verify(v):
 d=b(Path(v['path']));assert (d['bytes'],d['sha256'])==(v['bytes'],v['sha256']),v['path']
def canonical(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=True).encode()).hexdigest()
r=json.loads((A/'root/replay-validation.json').read_text());identity=json.loads((A/'eris-js-host-final-1.json').read_text());assert r['binary']==identity
verify(identity);verify(identity['source_inventory']);verify(identity['build_receipt']);verify(r['source'])
assert b(A/'target-msrv/release/eris-js')['sha256']==identity['sha256']
assert Path(identity['path']).read_bytes()[:4]==b'\x7fELF'
assert (A/'source-final.json').read_bytes()==(A/'source-candidate-extended.json').read_bytes()
inv=json.loads((A/'source-final.json').read_text())['source_sha256'];parent=json.loads((A/'parent-source-extended.json').read_text())['source_sha256']
assert len(inv)==1540 and len(parent)==1538
for p,h in inv.items():assert b(W/p)['sha256']==h,p
build=json.loads(Path(identity['build_receipt']['path']).read_text());assert build['exit']==0 and build['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--features','test262-host','--release','--bin','eris-js'];assert b(A/'validation'/build['log'])['sha256']==build['sha256']
oldr=json.loads((AX/'root/replay-validation.json').read_text());copies={Path(x['replay']['path']).name:x['replay'] for x in oldr['comparisons']}
records=[];all_ids=[];control_ids=[]
for row in r['comparisons']:
 for k in ['parent','report','receipt','log']:verify(row[k])
 original=AX/Path(row['parent']['path']).name;assert original.read_bytes()==Path(row['parent']['path']).read_bytes();verify(copies[original.name])
 old=json.loads(original.read_text());new=json.loads(Path(row['report']['path']).read_text())
 assert len(new['cases'])==row['cases'] and len(new['harness_preflight'])==row['controls']
 assert Counter(c['status'] for c in new['cases'])==new['counts']==row['counts']
 assert new['cases']==old['cases'] and new['harness_preflight']==old['harness_preflight']
 diffs=sorted(k for k in set(old)|set(new) if old.get(k)!=new.get(k));assert set(diffs)<= {'seconds','binary','binary_sha256'}
 assert new['binary']==identity['path'] and new['binary_sha256']==identity['sha256']
 assert new['regressions']==new['improvements']==[] and new['harness_preflight_passed'] is True
 assert all(x['verified'] is True for x in new['harness_preflight'])
 assert new['full_test262_conformance'] is False
 assert len({c['id'] for c in new['cases']})==len(new['cases'])
 keys=[(x['name'],x['result']['mode']) for x in new['harness_preflight']];assert len(keys)==len(set(keys))
 all_ids.extend(c['id'] for c in new['cases']);control_ids.extend(keys)
 policy=new['runner_policy'];assert policy['request_protocol']=='ERJS2' and policy['response_protocol']=='ERJR3' and policy['adapter_feature']=='test262-host' and policy['unhandled_rejection_policy']=='final-quiescent-veto' and policy['completion_policy']=={'sync':'checked-sync','async':'authenticated-done'}
 receipt=json.loads(Path(row['receipt']['path']).read_text());cmd=receipt['command'];assert receipt['exit']==0 and receipt['sha256']==row['log']['sha256']
 assert cmd[cmd.index('--binary')+1]==identity['path'] and cmd[cmd.index('--profile')+1]==row['profile'] and cmd[cmd.index('--output')+1]==row['report']['path']
 baseline_path='tests/conformance/test262-'+row['profile']+'-current.json';assert cmd[cmd.index('--baseline')+1]==baseline_path
 assert parent[baseline_path]==inv[baseline_path]==b(W/baseline_path)['sha256']
 baseline=json.loads((W/baseline_path).read_text());assert set(baseline['cases'])=={x['id'] for x in new['cases']}
 for c in new['cases']:
  assert baseline['cases'][c['id']]=={k:c[k] for k in ['status','case_sha256','source_sha256']}
 manifest_path='tests/upstream/test262-'+row['profile']+'/manifest.json';assert new['corpus_manifest_sha256']==b(W/manifest_path)['sha256']==parent[manifest_path]
 manifest=json.loads((W/manifest_path).read_text());assert new['revision']==manifest['revision']==baseline['revision']
 corpus=W/Path(manifest_path).parent
 for f in manifest['files']:
  assert b(corpus/f['path'])['sha256']==f['sha256'] and (corpus/f['path']).stat().st_size==f['bytes']
 assert len({c['file'] for c in new['cases']})==new['source_tests']
 failures=Counter((x.get('observation',{}).get('status'),x.get('observation',{}).get('message')) for x in new['cases'] if x['status']=='failed')
 records.append({'profile':row['profile'],'parent_original':b(original),'retained_parent':row['parent'],'report':row['report'],'receipt':row['receipt'],'log':row['log'],'counts':new['counts'],'cases':len(new['cases']),'controls':len(keys),'complete_cases_canonical_sha256':canonical(new['cases']),'complete_controls_canonical_sha256':canonical(new['harness_preflight']),'only_report_changes':diffs,'baseline':b(W/baseline_path),'manifest':b(W/manifest_path),'failure_categories':[{'observation_status':k[0],'message':k[1],'modes':v} for k,v in sorted(failures.items())]})
assert len(all_ids)==len(set(all_ids))==842 and len(control_ids)==254
assert r['exact_cases']==842 and r['exact_controls']==254 and r['baseline_changes']==0
x={'status':'all_inert_replay_checks_clear','binary_identity':b(A/'eris-js-host-final-1.json'),'binary':identity,'source':b(A/'source-final.json'),'parent_replay_record':b(AX/'root/replay-validation.json'),'records':records,'total_case_records':842,'distinct_case_ids':842,'per_profile_control_records':254,'distinct_control_name_mode_pairs':len(set(control_ids)),'execution':'Only inert stdlib byte/hash/JSON inspection; no binary, project script or test executed.'}
p=O/'replay-checks.json';p.write_text(json.dumps(x,indent=2)+'\n');print(json.dumps({'checks':b(p),'counts':[{'profile':v['profile'],'counts':v['counts']} for v in records],'distinct_control_pairs':len(set(control_ids))},indent=2))
