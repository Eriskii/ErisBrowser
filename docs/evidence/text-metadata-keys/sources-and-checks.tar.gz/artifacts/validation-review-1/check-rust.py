from pathlib import Path
import hashlib,json,re,ast
A=Path('/tmp/eris-text-metadata-keys-1'); OLD=Path('/tmp/eris-promise-race-1'); OUT=A/'validation-review-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def parse(root,label,expect_exit=0):
 p=root/'validation'/f'{label}.json';r=json.loads(p.read_text());log=p.with_suffix('.log');b=bind(log)
 assert r['exit']==expect_exit and b['sha256']==r['sha256'],label
 text=log.read_text();current=None;names={'ok':[],'ignored':[],'FAILED':[]};counts=[];rows=[]
 for line in text.splitlines():
  if m:=re.fullmatch(r'\s+Running (?:unittests )?([^ ]+) \(.+\)',line):current=m[1]
  elif m:=re.fullmatch(r'\s+Doc-tests (\S+)',line):current='Doc-tests '+m[1]
  elif m:=re.fullmatch(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:,.*)?',line):
   assert current;names[m[2]].append(current+'::'+m[1])
  elif m:=re.fullmatch(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in .+',line):
   v=tuple(map(int,m.groups()[1:]));counts.append(v);rows.append({'harness':current,'status':m[1],'counts':v})
 totals=[sum(t[i] for t in counts) for i in range(5)]
 assert totals[:3]==[len(names['ok']),len(names['FAILED']),len(names['ignored'])]
 for v in names.values():assert len(v)==len(set(v)),label
 return {'receipt':bind(p),'command':r['command'],'log':b,'totals':totals,'rows':rows,'names':{k:sorted(v) for k,v in names.items()}}
labels={'focused':(A,'candidate-text-1'),'default':(A,'default-full-1'),'default_ignored':(A,'default-ignored-1'),'host_vulkan':(A,'host-vulkan-full-1'),'default_previous':(OLD,'default-full-1'),'host_previous':(OLD,'host-vulkan-full-1')}
runs={k:parse(*v) for k,v in labels.items()};parent=parse(A,'parent-text-1',101)
root_record=json.loads((A/'root/rust-validation.json').read_text())
for k,v in runs.items():
 q=root_record[k];assert q['totals']==v['totals'];assert q['result_rows']==len(v['rows']);assert q['passed_names']==v['names']['ok'];assert q['ignored_names']==v['names']['ignored']
assert runs['default']['totals']==[2965,0,124,0,0]
assert runs['default_ignored']['totals']==[124,0,0,0,2965]
assert runs['host_vulkan']['totals']==[3443,0,0,0,0]
assert runs['focused']['totals']==[5,0,0,0,2746]
assert parent['totals']==[1,2,0,0,2746]
assert all(len(runs[k]['rows'])==51 for k in ['default','default_ignored','host_vulkan','default_previous','host_previous'])
base_prefix='src/lib.rs::script::'
renames={
base_prefix+'processing_instruction::key_cache_tests::cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99846_work_boundary':base_prefix+'processing_instruction::key_cache_tests::cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99786_work_boundary',
base_prefix+'promises::install_tests::promise_full_raw99846_and_public_reset_preserve_empty_paid_arenas':base_prefix+'promises::install_tests::promise_full_raw99786_and_public_reset_preserve_empty_paid_arenas'}
new=set(runs['focused']['names']['ok']);pub=json.loads((A/'tests-before-1/roster.json').read_text());priv=json.loads((A/'private-tests-1/roster.json').read_text())
assert new=={'src/lib.rs::'+g['name'] for g in pub['groups']+priv['groups']}
assert priv['planned_operation_rows']==16 and sum(g['planned_rows'] for g in priv['groups'])==16
ordinary=set(runs['default']['names']['ok']);comp=set(runs['default_ignored']['names']['ok'])
assert not ordinary&comp;assert comp==set(runs['default']['names']['ignored']);combined=ordinary|comp;assert len(combined)==3089
for current,old in [(combined,set(runs['default_previous']['names']['ok'])),(set(runs['host_vulkan']['names']['ok']),set(runs['host_previous']['names']['ok']))]:
 assert set(renames)<=old and not set(renames)&current
 normalized={renames.get(n,n) for n in old};assert not normalized&new;assert current==normalized|new
assert set(parent['names']['ok'])=={'src/lib.rs::'+pub['groups'][1]['name']}
assert set(parent['names']['FAILED'])=={'src/lib.rs::'+pub['groups'][i]['name'] for i in [0,2]}
parent_text=Path(parent['log']['path']).read_text();assert 'DOM.Text.getWholeText stored length' in parent_text and 'key_cache_tests.rs:107:13' in parent_text and 'key_cache_tests.rs:209:30' in parent_text and 'kind: Resource' in parent_text
checks=[]
for label in ['clippy-msrv-1','clippy-host-vulkan-1','format-check-1']:
 p=A/'validation'/f'{label}.json';v=json.loads(p.read_text());l=p.with_suffix('.log');assert v['exit']==0 and v['sha256']==bind(l)['sha256'];checks.append({'receipt':bind(p),'log':bind(l),'command':v['command']})
assert checks[0]['command'][1]=='+1.88.0' and checks[1]['command'][1]=='+1.99.0'
assert all(x['command'][-2:]==['-D','warnings'] and '--all-targets' in x['command'] for x in checks[:2])
assert checks[2]['command'][-1]=='--check' and '+1.99.0' in checks[2]['command']
# Current selected source hashes establish that the frozen candidate still holds.
source=A/'source-candidate-extended.json'; inv=json.loads(source.read_text())['source_sha256'];assert len(inv)==1540
for p,h in inv.items():assert hashlib.sha256((A/'worktree'/p).read_bytes()).hexdigest()==h,p
# Independently compare the frozen fixture tokens, without running Rust tools.
lexer_ast=ast.parse((A/'inventory-audit-1/audit.py').read_text());env={'re':re};exec(compile(ast.Module(body=[n for n in lexer_ast.body if isinstance(n,ast.FunctionDef) and n.name=='tokens'],type_ignores=[]),'<inert Rust lexer>','exec'),env)
def norm(ts):return [(k,t) for i,(k,t,*_) in enumerate(ts) if not (t==',' and i+1<len(ts) and ts[i+1][1] in [')',']','}'])]
fixture_checks=[]
for folder,name in [('private-tests-1','key_cache_fee_tests.rs'),('tests-before-1','key_cache_tests.rs')]:
 p='src/script/text_operations/'+name;before=A/folder/'raw'/p;after=A/'worktree'/p;x=env['tokens'](before.read_text());y=env['tokens'](after.read_text());assert norm(x)==norm(y)
 assert [t[1] for t in x if t[0] in ['string','char']]==[t[1] for t in y if t[0] in ['string','char']]
 fixture_checks.append({'held':bind(before),'formatted':bind(after),'tokens_preserved_except_optional_trailing_commas':True})
fmt=json.loads((A/'root/formatting.json').read_text());assert len(fmt['changes'])==3
assert {x['path'] for x in fmt['changes']}=={'src/script/text_operations.rs','src/script/text_operations/key_cache_fee_tests.rs','src/script/text_operations/key_cache_tests.rs'}
for f in fmt['changes']:assert hashlib.sha256((A/'worktree'/f['path']).read_bytes()).hexdigest()==f['after']
a=json.loads((A/'root/formatting-inventory-attempt-1.json').read_text());assert a['assumed_files']==2 and a['actual_files']==3
out={'status':'all_checks_passed_inert_log_source_audit','root_receipt':bind(A/'root/rust-validation.json'),'candidate_source':bind(source),'runs':runs,'parent':parent,'renames':renames,'new_groups':sorted(new),'private_operations_from_source':16,'strict_and_format':checks,'fixture_checks':fixture_checks,'format_attempt':bind(A/'root/formatting-inventory-attempt-1.json'),'format_diffs':[bind(Path(x['diff'])) for x in fmt['changes']]}
(OUT/'rust-checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'counts':{k:v['totals'] for k,v in runs.items()},'parent':parent['totals'],'default_union':len(combined),'new_groups':len(new),'private_source_operations':16,'candidate_inputs':len(inv),'checks_artifact':bind(OUT/'rust-checks.json')},indent=2))
