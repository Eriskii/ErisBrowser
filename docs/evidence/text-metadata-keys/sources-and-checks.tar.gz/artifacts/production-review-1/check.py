from pathlib import Path
import json,hashlib,difflib
P=Path('/tmp/eris-text-metadata-keys-1'); O=P/'production-review-1'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
parent=json.loads((P/'parent-source.json').read_text())['source_sha256']
checked=[]
for h,want in [('production-1','6871ef93c0fb095741e8edef572bf23db06ce3da81d6aca0e0cdb34c980c7179'),('migrations-1','aca7c9d379579f0f8f08de36d708f75289236b291618574410a4ee40655da76d')]:
 p=P/h/'source-ready.json'; assert bind(p)['sha256']==want
 d=json.loads(p.read_text())
 for f in d['files']:
  for field in ['before','raw','diff']: assert bind(f[field]['path'])==f[field],(h,f['relative'],field)
  assert f['before']['sha256']==parent[f['relative']]
  before=Path(f['before']['path']).read_text();raw=Path(f['raw']['path']).read_text()
  diff=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+f['relative'],tofile='b/'+f['relative']))
  assert diff==Path(f['diff']['path']).read_text()
  checked.append({'hold':h,'relative':f['relative'],'before':f['before']['sha256'],'raw':f['raw']['sha256'],'exact_diff_and_parent_join':True})
 for field in ['selection','fee_peer']: assert bind(d[field]['path'])==d[field]
raw=(P/'production-1/raw/src/script/text_operations.rs').read_text()
restored=raw.replace('#[cfg(test)]\nmod key_cache_fee_tests;\n#[cfg(test)]\nmod key_cache_tests;\n','',1)
restored=restored.replace('        metadata_keys: [&PropertyKey; 2],\n','',1)
restored=restored.replace('        // Pay both retained key clones before publishing either descriptor.\n        self.work(2)?;\n','',1)
for n,k in [(0,'length'),(1,'name')]:
 restored=restored.replace('self.dom_proto_property(\n            properties,\n            metadata_keys['+str(n)+'].clone(),','self.dom_proto_named(\n            properties,\n            "'+k+'",',1)
restored=restored.replace('    pub(super) fn install_text_operations(\n        &mut self,\n        prototype: usize,\n        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<()> {\n        // Forward the existing immutable length/name pool once for both bags.\n        self.work(8)?;','    pub(super) fn install_text_operations(&mut self, prototype: usize) -> Result<()> {',1)
restored=restored.replace('"getWholeText", "get wholeText", 0, metadata_keys','"getWholeText", "get wholeText", 0',1).replace('"splitText", "splitText", 1, metadata_keys','"splitText", "splitText", 1',1)
assert restored==(P/'production-1/before/src/script/text_operations.rs').read_text()
rawpi=(P/'production-1/raw/src/script/processing_instruction.rs').read_text()
assert rawpi.replace('self.install_text_operations(prototype, metadata_keys)?','self.install_text_operations(prototype)?',1)==(P/'production-1/before/src/script/processing_instruction.rs').read_text()
# Independent literal tariff derivation from the read static-ASCII and metadata helpers.
old_text_pair=(8+2*6)+(8+2*4); new_clones=2; handoff=8
assert 2*(old_text_pair-new_clones)-handoff==60
assert 2*((64+4*6)+(64+4*4))==336
new_factories=[]
for suffix,display in [('getWholeText','get wholeText'),('splitText','splitText')]:
 native=len('DOM.Text.')+len(suffix)
 work=9+(8+2*len(display))+2+9+15+(8+native)
 new_factories.append(work)
assert new_factories==[98,87]
# owner count0 wholeText then count1 splitText, exact order2: key lengths9,9.
assert 8+4+98+(8+2*9)+9+87+(8+2*9)+(10+9+1)==278
result={
 'status':'clear_source_only','base':json.loads((P/'root/selection-2.json').read_text())['base'],
 'reviewed_holds':[bind(P/'production-1/source-ready.json'),bind(P/'migrations-1/source-ready.json')],
 'selection':bind(P/'root/selection-2.json'),'independent_arithmetic_peer':bind(P/'planning/text-key-sharing-review.json'),
 'checks':checked,
 'production_findings':[
  'Exactly two source paths; reverse the listed signature/key changes and remove the two cfg(test) declarations to recover both complete parent files byte-for-byte.',
  'The sole Text branch passes the existing length/name pair from PI; two factory callsites use it. Upstream DOM pool already supplies length then name. No new static key payload, cache, Runtime field, arena, object, production registry entry or limit.',
  'Factory staging preserves bag then display, prepays clone2 before either length/name property, then preserves native construction. Installer prepays handoff8 then retains old4 before wholeText getter/splitText publication.',
  'No author calls or public failure conversion added. Work/heap failure still propagates with ?; earlier allocation prefixes intentionally differ only according to the selected removed-key allocation and paid-clone schedule.',
  'Bag IDs and owner order/capacity, descriptors, native names/receivers, original Text behavior and prototype identity are unchanged. Text bag keys now share immutable pooled payloads; replacing/deleting one own descriptor cannot mutate the pool or other bags.',
  'No claim that arbitrary planner values are actual resident allocations. Physical order capacity does not change because order2 and owner insertions are unchanged.'
 ],
 'arithmetic':{'per_factory_work_change':-34,'installer_handoff_add':8,'two_factory_work_change':-60,'heap_change':-336,'new_factory_work':[98,87],'empty_owner_installer_work':278,'raw_before':99846,'raw_after':99786,'remaining_before':154,'remaining_after':214},
 'migration_findings':[
  'Six exact patches cover five existing groups plus shared-key replay comment. Two test names track the new raw boundary; exact/one-short become99786/99785; remaining154 becomes214.',
  'Whole-bootstrap typed heap formula subtracts336 and work formula adds60 remaining. No Promise standalone/shared fee, Node/PI isolated fee, object count, metadata identity/order, header formula or security allowance changed.',
  'Source search of fixed99845/99846/remaining154 assertions finds only these current bootstrap paths. Existing Text tests have no direct calls requiring signature migration. Test modules themselves remain separately held and are not approved by this production receipt.'
 ],
 'limitations':'No execution, compilation, formatting, project import or live edit. New tests, source composition and runtime results require their separately assigned reviews.',
 'checker':bind(O/'check.py')}
(O/'source-review.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(bind(O/'source-review.json')))
