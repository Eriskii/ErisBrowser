from pathlib import Path
import json,hashlib,difflib,re
P=Path('/tmp/eris-text-metadata-keys-1');H=P/'private-tests-1';O=P/'production-review-1'
def bind(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
m=bind(H/'source-ready.json');assert m['sha256']=='8fab50cf48704007ad2817a67bccc90567eff8b9a874bdf14dfbf388314d568f'
d=json.loads((H/'source-ready.json').read_text())
for f in d['files']: assert bind(f['path'])==f
before=(H/'before/src/script/text_operations.rs').read_text();raw=(H/'raw/src/script/text_operations.rs').read_text()
assert raw.replace('#[cfg(test)]\nmod key_cache_fee_tests;\n','',1)==before
assert ''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/src/script/text_operations.rs',tofile='b/src/script/text_operations.rs'))==(H/'registration.patch').read_text()
b=json.loads((H/'source-bindings.json').read_text());inv=json.loads((P/'parent-source.json').read_text())['source_sha256']
for f in b['files']:
 rel=Path(f['path']).relative_to(P/'worktree').as_posix();assert f['sha256']==inv[rel]
for k in ['parent_inventory','selected_root_contract','fee_derivation']:assert bind(b[k]['path'])==b[k]
ledger=json.loads((H/'ledger.json').read_text());test=(H/'raw/src/script/text_operations/key_cache_fee_tests.rs').read_text();roster=json.loads((H/'roster.json').read_text())
assert len(re.findall(r'#\[test\]',test))==2
assert [x['name'].rsplit('::',1)[1] for x in roster['groups']]==re.findall(r'#\[test\]\nfn (\w+)',test)
for f in ledger['factory_rows']:
 assert sum(f['work_components'])==f['work'];assert sum(f['heap_constant_components'])==int(f['heap'].split('+')[-1])
assert sum(ledger['installer']['work_components'])==278
assert sum(ledger['installer']['heap_constant_components'])==2351
result={'status':'clear_source_only','held_manifest':m,'source_inventory':bind(P/'parent-source.json'),'test_module':bind(H/'raw/src/script/text_operations/key_cache_fee_tests.rs'),'api':bind(H/'api.txt'),'ledger':bind(H/'ledger.json'),'roster':bind(H/'roster.json'),'production_review':bind(O/'source-review.json'),'checks':[
 'All ten manifest file bindings exact; eight source hashes join the published inventory. Registration removes exactly to parent and is insertion-only for later composition.',
 'Two natural child-module tests use visible parent private helpers. Existing API parent eligibility is correctly false; no test-only accessor, new field or alternate implementation.',
 'Ten factory rows:98/87 exact; one-short Native work/heap endpoints; clone debit one-short44/36; preceding display heap failure leaves55/52 work. Keys, descriptors, partial bag contents and capacities checked at reached stages.',
 'Six installer rows: handoff7 refuses before8;11 pays8 and refuses old4, both without allocation. Prepared order2 owner gives278 exact/279 excess,277 final-property work refusal and H-1 final-property heap refusal.',
 'Constant heaps793/774+T and2351+2T+Bpp independently match staged existing helpers. Native work refusal leaves native heap uncharged; final owner insertion work refusal leaves292 uncharged; charge refusal recordsMAX+1.',
 'Fixture reservation/extraction occurs before measured budgets. >=capacity conditions avoid assuming allocator exactness. Original object/prototype/global/native identities and immutable key payload sharing are checked without numeric bootstrap IDs.',
 'The actual tagged Text owner starts at count1, so its two owner insertions cost20/31 versus9/20 in the empty-owner fixture:300 actual segment,278 fixture; both save60. No cap or logical storage change.'
 ],'findings':[],'execution':'Static source, stdlib JSON/hash/diff/arithmetic only; no compiler/engine/project tests/import/live edits. Parent remains ineligible.'}
(O/'private-tests-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(bind(O/'private-tests-review.json')))
