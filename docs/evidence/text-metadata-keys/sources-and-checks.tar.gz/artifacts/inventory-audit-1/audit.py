"""Read source text and Git object identities only; never import project code."""
from pathlib import Path
import hashlib, json, re, subprocess

ROOT = Path('/tmp/eris-text-metadata-keys-1/worktree')
OUT = ROOT.parent / 'inventory-audit-1'
BASE = 'f3e70ba152fdd3b730b1dd1494963a77f5141161'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob_sha(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def tokens(s):
    """Skip nested comments and whole Rust string/char literals, retaining spans."""
    out = []
    i = 0
    while i < len(s):
        if s[i].isspace():
            i += 1
            continue
        if s.startswith('//', i):
            end = s.find('\n', i + 2)
            i = len(s) if end < 0 else end + 1
            continue
        if s.startswith('/*', i):
            depth = 1
            j = i + 2
            while depth:
                assert j < len(s), ('unterminated comment', i)
                if s.startswith('/*', j):
                    depth += 1
                    j += 2
                elif s.startswith('*/', j):
                    depth -= 1
                    j += 2
                else:
                    j += 1
            i = j
            continue
        raw = re.match(r'(?:br|r)(#*)"', s[i:])
        if raw:
            end_marker = '"' + raw[1]
            start = i + len(raw[0])
            end = s.find(end_marker, start)
            assert end >= 0, ('unterminated raw string', i)
            finish = end + len(end_marker)
            out.append(('string', s[i:finish], i, finish))
            i = finish
            continue
        quote_at = i + 1 if s.startswith('b"', i) or s.startswith('c"', i) else i
        if s[quote_at:quote_at + 1] == '"':
            j = quote_at + 1
            while j < len(s):
                if s[j] == '\\':
                    j += 2
                elif s[j] == '"':
                    j += 1
                    break
                else:
                    j += 1
            assert j <= len(s) and s[j - 1] == '"'
            out.append(('string', s[i:j], i, j))
            i = j
            continue
        char = re.match(r"(?:b)?'(?:[^'\\\n]|\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.))'", s[i:])
        if char:
            j = i + len(char[0])
            out.append(('char', char[0], i, j))
            i = j
            continue
        ident = re.match(r'[A-Za-z_][A-Za-z_0-9]*', s[i:])
        if ident:
            j = i + len(ident[0])
            out.append(('ident', ident[0], i, j))
            i = j
            continue
        out.append(('punct', s[i], i, i + 1))
        i += 1
    return out

raw_tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', BASE], cwd=ROOT)
tree = {}
for row in raw_tree.split(b'\0'):
    if not row:
        continue
    header, name = row.split(b'\t', 1)
    mode, kind, oid = header.decode().split()
    tree[name.decode()] = {'mode': mode, 'type': kind, 'git_blob': oid}
parent = json.loads((ROOT.parent / 'parent-source.json').read_text())['source_sha256']
tracked = subprocess.check_output(['git', 'ls-files', '-z'], cwd=ROOT).decode().split('\0')
rust_paths = sorted(p for p in tracked if p.endswith('.rs'))
assert len(rust_paths) == len(set(rust_paths))
sources = []
uses = []
nonliteral = []
for relative in rust_paths:
    path = ROOT / relative
    data = path.read_bytes()
    source = data.decode('utf-8')
    source_info = {'path': relative, 'bytes': len(data), 'sha256': sha(data),
                   'in_parent_inventory': relative in parent,
                   'parent_inventory_matches': parent.get(relative) == sha(data),
                   'published_git_blob': tree.get(relative, {}).get('git_blob'),
                   'published_blob_matches': blob_sha(data) == tree.get(relative, {}).get('git_blob')}
    sources.append(source_info)
    ts = tokens(source)
    for i, token in enumerate(ts):
        if token[0] != 'ident' or token[1] not in ('include_str', 'include_bytes'):
            continue
        if i + 2 >= len(ts) or ts[i + 1][1] != '!' or ts[i + 2][1] not in ('(', '[', '{'):
            continue
        close = {'(': ')', '[': ']', '{': '}'}[ts[i + 2][1]]
        row = {'source': relative, 'line': source.count('\n', 0, token[2]) + 1, 'macro': token[1]}
        a = i + 3
        if ts[a][0] == 'string' and (ts[a + 1][1] == close or (ts[a + 1][1] == ',' and ts[a + 2][1] == close)):
            literal = ts[a][1]
            if literal.startswith('r'):
                m = re.fullmatch(r'r(#*)"(.*)"\1', literal, re.S)
                assert m
                value = m[2]
            else:
                assert literal.startswith('"'), (relative, literal)
                value = json.loads(literal)
            resolved = (path.parent / value).resolve()
            try:
                target = resolved.relative_to(ROOT).as_posix()
            except ValueError:
                raise AssertionError(('include outside checkout', relative, value))
            exists = resolved.is_file() and not resolved.is_symlink()
            payload = resolved.read_bytes() if exists else None
            row.update({'literal': literal, 'target': target, 'exists': exists, 'bytes': len(payload) if exists else None, 'sha256': sha(payload) if exists else None,
                        'in_parent_inventory': target in parent,
                        'parent_inventory_matches': exists and parent.get(target) == sha(payload),
                        'published_git_blob': tree.get(target, {}).get('git_blob'),
                        'published_blob_matches': exists and blob_sha(payload) == tree.get(target, {}).get('git_blob')})
            uses.append(row)
        else:
            # Retain computed includes rather than claiming literal closure covers them.
            row['expression_prefix'] = source[ts[a][2]:ts[a][2] + 180]
            nonliteral.append(row)

by_target = {}
for use in uses:
    target = use['target']
    item = by_target.setdefault(target, {k: use[k] for k in ['target', 'exists', 'bytes', 'sha256', 'in_parent_inventory', 'parent_inventory_matches', 'published_git_blob', 'published_blob_matches']})
    item.setdefault('uses', []).append({k: use[k] for k in ['source', 'line', 'macro', 'literal']})
assert all(v['published_blob_matches'] for v in by_target.values() if v['exists'])
assert all(not v['in_parent_inventory'] or v['parent_inventory_matches'] for v in by_target.values())
missing = [by_target[p] for p in sorted(by_target) if by_target[p]['exists'] and not by_target[p]['in_parent_inventory']]
unresolved = [by_target[p] for p in sorted(by_target) if not by_target[p]['exists']]
for p in ['tests/fixtures/text-operations.js', 'tests/fixtures/text-operations.html']:
    assert p in by_target

result = {
    'status': 'literal_include_audit_complete_with_inventory_omissions',
    'base': BASE,
    'parent_inventory': binding(ROOT.parent / 'parent-source.json'),
    'counts': {
        'tracked_rust_files': len(sources), 'literal_uses': len(uses),
        'unique_literal_targets': len(by_target), 'computed_or_nonliteral_macros': len(nonliteral),
        'targets_in_selected_parent_inventory': sum(x['in_parent_inventory'] for x in by_target.values()),
        'unresolved_literal_targets': len(unresolved),
        'targets_missing_from_selected_parent_inventory': len(missing),
        'missing_target_bytes': sum(x['bytes'] for x in missing),
        'rust_files_missing_from_selected_parent_inventory': sum(not x['in_parent_inventory'] for x in sources),
    },
    'missing_targets': missing,
    'text_inputs': [by_target[p] for p in ['tests/fixtures/text-operations.js', 'tests/fixtures/text-operations.html']],
    'all_targets': [by_target[p] for p in sorted(by_target)],
    'nonliteral_macros': nonliteral,
    'unresolved_targets': unresolved,
    'rust_source_bindings': sources,
    'current_tracked_rust_deltas_from_published_base': [x for x in sources if not x['published_blob_matches']],
}
(OUT / 'literal-inputs.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'counts': result['counts'], 'missing_paths': [x['target'] for x in missing],
                  'nonliteral_macros': nonliteral, 'unresolved_targets': unresolved,
                  'current_rust_deltas': result['current_tracked_rust_deltas_from_published_base']}, indent=2))
