import difflib
import hashlib
import json
from pathlib import Path

A=Path(__file__).resolve().parents[1]; W=A/'worktree'; H=A/'production-1'
changes=[]

def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def save(relative,before,after,edits):
    inverse=after
    for old,new in reversed(edits):
        assert inverse.count(new)==1,new
        inverse=inverse.replace(new,old)
    assert inverse==before
    for sub,data in [('before',before),('raw',after)]:
        p=H/sub/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
    diff=H/'diffs'/(relative+'.patch');diff.parent.mkdir(parents=True,exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),'a/'+relative,'b/'+relative)))
    changes.append(dict(relative=relative,before=bind(H/'before'/relative),raw=bind(H/'raw'/relative),diff=bind(diff),exact_inverse=True))

relative='src/script/text_operations.rs';before=(W/relative).read_text();after=before;edits=[]
def edit(old,new):
    global after
    assert after.count(old)==1,old
    after=after.replace(old,new);edits.append((old,new))

edit('#[cfg(test)]\nmod tests;\n', '#[cfg(test)]\nmod key_cache_fee_tests;\n#[cfg(test)]\nmod key_cache_tests;\n#[cfg(test)]\nmod tests;\n')
edit('        length: usize,\n    ) -> Result<Value> {', '        length: usize,\n        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<Value> {')
edit('''        let name = self.dom_proto_text(display)?;
        self.dom_proto_named(
            properties,
            "length",
''', '''        let name = self.dom_proto_text(display)?;
        // Pay both retained key clones before publishing either descriptor.
        self.work(2)?;
        self.dom_proto_property(
            properties,
            metadata_keys[0].clone(),
''')
edit('''        self.dom_proto_named(
            properties,
            "name",
''', '''        self.dom_proto_property(
            properties,
            metadata_keys[1].clone(),
''')
edit('''    pub(super) fn install_text_operations(&mut self, prototype: usize) -> Result<()> {
        self.work(4)?;
''', '''    pub(super) fn install_text_operations(
        &mut self,
        prototype: usize,
        metadata_keys: [&PropertyKey; 2],
    ) -> Result<()> {
        // Forward the existing immutable length/name pool once for both bags.
        self.work(8)?;
        self.work(4)?;
''')
edit('self.text_operations_function("getWholeText", "get wholeText", 0)?', 'self.text_operations_function("getWholeText", "get wholeText", 0, metadata_keys)?')
edit('self.text_operations_function("splitText", "splitText", 1)?', 'self.text_operations_function("splitText", "splitText", 1, metadata_keys)?')
save(relative,before,after,edits)
relative='src/script/processing_instruction.rs';before=(W/relative).read_text();old='"Text" => self.install_text_operations(prototype)?,';new='"Text" => self.install_text_operations(prototype, metadata_keys)?,'
assert before.count(old)==1;save(relative,before,before.replace(old,new),[(old,new)])
r=dict(status='sealed_source_only_before_parent_baseline',base='f3e70ba152fdd3b730b1dd1494963a77f5141161',files=changes,
    source_scope='Two existing Text metadata factories borrow the existing PI/DOM key pool; preserve all owner keys, display/native names, descriptors, identities/order and resource limits.',
    test_modules=['key_cache_tests','key_cache_fee_tests'], parent_test_overlay='Only key_cache_tests declaration is imported for parent baseline; final raw adds both declarations with frozen files.',
    expected_delta=dict(work=-60,accounted_heap=-336,raw_work=99786,remainder=214),
    selection=bind(A/'root/selection-2.json'),fee_peer=bind(A/'planning/text-key-sharing-review.json'))
(H/'source-ready.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(bind(H/'source-ready.json')))
