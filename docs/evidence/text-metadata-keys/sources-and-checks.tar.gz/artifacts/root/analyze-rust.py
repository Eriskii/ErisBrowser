import hashlib
import json
import re
from pathlib import Path

A=Path(__file__).resolve().parents[1]
AW=Path('/tmp/eris-promise-race-1')

def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

def parse(root,label):
    receipt=root/'validation'/(label+'.json'); r=json.loads(receipt.read_bytes())
    log=receipt.with_suffix('.log'); text=log.read_text()
    assert r['exit']==0 and r['sha256']==bind(log)['sha256']
    rows=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)]
    totals=[sum(row[i] for row in rows) for i in range(5)]
    assert totals[1]==totals[3]==0
    harness=None; names={'ok':[], 'ignored':[]}
    for line in text.splitlines():
        match=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
        if match:harness=match[1]
        if 'Doc-tests ' in line:harness='Doc-tests '+line.split('Doc-tests ',1)[1]
        result=re.match(r'^test (.+) \.\.\. (ok|ignored)(?:,.*)?$',line)
        if result:
            assert harness is not None
            names[result[2]].append(harness+'::'+result[1])
    assert len(names['ok'])==totals[0] and len(names['ignored'])==totals[2],(label,totals,{k:len(v) for k,v in names.items()})
    assert len(names['ok'])==len(set(names['ok']))
    return dict(receipt=bind(receipt),log=bind(log),result_rows=len(rows),totals=totals,passed_names=sorted(names['ok']),ignored_names=sorted(names['ignored']))

def normalized(names):
    return {n.replace('frozen_99846_work_boundary','frozen_99786_work_boundary').replace('promise_full_raw99846_and_public_reset','promise_full_raw99786_and_public_reset') for n in names}

focused=parse(A,'candidate-text-1'); assert focused['totals']==[5,0,0,0,2746]
default=parse(A,'default-full-1'); ignored=parse(A,'default-ignored-1')
assert default['totals']==[2965,0,124,0,0]
assert ignored['totals']==[124,0,0,0,2965]
assert not set(default['passed_names'])&set(ignored['passed_names'])
assert default['ignored_names']==ignored['passed_names']
combined=set(default['passed_names'])|set(ignored['passed_names'])
old_default=parse(AW,'default-full-1')
assert len(combined)==3089 and len(old_default['passed_names'])==3084
new=set(focused['passed_names'])
assert combined==normalized(old_default['passed_names'])|new
assert not normalized(old_default['passed_names'])&new
record=dict(status='default_complete',focused=focused,default=default,default_ignored=ignored,
            default_distinct_passed=3089,default_unexecuted=0,
            default_previous=old_default,
            qualification='The standard default invocation excluded124 tests. A disjoint --ignored run executed all124; exact old roster plus five new groups is covered. Neither log alone is called full including ignored.')
if (A/'validation/host-vulkan-full-1.json').exists():
    host=parse(A,'host-vulkan-full-1'); old_host=parse(AW,'host-vulkan-full-1')
    assert host['totals']==[3443,0,0,0,0]
    assert len(old_host['passed_names'])==3438
    assert set(host['passed_names'])==normalized(old_host['passed_names'])|new
    record.update(status='all_rust_suites_complete',host_vulkan=host,host_previous=old_host,
                  host_distinct_passed=3443,new_groups=5,selected_existing_renames=2)
(A/'root/rust-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(record['status'],record['default_distinct_passed'],record.get('host_distinct_passed'))
