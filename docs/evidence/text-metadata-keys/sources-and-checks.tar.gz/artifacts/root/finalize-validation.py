import hashlib
import json
import shutil
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def read(name):
    return json.loads((A / name).read_bytes())

source = read('source-final.json')['source_sha256']
parent = read('parent-source-extended.json')['source_sha256']
assert len(source) == 1540 and len(parent) == 1538
changed = sorted(p for p, h in source.items() if parent.get(p) != h)
assert len(changed) == 10
for p, h in source.items():
    assert bind(W / p)['sha256'] == h, p
rust = read('root/rust-validation.json')
replay = read('root/replay-validation.json')
assert rust['status'] == 'all_rust_suites_complete'
assert read('validation-review-1/rust-review.json')['status'] == 'clear'
assert replay['status'] == 'pass' and replay['exact_cases'] == 842 and replay['exact_controls'] == 254
for label in ['clippy-msrv-1', 'clippy-host-vulkan-1', 'format-check-1', 'host-release-1']:
    assert read('validation/' + label + '.json')['exit'] == 0

# Retain the old full-suite records used in exact roster comparisons.
prior = A / 'prior-rust'
prior.mkdir(exist_ok=True)
prior_records = []
for label in ['default-full-1', 'host-vulkan-full-1']:
    for suffix in ['json', 'log']:
        original = Path('/tmp/eris-promise-race-1/validation') / (label + '.' + suffix)
        copy = prior / original.name
        if not copy.exists():
            shutil.copyfile(original, copy)
        assert bind(copy)['sha256'] == bind(original)['sha256']
        prior_records.append(dict(original=bind(original), retained=bind(copy)))

ledger = dict(
    status='verified', base='f3e70ba152fdd3b730b1dd1494963a77f5141161',
    scope='Reuse the existing immutable length/name key payloads for both Text native metadata bags, preserving observable behavior and runtime limits.',
    source=bind(A / 'source-final.json'), parent_source=bind(A / 'parent-source-extended.json'),
    selected_source_inputs=1540, changed_source_paths=changed,
    production_files=2, existing_test_migration_files=6, new_test_modules=2,
    resource_change=dict(raw_startup_before=99846, raw_startup_after=99786,
        work_saved=60, accounted_heap_bytes_saved=336, instruction_limit=100000,
        remaining_before=154, remaining_after=214, heap_limit_bytes=8388608,
        objects=751, native_registry_entries=299, prototypes=25, globals=212,
        qualification='Abstract work and heap accounting; not CPU timing, resident memory or Chromium performance.'),
    parent_baseline=bind(A / 'root/parent-baseline.json'),
    new_tests=dict(groups=5, parent_compatible_groups=3, parent_passed=1,
        parent_expected_failures=2, private_groups=2, private_operation_rows=16,
        assertions_changed_after_parent=False),
    rust_validation=dict(default_distinct_passed=3089, default_ordinary_passed=2965,
        default_ordinary_ignored=124, default_complement_passed=124,
        default_complement_filtered=2965, host_vulkan_passed=3443,
        new_groups=5, selected_existing_renames=2,
        record=bind(A / 'root/rust-validation.json'),
        peer=bind(A / 'validation-review-1/rust-review.json'),
        qualification='The default total is the exact disjoint union of ordinary and ignored-only commands. Host/Vulkan used --include-ignored. Both old rosters are preserved after two selected boundary-name renames plus five new groups.'),
    strict_checks=[bind(A / 'validation' / (n + '.json')) for n in
        ['clippy-msrv-1', 'clippy-host-vulkan-1', 'format-check-1']],
    release_binary=replay['binary'], replay=bind(A / 'root/replay-validation.json'),
    exact_case_records=842, exact_harness_records=254, baseline_changes=0,
    retained_prior_rust_records=prior_records,
    source_inventory_qualification=dict(record=bind(A / 'root/inventory-extension.json'),
        note='The inherited 1361-entry selected map omitted literal include inputs. This checkpoint binds 177 unchanged published-parent inputs, yielding 1538 parent entries and 1540 candidate entries. Two Text inputs were bound before the parent run; the remaining supplement was retrospective evidence-only. Earlier archives remain unchanged. This is not a complete dependency/build-graph inventory.'),
    formatting_qualification=dict(record=bind(A / 'root/formatting-inventory-attempt-1.json'),
        note='Formatting affected three files; an initial inventory-script assumption of two was corrected. No assertion, expectation or implementation logic changed.'),
    source_peer=bind(A / 'candidate-source-review-1/source-review.json'),
    limitations=['Promise.allSettled remains absent at this checkpoint.',
        'No new web API or standards-coverage claim.',
        'Existing Promise profile failures and unsupported modes remain recorded.',
        'No GPU execution, Chromium speed comparison or general security proof.',
        'Full web compatibility and the overall browser objective remain incomplete.'])
(A / 'root/final-validation.json').write_text(json.dumps(ledger, indent=2) + '\n')
print(json.dumps(dict(status=ledger['status'], changed=len(changed), default=3089, host_vulkan=3443, cases=842, controls=254)))
