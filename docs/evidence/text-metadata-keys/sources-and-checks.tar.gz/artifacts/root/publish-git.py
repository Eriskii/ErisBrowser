import json
import subprocess
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], text=True).strip()

v = json.loads((A / 'root/publication-verification.json').read_bytes())
assert v['status'] == 'verified'
base = 'f3e70ba152fdd3b730b1dd1494963a77f5141161'
assert git(W, 'rev-parse', 'HEAD') == git(MAIN, 'rev-parse', 'HEAD') == base
assert not git(MAIN, 'status', '--porcelain') and not git(W, 'diff', '--cached', '--name-only')
paths = v['expected_commit_paths']
actual = set(git(W, 'diff', '--name-only').splitlines()) | set(git(W, 'ls-files', '--others', '--exclude-standard').splitlines())
assert actual == set(paths)
subprocess.run(['git', '-C', str(W), 'diff', '--check'], check=True)
subprocess.run(['git', '-C', str(W), 'add', '--', *paths], check=True)
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
message = A / 'commit-message.txt'
message.write_text('Share Text native metadata key payloads during startup\n\nReuse the existing length/name keys for wholeText and splitText while\npreserving their separate metadata bags and callable identities. Save\n60 startup work units and 336 accounted heap bytes under unchanged caps.\n\nValidate five new test groups, 3,089 distinct default Rust tests across\ncomplementary commands, 3,443 host/Vulkan tests and strict lint/format checks.\nPreserve all 842 Promise case records and 254 harness records on the rebuilt\nrelease adapter. Retain evidence and the unchanged literal-input supplement.\n')
subprocess.run(['git', '-C', str(W), 'commit', '-F', str(message)], check=True)
commit = git(W, 'rev-parse', 'HEAD')
assert not git(W, 'status', '--porcelain')
subprocess.run(['git', '-C', str(MAIN), 'merge', '--ff-only', commit], check=True)
subprocess.run(['git', '-C', str(MAIN), 'push', 'origin', 'main'], check=True)
assert git(MAIN, 'rev-parse', 'HEAD') == commit and not git(MAIN, 'status', '--porcelain')
(A / 'root/github-publication.json').write_text(json.dumps(dict(commit=commit,
    remote='https://github.com/Eriskii/ErisBrowser', push='success', ci_status='pending',
    note='Postpublication state intentionally outside the immutable evidence archive.'), indent=2) + '\n')
print('Published ' + commit)
