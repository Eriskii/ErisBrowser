import difflib
import hashlib
import json
from pathlib import Path

A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'migrations-1'
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

rows={
 'src/script/bootstrap_tests.rs': [
  ('    assert_eq!(reference.steps, 154);','    // Two Text factories share existing keys, saving60 work and336 bytes.\n    assert_eq!(reference.steps, 214);')],
 'src/script/typed_array/tests.rs': [
  ('            - 121\n    );','            - 121\n            + 60\n    );'),
  ('            + race_added\n    );','            + race_added\n            - 336\n    );'),
  ('    // Race adds one method and no State header.','    // Text metadata sharing saves60 work and336 bytes without new bags.\n    // Race adds one method and no State header.')],
 'src/script/processing_instruction/key_cache_tests.rs': [
  ('frozen_99846_work_boundary','frozen_99786_work_boundary'),
  ('[(99_845, false, 0), (99_846, true, 0), (100_000, true, 154)]','[(99_785, false, 0), (99_786, true, 0), (100_000, true, 214)]')],
 'src/script/promises/install_tests.rs': [
  ('promise_full_raw99846_and_public_reset','promise_full_raw99786_and_public_reset'),
  ('[(99_845, false, 0), (99_846, true, 0), (100_000, true, 154)]','[(99_785, false, 0), (99_786, true, 0), (100_000, true, 214)]')],
 'src/script/promises/shared_key_tests.rs': [
  ('migrated99845/99846/100000','migrated99785/99786/100000')],
 'src/script/test262_host/quota_tests.rs': [
  ('    assert_eq!(runtime.steps, 154);','    assert_eq!(runtime.steps, 214);')],
}
files=[]
for relative,edits in rows.items():
    before=(W/relative).read_text();after=before
    for old,new in edits:
        assert after.count(old)==1,(relative,old)
        after=after.replace(old,new)
    inverse=after
    for old,new in reversed(edits):
        assert inverse.count(new)==1;inverse=inverse.replace(new,old)
    assert inverse==before
    for sub,data in [('before',before),('raw',after)]:
        p=H/sub/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data)
    diff=H/'diffs'/(relative+'.patch');diff.parent.mkdir(parents=True,exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),'a/'+relative,'b/'+relative)))
    files.append(dict(relative=relative,before=bind(H/'before'/relative),raw=bind(H/'raw'/relative),diff=bind(diff),exact_inverse=True))
r=dict(status='frozen_source_derived_accounting_migrations',files=files,executed=False,
    scope='Five existing groups in six files, including one comment-only file. Two names follow raw boundary. No standalone/shared Promise, Node/PI factory, metadata identity/order/count, or cap assertion changes.',
    selection=bind(A/'root/selection-2.json'),fee_peer=bind(A/'planning/text-key-sharing-review.json'))
(H/'source-ready.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(bind(H/'source-ready.json')))
