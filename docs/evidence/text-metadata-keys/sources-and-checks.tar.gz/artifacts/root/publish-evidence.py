import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
E = W / 'docs/evidence/text-metadata-keys'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=sha(data))

def read(name):
    return json.loads((A / name).read_bytes())

final = read('source-final.json')['source_sha256']
parent = read('parent-source-extended.json')['source_sha256']
changed = sorted(p for p, h in final.items() if parent.get(p) != h)
assert len(changed) == 10
for p, h in final.items():
    assert sha((W / p).read_bytes()) == h, p
members = {}

def add(name, path, role):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    members[name] = dict(data=path.read_bytes(), origin=str(path), role=role)

for p in changed:
    add('sources/' + p, W / p, 'changed-source')
for row in read('documentation-1/source-ready.json')['files']:
    p = row['relative_path']
    assert bind(W / p)['sha256'] == row['raw']['sha256']
    add('documentation/' + p, W / p, 'published-documentation')

directories = ['candidate-source-review-1', 'documentation-1', 'formatting-1',
    'inventory-audit-1', 'migrations-1', 'planning', 'private-tests-1',
    'production-1', 'production-review-1', 'replay-parent', 'tests-before-1',
    'validation', 'validation-review-1', 'prior-rust']
for directory in directories:
    assert (A / directory).is_dir(), directory
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and '__pycache__' not in p.parts:
            add('artifacts/' + str(p.relative_to(A)), p, 'validation-artifact')
excluded = {'evidence-selection.json', 'publication-verification.json', 'github-publication.json'}
for p in sorted((A / 'root').glob('*')):
    if p.is_file() and p.name not in excluded:
        add('artifacts/root/' + p.name, p, 'root-receipt-or-script')
for p in sorted(A.glob('*')):
    if p.is_file() and (p.suffix == '.json' or p.name in ['run-check.py', 'run-tool.py']):
        add('artifacts/' + p.name, p, 'validation-artifact')
# Retain the actual previously omitted include bytes, not merely their hashes.
supplement = read('inventory-audit-1/supplemental-literal-inputs.json')['source_sha256']
assert len(supplement) == 177
for p, h in sorted(supplement.items()):
    assert bind(W / p)['sha256'] == h
    add('supplemental-inputs/' + p, W / p, 'unchanged-literal-input')
ledger = read('root/final-validation.json')
peer = read('validation-review-1/final-review.json')
assert peer['status'] == 'clear'
selection = [dict(path=name, bytes=len(item['data']), sha256=sha(item['data']),
    origin=item['origin'], role=item['role']) for name, item in sorted(members.items())]
assert sum(row['bytes'] for row in selection) < 32 * 1024 * 1024
selection_path = A / 'root/evidence-selection.json'
selection_path.write_text(json.dumps(dict(status='frozen', members=selection,
    excluded='Compiled binaries, build caches, full unchanged repository and subsequent publication/CI state. Archive paths retain portable bytes; absolute origins document provenance.'), indent=2) + '\n')
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name, item in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(item['data'])
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(item['data']))
packed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
assert len(packed) < 8 * 1024 * 1024
E.mkdir(parents=True, exist_ok=True)
archive_path = E / 'sources-and-checks.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(packed)
summary = dict(schema=1, status='verified',
    archive=dict(path=archive_path.name, bytes=len(packed), sha256=sha(packed),
        member_bytes=sum(row['bytes'] for row in selection), uncompressed_tar_bytes=len(raw.getvalue()),
        selected_max_uncompressed_bytes=32 * 1024 * 1024),
    source_count=10, documentation_count=4, supplemental_input_count=177,
    artifact_count=len(selection)-191, source_inventory=bind(A / 'source-final.json'),
    claims=dict(base=ledger['base'], scope=ledger['scope'], resource_change=ledger['resource_change'],
        new_test_groups=5, private_operation_rows=16, parent_passed=1, parent_expected_failures=2,
        default_distinct_passed=3089, default_commands_passed=[2965, 124], host_vulkan_passed=3443,
        exact_case_records=842, exact_harness_records=254, baseline_changes=0,
        source_inputs=1540, changed_source_inputs=10,
        binary_sha256=ledger['release_binary']['sha256'], limitations=ledger['limitations']),
    claims_authority=dict(ledger=bind(A / 'root/final-validation.json'), peer=bind(A / 'validation-review-1/final-review.json')),
    selection=bind(selection_path), members=selection)
(E / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
with tarfile.open(archive_path, 'r:gz') as archive:
    assert archive.getnames() == [row['path'] for row in selection]
    for row in selection:
        member = archive.getmember(row['path'])
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
print(json.dumps(dict(members=len(selection), sources=10, docs=4, supplemental_inputs=177, archive=bind(archive_path))))
