from pathlib import Path
import hashlib,json,difflib,re,struct,zlib,os
P=Path('/tmp/eris-text-metadata-keys-1');R=P/'worktree';O=P/'candidate-source-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def read(n):return json.loads((P/n).read_text())
parent=read('parent-source.json')['source_sha256']; raw=read('source-candidate-raw.json')['source_sha256'];candidate=read('source-candidate.json')['source_sha256']
assert len(parent)==1361 and len(raw)==len(candidate)==1365
selected=dict(parent);held={}
for h in ['production-1','migrations-1']:
 d=read(h+'/source-ready.json')
 for f in d['files']:
  assert bind(f['before']['path'])==f['before'];assert bind(f['raw']['path'])==f['raw'];assert parent[f['relative']]==f['before']['sha256']
  selected[f['relative']]=f['raw']['sha256'];held[f['relative']]=Path(f['raw']['path'])
for rel,h in [('src/script/text_operations/key_cache_tests.rs','tests-before-1'),('src/script/text_operations/key_cache_fee_tests.rs','private-tests-1')]:
 f=P/h/'raw'/rel;selected[rel]=sha(f.read_bytes());held[rel]=f
supp2=read('root/text-input-supplement.json')
for row in supp2['inputs']: selected[row['path']]=row['sha256']
assert selected==raw
# Literal-preserving token scan; commas optional only at manually checked multi-field/argument/array endings.
pat=re.compile(r'//[^\n]*|/\*.*?\*/|(?:br|r)(?P<h>\#*)".*?"(?P=h)|b?"(?:\\.|[^"\\])*"|b?\'(?:\\.|[^\'\\])\'|[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*|[^\s]',re.S)
def tokens(s):
 out=[m.group() for m in pat.finditer(s) if not m.group().startswith(('//','/*'))]
 return [t for i,t in enumerate(out) if not(t==',' and i+1<len(out) and out[i+1] in [')','}',']'])]
fmt=read('root/formatting.json');diffpaths=[]
for f in fmt['changes']:
 rel=f['path'];before=held[rel].read_text();after=(R/rel).read_text()
 assert sha(before.encode())==f['before']==raw[rel];assert sha(after.encode())==f['after']==candidate[rel]
 assert tokens(before)==tokens(after),rel
 diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='raw/'+rel,tofile='formatted/'+rel))
 assert diff==Path(f['diff']).read_text();diffpaths.append(rel)
 assert re.findall(r'(?s)r(\#*)".*?"\1|"(?:\\.|[^"\\])*"',before)==re.findall(r'(?s)r(\#*)".*?"\1|"(?:\\.|[^"\\])*"',after)
assert sorted(k for k in raw if raw[k]!=candidate[k])==sorted(diffpaths)
for rel,want in candidate.items():assert sha((R/rel).read_bytes())==want,rel
# Supplement extension is additive and disjoint, except the two independently held Text supplements.
supp=read('inventory-audit-1/supplemental-literal-inputs.json')['source_sha256'];assert len(supp)==177
assert not(set(supp)&set(parent))
for rel,want in supp.items():assert sha((R/rel).read_bytes())==want
parentex=read('parent-source-extended.json')['source_sha256'];candidateex=read('source-candidate-extended.json')['source_sha256']
assert parentex==parent|supp and len(parentex)==1538
assert candidateex==candidate|supp and len(candidateex)==1540
changes=sorted(k for k in candidateex if parentex.get(k)!=candidateex[k]);assert len(changes)==10
assert set(changes)==set(held)
# Independent inert Git-index parse. Prove index tree equals published parent, then hash all tracked bytes.
gitdir=Path((R/'.git').read_text().strip().split(': ',1)[1]);common=(gitdir/(gitdir/'commondir').read_text().strip()).resolve()
data=(gitdir/'index').read_bytes();magic,version,count=struct.unpack('>4sII',data[:12]);assert(magic,version)==(b'DIRC',2);assert hashlib.sha1(data[:-20]).digest()==data[-20:]
pos=12;entries=[];tree={}
for _ in range(count):
 start=pos;mode=struct.unpack('>I',data[pos+24:pos+28])[0];oid=data[pos+40:pos+60];flags=struct.unpack('>H',data[pos+60:pos+62])[0];assert flags&0x7000==0
 end=data.index(b'\0',pos+62);name=data[pos+62:end];pos=start+((end+1-start+7)//8)*8
 entries.append((name,mode,oid));node=tree
 for part in name.split(b'/')[:-1]:node=node.setdefault(part,{})
 node[name.split(b'/')[-1]]=(mode,oid)
def digest_tree(node):
 parts=[]
 for name,v in sorted(node.items(),key=lambda kv:kv[0]+(b'/' if isinstance(kv[1],dict) else b'')):
  mode,oid=(0o40000,digest_tree(v)) if isinstance(v,dict) else v
  parts.append(format(mode,'o').encode()+b' '+name+b'\0'+oid)
 body=b''.join(parts);return hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).digest()
base='f3e70ba152fdd3b730b1dd1494963a77f5141161';obj=zlib.decompress((common/'objects'/base[:2]/base[2:]).read_bytes());header,body=obj.split(b'\0',1);assert header.startswith(b'commit ');assert hashlib.sha1(obj).hexdigest()==base
parent_tree=body.splitlines()[0].split()[1].decode();assert digest_tree(tree).hex()==parent_tree
head=(gitdir/'HEAD').read_text().strip();assert head.startswith('ref: ');head_oid=(common/head[5:]).read_text().strip();assert head_oid==base
tracked_changes=[];total_bytes=0
for name,mode,oid in entries:
 rel=name.decode();p=R/rel
 content=os.readlink(p).encode() if mode==0o120000 else p.read_bytes();total_bytes+=len(content)
 got=hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).digest()
 if got!=oid: tracked_changes.append(rel)
assert sorted(tracked_changes)==sorted(k for k in held if k in parent)
# All actual source .rs files outside target/git are tracked or the two explicitly held additions.
tracked={n.decode() for n,_,_ in entries};untracked_rust=[]
for top in ['src','tests','crates']:
 for p in (R/top).rglob('*.rs'):
  rel=p.relative_to(R).as_posix()
  if rel not in tracked:untracked_rust.append(rel)
assert sorted(untracked_rust)==sorted(k for k in held if k not in parent)
result={'status':'clear_static_candidate_composition','published_base':base,'snapshots':[bind(P/n) for n in ['parent-source.json','source-candidate-raw.json','source-candidate.json','parent-source-extended.json','source-candidate-extended.json']],'holds':[bind(P/n/'source-ready.json') for n in ['production-1','migrations-1','tests-before-1','private-tests-1']],'prior_reviews':[bind(P/'production-review-1'/n) for n in ['source-review.json','private-tests-review.json']],'formatting':{'receipt':bind(P/'root/formatting.json'),'original_inventory_writer_attempt':bind(P/'root/formatting-inventory-attempt-1.json'),'files':[{'path':x,'diff':bind(P/'formatting-1'/(x+'.patch'))} for x in diffpaths],'comparison':'Exact raw-to-formatted diffs; tokens identical after whitespace/comments and manually reviewed optional ending commas. All string/raw-string and numeric tokens unchanged. No module reordering. Production patch is only one let-binding line wrap; test patches are wrapping and optional commas.','writer_qualification':'Original expected2-file inventory writer stopped after producing3 format diffs. It did not change source or expected results; corrected snapshot binds the same formatted bytes. This receipt infers no runtime result.'},'composition':{'parent_selected':1361,'raw_and_formatted_selected':1365,'parent_extended':1538,'candidate_extended':1540,'changed_existing':8,'new_tests':2,'changed_paths':changes,'known_Text_supplements':2,'other_late_literal_bindings':175,'all_current_candidate_and_supplement_hashes_match':True},'tracked_audit':{'mechanism':'Read-only stdlib parsing of Git index and loose published commit; reconstructed complete index tree equals parent commit tree. Independently Git-blob-hashed every tracked worktree file, with symlink treatment. No git process, project execution or mutation.','entries':count,'bytes_read':total_bytes,'index_checksum':data[-20:].hex(),'parent_tree':parent_tree,'modified_tracked_paths':tracked_changes,'untracked_active_rust_paths':untracked_rust,'extra_tracked_edits':[]},'literal_scope':{'audit':bind(P/'inventory-audit-1/source-review.json'),'supplement':bind(P/'inventory-audit-1/supplemental-literal-inputs.json'),'extension':bind(P/'root/inventory-extension.json'),'qualification':'Inherited1361 is a selected source/conformance map, not a complete build-graph/repository input closure.177 omitted non-evidence literal targets are now bound additively to current bytes and published parent; two Text targets were held before baseline,175 are later evidence-only. All35 omitted tracked Rust files are nevertheless included in the independent tracked audit; six unresolved archived relative includes are not asserted current build inputs. No prior AX map/archive rewritten; no inferred test execution or macro/build-script dependency closure.'},'checks':['Raw candidate map is exact overlay of two production paths, six migration paths, two frozen new test modules and two Text literal supplements.','Eight old paths and two new modules are the only extended-map changes; all other1530 hashes unchanged.','Two new cfg(test) registrations appear exactly once in the reviewed production overlay. No old Text semantic fixture or test assertion beyond the selected six migration patches changed.','All15,897 tracked file blobs were compared to the parent-bound index; only the same eight authorized source/migration paths differ.'],'execution':'Static reads/stdlib hashing, lexical and binary parsing, external review artifact only. No compiler/tests/project import or live edits.','checker':bind(O/'check.py')}
(O/'source-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(bind(O/'source-review.json')))
