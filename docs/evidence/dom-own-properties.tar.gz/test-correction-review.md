# Historical private-test correction review

Read-only source review confirms the two narrow updates. No reviewer test/engine execution.

- src/script/dom_bindings.rs:919–928: the div keeps its native hidden Boolean check; input now owns the disabled/checked Boolean-conversion checks. Separate div assignments assert exact Symbol/object expando identity, preserving the no-conversion requirement. HTMLDivElement has neither disabled nor checked, while HTMLInputElement declares both. [HTML input](https://html.spec.whatwg.org/multipage/input.html), [HTMLElement](https://html.spec.whatwg.org/multipage/dom.html#htmlelement).
- src/script.rs:12348: the untouched Document.title and Element.textContent instances have no own descriptor, so Undefined replaces the earlier policy refusal. Their regular IDL attributes belong on interface prototypes; this does not claim those prototypes are now implemented. All five Window refusal source strings and expected Unsupported results remain exact. [WebIDL attributes](https://webidl.spec.whatwg.org/#es-attributes).

The two original failures remain validation history. This correction changes authored private tests only; no approval of changes to frozen external sources/oracles is implied.

Reviewed main-workspace SHA-256:

- `src/script/dom_bindings.rs`: `d4fb3551f13734b052062e764a90860cc42a4613653a4d5cf99071c30ca98183`
- `src/script.rs`: `f87c52379746f1d4eff6ec9910b28fc8d82429a529668eea29bad25a04ec892b`
- `src/script/dom_own_properties.rs`: `b262f81d395ac1886c15504d8886df66f7a9624d8779fb7156fa6621e2929394`
