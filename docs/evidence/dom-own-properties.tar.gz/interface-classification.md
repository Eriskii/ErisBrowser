# Bounded native-attribute classification review

Read-only review, 2026-10-02. This covers names already synthesized by Eris's DOM Get/Set paths. It does not implement missing WebIDL prototypes, the complete HTML interface inventory, legacy named properties, or the complete semantics of existing form/URL/style attributes. Ordinary own descriptors must win before these fallback checks. After deletion, an absent-interface name must expose undefined, rather than the old overbroad getter.

| Defining interface | Writable / forwarding | Readonly |
|---|---|---|
| Node | textContent | nodeName, nodeType, parentNode, parentElement, firstChild, lastChild, childNodes, baseURI |
| ParentNode: Document, Element, DocumentFragment | — | children |
| Element | id, className; innerHTML, outerHTML; classList forwards to value | namespaceURI, tagName |
| HTMLElement | title, innerText, hidden | — |
| HTMLElement / SVGElement / MathMLElement | style forwards to cssText | — |
| Existing Document-specific inventory | title; body (setter currently absent) | defaultView, URL, documentURI, characterSet, charset, inputEncoding, compatMode, head, documentElement, readyState |
| Existing HTML details / template inventory | details.open, details.name | template.content |

Node inheritance includes Document, but several corresponding Document getters are missing in Eris. Preserve explicit unsupported behavior for those missing bindings; do not manufacture writable expandos or falsely claim a working getter. `baseURI` is inherited Node readonly even though today's binding only reads it on Document. SVGElement overrides className with an animated-string readonly attribute: the old generic string behavior is not full SVG conformance. OuterHTML, body, style, and classList have real setters; an unimplemented setter is not a getter-only readonly field.

Primary definitions: [DOM Node/Element/ParentNode](https://dom.spec.whatwg.org/), [HTML Document and HTMLElement](https://html.spec.whatwg.org/multipage/dom.html), [CSSOM style forwarding](https://drafts.csswg.org/cssom/#the-elementcssinlinestyle-mixin), [SVGElement](https://svgwg.org/svg2-draft/types.html#InterfaceSVGElement).

HTML-namespace tag classification for existing short names:

| Name | Tags with setters | Tags with readonly field |
|---|---|---|
| value | button, data, input, li, meter, option, output, param, progress, select, textarea | — |
| href | a, area, base, link | — |
| src | audio, video, embed, iframe, img, input, script, source, track, frame | — |
| type | a, button, embed, input, link, object, ol, script, source, li, param, style, ul | fieldset, output, select, textarea |
| checked | input | — |
| disabled | button, fieldset, input, optgroup, option, select, textarea, link, style | — |

The obsolete frame/param/li/ul/style members remain declared in current HTML. Area has no type. Numeric value fields, select/output state, URL resolution, and stylesheet disabled state need their own semantics; this table does not validate today's generic string/Boolean implementation. Other currently absent names remain future work.

Primary definitions: [form elements](https://html.spec.whatwg.org/multipage/form-elements.html), [input](https://html.spec.whatwg.org/multipage/input.html), [metadata elements](https://html.spec.whatwg.org/multipage/semantics.html), [obsolete members](https://html.spec.whatwg.org/multipage/obsolete.html), [element/interface index](https://html.spec.whatwg.org/multipage/indices.html).

GlobalEventHandlers applies to Document and HTML/SVG/MathML elements, not Text, Comment, or DocumentFragment. Existing event-name extensions need explicit qualification: onfocusin/onfocusout are absent from HTML's GlobalEventHandlers IDL; onunload belongs WindowEventHandlers (body/frameset exposure), not generic Element or Document. This review does not request an unrelated event-system expansion. [HTML event handlers](https://html.spec.whatwg.org/multipage/webappapis.html#event-handlers), [MathML interface mixins](https://w3c.github.io/mathml-core/#dom-and-javascript).

Concrete regression shapes: fragment.id = object; text.innerHTML = object; text.onclick = function; deleting each restores undefined; no conversion callback or listener installation. Absent-own readonly writes should fail only in strict mode and must not convert the RHS. Explicit own data/accessor definitions can shadow configurable inherited fields, including readonly ones, and deleting the shadow restores the original host behavior. Preserve the separately declared Document.location refusal, complete Document enumeration gap, and ordinary document.all scope decision.
