# DOM own-property source review

No remaining concrete finding in the reviewed scope after the two corrections below. Read-only review of the isolated worktree; no reviewer compiler, engine, or test execution. Runtime results remain separate evidence.

1. The initial native fallback classified Element fields and handlers on every Node. A shared Get/Set classifier now keeps inapplicable names ordinary on Text, Comment and DocumentFragment, and deletion reveals inherited lookup or undefined. Readonly fields reject assignment without converting its value. Existing unsupported setters remain distinct from readonly fields; style/classList forwarding, outerHTML and Document.body must not become ordinary readonly fields. The bounded classifier is not a complete WebIDL inventory.
2. The new DOM accessor setter path allocated a one-Value argument Vec without a local debit. The corrected dom_call_setter charges its typed storage and fallibly reserves before calling author code, for both string and symbol keys.

Descriptor conversion finishes before reading live target state. Nonconfigurable descriptor checks use the paid SameValue helper. Author getters/setters receive the public host receiver after map borrows are released; reservation/publication paths call no author code. New descriptors and host-map entries are published only after charged tree operations, order-vector/arena growth and fallible reservations. String and symbol descriptors share one lazy private bag. Missing reads/deletes and empty-bag direct reads do not create a bag or copy the key; nonempty direct-key conversion is prepaid. Tests for resource admission, callback cleanup, reentrancy, shared identity and delete restoration were inspected as source.

The original missing-prototype boundary remains: Document/Nodes still use the existing EventTarget chain, not real Document/Element/DocumentFragment prototypes. The private bag is not exposed as the receiver or prototype and does not admit host integrity or prototype mutation. Complete Document enumeration and Document.location remain explicit unsupported cases; document.all remains the declared ordinary-shadow scope choice. Existing SVG className, event-handler extensions, URL/form/numeric/stylesheet setter semantics remain legacy gaps, not new conformance claims. BTreeMap/Rc allocator boundaries remain prepaid, not generally recoverable allocation failures.

The primary-source interface table and caveats are in [interface-classification.md](precedence-review/interface-classification.md), with official DOM, HTML, WebIDL-related attribute and CSSOM sources. No separate consumer review is incorporated here.

Suggested bounded regression profiles: symbols (242 modes, tests/conformance/test262-symbols-current.json) and array-descriptors (3,574 modes, tests/conformance/test262-array-descriptors-current.json). These exercise shared symbol/reflection/descriptor/enumeration paths; the frozen DOM/Object.is cases and focused browser tests cover host behavior.

Reviewed source SHA-256:

- `src/script/dom_own_properties.rs`: `b262f81d395ac1886c15504d8886df66f7a9624d8779fb7156fa6621e2929394`
- `src/script/dom_own_properties/tests.rs`: `1c00dd5cc1358716a93f9329231bbc4e63273499f9e263f7648d5b8671efeb2d`
- `src/script.rs`: `5f57bf4a98a9f15960e13eb751efd34d3f1aebc100dcd87eef869911dfcfc4f4`
- `src/script/property_keys.rs`: `535a1bc0f4c8894759603d9a11529c02f314258e73d3240089a7f556e0a5f952`
- `src/script/own_keys.rs`: `ea454686281aa5105f3694a1deb73554c36d624117a8b1235a66425025c4125c`
- `src/script/object_is.rs`: `3bbe24fbe62b1236480372d12bdc2862ff8c73a881e5c232ed8b98ced4d82f77`

Machine-readable review: `precedence-review/final-source-review.json`, SHA-256 `46848ed79432e18f5ac40eba85b5eaf1da21801101d37dafcd1e2ec9dd3e55c1`.
