import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def check(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def total(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(r[i]) for r in rows) for i in range(3)]
assert total('full-default-188-2')==[1619,0,0] and total('full-native-198-1')==[1742,0,0]
source=read('main-source-final.json');assert len(source['files'])==18
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'final-source'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
comparison=read('node-comparison.json');assert not comparison['validation_failures']
s=comparison['summary'];assert s['established']['cases']['unchanged']==4088 and s['established']['controls']['unchanged']==372
assert s['new']['cases']['gains']==36 and s['new']['cases']['losses']==0 and s['new']['cases']['other_changes']==0
assert s['new']['controls']['before_healthy']==8 and s['new']['controls']['after_healthy']==16 and s['new']['controls']['gains']==8
summary=dict(kind='Ordinary exact Node data accessors',base_commit=source['base'],scope='Ordinary Node.nodeValue/textContent accessors with exact UTF-16 CharacterData and descendant reads; staged container replacement preserves detached identities/storage and charges both actual runtime counters on success/refusal.',source=source,release=release,final_validation={label:check(label) for label in ['full-default-188-2','full-native-198-1','clippy-native-198-1','clippy-presenter-188-1','format-198-final','release-adapter-188-1']},tests=dict(default=1619,native=1742,new_groups=42,focused_unique=83,focused_executions=87,failed=0,ignored=0),raw_bootstrap=read('source-ready.json')['bootstrap'],compatibility=dict(path='node-comparison.json',sha256=sha(BASE/'node-comparison.json'),summary=s),retained_corrections=['Measured descriptive bootstrap object/work assertions updated; no budgets or reset points changed.','Legacy UTF16-boundary textContent expectation explicitly migrated from display replacement to exact units; original bytes/assertions retained.','First full default run failed a second old lossy getter assertion in String.concat test; only that expected DOM string changed, and final full rerun passes. Production and frozen JS fixture bytes unchanged.'],boundaries=['Legacy innerText/title/textarea setters, append-string, attribute and parser writes remain separate work.','Standard BTree and URL/encoding/IDNA allocations remain infallible; logical work/heap charges are not process-wide allocation accounting or OOM recovery.','Two original PI host-prototype mutation expectations remain unmet.','Exact nonscalar HTML serialization, unit-aware editing, Attr/CDATA, complete Node interfaces and mutation reactions remain incomplete.','No new GPU performance or Chromium comparison. Full web compatibility and production security are not achieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p==BASE/'eris-js' or p.is_symlink() or name=='final-publication-review.json':continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/node-data.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
(ROOT/'docs/evidence/node-data.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
