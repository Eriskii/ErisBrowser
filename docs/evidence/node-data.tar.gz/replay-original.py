import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
HERE=Path(__file__).resolve().parent
PREP=Path('/tmp/eris-node-data-preparation-1')
source=(PREP/'cases.js').read_bytes();fixture_sha=hashlib.sha256(source).hexdigest()
assert fixture_sha=='0c4e8f1e7fa88114afa099052298fecdaa91a9698cc7a114883fc83407498851'
source_ready=json.loads((PREP/'source-ready.json').read_text())
expected=dict(status='complete',phase='runtime',error_type='',error_identity='')
matrix=[]
for row in source_ready['case_candidates']:
 name=row['name'];body=source+b'\nif(nodeDataCases.'+name.encode()+b'() !== true) throw new Error("case did not return true");'
 for mode in row['modes']:
  case=dict(id=name+'#'+mode,file='node-data-original.js',mode=mode,source=body,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=[])
  case['case_sha256']=runner.case_fingerprint(case)
  matrix.append((case,dict(id=case['id'],mode=mode,case_sha256=case['case_sha256'],source_sha256=hashlib.sha256(body).hexdigest(),fixture_sha256=fixture_sha,expected_observation=expected)))
frozen=dict(replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),source_ready_sha256=hashlib.sha256((PREP/'source-ready.json').read_bytes()).hexdigest(),cases=[row for _,row in matrix])
freeze=HERE/'original-replay-matrix.json'
if sys.argv[1]=='--prepare':
 with freeze.open('x') as f:json.dump(frozen,f,indent=2);f.write('\n')
 print('Frozen original8cases/16modes, no engine use')
 raise SystemExit
assert frozen==json.loads(freeze.read_text())
binary=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]);binary_sha=hashlib.sha256(binary.read_bytes()).hexdigest();rows=[]
for case,identity in matrix:
 result=runner.run_case(case,binary,3);result.update(identity)
 result['matches_expectation']=all(result.get('observation',{}).get(k)==v for k,v in expected.items());rows.append(result)
assert hashlib.sha256(binary.read_bytes()).hexdigest()==binary_sha
report=dict(binary_sha256=binary_sha,matrix_sha256=hashlib.sha256(freeze.read_bytes()).hexdigest(),replay_sha256=frozen['replay_sha256'],runner_sha256=frozen['runner_sha256'],cases=rows)
with output.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps(dict(total=len(rows),matched=sum(r['matches_expectation'] for r in rows),unmet=[dict(id=r['id'],observation=r.get('observation'),status=r['status']) for r in rows if not r['matches_expectation']]),indent=2))
