# Independent Node data fixtures

Prepared without compiler, parser, runtime or browser execution. The source bodies are standards-success expectations, not measured pass or quota claims. Each JavaScript case is a separate fresh realm in both sloppy and strict mode; load its complete definitions and invoke just the named function. Do not concatenate invocations into one author-work allowance.

`original-cases.js` is the byte-exact original eight-case `/tmp/eris-node-data-preparation-1/cases.js`, SHA-256 `0c4e8f1e7fa88114afa099052298fecdaa91a9698cc7a114883fc83407498851`. It defines `nodeDataCases`. The ten separately named additions in `exact-cases.js` define `exactNodeDataCases`. Every invocation expects ordinary completion returning `true`. Existing policy fixtures and their sources/expectations are not replaced or changed.

The additional cases retain literal UTF-16 arrays rather than deriving expected values through DOM helpers. They cover exact CharacterData identity; Text-only aggregation joining a pair across separate nodes while excluding Comment, PI and hosted template content; fresh Text identity even for repeated equal container assignments; retained detached descendants; nullable versus converted-nullish values; ignored kinds and ignored extra arguments; callback-added children and abrupt prefixes; saved intrinsics under own shadows; base selection; details groups after root separation; and template direct-child/content independence.

The base cases assume a fresh document without an earlier connected base. Absolute `.example` URL strings are inert data; no navigation or network operation is requested. The group cases use fresh names and do not assert synchronous toggle-event delivery. Doctype/invalid-ID and admission-failure tests require private Rust setup and remain outside these JavaScript bodies.

## Browser integration contract

Both HTML sources use the existing six-sample convention: sample centers `(20 + 50*i, 20)`, green after load, blue after one actual `#change` click; `#result` is `ready` then `6`; body class is `ready` then `clicked`. The click button is at top 60px. Assertions remain ordinary exceptions; no error is converted into a success marker. Keep each file as a separate Page/worker load.

`node-data.html` is 3,815 bytes. Integration should check:

* `#exact` contains one new Text after each nonempty replacement. Its load units are `[65,55296,66,56320]`, click units `[67,56320,68,55296]`. The NodeId changes across click; the old Text remains detached with its load units.
* The detached `#old-branch` remains in the node arena with its original Text and Comment children still parented to it, holding `[111,108,100,55296]` and `[56320]`. Find this detached branch through retained arena/snapshot data, not a connected-document selector.
* `#value` keeps one Text NodeId across click: `[86,55296]` becomes `[87,56320]` through the saved nodeValue setter. The result Text also keeps its NodeId.
* Display-list text and rendering use literal replacement projections `A\uFFFDB\uFFFD` / `C\uFFFDD\uFFFD`, and `V\uFFFD` / `W\uFFFD`. Inspect exact stored units before and after rendering. A literal scalar reference Page can provide full pixel comparison using the same public test-only reference construction pattern as the previous producer fixture; never rewrite the actual document to obtain its expected pixels.
* Confined worker snapshots preserve both the live and detached exact payloads and the same identity relationships. Direct/worker agreement alone is not the literal expected-value oracle.

`node-data-effects.html` is 4,212 bytes. Its separate, bounded connected-state checks are:

| State | Load | Click |
| --- | --- | --- |
| Page/document title | `ready` | `changed` |
| `#visible` Text | `ready`, fresh from parsed `initial` | `changed`, fresh NodeId; old Text detached |
| Display-list text color | green `(0,128,0)` | blue `(0,0,255)` |
| `#style-sample` background from replaced style text | green | blue |
| Clean `#field` raw text/value | `ready` | `changed` |
| Document base URL | `https://second.example/b/` | original document URL |
| Detached details + connected peer | both retain `open` in separate roots | still independent after peer close/reopen |
| Connected `#disclosure` summary | original `#old-summary` | no summary after replacement; old summary subtree retained |

The style sample is deliberately changed only by the replaced style element, not an inline mark. Assert a real `DrawCommand::Text` with the literal visible string/color and the sample pixels after layout. Check the title and clean textarea value using existing Page/worker snapshot hooks. For details cache coverage, call the existing `first_summary(disclosure)` before click, then require `None` afterward; a closed disclosure's replacement content remains hidden. The old summary Text stays parented to the detached summary. The tests do not require a particular default-summary localized label or timing of queued toggle notifications.

These witnesses establish the named tree and existing rendering/metadata consequences only. They do not establish complete synchronous children-changed reactions, MutationObservers, live Range/NodeIterator repair, CEReactions, slot assignment, dirty textarea behavior, arbitrary document ownership, full reflection, exact HTML serialization or native editing. Preserve any actual refusal/failure as an unmet ordinary-success observation instead of shortening a case after execution.

## Normative basis and consulted design

* [Node nodeValue](https://dom.spec.whatwg.org/#dom-node-nodevalue), [textContent](https://dom.spec.whatwg.org/#dom-node-textcontent), [string replace all](https://dom.spec.whatwg.org/#string-replace-all), and [descendant text content](https://dom.spec.whatwg.org/#concept-descendant-text-content).
* [Web IDL nullable conversion](https://webidl.spec.whatwg.org/#es-nullable-type) and [attribute bindings](https://webidl.spec.whatwg.org/#es-attributes).
* HTML [base](https://html.spec.whatwg.org/multipage/semantics.html#the-base-element), [title](https://html.spec.whatwg.org/multipage/semantics.html#the-title-element), [style](https://html.spec.whatwg.org/multipage/semantics.html#the-style-element), [textarea](https://html.spec.whatwg.org/multipage/form-elements.html#the-textarea-element), and [details](https://html.spec.whatwg.org/multipage/interactive-elements.html#the-details-element).

The current proposal and runtime handoff under `/tmp/eris-node-data-production-preparation-1` were read for scope and supported entry points. Expected strings, tree relationships and identity outcomes were authored from these normative operations; production outcomes were not observed.
