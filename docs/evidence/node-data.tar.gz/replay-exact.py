#!/usr/bin/env python3
"""Frozen independent Node data cases; --prepare/--verify never run an engine."""
import hashlib
import json
import sys
from pathlib import Path

if not __debug__:
    raise RuntimeError('run without Python optimization')
sys.dont_write_bytecode = True
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'tools'))
import test262_conformance as runner


def digest(data):
    return hashlib.sha256(data).hexdigest()


inventory_path = HERE / 'exact-replay-inputs.json'
inventory = json.loads(inventory_path.read_text())
fixture_path = HERE / inventory['fixture']
fixture = fixture_path.read_bytes()
assert digest(fixture) == inventory['fixture_sha256'] == 'c7e93bf860ff4f0a073de6cc1bdfb4eae7842dcd012623bed11807d9f915c8da'
assert inventory['collection'] == 'exactNodeDataCases'
assert len(inventory['cases']) == 10 and len(inventory['controls']) == 8
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
matrix = []
for kind, inputs in [('case', inventory['cases']), ('control', inventory['controls'])]:
    for row in inputs:
        assert row['modes'] == ['sloppy', 'strict']
        expected = row['expected_observation']
        assert expected == (complete if kind == 'case' or row['positive'] else wrong)
        body = (fixture + b'\nif(exactNodeDataCases.' + row['name'].encode() +
                b'() !== true) throw new Error("case did not return true");'
                if kind == 'case' else row['source'].encode())
        for mode in row['modes']:
            case = dict(id=row['name'] + '#' + mode,
                        file='node-data-exact.js' if kind == 'case' else 'controls',
                        mode=mode, source=body,
                        metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None), harness=[])
            case['case_sha256'] = runner.case_fingerprint(case)
            identity = dict(id=case['id'], mode=mode, kind=kind,
                            source_sha256=digest(body), case_sha256=case['case_sha256'],
                            expected_observation=expected)
            if kind == 'control':
                identity.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                                partner=row['pair'] + '-positive#' + mode)
            matrix.append((case, identity))
assert len(matrix) == 36 and len({case['id'] for case, _ in matrix}) == 36
bound_paths = [Path(__file__).resolve(), inventory_path, fixture_path,
               HERE / 'independent-preparation/source-ready.json',
               ROOT / 'tools/test262_conformance.py', ROOT / 'tools/html_conformance.py',
               ROOT / 'tools/import_test262.py']
bound_inputs = [dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p.read_bytes())) for p in bound_paths]
frozen = dict(fixture_sha256=digest(fixture), inventory_sha256=digest(inventory_path.read_bytes()),
              replay_sha256=digest(Path(__file__).read_bytes()),
              runner_sha256=digest(Path(runner.__file__).read_bytes()),
              bounds=dict(timeout_seconds=3, stdout_limit=96 * 1024, stderr_limit=64 * 1024,
                          execution='sequential inherited run_case'),
              bound_inputs=bound_inputs, rows=[identity for _, identity in matrix])
freeze = HERE / 'exact-replay-matrix.json'
if sys.argv[1:] == ['--prepare']:
    with freeze.open('x') as output:
        json.dump(frozen, output, indent=2)
        output.write('\n')
    print('Frozen 20 independent case modes and 16 paired control modes; no engine execution')
    raise SystemExit
assert frozen == json.loads(freeze.read_text())
if sys.argv[1:] == ['--verify']:
    print('Exact inputs/matrix verified; no engine execution')
    raise SystemExit
if len(sys.argv) != 3:
    raise SystemExit('usage: replay-exact.py --prepare | --verify | BINARY FRESH_OUTPUT')
binary = Path(sys.argv[1]).resolve()
output_path = Path(sys.argv[2])
if output_path.exists():
    raise FileExistsError(output_path)
binary_sha = digest(binary.read_bytes())
matrix_sha = digest(freeze.read_bytes())
records = []
for case, identity in matrix:
    result = runner.run_case(case, binary, 3)
    result.update(identity)
    result['matches_expectation'] = all(
        result.get('observation', {}).get(k) == v for k, v in identity['expected_observation'].items())
    records.append(result)

# Preserve completed observations even if a post-run binding changes or vanishes.
binding_failures = []
for row in bound_inputs + [dict(path=str(binary), sha256=binary_sha),
                           dict(path=str(freeze), sha256=matrix_sha)]:
    try:
        if digest(Path(row['path']).read_bytes()) != row['sha256']:
            binding_failures.append(dict(path=row['path'], reason='hash changed'))
    except OSError as error:
        binding_failures.append(dict(path=row['path'], reason=str(error)))
cases = [r for r in records if r['kind'] == 'case']
controls = [r for r in records if r['kind'] == 'control']
report = dict(binary_sha256=binary_sha, matrix_sha256=matrix_sha,
              **{k: v for k, v in frozen.items() if k != 'rows'},
              cases=cases, controls=controls, binding_failures=binding_failures)
with output_path.open('x') as output:
    json.dump(report, output, indent=2)
    output.write('\n')
print(json.dumps(dict(cases=sum(r['matches_expectation'] for r in cases), total=len(cases),
                      controls=sum(r['matches_expectation'] for r in controls), control_total=len(controls),
                      binding_failures=binding_failures,
                      unmet=[dict(id=r['id'], status=r['status'], observation=r.get('observation'))
                             for r in records if not r['matches_expectation']]), indent=2))
if binding_failures:
    raise SystemExit(2)
