    #[test]
    fn utf16_dom_boundary_is_explicitly_lossy_without_changing_script_values() {
        let mut document = Document::parse("<p id=out></p>");
        let mut runtime = Runtime::new();
        let result=runtime.execute(r#"const original='\ud800🦀\udfff'; const out=document.getElementById('out'); out.textContent=original; original;"#,&mut document).unwrap();
        assert_eq!(
            result,
            Value::String(JsString::from(vec![0xd800, 0xd83e, 0xdd80, 0xdfff]))
        );
        assert_eq!(
            document.text_content(document.query_selector("#out").unwrap()),
            "�🦀�"
        );
        assert_eq!(
            runtime.execute("out.textContent", &mut document).unwrap(),
            Value::String(JsString::from("�🦀�"))
        );
    }

