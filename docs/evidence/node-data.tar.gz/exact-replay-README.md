# Separate exact Node accessor replay

This runner is scratch-only and independent of the original eight-case inventory. `exact-replay-inputs.json` retains the ten additional named cases and four positive/wrong control pairs. Both script modes give 20 case observations and 16 control observations. Case source is the frozen `independent-preparation/exact-cases.js`; each invocation uses a fresh adapter process. No case is excluded and no expected-success case is replaced by a policy expectation.

`replay-exact.py --prepare` and `--verify` have completed without engine use. The original matrix is separate and unchanged. Preparation uses Python source/data operations only, not a JavaScript parser or compiler.

The four controls cover literal UTF-16 units, thrown-object identity, actual nodeValue accessors, and actual textContent replacement. Every wrong source is byte-exact positive source plus the same deliberate `throw new Error(...)` tail. Prerequisite refusal uses intrinsic TypeError, distinct from the required negative Error identity. Negative raw adapter status remains `failed` because these are explicit expected-observation controls, not rewritten Test262 negative metadata. Health means matching the declared complete or intrinsic-Error observation. Missing feature controls must stay visible in the baseline; do not relabel their expectation.

For parent-owned execution, use fresh output files:

```sh
python3 /tmp/eris-node-data-1/replay-exact.py /tmp/eris-dom-production-1/eris-js /tmp/eris-node-data-1/exact-before.json
python3 /tmp/eris-node-data-1/replay-exact.py FINAL_BINARY /tmp/eris-node-data-1/exact-after.json
```

The first command names the frozen producer release SHA-256 `4e613cf659787db1093ba1993bb4739e1ac0eb795d30ab164bbecca0df4ad207`. The final binary must be independently frozen before invoking the second command. This preparation has run neither command.

The runner reuses the unchanged `test262_conformance.run_case` and existing process helper with a three-second case timeout, 96 KiB stdout and 64 KiB stderr bounds. It runs cases sequentially. The frozen matrix binds its own code, fixture, inventory, fixture source receipt and all three imported tooling source files. Inputs, matrix and binary are rehashed after execution. Post-run binding failures are written alongside retained observations and cause exit 2. Fresh output uses exclusive creation. The parent should retain stdout/stderr and command/exit metadata as usual.

Timeout, adapter-error and static refusal rows with no `observation` are retained and do not match a success/exception expectation. Synthetic checks of the actual Python matching expression verify this without launching an adapter. The source-only review does not establish engine outcomes, runtime quota feasibility or process cleanup beyond the inherited helper contract. Existing limits, policies, test sources and the original eight-case matrix are unchanged.
