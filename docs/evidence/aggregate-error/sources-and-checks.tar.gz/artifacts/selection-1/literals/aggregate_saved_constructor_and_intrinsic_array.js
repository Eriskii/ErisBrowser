if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,O=Object,Arr=Array,p=A.prototype,a={},b={};
AggregateError=function(){throw new Error('global AggregateError');};Array=function(){throw new Error('global Array');};
var e=A([a,b]);check(O.getPrototypeOf(e)===p&&Arr.isArray(e.errors)&&O.getPrototypeOf(e.errors)===Arr.prototype&&e.errors[0]===a&&e.errors[1]===b);
var result='ok';
