function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,key=Symbol.toStringTag,subjects=[Error('m'),O.create(Error.prototype),Error.prototype],gets=0,throws=0;
for(var i=0;i<subjects.length;i++){
 var target=subjects[i],token={};
 O.defineProperty(target,key,{get:function(){check(this===target);gets++;return 'chosen';},configurable:true});
 check(tag.call(target)==='[object chosen]');
 O.defineProperty(target,key,{value:'',writable:true,configurable:true});check(tag.call(target)==='[object ]');
 O.defineProperty(target,key,{get:function(){check(this===target);throws++;throw token;},configurable:true});
 var same=false;try{tag.call(target);}catch(e){same=e===token;}check(same);delete target[key];
}
var result=gets+':'+throws;
