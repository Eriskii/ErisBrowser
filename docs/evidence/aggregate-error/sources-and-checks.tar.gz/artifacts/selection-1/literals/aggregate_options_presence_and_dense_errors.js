if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,h=Object.prototype.hasOwnProperty,src=[,undefined],e=A(src,undefined,{cause:undefined});
check(!h.call(e,'message')&&h.call(e,'cause')&&e.cause===undefined&&e.errors!==src&&e.errors.length===2&&h.call(e.errors,'0')&&h.call(e.errors,'1'));
var d=Object.getOwnPropertyDescriptor(e,'errors');check(d.writable&&!d.enumerable&&d.configurable);
var c=Object.getOwnPropertyDescriptor(e,'cause');check(c.writable&&!c.enumerable&&c.configurable);
Object.defineProperty(String.prototype,'cause',{get:function(){throw new Error('primitive options inspected');},configurable:true});
check(!h.call(A([],undefined,'x'),'cause'));delete String.prototype.cause;
check(!h.call(A([],undefined,null),'cause')&&!h.call(A([],undefined,undefined),'cause'));
var result='ok';
