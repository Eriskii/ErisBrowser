function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,key=Symbol.toStringTag,token={},poison={toString:function(){throw token;},valueOf:function(){throw token;}};
var genuine=Error('m'),fake=O.create(Error.prototype),subjects=[genuine,fake,Error.prototype],values=[undefined,null,1,false,Symbol('tag'),poison],checked=0;
for(var i=0;i<values.length;i++){
 for(var j=0;j<subjects.length;j++){
  O.defineProperty(subjects[j],key,{value:values[i],writable:true,configurable:true});
  check(tag.call(subjects[j])===(j===0?'[object Error]':'[object Object]'));checked++;
 }
}
var gets=0;O.defineProperty(genuine,key,{get:function(){check(this===genuine);gets++;return poison;},configurable:true});
check(tag.call(genuine)==='[object Error]');
for(var j=0;j<subjects.length;j++)delete subjects[j][key];
check(tag.call(genuine)==='[object Error]'&&tag.call(fake)==='[object Object]'&&tag.call(Error.prototype)==='[object Object]');
var result=checked+':'+gets;
