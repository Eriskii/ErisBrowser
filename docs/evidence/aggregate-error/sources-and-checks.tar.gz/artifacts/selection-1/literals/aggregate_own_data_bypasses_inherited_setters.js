if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,called=0,keys=['message','cause','errors'];
for(var i=0;i<keys.length;i++){var d=Object.create(null);d.set=function(){called++;};d.configurable=true;Object.defineProperty(A.prototype,keys[i],d);}
var payload={},cause={},e=A([payload],'m',{cause:cause});check(called===0&&e.message==='m'&&e.cause===cause&&e.errors[0]===payload);
check(Object.getOwnPropertyNames(e).join(',')==='message,cause,errors');var result='ok';
