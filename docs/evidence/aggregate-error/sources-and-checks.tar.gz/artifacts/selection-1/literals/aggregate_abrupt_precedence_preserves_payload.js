if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var stage=0;stage<4;stage++){
 var t='',token={},N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){t+='P';if(stage===0)throw token;return {};}});
 var msg={toString:function(){t+='M';if(stage===1)throw token;return 'm';}};
 var opts={get cause(){t+='C';if(stage===2)throw token;return 1;}};
 var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){t+='I';throw token;}});
 var same=false;try{Reflect.construct(AggregateError,[items,msg,opts],N);}catch(e){same=e===token;}check(same);rows.push(t);
}
var result=rows.join('|');
