if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,tag=Object.prototype.toString,e=A([]),fake=Object.create(A.prototype);
check(tag.call(e)==='[object Error]'&&tag.call(fake)==='[object Object]'&&tag.call(A.prototype)==='[object Object]');
Object.setPrototypeOf(e,null);check(tag.call(e)==='[object Error]');e[Symbol.toStringTag]='chosen';check(tag.call(e)==='[object chosen]');
var m=[];m.toString=function(){return 'override';};check(A([],m).message==='override');
var touched=0,type=false;try{A([],Symbol('message'),{get cause(){touched++;}});}catch(x){type=x instanceof TypeError;}check(type&&touched===0);var result='ok';
