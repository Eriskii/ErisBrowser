if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var rows=[];
for(var stage=0;stage<4;stage++){
 var token={},closed=0,it={next:function(){if(stage===0)throw token;if(stage===3)return 1;return {get done(){if(stage===1)throw token;return false;},get value(){throw token;}};}};
 Object.defineProperty(it,'return',{get:function(){closed++;throw new Error('close');}});var items={};items[Symbol.iterator]=function(){return it;};
 var same=false;try{AggregateError(items);}catch(e){same=stage===3?e instanceof TypeError:e===token;}check(same&&closed===0);rows.push('0');
}
var result=rows.join(',');
