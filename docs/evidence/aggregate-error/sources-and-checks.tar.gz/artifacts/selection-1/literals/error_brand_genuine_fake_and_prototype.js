function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,ctors=[Error,EvalError,RangeError,ReferenceError,SyntaxError,TypeError,URIError],called=[],built=[],fake=[];
for(var i=0;i<ctors.length;i++){
 var C=ctors[i],e=C('called'),b=new C('built'),f=O.create(C.prototype);
 check(tag.call(C.prototype)==='[object Object]'&&tag.call(f)==='[object Object]');
 f.name=C.name;f.message='called';check(tag.call(f)==='[object Object]');
 called.push(e);built.push(b);fake.push(f);
}
for(var i=0;i<called.length;i++){
 check(tag.call(called[i])==='[object Error]'&&tag.call(built[i])==='[object Error]');
 O.setPrototypeOf(called[i],null);check(tag.call(called[i])==='[object Error]');
}
var result=called.length+':'+built.length+':'+fake.length;
