if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var t='',token={},cause={},proto={},N=(function(){}).bind(null);
Object.defineProperty(N,'prototype',{get:function(){t+='P';return proto;}});
var msg={};msg[Symbol.toPrimitive]=function(h){check(h==='string');t+='M';return 'text';};
var inherited={};Object.defineProperty(inherited,'cause',{get:function(){t+='C';return cause;}});var options=Object.create(inherited);
var count=0,it={};Object.defineProperty(it,'next',{get:function(){t+='N';return function(){t+='S';if(count++===0)return {get done(){t+='D';return false;},get value(){t+='V';return token;}};return {get done(){t+='D';return true;}};};}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){t+='I';return function(){t+='i';return it;};}});
var e=Reflect.construct(AggregateError,[items,msg,options],N);
check(Object.getPrototypeOf(e)===proto&&e.message==='text'&&e.cause===cause&&e.errors[0]===token);
check(Object.getOwnPropertyNames(e).join(',')==='message,cause,errors');var result=t;
