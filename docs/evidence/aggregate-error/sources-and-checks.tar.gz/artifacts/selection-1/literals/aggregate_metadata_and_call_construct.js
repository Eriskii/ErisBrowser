if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,O=Object;
function flags(o,k,v,w,e,c){var d=O.getOwnPropertyDescriptor(o,k);check(d.value===v&&d.writable===w&&d.enumerable===e&&d.configurable===c);}
flags(globalThis,'AggregateError',A,true,false,true);flags(A,'length',2,false,false,true);flags(A,'name','AggregateError',false,false,true);flags(A,'prototype',A.prototype,false,false,false);
check(O.getPrototypeOf(A)===Error&&O.getPrototypeOf(A.prototype)===Error.prototype);
flags(A.prototype,'constructor',A,true,false,true);flags(A.prototype,'name','AggregateError',true,false,true);flags(A.prototype,'message','',true,false,true);
var a=A([]),b=new A([]);check(a!==b&&a.errors!==b.errors&&a instanceof A&&a instanceof Error&&b instanceof A);check(!O.prototype.hasOwnProperty.call(A.prototype,'errors'));
var result='ok';
