if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var A=AggregateError,N=(function(){}).bind(null),seen=0;Object.defineProperty(N,'prototype',{get:function(){seen++;return 1;}});
var e=Reflect.construct(A,[[]],N);check(seen===1&&Object.getPrototypeOf(e)===A.prototype);
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){throw new Error('must not inspect iterable');}});
var type=false;try{Reflect.construct(A,[items],()=>{});}catch(x){type=x instanceof TypeError;}check(type);var result='ok';
