if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var e=AggregateError('A\uD83D\uDE00');check(e.errors.length===2&&e.errors[0]==='A'&&e.errors[1]==='\uD83D\uDE00');
var inputs=[undefined,null,1,false],n=0;for(var i=0;i<inputs.length;i++){try{AggregateError(inputs[i]);}catch(x){check(x instanceof TypeError);n++;}}
check(n===4);var result='ok';
