"""Freeze source-only public literals before authoring their Rust conversion."""
from pathlib import Path
import hashlib
import json
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
H = P / 'selection-1'
OLD = Path('/tmp/eris-promise-any-plan-1')
W = Path('/tmp/eris-bootstrap-budget-plan-1/worktree')
BASE = '15226307b153da0857f80486d5f23c375b6b2add'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2) + '\n')

assert not (H / 'source-ready.json').exists()
assert sha((OLD / 'source-ready.json').read_bytes()) == '7846cdbc51142d5a1d658a9e1c93a0e0d199dcffc2a8a8dae41c6c3c1b697dd8'
old_seal = json.loads((OLD / 'source-ready.json').read_text())
old = json.loads((OLD / 'semantic-cases.json').read_text())
original = [row for row in old['cases'] if row['phase'] == 'aggregate']
assert len(original) == 10 and original == old['cases'][:10]
for row in original:
    assert sha(row['source'].encode()) == row['source_sha256']
    assert row['modes'] == ['sloppy', 'strict']
    assert row['source'].startswith("if(typeof AggregateError!=='function')throw new Error('AggregateError missing');\n")

extra_sources = [
    ('error_brand_genuine_fake_and_prototype', '''function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,ctors=[Error,EvalError,RangeError,ReferenceError,SyntaxError,TypeError,URIError],called=[],built=[],fake=[];
for(var i=0;i<ctors.length;i++){
 var C=ctors[i],e=C('called'),b=new C('built'),f=O.create(C.prototype);
 check(tag.call(C.prototype)==='[object Object]'&&tag.call(f)==='[object Object]');
 f.name=C.name;f.message='called';check(tag.call(f)==='[object Object]');
 called.push(e);built.push(b);fake.push(f);
}
for(var i=0;i<called.length;i++){
 check(tag.call(called[i])==='[object Error]'&&tag.call(built[i])==='[object Error]');
 O.setPrototypeOf(called[i],null);check(tag.call(called[i])==='[object Error]');
}
var result=called.length+':'+built.length+':'+fake.length;
''', '7:7:7'),
    ('error_tag_string_override_and_getter_identity', '''function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,key=Symbol.toStringTag,subjects=[Error('m'),O.create(Error.prototype),Error.prototype],gets=0,throws=0;
for(var i=0;i<subjects.length;i++){
 var target=subjects[i],token={};
 O.defineProperty(target,key,{get:function(){check(this===target);gets++;return 'chosen';},configurable:true});
 check(tag.call(target)==='[object chosen]');
 O.defineProperty(target,key,{value:'',writable:true,configurable:true});check(tag.call(target)==='[object ]');
 O.defineProperty(target,key,{get:function(){check(this===target);throws++;throw token;},configurable:true});
 var same=false;try{tag.call(target);}catch(e){same=e===token;}check(same);delete target[key];
}
var result=gets+':'+throws;
''', '3:3'),
    ('error_tag_non_string_falls_back_without_coercion', '''function check(v){if(!v)throw new Error('oracle');}
var O=Object,tag=O.prototype.toString,key=Symbol.toStringTag,token={},poison={toString:function(){throw token;},valueOf:function(){throw token;}};
var genuine=Error('m'),fake=O.create(Error.prototype),subjects=[genuine,fake,Error.prototype],values=[undefined,null,1,false,Symbol('tag'),poison],checked=0;
for(var i=0;i<values.length;i++){
 for(var j=0;j<subjects.length;j++){
  O.defineProperty(subjects[j],key,{value:values[i],writable:true,configurable:true});
  check(tag.call(subjects[j])===(j===0?'[object Error]':'[object Object]'));checked++;
 }
}
var gets=0;O.defineProperty(genuine,key,{get:function(){check(this===genuine);gets++;return poison;},configurable:true});
check(tag.call(genuine)==='[object Error]');
for(var j=0;j<subjects.length;j++)delete subjects[j][key];
check(tag.call(genuine)==='[object Error]'&&tag.call(fake)==='[object Object]'&&tag.call(Error.prototype)==='[object Object]');
var result=checked+':'+gets;
''', '18:1')
]
supplement = [{'name': name, 'phase': 'existing_error_branding', 'modes': ['sloppy', 'strict'], 'source': source, 'readback': 'result', 'expected': expected, 'source_sha256': sha(source.encode()), 'basis': 'Source-derived primary Object.prototype.toString/ErrorData and ordinary Error-prototype requirements; no execution.'} for name, source, expected in extra_sources]
cases = original + supplement
assert len({row['name'] for row in cases}) == 13
assert all('Promise.any' not in row['source'] and 'class ' not in row['source'] for row in cases)

inputs = []
for relative in ['src/script.rs', 'src/script/construction.rs', 'src/script/array_from.rs', 'src/script/promise_all_settled_semantic_tests.rs', 'src/script/promise_race_semantic_tests.rs', 'src/script/machine/calls.rs']:
    data = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + relative])
    path = H / 'source-snapshots' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    inputs.append({'relative_path': relative, 'published_base': BASE, 'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(), 'snapshot': bind(path)})

literal_files = []
for row in cases:
    source_path = H / 'literals' / (row['name'] + '.js')
    source_path.parent.mkdir(parents=True, exist_ok=True)
    source_path.write_text(row['source'])
    assert bind(source_path)['sha256'] == row['source_sha256']
    literal_files.append(bind(source_path))

write('cases.json', {'status': 'frozen_before_Rust_conversion_and_execution', 'cases': cases, 'groups': 13, 'planned_modes': 26, 'original_aggregate_cases_exact': 10, 'supplement_groups': 3})
write('source-bindings.json', {'status': 'published15226307 semantic/API source base; refresh after bootstrap-budget publication before import', 'files': inputs, 'retained_origins': [bind(OLD / name) for name in ['source-ready.json', 'semantic-cases.json', 'spec-sources.json', 'architecture.json', 'html-literal-review-1/review.json', 'error-source-audit-1/review.json']]})
spec = {
    'status': 'primary grammar/algorithm read; prospective applications only',
    'read_date': '2026-10-15',
    'sources': [
        {'url': 'https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.prototype.tostring', 'basis': 'An ErrorData slot supplies the default Error tag. A string Symbol.toStringTag overrides it; other values are not coerced. Getter throws propagate.'},
        {'url': 'https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-properties-of-the-error-prototype-object', 'basis': 'Error.prototype is an ordinary object without the instance ErrorData slot.'},
        {'url': 'https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-properties-of-the-nativeerror-prototype-objects', 'basis': 'The six NativeError prototypes are also unbranded ordinary objects; their constructed instances carry the slot.'},
        {'url': 'https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-aggregateerror', 'basis': 'NewTarget prototype selection precedes message conversion, cause installation and iterator collection. The errors array is fresh intrinsic storage.'}
    ],
    'inherited_primary_reads': bind(OLD / 'spec-sources.json'),
    'exclusions': ['Error.isError', 'SuppressedError', 'Promise.any', 'Proxy', 'class syntax', 'multi-realm behavior', 'host decoder/policy changes', 'runtime fee or startup installer selection']
}
write('primary-basis.json', spec)
rows = []
for row in cases:
    if row['phase'] == 'aggregate':
        parent = {'prediction': 'fail', 'first_boundary': "The initial missing-AggregateError guard throws Error('AggregateError missing') in the first sloppy source evaluation.", 'unreached': 'All subsequent statements, readback and strict iteration of this Rust group.'}
    elif row['name'] == 'error_brand_genuine_fake_and_prototype':
        parent = {'prediction': 'fail', 'first_boundary': 'After preparing seven called/constructed errors and checking all seven unbranded prototypes/fakes, the first genuine Error tag comparison sees Object and throws the oracle Error.', 'unreached': 'Remaining genuine checks, prototype-removal checks, readback and strict iteration.'}
    elif row['name'] == 'error_tag_string_override_and_getter_identity':
        parent = {'prediction': 'pass', 'first_boundary': 'Existing string-tag and throwing-getter path suffices in both modes.', 'unreached': None}
    else:
        parent = {'prediction': 'fail', 'first_boundary': 'The first non-string tag (undefined) on genuine Error falls back to Object, so the source oracle throws.', 'unreached': 'Remaining non-string matrix, non-string getter, deletion fallback, readback and strict iteration.'}
    rows.append({'name': row['name'], 'modes': row['modes'], 'expected': row['expected'], 'source_sha256': row['source_sha256'], 'parent': parent})
write('selection.json', {
    'status': 'written selection frozen before full Rust module',
    'scope': 'AggregateError-only public semantic cases plus explicit existing-Error Object.toString brand/tag controls.',
    'groups': 13, 'planned_mode_rows': 26,
    'parent_source_prediction': {'passed_groups': 1, 'failed_groups': 12, 'not_an_observation': True},
    'rows': rows,
    'conversion_contract': 'One Rust test per selected literal. Fresh Runtime::try_new and empty Document per sloppy/strict mode. Execute exact source with execute/execute_strict, require normal completion, then separately execute exact readback and compare Value::String(expected). Existing execute checkpoint behavior is reused; no counter resets, private seams, console assertions, host protocol or Promise.any code.',
    'registration_proposal': {'new_module': 'src/script/aggregate_error_semantic_tests.rs', 'declaration_owner': 'src/script.rs', 'fragment': '#[cfg(test)]\nmod aggregate_error_semantic_tests;\n'},
    'bounds': 'No full-conformance, cap, layout, quota, implementation or observed-result claim. Preserve first ten case objects exactly. Current parent source is published15226307; next publication refresh is additive.'
})
payloads = [bind(H / name) for name in ['cases.json', 'selection.json', 'source-bindings.json', 'primary-basis.json', 'derive.py']] + literal_files + [row['snapshot'] for row in inputs]
write('source-ready.json', {'status': 'literal_selection_source_ready_before_Rust_conversion', 'groups': 13, 'planned_modes': 26, 'published_semantic_source_base': BASE, 'files': payloads, 'parent_predicted': {'pass': 1, 'fail': 12}, 'checks': ['All ten applicable frozen AggregateError case objects and exact source hashes retained.', 'Three additional branding/tag groups are independently specified from primary algorithms and existing public APIs.', 'Six supporting Rust snapshots are read-only published Git blobs.', 'No executable Rust module has been authored at this selection seal; no project or JS engine execution or live source edit.']})
print(json.dumps(bind(H / 'source-ready.json')))
