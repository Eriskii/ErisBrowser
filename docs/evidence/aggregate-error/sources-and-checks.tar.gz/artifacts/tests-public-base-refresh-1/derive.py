"""Additive published-base refresh; no project code execution or live edits."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
H = P / 'tests-public-base-refresh-1'
OLD = P / 'tests-public-1'
W = P / 'worktree'
BASE = '383985eded4889cf354c69857cce6ae9cc9b354c'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

assert not (H / 'source-ready.json').exists()
assert bind(OLD / 'source-ready.json')['sha256'] == '518ef7e38be5ca62cfc7d40094488877abe85b04d36fa0df71872c901df456be'
before = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':src/script.rs'])
assert before == (W / 'src/script.rs').read_bytes()
old_before = (OLD / 'before/src/script.rs').read_bytes()
added = b'// Fixed intrinsic initialization has a separate finite work allowance.\n// Successful public construction resets author work to MAX_STEPS.\nconst BOOTSTRAP_STEPS: usize = 1_000_000;\n'
assert before.count(added) == 1
assert before.replace(added, b'', 1).replace(b'            steps: BOOTSTRAP_STEPS,', b'            steps: MAX_STEPS,', 1) == old_before
fragment = (OLD / 'registration-fragment.txt').read_bytes()
anchor = b'#[cfg(test)]\nmod bootstrap_tests;'
assert before.count(anchor) == 1 and fragment not in before
raw = before.replace(anchor, fragment + anchor, 1)
assert raw.replace(fragment, b'', 1) == before

before_path = H / 'before/src/script.rs'
raw_path = H / 'raw/src/script.rs'
diff_path = H / 'diffs/src__script.rs.patch'
module_rel = 'src/script/aggregate_error_semantic_tests.rs'
module_path = H / 'raw' / module_rel
for path in [before_path, raw_path, diff_path, module_path]:
    path.parent.mkdir(parents=True, exist_ok=True)
before_path.write_bytes(before)
raw_path.write_bytes(raw)
diff_path.write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile='a/src/script.rs', tofile='b/src/script.rs')))
module_path.write_bytes((OLD / 'raw' / module_rel).read_bytes())
assert module_path.read_bytes() == (OLD / 'raw' / module_rel).read_bytes()

source_joins = []
sources = json.loads((P / 'selection-1/source-bindings.json').read_text())['files']
for row in sources:
    relative = row['relative_path']
    new_bytes = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + relative])
    old_bytes = Path(row['snapshot']['path']).read_bytes()
    if relative != 'src/script.rs':
        assert new_bytes == old_bytes
    source_joins.append({'relative_path': relative, 'published_sha256': hashlib.sha256(new_bytes).hexdigest(), 'old_snapshot': row['snapshot'], 'unchanged': relative != 'src/script.rs'})

record = {
    'status': 'source_ready_unexecuted_additive_base_refresh',
    'published_base': BASE,
    'prior_semantic_base': '15226307b153da0857f80486d5f23c375b6b2add',
    'groups': 13,
    'planned_mode_rows': 26,
    'original_test_hold': bind(OLD / 'source-ready.json'),
    'original_literal_selection': bind(P / 'selection-1/source-ready.json'),
    'independent_original_peer': bind(P / 'public-script-review-1/source-review.json'),
    'files': [
        {'relative_path': module_rel, 'new_file': True, 'before': None, 'raw': bind(module_path), 'exact_original_raw': bind(OLD / 'raw' / module_rel)},
        {'relative_path': 'src/script.rs', 'new_file': False, 'before': bind(before_path), 'raw': bind(raw_path), 'diff': bind(diff_path)}
    ],
    'unchanged_contract': [bind(OLD / name) for name in ['roster.json', 'helper.rs.txt', 'registration-fragment.txt']],
    'published_source_joins': source_joins,
    'checks': ['All13 test bodies, literal/readback/expected bytes and helper are exact original module bytes.', 'Only registration before/raw bytes are rebased. Removing the same cfg(test) fragment exactly recovers published383985ed script.rs.', 'Compared with the prior registration base, script.rs contains only the published bootstrap constant/comment and uninitialized.steps change; five other bound semantic/API source snapshots are unchanged.', 'Parent prediction1pass12fail and later-row reachability remain source-derived and unexecuted. Original holds and peer remain immutable.', 'Only read-only Git blobs and inert source/hash/diff processing; no project/compiler/engine execution or live edits.'],
    'author': bind(Path(__file__))
}
(H / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(bind(H / 'source-ready.json')))
