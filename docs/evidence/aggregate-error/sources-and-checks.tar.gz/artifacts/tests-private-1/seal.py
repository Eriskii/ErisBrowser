"""Inert source binding and append composition; never imports project modules."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
O = P / 'tests-private-1'
BASE = '383985eded4889cf354c69857cce6ae9cc9b354c'
assert not (O / 'source-ready.json').exists(), 'immutable hold already exists'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def write(path, raw):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(raw.encode() if isinstance(raw, str) else raw)

def dump(path, value):
    write(path, json.dumps(value, indent=2) + '\n')

contract = P / 'runtime-contract-1/source-ready.json'
assert sha(contract.read_bytes()) == '658689209f51db4eb9eabbc7240cc4f7aadd1dcc67c84cf846250293f574e2a5'
production = P / 'runtime-production-1/source-ready.json'
assert sha(production.read_bytes()) == '408a9c73852fa10d4326de8f8d6218d1485bdd7a03a3fcb347cee0e275039ed6'
selected = json.loads((O / 'selection.json').read_text())
assert selected['planned_operations'] == sum(g['rows'] for g in selected['groups']) == 57
production_files = {f['relative']: f for f in json.loads(production.read_text())['files']}
files = []
registrations = []
for relative, declaration in [
    ('src/script/aggregate_error.rs', '\n#[cfg(test)]\nmod quota_tests;\n'),
    ('src/script/promises.rs', '\n#[cfg(test)]\nmod aggregate_error_coupling_tests;\n'),
]:
    binding = production_files[relative]['raw']
    origin = Path(binding['path'])
    assert bind(origin) == binding
    before = origin.read_bytes()
    assert declaration.strip().encode() not in before
    raw = before + declaration.encode()
    assert raw[:-len(declaration)] == before
    write(O / 'before' / relative, before)
    write(O / 'raw' / relative, raw)
    fragment = O / 'registrations' / (relative.replace('/', '__') + '.append.txt')
    write(fragment, declaration)
    registrations.append({'relative_path': relative, 'source_before': binding, 'append': bind(fragment)})

new_paths = ['src/script/aggregate_error/quota_tests.rs', 'src/script/promises/aggregate_error_coupling_tests.rs']
for relative in new_paths:
    write(O / 'before' / relative, b'')
for relative in new_paths + [r['relative_path'] for r in registrations]:
    before_path = O / 'before' / relative
    raw_path = O / 'raw' / relative
    before = before_path.read_bytes()
    raw = raw_path.read_bytes()
    diff = O / 'diffs' / (relative.replace('/', '__') + '.patch')
    write(diff, ''.join(difflib.unified_diff(before.decode().splitlines(True), raw.decode().splitlines(True),
                                          fromfile='/dev/null' if relative in new_paths else 'a/' + relative,
                                          tofile='b/' + relative)))
    files.append({'relative_path': relative, 'new_file': relative in new_paths,
                  'before': bind(before_path), 'raw': bind(raw_path), 'diff': bind(diff)})

roster = []
for relative in new_paths:
    source = (O / 'raw' / relative).read_text()
    for name in re.findall(r'#\[test\]\nfn (\w+)\(', source):
        selected_row = next(g for g in selected['groups'] if g['name'] == name)
        roster.append({'relative_path': relative, 'name': name, 'planned_operations': selected_row['rows']})
assert len(roster) == 6 and sum(r['planned_operations'] for r in roster) == 57
dump(O / 'roster.json', {'groups': 6, 'planned_operations': 57, 'rows': roster,
                       'scope': 'Private operations are not strict/sloppy mode rows; each measured row uses a fresh prepared fixture.',
                       'parent_eligibility': 'New private AggregateError API required; no claim these groups compile or run on the missing-API parent.'})
dump(O / 'registrations.json', registrations)

source_rows = []
for relative in [
    'src/script.rs', 'src/script/property_keys.rs', 'src/script/construction.rs',
    'src/script/dom_prototypes.rs', 'src/script/array_from.rs', 'src/script/microtasks.rs',
    'src/script/machine/calls.rs', 'src/script/promises.rs',
    'src/script/promises/factories.rs', 'src/script/promises/all_state.rs',
    'src/script/promises/install.rs', 'src/script/promises/all_allocation_probe.rs',
    'src/script/promises/all_quota_tests.rs', 'src/script/promises/all_semantics/race_quota_tests.rs',
]:
    raw = subprocess.check_output(['git', '-C', str(P / 'worktree'), 'show', BASE + ':' + relative])
    path = O / 'published-source' / relative
    write(path, raw)
    source_rows.append({'relative_path': relative, 'published_base': BASE, 'snapshot': bind(path)})
dump(O / 'source-bindings.json', source_rows)

notes = {
    'status': 'source-derived controls frozen before production import or candidate execution',
    'expectation_provenance': 'selection.json was written before the two Rust modules. Numeric rows come from selected runtime-contract-1 and independently inspected published helper bodies, not runtime-production-1 bodies or measurements.',
    'production_binding_scope': 'The production seal is used only for exact private API/registration lineage. Full before/raw registration copies are exact append compositions, not extra production edits.',
    'wrapper_fixture': 'A real bound ordinary constructor owns a prototype accessor. An inert Native fixture shares that metadata bag to exercise callable wrapper ownership. The selected receiver getter runs once during setup to prove it is live, then must remain at entered=1 throughout the measured refusal. Target/body/named-get/text stages before any Get are 2/16/2/26; text heap is100.',
    'instance_prefix': 'At work-one-short only the final old bag1/order stage refuses: slot reservation and base72+A+D are already paid, leaving MAX_HEAP-3K. At heap-one-short the final order charge records MAX_HEAP+1, drops temporary prototype, and publishes no object. Warm and cold include sizeof(ScriptObject) explicitly.',
    'reachable_properties': 'Message receives String; cause receives Native identity; errors receives a real intrinsic dense Array created during setup. Previous fields use the actual helper in legal order. No unreachable message1/message2/cause2 rows. Presence of earlier values/order is preserved on both refusal types.',
    'list_provenance': 'All incoming receipts come from actual acquire/next_value. Existing values entered through actual append_received. No test manufactures ReceivedAggregateValue. Fixture preparation has ample remaining normal allowance; only immediately before measured append are counters set. Growth8-to16 has physical spare deliberately, proving logical admission is still charged.',
    'malformed_provenance': 'Only documented private logical fields are corrupted after valid setup; physical0/logical8, minimum1, nonpower9, and paid len1/logical0 isolate bounded invariants. No oversized allocation or public state mutation is used.',
    'coupling_fixture': 'All reached author callbacks are arrows, so current calls.rs does not allocate unrelated arguments objects/Arrays. All iterator-result objects are prepared before the operation. The vector is made exactly full using the existing inert boxed-slice fixture technique; objects have two spare physical slots. Existing ArrayValues fail_once fires once; unchanged other reserve stages do not fire.',
    'terminal': 'Only wrapper tests and the natural shared-array path assert suspension. Direct private-helper refusal makes no independent sticky-latch assertion. Coupling uses with_author_entry and normal call, then two real suspended checkpoints; no execution/readback API reset, observer reset or heap reset follows refusal.',
    'array_reuse': 'Existing full five-stage array reserve suite, probe definitions/visibility and old helper bodies remain untouched. One new promises child reaches the existing private probe naturally.',
    'execution': 'No Rust compiler, formatter, JS engine, project tests, or project Python imports executed. No live worktree source writes. Inert external JSON/hash/diff/Git-read preparation only.',
}
dump(O / 'notes.json', notes)

paths = [O / n for n in ['selection.json', 'roster.json', 'registrations.json', 'notes.json', 'source-bindings.json', 'seal.py']]
paths.extend(Path(row['append']['path']) for row in registrations)
paths.extend(Path(row['snapshot']['path']) for row in source_rows)
ready = {'status': 'source_ready_unexecuted_focused_private_runtime_controls', 'published_base': BASE,
         'groups': 6, 'planned_operations': 57, 'files': files, 'artifacts': [bind(f) for f in paths],
         'origins': [bind(contract), bind(P / 'runtime-contract-1/derived-cuts.json'),
                     bind(P / 'runtime-contract-1/interfaces.json'), bind(P / 'runtime-contract-1/fixed-envelopes.json'),
                     bind(production)],
         'scope': 'Selected runtime controls only; installer and old-test migrations remain separately owned. Two new modules and two exact test-only append registrations.',
         'limitations': 'Expected source assertions, not observed results; requires new private API. Root alone imports and executes. Existing retained helper suites are not duplicated.'}
dump(O / 'source-ready.json', ready)
print(json.dumps(bind(O / 'source-ready.json')))
