from pathlib import Path
import hashlib,json,difflib
A=Path('/tmp/eris-aggregate-error-plan-1');W=A/'worktree';O=A/'documentation-1'
BASE='383985eded4889cf354c69857cce6ae9cc9b354c'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def insert(s,needle,added,before=False):
 assert s.count(needle)==1,needle
 return s.replace(needle,added+needle if before else needle+added,1)
chapter='''# AggregateError

`AggregateError(errors, message, options)` works as a call or with `new` in the
supported language subset. It collects a synchronous iterable into a fresh,
dense intrinsic Array, preserving input order and value identities. Empty input
produces an empty `errors` Array. The constructor has length two and inherits
from the saved `Error` constructor; its prototype inherits from the saved
`Error.prototype`.

Construction reads `NewTarget.prototype` before converting an optional message,
checking the optional cause and acquiring the iterable. An undefined message
creates no own `message` property. Object options use observable cause presence
and then a value read, including inherited properties and present undefined
values. Primitive options supply no cause. Created `message`, `cause` and
`errors` properties are writable and configurable but nonenumerable; inherited
setters cannot intercept their definitions.

Iterator acquisition reads the iterator method and caches `next`. Each reached
step reads `done` before `value`; an exhausted result's value is not read.
Ordinary acquisition, step and value errors propagate without `IteratorClose`.
The result Array uses the retained intrinsic Array machinery, so replacing the
global `Array` does not replace it. A saved callable constructor supplies its
own target even after the global or `prototype.constructor` changes. Existing
`Reflect.construct` validation and explicit NewTarget prototype selection remain
in effect; a non-object prototype falls back to the retained AggregateError
prototype.

Instances carry the existing private Error brand. `Object.prototype.toString`
now uses `[object Error]` as the fallback for genuine existing Error instances
and AggregateError instances. A string `Symbol.toStringTag` still overrides the
fallback; a non-string tag is not coerced. Getters retain their observable error
behavior. Copying a name, constructor or prototype does not forge the private
brand, and the ordinary AggregateError prototype itself is not branded. This
change does not otherwise extend the older Error constructors.

Construction shares the current author work and cumulative allocation budgets.
Its temporary value list grows through the existing checked planner, with a
maximum derived from the heap allowance and the actual Value size. Moving that
list into the existing dense-array helper grants no refund. Resource-limit and
unsupported-operation failures are terminal: later author steps and unstarted
jobs do not run, and later readbacks do not resume the suspended queue. No
iteration retry, author `return` call or in-operation budget reset is introduced.
These are bounded subset semantics, not a complete implementation of all
possible iterable, realm or language behavior.

The selected installation ledger adds **1,103 work units** and two appended
metadata bags. Its arithmetic gives **100,797 consumed units and 899,203
remaining** from the finite 1,000,000-unit trusted allowance. Public construction
still returns 100,000 author work units, and both phases share the cumulative
8 MiB allocation ceiling. The typed heap delta is
`2*S + 2*A + 2*D + 6*K + 2*Bpp + N + 3*Bstatic + 4*Bnative + 4*Bglobal + 2634`.
Here `S`, `A`, `D`, `K` and `N` are the sizes of ScriptObject,
Option<AbortSlot>, Option<f64>, PropertyKey and Native; each `B` is the existing
typed B-tree node allowance for its property, static-key, native-map or global
map. On the previously observed x86_64 Linux layouts this is **17,554 accounted
bytes**, including both upfront object slots. These figures are source-derived
accounting, not process-memory or timing measurements.

Installation preserves every preceding object ID and map entry. The new
prototype and constructor bag follow them, and the global is published last.
A failed initialization can retain prepaid private metadata or earlier map
entries inside a realm that is never returned. Existing raw tests retain their
99,693, 99,694 and 100,000 inputs as refusals and add 100,796/100,797 and the
default 1,000,000 boundaries. Seventeen existing test files receive selected
count/ledger changes, with four explicit boundary-name renames. Earlier-stage
fixtures exclude only the new late entry they cannot retain; their original
order, isolated fees and early 25-prototype assertions remain intact.

The authored controls cover observable ordering and identities, Error tag
fallback, terminal suspension, and private work/storage admission. Parent runs
passed the string-tag override group in both modes. The other thirteen semantic
groups and five terminal groups stopped in their first sloppy attempt; later
readbacks and strict attempts were not reached. Their generic Error diagnostics
do not identify every internal check statement.

PENDING_FINAL_RUST_RESULTS

PENDING_FINAL_REPLAY_RESULTS

`Promise.any`, classes, Proxy, async iteration and multiple realms remain
unfinished. The optional conformance host's existing response decoder rejects
an uncaught `AggregateError` intrinsic identity; this checkpoint does not widen
that decoder or its final-unhandled-rejection policy. Caught JavaScript values
retain their identity, but no new AggregateError upstream profile or pass count
is claimed. This is not full ECMAScript compatibility, production security,
a CPU/GPU performance result or an RSS bound. Historical checkpoint records and
archives keep their original counts and limits.

The [evidence manifest](evidence/aggregate-error/manifest.json) and
[source/check archive](evidence/aggregate-error/sources-and-checks.tar.gz) are the
publication targets for the selected sources, controls and observed receipts.
'''
changes={}
rel='README.md';s=(W/rel).read_text();needle='notifications remain unfinished.\n'
added='''
[`AggregateError`](docs/aggregate-error.md) adds callable and constructed errors
with ordered synchronous iterable collection, optional message/cause properties
and a fresh intrinsic `errors` Array. Genuine Error instances now receive the
Error fallback tag from `Object.prototype.toString`. `Promise.any` and the
conformance host's uncaught AggregateError identity decoder remain separate work.
''';changes[rel]=insert(s,needle,added)
rel='docs/COMPATIBILITY.md';s=(W/rel).read_text();needle='not a full ECMAScript conformance result.\n'
added='''
[`AggregateError`](aggregate-error.md) supports call/new construction, optional
message and cause, cached synchronous iteration and a fresh intrinsic errors
Array. It preserves observable operation order and ordinary thrown values;
iterator failures do not trigger closing. Genuine Error instances now have the
Error fallback `Object.prototype.toString` tag, while string tag overrides and
ordinary fake objects retain their distinctions. `Promise.any` is still absent,
and the unchanged conformance decoder rejects an uncaught AggregateError
intrinsic identity. This adds no full-standard or new upstream result claim.
''';changes[rel]=insert(s,needle,added)
rel='docs/ROADMAP.md';s=(W/rel).read_text();needle='Remaining asynchronous work\n'
added='''[`AggregateError`](aggregate-error.md) now supplies ordered iterable errors,
message/cause handling and genuine Error fallback branding under the existing
limits. `Promise.any` and host decoding of uncaught AggregateError identities
remain separate follow-ups; the constructor alone does not implement either.
''';changes[rel]=insert(s,needle,added,True)
rel='docs/SECURITY.md';s=(W/rel).read_text();needle='## Representative limits\n'
added='''[AggregateError construction](aggregate-error.md) uses the existing work,
checked-growth and cumulative heap policies. Ordinary iterable failures
propagate without author iterator closing; resource and unsupported-operation
failures retain terminal queue suspension. Its two late metadata bags consume
the trusted initialization allowance, and only successful bootstrap returns an
author runtime. Partial metadata after refusal is not rolled back into a usable
realm. This adds no renderer authority or host decoder acceptance, and the
logical ledger does not account for all allocator overhead or process memory.

''';changes[rel]=insert(s,needle,added,True)
rel='docs/runtime-budget-boundary.md';s=(W/rel).read_text();needle='## Original boundary checkpoint\n'
added='''The [AggregateError installation](aggregate-error.md) adds 1,103 charged work
units. Its selected ledger totals 100,797 consumed units and leaves 899,203
from trusted initialization; the returned author's 100,000 units are unchanged.
The typed heap increment includes two upfront object slots and three late map
entries, without a new Runtime field. Former 99,693/99,694/100,000 raw inputs
remain explicit refusal controls beside the new exact and one-short boundaries.

''';changes[rel]=insert(s,needle,added,True)
rel='docs/VALIDATION.md';s=(W/rel).read_text();needle='# Validation record\n\n'
added='''## AggregateError and Error fallback branding

The [AggregateError checkpoint](aggregate-error.md) adds call/new construction,
ordered synchronous iterable collection, message/cause properties and genuine
Error fallback tagging. Its selected installation ledger adds 1,103 work units
and two metadata bags, with the existing trusted/author/heap limits unchanged.

The initial thirteen-group public parent run passed one string-tag override
group and failed twelve groups. The additive cached-next group failed too.
Five terminal-policy groups also failed at the initial missing-API boundary.
Each failed group stopped in its first sloppy attempt; later readbacks and
strict attempts were not reached. Generic Error diagnostics alone do not locate
every internal assertion. The parent records remain retained.

PENDING_FINAL_VALIDATION_RESULTS

PENDING_FINAL_VALIDATION_REPLAY

There is no new AggregateError upstream selection or transport acceptance
claim. The unchanged host decoder rejects an uncaught AggregateError intrinsic
identity. The evidence links in the chapter bind the final published checkpoint;
the historical sections below retain their original measurements.

''';changes[rel]=insert(s,needle,added)
changes['docs/aggregate-error.md']=chapter
roster=[]
for rel,raw in changes.items():
 p=W/rel;before=p.read_text() if p.exists() else ''
 if before:
  # The BC documentation hold provides the exact published before text.
  prior=Path('/tmp/eris-bootstrap-budget-plan-1/documentation-1/raw')/rel
  assert prior.exists() and prior.read_text()==before,rel
 put(O/'before'/rel,before);put(O/'raw'/rel,raw)
 diff=''.join(difflib.unified_diff(before.splitlines(keepends=True),raw.splitlines(keepends=True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel))
 put(O/'diffs'/(rel+'.patch'),diff)
 roster.append({'relative_path':rel,'new':not bool(before),'before':bind(O/'before'/rel),'raw':bind(O/'raw'/rel),'diff':bind(O/'diffs'/(rel+'.patch'))})
# Exact historical suffix and narrow insert inverses.
old=(O/'before/docs/VALIDATION.md').read_text();new=(O/'raw/docs/VALIDATION.md').read_text();assert new[new.index('## Separate trusted bootstrap allowance'):]==old[old.index('## Separate trusted bootstrap allowance'):]
old=(O/'before/docs/runtime-budget-boundary.md').read_text();new=(O/'raw/docs/runtime-budget-boundary.md').read_text();marker='## Original boundary checkpoint';assert new[new.index(marker):]==old[old.index(marker):]
for rel in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md']:
 old=(O/'before'/rel).read_text();new=(O/'raw'/rel).read_text();i=next((i for i,(a,b) in enumerate(zip(old,new)) if a!=b),len(old));delta=len(new)-len(old);assert delta>0 and new[:i]+new[i+delta:]==old,rel
markers=[]
for rel in changes:
 for line in (O/'raw'/rel).read_text().splitlines():
  if line.startswith('PENDING_'):markers.append({'path':rel,'marker':line})
assert len(markers)==4
checks={'status':'draft_source_checks_complete_pending_actual_final_validation','published_before_base':BASE,'paths':7,'existing6_before_files_exact_to_published_BC_documentation_hold':True,'historical_validation_suffix_exact':True,'runtime_budget_historical_suffix_exact':True,'four_other_existing_docs_insertions_only':True,'placeholders':markers,'pending_only':'Final focused/full/strict/release and replay outcome statements. No projected suite total is presented as observed.','source_accounting_qualification':'1103/100797/899203 and typed17554 are labeled selected/source-derived; actual diagnostic receipt may strengthen final wording.','host_decoder_source':'tools/test262_conformance.py INTRINSIC_ERRORS and both unknown-intrinsic checks remain unchanged; AggregateError absent from accepted set.','chapter_words':len(chapter.split()),'evidence_links':'Relative aggregate-error manifest/archive destinations are planned publication paths; no artifact-existence claim.'}
put(O/'checks.json',json.dumps(checks,indent=2)+'\n')
inputs=['source-parent.json','runtime-production-1/source-ready.json','install-production-1/source-ready.json','install-ledger-1/ledger.json','root/parent-public-validation-1.json','root/parent-public-supplement-validation-1.json','root/parent-abort-validation-1.json','tests-install-1/source-ready.json','tests-install-review-1/source-review.json']
put(O/'source-ready.json',json.dumps({'status':'immutable_documentation_draft_pending_actual_results_not_for_publication','base':BASE,'files':roster,'inputs':[bind(A/x) for x in inputs],'additional_source':bind(W/'tools/test262_conformance.py'),'checks':bind(O/'checks.json'),'author':bind(O/'author.py'),'placeholders':markers,'finalization':'Create a separate additive final documentation hold after root supplies actual final validation/replay receipts; retain this draft and every historical suffix.'},indent=2)+'\n')
print(json.dumps({'hold':bind(O/'source-ready.json'),'chapter_words':len(chapter.split()),'markers':markers},indent=2))
