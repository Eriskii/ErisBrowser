from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

A = Path('/tmp/eris-aggregate-error-plan-1')
P = A / 'documentation-2'
O = A / 'documentation-3'
seal = '--seal' in sys.argv
assert not (O / 'source-ready.json').exists(), 'Retain the immutable sealed hold.'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def put(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)

def read(relative):
    return json.loads((A / relative).read_text())

def checked_receipt(label):
    path = A / 'validation' / (label + '.json')
    receipt = json.loads(path.read_text())
    log = A / 'validation' / receipt['log']
    assert receipt['exit'] == 0
    assert receipt['sha256'] == bind(log)['sha256']
    return path, log

chapter_corrections = '''Retained attempts include an unsigned arithmetic compile failure,
a bootstrap run with 47 passes and six earlier-stage DataView fixture failures,
and a strict lint refusal. The corrections reorder unchanged ledger terms,
exclude only the new late prototype from the earlier DataView stage, and borrow
a one-element setup slice instead of cloning it. Separately, source review
moved an iterator arrow into setup before measurement so its metadata could not
distort the private allocation witness. All selected traces, quota expectations
and production behavior remain unchanged. The corrected bootstrap-focused run
passes all 53 tests; the earlier records remain retained.

The raw diagnostic records 899,203 work remaining and 1,761,871 accounted bytes,
confirming the 1,103-work and 17,554-byte deltas against the published parent.

'''
chapter_rust = '''The final candidate passes **3,159 Rust 1.88 default tests** and **3,513
Rust 1.99 tests with `test262-host,vulkan-raster`**. Each complete
`--include-ignored` run has 52 result rows with no failed, ignored or filtered
tests. Both preserve the parent roster after four selected boundary-name
renames and add exactly 27 groups: fourteen semantic, five terminal, two
installer and six private runtime groups. The installer controls cover 23
operation rows; the private runtime controls cover 57. Both full suites were
rerun after the lint-only fixture correction. Strict all-target Clippy passes
in both configurations, and formatting passes.'''
chapter_replay = '''The rebuilt Rust 1.88 release host adapter preserves all **1,050 case records
and 348 harness records** across the four existing Promise profiles. Complete
arrays match the published parent, including failed and unsupported outcomes;
all controls verify. There are no regressions, improvements or baseline changes.
The tooling, corpora and baselines remain unchanged; no separate full Python
suite rerun is claimed.'''
validation_corrections = '''Retained corrections cover an initial unsigned arithmetic compile failure,
an independently identified iterator-arrow setup allocation, six
earlier-stage DataView fixture failures, and a strict lint refusal for a needless
setup clone. They respectively reorder unchanged accounting terms, precreate
the arrow before measurement, exclude only the late prototype from the old
stage, and borrow the one-element slice. Production code and selected semantic
and quota expectations remain unchanged. The earlier 33-test focused pass and
47-pass/six-fail bootstrap run remain retained; the corrected bootstrap run
passes all 53 tests.

'''
validation_rust = '''The final source passes **3,159 Rust 1.88 default tests** and **3,513 Rust 1.99
tests with `test262-host,vulkan-raster`** in complete `--include-ignored` runs.
Each has 52 result rows and no failed, ignored or filtered tests. Exact parent
rosters survive four selected boundary-name renames and gain 27 groups. Both
full suites were rerun after the lint-only fixture correction. Strict all-target
Clippy passes in both configurations, and formatting passes. Raw diagnostics
record 100,797 consumed trusted work units, 899,203 remaining and 1,761,871
accounted bytes; successful public construction still returns 100,000 author
work units under the unchanged shared 8 MiB heap ceiling.'''
validation_replay = '''The rebuilt Rust 1.88 release host adapter preserves all **1,050 case records
and 348 harness records** across four existing Promise profiles. Complete arrays
match the published parent, including failed and unsupported outcomes; all
controls verify. There are no regressions, improvements or baseline changes.
No separate full Python suite rerun is claimed; its tools, corpora and baselines
remain unchanged.'''

files = []
for oldraw in sorted((P / 'raw').rglob('*.md')):
    rel = str(oldraw.relative_to(P / 'raw'))
    before = (P / 'before' / rel).read_text()
    old = oldraw.read_text()
    text = old
    if rel == 'docs/aggregate-error.md':
        text = text.replace(
            'remaining** from the finite 1,000,000-unit trusted allowance. Successful public Runtime construction\n'
            'still returns 100,000 author work units, and both phases share the cumulative\n',
            'remaining** from the finite 1,000,000-unit trusted allowance. Successful\n'
            'public Runtime construction still returns 100,000 author work units, and\n'
            'both phases share the cumulative\n')
        text = text.replace('both phases share the cumulative\n8 MiB allocation ceiling.',
                            'both phases share the cumulative 8 MiB allocation ceiling.')
        start = text.index('The first candidate attempt stopped at compile time:')
        end = text.index('PENDING_FINAL_RUST_RESULTS', start)
        text = text[:start] + chapter_corrections + text[end:]
        assert text.count('PENDING_FINAL_RUST_RESULTS') == 1
        text = text.replace('PENDING_FINAL_RUST_RESULTS', chapter_rust)
        if seal:
            text = text.replace('PENDING_FINAL_REPLAY_RESULTS', chapter_replay)
    elif rel == 'docs/VALIDATION.md':
        start = text.index('The first candidate attempt failed before tests')
        end = text.index('PENDING_FINAL_VALIDATION_RESULTS', start)
        text = text[:start] + validation_corrections + text[end:]
        assert text.count('PENDING_FINAL_VALIDATION_RESULTS') == 1
        text = text.replace('PENDING_FINAL_VALIDATION_RESULTS', validation_rust)
        if seal:
            text = text.replace('PENDING_FINAL_VALIDATION_REPLAY', validation_replay)
    put(O / 'before' / rel, before)
    put(O / 'raw' / rel, text)
    patch = ''.join(difflib.unified_diff(before.splitlines(keepends=True), text.splitlines(keepends=True),
                                        fromfile='a/' + rel if before else '/dev/null', tofile='b/' + rel))
    put(O / 'diffs' / (rel + '.patch'), patch)
    if text != old:
        correction = ''.join(difflib.unified_diff(old.splitlines(keepends=True), text.splitlines(keepends=True),
                                                 fromfile='documentation-2/' + rel, tofile='documentation-3/' + rel))
        put(O / 'corrections' / (rel + '.patch'), correction)
    files.append({'relative_path': rel, 'before': bind(O / 'before' / rel), 'raw': bind(O / 'raw' / rel),
                  'diff': bind(O / 'diffs' / (rel + '.patch')), 'same_as_prior_draft': text == old})

assert len(files) == 7 and sum(not row['same_as_prior_draft'] for row in files) == 2
for rel, marker in [('docs/VALIDATION.md', '## Separate trusted bootstrap allowance'),
                    ('docs/runtime-budget-boundary.md', '## Original boundary checkpoint')]:
    before = (O / 'before' / rel).read_text()
    after = (O / 'raw' / rel).read_text()
    assert before[before.index(marker):] == after[after.index(marker):]

inputs = []
for label, expected in [('default-full-2', 3159), ('host-vulkan-full-2', 3513)]:
    receipt, log = checked_receipt(label)
    rows = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', log.read_text(), re.M)
    assert len(rows) == 52
    assert [sum(int(row[i]) for row in rows) for i in range(5)] == [expected, 0, 0, 0, 0]
    inputs += [receipt, log]
for label in ['default-clippy-2', 'host-vulkan-clippy-2', 'format-check-2']:
    inputs += list(checked_receipt(label))

lint = read('lint-correction-1/source-ready.json')
old_lint = Path(lint['before']['path']).read_text()
new_lint = Path(lint['raw']['path']).read_text()
assert old_lint.replace('&[queued.clone()]', 'std::slice::from_ref(&queued)', 1) == new_lint
delta = read('root/final-candidate-delta.json')
assert delta['changed_paths'] == ['src/script/promises/aggregate_error_coupling_tests.rs']
assert delta['production_unchanged'] and delta['expectations_unchanged']
observation = read('root/candidate-observation-1.json')
assert [observation[k] for k in ['raw_remaining', 'consumed_work', 'accounted_heap', 'work_delta', 'accounted_heap_delta', 'public_remaining']] == [899203, 100797, 1761871, 1103, 17554, 100000]
rust = read('root/rust-validation.json')
assert rust['status'] == 'complete' and rust['new_test_groups'] == 27
assert len(rust['selected_existing_test_renames']) == 4
assert all(row['exact_old_roster_after_selected_renames_plus_new'] for row in rust['comparisons'])
assert [row['current']['totals'] for row in rust['comparisons']] == [[3159, 0, 0, 0, 0], [3513, 0, 0, 0, 0]]
assert [Path(row['current']['receipt']['path']).name for row in rust['comparisons']] == ['default-full-2.json', 'host-vulkan-full-2.json']
inputs += [A / rel for rel in ['root/rust-validation.json', 'root/final-candidate-delta.json', 'root/candidate-observation-1.json',
    'root/focused-validation.json', 'root/parent-public-validation-1.json', 'root/parent-public-supplement-validation-1.json',
    'root/parent-abort-validation-1.json', 'migration-correction-1/source-ready.json', 'migration-correction-1/layout-review.json',
    'tests-private-correction-1/source-ready.json', 'tests-private-correction-1/reason.json', 'tests-private-correction-1/script-review.json',
    'stage-fixture-correction-1/source-ready.json', 'stage-fixture-correction-1/layout-review.json',
    'lint-correction-1/source-ready.json', 'validation/host-vulkan-clippy-1.json', 'validation/host-vulkan-clippy-1.log']]
markers = [{'path': row['relative_path'], 'marker': line}
           for row in files for line in Path(row['raw']['path']).read_text().splitlines() if line.startswith('PENDING_')]
assert len(markers) == (0 if seal else 2)

if seal:
    final = read('root/final-validation.json')
    replay = read('root/replay-validation.json')
    assert final['status'] == 'pass' and replay['status'] == 'pass'
    assert final['default_passed'] == 3159 and final['host_vulkan_passed'] == 3513
    assert final['selected_source_inputs'] == 1682 and len(final['changed_source_paths']) == 33
    assert [final[k] for k in ['existing_test_migration_paths', 'existing_migration_groups', 'new_test_groups', 'selected_existing_renames']] == [18, 126, 27, 4]
    assert [final[k] for k in ['exact_case_records', 'exact_harness_records', 'baseline_changes']] == [1050, 348, 0]
    assert replay['exact_cases'] == 1050 and replay['exact_controls'] == 348
    assert read('source-final.json') == read('source-candidate-4.json')
    assert final['source']['sha256'] == bind(A / 'source-final.json')['sha256']
    assert final['replay_validation']['sha256'] == bind(A / 'root/replay-validation.json')['sha256']
    assert final['roster_validation']['sha256'] == bind(A / 'root/rust-validation.json')['sha256']
    binary = Path(replay['binary']['path'])
    assert bind(binary)['sha256'] == replay['binary']['sha256'] == final['release_binary']['sha256']
    assert bind(binary)['bytes'] == 4465368
    release_receipt, release_log = checked_receipt('host-release-1')
    build = json.loads(release_receipt.read_text())
    assert '+1.88.0' in build['command'] and '--release' in build['command'] and 'test262-host' in build['command']
    inputs += [release_receipt, release_log]
    cases = controls = 0
    replay_rows = []
    for row in replay['comparisons']:
        for label in ['parent', 'report', 'receipt', 'log']:
            path = Path(row[label]['path'])
            assert bind(path) == row[label]
            inputs.append(path)
        previous = json.loads(Path(row['parent']['path']).read_text())
        current = json.loads(Path(row['report']['path']).read_text())
        assert previous['cases'] == current['cases'] and previous['harness_preflight'] == current['harness_preflight']
        for field in ['counts', 'runner_policy', 'runner_policy_sha256', 'corpus_manifest_sha256', 'revision']:
            assert previous[field] == current[field]
        assert all(item['verified'] for item in current['harness_preflight'])
        assert current['harness_preflight_passed'] and current['regressions'] == current['improvements'] == []
        assert row['regressions'] == row['improvements'] == 0
        assert current['binary_sha256'] == bind(binary)['sha256']
        assert len(current['cases']) == row['cases'] and len(current['harness_preflight']) == row['controls']
        cases += len(current['cases'])
        controls += len(current['harness_preflight'])
        replay_rows.append({'profile': row['profile'], 'cases': row['cases'], 'controls': row['controls'], 'counts': current['counts'], 'complete_arrays_and_policy_exact': True})
    assert cases == 1050 and controls == 348 and len(replay_rows) == 4
    previous_source = read('source-parent.json')['source_sha256']
    final_source = read('source-final.json')['source_sha256']
    tooling_paths = [path for path in previous_source if path.startswith('tools/') or path.startswith('tests/conformance/')]
    assert all(final_source[path] == previous_source[path] for path in tooling_paths)
    inputs += [A / rel for rel in ['root/final-validation.json', 'root/replay-validation.json', 'source-final.json', 'source-candidate-4.json']]
    checks = {'five_other_drafts_exact': True, 'published_before_all_exact': True,
        'historical_validation_and_budget_suffixes_exact': True, 'all_four_corrections_retained': True,
        'final_candidate4_full2_and_strict2_only': True, 'observed_raw_ledger_reconciles_selected_delta': True,
        'parent_unreached_attempts_qualified': True, 'no_new_upstream_or_decoder_claim': True,
        'no_python_suite_rerun_claim': True, 'evidence_links_remain_relative_publication_targets': True,
        'selected_source_inventory_not_full_build_graph': True, 'no_placeholders': True,
        'replay_comparisons': replay_rows, 'unchanged_tool_and_conformance_selected_paths': len(tooling_paths),
        'release_binary': bind(binary)}
    put(O / 'checks.json', json.dumps(checks, indent=2) + '\n')
    record = {'status': 'source_ready_final_documentation_external_only', 'prior': bind(P / 'source-ready.json'),
        'published_base': '383985eded4889cf354c69857cce6ae9cc9b354c', 'files': files,
        'evidence_inputs': [bind(path) for path in inputs], 'checks': bind(O / 'checks.json'),
        'author': bind(O / 'author.py'), 'placeholders': [],
        'scope': 'Seven documentation paths only. No live source edit, project execution or remote CI outcome claim.',
        'qualifications': ['Actual final candidate4 results are separate from retained candidate3 full passes and strict-lint failure.',
            'The precreated-arrow correction was source-derived before candidate results; selected traces and numeric expectations are unchanged.',
            'Archived historical checkpoint sections remain byte-exact.',
            'Logical work and typed heap accounting are not CPU timing, physical allocation or RSS measurements.',
            'Promise.any and a new AggregateError upstream profile remain absent; the unchanged host rejects an uncaught AggregateError intrinsic identity.']}
    put(O / 'source-ready.json', json.dumps(record, indent=2) + '\n')
    print(json.dumps({'hold': bind(O / 'source-ready.json'), 'chapter_words': len((O / 'raw/docs/aggregate-error.md').read_text().split())}, indent=2))
else:
    print(json.dumps({'status': 'unsealed_draft', 'pending': markers, 'chapter_words': len((O / 'raw/docs/aggregate-error.md').read_text().split())}, indent=2))
