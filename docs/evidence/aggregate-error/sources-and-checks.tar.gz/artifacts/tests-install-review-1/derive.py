from pathlib import Path
import hashlib,json
A=Path('/tmp/eris-aggregate-error-plan-1');O=A/'tests-install-review-1'
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(n,x):(O/n).write_text(json.dumps(x,indent=2)+'\n')
# Inert source arithmetic, not execution/import of Rust or project Python.
# Parent ABI widths are used only to print concrete examples of typed charges.
S,A0,D,K,P,N,U,St,B=216,16,16,16,56,56,8,24,48
node=lambda k,v:16*(k+v)+32*U+64
Bpp=node(K,P);Bstatic=node(16,U);Bnative=node(St,U);Bglobal=node(St,B)
header=72+A0+D;order=3*K
stages=[]
def stage(work,heap=0,effect=None):stages.append((work,heap,effect))
for w in [19,33,1,22,44,66,66]:stage(w)
for length in [6,4,9,11,7,14,0]:stage(8+2*length,64+4*length)
stage(10)
for bag in ['prototype_bag','constructor_bag']:
 stage(8,header);stage(1,order,bag)
for count,length in enumerate([6,4,9]):stage(count*(1+length)+(count+8)+1,256+4*length+(Bpp if count==0 else 0))
stage(22,N+46)
for count,length in enumerate([11,4,7]):stage(count*(1+length)+(count+8)+1,256+4*length+(Bpp if count==0 else 0))
stage(8+44+28*3,3*Bstatic,'prototype')
stage(15,14);stage(8+66+28*4,32+4*Bnative,'native')
stage(15,14);stage(8+66+28*4,32+4*Bglobal,'global')
assert sum(x[0] for x in stages)==1103 and sum(x[1] for x in stages)==17122
# A source-model row stops at the first refused debit/charge, before its effect.
def state(work,available):
 heap=0;objects=752;maps={'prototype':False,'native':False,'global':False}
 for debit,charge,effect in stages:
  if debit>work:return {'steps':0,'heap':heap,'objects':objects,**maps,'success':False}
  work-=debit;heap+=charge
  if heap>available:return {'steps':work,'heap':heap,'objects':objects,**maps,'success':False}
  if effect in ['prototype_bag','constructor_bag']:objects+=1
  elif effect:maps[effect]=True
 return {'steps':work,'heap':heap,'objects':objects,**maps,'success':True}
work_rows=[(0,752,False,False,False),(18,752,False,False,False),(419,752,False,False,False),(427,752,False,False,False),(428,753,False,False,False),(436,753,False,False,False),(437,754,False,False,False),(565,754,False,False,False),(700,754,False,False,False),(701,754,True,False,False),(901,754,True,False,False),(902,754,True,True,False),(1102,754,True,True,False),(1103,754,True,True,True)]
wr=[]
for w,o,p,n,g in work_rows:
 r=state(w,8388608);assert (r['steps'],r['objects'],r['prototype'],r['native'],r['global'],r['success'])==(0,o,p,n,g,g)
 wr.append({'budget':w,**r})
metadata=2*A0+2*D+6*K+2*Bpp+N+2542
through_proto=metadata+3*Bstatic;through_native=through_proto+14+4*Bnative+32;total=through_native+14+4*Bglobal+32
pool=652;prototype_bag=pool+header+order;constructor_bag=prototype_bag+header+order
heap_rows=[(87,271,752,False,False,False),(pool+header-1,427,752,False,False,False),(prototype_bag-1,428,752,False,False,False),(prototype_bag+header-1,436,753,False,False,False),(constructor_bag-1,437,753,False,False,False),(through_proto-1,701,754,False,False,False),(through_native-1,902,754,True,False,False),(total-1,1103,754,True,True,False),(total,1103,754,True,True,True)]
hr=[]
for a,spent,o,p,n,s in heap_rows:
 r=state(1103,a);assert (r['steps'],r['objects'],r['prototype'],r['native'],r['global'],r['success'])==(1103-spent,o,p,n,s,s)
 assert r['heap']==a+(0 if s else 1)
 hr.append({'available_example':a,'spent_work':spent,**r})
put('arithmetic.json',{'kind':'source-derived_arithmetic_only','work_rows':wr,'heap_rows_observed_parent_abi_examples':hr,'metadata_heap_constant':2542,'helper_total_constant':2634,'constant_equality':'2542 + native key14 + native fixed32 + global key14 + global fixed32 =2634','complete_helper_heap_example':total,'upfront_slots_excluded_from_helper':2*S,'qualification':'The test code uses size_of types, not these example numbers. No candidate execution or architecture measurement was performed.'})
inputs=[A/'tests-install-1/source-ready.json',A/'tests-install-1/raw/src/script/aggregate_error/install/tests.rs',A/'install-ledger-1/source-ready.json',A/'install-ledger-1/ledger.json',A/'root/install-selection-1.json',A/'root/install-staging-1.json',A/'install-ledger-addendum-1/source-ready.json',A/'install-production-1/source-ready.json',A/'install-production-1/raw/src/script/aggregate_error/install.rs',A/'install-production-1/raw/src/script/dom_prototypes.rs',A/'runtime-production-1/source-ready.json',A/'runtime-production-1/raw/src/script.rs',A/'runtime-production-1/raw/src/script/promises.rs',A/'runtime-production-1/raw/src/script/promises/install.rs',A/'runtime-production-1/raw/src/script/aggregate_error.rs']
put('source-review.json',{'status':'clear','scope':'Independent source review of two installer-admission groups/23 rows before production import or candidate execution. No requested payload change.','inputs':[binding(p) for p in inputs],'groups':2,'operation_rows':23,'work_rows':14,'typed_heap_rows':9,'fixture':{'valid':True,'reason':'Real initialize_bootstrap runs preceding unchanged installation with99694 work. Upfront capacity adds two slots without extra work. The new first19 debit refuses before reads/retains/texts/bags/maps. Thus752 objects,capacity>=754,native299,prototypes25,globals212 and next order212 are valid.','budget_reset_qualification':'Counter changes are inert private fixture setup on a Runtime that was never returned to author code. No author callback or queue resumes during the measured direct installer call.','heap':'The work test measures only incremental helper charge from the actual fixture allocation, excluding the two already paid arena slots. Heap tests set a private allowance before the call and never reset during it.'},'work_proof':['0/18 refuse fixed19.','419 reaches the first bag header;427 pays its header but cannot pay order1.','428 publishes the first bag;436 pays the second header but cannot pay its order1.','437 publishes both bags;565 completes private metadata.','700 cannot pay prototype entry136;701 publishes prototype only.','901 cannot pay native entry186;902 publishes native after prototype.','1102 cannot pay global entry186;1103 publishes the global and advances checked order.','Every selected partial work row reaches a later unpaid debit, which sets steps to0; no excess-budget success row is asserted.'],'heap_proof':['Pool652 and per-bag72+A+D plus3K are exact existing helper stages.','First text length has88 charge;87 availability fails at work271.','Both header/order one-short cuts fail before their corresponding bag append.','Metadata prefix has2A+2D+6K+2Bpp+N+2542; adding both owned key14 and fixed32 allowances yields the selected2634 constant.','Prototype/native/global one-short cumulative boundaries reach work701/902/1103 respectively and fail before their own Entry publication.','charge records the full debit before refusing, so every exactly-one-short cumulative cut yields MAX_HEAP+1. Exact success yields MAX_HEAP.'],'rust_source_fit':{'visibility':'The tests are a child of aggregate_error::install, itself below script. Ancestor-private Runtime construction/budget/state access is legal. Entry method is pub(in crate::script).','types':'next_global_order is u64;u64::from(bool) is used. Map lengths use usize::from(bool). Typed node formulas match actual static/string key and value types.','imports':'All explicitly imported types are used in typed heap expressions or fixtures. No extra runtime API or field is required.','registration':'Sealed installer includes cfg(test) mod tests. Runtime sibling hold supplies METADATA_OBJECTS2, late invocation, intrinsic_tree reexport and widened unchanged promise_native.'},'coverage_qualification':'This is the selected new bag/map admission subset. It does not claim exhaustive malformed-prerequisite, every reused property helper, OS allocator-failure, descriptor/identity or constructor-runtime coverage. Those concerns belong to separate source/public/private controls.','execution':'None: only source reads, SHA bindings and inert arithmetic. No live changes, Rust/compiler/formatter/engine/project Python execution.','arithmetic':binding(O/'arithmetic.json'),'findings':[]})
print(json.dumps(binding(O/'source-review.json'),indent=2))
