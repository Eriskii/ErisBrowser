from pathlib import Path
import hashlib,json,re,difflib
A=Path('/tmp/eris-aggregate-error-plan-1');O=A/'install-production-1';W=A/'worktree'
def sha(x):return hashlib.sha256(x).hexdigest()
def b(p):
 x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':sha(x)}
def put(n,v):(O/n).write_text(json.dumps(v,indent=2)+'\n')
parent=json.loads((A/'source-parent.json').read_text())
rel='src/script/aggregate_error/install.rs';p=O/'raw'/rel;assert not(W/rel).exists()
q=O/'diffs'/(rel+'.patch');q.parent.mkdir(parents=True,exist_ok=True);q.write_text(''.join(difflib.unified_diff([],p.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+rel)))
roster=[];groups=[];inverse=[]
for raw in sorted((O/'raw').rglob('*.rs')):
 rel=str(raw.relative_to(O/'raw'));before=O/'before'/rel;new=raw.read_text();old=before.read_text() if before.exists() else ''
 if before.exists():
  assert sha(before.read_bytes())==parent['source_sha256'][rel]
  assert (W/rel).read_bytes()==before.read_bytes()
 else:assert rel=='src/script/aggregate_error/install.rs'
 patch=O/'diffs'/(rel+'.patch')
 expected=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile=('a/'+rel if before.exists() else '/dev/null'),tofile='b/'+rel))
 assert patch.read_text()==expected
 # Independent sequential hunk replay, using the advertised old hunk positions.
 src=old.splitlines(keepends=True);out=[];cur=0;lines=patch.read_text().splitlines(keepends=True);i=2
 while i<len(lines):
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert m,lines[i]
  start=int(m.group(1));oldn=int(m.group(2) or 1);at=start-1 if oldn else start
  assert at>=cur;out.extend(src[cur:at]);cur=at;i+=1;seenold=seennew=0
  while i<len(lines) and not lines[i].startswith('@@ '):
   l=lines[i];i+=1
   if l[0] in ' -':assert src[cur]==l[1:],(rel,cur,l,src[cur]);cur+=1;seenold+=1
   if l[0] in ' +':out.append(l[1:]);seennew+=1
  assert seenold==oldn
  assert seennew==int(m.group(4) or 1)
 out.extend(src[cur:]);assert ''.join(out)==new
 names=lambda s:re.findall(r'#\[test\]\s*fn\s+(\w+)',s)
 oldnames=names(old);newnames=names(new)
 if '/tests' in rel or rel.endswith('_tests.rs') or rel.endswith('/tests.rs'):
  assert len(oldnames)==len(newnames)
  groups.append({'path':rel,'count':len(oldnames),'before':oldnames,'after':newnames,'renames':[{'before':x,'after':y} for x,y in zip(oldnames,newnames) if x!=y]})
 roster.append({'path':rel,'status':'modified' if before.exists() else 'new','before':b(before) if before.exists() else None,'raw':b(raw),'diff':b(patch)})
 inverse.append({'path':rel,'diff_reconstructs_raw':True,'published_before_exact':before.exists(),'new_path_absent_in_live_parent':not before.exists()})
assert len(roster)==19 and len(groups)==17
renames=[r for f in groups for r in f['renames']];assert len(renames)==4
for path in ['processing_instruction/key_cache_tests.rs','promises/install_tests.rs','text_operations/key_cache_tests.rs']:
 text=(O/'raw/src/script'/path).read_text()
 for row in ['(99_693, false, 0)','(99_694, false, 0)','(100_000, false, 0)','(100_796, false, 0)','(100_797, true, 0)','(1_000_000, true, 899_203)']:assert text.count(row)==1,(path,row)
# Explicit preservation controls called out by the selected migration audit.
p=(O/'raw/src/script/bootstrap_tests.rs').read_text();assert 'assert_eq!(witness.prototypes.len(), 25);' in p
p=(O/'raw/src/script/array_buffer/bootstrap/tests.rs').read_text();assert p.count('assert_eq!(runtime.prototypes.len(), 25);')==1
p=(O/'raw/src/script/test262_host/quota_tests.rs').read_text();assert 'object_plan(750, 752)' in p
p=(O/'raw/src/script/node_data/key_cache_fee_tests.rs').read_text();assert 'runtime.steps = 98;' in p and 'assert_eq!(runtime.steps, 90);' in p
p=(O/'raw/src/script/promises/shared_key_tests.rs').read_text();assert 'runtime.next_global_order = 210;' in p and 'assert_eq!(aggregate.global_order, 212);' in p
p=(O/'raw/src/script/aggregate_error/install.rs').read_text();assert p.count('.clone()')==11 and p.count('self.dom_proto_text(')==7 and p.count('self.dom_proto_object(')==2 and p.count('self.dom_proto_property(')==6
assert 'fn tree(' not in p and 'self.promise_native(constructor_bag, GLOBAL, Value::Window)' in p
put('roster.json',{'base':parent['base'],'production_paths':2,'migration_paths':17,'total_paths':19,'files':roster,'test_groups':groups,'renames':renames,'existing_test_group_count':sum(x['count'] for x in groups),'new_tests_authored_here':0,'new_test_registration':'#[cfg(test)] mod tests in aggregate_error/install.rs; root owns install/tests.rs payload.'})
put('source-checks.json',{'status':'source_only_checks_pass','inverse':inverse,'all_selected_17_migration_paths_exact':True,'old_test_names_preserved_except_four_explicit_boundary_renames':True,'old_three_raw_inputs_retained_in_each_of_three_matrices':True,'new_derived_rows_added_in_each_matrix':True,'early_prototype25_and_isolated_planner_750_752_preserved':True,'existing_eager_guard98_remaining90_preserved':True,'shared_replay_order_literals210_211_212_preserved':True,'installer_clone_calls':11,'installer_text_calls':7,'installer_object_calls':2,'installer_property_calls':6,'new_total_work_source_selected':1103,'heap_formula_source_selected':'2*S+2*A+2*D+6*K+2*Bpp+N+3*Bstatic+4*Bnative+4*Bglobal+2634','no_execution':'No Rust/compiler/formatter/engine/project execution. Only external source authoring, data reads, arithmetic, hashes and patch reconstruction.'})
put('composition.json',{'status':'external_source_ready_requires_sibling_composition','owned_paths':19,'required_script_owned_joins':['aggregate_error.rs: mod install; pub(super) const METADATA_OBJECTS: usize = 2; imports exposing root script types to child.','script.rs: mod aggregate_error; append install_aggregate_error_intrinsics after successful Promise installation.','promises.rs: pub(super) reexport install::tree as intrinsic_tree.','promises/install.rs: widen promise_native visibility to crate::script without altering body.'],'required_root_owned_join':'src/script/aggregate_error/install/tests.rs; registration is included in this hold.','method':'Runtime::install_aggregate_error_intrinsics','visibility':'pub(in crate::script)','before_source':b(A/'source-parent.json'),'selected_ledger':b(A/'install-ledger-1/source-ready.json'),'selected_borrow_addendum':b(A/'install-ledger-addendum-1/source-ready.json'),'refusal_qualification':'Invalid Error binding variants consume lookup33+clone1 after fixed19 before the one map read. Empty/new failures create no handles; successfully retained saved Error is later dropped or moved to the second bag. Partial maps/bags after later refusal are intentional and remain in an unreturned Runtime.','raw_fixture':'Root proposed Runtime::uninitialized with99694 steps then initialize_bootstrap(&mut self): existing setup completes; new first19 debit refuses before any new effect, leaving752 objects with754 reserved slots and old299/25/212 maps. Counters may be isolated only in inert private tests; no author execution or queue reset is proposed.','no_live_import_or_result_claim':True})
files=[p for p in O.rglob('*') if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',{'status':'sealed_external_installer_and_selected_existing_test_migrations','base':parent['base'],'paths':19,'new_production':1,'modified_production':1,'existing_test_files':17,'files':[b(p) for p in sorted(files)],'source_checks':b(O/'source-checks.json'),'scope':'No script.rs, Runtime constructor body, native dispatch, runtime collection, or old helper body authored in this hold. No live edits or project execution.'})
print(json.dumps({'seal':b(O/'source-ready.json'),'roster':b(O/'roster.json'),'checks':b(O/'source-checks.json'),'groups':sum(x['count'] for x in groups),'renames':renames},indent=2))
