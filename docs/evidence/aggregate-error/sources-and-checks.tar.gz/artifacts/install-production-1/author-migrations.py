from pathlib import Path
import hashlib,json,difflib,re
A=Path('/tmp/eris-aggregate-error-plan-1'); O=A/'install-production-1'; L=A/'install-ledger-1'; W=A/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def write(rel,s,base):
 for d,t in [('before',base),('raw',s)]:
  p=O/d/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(t)
 p=O/'diffs'/(rel+'.patch');p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(''.join(difflib.unified_diff(base.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+rel,tofile='b/'+rel)))
def rep(s,a,b,n=None):
 found=s.count(a)
 if n is None:assert found>0,(a,found)
 else:assert found==n,(a,found,n)
 return s.replace(a,b)
paths=[e['path'] for e in json.loads((L/'migrations.json').read_text())['entries']]
old='[(99_693, false, 0), (99_694, true, 0), (100_000, true, 306)]'
new='[\n        (99_693, false, 0),\n        (99_694, false, 0),\n        (100_000, false, 0),\n        (100_796, false, 0),\n        (100_797, true, 0),\n        (1_000_000, true, 899_203),\n    ]'
for rel in paths:
 before=(L/'source-snapshots'/rel).read_text();assert (W/rel).read_text()==before,rel
 s=before
 if rel.endswith('array_buffer/bootstrap/tests.rs'):
  s=rep(s,'    runtime.objects.truncate(first);','    // Exclude the new late prototype when reconstructing this earlier stage.\n    assert!(runtime.prototypes.remove("AggregateError").is_some());\n    runtime.objects.truncate(first);',1)
  s=rep(s,'assert_eq!(runtime.native_properties.len(), 299);','assert_eq!(runtime.native_properties.len(), 300);',1)
  # Only the completed-realm assertion; preserve stage()'s original25.
  i=s.index('fn array_buffer_bootstrap_reports_raw_combined_initialization')
  s=s[:i]+rep(s[i:],'assert_eq!(runtime.prototypes.len(), 25);','assert_eq!(runtime.prototypes.len(), 26);',1)
 elif rel.endswith('bootstrap_tests.rs'):
  s=rep(s,'reference.steps, 900_306','reference.steps, 899_203',1)
  s=rep(s,'reference.objects.len(), 752','reference.objects.len(), 754',1)
  s=rep(s,'reference.native_properties.len(), 299','reference.native_properties.len(), 300',1)
  s=rep(s,'reference.prototypes.len(), 25','reference.prototypes.len(), 26',1)
 elif rel.endswith('dom_bindings/identity_tests.rs'):
  s=rep(s,'runtime.objects.len(), 752','runtime.objects.len(), 754',1)
 elif rel.endswith('node_clone/tests.rs'):
  s=rep(s,'runtime.native_properties.len(), 299','runtime.native_properties.len(), 300',1)
 elif '/node_data/' in rel:
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213'),('(752, 752)','(754, 754)')]:
   if a in s:s=s.replace(a,b)
 elif rel.endswith('processing_instruction/display_key_tests.rs'):
  s=rep(s,'startup_headroom_raw_observation_precedes_the_frozen_99694_work_witness','startup_headroom_raw_observation_precedes_the_frozen_100797_work_witness',1)
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.objects.capacity() >= 752','runtime.objects.capacity() >= 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213'),('BOOTSTRAP_STEPS - runtime.steps, 99_694','BOOTSTRAP_STEPS - runtime.steps, 100_797'),('runtime.steps, 900_306','runtime.steps, 899_203')]:s=rep(s,a,b,1)
 elif rel.endswith('processing_instruction/key_cache_tests.rs'):
  s=rep(s,'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99694_work_boundary','cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_100797_work_boundary',1)
  s=rep(s,old,new,1)
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213')]:s=rep(s,a,b,1)
  s=rep(s,'panic!("one-short bootstrap succeeded")','panic!("under-budget bootstrap succeeded")',1)
  s=rep(s,'    for (allowance, success, remaining) in\n','    // Keep all three old raw inputs as refusals; append the new exact boundary.\n    for (allowance, success, remaining) in\n',1)
 elif rel.endswith('promises/install_tests.rs'):
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.objects.len(), 763','runtime.objects.len(), 765'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('(752, 752)','(754, 754)')]:s=rep(s,a,b)
  # Avoid cascading replacements of two different old global counts.
  s=s.replace('bindings.len(), 212','bindings.len(), GLOBAL_COMPLETE').replace('bindings.len(), 211','bindings.len(), 212').replace('bindings.len(), GLOBAL_COMPLETE','bindings.len(), 213')
  s=rep(s,'promise_full_raw99694_and_public_reset_preserve_empty_paid_arenas','promise_full_raw100797_and_public_reset_preserve_empty_paid_arenas',1)
  s=rep(s,old,new,1)
  s=rep(s,'    for (work, accepted, remaining) in [','    // Preserve old raw inputs explicitly, then add the derived new boundary.\n    for (work, accepted, remaining) in [',1)
 elif rel.endswith('promises/shared_key_tests.rs'):
  s=rep(s,'    // Retain all old bags. Physical preparation and restoration of the two\n    // last global order positions are outside the measured installer call.', '    // Exclude the late global before restoring the two earlier order positions.\n    // Keep every metadata bag and both late registry entries.\n    let aggregate = runtime.environments[0]\n        .bindings\n        .remove("AggregateError")\n        .unwrap();\n    assert_eq!(aggregate.global_order, 212);\n    // Physical preparation and order restoration are inert fixture setup.',1)
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.objects.len(), 753','runtime.objects.len(), 755'),('runtime.objects.len(), 764','runtime.objects.len(), 766'),('runtime.objects.capacity() >= 764','runtime.objects.capacity() >= 766'),('runtime.objects[752]','runtime.objects[754]'),('owner, 752','owner, 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26')]:s=rep(s,a,b)
  s=rep(s,'    // the independently migrated99693/99694/100000 witnesses, not this replay.','    // the retained99693/99694/100000 refusals and new100797 boundary, not this replay.',1)
 elif rel.endswith('promises/shared_key_identity_tests.rs'):
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.objects.capacity(), 752','runtime.objects.capacity(), 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213')]:s=rep(s,a,b,1)
 elif rel.endswith('promises/all_state/all_settled_quota_tests.rs'):
  s=rep(s,'runtime.prototypes.len(), 25','runtime.prototypes.len(), 26',1)
  s=rep(s,'if missing { 24 } else { 25 }','if missing { 25 } else { 26 }',1)
 elif rel.endswith('test262_host/quota_tests.rs'):
  for a,b in [('runtime.steps, 900_306','runtime.steps, 899_203'),('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300')]:s=rep(s,a,b,1)
 elif rel.endswith('text_operations/key_cache_tests.rs'):
  s=rep(s,'text_metadata_keys_raw_bootstrap_uses_99694_work_and_preserves_public_reset','text_metadata_keys_raw_bootstrap_uses_100797_work_and_preserves_public_reset',1)
  s=rep(s,old,new,1)
  for a,b in [('runtime.objects.len(), 752','runtime.objects.len(), 754'),('runtime.objects.capacity(), 752','runtime.objects.capacity(), 754'),('runtime.native_properties.len(), 299','runtime.native_properties.len(), 300'),('runtime.prototypes.len(), 25','runtime.prototypes.len(), 26'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213')]:s=rep(s,a,b)
  s=rep(s,'    // leave a net60 work saving. The allowance and arena counts stay unchanged.','    // leave a net60 work saving. AggregateError subsequently adds1103 startup\n    // work and two bags; preserve the former raw inputs below as refusals.',1)
  s=rep(s,'panic!("one-short Text key-cache bootstrap succeeded")','panic!("under-budget Text key-cache bootstrap succeeded")',1)
 elif rel.endswith('typed_array/tests.rs'):
  a='    // The cumulative remainder below starts from MAX_STEPS; only its\n'
  b='    // AggregateError adds two prepaid slots and three late map entries.\n    let b_static =\n        16 * (size_of::<&\'static str>() + size_of::<usize>()) + 32 * size_of::<usize>() + 64;\n    let b_native =\n        16 * (size_of::<String>() + size_of::<usize>()) + 32 * size_of::<usize>() + 64;\n    let aggregate_error_added =\n        2 * s + 2 * a + 2 * d + 6 * k + 2 * bpp + n + 3 * b_static + 4 * b_native + 4 * bsb + 2634;\n'+a
  s=rep(s,a,b,1)
  s=rep(s,'            + 279\n            + (BOOTSTRAP_STEPS - MAX_STEPS)','            + 279\n            - 1103\n            + (BOOTSTRAP_STEPS - MAX_STEPS)',1)
  s=rep(s,'            - 1132\n','            - 1132\n            + aggregate_error_added\n',1)
  for a,b in [('(752, 752)','(754, 754)'),('(299, 25)','(300, 26)'),('runtime.environments[0].bindings.len(), 212','runtime.environments[0].bindings.len(), 213')]:s=rep(s,a,b,1)
 else:raise AssertionError(rel)
 if old in before:
  s=s.replace(" in\n        [\n", " in [\n").replace("    ]\n    {\n", "    ] {\n")
 assert s!=before,rel
 write(rel,s,before)
rel='src/script/dom_prototypes.rs';before=(L/'source-snapshots'/rel).read_text();assert(W/rel).read_text()==before
s=rep(before,'    + text_operations::METADATA_OBJECTS;','    + text_operations::METADATA_OBJECTS\n    + aggregate_error::METADATA_OBJECTS;',1)
write(rel,s,before)
print('External existing-file drafts:',len(paths)+1)
