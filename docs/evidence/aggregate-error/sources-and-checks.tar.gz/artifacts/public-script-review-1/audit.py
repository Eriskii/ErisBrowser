from pathlib import Path
import difflib,hashlib,json,re
P=Path('/tmp/eris-aggregate-error-plan-1');R=P/'public-script-review-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys(): assert bind(Path(v['path']))=={k:v[k] for k in ['path','bytes','sha256']},v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
for name in ['selection-1/source-ready.json','tests-public-1/source-ready.json']:verify(json.loads((P/name).read_text()))
cases=json.loads((P/'selection-1/cases.json').read_text())['cases']
original=json.loads(Path('/tmp/eris-promise-any-plan-1/semantic-cases.json').read_text())
original=original['cases'] if isinstance(original,dict) else original
assert cases[:10]==[r for r in original if r['phase']=='aggregate']
module=(P/'tests-public-1/raw/src/script/aggregate_error_semantic_tests.rs').read_text()
pattern=re.compile(r'#\[test\]\nfn (\w+)\(\) \{\n    observe\(\n        "([^"\n]+)",\n        r###"([\s\S]*?)"###,\n        r###"([\s\S]*?)"###,\n        "([^"\n]*)",\n    \);\n\}')
rows=pattern.findall(module);assert len(rows)==len(cases)==13
for row,case in zip(rows,cases):
 name,identifier,source,readback,expected=row
 assert name==identifier==case['name'] and source==case['source'] and readback==case['readback'] and expected==case['expected']
 assert hashlib.sha256(source.encode()).hexdigest()==case['source_sha256']
helper=(P/'tests-public-1/helper.rs.txt').read_text();assert module.startswith(helper)
assert 'for strict in [false, true]' in helper and 'Runtime::try_new()' in helper
assert '.steps =' not in module and 'BOOTSTRAP_STEPS' not in module
manifest=json.loads((P/'tests-public-1/source-ready.json').read_text())
for row in manifest['files']:
 old=Path(row['before']['path']).read_text() if row['before'] else ''
 new=Path(row['raw']['path']).read_text()
 rel=row['relative_path']
 if rel=='src/script.rs':
  fragment=(P/'tests-public-1/registration-fragment.txt').read_text()
  assert new.count(fragment)==1 and new.replace(fragment,'',1)==old
 else:assert new==module
 patch=Path(row['diff']['path']).read_text()
 # The frozen new-file patch uses /dev/null; the registration is a usual a/b diff.
 expected=''.join(difflib.unified_diff(old.splitlines(keepends=True),new.splitlines(keepends=True),fromfile='/dev/null' if row['new_file'] else 'a/'+rel,tofile='b/'+rel))
 assert patch==expected,rel
report=dict(status='clear_source_only',reviewer='/root/script',inputs=[bind(P/p) for p in ['selection-1/source-ready.json','selection-1/cases.json','selection-1/primary-basis.json','tests-public-1/source-ready.json','tests-public-1/helper.rs.txt','tests-public-1/registration-fragment.txt']],groups=13,mode_rows=26,literal_findings=[],checks=['All selection/test manifest bindings verify; ten prior AggregateError case objects remain exact.', 'All13 Rust sources/readbacks/expected strings independently extracted and matched to frozen cases.', 'Shared helper uses fresh existing Runtime::try_new per mode and the ordinary execute/execute_strict APIs; no private helper, fixture counter reset or new production symbol.', 'Registration inverse and both unified diffs are exact; published15226307 before lineage and required later-base refresh remain explicit.', 'Manually reconciled metadata/call/new, P-M-C-I iterator sequence, abrupt payload identity, dense holes, own-property descriptor flags, saved constructor/Array identity, alternate NewTarget validation/fallback, code-point string iteration and no-close traces.', 'Three new Error-tag groups correctly distinguish private brand from prototype/name spoofing, preserve string/empty-tag override and throwing getter identity, and never coerce non-string tag values. All seven original Error constructors are covered.', 'Source-predicted parent1pass12fail follows missing AggregateError guards and inherited Error-brand gap; this is not a runtime observation.'],primary_verification=[dict(url='https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-aggregate-error-constructor',claim='Current constructor order and prototype requirements checked directly.'),dict(url='https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.prototype.tostring',claim='Current ErrorData builtin-tag plus string-only override rules checked directly.'),dict(url='https://tc39.es/ecma262/multipage/abstract-operations.html#sec-iteratortolist',claim='Current IteratorToList abrupt propagation has no IteratorClose step.')],limits='No project execution or live edits. No implementation/fee/host-policy approval; this receipt covers source literals, conversion and existing API eligibility only.',audit=bind(R/'audit.py'))
q=R/'source-review.json';q.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(q)))
