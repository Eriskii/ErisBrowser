"""Inert external conversion of selected, already-frozen JS literals to Rust."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
W = P / 'worktree'
OUT = P / 'tests-abort-1'
BASE = '383985eded4889cf354c69857cce6ae9cc9b354c'
assert not (OUT / 'source-ready.json').exists(), 'immutable hold already exists'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data, str) else data)

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))

def dump(path, obj):
    write(path, json.dumps(obj, indent=2) + '\n')

proposal = P / 'terminal-proposal-1'
assert digest((proposal / 'source-ready.json').read_bytes()) == '43dc6719e23e6574bbc07d946e8dd807226e41bd5afcf6a015f4811fcaf663d6'
for row in json.loads((proposal / 'source-ready.json').read_text())['files']:
    path = Path(row['path'])
    assert bind(path) == row
cases = json.loads((proposal / 'public-cases.json').read_text())['cases']
contract = json.loads((proposal / 'public-contract.json').read_text())
assert len(cases) == 10 and len(contract['groups']) == 5
assert all(c['modes'] == ['sloppy', 'strict'] for c in cases)
assert all(c['readback'] == contract['readback'] for c in cases)
by_name = {c['name']: c for c in cases}

published = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':src/script.rs'])
before = (W / 'src/script.rs').read_bytes()
selected_registration = (P / 'tests-public-base-refresh-1/raw/src/script.rs').read_bytes()
assert before == selected_registration
semantic_registration = b'#[cfg(test)]\nmod aggregate_error_semantic_tests;\n'
assert before.count(semantic_registration) == 1
assert before.replace(semantic_registration, b'', 1) == published
insertion = b'#[cfg(test)]\nmod aggregate_error_abort_tests;\n'
assert insertion not in before
after = before.replace(semantic_registration, insertion + semantic_registration, 1)
assert after.replace(insertion, b'', 1) == before

helper_path = W / 'src/script/promise_all_settled_abort_tests.rs'
helper_source = helper_path.read_text()
published_helper = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':src/script/promise_all_settled_abort_tests.rs'])
assert helper_source.encode() == published_helper
old_helper = helper_source.split('#[test]', 1)[0]
new_header = ('//! AggregateError host-terminal controls with frozen source literals.\n'
              '//! No manual allowance, queue or suspension resets.\n')
helper = new_header + old_helper[old_helper.index('use super::*;'):]
old_readback = "[trace,resolves,rejects,returnGets,returnCalls,after].join('|')"
assert helper.count(old_readback) == 1
helper = helper.replace(old_readback, contract['readback'])
assert helper[helper.index('use super::*;'):].replace(contract['readback'], old_readback) == old_helper[old_helper.index('use super::*;'):]

module = helper
roster = []
for group in contract['groups']:
    rows = [by_name[name] for name in group['source_names']]
    assert [r['kind'] for r in rows] == ['work', 'unsupported']
    assert all(r['expected'] == group['expected'] for r in rows)
    name = f"aggregate_error_terminal_{group['stage']}_stops_author_code_and_jobs"
    module += '#[test]\nfn ' + name + '() {\n    fatal_stop(\n        [\n'
    for row in rows:
        literal = Path(row['literal']['path']).read_bytes()
        assert literal == row['source'].encode()
        assert digest(literal) == row['source_sha256']
        assert '"###' not in row['source']
        module += ('            (\n                ' + json.dumps(row['name']) + ',\n'
                   '                ' + ('true' if row['kind'] == 'unsupported' else 'false') + ',\n'
                   '                r###"' + row['source'] + '"###,\n            ),\n')
    module += '        ],\n        ' + json.dumps(group['expected']) + ',\n    );\n}\n\n'
    roster.append({'rust_test': name, 'stage': group['stage'], 'source_names': group['source_names'],
                   'planned_mode_rows': 4, 'expected_readback': group['expected'],
                   'first_parent_failure': 'First sloppy work case: is_unsupported false passes, is_resource_limit expected true fails on the ordinary missing-AggregateError Error.',
                   'unreached_on_parent': ['suspension assertion', 'both readbacks', 'strict work mode', 'both Unsupported modes']})

module_path = 'src/script/aggregate_error_abort_tests.rs'
files = []
for relative, old, raw, new_file in [('src/script.rs', before, after, False), (module_path, b'', module.encode(), True)]:
    before_path = OUT / 'before' / relative
    raw_path = OUT / 'raw' / relative
    diff_path = OUT / 'diffs' / (relative.replace('/', '__') + '.patch')
    write(before_path, old)
    write(raw_path, raw)
    patch = ''.join(difflib.unified_diff(old.decode().splitlines(True), raw.decode().splitlines(True),
                                      fromfile='/dev/null' if new_file else 'a/' + relative, tofile='b/' + relative))
    write(diff_path, patch)
    files.append(dict(relative_path=relative, new_file=new_file, before=bind(before_path), raw=bind(raw_path), diff=bind(diff_path)))

write(OUT / 'registration-insertion.txt', insertion)
write(OUT / 'helper.rs.txt', helper)
dump(OUT / 'roster.json', {'groups': 5, 'source_literals': 10, 'planned_modes': 20, 'tests': roster,
                          'parent_prediction': {'passed': 0, 'failed': 5, 'observed': False},
                          'execution_order': 'Each group runs work sloppy, work strict, Unsupported sloppy, Unsupported strict; each uses fresh Runtime and Document.'})
dump(OUT / 'contract.json', {
    'selection': 'Root explicitly selected terminal-proposal-1 public contract before this conversion.',
    'source': bind(proposal / 'public-cases.json'), 'contract': bind(proposal / 'public-contract.json'),
    'helper_origin': bind(helper_path), 'helper_changes': ['module documentation', 'exact frozen readback expression'],
    'classification': 'is_unsupported equals selected bool, is_resource_limit equals its inverse, before any suspension/readback checks.',
    'runtime': 'Fresh Runtime::try_new and Document per source/mode; execute or execute_strict. On intended terminal error require suspension, then two normal execute readbacks, each exact String, still suspended and console empty.',
    'no_manual_reset': 'No writes to steps, allocated, author depth, queue or suspended state. Later readbacks use existing public entry behavior.',
    'scope': 'Public work exhaustion and Unsupported host-terminal policy only. No numeric private fees, heap exhaustion, allocation injection, Promise.any or decoder change.',
    'parent': contract['parent_prediction'],
    'registration': 'Complete before is the published 383985ed script plus the exact previously selected semantic-test registration. Only one test-only module declaration is inserted immediately before that registration.',
    'preservation': 'Existing 13 semantic groups, their supplemental group, all production inputs and existing test bodies are untouched.'
})

source_bindings = []
for relative in ['src/script.rs', 'src/script/promise_all_settled_abort_tests.rs', 'src/script/microtasks.rs', 'src/script/machine.rs']:
    raw = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + relative])
    snapshot = OUT / 'published-source' / relative
    write(snapshot, raw)
    source_bindings.append({'relative_path': relative, 'published_base': BASE, 'snapshot': bind(snapshot)})
dump(OUT / 'source-bindings.json', source_bindings)

# Independent textual readback of authored payload: exact sources and expected strings.
raw_strings = re.findall(r'r###"([\s\S]*?)"###', module)
assert raw_strings == [contract['readback']] + [r['source'] for r in cases]
assert re.findall(r'#\[test\]\nfn (\w+)\(', module) == [r['rust_test'] for r in roster]
assert len(re.findall(r'\n                false,\n', module)) == 5
assert len(re.findall(r'\n                true,\n', module)) == 5
for group in contract['groups']:
    assert module.count('        ' + json.dumps(group['expected']) + ',\n') == 1
assert not re.search(r'runtime\.(steps|allocated|microtasks)\s*=', module)

artifacts = [OUT / n for n in ['derive.py', 'registration-insertion.txt', 'helper.rs.txt', 'roster.json', 'contract.json', 'source-bindings.json']]
artifacts.extend(OUT / 'published-source' / r['relative_path'] for r in source_bindings)
ready = {
    'status': 'source_ready_unexecuted_parent_compatible_terminal_tests',
    'published_base': BASE, 'groups': 5, 'sources': 10, 'planned_modes': 20,
    'files': files, 'artifacts': [bind(f) for f in artifacts],
    'origins': [bind(proposal / 'source-ready.json'), bind(proposal / 'script-review.json'),
                bind(P / 'tests-public-base-refresh-1/source-ready.json')],
    'checks': ['All ten JS source bodies byte-exact with frozen proposal literals.',
               'Readback expression and five expected strings exactly preserved.',
               'Existing fatal_stop/execute_mode helper bodies exact except selected readback expression.',
               'Published-base source joins and exact test-only registration inverse checked.',
               'Five tests, ten sources and twenty planned strict/sloppy rows; parent reachability explicitly qualified.'],
    'qualification': 'External inert authoring/hash/diff work only. No project code, compiler, JS engine, formatter or tests executed; no live source writes. Root owns import/baseline and implementation.'
}
dump(OUT / 'source-ready.json', ready)
print(json.dumps(bind(OUT / 'source-ready.json')))
