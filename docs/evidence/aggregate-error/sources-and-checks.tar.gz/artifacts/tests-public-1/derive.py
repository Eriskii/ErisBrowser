"""Convert already-frozen public literals without running project code."""
from pathlib import Path
import difflib
import hashlib
import json
import re

P = Path('/tmp/eris-aggregate-error-plan-1')
S = P / 'selection-1'
H = P / 'tests-public-1'
REL = 'src/script/aggregate_error_semantic_tests.rs'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2) + '\n')

assert not (H / 'source-ready.json').exists(), 'Do not overwrite sealed bytes'
assert sha((S / 'source-ready.json').read_bytes()) == '5c004f56a8a0294b3b4c47b0d7878530999345f2623447bdc0cbf4e3a3c78078'
selection = json.loads((S / 'selection.json').read_text())
cases = json.loads((S / 'cases.json').read_text())['cases']
assert len(cases) == 13

helper = '''//! Frozen AggregateError literals and existing Error brand/tag controls.
//! Each mode uses a fresh Runtime and a separate post-execution observation.
use super::*;

fn observe(case_id: &str, source: &str, expression: &str, expected: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let result = if strict {
            runtime.execute_strict(source, &mut document)
        } else {
            runtime.execute(source, &mut document)
        };
        result.unwrap_or_else(|error| panic!("{case_id} strict={strict} source: {error:?}"));
        let observed = if strict {
            runtime.execute_strict(expression, &mut document)
        } else {
            runtime.execute(expression, &mut document)
        }
        .unwrap_or_else(|error| panic!("{case_id} strict={strict} observation: {error:?}"));
        assert_eq!(
            observed,
            Value::String(expected.into()),
            "{case_id} strict={strict}"
        );
    }
}
'''
parts = [helper]
for row in cases:
    assert sha(row['source'].encode()) == row['source_sha256']
    assert '"###' not in row['source'] and '"###' not in row['readback']
    assert row['modes'] == ['sloppy', 'strict']
    parts.append('\n#[test]\nfn ' + row['name'] + '() {\n    observe(\n        ' + json.dumps(row['name']) + ',\n        r###"' + row['source'] + '"###,\n        r###"' + row['readback'] + '"###,\n        ' + json.dumps(row['expected']) + ',\n    );\n}\n')
raw = ''.join(parts).encode()
assert raw.count(b'#[test]') == 13
assert b'.steps' not in raw and b'.allocated' not in raw and b'Promise.any' not in raw
extracted = re.findall(r'r###"(.*?)"###', raw.decode(), re.S)
assert len(extracted) == 26
for index, row in enumerate(cases):
    assert extracted[2 * index] == row['source']
    assert extracted[2 * index + 1] == row['readback']

raw_path = H / 'raw' / REL
raw_path.parent.mkdir(parents=True, exist_ok=True)
raw_path.write_bytes(raw)
(H / 'helper.rs.txt').write_text(helper)

before = (S / 'source-snapshots/src/script.rs').read_bytes()
fragment = b'#[cfg(test)]\nmod aggregate_error_semantic_tests;\n'
anchor = b'#[cfg(test)]\nmod bootstrap_tests;'
assert before.count(anchor) == 1 and b'mod aggregate_error_semantic_tests;' not in before
registered = before.replace(anchor, fragment + anchor, 1)
assert registered.replace(fragment, b'', 1) == before
before_path = H / 'before/src/script.rs'
registration_raw = H / 'raw/src/script.rs'
before_path.parent.mkdir(parents=True, exist_ok=True)
before_path.write_bytes(before)
registration_raw.write_bytes(registered)
(H / 'registration-fragment.txt').write_bytes(fragment)

diffs = H / 'diffs'
diffs.mkdir(exist_ok=True)
test_diff = diffs / 'src__script__aggregate_error_semantic_tests.rs.patch'
test_diff.write_text(''.join(difflib.unified_diff([], raw.decode().splitlines(keepends=True), fromfile='/dev/null', tofile='b/' + REL)))
registration_diff = diffs / 'src__script.rs.patch'
registration_diff.write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), registered.decode().splitlines(keepends=True), fromfile='a/src/script.rs', tofile='b/src/script.rs')))

roster = {'status': 'frozen source roster; no observations', 'groups': 13, 'planned_mode_rows': 26, 'rows': []}
for row in cases:
    prediction = next(item['parent'] for item in selection['rows'] if item['name'] == row['name'])
    roster['rows'].append({'test_name': 'script::aggregate_error_semantic_tests::' + row['name'], 'case_name': row['name'], 'source_sha256': row['source_sha256'], 'readback': row['readback'], 'expected_string': row['expected'], 'modes': row['modes'], 'parent_prediction': prediction})
write('roster.json', roster)
write('contract.json', {
    'status': 'parent-API eligible source hold; unexecuted',
    'published_semantic_base': '15226307b153da0857f80486d5f23c375b6b2add',
    'refresh_requirement': 'Refresh exact registration before bytes after the separately selected bootstrap-budget checkpoint is published. Preserve this hold and its published semantic/API source binding.',
    'fixture': 'Fresh Runtime::try_new and Document per mode; exact source must complete normally; execute/execute_strict then evaluate exact readback and compare Value::String. No private hooks or test budget changes.',
    'ordinary_checkpoint': 'Existing execute/execute_strict entry-point checkpoint behavior is reused. These selected cases are synchronous; no new explicit job-drain API is introduced.',
    'mode_reachability': 'Each Rust group runs sloppy before strict. A sloppy assertion or source error ends that group; later rows and readback are unreached and must remain qualified in parent evidence.',
    'parent_source_prediction': {'passed_groups': 1, 'failed_groups': 12, 'not_observed': True},
    'expected_failures': 'Ten missing-AggregateError guards and two current default Error-brand tagging gaps. The independent string-tag/getter group is a preservation control.',
    'scope_exclusions': ['Promise.any', 'Error.isError', 'SuppressedError', 'host decoder/policy', 'fees', 'startup installer', 'class/Proxy/multi-realm syntax'],
    'production_neutral_registration': 'One cfg(test) child module inserted before existing bootstrap_tests declaration. Removing the exact fragment recovers the published script.rs bytes.'
})
write('source-ready.json', {
    'status': 'source_ready_unexecuted',
    'groups': 13,
    'planned_mode_rows': 26,
    'new_paths': 1,
    'registration_paths': 1,
    'selected_literals': bind(S / 'source-ready.json'),
    'files': [
        {'relative_path': REL, 'new_file': True, 'before': None, 'raw': bind(raw_path), 'diff': bind(test_diff)},
        {'relative_path': 'src/script.rs', 'new_file': False, 'before': bind(before_path), 'raw': bind(registration_raw), 'diff': bind(registration_diff)}
    ],
    'artifacts': [bind(H / item) for item in ['helper.rs.txt', 'registration-fragment.txt', 'roster.json', 'contract.json', 'derive.py']],
    'source_bindings': [bind(S / 'source-bindings.json'), bind(S / 'cases.json'), bind(S / 'primary-basis.json'), bind(S / 'source-snapshots/src/script/promise_all_settled_semantic_tests.rs')],
    'checks': ['Exact13 source/readback/expected literal joins; original10 objects remain unchanged.', 'One Rust group per literal;26 planned mode rows with ordinary existing Runtime APIs.', 'Byte-exact registration inverse; test-only module and no production semantic edits.', 'Published15226307 source binding is retained; next-checkpoint base refresh is explicit.', 'No project/test/engine/compiler/formatter execution or live edits.']
})
print(json.dumps(bind(H / 'source-ready.json')))
