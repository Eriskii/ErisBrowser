from pathlib import Path
import json,hashlib,shutil
A=Path('/tmp/eris-aggregate-error-plan-1');W=A/'worktree';H=A/'tests-private-1'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(r):
 p=Path(r['path']);assert p.stat().st_size==r['bytes'] and sha(p)==r['sha256'],p
j=json.loads((H/'source-ready.json').read_text());rows=[]
for group in ['artifacts','origins']:
 for r in j[group]:verify(r)
for r in j['files']:
 for k in ['before','raw','diff']:verify(r[k])
 dst=W/r['relative_path']
 if r['new_file']:assert not dst.exists()
 else:assert dst.read_bytes()==Path(r['before']['path']).read_bytes(),dst
 rows.append({'path':r['relative_path'],'before':None if r['new_file'] else sha(dst),'raw':r['raw']})
 dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(r['raw']['path'],dst)
(A/'root/private-import-1.json').write_text(json.dumps({'status':'raw_imported_not_formatted_or_executed','imports':rows,'root_review':'Read both modules; selected57 operation rows and natural dense-array terminal coupling preserved.'},indent=2)+'\n')
print('Imported2private modules and2test-only registrations.')
