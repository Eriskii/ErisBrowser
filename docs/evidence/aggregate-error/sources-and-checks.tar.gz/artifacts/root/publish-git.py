import json,subprocess
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';M=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');O=A/'publication';O.mkdir(exist_ok=True)
base='383985eded4889cf354c69857cce6ae9cc9b354c'
def output(argv,cwd=W):return subprocess.run(argv,cwd=cwd,capture_output=True,text=True,check=True).stdout.strip()
def logged(name,argv,cwd=W):
 with (O/(name+'.log')).open('x') as f:subprocess.run(argv,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,check=True)
v=json.loads((A/'root/publication-verification.json').read_text());assert v['status']=='verified'
assert output(['git','rev-parse','HEAD'])==base
assert output(['git','rev-parse','HEAD'],M)==base and not output(['git','status','--porcelain'],M)
subprocess.run(['git','add','--',*v['expected_paths']],cwd=W,check=True)
assert set(output(['git','diff','--cached','--name-only']).splitlines())==set(v['expected_paths'])
subprocess.run(['git','diff','--cached','--check'],cwd=W,check=True)
logged('commit',['git','commit','-F',str(A/'root/commit-message.txt')]);commit=output(['git','rev-parse','HEAD']);assert not output(['git','status','--porcelain'])
logged('merge',['git','merge','--ff-only','aggregate-error'],M);assert output(['git','rev-parse','HEAD'],M)==commit and not output(['git','status','--porcelain'],M)
logged('push',['git','push','origin','main'],M)
r={'commit':commit,'remote':'https://github.com/Eriskii/ErisBrowser','push':'success','ci_status':'pending','note':'Postpublication state intentionally outside the immutable evidence archive.'};(A/'root/github-publication.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
