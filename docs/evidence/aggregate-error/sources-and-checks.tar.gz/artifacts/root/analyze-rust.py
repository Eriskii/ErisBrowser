import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def parse(directory,label):
 receipt=directory/(label+'.json');r=json.loads(receipt.read_text());log=directory/(label+'.log');text=log.read_text()
 assert r['exit']==0 and r['sha256']==bind(log)['sha256']
 rows=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)]
 totals=[sum(row[i] for row in rows) for i in range(5)]
 assert totals[1:]==[0,0,0,0],(label,totals)
 harness=None;names=[]
 for line in text.splitlines():
  match=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
  if match:harness=match[1]
  if 'Doc-tests ' in line:harness='Doc-tests '+line.split('Doc-tests ',1)[1]
  result=re.match(r'^test (.+) \.\.\. ok$',line)
  if result:
   assert harness is not None
   names.append(harness+'::'+result[1])
 assert len(names)==len(set(names))==totals[0],(label,len(names),totals)
 return {'receipt':bind(receipt),'log':bind(log),'result_rows':len(rows),'totals':totals,'passed_names':sorted(names)}
new=json.loads((A/'root/candidate-roster-4.json').read_text())['new_names']
renames=json.loads((A/'install-production-1/roster.json').read_text())['renames']
comparisons=[]
for label,expected in [('default-full-2',3159),('host-vulkan-full-2',3513)]:
 old=parse(A/'rust-parent',label.removesuffix('-2')+'-1');current=parse(A/'validation',label)
 assert current['totals']==[expected,0,0,0,0]
 normalized=set(old['passed_names']);applied=[]
 for row in renames:
  hits=[name for name in normalized if name.endswith('::'+row['before'])]
  assert len(hits)==1,(row,hits)
  previous=hits[0];replacement=previous.rsplit('::',1)[0]+'::'+row['after']
  normalized.remove(previous);normalized.add(replacement)
  applied.append({'before':previous,'after':replacement})
 assert set(current['passed_names'])==normalized|set(new),{'missing':sorted(normalized|set(new)-set(current['passed_names'])),'unexpected':sorted(set(current['passed_names'])-normalized-set(new))}
 assert not normalized&set(new)
 comparisons.append({'current':current,'previous':old,'exact_old_roster_after_selected_renames_plus_new':True,'renames':applied})
r={'status':'complete','new_test_groups':len(new),'new_names':new,'selected_existing_test_renames':renames,'comparisons':comparisons}
(A/'root/rust-validation.json').write_text(json.dumps(r,indent=2)+'\n')
print('All3159 default and3513 host/Vulkan tests pass; exact old rosters with4 selected renames plus27 new groups.')
