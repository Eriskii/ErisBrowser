from pathlib import Path
import json,hashlib,shutil
A=Path('/tmp/eris-aggregate-error-plan-1');W=A/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def verify(row):
 p=Path(row['path']);assert p.stat().st_size==row['bytes'];assert sha(p)==row['sha256'],p
rows=[]
for hold in ['install-production-1','runtime-production-1']:
 manifest=json.loads((A/hold/'source-ready.json').read_text())
 if hold=='install-production-1':
  for row in manifest['files']:verify(row)
  candidates=sorted((A/hold/'raw').rglob('*.rs'))
 else:
  candidates=[]
  for row in manifest['files']:
   for key in ['before','raw','diff']:verify(row[key])
   candidates.append(Path(row['raw']['path']))
 for src in candidates:
  rel=src.relative_to(A/hold/'raw');before=A/hold/'before'/rel;dst=W/rel
  if before.exists() and before.stat().st_size:
   assert dst.exists() and dst.read_bytes()==before.read_bytes(),(hold,str(rel))
  else:assert not dst.exists(),str(rel)
  rows.append({'path':str(rel),'hold':hold,'before':sha(dst) if dst.exists() else None,'after':sha(src)})
  dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dst)
hold='tests-install-1';row=json.loads((A/hold/'source-ready.json').read_text())['file'];verify(row['raw'])
dst=W/row['relative_path'];assert not dst.exists();dst.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(row['raw']['path'],dst)
rows.append({'path':row['relative_path'],'hold':hold,'before':None,'after':sha(dst)})
assert len(rows)==28 and len({r['path'] for r in rows})==28
record={'status':'raw_imported_not_yet_formatted_or_executed','imports':rows,'review':'Root read all installer migration diffs and runtime helper visibility diffs; selected installer and runtime contracts preserved.'}
(A/'root/production-import-1.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'imported':len(rows),'receipt_sha256':sha(A/'root/production-import-1.json')}))
