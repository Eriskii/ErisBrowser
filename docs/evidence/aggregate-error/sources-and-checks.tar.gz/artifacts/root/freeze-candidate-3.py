from pathlib import Path
import json,hashlib,re,subprocess
A=Path('/tmp/eris-aggregate-error-plan-1');W=A/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
parent=json.loads((A/'source-parent.json').read_text());old=parent['source_sha256']
newfiles=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
assert len(newfiles)==7 and all(p.endswith('.rs') for p in newfiles),newfiles
paths=sorted(set(old)|set(newfiles));source={p:sha(W/p) for p in paths};assert len(source)==1682
changed=[p for p in paths if old.get(p)!=source[p]];assert len(changed)==33,(len(changed),changed)
(A/'source-candidate-3.json').write_text(json.dumps({'base':parent['base'],'source_sha256':source},indent=2)+'\n')
testpaths=[p for p in newfiles if p.endswith('tests.rs')];assert len(testpaths)==5
newnames=[]
for p in testpaths:
 module=p.removesuffix('.rs').replace('/','::')
 module=module.removeprefix('src::')
 for name in re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(', (W/p).read_text()):
  newnames.append('src/lib.rs::'+module+'::'+name)
assert len(newnames)==27,(len(newnames),newnames)
(A/'root/candidate-roster-3.json').write_text(json.dumps({'new_groups':27,'new_names':sorted(newnames),'changed_source_paths':changed},indent=2)+'\n')
print(json.dumps({'sources':len(source),'changed':len(changed),'new_files':len(newfiles),'new_groups':len(newnames),'candidate_sha256':sha(A/'source-candidate-3.json')}))
