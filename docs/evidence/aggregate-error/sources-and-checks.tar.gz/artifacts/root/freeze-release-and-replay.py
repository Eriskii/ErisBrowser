import hashlib
import json
import shutil
import subprocess
import sys
from pathlib import Path

A=Path(__file__).resolve().parents[1];W=A/'worktree'
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())

receipt=A/'validation/host-release-1.json'
assert json.loads(receipt.read_bytes())['exit']==0
source=A/'source-candidate-4.json'
for p,h in json.loads(source.read_bytes())['source_sha256'].items():
    assert bind(W/p)['sha256']==h,p
final=A/'source-final.json';assert not final.exists();final.write_bytes(source.read_bytes())
binary=A/'eris-js-host-final-1';assert not binary.exists()
shutil.copy2(A/'target-msrv/release/eris-js',binary)
identity=dict(**bind(binary),source_inventory=bind(final),build_receipt=bind(receipt))
(A/'eris-js-host-final-1.json').write_text(json.dumps(identity,indent=2)+'\n')
comparisons=[]
for profile,old_name,label in [
    ('promise-all-settled','upstream-settled-1.json','upstream-settled-1'),
    ('promise-race','upstream-race-1.json','upstream-race-1'),
    ('promise-all','upstream-all-1.json','upstream-all-1'),
    ('promise-methods-async','upstream-existing-1.json','upstream-existing-1')]:
    report=A/(label+'.json')
    subprocess.run([sys.executable,str(A/'run-tool.py'),label,sys.executable,'-B',
        'tools/test262_conformance.py','--binary',str(binary),'--profile',profile,
        '--baseline','tests/conformance/test262-'+profile+'-current.json',
        '--output',str(report)],check=True)
    old=json.loads((A/'replay-parent'/old_name).read_bytes());new=json.loads(report.read_bytes())
    for key in ('cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts'):
        assert old[key]==new[key],(profile,key)
    assert new['regressions']==new['improvements']==[]
    assert new['harness_preflight_passed'] and all(r['verified'] for r in new['harness_preflight'])
    assert new['binary_sha256']==identity['sha256']
    comparisons.append(dict(profile=profile,parent=bind(A/'replay-parent'/old_name),report=bind(report),
        receipt=bind(A/'validation'/(label+'.json')),log=bind(A/'validation'/(label+'.log')),
        cases=len(new['cases']),controls=len(new['harness_preflight']),counts=new['counts'],
        exact_observations=True,regressions=0,improvements=0))
assert sum(r['cases'] for r in comparisons)==1050
assert sum(r['controls'] for r in comparisons)==348
assert bind(binary)['sha256']==identity['sha256']
for p,h in json.loads(source.read_bytes())['source_sha256'].items():assert bind(W/p)['sha256']==h,p
(A/'root/replay-validation.json').write_text(json.dumps(dict(status='pass',binary=identity,
    source=bind(final),comparisons=comparisons,exact_cases=1050,exact_controls=348,
    baseline_changes=0,qualification='Complete case and harness arrays match the published BC parent. Binary identity changes with rebuilt code; runner policies, corpus bytes, statuses and observation contents do not.'),indent=2)+'\n')
print('All1050 case and348 harness records exact across four profiles; no baseline changes.')
