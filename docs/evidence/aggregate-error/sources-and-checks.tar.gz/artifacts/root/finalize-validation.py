import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(name):return json.loads((A/name).read_text())
current=read('source-final.json')['source_sha256'];parent=read('source-parent.json')['source_sha256']
for p,h in current.items():assert bind(W/p)['sha256']==h,p
changed=sorted(p for p,h in current.items() if parent.get(p)!=h)
assert len(changed)==33 and len(current)==1682
assert current==read('source-candidate-4.json')['source_sha256']
rust=read('root/rust-validation.json');assert rust['status']=='complete' and rust['new_test_groups']==27
strict=[]
for label in ['format-check-2','default-clippy-2','host-vulkan-clippy-2']:
 receipt=A/'validation'/(label+'.json');log=A/'validation'/(label+'.log');r=json.loads(receipt.read_text())
 assert r['exit']==0 and r['sha256']==bind(log)['sha256'];strict.append(dict(receipt=bind(receipt),log=bind(log)))
replay=read('root/replay-validation.json');assert replay['status']=='pass' and replay['exact_cases']==1050 and replay['exact_controls']==348
ledger=dict(status='pass',base=read('source-parent.json')['base'],scope='AggregateError construction and genuine Error fallback branding within the implemented language subset.',source=bind(A/'source-final.json'),selected_source_inputs=1682,changed_source_paths=changed,production_paths=10,existing_test_migration_paths=18,existing_migration_groups=126,new_test_modules=5,new_test_groups=27,selected_existing_renames=4,public_semantic_groups=14,public_semantic_modes=28,public_terminal_groups=5,public_terminal_modes=20,installer_groups=2,installer_operation_rows=23,private_runtime_groups=6,private_runtime_operation_rows=57,budgets=dict(bootstrap=1_000_000,author=100_000,cumulative_heap=8*1024*1024),startup_observation=read('root/candidate-observation-1.json'),selected_installer=bind(A/'install-ledger-1/source-ready.json'),selected_runtime_contract=bind(A/'runtime-contract-1/source-ready.json'),focused_validation=bind(A/'root/focused-validation.json'),parent_controls=[bind(A/'root'/p) for p in ['parent-public-validation-1.json','parent-public-supplement-validation-1.json','parent-abort-validation-1.json']],source_reviews=[bind(A/p) for p in ['runtime-production-review-1/review.json','candidate-source-review-1/review.json','candidate-source-review-2/review.json','install-production-1/script-review.json','tests-install-review-1/source-review.json','tests-private-correction-1/script-review.json','migration-correction-1/layout-review.json','stage-fixture-correction-1/layout-review.json']],default_passed=3159,host_vulkan_passed=3513,result_rows_per_configuration=52,worker_checks_per_configuration=93,roster_validation=bind(A/'root/rust-validation.json'),strict_checks=strict,release_binary=replay['binary'],replay_validation=bind(A/'root/replay-validation.json'),exact_case_records=1050,exact_harness_records=348,baseline_changes=0,qualifications=[
 'Parent semantic14 groups:1passed,13failed; terminal5 allfailed. Every failed group stopped in its first sloppy source attempt; later readbacks and strict/alternative terminal attempts were not reached. First13-group run attempted14 modes, supplement1,terminal5; generic Error diagnostics alone do not identify each internal assertion.',
 'Initial candidate compilation failed before tests on an unsigned intermediate expression. A source-reviewed reordering preserves every accounting term. Independently spotted coupling fixture arrow allocation was moved to setup without changing selected expectations.',
 'Candidate2 bootstrap47passed/6failed because an earlier DataView fixture retained the new late prototype. The additional fixture exclusion preserves the old production stage guard, fees and expected metadata. Candidate3 bootstrap53passed. Final candidate4 removes only an unnecessary temporary clone in fixture queue preparation after Rust1.99 strict lint rejected it; all full suites were rerun on candidate4.',
 'Initialization reads Instant::now for performance_origin, and runs no author callback. Successful publication retains cumulative heap accounting and resets only author work.',
 'No separate Python suite rerun: tooling, corpora and baselines remain byte-identical; all four existing Promise release profiles were actually replayed.',
 'Selected source inventory is not the full build graph. Logical work and heap accounting are not CPU timings, physical allocation or RSS measurements.'
 ],limitations=[
 'Promise.any is absent; no new AggregateError upstream profile or complete ECMAScript compatibility claim.',
 'Existing Test262 response decoder remains unchanged and rejects an uncaught AggregateError intrinsic identity. Genuine runtime branding is retained.',
 'Existing language, proxy, realm and host object limitations are inherited.',
 'No production-security, Chromium-relative performance, GPU implementation change or new acquired-window result claimed.'
 ])
(A/'root/final-validation.json').write_text(json.dumps(ledger,indent=2)+'\n')
print('Validation ledger sealed:3159/3513 tests;1050cases and348controls exact.')
