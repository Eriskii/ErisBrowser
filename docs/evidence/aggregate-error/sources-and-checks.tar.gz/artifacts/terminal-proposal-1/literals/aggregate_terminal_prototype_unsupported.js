if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
var trace='',returnGets=0,returnCalls=0,caught=0,finalized=0,after=false,marker={},proto={},step=0;
var N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){trace+='P';eval('0');return proto;}});
var msg={toString:function(){trace+='M';return 'm';}};
var options={get cause(){trace+='C';return marker;}};
var it={};Object.defineProperty(it,'next',{get:function(){trace+='N';return function(){trace+='S';if(step++===0)return {get done(){trace+='D';return false;},get value(){trace+='V';return marker;}};return {done:true};};}});
Object.defineProperty(it,'return',{get:function(){returnGets++;trace+='R';return function(){returnCalls++;trace+='r';return {};};}});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';return function(){trace+='i';return it;};}});
queueMicrotask(function(){trace+='Q';});
try{Reflect.construct(AggregateError,[items,msg,options],N);after=true;}catch(e){caught++;trace+='K';}finally{finalized++;trace+='F';}
after=true;
