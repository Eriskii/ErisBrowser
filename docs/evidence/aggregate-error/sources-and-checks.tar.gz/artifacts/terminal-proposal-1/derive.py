"""Source-only terminal literal proposal and bounded quota obligations."""
from pathlib import Path
import hashlib
import json
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
H = P / 'terminal-proposal-1'
W = P / 'worktree'
BASE = '383985eded4889cf354c69857cce6ae9cc9b354c'
PRIOR = Path('/tmp/eris-promise-any-plan-1')

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2) + '\n')

assert not (H / 'source-ready.json').exists()
stages = [('prototype', 'P'), ('message', 'PM'), ('cause', 'PMC'), ('iterator_acquisition', 'PMCI'), ('iterator_value', 'PMCIiNSDV')]
readback = "[trace,returnGets,returnCalls,caught,finalized,after].join('|')"
cases = []
for stage, trace in stages:
    for kind, terminal in [('work', 'while(true){}'), ('unsupported', "eval('0');")]:
        body = {key: terminal if key == stage else '' for key, _ in stages}
        source = ("if(typeof AggregateError!=='function')throw new Error('AggregateError missing');\n"
            "var trace='',returnGets=0,returnCalls=0,caught=0,finalized=0,after=false,marker={},proto={},step=0;\n"
            "var N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){trace+='P';" + body['prototype'] + "return proto;}});\n"
            "var msg={toString:function(){trace+='M';" + body['message'] + "return 'm';}};\n"
            "var options={get cause(){trace+='C';" + body['cause'] + "return marker;}};\n"
            "var it={};Object.defineProperty(it,'next',{get:function(){trace+='N';return function(){trace+='S';if(step++===0)return {get done(){trace+='D';return false;},get value(){trace+='V';" + body['iterator_value'] + "return marker;}};return {done:true};};}});\n"
            "Object.defineProperty(it,'return',{get:function(){returnGets++;trace+='R';return function(){returnCalls++;trace+='r';return {};};}});\n"
            "var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';" + body['iterator_acquisition'] + "return function(){trace+='i';return it;};}});\n"
            "queueMicrotask(function(){trace+='Q';});\n"
            "try{Reflect.construct(AggregateError,[items,msg,options],N);after=true;}catch(e){caught++;trace+='K';}finally{finalized++;trace+='F';}\n"
            "after=true;\n")
        case_id = 'aggregate_terminal_' + stage + '_' + kind
        path = H / 'literals' / (case_id + '.js')
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(source)
        cases.append({'name': case_id, 'stage': stage, 'kind': kind, 'modes': ['sloppy', 'strict'], 'source': source, 'source_sha256': bind(path)['sha256'], 'readback': readback, 'expected': trace + '|0|0|0|0|false', 'expected_error': 'ResourceLimit' if kind == 'work' else 'Unsupported', 'source_kind_qualification': 'The resource variant exhausts unchanged finite author work inside its selected callback; it is not a heap-limit oracle.' if kind == 'work' else 'Existing unsupported eval is a host terminal completion, not an ordinary JavaScript exception.', 'literal': bind(path)})
assert len(cases) == 10
assert all('Promise.any' not in row['source'] for row in cases)
write('public-cases.json', {'status': 'prospective frozen terminal literals before implementation/execution', 'groups': 5, 'sources': 10, 'planned_modes': 20, 'cases': cases})

snapshots = []
for relative in ['src/script.rs', 'src/script/construction.rs', 'src/script/microtasks.rs', 'src/script/promise_all_settled_abort_tests.rs', 'src/script/promises/all_state.rs', 'src/script/promises/all_allocation_probe.rs', 'src/script/promises/factories.rs', 'src/script/machine.rs']:
    data = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + relative])
    path = H / 'source-snapshots' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    snapshots.append({'relative_path': relative, 'snapshot': bind(path), 'published_git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()})
write('source-bindings.json', {'published_base': BASE, 'files': snapshots, 'prior_literal_reference': bind(PRIOR / 'terminal-cases.json'), 'prior_reference_qualification': 'The original four AggregateError terminal source strings remain unchanged in the prior plan. This proposal separately adds an outer catch/finally witness, explicit NewTarget ordering and AggregateError-only readback fields. It does not claim byte-identical reuse.', 'selected_public_hold': bind(P / 'tests-public-1/source-ready.json'), 'selected_public_refresh': bind(P / 'tests-public-base-refresh-1/source-ready.json')})

write('public-contract.json', {
    'status': 'proposal requiring root selection before Rust conversion/import',
    'fixture': 'Adapt the existing allSettled fatal_stop shape, with one fresh Runtime::try_new and Document per source/mode. Require ResourceLimit for work variant and Unsupported for eval variant; the opposite classification must be false. Require runtime.microtasks_suspended(). Read the exact expression twice using the same execute mode; each must match the literal and leave suspension true and console empty.',
    'readback': readback,
    'no_manual_reset': 'No test writes steps, allocated, queue state or suspension in these public cases. Later execute readbacks use only the existing normal author-entry reset and must not resume Q.',
    'witnesses': 'P/M/C/I/i/N/S/D/V identify the exact reached stage. R/r witness forbidden return lookup/call; K/F witness forbidden catch/finally; Q witnesses forbidden queued-job execution; after remains false.',
    'scope': 'These are inherited host-terminal policy controls. Ordinary JavaScript exceptions and successful IteratorToList semantics are already separately frozen in the public semantic hold.',
    'parent_prediction': {'passed_groups': 0, 'failed_groups': 5, 'reason': 'First sloppy work case reaches the missing-AggregateError guard and produces ordinary Error before state variables, terminal callback, queue or outer try are reached.', 'unreached': 'The intended terminal stage, readbacks, strict row and Unsupported variant in each group. No observed parent outcome is asserted.'},
    'groups': [dict(stage=stage, source_names=[row['name'] for row in cases if row['stage'] == stage], expected=trace + '|0|0|0|0|false') for stage, trace in stages],
    'no_claim': 'No heap exhaustion, final-array admission, private numeric tariff, allocation-failure injection, or engine execution is established by these ten literals.'
})

private = {
    'status': 'bounded admission/terminal obligations; helper signatures and numeric cuts await Script fee plan/root selection',
    'purpose': 'Complement public callback work/Unsupported witnesses with actual finite work and accounted-heap refusals around new AggregateError ownership/publication boundaries, without reproducing all existing planner tests.',
    'selected_rows_to_freeze_later': [
        {'stage': 'shared-body admission before prototype lookup', 'cut': 'One-short/exact selected fixed admission, then a deliberately refusing first prototype operation.', 'expected_prefix': 'No P before fixed admission. No new object or array publication. Assert the exact reached counter debit; no fresh allowance or retry.'},
        {'stage': 'fresh branded error object after prototype lookup, before message', 'cut': 'Source-derived object-slot/bag work and typed heap threshold, using warm versus required cold provenance only as needed.', 'expected_prefix': 'P only; message/cause/iterator hooks absent. Any already completed reservation/accounting remains; no returned object or later callback.'},
        {'stage': 'message conversion and hidden message data property', 'cut': 'One work refusal at the conversion admission and one accounted-heap refusal at the first message storage/publication boundary; source fees must include all preceding target/prototype/object work.', 'expected_prefix': 'Exact P or PM boundary follows the selected order. No C/I, no inherited setter invocation; retain only admitted partial state.'},
        {'stage': 'cause HasProperty/Get and hidden cause data property', 'cut': 'A finite work cut before the cause Get plus a typed heap cut for its own-data storage, with object-only options and no getter duplication.', 'expected_prefix': 'PM or PMC as selected; no I. Cause is not read before HasProperty admission. Earlier message remains exactly as admitted.'},
        {'stage': 'first collected value/list growth', 'cut': 'One cold logical list growth work/heap admission failure after the selected iterator/value stage, with physical capacity provenance explicitly frozen.', 'expected_prefix': 'No second next and no IteratorClose; preserve cached next and exact retained value ownership. Do not substitute the spread65536 cap or allocator rounding.'},
        {'stage': 'normal exhaustion to shared dense-array publisher', 'cut': 'One work and one accounted-heap cut at the reused new_all_values_array admission, after the source-derived AggregateError prefix; retain existing publisher tariffs/body.', 'expected_prefix': 'Normal done observed, exhausted value unread, no close. All five parallel array tables and object counts retain their actual pre-publication prefix on publisher refusal. Existing publisher tests own exhaustive reserve-failure coverage.'},
        {'stage': 'final hidden errors property publication', 'cut': 'Exact/one-short work or heap admission for the final own-data field after a completed dense array, depending on actual selected property plan.', 'expected_prefix': 'No successful returned AggregateError on refusal. If the shared array was already fully published, retain its paid private rows rather than demand rollback or arbitrary graph teardown. Inherited errors setter stays unread.'}
    ],
    'minimal_execution_structure': [
        'Use actual existing public/prepared functions and natural helper entry points; do all setup, value preparation, physical capacity assertions and queue preparation before the single injected test allowance.',
        'Derive every literal work/heap cut from the frozen API/ledger and current helper source, including wrapper/target-copy and caller overhead. Do not measure candidate consumption to set expectations.',
        'For a caller-level terminal witness, precompile the JS wrapper with try/catch/finally during ordinary setup, obtain its function value, then call it through existing with_author_entry/call. This shares the injected remaining allowance and does not perform an execute reset.',
        'Prepare the Q callback during setup and enqueue it after the setup checkpoint, before injection. Let the real with_author_entry epilogue observe the terminal result; do not manually set suspension.',
        'After heap refusal, inspect frozen scalar/global values and arena lengths by borrowed Rust state. Do not try to execute a readback script with an already exceeded heap, or reset allocated to enable one.',
        'Once the natural caller has suspended the queue, invoke existing microtask_checkpoint twice; its early suspended return must preserve queue length, trace, steps and allocated. This is meaningful after heap refusal because it precedes any new admission.',
        'For direct helper cuts, assert only that helper’s selected ownership/accounting contract. Do not assume direct calls independently set the host-terminal latch unless that helper actually owns the observer.',
        'Use one successful adjacent boundary/control per new admission family only where needed; leave existing dense-array/planner exhaustive tests unchanged.'
    ],
    'existing_helper_source_facts': {
        'work': 'work(units) consumes the existing counter or sets it to zero and returns ResourceLimit; no allocation or reset.',
        'charge': 'charge(bytes) cumulatively increments allocated before rejecting values above MAX_HEAP. A refused heap ledger may remain over the limit.',
        'call': 'call delegates to call_with_new_target; it pays tick/stack/call entry and invokes the real machine, without resetting author work.',
        'with_author_entry': 'Existing work8 admission, real operation, terminal observation and checkpoint; fatal result suspends before checkpoint.',
        'checkpoint': 'Suspended state returns before work debit or queue pop.',
        'array_publisher': 'Existing new_all_values_array pays its23 fixed envelope, typed plans/work/heap, reserves five destinations, then bag9 before parallel pushes; its own terminal observer is retained.'
    },
    'limits': 'This is not a frozen executable quota module or selected numeric fee schedule. Final API/line ledger, meaningful reachability and expected partial-publication states require independent peer before root execution.'
}
write('private-boundaries.json', private)
artifacts = [bind(H / name) for name in ['public-cases.json', 'public-contract.json', 'private-boundaries.json', 'source-bindings.json', 'derive.py']]
artifacts += [row['literal'] for row in cases]
artifacts += [row['snapshot'] for row in snapshots]
write('source-ready.json', {'status': 'terminal_proposal_source_ready_unexecuted', 'published_base': BASE, 'public_groups': 5, 'public_sources': 10, 'public_planned_modes': 20, 'files': artifacts, 'qualification': 'Public literal expectations are frozen before implementation/execution; root selection and Rust conversion remain separate. Private stage obligations are intentionally symbolic pending the concrete fee/API plan. No live edits or project/engine/compiler execution.'})
print(json.dumps(bind(H / 'source-ready.json')))
