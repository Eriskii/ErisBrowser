from pathlib import Path
import difflib,hashlib,json,re,subprocess
P=Path('/tmp/eris-aggregate-error-plan-1');W=P/'worktree';D=P/'documentation-3';O=P/'documentation-review-1'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
verified=set()
def check(o):
 if isinstance(o,dict):
  if {'path','bytes','sha256'}<=o.keys():
   p=Path(o['path']);b=p.read_bytes();assert len(b)==o['bytes'] and sha(b)==o['sha256'],p;verified.add(str(p))
  for v in o.values():check(v)
 elif isinstance(o,list):
  for v in o:check(v)
m=json.loads((D/'source-ready.json').read_bytes());assert sha((D/'source-ready.json').read_bytes())=='776cb2dee6841664fde1b064b98879600ce4f7209f522be33140d3435d0d0371';check(m)
prior=json.loads(Path(m['prior']['path']).read_bytes());priorrows={x['relative_path']:x for x in prior['files']}
docrows=[]
for row in m['files']:
 rel=row['relative_path'];before=Path(row['before']['path']).read_bytes();raw=Path(row['raw']['path']).read_bytes()
 expected=''.join(difflib.unified_diff(before.decode().splitlines(keepends=True),raw.decode().splitlines(keepends=True),fromfile=('/dev/null' if rel=='docs/aggregate-error.md' else 'a/'+rel),tofile='b/'+rel)).encode()
 assert expected==Path(row['diff']['path']).read_bytes(),rel
 if rel!='docs/aggregate-error.md':
  old=subprocess.run(['git','show',m['published_base']+':'+rel],cwd=W,check=True,stdout=subprocess.PIPE).stdout
  assert old==before,rel
  ops=difflib.SequenceMatcher(a=before.decode().splitlines(keepends=True),b=raw.decode().splitlines(keepends=True),autojunk=False).get_opcodes()
  assert all(op in ('equal','insert') for op,*_ in ops),(rel,ops)
  inserted=sum(b2-b1 for op,a1,a2,b1,b2 in ops if op=='insert')
 else:assert before==b'';inserted=len(raw.splitlines())
 if row['same_as_prior_draft']:assert raw==Path(priorrows[rel]['raw']['path']).read_bytes()
 docrows.append(dict(path=rel,before_sha256=sha(before),raw_sha256=sha(raw),diff_exact=True,parent_git_exact=rel!='docs/aggregate-error.md',historical_lines_untouched=True,added_lines=inserted))
v=json.loads((P/'root/final-validation.json').read_bytes());check(v)
assert v['status']=='pass' and v['source']['sha256']==sha((P/'source-final.json').read_bytes())
assert (v['default_passed'],v['host_vulkan_passed'],v['new_test_groups'],v['result_rows_per_configuration'])==(3159,3513,27,52)
full=[]
for name,expected,compiler in [('default-full-2',3159,'+1.88.0'),('host-vulkan-full-2',3513,'+1.99.0')]:
 receipt=json.loads((P/'validation'/f'{name}.json').read_bytes());log=(P/'validation'/receipt['log']).read_bytes();assert receipt['exit']==0 and receipt['sha256']==sha(log)
 assert compiler in receipt['command'] and '--include-ignored' in receipt['command']
 if name.startswith('host'):assert 'test262-host,vulkan-raster' in receipt['command']
 rows=[tuple(map(int,r)) for r in re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log)]
 assert len(rows)==52 and sum(r[0] for r in rows)==expected and all(r[1:]==(0,0,0,0) for r in rows)
 full.append(dict(name=name,receipt=bind(P/'validation'/f'{name}.json'),log=bind(P/'validation'/receipt['log']),rows=52,passed=expected))
strict=[]
for name in ['default-clippy-2','host-vulkan-clippy-2','format-check-2','host-release-1']:
 p=P/'validation'/f'{name}.json';r=json.loads(p.read_bytes());assert r['exit']==0
 log=P/'validation'/r['log'];assert r['sha256']==sha(log.read_bytes())
 if 'clippy' in name:assert '--all-targets' in r['command'] and ['-D','warnings']==r['command'][-2:]
 strict.append(dict(name=name,receipt=bind(p),log=bind(log)))
rr=json.loads((P/'root/rust-validation.json').read_bytes());assert len(rr['new_names'])==27 and len(rr['selected_existing_test_renames'])==4
for c in rr['comparisons']:
 assert c['exact_old_roster_after_selected_renames_plus_new'] is True
 assert c['current']['result_rows']==c['previous']['result_rows']==52
 # Final independent audit is HTML-owned; docs claim is checked against bound root roster and actual summary rows.
replay=json.loads((P/'root/replay-validation.json').read_bytes());check(replay);replays=[]
for row in replay['comparisons']:
 a=json.loads(Path(row['parent']['path']).read_bytes());b=json.loads(Path(row['report']['path']).read_bytes())
 assert a['cases']==b['cases'] and a['harness_preflight']==b['harness_preflight']
 assert a['runner_policy']==b['runner_policy'] and a['runner_policy_sha256']==b['runner_policy_sha256']
 assert b['binary_sha256']==v['release_binary']['sha256'] and not b['regressions'] and not b['improvements']
 assert all(x['verified'] for x in b['harness_preflight']) and b['harness_preflight_passed']
 replays.append(dict(profile=row['profile'],cases=len(b['cases']),controls=len(b['harness_preflight']),full_arrays_exact=True,policy_exact=True,counts=b['counts']))
assert sum(x['cases'] for x in replays)==1050 and sum(x['controls'] for x in replays)==348
chapter=(D/'raw/docs/aggregate-error.md').read_text();validation=(D/'raw/docs/VALIDATION.md').read_text();intro=validation.split('## Separate trusted bootstrap allowance',1)[0]
for literal in ['3,159','3,513','1,050','348','899,203','1,761,871','27','53']:
 assert literal in chapter and literal in intro,literal
assert 'no separate full Python' in chapter and 'No separate full Python' in intro
assert 'no new AggregateError upstream' in chapter and 'no new AggregateError upstream' in intro
assert 'reads Instant::now' in v['qualifications'][3]
report=dict(status='clear',reviewer='/root/script',scope='Independent source-only seven-document review against actual receipts; no project execution/live edits. Full final-validation audit is separately HTML-owned.',manifest=bind(D/'source-ready.json'),published_base=m['published_base'],source_final=bind(P/'source-final.json'),final_validation=bind(P/'root/final-validation.json'),verified_bound_files=len(verified),documents=docrows,full_suite_claims=full,strict_and_release_claims=strict,replay_claims=replays,claims_checked=[
 'Callable/constructible AggregateError and ordered prototype/message/cause/iterator behavior agree with selected runtime and reviewed source; saved identities/dense Array/private branding limitations are accurate.',
 'Selected installer1103 work/typed17554 bytes, raw100797 consumed899203 remaining and1761871 accounted heap agree with recorded startup evidence. Bootstrap1m, author100k and8MiB unchanged.',
 'Twenty-seven new groups, 23 installer rows and57 private operations are stated separately from28 semantic and20 terminal mode attempts; parent failed groups stop in their first sloppy attempt.',
 'Compile arithmetic, precreated arrow, earlier-stage DataView exclusion and final lint slice correction are preserved as separate retained attempts. Candidate4 finalfull2/strict2 reruns are not conflated with prior candidates.',
 'Actual full1050 case/348 harness arrays and old policies were independently compared to retained parent reports; no baseline change or Python suite rerun is asserted.',
 'No new AggregateError profile, Promise.any, Proxy/realm capability, host decoder acceptance, remote CI success, complete ECMAScript/security/performance/RSS result is claimed.',
 'All six existing document files are pure insertions into published parent bytes. Historical sections and prior checkpoint counts remain exact; seventh path is a new chapter.',
 'Evidence links are clearly publication targets; root must create the referenced manifest/archive before publication.'
 ],findings=[],qualifications=['This review does not execute tests or reproduce compiler results. It authenticates retained raw receipts and documentation scope.','The selected source inventory is not asserted to cover the complete build graph; the docs retain logical-versus-physical accounting limits.'])
p=O/'review.json';p.write_text(json.dumps(report,indent=2,sort_keys=True)+'\n');print(json.dumps(bind(p)))
