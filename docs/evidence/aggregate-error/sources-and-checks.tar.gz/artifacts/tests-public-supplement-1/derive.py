"""Freeze one requested iterator witness, then append its Rust conversion."""
from pathlib import Path
import difflib
import hashlib
import json

P = Path('/tmp/eris-aggregate-error-plan-1')
H = P / 'tests-public-supplement-1'
REL = 'src/script/aggregate_error_semantic_tests.rs'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

assert not (H / 'source-ready.json').exists()
source = '''if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',calls=0,gets=0,poison=0,it={},item={};
Object.defineProperty(it,'next',{get:function(){gets++;trace+='N';return function(){
 trace+='S';if(calls++===0){
  Object.defineProperty(it,'next',{get:function(){poison++;throw new Error('replacement next');},configurable:true});
  return {get done(){trace+='D';return false;},get value(){trace+='V';return item;}};
 }
 return {get done(){trace+='D';return true;},get value(){poison++;throw new Error('exhausted value');}};
};},configurable:true});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';return function(){trace+='i';return it;};}});
var e=AggregateError(items);check(e.errors.length===1&&e.errors[0]===item&&gets===1&&calls===2&&poison===0);
var result=trace+'|'+gets+'|'+calls+'|'+poison;
'''
name = 'aggregate_iterator_caches_next_and_skips_exhausted_value'
expected = 'IiNSDVSD|1|2|0'
(H / 'source.js').write_text(source)
case = {'status': 'literal frozen before Rust conversion/execution', 'name': name, 'source': source, 'source_sha256': bind(H / 'source.js')['sha256'], 'readback': 'result', 'expected': expected, 'modes': ['sloppy', 'strict'], 'derivation': ['GetIterator reads iterator method I, calls it i, then reads next N once.', 'The first cached next call S replaces iterator.next, then its done D is false and value V is read once.', 'The second cached next call S has done D true; its poisoned value getter is never read. The replacement next getter is also never read.', 'Result contains exactly the original item; gets1/calls2/poison0.'], 'parent_prediction': 'First sloppy missing-AggregateError guard throws; all iterator statements, readback and strict row are unreached. Not observed.', 'primary_basis': ['https://tc39.es/ecma262/multipage/abstract-operations.html#sec-getiterator', 'https://tc39.es/ecma262/multipage/abstract-operations.html#sec-iteratorstepvalue', 'https://tc39.es/ecma262/multipage/abstract-operations.html#sec-iteratortolist']}
(H / 'case.json').write_text(json.dumps(case, indent=2) + '\n')

before = (P / 'tests-public-1/raw' / REL).read_bytes()
assert before == (P / 'tests-public-base-refresh-1/raw' / REL).read_bytes()
assert before == (P / 'worktree' / REL).read_bytes()
added = ('\n#[test]\nfn ' + name + '() {\n    observe(\n        ' + json.dumps(name) + ',\n        r###"' + source + '"###,\n        r###"result"###,\n        ' + json.dumps(expected) + ',\n    );\n}\n').encode()
raw = before + added
assert raw[:len(before)] == before and raw.count(b'#[test]') == 14
before_path = H / 'before' / REL
raw_path = H / 'raw' / REL
diff_path = H / 'diffs/src__script__aggregate_error_semantic_tests.rs.patch'
for path in [before_path, raw_path, diff_path]:
    path.parent.mkdir(parents=True, exist_ok=True)
before_path.write_bytes(before)
raw_path.write_bytes(raw)
diff_path.write_text(''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile='a/' + REL, tofile='b/' + REL)))
manifest = {
    'status': 'source_ready_unexecuted_additive_public_supplement',
    'groups_added': 1,
    'planned_modes_added': 2,
    'composed_groups': 14,
    'composed_planned_modes': 28,
    'files': [{'relative_path': REL, 'new_file': False, 'before': bind(before_path), 'raw': bind(raw_path), 'diff': bind(diff_path)}],
    'artifacts': [bind(H / name) for name in ['case.json', 'source.js', 'derive.py']],
    'origins': [bind(P / 'tests-public-1/source-ready.json'), bind(P / 'tests-public-base-refresh-1/source-ready.json'), bind(P / 'selection-1/primary-basis.json')],
    'checks': ['Original13-group module is an exact prefix; existing helper and registration are unchanged.', 'One explicit small iterator covers both cached next and unread done-result value with independent poison counters.', 'Source and literal expected trace are frozen before any root execution; no candidate output used.', 'Only external inert authoring/hash/diff work; no live edits or project execution.'],
    'scope': 'Root-selected narrow semantic supplement; no new terminal, quota, Promise.any or host decoder behavior.'
}
(H / 'source-ready.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(bind(H / 'source-ready.json')))
