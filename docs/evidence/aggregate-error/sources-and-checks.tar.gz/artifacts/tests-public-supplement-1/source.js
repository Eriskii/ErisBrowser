if(typeof AggregateError!=='function')throw new Error('AggregateError missing');
function check(v){if(!v)throw new Error('oracle');}
var trace='',calls=0,gets=0,poison=0,it={},item={};
Object.defineProperty(it,'next',{get:function(){gets++;trace+='N';return function(){
 trace+='S';if(calls++===0){
  Object.defineProperty(it,'next',{get:function(){poison++;throw new Error('replacement next');},configurable:true});
  return {get done(){trace+='D';return false;},get value(){trace+='V';return item;}};
 }
 return {get done(){trace+='D';return true;},get value(){poison++;throw new Error('exhausted value');}};
};},configurable:true});
var items={};Object.defineProperty(items,Symbol.iterator,{get:function(){trace+='I';return function(){trace+='i';return it;};}});
var e=AggregateError(items);check(e.errors.length===1&&e.errors[0]===item&&gets===1&&calls===2&&poison===0);
var result=trace+'|'+gets+'|'+calls+'|'+poison;
