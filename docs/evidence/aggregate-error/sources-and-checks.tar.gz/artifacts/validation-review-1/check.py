"""Inert independent receipt/log/hash review. Does not import project code."""
from pathlib import Path
import collections
import hashlib
import json
import re

P = Path('/tmp/eris-aggregate-error-plan-1')
W = P / 'worktree'
OUT = P / 'validation-review-1'

def read(path):
    return json.loads(Path(path).read_text())

def bind(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

checked_bindings = {}
def check_bindings(value):
    if isinstance(value, dict):
        if all(k in value for k in ('path', 'bytes', 'sha256')):
            actual = bind(value['path'])
            assert all(actual[k] == value[k] for k in actual), value['path']
            checked_bindings[actual['path']] = actual
        for child in value.values():
            check_bindings(child)
    elif isinstance(value, list):
        for child in value:
            check_bindings(child)

def receipt(path, expected_exit=0):
    value = read(path)
    log = Path(path).parent / value['log']
    assert value['exit'] == expected_exit, path
    assert bind(log)['sha256'] == value['sha256'], path
    return dict(receipt=bind(path), log=bind(log), command=value['command'], exit=value['exit'])

def rust_log(path):
    target = None
    names = []
    rows = []
    for line in Path(path).read_text().splitlines():
        running = re.match(r'\s*Running (?:unittests )?(\S+) \(', line)
        if running:
            target = running.group(1)
        doc = re.match(r'\s*Doc-tests (\S+)', line)
        if doc:
            target = 'Doc-tests ' + doc.group(1)
        name = re.match(r'^test (\S+) \.\.\. ok$', line)
        if name:
            assert target is not None
            names.append(target + '::' + name.group(1))
        result = re.match(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', line)
        if result:
            rows.append(dict(target=target, status=result.group(1), totals=[int(x) for x in result.groups()[1:]]))
    assert len(names) == len(set(names)), path
    totals = [sum(row['totals'][i] for row in rows) for i in range(5)]
    assert totals[0] == len(names), path
    return dict(rows=rows, totals=totals, names=sorted(names))

ledger = read(P / 'root/final-validation.json')
roster = read(P / 'root/rust-validation.json')
replay = read(P / 'root/replay-validation.json')
for value in (ledger, roster, replay):
    check_bindings(value)
source = read(P / 'source-final.json')
assert (P / 'source-final.json').read_bytes() == (P / 'source-candidate-4.json').read_bytes()
assert len(source['source_sha256']) == 1682
for path, digest in source['source_sha256'].items():
    assert bind(W / path)['sha256'] == digest, path

rust_results = []
new_names = set(read(P / 'root/candidate-roster-4.json')['new_names'])
assert len(new_names) == 27
for comparison in roster['comparisons']:
    current = rust_log(comparison['current']['log']['path'])
    previous = rust_log(comparison['previous']['log']['path'])
    for side, parsed in [('current', current), ('previous', previous)]:
        claimed = comparison[side]
        assert parsed['names'] == claimed['passed_names']
        assert parsed['totals'] == claimed['totals']
        assert len(parsed['rows']) == claimed['result_rows'] == 52
        assert parsed['totals'][1:] == [0, 0, 0, 0]
        assert all(row['status'] == 'ok' for row in parsed['rows'])
        checked = receipt(claimed['receipt']['path'])
        assert '--include-ignored' in checked['command']
    renamed = set(previous['names'])
    assert len(comparison['renames']) == 4
    for change in comparison['renames']:
        assert change['before'] in renamed and change['after'] not in renamed
        renamed.remove(change['before'])
        renamed.add(change['after'])
    assert not renamed & new_names
    assert set(current['names']) == renamed | new_names
    worker = [row for row in current['rows'] if row['target'] == 'tests/worker.rs']
    assert len(worker) == 1 and worker[0]['totals'] == [93, 0, 0, 0, 0]
    rust_results.append(dict(current_log=comparison['current']['log'], previous_log=comparison['previous']['log'], current_passed=current['totals'][0], previous_passed=previous['totals'][0], result_rows=52, exact_prior_plus_27_after_four_renames=True, worker_passed=93))
assert [x['current_passed'] for x in rust_results] == [3159, 3513]

strict = [receipt(P / 'validation' / (name + '.json')) for name in ('format-check-2', 'default-clippy-2', 'host-vulkan-clippy-2', 'host-release-1')]
binary = read(P / 'eris-js-host-final-1.json')
check_bindings(binary)
assert binary == ledger['release_binary'] == replay['binary']
assert binary['source_inventory'] == bind(P / 'source-final.json')

replays = []
case_count = control_count = 0
for comparison in replay['comparisons']:
    before = read(comparison['parent']['path'])
    after = read(comparison['report']['path'])
    assert before['cases'] == after['cases']
    assert before['harness_preflight'] == after['harness_preflight']
    for key in ('revision', 'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256', 'counts', 'suite', 'source_files', 'source_tests', 'mode_cases', 'fixture_files', 'harness_preflight_passed'):
        assert before[key] == after[key], (comparison['profile'], key)
    assert after['full_test262_conformance'] is False
    assert after['harness_preflight_passed'] is True
    assert after['binary'] == binary['path'] and after['binary_sha256'] == binary['sha256']
    assert not after['regressions'] and not after['improvements']
    actual_counts = dict(collections.Counter(row['status'] for row in after['cases']))
    assert actual_counts == after['counts'] == comparison['counts']
    assert len({row['id'] for row in after['cases']}) == len(after['cases'])
    assert len(after['cases']) == comparison['cases']
    assert len(after['harness_preflight']) == comparison['controls']
    run = receipt(comparison['receipt']['path'])
    assert binary['path'] in run['command']
    assert '--baseline' in run['command'] and '--record-baseline' not in run['command']
    baseline_path = W / run['command'][run['command'].index('--baseline') + 1]
    baseline_relative = str(baseline_path.relative_to(W))
    assert source['source_sha256'][baseline_relative] == read(P / 'source-parent.json')['source_sha256'][baseline_relative]
    cases = read(baseline_path)['cases']
    assert cases == {row['id']: {key: row[key] for key in ('status', 'case_sha256', 'source_sha256')} for row in after['cases']}
    case_count += len(after['cases'])
    control_count += len(after['harness_preflight'])
    replays.append(dict(profile=comparison['profile'], cases=comparison['cases'], controls=comparison['controls'], counts=actual_counts, complete_case_and_control_arrays_exact=True, unchanged_baseline=bind(baseline_path), binary_identity_verified=True))
assert (case_count, control_count) == (1050, 348)

parent_results = []
for label, expected in [('parent-public-1', (1,12)), ('parent-public-supplement-1', (0,1)), ('parent-abort-1', (0,5))]:
    checked = receipt(P / 'validation' / (label + '.json'), 101)
    parsed = rust_log(checked['log']['path'])
    assert len(parsed['rows']) == 1 and tuple(parsed['totals'][:2]) == expected
    log = Path(checked['log']['path']).read_text()
    assert log.count('strict=false') == expected[1] and 'strict=true' not in log
    parent_results.append(dict(label=label, **checked, passed=expected[0], failed=expected[1], failed_groups_first_sloppy_attempt_only=True))

interruptions = [receipt(P / 'validation' / (label + '.json'), code) for label,code in [('aggregate-focused-1',101),('bootstrap-focused-1',101),('host-vulkan-clippy-1',101)]]
assert 'test result:' not in (P / 'validation/aggregate-focused-1.log').read_text()
assert rust_log(P / 'validation/bootstrap-focused-1.log')['totals'][:2] == [47,6]
assert rust_log(P / 'validation/bootstrap-focused-2.log')['totals'][:2] == [53,0]
assert 'cloned_ref_to_slice_refs' in (P / 'validation/host-vulkan-clippy-1.log').read_text()
startup = ledger['startup_observation']
assert startup['source'] == bind(P / 'source-candidate-3.json')
raw_log = Path(startup['log']['path']).read_text()
assert 'remaining=899203 allocated=1761871 objects=754 capacity=754 native=300 prototypes=26 globals=213' in raw_log
assert startup['consumed_work'] == 1_000_000 - startup['raw_remaining'] == 100797
assert startup['work_delta'] == 100797 - 99694 == 1103
assert startup['accounted_heap_delta'] == 1761871 - 1744317 == 17554
assert ledger['budgets'] == dict(bootstrap=1_000_000, author=100_000, cumulative_heap=8*1024*1024)
parent_map = read(P / 'source-parent.json')['source_sha256']
for path in parent_map:
    if path.startswith('tools/') or path.startswith('tests/conformance/'):
        assert parent_map[path] == source['source_sha256'][path], path

checks = dict(status='clear', rust=rust_results, strict_and_release=strict, replays=replays, parent=parent_results, retained_interruptions=interruptions, verified_binding_count=len(checked_bindings), selected_final_inputs_checked=1682, exact_case_records=case_count, exact_control_records=control_count, startup_observation_attributed_to_candidate3=True, final_execution_sources_attributed_to_candidate4=True)
(OUT / 'checks.json').write_text(json.dumps(checks, indent=2)+'\n')
print(json.dumps(bind(OUT / 'checks.json')))
