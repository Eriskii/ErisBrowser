"""Read-only source/format/inventory checks. No project imports or execution."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-aggregate-error-plan-1')
O = P / 'candidate-source-review-1'
W = P / 'worktree'
BASE = '383985eded4889cf354c69857cce6ae9cc9b354c'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def dump(name, data):
    (O / name).write_text(json.dumps(data, indent=2) + '\n')

def lex(source):
    tokens, literals, comments = [], [], []
    at = 0
    while at < len(source):
        if source[at].isspace():
            at += 1
            continue
        if source.startswith('//', at):
            end = source.find('\n', at)
            if end < 0: end = len(source)
            comments.append(source[at:end]); at = end; continue
        if source.startswith('/*', at):
            end, depth = at + 2, 1
            while depth:
                assert end < len(source)
                if source.startswith('/*', end): depth += 1; end += 2
                elif source.startswith('*/', end): depth -= 1; end += 2
                else: end += 1
            comments.append(source[at:end]); at = end; continue
        raw = re.match(r'(?:b|c)?r(\#*)"', source[at:])
        if raw:
            endmark = '"' + raw[1]
            end = source.index(endmark, at + raw.end()) + len(endmark)
            token = source[at:end]; tokens.append(token); literals.append(token); at = end; continue
        ordinary = re.match(r'(?:b|c)?"(?:\\[\s\S]|[^"\\])*"', source[at:])
        char = re.match(r"b?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'", source[at:])
        if ordinary or char:
            token = (ordinary or char)[0]; tokens.append(token); literals.append(token); at += len(token); continue
        word = re.match(r'[A-Za-z_0-9]+', source[at:])
        if word:
            tokens.append(word[0]); at += len(word[0]); continue
        tokens.append(source[at]); at += 1
    return tokens, literals, comments

parent_record = json.loads((P / 'source-parent.json').read_text())
s2_record = json.loads((P / 'source-candidate-2.json').read_text())
s3_record = json.loads((P / 'source-candidate-3.json').read_text())
assert parent_record['base'] == s2_record['base'] == s3_record['base'] == BASE
parent = parent_record['source_sha256']; s2 = s2_record['source_sha256']; s3 = s3_record['source_sha256']
assert len(parent) == 1675 and len(s2) == len(s3) == 1682
assert not set(parent) - set(s2) and set(s2) == set(s3)
assert [path for path in s2 if s2[path] != s3[path]] == ['src/script/data_view/bootstrap/tests.rs']
for path, digest in s3.items(): assert sha((W / path).read_bytes()) == digest, path

# Authenticate every selected parent input against the actual published blob,
# rather than treating an inherited SHA256 ledger as its own provenance.
paths = sorted(parent)
result = subprocess.run(['git', '-C', str(W), 'cat-file', '--batch'],
                        input=''.join(BASE + ':' + path + '\n' for path in paths).encode(),
                        stdout=subprocess.PIPE, check=True).stdout
at, parent_bytes, parent_sources = 0, 0, {}
for path in paths:
    nl = result.index(b'\n', at)
    header = result[at:nl].decode().split()
    assert len(header) == 3 and header[1] == 'blob', (path, header)
    length = int(header[2]); raw = result[nl + 1:nl + 1 + length]
    assert result[nl + 1 + length:nl + 2 + length] == b'\n'
    at = nl + 2 + length; parent_bytes += length
    assert sha(raw) == parent[path], path
    if path.endswith('.rs'): parent_sources[path] = raw.decode()
assert at == len(result)

changed2 = sorted(path for path in s2 if parent.get(path) != s2[path])
changed3 = sorted(path for path in s3 if parent.get(path) != s3[path])
assert len(changed2) == 32 and len(changed3) == 33
tracked_delta = subprocess.check_output(['git', '-C', str(W), 'diff', '--name-only', '--no-renames', BASE], text=True).splitlines()
untracked = subprocess.check_output(['git', '-C', str(W), 'ls-files', '--others', '--exclude-standard'], text=True).splitlines()
assert len(untracked) == 7 and sorted(set(tracked_delta) | set(untracked)) == changed3
assert sorted(untracked) == sorted(set(s3) - set(parent))

composition = json.loads((O / 'composition.json').read_text())
format_rows, comma_changes = [], []
for row in composition:
    path = row['relative_path']
    held = Path(row['held_path']).read_text(); current = (W / path).read_text()
    assert sha(held.encode()) == row['held_sha256']
    assert sha(current.encode()) == row['final_sha256'] == s3[path]
    if held != current:
        a, al, ac = lex(held); b, bl, bc = lex(current)
        assert al == bl, ('literal change', path)
        assert ac == bc, ('comment change', path)
        assert [t for t in a if t != ','] == [t for t in b if t != ','], ('token change', path)
        edits = []
        for tag, i, j, k, l in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
            if tag == 'equal': continue
            assert all(t == ',' for t in a[i:j] + b[k:l]), (path, tag, a[i:j], b[k:l])
            edits.append({'removed': len(a[i:j]), 'added': len(b[k:l]),
                          'before_context': a[max(0, i - 8):j + 3], 'after_context': b[max(0, k - 8):l + 3]})
        comma_changes.extend({'path': path, **edit} for edit in edits)
        format_rows.append({'path': path, 'literal_tokens_unchanged': len(al), 'comments_unchanged': len(ac),
                            'ordered_tokens_excluding_optional_commas_exact': True, 'comma_edits': len(edits),
                            'diff': bind(Path(row['format_diff_path']))})
assert len(format_rows) == 5

test_pattern = re.compile(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn\s+(\w+)\s*\(')
names = []
for path in untracked:
    for name in test_pattern.findall((W / path).read_text()):
        module = path.removesuffix('.rs').replace('/', '::').removeprefix('src::')
        names.append('src/lib.rs::' + module + '::' + name)
assert len(names) == len(set(names)) == 27
for n in [2, 3]:
    roster = json.loads((P / f'root/candidate-roster-{n}.json').read_text())
    assert roster['new_groups'] == 27 and roster['new_names'] == sorted(names)
    assert roster['changed_source_paths'] == (changed2 if n == 2 else changed3)

renames = []
for path in changed3:
    if path not in parent_sources: continue
    before = set(test_pattern.findall(parent_sources[path])); after = set(test_pattern.findall((W / path).read_text()))
    removed, added = sorted(before - after), sorted(after - before)
    if removed or added:
        assert len(removed) == len(added), (path, removed, added)
        renames.append({'path': path, 'before': removed, 'after': added})
assert sum(len(row['before']) for row in renames) == 4

# Root's two candidate2 corrections are distinct: arithmetic ordering and one
# coupling fixture source; candidate3 adds only pre-DataView stage reconstruction.
stage = json.loads((P / 'stage-fixture-correction-1/source-ready.json').read_text())
stage_before = Path(stage['before']['path']).read_bytes()
stage_after = Path(stage['raw']['path']).read_bytes()
addition = b'    // Exclude the late AggregateError prototype when reconstructing this earlier stage.\n    assert!(runtime.prototypes.remove("AggregateError").is_some());\n'
assert stage_after.count(addition) == 1 and stage_after.replace(addition, b'', 1) == stage_before
assert sha(stage_before) == s2[stage['path']] == parent[stage['path']]
assert sha(stage_after) == s3[stage['path']]
typed = json.loads((P / 'migration-correction-1/source-ready.json').read_text())
t_before = Path(typed['before']['path']).read_text(); t_after = Path(typed['raw']['path']).read_text()
ta = '            - 1103\n            + (BOOTSTRAP_STEPS - MAX_STEPS)\n'
tb = '            + (BOOTSTRAP_STEPS - MAX_STEPS)\n            - 1103\n'
assert t_before.count(ta) == 1 and t_before.replace(ta, tb, 1) == t_after

dump('checks.json', {'status': 'clear', 'parent_inputs': len(parent), 'published_parent_bytes_hashed': parent_bytes,
                     'candidate2_inputs': len(s2), 'candidate2_changed_paths': len(changed2),
                     'candidate3_inputs': len(s3), 'candidate3_changed_paths': len(changed3),
                     'no_parent_paths_dropped': True, 'tracked_and_untracked_worktree_delta_exact': True,
                     'new_files': sorted(untracked), 'new_groups': sorted(names), 'selected_renames': renames,
                     'format_rows': format_rows, 'optional_comma_edits': comma_changes,
                     'candidate2_to3_only_path': stage['path'],
                     'correction_inverses_exact': True,
                     'scope': 'Selected inventory, with published blob joins; no claim that inherited selected inventory covers every possible dynamic or archival source input.',
                     'no_execution': 'Only stdlib source/hash/diff processing and read-only Git; no project imports, compiler, formatter, tests or engine.'})
print(json.dumps({'checks': bind(O / 'checks.json'), 'renames': renames,
                  'format_files': len(format_rows), 'optional_comma_edits': len(comma_changes)}))
