from pathlib import Path
import hashlib,json,subprocess
P=Path('/tmp/eris-aggregate-error-plan-1');D=P/'runtime-contract-draft-1';W=P/'worktree'
BASE='383985eded4889cf354c69857cce6ae9cc9b354c'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(name,value):
 p=D/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(value,indent=2)+'\n')
paths=['src/script.rs','src/script/construction.rs','src/script/machine/calls.rs','src/script/machine.rs','src/script/dom_prototypes.rs','src/script/property_keys.rs','src/script/array_from.rs','src/script/promises.rs','src/script/promises/factories.rs','src/script/promises/install.rs','src/script/promises/all_state.rs','src/script/machine/call_spread.rs','src/script/microtasks.rs','src/script/throw_metadata.rs','src/bin/eris-js.rs','tools/test262_conformance.py']
parent=json.loads((P/'source-parent.json').read_text())
assert parent['base']==BASE
sources=[]
for rel in paths:
 b=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
 assert hashlib.sha256(b).hexdigest()==parent['source_sha256'][rel]
 out=D/'sources'/rel;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
 sources.append(dict(relative=rel,snapshot=bind(out)))
dump('source-bindings.json',dict(published_base=BASE,parent=bind(P/'source-parent.json'),files=sources))
dump('interfaces.json',dict(status='concrete prospective runtime contract; new fixed envelopes await root selection and private tests',scope='AggregateError only, plus genuine existing Error Object.prototype.toString fallback. No Promise.any, Error.isError, SuppressedError, host decoder/policy or Runtime/State field changes.',root_selected=['Late map-backed installer preserving existing IDs; saved intrinsic prototype and constructor metadata.', 'Visibility-only reuse of existing Promise growth/object-slot planners and new_all_values_array; all old helper bodies/tariffs unchanged.', 'Heap-derived temporary list maximum; no imported call-spread65536 cap.', 'Current callable Rc<Native> supplies NewTarget; no mutable global lookup.', 'Genuine private AggregateError brand retained; existing transport decoder boundary remains explicit.'],new_module='src/script/aggregate_error.rs',new_installer_child='src/script/aggregate_error/install.rs',interfaces=[dict(name='Runtime::aggregate_error_call',signature='(&mut self, native: &Rc<Native>, arguments: &[Value], doc: &mut Document) -> Result<Value>',meaning='Called only by invoke_native AggregateError arm. Inside terminal-observed closure, pay target2 then clone current Rc into Value::Native and invoke common body. Dynamic this is ignored. Refusal cannot bypass existing native stack unwind.'),dict(name='Runtime::aggregate_error_construct',signature='(&mut self, arguments: &[Value], new_target: &Value, doc: &mut Document) -> Result<Value>',meaning='Called by dedicated construct_inner AggregateError arm after existing constructor/NewTarget validation and bound-target substitution. Pay target2 then clone supplied target and invoke same body, all inside terminal-observed closure.'),dict(name='Runtime::aggregate_error_body',signature='(&mut self, arguments: &[Value], new_target: Value, doc: &mut Document) -> Result<Value>',meaning='Private common body. Incoming target copy/release is prepaid by one of the two wrappers. Read no mutable global constructor or Array.'),dict(name='Runtime::aggregate_error_named_get',signature='(&mut self, receiver: Value, name: &str, doc: &mut Document) -> Result<Value>',meaning='Only fixed static prototype/next/done/value keys. fixed2 then dom_proto_text(name) then get_property_key(receiver,&key,doc). Incoming receiver release is prepaid by wrapper/body/iterator caller.'),dict(name='Runtime::new_aggregate_error_object',signature='(&mut self, prototype: Value) -> Result<usize>',meaning='fixed8; object_slot_plan current objects,1; pay plan work/bytes, reserve if required; dom_proto_object(Some(prototype),3); set existing intrinsic_error=Some("AggregateError"); return ID. No new layout field.'),dict(name='Runtime::define_aggregate_error_data',signature='(&mut self, object: usize, name: &str, value: Value) -> Result<()>',meaning='Only static message/cause/errors names. fixed4 then valid object+AggregateError private brand check; dom_proto_text(name); dom_proto_property with Property::data(value,true,false,true). No inherited setters. Caller prepays incoming value cleanup.'),dict(name='Runtime::install_aggregate_error_cause',signature='(&mut self, object: usize, options: &Value, doc: &mut Document) -> Result<()>',meaning='fixed10; return for !js_object(options); fixed cause key; find_property_key_in as HasProperty without invoking accessor. If present, pay clone1 before options.clone Get using same key; then define_aggregate_error_data creates its own fixed cause key. Presence remains distinct from undefined.'),dict(name='AggregateIterator',signature='{ iterator: Value, next: Value }',meaning='Private operation-local structure only; acquire borrows source and next_value yields Option<ReceivedAggregateValue>. No author Close on any abrupt branch.'),dict(name='ReceivedAggregateValue',signature='opaque tuple(Value)',meaning='Receipt produced only by a reached, prepaid iterator attempt. Incoming release is funded before append can refuse.'),dict(name='AggregateList',signature='{ values: Vec<Value>, admitted_capacity: usize }',meaning='Local flat list. empty_prepaid, append_received(runtime,receipt), into_values. No Runtime field, persistent arena, prototype or author-facing object.'),dict(name='Runtime::aggregate_error_collect',signature='(&mut self, source: &Value, doc: &mut Document) -> Result<Vec<Value>>',meaning='collection8, empty list, acquire, next/append loop, transfer Vec. No alternate test-only execution implementation.')],visibility_only=[dict(path='src/script/promises.rs',edits=['Expose add/mul only if imported, otherwise keep local checked arithmetic; no body changes.', 'pub(super) GrowthPlan with pub(super) target/work/bytes fields, pub(super) growth_plan.', 'Replace cfg(test)-only object_slot_plan use with pub(super) re-export of same helper.', 'Re-export install::tree as intrinsic_tree under pub(super), no module-wide public exposure.']),dict(path='src/script/promises/all_state.rs',edits=['new_all_values_array becomes pub(in crate::script); body/probes/observer exact.']),dict(path='src/script/promises/install.rs',edits=['tree and promise_native become pub(in crate::script); bodies exact. The re-export must not exceed the defining item visibility.']),dict(path='src/script/promises/factories.rs',edits=['object_slot_plan becomes pub(in crate::script); body exact. This permits the selected promises re-export.'])],routing=[dict(path='src/script/machine/calls.rs',edit='One AggregateError match arm invokes aggregate_error_call(&native,&arguments,doc), before generic native_call route; result stays in existing unwind block.'),dict(path='src/script/construction.rs',edit='Add AggregateError to existing Window-native is_constructor list and one dedicated construct_inner arm calling aggregate_error_construct(&arguments,&new_target,doc). Keep old seven-Error arm exact.'),dict(path='src/script.rs',edit='Register new production child, append late installer after current final initializer, add one ErrorData predicate to Object.toString fallback classification. No intrinsic_error_type whitelist or old error_object modification.'),dict(path='src/script/dom_prototypes.rs',edit='Add aggregate_error::METADATA_OBJECTS=2 to existing upfront BOOTSTRAP_OBJECTS reservation; no second installer reserve.')],diagnostics='Writing Some("AggregateError") to existing private intrinsic_error is genuine ErrorData branding. Existing throw_metadata can already emit intrinsic_name AggregateError for canonical constructor metadata, and ErrorKind::Thrown returns it directly. Existing runner decoders reject unknown AggregateError identity; do not hide the brand, alter whitelist/policy, or claim that transport support exists.',layout='No persistent type gains a field or variant. Local list/iterator wrappers have ordinary Value/Vec payloads; account their heap using actual sizeof, not new hardcoded ABI guesses. Existing ScriptObject/Runtime/Promise shapes must stay unchanged.'))
fees=[
 dict(id='target',work=2,when='Before either wrapper clones its borrowed target into an owned Value.',proof=['one retained handle copy','one incoming target release if body admission refuses'],heap=0),
 dict(id='body',work=16,when='First statement of common body, before prototype key allocation/Get.',proof=['eight bounded scalar/control slots: three argument selections, message branch, cause handoff, collect handoff, final property handoff, return/observer handoff','eight conservative outer retained-handle/release slots: incoming target, prototype result, instance token, message conversion temporary, two possible cause-presence descriptor handles, cause result, final Array token'],heap=0,qualification='Target release is deliberately also covered by wrapper2, because body16 may refuse before creating its envelope. Do not refund conservative overlap. Nested helper-owned keys/list entries have their own credits.'),
 dict(id='named_get',work=2,when='Before fixed-name key construction.',proof=['receiver handoff/cleanup','temporary fixed-key cleanup'],heap=0,additional='dom_proto_text(name):8+2L work,64+4L bytes, then unchanged get_property_key costs. Incoming receiver cleanup is also covered before this debit can refuse.'),
 dict(id='instance',work=8,when='Before instance object-slot plan/reservation.',proof=['prototype validation','plan control','reserve control','capture object ID','private brand publication','result construction','prototype handoff/cleanup','result handoff'],heap=0,additional='object_slot_plan<ScriptObject>(len,physical,1) work+bytes; then unchanged bag9 with72+A+D+3K bytes. Caller body funds incoming prototype on refusal of8.'),
 dict(id='own_data',work=4,when='Before checking private object ID/brand and before fixed key construction.',proof=['checked owner lookup','private brand check','own data descriptor/publication handoff','temporary key cleanup'],heap=0,additional='dom_proto_text(name) then dom_proto_property at current own-property count and physical order capacity. Body/cause/array owner prepays incoming value release.'),
 dict(id='cause',work=10,when='Before options object classification, including primitive early return.',proof=['four bounded control slots: object gate,key preparation,presence branch,publication handoff','six conservative cleanup slots: fixed key,two possible presence-descriptor handles,Get receiver,cause payload,early-return/handoff cleanup'],heap=0,additional='Object options: cause key18work/84bytes + unchanged HasProperty traversal. If present: clone1 before receiver clone + unchanged Get + own_data stages. Primitive options are never boxed or inspected.'),
 dict(id='collection',work=8,when='Before temporary list construction and iterator acquisition.',proof=['list header initialization and invariant setup4','iterator/list container lifetime, final ownership transfer and cleanup4'],heap=0),
 dict(id='acquisition',work=8,when='Before GetMethod(@@iterator).',proof=['bounded acquisition/control4','source/method/iterator/next temporary ownership and release4'],heap=0,additional='Existing array_from_iterator_method; clone1 before source clone into Call; validate iterator object; clone1 before iterator clone into named_get(next). This caches next exactly once without an eager callability check.'),
 dict(id='attempt',work=8,when='Before each next call, including final done:true call.',proof=['bounded step/result/done/value control4','step/done/incoming-value/temporary cleanup4'],heap=0,additional='clone2 before cached next+iterator copies into Call; object result check; clone1 before retaining original step for value while named_get(done) consumes its copy. If done false, named_get(value) consumes original step; return opaque received-value receipt. No return getter/read/call.'),
 dict(id='append',work=8,when='Before list invariant checks, growth planning/reservation or publication.',proof=['len/logical/physical/cap guards4','growth/publication transition2','retained value move and eventual release2'],heap=0,additional='Use existing growth_plan<Value>(len,logical,1). Pay plan.work then plan.bytes, try_reserve_exact only if target present, then publish logical capacity and push in one infallible block. Incoming value release was prepaid by attempt8 before append8 may refuse.'),
 dict(id='retained_clone',work=1,when='Before each reached clone separately identified in the sequence.',proof=['one scalar/shared-handle copy'],heap=0,qualification='Caller helper envelope must already cover that handle release on downstream refusal. This is direct handle accounting, not an assertion that existing Native.receiver Rc ownership is recursively flat.'),
 dict(id='brand_fallback',work=0,when='Existing Object.toString fallback match, only after current @@toStringTag path found no string.',proof=['one additional bounded private field predicate under existing native classification/dispatch convention'],heap=0,qualification='Proposed zero-extra scalar branch debit requires root selection. No new traversal, allocation, clone or tag coercion. Existing ErrorData cannot be modified by author code, so retaining current lookup-before-fallback structure does not change the required outcome.')]
dump('fixed-envelopes.json',dict(status='proposed exact new envelopes before production; not yet root-selected',convention='Bounded scalar/control and direct retained-handle publication/cleanup credits; these are conservative logical tariffs, not CPU instruction counts. Old helper tariffs are retained independently. No refund after failed heap/reserve stages.',fees=fees))
sequence='''PROSPECTIVE SOURCE PSEUDOCODE — NOT AN EXECUTABLE IMPLEMENTATION

call wrapper(native: &Rc<Native>, args):
  result = closure:
    work(target=2)
    target = Value::Native(native.clone())
    aggregate_error_body(args, target)
  observe_microtask_failure(result)
construct wrapper(args, new_target: &Value):
  result = closure:
    work(target=2)
    target = new_target.clone()
    aggregate_error_body(args, target)
  observe_microtask_failure(result)

body(args, target):
  work(body=16)
  prototype = named_get(target, "prototype") // target moved, not cloned
  if !js_object(prototype):
    work(intrinsic_tree(prototypes.len).comparisons * (1 + 14/8))
    prototype = Value::Object(checked saved prototypes["AggregateError"])
  object = new_aggregate_error_object(prototype) // capacity3 and genuine brand
  message = borrowed args[1] or borrowed Undefined
  if message is not Undefined:
    work(clone=1)
    text = string_hint(message.clone()) // unchanged ordinary conversion helper
    define_aggregate_error_data(object, "message", Value::String(text))
  options = borrowed args[2] or borrowed Undefined
  install_aggregate_error_cause(object, options)
  items = borrowed args[0] or borrowed Undefined
  values = aggregate_error_collect(items)
  array = new_all_values_array(values) // unchanged helper, moved list, no clones
  define_aggregate_error_data(object, "errors", array)
  return Value::Object(object)

named_get(receiver, fixed_name):
  work(named_get=2)
  key = dom_proto_text(fixed_name).into()
  get_property_key(receiver, &key)

new_aggregate_error_object(prototype):
  work(instance=8)
  require js_object(prototype), otherwise Resource invariant error
  plan = object_slot_plan(objects.len, objects.capacity, 1)
  work(plan.work); charge(plan.bytes)
  if plan.target: objects.try_reserve_exact(target - len) or Resource
  id = dom_proto_object(Some(prototype), 3) // unchanged bag9
  objects[id].intrinsic_error = Some("AggregateError")
  return id

define_aggregate_error_data(id, static_name, value):
  work(own_data=4)
  require existing object whose private intrinsic_error is AggregateError
  key = dom_proto_text(static_name).into()
  dom_proto_property(id, key, Property::data(value, true, false, true))
  // This fresh private instance is not author-reachable before return.
  // Known static names and phase order guarantee no duplicate ordinary key.

install_aggregate_error_cause(id, options):
  work(cause=10)
  if !js_object(options): return Ok
  key = dom_proto_text("cause").into()
  present = find_property_key_in(options, &key).is_some() // no getter invocation
  if present:
    work(clone=1)
    value = get_property_key(options.clone(), &key)
    define_aggregate_error_data(id, "cause", value)
  // Keeping two separately charged cause-key lifetimes makes this recipe exact;
  // no unselected key-pool optimization or old helper change is assumed.

collect(source):
  work(collection=8)
  list = AggregateList::empty_prepaid()
  iterator = AggregateIterator::acquire(source)
  while Some(receipt) = iterator.next_value(): list.append_received(receipt)
  return list.into_values() // moves entire Vec; no per-element clone

acquire(source):
  work(acquisition=8)
  method = array_from_iterator_method(source) or TypeError noniterable
  work(clone=1)
  iterator = call(method, empty Vec, source.clone())
  require js_object(iterator), otherwise TypeError
  work(clone=1)
  next = named_get(iterator.clone(), "next")
  return {iterator,next}

next_value(iterator):
  work(attempt=8)
  work(clones=2)
  step = call(next.clone(), empty Vec, iterator.clone())
  require js_object(step), otherwise TypeError
  work(clone=1)
  done = named_get(step.clone(), "done")
  if done.truthy(): return None // no value Get
  value = named_get(step, "value")
  return Some(ReceivedAggregateValue(value))

append_received(receipt):
  work(append=8)
  maximum = MAX_HEAP / sizeof(Value)
  require len <= admitted <= maximum and physical_capacity >= admitted
  require admitted==0 or admitted==maximum or (admitted>=8 and admitted.is_power_of_two())
  plan = growth_plan<Value>(len, admitted, 1) // checked arithmetic, heap-derived max
  work(plan.work); charge(plan.bytes)
  if plan.target: values.try_reserve_exact(target - len) or Resource
  // No fallible operation, callback, lookup or new arithmetic below this point.
  if plan.target: admitted = target
  values.push(receipt.value)

Every '?' propagates original errors. No IteratorClose helper is called on any
ordinary or terminal path. Resource/Unsupported is observed by the wrapper and
by the reused dense-array helper; script catch/finally and queued jobs must not
resume after terminal failure. Successful ordinary calls retain standard host
checkpoint behavior. The shared helper's existing test-only reserve probes also
apply when called here; no new Runtime hook or field is introduced.
'''
(D/'sequence.txt').write_text(sequence)
property_rows=[]
for name in ['message','cause','errors']:
 L=len(name)
 for count in range(3):
  prop=count*(1+L)+(count+8)+1
  property_rows.append(dict(name=name,old_own_count=count,order_capacity=3,work=4+(8+2*L)+prop,heap=f'{320+8*L} + '+('Bpp' if count==0 else '0'),qualification='fresh private instance, order has spare capacity, count<3; no callback or duplicate key'))
dump('derived-cuts.json',dict(status='source-derived prospective helper cuts; no engine observations',symbols=dict(V='sizeof(Value)',S='sizeof(ScriptObject)',A='sizeof(Option<AbortSlot>)',D='sizeof(Option<f64>)',K='sizeof(PropertyKey)',Bpp='16*(sizeof(PropertyKey)+sizeof(Property))+32*sizeof(usize)+64'),property_rows=property_rows,instance_warm=dict(work=17,heap='S+72+A+D+3K',preconditions='object_slot_plan targetNone; physical slot spare; valid object prototype; no private test reset inside operation'),fixed_gets=[dict(name=n,work=10+2*len(n),heap=64+4*len(n),excludes='unchanged Get traversal/getter') for n in ['prototype','next','done','value']],collection_prefix=dict(work=36,excludes='GetMethod, iterator Call and next Get',formula='collection8+acquisition8+source clone1+iterator clone1+next fixed-get18'),attempt_done=dict(work=29,excludes='next Call and done Get',formula='attempt8+call clones2+step clone1+done fixed-get18'),attempt_value=dict(work=49,excludes='next Call,done/value Gets,append/growth',formula='done-prefix29+value fixed-get20'),append_cuts=[dict(before_len=0,logical=0,fixed_and_growth_work=16,heap='32+8V'),dict(before_len=7,logical=8,fixed_and_growth_work=8,heap='0'),dict(before_len=8,logical=8,fixed_and_growth_work=32,heap='32+16V')],cause_missing_object_prefix=dict(work=28,heap=84,excludes='HasProperty traversal',formula='cause10+cause-text18'),cause_present_extra=dict(work='clone1+own-data row for current count',heap='own-data row',excludes='HasProperty/Get traversal and getter'),dense_array='Unchanged new_all_values_array:fixed23 + five typed destination plan work/bytes + logical32+nV + bag9 and72+A+D. List growth charges remain cumulative; no refund or hidden transfer discount.',fallback_saved_prototype='intrinsic_tree(26).comparisons=22, key length14 =>44work when target.prototype is not an object; actual map size must be read, never hardcoded in production.',full_constructor_total='Compositional only: target2+body16+prototype fixed-get28+Get(+fallback if needed)+instance17+object growth+optional message/cause phases+collection+attempts+append growth+unchanged array publication+errors data. Author callback work/allocations are neither predicted nor waived.'))
dump('control-outline.json',dict(status='bounded prospective private controls; no executable tests or final test roster',controls=[dict(id='target-body',purpose='Both natural wrappers at target2 and body16 exact/one-short, proving no target getter before admission and no reset; direct body fixtures must preserve prepaid target provenance.'),dict(id='instance',purpose='Warm typed object slot exact17 and one-short plus heap-short; no object on earlier refusal, bag stage/brand publication only when admitted. Cold plan derived from actual capacity.'),dict(id='own-data',purpose='Fresh 0/1/2-count property rows with paid warm bag/order; flags, identity and no inherited setter; owner/brand invalid states refuse Resource before publication.'),dict(id='cause',purpose='Primitive skip; absent, inherited undefined and setter-only presence; Has before Get; fixed/copy/key/property cuts retain exact getter trace and thrown identity.'),dict(id='iterator-sequence',purpose='Acquisition/next/done/value stages with cached next and poisoned return/value getter; ordinary error identity and Resource/Unsupported skip Close; no synthetic replay or reset.'),dict(id='list-growth',purpose='0→8,7→8,8→16 admission and one-short work/heap; paid physical spare grants no logical credit; reject logical8/physical0 and malformed counts before publish.'),dict(id='array-reuse',purpose='Use existing array destination reserve probes, admitting actual fixture preparation; verify five reserve stages and no partial Array rows on refusal. Existing helper’s final bag refusal/observer semantics remain exact.'),dict(id='terminal-queue',purpose='Bound public Resource/Unsupported plus queued sentinel/readbacks to show no author catch/finally/Close/jobs resume. HTML owns separate public terminal literals.'),dict(id='branding',purpose='Public genuine/fake/prototype/tag witnesses already frozen. Private exact brand/field and unchanged layout controls; no decoder whitelist or fake brand suppression.'),dict(id='installer',purpose='Layout owns complete startup/install count/migration controls. Fixed100000 injected row remains fixed and becomes truthful refusal if total>100000; exact/one-short follow separately derived total and default1m remainder.')],preservation=['Existing Promise helper bodies, exact tariffs and type widths.', 'Existing call-spread cap/provenance/fee paths.', 'All author work/heap/stack/source/event/host limits and Runtime success reset.', 'Unchanged old Error construction/conversion/cause behavior; only Object.toString genuine ErrorData fallback is selected.'],prerequisites=['Root numeric fee selection after independent source proof review.', 'Concrete private executable controls and reviewed exact installer migrations before implementation import.', 'No hardcoded actual shape assumptions without prior observed/current-source joins.', 'Separate all current parent outcomes from prospective controls.']))
dump('primary-basis.json',dict(checked_date='2026-10-15',sources=[dict(url='https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-aggregateerror',claims=['Active callable is fallback NewTarget; prototype/object first, optional message ToString, cause, sync iteration, fresh intrinsic errors Array.','Constructor inherits Error; prototype inherits Error.prototype and has no instance ErrorData.']),dict(url='https://tc39.es/ecma262/multipage/abstract-operations.html#sec-iteratortolist',claims=['Cached IteratorRecord with repeated IteratorStepValue; abrupt step propagates without IteratorClose.']),dict(url='https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.prototype.tostring',claims=['Private ErrorData provides Error fallback, string tag overrides; non-string tag is not coerced.'])],prior_source_audit=bind(Path('/tmp/eris-promise-any-plan-1/error-source-audit-1/review.json')),selection=bind(P/'selection-1/source-ready.json')))
print('Draft files authored externally; not sealed. New fee rows await independent read.')
