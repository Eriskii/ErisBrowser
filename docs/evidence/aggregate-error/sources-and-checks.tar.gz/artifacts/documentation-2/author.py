from pathlib import Path
import hashlib,json,difflib
A=Path('/tmp/eris-aggregate-error-plan-1');P=A/'documentation-1';O=A/'documentation-2'
def b(p):
 x=p.read_bytes();return {'path':str(p),'bytes':len(x),'sha256':hashlib.sha256(x).hexdigest()}
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
files=[]
for oldraw in sorted((P/'raw').rglob('*.md')):
 rel=str(oldraw.relative_to(P/'raw'));s=oldraw.read_text();before=(P/'before'/rel).read_text()
 if rel=='docs/aggregate-error.md':
  s=s.replace('Public construction\nstill returns 100,000 author work units','Successful public Runtime construction\nstill returns 100,000 author work units')
  s=s.replace('Seventeen existing test files receive selected','Eighteen existing test files receive selected')
  needle='PENDING_FINAL_RUST_RESULTS'
  added='''The first candidate attempt stopped at compile time: a cumulative unsigned
ledger expression subtracted 1,103 from 306 before adding the 900,000-unit
bootstrap-origin term. Reordering those unchanged terms fixes the intermediate
underflow without changing the expected result or production code. The next
focused run passed all 33 selected tests, including the 27 new groups.

The first bootstrap-focused run passed 47 tests and failed six DataView
stage-fixture groups. Their reconstruction retained the new late prototype,
contradicting the unchanged earlier 25-prototype invariant. Removing only that
entry restores the old fixture; the 236-work guard, 4,553-work installation,
heap expectations and production implementation are unchanged. Both interrupted
runs remain recorded. The successful raw diagnostic in that same run reports
899,203 work remaining and 1,761,871 accounted bytes, confirming the selected
1,103-work and 17,554-byte deltas against the published parent.

'''
  assert s.count(needle)==1;s=s.replace(needle,added+needle)
 elif rel=='docs/VALIDATION.md':
  needle='PENDING_FINAL_VALIDATION_RESULTS'
  added='''The first candidate attempt failed before tests because the cumulative usize
ledger subtracted 1,103 before adding the bootstrap-origin term. Moving the
unchanged positive term earlier fixes the expression without changing its
expected result. The next focused run passed 33 tests, including all 27 new
groups. A separate bootstrap-focused run passed 47 and failed six earlier-stage
DataView fixture groups. The reviewed correction excludes the late AggregateError
prototype from that reconstructed stage and preserves all old production guards,
fees and expectations. Both failed attempts remain retained.

'''
  assert s.count(needle)==1;s=s.replace(needle,added+needle)
 for d,t in [('before',before),('raw',s)]:put(O/d/rel,t)
 patch=''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+rel if before else '/dev/null',tofile='b/'+rel));put(O/'diffs'/(rel+'.patch'),patch)
 delta=''.join(difflib.unified_diff(oldraw.read_text().splitlines(keepends=True),s.splitlines(keepends=True),fromfile='documentation-1/'+rel,tofile='documentation-2/'+rel))
 if delta:put(O/'corrections'/(rel+'.patch'),delta)
 files.append({'relative_path':rel,'before':b(O/'before'/rel),'raw':b(O/'raw'/rel),'diff':b(O/'diffs'/(rel+'.patch')),'same_as_prior_draft':s==oldraw.read_text()})
assert sum(not x['same_as_prior_draft'] for x in files)==2
old=(P/'before/docs/VALIDATION.md').read_text();new=(O/'raw/docs/VALIDATION.md').read_text();marker='## Separate trusted bootstrap allowance';assert new[new.index(marker):]==old[old.index(marker):]
log=A/'validation/aggregate-focused-2.log';text=log.read_text();assert '33 passed; 0 failed;' in text
rows=[l for l in text.splitlines() if l.startswith('test ') and l.endswith(' ... ok')];assert len(rows)==33
boot=A/'validation/bootstrap-focused-1.log';assert 'remaining=899203 allocated=1761871 objects=754 capacity=754 native=300 prototypes=26 globals=213' in boot.read_text()
assert 1761871-1744317==17554 and 1000000-899203==100797 and 100797-99694==1103
markers=[{'path':x['relative_path'],'marker':line} for x in files for line in Path(x['raw']['path']).read_text().splitlines() if line.startswith('PENDING_')];assert len(markers)==4
inputs=[A/'migration-correction-1/source-ready.json',A/'migration-correction-1/layout-review.json',A/'stage-fixture-correction-1/source-ready.json',A/'stage-fixture-correction-1/layout-review.json',A/'validation/aggregate-focused-2.json',log,A/'validation/bootstrap-focused-1.json',boot]
put(O/'source-ready.json',json.dumps({'status':'immutable_corrected_documentation_draft_pending_final_validation_not_for_publication','prior':b(P/'source-ready.json'),'files':files,'correction_inputs':[b(p) for p in inputs],'author':b(O/'author.py'),'placeholders':markers,'checks':{'five_other_drafts_exact':True,'published_before_all_exact':True,'historical_validation_suffix_exact':True,'observed_initial_focused33_pass':True,'retained_bootstrap47_pass6_fail_qualified':True,'actual_raw_diagnostic_reconciles_selected_delta':True,'current_migration_census':{'paths':18,'retained_groups':126,'renames':4},'public_runtime_grant_distinguished_from_AggregateError_call':True},'finalization':'Only final full/strict/release/replay statements await actual receipts. No projected3159/3513 totals appear as observations. Retain both prior draft and correction receipts.'},indent=2)+'\n')
print(json.dumps({'hold':b(O/'source-ready.json'),'chapter_words':len((O/'raw/docs/aggregate-error.md').read_text().split())},indent=2))
