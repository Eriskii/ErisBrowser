# AggregateError

`AggregateError(errors, message, options)` works as a call or with `new` in the
supported language subset. It collects a synchronous iterable into a fresh,
dense intrinsic Array, preserving input order and value identities. Empty input
produces an empty `errors` Array. The constructor has length two and inherits
from the saved `Error` constructor; its prototype inherits from the saved
`Error.prototype`.

Construction reads `NewTarget.prototype` before converting an optional message,
checking the optional cause and acquiring the iterable. An undefined message
creates no own `message` property. Object options use observable cause presence
and then a value read, including inherited properties and present undefined
values. Primitive options supply no cause. Created `message`, `cause` and
`errors` properties are writable and configurable but nonenumerable; inherited
setters cannot intercept their definitions.

Iterator acquisition reads the iterator method and caches `next`. Each reached
step reads `done` before `value`; an exhausted result's value is not read.
Ordinary acquisition, step and value errors propagate without `IteratorClose`.
The result Array uses the retained intrinsic Array machinery, so replacing the
global `Array` does not replace it. A saved callable constructor supplies its
own target even after the global or `prototype.constructor` changes. Existing
`Reflect.construct` validation and explicit NewTarget prototype selection remain
in effect; a non-object prototype falls back to the retained AggregateError
prototype.

Instances carry the existing private Error brand. `Object.prototype.toString`
now uses `[object Error]` as the fallback for genuine existing Error instances
and AggregateError instances. A string `Symbol.toStringTag` still overrides the
fallback; a non-string tag is not coerced. Getters retain their observable error
behavior. Copying a name, constructor or prototype does not forge the private
brand, and the ordinary AggregateError prototype itself is not branded. This
change does not otherwise extend the older Error constructors.

Construction shares the current author work and cumulative allocation budgets.
Its temporary value list grows through the existing checked planner, with a
maximum derived from the heap allowance and the actual Value size. Moving that
list into the existing dense-array helper grants no refund. Resource-limit and
unsupported-operation failures are terminal: later author steps and unstarted
jobs do not run, and later readbacks do not resume the suspended queue. No
iteration retry, author `return` call or in-operation budget reset is introduced.
These are bounded subset semantics, not a complete implementation of all
possible iterable, realm or language behavior.

The selected installation ledger adds **1,103 work units** and two appended
metadata bags. Its arithmetic gives **100,797 consumed units and 899,203
remaining** from the finite 1,000,000-unit trusted allowance. Successful public Runtime construction
still returns 100,000 author work units, and both phases share the cumulative
8 MiB allocation ceiling. The typed heap delta is
`2*S + 2*A + 2*D + 6*K + 2*Bpp + N + 3*Bstatic + 4*Bnative + 4*Bglobal + 2634`.
Here `S`, `A`, `D`, `K` and `N` are the sizes of ScriptObject,
Option<AbortSlot>, Option<f64>, PropertyKey and Native; each `B` is the existing
typed B-tree node allowance for its property, static-key, native-map or global
map. On the previously observed x86_64 Linux layouts this is **17,554 accounted
bytes**, including both upfront object slots. These figures are source-derived
accounting, not process-memory or timing measurements.

Installation preserves every preceding object ID and map entry. The new
prototype and constructor bag follow them, and the global is published last.
A failed initialization can retain prepaid private metadata or earlier map
entries inside a realm that is never returned. Existing raw tests retain their
99,693, 99,694 and 100,000 inputs as refusals and add 100,796/100,797 and the
default 1,000,000 boundaries. Eighteen existing test files receive selected
count/ledger changes, with four explicit boundary-name renames. Earlier-stage
fixtures exclude only the new late entry they cannot retain; their original
order, isolated fees and early 25-prototype assertions remain intact.

The authored controls cover observable ordering and identities, Error tag
fallback, terminal suspension, and private work/storage admission. Parent runs
passed the string-tag override group in both modes. The other thirteen semantic
groups and five terminal groups stopped in their first sloppy attempt; later
readbacks and strict attempts were not reached. Their generic Error diagnostics
do not identify every internal check statement.

The first candidate attempt stopped at compile time: a cumulative unsigned
ledger expression subtracted 1,103 from 306 before adding the 900,000-unit
bootstrap-origin term. Reordering those unchanged terms fixes the intermediate
underflow without changing the expected result or production code. The next
focused run passed all 33 selected tests, including the 27 new groups.

The first bootstrap-focused run passed 47 tests and failed six DataView
stage-fixture groups. Their reconstruction retained the new late prototype,
contradicting the unchanged earlier 25-prototype invariant. Removing only that
entry restores the old fixture; the 236-work guard, 4,553-work installation,
heap expectations and production implementation are unchanged. Both interrupted
runs remain recorded. The successful raw diagnostic in that same run reports
899,203 work remaining and 1,761,871 accounted bytes, confirming the selected
1,103-work and 17,554-byte deltas against the published parent.

PENDING_FINAL_RUST_RESULTS

PENDING_FINAL_REPLAY_RESULTS

`Promise.any`, classes, Proxy, async iteration and multiple realms remain
unfinished. The optional conformance host's existing response decoder rejects
an uncaught `AggregateError` intrinsic identity; this checkpoint does not widen
that decoder or its final-unhandled-rejection policy. Caught JavaScript values
retain their identity, but no new AggregateError upstream profile or pass count
is claimed. This is not full ECMAScript compatibility, production security,
a CPU/GPU performance result or an RSS bound. Historical checkpoint records and
archives keep their original counts and limits.

The [evidence manifest](evidence/aggregate-error/manifest.json) and
[source/check archive](evidence/aggregate-error/sources-and-checks.tar.gz) are the
publication targets for the selected sources, controls and observed receipts.
