from pathlib import Path
import hashlib,json,difflib
P=Path('/tmp/eris-startup-headroom-plan-1');W=P/'worktree';H=P/'documentation-1'
chapter='''# Shared startup metadata payloads

Document.title accessors now borrow the existing immutable `length` and `name`
keys. Six ProcessingInstruction and CharacterData methods reuse their function
name payload as the owner property key, and CharacterData.length reuses the
pooled `length` key. Mutable metadata bags, function values, descriptors,
property order and existing object IDs remain separate and unchanged. This adds
no API behavior.

The title installer pays an eight-unit handoff before its existing entry charge;
each of its two factories pays two units before retaining the borrowed keys.
Each of the ten PI factories pays one unit after display-text admission to
retain that immutable payload as a key. Six callers consume the key for their
owner property; four accessor callers discard it. CharacterData.length pays
one unit before retaining the pooled key. Existing object, property and native
allocation admissions keep their order and charges.

Together these changes save **279 startup work units and 1,132 accounted heap
bytes**: title keys save 60/336, PI owner keys save 200/708, and the length owner
key saves 19/88. Raw startup consumes **99,694 work units**, leaving **306**
under the unchanged 100,000-unit limit. The cumulative accounted-heap limit stays
**8 MiB**. Public Runtime construction still resets execution work after startup
while retaining initialization heap charges.

The focused Rust 1.88 default observations record accounted allocation falling
from **1,745,449 to 1,744,317 bytes**. Both observations retain 752 ordinary objects
and capacity, 299 native registry entries, 25 prototypes and 212 global bindings.
These are metered accounting observations, not resident-memory or CPU-performance
measurements. Portable private assertions use type-size formulas instead of
hardcoding these absolute allocation totals.

All three parent-compatible witnesses fail at their intended new boundaries:
the first method owner/display pointer comparison, the title getter's borrowed
length-key comparison, and 99,973 versus the new 99,694 raw-work expectation.
Their preceding descriptor, identity and count controls pass. The same three
groups pass on the candidate with unchanged expectations. Four additional
private groups freeze 84 operations covering paid clone boundaries, retained
metadata prefixes, exact title factory/installer fees and owner publication
refusals. Existing full PI factory quota controls remain in their original
module. Seven existing test files receive only the reviewed signature,
accounting or explanatory migrations.

PENDING_RUST_VALIDATION

PENDING_RELEASE_REPLAY_VALIDATION

Historical checkpoint chapters and conformance baselines retain their original
scope. Promise.any and AggregateError remain separate work: the additional
startup headroom does not establish their admission or implementation. This
checkpoint makes no new GPU, security or Chromium-relative performance claim.
'''
changes={
 'README.md':('heap bytes while preserving both functions and their behavior.\n','heap bytes while preserving both functions and their behavior.\nThe [startup metadata follow-up](docs/startup-metadata-sharing.md) shares title\nkeys and PI/CharacterData owner-name payloads, saving 279 more startup work units\nand 1,132 accounted heap bytes. Raw startup leaves 306 units under the same limit.\n'),
 'docs/COMPATIBILITY.md':('keys. Its startup saving adds no Text or Promise API coverage.\n','keys. Its startup saving adds no Text or Promise API coverage.\nThe [startup metadata follow-up](startup-metadata-sharing.md) also shares title\nkeys and PI/CharacterData owner-name payloads while preserving their descriptors,\nidentities and behavior. It changes accounting without adding API coverage.\n'),
 'docs/ROADMAP.md':('`allSettled` installation and its validation are recorded in the linked chapter.\n','`allSettled` installation and its validation are recorded in the linked chapter.\nThe [startup metadata follow-up](startup-metadata-sharing.md) saves another 279\nwork units and 1,132 accounted heap bytes, leaving 306 under the unchanged limit.\nThis headroom does not establish admission for the remaining Promise APIs.\n'),
 'docs/VALIDATION.md':('# Validation record\n','# Validation record\n\n## Shared startup metadata payloads\n\nThe [startup metadata follow-up](startup-metadata-sharing.md) reduces raw work\nfrom 99,973 to 99,694 and leaves 306 under the unchanged 100,000-unit limit.\nThe focused default allocation observations differ by exactly 1,132 accounted\nbytes, with object, native, prototype and global counts unchanged. All three\nparent-compatible controls fail at their intended new boundaries after their\npreservation checks; the same candidate controls pass. Four private groups\nfreeze 84 admission and ownership operations.\n\nPENDING_VALIDATION_RECORD\n')}
manifest=[]
for rel in ['docs/startup-metadata-sharing.md']+list(changes):
 old=(W/rel).read_bytes() if (W/rel).exists() else b''
 if rel in changes:
  a,b=changes[rel];assert old.decode().count(a)==1;new=old.decode().replace(a,b,1).encode()
 else:new=chapter.encode()
 for stem,data in [('before',old),('raw',new)]:
  p=H/stem/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 d=H/'diffs'/Path(rel+'.patch');d.parent.mkdir(parents=True,exist_ok=True);d.write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel)))
 manifest.append({'path':rel,'before_bytes':len(old),'before_sha256':hashlib.sha256(old).hexdigest(),'raw_bytes':len(new),'raw_sha256':hashlib.sha256(new).hexdigest()})
(H/'draft-state.json').write_text(json.dumps({'status':'unsealed draft; awaiting actual full Rust/strict/release/replay observations','paths':manifest,'pending':['PENDING_RUST_VALIDATION','PENDING_RELEASE_REPLAY_VALIDATION','PENDING_VALIDATION_RECORD'],'scope':'Five documentation paths only; historical chapter bytes are not edited. No live worktree edits or project execution.'},indent=2)+'\n')
print('drafted five external documentation paths; final seal intentionally pending')
