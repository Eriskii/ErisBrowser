from pathlib import Path
import json,hashlib,difflib,re
O=Path('/tmp/eris-startup-headroom-plan-1');D=O/'production-1';W=O/'worktree'
H=lambda b:hashlib.sha256(b).hexdigest()
bind={r['path']:r['sha256'] for r in json.loads((O/'source-bindings.json').read_text())['source_files']}
prod=['src/script/document_title.rs','src/script/dom_prototypes.rs','src/script/processing_instruction.rs']
migr=['src/script/bootstrap_tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/processing_instruction/key_cache_fee_tests.rs','src/script/text_operations/key_cache_tests.rs','src/script/test262_host/quota_tests.rs','src/script/promises/install_tests.rs','src/script/promises/shared_key_tests.rs']
source={}
for path in prod+migr:
 b=(W/path).read_bytes();assert H(b)==bind[path],path;source[path]=b.decode()
 q=D/'before'/path;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b)
def replace(s,old,new,count=1):
 assert s.count(old)==count,(old,s.count(old));return s.replace(old,new)
s=source[prod[0]]
s=replace(s,'        length: usize,\n    ) -> Result<Value> {','        length: usize,\n        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<Value> {')
s=replace(s,'        let name = self.dom_proto_text(display)?;\n        self.dom_proto_named(\n            properties,\n            "length",','        let name = self.dom_proto_text(display)?;\n        // Pay both retained key clones before publishing either descriptor.\n        self.work(2)?;\n        self.dom_proto_property(\n            properties,\n            metadata_keys[0].clone(),')
s=replace(s,'        self.dom_proto_named(\n            properties,\n            "name",','        self.dom_proto_property(\n            properties,\n            metadata_keys[1].clone(),')
s=replace(s,'    pub(super) fn install_document_title(&mut self, prototype: usize) -> Result<()> {\n        self.work(4)?;\n        let get = self.document_title_function("get", "get title", 0)?;\n        let set = self.document_title_function("set", "set title", 1)?;','    pub(super) fn install_document_title(\n        &mut self,\n        prototype: usize,\n        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<()> {\n        // Forward the existing immutable length/name pool once for both bags.\n        self.work(8)?;\n        self.work(4)?;\n        let get = self.document_title_function("get", "get title", 0, metadata_keys)?;\n        let set = self.document_title_function("set", "set title", 1, metadata_keys)?;')
source[prod[0]]=s
source[prod[1]]=replace(source[prod[1]],'                self.install_document_title(prototype)?;','                self.install_document_title(prototype, [&keys[1], &keys[0]])?;')
s=source[prod[2]]
s=replace(s,'        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<Value> {','        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<(Value, PropertyKey)> {')
s=replace(s,'        let name = self.dom_proto_text(display)?;\n        // Pay for both borrowed-key clones before retaining either handle.','        let name = self.dom_proto_text(display)?;\n        // Retain the immutable display once for the eventual owner key.\n        self.work(1)?;\n        let owner_key = PropertyKey::String(name.clone());\n        // Pay for both borrowed-key clones before retaining either handle.')
s=replace(s,'        Ok(Value::Native(Rc::new(Native {\n            properties: Some(properties),\n            name,\n            receiver: Value::Undefined,\n        })))','        Ok((\n            Value::Native(Rc::new(Native {\n                properties: Some(properties),\n                name,\n                receiver: Value::Undefined,\n            })),\n            owner_key,\n        ))')
s=replace(s,'                let function =\n                    self.pi_function("create", "createProcessingInstruction", 2, metadata_keys)?;\n                self.dom_proto_named(\n                    prototype,\n                    "createProcessingInstruction",','                let (function, key) =\n                    self.pi_function("create", "createProcessingInstruction", 2, metadata_keys)?;\n                self.dom_proto_property(\n                    prototype,\n                    key,')
s=replace(s,'                let get = self.pi_function("target", "get target", 0, metadata_keys)?;','                let (get, display_key) =\n                    self.pi_function("target", "get target", 0, metadata_keys)?;\n                drop(display_key);')
s=replace(s,'                let get = self.pi_function("data", "get data", 0, metadata_keys)?;\n                let set = self.pi_function("setData", "set data", 1, metadata_keys)?;','                let (get, display_key) = self.pi_function("data", "get data", 0, metadata_keys)?;\n                drop(display_key);\n                let (set, display_key) = self.pi_function("setData", "set data", 1, metadata_keys)?;\n                drop(display_key);')
s=replace(s,'                let get = self.pi_function("length", "get length", 0, metadata_keys)?;\n                self.dom_proto_named(\n                    prototype,\n                    "length",','                let (get, display_key) =\n                    self.pi_function("length", "get length", 0, metadata_keys)?;\n                drop(display_key);\n                // The existing metadata pool already owns this exact key.\n                self.work(1)?;\n                self.dom_proto_property(\n                    prototype,\n                    metadata_keys[0].clone(),')
s=replace(s,'                    let function = self.pi_function(name, name, length, metadata_keys)?;\n                    self.dom_proto_named(\n                        prototype,\n                        name,','                    let (function, key) = self.pi_function(name, name, length, metadata_keys)?;\n                    self.dom_proto_property(\n                        prototype,\n                        key,')
source[prod[2]]=s
p=migr[0];source[p]=replace(source[p],'    // AllSettled adds187 metadata work and one bag, reusing the existing arenas.\n    assert_eq!(reference.steps, 27);','    // AllSettled adds187 metadata work and one bag, reusing the existing arenas.\n    // Title keys, PI owner names and CharacterData.length save279 work/1132 bytes.\n    assert_eq!(reference.steps, 306);')
p=migr[1];s=source[p];calls=0
def fee(m):
 global calls
 calls+=1;return m[1]+str(int(m[2])+1)+m[3]
s=re.sub(r'(        work: )(\d+)(,)',fee,s);assert calls==10
s=replace(s,'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99973_work_boundary','cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99694_work_boundary')
s=replace(s,'[(99_972, false, 0), (99_973, true, 0), (100_000, true, 27)]','[(99_693, false, 0), (99_694, true, 0), (100_000, true, 306)]');source[p]=s
p=migr[2];source[p]=replace(source[p],'                let Value::Native(native) = result.unwrap() else {','                let (Value::Native(native), _) = result.unwrap() else {')
p=migr[3];s=source[p];s=replace(s,'text_metadata_keys_raw_bootstrap_uses_99973_work_and_preserves_public_reset','text_metadata_keys_raw_bootstrap_uses_99694_work_and_preserves_public_reset');s=replace(s,'[(99_972, false, 0), (99_973, true, 0), (100_000, true, 27)]','[(99_693, false, 0), (99_694, true, 0), (100_000, true, 306)]');source[p]=s
p=migr[4];source[p]=replace(source[p],'    assert_eq!(runtime.steps, 27);','    assert_eq!(runtime.steps, 306);')
p=migr[5];s=source[p];s=replace(s,'promise_full_raw99973_and_public_reset_preserve_empty_paid_arenas','promise_full_raw99694_and_public_reset_preserve_empty_paid_arenas');s=replace(s,'[(99_972, false, 0), (99_973, true, 0), (100_000, true, 27)]','[(99_693, false, 0), (99_694, true, 0), (100_000, true, 306)]');source[p]=s
p=migr[6];source[p]=replace(source[p],'independently migrated99972/99973/100000','independently migrated99693/99694/100000')
rows=[]
for path,text in source.items():
 before=(D/'before'/path).read_bytes();after=text.encode();assert before!=after
 raw=D/'raw'/path;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_bytes(after)
 diff=''.join(difflib.unified_diff(before.decode().splitlines(True),text.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 patch=D/'diffs'/(path+'.patch');patch.parent.mkdir(parents=True,exist_ok=True);patch.write_text(diff)
 rows.append({'path':path,'kind':'production' if path in prod else 'existing-test-migration','before':{'bytes':len(before),'sha256':H(before)},'raw':{'bytes':len(after),'sha256':H(after)},'diff':{'path':str(patch.relative_to(D)),'bytes':len(diff.encode()),'sha256':H(diff.encode())}})
(D/'manifest-draft.json').write_text(json.dumps({'rows':rows,'production_paths':prod,'existing_test_migration_paths':migr},indent=2)+'\n')
print('Wrote',len(rows),'external files; no live writes or project execution.')
