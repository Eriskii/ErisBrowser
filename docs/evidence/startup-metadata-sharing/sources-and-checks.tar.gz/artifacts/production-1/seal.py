from pathlib import Path
import json,hashlib,re
D=Path('/tmp/eris-startup-headroom-plan-1/production-1');O=D.parent;W=O/'worktree';H=lambda b:hashlib.sha256(b).hexdigest()
j=json.loads((D/'manifest-draft.json').read_text())
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def patch_check(before,after,diff):
 b=before.splitlines(True);out=[];i=0;lines=diff.splitlines(True);n=2
 while n<len(lines):
  m=re.fullmatch(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@.*\n?',lines[n]);assert m,lines[n]
  start=int(m[1])-1;out.extend(b[i:start]);i=start;n+=1
  while n<len(lines) and not lines[n].startswith('@@ '):
   line=lines[n];tag=line[0];s=line[1:]
   if tag==' ': assert b[i]==s;out.append(s);i+=1
   elif tag=='-':assert b[i]==s;i+=1
   elif tag=='+':out.append(s)
   else:raise AssertionError(tag)
   n+=1
 out.extend(b[i:]);assert ''.join(out)==after
for r in j['rows']:
 before=(D/'before'/r['path']).read_text();after=(D/'raw'/r['path']).read_text();diff=(D/r['diff']['path']).read_text()
 assert H(before.encode())==r['before']['sha256'];assert H(after.encode())==r['raw']['sha256'];assert (W/r['path']).read_bytes()==before.encode()
 patch_check(before,after,diff)
 if r['kind']=='existing-test-migration':
  # All quoted payloads stay identical; changes are numbers, named test identifiers,
  # one tuple pattern and comments. Exact whole-file patch is bound separately.
  assert re.findall(r'"(?:\\.|[^"\\])*"',before)==re.findall(r'"(?:\\.|[^"\\])*"',after),r['path']
for p,marker in [('src/script/document_title.rs','    pub(super) fn document_title_call_preflight'),('src/script/processing_instruction.rs','    pub(super) fn pi_call_preflight')]:
 before=(D/'before'/p).read_text();after=(D/'raw'/p).read_text();assert before[before.index(marker):]==after[after.index(marker):]
notes={'status':'source authored; unformatted and unexecuted','scope':'Three production paths plus seven old-test migration paths only; no new module registration or test source.','base':'fb6f51ab5a2033fc14b828c0df36642d7c41fb62','admission_order':{'title':'existing bag9/display26, new clone2, unchanged property9/15 and Native21; installer8 before existing4','PI':'existing bag then display, selected clone1 immediately before name.clone(), existing metadata clone2/insertions/Native; pair is returned by move','CharacterData_length':'completed getter, discard its unused display key, clone1 immediately before metadata_keys[0].clone(), unchanged property insertion'},'predicted':{'saved_work':279,'saved_accounted_heap':1132,'raw_work':99694,'remaining':306,'one_short':99693},'private_factory_migrations':'Ten CASES work literals+1; heap constants unchanged; old direct success pattern destructures new pair without removing an old assertion.','renames':[{'old':'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99973_work_boundary','new':'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99694_work_boundary'},{'old':'text_metadata_keys_raw_bootstrap_uses_99973_work_and_preserves_public_reset','new':'text_metadata_keys_raw_bootstrap_uses_99694_work_and_preserves_public_reset'},{'old':'promise_full_raw99973_and_public_reset_preserve_empty_paid_arenas','new':'promise_full_raw99694_and_public_reset_preserve_empty_paid_arenas'}],'checks':{'all_ten_before_files_match_live_base':True,'all_ten_unified_patches_reconstruct_complete_raw_files':True,'all_existing_test_quoted_payload_sequences_unchanged':True,'title_and_PI_invocation_suffixes_byte_exact':True,'new_test_registrations_included':False,'new_test_modules_included':False,'caps_layout_registry_or_id_changes':False,'project_execution_or_live_edits':False},'qualifications':['This is a source hold, not a test result. Parent/control and candidate execution remain root-owned.','No Rust formatter/compiler, engine, browser, Git or project module execution was performed. Only external authoring and stdlib text/hash checks ran.','No alternate8 fee remains in source; the extra PI handle pays exactly1 after display admission.','Root must compose separately frozen new tests/registrations and review any formatting corrections.']}
(D/'notes.json').write_text(json.dumps(notes,indent=2)+'\n')
manifest={'status':'sealed external source hold; no execution','plan':rec(O/'source-ready.json'),'selection':rec(O/'root/selection-1.json'),'notes':rec(D/'notes.json'),'base':'fb6f51ab5a2033fc14b828c0df36642d7c41fb62','production_paths':j['production_paths'],'existing_test_migration_paths':j['existing_test_migration_paths'],'files':j['rows'],'new_registrations':[],'new_tests':[]}
p=D/'source-ready.json';p.write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(rec(p)))
