from pathlib import Path
import json,hashlib,subprocess
P=Path('/tmp/eris-startup-headroom-plan-1');W=P/'worktree';R=P/'current-source-review-1'
def h(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def j(p):return json.loads(p.read_text())
previous=j(R/'source-review.json');c2=j(P/'source-candidate-2.json')['source_sha256'];c3=j(P/'source-candidate-3.json')['source_sha256'];parent=j(P/'source-parent.json')['source_sha256'];m=j(P/'migration-addendum-1/source-ready.json')
rel=m['path'];before=(P/'migration-addendum-1/before.rs').read_text();raw=(P/'migration-addendum-1/raw.rs').read_text()
assert h(before.encode())==m['before_sha256']==parent[rel]==c2[rel]
assert h(raw.encode())==m['raw_sha256']==c3[rel]
comment='    // Title/PI metadata sharing saves279 work and1132 bytes without new bags.\n'
assert raw.count(comment)==1
inverse=raw.replace(comment,'',1).replace('            - 187\n            + 279\n','            - 187\n',1).replace('            + all_settled_added\n            - 1132\n','            + all_settled_added\n',1)
assert inverse==before
assert set(c2)==set(c3) and len(c3)==1675
assert [r for r in c3 if c2[r]!=c3[r]]==[rel]
for r,sha in c3.items():assert h((W/r).read_bytes())==sha,r
changed=sorted(r for r in set(parent)|set(c3) if parent.get(r)!=c3.get(r));assert len(changed)==14
hold=j(P/'production-1/source-ready.json');oldpaths=hold['production_paths']+hold['existing_test_migration_paths'];newpaths=[r for r in changed if r not in parent]
assert len(newpaths)==3 and set(changed)==set(oldpaths+newpaths+[rel])
tracked=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
assert set(tracked)==set(oldpaths+[rel]) and set(untracked)==set(newpaths)
# Independent arithmetic from unchanged dom_proto_text and the selected clone placement.
names=['createProcessingInstruction','substringData','appendData','insertData','deleteData','replaceData']
text_work=lambda s:8+2*len(s);text_heap=lambda s:64+4*len(s)
title_work=2*(text_work('length')+text_work('name')-2)-8
title_heap=2*(text_heap('length')+text_heap('name'))
pi_work=sum(map(text_work,names))-10
pi_heap=sum(map(text_heap,names))
length_work=text_work('length')-1;length_heap=text_heap('length')
assert (title_work,pi_work,length_work)==(60,200,19)
assert (title_heap,pi_heap,length_heap)==(336,708,88)
work=title_work+pi_work+length_work;heap=title_heap+pi_heap+length_heap
assert (work,heap)==(279,1132)
log=P/'validation/default-full-1.log';run=j(P/'validation/default-full-1.json');assert h(log.read_bytes())==run['sha256']
assert '2790 passed; 1 failed;' in log.read_text() and 'left: 306\n right: 27' in log.read_text()
x=dict(status='clear_source_only_addendum',previous_review=bind(R/'source-review.json'),bindings=[bind(P/n) for n in ['source-parent.json','source-candidate-2.json','source-candidate-3.json','migration-addendum-1/source-ready.json','migration-addendum-1/before.rs','migration-addendum-1/raw.rs','migration-addendum-1/diff.patch','root/selection-1.json','report.json','validation/default-full-1.json','validation/default-full-1.log']],final_inventory=dict(selected_paths=1675,changed_paths=changed,production_paths=3,existing_migration_paths=8,new_test_files=3,all_current_hashes_match=True,only_candidate2_to3_change=rel),independent_derivation=dict(title_work_saved=title_work,pi_work_saved=pi_work,character_data_length_work_saved=length_work,total_work_saved=work,title_heap_saved=title_heap,pi_heap_saved=pi_heap,character_data_length_heap_saved=length_heap,total_heap_saved=heap,method='Compute dom_proto_text8+2L/64+4L for the exact six owner names and length/name pair; subtract selected clone/handoff work. No observed remaining/heap value is copied to derive the corrections.'),checks=['The addendum before is byte-identical to both published parent and candidate2 for this path.','Removing only the explanatory comment,+279 and-1132 exactly reconstructs before; every older formula term, type/count/cleanup assertion and literal is retained.','All1675 current hashes join candidate3. Its sole delta from candidate2 is the new eighth migration; the prior13 final bytes remain exact.','Read-only Git roster is exactly11 tracked changes (three production+eight migrations) and three new test files.','No production, new-control, layout, counter, cap or object-ID change accompanies this test-only correction.'],prior_stage_limit='The candidate2 source review correctly described its frozen13-path composition and formatting, but did not establish that every old cumulative ledger requiring migration had been found. The typed-array ledger omission was outside that changed roster and surfaced only in the subsequent root-owned full run. The earlier review and source2 remain retained, not rewritten.',failure_scope='Root default-full-1 reached the library target:2790 passed,1 failed at the remaining-work assertion306 versus old expression27. The following heap assertion and later targets were not reached. This addendum reports no corrected execution outcome.',qualification='Inert external source/hash/arithmetic work and read-only Git inspection only. No project import, JavaScript/Rust execution, compiler/formatter invocation or live edit. Final reruns remain root-owned.')
(R/'source-review-2.json').write_text(json.dumps(x,indent=2)+'\n');print(json.dumps(bind(R/'source-review-2.json')))
