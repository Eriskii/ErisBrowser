from pathlib import Path
import hashlib,json,re,difflib,subprocess
P=Path('/tmp/eris-startup-headroom-plan-1');W=P/'worktree';R=P/'current-source-review-1'
def h(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def j(p):return json.loads(p.read_text())
def dump(n,x):(R/n).write_text(json.dumps(x,indent=2)+'\n')
def check(p,x):
 b=p.read_bytes();assert len(b)==x['bytes'] and h(b)==x['sha256'],str(p)
def patch(before,diff):
 old=before.splitlines(keepends=True);out=[];cursor=0;lines=diff.splitlines(keepends=True);i=0
 while i<len(lines):
  if not lines[i].startswith('@@'):i+=1;continue
  m=re.match(r'@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@',lines[i]);assert m
  start=int(m[1])-1;oldn=int(m[2] or '1');newn=int(m[4] or '1');assert start>=cursor
  out.extend(old[cursor:start]);cursor=start;i+=1;oc=nc=0
  while i<len(lines) and not lines[i].startswith('@@'):
   v=lines[i];i+=1
   if v.startswith('\\'):continue
   if v[:1] in (' ','-'):
    assert old[cursor]==v[1:],(cursor,v,old[cursor]);cursor+=1;oc+=1
   if v[:1] in (' ','+'):
    out.append(v[1:]);nc+=1
  assert (oc,nc)==(oldn,newn)
 out.extend(old[cursor:]);return ''.join(out)
# Inert lexical comparison: retain literal token bytes, discard Rust comments/spacing.
def lex(s):
 out=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   k=s.find('\n',i);i=len(s) if k<0 else k+1;continue
  if s.startswith('/*',i):
   d=1;i+=2
   while d:
    if s.startswith('/*',i):d+=1;i+=2
    elif s.startswith('*/',i):d-=1;i+=2
    else:i+=1
    assert i<=len(s)
   continue
  m=re.match(r'(?:br|r)(#*)"',s[i:])
  if m:
   end='"'+m[1];k=s.index(end,i+len(m[0]))+len(end);out.append(s[i:k]);i=k;continue
  m=re.match(r'(?:b|c)?"(?:\\.|[^"\\])*"',s[i:],re.S)
  if m:out.append(m[0]);i+=len(m[0]);continue
  m=re.match(r"(?:b)?'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\])'",s[i:],re.S)
  if m:out.append(m[0]);i+=len(m[0]);continue
  m=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9.]*',s[i:])
  if m:out.append(m[0]);i+=len(m[0]);continue
  out.append(s[i]);i+=1
 return out
def literals(s):return [v for v in lex(s) if v.startswith(('"','r"','r#','br"','br#','b"','c"',"'")) and not re.match(r"^'[A-Za-z_]$",v)]
def fmt_tokens(s):
 # The only import-order deltas were manually inspected in the two new PI modules.
 for pair in [('use super::*;\nuse super::key_cache_tests::CASES;', 'use super::key_cache_tests::CASES;\nuse super::*;'),('use super::*;\nuse super::key_cache_tests::{CASES, cached_keys};','use super::key_cache_tests::{CASES, cached_keys};\nuse super::*;')]:s=s.replace(*pair)
 v=lex(s)
 return [x for i,x in enumerate(v) if not (x==',' and i+1<len(v) and v[i+1] in (')',']','}'))]
parent=j(P/'source-parent.json')['source_sha256'];v1=j(P/'source-candidate.json')['source_sha256'];final=j(P/'source-candidate-2.json')['source_sha256']
assert len(parent)==1672 and len(final)==1675
changed=sorted(k for k in set(parent)|set(final) if parent.get(k)!=final.get(k));assert len(changed)==13
assert not set(parent)-set(final)
for rel,sha in final.items():assert h((W/rel).read_bytes())==sha,rel
hold=j(P/'production-1/source-ready.json');expected={};checks=[]
for row in hold['files']:
 rel=row['path'];before=P/'production-1/before'/rel;raw=P/'production-1/raw'/rel;diff=P/'production-1'/row['diff']['path']
 for path,ref in [(before,row['before']),(raw,row['raw']),(diff,row['diff'])]:check(path,ref)
 assert h(before.read_bytes())==parent[rel]
 assert patch(before.read_text(),diff.read_text())==raw.read_text()
 expected[rel]=raw.read_text();checks.append(dict(path=rel,kind=row['kind'],before_sha256=h(before.read_bytes()),raw_sha256=h(raw.read_bytes()),patch_exact=True))
parenthold=j(P/'tests-before-1/parent-ready.json');private=j(P/'tests-before-1/private-ready.json')
for ref in parenthold['payloads']+private['payloads']:check(Path(ref['path']),ref)
pi='src/script/processing_instruction.rs';title='src/script/document_title.rs'
parent_append=(P/'tests-before-1/parent-registration/registration-append.txt').read_text()
pibefore=(P/'tests-before-1/parent-registration/before'/pi).read_text();piraw=(P/'tests-before-1/parent-registration/raw'/pi).read_text()
assert pibefore+parent_append==piraw
assert patch(pibefore,(P/'tests-before-1/parent-registration/registration.patch').read_text())==piraw
expected[pi]+=parent_append
for row in private['registrations']:
 rel=row['path'];before=Path(row['before']['path']).read_text();raw=Path(row['raw']['path']).read_text();append=Path(row['append']['path']).read_text()
 assert expected[rel]==before and before+append==raw
 assert patch(before,(P/'tests-before-1/private-registration/diffs'/f'{rel}.patch').read_text())==raw
 expected[rel]=raw
for row in [parenthold['imports'][0]]+private['modules']:expected[row['path']]=Path(row['raw']['path']).read_text()
assert set(expected)==set(changed)
format_rows=[]
comment=j(P/'root/comment-clarification.json');comment_rel=comment['path']
assert [k for k in v1 if v1[k]!=final[k]]==[comment_rel]
for rel,raw in expected.items():
 live=(W/rel).read_text();same=raw==live
 assert literals(raw)==literals(live),rel
 assert fmt_tokens(raw)==fmt_tokens(live),rel
 if rel!=comment_rel:assert h(raw.encode())==j(P/'source-candidate-raw.json')['source_sha256'][rel],rel
 if not same:
  diff=''.join(difflib.unified_diff(raw.splitlines(True),live.splitlines(True),fromfile='held/'+rel,tofile='candidate2/'+rel))
  dp=R/'diffs'/f'{rel}.patch';dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(diff)
  format_rows.append(dict(path=rel,diff=bind(dp),qualification='comment-only additive clarification' if rel==comment_rel else 'format-only; optional commas/import order manually checked'))
 if rel in hold['existing_test_migration_paths']:
  assert literals((P/'production-1/before'/rel).read_text())==literals(live),rel
assert set(r['path'] for r in format_rows)==set(j(P/'root/formatting.json')['formatted_paths'])|{comment_rel}
assert h(expected[comment_rel].encode())==comment['before_sha256'] and final[comment_rel]==comment['after_sha256']
assert lex(expected[comment_rel])==lex((W/comment_rel).read_text())
# Production invocation bodies are byte-exact after removing appended test registrations.
for rel,marker in [(title,'    pub(super) fn document_title_call_preflight'),(pi,'    pub(super) fn pi_call_preflight')]:
 before=(P/'production-1/before'/rel).read_text();raw=(P/'production-1/raw'/rel).read_text();assert before[before.index(marker):]==raw[raw.index(marker):]
# Read-only Git audit; no index/worktree mutation.
tracked=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
assert set(tracked)==set(hold['production_paths']+hold['existing_test_migration_paths']),tracked
assert set(untracked)==set(expected)-set(parent),untracked
dump('git-path-audit.json',dict(tracked_modified=tracked,untracked=untracked,read_only=True))
dump('composition.json',dict(parent_count=len(parent),candidate_count=len(final),changed=changed,production_checks=checks,format_and_comment_diffs=format_rows,all_current_hashes_join=True,raw_composition_exact=True,old_migration_literal_tokens_exact=True,all_held_to_final_literals_exact=True,all_held_to_final_normalized_tokens_exact=True,production_invocation_tails_exact=True,comment_only_tokens_exact=True))
receipt=dict(status='clear_source_only',base=j(P/'source-candidate-2.json')['base'],bindings=[bind(P/n) for n in ['source-parent.json','source-candidate.json','source-candidate-raw.json','source-candidate-2.json','production-1/source-ready.json','tests-before-1/source-ready.json','tests-before-1/parent-ready.json','tests-before-1/private-ready.json','root/formatting.json','root/comment-clarification.json','validation/format-1.json','validation/format-1.log','validation/format-2.json','validation/format-2.log']],composition=bind(R/'composition.json'),git_paths=bind(R/'git-path-audit.json'),findings=[],conclusions=[
 'All1675 selected current input hashes join candidate2. Compared with1672 parent inputs, exactly13 paths change: three production, seven existing migration paths, three new child-test files. No parent path is removed; read-only Git roster contains exactly those paths.',
 'Ten production/migration before/raw/diff bindings reconstruct exactly. Existing snapshots join parent; new parent/private registrations compose additively over the production raw files, with all three new modules exact before formatting.',
 'Formatting changes exactly four paths: one PI let-binding wrap and three test modules. Manual diff review and independent lexical comparisons preserve every literal, identifier, number and operator, allowing only inspected optional trailing commas and two ordinary import reorderings. No old semantic JS/string payload changes.',
 'Candidate2 adds only the separately disclosed key-cache comment clarification. Its executable tokens and all assertions equal the frozen migrated raw module and candidate1. Both inventories and the clarification binding are retained.',
 'Title factory uses the supplied length/name handles with clone2 after display and one installer handoff8 before old4. PI pays clone1 immediately after display, returns its retained owner key by move, uses it at six matching method names and discards it for four accessor displays. CharacterData.length pays clone1 for the existing key. Old invocation bodies, descriptors, method/native names, object creation order and runtime object/registry counts remain unchanged by source.',
 'No Runtime counter/field, stored type layout, object-ID assignment, cap or reset changes are present. MAX_STEPS and host/protocol/runtime dispatch sources retain their parent hashes. Numeric migrations are only selected fee/aggregate boundaries plus three boundary-name renames and one tuple destructuring adapter; old isolated heap/semantic assertions remain.'],qualification='Static source/byte/lexical/patch and read-only Git inspection only. No project code import, Rust/JS execution, build, formatter invocation or live edit by this reviewer. Root owns observed outcomes. The1675 map is the root-selected input inventory, not a claim that this receipt independently discovered all build dependencies. Failed format invocation and first normalizer attempt are preserved as root-qualified tooling history, not candidate semantic failures.')
dump('source-review.json',receipt)
print(json.dumps(bind(R/'source-review.json')))
