from pathlib import Path
import json,hashlib,collections
P=Path('/tmp/eris-startup-headroom-plan-1');O=P/'validation-review-1';W=P/'worktree';H=lambda b:hashlib.sha256(b).hexdigest()
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def verify(r):
 p=Path(r['path']);b=p.read_bytes();assert len(b)==r['bytes'] and H(b)==r['sha256'],str(p)
def refs(value):
 if isinstance(value,dict):
  if {'path','bytes','sha256'}<=value.keys():verify(value)
  for v in value.values():refs(v)
 elif isinstance(value,list):
  for v in value:refs(v)
def receipt(path):
 j=json.loads(path.read_text());log=path.parent/j['log'];assert H(log.read_bytes())==j['sha256'];assert j['exit']==0
 return j,rec(log)
final_path=P/'root/final-validation.json';f=json.loads(final_path.read_text());refs(f);rpath=P/'root/replay-validation.json';r=json.loads(rpath.read_text());refs(r)
assert f['status']==r['status']=='pass'
assert (P/'source-final.json').read_bytes()==(P/'source-candidate-3.json').read_bytes()
source=json.loads((P/'source-final.json').read_text())['source_sha256'];parent=json.loads((P/'source-parent.json').read_text())['source_sha256'];assert len(source)==1675
changed=sorted(p for p in source if source[p]!=parent.get(p));assert changed==f['changed_source_paths'] and len(changed)==14
for path,h in source.items():
 # Publication documentation can be imported independently after measured code;
 # current immutable code/tool/corpus/baseline inputs must still equal the map.
 if path.startswith('docs/') or path=='README.md':continue
 assert H((W/path).read_bytes())==h,path
assert (f['production_paths'],f['existing_test_migration_paths'],f['new_test_files'],f['new_test_groups'],f['private_operation_rows'])==(3,8,3,7,84)
old_rust=json.loads((O/'rust-review.json').read_text());refs(old_rust)
assert old_rust['status']=='clear'
for key,total in [('default',3131),('host_vulkan',3485)]:
 a=old_rust['full_suites'][key];assert a['run']['totals']=={'passed':total,'failed':0,'ignored':0,'measured':0,'filtered':0};assert a['run']['result_rows']==52 and a['run']['worker_passed']==93
assert f['default_passed']==3131 and f['host_vulkan_passed']==3485
strict=[]
for row in f['strict_checks']:
 j,log=receipt(Path(row['receipt']['path']));assert log==row['log']
 cmd=j['command']
 if 'clippy' in cmd:assert '--all-targets' in cmd and cmd[-3:]==['--','-D','warnings']
 else:assert 'fmt' in cmd and cmd[-2:]==['--','--check']
 strict.append({'receipt':row['receipt'],'log':row['log'],'command':cmd,'exit':0})
binary=f['release_binary'];verify(binary);assert binary==r['binary'];assert binary['source_inventory']==r['source']==f['source']
build,build_log=receipt(Path(binary['build_receipt']['path']));assert '+1.88.0' in build['command'] and '--release' in build['command'] and 'test262-host' in build['command'] and build['command'][-2:]==['--bin','eris-js']
assert H((P/'target-msrv/release/eris-js').read_bytes())==binary['sha256']
prior_root=Path('/tmp/eris-promise-all-settled-upstream-plan-1/root/replay-validation.json');prior=json.loads(prior_root.read_text());origins={'promise-all-settled':prior['baseline_replay'],**{x['profile']:x['report'] for x in prior['old_comparisons']}}
rows=[];total_cases=total_controls=0;total_counts=collections.Counter();failure_classes=collections.Counter()
for row in r['comparisons']:
 profile=row['profile'];origin=origins[profile];verify(origin);assert row['parent']['sha256']==origin['sha256'];assert Path(row['parent']['path']).read_bytes()==Path(origin['path']).read_bytes()
 before=json.loads(Path(row['parent']['path']).read_text());after=json.loads(Path(row['report']['path']).read_text());assert set(after)==set(before)
 changed_fields=[k for k in after if after[k]!=before[k]];assert sorted(changed_fields)==['binary','binary_sha256','seconds']
 assert after['binary']==binary['path'] and after['binary_sha256']==binary['sha256']
 cases=after['cases'];controls=after['harness_preflight'];assert cases==before['cases'] and controls==before['harness_preflight']
 assert len(cases)==row['cases'] and len(controls)==row['controls'];assert len({x['id'] for x in cases})==len(cases)
 assert all(x['verified'] is True for x in controls) and after['harness_preflight_passed'] is True
 assert len({(x['name'],x['result']['mode']) for x in controls})==len(controls)
 counts=dict(collections.Counter(x['status'] for x in cases));assert counts==row['counts']==after['counts']
 assert after['mode_cases']==len(cases) and after['regressions']==after['improvements']==[]
 assert after['full_test262_conformance'] is False
 assert H(json.dumps(after['runner_policy'],sort_keys=True).encode())==after['runner_policy_sha256']
 cmd,log=receipt(Path(row['receipt']['path']));assert log==row['log'];args=cmd['command']
 assert args[args.index('--binary')+1]==binary['path'] and args[args.index('--profile')+1]==profile and args[args.index('--output')+1]==row['report']['path']
 baseline_path=W/args[args.index('--baseline')+1];baseline=json.loads(baseline_path.read_text());rel=str(baseline_path.relative_to(W));assert H(baseline_path.read_bytes())==source[rel]==parent[rel]
 for k in ['revision','corpus_manifest_sha256','runner_policy_sha256']:assert baseline[k]==after[k]
 projected={x['id']:{k:x[k] for k in ['status','case_sha256','source_sha256']} for x in cases};assert baseline['cases']==projected
 corpus=W/'tests/upstream'/('test262-'+profile)/'manifest.json';assert H(corpus.read_bytes())==after['corpus_manifest_sha256'];corpus_rel=str(corpus.relative_to(W));assert source[corpus_rel]==parent[corpus_rel]
 for x in cases:
  if x['status']=='failed':
   obs=x['observation'];failure_classes[(obs.get('status'),obs.get('message'))]+=1
 total_cases+=len(cases);total_controls+=len(controls);total_counts.update(counts)
 rows.append({'profile':profile,'parent_origin':origin,'retained_parent':row['parent'],'report':row['report'],'receipt':row['receipt'],'log':row['log'],'cases':len(cases),'controls':len(controls),'counts':counts,'exact_complete_arrays':True,'all_controls_verified':True,'only_changed_top_level_fields':changed_fields,'case_array_sha256':H(json.dumps(cases,sort_keys=True,separators=(',',':')).encode()),'control_array_sha256':H(json.dumps(controls,sort_keys=True,separators=(',',':')).encode()),'baseline':rec(baseline_path),'corpus_manifest':rec(corpus),'runner_policy_sha256':after['runner_policy_sha256']})
assert (total_cases,total_controls)==(1050,348)==(r['exact_cases'],r['exact_controls'])==(f['exact_case_records'],f['exact_harness_records'])
assert total_counts=={'passed':952,'failed':44,'unsupported':54}
assert failure_classes=={('host-failure','unhandled-rejection'):42,('exception',"'Proxy' is not defined"):2}
assert f['baseline_changes']==r['baseline_changes']==0
for path in source:
 if path.startswith('tools/') or path.startswith('tests/conformance/') or path.startswith('tests/upstream/'):
  assert source[path]==parent[path],path
ci=json.loads((P/'root/parent-ci-final.json').read_text());assert ci['status']=='completed' and ci['conclusion']=='success' and len(ci['jobs'])==11 and all(x['conclusion']=='success' for x in ci['jobs'])
replay_detail={'status':'clear','scope':'All four actual reports and retained parents read directly; exact full arrays and metadata compared independently.','root_replay':rec(rpath),'prior_published_replay_ledger':rec(prior_root),'profiles':rows,'totals':{'cases':total_cases,'verified_controls':total_controls,'case_status_counts':dict(total_counts),'unchanged_host_unhandled_vetoes':42,'unchanged_Proxy_exceptions':2},'baseline_changes':0,'policy_tool_and_corpus_source_hashes_unchanged':True}
p=O/'replay-review.json';p.write_text(json.dumps(replay_detail,indent=2)+'\n')
review={'status':'clear','scope':'Independent final source, raw-log, frozen-binary and complete replay audit; no project execution or live changes.','final_ledger':rec(final_path),'source':f['source'],'source_equals_candidate3_bytes':True,'selected_source_inputs':1675,'changed_paths':14,'production_paths':3,'existing_test_migrations':8,'new_test_files':3,'rust_roster_review':rec(O/'rust-review.json'),'rust_summary':{'default_1_88':3131,'host_vulkan_1_99':3485,'result_rows_each':52,'worker_cases_each':93,'new_groups':7,'selected_old_numeric_renames':3,'old_rosters_preserved':True,'failed_or_ignored_or_filtered':0},'observed_startup':{'parent_work':99973,'candidate_work':99694,'work_saved':279,'remaining':306,'parent_accounted_heap':1745449,'candidate_accounted_heap':1744317,'accounted_heap_saved':1132,'objects_and_capacity':752,'globals':212,'native_registry':299,'prototype_registry':25},'strict_checks':strict,'release_binary':binary,'release_log':build_log,'replay_review':rec(O/'replay-review.json'),'replay_totals':{'exact_cases':1050,'exact_controls':348,'baseline_changes':0,'regressions':0,'improvements':0},'parent_ci':{'receipt':rec(P/'root/parent-ci-final.json'),'jobs':11,'conclusion':'success','qualification':'Published parent CI only; no candidate remote CI claim.'},'retained_failure_and_correction':{'first_full':'2790passed/1failed library target; stale cumulative work equality306vs27; later heap equality and integration targets unreached.','migration':'Explicit eighth migration appends preselected+279/-1132; exact inverse and unchanged production already peer-reviewed.','peer':rec(P/'migration-addendum-1/layout-review.json')},'qualifications':['Embedded candidate-observation-1 retains its historical then-pending wording; completed focused/full/strict/replay receipts supersede that phase status.','The rebuilt binary is4,436,696 bytes with its own changed identity; exact replay comparisons exclude only top-level seconds/binary/binary_sha256. All case observations, harness observations, fingerprints, policies, corpus identities and denominators remain exact.','The unchanged44 failed modes include42 final-unhandled host-policy vetoes and2 Proxy runtime exceptions; no reason-based removal, reclassification or new passing outcome is inferred.','No new standalone Python suite was run or claimed. Existing runner/tool/corpus/baseline source hashes are unchanged.','Source inventory is a selected-input map, not a complete build graph. Startup work/heap are logical counters, not CPU time, allocator bytes, stack or RSS.','Publication documentation/evidence packaging and future Promise.any/AggregateError admission are separate; this receipt makes no broader compatibility, security, GPU or Chromium claim.'],'findings':[]}
p=O/'final-review.json';p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(rec(p)))
