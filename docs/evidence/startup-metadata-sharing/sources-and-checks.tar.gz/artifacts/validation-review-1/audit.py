from pathlib import Path
import json,hashlib,re,collections
P=Path('/tmp/eris-startup-headroom-plan-1');O=P/'validation-review-1';W=P/'worktree';H=lambda b:hashlib.sha256(b).hexdigest()
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
def emit(n,j):
 p=O/n;p.write_text(json.dumps(j,indent=2)+'\n');return rec(p)
def compact_run(label,run):
 roster=emit(label+'-roster.json',run['records'])
 return {**{k:v for k,v in run.items() if k!='records'},'roster':roster}
def read_run(folder,name):
 receipt=P/folder/(name+'.json')
 if not receipt.exists():return None
 j=json.loads(receipt.read_text());log=P/folder/j['log'];b=log.read_bytes();assert H(b)==j['sha256'];s=b.decode();result_rows=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s,re.M);assert result_rows
 records=re.findall(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?: .*)?$',s,re.M)
 names=collections.Counter(n for n,status in records);assert len(names)==len(records),name
 totals={k:sum(int(row[i+1]) for row in result_rows) for i,k in enumerate(['passed','failed','ignored','measured','filtered'])}
 actual=collections.Counter(status for _,status in records)
 assert len(records)==totals['passed']+totals['failed']+totals['ignored']
 assert actual['ok']==totals['passed'] and actual['FAILED']==totals['failed'] and actual['ignored']==totals['ignored']
 compiler=next((x for x in j['command'] if x.startswith('+')),None)
 worker=s.split('Running tests/worker.rs (',1)
 worker_count=None
 if len(worker)==2:
  m=re.search(r'^test result: \w+\. (\d+) passed;',worker[1],re.M);assert m;worker_count=int(m[1])
 return {'receipt':rec(receipt),'log':rec(log),'command':j['command'],'compiler_request':compiler,'exit':j['exit'],'result_rows':len(result_rows),'totals':totals,'records':dict(sorted(records)),'worker_passed':worker_count}
parent_default=read_run('rust-parent','default-full-2');parent_host=read_run('rust-parent','host-vulkan-full-1')
assert parent_default['totals']=={'passed':3124,'failed':0,'ignored':0,'measured':0,'filtered':0}
assert parent_host['totals']=={'passed':3478,'failed':0,'ignored':0,'measured':0,'filtered':0}
parent_rosters=emit('parent-rosters.json',{'default':parent_default,'host_vulkan':parent_host})
parent_map=json.loads((P/'source-parent.json').read_text())['source_sha256'];first_map=json.loads((P/'source-candidate.json').read_text())['source_sha256'];second_map=json.loads((P/'source-candidate-2.json').read_text())['source_sha256'];candidate_map=json.loads((P/'source-candidate-3.json').read_text())['source_sha256']
assert len(parent_map)==1672 and len(candidate_map)==1675
for path,h in candidate_map.items():assert H((W/path).read_bytes())==h,path
removed=sorted(set(parent_map)-set(candidate_map));new=sorted(set(candidate_map)-set(parent_map));changed=sorted(p for p in parent_map if candidate_map[p]!=parent_map[p]);assert not removed and len(new)==3 and len(changed)==11
prod=json.loads((P/'production-1/source-ready.json').read_text());assert set(changed)==set(prod['production_paths']+prod['existing_test_migration_paths']+['src/script/typed_array/tests.rs'])
private=json.loads((P/'tests-before-1/private-ready.json').read_text());parent_tests=json.loads((P/'tests-before-1/parent-ready.json').read_text())
expected_new=[private['modules'][0]['path'],private['modules'][1]['path'],parent_tests['imports'][0]['path']];assert sorted(expected_new)==new
raw_map=json.loads((P/'source-candidate-raw.json').read_text())['source_sha256']
for r in prod['files']:
 path=r['path'];selected=P/'production-1/raw'/path
 for reg in private['registrations']:
  if reg['path']==path:selected=Path(reg['raw']['path'])
 assert raw_map[path]==H(selected.read_bytes()),path
for path in new:assert raw_map[path]==H((P/'tests-before-1/raw'/path).read_bytes()),path
raw_to_first=sorted(p for p in raw_map if raw_map[p]!=first_map[p]);formatting=json.loads((P/'root/formatting.json').read_text());assert sorted(formatting['formatted_paths'])==raw_to_first
changed_second=sorted(p for p in first_map if first_map[p]!=second_map[p]);assert changed_second==['src/script/processing_instruction/key_cache_tests.rs']
b=(P/'comment-clarification-1/before.rs').read_bytes();a=(P/'comment-clarification-1/after.rs').read_bytes();path=changed_second[0];assert H(b)==first_map[path] and H(a)==second_map[path]
strip=lambda text:'\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('//'))
assert strip(b.decode())==strip(a.decode())
# No changed code/data input outside the selected eleven existing paths and three additions.
assert [p for p in candidate_map if second_map[p]!=candidate_map[p]]==['src/script/typed_array/tests.rs']
assert H((P/'migration-addendum-1/raw.rs').read_bytes())==candidate_map['src/script/typed_array/tests.rs']
source=emit('source-accounting.json',{'status':'clear selected composition, comment-only source2 and explicit eighth migration in source3','parent':rec(P/'source-parent.json'),'raw_candidate':rec(P/'source-candidate-raw.json'),'first_formatted':rec(P/'source-candidate.json'),'comment_corrected_candidate':rec(P/'source-candidate-2.json'),'final_candidate':rec(P/'source-candidate-3.json'),'eighth_migration_peer':rec(P/'migration-addendum-1/layout-review.json'),'verified_live_files':len(candidate_map),'changed_existing_paths':changed,'new_paths':new,'removed_paths':removed,'raw_composition_exact':True,'formatter_paths':raw_to_first,'formatter_receipt':rec(P/'root/formatting.json'),'independent_formatter_token_check':rec(O/'format-token-review.json'),'comment_only_correction':rec(P/'root/comment-clarification.json'),'correction_before':rec(P/'comment-clarification-1/before.rs'),'correction_after':rec(P/'comment-clarification-1/after.rs'),'source2_noncomment_lines_exact_to_source1':True,'qualification':'Formatting scope is bound to root retained receipt and raw/composed source hashes. The three production APIs and staged fees were independently reviewed before import. No compiler, formatter, engine or project code executed by this reviewer.'})
focused={n:read_run('validation',n) for n in ['parent-controls-1','candidate-controls-1','candidate-pi-1','candidate-title-1']}
assert focused['parent-controls-1']['totals']['failed']==3 and focused['parent-controls-1']['exit']==101
assert [focused[n]['totals']['passed'] for n in ['candidate-controls-1','candidate-pi-1','candidate-title-1']]==[3,66,24]
for n in ['candidate-controls-1','candidate-pi-1','candidate-title-1']:assert focused[n]['exit']==0 and focused[n]['totals']['failed']==focused[n]['totals']['ignored']==0
observations={}
for n in ['parent-controls-1','candidate-controls-1']:
 s=(P/'validation'/f'{n}.log').read_text();m=re.search(r'STARTUP_HEADROOM (.*)',s);assert m
 observations[n]={k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',m[1])}
base=observations['parent-controls-1'];now=observations['candidate-controls-1'];assert base['raw_work']-now['raw_work']==279 and base['allocated']-now['allocated']==1132
assert (base['raw_work'],base['remaining'],base['allocated'])==(99973,27,1745449)
assert (now['raw_work'],now['remaining'],now['allocated'])==(99694,306,1744317)
for k in ['objects','capacity','globals','natives','prototypes']:assert base[k]==now[k]
expected_groups=[]
for mod in [Path(parent_tests['imports'][0]['raw']['path'])]+[Path(m['raw']['path']) for m in private['modules']]:
 rel=str(mod.relative_to(P/'tests-before-1/raw'));prefix=rel[:-3].replace('/','::').replace('src::','',1)
 expected_groups.extend(prefix+'::'+name for name in re.findall(r'#\[test\]\s*fn (\w+)\(',mod.read_text()))
assert len(expected_groups)==7
current_focused={**focused['candidate-pi-1']['records'],**focused['candidate-title-1']['records']};assert all(current_focused.get(g)=='ok' for g in expected_groups)
focus=emit('focused-accounting.json',{'status':'clear observed focused results','runs':focused,'observations':observations,'observed_saved_work':279,'observed_saved_accounted_heap':1132,'new_groups':expected_groups,'new_groups_all_observed_passed':True,'private_operations':'Four passed authored groups contain84 fixed planned operations; these are not84 separate test cases.','scope':['Parent three failures match first createProcessingInstruction pointer, title-get length pointer and raw99973 vs99694 mismatch. Later assertions after each first failure were not reached.','The candidate3 run overlaps the later PI66 run; PI66 plus title24 contain90 distinct groups, not93.','Parent and initial candidate controls were compiled with Rust1.88 default features. Their counter difference is logical/accounted, not CPU/allocator/RSS timing.','candidate-controls and candidate-pi precede the comment-only source2 clarification; final executable code is unchanged by that clarification.','Raw observations establish the selected delta but do not establish future Promise.any/AggregateError admission.']})
renames={r['old']:r['new'] for r in json.loads((P/'production-1/notes.json').read_text())['renames']};assert len(renames)==3
full={}
for label,parent,name in [('default',parent_default,'default-full-2'),('host_vulkan',parent_host,'host-vulkan-full-1')]:
 run=read_run('validation',name)
 if run is None:full[label]={'status':'pending; no completed receipt'};continue
 assert run['exit']==0 and run['totals']['failed']==run['totals']['ignored']==run['totals']['filtered']==0
 mapped={}
 changed_names=[]
 for old,status in parent['records'].items():
  parts=old.rsplit('::',1);tail=parts[-1];new_name=old
  if tail in renames:
   new_name='::'.join(parts[:-1]+[renames[tail]]);changed_names.append({'old':old,'new':new_name})
  mapped[new_name]=status
 assert len(changed_names)==3
 added=sorted(set(run['records'])-set(mapped));missing=sorted(set(mapped)-set(run['records']));assert not missing and added==sorted(expected_groups)
 assert all(run['records'][n]==s for n,s in mapped.items())
 assert len(run['records'])==len(parent['records'])+7
 full[label]={'status':'clear','run':compact_run(label+'-candidate',run),'three_exact_renames':changed_names,'added_groups':added,'removed_groups':missing,'retained_parent_records':len(mapped),'new_groups':len(added),'all_parent_results_preserved':True}
all_done=all(r['status']=='clear' for r in full.values())
receipt={'status':'clear' if all_done else 'preliminary; focused/source checks clear; full suites pending','scope':'Independent inert source/log/hash/roster audit. No project execution or live changes.','source_accounting':source,'parent_rosters':parent_rosters,'focused_accounting':focus,'retained_initial_full_failure':compact_run('initial-failed-full',read_run('validation','default-full-1')),'eighth_migration_peer':rec(P/'migration-addendum-1/layout-review.json'),'full_suites':full,'expected_final_totals_not_claimed_until_observed':{'default':3131,'host_vulkan':3485},'strict_release_replay':'Outside this interim Rust roster receipt until completed receipts are provided; no inference of successful runs.'}
print(json.dumps(emit('rust-review.json' if all_done else 'preliminary.json',receipt)))
