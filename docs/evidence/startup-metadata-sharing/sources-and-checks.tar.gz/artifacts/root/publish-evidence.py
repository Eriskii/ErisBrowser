import gzip,hashlib,io,json,tarfile
from pathlib import Path,PurePosixPath
A=Path(__file__).resolve().parents[1];W=A/'worktree';E=W/'docs/evidence/startup-metadata-sharing'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def read(n):return json.loads((A/n).read_bytes())
final=read('source-final.json')['source_sha256'];parent=read('source-parent.json')['source_sha256']
changed=sorted(p for p,h in final.items() if parent.get(p)!=h);assert len(changed)==14
for p,h in final.items():assert sha((W/p).read_bytes())==h,p
members={}
def add(name,path,role):
 assert path.is_file() and not path.is_symlink(),path
 assert name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
 members[name]={'data':path.read_bytes(),'origin':str(path),'role':role}
for p in changed:add('sources/'+p,W/p,'changed-source')
docs=read('documentation-1/source-ready.json')['files'];assert len(docs)==5
for row in docs:
 p=row['relative_path'];assert bind(W/p)['sha256']==row['raw']['sha256'];add('documentation/'+p,W/p,'published-documentation')
for directory in ['production-1','tests-before-1','comment-clarification-1','migration-addendum-1','current-source-review-1','documentation-1','replay-parent','rust-parent','validation','validation-review-1']:
 assert (A/directory).is_dir(),directory
 for p in sorted((A/directory).rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:add('artifacts/'+str(p.relative_to(A)),p,'validation-artifact')
excluded={'evidence-selection.json','publication-verification.json','github-publication.json'}
for p in sorted((A/'root').glob('*')):
 if p.is_file() and p.name not in excluded:add('artifacts/root/'+p.name,p,'root-receipt-or-script')
for p in sorted(A.glob('*')):
 if p.is_file() and p.suffix in ('.json','.py'):add('artifacts/'+p.name,p,'validation-artifact')
ledger=read('root/final-validation.json');peer=read('validation-review-1/final-review.json');assert ledger['status']=='pass' and peer['status']=='clear'
selection=[{'path':n,'bytes':len(x['data']),'sha256':sha(x['data']),'origin':x['origin'],'role':x['role']} for n,x in sorted(members.items())]
assert sum(r['bytes'] for r in selection)<32*1024*1024
S=A/'root/evidence-selection.json';S.write_text(json.dumps({'status':'frozen','members':selection,'excluded':'Compiled binaries, build caches, unchanged repository, and subsequent publication/CI state. Selected source map is not the full build graph.'},indent=2)+'\n')
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w',format=tarfile.USTAR_FORMAT) as archive:
 for name,x in sorted(members.items()):
  info=tarfile.TarInfo(name);info.size=len(x['data']);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(x['data']))
packed=gzip.compress(raw.getvalue(),compresslevel=9,mtime=0);assert len(packed)<8*1024*1024
E.mkdir(parents=True,exist_ok=True);P=E/'sources-and-checks.tar.gz';assert not P.exists();P.write_bytes(packed)
summary={'schema':1,'status':'verified','archive':{'path':P.name,'bytes':len(packed),'sha256':sha(packed),'uncompressed_tar_bytes':len(raw.getvalue()),'member_bytes':sum(r['bytes'] for r in selection)},'source_count':14,'documentation_count':5,'artifact_count':len(selection)-19,'source_inventory':bind(A/'source-final.json'),'claims':ledger,'claims_authority':{'ledger':bind(A/'root/final-validation.json'),'peer':bind(A/'validation-review-1/final-review.json')},'selection':bind(S),'members':selection}
(E/'manifest.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(P,'r:gz') as archive:
 assert archive.getnames()==[r['path'] for r in selection]
 for r in selection:
  member=archive.getmember(r['path']);assert member.isfile() and not member.issym() and not member.islnk();b=archive.extractfile(member).read();assert len(b)==r['bytes'] and sha(b)==r['sha256']
print(json.dumps({'members':len(selection),'sources':14,'docs':5,'archive':bind(P)}))
