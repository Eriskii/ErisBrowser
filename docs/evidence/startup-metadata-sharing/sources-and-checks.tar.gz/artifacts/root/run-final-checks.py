import subprocess,sys,json,hashlib
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def unchanged():
 for p,h in json.loads((A/'source-candidate-3.json').read_text())['source_sha256'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
commands=[
 [str(A/'run-tool.py'),'format-check-1','env','CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.99.0','fmt','--manifest-path','Cargo.toml','--','--check'],
 [str(A/'run-check.py'),'default-clippy-1','1.88.0','Cargo.toml','-','clippy','--all-targets','--','-D','warnings'],
 [str(A/'run-check.py'),'host-vulkan-clippy-1','1.99.0','Cargo.toml','test262-host,vulkan-raster','clippy','--all-targets','--','-D','warnings'],
 [str(A/'run-check.py'),'host-release-1','1.88.0','Cargo.toml','test262-host','build','--release','--bin','eris-js'],
 [str(A/'root/freeze-release-and-replay.py')],
 [str(A/'root/finalize-validation.py')]]
for command in commands:
 unchanged();subprocess.run([sys.executable,*command],check=True,cwd=W)
unchanged();print('Final checks, release build and exact four-profile replay complete.',flush=True)
