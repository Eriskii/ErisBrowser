import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def parse(directory,label):
 receipt=directory/(label+'.json');r=json.loads(receipt.read_text());log=directory/(label+'.log');text=log.read_text()
 assert r['exit']==0 and r['sha256']==bind(log)['sha256']
 rows=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)]
 totals=[sum(row[i] for row in rows) for i in range(5)]
 assert totals[1:]==[0,0,0,0],(label,totals)
 harness=None;names=[]
 for line in text.splitlines():
  match=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
  if match:harness=match[1]
  if 'Doc-tests ' in line:harness='Doc-tests '+line.split('Doc-tests ',1)[1]
  result=re.match(r'^test (.+) \.\.\. ok$',line)
  if result:
   assert harness is not None
   names.append(harness+'::'+result[1])
 assert len(names)==len(set(names))==totals[0],(label,len(names),totals)
 return {'receipt':bind(receipt),'log':bind(log),'result_rows':len(rows),'totals':totals,'passed_names':sorted(names)}
renames={
 'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99973_work_boundary':'cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99694_work_boundary',
 'promise_full_raw99973_and_public_reset_preserve_empty_paid_arenas':'promise_full_raw99694_and_public_reset_preserve_empty_paid_arenas',
 'text_metadata_keys_raw_bootstrap_uses_99973_work_and_preserves_public_reset':'text_metadata_keys_raw_bootstrap_uses_99694_work_and_preserves_public_reset'}
def normalize(names):
 result=set(names)
 for old,new in renames.items():
  matches=[n for n in result if n.endswith('::'+old)];assert len(matches)==1
  result.remove(matches[0]);result.add(matches[0][:-len(old)]+new)
 return result
new=[]
for p in ['src/script/processing_instruction/display_key_tests.rs','src/script/processing_instruction/display_key_fee_tests.rs','src/script/document_title/key_cache_fee_tests.rs']:
 module=p.removeprefix('src/').removesuffix('.rs').replace('/','::')
 for name in re.findall(r'#\[test\]\s*fn (\w+)',(A/'worktree'/p).read_text()):new.append('src/lib.rs::'+module+'::'+name)
assert len(new)==len(set(new))==7
comparisons=[]
for label,oldlabel,expected in [('default-full-2','default-full-2',3131),('host-vulkan-full-1','host-vulkan-full-1',3485)]:
 old=parse(A/'rust-parent',oldlabel);current=parse(A/'validation',label)
 assert current['totals']==[expected,0,0,0,0]
 assert set(current['passed_names'])==normalize(old['passed_names'])|set(new)
 assert not normalize(old['passed_names'])&set(new)
 comparisons.append({'current':current,'previous':old,'exact_old_roster_plus_new':True})
r={'status':'complete','new_test_groups':7,'new_names':new,'selected_existing_test_renames':renames,'comparisons':comparisons}
(A/'root/rust-validation.json').write_text(json.dumps(r,indent=2)+'\n')
print('All3131 default and3485 host/Vulkan tests pass; exact old rosters plus7 new groups,3 selected renames.')
