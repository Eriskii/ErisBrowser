from pathlib import Path
import hashlib,json,re
OUT=Path('/tmp/eris-startup-headroom-plan-1')
U=Path('/tmp/eris-promise-all-settled-upstream-plan-1')
W=U/'worktree'
P=U/'parent-source.json'
H=lambda b:hashlib.sha256(b).hexdigest()
def emit(name,data):
 (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def file_record(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':H(b)}
parent=json.loads(P.read_text())['source_sha256']
paths=['src/script.rs','src/script/dom_prototypes.rs','src/script/dom_prototypes/interfaces.rs','src/script/document_title.rs','src/script/document_title/tests.rs','tests/fixtures/document-title.js','src/script/processing_instruction.rs','src/script/processing_instruction/character_data.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/processing_instruction/key_cache_fee_tests.rs','src/script/processing_instruction/tests.rs','src/script/processing_instruction/character_data/tests.rs','src/script/text_operations.rs','src/script/text_operations/key_cache_tests.rs','src/script/text_operations/key_cache_fee_tests.rs','src/script/bootstrap_tests.rs','src/script/test262_host/quota_tests.rs','src/script/promises/install_tests.rs','src/script/promises/shared_key_tests.rs','src/script/node_data.rs','src/script/node_data/method_key_tests.rs','src/script/node_data/key_cache_fee_tests.rs','src/script/node_root.rs','src/script/node_predicates.rs','src/script/node_normalize.rs','src/script/node_clone.rs','src/script/node_equality.rs','src/script/object_has_own.rs','src/script/object_has_own/tests.rs','src/script/dom_bindings.rs','src/script/reflect_properties_install.rs','src/script/array_buffer/bootstrap.rs','src/script/data_view/bootstrap.rs','src/script/typed_array/intrinsics.rs','src/script/microtasks.rs']
records=[]
for path in paths:
 p=W/path;b=p.read_bytes();h=H(b);assert parent[path]==h,path
 records.append({'path':path,'bytes':len(b),'sha256':h,'matches_published_parent_inventory':True})
assert len(parent)==1549
# Static literal census only: no project module is imported or executed.
s=(W/'src/script/processing_instruction/key_cache_tests.rs').read_text()
cases=[]
for m in re.finditer(r'Case \{\s*owner: "([^"]+)",\s*member: "([^"]+)",\s*part: "([^"]+)",\s*suffix: "([^"]+)",\s*display: "([^"]+)",\s*arity: (\d+),\s*work: (\d+),\s*heap_constant: (\d+),\s*\}',s):
 owner,member,part,suffix,display,arity,work,heap=m.groups()
 cases.append({'owner':owner,'member':member,'part':part,'suffix':suffix,'display':display,'arity':int(arity),'old_factory_work':int(work),'proposed_factory_work':int(work)+8,'heap_constant_unchanged':int(heap),'consumer':'move returned key into owner property' if part=='value' else 'discard returned display key before owner insertion or next factory','removed_owner_text_work':8+2*len(member) if part=='value' else 0,'removed_owner_text_heap':64+4*len(member) if part=='value' else 0})
assert len(cases)==10
assert sum(c['removed_owner_text_work'] for c in cases)==210
assert sum(c['removed_owner_text_heap'] for c in cases)==708
assert sum(c['part']=='value' for c in cases)==6
emit('source-bindings.json',{'published_api_commit':'486bca305a08b3711077123dff8b2e968f13ef19','later_published_profile_commit':'fb6f51ab5a2033fc14b828c0df36642d7c41fb62','provenance':'Root supplied the commit identities; this review verifies bytes against the published API selected-input inventory, without Git execution. Profile publication changes no Rust inputs.','parent_inventory':file_record(P),'parent_inputs':len(parent),'read_worktree':str(W),'source_files':records,'prior_actual_validation':file_record(Path('/tmp/eris-promise-all-settled-plan-1/root/final-validation.json'))})
report={
 'status':'prospective source audit complete; no implementation or execution',
 'scope':'Remaining immutable native metadata payload duplication at startup. Preserve mutable bags, Native values, method identities, descriptors, order, object IDs and all resource caps.',
 'base':{'commit':'486bca305a08b3711077123dff8b2e968f13ef19','raw_work':99973,'remaining_work':27,'max_work':100000,'max_heap':8388608,'ordinary_objects':752,'native_registry':299,'prototype_registry':25,'globals':212,'binding':'source-bindings.json'},
 'recommendation':{'first_small_option':'Document.title borrowed length/name keys: existing Text-key pattern, two production files, net60 work/336 accounted bytes. Alone leaves87 and does not establish admission for Promise.any/AggregateError.','larger_concrete_option':'PI/CharacterData factory returns its retained display key; six operation owners consume it. Conservative new fixed8 per all10 factory invocations gives net130 work/708 accounted bytes in one production file. New fee requires root selection and frozen quota controls.','optional_same_file_addendum':'CharacterData length owner already has the pooled key in scope: fresh20/88 replaced by clone1, net19 work/88 accounted bytes.','combined_if_all_selected':{'production_paths':['src/script/document_title.rs','src/script/dom_prototypes.rs','src/script/processing_instruction.rs'],'saved_work':209,'saved_accounted_heap':1132,'raw_work':99764,'remaining_work':236,'one_short_raw_work':99763},'future_api_limit':'These projections do not establish that Promise.any plus AggregateError fits. Those installers still need their own complete accounting and admission proof.'},
 'title':{
  'production_paths':['src/script/document_title.rs','src/script/dom_prototypes.rs'],
  'call_sites':'One Document branch in INTERFACES; HTMLDocument aliases Document. Only get/set factories are invoked. Existing pool keys[1]/keys[0] are available in the caller.',
  'proposed_signatures':['document_title_function(&mut self, suffix:&str, display:&str, length:usize, metadata_keys:[&PropertyKey;2]) -> Result<Value>','install_document_title(&mut self, prototype:usize, metadata_keys:[&PropertyKey;2]) -> Result<()>'],
  'sequence':['Installer pays new handoff8 before existing4. Caller forwards [&keys[1], &keys[0]] without a new pool, lookup, retained Runtime field or extra bag.','Factory keeps bag then display-text staging, pays2 before cloning either borrowed metadata key, and uses the unchanged dom_proto_property insertion helper.','Keep both unique display strings, Native strings/records, metadata bags, get/set values, title accessor insertion and all invocation code unchanged.'],
  'per_factory_work':{'old_stages':[9,26,20,9,16,15,21],'old':116,'proposed_stages':[9,26,2,9,15,21],'proposed':82,'saved':34},
  'typed_heap':{'symbols':{'A':'size_of::<Option<AbortSlot>>()','D':'size_of::<Option<f64>>()','K':'size_of::<PropertyKey>()','Bpp':'16*(K+size_of::<Property>()) + 32*size_of::<usize>() + 64','N':'size_of::<Native>()','T':'A+D+2*K+Bpp+N'},'old_constant_stages':[72,100,88,280,80,272,45],'old':'T+937','proposed':'T+769','saved_per_factory':168,'qualification':'Typed conservative charges, not allocator/RSS observations. The property insertion charge256+4*key_length remains unchanged even when the text payload is shared.'},
  'net':{'work':'2*(116-82)-8=60','heap':'2*168=336','raw':99913,'remaining':87},
  'isolated_installer_fixture':{'requires':'Empty owner with pre-reserved order capacity at least1, two spare ordinary slots, separately prepared borrowed keys; fixture costs precede measured budget.','old_work':263,'proposed_work':203,'old_heap':'2*T+Bpp+2234','proposed_heap':'2*T+Bpp+1898','stages':'Old4 +2*116 +title text18 +empty owner insert9; proposed8+4 +2*82 +18+9.'},
  'peer':'Script independently reconciled116→82 and T+937→T+769, net60/336, in a source-only message; retained in peer-note.json.'
 },
 'pi_owner_name':{
  'status':'Concrete conservative prospective option; new8 is proposed, not selected or measured.',
  'production_paths':['src/script/processing_instruction.rs'],
  'proposed_signature':'pi_function(&mut self,suffix:&str,display:&str,length:usize,metadata_keys:[&PropertyKey;2]) -> Result<(Value,PropertyKey)>',
  'why_all_ten':'All calls use one unconditional producer shape. Paying8 on all10 avoids pretending a new optional-output branch or extra lifetime is free on the four accessor paths. No generic metadata redesign or new lookup is required.',
  'sequence':['Pay new8 before the existing first work/bag admission; an8 refusal creates no bag/key/value.','Run the existing bag and display-text stages in their original order. Retain a single PropertyKey::String(name.clone()) immediately after successful display allocation.','Run the existing clone2, length/name insertion and Native allocation stages byte-equivalently; the original display handle moves into the name descriptor. The new owner key has prepaid cleanup on every later refusal.','Return (fresh Native value, retained owner key). Six methods consume the key through dom_proto_property, removing only their dom_proto_named text stage.','Four accessors destructure and discard the returned display key promptly, before the next factory/owner insertion. They still materialize target/data/length owner keys as before, except the separately selected length addendum.'],
  'new_fixed8_proof':[{'work':2,'role':'Bounded additional result-state preparation and pair assembly.'},{'work':1,'role':'One retained JsString handle clone after the existing text admission.'},{'work':1,'role':'Wrap the retained handle as an owned PropertyKey.'},{'work':2,'role':'Transfer and destructure the two-field result at its immediate private caller.'},{'work':2,'role':'Prepay release of the additional handle for factory-local refusal and the caller-side discard/insertion-refusal alternatives.'}],
  'proof_qualification':'These are bounded abstract ownership/control roles, not counts of machine instructions. Existing factory work/heap and insertion-helper fees remain distinct; root must select the new envelope before quota tests or production. Successful insertion transfers the same handle, so there is no second clone or new buffer.',
  'case_rows':cases,
  'totals':{'removed_owner_text_work':210,'new_work':'10*8=80','net_saved_work':130,'removed_accounted_heap':708,'raw_work':99843,'remaining_work':157,'one_short_raw_work':99842},
  'preservation':['Every original metadata object is still allocated at the same point and ID; no new or removed ordinary object, native registry entry, prototype, global, State field, arena or queue field.','Display and owner key share immutable UTF-16 storage only. Replacing/deleting mutable function.name metadata cannot mutate the owner key; getter/setter bags and cross-realm bags remain distinct.','Native dispatch names stay distinct owned UTF-8 strings; do not share or remove their charge.','Existing dom_proto_property comparisons, movement, map/order growth,256+4*length heap tariff and property flags stay unchanged.','A failed factory may leave its admitted private bag prefix, as today; no rollback or atomic-allocation claim. New retained handle cleanup is prepaid at entry.','No body/getter/setter call semantics or public caps change. New result tuple may affect local generated stack layout; no unmeasured stack or performance claim.']
 },
 'character_data_length':{
  'production_path':'src/script/processing_instruction.rs',
  'source':'CharacterData branch after the existing get-length factory already has metadata_keys[0], exactly the immutable length key.',
  'proposed_sequence':'After the getter exists, pay1 before cloning metadata_keys[0]; call unchanged dom_proto_property for the same accessor. Replace only dom_proto_named(length), not getter metadata or dispatch.',
  'ownership':'The getter handle already exists at the old text-admission refusal point; preserve that existing cleanup. The additional key is not cloned until its1 debit succeeds. The unchanged property helper retains its existing consumption/refusal behavior.',
  'saved_work':'20-1=19','saved_accounted_heap':88,'standalone_raw_work':99954,'standalone_remaining':46,
  'independence':'One invocation; no new handoff because the borrowed pair is already in this branch. Keep the existing PI pool handoff8 and getter factory fee unchanged unless the owner-name option is separately selected.'
 },
 'counting_limits':['No new cap or allowance is proposed. Lower startup consumption is the only source of headroom.','No engine, compiler, test, browser, Git command or project Python module was executed for this audit. All candidate numbers are source-derived and unexecuted.','The observed base and source integrity are separate from the prospective fee formulas. No new test has been authored/imported.','No guessed Promise.any/AggregateError cost or pass result is supplied.']
}
assert sum(x['work'] for x in report['pi_owner_name']['new_fixed8_proof'])==8
emit('report.json',report)
# Gross inventory is deliberately separate from the net proposals.
families={'Node':['getRootNode','hasChildNodes','normalize','cloneNode','isEqualNode','isSameNode','compareDocumentPosition','contains'],'PI/CharacterData':['createProcessingInstruction','substringData','appendData','insertData','deleteData','replaceData'],'Text':['splitText'],'Object':['hasOwn']}
inv=[]
for family,names in families.items():
 rows=[{'text':s,'length':len(s),'duplicate_work':8+2*len(s),'duplicate_heap':64+4*len(s)} for s in names]
 inv.append({'family':family,'rows':rows,'gross_work':sum(x['duplicate_work'] for x in rows),'gross_heap':sum(x['duplicate_heap'] for x in rows)})
assert sum(x['gross_work'] for x in inv)==508
assert sum(x['gross_heap'] for x in inv)==1784
emit('remaining-inventory.json',{'scope':'Non-exhaustive bounded paid-text inventory; these gross sums are not net savings. Only PI has a concrete retained-output envelope in report.json.','display_owner_duplicates':inv,'total_gross':{'methods':16,'work':508,'accounted_heap':1784},'already_pooled':['DOM constructor length/name/prototype/constructor; ten PI and two Text factories already borrow the metadata pair.','Reflect pool11 already shares method display text with owner keys; do not count its nine bags as nine fresh metadata-key pairs.','ArrayBuffer TEXT17, DataView TEXT27, TypedArray LITERALS39 and ParentNode metadata pool already amortize literals within each installer.','Microtask producer creates its pair once and passes it to Promise; do not multiply pair savings by Promise bag count.'],'deferred':['Cross-installer pair sharing could remove one36work/168byte materialization per eliminated pool, but producer return/handoff/consumer cleanup charges and exact pool order need a separate proof.','Object.hasOwn still creates a length/name pair, but the preceding DOM pool currently dies at return. No net saving is claimed without producer/consumer ownership fees.','Generic Runtime::intrinsic_function/object_ordered and generic constructor loops allocate repeated string handles without this separate dom_proto_text tariff. No per-key36work saving is inferred from those paths.','The cfg(test)-only node_data_function still materializes keys but is not a startup invocation; its old direct control remains outside the production count.','Runtime Promise callback factories, host-session DONE/print metadata and diagnostic throw metadata are outside raw startup.']})
