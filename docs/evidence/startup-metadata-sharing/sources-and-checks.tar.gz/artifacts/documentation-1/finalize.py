from pathlib import Path
import json,hashlib,difflib
P=Path('/tmp/eris-startup-headroom-plan-1');H=P/'documentation-1';W=P/'worktree'
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check(x):
 a=info(Path(x['path']));assert all(a[k]==x[k] for k in a);return a
ledger=json.loads((P/'root/final-validation.json').read_text());replay=json.loads((P/'root/replay-validation.json').read_text())
assert ledger['status']=='pass' and replay['status']=='pass'
check(ledger['source']);check(ledger['replay_validation']);check(ledger['release_binary']);check(ledger['release_binary']['build_receipt'])
assert ledger['source']==replay['source']==ledger['release_binary']['source_inventory']
source=json.loads(Path(ledger['source']['path']).read_text())['source_sha256']
assert len(source)==1675
for rel,digest in source.items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==digest,rel
bindings=[info(P/'root/final-validation.json'),info(P/'root/replay-validation.json'),info(P/'eris-js-host-final-1.json'),check(ledger['source']),check(ledger['release_binary']['build_receipt'])]
for x in ledger['source_reviews']+[ledger['roster_validation']]:bindings.append(check(x))
build=json.loads(Path(ledger['release_binary']['build_receipt']['path']).read_text());assert build['exit']==0 and build['command'][1]=='+1.88.0' and '--release' in build['command']
buildlog=P/'validation'/build['log'];assert info(buildlog)['sha256']==build['sha256'];bindings.append(info(buildlog))
comparisons=[]
for row in replay['comparisons']:
 for key in ['parent','report','receipt','log']:bindings.append(check(row[key]))
 r=json.loads(Path(row['report']['path']).read_text());p=json.loads(Path(row['parent']['path']).read_text());receipt=json.loads(Path(row['receipt']['path']).read_text())
 assert receipt['exit']==0 and receipt['sha256']==row['log']['sha256']
 assert r['cases']==p['cases'] and r['harness_preflight']==p['harness_preflight']
 assert r['harness_preflight_passed'] is True and r['regressions']==[] and r['improvements']==[]
 assert r['binary_sha256']==ledger['release_binary']['sha256']
 for field in ['runner_policy','runner_policy_sha256','corpus_manifest_sha256','revision','counts','source_files','source_tests','mode_cases']:assert r[field]==p[field],(row['profile'],field)
 assert len(r['cases'])==row['cases'] and len(r['harness_preflight'])==row['controls']
 comparisons.append({'profile':row['profile'],'cases':len(r['cases']),'controls':len(r['harness_preflight']),'counts':r['counts'],'complete_arrays_equal':True})
assert sum(x['cases'] for x in comparisons)==1050 and sum(x['controls'] for x in comparisons)==348
parent=json.loads((P/'source-parent.json').read_text())['source_sha256'];baselines=[x for x in parent if x.startswith('tests/conformance/') and x.endswith('-current.json')]
assert baselines
for rel in baselines:assert source[rel]==parent[rel],rel
p=H/'raw/docs/startup-metadata-sharing.md';s=p.read_text();assert s.count('PENDING_RELEASE_REPLAY_VALIDATION')==1
s=s.replace('PENDING_RELEASE_REPLAY_VALIDATION','''A rebuilt Rust 1.88 release host adapter preserves all **1,050 case-mode records
and 348 harness records** across the four existing Promise profiles. Complete
case and control arrays match the published parent, including existing failed
and unsupported outcomes. All 348 controls verify, with zero regressions,
improvements or baseline changes. This comparison adds no upstream cases.''');p.write_text(s)
p=H/'raw/docs/VALIDATION.md';s=p.read_text();assert s.count('PENDING_VALIDATION_REPLAY_RECORD')==1
s=s.replace('PENDING_VALIDATION_REPLAY_RECORD','''The rebuilt Rust 1.88 release host adapter preserves all 1,050 case and 348
control records across the four existing Promise profiles, including their
failed and unsupported outcomes. All controls verify; no regression,
improvement or baseline change is recorded. See the chapter's linked evidence
manifest and source/check archive.''');p.write_text(s)
state=json.loads((H/'draft-state.json').read_text())
files=[]
for row in state['paths']:
 rel=row['path'];old=(H/'before'/rel).read_bytes();new=(H/'raw'/rel).read_bytes()
 assert b'PENDING_' not in new
 if old:assert (W/rel).read_bytes()==old
 else:assert not (W/rel).exists()
 patch=H/'diffs'/Path(rel+'.patch');patch.write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel if old else '/dev/null',tofile='b/'+rel)))
 files.append({'relative_path':rel,'new_file':not bool(old),'before':info(H/'before'/rel),'raw':info(H/'raw'/rel),'diff':info(patch)})
for x in state['rust_receipt_bindings']+[state['migration_addendum'],state['retained_first_failure']]:bindings.append(check(x))
for path in ['tests-before-1/source-ready.json','tests-before-1/parent-ready.json','tests-before-1/private-ready.json','tests-before-1/layout-parent-review.json','tests-before-1/layout-private-review.json','root/parent-validation.json','root/candidate-observation-1.json','validation/candidate-pi-1.json','validation/candidate-title-1.json','html-plan-review.json']:
 bindings.append(info(P/path))
seen=set();bindings=[x for x in bindings if not(x['path'] in seen or seen.add(x['path']))]
verification={'status':'source/read-only documentation evidence checks complete','source_inventory_matches':1675,'full_source_final_equals_candidate3':(P/'source-final.json').read_bytes()==(P/'source-candidate-3.json').read_bytes(),'replay_comparisons':comparisons,'all_case_records':1050,'all_control_records':348,'unchanged_selected_baseline_files':baselines,'limitations':['No project code, compiler, test or engine execution by documentation author.','Full roster/source independent peers are explicitly bound; documentation author independently recomputed aggregate full-run rows and compared complete replay arrays.','Initial focused observation record retains its historical pending qualification; final documentation derives completed checks from final receipts.','Evidence archive/manifest publication remains root-owned and is not yet claimed verified by this hold.']}
(H/'evidence-checks.json').write_text(json.dumps(verification,indent=2)+'\n')
hold={'status':'sealed final documentation, five exact external patches; no live edits','base':ledger['base'],'files':files,'bindings':bindings,'evidence_checks':info(H/'evidence-checks.json'),'facts':{'startup_work_saved':279,'accounted_heap_saved':1132,'raw_work':99694,'remaining':306,'new_groups':7,'private_operations':84,'default_full':3131,'host_vulkan_full':3485,'exact_replay_cases':1050,'exact_replay_controls':348},'retained_limits':['Existing failed and unsupported replay outcomes remain visible.','First full default library2790pass/1 stale work-ledger failure retained; heap assertion and later targets unreached.','Eight existing migration paths include separately held preselected typed-array cumulative correction.','Architecture-specific absolute accounted allocation qualified as observed Rust1.88 default; typed private formulas remain portable.','Historical chapters unchanged; no API, GPU, CPU-performance or security-completion claim.']}
(H/'source-ready.json').write_text(json.dumps(hold,indent=2)+'\n');print(json.dumps(info(H/'source-ready.json'),indent=2))
