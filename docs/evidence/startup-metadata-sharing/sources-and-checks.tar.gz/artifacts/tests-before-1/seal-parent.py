from pathlib import Path
import hashlib,json,difflib
P=Path('/tmp/eris-startup-headroom-plan-1'); H=P/'tests-before-1'; W=P/'worktree'
def info(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,x):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(x,indent=2)+'\n')
seal=json.loads((P/'source-ready.json').read_text())
for x in seal['payloads']+[seal['root_selection']]:
 assert info(Path(x['path']))==x
bindings=json.loads((P/'source-bindings.json').read_text())
for x in bindings['source_files']:
 a=info(W/x['path']);assert a['bytes']==x['bytes'] and a['sha256']==x['sha256']
rows=json.loads((P/'report.json').read_text())['pi_owner_name']['case_rows']
assert sum(x['removed_owner_text_work'] for x in rows)-len(rows)==200
assert sum(x['removed_owner_text_heap'] for x in rows)==708
assert 2*(36-2)-8+200+20-1==279
assert 2*(88+80)+708+88==1132
write(P/'html-plan-review.json',{'status':'clear','scope':'Independent source-only selected clone1/title/length accounting and ownership review; no execution or implementation approval.','selected_hold':info(P/'source-ready.json'),'checks':['All bound source bytes equal current published-parent worktree.','Existing JsString is an immutable Rc<[u16]> handle; selected one paid retain introduces no loop/map lookup/heap storage. PropertyKey and tuple are moves.','Existing bag/display/metadata/Native admissions remain ordered; four unused accessor display keys must be promptly discarded and six method owner keys consumed.','Title two borrowed-key clones retain separate mutable bags and distinct Native values; selected installer handoff8 precedes old4.','CharacterData.length reuses exact pooled length payload, not get length display.','Seven explicit old migration paths retain isolated neighboring fees and old IDs/caps.'],'source_equations':{'PI':{'removed_text_work':210,'paid_retains':10,'saved_work':200,'saved_heap':708},'title':{'factory_old':116,'factory_new':82,'handoff':8,'saved_work':60,'saved_heap':336},'length':{'saved_work':19,'saved_heap':88},'combined':{'saved_work':279,'saved_heap':1132,'raw_work':99694,'remaining':306}},'limitations':['No measured absolute heap or instruction/performance claim.','Future AggregateError/Promise.any installer fit is outside this selected savings proof.','New permanent tests are separate; production source review remains required.']})
rel='src/script/processing_instruction.rs'; old=(W/rel).read_bytes();append=b'\n#[cfg(test)]\nmod display_key_tests;\n';new=old+append
for stem,b in [('before',old),('raw',new)]:
 p=H/'parent-registration'/stem/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
p=H/'parent-registration'/'registration-append.txt';p.write_bytes(append)
p=H/'parent-registration'/'registration.patch';p.write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
module=H/'raw/src/script/processing_instruction/display_key_tests.rs'
groups=['retained_display_keys_share_six_owner_names_and_the_character_data_length_key','title_borrowed_metadata_keys_preserve_two_distinct_accessor_bags','startup_headroom_raw_observation_precedes_the_frozen_99694_work_witness']
write(H/'parent-oracle.json',{'groups':groups,'parent_api_eligible':True,'expected_parent':{'pass':0,'fail':3,'reachability':['PI: all ten metadata/identity and CharacterData descriptor checks precede expected first createProcessingInstruction map/display pointer mismatch. Later pointer rows unreached.','Title: both Native identities and metadata bags precede expected getter length pointer mismatch. Remaining sharing rows unreached.','Raw: observation and unchanged count/cleanliness checks precede expected99973 versus99694 mismatch; later306 assertion unreached.']},'expected_candidate':'All three groups pass; no execution observed by author.','raw_observation':'Print raw_work, remaining, allocated, objects, physical capacity, globals, natives and prototypes before new work assertion. Same test supports same-ABI parent/candidate allocated delta1132 without guessed absolute heap.','scope':'Existing broad public semantic suites retained; these controls add internal immutable payload and startup saving witnesses.'})
write(H/'parent-bindings.json',{'base':bindings['later_published_profile_commit'],'selected_plan':info(P/'source-ready.json'),'source_parent':info(P/'source-parent.json'),'source_inputs':[info(W/p) for p in ['src/script.rs','src/js_string.rs','src/script/symbols.rs','src/script/processing_instruction.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/document_title.rs','src/script/document_title/tests.rs','src/script/dom_prototypes.rs']],'review':info(P/'html-plan-review.json')})
payload=[module,H/'parent-oracle.json',H/'parent-bindings.json']+sorted((H/'parent-registration').rglob('*'))
payload=[p for p in payload if p.is_file()]
write(H/'parent-ready.json',{'status':'frozen parent-compatible tests, source-only, unexecuted','base':bindings['later_published_profile_commit'],'new_groups':3,'imports':[{'path':'src/script/processing_instruction/display_key_tests.rs','raw':info(module)},{'path':rel,'before':info(H/'parent-registration/before'/rel),'raw':info(H/'parent-registration/raw'/rel)}],'payloads':[info(p) for p in payload]})
print(json.dumps({'plan_review':info(P/'html-plan-review.json'),'parent_hold':info(H/'parent-ready.json')},indent=2))
