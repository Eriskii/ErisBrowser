    /// Prove all-covered original Box candidates and exact raw Rect clipping.
    /// Inputs are already translated. The immutable proof exposes the full
    /// outer candidate count, before an image's later no-repeat narrowing.
    /// No pixel scan, payload allocation or work debit occurs here.
    pub(crate) fn rect_proof(
        width: u32,
        height: u32,
        outer: RoundedBox,
        cutout: Option<RoundedBox>,
        clip: Rect,
    ) -> Result<Option<BoxRectProof>, BoxMaskError> {
        // Keep invalid input observable before empty/ineligible early returns.
        if width == 0
            || height == 0
            || width > Profile::Native.max_width()
            || height > Profile::Native.max_height()
            || !outer.valid()
            || cutout.is_some_and(|shape| !shape.valid())
            || ![clip.x, clip.y, clip.width, clip.height]
                .into_iter()
                .all(|v| v.is_finite() && f64::from(v).abs() <= MAX_COORDINATE)
        {
            return Err(BoxMaskError::InvalidGeometry);
        }
        if cutout.is_some()
            || outer.radii.iter().any(|[rx, ry]| *rx != 0.0 && *ry != 0.0)
            || ![
                outer.rect.x,
                outer.rect.y,
                outer.rect.width,
                outer.rect.height,
            ]
            .into_iter()
            .all(|v| v.fract() == 0.0)
        {
            return Ok(None);
        }
        if outer.rect.width <= 0.0
            || outer.rect.height <= 0.0
            || clip.width <= 0.0
            || clip.height <= 0.0
        {
            return BoxRectProof::new(0).map(Some);
        }
        // Preserve the original Canvas/core f32 candidate-window expression.
        let visible = outer.rect.intersect(clip);
        if visible.width <= 0.0 || visible.height <= 0.0 {
            return BoxRectProof::new(0).map(Some);
        }
        let x0 = visible.x.floor().max(clip.x.ceil()).max(0.0) as i32;
        let y0 = visible.y.floor().max(clip.y.ceil()).max(0.0) as i32;
        let x1 = (visible.x + visible.width).ceil().min(width as f32) as i32;
        let y1 = (visible.y + visible.height).ceil().min(height as f32) as i32;
        if x1 <= x0 || y1 <= y0 {
            return BoxRectProof::new(0).map(Some);
        }
        // Box always blends through its mask. Opaque root Rect omits blend's
        // upper clip check, so prove that all candidate cells pass it anyway.
        // The integer shape bounds also prove all sixteen samples are inside.
        if f64::from(x0) < f64::from(outer.rect.x)
            || f64::from(y0) < f64::from(outer.rect.y)
            || f64::from(x1) > f64::from(outer.rect.x) + f64::from(outer.rect.width)
            || f64::from(y1) > f64::from(outer.rect.y) + f64::from(outer.rect.height)
            || x1 as f32 > (clip.x + clip.width).ceil()
            || y1 as f32 > (clip.y + clip.height).ceil()
        {
            return Ok(None);
        }
        let pixels = ((x1 - x0) as u64)
            .checked_mul((y1 - y0) as u64)
            .ok_or(BoxMaskError::WorkLimit)?;
        BoxRectProof::new(pixels).map(Some)
    }

