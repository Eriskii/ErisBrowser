    /// Preserve the Color route's conservative software tariff, 8 + 3P.
    /// The caller prepays this result before retaining the selected route.
    pub(crate) fn rect_work(
        width: u32,
        height: u32,
        outer: RoundedBox,
        cutout: Option<RoundedBox>,
        clip: Rect,
    ) -> Result<Option<u64>, BoxMaskError> {
        Self::rect_proof(width, height, outer, cutout, clip)?
            .map(|proof| {
                proof.classification_work()
                    .checked_add(proof.candidate_pixels())
                    .ok_or(BoxMaskError::WorkLimit)
            })
            .transpose()
    }

