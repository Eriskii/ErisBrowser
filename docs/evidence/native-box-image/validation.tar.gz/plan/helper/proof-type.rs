/// Validated all-covered candidate metadata, before paint-specific funding.
/// Construction stays private; no caller can invent a proof by filling fields.
pub(crate) struct BoxRectProof {
    candidate_pixels: u64,
    classification_work: u64,
}

impl BoxRectProof {
    fn new(candidate_pixels: u64) -> Result<Self, BoxMaskError> {
        let classification_work = if candidate_pixels == 0 {
            0
        } else {
            candidate_pixels
                .checked_mul(2)
                .and_then(|work| work.checked_add(SETUP_WORK))
                .ok_or(BoxMaskError::WorkLimit)?
        };
        Ok(Self { candidate_pixels, classification_work })
    }

    pub(crate) fn candidate_pixels(&self) -> u64 {
        self.candidate_pixels
    }

    pub(crate) fn classification_work(&self) -> u64 {
        self.classification_work
    }
}

