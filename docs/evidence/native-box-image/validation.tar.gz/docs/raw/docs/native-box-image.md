# Image boxes on Vulkan

Native `BoxPaint::Image` can use the existing raster-background lookup tables
and Vulkan image kernel. This admits selected padding/content clips from
`background-origin` and `background-clip` when their painted shape meets the
same geometry proof as [rectangular color fills](native-box-fastpath.md).

Each corner must have a zero horizontal or vertical radius, there must be no
cutout, and the outer rectangle must have integer coordinates and dimensions
after document or fixed-coordinate translation. A bounded check proves full
coverage for its candidate pixels and compatibility with the active clip.
Fractional clips may pass this proof. The positioning tile may still have
fractional origins or positive fractional dimensions; it is independent of the
selected painting box.

The structural pass validates raw shapes, tiles and image keys before a
separate metadata eligibility pass examines every image box. Unsupported
shapes refuse the whole scene even when empty, hidden, missing their source,
or enclosed by zero opacity. Rounded/fractional outer shapes, cutouts and
`BoxPaint::LinearGradient` retain fallback. Primitive and text-aware Probe
planners still refuse box decorations.

Admitted commands retain their original rectangle and tile. Existing scope
handling applies document/fixed offsets once; center sampling, repeat and
no-repeat phase, source alpha, paint order and isolated opacity groups stay on
the existing image path. The implementation adds no shader, worker protocol,
image decoding or fetching authority.

## Resource accounting

The reservation is one checked, atomic debit of `B + T + L`:

- `B` is zero for an empty outer candidate window; otherwise `8 + 2P`, where
  `P` counts the original box candidates before no-repeat restriction.
- `T` is the existing background-image loop allowance: zero for an empty image
  window, otherwise `8 + Q * (3 + repeated_axes)`.
- `L` is the existing per-axis lookup allowance: zero for an empty final
  window, otherwise `8 + (3 + repeat_x) * W + (3 + repeat_y) * H`.

Repeat flags are zero or one. These are conservative policy units, not CPU
instruction measurements. Missing, transparent and suppressed sources retain
the reservation. A disjoint no-repeat tile can eliminate `T` and `L` while
leaving `B` intact. No mask coverage, mask rows or destination bitmap is allocated.

Box images borrow keys and share loaded sources by allocation identity with
ordinary images and raster backgrounds. Existing key, source-entry, RGBA,
lookup, command, CPU and GPU limits remain unchanged; all retained rasters
still receive source validation. Missing keys emit no image draw and keep the
existing missing-image count. `box_background_images` counts admitted routes,
including missing or empty ones; `box_loop_work` includes their complete
`B + T + L` reservation alongside existing color-box work.

## Validation

Validation is pending. Six independently frozen image fixtures are planned for
both output formats: 12 offscreen frames and 2,144 active bytes per adapter.
They cover four repeat modes, fractional tiles and clips, alpha and nested
opacity, fixed/document restoration, empty no-repeat and missing-source cases,
and a cached local Page with padding-box positioning and content-box clipping.
The retained ten-case mask checker and five-case color-rectangle checker keep
their literal pixels and completion protocols. No execution, acquired-window
or performance result is claimed here yet.

The final [summary](evidence/native-box-image/summary.json) and
[archive](evidence/native-box-image/validation.tar.gz) will bind the selected
source, literals, reviews and actual receipts.
