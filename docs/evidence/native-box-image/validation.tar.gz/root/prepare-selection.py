from pathlib import Path
import hashlib,json,re,subprocess,sys
U=Path('/tmp/eris-native-box-image-1');W=U/'worktree'
def binding(p):
 p=Path(p)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def ub(s):return binding(U/s)
source=ub('compiled-source-3.json')
roles={'full_native':'full-native-2','full_default':'full-default-2','clippy_native_msrv':'clippy-native-msrv-2','clippy_native_current':'clippy-native-current-2','clippy_default_current':'clippy-default-current-1','format':'format-root-2','format_probe':'format-probe-2','clippy_probe_current':'clippy-probe-current-1','probe_cpu':'probe-cpu-2','browser_build':'browser-build-1','browser_strip':'browser-strip-1','reftests':'reftests-final-1','parent_images':'parent-images-1'}
checks=[]
for role,label in roles.items():
 path=U/'validation'/f'{label}.json';r=json.loads(path.read_text());log=(path.parent/r['log']).read_text()
 assert r['exit']==0 and hashlib.sha256(log.encode()).hexdigest()==r['sha256']
 row={'role':role,'receipt':binding(path),'command':r['command'],'exit':r['exit'],'final':True,'source_sha256':source['sha256']}
 values=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
 if values:row['rust']={'rows':len(values),'passed':sum(int(v[1]) for v in values),'failed':sum(int(v[2]) for v in values),'ignored':sum(int(v[3]) for v in values)}
 checks.append(row)
changed=set()
for cmd in [['git','diff','--name-only','-z','HEAD'],['git','ls-files','--others','--exclude-standard','-z']]:changed.update(subprocess.check_output(cmd,cwd=W).decode().split('\0'))
changed.discard('')
published=[{**binding(W/name),'path':name} for name in sorted(changed)]
docs=Path(sys.argv[1])
review_names=['root/native-review.json','tests/layout-review.json','tests/key-preflight-correction-1/layout-review.json','root/script-ci-review-2.json','gpu/layout-review.json','root/parent-image-comparison-1.json','root/publisher-root-review.json','root/publisher-layout-review.json']
gpu={}
for group,tag,record in [('native_box','native-box','mask'),('box_rect','box-rect','rect'),('box_image','box-image','image')]:
 gpu[group]={'binary':ub(f'gpu-{record}-binary-1.json'),'build':ub('validation/gpu-build-1.json'),'list':ub(f'validation/gpu-{tag}-list-1.json'),'adapters':[{'index':i,'receipt':ub(f'validation/gpu-{tag}-adapter-{i}-1.json')} for i in range(3)],'loader_environment':json.loads((U/f'validation/gpu-{tag}-list-1.json').read_text())['command'][1]}
s={'source':source,'source_count':len(json.loads((U/'compiled-source-3.json').read_text())['source_sha256']),'checks':checks,'browser':ub('browser-final-1.json'),'report':ub('reftests-final-1/report.json'),'gpu':gpu,'docs':binding(docs),'documentation_review':ub('root/documentation-review.json'),'reviews':[ub(n) for n in review_names],'published_files':published,'archive_files':[ub('parent-source.json'),ub('run-check.py'),ub('run-tool.py'),ub('snapshot-source.py')]}
with (U/'publication-selection.json').open('x') as f:json.dump(s,f,indent=2);f.write('\n')
print(json.dumps({'selection':ub('publication-selection.json'),'files':len(published)},indent=2))
