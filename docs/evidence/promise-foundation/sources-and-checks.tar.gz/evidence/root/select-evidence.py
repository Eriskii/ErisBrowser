from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent

def bind(path):
 data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

inventory=root/'source-2.json';sources=json.loads(inventory.read_text())['source_sha256']
assert len(sources)==783
for name,sha in sources.items(): assert bind(root/'worktree'/name)['sha256']==sha,name
checks={}
for label in ['native-full-2','default-full-1','strict-msrv-2','strict-current-2','actual-layout-current-1','format-check-1','browser-final-build-1','references-final-1']:
 r=json.loads((root/'validation'/(label+'.json')).read_text());assert r['exit']==0
 assert bind(root/'validation'/r['log'])['sha256']==r['sha256'];checks[label]=r
for name in ['final-source-review.json','validation-review.json']:
 assert json.loads((root/'root'/name).read_text())['status'] in ('clear','clear_source_only')
totals=json.loads((root/'root/full-suite-totals.json').read_text())
assert totals['native-full-2']['passed']==3148 and totals['default-full-1']['passed']==2844
parent_ci=json.loads((root/'validation/parent-ci-final-1.log').read_text())
assert parent_ci['headSha']=='2d103b4f2dedc438e0cc53652de43ac8dc11f146'
assert parent_ci['conclusion']=='success' and len(parent_ci['jobs'])==9
assert all(j['conclusion']=='success' for j in parent_ci['jobs'])
reference=json.loads((root/'root/reference-comparison-final.json').read_text())
assert reference['status']=='pass' and reference['pairs']==102 and reference['unchanged_pngs']==204
artifacts={}
for directory in ['plans','integration','production-draft','production-draft-2','production-draft-script','production-draft-layout','validation','validation-review','reftests-final','root']:
 for path in sorted((root/directory).rglob('*')):
  if path.is_file():
   assert not path.is_symlink()
   if path.name in ('selection-final.json','publication-verification.json'):continue
   assert '__pycache__' not in path.parts
   artifacts[str(path.relative_to(root))]=bind(path)
for path in sorted(root.glob('*')):
 if path.is_file() and path.suffix in ('.json','.py'):artifacts[path.name]=bind(path)
for name in ['README.md','docs/ROADMAP.md','docs/COMPATIBILITY.md','docs/promise-foundation.md']:
 artifacts['documentation/'+name]=bind(root/'worktree'/name)
selection={'source_inventory':bind(inventory),'artifacts':artifacts,'max_uncompressed_bytes':128*1024*1024,'claims':{
 'base':parent_ci['headSha'],
 'scope':'Custom Promise construction, then, resolve, reject, species/generic capabilities and thenable adoption share the existing bounded microtask FIFO.',
 'source_inputs':783,
 'new_test_groups':{'public_semantics':16,'private_resource_boundaries':18,'installer':3,'layout_mirror':1,'actual_type_layout':1,'page':1,'confined_worker':1,'total':41},
 'parent_baselines':json.loads((root/'root/baseline-result.json').read_text()),
 'history':{'prebaseline_addition':'One independently held species-constructor reentrancy case appended to the original15 semantic groups; original23 rows retained byte-exact.',
  'source_corrections':['Installer visibility widened only to crate::script before implementation import.','Pre-seal private helper visibility/import seams corrected before compiler execution.','First complete native suite passed3148; Rust1.98 strict lint then required the equivalent div_ceil expression. All final checks bind source2; original failed lint and source1 retained.'],
  'old_test_migrations':{'count':5,'paths':['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/microtask_budget_tests.rs','src/script/dom_bindings/identity_tests.rs'],'scope':'Explicit new bootstrap work/heap/counts/global presence and typed QueueJob callback wrappers. Existing callback work cuts and unrelated assertions remain unchanged.'},
  'source_inventory_sha256':bind(inventory)['sha256']},
 'checks':checks,
 'full_suite_totals':{key:{field:val[field] for field in ['passed','failed','ignored','result_rows','log_sha256']} for key,val in totals.items()},
 'references':{key:reference[key] for key in ['pairs','unchanged_pngs','parent_archive_sha256','report_sha256']},
 'browser':json.loads((root/'root/final-browser.json').read_text()),
 'parent_ci':{'head':parent_ci['headSha'],'url':parent_ci['url'],'conclusion':'success','jobs':9,'raw':bind(root/'validation/parent-ci-final-1.log')},
 'resource_policy':{'bootstrap_work_allowance':100000,'parent_raw_bootstrap_work':98875,'raw_bootstrap_work':99805,'raw_bootstrap_remaining':195,'installer_work':930,'author_work':100000,'cumulative_heap_bytes':8388608,'unchanged_numeric_caps':True,'objects':747,'native_registry':299,'prototypes':25,'globals':212,'state_bytes_x86_64':192,'queue_entry_bytes_x86_64':24,'append_only_private_ids':True,'fatal_suspension':True,'measurement_scope':'Logical prepaid charges, exact admission cuts and typed layouts; no physical allocator or processor-work guarantee.'},
 'integration':{'literal_frames':12,'literal_rgba_bytes':1802496,'successful_layout_or_render_calls':20,'initial_title':'ESQTFMRD','clicked_title':'ESQTFMRDAPMTRB','render_scope':'CPU Canvas and CPU interpretation of packed native plans; no acquired GPU surface observation.'},
 'limits':['Authored local tests, not imported WPT/Test262 conformance results.','catch/finally, combinators, async/await, fetch, rejection notifications and multiple realms remain absent.','Append-only bounded arenas; no added garbage collector.','No Chromium performance comparison, full web compatibility, or production-security claim.','Existing Vulkan backend unchanged; no new GPU claim.','Build caches reused; times are not cold-build measurements.']}}
with (root/'root/selection-final.json').open('x') as out:json.dump(selection,out,indent=2);out.write('\n')
print(json.dumps({'sources':len(sources),'artifacts':len(artifacts)}))
