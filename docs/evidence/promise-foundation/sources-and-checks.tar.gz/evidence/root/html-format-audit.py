from pathlib import Path
import json,hashlib,re,difflib
A=Path('/tmp/eris-promise-1');P=Path('/tmp/eris-promise-plan-1');W=A/'worktree'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tokens(s):
 out=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   n=s.find('\n',i);i=len(s) if n<0 else n+1;continue
  if s.startswith('/*',i):
   depth=1;i+=2
   while depth:
    if s.startswith('/*',i):depth+=1;i+=2
    elif s.startswith('*/',i):depth-=1;i+=2
    else:i+=1
    assert i<=len(s)
   continue
  m=re.compile(r'(?:br|cr|r)(#*)"').match(s,i)
  if m:
   end=s.find('"'+m[1],i+len(m[0]));assert end>=0;end+=1+len(m[1]);out.append(s[i:end]);i=end;continue
  m=re.compile(r'(?:b|c)?"').match(s,i)
  if m:
   end=i+len(m[0])
   while s[end]!='"':end+=2 if s[end]=='\\' else 1
   end+=1;out.append(s[i:end]);i=end;continue
  m=re.compile(r"(?:b)?'(?:\\u\{[0-9A-Fa-f_]+\}|\\x[0-9A-Fa-f]{2}|\\.|[^'\\\n])'").match(s,i)
  if m:out.append(m[0]);i+=len(m[0]);continue
  m=re.compile(r'(?:r#)?[A-Za-z_0-9]+').match(s,i)
  if m:out.append(m[0]);i+=len(m[0]);continue
  out.append(s[i]);i+=1
 return out
sources={};holds=[]
def ingest(path,style='files'):
 path=Path(path);x=json.loads(path.read_text());holds.append(str(path))
 for f in x[style]:
  b=f.get('raw',f.get('file',f.get('source')));t=f['target']
  if t in sources:assert sources[t]==b['path'],(t,sources[t],b['path'])
  sources[t]=b['path']
for h in [A/'production-draft-2/source-ready.json',A/'production-draft-script/source-ready.json',A/'production-draft-layout/source-ready.json',P/'migrations-before-1/source-ready.json',A/'integration/source-ready.json']:ingest(h)
sources['src/script/promise_semantic_tests.rs']=str(P/'semantic-tests-2/raw/src/script/promise_semantic_tests.rs');holds.append(str(P/'semantic-tests-2/source-ready.json'))
sources['src/script/promise_layout_probe.rs']=str(P/'runtime-tests-before-1/raw/src/script/promise_layout_probe.rs')
sources['src/script/promises/quota_tests.rs']=str(P/'runtime-tests-before-1/raw/src/script/promises/quota_tests.rs');holds.append(str(P/'runtime-tests-before-1/source-ready.json'))
sources['src/script/promises/quota_more_tests.rs']=str(P/'runtime-tests-before-2/raw/src/script/promises/quota_more_tests.rs');holds.append(str(P/'runtime-tests-before-2/source-ready.json'))
x=json.loads((A/'source-2.json').read_text());old=json.loads(Path('/tmp/eris-pi-key-cache-1/source-1.json').read_text())['source_sha256'];new=x['source_sha256'];assert len(new)==783
for t,h in new.items():assert sha(W/t)==h,t
changed={t for t,h in new.items() if old.get(t)!=h};assert changed==set(sources)|{'tests/worker.rs'},(changed-set(sources),set(sources)-changed)
rows=[]
for t,src in sorted(sources.items()):
 before=Path(src).read_bytes();after=(W/t).read_bytes();r={'target':t,'held_path':src,'held_sha256':sha(src),'live_sha256':sha(W/t),'byte_exact':before==after}
 if not r['byte_exact']:
  aa=tokens(before.decode());bb=tokens(after.decode());r['token_diffs']=[]
  start=0
  while start<min(len(aa),len(bb)) and aa[start]==bb[start]:start+=1
  enda,endb=len(aa),len(bb)
  while enda>start and endb>start and aa[enda-1]==bb[endb-1]:enda-=1;endb-=1
  for op,i,j,k,l in difflib.SequenceMatcher(a=aa[start:enda],b=bb[start:endb],autojunk=True).get_opcodes():
   i+=start;j+=start;k+=start;l+=start
   if op!='equal':r['token_diffs'].append({'op':op,'before':aa[i:j],'after':bb[k:l],'context_before':aa[max(0,i-6):i],'context_after':aa[j:j+6]})
  # Every literal token is preserved as text, independent of comma/layout normalization.
  lit=lambda ts:[v for v in ts if '"' in v or re.fullmatch(r"(?:b)?'(?:\\.|.)'",v)]
  r['literal_tokens_exact']=lit(aa)==lit(bb)
 rows.append(r)
 print('completed',t,flush=True)
result={'snapshot':str(A/'source-2.json'),'snapshot_sha256':sha(A/'source-2.json'),'inventory_verified':len(new),'changed_count':len(changed),'holds':holds,'comparisons':rows}
q=A/'root/html-format-comparison.json';q.write_text(json.dumps(result,indent=2)+'\n')
print('inventory',len(new),'changed',len(changed),'held',len(rows))
for r in rows:
 print(r['target'],'BYTE_EXACT' if r['byte_exact'] else 'TOKEN_DIFFS '+str(len(r['token_diffs']))+' LITERALS_EXACT '+str(r['literal_tokens_exact']))
 if not r['byte_exact']:
  for d in r['token_diffs']:
   if d['before']!=[','] and d['after']!=[',']:print(json.dumps(d))
print('retained',q)
