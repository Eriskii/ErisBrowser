from pathlib import Path
import hashlib,json,re
A=Path('/tmp/eris-promise-1'); P=Path('/tmp/eris-promise-plan-1'); W=A/'worktree'
def binding(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
checked={}
def verify(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and x['path'].startswith('/') and '/worktree/' not in x['path'] and 'sha256' in x:
   got=binding(x['path']);assert got['sha256']==x['sha256'],x['path']
   if 'bytes' in x:assert got['bytes']==x['bytes'],x['path']
   checked[x['path']]=got
  for y in x.values():verify(y)
 elif isinstance(x,list):
  for y in x:verify(y)
s1=read(A/'source-1.json');s2=read(A/'source-2.json');old=read('/tmp/eris-pi-key-cache-1/source-1.json')
a=s1['source_sha256'];b=s2['source_sha256'];base=old['source_sha256']
assert set(a)==set(b) and len(b)==783
assert [k for k in b if a[k]!=b[k]]==['src/script/promises.rs']
for t,h in b.items():assert binding(W/t)['sha256']==h,t
correction=read(A/'root/corrections-1/correction.json');verify(correction)
assert correction['before']['sha256']==a['src/script/promises.rs']
assert correction['after']['sha256']==b['src/script/promises.rs']
before=Path(correction['before']['path']).read_text();after=Path(correction['after']['path']).read_text()
manual='width / size_of::<Value>() + usize::from(width % size_of::<Value>() != 0)'
assert before.count(manual)==1 and before.replace(manual,'width.div_ceil(size_of::<Value>())')==after
cmp=read(A/'root/html-format-comparison.json');assert cmp['snapshot_sha256']==binding(A/'source-2.json')['sha256']
for h in cmp['holds']:verify(read(h))
verify(read(A/'integration/tests-before/oracles.json'))
assert all(r['byte_exact'] or r['literal_tokens_exact'] for r in cmp['comparisons'])
for r in cmp['comparisons']:
 assert binding(r['held_path'])['sha256']==r['held_sha256']
 assert b[r['target']]==r['live_sha256']
parentworker=Path('/tmp/eris-pi-key-cache-1/worktree/tests/worker.rs');assert binding(parentworker)['sha256']==base['tests/worker.rs']
registration='\n#[path = "worker/promise_foundation.rs"]\nmod promise_foundation;\n'
assert (W/'tests/worker.rs').read_text()==parentworker.read_text()+registration
roster=[]
for rel,count,kind in [('src/script/promise_semantic_tests.rs',16,'public_runtime'),('src/script/promise_layout_probe.rs',1,'test_only_mirror'),('src/script/promises/quota_tests.rs',8,'private_quota'),('src/script/promises/quota_more_tests.rs',10,'private_quota'),('src/script/promises/install_tests.rs',3,'installer'),('src/script/promises/layout_tests.rs',1,'actual_type_layout'),('tests/promise_foundation.rs',1,'Page'),('tests/worker/promise_foundation.rs',1,'confined_worker')]:
 text=(W/rel).read_text();names=re.findall(r'#\[test\](?:(?:\s*#\[[^\n]+\])|\s)*fn\s+(\w+)',text);assert len(names)==count
 roster.append({'target':rel,'kind':kind,'count':count,'names':names,'binding':binding(W/rel)})
assert sum(x['count'] for x in roster)==41
script=(W/'src/script.rs').read_text();core=(W/'src/script/promises.rs').read_text()
for name in ['promise_layout_probe','promise_semantic_tests']:assert '#[cfg(test)]\nmod '+name+';' in script
for name in ['quota_tests','quota_more_tests','install_tests','layout_tests']:assert '#[cfg(test)]\nmod '+name+';' in core
assert '\nmod promises;' in script
assert '#[cfg(target_pointer_width = "64")]\n#[test]' in (W/'src/script/promises/layout_tests.rs').read_text()
assert '#[ignore = "requires Linux Landlock ABI 6; launches a confined renderer and broker"]' in (W/'tests/worker/promise_foundation.rs').read_text()
assert 'autotests = false' not in (W/'Cargo.toml').read_text()
peerpaths=[A/'production-draft/html-review.json',A/'production-draft-2/html-review.json',A/'production-draft-script/html-review.json',A/'production-draft-layout/script-review.json',P/'migrations-before-1/html-review.json',P/'semantic-tests-1/html-review.json',P/'semantic-tests-2/script-review.json',P/'runtime-tests-before-1/html-review.json',P/'runtime-tests-before-2/html-review.json',A/'integration/layout-review.json']
# Verify selected peer-held source bindings while preserving the peers' scope statements.
for p in peerpaths:verify(read(p))
changed=sorted(t for t,h in b.items() if base.get(t)!=h)
added=sorted(set(b)-set(base));modified=sorted(t for t in changed if t in base)
assert len(changed)==26 and len(added)==14 and len(modified)==12 and not(set(base)-set(b))
frames=read(A/'integration/tests-before/oracles.json')['frames'];assert len(frames)==12
out={
 'status':'clear_source_only', 'reviewer':'html_css',
 'scope':'Final source-2 preservation, selected source1-to-source2 correction, formatting of independently reviewed production and test holds, exact registration roster and frozen literals. This receipt makes no new execution or validation-success claim.',
 'final_source':binding(A/'source-2.json'), 'previous_source':binding(A/'source-1.json'), 'parent_source':binding('/tmp/eris-pi-key-cache-1/source-1.json'),
 'base_commit':s2['base'], 'inventory':{'live_inputs_rehashed':783,'changed_count':26,'added':added,'modified':modified,'removed':[]},
 'selected_holds':[binding(h) for h in cmp['holds']],
 'prior_source_peers':[binding(p) for p in peerpaths],
 'mechanical_correction':{'hold':binding(A/'root/corrections-1/correction.json'),'before':correction['before'],'after':correction['after'],'exact_source_delta':['src/script/promises.rs'],'proof':'For d = size_of::<Value>() > 0, floor(width/d) plus one iff the remainder is nonzero equals width.div_ceil(d). The explicit quotient sum cannot overflow: d=1 has zero remainder, and d>1 leaves quotient below usize::MAX. This exact replacement changes no tariff, reserve target, cap, state, test or oracle. The initial strict-current failure remains recorded by the bound correction hold.'},
 'formatting':{'comparison':binding(A/'root/html-format-comparison.json'),'inert_scanner':binding(A/'root/html-format-audit.py'),'held_paths_compared':25,'method':'Byte comparison, source lexical comparison preserving full raw/quoted literal tokens, and manual review of all non-comma token deltas. This is a source comparison, not a Rust parser/compiler execution.','allowed_changes':['Whitespace and line wrapping.','Trailing commas in arguments, tuples, patterns, literals and arrays.','Use and module sorting with unchanged cfg attributes; semantics remains a production module, four core test modules remain cfg(test).','Equivalent braces around single-expression closures/match arms, including return Err arm semicolon.','Separately held source2 div_ceil correction.'],'result':'No other source or expected-value differences found; all quoted script/error/name/descriptor literals remain exact.'},
 'registration':{'new_groups':41,'groups':roster,'worker_registration':registration,'worker_parent':binding(parentworker),'worker_live':binding(W/'tests/worker.rs'),'controls':['Runtime public tests and layout probe retain cfg(test) registrations in script.rs.','Private quota8+10 and installer3 retain cfg(test) registrations in promises.rs.','Actual production type group is cfg(test) and 64-bit; mirror remains the separate original control.','Top-level Page test follows unchanged Cargo autotest discovery.','Confined worker remains explicitly ignored with its original prerequisite annotation; this receipt does not claim it ran.','A root-reported focused count42 includes one pre-existing migrated PI raw-bootstrap group. Exactly41 groups are new.']},
 'preserved_expectations':{'semantic_groups':16,'semantic_rows':24,'semantic_note':'All original23 rows and the additive CSH4R5 species reentrancy row retain their exact source literal tokens.','quota_groups':18,'installer_groups':3,'old_migrations':{'hold':binding(P/'migrations-before-1/source-ready.json'),'count':5,'correspondence':['Bootstrap remaining work1125→195 and objects741→747.','Typed-array bootstrap adds selected Promise state,6 metadata objects and helper heap; work930 and global212.','Cached PI raw-bootstrap cut98875→99805 with same descriptor/arity controls.','Microtask queue changes Value handle wrapper to same-size QueueJob, preserving its existing callback/report fees.','DOM identity count741→747; no existing behavioral expectations weakened.']},'integration_files_byte_exact':True,'oracle_hold':binding(A/'integration/tests-before/oracles.json'),'rgba_files_rehashed':len(frames),'rgba_bindings':[x['rgba'] for x in frames]},
 'verified_nested_bindings':len(checked), 'remaining_findings':[],
 'limits':'Read/hash/diff and external receipt writes only. No project import, formatter, compiler, test, browser, git command or live source mutation. Root owns all actual results and publication. Core algorithm review is separately attributed to the bound Script peer; this receipt confirms its selected source survived integration.'}
q=A/'root/final-source-review.json';assert not q.exists();q.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(binding(q)));print('nested bindings',len(checked),'roster',sum(r['count'] for r in roster))
