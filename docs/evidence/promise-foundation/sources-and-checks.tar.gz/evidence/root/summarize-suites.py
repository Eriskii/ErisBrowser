"""Summarize complete Cargo logs and retain their per-target test identities."""
import hashlib
import json
import re
import sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
summary = {}
for label in sys.argv[1:]:
    record = json.loads((root / 'validation' / (label + '.json')).read_text())
    assert record['exit'] == 0, label
    log = root / 'validation' / record['log']
    assert hashlib.sha256(log.read_bytes()).hexdigest() == record['sha256']
    target = None
    roster = []
    rows = []
    for line in log.read_text().splitlines():
        match = re.match(r'\s+Running (?:unittests )?(\S+) \(', line)
        if match:
            target = match.group(1)
        elif re.match(r'\s+Doc-tests ', line):
            target = line.strip()
        match = re.match(r'test (\S+) \.\.\. (ok|FAILED|ignored)$', line)
        if match:
            assert target is not None
            roster.append({'target': target, 'test': match.group(1), 'status': match.group(2)})
        match = re.match(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', line)
        if match:
            assert match.group(1) == 'ok'
            counts = [int(x) for x in match.groups()[1:]]
            assert counts[1:] == [0, 0, 0, 0], (label, target, counts)
            rows.append({'target': target, 'passed': counts[0]})
    assert rows and len(roster) == sum(row['passed'] for row in rows)
    assert all(row['status'] == 'ok' for row in roster)
    identities = {(row['target'], row['test']) for row in roster}
    assert len(identities) == len(roster)
    summary[label] = {
        'passed': len(roster), 'failed': 0, 'ignored': 0,
        'result_rows': len(rows), 'per_target': rows,
        'roster': roster, 'log_sha256': record['sha256'],
    }
with (root / 'root/full-suite-totals.json').open('x') as out:
    json.dump(summary, out, indent=2)
    out.write('\n')
print(json.dumps({key: {field: value[field] for field in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for key, value in summary.items()}))
