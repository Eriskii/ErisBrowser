"""Independent inert artifact review; never invokes the project or tools."""
from pathlib import Path
import json,hashlib,re,tarfile
A=Path('/tmp/eris-promise-1');W=A/'worktree';V=A/'validation';R=A/'root'
def bind(p):
 p=Path(p);h=hashlib.sha256()
 with p.open('rb') as f:
  for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
 return {'path':str(p),'bytes':p.stat().st_size,'sha256':h.hexdigest()}
def read(p):return json.loads(Path(p).read_text())
def receipt(label):
 p=V/(label+'.json');r=read(p);log=V/r['log'];assert bind(log)['sha256']==r['sha256'],p
 return r,log
needed=['native-full-2','default-full-1','strict-msrv-2','strict-current-2','actual-layout-current-1','format-check-1','browser-final-build-1']
missing=[str(V/(x+'.json')) for x in needed if not(V/(x+'.json')).exists()]
missing += [str(R/x) for x in ['full-suite-totals.json','final-browser.json','reference-comparison-final.json'] if not(R/x).exists()]
if missing:
 print(json.dumps({'pending':missing}));raise SystemExit(0)
source=read(A/'source-2.json');mapping=source['source_sha256'];assert len(mapping)==783
assert all(bind(W/p)['sha256']==h for p,h in mapping.items())
transition=read(A/'validation-review/source-transition.json');assert transition['source2']==bind(A/'source-2.json')
phase=read(A/'validation-review/phase-1-observations.json')
for row in phase['frozen_test_comparisons']:
 assert bind(row['held']['path'])==row['held']
 assert bind(row['current']['path'])==row['current']
 assert row['literal_tokens_exact']
 if row['unexplained_token_differences']:
  assert row['target']=='src/script/microtask_budget_tests.rs'
  before=Path(row['held']['path']).read_text();after=Path(row['current']['path']).read_text()
  assert before.startswith('//! Private-seam cuts, derived before implementation; no measured callback fees.\nuse super::*;\nuse super::promises::QueueJob;\n')
  assert after.startswith('//! Private-seam cuts, derived before implementation; no measured callback fees.\nuse super::promises::QueueJob;\nuse super::*;\n')
# Full logs, not a tail or a trusted total, provide all per-target identities.
summaries=read(R/'full-suite-totals.json');suite_rows={};suite_rosters={}
for label in ['native-full-2','default-full-1']:
 rec,log=receipt(label);assert rec['exit']==0 and '--include-ignored' in rec['command']
 text=log.read_text();target=None;rows=[];roster=[]
 for line in text.splitlines():
  m=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
  if m:target=m[1]
  elif re.match(r'\s+Doc-tests ',line):target=line.strip()
  m=re.fullmatch(r'test (\S+) \.\.\. (ok|FAILED|ignored)',line)
  if m:assert target;roster.append({'target':target,'test':m[1],'status':m[2]})
  m=re.fullmatch(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;.*',line)
  if m:
   nums=list(map(int,m.groups()[1:]));assert m[1]=='ok' and nums[1:]==[0,0,0,0]
   rows.append({'target':target,'passed':nums[0]})
 assert len(roster)==sum(x['passed'] for x in rows)
 assert len({(x['target'],x['test']) for x in roster})==len(roster)
 assert all(x['status']=='ok' for x in roster)
 held=summaries[label];assert held['roster']==roster and held['per_target']==rows
 assert held['passed']==len(roster) and held['failed']==held['ignored']==0 and held['log_sha256']==rec['sha256']
 suite_rows[label]={'receipt':bind(V/(label+'.json')),'log':bind(log),'passed':len(roster),'failed':0,'ignored':0,'result_rows':len(rows)}
 suite_rosters[label]=roster
assert suite_rows['native-full-2']['passed']==3148 and suite_rows['native-full-2']['result_rows']==45
# Every newly held group must occur in the complete final Native population.
allnames={r['test'] for r in suite_rosters['native-full-2']}
new_group_count=0
for row in phase['frozen_test_comparisons']:
 path=row['target']
 if path in ['src/script/promise_semantic_tests.rs','src/script/promise_layout_probe.rs','src/script/promises/quota_tests.rs','src/script/promises/quota_more_tests.rs','src/script/promises/install_tests.rs','src/script/promises/layout_tests.rs']:
  prefix=path.removesuffix('.rs').removeprefix('src/').replace('/','::')+'::'
 elif path=='tests/promise_foundation.rs':prefix=''
 elif path=='tests/worker/promise_foundation.rs':prefix='promise_foundation::'
 else:continue
 names=re.findall(r'#\[test\](?:\s*#\[[^\]]*\])*\s*fn\s+(\w+)', (W/path).read_text())
 for name in names:assert prefix+name in allnames,(path,name)
 new_group_count+=len(names)
assert new_group_count==41
# Original held frame bytes and trace review remain intact.
integration=read(A/'integration/layout-review.json')
for row in integration['frames']:assert bind(row['binding']['path'])==row['binding']
assert len(integration['frames'])==12 and sum(x['binding']['bytes'] for x in integration['frames'])==1802496
# Root's serial current-toolchain run compares actual and mirror layouts.
layout_rec,layout_log=receipt('actual-layout-current-1');assert layout_rec['exit']==0
pat=r'PROMISE_LAYOUT(?P<actual>_ACTUAL)? (?P<name>\w+) bytes=(?P<bytes>\d+) align=(?P<align>\d+)'
parsed=[m.groupdict() for m in re.finditer(pat,layout_log.read_text())]
mirror={x['name']:(int(x['bytes']),int(x['align'])) for x in parsed if not x['actual']}
actual={x['name']:(int(x['bytes']),int(x['align'])) for x in parsed if x['actual']}
assert len(parsed)==36 and len(actual)==18 and mirror==actual
prior=read(R/'type-layout-measurement.json');assert actual=={x['name']:(x['bytes'],x['align']) for x in prior['layouts']}
# Source1's MSRV actual output is valid for the sole expression-equivalent delta.
rec,log=receipt('focused-candidate-1');assert rec['exit']==0
msrv_actual={m[0]:(int(m[1]),int(m[2])) for m in re.findall(r'PROMISE_LAYOUT_ACTUAL (\w+) bytes=(\d+) align=(\d+)',log.read_text())};assert msrv_actual==actual
# Strict checks and exact format/build exit receipts.
checks=[]
for label in needed:
 rec,log=receipt(label);assert rec['exit']==0
 checks.append({'label':label,'receipt':bind(V/(label+'.json')),'log':bind(log)})
# Parent diagnostic locations and the ignored-then-executed worker are explicit.
pr,pl=receipt('public-parent-1');wr,wl=receipt('worker-parent-1');assert pr['exit']==wr['exit']==101
assert '--ignored' in wr['command'] and '--include-ignored' not in pr['command']
assert '16 failed; 0 ignored' in pl.read_text() and '1 ignored' in pl.read_text()
assert 'pixel (2,2) actual=ff0000 expected=ffffff' in pl.read_text() and 'pixel (2,2) actual=ff0000 expected=ffffff' in wl.read_text()
baseline=read(R/'baseline-result.json');assert baseline['semantic_groups']==16 and baseline['integration_groups']==2 and baseline['base']==source['base']
# Expected unwind diagnostic is owned by a caught panic, followed by success.
quota=(W/'src/script/promises/quota_more_tests.rs').read_text()
assert 'let unwound = std::panic::catch_unwind(|| {' in quota and 'panic!("Promise reserve probe restoration witness")' in quota and 'assert!(unwound.is_err());' in quota
assert 'promise_settlement_second_reserve_failure_keeps_exact_old_state ... ok' in log.read_text() or 'promise_settlement_second_reserve_failure_keeps_exact_old_state ... ok' in (V/'focused-candidate-1.log').read_text()
failed_rec,failed_log=receipt('strict-current-1');assert failed_rec['exit']==101 and 'manual_is_multiple_of' in failed_log.read_text()
# Immutable final browser and the precise source/build join.
browser=read(R/'final-browser.json');binary=Path(browser['path']);assert bind(binary)['sha256']==browser['sha256'] and binary.stat().st_size==browser['bytes']
with binary.open('rb') as f:assert f.read(4)==b'\x7fELF'
assert browser['source_inventory']=='source-2.json' and browser['source_inventory_sha256']==bind(A/'source-2.json')['sha256'] and browser['verified_source_inputs']==783
assert browser['build']==read(V/'browser-final-build-1.json') and browser['features']==['vulkan-raster'] and browser['rust']=='1.88.0'
# Reference receipt must identify this binary and all102 result pairs.
ref_runs=[]
for p in V.glob('*.json'):
 rec=read(p);cmd=rec.get('command',[])
 if any('reftest.py' in str(v) for v in cmd):
  log=V/rec['log'];assert bind(log)['sha256']==rec['sha256'];assert rec['exit']==0
  assert '--binary' in cmd and cmd[cmd.index('--binary')+1]==str(binary)
  ref_runs.append({'receipt':bind(p),'log':bind(log)})
assert len(ref_runs)==1
comparison=read(R/'reference-comparison-final.json');report=A/'reftests-final/report.json';data=read(report)
assert comparison['status']=='pass' and comparison['pairs']==102 and comparison['unchanged_pngs']==204
assert data['total']==102 and data['failed']==0 and comparison['report_sha256']==bind(report)['sha256']
parent=W/'docs/evidence/pi-key-cache';parent_summary=read(parent/'summary.json');archive=parent/'sources-and-checks.tar.gz'
assert bind(archive)['sha256']==parent_summary['archive']['sha256']==comparison['parent_archive_sha256'] and archive.stat().st_size==parent_summary['archive']['bytes']
rows={x['name']:x for x in comparison['images']};assert len(rows)==204
seen=set();totalbytes=0
with tarfile.open(archive,'r:gz') as tar:
 for member in tar:
  prefix='evidence/reftests-final/'
  if member.name.startswith(prefix) and member.name.endswith('.png'):
   name=member.name[len(prefix):];assert member.isfile() and '/' not in name and name not in seen and 0<member.size<=4*1024*1024
   old=tar.extractfile(member).read();now=(A/'reftests-final'/name).read_bytes()
   assert now==old and len(now)==member.size==rows[name]['bytes']
   assert hashlib.sha256(now).hexdigest()==rows[name]['sha256']
   seen.add(name);totalbytes+=len(now)
assert seen==set(rows)=={p.name for p in (A/'reftests-final').glob('*.png')}
result={
 'status':'clear','scope':'Independent inert source, manifest, frozen-test, complete-log, reference-archive and immutable-browser inspection. No project compiler/runtime/browser/GitHub/git execution or live code changes.',
 'source':bind(A/'source-2.json'),'verified_source_inputs':783,'source_transition':bind(A/'validation-review/source-transition.json'),
 'frozen_tests':{'audit':bind(A/'validation-review/phase-1-observations.json'),'files':15,'literals':'All preserved. Only rustfmt whitespace/trailing commas and one exact two-import reordering. Original8+additive10 quota groups remain intact.','new_groups_observed':41,'focused_population':{'semantic':16,'quota':18,'installer':3,'mirror_and_actual_layout':2,'migrated_PI_boundary':1,'Page_and_worker':2,'total':42},'literal_frames':12,'literal_rgba_bytes':1802496,'integration_review':bind(A/'integration/layout-review.json')},
 'parent_baseline':{'receipt':bind(R/'baseline-result.json'),'public_run':bind(V/'public-parent-1.json'),'worker_run':bind(V/'worker-parent-1.json'),'observed':'16 semantic groups failed on absent Promise, one mirror group passed; Page and separately executed confined worker each failed their first enabled pixel after four scripts-disabled frame controls. The first combined run ignored the worker; --ignored later executed it. Multi-row groups stop at their first failure; later rows are not parent observations.'},
 'full_suites':suite_rows,'full_suite_totals':bind(R/'full-suite-totals.json'),'selected_checks':checks,
 'type_layout':{'actual_and_mirror_rows':18,'all_equal':True,'current_receipt':bind(V/'actual-layout-current-1.json'),'current_log':bind(layout_log),'msrv_source1_receipt':bind(V/'focused-candidate-1.json'),'qualification':'Actual production assertion/output compared with held mirror on x86-64 Rust1.88 and1.98; source1→2 changes only equivalent arithmetic, not any type. No total-runtime/stack/physical-memory claim.'},
 'known_caught_panic':'The quota reserve-unwind witness intentionally panics inside catch_unwind, asserts that unwind was caught, then proves guard restoration with a successful fresh settlement. Its focused and final test groups pass; this is not an uncaught candidate failure.',
 'retained_failed_attempt':{'receipt':bind(V/'strict-current-1.json'),'log':bind(failed_log),'reason':'Rust1.98 manual_is_multiple_of lint; exact equivalent div_ceil spelling is bound in source-transition, with no fee/test changes.'},
 'browser':{'record':bind(R/'final-browser.json'),'file':bind(binary),'source_join':True},
 'references':{'comparison':bind(R/'reference-comparison-final.json'),'report':bind(report),'run':ref_runs[0],'pairs':102,'parent_identical_pngs':204,'compared_png_bytes':totalbytes,'parent_summary':bind(parent/'summary.json'),'parent_archive':bind(archive)},
 'claims_limit':'Local regression and headless software-reference evidence only. Native feature compilation/planning is not a new actual GPU/adaptor/window run. No performance, full-conformance, production-security, garbage-collection or whole-runtime footprint claim. Parent CI is historical, not candidate CI.',
 'findings':[]
}
out=R/'validation-review.json'
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(bind(out));print({k:{x:v[x] for x in ['passed','failed','ignored','result_rows']} for k,v in suite_rows.items()})
