from pathlib import Path
import json,hashlib,re,difflib
A=Path('/tmp/eris-promise-1');W=A/'worktree';P=Path('/tmp/eris-promise-plan-1');O=A/'validation-review'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
def lex(s):
 # Preserve literal bytes. Whitespace/comments are not semantic tokens; the
 # only normalization below additionally permits rustfmt trailing commas.
 t=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   k=s.find('\n',i);i=len(s) if k<0 else k+1;continue
  if s.startswith('/*',i):
   depth=1;i+=2
   while depth:
    if s.startswith('/*',i):depth+=1;i+=2
    elif s.startswith('*/',i):depth-=1;i+=2
    else:i+=1
    assert i<=len(s)
   continue
  m=re.match(r'(?:br|cr|r)(#*)"',s[i:])
  if m:
   k=s.find('"'+m[1],i+len(m[0]));assert k>=0;k+=1+len(m[1]);t.append(s[i:k]);i=k;continue
  m=re.match(r'(?:b|c)?"',s[i:])
  if m:
   k=i+len(m[0])
   while s[k]!='"':k+=2 if s[k]=='\\' else 1
   k+=1;t.append(s[i:k]);i=k;continue
  m=re.match(r"(?:b)?'(?:\\u\{[\da-fA-F_]+\}|\\x[\da-fA-F]{2}|\\.|[^'\\\n])'",s[i:])
  if m:t.append(m[0]);i+=len(m[0]);continue
  m=re.match(r'(?:r#)?[A-Za-z_0-9]+',s[i:])
  if m:t.append(m[0]);i+=len(m[0]);continue
  t.append(s[i]);i+=1
 return [v for k,v in enumerate(t) if not(v==',' and k+1<len(t) and t[k+1] in [')',']','}'])]
sources={
 'src/script/promise_semantic_tests.rs':P/'semantic-tests-2/raw/src/script/promise_semantic_tests.rs',
 'src/script/promise_layout_probe.rs':P/'runtime-tests-before-1/raw/src/script/promise_layout_probe.rs',
 'src/script/promises/quota_tests.rs':P/'runtime-tests-before-1/raw/src/script/promises/quota_tests.rs',
 'src/script/promises/quota_more_tests.rs':P/'runtime-tests-before-2/raw/src/script/promises/quota_more_tests.rs',
 'src/script/promises/layout_tests.rs':A/'production-draft-layout/raw/src/script/promises/layout_tests.rs',
}
for folder in [P/'migrations-before-1/raw',A/'integration/raw']:
 for p in folder.rglob('*'):
  if p.is_file():sources[str(p.relative_to(folder))]=p
comparisons=[]
for target,held in sorted(sources.items()):
 live=W/target;before=held.read_text();after=live.read_text()
 a,b=lex(before),lex(after)
 diffs=[{'op':op,'old':a[i:j],'new':b[k:l]} for op,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes() if op!='equal'] if target.endswith('.rs') else []
 literals=lambda ts:[v for v in ts if '"' in v or re.fullmatch(r"(?:b)?'(?:\\.|.)'",v)]
 comparisons.append({'target':target,'held':bind(held),'current':bind(live),'byte_exact':before==after,'tokens_exact_after_whitespace_comments_and_trailing_commas':a==b if target.endswith('.rs') else None,'literal_tokens_exact':literals(a)==literals(b),'unexplained_token_differences':diffs,'test_names':re.findall(r'#\[test\]\s*fn\s+(\w+)',after)})
manifest=read(A/'source-1.json');mapping=manifest['source_sha256']
mismatches=[p for p,h in mapping.items() if bind(W/p)['sha256']!=h]
logs=[]
for p in sorted((A/'validation').glob('*.json')):
 x=read(p)
 if 'log' not in x:continue
 log=p.parent/x['log'];assert bind(log)['sha256']==x['sha256'],p
 rows=[{'status':m[0],'passed':int(m[1]),'failed':int(m[2]),'ignored':int(m[3]),'measured':int(m[4]),'filtered':int(m[5])} for m in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',log.read_text())]
 logs.append({'receipt':bind(p),'log':bind(log),'command':x['command'],'exit':x['exit'],'rows':rows,'totals':{k:sum(r[k] for r in rows) for k in ['passed','failed','ignored','measured','filtered']}})
result={'status':'partial_observations_pending_final_checks','manifest':bind(A/'source-1.json'),'manifest_inputs':len(mapping),'current_mismatches':mismatches,'frozen_test_comparisons':comparisons,'receipts':logs,'scope':'Inert source/token/hash/log inspection only. No compiler/browser/project import/git. Raw source1 retained; final source correction and remaining checks not inferred.'}
(O/'phase-1-observations.json').write_text(json.dumps(result,indent=2)+'\n')
print('manifest',len(mapping),'current mismatches',mismatches)
print('test files',len(comparisons),'unexplained',[(r['target'],r['unexplained_token_differences']) for r in comparisons if r['unexplained_token_differences']])
for r in logs:print(Path(r['receipt']['path']).name,'exit',r['exit'],'rows',len(r['rows']),r['totals'])
print(bind(O/'phase-1-observations.json'))
