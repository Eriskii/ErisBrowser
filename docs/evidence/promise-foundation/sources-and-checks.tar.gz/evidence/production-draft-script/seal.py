from pathlib import Path
import difflib,hashlib,json,re
R=Path('/tmp/eris-promise-1/production-draft-script');W=Path('/tmp/eris-promise-1/worktree')
def b(p):
 p=Path(p);v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def write(n,x):
 p=R/n;p.write_text(json.dumps(x,indent=2)+'\n');return b(p)
files=[]
for rel in ['src/script/promises/semantics.rs','src/script/machine/calls.rs','src/script/construction.rs']:
 raw=R/'raw'/rel;before=R/'before'/rel
 if before.exists():
  assert before.read_bytes()==(W/rel).read_bytes(),rel
  old=before.read_text();bb=b(before)
 else: old='';bb=None
 new=raw.read_text()
 patch=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+rel if bb else '/dev/null',tofile='b/'+rel))
 d=R/'diffs'/(rel+'.patch');d.parent.mkdir(parents=True,exist_ok=True);d.write_text(patch)
 files.append({'target':rel,'before':bb,'raw':b(raw),'diff':b(d)})
api=write('interface.json',{
 'status':'selected_interfaces_coordinated_with_root_and_layout_before_implementation',
 'registration':'Layout-owned promises.rs must register mod semantics; no test registration or root-owned file mutation is included here.',
 'outward_methods':[
 'pub(in crate::script) fn promise_construct(&mut self,args:&[Value],new_target:Value,doc:&mut Document)->Result<Value>',
 'pub(in crate::script) fn promise_native_operation(&mut self,name:&str,receiver:Value,args:&[Value],doc:&mut Document)->Result<Value>',
 'pub(in crate::script) fn promise_callback(&mut self,native:&Native,args:&[Value],doc:&mut Document)->Result<Value>',
 'pub(in crate::script) fn run_promise_job(&mut self,job:PromiseJob,doc:&mut Document)->Result<Value>'],
 'layout_owned_dependencies':[
 'new_pending_promise(Value)->Result<(PromiseId,Value)>; base20+record/object growth',
 'promise_id(&Value)->Result<Option<PromiseId>>;8+2*bit_length(records)',
 'promise_object_id(PromiseId)->Result<usize>;8',
 'new_resolving_functions(PromiseId)->Result<(Value,Value)>',
 'new_capability_executor()->Result<(CaptureId,Value)>',
 'callback_target(&Native)->Result<CallbackKind>;8+2*bit_length(callbacks)',
 'take_resolve_gate(GateId)->Result<Option<PromiseId>>;8',
 'store_capability_capture(CaptureId,&[Value])->Result<()>;14',
 'read_capability_capture(CaptureId)->Result<(Value,Value)>;12',
 'register_promise_then(PromiseId,Option<&Value>,Option<&Value>,Capability)->Result<()>;8 reread then held pending/direct settled admission',
 'settle_promise(PromiseId,ReactionKind,Value)->Result<()>',
 'enqueue_resolve_thenable(PromiseId,&Value,&Value)->Result<()>',
 'promise_arguments<const N:usize>([Value;N])->Result<Vec<Value>>;10/12work and32+N*sizeof(Value)'],
 'root_owned_dependencies':['well_known_symbol_count(&self)->usize; unchanged well_known_key accessor after paid search','Shared dispatcher prepays32 before first Promise payload pop/take; run_promise_job is called once with owned payload. Ordinary returned error is reported with Promise prefix; fatal result suspends/propagates.','Installer fields match selected State/Intrinsics; original constructor/prototype come only from private cache.'],
 'ownership':'No arena/factory/installer/report implementation duplicated here. Generic capabilities remain generic; no intrinsic-only shortcut. All required helper/API additions were sent and selected before this source hold.',
 'visibility':'Methods used by machine/construction/microtasks are pub(in crate::script), not child-module pub(super). Internal semantic helpers remain private.'})
fees=write('orchestration-ledger.json',{
 'status':'root_selected_additional_semantic_orchestration_only_no_end_to_end_fee_claim',
 'unchanged':'All frozen direct core/factory/installer/argument/queue/report cuts remain separate and unchanged. Existing Get/Call/Construct/object_is_values/exception_value fees are reused. No new cap, reset, replay, scheduler or budget allowance.',
 'rows':[
 {'operation':'public constructor or one public native operation','work':8,'heap':0,'covers':'Fixed operation/argument/callability/branch checks and bounded temporary-handle cleanup on normal/abrupt return. Includes discarded nonobject prototype value, unselected capability callback, ignored call result and local constructor/capability temporaries. Nested calls retain their independent old call/frame fees.'},
 {'operation':'explicit additional Value clone','work':1,'heap':0,'covers':'One constant-sized owned handle copy before constructing an owned input list or retaining a source/return handle; original factories/payloads/private core retain their own lifetime credits.'},
 {'operation':'cached original constructor','work':9,'heap':0,'covers':'8 private cache validation/read +1 handle copy. No global lookup, author Get, constructor-name scan or new allocation.'},
 {'operation':'cached original prototype','work':8,'heap':0,'covers':'Private cache validation and scalar object identity read.'},
 {'operation':'fixed named Get key','work':'8+2*ASCII_len','heap':'64+4*ASCII_len','covers':'Unchanged dom_proto_text Vec and Rc text-copy admission. Move into PropertyKey::String; existing get_property_key does observable Get with ordinary/host dispatch and existing fees.'},
 {'operation':'species fixed symbol key','work':'tree_comparison_bound(well_known_count)*(1+7/8)+2','heap':0,'current15work':17,'covers':'PinnedB6 search15 for species7bytes plus key and receiver handle copies. Paid before well_known_key and receiver clone; existing get_property_key adds own traversal/callback fees.'},
 {'operation':'generic IsConstructor checks','work':'explicit1 for new source handle +existing is_constructor/construct fees','heap':'existing helper charges','covers':'No replacement constructor implementation or unpaid author call. Bound target traversal remains the old helper.'},
 {'operation':'post-capability source state reread','work':'Layout register_promise_then8, then unchanged append18/directjob16 plus growth','heap':'selected core formulas','covers':'Never retain a source Settlement borrow across SpeciesConstructor/NewPromiseCapability author calls. Consumes owned Capability; semantics separately pays1 for child return handle.'},
 {'operation':'generated callback routing','work':'Layout callback_target then gate8/capture14; argument clone1 after gate consumption','heap':'core/ordinary Get/settlement fees only','covers':'Private Native stored metadata identity, independent of dynamic receiver. No semantic fixed8 surcharge on held direct callback/gate/capture cuts.'},
 {'operation':'reaction job body','work':'first promise_arguments1=10; callable handler call and optional second1arg list use existing fees','heap':'each actual argument list32+sizeof(Value)','covers':'No-handler case forwards its original paid argument vector directly to resolve/reject. No fake throw or Error allocation. Handler ordinary throw materializes exact reason via exception_value before reject call.'},
 {'operation':'thenable job body','work':'selected resolving-pair factory +1 reject clone +promise_arguments2=12; ordinary abrupt completion adds1arg list10','heap':'selected factory/argument/exception/call fees','covers':'Fresh gate/pair; captured then called once with original thenable receiver. Return ignored; thrown ordinary value invokes reject, which observes already-resolved gate. No Get(then) in job.'}],
 'abrupt_cleanup':'Public fixed8 covers bounded semantic temporaries; private factory/payload/retention schedules prepay their own handle/arena teardown, and argument builders prepay vector fill/drop. Existing call frames own author-call cleanup. Active job is already consumed and never replayed; exception_value rejects Resource/Unsupported instead of producing an ordinary rejection. This does not assert a new complete proof of every existing runtime allocator or Error helper.',
 'no_handler_boundary':'run_promise_job performs no work debit, cache lookup, clone or allocation before promise_arguments([argument]) for a Reaction payload. Root common+Promise dispatch32 therefore remains the frozen consumed-job/next10 refusal boundary.',
 'key_lengths':{'constructor':11,'prototype':9,'then':4,'species':7},
 'lookup_limit':'well_known table is runtime-private, initialized before publication, presently15 entries; generated callbacks never derive record IDs from mutable JavaScript properties.'})
review=write('source-review.json',{
 'status':'author_source_read_complete_pending_independent_peer_no_execution',
 'files':3,
 'checks':[
 'Constructor is callable-as-error and constructible only through existing native Window constructor routing. Executor callable check precedes observable NewTarget.prototype access; nonobject prototype falls back to cached original Promise.prototype.',
 'Generic NewPromiseCapability checks constructor, builds selected private capture executor and uses existing Construct. Captured values are read after author construction and both callbacks must be callable. Two undefined captures do not become a boolean-already-called policy.',
 'then validates genuine private brand before constructor/species getters, constructs generic capability, then uses live-state registration. Reentrant CSH4R5 path is supported without stale borrowed state.',
 'resolve requires object receiver and preserves genuine Promise.constructor SameValue identity before capability constructor validation. reject remains generic capability invocation.',
 'Generated callback dispatch precedes generic dotted-name receiver substitution. Immutable Native is borrowed, name not cloned; dynamic receiver does not supply private callback identity.',
 'Resolve gate is consumed before argument clone and observable then getter. Self resolution produces TypeError reason; nonobject or noncallable then fulfills; callable then is captured for one queued job.',
 'Reaction absent handlers forward exact values, callable handlers use Undefined receiver/one argument; ordinary handler throws become exact rejection via exception_value. Arbitrary resolve/reject callback throw is returned as abrupt job for root reporting.',
 'Thenable job creates fresh resolving pair, calls captured then with thenable receiver/two arguments, ignores return and sends ordinary abrupt value to fresh reject. Fatal errors always propagate.',
 'Every public semantic entry/job/callback observes Resource/Unsupported through sticky microtask failure wrapper; no author-entry reset or checkpoint insertion in this module.',
 'Dispatch patch remains inside result expression so existing native stack cleanup is unconditional. Construction patch adds exactly whitelist Promise and one constructor match arm.' ],
 'known_scope':'Only selected Promise constructor/then/resolve/reject/species and supporting generated callbacks/jobs. No catch/finally/aggregates/async/await/unhandled-rejection tracker or new scheduler. Existing runtime quotas and general language limits remain.',
 'unexecuted':'No project/compiler/parser/JavaScript/test/browser/formatter/git execution or live edits. This source has not been compiled. Peer and root integration are required.'})
inputs=[]
for p in [
 '/tmp/eris-promise-plan-1/root/runtime-selection-1.json',
 '/tmp/eris-promise-plan-1/runtime-ledger-1/ledger.json',
 '/tmp/eris-promise-plan-1/runtime-tests-before-1/api.json',
 '/tmp/eris-promise-plan-1/runtime-tests-before-2/api-additions.json',
 '/tmp/eris-promise-plan-1/semantic-tests-2/source-ready.json',
 '/tmp/eris-promise-plan-1/semantic-tests-2/script-review.json',
 '/tmp/eris-promise-plan-1/migrations-before-1/source-ready.json']:
 inputs.append(b(p))
manifest=write('source-ready.json',{'status':'external_semantic_production_draft_source_ready_for_independent_peer','files':files,'interface':api,'orchestration_ledger':fees,'source_review':review,'selected_inputs':inputs,'authoring':[b(R/'dispatch-patches.py'),b(R/'seal.py')],'integration':'Root imports after peer; Layout registers mod semantics in its promises.rs. Existing selected public/private tests and old migrations are independent held files, unchanged here. No live edits or execution.'})
print(json.dumps(manifest,indent=2))
