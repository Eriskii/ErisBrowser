from pathlib import Path
import difflib
r=Path('/tmp/eris-promise-1/production-draft-script');w=Path('/tmp/eris-promise-1/worktree')
def replace(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)
for path in ['src/script/machine/calls.rs','src/script/construction.rs']:
 old=(w/path).read_text();new=old
 if path.endswith('calls.rs'):
  new=replace(new,'''        runtime.queue_microtask(&receiver, &arguments)
    } else if NumberPredicate::from_name''','''        runtime.queue_microtask(&receiver, &arguments)
    } else if native.name == "Promise.callback" {
        // Private capture identity is the stored metadata receiver. Do not
        // substitute dynamic this or allocate a copied Native name.
        runtime.promise_callback(&native, &arguments, doc)
    } else if matches!(
        native.name.as_str(),
        "Promise" | "Promise.then" | "Promise.resolve" | "Promise.reject" | "Promise.getSpecies"
    ) {
        runtime.promise_native_operation(&native.name, receiver, &arguments, doc)
    } else if NumberPredicate::from_name''')
 else:
  new=replace(new,'''                                    | "ArrayBuffer"
                                    | "DataView"''','''                                    | "ArrayBuffer"
                                    | "Promise"
                                    | "DataView"''')
  new=replace(new,'''                    "ArrayBuffer" => self.array_buffer_constructor(&arguments, new_target, doc),''','''                    "Promise" => self.promise_construct(&arguments, new_target, doc),
                    "ArrayBuffer" => self.array_buffer_constructor(&arguments, new_target, doc),''')
 for kind,text in [('before',old),('raw',new)]:
  p=r/kind/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 p=r/'diffs'/(path+'.patch');p.parent.mkdir(parents=True,exist_ok=True)
 p.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
