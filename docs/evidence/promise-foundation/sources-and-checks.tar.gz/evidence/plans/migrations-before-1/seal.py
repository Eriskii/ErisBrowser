from pathlib import Path
import hashlib,json,difflib,re
R=Path('/tmp/eris-promise-plan-1/migrations-before-1')
W=Path('/tmp/eris-promise-1/worktree')
def binding(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(name,obj):
 p=R/name;p.write_text(json.dumps(obj,indent=2)+'\n');return binding(p)
paths=['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/microtask_budget_tests.rs','src/script/dom_bindings/identity_tests.rs']
entries=[]
for p in paths:
 assert (R/'before'/p).read_bytes()==(W/p).read_bytes()
 entries.append({'target':p,'before':binding(R/'before'/p),'raw':binding(R/'raw'/p),'diff':binding(R/'diffs'/(p+'.patch'))})
new='src/script/promises/install_tests.rs'
newtext=(R/'raw'/new).read_text()
d=''.join(difflib.unified_diff([],newtext.splitlines(True),fromfile='/dev/null',tofile='b/'+new))
p=R/'diffs'/(new+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(d)
entries.append({'target':new,'before':None,'raw':binding(R/'raw'/new),'diff':binding(p)})
measure_log=Path('/tmp/eris-promise-1/validation/layout-probe-msrv-1.log')
measure_receipt=Path('/tmp/eris-promise-1/validation/layout-probe-msrv-1.json')
receipt=json.loads(measure_receipt.read_text());assert receipt['exit']==0 and receipt['sha256']==binding(measure_log)['sha256']
sizes={name:int(n) for name,n in re.findall(r'PROMISE_LAYOUT (\w+) bytes=(\d+) align=\d+',measure_log.read_text())}
assert {k:sizes[k] for k in ('Value','QueueJob','CurrentMicrotaskState','ProposedMicrotaskState','State','ScriptObject')}=={'Value':24,'QueueJob':24,'CurrentMicrotaskState':56,'ProposedMicrotaskState':56,'State':192,'ScriptObject':216}
measurement=write('measurement-binding.json',{'status':'read_existing_root_execution_receipt_only','receipt':binding(measure_receipt),'log':binding(measure_log),'mirror_source':binding(W/'src/script/promise_layout_probe.rs'),'sizes':sizes,'qualification':'These are root-measured proposed mirror layouts on Rust1.88 x86-64, not final Promise implementation measurements. No primitive symbolic sizes were guessed. No execution by this author.'})
api=write('api.json',{
 'registration':{'production_parent':'src/script/promises.rs','declaration':'#[cfg(test)] mod install_tests;'},
 'private_method':'Runtime::install_promise_intrinsics(&mut self) -> Result<()>',
 'state_fields':'Runtime.promises: promises::State; State fields promises,gates,callbacks,captures,jobs: Arena<T>, each records:Vec<T>, admitted_capacity:usize; intrinsics:Option<Intrinsics>; Intrinsics constructor:Value, prototype:usize.',
 'queue':'promises::QueueJob::{Callback(Value),Promise(JobId)}, Clone+Debug+PartialEq; JobId Copy+Clone+Debug+PartialEq+Eq. Existing Microtasks State queue becomes VecDeque<QueueJob>.',
 'visibility':'promises::State and QueueJob visible within crate::script; installer callable by its descendant tests. Private arena and intrinsic fields remain private to promises; tests are a child module.',
 'fixture':'Start with fully initialized Runtime, assert five arenas/FIFO empty and cache coherence; remove only exposed Promise global and private cache; retain all747 old metadata bags and reserve6 spare slots using Rust setup; reset counters before direct installer. Globals211, maps299/25. Success753 private bags/212globals, restored cache, no backing arena growth.',
 'failure':'Do not require partial metadata-bag rollback. Direct work refusal or late global heap refusal leaves Promise global/private cache absent. Failed full bootstrap consumes/discards the unexposed Runtime. No callback execution or production cap reset.',
 'publication_order':'All930 installer work precedes the final global key/split heap charge and global Entry insertion; constructor clones paid before use, fixed16 paid first. Cache publication follows successful global insertion; no fallible operation after publication.',
 'unchanged':'No new production observer, heap limit, work allowance, callback dispatch fee, reporter fee, or old semantic assertion.'})
ledger=write('ledger.json',{
 'status':'tests_and_migrations_frozen_before_Promise_production_or_observation',
 'base':'Published AH 2d103b4f as provided by root; each exact before file is frozen and hashed.',
 'installer_work':{'rows':[54,220,284,106,21,2,45,22,160,16],'sum':930,'exact':930,'one_short':929},
 'raw_bootstrap':{'old':98875,'installer':930,'new':99805,'one_short':99804,'limit':100000,'remaining':195,'public_try_new_resets_after_success':100000},
 'counts':{'objects':[741,747],'globals':[211,212],'native_registry':[299,299],'prototypes':[25,25],'new_direct_native_handles':5,'new_metadata_bags':6},
 'helper_heap':'6*A +6*D +17*K +6*Bpp +5*N +4*Bsb +6269',
 'whole_heap_delta':'sizeof(promises::State) +6*sizeof(ScriptObject) +helper_heap; existing typed_array microtask_added uses current sizeof(microtasks::State), already carrying any header delta exactly once.',
 'heap_constant_derivation':'6*72 +17*256 +4*87 +9*64 +4*74 +5*32 +66 +32 +7 =6269. Helpers own their bag/order/property/node charges; no second total debit.',
 'type_symbols':{'A':'sizeof(Option<AbortSlot>)','D':'sizeof(Option<f64>)','K':'sizeof(PropertyKey)','N':'sizeof(Native)','Bpp':'16*(K+sizeof(Property))+32*sizeof(usize)+64','Bsb':'16*(sizeof(String)+sizeof(Binding))+32*sizeof(usize)+64'},
 'measured_mirror_only':{'State':192,'ScriptObject':216,'old_microtask_header':56,'new_microtask_header':56,'Value':24,'QueueJob':24,'state_plus_initial_arena_delta':1488},
 'queue':{'cold_heap':'32+8*sizeof(QueueJob)','growth_heap':'32+16*sizeof(QueueJob)','old_new_numeric_bytes':[224,416],'movement_units':1,'cold_work':[16,15],'spare_work':[8,7],'full_growth_work':[32,31],'checkpoint_controls':[29,28,24,23,16,7],'whole_entry_controls':[37,36],'reporter':'All original reporter strings/fees/cap/overflow tests byte-identical; Promise dedicated prefix is outside this old-test migration.'},
 'direct_heap_cuts':'Start allocated=MAX_HEAP-helper_bytes for success, plus1 for failure. The last charged helper allocation is the global key/split envelope; all930 work is already paid. Success ends allocated=MAX_HEAP/steps0; one-short ends allocated=MAX_HEAP+1/steps0 and no global/cache.',
 'private_witness_groups':re.findall(r'^fn (promise_[a-z0-9_]+)\(',newtext,re.M),
 'source_arithmetic_only':True})
assert sum([54,220,284,106,21,2,45,22,160,16])==930
assert 6*72+17*256+4*87+9*64+4*74+5*32+66+32+7==6269
assert 98875+930==99805 and 100000-99805==195
assert 192+6*216==1488
review=write('audit.json',{
 'status':'source_audit_clear_pending_independent_peer_and_root_execution',
 'changed_existing_files':5,'new_private_groups':3,
 'migrations':[
 {'path':paths[0],'reason':'Promise installer adds930 work/six metadata bags; prior PI cache-saving comment retained; unrelated bootstrap refusal/reset tests untouched.'},
 {'path':paths[1],'reason':'Append exact symbolic Promise State/arena/helper delta to historical cumulative formula; subtract930work; objects/capacity747, globals212. Keep299native-registry/25prototype rows.'},
 {'path':paths[2],'reason':'Raw whole-bootstrap witness remains exact/one-short, with selected additional930work; explicit Promise absence becomes presence. PI metadata and key-cache semantic assertions are unchanged.'},
 {'path':paths[3],'reason':'Two Value slot-byte types become QueueJob; two front comparisons wrap Callback; one size-equality control binds unchanged work cuts to the measured mirror. All fee literals and other assertions remain exact.'},
 {'path':paths[4],'reason':'Additional audit discovery: one raw bootstrap object-count741 becomes747; no other token changes.'}],
 'search':'Read-only rg across script test modules and script.rs for741/1125/98875/211/Promise absence and queue Value-size/front assertions. Matches in unrelated numeric/string fixtures were not changed.',
 'new_tests':'Three direct/raw installer groups use selected private seams; they do not compile on the unchanged parent before promises exists. Existing migrated tests remain held externally until root installs candidate.',
 'validation_boundary':'No project compiler/parser/tests/browser/git executed or imported. Root mirror receipt was read, rehashed and bound. Source before/raw/diffs and JSON arithmetic only.'})
inputs=[binding('/tmp/eris-promise-plan-1/bootstrap-ledger-1/ledger.json'),binding('/tmp/eris-promise-plan-1/runtime-ledger-1/ledger.json'),binding('/tmp/eris-promise-plan-1/root/runtime-selection-1.json')]
manifest=write('source-ready.json',{'status':'frozen_external_tests_and_explicit_migrations_before_production','files':entries,'api':api,'ledger':ledger,'audit':review,'measurement':measurement,'selected_inputs':inputs,'authoring_files':[binding(R/'author.py'),binding(R/'seal.py')],'group_count_new':3,'old_file_count':5,'execution':'No project execution, imports or live edits. Root alone may integrate/format/compile/run.'})
print(json.dumps(manifest,indent=2))
