from pathlib import Path
import difflib,hashlib,json
BASE=Path('/tmp/eris-promise-1/worktree')
OUT=Path('/tmp/eris-promise-plan-1/migrations-before-1')
paths=['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/microtask_budget_tests.rs','src/script/dom_bindings/identity_tests.rs']
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
for path in paths:
 s=(BASE/path).read_text(); old=s
 if path.endswith('bootstrap_tests.rs'):
  s=replace(s,'    assert_eq!(reference.steps, 1125);','    // Promise adds930 paid installation work and six metadata bags.\n    assert_eq!(reference.steps, 195);')
  s=replace(s,'assert_eq!(reference.objects.len(), 741);','assert_eq!(reference.objects.len(), 747);')
 elif path.endswith('typed_array/tests.rs'):
  s=replace(s,'    assert_eq!(\n        runtime.steps,\n        5941', '''    // Promise's five arena headers/private cache and six eagerly reserved bags
    // are separate from its existing helper charges. The microtask header's
    // current sizeof is already included in microtask_added above.
    let promise_added = size_of::<crate::script::promises::State>()
        + 6 * s
        + 6 * a
        + 6 * d
        + 17 * k
        + 6 * bpp
        + 5 * n
        + 4 * bsb
        + 6269;
    assert_eq!(
        runtime.steps,
        5941''')
  s=replace(s,' - 327 + 332\n',' - 327 + 332 - 930\n')
  s=replace(s,'            - 1680\n','            - 1680\n            + promise_added\n')
  s=replace(s,'(741, 741)','(747, 747)')
  s=replace(s,'bindings.len(), 211);','bindings.len(), 212);')
 elif path.endswith('key_cache_tests.rs'):
  s=replace(s,'cached_pi_keys_raw_bootstrap_uses_the_frozen_98875_work_boundary','cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99805_work_boundary')
  s=replace(s,'    for (allowance, success, remaining) in [','    // Cached PI keys still save332; the separately held Promise installer adds930.\n    for (allowance, success, remaining) in [')
  s=replace(s,'(98_874, false, 0)','(99_804, false, 0)')
  s=replace(s,'(98_875, true, 0)','(99_805, true, 0)')
  s=replace(s,'(100_000, true, 1_125)','(100_000, true, 195)')
  s=replace(s,'objects.len(), 741);','objects.len(), 747);')
  s=replace(s,'bindings.len(), 211);','bindings.len(), 212);')
  s=replace(s,'assert!(!runtime.environments[0].bindings.contains_key("Promise"));','assert!(runtime.environments[0].bindings.contains_key("Promise"));')
 elif path.endswith('microtask_budget_tests.rs'):
  s=replace(s,'use super::*;','use super::*;\nuse super::promises::QueueJob;')
  s=replace(s,'std::mem::size_of::<Value>()','std::mem::size_of::<QueueJob>()',2)
  s=replace(s,'Some(&callback)','Some(&QueueJob::Callback(callback.clone()))')
  s=replace(s,'Some(&later)','Some(&QueueJob::Callback(later.clone()))')
  s=replace(s,'    let bytes = 32 + 16 * std::mem::size_of::<QueueJob>();','    // The frozen layout mirror has QueueJob=Value=24 bytes, so the\n    // existing growth movement unit and exact32/31 work cuts stay unchanged.\n    assert_eq!(std::mem::size_of::<QueueJob>(), std::mem::size_of::<Value>());\n    let bytes = 32 + 16 * std::mem::size_of::<QueueJob>();')
 else:
  s=replace(s,'assert_eq!(runtime.objects.len(), 741);','assert_eq!(runtime.objects.len(), 747);')
 for kind,data in [('before',old),('raw',s)]:
  dest=OUT/kind/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(data)
 diff=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 dest=OUT/'diffs'/(path+'.patch');dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(diff)
