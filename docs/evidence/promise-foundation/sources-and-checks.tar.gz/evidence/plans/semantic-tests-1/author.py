from pathlib import Path
import json,hashlib
p=Path('/tmp/eris-promise-plan-1');o=p/'semantic-tests-1'
root=json.loads((p/'root-semantic-oracles-1/cases.json').read_text());peer=json.loads((p/'root-semantic-oracles-1/review.json').read_text())
groups=[]
for c in root['cases']:
 row={k:c[k] for k in ['script','after_checkpoint_expression','expected']};row['console']=[]
 if 'entry_result' in c:row['entry_result']=c['entry_result']
 groups.append({'name':c['name'],'origin':'root ten reviewed traces; source script and expected literal unchanged','rows':[row]})
requirements=peer['coverage_requirements']
for c in requirements[:3]:
 row={k:c[k] for k in ['script','after_checkpoint_expression','expected']};row['console']=[];rows=[row]
 if 'nested_script' in c:rows.append({'script':c['nested_script'],'after_checkpoint_expression':'log','expected':c['nested_expected'],'console':[]})
 groups.append({'name':c['id'],'origin':'independently reviewed coverage trace, unchanged','rows':rows})
capture=r"""
var captures=0,outer=0,calls=0;
function firstResolve(e){e(function(){calls++;},undefined);try{e(function(){calls++;},function(){calls++;});}catch(x){if(x instanceof TypeError)captures++;}}
function firstReject(e){e(undefined,function(){calls++;});try{e(function(){calls++;},function(){calls++;});}catch(x){if(x instanceof TypeError)captures++;}}
function badResolve(e){e(7,function(){calls++;});}
function badReject(e){e(function(){calls++;},7);}
var constructors=[firstResolve,firstReject,badResolve,badReject];
for(var i=0;i<constructors.length;i++){try{Promise.resolve.call(constructors[i],1);}catch(x){if(x instanceof TypeError)outer++;}}
""".strip()
synchronous=r"""
var token={},seen=0,wrong=0;
function ResolveThrow(e){e(function(){throw token;},function(){wrong++;});return {};}
function RejectThrow(e){e(function(){wrong++;},function(){throw token;});return {};}
try{Promise.resolve.call(ResolveThrow,1);}catch(x){if(x===token)seen++;}
try{Promise.reject.call(RejectThrow,1);}catch(x){if(x===token)seen++;}
""".strip()
reject_job=r"""
var log='',token={};function C(e){e(function(){log+='R';},function(){log+='J';throw token;});return {};}
var p=Promise.reject(token);p.constructor={};p.constructor[Symbol.species]=C;
p.then(undefined,function(e){log+='H';throw e;});queueMicrotask(function(){log+='Q';});log+='S';
""".strip()
report='Uncaught Promise job exception: uncaught exception: [object Object]'
groups.append({'name':requirements[3]['id'],'origin':'reviewed capture matrix and resolve-job script; bounded static/reject-job counterparts','rows':[
 {'script':capture,'after_checkpoint_expression':"captures+'|'+outer+'|'+calls",'expected':'2|4|0','console':[]},
 {'script':synchronous,'after_checkpoint_expression':"seen+'|'+wrong",'expected':'2|0','console':[]},
 {'script':requirements[3]['job_script'],'after_checkpoint_expression':'log','expected':'SHRQ','console':[report]},
 {'script':reject_job,'after_checkpoint_expression':'log','expected':'SHJQ','console':[report]},
]})
surface=r"""
function check(v){if(!v)throw new Error('Promise selected descriptor surface');}
function data(o,k,v,w,e,c){var d=Object.getOwnPropertyDescriptor(o,k);check(d.value===v&&d.writable===w&&d.enumerable===e&&d.configurable===c);}
var P=Promise,proto=P.prototype;
data(window,'Promise',P,true,false,true);check(P===globalThis.Promise);
check(Object.getPrototypeOf(P)===Function.prototype&&Object.getPrototypeOf(proto)===Object.prototype);
data(P,'name','Promise',false,false,true);data(P,'length',1,false,false,true);data(P,'prototype',proto,false,false,false);
data(P,'resolve',P.resolve,true,false,true);data(P,'reject',P.reject,true,false,true);
data(proto,'constructor',P,true,false,true);data(proto,'then',proto.then,true,false,true);
data(proto,Symbol.toStringTag,'Promise',false,false,true);
check(Object.getOwnPropertyNames(P).join(',')==='length,name,prototype,resolve,reject');
check(Object.getOwnPropertyNames(proto).join(',')==='constructor,then');
check(Object.getOwnPropertySymbols(P).length===1&&Object.getOwnPropertySymbols(P)[0]===Symbol.species);
check(Object.getOwnPropertySymbols(proto).length===1&&Object.getOwnPropertySymbols(proto)[0]===Symbol.toStringTag);
var species=Object.getOwnPropertyDescriptor(P,Symbol.species);check(species.set===undefined&&!species.enumerable&&species.configurable);
var marker={};check(species.get.call(marker)===marker&&species.get.call(null)===null&&species.get.call(undefined)===undefined);
var rows=[[P.resolve,'resolve',1],[P.reject,'reject',1],[proto.then,'then',2],[species.get,'get [Symbol.species]',0]];
var refused=0;
for(var i=0;i<rows.length;i++){var f=rows[i][0];check(Object.getPrototypeOf(f)===Function.prototype);check(Object.getOwnPropertyNames(f).join(',')==='length,name');check(Object.getOwnPropertySymbols(f).length===0);data(f,'length',rows[i][2],false,false,true);data(f,'name',rows[i][1],false,false,true);check(Object.getOwnPropertyDescriptor(f,'prototype')===undefined);try{new f();}catch(x){if(x instanceof TypeError)refused++;}for(var j=0;j<i;j++)check(f!==rows[j][0]);}
check(P.resolve===rows[0][0]&&P.reject===rows[1][0]&&proto.then===rows[2][0]);
check(Object.prototype.toString.call(proto)==='[object Promise]');
""".strip()
branding=r"""
var failures=0,poison=0;
function typeError(f){try{f();}catch(x){if(x instanceof TypeError)failures++;}}
typeError(function(){Promise(function(){});});typeError(function(){new Promise(7);});
var forged=Object.create(Promise.prototype);
Object.defineProperty(forged,'constructor',{get:function(){poison++;throw 7;}});
Object.defineProperty(Promise.prototype,'constructor',{get:function(){poison++;throw 7;},configurable:true});
typeError(function(){Promise.prototype.then.call(forged);});typeError(function(){Promise.prototype.then.call(Promise.prototype);});
""".strip()
species_cases=r"""
var P=Promise,p=P.resolve(1),token={},seen=0,wrong=0;
Object.defineProperty(p,'constructor',{get:function(){throw token;},configurable:true});
try{p.then(function(){wrong++;});}catch(x){if(x===token)seen++;}
var marker={};Object.defineProperty(marker,Symbol.species,{get:function(){throw token;},configurable:true});
Object.defineProperty(p,'constructor',{value:marker,writable:true,configurable:true});
try{p.then(function(){wrong++;});}catch(x){if(x===token)seen++;}
Object.defineProperty(marker,Symbol.species,{value:{},writable:true,configurable:true});
try{p.then();}catch(x){if(x instanceof TypeError)seen++;}
p.constructor=7;try{p.then();}catch(x){if(x instanceof TypeError)seen++;}
p.constructor={};p.constructor[Symbol.species]=null;var nullChild=p.then();
p.constructor={};p.constructor[Symbol.species]=undefined;var undefinedChild=p.then();
p.constructor=undefined;window.Promise=17;var noConstructorChild=p.then();window.Promise=P;
var defaults=Object.getPrototypeOf(nullChild)===P.prototype&&Object.getPrototypeOf(undefinedChild)===P.prototype&&Object.getPrototypeOf(noConstructorChild)===P.prototype;
""".strip()
newtarget=r"""
var log='',executorOK=false,handlerOK=false,poison=0,custom={};
var Alt=(function(){}).bind(null);
Object.defineProperty(Alt,'prototype',{get:function(){log+='P';return custom;}});
try{Reflect.construct(Promise,[7],Alt);}catch(x){if(x instanceof TypeError)log+='I';}
var ignored={};Object.defineProperty(ignored,'then',{get:function(){poison++;throw 7;}});
var p=Reflect.construct(Promise,[function(r,j){'use strict';log+='E';executorOK=this===undefined&&arguments.length===2;r(8);return ignored;}],Alt);
var changedPrototype=Object.getPrototypeOf(p)===custom;
Promise.prototype.then.call(p,function(v){'use strict';log+='H';handlerOK=this===undefined&&arguments.length===1&&v===8;});
function Other(){}Other.prototype=7;var fallback=Reflect.construct(Promise,[function(){}],Other);
var fallbackOK=Object.getPrototypeOf(fallback)===Promise.prototype;
""".strip()
callbacks=r"""
function check(v){if(!v)throw new Error('Promise callback identity');}
var r1,j1,r2,j2,a=0,b=0;
var p1=new Promise(function(r,j){r1=r;j1=j;});var p2=new Promise(function(r,j){r2=r;j2=j;});
var fs=[r1,j1,r2,j2];for(var i=0;i<fs.length;i++){check(fs[i].name===''&&fs[i].length===1);check(Object.getOwnPropertyDescriptor(fs[i],'prototype')===undefined);for(var k=0;k<i;k++)check(fs[i]!==fs[k]);}
var refused=0;for(var n=0;n<fs.length;n++){try{new fs[n]();}catch(x){if(x instanceof TypeError)refused++;}}
check(r1.call({wrong:true},11)===undefined);check(j1.apply(null,[22])===undefined);
var bound=r2.bind({wrong:true});check(bound(33)===undefined);check(j2.call(undefined,44)===undefined);
try{new bound();}catch(x){if(x instanceof TypeError)refused++;}
p1.then(function(v){a=v;});p2.then(function(v){b=v;});
var captures=[],received=0,target={};function C(e){captures.push(e);e.call({wrong:true},function(v){received+=v;},function(){received=-99;});return target;}
check(Promise.resolve.call(C,5)===target);check(Promise.resolve.call(C,7)===target);
check(captures[0]!==captures[1]);for(var z=0;z<captures.length;z++){check(captures[z].name===''&&captures[z].length===2);check(Object.getOwnPropertyDescriptor(captures[z],'prototype')===undefined);try{new captures[z]();}catch(x){if(x instanceof TypeError)refused++;}}
""".strip()
groups.append({'name':requirements[4]['id'],'origin':'finite selected-surface, brand, species, NewTarget and generated-callback controls','rows':[
 {'script':surface,'after_checkpoint_expression':'refused','expected':4,'console':[]},
 {'script':branding,'after_checkpoint_expression':"failures+'|'+poison",'expected':'4|0','console':[]},
 {'script':species_cases,'after_checkpoint_expression':"seen===4&&wrong===0&&defaults",'expected':True,'console':[]},
 {'script':newtarget,'after_checkpoint_expression':"log==='IPEH'&&executorOK&&handlerOK&&changedPrototype&&fallbackOK&&poison===0",'expected':True,'console':[]},
 {'script':callbacks,'after_checkpoint_expression':"a+'|'+b+'|'+received+'|'+refused",'expected':'11|33|12|7','console':[]},
]})
assert len(groups)==15
oracles={'status':'frozen_public_api_semantic_expectations_before_production','scope':'Selected constructor/then/resolve/reject/species only; single Window realm; no Promise catch/finally/combinators or resource tariff assertions.','groups':groups,'group_count':15,'script_rows':sum(len(g['rows']) for g in groups),'reporter':{'prefix':'Uncaught Promise job exception: ','prefix_utf8_bytes':32,'ordinary_rejection':'Handled rejection stays out of host console. Only abrupt custom-capability reaction jobs in the selected rows report.'},'baseline':'Existing public Runtime API compiles before Promise installation; no baseline result inferred. One execute call per original script, then a distinct pure observation after its checkpoint.','matrix_derivations':{'capture_failures':'Each partial first capture prevents replacement; both missing/noncallable final pairs produce TypeError before any callback.2 capture catches,4 outer errors,0 calls.','static_throws':'Custom resolve/reject throw original token synchronously;2 exact catches,0 opposite callbacks.','reject_job':'S synchronously; reaction handler H throws token; custom reject J throws token; host reports, Q follows.','newtarget':'Invalid executor I before prototype getter; valid construction P then synchronous E, eventual reaction H. Executor return ignored.','callback_matrix':'Four resolving functions plus bound resolver plus two capability executors refuse construction =>7; captured promises settle11/33 and custom static resolve callbacks sum12.','descriptor_scope':'Own-key rosters intentionally match the selected incomplete bootstrap ledger, not a browser Promise with all methods.'}}
(o/'oracles.json').write_text(json.dumps(oracles,indent=2)+'\n')
def rust_value(v):
 if isinstance(v,bool):return 'Value::Bool('+str(v).lower()+')'
 if isinstance(v,int):return f'Value::Number({v}.0)'
 return 'Value::String('+json.dumps(v)+'.into())'
def raw(s):assert '"###' not in s;return 'r###"'+s+'"###'
s='''//! Public-API Promise semantic literals frozen before production.
use super::*;

fn observe(script: &str, expression: &str, expected: Value, entry: Option<Value>, console: &[&str]) {
    let mut runtime = Runtime::try_new().unwrap();
    let mut document = Document::parse("");
    let completion = runtime.execute(script, &mut document).unwrap();
    if let Some(expected) = entry { assert_eq!(completion, expected); }
    assert_eq!(runtime.execute(expression, &mut document).unwrap(), expected);
    assert_eq!(runtime.console.iter().map(String::as_str).collect::<Vec<_>>(), console);
}
'''
for g in groups:
 s+='\n#[test]\nfn promise_'+g['name']+'() {\n'
 for row in g['rows']:
  entry='Some('+rust_value(row['entry_result'])+')' if 'entry_result' in row else 'None'
  consoles='&['+', '.join(json.dumps(x) for x in row['console'])+']'
  s+='    observe('+raw(row['script'])+', '+raw(row['after_checkpoint_expression'])+', '+rust_value(row['expected'])+', '+entry+', '+consoles+');\n'
 s+='}\n'
(o/'raw/src/script/promise_semantic_tests.rs').write_text(s)
print('authored fifteen external groups; no project code execution')
