from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path(__file__).resolve().parent;W=R/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p):return json.loads(p.read_text())
up=js(R/'upstream-before.json');local=js(R/'local-before.json')
assert up['counts']=={'passed':46,'failed':154,'unsupported':16}
assert up['mode_cases']==216 and not up['harness_preflight_passed']
assert len(up['harness_preflight'])==52 and sum(x['verified'] for x in up['harness_preflight'])==36
assert local['summary']=={'case_matches':0,'case_total':28,'control_matches':4,'controls_verified':4,'control_total':20,'runner_errors':0}
assert not local['binding_failures']
assert up['binary_sha256']==local['binary_sha256']==js(R/'before-adapter.json')['sha256']
assert js(R/'validation/test262-protocols-2.json')['exit']==0
assert 'Ran 276 tests' in (R/'validation/test262-protocols-2.log').read_text()
labels=['local-source-verify','local-before','upstream-offline-import','upstream-before','test262-protocols-1','test262-protocols-2']
for label in ['local-before','upstream-before','test262-protocols-1']:assert js(R/'validation'/(label+'.json'))['exit']==1
roots=['before-adapter.json','local-before.json','upstream-before.json','typedarray-ci-observation-2.json','run-tool.py','package-preparation.py']
dirs=['fixtures','local-runner','upstream-discovery','upstream-profile']
paths=[p for d in dirs for p in (R/d).rglob('*') if p.is_file()]+[R/n for n in roots]+[R/'validation'/(label+suffix) for label in labels for suffix in ['.log','.json']]
assert all(not p.is_symlink() for p in paths)
rows=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(paths))]
manifest={'format':1,'scope':'Reflect property corpus preparation and published-engine before observations; no runtime implementation result','files':rows}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
out=W/'docs/evidence/reflect-properties-preparation.tar.gz'
with out.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,data in [('manifest.json',raw)]+[(row['path'],(R/row['path']).read_bytes()) for row in rows]:
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
modified=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],cwd=W,text=True).splitlines()
public={rel:sha(W/rel) for rel in modified if (W/rel).is_file() and (rel.startswith(('tools/','tests/upstream/test262-reflect-properties/','tests/conformance/reflect-properties-local/')) or rel in {'docs/reflect-properties-test262.md','tests/conformance/reflect-properties-local-before.json','tests/conformance/test262-reflect-properties-before.json'})}
record={'format':1,'status':'Frozen Reflect property test preparation; methods remain absent in the published before engine; full browser goal remains incomplete','base':'b4ce6570f42ab4f45862cc29445a4181d5dafec5','revision':up['revision'],'before_adapter':js(R/'before-adapter.json'),'upstream':{'source_files':108,'modes':216,'counts':up['counts'],'controls_verified':36,'control_modes':52,'harness_healthy':False,'exit':1,'report':'tests/conformance/test262-reflect-properties-before.json','sha256':sha(R/'upstream-before.json'),'note':'Invalid-target cases can pass when calling an absent method also throws TypeError; unhealthy preflight prevents a compatibility claim.'},'local':{'summary':local['summary'],'binding_failures':[],'exit':1,'report':'tests/conformance/reflect-properties-local-before.json','sha256':sha(R/'local-before.json')},'protocol_tests':{'groups':276,'passing_run':'validation/test262-protocols-2.json','retained_first_failure':'Three newly registered profile exclusion omissions; no old corpus or oracle changes. Full failed run retained.'},'public_file_sha256':public,'archive':{'path':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'records':len(rows),'manifest_sha256':hashlib.sha256(raw).hexdigest()},'limits':['No Rust runtime change in this preparation commit.','All108 original bodies and both modes retained;16 Proxy modes explicitly unsupported.','Existing profiles, policies and committed baseline reports retained.','The before executable is byte-identical to the independently validated published TypedArray adapter.','No conformance, production-security or Chromium-performance completion claim.']}
dest=W/'docs/evidence/reflect-properties-preparation.json'
with dest.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
stage=sorted([*public,'docs/evidence/reflect-properties-preparation.tar.gz','docs/evidence/reflect-properties-preparation.json'])
(R/'preparation-stage-paths.json').write_text(json.dumps(stage,indent=2)+'\n')
print(json.dumps({'archive':record['archive'],'evidence_sha256':sha(dest),'stage_paths':len(stage)},indent=2))
