"""Text-only source adaptation; never imports or runs project tools."""
import ast,difflib,hashlib,json,shutil
from pathlib import Path
A=Path('/tmp/eris-reflect-properties-1');P=A/'upstream-profile';W=A/'worktree';D=P/'draft';I=json.loads((A/'upstream-discovery/inventory.json').read_text())
def write(p,data):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data)
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
paths=['tools/import_test262.py','tools/test262_conformance.py','tools/test_test262_object_has_own.py','tools/test_test262_typedarray_foundation.py']
for rel in paths:write(P/'before'/rel,(W/rel).read_bytes())
s=(W/paths[0]).read_text()
constants='REFLECT_PROPERTY_DIRECTORIES = '+repr(I['directories'])+'\nREFLECT_PROPERTY_HELPERS = '+repr(set(I['helpers']))+'\n# Original auxiliary blobs authenticated independently against the pinned root/harness trees.\nREFLECT_PROPERTY_AUXILIARY_BLOBS = '+repr(I['auxiliary_blobs'])+'\n'
s=once(s,'ARRAY_DESCRIPTOR_DIRECTORIES =',constants+'ARRAY_DESCRIPTOR_DIRECTORIES =')
s=once(s,"TREE_PROFILES = {'typedarray-foundation',","TREE_PROFILES = {'reflect-properties', 'typedarray-foundation',")
s=once(s,"PROFILES = {'typedarray-foundation':","PROFILES = {'reflect-properties': REFLECT_PROPERTY_DIRECTORIES, 'typedarray-foundation':")
s=once(s,"PROFILE_ROOTS = {'typedarray-foundation':","PROFILE_ROOTS = {'reflect-properties': 'test/built-ins', 'typedarray-foundation':")
s=once(s,"def profile_tree_inventory(profile, read=None):\n","def profile_tree_inventory(profile, read=None):\n    if profile == 'reflect-properties':\n        listings, proof, description = git_tree_inventory(\n            REFLECT_PROPERTY_DIRECTORIES, 'test/built-ins', read)\n        description['auxiliary_blobs'] = REFLECT_PROPERTY_AUXILIARY_BLOBS.copy()\n        return listings, proof, description\n")
s=once(s,"    if profile == 'typedarray-foundation' and harness != TYPEDARRAY_HELPERS:","    if profile == 'reflect-properties' and harness != REFLECT_PROPERTY_HELPERS:\n        raise ValueError('Reflect property requested harness differs from the frozen five helpers')\n    if profile == 'typedarray-foundation' and harness != TYPEDARRAY_HELPERS:")
s=once(s,"    if profile in {'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:","    if profile in {'reflect-properties', 'date', 'typedarray-foundation'} or profile in ITERATION_SUBTREES:")
s=once(s,"    scope = {\n","    scope = {\n        'reflect-properties': 'all 108 original .js files in nine complete Reflect property method trees plus three direct Reflect object tests; full pinned Git-tree inventories; Proxy originals retained for explicit policy exclusion; no implementation',\n")
write(D/paths[0],s.encode())
s=(W/paths[1]).read_text()
s=once(s,"TYPEDARRAY_FEATURES = DATA_VIEW_FEATURES", "REFLECT_PROPERTY_FEATURES = {'Reflect', 'Reflect.set', 'Reflect.setPrototypeOf',\n                             'Reflect.construct', 'Symbol', 'Symbol.toStringTag', 'arrow-function'}\nTYPEDARRAY_FEATURES = DATA_VIEW_FEATURES")
s=once(s,"PROFILE_FEATURES = {'typedarray-foundation':","PROFILE_FEATURES = {'reflect-properties': REFLECT_PROPERTY_FEATURES, 'typedarray-foundation':")
s=once(s,"    if profile in {'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:","    if profile in {'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:")
s=once(s,"        if profile in {'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys() != (","        if profile in {'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys() != (")
start=s.index('def typedarray_foundation_preflight_variants():');end=s.index('\n\ndef object_has_own_preflight_variants',start)
new=s[start:end].replace('typedarray_foundation','reflect_property').replace('typedarray-foundation','reflect-properties').replace('TypedArray','Reflect property').replace('3abcef539581ee96beae6314a287408a6d90780da055263ee6447b87b2cbb888','c29babfc2d1f8db802e2cbdde1dfbd95038023cbe1a1704a34caaab4914dcf13')
s=s[:start]+new+'\n\n'+s[start:]
s=once(s,"    if profile == 'typedarray-foundation':\n        variants += typedarray_foundation_preflight_variants()","    if profile == 'reflect-properties':\n        variants += reflect_property_preflight_variants()\n    if profile == 'typedarray-foundation':\n        variants += typedarray_foundation_preflight_variants()")
s=once(s,"            if profile == 'typedarray-foundation' and name.startswith('typedarray-foundation-'):","            if ((profile == 'reflect-properties' and name.startswith('reflect-properties-'))\n                    or (profile == 'typedarray-foundation' and name.startswith('typedarray-foundation-'))):")
start=s.index("    if profile == 'typedarray-foundation':\n        # Preserve")
end=s.index("    if profile == 'object-has-own':\n        # Preserve",start)
s=s[:start]+s[start:end].replace('typedarray-foundation','reflect-properties')+s[start:]
write(D/paths[1],s.encode())
s=(W/paths[2]).read_text();s=once(s,"set(runner.PROFILES) - {'typedarray-foundation'}","set(runner.PROFILES) - {'typedarray-foundation', 'reflect-properties'}");s=once(s,"capture_contracts(excluded={'typedarray-foundation', PROFILE})","capture_contracts(excluded={'typedarray-foundation', 'reflect-properties', PROFILE})");write(D/paths[2],s.encode())
s=(W/paths[3]).read_text();s=once(s,"self.assertEqual(len(runner.PROFILES), 46)","self.assertEqual(len(runner.PROFILES), 47)");write(D/paths[3],s.encode())
write(D/'tools/reflect-properties-controls.json',(A/'fixtures/controls.json').read_bytes())
for rel in paths:
 a=(P/'before'/rel).read_text();b=(D/rel).read_text();ast.parse(b)
 write(P/'diffs'/(Path(rel).name+'.diff'),''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+rel,tofile='draft/'+rel)).encode())
print('Drafted two tools, two registration-only test migrations, exact control copy. No tool import/execution.')
