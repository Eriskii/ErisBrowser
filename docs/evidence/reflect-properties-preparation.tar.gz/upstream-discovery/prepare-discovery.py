"""Retain fetched source data and independently enumerate metadata; no project import."""
import collections, hashlib, json, re, shutil
from pathlib import Path
P=Path(__file__).parent
Q=Path('/tmp/eris-typedarray-fixtures-1/upstream')
REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
ROOT='91b2052adad1f066ae031e2ff3a1e9bd6d732886'
DIRS=['deleteProperty','get','getOwnPropertyDescriptor','getPrototypeOf','has','isExtensible','preventExtensions','set','setPrototypeOf']
def write(p,data):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(data)
def dump(p,data):write(p,(json.dumps(data,indent=2)+'\n').encode())
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def binding(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
proof=P/'proof'
for name in ['commit.json']+['tree-'+s+'.json' for s in [ROOT,'a2eada339f3c7e678edfc08497985f261a9ae258','b42c4a8f19ad479b70ee2f64ecd683735d83cde9','e7917cf01aee95d5ed85ba370c550d02cea533c7']]:write(proof/name,(Q/'proof'/name).read_bytes())
for row in json.loads((P/'tree-responses.json').read_text()):
 write(proof/('tree-'+row['sha']+'.json'),row['response']['structuredContent']['content'].encode())
trees={}
for p in proof.glob('tree-*.json'):
 data=json.loads(p.read_text()); assert data['truncated'] is False
 raw=[]
 for e in data['tree']:
  assert '/' not in e['path'] and e['path'] not in ('.','..')
  raw.append((e['path'].encode()+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha'])))
 body=b''.join(x[1] for x in sorted(raw)); assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==data['sha']
 trees[data['sha']]={x['path']:x for x in data['tree']}
commit=json.loads((proof/'commit.json').read_text()); assert commit['sha']==REV and commit['tree']['sha']==ROOT
root=trees[ROOT]; harness=trees[root['harness']['sha']]; built=trees[trees[root['test']['sha']]['built-ins']['sha']]; reflect=trees[built['Reflect']['sha']]
aux={}
for name in ['LICENSE','INTERPRETING.md']+['harness/'+x for x in ['assert.js','sta.js','propertyHelper.js','compareArray.js','isConstructor.js']]:
 sha=(harness[name[8:]] if name.startswith('harness/') else root[name])['sha']
 data=(Q/'original'/name).read_bytes();assert blob(data)==sha
 write(P/'originals'/name,data);aux[name]=sha
rows=[]; counts=collections.Counter(); features=collections.Counter(); helpers={'assert.js','sta.js'}
for directory in ['']+DIRS:
 tree=trees[reflect[directory]['sha']] if directory else reflect
 if directory:assert not any(x['type']=='tree' for x in tree.values())
 for name,e in sorted(tree.items()):
  if e['type']!='blob':continue
  assert name.endswith('.js') and '_FIXTURE' not in name
  relative='test/built-ins/Reflect/'+(directory+'/' if directory else '')+name
  p=P/'originals'/relative;data=p.read_bytes();assert blob(data)==e['sha']
  source=data.decode();assert source.count('/*---')==source.count('---*/')==1
  front=source.split('/*---')[1].split('---*/')[0]
  metadata={}
  for key in ['features','includes','flags','locale']:
   match=re.search('^'+key+r':\s*(\[[^\n]*\])$',front,re.M)
   if re.search('^'+key+':',front,re.M):assert match,(relative,key)
   metadata[key]=[x.strip() for x in match[1][1:-1].split(',') if x.strip()] if match else []
  assert not metadata['flags'] and not metadata['locale']
  assert not re.search(r'^(negative|timeout):',front,re.M)
  metadata['negative']=None
  helpers.update(metadata['includes']);features.update(metadata['features']);counts['Reflect'+('/'+directory if directory else '')]+=1
  rows.append(dict(path=relative,blob=e['sha'],bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),metadata=metadata,modes=['sloppy','strict'],declared_unsupported=['Proxy'] if 'Proxy' in metadata['features'] else []))
assert len(rows)==108 and helpers=={'assert.js','sta.js','propertyHelper.js','compareArray.js','isConstructor.js'}
assert sum(bool(r['declared_unsupported']) for r in rows)==8
inventory=dict(revision=REV,root_tree=ROOT,reflect_tree=built['Reflect']['sha'],directories=dict(sorted(counts.items())),sources=108,modes=216,declared_proxy_sources=8,declared_proxy_modes=16,features=dict(sorted(features.items())),helpers=sorted(helpers),auxiliary_blobs=aux,rows=rows,scope='all nine selected leaf method trees and all three direct Reflect object files; no outcome filtering')
dump(P/'inventory.json',inventory)
fetchmap={}
for p in proof.iterdir():
 route='commits/'+REV if p.name=='commit.json' else 'trees/'+p.name[5:-5]
 fetchmap['https://api.github.com/repos/tc39/test262/git/'+route]=binding(p)
for p in (P/'originals').rglob('*'):
 if p.is_file():fetchmap['https://raw.githubusercontent.com/tc39/test262/'+REV+'/'+str(p.relative_to(P/'originals'))]=binding(p)
dump(P/'fetch-map.json',fetchmap)
print(json.dumps({k:inventory[k] for k in ['sources','modes','directories','features','helpers','declared_proxy_modes']},indent=2))
