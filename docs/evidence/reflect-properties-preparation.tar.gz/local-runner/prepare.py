from pathlib import Path
import ast
import hashlib
import json
import shutil
import subprocess
import difflib

A = Path('/tmp/eris-reflect-properties-1')
W = A / 'worktree'
F = A / 'fixtures'
D = A / 'local-runner'
OUT = D / 'draft'
BASE = 'b4ce6570f42ab4f45862cc29445a4181d5dafec5'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('x', encoding='utf-8') as stream:
        stream.write(data)

def js(value):
    return json.dumps(value, indent=2) + '\n'

assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip() == BASE
hold = json.loads((F / 'source-ready.json').read_bytes())
for row in hold['files']:
    assert bind(Path(row['path']))['sha256'] == row['sha256']
    assert Path(row['path']).read_bytes() == Path(row['held_copy']).read_bytes()
source_paths = [
    'src/script.rs', 'src/script/typed_array.rs', 'src/script/typed_array/constructors.rs',
    'src/script/typed_array/index.rs', 'src/script/typed_array/intrinsics.rs',
    'src/script/array_buffer.rs', 'src/script/construction.rs', 'src/script/symbols.rs',
    'src/script/property_keys.rs', 'src/script/array_properties.rs', 'src/script/own_keys.rs',
    'src/script/object_integrity.rs', 'src/script/dom_own_properties.rs', 'src/script/iterators.rs',
]
bound = []
for rel in source_paths:
    data = subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=W)
    assert data == (W / rel).read_bytes()
    p = D / 'published-source' / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as out:
        out.write(data)
    bound.append(dict(relative_path=rel, sha256=digest(data), bytes=len(data), held_copy=str(p)))
base_receipt = dict(published_base=BASE, fixture_hold=bind(F / 'source-ready.json'),
                    unchanged_fixture_files=[bind(Path(r['path'])) for r in hold['files']],
                    source_files=bound,
                    note='Additive actual-published-base binding. Original context and fixture hold remain historical and byte-exact. Read-only Git/data operations; no engine.')
write(F / 'published-base.json', js(base_receipt))

corpus = OUT / 'tests/conformance/reflect-properties-local'
names = ['cases.js', 'controls.json', 'inventory.json', 'README.md', 'design.md', 'spec-notes.json', 'context.json']
files = []
for name in names:
    p = corpus / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('xb') as out:
        out.write((F / name).read_bytes())
    row = bind(p)
    files.append(dict(path=name, bytes=row['bytes'], sha256=row['sha256']))
pins = {r['path']: r['sha256'] for r in files}
manifest = dict(schema=1, origin='Independent frozen Reflect property fixtures',
                original_readiness_sha256=bind(F / 'source-ready.json')['sha256'],
                published_base=BASE, collection='reflectPropertyCases',
                case_count=14, case_modes=28, control_pairs=5, control_modes=20,
                case_invocation_arguments=[], ordinary_observation=dict(status='complete',phase='runtime',error_type='',error_identity='',return_value=True), files=files)
write(corpus / 'manifest.json', js(manifest))
prior_path = W / 'tools/typedarray_foundation_local.py'
old = prior_path.read_text()
write(D / 'typedarray_foundation_local.before.py', old)
s = old.replace('TypedArray cases', 'Reflect property cases').replace('typedarray-foundation-local', 'reflect-properties-local').replace('typedArrayFoundationCases', 'reflectPropertyCases')
a = s.index('PINS = {'); z = s.index('\nCOMPLETE =', a)
s = s[:a] + 'PINS = ' + json.dumps(pins, indent=4) + s[z:]
s = s.replace('(27, 54, 8, 32)', '(14, 28, 5, 20)')
a = s.index("    require(inventory['case_invocation_argument_by_mode']")
z = s.index("    names = inventory['cases']", a)
s = s[:a] + '''    require(manifest['case_invocation_arguments'] == [], 'zero-argument invocation changed')
    require(manifest['ordinary_observation'] == dict(COMPLETE, return_value=True),
            'case expectation changed')
    require(inventory['named_bodies'] == 14 and inventory['mode_cases'] == 28
            and inventory['modes'] == ['sloppy', 'strict'], 'inventory population changed')
''' + s[z:]
s = s.replace('len(set(names)) == 27', 'len(set(names)) == 14')
s = s.replace("controls['pairs'] == 8 and controls['control_modes'] == 32 and len(rows) == 16", "controls['pairs'] == 5 and controls['control_modes'] == 20 and len(rows) == 10")
s = s.replace("len(by_name) == 16", "len(by_name) == 10").replace("len({row['pair'] for row in rows}) == 8", "len({row['pair'] for row in rows}) == 5")
s = s.replace("positive['positive'] is True and positive['area'] == row['area']", "positive['positive'] is True and positive['pair'] == row['pair']")
a=s.index("        tail = ('if(actual!==")
z=s.index("        require(row['source'].endswith(tail)", a)
s=s[:a]+'''        tail = ('if(actual!==' + json.dumps(row['asserted_observation'])
                + ')throw new Error(' + json.dumps(row['pair'] + ' expectation') + ');')
        positive_tail = ('if(actual!==' + json.dumps(positive['asserted_observation'])
                         + ')throw new Error(' + json.dumps(row['pair'] + ' expectation') + ');')
'''+s[z:]
s=s.replace("                    argument = b'true' if mode == 'strict' else b'false'\n", '')
s=s.replace("+ b'(' + argument + b') !== true) '", "+ b'() !== true) '")
s=s.replace("identity.update(pair=row['pair'], positive=row['positive'], area=row['area'],", "identity.update(pair=row['pair'], positive=row['positive'],")
s=s.replace('== 86,', '== 48,').replace('cases=54, controls=32, rows=86', 'cases=28, controls=20, rows=48')
s=s.replace("scope='local TypedArray foundation, separate from upstream profile'", "scope='local Reflect property methods, separate from upstream profile'")
assert 'typedArrayFoundationCases' not in s and 'argument = b\'true\'' not in s
for name in ['digest','binding','require','matches']:
    def body(src):
        return next(n for n in ast.parse(src).body if isinstance(n,ast.FunctionDef) and n.name==name)
    assert ast.dump(body(old),include_attributes=False)==ast.dump(body(s),include_attributes=False)
write(OUT / 'tools/reflect_properties_local.py', s)
write(D / 'runner.diff', ''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='published/typedarray_foundation_local.py',tofile='draft/reflect_properties_local.py')))

# Reconstruct fingerprints independently as data; never import or run the runner.
fixture=(F/'cases.js').read_bytes(); inv=json.loads((F/'inventory.json').read_bytes()); controls=json.loads((F/'controls.json').read_bytes())
complete=dict(status='complete',phase='runtime',error_type='',error_identity='')
metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None)
matrix=[]
for kind,items in [('case',[dict(name=x) for x in inv['cases']]),('control',controls['controls'])]:
    for row in items:
        for mode in ['sloppy','strict']:
            source=(fixture+b'\nif (reflectPropertyCases.'+row['name'].encode()+b'() !== true) '+b'throw new Error("case did not return true");\n') if kind=='case' else row['source'].encode()
            source_sha=digest(source)
            fingerprint=digest(json.dumps(dict(source_sha256=source_sha,mode=mode,metadata=metadata,harness=[]),sort_keys=True,ensure_ascii=True).encode())
            identity=dict(id=row['name']+'#'+mode,mode=mode,kind=kind,source_sha256=source_sha,case_sha256=fingerprint,expected_observation=complete if kind=='case' else row['expected_observation'])
            if kind=='control':identity.update(pair=row['pair'],positive=row['positive'],partner=row['pair']+'-positive#'+mode)
            matrix.append(identity)
assert len(matrix)==len({r['id'] for r in matrix})==48
assert sum(r['kind']=='case' for r in matrix)==28
write(corpus/'matrix.json', js(matrix))
# Exact helper copies make the draft self-contained for root's later inert read.
# These are supporting dependencies, not proposed changes to the shared tools.
helpers=[]
for name in ['test262_conformance.py','html_conformance.py','import_test262.py']:
    src=W/'tools'/name;dst=OUT/'tools'/name
    dst.parent.mkdir(parents=True,exist_ok=True)
    with dst.open('xb') as stream:stream.write(src.read_bytes())
    assert subprocess.check_output(['git','show',BASE+':tools/'+name],cwd=W)==src.read_bytes()
    helpers.append(dict(bind(src),held_copy=str(dst)))
write(D/'helper-bindings.json',js(helpers))
write(D/'generation-checks.json',js(dict(status='source/data checks only; no runner/helper import or engine',matrix_rows=48,case_modes=28,control_modes=20,unchanged_core_functions=['digest','binding','require','matches'],helpers_exact_to_base=True,source_fixture_copies_exact=True)))
print(bind(F/'published-base.json'))
print(bind(OUT/'tools/reflect_properties_local.py'))
