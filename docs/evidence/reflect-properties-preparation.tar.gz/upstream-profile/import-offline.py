"""Root-owned execution entry: frozen-map-only import; no network or JS engine."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
A = Path('/tmp/eris-reflect-properties-1')
W = A / 'worktree'
MAP = A / 'upstream-discovery/fetch-map.json'
READY = A / 'upstream-profile/source-ready.json'
OUTPUT = W / 'tests/upstream/test262-reflect-properties'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if OUTPUT.exists():
        raise ValueError('fresh corpus output required')
    if digest(READY.read_bytes()) != '1585959681840d0400394495feaf015a25f1779ff499dd94d8802b7b63ba602c':
        raise ValueError('source hold changed')
    ready = json.loads(READY.read_bytes())
    expected = next(r['draft'] for r in ready['files'] if r['path'] == 'tools/import_test262.py')
    source = W / 'tools/import_test262.py'
    if digest(source.read_bytes()) != expected['sha256']:
        raise ValueError('integrated importer differs from held source')
    expected_map = next(r for r in ready['references'] if r['path'] == str(MAP))
    if digest(MAP.read_bytes()) != expected_map['sha256']:
        raise ValueError('fetch map changed')
    sources = json.loads(MAP.read_bytes())

    def fetch(url):
        row = sources[url]  # Any unknown URL refuses without a network fallback.
        data = Path(row['path']).read_bytes()
        if len(data) != row['bytes'] or digest(data) != row['sha256']:
            raise ValueError('frozen fetched bytes changed: ' + url)
        return data

    spec = importlib.util.spec_from_file_location('reflect_importer_held', source)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    with patch.object(module, 'fetch', side_effect=fetch):
        module.import_corpus(OUTPUT, 'reflect-properties')


if __name__ == '__main__':
    main()
