Reflect property upstream preparation is source-only and independent of candidate outcomes.

The full selected population is 108 original bodies / 216 mode cases: all sources in nine method leaves and three direct Reflect object tests. Five helpers plus LICENSE and INTERPRETING.md are original pinned bytes. Source selection and hashes are in ../upstream-discovery/inventory.json; fetch-map.json supports an entirely offline import without changing the importer. The map includes the 14 required Git-tree/commit proofs and a separate original harness-tree proof used to authenticate auxiliary pins during discovery.

The profile is reflect-properties. It adds 20 independently authored control modes to 32 unchanged common preflight modes: 52 total. Eight declared Proxy bodies / 16 modes remain explicitly unsupported. The other 200 modes are eligible, not predicted successful. All source tests and controls remain in reports when preflight is unhealthy. The local 48-row fixture remains separately reported.

The retained draft changes two shared tools, adds the exact controls file, seven mocked Python groups and one documentation chapter. Twelve old Python test files receive only registered-profile migration: eleven historical contract exclusions add reflect-properties (Object.hasOwn also excludes it from its old roster count), and TypedArray's current total count changes 46 to 47. Old source populations, features, helper identities, control expectations and baseline digests are unchanged. Before images and exact diffs are retained.

Discovery used pinned public GitHub blob/tree reads and Python file/AST/hash inspection only. No importer/runner import, protocol tests, compiler, engine or candidate observations were executed by this preparation author.

Root execution sequence after source review/integration:
1. Offline import using fetch-map.json, with every fetched file length/SHA checked and unknown URL refused; invoke importer.import_corpus(RW/tests/upstream/test262-reflect-properties, 'reflect-properties').
2. python3 -m unittest discover -s tools -p 'test_test262*.py'
3. python3 tools/test262_conformance.py --profile reflect-properties --binary <published-before-eris-js> --jobs 4 --timeout 3 --output <fresh-before-report.json>

The runner retains current baseline-recording policy; do not call a pre-implementation report a healthy baseline when its feature controls fail. Original source bytes and metadata must not change in response to observations. This preparation can be published before runtime implementation.
