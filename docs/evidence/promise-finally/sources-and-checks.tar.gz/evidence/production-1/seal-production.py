from pathlib import Path
import json,hashlib,difflib
A=Path('/tmp/eris-promise-finally-1');D=A/'production-1';P=Path('/tmp/eris-promise-finally-plan-1/concrete-1');W=A/'worktree'
def b(p):
 v=p.read_bytes();return {'path':str(p),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def put(p,v):
 with p.open('x') as f:json.dump(v,f,indent=2);f.write('\n')
m=json.loads((D/'draft-files.json').read_text())
for row in m['files']:
 for k in ['before','raw','diff']:
  if row[k]:assert b(Path(row[k]['path']))==row[k]
 old=Path(row['before']['path']).read_bytes() if row['before'] else b''
 new=Path(row['raw']['path']).read_bytes()
 assert ''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='a/'+row['target'] if row['before'] else '/dev/null',tofile='b/'+row['target']))==Path(row['diff']['path']).read_text()
 assert ((W/row['target']).read_bytes() if (W/row['target']).exists() else b'')==old
old=(D/'before/src/script/promises/semantics.rs').read_text();new=(D/'raw/src/script/promises/semantics.rs').read_text()
a='        if self.promise_id(&value)?.is_some() {';z='    fn promise_reject('
assert old[old.index(a):old.index(z)]==new[new.index(a):new.index(z)]
a='    pub(in crate::script) fn run_promise_job('
assert old[old.index(a):]==new[new.index(a):]
assert 'finally_layout_probe' not in (W/'src/script/promises.rs').read_text()
for row in json.loads((P/'migrations-before-1/source-ready-2.json').read_text())['files']:
 assert (D/'raw'/row['target']).read_bytes()==Path(row['raw']['path']).read_bytes()
for folder,p in [('quota-tests-before','src/script/promises/finally_quota_tests.rs'),('actual-layout-before','src/script/promises/finally_layout_tests.rs'),('public-tests-before-2','src/script/promise_finally_tests.rs')]:
 assert (D/'raw'/p).read_bytes()==(P/folder/p).read_bytes()
assert b(W/'src/script.rs')==m['preserved_script_registration']
notes={'status':'author_source_review_complete_unexecuted','API':b(P/'api-2.txt'),'ledger':b(P/'ledger-2.json'),'frozen_peer':b(P/'html-tests-review.json'),
 'semantic_checks':[
 'Promise.finally enters existing dynamic receiver dispatch, object check then SpeciesConstructor before callable classification; noncallable raw values clone twice after debit2 and pass through unchanged. Outer observable then sees original receiver and exact two arguments; no brand restriction.',
 'Factory borrows constructor/finalizer until all metadata succeeds. One immutable capture feeds two distinct CallbackKind/metadata IDs; later wrapper calls allocate separate immutable outcome capture/thunk. No gate consumption or callback identity alias.',
 'Capture/record/object growth envelope is prepaid before reserves; metadata101 fees remain staged. Only nonfallible final commit clones payloads and publishes private lengths/admitted capacities. Early/late failures keep logical private state unmodified; cumulative charges and unexposed bags may remain.',
 'Read12/10 prepays index/kind check, copies and temporary cleanup. Wrong IDs/kinds become sticky ResourceLimit. Neither reads nor callback dispatch mutate the capture, enabling repeated uses.',
 'Wrapper fixed8 then read12/argcopy1 precede Call(finalizer,undefined,zero args). Captured constructor goes to shared internal PromiseResolve; thunk creation follows successful resolution; then Get/Call is observable with one argument and correct receiver. No caller-provided receiver selects private capture state.',
 'Old PromiseResolve post-copy body is byte-identical inside extracted helper; public guard/copy fees are unchanged. Existing run_promise_job tail is byte-identical. ReturnValue/ThrowReason read exact payload; throws retain existing non-observing thrown_error work/heap and do not run diagnostic metadata getters.',
 'Installer creates finally bag after all old method IDs; property appended after catch before symbol tag. Shared17/standalone19 guards preserve allocation ordering; pool31 copies and metadata121+arena guard1 produce selected1116/1154/raw99995. Producer331 and borrowed bootstrap unchanged.',
 'No public/global method beyond Promise.prototype.finally, no queue job kind, limit increase, fresh-budget checkpoint, scheduler change or Promise combinator. Existing fatal observer wraps all new factory/read/public/callback failures.',
 'Fifteen public and seven quota groups plus actual-layout group copied exactly. Nine migration selections copied exactly, including held label correction. Public registration already exists; two private module registrations are added near top. Integration files are untouched.'
 ],
 'tariffs':{'factory_pair_warm_cold':[246,262],'factory_thunk_warm_cold':[127,143],'capture_reads':[12,10],'leaf_single_callback_return_throw':[20,21],'throw_heap_zero_units':512,'shared_installer':1116,'standalone_installer':1154,'raw_bootstrap':99995,'remaining_under_existing_cap':5},
 'layout':'Sixth empty Arena header, no capture backing at startup. Root mirrorF48/State224 is bound; actual final candidate and unchanged128KiB witnesses still require root compilation/execution. No observed final pass claimed.',
 'public_baseline': b(A/'baseline-result.json'),
 'parent_mirror_archive': b(A/'root/parent-layout-probe.rs'),
 'execution':'Inert text/hash/diff authoring only. No live source edits/imports, Rust/compiler/formatter/project tests/JS/browser or git.'}
put(D/'source-review-notes.json',notes)
sel={'status':'source_ready_external_unexecuted','parent':'3275179229f6d7753cedf0b66bd91998ada21707','frozen_selection':b(P/'source-ready-2.json'),'frozen_test_peer':b(P/'html-tests-review.json'),'source_review':b(D/'source-review-notes.json'),'files':m['files'],'preserved_script_registration':m['preserved_script_registration'],'counts':{'production_files':5,'old_migration_files':9,'new_private_test_files':2,'already_imported_public_test_files':1,'public_groups':15,'private_quota_groups':7,'actual_layout_groups':1},'import_policy':'Before bindings are exact current AM files after parent mirror removal. Public test raw is already identical live. Root owns import/formatter/compiler/tests. Leave integration and other source untouched.','execution':'No execution; production source peer requested before root import.'}
put(D/'source-ready.json',sel)
print(json.dumps(b(D/'source-ready.json')))
