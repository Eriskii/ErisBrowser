from pathlib import Path
import json,hashlib,difflib
A=Path('/tmp/eris-promise-finally-1'); W=A/'worktree'; D=A/'production-1'
P=Path('/tmp/eris-promise-finally-plan-1/concrete-1')
def one(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('xb') as f:f.write(s if isinstance(s,bytes) else s.encode())
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
raw={}
p='src/script/promises.rs';s=(W/p).read_text()
s=one(s,'mod factories;','mod factories;\n#[cfg(test)]\nmod finally_layout_tests;\n#[cfg(test)]\nmod finally_quota_tests;')
s=one(s,'pub(super) const METADATA_OBJECTS: usize = 7;','pub(super) const METADATA_OBJECTS: usize = 8;')
s=one(s,'    pub(super) jobs: Arena<Option<PromiseJob>>,\n    intrinsics:', '    pub(super) jobs: Arena<Option<PromiseJob>>,\n    finally_captures: Arena<FinallyCapture>,\n    intrinsics:')
s=one(s,'pub(super) struct CaptureId(pub(super) usize);','pub(super) struct CaptureId(pub(super) usize);\n#[derive(Clone, Copy, Debug, PartialEq, Eq)]\nstruct FinallyCaptureId(usize);')
s=one(s,'    CapabilityExecutor(CaptureId),\n}', '    CapabilityExecutor(CaptureId),\n    ThenFinally(FinallyCaptureId),\n    CatchFinally(FinallyCaptureId),\n    ReturnValue(FinallyCaptureId),\n    ThrowReason(FinallyCaptureId),\n}')
s=one(s,'pub(super) enum PromiseJob {','// Reusable callbacks retain immutable values; these are never one-shot gates.\nenum FinallyCapture {\n    Finalizer { constructor: Value, on_finally: Value },\n    Outcome(Value),\n}\n\npub(super) enum PromiseJob {')
raw[p]=s

p='src/script/promises/factories.rs';s=(W/p).read_text()
s=one(s,'enum FactoryExtra {',"enum FactoryExtra<'a> {")
s=one(s,'    Capture,\n}',"    Capture,\n    Finally(&'a Value, &'a Value),\n    Outcome(&'a Value),\n}")
s=one(s,'        extra: FactoryExtra,',"        extra: FactoryExtra<'_>,")
anchor='''            FactoryExtra::Capture => (
                10,
                growth_plan::<CapabilityCapture>(
                    self.promises.captures.records.len(),
                    self.promises.captures.admitted_capacity,
                    1,
                )?,
            ),'''
s=one(s,anchor,anchor+'''
            FactoryExtra::Finally(_, _) | FactoryExtra::Outcome(_) => (
                if matches!(extra, FactoryExtra::Finally(_, _)) { 14 } else { 11 },
                growth_plan::<FinallyCapture>(
                    self.promises.finally_captures.records.len(),
                    self.promises.finally_captures.admitted_capacity,
                    1,
                )?,
            ),''')
anchor='''                        CallbackKind::CapabilityExecutor(id) => {
                            id.0 < self.promises.captures.records.len()
                        }'''
s=one(s,anchor,anchor+'''
                        CallbackKind::ThenFinally(id) | CallbackKind::CatchFinally(id) => {
                            matches!(self.promises.finally_captures.records.get(id.0), Some(FinallyCapture::Finalizer { .. }))
                        }
                        CallbackKind::ReturnValue(id) | CallbackKind::ThrowReason(id) => {
                            matches!(self.promises.finally_captures.records.get(id.0), Some(FinallyCapture::Outcome(_)))
                        }''')
anchor='''            FactoryExtra::Capture => reserve_arena(&mut self.promises.captures, extra_plan)?,'''
s=one(s,anchor,anchor+'''
            FactoryExtra::Finally(_, _) | FactoryExtra::Outcome(_) => {
                reserve_arena(&mut self.promises.finally_captures, extra_plan)?;
            }''')
s=one(s,'                CallbackKind::CapabilityExecutor(_) => 2,','                CallbackKind::CapabilityExecutor(_) => 2,\n                CallbackKind::ReturnValue(_) | CallbackKind::ThrowReason(_) => 0,')
anchor='''            FactoryExtra::Capture => {
                self.promises.captures.records.push(CapabilityCapture {
                    resolve: Value::Undefined,
                    reject: Value::Undefined,
                });
                publish_arena(&mut self.promises.captures, extra_plan);
            }'''
s=one(s,anchor,anchor+'''
            FactoryExtra::Finally(constructor, on_finally) => {
                // All metadata exists before either retained payload is cloned.
                // The extra14 paid both clones, field moves and final releases.
                self.promises.finally_captures.records.push(FinallyCapture::Finalizer {
                    constructor: constructor.clone(),
                    on_finally: on_finally.clone(),
                });
                publish_arena(&mut self.promises.finally_captures, extra_plan);
            }
            FactoryExtra::Outcome(value) => {
                // Extra11 likewise covers the single immutable payload.
                self.promises.finally_captures.records.push(FinallyCapture::Outcome(value.clone()));
                publish_arena(&mut self.promises.finally_captures, extra_plan);
            }''')
anchor='    pub(super) fn callback_target(&mut self, native: &Native) -> Result<CallbackKind> {'
new='''    pub(super) fn new_finally_functions(
        &mut self,
        constructor: &Value,
        on_finally: &Value,
    ) -> Result<(Value, Value)> {
        let capture = FinallyCaptureId(self.promises.finally_captures.records.len());
        let result = self
            .build_promise_callbacks(
                [CallbackKind::ThenFinally(capture), CallbackKind::CatchFinally(capture)],
                FactoryExtra::Finally(constructor, on_finally),
            )
            .map(|[fulfilled, rejected]| (fulfilled, rejected));
        self.observe_microtask_failure(result)
    }

    pub(super) fn new_finally_thunk(
        &mut self,
        value: &Value,
        kind: ReactionKind,
    ) -> Result<Value> {
        let capture = FinallyCaptureId(self.promises.finally_captures.records.len());
        let kind = match kind {
            ReactionKind::Fulfill => CallbackKind::ReturnValue(capture),
            ReactionKind::Reject => CallbackKind::ThrowReason(capture),
        };
        let result = self
            .build_promise_callbacks([kind], FactoryExtra::Outcome(value))
            .map(|[value]| value);
        self.observe_microtask_failure(result)
    }

    pub(super) fn read_finally_finalizer(
        &mut self,
        id: FinallyCaptureId,
    ) -> Result<(Value, Value)> {
        let result = (|| {
            // Check8 plus two copies and their eventual temporary releases.
            self.work(12)?;
            let Some(FinallyCapture::Finalizer { constructor, on_finally }) =
                self.promises.finally_captures.records.get(id.0)
            else {
                return Err(invalid());
            };
            Ok((constructor.clone(), on_finally.clone()))
        })();
        self.observe_microtask_failure(result)
    }

    pub(super) fn read_finally_outcome(&mut self, id: FinallyCaptureId) -> Result<Value> {
        let result = (|| {
            // Check8 plus one copy and its eventual temporary release.
            self.work(10)?;
            let Some(FinallyCapture::Outcome(value)) =
                self.promises.finally_captures.records.get(id.0)
            else {
                return Err(invalid());
            };
            Ok(value.clone())
        })();
        self.observe_microtask_failure(result)
    }

'''+anchor
s=one(s,anchor,new);raw[p]=s

p='src/script/promises/semantics.rs';s=(W/p).read_text()
anchor='    fn promise_then(\n'
new='''    fn promise_finally(
        &mut self,
        receiver: Value,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        if !js_object(&receiver) {
            return Err(ScriptError::type_error("Promise.finally receiver is not an object"));
        }
        self.work(1)?;
        let constructor = self.promise_species_constructor(receiver.clone(), doc)?;
        let on_finally = args.first().unwrap_or(&Value::Undefined);
        // Species is observable even when a noncallable argument passes through.
        let (fulfilled, rejected) = if json_callable(on_finally) {
            self.new_finally_functions(&constructor, on_finally)?
        } else {
            self.work(2)?;
            (on_finally.clone(), on_finally.clone())
        };
        self.work(1)?;
        let method = self.promise_named_get(receiver.clone(), "then", doc)?;
        let arguments = self.promise_arguments([fulfilled, rejected])?;
        self.call(method, arguments, receiver, doc)
    }

'''+anchor
s=one(s,anchor,new)
anchor='''        let value = args.first().cloned().unwrap_or(Value::Undefined);
        if self.promise_id(&value)?.is_some() {'''
new='''        let value = args.first().cloned().unwrap_or(Value::Undefined);
        self.promise_resolve_with_constructor(constructor, value, doc)
    }

    // Internal PromiseResolve uses its captured constructor, never C.resolve
    // or the mutable global binding. The old public resolve body/fees stay here.
    fn promise_resolve_with_constructor(
        &mut self,
        constructor: Value,
        value: Value,
        doc: &mut Document,
    ) -> Result<Value> {
        if self.promise_id(&value)?.is_some() {'''
s=one(s,anchor,new)
s=one(s,'                "Promise.catch" => self.promise_catch(receiver, args, doc),','                "Promise.catch" => self.promise_catch(receiver, args, doc),\n                "Promise.finally" => self.promise_finally(receiver, args, doc),')
anchor='    pub(in crate::script) fn promise_callback(\n'
new='''    fn run_finally_callback(
        &mut self,
        capture: FinallyCaptureId,
        kind: ReactionKind,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        // Fixed orchestration and bounded temporary cleanup precede any copy.
        self.work(8)?;
        let (constructor, on_finally) = self.read_finally_finalizer(capture)?;
        self.work(1)?;
        let outcome = args.first().cloned().unwrap_or(Value::Undefined);
        let result = self.call(on_finally, Vec::new(), Value::Undefined, doc)?;
        let promise = self.promise_resolve_with_constructor(constructor, result, doc)?;
        let thunk = self.new_finally_thunk(&outcome, kind)?;
        self.work(1)?;
        let method = self.promise_named_get(promise.clone(), "then", doc)?;
        let arguments = self.promise_arguments([thunk])?;
        self.call(method, arguments, promise, doc)
    }

'''+anchor
s=one(s,anchor,new)
anchor='''                CallbackKind::CapabilityExecutor(capture) => {
                    self.store_capability_capture(capture, args)?;
                }'''
s=one(s,anchor,anchor+'''
                CallbackKind::ThenFinally(capture) => {
                    return self.run_finally_callback(capture, ReactionKind::Fulfill, args, doc);
                }
                CallbackKind::CatchFinally(capture) => {
                    return self.run_finally_callback(capture, ReactionKind::Reject, args, doc);
                }
                CallbackKind::ReturnValue(capture) => return self.read_finally_outcome(capture),
                CallbackKind::ThrowReason(capture) => {
                    let reason = self.read_finally_outcome(capture)?;
                    // The exact original payload is retained. Formatting uses
                    // the existing non-observing error path, not author getters.
                    return Err(self.thrown_error(reason)?);
                }''')
raw[p]=s

p='src/script/promises/install.rs';s=(W/p).read_text()
s=one(s,'ordering and all ten','ordering and all eleven')
s=one(s,'        self.work(17)?;','        self.work(19)?;')
s=one(s,'publication and eight pool releases.','publication and nine pool releases.')
s=one(s,'        self.work(15)?;','        self.work(17)?;')
s=one(s,'            || !self.promises.jobs.records.is_empty()','            || !self.promises.jobs.records.is_empty()\n            || !self.promises.finally_captures.records.is_empty()')
s=one(s,'            self.dom_proto_text("catch")?,','            self.dom_proto_text("catch")?,\n            self.dom_proto_text("finally")?,')
s=one(s,'// 18 string keys, 6 display names, 1 prototype tag, 2 constructor handles.','// 21 string keys, 7 display names, 1 prototype tag, 2 constructor handles.')
s=one(s,'        self.work(27)?;','        self.work(31)?;')
s=one(s,'self.dom_proto_object(Some(Value::Object(object_prototype)), 4)?','self.dom_proto_object(Some(Value::Object(object_prototype)), 5)?')
s=one(s,'        let catch = self.promise_intrinsic_method("Promise.catch", pool[9].clone(), 1, keys)?;','        let catch = self.promise_intrinsic_method("Promise.catch", pool[9].clone(), 1, keys)?;\n        let finally = self.promise_intrinsic_method("Promise.finally", pool[10].clone(), 1, keys)?;')
anchor='''        self.dom_proto_property(
            prototype,
            tag,
            Property::data(Value::String(pool[2].clone()), false, false, true),
        )?;'''
s=one(s,anchor,'''        self.dom_proto_property(
            prototype,
            pool[10].clone().into(),
            Property::data(finally, true, false, true),
        )?;
'''+anchor)
raw[p]=s

p='src/script/machine/calls.rs';s=(W/p).read_text();s=one(s,'            | "Promise.catch"','            | "Promise.catch"\n            | "Promise.finally"');raw[p]=s

migrations=json.loads((P/'migrations-before-1/source-ready-2.json').read_text())
for row in migrations['files']:
 assert (W/row['target']).read_bytes()==Path(row['before']['path']).read_bytes(),row['target']
 raw[row['target']]=Path(row['raw']['path']).read_bytes()
for sub,path in [('quota-tests-before','src/script/promises/finally_quota_tests.rs'),('actual-layout-before','src/script/promises/finally_layout_tests.rs'),('public-tests-before-2','src/script/promise_finally_tests.rs')]:
 raw[path]=(P/sub/path).read_bytes()
rows=[]
for p,s in raw.items():
 data=s.encode() if isinstance(s,str) else s
 before=(W/p).read_bytes() if (W/p).exists() else None
 if before is not None:put(D/'before'/p,before)
 put(D/'raw'/p,data)
 diff=''.join(difflib.unified_diff((before or b'').decode().splitlines(True),data.decode().splitlines(True),fromfile='a/'+p if before is not None else '/dev/null',tofile='b/'+p))
 put(D/'diffs'/(p+'.patch'),diff)
 rows.append({'target':p,'status':'new' if before is None else ('selected_unchanged' if before==data else 'changed'),'before':bind(D/'before'/p) if before is not None else None,'raw':bind(D/'raw'/p),'diff':bind(D/'diffs'/(p+'.patch'))})
put(D/'draft-files.json',json.dumps({'status':'unexecuted_draft_pending_author_final_source_review','files':rows,'selected_tests':bind(P/'source-ready-2.json'),'test_peer':bind(P/'html-tests-review.json'),'preserved_script_registration':bind(W/'src/script.rs'),'execution':'No live edits/imports, compiler/formatter/project tests/browser/JS or git.'},indent=2)+'\n')
print(json.dumps(bind(D/'draft-files.json')))
