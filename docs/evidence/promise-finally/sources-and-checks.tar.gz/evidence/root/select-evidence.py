from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]


def bind(p):
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inventory = A / 'source-1.json'
sources = json.loads(inventory.read_text())['source_sha256']
assert len(sources) == 797
for name, sha in sources.items():
    assert bind(A / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['native-full-1', 'default-full-1', 'strict-stable-1', 'strict-msrv-1',
              'format-check-1', 'browser-final-build-1', 'references-final-1',
              'finally-focused-1', 'actual-layout-stable-1']:
    r = json.loads((A / 'validation' / (label + '.json')).read_text())
    assert r['exit'] == 0
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256']
    checks[label] = r
for name in ['formatted-source-review.json', 'validation-review.json']:
    assert json.loads((A / 'root' / name).read_text())['status'] in ['clear', 'clear_source_only']
totals = json.loads((A / 'root/full-suite-totals.json').read_text())
assert totals['native-full-1']['passed'] == 3190
assert totals['default-full-1']['passed'] == 2886
assert all(v['failed'] == v['ignored'] == 0 for v in totals.values())
reference = json.loads((A / 'root/reference-comparison-final.json').read_text())
assert reference['status'] == 'pass' and reference['pairs'] == 102 and reference['unchanged_pngs'] == 204
ci = json.loads((A / 'validation/parent-ci-final.json').read_text())
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 9
assert all(j['conclusion'] == 'success' for j in ci['jobs'])
artifacts = {}
for directory in ['plans', 'production-1', 'integration', 'validation', 'root', 'reftests-final']:
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and p.name not in ['selection-final.json', 'publication-verification.json']:
            assert not p.is_symlink() and '__pycache__' not in p.parts
            artifacts[str(p.relative_to(A))] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json']:
        artifacts[p.name] = bind(p)
for name in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/promise-finally.md']:
    artifacts['documentation/' + name] = bind(A / 'worktree' / name)
selection = {
    'source_inventory': bind(inventory), 'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': json.loads(inventory.read_text())['base'],
        'parent_ci': {'status': 'success', 'jobs': 9, 'receipt': bind(A / 'validation/parent-ci-final.json')},
        'scope': 'Promise.prototype.finally with observable species/then behavior, internal Promise resolution, reusable retained cleanup/outcome callbacks and the existing bounded microtask FIFO.',
        'source_inputs': 797,
        'new_test_groups': {'public_semantics': 15, 'private_resource_boundaries': 7, 'actual_layout': 1,
                            'Page': 1, 'confined_worker': 1, 'total': 25},
        'baseline': json.loads((A / 'baseline-result.json').read_text()),
        'history': {
            'old_test_migrations': 'Nine explicit existing-test files reflect one added method, one arena header, unchanged prior IDs and the selected startup ledger. Raw bootstrap assertion remains 99,995; no runtime allowance increased.',
            'public_test_addition': 'Original eleven cases retained byte-exact as a prefix of the held fifteen-case module before production.',
            'parent_layout_mirror': 'Parent-only inert mirror measured on both compilers and removed before production. Actual final types agree on both compilers.',
            'final_source': bind(inventory)
        },
        'checks': checks,
        'full_suite_totals': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k, v in totals.items()},
        'confined_worker_tests_per_full_suite': 89,
        'integration': {'groups': 2, 'frame_checks_per_group': 12, 'total_frame_checks': 24,
                        'archived_literal_rgba_frames': 12, 'archived_rgba_bytes': 1802496,
                        'initial_title': 'SFGQTMV7', 'clicked_title': 'SFGQTMV7ACKDB',
                        'oracle': 'Runtime assertions use fixed-coordinate literal rectangles. Archived RGBA is independently reconstructed from the same frozen geometry. CPU Canvas plus CPU packed-native interpretation; no new hardware observation.'},
        'references': {k: reference[k] for k in ['pairs', 'unchanged_pngs', 'parent_archive_sha256', 'report_sha256']},
        'reference_baseline': 'Published shared job metadata keys archive at 3275179229f6d7753cedf0b66bd91998ada21707.',
        'browser': json.loads((A / 'root/final-browser.json').read_text()),
        'resource_policy': {'bootstrap_allowance': 100000, 'raw_bootstrap_work': 99995, 'remaining': 5,
                            'producer_work': 331, 'shared_consumer_work': 1116, 'standalone_consumer_work': 1154,
                            'combined_work': 1447, 'startup_work_delta': 122,
                            'objects': 749, 'globals': 212, 'native_registry': 299, 'prototypes': 25,
                            'promise_arenas': 6, 'unchanged_limits': True, 'author_work': 100000,
                            'cumulative_heap_bytes': 8388608,
                            'callback_pair_work': {'warm': 246, 'cold': 262},
                            'outcome_thunk_work': {'warm': 127, 'cold': 143},
                            'capture_read_work': {'finalizer': 12, 'outcome': 10},
                            'state_bytes': 224, 'finally_capture_bytes': 48, 'runtime_bytes': 1776,
                            'width_scope': 'Observed x86_64 layouts on Rust 1.88.0 and 1.99.0.'},
        'limits': ['Resource fees are logical accounting, not measured instructions or resident allocator bytes.',
                   'Local authored tests, not new imported WPT/Test262 conformance results; current Test262 adapter still excludes async completion.',
                   'Promise combinators, async/await, full rejection notifications, multiple realms and garbage collection remain unfinished.',
                   'No Chromium performance comparison, complete compatibility or production-security claim.',
                   'Build caches reused; elapsed times are not cold-build measurements.']
    }
}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2)
    out.write('\n')
print(json.dumps({'sources': len(sources), 'artifacts': len(artifacts)}))
