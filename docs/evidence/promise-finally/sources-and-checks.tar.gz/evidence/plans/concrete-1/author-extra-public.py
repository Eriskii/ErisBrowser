from pathlib import Path
import json,hashlib
P=Path('/tmp/eris-promise-finally-plan-1');D=P/'concrete-1/public-tests-before-2'
D.mkdir(exist_ok=False)
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(s)
groups=[]
rows=[]
for setup, cleanup in [
 ('var p=Promise.resolve(7);',"throw token;"),
 ("var replacement={};Object.defineProperty(replacement,'then',{get:function(){throw token;}});var p=Promise.resolve(7);","return replacement;"),
 ("var p=Promise.reject(original);","return new Promise(function(resolve,reject){queueMicrotask(function(){reject(token);});});"),
 ("var replacement=Promise.resolve(9);Object.defineProperty(replacement,'constructor',{get:function(){throw token;}});var p=Promise.resolve(7);","return replacement;")]:
 script="var token={},original={},poison=0,ok=false;Object.defineProperty(token,'constructor',{get:function(){poison++;throw 91;}});"+setup+"p.finally(function(){"+cleanup+"}).then(function(){ok=false;},function(e){ok=e===token;});"
 rows.append({'script':script,'expression':'ok&&poison===0','expected':True,'console':[]})
groups.append({'name':'cleanup_abrupt_values_replace_both_fulfillment_and_rejection','rows':rows})
rows=[]
for literal in ['undefined','null','NaN','-0',"Symbol('outcome')",'{}']:
 for operation in ['resolve','reject']:
  script="var original="+literal+",ok=false;Promise."+operation+"(original).finally(function(){return 99;}).then("+('function(v){ok=Object.is(v,original);},function(){ok=false;}' if operation=='resolve' else 'function(){ok=false;},function(e){ok=Object.is(e,original);}')+");"
  rows.append({'script':script,'expression':'ok','expected':True,'console':[]})
groups.append({'name':'original_outcomes_use_same_value_after_successful_cleanup','rows':rows})
script="var saved=Promise.prototype.finally,poison=0,seen=0,same=0,expected,raw={};Object.defineProperty(raw,'then',{get:function(){poison++;throw 91;}});var symbol=Symbol('raw'),values=[undefined,null,7,raw,symbol];var receiver={constructor:undefined,then:function(a,b){'use strict';if(this===receiver&&arguments.length===2&&a===expected&&b===expected)seen++;return a;}};for(var i=0;i<values.length;i++){expected=values[i];if(saved.call(receiver,expected,'ignored')===expected)same++;}expected=undefined;if(saved.call(receiver)===undefined)same++;"
groups.append({'name':'generic_noncallable_and_omitted_values_are_forwarded_without_conversion','rows':[{'script':script,'expression':"seen+'|'+same+'|'+poison",'expected':'6|6|0','console':[]}]})
fatal={'name':'fatal_finalizer_keeps_fifo_suspended_and_fresh_realm_independent','script':"var log='';Promise.resolve(1).finally(function(){log+='F';while(true){};});queueMicrotask(function(){log+='!';});",'error':'ResourceLimit','after_sync_read':'F','suspended':True,'console':[],'later_sync_script':"log+='S';log;",'later_sync_result':'FS','fresh_script':"var log='';Promise.resolve(1).finally(function(){log+='F';}).then(function(){log+='R';});",'fresh_expression':'log','fresh_result':'FR'}
oracles={'status':'additive_literal_expectations_before_implementation_or_observation','preserves':bind(P/'concrete-1/public-tests-before/source-ready.json'),'groups':groups,'fatal':fatal,'group_total_added':4,'ordinary_rows_added':17,'claims':'No actual execution; original11 scripts and expectations remain exact.'}
put(D/'oracles.json',json.dumps(oracles,indent=2)+'\n')
s=(P/'concrete-1/public-tests-before/src/script/promise_finally_tests.rs').read_text()
def val(x):return 'Value::Bool(true)' if x is True else 'Value::String('+json.dumps(x)+'.into())'
for group in groups:
 s+='\n#[test]\nfn promise_finally_'+group['name']+'() {\n'
 for row in group['rows']:
  s+='    observe(\n        r###"'+row['script']+'"###,\n        r###"'+row['expression']+'"###,\n        '+val(row['expected'])+',\n        None,\n    );\n'
 s+='}\n'
s+='''
#[test]
fn promise_finally_fatal_finalizer_keeps_fifo_suspended_and_fresh_realm_independent() {
    let mut runtime = Runtime::try_new().unwrap();
    let mut document = Document::parse("");
    let error = runtime.execute(
        r###"'''+fatal['script']+'''"###,
        &mut document,
    ).unwrap_err();
    assert!(error.is_resource_limit());
    assert!(runtime.microtasks_suspended());
    assert_eq!(runtime.execute("log", &mut document).unwrap(), Value::String("F".into()));
    assert_eq!(runtime.execute("log+='S';log;", &mut document).unwrap(), Value::String("FS".into()));
    assert!(runtime.microtasks_suspended());
    assert!(runtime.console.is_empty());
    observe(
        r###"'''+fatal['fresh_script']+'''"###,
        "log",
        Value::String("FR".into()),
        None,
    );
}
'''
f=D/'src/script/promise_finally_tests.rs';put(f,s)
assert f.read_bytes().startswith((P/'concrete-1/public-tests-before/src/script/promise_finally_tests.rs').read_bytes())
manifest={'status':'frozen_additive_existing_API_tests_before_production','prior_hold':bind(P/'concrete-1/public-tests-before/source-ready.json'),'new_oracles':bind(D/'oracles.json'),'files':[bind(f)],'groups':15,'ordinary_rows':28,'fatal_groups':1,'preservation':'Original11-group module is an exact byte prefix; four additional groups pin17 ordinary rows and fatal suspension/fresh-realm control.','execution':'No execution/import/live source changes.'}
put(D/'source-ready.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(bind(D/'source-ready.json')))
