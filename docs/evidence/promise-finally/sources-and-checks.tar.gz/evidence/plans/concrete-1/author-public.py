from pathlib import Path
import hashlib,json
P=Path('/tmp/eris-promise-finally-plan-1'); D=P/'concrete-1/public-tests-before'
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(s)
def val(v):
 if isinstance(v,bool):return 'Value::Bool('+str(v).lower()+')'
 if isinstance(v,str):return 'Value::String('+json.dumps(v)+'.into())'
 raise AssertionError(v)
o=json.loads((P/'public-oracles.json').read_text())
s='''//! Promise.prototype.finally literals frozen before implementation or execution.
use super::*;

fn observe(script: &str, expression: &str, expected: Value, entry: Option<Value>) {
    let mut runtime = Runtime::try_new().unwrap();
    let mut document = Document::parse("");
    let completion = runtime.execute(script, &mut document).unwrap();
    if let Some(expected) = entry {
        assert_eq!(completion, expected);
    }
    assert_eq!(runtime.execute(expression, &mut document).unwrap(), expected);
    assert!(runtime.console.is_empty(), "{:?}", runtime.console);
}
'''
for group in o['groups']:
 s+='\n#[test]\nfn promise_finally_'+group['name']+'() {\n'
 for row in group['rows']:
  s+='    observe(\n        r###"'+row['script']+'"###,\n        r###"'+row['after_checkpoint_expression']+'"###,\n        '+val(row['expected'])+',\n        '+('Some('+val(row['entry_result'])+')' if 'entry_result' in row else 'None')+',\n    );\n'
 s+='}\n'
f=D/'src/script/promise_finally_tests.rs';put(f,s)
manifest={'status':'frozen_existing_API_semantic_tests_before_production','original_plan':binding(P/'source-ready.json'),'oracles':binding(P/'public-oracles.json'),'files':[binding(f)],'groups':11,'rows':11,'assertion_policy':'All script/expression/result strings equal original frozen proposal. Entry completion is checked where originally specified; retained log is read after the checkpoint. Fresh Runtime/Document per row; console empty.','registration':'Add #[cfg(test)] mod promise_finally_tests; near script.rs existing module declarations. Parent imports use only current Runtime APIs; no production methods needed.','expected_parent':'Missing finally produces TypeError/call failure or incorrect metadata; compilation should succeed. No actual baseline claimed.','execution':'Source-only generation; no live edit/import, compiler/formatter/tests/browser/JS/git.'}
put(D/'source-ready.json',json.dumps(manifest,indent=2)+'\n')
print(json.dumps(binding(D/'source-ready.json')))
