from pathlib import Path
import re,json,hashlib,difflib
D=Path('/tmp/eris-promise-finally-plan-1/concrete-1/migrations-before-1');W=Path('/tmp/eris-shared-job-keys-1/worktree')
D.mkdir(exist_ok=False)
def one(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def numbers(s,m):return re.sub(r'\b('+ '|'.join(re.escape(k) for k in m)+r')\b',lambda x:m[x[0]],s)
def put(p,s):
 p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:f.write(s)
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
rows=[]
def stage(p,s,why):
 old=(W/p).read_text();assert old!=s
 put(D/'before'/p,old);put(D/'raw'/p,s)
 diff=''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
 put(D/'diffs'/(p+'.patch'),diff)
 rows.append({'target':p,'reason':why,'before':bind(D/'before'/p),'raw':bind(D/'raw'/p),'diff':bind(D/'diffs'/(p+'.patch'))})
p='src/script/bootstrap_tests.rs';s=(W/p).read_text();s=one(s,'Promise with catch adds1032 standalone work and seven metadata bags.','Promise with finally adds1154 standalone work and eight metadata bags.');s=one(s,'assert_eq!(reference.steps, 127);','assert_eq!(reference.steps, 5);');s=one(s,'assert_eq!(reference.objects.len(), 748);','assert_eq!(reference.objects.len(), 749);');stage(p,s,'Finally metadata121+arena guard1; standalone1154,raw99995/remainder5,one new bag. Existing limit/reset assertions preserved.')
p='src/script/typed_array/tests.rs';s=(W/p).read_text();s=one(s,"// Promise's five arena headers/private cache and six eagerly reserved bags","// Promise's current arena headers/private cache and first six reserved bags");s=one(s,'    let catch_added = s + a + d + 3 * k + bpp + n + 1029;','    let catch_added = s + a + d + 3 * k + bpp + n + 1029;\n    // Finally adds one method; the current State term above includes its arena header.\n    let finally_added = s + a + d + 3 * k + bpp + n + 1047;');s=one(s,'            + 34\n','            + 34\n            - 122\n');s=one(s,'            - 168\n','            - 168\n            + finally_added\n');s=one(s,'(748, 748)','(749, 749)');stage(p,s,'Work-122; method/eager-slot heap+O+A+D+3K+L+N+1047. Existing size_of(State) absorbs new header once, no double charge. Counts749.')
p='src/script/processing_instruction/key_cache_tests.rs';s=(W/p).read_text();s=numbers(s,{'99873':'99995','99_872':'99_994','99_873':'99_995','127':'5','748':'749'});s=one(s,'Promise with catch standalone installation adds1032.','Promise with finally standalone installation adds1154.');stage(p,s,'Raw99994/99995,remaining5,objects749; cached PI saving332 and all getter checks preserved.')
p='src/script/dom_bindings/identity_tests.rs';s=one((W/p).read_text(),'assert_eq!(runtime.objects.len(), 748);','assert_eq!(runtime.objects.len(), 749);');stage(p,s,'Single realm object-count literal for one new method bag; native/prototype/DOM identities unchanged.')
p='src/script/promises/install_tests.rs';s=(W/p).read_text();s=one(s,'seven initial ScriptObject','eight initial ScriptObject');s=one(s,'7 * a + 7 * d + 20 * k + 7 * bpp + 6 * n + 4 * bsb + 7298','8 * a + 8 * d + 23 * k + 8 * bpp + 7 * n + 4 * bsb + 8345');s=one(s,'    empty!(jobs);','    empty!(jobs);\n    empty!(finally_captures);');s=one(s,'reserve seven additional','reserve eight additional');s=one(s,'try_reserve_exact(7)','try_reserve_exact(8)');s=one(s,'runtime.objects.len() + 7','runtime.objects.len() + 8');s=s.replace('exact1032_and_one_short1031','exact1154_and_one_short1153').replace('raw99873','raw99995');s=numbers(s,{'1032':'1154','1031':'1153','748':'749','755':'757','99_872':'99_994','99_873':'99_995','127':'5'});stage(p,s,'Standalone1154/1153 and typed heap; replay749+8=757; raw99995. Add sixth empty arena while retaining refusal/global-cache atomicity assertions.')
p='src/script/promise_semantic_tests.rs';s=one((W/p).read_text(),"'constructor,then,catch'","'constructor,then,catch,finally'");stage(p,s,'One Promise.prototype own-name roster addition only; every existing callable/then/species behavior literal unchanged.')
p='src/script/promises/shared_key_tests.rs';s=(W/p).read_text();s=one(s,'7 * a + 7 * d + 20 * k + 7 * l + 6 * n + 4 * b + 7130','8 * a + 8 * d + 23 * k + 8 * l + 7 * n + 4 * b + 8177');s=one(s,'    arena!(jobs);','    arena!(jobs);\n    arena!(finally_captures);');s=one(s,'try_reserve_exact(8)','try_reserve_exact(9)');s=s.replace('exact994','exact1116').replace('exact1325','exact1447').replace('99872/99873','99994/99995');s=numbers(s,{'748':'749','749':'750','756':'758','994':'1116','993':'1115','1325':'1447','1324':'1446'});s=one(s,'        _ => unreachable!(),','        6 => runtime.promises.finally_captures.records.push(FinallyCapture::Outcome(Value::Undefined)),\n        _ => unreachable!(),');s=one(s,'all_six_invalid_states','all_seven_invalid_states');s=one(s,'if shared { 15 } else { 17 }','if shared { 17 } else { 19 }');s=one(s,'for which in 0..6','for which in 0..7');s=one(s,'''        (false, 17, 0),
        (false, 36, 0),
        (false, 37, 88),
        (false, 52, 88),
        (false, 53, 168),
        (true, 15, 0),
        (true, 36, 0),
        (true, 37, 92),''','''        (false, 19, 0),
        (false, 38, 0),
        (false, 39, 88),
        (false, 54, 88),
        (false, 55, 168),
        (true, 17, 0),
        (true, 38, 0),
        (true, 39, 92),''');stage(p,s,'Producer331/prefixes/heap unchanged; new replay749->750->758,consumer1116/pair1447/heap, new seventh guard, original standalone/shared prefix ordering shifted2 fixed work.')
p='src/script/promises/shared_key_identity_tests.rs';s=(W/p).read_text();s=one(s,'    arena!(jobs);','    arena!(jobs);\n    arena!(finally_captures);');s=one(s,'all_seven_function_bags','all_eight_function_bags');s=numbers(s,{'748':'749'});s=one(s,'[740, 741, 743, 744, 745, 746, 747]','[740, 741, 743, 744, 745, 746, 747, 748]');s=one(s,'[740, 743, 744, 745, 746, 747]','[740, 743, 744, 745, 746, 747, 748]');s=one(s,"[P.prototype.catch,'catch',1]];","[P.prototype.catch,'catch',1],[P.prototype.finally,'finally',1]];");s=one(s,"'constructor,then,catch'","'constructor,then,catch,finally'");s=one(s,"&&P.prototype.catch.name==='catch';","&&P.prototype.catch.name==='catch'&&P.prototype.finally.name==='finally';");stage(p,s,'New function bag748 shares immutable length/name payloads; old IDs unchanged,objects749,eighth public reflection/mutation row, prototype roster appended. SQV7 and old descriptors remain.')
put(D/'draft-selection.json',json.dumps({'status':'eight_migrations_frozen_layout_migration_waits_for_root_measurement','files':rows,'pending':'src/script/promises/layout_tests.rs: no new numeric width invented before mirror. All original baseline files preserved; historical promise_layout_probe.rs and node_clone/tests.rs unchanged.','execution':'Source-only text generation; no live edits, compiler, formatter, tests/browser or git.'},indent=2)+'\n')
print(json.dumps(bind(D/'draft-selection.json')))
