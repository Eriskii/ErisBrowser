//! Source-held prospective types only; this does not initialize or execute finally.
#![allow(dead_code)]
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy)]
struct FinallyCaptureIdMirror(usize);
enum FinallyCaptureMirror {
    Finalizer { constructor: Value, on_finally: Value },
    Outcome(Value),
}
#[derive(Clone, Copy)]
enum CallbackKindMirror {
    Resolve(GateId),
    Reject(GateId),
    CapabilityExecutor(CaptureId),
    ThenFinally(FinallyCaptureIdMirror),
    CatchFinally(FinallyCaptureIdMirror),
    ReturnValue(FinallyCaptureIdMirror),
    ThrowReason(FinallyCaptureIdMirror),
}
struct CallbackRecordMirror {
    object_id: usize,
    kind: CallbackKindMirror,
}
struct StateMirror {
    promises: Arena<PromiseRecord>,
    gates: Arena<ResolveGate>,
    callbacks: Arena<CallbackRecordMirror>,
    captures: Arena<CapabilityCapture>,
    jobs: Arena<Option<PromiseJob>>,
    finally_captures: Arena<FinallyCaptureMirror>,
    intrinsics: Option<Intrinsics>,
}

#[test]
fn finally_prospective_layout_mirror_before_production() {
    macro_rules! row {
        ($name:literal, $ty:ty) => {
            println!("FINALLY_LAYOUT_MIRROR {} bytes={} align={}", $name, size_of::<$ty>(), align_of::<$ty>());
        };
    }
    row!("RuntimeParent", Runtime);
    row!("Value", Value);
    row!("ScriptObject", ScriptObject);
    row!("StateParent", State);
    row!("StateMirror", StateMirror);
    row!("FinallyCaptureMirror", FinallyCaptureMirror);
    row!("FinallyCaptureArenaMirror", Arena<FinallyCaptureMirror>);
    row!("CallbackKindParent", CallbackKind);
    row!("CallbackKindMirror", CallbackKindMirror);
    row!("CallbackRecordParent", CallbackRecord);
    row!("CallbackRecordMirror", CallbackRecordMirror);
    row!("PromiseJob", PromiseJob);
    row!("QueueJob", QueueJob);
    row!("MicrotaskState", microtasks::State);
    assert_eq!(size_of::<CallbackKindMirror>(), size_of::<CallbackKind>());
    assert_eq!(size_of::<CallbackRecordMirror>(), size_of::<CallbackRecord>());
    assert_eq!(size_of::<StateMirror>(), size_of::<State>() + size_of::<Arena<FinallyCaptureMirror>>());
}
