"""Author frozen literal oracle using only stdlib AST/data, never project execution."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
D = C / 'controls-1'
parent = C / 'readiness-1/parent/tools/test262_conformance.py'
def digest(data):
    return hashlib.sha256(data).hexdigest()
def ref(path):
    p = Path(path); b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=digest(b))
def save(name, value):
    p = D / name; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')
    return ref(p)

assert digest((C/'root/selection-1.json').read_bytes()) == 'ebd8ef75afa8744addbc57b4f51260212d0119807b39d84d5dcaabe74fc5479e'
selected = json.loads((C/'source-parent.json').read_text())
assert digest(parent.read_bytes()) == selected['source_sha256']['tools/test262_conformance.py']
module = ast.parse(parent.read_text())
function = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'aggregate_error_preflight_variants')
constants = {}
for node in function.body:
    if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name) and node.targets[0].id in ('common','strict_only'):
        constants[node.targets[0].id] = ast.literal_eval(node.value)
rows = []
def add(name, mode, source, expected, includes=(), prerequisites=(), mode_id=False):
    rows.append(dict(name=name, mode=mode, id='harness-preflight:'+name+(':'+mode if mode_id else ''),
                     source=source, metadata=dict(features=[], flags=[], includes=list(includes), locale=[], negative=None),
                     expected=expected, required_observation=dict(error_identity='', error_type='Test262Error' if expected=='failed' else '',
                     harness='', phase='runtime', status='exception' if expected=='failed' else 'complete'),
                     prerequisites=[list(p) for p in prerequisites]))
for mode, prefix in [('sloppy',''),('strict','strict-')]:
    for name, source, expected, prerequisite in constants['common']:
        add(prefix+name, mode, source, expected, ['propertyHelper.js'] if 'property-' in name else [],
            [(prefix+prerequisite,mode)] if prerequisite is not None else [])
for name, source in constants['strict_only']:
    add(name,'strict',source,'passed')
common_refs = [(row['name'],row['mode']) for row in rows]
assert len(rows) == 32
new = []
for family, old, changed in [
    ('generic', "assert.sameValue(count, 1, 'one generic constructor call');", "assert.sameValue(count, 2, 'one generic constructor call');"),
    ('genuine', "assert.sameValue(result.reject.length, 1, 'reject arity');", "assert.sameValue(result.reject.length, 2, 'reject arity');"),
    ('result', "verifyProperty(result, 'reject', {enumerable: true}, {restore: true});", "verifyProperty(result, 'reject', {enumerable: false}, {restore: true});"),
]:
    name = 'with-resolvers-'+family
    positive = (D/'literals'/f'{name}.js').read_text()
    assert positive.count(old) == 1
    mismatch = positive.replace(old, changed)
    (D/'literals'/f'{name}-mismatch.js').write_text(mismatch)
    (D/'literals'/f'{name}.pair.diff').write_text(''.join(difflib.unified_diff(positive.splitlines(True), mismatch.splitlines(True), fromfile=name+'.js', tofile=name+'-mismatch.js')))
    for suffix, source, expected in [('',positive,'passed'),('-mismatch',mismatch,'failed')]:
        for mode in ['sloppy','strict']:
            add(name+suffix,mode,source,expected,['propertyHelper.js'] if family=='result' else [],
                common_refs+([(name,mode)] if suffix else []),True)
            new.append((name+suffix,mode))
assert len(rows) == 44 and len(new) == 12
helpers = {name: (C/'readiness-1/auxiliary/harness'/name).read_bytes() for name in ['assert.js','sta.js','propertyHelper.js']}
cases = []
for row in rows:
    names = ['assert.js','sta.js'] + row['metadata']['includes']
    identity = dict(source_sha256=digest(row['source'].encode()), mode=row['mode'], metadata=row['metadata'],
                    harness=[dict(name=n,sha256=digest(helpers[n])) for n in names])
    case_sha = digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
    cases.append(dict(id=row['id'],file='<preflight>',mode=row['mode'],metadata=row['metadata'],source=row['source'],
                      harness=identity['harness'],case_sha256=case_sha,source_sha256=identity['source_sha256']))
known = json.loads((C/'ordinary-control-audit-1/common-control-identities.json').read_text())['records']
for row, case, expected in zip(rows[:32],cases[:32],known):
    actual = dict(name=row['name'],mode=row['mode'],id=row['id'],source_sha256=case['source_sha256'],case_sha256=case['case_sha256'],
                  expected=row['expected'],includes=row['metadata']['includes'],prerequisites=row['prerequisites'])
    assert actual == expected
def reference(i):
    row,case=rows[i],cases[i]
    return dict(name=row['name'],mode=case['mode'],id=case['id'],case_sha256=case['case_sha256'],source_sha256=case['source_sha256'],expected=row['expected'])
by_key = {(r['name'],r['mode']):i for i,r in enumerate(rows)}
outcomes=[]
for row,case in zip(rows,cases):
    observation=dict(row['required_observation'],message='')
    outcomes.append(dict(name=row['name'],expected=row['expected'],verified=True,
                         result=dict(id=case['id'],file=case['file'],mode=case['mode'],case_sha256=case['case_sha256'],source_sha256=case['source_sha256'],
                                     expected_negative=None,status=row['expected'],observation=observation),
                         prerequisites=[reference(by_key[tuple(key)]) for key in row['prerequisites']]))
oracle=dict(format=1,profile='promise-with-resolvers',features=['promise-with-resolvers'],base=selected['base'],
            variants=rows,cases=cases,healthy_outcomes=outcomes,
            helpers={name:dict(source=content.decode(),bytes=len(content),sha256=digest(content)) for name,content in helpers.items()},
            expected_counts=dict(Counter(r['expected'] for r in rows)),
            raw_contract=dict(fields=['status','phase','error_type','error_identity','message','harness'],field_type='str',maximum_utf8_bytes=16384,
                              message='Any bounded UTF-8 string; no exact serialized engine diagnostic required. Empty strings in synthetic observations are data-only gate witnesses.'),
            no_engine_execution=True)
oracle_ref=save('raw/tools/test262-with-resolvers-controls-oracle.json',oracle)
variants_ref=save('variants.json',rows)
contract=dict(status='frozen literal and canonical identity contract; no engine observations',base=selected['base'],
              APIs=['with_resolvers_preflight_variants()','with_resolvers_preflight_cases(files)','with_resolvers_preflight_reference(row, case)',
                    'with_resolvers_preflight_checks(outcomes, files)','with_resolvers_preflight_healthy(outcomes, files)','with_resolvers_harness_preflight(files, binary, timeout)'],
              counts=dict(common=32,new=12,total=44,expected=oracle['expected_counts']),
              schema='AggregateError variant/case/reference/observation conventions; no completion field or policy. Rows metadata.features remains[]; profile feature policy is separately selected.',
              prerequisites='Common edges exact. All12 new rows depend on all32 common rows in their frozen order; each of six mismatch-mode rows additionally depends on its matching-mode positive.',
              raw_gate='Exact outer/result/reference schemas and values, string-only bounded UTF-8 raw fields, exact required raw fields, recomputed ordinary classification. No verified flag shortcut. Malformed/unhashable nested values refuse without raising.',
              control_semantics={'generic':'Valid intrinsic capability then generic exact identities, zero eager calls, primitive and nonconstructible refusal; sole mismatch is constructor count1→2.',
                                 'genuine':'Intrinsic Promise and pending then receiver brand check without scheduling reactions; callable names/arity; sole mismatch is reject arity1→2.',
                                 'result':'Two fresh ordinary results, exact key order/data descriptors/capability identities, no eager calls; sole mismatch final enumerable true→false. Every verifyProperty uses restore:true.'},
              boundaries=['Function constructor controls do not replace the retained class original.','Pending then brand check is not async settlement coverage.',
                          'No new default intrinsic identity, host policy, helper or runtime support.','All12 original source rows blocked before dispatch if gate unhealthy; baseline recording refused.'],
              oracle=oracle_ref,variants=variants_ref)
contract_ref=save('contract.json',contract)
source_bindings=save('source-bindings.json',[ref(parent),ref(C/'source-parent.json'),ref(C/'root/selection-1.json'),
   ref(C/'ordinary-control-audit-1/review.json'),ref(C/'ordinary-control-audit-1/common-control-identities.json')]+[ref(C/'readiness-1/auxiliary/harness'/n) for n in helpers])
literal_files=[ref(p) for p in sorted((D/'literals').iterdir()) if p.is_file()]
save('literals-ready.json',dict(status='frozen',scope='Six new JS literals,44 exact expanded controls and independent metadata/helper fingerprints and synthetic raw-observation oracle; tests follow separately.',
                              contract=contract_ref,oracle=oracle_ref,variants=variants_ref,source_bindings=source_bindings,literals=literal_files,
                              author_script=ref(D/'derive-literals.py'),execution='AST literal evaluation/hash/JSON only; no project imports, engine execution or fetch'))
print(json.dumps(ref(D/'literals-ready.json'),indent=2))
