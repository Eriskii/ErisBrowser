assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');
var method = Promise.withResolvers;
var probe = method.call(Promise);
assert.sameValue(probe.promise instanceof Promise, true);
var promise = {}, count = 0, calls = 0;
function resolve(value) { calls++; return value; }
function reject(value) { calls++; return value; }
function C(executor) {
  assert.sameValue(typeof executor, 'function');
  count++;
  executor(resolve, reject);
  return promise;
}
var result = method.call(C);
assert.sameValue(result.promise, promise);
assert.sameValue(result.resolve, resolve);
assert.sameValue(result.reject, reject);
assert.sameValue(calls, 0);
var invalid = [undefined, null, false, 1, 'text', Symbol()];
for (var i = 0; i < invalid.length; i++) {
  assert.throws(TypeError, function () { method.call(invalid[i]); });
}
assert.throws(TypeError, function () { method.call(eval); });
assert.throws(TypeError, function () { method.call(method); });
assert.sameValue(count, 1, 'one generic constructor call');
