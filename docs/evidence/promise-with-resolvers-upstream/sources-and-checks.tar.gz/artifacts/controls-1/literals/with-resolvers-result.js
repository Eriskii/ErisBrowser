assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');
var promise = {}, calls = 0, constructors = 0;
function resolve(value) { calls++; return value; }
function reject(value) { calls++; return value; }
function C(executor) { constructors++; executor(resolve, reject); return promise; }
var result = Promise.withResolvers.call(C);
var again = Promise.withResolvers.call(C);
assert.notSameValue(result, again);
assert.sameValue(Object.getPrototypeOf(result), Object.prototype);
assert.sameValue(Object.getPrototypeOf(again), Object.prototype);
assert.compareArray(Object.getOwnPropertyNames(result), ['promise', 'resolve', 'reject']);
assert.compareArray(Object.keys(result), ['promise', 'resolve', 'reject']);
assert.sameValue(constructors, 2);
assert.sameValue(calls, 0);
var keys = ['promise', 'resolve', 'reject'];
var values = [promise, resolve, reject];
for (var i = 0; i < keys.length; i++) {
  var descriptor = Object.getOwnPropertyDescriptor(result, keys[i]);
  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'value'), true);
  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'get'), false);
  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'set'), false);
  assert.sameValue(again[keys[i]], values[i]);
  verifyProperty(result, keys[i], {value: values[i], writable: true,
    enumerable: true, configurable: true}, {restore: true});
}
assert.sameValue(calls, 0);
verifyProperty(result, 'reject', {enumerable: true}, {restore: true});
