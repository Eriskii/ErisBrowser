assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');
var result = Promise.withResolvers();
assert.sameValue(result.promise.constructor, Promise);
assert.sameValue(Object.getPrototypeOf(result.promise), Promise.prototype);
assert.sameValue(result.promise instanceof Promise, true);
var calls = 0;
var child = Promise.prototype.then.call(result.promise,
  function () { calls++; }, function () { calls++; });
assert.sameValue(child instanceof Promise, true);
assert.sameValue(calls, 0, 'pending promise has no handler calls');
assert.sameValue(typeof result.resolve, 'function');
assert.sameValue(typeof result.reject, 'function');
assert.sameValue(result.resolve.name, '');
assert.sameValue(result.reject.name, '');
assert.sameValue(result.resolve.length, 1);
assert.sameValue(result.reject.length, 1, 'reject arity');
