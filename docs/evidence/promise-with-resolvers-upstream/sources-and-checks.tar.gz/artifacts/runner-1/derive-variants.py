"""Extract inert AST literals and compose the externally proposed factory."""
from pathlib import Path
import ast, hashlib, json
R=Path(__file__).resolve().parent
C=R.parent
base=(R/'before/tools/test262_conformance.py').read_text()
old=next(n for n in ast.parse(base).body if isinstance(n,ast.FunctionDef) and n.name=='aggregate_error_preflight_variants')
oldsource=ast.get_source_segment(base,old)
prefix=oldsource.split('    # Each new literal is written once',1)[0]
prefix=prefix.replace('def aggregate_error_preflight_variants():','def with_resolvers_preflight_variants():',1).replace('Build the frozen ordinary32 and selected20 controls without observed digests.','Build the frozen ordinary32 and selected12 controls from source literals.',1)
frozen=json.loads((C/'controls-1/variants.json').read_text())
selected=[]
for first,second in zip(frozen[32::2],frozen[33::2]):
 assert first['mode']=='sloppy' and second['mode']=='strict'
 for key in ('name','source','metadata','expected','required_observation'):
  assert first[key]==second[key],(first['name'],key)
 assert first['metadata']['negative'] is None
 assert first['metadata']['features']==first['metadata']['flags']==first['metadata']['locale']==[]
 prior=first['name'].removesuffix('-mismatch') if first['name'].endswith('-mismatch') else None
 selected.append(dict(name=first['name'],source=first['source'],includes=tuple(first['metadata']['includes']),expected=first['expected'],prerequisite=prior))
lines=[prefix,'    # Each selected source is written once and expanded into both modes.\n','    selected = [\n']
for row in selected:
 lines.extend(['        {\n',f"            'name': {row['name']!r},\n","            'source': (\n"])
 lines.extend('                '+repr(line)+'\n' for line in row['source'].splitlines(True))
 lines.extend(['            ),\n',f"            'includes': {row['includes']!r},\n",f"            'expected': {row['expected']!r},\n",f"            'prerequisite': {row['prerequisite']!r},\n",'        },\n'])
lines.extend(['    ]\n',"    for row in selected:\n","        for mode in ('sloppy', 'strict'):\n","            prerequisites = common_refs + ([(row['prerequisite'], mode)]\n","                                           if row['prerequisite'] is not None else [])\n","            add(row['name'], mode, row['source'], row['expected'],\n","                includes=row['includes'],\n","                error_type='Test262Error' if row['expected'] == 'failed' else '',\n","                prerequisites=prerequisites, mode_id=True)\n","    return rows\n"])
factory=''.join(lines)
(R/'payload/preflight-variants.py').write_text(factory)
node=ast.parse(factory).body[0]
literals={n.targets[0].id:ast.literal_eval(n.value) for n in node.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'common','strict_only','selected'}}
assert literals['selected']==selected
# Independent inert expansion of literal tuples; no project/function evaluation.
rows=[]
def add(name,mode,source,expected,includes=(),prerequisites=(),mode_id=False):
 rows.append({'name':name,'mode':mode,'id':'harness-preflight:'+name+(':'+mode if mode_id else ''),'source':source,'metadata':{'features':[],'flags':[],'includes':list(includes),'locale':[],'negative':None},'expected':expected,'required_observation':{'error_identity':'','error_type':'Test262Error' if expected=='failed' else '', 'harness':'','phase':'runtime','status':'exception' if expected=='failed' else 'complete'},'prerequisites':[list(ref) for ref in prerequisites]})
for mode,prefixname in (('sloppy',''),('strict','strict-')):
 for name,source,expected,prerequisite in literals['common']:
  add(prefixname+name,mode,source,expected,('propertyHelper.js',) if 'property-' in name else (),[(prefixname+prerequisite,mode)] if prerequisite is not None else [])
for name,source in literals['strict_only']:add(name,'strict',source,'passed')
commonrefs=[(row['name'],row['mode']) for row in rows]
for row in literals['selected']:
 for mode in ('sloppy','strict'):
  add(row['name'],mode,row['source'],row['expected'],row['includes'],commonrefs+([(row['prerequisite'],mode)] if row['prerequisite'] is not None else []),True)
assert rows==frozen
h=lambda b:hashlib.sha256(b).hexdigest()
receipt={'method':'stdlib AST literal extraction and independent schema expansion; no import, eval or execution of candidate or project functions','count':len(rows),'common_count':32,'selected_count':12,'all_44_structures_exact':True,'common_factory_prefix_exact_except_name_docstring':True,'factory_sha256':h(factory.encode()),'frozen_variants_sha256':h((C/'controls-1/variants.json').read_bytes()),'canonical_rows_compact_sha256':h(json.dumps(rows,sort_keys=True,separators=(',',':')).encode()),'source_sha256_by_name':{row['name']:h(row['source'].encode()) for row in rows}}
(R/'factory-equivalence.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('count','all_44_structures_exact','factory_sha256')}))
