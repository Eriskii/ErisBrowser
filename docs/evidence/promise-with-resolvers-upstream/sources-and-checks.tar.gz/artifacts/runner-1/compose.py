"""External text composition only; never import or execute project modules."""
from pathlib import Path
import ast,difflib,hashlib,json
R=Path(__file__).resolve().parent
before=(R/'before/tools/test262_conformance.py').read_text();source=before;edits=[]
def replace(old,new,label):
 global source
 assert source.count(old)==1,(label,source.count(old))
 source=source.replace(old,new,1);edits.append({'label':label,'before':old,'after':new})
replace("PROFILE_FEATURES[AGGREGATE_ERROR_PROFILE] = AGGREGATE_ERROR_FEATURES\n", "PROFILE_FEATURES[AGGREGATE_ERROR_PROFILE] = AGGREGATE_ERROR_FEATURES\nPROMISE_WITH_RESOLVERS_PROFILE = 'promise-with-resolvers'\nPROMISE_WITH_RESOLVERS_FEATURES = {'promise-with-resolvers'}\nPROFILE_FEATURES[PROMISE_WITH_RESOLVERS_PROFILE] = PROMISE_WITH_RESOLVERS_FEATURES\n", 'standalone profile feature selection')
old="    if profile in {'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:\n"
replace(old,old.replace("{'promise-any'", "{PROMISE_WITH_RESOLVERS_PROFILE, 'promise-any'"),'authenticate selected auxiliary blobs')
old="        if profile in {'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse', 'typedarray-fill', 'typedarray-search', 'typedarray-views', 'reflect-properties', 'typedarray-foundation', 'object-has-own', 'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys() != (\n"
replace(old,old.replace("{'promise-any'", "{PROMISE_WITH_RESOLVERS_PROFILE, 'promise-any'"),'exact selected auxiliary membership')
replace('def decode_response(output, *, profile=None):\n','def decode_response(output, *, profile=None):\n    if profile == PROMISE_WITH_RESOLVERS_PROFILE and not output.startswith(b\'ERJR2\'):\n        raise ValueError(\'Promise.withResolvers profile requires an ordinary ERJR2 response\')\n','selected ordinary wire guard')
replace("    result['expected_negative'] = case['metadata']['negative']\n    reason = unsupported_reason(case, supported_features, profile)\n", "    result['expected_negative'] = case['metadata']['negative']\n    if profile == PROMISE_WITH_RESOLVERS_PROFILE and 'completion_policy' in case:\n        return dict(result, status='adapter-error',\n                    reason='Promise.withResolvers requires an ordinary request')\n    reason = unsupported_reason(case, supported_features, profile)\n", 'selected completion-policy presence refusal')
replace("                       if profile in {AGGREGATE_ERROR_PROFILE, PROMISE_ANY_PROFILE} else decode_response(output))\n", "                       if profile in {AGGREGATE_ERROR_PROFILE, PROMISE_ANY_PROFILE,\n                                      PROMISE_WITH_RESOLVERS_PROFILE} else decode_response(output))\n", 'selected decoder context only')
replace('    """Fail closed if the upstream assertions no longer enforce basic failures."""\n', '    """Fail closed if the upstream assertions no longer enforce basic failures."""\n    if profile == PROMISE_WITH_RESOLVERS_PROFILE:\n        return with_resolvers_harness_preflight(files, binary, timeout)\n','selected ordinary preflight dispatch')
# This file is not complete or sealed until the independent literal hold arrives.
variants=(R/'payload/preflight-variants.py').read_text()
support=(R/'payload/preflight-support.py').read_text()
replace('def check_baseline(previous, current):\n',variants.rstrip()+'\n\n\n'+support.rstrip()+'\n\n\ndef check_baseline(previous, current):\n','six selected canonical ordinary control functions')
replace('        preflight_ok = (promise_any_preflight_healthy(preflight, files) if args.profile == PROMISE_ANY_PROFILE\n','        preflight_ok = (with_resolvers_preflight_healthy(preflight, files) if args.profile == PROMISE_WITH_RESOLVERS_PROFILE\n                        else promise_any_preflight_healthy(preflight, files) if args.profile == PROMISE_ANY_PROFILE\n','selected health gate')
replace("        if args.profile == AGGREGATE_ERROR_PROFILE and not preflight_ok:\n", "        if args.profile == PROMISE_WITH_RESOLVERS_PROFILE and not preflight_ok:\n            results = [dict(id=case['id'], file=case['file'], mode=case['mode'],\n                            case_sha256=case['case_sha256'], source_sha256=digest(case['source']),\n                            expected_negative=case['metadata']['negative'], status='blocked',\n                            reason='Promise.withResolvers harness preflight failed') for case in cases]\n        elif args.profile == AGGREGATE_ERROR_PROFILE and not preflight_ok:\n",'selected blocked corpus dispatch')
ast.parse(source)
inverse=source
for edit in reversed(edits):
 assert inverse.count(edit['after'])==1,edit['label']
 inverse=inverse.replace(edit['after'],edit['before'],1)
assert inverse==before
p=R/'raw/tools/test262_conformance.py';p.parent.mkdir(parents=True,exist_ok=True);p.write_text(source)
d=R/'diffs/tools/test262_conformance.py.patch';d.parent.mkdir(parents=True,exist_ok=True);d.write_text(''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='a/tools/test262_conformance.py',tofile='b/tools/test262_conformance.py')))
(R/'edit-manifest.json').write_text(json.dumps(edits,indent=2)+'\n')
old={n.name:ast.get_source_segment(before,n) for n in ast.parse(before).body if isinstance(n,ast.FunctionDef)};new={n.name:ast.get_source_segment(source,n) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
changed=[name for name in old if old[name]!=new[name]];added=[name for name in new if name not in old]
assert set(changed)=={'load_corpus','decode_response','run_case','harness_preflight','main'}
assert len(added)==6 and all(n.startswith('with_resolvers_') for n in added)
(R/'changed-functions.json').write_text(json.dumps({'changed':changed,'added':added,'unchanged_old_functions':len(old)-len(changed),'classify_byte_exact':old['classify']==new['classify'],'inverse_byte_exact':True,'old_function_hashes':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in old.items()},'new_function_hashes':{n:hashlib.sha256(s.encode()).hexdigest() for n,s in new.items()}},indent=2)+'\n')
print(json.dumps({'changed':changed,'added':added,'raw_bytes':len(source.encode())}))
