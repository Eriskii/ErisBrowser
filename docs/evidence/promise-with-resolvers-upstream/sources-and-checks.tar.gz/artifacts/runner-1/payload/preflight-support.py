def with_resolvers_preflight_cases(files):
    """Rebuild ordinary control identities from frozen literals and pinned helpers."""
    definitions = []
    for row in with_resolvers_preflight_variants():
        metadata = row['metadata']
        case = dict(id=row['id'], file='<preflight>', mode=row['mode'],
                    metadata=metadata, source=row['source'].encode(),
                    harness=[(name, files['harness/' + name])
                             for name in harness_names(metadata)])
        case['case_sha256'] = case_fingerprint(case)
        definitions.append((row, case))
    return definitions


def with_resolvers_preflight_reference(row, case):
    return dict(name=row['name'], mode=case['mode'], id=case['id'],
                case_sha256=case['case_sha256'], source_sha256=digest(case['source']),
                expected=row['expected'])


def with_resolvers_preflight_checks(outcomes, files):
    """Recheck exact identities, ordinary observations and prerequisite health."""
    try:
        definitions = with_resolvers_preflight_cases(files)
        if not isinstance(outcomes, list) or len(outcomes) != 44 or len(definitions) != 44:
            return None
        canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
        if len(canonical) != 44:
            return None
        observed = {}
        for item in outcomes:
            if (not isinstance(item, dict)
                    or set(item) != {'name', 'expected', 'verified', 'result', 'prerequisites'}
                    or not isinstance(item['name'], str)
                    or not isinstance(item['expected'], str)
                    or type(item['verified']) is not bool
                    or not isinstance(item['result'], dict)
                    or not isinstance(item['result'].get('mode'), str)
                    or not isinstance(item['prerequisites'], list)):
                return None
            identity = (item['name'], item['result']['mode'])
            if identity in observed or identity not in canonical:
                return None
            observed[identity] = item
        if observed.keys() != canonical.keys():
            return None
        raw_checks = {}
        for identity, (row, case) in canonical.items():
            item = observed[identity]
            result = item['result']
            expected_result = {key: case[key] for key in ('id', 'file', 'mode', 'case_sha256')}
            expected_result.update(source_sha256=digest(case['source']),
                                   expected_negative=case['metadata']['negative'],
                                   status=row['expected'])
            observation = result.get('observation')
            raw_names = {'status', 'phase', 'error_type', 'error_identity', 'message', 'harness'}
            expected_prerequisites = [with_resolvers_preflight_reference(*canonical[key])
                                      for key in row['prerequisites']]
            prerequisites = item['prerequisites']
            reference_names = {'name', 'mode', 'id', 'case_sha256', 'source_sha256', 'expected'}
            negative = result.get('expected_negative')
            good = ('completion_policy' not in case
                    and item['expected'] == row['expected']
                    and set(result) == set(expected_result) | {'observation'}
                    and all(isinstance(result.get(key), str) for key in
                            ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'status'))
                    and (negative is None or isinstance(negative, dict)
                         and set(negative) == {'phase', 'type'}
                         and all(isinstance(value, str) for value in negative.values()))
                    and all(result.get(key) == value for key, value in expected_result.items())
                    and len(prerequisites) == len(expected_prerequisites)
                    and all(isinstance(ref, dict) and set(ref) == reference_names
                            and all(isinstance(value, str) for value in ref.values())
                            for ref in prerequisites)
                    and prerequisites == expected_prerequisites
                    and isinstance(observation, dict) and set(observation) == raw_names)
            if good:
                good = (all(isinstance(value, str) and len(value.encode('utf-8')) <= 16384
                            for value in observation.values())
                        and all(observation[key] == value
                                for key, value in row['required_observation'].items())
                        and classify(case, observation) == row['expected'])
            raw_checks[identity] = good
        checked, visiting = {}, set()

        def healthy(identity):
            if identity in checked:
                return checked[identity]
            if identity in visiting:
                return False
            visiting.add(identity)
            row, _ = canonical[identity]
            value = raw_checks[identity] and all(healthy(key) for key in row['prerequisites'])
            visiting.remove(identity)
            checked[identity] = value
            return value

        for identity in canonical:
            healthy(identity)
        return checked
    except (KeyError, TypeError, ValueError):
        return None


def with_resolvers_preflight_healthy(outcomes, files):
    checks = with_resolvers_preflight_checks(outcomes, files)
    return (checks is not None and len(checks) == 44 and all(checks.values())
            and all(item['verified'] is True for item in outcomes))


def with_resolvers_harness_preflight(files, binary, timeout):
    definitions = with_resolvers_preflight_cases(files)
    canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
    outcomes = []
    for row, case in definitions:
        result = run_case(case, binary, timeout,
                          PROMISE_WITH_RESOLVERS_FEATURES, PROMISE_WITH_RESOLVERS_PROFILE)
        prerequisites = [with_resolvers_preflight_reference(*canonical[key])
                         for key in row['prerequisites']]
        outcomes.append(dict(name=row['name'], expected=row['expected'], verified=False,
                             result=result, prerequisites=prerequisites))
    checks = with_resolvers_preflight_checks(outcomes, files)
    if checks is not None:
        for item in outcomes:
            item['verified'] = checks[(item['name'], item['result']['mode'])]
    return outcomes
