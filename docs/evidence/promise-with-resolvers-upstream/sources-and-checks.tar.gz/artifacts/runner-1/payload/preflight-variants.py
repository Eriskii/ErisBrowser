def with_resolvers_preflight_variants():
    """Build the frozen ordinary32 and selected12 controls from source literals."""
    rows = []

    def add(name, mode, source, expected, *, includes=(), negative=None,
            error_type='', error_identity='', prerequisites=(), mode_id=False):
        rows.append({
            'name': name,
            'mode': mode,
            'id': 'harness-preflight:' + name + (':' + mode if mode_id else ''),
            'source': source,
            'metadata': {'features': [], 'flags': [], 'includes': list(includes),
                         'locale': [], 'negative': None if negative is None else
                         {'phase': 'runtime', 'type': negative}},
            'expected': expected,
            'required_observation': {'error_identity': error_identity,
                                     'error_type': error_type, 'harness': '',
                                     'phase': 'runtime',
                                     'status': 'exception' if error_type else 'complete'},
            'prerequisites': list(prerequisites),
        })

    # Existing ordinary controls: name, source, result, same-mode prerequisite.
    common = [
        ('success',
         'assert.sameValue(1, 1); assert.sameValue(NaN, NaN);',
         'passed', None),
        ('assert-false',
         'assert(false);',
         'failed', 'success'),
        ('same-value',
         'assert.sameValue(1, 2);',
         'failed', 'success'),
        ('signed-zero',
         'assert.sameValue(0, -0);',
         'failed', 'success'),
        ('not-same-value',
         'assert.notSameValue(1, 1);',
         'failed', 'success'),
        ('throws-success',
         'assert.throws(TypeError, function () { throw new TypeError(); });',
         'passed', None),
        ('throws-wrong-type',
         'assert.throws(TypeError, function () { throw new RangeError(); });',
         'failed', 'throws-success'),
        ('throws-missing',
         'assert.throws(TypeError, function () {});',
         'failed', 'throws-success'),
        ('array-mismatch',
         'assert.compareArray([1], [2]);',
         'failed', 'success'),
        ('property-success',
         "verifyProperty({x: 1}, 'x', {value: 1, writable: true, enumerable: true, configurable: true});",
         'passed', None),
        ('property-writable',
         "verifyProperty({x: 1}, 'x', {writable: false});",
         'failed', 'property-success'),
        ('property-enumerable',
         "verifyProperty({x: 1}, 'x', {enumerable: false});",
         'failed', 'property-success'),
        ('property-configurable',
         "verifyProperty({x: 1}, 'x', {configurable: false});",
         'failed', 'property-success'),
    ]
    for mode, prefix in (('sloppy', ''), ('strict', 'strict-')):
        for name, source, expected, prerequisite in common:
            add(prefix + name, mode, source, expected,
                includes=('propertyHelper.js',) if 'property-' in name else (),
                error_type='Test262Error' if expected == 'failed' else '',
                prerequisites=([(prefix + prerequisite, mode)]
                               if prerequisite is not None else []))

    strict_only = [
        ('strict-receiver',
         'function f(){return this;} assert.sameValue(f(),undefined); assert.sameValue(f.call(null),null); assert.sameValue(f.call(3),3);'),
        ('strict-unbound-write',
         'assert.throws(ReferenceError,function(){missing=1;});'),
        ('strict-readonly-write',
         "var o={};Object.defineProperty(o,'x',{value:1});assert.throws(TypeError,function(){o.x=2;});"),
        ('strict-delete',
         "var o={};Object.defineProperty(o,'x',{value:1});assert.throws(TypeError,function(){delete o.x;});"),
        ('strict-arguments',
         'function f(a){arguments[0]=2;assert.sameValue(a,1);assert.throws(TypeError,()=>arguments.callee);}f(1);'),
        ('strict-tdz',
         'assert.throws(ReferenceError,function(){typeof x;let x;});'),
    ]
    for name, source in strict_only:
        add(name, 'strict', source, 'passed')
    common_refs = [(row['name'], row['mode']) for row in rows]

    # Each selected source is written once and expanded into both modes.
    selected = [
        {
            'name': 'with-resolvers-generic',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var method = Promise.withResolvers;\n'
                'var probe = method.call(Promise);\n'
                'assert.sameValue(probe.promise instanceof Promise, true);\n'
                'var promise = {}, count = 0, calls = 0;\n'
                'function resolve(value) { calls++; return value; }\n'
                'function reject(value) { calls++; return value; }\n'
                'function C(executor) {\n'
                "  assert.sameValue(typeof executor, 'function');\n"
                '  count++;\n'
                '  executor(resolve, reject);\n'
                '  return promise;\n'
                '}\n'
                'var result = method.call(C);\n'
                'assert.sameValue(result.promise, promise);\n'
                'assert.sameValue(result.resolve, resolve);\n'
                'assert.sameValue(result.reject, reject);\n'
                'assert.sameValue(calls, 0);\n'
                "var invalid = [undefined, null, false, 1, 'text', Symbol()];\n"
                'for (var i = 0; i < invalid.length; i++) {\n'
                '  assert.throws(TypeError, function () { method.call(invalid[i]); });\n'
                '}\n'
                'assert.throws(TypeError, function () { method.call(eval); });\n'
                'assert.throws(TypeError, function () { method.call(method); });\n'
                "assert.sameValue(count, 1, 'one generic constructor call');\n"
            ),
            'includes': (),
            'expected': 'passed',
            'prerequisite': None,
        },
        {
            'name': 'with-resolvers-generic-mismatch',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var method = Promise.withResolvers;\n'
                'var probe = method.call(Promise);\n'
                'assert.sameValue(probe.promise instanceof Promise, true);\n'
                'var promise = {}, count = 0, calls = 0;\n'
                'function resolve(value) { calls++; return value; }\n'
                'function reject(value) { calls++; return value; }\n'
                'function C(executor) {\n'
                "  assert.sameValue(typeof executor, 'function');\n"
                '  count++;\n'
                '  executor(resolve, reject);\n'
                '  return promise;\n'
                '}\n'
                'var result = method.call(C);\n'
                'assert.sameValue(result.promise, promise);\n'
                'assert.sameValue(result.resolve, resolve);\n'
                'assert.sameValue(result.reject, reject);\n'
                'assert.sameValue(calls, 0);\n'
                "var invalid = [undefined, null, false, 1, 'text', Symbol()];\n"
                'for (var i = 0; i < invalid.length; i++) {\n'
                '  assert.throws(TypeError, function () { method.call(invalid[i]); });\n'
                '}\n'
                'assert.throws(TypeError, function () { method.call(eval); });\n'
                'assert.throws(TypeError, function () { method.call(method); });\n'
                "assert.sameValue(count, 2, 'one generic constructor call');\n"
            ),
            'includes': (),
            'expected': 'failed',
            'prerequisite': 'with-resolvers-generic',
        },
        {
            'name': 'with-resolvers-genuine',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var result = Promise.withResolvers();\n'
                'assert.sameValue(result.promise.constructor, Promise);\n'
                'assert.sameValue(Object.getPrototypeOf(result.promise), Promise.prototype);\n'
                'assert.sameValue(result.promise instanceof Promise, true);\n'
                'var calls = 0;\n'
                'var child = Promise.prototype.then.call(result.promise,\n'
                '  function () { calls++; }, function () { calls++; });\n'
                'assert.sameValue(child instanceof Promise, true);\n'
                "assert.sameValue(calls, 0, 'pending promise has no handler calls');\n"
                "assert.sameValue(typeof result.resolve, 'function');\n"
                "assert.sameValue(typeof result.reject, 'function');\n"
                "assert.sameValue(result.resolve.name, '');\n"
                "assert.sameValue(result.reject.name, '');\n"
                'assert.sameValue(result.resolve.length, 1);\n'
                "assert.sameValue(result.reject.length, 1, 'reject arity');\n"
            ),
            'includes': (),
            'expected': 'passed',
            'prerequisite': None,
        },
        {
            'name': 'with-resolvers-genuine-mismatch',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var result = Promise.withResolvers();\n'
                'assert.sameValue(result.promise.constructor, Promise);\n'
                'assert.sameValue(Object.getPrototypeOf(result.promise), Promise.prototype);\n'
                'assert.sameValue(result.promise instanceof Promise, true);\n'
                'var calls = 0;\n'
                'var child = Promise.prototype.then.call(result.promise,\n'
                '  function () { calls++; }, function () { calls++; });\n'
                'assert.sameValue(child instanceof Promise, true);\n'
                "assert.sameValue(calls, 0, 'pending promise has no handler calls');\n"
                "assert.sameValue(typeof result.resolve, 'function');\n"
                "assert.sameValue(typeof result.reject, 'function');\n"
                "assert.sameValue(result.resolve.name, '');\n"
                "assert.sameValue(result.reject.name, '');\n"
                'assert.sameValue(result.resolve.length, 1);\n'
                "assert.sameValue(result.reject.length, 2, 'reject arity');\n"
            ),
            'includes': (),
            'expected': 'failed',
            'prerequisite': 'with-resolvers-genuine',
        },
        {
            'name': 'with-resolvers-result',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var promise = {}, calls = 0, constructors = 0;\n'
                'function resolve(value) { calls++; return value; }\n'
                'function reject(value) { calls++; return value; }\n'
                'function C(executor) { constructors++; executor(resolve, reject); return promise; }\n'
                'var result = Promise.withResolvers.call(C);\n'
                'var again = Promise.withResolvers.call(C);\n'
                'assert.notSameValue(result, again);\n'
                'assert.sameValue(Object.getPrototypeOf(result), Object.prototype);\n'
                'assert.sameValue(Object.getPrototypeOf(again), Object.prototype);\n'
                "assert.compareArray(Object.getOwnPropertyNames(result), ['promise', 'resolve', 'reject']);\n"
                "assert.compareArray(Object.keys(result), ['promise', 'resolve', 'reject']);\n"
                'assert.sameValue(constructors, 2);\n'
                'assert.sameValue(calls, 0);\n'
                "var keys = ['promise', 'resolve', 'reject'];\n"
                'var values = [promise, resolve, reject];\n'
                'for (var i = 0; i < keys.length; i++) {\n'
                '  var descriptor = Object.getOwnPropertyDescriptor(result, keys[i]);\n'
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'value'), true);\n"
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'get'), false);\n"
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'set'), false);\n"
                '  assert.sameValue(again[keys[i]], values[i]);\n'
                '  verifyProperty(result, keys[i], {value: values[i], writable: true,\n'
                '    enumerable: true, configurable: true}, {restore: true});\n'
                '}\n'
                'assert.sameValue(calls, 0);\n'
                "verifyProperty(result, 'reject', {enumerable: true}, {restore: true});\n"
            ),
            'includes': ('propertyHelper.js',),
            'expected': 'passed',
            'prerequisite': None,
        },
        {
            'name': 'with-resolvers-result-mismatch',
            'source': (
                "assert.sameValue(typeof Promise.withResolvers, 'function', 'withResolvers availability');\n"
                'var promise = {}, calls = 0, constructors = 0;\n'
                'function resolve(value) { calls++; return value; }\n'
                'function reject(value) { calls++; return value; }\n'
                'function C(executor) { constructors++; executor(resolve, reject); return promise; }\n'
                'var result = Promise.withResolvers.call(C);\n'
                'var again = Promise.withResolvers.call(C);\n'
                'assert.notSameValue(result, again);\n'
                'assert.sameValue(Object.getPrototypeOf(result), Object.prototype);\n'
                'assert.sameValue(Object.getPrototypeOf(again), Object.prototype);\n'
                "assert.compareArray(Object.getOwnPropertyNames(result), ['promise', 'resolve', 'reject']);\n"
                "assert.compareArray(Object.keys(result), ['promise', 'resolve', 'reject']);\n"
                'assert.sameValue(constructors, 2);\n'
                'assert.sameValue(calls, 0);\n'
                "var keys = ['promise', 'resolve', 'reject'];\n"
                'var values = [promise, resolve, reject];\n'
                'for (var i = 0; i < keys.length; i++) {\n'
                '  var descriptor = Object.getOwnPropertyDescriptor(result, keys[i]);\n'
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'value'), true);\n"
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'get'), false);\n"
                "  assert.sameValue(Object.prototype.hasOwnProperty.call(descriptor, 'set'), false);\n"
                '  assert.sameValue(again[keys[i]], values[i]);\n'
                '  verifyProperty(result, keys[i], {value: values[i], writable: true,\n'
                '    enumerable: true, configurable: true}, {restore: true});\n'
                '}\n'
                'assert.sameValue(calls, 0);\n'
                "verifyProperty(result, 'reject', {enumerable: false}, {restore: true});\n"
            ),
            'includes': ('propertyHelper.js',),
            'expected': 'failed',
            'prerequisite': 'with-resolvers-result',
        },
    ]
    for row in selected:
        for mode in ('sloppy', 'strict'):
            prerequisites = common_refs + ([(row['prerequisite'], mode)]
                                           if row['prerequisite'] is not None else [])
            add(row['name'], mode, row['source'], row['expected'],
                includes=row['includes'],
                error_type='Test262Error' if row['expected'] == 'failed' else '',
                prerequisites=prerequisites, mode_id=True)
    return rows
