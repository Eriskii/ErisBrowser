"""Seal inert source artifacts after exact published-Git and inverse checks."""
from pathlib import Path
import ast,hashlib,json,subprocess
R=Path(__file__).resolve().parent; C=R.parent
base='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0';rel='tools/test262_conformance.py'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
before=(R/'before'/rel).read_bytes();raw=(R/'raw'/rel).read_bytes()
assert before==subprocess.check_output(['git','show',base+':'+rel],cwd=C/'worktree')
parent=json.loads((C/'source-parent.json').read_text())
assert parent['base']==base and parent['source_sha256'][rel]==hashlib.sha256(before).hexdigest()
edits=json.loads((R/'edit-manifest.json').read_text());inverse=raw.decode()
for row in reversed(edits):
 assert inverse.count(row['after'])==1;inverse=inverse.replace(row['after'],row['before'],1)
assert inverse.encode()==before
# All old module statements except the five selected functions and configuration
# remain byte-identical; insertion/delta inverse above covers the complete file.
oldtree=ast.parse(before);newtree=ast.parse(raw)
ledger=json.loads((R/'changed-functions.json').read_text())
assert ledger['classify_byte_exact'] and ledger['inverse_byte_exact']
refs=['root/selection-1.json','root/run-case-boundary-1.json','source-parent.json','readiness-base-refresh-1/source-ready.json','controls-1/literals-ready.json','controls-1/contract.json','controls-1/variants.json','controls-1/raw/tools/test262-with-resolvers-controls-oracle.json']
# Validate all recursively embedded file bindings in the literal seal now.
def check(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   assert bind(x['path'])=={k:x[k] for k in ('path','bytes','sha256')},x['path']
  for v in x.values():check(v)
 elif isinstance(x,list):
  for v in x:check(v)
check(json.loads((C/'controls-1/literals-ready.json').read_text()))
notes={'status':'source_only','published_base':base,'published_git_before_exact':True,'source_parent_join_exact':True,'complete_edit_inverse_exact':True,'scope':'One runner file; five existing functions, six new control functions, standalone profile constant and feature set. No importer, tests, corpus, baseline, CI, Rust or host changes.','old_routes':'Generic classify, profile_intrinsic_errors, encode_request, all old preflight/gate functions, host-profile membership and policy construction expressions remain exact; selected-only branches preserve default decoder/classifier arities.','request_boundary':'Any presence of completion_policy returns canonical adapter-error before unsupported_reason, encode_request or adapter execution, with selected reason.','response_boundary':'Selected profile requires ERJR2; default seven intrinsic identities remain unchanged.','gate':'Canonical 44 identities, raw six-field string schema, exact five required observation fields, reclassification, exact ordered six-field prerequisite references and recursive prerequisite health; no completion fields admitted.','authoring_note':'Initial external composition failed before writing raw output because a text anchor used baseline rather than the published check_baseline parameter previous. Corrected inert composition anchor; no candidate code was executed.','execution':'Only stdlib text/AST/JSON/hash and read-only Git; no project import or execution, engine runs, tests, builds, network, or live edits.'}
(R/'source-checks.json').write_text(json.dumps(notes,indent=2)+'\n')
receipt={'status':'source_ready','base':base,'files':[{'relative':rel,'new':False,'before':bind(R/'before'/rel),'raw':bind(R/'raw'/rel),'diff':bind(R/'diffs'/f'{rel}.patch')}],'bindings':[bind(C/p) for p in refs],'changed_functions':bind(R/'changed-functions.json'),'exact_edits':bind(R/'edit-manifest.json'),'factory_equivalence':bind(R/'factory-equivalence.json'),'source_checks':bind(R/'source-checks.json'),'authoring_sources':[bind(R/p) for p in ('compose.py','derive-variants.py','seal.py','payload/preflight-variants.py','payload/preflight-support.py')],'scope':notes['scope'],'execution':notes['execution']}
(R/'source-ready.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(bind(R/'source-ready.json')))
