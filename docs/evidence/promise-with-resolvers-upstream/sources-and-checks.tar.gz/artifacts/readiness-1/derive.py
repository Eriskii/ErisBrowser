"""Inert stdlib source/proof analysis; never import or execute project code."""
from pathlib import Path
import ast, base64, hashlib, json, re, subprocess
B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
R=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1/readiness-1')
W=B/'worktree'; BASE='33ddb14aea0b8a20b7e340c4a5900abda3062f6f'
def digest(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def write(name,obj):
 p=R/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(obj,indent=2,ensure_ascii=True)+'\n')
def copy(p,rel):
 b=p.read_bytes();q=R/rel;q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(b);return {'original':str(p),'snapshot':str(q),'bytes':len(b),'sha256':digest(b)}
def published(rel):
 b=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W);assert b==(W/rel).read_bytes(),rel
 p=R/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);return {'relative_path':rel,'snapshot':str(p),'bytes':len(b),'sha256':digest(b),'git_blob':blob(b)}
bindings=[published(rel) for rel in ['tools/import_test262.py','tools/test262_conformance.py','.github/workflows/check.yml']]
# Restricted interpretation of literal configuration AST only, never compiled/eval/imported.
def tables(source):
 env={}
 def val(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,(ast.List,ast.Tuple)):return [val(x) for x in n.elts]
  if isinstance(n,ast.Set):return {val(x) for x in n.elts}
  if isinstance(n,ast.Dict):return {val(k):val(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.BinOp) and isinstance(n.op,ast.BitOr):return val(n.left)|val(n.right)
  if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute) and n.func.attr=='copy' and not n.args:return val(n.func.value).copy()
  raise ValueError(type(n).__name__)
 for n in ast.parse(source).body:
  try:
   if isinstance(n,ast.Assign):
    v=val(n.value)
    for t in n.targets:
     if isinstance(t,ast.Name):env[t.id]=v
     elif isinstance(t,ast.Subscript) and isinstance(t.value,ast.Name):env[t.value.id][val(t.slice)]=v
   elif isinstance(n,ast.Expr) and isinstance(n.value,ast.Call) and isinstance(n.value.func,ast.Attribute) and n.value.func.attr=='add':env[n.value.func.value.id].add(val(n.value.args[0]))
  except (ValueError,KeyError,AttributeError):pass
 return env
imp=(R/'parent/tools/import_test262.py').read_text();run=(R/'parent/tools/test262_conformance.py').read_text();i=tables(imp);r=tables(run)
assert len(i['PROFILES'])==len(r['PROFILE_FEATURES'])==59
policies={}
for name,features in r['PROFILE_FEATURES'].items():
 ids=r['INTRINSIC_ERRORS']|({'AggregateError'} if name in {'aggregate-error','promise-any'} else set())
 p=dict(format=2,supported_features=sorted(features),negative_intrinsic_errors=sorted(ids),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if name in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:p['excluded_harness']=['resizableArrayBufferUtils.js']
 if name in r['PROMISE_HOST_PROFILES']:p.update(format=3,async_completion=True,host_hooks=True,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
 policies[name]={'policy':p,'sha256':digest(json.dumps(p,sort_keys=True).encode())}
old=json.loads((W/'tools/promise-any-preservation-oracle.json').read_text())
assert {k:v for k,v in policies.items() if k!='promise-any'}==old['policies_at_timeout3']
write('old-profile-contract.json',{'base':BASE,'profiles':i['PROFILES'],'roots':i['PROFILE_ROOTS'],'tree_profiles':sorted(i['TREE_PROFILES']),'features':{k:sorted(v) for k,v in r['PROFILE_FEATURES'].items()},'promise_host_profiles':sorted(r['PROMISE_HOST_PROFILES']),'intrinsic_errors':sorted(r['INTRINSIC_ERRORS']),'policies_at_timeout3':policies,'old58_policy_join':True})
# Authenticate complete retained tree chain and pinned auxiliary bytes.
C=W/'tests/upstream/test262-promise-any';proofs={}
for p in (C/'inventory-proof').glob('*.json'):
 if 'e2352be158fb0c0625d1ab642330faabc62a2df8' not in p.name:proofs[p.name]=p
proofs['tree-062393e615d0cf97a0252e6a93923bd91444a455.json']=B/'root/upstream-directory.json'
trees={};proof_rows=[]
for name,p in sorted(proofs.items()):
 d=json.loads(p.read_text());proof_rows.append(copy(p,'proof/'+name))
 if name=='commit.json':assert d['sha']==i['REVISION'] and d['tree']['sha']==i['REVISION_TREE'];continue
 assert d['truncated'] is False
 chunks=[];names=set()
 for e in d['tree']:
  assert e['path'] not in names;names.add(e['path']);raw=e['path'].encode();chunks.append((raw+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+raw+b'\0'+bytes.fromhex(e['sha'])))
 body=b''.join(x[1] for x in sorted(chunks));assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==d['sha'];trees[d['sha']]={e['path']:e for e in d['tree']}
chain=[];sha=i['REVISION_TREE']
for part in ['test','built-ins','Promise','withResolvers']:
 e=trees[sha][part];assert e['type']=='tree';chain.append({'parent':sha,'name':part,'child':e['sha']});sha=e['sha']
assert sha=='062393e615d0cf97a0252e6a93923bd91444a455'
leaf=trees[sha];assert len(leaf)==6 and all(x['type']=='blob' and x['mode']=='100644' and n.endswith('.js') for n,x in leaf.items())
root=trees[i['REVISION_TREE']];harness=trees[root['harness']['sha']];aux={};auxrows=[]
for path in ['LICENSE','INTERPRETING.md','harness/assert.js','harness/sta.js','harness/propertyHelper.js']:
 entry=harness[path.split('/')[1]] if path.startswith('harness/') else root[path];b=(C/path).read_bytes();assert blob(b)==entry['sha'];aux[path]=entry['sha'];auxrows.append(copy(C/path,'auxiliary/'+path))
receipt=json.loads((B/'upstream-reference-1/receipt.json').read_text());rows=[];cases=[]
for name,e in sorted(leaf.items()):
 p=B/'upstream-reference-1'/name;b=p.read_bytes();assert len(b)==e['size'] and blob(b)==e['sha'];r0=next(x for x in receipt['rows'] if x['path']==name);assert digest(b)==r0['sha256']
 response=json.loads((p.with_name(name+'.response.json')).read_text());assert response['sha']==e['sha'] and base64.b64decode(response['content'])==b
 meta={'flags':[],'includes':[],'features':['promise-with-resolvers'],'locale':[],'negative':None}
 if name=='ctx-ctor.js':meta['features'].append('class')
 if name=='result.js':meta['includes'].append('propertyHelper.js')
 fm=b.decode().split('/*---',1)[1].split('---*/',1)[0]
 for key in ['flags','locale','negative','timeout']:assert not re.search(r'^'+key+r':',fm,re.M)
 assert re.search(r'^features: \['+re.escape(', '.join(meta['features']))+r'\]$',fm,re.M)
 helpers=['assert.js','sta.js']+meta['includes'];copy(p,'originals/'+name)
 row={'path':'test/built-ins/Promise/withResolvers/'+name,'bytes':len(b),'git_blob':e['sha'],'sha256':digest(b),'metadata':meta,'helpers':helpers};rows.append(row)
 for mode in ['sloppy','strict']:
  identity={'source_sha256':digest(b),'mode':mode,'metadata':meta,'harness':[{'name':n,'sha256':digest((C/'harness'/n).read_bytes())} for n in helpers]}
  cases.append({'id':row['path']+':'+mode,'source_sha256':digest(b),'case_sha256':digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()),'mode':mode,'file':row['path'],'metadata':meta,'harness':identity['harness']})
write('corpus-census.json',{'revision':i['REVISION'],'root_tree':i['REVISION_TREE'],'ancestor_chain':chain,'directory_trees':{'Promise/withResolvers':sha},'complete_direct_sources':6,'source_bytes':sum(x['bytes'] for x in rows),'modes':12,'async_modes':0,'negative_sources':0,'feature_source_counts':{'promise-with-resolvers':6,'class':1},'declared_helper_source_counts':{'propertyHelper.js':1},'helpers':['assert.js','sta.js','propertyHelper.js'],'auxiliary_blobs':aux,'proof_documents':7,'binary_tree_hashes_reconstructed':6,'rows':rows,'cases':cases,'prospective_package_files':19,'prospective_package_formula':'6 originals +3 helpers +2 legal +7 proof documents +manifest; no package/manifest authored','qualification':'Class source retained; excluding class yields2 metadata-unsupported modes and10 adapter-eligible modes, not a success prediction. No response or engine was run.'})
# Derive exact inherited adapter sites from current source, without editing it.
prior=json.loads(Path('/tmp/eris-promise-any-upstream-plan-1/controls-1/migration-census.json').read_text());entries=[]
for e in prior['entries']:
 if e['path']=='tools/test_test262_aggregate_error_preservation.py' and e['line']==84:continue
 src=(W/e['path']).read_text();line=src.splitlines()[e['line']-1];assert 'promise-any' in line,(e['path'],e['line'])
 entries.append({'path':e['path'],'line':e['line'],'source_line':line,'action':'Add only promise-with-resolvers to this historical table/count exclusion; preserve old literal totals/oracles and all host-profile sets.'})
for rel,lines in [('tools/test_import_test262_promise_any.py',[184,185,186]),('tools/test_test262_promise_any_preservation.py',[33,34,35,36])]:
 for lineno in lines:entries.append({'path':rel,'line':lineno,'source_line':(W/rel).read_text().splitlines()[lineno-1],'action':'Exclude only promise-with-resolvers alongside existing Any selector; preserve frozen58 maps/features/hashes.'})
assert len(entries)==35 and len({x['path'] for x in entries})==20
paths=sorted({x['path'] for x in entries});bindings.extend(published(p) for p in paths)
write('legacy-adapter-census.json',{'base':BASE,'paths':20,'entries_count':35,'entries':entries,'unchanged_host_set_assertions':['AggregateError preservation host-set subtraction only Any','Any protocol OLD_HOST and Any preservation host-set subtraction only Any'],'unchanged_feature_isolation_loops':['u180e','stable-array-sort','globalThis','rest-parameters','Object.hasOwn'],'qualification':'Source-only prospective edits, not payloads. Selection-only no host admission, no old function/oracle/baseline/corpus changes.'})
write('source-bindings.json',{'base':BASE,'future_BH_published_base_refresh_pending':True,'published_inputs':bindings,'proof_inputs':proof_rows,'auxiliary_inputs':auxrows,'source_receipt':copy(B/'upstream-reference-1/receipt.json','upstream-source-receipt.json'),'project_execution':False})
print(json.dumps({'profiles':59,'sources':6,'modes':12,'proof_documents':len(proof_rows),'legacy_paths':20,'legacy_entries':35,'source_bindings':len(bindings)}))
