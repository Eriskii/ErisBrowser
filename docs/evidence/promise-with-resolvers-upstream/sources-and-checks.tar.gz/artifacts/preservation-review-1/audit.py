"""Independent static peer; no project imports/execution or live edits."""
import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
W, O = C / 'worktree', C / 'preservation-review-1'
BASE = 'dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def save(name, value):
    path = O / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')
    return path


def published(relative):
    data = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=W)
    target = O / 'parent' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    return data


seals = {
    'migrations-1/source-ready.json': '25fd222ca650896d1acfc36399b68b3dd4a9bd589f9b3f4c376e5fe817133a66',
    'preservation-1/source-ready.json': '18af907c47c8b4938317821d66f6758b9f101e7127065ed76bdb7c5dc99fdd82',
    'ci-1/source-ready.json': '6c8e56a6e05ab83a636ac2bfb392758de257b10b1b6a647f23623c7808e58b2e',
}
holds = {}
for name, expected in seals.items():
    assert digest((C/name).read_bytes()) == expected
    holds[name.split('/')[0]] = json.loads((C/name).read_bytes())

migrations = holds['migrations-1']
census = json.loads((C/'readiness-1/legacy-adapter-census.json').read_bytes())
assert migrations['paths'] == len(migrations['files']) == 20
assert migrations['edits'] == sum(len(row['edits']) for row in migrations['files']) == 35
assert {r['relative_path'] for r in migrations['files']} == {r['path'] for r in census['entries']}
migration_checks = []
all_group_count = 0
for row in migrations['files']:
    relative = row['relative_path']
    before = published(relative)
    assert len(before) == row['before']['bytes'] and digest(before) == row['before']['sha256']
    raw = Path(row['raw']['path']).read_bytes()
    assert bind(Path(row['raw']['path'])) == row['raw']
    assert bind(Path(row['diff']['path'])) == row['diff']
    source = before.decode()
    expected_entries = [e['source_line'] for e in census['entries'] if e['path'] == relative]
    assert [e['before'] for e in row['edits']] == expected_entries
    for edit in row['edits']:
        assert 'PROMISE_HOST_PROFILES' not in edit['before']
        assert 'promise-with-resolvers' not in edit['before']
        assert edit['after'].count("'promise-with-resolvers'") == 1
        narrow = edit['after'].replace(", 'promise-with-resolvers'", '')
        # Five old single-name exclusions acquire a set solely for the new name.
        narrow = narrow.replace('not in {PROFILE}', '!= PROFILE').replace('not in {NEW_PROFILE}', '!= NEW_PROFILE')
        assert narrow == edit['before']
        assert source.count(edit['before']) == 1
        source = source.replace(edit['before'], edit['after'], 1)
    assert source.encode() == raw
    inverse = source
    for edit in reversed(row['edits']):
        assert inverse.count(edit['after']) == 1
        inverse = inverse.replace(edit['after'], edit['before'], 1)
    assert inverse.encode() == before
    patch = Path(row['diff']['path']).read_text()
    first = patch.splitlines()
    assert first[0].startswith('--- ') and first[1].startswith('+++ ')
    expected = ''.join(difflib.unified_diff(before.decode().splitlines(True), source.splitlines(True),
                                          fromfile=first[0][4:], tofile=first[1][4:]))
    assert expected == patch
    b_ast, a_ast = ast.parse(before.decode()), ast.parse(source)
    b_names = [n.name for n in ast.walk(b_ast) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    a_names = [n.name for n in ast.walk(a_ast) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    assert b_names == a_names and len(b_names) == row['test_groups']
    def constants(tree):
        return [(type(n.value).__name__, n.value) for n in ast.walk(tree) if isinstance(n, ast.Constant)
                and n.value != 'promise-with-resolvers']
    # AST traversal can reorder nearby constants when a comparison becomes a set;
    # exact inverse above is authoritative, while this multiset separately checks values.
    assert sorted(map(repr, constants(b_ast))) == sorted(map(repr, constants(a_ast)))
    host_before = [line for line in before.decode().splitlines() if 'PROMISE_HOST_PROFILES' in line]
    host_after = [line for line in source.splitlines() if 'PROMISE_HOST_PROFILES' in line]
    assert host_before == host_after
    all_group_count += len(b_names)
    migration_checks.append(dict(relative_path=relative, before=bind(O/'parent'/relative),
        raw=row['raw'], diff=row['diff'], edits=len(row['edits']),
        retained_groups=len(b_names), names=b_names, inverse_exact=True,
        old_literals_and_host_sets_exact=True, census_entries_exact=True))


def tables(source):
    env = {}
    def val(n):
        if isinstance(n, ast.Constant): return n.value
        if isinstance(n, ast.Name): return env[n.id]
        if isinstance(n, (ast.List, ast.Tuple)): return [val(x) for x in n.elts]
        if isinstance(n, ast.Set): return {val(x) for x in n.elts}
        if isinstance(n, ast.Dict): return {val(k): val(v) for k,v in zip(n.keys,n.values)}
        if isinstance(n, ast.BinOp) and isinstance(n.op, ast.BitOr): return val(n.left) | val(n.right)
        if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'copy' and not n.args:
            return val(n.func.value).copy()
        raise ValueError(type(n).__name__)
    for n in ast.parse(source).body:
        try:
            if isinstance(n, ast.Assign):
                value = val(n.value)
                for t in n.targets:
                    if isinstance(t, ast.Name): env[t.id] = value
                    elif isinstance(t, ast.Subscript) and isinstance(t.value, ast.Name): env[t.value.id][val(t.slice)] = value
            elif isinstance(n, ast.Expr) and isinstance(n.value, ast.Call) and isinstance(n.value.func, ast.Attribute) and n.value.func.attr == 'add':
                env[n.value.func.value.id].add(val(n.value.args[0]))
        except (ValueError, KeyError, AttributeError):
            pass
    return env

preservation = holds['preservation-1']
for row in preservation['files']:
    assert bind(Path(row['raw']['path'])) == row['raw']
oracle_path = C/'preservation-1/raw/tools/with-resolvers-preservation-oracle.json'
oracle = json.loads(oracle_path.read_bytes())
importer = published('tools/import_test262.py').decode()
runner = published('tools/test262_conformance.py').decode()
im, ru = tables(importer), tables(runner)
assert oracle['profiles'] == im['PROFILES'] and len(im['PROFILES']) == 59
assert oracle['roots'] == im['PROFILE_ROOTS']
assert oracle['tree_profiles'] == sorted(im['TREE_PROFILES'])
assert oracle['features'] == {k:sorted(v) for k,v in ru['PROFILE_FEATURES'].items()}
assert oracle['promise_host_profiles'] == sorted(ru['PROMISE_HOST_PROFILES'])
assert oracle['intrinsic_errors'] == sorted(ru['INTRINSIC_ERRORS'])
assert len(oracle['intrinsic_errors']) == 7
policies = {}
for name, features in ru['PROFILE_FEATURES'].items():
    names = ru['INTRINSIC_ERRORS'] | ({'AggregateError'} if name in {'aggregate-error','promise-any'} else set())
    policy = dict(format=2, supported_features=sorted(features), negative_intrinsic_errors=sorted(names),
                  strict=True, modules=False, async_completion=False, host_hooks=False, timeout_seconds=3.0)
    if name in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:
        policy['excluded_harness'] = ['resizableArrayBufferUtils.js']
    if name in ru['PROMISE_HOST_PROFILES']:
        policy.update(format=3, async_completion=True, host_hooks=True, request_protocol='ERJS2',
                      response_protocol='ERJR3', adapter_feature='test262-host',
                      completion_policy={'sync':'checked-sync','async':'authenticated-done'},
                      unhandled_rejection_policy='final-quiescent-veto', print_only_completion=False)
    policies[name] = dict(policy=policy, sha256=digest(json.dumps(policy, sort_keys=True).encode()))
assert policies == oracle['policies_at_timeout3'] and len(policies) == 59
function_checks = {}
exclusions = {'tools/import_test262.py': {'import_corpus','profile_tree_inventory'},
              'tools/test262_conformance.py': {'decode_response','harness_preflight','load_corpus','main','run_case'}}
for relative, source in [('tools/import_test262.py',importer),('tools/test262_conformance.py',runner)]:
    all_functions = {n.name:digest(ast.get_source_segment(source,n).encode()) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
    expected = {n:h for n,h in all_functions.items() if n not in exclusions[relative]}
    assert expected == oracle['unchanged_functions'][relative]
    assert len(expected) == preservation['function_counts'][relative]
    assert exclusions[relative] == set(preservation['changed_function_exclusions'][relative])
    function_checks[relative] = dict(total_parent_functions=len(all_functions), protected=len(expected),
                                     exact_exclusions=sorted(exclusions[relative]), hashes=expected)
test_path = C/'preservation-1/raw/tools/test_test262_with_resolvers_preservation.py'
test_source = test_path.read_text()
test_ast = ast.parse(test_source)
test_names = [n.name for n in ast.walk(test_ast) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(test_names) == 2
assert tables(test_source)['ORACLE_SHA'] == digest(oracle_path.read_bytes())

ci = holds['ci-1'];row = ci['files'][0]
parent_ci = published(row['relative_path'])
assert len(parent_ci) == row['before']['bytes'] and digest(parent_ci) == row['before']['sha256']
assert bind(Path(row['raw']['path'])) == row['raw']
candidate_ci = Path(row['raw']['path']).read_text()
addition = ci['addition']
assert candidate_ci.count(addition) == 1 and candidate_ci.replace(addition,'',1).encode() == parent_ci
anchor = '      - name: Preserve pinned AggregateError construction cases\n        run: python3 tools/test262_conformance.py --binary target/release/eris-js --profile aggregate-error --baseline tests/conformance/test262-aggregate-error-current.json --output artifacts/test262-aggregate-error-gate.json\n'
assert anchor + addition in candidate_ci
assert '--record-baseline' not in addition and '--features' not in addition
assert candidate_ci.index('cargo build --locked --release') < candidate_ci.index(addition)
assert candidate_ci.index(addition) < candidate_ci.index('cargo build --locked --release --features test262-host')

checks = save('checks.json', dict(migrations=migration_checks, migration_paths=20, migration_edits=35,
    retained_test_groups=all_group_count, policies=policies, function_checks=function_checks,
    preservation_test_names=test_names, ci_before=bind(O/'parent'/row['relative_path']),
    ci_raw=row['raw'], ci_exact_inverse=True))
review = dict(status='clear', findings=[], base=BASE,
    holds=[bind(C/p) for p in seals], checks=bind(checks), auditor=bind(Path(__file__)),
    scope='Independent static source peer of historical selection migrations, preservation oracle/test fixture and one ordinary CI command. No importer or runner implementation correctness claim beyond named preserved-source boundaries.',
    conclusions={
      'migrations':f'20 paths /35 entries exactly match the readiness census; all {all_group_count} test groups and all old constants/JS/hash literals survive. Only the new profile exclusion is added. Exact forward, inverse and regenerated diffs join the published parent.',
      'host_sets':'Every existing PROMISE_HOST_PROFILES assertion line is unchanged. New profile exclusions do not grant host membership or edit old feature isolation loops.',
      'policies':'All59 old tables/features and all59 timeout3 policy objects/hashes independently derive from published source. Default seven identities, AggregateError ordinary eighth identity and Any host eighth identity remain distinct.',
      'functions':'Oracle covers every old top-level importer function except the two selected edit sites (11 protected), and every old runner function except the five selected edit sites (57 protected), including unchanged classify, encoders, host validators, existing gates and Git authentication.',
      'mock_fixture':'The first test calls actual main once for each of59 old profiles with zero mocked cases and an inert byte file, forbids fetch/adapter/run_case, and patches every existing special health gate. Main reads the inert file twice, writes a real temporary report, and returns0 because the empty healthy roster is complete. The test compares actual report policy/hash to fixed values. It is policy coverage only, not corpus or gate health coverage.',
      'source_fixture':'The second test recomputes source hashes from installed modules and requires all68 protected names. A deleted or changed protected function fails. New functions and the seven selected edit sites remain deliberately outside that source-hash test.',
      'ci':'Exactly one two-line command is added immediately after AggregateError in the ordinary release job. It uses target/release/eris-js, the selected profile, checked baseline and distinct report path. All old workflow bytes and host build/gates remain exact under removal of this insertion.',
      'pending_dependency':'The selected baseline is intentionally absent at this source freeze and must come from the later healthy measured run before publication; this review does not claim CI execution.'},
    provenance='Hold before records point at the mutable checkout. This peer verifies their byte/hash identities against the immutable published Git blobs and retains independent parent copies; no assumption that a later live path remains a before image.',
    execution='Stdlib AST/hash/source comparison and read-only git show only. No project import, main/test execution, engine/network call, live edit or outcome inference.')
path = save('review.json',review)
print(json.dumps(bind(path)))
print('retained_groups',all_group_count)
