"""Independent stdlib-only documentation/source/log audit; no project imports."""
import collections
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
OUT = C / 'documentation-review-1'
BASE = 'dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'
def read(path):
    return json.loads(Path(path).read_text())
def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

bound = {}
def check_binding(row):
    actual = binding(row['path'])
    assert actual == {key: row[key] for key in ('path', 'bytes', 'sha256')}, actual
    bound[actual['path']] = actual
def walk(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            check_binding(value)
        for child in value.values():
            walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)

seal_path = C / 'documentation-1/source-ready.json'
seal = read(seal_path)
assert binding(seal_path)['sha256'] == '4fac159d62b165dcd5cb4ee56794d8831da98356c68531bd6afe8921abe179a3'
ledger_path = C / 'root/final-validation.json'
assert binding(ledger_path)['sha256'] == 'bc92cafb38f970f500627aed12504b6dcd9f9d91cafee04d9600ab5840d57bef'
ledger = read(ledger_path)
walk(seal)
walk(ledger)

edits = read(C / 'documentation-1/edit-manifest.json')
assert len(edits) == len(seal['files']) == 6
doc_checks = []
for row in seal['files']:
    relative = row['relative']
    old = Path(row['before']['path']).read_bytes()
    new = Path(row['raw']['path']).read_bytes()
    published = subprocess.run(['git', '-C', str(C / 'worktree'), 'show', BASE + ':' + relative],
                               check=True, stdout=subprocess.PIPE).stdout
    assert old == published
    edit, = [e for e in edits if e['relative'] == relative]
    assert old.count(edit['before'].encode()) == 1
    assert old.replace(edit['before'].encode(), edit['after'].encode(), 1) == new
    assert new.count(edit['after'].encode()) == 1
    assert new.replace(edit['after'].encode(), edit['before'].encode(), 1) == old
    patch = ''.join(difflib.unified_diff(old.decode().splitlines(True), new.decode().splitlines(True),
                                       fromfile='a/' + relative, tofile='b/' + relative))
    assert patch.encode() == Path(row['diff']['path']).read_bytes()
    doc_checks.append({'relative': relative, 'published_before_exact': True,
                       'single_selected_replacement_and_inverse_exact': True,
                       'unified_diff_exact': True})
for relative, header in [('docs/VALIDATION.md', b'# Validation record\n\n'),
                          ('docs/promise-with-resolvers.md', b'# Promise.withResolvers\n\n')]:
    old = (C / 'documentation-1/before' / relative).read_bytes()
    new = (C / 'documentation-1/raw' / relative).read_bytes()
    assert old.startswith(header) and new.startswith(header)
    assert new.endswith(old[len(header):])

report_paths = [C / ('upstream-with-resolvers' + suffix + '.json')
                for suffix in ('-1', '-record-1', '-check-1')]
reports = [read(p) for p in report_paths]
first = reports[0]
for report in reports:
    for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
                'corpus_manifest_sha256', 'binary', 'binary_sha256'):
        assert report[key] == first[key]
    assert len(report['cases']) == 12 and len(report['harness_preflight']) == 44
    assert collections.Counter(row['status'] for row in report['cases']) == {'passed': 10, 'unsupported': 2}
    assert all(row['verified'] is True for row in report['harness_preflight'])
    assert collections.Counter(row['expected'] for row in report['harness_preflight']) == {'passed': 18, 'failed': 26}
    assert report['harness_preflight_passed'] is True
    assert report['regressions'] == report['improvements'] == []
unsupported = [row for row in first['cases'] if row['status'] == 'unsupported']
assert {row['mode'] for row in unsupported} == {'sloppy', 'strict'}
assert all(row['file'] == 'test/built-ins/Promise/withResolvers/ctx-ctor.js'
           and row['reason'] == 'unimplemented declared features: class'
           and 'observation' not in row for row in unsupported)
assert len({row['file'] for row in first['cases']}) == 6
assert first['runner_policy']['async_completion'] is False
assert first['runner_policy']['host_hooks'] is False
assert len(first['runner_policy']['negative_intrinsic_errors']) == 7
baseline_path = C / 'worktree/tests/conformance/test262-promise-with-resolvers-current.json'
baseline = read(baseline_path)
expected_baseline = {key: first[key] for key in ('revision', 'corpus_manifest_sha256',
                                              'runner_policy_sha256', 'binary_sha256')}
expected_baseline['cases'] = {row['id']: {key: row[key] for key in
                                        ('status', 'case_sha256', 'source_sha256')}
                              for row in first['cases']}
assert baseline == expected_baseline

def roster(name, expected):
    path = C / 'validation' / (name + '.log')
    text = path.read_text()
    rows = re.findall(r'^(test_\w+) \(([^\n()]+)\) \.\.\. ok$', text, re.M)
    assert len(rows) == len(set(rows)) == expected
    assert re.search(r'\nRan ' + str(expected) + r' tests in [0-9.]+s\n\nOK\n$', text)
    return set(rows)
parent_roster = roster('python-parent-1', 624)
candidate_roster = roster('python-full-1', 652)
focused_roster = roster('selected-candidate-1', 28)
assert not (parent_roster & focused_roster)
assert candidate_roster == parent_roster | focused_roster

legacy_checks = []
for name in ('aggregate-error', 'existing', 'all', 'race', 'settled', 'any'):
    before_path = B / ('upstream-' + name + '-1.json')
    after_path = C / ('upstream-' + name + '-1.json')
    before, after = read(before_path), read(after_path)
    keys = ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
            'corpus_manifest_sha256', 'binary', 'binary_sha256')
    for key in keys:
        assert before[key] == after[key], (name, key)
    assert after['regressions'] == after['improvements'] == []
    legacy_checks.append({'name': name, 'parent': binding(before_path), 'current': binding(after_path),
                          'cases': len(after['cases']), 'controls': len(after['harness_preflight']),
                          'exact_keys': list(keys)})
assert sum(row['cases'] for row in legacy_checks) == 1288
assert sum(row['controls'] for row in legacy_checks) == 502
baseline_checks = []
for old in (B / 'worktree/tests/conformance').glob('test262-*-current.json'):
    current = C / 'worktree/tests/conformance' / old.name
    assert current.read_bytes() == old.read_bytes(), old.name
    baseline_checks.append(old.name)

binary_receipt = read(C / 'root/binary-reuse-1.json')
binary_checks = []
for row in binary_receipt['binaries']:
    actual = binding(row['binary'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256']
    assert row['toolchain'] == '1.88.0'
    build = read(row['build'])
    assert build['exit'] == 0
    build_log = Path(row['build']).parent / build['log']
    assert binding(build_log)['sha256'] == build['sha256']
    assert 'Finished `release` profile' in build_log.read_text()
    binary_checks.append({'binary': actual, 'build_receipt': binding(row['build']),
                          'toolchain': row['toolchain'], 'features': row['features']})
assert first['binary_sha256'] == binary_checks[0]['binary']['sha256']
parent_inventory = read(C / 'source-parent.json')['source_sha256']
final_inventory = read(C / 'source-final.json')['source_sha256']
rust_inputs = [p for p in parent_inventory if p.endswith('.rs') or p in ('Cargo.toml', 'Cargo.lock', 'build.rs')]
assert all(final_inventory.get(p) == parent_inventory[p] for p in rust_inputs)
assert not [p for p in final_inventory if p.endswith('.rs') and p not in parent_inventory]

corpus_roots = [C / 'importer-1/corpus', C / 'offline-import-1/corpus',
                C / 'worktree/tests/upstream/test262-promise-with-resolvers']
corpus = [{str(p.relative_to(root)): p.read_bytes() for p in root.rglob('*') if p.is_file()}
          for root in corpus_roots]
assert corpus[0] == corpus[1] == corpus[2]
assert len(corpus[0]) == 19
assert len([p for p in corpus[0] if p.startswith('test/') and p.endswith('.js')]) == 6
assert sorted(p for p in corpus[0] if p.startswith('harness/')) == ['harness/assert.js', 'harness/propertyHelper.js', 'harness/sta.js']
assert sum(map(len, corpus[0].values())) == 101418

result = {'status': 'clear', 'method': 'Independent stdlib hash/JSON/log/byte comparison and read-only published Git blob reads; no project import or execution.',
          'documentation_seal': binding(seal_path), 'final_ledger': binding(ledger_path),
          'documents': doc_checks, 'historical_validation_suffix_exact': True,
          'historical_runtime_body_exact': True,
          'selected': {'cases': 12, 'passed': 10, 'unsupported_class_modes': 2,
                       'controls': 44, 'expected_passed_controls': 18, 'expected_failed_controls': 26,
                       'three_case_control_arrays_exact': True, 'compact_baseline_exact_projection': True,
                       'reports': [binding(p) for p in report_paths]},
          'python': {'parent': 624, 'candidate': 652, 'focused': 28, 'exact_disjoint_roster_union': True,
                     'logs': [binding(C / 'validation' / (n + '.log')) for n in
                              ('python-parent-1', 'python-full-1', 'selected-candidate-1')]},
          'legacy': {'cases': 1288, 'controls': 502, 'comparisons': legacy_checks,
                     'unchanged_old_baselines': baseline_checks},
          'binary_checks': binary_checks, 'unchanged_rust_cargo_input_count': len(rust_inputs),
          'corpus': {'files': 19, 'bytes': 101418, 'authored_offline_and_live_bytes_exact': True},
          'validated_bindings': list(bound.values())}
(OUT / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({'checks': binding(OUT / 'checks.json'), 'documents': len(doc_checks),
                  'bound_files': len(bound), 'rust_inputs': len(rust_inputs)}, indent=2))
