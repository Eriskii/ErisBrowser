"""Bind documentation to completed receipts; inspect data only."""
from pathlib import Path
import collections,hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;C=R.parent;B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def read(p):return json.loads(Path(p).read_text())
final=read(C/'root/final-validation.json');base=final['base']
assert bind(C/'root/final-validation.json')['sha256']=='bc92cafb38f970f500627aed12504b6dcd9f9d91cafee04d9600ab5840d57bef'
refs=[]
def verify(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   b=bind(x['path']);assert b=={k:x[k] for k in b};refs.append(b)
  for v in x.values():verify(v)
 elif isinstance(x,list):
  for v in x:verify(v)
verify(final)
reports=[read(x['path']) for x in final['selected_reports']]
report=reports[0]
assert all(r['cases']==report['cases'] and r['harness_preflight']==report['harness_preflight'] for r in reports)
assert len(report['cases'])==12 and len(report['harness_preflight'])==44
assert collections.Counter(r['status'] for r in report['cases'])=={'passed':10,'unsupported':2}
assert all(r['verified'] is True for r in report['harness_preflight'])
unsupported=[r for r in report['cases'] if r['status']=='unsupported'];assert all(r['file'].endswith('/ctx-ctor.js') and r['reason']=='unimplemented declared features: class' and 'observation' not in r for r in unsupported)
baseline=read(final['selected']['baseline']['path']);assert set(baseline)=={'revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256','cases'}
assert baseline['cases']=={r['id']:{k:r[k] for k in ('status','case_sha256','source_sha256')} for r in report['cases']}
legacy=[]
for row in final['legacy']['profiles']:
 name=row['name'];old=B/('upstream-'+name+'-1.json');prior=read(old);current=read(row['report']['path'])
 for key in ('cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','binary_sha256'):
  assert current[key]==prior[key],(name,key)
 legacy.append(bind(old))
assert final['legacy']['cases']==1288 and final['legacy']['controls']==502
ids={}
for name,count in [('python-parent-1',624),('python-full-1',652),('selected-candidate-1',28)]:
 text=(C/'validation'/(name+'.log')).read_text();rows=re.findall(r'^test_\w+ \(([^\n]+)\) \.\.\. ok$',text,re.M)
 assert len(rows)==len(set(rows))==count,(name,len(rows))
 assert re.search(r'Ran '+str(count)+r' tests in [\d.]+s\n\nOK\s*$',text)
 ids[name]=set(rows)
assert ids['python-parent-1']<=ids['python-full-1']
assert ids['python-full-1']-ids['python-parent-1']==ids['selected-candidate-1']
assert final['scope']['corpus_files']==19 and read(C/'root/offline-import-1.json')['exact_bytes'] is True
paths=read(R/'draft-index.json')['files'];edits=read(R/'edit-manifest.json');files=[]
for path in paths:
 before=(R/'before'/path).read_bytes();raw=(R/'raw'/path).read_bytes()
 assert before==subprocess.check_output(['git','show',base+':'+path],cwd=C/'worktree')
 assert (C/'worktree'/path).read_bytes()==before
 inverse=raw.decode()
 for edit in reversed([e for e in edits if e['relative']==path]):
  assert inverse.count(edit['after'])==1;inverse=inverse.replace(edit['after'],edit['before'],1)
 assert inverse.encode()==before
 files.append({'relative':path,'new':False,'before':bind(R/'before'/path),'raw':bind(R/'raw'/path),'diff':bind(R/'diffs'/(path+'.patch'))})
assert (R/'raw/docs/VALIDATION.md').read_text().endswith((R/'before/docs/VALIDATION.md').read_text().removeprefix('# Validation record\n\n'))
assert (R/'raw/docs/promise-with-resolvers.md').read_text().endswith((R/'before/docs/promise-with-resolvers.md').read_text().removeprefix('# Promise.withResolvers\n\n'))
checks={'status':'checked','published_base':base,'six_before_git_joins':True,'six_exact_edit_inverses':True,'historical_validation_suffix_byte_exact':True,'historical_runtime_body_byte_exact':True,'selected_actual_counts':{'passed':10,'unsupported':2,'healthy_controls':44},'unsupported':'Only ctx-ctor.js declared-class exclusions, both modes; no adapter observation.','selected_three_full_case_control_arrays_exact':True,'compact_baseline':'Exactly five top-level fields; 12 statuses plus case/source fingerprints and revision/corpus/policy/binary bindings, distinct from raw reports.','python':'624 unique old full-suite IDs plus28 focused new IDs equal652 unique passing IDs.','legacy_full_arrays_exact':{'cases':1288,'controls':502,'profiles':6},'execution_qualification':'All execution receipts belong to root. Documentation author ran only stdlib data/text/hash and read-only Git checks. No new Rust run/build/Clippy is claimed.','corrections_retained':final['corrections'],'scope':'Selected source inventory is not a complete build graph; docs make no graph-size claim. No full-compatibility, security or performance claim.','links_pending_publication':['docs/evidence/promise-with-resolvers-upstream/manifest.json','docs/evidence/promise-with-resolvers-upstream/sources-and-checks.tar.gz'],'legacy_report_bindings':legacy}
(R/'claim-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
selected_refs=['root/final-validation.json','source-final.json','root/validation-checks-1.json','root/binary-reuse-1.json','root/offline-import-1.json','root/selected-initial-observation.json','root/selection-1.json','root/run-case-boundary-1.json','ci-1/source-ready.json','controls-1/source-ready.json']
ready={'status':'source_ready','base':base,'scope':'Six documentation paths only; completed ordinary upstream profile results with earlier runtime and validation text preserved.','files':files,'result_bindings':[bind(C/p) for p in selected_refs]+final['selected_reports']+[final['selected']['baseline']],'claim_checks':bind(R/'claim-checks.json'),'exact_edits':bind(R/'edit-manifest.json'),'authoring_sources':[bind(R/'author.py'),bind(R/'seal.py')],'qualifications':['All factual outcome text is bound to the final ledger and original reports; no project execution or live edits by the documentation author.','Two orchestration assertions and the separate evidence-parser correction remain described; no candidate/control/test correction occurred.','Evidence links are anticipated publication targets owned by root; CI configuration is not claimed as a remote result.']}
(R/'source-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps(bind(R/'source-ready.json')))
