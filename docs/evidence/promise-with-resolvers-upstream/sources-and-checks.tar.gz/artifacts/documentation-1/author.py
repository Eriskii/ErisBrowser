"""External documentation draft; no project imports or live changes."""
from pathlib import Path
import difflib,hashlib,json,subprocess
R=Path(__file__).resolve().parent;C=R.parent
base='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/promise-with-resolvers.md','docs/VALIDATION.md']
before={p:subprocess.check_output(['git','show',base+':'+p],cwd=C/'worktree').decode() for p in paths}
after=dict(before);edits=[]
def replace(path,old,new):
 assert after[path].count(old)==1,path
 after[path]=after[path].replace(old,new,1);edits.append({'relative':path,'before':old,'after':new})
replace('README.md', '''settlement and terminal queue behavior are preserved. A dedicated upstream
profile remains separate work.
''','''settlement and terminal queue behavior are preserved. Its complete pinned
six-source upstream profile retains all 12 modes: **10 passed and two unsupported**,
with all **44 controls verified**. The two class-tagged modes remain excluded;
the profile uses ordinary requests and responses without a Promise host policy.
''')
replace('docs/COMPATIBILITY.md','''deferred settlement, callback identity and terminal suspension. No dedicated
withResolvers upstream profile is claimed.
''','''deferred settlement, callback identity and terminal suspension. Its complete
pinned upstream directory retains six sources and all 12 modes, with **10 passed
and two unsupported** under a healthy 44-control gate. Both modes of
`ctx-ctor.js` are excluded for the declared `class` feature. The synchronous
profile uses ordinary ERJS1/ERJR2 transport and the existing seven intrinsic
error identities; it adds no async completion or class support.
''')
replace('docs/ROADMAP.md','''Its runtime controls and six older profile replays pass their selected checks;
a dedicated withResolvers upstream profile remains separate work.
''','''Its dedicated six-source, 12-mode upstream profile now records 10 passed and
two class-metadata exclusions, with all 44 controls verified. The ordinary
profile preserves all six older profile reports and adds no async host policy.
''')
security='''
The withResolvers upstream profile uses ordinary ERJS1 requests and accepts only
ERJR2 responses with the existing seven intrinsic error identities. A supplied
completion-policy key is refused before metadata exclusions, encoding or adapter
execution. Its 44-control gate checks exact source/helper identities, bounded raw
fields and prerequisite records, then recomputes ordinary classification. An
unhealthy gate blocks every source mode and prevents baseline recording. These
checks rely on the trusted adapter; they grant no renderer authority and change
no runtime, transport bytes or resource limits.
'''
anchor='''decoder policy. These logical charges do not establish process-memory bounds.
'''
replace('docs/SECURITY.md',anchor,anchor+security)
upstream='''## Complete pinned upstream profile

The `promise-with-resolvers` profile retains all six original files in
`built-ins/Promise/withResolvers` at Test262 revision
`7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`, in both sloppy and strict modes.
It records **10 passed and two unsupported modes**, with all **44 controls
verified**. Both unsupported rows are `ctx-ctor.js`: its declared `class`
feature is excluded before adapter execution. No source or mode is removed
because of its outcome.

The 19-file package includes the six sources, three unchanged helpers
(`assert.js`, `sta.js` and `propertyHelper.js`), legal files, complete directory
proofs linked to the pinned root, and a manifest. An offline importer replay
reproduces every packaged byte. All six sources are synchronous; this profile
uses ordinary ERJS1 requests and ERJR2 responses with the existing seven
intrinsic error identities. It adds no Promise host requirement or async
completion policy. Class syntax remains unsupported.

The canonical gate retains 32 existing ordinary controls and adds three
positive/mismatch pairs in both modes. They exercise generic capability
capture and constructor validation, genuine pending Promises and resolver
metadata, and fresh result objects with exact callback identities and data
properties. Each mismatch changes one final assertion. Pending `then` is a
synchronous brand check, not asynchronous settlement coverage. Control success
means the expected result was verified, including deliberate assertion failures.

Admission rebuilds source, metadata, mode and ordered-helper fingerprints;
checks exact result and prerequisite records; validates the six ordinary raw
fields; and recomputes classification. A completion-policy key is refused
before encoding or dispatch, and ERJR3 responses are rejected. A bad gate blocks
all 12 source modes, including metadata-excluded rows, and cannot create or
overwrite a baseline.

All **652 Python tests pass**, retaining the 624 parent test identities and
adding 28 groups. The first focused candidate run passes all 28. Healthy
recording and replay retain the exact 12 case and 44 control arrays. The new
baseline stores a compact map of the 12 statuses and case/source fingerprints,
with corpus, policy and binary bindings; it is not a copy of the full reports. The six older profiles keep
their complete 1,288 case and 502 control records, including failed and
unsupported outcomes, with unchanged policies and baselines.

Two orchestration assertions were corrected after complete reports had been
written: the initial recipe expected exit zero despite retained unsupported
rows, and the first replay verifier compared the compact baseline with a full
report. Neither correction changes source, controls, test expectations or raw
results. Those initial records remain in the evidence. A separate evidence-parser
correction deduplicates repeated parent-test summary lines without changing raw
logs or project results.

This checkpoint changes tooling, corpus data, tests and the adjacent ordinary
CI gate. It reuses the published runtime checkpoint's exact Rust 1.88 ordinary
and host adapters; Rust sources, build settings, wire bytes and runtime limits
are unchanged. No new Rust suite, Clippy or build result is claimed. The CI step
is configured here; no remote result for this checkpoint is claimed. These
selected results establish neither full ECMAScript compatibility nor a security
or performance result.

The [upstream evidence manifest](evidence/promise-with-resolvers-upstream/manifest.json)
and [source/check archive](evidence/promise-with-resolvers-upstream/sources-and-checks.tar.gz)
retain the source contracts, original reports, compact baseline and validation
receipts. The earlier runtime record below keeps its historical scope.

## Runtime checkpoint

'''
replace('docs/promise-with-resolvers.md','# Promise.withResolvers\n\n','# Promise.withResolvers\n\n'+upstream)
validation='''## Complete pinned Promise.withResolvers selection

The [withResolvers upstream profile](promise-with-resolvers.md) retains all six
pinned sources and 12 modes. It records **10 passed and two unsupported modes**,
with all **44 controls verified**. Both unsupported rows are `ctx-ctor.js`,
excluded for its declared `class` feature before adapter execution. All six
originals are synchronous; the profile uses ordinary ERJS1/ERJR2 transport and
the existing seven intrinsic error identities.

The complete Python suite passes **652 tests**, preserving all 624 parent
identities and adding 28 groups. The first focused candidate run passes all 28.
Offline importing reproduces the complete 19-file package byte for byte.
The gate authenticates canonical control identities, raw observations and
prerequisites; an unhealthy gate blocks all 12 modes and refuses both new and
existing baseline destinations.

Healthy recording and replay retain the complete **12 case and 44 control
arrays**. The measured baseline is the compact 12-status map with binding
metadata, not a full report. All six older profiles preserve their complete
**1,288 case and 502 control arrays**, including nonpassing outcomes, with no
old policy or baseline changes.

The initial orchestration recipe incorrectly required exit zero despite the
two retained unsupported rows; a later verifier incorrectly equated the compact
baseline with a full report. Both assertions were corrected without changing
source, controls, tests or recorded outcomes. The completed initial reports
remain retained. A separate evidence-parser correction deduplicates repeated
parent-test summary lines without changing raw logs or project results.

This tooling checkpoint reuses the published runtime's exact Rust 1.88 ordinary
and host adapters. Rust execution inputs and limits are unchanged; no new Rust
suite, Clippy or build is claimed. The adjacent ordinary baseline CI gate is
configured without a new remote-result claim. Evidence is linked from the
chapter. All prior validation text below remains byte-exact.

'''
replace('docs/VALIDATION.md','# Validation record\n\n','# Validation record\n\n'+validation)
# Exact removal of selected additions/replacements recovers every parent file.
for p in paths:
 inverse=after[p]
 for e in reversed([e for e in edits if e['relative']==p]):
  assert inverse.count(e['after'])==1;inverse=inverse.replace(e['after'],e['before'],1)
 assert inverse==before[p]
 assert (C/'worktree'/p).read_text()==before[p],p
 bp=R/'before'/p;rp=R/'raw'/p;dp=R/'diffs'/(p+'.patch')
 for x in (bp,rp,dp):x.parent.mkdir(parents=True,exist_ok=True)
 bp.write_text(before[p]);rp.write_text(after[p]);dp.write_text(''.join(difflib.unified_diff(before[p].splitlines(True),after[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
assert after['docs/VALIDATION.md'].endswith(before['docs/VALIDATION.md'].removeprefix('# Validation record\n\n'))
assert after['docs/promise-with-resolvers.md'].endswith(before['docs/promise-with-resolvers.md'].removeprefix('# Promise.withResolvers\n\n'))
(R/'edit-manifest.json').write_text(json.dumps(edits,indent=2)+'\n')
(R/'draft-index.json').write_text(json.dumps({'status':'draft awaiting root final-validation before sealing','base':base,'files':paths,'historical_validation_suffix_exact':True,'historical_runtime_body_exact':True,'upstream_words':len(upstream.split()),'validation_words':len(validation.split()),'execution':'Only inert text composition and read-only published Git; no project execution or live writes.'},indent=2)+'\n')
print(json.dumps({'paths':len(paths),'upstream_words':len(upstream.split()),'validation_words':len(validation.split())}))
