"""Root-only offline importer replay; authored here, never executed by the author."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sys
import threading
from unittest.mock import patch


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--worktree', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--receipt', type=Path, required=True)
    args = parser.parse_args()
    hold = Path(__file__).resolve().parent
    mapping = json.loads((hold / 'fetch-url-map.json').read_bytes())
    oracle_bytes = (hold / 'raw/tools/test262-promise-with-resolvers-import-oracle.json').read_bytes()
    if digest(oracle_bytes) != '5b88482eae075e32cf5f0dd4221eb68c14555a7937cc1d964928055ce34b3d56':
        raise ValueError('frozen oracle differs')
    oracle = json.loads(oracle_bytes)
    retained = Path(mapping['corpus'])
    if args.output.exists() or args.receipt.exists():
        raise ValueError('replay output and receipt must be new paths')
    expected_files = {row['path']: row for row in oracle['all_files']}
    if {p.relative_to(retained).as_posix() for p in retained.rglob('*') if p.is_file()} != set(expected_files):
        raise ValueError('retained corpus inventory differs')
    for name, row in expected_files.items():
        data = (retained / name).read_bytes()
        if len(data) != row['bytes'] or digest(data) != row['sha256']:
            raise ValueError('retained corpus bytes differ: ' + name)
    urls = mapping['urls']
    if len(urls) != 18 or set(urls.values()) != set(expected_files) - {'manifest.json'}:
        raise ValueError('retained URL coverage differs')
    seen, lock = Counter(), threading.Lock()

    def fetch(url):
        if url not in urls:
            raise AssertionError('unlisted URL; no network fallback: ' + url)
        with lock:
            seen[url] += 1
        return (retained / urls[url]).read_bytes()

    sys.path.insert(0, str(args.worktree.resolve() / 'tools'))
    import import_test262 as importer
    with patch.object(importer, 'fetch', side_effect=fetch):
        importer.import_corpus(args.output, 'promise-with-resolvers')
    if seen != Counter(urls.keys()):
        raise ValueError('offline replay request multiset differs')
    actual_names = {p.relative_to(args.output).as_posix() for p in args.output.rglob('*') if p.is_file()}
    if actual_names != set(expected_files):
        raise ValueError('offline replay output inventory differs')
    for name in sorted(expected_files):
        if (args.output / name).read_bytes() != (retained / name).read_bytes():
            raise ValueError('offline replay output bytes differ: ' + name)
    args.receipt.parent.mkdir(parents=True, exist_ok=True)
    args.receipt.write_text(json.dumps(dict(status='pass', profile='promise-with-resolvers',
        files=19, bytes=101418, requests=18, exact_bytes=True, network=False,
        oracle_sha256=digest(oracle_bytes), importer_sha256=digest(Path(importer.__file__).read_bytes()),
        output=str(args.output.resolve()), request_counts=dict(sorted(seen.items()))), indent=2) + '\n')


if __name__ == '__main__':
    main()
