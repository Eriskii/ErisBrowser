"""Independent stdlib data/proof derivation; no project imports or execution."""
import ast
import hashlib
import json
import re
import subprocess
from pathlib import Path

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
W, R, O = C / 'worktree', C / 'readiness-1', C / 'importer-1'
BASE = 'dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'
PROFILE = 'promise-with-resolvers'
REVISION = '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
ROOT = '91b2052adad1f066ae031e2ff3a1e9bd6d732886'
LEAF = '062393e615d0cf97a0252e6a93923bd91444a455'
SCOPE = 'all 6 original .js files in the complete Promise/withResolvers subtree; root-linked nonrecursive Git proofs and unchanged three-helper closure; all original feature metadata retained; no execution or conformance claim'
HELPERS = ['assert.js', 'sta.js', 'propertyHelper.js']


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data, str) else data)
    return path


def jsave(path, value):
    return save(path, json.dumps(value, indent=2, ensure_ascii=True) + '\n')


# Restricted literal table inspection, never eval/compile/import project code.
def tables(source):
    env = {}

    def value(node):
        if isinstance(node, ast.Constant):
            return node.value
        if isinstance(node, ast.Name):
            return env[node.id]
        if isinstance(node, ast.Dict):
            return {value(k): value(v) for k, v in zip(node.keys, node.values)}
        if isinstance(node, (ast.List, ast.Tuple)):
            return [value(x) for x in node.elts]
        if isinstance(node, ast.Set):
            return {value(x) for x in node.elts}
        raise ValueError(type(node).__name__)

    for node in ast.parse(source).body:
        if isinstance(node, ast.Assign):
            try:
                result = value(node.value)
            except (ValueError, KeyError):
                continue
            for target in node.targets:
                if isinstance(target, ast.Name):
                    env[target.id] = result
    return env


parent = (W / 'tools/import_test262.py').read_bytes()
assert parent == subprocess.check_output(['git', 'show', BASE + ':tools/import_test262.py'], cwd=W)
assert parent == (R / 'parent/tools/import_test262.py').read_bytes()
runner = (W / 'tools/test262_conformance.py').read_bytes()
assert runner == subprocess.check_output(['git', 'show', BASE + ':tools/test262_conformance.py'], cwd=W)
assert runner == (R / 'parent/tools/test262_conformance.py').read_bytes()
save(O / 'before/tools/import_test262.py', parent)
save(O / 'parent/tools/test262_conformance.py', runner)
config = tables(parent.decode())
assert config['REVISION'] == REVISION and config['REVISION_TREE'] == ROOT
assert len(config['PROFILES']) == 59 and PROFILE not in config['PROFILES']

proofs, trees, tree_hashes = {}, {}, []
for path in sorted((R / 'proof').glob('*.json')):
    data = path.read_bytes()
    doc = json.loads(data)
    proofs['inventory-proof/' + path.name] = data
    if path.name == 'commit.json':
        assert doc['sha'] == REVISION and doc['tree']['sha'] == ROOT
        continue
    assert doc['truncated'] is False
    assert path.name == 'tree-' + doc['sha'] + '.json'
    names, chunks = {}, []
    for entry in doc['tree']:
        name = entry['path']
        assert name not in names and '/' not in name and '\0' not in name
        names[name] = entry
        raw = name.encode()
        chunks.append((raw + (b'/' if entry['type'] == 'tree' else b''),
                       entry['mode'].lstrip('0').encode() + b' ' + raw + b'\0' + bytes.fromhex(entry['sha'])))
    body = b''.join(x[1] for x in sorted(chunks))
    actual = hashlib.sha1(b'tree ' + str(len(body)).encode() + b'\0' + body).hexdigest()
    assert actual == doc['sha']
    trees[actual] = names
    tree_hashes.append(dict(sha=actual, entries=len(names)))
assert len(proofs) == 7 and len(trees) == 6
current = ROOT
chain = []
for name in ['test', 'built-ins', 'Promise', 'withResolvers']:
    entry = trees[current][name]
    assert entry['type'] == 'tree'
    chain.append(dict(parent=current, name=name, child=entry['sha']))
    current = entry['sha']
assert current == LEAF
leaf = trees[LEAF]
assert len(leaf) == 6 and all(e['type'] == 'blob' and e['mode'] == '100644' and n.endswith('.js') for n, e in leaf.items())
root = trees[ROOT]
harness = trees[root['harness']['sha']]
auxiliary = {}
for name in sorted(HELPERS):
    auxiliary['harness/' + name] = harness[name]['sha']
for name in ('LICENSE', 'INTERPRETING.md'):
    auxiliary[name] = root[name]['sha']

sources, metadata, cases = {}, {}, []
for name, entry in sorted(leaf.items()):
    data = (R / 'originals' / name).read_bytes()
    assert blob(data) == entry['sha'] and len(data) == entry['size']
    path = 'test/built-ins/Promise/withResolvers/' + name
    sources[path] = data
    front = data.decode().split('/*---', 1)[1].split('---*/', 1)[0]
    fields = dict(re.findall(r'^(flags|includes|features|locale):\s*\[([^\]]*)\]\s*$', front, re.M))
    meta = {key: [x.strip() for x in fields.get(key, '').split(',') if x.strip()]
            for key in ('flags', 'includes', 'features', 'locale')}
    meta['negative'] = None
    assert not re.search(r'^(negative|timeout):', front, re.M)
    assert meta['flags'] == meta['locale'] == []
    assert meta['features'] == ['promise-with-resolvers'] + (['class'] if name == 'ctx-ctor.js' else [])
    assert meta['includes'] == (['propertyHelper.js'] if name == 'result.js' else [])
    metadata[path] = meta
for path, expected in auxiliary.items():
    data = (R / 'auxiliary' / path).read_bytes()
    assert blob(data) == expected
    sources[path] = data
assert len(sources) == 11 and sum(len(v) for k, v in sources.items() if k.startswith('test/')) == 3708
for path, meta in sorted(metadata.items()):
    for mode in ('sloppy', 'strict'):
        identity = dict(source_sha256=sha(sources[path]), mode=mode, metadata=meta,
                        harness=[dict(name=n, sha256=sha(sources['harness/' + n]))
                                 for n in ['assert.js', 'sta.js'] + meta['includes']])
        cases.append(dict(id=path + ':' + mode, case_sha256=sha(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())))
census = json.loads((R / 'corpus-census.json').read_bytes())
assert cases == [dict(id=r['id'], case_sha256=r['case_sha256']) for r in census['cases']]

description = dict(method='complete-nonrecursive-git-trees', revision=REVISION,
                   root_tree=ROOT, directory_trees={'Promise/withResolvers': LEAF}, auxiliary_blobs=auxiliary)
manifest = dict(format=1, repository='https://github.com/tc39/test262', revision=REVISION,
                scope=SCOPE, directories={'Promise/withResolvers': sorted(leaf)}, test_files=6, files=[])
manifest['inventory_proof'] = dict(description, files=[])
url_map = {}
for path, data in sorted(proofs.items()):
    route = 'commits/' + REVISION if path.endswith('/commit.json') else 'trees/' + Path(path).name[5:-5]
    url = 'https://api.github.com/repos/tc39/test262/git/' + route
    manifest['inventory_proof']['files'].append(dict(path=path, bytes=len(data), sha256=sha(data), url=url))
    url_map[url] = path
for path, data in sorted(sources.items()):
    manifest['files'].append(dict(path=path, upstream_path=path, bytes=len(data), sha256=sha(data)))
    url_map['https://raw.githubusercontent.com/tc39/test262/' + REVISION + '/' + path] = path
package = dict(sources, **proofs)
package['manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
assert len(package) == 19 and len(url_map) == 18
all_files = []
for path, data in sorted(package.items()):
    save(O / 'corpus' / path, data)
    all_files.append(dict(path=path, bytes=len(data), sha256=sha(data)))
tables_hashes = {name: sha(json.dumps(value, sort_keys=True).encode()) for name, value in {
    'PROFILES': config['PROFILES'], 'PROFILE_ROOTS': config['PROFILE_ROOTS'],
    'TREE_PROFILES': sorted(config['TREE_PROFILES'])}.items()}
oracle = dict(base=BASE, profile=PROFILE, expected_manifest=manifest,
              manifest_sha256=sha(package['manifest.json']), all_files=all_files,
              total_package_bytes=sum(r['bytes'] for r in all_files), metadata=metadata,
              case_identities=cases, old_profile_count=59, old_tables_sha256=tables_hashes,
              source_features={'promise-with-resolvers': 6, 'class': 1},
              source_includes={'propertyHelper.js': 1}, source_bytes=3708,
              source_modes=12, completion_policy_present=False,
              qualification='Exact source-derived data only. All six originals retained; no runtime outcome prediction.')
oracle_path = jsave(O / 'raw/tools/test262-promise-with-resolvers-import-oracle.json', oracle)
urls_path = jsave(O / 'fetch-url-map.json', dict(base=BASE, profile=PROFILE,
    corpus=str(O / 'corpus'), urls=url_map, unique_fetches=18,
    qualification='Retained raw response bytes only. Reject any unlisted URL; no network fallback.'))
contract = dict(status='frozen before importer implementation payload', base=BASE,
    profile=PROFILE, scope_literal=SCOPE, oracle=bind(oracle_path), package_files=19,
    importer_groups=[
        dict(name='test_complete_19_file_replay_matches_frozen_manifest_and_every_byte', expected_parent='missing new importer constants; error before replay', coverage='Every byte/manifest/proof/URL matches fixed oracle; offline import makes18 unique fetches.'),
        dict(name='test_all_12_metadata_identities_retain_modes_features_and_helper_order', expected_parent='pass using existing parse_metadata only', coverage='All six original metadata objects,12 ordinary fingerprints,3 helper closure and class body remain exact; no completion_policy.'),
        dict(name='test_all_proofs_refuse_corruption_and_selected_subtree_has_no_omitted_children', expected_parent='missing profile; error before refusal variants', coverage='All7proofs, truncated/omitted/renamed/duplicate/unsafe/changed leaf entries; mocked authenticated walker isolates descendant postcondition.'),
        dict(name='test_frozen_selection_refusals_and_all_59_old_profile_tables_are_preserved', expected_parent='missing new importer constants; error before refusal variants', coverage='Wrong counts/root/path/constants, consistent changed selection, all59 old table hashes unchanged.'),
        dict(name='test_every_source_helper_and_legal_blob_mutation_is_refused_before_publication', expected_parent='missing new importer constants; error before refusal variants', coverage='All11source/helper/legal byte mutations and one missing response from each source/helper/proof class; output remains absent.'),
        dict(name='test_requested_helper_closure_refuses_every_missing_helper_and_one_extra', expected_parent='missing new importer constants; error before refusal variants', coverage='Each of3missinghelpers and extra compareArray helper refused; no output.')],
    loader_groups=[
        dict(name='test_actual_loader_admits_exact_12_ordinary_identities_and_helper_bytes', expected_parent='missing profile KeyError', coverage='Real load_corpus result binds all11files and12fingerprints; no policy, no fixtures, exact ordered helper bytes.'),
        dict(name='test_auxiliary_authentication_refuses_self_consistent_edits_omissions_and_extras', expected_parent='missing profile KeyError; not accepted as intended ValueError', coverage='All5auxiliary edit+rehash/delete+unlist; listed extras; rewritten auxiliary authority remains root-bound.'),
        dict(name='test_sources_and_all_proofs_remain_bound_after_manifest_rewrites', expected_parent='missing profile KeyError; not accepted as intended ValueError', coverage='All7proof hashes rehashed, source edit/deletion+recount/table patch, unlisted source, missing/extra proof, illegal proof alias; complete directory cannot be narrowed by altered counts.')],
    predicted_parent=dict(groups=9, passes=1, error_groups=8, qualification='Group-level source prediction after exact corpus/oracle/test import; subtest error count not predicted. Existing APIs only at module import; no production read or execution.'),
    dependency_boundaries='Importer and loader tests use existing public functions; runner profile/gate implementations owned separately. No engine or network. Parent absence never satisfies a ValueError refusal assertion.',
    selected_production_api=dict(directory_constant='PROMISE_WITH_RESOLVERS_DIRECTORIES', helper_constant='PROMISE_WITH_RESOLVERS_HELPERS', profile=PROFILE),
    source_bindings=[bind(C/'root/selection-1.json'),bind(C/'source-parent.json'),bind(R/'source-ready.json'),bind(R/'corpus-census.json'),bind(O/'before/tools/import_test262.py'),bind(O/'parent/tools/test262_conformance.py')])
contract_path = jsave(O / 'test-contract.json', contract)
proof_path = jsave(O / 'authentication.json', dict(base=BASE, tree_hashes=tree_hashes,
    ancestor_chain=chain, leaf_sources=6, auxiliary_blobs=auxiliary,
    blob_count=11, proofs=7, full_package_files=19, all_files=all_files,
    parent_importer_git_exact=True, parent_runner_git_exact=True,
    readiness_tooling_bytes_unchanged=True, no_project_execution=True))
ready = jsave(O/'oracle-ready.json', dict(status='frozen source-derived oracle/package/test contract before production payload',
    base=BASE, oracle=bind(oracle_path), test_contract=bind(contract_path),
    authentication=bind(proof_path), fetch_url_map=bind(urls_path), author=bind(Path(__file__)),
    corpus_files=all_files, no_project_execution=True))
print(json.dumps(bind(ready)))
print(json.dumps(bind(oracle_path)))
print('package_bytes',oracle['total_package_bytes'])
