"""Author the selected importer payload using exact inverses; no project execution."""
import ast
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
W, O = C / 'worktree', C / 'importer-1'
BASE = 'dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def save(relative, data):
    path = O / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data.encode() if isinstance(data, str) else data)
    return path


def jsave(relative, value):
    return save(relative, json.dumps(value, indent=2) + '\n')


assert sha((O / 'oracle-ready.json').read_bytes()) == '2c73353f2b5214618e605b20fcb3b3e60f1479c6ff04cf702a65a8e08fbbce7f'
assert sha((O / 'tests-ready.json').read_bytes()) == 'ceb81f0216e522ba228b1f7a923e0a6d7b4a9f8ab116ca9a5e32132c7a2e58a6'
parent = (O / 'before/tools/import_test262.py').read_bytes()
assert parent == subprocess.check_output(['git', 'show', BASE + ':tools/import_test262.py'], cwd=W)
assert (W / 'tools/import_test262.py').read_bytes() == parent
text = parent.decode()
contract = json.loads((O / 'test-contract.json').read_bytes())
edits = []


def edit(label, old, new):
    global text
    assert text.count(old) == 1, label
    text = text.replace(old, new, 1)
    edits.append(dict(label=label, before=old, after=new))


edit('selected constants', 'PROMISE_ANY_DIRECTORIES =',
     "PROMISE_WITH_RESOLVERS_DIRECTORIES = {'Promise/withResolvers': 6}\n"
     "PROMISE_WITH_RESOLVERS_HELPERS = {'assert.js', 'sta.js', 'propertyHelper.js'}\n"
     'PROMISE_ANY_DIRECTORIES =')
edit('tree profile membership', "TREE_PROFILES = {'promise-any'", "TREE_PROFILES = {'promise-with-resolvers', 'promise-any'")
edit('profile selection', "PROFILES = {'promise-any':", "PROFILES = {'promise-with-resolvers': PROMISE_WITH_RESOLVERS_DIRECTORIES, 'promise-any':")
edit('profile source root', "PROFILE_ROOTS = {'promise-any':", "PROFILE_ROOTS = {'promise-with-resolvers': 'test/built-ins', 'promise-any':")
branch = '''    if profile == 'promise-with-resolvers':
        expected = {'Promise/withResolvers': 6}
        if (PROMISE_WITH_RESOLVERS_DIRECTORIES != expected or PROFILES[profile] != expected
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.withResolvers frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            expected, 'test/built-ins', read, auxiliary_helpers=PROMISE_WITH_RESOLVERS_HELPERS)
        if any(len(listings[name]) != count for name, count in expected.items()):
            raise ValueError('Promise.withResolvers complete directory counts differ')
        # Keep the complete authenticated leaf; no descendant may be omitted.
        sha = description['directory_trees']['Promise/withResolvers']
        tree = json.loads(proof[tree_proof_path('trees/' + sha)])
        if any(entry['type'] == 'tree' for entry in tree['tree']):
            raise ValueError('Promise.withResolvers incomplete descendant selection')
        return listings, proof, description
'''
edit('authenticated selected inventory', 'def profile_tree_inventory(profile, read=None):\n',
     'def profile_tree_inventory(profile, read=None):\n' + branch)
anchor = "    if profile == 'promise-any' and harness != PROMISE_ANY_HELPERS:\n"
edit('requested helper closure', anchor,
     "    if profile == 'promise-with-resolvers' and harness != PROMISE_WITH_RESOLVERS_HELPERS:\n"
     "        raise ValueError('Promise.withResolvers requested harness differs from the frozen three helpers')\n" + anchor)
anchor = "    if profile in {'promise-any', 'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'"
edit('authenticated auxiliary bytes', anchor,
     anchor.replace("{'promise-any'", "{'promise-with-resolvers', 'promise-any'"))
edit('manifest scope', '    scope = {\n',
     '    scope = {\n' + "        'promise-with-resolvers': " + repr(contract['scope_literal']) + ',\n')
restored = text
for row in reversed(edits):
    assert restored.count(row['after']) == 1, row['label']
    restored = restored.replace(row['after'], row['before'], 1)
assert restored.encode() == parent
before_ast, after_ast = ast.parse(parent.decode()), ast.parse(text)
before_funcs = {n.name: ast.get_source_segment(parent.decode(), n) for n in before_ast.body if isinstance(n, ast.FunctionDef)}
after_funcs = {n.name: ast.get_source_segment(text, n) for n in after_ast.body if isinstance(n, ast.FunctionDef)}
assert before_funcs.keys() == after_funcs.keys()
changed = [n for n in before_funcs if before_funcs[n] != after_funcs[n]]
assert changed == ['profile_tree_inventory', 'import_corpus']
assert len(edits) == 8
raw = save('raw/tools/import_test262.py', text)
diff = save('diffs/tools/import_test262.py.patch', ''.join(difflib.unified_diff(
    parent.decode().splitlines(True), text.splitlines(True), fromfile='a/tools/import_test262.py', tofile='b/tools/import_test262.py')))
edit_path = jsave('production-edits.json', edits)
checks = jsave('production-checks.json', dict(status='source checks pass; no execution',
    base=BASE, edits=8, changed_functions=changed,
    preserved_function_hashes={n:sha(s.encode()) for n,s in before_funcs.items() if n not in changed},
    no_new_functions=True, exact_inverse=True, published_parent_exact=True,
    old_bodies='Every old branch/helper survives byte-exact under the eight explicit inverses; no old profile table entry or scope literal changes.',
    oracle_sealed_before_production=bind(O/'oracle-ready.json'),
    tests_sealed_before_production=bind(O/'tests-ready.json'),
    source_only=True))
ast.parse((O/'replay-import.py').read_text())
recipe = jsave('execution-recipe.json', dict(status='root-only recipe, not run by author',
    command=['python3',str(O/'replay-import.py'),'--worktree',str(W),
             '--output',str(C/'offline-import-1/corpus'),'--receipt',str(C/'root/offline-import-1.json')],
    preconditions='Root imports the reviewed importer payload first; output and receipt must not exist. Only retained URLs are admitted, no network fallback.',
    expected=dict(unique_requests=18, files=19, bytes=101418, exact_package_bytes=True),
    guards='The recipe compares Counter(urls.keys()), not Counter(the URL mapping). Every produced byte and filename must match the frozen independent oracle.',
    recipe=bind(O/'replay-import.py')))
files=[dict(relative_path='tools/import_test262.py', role='production', before=bind(O/'before/tools/import_test262.py'),
            raw=bind(raw), diff=bind(diff), inverse_exact=True)]
test_ready=json.loads((O/'tests-ready.json').read_bytes())
files.extend(dict(relative_path=row['relative_path'],role='test-oracle' if row['relative_path'].endswith('.json') else 'test',
                  before=None,raw=row['raw']) for row in test_ready['files'])
oracle=json.loads((O/'raw/tools/test262-promise-with-resolvers-import-oracle.json').read_bytes())
corpus=[dict(relative_path='tests/upstream/test262-promise-with-resolvers/'+row['path'],raw=bind(O/'corpus'/row['path'])) for row in oracle['all_files']]
ready=jsave('source-ready.json',dict(status='sealed importer-only production, independently frozen tests/oracle and exact authenticated corpus; unexecuted',
    base=BASE, files=files, corpus=corpus, scope=dict(production_files=1, test_modules=2, test_groups=9,
    oracle_files=1, corpus_files=19, originals=6, ordinary_modes=12, helpers=3, legal=2, proofs=7),
    oracle_ready=bind(O/'oracle-ready.json'), tests_ready=bind(O/'tests-ready.json'),
    production_edits=bind(edit_path), production_checks=bind(checks),
    execution_recipe=bind(recipe), recipe=bind(O/'replay-import.py'),
    author=bind(Path(__file__)), root_selection=bind(C/'root/selection-1.json'),
    source_parent=bind(C/'source-parent.json'),
    constraints='No network fetch, project imports/execution, live edits, Rust changes or new execution policy. Root alone imports/runs the held recipe and tests. Existing59 profiles/old corpus bytes preserved.'))
print(json.dumps(bind(ready)))
print(json.dumps(bind(raw)))
