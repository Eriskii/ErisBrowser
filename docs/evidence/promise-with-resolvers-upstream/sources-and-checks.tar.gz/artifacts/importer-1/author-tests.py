"""Write independent test payloads from the frozen oracle; do not run them."""
import ast
import hashlib
import json
from pathlib import Path

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
W, O = C / 'worktree', C / 'importer-1'
ORACLE_SHA = '5b88482eae075e32cf5f0dd4221eb68c14555a7937cc1d964928055ce34b3d56'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))


def replace_method(source, name, replacement):
    node = next(n for n in ast.walk(ast.parse(source)) if isinstance(n, ast.FunctionDef) and n.name == name)
    lines = source.splitlines(True)
    return ''.join(lines[:node.lineno - 1]) + replacement.rstrip() + '\n' + ''.join(lines[node.end_lineno:])


oracle_path = O / 'raw/tools/test262-promise-with-resolvers-import-oracle.json'
assert sha(oracle_path.read_bytes()) == ORACLE_SHA
source = (W / 'tools/test_import_test262_promise_any.py').read_text()
for before, after in [
    ('Promise.any', 'Promise.withResolvers'), ('PromiseAny', 'PromiseWithResolvers'),
    ('promise-any', 'promise-with-resolvers'), ('Promise/any', 'Promise/withResolvers'),
    ('PROMISE_ANY', 'PROMISE_WITH_RESOLVERS'), ('ANY_TREE', 'WITH_RESOLVERS_TREE'),
    ("'e2352be158fb0c0625d1ab642330faabc62a2df8'", "'062393e615d0cf97a0252e6a93923bd91444a455'"),
    ("'d8907cbf2a1992e023da96d5b304e09637b82d5f4f0d77b6ccd2ab873f6119b8'", repr(ORACLE_SHA)),
]:
    source = source.replace(before, after)
source = source.replace('import contextlib\n', 'import contextlib\nfrom collections import Counter\n')
source = source.replace("DIRECTORIES = {'Promise/withResolvers': 94}", "DIRECTORIES = {'Promise/withResolvers': 6}")
source = source.replace("HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js', 'isConstructor.js',\n           'promiseHelper.js', 'propertyHelper.js'}", "HELPERS = {'assert.js', 'sta.js', 'propertyHelper.js'}")
source = source.replace('test_complete_110_file_', 'test_complete_19_file_')
source = source.replace('(94, 102, 7)', '(6, 11, 7)').replace('(110, 266666)', '(19, 101418)')
source = source.replace("side_effect=self.cached_fetch), contextlib.redirect_stdout", "side_effect=self.cached_fetch) as fetch, contextlib.redirect_stdout")
source = source.replace("            importer.import_corpus(output, PROFILE)\n            self.assertEqual", "            importer.import_corpus(output, PROFILE)\n            expected_urls = {r['url'] for r in self.manifest['inventory_proof']['files']}\n            expected_urls.update(f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/' + r['path']\n                                 for r in self.manifest['files'])\n            self.assertEqual(len(expected_urls), 18)\n            self.assertEqual(Counter(call.args[0] for call in fetch.call_args_list), Counter(expected_urls))\n            self.assertEqual", 1)
source = replace_method(source, 'test_all_188_metadata_identities_retain_modes_features_and_helper_order', '''    def test_all_12_metadata_identities_retain_modes_features_and_helper_order(self):
        helpers, identities = {'assert.js', 'sta.js'}, []
        source_bytes, features, includes = 0, {}, {}
        for path, expected in self.oracle['metadata'].items():
            data = (CORPUS / path).read_bytes()
            metadata = importer.parse_metadata(data.decode('utf-8'))
            self.assertEqual(metadata, expected, path)
            self.assertEqual(metadata['flags'], [])
            self.assertEqual(metadata['locale'], [])
            self.assertIsNone(metadata['negative'])
            self.assertNotIn('timeout', metadata)
            source_bytes += len(data)
            helpers.update(metadata['includes'])
            names = ['assert.js', 'sta.js'] + metadata['includes']
            harness = [dict(name=name, sha256=digest((CORPUS / 'harness' / name).read_bytes()))
                       for name in names]
            for mode in ('sloppy', 'strict'):
                identity = dict(source_sha256=digest(data), mode=mode, metadata=metadata,
                                harness=harness)
                self.assertNotIn('completion_policy', identity)
                identities.append(dict(id=path + ':' + mode,
                    case_sha256=digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())))
            for feature in metadata['features']:
                features[feature] = features.get(feature, 0) + 1
            for name in metadata['includes']:
                includes[name] = includes.get(name, 0) + 1
        self.assertEqual((len(self.oracle['metadata']), source_bytes), (6, 3708))
        self.assertEqual(helpers, HELPERS)
        self.assertEqual(identities, self.oracle['case_identities'])
        self.assertEqual(len({r['id'] for r in identities}), 12)
        self.assertEqual(features, {'promise-with-resolvers': 6, 'class': 1})
        self.assertEqual(includes, {'propertyHelper.js': 1})
''')
source = source.replace('all_58_old_profile', 'all_59_old_profile').replace("self.oracle['old_profile_count'], 58", "self.oracle['old_profile_count'], 59")
source = source.replace("{'Promise/withResolvers': 93}, {'Promise/withResolvers': 95}", "{'Promise/withResolvers': 5}, {'Promise/withResolvers': 7}")
source = source.replace("{'Promise/race': 94}, {'Promise/withResolvers': 94, 'Promise/withResolvers/child': 1}", "{'Promise/resolve': 6}, {'Promise/withResolvers': 6, 'Promise/withResolvers/child': 1}")
source = source.replace("{'Promise/withResolvers': 93}", "{'Promise/withResolvers': 5}")
source = source.replace('(102, 94, 6)', '(11, 6, 3)')
source = source.replace('test/built-ins/Promise/withResolvers/name.js', 'test/built-ins/Promise/withResolvers/result.js')
source = source.replace('pinned Any tree', 'pinned withResolvers tree')

loader = (W / 'tools/test_test262_promise_any_loader.py').read_text()
for before, after in [
    ('Any loader', 'withResolvers loader'), ('PromiseAny', 'PromiseWithResolvers'),
    ('promise-any', 'promise-with-resolvers'), ('Promise/any', 'Promise/withResolvers'),
    ("'d8907cbf2a1992e023da96d5b304e09637b82d5f4f0d77b6ccd2ab873f6119b8'", repr(ORACLE_SHA)),
    ('test_any_auxiliary_authentication', 'test_auxiliary_authentication'),
    ('test_any_sources_and_all_proofs', 'test_sources_and_all_proofs'),
    ("len(auxiliary), 8", "len(auxiliary), 5"),
    ("'harness/promiseHelper.js'", "'harness/propertyHelper.js'"),
    ('test/built-ins/Promise/withResolvers/name.js', 'test/built-ins/Promise/withResolvers/result.js'),
    ("remove('name.js')", "remove('result.js')"),
]:
    loader = loader.replace(before, after)
loader = replace_method(loader, 'test_actual_loader_admits_exact_188_identities_policies_and_helper_bytes', '''    def test_actual_loader_admits_exact_12_ordinary_identities_and_helper_bytes(self):
        manifest, files, cases, fixtures, manifest_sha = runner.load_corpus(CORPUS, PROFILE)
        self.assertEqual(manifest, self.manifest)
        self.assertEqual(manifest_sha, self.oracle['manifest_sha256'])
        self.assertEqual(fixtures, [])
        self.assertEqual(set(files), {row['path'] for row in self.manifest['files']})
        self.assertEqual(len(files), 11)
        for row in self.manifest['files']:
            self.assertEqual((len(files[row['path']]), digest(files[row['path']])),
                             (row['bytes'], row['sha256']), row['path'])
        self.assertEqual([dict(id=c['id'], case_sha256=c['case_sha256']) for c in cases],
                         self.oracle['case_identities'])
        self.assertEqual(len(cases), 12)
        for case in cases:
            meta = self.oracle['metadata'][case['file']]
            self.assertEqual(case['metadata'], meta)
            self.assertEqual(case['source'], files[case['file']])
            self.assertNotIn('completion_policy', case)
            self.assertEqual(case['harness'], [(name, files['harness/' + name]) for name in
                ['assert.js', 'sta.js'] + meta['includes']])
            self.assertIn(case['mode'], ('sloppy', 'strict'))
        self.assertEqual({c['file'] for c in cases}, set(self.oracle['metadata']))
''')
loader = loader.replace("'unlisted-source', 'delete-proof-and-unlist', 'extra-proof'):", "'delete-source-and-patch-count', 'unlisted-source', 'delete-proof-and-unlist',\n                          'extra-proof', 'proof-symlink'):")
loader = loader.replace("elif operation == 'delete-source-and-recount':", "elif operation in ('delete-source-and-recount', 'delete-source-and-patch-count'):")
loader = loader.replace("                else:\n                    path = 'inventory-proof/tree-'", "                elif operation == 'proof-symlink':\n                    proof = manifest['inventory_proof']['files'][0]\n                    target = directory / proof['path']\n                    saved = Path(temporary) / 'aliased-proof.json'\n                    saved.write_bytes(target.read_bytes())\n                    target.unlink()\n                    target.symlink_to(saved)\n                else:\n                    path = 'inventory-proof/tree-'")
old = """                write_manifest(directory, manifest)
                with self.assertRaises(ValueError):
                    runner.load_corpus(directory, PROFILE)


if __name__"""
new = """                write_manifest(directory, manifest)
                if operation == 'delete-source-and-patch-count':
                    narrowed = {'Promise/withResolvers': 5}
                    with patch.dict(importer.PROFILES, {PROFILE: narrowed}), \\
                            patch.dict(runner.PROFILES, {PROFILE: narrowed}), \\
                            patch.object(importer, 'PROMISE_WITH_RESOLVERS_DIRECTORIES', narrowed), \\
                            self.assertRaises(ValueError):
                        runner.load_corpus(directory, PROFILE)
                else:
                    with self.assertRaises(ValueError):
                        runner.load_corpus(directory, PROFILE)


if __name__"""
assert loader.count(old) == 1
loader = loader.replace(old, new)

files = []
for relative, content, expected_count in [
    ('tools/test_import_test262_promise_with_resolvers.py', source, 6),
    ('tools/test_test262_promise_with_resolvers_loader.py', loader, 3),
]:
    tree = ast.parse(content)
    names = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
    assert len(names) == expected_count
    assert not (W / relative).exists()
    for stale in ('PromiseAny', 'promise-any', 'ANY_TREE', '188', '94, 102', '266666'):
        assert stale not in content, (relative, stale)
    path = O / 'raw' / relative
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    files.append(dict(relative_path=relative, raw=bind(path), test_names=names,
                      groups=expected_count, new_file=True))
files.append(dict(relative_path='tools/test262-promise-with-resolvers-import-oracle.json',
                  raw=bind(oracle_path), new_file=True))
contract = json.loads((O / 'test-contract.json').read_bytes())
assert [n for row in files[:2] for n in row['test_names']] == [row['name'] for row in contract['importer_groups'] + contract['loader_groups']]
ready = O / 'tests-ready.json'
ready.write_text(json.dumps(dict(status='frozen nine test groups before importer production; unexecuted',
    base=contract['base'], oracle_ready=bind(O / 'oracle-ready.json'),
    test_contract=bind(O / 'test-contract.json'), files=files,
    predicted_parent=contract['predicted_parent'], author=bind(Path(__file__)),
    qualification='Existing module imports only; missing new constants/profile are accessed inside test bodies. AST parse is not execution.'), indent=2) + '\n')
print(json.dumps(bind(ready)))
