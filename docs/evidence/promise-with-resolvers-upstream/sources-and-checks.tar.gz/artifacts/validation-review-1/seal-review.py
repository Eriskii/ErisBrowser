"""Bind independent evidence checks to the final ledger; stdlib inspection only."""
from pathlib import Path
import hashlib
import json

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
W = C/'worktree'
O = Path(__file__).parent

def binding(p):
    p=Path(p); b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def read(p): return json.loads(Path(p).read_bytes())

ledger_path=C/'root/final-validation.json'
assert binding(ledger_path)['sha256']=='bc92cafb38f970f500627aed12504b6dcd9f9d91cafee04d9600ab5840d57bef'
ledger=read(ledger_path)
checks=read(O/'evidence-checks-1.json')
refs=[]
def verify_refs(x):
    if isinstance(x,dict):
        if {'path','bytes','sha256'} <= x.keys():
            assert binding(x['path']) == {k:x[k] for k in ['path','bytes','sha256']}, x['path']
            refs.append({k:x[k] for k in ['path','bytes','sha256']})
        for y in x.values(): verify_refs(y)
    elif isinstance(x,list):
        for y in x: verify_refs(y)
verify_refs(ledger)
for item in checks['bindings']:
    assert binding(item['path'])==item,item['path']
assert ledger['base']=='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'
assert ledger['python']['parent']==624 and ledger['python']['candidate']==652 and ledger['python']['new']==28
assert ledger['python']['exact_roster_union'] is True
for declared,key in zip(ledger['python']['parent_new_group_observations'],['selected_parent','controls_parent']):
    actual=checks['python'][key]
    assert declared['groups']==actual['groups'] and declared['passed_groups']==actual['passed_groups']
    assert declared['nonpassing_groups']==actual['groups_with_error_or_failure']
assert ledger['selected']['counts']==checks['selected_profile']['counts']
assert ledger['selected']['cases']==12 and ledger['selected']['controls']==44
assert ledger['selected']['all_three_arrays_identical'] is True
assert ledger['legacy']['cases']==1288 and ledger['legacy']['controls']==502
for declared,actual in zip(ledger['legacy']['profiles'],checks['legacy']):
    assert declared['name']==actual['profile'] and declared['counts']==actual['counts']
    assert declared['cases']==actual['case_records'] and declared['controls']==actual['control_records']
assert len(ledger['execution_receipts'])==15
for entry in ledger['execution_receipts']:
    raw=read(entry['receipt']['path'])
    assert raw['exit']==entry['exit'] and raw['command']==entry['command']
    assert raw['sha256']==entry['log']['sha256']

# Confirm the actual final composition against all immutable selected raw payloads.
parent=read(C/'source-parent.json')['source_sha256']
final=read(C/'source-final.json')['source_sha256']
expected_paths=set()
raw_joins=[]
for entry in ledger['payload_seals']:
    hold=read(entry['path'])
    files=hold.get('files',[])
    if 'module' in hold:
        p=Path(hold['module']['path'])
        files=[{'relative_path':'tools/'+p.name,'raw':hold['module']}]
    for row in files:
        rel=row.get('relative_path',row.get('relative',row.get('path')))
        raw=row['raw']
        assert binding(raw['path'])==raw
        assert (W/rel).read_bytes()==Path(raw['path']).read_bytes(),rel
        if row.get('before') is not None:
            # A few historical holds point before.path at the then-live worktree;
            # bind their frozen hash to the preserved parent map, not mutable bytes.
            assert row['before']['sha256']==parent[rel]
        expected_paths.add(rel)
        raw_joins.append({'path':rel,'sha256':raw['sha256']})
package=C/'importer-1/corpus'
for p in package.rglob('*'):
    if p.is_file(): expected_paths.add('tests/upstream/test262-promise-with-resolvers/'+str(p.relative_to(package)))
expected_paths.add('tests/conformance/test262-promise-with-resolvers-current.json')
actual_paths={p for p,h in final.items() if parent.get(p)!=h}
assert expected_paths==actual_paths and len(actual_paths)==51
assert ledger['scope']==dict(source_paths=51,production_files=2,new_test_modules=5,new_test_groups=28,
    new_oracles=3,historical_test_paths=20,historical_test_groups=270,historical_selection_edits=35,
    ci_commands_added=1,corpus_files=19,baseline_files=1)
assert ledger['source']['selected_inputs']==1775
assert ledger['corrections']['candidate_production']==ledger['corrections']['candidate_tests']==ledger['corrections']['candidate_controls']==0

prior=read(ledger['prior_ci']['receipt']['path'])
assert prior['headSha']==ledger['base']==ledger['prior_ci']['sha']
assert prior['status']=='completed' and prior['conclusion']=='success'
assert len(prior['jobs'])==11 and all(j['status']=='completed' and j['conclusion']=='success' for j in prior['jobs'])
assert prior['url']==ledger['prior_ci']['url']
whitespace=read(C/'root/new-file-whitespace.json')
expected_whitespace={
    'tests/upstream/test262-promise-with-resolvers/LICENSE',
    'tests/upstream/test262-promise-with-resolvers/test/built-ins/Promise/withResolvers/ctx-ctor.js',
    'tests/upstream/test262-promise-with-resolvers/test/built-ins/Promise/withResolvers/ctx-non-object.js',
    'tests/upstream/test262-promise-with-resolvers/test/built-ins/Promise/withResolvers/promise.js'}
assert {i['path'] for i in whitespace['issues']}==expected_whitespace
for rel in expected_whitespace:
    local=rel.removeprefix('tests/upstream/test262-promise-with-resolvers/')
    assert (W/rel).read_bytes()==(package/local).read_bytes()

review={
 'status':'clear',
 'findings':[],
 'scope':'Independent retained-evidence audit using stdlib byte/hash/AST/log/JSON inspection only. No project modules imported, project tests run, live files edited, binary rebuilt or network fetched by this reviewer.',
 'final_ledger':binding(ledger_path),
 'independent_checks':binding(O/'evidence-checks-1.json'),
 'audit_source':binding(O/'audit-evidence.py'),
 'seal_source':binding(__file__),
 'checked':{
   'python':'Parent 624 distinct successful groups; candidate 652 exactly equals that roster plus the 28 frozen new groups. Focused candidate 28/28. No removed or renamed parent tests.',
   'parent':'Selected parent run: 19 groups, 7 pass, 12 nonpass, with 21 failure and 34 error detail rows. Separate controls run: 9 groups, 0 pass, with 254 error detail rows. Duplicate verbose summary lines deduplicated by exact test ID; subtests are not counted as groups.',
   'selected':'All 6 originals retained as 12 modes: observed 10 passed and 2 class metadata exclusions, both ctx-ctor.js. All 44 canonical controls and prerequisites match the held oracle; six raw string fields are bounded, and only the permitted diagnostic message differs from synthetic oracle values.',
   'baseline':'Initial no-baseline exit 1 is retained. Baseline record and check each exit 0. All three complete 12-case and 44-control arrays are exact; baseline equals the compact five-key report projection.',
   'legacy':'All six prior complete arrays are unchanged: 1,288 case records and 502 control records, including existing failures/unsupported outcomes. Policies, corpus IDs and binary identities also match; no legacy baseline reset, regression or improvement.',
   'source':'All 1,775 selected final hashes checked. Exact 51-path composition joins selected raw holds; candidate-to-final only adds the new baseline. Inherited 1,747-input map matches BH. This is a selected inventory, not a complete compile graph claim.',
   'binaries':'Reused BH ordinary 4,440,792-byte ffab8978… and host 4,485,848-byte b609efbe… binaries rehashed, with successful BH build receipt/log and unchanged source inventory binding. No new Rust build or test execution claimed.',
   'import':'Offline retained-response replay has 18 requests and all 19 exact package files, joining the held corpus, offline output and live candidate bytes.',
   'receipts':'All 15 execution receipt/log pairs and every direct final-ledger byte/hash reference independently checked.',
   'ci':'The retained 11-job success belongs only to published BH base dbbb86c0. It is not a current-checkpoint CI success claim.'
 },
 'retained_corrections':{
   'first_wrapper':'Initial orchestration expected exit 0 but the valid unbaselined report returned 1 for retained class exclusions.',
   'baseline_wrapper':'A later orchestration assertion compared compact baseline bytes with a full report after successful record/check commands. The verified comparison is the exact compact projection; no engine rerun or candidate expectation correction.',
   'parent_parser':'Initial root census counted repeated verbose group summary lines; exact-ID deduplication restores the 19+9 group roster.',
   'review_helper':'The first independent audit attempt assumed compact JSON policy hashing and stopped before producing checks; source confirms existing json.dumps default separators. Only the external audit helper was corrected; no project or evidence bytes changed.'
 },
 'supplemental_whitespace':{
   'receipt':binding(C/'root/new-file-whitespace.json'),
   'paths':sorted(expected_whitespace),
   'qualification':'These four pinned originals retain authenticated pre-existing whitespace. The reviewer checked exact original bytes; no whitespace normalization or blanket authored-file exception is endorsed.'
 },
 'raw_joins':raw_joins,
 'direct_ledger_reference_count':len(refs),
 'limits':['No full Test262/ECMAScript conformance claim; class remains excluded.',
           'Ordinary ERJS1/ERJR2 profile, existing seven intrinsic error identities; no host/async expansion.',
           'No new security, performance, hardware, Rust-suite or current remote-CI result claim.']
}
target=O/'final-review.json'
assert not target.exists()
target.write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(binding(target)))
