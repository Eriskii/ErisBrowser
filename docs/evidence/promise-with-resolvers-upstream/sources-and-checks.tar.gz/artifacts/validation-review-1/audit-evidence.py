"""Independent stdlib-only inspection of retained evidence; executes no project code."""
from pathlib import Path
import ast
from collections import Counter
import copy
import hashlib
import json
import re

C = Path('/tmp/eris-promise-with-resolvers-upstream-plan-1')
B = Path('/tmp/eris-promise-with-resolvers-runtime-plan-1')
W = C / 'worktree'
OUT = Path(__file__).parent
bindings = {}

def bind(path):
    path = Path(path)
    data = path.read_bytes()
    item = {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
    bindings[str(path)] = item
    return item

def read(path):
    bind(path)
    return json.loads(Path(path).read_bytes())

def sha(path):
    return bind(path)['sha256']

def receipt(label, expected_exit):
    r = read(C / 'validation' / (label + '.json'))
    log = C / 'validation' / r['log']
    assert sha(log) == r['sha256'], label
    assert r['exit'] == expected_exit, label
    return r, log.read_text()

def python_rows(label, count, success):
    r, text = receipt(label, 0 if success else 1)
    rows = re.findall(r'^(test\w+) \(([^)]+)\) \.\.\. *([^\n]*)$', text, re.M)
    observed = {full for _, full, _ in rows}
    assert len(observed) == count
    assert re.findall(r'^Ran (\d+) tests in [^\n]+$', text, re.M) == [str(count)]
    if success:
        assert len(rows) == count and all(status == 'ok' for _, _, status in rows)
        assert re.findall(r'^OK$', text, re.M) == ['OK']
    headers = re.findall(r'^(ERROR|FAIL): (test\w+) \(([^)]+)\)', text, re.M)
    bad = {full for _, _, full in headers}
    assert bad <= observed
    return {'groups': count, 'passed_groups': count-len(bad),
            'groups_with_error_or_failure': len(bad),
            'error_rows': sum(k == 'ERROR' for k, _, _ in headers),
            'failure_rows': sum(k == 'FAIL' for k, _, _ in headers),
            'roster': sorted(observed), 'bad_groups': sorted(bad),
            'receipt': bindings[str(C/'validation'/(label+'.json'))]}

new = []
modules = []
for rel in [
    'importer-1/raw/tools/test_import_test262_promise_with_resolvers.py',
    'importer-1/raw/tools/test_test262_promise_with_resolvers_loader.py',
    'protocol-1/raw/tools/test_test262_with_resolvers_protocol.py',
    'preservation-1/raw/tools/test_test262_with_resolvers_preservation.py',
    'controls-1/raw/tools/test_test262_with_resolvers_controls.py',
]:
    p = C/rel
    bind(p)
    assert p.read_bytes() == (W/'tools'/p.name).read_bytes()
    groups = []
    for cls in ast.parse(p.read_text()).body:
        if isinstance(cls, ast.ClassDef):
            groups += [f'{p.stem}.{cls.name}.{fn.name}' for fn in cls.body
                       if isinstance(fn, ast.FunctionDef) and fn.name.startswith('test_')]
    modules.append({'path': rel, 'groups': len(groups), 'roster': groups})
    new += groups
assert len(new) == len(set(new)) == 28
parent = python_rows('python-parent-1', 624, True)
candidate = python_rows('python-full-1', 652, True)
focused = python_rows('selected-candidate-1', 28, True)
red = python_rows('selected-parent-1', 19, False)
red_controls = python_rows('controls-parent-1', 9, False)
assert set(candidate['roster']) == set(parent['roster']) | set(new)
assert not set(parent['roster']) & set(new)
assert set(focused['roster']) == set(new)
assert set(red['roster']) | set(red_controls['roster']) == set(new)
assert not set(red['roster']) & set(red_controls['roster'])
assert (red['passed_groups'], red['groups_with_error_or_failure'], red['error_rows'], red['failure_rows']) == (7,12,34,21)
assert (red_controls['passed_groups'], red_controls['groups_with_error_or_failure'], red_controls['error_rows']) == (0,9,254)
for label in ['python-parent-1', 'selected-parent-1', 'controls-parent-1']:
    for suffix in ['.json', '.log']:
        src = C/'validation'/(label+suffix)
        dest = OUT/'retained-parent'/(label+suffix)
        dest.parent.mkdir(parents=True, exist_ok=True)
        if dest.exists(): assert dest.read_bytes() == src.read_bytes()
        else: dest.write_bytes(src.read_bytes())
        bind(dest)

parent_source = read(C/'source-parent.json')['source_sha256']
bh_source = read(B/'source-final.json')['source_sha256']
candidate_source = read(C/'source-candidate-1.json')['source_sha256']
final_source = read(C/'source-final.json')['source_sha256']
assert parent_source == bh_source
assert not set(parent_source) - set(candidate_source)
assert not set(candidate_source) - set(final_source)
assert all(final_source[p] == h for p, h in candidate_source.items())
baseline_path = 'tests/conformance/test262-promise-with-resolvers-current.json'
assert set(final_source) - set(candidate_source) == {baseline_path}
assert all(sha(W/p) == h for p, h in final_source.items())
changed = [p for p, h in parent_source.items() if final_source[p] != h]
assert len(parent_source) == 1747 and len(final_source) == 1775
assert len(changed) == 23 and len(set(final_source)-set(parent_source)) == 28
assert not any(p.endswith('.rs') or Path(p).name.startswith('Cargo.') for p in changed)
reuse = read(C/'root/binary-reuse-1.json')
binaries = {}
for kind in ['ordinary', 'host']:
    meta = read(B/f'eris-js-{kind}-1.json')
    binary = bind(Path(meta['binary']))
    assert binary['sha256'] == meta['sha256'] and binary['bytes'] == meta['bytes']
    assert sha(Path(meta['source_inventory'])) == meta['source_sha256']
    assert read(Path(meta['source_inventory']))['source_sha256'] == bh_source
    build = read(Path(meta['build']))
    assert build['exit'] == 0
    buildlog = Path(meta['build']).parent/build['log']
    assert sha(buildlog) == build['sha256']
    assert meta in reuse['binaries']
    binaries[kind] = binary

oracle = read(C/'importer-1/raw/tools/test262-promise-with-resolvers-import-oracle.json')
offline = read(C/'root/offline-import-1.json')
receipt('offline-import-1', 0)
assert offline['files'] == 19 and offline['requests'] == 18 and offline['exact_bytes'] is True
assert offline['oracle_sha256'] == bindings[str(C/'importer-1/raw/tools/test262-promise-with-resolvers-import-oracle.json')]['sha256']
package = C/'importer-1/corpus'
live_package = W/'tests/upstream/test262-promise-with-resolvers'
expected_files = {str(p.relative_to(package)) for p in package.rglob('*') if p.is_file()}
assert len(expected_files) == 19
for location in [Path(offline['output']), live_package]:
    actual_files = {str(p.relative_to(location)) for p in location.rglob('*') if p.is_file()}
    assert actual_files == expected_files
    assert all((package/p).read_bytes() == (location/p).read_bytes() for p in expected_files)

control_oracle = read(C/'controls-1/raw/tools/test262-with-resolvers-controls-oracle.json')
reports = []
for label, ex in [('upstream-with-resolvers-1',1), ('upstream-with-resolvers-record-1',0), ('upstream-with-resolvers-check-1',0)]:
    receipt(label, ex)
    r = read(C/(label+'.json'))
    assert r['mode_cases'] == len(r['cases']) == 12 and len(r['harness_preflight']) == 44
    assert r['harness_preflight_passed'] is True
    assert r['binary_sha256'] == binaries['ordinary']['sha256']
    assert r['corpus_manifest_sha256'] == oracle['manifest_sha256']
    assert r['runner_policy']['supported_features'] == ['promise-with-resolvers']
    assert r['runner_policy']['negative_intrinsic_errors'] == ['Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError']
    assert r['runner_policy']['async_completion'] is False and r['runner_policy']['host_hooks'] is False
    # Existing runner policy hashing uses json.dumps' default separators.
    assert r['runner_policy_sha256'] == hashlib.sha256(json.dumps(r['runner_policy'],sort_keys=True).encode()).hexdigest()
    assert [{'id':x['id'],'case_sha256':x['case_sha256']} for x in r['cases']] == oracle['case_identities']
    for case in r['cases']:
        assert case['source_sha256'] == sha(package/case['file'])
        assert case['expected_negative'] is None
    assert dict(Counter(x['status'] for x in r['cases'])) == r['counts']
    assert not r['regressions'] and not r['improvements']
    observed = copy.deepcopy(r['harness_preflight'])
    for row in observed:
        raw = row['result']['observation']
        assert set(raw) == set(control_oracle['raw_contract']['fields'])
        assert all(type(v) is str and len(v.encode('utf-8')) <= 16384 for v in raw.values())
        raw['message'] = ''
    assert observed == control_oracle['healthy_outcomes']
    reports.append(r)
first = reports[0]
for r in reports[1:]:
    for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','counts','binary_sha256','corpus_manifest_sha256']:
        assert r[key] == first[key], key
assert first['counts'] == {'unsupported':2,'passed':10}
assert all(x['file'].endswith('/ctx-ctor.js') and x['reason']=='unimplemented declared features: class'
           for x in first['cases'] if x['status']=='unsupported')
baseline = read(W/baseline_path)
expected_baseline = {k:first[k] for k in ['revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256']}
expected_baseline['cases'] = {x['id']:{k:x[k] for k in ['status','case_sha256','source_sha256']} for x in first['cases']}
assert baseline == expected_baseline

legacy = []
for short in ['aggregate-error','existing','all','race','settled','any']:
    label = f'upstream-{short}-1'
    receipt(label,0)
    old = read(C/'replay-parent'/(label+'.json'))
    bh = read(B/(label+'.json'))
    current = read(C/(label+'.json'))
    assert old == bh
    for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','mode_cases','binary_sha256']:
        assert current[key] == old[key], (short,key)
    assert current['harness_preflight_passed'] is True
    assert all(row['verified'] is True for row in current['harness_preflight'])
    assert current['binary_sha256'] == binaries['ordinary' if short=='aggregate-error' else 'host']['sha256']
    assert not current['regressions'] and not current['improvements']
    legacy.append({'profile':short,'case_records':len(current['cases']),'control_records':len(current['harness_preflight']),
                   'counts':current['counts'],'complete_case_and_control_arrays_equal':True})
assert sum(x['case_records'] for x in legacy) == 1288
assert sum(x['control_records'] for x in legacy) == 502

result = {
    'status':'intermediate evidence checks clear; final root ledger not reviewed by this script',
    'scope':'stdlib-only byte/hash/AST/log/JSON inspection; no project import, engine execution, live edit, rebuild or Rust suite rerun',
    'python':{'parent':parent,'candidate':candidate,'focused':focused,'selected_parent':red,'controls_parent':red_controls,
              'new_modules':modules,'exact_old_roster_plus_new':True,
              'parent_qualification':'19 and 9 are test-group counts. The 34 errors/21 failures and 254 errors include subtests; duplicate verbose top-level lines are deduplicated by complete test ID.'},
    'source':{'parent_selected':1747,'candidate_selected':len(candidate_source),'final_selected':1775,'changed_old':23,'added_final':28,
              'all_parent_inputs_retained':True,'all_final_selected_hashes_match':True,'candidate_to_final_only_new_baseline':True,
              'selected_inventory_is_not_claimed_complete_repo_or_compile_closure':True},
    'binaries':binaries,
    'offline_import':{'files':19,'requests':18,'exact_held_offline_and_live_bytes':True},
    'selected_profile':{'cases':12,'controls':44,'counts':first['counts'],'canonical_controls_exact_except_bounded_diagnostic_message':True,
                        'first_record_check_full_arrays_exact':True,'baseline_exact_report_projection':True,
                        'first_exit':1,'record_exit':0,'check_exit':0,
                        'classification':'The two ctx-ctor.js modes are metadata-excluded for class, not engine failures. All six original files remain.'},
    'legacy':legacy,'legacy_case_records':1288,'legacy_control_records':502,
    'limitations':['No full Test262 conformance, new Rust run, remote CI result, security or performance claim.',
                   'Successful full Python run is 652 distinct groups, not subtest operations.',
                   'Initial orchestration and compact-baseline/full-report bookkeeping corrections are separately retained by root.'],
    'bindings':list(bindings.values())
}
dest=OUT/'evidence-checks-1.json'
if dest.exists(): assert json.loads(dest.read_bytes()) == result
else: dest.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'output':str(dest),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),
                  'python':652,'new_groups':28,'selected_cases':12,'controls':44,'legacy_cases':1288,'legacy_controls':502}))
