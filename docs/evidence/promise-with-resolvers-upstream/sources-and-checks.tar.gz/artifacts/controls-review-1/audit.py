"""Independent static source/data review. No project imports or execution."""
from pathlib import Path
import ast,hashlib,json,subprocess
C=Path(__file__).resolve().parent.parent;R=C/'controls-review-1';H=C/'controls-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def verify_bindings(x):
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():assert bind(x['path'])=={k:x[k] for k in ('path','bytes','sha256')},x['path']
  for v in x.values():verify_bindings(v)
 elif isinstance(x,list):
  for v in x:verify_bindings(v)
for name in ('source-ready.json','literals-ready.json','contract.json','source-bindings.json'):verify_bindings(json.loads((H/name).read_text()))
hold=json.loads((H/'source-ready.json').read_text());base=hold['base']
v=json.loads((H/'variants.json').read_text());o=json.loads((H/'raw/tools/test262-with-resolvers-controls-oracle.json').read_text());assert o['variants']==v and len(v)==44
old=json.loads((C/'ordinary-control-audit-1/common-control-identities.json').read_text())['records']
parent=(C/'readiness-1/parent/tools/test262_conformance.py').read_text()
assert subprocess.check_output(['git','show',base+':tools/test262_conformance.py'],cwd=C/'worktree')==parent.encode()
fn=next(n for n in ast.parse(parent).body if isinstance(n,ast.FunctionDef) and n.name=='aggregate_error_preflight_variants')
literals={n.targets[0].id:ast.literal_eval(n.value) for n in fn.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'common','strict_only'}}
expected_common=[]
for mode,prefix in [('sloppy',''),('strict','strict-')]:
 for name,source,expected,prior in literals['common']:
  expected_common.append((prefix+name,mode,source,expected,['propertyHelper.js'] if 'property-' in name else [],[[prefix+prior,mode]] if prior is not None else []))
for name,source in literals['strict_only']:expected_common.append((name,'strict',source,'passed',[],[]))
assert [(r['name'],r['mode'],r['source'],r['expected'],r['metadata']['includes'],r['prerequisites']) for r in v[:32]]==expected_common
helpers={}
for name,held in o['helpers'].items():
 data=held['source'].encode();assert len(data)==held['bytes'] and sha(data)==held['sha256'];assert data==(C/'readiness-1/auxiliary/harness'/name).read_bytes();helpers[name]=data
assert set(helpers)=={'assert.js','sta.js','propertyHelper.js'}
refs={};cases=[]
for i,row in enumerate(v):
 names=['assert.js','sta.js']+row['metadata']['includes'];harness=[{'name':n,'sha256':sha(helpers[n])} for n in names]
 identity={'source_sha256':sha(row['source'].encode()),'mode':row['mode'],'metadata':row['metadata'],'harness':harness}
 fingerprint=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
 case={'id':row['id'],'file':'<preflight>','mode':row['mode'],'metadata':row['metadata'],'source':row['source'],'harness':harness,'case_sha256':fingerprint,'source_sha256':identity['source_sha256']};assert case==o['cases'][i];cases.append(case)
 ref={'name':row['name'],'mode':row['mode'],'id':row['id'],'case_sha256':fingerprint,'source_sha256':identity['source_sha256'],'expected':row['expected']};refs[(row['name'],row['mode'])]=ref
 if i<32:assert dict(ref,includes=row['metadata']['includes'],prerequisites=row['prerequisites'])==old[i]
assert len(refs)==44
for row,case,outcome in zip(v,cases,o['healthy_outcomes']):
 obs=dict(row['required_observation'],message='')
 result={k:case[k] for k in ('id','file','mode','case_sha256','source_sha256')};result.update(expected_negative=None,status=row['expected'],observation=obs)
 expected={'name':row['name'],'expected':row['expected'],'verified':True,'result':result,'prerequisites':[refs[tuple(k)] for k in row['prerequisites']]}
 assert outcome==expected
 assert row['metadata']['negative'] is None and not row['metadata']['features'] and not row['metadata']['flags']
 assert obs==dict(status='complete' if row['expected']=='passed' else 'exception',phase='runtime',error_type='' if row['expected']=='passed' else 'Test262Error',error_identity='',harness='',message='')
for i in range(32,44):
 row=v[i];common=[[r['name'],r['mode']] for r in v[:32]]
 assert row['prerequisites']==common+([[row['name'].removesuffix('-mismatch'),row['mode']]] if row['name'].endswith('-mismatch') else [])
visited=set();active=set();bykey={(r['name'],r['mode']):r for r in v}
def visit(key):
 assert key not in active
 if key in visited:return
 active.add(key)
 for dep in bykey[key]['prerequisites']:visit(tuple(dep))
 active.remove(key);visited.add(key)
for k in bykey:visit(k)
pairs=[]
for prefix in ('generic','genuine','result'):
 p=H/'literals'/('with-resolvers-'+prefix+'.js');m=H/'literals'/('with-resolvers-'+prefix+'-mismatch.js')
 good=p.read_text().splitlines(True);bad=m.read_text().splitlines(True);assert len(good)==len(bad) and good[:-1]==bad[:-1] and good[-1]!=bad[-1]
 pairs.append({'family':prefix,'changed_line_1based':len(good),'positive':good[-1].rstrip(),'mismatch':bad[-1].rstrip()})
module=H/'raw/tools/test_test262_with_resolvers_controls.py';tree=ast.parse(module.read_text());assign={n.targets[0].id:n.value for n in tree.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name)}
assert ast.literal_eval(assign['ORACLE_SHA'])==sha((H/'raw/tools/test262-with-resolvers-controls-oracle.json').read_bytes())
groups=[n.name for cls in tree.body if isinstance(cls,ast.ClassDef) for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
roster=json.loads((H/'test-roster.json').read_text());assert groups==roster['tests'] and len(groups)==9
# Source-semantic inputs are published exact, not future production.
rust=[]
for rel in ('src/script/promises/semantics.rs','src/script/promises/factories.rs'):
 p=C/'worktree'/rel;assert p.read_bytes()==subprocess.check_output(['git','show',base+':'+rel],cwd=C/'worktree');rust.append(bind(p))
report={'status':'clear','scope':'Independent source-only review of 44 frozen control rows, three literal pairs and nine mocked canonical-gate test groups.','base':base,'bindings':[bind(H/'source-ready.json'),bind(H/'literals-ready.json'),bind(module),bind(H/'raw/tools/test262-with-resolvers-controls-oracle.json'),bind(C/'ordinary-control-audit-1/common-control-identities.json'),bind(C/'readiness-1/parent/tools/test262_conformance.py'),bind(C/'root/selection-1.json')]+rust,'counts':{'controls':44,'common':32,'new':12,'intentional_passed':18,'intentional_failed':26,'test_groups':9,'synthetic_main_rows':12},'all_fingerprints_independently_recomputed':True,'old32_sources_metadata_helpers_identities_prerequisites_exact':True,'prerequisite_DAG_complete_and_acyclic':True,'one_terminal_assertion_pairs':pairs,'findings':[],'checks':['The generic control first proves the genuine intrinsic route, then captures the exact custom capability triple with zero eager calls. Invalid primitive, eval and method receivers fail constructor validation; only the final constructor count differs in the mismatch.','The genuine control checks the saved Promise prototype/constructor/brand through pending then, with no fulfillment/rejection queued, then verifies both callable names and arities. Its mismatch changes only the final reject arity.','The result control creates two fresh ordinary bags, verifies own key ordering, values and W/E/C data descriptors and no eager callback calls. All verifyProperty uses restore:true, preserving identities for later assertions. The final enumerable expectation is the sole mismatch.','The oracle rebuilds all44 source/mode/metadata/ordered-helper hashes and exact six-field references from pinned helper bytes. Synthetic observations are complete or Test262Error exception with empty identity/harness, not engine measurements.','All adapter execution is forbidden by a per-test guard. Builder tests mock run_case and independently require the selected profile/features and no completion policy. Gate tests cover malformed/unhashable outer/result/reference fields, raw six-field shape/types/UTF-8 byte limits, all44 required raw fields, helper/source/metadata changes and independent reclassification.','Dependency tests corrupt exact order/identity/same-mode links, prove positive-to-negative and common-to-all-new failure propagation, and test a defensive canonical self-cycle without allowing recursion failure.','Failed main-gate fixtures retain malformed or unverified/empty controls, block all12 synthetic source modes including class-tagged ones before run_case, preserve report identities, and refuse creation or overwrite of a baseline. The positive counterpart mocks all outcomes explicitly and checks ordinary format2/seven-name/no-host policy.'],'qualifications':['The healthy main fixture deliberately mocks the two class-tagged rows as passed to isolate routing; it states this explicitly and predicts no upstream class outcome.','Pending then is a synchronous Promise brand check, not asynchronous settlement or host-completion coverage.','No candidate runner or project execution was used for this review. Runtime sources were only read and joined to the published base.'],'execution':'Stdlib AST/literal/JSON/hash/data checks and read-only Git; no project import, test run, engine, build, fetch or live edits.'}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(R/'review.json')))
