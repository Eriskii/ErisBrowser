from pathlib import Path
import hashlib,json,subprocess,sys
C=Path(__file__).resolve().parents[1]; B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1');W=C/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def validate():
 s=json.loads((C/'source-candidate-1.json').read_bytes())
 for rel,expected in s['source_sha256'].items():assert sha(W/rel)==expected,rel
 for kind in ['ordinary','host']:
  m=json.loads((B/f'eris-js-{kind}-1.json').read_bytes());p=Path(m['binary']);assert sha(p)==m['sha256'] and p.stat().st_size==m['bytes']
def run(label,profile,kind,extra=()):
 validate();out=C/(label+'.json');assert not out.exists()
 cmd=[sys.executable,'-B',str(C/'run-tool.py'),label,sys.executable,'-B','tools/test262_conformance.py','--binary',str(B/f'eris-js-{kind}-1'),'--profile',profile,'--output',str(out),*extra]
 result=subprocess.run(cmd,check=False,cwd=W)
 assert result.returncode == (1 if label=='upstream-with-resolvers-1' else 0), (label,result.returncode)
 return json.loads(out.read_bytes())
mode=sys.argv[1]
if mode=='selected':
 r=run('upstream-with-resolvers-1','promise-with-resolvers','ordinary');assert r['harness_preflight_passed'] and len(r['harness_preflight'])==44 and all(x['verified'] is True for x in r['harness_preflight']);assert r['mode_cases']==12 and len(r['cases'])==12
 print(json.dumps(dict(actual_counts=r['counts'],controls=44,cases=12,policy=r['runner_policy_sha256'])))
elif mode=='legacy':
 for short,profile in [('aggregate-error','aggregate-error'),('existing','promise-methods-async'),('all','promise-all'),('race','promise-race'),('settled','promise-all-settled'),('any','promise-any')]:
  run('upstream-'+short+'-1',profile,'ordinary' if short=='aggregate-error' else 'host',['--baseline',f'tests/conformance/test262-{profile}-current.json'])
elif mode=='baseline':
 first=json.loads((C/'upstream-with-resolvers-1.json').read_bytes());assert first['harness_preflight_passed']
 baseline='tests/conformance/test262-promise-with-resolvers-current.json';assert not (W/baseline).exists()
 second=run('upstream-with-resolvers-record-1','promise-with-resolvers','ordinary',['--record-baseline',baseline])
 third=run('upstream-with-resolvers-check-1','promise-with-resolvers','ordinary',['--baseline',baseline])
 for r in [second,third]:
  for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','binary_sha256','corpus_manifest_sha256','counts','mode_cases']:assert r[key]==first[key],key
 assert (W/baseline).read_bytes()==(C/'upstream-with-resolvers-record-1.json').read_bytes()
 print('New baseline recorded only after44 healthy controls and checked with identical12 cases')
else:raise ValueError(mode)
