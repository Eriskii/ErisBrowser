from pathlib import Path
import hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');W=C/'worktree'
def verify(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
rows=[]
for hold in ['importer-1','runner-1','migrations-1','ci-1']:
 s=json.loads((C/hold/'source-ready.json').read_bytes())
 for r in s['files']:
  if hold=='importer-1' and r['role']!='production':continue
  rel=r.get('relative_path',r.get('relative'));p=W/rel;assert p.read_bytes()==verify(r['before']),rel
  p.write_bytes(verify(r['raw']));rows.append(dict(relative_path=rel,before=r['before'],raw=r['raw']))
(C/'root/candidate-import-1.json').write_text(json.dumps(dict(status='reviewed production/migrations/CI payloads imported',files=rows),indent=2)+'\n')
print('Imported',len(rows),'changed paths')
