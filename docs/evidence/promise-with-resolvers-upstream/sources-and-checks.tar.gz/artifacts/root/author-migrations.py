from pathlib import Path
import ast,difflib,hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1'); W=C/'worktree'; H=C/'migrations-1'; H.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def write(p,b):
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
census=json.loads((C/'readiness-1/legacy-adapter-census.json').read_bytes()); grouped={}
for e in census['entries']:grouped.setdefault(e['path'],[]).append(e)
records=[]
for rel, entries in grouped.items():
 before=(W/rel).read_bytes();s=before.decode();edits=[]
 for e in entries:
  old=e['source_line'];assert s.count(old)==1,(rel,old)
  if 'if k != NEW_PROFILE' in old:new=old.replace('if k != NEW_PROFILE',"if k not in {NEW_PROFILE, 'promise-with-resolvers'}")
  elif 'if k != PROFILE' in old:new=old.replace('if k != PROFILE',"if k not in {PROFILE, 'promise-with-resolvers'}")
  elif '- {NEW_PROFILE}' in old:new=old.replace('- {NEW_PROFILE}',"- {NEW_PROFILE, 'promise-with-resolvers'}")
  elif '- {PROFILE}' in old:new=old.replace('- {PROFILE}',"- {PROFILE, 'promise-with-resolvers'}")
  else:
   assert "'promise-any'" in old
   new=old.replace("'promise-any'","'promise-any', 'promise-with-resolvers'")
  s=s.replace(old,new);edits.append(dict(before=old,after=new))
 after=s.encode();ast.parse(s);raw=H/'raw'/rel;diff=H/'diff'/(rel+'.diff');write(raw,after);write(diff,''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile=rel,tofile=rel)).encode())
 inverse=s
 for e in reversed(edits):assert inverse.count(e['after'])==1;inverse=inverse.replace(e['after'],e['before'])
 assert inverse.encode()==before
 records.append(dict(relative_path=rel,before=info(W/rel),raw=info(raw),diff=info(diff),edits=edits,test_groups=sum(isinstance(n,ast.FunctionDef) and n.name.startswith('test_') for n in ast.walk(ast.parse(s)))))
assert len(records)==20 and sum(len(r['edits']) for r in records)==35
seal=dict(status='frozen selection-only historical migrations before candidate execution',base='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0',files=records,paths=20,edits=35,scope='Only new ordinary-profile exclusions; all old totals, host sets, numeric constants and oracle bytes retained. Exact inverses verified.')
write(H/'source-ready.json',(json.dumps(seal,indent=2)+'\n').encode());print(info(H/'source-ready.json'))
H=C/'ci-1';H.mkdir();rel='.github/workflows/check.yml';before=(W/rel).read_bytes();anchor=b'      - name: Preserve pinned synchronous for-of behavior\n';assert before.count(anchor)==1
addition=b'      - name: Preserve pinned Promise.withResolvers cases\n        run: python3 tools/test262_conformance.py --binary target/release/eris-js --profile promise-with-resolvers --baseline tests/conformance/test262-promise-with-resolvers-current.json --output artifacts/test262-promise-with-resolvers-gate.json\n'
after=before.replace(anchor,addition+anchor);assert after.replace(addition,b'')==before;raw=H/'raw'/rel;write(raw,after)
seal=dict(base='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0',status='frozen CI command before candidate execution; baseline will be authored only after healthy actual run',files=[dict(relative_path=rel,before=info(W/rel),raw=info(raw))],addition=addition.decode())
write(H/'source-ready.json',(json.dumps(seal,indent=2)+'\n').encode());print(info(H/'source-ready.json'))
