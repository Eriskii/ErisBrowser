from pathlib import Path
import ast,hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');W=C/'worktree';H=C/'preservation-1';H.mkdir()
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,b):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
o=json.loads((C/'readiness-1/old-profile-contract.json').read_bytes());o['base']='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'
f=json.loads((C/'readiness-1/old-function-hashes.json').read_bytes())
changed={'tools/import_test262.py':{'profile_tree_inventory','import_corpus'},'tools/test262_conformance.py':{'load_corpus','decode_response','run_case','harness_preflight','main'}}
o['unchanged_functions']={rel:{n:v for n,v in fs.items() if n not in changed[rel]} for rel,fs in f.items()}
for rel,expected in o['unchanged_functions'].items():
 s=(W/rel).read_text();actual={n.name:hashlib.sha256(ast.get_source_segment(s,n).encode()).hexdigest() for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name in expected};assert actual==expected
oracle=H/'raw/tools/with-resolvers-preservation-oracle.json';write(oracle,(json.dumps(o,indent=2)+'\n').encode())
s=(W/'tools/test_test262_promise_any_preservation.py').read_text()
s=s.replace('Any-only','ordinary Promise.withResolvers').replace('promise-any-preservation-oracle.json','with-resolvers-preservation-oracle.json').replace('01ac062ca6999de4b36cac2d3a36fe58a5210ea17ca52db032bb823d41c30406',info(oracle)['sha256']).replace("NEW_PROFILE = 'promise-any'","NEW_PROFILE = 'promise-with-resolvers'").replace('class PromiseAnyPreservationTests','class WithResolversPreservationTests').replace('test_all_58_old','test_all_59_old').replace("sorted(runner.PROMISE_HOST_PROFILES - {NEW_PROFILE})","sorted(runner.PROMISE_HOST_PROFILES)").replace("len(old['profiles']), 58","len(old['profiles']), 59").replace("for health in ('aggregate_error_preflight_healthy'","for health in ('promise_any_preflight_healthy', 'aggregate_error_preflight_healthy'")
start=s.index('    def test_existing_gates_literals_fingerprints_and_request_encoding_are_unchanged(self):')
end=s.index("\n\nif __name__",start)
s=s[:start]+'''    def test_old_import_authentication_gates_classifiers_and_encoders_remain_exact(self):
        for relative, expected in self.oracle['unchanged_functions'].items():
            with self.subTest(path=relative):
                source = (Path(__file__).resolve().parent.parent / relative).read_text()
                actual = {node.name: hashlib.sha256(ast.get_source_segment(source, node).encode()).hexdigest()
                          for node in ast.parse(source).body
                          if isinstance(node, ast.FunctionDef) and node.name in expected}
                self.assertEqual(actual, expected)
        self.assertIn('classify', self.oracle['unchanged_functions']['tools/test262_conformance.py'])
        self.assertIn('git_tree_inventory', self.oracle['unchanged_functions']['tools/import_test262.py'])
'''+s[end:]
ast.parse(s);test=H/'raw/tools/test_test262_with_resolvers_preservation.py';write(test,s.encode())
seal=dict(status='frozen published-parent59 policies and unchanged function bodies before candidate execution',base=o['base'],files=[dict(relative_path=str(p.relative_to(H/'raw')),raw=info(p),new_file=True) for p in [oracle,test]],groups=2,old_profiles=59,function_counts={p:len(v) for p,v in o['unchanged_functions'].items()},changed_function_exclusions={p:sorted(v) for p,v in changed.items()},qualification='All real fetch/adapter calls forbidden; main policies observed with zero mocked cases; no candidate source imported.')
write(H/'source-ready.json',(json.dumps(seal,indent=2)+'\n').encode());print(info(H/'source-ready.json'))
