from pathlib import Path
from collections import Counter
import hashlib,json,re
C=Path(__file__).resolve().parents[1];W=C/'worktree'
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(p):return json.loads(p.read_bytes())
def passed(label,count):
 p=C/'validation'/(label+'.log');s=p.read_text();rows=re.findall(r'^(test_\S+) \(([^)]+)\) \.\.\. ok$',s,re.M)
 assert len(rows)==count and f'Ran {count} tests' in s and s.endswith('\nOK\n'),(label,len(rows))
 assert read(p.with_suffix('.json'))['exit']==0
 return Counter(identity for _,identity in rows)
parent=passed('python-parent-1',624);candidate=passed('python-full-1',652);selected=passed('selected-candidate-1',28);assert candidate==parent+selected
parent_observations=[]
for label,total in [('selected-parent-1',19),('controls-parent-1',9)]:
 s=(C/'validation'/(label+'.log')).read_text();entries=re.findall(r'^(test_\S+) \(([^)]+)\) \.\.\.(.*)$',s,re.M);assert len({identity for _,identity,_ in entries})==total
 failure_ids=set(re.findall(r'^(?:ERROR|FAIL): test_\S+ \(([^)]+)\)',s,re.M))
 okay=[identity for _,identity,result in entries if result.strip()=='ok'];assert len(set(okay)|failure_ids)==total and not set(okay)&failure_ids
 parent_observations.append(dict(label=label,groups=total,passed_groups=len(okay),nonpassing_groups=len(failure_ids),failure_or_error_details=re.search(r'FAILED \(([^\n]+)\)',s)[1],qualification='Subtest failure/error detail counts differ from group counts.',log=info(C/'validation'/(label+'.log'))))
profiles=[]
for name in ['aggregate-error','existing','all','race','settled','any']:
 p=C/f'upstream-{name}-1.json';r=read(p);old=read(C/'replay-parent'/p.name)
 for k in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','mode_cases','binary_sha256']:assert r[k]==old[k],(name,k)
 assert r['harness_preflight_passed'] and all(x['verified'] is True for x in r['harness_preflight']) and not r['regressions'] and not r['improvements']
 profiles.append(dict(name=name,cases=len(r['cases']),controls=len(r['harness_preflight']),counts=r['counts'],report=info(p)))
assert sum(r['cases'] for r in profiles)==1288 and sum(r['controls'] for r in profiles)==502
reports=[read(C/f'upstream-with-resolvers{s}-1.json') for s in ['','-record','-check']];first=reports[0]
for r in reports:
 assert r['counts']=={'unsupported':2,'passed':10} and r['mode_cases']==12 and len(r['cases'])==12 and r['harness_preflight_passed'] and len(r['harness_preflight'])==44 and all(x['verified'] is True for x in r['harness_preflight'])
 for k in ['cases','harness_preflight','runner_policy','runner_policy_sha256','binary_sha256','corpus_manifest_sha256','counts','mode_cases']:assert r[k]==first[k],k
 assert not r['regressions'] and not r['improvements']
baseline=W/'tests/conformance/test262-promise-with-resolvers-current.json';expected={k:first[k] for k in ['revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256']};expected['cases']={r['id']:{k:r[k] for k in ['status','case_sha256','source_sha256']} for r in first['cases']};assert read(baseline)==expected
notes=['Initial wrapper required exit0 for unbaselined run; actual runner correctly returned1 because2class rows remain unsupported. Complete healthy report retained; no candidate correction.', 'Baseline wrapper compared compact status-map baseline bytes against full report; assertion failed after successful record and check commands. This independent verifier compares the exact five-field compact schema and every retained case identity/status. No repeated engine run or candidate correction.']
result=dict(status='pass',python=dict(parent=624,candidate=652,new=28,exact_roster_union=True,parent_new_group_observations=parent_observations),selected=dict(cases=12,controls=44,counts=first['counts'],policy=first['runner_policy'],policy_sha256=first['runner_policy_sha256'],baseline=info(baseline),all_three_arrays_identical=True,unsupported=[r['id'] for r in first['cases'] if r['status']=='unsupported']),legacy=dict(profiles=profiles,cases=1288,controls=502,all_case_control_policy_corpus_binary_arrays_exact=True),orchestration_notes=notes)
p=C/'root/validation-checks-1.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n');print(info(p));print(json.dumps(result['python']));print('Legacy1288cases502controls exact; selected12cases44controls stable; compactbaseline exact')
