from pathlib import Path
import ast,hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');H=C/'importer-1';W=C/'worktree';out=C/'importer-review-1';out.mkdir()
sha=lambda b:hashlib.sha256(b).hexdigest()
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
s=json.loads((H/'source-ready.json').read_bytes())
for r in s['files']+s['corpus']:
 for key in ['before','raw','diff']:
  v=r.get(key)
  if v:assert info(Path(v['path']))==v
r=s['files'][0];before=Path(r['before']['path']).read_text();after=Path(r['raw']['path']).read_text();assert before==(W/r['relative_path']).read_text()
inverse=after
for e in reversed(json.loads((H/'production-edits.json').read_bytes())):
 assert inverse.count(e['after'])==1;inverse=inverse.replace(e['after'],e['before'])
assert inverse==before
def funcs(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=funcs(before),funcs(after);assert a.keys()==b.keys();changed=sorted(n for n in a if a[n]!=b[n]);assert changed==['import_corpus','profile_tree_inventory']
P=H/'corpus';m=json.loads((P/'manifest.json').read_bytes());proof=m['inventory_proof'];trees={}
def git(kind,body):return hashlib.sha1(kind.encode()+b' '+str(len(body)).encode()+b'\0'+body).hexdigest()
for p in (P/'inventory-proof').glob('tree-*.json'):
 d=json.loads(p.read_bytes());assert d['truncated'] is False
 entries=d['tree'];body=b''
 for e in sorted(entries,key=lambda e:e['path'].encode()+ (b'/' if e['type']=='tree' else b'')):
  mode=e['mode'].lstrip('0');body+=mode.encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha'])
 assert git('tree',body)==d['sha'];trees[d['sha']]={e['path']:e for e in entries}
assert len(trees)==6
root=proof['root_tree'];node=root
for name in ['test','built-ins','Promise','withResolvers']:node=trees[node][name]['sha']
assert node==proof['directory_trees']['Promise/withResolvers'];leaf=trees[node];assert len(leaf)==6 and all(e['type']=='blob' and e['path'].endswith('.js') for e in leaf.values())
for row in m['files']:
 node=root
 for part in row['path'].split('/'):node=trees[node][part]['sha']
 data=(P/row['path']).read_bytes();assert git('blob',data)==node
 assert len(data)==row['bytes'] and sha(data)==row['sha256']
assert len(m['files'])==11
# The retained commit binds the root; its full API response was independently fetched in readiness.
commit=json.loads((P/'inventory-proof/commit.json').read_bytes());assert commit['sha']==m['revision'] and commit['tree']['sha']==root
for p in (H/'raw/tools').glob('test_*.py'):ast.parse(p.read_text())
report=dict(status='pass source review; project execution remains root validation',base=s['base'],source_ready=info(H/'source-ready.json'),exact_inverse_edits=8,changed_existing_functions=changed,unchanged_functions=len(a)-2,authenticated_trees=6,authenticated_blobs=11,commit_root_binding=True,corpus_files=19,corpus_bytes=sum(r['raw']['bytes'] for r in s['corpus']),tests=dict(groups=9,checks=['fixed independent oracle','every proof and all source/helper/legal corruption','metadata12identities','full old59 tables','no network fallback','no publication on missing or altered inputs']),notes='Selected branch only. Shared tree walker, parse_metadata, fetch and all other old function bytes exact. Source-root proof follows root/test/built-ins/Promise/withResolvers; auxiliary helpers/legal follow same root. No live production imported.')
(out/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(info(out/'review.json'))
