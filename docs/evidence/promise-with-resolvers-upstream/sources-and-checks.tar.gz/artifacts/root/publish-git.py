import json
from pathlib import Path
import subprocess
B=Path(__file__).resolve().parents[1];W=B/'worktree';MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0';P=B/'publication';P.mkdir(exist_ok=True);record_path=B/'root/github-publication.json';assert not record_path.exists()
verified=json.loads((B/'root/publication-verification.json').read_bytes());assert verified['status']=='verified' and verified['path_count']==59

def git(directory,*args):
 r=subprocess.run(['git',*args],cwd=directory,text=True,capture_output=True,check=True);return r.stdout.strip()

assert git(MAIN,'branch','--show-current')=='main'
assert git(MAIN,'rev-parse','HEAD')==git(W,'rev-parse','HEAD')==BASE
assert git(MAIN,'status','--porcelain')=='' and git(W,'diff','--cached','--name-only')==''
paths=verified['expected_commit_paths'];pathspec=P/'paths.nul';pathspec.write_bytes(b'\0'.join(p.encode() for p in paths)+b'\0')
git(W,'add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul')
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
whitespace=json.loads((B/'root/new-file-whitespace.json').read_bytes())
exceptions=[r['path'] for r in whitespace['issues']]
assert len(exceptions)==4 and all(p.startswith('tests/upstream/test262-promise-with-resolvers/') for p in exceptions)
# Authenticated upstream bytes are retained verbatim; check every authored path.
git(W,'diff','--cached','--check','--','.',*[":(exclude)"+p for p in exceptions])
message=P/'commit-message.txt';message.write_text('Add pinned Promise.withResolvers conformance profile\n\nAuthenticate the complete six-file upstream selection and retain all 12 modes.\nRequire 44 canonical ordinary-protocol controls before running source cases or\nrecording a baseline. Reject forged completion requests and host responses.\n\nThe actual selection passes 10 modes; two class modes remain unsupported.\nAll 652 Python groups pass, including 28 additions. All 1288 older cases and\n502 controls retain their full results using the published Rust binaries.\n')
(P/'commit.log').write_text(git(W,'commit','-F',str(message))+'\n');commit=git(W,'rev-parse','HEAD')
assert git(W,'status','--porcelain')==''
assert set(git(W,'diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())==set(paths)
record={'status':'committed','base':BASE,'commit':commit,'repository':'https://github.com/Eriskii/ErisBrowser','paths':len(paths)};record_path.write_text(json.dumps(record,indent=2)+'\n')
(P/'merge.log').write_text(git(MAIN,'merge','--ff-only','promise-with-resolvers-upstream')+'\n')
assert git(MAIN,'rev-parse','HEAD')==commit and git(MAIN,'status','--porcelain')==''
(P/'push.log').write_text(git(MAIN,'push','origin','main')+'\n');remote=git(MAIN,'ls-remote','origin','refs/heads/main').split()[0];assert remote==commit
record.update(status='pushed',remote_head=remote,ci='not yet observed');record_path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
