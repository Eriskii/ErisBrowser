from pathlib import Path
import ast,hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');H=C/'runner-1';W=C/'worktree';O=C/'runner-review-1';O.mkdir()
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
s=json.loads((H/'source-ready.json').read_bytes());r=s['files'][0]
for v in [r['before'],r['raw'],r['diff']]+s['bindings']:assert info(Path(v['path']))==v
before=Path(r['before']['path']).read_text();after=Path(r['raw']['path']).read_text();assert before==(W/r['relative']).read_text()
edits=json.loads((H/'edit-manifest.json').read_bytes());inverse=after
for e in reversed(edits):
 assert inverse.count(e['after'])==1,e['label'];inverse=inverse.replace(e['after'],e['before'])
assert inverse==before
def functions(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a,b=functions(before),functions(after);changed=sorted(n for n in a if a[n]!=b[n]);assert changed==['decode_response','harness_preflight','load_corpus','main','run_case'];assert len(b.keys()-a.keys())==6
assert a['classify']==b['classify'] and a['profile_intrinsic_errors']==b['profile_intrinsic_errors']
f=b['run_case'];assert f.index("'completion_policy' in case")<f.index('unsupported_reason(')<f.index('encode_request(')
review=dict(status='pass independent source review; project execution pending',base=s['base'],source_ready=info(H/'source-ready.json'),exact_inverse_edits=len(edits),changed_functions=changed,new_functions=sorted(b.keys()-a.keys()),unchanged_functions=len(a)-5,checks=['selected feature only; host membership unchanged','ERJR2 refusal before ERJR3 decoder','request-key presence refusal before unsupported dispatch','canonical44 complete unique row set','exact outer/result/reference/raw field sets and types','all raw strings UTF8bounded16384','expected observations and unchanged ordinary classify','canonical ordered prerequisite references and recursive health','failed selected gate blocksall12 before case dispatch','all old decoder/classifier arities preserved'],qualification='No source outcome or browser compatibility inferred from source review. Script peer independently reviewed root protocol fixtures; live test execution remains root-owned.')
(O/'review.json').write_text(json.dumps(review,indent=2)+'\n');print(info(O/'review.json'))
