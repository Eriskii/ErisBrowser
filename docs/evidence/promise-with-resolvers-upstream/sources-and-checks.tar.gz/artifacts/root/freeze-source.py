from pathlib import Path
import hashlib,json,subprocess,sys
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');W=C/'worktree'
label=sys.argv[1]; p=json.loads((C/'source-parent.json').read_bytes());known=dict(p['source_sha256'])
changed=subprocess.check_output(['git','diff','--name-only',p['base']],cwd=W,text=True).splitlines()
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()
expected=json.loads((C/'root/candidate-import-1.json').read_bytes())['files'];assert set(changed)=={r['relative_path'] for r in expected}
for r in expected:assert hashlib.sha256((W/r['relative_path']).read_bytes()).hexdigest()==r['raw']['sha256']
for rel,sha in known.items():
 actual=hashlib.sha256((W/rel).read_bytes()).hexdigest()
 if rel not in changed:assert actual==sha,rel
 known[rel]=actual
for rel in untracked:
 if rel.startswith('docs/') or rel=='README.md':continue
 assert rel.startswith(('tests/upstream/test262-promise-with-resolvers/','tools/','tests/conformance/test262-promise-with-resolvers-current.json')),rel
 known[rel]=hashlib.sha256((W/rel).read_bytes()).hexdigest()
record=dict(base=p['base'],source_sha256=dict(sorted(known.items())),scope='Cumulative selected inputs, not the entire build graph. Runtime/Cargo/build inputs unchanged from published BH; new profile tooling, corpus and baseline included.')
out=C/(label+'.json');assert not out.exists();out.write_text(json.dumps(record,indent=2)+'\n')
receipt=dict(status='pass',inventory=str(out),bytes=out.stat().st_size,sha256=hashlib.sha256(out.read_bytes()).hexdigest(),selected_inputs=len(known),changed=len(changed),new=len(untracked),unchanged_selected=len(p['source_sha256'])-len(changed),runtime_unchanged=True,changed_paths=changed,new_paths=untracked)
(C/'root'/(label+'-binding.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
