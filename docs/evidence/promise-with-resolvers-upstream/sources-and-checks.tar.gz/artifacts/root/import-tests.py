from pathlib import Path
import hashlib,json
C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');W=C/'worktree'
def check(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256'];return b
rows=[]
i=json.loads((C/'importer-1/source-ready.json').read_bytes());rows.extend(r for r in i['files'] if r['role']!='production');rows+=i['corpus']
p=json.loads((C/'protocol-1/source-ready.json').read_bytes());rows.append(dict(relative_path='tools/test_test262_with_resolvers_protocol.py',raw=p['module']))
rows+=json.loads((C/'preservation-1/source-ready.json').read_bytes())['files']
for r in rows:
 p=W/r['relative_path'];assert not p.exists();b=check(r['raw']);p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
report=dict(status='tests-only and authenticated corpus imported; production remains published parent',files=rows,expected_groups=19)
(C/'root/tests-import-1.json').write_text(json.dumps(report,indent=2)+'\n');print('Imported',len(rows),'paths; production unchanged')
