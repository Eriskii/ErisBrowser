from pathlib import Path
import json,hashlib,re,difflib
H=Path('/tmp/eris-promise-race-1/tests-public-2');m=json.loads((H/'source-ready.json').read_text())
def b(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
checks=0
def verify(x):
 global checks
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   a=b(Path(x['path']));assert (a['bytes'],a['sha256'])==(x['bytes'],x['sha256']),x['path'];checks+=1
  for y in x.values():verify(y)
 elif isinstance(x,list):
  for y in x:verify(y)
verify(m)
raw=Path(m['test_module']['raw']['path']).read_text();old=Path(m['test_module']['before']['path']).read_text();assert raw.startswith(old)
assert Path(m['registration']['before']['path']).read_bytes()==Path(m['registration']['raw']['path']).read_bytes()
assert Path(m['registration']['patch']['path']).read_bytes()==b''
diff=''.join(difflib.unified_diff(old.splitlines(True),raw.splitlines(True),fromfile='a/src/script/promise_race_semantic_tests.rs',tofile='b/src/script/promise_race_semantic_tests.rs'))
assert diff==Path(m['test_module']['patch']['path']).read_text()
o=Path(m['oracle_hold']['path']);oh=json.loads(o.read_text())
for x in oh['files']:
 p=o.parent/x['path'];a=b(p);assert (a['bytes'],a['sha256'])==(x['bytes'],x['sha256']);checks+=1
oracle=json.loads((o.parent/'oracles.json').read_text());roster=json.loads((H/'roster.json').read_text());verify(roster)
added=raw[len(old):];groups=re.findall(r'#\[test\]\s*fn (\w+)\(\) \{(.*?)(?=\n#\[test\]|\Z)',added,re.S);assert len(groups)==11
prefix=oracle['fixture_contract']['required_source_prefix'];n=0
pattern=r'observe\(\s*"([^"\n]+)",\s*r###"(.*?)"###,\s*r###"(.*?)"###,\s*(Value::Bool\((true|false)\)|Value::String\(("(?:[^"\\]|\\.)*")\.into\(\)\)),\s*\);'
for (name,body),og,rg in zip(groups,oracle['groups'],roster['groups']):
 assert name=='promise_race_'+og['id']==rg['test'].split('::')[-1]
 rows=re.findall(pattern,body,re.S);assert len(rows)==len(og['rows'])==len(rg['rows'])
 for parsed,er,rr in zip(rows,og['rows'],rg['rows']):
  ident,js,obs,expr,boolean,string=parsed;assert ident==og['id']+'/'+er['id']==rr['id']
  assert js==prefix+er['source']+'\n'==Path(rr['source']['path']).read_text()
  assert js.count(prefix)==1
  assert obs==er['observation']+'\n'==Path(rr['observation']['path']).read_text()
  expected=(boolean=='true') if boolean else json.loads(string)
  assert type(expected)==type(er['expected']) and expected==er['expected']==rr['expected']
  n+=1
 assert re.sub(pattern,'',body,flags=re.S).strip()=='}'
assert n==49 and len(re.findall(r'#\[test\]',raw))==17
r={'status':'clear_source_only','scope':'Independent conversion/API/provenance peer of additive49 rows; existing semantic oracle peer is separately bound. No execution or live edits.','bindings':[b(H/'source-ready.json'),b(H/'roster.json'),b(o),b(Path(m['oracle_review']['path'])),b(H/'script-review-check.py')],'checks':{'bound_files_checked':checks,'original_prefix_bytes':len(old.encode()),'original_six_groups_unchanged':True,'added_groups':11,'added_rows':49,'added_strict_sloppy_rows':98,'total_groups':17,'total_rows':55,'total_strict_sloppy_rows':110,'source_and_readback':'Every raw triple-hash source/readback equals its reviewed standalone blob exactly, including its final newline. Standalone source equals required prerequisite+oracle source+one newline; readback equals oracle observation+one newline. Each prerequisite appears exactly once.','expectations':'Every typed Bool/String expectation equals the oracle and roster; no coercion or literal correction.','conversion_structure':'After removing exact observe calls, each added function contains only its closing brace; no added setup/reset/branch/helper. Existing observe helper remains in the exact5005-byte prefix.','registration':'Before/raw identical, empty patch; original cfg(test) module registration retained.','patch':'Unified diff reconstructed exactly from before/raw.','eligibility':'Existing Runtime/Document APIs only. Parent-compilable; each additive group should fail at its first missing-race prerequisite, leaving later rows unobserved until candidate execution. No observed outcome claimed.'},'findings':[]}
p=H/'script-review.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(b(p)))
