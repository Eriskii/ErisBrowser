from pathlib import Path
import hashlib,json,difflib
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=Path(__file__).resolve().parent

def write(relative,data):
 p=H/'raw'/relative;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(data);return p

def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

page=(W/'tests/promise_all.rs').read_text().replace('Promise.all preserves input order and runs reactions at host checkpoints.','Promise.race preserves settlement ordering at page and host checkpoints.').replace('promise_all','promise_race').replace('promise-all.invalid','promise-race.invalid').replace('collects_in_order_and_drains_before_the_next_host_listener','settles_in_fifo_order_and_handles_click_rejection').replace('&fonts, 12,','&fonts, 6,').replace('&fonts, 16,','&fonts, 10,')
worker=(W/'tests/worker/promise_all.rs').read_text().replace('Promise.all ordering, literal pixels and host callbacks through a confined worker.','Promise.race ordering, literal pixels and host callbacks through a confined worker.').replace('promise_all','promise_race').replace('collects_in_order_and_drains_before_the_next_host_listener','settles_in_fifo_order_and_handles_click_rejection').replace('641','651').replace('642','652').replace(', 12, oracle::INITIAL',', 6, oracle::INITIAL').replace(', 16, oracle::CLICKED',', 10, oracle::CLICKED')
support=(W/'tests/support/promise_all.rs').read_text().replace('promise-all.html','promise-race.html').replace('"SQA"','"SEPQW7"').replace('"SQACDKB"','"SEPQW7ACQR"')
old=(W/'tests/fixtures/promise-all.html').read_text();prefix=old.split('<script>\n')[0]
script='''var red=document.getElementById('red');
var trace='S';
Promise.race([Promise.resolve(7),Promise.resolve(9)]).then(function(v){trace+='W'+v;red.style.left=(v-1)+'px';document.title=trace;});
Promise.resolve().then(function(){trace+='P';});
queueMicrotask(function(){trace+='Q';});
trace+='E';
red.addEventListener('click',function(){
  trace+='A';var token={};
  Promise.race([Promise.reject(token),Promise.resolve(9)]).then(function(){trace+='BAD';document.title=trace;},function(e){trace+=e===token?'R':'BAD';red.style.left='10px';document.title=trace;});
  queueMicrotask(function(){trace+='Q';});
  trace+='C';
});
'''
paths=[]
for relative,data in [('tests/promise_race.rs',page),('tests/worker/promise_race.rs',worker),('tests/support/promise_race.rs',support),('tests/fixtures/promise-race.html',prefix+'<script>\n'+script+'</script></body></html>\n')]:
 assert not (W/relative).exists();paths.append({'relative':relative,'raw':bind(write(relative,data))})
relative='tests/worker.rs';before=H/'before'/relative;before.parent.mkdir(parents=True,exist_ok=True);before.write_bytes((W/relative).read_bytes())
append='\n#[path = "worker/promise_race.rs"]\nmod promise_race;\n';raw=write(relative,before.read_text()+append)
diff=H/'worker-registration.patch';diff.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),raw.read_text().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
roster={'groups':2,'tests':['promise_race_settles_in_fifo_order_and_handles_click_rejection','promise_race::confined_promise_race_settles_in_fifo_order_and_handles_click_rejection'],'viewports':[[320,240],[300,240]],'expected':{'disabled':{'red_x':2,'title':'base'},'enabled_initial':{'red_x':6,'title':'SEPQW7'},'enabled_clicked':{'red_x':10,'title':'SEPQW7ACQR'},'geometry':'White frame; red4x4 at(x,2), blue4x4 at(20,2), full literal pixels and hit IDs before title/idle/diagnostics checks.'},'preserved':'Existing Page/worker check helpers and literal pixel generator retained except function/profile labels and selected positions/traces. Disabled first, repeated Render/RunTasks and actual Click. No hardware GPU claim.','parent_prediction':'Both groups first pass disabled checks; enabled first full pixel comparison fails because missing Promise.race leaves red at2 rather than6. Later title/click/repeat checks unreached.'}
(H/'roster.json').write_text(json.dumps(roster,indent=2)+'\n')
sources=[]
for r in ['tests/promise_all.rs','tests/worker/promise_all.rs','tests/support/promise_all.rs','tests/fixtures/promise-all.html']:
 p=H/'sources'/r;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((W/r).read_bytes());sources.append({'relative':r,'snapshot':bind(p)})
ready={'status':'frozen_integration_tests_before_production','base':'781d012242374c2b4cb8c3b7a50c0b908e4309fa','paths':paths,'registration':{'relative':relative,'before':bind(before),'raw':bind(raw),'patch':bind(diff),'exact_append_utf8':append},'roster':bind(H/'roster.json'),'sources':sources,'author':bind(Path(__file__)),'scope':'Root-authored two-route witness from selected six ordering traces; no production, old test changes, changed caps or execution.'}
(H/'source-ready.json').write_text(json.dumps(ready,indent=2)+'\n')
print(json.dumps({'hold':bind(H/'source-ready.json'),'groups':2}))
