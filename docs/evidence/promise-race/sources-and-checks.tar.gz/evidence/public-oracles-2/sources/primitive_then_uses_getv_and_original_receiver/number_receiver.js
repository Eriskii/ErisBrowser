if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',result={},out,receiver=false,identities=false,ignored=0;
function resolve(v){trace+='F'+v;}
function reject(v){trace+='J'+v;}
function C(executor){executor(resolve,reject);return result;}
C.resolve=function(){return 7;};
Object.defineProperty(Number.prototype,'then',{configurable:true,value:function(f,j){'use strict';receiver=this===7;identities=f===resolve&&j===reject&&arguments.length===2;f(9);j(10);return {get then(){ignored++;throw 'ignored then return';}};}});
out=Promise.race.call(C,[1]);delete Number.prototype.then;
