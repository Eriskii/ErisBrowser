trace+'|'+receiver+'|'+identities+'|'+ignored+'|'+(out===result)
