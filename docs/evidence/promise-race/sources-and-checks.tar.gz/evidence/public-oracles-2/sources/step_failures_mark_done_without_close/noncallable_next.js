if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},seen,result={},out,gets=0,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='BAD';};}});
input[Symbol.iterator]=function(){trace+='I';return it;};
Object.defineProperty(it,'next',{get:function(){trace+='G';return 0;}});
Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';throw 'close must not run';}});
out=Promise.race.call(C,input);
