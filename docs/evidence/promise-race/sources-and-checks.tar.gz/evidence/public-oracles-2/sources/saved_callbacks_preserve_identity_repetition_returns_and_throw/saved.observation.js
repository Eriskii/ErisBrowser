trace+'|'+returns.join(',')+'|'+caught+'|'+(f===resolve&&j===reject)+'|'+(out===result)
