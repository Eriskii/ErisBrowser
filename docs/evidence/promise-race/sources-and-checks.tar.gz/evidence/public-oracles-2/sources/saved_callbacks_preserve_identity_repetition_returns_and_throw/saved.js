if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},caught=false,result={},out,f,j,returns=[];
function resolve(v){trace+='F'+v;if(v===4)throw token;return v+100;}
function reject(v){trace+='J'+v;return v+200;}
function C(executor){executor(resolve,reject);return result;}
C.resolve=function(v){return v;};
out=Promise.race.call(C,[{then:function(a,b){f=a;j=b;}}]);
returns.push(f(1));returns.push(f(2));returns.push(j(3));try{f(4);}catch(e){caught=e===token;}
