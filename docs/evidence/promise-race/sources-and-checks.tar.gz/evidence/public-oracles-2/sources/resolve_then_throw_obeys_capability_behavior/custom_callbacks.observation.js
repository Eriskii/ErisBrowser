trace+'|'+(seen===token)+'|'+closed+'|'+(out===result)
