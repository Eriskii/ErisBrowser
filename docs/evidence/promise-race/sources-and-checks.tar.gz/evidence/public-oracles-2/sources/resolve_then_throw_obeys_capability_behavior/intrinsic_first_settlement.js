if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},closed=0,it={},input={},original=Promise.resolve;
Promise.resolve=function(){return {then:function(f){f(7);throw token;}};};
it.next=function(){return {done:false,value:1};};it.return=function(){closed++;return {};};
input[Symbol.iterator]=function(){return it;};var result=Promise.race(input);
Promise.resolve=original;
result.then(function(v){trace+='W'+v;},function(){trace+='BAD';});
