trace+'|'+closed
