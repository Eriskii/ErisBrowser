if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},seen,result={},out,closed=0,it={},input={};
function C(executor){executor(function(v){trace+='F'+v;},function(e){trace+='J';seen=e;});return result;}
C.resolve=function(){return {then:function(f){f(7);throw token;}};};
it.next=function(){return {done:false,value:1};};it.return=function(){closed++;return {};};
input[Symbol.iterator]=function(){return it;};out=Promise.race.call(C,input);
