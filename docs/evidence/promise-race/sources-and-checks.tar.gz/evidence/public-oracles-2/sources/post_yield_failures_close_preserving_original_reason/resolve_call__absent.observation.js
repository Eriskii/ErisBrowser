trace+'|'+(seen===token)+'|'+gets+'|'+calls+'|'+rejects+'|'+receiver+'|'+(out===result)
