if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},closeToken={},seen,result={},out,gets=0,calls=0,rejects=0,receiver=true,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){'use strict';receiver=receiver&&this===undefined;rejects++;trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='A';return {get then(){trace+='G';return function(){trace+='T';throw token;};}};};}});
input[Symbol.iterator]=function(){trace+='I';return it;};
it.next=function(){trace+='N';return {get done(){trace+='D';return false;},get value(){trace+='V';return 1;}};};
Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';return undefined;}});
out=Promise.race.call(C,input);
