if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var d=Object.getOwnPropertyDescriptor(Promise,'race'),f=d.value;
var n=Object.getOwnPropertyDescriptor(f,'name'),l=Object.getOwnPropertyDescriptor(f,'length');
var noNew=false;try{new f([]);}catch(e){noNew=e instanceof TypeError;}
var old=[Promise,Promise.all,Promise.resolve,Promise.reject,Promise.prototype.then,Promise.prototype.catch,Promise.prototype.finally];
var distinct=true;for(var i=0;i<old.length;i++){if(f===old[i])distinct=false;}
var check=[f===Promise.race,d.writable,!d.enumerable,d.configurable,n.value==='race',l.value===1,
!n.writable,!n.enumerable,n.configurable,!l.writable,!l.enumerable,l.configurable,
!Object.prototype.hasOwnProperty.call(f,'prototype'),Object.getPrototypeOf(f)===Function.prototype,noNew,distinct,
Object.getOwnPropertyNames(Promise).join(',')==='length,name,prototype,resolve,reject,all,race'].every(function(v){return v;});
Object.defineProperty(f,'name',{value:'changed race'});Object.defineProperty(f,'length',{value:99});
check=check&&Promise.all.name==='all'&&Promise.all.length===1&&Promise.resolve.name==='resolve'&&Promise.resolve.length===1;
