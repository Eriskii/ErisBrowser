if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},seen,result={},out,receiver=false,input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){'use strict';receiver=this===undefined;trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return 0;}});
Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw 'late iterator';}});
out=Promise.race.call(C,input);
