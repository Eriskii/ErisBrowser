trace+'|'+(seen instanceof TypeError)+ '|'+receiver+'|'+(out===result)
