trace+'|'+(seen===token)+ '|'+receiver+'|'+(out===result)
