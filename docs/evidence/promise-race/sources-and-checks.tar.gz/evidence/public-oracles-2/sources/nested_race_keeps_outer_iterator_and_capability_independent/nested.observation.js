trace+'|'+bad+'|'+(out===outer)
