if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',outer={},inner={},out,bad=false;
function outerResolve(v){trace+='F'+v;}
function innerResolve(v){trace+='d'+v;}
function reject(){bad=true;}
function C(executor){trace+='C';executor(outerResolve,reject);return outer;}
function D(executor){trace+='D';executor(innerResolve,reject);return inner;}
D.resolve=function(v){trace+='B'+v;return {then:function(f,j){if(f!==innerResolve||j!==reject)bad=true;trace+='U';f(v);}};};
C.resolve=function(v){trace+='A'+v;if(v===1&&Promise.race.call(D,[9])!==inner)bad=true;return {then:function(f,j){if(f!==outerResolve||j!==reject)bad=true;trace+='T';f(v);}};};
out=Promise.race.call(C,[1,2]);
