if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},caught=false,input={};
function C(executor){trace+='C';executor(0,function(){});}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';throw 'late resolve';}});
Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw 'late iterator';}});
try{Promise.race.call(C,input);}catch(e){caught=e instanceof TypeError;}
