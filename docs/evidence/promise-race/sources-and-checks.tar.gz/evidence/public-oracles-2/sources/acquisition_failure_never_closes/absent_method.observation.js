trace+'|'+(seen instanceof TypeError)+'|'+gets+'|'+(out===result)
