trace+'|'+(seen===token)+'|'+gets+'|'+(out===result)
