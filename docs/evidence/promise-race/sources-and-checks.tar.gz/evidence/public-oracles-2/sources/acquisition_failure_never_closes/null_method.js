if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},seen,result={},out,gets=0,input={},it={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='BAD';};}});
Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';throw 'close must not run';}});
Object.defineProperty(it,'next',{get:function(){trace+='G';return function(){trace+='BAD';return {done:true};};}});
Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';return null;}});
out=Promise.race.call(C,input);
