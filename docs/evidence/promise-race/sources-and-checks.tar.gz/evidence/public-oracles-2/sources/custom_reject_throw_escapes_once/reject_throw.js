if(typeof Promise.race!=='function')throw new Error('Promise.race missing');
var trace='',token={},replacement={},seen=false,caught=false,closed=0,rejects=0,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){rejects++;trace+='J';seen=e===token;throw replacement;});}
C.resolve=function(){trace+='A';throw token;};
it.next=function(){trace+='N';return {done:false,value:1};};it.return=function(){closed++;trace+='R';return {};};
input[Symbol.iterator]=function(){trace+='I';return it;};
try{Promise.race.call(C,input);}catch(e){caught=e===replacement;trace+='E';}
