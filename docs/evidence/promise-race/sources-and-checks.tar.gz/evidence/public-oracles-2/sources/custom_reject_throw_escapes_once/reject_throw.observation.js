trace+'|'+seen+'|'+caught+'|'+closed+'|'+rejects
