from pathlib import Path
import json,hashlib
P=Path('/tmp/eris-promise-race-plan-1/public-oracles-2');groups=[]
def group(name,rows,reason):groups.append(dict(id=name,rows=rows,rationale=reason))
def row(id,source,observe,expected):return dict(id=id,source=source.strip(),observation=observe,expected=expected,expected_type='bool' if isinstance(expected,bool) else 'string')
group('metadata_and_nonconstructor',[row('metadata',r'''
var d=Object.getOwnPropertyDescriptor(Promise,'race'),f=d.value;
var n=Object.getOwnPropertyDescriptor(f,'name'),l=Object.getOwnPropertyDescriptor(f,'length');
var noNew=false;try{new f([]);}catch(e){noNew=e instanceof TypeError;}
var old=[Promise,Promise.all,Promise.resolve,Promise.reject,Promise.prototype.then,Promise.prototype.catch,Promise.prototype.finally];
var distinct=true;for(var i=0;i<old.length;i++){if(f===old[i])distinct=false;}
var check=[f===Promise.race,d.writable,!d.enumerable,d.configurable,n.value==='race',l.value===1,
!n.writable,!n.enumerable,n.configurable,!l.writable,!l.enumerable,l.configurable,
!Object.prototype.hasOwnProperty.call(f,'prototype'),Object.getPrototypeOf(f)===Function.prototype,noNew,distinct,
Object.getOwnPropertyNames(Promise).join(',')==='length,name,prototype,resolve,reject,all,race'].every(function(v){return v;});
Object.defineProperty(f,'name',{value:'changed race'});Object.defineProperty(f,'length',{value:99});
check=check&&Promise.all.name==='all'&&Promise.all.length===1&&Promise.resolve.name==='resolve'&&Promise.resolve.length===1;
''','check',True)],'Member/function descriptors, nonconstructibility, original relative constructor order and independent metadata.')
cap=[]
for kind,C,expect in [
 ('nonconstructor','var C={};',''),
 ('constructor_throw',"function C(executor){trace+='C';throw token;}",'C'),
 ('invalid_resolve',"function C(executor){trace+='C';executor(0,function(){});}",'C'),
 ('invalid_reject',"function C(executor){trace+='C';executor(function(){},0);}",'C')]:
 src="var trace='',token={},caught=false,input={};\n"+C+"\nObject.defineProperty(C,'resolve',{get:function(){trace+='R';throw 'late resolve';}});\nObject.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw 'late iterator';}});\ntry{Promise.race.call(C,input);}catch(e){caught="+('e===token' if kind=='constructor_throw' else 'e instanceof TypeError')+';}\n'
 cap.append(row(kind,src,"trace+'|'+caught",expect+'|true'))
group('capability_precedes_later_getters',cap,'Synchronous capability errors occur before resolve/iterator access; missing-race guard prevents incidental TypeError passing.')
res=[]
for kind,body,reason in [('getter_throw','throw token;','seen===token'),('not_callable','return 0;','seen instanceof TypeError')]:
 src="""var trace='',token={},seen,result={},out,receiver=false,input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){'use strict';receiver=this===undefined;trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';BODY}});
Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';throw 'late iterator';}});
out=Promise.race.call(C,input);
""".replace('BODY',body)
 res.append(row(kind,src,"trace+'|'+("+reason+")+ '|'+receiver+'|'+(out===result)",'CRJ|true|true|true'))
group('resolve_get_or_callable_failure_rejects_before_iterator',res,'Cached resolve acquisition rejects once after capability creation with undefined callback receiver, without touching input.')
acq=[]
variants=[
 ('absent_method','',"return function(){trace+='M';return it;};",False,'CRJ'),
 ('null_method','define',"return null;",False,'CRIJ'),
 ('noncallable_method','define',"return 0;",False,'CRIJ'),
 ('iterator_getter_throw','define',"throw token;",True,'CRIJ'),
 ('iterator_call_throw','define',"return function(){trace+='M';throw token;};",True,'CRIMJ'),
 ('iterator_result_primitive','define',"return function(){trace+='M';return 3;};",False,'CRIMJ'),
 ('next_getter_throw','define',"return function(){trace+='M';return it;};",True,'CRIMGJ')]
for kind,define,body,identity,trace in variants:
 src="""var trace='',token={},seen,result={},out,gets=0,input={},it={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='BAD';};}});
Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';throw 'close must not run';}});
Object.defineProperty(it,'next',{get:function(){trace+='G';NEXT}});
DEFINE
out=Promise.race.call(C,input);
""".replace('NEXT',"throw token;" if kind=='next_getter_throw' else "return function(){trace+='BAD';return {done:true};};")
 src=src.replace('DEFINE',"Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';"+body+'}});' if define else '')
 reason='seen===token' if identity else 'seen instanceof TypeError'
 acq.append(row(kind,src,"trace+'|'+("+reason+")+'|'+gets+'|'+(out===result)",trace+'|true|0|true'))
group('acquisition_failure_never_closes',acq,'Only a successful next Get completes acquisition; even an existing iterator object does not authorize close after failed acquisition.')
steps=[]
for kind,next_body,is_identity,trace in [
 ('noncallable_next','return 0;',False,'CRIGJ'),
 ('throwing_next',"return function(){trace+='N';throw token;};",True,'CRIGNJ'),
 ('primitive_step',"return function(){trace+='N';return 0;};",False,'CRIGNJ'),
 ('throwing_done',"return function(){trace+='N';return {get done(){trace+='D';throw token;},get value(){trace+='BAD';}};};",True,'CRIGNDJ'),
 ('throwing_value',"return function(){trace+='N';return {get done(){trace+='D';return false;},get value(){trace+='V';throw token;}};};",True,'CRIGNDVJ')]:
 src="""var trace='',token={},seen,result={},out,gets=0,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='BAD';};}});
input[Symbol.iterator]=function(){trace+='I';return it;};
Object.defineProperty(it,'next',{get:function(){trace+='G';NEXT}});
Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';throw 'close must not run';}});
out=Promise.race.call(C,input);
""".replace('NEXT',next_body)
 reason='seen===token' if is_identity else 'seen instanceof TypeError'
 steps.append(row(kind,src,"trace+'|'+("+reason+")+'|'+gets+'|'+(out===result)",trace+'|true|0|true'))
group('step_failures_mark_done_without_close',steps,'Next callability/object checks and next/done/value errors all suppress close and preserve the appropriate rejection reason.')
close=[]
return_variants=[('absent','',0,0,''),('undefined','return undefined;',1,0,'X'),('null','return null;',1,0,'X'),('noncallable','return 0;',1,0,'X'),('getter_throw','throw closeToken;',1,0,'X'),('call_throw',"return function(){'use strict';receiver=receiver&&this===it;calls++;trace+='Y';throw closeToken;};",1,1,'XY'),('primitive_result',"return function(){'use strict';receiver=receiver&&this===it;calls++;trace+='Y';return 0;};",1,1,'XY'),('object_result',"return function(){'use strict';receiver=receiver&&this===it;calls++;trace+='Y';return {};};",1,1,'XY')]
stages=[('resolve_call',"throw token;",'CRINDVA'),('then_get',"return {get then(){trace+='G';throw token;}};",'CRINDVAG'),('then_call',"return {get then(){trace+='G';return function(){trace+='T';throw token;};}};",'CRINDVAGT')]
for stage,resolve_body,prefix in stages:
 for variant,return_body,get_count,call_count,suffix in return_variants:
  src="""var trace='',token={},closeToken={},seen,result={},out,gets=0,calls=0,rejects=0,receiver=true,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){'use strict';receiver=receiver&&this===undefined;rejects++;trace+='J';seen=e;});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='A';RESOLVE};}});
input[Symbol.iterator]=function(){trace+='I';return it;};
it.next=function(){trace+='N';return {get done(){trace+='D';return false;},get value(){trace+='V';return 1;}};};
RETURN
out=Promise.race.call(C,input);
""".replace('RESOLVE',resolve_body).replace('RETURN',"Object.defineProperty(it,'return',{get:function(){gets++;trace+='X';"+return_body+'}});' if variant!='absent' else '')
  close.append(row(stage+'__'+variant,src,"trace+'|'+(seen===token)+'|'+gets+'|'+calls+'|'+rejects+'|'+receiver+'|'+(out===result)",prefix+suffix+'J|true|'+str(get_count)+'|'+str(call_count)+'|1|true|true'))
group('post_yield_failures_close_preserving_original_reason',close,'Three ordinary post-yield throw sites crossed with eight return variants; original throw wins over ordinary close failures and exactly one reject follows.')
group('primitive_then_uses_getv_and_original_receiver',[row('number_receiver',r'''
var trace='',result={},out,receiver=false,identities=false,ignored=0;
function resolve(v){trace+='F'+v;}
function reject(v){trace+='J'+v;}
function C(executor){executor(resolve,reject);return result;}
C.resolve=function(){return 7;};
Object.defineProperty(Number.prototype,'then',{configurable:true,value:function(f,j){'use strict';receiver=this===7;identities=f===resolve&&j===reject&&arguments.length===2;f(9);j(10);return {get then(){ignored++;throw 'ignored then return';}};}});
out=Promise.race.call(C,[1]);delete Number.prototype.then;
''',"trace+'|'+receiver+'|'+identities+'|'+ignored+'|'+(out===result)",'F9J10|true|true|0|true')],'No object-only restriction on resolve result; then return is ignored.')
group('resolve_then_throw_obeys_capability_behavior',[
row('custom_callbacks',r'''
var trace='',token={},seen,result={},out,closed=0,it={},input={};
function C(executor){executor(function(v){trace+='F'+v;},function(e){trace+='J';seen=e;});return result;}
C.resolve=function(){return {then:function(f){f(7);throw token;}};};
it.next=function(){return {done:false,value:1};};it.return=function(){closed++;return {};};
input[Symbol.iterator]=function(){return it;};out=Promise.race.call(C,input);
''',"trace+'|'+(seen===token)+'|'+closed+'|'+(out===result)",'F7J|true|1|true'),
row('intrinsic_first_settlement',r'''
var trace='',token={},closed=0,it={},input={},original=Promise.resolve;
Promise.resolve=function(){return {then:function(f){f(7);throw token;}};};
it.next=function(){return {done:false,value:1};};it.return=function(){closed++;return {};};
input[Symbol.iterator]=function(){return it;};var result=Promise.race(input);
Promise.resolve=original;
result.then(function(v){trace+='W'+v;},function(){trace+='BAD';});
''',"trace+'|'+closed",'W7|1')], 'Race does not suppress the reject attempt after then throws; native first settlement and custom repeated callback behavior remain distinct.')
group('custom_reject_throw_escapes_once',[row('reject_throw',r'''
var trace='',token={},replacement={},seen=false,caught=false,closed=0,rejects=0,it={},input={};
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(e){rejects++;trace+='J';seen=e===token;throw replacement;});}
C.resolve=function(){trace+='A';throw token;};
it.next=function(){trace+='N';return {done:false,value:1};};it.return=function(){closed++;trace+='R';return {};};
input[Symbol.iterator]=function(){trace+='I';return it;};
try{Promise.race.call(C,input);}catch(e){caught=e===replacement;trace+='E';}
''',"trace+'|'+seen+'|'+caught+'|'+closed+'|'+rejects",'CINARJE|true|true|1|1')], 'Close precedes reject, and an abrupt custom reject escapes without another close or rejection call.')
group('saved_callbacks_preserve_identity_repetition_returns_and_throw',[row('saved',r'''
var trace='',token={},caught=false,result={},out,f,j,returns=[];
function resolve(v){trace+='F'+v;if(v===4)throw token;return v+100;}
function reject(v){trace+='J'+v;return v+200;}
function C(executor){executor(resolve,reject);return result;}
C.resolve=function(v){return v;};
out=Promise.race.call(C,[{then:function(a,b){f=a;j=b;}}]);
returns.push(f(1));returns.push(f(2));returns.push(j(3));try{f(4);}catch(e){caught=e===token;}
''',"trace+'|'+returns.join(',')+'|'+caught+'|'+(f===resolve&&j===reject)+'|'+(out===result)",'F1F2J3F4|101,102,203|true|true|true')], 'No race-generated wrapper changes callback return, throw, repeated calls or function identity.')
group('nested_race_keeps_outer_iterator_and_capability_independent',[row('nested',r'''
var trace='',outer={},inner={},out,bad=false;
function outerResolve(v){trace+='F'+v;}
function innerResolve(v){trace+='d'+v;}
function reject(){bad=true;}
function C(executor){trace+='C';executor(outerResolve,reject);return outer;}
function D(executor){trace+='D';executor(innerResolve,reject);return inner;}
D.resolve=function(v){trace+='B'+v;return {then:function(f,j){if(f!==innerResolve||j!==reject)bad=true;trace+='U';f(v);}};};
C.resolve=function(v){trace+='A'+v;if(v===1&&Promise.race.call(D,[9])!==inner)bad=true;return {then:function(f,j){if(f!==outerResolve||j!==reject)bad=true;trace+='T';f(v);}};};
out=Promise.race.call(C,[1,2]);
''',"trace+'|'+bad+'|'+(out===outer)",'CA1DB9Ud9TF1A2TF2|false|true')], 'Nested author execution occurs between outer resolve and then; local iterator and callback identities resume correctly.')
assert len(groups)==11
rows=sum(len(g['rows']) for g in groups);assert rows==49,rows
payload={'status':'source-only executable oracle hold; no execution or production','base':'781d012242374c2b4cb8c3b7a50c0b908e4309fa','fixture_contract':{'helper':'Existing promise_all_semantic_tests.rs observe: fresh Runtime per strict/sloppy mode, execute source and drain host checkpoint, then execute observation and compare exact typed Value.','required_source_prefix':"if(typeof Promise.race!=='function')throw new Error('Promise.race missing');\n",'reason':'Apply to every row before source. Prevent expected-TypeError cases from accidentally passing on the parent because race is undefined. This is a fixture prerequisite, not a new engine guard.','runtime_calls':'Existing Runtime::try_new,execute/execute_strict and Document::parse only; no new private APIs.','modes':['sloppy','strict'],'parent_prediction':'All11 groups fail at first sloppy row prerequisite while race is absent; later rows/modes are planned coverage, not predicted observed parent results.'},'groups':groups,'counts':{'groups':11,'rows':rows,'planned_modes':2*rows},'scope':'Ordinary metadata/errors, generic callback behavior and one reentrant call only. Resource/fatal cuts are separate Script-owned work. Original six successful source cases remain immutable in the first hold.'}
(P/'oracles.json').write_text(json.dumps(payload,indent=2)+'\n')
# Bind every source as a standalone draft JS artifact, with a separate readback expression.
for g in groups:
 for r in g['rows']:
  d=P/'sources'/g['id'];d.mkdir(parents=True,exist_ok=True)
  (d/(r['id']+'.js')).write_text(payload['fixture_contract']['required_source_prefix']+r['source']+'\n')
  (d/(r['id']+'.observation.js')).write_text(r['observation']+'\n')
print('wrote',len(groups),'groups',rows,'rows',2*rows,'modes')
