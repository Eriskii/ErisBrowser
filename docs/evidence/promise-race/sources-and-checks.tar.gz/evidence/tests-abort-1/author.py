from pathlib import Path
import re,json,hashlib,difflib
P=Path('/tmp/eris-promise-race-1/tests-abort-1');W=Path('/tmp/eris-promise-race-1/worktree')
s=(W/'src/script/promise_all_abort_tests.rs').read_text()
def h(b):return hashlib.sha256(b).hexdigest()
def put(name,d):
 f=P/name;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(json.dumps(d,indent=2)+'\n')
execute=s[s.index('fn execute_mode('):s.index('#[test]')].rstrip()
fatal=s[s.index('fn fatal_stop('):s.index('#[test]',s.index('fn fatal_stop('))].rstrip()
blocks={}
for part in re.split(r'(?=^#\[test\])',s,flags=re.M):
 m=re.match(r'#\[test\]\nfn (\w+)\(',part)
 if m:blocks[m.group(1)]=part.rstrip()
selected=[('next','N|0|0|0|0|false'),('resolve','NR|0|0|0|0|false'),('then_call','NRGT|0|0|0|0|false'),('return_get','NRGTC|0|0|1|0|false'),('return_call','NRGTCX|0|0|1|1|false')]
rows=[]
for unsupported,stop in [(False,'while(true){}'),(True,"eval('0');")]:
 source="var trace='',after=false,resolves=0,rejects=0,returnGets=0,returnCalls=0,marker={};function C(executor){executor(function(){resolves++;trace+='A';},function(){rejects++;trace+='J';});}C.resolve=function(x){trace+='R';return {get then(){trace+='G';return function(){trace+='T';};}};};var it={next:function(){trace+='N';return {done:false,value:1};}};Object.defineProperty(it,'return',{get:function(){returnGets++;trace+='C';return function(){returnCalls++;trace+='X';return {};};}});var src={};Object.defineProperty(src,Symbol.iterator,{get:function(){trace+='I';"+stop+"return function(){trace+='M';return it;};}});queueMicrotask(function(){trace+='Q';});Promise.race.call(C,src);after=true;"
 rows.append({'case_id':'fatal_acquisition_'+('unsupported' if unsupported else 'resource'),'unsupported':unsupported,'source':source})
groups=[{'test':'promise_race_fatal_acquisition_stops_before_later_author_callbacks','boundary':'iterator method getter during acquisition','cases':rows,'expected':'I|0|0|0|0|false','basis':'New boundary; existing all fixtures supply identical callback/counter/sentinel structure.'}]
for name,expected in selected:
 old='promise_all_fatal_'+name+'_stops_before_later_author_callbacks';block=blocks[old]
 sources=re.findall(r'r###"(.*?)"###',block,re.S);assert len(sources)==2
 groups.append({'test':old.replace('promise_all_','promise_race_'),'boundary':name,'cases':[{'case_id':'fatal_'+name+'_'+kind,'unsupported':bool(i),'source':source.replace('Promise.all.call(C,src)','Promise.race.call(C,src)')} for i,(kind,source) in enumerate(zip(['resource','unsupported'],sources))],'expected':expected,'basis':{'path':'src/script/promise_all_abort_tests.rs','test':old,'source_delta':'Only Promise.all.call→Promise.race.call in each exact held JavaScript literal.'}})
observation="[trace,resolves,rejects,returnGets,returnCalls,after].join('|')"
oracle={'status':'frozen before candidate implementation; no execution','groups':groups,'observation':observation,'counts':{'groups':6,'source_literals':12,'failure_classes':['ResourceLimit','Unsupported'],'strict_modes':[False,True],'planned_attempts':24,'post_failure_readbacks_per_attempt':2,'planned_readbacks':48},'expected_fatal_classes':'is_unsupported==literal; is_resource_limit==!literal. Terminal class must supersede the ordinary marker in both return groups.','sentinel':'queueMicrotask Q is enqueued before race. No selected trace contains Q; the two later execute entries must not revive it.','scope':'No ordinary abort sentinel case and no duplicated fatal then-getter group; six selected boundaries only.','budget_policy':'No direct steps/allocated/call/queue counter writes. Each fatal operation runs in one author execute entry. Later ordinary observation entries use existing public execute reset behavior only after terminal completion; suspension must remain sticky and never resume the queued sentinel.','parent_prediction':'All6 groups compile with existing APIs but fail first ResourceLimit classification on the first sloppy row because race is absent. Later Unsupported/mode/readback paths are planned, not claimed parent observations.'}
put('oracle.json',oracle)
parts=['//! Promise.race terminal boundaries using the existing Promise.all abort policy.\n//! Existing APIs only; no in-operation budget reset or iteration-count oracle.\nuse super::*;\n',execute,fatal]
for g in groups:
 body='#[test]\nfn '+g['test']+'() {\n    fatal_stop(\n        [\n'
 for c in g['cases']:
  body+='            (\n                "'+c['case_id']+'",\n                '+str(c['unsupported']).lower()+',\n                r###"'+c['source']+'"###,\n            ),\n'
 body+='        ],\n        "'+g['expected']+'",\n    );\n}'
 parts.append(body)
raw='\n\n'.join(parts)+'\n';f=P/'raw/src/script/promise_race_abort_tests.rs';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(raw)
assert len(re.findall(r'^#\[test\]',raw,re.M))==6
before=(W/'src/script.rs').read_text();needle='#[cfg(test)]\nmod promise_race_semantic_tests;';assert before.count(needle)==1
reg=before.replace(needle,needle+'\n#[cfg(test)]\nmod promise_race_abort_tests;')
for stem,text in [('before',before),('raw-registration',reg)]:
 f=P/stem/'src/script.rs';f.parent.mkdir(parents=True,exist_ok=True);f.write_text(text)
patch=''.join(difflib.unified_diff(before.splitlines(True),reg.splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs'))
(P/'registration.patch').write_text(patch)
put('source-bindings.json',{'base':'781d012242374c2b4cb8c3b7a50c0b908e4309fa','source_files':[{'path':r,'sha256':h((W/r).read_bytes()),'bytes':(W/r).stat().st_size}for r in ['src/script/promise_all_abort_tests.rs','src/script.rs','src/script/promises/all_semantics.rs','src/script/array_from.rs','src/script/microtasks.rs']],'selection':{'path':'/tmp/eris-promise-race-1/root/selection-2.json','sha256':h(Path('/tmp/eris-promise-race-1/root/selection-2.json').read_bytes())},'registration_baseline':'Published implementation plus imported first six public semantic tests registration; preserve it and append one cfg(test) module only.','helper_proof':'execute_mode and fatal_stop copied byte-exact from existing all abort module; no fee/microtask/Runtime mutation helper added.'})
put('roster.json',{'tests':[g['test']for g in groups],'cases':[{'test':g['test'],'case_id':c['case_id'],'source_sha256':h(c['source'].encode()),'expected':g['expected'],'unsupported':c['unsupported']}for g in groups for c in g['cases']]})
put('import.json',{'new_test_file':{'from':'raw/src/script/promise_race_abort_tests.rs','to':'src/script/promise_race_abort_tests.rs'},'registration':'Apply registration.patch against bound before/src/script.rs or insert identical cfg(test) registration after promise_race_semantic_tests if root composition has since advanced; verify exact two added lines and do not overwrite unrelated registrations.','expected_root_filter':'promise_race_fatal_','parent_compatible':True,'parent_failure':'ResourceLimit assertion mismatch caused by absent Promise.race, before Unsupported/strict/readback rows are reached. Preserve the actual observation scope.'})
files=[P/x for x in ['oracle.json','source-bindings.json','roster.json','import.json','registration.patch','raw/src/script/promise_race_abort_tests.rs','before/src/script.rs','raw-registration/src/script.rs']]
put('source-ready.json',{'status':'source_ready_for_independent_peer_and_parent_baseline','scope':'6 groups/12 source literals/24 planned strict-mode attempts and48 post-failure readbacks; terminal public controls only. No production, live edits, Rust formatting/compiler/engine/project execution.','files':[{'path':str(f.relative_to(P)),'sha256':h(f.read_bytes()),'bytes':f.stat().st_size}for f in files],'authoring_helper_excluded':'author.py','immutable_prior_holds':'Existing all abort source, original six race public groups and expanded ordinary oracle hold remain unchanged.'})
print('source-ready',h((P/'source-ready.json').read_bytes()))
