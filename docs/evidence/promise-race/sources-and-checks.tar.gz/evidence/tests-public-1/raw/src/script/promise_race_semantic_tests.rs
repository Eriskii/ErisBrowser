//! Frozen Promise.race public literals from the independently reviewed proposal.
//! Fresh Runtime per strict mode; source and post-drain observation are separate.
use super::*;

fn observe(case_id: &str, source: &str, expression: &str, expected: Value) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let result = if strict {
            runtime.execute_strict(source, &mut document)
        } else {
            runtime.execute(source, &mut document)
        };
        result.unwrap_or_else(|error| panic!("{case_id} strict={strict} source: {error:?}"));
        let observed = if strict {
            runtime.execute_strict(expression, &mut document)
        } else {
            runtime.execute(expression, &mut document)
        }
        .unwrap_or_else(|error| panic!("{case_id} strict={strict} observation: {error:?}"));
        assert_eq!(observed, expected, "{case_id} strict={strict}");
    }
}

#[test]
fn promise_race_fulfilled_fifo() {
    observe(
        "fulfilled_fifo",
        r###"var trace='S', winner;
Promise.race([Promise.resolve(7),Promise.resolve(9)]).then(function(v){winner=v;trace+='W'+v;});
Promise.resolve().then(function(){trace+='P';});
queueMicrotask(function(){trace+='Q';});
trace+='E';"###,
        r###"trace+'|'+(winner===7)"###,
        Value::String("SEPQW7|true".into()),
    );
}

#[test]
fn promise_race_thenable_vs_plain_value() {
    observe(
        "thenable_vs_plain_value",
        r###"var trace='S', winner;
var item={};
Object.defineProperty(item,'then',{get:function(){trace+='G';return function(resolve){trace+='T';resolve('t');};}});
Promise.race([item,'v']).then(function(v){winner=v;trace+='W'+v;});
queueMicrotask(function(){trace+='Q';});
trace+='E';"###,
        r###"trace+'|'+(winner==='v')"###,
        Value::String("SGETQWv|true".into()),
    );
}

#[test]
fn promise_race_intrinsic_empty_pending() {
    observe(
        "intrinsic_empty_pending",
        r###"var trace='S';
Promise.race([]).then(function(){trace+='BAD';},function(){trace+='BAD';});
queueMicrotask(function(){trace+='Q';});
trace+='E';"###,
        r###"trace"###,
        Value::String("SEQ".into()),
    );
}

#[test]
fn promise_race_rejection_identity_fifo() {
    observe(
        "rejection_identity_fifo",
        r###"var trace='S', token={}, same=false;
Promise.race([Promise.reject(token),Promise.resolve(9)]).then(function(){trace+='BAD';},function(e){same=e===token;trace+='R';});
queueMicrotask(function(){trace+='Q';});
trace+='E';"###,
        r###"trace+'|'+same"###,
        Value::String("SEQR|true".into()),
    );
}

#[test]
fn promise_race_generic_identity_cached_lookup_and_repeated_callbacks() {
    observe(
        "generic_identity_cached_lookup_and_repeated_callbacks",
        r###"var trace='',result={},bad=false,seen;
function resolve(v){trace+='F'+v;}
function reject(v){trace+='J'+v;}
function C(executor){trace+='C';executor(resolve,reject);return result;}
Object.defineProperty(C,Symbol.species,{get:function(){bad=true;throw 'species';}});
Object.defineProperty(C,'resolve',{configurable:true,get:function(){trace+='R';return function(v){
  if(this!==C)bad=true;
  trace+='A'+v;
  return {then:function(f,j){
    if(f!==resolve||j!==reject||arguments.length!==2)bad=true;
    trace+='T';f(v);f(v+10);j(v+20);
    Object.defineProperty(C,'resolve',{value:function(){bad=true;throw 'late resolve';}});
  }};
};}});
var index=0,iterator={};
Object.defineProperty(iterator,'next',{configurable:true,get:function(){trace+='N';return function(){
  if(this!==iterator)bad=true;
  trace+='X';var done=index===2,value=++index;
  Object.defineProperty(iterator,'next',{value:function(){bad=true;throw 'late next';}});
  var step={};
  Object.defineProperty(step,'done',{get:function(){trace+='D';return done;}});
  Object.defineProperty(step,'value',{get:function(){trace+='V';return value;}});
  return step;
};}});
var input={};
Object.defineProperty(input,Symbol.iterator,{get:function(){trace+='I';return function(){if(this!==input)bad=true;trace+='M';return iterator;};}});
seen=Promise.race.call(C,input);"###,
        r###"trace+'|'+(seen===result)+'|'+bad"###,
        Value::String("CRIMNXDVA1TF1F11J21XDVA2TF2F12J22XD|true|false".into()),
    );
}

#[test]
fn promise_race_generic_empty_returns_without_callback() {
    observe(
        "generic_empty_returns_without_callback",
        r###"var trace='',result={},seen;
function C(executor){trace+='C';executor(function(){trace+='BAD';},function(){trace+='BAD';});return result;}
Object.defineProperty(C,'resolve',{get:function(){trace+='R';return function(){trace+='BAD';};}});
var iterator={next:function(){trace+='N';return {done:true,get value(){trace+='BAD';}};}};
var input={};input[Symbol.iterator]=function(){trace+='I';return iterator;};
seen=Promise.race.call(C,input);"###,
        r###"trace+'|'+(seen===result)"###,
        Value::String("CRIN|true".into()),
    );
}
