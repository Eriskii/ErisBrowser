from pathlib import Path
import json,hashlib,difflib
H=Path('/tmp/eris-promise-race-1/production-1');W=Path('/tmp/eris-promise-race-1/worktree');M=json.loads((H/'source-ready.json').read_text());parent=json.loads(Path('/tmp/eris-promise-race-1/parent-source.json').read_text())['source_sha256']
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
checked=0
def verify(x):
 global checked
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   b=bind(Path(x['path']));assert (b['bytes'],b['sha256'])==(x['bytes'],x['sha256']),x['path'];checked+=1
  for y in x.values():verify(y)
 elif isinstance(x,list):
  for y in x:verify(y)
verify(M);verify(json.loads((H/'contracts.json').read_text()))
for f in M['files']:
 rel=f['relative'];before=Path(f['before']['path']).read_text();raw=Path(f['raw']['path']).read_text()
 assert f['before']['sha256']==parent[rel],rel
 d=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
 assert d==Path(f['diff']['path']).read_text()

def raw(rel):return (H/'raw'/rel).read_text()
def before(rel):return (H/'before'/rel).read_text()
r='src/script/promises/all_semantics.rs';s=raw(r);method=(H/'race-method.txt').read_text();assert s.count(method)==1
assert s.replace(method,'').replace('//! Observable Promise.all and Promise.race iteration over the realm\'s job machinery.','//! Observable Promise.all iteration over the realm\'s existing job machinery.')==before(r)
for rel,a,b in [
 ('src/script/promises.rs','pub(super) const METADATA_OBJECTS: usize = 10;','pub(super) const METADATA_OBJECTS: usize = 9;'),
 ('src/script/promises/semantics.rs','                "Promise.race" => self.promise_race(receiver, args, doc)?INVALID','')]:
 if '?INVALID' in a:continue
 assert raw(rel).replace(a,b)==before(rel)
r='src/script/promises/semantics.rs';line='                "Promise.race" => self.promise_race(receiver, args, doc),\n';assert raw(r).count(line)==1 and raw(r).replace(line,'')==before(r)
r='src/script/machine/calls.rs';line='                    | "Promise.race"\n';assert raw(r).count(line)==1 and raw(r).replace(line,'')==before(r)
r='src/script/promises/install.rs';s=raw(r)
changes=[
 ('all thirteen','all twelve'),('self.work(22)?;','self.work(21)?;'),('eleven pool releases','ten pool releases'),('self.work(20)?;','self.work(19)?;'),
 ('            self.dom_proto_text("race")?,\n',''),
 ('// 27 string keys, 9 display names, 1 prototype tag, 2 constructor handles.','// 24 string keys, 8 display names, 1 prototype tag, 2 constructor handles.'),
 ('self.work(39)?;','self.work(35)?;'),
 ('self.dom_proto_object(Some(Value::Function(self.function_prototype)), 8)?;','self.dom_proto_object(Some(Value::Function(self.function_prototype)), 7)?;'),
 ('        let race = self.promise_intrinsic_method("Promise.race", pool[12].clone(), 1, keys)?;\n',''),
 ('        self.dom_proto_property(\n            constructor_bag,\n            pool[12].clone().into(),\n            Property::data(race, true, false, true),\n        )?;\n','')]
for a,b in changes:assert s.count(a)==1,a;s=s.replace(a,b)
assert s==before(r)
# Bound unchanged inherited error/constructor/metadata implementations in the actual parent.
inherit=[]
for rel in ['src/script.rs','src/script/array_from.rs','src/script/construction.rs','src/script/promises/factories.rs','src/script/dom_prototypes.rs']:
 p=W/rel
 if bind(p)['sha256']!=parent[rel]:
  p=Path('/tmp/eris-promise-race-1/tests-private-1/source')/rel
 assert bind(p)['sha256']==parent[rel],rel
 inherit.append({'relative':rel,**bind(p)})
r={'status':'clear_source_only','reviewer':'script','scope':'Independent five-file production source peer against selected fixed17/installer121 and frozen private/public/migration contracts. No candidate execution, compilation, live edit or observed-layout claim.','bindings':[bind(H/'source-ready.json'),bind(H/'contracts.json'),bind(H/'preservation.json'),bind(H/'script-review-check.py'),bind(Path('/tmp/eris-promise-race-1/tests-private-1/html-review.json')),bind(Path('/tmp/eris-promise-race-1/migrations-before-1/html-review.json'))],'checks':{'bound_artifacts_verified':checked,'five_before_files_join_published_parent':True,'five_diffs_reconstructed_exactly':True,'existing_all_and_helpers':'Removing exactly race-method.txt and restoring module header recovers full old all_semantics.rs; AllIterator, terminal, all_iterator_step, resolve_all_ready and Promise.all are unchanged.','state':'Only METADATA_OBJECTS9->10; no arena, callback/job type, Runtime/queue header, cap or limit changes.','installer_work':{'delta':121,'rows':[9,16,24,20,4,1,45,2],'meanings':['method bag','race text','length/name properties','Promise.race Native','four handle copies','pool release','constructor race insertion','shifted species insertion'],'standalone':1383,'shared':1345,'producer_plus_shared':1676,'raw':99846,'raw_remaining':154},'installer_heap':{'helper_delta':'A+D+3K+Bpp+N+1020','full_bootstrap_delta':'O+A+D+3K+Bpp+N+1020','symbols':'A=sizeof(Option<AbortSlot>),D=sizeof(Option<f64>),K=sizeof(PropertyKey),N=sizeof(Native),O=sizeof(ScriptObject),Bpp=16*(K+sizeof(Property))+32*sizeof(usize)+64','literal_rows':[72,80,280,272,44,272],'fixed_literal_sum':1020,'no_state_delta':True},'installer_order':'New race bag is allocated after all, preserving old IDs; constructor race property follows all and precedes species. Public descriptor writable/configurable/nonenumerable, name race, arity1, Function prototype. Guards unchanged; standalone guard still precedes key allocation. Final global/cache publication tail exact.','dispatch_and_construction':'Only race arm added to Native dynamic-receiver dispatch and public8 wrapper. Method Native uses Undefined stored receiver, remains outside constructor whitelist, and has no prototype property; original Promise constructor and all routing unchanged.','entry_and_retention':'Body17 before retained owners. Entry clones each prepaid1. Per-value2 before cached resolve+C clones;3 before retained nextPromise Get receiver and later shared resolve/reject clones. Existing N1/N2 helpers prepay their own vector/storage cleanup; no new unfunded clone or allocation seam.','observable_algorithm':'NPC precedes resolve lookup; cached resolve precedes iterator acquisition; acquired next cached once. Step done/error flags use unchanged helper. Same resolve/reject Values passed to every then, original nextPromise receiver retained; no per-element wrapper, collection, short circuit after callback settlement, or exhausted-input resolve.','abrupt_paths':'NPC failures escape directly. Post-acquisition ordinary failures close iff not done, preserving pending thrown identity over ordinary return failures. Terminal failures bypass close/reject; terminal close error remains fatal through unchanged exception_value. Reject uses undefined receiver and an abrupt reject escapes exactly once.','private_control_fit':'Direct invalid-constructor20/public28 and warm/cold executor146/162 plus N1+10 cut provenance match implementation. Generic path creates only existing capability executor/capture; no all-specific storage. Direct-helper observation qualification preserved.','separate_registration':'Production contains no test edits/registration; root composes the frozen private append separately.','limits':'Direct-handle cleanup credits retain the inherited graph teardown qualification; no full author invocation, RSS/native-stack or conformance claim.'},'inherited_source_bindings':inherit,'findings':[]}
assert sum(r['checks']['installer_work']['rows'])==121
assert sum(r['checks']['installer_heap']['literal_rows'])==1020
p=H/'script-review.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(bind(p)))
