from pathlib import Path
import json,hashlib,difflib
P=Path('/tmp/eris-promise-race-1/production-1');W=Path('/tmp/eris-promise-race-1/worktree')
paths=['src/script/promises/all_semantics.rs','src/script/promises.rs','src/script/promises/install.rs','src/script/promises/semantics.rs','src/script/machine/calls.rs']
base={r:(W/r).read_text() for r in paths}
for r,s in base.items():
 f=P/'before'/r;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists();f.write_text(s)
raw=dict(base)
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
r='src/script/promises.rs';raw[r]=once(raw[r],'pub(super) const METADATA_OBJECTS: usize = 9;','pub(super) const METADATA_OBJECTS: usize = 10;')
r='src/script/promises/install.rs';s=raw[r]
s=once(s,'// Preserve standalone guard-before-allocation ordering and all twelve','// Preserve standalone guard-before-allocation ordering and all thirteen')
s=once(s,'self.work(21)?;','self.work(22)?;')
s=once(s,'// refusal of this debit. Pay guards, publication and ten pool releases.','// refusal of this debit. Pay guards, publication and eleven pool releases.')
s=once(s,'self.work(19)?;','self.work(20)?;')
s=once(s,'            self.dom_proto_text("all")?,','            self.dom_proto_text("all")?,\n            self.dom_proto_text("race")?,')
s=once(s,'// 24 string keys, 8 display names, 1 prototype tag, 2 constructor handles.','// 27 string keys, 9 display names, 1 prototype tag, 2 constructor handles.')
s=once(s,'self.work(35)?;','self.work(39)?;')
s=once(s,'self.dom_proto_object(Some(Value::Function(self.function_prototype)), 7)?;','self.dom_proto_object(Some(Value::Function(self.function_prototype)), 8)?;')
s=once(s,'        let all = self.promise_intrinsic_method("Promise.all", pool[11].clone(), 1, keys)?;','        let all = self.promise_intrinsic_method("Promise.all", pool[11].clone(), 1, keys)?;\n        let race = self.promise_intrinsic_method("Promise.race", pool[12].clone(), 1, keys)?;')
needle='''        self.dom_proto_property(
            constructor_bag,
            species,
'''
s=once(s,needle,'''        self.dom_proto_property(
            constructor_bag,
            pool[12].clone().into(),
            Property::data(race, true, false, true),
        )?;
'''+needle)
raw[r]=s
r='src/script/promises/semantics.rs';raw[r]=once(raw[r],'                "Promise.all" => self.promise_all(receiver, args, doc),','                "Promise.all" => self.promise_all(receiver, args, doc),\n                "Promise.race" => self.promise_race(receiver, args, doc),')
r='src/script/machine/calls.rs';raw[r]=once(raw[r],'                    | "Promise.all"','                    | "Promise.all"\n                    | "Promise.race"')
r='src/script/promises/all_semantics.rs';s=raw[r]
s=once(s,"//! Observable Promise.all iteration over the realm's existing job machinery.","//! Observable Promise.all and Promise.race iteration over the realm's job machinery.")
method='''    pub(super) fn promise_race(
        &mut self,
        constructor: Value,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        // Eight units for orchestration, nine for outer handle cleanup.
        // Unlike all, race retains resolve without transferring it to a Group.
        self.work(17)?;
        self.work(1)?;
        let Capability {
            promise,
            resolve,
            reject,
        } = self.new_promise_capability(constructor.clone(), doc)?;
        let mut iterator = None;
        let result = (|| {
            self.work(1)?;
            let promise_resolve = self.promise_named_get(constructor.clone(), "resolve", doc)?;
            if !json_callable(&promise_resolve) {
                return Err(ScriptError::type_error("Promise resolve is not callable"));
            }
            self.work(1)?;
            let items = args.first().cloned().unwrap_or(Value::Undefined);
            let method = self
                .array_from_iterator_method(&items, doc)?
                .ok_or_else(|| ScriptError::type_error("Promise.race input is not iterable"))?;
            let object = self.call(method, Vec::new(), items, doc)?;
            if !js_object(&object) {
                return Err(ScriptError::type_error("iterator is not an object"));
            }
            self.work(1)?;
            let next = self.promise_named_get(object.clone(), "next", doc)?;
            iterator = Some(AllIterator {
                iterator: object,
                next,
                done: false,
            });
            let record = iterator.as_mut().expect("acquired iterator record");
            loop {
                let Some(value) = self.all_iterator_step(record, doc)? else {
                    // Empty/exhausted input does not itself settle the capability.
                    return Ok(());
                };
                self.work(2)?;
                let arguments = self.promise_arguments([value])?;
                let next_promise =
                    self.call(promise_resolve.clone(), arguments, constructor.clone(), doc)?;
                // Retain the Get receiver and both shared capability callbacks.
                // No per-element wrapper or early-settlement check is introduced.
                self.work(3)?;
                let then = self.promise_named_get(next_promise.clone(), "then", doc)?;
                let arguments = self.promise_arguments([resolve.clone(), reject.clone()])?;
                self.call(then, arguments, next_promise, doc)?;
            }
        })();
        if let Err(mut error) = result {
            if terminal(&error) {
                return Err(error);
            }
            if let Some(record) = iterator.as_ref().filter(|record| !record.done) {
                error = self.array_from_close(&record.iterator, error, doc);
            }
            let reason = self.exception_value(error)?;
            let arguments = self.promise_arguments([reason])?;
            self.call(reject, arguments, Value::Undefined, doc)?;
        }
        Ok(promise)
    }

'''
s=once(s,'    fn all_iterator_step(\n',method+'    fn all_iterator_step(\n');raw[r]=s
for r,s in raw.items():
 f=P/'raw'/r;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
 f=P/'diffs'/(r+'.patch');f.parent.mkdir(parents=True,exist_ok=True)
 f.write_text(''.join(difflib.unified_diff(base[r].splitlines(True),s.splitlines(True),fromfile='a/'+r,tofile='b/'+r)))
# Exact preservation proof: remove only the new method and restore module header.
restored=raw['src/script/promises/all_semantics.rs'].replace(method,'',1).replace("//! Observable Promise.all and Promise.race iteration over the realm's job machinery.","//! Observable Promise.all iteration over the realm's existing job machinery.",1)
assert restored==base['src/script/promises/all_semantics.rs']
(P/'race-method.txt').write_text(method)
print('drafted five production paths; existing all source exact after selected inverse')
