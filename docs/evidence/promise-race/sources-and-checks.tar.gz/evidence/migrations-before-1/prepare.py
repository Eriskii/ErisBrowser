from pathlib import Path
import json, hashlib, difflib, re
H=Path('/tmp/eris-promise-race-1/migrations-before-1'); W=Path('/tmp/eris-promise-race-1/worktree')
def bind(p):
 b=p.read_bytes(); return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def replace(s,a,b,n=1):
 assert s.count(a)==n,(a,s.count(a),n)
 return s.replace(a,b)
changes=[]
def save(rel,s,reason,groups):
 before=(W/rel).read_text(); assert s!=before
 bp=H/'before'/rel; rp=H/'raw'/rel; dp=H/'diffs'/(rel+'.patch')
 for p in [bp,rp,dp]: p.parent.mkdir(parents=True,exist_ok=True)
 bp.write_text(before); rp.write_text(s); dp.write_text(''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 changes.append({'relative':rel,'before':bind(bp),'raw':bind(rp),'diff':bind(dp),'reason':reason,'affected_groups':groups})
def read(r):return (W/r).read_text()
r='src/script/bootstrap_tests.rs';s=read(r)
s=replace(s,'    assert_eq!(reference.steps, 275);','    // Promise.race adds121 metadata work and one reserved bag, with no new arena.\n    assert_eq!(reference.steps, 154);')
s=replace(s,'assert_eq!(reference.objects.len(), 750);','assert_eq!(reference.objects.len(), 751);')
save(r,s,'Exact raw remaining and eager object count only; public budget reset and historic accounting stay exact.',1)
r='src/script/typed_array/tests.rs';s=read(r)
s=replace(s,'    let all_added = s + a + d + 3 * k + bpp + n + 1011;','    let all_added = s + a + d + 3 * k + bpp + n + 1011;\n    // Race adds one method and no State header.\n    let race_added = s + a + d + 3 * k + bpp + n + 1020;')
s=replace(s,'            + 250\n','            + 250\n            - 121\n')
s=replace(s,'            - 1512\n','            - 1512\n            + race_added\n')
s=replace(s,'        (750, 750)','        (751, 751)')
save(r,s,'Add exactly121 work and O+A+D+3K+Bpp+N+1020 heap; current State size is not charged again.',1)
r='src/script/processing_instruction/key_cache_tests.rs';s=read(r)
s=replace(s,'frozen_99725_work_boundary','frozen_99846_work_boundary')
s=replace(s,'[(99_724, false, 0), (99_725, true, 0), (100_000, true, 275)]','[(99_845, false, 0), (99_846, true, 0), (100_000, true, 154)]')
s=replace(s,'assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);')
save(r,s,'Current raw boundary label and exact/one-short/full rows only; isolated PI fees unchanged.',1)
for r in ['src/script/dom_bindings/identity_tests.rs','src/script/node_data/key_cache_tests.rs','src/script/node_data/method_key_tests.rs']:
 s=replace(read(r),'assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);')
 save(r,s,'Aggregate eager object count only; prior identity, order and operation assertions unchanged.',1)
r='src/script/node_data/key_cache_fee_tests.rs';s=replace(read(r),'        (750, 750)','        (751, 751)',2)
save(r,s,'Two full-arena count/capacity observations only; isolated98/104/503/90 and original127/126 remain exact.',1)
r='src/script/test262_host/quota_tests.rs';s=read(r)
s=replace(s,'assert_eq!(runtime.steps, 275);','assert_eq!(runtime.steps, 154);')
s=replace(s,'assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);')
save(r,s,'Raw startup witness only. Generic object_plan(750,750)/(750,752) examples and all host operation fees unchanged.',1)
r='src/script/promise_semantic_tests.rs';s=replace(read(r),"'length,name,prototype,resolve,reject,all'","'length,name,prototype,resolve,reject,all,race'")
save(r,s,'Complete constructor own-name membership gains race only; foundation four-method/refused4 matrix unchanged.',1)
r='src/script/promises/install_tests.rs';s=read(r)
for a,b,n in [
 ('the nine initial ScriptObject','the ten initial ScriptObject',1),
 ('9 * a + 9 * d + 26 * k + 9 * bpp + 8 * n + 4 * bsb + 9356','10 * a + 10 * d + 29 * k + 10 * bpp + 9 * n + 4 * bsb + 10376',1),
 ('assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);',1),
 ('reserve nine additional','reserve ten additional',1),
 ('try_reserve_exact(9)','try_reserve_exact(10)',1),
 ('runtime.objects.len() + 9','runtime.objects.len() + 10',1),
 ('exact1262_and_one_short1261','exact1383_and_one_short1382',1),
 ('[(1262, true), (1261, false)]','[(1383, true), (1382, false)]',1),
 ('runtime.steps = 1262;','runtime.steps = 1383;',1),
 ('assert_eq!(runtime.objects.len(), 759);','assert_eq!(runtime.objects.len(), 761);',2),
 ('raw99725','raw99846',1),
 ('[(99_724, false, 0), (99_725, true, 0), (100_000, true, 275)]','[(99_845, false, 0), (99_846, true, 0), (100_000, true, 154)]',1),
 ('(750, 750)','(751, 751)',1)]: s=replace(s,a,b,n)
save(r,s,'Three installer groups: +121 exact work and typed helper delta, one extra bag/reservation; publication/heap refusal/empty arenas unchanged.',3)
r='src/script/promises/shared_key_tests.rs';s=read(r)
for a,b,n in [
 ('9 * a + 9 * d + 26 * k + 9 * l + 8 * n + 4 * b + 9188','10 * a + 10 * d + 29 * k + 10 * l + 9 * n + 4 * b + 10208',1),
 ('assert_eq!(runtime.objects.len(), 751);','assert_eq!(runtime.objects.len(), 752);',3),
 ('assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);',1),
 ('try_reserve_exact(10)','try_reserve_exact(11)',1),
 ('capacity() >= 760','capacity() >= 762',1),
 ('assert_eq!(owner, 750);','assert_eq!(owner, 751);',1),
 ('exact1224','exact1345',1),
 ('(1224, bytes, true)','(1345, bytes, true)',1),
 ('(1223, bytes, false)','(1344, bytes, false)',1),
 ('(1224, bytes - 1, false)','(1345, bytes - 1, false)',1),
 ('assert_eq!(runtime.objects.len(), 760);','assert_eq!(runtime.objects.len(), 762);',1),
 ('exact1555','exact1676',1),
 ('(1555, bytes, true)','(1676, bytes, true)',1),
 ('(1554, bytes, false)','(1675, bytes, false)',1),
 ('(1555, bytes - 1, false)','(1676, bytes - 1, false)',1),
 ('migrated99724/99725/100000','migrated99845/99846/100000',1),
 ('runtime.objects.len(), 750 + added','runtime.objects.len(), 751 + added',1),
 ('runtime.objects[750].values.len()','runtime.objects[751].values.len()',1),
 ('if shared { 19 } else { 21 }','if shared { 20 } else { 22 }',1),
 ('(false, 21, 0),\n        (false, 40, 0),\n        (false, 41, 88),\n        (false, 56, 88),\n        (false, 57, 168),\n        (true, 19, 0),\n        (true, 40, 0),\n        (true, 41, 92),','(false, 22, 0),\n        (false, 41, 0),\n        (false, 42, 88),\n        (false, 57, 88),\n        (false, 58, 168),\n        (true, 20, 0),\n        (true, 41, 0),\n        (true, 42, 92),',1)]: s=replace(s,a,b,n)
save(r,s,'Six existing groups retain producer331, cleanup prefixes and eight invalid states; consumer/pair +121 and fixed pool cleanup +1, one new bag.',6)
r='src/script/promises/shared_key_identity_tests.rs';s=read(r)
for a,b,n in [
 ('all_nine_function_bags','all_ten_function_bags',1),
 ('assert_eq!(runtime.objects.len(), 750);','assert_eq!(runtime.objects.len(), 751);',1),
 ('assert_eq!(runtime.objects.capacity(), 750);','assert_eq!(runtime.objects.capacity(), 751);',1),
 ('[740, 741, 743, 744, 745, 746, 747, 748, 749]','[740, 741, 743, 744, 745, 746, 747, 748, 749, 750]',1),
 ('[740, 743, 744, 745, 746, 747, 748, 749]','[740, 743, 744, 745, 746, 747, 748, 749, 750]',1),
 ('runtime.objects[constructor].values.len(), 7','runtime.objects[constructor].values.len(), 8',1),
 ("[P.prototype.catch,'catch',1],[P.prototype.finally,'finally',1],[P.all,'all',1]];","[P.prototype.catch,'catch',1],[P.prototype.finally,'finally',1],[P.all,'all',1],[P.race,'race',1]];",1),
 ("'length,name,prototype,resolve,reject,all'","'length,name,prototype,resolve,reject,all,race'",1)]: s=replace(s,a,b,n)
save(r,s,'Complete sharing/metadata roster gains appended bag750/race; all prior IDs and mutation/SQV7 observations unchanged.',2)
assert len(changes)==12 and sum(c['affected_groups'] for c in changes)==20
(H/'selection.json').write_text(json.dumps({'status':'prospective_held_migrations_before_production','base':'781d012242374c2b4cb8c3b7a50c0b908e4309fa','paths':12,'mandatory_groups':20,'selection':changes,'unchanged':'All optional arbitrary host planner examples, caps, layouts, original producer/factory fees, eight invalid states, old bag IDs, and unrelated assertions. No execution or live edits.'},indent=2)+'\n')
manifest={'status':'source_ready_for_independent_review','scope':'Twelve exact old-test migrations affecting mandatory20 groups. No new test groups, production or execution.','selection':bind(H/'selection.json'),'bindings':[bind(Path('/tmp/eris-promise-race-1/parent-source.json')),bind(Path('/tmp/eris-promise-race-1/root/selection-1.json')),bind(Path('/tmp/eris-promise-race-1/install-audit-1/source-ready.json'))],'files':changes,'authoring_script':bind(H/'prepare.py')}
(H/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(bind(H/'source-ready.json')))
