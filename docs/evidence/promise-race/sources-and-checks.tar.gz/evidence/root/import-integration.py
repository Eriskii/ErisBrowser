import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-integration-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:assert bind(Path(v['path']))==v,v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
ready=json.loads((H/'source-ready.json').read_text());verify(ready)
peer=json.loads((H/'html-review.json').read_text());assert 'clear' in peer['status']
source=json.loads((A/'source-parent-public-1.json').read_text())
for p,h in source['source_sha256'].items():assert bind(W/p)['sha256']==h,p
r=ready['registration'];relative=r['relative'];assert (W/relative).read_bytes()==Path(r['before']['path']).read_bytes()
assert Path(r['raw']['path']).read_bytes()==(W/relative).read_bytes()+r['exact_append_utf8'].encode()
for row in ready['paths']:
 p=W/row['relative'];assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(Path(row['raw']['path']).read_bytes());source['source_sha256'][row['relative']]=bind(p)['sha256']
(W/relative).write_bytes(Path(r['raw']['path']).read_bytes());source['source_sha256'][relative]=bind(W/relative)['sha256']
source['scope']='Published AV with six public and two Page/worker race groups, registrations only; before production.'
source['source_sha256']=dict(sorted(source['source_sha256'].items()));assert len(source['source_sha256'])==1245
(A/'source-parent-integration-1.json').write_text(json.dumps(source,indent=2)+'\n')
(A/'root/integration-import.json').write_text(json.dumps({'status':'verified_import','hold':bind(H/'source-ready.json'),'peer':bind(H/'html-review.json'),'source':bind(A/'source-parent-integration-1.json')},indent=2)+'\n')
print('Imported two-route integration witness; parent source now1245 bound inputs.')
