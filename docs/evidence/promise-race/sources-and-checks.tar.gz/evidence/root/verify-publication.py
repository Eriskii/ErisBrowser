import hashlib,json,tarfile
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
summary=read(W/'docs/evidence/promise-race/summary.json')
archive=W/'docs/evidence/promise-race'/summary['archive']['path']
assert bind(archive)['bytes']==summary['archive']['bytes']
assert bind(archive)['sha256']==summary['archive']['sha256']
selection=read(A/'root/selection-final.json')
assert bind(A/'root/selection-final.json')==summary['selection']
with tarfile.open(archive,'r:gz') as tf:
 members=tf.getmembers();assert len(members)==len(summary['members'])
 for member,record in zip(members,summary['members']):
  assert member.isfile() and member.name==record['name'] and member.size==record['bytes']
  assert member.name.startswith(('sources/','evidence/'))
  assert not {'..','.'}&set(member.name.split('/'))
  data=tf.extractfile(member).read();assert hashlib.sha256(data).hexdigest()==record['sha256']
  assert bind(Path(record['path']))=={k:record[k] for k in ['path','bytes','sha256']}
source=read(A/'source-final.json');parent=read(A/'parent-source.json')
for name,digest in source['source_sha256'].items():assert bind(W/name)['sha256']==digest,name
changed={p:h for p,h in source['source_sha256'].items() if parent['source_sha256'].get(p)!=h}
assert changed==read(A/'evidence-source.json')['source_sha256']
assert len(changed)==summary['source_count']==26
assert len(source['source_sha256'])==1247
expected=sorted([*changed,'README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md',
                 'docs/promise-race.md',
                 'docs/evidence/promise-race/summary.json','docs/evidence/promise-race/sources-and-checks.tar.gz'])
assert len(expected)==32
out={'status':'verified','source':bind(A/'source-final.json'),'summary':bind(W/'docs/evidence/promise-race/summary.json'),
     'archive':bind(archive),'verified_archive_members':len(members),'full_build_inputs':1247,
     'changed_build_inputs':26,'expected_commit_paths':expected,
     'note':'Publication receipt is outside the immutable archive; archive members verified without extraction.'}
(A/'root/publication-verification.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'verified','members':len(members),'commit_paths':len(expected)}))
