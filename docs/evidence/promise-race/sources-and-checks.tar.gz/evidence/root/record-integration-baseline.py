import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
checks={}
for label in ['parent-page-1','parent-worker-1']:
 p=A/'validation'/f'{label}.json';r=json.loads(p.read_bytes());l=p.with_suffix('.log');s=l.read_text()
 assert r['exit']==101 and bind(l)['sha256']==r['sha256']
 assert 'pixel (2,2) actual=ff0000 expected=ffffff' in s
 assert 'test result: FAILED. 0 passed; 1 failed; 0 ignored;' in s
 checks[label]={'receipt':bind(p),'log':bind(l),'failed':1,'passed':0,'first_failure':'first enabled viewport pixels: (2,2) red rather than white'}
o={'status':'observed_expected_parent_failures','source':bind(A/'source-parent-integration-1.json'),'hold':bind(A/'tests-integration-1/source-ready.json'),'checks':checks,'qualification':'Both disabled initial/click/task checks completed at both widths. First enabled320 viewport pixel check failed because square remained at2 instead of6; later enabled title, hit, task, click and300-width assertions were unreached.'}
(A/'root/parent-integration-baseline.json').write_text(json.dumps(o,indent=2)+'\n')
