import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=A/'validation/parent-abort-2.json';v=json.loads(r.read_bytes());l=r.with_suffix('.log');s=l.read_text();assert v['exit']==101 and bind(l)['sha256']==v['sha256']
names=re.findall(r'^test (\S+) \.\.\. FAILED$',s,re.M);assert len(names)==len(set(names))==6
assert s.count('kind: Runtime("TypeError")')==6 and s.count('strict=false:')==6
out=dict(status='observed_expected_parent_failures',source=bind(A/'source-parent-abort-1.json'),hold=bind(A/'tests-abort-1/source-ready.json'),receipt=bind(r),log=bind(l),passed=0,failed=6,groups=sorted(names),qualification='All six groups stop at first sloppy ResourceLimit classification: absent race instead produces TypeError at .call access. Unsupported, strict and sticky readback rows are unreached. The earlier zero-selected-test attempt is retained separately and is not a baseline.')
(A/'root/parent-abort-baseline.json').write_text(json.dumps(out,indent=2)+'\n')
