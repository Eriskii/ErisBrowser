import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=set(v):assert bind(Path(v['path']))=={k:v[k] for k in ['path','bytes','sha256']},v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
s=json.loads((A/'source-parent-public-2.json').read_bytes())
for p,h in s['source_sha256'].items():assert bind(W/p)['sha256']==h,p
changes={};holds={}
for name in ['production-1','migrations-before-1']:
 H=A/name;r=json.loads((H/'source-ready.json').read_bytes());verify(r)
 peer=H/('script-review.json' if name=='production-1' else 'html-review.json');assert 'clear' in json.loads(peer.read_bytes())['status']
 holds[name]=dict(hold=bind(H/'source-ready.json'),peer=bind(peer))
 for f in r['files']:
  p=f['relative'];assert p not in changes;assert (W/p).read_bytes()==Path(f['before']['path']).read_bytes();changes[p]=Path(f['raw']['path']).read_bytes()
H=A/'tests-private-1';r=json.loads((H/'source-ready.json').read_bytes());verify(r);peer=H/'html-review.json';assert 'clear' in json.loads(peer.read_bytes())['status'];holds['tests-private-1']=dict(hold=bind(H/'source-ready.json'),peer=bind(peer))
f=r['module'];p=f['relative'];assert not (W/p).exists();changes[p]=Path(f['path']).read_bytes()
reg=json.loads(Path(r['registration']['path']).read_bytes());suffix=reg['suffix'].encode();assert hashlib.sha256(suffix).hexdigest()==reg['suffix_sha256'];p=reg['relative'];assert suffix not in changes[p];changes[p]+=suffix
for p,b in changes.items():
 (W/p).parent.mkdir(parents=True,exist_ok=True);(W/p).write_bytes(b);s['source_sha256'][p]=hashlib.sha256(b).hexdigest()
s['scope']='Selected Promise.race implementation, reviewed mandatory installer migrations and frozen public/fatal/private/integration tests, before formatting.';s['source_sha256']=dict(sorted(s['source_sha256'].items()));assert len(s['source_sha256'])==1247
parent=json.loads((A/'parent-source.json').read_bytes());changed={p:h for p,h in s['source_sha256'].items() if parent['source_sha256'].get(p)!=h};assert len(changed)==26,len(changed)
for p in changed:
 out=A/'unformatted'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes((W/p).read_bytes())
(A/'source-unformatted.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/candidate-import.json').write_text(json.dumps(dict(status='verified_composition',holds=holds,source=bind(A/'source-unformatted.json'),changed_build_inputs=sorted(changed),private_registration=reg),indent=2)+'\n')
print('Imported26 changed/new build inputs;1247 total; four private groups require candidate API.')
