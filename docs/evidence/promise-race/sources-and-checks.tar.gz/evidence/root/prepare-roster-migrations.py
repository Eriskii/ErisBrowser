import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];H=A/'migrations-before-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=json.loads((H/'source-ready.json').read_bytes());renames={};rows=[]
for f in r['files']:
 p=f['relative'];b=Path(f['before']['path']);a=Path(f['raw']['path']);assert bind(b)==f['before'];assert bind(a)==f['raw'];assert (A/'worktree'/p).read_bytes()==b.read_bytes()
 old=re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn (\w+)\(',b.read_text());new=re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn (\w+)\(',a.read_text());assert len(old)==len(new)
 for x,y in zip(old,new):
  if x!=y:
   prefix=p.removeprefix('src/').removesuffix('.rs').replace('/', '::')+'::';renames[prefix+x]=prefix+y
 rows.append(dict(relative=p,old_test_count=len(old),affected_groups=f['affected_groups']))
assert len(rows)==12 and sum(x['affected_groups'] for x in rows)==20
out=dict(status='source_reviewed_before_production',hold=bind(H/'source-ready.json'),peer=bind(H/'html-review.json'),paths=rows,renames=renames,scope='Mandatory installer accounting and complete metadata membership only. No caps or unrelated operation fees changed. Parent compile is available but new expectations intentionally describe the selected candidate startup; no parent outcome asserted.')
(A/'root/migration-review.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(renames,indent=2))
