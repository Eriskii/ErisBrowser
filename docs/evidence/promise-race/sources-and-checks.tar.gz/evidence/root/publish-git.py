import json,subprocess
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def git(directory,*args):return subprocess.check_output(['git','-C',str(directory),*args],text=True).strip()
v=json.loads((A/'root/publication-verification.json').read_bytes());assert v['status']=='verified'
base=json.loads((A/'source-final.json').read_bytes())['base'];assert git(W,'rev-parse','HEAD')==base;assert git(MAIN,'rev-parse','HEAD')==base
assert not git(MAIN,'status','--porcelain')
paths=v['expected_commit_paths'];tracked=set(git(W,'diff','--name-only').splitlines());untracked=set(git(W,'ls-files','--others','--exclude-standard').splitlines());assert tracked|untracked==set(paths),(tracked|untracked)^set(paths)
subprocess.run(['git','-C',str(W),'diff','--check'],check=True)
subprocess.run(['git','-C',str(W),'add','--',*paths],check=True)
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
body=A/'commit-message.txt';body.write_text('Implement generic Promise.race with shared capability callbacks\n\nAdd synchronous iterable racing through the existing Promise capability,\niterator and FIFO machinery. Preserve cached lookups, callback identities,\niterator close ordering and terminal resource policy without an all-style\ncollection arena. Account for the new intrinsic within unchanged limits.\n\nValidate 29 new regression groups, Page and confined-worker pixel/click\nchecks, full 3,084/3,438-test suites, strict Clippy and exact preservation\nof 654 existing Promise case modes plus 164 harness controls.\n')
subprocess.run(['git','-C',str(W),'commit','-F',str(body)],check=True)
commit=git(W,'rev-parse','HEAD');assert not git(W,'status','--porcelain')
subprocess.run(['git','-C',str(MAIN),'merge','--ff-only',commit],check=True)
subprocess.run(['git','-C',str(MAIN),'push','origin','main'],check=True)
assert git(MAIN,'rev-parse','HEAD')==commit and not git(MAIN,'status','--porcelain')
(A/'root/github-publication.json').write_text(json.dumps(dict(commit=commit,remote='https://github.com/Eriskii/ErisBrowser',push='success',ci_status='pending',note='Postpublication record intentionally outside immutable archive.'),indent=2)+'\n');print('Published '+commit)
