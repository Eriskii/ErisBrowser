import hashlib,json,shutil
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-public-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def verify(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:assert bind(Path(v['path']))==v,v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
ready=json.loads((H/'source-ready.json').read_text());verify(ready)
source=json.loads((A/'parent-source.json').read_text())
for relative,digest in source['source_sha256'].items():assert bind(W/relative)['sha256']==digest,relative
registration=ready['registration'];relative=registration['relative']
assert (W/relative).read_bytes()==Path(registration['before']['path']).read_bytes()
assert Path(registration['raw']['path']).read_bytes()==(W/relative).read_bytes()+registration['exact_append_utf8'].encode()
test=Path(ready['test_module']['path']);new=str(test.relative_to(H/'raw'));assert not (W/new).exists()
(W/new).write_bytes(test.read_bytes());(W/relative).write_bytes(Path(registration['raw']['path']).read_bytes())
for r in [new,relative]:source['source_sha256'][r]=bind(W/r)['sha256']
source['source_sha256']=dict(sorted(source['source_sha256'].items()));assert len(source['source_sha256'])==1241
source['scope']='Published AV plus six frozen Promise.race public ordering/identity groups, registration only; no production.'
(A/'source-parent-public-1.json').write_text(json.dumps(source,indent=2)+'\n')
(A/'root/public-import-1.json').write_text(json.dumps({'status':'verified_import','hold':bind(H/'source-ready.json'),'source':bind(A/'source-parent-public-1.json'),'test':bind(W/new),'registration':bind(W/relative)},indent=2)+'\n')
shutil.copyfile('/tmp/eris-promise-race-plan-1/html-semantic-review.json',A/'plans/html-semantic-review.json')
print('Imported six frozen public groups; bound1241 inputs before production.')
