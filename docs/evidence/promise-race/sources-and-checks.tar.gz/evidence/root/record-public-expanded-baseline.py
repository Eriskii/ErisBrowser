import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=A/'validation/parent-public-2.json';v=json.loads(r.read_bytes());l=r.with_suffix('.log');s=l.read_text();assert v['exit']==101 and bind(l)['sha256']==v['sha256']
names=re.findall(r'^test (\S+) \.\.\. FAILED$',s,re.M);assert len(names)==len(set(names))==17
failures=re.findall(r'^([^\n]+ strict=false source: ScriptError[^\n]+)$',s,re.M);assert len(failures)==17
out=dict(status='observed_expected_parent_failures',source=bind(A/'source-parent-public-2.json'),hold=bind(A/'tests-public-2/source-ready.json'),receipt=bind(r),log=bind(l),passed=0,failed=17,groups=sorted(names),first_failures=failures,qualification='Six original groups fail absent-method TypeError; eleven added groups fail their explicit missing-race prerequisite with Error. Each stops in the first sloppy source; subsequent rows/modes/observations remain unreached.')
assert s.count('intrinsic_name: Some("Error")')==11
(A/'root/parent-public-baseline-2.json').write_text(json.dumps(out,indent=2)+'\n')
