import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'documentation-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
v=json.loads((A/'root/final-validation.json').read_bytes());assert v['status']=='pass'
assert v['checks']['default-full-1']['passed']==3084 and v['checks']['host-vulkan-full-1']['passed']==3438
r=json.loads((H/'source-ready.json').read_bytes());written={}
for f in r['files']:
 p=W/f['relative'];raw=Path(f['raw']['path']);assert bind(raw)==f['raw']
 if f['before']:
  before=Path(f['before']['path']);assert bind(before)==f['before'] and p.read_bytes()==before.read_bytes()
 else:assert not p.exists()
 t=raw.read_text()
 if f['relative']=='docs/promise-race.md':
  replacements={
   'PENDING_RUST_VALIDATION':'''All **29 new regression groups pass**, including both Page and confined-worker
integrations. The complete suites pass **3,084 tests on Rust 1.88** and **3,438
with `test262-host,vulkan-raster` on Rust 1.99**, across 51 result rows each
with no failed, ignored or filtered tests. Strict Clippy passes for all targets
in both configurations; formatting also passes. The 17 ordinary public groups
cover 110 observations across sloppy and strict modes. The six terminal groups
cover 24 operations and 48 sticky readbacks; the four private groups cover
28 operations.
Twenty existing groups receive the reviewed metadata/accounting updates;
no frozen new expectation was changed. Before implementation, all 17 public,
six terminal and two integration groups failed at their documented first
missing-method boundary. Private helper tests require the new implementation.''',
   'PENDING_PRESERVATION_REPLAYS':'''The release adapter preserves all **654 case-mode and 164 harness records**
from the existing Promise profiles: `Promise.all` remains 174 passed, 14 failed
and 8 unsupported out of 196; the earlier profile remains 420 passed, 8 failed
and 30 unsupported out of 458. All 164 harness controls pass. These checks preserve
existing outcomes; they are not a new `Promise.race` conformance result.''',
   'PENDING_EVIDENCE':'''[Source and validation evidence](evidence/promise-race/summary.json) binds the
complete build inventory, changed inputs, frozen contracts, parent observations,
review receipts and final logs. Its adjacent archive contains the selected
sources and checks; compiled binaries are excluded.'''}
  for key,value in replacements.items():
   t,n=re.subn(r'\['+key+r':[^\]]*\]',lambda _:value,t);assert n==1,key
  assert 'PENDING_' not in t
 p.write_text(t);written[f['relative']]=bind(p)
(A/'root/documentation-final.json').write_text(json.dumps(dict(status='filled_from_validated_results',draft=bind(H/'source-ready.json'),validation=bind(A/'root/final-validation.json'),files=written),indent=2)+'\n')
