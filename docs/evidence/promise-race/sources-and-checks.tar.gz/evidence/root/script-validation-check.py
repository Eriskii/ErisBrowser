from pathlib import Path
import json,hashlib,re,collections
A=Path('/tmp/eris-promise-race-1');P=Path('/tmp/eris-expression-in-1');W=A/'worktree'
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
verified=0
def verify(x):
 global verified
 if isinstance(x,dict):
  if {'path','bytes','sha256'}<=x.keys():
   actual=bind(Path(x['path']));assert (actual['bytes'],actual['sha256'])==(x['bytes'],x['sha256']),x['path'];verified+=1
  for y in x.values():verify(y)
 elif isinstance(x,list):
  for y in x:verify(y)
def tests(p):
 t=p.read_text();rows=[(v[0],*[int(n) for n in v[1:]]) for v in re.findall(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',t,re.M)]
 names=re.findall(r'^test (\S+) \.\.\. ok$',t,re.M)
 assert rows and len(names)==len(set(names))==sum(v[1] for v in rows)
 assert all(v[0]=='ok' and v[2:5]==(0,0,0) for v in rows)
 return rows,set(names)
v=read(A/'root/final-validation.json');assert v['status']=='pass';verify(v)
s=read(A/'source-final.json')['source_sha256'];old=read(A/'parent-source.json')['source_sha256'];assert len(s)==1247 and len(old)==1240 and old.keys()<=s.keys()
for rel,h in s.items():assert bind(W/rel)['sha256']==h,rel
changed={p for p,h in s.items() if old.get(p)!=h};assert changed==set(v['changed_build_inputs']) and len(changed)==26
assert sum(p in old for p in changed)==19 and len(s.keys()-old.keys())==7
source_peer=read(A/'root/final-source-review.json');assert source_peer['status']=='clear' and not source_peer['findings'];verify(source_peer)
roster=read(A/'root/final-roster.json');names={x for ns in roster.values() for x in ns};lib={x for k,ns in roster.items() if k not in ['page','worker'] for x in ns};assert len(names)==29 and len(lib)==27 and {k:len(x) for k,x in roster.items()}==v['new_groups']
for key,rel in [('public','src/script/promise_race_semantic_tests.rs'),('abort','src/script/promise_race_abort_tests.rs'),('private','src/script/promises/all_semantics/race_quota_tests.rs')]:
 fs=re.findall(r'#\[test\]\s*fn (\w+)\(', (W/rel).read_text());assert set(fs)=={x.split('::')[-1] for x in roster[key]}
ren=read(A/'root/migration-review.json')['renames'];assert len(ren)==6 and len(set(ren.values()))==6
migration=read(A/'migrations-before-1/source-ready.json');actual_renames={}
for f in migration['files']:
 before=re.findall(r'#\[test\]\s*fn (\w+)\(',Path(f['before']['path']).read_text());after=re.findall(r'#\[test\]\s*fn (\w+)\(',Path(f['raw']['path']).read_text());assert len(before)==len(after)
 for a,b in zip(before,after):
  if a!=b:
   matches=[(k,val) for k,val in ren.items() if k.split('::')[-1]==a and val.split('::')[-1]==b];assert len(matches)==1;actual_renames.update(matches)
assert actual_renames==ren
observed={}
for label,c in v['checks'].items():
 receipt=read(Path(c['receipt']['path']));log=Path(c['log']['path']);assert receipt['exit']==0 and receipt['sha256']==c['log']['sha256'] and receipt['log']==log.name
 command=receipt['command']
 if label in ['focused-race-1','candidate-page-1','candidate-worker-1','default-full-1','host-vulkan-full-1']:
  rows,found=tests(log);assert len(found)==c['passed'] and len(rows)==c['result_rows']
  if label=='focused-race-1':assert found==lib and len(rows)==1
  elif label=='candidate-page-1':assert found==set(roster['page']) and len(rows)==1
  elif label=='candidate-worker-1':assert found==set(roster['worker']) and '--include-ignored' in command
  else:
   previous_rows,previous=tests(Path(c['previous_log']['path']));mapped={ren.get(x,x) for x in previous}
   assert set(ren)<=previous and not mapped&names and found==mapped|names
   assert len(rows)==51 and len(previous_rows)==50 and all(x[5]==0 for x in rows)
   assert len(found)==(3084 if label=='default-full-1' else 3438)
   assert command[1]==(' +1.88.0'.strip() if label=='default-full-1' else '+1.99.0')
   assert ('--features' in command)==(label=='host-vulkan-full-1')
   if '--features' in command:assert command[command.index('--features')+1]=='test262-host,vulkan-raster'
   assert '--include-ignored' in command
  observed[label]={'passed':len(found),'result_rows':len(rows),'failed':0,'ignored':0,'measured':0,'filtered':sum(x[5] for x in rows)}
 if label.startswith('clippy'):
  assert command[2]=='clippy' and '--all-targets' in command and command[-3:]==['--','-D','warnings']
  assert command[1]==(' +1.88.0'.strip() if label=='clippy-msrv-1' else '+1.99.0')
  if label=='clippy-host-vulkan-1':assert command[command.index('--features')+1]=='test262-host,vulkan-raster'
 if label=='format-check-1':assert command[-4:]==['fmt','--all','--','--check'] and '+1.99.0' in command
 if label=='host-release-1':assert command[1:3]==['+1.88.0','build'] and command[-5:]==['--features','test262-host','--release','--bin','eris-js']
binary=read(A/'binary.json');verify(binary);assert binary==v['binary'] and binary['source_inventory']==str(A/'source-final.json') and binary['build_receipt']==str(A/'validation/host-release-1.json')
replays={}
for name,total,controls in [('promise-all-report.json',196,90),('promise-existing-report.json',458,74)]:
 r=read(A/name);parent_path=A/'replay-parent'/name;prior=read(parent_path);assert parent_path.read_bytes()==(P/name).read_bytes()
 assert r['cases']==prior['cases'] and r['harness_preflight']==prior['harness_preflight']
 assert len(r['cases'])==len({x['id'] for x in r['cases']})==r['mode_cases']==total
 assert dict(collections.Counter(x['status'] for x in r['cases']))==r['counts']==v['replays'][name]['counts']
 assert len(r['harness_preflight'])==len({(x['name'],x['result']['mode']) for x in r['harness_preflight']})==controls
 assert r['harness_preflight_passed'] and all(x['verified'] for x in r['harness_preflight'])
 assert not r['regressions'] and not r['improvements'] and not r['full_test262_conformance']
 for key in ['revision','corpus_manifest_sha256','runner_policy_sha256','counts']:assert r[key]==prior[key]
 assert r['binary_sha256']==binary['sha256']
 replays[name]={'modes':total,'controls':controls,'counts':r['counts'],'all_case_and_control_records_exact':True}
for p in v['parent_baselines'].values():
 base=read(Path(p['path']));verify(base)
 checks=base.get('checks',{'only':{'receipt':base.get('receipt'),'log':base.get('log')}})
 for c in checks.values():
  rec=read(Path(c['receipt']['path']));assert rec['exit']!=0 and rec['sha256']==c['log']['sha256']
  text=Path(c['log']['path']).read_text();rr=re.findall(r'^test result: FAILED\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text,re.M);assert len(rr)==1 and rr[0][0]=='0'
docs=read(A/'root/documentation-final.json');verify(docs)
chapter=(W/'docs/promise-race.md').read_text();assert '110 observations across sloppy and strict modes' in chapter and '110 strict-mode' not in chapter and 'PENDING_' not in chapter
for rel,expected in docs['files'].items():assert bind(W/rel)==expected
review={'status':'clear','reviewer':'script','scope':'Independent final validation/result/documentation audit using inert source, JSON, log and hash parsing only. No build, Rust/JavaScript/browser, runner or project execution.','bindings':[bind(A/'root/final-validation.json'),bind(A/'root/finalize-validation.py'),bind(A/'source-final.json'),bind(A/'root/final-source-review.json'),bind(A/'root/documentation-final.json'),bind(A/'root/update-documentation.py'),bind(A/'run-final-checks.py'),bind(A/'run-check.py'),bind(A/'run-tool.py'),bind(A/'root/script-validation-check.py')],'bound_artifacts_verified':verified,'source':{'inputs':1247,'parent_inputs':1240,'changed_existing':19,'new':7,'unchanged_parent':1221,'all_current_hashes_match':True},'observed_checks':observed,'roster':{'new_total':29,'focused':27,'public':17,'abort':6,'private':4,'page':1,'worker':1,'old_renames':6,'all_other_prior_names_preserved':True},'other_checks':'Both strict all-target Clippy configurations, Rust1.99 fmt check and Rust1.88 test262-host release build have terminal exit0 with correctly bound logs/commands. Binary4416216 bytes SHA80a2bc01eeb9d786c2a6042eced35d5a0da974fdc955d8c194943e9cbc22352e is independently hashed and joins both replay reports.','replays':replays,'parent_observations':'Production parent bytes retained in each selected baseline inventory. Public0/17 and abort0/6 fail at first sloppy missing-method/prerequisite path; each integration0/1 fails first enabled pixel after disabled controls. Later rows remain explicitly unreached. Earlier zero-selected abort attempt is retained and excluded; private4 is API-dependent, not parent-executed.','finalizer_review':'Exact test row/name cardinality, six rename mapping, zero full filtering, previous full roster union, source inventory, terminal receipt hashes, frozen binary and exact full replay case/control comparisons are enforced. Independent audit rederived the same outcomes instead of executing the finalizer.','documentation':'Four docs retain historical material and describe selected race behavior/limits without claiming complete94-source execution or full conformance. Counts29,3084/3438,51 rows,110 mixed-mode public observations,24 fatal operations/48 readbacks,28 private operations and654/164 preservation reconcile. Complete upstream race profile and device/performance claims remain excluded. Archive publication itself is outside this audit.','resolved_wording':[{'issue':'Initial final chapter called110 mixed sloppy/strict observations strict-mode observations.','resolution':'Root corrected chapter and updater to110 observations across sloppy and strict modes, updating documentation-final hashes; no test or build-input change.'}],'findings':[]}
p=A/'root/final-validation-review.json';p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(p)))
