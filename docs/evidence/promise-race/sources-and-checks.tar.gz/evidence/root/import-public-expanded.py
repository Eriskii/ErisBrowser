import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];H=A/'tests-public-2';W=A/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(v):
 if isinstance(v,dict):
  if set(v)=={'path','bytes','sha256'}:assert bind(Path(v['path']))==v,v['path']
  else:
   for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
r=json.loads((H/'source-ready.json').read_bytes());verify(r)
peer=json.loads((H/'script-review.json').read_bytes());assert 'clear' in peer['status']
s=json.loads((A/'source-parent-abort-1.json').read_bytes())
for p,h in s['source_sha256'].items():assert bind(W/p)['sha256']==h,p
f=r['test_module'];p=f['relative'];assert (W/p).read_bytes()==Path(f['before']['path']).read_bytes();raw=Path(f['raw']['path']).read_bytes();assert raw.startswith((W/p).read_bytes());(W/p).write_bytes(raw);s['source_sha256'][p]=bind(W/p)['sha256']
s['scope']='Published AV plus17 public,6 fatal and2 integration race groups; no production.'
(A/'source-parent-public-2.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/public-import-2.json').write_text(json.dumps(dict(status='verified_import',hold=bind(H/'source-ready.json'),peer=bind(H/'script-review.json'),source=bind(A/'source-parent-public-2.json'),registration='Unchanged by this import; prior abort registration retained.'),indent=2)+'\n')
