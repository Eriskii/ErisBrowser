import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];H=A/'tests-abort-1';W=A/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=json.loads((H/'source-ready.json').read_bytes())
for row in r['files']:
 p=H/row['path'];assert bind(p)==dict(row,path=str(p))
peer=json.loads((H/'html-review.json').read_bytes());print(peer['status'])
s=json.loads((A/'source-parent-integration-1.json').read_bytes())
for p,h in s['source_sha256'].items():assert bind(W/p)['sha256']==h,p
p='src/script.rs';before=(H/'before'/p).read_bytes();raw=(H/'raw-registration'/p).read_bytes();assert (W/p).read_bytes()==before;assert raw==before+b'#[cfg(test)]\nmod promise_race_abort_tests;\n';(W/p).write_bytes(raw);s['source_sha256'][p]=bind(W/p)['sha256']
p='src/script/promise_race_abort_tests.rs';assert not (W/p).exists();(W/p).write_bytes((H/'raw'/p).read_bytes());s['source_sha256'][p]=bind(W/p)['sha256']
s['scope']='Published AV plus six public, six fatal and two integration race groups; no production.';s['source_sha256']=dict(sorted(s['source_sha256'].items()));assert len(s['source_sha256'])==1246
(A/'source-parent-abort-1.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/abort-import.json').write_text(json.dumps(dict(status='verified_import',hold=bind(H/'source-ready.json'),peer=bind(H/'html-review.json'),source=bind(A/'source-parent-abort-1.json')),indent=2)+'\n')
