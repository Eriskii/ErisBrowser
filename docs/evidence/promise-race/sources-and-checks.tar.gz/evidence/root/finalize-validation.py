import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';PREVIOUS=Path('/tmp/eris-expression-in-1')
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def tests(p):
 t=p.read_text();pattern=r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
 rows=[(status,*map(int,numbers)) for status,*numbers in re.findall(pattern,t,re.M)];found=re.findall(r'^test (\S+) \.\.\. ok$',t,re.M)
 assert rows and sum(r[1] for r in rows)==len(found)==len(set(found))
 assert all(r[0]=='ok' and r[2:5]==(0,0,0) for r in rows)
 return rows,set(found)
s=read(A/'source-final.json');parent=read(A/'parent-source.json')
for p,h in s['source_sha256'].items():assert bind(W/p)['sha256']==h,p
changed={p for p,h in s['source_sha256'].items() if parent['source_sha256'].get(p)!=h};assert len(changed)==26 and len(s['source_sha256'])==1247
roster=read(A/'root/final-roster.json');names={n for v in roster.values() for n in v};lib={n for k,v in roster.items() if k not in ['page','worker'] for n in v};assert len(names)==29 and len(lib)==27
renames=read(A/'root/migration-review.json')['renames'];assert len(renames)==6
checks={}
for label in ['focused-race-1','candidate-page-1','candidate-worker-1','default-full-1','host-vulkan-full-1','clippy-msrv-1','clippy-host-vulkan-1','format-check-1','host-release-1','upstream-all-1','upstream-existing-1']:
 p=A/'validation'/f'{label}.json';r=read(p);l=p.with_suffix('.log');assert r['exit']==0 and bind(l)['sha256']==r['sha256'];checks[label]=dict(receipt=bind(p),log=bind(l))
 if label in ['focused-race-1','candidate-page-1','candidate-worker-1','default-full-1','host-vulkan-full-1']:
  rows,found=tests(l)
  if label=='focused-race-1':assert len(rows)==1 and found==lib
  elif label=='candidate-page-1':assert len(rows)==1 and found==set(roster['page'])
  elif label=='candidate-worker-1':assert len(rows)==1 and found==set(roster['worker'])
  else:
   oldlog=PREVIOUS/'validation'/f'{label}.log';oldrows,oldnames=tests(oldlog);mapped={renames.get(n,n) for n in oldnames}
   assert len(rows)==len(oldrows)+1==51 and all(r[5]==0 for r in rows)
   assert not(names&mapped) and found==mapped|names
   checks[label]['previous_log']=bind(oldlog)
  checks[label].update(passed=len(found),result_rows=len(rows),failed=0,ignored=0)
binary=read(A/'binary.json');assert bind(Path(binary['path']))=={k:binary[k] for k in ['path','bytes','sha256']}
reports={}
for name,total,controls in [('promise-all-report.json',196,90),('promise-existing-report.json',458,74)]:
 r=read(A/name);p=A/'replay-parent'/name;old=read(p);assert p.read_bytes()==(PREVIOUS/name).read_bytes()
 assert r['cases']==old['cases'] and r['harness_preflight']==old['harness_preflight']
 assert r['mode_cases']==len(r['cases'])==total and len(r['harness_preflight'])==controls
 assert r['harness_preflight_passed'] and all(x['verified'] for x in r['harness_preflight'])
 assert not r['regressions'] and not r['improvements'] and r['binary_sha256']==binary['sha256']
 for key in ['revision','corpus_manifest_sha256','runner_policy_sha256','counts']:assert r[key]==old[key]
 reports[name]=dict(report=bind(A/name),parent_report=bind(p),counts=r['counts'],modes=total,harness_controls=controls,all_case_and_harness_records_unchanged=True)
out=dict(status='pass',base=s['base'],source=bind(A/'source-final.json'),source_review=bind(A/'root/final-source-review.json'),source_inputs=1247,changed_build_inputs=sorted(changed),new_groups={k:len(v) for k,v in roster.items()},roster=bind(A/'root/final-roster.json'),migration_review=bind(A/'root/migration-review.json'),checks=checks,binary=binary,replays=reports,parent_baselines={k:bind(A/'root'/p) for k,p in [('public','parent-public-baseline-2.json'),('abort','parent-abort-baseline.json'),('integration','parent-integration-baseline.json')]},private_parent_eligibility='Four groups require the new helper; no parent compilation or execution claim.',preservation='Inherited all algorithms/types/arenas/caps unchanged. Twenty existing groups migrate only mandatory metadata/accounting expectations; six test names change. Remaining old test names remain in full passing rosters.',limitations=['Selected Promise.race API checkpoint; complete94-source upstream profile is separate follow-up, not a claimed result.','No full-web compatibility, production-security, GPU-device, physical-memory or Chromium-speed claim.','Fixed body17 funds selected orchestration/direct-handle cleanup; it is not a bound on arbitrary inherited graph teardown. Existing promise/job storage can grow with input.'])
(A/'root/final-validation.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(status='pass',new_groups=29,default=checks['default-full-1']['passed'],host_vulkan=checks['host-vulkan-full-1']['passed'])))
