import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
s=json.loads((A/'source-unformatted.json').read_bytes());parent=json.loads((A/'parent-source.json').read_bytes());changes={}
for p,h in list(s['source_sha256'].items()):
 actual=bind(W/p)['sha256']
 if actual!=h:changes[p]=dict(before=h,after=actual)
 s['source_sha256'][p]=actual
s['scope']='Promise.race candidate after root formatting; complete build input inventory.'
assert len(s['source_sha256'])==1247
(A/'source-final.json').write_text(json.dumps(s,indent=2)+'\n')
roster={}
for key,relative,prefix in [
 ('public','src/script/promise_race_semantic_tests.rs','script::promise_race_semantic_tests::'),
 ('abort','src/script/promise_race_abort_tests.rs','script::promise_race_abort_tests::'),
 ('private','src/script/promises/all_semantics/race_quota_tests.rs','script::promises::all_semantics::race_quota_tests::'),
 ('page','tests/promise_race.rs',''),
 ('worker','tests/worker/promise_race.rs','promise_race::')]:
 text=(W/relative).read_text();names=re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn (\w+)\(',text);roster[key]=[prefix+n for n in names]
assert [len(roster[k]) for k in ['public','abort','private','page','worker']]==[17,6,4,1,1]
(A/'root/final-roster.json').write_text(json.dumps(roster,indent=2)+'\n')
(A/'root/format-changes.json').write_text(json.dumps(dict(status='formatted',changes=changes,source=bind(A/'source-final.json')),indent=2)+'\n');print(json.dumps(dict(inputs=1247,formatted_paths=list(changes),new_groups=29)))
