import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree'
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
s=read(A/'source-final.json');parent=read(A/'parent-source.json');changed={p:h for p,h in s['source_sha256'].items() if parent['source_sha256'].get(p)!=h};assert len(changed)==26 and len(s['source_sha256'])==1247
(A/'evidence-source.json').write_text(json.dumps(dict(base=s['base'],scope='Changed build inputs only; reconstruct all1247 inputs from parent commit plus26 files. Complete source inventory retained.',source_sha256=changed),indent=2)+'\n')
v=read(A/'root/final-validation.json');assert v['status']=='pass';peer=read(A/'root/final-validation-review.json');assert 'clear' in peer['status']
artifacts={};excluded={'selection-final.json','publication-verification.json','github-publication.json'}
for directory in ['plans','runtime-fee-proof-1','install-audit-1','public-oracles-2','tests-public-1','tests-public-2','tests-abort-1','tests-private-1','tests-integration-1','migrations-before-1','production-1','unformatted','documentation-1','root','validation','replay-parent']:
 for p in sorted((A/directory).rglob('*')):
  assert not p.is_symlink(),p
  if not p.is_file() or p.name in excluded or '__pycache__' in p.parts:continue
  artifacts[str(p.relative_to(A))]=bind(p)
for p in sorted(A.iterdir()):
 if p.is_file() and p.suffix in ['.json','.py','.md']:artifacts[p.name]=bind(p)
for relative in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/promise-race.md']:artifacts['documentation/'+relative]=bind(W/relative)
selection=dict(source_inventory=bind(A/'evidence-source.json'),artifacts=artifacts,claims=dict(scope='Generic Promise.race with cached synchronous iteration, direct shared capability callbacks, inherited FIFO and terminal resource policy.',base=s['base'],complete_build_inventory=bind(A/'source-final.json'),complete_build_input_count=1247,changed_build_inputs=26,validation=v,peer=bind(A/'root/final-validation-review.json'),limitations='No complete race upstream profile, full-web compatibility, production-security, GPU-device or Chromium-relative performance claim.'),max_uncompressed_bytes=32*1024*1024)
(A/'root/selection-final.json').write_text(json.dumps(selection,indent=2)+'\n');print(json.dumps(dict(changed_source_inputs=26,full_build_inputs=1247,artifacts=len(artifacts))))
