from pathlib import Path
p=Path(__file__).resolve().parent
s=(p/'original/node-root-audit-results.py').read_text()
s=s.replace('Initial source-only adaptation of the retained predicate audit. Missing pending\nresult/release files fail explicitly; counts are derived from literal test rows.', 'Equality adaptation of the retained root audit. Requires the final announced\nrelease and all result files; counts come from literal test rows, including\nserial nocapture status wraps. No prior SHA-specific log repair is used.')
s=s.replace('B = Path(__file__).resolve().parent','B = Path(__file__).resolve().parent.parent')
s=s.replace("SOURCE = 'ccace7ea810ad2739f65ef073dc0022211d7eba725b1701dfbe117e09d1f7f81'", "SOURCE = '08dc5dc8c66fe1d77fe93501179a109ee2baf66ad653c7f676d1d4eafeb7784b'")
s=s.replace("BASE_BINARY = '1d0a4eaa3a900f759b574de1454c91ae5be7570e0a7c3be51a9db169162dc07f'", "BASE_BINARY = '3198cd31112100406a47052d3bc179924435c9711ec9f37a5240939572fa6834'")
a=s.index('def tests(');b=s.index('\n\nOUTCOMES =',a)
s=s[:a]+'''def test_rows(log, serial):
    """Associate a serial bare status with exactly one unfinished test header."""
    names, wraps = [], []
    pending = None
    for number, line in enumerate(log.splitlines(), 1):
        match = re.fullmatch(r'test ([A-Za-z0-9_:]+) \\.\\.\\. (.*)', line)
        if match:
            require(pending is None, 'new test before prior status at line ' + str(number))
            name, tail = match.groups()
            if tail in {'ok', 'FAILED', 'ignored'}:
                names.append((name, tail))
            else:
                require(serial, 'nonserial wrapped test status at line ' + str(number))
                pending = (name, number)
        elif line in {'ok', 'FAILED', 'ignored'}:
            require(pending is not None and serial, 'orphan test status at line ' + str(number))
            names.append((pending[0], line))
            wraps.append(dict(name=pending[0], header_line=pending[1], status_line=number, status=line))
            pending = None
        elif line.startswith('test result:'):
            require(pending is None, 'missing test status before summary')
    require(pending is None, 'unfinished test status')
    return names, wraps


def tests(path, exit_code, totals=None):
    record, log = command('validation/' + path + '.json', exit_code)
    summaries = re.findall(r'^test result: (?:ok|FAILED)\\. (\\d+) passed; (\\d+) failed; (\\d+) ignored;', log, re.M)
    require(summaries, 'missing test summary: ' + path)
    observed = [sum(int(row[i]) for row in summaries) for i in range(3)]
    if totals is not None:
        require(observed == totals, 'test summary: ' + path)
    names, wraps = test_rows(log, '--test-threads=1' in record['command'])
    require([sum(status == status_name for _, status in names) for status_name in ['ok', 'FAILED', 'ignored']] == observed,
            'literal test rows: ' + path)
    if exit_code == 0:
        require(observed[0] > 0 and observed[1:] == [0, 0], 'successful complete test run: ' + path)
    record = {**record, 'serial_status_wraps': wraps}
    return record, names, log, observed


def validation():
    source = read('candidate-source-final.json')
    require(INPUTS[str(B / 'candidate-source-final.json')]['sha256'] == SOURCE, 'final source identity')
    require(len(source['files']) == 19, 'final source population')
    for row in source['files']:
        bound(row, B / 'worktree')
        bound(row, B / 'held-source-final')
    initial = read('candidate-source-initial.json')
    require(len(initial['files']) == 17, 'initial source population')
    old = {r['path']: r for r in initial['files']}
    current = {r['path']: r for r in source['files']}
    require(all(current[p] == r for p, r in old.items()), 'initial source/fixture drift')
    for row in initial['files']:
        bound(row, B / 'held-source-initial')
    extra = {'src/script/bootstrap_tests.rs', 'src/script/dom_bindings/identity_tests.rs'}
    require(current.keys() - old.keys() == extra, 'only measured test paths added')
    correction = read('bootstrap-correction/receipt.json')
    require({r['path'] for r in correction['files']} == extra, 'measured correction scope')
    require(sum(len(r['changes']) for r in correction['files']) == 3, 'three measured literals')
    for row in correction['files']:
        data = raw('bootstrap-correction/before/' + row['path'])
        require(hashlib.sha256(data).hexdigest() == row['before_sha256'], 'measured original')
        for change in row['changes']:
            old_text, new_text = change['before'], change['after']
            require(data.count(old_text.encode()) == 1, 'measured replacement count')
            data = data.replace(old_text.encode(), new_text.encode())
        require(hashlib.sha256(data).hexdigest() == row['after_sha256'], 'correction after binding')
        require(data == raw('worktree/' + row['path']), 'exact measured replacement')
    inventory_correction = read('runtime/test-inventory-correction.json')
    old_inventory = json.loads(bound(inventory_correction['original_inventory']))
    new_inventory = json.loads(bound(inventory_correction['corrected_inventory']))
    bound(inventory_correction['original_source_hold'])
    test_source = bound(inventory_correction['held_test_source']).decode()
    corrected = json.loads(json.dumps(old_inventory))
    for change in inventory_correction['changes']:
        require(corrected['direct_private'].count(change['before']) == 1, 'unique truncated name')
        corrected['direct_private'][corrected['direct_private'].index(change['before'])] = change['after']
    require(corrected == new_inventory, 'only two inventory names corrected')
    direct = re.findall(r'^#\\[test\\]\\nfn ([A-Za-z_][A-Za-z0-9_]*)\\(', test_source, re.M)
    require(direct == new_inventory['direct_private'] and len(direct) == 18, 'full digit-bearing private names')
    require(len(new_inventory['independent']) == 16 and new_inventory['new_groups'] == 34, 'Runtime inventory')
    focus = Counter(); focused_commands = {}; measurement_wraps = {}
    labels = ['equality-188-1', 'bootstrap-188-2', 'constants-188-1', 'node-data-188-1',
              'normalize-188-1', 'predicates-188-1', 'root-188-1']
    equality_log = None
    for label in labels:
        rec, rows, log, observed = tests(label, 0)
        require('--include-ignored' in rec['command'], 'focused include ignored: ' + label)
        if label == 'equality-188-1':
            require(observed == [36, 0, 0], '34 Runtime plus Page/worker groups')
            expected_runtime = {'script::node_equality::tests::' + n for n in new_inventory['independent'] + direct}
            require({n for n, _ in rows if n.startswith('script::node_equality::tests::')} == expected_runtime, 'new Runtime names')
            require(len({n for n, _ in rows} - expected_runtime) == 2, 'two browser witnesses')
            equality_log = log
        focus.update(n for n, _ in rows)
        focused_commands[label] = dict(command=rec['command'], totals=observed)
        if rec['serial_status_wraps']:
            measurement_wraps[label] = rec['serial_status_wraps']
    require(equality_log is not None, 'new test log')
    dense = re.findall(r'NODE_EQUALITY_DEPTH layout=(\\d+) work=(\\d+) heap=(\\d+)', equality_log)
    require(dense == [('0', '65681', '13416'), ('1', '70989', '13416')], 'measured dense endpoints')
    failed_record, failed, log, _ = tests('bootstrap-188-1', 101, [28, 2, 0])
    require({n for n, status in failed if status == 'FAILED'} == {
        'script::bootstrap_tests::bootstrap_convenience_and_try_paths_separate_work_and_retain_heap',
        'script::dom_bindings::identity_tests::dom_parent_bootstrap_reports_actual_remaining_budget_and_capacities'}, 'bootstrap failures')
    measurement_wraps['bootstrap-188-1'] = failed_record['serial_status_wraps']
    diagnostic = 'NODE_EQUALITY_BOOTSTRAP steps=7816 allocated=1762227 objects=687 capacity=687 native=321 prototypes=25'
    require(diagnostic in log and diagnostic in equality_log, 'measured diagnostic')
    require(correction['measurements'] == dict(steps=7816, allocated=1762227, objects=687,
                                             capacity=687, native=321, prototypes=25), 'measured receipt')
    require(correction['equality_log_sha256'] == INPUTS[str(B / 'validation/equality-188-1.log')]['sha256'] and
            correction['initial_bootstrap_log_sha256'] == INPUTS[str(B / 'validation/bootstrap-188-1.log')]['sha256'], 'measurement log bindings')
    gate_labels = ['compile-188-1', 'clippy-native-198-1', 'clippy-presenter-188-1',
                   'format-198-1', 'release-adapter-188-1']
    gates = {}
    for label in gate_labels:
        rec, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(rec['command'][-2:] == ['-D', 'warnings'] and '--all-targets' in rec['command'], 'strict Clippy')
        if label.startswith('release'):
            require('--release' in rec['command'] and '--bin' in rec['command'] and 'eris-js' in rec['command'], 'release adapter build')
        gates[label] = rec['command']
    full = {}
    for label, feature in [('full-default-188-1', None), ('full-native-198-1', 'vulkan-raster')]:
        rec, _, _, observed = tests(label, 0)
        argv = rec['command']
        require('--include-ignored' in argv and '--test-threads=4' in argv, 'full command flags')
        if feature:
            require('--features' in argv and feature in argv, 'native feature')
        else:
            require('--features' not in argv, 'default feature')
        full[label] = dict(command=argv, totals=observed)
    permitted = set(labels + gate_labels + list(full) + ['bootstrap-188-1'])
    observed_labels = {p.stem for p in (B / 'validation').glob('*.json')}
    require(observed_labels == permitted, 'validation command inventory changed: ' + repr(observed_labels ^ permitted))
    return dict(full=full, new_groups=36, focused_observations=sum(focus.values()),
                focused_unique=len(focus), focused_commands=focused_commands, successful_gates=gates,
                earlier_bootstrap_passes=28, retained_bootstrap_failures=2,
                all_attempt_passing_observations=sum(focus.values()) + 28,
                measured_bootstrap=correction['measurements'], dense_body_observations=dense,
                serial_status_wraps=measurement_wraps, source_manifest_sha256=SOURCE)
''' + s[b:]
s=s.replace("['comparison-preparation-ready.json', 'compare-root-inputs.json', 'before-comparison-inputs.json']", "['comparison-preparation-ready.json', 'compare-equality-inputs.json', 'before-comparison-inputs.json']")
s=s.replace("read('root-comparison.json')", "read('equality-comparison.json')")
s=s.replace("len(comparison['profiles']) == 17", "len(comparison['profiles']) == 18")
s=s.replace("if r['profile'] != 'node-root'", "if r['profile'] != 'node-equality'")
s=s.replace("row['profile'] == 'node-predicates'", "row['profile'] == 'node-root'")
s=s.replace("len(policy['already_unhealthy_unchanged']) == 12", "len(policy['already_unhealthy_unchanged']) == 18")
s=s.replace("{'node-constants', 'node-normalize'}", "{'node-constants', 'node-normalize', 'node-predicates'}")
s=s.replace("reports['node-root']", "reports['node-equality']")
s=s.replace("p['profile'] == 'node-root'", "p['profile'] == 'node-equality'")
s=s.replace("raw('root-after.json')", "raw('equality-after.json')")
s=s.replace("('cases', 4268, 4178, 4176, 2), ('controls', 476, 468, 464, 4)", "('cases', 4300, 4208, 4206, 2), ('controls', 492, 480, 476, 4)")
s=s.replace("B / 'root-comparison.json'", "B / 'equality-comparison.json'")
s=s.replace("len(replay_receipts) == 17", "len(replay_receipts) == 18")
s=s.replace("'node-predicates-replay-command.json'}", "'node-predicates-replay-command.json', 'node-root-replay-command.json'}")
s=s.replace("profiles=17", "profiles=18")
s=s.replace("preserved_older_unhealthy_rows=12", "preserved_older_unhealthy_rows=18")
s=s.replace("return all(r['observation'].get(k) == v for k, v in r['expected_observation'].items())", "observation = r.get('observation', {})\n                return isinstance(observation, dict) and all(observation.get(k) == v for k, v in r['expected_observation'].items())")
# Independently verify status histograms as well as unchanged four row helpers.
s=s.replace("actual = profile[kind]\n            require", "actual = profile[kind]\n            unwrap = lambda row: row.get('result', row)\n            require(actual['before_status_counts'] == dict(Counter(unwrap(r).get('status') for r in left)) and\n                    actual['after_status_counts'] == dict(Counter(unwrap(r).get('status') for r in right)), 'raw status counts')\n            require")
s=s.replace("require(len(comparison['profiles']) == 18, 'profile count')", "require(len(comparison['profiles']) == 18, 'profile count')\n    require({p['profile'] for p in comparison['profiles']} == {\n        'dom-method-identity', 'object-is', 'symbols', 'array-descriptors', 'reflect-construction',\n        'prior-CharacterData', 'prior-PI', 'prior-production', 'node-original', 'node-exact',\n        'append-exact', 'document-title', 'node-constants', 'text-operations', 'node-normalize',\n        'node-predicates', 'node-root', 'node-equality'}, 'exact profile identities')")
s=s.replace("return dict(summary=comparison['summary']", "for label, code in [('equality-baseline', 1), ('equality-verify', 0), ('compare-before', 0), ('classify-before', 0)]:\n        command(label + '-command.json', code)\n    expected_commands = {p.name for p in replay_receipts} | {p + '-command.json' for p in [\n        'symbols', 'array-descriptors', 'reflect-construction', 'replay-jobs', 'comparison',\n        'inventory-classification', 'equality-baseline', 'equality-verify', 'compare-before', 'classify-before']}\n    actual_commands = {p.name for p in B.glob('*-command.json')}\n    require(actual_commands == expected_commands, 'unreviewed command receipt inventory: ' + repr(actual_commands ^ expected_commands))\n    return dict(summary=comparison['summary']")
# Retain nonzero command records explicitly in addition to binding every receipt.
s=s.replace("INPUTS = {}", "INPUTS = {}\nCOMMANDS = {}")
s=s.replace("record = read(path)\n    require(record['exit']", "record = read(path)\n    COMMANDS[path] = record\n    require(record['exit']")
s=s.replace("report['inputs'] =", "report['commands'] = COMMANDS\n    report['nonzero_commands'] = {p: r for p, r in COMMANDS.items() if r['exit'] != 0}\n    report['inputs'] =")
s=s.replace("{'inputs', 'comparison'}", "{'inputs', 'comparison', 'commands'}")
(p/'audit-results.py').write_text(s)
