#!/usr/bin/env python3
"""Read JSON, logs and bytes only; never import a reviewed helper or run an engine.

Equality adaptation of the retained root audit. Requires the final announced
release and all result files; counts come from literal test rows, including
serial nocapture status wraps. No prior SHA-specific log repair is used.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent.parent
SOURCE = '08dc5dc8c66fe1d77fe93501179a109ee2baf66ad653c7f676d1d4eafeb7784b'
BASE_BINARY = '3198cd31112100406a47052d3bc179924435c9711ec9f37a5240939572fa6834'
# Required independently from the eventual root release announcement; no guessed pin.
CANDIDATE = None
INPUTS = {}
COMMANDS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def raw(path):
    path = B / path
    data = path.read_bytes()
    binding = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    require(str(path) not in INPUTS or INPUTS[str(path)] == binding, 'input changed: ' + str(path))
    INPUTS[str(path)] = binding
    return data


def read(path):
    return json.loads(raw(path))


def bound(row, prefix=B):
    data = raw(prefix / row['path'])
    require(hashlib.sha256(data).hexdigest() == row['sha256'], 'hash: ' + row['path'])
    if 'bytes' in row:
        require(len(data) == row['bytes'], 'length: ' + row['path'])
    return data


def command(path, exit_code):
    record = read(path)
    COMMANDS[path] = record
    require(record['exit'] == exit_code, 'command exit: ' + path)
    log = Path(path).parent / record['log']
    data = raw(log)
    require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)
    return record, data.decode()


def test_rows(log, serial):
    """Associate a serial bare status with exactly one unfinished test header."""
    names, wraps = [], []
    pending = None
    for number, line in enumerate(log.splitlines(), 1):
        match = re.fullmatch(r'test ([A-Za-z0-9_:]+) \.\.\. (.*)', line)
        if match:
            require(pending is None, 'new test before prior status at line ' + str(number))
            name, tail = match.groups()
            if tail in {'ok', 'FAILED', 'ignored'}:
                names.append((name, tail))
            else:
                require(serial, 'nonserial wrapped test status at line ' + str(number))
                pending = (name, number)
        elif line in {'ok', 'FAILED', 'ignored'}:
            require(pending is not None and serial, 'orphan test status at line ' + str(number))
            names.append((pending[0], line))
            wraps.append(dict(name=pending[0], header_line=pending[1], status_line=number, status=line))
            pending = None
        elif line.startswith('test result:'):
            require(pending is None, 'missing test status before summary')
    require(pending is None, 'unfinished test status')
    return names, wraps


def tests(path, exit_code, totals=None):
    record, log = command('validation/' + path + '.json', exit_code)
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    require(summaries, 'missing test summary: ' + path)
    observed = [sum(int(row[i]) for row in summaries) for i in range(3)]
    if totals is not None:
        require(observed == totals, 'test summary: ' + path)
    names, wraps = test_rows(log, '--test-threads=1' in record['command'])
    require([sum(status == status_name for _, status in names) for status_name in ['ok', 'FAILED', 'ignored']] == observed,
            'literal test rows: ' + path)
    if exit_code == 0:
        require(observed[0] > 0 and observed[1:] == [0, 0], 'successful complete test run: ' + path)
    record = {**record, 'serial_status_wraps': wraps}
    return record, names, log, observed


def validation():
    source = read('candidate-source-final.json')
    require(INPUTS[str(B / 'candidate-source-final.json')]['sha256'] == SOURCE, 'final source identity')
    require(len(source['files']) == 19, 'final source population')
    for row in source['files']:
        bound(row, B / 'worktree')
        bound(row, B / 'held-source-final')
    initial = read('candidate-source-initial.json')
    require(len(initial['files']) == 17, 'initial source population')
    old = {r['path']: r for r in initial['files']}
    current = {r['path']: r for r in source['files']}
    require(all(current[p] == r for p, r in old.items()), 'initial source/fixture drift')
    for row in initial['files']:
        bound(row, B / 'held-source-initial')
    extra = {'src/script/bootstrap_tests.rs', 'src/script/dom_bindings/identity_tests.rs'}
    require(current.keys() - old.keys() == extra, 'only measured test paths added')
    correction = read('bootstrap-correction/receipt.json')
    require({r['path'] for r in correction['files']} == extra, 'measured correction scope')
    require(sum(len(r['changes']) for r in correction['files']) == 3, 'three measured literals')
    for row in correction['files']:
        data = raw('bootstrap-correction/before/' + row['path'])
        require(hashlib.sha256(data).hexdigest() == row['before_sha256'], 'measured original')
        for change in row['changes']:
            old_text, new_text = change['before'], change['after']
            require(data.count(old_text.encode()) == 1, 'measured replacement count')
            data = data.replace(old_text.encode(), new_text.encode())
        require(hashlib.sha256(data).hexdigest() == row['after_sha256'], 'correction after binding')
        require(data == raw('worktree/' + row['path']), 'exact measured replacement')
    inventory_correction = read('runtime/test-inventory-correction.json')
    old_inventory = json.loads(bound(inventory_correction['original_inventory']))
    new_inventory = json.loads(bound(inventory_correction['corrected_inventory']))
    bound(inventory_correction['original_source_hold'])
    test_source = bound(inventory_correction['held_test_source']).decode()
    corrected = json.loads(json.dumps(old_inventory))
    for change in inventory_correction['changes']:
        require(corrected['direct_private'].count(change['before']) == 1, 'unique truncated name')
        corrected['direct_private'][corrected['direct_private'].index(change['before'])] = change['after']
    require(corrected == new_inventory, 'only two inventory names corrected')
    direct = re.findall(r'^#\[test\]\nfn ([A-Za-z_][A-Za-z0-9_]*)\(', test_source, re.M)
    require(direct == new_inventory['direct_private'] and len(direct) == 18, 'full digit-bearing private names')
    require(len(new_inventory['independent']) == 16 and new_inventory['new_groups'] == 34, 'Runtime inventory')
    focus = Counter(); focused_commands = {}; measurement_wraps = {}
    labels = ['equality-188-1', 'bootstrap-188-2', 'constants-188-1', 'node-data-188-1',
              'normalize-188-1', 'predicates-188-1', 'root-188-1']
    equality_log = None
    for label in labels:
        rec, rows, log, observed = tests(label, 0)
        require('--include-ignored' in rec['command'], 'focused include ignored: ' + label)
        if label == 'equality-188-1':
            require(observed == [36, 0, 0], '34 Runtime plus Page/worker groups')
            expected_runtime = {'script::node_equality::tests::' + n for n in new_inventory['independent'] + direct}
            require({n for n, _ in rows if n.startswith('script::node_equality::tests::')} == expected_runtime, 'new Runtime names')
            require(len({n for n, _ in rows} - expected_runtime) == 2, 'two browser witnesses')
            equality_log = log
        focus.update(n for n, _ in rows)
        focused_commands[label] = dict(command=rec['command'], totals=observed)
        if rec['serial_status_wraps']:
            measurement_wraps[label] = rec['serial_status_wraps']
    require(equality_log is not None, 'new test log')
    dense = re.findall(r'NODE_EQUALITY_DEPTH layout=(\d+) work=(\d+) heap=(\d+)', equality_log)
    require(dense == [('0', '65681', '13416'), ('1', '70989', '13416')], 'measured dense endpoints')
    failed_record, failed, log, _ = tests('bootstrap-188-1', 101, [28, 2, 0])
    require({n for n, status in failed if status == 'FAILED'} == {
        'script::bootstrap_tests::bootstrap_convenience_and_try_paths_separate_work_and_retain_heap',
        'script::dom_bindings::identity_tests::dom_parent_bootstrap_reports_actual_remaining_budget_and_capacities'}, 'bootstrap failures')
    measurement_wraps['bootstrap-188-1'] = failed_record['serial_status_wraps']
    diagnostic = 'NODE_EQUALITY_BOOTSTRAP steps=7816 allocated=1762227 objects=687 capacity=687 native=321 prototypes=25'
    require(diagnostic in log and diagnostic in equality_log, 'measured diagnostic')
    require(correction['measurements'] == dict(steps=7816, allocated=1762227, objects=687,
                                             capacity=687, native=321, prototypes=25), 'measured receipt')
    require(correction['equality_log_sha256'] == INPUTS[str(B / 'validation/equality-188-1.log')]['sha256'] and
            correction['initial_bootstrap_log_sha256'] == INPUTS[str(B / 'validation/bootstrap-188-1.log')]['sha256'], 'measurement log bindings')
    gate_labels = ['compile-188-1', 'clippy-native-198-1', 'clippy-presenter-188-1',
                   'format-198-1', 'release-adapter-188-1']
    gates = {}
    for label in gate_labels:
        rec, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(rec['command'][-2:] == ['-D', 'warnings'] and '--all-targets' in rec['command'], 'strict Clippy')
        if label.startswith('release'):
            require('--release' in rec['command'] and '--bin' in rec['command'] and 'eris-js' in rec['command'], 'release adapter build')
        gates[label] = rec['command']
    full = {}
    for label, feature in [('full-default-188-1', None), ('full-native-198-1', 'vulkan-raster')]:
        rec, _, _, observed = tests(label, 0)
        argv = rec['command']
        require('--include-ignored' in argv and '--test-threads=4' in argv, 'full command flags')
        if feature:
            require('--features' in argv and feature in argv, 'native feature')
        else:
            require('--features' not in argv, 'default feature')
        full[label] = dict(command=argv, totals=observed)
    permitted = set(labels + gate_labels + list(full) + ['bootstrap-188-1'])
    observed_labels = {p.stem for p in (B / 'validation').glob('*.json')}
    require(observed_labels == permitted, 'validation command inventory changed: ' + repr(observed_labels ^ permitted))
    return dict(full=full, new_groups=36, focused_observations=sum(focus.values()),
                focused_unique=len(focus), focused_commands=focused_commands, successful_gates=gates,
                earlier_bootstrap_passes=28, retained_bootstrap_failures=2,
                all_attempt_passing_observations=sum(focus.values()) + 28,
                measured_bootstrap=correction['measurements'], dense_body_observations=dense,
                serial_status_wraps=measurement_wraps, source_manifest_sha256=SOURCE)


OUTCOMES = {'status', 'observation', 'reason', 'stderr', 'matches_expectation', 'matches_implementation_policy',
            'verified', 'verified_with_protocol_prerequisite', 'positive_partner_matches'}


def key(row):
    row = row.get('result', row)
    return row['id'], row.get('mode', '')


def inputs(row):
    if 'result' in row:
        return {**{k: v for k, v in row.items() if k not in {'result', 'verified'}}, 'result': inputs(row['result'])}
    return {k: v for k, v in row.items() if k not in OUTCOMES}


def healthy(row):
    if 'result' in row:
        return row.get('verified') is True and row['result'].get('status') == row['expected']
    if 'expected_observation' not in row:
        return row.get('status') == 'passed'
    observation = row.get('observation', {})
    return (isinstance(observation, dict) and all(observation.get(k) == v for k, v in row['expected_observation'].items())
            and row.get('matches_expectation') is True and row.get('verified', True) is True
            and row.get('verified_with_protocol_prerequisite', True) is True)


def complete_rows(before, after):
    old, new = {key(r): r for r in before}, {key(r): r for r in after}
    require(len(old) == len(before) and len(new) == len(after) and old.keys() == new.keys(), 'row identity/population')
    result = dict(before_total=len(before), after_total=len(after), before_healthy=sum(map(healthy, before)),
                  after_healthy=sum(map(healthy, after)), unchanged=0, gains=0, losses=0, other_changes=0)
    changes = []
    for identity, a in old.items():
        b = new[identity]
        require(inputs(a) == inputs(b), 'row inputs changed: ' + repr(identity))
        if a == b:
            result['unchanged'] += 1
            continue
        category = 'gains' if not healthy(a) and healthy(b) else 'losses' if healthy(a) and not healthy(b) else 'other_changes'
        result[category] += 1
        changes.append(dict(id=identity[0], mode=identity[1], classification=category, before=a, after=b))
    return result, changes


def comparisons():
    prior_release = read('comparison-before/release.json')
    require(prior_release['sha256'] == BASE_BINARY, 'baseline release binding')
    bound(prior_release)
    release = read('release.json')
    require(release['sha256'] == CANDIDATE and release['bytes'] > 0 and release['source_manifest_sha256'] == SOURCE, 'release binding')
    bound(release)
    require(release['source_manifest'] == 'candidate-source-final.json' and release['build_receipt'] == 'validation/release-adapter-188-1.json', 'release source/build')
    for manifest in ['comparison-preparation-ready.json', 'compare-equality-inputs.json', 'before-comparison-inputs.json']:
        for row in read(manifest)['files']:
            data = bound(row)
            if 'original' in row:
                require(data == raw(row['original']), 'original copy: ' + row['path'])
    comparison = read('equality-comparison.json')
    require(not comparison['validation_failures'] and comparison['candidate']['sha256'] == CANDIDATE, 'comparison status')
    require(len(comparison['profiles']) == 18, 'profile count')
    require({p['profile'] for p in comparison['profiles']} == {
        'dom-method-identity', 'object-is', 'symbols', 'array-descriptors', 'reflect-construction',
        'prior-CharacterData', 'prior-PI', 'prior-production', 'node-original', 'node-exact',
        'append-exact', 'document-title', 'node-constants', 'text-operations', 'node-normalize',
        'node-predicates', 'node-root', 'node-equality'}, 'exact profile identities')
    totals = {'established': {'cases': Counter(), 'controls': Counter()}, 'new': {'cases': Counter(), 'controls': Counter()}}
    all_changes = []; reports = {}
    for profile in comparison['profiles']:
        a = json.loads(bound(profile['before'])); b = json.loads(bound(profile['after']))
        require(a['binary_sha256'] == BASE_BINARY and b['binary_sha256'] == CANDIDATE, 'raw binary binding')
        require(not b.get('binding_failures'), 'raw binding failure')
        require(not profile['header_input_changes'], 'header drift')
        for header in set(a) | set(b):
            if (header.endswith('_sha256') and header != 'binary_sha256') or header in {'bounds', 'harness', 'tool_hashes', 'revision', 'runner_policy', 'mode_cases', 'bound_inputs'}:
                require(a.get(header) == b.get(header), 'raw input header: ' + header)
        reports[profile['profile']] = (a, b)
        for kind in ['cases', 'controls']:
            left = a[kind] if kind in a else a.get('harness_preflight', [])
            right = b[kind] if kind in b else b.get('harness_preflight', [])
            stats, changes = complete_rows(left, right)
            actual = profile[kind]
            unwrap = lambda row: row.get('result', row)
            require(actual['before_status_counts'] == dict(Counter(unwrap(r).get('status') for r in left)) and
                    actual['after_status_counts'] == dict(Counter(unwrap(r).get('status') for r in right)), 'raw status counts')
            require(all(actual[k] == v for k, v in stats.items()) and actual['changes'] == changes, 'complete-row reconstruction')
            require(not actual['added'] and not actual['removed'] and not actual['input_changes'], 'raw population drift')
            totals[profile['group']][kind].update(stats)
            all_changes.extend(dict(profile=profile['profile'], kind=kind, **r) for r in changes)
    require(totals == comparison['summary'], 'summary reconstructed from complete raw rows')
    policy = read('anticipated-inventory-changes.json')
    expected = {(r['kind'], r['id'], r['mode']): r for r in policy['rows']}
    historical = [r for r in all_changes if r['profile'] != 'node-equality']
    require(len(historical) == 6, 'exact historical change count')
    for row in historical:
        require(row['profile'] == 'node-root', 'unanticipated established profile')
        expected_row = expected.pop((row['kind'], row['id'], row['mode']))
        require(row['classification'] == 'losses' and row['before'] == expected_row['before'], 'historical identity/health')
        after = row['after']
        require(after['status'] == 'failed' and after['matches_expectation'] is False, 'retained raw failure')
        require(all(after['observation'].get(k) == v for k, v in expected_row['expected_after_observation'].items()), 'Error versus TypeError')
        if row['kind'] == 'controls':
            require(after['verified'] is False and after['positive_partner_matches'] is False, 'no control-health waiver')
    require(not expected, 'all expected historical changes reached')
    require(len(policy['already_unhealthy_unchanged']) == 18, 'older unhealthy population')
    for row in policy['already_unhealthy_unchanged']:
        require(row['profile'] in {'node-constants', 'node-normalize', 'node-predicates'}, 'older profile identity')
        old_before, old_after = reports[row['profile']]
        wanted = row['before']
        require([r for r in old_before[row['kind']] if key(r) == key(wanted)] == [wanted], 'older before binding')
        require([r for r in old_after[row['kind']] if key(r) == key(wanted)] == [wanted] and not healthy(wanted), 'older unhealthy row changed')
    new_before, new_after = reports['node-equality']
    require([sum(map(healthy, r[k])) for r in [new_before, new_after] for k in ['cases', 'controls']] == [0, 4, 32, 16], 'new ordinary and paired control health')
    current_profile = next(p for p in comparison['profiles'] if p['profile'] == 'node-equality')
    require(raw('equality-after.json') == bound(current_profile['after']), 'current oracle raw report cross-binding')
    require(new_after['binary_sha256'] == CANDIDATE, 'current oracle candidate cross-binding')
    for kind, count, before_health, after_health, losses in [
        ('cases', 4300, 4208, 4206, 2), ('controls', 492, 480, 476, 4)]:
        stats = totals['established'][kind]
        require(stats['before_total'] == stats['after_total'] == count, 'established population')
        require(stats['before_healthy'] == before_health and stats['after_healthy'] == after_health, 'raw established health')
        require(stats['unchanged'] == count-losses and stats['losses'] == losses and
                stats['gains'] == stats['other_changes'] == 0, 'only exact established losses')
    for kind, count, before_health in [('cases', 32, 0), ('controls', 16, 4)]:
        stats = totals['new'][kind]
        require(stats['before_total'] == stats['after_total'] == stats['after_healthy'] == count,
                'new complete population')
        require(stats['before_healthy'] == before_health and stats['gains'] == count-before_health and
                stats['unchanged'] == before_health and stats['losses'] == stats['other_changes'] == 0,
                'new exact gains and unchanged controls')
    for report in [new_before, new_after]:
        controls = {r['id']: r for r in report['controls']}
        for row in report['controls']:
            partner = controls[row['partner']]
            require(partner['positive'] is True and partner['mode'] == row['mode'] and
                    partner['pair'] == row['pair'], 'same-mode positive partner')
            def observation_matches(r):
                observation = r.get('observation', {})
                return isinstance(observation, dict) and all(observation.get(k) == v for k, v in r['expected_observation'].items())
            matches = observation_matches(row)
            partner_matches = observation_matches(partner)
            require(row['matches_expectation'] is matches and row['positive_partner_matches'] is partner_matches,
                    'independent raw control matches')
            require(row['verified'] is (matches and partner_matches), 'independent paired control health')
    for mode in ['sloppy', 'strict']:
        case = next(r for r in new_after['cases'] if r['id'] == 'represented_complete_key_order#' + mode)
        require(healthy(case), 'current pristine inventory')
        for variant in ['positive', 'wrong']:
            control = next(r for r in new_after['controls'] if r['id'] == 'represented-node-order-' + variant + '#' + mode)
            require(healthy(control) and control['positive_partner_matches'] is True, 'current reflected-order pair')
    annotation = read('inventory-classification.json')
    require(annotation['comparison_sha256'] == INPUTS[str(B / 'equality-comparison.json')]['sha256'], 'annotation comparison binding')
    require(annotation['policy_sha256'] == INPUTS[str(B / 'anticipated-inventory-changes.json')]['sha256'], 'annotation policy binding')
    require(annotation['expected_case_losses'] == 2 and annotation['expected_unhealthy_controls'] == 4 and annotation['unexpected_established_changes'] == 0, 'annotation totals')
    for label, expected_exit in [('replay-jobs', 1), ('comparison', 0), ('inventory-classification', 0)]:
        command(label + '-command.json', expected_exit)
    replay_receipts = sorted(B.glob('*-replay-command.json'))
    require(len(replay_receipts) == 18, 'replay command population')
    for path in replay_receipts:
        command(path.name, 1 if path.name in {'node-constants-replay-command.json', 'node-normalize-replay-command.json', 'node-predicates-replay-command.json', 'node-root-replay-command.json'} else 0)
    for profile in ['symbols', 'array-descriptors', 'reflect-construction']:
        command(profile + '-command.json', 0)
    for label, code in [('equality-baseline', 1), ('equality-verify', 0), ('compare-before', 0), ('classify-before', 0)]:
        command(label + '-command.json', code)
    expected_commands = {p.name for p in replay_receipts} | {p + '-command.json' for p in [
        'symbols', 'array-descriptors', 'reflect-construction', 'replay-jobs', 'comparison',
        'inventory-classification', 'equality-baseline', 'equality-verify', 'compare-before', 'classify-before']}
    actual_commands = {p.name for p in B.glob('*-command.json')}
    require(actual_commands == expected_commands, 'unreviewed command receipt inventory: ' + repr(actual_commands ^ expected_commands))
    return dict(summary=comparison['summary'], profiles=18, complete_historical_changes=historical,
                preserved_older_unhealthy_rows=18, aggregate_exit=1, comparison_exit=0, classifier_exit=0,
                release_sha256=CANDIDATE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True, help='Actual announced release SHA256; no engine is run.')
    args = parser.parse_args()
    global CANDIDATE
    require(re.fullmatch(r'[0-9a-f]{64}', args.binary_sha256), 'invalid release SHA256')
    CANDIDATE = args.binary_sha256
    require(not args.output.exists(), 'audit output must be new')
    report = dict(status='incomplete', findings=[], execution='Only byte/JSON/log parsing; no engine, compiler, helper import or subprocess.')
    try:
        raw(Path(__file__))
        report['validation'] = validation()
        report['comparison'] = comparisons()
        for path, expected in list(INPUTS.items()):
            data = Path(path).read_bytes()
            require(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) == expected, 'post-audit input drift: ' + path)
        report['status'] = 'clear'
    except Exception as error:
        report['status'] = 'failed'
        report['findings'].append(dict(type=type(error).__name__, message=str(error)))
    report['commands'] = COMMANDS
    report['nonzero_commands'] = {p: r for p, r in COMMANDS.items() if r['exit'] != 0}
    report['inputs'] = [{'path': path, **binding} for path, binding in sorted(INPUTS.items())]
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k not in {'inputs', 'comparison', 'commands'}}, indent=2))
    return 0 if report['status'] == 'clear' else 1


if __name__ == '__main__':
    raise SystemExit(main())
