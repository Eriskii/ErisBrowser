from pathlib import Path
import hashlib,json,subprocess,time
B=Path(__file__).resolve().parent
P=Path('/tmp/eris-node-equality-preparation-1/replay')
binary=Path('/tmp/eris-node-root-1/eris-js');expected='3198cd31112100406a47052d3bc179924435c9711ec9f37a5240939572fa6834'
assert hashlib.sha256(binary.read_bytes()).hexdigest()==expected
assert json.loads((P/'layout-source-review.json').read_text())['status'].startswith('clear')
for label,args,wanted in [('equality-verify',['python3',str(P/'replay.py'),'--verify'],0),('equality-baseline',['python3',str(P/'replay.py'),str(binary),expected,str(B/'equality-before.json')],1)]:
 log=B/(label+'.log');started=time.monotonic()
 with log.open('xb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 record=dict(command=args,exit=r.returncode,elapsed_seconds=time.monotonic()-started,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 with (B/(label+'-command.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
 print(json.dumps(record),flush=True)
 assert r.returncode==wanted,log.read_text()[-1000:]
