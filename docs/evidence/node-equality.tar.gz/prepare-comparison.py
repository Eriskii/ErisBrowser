from pathlib import Path
import ast,hashlib,json,re,shutil,subprocess
B=Path(__file__).resolve().parent;P=Path('/tmp/eris-node-equality-preparation-1');OLD=Path('/tmp/eris-node-root-1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 with (B/name).open('x')as f:json.dump(value,f,indent=2);f.write('\n')
def binding(name):
 p=B/name;return dict(path=name,bytes=p.stat().st_size,sha256=sha(p))
baseline=json.loads((B/'equality-before.json').read_text())
assert len(baseline['cases'])==32 and len(baseline['controls'])==16 and not baseline['binding_failures']
assert all(x['observation']['status']=='exception' and x['observation']['phase']=='runtime' and x['observation']['error_type']==x['observation']['error_identity']=='TypeError'for x in baseline['cases'])
assert sum(x['verified']for x in baseline['controls'])==4
# Snapshot fixed independent/replay/root preparation only. Mutable Runtime/browser
# plans and new peer drafts are retained additively after their own later holds.
def excluded(directory,names):
 return [n for n in names if n=='__pycache__' or Path(directory)==P and n in {'runtime','layout','browser'}]
shutil.copytree(P,B/'preparation',ignore=excluded)
files=['base.json','before-comparison-inputs.json','baseline-review.json','equality-before.json','equality-baseline-command.json','equality-baseline.log','equality-verify-command.json','equality-verify.log','preparation/replay/source-ready.json','preparation/replay/replay.py','preparation/replay/replay-inputs.json','preparation/replay/replay-matrix.json','preparation/replay/preparation-history.json','preparation/replay/inert-verification.json','preparation/replay/layout-source-review.json','preparation/independent/cases.js','preparation/independent/controls.json','preparation/root/independent-source-review.json']
config=dict(base='51907b7b6b3a7465c7a2605f3762375ddaa97a26',baseline_release_sha256=baseline['binary_sha256'],established_cases=4300,established_controls=492,new_cases=32,new_controls=16,files=[binding(n)for n in files]);write('compare-equality-inputs.json',config)
s=(OLD/'compare-root.py').read_text().replace('compare-root-inputs.json','compare-equality-inputs.json')
s=re.sub(r"INPUT_SHA = '[0-9a-f]{64}'","INPUT_SHA = '"+sha(B/'compare-equality-inputs.json')+"'",s)
needle="('node-root', 'root-after.json', 32, 16, 'new'),";assert s.count(needle)==1
s=s.replace(needle,"('node-root', 'root-after.json', 32, 16, 'established'),\n    ('node-equality', 'equality-after.json', 32, 16, 'new'),").replace("if name == 'node-root':","if name == 'node-equality':").replace('complete-node-root-replay-comparison','complete-node-equality-replay-comparison').replace("'root-comparison.json'","'equality-comparison.json'")
(B/'compare-equality.py').write_text(s)
def funcs(s):return {n.name:ast.dump(n,include_attributes=False)for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
a=funcs((OLD/'compare-root.py').read_text());c=funcs(s)
for name in ['underlying','identity','input_record','healthy','compare_rows','controls']:assert a[name]==c[name]
previous=json.loads((B/'comparison-before/root-after.json').read_text())
policy=dict(profile='node-root',reason='New ordinary isEqualNode invalidates the former complete27-key inventory. Frozen sources/expectations retain raw health; annotate only exact anticipated losses.',rows=[],already_unhealthy_unchanged=[])
for kind in ['cases','controls']:
 for row in previous[kind]:
  if row['id'].startswith('represented_complete_key_order#') or row['id'].startswith('represented-node-order-'):
   assert row['matches_expectation'] is True
   policy['rows'].append(dict(kind=kind,id=row['id'],mode=row['mode'],before=row,expected_after_observation=dict(status='exception',phase='runtime',error_type='Error'if kind=='cases'else'TypeError',error_identity='Error'if kind=='cases'else'TypeError')))
assert len(policy['rows'])==6
for profile,filename in [('node-constants','node-constants-after.json'),('node-normalize','normalize-after.json'),('node-predicates','predicates-after.json')]:
 report=json.loads((B/'comparison-before'/filename).read_text());count=0
 for kind in ['cases','controls']:
  for row in report[kind]:
   if row.get('matches_expectation')is False:
    policy['already_unhealthy_unchanged'].append(dict(profile=profile,filename=filename,kind=kind,id=row['id'],mode=row['mode'],before=row));count+=1
 assert count==6
write('anticipated-inventory-changes.json',policy)
s=(OLD/'classify-inventory.py').read_text();s=re.sub(r"EXPECTED='[0-9a-f]{64}'","EXPECTED='"+sha(B/'anticipated-inventory-changes.json')+"'",s)
s=s.replace("B/'comparison-before/predicates-after.json'","B/'comparison-before/root-after.json'")
s=s.replace("len(policy['already_unhealthy_unchanged'])==12","len(policy['already_unhealthy_unchanged'])==18")
s=s.replace("'root-comparison.json'","'equality-comparison.json'").replace("['node-constants','node-normalize']","['node-constants','node-normalize','node-predicates']")
s=s.replace("('cases',4178,4176),('controls',468,464)","('cases',4208,4206),('controls',480,476)").replace("('cases',4268,2),('controls',476,4)","('cases',4300,2),('controls',492,4)")
s=s.replace("current_path=B/'root-after.json'","current_path=B/'equality-after.json'").replace("x['profile']=='node-root'","x['profile']=='node-equality'")
s=s.replace('Six predicate inventory assumptions are invalidated by getRootNode. Older Node and Normalize inventory failures remain unchanged. Raw losses and unhealthy controls retain their health; no waiver.','Six root inventory assumptions are invalidated by isEqualNode. Older Nodeconstant, Normalize and Predicate inventory failures remain unchanged. Raw losses and unhealthy controls retain their health; no waiver.')
(B/'classify-inventory.py').write_text(s)
s=(OLD/'replay-jobs.py').read_text();marker='def run(job):';assert s.count(marker)==1
s=s.replace(marker,"jobs.append(('node-equality',['python3','/tmp/eris-node-equality-preparation-1/replay/replay.py',str(BINARY),sha,str(OUT/'equality-after.json')]))\n"+marker);(B/'replay-jobs.py').write_text(s)
(B/'formal-check.py').write_bytes((OLD/'formal-check.py').read_bytes())
for label,script in [('compare-before','compare-equality.py'),('classify-before','classify-inventory.py')]:
 log=B/(label+'.log');args=['python3',str(B/script),'--verify-before']
 with log.open('xb')as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 write(label+'-command.json',dict(command=args,exit=r.returncode,log=log.name,sha256=sha(log)));assert r.returncode==0,log.read_text()
files=['before-comparison-inputs.json','compare-equality-inputs.json','compare-equality.py','replay-jobs.py','formal-check.py','anticipated-inventory-changes.json','classify-inventory.py','prepare-comparison.py','equality-before.json','compare-before-command.json','compare-before.log','classify-before-command.json','classify-before.log']
ready=dict(phase='Prepared after single published-root baseline and before equality implementation/candidate compiler',files=[binding(n)for n in files],established_cases=4300,established_controls=492,new_cases=32,new_controls=16,baseline_healthy_cases=4208,baseline_healthy_controls=480,expected_new_historical_losses=dict(cases=2,controls=4),older_unhealthy_unchanged=dict(cases=6,controls=12),profile_count=18,runner_path='Original absolute preparation driver paths required; copies are archival only',aggregate_runner='Expect1 from olderNode/Normalize/Predicate and newly staleRoot profiles; retain raw nonzero exits and independently classify exact differences')
write('comparison-preparation-ready.json',ready);print('Prepared18profiles; data-only before checks passed')
