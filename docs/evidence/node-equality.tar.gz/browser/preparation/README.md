# Proposed isEqualNode Page and worker witness

Source-only browser preparation against published predecessor
`51907b7b6b3a7465c7a2605f3762375ddaa97a26`, bound separately in
`../root/published-base.json`. The getRootNode release is
`3198cd31112100406a47052d3bc179924435c9711ec9f37a5240939572fa6834`.
No equality implementation, baseline outcome, compiler, browser, parser or engine
execution is asserted. These files remain scratch-only; no integration is made.

The fixture compares a connected `div` with a detached peer built independently
from literal element names, reversed attribute insertion order, two nested Text
nodes and one exact Comment. It does not clone or serialize the live branch to
manufacture an expected peer. Both comments retain `[114,97,119,55296]`, requiring
eight bytes in canonical nonscalar storage; they never paint. Differing own JS
properties, a saved native method and a callable own shadow do not change the
native structural comparison.

Load proves genuine equal and unequal Text calls before any feature assertion.
The initial branch and peer compare equal in both directions. A real `#change`
click performs three explicit stages:

1. Replace only the peer Comment's final unmatched unit with U+FFFD; equality
   must become false, then become true after restoring U+D800.
2. Change only the peer's existing `data-note` value; equality must become false,
   then become true after restoring `base`.
3. Change the connected second Text from literal ` beta` to ` gamma`; equality
   must become false until the independent peer's Text is changed to ` gamma`.

The literal completion trace is `data;attribute;visible;`. Final verification
precedes title/status updates and the blue body class. The fixture has no expected
exception catches. A missing method, incorrect comparison, thrown callback or
Resource refusal cannot satisfy the expected title and marker state by accident.
Equality itself is read-only; the authored Text, attribute and class writes cause
the visible updates. No equality-induced layout invalidation is claimed.

Template coverage compares a connected template and independent detached template
with matching ordinary Text children and equal scalar attributes, but different
actual content Texts (`inside` versus `different`). The elements must compare
equal while their content fragments compare unequal. The actual hosted content
fragment also compares equal to an independently built unhosted fragment with
literal `inside`. This checks ordinary children and fragment host exclusion,
without ShadowRoot or implicit template traversal claims.

The helper uses public `Document`, `NodeKind`, layout and canvas APIs only. Its
`State` retains 29 explicit distinct IDs and the whole arena count. Both phases
check literal element/attribute/child vectors, reciprocal parent links, Text and
Comment units, fixed base URL, template hosts, content identities and the detached
peer roots. Detached peers are located by unique parentless literal IDs; the
unhosted fragment is located by its unique ordinary `inside` Text child. No
Runtime-private object bag or serialized JavaScript handle is used as a Rust
oracle. Worker snapshots retain node IDs under the existing protocol; the
proposed worker test must use the same real worker realm across load and click.

The whole-canvas reference is an independently authored script-free scalar page
with two separate span/Text nodes: `Alpha` and ` beta` on load, `Alpha` and
` gamma` after click. It omits only nonpainting bookkeeping nodes. Literal green
and blue marker pixels, nonempty glyph bands, exactly one `Alpha`, expected tail
and status DrawCommand, and absence of the other tail prevent vacuous equality.
The helper never copies or projects observed actual data into the reference.
There is no cross-node surrogate shaping assertion.

Public helper API is `HTML`, `State`, `metadata(phase)` and
`check(doc, layout, images, fonts, phase, previous) -> State`. Proposed integration
is one Page test and one confined-worker test: viewport 320×240, URL
`https://equality.example/page/index.html`, initial render, real click at `#change`,
second render with prior State. Titles must be `Equality ready` and
`Equality done`, and diagnostics must remain empty apart from the existing
worker protocol allowances. Root owns integration and will reserve its worker
generation separately; no generation is guessed here.

All click operations update existing node data or existing attributes. There is
no click-time DOM node creation, append, clone or parsing. Detached peers and
template branches remain retained. Runtime allocations for comparison traversal,
JS expressions and mutation strings still consume ordinary budgets. Feasibility
has not been measured, and ordinary success expectations must remain unchanged
if a future run exposes a limit.

Rust formatting was applied only to the helper. Data-only static checks verify
equal literal CSS blocks, actual single JavaScript Unicode escapes, the 29 ID
expressions, and absence of node-creation syntax in the click body. An initial
ID-count regex selected the earlier struct type declaration; scoping it to the
literal State initializer corrected that inspection without changing fixture or
helper bytes. No HTML/JS parser or runtime was used.

References: [DOM node equality](https://dom.spec.whatwg.org/#concept-node-equals),
[isEqualNode](https://dom.spec.whatwg.org/#dom-node-isequalnode), and
[template contents](https://html.spec.whatwg.org/multipage/scripting.html#template-contents).
