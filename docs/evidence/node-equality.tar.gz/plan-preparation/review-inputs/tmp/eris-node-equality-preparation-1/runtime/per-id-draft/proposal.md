# Concrete represented Node.isEqualNode Runtime proposal

Status: source-only plan for review. Root selected the scope after feasibility; implementation, executable fixtures, compiler and engine execution remain unauthorized in this preparation task. The anticipated predecessor is the held getRootNode candidate final18 manifest, not a published checkpoint. Its source and observed bootstrap log are bound separately below; a later public-base receipt must be additive.

## Scope and public installation

Provide one ordinary cached Node.prototype.isEqualNode operation with name isEqualNode, length 1, Function.prototype, writable/enumerable/configurable owner property, and no construction route. Install it after normalize and before isSameNode. All currently represented node kinds participate; the fixed HTML/SVG/MathML namespace and attribute model is part of the scope. No storage, parser, wire, renderer, DOM mutation, virtual cloneNode, general namespace or cross-document expansion is included. Equal template elements ignore hosted contents; explicit fragment operands compare ordinary children. The primary and representation rationale remains in the separate held feasibility assessment.

Proposed Runtime entry: `node_is_equal_node(&mut self, receiver: Value, args: &[Value], doc: &Document) -> Result<Value>`. Reuse paid authentic conversion `node_predicates::node_id`. Broaden only visibility of its existing `predicate_argument` method to reuse required/nullable interface conversion unchanged. No generic JS comparison, property getter, conversion hook, prototype search or callback is performed by the body.

The existing DOM.Node cached factory and invocation preflight are sufficient. isEqualNode and getRootNode share suffix length 11: keep the length discriminator debit, pay the current first 11-unit comparison against getRootNode and return on match. For the unmatched branch only, pay another 11 before comparing isEqualNode. Other length arms and the accessor fallback stay byte-for-byte in behavior. Update the distinct-length comment. Equality's temporary full native name is 20 bytes: existing cleanup-protected copy costs 24 work/52 bytes; suffix dispatch is 23 work, total scoped pre-body work 47. Common VM call charges remain additional. Existing getRootNode still pays 36 scoped pre-body work/52 bytes.

## Receiver, argument, and chosen fast paths

Pay 16 before authentic receiver conversion. `predicate_argument` pays 4 before required arity and 12 before nullable/interface conversion. Missing argument throws TypeError, explicit null/undefined yields null, other non-Nodes throw without hooks. Extra argument expressions run normally but extra values are not converted.

For null pay 2 and return false; body total 34, no owned body heap. For non-null operands, run the equality-local check on each ID, charging 16 per node. It may reuse `local_node` after admission, then additionally require that a selected ID equal to doc.root really has Document kind; for an Element, check attrs <=1024, metadata <= attrs and metadata <=11. The existing checks enforce arena/children counts, the unique root Document, parentless fragments and childless leaves. This is O(1) local header validation; it does not inspect descendant entries or namespace-map contents. Pay 2 to compare canonical IDs. If equal, return true without descendant/payload/attribute-content audit; body total 66. This is the selected reflexive fast path, not a validity certificate.

For distinct IDs, compare local fields. No same-ID shortcut is used for later child pairs; those pairs remain subject to per-side reached tracking and their selected subtree walk. A null result, early mismatch or top-level self result need not validate unvisited state. Invalid data actually consumed is an explicit TypeError, never a guessed boolean. Arithmetic/work/storage refusal is Resource.

## Borrowed field comparison helpers

Keep helpers private to the new module. No payload ownership is created.

- `equality_bytes(left: &[u8], right: &[u8]) -> Result<bool>`: pay 8 before lengths; unequal lengths return false. Equal lengths n pay checked `1 + 4*n` before borrowed slice equality. This conservatively covers both loads, comparison/advance work and endpoint handling. It deliberately admits the complete equal-length field before learning an early mismatch.
- `equality_units(left: &[u16], right: &[u16]) -> Result<bool>`: the same 8 plus, only for equal lengths, `1 + 4*n`, using native u16 slices. These are logical unit operations, not a wall-clock claim.
- `equality_key_order(left: &[u8], right: &[u8]) -> Result<Ordering>`: pay 8 plus checked `1 + 4*min(left.len(),right.len())` before borrowed lexicographic comparison, including terminal length ordering. This is used only to align namespace side-map keys with attribute keys.
- `equality_data(left: &DomString, right: &DomString) -> Result<bool>`: pay 8 before inspecting canonical variants. Scalar pairs delegate to bytes; Units pairs to units. Mixed variants return false with no payload scan. Private canonical Storage, validated constructors and codec admission make this equivalent to exact UTF-16 equality. No MAX_STRING restriction or replacement projection applies.

`equality_fields(left: &Node, right: &Node) -> Result<bool>` pays 16 for kind dispatch, child-count checks, fixed field selection and enum/header comparisons. Check kind and child count first; mismatches return false immediately. For matching kinds:

| Kind | Additional paid comparisons |
| --- | --- |
| Document / DocumentFragment | None. Host, URL/mode and runtime state are excluded. |
| Text / Comment | equality_data on the exact retained data. Different kinds never reach this row. |
| PI | equality_bytes for target, then equality_data for data if the target matched. No creation validation. |
| Doctype | Three equality_bytes calls for name and IDs; borrow absent IDs as empty. Ignore force_quirks. |
| Element | Namespace enum in the fixed header; then equality_bytes on tag; then the attribute helper. Prefix is implicitly null in this representation. |

No new interface-index search is needed: matching kind and equal Element namespace/tag imply equal native interface mapping in the current static model. Mutable prototypes and public getters do not enter this proof. A distinct pair with a kind or child-count mismatch costs body 82 and no owned heap. Matched exact Text leaves add the chosen data/byte or unit comparison rows; no traversal maps/cursor are created.

## Attributes without copied or quadratic matching

Use two stack-only borrowed cursors, one per Element. Each holds attrs.iter(), attr_namespaces.iter(), a namespace lookahead and the precomputed heights. A yielded row is borrowed key/value plus Option<AttributeNamespace>. Nothing persists across the containing field comparison, and no attribute/URI/key String is created.

The fixed qualified-key roster is injective by namespace/local-name pair; absent metadata means the whole key in null namespace. Thus matching sorted qualified-key/value rows with matching annotations implements unordered semantic attribute equality for this model. The annotation must still be checked when consumed. If this storage model later admits aliases or collisions, this algorithm must change rather than silently preserving qualified-name equality.

The attribute helper pays 32 for setup, count comparisons, checked bounded-height calculations and cursor control. Different attr counts or metadata counts return false before creating iterators. Equal counts continue. Compute H(n) by the existing conservative BTree height convention: 0 when n=0, otherwise start at 1 with floor((n+1)/2), incrementing per division by 6 while that capacity is at least 6. Attribute count <=1024 implies H<=4; annotations <=11 imply H<=1.

Define iterator admission I(n)=8+8*H(n). Charge I before creating each of the four borrowed iterators, and before every actual next(), including the initial namespace lookahead loads and attempted EOF reads. Iter creation/advance can descend or climb bounded tree height without allocation; this per-call allowance avoids an unproved amortized-prefix assumption. Dropping borrowed iterators does not walk or free the backing maps. A peer must bind the pinned standard-library iterator path before implementation approval; the source receipt will record the actual proof.

Each cursor row extraction pays 8 for lookahead/EOF/branch handling in addition to actual next() fees. On attr EOF, any remaining namespace lookahead is dangling metadata and errors. On an attr row with lookahead, call equality_key_order(namespace_key, attr_key). Less is dangling metadata and errors; greater emits None without advancing the namespace iterator; equal validates the namespace roster before consuming lookahead and emitting Some(namespace).

Roster admission is a fixed 162: 8 setup plus 11 comparisons bounded by 1+13 units each. The actual from_qualified_name roster has 11 ASCII spellings of maximum length 13. Length-based string comparisons reject longer host keys without scanning their arbitrary suffix. After paying, require the returned namespace to match the stored enum; otherwise TypeError. Each consumed annotation then advances the side iterator with its own I fee.

The paired attribute loop pays 8 before each iteration (including its final EOF decision). Obtain each cursor row with its own fees. For two rows, compare qualified keys through equality_bytes, then pay 4 for namespace enum/branch comparison, then compare values through equality_bytes. Return false at the first mismatch. An EOF asymmetry is invalid because known row counts matched; both EOF is true. All performed string comparisons, side-map alignments and iterator steps are paid. Malformed unvisited annotations after an earlier mismatch are outside this local policy.

## Paired DFS and reached-ID admission

After distinct-root local fields match, return true immediately when child count is zero. Otherwise allocate lazily: two `BTreeMap<NodeId, ()>` reached maps and `Vec<EqualityFrame>`, where the Copy frame has exactly left ID, right ID and next-child index. Mark both roots separately, then push the initial frame. There are no cloned nodes, snapshots, pending all-sibling arrays, payload copies or whole-arena bitmap.

Each loop iteration pays 8 before reading the last frame, comparing its cursor with the immutable child count, incrementing/resuming it, or finishing it. A completed frame pops using prepaid removal allowance. Before selecting a child pair pay 16 for the two child-array reads, checked depth/cursor arithmetic, bounded IDs and reciprocal backlink checks. Reject selected doc.root/Document or Fragment as a child; reject selected Doctype under a parent other than doc.root. Document-parent Text remains admitted. Child depth is frames.len(); reject >256 while accepting exactly256. No ancestry is walked above operand roots.

Run both 16-work local header checks, mark each child's ID in its own side map, then call equality_fields. A repeated ID on a side errors before comparing that node. Cross-side overlap is permitted. False returns immediately with maps/frames destroyed under already paid allowances; no mutation has occurred. A matched nonempty container gets a frame, otherwise resume its parent. At final exhaustion, true needs no additional tree pass.

Private `equality_mark` should mirror the reviewed Normalize Entry algorithm rather than change Normalize production in this increment. For current count n, let H use the same convention, L=H+1 and C=min(n,11*H). Pay 16 before count planning and checked arithmetic; require n<MAX_NODES. Pay C+44*L+4 before the single Entry operation, covering search, conservative splits/moves/headers and eventual map destruction. A prospective BTree block is B_id=16*(sizeof(NodeId)+sizeof(()))+32*sizeof(usize)+64. Charge A(n)*B_id before entry, with A=1 for n=0, A=0 for 1..10, and A=L thereafter. Vacant inserts; Occupied errors. Both sides are independently charged, and failed/unused prospective allowance is not refunded. Standard BTree allocation remains an inherited infallible process-OOM boundary despite logical quota admission.

Private frame push prepays 5 before any length rejection: one push, two eventual pop/cleanup operations and two conservative buffer-release operations. Require current len<257. On actual capacity exhaustion, choose new_capacity=max(len+1,min(2*capacity,257)) with checked arithmetic. Pay 1+6*len for the possible relocation of three usize fields (read/write per field), charge new_capacity*sizeof(EqualityFrame), then try_reserve_exact(new_capacity-len) before push. On capacity reuse only the fixed 5 applies. Existing capacity remains cumulatively charged; no refund after drop. Stack headers and borrowed cursors are fixed-size native state, not owned traversal buffers. Do not call this body heap-free once DFS starts.

This design has O(V log V) reached bookkeeping plus paid field/string/attribute comparisons and bounded active-depth cursor storage. Attribute iteration uses a conservative per-next height bound. It intentionally may hit the unchanged 100000-work/8MiB limits on a large tree before exhausting structural DOM limits. Early mismatch stops actual traversal; complete-field comparison admission may still cover untouched tails within that field. There is no claim of unconstrained standard completion on every admitted 32MiB tree.

## Conditional bootstrap delta

Relative only to the bound, still-unpublished root candidate:

| Work row | Added work |
| --- | ---: |
| One cached function factory | 127 |
| isEqualNode owner key/text at count6 | 117 |
| New installer entry | 4 |
| Existing isSameNode count6 to7 | 12 |
| Existing contains count7 to8 | 10 |
| N26 to N27 constant batch | 232 |
| Later Node constructor property | 0 |
| Total | 502 |

The factory is 9+30+29+31+28. Owner117 is text30 plus insertion6*12+14+1. Batching now has prototype old9/map27/order28 versus constructor old3/map21/order21. N27 has 78 full comparisons at42=3276 and structure642, map3918; owner828. Constructor3030/300 remains unchanged. Batch total9660, delta232. Both overflows remain at12/24 with height1/four prototype nodes. Last leaf length3 requires two-pair repair; existing64 repair,32 navigation,32 headers and48E sort scratch are retained. All guards/charges/reservations still precede both takes; post-take invariant failures discard the incomplete initializer, both completed maps publish together.

Batch storage is 14820+18K+144E+7B, delta E. Overall metadata adds `1360+(S+A+D+N)+3K+B+E`, using the existing definitions K=sizeof(PropertyKey), E=sizeof((PropertyKey,Property)), B=16*(K+sizeof(Property))+32*sizeof(usize)+64, S=sizeof(ScriptObject), A=sizeof(Option<AbortSlot>), D=sizeof(Option<f64>), N=sizeof(Native). Prior 64-bit sizes infer3256 additional bytes. Bound root bootstrap observed8318work remaining/1758971bytes/686objects would therefore predict7816/1762227/687, with native registry321/legacy prototypes25 unchanged. These are conditional equality predictions, never measurements. Rebind to the eventual published source and actual type sizes before updating descriptive tests.

## Planned paths and evidence

Likely Runtime ownership: module declaration; new node_equality.rs/private tests; predicate_argument visibility; node_data dispatch; dom_prototypes capacity/order/install; node_constants production/tests; historical private wrapper adjustments in constants/normalize/predicates/root plus current node_data partial-order witness; independently held new fixture copied exactly. Root owns later measured bootstrap assertions and browser/evidence integration. No source file is changed by this plan.

Preserve every old JS fixture byte-exact. Update clearly named disposable wrappers by removing/restoring the later configurable equality method before invoking their original literal inventory, with descriptor identity/flags checked. Add such a wrapper for the old root complete-inventory case. Descriptor restoration changes order, so discard those realms. Independent current equality cases/control sources must assert the pristine28-key inventory before first execution. Retain old unhealthy outcomes and newly outdated root inventory losses separately; derive aggregate counts from actual frozen matrices rather than assuming universal control health.

Private coverage must measure, not copy fee formulas: null/self/root and leaf exact boundaries with zero body heap; first differing kind/count/tag/value; canonical scalar/exact-unit differences and long prefixes; semantic attribute insertion order/annotations plus malformed reached metadata; doctype None/empty/force_quirks; exact PI data without creation checks; template ignored links versus explicit contents; argument expressions, brands/no hooks and arbitrary public property poison; accepted256 edges and an extra host edge; repeated IDs on each side, cross-side overlap, cycles/backlinks; frame growth and both map admissions with unchanged Document/capacities at every refusal; saved call work/heap cuts and cleanup; unrelated-arena independence; and two live metadata bags. Keep terminal Resource catch/finally behavior and completed argument effects visible. No executable private or independent fixture is authored in this plan.
