"""Data-only arithmetic; does not import or invoke an engine/compiler/runner."""
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent


def height(count):
    if count == 0:
        return 0
    height_value = 1
    capacity = (count + 1) // 2
    while capacity >= 6:
        height_value += 1
        capacity //= 6
    return height_value


def stream(ids, vacancy_multiplier=256, vacancy_fixed=32):
    pages = {}
    work = heap = vacant = occupied = 0
    for node_id in ids:
        assert 0 <= node_id < 100000
        count = len(pages)
        assert count <= 1563
        levels = height(count) + 1
        work += 16 + min(count, 11 * height(count)) + 8 * levels + 4
        page, bit = divmod(node_id, 64)
        assert page < 1563
        mask = 1 << bit
        if page in pages:
            work += 8
            assert pages[page] & mask == 0
            pages[page] |= mask
            occupied += 1
        else:
            assert count < 1563
            work += vacancy_multiplier * levels + vacancy_fixed
            blocks = 1 if count == 0 else 0 if count <= 10 else levels
            heap += blocks * 576
            pages[page] = mask
            vacant += 1
    return dict(work=work, heap=heap, pages=len(pages), vacant=vacant, occupied=occupied)


def calculate(multiplier=256, fixed=32):
    rows = []
    for layout in ('contiguous', 'alternating', 'sparse'):
        for residue in range(64):
            base = 64 + residue
            if layout == 'contiguous':
                left_ids = [base + i for i in range(257)]
                right_ids = [base + 257 + i for i in range(257)]
            elif layout == 'alternating':
                left_ids = [base + 2*i for i in range(257)]
                right_ids = [base + 2*i + 1 for i in range(257)]
            else:
                left_ids = [base + 128*i for i in range(257)]
                right_ids = [base + 128*i + 64 for i in range(257)]
            left = stream(left_ids, multiplier, fixed)
            right = stream(right_ids, multiplier, fixed)
            rows.append(dict(layout=layout, base_residue_mod64=residue, left=left,
                             right=right, body_work=36917 + left['work'] + right['work'],
                             body_heap=12264 + left['heap'] + right['heap']))
    summary = {}
    for layout in ('contiguous', 'alternating', 'sparse'):
        selected = [row for row in rows if row['layout'] == layout]
        summary[layout] = dict(
            minimum_body_work=min(row['body_work'] for row in selected),
            maximum_body_work=max(row['body_work'] for row in selected),
            minimum_body_heap=min(row['body_heap'] for row in selected),
            maximum_body_heap=max(row['body_heap'] for row in selected),
            fits_100000_work=max(row['body_work'] for row in selected) <= 100000,
            maximum_pages_per_side=max(max(row['left']['pages'], row['right']['pages']) for row in selected))
    return dict(status='Data-only arithmetic predictions, not engine execution; fixed simple trees only',
                geometry='Each side is one Fragment root, 255 empty-attribute div elements, one Text x leaf: 257 nodes / 256 edges; distinct IDs',
                fixed_body_work=36917, frame_bytes_at_64bit=12264,
                frame_size_assumption=24, B_page_assumption=576,
                scope='Excludes source parsing, construction and generic invocation; add 47 work / 52 bytes for the existing scoped name copy/dispatch plus other VM charges',
                summary=summary, rows=rows, vacant_work=f'{multiplier}*(H(q)+1)+{fixed}')


# Reproduce every numeric row of the retained first 96L+16 draft before emitting
# the revised prediction. This preserves the comparison independently of prose.
prior = json.loads((HERE/'initial-sparse-96/depth-costs.json').read_text())
assert calculate(96, 16)['rows'] == prior['rows']
assert calculate(96, 16)['summary'] == prior['summary']
result = calculate()
(HERE/'depth-costs.json').write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps(result['summary'], indent=2))
