# Node.isEqualNode

This increment is being implemented for represented nodes. Candidate execution,
measured accounting and validation results remain pending. This chapter records
the reviewed scope and admission plan; it does not report candidate success.

The ordinary `Node.prototype.isEqualNode(other)` method compares internal node
fields and ordered ordinary children. Equal nodes can have different identities,
parents, connection states, own JavaScript properties and rendering state.
Neither cloning nor serialization is used to decide equality.

## Receiver and argument rules

The receiver must be an authentic represented Node. Its brand is checked before
the required nullable Node argument. Omitting the argument throws TypeError;
explicit `null` or `undefined` returns false. Other non-Nodes throw without
calling `toString`, `valueOf` or `Symbol.toPrimitive`. Inheriting from
`Node.prototype` does not create a Node brand. Authentic nodes produced through
the supported alternate-constructor-prototype path retain their brand.

Argument expressions, including extra arguments, finish before native
invocation. Their mutations and thrown values retain their normal order. Once
invoked, the comparison body uses internal data without authored getters,
conversion hooks or callbacks. Authored shadows of `nodeType`, `childNodes`,
data fields or the method itself do not change a saved native call's operands.

## Equality within the represented model

Different kinds or child counts are unequal. Matching kinds compare these fields
before traversing children:

| Kind | Equality fields |
| --- | --- |
| Document and DocumentFragment | Ordered ordinary children; document URL/mode and fragment host are excluded. |
| Text and Comment | Exact retained UTF-16 data, with the two kinds remaining distinct. |
| ProcessingInstruction | Case-sensitive scalar target and exact retained data, without rerunning creation validators. |
| DocumentType | Name, public ID and system ID; absent optional IDs compare as empty strings, and the internal quirks flag is excluded. |
| Element | Represented namespace and local tag, unordered attributes with their actual namespace annotations and values, then ordered ordinary children. |

Canonical Scalar/Units storage permits borrowed data comparison without an
intermediate JavaScript string or replacement projection. Unpaired UTF-16 units
remain significant, and Unicode normalization is not performed. Two adjacent
Text nodes and a single Text with their combined data are different structures.

Element attribute comparison relies on the current fixed qualified-name roster:
its namespace/local-name pairs are unambiguous in this storage model. Sorted
borrowed map walks can therefore compare unordered attributes while checking
their namespace annotations. Equal spellings and values with different actual
namespaces remain unequal. Literal colons do not create invented element
prefixes. This does not add general XML prefix storage, arbitrary namespace
aliases or new attribute APIs.

Template elements compare their ordinary children, excluding hosted content.
Passing `template.content` explicitly compares that fragment's ordinary
children, irrespective of its host association. Parent links and connection
state are not equality fields, though reached descendant links are checked for
local consistency. No ancestor walk above the operands is needed.

## Ordinary metadata and historical inventories

The planned property is writable, enumerable and configurable. Its cached
function has name `isEqualNode`, length one, ordinary Function inheritance and
no construction behavior. Saved calls are intended to survive own shadows and
prototype property replacement or deletion, without a hidden fallback.

The new represented prototype inventory has 28 keys: `nodeValue`, `textContent`,
`getRootNode`, `hasChildNodes`, `normalize`, `isEqualNode`, `isSameNode`, `contains`,
the eighteen Node constants, `constructor`, then `Symbol.toStringTag`. The
constructor's 21-key inventory stays unchanged. These are literal implemented
inventories, not the entire standard Node interface.

The constant batch consequently starts with nine prototype entries and three
constructor entries. Before the later constructor property, the prototype map
has 27 entries and its order buffer reserves 28 slots. The pinned sorted build
plan retains four prototype tree nodes and three constructor tree nodes, with
admission preceding consumption of either old bag. Existing `getRootNode`
dispatch remains the first length-eleven comparison; only its unmatched branch
pays for the additional `isEqualNode` comparison.

Adding the member is expected to invalidate two frozen getRootNode inventory
case modes and four reflected-order controls. Their sources and expectations
remain unchanged: anticipated ordinary Error case losses and TypeError/unhealthy
controls must stay visible. Eighteen older Node-constant, Normalize and predicate
inventory observations are already unhealthy and must remain byte-exact.
The new pristine 28-key case and positive/wrong control pair are separate.

Private historical wrappers may temporarily delete the later configurable
members, call an unchanged older oracle, and restore the saved descriptors.
Those realms are discarded because reinsertion changes creation order. External
replays retain their original sources and realms without those wrappers; no
historical failure is relabeled as healthy.

## Reached work and storage admission

After authentic conversion and local header checks, a top-level same-ID pair
returns true. That shortcut does not validate its subtree or attribute contents.
For distinct operands, a kind, count or field mismatch returns false without
auditing unvisited data. Matched leaves and empty containers need no owned
traversal buffers. Equal-length field comparison prepays its full selected field
even if the actual comparison finds an earlier difference.

Nonempty matching containers use an iterative paired depth-first walk, selecting
one child pair at a time. Each side has separate reached-ID bits stored in sparse
64-ID pages, plus a frame vector for active depth. IDs repeated within one side
refuse; overlap between the two operand trees is allowed. The plan admits the
256-edge endpoint, rejects deeper reached edges and checks actual descendant
backlinks. A descendant identity match does not bypass these checks.

Work is paid before field comparisons, borrowed attribute iterator creation and
advancement, side-map alignment, namespace checks, child selection, reached-map
searches and updates. New map pages admit typed blocks and insertion/cleanup
work; frame growth admits allocation and relocation before a fallible reserve.
Existing capacity is reused without pretending a new allocation occurred.
There is no comparison payload copy, persistent cache or whole-arena bitmap.
Scratch depends on reached pages and active depth, so widely spaced node IDs
can require more page entries than a dense layout with the same shape.

Reached invalid host data refuses with TypeError; work, arithmetic and storage
refusals are Resource. The same-ID and early-mismatch paths are deliberately
local policies, not graph-validation certificates. Consumed work and cumulative
allocation remain spent when scratch is dropped. Standard BTree allocation
retains its infallible process-OOM boundary; generic VM, native dispatch and
diagnostic allocation limits remain additional. The comparison body does not
mutate the DOM, but terminal Resource refusal cannot undo completed argument
effects and does not run ordinary JavaScript `catch` or `finally`.

The existing 100,000-work and 8 MiB cumulative runtime limits remain unchanged.
A structurally admitted tree can still exceed them. There is no promise that
every DOM at the depth, node or retained-byte limit can be compared in one turn.
The source-only bootstrap forecast is 502 additional work units and, using the
prior 64-bit type sizes, 3,256 additional charged bytes and one object. These are
predictions awaiting measurement, not elapsed-time or physical-memory results.
The selected plan leaves storage, ERWA/EWB1 transport, rendering and reset sites
unchanged.

## Frozen expectations and pending validation

Sixteen independent fresh-realm bodies define 32 strict/sloppy expectations.
Four positive/wrong pairs define 16 controls. A negative tail is healthy only
when its same-mode positive partner succeeds. The published getRootNode release
baseline matches zero new cases and has four healthy controls; all 32 case
failures are ordinary runtime TypeError from missing prerequisites, with no
binding drift. Candidate results and full-suite checks remain pending.

The authored Page and confined-worker witness compares a live branch with an
independently constructed detached peer. A real click changes and restores exact
Comment data and an attribute, then changes visible Text on each side in turn.
Each intermediate inequality and restored equality is asserted. Twenty-nine IDs
and total node count must remain stable; template ordinary children and contents
are checked separately. Titles are `Equality ready` and `Equality done`.
An independent scalar page supplies literal green/blue markers, text and canvas
expectations. Rendering changes come from explicit data mutations, not from the
equality operation. Browser execution and budget feasibility are still pending.

The planned [summary](evidence/node-equality.json),
[archive](evidence/node-equality.tar.gz) and [validation record](VALIDATION.md)
will bind the final source, attempts and complete raw comparisons after
validation. No current CI, speedup or platform-wide conformance claim is made.
CDATA, Attr, ShadowRoot, broader XML representation and cross-document adoption
remain outside the represented scope. Proxy, BigInt, broader Node members,
legacy string writers and unrelated existing DOM/allocator gaps remain.

Primary references: [isEqualNode](https://dom.spec.whatwg.org/#dom-node-isequalnode),
[node equality](https://dom.spec.whatwg.org/#concept-node-equals),
[Node IDL](https://dom.spec.whatwg.org/#interface-node),
[operation bindings](https://webidl.spec.whatwg.org/#es-operations), and
[nullable conversion](https://webidl.spec.whatwg.org/#es-nullable-type).
