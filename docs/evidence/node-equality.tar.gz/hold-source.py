import hashlib,json,shutil,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent
ROOT=OUT/'worktree'
phase=sys.argv[1]
assert phase in ('initial','final')
paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=ROOT,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=ROOT,text=True).splitlines())
paths=sorted(p for p in paths if p.startswith(('src/','tests/')))
hold=OUT/('held-source-'+phase);hold.mkdir()
rows=[]
for rel in paths:
 source=ROOT/rel;target=hold/rel;target.parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(source,target);data=target.read_bytes()
 rows.append(dict(path=rel,bytes=len(data),sha256=hashlib.sha256(data).hexdigest()))
record=dict(base='51907b7b6b3a7465c7a2605f3762375ddaa97a26',files=rows)
p=OUT/('candidate-source-'+phase+'.json')
with p.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(path=str(p),files=len(rows),sha256=hashlib.sha256(p.read_bytes()).hexdigest())))
