from pathlib import Path
import hashlib,json,re,shutil,subprocess
P=Path(__file__).resolve().parents[1]
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD=Path('/tmp/eris-node-root-preparation-1/replay');OUT=P/'replay'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
ready=json.loads((P/'independent/source-ready.json').read_text())
for row in ready['files']:
 p=P/'independent'/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
assert json.loads((P/'root/independent-source-review.json').read_text())['findings']==[]
base=json.loads((P/'root/published-base.json').read_text())
assert base['commit']==subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip()
OUT.mkdir();history=[]
def copy(p,rel):
 dest=OUT/rel
 if dest.exists():assert dest.read_bytes()==p.read_bytes();return
 dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 history.append(dict(origin=str(p),copy=str(rel),bytes=dest.stat().st_size,sha256=sha(dest)))
# Copy only already-held inputs, never a concurrently drafted Runtime plan.
for rel in ['independent/source-ready.json',*[str(Path('independent')/r['path'])for r in ready['files']],
 'root/scope.md','root/independent-source-review.json','root/published-base.json','root/prepare-replay.py',
 'runtime/assessment.md','runtime/feasibility-source-ready.json','runtime/feasibility-source-inputs.json','runtime/feasibility-spec-inputs.json',
 'layout/assessment.md','layout/source-ready.json','layout/source-inputs.json','layout/spec-inputs.json','layout/runtime-followup.md']:
 copy(P/rel,Path(rel))
for name in ['test262_conformance.py','html_conformance.py','import_test262.py']:
 assert (R/'tools'/name).read_bytes()==(OLD/'tools'/name).read_bytes();copy(OLD/'tools'/name,Path('tools')/name)
for name in ['node-constants.js','node-normalize.js','node-predicates.js','node-root.js']:
 copy(R/'tests/fixtures'/name,Path('history')/name)
for name in ['source-ready.json','replay.py','replay-matrix.json','replay-inputs.json']:
 copy(OLD/name,Path('history/prior-replay')/name)
for name in ['candidate-source-final.json','release.json','published.json']:
 copy(Path('/tmp/eris-node-root-1')/name,Path('history/published-root')/name)
for row in json.loads((P/'runtime/feasibility-source-inputs.json').read_text())['sources']:
 p=Path(row['path']);assert sha(p)==row['sha256']==sha(R/row['repository_path'])
 copy(p,Path('history/base-source')/row['repository_path'])
for row in json.loads((P/'independent/source-inputs.json').read_text())['files']:
 p=Path(row['path']);assert sha(p)==row['sha256']
 if p.is_relative_to(Path('/tmp/eris-node-root-1/worktree')):
  copy(p,Path('history/base-source')/p.relative_to(Path('/tmp/eris-node-root-1/worktree')))
# Earlier feasibility inspected published066435f; preserve that exact git object,
# not today's changed working file at the same source path.
legacy=json.loads((P/'layout/source-inputs.json').read_text())
for row in legacy['sources']:
 rel=Path('history/layout-base-source')/row['repository_path'];dest=OUT/rel;dest.parent.mkdir(parents=True,exist_ok=True)
 b=subprocess.check_output(['git','show',legacy['base']+':'+row['repository_path']],cwd=R)
 assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256'];dest.write_bytes(b)
 history.append(dict(origin='git:'+legacy['base']+':'+row['repository_path'],copy=str(rel),bytes=len(b),sha256=sha(dest)))
fixture=OUT/'independent/cases.js';fixture_sha=sha(fixture)
assert fixture_sha=='675e9c85be938da35f929c8b9f661b2493789648074e92de2816367795474597'
inv=json.loads((OUT/'independent/inventory.json').read_text());ctrl=json.loads((OUT/'independent/controls.json').read_text())
assert len(inv['cases'])==16 and inv['collection']=='nodeEqualityCases' and len(ctrl['controls'])==8
assert set(re.findall(r'^  ([A-Za-z0-9_]+): function\(\)',fixture.read_text(),re.M))==set(inv['cases'])
inventory=dict(fixture='independent/cases.js',fixture_sha256=fixture_sha,collection=inv['collection'],cases=[dict(name=name,modes=['sloppy','strict'],expected_observation=inv['ordinary_expectation']) for name in inv['cases']],controls=ctrl['controls'],case_modes=32,control_modes=16)
(OUT/'replay-inputs.json').write_text(json.dumps(inventory,indent=2)+'\n')
original=(OLD/'replay.py').read_text()
changes=[('Frozen Node root observations','Frozen Node equality observations'),('nodeRootCases','nodeEqualityCases'),('node-root.js','node-equality.js'),('65e3b34ac5b80a095d59505ab8693ec22b26225ae9d7f3408163070593ed6af3',fixture_sha)]
driver=original
for before,after in changes:
 assert before in driver;driver=driver.replace(before,after)
reverse=driver
for before,after in reversed(changes):reverse=reverse.replace(after,before)
assert reverse==original
(OUT/'replay.py').write_text(driver)
(OUT/'preparation-history.json').write_text(json.dumps(history,indent=2)+'\n')
commands=[]
for option in ['--prepare','--verify']:
 args=['python3',str(OUT/'replay.py'),option];x=subprocess.run(args,capture_output=True,text=True)
 record=dict(command=args,exit=x.returncode,stdout=x.stdout,stderr=x.stderr);commands.append(record);assert x.returncode==0,record
(OUT/'inert-verification.json').write_text(json.dumps(dict(engine_run=False,compiler_run=False,commands=commands),indent=2)+'\n')
result=dict(status='Frozen source-reviewed equality expectations; inert matrix verified; no equality engine or parser execution',location=str(OUT),location_must_remain_fixed=True,ordinary_bodies=16,ordinary_modes=32,control_pairs=4,control_modes=16,total_rows=48,history_copies=len(history),driver=dict(path=str(OUT/'replay.py'),sha256=sha(OUT/'replay.py')),matrix=dict(path=str(OUT/'replay-matrix.json'),sha256=sha(OUT/'replay-matrix.json')),fixture_sha256=fixture_sha,supervision='Exact prior root driver except four reversible identity substitutions; ERJS1/ERJR2,3s,96KiBstdout/64KiBstderr,4MiBrequest,exclusivefreshreport,pre/postbindings,same-mode positive controls. Inherited direct-child supervision.',baseline='Not yet executed; eventual baseline is published51907b7 release3198cd31. No equality implementation or candidate compilation.',files=[dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.rglob('*')) if p.is_file()])
(OUT/'source-ready.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k!='files'},indent=2))
