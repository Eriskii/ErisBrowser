from pathlib import Path
import hashlib,json,re
out=Path(__file__).parent
sha=lambda s:hashlib.sha256(s.encode()).hexdigest()
complete={'status':'complete','phase':'runtime','error_type':'','error_identity':''}
error={'status':'exception','phase':'runtime','error_type':'Error','error_identity':'Error'}
tail="throw new Error('deliberately wrong expectation');"
guard="if(typeof Node!=='function'||typeof Text!=='function'||typeof DocumentFragment!=='function')throw new TypeError('constructors');var method=Node.prototype.isEqualNode;if(typeof method!=='function')throw new TypeError('equality function');var guardA=new Text('guard'),guardB=new Text('guard');if(guardA===guardB||method.call(guardA,guardA)!==true||method.call(guardA,guardB)!==true||method.call(guardA,new Text('different'))!==false)throw new TypeError('genuine positive and negative equality');"
constants=['ELEMENT_NODE','ATTRIBUTE_NODE','TEXT_NODE','CDATA_SECTION_NODE','ENTITY_REFERENCE_NODE','ENTITY_NODE','PROCESSING_INSTRUCTION_NODE','COMMENT_NODE','DOCUMENT_NODE','DOCUMENT_TYPE_NODE','DOCUMENT_FRAGMENT_NODE','NOTATION_NODE','DOCUMENT_POSITION_DISCONNECTED','DOCUMENT_POSITION_PRECEDING','DOCUMENT_POSITION_FOLLOWING','DOCUMENT_POSITION_CONTAINS','DOCUMENT_POSITION_CONTAINED_BY','DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC']
strings=['nodeValue','textContent','getRootNode','hasChildNodes','normalize','isEqualNode','isSameNode','contains']+constants+['constructor']
constructor=['length','name','prototype']+constants
pairs=[
 ('literal-units','common',r"var value='A\uD800',tail='\uDC00';if(value.length!==2||value.charCodeAt(0)!==65||value.charCodeAt(1)!==55296||tail.length!==1||tail.charCodeAt(0)!==56320)throw new TypeError('exact literal units');"),
 ('authentic-equality-method','feature',guard+"var d=Object.getOwnPropertyDescriptor(Node.prototype,'isEqualNode');if(!d||d.value!==method||d.writable!==true||d.enumerable!==true||d.configurable!==true||method.name!=='isEqualNode'||method.length!==1||method.call(guardA,null)!==false||method.call(guardA,undefined)!==false)throw new TypeError('method metadata and nullish');var missing=false;try{method.call(guardA);}catch(e){missing=e instanceof TypeError;}if(!missing)throw new TypeError('required argument');"),
 ('exact-data-and-namespace','feature',guard+r"var a=new Text('\uD800'),b=new Text('\uD800');if(a.data.length!==1||a.data.charCodeAt(0)!==55296||method.call(a,b)!==true||method.call(a,new Text('\uFFFD'))!==false)throw new TypeError('exact retained data');var box=document.createElement('div');box.innerHTML='<svg xlink:href=\"same\"></svg><svg></svg>';var x=box.firstChild,y=box.childNodes[1];if(!x||!y||x.namespaceURI!=='http://www.w3.org/2000/svg'||y.namespaceURI!==x.namespaceURI)throw new TypeError('foreign parsing');y.setAttribute('xlink:href','same');if(x.getAttribute('xlink:href')!=='same'||y.getAttribute('xlink:href')!=='same'||method.call(x,y)!==false||method.call(y,x)!==false)throw new TypeError('attribute namespace identity');"),
 ('represented-node-order','feature',guard+"var strings="+json.dumps(strings,separators=(',',':'))+",keys=Reflect.ownKeys(Node.prototype);if(strings.length!==27||keys.length!==28||keys[27]!==Symbol.toStringTag)throw new TypeError('prototype count');for(var i=0;i<27;i++)if(keys[i]!==strings[i])throw new TypeError('prototype order');var expected="+json.dumps(constructor,separators=(',',':'))+",actual=Reflect.ownKeys(Node);if(actual.length!==21)throw new TypeError('constructor count');for(var j=0;j<21;j++)if(actual[j]!==expected[j])throw new TypeError('constructor order');")
]
controls=[]
for name,area,source in pairs:
 for positive in [True,False]:
  code=source if positive else source+tail
  controls.append({'name':name+('-positive' if positive else '-wrong'),'pair':name,'positive':positive,'area':area,'modes':['sloppy','strict'],'source':code,'source_sha256':sha(code),'expected_observation':complete if positive else error})
control_data={'status':'Fixed independently authored sources; unexecuted and unparsed','negative_health':'Exact runtime Error/Error tail requires successful same-mode positive partner; all prerequisite failures TypeError. Missing or null observations cannot pass.','pairs':4,'control_modes':16,'controls':controls}
(out/'controls.json').write_text(json.dumps(control_data,indent=2)+'\n')
source=(out/'cases.js').read_text();names=re.findall(r'^  ([a-z][a-z0-9_]+): function\(\)',source,re.M)
assert len(names)==len(set(names))==16
assert all(source.count('  '+name+': function()')==1 for name in names)
assert len(strings)==27 and len(constructor)==21 and len(set(strings))==27
assert 'isEqualNode'==strings[5] and 'isSameNode'==strings[6]
for p,n in zip(controls[::2],controls[1::2]):
 assert n['source']==p['source']+tail and n['pair']==p['pair']
 assert p['source_sha256']==sha(p['source']) and n['source_sha256']==sha(n['source'])
# Data checks inspect exact JS source bytes without a JS parser or engine.
assert controls[0]['source'].count('\\uD800')==1 and '\\\\uD800' not in controls[0]['source']
assert "xlink:href=\\\"same\\\"" in controls[4]['source']
inventory={'collection':'nodeEqualityCases','fixture_filename':'node-equality.js','proposed_repository_path':'tests/fixtures/node-equality.js','execution':'Load exact cases.js then invoke one named body in an ordinary fresh Runtime/Document per sloppy/strict mode; no aggregate.','case_count':16,'case_modes':32,'control_modes':16,'cases':names,'ordinary_expectation':complete,'ordinary_return':True,'literal_prototype_string_keys':strings,'literal_prototype_final_symbol':'Symbol.toStringTag','literal_prototype_total':28,'literal_constructor_keys':constructor,'anticipated_predecessor':'Unpublished getRootNode candidate in /tmp/eris-node-root-1/worktree, implemented on published066435fb0682449c62be6ecb999ca457653af7a1. No candidate publication claim.','exact_data_literals':{'text':[65,55296,56320,55296],'comment':[56320],'mutated_pi':[63,62,56320]},'private_only':['two parsed doctypes; absent versus empty public/system IDs and ignored force_quirks','deep/wide work and heap cuts','malformed IDs/backlinks/duplicate sides/cycles','Document metadata differences and cross-Document storage prerequisites']}
(out/'inventory.json').write_text(json.dumps(inventory,indent=2)+'\n')
print(json.dumps({'ordinary_cases':len(names),'ordinary_modes':32,'controls':len(controls),'control_modes':16,'source_bytes':len(source.encode()),'source_sha256':sha(source)}))
