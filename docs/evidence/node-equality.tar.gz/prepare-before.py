from pathlib import Path
import json,hashlib,shutil
B=Path(__file__).resolve().parent
P=Path('/tmp/eris-node-root-1')
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((B/'base.json').read_text());release=json.loads((P/'release.json').read_text())
assert sha(P/'eris-js')==release['sha256']==base['release']['sha256']
comparison=json.loads((P/'root-comparison.json').read_text());assert len(comparison['profiles'])==17
paths=[x['after']['path'] for x in comparison['profiles']]+[str(P/x) for x in ['release.json','candidate-source-final.json','root-comparison.json','inventory-classification.json']]
dest=B/'comparison-before';dest.mkdir();rows=[]
for name in paths:
 p=Path(name);out=dest/p.name;assert not out.exists();shutil.copy2(p,out)
 rows.append(dict(path=str(out.relative_to(B)),original=str(p),bytes=out.stat().st_size,sha256=sha(out)))
source=json.loads((P/'candidate-source-final.json').read_text())
for row in source['files']:
 assert sha(R/row['path'])==row['sha256']
cases=sum(len(json.loads((dest/Path(x['after']['path']).name).read_text())['cases']) for x in comparison['profiles'])
def controls(x):return x.get('controls',x.get('harness_preflight',[]))
control_count=sum(len(controls(json.loads((dest/Path(x['after']['path']).name).read_text()))) for x in comparison['profiles'])
assert cases==4300 and control_count==492
healthy_cases=sum(x['cases']['after_healthy'] for x in comparison['profiles']);healthy_controls=sum(x['controls']['after_healthy'] for x in comparison['profiles'])
assert (healthy_cases,healthy_controls)==(4208,480)
record=dict(base=base['commit'],release_sha256=release['sha256'],files=rows,established_cases=cases,established_controls=control_count,healthy_cases=healthy_cases,healthy_controls=healthy_controls,source_manifest=dict(path='comparison-before/candidate-source-final.json',historical_manifest_base=source['base'],public_base=base['commit'],all18_public_source_paths_verified=True),note='Exact prior reports retain their own old source base/input identities. No old expectation, source, result or unhealthy inventory flag rewritten.')
with (B/'before-comparison-inputs.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in record.items() if k!='files'},indent=2))
