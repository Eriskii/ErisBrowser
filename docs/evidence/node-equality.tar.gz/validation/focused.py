import subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
for label,match in [('bootstrap-188-2','bootstrap'),('constants-188-1','node_constant'),('node-data-188-1','node_data'),('normalize-188-1','node_normalize'),('predicates-188-1','node_predicates'),('root-188-1','node_root')]:
 r=subprocess.run(['python3',str(H/'check.py'),label,'1.88.0','Cargo.toml','-','test',match,'--','--include-ignored'])
 if r.returncode:raise SystemExit(r.returncode)
