import hashlib,json,re
from pathlib import Path
B=Path(__file__).resolve().parent
def read(name):return json.loads((B/name).read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def checked(label):
 r=read('validation/'+label+'.json')
 assert r['exit']==0 and sha(B/'validation'/r['log'])==r['sha256']
 return r
source=read('candidate-source-final.json');assert len(source['files'])==19
release=read('release.json');assert sha(B/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(B/'candidate-source-final.json')
comparison=read('equality-comparison.json');assert not comparison['validation_failures']
s=comparison['summary']
for kind,total,unchanged,losses in [('cases',4300,4298,2),('controls',492,488,4)]:
 r=s['established'][kind];assert r['before_total']==r['after_total']==total
 assert r['unchanged']==unchanged and r['losses']==losses and r['gains']==r['other_changes']==0
for kind,total,before in [('cases',32,0),('controls',16,4)]:
 r=s['new'][kind];assert r['before_total']==r['after_total']==r['after_healthy']==total
 assert r['before_healthy']==before and r['gains']==total-before and r['losses']==r['other_changes']==0
classification=read('inventory-classification.json');assert classification['comparison_sha256']==sha(B/'equality-comparison.json')
audit=read('independent-results-review.json');assert audit['status']=='clear' and not audit['findings']
ci=read('node-root-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
for label,total in [('full-default-188-1',1873),('full-native-198-1',1996)]:
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(B/'validation'/(label+'.log')).read_text())
 assert [sum(int(x[i]) for x in rows) for i in range(3)]==[total,0,0]
summary=dict(
 kind='Represented ordinary Node structural equality',base_commit=source['base'],
 scope='Ordinary cached Node.prototype.isEqualNode with authentic receiver and required nullable Node; exact retained fields, fixed attribute namespace model and ordered ordinary children; no authored callback in body. Template content participates only as an explicit operand.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-1','clippy-native-198-1','clippy-presenter-188-1','full-default-188-1','full-native-198-1','release-adapter-188-1']},
 tests=dict(default=1873,native=1996,new_groups=36,independent_groups=16,private_groups=18,browser_groups=2,focused=read('focused-validation-review.json'),final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False,full_test_threads=4),
 accounting=dict(remaining_bootstrap_work=7816,allocated_bytes=1762227,objects=687,object_capacity=687,native_entries=321,legacy_prototype_entries=25,additional_work=502,additional_charged_bytes=3256,bootstrap_work_limit=100000,author_work_limit=100000,cumulative_heap_limit=8388608,numeric_limits_and_resets_changed=False,dense_body_work=[65681,70989],dense_body_charged_bytes=[13416,13416],sparse='Fixed-budget refusal passed; full schedule remains a source-only arithmetic prediction.'),
 compatibility=dict(path='equality-comparison.json',sha256=sha(B/'equality-comparison.json'),summary=s,inventory_classification=dict(path='inventory-classification.json',sha256=sha(B/'inventory-classification.json'),report=classification)),
 independent_audit=dict(path='independent-results-review.json',sha256=sha(B/'independent-results-review.json'),original_path='audit-results-1.json',status='clear'),
 retained_history=[
 'Initial all-target compilation and all36newgroups passed. Initial bootstrap filter retained28passes and2stale descriptive failures. Exactly3literals in2test files changed after measurement; initial17source paths remain unchanged. No production correction after initial compilation.',
 'Pre-hold tests initially used invalid comma-separated Rust lets; corrected before formatting or compilation. A malformed-child witness initially exhausted heap before traversal; final source gives traversal headroom and restores the exhausted budget for later local checks. Original draft retained; no frozen JS oracle changed.',
 'Original test-inventory.json truncated two digit-bearing function names. Additive corrected inventory and receipt preserve original hold/source; groups remain16independent+18private.',
 'Final HTML source-review receipt originally misstated its timing. Additive corrected receipt records that it followed compiler start; root and layout final source reviews plus HTML incremental review preceded compilation. Original receipt retained.',
 'Baseline0/32newcases and4/16healthy controls used the published root release before equality implementation. No baseline rerun or input drift.',
 'Four historical inventory profile commands and aggregate retain exit1. Eighteen older Nodeconstant/Normalize/Predicate unhealthy observations remain byte-exact; two root inventory cases newly fail with Error and four controls become unhealthy with TypeError. No health waiver.',
 'Independent data-only audit passed first run with all239boundinputs; no engine/compiler rerun. Preceding root commit51907b7 has9successfulCIjobs, distinct from current local validation.'],
 boundaries=[
 'Represented ordinary kinds and fixed namespaces only; no new ShadowRoot, Attr, CDATA, XMLDocument, arbitrary namespace/prefix storage or cross-document ownership.',
 'Local self and early mismatch policies do not validate unreached state. Selected descendants require valid kinds/backlinks/depth and separate-side reached bits. No template-host traversal, comparison payload copy or whole-arena scratch.',
 'Owned sparse page maps and active-depth frames prepay work, growth and cleanup. ID density and field size can exhaust unchanged limits on structurally admitted DOMs. Generic VM/diagnostic costs and inherited infallible BTree process-OOM boundary remain.',
 'Page/worker real-click witnesses retain29IDs with0newclicknodes, explicit temporary mismatches and restored equality, and literal whole-canvas/text/status checks. Equality itself makes no DOM/render mutation.',
 'No page/GPU/physical-memory performance result. Full web compatibility, production security and Chromium performance threshold remain unachieved.'])
with (B/'result.json').open('x') as out:json.dump(summary,out,indent=2);out.write('\n')
print(json.dumps(dict(path=str(B/'result.json'),sha256=sha(B/'result.json'))))
