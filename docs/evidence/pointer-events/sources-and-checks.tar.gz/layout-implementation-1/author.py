#!/usr/bin/env python3
"""Author held source only. Do not import or execute project code."""
from pathlib import Path
import difflib
import hashlib
import json
import re

P = Path('/tmp/eris-pointer-events-plan-1')
W = Path('/tmp/eris-canvas-display-plan-1/worktree')
I = P / 'layout-implementation-1'
F = P / 'layout-fixtures-1'

def binding(path):
    b = path.read_bytes()
    return {'path': str(path), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

def save_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')
    return binding(path)

def put(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(text)
    return binding(path)

def payload(hold, relative, before, after):
    a = put(hold / 'before' / relative, before)
    b = put(hold / 'raw' / relative, after)
    diff = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                       fromfile='a/' + relative, tofile='b/' + relative))
    inverse = ''.join(difflib.unified_diff(after.splitlines(True), before.splitlines(True),
                                          fromfile='b/' + relative, tofile='a/' + relative))
    return {'path': relative, 'before': a, 'raw': b,
            'diff': put(hold / 'diff' / (relative + '.diff'), diff),
            'inverse': put(hold / 'inverse' / (relative + '.diff'), inverse)}

def apply_chunks(before, chunks):
    after = before
    for c in chunks:
        assert after.count(c['old']) == c.get('count', 1), c['name']
        after = after.replace(c['old'], c['new'])
    recovered = after
    for c in reversed(chunks):
        assert recovered.count(c['new']) == c.get('count', 1), c['name']
        recovered = recovered.replace(c['new'], c['old'])
    assert recovered == before
    return after

design = json.loads((P / 'design-1.json').read_text())
source = (W / 'src/layout.rs').read_text()
assert hashlib.sha256(source.encode()).hexdigest() == design['origin_layout_sha256']
chunks = [
    {'name': 'import enum',
     'old': '    GridBreadth, GridLine, GridTrack, Length, ObjectFit, ObjectPosition, PositionComponent,\n    Visibility,\n',
     'new': '    GridBreadth, GridLine, GridTrack, Length, ObjectFit, ObjectPosition, PointerEvents,\n    PositionComponent, Visibility,\n'},
    {'name': 'hit field',
     'old': 'pub struct HitRegion {\n    pub node: NodeId,\n    pub action: HitAction,\n',
     'new': 'pub struct HitRegion {\n    pub node: NodeId,\n    pub action: HitAction,\n    /// Point eligibility; geometry remains available to focus and navigation.\n    pub pointer_events: PointerEvents,\n'},
    {'name': 'point selector only',
     'old': '        self.hit_regions.iter().rev().find_map(|hit| {\n            (x >= hit.rect.x\n',
     'new': '        self.hit_regions.iter().rev().find_map(|hit| {\n            (hit.pointer_events == PointerEvents::Auto\n                && x >= hit.rect.x\n'},
    {'name': 'ordinary box own style',
     'old': '        self.push_hit(HitRegion {\n            fixed: false,\n            node: id,\n            action: HitAction::Node,\n            rect: rect(x, y, width, 0.0),\n',
     'new': '        self.push_hit(HitRegion {\n            fixed: false,\n            node: id,\n            action: HitAction::Node,\n            pointer_events: style.pointer_events,\n            rect: rect(x, y, width, 0.0),\n'},
    {'name': 'default summary own details style',
     'old': '            self.push_hit(HitRegion {\n                node: id,\n                action: HitAction::DefaultSummary,\n                fixed: false,\n',
     'new': '            self.push_hit(HitRegion {\n                node: id,\n                action: HitAction::DefaultSummary,\n                pointer_events: style.pointer_events,\n                fixed: false,\n'},
    {'name': 'text own inherited style',
     'old': '                    self.push_hit(HitRegion {\n                        fixed: false,\n                        node: item.node,\n                        action: HitAction::Node,\n',
     'new': '                    self.push_hit(HitRegion {\n                        fixed: false,\n                        node: item.node,\n                        action: HitAction::Node,\n                        pointer_events: style.pointer_events,\n'},
    {'name': 'row own style',
     'old': '            self.push_hit(HitRegion {\n                fixed: false,\n                node: id,\n                action: HitAction::Node,\n                rect: row_rect,\n',
     'new': '            self.push_hit(HitRegion {\n                fixed: false,\n                node: id,\n                action: HitAction::Node,\n                pointer_events: self.style(id).pointer_events,\n                rect: row_rect,\n'},
]
raw = apply_chunks(source, chunks)
production = payload(I, 'src/layout.rs', source, raw)
chunk_binding = save_json(I / 'chunks.json', chunks)

fixture_chunks = {}
layout_fixture_chunks = []
for node in (1, 2):
    old = f'                    node: {node},\n                    action: HitAction::Node,\n'
    layout_fixture_chunks.append({'name': f'old hit-order fixture node {node}', 'old': old,
                                 'new': old + '                    pointer_events: PointerEvents::Auto,\n'})
fixture_chunks['src/layout.rs'] = layout_fixture_chunks
# The two independent fixtures intentionally have different indentation.
fixture_chunks['src/layout/inline_edges/independent_tests.rs'] = [
    {'name': 'old atomic fragment',
     'old': '                    action: HitAction::Node,\n',
     'new': '                    action: HitAction::Node,\n                    pointer_events: PointerEvents::Auto,\n'},
    {'name': 'old sentinel fragment',
     'old': '\n            action: HitAction::Node,\n',
     'new': '\n            action: HitAction::Node,\n            pointer_events: PointerEvents::Auto,\n'}
]
fixture_chunks['src/layout/inline_backgrounds/translation_tests.rs'] = [
    {'name': 'old translation fragment',
     'old': '            action: HitAction::Node,\n',
     'new': '            action: HitAction::Node,\n            pointer_events: PointerEvents::Auto,\n'}
]
fixtures = []
for path, changes in fixture_chunks.items():
    before = raw if path == 'src/layout.rs' else (W / path).read_text()
    after = apply_chunks(before, changes)
    fixtures.append(payload(F, path, before, after))
    if path == 'src/layout.rs':
        composed = after
fixture_chunk_binding = save_json(F / 'chunks.json', fixture_chunks)

# A full active-source textual census includes qualified names and shorthand
# field forms. Historical copies inside docs/evidence are deliberately excluded.
census = []
for top in ('src', 'tests', 'examples'):
    for path in sorted((W / top).rglob('*.rs')):
        text = path.read_text()
        for m in re.finditer(r'\bHitRegion\s*\{', text):
            line = text.count('\n', 0, m.start()) + 1
            previous = text[max(0, m.start()-20):m.start()]
            kind = 'declaration' if re.search(r'\bstruct\s*$', previous) else 'literal'
            rel = str(path.relative_to(W))
            owner = 'layout' if rel == 'src/layout.rs' or rel.startswith(('src/layout/', 'src/graphics/')) else 'script'
            census.append({'path': rel, 'line': line, 'kind': kind, 'owner': owner})
assert len([r for r in census if r['kind'] == 'literal']) == 15
assert len([r for r in census if r['kind'] == 'literal' and r['owner'] == 'layout']) == 9
assert not [r for r in census if r['path'].startswith('src/graphics/')]
census_binding = save_json(I / 'constructor-census.json', {
    'method': 'All *.rs under active src/tests/examples; multiline HitRegion brace scan. All references also reviewed by rg; no active alias constructor found.',
    'excluded': 'Historical source copies under docs/evidence are not active constructors and remain immutable.',
    'rows': census,
    'production_layout_literals': 4,
    'historical_layout_literals': 5,
    'script_owned_remaining_literals': 6,
    'graphics_literals': 0,
    'source_bindings': [binding(W / p) for p in sorted({r['path'] for r in census})],
})
review = save_json(I / 'source-checks.json', {
    'checks': [
        'Seven production replacements have unique exact anchors and a complete byte-for-byte inverse.',
        'The existing six-line canvas display guard is preserved by the full inverse.',
        'Four producers assign the owning box/details/text/row computed value; no ancestor gate or hit omission is introduced.',
        'The text producer reads the existing cloned style for item.node; row assignment borrows self.style(id) with the existing fallback.',
        'The single eligibility predicate precedes existing rectangle comparisons; all geometry comparisons and reverse ordering remain exact.',
        'Fragment collection, restacking, clipping, translation, hit counts/caps, paint commands, node_visibility and focus consumers are untouched.',
        'All five old fixture literals receive only PointerEvents::Auto; their original assertions, strings, rectangles and budget values remain exact.',
        'No new tests, registrations or numeric type-layout claims are authored in these holds.'
    ],
    'unexecuted': True,
    'required_external_composition': ['CSS enum and ComputedStyle field from html_css', 'Browser/codec and six remaining constructor migrations from script', 'Independent controls and actual type measurement by root'],
})
implementation_seal = {
    'schema': 1, 'status': 'source-ready held layout production; unexecuted',
    'design': binding(P / 'design-1.json'),
    'origin': str(W), 'origin_published_parent': design['origin_published_parent'],
    'base_qualification': 'Origin includes the selected canvas guard. Final published O commit binding will be additive after root provides it.',
    'paths': [production], 'chunks': chunk_binding,
    'constructor_census': census_binding, 'source_checks': review,
    'changed_paths': 1, 'production_chunks': 7,
    'new_public_interface': 'HitRegion.pointer_events: css::PointerEvents',
    'fixture_composition': 'Apply layout-fixtures-1 after this production payload; its src/layout.rs before bytes equal this raw exactly.',
    'all_other_source_bytes_exact': True, 'exact_inverse': True,
    'project_execution': False, 'project_imports': False, 'live_edits': False,
    'author_script': binding(I / 'author.py'),
}
seal_binding = save_json(I / 'source-ready.json', implementation_seal)
fixture_seal = {
    'schema': 1, 'status': 'source-ready held mechanical historical fixtures; unexecuted',
    'design': binding(P / 'design-1.json'),
    'production_dependency': seal_binding,
    'paths': fixtures, 'chunks': fixture_chunk_binding,
    'changed_paths': 3, 'added_fields': 5,
    'composition': 'src/layout.rs is based on layout-implementation-1/raw; both child files are based on exact O worktree source.',
    'original_tests_and_assertions_preserved': True, 'exact_inverse': True,
    'graphics_migrations': [],
    'project_execution': False, 'project_imports': False, 'live_edits': False,
}
fixture_binding = save_json(F / 'source-ready.json', fixture_seal)
print(json.dumps({'production': seal_binding, 'fixtures': fixture_binding}, indent=2))
