from pathlib import Path
from collections import Counter
import hashlib,json,re,sys
p=Path(__file__).resolve().parents[1];w=p/'worktree';old=Path('/tmp/eris-canvas-display-plan-1');version=sys.argv[1]
def load(f):return json.loads(f.read_bytes())
def bound(f):
    b=f.read_bytes();return dict(path=str(f),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def roster(f):return Counter(re.findall(r'^test (\S+) \.\.\. ok$',f.read_text(),re.M))
inv=p/f'source-candidate-{version}.json';inventory=load(inv)
for row in inventory['files']:assert dict(bound(w/row['path']),path=row['path'])==row,row['path']
changed=load(p/f'root/candidate-snapshots-{version}.json')['changed_paths'];state=dict(base=inventory['base'],changed=changed)
attempts=[]
for receipt in sorted((p/'validation').glob('*.json')):
    d=load(receipt)
    if 'command' not in d:continue
    log=p/'validation'/d['log'];assert bound(log)['sha256']==d['sha256']
    if 'format' not in receipt.stem:assert d['source_before']==d['source_after'],receipt
    rows=[tuple(map(int,r)) for r in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text(),re.M)]
    attempts.append(dict(label=receipt.stem,receipt=bound(receipt),command=d['command'],exit=d['exit'],log=bound(log),totals=dict(passed=sum(r[0] for r in rows),failed=sum(r[1] for r in rows),ignored=sum(r[2] for r in rows),suites=len(rows))))
by={a['label']:a for a in attempts}
parents={'parent-pixels-1':(3,10),'parent-cssom-1':(0,4),'parent-dynamic-direct-1':(0,1),'parent-dynamic-confined-1':(0,1),'candidate-all-before-1':(1,2)}
for label,(passed,failed) in parents.items():
    a=by[label];assert a['exit']==101 and a['totals']['passed']==passed and a['totals']['failed']==failed and a['totals']['ignored']==0
new=Counter();host=Counter()
files=[('tests/pointer_events.rs',''),('tests/pointer_events_cssom.rs',''),('tests/pointer_events_dynamic.rs',''),('tests/worker/pointer_events_dynamic.rs','pointer_events_dynamic::'),('src/css/pointer_events_tests.rs','css::pointer_events_tests::'),('src/css/pointer_events_budget_tests.rs','css::pointer_events_budget_tests::'),('src/cssom/pointer_events_all_tests.rs','cssom::pointer_events_all_tests::'),('src/browser/pointer_events_tests.rs','browser::pointer_events_tests::'),('src/worker/codec/pointer_events_tests.rs','worker::codec::pointer_events_tests::')]
for path,prefix in files:
    names=re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn (\w+)\(', (w/path).read_text())
    assert names,path
    new.update(prefix+name for name in names)
native=re.findall(r'#\[test\]\s*fn (\w+)\(', (w/'src/browser/native_scene/pointer_events_tests.rs').read_text())
host.update('browser::native_scene::pointer_events_tests::'+n for n in native)
assert sum(new.values())==42 and sum(host.values())==1
for label,extra,expected in [('candidate-full-msrv-1',new,3577),('candidate-full-host-vulkan-1',new+host,3942)]:
    a=by[label];assert a['exit']==0 and a['totals']==dict(passed=expected,failed=0,ignored=0,suites=62),a
    assert roster(p/'validation'/f'{label}.log')==roster(old/'validation'/f'{label}.log')+extra
for label in ['candidate-full-msrv-1','candidate-full-host-vulkan-1','candidate-clippy-msrv-1','candidate-clippy-host-vulkan-1','candidate-format-check-1','candidate-release-1','candidate-reftests-1']:
    d=load(p/'validation'/f'{label}.json');assert d['exit']==0 and d['source_before']==state and d['source_after']==state,label
report=load(p/'reftests-1/report.json');assert (report['passed'],report['failed'],report['total'])==(102,0,102)
prior={r['name']:r for r in load(old/'reftests-1/report.json')['cases']};assert set(prior)=={r['name'] for r in report['cases']}
images=[]
for case in report['cases']:
    assert case['status']=='pass' and case['different_pixels']==0
    for kind in ['test_image','reference_image']:
        a,b=Path(prior[case['name']][kind]),Path(case[kind]);assert a.read_bytes()==b.read_bytes()
        images.append(dict(name=case['name'],kind=kind,parent=bound(a),candidate=bound(b)))
sizes={}
for label in ['parent-storage-1','candidate-storage-2']:
    sizes[label]={name:dict(bytes=int(size),align=int(align)) for name,size,align in re.findall(r'^(ComputedStyle|HitRegion|LayoutResult) size=(\d+) align=(\d+)$',(p/'validation'/f'{label}.log').read_text(),re.M)}
assert sizes['parent-storage-1']==sizes['candidate-storage-2']=={'ComputedStyle':{'bytes':1032,'align':8},'HitRegion':{'bytes':32,'align':8},'LayoutResult':{'bytes':80,'align':8}}
summary=dict(status='pass',checkpoint='pointer-events',base=inventory['base'],source_inventory=bound(inv),inputs=len(inventory['files']),changed_sources=changed,attempts=attempts,new_test_names=sorted(new),host_only_new_test_names=sorted(host),old_rosters_preserved=True,compiled_type_sizes=sizes,reftest_pairs=102,parent_identical_pngs=len(images),reftest_report=bound(p/'reftests-1/report.json'),images=images,release_binary=bound(p/'target-msrv/release/eris-browser'),qualification='Bounded HTML auto/none targeting, no full WPT or browser compatibility claim. Existing conservative supports(var()) refusal retained. No new GPU hardware, Chromium performance comparison or security certification. All local ignored tests explicitly included. Failed candidate1 exposed excessive all reset merge work; final candidate removes redundant scans without raising resource caps or weakening the public control.')
with (p/'root/final-validation.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
print(json.dumps({k:summary[k] for k in ['status','inputs','reftest_pairs','parent_identical_pngs']}));print(bound(p/'root/final-validation.json'))
