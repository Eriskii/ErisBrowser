from pathlib import Path
import gzip,hashlib,io,json,tarfile
p=Path(__file__).resolve().parents[1];w=p/'worktree';out=w/'docs/evidence/pointer-events';out.mkdir(parents=True,exist_ok=True)
summary=json.loads((p/'root/final-validation.json').read_bytes());assert summary['status']=='pass'
for row in summary['changed_sources']:
    b=(w/row['path']).read_bytes();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
paths={}
excluded={'worktree','target-msrv','target-1990','publication'}
for child in p.iterdir():
    if child.name in excluded:continue
    candidates=child.rglob('*') if child.is_dir() else [child]
    for f in candidates:
        if not f.is_file() or '__pycache__' in f.parts:continue
        assert not f.is_symlink();paths[f.relative_to(p).as_posix()]=f
for stem in ['eris-pointer-events-assessment-1','eris-pointer-events-css-assessment-1','eris-pointer-events-browser-assessment-1']:
    f=Path('/tmp')/(stem+'.json');paths['assessments/'+f.name]=f
assert len(paths)<1500 and sum(f.stat().st_size for f in paths.values())<96*1024*1024
members=[];archive=out/'sources-and-checks.tar.gz';assert not archive.exists()
with archive.open('xb') as raw,gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0) as gz:
    with tarfile.open(fileobj=gz,mode='w',format=tarfile.USTAR_FORMAT) as tar:
        for name,f in sorted(paths.items()):
            b=f.read_bytes();info=tarfile.TarInfo(name);info.size,info.mode,info.mtime=len(b),0o644,0
            tar.addfile(info,io.BytesIO(b));members.append(dict(path=name,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
with tarfile.open(archive,'r:gz') as tar:
    actual=tar.getmembers();assert [f.name for f in actual]==[r['path'] for r in members]
    for f,r in zip(actual,members):
        assert f.isfile() and f.size==r['bytes'];b=tar.extractfile(f).read();assert b==paths[r['path']].read_bytes() and hashlib.sha256(b).hexdigest()==r['sha256']
record=dict(schema=1,checkpoint='pointer-events',validation=summary,members=members,archive=dict(path=archive.name,bytes=archive.stat().st_size,sha256=hashlib.sha256(archive.read_bytes()).hexdigest()),qualification='Selected source, authored controls, reviews and validation attempts, including failures and additive correction. External dependencies/toolchains are not archived. Parent outputs are linked by prior checkpoint paths and hashes. Final source and prose are in Git; publication evidence is recorded after commit.')
with (out/'validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(status='verified',members=len(members),archive=record['archive'])))
