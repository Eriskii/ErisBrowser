from pathlib import Path
import hashlib,json
p=Path(__file__).resolve().parents[1];w=p/'worktree';out=p/'candidate-import-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(item):
    b=Path(item['path']).read_bytes()
    assert len(b)==item['bytes'] and sha(b)==item['sha256'],item['path']
    return b
holds=['css-implementation-1','layout-implementation-1','layout-fixtures-1','browser-implementation-1','css-controls-1','budget-controls-1']
state={};imports=[]
registration=json.loads((p/'dynamic-controls-1/registration/proposal.json').read_text())['append'].encode()
for hold in holds:
    m=json.loads((p/hold/'source-ready.json').read_text())
    for row in m.get('files',m.get('paths',[])):
        path=row['path']
        if hold=='css-controls-1' and not path.startswith('src/'):continue
        target=w/path
        before=state.get(path,target.read_bytes() if target.exists() else None)
        expected=checked(row['before']) if row.get('before') else None
        raw=checked(row['raw'])
        if path=='tests/worker.rs':
            assert before==expected+registration
            raw+=registration
        else:assert before==expected,(hold,path)
        state[path]=raw
        imports.append({'hold':hold,'path':path,'before_sha256':sha(before) if before is not None else None,'after_sha256':sha(raw)})
for module in ['pointer_events_tests','pointer_events_budget_tests']:
    fragment=f'\n#[cfg(test)]\nmod {module};\n'.encode()
    assert f'mod {module};'.encode() not in state['src/css.rs']
    state['src/css.rs']+=fragment
assert sha(state['tests/worker.rs'])==json.loads((p/'dynamic-controls-1/registration/proposal.json').read_text())['parent_plus_magic_and_append_sha256']
for path,raw in state.items():
    target=w/path
    if target.exists():
        b=out/'before'/path;b.parent.mkdir(parents=True,exist_ok=True);b.write_bytes(target.read_bytes())
    a=out/'after'/path;a.parent.mkdir(parents=True,exist_ok=True);a.write_bytes(raw)
    target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(raw)
out.mkdir(exist_ok=True)
(out/'receipt.json').write_text(json.dumps({'imports':imports,'unique_paths':len(state),'worker_registration_preserved':True,'css_test_registrations_added':2},indent=2)+'\n')
(p/'root/candidate-review-1.json').write_text(json.dumps({'css':'Inherited Auto/None paths, shared bounded single-ident grammar and unchanged visibility cuts reviewed; conservative supports(var()) policy retained.','layout':'All four producers preserve geometry/order; point-only predicate reviewed by CSS peer.','browser_codec':'Root read production and test payloads; independent peer confirms strict ERWC 23-byte hits, old refusals, keyboard/focus retention.','budget':'Root-fixed fee literals, shared allowance and atomic CSSOM refusals read before execution.','dynamic':'Root literal rectangles/targets/phases match frozen contract; parent tests failed at first scripted pass-through phase.'},indent=2)+'\n')
print('Imported',len(state),'paths after all preconditions passed')
