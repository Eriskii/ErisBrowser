from pathlib import Path
import json,subprocess,sys,re
p=Path(__file__).resolve().parents[1];label,*args=sys.argv[1:]
with (p/'validation'/(label+'-console.txt')).open('x') as out:
    result=subprocess.run([sys.executable,str(p/'root/run-config.py'),label,*args],stdout=out,stderr=subprocess.STDOUT)
receipt=p/'validation'/(label+'.json')
if receipt.exists():
    d=json.loads(receipt.read_text());print(json.dumps({k:d[k] for k in ('command','exit','elapsed_seconds','log','sha256')}))
    text=(p/'validation'/d['log']).read_text()
    rows=[tuple(map(int,m)) for m in re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',text,re.M)]
    if rows:print('Tests:',[sum(r[i] for r in rows) for i in range(3)],'suites',len(rows))
    if result.returncode:print(text[-7000:])
else:print((p/'validation'/(label+'-console.txt')).read_text()[-7000:])
raise SystemExit(result.returncode)
