from pathlib import Path
import hashlib,json,re,difflib
p=Path(__file__).resolve().parents[1];w=p/'worktree';draft=p/'docs-draft-1/raw';out=p/'docs-final-1';summary=json.loads((p/'root/final-validation.json').read_text());assert summary['status']=='pass'
common = """The default Rust 1.88 suite passes 3,577 tests; Rust 1.99 with
`test262-host,vulkan-raster` passes 3,942. Both include ignored tests explicitly,
with zero failures or skips across 62 targets. Their prior passing rosters are
preserved with 42 new default groups and one extra native-raster group. Strict
Clippy passes for both configurations; formatting and the release build pass.
All 102 existing visual-reference pairs pass, and their 204 PNGs are byte-identical
to the previous canvas-display checkpoint.

The original parent passes three of the 19 public targeting/CSSOM/dynamic groups
and fails the other 16. The final candidate passes all 42 focused groups,
including the three additional all-reset regressions. Direct and confined-worker
dynamic controls each cover 24 full-frame snapshots (scripts off/on, six phases,
two widths). Feature-enabled runs compare the same pixels with the CPU native
scene witness; they are not GPU hardware executions.

Candidate1 exposed an `all:initial` CSSOM work-budget failure. The final change
skips redundant name searches only for an `all` expansion into an empty block,
whose static longhand names are distinct. Record admission remains before every
push; nonempty merges, importance, source order, summary/clone/commit accounting
and limits stay in place. The unchanged public control now passes. Three new
controls preserve earlier priority, later order and pending shorthand behavior;
before the correction, the two bounded parse controls failed and the merge
control passed. All failed attempts and the additive correction are retained.

Measured on the tested x86_64 Rust 1.88 build, `ComputedStyle` remains 1,032 bytes,
`HitRegion` 32 bytes and `LayoutResult` 80 bytes, all aligned to 8. The new byte
fits existing Rust padding, so hit-vector stride does not grow. ERWC still adds
one serialized byte per hit; the Rust layout result is platform-specific.

Local validation is complete for this checkpoint. GitHub CI for its new commit
is pending at publication; the preceding `3d90bd57` checkpoint passed all 11 jobs.
See the [validation manifest](evidence/pointer-events/validation.json) and
[source/check archive](evidence/pointer-events/sources-and-checks.tar.gz).
"""
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/VALIDATION.md','docs/css-pointer-events.md']
records=[]
for path in paths:
    source=(draft/path).read_text()
    source=re.sub(r'\[PENDING:[\s\S]*?\]','',source)
    source=re.sub(r'\n{3,}','\n\n',source)
    if path=='docs/css-pointer-events.md':
        source=source.replace('larger roster. \n','larger roster.\n')
        anchor='The controls cover target changes'
        source=source.replace(anchor,common+'\n'+anchor)
    elif path=='docs/VALIDATION.md':
        source=source.replace('## CSS pointer-events: auto and none — draft','## CSS pointer-events: auto and none')
        anchor='The frozen controls distinguish'
        source=source.replace(anchor,common+'\n'+anchor)
        source=source.replace('All failed attempts and the additive correction are retained.','All failed attempts and the additive correction are retained. The selected inventory binds '+str(summary['inputs'])+' source/build/test inputs and '+str(len(summary['changed_sources']))+' changed source paths, SHA-256 `'+summary['source_inventory']['sha256']+'`.')
    assert '[PENDING:' not in source
    prior=w/path;before=prior.read_bytes() if prior.exists() else None
    old=p/'docs-draft-1/before'/path
    assert before==(old.read_bytes() if old.exists() else None),path
    target=out/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(source)
    diff=''.join(difflib.unified_diff(before.decode().splitlines(True) if before else [],source.splitlines(True),fromfile='a/'+path,tofile='b/'+path));f=out/'diffs'/(path+'.patch');f.parent.mkdir(parents=True,exist_ok=True);f.write_text(diff)
    records.append(dict(path=path,bytes=len(source.encode()),sha256=hashlib.sha256(source.encode()).hexdigest()))
(out/'manifest.json').write_text(json.dumps(records,indent=2)+'\n')
print('Review final prose in',out)
