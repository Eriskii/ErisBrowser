use eris::page::Page;
use url::Url;
fn main() {
    println!("ComputedStyle size={} align={}",std::mem::size_of::<eris::css::ComputedStyle>(),std::mem::align_of::<eris::css::ComputedStyle>());
    println!("HitRegion size={} align={}",std::mem::size_of::<eris::layout::HitRegion>(),std::mem::align_of::<eris::layout::HitRegion>());
    println!("LayoutResult size={} align={}",std::mem::size_of::<eris::layout::LayoutResult>(),std::mem::align_of::<eris::layout::LayoutResult>());
    for source in [
        "var s=document.getElementById('target').style;s.setProperty('pointer-events','var(--late)');s.getPropertyValue('pointer-events');",
        "var s=document.getElementById('target').style;s.cssText='all:initial';true;",
        "var s=document.getElementById('target').style;s.cssText='all:initial';s.pointerEvents;",
        "var s=document.getElementById('target').style;s.cssText='all:initial';s.length;",
    ] {
        let mut page=Page::from_html(Url::parse("https://pointer-diagnostic.invalid/").unwrap(),"<div id=target></div>",false);
        println!("{source} => {:?}",page.runtime.execute(source,&mut page.document));
    }
}
