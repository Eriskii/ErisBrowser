from pathlib import Path
import hashlib,json,difflib,re,subprocess
H=Path(__file__).parent;P=H.parent
ROOT=P/'controls-1/pixel-contract-1.json';SUP=H/'supplemental-contract.json'
r=json.loads(ROOT.read_text());s=json.loads(SUP.read_text());base=r['base']
def bind(f):
 f=Path(f);v=f.read_bytes();return {'path':str(f),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def write(rel,text):
 f=H/rel;f.parent.mkdir(parents=True,exist_ok=True);assert not f.exists(),f;f.write_text(text);return f
def js(v):return 'r###"'+v+'"###'
def pixels(values):
 assert len(values)==48
 return '&[\n'+''.join('            '+', '.join(f'0x{x:06x}' for x in values[i:i+8])+',\n' for i in range(0,48,8))+'        ]'
head='''//! Literal pointer eligibility controls: pixels and retained geometry are independent of hit selection.
use eris::{
    dom::{NodeId, NodeKind},
    graphics::{Canvas, Color, Fonts},
    layout::{HitAction, LayoutResult},
    page::Page,
    script::Value,
};
use url::Url;

const WIDTH: u32 = 8;
const HEIGHT: u32 = 6;
type HitGeometry = (NodeId, HitAction, u32, u32, u32, u32, bool);

fn page(html: &str) -> Page {
    Page::from_html(Url::parse("https://pointer-events.invalid/").unwrap(), html, false)
}

fn node(page: &Page, id: &str) -> NodeId {
    page.document.query_selector(&format!("#{id}")).unwrap()
}

fn execute(page: &mut Page, strict: bool, source: &str) -> Value {
    if strict {
        page.runtime.execute_strict(source, &mut page.document)
    } else {
        page.runtime.execute(source, &mut page.document)
    }
    .unwrap()
}

fn snapshot(page: &Page, fonts: &Fonts) -> (LayoutResult, Vec<u32>) {
    let layout = page.layout(WIDTH as f32, HEIGHT as f32, fonts);
    let mut canvas = Canvas::new(WIDTH, HEIGHT).unwrap();
    canvas.clear(Color::WHITE);
    canvas.paint(&layout.commands, fonts, &page.images, 0.0, 0.0);
    assert!(!canvas.exhausted());
    assert_eq!(canvas.pixels.len(), 48);
    assert!(page.diagnostics.is_empty(), "{:?}", page.diagnostics);
    (layout, canvas.pixels)
}

fn geometry(layout: &LayoutResult) -> Vec<HitGeometry> {
    layout.hit_regions.iter().map(|hit| (
        hit.node, hit.action, hit.rect.x.to_bits(), hit.rect.y.to_bits(),
        hit.rect.width.to_bits(), hit.rect.height.to_bits(), hit.fixed,
    )).collect()
}

fn preserved(before: &(LayoutResult, Vec<u32>), after: &(LayoutResult, Vec<u32>)) {
    assert_eq!(after.1, before.1, "pointer eligibility must not alter pixels");
    assert_eq!(geometry(&after.0), geometry(&before.0), "all existing hit fields and ordering");
    assert_eq!(after.0.content_height.to_bits(), before.0.content_height.to_bits());
    assert_eq!(after.0.node_visibility, before.0.node_visibility);
}

fn check(html: &str, expected: &[u32; 48], points: &[(f32, f32, &str)]) {
    let page = page(html);
    let (layout, pixels) = snapshot(&page, &Fonts::new());
    assert_eq!(pixels.as_slice(), expected);
    for &(x, y, id) in points {
        assert_eq!(layout.hit_test(x, y), Some(node(&page, id)), "point ({x},{y}): {id}");
    }
}
'''
parts=[head];strings=[];roster=[]
for row in r['scenes']:
 name='pointer_events_'+row['name'];roster.append({'name':name,'kind':'literal pixels and fixed owner','modes':1,'contract':row['name']})
 points='&['+', '.join(f'({float(x):.1f}, {float(y):.1f}, "{owner}")' for x,y,owner in row['targets'])+']'
 parts.append(f'\n#[test]\nfn {name}() {{\n    check(\n        {js(row["html"])},\n        {pixels(row["pixels"])},\n        {points},\n    );\n}}\n');strings.append(row['html'])
t=s['transition'];html=next(v['html'] for v in r['scenes'] if v['name']==t['html_scene']);strings.append(html)
parts.append('''
#[test]
fn pointer_events_cssom_auto_none_auto_preserves_pixels_and_geometry() {
    for strict in [false, true] {
        let mut page = page(HTML);
        let fonts = Fonts::new();
        let before = snapshot(&page, &fonts);
        assert_eq!(before.1.as_slice(), PIXELS);
        for (source, target) in PHASES {
            execute(&mut page, strict, source);
            let after = snapshot(&page, &fonts);
            preserved(&before, &after);
            assert_eq!(after.0.hit_test(3.0, 3.0), Some(node(&page, target)), "strict={strict}, target={target}");
        }
    }
}
'''.replace('page(HTML)',f'page({js(html)})').replace('PIXELS',pixels(r['paint_geometry_transition']['pixels'])).replace('PHASES','[\n'+''.join(f'            ({js(src)}, "{target}"),\n' for src,target in zip(t['sources'],t['targets']))+'        ]'))
strings+=t['sources'];roster.append({'name':'pointer_events_cssom_auto_none_auto_preserves_pixels_and_geometry','kind':'CSSOM transition and complete old hit tuple preservation','modes':2,'phases_per_mode':3})
t=s['text'];strings.append(t['html']);strings+=t['sources']
parts.append('''
#[test]
fn pointer_events_inline_text_inheritance_and_explicit_override() {
    for strict in [false, true] {
        let mut page = page(HTML);
        let inline = node(&page, "inline");
        assert_eq!(page.document.nodes[inline].children.len(), 1);
        let text = page.document.nodes[inline].children[0];
        assert!(matches!(&page.document.nodes[text].kind, NodeKind::Text(value) if value == "X"));
        let under = node(&page, "under");
        let fonts = Fonts::new();
        let before = snapshot(&page, &fonts);
        assert!(before.0.hit_regions.iter().any(|hit| hit.node == text));
        assert!(before.1.iter().any(|&pixel| pixel != 0x0000ff));
        for (source, expected) in PHASES {
            if !source.is_empty() {
                execute(&mut page, strict, source);
            }
            let after = snapshot(&page, &fonts);
            preserved(&before, &after);
            assert_eq!(after.0.hit_test(1.0, 1.0), Some(expected), "strict={strict}");
        }
    }
}
'''.replace('page(HTML)',f'page({js(t["html"])})').replace('PHASES','[\n'+''.join(f'            ({js(src)}, {owner}),\n' for src,owner in zip(t['sources'],['under','text','under']))+'        ]'))
roster.append({'name':'pointer_events_inline_text_inheritance_and_explicit_override','kind':'fixed DOM text child owner and inline inheritance','modes':2,'phases_per_mode':3})
t=s['table'];strings.append(t['html']);strings+=t['sources']
parts.append('''
#[test]
fn pointer_events_table_row_and_cell_have_independent_owners() {
    for strict in [false, true] {
        let mut page = page(HTML);
        let fonts = Fonts::new();
        let before = snapshot(&page, &fonts);
        for id in ["under", "row", "cell", "other"] {
            assert!(before.0.hit_regions.iter().any(|hit| hit.node == node(&page, id)), "retained {id}");
        }
        for (source, targets) in PHASES {
            if !source.is_empty() {
                execute(&mut page, strict, source);
            }
            let after = snapshot(&page, &fonts);
            preserved(&before, &after);
            for (x, id) in [1.5, 3.5, 4.5].into_iter().zip(targets) {
                assert_eq!(after.0.hit_test(x, 1.5), Some(node(&page, id)), "strict={strict}, x={x}, owner={id}");
            }
        }
    }
}
'''.replace('page(HTML)',f'page({js(t["html"])})').replace('PHASES','[\n'+''.join('            ('+js(src)+', ['+', '.join('"'+v+'"' for v in targets)+']),\n' for src,targets in zip(t['sources'],t['targets']))+'        ]'))
roster.append({'name':'pointer_events_table_row_and_cell_have_independent_owners','kind':'row spacing and cell owner matrix with retained geometry','modes':2,'phases_per_mode':4})
t=s['events'];strings.extend([t['html'],t['setup'],t['readback']])
parts.append('''
#[test]
fn pointer_events_reenabled_child_keeps_capture_and_bubble_without_skipped_sibling() {
    for strict in [false, true] {
        let mut page = page(HTML);
        execute(&mut page, strict, SETUP);
        let child = node(&page, "child");
        let (layout, _) = snapshot(&page, &Fonts::new());
        // The expected DOM owner is fixed independently before event dispatch.
        assert_eq!(layout.hit_test(1.0, 1.0), Some(child));
        page.runtime.dispatch_click(child, &mut page.document).unwrap();
        assert_eq!(execute(&mut page, strict, READBACK), Value::String(EXPECTED.into()), "strict={strict}");
    }
}
'''.replace('page(HTML)',f'page({js(t["html"])})').replace('SETUP',js(t['setup'])).replace('READBACK',js(t['readback'])).replace('EXPECTED',json.dumps(t['expected'])))
roster.append({'name':'pointer_events_reenabled_child_keeps_capture_and_bubble_without_skipped_sibling','kind':'fixed child point target then public event dispatch','modes':2,'phases_per_mode':1})
source=''.join(parts);path='tests/pointer_events.rs';out=write('raw/'+path,source)
actual=re.findall(r'r###"([\s\S]*?)"###',source);assert actual==strings,(len(actual),len(strings))
assert re.findall(r'^fn (pointer_events_\w+)\(',source,re.M)==[v['name'] for v in roster]
assert len(roster)==13 and len(actual)==25
repo='/home/eriskii/Documents/Programming/Projects/ErisBrowser'
tracked=subprocess.check_output(['git','-C',repo,'ls-tree','-r','--name-only',base]).decode().splitlines();assert path not in tracked
refs=[]
for rel in ['tests/visibility.rs','tests/canvas_display.rs','src/dom.rs','src/layout.rs','src/page.rs','src/script.rs']:
 data=subprocess.check_output(['git','-C',repo,'show',base+':'+rel]);refs.append({'path':rel,'base':base,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
forward=write('diffs/forward/'+path+'.patch',''.join(difflib.unified_diff([],source.splitlines(True),fromfile='/dev/null',tofile='b/'+path)))
inverse=write('diffs/inverse/'+path+'.patch',''.join(difflib.unified_diff(source.splitlines(True),[],fromfile='b/'+path,tofile='/dev/null')))
before=write('before.json',json.dumps({'base':base,'path':path,'exists':False},indent=2)+'\n')
registration=write('registration.txt','tests/pointer_events.rs is discovered by Cargo as an integration test. No module registration or Cargo manifest edit is required.\n')
rf=write('roster.json',json.dumps(roster,indent=2)+'\n')
checks=write('checks.json',json.dumps({'static_source_checks':{'root_scene_count':9,'root_scene_html_exact':True,'root_pixel_integers_exact':432,'root_point_rows':sum(len(v['targets']) for v in r['scenes']),'supplement_js_strings_exact':True,'raw_html_js_occurrences':len(actual),'test_groups':13,'dynamic_modes':8,'phase_snapshots':22,'parent_api_only':True,'new_enum_or_hit_field_used':False,'new_file_absent_at_base':True},'qualifications':['No project imports, compilation, formatting, or tests were run.','Static scenes run once; only JS-driven groups loop strict/sloppy.','Fixed DOM owner assertions precede event dispatch. Text owner comes from DOM children, never hit_test.','The nine scene oracles were frozen by root independently. Supplemental literals were frozen before conversion, after author source review; no test or measured outcome informed them.'],'source_bindings':refs},indent=2)+'\n')
ready={'schema':1,'status':'held public test payload; source-checked, unexecuted','base':base,'literals_ready':bind(H/'literals-ready.json'),'contracts':[bind(ROOT),bind(SUP)],'files':[{'path':path,'before':bind(before),'raw':bind(out),'forward':bind(forward),'inverse':bind(inverse)}],'roster':bind(rf),'registration':bind(registration),'checks':bind(checks),'author':bind(Path(__file__)),'test_groups':13,'project_execution':False,'project_imports':False,'live_edits':False}
f=write('source-ready.json',json.dumps(ready,indent=2)+'\n');print(json.dumps(bind(f)))
