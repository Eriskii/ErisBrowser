#!/usr/bin/env python3
"""Source-only hold authoring and literal joins; never imports or executes Eris."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import struct
import subprocess

P = Path('/tmp/eris-pointer-events-plan-1')
H = P / 'dynamic-controls-1'
W = P / 'worktree'
BASE = '3d90bd578f2b17318e3e5831849e0aee526e68c4'
def sha(data): return hashlib.sha256(data).hexdigest()
def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')
def git(path):
    return subprocess.run(['git','-C',str(W),'show',f'{BASE}:{path}'],check=True,capture_output=True).stdout
def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

contract_path = P/'controls-1/dynamic-contract-1.json'
fixture_path = P/'controls-1/pointer-events-dynamic.html'
assert sha(contract_path.read_bytes()) == '16fd002056523a86a83851fe3dee37f94b4169b7b4649114d1c584d99662ee5c'
contract = json.loads(contract_path.read_bytes())
assert contract['base'] == BASE
assert bind(fixture_path)['sha256'] == contract['fixture']['sha256']
new = [
 'tests/pointer_events_dynamic.rs',
 'tests/worker/pointer_events_dynamic.rs',
 'tests/support/pointer_events_dynamic.rs',
 'tests/fixtures/pointer-events-dynamic.html',
]
tracked = subprocess.run(['git','-C',str(W),'ls-tree','-r','--name-only',BASE], check=True,capture_output=True,text=True).stdout.splitlines()
assert not set(new).intersection(tracked)
assert (H/'raw'/new[-1]).read_bytes() == fixture_path.read_bytes()
support = (H/'raw/tests/support/pointer_events_dynamic.rs').read_text()
assert 'PointerEvents' not in support
assert '[16, 20]' in support and 'HEIGHT: u32 = 12' in support
rect_text = support.split('const RECTANGLES:',1)[1].split('];',1)[0]
rects = [[int(v.strip(),0) for v in row.split(',')] for row in re.findall(r'\((\d+,\s*\d+,\s*\d+,\s*\d+,\s*0x[0-9a-f]+)\)',rect_text)]
assert rects == contract['pixels']['ordered_rectangles']
phase_map = {'Initial':'initial','ClickToggle':'click-toggle','ClickMain':'click-current-main-point','ClickChild':'click-child-point','DrainTasks':'drain-tasks'}
rows = [{'action': phase_map[a], 'target': target, 'title': title} for a,target,title in re.findall(r'\(Action::(\w+), "([^"]+)", "([^"]+)"\)',support)]
assert rows == contract['scripts_on']
points = [[int(float(x)),int(float(y))] for x,y in re.findall(r'\.hit_test\(([\d.]+), ([\d.]+)\)',support)]
assert points == list(contract['points'].values())
for file in new[:2]:
    text = (H/'raw'/file).read_text()
    assert '#[test]' in text and text.count('#[test]') == 1
    assert 'PointerEvents' not in text and 'pointer_events:' not in text
    for value in ['for scripts in [false, true]', 'for (action, main, title) in oracle::PHASES', 'if scripts { main } else { "over" }', 'if scripts { title } else { "auto" }']:
        assert value in text
    assert 'oracle::assert_geometry' in text and 'oracle::assert_targets' in text
    assert 'oracle::assert_pixels' in text

inputs = [
 'tests/visibility_dynamic.rs', 'tests/worker/visibility_dynamic.rs',
 'tests/support/visibility_dynamic.rs', 'tests/support/vulkan_backgrounds.rs',
 'tests/worker.rs', 'src/layout.rs', 'src/page.rs', 'src/worker.rs',
 'src/dom.rs', 'src/graphics.rs',
]
input_bindings = []
for path in inputs:
    data = git(path)
    save(H/'before'/path,data)
    input_bindings.append({'path':path,'bytes':len(data),'sha256':sha(data),'git_base':BASE})
worker = git('tests/worker.rs')
fragment = b'\n#[path = "worker/pointer_events_dynamic.rs"]\nmod pointer_events_dynamic;\n'
assert b'mod pointer_events_dynamic;' not in worker
save(H/'registration/worker-append.rs',fragment)
proposed = worker+fragment
assert proposed[:-len(fragment)] == worker
save(H/'diff/registration-worker.diff',''.join(difflib.unified_diff(worker.decode().splitlines(keepends=True),proposed.decode().splitlines(keepends=True),fromfile='a/tests/worker.rs',tofile='b/tests/worker.rs')).encode())
magic_path = P/'browser-implementation-1/worker-magic-chunks.json'
magic_chunks = json.loads(magic_path.read_bytes())
def magic(text):
    for item in magic_chunks:
        assert text.count(item['before']) == item['occurrences'] == 1
        text = text.replace(item['before'],item['after'])
    return text
assert magic(proposed.decode()) == magic(worker.decode())+fragment.decode()
write_json(H/'registration/proposal.json',{
 'path':'tests/worker.rs','operation':'append','append':fragment.decode(),
 'parent_sha256':sha(worker),'proposal_only':True,
 'instruction':'Root composes the append with the separately sealed five magic-only chunks and any other independent registrations. No full replacement of tests/worker.rs is supplied.',
 'exact_inverse':'Remove the single exact append fragment to recover all preceding bytes.',
 'magic_chunks':bind(magic_path),'two_order_composition_equal':True,
 'parent_plus_append_sha256':sha(proposed),
 'parent_plus_magic_and_append_sha256':sha(magic(proposed.decode()).encode()),
})
payloads = []
for path in new:
    data = (H/'raw'/path).read_bytes()
    diff = ''.join(difflib.unified_diff([],data.decode().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+path))
    save(H/'diff'/(path+'.diff'),diff.encode())
    payloads.append({'path':path,'operation':'add','bytes':len(data),'sha256':sha(data),'raw':'raw/'+path,'diff':'diff/'+path+'.diff','inverse':'Remove only this previously absent new path.'})
checks = []
for width in contract['widths']:
    pixels = [contract['pixels']['clear']]*(width*contract['height'])
    for left,top,w,h,color in rects:
        assert left+w <= width and top+h <= contract['height']
        for y in range(top,top+h):
            pixels[y*width+left:y*width+left+w] = [color]*w
    checks.append({'width':width,'height':contract['height'],'pixels':len(pixels),'u32_le_sha256':sha(b''.join(struct.pack('<I',v) for v in pixels)),'source':'Root-frozen ordered rectangle literals; stdlib expansion only, not a renderer output.'})
write_json(H/'checks.json',{
 'status':'source-ready-unexecuted','contract':bind(contract_path),'fixture':bind(fixture_path),
 'fixture_copy_exact':True,'rectangles_exact':True,'phases_exact':True,'points_exact':True,
 'no_new_enum_or_field_reference':True,'new_paths_absent_at_base':True,
 'existing_api_joins':input_bindings,'registration_inverse_exact':True,
 'registration_magic_composition_exact':True,'literal_pixel_arrays':checks,
 'groups':[
 {'name':'pointer_events_dynamic_keeps_pixels_geometry_and_auto_child_event_ancestors','path':new[0],'modes':[False,True],'phases_per_mode':6,'widths_per_phase':2,'planned_checks_if_completed':24},
 {'name':'confined_pointer_events_dynamic_keeps_pixels_geometry_and_auto_child_event_ancestors','path':new[1],'ignored':True,'ignore_reason':'requires Linux Landlock ABI 6; launches a confined renderer and broker','modes':[False,True],'generations':[741,742],'phases_per_mode':6,'widths_per_phase':2,'planned_checks_if_completed':24},
 ],
 'observations':[
  'Both adapters dispatch click actions using the actual preceding point target; the independent literal expected target is also asserted at every phase.',
  'Geometry comparisons cover existing node/action/rect IEEE bits/fixed fields, exact order and content-height bits. Each width has its own initial snapshot, retained across all phases.',
  'The pixels are fully compared with literal rectangles for every snapshot; raster-bridge additionally compares the existing CPU native-plan witness against those same arrays.',
  'Confined checks require exact generation, zero processed edit sequence, Idle, no navigation and exactly two diagnostics with the existing process/broker prefixes.',
 ],
 'qualification':'Source/stdlib inspection only. No build, project import, formatter, test, browser, renderer or worker execution. Snapshot counts are the planned complete path, not measured results. CPU native-plan comparisons do not claim a Vulkan hardware run.',
})
write_json(H/'integration.json',{
 'base':BASE,'new_files':new,'registration':'registration/proposal.json',
 'owns_existing_file_replacements':[],
 'root_actions':'Import four new files; compose worker module append with five previously held magic chunks. Root owns formatting, baseline/candidate execution and any later corrections.',
 'test_filter':'pointer_events_dynamic','worker_filter':'confined_pointer_events_dynamic',
 'no_literal_correction':True,
})
artifacts = []
for path in sorted(H.rglob('*')):
    if path.is_file() and path.name != 'source-ready.json':
        data = path.read_bytes()
        artifacts.append({'path':str(path.relative_to(H)),'bytes':len(data),'sha256':sha(data)})
write_json(H/'source-ready.json',{
 'status':'source-ready-unexecuted','base':BASE,'owner':'script',
 'contract':bind(contract_path),'fixture':bind(fixture_path),
 'scope':'Two parent-compatible dynamic integration groups, shared root-literal oracle and unchanged fixture, with a separate worker module append proposal.',
 'payloads':payloads,'registration':bind(H/'registration/proposal.json'),
 'checks':bind(H/'checks.json'),'artifacts':artifacts,
 'no_execution_or_live_edits':True,
})
print(json.dumps(bind(H/'source-ready.json'),indent=2))
