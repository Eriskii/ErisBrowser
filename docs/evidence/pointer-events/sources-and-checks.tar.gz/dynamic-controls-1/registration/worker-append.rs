
#[path = "worker/pointer_events_dynamic.rs"]
mod pointer_events_dynamic;
