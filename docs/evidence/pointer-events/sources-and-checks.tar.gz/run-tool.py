import hashlib,json,os,subprocess,sys,time
from pathlib import Path
p=Path(__file__).resolve().parent;o=p/'validation';o.mkdir(exist_ok=True)
def source_state():
    w=p/'worktree'
    tracked=subprocess.check_output(['git','diff','--name-only'],cwd=w,text=True).splitlines()
    added=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=w,text=True).splitlines()
    rows=[]
    for name in sorted(set(tracked+added)):
        data=(w/name).read_bytes()
        rows.append({'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
    return {'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),'changed':rows}
before=source_state()
label,*argv=sys.argv[1:];env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';start=time.monotonic();log=o/(label+'.log')
with log.open('xb') as f:r=subprocess.run(argv,cwd=p/'worktree',env=env,stdout=f,stderr=subprocess.STDOUT,close_fds=True)
after=source_state()
record={'command':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-start,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'source_before':before,'source_after':after}
with (o/(label+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record),flush=True);print(log.read_text()[-6000:]);raise SystemExit(r.returncode)
