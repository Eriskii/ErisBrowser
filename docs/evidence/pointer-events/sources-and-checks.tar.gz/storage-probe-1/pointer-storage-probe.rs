fn main() {
    println!("ComputedStyle size={} align={}", size_of::<eris::css::ComputedStyle>(), align_of::<eris::css::ComputedStyle>());
    println!("HitRegion size={} align={}", size_of::<eris::layout::HitRegion>(), align_of::<eris::layout::HitRegion>());
    println!("LayoutResult size={} align={}", size_of::<eris::layout::LayoutResult>(), align_of::<eris::layout::LayoutResult>());
}
