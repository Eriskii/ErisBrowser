from pathlib import Path
import hashlib,json,difflib,subprocess,re
P=Path('/tmp/eris-pointer-events-plan-1');H=P/'css-implementation-1';W=Path('/tmp/eris-canvas-display-plan-1/worktree');BASE='af46557a774e2e4b07cc23a7b6e39397eace2e04'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,s):
 p=H/p;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def put(p,j):write(p,json.dumps(j,indent=2)+'\n')
design=P/'design-1.json';selection=json.loads(design.read_text());assert selection['css']['roster_after']=='visibility'
oldpaths=['src/css.rs','src/cssom.rs','src/css/visibility.rs','src/css/pending_inline_budget_tests.rs','src/cssom/pending_record_tests.rs','src/cssom/pending_record_accounting_tests.rs']
before={p:(W/p).read_text() for p in oldpaths}
for p,s in before.items():
 assert s.encode()==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]);write('before/'+p,s)
after=dict(before);edits=[]
def replace(p,a,b,count=1):
 assert after[p].count(a)==count,(p,a,after[p].count(a),count)
 after[p]=after[p].replace(a,b);edits.append({'path':p,'before':a,'after':b,'occurrences':count})
css='src/css.rs'
replace(css,'mod visibility;','mod keyword_value;\nmod pointer_events;\nmod visibility;')
replace(css,'pub use visibility::Visibility;','pub use pointer_events::PointerEvents;\npub(crate) use pointer_events::valid as valid_pointer_events;\npub use visibility::Visibility;')
replace(css,'    pub visibility: Visibility,','    pub visibility: Visibility,\n    pub pointer_events: PointerEvents,')
replace(css,'            visibility: Visibility::Visible,','            visibility: Visibility::Visible,\n            pointer_events: PointerEvents::Auto,')
replace(css,'            s.visibility = p.visibility;','            s.visibility = p.visibility;\n            s.pointer_events = p.pointer_events;')
replace(css,'    "visibility",\n    "object-fit",','    "visibility",\n    "pointer-events",\n    "object-fit",')
replace(css,'            "color"\n                | "visibility"','            "color"\n                | "visibility"\n                | "pointer-events"')
replace(css,'''        "visibility" => {
            if let Ok(Some(visibility)) = visibility::parse(value, work) {
                s.visibility = visibility;
            }
        }
''','''        "visibility" => {
            if let Ok(Some(visibility)) = visibility::parse(value, work) {
                s.visibility = visibility;
            }
        }
        "pointer-events" => {
            if let Ok(Some(pointer_events)) = pointer_events::parse(value, work) {
                s.pointer_events = pointer_events;
            }
        }
''')
replace(css,'        "visibility" => s.visibility = p.visibility,','        "visibility" => s.visibility = p.visibility,\n        "pointer-events" => s.pointer_events = p.pointer_events,')
replace(css,'''    if name == "visibility" {
        valid_visibility(value, work)
    } else if name == "border-spacing" {''','''    if name == "visibility" {
        valid_visibility(value, work)
    } else if name == "pointer-events" {
        valid_pointer_events(value, work)
    } else if name == "border-spacing" {''')
replace(css,'''    if name == "visibility" {
        let mut work = MAX_SUPPORTS_WORK;
        return valid_visibility(value, &mut work).unwrap_or(false);
    }
''','''    if name == "visibility" {
        let mut work = MAX_SUPPORTS_WORK;
        return valid_visibility(value, &mut work).unwrap_or(false);
    }
    if name == "pointer-events" {
        let mut work = MAX_SUPPORTS_WORK;
        return valid_pointer_events(value, &mut work).unwrap_or(false);
    }
''')
# Only the selected keyword-valued properties share this classification.
replace(css,'/// The bounded two-argument CSS.supports(property, value) capability check.', '''fn keyword_value_property(name: &str) -> Option<&'static str> {
    ["visibility", "pointer-events"]
        .into_iter()
        .find(|property| name.eq_ignore_ascii_case(property))
}

/// The bounded two-argument CSS.supports(property, value) capability check.''')
replace(css,'        let visibility_property = property.eq_ignore_ascii_case("visibility");','        let keyword_property = keyword_value_property(property).is_some();')
replace(css,'&& !(visibility_property && visibility::escape_allowed(*token))','&& !(keyword_property && keyword_value::escape_allowed(*token))')
replace(css,'            "border-spacing"\n                | "visibility"','            "border-spacing"\n                | "visibility"\n                | "pointer-events"')
replace(css,r'''        let visibility_property = name.eq_ignore_ascii_case("visibility")
            || name.contains('\\')
                && css_identifier(name).is_some_and(|(decoded, end)| {
                    end == name.len() && decoded.eq_ignore_ascii_case("visibility")
                });''',r'''        let keyword_property = keyword_value_property(name).or_else(|| {
            if !name.contains('\\') {
                return None;
            }
            let (decoded, end) = css_identifier(name)?;
            if end == name.len() {
                keyword_value_property(&decoded)
            } else {
                None
            }
        });''')
replace(css,'        if image_property || box_property || spacing_property || visibility_property {','        if image_property || box_property || spacing_property || keyword_property.is_some() {')
replace(css,'&& !(visibility_property && visibility::escape_allowed(*t))','&& !(keyword_property.is_some() && keyword_value::escape_allowed(*t))')
replace(css,'''            let name = if visibility_property {
                "visibility".into()
            } else {
                name.to_ascii_lowercase()
            };''','''            let name = keyword_property.map_or_else(|| name.to_ascii_lowercase(), str::to_owned);''')
replace('src/cssom.rs', '''    if property == "visibility" {
        return css::valid_visibility(value, work).map_err(|_| Error::Limit);
    }
''','''    if property == "visibility" {
        return css::valid_visibility(value, work).map_err(|_| Error::Limit);
    }
    if property == "pointer-events" {
        return css::valid_pointer_events(value, work).map_err(|_| Error::Limit);
    }
''')
visibility='''//! Inherited visibility for boxes that retain their layout contribution.
use super::keyword_value;
use crate::selectors::Error;

#[repr(u8)]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum Visibility {
    #[default]
    Visible = 0,
    Hidden = 1,
}

const KEYWORDS: [&str; 7] = [
    "visible",
    "hidden",
    "inherit",
    "initial",
    "unset",
    "revert",
    "revert-layer",
];

pub(crate) fn valid(value: &str, work: &mut usize) -> Result<bool, Error> {
    Ok(keyword_value::keyword(value, &KEYWORDS, work)?.is_some())
}

pub(super) fn parse(value: &str, work: &mut usize) -> Result<Option<Visibility>, Error> {
    Ok(match keyword_value::keyword(value, &KEYWORDS, work)? {
        Some("visible") => Some(Visibility::Visible),
        Some("hidden") => Some(Visibility::Hidden),
        _ => None,
    })
}
'''
replace('src/css/visibility.rs',before['src/css/visibility.rs'],visibility)
after['src/css/keyword_value.rs']='''//! Shared bounded grammar for two-value inherited keyword properties.
use crate::selectors::{self, Error, Kind, Token, spend};

// Supports scanners prepay the token scan. Final grammar validation below
// checks decoded spelling; this predicate only permits escaped identifiers.
pub(super) fn escape_allowed(token: Token<'_>) -> bool {
    token.kind == Kind::Ident && !token.raw.contains('\\0')
}

pub(super) fn keyword(
    value: &str,
    keywords: &[&'static str; 7],
    work: &mut usize,
) -> Result<Option<&'static str>, Error> {
    if value.len() > 4096 {
        return Err(Error::Limit);
    }
    // Prepay the significant-token pass and at most seven decoded comparisons.
    spend(work, value.len().saturating_mul(8) + 1)?;
    let tokens = selectors::tokens(value, work)?;
    let mut significant = tokens.iter().filter(|token| token.kind != Kind::Whitespace);
    let Some(token) = significant.next() else {
        return Ok(None);
    };
    if significant.next().is_some() || !escape_allowed(*token) {
        return Ok(None);
    }
    Ok(keywords.iter().copied().find(|name| token.is_name(name)))
}
'''
after['src/css/pointer_events.rs']='''//! Inherited point-targeting eligibility; independent of paint and focus.
use super::keyword_value;
use crate::selectors::Error;

#[repr(u8)]
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
pub enum PointerEvents {
    #[default]
    Auto = 0,
    None = 1,
}

const KEYWORDS: [&str; 7] = [
    "auto",
    "none",
    "inherit",
    "initial",
    "unset",
    "revert",
    "revert-layer",
];

pub(crate) fn valid(value: &str, work: &mut usize) -> Result<bool, Error> {
    Ok(keyword_value::keyword(value, &KEYWORDS, work)?.is_some())
}

pub(super) fn parse(value: &str, work: &mut usize) -> Result<Option<PointerEvents>, Error> {
    Ok(match keyword_value::keyword(value, &KEYWORDS, work)? {
        Some("auto") => Some(PointerEvents::Auto),
        Some("none") => Some(PointerEvents::None),
        _ => None,
    })
}
'''
replace('src/css/pending_inline_budget_tests.rs','("all", 87)','("all", 88)')
p='src/cssom/pending_record_tests.rs'
replace(p,'assert_eq!(style.len(), 88);','assert_eq!(style.len(), 89);',2)
replace(p,'assert_eq!(style.item(21), "border-spacing");','assert_eq!(style.item(22), "border-spacing");')
replace(p,'assert_eq!(style.item(87), "vertical-align");','assert_eq!(style.item(88), "vertical-align");')
replace(p,'assert_eq!(style.item(88), "");','assert_eq!(style.item(89), "");')
replace(p,'for custom_count in [169, 170]','for custom_count in [168, 169]')
replace(p,'if custom_count == 169','if custom_count == 168')
replace(p,'// 87 target names total 1059 bytes; 87*(737+4)+1059=65526.\n    // --pad contributes 5+1+4=10, giving exactly 65536.','// 88 target names total 1073 bytes; 88*(728+4)+1073=65489.\n    // --pad contributes 5+38+4=47, giving exactly 65536.')
replace(p,'"0".repeat(728)','"0".repeat(719)')
replace(p,'assert_eq!(pending.len(), 737);','assert_eq!(pending.len(), 728);')
replace(p,'let filler = "x".to_string();','let filler = "x".repeat(38);')
replace('src/cssom/pending_record_accounting_tests.rs','assert_eq!(style.declarations().len(), 88);','assert_eq!(style.declarations().len(), 89);')
files=[]
for p in sorted(after):
 a=before.get(p,'');b=after[p];write('raw/'+p,b)
 write('diffs/forward/'+p+'.patch',''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+p if a else '/dev/null',tofile='b/'+p)))
 write('diffs/inverse/'+p+'.patch',''.join(difflib.unified_diff(b.splitlines(True),a.splitlines(True),fromfile='a/'+p,tofile='b/'+p if a else '/dev/null')))
 files.append({'path':p,'before':bind(H/'before'/p) if a else None,'raw':bind(H/'raw'/p),'forward':bind(H/'diffs/forward'/(p+'.patch')),'inverse':bind(H/'diffs/inverse'/(p+'.patch'))})
put('edits.json',edits)
# Independent text inverse, full inherited visibility table/grammar and fixtures.
for p in before:
 s=after[p]
 for e in reversed([e for e in edits if e['path']==p]):
  assert s.count(e['after'])==e['occurrences'],(p,e['after']);s=s.replace(e['after'],e['before'])
 assert s==before[p]
oldvis=before['src/css/visibility.rs'];newcore=after['src/css/keyword_value.rs']
oldgate=oldvis[oldvis.index('    if value.len() > 4096'):oldvis.index('    Ok([')]
newgate=newcore[newcore.index('    if value.len() > 4096'):newcore.index('    Ok(keywords')]
assert oldgate==newgate
oldpred=oldvis[oldvis.index('pub(super) fn escape_allowed'):oldvis.index('\nfn keyword')]
newpred=newcore[newcore.index('pub(super) fn escape_allowed'):newcore.index('\npub(super) fn keyword')]
assert oldpred==newpred
words=re.findall(r'"([a-z-]+)"',oldvis[oldvis.index('    Ok(['):oldvis.index('    .into_iter()')]);assert words==['visible','hidden','inherit','initial','unset','revert','revert-layer']
assert words==re.findall(r'"([a-z-]+)"',re.search(r'const KEYWORDS:.*?= \[(.*?)\];',visibility,re.S).group(1))
roster=re.findall(r'"([a-z-]+)"',re.search(r'const SUPPORTED_PROPERTIES:.*?=\s*&\[(.*?)\];',after[css],re.S).group(1))
oldroster=re.findall(r'"([a-z-]+)"',re.search(r'const SUPPORTED_PROPERTIES:.*?=\s*&\[(.*?)\];',before[css],re.S).group(1))
assert roster==oldroster[:2]+['pointer-events']+oldroster[2:];assert (len(roster),sum(map(len,roster)))==(88,1073)
assert 168+len(roster)==256 and 169+len(roster)==257
assert 1073+88*(728+4)+(5+38+4)==65536 and len('var(--x,'+'0'*719+')')==728
old_tests={}
for p in oldpaths[3:]:
 old_tests[p]=re.findall(r'#\[test\]\s*fn (\w+)\(',before[p]);assert old_tests[p]==re.findall(r'#\[test\]\s*fn (\w+)\(',after[p])
visibility_controls=[]
for p in ['src/css/visibility_tests.rs','src/css/visibility_budget_tests.rs','tests/visibility.rs']:
 b=(W/p).read_bytes();assert b==subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]);visibility_controls.append({'path':p,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest(),'not_changed':True})
put('checks.json',{'status':'source checks clear; unexecuted','selection':bind(design),'old_visibility_core_gate_and_escape_predicate_exact':True,'old_visibility_keyword_order_exact':True,'old_visibility_control_bindings':visibility_controls,'before_files_published_parent_exact':BASE,'inverse_all_existing_paths_exact':True,'roster':{'longhands':88,'name_bytes':1073,'insert_after':'visibility'},'caps':{'record_exact':256,'record_one_over':257,'logical_exact':65536,'logical_one_over':65537,'pending_zeros':719,'pending_bytes':728,'filler_bytes':38},'old_fixture_names_exact':old_tests,'production_paths':sorted(p for p in after if p not in oldpaths[3:]),'fixture_paths':oldpaths[3:],'scope':'Only CSS parsing/type/cascade/supports/CSSOM wiring and four historical assertions/fixtures across three test files. No new tests or downstream hit/codec fields.','pending':'Bind final canvas published commit and verify every existing before/source-control byte against it before import.','project_execution':False,'live_edits':False})
put('source-ready.json',{'schema':1,'status':'held source ready; final canvas published-base receipt required before import','origin':str(W),'origin_published_parent':BASE,'selection':bind(design),'files':files,'edits':bind(H/'edits.json'),'checks':bind(H/'checks.json'),'author':bind(H/'author.py'),'interfaces':['css::PointerEvents Auto=0 default / None=1 repr(u8)','ComputedStyle.pointer_events','css::valid_pointer_events(&str,&mut usize)->Result<bool,selectors::Error>'],'path_count':len(files),'project_execution':False,'live_edits':False})
print(json.dumps(bind(H/'source-ready.json')))
