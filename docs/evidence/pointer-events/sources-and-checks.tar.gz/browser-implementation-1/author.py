from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

P = Path('/tmp/eris-pointer-events-plan-1')
H = P / 'browser-implementation-1'
W = P / 'worktree'
BASE = '3d90bd578f2b17318e3e5831849e0aee526e68c4'

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def write(path, text):
    path = H / path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)

def put(path, value):
    write(path, json.dumps(value, indent=2) + '\n')

assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD']).decode().strip() == BASE
before = {}
raw = {}
chunks = []

def load(path):
    if path not in raw:
        text = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + path]).decode()
        assert (W / path).read_text() == text
        before[path] = text
        raw[path] = text
    return raw[path]

def replace(path, old, new, category, occurrences=1):
    text = load(path)
    assert old and text.count(old) == occurrences, (path, old, text.count(old))
    raw[path] = text.replace(old, new)
    chunks.append({'path': path, 'before': old, 'after': new, 'occurrences': occurrences, 'category': category})

browser = 'src/browser.rs'
codec = 'src/worker/codec.rs'
replace(browser, '    css::Visibility,', '    css::{PointerEvents, Visibility},', 'production-import')
replace(browser, '''        snapshot.layout.hit_regions.iter().rev().find(|h| {
            h.rect.contains(
                x / self.zoom,
                (y - TOOLBAR + if h.fixed { 0.0 } else { self.scroll }) / self.zoom,
            )
        })''', '''        snapshot.layout.hit_regions.iter().rev().find(|h| {
            h.pointer_events == PointerEvents::Auto
                && h.rect.contains(
                    x / self.zoom,
                    (y - TOOLBAR + if h.fixed { 0.0 } else { self.scroll }) / self.zoom,
                )
        })''', 'production-point-filter')
replace(codec, '    css::Visibility,', '    css::{PointerEvents, Visibility},', 'production-import')
replace(codec, 'const MAGIC: &[u8] = b"ERWB";', 'const MAGIC: &[u8] = b"ERWC";', 'production-protocol-version')
replace(codec, '''        e.byte(match hit.action {
            HitAction::Node => 0,
            HitAction::DefaultSummary => 1,
        });''', '''        e.byte(match hit.action {
            HitAction::Node => 0,
            HitAction::DefaultSummary => 1,
        });
        e.byte(match hit.pointer_events {
            PointerEvents::Auto => 0,
            PointerEvents::None => 1,
        });''', 'production-encode')
replace(codec, '''        hit_regions.push(HitRegion {
            node,
            rect,
            fixed,
            action,
        });''', '''        let pointer_events = match d.byte()? {
            0 => PointerEvents::Auto,
            1 => PointerEvents::None,
            _ => return Err("unknown IPC pointer events".into()),
        };
        hit_regions.push(HitRegion {
            node,
            rect,
            fixed,
            action,
            pointer_events,
        });''', 'production-decode')

for path, indent, count in [
    (browser, '                ', 2),
    ('src/browser/native_scene.rs', '                ', 1),
    ('src/browser/visibility_tests.rs', '        ', 1),
    ('src/worker/codec/visibility_tests.rs', '        ', 1),
]:
    old = indent + 'action: HitAction::Node,\n'
    replace(path, old, old + indent + 'pointer_events: PointerEvents::Auto,\n', 'historical-field-only', count)

magic_counts = {
    codec: 3,
    'src/worker/codec/background_image_tests.rs': 3,
    'src/worker/codec/background_geometry_tests.rs': 1,
    'src/worker/codec/box_decoration_tests.rs': 2,
    'src/worker/codec/gradient_tests.rs': 1,
    'src/worker/codec/visibility_tests.rs': 1,
    'tests/worker.rs': 5,
}
for path, count in magic_counts.items():
    lines = [line for line in load(path).splitlines(True) if 'ERWB' in line]
    assert len(lines) == count
    for line in lines:
        replace(path, line, line.replace('ERWB', 'ERWC'), 'historical-current-magic-only')
replace(codec, 'for old in [b"ERWA", b"ERW9", b"ERW8"] {', 'for old in [b"ERWB", b"ERWA", b"ERW9", b"ERW8"] {', 'historical-add-old-version-refusal')
replace('src/worker/codec/visibility_tests.rs', '''        let mut old = encoded;
        old[..4].copy_from_slice(b"ERWA");
        assert!(
            matches!(decode_reply(&old), Err(error) if error == "invalid IPC version/message kind")
        );''', '''        for magic in [b"ERWB", b"ERWA"] {
            let mut old = encoded.clone();
            old[..4].copy_from_slice(magic);
            assert!(
                matches!(decode_reply(&old), Err(error) if error == "invalid IPC version/message kind")
            );
        }''', 'historical-add-old-version-refusal')

for path in [browser, codec]:
    replace(path, '#[cfg(test)]\nmod visibility_tests;', '#[cfg(test)]\nmod visibility_tests;\n#[cfg(test)]\nmod pointer_events_tests;', 'new-test-registration')
path = 'src/browser/native_scene.rs'
tail = '\n#[cfg(test)]\n#[path = "native_scene/pointer_events_tests.rs"]\nmod pointer_events_tests;\n'
old = load(path)
raw[path] = old + tail
chunks.append({'path': path, 'before': '', 'after': tail, 'occurrences': 1, 'category': 'new-test-registration', 'operation': 'append'})
new_paths = {
    'src/browser/pointer_events_tests.rs': 'browser.rs',
    'src/browser/native_scene/pointer_events_tests.rs': 'native.rs',
    'src/worker/codec/pointer_events_tests.rs': 'codec.rs',
}
for path, source in new_paths.items():
    assert not (W / path).exists()
    raw[path] = (H / 'tests-input' / source).read_text()

# Full inverse for each changed existing file, in reverse edit order.
restored = dict(raw)
for chunk in reversed(chunks):
    path = chunk['path']
    if chunk.get('operation') == 'append':
        assert restored[path].endswith(chunk['after'])
        restored[path] = restored[path][:-len(chunk['after'])]
    else:
        assert restored[path].count(chunk['after']) == chunk['occurrences'], path
        restored[path] = restored[path].replace(chunk['after'], chunk['before'])
assert all(restored[path] == value for path, value in before.items())

files = []
for path, after in sorted(raw.items()):
    old = before.get(path, '')
    if path in before:
        write('before/' + path, old)
    write('raw/' + path, after)
    forward = ''.join(difflib.unified_diff(old.splitlines(True), after.splitlines(True), fromfile='a/' + path if old else '/dev/null', tofile='b/' + path))
    inverse = ''.join(difflib.unified_diff(after.splitlines(True), old.splitlines(True), fromfile='a/' + path, tofile='b/' + path if old else '/dev/null'))
    write('diff/' + path + '.diff', forward)
    write('inverse/' + path + '.diff', inverse)
    files.append({'path': path, 'before': binding(H / 'before' / path) if old else None, 'raw': binding(H / 'raw' / path), 'diff': binding(H / 'diff' / (path + '.diff')), 'inverse': binding(H / 'inverse' / (path + '.diff'))})

put('chunks.json', chunks)
worker_chunks = [x for x in chunks if x['path'] == 'tests/worker.rs']
assert len(worker_chunks) == 5 and all(x['occurrences'] == 1 for x in worker_chunks)
put('worker-magic-chunks.json', worker_chunks)
groups = {path: re.findall(r'#\[test\]\s*fn (\w+)\(', raw[path]) for path in new_paths}
assert [len(groups[p]) for p in new_paths] == [4, 1, 5]
put('test-contract.json', {
    'status': 'producer-authored bounded browser/codec regression source; no execution',
    'groups': groups, 'new_groups': 10, 'default_groups': 9,
    'native_group_configuration': 'Linux vulkan-raster; CPU paints composed native phases, no GPU execution',
    'browser': [
        'Two retained synthetic regions distinguish document/fixed coordinates at zoom2/scroll800. Auto/None changes only selection; edge/toolbar/generation exclusions and length remain.',
        'None retains offscreen Tab, Shift-Tab, edit eligibility, button Enter and generated-summary Space activation.',
        'None snapshot preserves pending edit/focus; completed acknowledgement remains accepted and an older Auto acknowledgement cannot replace it.',
        'Fragment lookup uses retained None geometry and keeps its original fixed-hit exclusion.'
    ],
    'codec': [
        'Fixtures are assembled from literal ERWC fields without Encoder. Single0, single1 and ordered1/0 records preserve exact23-byte stride, geometry, action and flag through encode/decode.',
        'Unknown2/255, every truncation and trailing bytes refuse.',
        'Malformed node, finite geometry, nonnegative size, fixed boolean and action remain errors with None; hidden-node refusal precedes new data.',
        'Zero hits remain valid, MAX_COMMANDS+1 refuses, ERWB/ERWA/ERW9/ERW8 refuse.',
        'None permits a genuine default-summary action, while a forged ordinary target still refuses.'
    ],
    'qualification': 'Browser/native tests set the scalar directly to isolate consumer behavior. Root owns independent CSS/point/event/direct/confined controls. No parent/candidate outcome is inferred.'
})
put('review-notes.json', {
    'production_functions_changed': ['Browser::hit_region', 'encode_snapshot', 'decode_snapshot'],
    'other_production_change': 'Import PointerEvents and advance shared MAGIC ERWB to ERWC.',
    'order': 'Existing node/visibility/rect/fixed/action checks precede strict pointer byte, which precedes HitRegion push.',
    'preserved': 'Every currently retained hit, all old caps, node_visibility, focus/IME/Tab, keyboard/default-summary activation, ancestor dispatch, fragment jumps, CPU/native focus painters and native benchmark identity remain unchanged.',
    'fixed_cursor_limitation': 'accept_snapshot still clears status without recomputing hover_clickable/native cursor until CursorMoved; point selection reads latest accepted metadata. No new pointerenter/leave/capture behavior.',
    'historical_fields': 5, 'historical_current_magic_literals': 16, 'older_version_sites_extended': 2,
    'layout_fixture_owner': 'Layout owns five additional src/layout fixture initializers and four layout producers; none are included here.',
    'worker_registration_composition': 'Root owns tests/worker.rs registration. Apply worker-magic-chunks.json to that file rather than replacing a root-composed version. The full raw file here is lineage/reference only after independent registration changes.',
    'all_existing_file_inverse_checks': True,
    'authoring_check_qualification': 'An initial in-memory inverse check rejected global magic-token replacement because it also matched the new production constant. Full-line fixture anchors corrected that authoring ambiguity before any payload or source-ready files were written. No project command or test expectation changed.',
    'project_execution': False, 'project_imports': False, 'live_edits': False
})
put('source-ready.json', {
    'schema': 1, 'status': 'source-ready held browser/codec implementation and regressions; unexecuted',
    'base': BASE, 'origin': str(W), 'design': binding(P / 'design-1.json'),
    'assessment': binding(Path('/tmp/eris-pointer-events-browser-assessment-1.json')),
    'files': files, 'changed_existing_paths': len(before), 'new_paths': len(new_paths),
    'chunks': binding(H / 'chunks.json'), 'worker_magic_chunks': binding(H / 'worker-magic-chunks.json'),
    'test_contract': binding(H / 'test-contract.json'), 'review_notes': binding(H / 'review-notes.json'),
    'author': binding(H / 'author.py'), 'new_test_groups': 10,
    'exact_inverse': True, 'project_execution': False, 'project_imports': False, 'live_edits': False,
    'producer_authored_test_qualification': 'These native/codec tests complement root-owned independent semantic controls; they are not described as producer-blind.'
})
print(json.dumps(binding(H / 'source-ready.json')))
