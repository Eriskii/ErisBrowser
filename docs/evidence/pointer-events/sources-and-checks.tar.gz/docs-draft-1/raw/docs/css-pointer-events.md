# CSS pointer-events: auto and none

`pointer-events:none` excludes a box from the existing point-target search
without removing its painting or layout geometry. Content behind it can become
the target. The inherited default is `auto`; a descendant can explicitly restore
`auto` inside a `none` ancestor. The ancestor remains on the descendant's event
path, so capture and bubbling still work. These are the HTML `auto`/`none`
behaviors described by [CSS UI 4](https://www.w3.org/TR/2026/WD-css-ui-4-20260120/#pointer-events-control),
a Working Draft whose broader hit-testing and selection details remain open.

Values use one decoded, ASCII-insensitive identifier. CSS-wide keywords,
variables, layer/importance ordering and the `all` shorthand follow the existing
cascade. Invalid later declarations do not replace an earlier valid declaration;
an invalid computed variable value uses the inherited property's `unset`
behavior. Inline `style.pointerEvents`, `setProperty`, removal and getters use
the bounded CSSOM machinery. The supported longhand roster now has 88 entries.

Feature queries share the keyword validator. A condition can decode an escaped
CSS property name, while the two-argument `CSS.supports(property,value)` API
keeps its literal-name rule. Queries containing unresolved `var()` retain Eris's
conservative false result. This is a capability-query limitation, not a claim
that variable references are invalid CSS; valid references defer property
validation under [CSS Variables](https://www.w3.org/TR/2022/CR-css-variables-1-20220616/#using-variables).

Layout retains every admitted hit region, its rectangle and its order. The
ordinary-box, default-summary, text and table-row producers record their own
computed pointer value. Direct layout and native browser point selection skip
`none` and continue through the previous paint-order search. Existing clipping,
fixed/scroll coordinates and zoom rules remain in force.

Keyboard focus, editing reconciliation, fragment scrolling and native focus
outlines continue to use all retained geometry. A pointer setting does not clear
focus or suppress keyboard activation. Node-targeted event dispatch and DOM
ancestry are unchanged. `visibility:hidden` still excludes its own hit regions;
`pointer-events:auto` does not revive them. `display:none`, canvas-background
selection and all painting behavior remain unchanged by this checkpoint.

ERWC carries one additional 0/1 byte after each hit action: `0` for `auto`, `1`
for `none`. Each serialized hit is 23 bytes, independent of Rust structure
padding. `none` records remain valid because other consumers need their geometry.
Unknown values and old protocol versions are rejected; previous node, visibility,
rectangle and action checks remain. There is no additional per-node table.

The existing limits remain: layout creates at most 100,000 hits, while the worker
decoder retains its separate 200,000-hit ceiling and existing frame cap. The new
wire cost is one byte per hit. CSS raw-value, work, 256-record and 65,536-byte
logical-storage limits are unchanged; `all` fixture arithmetic accounts for the
larger roster. [PENDING: actual ComputedStyle/HitRegion size and alignment, vector
stride consequences, and final source-bound storage observations.]

[PENDING: actual focused parent/candidate results and complete suite counts.]
[PENDING: strict checks, existing visual references and direct/worker witnesses.]
[PENDING: retained failure/correction qualification and exact CI status.]
[PENDING: final evidence manifest and source/check archive links.]

The controls cover target changes alongside unchanged geometry/pixels, inherited
and re-enabled regions, event paths, focus, exact grammar budgets and malformed
transport. They are bounded implementation regressions. SVG-specific values,
pointer capture, specialized pointer events, touch/drag selection and complete
hit-testing conformance are not added. There is no GPU validation, new benchmark,
Chromium speed comparison, whole-browser or production-security claim.
