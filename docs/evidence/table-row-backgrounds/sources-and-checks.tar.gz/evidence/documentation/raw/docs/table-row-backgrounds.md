# Table row backgrounds

A row's color and supported gradient/URL layers now paint through the final
border rectangles of cells originating in that row. Inter-cell spacing shows
the table background. A colspan keeps its internal nominal track gaps filled;
a rowspan retains its originating row's paint over the whole cell, including
the vertical gap inside the span. This follows the [CSS table-layer rule](https://www.w3.org/TR/CSS22/tables.html#table-layers)
within the current rectangular table model.

Painting area and image positioning area remain separate. All cells in a row
use one tile origin and size derived from that row, so percentages, centering
and repetition do not restart at each cell. A no-repeat image on a rowspan
stays within its original row tile; repetition can reach the remaining cell
area. Row width for image positioning uses the final track sum and internal
horizontal gaps. For two fixed 6px tracks in a 10px table with 2px spacing,
that area is 14px wide, even though the existing row hit rectangle remains
6px wide. This changes painting phase without changing the table's sizing or
hit policy.

Missing grid slots have no originating cell and receive no invented row
paint. A real empty `td` or `th` still receives its row background under the
supported default-show behavior. The [Tables 3 draft's missing-cell rule](https://www.w3.org/TR/2025/WD-css-tables-3-20251216/#drawing-cell-backgrounds)
and its [WPT source](https://github.com/web-platform-tests/wpt/blob/master/css/css-tables/paint/row-background-paint-remove-last-cell.html)
make that distinction explicit. This is source-backed scope selection, not a
cross-browser execution result. An entirely empty row can keep its existing
layout height while contributing no cell background paint.

Image indices, layer order and resource bindings remain attached to the row.
A `none` or unavailable layer keeps its slot. The first authored image stays
on top; the row color is below its image layers, and cell backgrounds paint
above the row. Existing restacking retains row opacity and descendant order.
The same loaded keys and raster allocations are used; this change adds no
resource request or new rendering command.

A fully transparent row with exactly one `none` image returns before extra
work, command or key admission. For other rows, the final track sum is computed
lazily once after a prepaid column-count charge. Each real cell then reserves
one complete `1 + N` command/owner group and `16 + 16*N` units of the existing
geometry-work allowance, where `N` is the retained image-slot count. An opaque
color-only row has `N = 0`. Existing URL key clones additionally cost `len + 1`
work and `len` cumulative key bytes, within the unchanged 4,096/65,536-byte
per-key/frame bounds.

Refusing group capacity or geometry work omits that cell's row decoration
without changing its already computed layout or hits. Invalid principal
geometry is omitted without clamping its phase or substituting a child's
bounds. A refused URL key leaves that layer empty while other admitted layers
survive. Paint work is not refunded. Painted rows may now consume more
commands and key copies; the existing limits can therefore omit paint or
trigger whole-frame Native fallback earlier. There is no new per-cell style
clone, table membership matrix, shader, quota or resource authority.

Full intrinsic table sizing, row-group and column backgrounds, `empty-cells`
parsing/hide, `border-collapse`, general relative/rounded-cell clipping,
anonymous table construction and writing-mode/RTL table behavior remain
outside this increment. Caption, spacing and empty-table geometry retain
their earlier policies. These are focused table-background corrections,
not a claim of full table conformance or hardware performance.

Run `./run.sh ./examples/table-row-backgrounds.html` for gaps, spans and shared
image phase. Four 320×240 pairs use independently frozen literal RGBA frames
and solid positioned-rectangle references, including fixed-track overflow,
no-repeat and layer order.

Validation is pending in this draft: source `{{FINAL_SOURCE_HASH}}`; native
and default suites `{{NATIVE_TOTAL}}` / `{{DEFAULT_TOTAL}}`; strict checks
`{{STRICT_RESULTS}}`; references and literal/parent comparisons
`{{REFERENCE_AND_PIXEL_RESULTS}}`; measured types `{{TYPE_RESULTS}}`; CI
`{{CI_RESULTS}}`. Evidence: `{{EVIDENCE_LINK}}`. These placeholders are not
observed pass claims.
