from pathlib import Path
import hashlib,importlib.util,json,sys
A=Path(__file__).resolve().parent.parent
root=A/'worktree'
spec=importlib.util.spec_from_file_location('eris_reftest',root/'tools/reftest.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
report=json.loads((A/'reftests-final/report.json').read_text());assert report['failed']==0 and report['total']==102
oracle_path=A/'references/tests-before/oracles.json';oracles=json.loads(oracle_path.read_text());rows=[]
for case in oracles['cases']:
 literal=(A/'references/tests-before'/case['literal_rgba']['path']).read_bytes();assert hashlib.sha256(literal).hexdigest()==case['literal_rgba']['sha256']
 for suffix in ['', '-ref']:
  path=A/'reftests-final'/(case['name']+suffix+'.png');w,h,pixels=module.decode_png(path)
  assert (w,h)==(320,240) and pixels==literal,case['name']+suffix
  rows.append({'name':case['name']+suffix,'rgba_sha256':hashlib.sha256(pixels).hexdigest(),'png_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'bytes':len(pixels),'different_bytes':0})
record={'status':'pass','oracle_sha256':hashlib.sha256(oracle_path.read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((A/'reftests-final/report.json').read_bytes()).hexdigest(),'images':rows}
with (A/'root/reference-literals-final.json').open('x') as stream:json.dump(record,stream,indent=2);stream.write('\n')
print(json.dumps(record))
