"""Controlled Linux writable-FD inheritance witness, not an original-failure trace."""
import errno
import json
import os
from pathlib import Path
import subprocess
import tempfile

A = Path(__file__).resolve().parent.parent
result = {'scope': 'Controlled reproduction of ETXTBSY from an inherited writable executable descriptor; does not identify the child involved in the original suite failure.'}
with tempfile.TemporaryDirectory(prefix='eris-exec-witness-') as directory:
    path = Path(directory) / 'fixture'
    fd = os.open(path, os.O_CREAT | os.O_WRONLY | os.O_CLOEXEC, 0o700)
    os.write(fd, b'#!/bin/sh\nexit 0\n')
    ready_read, ready_write = os.pipe()
    release_read, release_write = os.pipe()
    child = os.fork()
    if child == 0:
        os.close(ready_read)
        os.close(release_write)
        os.write(ready_write, b'1')
        os.read(release_read, 1)
        os._exit(0)
    os.close(ready_write)
    os.close(release_read)
    try:
        assert os.read(ready_read, 1) == b'1'
        os.close(fd)
        try:
            subprocess.run([str(path)], check=True)
        except OSError as error:
            assert error.errno == errno.ETXTBSY
            result['parent_write_with_inherited_fd'] = {'errno': error.errno, 'name': errno.errorcode[error.errno]}
        else:
            raise AssertionError('Expected ETXTBSY while child retains the writer')
        isolated = Path(directory) / 'isolated'
        subprocess.run(['/bin/sh', '-c', 'umask 077; printf "%s" "$2" > "$1"', 'fixture-writer', str(isolated), '#!/bin/sh\nexit 0\n'], check=True)
        isolated.chmod(0o700)
        completed = subprocess.run([str(isolated)], check=True)
        result['child_write_while_same_sibling_is_alive'] = {'exit': completed.returncode}
    finally:
        os.write(release_write, b'1')
        os.close(release_write)
        os.close(ready_read)
        _, status = os.waitpid(child, 0)
        assert status == 0
with (A / 'root/fixture-exec-mechanism.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(result))
