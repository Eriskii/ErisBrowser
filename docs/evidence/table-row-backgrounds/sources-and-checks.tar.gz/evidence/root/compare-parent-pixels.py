from pathlib import Path
import hashlib
import json
import tarfile

A = Path(__file__).resolve().parent.parent
parent = A / 'worktree/docs/evidence/table-spacing'
summary = json.loads((parent / 'summary.json').read_text())
archive = parent / summary['archive']['path']
assert hashlib.sha256(archive.read_bytes()).hexdigest() == summary['archive']['sha256']
members = {m['name']: m for m in summary['members']}
rows = []
with tarfile.open(archive, 'r:gz') as saved:
    report_name = 'evidence/reftests-final/report.json'
    report_bytes = saved.extractfile(report_name).read()
    assert hashlib.sha256(report_bytes).hexdigest() == members[report_name]['sha256']
    report = json.loads(report_bytes)
    assert report['total'] == report['passed'] == 98 and report['failed'] == 0
    current = json.loads((A / 'reftests-final/report.json').read_text())
    assert current['passed'] == current['total'] == 102 and current['failed'] == 0
    assert [c['name'] for c in current['cases'][:98]] == [c['name'] for c in report['cases']]
    for case in report['cases']:
        for suffix in ('.png', '-ref.png'):
            name = case['name'] + suffix
            member = 'evidence/reftests-final/' + name
            old = saved.extractfile(member).read()
            assert hashlib.sha256(old).hexdigest() == members[member]['sha256']
            new = (A / 'reftests-final' / name).read_bytes()
            assert old == new, name
            rows.append({'name': name, 'bytes': len(new), 'sha256': hashlib.sha256(new).hexdigest(), 'different_bytes': 0})
record = {'status': 'pass', 'scope': '196 PNGs decoded by the respective reference runs and byte-identical to parent published archive members', 'parent_commit': 'c06bce2aa70d8d60dd1e7e22dc41c69efe653886', 'parent_archive_sha256': summary['archive']['sha256'], 'pairs': 98, 'images': rows}
with (A / 'root/parent-pixel-comparison.json').open('x') as output:
    json.dump(record, output, indent=2)
    output.write('\n')
print(json.dumps({k: v for k, v in record.items() if k != 'images'}))
