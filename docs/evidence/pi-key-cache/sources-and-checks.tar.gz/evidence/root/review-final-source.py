from pathlib import Path
import hashlib,json,re
p=Path('/tmp/eris-pi-key-cache-1');w=p/'worktree'
def bind(q):
 b=q.read_bytes();return {'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(q):return json.loads(q.read_text())
def tokens(s):
 out=[];comments=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   end=s.find('\n',i);end=len(s) if end<0 else end;comments.append(s[i:end]);i=end;continue
  m=re.match(r'r(#+)?"',s[i:])
  if m:
   start=i;hashes=m.group(1) or '';i+=len(m.group(0));end=s.find('"'+hashes,i);assert end>=0;i=end+1+len(hashes);out.append(s[start:i]);continue
  if s[i]=='"':
   start=i;i+=1
   while True:
    assert i<len(s)
    if s[i]=='\\':i+=2
    elif s[i]=='"':i+=1;break
    else:i+=1
   out.append(s[start:i]);continue
  m=re.match(r'[A-Za-z_][A-Za-z_0-9]*|[0-9]+(?:\.[0-9]+)?[A-Za-z_0-9]*',s[i:])
  if m:out.append(m.group(0));i+=len(m.group(0));continue
  assert not s.startswith('/*',i)
  out.append(s[i]);i+=1
 return [x for j,x in enumerate(out) if not(x==',' and j+1<len(out) and out[j+1] in [')',']','}'])],comments
parent=load(p/'parent-source.json')['source_sha256'];final=load(p/'source-1.json')['source_sha256'];assert len(parent)==767 and len(final)==769
added=sorted(final.keys()-parent.keys());removed=sorted(parent.keys()-final.keys());changed=sorted(k for k in parent.keys()&final.keys() if parent[k]!=final[k]);unchanged=sorted(k for k in parent.keys()&final.keys() if parent[k]==final[k])
assert removed==[] and added==['src/script/processing_instruction/key_cache_fee_tests.rs','src/script/processing_instruction/key_cache_tests.rs']
assert changed==['src/script/bootstrap_tests.rs','src/script/dom_prototypes.rs','src/script/processing_instruction.rs','src/script/typed_array/tests.rs']
for name,sha in final.items():
 q=w/name;assert not q.is_symlink();assert bind(q)['sha256']==sha,name
hold=load(p/'production-1/source-ready.json');assert bind(p/'production-1/source-ready.json')['sha256']=='c8b8fb79e8bce953923ca8353bcef9fec2fae7bc37c6fcb5030492429b740db1'
entries=[]
for entry in hold['files']:
 name=entry['target'];raw=Path(entry['raw']['path']);a=raw.read_text();b=(w/name).read_text();assert bind(raw)['sha256']==entry['raw']['sha256']
 if entry['before']:
  before=Path(entry['before']['path']);assert bind(before)['sha256']==entry['before']['sha256']==parent[name]
 else:assert name not in parent
 notes=[]
 if a==b:notes=['byte exact']
 else:
  if name.endswith('key_cache_fee_tests.rs'):
   old='use super::*;\nuse super::key_cache_tests::{CASES, cached_keys};';new='use super::key_cache_tests::{CASES, cached_keys};\nuse super::*;';assert a.count(old)==1;a=a.replace(old,new);notes.append('two existing use declarations reordered by formatter')
  assert tokens(a)==tokens(b),name
  notes.append('whitespace and optional trailing commas only; literal/comment tokens exact')
 if entry['frozen_migration']:assert raw.read_bytes()==(w/name).read_bytes()
 entries.append({'target':name,'held':entry['raw'],'installed':bind(w/name),'formatting':notes,'held_migration_exact':entry['frozen_migration']})
selected=load(p/'tests-before/source-ready-2.json');roster=[]
for test in selected['files']:
 held=Path(test['file']['path']);assert bind(held)['sha256']==test['file']['sha256'];target=w/test['target'];a=held.read_text();b=target.read_text()
 if test['target'].endswith('key_cache_fee_tests.rs'):a=a.replace('use super::*;\nuse super::key_cache_tests::{CASES, cached_keys};','use super::key_cache_tests::{CASES, cached_keys};\nuse super::*;')
 assert tokens(a)==tokens(b);roster.extend(re.findall(r'^fn (cached_pi_[A-Za-z_0-9]+)\(',b,re.M))
assert len(roster)==4
# The exact selected migration files were already source-reviewed; rebind to live bytes.
migrations=load(Path(selected['migrations']['path']))
for m in migrations['files']:assert (w/m['target']).read_bytes()==Path(m['after']['path']).read_bytes()
assert len(migrations['files'])==2
for name,sha in final.items():assert bind(w/name)['sha256']==sha,name
review={'status':'clear_source_only','source_snapshot':bind(p/'source-1.json'),'parent_inventory':bind(p/'parent-source.json'),'production_hold':bind(p/'production-1/source-ready.json'),'production_peer':bind(p/'production-1/script-review.json'),'inventory':{'parent_inputs':767,'final_inputs':769,'all_input_hashes_rechecked':True,'unchanged_parent_inputs':len(unchanged),'changed_parent_inputs':changed,'added_inputs':added,'removed_inputs':removed},'overlay':entries,'frozen_test_hold':bind(p/'tests-before/source-ready-2.json'),'test_roster':roster,'migrations':{'count':2,'manifest':selected['migrations'],'live_files_byte_exact_to_frozen_after':True,'scope':'Raw remaining793->1125; independent historical work expression+332 and charged-byte expression-1680, with explanatory comments. All other expectations unchanged.'},'source_conclusion':['Formatted production remains the reviewed borrowed-key cache: handoff8 before loop, paid2 before both clones per factory, unchanged property insertion/native admission stages.','Four frozen groups preserve every literal, JS body, assertion and exact/one-short quota boundary; only formatting/import order changed.','All other763 parent inputs are byte-identical, including Runtime/Value fields, throw-completion repair, caps, bootstrap reservation counts, CharacterData methods and arities.','No further production/test migration or integration fixture was introduced.'],'scope_limit':'Source-only hashing, lexical/diff review and inert artifact authoring. No project import/compiler/tests/formatter/browser/git or live edits; no runtime result claimed.','review_helper':bind(p/'root/review-final-source.py'),'format_diffs':[bind(q) for q in sorted((p/'root/final-source-review-diffs').rglob('*.patch'))]}
(p/'root/final-source-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(p/'root/final-source-review.json')))
