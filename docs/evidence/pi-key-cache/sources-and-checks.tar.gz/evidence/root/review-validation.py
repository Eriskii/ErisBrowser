from pathlib import Path
import hashlib,json,re,struct
p=Path(__file__).resolve().parent.parent

def bind(f):
 d=f.read_bytes();return {'path':str(f),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}

inventory=p/'source-1.json';sources=json.loads(inventory.read_text())['source_sha256'];assert len(sources)==769
for name,sha in sources.items():assert bind(p/'worktree'/name)['sha256']==sha,name
checks={}
for label in ['baseline-public-1','focused-runtime-1','native-full-1','default-full-1','strict-msrv-1','strict-current-1','format-check-1','browser-final-build-1','references-final-1']:
 r=json.loads((p/'validation'/(label+'.json')).read_text());assert r['exit']==(101 if label=='baseline-public-1' else 0)
 assert bind(p/'validation'/r['log'])['sha256']==r['sha256'];checks[label]=r
s=(p/'validation/baseline-public-1.log').read_text();assert '1 passed; 2 failed; 0 ignored;' in s
assert 'create length' in s and 'script instruction limit exceeded' in s
s=(p/'validation/focused-runtime-1.log').read_text();assert '4 passed; 0 failed; 0 ignored;' in s
counts={}
for label,total in [('native-full-1',3107),('default-full-1',2803)]:
 s=(p/'validation'/(label+'.log')).read_text();rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s)
 assert len(rows)==44 and sum(int(r[0]) for r in rows)==total
 assert all(all(int(n)==0 for n in r[1:]) for r in rows)
 assert len(re.findall(r'^test \S+ \.\.\. ok$',s,re.M))==total
 counts[label]={'passed':total,'result_rows':len(rows),'failed':0,'ignored':0}
refs=json.loads((p/'root/reference-comparison-final.json').read_text());assert refs['status']=='pass' and refs['pairs']==102 and refs['unchanged_pngs']==204
for row in refs['images']:assert bind(p/'reftests-final'/row['name'])['sha256']==row['sha256']
b=json.loads((p/'root/final-browser.json').read_text());f=Path(b['path']);assert bind(f)['sha256']==b['sha256'] and f.stat().st_size==b['bytes'];assert b['source_inventory_sha256']==bind(inventory)['sha256']
data=f.read_bytes();assert data[:6]==b'\x7fELF\x02\x01';off=struct.unpack_from('<Q',data,40)[0];size,count,index=struct.unpack_from('<HHH',data,58)
headers=[struct.unpack_from('<IIQQQQIIQQ',data,off+i*size) for i in range(count)];strings=headers[index];table=data[strings[4]:strings[4]+strings[5]];names=[table[h[0]:].split(b'\0',1)[0].decode() for h in headers]
assert not any(n in names for n in ['.debug_info','.debug_line','.debug_abbrev','.debug_str']) and '.debug_gdb_scripts' in names
review={'status':'clear','authority':'Root review of actual validation records; independent production and final-source peers are separately retained.','source_inventory':bind(inventory),'checks':checks,'totals':counts,'baseline':'1 descriptor/identity control pass;2 intended failures at held stages; private API group not run on parent.','focused':'All4heldgroupspass; ten factories exact andone-short; no assertion changes after observations.','references':bind(p/'root/reference-comparison-final.json'),'browser':bind(p/'root/final-browser.json'),'binary':bind(f),'elf_debug_sections':[n for n in names if n.startswith('.debug')],'qualification':'Logical charges and immutable backing identity, not wall-clock speedup, physical allocator savings or new GPU execution.','selector':bind(p/'root/select-evidence.py'),'documentation':bind(p/'worktree/docs/pi-key-cache.md')}
with (p/'root/validation-review.json').open('x') as out:json.dump(review,out,indent=2);out.write('\n')
print(json.dumps({'status':'clear','counts':counts,'source_inputs':len(sources),'browser_sha256':b['sha256']}))
