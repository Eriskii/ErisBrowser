from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent.parent

def bind(path):
 data=path.read_bytes()
 return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

inventory=root/'source-1.json';sources=json.loads(inventory.read_text())['source_sha256']
assert len(sources)==769
for name,sha in sources.items(): assert bind(root/'worktree'/name)['sha256']==sha,name
checks={}
for label in ['focused-runtime-1','native-full-1','default-full-1','strict-msrv-1','strict-current-1','format-check-1','browser-final-build-1','references-final-1']:
 r=json.loads((root/'validation'/(label+'.json')).read_text()); assert r['exit']==0
 assert bind(root/'validation'/r['log'])['sha256']==r['sha256'];checks[label]=r
for name in ['final-source-review.json','validation-review.json']:
 assert json.loads((root/'root'/name).read_text())['status'] in ('clear','clear_source_only')
totals=json.loads((root/'root/full-suite-totals.json').read_text())
assert totals['native-full-1']['passed']==3107 and totals['default-full-1']['passed']==2803
parent_ci=json.loads((root/'validation/parent-ci-final-1.log').read_text())
assert parent_ci['headSha']=='6ed96e7fb050c3cae7f10b13cca7016b94380b09'
assert parent_ci['conclusion']=='success' and len(parent_ci['jobs'])==9
assert all(j['conclusion']=='success' for j in parent_ci['jobs'])
reference=json.loads((root/'root/reference-comparison-final.json').read_text())
assert reference['status']=='pass' and reference['pairs']==102 and reference['unchanged_pngs']==204
artifacts={}
for directory in ['tests-before','production-1','character-data-arity-audit-1','validation','reftests-final','root']:
 for path in sorted((root/directory).rglob('*')):
  if path.is_file():
   assert not path.is_symlink()
   assert path.name not in ('selection-final.json','publication-verification.json')
   artifacts[str(path.relative_to(root))]=bind(path)
for path in sorted(root.glob('*')):
 if path.is_file() and path.suffix in ('.json','.py'):artifacts[path.name]=bind(path)
for name in ['README.md','docs/ROADMAP.md','docs/pi-key-cache.md']:
 artifacts['documentation/'+name]=bind(root/'worktree'/name)
selection={'source_inventory':bind(inventory),'artifacts':artifacts,'max_uncompressed_bytes':128*1024*1024,'claims':{
 'base':parent_ci['headSha'],
 'scope':'Reuse existing immutable length/name key payloads in ten ProcessingInstruction and CharacterData function metadata bags without changing public descriptors, identity or configured limits.',
 'source_inputs':769,
 'new_test_groups':{'public_descriptor_control':1,'stored_key_backing_identity':1,'raw_bootstrap_boundary':1,'private_factory_budget':1,'total':4},
 'parent_baselines':{'existing_api_groups':3,'compiled':3,'passed_control':1,'failed_as_predicted':2,
  'private_budget_baseline':'One new private API group was not compiled on the parent; no parent failure claimed.',
  'failure_stages':'First create length UTF-16 backing pointer differs; raw98874 refusal control passes then98875 intended success fails. Later bootstrap assertions are not parent observations.',
  'warning':'The baseline-only build warns about fields used only by the unimported private fee group; no warning suppression was introduced.'},
 'history':{'prebaseline_test_correction':'Two newly authored CharacterData arities were corrected from1/2 to existing production2/3 in exactly six literals before baseline. Original hold, source audit and additive correction preserved; production arities unchanged.',
  'old_test_migrations':{'count':2,'paths':['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs'],'scope':'Only source-derived work+332 and cumulative heap-1680 accounting and explanatory comments; other assertions unchanged.'},
  'source_inventory_sha256':bind(inventory)['sha256']},
 'checks':checks,
 'full_suite_totals':{key:{field:val[field] for field in ['passed','failed','ignored','result_rows','log_sha256']} for key,val in totals.items()},
 'references':{key:reference[key] for key in ['pairs','unchanged_pngs','parent_archive_sha256','report_sha256']},
 'browser':json.loads((root/'root/final-browser.json').read_text()),
 'parent_ci':{'head':parent_ci['headSha'],'url':parent_ci['url'],'conclusion':'success','jobs':9,'raw':bind(root/'validation/parent-ci-final-1.log')},
 'resource_policy':{'bootstrap_work_allowance':100000,'parent_raw_bootstrap_work':99207,'raw_bootstrap_work':98875,'raw_bootstrap_remaining':1125,'saved_work':332,'saved_cumulative_charged_bytes':1680,'author_work':100000,'cumulative_heap_bytes':8388608,'unchanged_numeric_caps':True,'objects':741,'native_registry':299,'prototypes':25,'globals':211,'new_persistent_header':False,
  'measurement_scope':'Logical prepaid charges and immutable backing identity; no physical allocator or processor-work guarantee.'},
 'limits':['Authored local tests, not imported WPT conformance results.','Cache-only preservation change; no new web API.','Promise remains absent; subsequent installation fit is a separate proposed change.','No Chromium performance comparison, full web compatibility, or production-security claim.','No new GPU or acquired-window observation; existing Vulkan backend unchanged.','Build caches reused; times are not cold-build measurements.']}}
with (root/'root/selection-final.json').open('x') as out:json.dump(selection,out,indent=2);out.write('\n')
print(json.dumps({'sources':len(sources),'artifacts':len(artifacts)}))
