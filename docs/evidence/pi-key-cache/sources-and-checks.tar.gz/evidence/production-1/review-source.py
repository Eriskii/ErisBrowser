from pathlib import Path
import difflib,hashlib,json,re
p=Path('/tmp/eris-pi-key-cache-1');o=p/'production-1'
def bind(q):
 b=q.read_bytes();return {'path':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(q):return json.loads(q.read_text())
def valid(b):
 a=bind(Path(b['path']));assert all(a[k]==b[k] for k in ['bytes','sha256']);return Path(b['path'])
assert bind(o/'source-ready.json')['sha256']=='c8b8fb79e8bce953923ca8353bcef9fec2fae7bc37c6fcb5030492429b740db1'
hold=load(o/'source-ready.json');tests=load(valid(hold['tests_api_ledger']));oracles=load(valid(tests['oracles']));migrations=load(valid(tests['migrations']));base=load(valid(hold['base_inventory']))['source_sha256']
for key in ['source_notes','tests_review','root_selection']:valid(hold[key])
selected={x['target']:valid(x['file']) for x in tests['files']};migration_map={x['target']:x for x in migrations['files']};rows=[]
for entry in hold['files']:
 raw=valid(entry['raw']);patch=valid(entry['diff']);before=valid(entry['before']) if entry['before'] else None
 name=entry['target'];a=before.read_text() if before else '';b=raw.read_text()
 if before:assert bind(before)['sha256']==base[name]
 expected=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+name if before else '/dev/null',tofile='raw/'+name))
 assert patch.read_text()==expected,name
 if entry['frozen_test']:assert raw.read_bytes()==selected[name].read_bytes()
 if entry['frozen_migration']:
  m=migration_map[name];valid(m['before']);valid(m['after']);assert before.read_bytes()==Path(m['before']['path']).read_bytes();assert raw.read_bytes()==Path(m['after']['path']).read_bytes()
 rows.append({'target':name,'before':entry['before'],'raw':entry['raw'],'diff_exact':True,'frozen_test_exact':entry['frozen_test'],'frozen_migration_exact':entry['frozen_migration']})
# Exact reverse of the complete two production files.
s=(o/'raw/src/script/dom_prototypes.rs').read_text()
s=s.replace('    pub(super) fn dom_proto_property(', '    fn dom_proto_property(',1)
s=s.replace('        // Reuse the immutable length/name pool across the ten PI factories.\n        self.work(8)?;\n        let pi_metadata_keys = [&keys[1], &keys[0]];\n','',1)
s=s.replace('self.install_pi_members(interface.name, prototype, pi_metadata_keys)?;','self.install_pi_members(interface.name, prototype)?;',1)
assert s==(o/'before/src/script/dom_prototypes.rs').read_text()
s=(o/'raw/src/script/processing_instruction.rs').read_text()
s=s.replace('#[cfg(test)]\nmod key_cache_fee_tests;\n#[cfg(test)]\nmod key_cache_tests;\n','',1)
s=s.replace('''    fn pi_function(
        &mut self,
        suffix: &str,
        display: &str,
        length: usize,
        metadata_keys: [&PropertyKey; 2],
    ) -> Result<Value> {''','''    fn pi_function(&mut self, suffix: &str, display: &str, length: usize) -> Result<Value> {''',1)
s=s.replace('''        // Pay for both borrowed-key clones before retaining either handle.
        self.work(2)?;
        self.dom_proto_property(
            properties,
            metadata_keys[0].clone(),''','''        self.dom_proto_named(
            properties,
            "length",''',1)
s=s.replace('''        self.dom_proto_property(
            properties,
            metadata_keys[1].clone(),''','''        self.dom_proto_named(
            properties,
            "name",''',1)
s=s.replace('''    pub(super) fn install_pi_members(
        &mut self,
        interface: &str,
        prototype: usize,
        metadata_keys: [&PropertyKey; 2],
    ) -> Result<()> {''','''    pub(super) fn install_pi_members(&mut self, interface: &str, prototype: usize) -> Result<()> {''',1)
assert s.count(', metadata_keys)?')==6;s=s.replace(', metadata_keys)?',')?')
assert s==(o/'before/src/script/processing_instruction.rs').read_text()
# Independent literal row arithmetic from fixed ten names, not candidate output.
literal=[('create','createProcessingInstruction',2,118,841),('target','get target',0,84,773),('data','get data',0,78,763),('setData','set data',1,81,766),('length','get length',0,84,773),('substringData','substringData',2,97,792),('appendData','appendData',1,88,777),('insertData','insertData',2,88,777),('deleteData','deleteData',2,88,777),('replaceData','replaceData',3,91,782)]
for row,oracle in zip(literal,oracles['ten_function_rows'],strict=True):
 suffix,display,arity,work,heap=row
 assert (58+2*len(display)+len(suffix),727+len(suffix)+4*len(display))==(work,heap)
 assert (oracle['suffix'],oracle['display'],oracle['arity'],oracle['new_work'],oracle['new_heap_constant'])==row
assert sum(x[3] for x in literal)==897
assert 10*(20+16)-10*2-8==332 and 10*(88+80)==1680
assert 100000-(99207-332)==1125 and 99207-332==98875
roster=[]
for q in selected.values():roster.extend(re.findall(r'^fn (cached_pi_[A-Za-z_0-9]+)\(',q.read_text(),re.M))
assert len(roster)==4
review={'status':'clear','scope':'Independent bounded source peer only: two production paths, four exact frozen groups and exactly two held historical accounting migrations.','hold':bind(o/'source-ready.json'),'selected_test_hold':hold['tests_api_ledger'],'prior_test_peer':hold['tests_review'],'root_selection':hold['root_selection'],'selected_oracles':tests['oracles'],'selected_migrations':tests['migrations'],'files':rows,'complete_production_reversals':'Both complete existing production files reconstructed byte-exact to their held before files and AG final source inventory hashes. All other code in these paths remains unchanged.','key_lifetime_and_identity':['Existing initializer pool is name0/length1; borrowed handoff supplies [&keys[1],&keys[0]], then metadata_keys[0]/[1] preserve length/name insertion order.','Each pi_function still allocates its own bag and Native. Only immutable PropertyKey UTF16 backing is shared; property values, flags, names, IDs, receiver and callable identity remain independent.','The borrowed pool stays live throughout the initializer; no new cache header, global, registry entry, arena reserve or Runtime field.','dom_proto_property visibility broadens only to the script parent/siblings; its existing full paid insertion implementation is byte-exact.'], 'fee_sequence':['One8-unit handoff occurs after key pool construction and before the interface loop, including before any of the ten factories.','Each factory retains original bag9 work and display8+2D stages, then pays2 before either key clone. Length and name still use fully charged property insertion:9 and15 work with the already-reserved order capacity.','Native admission remains last:15+suffix_bytes work and size_of<Native>+39+suffix_bytes heap. Thus work-short leaves this final heap envelope uncharged; heap-short occurs after final work, matching existing charge MAX_HEAP+1 semantics.','One private unexposed metadata bag may remain on factory refusal; tests and ledger state this explicitly. No stronger object-arena rollback guarantee inferred.'],'independent_arithmetic':{'old_per_factory_work':'92+2D+S','new_per_factory_work':'9+(8+2D)+2+9+15+(15+S)=58+2D+S','new_per_factory_heap':'727+S+4D + Option<AbortSlot> + Option<f64> +2*PropertyKey + leaf<PropertyKey,Property> + Native','sum_new_factory_work':897,'net_work_saving':'10*36-10*2-8=332','cumulative_charged_heap_saving':'10*(88+80)=1680','raw_bootstrap_work':98875,'raw_remaining':1125},'test_review':{'roster':roster,'selected_corrected_arities':'deleteData2 and replaceData3 match unchanged METHODS/Operation::arity; old incorrect hold remains history, not selected.','behavior_controls':'Strict/sloppy descriptors, mutable metadata independence, ten distinct bags and actual immutable-key pointer sharing; quota tests retain exact/one-short work and heap cuts.','migrations':'Only raw793->1125 and independent historical arithmetic+332/-1680 plus comments. Remaining counts, capacities, registry/prototypes/globals and semantic assertions are exact.'},'limits':'Logical prepaid-work and cumulative-byte savings only; no measured CPU/allocator/performance or Promise-startup outcome is claimed. No compiler, tests, formatter, browser, project imports, git or live edits.','review_helper':bind(o/'review-source.py')}
(o/'script-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(bind(o/'script-review.json')))
