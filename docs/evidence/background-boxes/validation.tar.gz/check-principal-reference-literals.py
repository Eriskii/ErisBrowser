from pathlib import Path
import importlib.util,json,hashlib
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('eris_reference',p/'worktree/tools/reftest.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
o=json.loads((p/'fixtures/oracles.json').read_text());rows=[]
for c in o['cases']:
 w,h=c['viewport'];expected=bytearray(bytes.fromhex(c['clear']+'ff')*(w*h))
 for x,y,dx,dy,rgb in c['ordered_rectangles_xywh_rgb']:
  assert 0<=x and 0<=y and x+dx<=w and y+dy<=h
  for row in range(y,y+dy):
   at=(row*w+x)*4;expected[at:at+dx*4]=bytes.fromhex(rgb+'ff')*dx
 f=p/'parent-principal-reftests-1'/(c['name']+'-ref.png');iw,ih,rgba=m.decode_png(f);assert (iw,ih)==(w,h) and rgba==expected,c['name']
 rows.append({'name':c['name'],'rgba_sha256':hashlib.sha256(expected).hexdigest(),'reference_png_sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
result={'oracle_sha256':hashlib.sha256((p/'fixtures/oracles.json').read_bytes()).hexdigest(),'scope':'Six absolute reference frames match their independently frozen literal pixels. Parent test inputs fail all six; candidate renderer integration remains pending.','cases':rows}
with (p/'principal-reference-literals-1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
