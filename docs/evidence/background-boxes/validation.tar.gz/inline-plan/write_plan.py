import json,hashlib
from pathlib import Path
T=Path('/tmp/eris-background-boxes-1'); W=T/'worktree'; D=T/'inline-plan'
S=Path('/tmp/eris-inline-edges-1/layout/local-baseline-correction-1/after')
base_css='body{margin:0}main{font-size:20px;line-height:26px}i{display:inline-block;width:4px;height:26px;vertical-align:top}span{border-left:1px solid transparent;border-right:2px solid transparent;padding-left:2px;padding-right:1px}'
plan={
 'status':'source-only independent oracle proposal; no project execution or production edits',
 'scope':'Ordinary horizontal LTR slice painting using S nominal owner geometry. No bidi, vertical writing, clone, block-in-inline or font-outline claim.',
 'spec_sources':[
  {'url':'https://drafts.csswg.org/css-break-3/#break-decoration','section':'5.4','basis':'Slice paints an unbroken decoration then cuts it; breaks add no side border or padding.'},
  {'url':'https://drafts.csswg.org/css-break-3/#joining-boxes','section':'5.4.1','basis':'Join line fragments in visual order, aligned on the dominant baseline. Unequal cross-sizes require the specified widest-fragment rule for ratio-derived dimensions.'},
  {'url':'https://drafts.csswg.org/css-break-3/#transforms','section':'5.5','basis':'Fragmentation precedes relative movement; descendant movement must not enlarge an ancestor strip.'},
  {'url':'https://drafts.csswg.org/css-backgrounds-3/#the-background-origin','section':'2.7','basis':'Origin selects the positioning box independently of the painting clip.'},
  {'url':'https://drafts.csswg.org/css-backgrounds-3/#the-background-clip','section':'2.8','basis':'Clip constrains both background color and background image.'}],
 'metric_basis':{
  'selected_source':'S held local-baseline-correction-1, not mutable live files',
  'formula':'owner content y = line_top + (local_baseline - .95*owner_font); height = .95*font + .35*font',
  'integer_fixture_choice':'font20, atomic height26 gives baseline26, owner y=line_top+7 and height26. The atomic children are transparent. Vertical border/padding is zero unless stated.',
  'empty_choice':'An empty decorated font20/line-height26 span contributes a strut: baseline19, descent7, owner y=line_top, height26.',
  'limitation':'This is the existing nominal metric policy, not measured glyph bounds or a new vertical-align model.'},
 'metadata_assessment':{
  'recommendation':'Explicit None/Color/Image/Border layer plus one border-prefix value is sufficient; retain DrawCommand and Fragment sizes. Measure PaintOwner on the root build rather than assume its layout.',
  'geometry_source':'Use all successfully completed per-line inline owner BoxGeometry, including lines whose decoration slots were refused. Never sum command rects, enclosing positioning unions or descendants\' rectangles.',
  'one_prefix_formula':'Let pB be the sum of preceding real border widths. In each fragment, virtual border x = real border x - pB. Full padding/content x is virtual border x + the owner\'s original left border / combined left border+padding. Full widths are separate sums of real B/P/C widths. Their equivalent prefixes are not interchangeable.',
  'zero_and_edges':'Keep first/last physical sides from geometry/style even when their paint was refused; do not infer first/last from visible slots. Exclude positioned-only anchors from decoration geometry. Empty decorated owners with nonzero padding/border remain real geometry.',
  'precision':'Accumulate/check in f64, then cast each stored f32 prefix once. Do not increment the running sum in f32 or use prefix equality as identity: at prefix524288 two widths0.03125 can disappear under repeated f32 addition while their f64 sum reaches524288.0625. Check translated virtual origins before publication; do not clamp them.',
  'translation':'Placeholders carry actual fragment translations. Widths and prefixes come from pre-descendant-relative geometry; translating a child or a fragment changes its origin, never the ancestor\'s width.',
  'order':'S line_plan boxes are close-order, but existing restack assigns DOM background ranks. Retain background=true on the entire balanced clip/layer sequence and same-owner color,image,border order; ancestor and child retain their own currentColor/opacity/fixed ownership.',
  'quota':'Preflight the complete balanced slot group before any command publication. Geometry accumulation and prefix advance must survive command/key refusal. Retain exact caller refusal semantics for a line whose geometry plan itself failed; do not invent unlaid future lines.',
  'finalizer':'Reserve/charge scans over both box records and slots. Explicit tags replace index-minus-one predecessor assumptions. Repeated finalization must not reinterpret resolved commands as private slots.',
  'fractional_clip_decision':'Canvas hard clip tests integer(x,y), while BoxDecoration samples fractional centers. An exact PushClip at y1.05 wrongly suppresses row1 that shape coverage accepts. Outward rounding on the nonfragmented vertical axis avoids double clipping the shape edge. Horizontal fractional cuts require an explicit existing hard-clip policy; blindly outward rounding both axes may paint across the cut. Integer cut fixtures below are unambiguous.'},
 'cases':[
  {'id':'forced_two_fragments_three_origins',
   'source':f'<style>{base_css}main{{width:20px}}</style><main><span><i></i><br><i></i></span></main>',
   'real_boxes':[
    {'border':[0,7,7,26],'padding':[1,7,6,26],'content':[3,7,4,26]},
    {'border':[0,33,7,26],'padding':[0,33,5,26],'content':[0,33,4,26]}],
   'full_widths':{'border':14,'padding':11,'content':8},
   'prefixes':{'border':[0,7],'padding':[0,6],'content':[0,4]},
   'virtual_origins_x':{'border':[0,-7],'padding':[1,-6],'content':[3,-4]},
   'paint':'Hard red/blue50% horizontal gradient, size100%100%, repeat both axes, clip border, transparent fallback/border. Change only origin among B/P/C.',
   'row_oracles':{'border':['RRRRRRR','BBBBBBB'],'padding':['BRRRRRB','BBBBBRR'],'content':['BBBRRRR','BBBBRRR']},
   'row_ranges':'Each first string is every integer row y7..32 inclusive over x0..6; second y33..58. Every other pixel is white.',
   'derivation':'First left physical inset3 and last right inset3 are paid once. The odd padding width11 has its hard stop at a pixel center; equality selects blue.'},
  {'id':'soft_three_fragments_independent_origin_and_clip',
   'source':f'<style>{base_css}main{{width:10px}}</style><main><span><i></i><i></i><i></i><i></i></span></main>',
   'real_boxes':[
    {'border':[0,7,7,26],'padding':[1,7,6,26],'content':[3,7,4,26]},
    {'border':[0,33,8,26],'padding':[0,33,8,26],'content':[0,33,8,26]},
    {'border':[0,59,7,26],'padding':[0,59,5,26],'content':[0,59,4,26]}],
   'full_widths':{'border':22,'padding':19,'content':16},
   'prefixes':{'border':[0,7,15],'padding':[0,6,14],'content':[0,4,12]},
   'virtual_origins_x':{'border':[0,-7,-15],'padding':[1,-6,-14],'content':[3,-4,-12]},
   'paint':'Hard red/blue50%, origin content, size100%100%, repeat, clip content.',
   'rows_width10':['WWWRRRRWWW','RRRRBBBBWW','BBBBWWWWWW'],
   'row_ranges':[[7,33],[33,59],[59,85]],
   'independent_clip_variant':{'paint':'Solid blue color, no image; cycle clip B/P/C; row bands as above.','border':['BBBBBBBWWW','BBBBBBBBWW','BBBBBBBWWW'],'padding':['WBBBBBBWWW','BBBBBBBBWW','BBBBBWWWWW'],'content':['WWWBBBBWWW','BBBBBBBBWW','BBBBWWWWWW']},
   'raster_variant':{'source_pixels':['RRBB','RRBB'],'natural_size':[4,2],'background_size':'100% auto','origin':'content','clip':'content','repeat':[False,False],'tiles':[[3,7,16,8],[-4,33,16,8],[-12,59,16,8]],'rows':'Same three red/blue strings, but only first8 rows of each owner band; all remaining rows white. This tests ratio sizing against full16px content width.'},
   'fit_reason':'First atom pays3 opening pixels. Two middle atoms fit8. Last atom plus3 closing pixels moves to a third line; no forced break is used.'},
  {'id':'nested_different_fonts_and_child_relative_offset',
   'source':'<style>body{margin:0}main{position:absolute;top:20px;width:30px;font-size:20px;line-height:26px}i{display:inline-block;width:4px;height:26px;vertical-align:top}span{padding:0 2px;background:red;background-clip:content-box}b{font-size:40px;padding:0 1px;position:relative;left:5px;top:3px;background:blue;background-clip:content-box}</style><main><span><i></i><b><i></i><i></i></b><i></i></span></main>',
   'outer':{'border':[0,27,22,26],'padding':[0,27,22,26],'content':[2,27,18,26]},
   'inner_before_relative':{'border':[6,8,10,52],'padding':[6,8,10,52],'content':[7,8,8,52]},
   'inner_after_relative':{'border':[11,11,10,52],'padding':[11,11,10,52],'content':[12,11,8,52]},
   'atomic_children_after_relative':[[2,20,4,26],[12,23,4,26],[16,23,4,26],[16,20,4,26]],
   'ordered_literal_rects':[[2,27,18,26,'R'],[12,11,8,52,'B']],
   'checks':'Outer content width stays18 (not23 or a union of child visual bounds); final sibling remainsx16. Inner font40 does not turn the parent\'s height26 into52. Source-only nominal metrics deliberately exclude half-leading.',
   'row_witnesses':{'y12':'W*12 B*8 W*10','y28':'W*2 R*10 B*8 W*10','y54':'W*12 B*8 W*10'}},
  {'id':'empty_decorated_owner_color_clip',
   'source':'<style>body{margin:0}main{position:absolute;left:20px;top:20px;font-size:20px;line-height:26px}span{border-style:solid;border-color:transparent;border-width:1px 2px 1px 1px;padding:1px 3px 2px 2px;background:blue}</style><main><span></span></main>',
   'real_boxes':{'border':[20,18,8,31],'padding':[21,19,5,29],'content':[23,20,0,26]},
   'full_widths':{'border':8,'padding':5,'content':0},
   'clip_oracles':{'border':[[20,18,8,31,'B']],'padding':[[21,19,5,29,'B']],'content':[]},
   'checks':'Exactly one owner geometry, no fake text glyph. Empty content does not erase padding/border color. This case does not assert a zero-area raster positioning policy or change nominal line metrics.'},
  {'id':'rounded_shape_sliced_only_at_real_breaks',
   'geometry_from':'soft_three_fragments_independent_origin_and_clip',
   'paint':'Solid red background, clip border, scalar border-radius4; no border color/image.',
   'full_virtual_shapes':[[0,7,22,26],[-7,33,22,26],[-15,59,22,26]],
   'checks':'Normalize radius4 on full22x26 shape, not each7/8/7px fragment. Broken edges gain no new corner. Use real rectangular fragment windows only as slice boundaries.',
   'literal_pixels':[{'at':[0,7],'color':'W','reason':'All16 samples lie outside radius4 outer TL.'},{'at':[0,33],'color':'R','reason':'Virtualx7 is full interior at the middle broken top edge.'},{'at':[7,33],'color':'R','reason':'Virtualx14 is also away from either physical corner.'},{'at':[6,59],'color':'W','reason':'Virtualx21 is the true outer TR corner; all16 samples outside.'},{'at':[0,60],'color':'R','reason':'Last fragment starts inside virtualx15; it is not a new left corner.'}]},
  {'id':'paint_refusal_cannot_shorten_geometry',
   'geometry_from':'soft_three_fragments_independent_origin_and_clip',
   'paint':'Natural4x2 RRBB/RRBB image, size100% auto, origin content, no-repeat, clip content.',
   'full_geometry_in_every_variant':{'border_width':22,'padding_width':19,'content_width':16,'border_prefixes':[0,7,15]},
   'first_only_slot_admitted':{'tile':[3,7,16,8],'pixels':'x3..6 red during y7..14, white outside the admitted image; later geometries still count.'},
   'first_and_last_slots_admitted_synthetic':{'tiles':[[3,7,16,8],[-12,59,16,8]],'pixels':'First fragment red; last fragment blue, never red or a newly resized tile. Skipping middle publication does not skip prefix8.'},
   'missing_binding':'All owner geometry/prefixes identical, no image key copied; any admitted background color remains.',
   'key_work_refusal':'Separate fresh setup at one-short key/work budget omits only the image; geometry and balanced clip state remain. Do not replenish a cumulative budget in an actual integration run.',
   'real_command_budget':'Use actual all-or-nothing group boundary after final group size is chosen. One-short must leave commands/owners/open_clips transactional while retaining completed geometry. Test first-only publication with later geometry, which is reachable under monotonic command exhaustion.',
   'finalizer_work':'Freeze exact source-derived fees after implementation design; do not guess numerical cuts now. One-short scan cannot publish a partially normalized strip; all private layer placeholders must remain suppressed.'},
  {'id':'fractional_y_clip_preserves_shape_samples',
   'geometry':{'border':[0,1.05,4,1.3],'padding':[0,1.05,4,1.3],'content':[0,1.05,4,1.3]},
   'paint':'One solid blue BoxDecoration, square corners, white target4x4; integer horizontal slice.',
   'independent_shape_rows':['WWWW','BBBB','qqqq','WWWW'],
   'palette':{'q':'#c0c0ff'},
   'derivation':'Row1 has16/16 grid samples; row2 has4/16 giving floor(255*4/16)=63, then blue-over-white leaves192 in red/green.',
   'decision_required':'A raw PushClip with exact fractional y rejects row1 under existing integer-point clip semantics. Preserve these shape pixels by avoiding redundant fractional vertical clipping; horizontal fractional cut semantics are separately bounded.'}
 ],
 'legacy_migrations':[
  {'source':'src/layout/gradient_tests.rs:inline_slice_continues_through_three_atomic_fragments_and_wrapping','old':'3 per-child gradients, tiles6x2 at y0/2, full old4x4 pixels.','new':'2 owner-line layers; full width6, nominal height1.3, owner y1.05/3.05. Preserve horizontal hard-stop phase and change count/vertical oracle explicitly. Do not keep old child-height rectangles as the new reference.'},
  {'source':'src/layout/gradient_tests.rs:nested_inline_uses_ancestor_color_and_real_piece_height','old':'Parent emitted3 layers with child height2.','new':'Parent one owner layer; child one layer if painted. Their own currentColor remains red/blue. Rename the real-piece-height assertion to the selected nominal-owner policy; fractional vertical coverage changes, not ancestor color semantics.'},
  {'source':'src/layout/background_tests.rs:inline_size_and_position_resolve_once_against_the_complete_virtual_strip','old':'Three tiles x3,3,-1 y0,0,2.','new':'Two tiles x3,-1; y becomes1.05,3.05 for the explicit2px-height top-positioned image. Full virtual width6 and 75% x offset3 stay fixed; same hits/child geometry.'},
  {'source':'src/layout/url_background_tests.rs:unavailable_inline_color_and_loaded_virtual_strip_have_literal_pixels','old':'Four image layers/8x4 tiles, lime fills each full2px child row.','new':'Two owner layers. Width8 and ratio-derived image size8x4 remain, while owner clip y1.05/3.05,h1.3 replaces child height2. Missing-image color follows the same owner clip. Fractional edge color+image composition must be derived before changing full pixel arrays.'},
  {'source':'src/layout/url_background_tests.rs:nested_inline_url_background_order_is_ancestor_then_child','new':'Same ancestor/child colors/order and content advances, but owner-line layers and nominal heights replace leaf layers. Preserve opaque interior horizontal color split.'},
  {'source':'gradient_tests pending_inline_admission... and url_background_tests inline_pending_slots...','new':'Replace old direct paint_inline_gradient fixture setup with explicit geometry plus tagged slots; preserve atomic reservation, no leaked pending data, key refusal keeps color, and true zero geometry cannot revive. Re-derive exact tariff only from reached new operations, not by relaxing budget assertions.'},
  {'source':'tests/reftests/url-background-inline-table.html and its reference','old':'Only inline board at20,20 depends on child-height slices. Table board at20,60 is independent.','new':'Preserve original files/results. The inline natural4x2 image centers in full6x1.3 owner strip, so image tile y changes from20 to20.7 and from22 to22.7; owner clips become21.05..22.35 and23.05..24.35. Derive the changed inline reference after the fractional clip decision; all table literal rectangles remain exact.'}
 ],
 'not_observations':['No candidate was executed.','Root reports the six separately authored principal-box references fail on parent0/6; this plan does not reclassify that result.','No production/test migration is included here.']
}
(D/'oracles.json').write_text(json.dumps(plan,indent=2)+'\n')
paths=[S/'layout.rs',S/'inline_edges.rs',W/'src/layout/gradient_tests.rs',W/'src/layout/background_tests.rs',W/'src/layout/url_background_tests.rs',W/'tests/reftests/url-background-inline-table.html',W/'tests/reftests/url-background-inline-table-ref.html',W/'src/graphics.rs',W/'src/graphics/box_decoration.rs',D/'oracles.json']
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(D/'source-ready.json').write_text(json.dumps({'status':'source-only','scope':'Independent sliced-inline oracle proposal; no project execution or source/test mutation','files':[binding(p) for p in paths]},indent=2)+'\n')
print(json.dumps({'oracles':binding(D/'oracles.json'),'hold':binding(D/'source-ready.json'),'cases':len(plan['cases'])},indent=2))
