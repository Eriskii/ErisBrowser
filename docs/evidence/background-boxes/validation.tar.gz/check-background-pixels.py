"""Verify frozen literal frames and exact predecessor continuity, without a browser oracle."""
from pathlib import Path
import hashlib, importlib.util, json, re, sys
T=Path(__file__).resolve().parent
W=T/'worktree'
spec=importlib.util.spec_from_file_location('eris_reftest',W/'tools/reftest.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
directory=Path(sys.argv[1]);output=Path(sys.argv[2])
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=json.loads((directory/'report.json').read_text())
manifest=json.loads((W/'tests/reftests/manifest.json').read_text())
assert len(manifest['cases'])==90
assert [c['name'] for c in report['cases']]==[c['name'] for c in manifest['cases']]
assert (report['passed'],report['failed'],report['total'])==(90,0,90)
expected={}
def rectangles(rows,width=320,height=240):
 frame=bytearray(b'\xff\xff\xff\xff'*(width*height))
 for x,y,dx,dy,rgb in rows:
  assert 0<=x and 0<=y and x+dx<=width and y+dy<=height
  for row in range(y,y+dy):
   at=(row*width+x)*4;frame[at:at+dx*4]=bytes.fromhex(rgb+'ff')*dx
 return bytes(frame)
principal=T/'fixtures/oracles.json'
for case in json.loads(principal.read_text())['cases']:
 assert case['viewport']==[320,240] and case['clear']=='ffffff'
 expected[case['name']]=rectangles(case['ordered_rectangles_xywh_rgb'])
for p in sorted((T/'inline-fixtures/literals').glob('*.rgba')):
 assert p.stat().st_size==320*240*4
 expected[p.stem]=p.read_bytes()
# The explicitly migrated reference is independent authored absolute rectangles;
# decode its frozen source literals directly, never production layout or paint.
migration=T/'inline-migrations/after/tests/reftests/url-background-inline-table-ref.html'
pattern=r'left:(\d+)px;top:(\d+)px;width:(\d+)px;height:(\d+)px;background:#([0-9a-f]{6})'
rows=[[*map(int,v[:4]),v[4]] for v in re.findall(pattern,migration.read_text())]
assert len(rows)==20
expected['url-background-inline-table']=rectangles(rows)
results=[];inputs=[];predecessor=[]
for case in report['cases']:
 name=case['name'];pair=[]
 for suffix in ['', '-ref']:
  p=directory/(name+suffix+'.png');width,height,pixels=m.decode_png(p)
  assert (width,height)==(320,240)
  inputs.append({'path':str(p),'sha256':sha(p)})
  if name in expected:
   assert pixels==expected[name],(name,suffix,'frozen literal mismatch')
  else:
   old=Path('/tmp/eris-inline-edges-1/reftests-final-2')/p.name
   assert m.decode_png(old)==(width,height,pixels),(name,suffix,'predecessor changed')
   predecessor.append({'path':str(old),'sha256':sha(old)})
  pair.append(hashlib.sha256(pixels).hexdigest())
 assert pair[0]==pair[1]
 results.append({'name':name,'kind':'literal' if name in expected else 'predecessor-exact','rgba_sha256':pair[0]})
result={'report_sha256':sha(directory/'report.json'),'manifest_sha256':sha(W/'tests/reftests/manifest.json'),'principal_oracles_sha256':sha(principal),'inline_oracles_sha256':sha(T/'inline-fixtures/oracles.json'),'migrated_reference_sha256':sha(migration),'scope':'90 exact pairs: nine new literal cases, one explicit nominal-inline migration, eighty unchanged predecessor pairs. No web-platform-conformance claim.','cases':results,'image_inputs':inputs,'predecessor_inputs':predecessor}
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'output':str(output),'sha256':sha(output),'pairs':len(results),'literal_pairs':len(expected),'unchanged_pairs':len(predecessor)//2}))
