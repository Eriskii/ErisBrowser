
#[test]
fn table_rows_keep_coincident_boxes_for_every_origin_and_clip() {
    for origin in ["border-box","padding-box","content-box"] {for clip in ["border-box","padding-box","content-box"] {for raster in [false,true] {
        let image=if raster {"url(tile.png)"} else {"linear-gradient(red,blue)"};
        let doc=Document::parse(&format!("<style>body{{margin:0}}table{{width:12px}}td{{height:4px;padding:0;border:0;font-size:0}}tr{{background-image:{image};background-origin:{origin};background-clip:{clip};background-repeat:no-repeat}}</style><table><tr id=row><td></td></tr></table>"));
        let styles=crate::css::compute_styles(&doc,&doc.stylesheets(),32.0,24.0);let id=doc.query_selector("#row").unwrap();let mut loaded=vec![None;doc.nodes.len()];loaded[id]=raster.then_some(LoadedBackground{key:"row-tile",natural:RasterNaturalSize{width:4,height:2}});
        let result=layout_with_backgrounds(&doc,&styles,32.0,24.0,&Fonts::new(),&loaded);
        let area=rect(2.0,2.0,8.0,4.0);let tile=if raster {rect(2.0,2.0,4.0,2.0)}else{area};
        assert_eq!(result.commands.iter().filter_map(image_geometry).collect::<Vec<_>>(),vec![(area,tile)]);
    }}}
}
