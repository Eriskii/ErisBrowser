
#[test]
fn oversized_table_available_width_survives_the_forced_border_clamp() {
    let doc=Document::parse("<style>body{margin:0}#box{box-sizing:border-box;height:2px;padding-left:1%;padding-right:1%;background-image:linear-gradient(red,blue);background-origin:content-box;background-clip:content-box;background-size:100% 100%}</style><div id=box></div>");
    let styles=crate::css::compute_styles(&doc,&doc.stylesheets(),32.0,24.0);let id=doc.query_selector("#box").unwrap();let fonts=Fonts::new();let mut e=engine(&doc,&styles,&fonts,&[]);
    let mut f=e.fragment(id,2_000_000.0,2_000_000.0,0);
    assert_eq!(f.size.width,1_000_000.0);
    assert_eq!(f.commands.iter().filter_map(image_geometry).collect::<Vec<_>>(),vec![(rect(20_000.0,0.0,960_000.0,2.0),rect(20_000.0,0.0,960_000.0,2.0))]);
    let mut work=17;assert!(stretch_fragment_background_boxes(&mut f,6.0,&styles[id],2_000_000.0,None,&mut work));assert_eq!(work,0);
    assert_eq!(f.commands.iter().filter_map(image_geometry).collect::<Vec<_>>(),vec![(rect(20_000.0,0.0,960_000.0,6.0),rect(20_000.0,0.0,960_000.0,6.0))]);
}
#[test]
fn spanning_table_cell_retains_original_track_available_width() {
    // Two999999 tracks and fixed2 spacing give the spanning cell2000000.
    // Its border width clamps1000000; both1% sides still resolve to20000.
    let doc=Document::parse("<style>body{margin:0}table{width:32px}td{height:2px;padding:0;border:0;font-size:0}.track{width:999999px}#box{padding-left:1%;padding-right:1%;background-image:linear-gradient(red,blue);background-origin:content-box;background-clip:content-box;background-size:100% 100%}</style><table><tr><td class=track></td><td class=track></td></tr><tr><td id=box colspan=2></td></tr></table>");
    let styles=crate::css::compute_styles(&doc,&doc.stylesheets(),32.0,24.0);let result=layout(&doc,&styles,32.0,24.0,&Fonts::new());
    assert_eq!(result.commands.iter().filter_map(image_geometry).collect::<Vec<_>>(),vec![(rect(20_002.0,6.0,960_000.0,2.0),rect(20_002.0,6.0,960_000.0,2.0))]);
}
