
#[test]
fn translated_fractional_table_retile_uses_forward_insets() {
    // Literal f32 values: x=.1, width=.3, left=.1, right=0. Recovering
    // right from translated endpoints gives -2^-25 despite a zero side.
    let doc=Document::parse("<style>body{margin:0}#box{position:relative;left:.1px;box-sizing:border-box;width:.3px;height:2px;border-left:.1px solid transparent;background-image:linear-gradient(red,blue);background-origin:content-box;background-clip:content-box;background-size:100% 100%}</style><div id=box></div>");
    let styles=crate::css::compute_styles(&doc,&doc.stylesheets(),32.0,24.0);let id=doc.query_selector("#box").unwrap();let fonts=Fonts::new();let mut e=engine(&doc,&styles,&fonts,&[]);
    let mut f=e.fragment(id,0.3,0.3,0);
    let g=f.boxes.iter().find(|g|g.node==id).unwrap();
    assert_eq!(g.border,rect(0.1,0.0,0.3,2.0));
    assert_eq!(g.padding.x.to_bits(),0x3e4ccccd);
    assert_eq!(g.padding.width.to_bits(),0x3e4cccce);
    assert_eq!(((g.border.x+g.border.width)-(g.padding.x+g.padding.width)).to_bits(),0xb3000000);
    let mut work=17;assert!(stretch_fragment_background_boxes(&mut f,4.0,&styles[id],None,&mut work));assert_eq!(work,0);
    let area=rect(f32::from_bits(0x3e4ccccd),0.0,f32::from_bits(0x3e4cccce),4.0);
    assert_eq!(f.commands.iter().filter_map(image_geometry).collect::<Vec<_>>(),vec![(area,area)]);
    assert_eq!(f.hits[0].rect,rect(0.1,0.0,0.3,4.0));
}
