
#[test]
fn translucent_or_transparent_rounded_border_keeps_opaque_background_under_ring() {
    for (border, top) in [("rgba(255,0,0,.5)", 0x80007f), ("rgba(255,0,0,0)", 0x0000ff)] {
        let doc = Document::parse(&format!("<style>html,body{{margin:0;padding:0;background:white}}#box{{box-sizing:border-box;width:12px;height:12px;border:2px solid {border};border-radius:4px;background:blue}}</style><div id=box></div>"));
        let styles = crate::css::compute_styles(&doc, &doc.stylesheets(), 12.0, 12.0);
        let fonts = Fonts::new();
        let result = layout(&doc, &styles, 12.0, 12.0, &fonts);
        let background = result.commands.iter().find_map(|command| match command {
            DrawCommand::BoxDecoration(decoration)
                if decoration.cutout.is_none()
                    && matches!(&decoration.paint, BoxPaint::Color(color) if *color == Color::rgb(0, 0, 255)) => Some(decoration),
            _ => None,
        }).expect("opaque background covers its outer border-box, including beneath transparent border pixels");
        assert_eq!(background.shape, shape(rect(0.0, 0.0, 12.0, 12.0), 4.0));
        if top == 0x80007f {
            let ring = result.commands.iter().find_map(|command| match command {
                DrawCommand::BoxDecoration(decoration) if decoration.cutout.is_some() => Some(decoration),
                _ => None,
            }).unwrap();
            assert_eq!(ring.shape, shape(rect(0.0, 0.0, 12.0, 12.0), 4.0));
            assert_eq!(ring.cutout, Some(shape(rect(2.0, 2.0, 8.0, 8.0), 2.0)));
        }
        let mut canvas = crate::graphics::Canvas::new(12, 12).unwrap();
        canvas.paint(&result.commands, &fonts, &crate::graphics::ImageStore::new(), 0.0, 0.0);
        assert!(!canvas.exhausted());
        assert_eq!(canvas.pixels[5], top, "straight top edge: {border}");
        assert_eq!(canvas.pixels[5 * 12 + 5], 0x0000ff, "uncut interior: {border}");
        assert_eq!(canvas.pixels[0], 0xffffff, "outside corner: {border}");
    }
}
