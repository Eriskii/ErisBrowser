"""Root-only publication of explicitly selected, completed background-box evidence."""
from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

# This reviewed draft runs in package-preparation; no installation is necessary.
P = Path(__file__).resolve().parent.parent
W = P / 'worktree'
BASE = 'e89f5846a10cef7a7b2f062aaa296984da204026'
D = W / 'docs/evidence/background-boxes'
CAP = 64 * 1024 * 1024
PARENT = Path('/tmp/eris-inline-edges-1')
EXTERNAL = {PARENT, Path('/tmp/eris-rounded-boxes-1')}
TREES = {'css', 'cssom', 'layout', 'script', 'fixtures', 'inline-plan', 'inline-tests',
         'inline-migrations', 'inline-fixtures', 'inline-review', 'root', 'docs',
         'package-preparation', 'validation'}
PRESERVED_TYPES = {'eris::graphics::Canvas', 'eris::graphics::DrawCommand',
                   'eris::layout::Fragment', 'eris::layout::InlineKind'}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def local(name, root=P):
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path

def binding(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}

def checked(spec, root=P):
    path = local(spec['path'], root)
    assert path.stat().st_size == spec['bytes'] and digest(path) == spec['sha256'], path
    return path

def read(spec, root=P):
    return json.loads(checked(spec, root).read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)

def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return {'rows': len(rows), 'passed': sum(int(x[1]) for x in rows),
            'failed': sum(int(x[2]) for x in rows), 'ignored': sum(int(x[3]) for x in rows)}

def png(spec, root=P):
    path = local(spec['path'], root)
    assert path.suffix == '.png' and digest(path) == spec['sha256']
    if 'bytes' in spec:
        assert path.stat().st_size == spec['bytes']
    return path

assert len(sys.argv) in {1, 2} and __debug__, 'Do not execute with Python -O'
selection_path = local(sys.argv[1] if len(sys.argv) == 2 else 'publication-selection.json')
selection = json.loads(selection_path.read_text())
source_path = checked(selection['source'])
source = json.loads(source_path.read_text())
assert source['base'] == BASE and git('rev-parse', 'HEAD').decode().strip() == BASE
inputs = source['source_sha256']
assert len(inputs) == selection['source_count'] and selection['source_count'] > 0
for name, sha in inputs.items():
    assert digest(local(name, W)) == sha, name
source_sha = digest(source_path)

# Every actual attempt is retained, including compiler and aborted partial runs.
checks = {}
for path in sorted((P / 'validation').glob('*.json')):
    receipt = json.loads(path.read_text())
    if not {'command', 'exit', 'log', 'sha256'} <= receipt.keys():
        continue
    log = local(receipt['log'], path.parent)
    assert digest(log) == receipt['sha256'], path
    checks[path.name] = {'receipt': binding(path), 'log': binding(log),
                        'command': receipt['command'], 'exit': receipt['exit'],
                        'rust': totals(log.read_text(errors='replace'))}
for name, code, literal in [
    ('focused-css-1.json', 101, 'calc(1px)'),
    ('focused-layout-1.json', 134, 'has overflowed its stack'),
    ('focused-layout-2.json', 101, 'has no field named `owner`'),
]:
    assert checks[name]['exit'] == code
    assert literal in Path(checks[name]['log']['path']).read_text(errors='replace')
roles = {}
for item in selection['checks']:
    path = checked(item['receipt'])
    assert path.parent == P / 'validation' and item['role'] not in roles
    record = checks[path.name]
    assert record['command'] == item['command'] and record['exit'] == item['exit'], path
    if 'rust' in item:
        assert record['rust'] == item['rust'], path
    if item.get('final'):
        assert item['exit'] == 0 and item['source_sha256'] == source_sha, path
    roles[item['role']] = {**record, 'final': item.get('final', False)}
required = {'full_native', 'full_default', 'clippy_native_msrv', 'clippy_native_current',
            'clippy_default_current', 'format', 'browser_build', 'browser_strip',
            'reftests', 'final_pixel_literals', 'candidate_type_sizes'}
assert required <= roles.keys() and all(roles[name]['final'] for name in required)
assert 'parent_ci' in roles and roles['parent_ci']['exit'] == 0
for role, version, features in [('full_native', '1.88.0', ['--features', 'vulkan-raster']),
                                ('full_default', '1.98.0', [])]:
    assert roles[role]['command'] == ['cargo', '+' + version, 'test', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', *features, '--', '--include-ignored', '--test-threads=4']
    actual = roles[role]['rust']
    assert actual['rows'] > 0 and actual['passed'] > 0 and actual['failed'] == actual['ignored'] == 0
for role, version, features in [('clippy_native_msrv', '1.88.0', ['--features', 'vulkan-raster']),
                                ('clippy_native_current', '1.98.0', ['--features', 'vulkan-raster']),
                                ('clippy_default_current', '1.98.0', [])]:
    assert roles[role]['command'] == ['cargo', '+' + version, 'clippy', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', *features, '--all-targets', '--', '-D', 'warnings']
fmt = roles['format']['command']
assert fmt[-6:] == ['cargo', '+1.98.0', 'fmt', '--all', '--', '--check']
assert fmt[:-6] in [[], ['env', 'RUSTUP_HOME=/tmp/eris-vulkan-rustup',
    'CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home'], ['env',
    'CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home', 'RUSTUP_HOME=/tmp/eris-vulkan-rustup']]

browser_path = checked(selection['browser'])
browser = json.loads(browser_path.read_text())
binary = local(browser['path'])
assert binding(binary) == {k: browser[k] for k in ['path', 'bytes', 'sha256']}
assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
assert P / browser['build_receipt'] == Path(roles['browser_build']['receipt']['path'])
assert roles['browser_build']['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
    '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
assert roles['browser_strip']['command'] in [['strip', str(binary)], ['strip', '--strip-debug', str(binary)]]
parent_record_path = checked(selection['parent_browser'], PARENT)
parent_browser = json.loads(parent_record_path.read_text())
assert binding(local(parent_browser['path'], PARENT)) == {k: parent_browser[k] for k in ['path', 'bytes', 'sha256']}

# Preserve the parent manifest; permit only explicitly bound definition migrations.
refs = selection['references']
manifest = json.loads((W / 'tests/reftests/manifest.json').read_text())
parent_manifest_bytes = git('show', BASE + ':tests/reftests/manifest.json')
parent_manifest = json.loads(parent_manifest_bytes)
additions = [row for spec in refs['additions'] for row in read(spec)]
new_names = {r['name'] for r in additions}
assert len(new_names) == len(additions) and new_names
assert manifest['cases'] == parent_manifest['cases'] + additions
assert {k:v for k,v in manifest.items() if k != 'cases'} == {k:v for k,v in parent_manifest.items() if k != 'cases'}
migrations = {}
for item in refs['migrations']:
    name = item['relative']
    assert name.startswith('tests/reftests/') and name not in migrations
    before = checked(item['before']); after = checked(item['after'])
    assert before.read_bytes() == git('show', BASE + ':' + name)
    assert after.read_bytes() == local(name, W).read_bytes()
    migrations[name] = item
parent_files = git('ls-tree', '-r', '--name-only', BASE, '--', 'tests/reftests').decode().splitlines()
for name in parent_files:
    if name != 'tests/reftests/manifest.json' and name not in migrations:
        assert local(name, W).read_bytes() == git('show', BASE + ':' + name), name
fixture_names = set()
for item in refs['fixture_files']:
    name = item['relative']; fixture_names.add(name)
    assert checked(item['raw']).read_bytes() == local(name, W).read_bytes()
    assert inputs[name] == item['raw']['sha256']
assert {'tests/reftests/' + row[key] for row in additions for key in ['test','reference']} <= fixture_names
allowed_refs = {'tests/reftests/manifest.json'} | fixture_names | set(migrations)
assert set(git('diff', '--name-only', 'HEAD', '--', 'tests/reftests').decode().splitlines()) <= allowed_refs
report_path = checked(selection['report']); report = json.loads(report_path.read_text())
names = {row['name'] for row in manifest['cases']}; count = len(names)
assert len(manifest['cases']) == count
assert (report['passed'], report['failed'], report['total']) == (count, 0, count)
assert len(report['cases']) == count and {c['name'] for c in report['cases']} == names
assert all(c['status'] == 'pass' and c['different_pixels'] == c['maximum_channel_error'] == 0 for c in report['cases'])
assert report['binary'] == str(binary)
assert roles['reftests']['command'] == ['python3', 'tools/reftest.py', '--binary', str(binary), '--output-dir', str(report_path.parent)]
external_records = {parent_record_path}
report_dirs = {report_path.parent.name}
for item in refs['baselines']:
    root = Path(item['root']); assert root in EXTERNAL
    record_path = checked(item['browser'], root); prior = json.loads(record_path.read_text())
    assert binding(local(prior['path'], root)) == {k:prior[k] for k in ['path','bytes','sha256']}
    baseline_path = checked(item['report']); baseline = json.loads(baseline_path.read_text())
    expected = read(item['manifest'])['cases']; expected_names = {x['name'] for x in expected}
    assert baseline['binary'] == prior['path'] and {x['name'] for x in baseline['cases']} == expected_names
    assert (baseline['passed'],baseline['failed'],baseline['total']) == tuple(item['totals'])
    assert len(baseline['cases']) == baseline['total'] == len(expected)
    role = roles[item['role']]
    assert role['command'] == ['python3','tools/reftest.py','--binary',prior['path'],
        '--manifest',str(checked(item['manifest'])),'--output-dir',str(baseline_path.parent)]
    report_dirs.add(baseline_path.parent.name); external_records.add(record_path)

# Authenticate the selected checker stdout and its full flat-input receipt.
checker = checked(selection['final_pixel_checker'])
literal_path = checked(selection['final_pixel_literals']); literals = json.loads(literal_path.read_text())
assert roles['final_pixel_literals']['command'] == ['python3',str(checker),str(report_path.parent),str(literal_path)]
assert literals['report_sha256'] == digest(report_path)
assert literals['manifest_sha256'] == digest(W/'tests/reftests/manifest.json')
changed_old = {r['name'] for r in parent_manifest['cases'] if any('tests/reftests/'+r[k] in migrations for k in ['test','reference'])}
old_names = {r['name'] for r in parent_manifest['cases']} - changed_old
literal_names = new_names | changed_old
assert json.loads(Path(roles['final_pixel_literals']['log']['path']).read_text()) == {
    'output':str(literal_path),'sha256':digest(literal_path),'pairs':count,
    'literal_pairs':len(literal_names),'unchanged_pairs':len(old_names)}
oracle_specs = selection['pixel_oracles']
for field, key in [('principal_oracles_sha256','principal'),('inline_oracles_sha256','inline'),('migrated_reference_sha256','migration')]:
    assert literals[field] == digest(checked(oracle_specs[key]))
assert checked(oracle_specs['migration']).read_bytes() == local('tests/reftests/url-background-inline-table-ref.html',W).read_bytes()
assert changed_old == {'url-background-inline-table'}
assert len(literals['cases']) == count and {r['name'] for r in literals['cases']} == names
for row in literals['cases']:
    assert row['kind'] == ('literal' if row['name'] in literal_names else 'predecessor-exact')
    assert re.fullmatch('[0-9a-f]{64}',row['rgba_sha256'])
expected_literals = {}
for spec in selection['literal_records']:
    for row in read(spec)['cases']:
        value = row.get('literal_rgba_sha256',row.get('rgba_sha256'))
        assert isinstance(value,str) and re.fullmatch('[0-9a-f]{64}',value)
        assert row['name'] not in expected_literals or expected_literals[row['name']] == value
        expected_literals[row['name']] = value
for spec in selection['inline_literal_frames']:
    frame = checked(spec); assert frame.suffix == '.rgba' and frame.stat().st_size == 320*240*4
    expected_literals[frame.stem] = digest(frame)
assert new_names <= expected_literals.keys()
assert all(r['rgba_sha256'] == expected_literals[r['name']] for r in literals['cases'] if r['name'] in expected_literals)
expected_paths = {report_path.parent/(name+suffix+'.png') for name in names for suffix in ['', '-ref']}
pixel_files = {png(row) for row in literals['image_inputs']}
assert pixel_files == expected_paths and len(literals['image_inputs']) == 2*count
parent_report_path = checked(selection['parent_report'],PARENT)
parent_report = json.loads(parent_report_path.read_text())
assert parent_report['binary'] == parent_browser['path'] and parent_report['failed'] == 0
assert parent_report['total'] == parent_report['passed'] == len(parent_manifest['cases'])
assert {r['name'] for r in parent_report['cases']} == {r['name'] for r in parent_manifest['cases']}
predecessor_files = {png(row,PARENT) for row in literals['predecessor_inputs']}
assert predecessor_files == {parent_report_path.parent/(name+suffix+'.png') for name in old_names for suffix in ['', '-ref']}
assert len(literals['predecessor_inputs']) == 2*len(old_names)
external_records.add(parent_report_path)

sizes = {name: read(selection['type_sizes'][name]) for name in ['parent','candidate']}
for name, record in sizes.items():
    assert set(record['sizes']) == set(selection['type_names'][name])
    assert all(len(v) == 1 and v[0] > 0 for v in record['sizes'].values())
    root, expected = (PARENT,parent_browser) if name == 'parent' else (P,browser)
    assert digest(local(record['binary'],root)) == record['binary_sha256'] == expected['unstripped_sha256']
    assert record['method'] == 'readelf --debug-dump=info; namespace-qualified DW_AT_byte_size'
assert PRESERVED_TYPES <= set(sizes['parent']['sizes']) & set(sizes['candidate']['sizes'])
assert all(sizes['parent']['sizes'][n] == sizes['candidate']['sizes'][n] for n in PRESERVED_TYPES)
assert roles['candidate_type_sizes']['command'][-2:] == [sizes['candidate']['binary'],str(checked(selection['type_sizes']['candidate']))]
docs = read(selection['docs']); entries = docs.get('published_files',docs.get('drafts'))
published_docs = [{**row['draft'],'relative':row['path']} if 'draft' in row else row for row in entries]
assert published_docs and len({r['relative'] for r in published_docs}) == len(published_docs)
for row in published_docs:
    assert digest(checked(row)) == digest(local(row['relative'],W)) == row['sha256']
review_paths = []
for spec in selection['reviews']:
    review = read(spec); assert str(review.get('status','')).lower().startswith('clear'), spec
    review_paths.append(checked(spec))
doc_review = read(selection['documentation_review'])
assert str(doc_review['status']).lower().startswith('clear')
coverage = {r['relative']:r['sha256'] for r in doc_review['published_files']}
assert all(coverage.get(r['relative']) == r['sha256'] for r in published_docs)
assert review_paths
published = selection['published_files']
assert len({r['path'] for r in published}) == len(published)
for spec in published: checked(spec,W)
changed = set(git('diff','--name-only','-z','HEAD').decode().split('\0')) | set(git('ls-files','--others','--exclude-standard','-z').decode().split('\0'))
changed.discard('')
assert changed == {r['path'] for r in published}, sorted(changed ^ {r['path'] for r in published})
assert {r['relative'] for r in published_docs} == {name for name in changed if name.endswith('.md')}

# Finite selection of owned preparation trees; never recurse over the temp root.
files = {selection_path,source_path,browser_path,report_path,checker,literal_path,
         Path(__file__).resolve(),P/'package-preparation/publication-design.json'} | pixel_files
for group in ['holds','oracles','migrations']:
    assert selection['evidence'][group]
    files.update(checked(spec) for spec in selection['evidence'][group])
for dirname in selection['archive_directories']:
    assert dirname in TREES | report_dirs
    root = P/dirname; assert root.is_dir() and root == root.resolve() and root.parent == P
    for path in root.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_file(): files.add(path)
# All validation attempts are mandatory even if a directory was not selected.
for record in checks.values(): files.update([Path(record['receipt']['path']),Path(record['log']['path'])])
files.update(checked(spec) for spec in selection.get('archive_files',[]))
files.update(review_paths); files.add(checked(selection['documentation_review'])); files.add(checked(selection['docs']))
files.update(checked(spec) for spec in selection['type_sizes'].values())
files.update(checked(spec) for spec in selection['literal_records'])
files.update(checked(spec) for spec in selection['pixel_oracles'].values())
files.update(checked(spec) for spec in selection['inline_literal_frames'])
files.update(checked(spec) for spec in refs['additions'])
for item in refs['fixture_files']: files.add(checked(item['raw']))
for item in refs['migrations']: files.update([checked(item['before']),checked(item['after'])])
for item in refs['baselines']: files.update([checked(item['report']),checked(item['manifest'])])
files.update(checked(spec,W) for spec in published)
files.update(P.glob('compiled-source-*.json')); files.update(P.glob('authored-source-*.json'))
assert sum(path.stat().st_size for path in files) < CAP
contents = {}
for path in sorted(files):
    path = local(path); name = str(path.relative_to(P))
    assert not any(part in {'target','.git','archive','archives','__pycache__'} or part.startswith('target-') for part in Path(name).parts), name
    assert path.suffix not in {'.gz','.zip','.tar','.xz','.bz2','.7z','.rlib','.so','.pyc'}, name
    with path.open('rb') as stream: assert stream.read(4) != b'\x7fELF', name
    contents[name] = path.read_bytes()
for path in external_records:
    contents['parent-bindings/'+hashlib.sha256(str(path).encode()).hexdigest()[:16]+'-'+path.name] = path.read_bytes()
contents['parent-bindings/reftest-manifest.json'] = parent_manifest_bytes
assert sum(map(len,contents.values())) < CAP
for name, sha in inputs.items(): assert digest(local(name,W)) == sha,name
index = [{'path':name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()} for name,data in sorted(contents.items())]
raw = io.BytesIO()
with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as archive:
    for name,data in sorted(contents.items()):
        info = tarfile.TarInfo(name); info.size=len(data); info.mode=0o644; info.mtime=0
        archive.addfile(info,io.BytesIO(data))
assert raw.tell() < CAP
compressed = gzip.compress(raw.getvalue(),compresslevel=9,mtime=0); assert len(compressed) < CAP
assert D == D.resolve(); D.mkdir(parents=True,exist_ok=True)
archive_path=D/'validation.tar.gz'; summary_path=D/'summary.json'
assert not archive_path.exists() and not summary_path.exists()
with archive_path.open('xb') as stream: stream.write(compressed)
assert archive_path.read_bytes() == compressed
with tarfile.open(archive_path,'r:gz') as archive:
    assert [m.name for m in archive.getmembers()] == sorted(contents)
    for member in archive.getmembers():
        assert member.isfile() and archive.extractfile(member).read() == contents[member.name]
summary = {'base':BASE,'scope':'CSS single-layer background box selection and sliced inline decoration; no new GPU execution or timing claim.',
    'compiled_source':binding(source_path),'source_count':len(inputs),'checks':checks,'selected_roles':roles,
    'browser':browser,'reftests':binding(report_path),'reference_migrations':refs['migrations'],
    'baseline_reports':[item['report'] for item in refs['baselines']],
    'final_pixel_literals':binding(literal_path),'final_pixel_checker':binding(checker),'type_sizes':sizes,
    'reviews':selection['reviews'],'documentation_review':selection['documentation_review'],'published_bindings':published,
    'published_document_sha256':{r['relative']:r['sha256'] for r in published_docs},
    'archive':{'path':'validation.tar.gz','bytes':len(compressed),'sha256':digest(archive_path),'members':len(index)},
    'archive_inputs':index,'selection':binding(selection_path),
    'limits':['Self-authored cases do not establish full web compatibility.','Historical failed attempts have partial totals; only selected final roles assert completed success.','DWARF sizes are emitted build type sizes, not allocator instrumentation.']}
with summary_path.open('x') as stream: json.dump(summary,stream,indent=2); stream.write('\n')
assert json.loads(summary_path.read_text()) == summary
print(json.dumps({'summary_sha256':digest(summary_path),'archive':summary['archive'],'source_count':len(inputs)},indent=2))
