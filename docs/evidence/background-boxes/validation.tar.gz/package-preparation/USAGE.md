# Background-box evidence publisher

Root runs this held script only after final receipts, docs installation and independent review:

```sh
python3 /tmp/eris-background-boxes-1/package-preparation/publish-evidence.py /tmp/eris-background-boxes-1/publication-selection.json
```

`publication-design.json` describes the exact selection schema. Supply actual file sizes/SHA256, commands, exits and observed totals. Keep source review separate from final selection review. This script has not been executed by its author.

Run from the clean-base T worktree state with all intended edits still uncommitted; HEAD must be e89f5846a10cef7a7b2f062aaa296984da204026. The complete changed/untracked roster must match `published_files`; the two evidence outputs must not yet exist. Publication does not stage, commit, push or run project tests.

The selected root pixel checker emits a small stdout binding and a full flat-input receipt. Bind both through the validation receipt and `final_pixel_literals`; retain the actual rounded-box and inline-edge predecessor runs separately. Type records must come from the bound unstripped builds; no binary enters the archive.

After publication, root reviews/stages the two new outputs with the already-bound roster and verifies exact staged bytes. The publisher refuses overwrite; retain any partial failed output for diagnosis instead of silently retrying it.
