from pathlib import Path
import hashlib,json,sys
P=Path('/tmp/eris-background-boxes-1'); W=P/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
hold=Path(sys.argv[1]); record=json.loads(hold.read_text()); published=[]
for row in record['published_files']:
 spec=row['draft']; source=Path(spec['path']); name=row['path']; destination=W/name
 assert source.is_relative_to(P/'docs') and source.is_file()
 assert source.stat().st_size==spec['bytes'] and sha(source)==spec['sha256']
 assert name in {'README.md','docs/SECURITY.md','docs/background-boxes.md'}
 published.append({'relative':name,'bytes':spec['bytes'],'sha256':spec['sha256']})
assert len(published)==3
for row in record['published_files']:
 source=Path(row['draft']['path']); destination=W/row['path']
 destination.write_bytes(source.read_bytes())
review={'status':'clear: root read final chapter and README/SECURITY diffs; joined completed validation, browser, pixel and DWARF observations; explicit subset and GPU fallback limits retained', 'docs_hold':{'path':str(hold),'bytes':hold.stat().st_size,'sha256':sha(hold)},'published_files':published}
output=P/'root/documentation-review-1.json'
with output.open('x') as stream:json.dump(review,stream,indent=2);stream.write('\n')
print(json.dumps({'review':str(output),'sha256':sha(output),'published_files':published},indent=2))
