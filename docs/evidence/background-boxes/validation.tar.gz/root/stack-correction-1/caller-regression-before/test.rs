// Append to layout/background_boxes/tests.rs; uses its existing engine helper.
#[test]
fn principal_extraction_preserves_raw_origin_until_each_original_rect_call() {
    let doc = Document::parse(
        "<style>#box{box-sizing:border-box;border-left:2px solid transparent;background-image:linear-gradient(red,blue)}</style><div id=box></div>",
    );
    let styles = crate::css::compute_styles(&doc, &doc.stylesheets(), 10.0, 4.0);
    let id = doc.query_selector("#box").unwrap();
    assert_eq!(styles[id].background_origin, BackgroundBox::Padding);
    assert_eq!(styles[id].background_clip, BackgroundBox::Border);
    let fonts = Fonts::new();
    let mut e = engine(&doc, &styles, &fonts, &[]);
    let size = e.layout_box_sized(id, -1_000_001.0, 0.0, 10.0, (Some(10.0), Some(4.0)), 0);
    assert_eq!((size.width, size.height), (10.0, 4.0));
    let gradients: Vec<_> = e.commands.iter().filter_map(|command| {
        if let DrawCommand::LinearGradient { rect, tile, repeat, radius, stop_scale, .. } = command {
            assert_eq!(*repeat, [true, true]);
            assert_eq!(*radius, 0.0);
            assert_eq!(*stop_scale, 1.0);
            Some((*rect, *tile))
        } else {
            None
        }
    }).collect();
    assert_eq!(gradients, vec![(
        Rect { x: -1_000_000.0, y: 0.0, width: 10.0, height: 4.0 },
        Rect { x: -999_999.0, y: 0.0, width: 8.0, height: 4.0 },
    )]);
    assert!(!e.commands.iter().any(|command| matches!(command, DrawCommand::BoxDecoration(_))));
}
