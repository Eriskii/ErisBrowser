//! Fixed-size background box selection, independent of image positioning.
use super::*;
use crate::graphics::box_decoration::{BoxDecoration, BoxPaint, RoundedBox};
use std::sync::Arc;

pub(super) const SHAPE_WORK: usize = 16;
#[derive(Clone, Copy)]
pub(super) struct BackgroundBoxes {
    pub(super) border: RoundedBox,
    pub(super) padding: RoundedBox,
    pub(super) content: RoundedBox,
}
impl BackgroundBoxes {
    pub(super) fn new(outer: RoundedBox, border: Sides, padding: Sides) -> Option<Self> {
        let b = [border.top, border.right, border.bottom, border.left];
        let p = [padding.top, padding.right, padding.bottom, padding.left];
        if !p.into_iter().all(|v| v.is_finite() && v >= 0.0) {
            return None;
        }
        let mut total = [0.0; 4];
        for i in 0..4 {
            let value = f64::from(b[i]) + f64::from(p[i]);
            if !value.is_finite() || value > 16_000_000.0 {
                return None;
            }
            total[i] = value as f32;
        }
        // Every result starts from the original outer radii. In particular,
        // never normalize the truncated padding arcs before deriving content.
        Some(Self {
            border: outer.normalized()?,
            padding: outer.inset(b)?,
            content: outer.inset(total)?,
        })
    }
    pub(super) fn select(self, which: BackgroundBox) -> RoundedBox {
        match which {
            BackgroundBox::Border => self.border,
            BackgroundBox::Padding => self.padding,
            BackgroundBox::Content => self.content,
        }
    }
    pub(super) fn from_style(
        outer: RoundedBox,
        style: &ComputedStyle,
        reference: f32,
    ) -> Option<Self> {
        // Match the forward box-layout resolutions. Recovering zero insets by
        // subtracting translated endpoints can manufacture a negative side.
        let border = &style.border_width;
        let padding = &style.padding;
        Self::new(
            outer,
            Sides {
                top: extent(border.top),
                right: extent(border.right),
                bottom: extent(border.bottom),
                left: extent(border.left),
            },
            Sides {
                top: resolve(padding.top, reference).unwrap_or(0.0).max(0.0),
                right: resolve(padding.right, reference).unwrap_or(0.0).max(0.0),
                bottom: resolve(padding.bottom, reference).unwrap_or(0.0).max(0.0),
                left: resolve(padding.left, reference).unwrap_or(0.0).max(0.0),
            },
        )
    }
}
#[derive(Clone, Copy)]
pub(super) enum PaintRole {
    Color,
    Image,
    Top,
    Right,
    Bottom,
    Left,
    RoundOuter,
    RoundInner,
    Unused,
}
#[derive(Clone, Copy)]
pub(super) struct PaintSlots {
    image: bool,
    rounded: bool,
}
impl PaintSlots {
    pub(super) fn new(image: bool, rounded: bool) -> Self {
        Self { image, rounded }
    }
    pub(super) fn len(self) -> usize {
        5 + usize::from(self.image)
    }
    pub(super) fn role(self, index: usize) -> PaintRole {
        if self.rounded {
            return match index {
                0 => PaintRole::RoundOuter,
                1 => PaintRole::RoundInner,
                2 if self.image => PaintRole::Image,
                // Keep legacy motion even for its transparent zero-width slots.
                2 if !self.image => PaintRole::Right,
                3 if !self.image => PaintRole::Bottom,
                4 if !self.image => PaintRole::Left,
                _ => PaintRole::Unused,
            };
        }
        if index == 0 {
            return PaintRole::Color;
        }
        if self.image && index == 1 {
            return PaintRole::Image;
        }
        match index - usize::from(self.image) {
            1 => PaintRole::Top,
            2 => PaintRole::Right,
            3 => PaintRole::Bottom,
            4 => PaintRole::Left,
            _ => PaintRole::Unused,
        }
    }
}
pub(super) fn empty() -> DrawCommand {
    DrawCommand::Rect {
        rect: Rect::default(),
        color: Color::TRANSPARENT,
        radius: 0.0,
    }
}
pub(super) fn color(shape: RoundedBox, color: Color, cutout: Option<RoundedBox>) -> DrawCommand {
    if color.a == 0 {
        return empty();
    }
    DrawCommand::BoxDecoration(Arc::new(BoxDecoration {
        shape,
        cutout,
        paint: BoxPaint::Color(color),
    }))
}
pub(super) fn image(command: DrawCommand, shape: RoundedBox) -> DrawCommand {
    let paint = match command {
        DrawCommand::LinearGradient {
            tile,
            repeat,
            gradient,
            current_color,
            stop_scale,
            ..
        } => BoxPaint::LinearGradient {
            tile,
            repeat,
            gradient,
            current_color,
            stop_scale,
        },
        DrawCommand::BackgroundImage {
            tile, repeat, key, ..
        } => BoxPaint::Image { tile, repeat, key },
        _ => return empty(),
    };
    DrawCommand::BoxDecoration(Arc::new(BoxDecoration {
        shape,
        cutout: None,
        paint,
    }))
}
pub(super) fn shape_path(style: &ComputedStyle, border: Sides, legacy_rounded: bool) -> bool {
    style.background_clip != BackgroundBox::Border
        || style.border_radius > 0.0
            && border.horizontal() + border.vertical() > 0.0
            && !legacy_rounded
}
pub(super) fn nondefault(style: &ComputedStyle) -> bool {
    style.background_origin != BackgroundBox::Padding
        || style.background_clip != BackgroundBox::Border
}
pub(super) fn spend(work: &mut usize, cost: usize) -> bool {
    if cost > *work {
        false
    } else {
        *work -= cost;
        true
    }
}

#[cfg(test)]
mod tests;
