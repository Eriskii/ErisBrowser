"""Root-only: bind selected background-box evidence; write only the selection JSON.

Usage: python3 root/prepare-publication-selection.py FINAL_DOCS_HOLD FINAL_DOC_REVIEW
No project imports, builds, tests, publisher calls, git mutations, or archive writes.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

T = Path(__file__).resolve().parent.parent
W = T / 'worktree'
S = Path('/tmp/eris-inline-edges-1')
ROUNDED = Path('/tmp/eris-rounded-boxes-1')
BASE = 'e89f5846a10cef7a7b2f062aaa296984da204026'
OUTPUT = T / 'publication-selection.json'
CAP = 64 * 1024 * 1024
TREES = ('css', 'cssom', 'layout', 'script', 'fixtures', 'inline-plan',
         'inline-tests', 'inline-migrations', 'inline-fixtures', 'inline-review',
         'root', 'docs', 'package-preparation')
REPORT_DIRS = ('reftests-final-1', 'parent-principal-reftests-1', 'parent-inline-reftests-1')
FINAL = {
    'full_native': 'full-native-1',
    'full_default': 'full-default-198-2',
    'clippy_native_msrv': 'clippy-native-msrv-3',
    'clippy_native_current': 'clippy-native-198-1',
    'clippy_default_current': 'clippy-default-198-2',
    'format': 'format-final-1',
    'browser_build': 'browser-build-1',
    'browser_strip': 'browser-strip-1',
    'reftests': 'reftests-final-1',
    'final_pixel_literals': 'final-pixel-literals-1',
    'candidate_type_sizes': 'candidate-type-sizes-1',
}
SPECIAL = {
    'published-inline-ci-1': 'parent_ci',
    'parent-principal-reftests-1': 'parent_principal_references',
    'parent-inline-reftests-1': 'parent_inline_references',
}
REVIEWS = (
    'css/script-review.json', 'cssom/html-review.json', 'layout/script-review.json',
    'inline-tests/script-review.json', 'inline-review/html-review-2.json',
    'layout/inline-prefix-independent/layout-review.json',
    'root/stack-correction-1/script-review-2.json', 'root/source9-review.json',
    'package-preparation/script-review.json',
)


def local(value, root=T):
    path = Path(value)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def binding(value, root=T):
    path = local(value, root)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def read(value, root=T):
    return json.loads(local(value, root).read_text())


def checked(spec, root=T):
    actual = binding(spec['path'], root)
    assert actual == {key: spec[key] for key in ('path', 'bytes', 'sha256')}, spec
    return Path(actual['path'])


def git(*args):
    # Only explicit read-only commands below; no shell or user-supplied argv.
    return subprocess.check_output(['git', *args], cwd=W)


def totals(log):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    return {'rows': len(rows), 'passed': sum(int(r[1]) for r in rows),
            'failed': sum(int(r[2]) for r in rows), 'ignored': sum(int(r[3]) for r in rows)}


def assert_clear(value):
    data = read(value)
    assert str(data.get('status', '')).lower().startswith('clear'), value
    return data


def archive_file(path):
    path = local(path)
    parts = path.relative_to(T).parts
    assert not any(p in {'target', '.git', 'archive', 'archives', '__pycache__'}
                   or p.startswith('target-') for p in parts), path
    assert path.suffix not in {'.gz', '.zip', '.tar', '.xz', '.bz2', '.7z', '.rlib', '.so', '.pyc'}, path
    with path.open('rb') as stream:
        assert stream.read(4) != b'\x7fELF', path
    return path


def main():
    assert __debug__ and len(sys.argv) == 3, __doc__
    assert T == Path('/tmp/eris-background-boxes-1')
    assert not OUTPUT.exists(), 'Exclusive selection output already exists; preserve it.'
    docs_path, doc_review_path = (local(Path(arg).absolute()) for arg in sys.argv[1:])
    assert docs_path.is_relative_to(T / 'docs')
    # Clear review may be in docs/ or root/; local() already requires canonical T ownership.
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    source_path = local('compiled-source-9.json')
    source = read(source_path)
    source_sha = digest(source_path)
    assert source['base'] == BASE
    for name, sha in source['source_sha256'].items():
        assert digest(local(name, W)) == sha, name
    observation = read('root/final-suite-observation-1.json')
    assert observation['source'] == source_path.name and observation['source_sha256'] == source_sha
    final_by_stem = {stem: role for role, stem in FINAL.items()}
    assert len(final_by_stem) == len(FINAL)
    checks, logs, actual = [], [], {}
    for receipt_path in sorted((T / 'validation').glob('*.json')):
        receipt = read(receipt_path)
        if not {'command', 'exit', 'log', 'sha256'} <= receipt.keys():
            continue
        log = local(receipt['log'], receipt_path.parent)
        assert digest(log) == receipt['sha256'], receipt_path
        logs.extend([receipt_path, log])
        result = totals(log.read_text(errors='replace'))
        stem = receipt_path.stem
        role = final_by_stem.get(stem, SPECIAL.get(stem, 'attempt_' + stem.replace('-', '_')))
        item = {'role': role, 'receipt': binding(receipt_path), 'command': receipt['command'],
                'exit': receipt['exit'], 'final': stem in final_by_stem, 'rust': result}
        if item['final']:
            assert item['exit'] == 0, receipt_path
            item['source_sha256'] = source_sha
        checks.append(item)
        actual[stem] = item
    assert len({x['role'] for x in checks}) == len(checks)
    assert set(final_by_stem) <= actual.keys() and set(SPECIAL) <= actual.keys()
    for stem, old in observation['checks'].items():
        item = actual[stem]
        assert item['final'] and item['receipt']['sha256'] == old['receipt_sha256']
        assert item['receipt']['path'] == old['receipt']
        assert (item['command'], item['exit'], item['rust']) == (old['command'], old['exit'], old['totals'])
    assert set(observation['checks']) == {FINAL[r] for r in (
        'full_native', 'full_default', 'clippy_native_msrv', 'clippy_native_current',
        'clippy_default_current', 'format')}
    ci = read(local(read('validation/published-inline-ci-1.json')['log'], T / 'validation'))
    assert ci['status'] == 'completed' and ci['conclusion'] == 'success'
    assert len(ci['jobs']) == 9 and all(j['conclusion'] == 'success' for j in ci['jobs'])

    browser = read('browser-final-1.json')
    checked(browser)
    assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
    assert browser['build_receipt'] == 'validation/' + FINAL['browser_build'] + '.json'
    assert browser['strip_receipt'] == 'validation/' + FINAL['browser_strip'] + '.json'
    parent_browser = read('browser-final-2.json', S)
    checked(parent_browser, S)
    report = read('reftests-final-1/report.json')
    assert report['binary'] == browser['path']
    assert report['passed'] == report['total'] == len(report['cases']) and report['failed'] == 0
    literal = read('reftests-final-1-literals.json')
    assert literal['report_sha256'] == digest(local('reftests-final-1/report.json'))
    assert literal['manifest_sha256'] == digest(local('tests/reftests/manifest.json', W))

    additions = [binding('fixtures/manifest-additions.json'), binding('inline-fixtures/manifest-additions.json')]
    fixtures = []
    principal = read('fixtures/source-ready.json')
    for row in principal['files']:
        spec = {'path': row['raw'], 'bytes': row['bytes'], 'sha256': row['sha256']}
        checked(spec)
        fixtures.append({'relative': row['relative'], 'raw': spec})
    inline = read('inline-fixtures/source-ready.json')
    raw_root = T / 'inline-fixtures/raw'
    frames = []
    for spec in inline['files']:
        path = checked(spec)
        if path.is_relative_to(raw_root):
            fixtures.append({'relative': str(path.relative_to(raw_root)), 'raw': spec})
        if path.parent == T / 'inline-fixtures/literals' and path.suffix == '.rgba':
            frames.append(spec)
    assert len(frames) == 3 and len(fixtures) == 19
    assert len({x['relative'] for x in fixtures}) == len(fixtures)
    for item in fixtures:
        assert checked(item['raw']).read_bytes() == local(item['relative'], W).read_bytes()
        assert source['source_sha256'][item['relative']] == item['raw']['sha256']
    migration_rel = 'tests/reftests/url-background-inline-table-ref.html'
    migrations = [{'relative': migration_rel,
                   'before': binding('inline-migrations/original/' + migration_rel),
                   'after': binding('inline-migrations/after/' + migration_rel)}]
    assert checked(migrations[0]['before']).read_bytes() == git('show', BASE + ':' + migration_rel)
    assert checked(migrations[0]['after']).read_bytes() == local(migration_rel, W).read_bytes()
    baselines = []
    for root, record, name, manifest, role in [
        (ROUNDED, 'browser-final-3.json', 'parent-principal-reftests-1', 'fixtures/new-manifest.json', 'parent_principal_references'),
        (S, 'browser-final-2.json', 'parent-inline-reftests-1', 'inline-fixtures/parent-manifest.json', 'parent_inline_references'),
    ]:
        prior = read(record, root)
        checked(prior, root)
        baseline = read(name + '/report.json')
        assert baseline['binary'] == prior['path']
        baselines.append({'root': str(root), 'browser': binding(record, root),
            'report': binding(name + '/report.json'), 'manifest': binding(manifest),
            'role': role, 'totals': [baseline[k] for k in ('passed', 'failed', 'total')]})

    sizes = {name: read(name + '-type-sizes-1.json') for name in ('parent', 'candidate')}
    for name, record in sizes.items():
        root, expected = (S, parent_browser) if name == 'parent' else (T, browser)
        assert digest(local(record['binary'], root)) == record['binary_sha256'] == expected['unstripped_sha256']
    docs = read(docs_path)
    entries = docs.get('published_files', docs.get('drafts'))
    assert entries
    published_docs = [{**x['draft'], 'relative': x['path']} if 'draft' in x else x for x in entries]
    doc_review = assert_clear(doc_review_path)
    coverage = {x['relative']: x['sha256'] for x in doc_review['published_files']}
    for item in published_docs:
        checked(item)
        assert digest(local(item['relative'], W)) == item['sha256'] == coverage[item['relative']]
    assert set(coverage) == {x['relative'] for x in published_docs}
    changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0'))
    changed |= set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    changed.discard('')
    assert {name for name in changed if name.endswith('.md')} == set(coverage)
    published = [{**binding(name, W), 'path': name} for name in sorted(changed)]
    for path in REVIEWS:
        assert_clear(path)

    archive_files = [binding(name) for name in (
        'run-check.py', 'run-tool.py', 'snapshot-source.py', 'check-background-pixels.py',
        'check-principal-reference-literals.py', 'measure-dwarf-types.py',
        'principal-reference-literals-1.json', 'inline-reference-literals-1.json',
        'reftests-final-1-literals.json', 'parent-type-sizes-1.json', 'candidate-type-sizes-1.json')]
    selection = {
        'source': binding(source_path), 'source_count': len(source['source_sha256']), 'checks': checks,
        'browser': binding('browser-final-1.json'), 'parent_browser': binding('browser-final-2.json', S),
        'parent_report': binding('reftests-final-2/report.json', S), 'report': binding('reftests-final-1/report.json'),
        'references': {'additions': additions, 'fixture_files': fixtures, 'migrations': migrations, 'baselines': baselines},
        'final_pixel_checker': binding('check-background-pixels.py'),
        'final_pixel_literals': binding('reftests-final-1-literals.json'),
        'pixel_oracles': {'principal': binding('fixtures/oracles.json'),
            'inline': binding('inline-fixtures/oracles.json'), 'migration': migrations[0]['after']},
        'literal_records': [binding('principal-reference-literals-1.json'), binding('inline-reference-literals-1.json')],
        'inline_literal_frames': frames,
        'type_sizes': {name: binding(name + '-type-sizes-1.json') for name in sizes},
        'type_names': {name: sorted(record['sizes']) for name, record in sizes.items()},
        'docs': binding(docs_path), 'documentation_review': binding(doc_review_path),
        'reviews': [binding(p) for p in REVIEWS], 'published_files': published,
        'evidence': {
            'holds': [binding(p) for p in ('css/source-ready.json', 'cssom/source-ready.json',
                'layout/source-ready.json', 'script/source-ready.json', 'inline-tests/source-ready-2.json',
                'root/final-suite-observation-1.json')],
            'oracles': [binding(p) for p in ('fixtures/oracles.json', 'inline-fixtures/oracles.json',
                'inline-tests/oracles.json', 'inline-plan/oracles-2.json')],
            'migrations': [binding(p) for p in ('inline-migrations/source-ready.json',
                'inline-migrations/migration.patch', 'inline-migrations/opacity-predicate-1/source-ready.json',
                'cssom/old-missing-longhands-migration-1/record.json')],
        },
        'archive_directories': list(TREES + REPORT_DIRS), 'archive_files': archive_files,
    }
    # Bounded whitelist only: include every held history in owned trees and all
    # actual receipt/log pairs, never a recursive scan of T/worktree or temp root.
    files = set(logs)
    for dirname in TREES + REPORT_DIRS:
        root = T / dirname
        assert root.is_dir() and root == root.resolve()
        for path in root.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_file():
                files.add(archive_file(path))
    files.update(checked(x) for x in archive_files)
    files.update(local(x['path'], W) for x in published)
    files.update(T.glob('compiled-source-*.json'))
    files.update(T.glob('authored-source-*.json'))
    files.add(local('browser-final-1.json'))
    for path in files:
        archive_file(path)
    serialized = (json.dumps(selection, indent=2) + '\n').encode()
    # Publisher also archives these three small external records and parent manifest.
    external = [binding('browser-final-2.json', S), binding('reftests-final-2/report.json', S),
                binding('browser-final-3.json', ROUNDED)]
    external_bytes = [Path(x['path']).read_bytes() for x in external]
    external_bytes.append(git('show', BASE + ':tests/reftests/manifest.json'))
    sizes_to_pack = [p.stat().st_size for p in files] + [len(serialized)] + [len(x) for x in external_bytes]
    # Includes a generous per-member PAX allowance, padding and end blocks.
    tar_upper = 10240 + sum(2048 + ((n + 511) // 512) * 512 for n in sizes_to_pack)
    assert sum(sizes_to_pack) < CAP and tar_upper + 65536 < CAP, (sum(sizes_to_pack), tar_upper)
    for name, sha in source['source_sha256'].items():
        assert digest(local(name, W)) == sha, name
    with OUTPUT.open('xb') as stream:
        stream.write(serialized)
    assert OUTPUT.read_bytes() == serialized
    print(json.dumps({'selection': binding(OUTPUT), 'source_count': selection['source_count'],
        'checks': len(checks), 'published_files': len(published), 'archive_input_bytes': sum(sizes_to_pack),
        'conservative_tar_bytes': tar_upper}, indent=2))


if __name__ == '__main__':
    main()
