from pathlib import Path
import shutil
T=Path('/tmp/eris-background-boxes-1'); W=T/'worktree'
p=W/'src/layout.rs'; s=p.read_text()
s=s.replace('<<<<<<< Updated upstream\nmod inline_edges;\nuse inline_edges::{InlineCollection, InlineEdges, InlineSpan};\n=======\nmod background_boxes;\nuse background_boxes::{BackgroundBoxes, PaintRole, PaintSlots};\n>>>>>>> Stashed changes', 'mod inline_edges;\nuse inline_edges::{InlineCollection, InlineEdges, InlineSpan};\nmod background_boxes;\nuse background_boxes::{BackgroundBoxes, PaintRole, PaintSlots};\nmod inline_backgrounds;\nuse inline_backgrounds::InlineLayer;')
s=s.replace('    // Private inline URL slot. A transparent Rect carries its fragment geometry\n    // until the complete sliced strip is known; no fabricated image key escapes.\n    inline_raster: bool,', '    // Explicit pending layer and phase, independent of command admission.\n    inline_layer: InlineLayer,\n    inline_prefix: f32,\n    inline_sides: u8,')
s=s.replace('    inline: bool,\n}', '    inline: bool,\n    inline_prefix: f32,\n    inline_basis: f32,\n    inline_sides: u8,\n}')
a=s.index('    fn record_inline_boxes('); b=s.index('    #[allow(clippy::too_many_arguments)]\n    fn paint_line(',a)
s=s[:a]+s[b:]
s=s.replace('engine.finish_inline_gradients();', 'engine.finish_inline_backgrounds();')
s=s.replace('                self.boxes.push(geometry);\n', '                self.boxes.push(geometry);\n                self.paint_inline_background(geometry, geometry.inline_prefix, geometry.inline_sides);\n')
a=s.index('                    self.record_inline_boxes(item.node, item_rect);'); b=s.index('                    self.push(DrawCommand::Text {',a)
s=s[:a]+s[b:]
s=s.replace('                    self.record_inline_boxes(\n                        item.node,\n                        rect(visual_x, visual_y + offset, item.width, item.height),\n                    );\n','')
s=s.replace('                    self.record_inline_boxes(id, rect(visual_x, visual_y, 0.0, height));\n','')
s=s.replace('                            parent: active_span,','                            parent: active_span,\n                            basis: width,')
p.write_text(s)
# Mechanical private metadata initialization; no preexisting assertions changed.
for p in [W/'src/layout.rs', *sorted((W/'src/layout').rglob('*.rs'))]:
    s=p.read_text()
    s=s.replace('inline_raster: false,', 'inline_layer: InlineLayer::None, inline_prefix: 0.0, inline_sides: 0,')
    s=s.replace('!e.paint_owner.inline_raster', 'e.paint_owner.inline_layer == InlineLayer::None')
    # Existing initializers are one per line in these files.
    import re
    s=re.sub(r'(\binline: (?:true|false),)(\n\s*})', r'\1 inline_prefix: 0.0, inline_basis: 0.0, inline_sides: 0,\2', s)
    if p.name in ['tests.rs','independent_tests.rs'] and p.parent.name=='inline_edges':
        s=s.replace('parent: None,','parent: None, basis: 0.0,')
    p.write_text(s)
p=W/'src/layout/inline_edges.rs'; s=p.read_text()
s=s.replace('    pub(super) parent: Option<usize>,','    pub(super) parent: Option<usize>,\n    pub(super) basis: f32,')
s=s.replace('inline: true, inline_prefix: 0.0, inline_basis: 0.0, inline_sides: 0,', 'inline: true, inline_prefix: 0.0, inline_basis: self.basis, inline_sides: u8::from(first) * inline_backgrounds::FIRST | u8::from(last) * inline_backgrounds::LAST,',1)
s=s.replace('    start: f32,','    start: f32,\n    advance: f64,')
s=s.replace('                        generation: self.generation,','                        advance: slot.advance,\n                        generation: self.generation,')
s=s.replace('                let geometry = if slot.anchor {','                let mut geometry = if slot.anchor {')
s=s.replace('                boxes.push((geometry, self.offsets[id]));', '                geometry.inline_prefix = slot.advance as f32;\n                boxes.push((geometry, self.offsets[id]));')
# New transactional owner commit pass is charged before any line publication.
s=s.replace('.checked_mul(2 * (sort_depth + 2))?', '.checked_mul(2 * (sort_depth + 2) + 1)?')
s=s.replace('        Some(LinePlan { positions, boxes })','        // Every fallible operation and cursor check precedes this paid pass.\n        // A refused line cannot change the phase of a later successful line.\n        for ((_, id), (geometry, _)) in closes.iter().zip(&boxes) {\n            self.scratch[id.0].advance += f64::from(geometry.border.width);\n        }\n        Some(LinePlan { positions, boxes })')
p.write_text(s)
p=W/'tests/worker.rs'; s=p.read_text(); s+='\n#[path = "worker/background_boxes.rs"]\nmod background_boxes;\n';p.write_text(s)
dest=W/'src/layout/inline_backgrounds/tests.rs'; dest.parent.mkdir(exist_ok=True)
s=(T/'inline-tests/tests.rs').read_text().replace('inline_sides: 1 }','inline_sides: 1, inline_basis: 10.0 }').replace('inline_sides: 0 }','inline_sides: 0, inline_basis: 10.0 }').replace('inline_sides: 2 }','inline_sides: 2, inline_basis: 10.0 }').replace('inline_sides: sides }','inline_sides: sides, inline_basis: 4.0 }')
# The zero-sides replacement above also touches PaintOwner: remove there only.
s=s.replace('inline_layer: InlineLayer::None, inline_prefix: 0.0, inline_sides: 0, inline_basis: 10.0', 'inline_layer: InlineLayer::None, inline_prefix: 0.0, inline_sides: 0')
dest.write_text(s)
p=T/'snapshot-source.py';s=p.read_text().replace('/tmp/eris-rounded-boxes-1/compiled-source-3.json','/tmp/eris-inline-edges-1/compiled-source-2.json').replace('8595a6e8f4b00069cfa5c4a36e688a6e51cfd383','e89f5846a10cef7a7b2f062aaa296984da204026').replace('Background origin/clip parser and CSSOM staging; renderer integration not yet implemented.','Background box selection and sliced inline painting integration.')
p.write_text(s)
