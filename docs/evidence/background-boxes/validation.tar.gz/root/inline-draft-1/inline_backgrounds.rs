//! Sliced inline decoration from retained owner geometry, independent of paint admission.
use super::*;
use crate::graphics::box_decoration::RoundedBox;

#[derive(Clone, Copy, Default, PartialEq, Eq)]
#[repr(u8)]
pub(super) enum InlineLayer {
    #[default]
    None,
    Clip,
    Color,
    Image,
    Border,
}

pub(super) const FIRST: u8 = 1;
pub(super) const LAST: u8 = 2;
const MAX_STRIP: f64 = 16_000_000.0;

#[derive(Clone, Copy, Default)]
struct Metrics {
    widths: [f64; 3],
    heights: [f32; 3],
    border: Sides,
    padding: Sides,
    sides: u8,
    seen: bool,
    invalid: bool,
}

impl Metrics {
    fn add(&mut self, geometry: BoxGeometry) {
        let boxes = [geometry.border, geometry.padding, geometry.content];
        for (index, area) in boxes.into_iter().enumerate() {
            if ![area.x, area.y, area.width, area.height]
                .into_iter()
                .all(f32::is_finite)
                || area.width < 0.0
                || area.height < 0.0
            {
                self.invalid = true;
                return;
            }
            self.widths[index] += f64::from(area.width);
            self.invalid |= self.widths[index] > MAX_STRIP;
        }
        // The input is private layout geometry. Endpoint subtraction can lose
        // a zero inset after a large translation; preserve its nonnegative
        // used extent without rounding any author coordinate or pixel oracle.
        let difference = |outer: Rect, inner: Rect| Sides {
            top: (inner.y - outer.y).max(0.0),
            left: (inner.x - outer.x).max(0.0),
            right: ((outer.x + outer.width) - (inner.x + inner.width)).max(0.0),
            bottom: ((outer.y + outer.height) - (inner.y + inner.height)).max(0.0),
        };
        let border = difference(geometry.border, geometry.padding);
        let padding = difference(geometry.padding, geometry.content);
        if !self.seen {
            self.heights = boxes.map(|area| area.height);
            self.border.top = border.top;
            self.border.bottom = border.bottom;
            self.padding.top = padding.top;
            self.padding.bottom = padding.bottom;
        }
        if geometry.inline_sides & FIRST != 0 {
            self.border.left = border.left;
            self.padding.left = padding.left;
        }
        if geometry.inline_sides & LAST != 0 {
            self.border.right = border.right;
            self.padding.right = padding.right;
        }
        self.sides |= geometry.inline_sides;
        self.seen = true;
    }

    fn boxes(
        self,
        fragment: Rect,
        prefix: f32,
        radius: f32,
    ) -> Option<background_boxes::BackgroundBoxes> {
        if !self.seen || self.invalid || !prefix.is_finite() || prefix < 0.0 {
            return None;
        }
        let left = f64::from(fragment.x) - f64::from(prefix);
        if left.abs() > MAX_STRIP {
            return None;
        }
        let mut radii = [[radius; 2]; 4];
        if self.sides & FIRST == 0 {
            radii[0] = [0.0; 2];
            radii[3] = [0.0; 2];
        }
        if self.sides & LAST == 0 {
            radii[1] = [0.0; 2];
            radii[2] = [0.0; 2];
        }
        let outer = RoundedBox {
            rect: Rect {
                x: left as f32,
                y: fragment.y,
                width: self.widths[0] as f32,
                height: fragment.height,
            },
            radii,
        };
        let mut boxes = background_boxes::BackgroundBoxes::new(outer, self.border, self.padding)?;
        // Sum each selected box independently. Margins and descendant visual
        // movement never participate; omitted image commands cannot rephase it.
        boxes.padding.rect.width = self.widths[1] as f32;
        boxes.content.rect.width = self.widths[2] as f32;
        boxes.padding.rect.height = self.heights[1];
        boxes.content.rect.height = self.heights[2];
        (boxes.border.valid() && boxes.padding.valid() && boxes.content.valid()).then_some(boxes)
    }
}

fn fragment_clip(area: Rect, sides: u8) -> Option<Rect> {
    let left = if sides & FIRST != 0 { area.x.floor() } else { area.x };
    let right = area.x + area.width;
    let right = if sides & LAST != 0 { right.ceil() } else { right };
    let top = area.y.floor();
    let bottom = (area.y + area.height).ceil();
    let result = Rect { x: left, y: top, width: right - left, height: bottom - top };
    RoundedBox { rect: result, radii: [[0.0; 2]; 4] }.valid().then_some(result)
}

impl Engine<'_> {
    pub(super) fn paint_inline_background(
        &mut self,
        geometry: BoxGeometry,
        prefix: f32,
        physical_sides: u8,
    ) {
        let node = geometry.node;
        if self.canvas_background_node == Some(node)
            || geometry.border.width <= 0.0
            || geometry.border.height <= 0.0
            || !prefix.is_finite()
            || prefix < 0.0
            || f64::from(prefix) > MAX_STRIP
        {
            return;
        }
        let style = self.style(node);
        if style.background_color.a == 0
            && style.background_image.is_none()
            && (style.border_color.a == 0 || self.borders(node).horizontal() + self.borders(node).vertical() == 0.0)
        {
            return;
        }
        // The opener, three explicit layer slots and closer are one admission.
        // Geometry and prefix were retained before this paint-only decision.
        if self.commands_created + self.open_clips + 5 > MAX_COMMANDS {
            return;
        }
        let saved = self.paint_owner;
        self.paint_owner = PaintOwner {
            node,
            background: true,
            inline_layer: InlineLayer::Clip,
            inline_prefix: prefix,
            inline_sides: physical_sides,
        };
        self.push(DrawCommand::PushClip { rect: geometry.border });
        for layer in [InlineLayer::Color, InlineLayer::Image, InlineLayer::Border] {
            self.paint_owner.inline_layer = layer;
            self.push(DrawCommand::Rect {
                rect: geometry.border,
                color: Color::TRANSPARENT,
                radius: 0.0,
            });
        }
        self.paint_owner.inline_layer = InlineLayer::None;
        self.push(DrawCommand::PopClip);
        self.paint_owner = saved;
        self.inline_gradients = true;
    }

    pub(super) fn finish_inline_backgrounds(&mut self) {
        if !self.inline_gradients {
            return;
        }
        self.inline_gradients = false;
        if self.doc.nodes.len() > MAX_VISITS
            || !background_boxes::spend(&mut self.position_work_left, self.commands.len())
        {
            return;
        }
        let pending = self.owners.iter().filter(|owner| owner.inline_layer != InlineLayer::None).count();
        let cost = self.doc.nodes.len()
            .saturating_add(self.boxes.len().saturating_mul(8))
            .saturating_add(self.commands.len())
            .saturating_add(pending.saturating_mul(background_boxes::SHAPE_WORK));
        if !background_boxes::spend(&mut self.position_work_left, cost) {
            return;
        }
        let mut metrics = Vec::new();
        if metrics.try_reserve_exact(self.doc.nodes.len()).is_err() {
            return;
        }
        metrics.resize(self.doc.nodes.len(), Metrics::default());
        for &geometry in &self.boxes {
            if geometry.inline && let Some(metric) = metrics.get_mut(geometry.node) {
                metric.add(geometry);
            }
        }
        for index in 0..self.commands.len() {
            let owner = self.owners[index];
            if owner.inline_layer == InlineLayer::None {
                continue;
            }
            self.owners[index].inline_layer = InlineLayer::None;
            let area = match self.commands[index] {
                DrawCommand::Rect { rect, .. } | DrawCommand::PushClip { rect } => rect,
                _ => continue,
            };
            if owner.inline_layer == InlineLayer::Clip {
                self.commands[index] = DrawCommand::PushClip {
                    rect: fragment_clip(area, owner.inline_sides).unwrap_or_default(),
                };
                continue;
            }
            let style = self.style(owner.node);
            let Some(boxes) = metrics.get(owner.node).copied()
                .and_then(|metric| metric.boxes(area, owner.inline_prefix, style.border_radius))
            else { continue };
            let shape = boxes.select(style.background_clip);
            let command = match owner.inline_layer {
                InlineLayer::Color => background_boxes::color(shape, style.background_color, None),
                InlineLayer::Image => {
                    let origin = boxes.select(style.background_origin).rect;
                    let current_color = style.color;
                    self.background_command(owner.node, shape.rect, origin, 0.0, current_color, false)
                        .map(|command| background_boxes::image(command, shape))
                        .unwrap_or_else(background_boxes::empty)
                }
                InlineLayer::Border => {
                    if boxes.border == boxes.padding {
                        background_boxes::empty()
                    } else {
                        background_boxes::color(boxes.border, style.border_color, Some(boxes.padding))
                    }
                }
                InlineLayer::None | InlineLayer::Clip => unreachable!(),
            };
            self.commands[index] = command;
        }
    }
}

#[cfg(test)]
mod tests;
