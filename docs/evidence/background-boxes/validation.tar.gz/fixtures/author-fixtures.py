"""Inert source/data authoring: literal rectangles; no engine imports or execution."""
from pathlib import Path
import json, hashlib
root=Path('/tmp/eris-background-boxes-1'); out=root/'worktree/tests/reftests'; held=root/'fixtures'
RESET='html,body{margin:0;padding:0;background:white;font-size:0;line-height:0}div{position:absolute;box-sizing:content-box}'
R='ff0000'; B='0000ff'; L='00ff00'
def html(css,body): return '<!doctype html><meta charset="utf-8"><style>'+css+'</style>\n'+body+'\n'
def ref(rects):
 return html(RESET,'\n'.join(f'<div style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;background:#{c}"></div>' for x,y,w,h,c in rects))
cases=[]
def case(name,css,body,rects,description,derivation):
 name='background-box-'+name
 a=html(css,body); b=ref(rects)
 for suffix,value in [('.html',a),('-ref.html',b)]:
  p=out/(name+suffix);assert not p.exists(),p;p.write_text(value)
  q=held/'raw/tests/reftests'/p.name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(value)
 cases.append({'name':name,'description':description,'test':name+'.html','reference':name+'-ref.html','viewport':[320,240],'clear':'ffffff','ordered_rectangles_xywh_rgb':rects,'derivation':derivation})
# All geometry below is literal. The reference images contain no gradients,
# background-box properties, borders, padding or rounded commands.
uniform='div.sample{left:20px;width:12px;height:8px;padding:2px 4px;border:2px solid transparent;background-image:linear-gradient(to right,red 50%,blue 50%);background-size:50% 100%;background-repeat:repeat;background-position:0% 0%;background-clip:border-box}'
rects=[]
for y,bands in [(20,[(20,6,R),(26,6,B),(32,6,R),(38,6,B)]),(44,[(20,2,B),(22,5,R),(27,5,B),(32,5,R),(37,5,B),(42,2,R)]),(68,[(20,3,R),(23,3,B),(26,3,R),(29,3,B),(32,3,R),(35,3,B),(38,3,R),(41,3,B)])]:
 rects.extend((x,y,w,16,c) for x,w,c in bands)
case('origins',RESET+uniform,'\n'.join(f'<div class="sample" style="top:{y}px;background-origin:{box}-box"></div>' for y,box in [(20,'border'),(44,'padding'),(68,'content')]),rects,
 'Three positioning boxes independently determine percentage tile width and repeated hard-stop phase.',
 ['Border box(20,y,24,16), padding(22,y+2,20,12), content(26,y+4,12,8). All paint into border box.', '50% tile widths12/10/6 give red/blue runs6/5/3 anchored atx20/22/26; negative repeated phase covers the left border too.'])
clipcss='div.sample{left:20px;width:12px;height:8px;padding:2px 4px;border:2px solid transparent;background-color:lime;background-image:linear-gradient(to right,red 25%,transparent 25%,transparent 75%,blue 75%);background-size:8px 4px;background-repeat:repeat;background-position:0% 0%;background-origin:content-box}'
rects=[]
for y,h,bands in [(20,16,[(20,4,L),(24,2,B),(26,2,R),(28,4,L),(32,2,B),(34,2,R),(36,4,L),(40,2,B),(42,2,R)]),(46,12,[(22,2,L),(24,2,B),(26,2,R),(28,4,L),(32,2,B),(34,2,R),(36,4,L),(40,2,B)]),(72,8,[(26,2,R),(28,4,L),(32,2,B),(34,2,R),(36,2,L)])]:
 rects.extend((x,y,w,h,c) for x,w,c in bands)
case('clips',RESET+clipcss,'\n'.join(f'<div class="sample" style="top:{y}px;background-clip:{box}-box"></div>' for y,box in [(20,'border'),(44,'padding'),(68,'content')]),rects,
 'Three painting boxes clip both base color and image while a transparent middle stripe exposes the lime base.',
 ['Fixed content originx26 for every sample; tile runs2 red/4 transparent/2 blue. Transparent stop centers expose lime, not canvas white.', 'Clip rectangles are(20,20,24,16),(22,46,20,12),(26,72,12,8), independent of unchanged content origin.'])
unequal='div.sample{left:20px;width:8px;height:6px;border-style:solid;border-color:transparent;border-width:1px 3px 2px 4px;padding:3px 1px 4px 2px;background-color:lime;background-image:linear-gradient(to right,red 50%,blue 50%);background-size:4px 2px;background-repeat:no-repeat}'
rects=[(26,24,8,6,L),(20,44,18,16,L),(31,56,2,2,R),(33,56,2,2,B),(24,69,11,13,L),(28,74,2,2,R),(30,74,2,2,B)]
case('unequal-insets',RESET+unequal,
 '<div class="sample" style="top:20px;background-origin:border-box;background-clip:content-box;background-position:right bottom"></div>\n<div class="sample" style="top:44px;background-origin:padding-box;background-clip:border-box;background-position:right bottom"></div>\n<div class="sample" style="top:68px;background-origin:content-box;background-clip:padding-box;background-position:center"></div>',rects,
 'Unequal physical insets separate right/bottom and centered positioning from the chosen color/image clip.',
 ['Relative boxes border(0,0,18,16), padding(4,1,11,13), content(6,4,8,6).','First tile(34,34,4,2) is outside content clip; second tile(31,56,4,2) paints within border clip; third centered content tile(28,74,4,2) paints within padding clip.'])
rootbox='html{margin:0;width:24px;height:16px;box-sizing:content-box;padding:3px 5px;border:2px solid transparent;border-radius:8px;color:red;font-size:0;line-height:0}body{margin:0;padding:0;width:2px;height:2px;color:lime}'
image='background-image:linear-gradient(to right,currentColor 50%,blue 50%);background-size:8px 8px;background-position:0% 0%;background-repeat:repeat;background-clip:content-box;'
rects=[(x,0,4,240,R if x%8==0 else B) for x in range(0,320,4)]
case('root-canvas',rootbox+'html{'+image+'background-origin:border-box}', '<body></body>',rects,
 'Root canvas painting ignores content clipping and root rounding while retaining border-origin phase.',
 ['Root border(0,0,38,26), padding(2,2,34,22), content(7,5,24,16). Border-origin tile starts(0,0).','Entire320x240 canvas alternates4 red/4 blue columns despite clip:content-box and radius8. Body has no own background.'])
rects=[(0,0,3,240,R)]
for x in range(3,320,8):
 rects.append((x,0,min(4,320-x),240,B))
 if x+4<320:rects.append((x+4,0,min(4,316-x),240,R))
case('body-canvas',rootbox+'body{'+image+'background-origin:content-box}', '<body></body>',rects,
 'Propagated body background uses the root content origin and root currentColor, with no local second painting or content clip.',
 ['Root image:none and transparent color allow body background propagation. Root content origin is(7,5); body own2x2 geometry is not the positioning area.','Root red currentColor overrides body lime in propagated paint. Repeated8px tile phase atx0 is1px: first red run0..3, then blue3..7, red7..11; entirecanvasheight240 is painted.'])
radcss='div.sample{top:20px;width:4px;height:4px;padding:2px;border:2px solid transparent;border-radius:4px;background-color:blue}'
rects=[]
rows=[['a0a0ff','1010ff',B,B,B,B,'1010ff','a0a0ff'],['1010ff',B,B,B,B,B,B,'1010ff']]+[[B]*8 for _ in range(4)]+[['1010ff',B,B,B,B,B,B,'1010ff'],['a0a0ff','1010ff',B,B,B,B,'1010ff','a0a0ff']]
for y,row in enumerate(rows):
 for x,c in enumerate(row):rects.append((22+x,22+y,1,1,c))
rects.append((44,24,4,4,B))
case('rounded-insets',RESET+radcss,'<div class="sample" style="left:20px;background-clip:padding-box"></div>\n<div class="sample" style="left:40px;background-clip:content-box"></div>',rects,
 'Scalar outer radius4 becomes inner padding radius2 and content radius0, with independently counted fixed-grid coverage.',
 ['Outer12x12 radius4 is already normalized. Border2 produces padding8x8 radius2; combined border2+padding2 produces content4x4 radius0.','At padding top-left pixel, fixed subpixel odd-eighth coordinates give(16-a)^2+(16-b)^2<=256 for a,b in{1,3,5,7}:6 hits. Adjacent corner pixel has15hits; rest16. floor(255*h/16) gives95/239/255; blue overwhite becomes#a0a0ff/#1010ff/#0000ff. Reflections give all fourcorners.','Counts and antialias colors bind Eris BoxDecoration fixed4x4 sampling, not a CSS-mandated antialias algorithm. Interior witness(24,24) blue; exterior(21,21)white; content collapsed corner(44,24)blue.'])
manifest=[{k:c[k] for k in ['name','description','test','reference']} for c in cases]
(held/'manifest-additions.json').write_text(json.dumps(manifest,indent=2)+'\n')
(held/'oracles.json').write_text(json.dumps({'status':'Independent literal principal-box fixture expectations; no renderer execution','viewport':[320,240],'cases':cases,'spec_sources':[
 {'url':'https://drafts.csswg.org/css-backgrounds-3/#the-background-origin','basis':'Positioning area selects border, padding or content; percentage image sizing uses that area.'},
 {'url':'https://drafts.csswg.org/css-backgrounds-3/#the-background-clip','basis':'Painting area clips image and color; root canvas is exempt.'},
 {'url':'https://drafts.csswg.org/css-backgrounds-3/#special-backgrounds','basis':'Root background paints canvas using root positioning geometry; eligible body background values propagate to root.'},
 {'url':'https://drafts.csswg.org/css-backgrounds-3/#corner-shaping','basis':'Inner radii subtract corresponding border and padding insets, flooring atzero.'}], 'limits':'Six self-authored focused fixtures, not WPT or full CSS conformance. No inline/table coverage. Tests use gradient/color only; no fetch/GPU/performance claims.'},indent=2)+'\n')
files=[]
for c in cases:
 for key in ['test','reference']:
  rel='tests/reftests/'+c[key];p=root/'worktree'/rel;q=held/'raw'/rel;b=q.read_bytes();files.append({'relative':rel,'raw':str(q),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
(held/'source-ready.json').write_text(json.dumps({'status':'six independent principal-box pairs frozen before renderer edits or execution','files':files,'oracles':binding(held/'oracles.json'),'manifest_additions':binding(held/'manifest-additions.json'),'authoring':binding(held/'author-fixtures.py'),'manifest_edited':False,'executions':[]},indent=2)+'\n')
print(hashlib.sha256((held/'source-ready.json').read_bytes()).hexdigest())
