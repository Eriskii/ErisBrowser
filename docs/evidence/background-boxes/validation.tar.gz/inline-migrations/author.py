from pathlib import Path
import difflib,hashlib,json
D=Path('/tmp/eris-background-boxes-1/inline-migrations'); S=Path('/tmp/eris-inline-edges-1/worktree')
rels=['src/layout/gradient_tests.rs','src/layout/background_tests.rs','src/layout/url_background_tests.rs','tests/reftests/url-background-inline-table.html','tests/reftests/url-background-inline-table-ref.html']
for rel in rels:
 p=D/'original'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes((S/rel).read_bytes())
def read(n):return (D/'before'/('src/layout/'+n+'.rs')).read_text()
def block(s,name):
 a=s.index('fn '+name+'('); b=s.find('\n#[test]',a); return a,len(s) if b<0 else b

def change(s,name,fn):
 a,b=block(s,name);return s[:a]+fn(s[a:b])+s[b:]
def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b)

g=read('gradient_tests')
g=change(g,'gradients',lambda s:once(s,'            _ => None,','''            DrawCommand::BoxDecoration(value) => match &value.paint {
                crate::graphics::box_decoration::BoxPaint::LinearGradient { tile, current_color, stop_scale, .. } => {
                    assert_eq!(*stop_scale, 1.0);
                    let radius = value.shape.radii[0][0];
                    assert_eq!(value.shape.radii, [[radius; 2]; 4]);
                    Some((value.shape.rect, *tile, radius, *current_color))
                }
                _ => None,
            },
            _ => None,'''))
g=change(g,'inline_slice_continues_through_three_atomic_fragments_and_wrapping',lambda s: once(once(s,'''            rect(0.0, 0.0, 6.0, 2.0),
            rect(0.0, 0.0, 6.0, 2.0),
            rect(-4.0, 2.0, 6.0, 2.0)''','''            rect(0.0, 1.05, 6.0, 1.3),
            rect(-4.0, 3.05, 6.0, 1.3)'''),'''            0xff0000, 0xff0000, 0xff0000, 0x0000ff, 0xff0000, 0xff0000, 0xff0000, 0x0000ff,
            0x0000ff, 0x0000ff, 0xffffff, 0xffffff, 0x0000ff, 0x0000ff, 0xffffff, 0xffffff''','''            0xffffff, 0xffffff, 0xffffff, 0xffffff,
            0xff0000, 0xff0000, 0xff0000, 0x0000ff,
            0xffc0c0, 0xffc0c0, 0xffc0c0, 0xc0c0ff,
            0x0000ff, 0x0000ff, 0xffffff, 0xffffff'''))
def nested(s):
 s=s.replace('fn nested_inline_uses_ancestor_color_and_real_piece_height(', 'fn nested_inline_uses_ancestor_color_and_nominal_owner_height(')
 s=once(s,'assert_eq!(gradients(&result).len(), 3);','assert_eq!(gradients(&result).len(), 1);')
 s=once(s,'assert_eq!(pixels(&result, 6, 2), vec![0xff0000; 12]);','assert_eq!(pixels(&result, 6, 2), [vec![0xffffff; 6], vec![0xff0000; 6]].concat());')
 return once(s,'[0xff0000, 0xff0000, 0x0000ff, 0x0000ff, 0x0000ff, 0x0000ff].repeat(2)','[0xffffff, 0xffffff, 0xffffff, 0xffffff, 0xffffff, 0xffffff,\n         0xff0000, 0xff0000, 0x0000ff, 0x0000ff, 0x0000ff, 0x0000ff]')
g=change(g,'nested_inline_uses_ancestor_color_and_real_piece_height',nested)
g=change(g,'pending_inline_admission_is_atomic_and_zero_positioning_boxes_are_not_pending',lambda s:'''fn pending_inline_admission_is_atomic_and_zero_positioning_boxes_are_not_pending() {
    let (doc, mut styles) = prepare("<span id=a></span><div id=z></div>", 10.0, 10.0);
    let a = doc.query_selector("#a").unwrap();
    let z = doc.query_selector("#z").unwrap();
    let image = split(Color::rgb(255, 0, 0), Color::rgb(0, 0, 255));
    styles[a].background_image = Some(BackgroundImage::Gradient(Arc::clone(&image)));
    styles[z].background_image = Some(BackgroundImage::Gradient(image));
    let fonts = Fonts::new();
    let area = rect(0.0, 0.0, 2.0, 2.0);
    let geometry = BoxGeometry { node:a, border:area, padding:area, content:area,
        fixed:false, inline:true, inline_prefix:0.0, inline_sides:3, inline_basis:10.0 };
    let mut e = engine(&doc, &styles, &fonts);
    e.boxes.push(geometry);
    e.commands_created = MAX_COMMANDS - 4;
    e.paint_inline_background(geometry, 0.0, 3);
    assert!(e.commands.is_empty());
    assert_eq!(e.open_clips, 0);
    e.commands_created = MAX_COMMANDS - 5;
    e.paint_inline_background(geometry, 0.0, 3);
    assert_eq!((e.commands.len(), e.commands_created, e.open_clips), (5, MAX_COMMANDS, 0));
    // 5 classification + node table + 8 geometry + 5 slots + 4*16 shapes.
    let cost = doc.nodes.len() + 82;
    e.position_work_left = cost - 1;
    e.finish_inline_backgrounds();
    assert!(matches!(e.commands[2], DrawCommand::Rect { color, .. } if color == Color::TRANSPARENT));
    assert!(e.owners[2].inline_layer == InlineLayer::Image);
    assert_eq!(e.position_work_left, cost - 6); // Reached first scan stays charged.
    assert!(!e.inline_gradients); // Finalization is deliberately one-shot.

    let mut e = engine(&doc, &styles, &fonts);
    e.boxes.push(geometry);
    e.paint_inline_background(geometry, 0.0, 3);
    e.position_work_left = cost;
    e.finish_inline_backgrounds();
    assert_eq!(e.position_work_left, 0);
    assert!(matches!(&e.commands[2], DrawCommand::BoxDecoration(value)
        if matches!(&value.paint, crate::graphics::box_decoration::BoxPaint::LinearGradient {tile,..}
            if *tile == rect(0.0,0.0,2.0,2.0))));

    // A real zero-width tile stays zero while a separate inline slot is pending.
    let mut e = engine(&doc, &styles, &fonts);
    e.paint_owner = PaintOwner { node:z, background:true,
        inline_layer:InlineLayer::None, inline_prefix:0.0, inline_sides:0 };
    e.push(DrawCommand::LinearGradient {
        rect: rect(0.0, 0.0, 4.0, 4.0),
        tile: rect(2.0, 2.0, 0.0, 0.0),
        radius: 0.0,
        gradient: match styles[z].background_image.clone().unwrap() {
            BackgroundImage::Gradient(value) => value,
            _ => panic!("expected gradient"),
        },
        current_color: Color::BLACK,
        stop_scale: 1.0,
        repeat: [true; 2],
    });
    e.boxes.push(geometry);
    e.paint_inline_background(geometry, 0.0, 3);
    e.position_work_left = MAX_POSITION_WORK;
    e.finish_inline_backgrounds();
    assert!(matches!(e.commands[0], DrawCommand::LinearGradient {tile,..} if tile.width == 0.0));
}
''')

b=read('background_tests')
b=change(b,'gradients',lambda s:once(s,'            _ => None,','''            DrawCommand::BoxDecoration(value) => match &value.paint {
                crate::graphics::box_decoration::BoxPaint::LinearGradient { tile, repeat, .. } =>
                    Some((value.shape.rect, *tile, *repeat)),
                _ => None,
            },
            _ => None,'''))
b=change(b,'inline_size_and_position_resolve_once_against_the_complete_virtual_strip',lambda s:once(once(s,'''            rect(3.0, 0.0, 2.0, 2.0),
            rect(3.0, 0.0, 2.0, 2.0),
            rect(-1.0, 2.0, 2.0, 2.0)''','''            rect(3.0, 1.05, 2.0, 2.0),
            rect(-1.0, 3.05, 2.0, 2.0)'''),'''rows(&["WWWR", "WWWR", "BWWW", "BWWW"])''','''[
            0xffffff, 0xffffff, 0xffffff, 0xffffff,
            0xffffff, 0xffffff, 0xffffff, 0xff0000,
            0xffffff, 0xffffff, 0xffffff, 0xffc0c0,
            0x0000ff, 0xffffff, 0xffffff, 0xffffff,
        ]'''))

u=read('url_background_tests')
u=change(u,'rasters',lambda s:once(s,'            _ => None,','''            DrawCommand::BoxDecoration(value) => match &value.paint {
                crate::graphics::box_decoration::BoxPaint::Image { tile, repeat, key } => {
                    let radius = value.shape.radii[0][0];
                    assert_eq!(value.shape.radii, [[radius; 2]; 4]);
                    Some((value.shape.rect, *tile, radius, *repeat, key.as_str()))
                }
                _ => None,
            },
            _ => None,'''))
def urlinline(s):
 s=once(s,'assert_eq!(pixels(&result, 4, 4), vec![0x00ff00; 16]);','assert_eq!(pixels(&result, 4, 4), [vec![0xffffff; 4], vec![0x00ff00; 4], vec![0xc0ffc0; 4], vec![0x00ff00; 4]].concat());')
 s=once(s,'[vec![0xff0000; 8], vec![0x0000ff; 8]].concat()','[vec![0xffffff; 4], vec![0xff0000; 4], vec![0xd0c091; 4], vec![0x0000ff; 4]].concat()')
 s=once(s,'assert_eq!(images.len(), 4);','assert_eq!(images.len(), 2);')
 return once(s,'''            rect(0.0, 0.0, 8.0, 4.0),
            rect(0.0, 0.0, 8.0, 4.0),
            rect(-4.0, 2.0, 8.0, 4.0),
            rect(-4.0, 2.0, 8.0, 4.0)''','''            rect(0.0, 1.05, 8.0, 4.0),
            rect(-4.0, 3.05, 8.0, 4.0)''')
u=change(u,'unavailable_inline_color_and_loaded_virtual_strip_have_literal_pixels',urlinline)
u=change(u,'nested_inline_url_background_order_is_ancestor_then_child',lambda s:once(s,'[0xff0000, 0xff0000, 0x0000ff, 0x0000ff, 0x0000ff, 0x0000ff].repeat(2)','[0xffffff, 0xffffff, 0xffffff, 0xffffff, 0xffffff, 0xffffff,\n         0xff0000, 0xff0000, 0x0000ff, 0x0000ff, 0x0000ff, 0x0000ff]'))
u=change(u,'inline_pending_slots_are_private_balanced_and_budget_refusal_keeps_color',lambda s:'''fn inline_pending_slots_are_private_balanced_and_budget_refusal_keeps_color() {
    let (doc, mut styles) = prepare("<span id=a></span>", 4.0, 2.0);
    let a = doc.query_selector("#a").unwrap();
    url(&mut styles[a]);
    styles[a].background_color = Color::rgb(0, 255, 0);
    let mut bindings = vec![None; doc.nodes.len()];
    bindings[a] = Some(loaded("tile"));
    let fonts = Fonts::new();
    let area = rect(0.0,0.0,4.0,2.0);
    let geometry = BoxGeometry { node:a, border:area, padding:area, content:area,
        fixed:false, inline:true, inline_prefix:0.0, inline_sides:3, inline_basis:4.0 };
    let mut e = engine(&doc, &styles, &fonts, &bindings);
    e.boxes.push(geometry);
    e.commands_created = MAX_COMMANDS - 4;
    e.paint_inline_background(geometry, 0.0, 3);
    assert!(e.commands.is_empty());
    assert_eq!(e.open_clips, 0);
    e.commands_created = MAX_COMMANDS - 5;
    e.paint_inline_background(geometry, 0.0, 3);
    assert_eq!((e.commands.len(), e.open_clips), (5, 0));
    assert!(matches!(e.commands[2], DrawCommand::Rect {color,..} if color == Color::TRANSPARENT));
    assert!(e.owners[2].inline_layer == InlineLayer::Image);
    // 5 classification + node table + 8 geometry + 5 slots + 4*16 shapes.
    let scan = doc.nodes.len() + 82;
    e.position_work_left = scan - 1;
    e.finish_inline_backgrounds();
    assert_eq!(e.position_work_left, scan - 6);
    assert!(matches!(e.commands[2], DrawCommand::Rect { .. }));
    assert!(!e.inline_gradients);

    // One-shot failure uses a fresh preparation, not a runtime budget refill.
    let mut e = engine(&doc, &styles, &fonts, &bindings);
    e.boxes.push(geometry);
    e.paint_inline_background(geometry, 0.0, 3);
    e.position_work_left = scan + 4;
    e.finish_inline_backgrounds();
    assert_eq!(e.position_work_left, 4);
    assert_eq!(e.background_key_bytes_left, 65_536);
    assert!(matches!(e.commands[2], DrawCommand::Rect { .. }));
    // A fresh preparation with exact scan+key work resolves one real image.
    let mut e = engine(&doc, &styles, &fonts, &bindings);
    e.boxes.push(geometry);
    e.paint_inline_background(geometry, 0.0, 3);
    e.position_work_left = scan + 5;
    e.finish_inline_backgrounds();
    assert_eq!((e.position_work_left, e.background_key_bytes_left), (0, 65_532));
    assert!(matches!(&e.commands[2], DrawCommand::BoxDecoration(value)
        if matches!(&value.paint, crate::graphics::box_decoration::BoxPaint::Image {key,..} if key == "tile")));
    let mut e = engine(&doc, &styles, &fonts, &bindings);
    e.boxes.push(geometry);
    e.paint_inline_background(geometry, 0.0, 3);
    e.background_key_bytes_left = 0;
    e.finish_inline_backgrounds();
    e.restack();
    let result = LayoutResult { commands:e.commands, hit_regions:e.hits, content_height:2.0 };
    assert!(rasters(&result).is_empty());
    assert_eq!(pixels(&result, 4, 2), vec![0x00ff00; 8]);
}
''')

new={'src/layout/gradient_tests.rs':g,'src/layout/background_tests.rs':b,'src/layout/url_background_tests.rs':u}
ref=(D/'before/tests/reftests/url-background-inline-table-ref.html').read_text()
lines=ref.splitlines(True)
# The table begins at the first y62 literal. Preserve every byte from there.
idx=next(i for i,line in enumerate(lines) if 'top:62px' in line)
inline=[(21,21,'#ff0000'),(22,21,'#00ff00'),(23,21,'#0000ff'),(21,22,'#ffc0ff'),(22,22,'#ffffc0'),(23,22,'#c0c0c0'),(20,23,'#00ffff'),(20,24,'#ffe0c0')]
new['tests/reftests/url-background-inline-table-ref.html']=lines[0]+''.join(f'<div style="left:{x}px;top:{y}px;width:1px;height:1px;background:{color}"></div>\n' for x,y,color in inline)+''.join(lines[idx:])
new['tests/reftests/url-background-inline-table.html']=(D/'before/tests/reftests/url-background-inline-table.html').read_text()
patch=[]
for rel,after in new.items():
 p=D/'after'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(after)
 before=(D/'before'/rel).read_text()
 patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel))
(D/'migration.patch').write_text(''.join(patch))
print(json.dumps({'files':len(new),'changed':sum((D/'before'/r).read_text()!=v for r,v in new.items()),'patch_bytes':(D/'migration.patch').stat().st_size},indent=2))
