fn inline_opacity_encloses_wrapped_runs_once_and_keeps_primitive_alpha() {
        let (_, result) = render(
            "<style>body{margin:0;width:75px;font:20px monospace}span{opacity:.5;background:red;color:blue}</style><span>alpha beta gamma delta</span>",
            200.0,
        );
        assert_eq!(
            result
                .commands
                .iter()
                .filter(|c| matches!(c, DrawCommand::PushOpacity { .. }))
                .count(),
            1
        );
        let mut text_lines = std::collections::HashSet::new();
        for command in &result.commands {
            if let DrawCommand::Text { y, color, .. } = command {
                text_lines.insert(y.to_bits());
                assert_eq!(*color, Color::rgb(0, 0, 255));
            }
        }
        assert!(text_lines.len() >= 3);
        assert!(result.commands.iter().any(
            |c| matches!(c, DrawCommand::Rect { color, .. } if *color == Color::rgb(255, 0, 0))
        ));
    }

