from pathlib import Path
import json,hashlib,struct,zlib
D=Path('/tmp/eris-background-boxes-1/inline-fixtures'); R=D/'raw/tests/reftests';R.mkdir(parents=True,exist_ok=True)
W,H=320,240
RESET='html,body{margin:0;background:white}main{position:absolute;font-size:20px;line-height:26px}i{display:inline-block;width:4px;height:26px;vertical-align:top}'
EDGES='border-left:1px solid transparent;border-right:2px solid transparent;padding-left:2px;padding-right:1px;'
PALETTE={'R':'#ff0000','B':'#0000ff','W':'#ffffff'}
cases=[]
def rect(x,y,w,h,color):return {'x':x,'y':y,'width':w,'height':h,'color':color}
def runrow(x,y,h,s):
 out=[];start=0
 for end in range(1,len(s)+1):
  if end==len(s) or s[end]!=s[start]:
   if s[start]!='W':out.append(rect(x+start,y,end-start,h,PALETTE[s[start]]))
   start=end
 return out

def add(name,description,html,rects,reason):
 test=R/(name+'.html');ref=R/(name+'-ref.html')
 test.write_text('<!doctype html><meta charset="utf-8">'+html+'\n')
 ref.write_text('<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:white}div{position:absolute}</style>\n'+''.join(f'<div style="left:{v["x"]}px;top:{v["y"]}px;width:{v["width"]}px;height:{v["height"]}px;background:{v["color"]}"></div>\n' for v in rects))
 frame=bytearray([255,255,255,255]*(W*H))
 for r in rects:
  color=bytes.fromhex(r['color'][1:])+b'\xff'
  for yy in range(r['y'],r['y']+r['height']):
   for xx in range(r['x'],r['x']+r['width']):
    at=4*(yy*W+xx);frame[at:at+4]=color
 literal=D/'literals'/(name+'.rgba');literal.parent.mkdir(exist_ok=True);literal.write_bytes(frame)
 cases.append({'name':name,'description':description,'test':test.name,'reference':ref.name,'viewport':[W,H],'clear':'#ffffff','ordered_literal_rectangles':rects,'whole_frame':str(literal),'derivation':reason})

html='<style>'+RESET+'main{top:20px;width:20px}span{'+EDGES+'background-image:linear-gradient(to right,red 50%,blue 50%);background-size:100% 100%;background-clip:border-box}</style>'
rects=[]
for x,origin,rows in [(20,'border-box',['RRRRRRR','BBBBBBB']),(60,'padding-box',['BRRRRRB','BBBBBRR']),(100,'content-box',['BBBRRRR','BBBBRRR'])]:
 html+=f'<main style="left:{x}px"><span style="background-origin:{origin}"><i></i><br><i></i></span></main>'
 for y,row in zip([27,53],rows):rects+=runrow(x,y,26,row)
add('background-box-inline-origins','Forced two-line slices position repeated hard stops against distinct14/11/8px virtual boxes.',html,rects,'font20/atomic26 gives owner top7,height26. First B/P/C widths7/6/4, last7/5/4; physical insets paid once. Pixel-center equality at the odd11px midpoint selects blue.')

asset=R/'background-box-inline-assets/two-color.png';asset.parent.mkdir(exist_ok=True)
pixels=bytes([255,0,0,255]*2+[0,0,255,255]*2)
raw=b''.join(b'\0'+pixels for _ in range(2))
def chunk(name,payload):return struct.pack('>I',len(payload))+name+payload+struct.pack('>I',zlib.crc32(name+payload)&0xffffffff)
asset.write_bytes(b'\x89PNG\r\n\x1a\n'+chunk(b'IHDR',struct.pack('>IIBBBBB',4,2,8,6,0,0,0))+chunk(b'IDAT',zlib.compress(raw))+chunk(b'IEND',b''))
html='<style>'+RESET+'main{top:20px;width:10px}span{'+EDGES+'background-origin:content-box;background-clip:content-box}</style>'
html+='<main style="left:20px"><span style="background-image:linear-gradient(to right,red 50%,blue 50%);background-size:100% 100%"><i></i><i></i><i></i><i></i></span></main>'
html+='<main style="left:60px"><span style="background-image:url(background-box-inline-assets/two-color.png);background-size:100% auto;background-repeat:no-repeat"><i></i><i></i><i></i><i></i></span></main>'
rects=[]
for x,h in [(20,26),(60,8)]:
 for y,row in zip([27,53,79],['WWWRRRRWWW','RRRRBBBBWW','BBBBWWWWWW']):rects+=runrow(x,y,h,row)
add('background-box-inline-phase','Soft three-line gradient and natural-ratio raster retain complete16px content phase.',html,rects,'Width10 fits one atom with opening3, then two atoms, then last atom with closing3. B/P/C widths22/19/16. Source4x2 RRBB/RRBB scales to16x8; no-repeat limits each raster slice to its first8 vertical pixels.')

html='<style>'+RESET+'#nested{left:20px;top:30px;width:30px}#nested span{padding:0 2px;background:red;background-clip:content-box}#nested b{font-size:40px;padding:0 1px;position:relative;left:5px;top:3px;background:blue;background-clip:content-box}#empty{left:80px;top:30px}#empty span{border-style:solid;border-color:transparent;border-width:1px 2px 1px 1px;padding:1px 3px 2px 2px;background:blue;background-clip:padding-box}#rounded{left:120px;top:20px;width:10px}#rounded span{'+EDGES+'background:red;border-radius:4px;background-clip:border-box}</style>'
html+='<main id=nested><span><i></i><b><i></i><i></i></b><i></i></span></main><main id=empty><span></span></main><main id=rounded><span><i></i><i></i><i></i><i></i></span></main>'
rects=[rect(22,37,18,26,'#ff0000'),rect(32,21,8,52,'#0000ff'),rect(81,29,5,29,'#0000ff'),rect(120,27,7,26,'#ff0000'),rect(120,53,8,26,'#ff0000'),rect(120,79,7,26,'#ff0000')]
# Independent integer circle equation at odd-eighth subpixels, not a renderer import.
counts=[[sum((8*x+a-32)**2+(8*y+b-32)**2<=1024 for a in [1,3,5,7] for b in [1,3,5,7]) for x in range(4)] for y in range(4)]
assert counts==[[0,3,11,16],[3,15,16,16],[11,16,16,16],[16,16,16,16]]
for yy in range(4):
 for xx in range(4):
  n=counts[yy][xx]
  if n==16:continue
  coverage=255*n//16; rem=255-coverage; color=f'#ff{rem:02x}{rem:02x}'
  # Only the unbroken shape's physical left/right ends have corners.
  for x,y in [(120+xx,27+yy),(120+xx,52-yy),(126-xx,79+yy),(126-xx,104-yy)]:rects.append(rect(x,y,1,1,color))
add('background-box-inline-nested-ends','Nominal parent/child heights, empty padding paint, and true rounded physical ends stay separate.',html,rects,'Outerfont20 content18x26 and innerfont40 content8x52 use their own baselines. Childrelative(5,3) moves only child paint. Empty padding is5x29. Rounded22x26 virtual shape slices7/8/7: only first-left and last-right corners are rounded; middle is full red. Frozen radius4 corner count matrix is [[0,3,11,16],[3,15,16,16],[11,16,16,16],[16,16,16,16]].')

(D/'manifest-additions.json').write_text(json.dumps([{k:c[k] for k in ['name','description','test','reference']} for c in cases],indent=2)+'\n')
(D/'oracles.json').write_text(json.dumps({'status':'independent source/data; not engine output','cases':cases,'palette':'Literal RGBA8, opaque white target','png':'Authored4x2, each row red red blue blue; no production decoder executed.','execution':'Only Python stdlib emitted files and literal byte buffers. No compiler/project/browser/GPU execution.'},indent=2)+'\n')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
paths=sorted(p for sub in ['raw','literals'] for p in (D/sub).rglob('*') if p.is_file())+[D/'manifest-additions.json',D/'oracles.json',Path('/tmp/eris-background-boxes-1/inline-plan/oracles-2.json')]
(D/'source-ready.json').write_text(json.dumps({'status':'source-ready; no project execution','scope':'Three external HTML/reference pairs, one authored tiny PNG, three complete320x240 RGBA literal frames; no live manifest edits','files':[bind(p) for p in paths]},indent=2)+'\n')
print(json.dumps({'cases':len(cases),'hold':bind(D/'source-ready.json'),'asset':bind(asset)},indent=2))
