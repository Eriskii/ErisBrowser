#!/usr/bin/env python3
"""Adapt the existing bounded local runner; preserve all authored source bytes."""
from pathlib import Path
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
OLD = Path('/tmp/eris-data-view-1/local-preparation')

def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(name, value):
    with (HERE / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')

draft = PARENT / 'local-oracle-draft-2.json'
data = json.loads(draft.read_bytes())
assert data['case_sources'] == 39 and data['case_modes'] == 78
assert data['feature_control_modes'] == 48
for row in data['cases'] + data['feature_controls']:
    assert hashlib.sha256(row['source'].encode()).hexdigest() == row['sha256']
shutil.copyfile(draft, HERE / 'draft.json')
shutil.copyfile(PARENT / 'local-oracle-draft-2.js', HERE / 'object-is.js')
shutil.copyfile(PARENT / 'LICENSE', HERE / 'TEST262-LICENSE')
for directory in ('tools', 'harness'):
    shutil.copytree(OLD / directory, HERE / directory,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

source = (OLD / 'run.py').read_text()
changes = []
def replace(before, after):
    global source
    assert source.count(before) == 1, before
    source = source.replace(before, after)
    changes.append(dict(before=before, after=after))

source = source.replace('data-view', 'object-is')
changes.append(dict(replace_all=['data-view', 'object-is']))
replace("freeze=json.loads((HERE/'freeze.json').read_text());fixture=HERE/'object-is.js'",
        "freeze=json.loads((HERE/'freeze.json').read_text());fixture=HERE/'object-is.js'\n draft=json.loads((HERE/'draft.json').read_text())")
replace("assert sha(HERE/'preflights.json')==freeze['preflights_sha256']",
        "assert sha(HERE/'draft.json')==freeze['draft_sha256']")
begin = source.index(" records={r['name']:r for r in freeze['cases']}")
end = source.index(' harness_pairs=', begin)
before = source[begin:end]
after = ''' matrix=[];seen=set()
 for item in draft['cases']:
  name=item['id'];assert name not in seen;seen.add(name)
  source=item['source'].encode();assert hashlib.sha256(source).hexdigest()==item['sha256']
  expected=COMPLETE if item['expectation']=='pass' else dict(status='resource',phase='runtime')
  assert item['expectation'] in ('pass','resource')
  for mode in item['modes']:
   c=make_case(name,source,mode,expected,harness)
   matrix.append((c,expected,dict(category='fixture',area=item['kind'],prerequisites=item['requires'])))
 assert len(seen)==freeze['source_cases']
 pairs=draft['feature_controls']
 for pair in pairs:
  for mode in pair['modes']:
   positive=pair['variant']=='positive';assert pair['variant'] in ('positive','wrong')
   source=pair['source'].encode();assert hashlib.sha256(source).hexdigest()==pair['sha256']
   expected=COMPLETE if positive else WRONG
   name='preflight-'+pair['pair']+('-positive' if positive else '-wrong')
   c=make_case(name,source,mode,expected,harness,'preflight-controls')
   matrix.append((c,expected,dict(category='preflight-control',positive=positive,partner='preflight-'+pair['pair']+'-positive#'+mode)))
'''
replace(before, after)
replace("4*len(pairs),'preflights;'", "2*len(pairs),'preflights;'")
replace("HERE/'preflights.json',HERE/'runner-matrix.json'", "HERE/'draft.json',HERE/'runner-matrix.json'")
source=source.replace('preflight-genuine-byte-view-positive#','preflight-nan-positive#')
changes.append(dict(replace_all=['preflight-genuine-byte-view-positive#','preflight-nan-positive#']))
with (HERE/'run.py').open('x') as handle:
    handle.write(source)
save('freeze.json', dict(phase='Independent Object.is oracle; no engine execution',
    fixture_sha256=sha(HERE/'object-is.js'), generator_sha256=sha(__file__),
    draft_sha256=sha(HERE/'draft.json'), source_cases=39, mode_cases=78))
save('runner-adaptation.json', dict(origin=str(OLD/'run.py'), origin_sha256=sha(OLD/'run.py'),
    runner_sha256=sha(HERE/'run.py'), draft_sha256=sha(draft), changes=changes,
    source_handling='Exact JSON source bytes; JS companion is a bound readable artifact.',
    common_controls='The prior twelve common control modes and harness order are unchanged.',
    engines_executed=False))
print('Prepared exact 78 fixture modes, 48 feature controls and 12 common controls.')
