# Initial scratch helper-order correction

The initial preserved admission.py hardcoded common helpers in the order sta.js, assert.js. The unchanged conformance runner actually uses assert.js, sta.js. Original helper bytes, source identities and admission/exclusion decisions match, but the initial admission.json ordered-helper claim is not the actual runner contract. Preserve that original report and all initial preparation bytes; use the actual unchanged runner order in the new formal contract.

This corrects the corresponding ordered-helper wording in the held proposal-2.md without changing its reviewed installer or any oracle, expectation, source, feature policy or runtime. The formal tooling owner retains the initial failed static comparison and the corrected exact contract. No JavaScript or compiler execution was performed for this correction.
