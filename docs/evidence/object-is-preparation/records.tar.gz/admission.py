"""Data-only proposed policy evaluation. Subprocess creation is forbidden."""
import ast,hashlib,importlib.util,json,subprocess,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');OUT=Path(__file__).parent
class ForbiddenExecution(RuntimeError):pass
def forbidden(*a,**k):raise ForbiddenExecution('no adapter/subprocess authorized during preparation')
subprocess.Popen=forbidden
sys.path.insert(0,str(ROOT/'tools'))
s=importlib.util.spec_from_file_location('policy_source',ROOT/'tools/test262_conformance.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
policy=m.OBJECT_INTEGRITY_FEATURES | {'Object.is'}
v=json.loads((OUT/'inventory.json').read_text());rows=[]
for r in v['sources']:
 helpers=['sta.js','assert.js']+r['metadata']['includes']
 harness=[(n,(OUT/'harness'/n).read_bytes()) for n in helpers]
 for mode in r['modes']:
  case=dict(metadata=r['metadata'],source=(OUT/r['path']).read_bytes(),harness=harness,mode=mode)
  reason=m.unsupported_reason(case,policy)
  rows.append(dict(path=r['path'],mode=mode,source_sha256=r['sha256'],git_blob=r['git_blob'],source_git_mode='100644',helper_order=[dict(name=n,sha256=hashlib.sha256(b).hexdigest(),bytes=len(b)) for n,b in harness],admitted=reason is None,exclusion=reason))
assert len(rows)==42 and all(r['admitted'] for r in rows)
payload=dict(schema=1,policy_expression="OBJECT_INTEGRITY_FEATURES | {'Object.is'}",policy=sorted(policy),runner_path='tools/test262_conformance.py',runner_sha256=hashlib.sha256((ROOT/'tools/test262_conformance.py').read_bytes()).hexdigest(),source_rows=21,mode_rows=42,admitted_modes=42,excluded_modes=0,rows=rows,subprocess_creation_forbidden=True,engine_execution=False,warning='Proposed profile only; no repo importer/runner changes or expected baseline outcomes.')
(OUT/'admission.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({k:v for k,v in payload.items() if k!='rows'},indent=2))
