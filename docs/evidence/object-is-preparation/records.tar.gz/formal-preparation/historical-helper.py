#!/usr/bin/env python3
"""One-shot historical replay. Preparation is inert; --execute needs root authorization."""
import argparse
from collections import Counter
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
from unittest.mock import patch

sys.dont_write_bytecode = True
INPUTS = Path('/tmp/eris-array-buffer-historical-replay-inputs.json')
INPUTS_SHA = 'e13437a594a47a343abe12821a6102eee7876740bd7ca354200659c9c03fe0e1'
PROFILE_SECONDS = 180
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def write_new(path, value):
    with Path(path).open('x', encoding='utf-8') as handle:
        json.dump(value, handle, indent=2, ensure_ascii=True)
        handle.write('\n')


def observation(case):
    # Include unsupported reasons/stderr and every other observation field;
    # do not silently discard changed resource diagnostics or phases.
    return {key: value for key, value in case.items() if key not in IDENTITY}


def unique(rows, key):
    indexed = {key(item): item for item in rows}
    require(len(indexed) == len(rows), 'duplicate case/control identity')
    return indexed


def verify_static_contract(runner, root, profile, contract, before):
    corpus = root / 'tests/upstream' / runner.corpus_name(profile)
    manifest, files, cases, fixtures, manifest_hash = runner.load_corpus(corpus, profile)
    require(manifest_hash == contract['manifest_sha256'], f'{profile}: corpus drift')
    require(manifest['revision'] == contract['revision'], f'{profile}: revision drift')
    require(fixtures == contract['fixtures'], f'{profile}: fixture inventory drift')
    require(sorted(runner.PROFILE_FEATURES[profile]) == contract['policy']['supported_features'],
            f'{profile}: feature policy drift')
    current = unique(cases, lambda item: item['id'])
    require(current.keys() == contract['cases'].keys(), f'{profile}: case inventory drift')
    for name, item in current.items():
        frozen = contract['cases'][name]
        require(item['case_sha256'] == frozen['case_sha256'], f'{profile}/{name}: case drift')
        require(runner.unsupported_reason(item, runner.PROFILE_FEATURES[profile]) == frozen['unsupported_reason'],
                f'{profile}/{name}: exclusion drift')

    # Capture generated control inputs without invoking any executable. This
    # fails before the real replay if source, helper, mode or expected outcome moved.
    captured = []
    def capture(case, binary, timeout, *args, **kwargs):
        result = {key: case[key] for key in ('id', 'file', 'mode', 'case_sha256')}
        result.update(source_sha256=runner.digest(case['source']),
                      expected_negative=case['metadata']['negative'], status='passed')
        captured.append(result)
        return result
    with patch.object(runner, 'run_case', capture):
        controls = runner.harness_preflight(files, Path('/not-executed'), 3.0, profile)
    require(len(controls) == len(captured) == len(contract['preflights']), f'{profile}: control count drift')
    for current, frozen in zip(controls, contract['preflights']):
        result = current['result']
        require((current['name'], current['expected'], result['mode'], result['case_sha256'], result['source_sha256']) ==
                (frozen['name'], frozen['expected'], frozen['mode'], frozen['case_sha256'], frozen['source_sha256']),
                f'{profile}: control identity drift at {current["name"]}')
    require([case['id'] for case in cases] == [case['id'] for case in before['cases']],
            f'{profile}: historical execution order changed')


def run_profile(command, root, log):
    from run import launch_environment
    env = launch_environment()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    with log.open('xb') as output:
        process = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                                   stdout=output, stderr=subprocess.STDOUT,
                                   close_fds=True, start_new_session=True)
        reap_started = False
        try:
            deadline = time.monotonic() + PROFILE_SECONDS
            while os.waitid(os.P_PID, process.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT) is None:
                left = deadline - time.monotonic()
                if left <= 0:
                    raise subprocess.TimeoutExpired(command, PROFILE_SECONDS)
                time.sleep(min(0.05, left))
            # Keep the exited leader unreaped until the owned group is cleaned up.
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            reap_started = True
            return process.wait(timeout=5)
        except BaseException:
            if not reap_started:
                try:
                    os.killpg(process.pid, signal.SIGKILL)
                except ProcessLookupError:
                    pass
                reap_started = True
                process.wait(timeout=5)
            raise


def compare(profile, before, after):
    for key in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'runner_policy',
                'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases'):
        require(before[key] == after[key], f'{profile}: report contract drift in {key}')
    old = unique(before['cases'], lambda item: item['id'])
    new = unique(after['cases'], lambda item: item['id'])
    require(old.keys() == new.keys(), f'{profile}: report case inventory differs')
    require(list(old) == list(new), f'{profile}: report case order differs')
    changes = []
    for name, current in new.items():
        prior = old[name]
        require(all(prior.get(key) == current.get(key) for key in IDENTITY), f'{profile}/{name}: identity drift')
        a, b = observation(prior), observation(current)
        if a != b:
            kind = ('regression' if a['status'] == 'passed' and b['status'] != 'passed' else
                    'improvement' if a['status'] != 'passed' and b['status'] == 'passed' else 'other')
            changes.append(dict(id=name, kind=kind, before=a, candidate=b))
    require(dict(Counter(item['status'] for item in after['cases'])) == after['counts'], f'{profile}: counts differ')
    old_controls = unique(before['harness_preflight'], lambda item: (item['name'], item['result']['mode']))
    new_controls = unique(after['harness_preflight'], lambda item: (item['name'], item['result']['mode']))
    require(list(old_controls) == list(new_controls), f'{profile}: control inventory/order differs')
    control_changes = []
    for key, current in new_controls.items():
        prior = old_controls[key]
        require(prior['expected'] == current['expected'], f'{profile}/{key}: expected control result drift')
        require(all(prior['result'].get(field) == current['result'].get(field) for field in IDENTITY),
                f'{profile}/{key}: control identity drift')
        if prior != current:
            control_changes.append(dict(name=key[0], mode=key[1], before=prior, candidate=current))
    return changes, control_changes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true', help='run only after root authorizes the frozen replay')
    parser.add_argument('--candidate-directory', type=Path, help='root-supplied frozen candidate directory')
    parser.add_argument('--expected-input-sha256', help='required when selecting a different frozen candidate')
    args = parser.parse_args()
    require(sha(INPUTS) == INPUTS_SHA, 'prepared replay manifest changed')
    frozen = read(INPUTS)
    before_provenance = frozen['before_provenance']
    require(sha(before_provenance['path']) == before_provenance['sha256'], 'published before provenance changed')
    before = read(before_provenance['path'])
    require(before['parent_commit'] == frozen['before_commit'], 'published before commit differs')
    require(before['runtime_source_sha256'] == frozen['before_production_input_sha256'], 'published before input differs')
    require(sha(Path(frozen['before_root']) / 'eris-js') == frozen['before_binary_sha256'], 'published before adapter changed')
    require(sha(frozen['contract']['path']) == frozen['contract']['sha256'], 'historical contract changed')
    require(sha(frozen['baseline_archive']['path']) == frozen['baseline_archive']['sha256'], 'archived baseline payloads changed')
    archived_baselines = read(frozen['baseline_archive']['path'])
    require(archived_baselines['commit'] == frozen['before_commit'], 'baseline commit differs')
    require(set(archived_baselines['baselines']) == set(frozen['baselines']), 'baseline archive inventory differs')
    for name, row in frozen['baselines'].items():
        archived = archived_baselines['baselines'][name]
        require((archived['path'], archived['sha256']) == (row['path'], row['sha256']), 'baseline archive binding differs')
        require(sha(Path(frozen['repository']) / row['path']) == row['sha256'], 'baseline changed before replay')
    if not args.execute:
        print('Prepared only; no adapter execution.', frozen['counts'])
        return 0
    root = Path(frozen['repository'])
    require(args.candidate_directory is not None and args.expected_input_sha256 is not None, 'explicit candidate directory and production-input SHA required')
    out = args.candidate_directory
    expected_input = args.expected_input_sha256
    require(out.is_absolute() and Path('/tmp') in out.resolve().parents, 'candidate output must be a scratch directory')
    require(len(expected_input) == 64 and all(c in '0123456789abcdef' for c in expected_input), 'invalid input SHA')
    require(out.is_dir() and not out.is_symlink(), 'candidate directory missing or aliased')
    require(sha(Path(frozen['contract']['path'])) == frozen['contract']['sha256'], 'historical contract changed')
    contracts = read(frozen['contract']['path'])['profiles']
    for relative, digest in frozen['tooling'].items():
        require(sha(root / relative) == digest, f'tooling changed before import: {relative}')
    sys.path.insert(0, str(root / 'tools'))
    import test262_conformance as runner
    require(runner.ROOT == root, 'runner root mismatch')
    require(set(runner.PROFILES) == set(contracts) | set(frozen['excluded_new_profiles']), 'profile inventory drift')
    binary_manifest = out / 'default-binaries.json'
    binaries = read(binary_manifest)
    binary = out / 'eris-js'
    require(binary.is_file() and not binary.is_symlink(), 'candidate adapter is missing or aliased')
    expected_binary = binaries['eris-js']
    require(sha(binary) == expected_binary, 'candidate adapter hash mismatch')
    inputs = out / 'inputs.json'
    require(read(inputs)['input_sha256'] == expected_input, 'candidate input digest differs')
    destinations = [out / ('profile-' + item['name'] + suffix)
                    for item in frozen['profiles'] for suffix in ('.json', '.log')]
    destinations += [out / name for name in ('historical-replay-start.json', 'baselines-before.json', 'profiles-comparison.json')]
    require(not any(path.exists() or path.is_symlink() for path in destinations), 'refusing to overwrite replay evidence')

    def check_locks():
        require(sha(INPUTS) == INPUTS_SHA, 'prepared replay manifest changed during replay')
        require(sha(frozen['contract']['path']) == frozen['contract']['sha256'], 'historical contracts changed during replay')
        require(sha(frozen['baseline_archive']['path']) == frozen['baseline_archive']['sha256'], 'archived baseline bytes changed during replay')
        for prior in frozen['profiles']:
            require(sha(prior['before_report']) == prior['before_report_sha256'], 'before observation changed: ' + prior['name'])
        require(sha(before_provenance['path']) == before_provenance['sha256'], 'before provenance changed during replay')
        require(sha(Path(frozen['before_root']) / 'eris-js') == frozen['before_binary_sha256'], 'before adapter changed during replay')
        for relative, digest in frozen['tooling'].items():
            require(sha(root / relative) == digest, f'tooling changed: {relative}')
        for record in frozen['baselines'].values():
            require(sha(root / record['path']) == record['sha256'], f'baseline changed: {record["path"]}')
        require(sha(binary) == expected_binary, 'adapter changed during replay')
        import benchmark
        require(benchmark.input_digest() == expected_input, 'live production inputs changed during replay')
        require(sha(binary_manifest) == manifest_digest and sha(inputs) == inputs_digest,
                'candidate provenance changed during replay')

    manifest_digest, inputs_digest = sha(binary_manifest), sha(inputs)
    check_locks()
    write_new(out / 'baselines-before.json', frozen['baselines'])
    write_new(out / 'historical-replay-start.json', dict(
        replay_script=str(Path(__file__).resolve()), replay_script_sha256=sha(__file__),
        prepared_manifest=str(INPUTS), prepared_manifest_sha256=INPUTS_SHA,
        binary=str(binary), binary_sha256=expected_binary, default_binaries_sha256=manifest_digest,
        production_inputs_sha256=inputs_digest, production_input_digest=expected_input,
        before_commit=frozen['before_commit'], before_provenance_sha256=before_provenance['sha256'],
        counts=frozen['counts'], timeout_seconds_per_profile=PROFILE_SECONDS, adapter_timeout_seconds=3,
        jobs_per_profile=4, environment={key: os.environ.get(key) for key in ('TZ', 'TZDIR', 'LANG', 'LC_ALL', 'LC_TIME')}))
    def interrupted(signum, frame):
        raise KeyboardInterrupt('signal ' + str(signum))
    for sig in (signal.SIGINT, signal.SIGTERM):
        signal.signal(sig, interrupted)
    started, results, failure = time.monotonic(), [], None
    try:
        for item in frozen['profiles']:
            profile = item['name']
            prior_path = Path(item['before_report'])
            require(sha(prior_path) == item['before_report_sha256'], f'{profile}: before report changed')
            before = read(prior_path)
            require(before['binary_sha256'] == frozen['before_binary_sha256'], f'{profile}: before binary mismatch')
            check_locks()
            verify_static_contract(runner, root, profile, contracts[profile], before)
            dest, log = out / ('profile-' + profile + '.json'), out / ('profile-' + profile + '.log')
            command = [sys.executable, str(root / 'tools/test262_conformance.py'), '--profile', profile,
                       '--binary', str(binary), '--output', str(dest), '--jobs', '4', '--timeout', '3']
            baseline = frozen['baselines'].get(profile)
            if baseline:
                command += ['--baseline', str(root / baseline['path'])]
            exit_code = run_profile(command, root, log)
            require(exit_code in (0, 1), f'{profile}: infrastructure exit {exit_code}; see {log}')
            after = read(dest)
            require(after['binary_sha256'] == expected_binary, f'{profile}: candidate report binary mismatch')
            changes, control_changes = compare(profile, before, after)
            check_locks()
            verify_static_contract(runner, root, profile, contracts[profile], before)
            row = dict(profile=profile, before_report_sha256=item['before_report_sha256'],
                       report_path=str(dest), report_sha256=sha(dest), log_path=str(log), log_sha256=sha(log),
                       exit_code=exit_code, counts=after['counts'], cases=len(after['cases']),
                       controls=len(after['harness_preflight']), controls_verified=sum(c['verified'] for c in after['harness_preflight']),
                       baseline=baseline, baseline_gate_passed=exit_code == 0 if baseline else None,
                       baseline_regressions=after['regressions'], baseline_improvements=after['improvements'],
                       observation_changes=changes, control_changes=control_changes)
            results.append(row)
            print(profile, after['counts'], dict(Counter(c['kind'] for c in changes)),
                  'control_changes', len(control_changes), 'baseline_gate', row['baseline_gate_passed'], flush=True)
    except BaseException as error:
        failure = dict(type=type(error).__name__, message=str(error))
    totals = Counter(c['kind'] for row in results for c in row['observation_changes'])
    record = dict(complete=failure is None and len(results) == len(frozen['profiles']), infrastructure_failure=failure,
                  binary=str(binary), binary_sha256=expected_binary, before_binary_sha256=frozen['before_binary_sha256'],
                  production_input_sha256=expected_input, prepared_manifest_sha256=INPUTS_SHA,
                  before_commit=frozen['before_commit'], before_provenance_sha256=before_provenance['sha256'],
                  replay_script_sha256=sha(__file__), profiles=results, baselines_modified_by_replay=False,
                  baseline_hashes_unchanged=all((root / b['path']).is_file() and sha(root / b['path']) == b['sha256']
                                                for b in frozen['baselines'].values()),
                  counts=dict(profiles=len(results), cases=sum(r['cases'] for r in results),
                              controls=sum(r['controls'] for r in results), control_changes=sum(len(r['control_changes']) for r in results),
                              improvements=totals['improvement'], regressions=totals['regression'], other_changes=totals['other'],
                              existing_baseline_gates_passed=sum(r['baseline_gate_passed'] is True for r in results)),
                  elapsed_seconds=time.monotonic() - started)
    write_new(out / 'profiles-comparison.json', record)
    print('TOTAL', record['counts'], 'complete', record['complete'], flush=True)
    return 2 if failure else int(totals['regression'] > 0 or any(r['baseline_gate_passed'] is False for r in results)
                                or record['counts']['control_changes'] > 0)


if __name__ == '__main__':
    raise SystemExit(main())
