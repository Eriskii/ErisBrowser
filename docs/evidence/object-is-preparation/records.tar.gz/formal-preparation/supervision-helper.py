#!/usr/bin/env python3
"""One authorized immutable ArrayBuffer BEFORE replay; default is inert verification."""
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import signal
import subprocess
import sys
import time

ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BEFORE=Path('/tmp/eris-array-buffer-before')
OUT=Path('/tmp/eris-array-buffer-formal-before')
FREEZE=Path('/tmp/eris-array-buffer-formal-freeze.json')
FREEZE_SHA='dca40ca0966bdb42473ef8f4cb83dd11b14c1a31d1e598481167a03587653b72'
BINARY_SHA='64667259eff3ccec0c2ef98370a60a1dea71560def07574dc59db1bbb3fff3c0'
CI_SHA='6c008ff3efed175d6a8119ec0a40529c12c8a6c28a00ef069fc1ee76ad7eadb6'
DEADLINE_SECONDS=600

def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def canonical(value):return hashlib.sha256(json.dumps(value,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def save(name,value):(OUT/name).write_text(json.dumps(value,sort_keys=True,indent=2)+'\n')

def verify():
    assert sha(FREEZE)==FREEZE_SHA
    freeze=json.loads(FREEZE.read_bytes())
    assert len(freeze['files'])==freeze['file_count']==273
    assert canonical(freeze['files'])==freeze['file_ledger_sha256']
    for entry in freeze['files']:
        path=ROOT/entry['path'];assert path.stat().st_size==entry['bytes'] and sha(path)==entry['sha256'],str(path)
    for path,expected in [(freeze['new_contract_path'],freeze['new_contract_sha256']),
                          (freeze['frozen_upstream'],freeze['frozen_upstream_sha256']),
                          (freeze['independent_control_source'],freeze['independent_control_sha256']),
                          (freeze['verification_log'],freeze['verification_log_sha256']),
                          (freeze['old_contracts']['path'],freeze['old_contracts']['sha256'])]:
        assert sha(path)==expected,path
    for row in freeze['reviews']:assert sha(row['path'])==row['sha256']
    contracts=json.loads(Path(freeze['new_contract_path']).read_bytes())
    assert contracts['counts']==dict(profiles=1,cases=442,preflights=160)
    provenance=json.loads((BEFORE/'provenance.json').read_bytes())
    assert provenance['parent_commit']=='77866e93f4d8486807aa843667619ea4ccccccfa'
    assert provenance['runtime_source_sha256']=='b5204aa57dbbfbadedacfca614746cb1ad3b643da7156a81769ff0063d4f32f9'
    inputs=json.loads((BEFORE/'inputs.json').read_bytes())
    assert inputs['input_sha256']==provenance['runtime_source_sha256'] and len(inputs['files'])==104
    for row in inputs['files']:assert sha(ROOT/row['path'])==row['sha256'],row['path']
    assert sha(BEFORE/'eris-js')==provenance['binary_sha256']==BINARY_SHA
    assert sha(BEFORE/'parent-ci-final.json')==CI_SHA
    ci=json.loads((BEFORE/'parent-ci-final.json').read_bytes())
    assert ci['headSha']==provenance['parent_commit'] and ci['conclusion']=='success'
    assert len(ci['jobs'])==7 and all(j['conclusion']=='success' for j in ci['jobs'])
    baseline=json.loads(Path('/tmp/eris-array-buffer-baselines-before.json').read_bytes())
    assert len(baseline['baselines'])==33
    for row in baseline['baselines'].values():assert sha(ROOT/row['path'])==row['sha256'],row['path']
    return freeze,contracts['profiles']['array-buffer'],dict(commit=provenance['parent_commit'],production_input_sha256=provenance['runtime_source_sha256'],files={p.name:sha(p) for p in BEFORE.iterdir() if p.is_file()})

def limits():
    resource.setrlimit(resource.RLIMIT_AS,(1024**3,1024**3))
    resource.setrlimit(resource.RLIMIT_CPU,(300,300))
    resource.setrlimit(resource.RLIMIT_FSIZE,(32*1024**2,32*1024**2))

def kill_then_reap(process, ownership):
    # The caller never polls/reaps first: the retained leader prevents PID/PGID reuse.
    try:os.killpg(process.pid,signal.SIGKILL)
    except ProcessLookupError:pass
    # A wait interrupted after waitpid may already have reaped the leader.
    # Mark the phase before entering it so error cleanup never signals this PID again.
    ownership['reap_started']=True
    return process.wait(timeout=5)

def wait_unreaped(process, ownership):
    deadline=time.monotonic()+DEADLINE_SECONDS
    while True:
        result=os.waitid(os.P_PID,process.pid,os.WEXITED|os.WNOHANG|os.WNOWAIT)
        if result is not None:
            observed=dict(si_pid=result.si_pid,si_code=result.si_code,si_status=result.si_status)
            return kill_then_reap(process, ownership),observed
        remaining=deadline-time.monotonic()
        if remaining<=0:raise subprocess.TimeoutExpired(process.args,DEADLINE_SECONDS)
        time.sleep(min(0.05,remaining))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute-authorized',action='store_true')
    args=parser.parse_args()
    freeze,contract,provenance=verify()
    if not args.execute_authorized:
        print('INERT VERIFIED: 273 formal input files, contracts/controls, preserved browser bundle, adapter and seven-job CI; no adapter execution.')
        return
    OUT.mkdir(exist_ok=False)
    sys.path.insert(0,str(ROOT/'tools'))
    from run import launch_environment
    env=launch_environment();env['PYTHONDONTWRITEBYTECODE']='1'
    report=OUT/'array-buffer.json'
    command=[sys.executable,str(ROOT/'tools/test262_conformance.py'),'--binary',str(BEFORE/'eris-js'),
             '--profile','array-buffer','--output',str(report),'--jobs','4','--timeout','3']
    record=dict(format=1,phase='single formal ArrayBuffer BEFORE execution',started_utc=utc(),
        driver_sha256=sha(__file__),command=command,cwd=str(ROOT),formal_freeze_sha256=FREEZE_SHA,
        binary_sha256=BINARY_SHA,before_commit=provenance['commit'],before_input_sha256=provenance['production_input_sha256'],
        input_files={str(p):sha(p) for p in [Path(__file__),Path('/tmp/eris-array-buffer-formal-before-driver-preparation.json'),
            BEFORE/'eris-js',BEFORE/'provenance.json',BEFORE/'inputs.json',
            Path('/tmp/eris-array-buffer-baselines-before.json'),BEFORE/'parent-ci-final.json',FREEZE,Path(freeze['new_contract_path']),
            ROOT/'tools/import_test262.py',ROOT/'tools/test262_conformance.py',ROOT/'tools/html_conformance.py',ROOT/'tools/run.py']},
        formal_files_verified=273,before_files_verified=len(provenance['files']),
        environment={k:env.get(k) for k in ['TZ','LANG','LC_ALL','LC_TIME','LD_LIBRARY_PATH']},
        local_timezone=time.tzname,local_offset_seconds=time.timezone,
        limits=dict(case_timeout_seconds=3,jobs=4,profile_deadline_seconds=DEADLINE_SECONDS,
            process_address_space_bytes=1024**3,process_cpu_seconds=300,per_output_file_bytes=32*1024**2,
            adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024,reap_deadline_seconds=5),
        cleanup='waitid NOWAIT observes leader; process-group SIGKILL before first reaping wait on normal completion, timeout or error.',
        retries=False,baseline_written=False,normalization=False)
    save('pre-execution.json',record)
    started=time.monotonic();process=None;reaped=False;ownership={'reap_started':False}
    try:
        with (OUT/'stdout.log').open('xb') as stdout,(OUT/'stderr.log').open('xb') as stderr:
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,
                close_fds=True,start_new_session=True,preexec_fn=limits)
            record['process_pid']=process.pid
            code,observed=wait_unreaped(process,ownership);reaped=True
        record.update(returncode=code,exit_observed_without_reaping=observed,leader_reaped=True,
            process_group_cleanup_before_reap=True,elapsed_seconds=round(time.monotonic()-started,3))
        result=json.loads(report.read_bytes())
        assert result['binary_sha256']==BINARY_SHA
        assert result['corpus_manifest_sha256']==contract['manifest_sha256']
        assert result['runner_policy_sha256']==contract['runner_policy_sha256']
        assert len(result['cases'])==len(contract['cases'])==442
        assert {x['id'] for x in result['cases']}==contract['cases'].keys()
        for case in result['cases']:
            old=contract['cases'][case['id']]
            for key in ('case_sha256','source_sha256','file','mode'):assert case[key]==old[key],(case['id'],key)
            assert case['expected_negative']==old['metadata']['negative']
            if old['unsupported_reason']:
                assert case['status']=='unsupported' and case['reason']==old['unsupported_reason']
        assert len(result['harness_preflight'])==len(contract['preflights'])==160
        for actual,old in zip(result['harness_preflight'],contract['preflights']):
            assert actual['name']==old['name'] and actual['expected']==old['expected']
            for key in ('case_sha256','source_sha256','mode'):assert actual['result'][key]==old[key]
        record.update(report_sha256=sha(report),counts=result['counts'],controls=160,
            controls_verified=sum(c['verified'] for c in result['harness_preflight']),control_health=result['harness_preflight_passed'],
            control_raw_statuses=dict(collections.Counter(c['result']['status'] for c in result['harness_preflight'])),
            exact_case_control_and_exclusion_contracts=True)
        verify()
        for name,expected in record['input_files'].items():assert sha(name)==expected,name
        record['all_inputs_unchanged_after_execution']=True
    except BaseException as error:
        record['failure']=dict(type=type(error).__name__,message=str(error))
        if process is not None and not reaped:
            try:
                record['cleanup_returncode']=(process.wait(timeout=5) if ownership['reap_started']
                                               else kill_then_reap(process,ownership));reaped=True
            except BaseException as cleanup:
                record['cleanup_failure']=dict(type=type(cleanup).__name__,message=str(cleanup))
        raise
    finally:
        record['leader_reaped']=reaped
        record['ended_utc']=utc()
        record['captured_files']={p.name:dict(bytes=p.stat().st_size,sha256=sha(p))
            for p in (OUT/'stdout.log',OUT/'stderr.log',report) if p.exists()}
        save('execution.json',record)
    print('cases',record['counts'],'controls',record['controls_verified'],'/ 160',flush=True)
    print('execution_sha256',sha(OUT/'execution.json'),flush=True)

    return code

if __name__=='__main__':sys.exit(main())
