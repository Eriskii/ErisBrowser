from pathlib import Path
import json
R=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
P=Path('/tmp/eris-object-is-preparation-1')
p=R/'tools/import_test262.py';s=p.read_text()
for old,new in [
 ("ARRAY_FIND_DIRECTORIES =", "OBJECT_IS_DIRECTORIES = {'Object/is': 21}\nARRAY_FIND_DIRECTORIES ="),
 ("ITERATION_SUBTREES = {\n", "ITERATION_SUBTREES = {\n    'object-is': {'Object/is': '04a0f3e25947dbc1100ba4b4138765366d9704b4'},\n"),
 ("ITERATION_HELPERS = {\n", "ITERATION_HELPERS = {\n    'object-is': {'assert.js', 'sta.js', 'propertyHelper.js', 'isConstructor.js'},\n"),
 ("TREE_PROFILES = {'data-view'", "TREE_PROFILES = {'object-is', 'data-view'"),
 ("PROFILES = {'data-view'", "PROFILES = {'object-is': OBJECT_IS_DIRECTORIES, 'data-view'"),
 ("PROFILE_ROOTS = {'data-view'", "PROFILE_ROOTS = {'object-is': 'test/built-ins', 'data-view'"),
 ("    scope = {\n", "    scope = {\n        'object-is': 'all .js files in the complete recursive built-ins/Object/is subtree; original root-linked Git proofs; no implementation',\n"),
]:
 assert s.count(old)==1,(p,old,s.count(old));s=s.replace(old,new)
p.write_text(s)
p=R/'tools/test262_conformance.py';s=p.read_text()
for old,new in [
 ("OBJECT_INTEGRITY_FEATURES = CONSTRUCTION_FEATURES | REGEXP_FEATURES", "OBJECT_INTEGRITY_FEATURES = CONSTRUCTION_FEATURES | REGEXP_FEATURES\nOBJECT_IS_FEATURES = OBJECT_INTEGRITY_FEATURES | {'Object.is'}"),
 ("PROFILE_FEATURES = {'data-view'", "PROFILE_FEATURES = {'object-is': OBJECT_IS_FEATURES, 'data-view'"),
 ("    if profile == 'data-view':\n        variants += data_view_preflight_variants()", "    if profile == 'data-view':\n        variants += data_view_preflight_variants()\n    if profile == 'object-is':\n        variants += object_is_preflight_variants()"),
]:
 assert s.count(old)==1,(p,old,s.count(old));s=s.replace(old,new)
# The first two sets authenticate root-linked auxiliary bytes. Keep old gating unchanged.
s=s.replace("if profile in {'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:","if profile in {'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'date', 'for-of', 'core-iterators'}:",1)
s=s.replace("if profile in {'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys()", "if profile in {'object-is', 'data-view', 'array-buffer', 'array-concat', 'array-splice', 'array-from', 'for-of', 'core-iterators'} and files.keys()",1)
draft=json.loads((P/'local-oracle-draft-2.json').read_text())
guard="assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);\n"
lines=['def object_is_preflight_variants():', '    """Exact independent Object.is pairs; original positive/wrong IDs are retained."""', '    guard = '+repr(guard), '    pairs = [']
controls=draft['feature_controls']
for good,bad in zip(controls[::2],controls[1::2]):
 assert good['variant']=='positive' and bad['variant']=='wrong' and good['pair']==bad['pair']
 prefix,check=good['source'].rsplit('assert.sameValue(',1)
 prefix2,check2=bad['source'].rsplit('assert.sameValue(',1)
 actual,value=check[:-2].rsplit(',',1);actual2,value2=check2[:-2].rsplit(',',1)
 assert prefix==prefix2 and actual==actual2 and prefix.startswith(guard) and prefix.endswith('\n')
 setup=prefix[len(guard):-1]
 assert guard+setup+'\n'+f'assert.sameValue({actual},{value});'==good['source']
 lines.append('        '+repr((good['pair'],setup,actual,value,value2))+',')
lines+=['    ]', "    return [('object-is-' + name + '-' + variant,", "             guard + setup + '\\n' + f'assert.sameValue({actual},{value});', expected, mode)", "            for name, setup, actual, good, bad in pairs", "            for variant, value, expected in (('positive', good, 'passed'), ('wrong', bad, 'failed'))", "            for mode in ('sloppy', 'strict')]", '', '']
needle='def data_view_preflight_variants():'
assert s.count(needle)==1;s=s.replace(needle,'\n'.join(lines)+'\n'+needle)
needle="    if profile == 'identifiers':\n        # Parse-negative observations"
gating="""    if profile == 'object-is':
        # Preserve the independently authored positive/wrong names and require
        # the positive source to succeed in the same mode before verifying it.
        positives = {(item['name'], item['result']['mode']): item for item in outcomes
                     if item['name'].startswith('object-is-') and item['expected'] == 'passed'}
        for item in outcomes:
            if item['name'].startswith('object-is-') and item['name'].endswith('-wrong'):
                partner = positives[(item['name'].removesuffix('-wrong') + '-positive',
                                     item['result']['mode'])]
                result = partner['result']
                item['prerequisite'] = dict(name=partner['name'], mode=result['mode'],
                    case_sha256=result['case_sha256'], source_sha256=result['source_sha256'],
                    expected=partner['expected'], verified=partner['verified'])
                item['verified'] = item['verified'] and partner['verified']
"""
assert s.count(needle)==1;s=s.replace(needle,gating+needle);p.write_text(s)
# Preserve historical snapshots by excluding only the newly added profile.
changed=[]
for p in sorted((R/'tools').glob('test_test262_*.py')):
 s=p.read_text();t=s.replace("{'data-view',", "{'object-is', 'data-view',")
 t=t.replace("capture_contracts(excluded={PROFILE})", "capture_contracts(excluded={'object-is', PROFILE})")
 t=t.replace("excluded=(*PROFILES, 'data-view',", "excluded=(*PROFILES, 'object-is', 'data-view',")
 if t!=s:p.write_text(t);changed.append(str(p.relative_to(R)))
(P/'tooling/historical-test-exclusion-edits.json').write_text(json.dumps({'added_exclusion':'object-is','files':changed,'unchanged':'All old expected counts and hashes'},indent=2)+'\n')
print('Updated importer/runner and',len(changed),'historical exclusion sets')
