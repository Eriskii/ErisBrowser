"""Capture static contracts only; all adapter/process creation is forbidden."""
import hashlib,json,sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');BASE=Path('/tmp/eris-object-is-preparation-1')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
from test_test262_object_integrity import capture_contracts,canonical

def row(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
with patch('subprocess.Popen',side_effect=AssertionError('no engine or child process')):
 current=capture_contracts(excluded={'object-is'})
 previous=(BASE/'historical-freeze/contracts.json').read_bytes()
 assert canonical(current)==previous,'historical contracts changed'
 new=capture_contracts(excluded=set(runner.PROFILES)-{'object-is'})
profile=new['profiles']['object-is']
draft=json.loads((BASE/'local-oracle-draft-2.json').read_bytes())
expected=[(r['id'],mode,r['source'], {'pass':'passed','Test262Error':'failed'}[r['expectation']]) for r in draft['feature_controls'] for mode in r['modes']]
actual=[(r['name'],r['mode'],r['source'],r['expected']) for r in profile['preflights'][32:]]
assert actual==expected,'reviewed feature bytes/IDs/modes changed'
admission=json.loads((BASE/'admission.json').read_bytes())
assert profile['policy']['supported_features']==admission['policy']
for item in admission['rows']:
 c=next(r for r in profile['cases'].values() if r['file']==item['path'] and r['mode']==item['mode'])
 assert c['source_sha256']==item['source_sha256'] and c['unsupported_reason'] is None
 assert c['harness']==[{k:r[k] for k in ('name','sha256')} for r in item['helper_order']]
freeze=json.loads((BASE/'historical-freeze/freeze.json').read_bytes())
for binding in freeze['baselines'].values(): assert row(Path(binding['path']))==binding
contract_path=BASE/'tooling/new-profile-contract.json';contract_path.write_bytes(canonical(new))
_,files,cases,_,manifest_sha=runner.load_corpus(ROOT/'tests/upstream/test262-object-is','object-is')
summary=dict(schema=1,counts=new['counts'],historical_counts=current['counts'],historical_contracts_unchanged=True,
 historical_contract_sha256=hashlib.sha256(previous).hexdigest(),baseline_hashes_unchanged=len(freeze['baselines']),
 contract=row(contract_path),manifest_sha256=manifest_sha,
 case_identity_sha256=runner.digest(canonical([(c['id'],c['case_sha256']) for c in cases])),
 feature_identity_sha256=runner.digest(canonical([(r['name'],r['mode'],r['source_sha256'],r['expected']) for r in profile['preflights'][32:]])),
 reviewed_controls_exact=True,reviewed_policy_and_admission_exact=True,adapter_executions=0,
 tools=[row(ROOT/'tools'/n) for n in ['import_test262.py','test262_conformance.py']])
p=BASE/'tooling/static-contract-check.json';p.write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
