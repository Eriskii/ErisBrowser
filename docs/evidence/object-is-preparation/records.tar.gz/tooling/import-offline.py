"""Run the official importer against only the authenticated scratch bytes."""
import hashlib
import json
import sys
from pathlib import Path
from unittest.mock import patch
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE=Path('/tmp/eris-object-is-preparation-1')
sys.path.insert(0,str(ROOT/'tools'))
import import_test262 as importer
import test262_conformance as runner

def row(path):
 raw=path.read_bytes();return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
inventory=json.loads((BASE/'inventory.json').read_bytes())
assert row(BASE/'inventory.json')['sha256']=='a61e6589fa754beca3782f7173e60ce3d11706265cdbe9059d1d54fd77da19db'
allowed={}
for entry in inventory['sources']+inventory['auxiliary']+inventory['proof_files']:
 raw=(BASE/entry['path']).read_bytes()
 assert len(raw)==entry['bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256']
 allowed[entry['path']]=raw
api=f'https://api.github.com/repos/{importer.REPOSITORY}/git/'
raw_prefix=f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
requests=[]
def fetch(url):
 if url.startswith(api): key=importer.tree_proof_path(url[len(api):])
 elif url.startswith(raw_prefix): key=url[len(raw_prefix):]
 else:raise AssertionError('unbound importer URL '+url)
 assert key in allowed,key
 raw=allowed[key];requests.append(dict(url=url,path=key,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
 return raw
output=ROOT/'tests/upstream/test262-object-is'
assert not output.exists(),'fresh import required'
with patch.object(importer,'fetch',side_effect=fetch),patch('urllib.request.urlopen',side_effect=AssertionError('network forbidden')):
 importer.import_corpus(output,'object-is')
 manifest,files,cases,fixtures,digest=runner.load_corpus(output,'object-is')
assert len(cases)==42 and not fixtures and all(runner.unsupported_reason(c,runner.OBJECT_IS_FEATURES) is None for c in cases)
assert set(files)==set(allowed)-{k for k in allowed if k.startswith('inventory-proof/')}
for key,raw in files.items():assert raw==allowed[key]
receipt=dict(schema=1,method='Official import_corpus with closed authenticated byte lookup; network denied; no engine',
 inventory=row(BASE/'inventory.json'),importer=row(ROOT/'tools/import_test262.py'),runner=row(ROOT/'tools/test262_conformance.py'),
 reviewed_oracle=row(BASE/'local-oracle-draft-2.json'),manifest=row(output/'manifest.json'),
 counts=dict(sources=manifest['test_files'],modes=len(cases),helpers=4,admitted=42,excluded=0),
 request_bindings=sorted(requests,key=lambda x:x['url']),output_files=[row(p) for p in sorted(output.rglob('*')) if p.is_file()],
 source_and_auxiliary_bytes_exact=True,compiler_executions=0,engine_executions=0)
target=BASE/'tooling/import-receipt.json';target.write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(row(target)))
