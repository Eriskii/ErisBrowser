# Selected one-function Object.is installer

Root selected the existing `intrinsic_function("Object.is", "is", 2)` path, wrapped by one scoped installer. This supersedes the alternative-installation paragraph in the initial proposal. Do not generalize DataView or change its implementation, ArrayBuffer, global equality, quotas, or old tests. No code has been edited or executed for this plan.

Place the new one-time call immediately after the existing ArrayBuffer/DataView installation sequence. Its inputs are literal `Object`, `Object.is`, `is`, `name`, `length`; its counts come from the live registry/prototype/owner maps at that point. The global Object constructor and function prototype already exist. An author callback cannot run during initialization.

## Reached operation ledger

Use the reviewed pinned B=6 `tree_bound(n) = (C(n), H(n))` already present in ArrayBuffer/DataView. Let `S(n,k) = C(n) * (1 + k/8)`, where k is query bytes for the ASCII registry/prototype strings and UTF-16 units for property keys. All additions/multiplications must be checked or saturating into terminal refusal as appropriate; no hardcoded current registry size or desired remaining budget.

1. Before indexing `native_properties["Object"]`, charge `S(R,6)`. This constructor-owner lookup is separate from the two method-registry traversals below.
2. Read the owner's property count O and creation-order length/capacity, and the prototype-map count P from metadata. Charge the remaining admission before invoking `intrinsic_function` or publishing any property.
3. `intrinsic_function` does two method-registry searches when the literal method is fresh: `contains_key("Object.is")` and `insert("Object.is", id)`. Charge `2*S(R,9)` plus `28*(H(R)+1)` insertion work.
4. `object_ordered` looks up `prototypes["Object"]` when creating the ordinary function property bag. Charge `S(P,6)`.
5. The fresh property bag inserts `name` then `length` through `ScriptObject::insert`: each insert does contains+insert. Charge `2*S(0,4) + 2*S(1,6)`. The two attribute rewrites each search the completed two-key bag, charging `S(2,4)+S(2,6)`.
6. The fresh two-key bag never splits: charge three fixed key/value entry moves (first insertion, second insertion and shifted first entry), four initial leaf/root header operations, two order-handle appends and six descriptor flag assignments. This is a total of 15 fixed logical units in addition to those searches.
7. Installing Object's `is` property through `insert_hidden` does contains+insert: charge `2*S(O,2)` plus `28*(H(O)+1)` and one order-handle append. The owner property remains writable/configurable and nonenumerable.
8. Add a fixed 64-unit bounded construction allowance for the static key/name UTF-16 and native/registry string construction, tiny fixed records, Rc handles and ordinary property-bag setup. The fresh bag searches, movements and attribute assignments above are separate; they are not hidden inside this fixed allowance.

Thus, apart from the separately charged owner-order reserve, the total proposed work is:

`S(R,6) + 64 + 2*S(R,9) + 28*(H(R)+1) + S(P,6) + 2*S(0,4) + 2*S(1,6) + S(2,4) + S(2,6) + 15 + 2*S(O,2) + 28*(H(O)+1) + 1`.

The `28` remains **24 fixed-size entry/edge movement units plus four setup units per possible level**. It is not 28 byte copies, machine instructions or measured processor cycles. The already reviewed split bound is at most12 fixed entry moves and12 logical edge/backlink updates per reached level, with a possible new root. Existing-tree insertions do not borrow fresh-tree amortized credit.

## Storage and reserve order

Keep the existing `intrinsic_function` and `object_ordered` charges unchanged. In particular the ordinary object base remains `72 + size_of::<Option<AbortSlot>>() + size_of::<Option<f64>>()`, and the two ordinary property charges remain 552 bytes in total. They are already charged inside the generic allocator; do not remove them or add a second outside copy merely to conceal a ledger error.

Before entering that generic helper, charge:

- `1536 + 8*(9+2)` bytes for bounded native/registry/display/owner-key handles and payloads. This retained conservative allowance includes both temporary UTF-16 keys created by the two attribute rewrites, the Native record/Rc header, both method-name allocations, display string and static owner key. The sizes are fixed by the literal inputs; this is not a general arbitrary-string allocator formula.
- One complete fresh property-map leaf allowance `N<PropertyKey, Property>` for the two-key function bag.
- **Four** `PropertyKey` slots for the fresh function bag's implicit Vec allocation. The generic path pushes into an empty Vec and does not reserve two slots first. For the pinned Rust1.88/1.98 RawVec growth rule, PropertyKey's size is >1 and <=1024, so the minimum nonzero capacity is4. Include a private assertion of this size/growth premise; do not mistake length2 for capacity2.
- `(H(R)+1) * N<String, usize>` for the already populated registry's possible split chain.
- `(H(O)+1) * N<PropertyKey, Property>` for the already populated Object property map's possible split chain.

Use the existing reviewed conservative actual-type node allowance:

`N<K,V> = 16*(size_of::<K>() + size_of::<V>()) + 32*size_of::<usize>() + 64`.

Owner order: when `len == capacity`, compute checked `required=len+1` and `requested=max(4, 2*capacity, required)`. Prepay the **entire** requested new order buffer (`requested * size_of::<PropertyKey>()`), plus `1 + 2*len` logical reserve/old-handle movement units, before `try_reserve_exact(required_additional)`. To request the intended capacity from Vec, the additional argument is `requested - len`. On spare capacity, only the later one-unit append debit is needed. Reserve before creating the method or touching map entries; no old allocation refund. The actual allocator may grant more capacity than requested, so record logical requested bytes separately from allocator overhead.

After successful admission/reserve, call the unchanged generic helper and then `insert_hidden` on the already known owner. All underlying populated B-tree insertions and the fresh bag Vec push remain infallible Rust allocation boundaries; prepaid logical heap does not transform them into recoverable allocators. Owner reserve is explicitly fallible. Every logical map/order mutation follows its admission.

The selected generic path has two searches per fresh target map. Do not add an uncharged duplicate precheck. Installation is a one-time bootstrap operation with literal absence established by the source integration; the existing generic helper's behavior for an already registered name is unchanged. If root later asks for an explicit duplicate error, that is an extra searched branch and must be separately counted/reviewed.

## Meaningful checks once root authorizes implementation

Keep old maximum-string tests and limits exact. Add scoped tests that prepare a fresh installer state, measure complete work/heap, and exercise exact/one-short admission, preserving visible map/order entries on failure. Test reached owner-order growth independently from spare capacity. Assert name/length flags, absence of own prototype, owner flags and constructor identity; verify the fresh generic function bag has at least the four prepaid order slots under the pinned toolchains. Include tree-bound change points and independent formula checks for actual key/value sizes.

Record actual Runtime::new remaining work/heap, registry count and owner order capacity after installation; neither the implementation nor tests should target a chosen headroom number. The source arithmetic is the charge model. Compiler/private/full checks and unchanged historical replays will supply observations only after a new root freeze.
