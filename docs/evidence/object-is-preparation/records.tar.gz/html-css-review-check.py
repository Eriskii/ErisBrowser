"""Data-only independent Object.is draft review; never imports or runs a JS engine."""
import hashlib
import json
import re
from collections import Counter
from pathlib import Path

BASE = Path('/tmp/eris-object-is-preparation-1')
REPO = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def bound(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': sha(raw)}

def read(name):
    return json.loads((BASE / name).read_bytes())

original = read('local-oracle-draft.json')
corrected = read('local-oracle-draft-2.json')
assert bound(BASE / 'local-oracle-draft.json')['sha256'] == '8c4443fcdd426733b398ef39528d93865c9b5699ac6edff21efbdb684cd431e8'
assert bound(BASE / 'local-oracle-draft-2.json')['sha256'] == '5f38d1e5fb5ece6c1c41b73ba540e75f0c4a7c7bbd24e9b903aff6b34c99caa4'
preparation = read('preparation.json')
for row in preparation['files']:
    actual = bound(BASE / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
for row in preparation['inspected_repository_inputs']:
    actual = bound(REPO / row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']
guard = "assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);"
for draft, count in [(original, 37), (corrected, 39)]:
    assert len(draft['cases']) == count and len(draft['feature_controls']) == 24
    assert draft['case_sources'] == count and draft['case_modes'] == count * 2
    assert draft['feature_pairs'] == 12 and draft['feature_control_modes'] == 48
    ids = set()
    for row in draft['cases'] + draft['feature_controls']:
        assert row['id'] not in ids
        ids.add(row['id'])
        assert row['modes'] == ['sloppy', 'strict']
        assert row['sha256'] == sha(row['source'].encode())
        assert row['source'].startswith(guard)
    pairs = {}
    for row in draft['feature_controls']:
        pairs.setdefault(row['pair'], {})[row['variant']] = row
    assert len(pairs) == 12
    for pair in pairs.values():
        assert set(pair) == {'positive', 'wrong'}
        assert pair['positive']['expectation'] == 'pass'
        assert pair['wrong']['expectation'] == 'Test262Error'
old = {row['id']: row for row in original['cases']}
new = {row['id']: row for row in corrected['cases']}
changed = []
for name, row in old.items():
    after = new[name]
    for field in ['id', 'kind', 'requires', 'expectation', 'modes']:
        assert row[field] == after[field], (name, field)
    if row['source'] != after['source']:
        changed.append(name)
assert len(changed) == 7
added = sorted(set(new) - set(old))
assert added == ['dom-defining-interface-querySelector', 'dom-defining-interface-querySelectorAll']
for name in added:
    assert new[name]['expectation'] == 'pass' and new[name]['kind'] == 'ordinary'
    assert "assert.sameValue(Object.is(dm,em),false)" in new[name]['source']
    assert "typeof dm,'function'" in new[name]['source'] and "typeof em,'function'" in new[name]['source']
controls_before = {row['id']: row for row in original['feature_controls']}
control_changes = []
for row in corrected['feature_controls']:
    before = controls_before[row['id']]
    for key in ['pair', 'variant', 'modes', 'expectation']:
        assert before[key] == row[key]
    if before['source'] != row['source']:
        control_changes.append(row['id'])
assert control_changes == ['object-is-native-alias-positive', 'object-is-native-alias-wrong']
utf16_codes = {}
for rows, name in [(original['cases'], 'utf16-code-units-no-normalization'), (original['feature_controls'], 'object-is-utf16-positive')]:
    source = next(row['source'] for row in rows if row['id'] == name)
    index = source.index('uD800')
    codes = [ord(char) for char in source[index-2:index+5]]
    assert codes == [39, 92, 117, 68, 56, 48, 48]
    utf16_codes[name] = codes
for name in ['object-is-utf16-positive', 'object-is-utf16-wrong']:
    assert controls_before[name] == next(row for row in corrected['feature_controls'] if row['id'] == name)
long_lengths = {}
for name, expected in [
    ('long-string-success', [8192, 8192]),
    ('large-extra-values-ignored', [16384]),
    ('terminal-repeated-string-comparison', [4096, 4096]),
    ('terminal-string-budget-not-catchable', [4096, 4096]),
]:
    source = new[name]['source']
    lengths = [len(match) for match in re.findall(r"'(x{32,})'", source)]
    assert lengths == expected and ".join(" not in source
    long_lengths[name] = lengths
    if name.startswith('terminal'):
        assert source.index('assert.sameValue(Object.is(a,b),true)') < source.index('for(var i=0;i<200;i++)Object.is(a,b)')
for name in ['nonconstructability-and-argument-evaluation', 'newtarget-rejected-before-argument-list-read']:
    source = new[name]['source']
    assert source.index('Reflect.construct(Constructed,[]).ok,17') < source.index('assert.throws(TypeError')
for source in [new['native-alias-and-distinct-methods']['source']] + [row['source'] for row in corrected['feature_controls'] if row['pair'] == 'native-alias']:
    assert "typeof parseInt,'function'" in source and "typeof Number.parseInt,'function'" in source

report = {
    'schema': 1,
    'reviewer': 'html_css',
    'status': 'Original draft findings preserved; corrected local draft clear in bounded static review; proposal addendum pending separate review.',
    'method': 'Manual review of every semantic body and control pair against retained official clauses and current runtime source; data-only hashes, counts, original/final delta and literal checks. No JS engine, browser, compiler, importer or conformance runner execution. No repository edits.',
    'bindings': [bound(BASE / name) for name in ['preparation.json', 'proposal.md', 'inventory.json', 'admission.json', 'spec/manifest.json', 'local-oracle-draft.json', 'local-oracle-draft.js', 'prepare-oracle.py', 'local-oracle-draft-2.json', 'local-oracle-draft-2.js', 'prepare-oracle-2.py', 'layout-identity-review.json', 'html-css-review-check.py']] + [bound(REPO / name) for name in ['src/script.rs', 'src/script/array_methods.rs', 'src/script/construction.rs', 'src/script/machine/calls.rs', 'src/js_string.rs']],
    'initial_findings': [
        {'id': 'long-setup-before-comparison', 'cases': list(long_lengths), 'detail': 'new Array(N) contains holes. join walks absent own indices and Array.prototype through charged live Get. At least 16 Array.prototype names imply >=20 map lookup units; each hole costs at least one loop tick + two index-key units + one own edge + one prototype edge + twenty map units, plus separator work after the first hole. Already N=4097 costs at least 4097*25+4096=106521, exceeding MAX_STEPS=100000 before any Object.is call. Ordinary cases could fail incidentally and terminal cases could pass for the wrong reason. Larger setup sizes are worse.', 'resolution': 'Version 2 uses direct ASCII literals, explicit length guards and one successful comparison before each policy loop. No quota or expected result changed.'},
        {'id': 'caught-reflect-incidental-typeerror', 'cases': ['nonconstructability-and-argument-evaluation', 'newtarget-rejected-before-argument-list-read'], 'detail': 'A missing/noncallable Reflect.construct can produce the caught TypeError before constructor/newTarget semantics are reached. The reads===0 assertion alone does not distinguish that.', 'resolution': 'Version 2 first proves a successful Constructed instance with ok=17 and callable Reflect.construct.'},
        {'id': 'native-alias-positive-guard', 'cases': ['native-alias-and-distinct-methods', 'object-is-native-alias-positive', 'object-is-native-alias-wrong'], 'detail': 'Alias equality can be trivially true for two undefined values. Both aliases must be present functions before the positive/wrong pair can certify alias behavior.', 'resolution': 'Version 2 adds both callable guards.'},
    ],
    'reviewer_error_and_retraction': {
        'detail': 'Reviewer initially misread nested JSON escaping as doubled JS backslashes in the UTF-16 control. Direct character-code inspection of the unchanged original proves exactly one U+005C before uD800/uDC00. The finding was retracted promptly to root/script; no oracle correction was required or made.',
        'original_character_codes': utf16_codes,
        'original_and_corrected_utf16_control_bytes_identical': True,
    },
    'corrected_population': {
        'semantic_sources': 39, 'semantic_modes': 78,
        'categories': dict(Counter(row['kind'] for row in corrected['cases'])),
        'feature_pairs': 12, 'feature_control_modes': 48,
        'changed_old_semantic_sources': changed, 'changed_control_sources': control_changes,
        'old_expectations_modes_categories_preserved': True,
        'added_ordinary_sources': added,
        'new_known_host_gaps_are_not_exclusions': True,
        'terminal_string_comparison_lower_bound': 200 * (2 + 4096 // 8 + 4096 // 8),
        'terminal_lower_bound_scope': 'Comparison debit alone under the proposed declared full-length policy; fixed dispatch and ordinary call/loop work are additional. No measured runtime outcome is claimed.',
        'literal_code_unit_lengths': long_lengths,
        'common_controls': 'To be copied unchanged and frozen with the eventual runner; not yet counted here.',
    },
    'semantic_assessment': [
        'Signed zero, NaNs, infinities, subnormals, type lattice, missing arguments, exact UTF-16 and no normalization expectations match retained SameValue clauses.',
        'Ordinary objects, arrays, functions, bound functions, boxed values, symbols and ArrayBuffer/DataView wrappers compare identity without property or conversion hooks; source argument expressions still execute before Object.is and abrupt completion prevents the call.',
        'Object.is receiver and extra operand values are ignored by the comparator; this does not imply that .call/.apply setup or argument evaluation has no cost.',
        'Object.is/name/length descriptors and nonconstructability expectations are coherent. NewTarget rejection precedes reading the arguments-list length, guarded by successful Reflect construction.',
        'Same-interface style methods, stable host wrappers and aliases match the existing represented identity. The two new Document/Element rows correctly require distinct per-interface operation functions and remain ordinary known-gap rows.',
        'Proxy, BigInt and foreign-realm rows remain visible ordinary-success prerequisites; no pass is predicted and no exclusion is invented.',
        'Positive-partner success must gate deliberately wrong feature controls in the future runner; a raw Test262Error before the feature guard must never certify the pair.',
    ],
    'proposal_qualifications': [
        'Layout independently identified that Native derives PartialEq but not Eq: Rc<Native> has no existing Eq-specialized pointer shortcut. A new explicit ptr_eq is a scoped reflexivity rule, not preservation of such an old shortcut.',
        'Native name+receiver keys are a current representation convention, not a proof of complete host function identity. The retained Document/Element collapse is visible through the added ordinary cases.',
        'Root owns final installer and budget policy review. This review does not approve code not yet implemented or assert a runtime outcome.',
    ],
    'authenticated_inventory_review': {
        'receipt': bound(BASE / 'layout-identity-review.json'),
        'sources': 21, 'bytes': 16515, 'modes': 42, 'admitted': 42, 'excluded': 0,
        'helpers': ['sta.js', 'assert.js', 'propertyHelper.js', 'isConstructor.js'],
        'feature_counts': {'Object.is': 2, 'Symbol': 3, 'Reflect.construct': 1, 'arrow-function': 1},
        'scope': 'All source/blob/SHA and subtree identities, each admission row and ordered helpers independently checked by layout; original preparation hashes also rechecked here. No corpus fetch or malformed-proof control rerun.',
    },
    'original_preparation_files_rechecked': len(preparation['files']),
    'compiler_or_engine_executions': 0,
    'repository_edits': 0,
}
output = BASE / 'html-css-oracle-review.json'
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(bound(output)))
