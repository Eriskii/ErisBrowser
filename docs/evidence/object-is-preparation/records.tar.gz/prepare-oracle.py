"""Independent source-only Object.is draft; no JavaScript parser/engine imports."""
import hashlib,json
from pathlib import Path
OUT=Path(__file__).parent
GUARD="assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);\n"
cases=[]
def case(name,body,kind='ordinary',requires=()):
 cases.append(dict(id=name,kind=kind,requires=list(requires),expectation='resource' if kind=='policy' else 'pass',modes=['sloppy','strict'],source=GUARD+body))
case('all-signed-zero-pairs',"assert.sameValue(Object.is(0,0),true);assert.sameValue(Object.is(-0,-0),true);assert.sameValue(Object.is(0,-0),false);assert.sameValue(Object.is(-0,0),false);")
case('nan-and-numbers',"assert.sameValue(Object.is(NaN,0/0),true);assert.sameValue(Object.is(-NaN,NaN),true);assert.sameValue(Object.is(NaN,Infinity),false);assert.sameValue(Object.is(NaN,undefined),false);")
case('finite-infinite-subnormal',"assert.sameValue(Object.is(Infinity,Infinity),true);assert.sameValue(Object.is(-Infinity,-Infinity),true);assert.sameValue(Object.is(Infinity,-Infinity),false);assert.sameValue(Object.is(5e-324,5e-324),true);assert.sameValue(Object.is(5e-324,0),false);assert.sameValue(Object.is(1.5,1.5),true);assert.sameValue(Object.is(1,2),false);")
case('missing-and-undefined',"assert.sameValue(Object.is(),true);assert.sameValue(Object.is(undefined),true);assert.sameValue(Object.is(undefined,undefined),true);assert.sameValue(Object.is(null),false);assert.sameValue(Object.is(null,undefined),false);assert.sameValue(Object.is(null,null),true);")
case('booleans-no-number-coercion',"assert.sameValue(Object.is(true,true),true);assert.sameValue(Object.is(false,false),true);assert.sameValue(Object.is(false,true),false);assert.sameValue(Object.is(false,0),false);assert.sameValue(Object.is(true,1),false);")
case('primitive-type-lattice',"var values=[undefined,null,false,true,0,-0,1,'','1',NaN,Symbol('s')];for(var i=0;i<values.length;i++)for(var j=0;j<values.length;j++)assert.sameValue(Object.is(values[i],values[j]),i===j);")
case('utf16-code-units-no-normalization',r"assert.sameValue(Object.is('\uD800','\uD800'),true);assert.sameValue(Object.is('\uD800','\uDC00'),false);assert.sameValue(Object.is('\uD800\uDC00','\uD800\uDC00'),true);assert.sameValue(Object.is('\u00E9','e\u0301'),false);assert.sameValue(Object.is('a\0b','a\0b'),true);assert.sameValue(Object.is('a\0b','a'),false);")
case('separate-string-construction',"var a=['a','b'].join(''),b='xab'.slice(1);assert.sameValue(Object.is(a,b),true);assert.sameValue(Object.is(a,'abc'),false);")
case('objects-arrays-and-null-prototype',"var a={},b=[],c=Object.create(null);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(b,b),true);assert.sameValue(Object.is(c,c),true);assert.sameValue(Object.is(a,{}),false);assert.sameValue(Object.is(b,[]),false);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(c,Object.create(null)),false);")
case('functions-and-bound-identities',"function f(){}var a=f.bind(null),b=f.bind(null);assert.sameValue(Object.is(f,f),true);assert.sameValue(Object.is(f,function(){}),false);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(a,f),false);")
case('boxed-values-identity',"var n=new Number(NaN),s=new String('x'),b=new Boolean(false);assert.sameValue(Object.is(n,n),true);assert.sameValue(Object.is(n,NaN),false);assert.sameValue(Object.is(s,s),true);assert.sameValue(Object.is(s,'x'),false);assert.sameValue(Object.is(b,false),false);assert.sameValue(Object.is(new Number(0),new Number(0)),false);")
case('symbol-identity-not-description',"var a=Symbol('same'),b=Symbol('same');assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(Symbol.for('x'),Symbol.for('x')),true);assert.sameValue(Object.is(Symbol.iterator,Symbol.iterator),true);assert.sameValue(Object.is(a,Object(a)),false);")
case('never-read-conversion-hooks',"var reads=0,a={get valueOf(){reads++;throw 'valueOf';},get toString(){reads++;throw 'toString';}};Object.defineProperty(a,Symbol.toPrimitive,{get:function(){reads++;throw 'symbol';}});assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,1),false);assert.sameValue(Object.is('x',a),false);assert.sameValue(Object.is(a,{}),false);assert.sameValue(reads,0);")
case('receiver-ignored',"var receiver={get valueOf(){throw 'receiver';},get toString(){throw 'receiver';}};assert.sameValue(Object.is.call(receiver,NaN,NaN),true);assert.sameValue(Object.is.call(null,0,-0),false);assert.sameValue(Object.is.apply(undefined,[1,1]),true);")
case('arguments-evaluated-before-ignored-extras',"var trace='';function v(tag,value){trace+=tag;return value;}assert.sameValue(Object.is(v('A',1),v('B',1),v('C',9)),true);assert.sameValue(trace,'ABC');")
case('extra-value-not-coerced',"var x={get valueOf(){throw 'extra';},get toString(){throw 'extra';}};assert.sameValue(Object.is(1,1,x),true);assert.sameValue(Object.is(undefined,undefined,x,x),true);")
case('abrupt-argument-prevents-call',"var trace='',reason={},caught;function a(){trace+='A';return 1;}function b(){trace+='B';throw reason;}function c(){trace+='C';return 1;}try{Object.is(a(),b(),c());}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(trace,'AB');")
case('native-alias-and-distinct-methods',"assert.sameValue(Object.is(parseInt,Number.parseInt),true);assert.sameValue(Object.is(parseInt,parseFloat),false);assert.sameValue(Object.is(Object.is,Object.is),true);assert.sameValue(Object.is(Array.prototype.values,Array.prototype[Symbol.iterator]),true);")
case('native-prototype-function-identities',"assert.sameValue(Object.is('a'.slice,'b'.slice),true);assert.sameValue(Object.is('a'.slice,String.prototype.slice),true);assert.sameValue(Object.is(Array.prototype.push,Array.prototype.pop),false);assert.sameValue(Object.is(Object.prototype.toString,Array.prototype.toString),false);")
case('dom-wrapper-identities',"var a=document.createElement('div'),b=document.createElement('div');assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(a.style,a.style),true);assert.sameValue(Object.is(a.style,b.style),false);assert.sameValue(Object.is(a.classList,a.classList),true);assert.sameValue(Object.is(a.classList,b.classList),false);assert.sameValue(Object.is(document,window.document),true);assert.sameValue(Object.is(window,globalThis),true);",requires=['browser DOM'])
case('dom-native-method-identity',"var a=document.createElement('div'),b=document.createElement('div');assert.sameValue(Object.is(a.style.setProperty,b.style.setProperty),true);assert.sameValue(Object.is(a.style.setProperty,a.style.removeProperty),false);",requires=['browser DOM'])
case('cycles-never-traversed',"var a={},b={};a.self=a;b.self=b;Object.defineProperty(a,'x',{get:function(){throw 'unused';}});assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);")
case('buffer-and-view-identities',"var b=new ArrayBuffer(4),v=new DataView(b),w=new DataView(b);assert.sameValue(Object.is(v,v),true);assert.sameValue(Object.is(v,w),false);assert.sameValue(Object.is(v.buffer,b),true);b.transfer();assert.sameValue(Object.is(v.buffer,b),true);assert.sameValue(Object.is(v,w),false);",requires=['ArrayBuffer','DataView'])
case('object-property-descriptor',"var d=Object.getOwnPropertyDescriptor(Object,'is');assert.sameValue(d.value,Object.is);assert.sameValue(d.writable,true);assert.sameValue(d.enumerable,false);assert.sameValue(d.configurable,true);")
case('name-length-prototype',"var n=Object.getOwnPropertyDescriptor(Object.is,'name'),l=Object.getOwnPropertyDescriptor(Object.is,'length');assert.sameValue(n.value,'is');assert.sameValue(l.value,2);assert.sameValue(n.writable,false);assert.sameValue(l.writable,false);assert.sameValue(n.enumerable,false);assert.sameValue(l.enumerable,false);assert.sameValue(n.configurable,true);assert.sameValue(l.configurable,true);assert.sameValue(Object.getOwnPropertyDescriptor(Object.is,'prototype'),undefined);assert.sameValue(Object.getPrototypeOf(Object.is),Function.prototype);")
case('nonconstructability-and-argument-evaluation',"var seen=0;assert.throws(TypeError,function(){new Object.is((seen++,0),0);});assert.sameValue(seen,1);assert.throws(TypeError,function(){Reflect.construct(Object.is,[0,0]);});")
case('newtarget-rejected-before-argument-list-read',"var reads=0,args={get length(){reads++;throw 'length';}};assert.throws(TypeError,function(){Reflect.construct(function(){},args,Object.is);});assert.sameValue(reads,0);")
case('borrowed-call-apply-bound',"var f=Object.is,b=f.bind({ignored:true},NaN);assert.sameValue(f(2,2),true);assert.sameValue(f.call(7,-0,0),false);assert.sameValue(f.apply(null,[NaN,NaN]),true);assert.sameValue(b(NaN),true);assert.throws(TypeError,function(){new b(NaN);});")
case('prototype-hooks-never-read',"var p={get constructor(){throw 'constructor';},get valueOf(){throw 'valueOf';}},a=Object.create(p);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,null),false);assert.sameValue(Object.is(a,Object.create(p)),false);")
case('delete-and-restore-preserves-saved-function',"var d=Object.getOwnPropertyDescriptor(Object,'is'),f=Object.is;try{assert.sameValue(delete Object.is,true);assert.sameValue(Object.getOwnPropertyDescriptor(Object,'is'),undefined);assert.sameValue(f(NaN,NaN),true);}finally{Object.defineProperty(Object,'is',d);}assert.sameValue(Object.is,f);")
case('long-string-success',"var a=new Array(8193).join('x'),b=a.slice(0);assert.sameValue(Object.is(a,b),true);assert.sameValue(Object.is(a,b+'y'),false);")
case('large-extra-values-ignored',"var a=new Array(16385).join('x'),b=new Array(4096);assert.sameValue(Object.is(1,1,a,b),true);assert.sameValue(Object.is(a,null,a,b),false);")
case('terminal-repeated-string-comparison',"var a=new Array(4097).join('x'),b=a.slice(0);for(var i=0;i<200;i++)Object.is(a,b);throw new Test262Error('comparison work did not stop');",'policy')
case('terminal-string-budget-not-catchable',"var a=new Array(4097).join('x'),b=a.slice(0),caught=false;try{for(var i=0;i<200;i++)Object.is(a,b);}catch(e){caught=true;}throw new Test262Error('terminal comparison work was catchable or absent');",'policy')
case('proxy-identity-no-traps',"var p=new Proxy({}, {get:function(){throw 'trap';}});assert.sameValue(Object.is(p,p),true);assert.sameValue(Object.is(p,{}),false);",'prerequisite',['Proxy'])
case('bigint-identity-and-number-distinction',"assert.sameValue(Object.is(1n,1n),true);assert.sameValue(Object.is(1n,1),false);assert.sameValue(Object.is(0n,-0n),true);",'prerequisite',['BigInt'])
case('foreign-realm-object-identity',"var r=$262.createRealm(),o=r.evalScript('({})');assert.sameValue(Object.is(o,o),true);assert.sameValue(Object.is(o,{}),false);",'prerequisite',['$262.createRealm'])
pairs=[
 ('nan','', 'Object.is(NaN,0/0)','true','false'),
 ('signed-zero','', 'Object.is(0,-0)','false','true'),
 ('missing','', 'Object.is()','true','false'),
 ('different-type','', "Object.is(1,'1')",'false','true'),
 ('utf16',r"var a='\uD800',b='\uDC00';",'Object.is(a,b)','false','true'),
 ('object-identity','var a={};','Object.is(a,a)','true','false'),
 ('distinct-arrays','', 'Object.is([],[])','false','true'),
 ('symbol-identity',"var a=Symbol('x'),b=Symbol('x');",'Object.is(a,b)','false','true'),
 ('no-coercion',"var n=0,a={valueOf:function(){n++;throw 'bad';}};assert.sameValue(Object.is(a,1),false);",'n','0','1'),
 ('native-alias','', 'Object.is(parseInt,Number.parseInt)','true','false'),
 ('receiver-ignored','', 'Object.is.call(null,NaN,NaN)','true','false'),
 ('metadata',"var d=Object.getOwnPropertyDescriptor(Object,'is');",'d.enumerable','false','true')]
controls=[]
for name,setup,actual,good,bad in pairs:
 for suffix,expect,value in [('positive','pass',good),('wrong','Test262Error',bad)]:
  controls.append(dict(id='object-is-'+name+'-'+suffix,pair=name,variant=suffix,expectation=expect,modes=['sloppy','strict'],source=GUARD+setup+'\nassert.sameValue('+actual+','+value+');'))
for rows in [cases,controls]:
 for r in rows:r['sha256']=hashlib.sha256(r['source'].encode()).hexdigest()
manifest=dict(schema=1,status='independent proposal only; no execution or runner import',case_sources=len(cases),case_modes=len(cases)*2,feature_pairs=len(pairs),feature_control_modes=len(controls)*2,common_controls='Reuse unchanged profile common controls later; none invented here.',cases=cases,feature_controls=controls)
(OUT/'local-oracle-draft.json').write_text(json.dumps(manifest,indent=2)+'\n')
(OUT/'local-oracle-draft.js').write_text('\n\n'.join('// CASE '+r['id']+' ['+r['expectation']+']\n'+r['source'] for r in cases)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ['cases','feature_controls']},indent=2))
