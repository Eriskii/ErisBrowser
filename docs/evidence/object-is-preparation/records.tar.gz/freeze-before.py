#!/usr/bin/env python3
"""Bind both Object.is populations before any runtime edit or engine execution."""
from pathlib import Path
import hashlib
import json
import sys

sys.dont_write_bytecode = True
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'tools'))
import test262_conformance as runner
from test_test262_object_integrity import capture_contracts, canonical

if not __debug__:
    raise RuntimeError('Optimized Python is not allowed for the frozen verification driver')

def bind(path):
    path=Path(path)
    assert path.is_file() and not path.is_symlink()
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path, data):
    with Path(path).open('x') as handle:
        json.dump(data, handle, indent=2)
        handle.write('\n')

old=capture_contracts(excluded={'object-is'})
old_sha=runner.digest(canonical(old))
assert old_sha=='2555833d1cd7a66a19d02ed295f404060b72472d7af8fbd008517285be5d6cd6'
assert old==read(HERE/'historical-freeze/contracts.json')
historical=read(HERE/'historical-freeze/freeze.json')
for row in historical['baselines'].values():
    assert bind(row['path'])==row
new=capture_contracts(excluded=set(runner.PROFILES)-{'object-is'})
assert new['counts']==dict(profiles=1,cases=42,preflights=80)
formal=HERE/'formal-preparation'
with (formal/'contracts.json').open('xb') as handle:
    handle.write(canonical(new))
corpus=ROOT/'tests/upstream/test262-object-is'
manifest,files,cases,fixtures,_=runner.load_corpus(corpus,'object-is')
assert len(cases)==42 and not fixtures
assert all(runner.unsupported_reason(c,runner.OBJECT_IS_FEATURES) is None for c in cases)
parent=read(HERE/'checkpoint.json');candidate=Path(parent['before_candidate'])
inputs=read(candidate/'inputs.json')
for row in parent['before_files']:
    assert bind(row['path'])==row
for row in inputs['files']:
    assert bind(ROOT/row['path'])['sha256']==row['sha256']
corpus_files=sorted(p for p in corpus.rglob('*') if p.is_file())
shared=[ROOT/p for p in ('tools/test262_conformance.py','tools/import_test262.py',
    'tools/html_conformance.py','tools/run.py','.github/workflows/check.yml')]
shared+=sorted((ROOT/'tools').glob('test_test262_*.py'))
shared+=[HERE/'checkpoint.json',HERE/'parent-ci.json',Path(__file__)]
shared+=sorted(p for p in HERE.iterdir() if p.is_file() and p.suffix in {'.md','.json','.py'})
paths=corpus_files+shared+sorted(p for p in formal.iterdir() if p.is_file())
save(formal/'freeze.json',dict(format=1,stage='Before Object.is runtime changes and engine execution',
    files=[bind(p) for p in sorted(set(paths))],corpus_files=[str(p) for p in corpus_files],
    contracts=bind(formal/'contracts.json'),before=parent,
    before_input_sha256=inputs['input_sha256'],before_binary_sha256=bind(candidate/'eris-js')['sha256'],
    before_archive_sha256=bind(candidate/'archive-inputs.json')['sha256'],
    old43_contract_sha256=old_sha,counts=new['counts'],case_order=[c['id'] for c in cases],
    limits=dict(case_timeout_seconds=3,jobs=4,profile_seconds=600,address_space=1024**3,
                cpu_seconds=300,file_bytes=32*1024**2,reap_seconds=5),
    notes=['All21 sources42modes admitted. No exclusions.',
           'Existing43 contracts and35 baseline files remain identical.',
           'BEFORE retains incidental outcomes; unhealthy positive controls cannot establish support.']))
local=HERE/'local-preparation'
paths=shared+sorted(p for p in local.rglob('*') if p.is_file() and '__pycache__' not in p.parts)
save(local/'replay-inputs.json',dict(schema=1,phase='before',parent=parent['parent'],
    before=dict(candidate=str(candidate),input_sha256=inputs['input_sha256'],
                binary_sha256=bind(candidate/'eris-js')['sha256'],
                archive_inventory_sha256=bind(candidate/'archive-inputs.json')['sha256']),
    counts=dict(source_cases=39,case_modes=78,feature_controls=48,common_controls=12,rows=138),
    files={str(p):{k:v for k,v in bind(p).items() if k!='path'} for p in sorted(set(paths))}))
print(json.dumps(dict(formal=bind(formal/'freeze.json'),local=bind(local/'replay-inputs.json'))))
