"""Data-only arithmetic on four authored sources; no candidate parser or engine."""
import hashlib,json,math,re
from pathlib import Path
P=Path(__file__).parent
D=json.loads((P/'local-oracle-draft-2.json').read_text())
ids=['long-string-success','large-extra-values-ignored','terminal-repeated-string-comparison','terminal-string-budget-not-catchable']
rows=[]
for r in D['cases']:
 if r['id'] not in ids:continue
 source=r['source'];assert source.isascii()
 tokens=[];strings=[];pos=0
 # These four sources use only unescaped single-quoted ASCII strings, decimal
 # numbers, ASCII identifiers and a small fixed punctuation vocabulary.
 pattern=re.compile(r"\s+|'([^'\\]*)'|[A-Za-z_$][A-Za-z0-9_$]*|[0-9]+|===|!==|\+\+|[{}\[\]().,;:+<>=!-]")
 for m in pattern.finditer(source):
  assert m.start()==pos,(r['id'],pos);pos=m.end()
  if m.group(0).isspace():continue
  tokens.append(m.group(0))
  if m.group(1) is not None:strings.append(m.group(1))
 assert pos==len(source)
 lengths=list(map(len,strings));large=[n for n in lengths if n>=4096]
 quote_work=sum(n+2+(n+2)//8 for n in lengths)
 # Cumulative REQUESTED storage upper bound, not allocator-overhead claim:
 # 32 initial +8*(n+1) per char/close +<=8*(n+1) growth slots
 # +32 per growth +2*n+32 final Rc conversion.
 quoted_heap=sum(18*n+80+32*(1+math.ceil(math.log2(n+1))) for n in lengths)
 lex_base=1+len(source)//4
 identifiers=[t for t in tokens if re.fullmatch('[A-Za-z_$][A-Za-z0-9_$]*',t)]
 identifier_work=sum(1+len(t)//8 for t in identifiers)
 baseline_literal_work=quote_work+lex_base+identifier_work
 assert len(source)<256*1024 and max(lengths)<256*1024 and len(tokens)<256
 assert baseline_literal_work<30000 and quoted_heap+3*len(source)<450000
 policy=r['kind']=='policy'
 if policy:
  assert large==[4096,4096]
  assert source.index('assert.sameValue(Object.is(a,b),true);')<source.index('for(var i=0;i<200;i++)')
 assert '.join(' not in source and '.slice(' not in source
 rows.append(dict(id=r['id'],source_sha256=r['sha256'],source_bytes=len(source),tokens=len(tokens),literal_count=len(lengths),large_literal_code_units=large,quoted_text_exact_work=quote_work,lex_source_work=lex_base,ascii_identifier_token_work=identifier_work,these_lexical_work_terms=baseline_literal_work,remaining_compile_work_before_other_syntax_terms=100000-baseline_literal_work,quoted_text_requested_heap_upper=quoted_heap,runtime_source_retention_charge=3*len(source),these_heap_terms=quoted_heap+3*len(source),runtime_large_string_construction='None: precompiled literal handles cloned; no character loop, join, slice, conversion or copy',one_successful_comparison_before_policy_loop=policy,proposed_long_comparison_payload_work=1026 if policy else None,policy_comparison_count=200 if policy else None,policy_payload_work_lower_bound=205200 if policy else None))
assert len(rows)==4
out=dict(schema=1,kind='static arithmetic, not compiler/engine observation',rows=rows,limits=dict(MAX_STEPS=100000,MAX_HEAP=8388608,MAX_SOURCE=262144,MAX_STRING=262144,MAX_TOKENS=32768),scope='Exact source/quoted-literal/ASCII-token terms plus conservative requested quote-storage bound. Syntax records, fixed parser continuations, runtime lookups/calls and the loaded harness are separate; see prose conditions.',engine_executed=False)
(P/'setup-feasibility.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(rows,indent=2))
