#!/usr/bin/env python3
"""One hash-bound local BEFORE; inert unless --execute is explicitly supplied."""
import argparse
import hashlib
import importlib.util
import json
import signal
import sys
import time
from collections import Counter
from pathlib import Path

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
HELPER=Path('/tmp/eris-for-in-length-buckets-1/replay-preparation/replay.py')
HELPER_SHA='5a429d9c5aeb935907acc4b6bedcc35cd610b7576c713e98c0717746fa8ee319'

def sha(p):
    with Path(p).open('rb') as handle:
        return hashlib.file_digest(handle,'sha256').hexdigest()

def require(ok,message):
    if not ok:raise ValueError(message)

require(sha(HELPER)==HELPER_SHA,'candidate verifier changed')
spec=importlib.util.spec_from_file_location('preserved_local_helpers',HELPER)
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
old=helper.old

def verify_manifest(path,expected):
    require(sha(path)==expected,'manifest changed')
    data=old.read(path)
    for name,row in data['files'].items():
        p=Path(name)
        require(p.is_file() and not p.is_symlink() and p.stat().st_size==row['bytes'] and sha(p)==row['sha256'], 'frozen input changed: '+name)
    candidate=Path(data['before']['candidate'])
    release=helper.verify_candidate(candidate,data['before']['input_sha256'],data['before']['binary_sha256'],data['before']['archive_inventory_sha256'])
    # BEFORE retains the exact production tree as well as the binary's archive.
    for row in old.read(candidate/'inputs.json')['files']:
        require(sha(ROOT/row['path'])==row['sha256'],'runtime changed before BEFORE: '+row['path'])
    draft=old.read(HERE/'draft.json')
    matrix=old.read(HERE/'runner-matrix.json')['cases']
    require(len(matrix)==138 and len(draft['cases'])==39,'matrix count changed')
    authored=[(row,mode) for row in draft['cases'] for mode in row['modes']]
    for (row,mode),actual in zip(authored,matrix[:78]):
        require(actual['id']==row['id']+'#'+mode and actual['mode']==mode,'authored case changed')
        require(actual['source']==row['source'] and actual['source_sha256']==row['sha256'],'authored source changed')
        expected=(dict(status='complete',phase='runtime',error_identity='',error_type='')
                  if row['expectation']=='pass' else dict(status='resource',phase='runtime'))
        require(actual['expected']==expected,'authored expectation changed')
    controls=[(row,mode) for row in draft['feature_controls'] for mode in row['modes']]
    for (row,mode),actual in zip(controls,matrix[78:126]):
        require(actual['source']==row['source'] and actual['source_sha256']==row['sha256'],'control source changed')
        require(actual['mode']==mode and actual['positive']==(row['variant']=='positive'),'control mode or role changed')
    return data,release,matrix

def check_report(report,matrix,data):
    require(len(report['cases'])==78 and len(report['controls'])==60,'incomplete report')
    require(report['binary_sha256']==data['before']['binary_sha256'],'report binary changed')
    require(report['fixture_sha256']==sha(HERE/'object-is.js') and report['matrix_sha256']==sha(HERE/'runner-matrix.json') and report['runner_sha256']==sha(HERE/'run.py'),'report input binding changed')
    require(report['tool_hashes']==old.read(HERE/'runner-matrix.json')['tool_hashes'],'report helper binding changed')
    require(report['harness']==old.read(HERE/'runner-matrix.json')['harness'],'report harness binding changed')
    require(report['counts']==dict(Counter(r['status'] for r in report['cases'])),'raw status counts differ')
    require(report['bounds']==dict(per_case_wall_seconds=3,address_space_bytes=512*1024**2,per_process_cpu_seconds=30,core_bytes=0,adapter_stdout_bytes=96*1024,adapter_stderr_bytes=64*1024),'adapter limits differ')
    rows=report['cases']+report['controls']
    require(len({r['id'] for r in rows})==138,'duplicate report row')
    for expected,actual in zip(matrix,rows):
        for key in ('id','mode','source','case_sha256','source_sha256','expectation_sha256','category'):
            require(expected[key]==actual[key],'report row identity changed: '+expected['id']+' '+key)
        require(actual['expected_observation']==expected['expected'],'report expectation changed')
        filename={'fixture':'object-is.js','preflight-control':'preflight-controls','harness-control':'harness-controls'}[expected['category']]
        require(actual['file']==filename,'report source filename changed')
        for key in ('area','prerequisites','positive','partner'):
            require(actual.get(key)==expected.get(key),'report category/guard changed')
    helper.verify_health(report)
    return {key:report[key] for key in ('counts','controls_verified','fixture_expectations_matched','fixture_expectations_verified','protocol_prerequisite_verified')}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest',type=Path,default=HERE/'replay-inputs.json')
    parser.add_argument('--manifest-sha256',required=True)
    parser.add_argument('--output',type=Path,default=HERE.parent/'local-before')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    data,release,matrix=verify_manifest(args.manifest,args.manifest_sha256)
    if not args.execute:
        print(json.dumps(dict(inert=True,rows=138,cases=78,controls=60,binary_sha256=data['before']['binary_sha256'],archive_members=413)))
        return
    output=args.output.resolve()
    require(Path('/tmp') in output.parents and not output.exists(),'fresh scratch output required')
    protected=[ROOT,HERE,Path(data['before']['candidate'])]
    require(all(output!=p and p not in output.parents and output not in p.parents for p in protected),'output overlaps protected input')
    output.mkdir()
    sys.path.insert(0,str(ROOT/'tools'))
    from run import launch_environment
    env=launch_environment();env['PYTHONDONTWRITEBYTECODE']='1'
    for key in ('PYTHONOPTIMIZE','PYTHONPATH','PYTHONHOME'):env.pop(key,None)
    command=[sys.executable,'-B',str(HERE/'run.py'),'--binary',str(Path(data['before']['candidate'])/'eris-js'),'--sha256',data['before']['binary_sha256'],'--output',str(output/'report.json')]
    record=dict(schema=1,phase='before',started_utc=old.utc(),completed=False,driver_sha256=sha(__file__),manifest_sha256=args.manifest_sha256,
                command=command,release=release,counts=dict(cases=78,feature_controls=48,common_controls=12,total=138),
                process_limits=dict(wall_seconds=120,cpu_seconds=45,address_space_bytes=512*1024**2,log_file_bytes=32*1024**2,reap_seconds=5),
                adapter_limits=dict(per_case_wall_seconds=3,cpu_seconds=30,address_space_bytes=512*1024**2,stdout_bytes=96*1024,stderr_bytes=64*1024),
                scope='One unchanged local BEFORE; all rows and unsupported/resource outcomes retained, no retries or pass-health gate.')
    old.write_new(output/'start.json',record)
    previous={sig:signal.signal(sig,old.interrupt) for sig in (signal.SIGINT,signal.SIGTERM)}
    try:
        old.run_suite(command,output,'local',env,time.monotonic()+120,dict(wall_seconds=120,cpu_seconds=45))
        require((output/'local.stderr.log').stat().st_size==0,'runner stderr is not empty')
        record['summary']=check_report(old.read(output/'report.json'),matrix,data)
        after,after_release,after_matrix=verify_manifest(args.manifest,args.manifest_sha256)
        require(after==data and after_release==release and after_matrix==matrix,'inputs changed during BEFORE')
        record.update(completed=True,inputs_unchanged=True)
    except BaseException as error:
        record['failure']=dict(type=type(error).__name__,message=str(error))
        raise
    finally:
        for sig,handler in previous.items():signal.signal(sig,handler)
        # A failed run still retains its post-input audit; do not hide an earlier
        # process/report failure behind a later verification exception.
        try:
            final_data,final_release,final_matrix=verify_manifest(args.manifest,args.manifest_sha256)
            record['post_inputs_unchanged']=(final_data==data and final_release==release and final_matrix==matrix)
            require(record['post_inputs_unchanged'],'post-input identities differ')
        except BaseException as error:
            record.update(completed=False,post_input_failure=dict(type=type(error).__name__,message=str(error)))
        record['ended_utc']=old.utc()
        record['artifacts']={p.name:old.file_record(p) for p in sorted(output.iterdir()) if p.is_file()}
        old.write_new(output/'execution.json',record)
    require(record['completed'] and record.get('post_inputs_unchanged'),'incomplete BEFORE or changed inputs')
    print(json.dumps(record['summary'],sort_keys=True))

if __name__=='__main__':main()
