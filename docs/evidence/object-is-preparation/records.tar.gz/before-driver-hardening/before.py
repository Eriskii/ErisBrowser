#!/usr/bin/env python3
"""Hash-verified, single formal Object.is BEFORE replay; inert by default."""
import argparse
from collections import Counter
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT/'tools'))


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def read(path): return json.loads(Path(path).read_bytes())
def bind(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))


def verify(row):
    p = Path(row['path'])
    assert p.is_file() and not p.is_symlink(), str(p)
    assert p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], str(p)


def save(path, value):
    with Path(path).open('x') as f:
        json.dump(value, f, indent=2); f.write('\n')


def load(path, name):
    s = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(s); s.loader.exec_module(m); return m


def check(freeze):
    for row in freeze['files']: verify(row)
    for row in freeze['before']['before_files']: verify(row)
    archive = load(HERE/'archive-helper.py', 'object_is_archive_helper')
    provenance = archive.verify_candidate(Path(freeze['before']['before_candidate']),
        freeze['before_input_sha256'], freeze['before_binary_sha256'], freeze['before_archive_sha256'])
    # BEFORE still represents the held runtime: instrumentation/tooling may differ.
    inputs = read(Path(freeze['before']['before_candidate'])/'inputs.json')
    for row in inputs['files']:
        assert sha(ROOT/row['path']) == row['sha256'], row['path']
    import test262_conformance as runner
    from test_test262_object_integrity import capture_contracts, canonical
    current = capture_contracts(excluded=set(runner.PROFILES)-{'object-is'})
    contract = read(HERE/'contracts.json')
    assert current == contract
    old = capture_contracts(excluded={'object-is'})
    assert runner.digest(canonical(old)) == freeze['old43_contract_sha256']
    corpus = ROOT/'tests/upstream/test262-object-is'
    assert {str(p) for p in corpus.rglob('*') if p.is_file()} == set(freeze['corpus_files'])
    ci = read(HERE.parent/'parent-ci.json')
    assert ci['headSha'] == freeze['before']['parent'] and ci['conclusion'] == 'success'
    assert len(ci['jobs']) == 9 and all(j['conclusion']=='success' for j in ci['jobs'])
    return contract['profiles']['object-is'], provenance


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--freeze', type=Path, required=True)
    p.add_argument('--freeze-sha256', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--execute', action='store_true')
    args = p.parse_args()
    assert sha(args.freeze) == args.freeze_sha256
    freeze = read(args.freeze)
    contract, provenance = check(freeze)
    assert args.output.is_absolute() and Path('/tmp') in args.output.parents
    assert not args.output.exists() and not args.output.is_symlink()
    if not args.execute:
        print('INERT: all corpus, 42 case/80 control, old43, source archive and BEFORE bindings verified.'); return
    helper = load(HERE/'supervision-helper.py', 'object_is_supervision')
    helper.DEADLINE_SECONDS = 600
    from run import launch_environment
    env = launch_environment(); env['PYTHONDONTWRITEBYTECODE']='1'
    args.output.mkdir()
    report_path = args.output/'object-is.json'
    binary = Path(freeze['before']['before_candidate'])/'eris-js'
    command = [sys.executable, str(ROOT/'tools/test262_conformance.py'), '--binary', str(binary),
        '--profile', 'object-is', '--output', str(report_path), '--jobs', '4', '--timeout', '3']
    record = dict(format=1, freeze=bind(args.freeze), driver=bind(__file__), command=command,
        started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        before_binary_sha256=freeze['before_binary_sha256'], source_archive=provenance,
        no_retries=True, no_baseline_writes=True, no_result_normalization=True,
        limits=freeze['limits'], environment={k:env.get(k) for k in ('TZ','LANG','LC_ALL','LC_TIME','LD_LIBRARY_PATH')})
    save(args.output/'pre-execution.json', record)
    process=None; ownership={'reap_started':False}; reaped=False; started=time.monotonic()
    def interrupted(number, frame): raise KeyboardInterrupt('signal '+str(number))
    for sig in (signal.SIGTERM, signal.SIGINT): signal.signal(sig, interrupted)
    try:
        with (args.output/'stdout.log').open('xb') as stdout, (args.output/'stderr.log').open('xb') as stderr:
            process = subprocess.Popen(command,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,
                stdout=stdout,stderr=stderr,close_fds=True,start_new_session=True,preexec_fn=helper.limits)
            record['pid']=process.pid
            code, observed=helper.wait_unreaped(process,ownership); reaped=True
            record.update(returncode=code, exit_observed_without_reaping=observed)
        report=read(report_path)
        assert report['binary_sha256']==freeze['before_binary_sha256']
        assert report['corpus_manifest_sha256']==contract['manifest_sha256']
        assert report['runner_policy_sha256']==contract['runner_policy_sha256']
        assert report['runner_policy']==contract['policy']
        assert [r['id'] for r in report['cases']]==freeze['case_order']
        assert len(report['cases'])==42 and len(report['harness_preflight'])==80
        for row in report['cases']:
            before=contract['cases'][row['id']]
            for key in ('file','mode','case_sha256','source_sha256'): assert row[key]==before[key]
            assert row['expected_negative']==before['metadata']['negative']
            if before['unsupported_reason']:
                assert row['status']=='unsupported' and row['reason']==before['unsupported_reason']
        for row,before in zip(report['harness_preflight'],contract['preflights']):
            assert row['name']==before['name'] and row['expected']==before['expected']
            for key in ('mode','case_sha256','source_sha256'):assert row['result'][key]==before[key]
            if 'prerequisite' in before:
                assert {k:v for k,v in row['prerequisite'].items() if k!='verified'}==before['prerequisite']
        record.update(counts=report['counts'],controls_verified=sum(x['verified'] for x in report['harness_preflight']),
            control_raw_statuses=dict(Counter(x['result']['status'] for x in report['harness_preflight'])),
            control_health=report['harness_preflight_passed'], case_control_policy_verified=True)
        check(freeze); assert sha(args.freeze)==args.freeze_sha256
        record['all_bindings_unchanged_after_execution']=True
    except BaseException as error:
        record['failure']=dict(type=type(error).__name__,message=str(error)); raise
    finally:
        if process is not None and not reaped:
            try:
                record['cleanup_returncode']=(process.wait(timeout=5) if ownership['reap_started']
                    else helper.kill_then_reap(process,ownership)); reaped=True
            except BaseException as error:
                record['cleanup_failure']=dict(type=type(error).__name__,message=str(error))
        record.update(leader_reaped=reaped, reap_started=ownership['reap_started'],
            elapsed_seconds=time.monotonic()-started, captured_files=[bind(p) for p in
                (args.output/'stdout.log',args.output/'stderr.log',report_path) if p.exists()])
        save(args.output/'execution.json',record)
    print(json.dumps({k:record[k] for k in ('counts','controls_verified','control_health','leader_reaped')}))


if __name__=='__main__': main()
