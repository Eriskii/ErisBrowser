# Object.is: bounded next standards increment

Revised preparation only, following DataView publication f55911e2fd3ead3f42fa59718016c215b6c4a48f. The original proposal.md, original oracle and initial preparation.json remain unchanged. No repository implementation, importer, fixture, quota or expectation has changed; no compiler or JavaScript engine was run. This directory contains the complete proposed upstream selection and a separate independent local draft, not a baseline or an implementation result.

## Scope and normative behavior

Add `Object.is(value1, value2)` for the runtime's existing value kinds. Its specified result is SameValue: unlike strict equality, NaN compares equal to NaN and positive/negative zero differ. It neither converts operands nor reads object properties. Strings compare their exact UTF-16 code-unit sequences; normalization and surrogate repair are inappropriate. Objects and symbols compare by identity. Missing arguments are undefined; extra argument expressions still execute in ordinary source order, but the built-in ignores their resulting values and its `this` receiver.

Primary current specification sections were fetched from TC39 and retained in `spec/` with URL, complete-page hashes, section-text hashes and request provenance:

- [Object.is](https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-object.is)
- [SameValue](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-samevalue)
- [SameValueNonNumber](https://tc39.es/ecma262/multipage/abstract-operations.html#sec-samevaluenonnumber)
- [Number::sameValue](https://tc39.es/ecma262/multipage/ecmascript-data-types-and-values.html#sec-numeric-types-number-sameValue)
- [Built-in defaults](https://tc39.es/ecma262/multipage/ecmascript-standard-built-in-objects.html#sec-ecmascript-standard-built-in-objects)

The function has name `is`, length 2, Function.prototype as its prototype, and no own `prototype`. Its Object property is writable/configurable and nonenumerable. Name/length are nonwritable, nonenumerable, configurable. It has no [[Construct]], including when used as a Reflect.construct newTarget or through a bound function. Adding a property named `prototype` later would not make it a constructor.

Do not add BigInt, Proxy, foreign realms or other new value families. The local draft retains three ordinary-success prerequisite cases for those features, without pretending Object.is itself supplies them. DOM cases cover existing custom host identities, not general DOM conformance.

## Concrete runtime seams

- `src/script.rs:64`: Value represents numbers, UTF-16 strings, symbols, arena-indexed objects/arrays/functions, host wrappers and Native records.
- `src/script.rs:9087`: `json_same_value` already handles number bits/NaNs correctly, then delegates to Value equality. It has no budget access; do not expose it directly as an uncharged public native operation or change all existing callers in this increment.
- `src/script.rs:4130`: loose string equality prepays both code-unit lengths. `binary_value` also pays for strings before strict equality. These are accounting precedents, not Object.is implementations: loose equality coerces and strict equality has different NaN/zero results.
- `src/js_string.rs:8`: JsString is an Rc UTF-16 slice. Length is constant-time; comparisons may traverse code units; cloning shares storage. `symbols.rs` equality is symbol identity, not description text.
- `src/script.rs:2031`, `:2224`: existing static intrinsic installation and `intrinsic_function` supply property bags, name/length flags and native registry identity.
- `src/script.rs:7683` and `:8011`: put a dedicated `Object.is` dispatch before the generic native argument/receiver content scan. That generic path would charge ignored third arguments or a large borrowed receiver unnecessarily.
- `src/script/machine/calls.rs:120`: normal calls retain ordinary argument evaluation and guard cleanup. Object.is need not alter it; its comparison ignores the supplied receiver.
- `src/script/construction.rs:86`: the explicit native constructor whitelist already excludes Object.is. No constructor exception or whitelist change is needed.

Proposed production ownership: new `src/script/object_is.rs` plus private `object_is/tests.rs`, and a narrow module/install/dispatch hook in `src/script.rs`. No Runtime state field, Value variant, global equality rewrite or constructor change. These are proposed paths only, not permission to implement before root releases the next checkpoint.

## Comparison and identity accounting

Use a borrowed-operand helper returning `Result<bool>`; do not clone strings, scan array contents, create argument lists, inspect property maps or call author code. Default absent slice entries to one borrowed Undefined value.

1. Pay a small fixed dispatch/type/number allowance (proposed 4 logical work units).
2. Number pair: use the existing correct SameValue bit/NaN rule. No formatting/conversion/allocation.
3. String pair: lengths may be checked first. If unequal, return false without scanning either payload. For equal lengths, prepay `2 + a.len()/8 + b.len()/8` before comparison, consistent with existing string equality's conservative full-comparison bound. Preserve exact UTF-16. Aliased Rc storage does not justify bypassing the declared debit or weakening the frozen terminal policy.
4. Primitive/type mismatches, arena IDs, host wrapper kind plus NodeId, and symbols are scalar identity checks. No String-content debit when only one argument is a string. No payload debit for ignored extra arguments or receiver.
5. Native identity requires care: Native's current representation is a name plus an implementation receiver key. Native derives PartialEq, not Eq, so the existing Rc<Native> comparison does NOT receive Rc's Eq-specialized pointer shortcut. An explicit Rc::ptr_eq check would be a NEW scoped Object.is reflexivity guarantee, including a private Native whose receiver key contains NaN; do not describe it as preserved current derived-equality behavior. Fresh wrappers for the same host method can be distinct Rc allocations, so pointer identity alone is insufficient for represented shared methods. Preserve current name/key comparison after that new shortcut, without author-property lookup or a global Value equality rewrite.

For a robust scoped Native path, first accept identical Rc handles, then compare name lengths and prepay reached name-byte comparisons before comparing them. Descend receiver keys iteratively, ticking each reached Native link, rather than recursively invoking derived equality through an arbitrarily deep private chain. At a string receiver key, charge its equal-length code-unit comparison; arena/host/symbol keys are scalar. Receiver keys are implementation identity components, not new ECMAScript operands: preserve their existing equality semantics rather than recursively changing numeric key equality to SameValue. Number/String/Array method accesses resolve stored dotted Native values with Undefined receivers before legacy primitive fallback; invoke_native substitutes this only in a temporary invocation record. Style/DOM same-interface wrappers also use stable names plus Undefined. Private tests should exercise long strings and nested native keys to verify the defensive accounting boundary. This does not make the current host identity representation complete.

Existing host identity limitation: Document and Element querySelector/querySelectorAll are represented by the same DOM.querySelector/DOM.querySelectorAll name plus Undefined receiver, losing the defining interface. Object.is cannot recover that distinction from these operands. The revised local draft includes two ordinary-success cases expecting false across interfaces, while checking true within each interface. They are known host-representation gaps, not unsupported/excluded cases and not expected passes under the unchanged representation. Root will pursue separate DOM interface identity work after scalar/core Object.is. Keep ordinary borrowed Object.is.call/apply/bind checks; no general host-function identity or full DOM conformance claim.

The helper itself allocates nothing. Ordinary call setup/argument evaluation can still allocate and consume work; do not claim every complete Object.is expression is allocation-free. Terminal work exhaustion remains uncatchable under existing policy. No limit is raised and no budget is reset.

## Installing one intrinsic

Root selected the unchanged existing `intrinsic_function("Object.is", "is", 2)` path inside a small scoped installer. The concrete operation, storage, implicit four-slot fresh Vec, populated-tree split and owner-order reserve ledger is sealed separately in `installer-charge-plan.md`. It counts the constructor-owner registry lookup separately from two method-registry searches, two owner-property searches, the Object-prototype lookup and fresh-bag descriptor work. Existing ordinary function base/property charges remain in the generic allocator. Do not generalize DataView or hardcode desired bootstrap headroom. No implementation is authorized by this proposal.

## Authenticated upstream selection

Revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`, root Git tree `91b2052adad1f066ae031e2ff3a1e9bd6d732886`:

`test` → `built-ins` → `Object` (`0d01cdef5daae0a168799f8e263ba72ed0dd475f`) → `is` (`04a0f3e25947dbc1100ba4b4138765366d9704b4`).

The complete recursive subtree has 21 original JavaScript sources, 16,515 bytes, 42 modes (each source sloppy and strict), no fixture-only files, no async/negative/strict-only flags. Four exact root-linked helpers are retained: sta.js, assert.js, propertyHelper.js, isConstructor.js; LICENSE and INTERPRETING.md are retained too. Every source/helper has Git blob and SHA256 identity; each ancestor/descendant Git tree is reconstructed and authenticated by the copied existing verifier.

Proposed fixed policy: `OBJECT_INTEGRITY_FEATURES | {'Object.is'}`. It admits all 42 modes; metadata declares only Object.is (2 sources), Symbol (3), Reflect.construct (1) and arrow-function (1). The new feature tag is necessary to admit the method's own two tagged tests; it does not change any old profile's policy. The ordinary source/harness hook filter has no exclusions in this subtree. `admission.json` records every mode and exact ordered helper hashes with subprocess creation explicitly forbidden during that data-only check.

Six malformed-proof controls reject truncation, omitted source, duplicate path, substituted blob, wrong root and nonregular source mode. These are data verification checks, not conformance passes. First collector initialization failure and sandbox DNS failure remain in their original logs/request record; the authorized network attempt succeeded. No corpus has been imported into the repository and no baseline outcomes have been synthesized.

## Independent draft and validation after approval

`local-oracle-draft-2.json` and its readable JS contain 39 sources / 78 modes: 34 ordinary sources (including the two known defining-interface identity gaps), two explicit terminal string-comparison policy sources, and three ordinary missing-prerequisite sources. The original 37-source draft is preserved byte-for-byte. All original expectations and UTF-16 control sources remain identical; the peer initially suspected double escaping but retracted that finding after checking raw characters. The draft has 12 independent feature-control pairs / 48 modes. Each positive and deliberately wrong control begins with successful NaN/zero prerequisite guards, so an incidental wrong-control exception before support cannot verify the pair. Existing common controls should be copied unchanged when tooling is authorized. All four large-string cases now use authored bounded ASCII literals rather than Array.join over holes. Both policy cases must first complete a successful long-string comparison before entering their repeated loop. Reflect.construct error checks first construct an ordinary object successfully; native-alias controls first prove both aliases callable. See setup-feasibility.md and setup-feasibility.json for static setup calculations. This is an unexecuted draft pending independent review/freeze; it does not replace old DataView fixtures or the reciprocal negative-zero correction.

Required private regressions:

- Full number table, including distinct NaN payloads and both zero signs; no accidental SameValueZero/strict-equality substitution.
- Arbitrary UTF-16 equal/different strings from separate allocations, surrogate/NUL/normalization cases and equal/unequal lengths.
- Exact and one-short work at the comparison boundary, full heap already used (no allocation), type mismatch with large strings, and ignored large extra arguments/receiver.
- Stable symbol/object/array/function/DOM/native identity, native aliases, fresh host wrappers, no observable conversion/property reads, defensive Native receiver-key depth/name accounting.
- Installed descriptors/name/length/order/nonconstructability, deletion/restoration and saved-function identity; charged bootstrap diagnostic and the two existing maximum-string groups.
- Direct private terminal tests proving prior evaluated argument effects survive refusal, with calls/stack cleanup and no catch/finally execution after terminal exhaustion.

After root accepts/finalizes the draft: freeze/import the complete 21/42 profile and independent controls, retain one BEFORE on the published DataView binary, implement only the chosen scoped runtime delta, freeze candidate, run private/full compiler checks and fixed formal/local replays. Preserve existing old contracts/baselines before changing any gate. No predicted pass count or general security/Chromium claim is part of this proposal.
