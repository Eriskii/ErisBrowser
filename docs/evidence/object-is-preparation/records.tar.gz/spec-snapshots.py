import importlib.util,json,re
from pathlib import Path
from html.parser import HTMLParser
p=Path(__file__).parent
s=importlib.util.spec_from_file_location('collector',p/'collect.py');c=importlib.util.module_from_spec(s);s.loader.exec_module(c)
sections={
 'fundamental-objects.html':['sec-object.is'],
 'abstract-operations.html':['sec-samevalue','sec-samevaluenonnumber'],
 'ecmascript-data-types-and-values.html':['sec-numeric-types-number-sameValue'],
 'ecmascript-standard-built-in-objects.html':['sec-ecmascript-standard-built-in-objects']}
class Extract(HTMLParser):
 def __init__(self,ids):super().__init__();self.ids=set(ids);self.active=None;self.depth=0;self.result={}
 def handle_starttag(self,tag,attrs):
  if self.active:
   if tag in ['emu-clause','emu-intro','emu-annex']:self.depth+=1
  elif dict(attrs).get('id') in self.ids:
   self.active=dict(attrs)['id'];self.depth=1;self.result[self.active]=[]
 def handle_endtag(self,tag):
  if self.active and tag in ['emu-clause','emu-intro','emu-annex']:
   self.depth-=1
   if self.depth==0:self.active=None
 def handle_data(self,data):
  if self.active:self.result[self.active].append(data)
manifest=[]
for page,ids in sections.items():
 url='https://tc39.es/ecma262/multipage/'+page;b=c.document(url,p/'spec'/page);e=Extract(ids);e.feed(b.decode())
 for ident in ids:
  assert ident in e.result,(page,ident)
  text=re.sub(r'\s+',' ',' '.join(e.result[ident])).strip()
  out=p/'spec'/(ident+'.txt');c.save(out,(text+'\n').encode())
  manifest.append(dict(url=url+'#'+ident,page_sha256=c.sha(b),text_sha256=c.sha(out.read_bytes()),path=str(out.relative_to(p))))
c.save(p/'spec/manifest.json',(json.dumps(manifest,indent=2)+'\n').encode())
