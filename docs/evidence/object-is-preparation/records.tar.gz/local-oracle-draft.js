// CASE all-signed-zero-pairs [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(0,0),true);assert.sameValue(Object.is(-0,-0),true);assert.sameValue(Object.is(0,-0),false);assert.sameValue(Object.is(-0,0),false);

// CASE nan-and-numbers [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(NaN,0/0),true);assert.sameValue(Object.is(-NaN,NaN),true);assert.sameValue(Object.is(NaN,Infinity),false);assert.sameValue(Object.is(NaN,undefined),false);

// CASE finite-infinite-subnormal [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(Infinity,Infinity),true);assert.sameValue(Object.is(-Infinity,-Infinity),true);assert.sameValue(Object.is(Infinity,-Infinity),false);assert.sameValue(Object.is(5e-324,5e-324),true);assert.sameValue(Object.is(5e-324,0),false);assert.sameValue(Object.is(1.5,1.5),true);assert.sameValue(Object.is(1,2),false);

// CASE missing-and-undefined [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(),true);assert.sameValue(Object.is(undefined),true);assert.sameValue(Object.is(undefined,undefined),true);assert.sameValue(Object.is(null),false);assert.sameValue(Object.is(null,undefined),false);assert.sameValue(Object.is(null,null),true);

// CASE booleans-no-number-coercion [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(true,true),true);assert.sameValue(Object.is(false,false),true);assert.sameValue(Object.is(false,true),false);assert.sameValue(Object.is(false,0),false);assert.sameValue(Object.is(true,1),false);

// CASE primitive-type-lattice [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var values=[undefined,null,false,true,0,-0,1,'','1',NaN,Symbol('s')];for(var i=0;i<values.length;i++)for(var j=0;j<values.length;j++)assert.sameValue(Object.is(values[i],values[j]),i===j);

// CASE utf16-code-units-no-normalization [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is('\uD800','\uD800'),true);assert.sameValue(Object.is('\uD800','\uDC00'),false);assert.sameValue(Object.is('\uD800\uDC00','\uD800\uDC00'),true);assert.sameValue(Object.is('\u00E9','e\u0301'),false);assert.sameValue(Object.is('a\0b','a\0b'),true);assert.sameValue(Object.is('a\0b','a'),false);

// CASE separate-string-construction [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=['a','b'].join(''),b='xab'.slice(1);assert.sameValue(Object.is(a,b),true);assert.sameValue(Object.is(a,'abc'),false);

// CASE objects-arrays-and-null-prototype [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a={},b=[],c=Object.create(null);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(b,b),true);assert.sameValue(Object.is(c,c),true);assert.sameValue(Object.is(a,{}),false);assert.sameValue(Object.is(b,[]),false);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(c,Object.create(null)),false);

// CASE functions-and-bound-identities [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
function f(){}var a=f.bind(null),b=f.bind(null);assert.sameValue(Object.is(f,f),true);assert.sameValue(Object.is(f,function(){}),false);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(a,f),false);

// CASE boxed-values-identity [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var n=new Number(NaN),s=new String('x'),b=new Boolean(false);assert.sameValue(Object.is(n,n),true);assert.sameValue(Object.is(n,NaN),false);assert.sameValue(Object.is(s,s),true);assert.sameValue(Object.is(s,'x'),false);assert.sameValue(Object.is(b,false),false);assert.sameValue(Object.is(new Number(0),new Number(0)),false);

// CASE symbol-identity-not-description [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=Symbol('same'),b=Symbol('same');assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(Symbol.for('x'),Symbol.for('x')),true);assert.sameValue(Object.is(Symbol.iterator,Symbol.iterator),true);assert.sameValue(Object.is(a,Object(a)),false);

// CASE never-read-conversion-hooks [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var reads=0,a={get valueOf(){reads++;throw 'valueOf';},get toString(){reads++;throw 'toString';}};Object.defineProperty(a,Symbol.toPrimitive,{get:function(){reads++;throw 'symbol';}});assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,1),false);assert.sameValue(Object.is('x',a),false);assert.sameValue(Object.is(a,{}),false);assert.sameValue(reads,0);

// CASE receiver-ignored [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var receiver={get valueOf(){throw 'receiver';},get toString(){throw 'receiver';}};assert.sameValue(Object.is.call(receiver,NaN,NaN),true);assert.sameValue(Object.is.call(null,0,-0),false);assert.sameValue(Object.is.apply(undefined,[1,1]),true);

// CASE arguments-evaluated-before-ignored-extras [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var trace='';function v(tag,value){trace+=tag;return value;}assert.sameValue(Object.is(v('A',1),v('B',1),v('C',9)),true);assert.sameValue(trace,'ABC');

// CASE extra-value-not-coerced [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var x={get valueOf(){throw 'extra';},get toString(){throw 'extra';}};assert.sameValue(Object.is(1,1,x),true);assert.sameValue(Object.is(undefined,undefined,x,x),true);

// CASE abrupt-argument-prevents-call [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var trace='',reason={},caught;function a(){trace+='A';return 1;}function b(){trace+='B';throw reason;}function c(){trace+='C';return 1;}try{Object.is(a(),b(),c());}catch(e){caught=e;}assert.sameValue(caught,reason);assert.sameValue(trace,'AB');

// CASE native-alias-and-distinct-methods [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(parseInt,Number.parseInt),true);assert.sameValue(Object.is(parseInt,parseFloat),false);assert.sameValue(Object.is(Object.is,Object.is),true);assert.sameValue(Object.is(Array.prototype.values,Array.prototype[Symbol.iterator]),true);

// CASE native-prototype-function-identities [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is('a'.slice,'b'.slice),true);assert.sameValue(Object.is('a'.slice,String.prototype.slice),true);assert.sameValue(Object.is(Array.prototype.push,Array.prototype.pop),false);assert.sameValue(Object.is(Object.prototype.toString,Array.prototype.toString),false);

// CASE dom-wrapper-identities [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=document.createElement('div'),b=document.createElement('div');assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);assert.sameValue(Object.is(a.style,a.style),true);assert.sameValue(Object.is(a.style,b.style),false);assert.sameValue(Object.is(a.classList,a.classList),true);assert.sameValue(Object.is(a.classList,b.classList),false);assert.sameValue(Object.is(document,window.document),true);assert.sameValue(Object.is(window,globalThis),true);

// CASE dom-native-method-identity [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=document.createElement('div'),b=document.createElement('div');assert.sameValue(Object.is(a.style.setProperty,b.style.setProperty),true);assert.sameValue(Object.is(a.style.setProperty,a.style.removeProperty),false);

// CASE cycles-never-traversed [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a={},b={};a.self=a;b.self=b;Object.defineProperty(a,'x',{get:function(){throw 'unused';}});assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,b),false);

// CASE buffer-and-view-identities [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var b=new ArrayBuffer(4),v=new DataView(b),w=new DataView(b);assert.sameValue(Object.is(v,v),true);assert.sameValue(Object.is(v,w),false);assert.sameValue(Object.is(v.buffer,b),true);b.transfer();assert.sameValue(Object.is(v.buffer,b),true);assert.sameValue(Object.is(v,w),false);

// CASE object-property-descriptor [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var d=Object.getOwnPropertyDescriptor(Object,'is');assert.sameValue(d.value,Object.is);assert.sameValue(d.writable,true);assert.sameValue(d.enumerable,false);assert.sameValue(d.configurable,true);

// CASE name-length-prototype [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var n=Object.getOwnPropertyDescriptor(Object.is,'name'),l=Object.getOwnPropertyDescriptor(Object.is,'length');assert.sameValue(n.value,'is');assert.sameValue(l.value,2);assert.sameValue(n.writable,false);assert.sameValue(l.writable,false);assert.sameValue(n.enumerable,false);assert.sameValue(l.enumerable,false);assert.sameValue(n.configurable,true);assert.sameValue(l.configurable,true);assert.sameValue(Object.getOwnPropertyDescriptor(Object.is,'prototype'),undefined);assert.sameValue(Object.getPrototypeOf(Object.is),Function.prototype);

// CASE nonconstructability-and-argument-evaluation [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var seen=0;assert.throws(TypeError,function(){new Object.is((seen++,0),0);});assert.sameValue(seen,1);assert.throws(TypeError,function(){Reflect.construct(Object.is,[0,0]);});

// CASE newtarget-rejected-before-argument-list-read [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var reads=0,args={get length(){reads++;throw 'length';}};assert.throws(TypeError,function(){Reflect.construct(function(){},args,Object.is);});assert.sameValue(reads,0);

// CASE borrowed-call-apply-bound [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var f=Object.is,b=f.bind({ignored:true},NaN);assert.sameValue(f(2,2),true);assert.sameValue(f.call(7,-0,0),false);assert.sameValue(f.apply(null,[NaN,NaN]),true);assert.sameValue(b(NaN),true);assert.throws(TypeError,function(){new b(NaN);});

// CASE prototype-hooks-never-read [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var p={get constructor(){throw 'constructor';},get valueOf(){throw 'valueOf';}},a=Object.create(p);assert.sameValue(Object.is(a,a),true);assert.sameValue(Object.is(a,null),false);assert.sameValue(Object.is(a,Object.create(p)),false);

// CASE delete-and-restore-preserves-saved-function [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var d=Object.getOwnPropertyDescriptor(Object,'is'),f=Object.is;try{assert.sameValue(delete Object.is,true);assert.sameValue(Object.getOwnPropertyDescriptor(Object,'is'),undefined);assert.sameValue(f(NaN,NaN),true);}finally{Object.defineProperty(Object,'is',d);}assert.sameValue(Object.is,f);

// CASE long-string-success [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=new Array(8193).join('x'),b=a.slice(0);assert.sameValue(Object.is(a,b),true);assert.sameValue(Object.is(a,b+'y'),false);

// CASE large-extra-values-ignored [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=new Array(16385).join('x'),b=new Array(4096);assert.sameValue(Object.is(1,1,a,b),true);assert.sameValue(Object.is(a,null,a,b),false);

// CASE terminal-repeated-string-comparison [resource]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=new Array(4097).join('x'),b=a.slice(0);for(var i=0;i<200;i++)Object.is(a,b);throw new Test262Error('comparison work did not stop');

// CASE terminal-string-budget-not-catchable [resource]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var a=new Array(4097).join('x'),b=a.slice(0),caught=false;try{for(var i=0;i<200;i++)Object.is(a,b);}catch(e){caught=true;}throw new Test262Error('terminal comparison work was catchable or absent');

// CASE proxy-identity-no-traps [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var p=new Proxy({}, {get:function(){throw 'trap';}});assert.sameValue(Object.is(p,p),true);assert.sameValue(Object.is(p,{}),false);

// CASE bigint-identity-and-number-distinction [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
assert.sameValue(Object.is(1n,1n),true);assert.sameValue(Object.is(1n,1),false);assert.sameValue(Object.is(0n,-0n),true);

// CASE foreign-realm-object-identity [pass]
assert.sameValue(typeof Object.is,'function');assert.sameValue(Object.is(NaN,NaN),true);assert.sameValue(Object.is(0,-0),false);
var r=$262.createRealm(),o=r.evalScript('({})');assert.sameValue(Object.is(o,o),true);assert.sameValue(Object.is(o,{}),false);
