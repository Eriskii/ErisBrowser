#!/usr/bin/env python3
"""Read-only authenticated Object/is collection; scratch outputs only."""
import collections,hashlib,importlib.util,json,sys,time,urllib.request
from pathlib import Path
sys.dont_write_bytecode=True
OUT=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
TREE='04a0f3e25947dbc1100ba4b4138765366d9704b4'
CACHE=Path('/tmp/eris-object-integrity-upstream')
DV=Path('/tmp/eris-data-view-upstream-20261002')
sha=lambda b:hashlib.sha256(b).hexdigest()
def save(p,b):
 p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():assert p.read_bytes()==b,p
 else:p.write_bytes(b)
def document(url,target):
 if target.exists():return target.read_bytes()
 rec={'url':url,'target':str(target.relative_to(OUT)),'start':time.time()}
 try:
  with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Eris-pinned-Object-is-preparation'}),timeout=30) as r:
   b=r.read(4*1024*1024+1);rec['status']=r.status
  assert len(b)<=4*1024*1024
  save(target,b);rec.update(success=True,bytes=len(b),sha256=sha(b));return b
 except Exception as e:rec.update(success=False,error=type(e).__name__,message=str(e));raise
 finally:
  rec['end']=time.time();p=OUT/'requests';p.mkdir(exist_ok=True)
  n=len(list(p.glob('*.json')))+1;save(p/f'{n:03}.json',(json.dumps(rec,indent=2)+'\n').encode())
spec=importlib.util.spec_from_file_location('scratch_importer',OUT/'import_test262.py');imp=importlib.util.module_from_spec(spec);spec.loader.exec_module(imp)
def read(route):
 p=OUT/imp.tree_proof_path(route)
 if p.exists():return p.read_bytes()
 name=p.name
 for q in [CACHE/name,DV/'inventory-proof'/name]:
  if q.is_file():
   b=q.read_bytes();save(p,b);return b
 return document('https://api.github.com/repos/tc39/test262/git/'+route,p)
imp.ITERATION_SUBTREES['object-is']={'Object/is':TREE}
rec=read('trees/'+TREE+'?recursive=1');v=json.loads(rec)
assert v['sha']==TREE and v['truncated'] is False
counts={'Object/is':0}
for e in v['tree']:
 if e['type']=='tree':counts['Object/is/'+e['path']]=0
for e in v['tree']:
 if e['type']=='blob':counts['Object/is'+('/'+e['path'].rpartition('/')[0] if '/' in e['path'] else '')]+=1
imp.PROFILES['object-is']=counts;imp.PROFILE_ROOTS['object-is']='test/built-ins';imp.ITERATION_SUBTREES['object-is']={'Object/is':TREE};imp.ITERATION_HELPERS['object-is']={'assert.js','sta.js'}
listings,proof,description=imp.iteration_tree_inventory('object-is',read=read)
helpers={'assert.js','sta.js'};rows=[];features=collections.Counter();flags=collections.Counter()
for folder,listing in sorted(listings.items()):
 for e in sorted(listing,key=lambda e:e['name']):
  p='test/built-ins/'+folder+'/'+e['name'];b=document('https://raw.githubusercontent.com/tc39/test262/'+REV+'/'+p,OUT/p)
  blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert blob==e['sha']
  metadata=imp.parse_metadata(b.decode());helpers.update(metadata['includes']);f=set(metadata['flags'])
  if 'async' in f:helpers.add('doneprintHandle.js')
  modes=['module'] if 'module' in f else ['raw'] if 'raw' in f else ['strict'] if 'onlyStrict' in f else ['sloppy'] if 'noStrict' in f else ['sloppy','strict']
  features.update(metadata['features']);flags.update(metadata['flags'])
  rows.append(dict(path=p,bytes=len(b),sha256=sha(b),git_blob=blob,metadata=metadata,modes=modes))
imp.ITERATION_HELPERS['object-is']=helpers
listings,proof,description=imp.iteration_tree_inventory('object-is',read=read)
aux=[]
for p,blob in sorted(description['auxiliary_blobs'].items()):
 b=None
 for c in [CACHE/p,DV/p,ROOT/'tests/upstream/test262'/p]:
  if c.is_file():
   raw=c.read_bytes()
   if hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==blob:b=raw;break
 if b is None:b=document('https://raw.githubusercontent.com/tc39/test262/'+REV+'/'+p,OUT/p)
 save(OUT/p,b);assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==blob
 aux.append(dict(path=p,bytes=len(b),sha256=sha(b),git_blob=blob))
controls=[]
for name,mut in [('truncated',lambda t:t.update(truncated=True)),('omitted-source',lambda t:t['tree'].pop()),('duplicate-source',lambda t:t['tree'].append(t['tree'][0].copy())),('substituted-blob',lambda t:t['tree'][0].update(sha='0'*40)),('wrong-root',lambda t:t.update(sha='0'*40)),('nonregular-mode',lambda t:t['tree'][0].update(mode='120000'))]:
 bad=json.loads(rec);mut(bad)
 def badread(route):return json.dumps(bad).encode() if route=='trees/'+TREE+'?recursive=1' else read(route)
 try:imp.iteration_tree_inventory('object-is',read=badread)
 except ValueError as e:controls.append({'case':name,'rejected':True,'error':str(e)})
 else:raise AssertionError(name)
summary=dict(schema=1,revision=REV,root_tree=imp.REVISION_TREE,subtree_tree=TREE,source_files=len(rows),mode_cases=sum(len(r['modes']) for r in rows),source_bytes=sum(r['bytes'] for r in rows),directories=counts,helpers=sorted(helpers),features_by_source=dict(sorted(features.items())),flags_by_source=dict(sorted(flags.items())),sources=rows,auxiliary=aux,proof=description,proof_files=[dict(path=p,bytes=len(b),sha256=sha(b)) for p,b in sorted(proof.items())],malformed_proof_controls=controls,source_execution=False,repository_edits=False)
save(OUT/'inventory.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps({k:summary[k] for k in ['revision','subtree_tree','source_files','mode_cases','source_bytes','helpers','features_by_source','flags_by_source']},indent=2))
