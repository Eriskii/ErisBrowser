#!/usr/bin/env python3
"""Retain preparation and before observations without copying executables."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import tarfile

HERE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUTPUT=ROOT/'docs/evidence/object-is-preparation'

def require(ok, message):
    if not ok:
        raise ValueError(message)

def digest(raw):
    return hashlib.sha256(raw).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def save(path, data):
    with Path(path).open('x') as handle:
        json.dump(data,handle,indent=2)
        handle.write('\n')

def add(archive, name, raw):
    info=tarfile.TarInfo(name)
    info.size=len(raw)
    info.mode=0o644
    info.mtime=0
    archive.addfile(info,io.BytesIO(raw))

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    require(__debug__,'Optimized Python is not allowed')
    formal=read(HERE/'formal-before/execution.json')
    local=read(HERE/'local-before/execution.json')
    require(formal.get('all_bindings_unchanged_after_execution') and formal.get('leader_reaped')
            and 'failure' not in formal,'Incomplete formal BEFORE')
    require(local.get('completed') and local.get('post_inputs_unchanged')
            and 'failure' not in local,'Incomplete local BEFORE')
    require(not OUTPUT.exists(),'Refusing to replace public evidence')
    records=[];omitted=[]
    for path in sorted(HERE.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        require(not path.is_symlink(),'No symlink payloads')
        relative=str(path.relative_to(HERE))
        require(relative not in {'MANIFEST.json'},'Reserved archive name')
        raw=path.read_bytes()
        require(not raw.startswith(b'\x7fELF'),'Executable payload forbidden')
        record=dict(path=relative,bytes=len(raw),sha256=digest(raw))
        # Retain primary-spec URLs/section snapshots and full-page hashes;
        # publishing whole downloaded specification pages is unnecessary.
        if relative.startswith('spec/') and path.suffix=='.html':
            omitted.append(dict(record,reason='Full specification page remains in scratch; linked section and page hashes retained.'))
        else:
            records.append(record)
    manifest=dict(schema=1,scope='Object.is preparation and original BEFORE only; no implementation results',
                  parent_commit='f55911e2fd3ead3f42fa59718016c215b6c4a48f',
                  files=records,omitted=omitted)
    raw_manifest=(json.dumps(manifest,indent=2)+'\n').encode()
    if not args.execute:
        print(json.dumps(dict(inert=True,payloads=len(records),raw_bytes=sum(r['bytes'] for r in records),
                              manifest_sha256=digest(raw_manifest))))
        return
    OUTPUT.mkdir()
    archive_path=OUTPUT/'records.tar.gz'
    with archive_path.open('xb') as handle:
        with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as compressed:
            with tarfile.open(fileobj=compressed,mode='w|',format=tarfile.PAX_FORMAT) as archive:
                add(archive,'MANIFEST.json',raw_manifest)
                for row in records:
                    raw=(HERE/row['path']).read_bytes()
                    require(len(raw)==row['bytes'] and digest(raw)==row['sha256'],'Input changed while packaging')
                    add(archive,row['path'],raw)
    save(OUTPUT/'index.json',dict(schema=1,phase='Preparation; no Object.is runtime implementation',
        parent_commit=manifest['parent_commit'],archive=dict(path='records.tar.gz',bytes=archive_path.stat().st_size,
            sha256=digest(archive_path.read_bytes())),manifest_sha256=digest(raw_manifest),
        payloads=len(records),raw_bytes=sum(r['bytes'] for r in records),
        upstream=dict(sources=21,cases=42,controls=80,exclusions=0,report='formal-before/object-is.json'),
        local=dict(sources=39,cases=78,feature_controls=48,common_controls=12,report='local-before/report.json'),
        omissions=omitted,
        provenance=['Original and corrected drafts, static errors and reviewer retractions are retained.',
                    'Complete current runtime source archive and executable hashes bind the published DataView parent; binaries are not repackaged.',
                    'No prior contract, baseline, source expectation, or execution quota changes.']))
    print(json.dumps(dict(index_sha256=digest((OUTPUT/'index.json').read_bytes()),
                          archive_sha256=digest(archive_path.read_bytes()),payloads=len(records))))

if __name__=='__main__':
    main()
