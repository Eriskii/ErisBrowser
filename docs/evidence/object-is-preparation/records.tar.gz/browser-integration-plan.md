# Proposed Object.is browser integration

Scratch-only proposal following the published DataView fixture seams; no repository changes or execution. Keep this small ordinary-success document separate from the local/formal policy populations. It does not test or exclude the two known Document/Element method-identity gaps.

## Existing seams and owned paths after approval

Add only `tests/fixtures/object-is.html` and one test each in `tests/pipeline.rs` and `tests/worker.rs`. Reuse the existing six-sample HTML layout and helpers unchanged:

- `tests/pipeline.rs:212`, `assert_six_scripted_samples_with_result_text`: parse/script the page, render 320x240, verify diagnostics, body class, result text and six literal pixel samples, click through `Page::click`, repeat.
- `tests/worker.rs:315`, `assert_six_scripted_samples_through_worker_with_result_text`: load the same source in the confined worker and direct Page, click through the actual worker command, require both result texts and allowed process-only diagnostics, compare complete Canvas pixels, then check the six independently expected pixels.
- Follow `tests/fixtures/data-view.html` for markup/CSS and initial/click event structure, without changing that existing fixture.

Suggested test names: `object_is_same_value_and_saved_identity_survive_document_callbacks` and `confined_object_is_same_value_and_saved_identity_survive_document_callbacks`. The worker test keeps its Linux Landlock ABI 6 ignore requirement; generation 197 is currently unused in this file. Root owns final integration paths/fixture freeze and actual runs.

## Six independent semantic groups

Use six initially red, absolute 40x40 boxes at left 0/50/100/150/200/250 and top0. A group marks its own box only after all of its assertions pass. Green is literal RGB 0x008000 and blue is 0x0000ff, exactly as the existing helper expects at x10/60/110/160/210/260, y10. Button at y60, result at y100; no external resources.

Capture `const same=Object.is`, `const token=Symbol('token')`, `const saved={n:1}` and `let runs=0` once in page script. Require `typeof same==='function'` before use. Define `check` as a plain throw-on-false function, without Test262 helpers. `apply(color)` checks `runs===(color==='green'?0:1)`, performs the six groups, then increments runs. Proposed assertions:

1. **Numbers:** `same(NaN,0/0)`, `same(-0,-0)`, `same(0,0)`, `!same(0,-0)`, `!same(-0,0)`, `same(Infinity,Infinity)`, `!same(Infinity,-Infinity)`. The expectations are literal SameValue rules; do not derive them from candidate operations such as serialization.
2. **UTF-16:** `same('\uD800','\uD800')`, `!same('\uD800','\uDC00')`, `same('a\u0000b','a\u0000b')`, `!same('\u00E9','e\u0301')`, `!same('1',1)`. Keep each escape a single backslash in HTML source; no normalization or surrogate replacement.
3. **Symbols:** `same(token,token)`, `!same(token,Symbol('token'))`, `!same(token,'token')`. Require callable Symbol before creating token, so any missing prerequisite produces an ordinary diagnostic rather than certifying an exception assertion.
4. **Objects and retained state:** `same(saved,saved)`, `!same(saved,{n:saved.n})`, `!same([],[])`, with `saved.n===(color==='green'?1:2)`. Compare a saved author function with itself and a distinct function with equivalent source; require true/false respectively. These are existing arena identities, not defining-interface host functions.
5. **No coercion; expression order and ignored argument:** create `const poison={get valueOf(){throw new Error('unused valueOf');},get toString(){throw new Error('unused toString');}}`. Require `same(poison,poison)` and `!same(poison,1)`. Let `trace=''`; `first(){trace+='A';return NaN;}`, `second(){trace+='B';return NaN;}`, `extra(){trace+='E';return poison;}`. Require `same(first(),second(),extra())` and `trace==='ABE'`. This observes evaluation of the extra argument while proving its returned object is not converted. No caught incidental error is treated as success.
6. **Intrinsic contract:** require `same()`, `same(undefined,undefined)`, `!same(null,undefined)`, `same.name==='is'`, `same.length===2`, and no own prototype descriptor. Read the Object.is descriptor and require `d.value===same`, writable/configurable true, enumerable false. Read name/length descriptors and require their literal values plus writable/enumerable false and configurable true. This group can use the existing supported Object descriptor APIs; construction variants remain in the independent local/formal suites.

On initial success, all six boxes are green, result text is `ready` and body class is `ready`.

The click callback first proves the captured intrinsic survives ordinary property replacement: save its descriptor, set `Object.is=function(){throw new Error('replacement');}`, call `same(NaN,NaN)` and `same(saved,saved)` successfully, then restore the saved descriptor with Object.defineProperty. Require current Object.is identity equals the captured `same`. Set `saved.n=2`, call `apply('blue')`, require runs2, set result text to literal `6` and body class to `clicked`. The boxes turn blue only through assertions performed again in the event callback. No navigation is expected.

## Bounded scope and later validation

The source is a few kilobytes, has no large strings, loops, generated source, networking, resource-limit policy test or optional realm/Proxy/BigInt dependency. Only the initial Symbol, one saved object and one saved intrinsic survive to the click. The fixture deliberately does not compare DOM method function identities; DOM access is used only for actual visible mutation through established APIs.

Freeze the source and literal state/pixel expectations before its first run. Reuse the unchanged helper assertions with `Some(["ready", "6"])`. After runtime release/build, root can run each named pipeline and ignored worker test under the normal matrix. A direct-only pass does not establish confined-worker behavior; an ignored test declaration is not an execution. Retain any first setup/compiler/runtime failure and correct only a demonstrated fixture prerequisite before a separate candidate freeze. Existing DataView fixture and all local/formal expectations remain unchanged.
