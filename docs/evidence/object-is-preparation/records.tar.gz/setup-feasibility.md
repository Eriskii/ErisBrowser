# Revised large-string setup: static feasibility

This is a source/arithmetic check, not a compiler, parser or engine result. `check-setup-feasibility.py` only reads four already-authored source strings and applies integer formulas; `setup-feasibility.json` binds every source hash. Original drafts/logs are unchanged.

## Why the original setup was invalid

`new Array(N)` creates a logical sparse array, not N initialized values (`script.rs:8479–8494`). Its join performs a generic indexed Get for each hole. The peer's independent lower bound is already106,521 charged work for4,097 holes, before most Object.prototype and key-digit work. Thus the original ordinary cases could terminate in setup, and the original terminal cases could report resource without reaching Object.is. The original fixture semantics/results must not be described as observations; none was executed.

Version2 uses authored ASCII literals. Each repeated comparison has two separate literal tokens, so it does not depend on `slice`, `join`, `repeat`, string conversion or a runtime doubling loop. The only remaining `new Array(4096)` is an ignored extra argument value: its constructor sets logical length on an empty backing vector and does not enumerate holes. No getter traversal follows from its construction.

## Width-dependent costs are bounded and prepaid

For an unescaped ASCII literal with L code units, the current quoted scanner charges exactly `L+2+floor((L+2)/8)` work: one per content/closing character plus its final scan allowance (`script.rs:379–544`). Whole-source lexing separately charges `1+source_bytes/4`; ASCII identifier tokens charge `1+name_bytes/8`. None of these is the execution budget used later: the existing parser has its own100,000 budget and execute_program establishes the unchanged execution budget after compilation. This preparation adds no reset.

A conservative upper bound for the scanner's cumulative requested string storage is `18*L +80 +32*(1+ceil(log2(L+1)))`. It includes the initial allocation charge, eight bytes per reached content/closing character, every requested growth block, headers, and the final Rc conversion. The growth sum is bounded even if reserve_exact grants extra capacity: a reached growth requires old capacity<L+2, so the new requested capacity is at most2*(L+1); greater actual capacity removes later growth. This is logical requested accounting, not a bound on unspecified allocator rounding/overhead.

| Case | Source bytes | Non-whitespace tokens | Large literal lengths | Exact quoted/base-lex/identifier work | Quote storage + source-retention bytes |
|---|---:|---:|---|---:|---:|
| Ordinary equal string |16,672|110|8,192 +8,192|22,668|346,594|
| Ignored extra values |16,693|120|16,384|22,672|345,967|
| Repeated comparison policy |8,529|122|4,096 +4,096|11,451|175,259|
| Catchability policy |8,589|139|4,096 +4,096|11,496|175,831|

All literals are below262,144 code units; all sources are below262,144 bytes; all token counts are below32,768. The quoted payload does not cause a proportional number of AST records: each literal is one token and one expression record. The remaining grammar is the same small fixed call/member/var/for/try/throw shape regardless of literal width, with no template/regexp relex, function-body generation, destructuring or recursive data initializer. At least77,328 compile work units remain after the exact width-dependent terms. That leaves the short fixed syntax and its paged records substantial margin; there is no hole-by-hole or character-by-character runtime setup path.

At execution, `machine.rs:548` clones each precompiled literal's Rc handle. The new source performs two or three ordinary var initializations plus fixed length/assertion checks; it does not copy or scan the large payload until Object.is. `execute_program` charges source retention and compiled_storage, so the quoted scanner's cumulative storage is counted rather than omitted. The ordinary8,192-unit case additionally evaluates `b+'y'` only after a successful equal-string comparison; its existing addition path explicitly debits2,049 work and32,836 bytes for8,193 code units, plus fixed dispatch/primitive handling.

These arithmetic terms establish feasibility of the replacement setup under the existing per-source caps and remove the identified incidental source of terminal work. They are not a fabricated complete-run heap total: token/record/list headers, assertion-call state, bootstrap, the selected Object.is installer and previously loaded harness remain separately charged. The eventual runner freeze must retain their usual input/budget checks and actual observations. No present or future pass claim should replace that validation with this table.

## The policy target is reached before repetition

Both policy sources first assert both literal lengths and then **successfully evaluate and assert `Object.is(a,b) === true`** before entering the200-iteration loop. A setup or first-comparison problem therefore remains distinguishable during private prefix validation; the resource population is never a success claim about missing Object.is.

Under the proposed equal-length debit, one4,096-unit comparison costs `2+4096/8+4096/8 =1026` payload work, excluding the fixed dispatch and ordinary expression/call work. Two hundred reached comparisons demand205,200 payload units, which cannot fit the unchanged100,000 execution limit. The first comparison requires only1,026 payload work and no result allocation. Extra arguments and receivers are not involved in these terminal cases.

Public terminal status alone still cannot prove which debit stopped a program. Required private tests must execute/inspect the setup-and-first-comparison prefix under a fresh ordinary budget after implementation, then isolate the borrowed comparison helper with exact/one-short work and full-heap cutpoints. They must also verify prior effects and terminal cleanup. Those tests are planned, not run; no source/oracle/quota change can be justified by an incidental resource result.
