#[test]
    fn inline_pending_shorthands_preserve_order_and_safe_overrides() {
        let mut s = parse(
            "--space:2px; margin-top:1px; margin:var(--space); background:var(--Tone); color:red",
        );
        assert_eq!(get(&s, "margin"), "var(--space)");
        assert_eq!(get(&s, "margin-top"), "");
        assert!(set(&mut s, "color", "green", ""));
        assert!(text(&s).contains("margin: var(--space)"));
        assert!(text(&s).contains("background: var(--Tone)"));
        assert!(set(&mut s, "margin-top", "10px", ""));
        assert_eq!(get(&s, "margin-top"), "10px");
        assert_eq!(get(&s, "margin"), "");
        let before = s.clone();
        assert_eq!(
            s.remove_property("margin-top", &mut WORK.clone()).unwrap(),
            ""
        );
        assert_eq!(s, before);
        assert!(set(&mut s, "margin", "4px", ""));
        assert_eq!(get(&s, "margin"), "4px");
        let mut s = parse("margin:var(--x) !important");
        let before = s.clone();
        assert!(!set(&mut s, "margin-left", "3px", ""));
        assert_eq!(s, before);
        assert!(set(&mut s, "margin-left", "3px", "important"));
        assert_eq!(get(&s, "margin-left"), "3px");
    }
