#[test]
fn pending_seven_targets_keep_identity_priority_and_atomic_removal() {
    let mut pending = parse("background:var(--Saved)");
    assert_eq!(pending.len(), 1);
    assert_eq!(get(&pending, "background"), "var(--Saved)");
    assert_eq!(
        pending.records[0].pending.as_ref().unwrap(),
        &NAMES.map(str::to_owned)
    );
    assert!(set(&mut pending, "background-origin", "content-box", ""));
    assert_eq!(get(&pending, "background"), "");
    assert_eq!(get(&pending, "background-origin"), "content-box");
    assert_eq!(
        pending
            .remove_property("background", &mut WORK.clone())
            .unwrap(),
        ""
    );
    assert_eq!(pending, InlineStyle::default());
    let mut important = parse("background:var(--Saved)!important");
    let saved = important.clone();
    assert!(!set(&mut important, "background-clip", "content-box", ""));
    assert_eq!(important, saved);
    assert!(set(
        &mut important,
        "background-clip",
        "content-box",
        "important"
    ));
    assert_eq!(get(&important, "background"), "");
    assert_eq!(parse(&text(&important)), important);
}
