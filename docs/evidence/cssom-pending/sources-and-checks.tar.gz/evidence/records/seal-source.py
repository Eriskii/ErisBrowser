from pathlib import Path
import json,hashlib,difflib
b=Path('/tmp/eris-cssom-pending-1/records')
def bind(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
paths=['src/cssom.rs','src/cssom/background_tests.rs','src/cssom/background_box_tests.rs','src/cssom/pending_record_tests.rs','src/cssom/pending_record_accounting_tests.rs']
for n in ['pending_record_tests.rs','pending_record_accounting_tests.rs']:
 assert (b/'raw/src/cssom'/n).read_bytes()==(b/'tests-before'/n).read_bytes()
for n in ['background_tests.rs','background_box_tests.rs']:
 assert (b/'raw/src/cssom'/n).read_bytes()==(b/'migrations-before/raw/src/cssom'/n).read_bytes()
# Existing nested unit tests equal the selected tests-first migration exactly.
new=(b/'raw/src/cssom.rs').read_text();old=(b/'migrations-before/raw/src/cssom.rs').read_text()
a=old.index('#[cfg(test)]\nmod tests {')
a2=new.index('#[cfg(test)]\nmod tests {')
assert new[a2:].startswith(old[a:])
patch=''
for rel in paths:
 p=b/'before'/rel;before=p.read_text() if p.exists() else ''
 after=(b/'raw'/rel).read_text()
 patch+=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel))
(b/'source.patch').write_text(patch)
notes={'status':'source draft ready for independent peer and root integration; no execution',
 'scope':'Unique ordered longhand records with content-equal shared pending source; cached accounting; ordinary expanded compatibility serialization; Prepared ownership API.',
 'invariants':['Every pending record name is a target of its original shorthand; public mutation paths preserve unique names.', 'Parse merges by importance and last winning source position; setters replace each existing target in place regardless of old priority.', 'Factory record cleanup paid before construction; clone cleanup paid before copy; prepare pays new block cleanup before serialization/ownership transfer.', 'Parse summary computed once after incrementally admitted merges; clones recompute actual capacities; staged candidates publish only after summary and content equality prepayments.', 'Serializer uses fixed 256-entry flags; one paid content scan per distinct pending origin, no pointer-identity reconstruction.', 'No scope change to ordinary shorthand formatting, logical aliases, limits, renderer snapshot transport or leaf grammar.'],
 'fees':'Frozen ledger exact. Old literal records add T/F=p+42; singleton important setter totals1079/1124/1061/1106. Serializer461/413, clone1338, prepare606 retained.',
 'dependencies':['HTML allocation-free css::shorthand_property_count (wiring hold).','Selected DOM DomMutationBudget work/charge and Prepared API.'],
 'limits':'Conservative resource accounting uses actual Rust capacities and per-reference pending payload charge; does not claim allocator/RSS/stack measurement.',
 'verification':'Inert source, diff and hash inspection only. All13 frozen groups byte-exact; selected old migrations exact. No formatter/compiler/test/browser/git invocation.'}
(b/'source-notes.json').write_text(json.dumps(notes,indent=2)+'\n')
m={'status':'source-ready; runtime validation pending root','base':'1bbb31efc2413c9732873557d3344e27ae4bc96f','files':[{'intended_path':r,'before':bind(b/'before'/r) if (b/'before'/r).exists() else None,'source':bind(b/'raw'/r)} for r in paths], 'tests_before':bind(b/'tests-before/source-ready.json'),'migrations_before':bind(b/'migrations-before/source-ready.json'),'patch':bind(b/'source.patch'),'notes':bind(b/'source-notes.json'),'execution':'None; external source only.'}
(b/'source-ready.json').write_text(json.dumps(m,indent=2)+'\n');print(bind(b/'source-ready.json'))
