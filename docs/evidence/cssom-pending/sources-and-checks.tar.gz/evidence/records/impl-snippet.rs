fn targets(property: &str, work: &mut usize) -> Result<Vec<String>, Error> {
    let count = css::shorthand_property_count(property).unwrap_or(1);
    spend(work, add(1, mul(count, add(property.len(), 32)?)?)?)?;
    Ok(css::shorthand_properties(property).unwrap_or_else(|| vec![property.into()]))
}
impl InlineStyle {
    fn summarize(records: &Vec<Record>) -> Result<StyleSummary, Error> {
        let mut logical_bytes = 0;
        let mut retained_bytes = add(arc_bytes(), mul(records.capacity(), size_of::<Record>())?)?;
        let mut names_work = 0;
        let mut pending_records = 0;
        for record in records {
            logical_bytes = add(logical_bytes, record.logical_bytes()?)?;
            names_work = add(names_work, add(record.name.len(), 1)?)?;
            let payload = match &record.value {
                RecordValue::Tokens(tokens) => tokens.capacity(),
                RecordValue::Pending(pending) => {
                    pending_records += 1;
                    add(add(4 * size_of::<usize>(), size_of::<PendingValue>())?,
                        add(pending.tokens.capacity(), pending.shorthand.len())?)?
                }
            };
            retained_bytes = add(retained_bytes, add(record.name.capacity(), payload)?)?;
        }
        if records.len() > MAX_DECLARATIONS || logical_bytes > MAX_INLINE_BYTES {
            return Err(Error::Limit);
        }
        let release_work = add(add(1, records.len())?, logical_bytes)?;
        let clone_work = add(add(summary_work(records.len())?, logical_bytes)?, release_work)?;
        Ok(StyleSummary { logical_bytes, retained_bytes, clone_work, release_work,
            names_work, pending_records })
    }
    fn refresh_summary(&mut self, work: &mut usize) -> Result<(), Error> {
        spend(work, summary_work(self.records.len())?)?;
        self.summary = Self::summarize(&self.records)?;
        Ok(())
    }
    #[cfg(test)]
    fn from_records_for_test(records: Vec<Record>) -> Self {
        let summary = Self::summarize(&records).expect("bounded test records");
        Self { records, summary }
    }
    pub(crate) fn logical_bytes(&self) -> usize { self.summary.logical_bytes }
    pub(crate) fn retained_bytes(&self) -> usize { self.summary.retained_bytes }
    pub(crate) fn clone_work(&self) -> usize { self.summary.clone_work }
    pub(crate) fn release_work(&self) -> usize { self.summary.release_work }
    pub(crate) fn declarations(&self) -> impl ExactSizeIterator<Item = InlineDeclarationRef<'_>> {
        self.records.iter().map(|record| InlineDeclarationRef {
            name: &record.name,
            value: record.value.source(),
            important: record.important,
            pending_shorthand: record.value.pending().map(|p| &p.shorthand),
        })
    }
    pub(crate) fn try_clone_for_edit(&self, budget: &mut DomMutationBudget) -> Result<Self, DomDataError> {
        budget.work(self.clone_work())?;
        budget.charge(self.retained_bytes())?;
        Ok(self.clone())
    }
    pub(crate) fn prepare_commit(self, budget: &mut DomMutationBudget) -> Result<PreparedInlineStyle, DomDataError> {
        // Pays incoming-block teardown even when serialization or later DOM admission refuses.
        budget.work(self.release_work().checked_add(2).ok_or(DomDataError::LimitExceeded)?)?;
        budget.charge(self.logical_bytes().checked_add(arc_bytes()).ok_or(DomDataError::LimitExceeded)?)?;
        let serialized = self.serialize(&mut budget.steps).map_err(|_| DomDataError::LimitExceeded)?;
        Ok(PreparedInlineStyle { style: Arc::new(self), serialized })
    }
    pub(crate) fn parse(source: &str, work: &mut usize) -> Result<Self, Error> {
        if source.len() > MAX_INLINE_BYTES { return Err(Error::Limit); }
        let tokens = selectors::tokens(source, work).map_err(|_| Error::Limit)?;
        spend(work, tokens.len().saturating_mul(2) + 1)?;
        let mut style = Self::default();
        let mut depth = 0usize;
        let mut start = 0;
        for (i, token) in tokens.iter().enumerate() {
            if token.open().is_some() {
                depth += 1;
                if depth > MAX_DEPTH { return Err(Error::Limit); }
            } else if matches!(token.kind, Kind::Close(_)) {
                depth = depth.saturating_sub(1);
            } else if token.kind == Kind::Delim(';') && depth == 0 {
                style.parse_part(source, &tokens[start..i], work)?;
                start = i + 1;
            }
        }
        style.parse_part(source, &tokens[start..], work)?;
        style.refresh_summary(work)?;
        Ok(style)
    }
    fn parse_part(&mut self, source: &str, tokens: &[Token<'_>], work: &mut usize) -> Result<(), Error> {
        let significant: Vec<_> = tokens.iter().filter(|t| t.kind != Kind::Whitespace).collect();
        let [property, colon, rest @ ..] = significant.as_slice() else { return Ok(()); };
        if property.kind != Kind::Ident || colon.kind != Kind::Delim(':') { return Ok(()); }
        let Some((decoded, consumed)) = css::css_identifier(property.raw) else { return Ok(()); };
        if consumed != property.raw.len() { return Ok(()); }
        let Some(property) = name(&decoded) else { return Ok(()); };
        let important = rest.len() >= 2
            && rest[rest.len()-2].kind == Kind::Delim('!')
            && rest[rest.len()-1].kind == Kind::Ident
            && rest[rest.len()-1].is_name("important");
        let end = if important { rest[rest.len()-2].start }
            else { tokens.last().map_or(colon.end, |t| t.end) };
        let value = &source[colon.end..end];
        if value.len() > MAX_VALUE_BYTES { return Err(Error::Limit); }
        if let Some(records) = records(&property, value, important, work)? {
            for record in records {
                spend(work, add(self.summary.names_work, add(record.name.len(), 1)?)?)?;
                let index = self.records.iter().position(|old| old.name == record.name);
                if index.is_some_and(|i| self.records[i].important && !record.important) { continue; }
                self.admit_replacement(index, &record)?;
                // Parse precedence retains the last winning source position.
                if let Some(index) = index { self.records.remove(index); }
                self.records.push(record);
            }
        }
        Ok(())
    }
    // Called only inside a funded merge/mutation pass; keep admission metadata
    // incremental so no record-vector growth precedes count/logical admission.
    fn admit_replacement(&mut self, index: Option<usize>, replacement: &Record) -> Result<(), Error> {
        let old = index.map(|i| &self.records[i]);
        let old_bytes = old.map_or(Ok(0), Record::logical_bytes)?;
        let new_bytes = replacement.logical_bytes()?;
        let logical = add(self.summary.logical_bytes.checked_sub(old_bytes).ok_or(Error::Limit)?, new_bytes)?;
        let count = add(self.records.len(), usize::from(index.is_none()))?;
        if logical > MAX_INLINE_BYTES || count > MAX_DECLARATIONS { return Err(Error::Limit); }
        let old_names = old.map_or(0, |r| r.name.len()+1);
        self.summary.names_work = add(self.summary.names_work.checked_sub(old_names).ok_or(Error::Limit)?, replacement.name.len()+1)?;
        self.summary.logical_bytes = logical;
        Ok(())
    }
    pub(crate) fn len(&self) -> usize { self.records.len() }
    pub(crate) fn item(&self, index: usize) -> &str {
        self.records.get(index).map_or("", |record| record.name.as_str())
    }
    fn query_targets(&self, property: &str, work: &mut usize) -> Result<Option<(String, Vec<String>)>, Error> {
        spend(work, property.len().saturating_add(1))?;
        let Some(normalized) = name(property) else {
            spend(work, add(self.summary.names_work, add(property.len(), 1)?)?)?;
            return Ok(None);
        };
        let names = targets(&normalized, work)?;
        spend(work, mul(add(self.summary.names_work, add(property.len(), 1)?)?, names.len().max(1))?)?;
        Ok(Some((normalized, names)))
    }
    fn winner(&self, property: &str) -> Option<&Record> {
        self.records.iter().find(|record| record.name == property)
    }
    pub(crate) fn get_property_value(&self, property: &str, work: &mut usize) -> Result<String, Error> {
        let Some((property, names)) = self.query_targets(property, work)? else { return Ok(String::new()); };
        if css::shorthand_property_count(&property).is_none() {
            let value = self.winner(&property).and_then(|record| match &record.value {
                RecordValue::Tokens(tokens) => Some(tokens.as_str()), RecordValue::Pending(_) => None,
            }).unwrap_or("");
            spend(work, value.len()+1)?;
            return Ok(value.into());
        }
        // This prepayment precedes any pending-source content/importance checks.
        if self.summary.pending_records != 0 { spend(work, add(self.logical_bytes(), 1)?)?; }
        let values: Option<Vec<_>> = names.iter().map(|p| self.winner(p)).collect();
        let Some(values) = values else { return Ok(String::new()); };
        if values.iter().any(|r| r.important != values[0].important) { return Ok(String::new()); }
        if let Some(pending) = values[0].value.pending() {
            if pending.shorthand.as_ref() == property && values.iter().all(|r| r.value.pending() == Some(pending)) {
                spend(work, pending.tokens.len()+1)?;
                return Ok(pending.tokens.clone());
            }
            return Ok(String::new());
        }
        if values.iter().any(|r| r.value.pending().is_some()) { return Ok(String::new()); }
        let raw: Vec<_> = values.iter().map(|r| r.value.source()).collect();
        spend(work, raw.iter().map(|v| v.len()+1).sum::<usize>().saturating_mul(4)+1)?;
        if property == "background" && !raw.iter().all(|v| *v == raw[0] && wide(v)) {
            return css::serialize_background_shorthand(&raw, work).map_err(|_| Error::Limit);
        }
        Ok(shorthand_value(&property, &raw))
    }
    pub(crate) fn get_property_priority(&self, property: &str, work: &mut usize) -> Result<&'static str, Error> {
        let Some((_, names)) = self.query_targets(property, work)? else { return Ok(""); };
        Ok(if names.iter().all(|p| self.winner(p).is_some_and(|r| r.important)) { "important" } else { "" })
    }
    fn mutation_work(&self, property: &str, count: usize, work: &mut usize) -> Result<(), Error> {
        spend(work, add(1, mul(mul(2, count)?, add(self.summary.names_work, add(property.len(),1)?)?)?)?)
    }
    fn commit_staged(&mut self, mut staged: Self, work: &mut usize) -> Result<bool, Error> {
        staged.refresh_summary(work)?;
        spend(work, add(1, mul(2, add(self.logical_bytes(), staged.logical_bytes())?)?)?)?;
        let changed = *self != staged;
        *self = staged;
        Ok(changed)
    }
    pub(crate) fn set_property(&mut self, property: &str, value: &str, priority: &str, work: &mut usize) -> Result<bool, Error> {
        spend(work, property.len().saturating_add(value.len()).saturating_add(priority.len()).saturating_add(1))?;
        let Some(property) = name(property) else { return Ok(false); };
        if value.is_empty() {
            let before = self.records.len(); self.remove_property(&property, work)?;
            return Ok(before != self.records.len());
        }
        if !(priority.is_empty() || priority.eq_ignore_ascii_case("important")) { return Ok(false); }
        if value.len() > MAX_VALUE_BYTES { return Err(Error::Limit); }
        let Some(replacements) = records(&property, value, !priority.is_empty(), work)? else { return Ok(false); };
        let Some((_, names)) = self.query_targets(&property, work)? else { return Ok(false); };
        spend(work, self.clone_work())?;
        self.mutation_work(&property, names.len(), work)?;
        let mut staged = self.clone();
        for replacement in replacements {
            let index = staged.records.iter().position(|r| r.name == replacement.name);
            staged.admit_replacement(index, &replacement)?;
            if let Some(index) = index { staged.records[index] = replacement; }
            else { staged.records.push(replacement); }
        }
        self.commit_staged(staged, work)
    }
    pub(crate) fn remove_property(&mut self, property: &str, work: &mut usize) -> Result<String, Error> {
        let previous = self.get_property_value(property, work)?;
        let Some((property, names)) = self.query_targets(property, work)? else { return Ok(previous); };
        spend(work, self.clone_work())?;
        self.mutation_work(&property, names.len(), work)?;
        let mut staged = self.clone();
        staged.records.retain(|r| !names.contains(&r.name));
        self.commit_staged(staged, work)?;
        Ok(previous)
    }
    fn check_size(&self) -> Result<(), Error> {
        if self.records.len() > MAX_DECLARATIONS || self.logical_bytes() > MAX_INLINE_BYTES { Err(Error::Limit) } else { Ok(()) }
    }
    pub(crate) fn serialize(&self, work: &mut usize) -> Result<String, Error> {
        self.check_size()?;
        spend(work, add(mul(2,self.logical_bytes())?,1)?)?;
        let mut considered = [false; MAX_DECLARATIONS];
        let mut skip = [false; MAX_DECLARATIONS];
        let mut shorthand = [false; MAX_DECLARATIONS];
        if self.summary.pending_records != 0 {
            spend(work, self.records.len()+1)?;
            for (i, record) in self.records.iter().enumerate() {
                if considered[i] { continue; }
                let Some(pending) = record.value.pending() else { continue; };
                spend(work, add(add(1,mul(self.records.len(),add(pending.shorthand.len(),4)?)?)?,self.logical_bytes())?)?;
                let mut count = 0;
                let mut complete = true;
                for (j, other) in self.records.iter().enumerate() {
                    if let Some(source) = other.value.pending()
                        && source.shorthand == pending.shorthand {
                        considered[j] = true;
                        count += 1;
                        complete &= source == pending && other.important == record.important;
                    }
                }
                complete &= css::shorthand_property_count(&pending.shorthand) == Some(count);
                if complete {
                    shorthand[i] = true;
                    // The paid origin scan also funds this fixed flag publication.
                    for (j, other) in self.records.iter().enumerate() {
                        if j != i && other.value.pending().is_some_and(|p| p.shorthand == pending.shorthand) {
                            skip[j] = true;
                        }
                    }
                }
            }
        }
        let mut out = String::with_capacity(self.logical_bytes());
        for (i, record) in self.records.iter().enumerate() {
            if skip[i] { continue; }
            if !out.is_empty() { out.push(' '); }
            if shorthand[i] {
                let pending = record.value.pending().expect("planned pending shorthand");
                write_name(&mut out, &pending.shorthand);
                out.push_str(": "); out.push_str(&pending.tokens);
            } else {
                write_name(&mut out, &record.name); out.push_str(": ");
                if let RecordValue::Tokens(value) = &record.value { out.push_str(value); }
            }
            if record.important { out.push_str(" !important"); }
            out.push(';');
        }
        Ok(out)
    }
}
