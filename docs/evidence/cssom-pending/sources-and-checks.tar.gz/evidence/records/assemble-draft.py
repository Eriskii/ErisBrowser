from pathlib import Path
import shutil
b=Path('/tmp/eris-cssom-pending-1/records')
s=(b/'migrations-before/raw/src/cssom.rs').read_text()
s=s.replace('use crate::selectors::{self, Kind, Token};','use crate::selectors::{self, Kind, Token};\nuse crate::dom::{DomDataError, DomMutationBudget};\nuse std::{mem::size_of, sync::Arc};')
a=s.index('#[derive(Clone, Debug, PartialEq, Eq)]\nstruct Record')
z=s.index('fn alias(',a)
s=s[:a]+(b/'model-snippet.rs').read_text()+s[z:]
s=s.replace('css::shorthand_properties(lower).is_some()', 'css::shorthand_property_count(lower).is_some()')
a=s.index('fn targets(');z=s.index('fn serialized_name_len(',a)
s=s[:a]+(b/'impl-snippet.rs').read_text()+s[z:]
a=s.index('fn records(');z=s.index('\nfn wide(',a)
r=s[a:z]
r=r.replace('''    let tokens = selectors::tokens(raw, work)''','''    let count = css::shorthand_property_count(property).unwrap_or(1);
    spend(work, add(1, mul(count, add(property.len(), 32)?)?)?)?;
    // Flat temporary records are paid for even if a later validation/stage fails.
    spend(work, add(1, mul(8, count)?)?)?;
    let tokens = selectors::tokens(raw, work)''',1)
r=r.replace('''            value: value.into(),
            important,
            pending: None,''','''            value: RecordValue::Tokens(value.into()),
            important,''',1)
a2=r.index('    if css::contains_var_function(value) {');z2=r.index('    if !css::valid_calculations',a2)
r=r[:a2]+'''    if css::contains_var_function(value) {
        spend(work, add(1, mul(count, add(value.len(), 64)?)?)?)?;
        if let Some(names) = css::shorthand_properties(property) {
            let source = Arc::new(PendingValue {
                shorthand: Arc::from(property), tokens: value.into(),
            });
            return Ok(Some(names.into_iter().map(|name| Record {
                name, value: RecordValue::Pending(Arc::clone(&source)), important,
            }).collect()));
        }
        return Ok(Some(vec![Record {
            name: property.into(), value: RecordValue::Tokens(value.into()), important,
        }]));
    }
'''+r[z2:]
r=r.replace('    let count = css::shorthand_properties(property).map_or(1, |names| names.len());\n','')
r=r.replace('''            value: normalized,
            important,
            pending: None,''','''            value: RecordValue::Tokens(normalized),
            important,''')
r=r.replace('''                value: d.value,
                important: d.important,
                pending: None,''','''                value: RecordValue::Tokens(d.value),
                important: d.important,''')
s=s[:a]+r+s[z:]
s += '\n#[cfg(test)]\nmod pending_record_tests;\n\n#[cfg(test)]\nmod pending_record_accounting_tests;\n'
# The group scan pays one origin comparison; the second pass publishes only fixed flags.
s=s.replace('''                let mut count = 0;
                let mut complete = true;''','''                let mut count = 0;
                let mut complete = true;
                let mut group = [false; MAX_DECLARATIONS];''')
s=s.replace('''                        considered[j] = true;
                        count += 1;''','''                        considered[j] = true;
                        group[j] = true;
                        count += 1;''')
s=s.replace('''                    for (j, other) in self.records.iter().enumerate() {
                        if j != i && other.value.pending().is_some_and(|p| p.shorthand == pending.shorthand) {
                            skip[j] = true;
                        }
                    }''','''                    for (j, matches) in group.iter().enumerate().take(self.records.len()) {
                        if j != i && *matches { skip[j] = true; }
                    }''')
(b/'raw/src/cssom.rs').write_text(s)
for n in ['background_tests.rs','background_box_tests.rs']:
 shutil.copyfile(b/'migrations-before/raw/src/cssom'/n,b/'raw/src/cssom'/n)
for n in ['pending_record_tests.rs','pending_record_accounting_tests.rs']:
 shutil.copyfile(b/'tests-before'/n,b/'raw/src/cssom'/n)
for rel in ['src/cssom.rs','src/cssom/background_tests.rs','src/cssom/background_box_tests.rs']:
 shutil.copyfile(b/'tests-before/before'/rel,b/'before'/rel)
print('External draft assembled, no project execution.')
