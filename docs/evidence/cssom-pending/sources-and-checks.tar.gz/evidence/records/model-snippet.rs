#[derive(Clone, Debug, PartialEq, Eq)]
struct PendingValue {
    shorthand: Arc<str>,
    tokens: String,
}
#[derive(Clone, Debug, PartialEq, Eq)]
enum RecordValue {
    Tokens(String),
    Pending(Arc<PendingValue>),
}
impl RecordValue {
    fn source(&self) -> &str {
        match self {
            Self::Tokens(tokens) => tokens,
            Self::Pending(pending) => &pending.tokens,
        }
    }
    fn pending(&self) -> Option<&PendingValue> {
        match self {
            Self::Tokens(_) => None,
            Self::Pending(pending) => Some(pending),
        }
    }
}
#[derive(Clone, Debug, PartialEq, Eq)]
struct Record {
    name: String,
    value: RecordValue,
    important: bool,
}
impl Record {
    fn logical_bytes(&self) -> Result<usize, Error> {
        add(add(serialized_name_len(&self.name), self.value.source().len())?,
            if self.important { 15 } else { 4 })
    }
}
#[derive(Clone, Copy, Debug)]
struct StyleSummary {
    logical_bytes: usize,
    retained_bytes: usize,
    clone_work: usize,
    release_work: usize,
    names_work: usize,
    pending_records: usize,
}
#[derive(Debug)]
pub(crate) struct InlineStyle {
    records: Vec<Record>,
    summary: StyleSummary,
}
impl PartialEq for InlineStyle {
    fn eq(&self, other: &Self) -> bool { self.records == other.records }
}
impl Eq for InlineStyle {}
impl Clone for InlineStyle {
    fn clone(&self) -> Self {
        let records = self.records.clone();
        // Runtime callers pay the cached copy, summary and teardown tariff first.
        let summary = Self::summarize(&records).expect("bounded inline clone summary");
        Self { records, summary }
    }
}
impl Default for InlineStyle {
    fn default() -> Self {
        Self {
            records: Vec::new(),
            summary: StyleSummary {
                logical_bytes: 0, retained_bytes: arc_bytes(), clone_work: 2,
                release_work: 1, names_work: 0, pending_records: 0,
            },
        }
    }
}
pub(crate) struct InlineDeclarationRef<'a> {
    pub name: &'a str,
    pub value: &'a str,
    pub important: bool,
    pub pending_shorthand: Option<&'a Arc<str>>,
}
#[derive(Debug)]
pub(crate) struct PreparedInlineStyle {
    style: Arc<InlineStyle>,
    serialized: String,
}
impl PreparedInlineStyle {
    pub(crate) fn serialized(&self) -> &str { &self.serialized }
    pub(crate) fn style(&self) -> &InlineStyle { &self.style }
    pub(crate) fn into_parts(self) -> (Arc<InlineStyle>, String) {
        (self.style, self.serialized)
    }
}
fn add(a: usize, b: usize) -> Result<usize, Error> { a.checked_add(b).ok_or(Error::Limit) }
fn mul(a: usize, b: usize) -> Result<usize, Error> { a.checked_mul(b).ok_or(Error::Limit) }
fn arc_bytes() -> usize { 2 * size_of::<usize>() + size_of::<InlineStyle>() }
fn summary_work(count: usize) -> Result<usize, Error> { add(1, mul(264, count)?) }
