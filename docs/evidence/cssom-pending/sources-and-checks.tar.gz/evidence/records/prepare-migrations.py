from pathlib import Path
import hashlib,json,difflib,re
base=Path('/tmp/eris-cssom-pending-1')
out=base/'records/migrations-before'
for rel in ['src/cssom.rs','src/cssom/background_tests.rs','src/cssom/background_box_tests.rs']:
 s=(base/'records/tests-before/before'/rel).read_text()
 (out/'before'/rel).write_text(s)
 t=s
 if rel.endswith('background_tests.rs') or rel.endswith('background_box_tests.rs'):
  t=re.sub(r'value: ([^\n]+),\n(\s*)important:',r'value: RecordValue::Tokens(\1),\n\2important:',t)
  t=re.sub(r'\n\s*pending: None,','',t)
 if rel.endswith('background_tests.rs'):
  for p,v,old in [('background-image','none',497),('background-size','0',135),('background-position','0',151),('background-repeat','repeat',352)]:
   t=t.replace(f'("{p}", "{v}", {old})',f'("{p}", "{v}", {old+len(p)+42})')
  t=t.replace('// none: 60', '// Add T(p,1)+F(1)=p+42 to each unchanged leaf fee below.\n    // none: 60')
 if rel.endswith('background_box_tests.rs'):
  t=t.replace('assert_eq!(pending.len(), 1);','assert_eq!(pending.len(), 7);')
  t=t.replace('''    assert_eq!(
        pending.records[0].pending.as_ref().unwrap(),
        &NAMES.map(str::to_owned)
    );''','''    assert_eq!((0..pending.len()).map(|i| pending.item(i)).collect::<Vec<_>>(), NAMES);
    for record in &pending.records {
        let RecordValue::Pending(source) = &record.value else { panic!("pending background") };
        assert_eq!(source.shorthand.as_ref(), "background");
        assert_eq!(source.tokens, "var(--Saved)");
    }''')
  t=t.replace('''    let saved = important.clone();
    assert!(!set(&mut important, "background-clip", "content-box", ""));
    assert_eq!(important, saved);''','''    assert!(set(&mut important, "background-clip", "content-box", ""));
    assert_eq!(important.get_property_priority("background-clip", &mut WORK.clone()), Ok(""));
    assert_eq!(important.get_property_priority("background-origin", &mut WORK.clone()), Ok("important"));''')
  t=t.replace('''    assert_eq!(parse(&text(&important)), important);''','''    assert_eq!(important.len(), 7);
    let reparsed = parse(&text(&important));
    assert_eq!(reparsed.len(), 1);
    assert_eq!(get(&reparsed, "background-clip"), "content-box");
    assert_eq!(get(&reparsed, "background-origin"), "");''')
  t=t.replace('// shared box parser5n+9, normalized storage n+65 =>42n+88.', '// shared box parser5n+9, normalized storage n+65 =>42n+88.\n    // Record T(p,1)+F(1)=p+42 is now added before leaf validation.')
  t=t.replace('''        ] {
            let mut work = cost;
            assert_eq!(
                records(property, value, true, &mut work),''','''        ] {
            let cost = cost + property.len() + 42;
            let mut work = cost;
            assert_eq!(
                records(property, value, true, &mut work),''')
  t=t.replace('// Empty block: API bytes + records fee + two property query scans +1 staging.', '// Empty block: old leaf + T/F + API/Q + clone2 + M + summary265 + equality.\n    // For important singletons the exact sum is old_leaf +9*p+3*v+388.')
  for old,new in [(582,1079),(625,1124),(576,1061),(619,1106)]: t=t.replace(f', {old}),',f', {new}),')
  t=t.replace('''        let mut style = InlineStyle {
            records: (0..custom_count)''','''        let mut style = InlineStyle::from_records_for_test((0..custom_count)''')
  t=t.replace('''                .collect(),
        };''','''                .collect());''')
 if rel=='src/cssom.rs':
  t=t.replace('''        let before = s.clone();
        assert_eq!(
            s.remove_property("margin-top", &mut WORK.clone()).unwrap(),
            ""
        );
        assert_eq!(s, before);''','''        assert_eq!(
            s.remove_property("margin-top", &mut WORK.clone()).unwrap(),
            "10px"
        );
        assert_eq!(get(&s, "margin-top"), "");''')
  t=t.replace('''        let before = s.clone();
        assert!(!set(&mut s, "margin-left", "3px", ""));
        assert_eq!(s, before);''','''        assert!(set(&mut s, "margin-left", "3px", ""));
        assert_eq!(s.get_property_priority("margin-left", &mut WORK.clone()), Ok(""));
        assert_eq!(s.get_property_priority("margin-top", &mut WORK.clone()), Ok("important"));''')
 (out/'raw'/rel).write_text(t)
 (out/(Path(rel).name+'.patch')).write_text(''.join(difflib.unified_diff(s.splitlines(True),t.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel)))
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
manifest={'status':'tests-first additive selected migrations before production draft; no execution','reason':'Expanded pending longhands permit independent setter priority/removal; lossy public serialization intentionally drops pending survivors when explicitly reparsed. Literal representation adapters preserve values; fees add selected T/F/clone/summary/equality without relaxing cuts.','frozen_13_groups':'unchanged in records/tests-before','files':[bind(p) for p in sorted(out.rglob('*')) if p.is_file()]}
(out/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(bind(out/'source-ready.json'))
