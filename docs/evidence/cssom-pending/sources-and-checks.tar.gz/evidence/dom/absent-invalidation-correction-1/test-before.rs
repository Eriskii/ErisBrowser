//! Additive absent-owner invalidation fee: literal counts, no observations.
#[test]
fn absent_typed_owner_prepays_both_lookup_and_external_credit_searches() {
    for (count, fee) in [(0, 8), (1, 12), (11, 52), (12, 56)] {
        let (mut doc, node) = fresh();
        for _ in 0..count {
            let other = doc.create_element("p");
            install(&mut doc, other, "color:red", false);
        }
        let retained = doc.retained_bytes();
        let typed_bytes = doc.inline_style_bytes;
        let mut short = fee - 1;
        assert!(matches!(doc.prepay_inline_style_invalidation(node, "style", None, &mut short), Err(DomDataError::LimitExceeded)));
        assert_eq!(short, 0);
        assert_eq!(doc.attr(node, "style"), None);
        assert_eq!(doc.retained_bytes(), retained);
        assert_eq!(doc.inline_style_bytes, typed_bytes);
        assert_eq!(doc.inline_styles.len(), count);
        let mut exact = fee;
        doc.prepay_inline_style_invalidation(node, "style", None, &mut exact).unwrap();
        assert_eq!(exact, 0);
        doc.set_attr(node, "style", "color:blue");
        assert_eq!(doc.attr(node, "style"), Some("color:blue"));
        assert_eq!(doc.retained_bytes(), retained + 15);
        assert_eq!(doc.inline_style_bytes, typed_bytes);
        assert_eq!(doc.inline_styles.len(), count);
        assert!(!doc.inline_styles.contains_key(&node));
        assert_eq!(doc.inline_style_bytes, sum_entries(&doc));
    }
}
