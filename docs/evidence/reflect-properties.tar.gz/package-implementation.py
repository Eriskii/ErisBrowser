from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

R = Path(__file__).resolve().parent
W = R / 'worktree'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

adapter = read(R / 'final-adapter.json')
assert sha(R / adapter['binary']) == adapter['sha256']
for rel, digest in adapter['source_sha256'].items():
    assert sha(W / rel) == digest, rel

up = read(R / 'upstream-final.json')
local = read(R / 'local-candidate-1.json')
typed = read(R / 'typedarray-upstream-candidate-1.json')
assert up['counts'] == {'passed': 200, 'unsupported': 16}
assert up['mode_cases'] == 216 and up['harness_preflight_passed']
assert len(up['harness_preflight']) == 52
assert all(row['verified'] for row in up['harness_preflight'])
assert local['summary'] == {'case_matches': 28, 'case_total': 28,
                           'control_matches': 20, 'controls_verified': 20,
                           'control_total': 20, 'runner_errors': 0}
assert not local['binding_failures']
assert typed['counts'] == {'passed': 588, 'failed': 44,
                           'unsupported': 488, 'resource': 118}
assert len(typed['harness_preflight']) == 64 and typed['harness_preflight_passed']
assert up['binary_sha256'] == local['binary_sha256'] == typed['binary_sha256'] == adapter['sha256']

successes = ['bootstrap-diagnostic-1', 'buffer-bootstrap-188-1',
             'buffer-bootstrap-198-1', 'reflect-private-188-1',
             'reflect-private-198-1', 'full-native-2', 'clippy-188-1',
             'clippy-198-1', 'fmt-final-1', 'local-candidate-1',
             'typedarray-local-candidate-1', 'upstream-final-1',
             'upstream-ci-gate-1']
for label in successes:
    receipt = read(R / 'validation' / (label + '.json'))
    assert receipt['exit'] == 0, label
    assert sha(R / 'validation' / receipt['log']) == receipt['sha256'], label
for label, code in [('full-native-1', 101), ('upstream-candidate-1', 1),
                    ('typedarray-upstream-candidate-1', 1)]:
    assert read(R / 'validation' / (label + '.json'))['exit'] == code
full_log = (R / 'validation/full-native-2.log').read_text()
totals = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored;', full_log)
assert sum(map(int, totals)) == 2227
assert 'remaining=496 allocated=1872268 objects=730 capacity=730' in (
    R / 'validation/buffer-bootstrap-198-1.log').read_text()

comparison = read(R / 'regression-comparison.json')
assert comparison['profiles'] == 37 and comparison['modes'] == 16136
assert not comparison['changed_case_rows'] and comparison['regressions'] == 0
for row in read(R / 'predecessor-regression-bindings.json')['profiles']:
    before = R / 'predecessor-regressions' / Path(row['report']).name
    after = R / 'regressions-candidate-1' / Path(row['report']).name
    assert sha(before) == row['sha256']
    assert read(before)['cases'] == read(after)['cases']

ci = read(R / 'preparation-ci-observation-2.json')
assert ci['conclusion'] == 'success' and len(ci['jobs']) == 9
assert all(job['conclusion'] == 'success' for job in ci['jobs'])

dirs = ['arraybuffer-bootstrap', 'browser', 'candidate-source-1',
        'installer-draft-1', 'runtime', 'runtime-implementation',
        'snapshot-reconciliation', 'regressions-candidate-1',
        'predecessor-regressions', 'typedarray-followthrough',
        'documentation-proposal', 'publication-source', 'validation']
roots = ['before-adapter.json', 'candidate-adapter-1.json', 'final-adapter.json',
         'published-base.json', 'source-ready.json', 'proposal.md',
         'outer-sandbox-preflight.json', 'predecessor-regression-bindings.json',
         'preparation-ci-observation-2.json', 'typedarray-ci-observation-2.json',
         'regression-plan.json', 'regression-comparison.json',
         'typedarray-comparison-candidate-1.json',
         'local-before.json', 'local-candidate-1.json',
         'upstream-before.json', 'upstream-candidate-1.json',
         'upstream-final.json', 'upstream-ci-gate.json',
         'typedarray-local-candidate-1.json', 'typedarray-upstream-candidate-1.json',
         'run-check.py', 'run-tool.py', 'run-regressions.py',
         'package-implementation.py', 'publication-source-pre-docs.json']
assert all((R / name).is_dir() for name in dirs)
paths = [p for name in dirs for p in (R / name).rglob('*') if p.is_file()]
paths += [R / name for name in roots]
assert all(p.is_file() and not p.is_symlink() for p in paths)
rows = [{'path': str(p.relative_to(R)), 'bytes': p.stat().st_size,
         'sha256': sha(p)} for p in sorted(set(paths))]
manifest = {'format': 1, 'scope': 'Reflect property implementation and unchanged-budget ArrayBuffer bootstrap optimization; retained attempts and observations', 'files': rows}
raw = (json.dumps(manifest, indent=2) + '\n').encode()
archive = W / 'docs/evidence/reflect-properties.tar.gz'
with archive.open('xb') as stream:
    with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, data in [('manifest.json', raw)] + [
                    (row['path'], (R / row['path']).read_bytes()) for row in rows]:
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                tar.addfile(info, io.BytesIO(data))

modified = subprocess.check_output(['git', 'ls-files', '-m', '-o', '--exclude-standard'], cwd=W, text=True).splitlines()
public = {rel: sha(W / rel) for rel in sorted(set(modified))
          if (W / rel).is_file() and rel != 'docs/evidence/reflect-properties.tar.gz'}
record = {
    'format': 1,
    'status': 'Nine Reflect property operations implemented; full browser goal remains incomplete',
    'base': '8570143e45604292977b1fed02b024eb794da67d',
    'preparation_evidence': 'reflect-properties-preparation.json',
    'before_adapter': read(R / 'before-adapter.json'),
    'final_adapter': adapter,
    'public_file_sha256': public,
    'archive': {'path': archive.name, 'bytes': archive.stat().st_size,
                'sha256': sha(archive), 'records': len(rows),
                'manifest_sha256': hashlib.sha256(raw).hexdigest()},
    'validation': {
        'full_native_vulkan_feature': {'rust': '1.88.0', 'passed': 2227, 'failed': 0, 'ignored': 0},
        'private_groups_each_rust_version': {'reflect': 15, 'arraybuffer_bootstrap': 7},
        'rust_versions': ['1.88.0', '1.98.0'],
        'strict_clippy_all_targets_vulkan_feature': 'passed on both versions',
        'format': 'passed',
        'reflect_upstream': {'sources': 108, 'modes': 216, 'counts': up['counts'], 'controls': 52, 'verified': 52, 'report': 'tests/conformance/test262-reflect-properties-report.json', 'new_baseline_and_ci_gate': True},
        'reflect_local': local['summary'],
        'existing_gated_profiles': comparison,
        'typedarray_followthrough': {'modes': 1238, 'counts': typed['counts'], 'controls': 64, 'verified': 64, 'new_passes': 16, 'failed_to_resource': 26, 'failed_diagnostic_changes': 2, 'previous_pass_regressions': 0, 'report': 'tests/conformance/test262-typedarray-after-reflect.json', 'new_baseline': False},
        'typedarray_local': read(R / 'typedarray-local-candidate-1.json')['summary'],
        'preparation_ci': {'run': ci['databaseId'], 'head': ci['headSha'], 'conclusion': ci['conclusion'], 'jobs': 9}
    },
    'bootstrap': {
        'limit_unchanged': 100000, 'raw_remaining': 496,
        'charged_bytes': 1872268, 'objects': 730, 'object_capacity': 730,
        'arraybuffer_old_work': 11639, 'arraybuffer_new_work': 8150,
        'arraybuffer_saved_work': 3489, 'arraybuffer_saved_bytes': 5711,
        'reflect_work': 3278, 'reflect_site_bytes': 25704,
        'reflect_early_arena_bytes': 1944,
        'all_runtime_quotas_unchanged': True
    },
    'retained_attempts': [
        'Full-native-1: outer restricted environment denies the two socket preflights; identical source and test command pass all 2227 tests with outer execution permission in full-native-2. No sandbox/test weakening.',
        'Upstream-candidate-1 exits1 under all-modes-pass policy because16 Proxy modes remain unsupported; final baseline recording and baseline gate both exit0 with identical case/control rows.',
        'TypedArray complete1238-mode followthrough exits1;44 failures,488 unsupported and118 instruction-limit stops remain visible. No new TypedArray baseline.',
        'Preparation protocol first failure and corrected second run remain in earlier preparation evidence and copied validation logs.',
        'Three old numeric startup snapshots were reconciled only after raw measured changes; original values and reconciliation are retained.'
    ],
    'limits': [
        'Proxy and foreign realms remain incomplete; unrepresented legacy DOM string properties explicitly unsupported.',
        'Instruction-limit observations are not semantic passes; no quotas or harness population reduced.',
        'No full web compatibility, production security or Chromium-relative performance claim.',
        'This archive predates this implementation commit and its future CI run; only predecessor CI success is recorded here.'
    ]
}
dest = W / 'docs/evidence/reflect-properties.json'
with dest.open('x') as stream:
    json.dump(record, stream, indent=2)
    stream.write('\n')
staged = sorted([*public, 'docs/evidence/reflect-properties.tar.gz', 'docs/evidence/reflect-properties.json'])
(R / 'implementation-stage-paths.json').write_text(json.dumps(staged, indent=2) + '\n')
print(json.dumps({'archive': record['archive'], 'evidence_sha256': sha(dest), 'staged_paths': len(staged)}, indent=2))
