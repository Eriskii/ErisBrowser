# Newly reached TypedArray resource outcomes

All 26 new resource modes, covering 13 original files, report runtime `ResourceLimit` with `script instruction limit exceeded`. None reports heap exhaustion. The candidate changes 16 failed modes to passed and 26 failed modes to resource. All 572 previous passes and all 92 previous resource observations remain byte-for-byte equal as JSON rows. All 1,238 case/source fingerprints, the corpus manifest/policy pins and 64 healthy control rows are unchanged.

There are **44 raw changed rows**, not only the 42 status changes: `HasProperty/inherited-property.js` remains failed in both modes, but its diagnostic advances from TypeError/TypeError identity to Test262Error/empty identity. `raw-changes.json` retains these too. The 13 new resource files previously reported runtime TypeError; missing Reflect methods are consistent with that failure, but neither report identifies the precise executed statement.

This is source/data analysis after root's candidate run. No engine, compiler, tests, profiler or renderer was executed here. `inputs.json` binds the original reports, actual candidate binary, candidate source manifest, relevant source bytes, original bodies and harness. Unchanged source files absent from the changed-file snapshot were read from the worktree only after matching their candidate-manifest SHA. All costs below are requirements for a hypothetical complete script, not measured stopping prefixes.

## The full-script matrix

The pinned `testTypedArray.js` supplies ten Number kinds, including Float16, and eight factories: passthrough, Array, array-like, iterable, fixed ArrayBuffer, resizable, grown and shrunk. The default therefore calls the body and binds its argument factory **80 times**. Immutable is absent, so the bodies excluding immutable still request 80 calls. Four bodies explicitly select passthrough and request ten calls.

| File below `TypedArrayConstructors/internals/` | Body calls | Reflect calls | TypedArray constructions | Authored copied bytes |
| --- | ---: | ---: | ---: | ---: |
| Delete/key-is-symbol.js | 80 | 160 has | 150 | 58 |
| HasProperty/indexed-value.js | 80 | 160 has | 180 | 174 |
| HasProperty/key-is-greater-than-last-index.js | 80 | 80 has | 150 | 58 |
| HasProperty/key-is-lower-than-zero.js | 80 | 80 has | 150 | 58 |
| HasProperty/key-is-minus-zero.js | 80 | 80 has | 150 | 58 |
| HasProperty/key-is-not-canonical-index.js | 10 | 120 has | 40 | 0 |
| HasProperty/key-is-not-integer.js | 80 | 160 has | 150 | 58 |
| Set/key-is-canonical-invalid-index-reflect-set.js | 10 | 160 set | 200 | 0 |
| Set/key-is-minus-zero.js | 80 | 80 set | 180 | 87 |
| Set/key-is-not-canonical-index.js | 10 | 120 set | 40 | 0 |
| Set/key-is-not-integer.js | 80 | 160 set | 180 | 87 |
| Set/key-is-out-of-bounds.js | 80 | 240 set | 180 | 87 |
| Set/key-is-valid-index-reflect-set.js | 10 | 60 set | 90 | 0 |

These counts include intermediate factory views and Uint8 copy views. The ten widths sum to 29. Primitive length-one arguments require two copy loops per kind, hence 58 byte iterations; array length-one arguments require three, hence 87. The indexed-value array has two elements, hence 174. The primitive branches of grown/shrunk allocate and resize a buffer, then **fall through** into the later copy path; they do not return early. Full primitive matrices allocate 120 ArrayBuffers, full array matrices 110. The four passthrough files respectively construct 40, 200, 40 and 90 views/backing buffers. The invalid distinct-Receiver body has 16 targets and four typed receivers per kind; the valid body has six targets, two typed receivers and one coercion-reference view.

The Delete file uses delete syntax and the new `Reflect.has`; it does not call `Reflect.deleteProperty`. All 13 bodies include only `testTypedArray.js` beyond the default assertion harness. There is no `propertyHelper.js` explanation for this particular set.

## Present work and a strict quota proof

Each reached `Reflect.has`/`Reflect.set` call now pays the real scoped native preflight: `4 + 11 = 15` work and `32 + 11 = 43` temporary-name bytes. Both pay an eight-work body header. Has adds two work per reached prototype edge and eight per own-descriptor probe; Set adds four per edge and, when TypedArray Set falls through, eight for its subsequent own probe. Thus the roster's deliberately partial native prefixes are 33 per Has and 27 per Set, before key conversion, type/record/classification work, map searches, extra prototype edges and VM overhead. Ordinary Set needs at least eight more work. TypedArray objects and these cached Reflect natives use direct property bags; there is no new legacy native-registry search to remove here.

The inherited scalar bound still applies to the frozen candidate: a valid Uint8 indexed read costs at least 142 and a write at least 134, giving **276 per authored copied byte**. This excludes record lookup, Number-key formatting, loop/length access and constructors. The default primitive, one-element array and two-element array factories therefore have partial copy bounds of 16,008, 24,012 and 48,024. Constructor scalar writes additionally cost at least `66 + 3*w` per element, omitting the clamp surcharge. These partial bounds, plus the real construction/activation matrix and assertions, explain substantial work, but do not alone prove a total above 100,000 or identify a stop.

One file has a stronger proof. In `Set/key-is-not-canonical-index.js`, every three Reflect.set calls classifies its authentic TypedArray target at least twice: `typed_array_set` returns Ordinary, then `reflect_own` repeats `typed_array_own_property`. The explicit Object.defineProperty adds a seventh classification. For each of ten kinds, this applies to all four keys.

| Key | Classifier work lower bound |
| --- | ---: |
| `1.0` | 243 |
| `+1` | 212 |
| `1000000000000000000000` | 742 |
| `0.0000001` | 299 |

The sum gives **`7 * 10 * 1496 = 104720`**, already above the unchanged 100,000 limit. The detailed reached fee rows are in `classifier-lower-bound.json`. This excludes every formatter correction fee, brand lookup, Receiver recheck, internal definition, ordinary read, constructor, assertion and native/VM overhead. Every one of these ordinary numeric-looking keys also allocates the inherited primitive parse scratch and admits 1,024 bytes of formatter scratch on each classification. That cumulative allocation is real, but the observed refusal remains the instruction limit.

An initial prose subtotal of 842 for the long key was an addition error; the data-only assembly assertion caught it before any receipt was written. The corrected 742 subtotal and 104,720 result preserve the quota conclusion. The individual fee rows and route counts did not change.

## Bounded follow-up

Carry a classification of the already converted immutable property key through one property operation, instead of repeating its ASCII/integer/alphabet/parse/format scans. The current duplicate Set probe and subsequent Receiver/define probes offer concrete work to eliminate. A classification is key-only; it must not be confused with a live view or descriptor. Fresh receiver brand checks, resize/detach validity after callbacks, conversion order and all ordinary/host semantics still apply. A separate source-only proposal is being prepared under `/tmp/eris-typedarray-index-1`.

Do not replace the authored byte loops with a host copy, alter the frozen matrix/oracles, or increase quotas. No claim is made that one optimization will admit all 26 modes. For the other 12 files, exact constructor/factory/statement stopping points and complete cost totals remain unproven; the reports have no such trace. Preserve later resource or semantic failures as actual results.
