"""Source/data-only bootstrap ledger derivation. No repository code is imported."""
import hashlib,json,pathlib,re
P=pathlib.Path(__file__).resolve().parent
S=P/'source'
def read(p):return (S/p).read_text()
def section(s,a,b):return s.split(a,1)[1].split(b,1)[0]
def strings(s):return re.findall(r'"([^"\n]*)"',s)
def tuples(s):return re.findall(r'\("([^"]+)", "([^"]+)", \d+\)',s)
s=read('src/script.rs')
groups=[]
def add(name,keys):groups.append({'group':name,'keys':keys,'count':len(keys)})
d=read('src/script/dom_bindings.rs')
parents=re.findall(r'full: "([^"]+)"',section(d,'static PARENT_METHODS:','];'))
add('DOM parent methods',[parents[i] for i in [8,0,3,7,2,5,6,1,4]])
add('constructors',strings(section(section(s,'self.array_prototype = Some(array_prototype);','let properties = self.native_properties["Object"]'),'for name in [','] {')))
add('prototype functions',[a+'.'+b for a,b in tuples(section(s,'for (name, key, length) in [','] {'))])
add('RegExp accessors',['RegExp.get.'+x for x in (['source']+strings(section(s,'for key in [\n            "source",','] {')))])
add('constructor static functions',[a+'.'+b for a,b in tuples(section(s,'for (owner, key, length) in [','] {'))])
add('array scoped functions',['Array.from','Array.splice','Array.concat'])
ns=section(s,'fn initialize_number_statics','fn intrinsic_function')
add('Number predicates',[b for a,b in re.findall(r'\("([^"]+)", "([^"]+)"\)',section(ns,'for (key, full) in [','] {'))])
add('global conversions',['isFinite','isNaN','encodeURI','encodeURIComponent','decodeURI','decodeURIComponent'])
add('global numeric parsers',['parseInt','parseFloat'])
add('namespace bags',['JSON','Math'])
add('JSON functions',['JSON.parse','JSON.stringify'])
math=section(s,'for (key, length) in [\n            ("abs",','] {')
add('Math functions',['Math.abs']+['Math.'+x for x in re.findall(r'\("([^"]+)", \d+\)',math)])
es=section(s,'fn initialize_events','fn abort_signal_index')
add('Event methods',[a+'.'+b for a,b in tuples(section(es,'for (owner, key, length) in [','] {'))])
add('Abort static',['AbortSignal.static.abort'])
add('Abort accessors',['AbortController.get.signal','AbortSignal.get.aborted','AbortSignal.get.reason','AbortSignal.get.onabort','AbortSignal.set.onabort'])
ekeys=['type']+strings(section(es,'for key in [\n            "type",','] {'))
add('Event accessors',[v for x in ekeys for v in (['Event.get.'+x,'Event.set.'+x] if x in ('cancelBubble','returnValue') else ['Event.get.'+x])]+['Event.get.isTrusted'])
add('RegExp symbols',['RegExp.symbolSplit','RegExp.symbolMatch','RegExp.symbolSearch','RegExp.species'])
add('Symbol and Reflect functions',['Symbol.for','Symbol.keyFor','Symbol.toString','Symbol.valueOf','Symbol.description','Symbol.toPrimitive','Object.getOwnPropertySymbols','Reflect.ownKeys','Reflect.apply','Reflect.construct','Reflect.defineProperty','Function.hasInstance'])
keys=[k for g in groups for k in g['keys']]
assert len(keys)==178 and len(set(keys))==178,(len(keys),[(g['group'],g['count']) for g in groups])
rows=[('isView','isView','isView',1,'constructor',False),('getByteLength','get byteLength','byteLength',0,'prototype',True),('getMaxByteLength','get maxByteLength','maxByteLength',0,'prototype',True),('getResizable','get resizable','resizable',0,'prototype',True),('getDetached','get detached','detached',0,'prototype',True),('resize','resize','resize',1,'prototype',False),('slice','slice','slice',2,'prototype',False),('transfer','transfer','transfer',0,'prototype',False),('transferToFixedLength','transferToFixedLength','transferToFixedLength',0,'prototype',False),('species','get [Symbol.species]','@species',0,'constructor',True)]
def tree(n):
 c=(n+1)//2;h=int(n!=0)
 while c>=6:c//=6;h+=1
 return min(n,11*h),h
def search(n,u):return tree(n)[0]*(1+u//8)
def insertion(n):return 128*(tree(n)[1]+1)
def keyorder(k):return (1,k) if k.startswith('@') else (0,k)
def compare(a,b):
 if a.startswith('@')!=b.startswith('@'):return 2
 if a.startswith('@'):return 8
 q=0
 for x,y in zip(a,b):
  q+=1
  if x!=y:break
 return 4+2*q
owners={'constructor':['length','name','prototype'],'prototype':['constructor']}
initial_owners={k:list(v) for k,v in owners.items()}
oldrows=[];newowners=[];oldcounts={k:len(v) for k,v in owners.items()}
for i,(suffix,display,key,length,owner,getter) in enumerate(rows):
 full='ArrayBuffer.'+suffix;n=oldcounts[owner];oldcounts[owner]+=1;r=178+i
 old=64+2*search(r,len(full))+128*(tree(r)[1]+1)+2*search(n,len(display))+128*(tree(n)[1]+1)+n
 oldrows.append(dict(full=full,display=display,key=key,length=length,owner=owner,getter=getter,registry_before=r,owner_before=n,work=old))
for row in oldrows+[dict(full=None,key='@toStringTag',owner='prototype')]:
 key=row['key'];owner=row['owner'];order=owners[owner];ordered=sorted(order,key=keyorder);cost=0;count=0
 for previous in ordered:
  cost+=compare(key,previous);count+=1
  if keyorder(key)<keyorder(previous):break
 shifted=sum(keyorder(x)>keyorder(key) for x in order)
 newowners.append(dict(key=key,owner=owner,old_count=len(order),comparisons=count,comparison_work=cost,shifted_pairs=shifted,fixed_work=32,movement_work=4*shifted))
 order.append(key)
# Original push growth: constructor4->8, prototype4->8->16.
owner_work=11*32+sum(r['comparison_work']+r['movement_work'] for r in newowners)+2*(4+4+8)
assert owner_work==674 and sum(r['comparison_work'] for r in newowners)==266
fulls=[r['full'] for r in oldrows];displays=[r['display'] for r in oldrows]
pool=list(dict.fromkeys(['name','length']+displays+[r['key'] for r in oldrows if not r['key'].startswith('@')]+['ArrayBuffer']))
assert len(pool)==17
registry_order=sorted(range(10),key=lambda i:fulls[i])
assert not [k for k in keys if 'ArrayBuffer.'<=k<'ArrayBuffer/']
old_work=sum(r['work'] for r in oldrows)+174+8*32+90+274
assert old_work==11639
new_work_rows={
 'closed_stage_guard':128,'original_constructor_prototype_lookup_and_setup':174,
 'well_known_key_lookups':90,'paid_empty_registry_gap_validation':256,
 'pooled_utf16_text':sum(8+2*len(x) for x in pool),
 'ten_bag_helpers':10*9,'ten_fresh_sorted_two_entry_bags':10*(16+2*18+6),
 'ten_native_factories':sum(8+len(x) for x in fulls),
 'ten_owned_registry_keys':sum(4+len(x) for x in fulls),
 'saved_ArrayBuffer_native':8+11,
 'registry_entry_comparisons':sum(search(178+i,len(fulls[j])) for i,j in enumerate(registry_order)),
 'registry_entry_navigation':10*(8*(3+1)+4),
 'registry_aggregate_structure':13*256+128,
 'owner_entry_comparisons_moves_and_order_growth':owner_work,
 'fixed_stack_staging_control_and_retirement':96}
new_work=sum(new_work_rows.values())
# Use exactly retained measured type sizes; no fresh measurement.
types={'A':16,'D':16,'K':16,'N':56,'M':8,'Bpp':1472,'Bsu':832}
base=72+types['A']+types['D'];F=sum(map(len,fulls));D=sum(map(len,displays));U=sum(map(len,pool))
old_bytes=1024+11*types['M']+sum(1536+8*(len(r['full'])+len(r['display']))+base+552 for r in oldrows)+8*256+512
new_byte_rows={'pool':sum(64+4*len(x) for x in pool),'bag_bases':10*base,'bag_leaves':10*types['Bpp'],'bag_order_blocks_4_slots':40*types['K'],'owner_full_growth_blocks':32*types['K'],'native_records_and_names':11*(types['N']+32)+F+11,'registry_owned_names':F,'registry_split_nodes':3*types['Bsu']}
new_bytes=sum(new_byte_rows.values())
result={'status':'source-derived proposed allowances, no implementation or measurement','published_base':'b4ce6570f42ab4f45862cc29445a4181d5dafec5','registry_groups':groups,'registry_before_sorted':sorted(keys),'registry_before':178,'registry_after':188,'function_creation_order':oldrows,'registry_insertion_permutation':registry_order,'initial_owner_order':initial_owners,'final_owner_order':owners,'new_owner_rows':newowners,'text_pool':pool,'text_pool_units':U,'native_full_name_bytes':F,'display_units':D,'old_work':old_work,'new_work_rows':new_work_rows,'new_work':new_work,'work_saving':old_work-new_work,'bootstrap_remaining_if_only_this_change':285+old_work-new_work,'remaining_after_proposed_Reflect_3278':285+old_work-new_work-3278,'old_charged_bytes':old_bytes,'new_byte_rows':new_byte_rows,'new_charged_bytes':new_bytes,'byte_delta':new_bytes-old_bytes,'conditional_bootstrap_allocated':1850331+new_bytes-old_bytes,'type_context':types,'bounds':{'height_nodes':3,'leaf_split_max':2,'internal_split_max':1,'root_split_max':0,'touched_insertion_levels_max':13,'new_registry_nodes_max':3}}
(P/'ledger.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['registry_before','old_work','new_work','work_saving','bootstrap_remaining_if_only_this_change','remaining_after_proposed_Reflect_3278','old_charged_bytes','new_charged_bytes','byte_delta','text_pool_units','native_full_name_bytes','display_units']}))
