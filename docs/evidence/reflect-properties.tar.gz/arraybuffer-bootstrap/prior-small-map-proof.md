# Fixed small-map and comparator proof

The retained `stdlib/1.88.0/` and `stdlib/1.98.0/` files came from the corresponding version-tagged rust-lang/rust GitHub paths. They are source evidence, not installed toolchain rust-src and not a claim that a compiler was executed. `stdlib-bindings.json` gives exact URLs/hashes.

Both pinned BTree implementations use capacity11. `BTreeMap::entry` on an empty map returns a vacant entry without allocating; vacant insertion allocates the first leaf. For n≤10, every later strictly ascending new key searches that same leaf and inserts at index=current length. `search_node`/`find_key_index` compare the new key to every previous key, so the owner requires n(n−1)/2 comparisons. The tail's key/value move lengths are zero. No leaf split, root growth, edge movement or backlink repair is reached. At most one conservative typed tree block is therefore required per owner. Entry/root/length bookkeeping and eventual leaf/pair destruction are still paid.

Relevant pinned sources:

- [1.88 map entry](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/map.rs), [1.98 map entry](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/map.rs).
- [1.88 vacant insertion](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/map/entry.rs), [1.98 vacant insertion](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/map/entry.rs).
- [1.88 leaf insertion](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/node.rs), [1.98 leaf insertion](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/node.rs).
- [1.88 linear search](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/search.rs), [1.98 linear search](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/search.rs).

PropertyKey is a derived String-before-Symbol enum. JsString is derived Ord over Rc<[u16]>. The pinned Rc Ord forwards to its pointee comparison. The u16 slice follows generic SliceOrd and `chaining_impl`, which returns on the first non-equal element. The unsigned-bytewise specialization includes bool/u8/related byte types, **not u16**. Thus the prefix q in roster.json is the actual logical number of compared UTF-16 positions. A shared prefix also pays the fixed length/result part. This would not justify applying the same prefix proof to String/memcmp or changing existing global-map byte-key charges.

- [1.88 Rc Ord](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/rc.rs), [1.98 Rc Ord](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/rc.rs).
- [1.88 slice Ord](https://github.com/rust-lang/rust/blob/1.88.0/library/core/src/slice/cmp.rs), [1.98 slice Ord](https://github.com/rust-lang/rust/blob/1.98.0/library/core/src/slice/cmp.rs).

The inherited global rebuild continues using the previously reviewed sorted direct-Vec collect path, with its complete existing bulk formula and requested sort scratch. This proposal does not apply that large-map formula to the small fixed owners or replace it with repeated global insertion. The earlier detailed version-tagged bulk proof is retained in references/05-bulk-source-review.md.

These are logical operation envelopes. They do not count optimized machine instructions or promise allocator timing. The map builder's fixed16 and per-entry18 decomposition is stated in proposal.md and must be matched by the eventual implementation; the present source-only proof does not approve unseen extra passes.
