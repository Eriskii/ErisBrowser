# ArrayBuffer bootstrap: closed sorted-gap registry insertion

This is a source-only proposal bound to published foundation `b4ce6570f42ab4f45862cc29445a4181d5dafec5`. No repository source was changed; no compiler, interpreter, browser or test ran. `source/` comes directly from the published Git objects. The new Reflect worktree has already started changing independently; its current bytes are not silently substituted for this base. `derive.py` performs only source-text extraction and integer arithmetic.

The complete proposed installer debit is **8,150 work and 22,657 requested bytes**, using the already retained type census. The published installer charges **11,639 work and 28,368 bytes**. The conditional saving is therefore **3,489 work / 5,711 bytes**. Starting from the measured foundation remainder285, this predicts3,774 remaining; the root's revised3,278-work Reflect installer would leave496. The conditional allocation total is1,844,620. These are proposed charge totals, not a measurement or implementation acceptance. Object count/capacity721, registry count320 and prototype count25 remain unchanged at complete bootstrap.

## Preserve the graph and observable order

The registry has178 entries before ArrayBuffer,188 after. The derivation enumerates every prior registration, including the nine DOM parent bags, and retains both original registration order and sorted keys. The two owners start with constructor order `[length,name,prototype]` and prototype order `[constructor]`.

Create ten function bags in precisely the existing order: isView; get byteLength; get maxByteLength; get resizable; get detached; resize; slice; transfer; transferToFixedLength; species. Each receives the same object ID as before, the same Function prototype, final `name` and `length` descriptor flags(false,false,true), and original order `[name,length]`. The bag's internal BTree can be filled in sorted order `[length,name]`; its separate order Vec keeps `[name,length]`. Reserve four order slots, matching the current two-element Vec's capacity. Do not replace generic `intrinsic_function` or any other installer.

Return/create the same one native value for each owner slot: exact full registry key, receiverUndefined, `Native.properties=None`. The private saved ArrayBuffer native remains the full nameArrayBuffer, receiverWindow, propertiesNone. This proposal does not migrate these natives to direct metadata or change subsequent dispatch fees. Preserve constructor/prototype identities, all accessor setterUndefined values, method lengths, method flags(true,false,true), accessor flags(false,true), and Symbol.toStringTag valueArrayBuffer with flags(false,false,true). There are no new global entries or registry aliases.

Owner insertions retain their original sequence, including species before the final prototype tag. Stage only ten `(String, bag_id)` pairs in a fixed stack array. Their registry insertion order is the literal permutation `[1,4,2,3,0,5,6,9,7,8]`. This changes only private BTree shape. The registry is an ordered map and has no JavaScript creation-order vector; all existing key→ID mappings remain intact. No old map is consumed, rebuilt, cloned or dropped.

## Admission and construction sequence

1. Pay128 for closed-stage checks and174 for the existing constructor/prototype lookup/setup envelope. Resolve the two owners. Require ArrayBuffer state unset, records empty, registry length178, prototypes length25, owners distinct and valid, owner map/order lengths3 and1, existing order capacities4, and ten free already-reserved object slots. Validate the four original **map** string keys once. The128 guard decomposes as32 scalar/count/state checks +76 exact UTF-16 key comparisons (`4+2q`, totalq30) +16 iterator/handle steps +4 slack. It does not scan the four order strings again; order provenance is the closed published initializer. No author input can reach this stage.
2. Pay256 before proving the entire byte interval `["ArrayBuffer.", "ArrayBuffer/")` empty with a borrowed `BTreeMap::range::<str,_>` and one `next`. The fixed ASCII bounds cover every new full key and exclude ArrayBuffer itself. Charge two bounded root-to-leaf searches132, bounds comparison2, navigation24, lazy iterator32, setup32, plus34 slack. No allocation or map mutation is required. A collision or malformed private initialization state is a terminal Resource error.
3. Calculate/check the remaining work and complete requested storage, then debit both before any new allocation or mutation. Use checked arithmetic even for the final combination. The submitted rows are a static closed-stage plan; do not subtract already executed lookup/guard rows twice. A one-short work/heap cut must fail before new bags, owner properties, registry entries or saved handles are published. Construction uses private prepaid helpers mirroring the existing text/object/native operations; their row charges are already included in the aggregate and must not be charged a second time.
4. Build the17-string,183-unit ASCII UTF-16 pool using a private prepaid mirror of the existing fallible text helper:502 work /1,820 bytes. Pool shared name/length and identical owner/display strings. Distinct string allocation identity is not observable. Build the saved native with19 work and its typed bytes. All native names and registry-owned names use fallible exact String reservation before copying.
5. For each function in original order, allocate its bag using a private prepaid mirror of `dom_proto_object` with capacity4 (9 work /ordinary base +4K); fill its two final properties with private sorted Entry insertions and original creation order (58 work, one typed leaf). Construct a native with propertiesNone (8+full-name bytes), its separate registry String (4+full-name bytes), and stage that String/id without a heap vector. Insert the owner property through a scoped Entry helper. Do not execute public setters, dynamically discover metadata or call generic property APIs.
6. Consume the ten staged entries through the fixed sorted permutation, one Entry each. The empty-gap guard and literal uniqueness make every Entry vacant. Retain a checked impossible-collision error before insertion. Pay the full comparison/navigation/aggregate insertion allowance before the first Entry; no new quota debit may be hidden inside a live Entry borrow. The new String and id are moved, never cloned.
7. Append the final tag to the prototype in the original owner order, preserve the original well-known symbol identities, and publish the private saved handles. No author callback occurs anywhere. Any later bootstrap failure still discards the entire private realm and does not grant the author execution budget.

The above early work/heap refusal is stronger than the existing incremental private prefix. It intentionally does not preserve the old exact quota cutpoints: reducing genuine work requires new cutpoints. It preserves terminal Resource classification, no author callbacks or externally visible partial realm, all successful values/identities/orders, and the existing process-OOM limitation of Rc/BTree allocation. Allocation failures in new explicit Vec/String reservations return Resource. No quota, arena reservation or author budget is raised.

## Complete work ledger

`ledger.json` includes every old row and the following replacement rows. No inherited64-per-function shortcut is used to hide redesigned factory work.

| Row | Work |
|---|---:|
| Closed-stage guard |128|
| Constructor/prototype lookup and setup |174|
| Existing well-known symbol lookups |90|
| Empty registry gap query |256|
|17 UTF-16 strings,183 units (`8+2n`) |502|
|10 bag helpers (`9`) |90|
|10 fresh sorted two-entry maps (`16+2×18+6`) |580|
|10 native records/names (`8+n`) |305|
|10 registry String copies (`4+n`) |265|
| Saved ArrayBuffer native |19|
|10 registry Entry comparison bounds |1155|
|10 Entry search navigation/setup (`8(H+1)+4`, H3) |360|
| At most13 insertion levels (`256` each), final cleanup128 |3456|
|11 owner entries, comparisons, suffix moves and order growth |674|
| Fixed stack staging, pool/record retirement and control |96|
| **Total** |**8150**|

The96 fixed row covers20 fixed checks/control operations,40 pair staging/take/write operations,17 pool handle retirements,10 stack-slot retirements and9 spare operations. Strings own no nested per-character destruction loop.

Owner work is352 for11 fixed32-entry envelopes,266 exact examined-prefix comparisons,24 for six shifted key/value pairs (four read/write handle operations each), and32 for existing order-vector relocation. The latter moves4 constructor keys once, and4 then8 prototype keys. The full requested growth blocks8K+8K+16K are retained, not net capacity deltas. The32-entry envelope includes Entry/header/length updates, descriptor assembly, clone/write of the order key, and eventual new map/order handle retirement. The only moving owner insertions are isView (three pairs), byteLength(one), detached(two). No owner exceeds10 entries, so no owner split, root growth, or new owner tree block occurs.

## Full requested storage ledger

Let A=sizeof(Option<AbortSlot>), D=sizeof(Option<f64>), K=sizeof(PropertyKey), N=sizeof(Native), Bpp=`16*(sizeof(PropertyKey)+sizeof(Property))+32*sizeof(usize)+64`, and Bsu=`16*(sizeof(String)+sizeof(usize))+32*sizeof(usize)+64`. Use actual types in the eventual source, not the numerical census constants.

The replacement charges:

-1,820 pool bytes (temporary UTF-16 Vec +Rc copies remain fully charged).
-10×(72+A+D) ordinary bag bases;10Bpp fresh leaves;40K for four slots per function order Vec.
-32K for all reached owner order growth blocks, retaining prior storage charges without refund.
-11×(N+32)+236 bytes for ten method/getter native records and saved ArrayBuffer record/name; ten full names total225 bytes, saved name11.
-225 more bytes for the ten distinct registry-owned names.
-3Bsu for the aggregate registry split-node bound. Existing nodes and strings remain charged; there is no deallocation credit.

Thus bytes=`2281 +10*(72+A+D)+10Bpp+72K+11*(N+32)+3Bsu`. The retained census A16/D16/K16/N56/Bpp1472 and derived Bsu832 gives22,657. The old installer charges28,368 at these same sizes; `derive.py` reconstructs that directly, including11 metadata-slot chargesM8. New full Native records already include that slot. Ten ScriptObject arena slots were prepaid by the unchanged full bootstrap reservation; do not add or remove that existing charge.

The two stack arrays (pool handles and staged registry pairs) and static permutation are not heap storage. No sorting Vec, whole-registry traversal, BTree append, collect, or hidden temporary map is part of this plan. `append` is explicitly rejected because pinned Rust1.88 and1.98 take different algorithms.

## Implementation ownership and required validation

After root authorization, own `src/script/array_buffer.rs` and a new `src/script/array_buffer/bootstrap_tests.rs` (module declaration in the owned file). Keep other ArrayBuffer methods and existing tests byte-exact. Existing DOM text/object construction bodies provide the source pattern for private prepaid mirrors; do not call their charging wrappers after the aggregate debit. Root owns formatting/execution and any descriptive bootstrap snapshot correction after actual measurements.

Meaningful tests should bind the literal ten-entry roster/order/flags/name/length, all old owner descriptors/native identities and full registry key→ID mappings, exact object IDs/counts/capacity, native.propertiesNone, and registry count. Exercise the helper on a genuine preceding bootstrap state, and separately near-full insertion shapes with the same contiguous-gap invariant; include all twelve insertion edges and splits at the smallest leaf occupancy, first/last new key positions, zero/one/two leaf splits and a full parent. Check the guard's occupied-gap refusal, mismatched state/count/order-capacity refusal, and exact/one-short work and heap with no published changes. Reconcile the actual complete bootstrap diagnostic before combining Reflect; run existing ArrayBuffer/DataView/TypedArray tests and historical profiles without changing their expected outcomes. All numerical savings remain conditional until source review and root execution.
