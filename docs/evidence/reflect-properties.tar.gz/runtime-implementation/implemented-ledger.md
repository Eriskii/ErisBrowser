# Reflect operation bodies: implemented source accounting

The two new files are `src/script/reflect_properties.rs` and its child `tests.rs`. Existing assignment, Object methods, TypedArray helpers, host helpers and descriptor mutation routines are unchanged. Root separately owns installer, reservations, native-call admission, module declaration and dispatch. The operation entry API is `Runtime::reflect_property_call(name: &str, args: &[Value], doc: &mut Document) -> Result<Value>` with full names such as `Reflect.get`.

This source has not been compiled or executed. The ten private groups are proposed tests; their measured endpoints are determined by root's eventual execution. The external14-case/28-mode fixture and its five pairs/20 controls are separate validation inputs, not ten more Rust groups.

New work precedes the operation it admits. `search(n,u)=min(n,11*(1+floor(log2(n))))*(1+u)` for nonempty tables (zero for empty) bounds fixed-height BTree comparison work under the inherited logical convention. It is deliberately conservative for the small maps and does not change old helper tariffs.

| New site | Work/storage |
| --- | --- |
| Public native body |8 work for argument/dispatch/result control, before target validation or key conversion. Static this ignored. |
| Native registry resolution |Complete owned-name length times the search bound, paid per possible probe. Cached Native metadata needs no registry search. |
| Prototype edge |2 work plus registry probes and, when reached, fixed fallback prototype search. DOM's existing interface/override helper pays its own searches. |
| Own descriptor probe |8 work; TypedArray's paid canonical/live route first. Window string reflection and DOM own descriptors retain their existing admissions. |
| Ordinary stored descriptor |4 plus one full-key table search. Mapped arguments additionally pay two mapping searches and the retained binding-name search before reading its value; presence does not read that binding. |
| Virtual Array/boxed String descriptor |32+key units before index decoding; Array hole lookup charged separately. Only a value-reading boxed-string index allocates a code-unit result:2 work/64 bytes. Presence owns no character copy. |
| Get/Has traversal |2 per reached edge; terminal TypedArray absence stops the walk. Each edge then pays its own descriptor/prototype rows. |
| Set traversal |4 per reached edge; existing TypedArray Set handles same/distinct Receiver conversion and validity. The ordinary branch rechecks Receiver's own descriptor and delegates to the existing Boolean `define_property_key`. |
| Setter arguments |4 work and32+sizeof(Value) bytes before one fallible exact Vec reserve/write. The existing call path owns callback admission and guard cleanup. |
| Prototype change |6 work plus2 per visited candidate edge and the prototype helper's fees. Identity/non-extensibility/cycle decisions precede final mutation; no budget debit follows publication. |
| Extensibility |4 work plus the existing typed fixed-buffer check before mutation. A RAB view returns false; host extensibility remains Unsupported. |
| Descriptor result |276 work for twelve bounded comparisons (contains plus insertion), bounded suffix movement/control/retirement; one typed property-map node block and4K order block; explicit Object-prototype lookup and four separately paid ASCII key strings. Existing object_ordered base/property charges remain. |
| Descriptor arena growth |If full,1+2*old_count work and `(old_count+1)*sizeof(ScriptObject)` before fallible exact reserve. No hidden push growth follows. |

The descriptor result's276 row is `12*13 + 6*4 + 96`; the six moved-pair allowance bounds its actual non-sorted four-field construction. The conservative typed block is `16*(sizeof(PropertyKey)+sizeof(Property))+32*sizeof(usize)+64`. All arithmetic that can reflect arbitrary text/map size uses bounded sizes or saturating search work; arena byte multiplication is checked. No quotas or execution resets are changed.

Shared deletion/definition routines retain their existing charges and semantics, including partial Array length deletion on Boolean failure and fresh post-callback TypedArray byte checks. This ledger describes newly introduced work rather than retroactively changing old descriptor-helper tariffs. Native-body success does not promise rollback if the generic VM's later result-stack or subsequent authored operation exhausts.

The host boundary is intentional: represented DOM own expandos and installed prototype descriptors are traversed with the original Receiver. If a DOM string chain remains unresolved, Get/Has/Set report Unsupported rather than manufacture absence or a new shadow for a member represented only by legacy host fallback code. Own-only descriptor reflection retains the current ordinary DOM-own model. Style/Console/ClassList string reflection and host extensibility/prototype mutation retain Unsupported; Window strings use reflected global-property filtering and existing event-handler reflection refusals. This is not a new WebIDL fallback implementation.

The original metadata proposal remains immutable. Root's actual installer added30 work for the real @@toStringTag identity lookup, correcting the original3,248 prediction to3,278; its separate installer hold/measurement controls that change. This operation-body hold does not claim a raw bootstrap result. The reviewed ArrayBuffer prerequisite predicts3,489 savings and496 after the corrected installer, pending measurement.

Source-only review caught and corrected a test comparison against PropertyValue, which does not implement PartialEq; the test now matches the variant and compares Value/writable. No production type/expectation was altered to satisfy that issue. The descriptor construction envelope was raised from its early198 draft to276 before source freeze to include both contains_key and insertion searches. The early incremental source copy is retained.
