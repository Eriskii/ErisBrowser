# Immutable intrinsic prototype correction

Root source review found that both the new Reflect path and the existing Object path permitted changing Object.prototype. ECMA-262 20.1.3 defines this intrinsic as an immutable-prototype exotic object with initial null prototype. This additive correction preserves the original Runtime source-ready.json and all its held sources.

The shared object_prototype_is_immutable reads the existing private intrinsic registry under a prepaid 2 + min(n,11*(1+floor(log2(n))))*7 envelope (n=0 has search zero). With the current 25-entry registry this costs 177 logical work; it owns no storage. Global Object replacement cannot change that identity. Both call sites first recognize a same-prototype no-op; a different immutable prototype produces Reflect false or Object TypeError. Object.prototype remains ordinarily extensible for its own properties. Nonextensible ordinary objects preserve same-prototype success and change refusal. No state, bootstrap fee, quota, storage or native metadata changes.

Reflect's existing 6-work header covers the no-op comparison. The existing Object helper now explicitly prepays 2 work for the equality/control branch; its previous prototype-chain walk is retained for real ordinary changes, following the new intrinsic lookup. Same-prototype success skips unnecessary chain traversal as required by the abstract operation. Existing object-literal __proto__ setup uses this helper. No installed Object.prototype.__proto__ accessor is present in this implementation; this patch does not add one.

The old 20-work ordinary Reflect mutation witness now asserts exactly 20+177=197 work for the current registry, and still sweeps every cut before publication with MAX_HEAP already charged. The new immutable-refusal witness separately checks both entry-point body boundaries at one-short/exact: Object 2+177=179, Reflect 8+6+177=191, no heap, original null prototype and extensibility unchanged. The behavioral test covers renamed global Object, property extensibility, same-null, and nonextensible intrinsic/ordinary no-op behavior in both modes. The preexisting saved-native preflight and descriptor endpoint groups are unchanged. There are 12 private groups after adding these two.

No compiler, formatter, tests or engine were executed by this author. The correction is source-reviewed and unmeasured. Parent owns compilation and all observations.

Primary source: https://tc39.es/ecma262/multipage/fundamental-objects.html#sec-properties-of-the-object-prototype-object
