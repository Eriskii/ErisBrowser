
#[test]
fn background_getter_requires_geometry_declarations_in_the_same_block() {
    // CSSOM getPropertyValue returns empty for a missing longhand, even when
    // its computed initial value would be enough to paint this background.
    let mut partial = parse("background-color:yellow;background-image:linear-gradient(red,blue)");
    assert_eq!(get(&partial, "background"), "");
    for (name, value) in [
        ("background-size", "auto auto"),
        ("background-position", "0% 0%"),
    ] {
        assert!(set(&mut partial, name, value));
        assert_eq!(get(&partial, "background"), "");
    }
    assert!(set(&mut partial, "background-repeat", "repeat"));
    assert_eq!(get(&partial, "background"), "linear-gradient(red,blue) yellow");
    for name in ["background-size", "background-position", "background-repeat"] {
        let mut missing = partial.clone();
        assert!(!missing.remove_property(name, &mut WORK.clone()).unwrap().is_empty());
        assert_eq!(get(&missing, "background"), "", "missing {name}");
        assert_eq!(get(&missing, "background-color"), "yellow");
        assert_eq!(get(&missing, "background-image"), "linear-gradient(red,blue)");
    }

    // A shorthand initialization explicitly supplies all five declarations.
    // Later valid color/image setters and rejected setters retain that basis.
    let mut initialized = InlineStyle::default();
    assert!(set(&mut initialized, "background", "none"));
    assert!(set(&mut initialized, "background-color", "yellow"));
    let image = "linear-gradient(to right,currentColor 50%,transparent 50%)";
    assert!(set(&mut initialized, "background-image", image));
    assert_eq!(get(&initialized, "background"), format!("{image} yellow"));
    let saved = initialized.clone();
    assert!(!set(&mut initialized, "background-image", "linear-gradient(red,)"));
    assert!(!set(&mut initialized, "background", "linear-gradient(red,) orange"));
    assert_eq!(initialized, saved);
    assert_eq!(get(&initialized, "background-size"), "auto auto");
    assert_eq!(get(&initialized, "background-position"), "0% 0%");
    assert_eq!(get(&initialized, "background-repeat"), "repeat");
}
