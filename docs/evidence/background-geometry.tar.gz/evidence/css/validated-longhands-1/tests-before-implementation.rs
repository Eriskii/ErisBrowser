
#[test]
fn validated_background_longhands_keep_normalization_priority_and_pending_values() {
    for (property, authored, expected) in [
        ("background-image", "linear-gradient(to right,CURRENTColor 50%,transparent 50%)", "linear-gradient(to right,currentcolor 50%,transparent 50%)"),
        ("background-size", "AUTO 2px", "auto 2px"),
        ("background-position", "RIGHT calc(25% + 2px) BOTTOM", "right calc(25% + 2px) bottom"),
        ("background-repeat", "REPEAT-Y", "repeat-y"),
    ] {
        assert_eq!(records(property, authored, true, &mut WORK.clone()).unwrap(), Some(vec![Record {
            name: property.into(), value: expected.into(), important: true, pending: None,
        }]));
        for wide in ["inherit", "initial", "unset", "revert", "revert-layer"] {
            assert_eq!(records(property, wide, false, &mut WORK.clone()).unwrap(), Some(vec![Record {
                name: property.into(), value: wide.into(), important: false, pending: None,
            }]));
        }
        // Longhand variables retain authored custom-property case and are
        // accepted before ordinary validation, exactly as other pending values.
        assert_eq!(records(property, "var(--Saved)", true, &mut WORK.clone()).unwrap(), Some(vec![Record {
            name: property.into(), value: "var(--Saved)".into(), important: true, pending: None,
        }]));
    }
    let original = parse("background:linear-gradient(red) center / 4px 2px no-repeat lime;color:blue");
    for (property, invalid) in [
        ("background-image", "linear-gradient(red,)"),
        ("background-image", "linear-gradient(red]"),
        ("background-size", "-1e-999px"),
        ("background-size", "calc(1px/**/+/**/2px)"),
        ("background-position", "top 20%"),
        ("background-repeat", "repeat-x repeat"),
        ("background-repeat", "repeat\\"),
    ] {
        let mut current = original.clone();
        assert_eq!(current.set_property(property, invalid, "important", &mut WORK.clone()), Ok(false));
        assert_eq!(current, original);
    }
}

#[test]
fn validated_background_longhands_pay_one_parser_pass_before_record_publication() {
    // Literal source ledger for records(), including tokenization, variable
    // syntax, normalization allowance, first validation and storage prepay.
    // none: 60 + (49 + 49 + 270) + 69 = 497
    // size0: 24 + (13 + 13 + 19) + 66 = 135
    // pos0:  24 + (13 + 13 + 35) + 66 = 151
    // repeat:84 + (73 + 73 + 51) + 71 = 352
    for (property, value, cost) in [
        ("background-image", "none", 497),
        ("background-size", "0", 135),
        ("background-position", "0", 151),
        ("background-repeat", "repeat", 352),
    ] {
        let expected = Some(vec![Record {
            name: property.into(), value: value.into(), important: true, pending: None,
        }]);
        let mut exact = cost;
        assert_eq!(records(property, value, true, &mut exact), Ok(expected));
        assert_eq!(exact, 0);
        for cut in [0, 1, cost - 1] {
            let mut work = cut;
            assert_eq!(records(property, value, true, &mut work), Err(Error::Limit));
            assert_eq!(work, 0);
        }
    }
}
