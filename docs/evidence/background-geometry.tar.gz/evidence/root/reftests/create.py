from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;W=Path('/tmp/eris-background-geometry-1/worktree');R=W/'tests/reftests'
base='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:white}div{position:absolute}</style>\n'
grad='background-image:linear-gradient(to right,red 50%,blue 50%);'
def box(x,y,w,h,style):return f'<div style="left:{x}px;top:{y}px;width:{w}px;height:{h}px;{style}"></div>\n'
def refs(rectangles):return base+''.join(box(x,y,w,h,'background:'+color) for x,y,w,h,color in rectangles)
sets=[]
normal=grad+'background-size:16px 8px;background-position:center;background-repeat:no-repeat;'
inputs=[(20,20,normal),(80,20,normal+'background-position:25% 75%'),(140,20,normal+'background-size:64px 8px'),(200,20,normal+'background-position:right 8px bottom 4px'),(20,80,normal+'background-size:16px auto'),(80,80,normal+'background-size:auto 8px'),(140,80,normal+'background-size:cover'),(200,80,normal+'background-size:calc(50% - 8px) 8px'),(20,130,normal+'background-color:lime;background-size:calc(50% - 30px) 8px')]
rectangles=[]
for x,y,w,h in [(36,28,8,8),(88,32,8,8),(140,28,24,8),(224,32,8,8),(36,80,8,24),(80,88,24,8),(140,80,24,24),(216,88,8,8)]:rectangles += [(x,y,w,h,'red'),(x+w,y,w,h,'blue')]
rectangles.append((20,130,48,24,'lime'))
sets.append(('background-geometry-position','Single-layer size and physical/percentage position resolve after sizing; auto, oversized, cover, calc and zero values use independent rectangle references.',base+''.join(box(x,y,48,24,s) for x,y,s in inputs),rectangles))
inputs=[(20,20,normal+'background-repeat:repeat-x'),(80,20,normal+'background-repeat:repeat-y'),(140,20,normal+'background-repeat:repeat repeat'),(200,20,normal+'background-repeat:no-repeat repeat')]
rectangles=[]
for x,y,w,h in [(20,28,8,8),(36,28,8,8),(52,28,8,8),(96,20,8,24),(140,20,8,24),(156,20,8,24),(172,20,8,24),(216,20,8,24)]:rectangles += [(x,y,w,h,'red'),(x+w,y,w,h,'blue')]
page=base+''.join(box(x,y,48,24,s) for x,y,s in inputs)
page+=box(20,80,32,16,normal+'padding:4px;border:4px solid transparent;background-repeat:repeat')
for x in [20,36,52]:rectangles += [(x,80,8,32,'red'),(x+8,80,8,32,'blue')]
sets.append(('background-geometry-repeat','Independent repeat axes and aliases preserve tile phase through the border painting area.',page,rectangles))
page=base;rectangles=[]
for x,position,out in [(20,'.25px .5px',[(20,'red'),(21,'blue')]),(40,'.5px .5px',[(40,'red'),(41,'blue')]),(60,'.75px .5px',[(61,'red'),(62,'blue')]),(80,'-.75px .5px',[(80,'blue')])]:
 page+=box(x,20,8,4,grad+f'background-size:2px 1px;background-position:{position};background-repeat:no-repeat')
 rectangles += [(x,20,1,1,color) for x,color in out]
page+=box(20,80,12,6,grad+'background-size:4px 2px;background-position:center;background-repeat:no-repeat;border-radius:3px')
rectangles += [(24,82,2,2,'red'),(26,82,2,2,'blue')]
page+=box(70,80,6,3,'background-image:linear-gradient(to right,rgb(248 0 0),transparent);background-size:4px 1px;background-position:center;background-repeat:no-repeat')
rectangles += [(71+i,81,1,1,color) for i,color in enumerate(['#f92020','#fb6060','#fc9f9f','#fedfdf'])]
sets.append(('background-geometry-fractional','Nonrepeat accepts half-open pixel centers, keeps the original rounded outline and preserves premultiplied transparent-stop blending.',page,rectangles))
# Freeze the independently specified rectangles before writing test/reference pages.
(P/'oracles.json').write_text(json.dumps([dict(name=n,description=d,expected_rectangles=r) for n,d,t,r in sets],indent=2)+'\n')
m=json.loads((R/'manifest.json').read_text());assert len(m['cases'])==68
files=[]
for n,d,t,r in sets:
 for name,data in [(n+'.html',t),(n+'-ref.html',refs(r))]:
  (R/name).write_text(data);files.append(R/name)
 m['cases'].append(dict(name=n,description=d,test=n+'.html',reference=n+'-ref.html'))
(R/'manifest.json').write_text(json.dumps(m,indent=2)+'\n');files.append(R/'manifest.json')
rows=[]
for f in files:
 target=P/'raw'/f.name;target.parent.mkdir(exist_ok=True);target.write_bytes(f.read_bytes());rows.append(dict(relative=str(f.relative_to(W)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(P/'source-ready.json').write_text(json.dumps(dict(status='root-authored static reference fixtures before project execution;71 cases including68 preserved prior cases',files=rows),indent=2)+'\n')
print('Added3 independent reference comparisons;71 total')
