

#[test]
fn gradient_tile_translation_is_bounded_without_shifting_repetition_phase() {
    let command = |tile| DrawCommand::LinearGradient {
        rect: rect(0.0, 0.0, 4.0, 2.0), tile, radius: 0.0,
        gradient: image(), current_color: Color::BLACK, stop_scale: 1.0,
        repeat: [true; 2],
    };
    for (tile, dx, dy, expected) in [
        (rect(1.0, 2.0, 4.0, 2.0), 3.0, 5.0, Some(rect(4.0, 7.0, 4.0, 2.0))),
        (rect(999_998.0, 0.0, 4.0, 2.0), 2.0, 0.0, Some(rect(1_000_000.0, 0.0, 4.0, 2.0))),
        (rect(999_998.0, 0.0, 4.0, 2.0), 3.0, 0.0, None),
        (rect(-999_998.0, 0.0, 4.0, 2.0), -2.0, 0.0, Some(rect(-1_000_000.0, 0.0, 4.0, 2.0))),
        (rect(-999_998.0, 0.0, 4.0, 2.0), -3.0, 0.0, None),
        (rect(0.0, 999_998.0, 4.0, 2.0), 0.0, 3.0, None),
        (rect(0.0, -999_998.0, 4.0, 2.0), 0.0, -3.0, None),
        // Do not let f32 addition round an out-of-bound origin back to the limit.
        (rect(1_000_000.0, 0.0, 4.0, 2.0), 0.01, 0.0, None),
        (rect(0.0, 0.0, 4.0, 2.0), f32::NAN, 0.0, None),
    ] {
        let mut moved = command(tile);
        translate(&mut moved, dx, dy);
        let DrawCommand::LinearGradient { tile, .. } = moved else { panic!("gradient") };
        assert_eq!(tile, expected.unwrap_or_default());
    }
    let mut pending = command(Rect { x: 1.0, y: 2.0, width: -1.0, height: 2.0 });
    translate(&mut pending, 3.0, 5.0);
    assert!(matches!(&pending, DrawCommand::LinearGradient { tile, .. } if *tile == Rect { x: 4.0, y: 7.0, width: -1.0, height: 2.0 }));
    translate(&mut pending, 1_000_000.0, 0.0);
    assert!(matches!(&pending, DrawCommand::LinearGradient { tile, .. } if *tile == Rect::default()));
    translate(&mut pending, -1_000_000.0, 0.0);
    assert!(matches!(&pending, DrawCommand::LinearGradient { tile, .. } if tile.width == 0.0));
}

#[test]
fn table_placement_omits_out_of_range_tiles_and_preserves_exact_boundary_phase() {
    let (doc, mut styles) = prepare("<style>body{margin:0}table{width:14px}tr{height:6px}td{width:4px;height:2px;padding:0}</style><table><tr><td id=a></td><td></td></tr></table>", 14.0, 10.0);
    let a = doc.query_selector("#a").unwrap();
    let baseline = layout(&doc, &styles, 14.0, 10.0, &Fonts::new());
    assert_eq!(paint(&baseline, 14, 10), vec![0xffffff; 140]);
    styles[a].background_image = Some(image());
    styles[a].background_size = explicit(Length::Px(4.0), Length::Px(2.0));
    styles[a].background_position = position(Length::Px(1_000_000.0), Length::Px(0.0));
    let omitted = layout(&doc, &styles, 14.0, 10.0, &Fonts::new());
    assert!(gradients(&omitted).is_empty());
    assert_eq!(paint(&omitted, 14, 10), vec![0xffffff; 140]);
    assert_eq!(hits(&omitted), hits(&baseline));
    styles[a].background_position = position(Length::Px(999_998.0), Length::Px(0.0));
    let boundary = layout(&doc, &styles, 14.0, 10.0, &Fonts::new());
    assert_eq!(gradients(&boundary), [(rect(2.0, 2.0, 4.0, 6.0), rect(1_000_000.0, 2.0, 4.0, 2.0), [true; 2])]);
    assert_eq!(paint(&boundary, 14, 10), rows(&[
        "WWWWWWWWWWWWWW", "WWWWWWWWWWWWWW",
        "WWBBRRWWWWWWWW", "WWBBRRWWWWWWWW", "WWBBRRWWWWWWWW",
        "WWBBRRWWWWWWWW", "WWBBRRWWWWWWWW", "WWBBRRWWWWWWWW",
        "WWWWWWWWWWWWWW", "WWWWWWWWWWWWWW",
    ]));
    assert_eq!(hits(&boundary), hits(&baseline));
}
