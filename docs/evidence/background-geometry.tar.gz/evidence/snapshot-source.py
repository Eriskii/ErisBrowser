from pathlib import Path
import json,hashlib,subprocess,sys
p=Path(__file__).resolve().parent;w=p/'worktree'
old=json.loads(Path('/tmp/eris-vulkan-gradients-1/compiled-source-2.json').read_text())['source_sha256']
names=set(old)
changed=subprocess.check_output(['git','-C',str(w),'diff','HEAD','--name-only','-z']).decode().split('\0')
new=subprocess.check_output(['git','-C',str(w),'ls-files','--others','--exclude-standard','-z']).decode().split('\0')
for name in changed+new:
 if name and not name.startswith('docs/') and not name.endswith('.md'):names.add(name)
names.add('.github/workflows/check.yml')
rows={name:hashlib.sha256((w/name).read_bytes()).hexdigest() for name in sorted(names)}
result={'base':'c9231785978b6669055fea2684749084ddddec9b','scope':'Root, core and probe compile/runtime inputs inherited from the published native-gradient hold plus every changed/new non-document input; background size, position and repeat geometry.','source_sha256':rows}
out=p/sys.argv[1]
with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'path':str(out),'inputs':len(rows),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
