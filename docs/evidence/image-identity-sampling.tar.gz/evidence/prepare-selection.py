from pathlib import Path
import hashlib,json,re,subprocess
R=Path(__file__).resolve().parent;W=R/'worktree';Q=Path('/tmp/eris-image-identity-preparation-1');P=Path('/tmp/eris-object-fit-position-1')
def b(p):
 d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
sources={'candidate':b(R/'compiled-source-1.json'),'unit_baseline':b(R/'baseline-source-1.json'),'gpu_unsplit':b(R/'baseline-source-2.json'),'before_gpu':b(R/'baseline-source-3.json'),'prior_browser':b(P/'compiled-source-3.json')}
checks={}
def check(name,p,source):
 d=json.loads(p.read_text());lp=p.parent/d['log'];rows=re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;',lp.read_text(),re.M)
 checks[name]={'receipt':b(p),'log':b(lp),'argv':d['command'],'exit':d['exit'],'source':source,'rust_results':[sum(int(a) for a,_ in rows),sum(int(c) for _,c in rows),len(rows)] if rows else None}
roles={
 'baseline-canvas-1':'unit_baseline','baseline-core-1':'unit_baseline','baseline-reftests-1':'prior_browser',
 'baseline-gpu-build-1':'gpu_unsplit','probe-fetch-1':'gpu_unsplit','baseline-gpu-build-2':'gpu_unsplit','baseline-gpu-build-3':'before_gpu','baseline-gpu-list-1':'before_gpu',
 'full-native-1':'candidate','full-default-198-1':'candidate','core-gpu-198-1':'candidate','clippy-198-1':'candidate','clippy-msrv-1':'candidate','core-clippy-msrv-1':'candidate','probe-clippy-198-1':'candidate','format-check-all-1':'candidate','candidate-gpu-build-1':'candidate','candidate-browser-build-1':'candidate','candidate-browser-strip-1':'candidate','candidate-reftests-1':'candidate','original-svg-regression-1':'candidate'}
for i in range(1,4):roles[f'baseline-gpu-adapter-{i}']='before_gpu';roles[f'candidate-gpu-adapter-{i}']='candidate'
for name,role in roles.items():check(name,R/'validation'/(name+'.json'),role)
check('prior-browser-build',P/'validation/candidate-build-1.json','prior_browser');check('prior-browser-strip',P/'validation/candidate-strip-1.json','prior_browser')
reports={}
for key,report,manifest,binary,label,counts in [
 ('baseline',R/'reftests-baseline-1/report.json',Q/'reftests/only-new.json','prior_browser','baseline-reftests-1',[0,3,3]),
 ('candidate',R/'reftests-candidate-1/report.json',W/'tests/reftests/manifest.json','candidate_browser','candidate-reftests-1',[65,0,65]),
 ('original_svg',R/'reftests-original-svg-1/report.json',P/'root-reftests/only-combined.json','candidate_browser','original-svg-regression-1',[1,0,1])]:
 reports[key]={'report':b(report),'manifest':b(manifest),'binary':binary,'check':label,'counts':counts}
gpu={};adapter_lines=[]
rx=re.compile(r'^PASS (\S+) (\d+)x(\d+) draws=(\d+) invocations=(\d+) gpu_buffers=(\d+) compared_bytes=(\d+) exact=true$',re.M)
for phase,binary in [('baseline','before_gpu'),('candidate','candidate_gpu')]:
 for i in range(3):
  label=f'{phase}-gpu-adapter-{i+1}';raw=(R/'validation'/(label+'.log')).read_text();line=next(x for x in raw.splitlines() if x.startswith(f'ADAPTER {i} '));failure=next((x for x in raw.splitlines() if x.startswith('FAIL ')),None);passes=[[row[0],*map(int,row[1:])] for row in rx.findall(raw)]
  gpu[label]={'check':label,'binary':binary,'adapter':i,'adapter_line':line,'passes':passes,'failure':failure}
  if phase=='candidate':adapter_lines.append(line)
reviews={'production':R/'production-layout-review.json','initial_production':Q/'script/html-source-review.json','browser_fixtures':Q/'reftests/script-review.json','gpu_fixtures':Q/'layout/script-review-2.json','documentation':Q/'docs/layout-review.json','publisher':R/'package-preparation/html-review.json'}
evidence=[R/n for n in ['prepare-selection.py','run-tool.py','run-check.py','check-format.py','verify-staged.py','parent-publication.json','validation/parent-ci-3.json','validation/parent-ci-3.log','tests-only-integration-1.json','reftest-integration-1.json','gpu-fixture-integration-1.json','gpu-fixture-integration-2.json','production-integration-1.json','docs-integration-1.json','before-probe-split/record.json','package-preparation/source-ready.json']]
evidence += [Q/n for n in ['script/tests-source-ready.json','script/source-ready.json','script/plan.json','script/production.diff','reftests/source-ready-2.json','reftests/literal-oracles.json','layout/source-ready-2.json','layout/literal-oracles.json','layout/hold1/source-ready.json','layout/hold1/script-review.json','layout/script-review-correction-1.json','docs/source-ready-2.json']]
for n in ['image-identity-240-cross-125','image-identity-fractional-clip-original-origin','image-identity-y-only-with-x-upscale']:evidence.append(Q/'layout'/(n+'.expected-rgb32le'))
for n in ['tools/vulkan-raster-probe/Cargo.toml','tools/vulkan-raster-probe/src/main.rs','tools/vulkan-raster-probe/src/lib.rs','tools/vulkan-raster-probe/src/identity_fixtures.rs']:evidence.append(R/'before-probe-split'/n)
# Exact external inputs for predecessor and original-SVG reference observations.
for row in json.loads((Q/'reftests/source-ready-2.json').read_text())['drafts']:evidence.append(Path(row['path']))
for n in ['object-fit-combined-scale-down.html','object-fit-combined-scale-down-ref.html','object-fit-large.png','object-fit-small.png']:evidence.append(P/'root-reftests/draft/tests/reftests'/n)
for folder,names in [('reftests-baseline-1',['image-identity-svg','image-identity-clipped','image-identity-mixed-axes']),('reftests-candidate-1',['image-identity-svg','image-identity-clipped','image-identity-mixed-axes']),('reftests-original-svg-1',['object-fit-combined-scale-down'])]:
 for name in names:
  for suffix in ['.png','-ref.png','-diff.png']:
   p=R/folder/(name+suffix)
   if p.is_file():evidence.append(p)
changed=set(subprocess.check_output(['git','diff','HEAD','--name-only','-z'],cwd=W).decode().split('\0'))|set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=W).decode().split('\0'));changed.discard('')
s={'sources':sources,'live_source':'candidate','live_source_count':480,'final_source_roles':['candidate'],'published':{n:b(W/n) for n in sorted(changed)},'reviews':{n:b(p) for n,p in reviews.items()},'checks':checks,'final_checks':{'native':'full-native-1','default':'full-default-198-1','core':'core-gpu-198-1','clippy_msrv':'clippy-msrv-1','clippy_198':'clippy-198-1','format':'format-check-all-1','browser_build':'candidate-browser-build-1','gpu_build':'candidate-gpu-build-1','reftests':'candidate-reftests-1'},'binaries':{'prior_browser':b(P/'candidate-binary.json'),'before_gpu':b(R/'baseline-gpu-binary.json'),'candidate_browser':b(R/'candidate-browser-binary.json'),'candidate_gpu':b(R/'candidate-gpu-binary.json')},'reports':reports,'final_report':'candidate','gpu_runs':gpu,'baseline_gpu_runs':[f'baseline-gpu-adapter-{i}' for i in range(1,4)],'final_gpu_runs':[f'candidate-gpu-adapter-{i}' for i in range(1,4)],'expected_adapter_lines':adapter_lines,'evidence':[b(p) for p in evidence]}
with (R/'package-selection.json').open('x') as f:json.dump(s,f,indent=2);f.write('\n')
print(json.dumps({'published':len(changed),'checks':len(checks),'evidence':len(evidence),'gpu_runs':len(gpu)}))
