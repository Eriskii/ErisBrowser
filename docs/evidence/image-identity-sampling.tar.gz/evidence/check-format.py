import os,subprocess,json
from pathlib import Path
R=Path(__file__).resolve().parent
env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
for manifest in ['Cargo.toml','crates/raster-core/Cargo.toml','tools/vulkan-raster-probe/Cargo.toml']:
 command=['cargo','+1.98.0','fmt','--manifest-path',manifest,'--','--check']
 print(json.dumps(command),flush=True)
 subprocess.run(command,cwd=R/'worktree',env=env,close_fds=True,check=True)
