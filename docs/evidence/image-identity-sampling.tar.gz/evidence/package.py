#!/usr/bin/env python3
"""Root-run, explicit-input evidence packaging; never runs project code."""
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
Q = Path('/tmp/eris-image-identity-preparation-1')
BASE = '4472ce6b633a14cfcba767ec9331d079c8c8fa8c'
OUT = W / 'docs/evidence'
STEM = 'image-identity-sampling'
members = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, sort_keys=True, indent=2) + '\n').encode()


def path_checked(value):
    p = Path(value)
    require(p.is_absolute() and '..' not in p.parts, f'absolute clean path required: {p}')
    require(not any(q.is_symlink() for q in (p, *p.parents)), f'symlink: {p}')
    require(p.is_file(), f'not a regular file: {p}')
    return p


def member_name(p):
    for root, prefix in ((W, 'worktree'), (P, 'evidence'), (Q, 'preparation')):
        if p.is_relative_to(root):
            return prefix + '/' + p.relative_to(root).as_posix()
    return 'context/' + digest(str(p).encode())[:16] + '/' + p.name


def bound(row, archive=True):
    p = path_checked(row['path'])
    require(p.stat().st_size == row['bytes'], f'byte count: {p}')
    if not archive:  # Binaries are hashed in bounded chunks and never archived.
        h = hashlib.sha256()
        with p.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(chunk)
        require(h.hexdigest() == row['sha256'], f'hash: {p}')
        return None
    require(row['bytes'] <= 8 * 1024 * 1024, f'oversized archive input: {p}')
    require(not any(x in ('.git', '__pycache__', 'node_modules') or x.startswith('target') for x in p.parts), f'excluded tree: {p}')
    require(not p.name.endswith(('.tar', '.tar.gz', '.tgz', '.zip', '.xz', '.gz')), f'recursive archive: {p}')
    data = p.read_bytes()
    require(not data.startswith(b'\x7fELF'), f'ELF archive input: {p}')
    require(not data.startswith((b'\x1f\x8b', b'PK\x03\x04', b'\xfd7zXZ\x00')) and data[257:262] != b'ustar', f'archive input: {p}')
    require(digest(data) == row['sha256'], f'hash: {p}')
    name = member_name(p)
    require(name not in members or members[name] == data, f'colliding archive path: {name}')
    members[name] = data
    return data


def binding(p):
    p = path_checked(str(p))
    data = p.read_bytes()
    return {'path': str(p), 'bytes': len(data), 'sha256': digest(data)}


def load(row):
    return json.loads(bound(row))


def git(*args):
    return subprocess.check_output(['git', '-C', str(W), *args])


def main():
    require(len(sys.argv) == 2, 'usage: package.py ABSOLUTE_PACKAGE_SELECTION_JSON')
    require(not any(p.is_symlink() for p in (OUT, *OUT.parents)), 'symlink output directory')
    require(not any((OUT / (STEM + suffix)).exists() for suffix in ('.json', '.tar.gz')), 'exclusive outputs already exist')
    selection_row = binding(Path(sys.argv[1]))
    selection = load(selection_row)
    bound(binding(Path(__file__)))
    require(git('rev-parse', 'HEAD').decode().strip() == BASE, 'worktree HEAD')
    sources = {name: load(row) for name, row in selection['sources'].items()}
    live_role = selection['live_source']
    live = sources[live_role]
    require(live['base'] == BASE and len(live['source_sha256']) == selection['live_source_count'], 'live source inventory')
    for name, sha in live['source_sha256'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts, 'source path')
        require(binding(W / name)['sha256'] == sha, f'live source changed: {name}')

    published = {}
    for name, row in selection['published'].items():
        require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts and not name.startswith('docs/evidence/'), 'published path')
        require(row['path'] == str(W / name), 'published path binding')
        bound(row)
        published[name] = {k: row[k] for k in ('bytes', 'sha256')}
        if Path(name).suffix in ('.rs', '.toml', '.lock', '.html', '.png'):
            require(live['source_sha256'].get(name) == row['sha256'], f'unbound changed runtime input: {name}')
    changed = set(git('diff', 'HEAD', '--name-only', '-z').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    require(changed - {''} == set(published), 'published roster differs from changed files')
    require({'documentation', 'production', 'browser_fixtures', 'gpu_fixtures'} <= set(selection['reviews']), 'required reviews')
    for name, row in selection['reviews'].items():
        review = load(row)
        require(review['status'].startswith('clear') and review['files'], f'review not clear/bound: {name}')
        for item in review['files']:
            bound(item, archive=False)
        if name == 'documentation':
            reviewed = {item['path']: {k: item[k] for k in ('bytes', 'sha256')} for item in review['files']}
            require(all(reviewed.get(str(W / p)) == meta for p, meta in published.items() if p.endswith('.md')), 'published documentation review coverage')
    for row in selection['evidence']:
        bound(row)

    checks, receipts, logs = {}, {}, {}
    result_re = re.compile(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed;', re.M)
    for name, spec in selection['checks'].items():
        receipt = load(spec['receipt'])
        raw = bound(spec['log'])
        require(receipt['command'] == spec['argv'] and receipt['exit'] == spec['exit'], f'command/exit: {name}')
        require(Path(spec['receipt']['path']).parent / receipt['log'] == Path(spec['log']['path']) and receipt['sha256'] == spec['log']['sha256'], f'log join: {name}')
        require(spec['source'] in sources, f'check source role: {name}')
        log = raw.decode('utf-8', errors='replace')
        rows = [(int(a), int(b)) for a, b in result_re.findall(log)]
        totals = [sum(a for a, _ in rows), sum(b for _, b in rows), len(rows)] if rows else None
        require(totals == spec['rust_results'], f'raw Rust totals: {name}')
        receipts[name], logs[name] = receipt, log
        checks[name] = {'exit': receipt['exit'], 'results': totals, 'source': spec['source'], 'receipt': spec['receipt'], 'log': spec['log']}
    for name, totals in {'baseline-canvas-1': [3, 3, 1], 'baseline-core-1': [3, 2, 1]}.items():
        require(checks[name]['exit'] == 101 and checks[name]['results'] == totals, f'retained baseline: {name}')
    require({'native', 'default', 'core', 'clippy_msrv', 'clippy_198', 'format', 'browser_build', 'gpu_build', 'reftests'} == set(selection['final_checks']), 'final check roles')
    for role, name in selection['final_checks'].items():
        require(checks[name]['exit'] == 0 and checks[name]['source'] in selection['final_source_roles'], f'final source/success: {role}')
    for role in selection['final_source_roles']:
        require(sources[role]['base'] == BASE and all(live['source_sha256'].get(n) == sha for n, sha in sources[role]['source_sha256'].items()), f'final compiled/live source relation: {role}')

    binaries = {}
    for name, row in selection['binaries'].items():
        binary = load(row)
        bound(binary, archive=False)
        require(binary['compiled_source'] in selection['sources'].values(), f'binary source: {name}')
        matching = [s for s in selection['checks'].values() if s['receipt'] == binary['build_receipt']]
        require(len(matching) == 1 and matching[0]['exit'] == 0 and selection['sources'][matching[0]['source']] == binary['compiled_source'], f'binary build/source join: {name}')
        if 'strip_receipt' in binary:
            require(any(s['receipt'] == binary['strip_receipt'] and s['exit'] == 0 and selection['sources'][s['source']] == binary['compiled_source'] for s in selection['checks'].values()), f'binary strip/source join: {name}')
        binaries[name] = binary
    require({'prior_browser', 'before_gpu', 'candidate_browser', 'candidate_gpu'} <= set(binaries), 'required binary roles')
    for name, role in (('candidate_browser', 'browser_build'), ('candidate_gpu', 'gpu_build')):
        require(binaries[name]['build_receipt'] == selection['checks'][selection['final_checks'][role]]['receipt'], f'final binary/build role: {name}')
    prior = binaries['prior_browser']
    require(prior['path'] == '/tmp/eris-object-fit-position-1/eris-browser-candidate-1' and prior['bytes'] == 61784200 and prior['sha256'] == '2255e59e2aeb1a4e7c58c59166c98243f91e02d4e7432a07bdc17f33210ec8b5', 'published predecessor binary')

    report_counts = {}
    for name, spec in selection['reports'].items():
        report, manifest = load(spec['report']), load(spec['manifest'])
        command = receipts[spec['check']]['command']
        require(command[:2] == ['python3', str(W / 'tools/reftest.py')], 'reftest driver')
        require(command[command.index('--output-dir') + 1] == str(Path(spec['report']['path']).parent), 'reftest output')
        actual_manifest = command[command.index('--manifest') + 1] if '--manifest' in command else str(W / 'tests/reftests/manifest.json')
        require(actual_manifest == spec['manifest']['path'], 'reftest manifest')
        binary = binaries[spec['binary']]
        require(command[command.index('--binary') + 1] == binary['path'] == report['binary'], 'reftest binary')
        if spec['binary'] == 'candidate_browser':
            require(checks[spec['check']]['source'] == live_role, 'candidate reference/live source join')
        cases = report['cases']
        require([r['name'] for r in cases] == [r['name'] for r in manifest['cases']] and len({r['name'] for r in cases}) == len(cases), 'reftest identities/order')
        require(report['suite'] == 'eris-self-authored-reftests' and report['conformance_claim'] is False, 'reftest scope')
        require(report['viewport'] == {'width': manifest['width'], 'height': manifest['height']}, 'reftest viewport')
        for row in cases:
            require(row['status'] in ('pass', 'fail', 'error'), 'reftest status')
            if row['status'] != 'error':
                require((row['different_pixels'] == 0) == (row['status'] == 'pass'), 'reftest pixels/status')
        counts = [sum(r['status'] == 'pass' for r in cases), sum(r['status'] != 'pass' for r in cases), len(cases)]
        require(counts == spec['counts'] == [report['passed'], report['failed'], report['total']], 'reftest counts')
        require(receipts[spec['check']]['exit'] == int(counts[1] != 0), 'reftest exit/counts')
        report_counts[name] = counts
    require(report_counts['baseline'] == [0, 3, 3] and selection['reports']['baseline']['binary'] == 'prior_browser', 'browser baseline retained')
    final_report = selection['reports'][selection['final_report']]
    require(report_counts[selection['final_report']] == [65, 0, 65] and final_report['binary'] == 'candidate_browser' and final_report['check'] == selection['final_checks']['reftests'], 'final65 reference suite')

    gpu = {}
    identity_passes = [
        ['image-identity-240-cross-125', 240, 240, 2, 115200, 693632, 230400],
        ['image-identity-fractional-clip-original-origin', 20, 8, 3, 384, 5936, 640],
        ['image-identity-y-only-with-x-upscale', 6, 240, 2, 3840, 14928, 5760],
    ]  # Independent held fixture/plan literals, not guessed observations.
    pass_re = re.compile(r'^PASS (\S+) (\d+)x(\d+) draws=(\d+) invocations=(\d+) gpu_buffers=(\d+) compared_bytes=(\d+) exact=true$', re.M)
    for name, spec in selection['gpu_runs'].items():
        command, log = receipts[spec['check']]['command'], logs[spec['check']]
        require(binaries[spec['binary']]['path'] in command and command[command.index('--adapter') + 1] == str(spec['adapter']), 'GPU binary/adapter argv')
        require(selection['sources'][checks[spec['check']]['source']] == binaries[spec['binary']]['compiled_source'], 'GPU binary/run source join')
        require(log.splitlines().count(spec['adapter_line']) == 1 and spec['adapter_line'].startswith(f"ADAPTER {spec['adapter']} "), 'GPU adapter identity')
        passes = [[row[0], *map(int, row[1:])] for row in pass_re.findall(log)]
        require(passes == spec['passes'] and len({r[0] for r in passes}) == len(passes) and len(passes) == sum(line.startswith('PASS ') for line in log.splitlines()), 'GPU full ordered PASS rows')
        complete = [line for line in log.splitlines() if line.startswith('COMPLETE ')]
        failures = [line for line in log.splitlines() if line.startswith('FAIL ')]
        if spec['failure'] is None:
            require(receipts[spec['check']]['exit'] == 0 and not failures and complete == [f"COMPLETE adapter={spec['adapter']} fixtures={len(passes)} exact=true custom_wgsl=true"], 'GPU completion')
        else:
            require(receipts[spec['check']]['exit'] == 1 and not complete and failures == [spec['failure']], 'GPU retained failure')
        gpu[name] = {'check': spec['check'], 'binary': spec['binary'], 'adapter': spec['adapter'], 'adapter_line': spec['adapter_line'], 'passes': passes, 'failure': spec['failure']}
    require(selection['baseline_gpu_runs'], 'baseline GPU runs required')
    for name in selection['baseline_gpu_runs']:
        baseline_gpu = gpu[name]
        require(baseline_gpu['binary'] == 'before_gpu' and not baseline_gpu['passes'] and baseline_gpu['failure'] == 'FAIL image-identity-240-cross-125: pixel (125,0) actual=00808080 expected=0000ff00', 'actual baseline pixel mismatch retained')
    require(selection['final_gpu_runs'] and set(selection['final_gpu_runs']) <= set(gpu), 'selected actual GPU runs')
    for name in selection['final_gpu_runs']:
        run = gpu[name]
        require(run['binary'] == 'candidate_gpu' and run['failure'] is None and run['passes'] == identity_passes, 'final complete identity fixture comparison')
    require([gpu[n]['adapter_line'] for n in selection['final_gpu_runs']] == selection['expected_adapter_lines'], 'selected adapter roster')
    require([gpu[n]['adapter_line'] for n in selection['baseline_gpu_runs']] == selection['expected_adapter_lines'] and len(set(selection['expected_adapter_lines'])) == len(selection['expected_adapter_lines']), 'before/after adapter identity roster')

    require(sum(map(len, members.values())) <= 32 * 1024 * 1024, 'archive budget')
    index = {name: {'bytes': len(data), 'sha256': digest(data)} for name, data in sorted(members.items())}
    members['index.json'] = encoded(index)
    OUT.mkdir(parents=True, exist_ok=True)
    archive_path = OUT / (STEM + '.tar.gz')
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.USTAR_FORMAT) as archive:
                for name, data in sorted(members.items()):
                    entry = tarfile.TarInfo(name)
                    entry.size, entry.mode, entry.mtime = len(data), 0o644, 0
                    archive.addfile(entry, io.BytesIO(data))
    with tarfile.open(archive_path, 'r:gz') as archive:
        entries = archive.getmembers()
        require([r.name for r in entries] == sorted(members) and all(r.isfile() for r in entries), 'reopened archive roster/type')
        for entry in entries:
            require(archive.extractfile(entry).read() == members[entry.name], f'reopened bytes: {entry.name}')
        require(json.loads(archive.extractfile('index.json').read()) == index, 'reopened index')
    archive_data = archive_path.read_bytes()
    summary = {'schema': 'eris-image-identity-evidence-v1', 'base': BASE, 'sources': selection['sources'], 'live_source': live_role,
               'published_bindings': published, 'archive': archive_path.name, 'archive_bytes': len(archive_data),
               'archive_sha256': digest(archive_data), 'archive_members': len(members), 'checks': checks, 'reftests': report_counts,
               'gpu': gpu, 'binaries': selection['binaries'], 'reviews': selection['reviews'], 'selection': selection_row,
               'scope': 'Focused per-axis identity sampling evidence; no general scaling, global conformance, security, window or performance claim.'}
    with (OUT / (STEM + '.json')).open('xb') as stream:
        stream.write(encoded(summary))
    print(json.dumps({'archive_bytes': len(archive_data), 'archive_sha256': digest(archive_data), 'archive_members': len(members)}))


if __name__ == '__main__':
    main()
