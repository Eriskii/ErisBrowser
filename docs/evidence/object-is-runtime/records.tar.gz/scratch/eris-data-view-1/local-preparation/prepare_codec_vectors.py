#!/usr/bin/env python3
"""Transcribe independent literals and expand IEEE fields with integer arithmetic.

This never imports an engine or implementation codec. Python binary64 packing is
only used to spell already-selected exact Number input values as bits.
"""
import hashlib
import json
import math
import struct
from fractions import Fraction
from pathlib import Path

HERE=Path(__file__).resolve().parent

def f64(value):
    return struct.pack('>d',float(value)).hex()

def exact_f64_bits(integer, exponent, negative=False):
    """Encode integer*2**exponent exactly, requiring <=53 significant bits."""
    sign=int(negative)<<63
    if integer==0:
        return f'{sign:016x}'
    while integer%2==0:
        integer//=2
        exponent+=1
    assert integer.bit_length()<=53
    top=integer.bit_length()-1+exponent
    assert -1074<=top<=1023
    if top>=-1022:
        fraction=(integer<<(53-integer.bit_length()))&((1<<52)-1)
        result=sign|((top+1023)<<52)|fraction
    else:
        assert exponent>=-1074
        result=sign|(integer<<(exponent+1074))
    return f'{result:016x}'

def ieee_decoded_bits(raw, exponent_bits, fraction_bits):
    value=int(raw,16)
    sign=value>>(exponent_bits+fraction_bits)
    exponent=(value>>fraction_bits)&((1<<exponent_bits)-1)
    fraction=value&((1<<fraction_bits)-1)
    if exponent==(1<<exponent_bits)-1:
        if fraction:
            return 'NaN'
        return 'fff0000000000000' if sign else '7ff0000000000000'
    bias=(1<<(exponent_bits-1))-1
    return exact_f64_bits(fraction if exponent==0 else (1<<fraction_bits)|fraction,
                          (1-bias-fraction_bits) if exponent==0 else exponent-bias-fraction_bits,
                          bool(sign))

def fraction64(raw):
    value=int(raw,16)
    sign=value>>63
    exponent=(value>>52)&2047
    fraction=value&((1<<52)-1)
    if exponent==2047:
        return None
    integer=fraction if exponent==0 else (1<<52)|fraction
    power=-1074 if exponent==0 else exponent-1023-52
    result=Fraction(integer*(1<<max(power,0)),1<<max(-power,0))
    return -result if sign else result

def trunc(value):
    return value.numerator//value.denominator if value>=0 else -((-value.numerator)//value.denominator)

ROWS=[]
def row(name,codec,input_bits,expected):
    if expected=='NaN':
        decoded='NaN'
    elif codec.startswith('Float'):
        exponent,fraction={'Float16':(5,10),'Float32':(8,23),'Float64':(11,52)}[codec]
        decoded=ieee_decoded_bits(expected,exponent,fraction)
    else:
        width=int(codec.removeprefix('Uint').removeprefix('Int'))
        value=int(expected,16)
        if codec.startswith('Int') and value&(1<<(width-1)):
            value-=1<<width
        decoded=exact_f64_bits(abs(value),0,value<0)
        number=fraction64(input_bits)
        actual=(trunc(number) if number is not None else 0)%(1<<width)
        assert actual==int(expected,16),(name,actual,expected)
    assert len(expected)==int(codec.removeprefix('Uint').removeprefix('Int').removeprefix('Float'))//4 if expected!='NaN' else True
    ROWS.append([name,codec,input_bits,expected,decoded])

for codec,number,expected,other,other_expected in [
    ('Int8',-2.9,'fe',257.9,'01'),('Uint8',-2.9,'fe',257.9,'01'),
    ('Int16',-4660,'edcc',65537.9,'0001'),('Uint16',-4660,'edcc',65537.9,'0001'),
    ('Int32',-19088743,'fedcba99',4294967297.9,'00000001'),('Uint32',-19088743,'fedcba99',4294967297.9,'00000001'),
    ('Float16',-1.5,'be00',1.5,'3e00'),('Float32',-1.5,'bfc00000',1.5,'3fc00000'),
    ('Float64',-1.5,'bff8000000000000',1.5,'3ff8000000000000')]:
    row(codec+'-literal-negative',codec,f64(number),expected)
    row(codec+'-literal-positive-or-modulo',codec,f64(other),other_expected)

source=HERE/'float16-literal-vectors.json'
assert hashlib.sha256(source.read_bytes()).hexdigest()=='63c1df1a73b3288f4201e456f353c6ce4dc87cee851d05f5765bf79a318ea447'
for name,wide,half in json.loads(source.read_bytes())['vectors']:
    bits=int(wide,16)
    nan=((bits>>52)&2047)==2047 and bits&((1<<52)-1)!=0
    row('Float16-frozen-'+name,'Float16',wide,'NaN' if nan else half)

for name,value,expected in [
    ('positive-zero',0,'00000000'),('negative-zero',-0.0,'80000000'),
    ('positive-infinity',math.inf,'7f800000'),('negative-infinity',-math.inf,'ff800000'),
    ('even-tie',1.000000059604644775390625,'3f800000'),
    ('odd-tie',1.000000178813934326171875,'3f800002'),
    ('minimum-subnormal',2**-149,'00000001'),('zero-tie',2**-150,'00000000'),
    ('negative-zero-tie',-(2**-150),'80000000')]:
    row('Float32-'+name,'Float32',f64(value),expected)

for name,bits in [('positive-zero','0000000000000000'),('negative-zero','8000000000000000'),
                  ('positive-infinity','7ff0000000000000'),('negative-infinity','fff0000000000000'),
                  ('minimum-subnormal','0000000000000001'),('minimum-normal','0010000000000000'),
                  ('maximum-finite','7fefffffffffffff')]:
    row('Float64-'+name,'Float64',bits,bits)

for codec,value,expected in [('Uint32',4294967295,'ffffffff'),('Int32',4294967296,'00000000'),
                            ('Uint32',-4294967297,'ffffffff'),('Int32',9007199254740991,'ffffffff')]:
    row(codec+'-additional-modulo-'+str(value),codec,f64(value),expected)
for codec in ['Int8','Uint8','Int16','Uint16','Int32','Uint32']:
    for name,bits in [('nan','7ff8000000000000'),('infinity','7ff0000000000000'),('negative-infinity','fff0000000000000')]:
        width=int(codec.removeprefix('Uint').removeprefix('Int'))
        row(codec+'-'+name,codec,bits,'00'*(width//8))
row('Float32-nan','Float32','7ff8000000000001','NaN')
row('Float64-nan','Float64','7ff8000000000001','NaN')
# Decode-only rows expose literal memory patterns independently of any writer.
# A '-' input and decode-only name require no encode assertion in private tests.
for codec,raw in [('Int8','80'),('Uint8','ff'),('Int16','8001'),('Uint16','abcd'),
                  ('Int32','80000001'),('Uint32','89abcdef'),
                  ('Float16','03ff'),('Float16','0400'),('Float16','3555'),
                  ('Float16','7c01'),('Float16','fe01'),('Float32','007fffff'),
                  ('Float32','00800000'),('Float32','7f7fffff'),('Float32','7f800001'),
                  ('Float32','ffc00001'),('Float64','000fffffffffffff'),
                  ('Float64','7ff0000000000001'),('Float64','fff8000000000001')]:
    if codec.startswith('Float'):
        exponent,fraction={'Float16':(5,10),'Float32':(8,23),'Float64':(11,52)}[codec]
        decoded=ieee_decoded_bits(raw,exponent,fraction)
    else:
        width=int(codec.removeprefix('Uint').removeprefix('Int'));value=int(raw,16)
        if codec.startswith('Int') and value&(1<<(width-1)):
            value-=1<<width
        decoded=exact_f64_bits(abs(value),0,value<0)
    ROWS.append(['decode-only-'+codec+'-'+raw,codec,'-',raw,decoded])
assert len({r[0] for r in ROWS})==len(ROWS)
assert all(len(r[2])==16 or r[2]=='-' for r in ROWS)
text='# Independent Number DataView codec literals; NaN means any valid stable NaN, not canonical bytes.\n'
text+='# name\tcodec\tinput_f64_bits\texpected_be\tdecoded_f64_bits_or_classification\n'
text+='# decode-only-* rows have input_f64_bits=- and require only decoding the literal expected_be bytes.\n'
text+=''.join('\t'.join(r)+'\n' for r in ROWS)
(HERE/'data-view-codec-vectors.tsv').write_text(text)
receipt=dict(schema=1,rows=len(ROWS),decode_only_rows=sum(r[2]=='-' for r in ROWS),types=sorted({r[1] for r in ROWS}),
             frozen_float16_vectors=42,frozen_input_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
             tsv_sha256=hashlib.sha256(text.encode()).hexdigest(),
             authoring='Literal expected bytes from local oracle plus all 42 frozen Float16 inputs. Integer expected-byte residues independently checked from exact binary64 rational values. Decoded expected binary64 fields constructed with integer IEEE expansion; no runtime codec/raster/engine execution.',
             input_bit_spelling='Python struct.pack is used only to spell the selected host binary64 Number inputs, not to derive expected float narrowing bytes.',
             nan_policy='NaN is a classification marker. Same-input stability remains a separate public property; an implementation-specific canonical-storage test must be labeled separately.')
(HERE/'codec-vector-transcription.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
