#!/usr/bin/env python3
"""Independent DataView oracle authoring: data generation only, never JS execution."""
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
REPO = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
COMPLETE = dict(status='complete', phase='runtime', error_identity='', error_type='')
WRONG = dict(status='exception', phase='runtime', error_identity='', error_type='Test262Error')
RESOURCE = dict(status='resource', phase='runtime')
GUARD = r'''assert.sameValue(typeof ArrayBuffer,'function','ArrayBuffer availability');
assert.sameValue(typeof DataView,'function','DataView availability');
var $AB=ArrayBuffer,$DV=DataView,$dp=$DV.prototype,$buf=new $AB(2),$view=new $DV($buf);
assert.sameValue($view.buffer,$buf);assert.sameValue($view.byteLength,2);assert.sameValue($AB.isView($view),true);
assert.sameValue(typeof $dp.setUint8,'function');assert.sameValue(typeof $dp.getUint8,'function');
assert.sameValue($view.setUint8(0,37),undefined);assert.sameValue($view.getUint8(0),37);assert.sameValue($view.getUint8(1),0);
'''
HELPERS = r'''function own(o,k){return Object.prototype.hasOwnProperty.call(o,k);}
function sameThrow(t,f){var seen=false;try{f();}catch(e){seen=true;assert.sameValue(e,t);}assert.sameValue(seen,true);}
function getter(k){var d=Object.getOwnPropertyDescriptor($dp,k);assert.sameValue(typeof d.get,'function');return d.get;}
function method(k){var f=$dp[k];assert.sameValue(typeof f,'function',k+' availability');return f;}
function seed(v,at,bytes){for(var i=0;i<bytes.length;i++)v.setUint8(at+i,bytes[i]);}
function bytes(v,at,want){for(var i=0;i<want.length;i++)assert.sameValue(v.getUint8(at+i),want[i],'byte '+i);}
function meta(v,b,at,n){assert.sameValue(getter('buffer').call(v),b);assert.sameValue(getter('byteOffset').call(v),at);assert.sameValue(getter('byteLength').call(v),n);}
'''
CASES = []
PAIRS = []

def case(name, body, area='semantics', prerequisites=None, expected=None, note=''):
    assert name not in {c['name'] for c in CASES}
    CASES.append(dict(number=len(CASES)+1, name=name, source=GUARD+HELPERS+body.strip()+'\n',
                      area=area, prerequisites=prerequisites or [], expected=expected or COMPLETE,
                      modes=['sloppy','strict'], note=note))

def pair(name, setup, expression, correct, wrong):
    assert name not in {p['name'] for p in PAIRS}
    PAIRS.append(dict(name=name, setup=GUARD+HELPERS+setup+'\n', expression=expression,
                      correct=correct, wrong=wrong))

case('constructor-prototype-and-tag-metadata', r'''
verifyProperty($DV,'name',{value:'DataView',writable:false,enumerable:false,configurable:true},{restore:true});
verifyProperty($DV,'length',{value:1,writable:false,enumerable:false,configurable:true},{restore:true});
verifyProperty($DV,'prototype',{value:$dp,writable:false,enumerable:false,configurable:false},{restore:true});
verifyProperty($dp,'constructor',{value:$DV,writable:true,enumerable:false,configurable:true},{restore:true});
verifyProperty($dp,Symbol.toStringTag,{value:'DataView',writable:false,enumerable:false,configurable:true},{restore:true});
assert.sameValue(Object.getPrototypeOf($DV),Function.prototype);assert.sameValue(Object.getPrototypeOf($dp),Object.prototype);
assert.sameValue(Object.prototype.toString.call($dp),'[object DataView]');assert.sameValue(Object.prototype.toString.call($view),'[object DataView]');
assert.sameValue(own($DV,Symbol.species),false);
''','metadata')

for prop in ['buffer','byteLength','byteOffset']:
    case('accessor-'+prop+'-metadata', r'''
var k=PROP,f=getter(k);verifyProperty($dp,k,{get:f,set:undefined,enumerable:false,configurable:true},{restore:true});
verifyProperty(f,'name',{value:'get '+k,writable:false,enumerable:false,configurable:true},{restore:true});
verifyProperty(f,'length',{value:0,writable:false,enumerable:false,configurable:true},{restore:true});
assert.sameValue(own(f,'prototype'),false);assert.throws(TypeError,function(){Reflect.construct(f,[]);});
'''.replace('PROP',json.dumps(prop)),'metadata')

TYPES = [('Int8',1),('Uint8',1),('Int16',2),('Uint16',2),('Int32',4),('Uint32',4),('Float16',2),('Float32',4),('Float64',8)]
for typ, width in TYPES:
    case('method-pair-'+typ+'-metadata', r'''
var names=['getTYPE','setTYPE'],lens=[1,2];for(var i=0;i<2;i++){var k=names[i],f=method(k);
verifyProperty($dp,k,{value:f,writable:true,enumerable:false,configurable:true},{restore:true});
verifyProperty(f,'name',{value:k,writable:false,enumerable:false,configurable:true},{restore:true});
verifyProperty(f,'length',{value:lens[i],writable:false,enumerable:false,configurable:true},{restore:true});
assert.sameValue(own(f,'prototype'),false);assert.throws(TypeError,function(){Reflect.construct(f,[]);});}
'''.replace('TYPE',typ),'metadata',note='One getter/setter pair per source keeps descriptor-helper work bounded and does not mask ordinary success with a giant combined metadata loop.')

case('constructor-new-and-buffer-brand-before-index-hooks', r'''
var n=0,arg={valueOf:function(){n++;throw 'conversion';}},fake={};Object.defineProperty(fake,'byteLength',{get:function(){n++;throw 'length';}});
assert.throws(TypeError,function(){$DV($buf,arg,arg);});
var bad=[undefined,null,0,false,'x',{},$view,$AB.prototype,Object.create($buf),fake];
for(var i=0;i<bad.length;i++)assert.throws(TypeError,function(){new $DV(bad[i],arg,arg);});assert.sameValue(n,0);
''','construction')
case('constructor-omitted-undefined-zero-and-end-offset', r'''
var b=new $AB(4),r=new $AB(4,{maxByteLength:8});
meta(new $DV(b),b,0,4);meta(new $DV(b,1),b,1,3);meta(new $DV(b,1,undefined),b,1,3);meta(new $DV(b,4),b,4,0);meta(new $DV(b,4,0),b,4,0);
var a=new $DV(r,1),u=new $DV(r,1,undefined),z=new $DV(r,1,0),f=new $DV(r,1,2);r.resize(7);
meta(a,r,1,6);meta(u,r,1,6);meta(z,r,1,0);meta(f,r,1,2);assert.throws(RangeError,function(){new $DV(b,5);});
''','construction')
case('constructor-toindex-small-and-invalid-ranges', r'''
var b=new $AB(6),inputs=[undefined,null,false,true,NaN,-0,-0.75,2.9,'3'],wanted=[0,0,0,1,0,0,0,2,3];
for(var i=0;i<inputs.length;i++){meta(new $DV(b,inputs[i]),b,wanted[i],6-wanted[i]);meta(new $DV(b,0,inputs[i]),b,0,inputs[i]===undefined?6:wanted[i]);}
var invalid=[-1,-Infinity,Infinity,9007199254740992];for(var j=0;j<invalid.length;j++){assert.throws(RangeError,function(){new $DV(b,invalid[j]);});assert.throws(RangeError,function(){new $DV(b,0,invalid[j]);});}
assert.throws(TypeError,function(){new $DV(b,Symbol('offset'));});assert.throws(TypeError,function(){new $DV(b,0,Symbol('length'));});
''','conversion')
case('constructor-offset-length-prototype-order-and-custom-brand', r'''
var log='',b=new $AB(6),p={marker:9},N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){log+='P';return p;}});
var v=Reflect.construct($DV,[b,{valueOf:function(){log+='O';return 1;}},{valueOf:function(){log+='L';return 3;}}],N);
assert.sameValue(log,'OLP');assert.sameValue(Object.getPrototypeOf(v),p);meta(v,b,1,3);assert.sameValue($AB.isView(v),true);
method('setUint8').call(v,0,61);assert.sameValue(new $DV(b).getUint8(1),61);
''','construction')
case('constructor-detached-offset-conversion-before-refusal', r'''
var b=new $AB(4),log='',N=(function(){}).bind(null);b.transfer();Object.defineProperty(N,'prototype',{get:function(){log+='P';return {};}});
assert.throws(TypeError,function(){Reflect.construct($DV,[b,{valueOf:function(){log+='O';return 0;}},{valueOf:function(){log+='L';return 0;}}],N);});assert.sameValue(log,'O');
assert.throws(RangeError,function(){new $DV(b,-1);});var t={};sameThrow(t,function(){new $DV(b,{valueOf:function(){throw t;}});});
''','construction')
case('constructor-length-detachment-precedes-throwing-prototype', r'''
var b=new $AB(4),log='',t={},N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){log+='P';throw t;}});
sameThrow(t,function(){Reflect.construct($DV,[b,1,{valueOf:function(){log+='L';b.transfer();return 2;}}],N);});
assert.sameValue(log,'LP');assert.sameValue(b.detached,true);
''','construction',note='A detached check inserted immediately after explicit-length conversion would incorrectly replace the later prototype getter exception.')
case('constructor-captured-length-growth-does-not-rescue-overflow', r'''
var b=new $AB(4,{maxByteLength:8}),log='',N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){log+='P';return {};}});
assert.throws(RangeError,function(){Reflect.construct($DV,[b,1,{valueOf:function(){log+='L';b.resize(8);return 4;}}],N);});
assert.sameValue(log,'L');assert.sameValue(b.byteLength,8);
''','construction')
case('constructor-fresh-check-after-prototype-resize-or-detach', r'''
var b=new $AB(6,{maxByteLength:8}),N=(function(){}).bind(null),n=0;Object.defineProperty(N,'prototype',{get:function(){n++;b.resize(2);return {};}});
assert.throws(RangeError,function(){Reflect.construct($DV,[b,1,3],N);});assert.sameValue(n,1);assert.sameValue(b.byteLength,2);
var c=new $AB(4),M=(function(){}).bind(null);Object.defineProperty(M,'prototype',{get:function(){c.transfer();return {};}});
assert.throws(TypeError,function(){Reflect.construct($DV,[c,0,2],M);});assert.sameValue(c.detached,true);
''','construction')
case('constructor-tracking-uses-fresh-length-after-prototype', r'''
var b=new $AB(4,{maxByteLength:8}),N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){b.resize(7);return $dp;}});
var v=Reflect.construct($DV,[b,1],N);meta(v,b,1,6);b.resize(3);meta(v,b,1,2);
''','construction')
case('constructor-poisoned-species-and-global-alias-are-ignored', r'''
var b=new $AB(4),saved=DataView,N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{value:7});
Object.defineProperty(b,'constructor',{get:function(){throw 'buffer constructor';}});Object.defineProperty($DV,Symbol.species,{get:function(){throw 'species';},configurable:true});
try{DataView=function(){throw 'global';};var v=Reflect.construct($DV,[b,1,2],N);assert.sameValue(Object.getPrototypeOf(v),$dp);meta(v,b,1,2);}finally{DataView=saved;delete $DV[Symbol.species];}
''','construction')
case('constructor-callback-view-table-growth-keeps-outer-identity', r'''
var b=new $AB(6,{maxByteLength:8}),N=(function(){}).bind(null),saved=[],p={};Object.defineProperty(N,'prototype',{get:function(){for(var i=0;i<32;i++)saved.push(new $DV(new $AB(1)));b.resize(7);return p;}});
var v=Reflect.construct($DV,[b,{valueOf:function(){for(var i=0;i<16;i++)saved.push(new $DV(b,0,1));return 2;}},3],N);
assert.sameValue(saved.length,48);assert.sameValue(Object.getPrototypeOf(v),p);meta(v,b,2,3);method('setUint8').call(v,0,79);assert.sameValue(new $DV(b).getUint8(2),79);
''','reentrancy',note='Small bounded callback-created populations exercise table relocation without claiming an exact private capacity or budget cut point.')

case('accessor-brands-ignore-prototype-and-own-shadows', r'''
var bad=[undefined,null,0,false,'x',{},$dp,Object.create($view)],names=['buffer','byteLength','byteOffset'];
for(var i=0;i<names.length;i++){var f=getter(names[i]);f.call($view);for(var j=0;j<bad.length;j++)assert.throws(TypeError,function(){f.call(bad[j]);});}
var b=new $AB(5),v=new $DV(b,1,3);Object.defineProperty(v,'buffer',{value:{}});Object.defineProperty(v,'byteOffset',{value:99});Object.defineProperty(v,'byteLength',{value:99});meta(v,b,1,3);
''','brand')
case('method-brands-precede-index-and-value-conversion', r'''
var n=0,arg={valueOf:function(){n++;throw 'conversion';}},g=method('getUint16'),s=method('setUint16');g.call($view,0);s.call($view,0,1);
var bad=[undefined,null,0,false,'x',{},$dp,Object.create($view)];for(var i=0;i<bad.length;i++){assert.throws(TypeError,function(){g.call(bad[i],arg,arg);});assert.throws(TypeError,function(){s.call(bad[i],arg,arg,arg);});}assert.sameValue(n,0);
''','brand')
case('ordinary-properties-and-integrity-do-not-freeze-bytes', r'''
var b=new $AB(4),v=new $DV(b);assert.sameValue(Object.getOwnPropertyNames(v).length,0);v[1]=81;v[0]=17;v.note=9;
assert.sameValue(Object.keys(v).join(','),'0,1,note');assert.sameValue(v.getUint8(0),0);Object.freeze(v);assert.sameValue(Object.isFrozen(v),true);
assert.sameValue(v.setUint16(1,4660),undefined);bytes(v,0,[0,18,52,0]);assert.sameValue(v[0],17);assert.sameValue(v[1],81);assert.throws(TypeError,function(){Object.defineProperty(v,'extra',{value:1});});
assert.sameValue($AB.isView(v),true);assert.sameValue($AB.isView(Object.create(v)),false);
''','ordinary-properties')
case('saved-methods-call-apply-bind-and-prototype-change', r'''
var b=new $AB(6),v=new $DV(b,1,4),s=method('setUint16'),g=method('getUint16');$dp.setUint16=undefined;$dp.getUint16=undefined;Object.setPrototypeOf(v,null);
assert.sameValue(s.apply(v,[1,4660,true]),undefined);assert.sameValue(g.bind(v,1)(true),4660);assert.sameValue(g.call(v,1,false),13330);meta(v,b,1,4);assert.sameValue($AB.isView(v),true);
''','aliasing')

# Literal byte vectors: neither reader nor writer supplies the other's oracle.
CODECS = [
    ('Int8',1,'-2.9',[-2],[254],'257.9',[1]),
    ('Uint8',1,'-2.9',[254],[254],'257.9',[1]),
    ('Int16',2,'-4660',[-4660],[237,204],'65537.9',[0,1]),
    ('Uint16',2,'-4660',[60876],[237,204],'65537.9',[0,1]),
    ('Int32',4,'-19088743',[-19088743],[254,220,186,153],'4294967297.9',[0,0,0,1]),
    ('Uint32',4,'-19088743',[4275878553],[254,220,186,153],'4294967297.9',[0,0,0,1]),
    ('Float16',2,'-1.5',[-1.5],[190,0],'1.5',[62,0]),
    ('Float32',4,'-1.5',[-1.5],[191,192,0,0],'1.5',[63,192,0,0]),
    ('Float64',8,'-1.5',[-1.5],[191,248,0,0,0,0,0,0],'1.5',[63,248,0,0,0,0,0,0]),
]
for typ,width,value,read_values,big,other,other_big in CODECS:
    body = r'''
var b=new $AB(WIDTH+4),all=new $DV(b),v=new $DV(b,1,WIDTH+2),g=method('getTYPE'),s=method('setTYPE');
seed(all,0,FILL);seed(v,1,BIG);assert.sameValue(g.call(v,1),READ);assert.sameValue(g.call(v,1,false),READ);
seed(v,1,LITTLE);assert.sameValue(g.call(v,1,true),READ);
assert.sameValue(s.call(v,1,VALUE),undefined);bytes(v,1,BIG);assert.sameValue(all.getUint8(0),165);assert.sameValue(v.getUint8(0),165);assert.sameValue(v.getUint8(WIDTH+1),165);assert.sameValue(all.getUint8(WIDTH+3),165);
assert.sameValue(s.call(v,1,VALUE,true),undefined);bytes(v,1,LITTLE);s.call(v,1,OTHER);bytes(v,1,OTHER_BIG);
assert.throws(RangeError,function(){g.call(v,3);});assert.throws(RangeError,function(){s.call(v,3,0);});bytes(v,1,OTHER_BIG);
'''
    replacements={'TYPE':typ,'WIDTH':str(width),'FILL':json.dumps([165]*(width+4)),
                  'BIG':json.dumps(big),'LITTLE':json.dumps(big[::-1]),'READ':str(read_values[0]),
                  'VALUE':value,'OTHER_BIG':json.dumps(other_big),'OTHER':other}
    # Long tokens before their contained tokens.
    for key in sorted(replacements,key=len,reverse=True): body=body.replace(key,replacements[key])
    case('literal-'+typ+'-bytes-endians-and-unaligned-boundary',body,'codec')

case('integer-nan-infinity-and-modulo-are-not-saturating', r'''
var v=new $DV(new $AB(8)),names=['Int8','Uint8','Int16','Uint16','Int32','Uint32'],widths=[1,1,2,2,4,4],zero=[0,0,0,0];
for(var i=0;i<names.length;i++){var f=method('set'+names[i]);f.call(v,0,NaN);bytes(v,0,zero.slice(0,widths[i]));f.call(v,0,Infinity);bytes(v,0,zero.slice(0,widths[i]));f.call(v,0,-Infinity);bytes(v,0,zero.slice(0,widths[i]));}
v.setUint32(1,4294967295);bytes(v,1,[255,255,255,255]);assert.sameValue(v.getInt32(1),-1);v.setInt32(1,4294967296);bytes(v,1,[0,0,0,0]);
v.setUint32(1,-4294967297);bytes(v,1,[255,255,255,255]);v.setInt32(1,9007199254740991);bytes(v,1,[255,255,255,255]);
''','codec')
case('float32-literal-rounding-subnormal-zero-and-infinity', r'''
var v=new $DV(new $AB(4));
var inputs=[0,-0,Infinity,-Infinity,1.000000059604644775390625,1.000000178813934326171875,1.401298464324817e-45,7.006492321624085e-46,-7.006492321624085e-46];
var wants=[[0,0,0,0],[128,0,0,0],[127,128,0,0],[255,128,0,0],[63,128,0,0],[63,128,0,2],[0,0,0,1],[0,0,0,0],[128,0,0,0]];
for(var i=0;i<inputs.length;i++){v.setFloat32(0,inputs[i]);bytes(v,0,wants[i]);}
seed(v,0,[0,0,0,1]);assert.sameValue(v.getFloat32(0),1.401298464324817e-45);seed(v,0,[128,0,0,0]);assert.sameValue(v.getFloat32(0),-0);
seed(v,0,[127,127,255,255]);assert.sameValue(v.getFloat32(0),3.4028234663852886e38);
''','codec',note='Exact decimal dyadics for ties near one; decimal spellings of powers 2^-149 and 2^-150 are binary64 exact after Number parsing. Literal bytes define the separate codec oracle.')
case('float64-literal-signed-zero-extremes-and-endians', r'''
var v=new $DV(new $AB(8)),inputs=[0,-0,Infinity,-Infinity,5e-324,2.2250738585072014e-308,1.7976931348623157e308],wants=[[0,0,0,0,0,0,0,0],[128,0,0,0,0,0,0,0],[127,240,0,0,0,0,0,0],[255,240,0,0,0,0,0,0],[0,0,0,0,0,0,0,1],[0,16,0,0,0,0,0,0],[127,239,255,255,255,255,255,255]];
for(var i=0;i<inputs.length;i++){v.setFloat64(0,inputs[i]);bytes(v,0,wants[i]);seed(v,0,wants[i]);assert.sameValue(v.getFloat64(0),inputs[i]);}
seed(v,0,[0,0,0,0,0,0,240,63]);assert.sameValue(v.getFloat64(0,true),1);
''','codec')
case('floating-nan-classification-and-same-input-encoding-stability', r'''
var v=new $DV(new $AB(16)),types=['Float16','Float32','Float64'],widths=[2,4,8],nanBytes=[[126,1],[127,192,0,1],[127,248,0,0,0,0,0,1]];
for(var i=0;i<types.length;i++){var g=method('get'+types[i]),s=method('set'+types[i]);seed(v,0,nanBytes[i]);var n=g.call(v,0);assert.sameValue(n!==n,true);s.call(v,0,n);s.call(v,8,n);for(var j=0;j<widths[i];j++)assert.sameValue(v.getUint8(j),v.getUint8(8+j));assert.sameValue(g.call(v,0)!==g.call(v,0),true);}
''','codec',note='No fixed NaN payload/sign is required. The same Number value is encoded repeatedly; ECMAScript permits implementation-chosen NaN representations with per-distinguishable-NaN stability.')

VECTOR_ORIGIN = HERE.parent/'design-before/float16-literal-vectors.json'
vector_bytes = VECTOR_ORIGIN.read_bytes()
assert hashlib.sha256(vector_bytes).hexdigest() == '63c1df1a73b3288f4201e456f353c6ce4dc87cee851d05f5765bf79a318ea447'
vectors = json.loads(vector_bytes)['vectors']
assert len(vectors)==42
for group in range(6):
    selected=vectors[group*7:(group+1)*7]
    rows=[]
    for name,wide,half in selected:
        raw=list(bytes.fromhex(wide)); target=list(bytes.fromhex(half))
        is_nan=((int(wide,16)>>52)&2047)==2047 and (int(wide,16)&((1<<52)-1))!=0
        rows.append([name,raw,None if is_nan else target])
    case('float16-direct-binary64-literals-'+str(group+1),r'''
var source=new $DV(new $AB(8)),out=new $DV(new $AB(6)),rows=ROWS;
for(var i=0;i<rows.length;i++){var row=rows[i];seed(source,0,row[1]);var number=source.getFloat64(0);out.setFloat16(1,number,false);
if(row[2]===null){assert.sameValue(number!==number,true);var n=out.getFloat16(1);assert.sameValue(n!==n,true);out.setFloat16(3,number,false);bytes(out,3,[out.getUint8(1),out.getUint8(2)]);var high=out.getUint8(1),low=out.getUint8(2);assert.sameValue((high&124)===124&&((high&3)!==0||low!==0),true);}
else{bytes(out,1,row[2]);out.setFloat16(3,number,true);bytes(out,3,[row[2][1],row[2][0]]);}
assert.sameValue(out.getUint8(0),0);assert.sameValue(out.getUint8(5),0);}
'''.replace('ROWS',json.dumps(rows,separators=(',',':'))),'float16-literals',note='Frozen vector rows '+str(group*7+1)+'–'+str((group+1)*7)+'. Binary64 is assembled from literal bytes; no Float32 intermediate. Original NaN canonical-choice outputs are retained only in provenance and deliberately omitted from public expected-byte rows.')

case('float16-read-literal-boundaries-independent-of-writer', r'''
var v=new $DV(new $AB(2)),rows=[[[0,0],0],[[128,0],-0],[[0,1],0.000000059604644775390625],[[3,255],0.000060975551605224609375],[[4,0],0.00006103515625],[[60,0],1],[[60,1],1.0009765625],[[53,85],0.333251953125],[[123,255],65504],[[124,0],Infinity],[[252,0],-Infinity]];
for(var i=0;i<rows.length;i++){seed(v,0,rows[i][0]);assert.sameValue(v.getFloat16(0),rows[i][1]);seed(v,0,[rows[i][0][1],rows[i][0][0]]);assert.sameValue(v.getFloat16(0,true),rows[i][1]);}
''','float16-literals')

case('access-index-toindex-and-endian-toboolean-no-callback', r'''
var v=new $DV(new $AB(4));seed(v,0,[18,52,86,120]);var inputs=[undefined,null,false,NaN,-0,-0.75,0.9],n=0,endian={valueOf:function(){n++;throw 'value';},toString:function(){n++;throw 'string';}};
for(var i=0;i<inputs.length;i++)assert.sameValue(v.getUint16(inputs[i]),4660);assert.sameValue(v.getUint16(true),13398);assert.sameValue(v.getUint16('1.9'),13398);
assert.sameValue(v.getUint16(0,endian),13330);v.setUint16(0,4660,endian);bytes(v,0,[52,18]);assert.sameValue(n,0);
assert.throws(RangeError,function(){v.getUint8(-1);});assert.throws(RangeError,function(){v.setUint8(Infinity,0);});assert.throws(TypeError,function(){v.getUint8(Symbol('index'));});
''','conversion')
case('setter-index-then-value-before-range-and-no-partial-write', r'''
var v=new $DV(new $AB(4)),log='';seed(v,0,[11,22,33,44]);
assert.throws(RangeError,function(){v.setUint32({valueOf:function(){log+='I';v.setUint8(0,77);return 1;}},{valueOf:function(){log+='V';return 4294967295;}});});assert.sameValue(log,'IV');bytes(v,0,[77,22,33,44]);
var n=0;assert.throws(RangeError,function(){v.setUint8(-1,{valueOf:function(){n++;return 1;}});});assert.sameValue(n,0);
assert.throws(TypeError,function(){v.setUint16(99,Symbol('value'));});bytes(v,0,[77,22,33,44]);
''','conversion')
case('setter-value-symboltoprimitive-number-hint-and-abrupt-prefix', r'''
var v=new $DV(new $AB(4)),log='',t={},value={};value[Symbol.toPrimitive]=function(h){assert.sameValue(h,'number');log+='V';v.setUint8(3,99);return '258.9';};
v.setUint16({valueOf:function(){log+='I';return 1;}},value);assert.sameValue(log,'IV');bytes(v,0,[0,1,2,99]);
sameThrow(t,function(){v.setUint16(1,{valueOf:function(){v.setUint8(0,81);throw t;}});});bytes(v,0,[81,1,2,99]);
''','conversion')
case('getter-index-callback-mutates-bytes-before-fresh-read', r'''
var b=new $AB(4),v=new $DV(b),n=0;seed(v,0,[1,2,3,4]);var got=v.getUint16({valueOf:function(){n++;v.setUint8(1,90);v.setUint8(2,91);return 1;}});
assert.sameValue(got,23131);assert.sameValue(n,1);bytes(v,0,[1,90,91,4]);
''','reentrancy')
case('getter-shrink-out-of-bounds-beats-element-range', r'''
var b=new $AB(6,{maxByteLength:8}),v=new $DV(b,2,4),n=0;
assert.throws(TypeError,function(){v.getUint32({valueOf:function(){n++;b.resize(3);return 99;}});});assert.sameValue(n,1);assert.sameValue($AB.isView(v),true);assert.sameValue(getter('buffer').call(v),b);
assert.throws(TypeError,function(){getter('byteOffset').call(v);});assert.throws(TypeError,function(){getter('byteLength').call(v);});
''','resize')
case('setter-value-can-restore-out-of-bounds-fixed-view', r'''
var b=new $AB(6,{maxByteLength:8}),v=new $DV(b,2,4);b.resize(1);var log='';
assert.sameValue(v.setUint16({valueOf:function(){log+='I';return 1;}},{valueOf:function(){log+='V';b.resize(6);return 4660;}}),undefined);
assert.sameValue(log,'IV');meta(v,b,2,4);bytes(new $DV(b),0,[0,0,0,18,52,0]);
''','resize')
case('getter-index-can-restore-out-of-bounds-tracking-view', r'''
var b=new $AB(4,{maxByteLength:8}),v=new $DV(b,3);b.resize(2);
var value=v.getUint16({valueOf:function(){b.resize(6);var all=new $DV(b);all.setUint8(3,18);all.setUint8(4,52);return 0;}});
assert.sameValue(value,4660);meta(v,b,3,3);
''','resize')
case('setter-index-detaches-but-value-still-runs-and-can-throw', r'''
var b=new $AB(4),v=new $DV(b),log='',t={},moved;
sameThrow(t,function(){v.setUint16({valueOf:function(){log+='I';moved=b.transfer();return 0;}},{valueOf:function(){log+='V';throw t;}});});
assert.sameValue(log,'IV');assert.sameValue(moved.byteLength,4);assert.sameValue(getter('buffer').call(v),b);assert.sameValue($AB.isView(v),true);
var n=0;assert.throws(TypeError,function(){v.setUint16(0,{valueOf:function(){n++;return 1;}});});assert.sameValue(n,1);assert.throws(RangeError,function(){v.getUint8(-1);});
''','detachment')
case('setter-value-detachment-keeps-author-prefix-without-write', r'''
var b=new $AB(4),v=new $DV(b),moved;seed(v,0,[11,22,33,44]);
assert.throws(TypeError,function(){v.setUint32(0,{valueOf:function(){v.setUint8(1,77);moved=b.transferToFixedLength();return 4294967295;}});});bytes(new $DV(moved),0,[11,77,33,44]);
assert.sameValue($AB.isView(v),true);assert.sameValue(getter('buffer').call(v),b);assert.throws(TypeError,function(){getter('byteLength').call(v);});
''','detachment')
case('fixed-and-tracking-resize-regrow-and-zeroed-tail', r'''
var b=new $AB(6,{maxByteLength:10}),all=new $DV(b),fixed=new $DV(b,2,4),tracking=new $DV(b,2);seed(all,0,[11,22,33,44,55,66]);b.resize(4);
assert.throws(TypeError,function(){fixed.getUint8(0);});meta(tracking,b,2,2);bytes(tracking,0,[33,44]);assert.throws(RangeError,function(){tracking.getUint32(0);});
b.resize(8);meta(fixed,b,2,4);meta(tracking,b,2,6);bytes(all,0,[11,22,33,44,0,0,0,0]);fixed.setUint8(3,91);assert.sameValue(tracking.getUint8(3),91);
''','resize')
case('zero-length-at-end-revives-after-shrink-regrow', r'''
var b=new $AB(4,{maxByteLength:6}),fixed=new $DV(b,4,0),tracking=new $DV(b,4);meta(fixed,b,4,0);meta(tracking,b,4,0);
assert.throws(RangeError,function(){fixed.getUint8(0);});b.resize(3);assert.throws(TypeError,function(){getter('byteLength').call(fixed);});assert.throws(TypeError,function(){getter('byteOffset').call(tracking);});
b.resize(6);meta(fixed,b,4,0);meta(tracking,b,4,2);tracking.setUint16(0,4660);bytes(new $DV(b),4,[18,52]);assert.throws(RangeError,function(){fixed.setUint8(0,1);});
''','resize')
case('transfer-keeps-old-view-identity-and-copies-current-bytes', r'''
var b=new $AB(4,{maxByteLength:8}),v=new $DV(b,1,2),all=new $DV(b);seed(all,0,[17,29,43,61]);var moved=b.transfer(6),out=new $DV(moved);
bytes(out,0,[17,29,43,61,0,0]);assert.sameValue(moved.resizable,true);assert.sameValue(getter('buffer').call(v),b);assert.sameValue($AB.isView(v),true);assert.throws(TypeError,function(){v.getUint8(0);});
var final=moved.transferToFixedLength(3);bytes(new $DV(final),0,[17,29,43]);assert.sameValue(final.resizable,false);assert.sameValue($AB.isView(out),true);assert.throws(TypeError,function(){out.setUint8(0,1);});
''','transfer')
case('overlapping-views-alias-without-offset-or-endian-confusion', r'''
var b=new $AB(8),a=new $DV(b,1,6),c=new $DV(b,2,4),all=new $DV(b);a.setUint32(1,305419896);bytes(c,0,[18,52,86,120]);
c.setUint16(1,43981,true);bytes(all,0,[0,0,18,205,171,120,0,0]);assert.sameValue(a.getUint32(1),315468664);assert.sameValue(c.getUint16(1),52651);
''','aliasing')
case('callback-growth-of-buffer-and-view-tables-keeps-byte-access', r'''
var b=new $AB(8,{maxByteLength:12}),v=new $DV(b,1,6),saved=[];
v.setUint32({valueOf:function(){for(var i=0;i<24;i++)saved.push(new $DV(new $AB(2)));b.resize(10);return 1;}},{valueOf:function(){for(var j=0;j<24;j++)saved.push(new $DV(b,0,1));return 305419896;}});
assert.sameValue(saved.length,48);bytes(new $DV(b),0,[0,0,18,52,86,120,0,0,0,0]);assert.sameValue(v.getUint32(1),305419896);
''','reentrancy')

case('prerequisite-bigint-codecs-and-number-rejection', r'''
var v=new $DV(new $AB(8));v.setBigInt64(0,-1n);bytes(v,0,[255,255,255,255,255,255,255,255]);assert.sameValue(v.getBigUint64(0),18446744073709551615n);
assert.throws(TypeError,function(){v.setUint8(0,1n);});assert.throws(TypeError,function(){v.setBigInt64(0,1);});
''','prerequisite',['BigInt','DataView BigInt methods'])
case('prerequisite-shared-buffer-view-and-alias', r'''
var b=new SharedArrayBuffer(4),a=new $DV(b),v=new $DV(b,1,2);a.setUint16(1,4660);meta(v,b,1,2);assert.sameValue(v.getUint16(0),4660);assert.sameValue($AB.isView(v),true);
''','prerequisite',['SharedArrayBuffer'])
case('prerequisite-typedarray-byte-alias', r'''
var b=new $AB(4),v=new $DV(b),u=new Uint8Array(b);u[0]=18;u[1]=52;assert.sameValue(v.getUint16(0),4660);v.setUint16(2,43981,true);assert.sameValue(u[2],205);assert.sameValue(u[3],171);assert.sameValue($AB.isView(u),true);
''','prerequisite',['Uint8Array'])
case('prerequisite-proxy-never-forwards-private-view-brand', r'''
var n=0,p=new Proxy($view,{get:function(){n++;throw 'get';},getPrototypeOf:function(){n++;throw 'prototype';}});
assert.sameValue($AB.isView(p),false);assert.throws(TypeError,function(){getter('buffer').call(p);});assert.throws(TypeError,function(){method('getUint8').call(p,0);});assert.throws(TypeError,function(){method('setUint8').call(p,0,1);});assert.sameValue(n,0);
var r=Proxy.revocable($view,{});r.revoke();assert.sameValue($AB.isView(r.proxy),false);assert.throws(TypeError,function(){getter('byteLength').call(r.proxy);});
''','prerequisite',['Proxy'])
case('prerequisite-foreign-realm-view-slots-and-intrinsic-prototype', r'''
var other=$262.createRealm().global,b=new other.ArrayBuffer(4),v=new other.DataView(b,1,2);method('setUint16').call(v,0,4660);assert.sameValue(method('getUint16').call(v,0),4660);meta(v,b,1,2);assert.sameValue($AB.isView(v),true);
var local=new $DV(b,1,2);assert.sameValue(Object.getPrototypeOf(local),$dp);assert.sameValue(Object.getPrototypeOf(v),other.DataView.prototype);assert.sameValue(local.getUint16(0),4660);
''','prerequisite',['cross-realm','$262.createRealm'])
case('recursive-index-conversion-terminal-resource', r'''
var v=new $DV(new $AB(1)),index={valueOf:function(){return v.getUint8(index);}};
try{v.getUint8(index);}catch(e){throw new Test262Error('terminal resource was caught');}finally{throw new Test262Error('terminal resource ran finally');}throw new Test262Error('unbounded recursion completed');
''','engine-policy-resource',expected=RESOURCE,note='Unbounded author conversion must terminate under unchanged shared call/work/storage limits. It is not a catchable ECMAScript error.')
case('repeated-zero-byte-view-metadata-terminal-resource', r'''
var b=new $AB(0);try{while(true){new $DV(b);}}catch(e){throw new Test262Error('terminal resource was caught');}finally{throw new Test262Error('terminal resource ran finally');}throw new Test262Error('unbounded metadata allocation completed');
''','engine-policy-resource',expected=RESOURCE,note='Views allocate metadata even over one unchanged empty buffer. The fixture specifies terminal resource status, not a precise first heap/work boundary.')

# Independently wrong alternatives are gated by their same-mode positive partner.
pair('genuine-byte-view', '', '$AB.isView($view)+":"+$view.byteLength+":"+$view.getUint8(0)', "'true:2:37'", "'false:2:0'")
pair('constructor-metadata', "verifyProperty($DV,'length',{value:1,writable:false,enumerable:false,configurable:true},{restore:true});var d=Object.getOwnPropertyDescriptor($DV,'prototype');", '$DV.length===1&&!d.writable&&!d.configurable&&!d.enumerable', 'true','false')
pair('omitted-tracking-explicit-fixed', 'var b=new $AB(4,{maxByteLength:8}),a=new $DV(b,1),f=new $DV(b,1,2);b.resize(7);', 'a.byteLength+":"+f.byteLength', "'6:2'","'3:6'")
pair('brand-before-conversion', "var n=0,arg={valueOf:function(){n++;return 0;}};assert.throws(TypeError,function(){method('setUint8').call({},arg,arg);});", 'n','0','2')
pair('offset-length-prototype-order', "var b=new $AB(4),log='',N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){log+='P';return $dp;}});Reflect.construct($DV,[b,{valueOf:function(){log+='O';return 0;}},{valueOf:function(){log+='L';return 2;}}],N);", 'log',"'OLP'","'POL'")
pair('detached-length-prototype-abrupt-precedence', "var b=new $AB(2),t={},log='',N=(function(){}).bind(null);Object.defineProperty(N,'prototype',{get:function(){log+='P';throw t;}});sameThrow(t,function(){Reflect.construct($DV,[b,0,{valueOf:function(){log+='L';b.transfer();return 1;}}],N);});", 'log',"'LP'","'L'")
pair('captured-length-before-growth', "var b=new $AB(2,{maxByteLength:6}),hit=false;try{new $DV(b,1,{valueOf:function(){b.resize(6);return 2;}});}catch(e){assert.sameValue(e.constructor,RangeError);hit=true;}", 'hit+":"+b.byteLength',"'true:6'","'false:6'")
pair('uint32-big-endian-literal', 'var v=new $DV(new $AB(4));v.setUint32(0,305419896);', 'v.getUint8(0)+":"+v.getUint8(1)+":"+v.getUint8(2)+":"+v.getUint8(3)',"'18:52:86:120'","'120:86:52:18'")
pair('signed-little-endian-literal', 'var v=new $DV(new $AB(2));seed(v,0,[254,255]);', 'v.getInt16(0,true)','-2','-257')
pair('modulo-not-saturation', 'var v=new $DV(new $AB(4));v.setUint32(0,4294967297);', 'v.getUint32(0)','1','4294967295')
pair('float16-no-float32-double-rounding', 'var source=new $DV(new $AB(8)),v=new $DV(new $AB(2));seed(source,0,[63,240,2,0,0,0,0,1]);v.setFloat16(0,source.getFloat64(0));', 'v.getUint8(0)+":"+v.getUint8(1)',"'60:1'","'60:0'")
pair('float32-even-tie', 'var v=new $DV(new $AB(4));v.setFloat32(0,1.000000059604644775390625);', 'v.getUint8(0)+":"+v.getUint8(1)+":"+v.getUint8(2)+":"+v.getUint8(3)',"'63:128:0:0'","'63:128:0:1'")
pair('float64-negative-zero', 'var v=new $DV(new $AB(8));v.setFloat64(0,-0);', 'v.getFloat64(0)','-0','0')
pair('endian-object-no-user-conversion', "var v=new $DV(new $AB(2)),n=0,p={valueOf:function(){n++;throw 'value';}};seed(v,0,[18,52]);var result=v.getUint16(0,p);", 'result+":"+n',"'13330:0'","'4660:1'")
pair('setter-index-value-order', "var v=new $DV(new $AB(2)),log='';v.setUint16({valueOf:function(){log+='I';return 0;}},{valueOf:function(){log+='V';return 4660;}});", 'log+":"+v.getUint8(0)',"'IV:18'","'VI:18'")
pair('setter-restores-out-of-bounds', 'var b=new $AB(4,{maxByteLength:6}),v=new $DV(b,2,2);b.resize(1);v.setUint16(0,{valueOf:function(){b.resize(4);return 4660;}});', 'v.byteLength+":"+v.getUint16(0)',"'2:4660'","'0:0'")
pair('detached-view-still-isview', 'var b=new $AB(1),v=new $DV(b);b.transfer();assert.throws(TypeError,function(){v.getUint8(0);});', '$AB.isView(v)&&getter("buffer").call(v)===b','true','false')
pair('shrink-regrow-zeroes-discarded-tail', 'var b=new $AB(4,{maxByteLength:6}),v=new $DV(b);seed(v,0,[11,22,33,44]);b.resize(2);b.resize(4);', 'v.getUint8(0)+":"+v.getUint8(1)+":"+v.getUint8(2)+":"+v.getUint8(3)',"'11:22:0:0'","'11:22:33:44'")
pair('whole-view-oob-precedes-element-range', "var b=new $AB(4,{maxByteLength:6}),v=new $DV(b,2,2),seen='';assert.sameValue(method('getUint32').call(new $DV(b),0),0);b.resize(2);try{v.getUint32(999);}catch(e){seen=e.name;}", 'seen',"'TypeError'","'RangeError'")
pair('freeze-does-not-freeze-bytes', 'var v=new $DV(new $AB(2));Object.freeze(v);v.setUint16(0,4660);', 'Object.isFrozen(v)+":"+v.getUint16(0)',"'true:4660'","'true:0'")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def canonical(data):
    return json.dumps(data,sort_keys=True,separators=(',',':')).encode()

def write_json(name,data):
    (HERE/name).write_text(json.dumps(data,indent=2)+'\n')

assert len(PAIRS)==20
(HERE/'harness').mkdir(exist_ok=True)
harness=[]
origin=Path('/tmp/eris-array-from-local')
for name in ['assert.js','sta.js','propertyHelper.js']:
    path=origin/'harness'/name; data=path.read_bytes();(HERE/'harness'/name).write_bytes(data)
    harness.append(dict(name=name,path=str(HERE/'harness'/name),origin=str(path),bytes=len(data),sha256=digest(data)))
license_data=(origin/'TEST262-LICENSE').read_bytes();(HERE/'TEST262-LICENSE').write_bytes(license_data)
(HERE/'float16-literal-vectors.json').write_bytes(vector_bytes)
fixture='// Independent DataView draft; no engine execution.\n\n'+''.join('// CASE: '+c['name']+'\n'+c['source'] for c in CASES)
(HERE/'data-view.js').write_text(fixture)
write_json('preflights.json',PAIRS)
rows=[]
metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None)
def add_row(name,source,mode,expected,filename,extra):
    payload=dict(mode=mode,source_sha256=digest(source.encode()),metadata=metadata,harness=[dict(name=h['name'],sha256=h['sha256']) for h in harness])
    rows.append(dict(id=name+'#'+mode,file=filename,mode=mode,source=source,source_sha256=payload['source_sha256'],case_sha256=digest(json.dumps(payload,sort_keys=True,ensure_ascii=True).encode()),expected=expected,expectation_sha256=digest(canonical(expected)),fingerprint_payload=payload,**extra))
for c in CASES:
    for mode in c['modes']:
        add_row(c['name'],c['source'],mode,c['expected'],'data-view.js',dict(category='fixture',number=c['number'],area=c['area'],prerequisites=c['prerequisites'],note=c['note']))
for p in PAIRS:
    for mode in ['sloppy','strict']:
        for positive in [True,False]:
            name='preflight-'+p['name']+('-positive' if positive else '-wrong')
            source=p['setup']+'\nassert.sameValue('+p['expression']+','+p['correct' if positive else 'wrong']+');\n'
            add_row(name,source,mode,COMPLETE if positive else WRONG,'preflight-controls',dict(category='preflight-control',positive=positive,partner='preflight-'+p['name']+'-positive#'+mode))
common_origin=origin/'matrix.json'
common=[r for r in json.loads(common_origin.read_bytes())['cases'] if r.get('category')=='harness-control']
assert len(common)==12
rows.extend(common)
assert len({r['id'] for r in rows})==len(rows)
semantic=sum(c['area'] not in ['prerequisite','engine-policy-resource'] for c in CASES)
record=dict(format='eris-data-view-local-oracle-draft-v1',status='Held for independent preimplementation review; no engine or runner execution.',
    source_cases=len(CASES),fixture_modes=len(CASES)*2,feature_controls=len(PAIRS)*4,common_harness_controls=12,total_rows=len(rows),
    supported_semantic_completion_modes=semantic*2,prerequisite_completion_modes=sum(c['area']=='prerequisite' for c in CASES)*2,engine_policy_resource_modes=sum(c['area']=='engine-policy-resource' for c in CASES)*2,
    case_sources=CASES,feature_pairs=PAIRS,rows=rows,harness=harness,
    license=dict(path=str(HERE/'TEST262-LICENSE'),sha256=digest(license_data)),
    common_control_origin=dict(path=str(common_origin),sha256=digest(common_origin.read_bytes()),rows_copied_exactly=True),
    files=dict(generator=dict(path=str(Path(__file__)),sha256=digest(Path(__file__).read_bytes())),fixture=dict(path=str(HERE/'data-view.js'),sha256=digest(fixture.encode())),preflights=dict(path=str(HERE/'preflights.json'),sha256=digest((HERE/'preflights.json').read_bytes()))),
    frozen_float16_input=dict(origin=str(VECTOR_ORIGIN),copy='float16-literal-vectors.json',sha256=digest(vector_bytes),vectors=42,public_canonical_nan_bits_required=False),
    policy=dict(metadata_exclusions=False,guards='Every semantic and feature source constructs a genuine ArrayBuffer/DataView and succeeds at a Uint8 byte write/read before its assertion. Each wrong control requires its same-mode positive partner.',
        resource_expectations='Only unbounded recursive index conversion and repeated empty-view metadata creation expect terminal resource status under unchanged shared limits. No specific first resource message or cut point is guessed.',
        prerequisites='BigInt, SharedArrayBuffer, Uint8Array, Proxy and foreign realm cases retain ordinary complete expectations; parser/host-hook unsupported observations remain visible.',
        nan='Public checks permit any valid stable IEEE NaN encoding for the same Number input; copied frozen canonical half-NaN output is a private proposed choice, not a public requirement.'),
    primary_sources=['https://tc39.es/ecma262/multipage/structured-data.html#sec-dataview-objects','https://tc39.es/ecma262/multipage/structured-data.html#sec-dataview','https://tc39.es/ecma262/multipage/structured-data.html#sec-getviewvalue','https://tc39.es/ecma262/multipage/structured-data.html#sec-setviewvalue','https://tc39.es/ecma262/multipage/structured-data.html#sec-numerictorawbytes','https://tc39.es/ecma262/multipage/structured-data.html#sec-rawbytestonumeric','https://tc39.es/ecma262/multipage/structured-data.html#sec-arraybuffer.isview','https://tc39.es/ecma262/multipage/abstract-operations.html#sec-toindex'],
    primary_verification='Current official TC39 multipage algorithms read through the web tool before authoring; ECMAScript 2027 draft, observed 2026-10-02.',
    quota_source=dict(path='src/script.rs',sha256=digest((REPO/'src/script.rs').read_bytes()),MAX_STEPS=100000,MAX_CALLS=32,MAX_STACK_UNITS=96,MAX_HEAP=8388608),
    fingerprint_algorithm_source=dict(path='tools/test262_conformance.py',sha256=digest((REPO/'tools/test262_conformance.py').read_bytes()),algorithm='SHA256(json.dumps({source_sha256,mode,metadata,harness},sort_keys=True,ensure_ascii=True).encode()); expected observation has a separate canonical JSON hash.'),
    private_requirements=['Exact/one-short metadata search/growth and byte-operation work/heap cut points without partial writes.','Copied IDs only across author callbacks; no backing/table borrow survives conversion or prototype lookup.','No full backing scan/clone for a one-byte access; view metadata creation does not debit backing length.','Exhaustive finite binary16 decode/encode and threshold checks independently of binary32; fixed eight-byte scratch access.'],
    runner='No runner authored or executed. matrix.json is a data-only expectation matrix; parent review/freeze precedes runner preparation and BEFORE.')
write_json('draft.json',record)
write_json('matrix.json',dict(format='eris-data-view-local-expectation-matrix-v1',cases=rows,harness=harness,runner=None))
print(json.dumps({k:record[k] for k in ['source_cases','fixture_modes','feature_controls','common_harness_controls','total_rows','supported_semantic_completion_modes','prerequisite_completion_modes','engine_policy_resource_modes']},indent=2))
