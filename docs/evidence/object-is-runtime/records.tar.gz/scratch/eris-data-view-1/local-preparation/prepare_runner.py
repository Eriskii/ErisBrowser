#!/usr/bin/env python3
"""Prepare the inherited runner as text; never invoke a JS engine."""
import hashlib
import json
from pathlib import Path

HERE=Path(__file__).resolve().parent
OLD=Path('/tmp/eris-array-buffer-local')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
draft=json.loads((HERE/'draft.json').read_bytes())
old=(OLD/'run.py').read_text()
source=old.replace('array-buffer','data-view').replace('genuine-fixed-and-resizable','genuine-byte-view').replace("HERE/'matrix.json'","HERE/'runner-matrix.json'")
assert source.replace('data-view','array-buffer').replace('genuine-byte-view','genuine-fixed-and-resizable').replace("HERE/'runner-matrix.json'","HERE/'matrix.json'")==old
(HERE/'run.py').write_text(source)
(HERE/'tools').mkdir(exist_ok=True)
copies=[]
for name in ['test262_conformance.py','import_test262.py','html_conformance.py']:
    p=OLD/'tools'/name;q=HERE/'tools'/name;q.write_bytes(p.read_bytes())
    copies.append(dict(origin=str(p),path=str(q),bytes=q.stat().st_size,sha256=sha(q)))
freeze=dict(phase='Independent DataView local oracle, no engine execution; review before BEFORE',
            fixture_sha256=sha(HERE/'data-view.js'),generator_sha256=sha(HERE/'prepare.py'),
            preflights_sha256=sha(HERE/'preflights.json'),source_cases=draft['source_cases'],
            mode_cases=draft['fixture_modes'],cases=draft['case_sources'])
(HERE/'freeze.json').write_text(json.dumps(freeze,indent=2)+'\n')
receipt=dict(original_runner=dict(path=str(OLD/'run.py'),sha256=sha(OLD/'run.py')),
             adapted_runner=dict(path=str(HERE/'run.py'),sha256=sha(HERE/'run.py')),
             exact_text_deltas=['array-buffer -> data-view','genuine-fixed-and-resizable -> genuine-byte-view',
                                "HERE/'matrix.json' -> HERE/'runner-matrix.json' (authoring matrix remains intact)"],
             exact_tool_copies=copies,execution='None; parent may run --prepare to construct source identities only.')
(HERE/'runner-adaptation.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
