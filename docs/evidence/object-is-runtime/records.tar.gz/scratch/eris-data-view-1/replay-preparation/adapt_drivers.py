#!/usr/bin/env python3
"""Text-only adaptation of retained drivers; never executes their main functions."""
from pathlib import Path
import difflib
import hashlib
import json

HERE=Path(__file__).resolve().parent
OLD=Path('/tmp/eris-for-in-length-buckets-1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def replace_once(text,old,new):
    assert text.count(old)==1,(old,text.count(old));return text.replace(old,new)

local_origin=OLD/'replay-preparation/replay.py'
local=local_origin.read_text()
local=local.replace('eight unchanged local populations','nine unchanged local populations')
local=local.replace("'own-keys', 'array-splice', 'array-concat', 'array-buffer')", "'own-keys', 'array-splice', 'array-concat', 'array-buffer', 'data-view')")
local=local.replace('dict(suites=8, fixture_modes=1482, controls=392)','dict(suites=9, fixture_modes=1620, controls=484)')
local=local.replace("HERE / 'inputs.json'","HERE / 'local-inputs.json'")
local=local.replace('8 unchanged populations, 1482 cases + 392 controls','9 unchanged populations, 1620 cases + 484 controls')
local=local.replace("== 1482, 'complete mode count'","== 1620, 'complete mode count'")
local=local.replace("== 392, 'complete control count'","== 484, 'complete control count'")
local=replace_once(local,"""        public = old.read(suite['published_report']['path'])
        for key in suite['published_report']['pointer']:
            public = public[key]
        require(before['cases'] == public['cases'] and old.controls(before) == old.controls(public),
                'latest/public observation mismatch: ' + suite['name'])
""", """        # The latest retained report is authoritative. Earlier publications keep
        # their historical observations (notably the two later ArrayBuffer gains).
        require(sha(suite['report']) == suite['before_report_sha256'],
                'latest retained report changed: ' + suite['name'])
""")
(HERE/'local-replay.py').write_text(local)

formal_origin=OLD/'formal-preparation/replay.py'
formal=formal_origin.read_text().replace('authorized42-profile','authorized43-profile')
for arg in ['candidate-directory','output-directory']:
    formal=formal.replace("parser.add_argument('--"+arg+"', type=Path, required=True)","parser.add_argument('--"+arg+"', type=Path)")
for arg in ['production-input-sha256','binary-sha256','archive-inputs-sha256']:
    formal=formal.replace("parser.add_argument('--"+arg+"', required=True)","parser.add_argument('--"+arg+"')")
start="""    require(args.candidate_directory.is_absolute() and not args.candidate_directory.is_symlink(), 'explicit non-aliased candidate required')
    require(str(args.candidate_directory) == manifest['candidate_directory'], 'candidate directory differs')
    require(args.production_input_sha256 == manifest['candidate_input_sha256'], 'candidate input differs')
    require(args.binary_sha256 == manifest['candidate_binary_sha256'], 'candidate binary differs')
    verify(manifest['candidate_binary_manifest'])
    require(args.archive_inputs_sha256 == manifest['candidate_archive_inventory']['sha256'], 'archive inventory differs')
    require(args.output_directory.is_absolute() and not args.output_directory.exists() and not args.output_directory.is_symlink(), 'output must be fresh')
    out = args.output_directory.resolve()
    require(Path('/tmp') in out.parents and root not in out.parents and out != args.candidate_directory
            and args.candidate_directory not in out.parents and out not in args.candidate_directory.parents,
            'output must be separate scratch directory')
"""
new="""    require(__debug__, 'run with Python assertions enabled')
    supplied = [args.candidate_directory, args.production_input_sha256, args.binary_sha256,
                args.archive_inputs_sha256, args.output_directory]
    require(not any(supplied) or all(supplied), 'supply every candidate argument together')
    require(not args.execute_authorized or all(supplied), 'execution requires explicit candidate bindings')
    out = None
    if any(supplied):
        require(args.candidate_directory.is_absolute() and not args.candidate_directory.is_symlink(), 'explicit non-aliased candidate required')
        require(Path('/tmp') in args.candidate_directory.resolve().parents, 'candidate must be scratch directory')
        require(args.output_directory.is_absolute() and not args.output_directory.exists() and not args.output_directory.is_symlink(), 'output must be fresh')
        out = args.output_directory.resolve()
        protected = [root, args.candidate_directory.resolve(), Path(__file__).resolve().parent]
        require(Path('/tmp') in out.parents and all(out != p and p not in out.parents and out not in p.parents for p in protected),
                'output must be separate scratch directory')
"""
formal=replace_once(formal,start,new)
formal=formal.replace("== 42, 'profile count differs'","== 43, 'profile count differs'")
formal=formal.replace("len(results)==42","len(results)==43")
formal=formal.replace("    binary_manifest_binding = binding(args.candidate_directory/'default-binaries.json')", "    binary_manifest_binding = binding(args.candidate_directory/'default-binaries.json') if any(supplied) else None")
formal=replace_once(formal,"""        verify(manifest['candidate_inputs'])
        verify(manifest['candidate_supplemental'])
        verify(manifest['candidate_archive_inventory'])
        verify(binary_manifest_binding)
""", """        require(all(supplied), 'candidate bindings missing')
        verify(binary_manifest_binding)
""")
formal=formal.replace('    checked_candidate = candidate_check()','    checked_candidate = candidate_check() if any(supplied) else None')
(HERE/'formal-replay.py').write_text(formal)

rows=[]
for source,target in [(local_origin,HERE/'local-replay.py'),(formal_origin,HERE/'formal-replay.py')]:
    delta=''.join(difflib.unified_diff(source.read_text().splitlines(keepends=True),target.read_text().splitlines(keepends=True),fromfile=str(source),tofile=str(target)))
    patch=HERE/(target.stem+'.diff');patch.write_text(delta)
    rows.append(dict(origin=str(source),origin_sha256=sha(source),adapted=str(target),adapted_sha256=sha(target),diff=str(patch),diff_sha256=sha(patch)))
(HERE/'driver-adaptations.json').write_text(json.dumps(dict(schema=1,drivers=rows,
    preserved='Archive, source identity, full-observation comparisons, per-case/profile/total limits, error identities, same-mode guard health, signal-before-reap and baseline checking remain inherited.',
    changes=['Extend only the immutable selected populations to43 formal and9 local.',
             'Formal candidate arguments become an all-or-none group, so no-candidate preparation is inert; explicit candidate metadata is independently pinned at invocation and rechecked throughout.',
             'Local latest raw reports supersede older published checkpoint observations; sources/controls/expectations remain checked against those latest reports.',
             'Formal scratch output additionally cannot overlap its own new driver directory.'],
    future_exit_status='Inherited formal exit1 can reflect new DataView control changes as well as old regressions/gate failures; complete raw comparisons distinguish these, with no positive-control-gain suppression.'),indent=2)+'\n')
print(json.dumps(rows,indent=2))
