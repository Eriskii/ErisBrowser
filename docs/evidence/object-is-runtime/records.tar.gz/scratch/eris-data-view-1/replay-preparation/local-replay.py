#!/usr/bin/env python3
"""Inert by default: nine unchanged local populations against one frozen candidate."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import sys
import tarfile
import time

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
LEGACY = Path('/tmp/eris-array-buffer-historical-local-replay.py')
LEGACY_SHA = '31aab29fd7a8075210b9087906c2066fe0aaeb9947ae63aa0564871108706913'
NAMES = ('array-from', 'array-descriptors', 'object-integrity', 'for-of',
         'own-keys', 'array-splice', 'array-concat', 'array-buffer', 'data-view')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(path):
    with Path(path).open('rb') as handle:
        return hashlib.file_digest(handle, 'sha256').hexdigest()


def load_legacy():
    require(sha(LEGACY) == LEGACY_SHA, 'legacy helper hash changed')
    spec = importlib.util.spec_from_file_location('local_replay_legacy', LEGACY)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


old = load_legacy()


def verify_archive_inventory(directory, expected_sha):
    """Add complete archive binding without weakening the old production verifier."""
    path = directory / 'archive-inputs.json'
    require(old.valid_hash(expected_sha), 'invalid archive inventory SHA')
    require(path.is_file() and not path.is_symlink() and sha(path) == expected_sha,
            'archive inventory hash changed')
    records = old.read(path)['files']
    require(0 < len(records) <= 2048, 'archive inventory count limit')
    mapping = {}
    for row in records:
        name = row['path']
        p = Path(name)
        require(not p.is_absolute() and p.parts and str(p) == name
                and all(x not in ('.', '..') for x in p.parts)
                and name not in mapping and old.valid_hash(row['sha256']),
                'invalid archive inventory path or hash')
        mapping[name] = row['sha256']
    archive_path = directory / 'source.tar'
    require(archive_path.is_file() and not archive_path.is_symlink()
            and archive_path.stat().st_size <= 64 * 1024**2, 'archive file limit')
    with tarfile.open(archive_path, 'r:') as archive:
        members = archive.getmembers()
        require(len(members) <= 2048, 'archive member count limit')
        seen, regular, total = set(), {}, 0
        for member in members:
            p = Path(member.name)
            require(not p.is_absolute() and p.parts and '..' not in p.parts
                    and member.name not in seen and (member.isfile() or member.isdir()),
                    'invalid archive member')
            seen.add(member.name)
            require(0 <= member.size <= 16 * 1024**2, 'archive member byte limit')
            total += member.size
            require(total <= 64 * 1024**2, 'archive total byte limit')
            if member.isfile():
                regular[member.name] = member
        require(set(regular) == set(mapping), 'complete archive inventory differs')
        for name, member in regular.items():
            with archive.extractfile(member) as handle:
                data = handle.read(16 * 1024**2 + 1)
            require(hashlib.sha256(data).hexdigest() == mapping[name], 'archive differs: ' + name)
    return old.file_record(path)


def verify_candidate(directory, input_sha, binary_sha, archive_sha):
    records = old.verify_binary(directory, input_sha, binary_sha)
    records['archive-inputs.json'] = verify_archive_inventory(directory, archive_sha)
    for name in ('provenance.json', 'verification-inputs.json', 'pixel-inputs.json'):
        path = directory / name
        if path.exists():
            require(path.is_file() and not path.is_symlink(), 'nonregular supplemental receipt')
            records[name] = old.file_record(path)
    return records


def verify_health(report):
    cases, controls = report['cases'], old.controls(report)
    rows = cases + controls
    by_id = {r['id']: r for r in rows}
    require(len(by_id) == len(rows), 'duplicate case/control identity')
    for row in rows:
        expected = row.get('expected_observation', row.get('expected'))
        require(isinstance(expected, dict), 'missing frozen expected observation')
        matched = all(row.get('observation', {}).get(k) == v for k, v in expected.items())
        require(row['matches_expectation'] == matched, 'incorrect expectation match: ' + row['id'])
    for row in controls:
        if 'verified' in row:
            require(row['partner'] in by_id, 'missing positive partner')
            require(row['verified'] == (row['matches_expectation']
                    and by_id[row['partner']]['matches_expectation']), 'incorrect partner guard')
    if 'controls_verified' in report:
        require(report['controls_verified'] == sum(r['verified'] for r in controls), 'control total')
    if 'harness_controls_verified' in report:
        require(report['harness_controls_verified'] == sum(r['matches_expectation'] for r in controls),
                'common control total')
    if 'protocol_prerequisites' in report:
        for mode, entry in report['protocol_prerequisites'].items():
            guard = by_id[entry['id']]
            require(guard['mode'] == mode and entry['matches_expectation'] == guard['matches_expectation']
                    and entry['observation'] == guard.get('observation', {}), 'protocol prerequisite drift')
        require(report['protocol_prerequisite_verified'] == all(
            x['matches_expectation'] for x in report['protocol_prerequisites'].values()), 'protocol total')
    elif 'protocol_prerequisite_verified' in report:
        require(report['protocol_prerequisite_verified'] == all(
            by_id['preflight-protocol-values-positive#' + mode]['matches_expectation']
            for mode in ('sloppy', 'strict')), 'for-of prerequisite total')
    for row in cases:
        if 'prerequisite' in row:
            require(row['prerequisite'] == report['protocol_prerequisites'][row['mode']], 'case prerequisite')
        if 'verified_with_protocol_prerequisite' in row:
            guard = (row['prerequisite']['matches_expectation'] if 'prerequisite' in row
                     else report['protocol_prerequisite_verified'])
            require(row['verified_with_protocol_prerequisite'] == (row['matches_expectation'] and guard),
                    'fixture protocol guard')
        if 'guarded_verified' in row:
            require(row['guarded_verified'] == (row['matches_expectation'] and
                by_id['preflight-smoke-positive#' + row['mode']]['matches_expectation']), 'own-keys guard')
    if 'fixture_expectations_matched' in report:
        require(report['fixture_expectations_matched'] == sum(r['matches_expectation'] for r in cases),
                'fixture matched total')
    if 'fixture_expectations_verified' in report:
        require(report['fixture_expectations_verified'] == sum(
            r.get('verified_with_protocol_prerequisite', r.get('guarded_verified', False)) for r in cases),
            'fixture verified total')


def verify_inputs(manifest_path, manifest_sha):
    require(old.valid_hash(manifest_sha) and sha(manifest_path) == manifest_sha, 'manifest changed')
    manifest = old.read(manifest_path)
    require(tuple(s['name'] for s in manifest['suites']) == NAMES, 'suite inventory/order')
    require(manifest['counts'] == dict(suites=9, fixture_modes=1620, controls=484), 'suite totals')
    for path, record in manifest['files'].items():
        require(Path(path).is_file() and Path(path).stat().st_size == record['bytes']
                and sha(path) == record['sha256'], 'bound input changed: ' + path)
    require(manifest['files'][str(Path(__file__).resolve())]['sha256'] == sha(__file__), 'wrapper not bound')
    for suite in manifest['suites']:
        before = old.original(suite)
        old.verify_report(suite, before, manifest['before']['binary_sha256'])
        verify_health(before)
        # The latest retained report is authoritative. Earlier publications keep
        # their historical observations (notably the two later ArrayBuffer gains).
        require(sha(suite['report']) == suite['before_report_sha256'],
                'latest retained report changed: ' + suite['name'])
    return manifest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--manifest', type=Path, default=HERE / 'local-inputs.json')
    p.add_argument('--manifest-sha256', required=True)
    p.add_argument('--candidate-directory', type=Path)
    p.add_argument('--production-input-sha256')
    p.add_argument('--binary-sha256')
    p.add_argument('--archive-inputs-sha256')
    p.add_argument('--output-directory', type=Path)
    p.add_argument('--execute', action='store_true')
    a = p.parse_args()
    require(__debug__, 'run with Python assertions enabled for unchanged local runners')
    manifest = verify_inputs(a.manifest, a.manifest_sha256)
    supplied = [a.candidate_directory, a.production_input_sha256, a.binary_sha256,
                a.archive_inputs_sha256, a.output_directory]
    require(not any(supplied) or all(supplied), 'supply every candidate argument together')
    require(not a.execute or all(supplied), 'execution requires all candidate arguments')
    if not any(supplied):
        print('INERT VERIFIED: 9 unchanged populations, 1620 cases + 484 controls; no engine execution.')
        return
    require(a.candidate_directory.is_absolute() and not a.candidate_directory.is_symlink(), 'candidate path')
    candidate = a.candidate_directory.resolve()
    require(Path('/tmp') in candidate.parents, 'candidate must be scratch directory')
    require(not a.output_directory.is_symlink(), 'output symlink')
    out = a.output_directory.resolve()
    protected = [ROOT, candidate, HERE, Path(manifest['before']['directory'])]
    protected.extend(Path(s['runner']).parent for s in manifest['suites'] if s['name'] != 'array-descriptors')
    require(Path('/tmp') in out.parents and not out.exists() and all(
        out != q and q not in out.parents and out not in q.parents for q in protected), 'fresh disjoint output required')
    release = verify_candidate(candidate, a.production_input_sha256, a.binary_sha256, a.archive_inputs_sha256)
    def locks():
        verify_inputs(a.manifest, a.manifest_sha256)
        require(verify_candidate(candidate, a.production_input_sha256, a.binary_sha256,
                                 a.archive_inputs_sha256) == release, 'candidate changed')
    if not a.execute:
        print('INERT candidate/archive verified; no child or output directory created.')
        return
    out.mkdir()
    sys.path.insert(0, str(ROOT / 'tools'))
    from run import launch_environment
    env = launch_environment()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    for name in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME'):
        env.pop(name, None)
    record = dict(format=1, started_utc=old.utc(), driver_sha256=sha(__file__),
        manifest_sha256=a.manifest_sha256, production_input_sha256=a.production_input_sha256,
        binary_sha256=a.binary_sha256, release_files=release, completed=False,
        counts=manifest['counts'], retries=False, baseline_written=False,
        observation_comparison='latest completed ArrayBuffer-era reports, exact complete rows',
        bounds=dict(total_wall_seconds=1200, address_space_bytes=512*1024**2,
                    per_runner_output_file_bytes=32*1024**2, per_case_wall_seconds=3))
    old.write_new(out / 'start.json', record)
    previous = {sig: signal.getsignal(sig) for sig in (signal.SIGINT, signal.SIGTERM)}
    comparisons, summaries = {}, {}
    try:
        for sig in previous:
            signal.signal(sig, old.interrupt)
        deadline = time.monotonic() + 1200
        for suite in manifest['suites']:
            locks()
            require(time.monotonic() < deadline, 'total replay deadline')
            name = suite['name']
            target = out / (name + '.json')
            if suite['runner_kind'] == 'own-keys-worker':
                directory = out / name
                directory.mkdir()
                target = directory / 'report.json'
                command = [sys.executable, '-B', suite['runner'], '--execute-authorized', '--worker',
                    '--binary', str(candidate / 'eris-js'), '--sha256', a.binary_sha256,
                    '--output-directory', str(directory)]
            else:
                command = [sys.executable, '-B', suite['runner'], '--binary', str(candidate / 'eris-js'),
                           '--sha256', a.binary_sha256, '--output', str(target)]
            old.run_suite(command, out, name, env, deadline, suite)
            report = old.read(target)
            summaries[name] = old.verify_report(suite, report, a.binary_sha256)
            verify_health(report)
            comparison = old.compare(old.original(suite), report)
            comparisons[name] = comparison
            old.write_new(out / (name + '.comparison.json'), comparison)
            locks()
            print(name, summaries[name], comparison['changed_complete_records'], flush=True)
        require(sum(s['modes'] for s in summaries.values()) == 1620, 'complete mode count')
        require(sum(s['controls'] for s in summaries.values()) == 484, 'complete control count')
        old.write_new(out / 'comparison.json', dict(suites=comparisons, no_filters=True, no_normalization=True))
        record.update(completed=True, all_inputs_unchanged=True, summaries=summaries)
    except BaseException as error:
        record['failure'] = dict(type=type(error).__name__, message=str(error))
        raise
    finally:
        try:
            locks()
            record['post_input_checks_passed'] = True
        except BaseException as error:
            record['post_input_failure'] = dict(type=type(error).__name__, message=str(error))
        for sig, handler in previous.items():
            signal.signal(sig, handler)
        record['ended_utc'] = old.utc()
        record['captured_files'] = {str(x.relative_to(out)): old.file_record(x)
            for x in sorted(out.rglob('*')) if x.is_file()}
        old.write_new(out / 'execution.json', record)
    require(record['completed'] and record.get('post_input_checks_passed'), 'incomplete or mutated replay')
    print('Complete', manifest['counts'], sha(out / 'execution.json'))


if __name__ == '__main__':
    main()
