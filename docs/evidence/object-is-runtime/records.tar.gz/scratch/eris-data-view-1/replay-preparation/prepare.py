#!/usr/bin/env python3
"""Bind immutable replay populations; no engine, compiler or subprocess calls."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD=Path('/tmp/eris-for-in-length-buckets-1')
DATA=HERE.parent
BEFORE_BINARY='650c0860141ec576ddbad348af53fc125b6399d9087f8ae9c9b20992aa5975e7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_bytes())
def bind(p):
    p=Path(p);assert p.is_file() and not p.is_symlink()
    return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def compact(p):return {k:v for k,v in bind(p).items() if k!='path'}
def save(name,data):
    with (HERE/name).open('x') as handle:json.dump(data,handle,indent=2);handle.write('\n')
def load(p,name):
    spec=importlib.util.spec_from_file_location(name,p);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module);return module

old_formal=read(OLD/'formal-preparation/inputs.json')
history=read(OLD/'formal-replay-1/profiles-comparison.json')
assert history['complete'] and history['all_inputs_unchanged'] and history['binary_sha256']==BEFORE_BINARY
assert history['counts']['profiles']==42 and history['counts']['baseline_gates_passed']==34
latest={row['profile']:row for row in history['profiles']}
contracts=read(OLD/'formal-preparation/contracts.json')['profiles']|read(DATA/'formal-preparation/contracts.json')['profiles']
assert len(contracts)==43
save('formal-contracts.json',dict(schema=1,profiles=contracts,origins=[bind(OLD/'formal-preparation/contracts.json'),bind(DATA/'formal-preparation/contracts.json')]))
helpers={}
for key,name in [('historical','historical-helper.py'),('supervision','supervision-helper.py')]:
    old=OLD/'formal-preparation'/name
    (HERE/name).write_bytes(old.read_bytes());helpers[key]=bind(HERE/name)
helpers['candidate_legacy']=bind('/tmp/eris-array-buffer-historical-local-replay.py')
baselines={}
for line in (ROOT/'.github/workflows/check.yml').read_text().splitlines():
    if 'python3 tools/test262_conformance.py ' not in line:continue
    match=re.search(r'--baseline (\S+)',line)
    if not match:continue
    profile=re.search(r'--profile (\S+)',line);name=profile.group(1) if profile else 'string-json'
    assert name not in baselines;baselines[name]=bind(ROOT/match.group(1))
assert len(baselines)==34 and 'data-view' not in baselines
profiles=[]
for prior in old_formal['profiles']:
    name=prior['name'];after=latest[name]['after'];assert bind(after['path'])==after
    assert bind(latest[name]['execution']['path'])==latest[name]['execution']
    report=read(after['path']);assert report['binary_sha256']==BEFORE_BINARY
    old_report=read(prior['before_report']['path'])
    assert old_report['cases']==report['cases'] and old_report['harness_preflight']==report['harness_preflight']
    for row in prior['files']:assert bind(row['path'])==row
    if prior['baseline']:assert prior['baseline']==baselines[name]
    profile=prior.copy();profile.update(before_report=after,counts=report['counts'],controls_verified=sum(c['verified'] for c in report['harness_preflight']))
    profiles.append(profile)
new_corpus=ROOT/'tests/upstream/test262-data-view';new_report=DATA/'formal-before/data-view.json';new=read(new_report)
assert new['binary_sha256']==BEFORE_BINARY
profiles.append(dict(name='data-view',before_report=bind(new_report),cases=len(new['cases']),controls=len(new['harness_preflight']),counts=new['counts'],controls_verified=sum(c['verified'] for c in new['harness_preflight']),corpus=str(new_corpus),files=[bind(p) for p in sorted(new_corpus.rglob('*')) if p.is_file()],baseline=None))
profiles.sort(key=lambda p:p['name'])
assert {p['name'] for p in profiles}==set(contracts)
assert sum(p['cases'] for p in profiles)==19685 and sum(p['controls'] for p in profiles)==4484
formal_counts=dict(profiles=43,cases=19685,controls=4484,baseline_gates=34,corpus_files=sum(len(p['files']) for p in profiles))
formal=dict(schema=1,preparation_only=True,repository=str(ROOT),parent='b3f6e5cdcb4d43e5785d5a0309aa41d19b6d45ae',
    profiles=profiles,counts=formal_counts,contracts=bind(HERE/'formal-contracts.json'),helpers=helpers,
    helper_origins=old_formal['helper_origins'],candidate_verifier=bind(OLD/'replay-preparation/replay.py'),
    prior_provenance=[bind(OLD/'formal-replay-1/profiles-comparison.json'),bind(DATA/'formal-before/execution.json'),bind(DATA/'before-results-review.json')],
    static_files=[bind(ROOT/p) for p in ['tools/test262_conformance.py','tools/import_test262.py','tools/html_conformance.py','tools/run.py','.github/workflows/check.yml']]+[bind(HERE/p) for p in ['formal-replay.py','prepare.py','adapt_drivers.py','driver-adaptations.json']],
    before_binary_sha256=BEFORE_BINARY,limits=old_formal['limits'],
    notes=['All43 profiles execute once only after explicit frozen candidate input/binary/archive bindings are supplied.',
           'Before observations are the completed for-in42 reports plus the separately frozen DataView BEFORE; no original checkpoint report is silently substituted.',
           'All34 current baseline bytes and all source/helper/control/policy identities remain frozen; no new DataView gate or baseline.',
           'Complete changed case and control observations are retained, including newly healthy DataView controls; inherited exit1 may report such control changes without an infrastructure failure.',
           'Population-only verification captures generated controls with run_case replaced; no executable is launched.'])
save('formal-inputs.json',formal)

local_module=load(HERE/'local-replay.py','prepared_nine_local_driver')
old_local=read(OLD/'replay-preparation/inputs.json')
files={};updated=[]
permitted={str(ROOT/'tools'/name) for name in ['test262_conformance.py','import_test262.py','html_conformance.py','run.py']}
for path,row in old_local['files'].items():
    current=compact(path)
    if current!=row:
        assert path in permitted,'unexpected historical input drift: '+path
        updated.append(dict(path=path,before=row,current=current,reason='New profile registration in root tooling; original per-suite runner/tool copies and expectations remain unchanged.'))
    files[path]=current
execution=read(OLD/'locals-1/execution.json')
assert execution['completed'] and execution['all_inputs_unchanged'] and execution['post_input_checks_passed']
assert execution['binary_sha256']==BEFORE_BINARY
for rel,row in execution['captured_files'].items():
    path=OLD/'locals-1'/rel;assert bind(path)==row;files[str(path)]=compact(path)
suites=[]
for original in old_local['suites']:
    suite=original.copy();suite.pop('published_report',None)
    report=OLD/'locals-1'/('own-keys/report.json' if suite['name']=='own-keys' else suite['name']+'.json')
    suite.update(report=str(report),pointer=[],before_report_sha256=sha(report))
    suites.append(suite)
local=DATA/'local-preparation'
suites.append(dict(name='data-view',runner=str(local/'run.py'),runner_kind='standard',fixture=str(local/'data-view.js'),matrix=str(local/'runner-matrix.json'),report=str(DATA/'local-before/report.json'),pointer=[],modes=138,controls=92,cpu_seconds=30,wall_seconds=120,before_report_sha256=sha(DATA/'local-before/report.json')))
for path,row in read(local/'replay-inputs.json')['files'].items():
    assert compact(path)==row;files[path]=row
for path in [local/'replay-inputs.json',DATA/'local-before/execution.json',DATA/'local-before/local.execution.json',DATA/'local-before/report.json',DATA/'local-before/start.json',DATA/'local-before/local.stdout.log',DATA/'local-before/local.stderr.log',OLD/'locals-1/execution.json',OLD/'replay-preparation/inputs.json',HERE/'local-replay.py',HERE/'prepare.py',HERE/'adapt_drivers.py',HERE/'driver-adaptations.json']:
    files[str(path)]=compact(path)
for suite in suites:
    before=local_module.old.original(suite)
    local_module.old.verify_report(suite,before,BEFORE_BINARY)
    local_module.verify_health(before)
    assert sha(suite['runner'])==before['runner_sha256']
    if 'fixture_sha256' in before:assert sha(suite['fixture'])==before['fixture_sha256']
    if suite['matrix']:assert sha(suite['matrix'])==before['matrix_sha256']
    for path in [suite['report'],suite['runner'],suite['fixture']]+([suite['matrix']] if suite['matrix'] else []):files[str(path)]=compact(path)
for baseline in baselines.values():files[baseline['path']]={k:v for k,v in baseline.items() if k!='path'}
assert sum(s['modes'] for s in suites)==1620 and sum(s['controls'] for s in suites)==484
local_counts=dict(suites=9,fixture_modes=1620,controls=484)
save('local-inputs.json',dict(format=1,parent='b3f6e5cdcb4d43e5785d5a0309aa41d19b6d45ae',
    before=dict(directory=str(OLD/'candidate'),binary_sha256=BEFORE_BINARY,production_input_sha256='d02f2e6cd1aca614a5e90db3b79059c99d7b8626e287eae86991171aed0e8a10',observations='Latest complete for-in eight local reports plus independently frozen DataView BEFORE; prior published checkpoint counts are historical.'),
    counts=local_counts,suites=suites,files=dict(sorted(files.items())),baselines_locked=34,
    updated_root_tool_bindings=updated,reused_unchanged_helpers=old_local['reused_unchanged_helpers']+['verify_archive_inventory','verify_health'],
    notes=['All9 sources, expected observations, matrices, guarded controls and original runner helpers remain unchanged.',
           'The new DataView population has138cases/92controls, including four terminal policy expectations and visible missing prerequisites.',
           'Population-only mode requires no candidate and executes no engine; candidate execution requires all explicit frozen bindings.',
           'Every full changed before/after record is retained with unchanged per-runner limits and1200-second overall cap; no retry, baseline write or outcome normalization.']))
save('population-summary.json',dict(schema=1,formal=formal_counts,local=local_counts,
    total_case_modes=19685+1620,total_controls=4484+484,formal_manifest=bind(HERE/'formal-inputs.json'),local_manifest=bind(HERE/'local-inputs.json'),
    candidate=None,engine_execution=False,root_tool_binding_updates=updated))
print(json.dumps(read(HERE/'population-summary.json'),indent=2))
