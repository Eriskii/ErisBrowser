"""Project accepted Object.is reports into gates without executing an adapter.

Inert unless --execute is supplied with an explicitly hash-bound root review.
Run only after all frozen candidate replays and full Rust validation complete.
"""
import argparse
import hashlib
import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

if not __debug__:
    raise RuntimeError('Publication requires Python assertion checks; remove -O/PYTHONOPTIMIZE')

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
WORK = Path('/tmp/eris-object-is-runtime-1')
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT / 'tools'))


def forbidden(*args, **kwargs):
    raise AssertionError('baseline projection cannot execute processes')


subprocess.Popen = forbidden
import test262_conformance as runner


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bind(path):
    return dict(path=str(path), sha256=sha(path), bytes=path.stat().st_size)


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def projection(report):
    return dict(
        revision=report['revision'],
        corpus_manifest_sha256=report['corpus_manifest_sha256'],
        runner_policy_sha256=report['runner_policy_sha256'],
        binary_sha256=report['binary_sha256'],
        cases={case['id']: {key: case[key] for key in
               ('status', 'case_sha256', 'source_sha256')}
               for case in report['cases']})


parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--review', type=Path, required=True)
parser.add_argument('--review-sha256', required=True)
parser.add_argument('--execute', action='store_true')
args = parser.parse_args()
assert sha(args.review) == args.review_sha256
review_bytes = args.review.read_bytes()
assert hashlib.sha256(review_bytes).hexdigest() == args.review_sha256
review = json.loads(review_bytes)
assert review['accepted_for_runtime_checkpoint'] is True
assert review['publication_stage'] == 'all candidate validation and frozen replays complete'
assert review['source_parent'] == '9eddd040fd141a8669e67fecc580527527708fa1'
for item in review['required_records']:
    assert bind(Path(item['path'])) == item
comparison_path = Path(review['formal_comparison']['path'])
assert bind(comparison_path) == review['formal_comparison']
comparison = json.loads(comparison_path.read_bytes())
assert comparison['complete'] and comparison['infrastructure_failure'] is None
assert comparison['postcheck_failure'] is None
assert comparison['counts']['profiles'] == 44
assert comparison['counts']['cases'] == 19727
assert comparison['counts']['controls'] == 4564
assert comparison['counts']['regressions'] == 0
assert comparison['counts']['improvements'] == 42
assert comparison['counts']['other_changes'] == 0
assert comparison['counts']['control_changes'] == 48
assert comparison['counts']['baseline_gates_checked'] == 35
assert comparison['counts']['baseline_gates_passed'] == 35
reports = {}
old = {}
for item in comparison['profiles']:
    path = Path(item['after']['path'])
    assert bind(path) == item['after']
    report = json.loads(path.read_bytes())
    assert report['binary_sha256'] == review['binary_sha256']
    assert report['harness_preflight_passed']
    assert all(control['verified'] for control in report['harness_preflight'])
    reports[item['profile']] = (path, report)
    gate = item['current_baseline_gate']
    if gate is not None:
        assert gate['passed'] and gate['healthy'] and not gate['regressions']
        path = Path(gate['baseline']['path'])
        assert bind(path) == gate['baseline']
        old[item['profile']] = (path, path.read_bytes())
assert len(reports) == 44 and len(old) == 35
assert 'object-is' not in old

payloads = {}
changes = []
checks = []
for profile, (path, prior_bytes) in old.items():
    report_path, report = reports[profile]
    assert not any(report['counts'].get(status) for status in runner.BAD_RUN_STATUSES)
    prior = json.loads(prior_bytes)
    current = projection(report)
    lost, gained = runner.check_baseline(prior, current)
    assert not lost
    assert not gained, profile
    proposed = json.loads(payloads.get(path, prior_bytes))
    assert runner.check_baseline(proposed, current) == ([], [])
    checks.append(dict(profile=profile, baseline_path=str(path.relative_to(ROOT)),
                       baseline_sha256=hashlib.sha256(payloads.get(path, prior_bytes)).hexdigest(),
                       counts=report['counts'], report=bind(report_path),
                       lost_passes=[], unrecorded_improvements=[]))

data_path, data = reports['object-is']
assert data['counts'] == {'passed': 42}
assert len(data['cases']) == 42 and len(data['harness_preflight']) == 80
assert not any(data['counts'].get(status) for status in runner.BAD_RUN_STATUSES)
new_path = ROOT / 'tests/conformance/test262-object-is-current.json'
assert not new_path.exists()
new = projection(data)
assert runner.check_baseline(new, new) == ([], [])
payloads[new_path] = encoded(new)
checks.append(dict(profile='object-is', baseline_path=str(new_path.relative_to(ROOT)),
                   baseline_sha256=hashlib.sha256(payloads[new_path]).hexdigest(),
                   counts=data['counts'], report=bind(data_path),
                   lost_passes=[], unrecorded_improvements=[]))
workflow = ROOT / '.github/workflows/check.yml'
workflow_before = workflow.read_bytes()
anchor = '      - name: Preserve pinned non-shared DataView behavior\n'
addition = ('      - name: Preserve pinned Object.is behavior\n'
            '        run: python3 tools/test262_conformance.py --profile object-is '
            '--baseline tests/conformance/test262-object-is-current.json '
            '--output artifacts/test262-object-is-gate.json\n')
assert workflow_before.decode().count(anchor) == 1
assert '--profile object-is' not in workflow_before.decode()
payloads[workflow] = workflow_before.decode().replace(anchor, addition + anchor).encode()
receipt_path = ROOT / 'tests/conformance/test262-object-is-baseline-validation.json'
assert not receipt_path.exists()
receipt = dict(format=1, operation='Exact projection of reviewed reports and offline baseline checks',
               publisher=bind(Path(__file__)), runner=bind(ROOT/'tools/test262_conformance.py'),
               review=bind(args.review), formal_comparison=bind(comparison_path),
               engine_executions=0, known_state_gate_not_full_conformance=True,
               prior_gates_passed=35, unchanged_old_baselines=35, total_gates=36,
               strengthened_baselines=changes, checks=checks,
               workflow_before_sha256=sha(workflow),
               workflow_after_sha256=hashlib.sha256(payloads[workflow]).hexdigest(),
               workflow_addition=addition)
payloads[receipt_path] = encoded(receipt)
if not args.execute:
    print(json.dumps(dict(inert=True, proposed_files=[str(path.relative_to(ROOT)) for path in payloads],
                          current_gate_count=36, engine_executions=0)))
    raise SystemExit(0)

# All checks precede publication. Preserve exact old gates and workflow bytes.
assert args.review.read_bytes() == review_bytes
for item in review['required_records']:
    assert bind(Path(item['path'])) == item
assert bind(comparison_path) == review['formal_comparison']
for item in comparison['profiles']:
    assert bind(Path(item['after']['path'])) == item['after']
for path, content in old.values():
    assert path.read_bytes() == content
assert workflow.read_bytes() == workflow_before
assert not new_path.exists() and not receipt_path.exists()
archive = WORK / 'runtime-baselines-before.json'
with archive.open('xb') as stream:
    stream.write(encoded(dict(baselines={profile:dict(path=str(path),sha256=hashlib.sha256(content).hexdigest(),
                              text=content.decode()) for profile,(path,content) in old.items()},
                              workflow=dict(path=str(workflow),sha256=hashlib.sha256(workflow_before).hexdigest(),
                                            text=workflow_before.decode()))))
staged = {}
try:
    for path, content in payloads.items():
        descriptor, temporary = tempfile.mkstemp(prefix='.' + path.name + '.', dir=path.parent)
        staged[path] = Path(temporary)
        with os.fdopen(descriptor, 'wb') as stream:
            os.fchmod(stream.fileno(), 0o644)
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
    for path, before in old.values():
        assert path.read_bytes() == before
    assert workflow.read_bytes() == workflow_before
    assert not new_path.exists() and not receipt_path.exists()
    for path, temporary in staged.items():
        if path in (new_path, receipt_path):
            # A hard link publishes a complete new file without overwriting an
            # unexpected file created since the preceding absence check.
            os.link(temporary, path)
        else:
            os.replace(temporary, path)
        assert path.read_bytes() == payloads[path]
finally:
    for temporary in staged.values():
        temporary.unlink(missing_ok=True)
for profile, (path, before) in old.items():
    assert runner.check_baseline(json.loads(path.read_bytes()), projection(reports[profile][1])) == ([], [])
    assert path.read_bytes() == before
publication = dict(complete=True, engine_executions=0, offline_gates_checked=36,
                   preserved_before=bind(archive), files=[bind(path) for path in payloads])
with (WORK/'runtime-baseline-publication.json').open('xb') as stream:
    stream.write(encoded(publication))
print(json.dumps(publication, indent=2))
