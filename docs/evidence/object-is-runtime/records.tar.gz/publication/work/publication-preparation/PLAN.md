This is inert Object.is runtime evidence preparation. No packer has been imported or executed, and no public destination has been written. Root owns the final acceptance, baseline projection, documentation and publication.

Proposed public outputs are `docs/evidence/object-is-runtime/index.json` and `records.tar.gz`, linked by root's concise primary summary and conformance documentation. The already public Object.is preparation archive remains externally bound provenance. The collection maps each reused preparation input to an exact archived member instead of copying that preparation wholesale. The complete formal source corpus remains in the pinned public parent and frozen replay manifest.

Both candidates reconstruct from `9eddd040fd141a8669e67fecc580527527708fa1` and exactly six retained overlays: script.rs, object_is.rs, its private tests, the browser HTML fixture, pipeline.rs and worker.rs. Both archives contain 418 regular members. Source archive hashes remain bound, but tar containers and binaries are not distributed. Reconstruction proves member names/content, not original tar header encoding. Candidate2 changes only the two required pub(super) modifiers in object_is.rs; the packer checks the exact reversal.

Candidate1's first compiler failed E0624 before engine execution. It has no release binaries or external results. The initial formatter launcher failure and successful explicit formatter attempt are also retained. Candidate2 contains the complete final compiler/replay history, including all raw failures and exclusions. The summary must keep 42 new formal passes/80 healthy controls, and local 64 passes, eight failures, two unsupported modes, four resource outcomes, 68/78 expectations and 60 healthy controls distinct. There is no all-local-pass or browser-goal-complete claim.

`fixed-inputs.json` captures 944 payload bindings, both source reconstructions, all 222 formal and 53 local result files, validation drivers/logs/receipts, immutable replay manifests/helpers, previous reports, runtime reviews and the two recorded reviewer read/capture mistakes. All actual 44 formal profiles and ten local suites remain in the raw reports. Their total populations are 19,727/4,564 and 1,698/544 cases/controls respectively. All 44 explicit local terminal-policy rows remain visible. Historical runner dependencies are retained rather than rewritten. Repository records were copied into scratch at the exact replay-input hashes so later authorized baseline/doc changes cannot erase the before bindings.

The attempt-inventory template lists known attempts separately from pending publication steps. The release-manifest template remains deliberately non-executable. Before root can release packaging it must supply:

1. Final completed replay audit, validation/runtime review, packer peer review, documentation review, root acceptance and completed baseline-publication receipts. Every role must point to a retained hash-bound payload.
2. Baseline publisher source/reviews, before/projection/current gate records, actual stdout/stderr and any new publication attempt. Include final docs and root's primary summary as exact snapshots if desired. Preserve previous hashes and failure records.
3. A completed explicit attempt inventory, adding the later publication attempts. Its state must be `complete-and-reviewed`; every artifact must be in the manifest payloads.
4. A new release manifest with state `ready-for-packaging`, the fixed candidate bindings unchanged, additional payloads, all seven review roles and final publication observations. Do not edit this pending template in place.
5. A separate root sequencing receipt binding the exact manifest SHA, held packer SHA, seven accepted review SHA values and completed attempt-inventory SHA. This is internal evidence sequencing under the user's existing authorization, not a new permission request.

The packer uses bounded reads, refuses ELF and source.tar payloads, checks complete tree membership and full source reconstruction before writing, and accepts only a fresh `/tmp/eris-object-is-runtime-1/runtime-publication-package-N` output. It captures its own bytes once, uses that exact capture for the archive, and rechecks its source and all inputs after writing. An error leaves an incomplete directory; there is no overwrite, retry, validator, engine or compiler path. The completed index is emitted last.

After source review and root's release, the execution command will be:

```sh
python3 -B /tmp/eris-object-is-runtime-1/publication-preparation/pack.py \
  --manifest /tmp/eris-object-is-runtime-1/publication-preparation/release-manifest.json \
  --manifest-sha256 FINAL_MANIFEST_SHA \
  --authorization /tmp/eris-object-is-runtime-1/publication-preparation/root-sequencing-release.json \
  --authorization-sha256 FINAL_SEQUENCING_SHA \
  --output /tmp/eris-object-is-runtime-1/runtime-publication-package-1 \
  --execute-packaging
```

Root should have the completed archive/index audited before copying them to the repository. This preparation creates no package and makes no final publication claim.
