#!/usr/bin/env python3
"""Seal final evidence inputs after completed root records; never run the packer."""
import argparse
import hashlib
import json
from pathlib import Path
import tarfile

ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
WORK=Path('/tmp/eris-object-is-runtime-1')
OUT=WORK/'publication-preparation'

def binding(path):
    path=Path(path)
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 40*1024**2, path
    raw=path.read_bytes()
    return dict(path=str(path),bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())

def exact(path,sha):
    row=binding(path);assert row['sha256']==sha,(path,row);return row

def save(path,value):
    raw=(json.dumps(value,indent=2)+'\n').encode()
    with path.open('xb') as stream: stream.write(raw)
    return binding(path)

parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--final-review-sha256',required=True)
args=parser.parse_args()
fixed_row=exact(OUT/'fixed-inputs.json','1e0b63b57ab4e2b11d1ff2d7fc68d0438b1b81897800d368cbd92ec88598858f')
exact(OUT/'pack.py','82bd1ff96b3caf3297389949428ab67eee77cba8625b90fcfeb594e7943d2998')
exact(WORK/'root-runtime-acceptance.json','efba7886e4963dee3a1b656f79f8385e39338cf3678c5a30b772c1f37111588d')
exact(OUT/'layout-packer-review.json','f8137635b6b529d6afe525c00e5496f092d527e00a477b50cb0e5d1b44ae6ea9')
exact(WORK/'final-publication-script-review.json',args.final_review_sha256)
fixed=json.loads((OUT/'fixed-inputs.json').read_text())
manifest=json.loads((OUT/'release-manifest.template.json').read_text())
assert manifest['fixed_inventory']==fixed_row
baseline=json.loads((WORK/'runtime-baseline-publication.json').read_text())
acceptance=json.loads((WORK/'root-runtime-acceptance.json').read_text())
assert baseline['complete'] and baseline['engine_executions']==0 and baseline['offline_gates_checked']==36
assert acceptance['accepted_for_runtime_checkpoint'] and acceptance['candidate']=='candidate-2'
rows={}
known={row.get('original_path',row['path']):row for row in fixed['payloads']}
members={row['member'] for row in fixed['payloads']}

def add(path,member=None):
    path=Path(path);origin=str(path)
    if origin in rows: return rows[origin]['member']
    new=binding(path)
    if origin in known and new['sha256']==known[origin]['sha256'] and new['bytes']==known[origin]['bytes']:
        return known[origin]['member']
    raw=path.read_bytes()
    assert not raw.startswith(b'\x7fELF') and path.name!='source.tar'
    if member is None:
        if path.is_relative_to(ROOT): member='publication/repository/'+str(path.relative_to(ROOT))
        else:
            assert path.is_relative_to(WORK)
            member='publication/work/'+str(path.relative_to(WORK))
    assert member not in members and not member.startswith('packaging/'),member
    tarfile.TarInfo(member).tobuf(tarfile.USTAR_FORMAT)
    members.add(member)
    if path.is_relative_to(ROOT):
        dest=OUT/'published-inputs'/path.relative_to(ROOT)
        dest.parent.mkdir(parents=True,exist_ok=True)
        if dest.exists(): assert dest.read_bytes()==raw
        else: dest.write_bytes(raw)
        new['path']=str(dest)
    rows[origin]=dict(new,original_path=origin,member=member)
    return member

for path in sorted(WORK.iterdir()):
    if path.is_file() and path.name!='STATE.md': add(path)
for path in sorted((WORK/'layout-audit-attempt-1').rglob('*')):
    if path.is_file(): add(path)
for name in ['PLAN.md','source-ready.json','collection-receipt.json','fixed-inputs.initial.json',
             'release-manifest.template.initial.json','collection-receipt.initial.json',
             'attempt-inventory.template.json','release-manifest.template.json','layout-packer-review.json',
             'prepare-release.py']:
    add(OUT/name)

for row in baseline['files']:
    assert binding(row['path'])==row
    add(row['path'])
for name in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md',
             'tests/conformance/object-is.md','tests/conformance/object-is-runtime.json']:
    add(ROOT/name)

roles={
 'runtime':WORK/'implementation-review/private-review.json',
 'replays':WORK/'layout-replay-results-review.json',
 'validation':WORK/'validation/final-summary.json',
 'packer':OUT/'layout-packer-review.json',
 'documentation':WORK/'final-publication-script-review.json',
 'root_acceptance':WORK/'root-runtime-acceptance.json',
 'baseline_publication':WORK/'runtime-baseline-publication.json',
}
manifest['reviews']={role:add(path) for role,path in roles.items()}
attempts=json.loads((OUT/'attempt-inventory.template.json').read_text())
attempts['state']='complete-and-reviewed'
attempts.pop('pending')
def attempt(name,kind,disposition,paths):
    attempts['attempts'].append(dict(id=name,kind=kind,disposition=disposition,artifacts=[add(path) for path in paths]))

attempt('layout-replay-audit-initial','data-only-review','failed inspection retained; corrected audit follows',
        [p for p in sorted((WORK/'layout-audit-attempt-1').rglob('*')) if p.is_file()])
attempt('layout-replay-audit-final','data-only-review','completed independent audit',
        [WORK/n for n in ['layout-audit-replays.py','layout-audit-replays.log','layout-audit-replays.stderr.log','layout-replay-results-review.json']])
attempt('publication-preparation-read-errors','data-only-inspection','two metadata-read errors; no source/report/verdict changes',
        [OUT/'collection-read-errors.json'])
attempt('primary-summary-review','data-only-review','initial schema read correction disclosed in completed review',
        [WORK/'primary-publication-script-review.json'])
attempt('baseline-publisher-inert','offline-projection-check','completed before actual projection; no engine',
        [WORK/'baseline-publisher-inert.log',WORK/'publish-runtime-baselines.py'])
attempt('baseline-publisher-execute','offline-baseline-publication','36 gates checked; 35 old baseline files preserved; no engine',
        [WORK/'baseline-publisher-execute.log',WORK/'runtime-baseline-publication.json',WORK/'runtime-baselines-before.json'])
attempt('final-documentation-and-gates-review','data-only-review','completed independent review of final published bytes',
        [WORK/'final-publication-script-review.json'])
attempt('packer-source-review','source-only-review','clear; packer execution remains pending root sequencing',
        [OUT/'layout-packer-review.json'])
attempt_row=save(OUT/'attempt-inventory.json',attempts)
manifest['attempt_inventory_member']=add(OUT/'attempt-inventory.json','publication/attempt-inventory.json')
manifest['state']='ready-for-packaging'
manifest['additional_payloads']=sorted(rows.values(),key=lambda row:row['member'])
manifest['final_publication_observations']={
    'accepted_for_scoped_runtime_checkpoint':True,
    'baseline_engine_executions':0,'offline_gates_checked':36,'old_baselines_unchanged':35,
    'new_baseline':'test262-object-is-current.json',
    'primary_summary_member':add(ROOT/'tests/conformance/object-is-runtime.json'),
    'browser_goal_complete':False,
    'qualification':'Acceptance concerns this bounded Object.is increment. Candidate histories and all retained failures/exclusions/resources remain distinct.',
}
all_rows=fixed['payloads']+manifest['additional_payloads']
by_member={row['member']:row for row in all_rows}
assert len(by_member)==len(all_rows)
for attempt in attempts['attempts']:
    assert attempt['artifacts'] and all(name in by_member for name in attempt['artifacts'])
for row in all_rows:
    actual=binding(row['path']);assert actual['bytes']==row['bytes'] and actual['sha256']==row['sha256'],row
manifest_row=save(OUT/'release-manifest.json',manifest)
ready=dict(schema=1,state='final manifest ready; packer not executed',manifest=manifest_row,
           attempt_inventory=attempt_row,packer=binding(OUT/'pack.py'),fixed_inventory=fixed_row,
           review_hashes={role:by_member[member]['sha256'] for role,member in manifest['reviews'].items()},
           additional_payload_count=len(manifest['additional_payloads']),payload_count=len(all_rows),
           payload_bytes=sum(row['bytes'] for row in all_rows),
           publication_performed=False,engines_or_compilers_executed=False)
save(OUT/'manifest-ready.json',ready)
print(json.dumps(ready,indent=2))
