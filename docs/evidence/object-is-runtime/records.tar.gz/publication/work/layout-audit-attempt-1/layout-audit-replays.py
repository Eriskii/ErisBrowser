#!/usr/bin/env python3
"""Independent data-only replay audit; no project imports or subprocesses."""
from pathlib import Path
from collections import Counter
import datetime
import hashlib
import json
import tarfile

B = Path('/tmp/eris-object-is-runtime-1')
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
CANDIDATE = B / 'candidate-2'
PRODUCTION = '505dba3242fd9f28364c2ced18708773eb46acb4d7f56ae0ac39cabc75f96d28'
ARCHIVE_INVENTORY = '5c28bc9c91d729801a77851cf4c6da411d246e6e4eef67c8dd74d4a49a1ff02b'
BINARY = '804bc8dd688182641be37be577feade9fe043a0869000cd272977707c320b4df'
FORMAL_IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
LOCAL_IDENTITY = FORMAL_IDENTITY + ('source', 'expected_observation', 'expectation_sha256',
    'category', 'area', 'prerequisites', 'positive', 'partner', 'expected', 'oracle_kind', 'note')

def read(path):
    return json.loads(Path(path).read_bytes())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def bind(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def verify(row):
    p = Path(row['path'])
    assert p.is_file() and not p.is_symlink(), p
    assert bind(p) == row, p

def identity(row, fields):
    return {key: row[key] for key in fields if key in row}

def controls(report):
    return report.get('controls', report.get('harness_controls', []))

def check_formal_health(report):
    rows = report['harness_preflight']
    by_key = {(r['name'], r['result']['mode']): r for r in rows}
    assert len(by_key) == len(rows)
    computed = {}
    def health(key, active=frozenset()):
        if key in computed:
            return computed[key]
        assert key not in active
        r = by_key[key]
        value = r['result']['status'] == r['expected']
        if r['expected'] == 'failed':
            value = value and r['result'].get('observation', {}).get('error_type') == 'Test262Error'
        if 'prerequisite' in r:
            p = r['prerequisite']
            partner_key = (p['name'], p['mode'])
            partner = by_key[partner_key]
            assert p['mode'] == r['result']['mode']
            for field in ('case_sha256', 'source_sha256'):
                assert p[field] == partner['result'][field]
            assert p['expected'] == partner['expected']
            if 'result' in p:
                assert p['result'] == partner['result']
            expected_health = health(partner_key, active | {key})
            assert p['verified'] == expected_health
            value = value and expected_health
        assert r['verified'] == value
        computed[key] = value
        return value
    assert all(health(key) for key in by_key)
    assert report['harness_preflight_passed'] is True

def check_local_health(report):
    rows = report['cases'] + controls(report)
    by_id = {r['id']: r for r in rows}
    assert len(by_id) == len(rows)
    for r in rows:
        expected = r.get('expected_observation', r.get('expected'))
        assert isinstance(expected, dict)
        match = all(r.get('observation', {}).get(k) == v for k, v in expected.items())
        assert r['matches_expectation'] == match
        assert hashlib.sha256(r['source'].encode()).hexdigest() == r['source_sha256']
    for r in controls(report):
        if 'verified' in r:
            assert r['verified'] == (r['matches_expectation'] and by_id[r['partner']]['matches_expectation'])
    if 'controls_verified' in report:
        assert report['controls_verified'] == sum(r['verified'] for r in controls(report))
    if 'harness_controls_verified' in report:
        assert report['harness_controls_verified'] == sum(r['matches_expectation'] for r in controls(report))
    if 'protocol_prerequisites' in report:
        for mode, p in report['protocol_prerequisites'].items():
            actual = by_id[p['id']]
            assert actual['mode'] == mode and p['matches_expectation'] == actual['matches_expectation']
            assert p['observation'] == actual.get('observation', {})
        assert report['protocol_prerequisite_verified'] == all(p['matches_expectation'] for p in report['protocol_prerequisites'].values())
    elif 'protocol_prerequisite_verified' in report:
        assert report['protocol_prerequisite_verified'] == all(by_id['preflight-protocol-values-positive#' + mode]['matches_expectation'] for mode in ('sloppy', 'strict'))
    for r in report['cases']:
        if 'prerequisite' in r:
            assert r['prerequisite'] == report['protocol_prerequisites'][r['mode']]
        if 'verified_with_protocol_prerequisite' in r:
            ok = r['prerequisite']['matches_expectation'] if 'prerequisite' in r else report['protocol_prerequisite_verified']
            assert r['verified_with_protocol_prerequisite'] == (r['matches_expectation'] and ok)
        if 'guarded_verified' in r:
            assert r['guarded_verified'] == (r['matches_expectation'] and by_id['preflight-smoke-positive#' + r['mode']]['matches_expectation'])
    if 'fixture_expectations_matched' in report:
        assert report['fixture_expectations_matched'] == sum(r['matches_expectation'] for r in report['cases'])
    if 'fixture_expectations_verified' in report:
        assert report['fixture_expectations_verified'] == sum(r.get('verified_with_protocol_prerequisite', r.get('guarded_verified', False)) for r in report['cases'])

assert sha(CANDIDATE / 'archive-inputs.json') == ARCHIVE_INVENTORY
assert sha(CANDIDATE / 'eris-js') == BINARY
inventory = read(CANDIDATE / 'archive-inputs.json')['files']
mapping = {r['path']: r for r in inventory}
assert len(mapping) == len(inventory) == 418
with tarfile.open(CANDIDATE / 'source.tar', 'r:') as archive:
    seen, regular = set(), {}
    for member in archive.getmembers():
        name = Path(member.name)
        assert not name.is_absolute() and '..' not in name.parts and member.name not in seen
        assert member.isfile() or member.isdir()
        seen.add(member.name)
        if member.isfile():
            raw = archive.extractfile(member).read()
            expected = mapping[member.name]
            assert len(raw) == member.size == expected['bytes']
            assert hashlib.sha256(raw).hexdigest() == expected['sha256']
            regular[member.name] = raw
    assert set(regular) == set(mapping)
digest = hashlib.sha256()
inputs = read(CANDIDATE / 'inputs.json')
for r in sorted(inputs['files'], key=lambda r: Path(r['path'])):
    raw = regular[r['path']]
    assert hashlib.sha256(raw).hexdigest() == r['sha256'] == sha(ROOT / r['path'])
    digest.update(r['path'].encode() + b'\0' + raw + b'\0')
assert digest.hexdigest() == inputs['input_sha256'] == PRODUCTION
for r in read(CANDIDATE / 'verification-inputs.json')['files']:
    assert sha(ROOT / r['path']) == r['sha256'] == hashlib.sha256(regular[r['path']]).hexdigest()
assert read(CANDIDATE / 'default-binaries.json')['eris-js'] == BINARY
build = read(CANDIDATE / 'build-bindings.json')
assert build['all_source_inputs_unchanged'] and build['archive_inventory_sha256'] == ARCHIVE_INVENTORY
assert build['source_archive_sha256'] == sha(CANDIDATE / 'source.tar') and build['binaries']['eris-js'] == BINARY

fm = read(B / 'replay-preparation/formal-inputs.json')
lm = read(B / 'replay-preparation/local-inputs.json')
assert sha(B / 'replay-preparation/formal-inputs.json') == '45fd8f6e034e020fdb6bc96510f2bf94bc92135c2a4b55f1f3f0fe0d72201ca6'
assert sha(B / 'replay-preparation/local-inputs.json') == '0190143d0f5e3c3d845bb451df2ef8ef217d5284285184fd83bd45264b7207b7'
for r in fm['static_files'] + list(fm['helpers'].values()) + [fm['candidate_verifier'], fm['contracts']] + fm['prior_provenance']:
    verify(r)
for path, r in lm['files'].items():
    verify(dict(path=path, **r))
contract = read(fm['contracts']['path'])['profiles']
aggregate = read(B / 'formal-candidate-2/profiles-comparison.json')
assert aggregate['complete'] and aggregate['all_inputs_unchanged'] and not aggregate['infrastructure_failure'] and not aggregate['postcheck_failure']
assert not aggregate['baselines_written'] and not aggregate['retries']
assert aggregate['binary_sha256'] == BINARY and aggregate['production_input_sha256'] == PRODUCTION
verify(aggregate['manifest']); verify(aggregate['driver'])
formal_summary, process_codes, raw_formal, control_changes = [], Counter(), Counter(), 0
for profile, result in zip(fm['profiles'], aggregate['profiles']):
    name = profile['name']; assert name == result['profile']
    for r in profile['files'] + [profile['before_report'], result['after'], result['execution']]:
        verify(r)
    assert {str(p) for p in Path(profile['corpus']).rglob('*') if p.is_file()} == {r['path'] for r in profile['files']}
    before, after = read(profile['before_report']['path']), read(result['after']['path'])
    assert before['binary_sha256'] == fm['before_binary_sha256'] and after['binary_sha256'] == BINARY
    for k in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'runner_policy', 'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases'):
        assert before[k] == after[k]
    assert after['runner_policy'] == contract[name]['policy'] and after['corpus_manifest_sha256'] == contract[name]['manifest_sha256']
    assert len(after['cases']) == profile['cases'] and len(after['harness_preflight']) == profile['controls']
    assert after['counts'] == dict(Counter(r['status'] for r in after['cases']))
    changes = []
    for a, r in zip(before['cases'], after['cases']):
        assert identity(a, FORMAL_IDENTITY) == identity(r, FORMAL_IDENTITY)
        frozen = contract[name]['cases'][r['id']]
        for k in ('file', 'mode', 'case_sha256', 'source_sha256'):
            assert r[k] == frozen[k]
        assert r['expected_negative'] == frozen['metadata']['negative']
        if frozen['unsupported_reason']:
            assert r['status'] == 'unsupported' and r['reason'] == frozen['unsupported_reason']
        if a != r:
            kind = 'regression' if a['status'] == 'passed' and r['status'] != 'passed' else 'improvement' if a['status'] != 'passed' and r['status'] == 'passed' else 'other'
            changes.append(dict(id=r['id'], kind=kind, before=a, after=r))
    assert changes == result['complete_changed_case_records']
    cchanges = []
    for a, r, frozen in zip(before['harness_preflight'], after['harness_preflight'], contract[name]['preflights']):
        assert a['name'] == r['name'] == frozen['name'] and a['expected'] == r['expected'] == frozen['expected']
        assert identity(a['result'], FORMAL_IDENTITY) == identity(r['result'], FORMAL_IDENTITY)
        for k in ('mode', 'case_sha256', 'source_sha256'):
            assert r['result'][k] == frozen[k]
        if a != r:
            cchanges.append(dict(name=r['name'], mode=r['result']['mode'], before=a, candidate=r))
    assert cchanges == result['complete_changed_control_records']
    check_formal_health(after)
    assert result['controls_verified'] == profile['controls']
    assert result['unchanged_case_records'] == len(after['cases']) - len(changes)
    assert result['unchanged_control_records'] == len(after['harness_preflight']) - len(cchanges)
    gate = result['current_baseline_gate']
    if profile['baseline']:
        verify(profile['baseline']); previous = read(profile['baseline']['path'])
        assert gate['baseline'] == profile['baseline'] and gate['passed'] and gate['healthy']
        assert not gate['regressions'] and not gate['improvements']
        for k in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256'):
            assert previous[k] == after[k]
        projected = {r['id']: {k: r[k] for k in ('status', 'case_sha256', 'source_sha256')} for r in after['cases']}
        assert projected == previous['cases']
        assert not any(after['counts'].get(k) for k in ('adapter-error', 'timeout', 'resource'))
    else:
        assert gate is None
    execution = read(result['execution']['path'])
    assert execution['leader_reaped'] and execution['reap_started'] and not execution.get('failure') and not execution.get('cleanup_failure')
    observed = execution['exit_observed_without_reaping']
    assert execution['returncode'] == observed['si_status'] == int(after['counts'].get('passed', 0) != len(after['cases']))
    assert execution['pid'] == observed['si_pid'] and observed['si_code'] == 1
    for k in ('stdout_log', 'stderr_log', 'json'):
        verify(execution[k])
    assert execution['stderr_log']['bytes'] == 0
    process_codes[execution['returncode']] += 1
    raw_formal.update(after['counts']); control_changes += len(cchanges)
    if name != 'object-is':
        assert before['cases'] == after['cases'] and before['harness_preflight'] == after['harness_preflight']
    else:
        assert after['counts'] == dict(passed=42) and len(changes) == 42 and len(cchanges) == 48
    formal_summary.append(dict(profile=name, cases=len(after['cases']), controls=len(after['harness_preflight']), counts=after['counts'], changed_cases=len(changes), changed_controls=len(cchanges), gated=gate is not None))
assert len(formal_summary) == 44 and control_changes == 48
assert aggregate['counts'] == dict(profiles=44, cases=19727, controls=4564, improvements=42, regressions=0, other_changes=0, control_changes=48, baseline_gates_checked=35, baseline_gates_passed=35)

local_execution = read(B / 'local-candidate-2/execution.json')
assert local_execution['completed'] and local_execution['all_inputs_unchanged'] and local_execution['post_input_checks_passed']
assert local_execution['binary_sha256'] == BINARY and local_execution['production_input_sha256'] == PRODUCTION
assert not local_execution.get('failure') and not local_execution.get('post_input_failure') and not local_execution['baseline_written'] and not local_execution['retries']
for row in local_execution['captured_files'].values():
    verify(row)
for row in local_execution['release_files'].values():
    verify(row)
local_summary, policy = [], []
comparison = read(B / 'local-candidate-2/comparison.json')
for suite in lm['suites']:
    name = suite['name']; before = read(suite['report'])
    for key in suite['pointer']:
        before = before[key]
    path = B / 'local-candidate-2' / ('own-keys/report.json' if name == 'own-keys' else name + '.json')
    after = read(path)
    assert before['binary_sha256'] == lm['before']['binary_sha256'] and after['binary_sha256'] == BINARY
    assert len(after['cases']) == suite['modes'] and len(controls(after)) == suite['controls']
    for k in ('fixture_sha256', 'matrix_sha256', 'freeze_sha256', 'runner_sha256', 'tool_hashes', 'harness', 'bounds'):
        assert before.get(k) == after.get(k)
    assert after['counts'] == dict(Counter(r['status'] for r in after['cases']))
    check_local_health(after)
    changed, gains, losses, transitions = [], [], [], Counter()
    for group, left, right in [('cases', before['cases'], after['cases']), ('controls', controls(before), controls(after))]:
        for a, r in zip(left, right):
            assert identity(a, LOCAL_IDENTITY) == identity(r, LOCAL_IDENTITY)
            if a != r:
                changed.append(dict(group=group, id=r['id'], before=a, after=r))
            if group == 'cases':
                transitions[a['status'] + ' -> ' + r['status']] += 1
                if a['status'] != 'passed' and r['status'] == 'passed': gains.append(r['id'])
                if a['status'] == 'passed' and r['status'] != 'passed': losses.append(r['id'])
                expected = r.get('expected_observation', r.get('expected', {}))
                if expected.get('status') == 'resource':
                    assert r['status'] == 'resource' and r['matches_expectation']
                    if name != 'object-is': assert a == r
                    policy.append(dict(suite=name, id=r['id']))
    expected_comparison = dict(unchanged_complete_records=suite['modes'] + suite['controls'] - len(changed), changed_complete_records=len(changed), transitions=dict(transitions), raw_pass_gains=gains, raw_pass_losses=losses, changes=changed, no_observation_normalization=True)
    assert expected_comparison == comparison['suites'][name] == read(B / 'local-candidate-2' / (name + '.comparison.json'))
    process = read(B / 'local-candidate-2' / (name + '.execution.json'))
    assert process['leader_reaped'] and process['returncode'] == process['exit_observed_unreaped']['status'] == 0
    assert process['pid'] == process['exit_observed_unreaped']['pid'] and process['exit_observed_unreaped']['code'] == 1
    assert not process.get('failure') and not process.get('cleanup_failure')
    assert (B / 'local-candidate-2' / (name + '.stderr.log')).stat().st_size == 0
    if name != 'object-is': assert not changed
    else:
        object_is = after
        assert after['counts'] == dict(passed=64, failed=8, unsupported=2, resource=4)
        assert after['fixture_expectations_matched'] == after['fixture_expectations_verified'] == 68 and after['controls_verified'] == 60
    local_summary.append(dict(suite=name, cases=suite['modes'], controls=suite['controls'], counts=after['counts'], changed_complete_records=len(changed)))
assert len(local_summary) == 10 and len(policy) == 44 and policy == lm['explicit_terminal_policy_rows']
assert sum(x['cases'] for x in local_summary) == 1698 and sum(x['controls'] for x in local_summary) == 544
failures = [dict(id=r['id'], status=r['status'], observation=r.get('observation'), reason=r.get('reason')) for r in object_is['cases'] if r['status'] not in ('passed', 'resource')]
assert Counter(r['id'].split('#')[0] for r in failures) == Counter({'proxy-identity-no-traps':2, 'bigint-identity-and-number-distinction':2, 'foreign-realm-object-identity':2, 'dom-defining-interface-querySelector':2, 'dom-defining-interface-querySelectorAll':2})

report = dict(schema=1, reviewer='layout', reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    decision='clear: immutable candidate, complete observations, controls, current35 gates and process receipts agree', findings=[],
    candidate=dict(production_input_sha256=PRODUCTION, archive_inventory_sha256=ARCHIVE_INVENTORY,
        binary_sha256=BINARY, production_files=len(inputs['files']), archive_regular_members=418),
    formal=dict(counts=aggregate['counts'], raw_statuses=dict(raw_formal), all_controls_verified=4564,
        historical43_complete_rows_unchanged=True, runner_exit_counts=dict(process_codes), profiles=formal_summary,
        driver_exit_explanation='The preserved driver returns1 solely because48 Object.is control records improve; complete=true,0regressions,35/35gates. Individual nonzero profile exits retain known incomplete profile observations.'),
    local=dict(suites=local_summary, historical9_complete_rows_unchanged=True, cases=1698, controls=544,
        object_is_counts=object_is['counts'], object_is_expectations_matched=68, object_is_controls_verified=60,
        policy_rows=44, old40_policy_rows_unchanged=True, all44_policy_expectations_matched=True,
        object_is_remaining_rows=failures),
    processes=dict(formal=44, local=10, all_recorded_leaders_reaped=True, all_stderr_empty=True, cleanup_failures=0),
    bindings=[bind(p) for p in [Path(__file__), B/'replay-preparation/source-ready.json', B/'replay-preparation/formal-inputs.json', B/'replay-preparation/local-inputs.json',
        CANDIDATE/'inputs.json', CANDIDATE/'verification-inputs.json', CANDIDATE/'archive-inputs.json', CANDIDATE/'source.tar', CANDIDATE/'default-binaries.json', CANDIDATE/'eris-js', CANDIDATE/'build-bindings.json',
        B/'formal-candidate-2/profiles-comparison.json', B/'formal-candidate-2/start.json', B/'local-candidate-2/execution.json', B/'local-candidate-2/comparison.json', B/'formal-candidate-2-driver.log', B/'local-candidate-2-driver.log']],
    limitations=['Data-only audit: no engine, compiler, tests, replay or project imports executed by reviewer.',
        'The 35 baseline gates and all control checks pass; remaining profile/local failures and unsupported states remain visible. No global all-pass or full conformance claim.',
        'Foreign-realm rows are static host-hook exclusions with no engine observation. DOM defining-interface identity, Proxy and BigInt remain ordinary unsupported capability gaps, not adjusted expectations.',
        'Recorded process ownership/cleanup was checked against retained receipts and logs; the reviewer did not independently observe past process trees.',
        'Root owns the Rust matrix audit and subsequent baseline publication; this receipt authorizes neither an engine rerun nor altered baselines.'])
out = B / 'layout-replay-results-review.json'
with out.open('x') as output:
    json.dump(report, output, indent=2)
    output.write('\n')
print(json.dumps(bind(out)))
