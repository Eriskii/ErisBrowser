# Immutable Object.is runtime replay preparation

The drivers are inert by default. No candidate is selected and no engine or compiler has been launched by this preparation. The source checkpoint parent is preparation-only commit `9eddd040fd141a8669e67fecc580527527708fa1`; the comparison adapter is the published DataView candidate3 `b61e487bf1ea2c0ff70b471656b4abd15aa085b2570406d8c76ab8ab14fcdf18`.

`formal-inputs.json` binds 44 profiles, 19,727 case modes, 4,564 controls, 10,634 corpus files and all 35 current baseline gates. The first 43 authorities are the exact `after` reports in `/tmp/eris-data-view-1/formal-candidate-3/profiles-comparison.json`; Object.is uses its original `/tmp/eris-object-is-preparation-1/formal-before/object-is.json`. The existing 43 contracts have canonical SHA `2555833d1cd7a66a19d02ed295f404060b72472d7af8fbd008517285be5d6cd6`. There is no Object.is baseline or gate.

`local-inputs.json` binds all nine complete `/tmp/eris-data-view-1/local-candidate-3` reports plus the original Object.is local BEFORE: ten suites, 1,698 modes, 544 controls and 44 explicit terminal-resource expectations. Every original runner, fixture, expected observation, helper and per-suite limit remains unchanged. The four Object.is terminal-policy modes and two ordinary DOM identity gaps remain visible; no expected outcome was changed. Historical root bindings are refreshed only for the two Object.is tooling registrations and the already-published Object.seal baseline strengthening. The exact deltas are recorded; the current 35-gate freeze is authoritative.

Both population-only commands passed once with empty stderr:

```sh
python3 -B /tmp/eris-object-is-runtime-1/replay-preparation/formal-replay.py --manifest /tmp/eris-object-is-runtime-1/replay-preparation/formal-inputs.json --manifest-sha256 45fd8f6e034e020fdb6bc96510f2bf94bc92135c2a4b55f1f3f0fe0d72201ca6
python3 -B /tmp/eris-object-is-runtime-1/replay-preparation/local-replay.py --manifest-sha256 0190143d0f5e3c3d845bb451df2ef8ef217d5284285184fd83bd45264b7207b7
```

After root freezes an actual candidate, supply all five candidate arguments together. These placeholders are not candidate bindings. Without the final execution flag, each command verifies the supplied binary/source archive without creating replay output.

```sh
python3 -B /tmp/eris-object-is-runtime-1/replay-preparation/formal-replay.py --manifest /tmp/eris-object-is-runtime-1/replay-preparation/formal-inputs.json --manifest-sha256 45fd8f6e034e020fdb6bc96510f2bf94bc92135c2a4b55f1f3f0fe0d72201ca6 --candidate-directory /tmp/eris-object-is-runtime-1/CANDIDATE --production-input-sha256 INPUT_SHA256 --binary-sha256 ERIS_JS_SHA256 --archive-inputs-sha256 ARCHIVE_INVENTORY_SHA256 --output-directory /tmp/eris-object-is-runtime-1/formal-candidate-1 --execute-authorized
python3 -B /tmp/eris-object-is-runtime-1/replay-preparation/local-replay.py --manifest-sha256 0190143d0f5e3c3d845bb451df2ef8ef217d5284285184fd83bd45264b7207b7 --candidate-directory /tmp/eris-object-is-runtime-1/CANDIDATE --production-input-sha256 INPUT_SHA256 --binary-sha256 ERIS_JS_SHA256 --archive-inputs-sha256 ARCHIVE_INVENTORY_SHA256 --output-directory /tmp/eris-object-is-runtime-1/local-candidate-1 --execute
```

Candidate requirements remain regular `eris-js`, `default-binaries.json`, legacy `inputs.json` with its production digest, uncompressed `source.tar` and `archive-inputs.json` covering every regular archive member. The inherited verifier rejects links, unsafe or duplicate paths, missing/extra members, more than 2,048 members, individual files above 16 MiB and total archive content above 64 MiB. Optional supplemental receipts are bound when present. No live runtime tree or inferred candidate is substituted.

Formal limits remain 600 seconds per profile, 3 seconds per case, four jobs, 1 GiB address space, 300 CPU seconds, 32 MiB log files and 3,600 seconds overall. Local limits remain those of each original runner and 1,200 seconds overall; Object.is uses the unchanged 120-second suite wall/30-second CPU limits. Both preserve the original unreaped-leader, signal-before-reap cleanup and Python environment sanitization.

Complete report rows and before/after changes are retained. Baseline comparisons use the completed new reports without adapter reruns. Formal exit1 can mean newly healthy Object.is controls, a regression or gate failure; `profiles-comparison.json` distinguishes those without suppressing control gains. No baseline, fixture, policy, quota or observation is written or normalized by the drivers. `driver-adaptations.json` and both `.diff` files enumerate every driver change. Preparation and both inert checks completed on their first attempts.
