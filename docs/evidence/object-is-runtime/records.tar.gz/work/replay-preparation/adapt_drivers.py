#!/usr/bin/env python3
"""Text-only adaptation of held DataView replay drivers; no engine execution."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
OLD = Path('/tmp/eris-data-view-1/replay-preparation')

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def adapt(name, replacements):
    origin = OLD / name
    source = origin.read_text()
    changes = []
    for before, after in replacements:
        assert source.count(before) == 1, (name, before, source.count(before))
        source = source.replace(before, after)
        changes.append(dict(before=before, after=after))
    target = HERE / name
    with target.open('x') as output:
        output.write(source)
    delta = ''.join(difflib.unified_diff(origin.read_text().splitlines(keepends=True),
        source.splitlines(keepends=True), fromfile=str(origin), tofile=str(target)))
    patch = target.with_suffix('.diff')
    with patch.open('x') as output:
        output.write(delta)
    return dict(origin=str(origin), origin_sha256=sha(origin), adapted=str(target),
        adapted_sha256=sha(target), diff=str(patch), diff_sha256=sha(patch), changes=changes)

rows = [adapt('formal-replay.py', [
    ('one authorized43-profile replay', 'one authorized44-profile replay'),
    ("== 43, 'profile count differs'", "== 44, 'profile count differs'"),
    ('current34 gates', 'current35 gates'),
    ('len(results)==43', 'len(results)==44'),
    ("counts['baseline_gates_passed'] !=34", "counts['baseline_gates_passed'] !=35"),
]), adapt('local-replay.py', [
    ('nine unchanged local populations', 'ten unchanged local populations'),
    ("'array-concat', 'array-buffer', 'data-view')", "'array-concat', 'array-buffer', 'data-view', 'object-is')"),
    ('dict(suites=9, fixture_modes=1620, controls=484)', 'dict(suites=10, fixture_modes=1698, controls=544)'),
    ('9 unchanged populations, 1620 cases + 484 controls', '10 unchanged populations, 1698 cases + 544 controls'),
    ("observation_comparison='latest completed ArrayBuffer-era reports, exact complete rows'",
     "observation_comparison='latest completed DataView candidate3 reports plus Object.is BEFORE, exact complete rows'"),
    ("== 1620, 'complete mode count'", "== 1698, 'complete mode count'"),
    ("== 484, 'complete control count'", "== 544, 'complete control count'"),
])]
with (HERE / 'driver-adaptations.json').open('x') as output:
    json.dump(dict(schema=1, drivers=rows,
        preserved='Complete observation comparisons, policies/guards, original suite runners, candidate archive verifier, bounded process ownership/cleanup, all-or-none candidate arguments and all execution limits remain unchanged.',
        changes=['Extend formal population to44 and current immutable gates to35.',
                 'Extend local population to10,1698modes,544controls; correct comparison provenance label.'],
        future_exit_status='Formal exit1 may reflect newly healthy Object.is control changes as well as regressions or gate failures; complete changed records remain visible.'), output, indent=2)
    output.write('\n')
print(json.dumps(rows, indent=2))
