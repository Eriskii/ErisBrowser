#!/usr/bin/env python3
"""Freeze replay inputs from complete retained observations; never run an engine."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import sys

sys.dont_write_bytecode = True
if not __debug__:
    raise RuntimeError('Optimized Python is not allowed for preparation')
HERE = Path(__file__).resolve().parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-data-view-1')
PREP = Path('/tmp/eris-object-is-preparation-1')
PARENT = '9eddd040fd141a8669e67fecc580527527708fa1'
BEFORE_BINARY = 'b61e487bf1ea2c0ff70b471656b4abd15aa085b2570406d8c76ab8ab14fcdf18'

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def bind(path):
    p = Path(path)
    assert p.is_file() and not p.is_symlink(), str(p)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def compact(path):
    return {k: v for k, v in bind(path).items() if k != 'path'}

def save(name, data):
    with (HERE / name).open('x') as output:
        json.dump(data, output, indent=2)
        output.write('\n')

def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

old_formal = read(OLD / 'replay-preparation/formal-inputs.json')
history = read(OLD / 'formal-candidate-3/profiles-comparison.json')
assert history['complete'] and history['all_inputs_unchanged']
assert history['binary_sha256'] == BEFORE_BINARY
assert history['counts']['profiles'] == 43 and history['counts']['baseline_gates_passed'] == 34
latest = {row['profile']: row for row in history['profiles']}
old_contract_path = PREP / 'historical-freeze/contracts.json'
old_contract = read(old_contract_path)
assert sha(old_contract_path) == '2555833d1cd7a66a19d02ed295f404060b72472d7af8fbd008517285be5d6cd6'
assert old_contract['profiles'] == read(OLD / 'replay-preparation/formal-contracts.json')['profiles']
new_contract_path = PREP / 'formal-preparation/contracts.json'
new_contract = read(new_contract_path)
assert new_contract['counts'] == dict(profiles=1, cases=42, preflights=80)
contracts = old_contract['profiles'] | new_contract['profiles']
assert len(contracts) == 44
save('formal-contracts.json', dict(schema=1, profiles=contracts,
    origins=[bind(old_contract_path), bind(new_contract_path)]))

helpers = {}
for key, name in [('historical', 'historical-helper.py'), ('supervision', 'supervision-helper.py')]:
    source = OLD / 'replay-preparation' / name
    with (HERE / name).open('xb') as output:
        output.write(source.read_bytes())
    helpers[key] = bind(HERE / name)
helpers['candidate_legacy'] = bind('/tmp/eris-array-buffer-historical-local-replay.py')

baselines = {}
for line in (ROOT / '.github/workflows/check.yml').read_text().splitlines():
    if 'python3 tools/test262_conformance.py ' not in line:
        continue
    found = re.search(r'--baseline (\S+)', line)
    if not found:
        continue
    profile = re.search(r'--profile (\S+)', line)
    name = profile.group(1) if profile else 'string-json'
    assert name not in baselines
    baselines[name] = bind(ROOT / found.group(1))
assert len(baselines) == 35 and 'data-view' in baselines and 'object-is' not in baselines
assert baselines == read(PREP / 'historical-freeze/freeze.json')['baselines']
published = read(OLD / 'runtime-baseline-publication.json')
assert published['complete'] and published['engine_executions'] == 0 and published['offline_gates_checked'] == 35

profiles = []
for prior in old_formal['profiles']:
    name = prior['name']
    after = latest[name]['after']
    assert bind(after['path']) == after
    assert bind(latest[name]['execution']['path']) == latest[name]['execution']
    report = read(after['path'])
    assert report['binary_sha256'] == BEFORE_BINARY
    assert len(report['cases']) == prior['cases'] and len(report['harness_preflight']) == prior['controls']
    for row in prior['files']:
        assert bind(row['path']) == row
    profile = prior.copy()
    profile.update(before_report=after, counts=report['counts'],
        controls_verified=sum(row['verified'] for row in report['harness_preflight']),
        baseline=baselines.get(name))
    profiles.append(profile)
new_corpus = ROOT / 'tests/upstream/test262-object-is'
new_report = PREP / 'formal-before/object-is.json'
new = read(new_report)
assert new['binary_sha256'] == BEFORE_BINARY
profiles.append(dict(name='object-is', before_report=bind(new_report), cases=42, controls=80,
    counts=new['counts'], controls_verified=sum(row['verified'] for row in new['harness_preflight']),
    corpus=str(new_corpus), files=[bind(p) for p in sorted(new_corpus.rglob('*')) if p.is_file()], baseline=None))
profiles.sort(key=lambda p: p['name'])
assert {p['name'] for p in profiles} == set(contracts)
assert sum(p['cases'] for p in profiles) == 19727 and sum(p['controls'] for p in profiles) == 4564
formal_counts = dict(profiles=44, cases=19727, controls=4564, baseline_gates=35,
    corpus_files=sum(len(p['files']) for p in profiles))
provenance = [OLD / 'formal-candidate-3/profiles-comparison.json',
    OLD / 'runtime-baseline-publication.json', PREP / 'formal-before/execution.json',
    PREP / 'layout-before-results-review.json', PREP / 'before-summary.json']
formal = dict(schema=1, preparation_only=True, repository=str(ROOT), parent=PARENT,
    profiles=profiles, counts=formal_counts, contracts=bind(HERE / 'formal-contracts.json'), helpers=helpers,
    helper_origins=old_formal['helper_origins'], candidate_verifier=old_formal['candidate_verifier'],
    prior_provenance=[bind(p) for p in provenance],
    static_files=[bind(ROOT / p) for p in ['tools/test262_conformance.py', 'tools/import_test262.py',
        'tools/html_conformance.py', 'tools/run.py', '.github/workflows/check.yml']]
        + [bind(HERE / p) for p in ['formal-replay.py', 'prepare.py', 'adapt_drivers.py', 'driver-adaptations.json']],
    before_binary_sha256=BEFORE_BINARY, limits=old_formal['limits'],
    notes=['All44 profiles execute once only after explicit candidate path/input/binary/archive bindings.',
        'Before authorities are all43 latest DataView candidate3 reports plus the separately frozen Object.is BEFORE.',
        'All35 current baselines stay immutable; no Object.is gate exists or is written by this replay.',
        'Every complete changed case/control row is retained, including newly healthy controls; formal exit1 can represent such control changes.',
        'Population-only checks replace run_case to capture generated controls; no executable is launched.'])
save('formal-inputs.json', formal)

local_module = load(HERE / 'local-replay.py', 'prepared_ten_local_driver')
old_local = read(OLD / 'replay-preparation/local-inputs.json')
files = {}
updates = []
allowed_tools = {str(ROOT / 'tools' / name) for name in ['test262_conformance.py', 'import_test262.py']}
allowed_baseline = str(ROOT / 'tests/conformance/test262-object-integrity-current.json')
for path, row in old_local['files'].items():
    current = compact(path)
    if current != row:
        assert path in allowed_tools or path == allowed_baseline, 'unexpected historical binding drift: ' + path
        reason = ('Completed DataView publication strengthens two Object.seal modes; exact current35 gate freeze is authoritative.'
                  if path == allowed_baseline else 'Only new Object.is profile registration; per-suite copied runners/tools remain unchanged.')
        updates.append(dict(path=path, before=row, current=current, reason=reason))
    files[path] = current
execution = read(OLD / 'local-candidate-3/execution.json')
assert execution['completed'] and execution['all_inputs_unchanged'] and execution['post_input_checks_passed']
assert execution['binary_sha256'] == BEFORE_BINARY
for relative, row in execution['captured_files'].items():
    path = OLD / 'local-candidate-3' / relative
    assert bind(path) == row
    files[str(path)] = compact(path)
suites = []
for prior in old_local['suites']:
    suite = prior.copy()
    report = OLD / 'local-candidate-3' / ('own-keys/report.json' if suite['name'] == 'own-keys' else suite['name'] + '.json')
    suite.update(report=str(report), pointer=[], before_report_sha256=sha(report))
    suites.append(suite)
local = PREP / 'local-preparation'
suites.append(dict(name='object-is', runner=str(local / 'run.py'), runner_kind='standard',
    fixture=str(local / 'object-is.js'), matrix=str(local / 'runner-matrix.json'),
    report=str(PREP / 'local-before/report.json'), pointer=[], modes=78, controls=60,
    cpu_seconds=30, wall_seconds=120, before_report_sha256=sha(PREP / 'local-before/report.json')))
for path, row in read(local / 'replay-inputs.json')['files'].items():
    assert compact(path) == row
    files[path] = row
for path in [local / 'replay-inputs.json', PREP / 'local-before/execution.json',
    PREP / 'local-before/local.execution.json', PREP / 'local-before/report.json', PREP / 'local-before/start.json',
    PREP / 'local-before/local.stdout.log', PREP / 'local-before/local.stderr.log',
    OLD / 'local-candidate-3/execution.json', OLD / 'replay-preparation/local-inputs.json',
    PREP / 'layout-before-results-review.json', OLD / 'runtime-baseline-publication.json',
    HERE / 'local-replay.py', HERE / 'prepare.py', HERE / 'adapt_drivers.py', HERE / 'driver-adaptations.json']:
    files[str(path)] = compact(path)
policy_rows = []
for suite in suites:
    before = local_module.old.original(suite)
    local_module.old.verify_report(suite, before, BEFORE_BINARY)
    local_module.verify_health(before)
    assert sha(suite['runner']) == before['runner_sha256']
    if 'fixture_sha256' in before:
        assert sha(suite['fixture']) == before['fixture_sha256']
    if suite['matrix']:
        assert sha(suite['matrix']) == before['matrix_sha256']
    for path in [suite['report'], suite['runner'], suite['fixture']] + ([suite['matrix']] if suite['matrix'] else []):
        files[str(path)] = compact(path)
    policy_rows.extend(dict(suite=suite['name'], id=row['id']) for row in before['cases']
        if row.get('expected_observation', row.get('expected', {})).get('status') == 'resource')
for row in baselines.values():
    files[row['path']] = {k: v for k, v in row.items() if k != 'path'}
assert sum(s['modes'] for s in suites) == 1698 and sum(s['controls'] for s in suites) == 544
assert len(policy_rows) == 44
local_counts = dict(suites=10, fixture_modes=1698, controls=544)
save('local-inputs.json', dict(format=1, parent=PARENT,
    before=dict(directory=str(OLD / 'candidate-3'), binary_sha256=BEFORE_BINARY,
        production_input_sha256=read(OLD / 'candidate-3/inputs.json')['input_sha256'],
        observations='All9 latest DataView candidate3 local reports plus original Object.is BEFORE; prior checkpoint observations remain historical.'),
    counts=local_counts, suites=suites, files=dict(sorted(files.items())), baselines_locked=35,
    updated_historical_bindings=updates, reused_unchanged_helpers=old_local['reused_unchanged_helpers'],
    explicit_terminal_policy_rows=policy_rows,
    notes=['All10 original suite runners, fixture bytes, expected observations and guarded controls remain unchanged.',
        'Object.is adds78 fixture modes and60 controls; the four terminal policy modes and two ordinary DOM identity gaps remain visible.',
        'Population-only mode needs no candidate and launches no engine; execution requires all explicit frozen candidate arguments.',
        'Complete changed rows are retained under the original per-suite limits and1200s overall cap; no retry, baseline writes or normalization.']))
save('population-summary.json', dict(schema=1, formal=formal_counts, local=local_counts,
    total_case_modes=21425, total_controls=5108, explicit_terminal_policy_rows=len(policy_rows),
    formal_manifest=bind(HERE / 'formal-inputs.json'), local_manifest=bind(HERE / 'local-inputs.json'),
    candidate=None, engine_execution=False, updated_historical_bindings=updates))
print(json.dumps(read(HERE / 'population-summary.json'), indent=2))
