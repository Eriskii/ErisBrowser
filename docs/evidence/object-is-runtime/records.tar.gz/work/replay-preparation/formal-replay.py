#!/usr/bin/env python3
"""Inert verification by default; one authorized44-profile replay, no baseline writes."""
import argparse
from collections import Counter
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

sys.dont_write_bytecode = True

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def read(path):
    return json.loads(Path(path).read_bytes())

def binding(path):
    p = Path(path)
    return dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))

def verify(row):
    p = Path(row['path'])
    require(p.is_file() and not p.is_symlink(), 'missing/aliased input: ' + str(p))
    require(p.stat().st_size == row['bytes'] and sha(p) == row['sha256'], 'input changed: ' + str(p))

def save(path, data):
    with path.open('x', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=True)
        f.write('\n')

def load(row, name):
    verify(row)
    spec = importlib.util.spec_from_file_location(name, row['path'])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

def interrupted(signum, frame):
    raise KeyboardInterrupt('signal ' + str(signum))

def profile_files(profile):
    corpus = Path(profile['corpus'])
    actual = {str(p) for p in corpus.rglob('*') if p.is_file()}
    require(actual == {r['path'] for r in profile['files']}, profile['name'] + ': corpus file inventory changed')
    for row in profile['files']:
        verify(row)
    verify(profile['before_report'])
    if profile['baseline']:
        verify(profile['baseline'])

def full_changes(helper, name, before, after):
    changes, controls = helper.compare(name, before, after)
    old = {r['id']: r for r in before['cases']}
    new = {r['id']: r for r in after['cases']}
    # Preserve complete records including identity, errors, phases, stderr and reasons.
    rows = [dict(id=r['id'], kind=r['kind'], before=old[r['id']], after=new[r['id']]) for r in changes]
    return rows, controls

def run_profile(helper, command, root, env, out, name, deadline):
    record = dict(command=command, started_monotonic=time.monotonic(),
                  timeout_seconds=min(600, max(0, deadline-time.monotonic())),
                  reap_started=False, leader_reaped=False)
    require(record['timeout_seconds'] > 0, 'overall replay deadline expired')
    process = None
    ownership = {'reap_started': False}
    reaped = False
    try:
        with (out/(name+'.stdout.log')).open('xb') as stdout, (out/(name+'.stderr.log')).open('xb') as stderr:
            process = subprocess.Popen(command, cwd=root, env=env, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, close_fds=True, start_new_session=True, preexec_fn=helper.limits)
            record['pid'] = process.pid
            # Only the bounded timeout is shortened; the reviewed ownership/cleanup helper stays intact.
            helper.DEADLINE_SECONDS = record['timeout_seconds']
            code, observed = helper.wait_unreaped(process, ownership)
            reaped = True
            record.update(returncode=code, exit_observed_without_reaping=observed)
    except BaseException as error:
        record['failure'] = dict(type=type(error).__name__, message=str(error))
    finally:
        if process is not None and not reaped and not ownership['reap_started']:
            try:
                record['cleanup_returncode'] = helper.kill_then_reap(process, ownership)
                reaped = True
            except BaseException as error:
                record['cleanup_failure'] = dict(type=type(error).__name__, message=str(error))
        record.update(reap_started=ownership['reap_started'], leader_reaped=reaped,
                      elapsed_seconds=time.monotonic()-record['started_monotonic'])
        for suffix in ('stdout.log', 'stderr.log', 'json'):
            p = out/(name+'.'+suffix)
            if p.is_file():
                record[suffix.replace('.', '_')] = binding(p)
        save(out/(name+'.execution.json'), record)
    return record

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', type=Path, required=True)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--candidate-directory', type=Path)
    parser.add_argument('--production-input-sha256')
    parser.add_argument('--binary-sha256')
    parser.add_argument('--archive-inputs-sha256')
    parser.add_argument('--output-directory', type=Path)
    parser.add_argument('--execute-authorized', action='store_true')
    args = parser.parse_args()
    require(sha(args.manifest) == args.manifest_sha256, 'manifest hash mismatch')
    manifest = read(args.manifest)
    root = Path(manifest['repository'])
    require(__debug__, 'run with Python assertions enabled')
    supplied = [args.candidate_directory, args.production_input_sha256, args.binary_sha256,
                args.archive_inputs_sha256, args.output_directory]
    require(not any(supplied) or all(supplied), 'supply every candidate argument together')
    require(not args.execute_authorized or all(supplied), 'execution requires explicit candidate bindings')
    out = None
    if any(supplied):
        require(args.candidate_directory.is_absolute() and not args.candidate_directory.is_symlink(), 'explicit non-aliased candidate required')
        require(Path('/tmp') in args.candidate_directory.resolve().parents, 'candidate must be scratch directory')
        require(args.output_directory.is_absolute() and not args.output_directory.exists() and not args.output_directory.is_symlink(), 'output must be fresh')
        out = args.output_directory.resolve()
        protected = [root, args.candidate_directory.resolve(), Path(__file__).resolve().parent]
        require(Path('/tmp') in out.parents and all(out != p and p not in out.parents and out not in p.parents for p in protected),
                'output must be separate scratch directory')
    # Validate source code before importing it; imports never invoke their main functions.
    for row in manifest['static_files']:
        verify(row)
    historical = load(manifest['helpers']['historical'], 'frozen_historical_helper')
    supervisor = load(manifest['helpers']['supervision'], 'frozen_supervision_helper')
    candidate_verifier = load(manifest['candidate_verifier'], 'frozen_candidate_verifier')
    sys.path.insert(0, str(root/'tools'))
    import test262_conformance as runner
    from run import launch_environment
    verify(manifest['contracts'])
    contracts = read(manifest['contracts']['path'])['profiles']
    require(set(runner.PROFILES) == set(contracts) == {r['name'] for r in manifest['profiles']}, 'profile inventory differs')
    require(manifest['counts']['profiles'] == len(manifest['profiles']) == 44, 'profile count differs')
    self_binding = binding(__file__)
    manifest_binding = binding(args.manifest)
    binary_manifest_binding = binding(args.candidate_directory/'default-binaries.json') if any(supplied) else None
    checked_candidate = None
    def candidate_check():
        require(all(supplied), 'candidate bindings missing')
        verify(binary_manifest_binding)
        current = candidate_verifier.verify_candidate(args.candidate_directory,
            args.production_input_sha256, args.binary_sha256, args.archive_inputs_sha256)
        if checked_candidate is not None:
            require(current == checked_candidate, 'compiled candidate artifacts changed')
        return current
    def common_locks():
        verify(self_binding)
        verify(manifest_binding)
        for row in manifest['static_files'] + list(manifest['helpers'].values()) + [manifest['candidate_verifier'],manifest['contracts']]:
            verify(row)
        for profile in manifest['profiles']:
            if profile['baseline']:
                verify(profile['baseline'])
    common_locks()
    checked_candidate = candidate_check() if any(supplied) else None
    for row in manifest['prior_provenance']:
        verify(row)
    for profile in manifest['profiles']:
        profile_files(profile)
        before = read(profile['before_report']['path'])
        historical.verify_static_contract(runner, root, profile['name'], contracts[profile['name']], before)
        full_changes(historical, profile['name'], before, before)
    if not args.execute_authorized:
        print(json.dumps(dict(inert_verified=True, counts=manifest['counts'], candidate=checked_candidate,
                              engine_executed=False, output_created=False), indent=2))
        return 0
    out.mkdir(exist_ok=False)
    env = launch_environment()
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    for name in ('PYTHONOPTIMIZE', 'PYTHONPATH', 'PYTHONHOME'):
        env.pop(name, None)
    # No references to candidate readbacks/expected outcomes enter the engine.
    start = dict(schema=1, manifest=manifest_binding, driver=self_binding,
        candidate=checked_candidate, binary_sha256=args.binary_sha256,
        production_input_sha256=args.production_input_sha256, counts=manifest['counts'],
        limits=manifest['limits']|dict(overall_wall_seconds=3600),
        environment={k:env.get(k) for k in ('TZ','TZDIR','LANG','LC_ALL','LC_TIME','LD_LIBRARY_PATH')},
        retries=False, baseline_writes=False, outcome_normalization=False,
        comparison='Complete historical observations; current35 gates via unchanged runner.check_baseline without re-execution')
    save(out/'start.json', start)
    started = time.monotonic()
    deadline = started+3600
    results, failure, postcheck_failure = [], None, None
    handlers = {}
    try:
        for sig in (signal.SIGINT, signal.SIGTERM):
            handlers[sig] = signal.signal(sig, interrupted)
        for profile in manifest['profiles']:
            name = profile['name']
            common_locks()
            candidate_check()
            profile_files(profile)
            before = read(profile['before_report']['path'])
            historical.verify_static_contract(runner, root, name, contracts[name], before)
            destination = out/(name+'.json')
            command = [sys.executable, str(root/'tools/test262_conformance.py'), '--profile', name,
                '--binary', str(args.candidate_directory/'eris-js'), '--output', str(destination), '--jobs', '4', '--timeout', '3']
            execution = run_profile(supervisor, command, root, env, out, name, deadline)
            require(not execution.get('failure') and execution['leader_reaped'], name+': execution/cleanup failure')
            require(execution['returncode'] in (0,1), name+': infrastructure exit')
            after = read(destination)
            require(after['binary_sha256'] == args.binary_sha256, name+': report binary mismatch')
            changes, controls = full_changes(historical, name, before, after)
            gate = None
            if profile['baseline']:
                current = {k:after[k] for k in ('revision','corpus_manifest_sha256','runner_policy_sha256')}
                current['cases'] = {r['id']:{k:r[k] for k in ('status','case_sha256','source_sha256')} for r in after['cases']}
                losses, gains = runner.check_baseline(read(profile['baseline']['path']), current)
                healthy = after['harness_preflight_passed'] and not any(after['counts'].get(k) for k in runner.BAD_RUN_STATUSES)
                gate = dict(baseline=profile['baseline'], passed=healthy and not losses,
                            healthy=healthy, regressions=losses, improvements=gains)
            common_locks()
            candidate_check()
            profile_files(profile)
            historical.verify_static_contract(runner, root, name, contracts[name], before)
            result = dict(profile=name,before=profile['before_report'],after=binding(destination),execution=binding(out/(name+'.execution.json')),
                cases=len(after['cases']),controls=len(after['harness_preflight']),before_counts=before['counts'],after_counts=after['counts'],
                controls_verified=sum(bool(r['verified']) for r in after['harness_preflight']),
                complete_changed_case_records=changes,complete_changed_control_records=controls,
                unchanged_case_records=len(after['cases'])-len(changes),unchanged_control_records=len(after['harness_preflight'])-len(controls),
                current_baseline_gate=gate)
            save(out/(name+'.comparison.json'),result)
            results.append(result)
            print(name,after['counts'],dict(Counter(r['kind'] for r in changes)),'control_changes',len(controls),'gate',gate['passed'] if gate else None,flush=True)
    except BaseException as error:
        failure = dict(type=type(error).__name__,message=str(error))
    finally:
        try:
            common_locks()
            candidate_check()
            for row in manifest['prior_provenance']:
                verify(row)
            for profile in manifest['profiles']:
                profile_files(profile)
        except BaseException as error:
            postcheck_failure = dict(type=type(error).__name__,message=str(error))
        for sig, old in handlers.items():
            signal.signal(sig, old)
        changes = Counter(r['kind'] for p in results for r in p['complete_changed_case_records'])
        counts = dict(profiles=len(results),cases=sum(p['cases'] for p in results),controls=sum(p['controls'] for p in results),
            improvements=changes['improvement'],regressions=changes['regression'],other_changes=changes['other'],
            control_changes=sum(len(p['complete_changed_control_records']) for p in results),
            baseline_gates_checked=sum(p['current_baseline_gate'] is not None for p in results),
            baseline_gates_passed=sum(bool(p['current_baseline_gate'] and p['current_baseline_gate']['passed']) for p in results))
        record = dict(schema=1,complete=not failure and not postcheck_failure and len(results)==44,
            infrastructure_failure=failure,postcheck_failure=postcheck_failure,elapsed_seconds=time.monotonic()-started,
            counts=counts,profiles=results,manifest=manifest_binding,driver=self_binding,
            binary_sha256=args.binary_sha256,production_input_sha256=args.production_input_sha256,
            baselines_written=False,retries=False,all_inputs_unchanged=postcheck_failure is None)
        save(out/'profiles-comparison.json',record)
    print('TOTAL',record['counts'],'complete',record['complete'],flush=True)
    return 2 if not record['complete'] else int(bool(counts['regressions'] or counts['control_changes'] or counts['baseline_gates_passed'] !=35))

if __name__ == '__main__':
    raise SystemExit(main())
