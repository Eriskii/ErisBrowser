#!/usr/bin/env python3
"""Inspect literal source identities and formatting only; no runtime execution."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUT = Path('/tmp/eris-object-is-runtime-1/implementation-review')
PREP = Path('/tmp/eris-object-is-preparation-1')

def row(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

production = ROOT / 'src/script/object_is.rs'
tests = ROOT / 'src/script/object_is/tests.rs'
fixture = ROOT / 'tests/conformance/object-is-local.js'
draft_path = PREP / 'local-oracle-draft-2.json'
expected = {
    production: 'eba6600264f57a2787c1d9d6ed9c9ded749321dd6740686bb40b36df5d005c30',
    tests: '6b4f338574f266f4c4cef9fa483f46510f93b6634192093d12d2ff2841950660',
    draft_path: '5f38d1e5fb5ece6c1c41b73ba540e75f0c4a7c7bbd24e9b903aff6b34c99caa4',
}
for path, sha in expected.items():
    if row(path)['sha256'] != sha:
        raise SystemExit('held input hash mismatch: ' + str(path))

raw = production.read_bytes()
before = b'1536 + 8 * (9 + 2)'
after = b'1536\n                + 8 * (9 + 2)'
if raw.count(before) != 1:
    raise SystemExit('format reversal anchor is not unique')
reversed_sha = hashlib.sha256(raw.replace(before, after, 1)).hexdigest()
if reversed_sha != 'c0e7e720238172a41a105425c7906875579cc3bed9589047b0cebc8908550a24':
    raise SystemExit('production has changes beyond the reviewed line wrap')

draft = json.loads(draft_path.read_text())
parts = fixture.read_text().split('// CASE ')[1:]
if len(parts) != 39 or len(draft['cases']) != 39:
    raise SystemExit('frozen case inventory differs')
sources = []
ordinary = []
skipped = []
prefixes = []
prerequisites = {'proxy-identity-no-traps', 'bigint-identity-and-number-distinction',
                 'foreign-realm-object-identity'}
policies = {'terminal-repeated-string-comparison', 'terminal-string-budget-not-catchable'}
for i, (part, original) in enumerate(zip(parts, draft['cases'])):
    header, source = part.split('\n', 1)
    name = header.split(' ', 1)[0]
    expected_source = original['source'] + ('\n' if i == len(parts)-1 else '\n\n')
    if name != original['id'] or source != expected_source:
        raise SystemExit('source differs: ' + name)
    sources.append({'id': name, 'source_sha256': original['sha256'],
                    'included_body_sha256': hashlib.sha256(source.encode()).hexdigest()})
    if header.endswith('[resource]') or name in prerequisites or name.startswith('dom-defining-interface-'):
        skipped.append(name)
    else:
        ordinary.append(name)
    if name in policies:
        success = 'assert.sameValue(Object.is(a,b),true);'
        if source.count(success) != 1:
            raise SystemExit('policy success assertion is not unique')
        end = source.index(success) + len(success)
        prefix = source[:end]
        if 'for(var i=0;i<200;i++)' in prefix or 'for(var i=0;i<200;i++)' not in source[end:]:
            raise SystemExit('policy prefix is not before the original loop')
        prefixes.append({'id': name, 'bytes': len(prefix.encode()),
                         'sha256': hashlib.sha256(prefix.encode()).hexdigest(),
                         'modes': ['sloppy', 'strict']})
if len(ordinary) != 32 or len(skipped) != 7 or len(prefixes) != 2:
    raise SystemExit('private subset differs')

text = tests.read_text()
names = re.findall(r'#\[test\]\s*fn ([a-z0-9_]+)\(', text)
if len(names) != 20 or len(set(names)) != 20:
    raise SystemExit('private test inventory differs')
includes = []
for name in re.findall(r'include_str!\("([^"]+)"\)', text):
    target = (tests.parent / name).resolve()
    includes.append(row(target))
paths = [production, tests, ROOT/'src/script.rs', fixture, draft_path,
         OUT/'review.json', OUT/'private-review.md', Path(__file__)]
bindings = [row(path) for path in paths]
result = {
    'schema': 1, 'decision': 'clear for held private tests and formatting-only delta',
    'findings': [], 'bindings': bindings, 'include_bindings': includes,
    'format_only_restored_sha256': reversed_sha, 'test_groups': names,
    'frozen_sources': sources, 'ordinary_ids': ordinary, 'ordinary_modes': 64,
    'private_only_skipped_ids': skipped, 'policy_prefixes': prefixes,
    'full_policy_modes': 4,
    'actions': {'source_data_inspection': True, 'engine_execution': False,
                'compiler_execution': False, 'test_execution': False,
                'repository_edits': False},
    'qualification': 'Private subset is not a corpus exclusion. Original public source/expectation rows remain unchanged. Root owns observed compiler/runtime results.',
}
if bindings != [row(path) for path in paths]:
    raise SystemExit('a bound input changed during inspection')
encoded = (json.dumps(result, indent=2, sort_keys=True)+'\n').encode()
(OUT/'private-review.json').write_bytes(encoded)
print(json.dumps(row(OUT/'private-review.json'), indent=2))
