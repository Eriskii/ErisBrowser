#!/usr/bin/env python3
"""Hash the read-only source review; no compiler, engine or test invocation."""
from pathlib import Path
import hashlib
import json
import subprocess

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUT = Path('/tmp/eris-object-is-runtime-1/implementation-review')
PREP = Path('/tmp/eris-object-is-preparation-1')
PARENT = 'f55911e2fd3ead3f42fa59718016c215b6c4a48f'

def binding(path):
    raw = path.read_bytes()
    return {'path': str(path), 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()}

raw = (ROOT / 'src/script.rs').read_bytes()
restored = raw
changes = [
    (b'mod object_integrity;\nmod object_is;\n', b'mod object_integrity;\n'),
    (b'        self.install_data_view_intrinsics()?;\n        self.install_object_is_intrinsic()?;\n', b'        self.install_data_view_intrinsics()?;\n'),
    (b'        if native.name == "Object.is" {\n            return self.object_is(&args);\n        }\n', b''),
]
for before, after in changes:
    if restored.count(before) != 1:
        raise SystemExit('source restoration anchor is not unique')
    restored = restored.replace(before, after, 1)
parent = subprocess.run(['git', 'show', PARENT + ':src/script.rs'], cwd=ROOT,
                        check=True, capture_output=True).stdout
if restored != parent:
    raise SystemExit('script.rs has changes beyond the three reviewed hooks')

paths = [ROOT / name for name in (
    'src/script/object_is.rs', 'src/script.rs', 'src/js_string.rs',
    'src/script/symbols.rs', 'src/script/machine/calls.rs',
    'src/script/construction.rs', 'src/script/data_view.rs',
)] + [PREP / name for name in (
    'proposal-2.md', 'installer-charge-plan.md', 'layout-installer-charge-review.json',
    'spec/manifest.json', 'spec/sec-object.is.txt', 'spec/sec-samevalue.txt',
    'spec/sec-samevaluenonnumber.txt', 'spec/sec-numeric-types-number-sameValue.txt',
    'spec/sec-ecmascript-standard-built-in-objects.txt',
)] + [OUT / 'review.md', Path(__file__)]
rows = [binding(path) for path in paths]
result = {
    'schema': 1,
    'reviewer': 'html_css',
    'scope': 'Independent source-only Object.is production and narrow integration review',
    'decision': 'clear at the bound source hashes; no concrete finding',
    'findings': [],
    'bindings': rows,
    'script_hook_restoration': {
        'parent': PARENT, 'hooks': 3, 'exact_restoration': True,
        'restored_sha256': hashlib.sha256(restored).hexdigest(),
    },
    'checked': [
        'No-coercion SameValue for all supported Value variants',
        'Number bits/NaNs/signed zeros and exact UTF-16 comparisons',
        'Prepaid strings and iterative Native name/receiver-key work',
        'Top-level-only Native Rc reflexivity and retained implementation key equality',
        'Ignored extra operand values and receiver bypass generic content scan',
        'Installer live counts and every selected search/structural term',
        'Actual-type node/four-slot/fixed literal storage admission',
        'Owner reserve work/storage before reserve and visible publication',
        'Unchanged generic descriptors, constructor exclusion and call cleanup',
    ],
    'limitations': [
        'Private tests not present at production review seal; no private-test clearance is implied.',
        'Logical requested allocation/structural work model; allocator rounding and existing ordinary arena accounting are not redefined.',
        'Known DOM defining-interface representation gaps remain ordinary frozen expectations.',
        'No observed bootstrap budget, pass count, performance, or general host conformance claim.',
        'Two source-read commands named nonexistent ancillary paths; relevant source was subsequently located. No runner, compiler, engine or source mutation resulted.',
    ],
    'actions': {'repository_edits': False, 'engine_execution': False,
                'compiler_execution': False, 'test_execution': False,
                'read_only_git_and_hashing': True},
}
# Detect any bound input changing during capture; report only one coherent read.
if rows != [binding(path) for path in paths]:
    raise SystemExit('a reviewed input changed during capture')
encoded = (json.dumps(result, indent=2, sort_keys=True) + '\n').encode()
(OUT / 'review.json').write_bytes(encoded)
print(json.dumps({'review': binding(OUT / 'review.json'),
                  'production': rows[0], 'hooks': rows[1]}, indent=2))
