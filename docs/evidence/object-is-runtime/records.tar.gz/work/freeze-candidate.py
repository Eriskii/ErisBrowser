import argparse, hashlib, json, re, subprocess, tarfile
from pathlib import Path

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
parser=argparse.ArgumentParser()
parser.add_argument('--name', default='candidate-1')
args=parser.parse_args()
assert re.fullmatch(r'candidate-[1-9][0-9]*',args.name)
OUT = Path(__file__).resolve().parent / args.name
OUT.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
def save(name, obj):
    with (OUT / name).open('x') as f:
        json.dump(obj, f, indent=2); f.write('\n')
def record(p):
    return dict(path=str(p.relative_to(ROOT)), sha256=sha(p))

production = sorted({ROOT/'Cargo.toml', ROOT/'Cargo.lock', *(ROOT/'src').rglob('*.rs'),
    *(p for d in ('assets','examples') for p in (ROOT/d).rglob('*') if p.is_file())})
digest = hashlib.sha256()
for path in production:
    digest.update(str(path.relative_to(ROOT)).encode()); digest.update(b'\0')
    digest.update(path.read_bytes()); digest.update(b'\0')
save('inputs.json', dict(input_sha256=digest.hexdigest(), files=[record(p) for p in production]))

core = {p for p in (ROOT/'crates/raster-core').rglob('*')
    if p.is_file() and 'target' not in p.relative_to(ROOT/'crates/raster-core').parts}
verification = {*ROOT.glob('tests/*.rs'), *(ROOT/'tools').glob('*.py'),
    *(p for d in ('tests/fixtures','tests/reftests') for p in (ROOT/d).rglob('*') if p.is_file())}
included = set()
pattern = re.compile(r'\binclude_(?:str|bytes)!\s*\(\s*"([^"\n]+)"\s*,?\s*\)')
for source in [*production, *core, *verification]:
    if source.suffix != '.rs': continue
    text = source.read_text(); matches = list(pattern.finditer(text))
    assert len(matches) == len(re.findall(r'\binclude_(?:str|bytes)!', text)), source
    for m in matches:
        path = (source.parent/m[1]).resolve()
        assert path.is_file() and path.is_relative_to(ROOT), path
        included.add(path)
verification |= included | core
save('verification-inputs.json', [record(p) for p in sorted(verification)])
save('literal-includes.json', [record(p) for p in sorted(included)])
archive_paths = sorted(set(production) | verification)
assert sum(p.stat().st_size for p in archive_paths) < 64*1024**2
save('archive-inputs.json', dict(files=[dict(record(p),bytes=p.stat().st_size) for p in archive_paths]))
with tarfile.open(OUT/'source.tar', 'w') as t:
    for p in archive_paths:
        assert not p.is_symlink(), p
        t.add(p, arcname=str(p.relative_to(ROOT)), recursive=False)
save('provenance.json', dict(parent=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
    source_tar_sha256=sha(OUT/'source.tar'), inputs_sha256=sha(OUT/'inputs.json'),
    verification_inputs_sha256=sha(OUT/'verification-inputs.json'),
    phase='frozen source snapshot before candidate release build; all prior focused validation attempts retained separately',
    production_inventory='legacy Cargo/src/assets/examples digest for existing replay contract',
    additional_inputs='core and all literal test dependencies independently bound in verification-inputs.json',
    production_files=len(production), verification_files=len(verification), archive_files=len(archive_paths)))
print(json.dumps(dict(directory=str(OUT), input_sha256=digest.hexdigest(), archive_files=len(archive_paths),
    archive_bytes=(OUT/'source.tar').stat().st_size)))
