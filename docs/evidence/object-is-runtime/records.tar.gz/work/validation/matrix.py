"""Run the required root validation matrix once against a held source snapshot."""
import hashlib,json,os,subprocess,sys
from pathlib import Path
out=Path(__file__).resolve().parent
toolchain=sys.argv[1]
assert toolchain in ('1.88.0','1.98.0')
tag='188' if toolchain=='1.88.0' else '198'
attempt=sys.argv[2]
assert attempt.isdecimal() and int(attempt)>=1
for label,feature,action,tail in [
    ('full-default','-','test',['--','--include-ignored']),
    ('full-native','vulkan-raster','test',['--','--include-ignored']),
    ('clippy-default','-','clippy',['--all-targets','--','-D','warnings']),
    ('clippy-presenter','vulkan-presenter','clippy',['--all-targets','--','-D','warnings']),
    ('clippy-native','vulkan-raster','clippy',['--all-targets','--','-D','warnings']),
]:
    subprocess.run([sys.executable,str(out/'check.py'),label+'-'+tag+'-'+attempt,toolchain,'Cargo.toml',feature,action,*tail],check=True)
if tag=='188':
    env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
    command=['cargo','+'+toolchain,'fmt','--all','--','--check']
    log=out/('format-188-'+attempt+'.log')
    with log.open('xb') as f:result=subprocess.run(command,env=env,stdout=f,stderr=subprocess.STDOUT)
    record=dict(command=command,exit=result.returncode,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    with (out/('format-188-'+attempt+'.json')).open('x') as f:json.dump(record,f,indent=2);f.write('\n')
    print(record,flush=True)
    raise SystemExit(result.returncode)
