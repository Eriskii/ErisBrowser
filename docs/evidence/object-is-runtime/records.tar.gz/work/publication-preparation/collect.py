#!/usr/bin/env python3
"""Data-only inventory/snapshot collection; never imports or runs pack.py."""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
WORK = Path('/tmp/eris-object-is-runtime-1')
OUT = WORK/'publication-preparation'
PREP = Path('/tmp/eris-object-is-preparation-1')
PARENT = '9eddd040fd141a8669e67fecc580527527708fa1'
OVERLAYS = {'src/script.rs', 'src/script/object_is.rs', 'src/script/object_is/tests.rs',
            'tests/fixtures/object-is.html', 'tests/pipeline.rs', 'tests/worker.rs'}
rows, external, prep_references = {}, {}, []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def raw_file(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink() and path.stat().st_size <= 40*1024**2, path
    return path.read_bytes()

def binding(path):
    raw = raw_file(path)
    return dict(path=str(path), bytes=len(raw), sha256=sha(raw))

def save(name, value):
    path = OUT/name
    raw = (json.dumps(value, indent=2)+'\n').encode()
    with path.open('xb') as stream:
        stream.write(raw)
    return binding(path)

def retained(path, member=None, expected=None):
    path = Path(path)
    origin = str(path)
    if origin in rows:
        if expected:
            assert rows[origin]['sha256'] == expected['sha256'] and rows[origin]['bytes'] == expected['bytes']
        return rows[origin]['member']
    raw = raw_file(path)
    if expected and (len(raw) != expected['bytes'] or sha(raw) != expected['sha256']):
        assert path.is_relative_to(ROOT), ('changed nonrepository input', path)
        raw = subprocess.run(['git','show',PARENT+':'+str(path.relative_to(ROOT))],cwd=ROOT,
                             check=True,capture_output=True).stdout
    if expected:
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], path
    if raw.startswith(b'\x7fELF') or path.name == 'source.tar':
        external[origin] = dict(path=origin, bytes=len(raw), sha256=sha(raw))
        return None
    if member is None:
        if path.is_relative_to(WORK): member = 'work/'+str(path.relative_to(WORK))
        elif path.is_relative_to(ROOT): member = 'repository/'+str(path.relative_to(ROOT))
        else:
            assert path.is_relative_to('/tmp'), path
            member = 'scratch/'+str(path.relative_to('/tmp'))
    # Verify USTAR path representability without writing an archive.
    tarfile.TarInfo(member).tobuf(tarfile.USTAR_FORMAT)
    if path.is_relative_to(ROOT):
        snapshot = OUT/'repository-inputs'/path.relative_to(ROOT)
        snapshot.parent.mkdir(parents=True, exist_ok=True)
        if snapshot.exists(): assert snapshot.read_bytes() == raw
        else: snapshot.write_bytes(raw)
        path = snapshot
    rows[origin] = dict(path=str(path), original_path=origin, bytes=len(raw), sha256=sha(raw), member=member)
    return member

archive_path = ROOT/'docs/evidence/object-is-preparation/records.tar.gz'
external[str(archive_path)] = binding(archive_path)
prep_content = {}
with tarfile.open(archive_path, 'r:gz') as archive:
    for item in archive:
        assert item.isfile() and item.size <= 40*1024**2
        raw = archive.extractfile(item).read()
        prep_content.setdefault((len(raw), sha(raw)), []).append(item.name)

def replay_input(path, expected):
    path = Path(path)
    if path.is_relative_to(PREP):
        raw = raw_file(path)
        assert len(raw) == expected['bytes'] and sha(raw) == expected['sha256'], path
        matches = prep_content.get((len(raw), sha(raw)))
        assert matches, ('sealed preparation input absent from public archive', path)
        prep_references.append(dict(original_path=str(path), bytes=len(raw), sha256=sha(raw),
                                    archive_member=matches[0]))
        return
    retained(path, expected=expected)

parent_tree = {}
for record in subprocess.check_output(['git','ls-tree','-r','-z',PARENT],cwd=ROOT).split(b'\0'):
    if record:
        meta,name=record.split(b'\t',1)
        parent_tree[name.decode()] = meta.split()[2].decode()
candidates=[]
for number in (1,2):
    directory=WORK/('candidate-'+str(number)); stage='candidate'+str(number)
    roles={}
    names=[('inputs.json','inputs'),('archive-inputs.json','archive_inputs'),
           ('verification-inputs.json','verification_inputs'),('provenance.json','provenance'),
           ('literal-includes.json','literal_includes')]
    if number==2: names += [('default-binaries.json','binaries'),('build-bindings.json','build_bindings')]
    for name,role in names: roles[role]=retained(directory/name)
    inventory={r['path']:r for r in json.loads((directory/'archive-inputs.json').read_text())['files']}
    seen=set(); overlays={}
    with tarfile.open(directory/'source.tar','r:') as archive:
        for entry in archive:
            assert entry.isfile() and entry.name in inventory and entry.name not in seen
            assert entry.size <= 16*1024**2
            seen.add(entry.name); raw=archive.extractfile(entry).read(); row=inventory[entry.name]
            assert len(raw)==row['bytes'] and sha(raw)==row['sha256']
            oid=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
            if parent_tree.get(entry.name)!=oid:
                assert entry.name in OVERLAYS
                snapshot=OUT/(stage+'-overlays')/entry.name
                snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(raw)
                overlays[entry.name]=retained(snapshot,stage+'/overlays/'+entry.name)
    assert seen==set(inventory) and len(seen)==418 and set(overlays)==OVERLAYS
    candidates.append(dict(name=stage,input_sha256=json.loads((directory/'inputs.json').read_text())['input_sha256'],
                           roles=roles,overlays=overlays,source_tar=binding(directory/'source.tar'),
                           binaries=[binding(directory/name) for name in ('eris-js','eris-browser')] if number==2 else [],
                           build_status='release-built' if number==2 else 'compiler-failed-before-engine'))

trees=[]
for kind in ('formal','local'):
    directory=WORK/(kind+'-candidate-2')
    members=[retained(path) for path in sorted(directory.rglob('*')) if path.is_file()]
    trees.append(dict(kind=kind,directory=str(directory),members=members))
for dirname in ('replay-preparation','implementation-review','validation'):
    for path in sorted((WORK/dirname).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts: retained(path)
for name in ['freeze-candidate.py','plan.json','browser-fixture-ready.json','preparation-publication.json',
             'preparation-ci-1.json','preparation-ci-2.json','root-replay-preparation-review.json',
             'layout-installer-source-review.json','format-attempt-1.log','format-attempt-2.log',
             'source-ready.json','visibility-correction.json','local-candidate-inert.log',
             'formal-candidate-inert.log','formal-candidate-2-driver.log','local-candidate-2-driver.log']:
    retained(WORK/name)

formal=json.loads((WORK/'replay-preparation/formal-inputs.json').read_text())
for profile in formal['profiles']:
    replay_input(profile['before_report']['path'],profile['before_report'])
    if profile['baseline']: replay_input(profile['baseline']['path'],profile['baseline'])
for row in list(formal['helpers'].values())+[formal['candidate_verifier']]+formal['static_files']:
    replay_input(row['path'],row)
local=json.loads((WORK/'replay-preparation/local-inputs.json').read_text())
for path,expected in local['files'].items(): replay_input(path,expected)
for suite in local['suites']:
    path=Path(suite['report']);replay_input(path,dict(bytes=path.stat().st_size,sha256=suite['before_report_sha256']))
retained(ROOT/'docs/evidence/object-is-preparation/index.json')
retained(OUT/'prepare-packer.py');retained(OUT/'packer-adaptation.json');retained(Path(__file__))
retained(OUT/'collection-read-errors.json')

observations={
 'candidate1': {'status':'compiler-failed-before-engine','compiler_error':'E0624: two parent-called child methods lacked pub(super)',
                'engine_executions':0,'external_replays':'not-executed','binaries':'not-built'},
 'candidate2': {'status':'runtime-validation-and-replays-complete; final publication review pending',
   'correction':'Exactly two pub(super) modifiers; all oracle/test/quota bytes unchanged',
   'rust':{'1.88.0':{'default':1338,'native':1455},'1.98.0':{'default':1338,'native':1455},'focused_private_groups':20,'clippy_checks':6},
   'formal':{'profiles':44,'cases':19727,'controls':4564,'pass_gains':42,'pass_losses':0,'old_gates_passed':35,
             'object_is':{'passed':42,'controls_verified':80}},
   'local':{'suites':10,'cases':1698,'controls':544,'object_is':{'passed':64,'failed':8,'unsupported':2,'resource':4,
             'expectations_matched':68,'cases':78,'controls_verified':60}},
   'explicit_terminal_policy_rows_all_locals':44,
   'qualification':'Raw local failures, unsupported modes and terminal outcomes remain visible; no all-local-pass or custom-browser-goal-complete claim.'}}
attempts=[]
def attempt(name,kind,status,paths):
    attempts.append(dict(id=name,kind=kind,disposition=status,artifacts=[retained(WORK/p) for p in paths]))
attempt('formatter-1','tool-launch','failed before rustfmt: rustup temporary directory read-only',['format-attempt-1.log'])
attempt('formatter-2','formatting','successful explicit pinned formatter path',['format-attempt-2.log'])
for path in sorted((WORK/'validation').glob('*.json')):
    if path.name=='final-summary.json':continue
    value=json.loads(path.read_text())
    if 'command' in value and 'exit' in value:
        attempt(path.stem,'compiler-or-validation',f"recorded exit {value['exit']}",['validation/'+path.name,'validation/'+value['log']])
attempt('formal-candidate2','external-replay','complete observations, not all cases passed',
        ['formal-candidate-2/profiles-comparison.json','formal-candidate-2-driver.log'])
attempt('local-candidate2','external-replay','complete observations, retained raw failures/exclusions/terminal rows',
        ['local-candidate-2/execution.json','local-candidate-2/comparison.json','local-candidate-2-driver.log'])
attempt('private-review-capture-initial','data-only-review','stopped on concurrent authorized visibility correction',
        ['implementation-review/private-capture-initial-stop.json','implementation-review/capture-private-initial.py'])
attempts_row=save('attempt-inventory.template.json',dict(schema=1,state='awaiting-final-publication-attempts-and-review',attempts=attempts,
    pending=['root acceptance','baseline projection and audit','final documentation review','packer review','root sequencing release']))
fixed=dict(schema=1,parent=PARENT,candidates=candidates,candidate_observations=observations,complete_trees=trees,
           payloads=sorted(rows.values(),key=lambda row:row['member']),external_bindings=list(external.values()),
           external_provenance={'preparation_archive':binding(archive_path),'referenced_preparation_inputs':prep_references,
                                'formal_corpus':'All original profile source/helper/proof identities remain in the frozen manifest and pinned public parent; corpus bytes are not duplicated.'})
fixed_row=save('fixed-inputs.json',fixed)
template=dict(schema=1,state='awaiting-final-acceptance-baseline-docs-and-review',parent=PARENT,fixed_inventory=fixed_row,
    candidates=candidates,candidate_observations=observations,additional_payloads=[],external_bindings=[],
    external_replays={'candidate1':'not-executed','candidate2':'completed'},
    visibility_correction_member='work/visibility-correction.json',attempt_inventory_member=None,
    reviews={role:None for role in ['runtime','replays','validation','packer','documentation','root_acceptance','baseline_publication']},
    final_publication_observations=None)
template_row=save('release-manifest.template.json',template)
receipt=dict(schema=1,scope='Data-only collection; packer not imported or executed',fixed_inventory=fixed_row,
             manifest_template=template_row,attempt_template=attempts_row,payload_count=len(rows),
             payload_bytes=sum(r['bytes'] for r in rows.values()),complete_trees=[{'kind':t['kind'],'files':len(t['members'])} for t in trees],
             candidate_archive_members=[418,418],overlays_per_candidate=6,external_preparation_inputs=len(prep_references),
             engine_or_compiler_runs=0,public_writes=False)
save('collection-receipt.json',receipt)
print(json.dumps(receipt,indent=2))
