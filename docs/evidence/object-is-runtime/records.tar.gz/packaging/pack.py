#!/usr/bin/env python3
"""Inert evidence packaging: explicit root sequencing release, scratch output only.

Never executes a compiler, engine, replay or validator. Git reads reconstruct
archived source members. User authorization already exists; the separate receipt
is an internal evidence-sequencing guard, not a user approval request.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORK = Path('/tmp/eris-object-is-runtime-1')
REPOSITORY = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
PARENT = '9eddd040fd141a8669e67fecc580527527708fa1'
OVERLAYS = {'src/script.rs', 'src/script/object_is.rs', 'src/script/object_is/tests.rs',
            'tests/fixtures/object-is.html', 'tests/pipeline.rs', 'tests/worker.rs'}
MAX_FILE = 40 * 1024**2
MAX_PAYLOAD = 512 * 1024**2
MAX_FILES = 4096
REVIEW_ROLES = {'runtime', 'replays', 'validation', 'packer', 'documentation',
                'root_acceptance', 'baseline_publication'}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def read_bound(row):
    path = Path(row['path'])
    require(path.is_absolute() and path.is_file() and not path.is_symlink(),
            f'not a regular absolute input: {path}')
    require(0 <= row['bytes'] <= MAX_FILE, f'input byte bound: {path}')
    require(path.stat().st_size == row['bytes'], f'input size changed: {path}')
    with path.open('rb') as stream:
        raw = stream.read(MAX_FILE + 1)
    require(len(raw) == row['bytes'] and digest(raw) == row['sha256'],
            f'input hash changed: {path}')
    return raw


def bound_path(path, expected_sha):
    path = Path(path)
    row = dict(path=str(path), bytes=path.stat().st_size, sha256=expected_sha)
    return row, read_bound(row)


def member_name(value):
    name = PurePosixPath(value)
    require(not name.is_absolute() and name.parts and str(name) == value
            and all(p not in ('.', '..') for p in name.parts), f'unsafe member: {value}')
    return value


def json_bytes(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def check_tree(tree, records):
    directory = Path(tree['directory'])
    require(directory.is_absolute() and directory.is_dir() and not directory.is_symlink(), 'missing result tree')
    actual = set()
    for path in directory.rglob('*'):
        require(not path.is_symlink(), f'result symlink: {path}')
        if path.is_file():
            actual.add(str(path))
            require(len(actual) <= MAX_FILES, 'result tree count')
    expected = {records[member]['path'] for member in tree['members']}
    require(len(expected) == len(tree['members']) and expected == actual,
            f'result tree missing or extra file: {directory}')


def candidate_check(spec, payloads):
    """Check all 418 source members and only the six explicitly retained overlays."""
    stage = spec['name']
    require(stage in ('candidate1', 'candidate2'), 'unknown candidate')
    roles = spec['roles']
    required = {'inputs', 'archive_inputs', 'verification_inputs', 'provenance', 'literal_includes'}
    if stage == 'candidate2':
        required |= {'binaries', 'build_bindings'}
    require(set(roles) == required and all(member in payloads for member in roles.values()), 'candidate roles')
    def value(role):
        return json.loads(payloads[roles[role]]['raw'])
    inputs, provenance = value('inputs'), value('provenance')
    require(inputs['input_sha256'] == spec['input_sha256'] and provenance['parent'] == PARENT,
            'candidate source identity')
    for key, role in [('inputs_sha256', 'inputs'), ('verification_inputs_sha256', 'verification_inputs')]:
        require(provenance[key] == digest(payloads[roles[role]]['raw']), 'input provenance')
    raw_tar = read_bound(spec['source_tar'])
    require(provenance['source_tar_sha256'] == digest(raw_tar), 'source archive provenance')
    inventory = value('archive_inputs')['files']
    expected = {member_name(row['path']): row for row in inventory}
    require(len(inventory) == len(expected) == 418 and provenance['archive_files'] == 418, 'archive inventory')
    parent_tree = {}
    for line in subprocess.check_output(['git', 'ls-tree', '-r', '-z', PARENT], cwd=REPOSITORY).split(b'\0'):
        if line:
            meta, name = line.split(b'\t', 1)
            mode, kind, oid = meta.split()
            if kind == b'blob' and mode in (b'100644', b'100755'):
                parent_tree[name.decode()] = oid.decode()
    require(set(spec['overlays']) == OVERLAYS, 'six source overlays required')
    seen, changed = set(), set()
    with tarfile.open(fileobj=io.BytesIO(raw_tar), mode='r:') as archive:
        for entry in archive:
            name = member_name(entry.name)
            require(entry.isfile() and name in expected and name not in seen, 'archive member type/name/duplicate')
            require(0 <= entry.size <= 16 * 1024**2, 'archive member size')
            raw = archive.extractfile(entry).read()
            require(len(raw) == expected[name]['bytes'] and digest(raw) == expected[name]['sha256'], 'archive member bytes')
            seen.add(name)
            oid = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
            if parent_tree.get(name) != oid:
                changed.add(name)
                require(name in spec['overlays'] and payloads[spec['overlays'][name]]['raw'] == raw, 'unretained source change')
    require(seen == set(expected) and changed == OVERLAYS, 'parent plus overlays reconstruction')
    if stage == 'candidate1':
        require(spec['binaries'] == [] and spec['build_status'] == 'compiler-failed-before-engine', 'candidate1 binary claim')
        directory = Path(spec['source_tar']['path']).parent
        require(not (directory/'default-binaries.json').exists() and not (directory/'build-bindings.json').exists(), 'unexpected candidate1 build record')
    else:
        binary_map, build = value('binaries'), value('build_bindings')
        require({Path(row['path']).name for row in spec['binaries']} == set(binary_map) == {'eris-js', 'eris-browser'}, 'binary inventory')
        require(build['binaries'] == binary_map and build['all_source_inputs_unchanged'] is True
                and build['source_archive_sha256'] == digest(raw_tar)
                and build['archive_inventory_sha256'] == digest(payloads[roles['archive_inputs']]['raw']), 'build binding')
        for binary in spec['binaries']:
            require(binary['sha256'] == binary_map[Path(binary['path']).name], 'binary digest')
            read_bound(binary)
    return dict(name=stage, parent=PARENT, input_sha256=spec['input_sha256'],
                source_tar=spec['source_tar'], binaries=spec['binaries'], build_status=spec['build_status'],
                archive_members=len(seen), overlays=spec['overlays'],
                reconstruction='Exact member names/content from parent plus six overlays; original tar header encoding is separately hash-bound.')


def check_visibility(candidates, payloads, correction_member):
    old, new = candidates
    def inventory(spec):
        return {row['path']: row for row in json.loads(payloads[spec['roles']['archive_inputs']]['raw'])['files']}
    before, after = inventory(old), inventory(new)
    changed = {path for path in before if before[path] != after[path]}
    name = 'src/script/object_is.rs'
    require(set(before) == set(after) and changed == {name}, 'candidate2 must change only object_is.rs')
    old_raw = payloads[old['overlays'][name]]['raw']
    new_raw = payloads[new['overlays'][name]]['raw']
    restored = new_raw
    for method in (b'install_object_is_intrinsic', b'object_is'):
        anchor = b'pub(super) fn ' + method + b'('
        require(restored.count(anchor) == 1, 'visibility anchor')
        restored = restored.replace(anchor, b'fn ' + method + b'(', 1)
    require(restored == old_raw, 'candidate2 has a non-visibility delta')
    correction = json.loads(payloads[correction_member]['raw'])
    require(correction['before_sha256'] == digest(old_raw) and correction['after_sha256'] == digest(new_raw)
            and correction['engine_executions'] == 0, 'correction receipt mismatch')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--manifest', required=True, type=Path)
    parser.add_argument('--manifest-sha256', required=True)
    parser.add_argument('--authorization', required=True, type=Path)
    parser.add_argument('--authorization-sha256', required=True)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--execute-packaging', required=True, action='store_true')
    args = parser.parse_args()
    manifest_row, manifest_raw = bound_path(args.manifest, args.manifest_sha256)
    release_row, release_raw = bound_path(args.authorization, args.authorization_sha256)
    manifest, release = json.loads(manifest_raw), json.loads(release_raw)
    # Capture once, then use these same bytes for authorization and the payload.
    packer_row, packer_raw = bound_path(Path(__file__).resolve(), release['packer_sha256'])
    require(manifest['schema'] == 1 and manifest['state'] == 'ready-for-packaging'
            and manifest['parent'] == PARENT, 'pending or wrong manifest')
    require(release['state'] == 'root-sequencing-release'
            and release['manifest_sha256'] == args.manifest_sha256
            and release['packer_sha256'] == digest(packer_raw), 'exact root sequencing release required')
    output = args.output
    require(output.is_absolute() and output.parent.resolve() == WORK
            and output.name.startswith('runtime-publication-package-') and not output.exists(), 'fresh scratch output required')
    fixed_raw = read_bound(manifest['fixed_inventory'])
    fixed = json.loads(fixed_raw)
    require(fixed['parent'] == PARENT and manifest['candidates'] == fixed['candidates'], 'candidate bindings changed')
    require(manifest['candidate_observations'] == fixed['candidate_observations'], 'candidate history changed')
    rows = fixed['payloads'] + manifest['additional_payloads']
    require(0 < len(rows) <= MAX_FILES, 'payload count')
    records, payloads, total = {}, {}, 0
    for row in rows:
        member = member_name(row['member'])
        require(member not in records and not member.startswith('packaging/'), 'duplicate/reserved member')
        raw = read_bound(row)
        require(not raw.startswith(b'\x7fELF') and not row['path'].endswith('/source.tar'), 'no binary/source archive payload')
        total += len(raw)
        require(total <= MAX_PAYLOAD, 'payload aggregate')
        records[member], payloads[member] = row, dict(raw=raw)
    trees = fixed['complete_trees']
    require(len(trees) == 2 and {tree['kind'] for tree in trees} == {'formal', 'local'}, 'two final result trees required')
    for tree in trees:
        require(tree['directory'] == str(WORK/(tree['kind']+'-candidate-2')), 'unexpected result tree')
        check_tree(tree, records)
    require(manifest['external_replays'] == {'candidate1': 'not-executed', 'candidate2': 'completed'}, 'replay attribution')
    require(not (WORK/'formal-candidate-1').exists() and not (WORK/'local-candidate-1').exists(), 'unexpected candidate1 results')
    require([spec['name'] for spec in manifest['candidates']] == ['candidate1', 'candidate2'], 'two ordered candidates required')
    candidates = [candidate_check(spec, payloads) for spec in manifest['candidates']]
    check_visibility(manifest['candidates'], payloads, manifest['visibility_correction_member'])
    require(set(manifest['reviews']) == REVIEW_ROLES and set(release['accepted_reviews']) == REVIEW_ROLES, 'required review roles')
    for role, member in manifest['reviews'].items():
        require(member in records and release['accepted_reviews'][role] == records[member]['sha256'], 'unreleased review: '+role)
    attempt_member = manifest['attempt_inventory_member']
    require(attempt_member in records and release['attempt_inventory_sha256'] == records[attempt_member]['sha256'], 'unreleased attempt inventory')
    attempts = json.loads(payloads[attempt_member]['raw'])
    require(attempts['state'] == 'complete-and-reviewed' and attempts['attempts'], 'incomplete attempts')
    for attempt in attempts['attempts']:
        require(attempt['artifacts'] and all(member in records for member in attempt['artifacts']), 'attempt artifact missing')
    require(isinstance(manifest['final_publication_observations'], dict) and manifest['final_publication_observations'], 'final publication observations required')
    external = fixed['external_bindings'] + manifest['external_bindings']
    for row in external:
        read_bound(row)
    for member, raw, origin in (
        ('packaging/manifest.json', manifest_raw, manifest_row),
        ('packaging/authorization.json', release_raw, release_row),
        ('packaging/fixed-inventory.json', fixed_raw, manifest['fixed_inventory']),
        ('packaging/pack.py', packer_raw, packer_row),
    ):
        total += len(raw)
        require(total <= MAX_PAYLOAD, 'metadata aggregate')
        payloads[member] = dict(raw=raw)
        records[member] = dict(origin, member=member, stage='packaging', role='sequencing')
    output.mkdir()
    archive_path = output/'records.tar.gz'
    with archive_path.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(mode='w', fileobj=zipped, format=tarfile.USTAR_FORMAT) as archive:
                for name in sorted(payloads):
                    raw = payloads[name]['raw']
                    info = tarfile.TarInfo(name)
                    info.size, info.mode, info.mtime = len(raw), 0o644, 0
                    archive.addfile(info, io.BytesIO(raw))
    for row in rows + external + [manifest_row, release_row, packer_row, manifest['fixed_inventory']]:
        read_bound(row)
    for tree in trees:
        check_tree(tree, records)
    for spec in manifest['candidates']:
        read_bound(spec['source_tar'])
        for binary in spec['binaries']:
            read_bound(binary)
    index = dict(schema=1, scope='Object.is runtime evidence; failed compile and final observations remain distinct',
                 parent=PARENT, archive=dict(path='records.tar.gz', bytes=archive_path.stat().st_size,
                                            sha256=digest(archive_path.read_bytes())),
                 payload_count=len(records), payload_bytes=total, payloads=[records[key] for key in sorted(records)],
                 candidates=candidates, candidate_observations=manifest['candidate_observations'],
                 external_replays=manifest['external_replays'], reviews=manifest['reviews'],
                 external_bindings=external, external_provenance=fixed['external_provenance'],
                 visibility_correction_member=manifest['visibility_correction_member'],
                 final_publication_observations=manifest['final_publication_observations'],
                 authority='Reviewed summaries are supplied explicitly; this packer checks byte bindings and source reconstruction without running or reinterpreting tests.',
                 omissions=['ELF binaries and duplicate source.tar bytes; source members reconstruct from parent plus overlays.',
                            'Already published preparation remains external provenance; no general completion, all-local-pass or performance claim.'])
    with (output/'index.json').open('xb') as stream:
        stream.write(json_bytes(index))
    print(json.dumps(dict(output=str(output), index_sha256=digest((output/'index.json').read_bytes()),
                          payload_count=len(records), payload_bytes=total)))


if __name__ == '__main__':
    main()
