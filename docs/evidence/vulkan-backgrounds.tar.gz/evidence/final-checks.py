from pathlib import Path
import subprocess, sys
root = Path(__file__).resolve().parent
def check(label, version, manifest, features, action, *tail):
    subprocess.run([sys.executable, str(root/'run-check.py'), label, version, manifest, features, action, *tail], check=True)
def tool(label, *args):
    subprocess.run([sys.executable, str(root/'run-tool.py'), label, *args], check=True)
if sys.argv[1] == 'native':
    check('native-clippy-188-1','1.88.0','Cargo.toml','vulkan-raster','clippy','--all-targets','--','-D','warnings')
    check('core-gpu-tests-188-1','1.88.0','crates/raster-core/Cargo.toml','gpu','test','--','--include-ignored','--test-threads=4')
    check('core-clippy-188-1','1.88.0','crates/raster-core/Cargo.toml','gpu','clippy','--all-targets','--','-D','warnings')
    check('probe-tests-188-1','1.88.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','test','--','--include-ignored')
    check('candidate-browser-build-1','1.88.0','Cargo.toml','vulkan-raster','build','--bin','eris-browser')
    check('candidate-probe-build-1','1.88.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','build','--bin','eris-vulkan-background-check')
else:
    check('default-clippy-198-1','1.98.0','Cargo.toml','-','clippy','--all-targets','--','-D','warnings')
    check('native-clippy-198-1','1.98.0','Cargo.toml','vulkan-raster','clippy','--all-targets','--','-D','warnings')
    check('core-clippy-198-1','1.98.0','crates/raster-core/Cargo.toml','gpu','clippy','--all-targets','--','-D','warnings')
    check('probe-tests-198-1','1.98.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','test','--','--include-ignored')
    check('probe-clippy-198-1','1.98.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','clippy','--all-targets','--','-D','warnings')
    env=['env','CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.98.0','fmt']
    tool('format-check-1',*env,'--all','--','--check')
    tool('probe-format-check-1',*env,'--manifest-path','tools/vulkan-raster-probe/Cargo.toml','--','--check')
    tool('core-format-check-1',*env,'--manifest-path','crates/raster-core/Cargo.toml','--','--check')
