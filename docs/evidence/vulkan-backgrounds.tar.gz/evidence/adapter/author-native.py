from pathlib import Path
n=Path('/tmp/eris-native-backgrounds-1');w=n/'worktree';p=w/'src/graphics/raster_bridge/native.rs';s=p.read_text()
s=s.replace('    MAX_MASK_COVERAGE_BYTES, MAX_NATIVE_PHASES, MAX_ROW_ENTRIES, PARAM_STRIDE, Phase, Profile,\n','    BackgroundImageGeometry, MAX_MASK_COVERAGE_BYTES, MAX_NATIVE_PHASES, MAX_ROW_ENTRIES, PARAM_STRIDE, Phase, Profile,\n',1)
old='''                DrawCommand::BackgroundImage { .. } => {
                    return Err(at(FallbackKind::UnsupportedBackgroundImage, phase, index));
                }
'''
new='''                DrawCommand::BackgroundImage { rect, tile, radius, key, .. } => {
                    if !bounded_scalar(*radius) {
                        return Err(at(FallbackKind::InvalidGeometry, phase, index));
                    }
                    // Rounded coverage is not separable into X/Y lookup tables.
                    // Refuse even missing/offscreen/suppressed commands before
                    // any image table, font mask or source payload preparation.
                    if *radius != 0.0 {
                        return Err(at(FallbackKind::UnsupportedBackgroundImage, phase, index));
                    }
                    validate_rect(convert_rect(*rect), location).map_err(leaf)?;
                    validate_rect(convert_rect(*tile), location).map_err(leaf)?;
                    if tile.width <= 0.0 || tile.height <= 0.0 {
                        return Err(at(FallbackKind::InvalidGeometry, phase, index));
                    }
                    add_key(
                        key.len(),
                        &mut counts.command_key_bytes,
                        MAX_COMMAND_KEY_BYTES,
                        location,
                    ).map_err(leaf)?;
                    counts.image_commands += 1;
                }
'''
assert s.count(old)==1;s=s.replace(old,new)
old='''                    | DrawCommand::Image { .. }
                    | DrawCommand::LinearGradient { .. }'''
assert s.count(old)==2;s=s.replace(old,'''                    | DrawCommand::Image { .. }
                    | DrawCommand::BackgroundImage { .. }
                    | DrawCommand::LinearGradient { .. }''')
old='''                DrawCommand::BackgroundImage { .. } => {
                    unreachable!("preflight refused background images")
                }
'''
assert s.count(old)==2
geometry='''                DrawCommand::BackgroundImage { rect, tile, repeat, .. } => {
                    let geometry = BackgroundImageGeometry::new(
                        target, convert_rect(*rect), convert_rect(*tile), *repeat, &state,
                    ).map_err(|_| at(FallbackKind::InvalidGeometry, phase, index))?;
                    // Preserve Canvas's full candidate tariff and prepay the
                    // extra per-axis LUT work before source packing. Missing,
                    // transparent and suppressed sources keep this conservative
                    // upper bound even if no actual LUT is later emitted.
                    total = total.checked_add(geometry.loop_work)
                        .and_then(|work| work.checked_add(geometry.lut_work))
                        .ok_or_else(|| at(FallbackKind::CpuPaintBudget, phase, index))?;
                    continue;
                }
'''
s=s.replace(old,geometry,1)
lowering='''                DrawCommand::BackgroundImage { rect, tile, repeat, .. } => {
                    let Some(source) = source_image else {
                        continue;
                    };
                    // Core applies the current phase/fixed offset once. Keep
                    // the raw tile phase, separate from the paint outline.
                    Command::BackgroundImage {
                        rect: convert_rect(*rect),
                        tile: convert_rect(*tile),
                        repeat: *repeat,
                        source,
                    }
                }
'''
s=s.replace(old,lowering,1)
old='''            if let DrawCommand::Image { key, .. } = command {'''
new='''            if let DrawCommand::Image { key, .. } | DrawCommand::BackgroundImage { key, .. } = command {'''
assert s.count(old)==1;s=s.replace(old,new)
old='''        (1, size_of::<OpaqueGradient<'_>>()),'''
new='''        (1, size_of::<OpaqueGradient<'_>>()),
        // Background geometry is stack metadata, never a generated raster.
        // Bound both return-value/caller copies during the charged prepass.
        (2, size_of::<BackgroundImageGeometry>()),'''
assert s.count(old)==1;s=s.replace(old,new)
s+='\n#[cfg(test)]\nmod background_image_tests;\n';p.write_text(s)
t=w/'src/graphics/raster_bridge/native/background_image_tests.rs';t.write_bytes((n/'adapter/tests-before/background_image_tests.rs').read_bytes())
p=w/'src/graphics/raster_bridge/background_image_tests.rs';s=p.read_text()
anchor='fn assert_three_refuse(commands: &[DrawCommand], images: &ImageStore, index: usize) {'
helper='''// The two Probe routes still reject every BackgroundImage. Native now
// admits square corners, so preserve these whole-frame refusal witnesses with
// an explicit rounded clone; original Probe inputs and Canvas literals stay exact.
fn rounded_native(commands: &[DrawCommand]) -> Vec<DrawCommand> {
    commands.iter().cloned().map(|mut command| {
        if let DrawCommand::BackgroundImage { radius, .. } = &mut command {
            *radius = 1.0;
        }
        command
    }).collect()
}

'''
assert s.count(anchor)==1;s=s.replace(anchor,helper+anchor,1)
# First three-route helper: only Native receives rounded clone.
pos=s.index(anchor);end=s.index('\n#[test]',pos);part=s[pos:end]
old='''            &[native::NativePhase { frame, commands }],''';new='''            &[native::NativePhase { frame, commands: &rounded_native(commands) }],'''
assert part.count(old)==1;part=part.replace(old,new);s=s[:pos]+part+s[end:]
# Explicit hidden phase witness remains a structural rounded refusal.
old='''            commands: &hidden,
''';new='''            commands: &rounded_native(&hidden),
''';assert s.count(old)==1;s=s.replace(old,new)
# Text/cold preparation Native must also receive explicit rounded variant.
pos=s.index('fn background_image_fonts_and_native_refuse_before_preceding_text_materializes()');end=s.index('\n#[test]',pos);part=s[pos:end]
old='''                commands: &commands
''';new='''                commands: &rounded_native(&commands)
''';assert part.count(old)==1;part=part.replace(old,new);s=s[:pos]+part+s[end:]
# A square background now reaches the unchanged native store-cap guard.
pos=s.index('    // Native already checks all command structure before the image table guard.')
end=s.index('\n}\n',pos);part=s[pos:end]
part=part.replace('''    // Native already checks all command structure before the image table guard.''','''    // Native still checks command structure first. This valid square background
    // now reaches the unchanged image-table capacity guard.''')
old='''            kind: FallbackKind::UnsupportedBackgroundImage,
            phase_index: Some(0),
            command_index: Some(0)''';new='''            kind: FallbackKind::ImageStoreLimit,
            phase_index: None,
            command_index: None''';assert part.count(old)==1;part=part.replace(old,new);s=s[:pos]+part+s[end:]
p.write_text(s)
