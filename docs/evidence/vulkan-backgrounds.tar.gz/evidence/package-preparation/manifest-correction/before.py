#!/usr/bin/env python3
"""Root-only publisher for explicitly selected Native tiled-image evidence."""
from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
Q = Path('/tmp/eris-native-background-plan-1')
BASE = '05ab192cdd022b68a3ce63beadfc5774c7c8df13'
STEM = 'vulkan-backgrounds'
LIMIT = 64 * 1024 * 1024
PREPARATION_TREES = {'core', 'adapter', 'root', 'fixtures', 'docs', 'package-preparation'}

def require(value, message):
    if not value: raise ValueError(message)

def sha(data): return hashlib.sha256(data).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def binding(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and path == path.resolve(), 'canonical regular file required')
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'symlink input')
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(row):
    require(binding(row['path']) == row, 'changed input: ' + row['path'])
    return Path(row['path']).read_bytes()

def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])
def relative(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and path.as_posix() == name, 'relative path')
    return name

def rust_totals(log, expected):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    actual = {'rows': len(rows), 'passed': sum(int(r[1]) for r in rows),
              'failed': sum(int(r[2]) for r in rows), 'ignored': sum(int(r[3]) for r in rows)}
    require(actual == expected, 'raw Rust totals')
    require(all(r[0] == ('ok' if r[2] == '0' else 'FAILED') for r in rows), 'Rust result labels')

def cargo_command(argv):
    if argv and argv[0] == 'env':
        index = 1
        while index < len(argv) and re.fullmatch(r'[A-Za-z_][A-Za-z_0-9]*=.*', argv[index]): index += 1
        argv = argv[index:]
    require(argv and argv[0] == 'cargo', 'cargo check command')
    return argv

def verify_staged():
    out = W / 'docs/evidence'; summary_path = out / (STEM + '.json')
    summary = json.loads(read(binding(summary_path)))
    require(summary['base'] == BASE and git(W, 'rev-parse', 'HEAD').decode().strip() == BASE, 'staged parent')
    archive = summary['archive']; archive_path = out / archive['path']
    require(archive['path'] == STEM + '.tar.gz', 'archive basename')
    row = binding(archive_path)
    require((row['bytes'], row['sha256']) == (archive['bytes'], archive['sha256']), 'staged archive binding')
    published = dict(summary['published'])
    for path in (summary_path, archive_path):
        current = binding(path); published[path.relative_to(W).as_posix()] = {key: current[key] for key in ('bytes', 'sha256')}
    staged = set(git(W, 'diff', '--cached', '--name-only', '-z').decode().split('\0')) - {''}
    require(staged == set(published), 'exact staged publication roster')
    changed = set((git(W, 'diff', 'HEAD', '--name-only', '-z') + git(W, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')) - {''}
    require(changed == staged, 'no unstaged or unlisted publication paths')
    for name, expected in published.items():
        name = relative(name); live = binding(W / name); indexed = git(W, 'show', ':' + name)
        require({key: live[key] for key in ('bytes', 'sha256')} == expected, 'staged/live binding: ' + name)
        require(len(indexed) == expected['bytes'] and sha(indexed) == expected['sha256'], 'index bytes: ' + name)
    print(json.dumps({'status': 'clear', 'staged_files': len(staged), 'archive': archive}, indent=2))

def main():
    selected = binding(sys.argv[1]); selection = json.loads(read(selected))
    require(git(W, 'rev-parse', 'HEAD').decode().strip() == BASE, 'worktree base')
    source = selection['live_source']; inventory = json.loads(read(source))
    require(inventory['base'] == BASE and len(inventory['source_sha256']) == selection['source_count'] and selection['source_count'] > 0, 'source identity/population')
    for name, digest in inventory['source_sha256'].items():
        require(binding(W / relative(name))['sha256'] == digest, 'live source changed: ' + name)
    changed = set((git(W, 'diff', 'HEAD', '--name-only', '-z') + git(W, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')) - {''}
    require(changed == set(selection['published']), 'exact changed/publication roster')
    for name, row in selection['published'].items():
        require(row['path'] == str(W / relative(name)), 'published path')
        read(row)
        if not name.endswith('.md'):
            require(inventory['source_sha256'].get(name) == row['sha256'], 'unbound changed runtime input')
    verified = [source]; receipts = {}; logs = {}
    for label, item in selection['checks'].items():
        receipt = json.loads(read(item['receipt'])); raw = read(item['log'])
        require(receipt['command'] == item['command'] and receipt['exit'] == item['expected_exit'], 'check argv/exit: ' + label)
        require(receipt['sha256'] == sha(raw), 'log hash: ' + label)
        require(str(Path(item['receipt']['path']).parent / receipt['log']) == item['log']['path'], 'receipt log path')
        verified.extend([item['receipt'], item['log']]); receipts[label] = receipt; logs[label] = raw.decode()
        if 'source' in item: read(item['source']); verified.append(item['source'])
        if 'rust' in item: rust_totals(logs[label], item['rust'])
    # Preserve every actual failed attempt in the bounded flat validation directory.
    validation_paths = list((P / 'validation').glob('*.json'))
    require(len(validation_paths) <= 512, 'validation receipt population')
    failures = set()
    for path in validation_paths:
        row = binding(path); attempt = json.loads(read(row))
        if 'command' in attempt and 'exit' in attempt and attempt['exit'] != 0: failures.add(str(path))
    included_failures = {item['receipt']['path'] for item in selection['checks'].values() if item['expected_exit'] != 0}
    require(failures == included_failures, 'complete failed-attempt retention')
    require(set(selection['full_suites']) == {'native', 'default'}, 'both full suites required')
    for role, label in selection['full_suites'].items():
        item = selection['checks'][label]; result = item['rust']
        require(receipts[label]['exit'] == 0 and result['rows'] > 0 and result['passed'] > 0 and result['failed'] == result['ignored'] == 0, 'complete successful suite')
        require(item['source'] == source, 'suite/final source join')
        argv = cargo_command(receipts[label]['command'])
        require(argv[2] == 'test' and '--locked' in argv and '--offline' in argv, 'full suite operation/locking')
        require(argv[argv.index('--manifest-path') + 1] == 'Cargo.toml', 'full root suite manifest')
        require('--include-ignored' in argv and not any(a.startswith('--skip') for a in argv), 'full suite ignored coverage/no skips')
        require(argv == selection['suite_commands'][role], 'root-selected exact suite configuration')
        if role == 'native': require('--features' in argv and argv[argv.index('--features') + 1] == 'vulkan-raster', 'native suite feature')
        else: require('--features' not in argv, 'default suite features')
    require({'native_clippy', 'default_clippy', 'format', 'probe', 'core'} <= set(selection['final_checks']), 'final strict checks')
    for role, labels in selection['final_checks'].items():
        require(isinstance(labels, list) and labels, 'nonempty final check role')
        for label in labels:
            item = selection['checks'][label]
            require(receipts[label]['exit'] == 0 and item['source'] == source, 'final successful source check: ' + role)
            if role not in ('native_clippy', 'default_clippy', 'format', 'probe'): continue
            argv = cargo_command(receipts[label]['command'])
            if role.endswith('_clippy'):
                require(argv[2] == 'clippy' and '--all-targets' in argv and argv[-3:] == ['--', '-D', 'warnings'], 'strict all-target clippy')
                require(argv[argv.index('--manifest-path') + 1] == 'Cargo.toml', 'root clippy manifest')
                if role == 'native_clippy': require('--features' in argv and argv[argv.index('--features') + 1] == 'vulkan-raster', 'native clippy feature')
                else: require(argv[1] == '+1.98.0' and '--features' not in argv, 'default clippy toolchain/features')
            elif role == 'format': require(argv[2] == 'fmt' and '--check' in argv, 'format check')
            else:
                require(argv[2] in ('test', 'check', 'clippy') and argv[argv.index('--manifest-path') + 1] == 'tools/vulkan-raster-probe/Cargo.toml', 'probe seam manifest/operation')
                require('--features' in argv and argv[argv.index('--features') + 1] == 'browser-bridge', 'probe browser seam feature')
                if argv[2] == 'clippy':
                    require('--all-targets' in argv and argv[-3:] == ['--', '-D', 'warnings'], 'strict all-target probe clippy')
                elif argv[2] == 'test':
                    result = item.get('rust', {})
                    require(result.get('rows', 0) > 0 and result.get('passed', 0) > 0 and result.get('failed') == result.get('ignored') == 0, 'complete successful probe tests')
                    require('--include-ignored' in argv and not any(a.startswith('--skip') for a in argv), 'probe ignored coverage/no skips')
    probe_operations = {cargo_command(receipts[label]['command'])[2] for label in selection['final_checks']['probe']}
    require({'test', 'clippy'} <= probe_operations, 'probe tests and strict clippy required')
    core_operations = set()
    for label in selection['final_checks']['core']:
        item = selection['checks'][label]; argv = cargo_command(receipts[label]['command'])
        require(argv[argv.index('--manifest-path') + 1] == 'crates/raster-core/Cargo.toml', 'standalone core manifest')
        require('--features' in argv and argv[argv.index('--features') + 1] == 'gpu', 'core GPU feature')
        require('--locked' in argv and '--offline' in argv, 'locked core dependencies')
        core_operations.add(argv[2])
        if argv[2] == 'test':
            result = item['rust']
            require(result['rows'] > 0 and result['passed'] > 0 and result['failed'] == result['ignored'] == 0, 'successful standalone core tests')
            require('--include-ignored' in argv and not any(a.startswith('--skip') for a in argv), 'core ignored coverage/no skips')
        else:
            require(argv[2] == 'clippy' and '--all-targets' in argv and argv[-3:] == ['--', '-D', 'warnings'], 'strict standalone core clippy')
    require(core_operations == {'test', 'clippy'}, 'standalone core tests and lint required')
    item = selection['browser']; record = json.loads(read(item['record']))
    require(binding(record['path']) == {key: record[key] for key in ('path', 'bytes', 'sha256')}, 'immutable browser bytes')
    require((record['source'], record['source_sha256']) == (source['path'], source['sha256']), 'browser/source join')
    build = selection['checks'][item['build']]; strip = selection['checks'][item['strip']]
    require(record['build_receipt'] == build['receipt']['path'] and record['strip_receipt'] == strip['receipt']['path'], 'browser receipt joins')
    require(build['source'] == strip['source'] == source, 'build/source joins')
    require(cargo_command(receipts[item['build']]['command']) == ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser'], 'browser build command')
    require(receipts[item['strip']]['command'] == ['strip', '--strip-debug', record['path']], 'browser strip command')
    require(receipts[item['build']]['exit'] == receipts[item['strip']]['exit'] == 0, 'successful browser preparation')
    verified.append(item['record'])
    for label in selection.get('browser_checks', []):
        require(receipts[label]['exit'] == 0 and selection['checks'][label]['source'] == source, 'CLI final source/result')
        require(record['path'] in receipts[label]['command'], 'CLI immutable browser argument')

    gpu = selection['gpu']; probe = json.loads(read(gpu['record']))
    require(binding(probe['path']) == {key: probe[key] for key in ('path', 'bytes', 'sha256')}, 'immutable GPU checker')
    require((probe['source'], probe['source_sha256']) == (source['path'], source['sha256']), 'GPU checker/source join')
    for role in ('build', 'strip'):
        item = selection['checks'][gpu[role]]
        require(item['source'] == source and item['expected_exit'] == 0 and probe[role + '_receipt'] == item['receipt']['path'], 'GPU checker preparation joins')
    require(cargo_command(receipts[gpu['build']]['command']) == ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path', 'tools/vulkan-raster-probe/Cargo.toml', '--features', 'browser-bridge', '--bin', 'eris-vulkan-background-check'], 'GPU checker build command')
    require(receipts[gpu['strip']]['command'] == ['strip', '--strip-debug', probe['path']], 'GPU checker strip command')
    oracle = json.loads(read(gpu['oracles']))
    require(oracle['status'] == 'frozen-before-candidate-execution' and oracle['fixture_count'] == 6 and oracle['pixels'] == 222, 'independent literal roster')
    require(oracle['frames_per_adapter'] == 12 and oracle['compared_bytes_per_adapter'] == 1776, 'literal frame/byte totals')
    palette = {key: bytes.fromhex(value) + b'\xff' for key, value in oracle['palette'].items()}
    fixtures = {}
    for fixture in oracle['fixtures']:
        name = fixture['name']; width = fixture['width']; height = fixture['height']
        require(name not in fixtures and width > 0 and height > 0, 'distinct valid GPU fixture')
        require(len(fixture['rows']) == height and all(len(row) == width for row in fixture['rows']), 'literal dimensions')
        literal = b''.join(palette[pixel] for row in fixture['rows'] for pixel in row)
        require(read(fixture['rgba']) == literal, 'literal rows/RGBA join')
        fixtures[name] = len(literal); verified.append(fixture['rgba'])
    require(len(fixtures) == 6 and sum(fixtures.values()) == 888, 'exact GPU literal population')
    prefix = gpu['prefix']
    require(len(prefix) == 2 and prefix[0] == 'env' and prefix[1].startswith('LD_LIBRARY_PATH=/nix/store/'), 'selected Vulkan loader prefix')
    listing = gpu['list']; item = selection['checks'][listing]
    require(item['source'] == source and item['expected_exit'] == 0 and item['command'] == prefix + [probe['path'], '--list'], 'GPU enumeration source/command')
    identities = [line for line in logs[listing].splitlines() if line.startswith('ADAPTER ')]
    ids = [int(re.match(r'ADAPTER (\d+) ', line).group(1)) for line in identities]
    require(len(ids) == len(set(ids)) == 3 and len(gpu['adapters']) == 3, 'three enumerated adapters')
    seen_adapters = set()
    for run in gpu['adapters']:
        label = run['check']; adapter = run['adapter']; item = selection['checks'][label]
        require(adapter in ids and adapter not in seen_adapters, 'distinct enumerated GPU adapter'); seen_adapters.add(adapter)
        require(item['source'] == source and item['expected_exit'] == 0 and item['command'] == prefix + [probe['path'], '--adapter', str(adapter)], 'GPU execution source/command')
        lines = logs[label].splitlines()
        require([line for line in lines if line.startswith('ADAPTER ')] == identities, 'GPU driver/identity join')
        found = set()
        for line in [line for line in lines if line.startswith('PASS ')]:
            match = re.fullmatch(r'PASS (\S+) format=(Bgra8Unorm|Rgba8Unorm) draws=(\d+) compared_bytes=(\d+) exact=true reference=literal canvas=true bounded_background_lut=true', line)
            require(match is not None, 'exact GPU PASS shape')
            name, fmt, draws, compared = match.groups(); key = (name, fmt)
            require(name in fixtures and key not in found and int(draws) > 0 and int(compared) == fixtures[name], 'GPU fixture bytes/uniqueness'); found.add(key)
        require(found == {(name, fmt) for name in fixtures for fmt in ('Bgra8Unorm', 'Rgba8Unorm')}, 'complete GPU comparison roster')
        require([line for line in lines if line.startswith('COMPLETE ')] == [f'COMPLETE adapter={adapter} fixtures=6 frames=12 compared_bytes=1776 exact=true bounded_background_lut=true custom_image_shader=true offscreen=true acquired_surface=false'], 'exact GPU completion')
    verified.extend([gpu['record'], gpu['oracles']])

    report_item = selection['reftests']; report = json.loads(read(report_item['report'])); manifest = json.loads(read(report_item['manifest']))
    require(report['suite'] == 'eris-self-authored-reftests' and report['conformance_claim'] is False, 'reference scope')
    require((report['passed'], report['failed'], report['total']) == (76, 0, 76), 'final references')
    require(len(manifest['cases']) == 76 and [r['name'] for r in report['cases']] == [r['name'] for r in manifest['cases']], 'reference roster')
    require(len({r['name'] for r in report['cases']}) == 76, 'duplicate references')
    require(all(r['status'] == 'pass' and r['different_pixels'] == r['maximum_channel_error'] == 0 for r in report['cases']), 'reference pixels')
    require(report['viewport'] == {'width': manifest['width'], 'height': manifest['height']}, 'reference viewport')
    require(report_item['manifest']['path'] == str(W / 'tests/reftests/manifest.json'), 'reference manifest path')
    previous = json.loads(git(W, 'show', BASE + ':tests/reftests/manifest.json'))
    require(manifest == previous and len(previous['cases']) == 76, 'all parent reference definitions/metadata unchanged')
    require(inventory['source_sha256']['tests/reftests/manifest.json'] == report_item['manifest']['sha256'], 'manifest/source join')
    parent_files = set(git(W, 'ls-tree', '-r', '--name-only', '-z', BASE, '--', 'tests/reftests').decode().split('\0')) - {''}
    for name in parent_files:
        if not name.endswith('.md'):
            require(binding(W / relative(name))['sha256'] == sha(git(W, 'show', BASE + ':' + name)), 'parent reference body/asset changed: ' + name)
    argv = receipts[report_item['check']]['command']
    require(argv == ['python3', str(W / 'tools/reftest.py'), '--binary', record['path'], '--output-dir', str(Path(report_item['report']['path']).parent)], 'reference command/binary/output')
    require(report['binary'] == record['path'] and receipts[report_item['check']]['exit'] == 0 and selection['checks'][report_item['check']]['source'] == source, 'reference selected binary/source')
    verified.extend([report_item['report'], report_item['manifest']])
    ci = selection['parent_ci']; ci_log = json.loads(logs[ci])
    require(receipts[ci]['exit'] == 0 and receipts[ci]['command'][:3] == ['gh', 'run', 'view'], 'parent CI receipt')
    require(receipts[ci]['command'][receipts[ci]['command'].index('--repo') + 1] == 'Eriskii/ErisBrowser', 'parent CI repository')
    require(ci_log['headSha'] == BASE and ci_log['status'] in ('queued', 'in_progress', 'completed'), 'parent CI identity/status')
    require(ci_log['conclusion'] is None or isinstance(ci_log['conclusion'], str), 'parent CI observed conclusion')
    require({'documentation', 'core', 'adapter', 'pages', 'fixtures'} <= set(selection['reviews']), 'foundation peers')
    for name, row in selection['reviews'].items():
        review = json.loads(read(row)); require(review['status'].startswith('clear'), 'review conclusion: ' + name); verified.append(row)
    docs = json.loads(read(selection['reviews']['documentation'])); reviewed = {r['relative']: r['sha256'] for r in docs['published_files']}
    require(all(reviewed.get(name) == row['sha256'] for name, row in selection['published'].items() if name.endswith('.md')), 'complete documentation review coverage')
    require(isinstance(selection['reftest_archive_dirs'], list), 'explicit reference attempt directories')
    require(all(relative(name) == name and '/' not in name and name.startswith('reftests-') for name in selection['reftest_archive_dirs']), 'bounded reference directory names')
    require(Path(report_item['report']['path']).parent.name in selection['reftest_archive_dirs'] and Path(report_item['report']['path']).parent.parent == P, 'selected report archive directory')
    members = {}
    def add(row):
        path = Path(row['path']); require(row['bytes'] <= 8 * 1024 * 1024, 'archive member limit')
        require(not any(x in ('.git', '__pycache__', 'target') or x.startswith('target-') for x in path.parts), 'excluded archive tree')
        data = read(row); require(not data.startswith((b'\x7fELF', b'\x1f\x8b', b'PK\x03\x04', b'BZh', b'\xfd7zXZ')) and data[257:262] != b'ustar', 'ELF or recursive archive')
        require(not path.name.lower().endswith(('.tar', '.tgz', '.gz', '.zip', '.bz2', '.xz', '.7z')), 'recursive archive suffix')
        if path.is_relative_to(W):
            local = path.relative_to(W).as_posix()
            require(local in selection['published'], 'unselected worktree archive input')
            name = 'worktree/' + local
        elif path.is_relative_to(P):
            local = path.relative_to(P)
            require(len(local.parts) == 1 or local.parts[0] in PREPARATION_TREES | {'validation'} or local.parts[0] in selection['reftest_archive_dirs'], 'unlisted evidence tree')
            name = 'evidence/' + local.as_posix()
        elif path.is_relative_to(Q):
            local = path.relative_to(Q)
            require(len(local.parts) == 1, 'unlisted preparation subtree')
            name = 'preparation/' + local.as_posix()
        else: raise ValueError('unlisted archive root')
        require(name not in members or members[name] == data, 'archive collision'); members[name] = data
    add(selected); add(binding(__file__)); add(binding(P / 'package-design.json'))
    for row in verified + selection['archive_inputs'] + list(selection['published'].values()): add(row)
    require(set(selection['holds']) == {'core', 'adapter', 'pages', 'fixtures'}, 'foundation source hold roles')
    for role, rows in selection['holds'].items():
        require(isinstance(rows, list) and rows, 'nonempty held source role: ' + role)
        for row in rows: add(row)
    members['MANIFEST.json'] = encoded({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())})
    require(sum(map(len, members.values())) <= LIMIT, 'aggregate archive payload cap')
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o644; tar.addfile(info, io.BytesIO(data))
    archive = stream.getvalue(); require(len(archive) <= LIMIT, 'compressed archive cap')
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        require(len(tar.getnames()) == len(members) and set(tar.getnames()) == set(members), 'archive member roster')
        for member in tar: require(member.isfile() and tar.extractfile(member).read() == members[member.name], 'archive readback')
    out = W / 'docs/evidence'; require(out.is_dir() and out == out.resolve(), 'canonical output directory')
    for suffix in ('.json', '.tar.gz'): require(not (out / (STEM + suffix)).exists(), 'exclusive publication output')
    with (out / (STEM + '.tar.gz')).open('xb') as handle: handle.write(archive)
    require((out / (STEM + '.tar.gz')).read_bytes() == archive, 'disk archive readback')
    summary = {**selection['summary'], 'base': BASE, 'source': source, 'source_count': len(inventory['source_sha256']),
               'browser': record, 'gpu': gpu, 'checks': selection['checks'], 'reftests': report_item, 'parent_ci': ci,
               'published': {name: {key: row[key] for key in ('bytes', 'sha256')} for name, row in selection['published'].items()},
               'archive': {'path': STEM + '.tar.gz', 'bytes': len(archive), 'sha256': sha(archive), 'members': len(members)}}
    with (out / (STEM + '.json')).open('xb') as handle: handle.write(encoded(summary))
    print(json.dumps({'archive': summary['archive'], 'published_files': len(selection['published']), 'checks': len(receipts)}, indent=2))

if __name__ == '__main__':
    require(len(sys.argv) == 2, 'usage: package.py SELECTION.json | --verify-staged')
    verify_staged() if sys.argv[1] == '--verify-staged' else main()
