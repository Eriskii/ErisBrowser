import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
HERE=Path(__file__).resolve().parent
binary=Path(sys.argv[1]).resolve(); output=Path(sys.argv[2])
fixtures=HERE/'worktree/tests/fixtures'
specs=[('processing-instruction.js','46f6909fa212fa4dc2fc3fe63ea0ccf64af6871d30fd1ed41b98ae15d067dc73','piFollowupCases',[
'constructor_arity_defaults_and_call','factory_brand_arity_and_required_data','xml_name_valid_targets','xml_name_invalid_targets','xml_name_unicode_boundaries','data_terminator_and_literal_storage','genuine_node_identity_and_data','conversions_then_alternate_prototype','validation_follows_conversions_and_prototype','conversion_abrupt_identity','prototype_abrupt_precedes_validation','factory_conversion_order_and_abrupt_identity']),
('processing-instruction-accessors.js','7348d015b56903ed9e75f4191a2c6ff03def35b542c031fc68ed42e09accb502','piAccessorCases',[
'descriptors_and_placement','scalar_data_and_setter_defaults','authentic_brands_before_conversion','setter_callback_order_and_abrupt_identity','own_shadows_and_readonly_assignments','prototype_replacement_deletion_and_saved_getters','pi_setter_clone_and_html_serialization'])]
inputs=[]
for file,sha,obj,names in specs:
 source=(fixtures/file).read_bytes(); assert hashlib.sha256(source).hexdigest()==sha
 for name in names:
  inputs.append((file,name,source+b'\nif ('+f'{obj}.{name}()'.encode()+b' !== true) throw new Error("case did not return true");',sha))
file='processing-instruction-authentic-constructor-override.js'; source=(fixtures/file).read_bytes(); sha=hashlib.sha256(source).hexdigest(); assert sha=='a0dcbd8d5de85cc7a28b25f9f511f1f00582be20dbc139fc489937d891d7ba33'
inputs.append((file,'authentic_constructor_override',b'if (('+source+b') !== true) throw new Error("case did not return true");',sha))
records=[]
for file,name,source,sha in inputs:
 for mode in ('sloppy','strict'):
  case=dict(id=name+'#'+mode,file=file,mode=mode,source=source,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=[])
  case['case_sha256']=runner.case_fingerprint(case)
  record=runner.run_case(case,binary,3)
  record.update(fixture_sha256=sha,source_sha256=hashlib.sha256(source).hexdigest(),expected_observation=dict(status='complete',phase='runtime'))
  record['matches_expectation']=all(record.get('observation',{}).get(k)==v for k,v in record['expected_observation'].items())
  records.append(record)
result=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=records)
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(total=len(records),matched=sum(r['matches_expectation'] for r in records),unmet=[dict(id=r['id'],observation=r['observation']) for r in records if not r['matches_expectation']]),indent=2))
