import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
HERE=Path(__file__).resolve().parent
binary=Path(sys.argv[1]).resolve(); output=Path(sys.argv[2]); prep=HERE/'independent-preparation'
source=(prep/'cases.js').read_bytes();fixture_sha=hashlib.sha256(source).hexdigest();assert fixture_sha=='dde6c7970bd18b49565a5f78990eb47b659dbad65a549855f724478646f6fc7f'
draft=json.loads((prep/'source-ready.json').read_text()); inputs=[]
for name in draft['ordinary_case_names']:
 body=source+b'\nif(characterDataCases.'+name.encode()+b'() !== true) throw new Error("case did not return true");'
 inputs.append((name,body,fixture_sha,None))
policy=(prep/'policy-inputs.json').read_bytes();policy_sha=hashlib.sha256(policy).hexdigest();assert policy_sha=='1c328f0b7d2750f6f60ae8633e82294b18fd6f521b212c696bc665b2faaf3952'
for row in json.loads(policy)['cases']:
 body=row['source'].encode();assert hashlib.sha256(body).hexdigest()==row['sha256']
 expected=''.join(chr(92)+'u%04x'%unit for unit in row['standard_final_utf16'])
 body+=('\nif(n.data !== "'+expected+'") throw new Error("standard final DOM data");').encode()
 inputs.append((row['id'],body,policy_sha,row['standard_final_utf16']))
records=[]
for name,body,sha,units in inputs:
 for mode in ('sloppy','strict'):
  case=dict(id=name+'#'+mode,file='cases.js' if units is None else 'policy-inputs.json',mode=mode,source=body,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=[])
  case['case_sha256']=runner.case_fingerprint(case); r=runner.run_case(case,binary,3)
  r.update(source_sha256=hashlib.sha256(body).hexdigest(),fixture_sha256=sha,expected_observation=dict(status='complete',phase='runtime'),standard_final_utf16=units)
  r['matches_expectation']=all(r['observation'].get(k)==v for k,v in r['expected_observation'].items())
  if units is not None:r['matches_implementation_policy']=r['observation'].get('status')=='unsupported' and r['observation'].get('phase')=='runtime'
  records.append(r)
result=dict(binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),cases=records)
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(total=len(records),matched=sum(r['matches_expectation'] for r in records),policy_matched=sum(r.get('matches_implementation_policy',False) for r in records),unmet=[dict(id=r['id'],observation=r['observation']) for r in records if not r['matches_expectation']]),indent=2))
