# Five CharacterData methods: bounded implementation plan

Read-only plan against the current PI candidate; no source edits or execution. Coordinate independent semantic cases in `proposal.md` / `cases.js` from html_css. Add substringData, appendData, insertData, deleteData and replaceData to the represented Text/Comment/PI family. The existing checked `Document::replace_character_data(id, String)` is sufficient: no new DOM publication API is required for correctness.

## Contract and reuse

Check authentic node kind/ID and required arity before conversions. Numeric arguments convert left-to-right using paid `Runtime::number_value`, then existing `to_i32(number) as u32`; this already implements truncation/modulo rather than ToIndex. Convert data with `string_hint` after the numeric arguments. Every parameter is required; lengths are 2/1/2/2/3. Explicit undefined still converts. Data null becomes "null"; the data attribute's LegacyNullToEmptyString is not inherited by methods. Read current data after all callbacks; append obtains its offset then. Offset greater than current UTF16 length throws IndexSizeError; clamp count by `min(count, length-offset)` without overflowing offset+count. [DOM CharacterData](https://dom.spec.whatwg.org/#interface-characterdata), [Web IDL operations](https://webidl.spec.whatwg.org/#es-operations), [unsigned long](https://webidl.spec.whatwg.org/#es-unsigned-long).

`dom_exception` currently lacks IndexSizeError's legacy code: add the one name→1 mapping. Reuse its authentic exception object and thrown-error identity. Do not claim the still-incomplete DOMException constant inventory is repaired. Numeric conversion already preserves symbols' TypeError and callback effects; do not use `Value::number` directly or reconvert an argument.

## Exact substring without a whole-node copy

Use a borrowed `old.encode_utf16()` iterator after conversions. First skip exactly offset units, paying a fixed bounded step before each reached `next`; EOF before offset gives IndexSizeError. Then count up to count units or EOF, also paying per reached step. This obtains the exact output size without scanning the remainder of a large node or allocating a temporary string. An offset at end with zero count returns empty normally.

Check MAX_STRING on that selected result only. Prepay the bounded second skip/take traversal, Vec writes and Rc copy; charge `64 + 4*selected_units`, fallibly reserve that exact Vec capacity, fill it from a recreated iterator and convert once to JsString. The selected code units may include an isolated surrogate and must survive unchanged. Avoid `pi_dom_string(old)` or UTF8 substring slicing; both would impose the wrong representation boundary. Existing JsString::slice is lossless but allocates, so cannot substitute for admission.

A conservative per-step scan debit must cover one UTF8 decode (at most four bytes), UTF16 iterator transition and loop decision. Keep it explicit in the new helper. Second-pass work uses checked offset+selected length, not the potentially huge original count. This lets a small prefix substring of a node larger than MAX_STRING succeed under normal work limits and makes a meaningful regression without increasing a test budget.

## Mutation: validate the completed UTF16 splice

After all conversions, borrow current old data; pay a linear scan to determine its UTF16 length. Resolve bounds, then define a fresh allocation-free iterator:

`old.encode_utf16().take(offset)` → `inserted.units().iter().copied()` → `old.encode_utf16().skip(offset+clipped_count)`.

Decode that complete iterator, not its components. Pass one validates final scalar storage and computes exact UTF8 bytes using checked additions. A cut through a pair can be repaired by an inserted lone unit; a zero deletion inside a pair can preserve the original string. Do not call `pi_scalar_string(inserted)` first. Only a final unpaired sequence receives explicit Unsupported, before the outer mutation. Substring has no such restriction.

Recreate the same iterator for emission into a single exact, fallibly reserved String, then move it into replace_character_data. The current DOM API freshly validates kind, per-node limit and replacement-aware retained bytes before mutation, preserves node/links/PI target, and allocates nothing. The runtime cumulative heap receives no refund for replaced old bytes. A separate pure DOM admission helper is optional to avoid building a soon-rejected temporary, not a prerequisite; keep the implementation narrow unless measured behavior warrants it.

Prepay every reached scan before running it. A splice pass can traverse old UTF8 twice because suffix.skip revisits a prefix; account for both, plus inserted-unit iteration, combined decode, checked sizing and output writes. Use checked arithmetic in old byte length, inserted units and resolved output units. Prepay exact UTF8 capacity before allocation; no second retained-copy debit is needed. No author code runs between the fresh data borrow, final output admission and publication. MutationObserver/Range/PI pseudo-attribute and broader children-changed reactions remain explicitly incomplete, as for the existing data setter. Audit current visible parent behavior without expanding that claim.

## Small source delta and bootstrap ledger

Prefer a child module `processing_instruction/character_data.rs` for the operation enum/signatures, conversion order and substring/splice helpers. Reuse the existing `DOM.PI.` dispatch, cached Native metadata, cleanup-preserving name-copy preflight and `pi_function` installer. Add five ordinary writable/enumerable/configurable prototype methods before `constructor`, each nonconstructable with existing function name/length flags. No new registry rows, globals, prototype records or fallback getters. Extend CharacterData's initially reserved property-order capacity by five and the bootstrap object reservation from668 to673. Other source seams: processing_instruction.rs, dom_prototypes.rs, the IndexSizeError mapping in script.rs, focused fixtures/tests and measured descriptive snapshots.

Conditional source-derived installation estimate with existing helpers and method names as native suffixes: five function bags cost `sum(92+3*name_length)=622` work; five prototype property insertions at counts4..8 cost573; later constructor insertion at count9 instead of4 costs65 more. Total incremental work1260, suggesting8251 remaining from the observed9511. This is an estimate, not a measured admission claim. It assumes no extra redundant lookup/pass is introduced; preserve the first real result and all current fees.

Heap ledger adds five fully charged ScriptObject arena slots; five base charges; five two-key order buffers; each actual first-leaf property node; all key/display temporary+Rc payloads; full Native/Rc/name storage; five retained prototype keys/properties and five extra parent order slots. Existing dom_proto_object/text/named and pi_function perform these charges. Native and prototype name registries remain321/25, so their existing search bounds do not change. No quota/reset modifications or broad installer refactor.

## Focused witnesses

Use each independently authored ordinary case in a fresh runtime in both modes. Add measured exact/one-short work+heap for substring and all mutation families; no outer node/ledger/tree change on refusal; preserved conversion prefixes; a callback that changes offset validity and one that consumes remaining retained bytes; wrapping offsets/counts and overflow-free clipping; complete-pair repairs and final-nonscalar Unsupported; small substring from a large DOM node; saved method brands and prototype deletion with no resurrection; call-guard cleanup. Keep standards-success expectations for unsupported final DOM strings distinct from terminal-policy observations. Preserve raw bootstrap refusal tests, updating only descriptive counters after measurement.
