# CharacterData browser fixture

Independent source-only fixture; no compiler or engine execution by the author. Six load/click categories: connected Text updated by all five methods; saved prototype methods and Comment/PI borrowing; individual UTF-16 substring units and range identity; complete-splice surrogate repair; callback conversion order/current-data replacement; ordinary prototype replacement/deletion/restoration and authentic brand before conversion.

The retained Text node is the only child of #result. Its contents become ready at load and 6 at click using replaceData, preserving node identity. Both integration tests retain the old six-color, DOM text and diagnostic checks. The new opt-in also requires the matching DrawCommand::Text in the same layout; the worker case checks both direct and worker layouts and their complete raster equality. Existing helper entrypoints pass false, preserving earlier expectations. No double execution is introduced for the new draw-command assertions.

This fixture intentionally excludes terminal non-scalar final DOM storage, host prototype mutation, full CharacterData editing beyond the five methods, PI pseudo-attributes, ranges and mutation observers. Literal unit outcomes are independent: A + high + low + B becomes A + high + low + high + low + B when low/high is inserted at offset2. WXYZ with offset1/count2 replaced by ! becomes W!Z. The scalar storage contract is unchanged. Each callback body is finite; work/heap admission has not been measured.

Primary contract: ../eris-character-data-preparation-1/proposal.md, https://dom.spec.whatwg.org/#interface-characterdata and https://webidl.spec.whatwg.org/#es-operations. Original fixture bytes are retained beside this note.
