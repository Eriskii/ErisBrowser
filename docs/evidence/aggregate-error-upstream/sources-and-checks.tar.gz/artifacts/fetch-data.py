from pathlib import Path
import concurrent.futures
import hashlib
import json
import urllib.request

P = Path('/tmp/eris-aggregate-error-upstream-plan-1')
OLD = Path('/tmp/eris-promise-all-settled-upstream-plan-1/inventory-proof')
REV = '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
ROOT = '91b2052adad1f066ae031e2ff3a1e9bd6d732886'
TREE = '29aa43922ae5a34467878bf9f498ffc4a89bdf67'
proof = P / 'inventory-proof'
proof.mkdir(exist_ok=True)


def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())


def gitsha(kind, b):
    return hashlib.sha1(kind.encode() + b' ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def download(url):
    request = urllib.request.Request(url, headers={'User-Agent': 'ErisBrowser-source-inventory'})
    with urllib.request.urlopen(request, timeout=40) as response:
        data = response.read(2 * 1024 * 1024 + 1)
    assert len(data) <= 2 * 1024 * 1024
    return data


for name in ['commit.json', 'tree-' + ROOT + '.json',
             'tree-a2eada339f3c7e678edfc08497985f261a9ae258.json',
             'tree-b42c4a8f19ad479b70ee2f64ecd683735d83cde9.json',
             'tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json']:
    (proof / name).write_bytes((OLD / name).read_bytes())


def tree(sha):
    path = proof / ('tree-' + sha + '.json')
    if not path.exists():
        path.write_bytes(download('https://api.github.com/repos/tc39/test262/git/trees/' + sha))
    data = json.loads(path.read_bytes())
    assert data['sha'] == sha and data['truncated'] is False
    rows = data['tree']
    assert len({r['path'] for r in rows}) == len(rows)
    assert all('/' not in r['path'] and r['path'] not in ('', '.', '..') for r in rows)
    ordered = sorted(rows, key=lambda r: (r['path'] + ('/' if r['type'] == 'tree' else '')).encode())
    raw = b''.join((r['mode'].lstrip('0') + ' ' + r['path']).encode() + b'\0'
                   + bytes.fromhex(r['sha']) for r in ordered)
    assert gitsha('tree', raw) == sha
    return rows


commit = json.loads((proof / 'commit.json').read_bytes())
assert commit['sha'] == REV and commit['tree']['sha'] == ROOT
at = ROOT
ancestry = []
for name in ['test', 'built-ins', 'AggregateError']:
    entry = next(r for r in tree(at) if r['path'] == name and r['type'] == 'tree')
    ancestry.append(dict(parent=at, name=name, sha=entry['sha']))
    at = entry['sha']
assert at == TREE
assert next(r['sha'] for r in tree(ROOT) if r['path'] == 'harness') == 'e7917cf01aee95d5ed85ba370c550d02cea533c7'
tree('e7917cf01aee95d5ed85ba370c550d02cea533c7')

pending = [('test/built-ins/AggregateError', TREE)]
directories, blobs = [], []
while pending:
    prefix, sha = pending.pop(0)
    rows = tree(sha)
    directories.append(dict(path=prefix, tree=sha, entries=rows))
    assert len(directories) <= 24
    for row in rows:
        rel = prefix + '/' + row['path']
        if row['type'] == 'tree':
            assert row['mode'] == '040000'
            pending.append((rel, row['sha']))
        else:
            assert row['type'] == 'blob' and row['mode'] == '100644'
            blobs.append(dict(relative=rel, git_blob=row['sha']))
    assert len(blobs) <= 512


def fetch(row):
    path = P / 'data' / row['relative']
    path.parent.mkdir(parents=True, exist_ok=True)
    url = 'https://raw.githubusercontent.com/tc39/test262/' + REV + '/' + row['relative']
    data = path.read_bytes() if path.exists() else download(url)
    assert gitsha('blob', data) == row['git_blob'], row['relative']
    path.write_bytes(data)
    return dict(**row, url=url, binding=bind(path))


with concurrent.futures.ThreadPoolExecutor(max_workers=6) as executor:
    sources = list(executor.map(fetch, sorted(blobs, key=lambda r: r['relative'])))
assert sum(r['binding']['bytes'] for r in sources) <= 8 * 1024 * 1024
receipt = dict(status='complete_authenticated_subtree_retrieval_only', revision=REV,
               scope='all descendants of test/built-ins/AggregateError; no feature or result filtering',
               ancestry=ancestry, directory_tree=TREE, directories=directories,
               sources=sources, proof=[bind(p) for p in sorted(proof.glob('*.json'))],
               qualification='Pinned primary commit JSON retained; every nonrecursive tree reconstructed and every raw Git blob recomputed. No project code, importer, runner or engine execution.')
(P / 'fetch-receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(dict(directories=len(directories), blobs=len(sources),
                     bytes=sum(r['binding']['bytes'] for r in sources), receipt=bind(P / 'fetch-receipt.json'))))
