"""Render external docs only after root evidence selectors are resolved and authenticated.

This preparation script is not a project tool. It never imports project code or
runs tests. The immutable documentation-plan-1 supplies all existing-doc anchors.
Actual measurement selectors must be filled from root receipts before use.
"""
from pathlib import Path
from string import Template
import difflib
import hashlib
import json

PLAN = Path('/tmp/eris-aggregate-error-upstream-plan-1')
HERE = PLAN / 'documentation-template-1'
OUTPUT = PLAN / 'documentation-1'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def select(value, pointer):
    if pointer == '':
        return value
    if not isinstance(pointer, str) or not pointer.startswith('/'):
        raise ValueError('unresolved or invalid evidence pointer')
    for part in pointer[1:].split('/'):
        part = part.replace('~1', '/').replace('~0', '~')
        value = value[int(part)] if isinstance(value, list) else value[part]
    return value


def load_facts():
    specification = json.loads((HERE / 'evidence-selectors.json').read_bytes())
    facts, receipts = {}, {}
    for name, spec in specification['fields'].items():
        if not spec.get('receipt') or spec.get('pointer') is None or not spec.get('sha256'):
            raise ValueError('unresolved measured field: ' + name)
        path = Path(spec['receipt']).resolve()
        if PLAN.resolve() not in path.parents or path.suffix != '.json':
            raise ValueError('evidence must be a root-produced JSON receipt inside this plan')
        data = path.read_bytes()
        if digest(data) != spec['sha256']:
            raise ValueError('evidence receipt changed: ' + str(path))
        receipts[str(path)] = dict(path=str(path), bytes=len(data), sha256=digest(data))
        value = select(json.loads(data), spec['pointer'])
        if isinstance(value, (dict, list)):
            raise ValueError('choose a concrete scalar evidence field: ' + name)
        if value is None:
            raise ValueError('missing observation: ' + name)
        facts[name] = str(value)
    return facts, list(receipts.values())


def main():
    # Resolve every required measured field before creating any output directory.
    facts, receipts = load_facts()
    templates = json.loads((HERE / 'templates.json').read_bytes())
    rendered = {name: Template(body).substitute(facts) for name, body in templates.items()}
    if any('PENDING_' in text or '${' in text for text in rendered.values()):
        raise ValueError('unresolved prose remains')
    plan = json.loads((PLAN / 'documentation-plan-1/patch-plan.json').read_bytes())
    inputs = json.loads((PLAN / 'documentation-plan-1/inputs.json').read_bytes())
    original = {}
    for row in inputs:
        b = Path(row['current']['path']).read_bytes()
        if digest(b) != row['current']['sha256']:
            raise ValueError('documentation before changed: ' + row['relative_path'])
        original[row['relative_path']] = b.decode()
    result = {}
    for change in plan['changes']:
        path, anchor = change['path'], change['anchor']
        before = original[path]
        if before.count(anchor) != 1:
            raise ValueError('documentation anchor changed: ' + path)
        if path == 'docs/VALIDATION.md':
            after = before.replace(anchor, anchor + rendered['validation-section'], 1)
        elif change['operation'].startswith('insert_'):
            after = before.replace(anchor, anchor + change['proposed'], 1)
        else:
            after = before.replace(anchor, change['proposed'], 1)
        result[path] = after
    result['docs/aggregate-error-upstream.md'] = rendered['chapter']
    assert result['docs/VALIDATION.md'].endswith(original['docs/VALIDATION.md'][len('# Validation record\n\n'):])
    assert result['docs/aggregate-error.md'].endswith(original['docs/aggregate-error.md'][len('# AggregateError\n\n'):])
    if OUTPUT.exists():
        raise ValueError('external output hold already exists; retain it and select an additive hold')
    for path, after in result.items():
        target = OUTPUT / 'raw' / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(after)
        before = original.get(path, '')
        if path in original:
            f = OUTPUT / 'before' / path
            f.parent.mkdir(parents=True, exist_ok=True)
            f.write_text(before)
        patch = OUTPUT / 'diffs' / (path + '.patch')
        patch.parent.mkdir(parents=True, exist_ok=True)
        patch.write_text(''.join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                                    fromfile='a/' + path if path in original else '/dev/null',
                                                    tofile='b/' + path)))
    (OUTPUT / 'evidence-inputs.json').write_text(json.dumps(receipts, indent=2) + '\n')
    # This preparatory renderer deliberately does not seal source-ready.
    # Manual claim/source/link review and final root ledger binding remain required.


if __name__ == '__main__':
    main()
