"""Inert frozen-record/hash/source consistency checks; no project execution."""
from pathlib import Path
import collections
import hashlib
import json

P=Path('/tmp/eris-aggregate-error-upstream-plan-1')
H=P/'controls-1'
O=P/'controls-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(q):
    b=q.read_bytes();return dict(path=str(q),bytes=len(b),sha256=sha(b))
manifest=json.loads((H/'source-ready.json').read_text())
assert bind(H/'source-ready.json')['sha256']=='5d9d8fc009f39ca640b5e9161d80896afe5102565d813cbccb980a8d81501ac4'
for row in manifest['files']:
    actual=bind(Path(row['path']))
    assert all(actual[k]==row[k] for k in actual)
rows=json.loads((H/'variants.json').read_text())['records']
common=json.loads((P/'common-ordinary-controls.json').read_text())['rows']
independent=json.loads((P/'tests-preservation-1/raw/tools/aggregate-error-preservation-oracle.json').read_text())['common_controls']
assert len(rows)==52 and len(common)==len(independent)==32
assert len({(r['name'],r['mode']) for r in rows})==52
assert len({r['id'] for r in rows})==52
lookup={r['id']:r for r in rows}
by_pair={(r['name'],r['mode']):r for r in rows}
for r,c,i in zip(rows[:32],common,independent):
    assert (r['name'],r['source'],r['expected'],r['mode'])==(c['name'],c['source'],c['expected'],c['mode'])
    assert {k:r[k] for k in i}==i
for r in rows:
    assert Path(r['source_file']['path']).read_bytes()==r['source'].encode()
    assert bind(Path(r['source_file']['path']))==r['source_file']
    assert r['source_sha256']==sha(r['source'].encode())
    assert r['file']=='<preflight>'
    assert r['metadata']['flags']==r['metadata']['features']==r['metadata']['locale']==[]
    assert 'timeout' not in r['metadata'] and 'completion_policy' not in r
    names=['assert.js','sta.js']+r['metadata']['includes']
    harness=[dict(name=n,sha256=sha((P/'data/harness'/n).read_bytes())) for n in names]
    assert r['harness']==harness
    identity=dict(source_sha256=r['source_sha256'],mode=r['mode'],metadata=r['metadata'],harness=harness)
    assert sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())==r['case_sha256']
    obs=r['required_observation'];negative=r['metadata']['negative']
    assert set(obs)=={'status','phase','error_type','error_identity','harness'}
    assert obs['phase']=='runtime' and obs['harness']==''
    classification=('passed' if obs['status']=='complete' else 'failed') if negative is None else ('passed' if obs['status']=='exception' and obs['phase']==negative['phase'] and obs['error_identity']==negative['type'] else 'failed')
    assert classification==r['expected']
    assert len({p['id'] for p in r['prerequisites']})==len(r['prerequisites'])
    for dep in r['prerequisites']:
        target=lookup[dep['id']]
        assert dep=={k:target[k] for k in ('case_sha256','expected','id','mode','name','source_sha256')}
    if r['origin']=='new-selected':
        assert r['source'].startswith("assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');\n")
        assert [p['id'] for p in r['prerequisites'][:32]]==[c['id'] for c in rows[:32]]
        extra=r['prerequisites'][32:]
        if r['expected']=='failed':
            assert len(extra)==1 and extra[0]['mode']==r['mode'] and extra[0]['expected']=='passed'
        else:assert extra==[]
    elif r['expected']=='failed':
        assert len(r['prerequisites'])==1 and r['prerequisites'][0]['expected']=='passed' and r['prerequisites'][0]['mode']==r['mode']

visited=set()
def visit(id,active):
    assert id not in active
    if id in visited:return
    for dep in lookup[id]['prerequisites']:visit(dep['id'],active|{id})
    visited.add(id)
for id in lookup:visit(id,set())

pair_replacements=[('metadata','assert.sameValue(A.length, 2);','assert.sameValue(A.length, 3);'),
                   ('iteration-and-data',"assert.sameValue(trace, 'MCIiNSDVSD');","assert.sameValue(trace, 'MICiNSDVSD');"),
                   ('helper-sequence','checkSequence([1, 2, 3]);','checkSequence([1, 3, 2]);')]
for mode in ('sloppy','strict'):
    for suffix,a,b in pair_replacements:
        good=by_pair[('aggregate-error-'+suffix,mode)]
        bad=by_pair[('aggregate-error-'+suffix+'-mismatch',mode)]
        assert good['source'].count(a)==1 and good['source'].replace(a,b,1)==bad['source']
        assert good['metadata']==bad['metadata'] and good['harness']==bad['harness']
    good=by_pair[('aggregate-error-genuine-identity',mode)]
    bad=by_pair[('aggregate-error-genuine-identity-mismatch',mode)]
    assert good['source']==bad['source'] and good['harness']==bad['harness'] and good['required_observation']==bad['required_observation']
    assert good['metadata']['negative']=={'phase':'runtime','type':'AggregateError'}
    assert bad['metadata']['negative']=={'phase':'runtime','type':'TypeError'}
    assert {k:v for k,v in good['metadata'].items() if k!='negative'}=={k:v for k,v in bad['metadata'].items() if k!='negative'}
for name in {r['name'] for r in rows[32:]}:
    a,b=[by_pair[(name,m)] for m in ('sloppy','strict')]
    assert (a['source'],a['metadata'],a['required_observation'],a['expected'])==(b['source'],b['metadata'],b['required_observation'],b['expected'])

result=dict(status='clear_source_only',manifest=bind(H/'source-ready.json'),sealed_files_checked=len(manifest['files']),records=52,common_records_byte_identity=32,new_rows=20,new_logical_variants=10,mode_counts=dict(collections.Counter(r['mode'] for r in rows)),expected_classifications=dict(collections.Counter(r['expected'] for r in rows)),required_statuses=dict(collections.Counter(r['required_observation']['status'] for r in rows)),all_52_fingerprints_rederived=True,all_helper_bytes_joined=True,all_prerequisite_identity_links_exact=True,dependency_graph_acyclic=True,three_semantic_pair_deltas_each_mode_exact=True,genuine_pair_same_source_metadata_only=True,strict_sloppy_logical_oracles_equal=True)
(O/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(bind(O/'checks.json')))
