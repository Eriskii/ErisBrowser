import ast,collections,hashlib,json,re,subprocess
from pathlib import Path
U=Path('/tmp/eris-aggregate-error-upstream-plan-1');W=U/'worktree';H=U/'validation-review-1';V=U/'validation'
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def receipt(stem):
 p=V/(stem+'.json');r=json.loads(p.read_text());b=(V/r['log']).read_bytes();assert digest(b)==r['sha256'];return r,b.decode(),bind(p),bind(V/r['log'])
def success(stem,n):
 r,s,rb,lb=receipt(stem);assert r['exit']==0 and re.search(r'^Ran '+str(n)+r' tests in .*\n\nOK\n',s,re.M);rows=re.findall(r'^(test_\w+) \(([^\n]+)\) \.\.\. ok$',s,re.M);assert len(rows)==n and len({v for k,v in rows})==n;return dict(count=n,roster=sorted(v for k,v in rows),receipt=rb,log=lb)
parent=success('parent-python-full-1',573);pres=success('parent-preservation-1',4);imp=success('importer-tests-1',6);prof=success('profile-tests-1',13)
assert set(pres['roster'])<=set(parent['roster']);assert not set(imp['roster'])&set(parent['roster']);assert not set(prof['roster'])&set(parent['roster'])
expected=sorted(set(parent['roster'])|set(imp['roster'])|set(prof['roster']));assert len(expected)==592
frozen={}
for kind in ['preservation','importer','profile']:
 m=json.loads((U/('tests-'+kind+'-1/source-ready.json')).read_text());mod=next(r for r in m['payloads'] if r['relative_path'].endswith('.py'));raw=Path(mod['raw']['path']).read_bytes();assert digest(raw)==mod['raw']['sha256'];assert (W/mod['relative_path']).read_bytes()==raw
 tree=ast.parse(raw);name=Path(mod['relative_path']).stem;roster=sorted(name+'.'+c.name+'.'+f.name for c in tree.body if isinstance(c,ast.ClassDef) for f in c.body if isinstance(f,ast.FunctionDef) and f.name.startswith('test_'));frozen[kind]=roster;assert roster==dict(preservation=pres,importer=imp,profile=prof)[kind]['roster']
 for row in m['payloads']:assert (W/row['relative_path']).read_bytes()==Path(row['raw']['path']).read_bytes()
parents={}
for kind,n,fail,error in [('importer',6,0,63),('profile',13,3,9)]:
 r,s,rb,lb=receipt('parent-'+kind+'-tests-1');assert r['exit']!=0 and re.search(r'^Ran '+str(n)+r' tests in ',s,re.M)
 events=re.findall(r'^(ERROR|FAIL): (test_\w+) \(([^\n]+?)\)',s,re.M);assert collections.Counter(t for t,_,_ in events)==dict(ERROR=error,**({'FAIL':fail} if fail else {}))
 errors=sorted({n for t,n,_ in events if t=='ERROR'});failures=sorted({n for t,n,_ in events if t=='FAIL'});passed=re.findall(r'^(test_\w+) \([^\n]+\) \.\.\. ok$',s,re.M)
 summary=json.loads((U/('root/parent-'+kind+'-summary-1.json')).read_text());assert errors==summary['error_groups'] and failures==summary.get('failure_groups',[]) and passed==summary['passed']
 causes=collections.Counter(next((line for line in part.splitlines() if re.match(r'^(?:KeyError|AttributeError|TypeError|AssertionError):',line)),'?') for part in s.split('\n======================================================================\n')[1:]);assert '?' not in causes
 parents[kind]=dict(groups=n,passed=passed,failure_groups=failures,error_groups=errors,error_events=error,failure_events=fail,first_exception_categories=dict(causes),receipt=rb,log=lb,qualification='Parent groups stop at first reached absent-profile/API assertions; later control assertions are not claimed executed.')
r,s,rb,lb=receipt('importer-reproduction-1');assert r['exit']==0
repro=json.loads((U/'importer-reproduction-1/result.json').read_text());assert repro['status']=='pass' and repro['exact_files']==41 and repro['actual_network_requests']==0 and len(repro['retained_fetches'])==len(set(repro['retained_fetches']))==40
C=U/'corpus-expected-1/raw/tests/upstream/test262-aggregate-error';R=U/'importer-reproduction-1/raw';names=lambda p:{str(f.relative_to(p)) for f in p.rglob('*') if f.is_file()};assert names(C)==names(R) and len(names(C))==41
for name in names(C):assert (C/name).read_bytes()==(R/name).read_bytes()==(W/'tests/upstream/test262-aggregate-error'/name).read_bytes()
# Source scope is a point-in-time static snapshot, not the later final seal.
src=json.loads((U/'source-parent.json').read_text())['source_sha256'];assert len(src)==1682
changed={rel:digest((W/rel).read_bytes()) for rel,sha in src.items() if digest((W/rel).read_bytes())!=sha};m=json.loads((U/'legacy-adapters-1/source-ready.json').read_text());selected={r['relative_path'] for r in m['payloads']}|{'tools/import_test262.py','tools/test262_conformance.py'};assert set(changed)==selected
for row in m['payloads']:assert (W/row['relative_path']).read_bytes()==Path(row['raw']['path']).read_bytes()
for rel,raw in [('tools/import_test262.py','implementation-importer-1/raw/tools/import_test262.py'),('tools/test262_conformance.py','implementation-runner-2/raw/tools/test262_conformance.py')]:assert (W/rel).read_bytes()==(U/raw).read_bytes()
git_changed=subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines();assert set(git_changed)==selected
untracked=subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines();new_tools={r['relative_path'] for k in ['preservation','importer','profile'] for r in json.loads((U/('tests-'+k+'-1/source-ready.json')).read_text())['payloads']};new_corpus={'tests/upstream/test262-aggregate-error/'+p for p in names(C)};assert set(untracked)==new_tools|new_corpus
protected={rel:sha for rel,sha in src.items() if rel.endswith('.rs') or Path(rel).name in {'Cargo.toml','Cargo.lock'} or rel.startswith('assets/')};assert all(digest((W/rel).read_bytes())==sha for rel,sha in protected.items())
tracked=subprocess.check_output(['git','ls-files'],cwd=W,text=True).splitlines();old_corpus=[p for p in tracked if p.startswith('tests/upstream/')];old_baselines=[p for p in tracked if p.startswith('tests/conformance/')];assert not(set(git_changed)&set(old_corpus+old_baselines));assert not any(p.startswith(('src/','crates/','assets/')) or Path(p).name in {'Cargo.toml','Cargo.lock'} for p in git_changed)
report=dict(status='interim_source_and_completed_receipts_clear_final_seal_pending',reviewer='/root/script',mode='Read-only/static receipt and hash review, no project execution or live edits.',bindings=[bind(U/'source-parent.json'),bind(U/'root/selection-2.json'),bind(U/'implementation-importer-1/source-ready.json'),bind(U/'implementation-runner-2/source-ready.json'),bind(U/'legacy-adapters-1/source-ready.json')],parent_python=parent,preservation_parent=pres,parent_absence=parents,focused_importer=imp,focused_profile=prof,importer_reproduction=dict(exact_files=41,retained_fetches=40,actual_network_requests=0,manifest=bind(C/'manifest.json'),receipt=rb,log=lb,result=bind(U/'importer-reproduction-1/result.json'),driver=bind(U/'root/reproduce-import.py')),source_snapshot=dict(parent_selected_inputs=1682,changed_existing=changed,new_paths=sorted(untracked),protected_selected_inputs=len(protected),rust=sum(p.endswith('.rs') for p in protected),cargo=sum(Path(p).name in {'Cargo.toml','Cargo.lock'} for p in protected),assets=sum(p.startswith('assets/') for p in protected),all_protected_exact=True,tracked_old_corpus_files=len(old_corpus),tracked_old_baseline_files=len(old_baselines),old_corpora_and_baselines_unchanged_by_git_diff=True,qualification='Selected source map is scoped; independent tracked Git diff additionally checks old corpus/baseline and all tracked paths. CI and measured baseline have not yet been imported in this snapshot.'),expected_full_roster=expected,full_count_formula='569 old + 4 preservation + 6 importer + 13 profile = 592; measured parent full573 already includes preservation4.',pending=['Candidate full Python terminal receipt and exact roster join.','Actual new50/52 measurement, healthy baseline and exact replay.','Four old Promise1050/348 exact replays.','Root final source/report receipts and explicit request to seal.'],findings=[])
(H/'interim-source-and-receipts-1.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(H/'interim-source-and-receipts-1.json')));print(json.dumps(report['source_snapshot']|{'changed_existing':len(changed),'new_paths':len(untracked)}))
