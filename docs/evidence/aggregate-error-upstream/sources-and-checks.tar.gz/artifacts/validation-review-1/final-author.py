import collections,hashlib,json,re,struct,subprocess
from pathlib import Path
U=Path('/tmp/eris-aggregate-error-upstream-plan-1');W=U/'worktree';H=U/'validation-review-1';A=Path('/tmp/eris-aggregate-error-plan-1')
def h(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def load(p):return json.loads(Path(p).read_text())
def valid(b):
 assert bind(b['path'])==b;return Path(b['path']).read_bytes()
def binding_walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():assert bind(v['path'])=={k:v[k] for k in ['path','bytes','sha256']}
  for x in v.values():binding_walk(x)
 elif isinstance(v,list):
  for x in v:binding_walk(x)
def receipt(stem):
 p=U/'validation'/f'{stem}.json';r=load(p);log=p.parent/r['log'];assert h(log.read_bytes())==r['sha256'];assert r['exit']==0;return dict(receipt=bind(p),log=bind(log),command=r['command'])
root=load(U/'root/final-validation.json');binding_walk(root);assert root['status']=='pass'
interim=load(H/'interim-source-and-receipts-1.json');full=receipt('python-full-1');text=Path(full['log']['path']).read_text();assert re.search(r'^Ran 592 tests in .*\n\nOK\n',text,re.M);roster=sorted(re.findall(r'^test_\w+ \(([^\n]+)\) \.\.\. ok$',text,re.M));assert len(roster)==len(set(roster))==592 and roster==interim['expected_full_roster'];assert set(interim['parent_python']['roster'])<=set(roster)
added=sorted(set(roster)-set(interim['parent_python']['roster']));assert added==root['python']['added_after_parent_roster'] and len(added)==19;assert root['python']['new_groups']==23 and root['python']['new_groups_split']=={'preservation':4,'importer':6,'profile':13}
# Authenticate each actual report, all complete case/control arrays, policies and engine bytes.
pv=load(U/'root/profile-validation.json');binding_walk(pv);new=load(pv['new_profile']['report']['path']);replay=load(pv['new_profile']['replay']['path']);controls=load(U/'controls-1/variants.json')['records'];ids=load(U/'case-identities.json')['rows'];parent_controls=load(U/'parent-controls-2/observations.json')['observations'];assert len(new['cases'])==len(ids)==50 and len(new['harness_preflight'])==len(controls)==len(parent_controls)==52
for field in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:
 assert new[field]==replay[field]
assert new['counts']==dict(collections.Counter(r['status'] for r in new['cases']))=={'passed':44,'failed':4,'unsupported':2};assert new['full_test262_conformance'] is False and new['source_files']==new['source_tests']==25 and new['mode_cases']==50
assert new['harness_preflight_passed'] and replay['harness_preflight_passed'] and new['regressions']==new['improvements']==replay['regressions']==replay['improvements']==[]
policy={'format':2,'supported_features':sorted(['AggregateError','error-cause','Reflect','Reflect.construct','Symbol','Symbol.iterator','Symbol.toPrimitive']),'negative_intrinsic_errors':sorted(['AggregateError','Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError']),'strict':True,'modules':False,'async_completion':False,'host_hooks':False,'timeout_seconds':3.0};assert new['runner_policy']==policy;assert h(json.dumps(policy,sort_keys=True).encode())==new['runner_policy_sha256']=='d3fe422ab0532bbe29312f1aeaae90f26589cc7bd16c85699ad07dea49ae1a84'
C=U/'corpus-expected-1/raw/tests/upstream/test262-aggregate-error';assert new['corpus_manifest_sha256']==h((C/'manifest.json').read_bytes())=='ae30b6c1019a0e75df65de5199685f87caeb310f2750eea59c8f2b5b718fa1a1';assert new['binary_sha256']==replay['binary_sha256']==h((U/'eris-js-parent-ordinary-1').read_bytes())=='5f2ee13d295192075ae9966b78ccc8a6f4292d037ed5bad4c838d7fd9361bbf3'
nonpass=[]
for actual,expected in zip(new['cases'],ids):
 identity=expected['identity'];assert actual['id']==expected['id'] and actual['case_sha256']==expected['case_sha256']==h(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode());assert actual['source_sha256']==identity['source_sha256']==h((C/actual['file']).read_bytes());assert actual['mode']==identity['mode'] and actual['expected_negative']==identity['metadata']['negative'] is None
 for helper in identity['harness']:assert helper['sha256']==h((C/'harness'/helper['name']).read_bytes())
 if actual['status']=='failed':
  assert Path(actual['file']).name in {'newtarget-proto-custom.js','newtarget-proto-fallback.js'};assert 'Proxy' not in identity['metadata']['features'];assert 'new Proxy(' in (C/actual['file']).read_text();assert actual['observation']=={'status':'exception','phase':'runtime','error_type':'ReferenceError','error_identity':'ReferenceError','message':"'Proxy' is not defined",'harness':''};nonpass.append(dict(actual,analysis='Untagged Proxy use is adapter-dispatched; runtime ReferenceError occurs before the custom/fallback AggregateError assertion. Retained as failed, never relabeled unsupported.'))
 elif actual['status']=='unsupported':
  assert Path(actual['file']).name=='proto-from-ctor-realm.js' and 'cross-realm' in identity['metadata']['features'] and '$262.createRealm()' in (C/actual['file']).read_text();assert actual['reason']=='unimplemented declared features: cross-realm' and 'observation' not in actual;nonpass.append(dict(actual,analysis='Metadata policy exclusion before adapter execution; no realm behavior observation.'))
 else:assert actual['status']=='passed' and actual['observation']=={'status':'complete','phase':'runtime','error_type':'','error_identity':'','message':'','harness':''}
# Independent ordinary-wire decode and all canonical control dependencies.
legacy_rejections=0
for actual,expected,prior in zip(new['harness_preflight'],controls,parent_controls):
 assert set(actual)=={'name','expected','verified','result','prerequisites'} and actual['verified'] is True and actual['name']==expected['name'] and actual['expected']==expected['expected'] and actual['prerequisites']==expected['prerequisites'];r=actual['result'];assert set(r)=={'id','file','mode','case_sha256','source_sha256','expected_negative','status','observation'}
 for key in ['id','file','mode','case_sha256','source_sha256']:assert r[key]==expected[key]
 assert r['expected_negative']==expected['metadata']['negative'] and r['status']==expected['expected'];obs=r['observation'];assert set(obs)=={'status','phase','error_type','error_identity','message','harness'}
 for key,value in expected['required_observation'].items():assert obs[key]==value
 for key in ['name','mode','case_sha256','source_sha256']:assert prior[key]==expected[key]
 wire=valid(prior['response']);assert wire[:5]==b'ERJR2';offset=5;decoded={}
 for key in ['status','phase','error_type','error_identity','message','harness']:
  length=struct.unpack_from('<I',wire,offset)[0];offset+=4;decoded[key]=wire[offset:offset+length].decode();offset+=length
 assert offset==len(wire) and decoded==obs==prior['observation'];legacy_rejections+=('observation' not in prior['legacy_decoder'])
 assert r['source_sha256']==h(expected['source'].encode())
assert legacy_rejections==4
# Baseline is the unmodified healthy recording projection, including all failures/skips.
projection=dict(revision=new['revision'],corpus_manifest_sha256=new['corpus_manifest_sha256'],runner_policy_sha256=new['runner_policy_sha256'],binary_sha256=new['binary_sha256'],cases={r['id']:{k:r[k] for k in ['status','case_sha256','source_sha256']} for r in new['cases']});baseline=(json.dumps(projection,indent=2)+'\n').encode();assert baseline==valid(pv['new_profile']['baseline'])==(W/'tests/conformance/test262-aggregate-error-current.json').read_bytes();measure=receipt('upstream-aggregate-error-1');assert '--record-baseline' in measure['command'];replay_receipt=receipt('upstream-aggregate-error-replay-1');assert '--baseline' in replay_receipt['command']
old_contract=load(U/'old-profile-contracts.json')['contract'];assert len(old_contract['policies_at_timeout3'])==57
for rec in old_contract['policies_at_timeout3'].values():assert h(json.dumps(rec['policy'],sort_keys=True).encode())==rec['sha256']
old_rows=[];host=A/'eris-js-host-final-1';assert h(host.read_bytes())=='8b2898393aed16e9e7e98908e8284805e5a4dd71d445b3fcb66eaf5451ec375b'
for item in pv['old_profiles']:
 prior=load(item['parent']['path']);actual=load(item['actual']['path']);assert Path(item['parent']['path']).read_bytes()==(A/Path(item['parent']['path']).name).read_bytes()
 for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:assert prior[key]==actual[key]
 assert actual['binary_sha256']==prior['binary_sha256']==h(host.read_bytes());assert actual['harness_preflight_passed'] and all(c['verified'] is True for c in actual['harness_preflight']);assert actual['regressions']==actual['improvements']==[];assert len(actual['cases'])==item['cases'] and len(actual['harness_preflight'])==item['controls'];profile=item['profile'];expected_policy=old_contract['policies_at_timeout3'][profile];assert actual['runner_policy']==expected_policy['policy'] and actual['runner_policy_sha256']==expected_policy['sha256'];assert actual['corpus_manifest_sha256']==h((W/'tests/upstream'/('test262-'+profile)/'manifest.json').read_bytes())
 actual_receipt=receipt(Path(item['actual']['path']).stem);old_rows.append(dict(profile=profile,cases=item['cases'],controls=item['controls'],records_exact=True,policy_and_manifest_exact=True,parent=bind(item['parent']['path']),actual=bind(item['actual']['path']),receipt=actual_receipt))
assert sum(r['cases'] for r in old_rows)==1050 and sum(r['controls'] for r in old_rows)==348
# Final composition: only approved CI + measured baseline since the reviewed interim.
parent=load(U/'source-parent.json')['source_sha256'];final=load(U/'source-final.json')['source_sha256'];assert len(parent)==1682 and len(final)==1730 and set(parent)<=set(final)
for rel,sha in final.items():assert h((W/rel).read_bytes())==sha
changed={p for p in parent if parent[p]!=final[p]};newpaths=set(final)-set(parent);assert changed==set(interim['source_snapshot']['changed_existing'])|{'.github/workflows/check.yml'};assert newpaths==set(interim['source_snapshot']['new_paths'])|{'tests/conformance/test262-aggregate-error-current.json'};assert len(changed)==20 and len(newpaths)==48
assert (W/'.github/workflows/check.yml').read_bytes()==(U/'ci-1/raw/.github/workflows/check.yml').read_bytes();assert (W/'tools/test262_conformance.py').read_bytes()==(U/'implementation-runner-2/raw/tools/test262_conformance.py').read_bytes();assert (W/'tools/import_test262.py').read_bytes()==(U/'implementation-importer-1/raw/tools/import_test262.py').read_bytes()
for kind in ['preservation','importer','profile']:
 for row in load(U/('tests-'+kind+'-1/source-ready.json'))['payloads']:assert (W/row['relative_path']).read_bytes()==Path(row['raw']['path']).read_bytes()
for row in load(U/'legacy-adapters-1/source-ready.json')['payloads']:assert (W/row['relative_path']).read_bytes()==Path(row['raw']['path']).read_bytes()
for p in C.rglob('*'):
 if p.is_file():assert p.read_bytes()==(W/'tests/upstream/test262-aggregate-error'/p.relative_to(C)).read_bytes()
changed_git=set(subprocess.check_output(['git','diff','--name-only','HEAD'],cwd=W,text=True).splitlines());assert changed_git==changed
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines());assert untracked==newpaths
tracked=subprocess.check_output(['git','ls-files'],cwd=W,text=True).splitlines();assert not any(p.startswith(('src/','crates/','assets/','tests/upstream/','tests/conformance/')) or Path(p).name in {'Cargo.lock','Cargo.toml'} for p in changed_git)
# Bind explicit execution qualifications; old green CI is not current-profile CI.
metadata=load(U/'eris-js-parent-ordinary-1.json');binding_walk(metadata);assert metadata['base']==root['base'] and metadata['configuration']=='Rust1.88 release ordinary adapter; no optional features';build=receipt('parent-ordinary-release-1');assert '--release' in build['command'] and '--features' not in build['command'];assert root['runtime']['changed'] is False and root['runtime']['new_full_rust_suite_run'] is False and root['new_github_ci']=='Not yet published or observed';ci=load(U/'root/prior-checkpoint-ci-1.json');assert ci['headSha']==root['base'] and ci['status']=='completed' and ci['conclusion']=='success' and all(j['status']=='completed' and j['conclusion']=='success' for j in ci['jobs'])
report=dict(status='clear',reviewer='/root/script',mode='Independent read-only/stdlib reconciliation of logs, held source/oracles, raw ordinary responses, report arrays and source hashes. No project execution or live edits.',bindings=[bind(U/'root/final-validation.json'),bind(U/'source-final.json'),bind(U/'root/profile-validation.json'),bind(H/'interim-source-and-receipts-1.json'),bind(U/'controls-1/source-ready.json'),bind(U/'corpus-expected-1/source-ready.json'),bind(U/'old-profile-contracts.json'),bind(U/'root/baseline-and-ci-import-1.json'),bind(U/'root/run-profiles.py')],python=dict(parent=573,candidate=592,new_after_parent=19,new_since_published=23,split={'preservation':4,'importer':6,'profile':13},all_unique_names_and_exact_roster=True,old569_preserved=True,actual=full,roster_sha256=h(json.dumps(roster,indent=2).encode())),parent_and_focused='Interim receipt retains independently verified parent importer1pass/5error groups63events, parent profile1pass/3fail/9error, candidate6/13pass and41-file importer reproduction; no changed expectations.',new_profile=dict(source_files=25,mode_cases=50,controls_verified=52,counts=new['counts'],case_identities_exact=True,all_control_identities_observations_and_prerequisites_exact=True,parent52_raw_ERJR2_responses_independently_decoded=True,legacy_decoder_rejections=4,policy=policy,policy_sha256=new['runner_policy_sha256'],whole_case_and_control_replay_exact=True,baseline_exact_healthy_projection=True,baseline_sha256=h(baseline),ordinary_binary=bind(U/'eris-js-parent-ordinary-1'),measurement=measure,replay=replay_receipt,nonpass_analysis=nonpass),old_profiles=old_rows,old_total_cases_exact=1050,old_total_controls_exact=348,source=dict(parent_inputs=1682,final_inputs=1730,changed_existing=20,new_paths=48,total_changed=68,all_final_inputs_hash_verified=True,all_selected_holds_exact=True,only_post_interim_changes='Reviewed CI command and byte-exact measured baseline.',old_rust_cargo_assets_unchanged=True,old_corpora_and_baselines_unchanged=True,tracked_rust=sum(p.endswith('.rs') for p in tracked),tracked_old_corpus=sum(p.startswith('tests/upstream/') for p in tracked),tracked_old_conformance=sum(p.startswith('tests/conformance/') for p in tracked)),qualifications=['Root built the ordinary Rust1.88 release adapter from the unchanged published Rust inputs; the full Rust suites were not rerun for this tooling checkpoint.','Old Promise replays use the exact retained API host binary; all case/control records and policies match retained parent reports byte-for-value.','All four Proxy rows remain failed ReferenceError observations; both cross-realm rows are pre-execution metadata exclusions. No synthetic relabeling or full Test262 compatibility claim.','The first raw-control invocation used an unsupported CLI option and stopped before the first control; the corrected invocation retained the frozen literals and all52 observations.','Prior published CI is green; no current-profile remote CI result is claimed.'],findings=[])
(H/'final-review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(H/'final-review.json')))
