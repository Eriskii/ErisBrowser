from pathlib import Path
import ast,difflib,hashlib,json,pprint
P=Path('/tmp/eris-aggregate-error-upstream-plan-1');W=P/'worktree';H=P/'implementation-runner-1';rel='tools/test262_conformance.py'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
source=(W/rel).read_text();parent=json.loads((P/'source-parent.json').read_bytes());assert sha(source.encode())==parent['source_sha256'][rel]
before=H/'before'/rel;before.parent.mkdir(parents=True,exist_ok=True);before.write_text(source)
edits=[]
def replace(old,new,count=1):
 global source
 assert source.count(old)==count,(old[:100],source.count(old),count)
 source=source.replace(old,new);edits.append(dict(before=old,after=new,count=count))
replace("INTRINSIC_ERRORS = {'Error', 'TypeError', 'RangeError', 'SyntaxError', 'ReferenceError', 'EvalError', 'URIError'}", "AGGREGATE_ERROR_PROFILE = 'aggregate-error'\nAGGREGATE_ERROR_FEATURES = {'AggregateError', 'error-cause', 'Reflect', 'Reflect.construct',\n                            'Symbol', 'Symbol.iterator', 'Symbol.toPrimitive'}\nPROFILE_FEATURES[AGGREGATE_ERROR_PROFILE] = AGGREGATE_ERROR_FEATURES\nINTRINSIC_ERRORS = {'Error', 'TypeError', 'RangeError', 'SyntaxError', 'ReferenceError', 'EvalError', 'URIError'}")
replace("BAD_RUN_STATUSES = {'adapter-error', 'timeout', 'resource'}\n", "BAD_RUN_STATUSES = {'adapter-error', 'timeout', 'resource'}\n\n\ndef profile_intrinsic_errors(profile=None):\n    \"\"\"Ordinary AggregateError transport is an explicit profile-local capability.\"\"\"\n    names = frozenset(INTRINSIC_ERRORS)\n    return names | {'AggregateError'} if profile == AGGREGATE_ERROR_PROFILE else names\n")
replace("if profile in {'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-copy-within'", "if profile in {'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-copy-within'",2)
replace("if metadata['negative'] and metadata['negative']['type'] not in INTRINSIC_ERRORS:", "if metadata['negative'] and metadata['negative']['type'] not in profile_intrinsic_errors(profile):")
replace("def decode_response(output):\n    if output.startswith(b'ERJR3'):", "def decode_response(output, *, profile=None):\n    if profile == AGGREGATE_ERROR_PROFILE and not output.startswith(b'ERJR2'):\n        raise ValueError('AggregateError profile requires an ordinary ERJR2 response')\n    if output.startswith(b'ERJR3'):")
replace("        raise ValueError('unknown JS adapter response phase')\n    if fields['error_identity'] and fields['error_identity'] not in INTRINSIC_ERRORS:", "        raise ValueError('unknown JS adapter response phase')\n    if fields['error_identity'] and fields['error_identity'] not in profile_intrinsic_errors(profile):")
replace("        observation = decode_response(output)\n", "        observation = (decode_response(output, profile=profile)\n                       if profile == AGGREGATE_ERROR_PROFILE else decode_response(output))\n")
replace('    """Fail closed if the upstream assertions no longer enforce basic failures."""\n', '    """Fail closed if the upstream assertions no longer enforce basic failures."""\n    if profile == AGGREGATE_ERROR_PROFILE:\n        return aggregate_error_harness_preflight(files, binary, timeout)\n')
records=json.loads((P/'controls-1/variants.json').read_bytes())['records']
variants=[]
for r in records:
 variants.append({k:r[k] for k in ('name','mode','id','source','metadata','expected','required_observation')} | {'prerequisites':[(p['name'],p['mode']) for p in r['prerequisites']]})
block='''def aggregate_error_preflight_variants():
    """The frozen ordinary32 and selected20 controls, with no observed digests."""
    return '''+pprint.pformat(variants,width=100,sort_dicts=False).replace('\n','\n    ')+'''\n\n\ndef aggregate_error_preflight_cases(files):
    """Rebuild canonical identities from literal controls and authenticated helpers."""
    definitions = []
    for row in aggregate_error_preflight_variants():
        metadata = row['metadata']
        case = dict(id=row['id'], file='<preflight>', mode=row['mode'],
                    metadata=metadata, source=row['source'].encode(),
                    harness=[(name, files['harness/' + name])
                             for name in harness_names(metadata)])
        case['case_sha256'] = case_fingerprint(case)
        definitions.append((row, case))
    return definitions


def aggregate_error_preflight_reference(row, case):
    return dict(name=row['name'], mode=case['mode'], id=case['id'],
                case_sha256=case['case_sha256'], source_sha256=digest(case['source']),
                expected=row['expected'])


def aggregate_error_preflight_checks(outcomes, files):
    """Authenticate observations and the canonical prerequisite graph independently."""
    try:
        definitions = aggregate_error_preflight_cases(files)
        if not isinstance(outcomes, list) or len(outcomes) != 52 or len(definitions) != 52:
            return None
        canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
        if len(canonical) != 52:
            return None
        observed = {}
        for item in outcomes:
            if (not isinstance(item, dict)
                    or set(item) != {'name', 'expected', 'verified', 'result', 'prerequisites'}
                    or not isinstance(item['name'], str)
                    or type(item['verified']) is not bool
                    or not isinstance(item['result'], dict)
                    or not isinstance(item['result'].get('mode'), str)):
                return None
            identity = (item['name'], item['result']['mode'])
            if identity in observed or identity not in canonical:
                return None
            observed[identity] = item
        if observed.keys() != canonical.keys():
            return None
        raw_checks = {}
        for identity, (row, case) in canonical.items():
            item = observed[identity]
            result = item['result']
            expected_result = {key: case[key] for key in ('id', 'file', 'mode', 'case_sha256')}
            expected_result.update(source_sha256=digest(case['source']),
                                   expected_negative=case['metadata']['negative'],
                                   status=row['expected'])
            observation = result.get('observation')
            raw_names = {'status', 'phase', 'error_type', 'error_identity', 'message', 'harness'}
            expected_prerequisites = [aggregate_error_preflight_reference(*canonical[key])
                                      for key in row['prerequisites']]
            good = (item['expected'] == row['expected']
                    and set(result) == set(expected_result) | {'observation'}
                    and all(result.get(key) == value for key, value in expected_result.items())
                    and item['prerequisites'] == expected_prerequisites
                    and isinstance(observation, dict) and set(observation) == raw_names)
            if good:
                good = (all(isinstance(value, str) and len(value.encode('utf-8')) <= 16384
                            for value in observation.values())
                        and all(observation[key] == value
                                for key, value in row['required_observation'].items())
                        and classify(case, observation) == row['expected'])
            raw_checks[identity] = good
        checked, visiting = {}, set()

        def healthy(identity):
            if identity in checked:
                return checked[identity]
            if identity in visiting:
                return False
            visiting.add(identity)
            row, _ = canonical[identity]
            value = raw_checks[identity] and all(healthy(key) for key in row['prerequisites'])
            visiting.remove(identity)
            checked[identity] = value
            return value

        for identity in canonical:
            healthy(identity)
        return checked
    except (KeyError, TypeError, ValueError):
        return None


def aggregate_error_preflight_healthy(outcomes, files):
    checks = aggregate_error_preflight_checks(outcomes, files)
    return (checks is not None and len(checks) == 52 and all(checks.values())
            and all(item['verified'] is True for item in outcomes))


def aggregate_error_harness_preflight(files, binary, timeout):
    definitions = aggregate_error_preflight_cases(files)
    canonical = {(row['name'], case['mode']): (row, case) for row, case in definitions}
    outcomes = []
    for row, case in definitions:
        result = run_case(case, binary, timeout, AGGREGATE_ERROR_FEATURES, AGGREGATE_ERROR_PROFILE)
        prerequisites = [aggregate_error_preflight_reference(*canonical[key])
                         for key in row['prerequisites']]
        outcomes.append(dict(name=row['name'], expected=row['expected'], verified=False,
                             result=result, prerequisites=prerequisites))
    checks = aggregate_error_preflight_checks(outcomes, files)
    if checks is not None:
        for item in outcomes:
            item['verified'] = checks[(item['name'], item['result']['mode'])]
    return outcomes


'''
replace('def check_baseline(previous, current):\n', block+'def check_baseline(previous, current):\n')
replace('        preflight_ok = (promise_all_settled_preflight_healthy(preflight) if args.profile == PROMISE_ALL_SETTLED_PROFILE\n', '        preflight_ok = (aggregate_error_preflight_healthy(preflight, files) if args.profile == AGGREGATE_ERROR_PROFILE\n                        else promise_all_settled_preflight_healthy(preflight) if args.profile == PROMISE_ALL_SETTLED_PROFILE\n')
replace('        if args.profile in PROMISE_HOST_PROFILES and not preflight_ok:\n', "        if args.profile == AGGREGATE_ERROR_PROFILE and not preflight_ok:\n            results = [dict(id=case['id'], file=case['file'], mode=case['mode'],\n                            case_sha256=case['case_sha256'], source_sha256=digest(case['source']),\n                            expected_negative=case['metadata']['negative'], status='blocked',\n                            reason='AggregateError harness preflight failed') for case in cases]\n        elif args.profile in PROMISE_HOST_PROFILES and not preflight_ok:\n")
replace('                      negative_intrinsic_errors=sorted(INTRINSIC_ERRORS), strict=True,\n', '                      negative_intrinsic_errors=sorted(profile_intrinsic_errors(args.profile)), strict=True,\n')
raw=H/'raw'/rel;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_text(source)
diff=H/'diffs'/f'{rel}.patch';diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(''.join(difflib.unified_diff(before.read_text().splitlines(True),source.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
(H/'edit-manifest.json').write_text(json.dumps(dict(path=rel,edits=edits),indent=2)+'\n')
# Parse only: no project import, bytecode compilation, or call into candidate code.
oldtree=ast.parse(before.read_text());newtree=ast.parse(source)
inverse=source
for e in reversed(edits):
 assert inverse.count(e['after'])==e['count'],e['before'][:80]
 inverse=inverse.replace(e['after'],e['before'])
assert inverse==before.read_text()
fn=next(n for n in newtree.body if isinstance(n,ast.FunctionDef) and n.name=='aggregate_error_preflight_variants')
assert ast.literal_eval(fn.body[1].value)==variants
oldfunctions={n.name:ast.get_source_segment(before.read_text(),n) for n in oldtree.body if isinstance(n,ast.FunctionDef)}
newfunctions={n.name:ast.get_source_segment(source,n) for n in newtree.body if isinstance(n,ast.FunctionDef)}
changed=[n for n,s in oldfunctions.items() if newfunctions[n]!=s]
assert set(changed)=={'load_corpus','unsupported_reason','decode_response','run_case','harness_preflight','main'},changed
checks=dict(status='static_source_checks_pass_no_execution',modified_existing_functions=changed,existing_function_count=len(oldfunctions),unchanged_existing_functions=len(oldfunctions)-len(changed),exact_byte_inverse=True,ordinary52_literal_rows_exact=True,old_IN_TRINSIC_ERRORS_literal_unchanged=True,old_PROMISE_HOST_PROFILES_literal_unchanged=True,old_case_fingerprint_body_unchanged=True,old_promise_validator_and_gate_bodies_unchanged=True,checks='AST syntax parsing and literal extraction only; no candidate/parent runner import, JS, subprocess adapter, or project test executed.')
(H/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
print(json.dumps(dict(before=bind(before),raw=bind(raw),diff=bind(diff),modified=changed,added_functions=[n for n in newfunctions if n not in oldfunctions]),indent=2))
