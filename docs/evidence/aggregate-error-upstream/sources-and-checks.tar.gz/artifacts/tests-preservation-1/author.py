"""One-shot external authoring from frozen source data; no project imports."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import subprocess

P=Path('/tmp/eris-aggregate-error-upstream-plan-1')
H=P/'tests-preservation-1'
W=P/'worktree'
BASE='d3efc9aba87102366b538ff69e83c2524a48eb6b'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(q):
    b=q.read_bytes()
    return dict(path=str(q),bytes=len(b),sha256=sha(b))
def put(q,value):
    q.parent.mkdir(parents=True,exist_ok=True)
    q.write_text(json.dumps(value,indent=2)+'\n')

assert not (H/'source-ready.json').exists()
old=json.loads((P/'old-profile-contracts.json').read_text())['contract']
common=json.loads((P/'common-ordinary-controls.json').read_text())['rows']
parent=json.loads((P/'source-parent.json').read_text())
assert parent['base']==BASE
oracle_names=['promise-methods-runner-oracle.json','promise-all-profile-oracle.json','promise-race-profile-oracle.json','promise-all-settled-profile-oracle.json']
helper_names=['harness/assert.js','harness/sta.js','harness/propertyHelper.js']
old_oracles={name:{k:v for k,v in bind(W/'tools'/name).items() if k!='path'} for name in oracle_names}
helpers={name:{k:v for k,v in bind(W/'tests/upstream/test262'/name).items() if k!='path'} for name in helper_names}
controls=[]
for row in common:
    includes=['propertyHelper.js'] if 'property-' in row['name'] else []
    metadata=dict(flags=[],includes=includes,features=[],locale=[],negative=None)
    harness=[dict(name=name,sha256=helpers['harness/'+name]['sha256']) for name in ['assert.js','sta.js']+includes]
    identity=dict(source_sha256=sha(row['source'].encode()),mode=row['mode'],metadata=metadata,harness=harness)
    controls.append(dict(id='harness-preflight:'+row['name'],mode=row['mode'],metadata=metadata,
                         source=row['source'],case_sha256=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()),
                         harness=harness,expected=row['expected']))
assert len(controls)==32 and len({r['id'] for r in controls})==32
oracle=dict(schema='aggregate-error-parent-preservation-v1',scope='57 published old profiles and existing decoder/case/control identities; independent of new-profile API availability',old_contract=old,existing_oracles=old_oracles,common_helpers=helpers,common_controls=controls)
oracle_path=H/'raw/tools/aggregate-error-preservation-oracle.json'
put(oracle_path,oracle)
module_path=H/'raw/tools/test_test262_aggregate_error_preservation.py'
module=module_path.read_text()
assert module.count('ORACLE_SHA_PENDING')==1
module=module.replace('ORACLE_SHA_PENDING',bind(oracle_path)['sha256'])
module_path.write_text(module)
tree=ast.parse(module)
klass=next(n for n in tree.body if isinstance(n,ast.ClassDef))
names=[n.name for n in klass.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(names)==4
payloads=[]
for relative in ['tools/test_test262_aggregate_error_preservation.py','tools/aggregate-error-preservation-oracle.json']:
    assert not (W/relative).exists()
    raw=H/'raw'/relative
    patch=''.join(difflib.unified_diff([],raw.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+relative))
    diff=H/'diffs'/(relative+'.patch');diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(patch)
    payloads.append(dict(relative_path=relative,before_absent=True,raw=bind(raw),diff=bind(diff)))

source_paths=['tools/import_test262.py','tools/test262_conformance.py']+['tools/'+n for n in oracle_names]+['tests/upstream/test262/'+n for n in helper_names]
source_paths += ['tests/upstream/test262-'+profile+'/manifest.json' for profile in ['promise-methods-async','promise-all','promise-race','promise-all-settled']]
sources=[]
for relative in source_paths:
    data=(W/relative).read_bytes()
    assert sha(data)==parent['source_sha256'][relative]
    published=subprocess.run(['git','-C',str(W),'show',BASE+':'+relative],check=True,stdout=subprocess.PIPE).stdout
    assert data==published,relative
    retained=H/'source-snapshots'/relative;retained.parent.mkdir(parents=True,exist_ok=True);retained.write_bytes(data)
    sources.append(dict(relative_path=relative,published_git_exact=True,source=bind(W/relative),retained=bind(retained)))
put(H/'source-bindings.json',dict(base=BASE,parent_inventory=bind(P/'source-parent.json'),proposal=bind(P/'source-ready.json'),published_refresh=bind(P/'published-base-refresh-1/source-ready.json'),rows=sources))
put(H/'roster.json',dict(groups=4,names=names,parent_expected='four groups pass; no new profile or new API is referenced at import or required at runtime',claims=['57 table/root/tree/feature maps and real report policy dictionaries under empty-case mocks','default seven names and old ERJR3 validators with valid Error framing controls and eighth/unknown identity refusals','1050 held Promise case fingerprints, exact manifests and four unchanged guard literal rosters','32 exact common ordinary sources/modes/metadata/ordered helper fingerprints'],mock_qualification='No engine, adapter, network, measured corpus outcome, or actual preflight health is claimed by these unit controls.'))
put(H/'notes.json',dict(status='source_ready_parent_compatible',new_paths=2,production_changes=0,discovery='Existing unittest discover tools/test_*.py convention; no registration or workflow change.',expected_derivation=['old_contract copied byte-for-value from the sealed old-profile-contracts.json, whose static literal derivation was independently peered','Existing four published Promise oracle bytes are SHA-bound; expected case identities and guard literals are reused without regeneration','Common32 source/mode/status literals copied from sealed common-ordinary-controls.json; case fingerprint projection independently reconstructed from current case_fingerprint source and exact published helper bytes'],interfaces=['importer.PROFILES/PROFILE_ROOTS/TREE_PROFILES/ROOT/fetch','runner.PROFILE_FEATURES/INTRINSIC_ERRORS/PROMISE_HOST_PROFILES/main/load_corpus/harness_preflight/run_case/bounded_process','runner.decode_response/decode_promise_response/validate_promise_observation/unsupported_reason','all four existing promise_*_preflight_variants and case_fingerprint'],boundedness='The mocked main call uses no cases and explicitly mocks old health gates; it checks actual policy construction, not gate correctness. New-profile gate/capability admission controls belong to a separate module.',no_execution='Only external source/oracle authoring, ast.parse syntax inspection and read-only Git/hash joins performed; no project import or test execution.'))
files=[]
for q in sorted(H.rglob('*')):
    if q.is_file() and q.name!='source-ready.json':files.append(dict(relative=str(q.relative_to(H)),**bind(q)))
seal=dict(status='source_ready_no_project_execution',base=BASE,groups=4,parent_compatible=True,payloads=payloads,oracle_sha256=bind(oracle_path)['sha256'],proposal=bind(P/'source-ready.json'),selection=bind(P/'root/selection-1.json'),published_refresh=bind(P/'published-base-refresh-1/source-ready.json'),files=files)
put(H/'source-ready.json',seal)
print(json.dumps(bind(H/'source-ready.json')))
