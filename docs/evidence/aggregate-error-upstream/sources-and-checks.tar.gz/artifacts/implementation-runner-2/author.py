import ast,difflib,hashlib,json
from pathlib import Path
U=Path('/tmp/eris-aggregate-error-upstream-plan-1');H=U/'implementation-runner-2'
p=U/'implementation-runner-1/raw/tools/test262_conformance.py';old=p.read_text();tree=ast.parse(old);f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='aggregate_error_preflight_variants');rows=ast.literal_eval(f.body[-1].value);assert len(rows)==52
common=[]
for r in rows[:13]:
 deps=r['prerequisites'];common.append((r['name'],r['source'],r['expected'],deps[0][0] if deps else None))
strict_only=[(r['name'],r['source']) for r in rows[26:32]]
selected=[]
for a,b in zip(rows[32::2],rows[33::2]):
 assert a['name']==b['name'] and a['source']==b['source'] and a['metadata']==b['metadata'] and a['required_observation']==b['required_observation'] and a['expected']==b['expected']
 spec=dict(name=a['name'],source=a['source'],includes=tuple(a['metadata']['includes']),expected=a['expected'])
 if a['metadata']['negative'] is not None:spec['negative']=a['metadata']['negative']['type']
 if a['required_observation']['error_type']:spec['error_type']=a['required_observation']['error_type']
 if a['required_observation']['error_identity']:spec['error_identity']=a['required_observation']['error_identity']
 if len(a['prerequisites'])>32:spec['prerequisite']=a['prerequisites'][32][0]
 selected.append(spec)
head='''def aggregate_error_preflight_variants():
    """Build the frozen ordinary32 and selected20 controls without observed digests."""
    rows = []

    def add(name, mode, source, expected, *, includes=(), negative=None,
            error_type='', error_identity='', prerequisites=(), mode_id=False):
        rows.append({
            'name': name,
            'mode': mode,
            'id': 'harness-preflight:' + name + (':' + mode if mode_id else ''),
            'source': source,
            'metadata': {'features': [], 'flags': [], 'includes': list(includes),
                         'locale': [], 'negative': None if negative is None else
                         {'phase': 'runtime', 'type': negative}},
            'expected': expected,
            'required_observation': {'error_identity': error_identity,
                                     'error_type': error_type, 'harness': '',
                                     'phase': 'runtime',
                                     'status': 'exception' if error_type else 'complete'},
            'prerequisites': list(prerequisites),
        })

    # Existing ordinary controls: name, source, result, same-mode prerequisite.
    common = [
'''
parts=[head]
for name,source,expected,dep in common:
 parts.append('        ('+repr(name)+',\n         '+repr(source)+',\n         '+repr(expected)+', '+repr(dep)+'),\n')
parts.append('''    ]
    for mode, prefix in (('sloppy', ''), ('strict', 'strict-')):
        for name, source, expected, prerequisite in common:
            add(prefix + name, mode, source, expected,
                includes=('propertyHelper.js',) if 'property-' in name else (),
                error_type='Test262Error' if expected == 'failed' else '',
                prerequisites=([(prefix + prerequisite, mode)]
                               if prerequisite is not None else []))

    strict_only = [
''')
for name,source in strict_only:parts.append('        ('+repr(name)+',\n         '+repr(source)+'),\n')
parts.append('''    ]
    for name, source in strict_only:
        add(name, 'strict', source, 'passed')
    common_refs = [(row['name'], row['mode']) for row in rows]

    # Each new literal is written once and expanded into sloppy/strict rows.
    # Identity mismatches deliberately retain the same source and vary metadata.
    selected = [
''')
for spec in selected:
 parts.append('        {\n')
 for k,v in spec.items():
  if k=='source':
   parts.append("            'source': (\n")
   for line in v.splitlines(keepends=True):parts.append('                '+repr(line)+'\n')
   parts.append('            ),\n')
  else:parts.append('            '+repr(k)+': '+repr(v)+',\n')
 parts.append('        },\n')
parts.append('''    ]
    for control in selected:
        for mode in ('sloppy', 'strict'):
            prerequisites = list(common_refs)
            if 'prerequisite' in control:
                prerequisites.append((control['prerequisite'], mode))
            add(control['name'], mode, control['source'], control['expected'],
                includes=control['includes'], negative=control.get('negative'),
                error_type=control.get('error_type', ''),
                error_identity=control.get('error_identity', ''),
                prerequisites=prerequisites, mode_id=True)
    return rows''')
factory=''.join(parts);before_factory=ast.get_source_segment(old,f);assert old.count(before_factory)==1;raw=old.replace(before_factory,factory,1);rt=ast.parse(raw);rf=next(n for n in rt.body if isinstance(n,ast.FunctionDef) and n.name==f.name)
# Inert literal extraction, independent data expansion: no module import or function execution.
constants={n.targets[0].id:ast.literal_eval(n.value) for n in rf.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id in {'common','strict_only','selected'}}
expanded=[]
def record(name,mode,source,expected,includes=(),negative=None,error_type='',error_identity='',prerequisites=(),mode_id=False):
 return {'name':name,'mode':mode,'id':'harness-preflight:'+name+(':'+mode if mode_id else ''),'source':source,'metadata':{'features':[],'flags':[],'includes':list(includes),'locale':[],'negative':None if negative is None else {'phase':'runtime','type':negative}},'expected':expected,'required_observation':{'error_identity':error_identity,'error_type':error_type,'harness':'','phase':'runtime','status':'exception' if error_type else 'complete'},'prerequisites':list(prerequisites)}
for mode,prefix in [('sloppy',''),('strict','strict-')]:
 for name,source,expected,dep in constants['common']:
  expanded.append(record(prefix+name,mode,source,expected,['propertyHelper.js'] if 'property-' in name else [],error_type='Test262Error' if expected=='failed' else '',prerequisites=[] if dep is None else [(prefix+dep,mode)]))
for name,source in constants['strict_only']:expanded.append(record(name,'strict',source,'passed'))
common_refs=[(r['name'],r['mode']) for r in expanded]
for s in constants['selected']:
 for mode in ['sloppy','strict']:
  deps=common_refs+([(s['prerequisite'],mode)] if 'prerequisite' in s else [])
  expanded.append(record(s['name'],mode,s['source'],s['expected'],s['includes'],s.get('negative'),s.get('error_type',''),s.get('error_identity',''),deps,True))
assert expanded==rows
# Preserve insertion order as well as values for every nested dictionary/list.
assert json.dumps(expanded,ensure_ascii=True)==json.dumps(rows,ensure_ascii=True)
controls=json.loads((U/'controls-1/variants.json').read_text())['records']
for row,control in zip(expanded,controls):
 assert row['source']==control['source'] and row['name']==control['name'] and row['mode']==control['mode'] and row['id']==control['id'] and row['metadata']==control['metadata'] and row['expected']==control['expected'] and row['required_observation']==control['required_observation']
 assert row['prerequisites']==[(p['name'],p['mode']) for p in control['prerequisites']]
assert raw.replace(factory,before_factory,1)==old
of={n.name:ast.get_source_segment(old,n) for n in tree.body if isinstance(n,ast.FunctionDef)};nf={n.name:ast.get_source_segment(raw,n) for n in rt.body if isinstance(n,ast.FunctionDef)};assert of.keys()==nf.keys() and [k for k in of if of[k]!=nf[k]]==[f.name]
def binding(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for name,text in [('before/tools/test262_conformance.py',old),('raw/tools/test262_conformance.py',raw),('factory-before.py.txt',before_factory+'\n'),('factory-after.py.txt',factory+'\n')]:
 q=H/name;q.parent.mkdir(parents=True,exist_ok=True);q.write_text(text)
diff=''.join(difflib.unified_diff(old.splitlines(keepends=True),raw.splitlines(keepends=True),fromfile='a/tools/test262_conformance.py',tofile='b/tools/test262_conformance.py'));(H/'runner.patch').write_text(diff)
checks=dict(method='ast.parse and ast.literal_eval of three compact tables, followed by independent stdlib data expansion; candidate functions/module never executed',rows=52,common=32,new=20,old_factory_lines=len(before_factory.splitlines()),new_factory_lines=len(factory.splitlines()),exact_nested_json_order_and_values=True,serialized_rows_sha256=hashlib.sha256(json.dumps(rows,ensure_ascii=True).encode()).hexdigest(),frozen_controls_join=True,only_changed_function=f.name,outside_factory_exact=True,inverse_exact=True,freshness='Each call creates new tables/rows; add creates fresh metadata lists, negative dict, observation dict and copied prerequisite list for every row; shared scalar strings/tuple pairs are immutable.',limits='Static equality proves literal/expansion source fit; root owns executable frozen control tests and actual gate validation.')
(H/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
manifest=dict(status='authored_source_only_no_project_execution_or_live_import',base='d3efc9aba87102366b538ff69e83c2524a48eb6b',selected_parent_hold=binding(U/'implementation-runner-1/source-ready.json'),frozen_controls=binding(U/'controls-1/source-ready.json'),before=binding(H/'before/tools/test262_conformance.py'),raw=binding(H/'raw/tools/test262_conformance.py'),diff=binding(H/'runner.patch'),checks=binding(H/'checks.json'),author=binding(H/'author.py'),selection='Replace only aggregate_error_preflight_variants from hold1; all gate, routing, decoder, profile and old code bytes unchanged.',frozen_original='implementation-runner-1 remains unchanged.')
(H/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(binding(H/'source-ready.json')));print(json.dumps(checks))
