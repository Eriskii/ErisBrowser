from pathlib import Path
import ast,hashlib,json
P=Path('/tmp/eris-aggregate-error-upstream-plan-1');W=Path('/tmp/eris-aggregate-error-plan-1/worktree');A=W.parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def put(name,o):(P/name).write_text(json.dumps(o,indent=2,sort_keys=True)+'\n')
def evaluate(n,env):
 if isinstance(n,ast.Constant):return n.value
 if isinstance(n,ast.Name):return env[n.id]
 if isinstance(n,ast.Dict):return {evaluate(k,env):evaluate(v,env) for k,v in zip(n.keys,n.values)}
 if isinstance(n,(ast.List,ast.Tuple,ast.Set)):
  v=[evaluate(x,env) for x in n.elts];return set(v) if isinstance(n,ast.Set) else tuple(v) if isinstance(n,ast.Tuple) else v
 if isinstance(n,ast.BinOp) and isinstance(n.op,(ast.BitOr,ast.Add)):
  l,r=evaluate(n.left,env),evaluate(n.right,env);return l|r if isinstance(n.op,ast.BitOr) else l+r
 if isinstance(n,ast.Call) and not n.args and not n.keywords and isinstance(n.func,ast.Attribute) and n.func.attr=='copy':return evaluate(n.func.value,env).copy()
 if isinstance(n,ast.Subscript):return evaluate(n.value,env)[evaluate(n.slice,env)]
 raise ValueError(ast.dump(n))
def constants(path):
 env={};text=path.read_text()
 for n in ast.parse(text).body:
  if not isinstance(n,ast.Assign):continue
  try:v=evaluate(n.value,env)
  except (ValueError,KeyError):continue
  for target in n.targets:
   if isinstance(target,ast.Name):env[target.id]=v
   elif isinstance(target,ast.Subscript) and isinstance(target.value,ast.Name) and target.value.id in env:env[target.value.id][evaluate(target.slice,env)]=v
 return env
imp=constants(W/'tools/import_test262.py');run=constants(W/'tools/test262_conformance.py')
assert len(imp['PROFILES'])==len(run['PROFILE_FEATURES'])==57
policies={}
for profile,features in run['PROFILE_FEATURES'].items():
 policy=dict(format=2,supported_features=sorted(features),negative_intrinsic_errors=sorted(run['INTRINSIC_ERRORS']),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
 if profile in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:policy['excluded_harness']=['resizableArrayBufferUtils.js']
 if profile in run['PROMISE_HOST_PROFILES']:
  policy.update(format=3,async_completion=True,host_hooks=True,request_protocol='ERJS2',response_protocol='ERJR3',adapter_feature='test262-host',completion_policy={'sync':'checked-sync','async':'authenticated-done'},unhandled_rejection_policy='final-quiescent-veto',print_only_completion=False)
 policies[profile]=dict(policy=policy,sha256=sha(json.dumps(policy,sort_keys=True).encode()))
old=dict(profiles=imp['PROFILES'],roots=imp['PROFILE_ROOTS'],tree_profiles=sorted(imp['TREE_PROFILES']),features={k:sorted(v) for k,v in run['PROFILE_FEATURES'].items()},intrinsic_errors=sorted(run['INTRINSIC_ERRORS']),policies_at_timeout3=policies)
put('old-profile-contracts.json',dict(status='independent_static_AST_literal_derivation_no_project_import',count=57,contract=old))
selected={'AggregateError','error-cause','Reflect','Reflect.construct','Symbol','Symbol.iterator','Symbol.toPrimitive'}
policy=dict(format=2,supported_features=sorted(selected),negative_intrinsic_errors=sorted(run['INTRINSIC_ERRORS']|{'AggregateError'}),strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0)
put('proposed-policy.json',dict(profile='aggregate-error',supported_features=sorted(selected),accepted_ordinary_intrinsic_errors=sorted(run['INTRINSIC_ERRORS']|{'AggregateError'}),policy=policy,policy_sha256=sha(json.dumps(policy,sort_keys=True).encode()),request='ERJS1',response='ERJR2',host_feature_required=False,completion_policy_in_case_identity=False,status='proposal_not_selected_or_executed'))
paths=['tools/import_test262.py','tools/test262_conformance.py','tools/test_test262_conformance.py','tools/test_test262_async_host.py','tools/test_test262_promise_all_settled_profile.py','src/bin/eris-js.rs','src/script.rs','src/script/throw_metadata.rs','src/script/aggregate_error.rs','src/script/aggregate_error/install.rs','.github/workflows/check.yml']
selected_inventory=A/'source-candidate-4.json';inventory=json.loads(selected_inventory.read_bytes())['source_sha256']
rows=[]
for rel in paths:
 source=W/rel;data=source.read_bytes();assert inventory[rel]==sha(data),rel
 retained=P/'source-snapshots'/rel;retained.parent.mkdir(parents=True,exist_ok=True);retained.write_bytes(data)
 rows.append(dict(relative=rel,source=bind(source),retained=bind(retained),inventory_sha256=inventory[rel]))
put('source-bindings.json',dict(status='published_bootstrap_plus_unpublished_AggregateError_candidate4; future_publication_refresh_required',published_base='383985eded4889cf354c69857cce6ae9cc9b354c',candidate_inventory=bind(selected_inventory),rows=rows))
# Source-exact common ordinary preflight rows; not project execution.
module=ast.parse((W/'tools/test262_conformance.py').read_text());fn=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='harness_preflight')
scripts=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.Assign) and any(isinstance(x,ast.Name) and x.id=='scripts' for x in n.targets)))
extras=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='variants' and isinstance(n.value,ast.List)))
variants=[(name,source,expected,'sloppy') for name,source,expected in scripts]+[('strict-'+name,source,expected,'strict') for name,source,expected in scripts]+extras
assert len(variants)==32
put('common-ordinary-controls.json',dict(status='existing32_exact_literals_no_execution',rows=[dict(name=n,source=s,expected=e,mode=m) for n,s,e,m in variants]))
print(json.dumps(dict(old_profile_count=57,proposed_policy=policy,policy_sha256=sha(json.dumps(policy,sort_keys=True).encode()),source_bindings=bind(P/'source-bindings.json'),common_controls=32),indent=2))
