from pathlib import Path
import ast
import hashlib
import json
import re

P = Path('/tmp/eris-aggregate-error-upstream-plan-1')
O = P / 'corpus-expected-1'
REPO_CORPUS = 'tests/upstream/test262-aggregate-error'
C = O / 'raw' / REPO_CORPUS
assert not (O / 'source-ready.json').exists()
assert not C.exists()
assert not (P / 'worktree' / REPO_CORPUS).exists()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(path):
    return json.loads(path.read_text())

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)

def record(path, value):
    write(path, (json.dumps(value, indent=2) + '\n').encode())

def git_object(kind, body):
    return hashlib.sha1(kind.encode() + b' ' + str(len(body)).encode() + b'\0' + body).hexdigest()

selection = read(P / 'root/selection-1.json')
assert bind(P / 'root/selection-1.json')['sha256'] == 'a2b1b83b90700bfc650d7bf0f573997a874a6992c9f4a928cce3d24cab6e3886'
plan = read(P / 'plan.json')
parent = read(P / 'source-parent.json')
assert parent['base'] == selection['published_parent'] == 'd3efc9aba87102366b538ff69e83c2524a48eb6b'
refresh = []
for row in read(P / 'source-bindings.json')['rows']:
    rel = row['relative']
    current = P / 'worktree' / rel
    assert bind(current)['sha256'] == parent['source_sha256'][rel] == row['inventory_sha256']
    assert current.read_bytes() == Path(row['retained']['path']).read_bytes()
    refresh.append({'relative_path': rel, 'published_sha256': parent['source_sha256'][rel],
                    'retained': row['retained'], 'current': bind(current)})

# This author uses only stdlib bytes/JSON/AST. It does not import or invoke any
# project importer, runner, metadata parser, protocol helper, or engine.
trees = {}
proofs = {}
for path in sorted((P / 'inventory-proof').glob('*.json')):
    relative = 'inventory-proof/' + path.name
    proofs[relative] = path.read_bytes()
    if path.name == 'commit.json':
        continue
    data = read(path)
    assert data['truncated'] is False
    entries = data['tree']
    assert len({row['path'] for row in entries}) == len(entries)
    assert all(row['path'] not in ('', '.', '..') and '/' not in row['path'] for row in entries)
    order = sorted(entries, key=lambda row: row['path'].encode() + (b'/' if row['type'] == 'tree' else b''))
    body = b''.join((row['mode'].lstrip('0') + ' ' + row['path']).encode() + b'\0'
                    + bytes.fromhex(row['sha']) for row in order)
    assert git_object('tree', body) == data['sha'] == path.name[5:-5]
    trees[data['sha']] = {row['path']: row for row in entries}
assert len(proofs) == 7 and len(trees) == 6
commit = read(P / 'inventory-proof/commit.json')
revision = plan['pinned_revision']
root = commit['tree']['sha']
assert revision == commit['sha'] == '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
assert root == '91b2052adad1f066ae031e2ff3a1e9bd6d732886'
at = root
for component in ['test', 'built-ins', 'AggregateError']:
    entry = trees[at][component]
    assert entry['type'] == 'tree'
    at = entry['sha']
assert at == '29aa43922ae5a34467878bf9f498ffc4a89bdf67'

# Traverse every child, not only the selected source-directory counts.
pending = [('AggregateError', at)]
directory_trees = {}
inventory = {}
source_blobs = {}
while pending:
    directory, tree = pending.pop(0)
    assert directory not in directory_trees
    directory_trees[directory] = tree
    names = []
    for name, entry in trees[tree].items():
        if entry['type'] == 'tree':
            assert entry['mode'] == '040000'
            pending.append((directory + '/' + name, entry['sha']))
        else:
            assert entry['type'] == 'blob' and entry['mode'] == '100644'
            assert re.fullmatch(r'[A-Za-z0-9_.-]+\.js', name)
            names.append(name)
            source_blobs['test/built-ins/' + directory + '/' + name] = entry['sha']
    inventory[directory] = sorted(names)
assert {key: len(value) for key, value in inventory.items()} == plan['directories']
assert len(source_blobs) == 25

sources = {}
requested = {'assert.js', 'sta.js'}
for relative, expected in sorted(source_blobs.items()):
    raw = (P / 'data' / relative).read_bytes()
    assert git_object('blob', raw) == expected
    sources[relative] = raw
    header = raw.decode().split('/*---', 1)[1].split('---*/', 1)[0]
    # Every requested include in this fixed corpus is a simple inline list.
    lines = re.findall(r'^includes:\s*(\[[^\n]*\])\s*$', header, re.M)
    assert len(lines) <= 1
    if lines:
        requested.update(item.strip().strip('\"\'') for item in lines[0][1:-1].split(',') if item.strip())
    else:
        assert not re.search(r'^includes:', header, re.M)
    assert not re.search(r'^(flags|negative|locale|timeout):', header, re.M)
assert requested == {'assert.js', 'sta.js', 'propertyHelper.js', 'compareArray.js', 'isConstructor.js', 'promiseHelper.js'}
assert sum(map(len, sources.values())) == 28499

harness_entry = trees[root]['harness']
assert harness_entry['type'] == 'tree'
harness = trees[harness_entry['sha']]
auxiliary = {}
for name in sorted(requested):
    relative = 'harness/' + name
    expected = harness[name]
    assert expected['type'] == 'blob' and expected['mode'] in {'100644', '100755'}
    auxiliary[relative] = expected['sha']
for name in ['LICENSE', 'INTERPRETING.md']:
    expected = trees[root][name]
    assert expected['type'] == 'blob' and expected['mode'] in {'100644', '100755'}
    auxiliary[name] = expected['sha']
for relative, expected in auxiliary.items():
    raw = (P / 'data' / relative).read_bytes()
    assert git_object('blob', raw) == expected
    sources[relative] = raw
assert len(sources) == 33

# Preserve existing format1 field order, proof URL form, sorted inventories and
# indent2/newline serialization; the scope is the exact selected proposal text.
description = {'method': 'complete-nonrecursive-git-trees', 'revision': revision,
               'root_tree': root, 'directory_trees': directory_trees,
               'auxiliary_blobs': auxiliary}
manifest = {'format': 1, 'repository': 'https://github.com/tc39/test262', 'revision': revision,
            'scope': plan['scope_literal_proposed'], 'directories': inventory,
            'test_files': len(source_blobs), 'files': [],
            'inventory_proof': dict(description, files=[])}
for relative, raw in sorted(proofs.items()):
    route = ('commits/' + revision if relative.endswith('/commit.json')
             else 'trees/' + Path(relative).name[5:-5])
    manifest['inventory_proof']['files'].append({'path': relative, 'bytes': len(raw), 'sha256': sha(raw),
        'url': 'https://api.github.com/repos/tc39/test262/git/' + route})
    write(C / relative, raw)
for relative, raw in sorted(sources.items()):
    manifest['files'].append({'path': relative, 'upstream_path': relative, 'bytes': len(raw), 'sha256': sha(raw)})
    write(C / relative, raw)
record(C / 'manifest.json', manifest)

# Source-only compatibility check against the existing manifest schema.
previous = read(P / 'worktree/tests/upstream/test262-promise-all-settled/manifest.json')
assert list(previous) == list(manifest)
assert list(previous['inventory_proof']) == list(manifest['inventory_proof'])
assert set(previous['files'][0]) == set(manifest['files'][0])
assert set(previous['inventory_proof']['files'][0]) == set(manifest['inventory_proof']['files'][0])
files = sorted(path for path in C.rglob('*') if path.is_file())
assert len(files) == 41
assert {str(path.relative_to(C)) for path in files} == set(sources) | set(proofs) | {'manifest.json'}
assert sum(map(len, sources.values())) + sum(map(len, proofs.values())) < 16 * 1024 * 1024
for path in files:
    relative = str(path.relative_to(C))
    if relative in sources:
        assert path.read_bytes() == (P / 'data' / relative).read_bytes()
    elif relative in proofs:
        assert path.read_bytes() == (P / relative).read_bytes()

roster = [{'relative_path': str(path.relative_to(O / 'raw')),
           'corpus_relative_path': str(path.relative_to(C)), **bind(path)} for path in files]
record(O / 'roster.json', {'files': roster, 'files_including_manifest': 41,
       'bytes_including_manifest': sum(path.stat().st_size for path in files),
       'manifest_data_files': 33, 'proof_files': 7, 'source_files': 25,
       'helper_files': 6, 'legal_files': 2,
       'manifest': bind(C / 'manifest.json')})
record(O / 'published-base-refresh.json', {
    'status': 'source_exact_additive_published_base_join_for_corpus_oracle',
    'published_base': parent['base'], 'parent_source': bind(P / 'source-parent.json'),
    'previous_proposal_source_bindings': bind(P / 'source-bindings.json'),
    'rows': refresh, 'qualification': 'All eleven proposed context snapshots match published parent inputs; no earlier proposal bytes are rewritten.'})
importer_text = (P / 'worktree/tools/import_test262.py').read_text()
module = ast.parse(importer_text)
source_rows = []
for name in ['git_tree_inventory', 'tree_proof_path', 'import_corpus']:
    node = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == name)
    source_rows.append({'path': 'tools/import_test262.py', 'function': name,
                        'line': node.lineno, 'end_line': node.end_lineno,
                        'source_sha256': sha(ast.get_source_segment(importer_text, node).encode())})
record(O / 'schema-and-checks.json', {
    'status': 'derived_without_project_execution', 'schema': 'Existing format1; exact selected scope; json.dumps(indent=2) plus final newline.',
    'scope_literal': manifest['scope'], 'source_rows': source_rows,
    'directory_trees': directory_trees, 'helpers': sorted(requested),
    'complete_descendant_inventory': inventory, 'auxiliary_blobs': auxiliary,
    'independent_git_tree_reconstructions': 6, 'source_blob_checks': 25,
    'helper_legal_blob_checks': 8, 'mode_cases': 50, 'sync_modes': 50,
    'metadata_eligible_modes': 48, 'metadata_cross_realm_modes_retained': 2,
    'untagged_Proxy_modes_retained_for_dispatch': 4,
    'unchanged_case_identities': bind(P / 'case-identities.json'),
    'bounds': {'proof_documents': 7, 'existing_proof_document_limit': 32,
               'data_and_proof_bytes': sum(map(len, sources.values())) + sum(map(len, proofs.values())),
               'existing_total_import_limit': 16 * 1024 * 1024},
    'implementation_obligation': 'Importer and loader must verify full child-directory closure for this profile. Omitting AggregateError/prototype is invalid even if directory counts or a manifest are altered.',
    'no_outcomes_or_baseline': True, 'no_project_importer_or_runner_execution': True})
inputs = ['root/selection-1.json', 'source-ready.json', 'layout-review.json', 'host-policy-review.json',
          'plan.json', 'fetch-receipt.json', 'auxiliary-authentication.json', 'census.json',
          'case-identities.json', 'source-bindings.json', 'source-parent.json']
record(O / 'source-ready.json', {
    'status': 'sealed_independent_expected_corpus_before_importer_production',
    'published_base': parent['base'], 'profile': 'aggregate-error',
    'destination': REPO_CORPUS, 'raw_corpus': str(C), 'manifest': bind(C / 'manifest.json'),
    'counts': {'all_files': 41, 'test_sources': 25, 'mode_cases': 50,
               'helpers': 6, 'legal': 2, 'proof_documents': 7},
    'roster': bind(O / 'roster.json'), 'schema_checks': bind(O / 'schema-and-checks.json'),
    'published_base_refresh': bind(O / 'published-base-refresh.json'),
    'author': bind(O / 'derive.py'), 'inputs': [bind(P / name) for name in inputs],
    'before': 'New destination absent in selected published-parent worktree.',
    'preservation': 'All 40 nonmanifest files are byte-exact copies of authenticated retained sources/proofs; no metadata/result filtering.',
    'execution': 'External filesystem assembly and stdlib JSON/hash/AST checks only. No project importer/runner, engine, compiler or live source execution/edit.',
    'later_check': 'Actual importer output must match every expected file and this exact manifest byte-for-byte; root alone imports and executes.'})
print(json.dumps({'hold': bind(O / 'source-ready.json'), 'manifest': bind(C / 'manifest.json'),
                  'files': len(files), 'bytes': sum(path.stat().st_size for path in files)}, indent=2))
