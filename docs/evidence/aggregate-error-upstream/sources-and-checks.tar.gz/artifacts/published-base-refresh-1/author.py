from pathlib import Path
import hashlib,json,subprocess
P=Path('/tmp/eris-aggregate-error-upstream-plan-1');W=P/'worktree';R=P/'published-base-refresh-1'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
selection=json.loads((P/'root/selection-1.json').read_bytes());parent=json.loads((P/'source-parent.json').read_bytes());base=selection['published_parent'];assert parent['base']==base
bindings=json.loads((P/'source-bindings.json').read_bytes());adapters=json.loads((P/'legacy-adapters.json').read_bytes())
inputs={r['relative']:r['retained'] for r in bindings['rows']}
inputs.update({r['path']:r['retained'] for r in adapters['rows']})
rows=[]
for rel,old in sorted(inputs.items()):
 p=W/rel;b=p.read_bytes();retained=Path(old['path']).read_bytes()
 assert b==retained and sha(b)==old['sha256']==parent['source_sha256'][rel],rel
 git=subprocess.run(['git','show',base+':'+rel],cwd=W,check=True,stdout=subprocess.PIPE).stdout;assert git==b
 rows.append(dict(relative=rel,retained=old,published=binding if False else bind(p),published_git_exact=True))
assert len(parent['source_sha256'])==1682
result=dict(status='additive_published_base_refresh_all_referenced_bytes_exact',published_base=base,selection=bind(P/'root/selection-1.json'),proposal=bind(P/'source-ready.json'),old_source_bindings=bind(P/'source-bindings.json'),old_legacy_census=bind(P/'legacy-adapters.json'),published_source_inventory=bind(P/'source-parent.json'),rows=rows,unchanged=['all proposal sources,25rawtests/6helpers/2legal/7proofs and50 case identities','all57 oldprofile table/feature/policy contracts','selected52-control outline and17path24entry adapter scope'],qualification='Prior proposal and candidate4 bindings remain historical. Every referenced tooling/runtime snapshot and historical test adapter is now joined to published d3efc9ab without modifying any prior artifact. No project execution or source changes.')
p=R/'source-ready.json';p.write_text(json.dumps(result,indent=2,sort_keys=True)+'\n');print(json.dumps(bind(p)))
