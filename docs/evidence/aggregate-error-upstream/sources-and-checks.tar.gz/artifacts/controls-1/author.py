from pathlib import Path
import hashlib,json,difflib
P=Path('/tmp/eris-aggregate-error-upstream-plan-1');C=P/'controls-1';W=P/'worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def put(name,data):
 p=C/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n');return p
# These literals and expected observations are authored from the frozen source/spec contract, before any adapter execution.
guard="assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');\n"
metadata=guard+"""var A = AggregateError;
assert.sameValue(isConstructor(A), true);
assert.sameValue(isConstructor(() => {}), false);
verifyProperty(A, 'name', {value: 'AggregateError', writable: false, enumerable: false, configurable: true}, {restore: true});
verifyProperty(A, 'length', {value: 2, writable: false, enumerable: false, configurable: true}, {restore: true});
verifyProperty(A, 'prototype', {value: A.prototype, writable: false, enumerable: false, configurable: false}, {restore: true});
assert.sameValue(Object.getPrototypeOf(A), Error);
assert.sameValue(Object.getPrototypeOf(A.prototype), Error.prototype);
assert.sameValue(A.prototype.constructor, A);
assert.sameValue(Object.prototype.hasOwnProperty.call(A.prototype, 'errors'), false);
assert.sameValue(A.length, 2);
"""
iteration=guard+"""var A = AggregateError, trace = '', payload = {}, cause = {}, steps = 0;
var message = {toString: function () { trace += 'M'; return 'message'; }};
var options = {}, iterator = {}, source = {};
Object.defineProperty(options, 'cause', {get: function () { trace += 'C'; return cause; }});
Object.defineProperty(iterator, 'next', {get: function () {
  trace += 'N';
  return function () {
    trace += 'S';
    steps++;
    if (steps === 1) return {
      get done() { trace += 'D'; return false; },
      get value() { trace += 'V'; return payload; }
    };
    return {
      get done() { trace += 'D'; return true; },
      get value() { throw new Test262Error('exhausted value read'); }
    };
  };
}});
Object.defineProperty(source, Symbol.iterator, {get: function () {
  trace += 'I';
  return function () { trace += 'i'; return iterator; };
}});
AggregateError = function () { throw new Test262Error('replacement global called'); };
var result = A(source, message, options), values = result.errors;
assert.sameValue(Object.getPrototypeOf(result), A.prototype);
assert.sameValue(result.message, 'message');
assert.sameValue(result.cause, cause);
assert.sameValue(Array.isArray(values), true);
assert.sameValue(Object.getPrototypeOf(values), Array.prototype);
assert.sameValue(values.length, 1);
assert.sameValue(values[0], payload);
assert.sameValue(Object.prototype.hasOwnProperty.call(values, '0'), true);
var slot = Object.getOwnPropertyDescriptor(values, '0');
assert.sameValue(slot.value, payload);
assert.sameValue(slot.writable && slot.enumerable && slot.configurable, true);
verifyProperty(result, 'errors', {value: values, writable: true, enumerable: false, configurable: true}, {restore: true});
assert.sameValue(steps, 2);
assert.sameValue(trace, 'MCIiNSDVSD');
"""
helper=guard+"""var result = AggregateError([1, 2, 3]);
assert.sameValue(Array.isArray(result.errors), true);
assert.compareArray(result.errors, [1, 2, 3]);
assert.sameValue(compareArray([1, 2], [1, 2]), true);
assert.sameValue(compareArray([1, 2], [2, 1]), false);
checkSequence([1, 2, 3]);
"""
genuine=guard+"""var A = AggregateError;
var value = new A([1], 'aggregate identity control');
Object.defineProperty(A, 'name', {value: 'RenamedAggregateError', writable: false, enumerable: false, configurable: true});
throw value;
"""
fake_own=guard+"throw {name: 'AggregateError', constructor: AggregateError};\n"
fake_proto=guard+"throw Object.create(AggregateError.prototype);\n"
new=[]
def add(name,source,expected,kind,includes=(),negative=None,positive=None,raw_identity=None):
 assert source.startswith(guard) and source.count(guard)==1
 new.append(dict(name='aggregate-error-'+name,source=source,expected=expected,verification_kind=kind,includes=list(includes),negative=negative,positive=None if positive is None else 'aggregate-error-'+positive,raw_identity=raw_identity))
for name,source,includes,old,newtext in [
 ('metadata',metadata,['propertyHelper.js','isConstructor.js'],'assert.sameValue(A.length, 2);','assert.sameValue(A.length, 3);'),
 ('iteration-and-data',iteration,['propertyHelper.js'],"assert.sameValue(trace, 'MCIiNSDVSD');","assert.sameValue(trace, 'MICiNSDVSD');"),
 ('helper-sequence',helper,['compareArray.js','promiseHelper.js'],'checkSequence([1, 2, 3]);','checkSequence([1, 3, 2]);')]:
 assert source.count(old)==1
 add(name,source,'passed','semantic-pass',includes)
 add(name+'-mismatch',source.replace(old,newtext),'failed','assertion-mismatch',includes,positive=name)
add('genuine-identity',genuine,'passed','negative-match',negative=dict(phase='runtime',type='AggregateError'),raw_identity=('RenamedAggregateError','AggregateError'))
add('genuine-identity-mismatch',genuine,'failed','negative-mismatch',negative=dict(phase='runtime',type='TypeError'),positive='genuine-identity',raw_identity=('RenamedAggregateError','AggregateError'))
add('fake-own-name-constructor',fake_own,'failed','fake-identity-refusal',negative=dict(phase='runtime',type='AggregateError'),positive='genuine-identity',raw_identity=('AggregateError',''))
add('fake-prototype',fake_proto,'failed','fake-identity-refusal',negative=dict(phase='runtime',type='AggregateError'),positive='genuine-identity',raw_identity=('AggregateError',''))
assert len(new)==10
old=json.loads((P/'common-ordinary-controls.json').read_bytes())['rows'];records=[]
def observation(expected,kind,raw_identity):
 if kind=='semantic-pass':return dict(status='complete',phase='runtime',error_type='',error_identity='',harness='')
 diagnostic,identity=raw_identity if raw_identity is not None else ('Test262Error','')
 return dict(status='exception',phase='runtime',error_type=diagnostic,error_identity=identity,harness='')
def make(row,mode,origin):
 name=row['name'];source=row['source'];includes=row.get('includes',(['propertyHelper.js'] if 'property-' in name else []))
 metadata=dict(flags=[],includes=includes,features=[],locale=[],negative=row.get('negative'))
 harness=[dict(name=n,sha256=sha((P/'data/harness'/n).read_bytes())) for n in ['assert.js','sta.js']+includes]
 identity=dict(source_sha256=sha(source.encode()),mode=mode,metadata=metadata,harness=harness)
 kind=row.get('verification_kind','semantic-pass' if row['expected']=='passed' else 'assertion-mismatch')
 path=C/'raw'/f'{name}.js';path.parent.mkdir(parents=True,exist_ok=True)
 if path.exists():assert path.read_bytes()==source.encode()
 else:path.write_bytes(source.encode())
 return dict(name=name,mode=mode,id=f'harness-preflight:{name}'+(':'+mode if origin=='new-selected' else ''),file='<preflight>',origin=origin,source=source,source_sha256=identity['source_sha256'],case_sha256=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()),metadata=metadata,harness=harness,source_file=bind(path),expected=row['expected'],verification_kind=kind,required_observation=observation(row['expected'],kind,row.get('raw_identity')),positive_name=row.get('positive'))
for row in old:records.append(make(row,row['mode'],'existing-ordinary'))
for row in new:
 for mode in ('sloppy','strict'):records.append(make(row,mode,'new-selected'))
assert len(records)==52 and len({(x['name'],x['mode']) for x in records})==52
by={(x['name'],x['mode']):x for x in records}
def ref(row):return {k:row[k] for k in ('name','mode','id','case_sha256','source_sha256','expected')}
for row in records:
 prerequisites=[]
 if row['origin']=='existing-ordinary' and row['expected']=='failed':
  core=row['name'].removeprefix('strict-');prefix='strict-' if row['mode']=='strict' else ''
  positive='throws-success' if core.startswith('throws-') else 'property-success' if core.startswith('property-') else 'success'
  prerequisites=[ref(by[(prefix+positive,row['mode'])])]
 elif row['origin']=='new-selected':
  prerequisites=[ref(x) for x in records[:32]]
  if row['positive_name'] is not None:prerequisites.append(ref(by[(row['positive_name'],row['mode'])]))
 row['prerequisites']=prerequisites
 del row['positive_name']
# Exact common extraction is preserved, including absence of completion_policy/timeout.
for a,b in zip(old,records[:32]):
 assert all(a[k]==b[k] for k in ('name','mode','source','expected'))
 assert b['metadata']==dict(flags=[],includes=['propertyHelper.js'] if 'property-' in a['name'] else [],features=[],locale=[],negative=None)
 assert 'completion_policy' not in b and 'timeout' not in b['metadata']
for positive,negative in [('metadata','metadata-mismatch'),('iteration-and-data','iteration-and-data-mismatch'),('helper-sequence','helper-sequence-mismatch')]:
 a=by[('aggregate-error-'+positive,'sloppy')]['source'];b=by[('aggregate-error-'+negative,'sloppy')]['source']
 diff=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=positive,tofile=negative))
 path=C/'pair-diffs'/f'{positive}.patch';path.parent.mkdir(parents=True,exist_ok=True);path.write_text(diff)
put('variants.json',dict(status='frozen_pre_execution_source_derived',profile='aggregate-error',records=records))
put('expectations.json',dict(status='derived_before_execution',common_records=32,new_records=20,total_records=52,complete_success_rows=sum(r['required_observation']['status']=='complete' for r in records),exception_rows=sum(r['required_observation']['status']=='exception' for r in records),derivations=[
 dict(control='metadata',positive=2,mismatch=3,basis='Saved constructor length is2; descriptor checks use restore:true and retain name/prototype. isConstructor(A) true and arrow false exercise both helper paths.'),
 dict(control='iteration-and-data',positive='MCIiNSDVSD',mismatch='MICiNSDVSD',steps=['message ToString M','cause Get C after presence','iterator method Get I','iterator method Call i','cached next Get N','first next Call S','first done Get D false','first value Get V payload','second cached next Call S','second done Get D true; poisoned value not read'],data='Fresh dense intrinsic Array length1 with identical payload and default own index data descriptor; hidden writable/configurable errors own property.'),
 dict(control='helper-sequence',positive=[1,2,3],mismatch=[1,3,2],basis='checkSequence compares each reached element to index+1. Positive reaches return true; mismatch throws Test262Error at index1 after independently checked compareArray success/equal/unequal paths.'),
 dict(control='genuine-identity',negative_positive='AggregateError',negative_mismatch='TypeError',diagnostic='RenamedAggregateError',intrinsic='AggregateError',basis='Both rows have identical JS bytes. Only expected-negative type differs. Runtime throw_metadata reads stored constructor.name for diagnostics but authenticates existing private brand against Native internal name and Window receiver.'),
 dict(control='fake-own-name-constructor',expected_negative='AggregateError',diagnostic='AggregateError',intrinsic='',basis='Ordinary object has no intrinsic_error brand; copying a name and canonical constructor does not create it.'),
 dict(control='fake-prototype',expected_negative='AggregateError',diagnostic='AggregateError',intrinsic='',basis='Object.create inherits canonical constructor but has no private ErrorData brand.')
 ],message_field='Human diagnostic message is deliberately not an exact oracle. Required raw fields are status/phase/error_type/error_identity/harness; transport schema still validates message as bounded UTF-8.',no_observation_inputs=True))
put('gate-contract.json',dict(status='selected_scope_concrete_control_contract_no_runner_implementation',profile='aggregate-error',proposed_signature='aggregate_error_preflight_healthy(outcomes, files)',canonical_inputs='Rebuild all52 expected cases from these exact source/metadata records and authenticated helper bytes; do not duplicate frozen digest constants in runner production.',required_checks=['Every52 name/mode pair exactly once, no extras; expected/id/file/mode/case_sha256/source_sha256/expected_negative must match canonical case.','Every result must contain actual ordinary observation with exact five required fields; never trust verified alone or failurestatus alone.','New-profile controls, including existing32 literals, use selected ordinary decoder route. ERJR3 must reject before old decoder delegation. Existing one-argument callers/mocks and old gates remain unchanged.','Recompute classification from canonical expected-negative metadata and raw observation, and require exact expected classification.','All prerequisite records must link exact source/case/name/mode/id/expected identity and be healthy independently. Evaluate acyclic common positives/common negatives/new positives/new negatives; no trusting supplied prerequisite verified flags.','All32 common controls are prerequisites for each new row; every mismatch/refusal additionally binds a successful same-mode positive.','Source/helper mutation, missing API, unsupported/resource/timeout/adapter-error, wrong phase/identity or forged metadata cannot verify a negative control.','Failure blocks all50 upstream rows and baseline recording.'],protocol='ERJS1/ERJR2 only, no completion evidence or host hook requirement',old_control_preservation='Original32 source/mode/metadata/case fingerprints unchanged. Added gate/prerequisite validation is scoped solely to aggregate-error.'))
source_bindings=[]
for rel in ['tools/test262_conformance.py','src/script/throw_metadata.rs','src/script/aggregate_error.rs','src/script/aggregate_error/install.rs','src/script.rs','src/bin/eris-js.rs']:
 assert (W/rel).read_bytes()==(P/'source-snapshots'/rel).read_bytes()
 source_bindings.append(dict(relative=rel,published_path=str(W/rel),binding=bind(P/'source-snapshots'/rel)))
for helper in ['assert.js','sta.js','propertyHelper.js','isConstructor.js','compareArray.js','promiseHelper.js']:
 source_bindings.append(dict(relative='harness/'+helper,binding=bind(P/'data/harness'/helper)))
put('source-bindings.json',dict(parent='d3efc9aba87102366b538ff69e83c2524a48eb6b',published_refresh=bind(P/'published-base-refresh-1/source-ready.json'),selected_scope=bind(P/'root/selection-1.json'),common_literals=bind(P/'common-ordinary-controls.json'),rows=source_bindings))
print('drafted52 full source/metadata/identity/observation records; no execution')
