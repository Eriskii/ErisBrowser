assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');
var result = AggregateError([1, 2, 3]);
assert.sameValue(Array.isArray(result.errors), true);
assert.compareArray(result.errors, [1, 2, 3]);
assert.sameValue(compareArray([1, 2], [1, 2]), true);
assert.sameValue(compareArray([1, 2], [2, 1]), false);
checkSequence([1, 3, 2]);
