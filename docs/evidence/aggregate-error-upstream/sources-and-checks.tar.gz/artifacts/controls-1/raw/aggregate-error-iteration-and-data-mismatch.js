assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');
var A = AggregateError, trace = '', payload = {}, cause = {}, steps = 0;
var message = {toString: function () { trace += 'M'; return 'message'; }};
var options = {}, iterator = {}, source = {};
Object.defineProperty(options, 'cause', {get: function () { trace += 'C'; return cause; }});
Object.defineProperty(iterator, 'next', {get: function () {
  trace += 'N';
  return function () {
    trace += 'S';
    steps++;
    if (steps === 1) return {
      get done() { trace += 'D'; return false; },
      get value() { trace += 'V'; return payload; }
    };
    return {
      get done() { trace += 'D'; return true; },
      get value() { throw new Test262Error('exhausted value read'); }
    };
  };
}});
Object.defineProperty(source, Symbol.iterator, {get: function () {
  trace += 'I';
  return function () { trace += 'i'; return iterator; };
}});
AggregateError = function () { throw new Test262Error('replacement global called'); };
var result = A(source, message, options), values = result.errors;
assert.sameValue(Object.getPrototypeOf(result), A.prototype);
assert.sameValue(result.message, 'message');
assert.sameValue(result.cause, cause);
assert.sameValue(Array.isArray(values), true);
assert.sameValue(Object.getPrototypeOf(values), Array.prototype);
assert.sameValue(values.length, 1);
assert.sameValue(values[0], payload);
assert.sameValue(Object.prototype.hasOwnProperty.call(values, '0'), true);
var slot = Object.getOwnPropertyDescriptor(values, '0');
assert.sameValue(slot.value, payload);
assert.sameValue(slot.writable && slot.enumerable && slot.configurable, true);
verifyProperty(result, 'errors', {value: values, writable: true, enumerable: false, configurable: true}, {restore: true});
assert.sameValue(steps, 2);
assert.sameValue(trace, 'MICiNSDVSD');
