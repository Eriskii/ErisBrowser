assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');
throw {name: 'AggregateError', constructor: AggregateError};
