assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');
throw Object.create(AggregateError.prototype);
