assert.sameValue(typeof AggregateError, 'function', 'AggregateError availability');
var A = AggregateError;
var value = new A([1], 'aggregate identity control');
Object.defineProperty(A, 'name', {value: 'RenamedAggregateError', writable: false, enumerable: false, configurable: true});
throw value;
