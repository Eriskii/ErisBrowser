import ast,difflib,hashlib,json,re,subprocess
from pathlib import Path
U=Path('/tmp/eris-aggregate-error-upstream-plan-1'); W=U/'worktree'; BASE='d3efc9aba87102366b538ff69e83c2524a48eb6b'
def h(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p); b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=h(b))
def check(b):
 p=Path(b['path']);assert bind(p)==b;return p.read_bytes()
def published(rel):return subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
def reverse_patch(raw,patch):
 lines=raw.splitlines(keepends=True);out=[];i=0;sections=patch.splitlines(keepends=True);j=2
 while j<len(sections):
  m=re.match(r'@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@',sections[j]);assert m
  start=int(m[2])-1;out+=lines[i:start];i=start;j+=1
  while j<len(sections) and not sections[j].startswith('@@ '):
   s=sections[j];j+=1
   if s[0] in ' +': assert lines[i]==s[1:];i+=1
   if s[0] in ' -':out.append(s[1:])
 out+=lines[i:];return ''.join(out)
def assigned(tree,name):
 return next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id==name for t in n.targets))
m=json.loads((U/'implementation-importer-1/source-ready.json').read_text());raw=check(m['payload']).decode();patch=check(m['diff']).decode();before=published('tools/import_test262.py');assert h(before)==m['source_before']['sha256'];assert reverse_patch(raw,patch).encode()==before
old=ast.parse(before);new=ast.parse(raw)
of={n.name:ast.get_source_segment(before.decode(),n) for n in old.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};nf={n.name:ast.get_source_segment(raw,n) for n in new.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert of.keys()==nf.keys();changed=[k for k in of if of[k]!=nf[k]];assert changed==['profile_tree_inventory','import_corpus']
# Every old table element retains its exact AST value.
for name in ['PROFILES','PROFILE_ROOTS']:
 a=assigned(old,name);b=assigned(new,name); pairs=lambda x:{ast.literal_eval(k):ast.dump(v) for k,v in zip(x.keys,x.values)}
 x,y=pairs(a),pairs(b);assert set(y)-set(x)=={'aggregate-error'};assert all(y[k]==v for k,v in x.items())
assert ast.literal_eval(assigned(new,'TREE_PROFILES'))-{'aggregate-error'}==ast.literal_eval(assigned(old,'TREE_PROFILES'))
dirs=ast.literal_eval(assigned(new,'AGGREGATE_ERROR_DIRECTORIES'));helpers=ast.literal_eval(assigned(new,'AGGREGATE_ERROR_HELPERS'))
assert dirs=={'AggregateError':19,'AggregateError/prototype':6};assert helpers=={'assert.js','sta.js','propertyHelper.js','compareArray.js','isConstructor.js','promiseHelper.js'}
# Reconstruct all Git tree bodies and source/blob ancestry independently.
C=U/'corpus-expected-1/raw/tests/upstream/test262-aggregate-error'; proofs={str(p.relative_to(C)):p.read_bytes() for p in sorted((C/'inventory-proof').glob('*.json'))};assert len(proofs)==7
trees={}
for path,b in proofs.items():
 d=json.loads(b)
 if '/tree-' not in path:continue
 rows=d['tree'];assert d['truncated'] is False;parts=[]
 for e in rows:
  name=e['path'].encode();parts.append((name+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+name+b'\0'+bytes.fromhex(e['sha'])))
 body=b''.join(v for _,v in sorted(parts));assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==d['sha'];trees[d['sha']]={e['path']:e for e in rows}
commit=json.loads(proofs['inventory-proof/commit.json']);rev=ast.literal_eval(assigned(new,'REVISION'));root=ast.literal_eval(assigned(new,'REVISION_TREE'));assert commit['sha']==rev and commit['tree']['sha']==root
mapped={};inventory={};source_blobs={}
for directory,count in dirs.items():
 sha=root
 for name in ('test/built-ins/'+directory).split('/'):
  e=trees[sha][name];assert e['type']=='tree';sha=e['sha']
 mapped[directory]=sha;entries=trees[sha];children={k for k,e in entries.items() if e['type']=='tree'};selected={n[len(directory)+1:] for n in dirs if n.startswith(directory+'/') and '/' not in n[len(directory)+1:]};assert children==selected
 names=sorted(k for k,e in entries.items() if e['type']=='blob' and k.endswith('.js'));assert len(names)==count;inventory[directory]=names
 for name in names:source_blobs['test/built-ins/'+directory+'/'+name]=entries[name]['sha']
harness=trees[trees[root]['harness']['sha']];aux={('harness/'+n):harness[n]['sha'] for n in sorted(helpers)};aux.update({n:trees[root][n]['sha'] for n in ['LICENSE','INTERPRETING.md']});source_blobs.update(aux)
for path,sha in source_blobs.items():
 b=(C/path).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==sha;assert b==(U/'data'/path).read_bytes()
for path,b in proofs.items():assert b==(U/path).read_bytes()
# Rebuild field insertion and sorted rows dictated by the unchanged writer.
scopes=next(n.value for n in ast.walk(new) if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='scope' for t in n.targets));scope=ast.literal_eval(scopes.value)['aggregate-error'];assert scope==json.loads((U/'plan.json').read_text())['scope_literal_proposed']
manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=rev,scope=scope,directories=inventory,test_files=25,files=[])
manifest['inventory_proof']=dict(method='complete-nonrecursive-git-trees',revision=rev,root_tree=root,directory_trees=mapped,auxiliary_blobs=aux,files=[])
for path,b in sorted(proofs.items()):
 route='commits/'+rev if path.endswith('/commit.json') else 'trees/'+Path(path).name.removeprefix('tree-').removesuffix('.json')
 manifest['inventory_proof']['files'].append(dict(path=path,bytes=len(b),sha256=h(b),url='https://api.github.com/repos/tc39/test262/git/'+route))
for path in sorted(source_blobs):
 b=(C/path).read_bytes();manifest['files'].append(dict(path=path,upstream_path=path,bytes=len(b),sha256=h(b)))
encoded=(json.dumps(manifest,indent=2)+'\n').encode();assert encoded==(C/'manifest.json').read_bytes();assert len(list(C.rglob('*')))>41;assert len([p for p in C.rglob('*') if p.is_file()])==41
receipt=dict(status='source_clear',reviewer='/root/script',mode='Independent static/stdlib review; no project import, execution or live edit.',bindings=[bind(U/'implementation-importer-1/source-ready.json'),bind(U/'corpus-expected-1/source-ready.json'),bind(U/'root/selection-1.json'),bind(U/'source-parent.json')],checks=dict(published_before_sha256=h(before),patch_inverse_exact=True,changed_functions=changed,old_tables_preserved=True,shared_authentication_and_serialization_bodies_unchanged=True,authenticated_trees=6,raw_source_blobs=25,helpers=6,legal=2,proof_documents=7,complete_immediate_counts=dirs,all_descendant_directories_required=True,manifest_bytes=len(encoded),manifest_sha256=h(encoded),independent_manifest_reconstruction_byte_exact=True,corpus_files=41),qualification='This proves source fit and inert reconstruction against authenticated held bytes, not execution of the importer. Runtime/import replay remains root-owned.',findings=[])
(U/'implementation-importer-1/script-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
# All adapter deltas are exactly the selected line additions; no expected data changes.
lm=json.loads((U/'legacy-adapters-1/source-ready.json').read_text());plan=json.loads((U/'legacy-adapters.json').read_text());planned={r['path']:r for r in plan['rows']};results=[]
for r in lm['payloads']:
 rel=r['relative_path'];b=published(rel);assert h(b)==r['before']['sha256'];s=check(r['raw']).decode();d=check(r['diff']).decode();assert reverse_patch(s,d).encode()==b;ast.parse(s)
 prior=b.decode();assert prior.count("'aggregate-error'")==0
 reverted=s.replace(", 'aggregate-error'",'').replace("'aggregate-error', ",'')
 if rel.endswith('promise_all_settled_profile.py'):reverted=reverted.replace('if k not in {PROFILE}', 'if k != PROFILE')
 assert reverted==prior
 changes=[line[1:] for line in d.splitlines() if line.startswith('-') and not line.startswith('---')];assert changes==[e['source'] for e in planned[rel]['entries']]
 assert s.count("'aggregate-error'")==r['selected_entries']==len(changes)
 results.append(dict(path=rel,entries=len(changes),before_sha256=h(b),raw_sha256=h(s.encode()),inverse_exact=True))
assert len(results)==17 and sum(r['entries'] for r in results)==24
cm=json.loads((U/'ci-1/source-ready.json').read_text());cb=published('.github/workflows/check.yml');assert h(cb)==cm['before']['sha256'];cs=check(cm['raw']).decode();cd=check(cm['diff']).decode();assert reverse_patch(cs,cd).encode()==cb
added=[x[1:] for x in cd.splitlines() if x.startswith('+') and not x.startswith('+++')];assert len(added)==2 and '--binary target/release/eris-js --profile aggregate-error --baseline tests/conformance/test262-aggregate-error-current.json --output artifacts/test262-aggregate-error-gate.json' in added[1]
assert cs.index('cargo build --locked --release')<cs.index(added[0])
receipt=dict(status='source_clear',reviewer='/root/script',mode='Independent static/stdlib review; no project import, execution or live edit.',bindings=[bind(U/'legacy-adapters-1/source-ready.json'),bind(U/'legacy-adapters.json'),bind(U/'ci-1/source-ready.json'),bind(U/'root/selection-1.json')],paths=17,entries=24,adapters=results,checks=['Every before blob matches published d3efc9ab.','Every patch reconstructs parent exactly.','Each changed old line matches the selected census.','Only aggregate-error historical exclusions added; all prior expected numbers, fingerprints, assertions and test declarations exact.','CI adds exactly one two-line ordinary-adapter gate after existing release build; every old workflow byte recovered by inverse.'],ci=dict(added_lines=added,ordinary_binary=True,baseline='tests/conformance/test262-aggregate-error-current.json',qualification='Command source is clear; healthy measured baseline and actual execution remain pending/root-owned.'),findings=[])
(U/'legacy-adapters-1/script-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
for name in ['implementation-importer-1/script-review.json','legacy-adapters-1/script-review.json']:print(json.dumps(bind(U/name)))
