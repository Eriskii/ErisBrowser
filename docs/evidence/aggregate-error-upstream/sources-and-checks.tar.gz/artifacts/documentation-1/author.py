"""External documentation authoring from retained actual receipts; stdlib only."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import re

P = Path('/tmp/eris-aggregate-error-upstream-plan-1')
H = P / 'documentation-1'
W = P / 'worktree'
BASE = 'd3efc9aba87102366b538ff69e83c2524a48eb6b'

def digest(b):
    return hashlib.sha256(b).hexdigest()

def bind(f):
    b = f.read_bytes()
    return dict(path=str(f), bytes=len(b), sha256=digest(b))

def load(rel):
    return json.loads((P / rel).read_bytes())

def write(rel, data):
    f = H / rel
    f.parent.mkdir(parents=True, exist_ok=True)
    f.write_text(data if isinstance(data, str) else json.dumps(data, indent=2) + '\n')

assert not (H / 'source-ready.json').exists()
ledger = load('root/profile-validation.json')
assert ledger['status'] == 'pass'
# Read and authenticate the actual reports and binaries, rather than only summary counts.
all_receipts = []
def check_binding(row):
    f = Path(row['path']); b = f.read_bytes()
    assert len(b) == row['bytes'] and digest(b) == row['sha256'], f
    all_receipts.append(bind(f))
    return b

new = ledger['new_profile']
first = json.loads(check_binding(new['report']))
replay = json.loads(check_binding(new['replay']))
baseline = json.loads(check_binding(new['baseline']))
check_binding(new['binary'])
assert len(first['cases']) == 50 and len(first['harness_preflight']) == 52
assert Counter(row['status'] for row in first['cases']) == {'passed':44,'failed':4,'unsupported':2}
assert first['counts'] == new['counts'] == {'passed':44,'failed':4,'unsupported':2}
assert first['harness_preflight_passed'] is True
assert all(row['verified'] is True for row in first['harness_preflight'])
for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:
    assert first[key] == replay[key], key
assert replay['regressions'] == replay['improvements'] == []
assert first['binary_sha256'] == replay['binary_sha256'] == new['binary']['sha256']
assert first['runner_policy_sha256'] == 'd3fe422ab0532bbe29312f1aeaae90f26589cc7bd16c85699ad07dea49ae1a84'
assert len(first['runner_policy']['negative_intrinsic_errors']) == 8
assert first['runner_policy']['async_completion'] is False and first['runner_policy']['host_hooks'] is False
assert all('completion_policy' not in row for row in first['cases'])
expected_baseline = dict(revision=first['revision'],corpus_manifest_sha256=first['corpus_manifest_sha256'],
    runner_policy_sha256=first['runner_policy_sha256'],binary_sha256=first['binary_sha256'],
    cases={row['id']:{k:row[k] for k in ['status','case_sha256','source_sha256']} for row in first['cases']})
assert baseline == expected_baseline
assert (W/'tests/conformance/test262-aggregate-error-current.json').read_bytes() == Path(new['baseline']['path']).read_bytes()
proxy_names = {'test/built-ins/AggregateError/newtarget-proto-custom.js','test/built-ins/AggregateError/newtarget-proto-fallback.js'}
for row in first['cases']:
    if row['status'] == 'failed':
        assert row['file'] in proxy_names
        assert row['observation'] == dict(status='exception',phase='runtime',error_type='ReferenceError',
            error_identity='ReferenceError',message="'Proxy' is not defined",harness='')
    elif row['status'] == 'unsupported':
        assert row['file'] == 'test/built-ins/AggregateError/proto-from-ctor-realm.js'
        assert row['reason'] == 'unimplemented declared features: cross-realm'
    else:
        assert row['status'] == 'passed'
held_cases = load('case-identities.json')['rows']
assert [(r['id'],r['case_sha256']) for r in first['cases']] == [(r['id'],r['case_sha256']) for r in held_cases]
old_cases = old_controls = 0
for entry in ledger['old_profiles']:
    old = json.loads(check_binding(entry['parent']))
    actual = json.loads(check_binding(entry['actual']))
    for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts']:
        assert old[key] == actual[key], (entry['profile'], key)
    assert actual['regressions'] == actual['improvements'] == []
    assert actual['harness_preflight_passed'] is True and all(r['verified'] is True for r in actual['harness_preflight'])
    assert actual['binary_sha256'] == '8b2898393aed16e9e7e98908e8284805e5a4dd71d445b3fcb66eaf5451ec375b'
    old_cases += len(actual['cases']); old_controls += len(actual['harness_preflight'])
assert (old_cases,old_controls) == (1050,348)
assert ledger['old_baselines_changed'] is False
# Check build/test execution receipts and their actual terminal logs.
labels = ['python-full-1','parent-python-full-1','parent-preservation-1','parent-profile-tests-1',
          'parent-importer-tests-1','profile-tests-1','importer-tests-1','importer-reproduction-1',
          'parent-ordinary-release-1','upstream-aggregate-error-1','upstream-aggregate-error-replay-1']
logs = {}
for label in labels:
    receipt = load('validation/'+label+'.json')
    log = P / 'validation' / receipt['log']
    data = log.read_bytes()
    assert digest(data) == receipt['sha256'],label
    logs[label] = data.decode()
    all_receipts.extend([bind(P/'validation'/f'{label}.json'),bind(log)])
assert load('validation/python-full-1.json')['exit'] == 0
assert re.search(r'Ran 592 tests in .*\n\nOK\s*$', logs['python-full-1'])
roster = re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. ok$', logs['python-full-1'], re.M)
assert len(roster) == len(set(roster)) == 592
pres = [x for x in roster if x.startswith('test_test262_aggregate_error_preservation.')]
imp = [x for x in roster if x.startswith('test_import_test262_aggregate_error.')]
prof = [x for x in roster if x.startswith('test_test262_aggregate_error_profile.')]
assert (len(pres),len(imp),len(prof)) == (4,6,13)
parent_roster = re.findall(r'^test_\S+ \(([^\n]+)\) \.\.\. ok$', logs['parent-python-full-1'], re.M)
assert len(parent_roster) == 573 and set(parent_roster) < set(roster)
assert set(roster)-set(parent_roster) == set(imp+prof)
for label in ['parent-preservation-1','profile-tests-1','importer-tests-1','importer-reproduction-1',
              'parent-ordinary-release-1','upstream-aggregate-error-1','upstream-aggregate-error-replay-1']:
    assert load('validation/'+label+'.json')['exit'] == 0,label
parent_profile = load('root/parent-profile-summary-1.json')
assert (len(parent_profile['passed']),len(parent_profile['failure_groups']),len(parent_profile['error_groups'])) == (1,3,9)
ordinary = load('eris-js-parent-ordinary-1.json')
assert ordinary['base'] == BASE and ordinary['binary'] == new['binary']
assert '--features' not in load('validation/parent-ordinary-release-1.json')['command']
parent_src = load('source-parent.json')['source_sha256']; final_src = load('source-final.json')['source_sha256']
assert len(parent_src) == 1682 and len(final_src) == 1730
changed = [k for k in parent_src if parent_src[k] != final_src.get(k)]
assert len(changed) == 20 and all(k.startswith('tools/') or k=='.github/workflows/check.yml' for k in changed)
for k,v in parent_src.items():
    if k.endswith('.rs') or k.endswith('Cargo.toml') or k.endswith('Cargo.lock'):
        assert final_src[k] == v,k
summary = load('root/source-final-summary.json'); assert summary['runtime_unchanged'] is True
assert (len(summary['changed_existing']),len(summary['new']),summary['changed_paths']) == (20,48,68)
# Final prose is authored from the actual checked observations above.
chapter = '''# AggregateError upstream results

The complete pinned Test262 AggregateError subtree contains **25 sources and
50 required sloppy/strict modes**. Eris records **44 passed, four failed and
two unsupported**, with all **52 controls verified**. Every selected mode stays
in the denominator. This is a bounded selection, not full ECMAScript conformance.

The [manifest](../tests/upstream/test262-aggregate-error/manifest.json) binds
19 constructor-directory sources, six prototype sources, six unchanged helpers,
two legal/instruction files and seven complete nonrecursive proof documents.
Together with the manifest these are 41 files, pinned to revision
`7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`. No source or mode is removed because
of its feature tags or result.

The four failures are both modes of `newtarget-proto-custom.js` and
`newtarget-proto-fallback.js`. These untagged Proxy cases reach the adapter and
report a runtime `ReferenceError`, with intrinsic identity `ReferenceError`
and message `'Proxy' is not defined`. They remain failed cases. Both modes of
`proto-from-ctor-realm.js` remain unsupported because their metadata declares
`cross-realm`; their bodies are not dispatched.

The new profile uses ordinary ERJS1 requests and ERJR2 responses. Only
`aggregate-error` accepts the eighth intrinsic identity, `AggregateError`.
The default decoder, all 57 older profiles and every ERJR3 validator keep the
seven-name policy. The selected decoder rejects ERJR3 before delegation.
This changes no transport bytes or final-unhandled-rejection policy.

The gate combines 32 unchanged ordinary controls with 20 new mode rows covering
metadata, iterable data, the sequence helper, genuine error identity and forged
name/prototype objects. It rebuilds canonical source/helper identities and
checks actual observations, classification and prerequisite links independently.
A supplied verified flag or generic failure is insufficient. Any unhealthy or
malformed gate blocks all 50 cases and baseline recording.

All **592 Python tests pass**, including four new preservation, six importer
and thirteen profile groups. The importer reproduces every byte of the frozen
41-file corpus. Parent profile tests recorded one pass, three failing groups
and nine error groups at the missing-profile boundaries; later checks are not
claimed as reached. A retained parent-control invocation used an unsupported
CLI flag and was corrected before any control ran; literals were unchanged.

The measured baseline and replay retain the exact 50 case and 52 control
records, including the four failures and two exclusions. Both commands exit
successfully with healthy controls; that does not mean every upstream case
passed. The [baseline](../tests/conformance/test262-aggregate-error-current.json)
is the measured status/identity projection, with no manual outcome filtering.

Rust execution inputs are unchanged. The ordinary adapter was built with
Rust 1.88 in release mode, without optional features, from the published
[API checkpoint](aggregate-error.md) at `d3efc9aba871`. The four older Promise
profiles reuse that checkpoint's published `test262-host` adapter. Their full
**1,050 case and 348 control records** match the parent, including failures and
unsupported outcomes; no old policy or baseline changes. This checkpoint makes
no new full Rust-suite or Clippy claim. Binary identities and build logs are
bound in the evidence.

The adjacent ordinary CI gate uses this baseline. To reproduce it after
building the ordinary release adapter:

```sh
python3 tools/test262_conformance.py --binary target/release/eris-js \\
  --profile aggregate-error \\
  --baseline tests/conformance/test262-aggregate-error-current.json
```

No remote CI result is claimed here. `Promise.any`, Proxy and multiple realms
remain unfinished; these observations establish no production security,
CPU/GPU performance result or process-memory bound. The
[evidence manifest](evidence/aggregate-error-upstream/manifest.json) and
[source/check archive](evidence/aggregate-error-upstream/sources-and-checks.tar.gz)
retain the sources, controls, raw observations and validation receipts.
'''
assert 60 <= len(chapter.splitlines()) <= 90
validation = '''## Complete pinned AggregateError selection

The [AggregateError upstream profile](aggregate-error-upstream.md) retains all
25 sources and 50 modes. It records **44 passed, four failed and two unsupported**,
with all 52 controls verified. The four dispatched Proxy modes report runtime
ReferenceError; the two cross-realm modes are metadata exclusions.

All 592 Python tests pass. Healthy baseline recording and replay preserve the
exact 50 case and 52 control records, including nonpassing outcomes. The older
four Promise profiles retain all 1,050 case and 348 control records, with no old
policy or baseline changes. Only the new ordinary profile accepts an eighth
intrinsic error identity; default decoding and all ERJR3 validators retain seven.

The ordinary Rust 1.88 release adapter was built from the published API parent
without optional features; older Promise replays reuse the published host
adapter. Rust execution inputs are unchanged, and no new full Rust-suite or
Clippy run is claimed. The chapter's evidence retains parent stopping points,
raw results and binary bindings; the historical sections below stay unchanged.

'''
plan = load('documentation-plan-1/patch-plan.json')
original = {}
for row in load('documentation-plan-1/inputs.json'):
    f = Path(row['current']['path']); b=f.read_bytes()
    assert digest(b)==row['current']['sha256']
    original[row['relative_path']] = b.decode()
result = {}
for change in plan['changes']:
    name, anchor = change['path'], change['anchor']
    before = original[name]; assert before.count(anchor)==1
    if name == 'docs/VALIDATION.md':
        after=before.replace(anchor,anchor+validation,1)
    elif change['operation'].startswith('insert_'):
        after=before.replace(anchor,anchor+change['proposed'],1)
    else:
        after=before.replace(anchor,change['proposed'],1)
    result[name]=after
result['docs/aggregate-error-upstream.md']=chapter
assert result['docs/VALIDATION.md'].endswith(original['docs/VALIDATION.md'].split('\n\n',1)[1])
assert result['docs/aggregate-error.md'].endswith(original['docs/aggregate-error.md'].split('\n\n',1)[1])
assert len(result)==7
payloads=[]
for name,after in result.items():
    assert 'PENDING_' not in after
    before=original.get(name,'')
    if name in original: write('before/'+name,before)
    write('raw/'+name,after)
    diff=''.join(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
            fromfile='a/'+name if name in original else '/dev/null',tofile='b/'+name))
    write('diffs/'+name+'.patch',diff)
    payloads.append(dict(relative_path=name,before=bind(H/'before'/name) if name in original else None,
                         raw=bind(H/'raw'/name),diff=bind(H/'diffs'/(name+'.patch'))))
# Verify every new relative link resolves, except the two selected future archive publication paths.
future={'docs/evidence/aggregate-error-upstream/manifest.json','docs/evidence/aggregate-error-upstream/sources-and-checks.tar.gz'}
links=[]
for name,after in result.items():
    before=original.get(name,'')
    old_links=set(re.findall(r'\]\(([^)]+)\)',before))
    for target in sorted(set(re.findall(r'\]\(([^)]+)\)',after))-old_links):
        if '://' in target or target.startswith('#'): continue
        target=target.split('#',1)[0]
        resolved=(W/Path(name).parent/target).resolve()
        rel=resolved.relative_to(W.resolve()).as_posix()
        assert rel in result or resolved.exists() or rel in future,(name,target)
        links.append(dict(from_file=name,target=target,resolved=rel,future_publication=rel in future))
write('links.json',links)
write('claim-checks.json',dict(status='all_prose_claims_bound_to_actual_receipts',
    new_profile=dict(sources=25,modes=50,counts=first['counts'],verified_controls=52,
                     full_cases_and_controls_equal_replay=True,baseline_exact_projection=True,
                     failed_source_names=sorted(proxy_names),unsupported_reason='unimplemented declared features: cross-realm'),
    python=dict(total=592,preservation=4,importer=6,profile=13,parent_profile_groups=dict(passed=1,failed=3,errors=9)),
    previous=dict(cases=1050,controls=348,full_arrays_exact=True,old_baselines_changed=False),
    binary=dict(ordinary=new['binary'],ordinary_build=ordinary,host_sha256='8b2898393aed16e9e7e98908e8284805e5a4dd71d445b3fcb66eaf5451ec375b'),
    source=dict(parent_selected=1682,final_selected=1730,changed_existing=20,new=48,runtime_unchanged=True),
    historical_validation_suffix_exact=True,historical_aggregate_error_body_exact=True,
    new_chapter_lines=len(chapter.splitlines()),new_chapter_words=len(chapter.split()),
    limitations=['No new full Rust-suite or Clippy result claimed.','No pending remote CI success claimed.',
                 'No outcome filtering or reason-based reclassification.','No runtime/transport/cap/host-policy/security/performance expansion.']))
extra = ['root/profile-validation.json','root/source-final-summary.json','root/baseline-and-ci-import-1.json',
         'source-parent.json','source-final.json','eris-js-parent-ordinary-1.json','root/selection-2.json',
         'root/parent-profile-summary-1.json','root/parent-importer-summary-1.json','case-identities.json',
         'controls-1/source-ready.json','implementation-runner-2/source-ready.json',
         'tests-preservation-1/source-ready.json','tests-importer-1/source-ready.json','tests-profile-1/source-ready.json',
         'ci-1/source-ready.json','documentation-plan-1/source-ready.json','documentation-plan-1/inputs.json']
all_receipts.extend(bind(P/rel) for rel in extra)
# Include the actual installed baseline and host binary provenance without duplicating the binary.
all_receipts.append(bind(W/'tests/conformance/test262-aggregate-error-current.json'))
all_receipts.append(bind(Path('/tmp/eris-aggregate-error-plan-1/eris-js-host-final-1.json')))
unique={r['path']:r for r in all_receipts}
write('inputs.json',list(unique.values()))
files=[dict(relative_path=f.relative_to(H).as_posix(),**bind(f)) for f in sorted(H.rglob('*')) if f.is_file()]
write('source-ready.json',dict(status='sealed_external_final_documentation_actual_reports_no_live_edits',author='layout',
      published_parent=BASE,paths=7,payloads=payloads,claims=bind(H/'claim-checks.json'),links=bind(H/'links.json'),
      inputs=bind(H/'inputs.json'),files=files,
      history='Six existing documents use narrow current-summary updates or additive notes; old VALIDATION suffix and aggregate-error chapter body remain byte-exact.',
      execution='Source/data/log/hash inspection and external documentation authoring only. No project code, tests, compiler, formatter, network or live edits executed by author.',
      publication='Two evidence links target root-selected future archive paths; root owns import, archive and publication. No remote CI success claim.'))
print(json.dumps(bind(H/'source-ready.json')))
