"""Independent read-only source/report/documentation checks; no project imports."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess
U=Path('/tmp/eris-aggregate-error-upstream-plan-1');R=U/'documentation-review-1';W=U/'worktree'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
verified={}
def refs(d):
 if isinstance(d,dict):
  if all(k in d for k in ('path','bytes','sha256')) and isinstance(d['path'],str) and d['path'].startswith('/'):
   p=Path(d['path']);b=bind(p);assert all(b[k]==d[k] for k in ('path','bytes','sha256')),d['path'];verified[str(p)]=b
  for v in d.values():refs(v)
 elif isinstance(d,list):
  for v in d:refs(v)
seal=read(U/'documentation-1/source-ready.json');ledger=read(U/'root/final-validation.json');profile=read(U/'root/profile-validation.json')
for d in (seal,ledger,profile,read(U/'documentation-1/inputs.json')):refs(d)
assert ledger['upstream']==profile
assert seal['paths']==len(seal['payloads'])==7
base=seal['published_parent']
for row in seal['payloads']:
 relative=row['relative_path'];raw=Path(row['raw']['path']).read_text();before=Path(row['before']['path']).read_text() if row['before'] else ''
 if row['before']:
  assert subprocess.check_output(['git','-C',str(W),'show',f'{base}:{relative}'])==before.encode()
 expected=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+relative if row['before'] else '/dev/null',tofile='b/'+relative))
 assert expected==Path(row['diff']['path']).read_text(),relative
 if relative in ('docs/VALIDATION.md','docs/aggregate-error.md'):
  head,oldtail=before.split('\n',1)
  assert raw.startswith(head+'\n') and raw.endswith(oldtail),relative
p=profile['new_profile'];observed=read(Path(p['report']['path']));replay=read(Path(p['replay']['path']));baseline=read(Path(p['baseline']['path']))
assert observed['cases']==replay['cases'] and observed['harness_preflight']==replay['harness_preflight']
assert (observed['source_tests'],observed['mode_cases'],len(observed['cases']),len(observed['harness_preflight']))==(25,50,50,52)
assert dict(Counter(r['status'] for r in observed['cases']))==observed['counts']=={'passed':44,'failed':4,'unsupported':2}
assert observed['harness_preflight_passed'] is True and observed['full_test262_conformance'] is False
oracle=read(U/'tests-profile-1/raw/tools/aggregate-error-profile-oracle.json')
assert [dict((k,r[k]) for k in ('id','file','mode','case_sha256','source_sha256')) for r in observed['cases']]==oracle['case_identities']
for actual,frozen in zip(observed['harness_preflight'],read(U/'controls-1/variants.json')['records']):
 assert actual['verified'] is True and actual['name']==frozen['name'] and actual['expected']==frozen['expected']
 assert actual['prerequisites']==frozen['prerequisites']
 result=actual['result']
 for k in ('id','file','mode','case_sha256','source_sha256'):assert result[k]==frozen[k]
 assert result['expected_negative']==frozen['metadata']['negative'] and result['status']==frozen['expected']
 assert {k:result['observation'][k] for k in frozen['required_observation']}==frozen['required_observation']
 assert set(result['observation'])==set(frozen['required_observation'])|{'message'}
failed=[r for r in observed['cases'] if r['status']=='failed'];unsupported=[r for r in observed['cases'] if r['status']=='unsupported']
assert {r['file'] for r in failed}=={'test/built-ins/AggregateError/newtarget-proto-custom.js','test/built-ins/AggregateError/newtarget-proto-fallback.js'}
assert len(failed)==4 and all(r['observation']==dict(status='exception',phase='runtime',error_type='ReferenceError',error_identity='ReferenceError',message="'Proxy' is not defined",harness='') for r in failed)
assert len(unsupported)==2 and all(r['file']=='test/built-ins/AggregateError/proto-from-ctor-realm.js' and r['reason']=='unimplemented declared features: cross-realm' and 'observation' not in r for r in unsupported)
assert baseline['cases']=={r['id']:{k:r[k] for k in ('status','case_sha256','source_sha256')} for r in observed['cases']}
for k in ('revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256'):assert baseline[k]==observed[k]==replay[k]
assert all(not d['regressions'] and not d['improvements'] for d in (observed,replay))
old_cases=old_controls=0
for row in profile['old_profiles']:
 parent=read(Path(row['parent']['path']));actual=read(Path(row['actual']['path']))
 assert parent['cases']==actual['cases'] and parent['harness_preflight']==actual['harness_preflight']
 assert parent['runner_policy']==actual['runner_policy'] and parent['runner_policy_sha256']==actual['runner_policy_sha256']
 assert len(actual['cases'])==row['cases'] and len(actual['harness_preflight'])==row['controls']
 old_cases+=len(actual['cases']);old_controls+=len(actual['harness_preflight'])
assert (old_cases,old_controls)==(1050,348)
parent=read(U/'source-parent.json')['source_sha256'];final=read(U/'source-final.json')['source_sha256']
assert len(parent)==1682 and len(final)==1730 and parent.keys()<=final.keys()
changed={p for p in parent if parent[p]!=final[p]};new=final.keys()-parent.keys()
assert len(changed)==20 and len(new)==48
assert all(p.startswith('tools/') or p=='.github/workflows/check.yml' for p in changed)
assert all(p.startswith('tools/') or p.startswith('tests/upstream/test262-aggregate-error/') or p=='tests/conformance/test262-aggregate-error-current.json' for p in new)
assert final['tests/conformance/test262-aggregate-error-current.json']==sha(Path(p['baseline']['path']).read_bytes())
def names(path):
 text=path.read_text();names=re.findall(r'^test_\S+ \(([^)]+)\) \.\.\. ok$',text,re.M)
 assert len(names)==len(set(names));return set(names),text
old,oldtext=names(U/'validation/parent-python-full-1.log');now,text=names(U/'validation/python-full-1.log')
assert (len(old),len(now))==(573,592) and old<=now and len(now-old)==19
assert re.search(r'^Ran 592 tests in [0-9.]+s\n\nOK\n$',text,re.M)
assert now-old==set(ledger['python']['added_after_parent_roster'])
assert ledger['python']['new_groups_split']==dict(preservation=4,importer=6,profile=13)
parent_summary=read(U/'root/parent-profile-summary-1.json')
assert tuple(len(parent_summary[k]) for k in ('passed','failure_groups','error_groups'))==(1,3,9)
binary=read(U/'eris-js-parent-ordinary-1.json');refs(binary)
build=read(Path(binary['build']['path']))
assert build['exit']==0 and build['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--release','--bin','eris-js']
assert binary['source']['sha256']==sha((U/'source-parent.json').read_bytes()) and binary['base']==base
assert observed['binary_sha256']==binary['binary']['sha256']
assert ledger['checks']['upstream-aggregate-error-1']['exit']==ledger['checks']['upstream-aggregate-error-replay-1']['exit']==0
assert '--record-baseline' in read(U/'validation/upstream-aggregate-error-1.json')['command']
assert (U/'parent-controls-1/success-sloppy.response').read_bytes()==b''
assert '--test262' in (U/'root/observe-parent-controls.py').read_text()
assert '--test262' not in (U/'root/observe-parent-controls-2.py').read_text()
assert 'reads a single ERJS1 framed test request' in (U/'parent-controls-1/success-sloppy.stderr').read_text()
oldsrc=(U/'tests-preservation-1/source-snapshots/tools/test262_conformance.py').read_text();newsrc=(W/'tools/test262_conformance.py').read_text()
assert sha(newsrc.encode())==final['tools/test262_conformance.py']
def funcs(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
of,nf=funcs(oldsrc),funcs(newsrc)
for name in ('decode_promise_response','validate_promise_observation'):assert of[name]==nf[name]
assert "return names | {'AggregateError'} if profile == AGGREGATE_ERROR_PROFILE else names" in nf['profile_intrinsic_errors']
assert nf['decode_response'].index("if profile == AGGREGATE_ERROR_PROFILE")<nf['decode_response'].index("if output.startswith(b'ERJR3')")
for row in read(U/'documentation-1/links.json'):
 if not row['future_publication']:assert (U/'documentation-1/raw'/row['resolved']).exists() or (W/row['resolved']).exists()
 else:assert row['resolved'].startswith('docs/evidence/aggregate-error-upstream/')
checks=dict(status='clear_source_only',document_paths=7,held_references_verified=len(verified),new_profile=dict(sources=25,modes=50,passed=44,failed_proxy_reference_error=4,unsupported_cross_realm=2,verified_controls=52,report_replay_arrays_exact=True,baseline_projection_exact=True),
 old_profiles=dict(cases=1050,controls=348,full_arrays_and_policies_exact=True),python=dict(parent=573,final=592,additional=19,new_total=23),
 source=dict(parent=1682,final=1730,changed=20,new=48,no_rust_or_build_input_edits=True),
 published_before_docs_match=True,all_seven_diffs_exact=True,historical_validation_suffix_exact=True,historical_api_chapter_body_exact=True,
 identity_boundary='Selected ordinary ERJR2 admits AggregateError only; default seven retained; ERJR3 parser/validator bodies byte-exact.',
 execution='No project execution, import, test or live edit performed for this review.',future_evidence_links_qualified=True)
(R/'checks.json').write_text(json.dumps(checks,indent=2,sort_keys=True)+'\n')
(R/'references.json').write_text(json.dumps(list(verified.values()),indent=2,sort_keys=True)+'\n')
print(json.dumps(bind(R/'checks.json')))
