from pathlib import Path
from collections import Counter
import ast, hashlib, json, re
P=Path('/tmp/eris-aggregate-error-upstream-plan-1')
W=Path('/tmp/eris-aggregate-error-plan-1/worktree')
sha=lambda b:hashlib.sha256(b).hexdigest()
git=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def binding(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(name,data):
 (P/name).write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
r=json.loads((P/'fetch-receipt.json').read_bytes())
root=json.loads((P/'inventory-proof/tree-91b2052adad1f066ae031e2ff3a1e9bd6d732886.json').read_bytes())
harness=json.loads((P/'inventory-proof/tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json').read_bytes())
helpers=['assert.js','sta.js','propertyHelper.js','compareArray.js','isConstructor.js','promiseHelper.js']
aux=[]
for rel in ['harness/'+n for n in helpers]+['LICENSE','INTERPRETING.md']:
 expected=next(x['sha'] for x in (harness if '/' in rel else root)['tree'] if x['path']==rel.rsplit('/',1)[-1])
 candidates=sorted((W/'tests/upstream').glob('*/'+rel))
 selected=next(p for p in candidates if git(p.read_bytes())==expected)
 dest=P/'data'/rel;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(selected.read_bytes())
 aux.append(dict(relative=rel,git_blob=expected,source=binding(selected),retained=binding(dest)))
rows=[];cases=[];counts={k:Counter() for k in ['features','includes','flags']}
for item in r['sources']:
 p=Path(item['binding']['path']);raw=p.read_bytes();source=raw.decode();header=source.split('/*---',1)[1].split('---*/',1)[0]
 metadata={}
 for k in ['flags','includes','features','locale']:
  m=re.search(r'^'+k+r':[^\S\n]*(.*)$',header,re.M)
  if not m: v=[]
  else:
   value=m.group(1).strip()
   if value.startswith('['):
    assert value.endswith(']');v=[x.strip().strip("'\"") for x in value[1:-1].split(',') if x.strip()]
   else:
    tail=header[m.end():];v=[]
    for line in tail.splitlines():
     if not line.strip():continue
     mm=re.match(r'^\s+-\s+(\S.*?)\s*$',line)
     if not mm:break
     v.append(mm[1].strip("'\""))
  assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in v),(p,k,v)
  metadata[k]=v
 assert not re.search(r'^(negative|timeout):',header,re.M),p
 metadata['negative']=None
 assert not metadata['flags'] and not metadata['locale'],p
 for key in counts:counts[key].update(metadata[key])
 selected_helpers=['assert.js','sta.js']+metadata['includes']
 body=source.split('---*/',1)[1]
 markers={k:bool(re.search(pattern,body)) for k,pattern in {'Proxy':r'\bProxy\b','realm_host':r'\$262\b','class_identifier':r'\bclass\b','BigInt_identifier':r'\bBigInt\b','bigint_literal_lexical_scan':r'(?<![\w$])(?:\d+|0[xX][0-9a-fA-F]+)n\b'}.items()}
 row=dict(file=item['relative'],source_sha256=sha(raw),git_blob=git(raw),bytes=len(raw),metadata=metadata,modes=['sloppy','strict'],harness=selected_helpers,body_markers=markers)
 rows.append(row)
 for mode in row['modes']:
  identity=dict(source_sha256=sha(raw),mode=mode,metadata=metadata,harness=[dict(name=n,sha256=sha((P/'data/harness'/n).read_bytes())) for n in selected_helpers])
  cases.append(dict(id=item['relative']+':'+mode,case_sha256=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()),identity=identity))
assert len(rows)==25 and len(cases)==50
assert set(n for row in rows for n in row['harness'])==set(helpers)
write('census.json',dict(status='source_derived_no_execution',fetch_receipt=binding(P/'fetch-receipt.json'),directories={d['path']:sum(x['type']=='blob' for x in d['entries']) for d in r['directories']},sources=len(rows),modes=len(cases),mode_counts={'sloppy':25,'strict':25},sync_modes=50,async_modes=0,negative_sources=0,locale_sources=0,timeout_sources=0,metadata_census={k:dict(sorted(v.items())) for k,v in counts.items()},helper_closure=helpers,rows=rows,marker_qualification='Bounded lexical body scan is not a JavaScript parser or an outcome oracle; Proxy and realm dependencies also manually read.'))
write('auxiliary-authentication.json',dict(status='all_local_bytes_join_pinned_root_and_harness_trees',rows=aux))
write('case-identities.json',dict(status='prospective_ordinary_ERJS1_case_identity_no_completion_policy',construction='Source bytes/frontmatter and ordered helper digests only; no runner import or observation. json.dumps(sort_keys=True, ensure_ascii=True) uses default separators. Absent timeout remains absent.',rows=cases))
print(json.dumps(dict(metadata_census={k:dict(sorted(v.items())) for k,v in counts.items()},directories={d['path']:sum(x['type']=='blob' for x in d['entries']) for d in r['directories']},helpers=[(x['relative'],x['git_blob']) for x in aux],census=binding(P/'census.json')),indent=2))
