"""Read-only AST/literal/hash peer; never imports or evaluates project functions."""
import ast
import difflib
import hashlib
import json
from pathlib import Path

U=Path('/tmp/eris-aggregate-error-upstream-plan-1')
R=U/'runner-factory-review-1'
sha=lambda b:hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_bytes())
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def function(s):return next(n for n in ast.parse(s).body if isinstance(n,ast.FunctionDef) and n.name=='aggregate_error_preflight_variants')
def split(s,f):
 lines=s.splitlines(True);return ''.join(lines[:f.lineno-1]),''.join(lines[f.lineno-1:f.end_lineno]),''.join(lines[f.end_lineno:])
seal=read(U/'implementation-runner-2/source-ready.json')
bindings=[]
for key in ('selected_parent_hold','frozen_controls','before','raw','diff','checks','author'):
 row=seal[key];p=Path(row['path']);assert bind(p)==row;bindings.append(key)
before=Path(seal['before']['path']).read_text();raw=Path(seal['raw']['path']).read_text()
assert ''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/tools/test262_conformance.py',tofile='b/tools/test262_conformance.py')) == Path(seal['diff']['path']).read_text()
hold1=read(U/'implementation-runner-1/source-ready.json')
assert bind(Path(seal['before']['path']))['sha256']==hold1['files'][0]['raw']['sha256']
oldf,newf=function(before),function(raw)
oldparts,newparts=split(before,oldf),split(raw,newf)
assert oldparts[0]==newparts[0] and oldparts[2]==newparts[2]
assert newparts[0]+oldparts[1]+newparts[2]==before
old=ast.literal_eval(oldf.body[-1].value)
literals={node.targets[0].id:ast.literal_eval(node.value) for node in newf.body if isinstance(node,ast.Assign) and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('common','strict_only','selected')}
assert tuple(map(len,(literals['common'],literals['strict_only'],literals['selected'])))==(13,6,10)
# Independently enumerate the three source tables under the reviewed loop rules.
# This is a peer data model; no AST call/loop/body is executed.
rows=[]
def record(name,mode,source,expected,includes=(),negative=None,error_type='',identity='',dependencies=(),mode_id=False):
 return dict(name=name,mode=mode,id='harness-preflight:'+name+(':'+mode if mode_id else ''),source=source,
 metadata=dict(features=[],flags=[],includes=list(includes),locale=[],negative=None if negative is None else dict(phase='runtime',type=negative)),expected=expected,
 required_observation=dict(error_identity=identity,error_type=error_type,harness='',phase='runtime',status='exception' if error_type else 'complete'),prerequisites=list(dependencies))
for mode,prefix in [('sloppy',''),('strict','strict-')]:
 for name,source,expected,positive in literals['common']:
  rows.append(record(prefix+name,mode,source,expected,includes=['propertyHelper.js'] if 'property-' in name else [],error_type='Test262Error' if expected=='failed' else '',dependencies=[] if positive is None else [(prefix+positive,mode)]))
for name,source in literals['strict_only']:
 rows.append(record(name,'strict',source,'passed'))
common=[(r['name'],r['mode']) for r in rows]
for r in literals['selected']:
 for mode in ['sloppy','strict']:
  refs=common+([(r['prerequisite'],mode)] if 'prerequisite' in r else [])
  rows.append(record(r['name'],mode,r['source'],r['expected'],r['includes'],r.get('negative'),r.get('error_type',''),r.get('error_identity',''),refs,True))
assert rows==old
assert len(rows)==52 and len({r['id'] for r in rows})==52
frozen=read(U/'controls-1/variants.json')['records']
oracle=read(U/'tests-profile-1/raw/tools/aggregate-error-profile-oracle.json')['controls']
by_pair={(r['name'],r['mode']):r for r in frozen}
corpus=U/'corpus-expected-1/raw/tests/upstream/test262-aggregate-error'
for r,f,o in zip(rows,frozen,oracle):
 for key in ('name','mode','id','source','metadata','expected','required_observation'):
  assert r[key]==f[key]==o[key], (r['id'],key)
 references=[{k:by_pair[pair][k] for k in ('id','name','mode','expected','source_sha256','case_sha256')} for pair in r['prerequisites']]
 assert references==f['prerequisites']
 assert [ref['id'] for ref in references]==o['prerequisite_ids']
 harness=[dict(name=name,sha256=sha((corpus/'harness'/name).read_bytes())) for name in ['assert.js','sta.js']+r['metadata']['includes']]
 assert harness==f['harness']==o['harness']
 identity=dict(source_sha256=sha(r['source'].encode()),mode=r['mode'],metadata=r['metadata'],harness=harness)
 assert identity['source_sha256']==f['source_sha256']==o['source_sha256']
 assert sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())==f['case_sha256']==o['case_sha256']
checks=dict(status='clear_source_only',verified_hold2_bindings=bindings,old_records=52,new_static_model_records=52,
 literal_tables=dict(common=13,strict_only=6,new_logical=10),ordered_nested_data_equal=True,
 complete_source_prefix_and_suffix_equal=True,exact_factory_replacement_inverse=True,exact_unified_diff=True,
 frozen52_source_metadata_observation_and_helper_records_equal=True,frozen52_case_fingerprints_equal=True,
 frozen52_prerequisite_references_equal=True,independent_test_oracle_equal=True,
 old_factory_lines=oldf.end_lineno-oldf.lineno+1,new_factory_lines=newf.end_lineno-newf.lineno+1,
 before=bind(Path(seal['before']['path'])),raw=bind(Path(seal['raw']['path'])),
 source_segments=dict(prefix_sha256=sha(newparts[0].encode()),suffix_sha256=sha(newparts[2].encode())),
 project_imports_or_execution=False,live_writes=False)
(R/'checks.json').write_text(json.dumps(checks,indent=2,sort_keys=True)+'\n')
print(json.dumps(bind(R/'checks.json')))
