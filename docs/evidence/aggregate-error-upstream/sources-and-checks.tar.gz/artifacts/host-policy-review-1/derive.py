"""Read literal AST/source only; never import or execute project modules."""
from pathlib import Path
import ast
import hashlib
import json

P = Path('/tmp/eris-aggregate-error-upstream-plan-1')
def bind(p):
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

manifest = json.loads((P/'source-ready.json').read_text())
for row in manifest['files']:
    actual = bind(Path(row['path']))
    assert all(actual[k] == row[k] for k in actual), row['path']
source = (P/'source-snapshots/tools/test262_conformance.py').read_text()
tree = ast.parse(source)
env = {}

def literal(n):
    if isinstance(n, ast.Constant): return n.value
    if isinstance(n, ast.Name): return env[n.id]
    if isinstance(n, ast.Dict): return {literal(k): literal(v) for k,v in zip(n.keys,n.values)}
    if isinstance(n, ast.Set): return {literal(v) for v in n.elts}
    if isinstance(n, ast.Tuple): return tuple(literal(v) for v in n.elts)
    if isinstance(n, ast.List): return [literal(v) for v in n.elts]
    if isinstance(n, ast.Call) and isinstance(n.func, ast.Attribute) and n.func.attr == 'copy' and not n.args and not n.keywords:
        value = literal(n.func.value)
        if isinstance(value, (dict, list, set)): return value.copy()
    if isinstance(n, ast.BinOp):
        if isinstance(n.op, ast.BitOr): return literal(n.left) | literal(n.right)
        if isinstance(n.op, ast.Add): return literal(n.left) + literal(n.right)
    raise ValueError('Not a selected literal node')

for statement in tree.body:
    if not isinstance(statement, ast.Assign): continue
    try: value = literal(statement.value)
    except (ValueError, KeyError): continue
    for target in statement.targets:
        if isinstance(target, ast.Name): env[target.id] = value
        elif isinstance(target, ast.Subscript) and isinstance(target.value, ast.Name):
            if target.value.id in env: env[target.value.id][literal(target.slice)] = value

features = env['PROFILE_FEATURES']
errors = env['INTRINSIC_ERRORS']
hosts = env['PROMISE_HOST_PROFILES']
old = json.loads((P/'old-profile-contracts.json').read_text())['contract']
assert len(features) == 57
assert {k: sorted(v) for k,v in features.items()} == old['features']
assert sorted(errors) == old['intrinsic_errors']
assert errors == {'Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError'}
assert hosts == {'promise-methods-async','promise-all','promise-race','promise-all-settled'}
assert all('AggregateError' not in values for values in features.values())
policies = {}
for profile, tags in features.items():
    policy = {'format':2, 'supported_features':sorted(tags), 'negative_intrinsic_errors':sorted(errors), 'strict':True, 'modules':False, 'async_completion':False, 'host_hooks':False, 'timeout_seconds':3.0}
    if profile in {'typedarray-views','typedarray-search','typedarray-fill','typedarray-reverse','typedarray-copy-within'}:
        policy['excluded_harness'] = ['resizableArrayBufferUtils.js']
    if profile in hosts:
        policy.update(format=3, async_completion=True, host_hooks=True, request_protocol='ERJS2', response_protocol='ERJR3', adapter_feature='test262-host', completion_policy={'sync':'checked-sync','async':'authenticated-done'}, unhandled_rejection_policy='final-quiescent-veto', print_only_completion=False)
    assert old['policies_at_timeout3'][profile] == {'policy':policy,'sha256':digest(policy)}
    policies[profile] = digest(policy)
new = json.loads((P/'proposed-policy.json').read_text())
assert new['policy_sha256'] == digest(new['policy'])
assert new['policy']['negative_intrinsic_errors'] == sorted(errors | {'AggregateError'})
assert new['request'] == 'ERJS1' and new['response'] == 'ERJR2'
assert not new['completion_policy_in_case_identity'] and not new['host_feature_required']
assert new['policy']['format'] == 2 and not new['policy']['async_completion'] and not new['policy']['host_hooks']
assert set(new['supported_features']) == {'AggregateError','Reflect','Reflect.construct','Symbol','Symbol.iterator','Symbol.toPrimitive','error-cause'}
functions = {}
for node in tree.body:
    if isinstance(node, ast.FunctionDef) and node.name in {'encode_request','decode_response','run_case','unsupported_reason','classify','validate_promise_observation','decode_promise_response','case_fingerprint'}:
        raw = ''.join(source.splitlines(True)[node.lineno-1:node.end_lineno]).encode()
        functions[node.name] = dict(first_line=node.lineno,last_line=node.end_lineno,sha256=hashlib.sha256(raw).hexdigest())
assert len(functions) == 8
result = dict(status='clear_static_direction_only',sealed_input_files_hash_checked=len(manifest['files']),old_profile_count=57,old_intrinsic_errors=sorted(errors),old_host_profiles=sorted(hosts),old_policy_hashes_at_timeout3=policies,proposed_policy_sha256=digest(new['policy']),preserved_function_source_spans=functions,qualification='Literal AST derivation and source inspection only; no runner/importer import or execution, no prospective controls or implementation validated.')
q=P/'host-policy-review-1/checks.json'
q.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(bind(q)))
