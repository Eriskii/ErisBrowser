"""One-shot, source-only author. Never imports project code or executes tests/JS."""
import ast
import copy
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

U = Path('/tmp/eris-aggregate-error-upstream-plan-1')
H = U / 'tests-profile-1'
W = U / 'worktree'
BASE = 'd3efc9aba87102366b538ff69e83c2524a48eb6b'
assert not (H / 'source-ready.json').exists(), 'immutable seal already exists'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_bytes())

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def write(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, sort_keys=True) + '\n')

selected = read(U / 'controls-1/variants.json')['records']
assert len(selected) == len({r['id'] for r in selected}) == 52
by_id = {r['id']: r for r in selected}
controls = []
for row in selected:
    identity = dict(source_sha256=sha(row['source'].encode()), mode=row['mode'], metadata=row['metadata'], harness=row['harness'])
    assert identity['source_sha256'] == row['source_sha256']
    assert sha(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode()) == row['case_sha256']
    refs = [{key: by_id[r['id']][key] for key in ('id', 'name', 'mode', 'expected', 'source_sha256', 'case_sha256')} for r in row['prerequisites']]
    assert refs == row['prerequisites']
    kept = {key: copy.deepcopy(row[key]) for key in ('name', 'id', 'file', 'mode', 'metadata', 'source', 'source_sha256', 'case_sha256', 'harness', 'expected', 'required_observation')}
    kept['prerequisite_ids'] = [r['id'] for r in refs]
    controls.append(kept)
census = read(U / 'census.json')
cases = read(U / 'case-identities.json')['rows']
manifest_path = U / 'corpus-expected-1/raw/tests/upstream/test262-aggregate-error/manifest.json'
manifest = read(manifest_path)
policy = read(U / 'proposed-policy.json')
assert sha(json.dumps(policy['policy'], sort_keys=True).encode()) == policy['policy_sha256']
projected = []
for row in cases:
    assert sha(json.dumps(row['identity'], sort_keys=True, ensure_ascii=True).encode()) == row['case_sha256']
    projected.append(dict(id=row['id'], file=row['id'].rsplit(':', 1)[0], mode=row['identity']['mode'], source_sha256=row['identity']['source_sha256'], case_sha256=row['case_sha256']))
assert len(projected) == 50
assert len(census['rows']) == manifest['test_files'] == 25
assert len(manifest['files']) == 33 and len(manifest['inventory_proof']['files']) == 7
oracle = dict(profile='aggregate-error', provenance='Frozen source-only selected contracts; no observed adapter outcome or candidate implementation used.',
              controls=controls, case_identities=projected,
              metadata={r['file']: r['metadata'] for r in census['rows']},
              expected_manifest=manifest, manifest_sha256=sha(manifest_path.read_bytes()),
              helpers=census['helper_closure'], auxiliary_files=sorted(manifest['inventory_proof']['auxiliary_blobs']),
              features=policy['supported_features'], policy=policy['policy'], policy_sha256=policy['policy_sha256'],
              metadata_exclusions=[f"{r['file']}:{mode}" for r in census['rows'] if 'cross-realm' in r['metadata']['features'] for mode in r['modes']],
              untagged_proxy_sources=[r['file'] for r in census['rows'] if r['body_markers']['Proxy']])
assert len(oracle['metadata_exclusions']) == 2 and len(oracle['untagged_proxy_sources']) == 2
oracle_path = H / 'raw/tools/aggregate-error-profile-oracle.json'
write(oracle_path, oracle)
module = H / 'raw/tools/test_test262_aggregate_error_profile.py'
source = module.read_text()
assert source.count('ORACLE_SHA_PENDING') == 1
module.write_text(source.replace('ORACLE_SHA_PENDING', sha(oracle_path.read_bytes())))
tree = ast.parse(module.read_text())
groups = [n.name for cls in tree.body if isinstance(cls, ast.ClassDef) for n in cls.body if isinstance(n, ast.FunctionDef) and n.name.startswith('test_')]
assert len(groups) == 13
parent_rows = [
 ('pass', 'Entire raw manifest/metadata/source hash group uses existing parent APIs after the frozen 41-file corpus and this test/oracle are imported.'),
 ('error', 'First load_corpus(CORPUS, PROFILE) raises KeyError because the published PROFILES has no aggregate-error; later load, scope and mutations are unreached.'),
 ('error', 'First profile_intrinsic_errors(PROFILE) raises AttributeError; later policy checks are unreached.'),
 ('error', 'First decode_response(wire, profile=PROFILE) raises TypeError for the absent keyword parameter; later malformed rows are unreached.'),
 ('failure', 'The first genuine-identity sloppy row is unsupported by the old negative identity policy, differing from the selected passed result; transport and later rows are unreached.'),
 ('failure', 'Old harness_preflight falls through to the existing 32 generic controls; len(captured)==52 fails before canonical/protocol/gate assertions.'),
 ('error', 'Parent common capture completes, then the first aggregate_error_preflight_healthy access raises AttributeError; mutations are unreached.'),
 ('error', 'Parent common capture completes, then the first aggregate_error_preflight_healthy access raises AttributeError; raw observation mutations are unreached.'),
 ('error', 'Parent common capture completes, then the first aggregate_error_preflight_healthy access raises AttributeError; dependency rows are unreached.'),
 ('error', 'Parent common capture completes, then the first aggregate_error_preflight_healthy access raises AttributeError; helper mutations are unreached.'),
 ('error', 'First load_corpus raises KeyError; report/baseline refusal rows are unreached.'),
 ('error', 'First load_corpus raises KeyError; all explicit synthetic reporting/replay rows are unreached.'),
 ('failure', 'The first valid-ERJR3 mock runs the old 32 generic controls; expected (52,52) differs before later verification/wire rows.')]
roster = [dict(name=name, predicted_parent=outcome, first_reachability=why) for name, (outcome, why) in zip(groups, parent_rows)]
write(H / 'roster.json', dict(status='source_predicted_not_executed', groups=13,
    parent_totals=dict(passed=1, failure_groups=3, error_groups=9), rows=roster,
    precondition='Published d3efc9ab tooling plus complete frozen corpus41 and these two new files; no new profile production; module imports use existing APIs only.',
    limitations='Counts are source predictions, not observations. A first failed assertion/error ends its group; later assertions and subcases are not claimed reached.'))
source_bindings = []
parent = read(U / 'source-parent.json')['source_sha256']
for relative in ('tools/import_test262.py', 'tools/test262_conformance.py'):
    data = subprocess.check_output(['git', '-C', str(W), 'show', f'{BASE}:{relative}'])
    assert sha(data) == parent[relative]
    prior = U / 'tests-preservation-1/source-snapshots' / relative
    assert data == prior.read_bytes()
    target = H / 'source-snapshots' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    source_bindings.append(dict(relative_path=relative, published_blob=f'{BASE}:{relative}', selected_parent_sha256=parent[relative], snapshot=bind(target)))
refs = ['source-ready.json', 'source-parent.json', 'root/selection-1.json', 'published-base-refresh-1/source-ready.json',
        'controls-1/source-ready.json', 'controls-1/variants.json', 'controls-1/gate-contract.json', 'controls-1/html-review.json',
        'census.json', 'case-identities.json', 'proposed-policy.json', 'corpus-expected-1/source-ready.json',
        'corpus-expected-1/raw/tests/upstream/test262-aggregate-error/manifest.json', 'tests-preservation-1/source-ready.json']
write(H / 'source-bindings.json', dict(base=BASE, code=source_bindings, frozen_inputs=[bind(U / p) for p in refs],
    oracle_derivation='Stdlib JSON/hash projection only. All52 ordinary fingerprints and each canonical prerequisite reference rederived; all50 corpus fingerprints rederived. Old57/1050case/348control preservation remains the separate immutable four-group hold.',
    production_read=False, project_import_or_execution=False))
write(H / 'notes.json', dict(status='source_ready_no_execution', groups=13, payload_count=2,
    parent_import_eligibility='Only existing modules are imported. Every selected new function, profile lookup and keyword invocation occurs inside test methods.',
    source_inputs='Published parent sources, selected literal/control contracts, independent expected corpus manifest and source census only; candidate runner/importer holds and execution outputs were not read.',
    mock_boundary='Network and adapter calls are blocked by default; explicitly mocked where routing/classification is under test. The report helper uses a non-executable byte file and mocks every case dispatch.',
    synthetic_report='48 failed and 2 unsupported are deliberately mocked policy/report evidence, never a predicted or measured upstream outcome.',
    control_identity='Full52 source/mode/metadata/helper/case identities, required raw fields and six-field prerequisites are reconstructed from frozen oracle inputs. Prerequisite IDs avoid duplicating 32 full common rows per new control.',
    preservation='Separate tests-preservation-1 remains byte-exact: 57 old profiles/policies/features, default seven identities and ERJR3 behavior, old1050 case identities and348 Promise controls, common32 identities.',
    loader_refusals='Source/helper/proof corruption, deletion, manifest-rehashed but Git-unbound bytes, unlisted JS, declared unrelated proof and concealed prototype descendant with adjusted counts are all bounded temp-copy mutations.',
    proof_limit='An unlisted JSON file which is never advertised or read as evidence is not claimed refused. The extra-proof case advertises it in the manifest and must fail the authenticated proof set.',
    runner_api=['profile_intrinsic_errors(profile=None)', 'decode_response(output, *, profile=None)', 'aggregate_error_harness_preflight(files,binary,timeout)', 'aggregate_error_preflight_healthy(outcomes,files)'],
    new_profile_case_denominator=50, selected_control_count=52, no_upstream_outcome_forecast=True))
payloads=[]
for relative in ('tools/test_test262_aggregate_error_profile.py', 'tools/aggregate-error-profile-oracle.json'):
    assert relative not in parent
    result = subprocess.run(['git', '-C', str(W), 'cat-file', '-e', f'{BASE}:{relative}'], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    assert result.returncode != 0
    raw=H/'raw'/relative
    diff=H/'diffs'/(relative+'.patch')
    diff.parent.mkdir(parents=True, exist_ok=True)
    diff.write_text(''.join(difflib.unified_diff([], raw.read_text().splitlines(True), fromfile='/dev/null', tofile='b/'+relative)))
    payloads.append(dict(relative_path=relative,before_absent=True,raw=bind(raw),diff=bind(diff)))
held=[p for p in H.rglob('*') if p.is_file() and p.name!='source-ready.json']
seal=dict(status='source_ready_no_project_execution',base=BASE,groups=13,parent_api_eligible=True,
          parent_prediction=dict(passed=1,failure_groups=3,error_groups=9),payloads=payloads,oracle_sha256=sha(oracle_path.read_bytes()),
          selection=bind(U/'root/selection-1.json'),controls=bind(U/'controls-1/source-ready.json'),
          expected_corpus=bind(U/'corpus-expected-1/source-ready.json'),preservation=bind(U/'tests-preservation-1/source-ready.json'),
          roster=bind(H/'roster.json'),bindings=bind(H/'source-bindings.json'),files=[bind(p) for p in sorted(held)])
write(H/'source-ready.json',seal)
print(json.dumps(bind(H/'source-ready.json')))
print(json.dumps(dict(groups=groups,oracle=bind(oracle_path),module=bind(module))))
