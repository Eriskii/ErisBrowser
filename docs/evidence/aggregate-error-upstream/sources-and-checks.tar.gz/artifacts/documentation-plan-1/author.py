from pathlib import Path
import hashlib,json
P=Path('/tmp/eris-aggregate-error-upstream-plan-1'); H=P/'documentation-plan-1'; W=P/'worktree'
def bind(f):
 b=f.read_bytes(); return dict(path=str(f),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(n,v): (H/n).write_text(json.dumps(v,indent=2)+'\n')
assert not (H/'source-ready.json').exists()
paths=['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/aggregate-error.md']
inputs=[]
for name in paths:
 f=W/name; old=Path('/tmp/eris-aggregate-error-plan-1/documentation-3/raw')/name
 assert f.read_bytes()==old.read_bytes(),name
 inputs.append(dict(relative_path=name,current=bind(f),published_checkpoint_doc=bind(old)))
changes=[
 dict(path='README.md',operation='replace_current_summary_suffix',
      anchor="Error fallback tag from `Object.prototype.toString`. `Promise.any` and the\nconformance host's uncaught AggregateError identity decoder remain separate work.\n",
      proposed="Error fallback tag from `Object.prototype.toString`. `Promise.any` remains\nunfinished. The separate [AggregateError upstream profile](docs/aggregate-error-upstream.md)\nretains all 25 pinned sources and 50 modes, with an ordinary-response identity\ncapability confined to that profile.\n",
      qualification='Do not add result counts here until observed; link carries detailed results.'),
 dict(path='docs/COMPATIBILITY.md',operation='replace_current_summary_suffix',
      anchor="ordinary fake objects retain their distinctions. `Promise.any` is still absent,\nand the unchanged conformance decoder rejects an uncaught AggregateError\nintrinsic identity. This adds no full-standard or new upstream result claim.\n",
      proposed="ordinary fake objects retain their distinctions. `Promise.any` is still absent.\nThe separate [AggregateError upstream profile](aggregate-error-upstream.md) retains\nall 25 pinned sources and 50 modes. Only this profile accepts the AggregateError\nintrinsic identity in ordinary ERJR2 observations; other profiles and all ERJR3\nvalidators retain their existing identity policy. Its measured result inventory\nis a bounded selection, not full-standard conformance.\n",
      qualification='Use measured result wording only after actual profile receipt; no need duplicate numeric table.'),
 dict(path='docs/ROADMAP.md',operation='replace_current_followup_sentence',
      anchor="limits. `Promise.any` and host decoding of uncaught AggregateError identities\nremain separate follow-ups; the constructor alone does not implement either.\n",
      proposed="limits. Its separate [complete pinned upstream profile](aggregate-error-upstream.md)\nuses a profile-local ordinary-response AggregateError identity capability.\n`Promise.any`, wider host identity policy and multiple realms remain separate work.\n",
      qualification='Retain every preceding Promise checkpoint number and all later startup history.'),
 dict(path='docs/SECURITY.md',operation='insert_boundary_paragraph_after_existing_aggregate_mechanism',
      anchor="realm. This adds no renderer authority or host decoder acceptance, and the\nlogical ledger does not account for all allocator overhead or process memory.\n",
      proposed="\nThe separate [AggregateError conformance profile](aggregate-error-upstream.md)\nallows one additional intrinsic error identity only for its ordinary ERJR2\nresponses. It rejects ERJR3 responses before delegation; other profiles and\nPromise-host validators keep the seven-name identity policy. Exact source/helper\nidentities, raw observations and prerequisite controls gate the full selection.\nThis tooling change grants no renderer authority and changes no runtime limit,\ntransport bytes or final-unhandled-rejection policy.\n",
      qualification='Preserve existing isolation/experimental-security text and limits; confirm unchanged Rust/transport joins before final publication.'),
 dict(path='docs/VALIDATION.md',operation='prepend_new_checkpoint_after_title',
      anchor='# Validation record\n\n',
      proposed_section_title='## Complete pinned AggregateError selection',
      content_fields=['Observed50case status counts and52control health, distinguishing retained cross-realm metadata exclusions and actual untagged Proxy outcomes.',
                      'Exact new Python group/row roster, parent reachability and final fullPython receipt; no guessed errors or suite totals.',
                      'First measurement, healthy baseline recording and replay joins; existing profile case/control arrays and old baselines unchanged only if receipts prove them.',
                      'Reused published API binary identity and unchanged Rust inputs; no local Rust rebuild or full-suite rerun claim without receipt.',
                      'Link new chapter and evidence; original AggregateError API section and entire historical suffix remain byte-exact.']),
 dict(path='docs/aggregate-error.md',operation='insert_historical_checkpoint_note_after_title',
      anchor='# AggregateError\n\n',
      proposed="This chapter records the AggregateError API checkpoint at `d3efc9aba871`.\nIts validation and decoder limitations below describe that checkpoint. The\nseparate [upstream profile](aggregate-error-upstream.md) records the later\nprofile-local ordinary-response identity capability and conformance selection.\n\n",
      qualification='Every original paragraph, API result, resource number and evidence link remains exact.')]
for row in changes:
 text=(W/row['path']).read_text(); assert text.count(row['anchor'])==1,row['path']
 row['anchor_line']=text[:text.index(row['anchor'])].count('\n')+1
write('patch-plan.json',dict(status='prospective_documentation_plan_only',published_base='d3efc9aba87102366b538ff69e83c2524a48eb6b',
      changes=changes,new_path='docs/aggregate-error-upstream.md',
      preservation='No historical results rewritten; VALIDATION old suffix and aggregate-error.md old body stay byte-exact after additive insertion.',
      application='No docs or worktree source changed by this plan. Final prose must bind actual reports; root owns import/publication.'))
write('chapter-outline.json',dict(path='docs/aggregate-error-upstream.md',title='AggregateError upstream results',
 scope='Complete pinned AggregateError root19 and prototype6:25sources/50synchronous sloppy/strict modes. Entire denominator retained.',
 proposed_paragraphs=[
  'Open with actual passed/failed/unsupported counts out of50 and actual52-control health; state bounded selection, not full ECMAScript conformance.',
  'Explain unchanged41-file corpus:25sources,sixhelpers,twolegal files,sevencomplete nonrecursive proof documents and manifest; pinnedrevision7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd; no source filtering or rewriting.',
  'Table actual status/reason counts; cross-realm source proto-from-ctor-realm.js remains two required modes. Both untagged Proxy sources newtarget-proto-custom.js/newtarget-proto-fallback.js reach dispatch; quote only observed phase/identity, never infer results from feature tags.',
  'Describe ordinary ERJS1/ERJR2, exact seven feature tags, profile-local eighth intrinsic identity, and rejection of ERJR3 before delegation. Old57profile policies/sharedseven identities/Promise validators/final-unhandled policy unchanged.',
  'Explain52gate=32unchanged ordinary controls+20new rows: metadata, iteration/data, helper sequence, genuine AggregateError and forged-name/prototype identity controls. Canonical observations and exact prerequisite references are independently checked; unavailable/forged/partial gates block all50 and baseline recording.',
  'Describe frozen test/control provenance, actual parent failures with reached checks qualified, fullPython roster, and any retained tooling fixture corrections without claiming deeper parent assertions ran.',
  'Describe actual first/record/replay commands and exact arrays, baseline status/identity projection, old baselines and source/policy preservation. Healthy baseline exit0 is not all-passing conformance.',
  'Bind reused published adapter bytes/hash and unchanged Rust inputs. This tooling/corpus checkpoint claims no new runtime, cap, security, CPU/GPU performance or RSS result.',
  'Link actual baseline/evidence/archive and provide reviewed invocation. RemoteCI success only after a separate observed receipt.'
 ],
 links=[dict(label='corpus manifest',target='../tests/upstream/test262-aggregate-error/manifest.json',status='frozen expected payload available'),
        dict(label='baseline',target='../tests/conformance/test262-aggregate-error-current.json',status='await healthy observed recording'),
        dict(label='implementation checkpoint',target='aggregate-error.md',status='published'),
        dict(label='evidence manifest',target='evidence/aggregate-error-upstream/manifest.json',status='proposed root publication path; confirm before final seal'),
        dict(label='source/check archive',target='evidence/aggregate-error-upstream/sources-and-checks.tar.gz',status='proposed root publication path; confirm before final seal')],
 command_proposal=['python3 tools/test262_conformance.py --binary target/release/eris-js --profile aggregate-error --baseline tests/conformance/test262-aggregate-error-current.json'],
 result_placeholders=['ACTUAL_CASE_STATUS_COUNTS','ACTUAL_REASON_PHASE_IDENTITY_BREAKDOWN','ACTUAL_52_CONTROL_HEALTH',
                      'ACTUAL_FIRST_RECORD_REPLAY_EXIT_CODES_AND_ARRAY_JOINS','ACTUAL_PARENT_TEST_REACHABILITY',
                      'ACTUAL_FINAL_PYTHON_TOTAL_AND_EXACT_NEW_ROSTER','ACTUAL_LEGACY_REPLAY_ARRAY_JOINS',
                      'ACTUAL_REUSED_BINARY_BINDING','FINAL_SOURCE_AND_EVIDENCE_PATHS','REMOTE_CI_IF_OBSERVED']))
write('needed-facts.json',dict(required_before_final_seal=[
 'First profile report with all50case records and52control records, actual exit and raw reason/phase/identity fields.',
 'Healthy record-baseline and baseline replay receipts; exact projection and full arrays; baseline hash/path.',
 'Parent importer/preservation/profile test logs and final focused/fullPython logs with exact group names/counts; distinguish subevents from groups.',
 'Proof that all57 old profile policies and expected tables remain; exact legacy report/baseline joins for the exercised retained selections.',
 'Final source inventory and changed-path roster proving no Rust/build/transport/runtime changes, plus reused adapter bytes/SHA and parent provenance.',
 'Final validation/source-review receipts and root-selected archive/evidence paths.',
 'Any retained failed invocation or fixture correction history, without changing frozen expectations or implying unreached validations.',
 'CI gate file/command reviewed; separate actual remote status only if publication receipt exists.'
 ],known_facts_not_outcomes=dict(sources=25,modes=50,helpers=6,proofs=7,legal=2,total_corpus_files=41,
 new_gate_rows=52,common_rows=32,new_rows=20,old_profiles=57,cross_realm_retained_modes=2,untagged_proxy_retained_modes=4),
 disallowed_inferences=['No expected pass count from source or metadata.','No all-passing claim from healthy baseline exit0.',
 'No rerun Rust/build/strict claim from the previousAPI checkpoint.','No security/performance claim from conformance.']))
write('inputs.json',inputs)
files=[dict(relative_path=f.relative_to(H).as_posix(),**bind(f)) for f in sorted(H.iterdir()) if f.is_file()]
write('source-ready.json',dict(status='sealed_documentation_patch_plan_pending_actual_results',author='layout',
 published_base='d3efc9aba87102366b538ff69e83c2524a48eb6b',existing_paths=6,new_chapter_paths=1,
 files=files,execution='No project execution, network, production/docs edits or outcome claims.',
 scope='External plan only; no runnable importer/runner or documentation payload authored.'))
print(json.dumps(bind(H/'source-ready.json')))
