import hashlib
import json
from pathlib import Path
import struct
import subprocess
import sys

P = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(P / 'worktree/tools'))
import test262_conformance as runner

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

ready = json.loads((P / 'controls-1/source-ready.json').read_text())
for row in ready['files']:
    assert bind(Path(row['path'])) == {k: row[k] for k in ('path', 'bytes', 'sha256')}
rows = json.loads((P / 'controls-1/variants.json').read_text())['records']
out = P / 'parent-controls-2'
out.mkdir()
observations = []
for row in rows:
    case = {k: row[k] for k in ('id', 'file', 'mode', 'metadata', 'case_sha256')}
    case['source'] = row['source'].encode()
    case['harness'] = [(h['name'], (P / 'data/harness' / h['name']).read_bytes()) for h in row['harness']]
    assert runner.case_fingerprint(case) == case['case_sha256']
    request = runner.encode_request(case)
    assert request.startswith(b'ERJS1')
    key = row['name'] + '-' + row['mode']
    (out / (key + '.request')).write_bytes(request)
    result = subprocess.run([str(P / 'eris-js-parent-ordinary-1')], input=request,
                            capture_output=True, timeout=3, check=False)
    (out / (key + '.response')).write_bytes(result.stdout)
    (out / (key + '.stderr')).write_bytes(result.stderr)
    fields, offset = {}, 5
    assert result.returncode == 0 and result.stdout[:5] == b'ERJR2'
    for field in ('status', 'phase', 'error_type', 'error_identity', 'message', 'harness'):
        size, = struct.unpack_from('<I', result.stdout, offset)
        offset += 4
        assert size <= 16384 and offset + size <= len(result.stdout)
        fields[field] = result.stdout[offset:offset + size].decode()
        offset += size
    assert offset == len(result.stdout)
    try:
        legacy = dict(observation=runner.decode_response(result.stdout))
    except ValueError as error:
        legacy = dict(rejection=str(error))
    observations.append(dict(name=row['name'], mode=row['mode'], case_sha256=row['case_sha256'],
                             source_sha256=row['source_sha256'], observation=fields,
                             matches_frozen_fields=all(fields[k] == v for k, v in row['required_observation'].items()),
                             legacy_decoder=legacy, response=bind(out / (key + '.response'))))
report = dict(binary=bind(P / 'eris-js-parent-ordinary-1'), controls=bind(P / 'controls-1/source-ready.json'),
              ordinary_protocol=True, observations=observations,
              scope='Raw parent observations, not new-profile runner health; original legacy decoder unchanged.')
(out / 'observations.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(dict(rows=len(rows), matched=sum(x['matches_frozen_fields'] for x in observations),
                      legacy_rejections=[(x['name'], x['mode'], x['legacy_decoder']) for x in observations if 'rejection' in x['legacy_decoder']],
                      mismatches=[x for x in observations if not x['matches_frozen_fields']]), indent=2))
