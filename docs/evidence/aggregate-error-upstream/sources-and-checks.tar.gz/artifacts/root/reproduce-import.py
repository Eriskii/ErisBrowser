from pathlib import Path
from unittest.mock import patch
import hashlib
import json
import sys
import threading

P = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(P / 'worktree/tools'))
import import_test262 as importer

expected = P / 'corpus-expected-1/raw/tests/upstream/test262-aggregate-error'
manifest = json.loads((expected / 'manifest.json').read_text())
raw_prefix = f"https://raw.githubusercontent.com/tc39/test262/{manifest['revision']}/"
requests = {raw_prefix + row['upstream_path']: (expected / row['path']).read_bytes()
            for row in manifest['files']}
requests.update({row['url']: (expected / row['path']).read_bytes()
                 for row in manifest['inventory_proof']['files']})
seen, lock = [], threading.Lock()

def read(url):
    with lock:
        seen.append(url)
    return requests[url]

output = P / 'importer-reproduction-1'
output.mkdir()
with patch.object(importer, 'fetch', side_effect=read):
    importer.import_corpus(output / 'raw', 'aggregate-error')
names = {f.relative_to(expected) for f in expected.rglob('*') if f.is_file()}
assert {f.relative_to(output / 'raw') for f in (output / 'raw').rglob('*') if f.is_file()} == names
for name in names:
    assert (expected / name).read_bytes() == (output / 'raw' / name).read_bytes(), name
assert len(seen) == len(set(seen)) == len(requests) == 40

def bind(f):
    b = f.read_bytes()
    return dict(path=str(f), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

report = dict(status='pass', exact_files=len(names), actual_network_requests=0,
              retained_fetches=sorted(seen), actual_manifest=bind(output / 'raw/manifest.json'),
              expected_manifest=bind(expected / 'manifest.json'),
              importer=bind(P / 'worktree/tools/import_test262.py'))
(output / 'result.json').write_text(json.dumps(report, indent=2) + '\n')
print('Exact41-file importer reproduction passed with40 authenticated retained fetches.')
