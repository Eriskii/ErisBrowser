import json
from pathlib import Path
import subprocess

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE = 'd3efc9aba87102366b538ff69e83c2524a48eb6b'
publication = P / 'publication'
publication.mkdir(exist_ok=True)
record_path = P / 'root/github-publication.json'
assert not record_path.exists()
verified = json.loads((P / 'root/publication-verification.json').read_bytes())
assert verified['status'] == 'verified' and verified['path_count'] == 77

def git(directory, *args):
    result = subprocess.run(['git', *args], cwd=directory, text=True,
                            capture_output=True, check=True)
    return result.stdout.strip()

assert git(MAIN, 'branch', '--show-current') == 'main'
assert git(MAIN, 'rev-parse', 'HEAD') == git(W, 'rev-parse', 'HEAD') == BASE
assert git(MAIN, 'status', '--porcelain') == ''
assert git(W, 'diff', '--cached', '--name-only') == ''
paths = verified['expected_commit_paths']
pathspec = publication / 'paths.nul'
pathspec.write_bytes(b'\0'.join(name.encode() for name in paths) + b'\0')
git(W, 'add', '--pathspec-from-file=' + str(pathspec), '--pathspec-file-nul')
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
git(W, 'diff', '--cached', '--check')
message = publication / 'commit-message.txt'
message.write_text('Add authenticated AggregateError upstream conformance profile\n\n'
                   'Retain all 25 pinned Test262 sources and 50 modes with an ordinary\n'
                   'profile-local AggregateError identity capability and 52 guarded controls.\n'
                   'Record 44 passes, four Proxy failures and two realm exclusions.\n\n'
                   'Validation: 592 Python tests; exact 41-file offline import; new 50/52\n'
                   'replay and unchanged 1050/348 records across existing Promise profiles.\n')
commit_output = git(W, 'commit', '-F', str(message))
(publication / 'commit.log').write_text(commit_output + '\n')
commit = git(W, 'rev-parse', 'HEAD')
assert git(W, 'status', '--porcelain') == ''
assert set(git(W, 'diff-tree', '--no-commit-id', '--name-only', '-r', commit).splitlines()) == set(paths)
record = dict(status='committed', base=BASE, commit=commit,
              repository='https://github.com/Eriskii/ErisBrowser', paths=len(paths))
record_path.write_text(json.dumps(record, indent=2) + '\n')
merge_output = git(MAIN, 'merge', '--ff-only', 'aggregate-error-upstream')
(publication / 'merge.log').write_text(merge_output + '\n')
assert git(MAIN, 'rev-parse', 'HEAD') == commit and git(MAIN, 'status', '--porcelain') == ''
push_output = git(MAIN, 'push', 'origin', 'main')
(publication / 'push.log').write_text(push_output + '\n')
remote = git(MAIN, 'ls-remote', 'origin', 'refs/heads/main').split()[0]
assert remote == commit
record.update(status='pushed', remote_head=remote, ci='not yet observed')
record_path.write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
