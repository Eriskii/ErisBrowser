import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
E = W / 'docs/evidence/aggregate-error-upstream'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def read(name):
    return json.loads((P / name).read_bytes())

final = read('source-final.json')['source_sha256']
parent = read('source-parent.json')['source_sha256']
changed = sorted(name for name, value in final.items() if parent.get(name) != value)
assert len(changed) == 68
for name, value in final.items():
    assert sha((W / name).read_bytes()) == value, name
members = {}

def add(name, path, role):
    assert path.is_file() and not path.is_symlink(), path
    assert name not in members and not PurePosixPath(name).is_absolute()
    assert '..' not in PurePosixPath(name).parts
    members[name] = dict(data=path.read_bytes(), origin=str(path), role=role)

for name in changed:
    add('sources/' + name, W / name, 'changed-source')
docs = read('documentation-1/source-ready.json')['payloads']
assert len(docs) == 7
for row in docs:
    name = row['relative_path']
    assert bind(W / name)['sha256'] == row['raw']['sha256']
    add('documentation/' + name, W / name, 'published-documentation')
for directory in sorted(P.iterdir()):
    if (not directory.is_dir() or directory.is_symlink()
            or directory.name in {'worktree', 'root', 'publication'}):
        continue
    for path in sorted(directory.rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('artifacts/' + str(path.relative_to(P)), path, 'validation-artifact')
excluded = {'evidence-selection.json', 'publication-verification.json', 'github-publication.json'}
for path in sorted((P / 'root').glob('*')):
    if path.is_file() and path.name not in excluded:
        add('artifacts/root/' + path.name, path, 'root-receipt-or-script')
for path in sorted(P.iterdir()):
    if path.is_file() and path.suffix in {'.json', '.py'}:
        add('artifacts/' + path.name, path, 'validation-artifact')
ledger = read('root/final-validation.json')
peer = read('validation-review-1/final-review.json')
docpeer = read('documentation-review-1/review.json')
assert ledger['status'] == 'pass' and peer['status'] == 'clear' and docpeer['status'] == 'clear'
selection = [dict(path=name, bytes=len(row['data']), sha256=sha(row['data']),
                  origin=row['origin'], role=row['role']) for name, row in sorted(members.items())]
assert sum(row['bytes'] for row in selection) < 64 * 1024 * 1024
selection_path = P / 'root/evidence-selection.json'
assert not selection_path.exists()
selection_path.write_text(json.dumps(dict(status='frozen', members=selection,
    excluded='Compiled binaries, build caches, unchanged worktree and subsequent publication/CI state. '
             'Selected source inventory is not a full build graph.'), indent=2) + '\n')
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name, row in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size, info.mode, info.mtime = len(row['data']), 0o644, 0
        archive.addfile(info, io.BytesIO(row['data']))
packed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
assert len(packed) < 8 * 1024 * 1024
E.mkdir(parents=True, exist_ok=True)
output = E / 'sources-and-checks.tar.gz'
assert not output.exists()
output.write_bytes(packed)
summary = dict(schema=1, status='verified', archive=dict(path=output.name, bytes=len(packed),
    sha256=sha(packed), uncompressed_tar_bytes=len(raw.getvalue()),
    member_bytes=sum(row['bytes'] for row in selection)), source_count=68,
    documentation_count=7, artifact_count=len(selection) - 75,
    source_inventory=bind(P / 'source-final.json'), claims=ledger,
    claims_authority=dict(ledger=bind(P / 'root/final-validation.json'),
        peer=bind(P / 'validation-review-1/final-review.json'),
        documentation_peer=bind(P / 'documentation-review-1/review.json')),
    selection=bind(selection_path), members=selection)
(E / 'manifest.json').write_text(json.dumps(summary, indent=2) + '\n')
with tarfile.open(output, 'r:gz') as archive:
    assert archive.getnames() == [row['path'] for row in selection]
    for row in selection:
        member = archive.getmember(row['path'])
        assert member.isfile() and not member.issym() and not member.islnk()
        data = archive.extractfile(member).read()
        assert len(data) == row['bytes'] and sha(data) == row['sha256']
print(json.dumps(dict(members=len(selection), sources=68, docs=7, archive=bind(output))))
