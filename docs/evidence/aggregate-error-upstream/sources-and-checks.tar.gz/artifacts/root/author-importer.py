from pathlib import Path
import difflib
import hashlib
import json

P = Path(__file__).resolve().parents[1]
H = P / 'implementation-importer-1'
H.mkdir()
source = P / 'worktree/tools/import_test262.py'
before = source.read_text()
after = before

def replace(old, new):
    global after
    assert after.count(old) == 1, old
    after = after.replace(old, new)

replace("TREE_PROFILES = {'promise-all-settled'", "AGGREGATE_ERROR_DIRECTORIES = {'AggregateError': 19, 'AggregateError/prototype': 6}\nAGGREGATE_ERROR_HELPERS = {'assert.js', 'sta.js', 'propertyHelper.js',\n                           'compareArray.js', 'isConstructor.js', 'promiseHelper.js'}\nTREE_PROFILES = {'aggregate-error', 'promise-all-settled'")
replace("PROFILES = {'promise-all-settled':", "PROFILES = {'aggregate-error': AGGREGATE_ERROR_DIRECTORIES, 'promise-all-settled':")
replace("PROFILE_ROOTS = {'promise-all-settled':", "PROFILE_ROOTS = {'aggregate-error': 'test/built-ins', 'promise-all-settled':")
replace("def profile_tree_inventory(profile, read=None):\n", """def profile_tree_inventory(profile, read=None):
    if profile == 'aggregate-error':
        expected = {'AggregateError': 19, 'AggregateError/prototype': 6}
        if (AGGREGATE_ERROR_DIRECTORIES != expected or PROFILES[profile] != expected
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('AggregateError frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            expected, 'test/built-ins', read, auxiliary_helpers=AGGREGATE_ERROR_HELPERS)
        if any(len(listings[name]) != count for name, count in expected.items()):
            raise ValueError('AggregateError complete directory counts differ')
        # These documents have already been authenticated against the pinned
        # root. Require every child directory so the subtree stays complete.
        for directory, sha in description['directory_trees'].items():
            tree = json.loads(proof[tree_proof_path('trees/' + sha)])
            children = {entry['path'] for entry in tree['tree'] if entry['type'] == 'tree'}
            selected = {name[len(directory) + 1:] for name in expected
                        if name.startswith(directory + '/')
                        and '/' not in name[len(directory) + 1:]}
            if children != selected:
                raise ValueError('AggregateError incomplete descendant selection')
        return listings, proof, description
""")
replace("    if profile == 'promise-all-settled' and harness != PROMISE_ALL_SETTLED_HELPERS:\n", "    if profile == 'aggregate-error' and harness != AGGREGATE_ERROR_HELPERS:\n        raise ValueError('AggregateError requested harness differs from the frozen six helpers')\n    if profile == 'promise-all-settled' and harness != PROMISE_ALL_SETTLED_HELPERS:\n")
replace("    if profile in {'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'", "    if profile in {'aggregate-error', 'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'")
replace("    scope = {\n", "    scope = {\n        'aggregate-error': 'Complete pinned AggregateError constructor and prototype subtree, including unsupported realm and untagged Proxy cases; original sources and helper closure unchanged.',\n")

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

raw = H / 'raw/tools/import_test262.py'
raw.parent.mkdir(parents=True)
raw.write_text(after)
diff = H / 'importer.patch'
diff.write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                         fromfile='a/tools/import_test262.py', tofile='b/tools/import_test262.py')))
record = dict(status='authored_without_project_execution_or_live_import',
              base='d3efc9aba87102366b538ff69e83c2524a48eb6b',
              source_before=bind(source), payload=bind(raw), diff=bind(diff),
              selection=bind(P / 'root/selection-1.json'),
              expected_corpus=bind(P / 'corpus-expected-1/source-ready.json'))
(H / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
