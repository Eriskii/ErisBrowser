import hashlib
import json
from pathlib import Path
import subprocess
import sys

P = Path(__file__).resolve().parents[1]
W = P / 'worktree'
def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def run(label, binary, profile, options):
    report = P / (label + '.json')
    subprocess.run([sys.executable, str(P / 'run-tool.py'), label, sys.executable, '-B',
                    'tools/test262_conformance.py', '--binary', str(binary),
                    '--profile', profile, '--output', str(report), *options], check=True)
    return report, json.loads(report.read_bytes())

binary = P / 'eris-js-parent-ordinary-1'
baseline = P / 'aggregate-error-baseline-candidate.json'
assert not baseline.exists()
report, measured = run('upstream-aggregate-error-1', binary, 'aggregate-error',
                       ['--record-baseline', str(baseline)])
assert len(measured['cases']) == 50 and len(measured['harness_preflight']) == 52
assert measured['harness_preflight_passed']
assert all(row['verified'] for row in measured['harness_preflight'])
assert measured['binary_sha256'] == bind(binary)['sha256']
assert measured['runner_policy_sha256'] == 'd3fe422ab0532bbe29312f1aeaae90f26589cc7bd16c85699ad07dea49ae1a84'
assert measured['full_test262_conformance'] is False
frozen = json.loads((P / 'case-identities.json').read_text())
assert [(x['id'], x['case_sha256'], x['source_sha256']) for x in measured['cases']] == [
    (x['id'], x['case_sha256'], x['identity']['source_sha256']) for x in frozen['rows']]
# Preserve the measured report and baseline before any interpretation of case outcomes.
print('AggregateError measured counts:', measured['counts'], flush=True)
replay_path, replay = run('upstream-aggregate-error-replay-1', binary, 'aggregate-error',
                          ['--baseline', str(baseline)])
for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
            'corpus_manifest_sha256', 'counts'):
    assert measured[key] == replay[key], key
assert replay['regressions'] == replay['improvements'] == []

comparisons = []
host = Path('/tmp/eris-aggregate-error-plan-1/eris-js-host-final-1')
assert bind(host)['sha256'] == '8b2898393aed16e9e7e98908e8284805e5a4dd71d445b3fcb66eaf5451ec375b'
for profile, old_name, label in [
        ('promise-all-settled', 'upstream-settled-1.json', 'upstream-settled-1'),
        ('promise-race', 'upstream-race-1.json', 'upstream-race-1'),
        ('promise-all', 'upstream-all-1.json', 'upstream-all-1'),
        ('promise-methods-async', 'upstream-existing-1.json', 'upstream-existing-1')]:
    old_path = P / 'replay-parent' / old_name
    old = json.loads(old_path.read_bytes())
    new_path, new = run(label, host, profile,
                        ['--baseline', 'tests/conformance/test262-' + profile + '-current.json'])
    for key in ('cases', 'harness_preflight', 'runner_policy', 'runner_policy_sha256',
                'corpus_manifest_sha256', 'counts'):
        assert old[key] == new[key], (profile, key)
    assert new['regressions'] == new['improvements'] == []
    assert new['harness_preflight_passed'] and all(x['verified'] for x in new['harness_preflight'])
    assert new['binary_sha256'] == bind(host)['sha256']
    comparisons.append(dict(profile=profile, parent=bind(old_path), actual=bind(new_path),
                            cases=len(new['cases']), controls=len(new['harness_preflight']),
                            counts=new['counts']))
assert sum(x['cases'] for x in comparisons) == 1050
assert sum(x['controls'] for x in comparisons) == 348
result = dict(status='pass', new_profile=dict(report=bind(report), replay=bind(replay_path),
              baseline=bind(baseline), binary=bind(binary), cases=50, controls=52,
              counts=measured['counts']), old_profiles=comparisons,
              old_cases_exact=1050, old_controls_exact=348, old_baselines_changed=False)
(P / 'root/profile-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print('New50/52 replay and previous1050/348 records agree exactly.')
