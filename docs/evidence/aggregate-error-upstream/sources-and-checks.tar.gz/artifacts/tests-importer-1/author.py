"""Author frozen external test/oracle artifacts using only stdlib source/data operations."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

P = Path('/tmp/eris-aggregate-error-upstream-plan-1')
H = P / 'tests-importer-1'
C = P / 'corpus-expected-1/raw/tests/upstream/test262-aggregate-error'
BASE = 'd3efc9aba87102366b538ff69e83c2524a48eb6b'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))

def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')

assert not (H / 'source-ready.json').exists()
manifest_bytes = (C / 'manifest.json').read_bytes()
manifest = json.loads(manifest_bytes)
assert digest(manifest_bytes) == 'ae30b6c1019a0e75df65de5199685f87caeb310f2750eea59c8f2b5b718fa1a1'
census = json.loads((P / 'census.json').read_bytes())
identities = json.loads((P / 'case-identities.json').read_bytes())['rows']
all_files = [dict(path=f.relative_to(C).as_posix(), bytes=f.stat().st_size,
                  sha256=digest(f.read_bytes())) for f in sorted(C.rglob('*')) if f.is_file()]
assert len(all_files) == 41 and sum(row['bytes'] for row in all_files) == 124695
metadata = {row['file']: row['metadata'] for row in census['rows']}
case_rows = [dict(id=row['id'], case_sha256=row['case_sha256']) for row in identities]
# Independent serialization check against fixed original identity rows; do not import project code.
reconstructed = []
for name, meta in metadata.items():
    source = (C / name).read_bytes()
    helper_names = list(dict.fromkeys(['assert.js', 'sta.js'] + meta['includes']))
    harness = [dict(name=n, sha256=digest((C / 'harness' / n).read_bytes())) for n in helper_names]
    for mode in ('sloppy', 'strict'):
        identity = dict(source_sha256=digest(source), mode=mode, metadata=meta, harness=harness)
        reconstructed.append(dict(id=name + ':' + mode,
                                  case_sha256=digest(json.dumps(identity, sort_keys=True,
                                                               ensure_ascii=True).encode())))
assert reconstructed == case_rows and len(case_rows) == 50
oracle = dict(format=1, profile='aggregate-error', published_parent=BASE,
              expected_manifest=manifest, manifest_sha256=digest(manifest_bytes),
              all_files=all_files, metadata=metadata, case_identities=case_rows,
              qualification='Frozen source-only import/identity oracle. No engine outcomes or filtering. '
                            'Cross-realm two modes and untagged Proxy four modes remain in the full fifty.')
oracle_path = H / 'raw/tools/aggregate-error-importer-oracle.json'
write(oracle_path, oracle)
module_path = H / 'raw/tools/test_import_test262_aggregate_error.py'
module = module_path.read_text()
assert module.count('__ORACLE_SHA__') == 1
module = module.replace('__ORACLE_SHA__', digest(oracle_path.read_bytes()))
module_path.write_text(module)
tree = ast.parse(module)
classes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
groups = [node.name for cls in classes for node in cls.body
          if isinstance(node, ast.FunctionDef) and node.name.startswith('test_')]
assert len(groups) == 6
parent_importer = P / 'source-snapshots/tools/import_test262.py'
parent_bytes = parent_importer.read_bytes()
assert digest(parent_bytes) == '818ca38c2406c9a16c9f03be28ca8c4e6d8cb0dcbe6cd3eacc913212cadbecbf'
parent_ast = ast.parse(parent_bytes)
parent_names = {node.name for node in parent_ast.body if isinstance(node, ast.FunctionDef)}
assert {'import_corpus', 'profile_tree_inventory', 'parse_metadata', 'tree_proof_path', 'corpus_name'} <= parent_names
assert b'AGGREGATE_ERROR_DIRECTORIES' not in parent_bytes
assert b'AGGREGATE_ERROR_HELPERS' not in parent_bytes
payloads = []
for file in (module_path, oracle_path):
    relative = file.relative_to(H / 'raw').as_posix()
    assert not (P / 'worktree' / relative).exists()
    delta = ''.join(difflib.unified_diff([], file.read_text().splitlines(keepends=True),
                                        fromfile='/dev/null', tofile='b/' + relative))
    patch = H / 'diffs' / (relative + '.patch')
    patch.parent.mkdir(parents=True, exist_ok=True)
    patch.write_text(delta)
    payloads.append(dict(relative_path=relative, before_absent=True, raw=binding(file), diff=binding(patch)))
inputs = [P / name for name in [
    'source-parent.json', 'root/selection-1.json', 'source-ready.json', 'fetch-receipt.json',
    'census.json', 'case-identities.json', 'auxiliary-authentication.json',
    'corpus-expected-1/source-ready.json', 'corpus-expected-1/roster.json',
    'corpus-expected-1/layout-review.json', 'corpus-expected-1/published-base-refresh.json',
    'source-snapshots/tools/import_test262.py', 'source-snapshots/tools/test_import_test262_promise.py',
    'source-snapshots/tools/test_test262_promise_all_settled_profile.py']]
write(H / 'inputs.json', [binding(path) for path in inputs])
roster = [
 dict(name=groups[0], expected_parent='error: new AGGREGATE_ERROR_DIRECTORIES absent at first assertion',
      selected_expectation='pass', oracle='Exact new table/helper/root memberships; 25+6+2+7+manifest=41 files/124695 bytes; both complete listings, exact proof description and one byte-exact offline import including exact scope/manifest.'),
 dict(name=groups[1], expected_parent='pass once the independently frozen corpus is imported',
      selected_expectation='pass', oracle='Existing metadata parser; exact25 metadata records/28499sourcebytes, six helpers and50 fixed case fingerprints; two cross-realm and four untagged Proxy identities remain. No runner/outcome policy exercised.'),
 dict(name=groups[2], expected_parent='errors: profile absent; not counted as authentication refusal',
      selected_expectation='pass', refusal_rows=21, oracle='Seven wrong proof identities, six mutations for each of two selected trees, explicit prototype descendant removal, proof byte cap.'),
 dict(name=groups[3], expected_parent='errors: missing profile/root; not counted as selection validation',
      selected_expectation='pass', refusal_rows=7, oracle='Empty, omitted root, omitted prototype, both wrong counts, extra child, wrong source root; ValueError required.'),
 dict(name=groups[4], expected_parent='errors: profile absent; not counted as blob validation',
      selected_expectation='pass', refusal_rows=33, oracle='Every25source/sixhelper/twolegal blob gets one newline appended; pinned Git blob ValueError and no output directory.'),
 dict(name=groups[5], expected_parent='error: new AGGREGATE_ERROR_HELPERS absent at first assertion',
      selected_expectation='pass', refusal_rows=7, oracle='Remove each of six helpers separately and add existing doneprintHandle; helper closure refusal before output.')]
write(H / 'roster.json', dict(groups=roster, group_count=6, planned_refusal_rows=68,
      predicted_parent_group_summary=dict(pass_groups=1,error_groups=5),
      prediction_qualification='Source-only expected reachability, not observed execution or a fixed traceback/subevent count.',
      observation_denominator='No JavaScript executions. Fifty upstream metadata identities are retained, not measured outcomes.'))
write(H / 'contract.json', dict(
    purpose='Independent frozen importer admission/output oracle before reading or implementing the new importer branch.',
    APIs=['import_corpus(output, profile)', 'profile_tree_inventory(profile, read)', 'parse_metadata(source)',
          'tree_proof_path(route)', 'corpus_name(profile)'],
    selected_constants=dict(AGGREGATE_ERROR_DIRECTORIES={'AggregateError':19,'AggregateError/prototype':6},
                            AGGREGATE_ERROR_HELPERS=sorted({'assert.js','sta.js','propertyHelper.js','compareArray.js','isConstructor.js','promiseHelper.js'})),
    installation='Root imports the independently held 41-file corpus plus these two new tools paths; unittest discovery needs no registration edit. No existing test/source changes.',
    parent_compatibility='Imports and all helper APIs exist on the published parent; new constants occur only inside test methods. Five groups are expected to expose the absent profile, while the metadata preservation group can pass.',
    network='setUp forbids fetch globally. Explicit replay replaces it with retained proof/source bytes for import cases; all URLs must be in the frozen manifest. No Contents API fallback or live network.',
    corpus_scope='All25 sources retained, including cross-realm and untagged Proxy; no reason-based omission, pass-count prediction, host transport or baseline change.',
    output='All publication refusals assert destination absent. Byte-exact success asserts exact file set and all file bytes, including original proof serialization and manifest scope.',
    old_profiles='Covered separately by tests-preservation-1; these controls do not widen shared policy or alter old expected tables.',
    authored_checks=['stdlib ast.parse of held source only', 'all50 identity serialization independently reconstructed from held raw corpus',
                     'manifest/all41 file counts/hash bindings', 'new paths absent in current worktree', 'parent API declarations source-read'],
    not_executed=['project importer or runner', 'test module or unittest', 'engine/adapter', 'network', 'compiler/build/Git']))
files = [dict(relative_path=f.relative_to(H).as_posix(), **binding(f))
         for f in sorted(H.rglob('*')) if f.is_file() and f.name != 'source-ready.json']
write(H / 'source-ready.json', dict(status='frozen_source_only_before_importer_implementation',
      author='layout', published_parent=BASE, groups=6, new_project_paths=2,
      payloads=payloads, inputs=binding(H / 'inputs.json'), roster=binding(H / 'roster.json'),
      contract=binding(H / 'contract.json'), oracle_sha256=digest(oracle_path.read_bytes()),
      expected_corpus=binding(P / 'corpus-expected-1/source-ready.json'),
      scope='Importer-only controls; no project execution, live edits, network fetch, outcome filtering or production source read.',
      files=files))
print(json.dumps(binding(H / 'source-ready.json')))
