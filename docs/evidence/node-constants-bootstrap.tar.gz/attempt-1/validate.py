import hashlib,json,os,pathlib,subprocess,sys,time
base=pathlib.Path('/tmp/eris-node-constants-batch-1'); root=base/'worktree'
label=sys.argv[1];command=['cargo']+sys.argv[2:]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR='/tmp/eris-dom-own-properties-1/target')
env['PATH']='/tmp/eris-vulkan-rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
out=base/'validation';out.mkdir(exist_ok=True);log=out/(label+'.log')
record={'command':command,'cwd':str(root),'environment':{k:env[k] for k in ['CARGO_BUILD_JOBS','CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','PATH']},'source_manifest':os.environ.get('ERIS_NODE_CONSTANTS_SOURCE_MANIFEST','attempt-1/manifest.json'),'log':str(log)}
with (out/(label+'.command.json')).open('x') as receipt: receipt.write(json.dumps(record,indent=2)+'\n')
start=time.monotonic()
with log.open('xb') as stream: result=subprocess.run(command,cwd=root,env=env,stdout=stream,stderr=subprocess.STDOUT)
record.update(exit_code=result.returncode,seconds=round(time.monotonic()-start,3),sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (out/(label+'.json')).open('x') as receipt: receipt.write(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2));print(log.read_text()[-10000:]);sys.exit(result.returncode)
