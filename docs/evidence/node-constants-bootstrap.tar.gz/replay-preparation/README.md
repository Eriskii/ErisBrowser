# Held Node constant replay preparation

This directory is prepared but **not executed**. The driver was AST-parsed as
Python source only; it and its helper modules were not imported. The matrix was
constructed with independent data-only SHA-256/fingerprint calculations. Root
owns baseline compilation, inert driver verification, and any later engine run.

Immutable independent inputs are copied byte-for-byte under independent/.
The source remains e3253ef6cdc80310be70fa6975e5bbe41ba9482177ac568e6bc5dc2156685d1a.
Their earlier readiness and peer review are retained. Three established helper
modules are copied under tools/ with original paths and hashes in
preparation-history.json. The driver uses these copies, not changing repository
tool files. history/title-replay.py and replay.py.diff show the adaptation.

## Fixed matrix

Seven named cases run in separate strict/sloppy adapter processes: 14 ordinary
rows. Each executes the entire original source plus one named call whose result
must be true. Their expected observation is always complete/runtime with no
error type or identity. No expected result is inferred from a baseline run.

Three positive/wrong pairs run in both modes: 12 control rows.

- Literal syntax exercises const/let, a bounded array loop and literal unmatched
  UTF-16 input with independent numeric expectations.
- Node descriptors require actual own first/last constant values and full flags
  on both Node and Node.prototype.
- Reflected order requires actual callable reflection APIs, the complete key
  counts and independent boundary positions, including the final prototype
  Symbol.toStringTag. The ordinary cases separately check every key position.

Each wrong source is the exact positive source followed only by a deliberate
`throw new Error(...)`. All authored prerequisite failures throw TypeError.
Wrong-tail matches require runtime Error **identity**, not just an exception.
A control is verified only if its own observation matches and its same-mode
positive partner completes. Missing observations, timeout, Resource,
Unsupported and adapter/runner errors never count as control success.

The separate two-live-Runtime protocol is retained in the original source and
README, but no protocol step is invoked by this matrix. The standalone clean
marker case only checks a fresh realm. Separate ERJS processes do not test two
live realms; root/script will use public Runtime APIs in later Rust checks.

## Inherited protocol and process bounds

The unchanged test262 runner writes ERJS1 requests and validates ERJR2 responses.
Every row is sequential, with timeout 3 seconds, stdout 96 KiB and stderr
64 KiB. Its inherited bounded_process owns the direct adapter child, multiplexes
bounded pipes, and kills a remaining child and waits in finally. This does not
introduce a new general descendant-process supervisor.

The driver reconstructs and checks the entire frozen matrix and copied inputs
before launch. A binary must match the digest supplied by root. It reserves a
fresh report path exclusively before the first engine process. Every case and
control row is retained even when run_case fails; unexpected Python exceptions
become explicit runner-error rows and do not stop later rows. Inputs, matrix and
binary are rehashed afterward, with actual observed hashes or read failures
retained in the report. Existing reports are never overwritten.

The supplied binary digest binds executable bytes; root's build/source receipt
must separately bind that binary to its candidate source. No binary digest or
baseline result is invented in this preparation. Output completion cannot be
promised after externally killing the driver or a physical filesystem/OOM error.

## Commands for root, not yet run

Inert verification after source review:

```sh
python3 /tmp/eris-node-constants-batch-1/replay-preparation/replay.py --verify
```

Actual replay after root supplies the exact binary and SHA:

```text
python3 /tmp/eris-node-constants-batch-1/replay-preparation/replay.py BINARY EXPECTED_SHA256 FRESH_REPORT.json
```

The report's parent directory must already exist. Exit 0 means all 14 ordinary
expectations and 12 paired controls matched with unchanged bindings. Exit 1
retains ordinary/control mismatches; 2 indicates post-binding failure; 3 indicates
unexpected runner exceptions. Raw wrong controls normally have runner status
failed because the inherited conformance classifier sees an exception; the
separate exact expected-observation/verified fields are the control verdict.

`--prepare` is retained from the established driver but refuses to overwrite the
already held matrix. No preparation or verification mode was run by this author.
The initial matrix and source pins must remain unchanged for before/after replay.
