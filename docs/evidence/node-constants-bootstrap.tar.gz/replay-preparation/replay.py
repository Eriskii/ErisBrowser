#!/usr/bin/env python3
"""Frozen Node constant observations; --prepare/--verify never invoke an engine."""
import hashlib
import json
import sys
from pathlib import Path

if not __debug__:
    raise RuntimeError('run without Python optimization')
sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE  # Immutable copied helpers; no dependency on mutable worktree tools.
sys.path.insert(0, str(ROOT / 'tools'))
import test262_conformance as runner


def digest(data):
    return hashlib.sha256(data).hexdigest()


def matches(result, expected):
    observation = result.get('observation')
    return isinstance(observation, dict) and all(
        observation.get(key) == value for key, value in expected.items())


complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
# Data-only checks: missing/invalid observations cannot accidentally pass or abort retention.
for result in [dict(status='timeout'), dict(status='adapter-error'),
               dict(status='unsupported'), dict(status='runner-error'),
               dict(observation=None), dict(observation=[]), dict(observation={})]:
    assert not matches(result, complete) and not matches(result, wrong)
assert matches(dict(observation=complete), complete)
assert matches(dict(observation=wrong), wrong)
assert not matches(dict(observation=dict(wrong, error_identity='TypeError')), wrong)

inventory_path = HERE / 'replay-inputs.json'
inventory = json.loads(inventory_path.read_text())
fixture_path = HERE / inventory['fixture']
fixture = fixture_path.read_bytes()
assert digest(fixture) == inventory['fixture_sha256'] == 'e3253ef6cdc80310be70fa6975e5bbe41ba9482177ac568e6bc5dc2156685d1a'
assert inventory['collection'] == 'nodeConstantCases'
assert len(inventory['cases']) == 7 and len(inventory['controls']) == 6
assert (inventory['case_modes'], inventory['control_modes']) == (14, 12)
controls = {row['name']: row for row in inventory['controls']}
for row in inventory['controls']:
    positive = controls[row['pair'] + '-positive']
    assert positive['positive'] is True and positive['area'] == row['area']
    assert row['source'] == positive['source'] + (
        '' if row['positive'] else "throw new Error('deliberately wrong expectation');")

matrix = []
for kind, inputs in [('case', inventory['cases']), ('control', inventory['controls'])]:
    for row in inputs:
        assert row['modes'] == ['sloppy', 'strict']
        expected = row['expected_observation']
        assert expected == (complete if kind == 'case' or row['positive'] else wrong)
        body = (fixture + b'\nif(nodeConstantCases.' + row['name'].encode() +
                b'() !== true) throw new Error("case did not return true");'
                if kind == 'case' else row['source'].encode())
        for mode in row['modes']:
            case = dict(id=row['name'] + '#' + mode,
                        file='node-constants.js' if kind == 'case' else 'controls',
                        mode=mode, source=body,
                        metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None),
                        harness=[])
            case['case_sha256'] = runner.case_fingerprint(case)
            identity = dict(id=case['id'], mode=mode, kind=kind,
                            source_sha256=digest(body), case_sha256=case['case_sha256'],
                            expected_observation=expected)
            if kind == 'control':
                identity.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                                partner=row['pair'] + '-positive#' + mode)
            matrix.append((case, identity))
assert len(matrix) == 26 and len({case['id'] for case, _ in matrix}) == 26
history_path = HERE / 'preparation-history.json'
history = json.loads(history_path.read_text())
for row in history:
    copy = HERE / row['copy']
    assert len(copy.read_bytes()) == row['bytes'] and digest(copy.read_bytes()) == row['sha256']
bound_paths = [Path(__file__).resolve(), inventory_path, history_path,
               *[HERE / row['copy'] for row in history]]
bound_inputs = [dict(path=str(p), bytes=p.stat().st_size, sha256=digest(p.read_bytes()))
                for p in bound_paths]
frozen = dict(fixture_sha256=digest(fixture), inventory_sha256=digest(inventory_path.read_bytes()),
              replay_sha256=digest(Path(__file__).read_bytes()),
              runner_sha256=digest(Path(runner.__file__).read_bytes()),
              bounds=dict(timeout_seconds=3, stdout_limit=96 * 1024, stderr_limit=64 * 1024,
                          execution='sequential inherited run_case'),
              bound_inputs=bound_inputs, rows=[identity for _, identity in matrix])
freeze = HERE / 'replay-matrix.json'
if sys.argv[1:] == ['--prepare']:
    with freeze.open('x') as output:
        json.dump(frozen, output, indent=2)
        output.write('\n')
    print('Frozen 14 independent case modes and 12 paired controls; no engine execution')
    raise SystemExit
assert frozen == json.loads(freeze.read_text())
if sys.argv[1:] == ['--verify']:
    print('Input/matrix bindings and absent-observation checks verified; no engine execution')
    raise SystemExit
if len(sys.argv) != 4:
    raise SystemExit('usage: replay.py --prepare | --verify | BINARY EXPECTED_SHA256 FRESH_OUTPUT')
binary = Path(sys.argv[1]).resolve()
expected_binary_sha = sys.argv[2]
output_path = Path(sys.argv[3])
if output_path.exists():
    raise FileExistsError(output_path)
binary_sha = digest(binary.read_bytes())
if binary_sha != expected_binary_sha:
    raise ValueError('binary differs from supplied pinned digest')
matrix_sha = digest(freeze.read_bytes())
# Claim the exact output before any process launch; pre-existing paths refuse.
output_stream = output_path.open('x')
records = []
for case, identity in matrix:
    try:
        result = runner.run_case(case, binary, 3)
        if not isinstance(result, dict):
            raise TypeError('run_case did not return a result object')
    except Exception as error:
        # Preserve the failed row and every completed observation. Such rows are
        # infrastructure failures, never ordinary mismatches or control passes.
        result = dict(status='runner-error', reason=f'{type(error).__name__}: {error}')
    result.update(identity)
    result['matches_expectation'] = matches(result, identity['expected_observation'])
    records.append(result)

binding_failures = []
observed_after = []
for row in bound_inputs + [dict(path=str(binary), sha256=binary_sha),
                           dict(path=str(freeze), sha256=matrix_sha)]:
    try:
        raw = Path(row['path']).read_bytes()
        observed_after.append(dict(path=row['path'], bytes=len(raw), sha256=digest(raw)))
        if digest(raw) != row['sha256']:
            binding_failures.append(dict(path=row['path'], reason='hash changed'))
    except OSError as error:
        observed_after.append(dict(path=row['path'], error=str(error)))
        binding_failures.append(dict(path=row['path'], reason=str(error)))
cases = [r for r in records if r['kind'] == 'case']
controls = [r for r in records if r['kind'] == 'control']
control_by_id = {row['id']: row for row in controls}
for row in controls:
    row['positive_partner_matches'] = control_by_id[row['partner']]['matches_expectation']
    row['verified'] = row['matches_expectation'] and row['positive_partner_matches']
report = dict(binary=str(binary), binary_sha256=binary_sha, matrix_sha256=matrix_sha,
              **{k: v for k, v in frozen.items() if k != 'rows'},
              cases=cases, controls=controls, binding_failures=binding_failures,
              observed_after=observed_after)
with output_stream as output:
    json.dump(report, output, indent=2)
    output.write('\n')
print(json.dumps(dict(cases=sum(r['matches_expectation'] for r in cases), total=len(cases),
                      controls=sum(r['matches_expectation'] for r in controls),
                      controls_verified=sum(r['verified'] for r in controls), control_total=len(controls),
                      binding_failures=binding_failures,
                      unmet=[dict(id=r['id'], status=r.get('status'), observation=r.get('observation'))
                             for r in records if not r['matches_expectation']]), indent=2))
if binding_failures:
    raise SystemExit(2)
if any(row.get('status') == 'runner-error' for row in records):
    raise SystemExit(3)

if any(not row['matches_expectation'] for row in cases) or any(not row['verified'] for row in controls):
    raise SystemExit(1)
