#!/usr/bin/env python3
"""Frozen, sequential initialization/drop measurements; never builds anything."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import signal
import statistics
import subprocess
import time

HERE = Path(__file__).resolve().parent
TOOLS = ("1.88.0", "1.98.0")
ARMS = ("baseline", "candidate")
BUILD_KEYS = {f"{arm}-{suffix}" for arm in ARMS for suffix in ("188", "198")}
FIXED = {
    "runtime-init.rs": "9c4bdd7d8f9b7d9c285c9d0e09d18fc75c94fc897a45acc333a556e5f3f280e6",
    "schedule.json": "2d80b81985fed0444ebdd82e859201ebbc92e2d8b648ea84b0907e57149426e3",
}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def fingerprint(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path.resolve()), bytes=len(data), sha256=digest(data))


def strict_json(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, "duplicate JSON key: " + key)
            result[key] = value
        return result

    def invalid(value):
        raise ValueError("nonfinite JSON number: " + value)

    return json.loads(data, object_pairs_hook=pairs, parse_constant=invalid)


def read_binding(row):
    require(isinstance(row, dict) and set(row) == {"path", "bytes", "sha256"},
            "binding must contain only path, bytes, sha256")
    path = Path(row["path"])
    require(path.is_absolute() and path.is_file() and not path.is_symlink(),
            "binding is not an absolute regular file: " + str(path))
    require(type(row["bytes"]) is int and row["bytes"] >= 0, "invalid bound size")
    data = path.read_bytes()
    require(len(data) == row["bytes"] and digest(data) == row["sha256"],
            "binding changed: " + str(path))
    return data


def save(path, value):
    with path.open("x") as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write("\n")


def source_inventory(root):
    paths = [root / "Cargo.toml", root / "Cargo.lock"]
    for name in ("src", "assets", "crates"):
        paths.extend(p for p in (root / name).rglob("*")
                     if p.is_file() and "target" not in p.parts)
    return [fingerprint(p) for p in sorted(set(paths))]


def canonical_digest(value):
    return digest(json.dumps(value, sort_keys=True, separators=(",", ":")).encode())


def check_inputs(path, expected_sha):
    raw = path.read_bytes()
    require(digest(raw) == expected_sha, "explicit timing manifest digest mismatch")
    manifest = strict_json(raw)
    require(manifest["schema"] == "eris-runtime-init-timing-inputs-v1", "manifest schema")
    require(set(manifest["files"]) == {"driver", "harness", "protocol", "schedule",
                                         "build_plan", "build_driver", "build_correction"},
            "missing or extra manifest file role")
    files = manifest["files"]
    bindings = [fingerprint(path)] + list(files.values())
    captured = {role: read_binding(row) for role, row in files.items()}
    require(files["driver"]["path"] == str(Path(__file__).resolve()), "wrong timing driver")
    for role, name in (("harness", "runtime-init.rs"), ("schedule", "schedule.json")):
        require(files[role]["path"] == str(HERE / name)
                and files[role]["sha256"] == FIXED[name], "frozen " + role + " changed")
    schedule = strict_json(captured["schedule"])
    expected_runs = []
    for sample in range(24):
        for arm in (ARMS if sample % 2 == 0 else ARMS[::-1]):
            expected_runs.append(dict(slot=len(expected_runs), sample=sample,
                                      arm=arm, argument=str(sample)))
    require(schedule == dict(schema="eris-runtime-init-drop-schedule-v1",
                             toolchains_in_order=list(TOOLS),
                             apply_complete_schedule_separately_per_toolchain=True,
                             samples_per_arm=24, warmup_iterations_per_invocation=256,
                             batch_iterations_per_invocation=1024,
                             timeout_seconds_per_invocation=60, runs=expected_runs),
            "schedule does not match the frozen alternating protocol")
    plan = strict_json(captured["build_plan"])
    require(set(plan["rows"]) == BUILD_KEYS and set(manifest["builds"]) == BUILD_KEYS,
            "exactly four build arms required")
    builds = {}
    inventory_by_arm = {}
    versions = {}
    for key in sorted(BUILD_KEYS):
        spec = manifest["builds"][key]
        require(set(spec) == {"receipt", "library", "binary", "source_inventory_sha256"},
                "build binding fields differ: " + key)
        rec = strict_json(read_binding(spec["receipt"]))
        row = plan["rows"][key]
        bindings.extend(spec[k] for k in ("receipt", "library", "binary"))
        require(rec["arm"] == key and rec["source_unchanged"] is True
                and type(rec["timing_runs"]) is int and rec["timing_runs"] == 0,
                "build did not finish source checks: " + key)
        for rec_key, role in (("plan", "build_plan"), ("driver", "build_driver"),
                              ("harness", "harness")):
            require(rec[rec_key] == files[role], "build provenance differs: " + key)
        require(rec["environment"] == row["environment"], "build environment differs")
        require(rec["source_commit"] == plan["baseline_commit"], "unexpected source parent")
        require(rec["library"] == spec["library"] and rec["binary"] == spec["binary"],
                "receipt artifact differs: " + key)
        require(spec["binary"]["path"] == str(Path(row["out"]) / "runtime-init")
                and spec["library"]["path"] == str(Path(row["environment"]["CARGO_TARGET_DIR"])
                                                      / "release/liberis.rlib"),
                "wrong arm artifact paths")
        read_binding(spec["library"])
        read_binding(spec["binary"])
        require(os.access(spec["binary"]["path"], os.X_OK), "binary is not executable")
        commands = rec["commands"]
        require(len(commands) == 2, "expected library and wrapper stages")
        for stage, command in zip(("library", "wrapper"), commands):
            require(command["stage"] == stage and command["command"] == row[stage + "_command"]
                    and type(command["exit"]) is int and command["exit"] == 0,
                    "failed or unfrozen build stage: " + key)
            read_binding(command["log"])
            bindings.append(command["log"])
        require(row["arm"] in ARMS and row["toolchain"] in TOOLS, "build arm/toolchain")
        require(key == row["arm"] + "-" + row["toolchain"].replace(".", "")[:-1],
                "build key disagrees with plan")
        require(rec["rustc"].startswith("rustc " + row["toolchain"] + " "),
                "build compiler version mismatch")
        tc = row["toolchain"]
        require(tc not in versions or versions[tc] == rec["rustc"],
                "different compiler identity between arms")
        versions[tc] = rec["rustc"]
        current = source_inventory(Path(row["root"]))
        require(current == rec["source_before"]
                and canonical_digest(current) == spec["source_inventory_sha256"],
                "source inventory differs: " + key)
        arm = row["arm"]
        require(arm not in inventory_by_arm or inventory_by_arm[arm] == current,
                "toolchain builds used different source for " + arm)
        inventory_by_arm[arm] = current
        bindings.extend(current)
        builds[key] = dict(binary=spec["binary"], receipt=spec["receipt"],
                           source_inventory_sha256=spec["source_inventory_sha256"])
    # Full plan is frozen; also verify that arm differences are path-only.
    for tc, suffix in zip(TOOLS, ("188", "198")):
        normalized = []
        for arm in ARMS:
            row = plan["rows"][arm + "-" + suffix]
            def norm(value):
                return value.replace(row["out"], "<OUT>").replace(row["root"], "<ROOT>")
            normalized.append(([norm(x) for x in row["library_command"]],
                               [norm(x) for x in row["wrapper_command"]],
                               {k: norm(v) for k, v in row["environment"].items()}))
        require(normalized[0] == normalized[1], "unequal arm build flags: " + tc)
    return manifest, schedule, builds, bindings


def optional_read(path):
    try:
        return Path(path).read_text()
    except OSError as error:
        return {"unavailable": str(error)}


def host_state():
    state = dict(utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                 uname=list(platform.uname()), cpu_count=os.cpu_count(),
                 load_average=list(os.getloadavg()), affinity=sorted(os.sched_getaffinity(0)),
                 nice=os.getpriority(os.PRIO_PROCESS, 0),
                 cpuinfo=optional_read("/proc/cpuinfo"),
                 process_status=optional_read("/proc/self/status"),
                 governors={str(p): optional_read(p) for p in sorted(Path("/sys/devices/system/cpu")
                           .glob("cpufreq/policy*/scaling_governor"))})
    state["relevant_environment"] = {k: os.environ[k] for k in (
        "LANG", "LC_ALL", "LD_PRELOAD", "LD_LIBRARY_PATH", "MALLOC_CONF", "MALLOC_ARENA_MAX",
        "GLIBC_TUNABLES", "RUST_MIN_STACK", "RUST_BACKTRACE") if k in os.environ}
    state["policy_changes"] = "none; inherited affinity, priority, environment and governor"
    return state


def validate_observation(raw, sample):
    require(len(raw) <= 65536, "unexpectedly large observation; complete bytes retained")
    value = strict_json(raw.decode("utf-8"))
    keys = {"schema", "sample", "samples_per_arm", "warmup_iterations", "batch_iterations", "elapsed_ns"}
    require(isinstance(value, dict) and set(value) == keys, "observation keys/schema")
    require(value["schema"] == "eris-runtime-init-drop-v1", "observation schema")
    for key, expected in (("sample", sample), ("samples_per_arm", 24),
                          ("warmup_iterations", 256), ("batch_iterations", 1024)):
        require(type(value[key]) is int and value[key] == expected, "observation " + key)
    require(type(value["elapsed_ns"]) is int and value["elapsed_ns"] > 0
            and value["elapsed_ns"] <= 60_000_000_000, "elapsed time outside process deadline")
    return value


def kill_and_reap(process):
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass
    return process.wait()


def attempt(directory, tc, row, build, manifest_sha):
    directory.mkdir()
    command = [build["binary"]["path"], row["argument"]]
    record = dict(toolchain=tc, schedule=row, command=command, binary=build["binary"],
                  build_receipt=build["receipt"], manifest_sha256=manifest_sha,
                  timeout_seconds=60, cwd=str(HERE), load_before=list(os.getloadavg()),
                  exit=None, timed_out=False, error=None, observation=None, leader_reaped=False)
    save(directory / "command.json", record)
    process = None
    started = time.monotonic()
    try:
        with (directory / "stdout").open("xb") as stdout, (directory / "stderr").open("xb") as stderr:
            process = subprocess.Popen(command, cwd=HERE, stdin=subprocess.DEVNULL,
                                       stdout=stdout, stderr=stderr, start_new_session=True)
            try:
                record["exit"] = process.wait(timeout=60)
            except subprocess.TimeoutExpired:
                record["timed_out"] = True
                record["exit"] = kill_and_reap(process)
            record["leader_reaped"] = True
        require(not record["timed_out"] and record["exit"] == 0, "process failed or timed out")
        require((directory / "stderr").stat().st_size == 0, "unexpected stderr; retained in full")
        record["observation"] = validate_observation((directory / "stdout").read_bytes(), row["sample"])
    except BaseException as error:
        record["error"] = type(error).__name__ + ": " + str(error)
    finally:
        if process is not None:
            record["exit"] = (kill_and_reap(process) if process.poll() is None
                              else process.returncode)
            record["leader_reaped"] = True
        record["wall_seconds"] = time.monotonic() - started
        record["load_after"] = list(os.getloadavg())
        for stream in ("stdout", "stderr"):
            if (directory / stream).exists():
                record[stream] = fingerprint(directory / stream)
        save(directory / "result.json", record)
    return record


def summaries(records):
    result = {}
    for tc in TOOLS:
        arms = {arm: [None] * 24 for arm in ARMS}
        for rec in records:
            if rec["toolchain"] == tc:
                arms[rec["schedule"]["arm"]][rec["schedule"]["sample"]] = rec["observation"]["elapsed_ns"]
        require(all(type(v) is int and v > 0 for values in arms.values() for v in values),
                "incomplete per-toolchain samples")
        ratios = [c / b for b, c in zip(arms["baseline"], arms["candidate"])]
        q1, _, q3 = statistics.quantiles(ratios, n=4, method="inclusive")
        result[tc] = dict(raw_elapsed_ns_by_sample=arms, paired_candidate_over_baseline=ratios,
                          ratio_median=statistics.median(ratios), ratio_min=min(ratios),
                          ratio_max=max(ratios), ratio_q1=q1, ratio_q3=q3, ratio_iqr=q3-q1,
                          quartiles="linear inclusive interpolation (Python statistics.quantiles)",
                          median_ns_per_initialization={arm: statistics.median(values) / 1024
                                                        for arm, values in arms.items()},
                          samples_per_arm=24, discarded_valid_samples=0)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--inputs", type=Path, required=True)
    parser.add_argument("--inputs-sha256", required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir()  # Exclusive run; never resume or overwrite a partial schedule.
    result = dict(complete=False, error=None, postcheck_failures=[], attempts=[], summaries=None,
                  input_manifest=str(args.inputs.resolve()), expected_input_sha256=args.inputs_sha256,
                  limitation="One host, each toolchain separately, full initialization/drop only; no pooled or Chromium claims.")
    bindings = []
    try:
        manifest, schedule, builds, bindings = check_inputs(args.inputs.resolve(), args.inputs_sha256)
        save(output / "inputs.json", manifest)
        save(output / "host-before.json", host_state())
        save(output / "bindings-before.json", bindings)
        for tc, suffix in zip(TOOLS, ("188", "198")):
            for row in schedule["runs"]:
                directory = output / (suffix + "-" + str(row["slot"]).zfill(2) + "-" + row["arm"])
                rec = attempt(directory, tc, row, builds[row["arm"] + "-" + suffix], args.inputs_sha256)
                result["attempts"].append(rec)
                print(json.dumps(dict(toolchain=tc, slot=row["slot"], exit=rec["exit"],
                                      timed_out=rec["timed_out"], error=rec["error"])), flush=True)
                require(rec["error"] is None and rec["leader_reaped"], "failed scheduled observation; stopped")
        require(len(result["attempts"]) == 96, "incomplete schedule")
    except BaseException as error:
        result["error"] = type(error).__name__ + ": " + str(error)
    finally:
        # Recheck every captured byte binding even when a scheduled attempt failed.
        for row in bindings:
            try:
                read_binding(row)
            except Exception as error:
                result["postcheck_failures"].append(str(error))
        try:
            if bindings:
                check_inputs(args.inputs.resolve(), args.inputs_sha256)  # Also detect added source files.
        except Exception as error:
            result["postcheck_failures"].append(str(error))
        save(output / "host-after.json", host_state())
        if result["error"] is None and not result["postcheck_failures"]:
            result["summaries"] = summaries(result["attempts"])
            result["complete"] = True
        save(output / "result.json", result)
    return 0 if result["complete"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
