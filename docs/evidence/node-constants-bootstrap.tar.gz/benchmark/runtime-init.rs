//! One fixed, warmed initialization-and-drop timing sample per process.
//! Build this exact source against each separately pinned Eris library.

use eris::script::{Runtime, ScriptError};
use std::{hint::black_box, process::ExitCode, time::Instant};

const SAMPLE_COUNT: usize = 24;
const WARMUP_ITERATIONS: usize = 256;
const BATCH_ITERATIONS: usize = 1024;

fn batch(iterations: usize) -> Result<(), ScriptError> {
    for _ in 0..black_box(iterations) {
        let runtime = black_box(Runtime::try_new())?;
        drop(black_box(runtime));
    }
    Ok(())
}

fn run() -> Result<(), String> {
    let mut arguments = std::env::args().skip(1);
    let sample = arguments
        .next()
        .ok_or_else(|| "expected one sample index in 0..24".to_owned())?
        .parse::<usize>()
        .map_err(|_| "sample index must be an unsigned integer".to_owned())?;
    if sample >= SAMPLE_COUNT || arguments.next().is_some() {
        return Err("expected one sample index in 0..24".to_owned());
    }

    batch(WARMUP_ITERATIONS).map_err(|error| format!("warmup failed: {error}"))?;
    let start = Instant::now();
    let result = batch(BATCH_ITERATIONS);
    let elapsed = start.elapsed();
    result.map_err(|error| format!("measured initialization failed: {error}"))?;

    println!(
        "{{\"schema\":\"eris-runtime-init-drop-v1\",\"sample\":{sample},\"samples_per_arm\":{SAMPLE_COUNT},\"warmup_iterations\":{WARMUP_ITERATIONS},\"batch_iterations\":{BATCH_ITERATIONS},\"elapsed_ns\":{}}}",
        elapsed.as_nanos()
    );
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(message) => {
            eprintln!("runtime initialization benchmark: {message}");
            ExitCode::FAILURE
        }
    }
}
