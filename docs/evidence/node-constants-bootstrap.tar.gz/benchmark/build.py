"""Build a frozen benchmark arm, preserving commands and failures."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent


def fingerprint(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def source_bindings(root):
    files = [root / "Cargo.toml", root / "Cargo.lock"]
    for folder in [root / "src", root / "assets", root / "crates"]:
        files.extend(path for path in folder.rglob("*") if path.is_file()
                     and "target" not in path.parts)
    return [fingerprint(path) for path in sorted(set(files))]


def main():
    key, attempt = sys.argv[1:]
    if not attempt.isdecimal():
        raise ValueError("attempt must be a decimal number")
    plan = json.loads((HERE / "build-plan.json").read_text())
    row = plan["rows"][key]
    root, out = Path(row["root"]), Path(row["out"])
    out.mkdir(parents=True, exist_ok=True)
    records = out / ("attempt-" + attempt)
    records.mkdir()
    prep = json.loads((HERE / "preparation-source-ready.json").read_text())
    for binding in prep["files"]:
        assert fingerprint(HERE / binding["path"])["sha256"] == binding["sha256"]
    before = source_bindings(root)
    base = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip()
    if row["arm"] == "baseline":
        assert base == plan["baseline_commit"]
        assert not subprocess.check_output(["git", "status", "--porcelain"], cwd=root)
    env = os.environ.copy()
    env.update(row["environment"])
    version = subprocess.check_output(row["rustc_version_command"], env=env, text=True)
    receipt = dict(arm=key, attempt=attempt, source_commit=base,
                   plan=fingerprint(HERE / "build-plan.json"),
                   harness=fingerprint(HERE / "runtime-init.rs"),
                   driver=fingerprint(Path(__file__).resolve()),
                   source_before=before, rustc=version, environment=row["environment"],
                   commands=[])
    (records / "before.json").write_text(json.dumps(receipt, indent=2) + "\n")
    for stage, command in [("library", row["library_command"]),
                           ("wrapper", row["wrapper_command"])]:
        log = records / (stage + ".log")
        start = time.monotonic()
        with log.open("xb") as stream:
            result = subprocess.run(command, cwd=root, env=env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        receipt["commands"].append(dict(stage=stage, command=command,
                                         exit=result.returncode,
                                         seconds=time.monotonic() - start,
                                         log=fingerprint(log)))
        (records / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(receipt["commands"][-1]), flush=True)
        if result.returncode:
            print(log.read_text()[-12000:])
            return result.returncode
    after = source_bindings(root)
    receipt["source_unchanged"] = before == after
    assert receipt["source_unchanged"]
    for binding in prep["files"]:
        assert fingerprint(HERE / binding["path"])["sha256"] == binding["sha256"]
    receipt["library"] = fingerprint(Path(row["environment"]["CARGO_TARGET_DIR"])
                                        / "release/liberis.rlib")
    receipt["binary"] = fingerprint(out / "runtime-init")
    receipt["timing_runs"] = 0
    (records / "result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(dict(arm=key, binary=receipt["binary"], timing_runs=0)), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
