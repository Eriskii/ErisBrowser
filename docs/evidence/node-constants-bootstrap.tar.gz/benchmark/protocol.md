# Frozen initialization/drop benchmark protocol

This harness measures elapsed host time for a complete successful public `Runtime::try_new()` followed immediately by dropping that Runtime. It is separate from the logical-work ledger. No compiler or engine has run for this preparation; root reviews the source before the first baseline build.

Each invocation accepts one sample index in `0..24`, performs 256 complete untimed warmup iterations, and measures exactly 1,024 initialization/drop iterations with `Instant`. It emits one JSON record only after every measured Runtime has been dropped. The result and Runtime pass through `std::hint::black_box`; normal Result checking and loop/black-box overhead remain in the timed batch; timer overhead is not subtracted. The batch includes the public success-only author-budget reset and all destruction. It excludes process startup, argument parsing, warmup, output formatting and I/O. An initialization failure is a nonzero process result, retained as a failed observation rather than a valid timing sample.

No JavaScript source, DOM document, Page, renderer, worker, network or Date host is created. This does not time user script execution or page startup. The allocator is warmed within each fresh process; the test does not measure a cold first-ever initialization or steady-state initialization in an already busy browser.

## Identical builds

Root builds the title baseline and future candidate separately with each pinned Rust 1.88/1.98 toolchain, existing repository Cargo.lock, default empty features and the same release profile. Use separate target directories so one arm cannot silently reuse the other's library. Record exact source commit plus working-tree file binding, lock hash, compiler verbose version, build commands/environment, library and final harness binary hashes. Candidate and baseline must differ only by the intended repository source changes, not harness bytes or build settings.

The file is standalone Rust, needing only std and the public Eris library. A suitable build shape is:

```text
cargo build --locked --release --lib
rustc --edition=2024 -C opt-level=3 -C codegen-units=1 -C debuginfo=0 -C lto=off \
  --extern eris=<that arm's target/release/liberis.rlib> \
  -L dependency=<that arm's target/release/deps> \
  <frozen runtime-init.rs> -o <that arm's runtime-init executable>
```

Use the same pinned rustc as the library. Library release settings stay the repository's existing thin LTO/profile; the standalone wrapper deliberately uses the same stated non-LTO command for all arms. Freeze the concrete commands before the first build. If linking requires a build-command correction, preserve the failed command/output and apply the same correction to both arms before timing. Do not change harness constants after observing baseline or candidate durations.

## Fixed execution order and observations

Use `schedule.json` verbatim, separately per toolchain. It contains 24 adjacent baseline/candidate pairs: even sample indices run baseline then candidate, odd indices candidate then baseline. This balances early/late ordering and interleaves at the individual sample boundary. Each arm gets 24 fresh-process samples, 24,576 measured initializations and 6,144 warmup initializations per toolchain. Complete Rust 1.88 first, then Rust 1.98; evaluate each toolchain separately.

Do not run the two arms concurrently. Finish compilation before timing and avoid concurrent compiler, GPU, stress or other deliberate heavy work. Record whatever host/CPU/governor/affinity/load facts are available; do not change system policy for this measurement. Invocation, stdout, stderr, exit status, wall timeout status, schedule slot, sample index and binary/input hashes must be retained for every attempt. Use unique run directories and exclusive files. Verify frozen harness/source/binary bindings again after the schedule.

Use a fixed generous per-process timeout of 60 seconds. Invalid output, nonpositive elapsed time, wrong counts/index, initialization error, signal or timeout is a failed scheduled observation. Preserve it and stop that run; any later complete rerun receives a new run ID and retains the earlier run. A slow but valid timing is never discarded or retried for being inconvenient. Do not insert an unrecorded warmup process or choose iteration counts adaptively.

## Comparison and limits

Report all 24 raw elapsed values per arm and toolchain, dividing by 1,024 only for presentation. Pair samples by the frozen index; summarize the median of candidate/baseline elapsed-time ratios, the ratio range and interquartile range, plus each arm's median time per initialization. Do not pool 1.88 with 1.98 or treat individual initializations within one batch as independent samples. Keep logical charged-work/heap changes in a separate table.

These observations include scheduling, CPU frequency/thermal state, allocator behavior and system noise. Alternating order and warmup reduce some bias but do not remove it. Small or inconsistent differences are inconclusive; lower logical work is not proof of faster host execution. This is one host, these pinned release builds, this full initialization/drop workload, and no benchmark speed claim until the retained observations support it. There is no preselected percentage threshold that forces an optimization decision.
