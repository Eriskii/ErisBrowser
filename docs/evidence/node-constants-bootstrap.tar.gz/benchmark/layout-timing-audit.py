#!/usr/bin/env python3
"""Independent data-only timing audit; never imports/runs the timing driver."""
from pathlib import Path
import hashlib, json, math, traceback
P=Path('/tmp/eris-node-constants-batch-1/benchmark')
R=P/'runs/run-1'
OUT=P/'layout-timing-review.json'
EXPECTED='74c82adf9e801ea884dcdc05642e7edcb35ba971c857bca3c7aa0ef96ff81767'
cache={}
def need(v,m):
    if not v: raise ValueError(m)
def sha(b): return hashlib.sha256(b).hexdigest()
def fp(p):
    p=Path(p); need(p.is_file() and not p.is_symlink(),f'nonregular {p}')
    b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def check(row):
    p=row['path']
    if p not in cache: cache[p]=fp(p)
    need(cache[p]==row,f'binding {p}')
    return Path(p)
def read(p):
    def pairs(items):
        d={}
        for k,v in items:
            need(k not in d,f'duplicate {k}');d[k]=v
        return d
    def bad(v): raise ValueError('nonfinite '+v)
    return json.loads(Path(p).read_bytes().decode('utf-8'),object_pairs_hook=pairs,parse_constant=bad)
def inventory(root):
    ps=[root/'Cargo.toml',root/'Cargo.lock']
    for d in ['src','assets','crates']:
        ps.extend(p for p in (root/d).rglob('*') if p.is_file() and 'target' not in p.parts)
    return [fp(p) for p in sorted(set(ps))]
def canonical(v):return sha(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def median(v):
    a=sorted(v); n=len(a);return a[n//2] if n%2 else (a[n//2-1]+a[n//2])/2
# Inclusive linear quartiles, independently indexed instead of statistics.quantiles.
def quartile(v,numerator):
    a=sorted(v); k=(len(a)-1)*numerator;lo,rem=divmod(k,4)
    return (a[lo]*(4-rem)+a[min(lo+1,len(a)-1)]*rem)/4
report={'complete':False,'engine_or_compiler_runs':0,'findings':[]}
try:
    raw=R/'inputs.json';need(sha(raw.read_bytes())==EXPECTED,'captured manifest')
    inp=read(raw);m=P/'timing-inputs.json';need(m.read_bytes()==raw.read_bytes(),'manifest exact')
    top=read(R/'result.json');need(top['complete'] is True and top['error'] is None and top['postcheck_failures']==[],'completion')
    need(top['input_manifest']==str(m) and top['expected_input_sha256']==EXPECTED,'top manifest')
    files=inp['files'];need(set(files)=={'driver','harness','protocol','schedule','build_plan','build_driver','build_correction'},'roles')
    expected_bindings=[fp(m)]+list(files.values())
    for row in files.values():check(row)
    need(files['driver']['sha256']=='f792565ce708cfd91a7cf6e645a71e5b1e1e556263b458f4252fbca52fdeb233','frozen driver')
    need(files['harness']['sha256']=='9c4bdd7d8f9b7d9c285c9d0e09d18fc75c94fc897a45acc333a556e5f3f280e6','frozen harness')
    need(files['schedule']['sha256']=='2d80b81985fed0444ebdd82e859201ebbc92e2d8b648ea84b0907e57149426e3','frozen schedule')
    schedule=read(check(files['schedule'])); plan=read(check(files['build_plan']))
    expected=[]
    for i in range(24):
        for arm in (['baseline','candidate'] if i%2==0 else ['candidate','baseline']):
            expected.append({'slot':len(expected),'sample':i,'arm':arm,'argument':str(i)})
    need(schedule=={'schema':'eris-runtime-init-drop-schedule-v1','toolchains_in_order':['1.88.0','1.98.0'],'apply_complete_schedule_separately_per_toolchain':True,'samples_per_arm':24,'warmup_iterations_per_invocation':256,'batch_iterations_per_invocation':1024,'timeout_seconds_per_invocation':60,'runs':expected},'complete schedule')
    keys={a+'-'+t for a in ['baseline','candidate'] for t in ['188','198']}
    need(set(inp['builds'])==set(plan['rows'])==keys,'four builds')
    inventories={};builds=[];versions={}
    for key in sorted(keys):
        spec=inp['builds'][key];rec=read(check(spec['receipt']));row=plan['rows'][key]
        expected_bindings.extend(spec[k] for k in ['receipt','library','binary'])
        need(rec['arm']==key and rec['source_unchanged'] is True and type(rec['timing_runs']) is int and rec['timing_runs']==0,'successful build')
        for rk,fk in [('plan','build_plan'),('harness','harness'),('driver','build_driver')]:need(rec[rk]==files[fk],'build provenance')
        need(rec['source_commit']==plan['baseline_commit']=='bb69700794bde2c0dbda26bd2994f767c3fd0712','parent commit')
        need(rec['environment']==row['environment'],'build environment')
        need(rec['library']==spec['library'] and rec['binary']==spec['binary'],'artifacts')
        check(spec['library']);check(spec['binary'])
        need(spec['binary']['path']==str(Path(row['out'])/'runtime-init'),'binary path')
        need(spec['library']['path']==str(Path(row['environment']['CARGO_TARGET_DIR'])/'release/liberis.rlib'),'library path')
        need(len(rec['commands'])==2,'build stage count')
        for stage,command in zip(['library','wrapper'],rec['commands']):
            need(command['stage']==stage and command['command']==row[stage+'_command'] and type(command['exit']) is int and command['exit']==0,'build command')
            check(command['log']);expected_bindings.append(command['log'])
        need('lto=thin' in rec['commands'][1]['command'],'uniform corrected LTO')
        tc=row['toolchain'];need(rec['rustc'].startswith('rustc '+tc+' '),'compiler')
        need(tc not in versions or versions[tc]==rec['rustc'],'same compiler per arms');versions[tc]=rec['rustc']
        root=Path(row['root'])
        if str(root) not in inventories:inventories[str(root)]=inventory(root)
        now=inventories[str(root)]
        need(now==rec['source_before'] and canonical(now)==spec['source_inventory_sha256'],'current complete source inventory')
        expected_bindings.extend(now)
        builds.append({'key':key,'receipt':spec['receipt'],'binary':spec['binary'],'library':spec['library'],'source_inventory_sha256':canonical(now),'source_count':len(now)})
    for tc in ['188','198']:
        normalized=[]
        for arm in ['baseline','candidate']:
            r=plan['rows'][arm+'-'+tc]
            def norm(s):return s.replace(r['out'],'<OUT>').replace(r['root'],'<ROOT>')
            normalized.append(([norm(s) for s in r['library_command']],[norm(s) for s in r['wrapper_command']],{k:norm(v) for k,v in r['environment'].items()}))
        need(normalized[0]==normalized[1],'same arm flags')
    need(read(R/'bindings-before.json')==expected_bindings,'complete captured binding roster')
    for row in expected_bindings:check(row)
    corr=read(check(files['build_correction']));need(corr['corrected_plan_sha256']==files['build_plan']['sha256'] and corr['timing_runs_before_correction']==0,'link correction binding')
    old=read(P/corr['initial_build_receipt']);need(old['commands'][0]['exit']==0 and old['commands'][1]['exit']!=0,'first failed link retained')
    for command in old['commands']:check(command['log'])
    old_plan=P/'link-correction/build-plan.json';need(fp(old_plan)['sha256']==corr['original_plan_sha256'],'prior plan retained')
    need(len(top['attempts'])==96,'96 attempts')
    directories=[];raws={};raw_bindings=[];counts=[]
    for tc,suffix in [('1.88.0','188'),('1.98.0','198')]:
        arms={arm:[None]*24 for arm in ['baseline','candidate']}
        for slot in expected:
            d=R/f"{suffix}-{slot['slot']:02d}-{slot['arm']}";directories.append(d.name)
            need({p.name for p in d.iterdir()}=={'command.json','result.json','stdout','stderr'},'slot exact payloads')
            cmd=read(d/'command.json');rec=read(d/'result.json');spec=inp['builds'][slot['arm']+'-'+suffix]
            for key,value in [('toolchain',tc),('schedule',slot),('command',[spec['binary']['path'],slot['argument']]),('binary',spec['binary']),('build_receipt',spec['receipt']),('manifest_sha256',EXPECTED),('timeout_seconds',60),('cwd',str(P))]:
                need(cmd[key]==rec[key]==value,'slot command binding '+key)
            need(cmd['exit'] is None and cmd['observation'] is None and cmd['error'] is None and cmd['leader_reaped'] is False,'initial command receipt')
            need(type(rec['exit']) is int and rec['exit']==0 and rec['timed_out'] is False and rec['error'] is None and rec['leader_reaped'] is True,'slot outcome')
            need(0<rec['wall_seconds']<60,'wall bound')
            need((d/'stderr').read_bytes()==b'','empty stderr');obs=read(d/'stdout')
            need((d/'stdout').stat().st_size<=65536,'bounded JSON')
            need(set(obs)=={'schema','sample','samples_per_arm','warmup_iterations','batch_iterations','elapsed_ns'},'JSON fields')
            need(obs['schema']=='eris-runtime-init-drop-v1','JSON schema')
            for k,v in [('sample',slot['sample']),('samples_per_arm',24),('warmup_iterations',256),('batch_iterations',1024)]:need(type(obs[k]) is int and obs[k]==v,'strict counts')
            need(type(obs['elapsed_ns']) is int and 0<obs['elapsed_ns']<=60000000000,'positive elapsed')
            need(rec['observation']==obs and top['attempts'][len(directories)-1]==rec,'raw/slot/aggregate equality')
            for stream in ['stdout','stderr']:need(fp(d/stream)==rec[stream],'raw stream binding')
            for name in ['command.json','result.json','stdout','stderr']:raw_bindings.append(fp(d/name))
            need(arms[slot['arm']][slot['sample']] is None,'no duplicate sample');arms[slot['arm']][slot['sample']]=obs['elapsed_ns']
        raws[tc]=arms
    need({p.name for p in R.iterdir() if p.is_dir()}==set(directories),'no extra/discarded attempt dirs')
    need({p.name for p in R.iterdir() if p.is_file()}=={'inputs.json','bindings-before.json','host-before.json','host-after.json','result.json'},'run files')
    recalculated={}
    for tc,arms in raws.items():
        need(all(type(v) is int for vs in arms.values() for v in vs),'24 pairs')
        ratios=[c/b for b,c in zip(arms['baseline'],arms['candidate'])];s=top['summaries'][tc]
        need(s['raw_elapsed_ns_by_sample']==arms and s['paired_candidate_over_baseline']==ratios,'all raw ratios retained')
        q1=quartile(ratios,1);q3=quartile(ratios,3)
        metrics={'ratio_median':median(ratios),'ratio_min':min(ratios),'ratio_max':max(ratios),'ratio_q1':q1,'ratio_q3':q3,'ratio_iqr':q3-q1}
        for k,v in metrics.items():need(math.isclose(v,s[k],rel_tol=1e-15,abs_tol=1e-15),'recomputed '+k)
        medians={arm:median(vs)/1024 for arm,vs in arms.items()}
        need(s['median_ns_per_initialization']==medians and s['samples_per_arm']==24 and s['discarded_valid_samples']==0,'arm medians/discards')
        recalculated[tc]={**metrics,'per_arm_batch_ns_median':{a:median(v) for a,v in arms.items()},'median_ns_per_initialization':medians,'pairs':24,'discarded':0}
    before=read(R/'host-before.json');after=read(R/'host-after.json')
    for k in ['affinity','nice','relevant_environment','governors','policy_changes']:need(before[k]==after[k],'host policy stable '+k)
    need(before['policy_changes']=='none; inherited affinity, priority, environment and governor','no policy adjustment')
    snapshot=read(P.parent/'source-ready-final.json')
    report.update(complete=True,input_manifest=fp(m),aggregate_result=fp(R/'result.json'),captured_bindings=fp(R/'bindings-before.json'),binding_rows=len(expected_bindings),unique_current_files=len(cache),builds=builds,observations=96,raw_payloads=raw_bindings,recomputed=recalculated,host_records=[fp(R/'host-before.json'),fp(R/'host-after.json')],logical_measurement_receipt=fp(P.parent/'source-ready-final.json'),retained_logical_savings={'work':4742,'charged_bytes':69264},interpretation='Both paired medians exceed 1 and distributions span 1. This one-host full Runtime initialization/drop experiment does not demonstrate wall-time speedup; it does not establish a meaningful slowdown either. Retained logical charge reductions are separate measured accounting results. No samples discarded; no pooling or Chromium claim.',sequential_execution_evidence='The frozen driver waits and reaps each subprocess before invoking the next; 96 individual records and the aggregate preserve exactly the prescribed order.',postcheck='Run reports no postcheck failures; independent current byte and complete source-inventory checks all pass.',prior_link_failure={'receipt':fp(P/corr['initial_build_receipt']),'correction':files['build_correction']},auditor=fp(Path(__file__)))
except Exception as e:
    report['findings'].append(type(e).__name__+': '+str(e));report['traceback']=traceback.format_exc()
with OUT.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
print(json.dumps({k:report[k] for k in ['complete','findings']},indent=2))
if report['complete']:print(json.dumps(report['recomputed'],indent=2))
print(json.dumps(fp(OUT)))
raise SystemExit(0 if report['complete'] else 1)
