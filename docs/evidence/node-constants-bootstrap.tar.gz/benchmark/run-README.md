# Frozen timing driver

`run.py` is authored but has not been imported, executed or used to invoke a
compiler, harness or engine. Only Python AST syntax parsing is permitted at this
preparation stage. Root reviews and freezes this source before timing.

Invoke only after all four builds succeeded and deliberate heavy work stopped:

```
python3 /tmp/eris-node-constants-batch-1/benchmark/run.py \
  --inputs /absolute/path/to/timing-inputs.json \
  --inputs-sha256 <exact-sha256> \
  --output /tmp/eris-node-constants-batch-1/benchmark/runs/run-1
```

The output parent must already exist; the run directory must not. Each complete
rerun gets a fresh directory. Never resume a partial run, replace a scheduled
sample, discard a slow valid result, or run arms/toolchains concurrently. Complete
all 48 Rust 1.88 invocations before the 48 Rust 1.98 invocations. The driver uses
the frozen schedule verbatim and has no build commands or warmup-only process.

## Later explicit input manifest

The root-owned manifest is intentionally not populated during this preparation.
It has this schema (all paths absolute):

```
{
  "schema": "eris-runtime-init-timing-inputs-v1",
  "files": {
    "driver": {"path": ".../run.py", "bytes": 0, "sha256": "..."},
    "harness": {"path": ".../runtime-init.rs", "bytes": 1776, "sha256": "..."},
    "protocol": {"path": ".../protocol.md", "bytes": 0, "sha256": "..."},
    "schedule": {"path": ".../schedule.json", "bytes": 5065, "sha256": "..."},
    "build_plan": {"path": ".../build-plan.json", "bytes": 0, "sha256": "..."},
    "build_driver": {"path": ".../build.py", "bytes": 0, "sha256": "..."},
    "build_correction": {"path": ".../correction-receipt.json", "bytes": 0, "sha256": "..."}
  },
  "builds": {
    "baseline-188": {
      "receipt": {"path": ".../attempt-2/result.json", "bytes": 0, "sha256": "..."},
      "library": {"path": ".../target/release/liberis.rlib", "bytes": 0, "sha256": "..."},
      "binary": {"path": ".../runtime-init", "bytes": 0, "sha256": "..."},
      "source_inventory_sha256": "..."
    },
    "candidate-188": {"receipt": {}, "library": {}, "binary": {}, "source_inventory_sha256": "..."},
    "baseline-198": {"receipt": {}, "library": {}, "binary": {}, "source_inventory_sha256": "..."},
    "candidate-198": {"receipt": {}, "library": {}, "binary": {}, "source_inventory_sha256": "..."}
  }
}
```

The illustrative zero sizes/empty rows are not valid bindings. Use actual sizes
and hashes. `source_inventory_sha256` is SHA-256 of the successful receipt's
`source_before` serialized using `json.dumps(value, sort_keys=True,
separators=(",", ":")).encode()`. Every complete source inventory is already
contained in that bound receipt; it is re-enumerated and checked before and after
timing, including added files. The two compiler builds for each arm must bind
identical source rows, and each baseline/candidate pair must bind identical
compiler verbose versions and build flags after normalizing only arm paths.

Use the successful receipts from the uniformly corrected build plan (thin-LTO
wrapper correction). Bind its correction receipt under `build_correction`; keep
failed original plans/logs elsewhere unchanged. The harness and schedule retain
their original fixed hashes. Driver, corrected build helper, plan, libraries,
binaries, successful logs, protocol, correction record, complete source files
and input manifest are all checked again after the schedule, including after a
failed observation. Keep main baseline and isolated candidate source paths
unchanged until timing finishes. This driver does not compile or reconstruct
historical source snapshots.

## Observations and failure retention

Every scheduled slot receives its own exclusive directory with `command.json`,
complete `stdout`, complete `stderr`, and `result.json`. Records include arm,
toolchain, slot/index, input/binary/build bindings, timeout, exit code, wall time,
load and leader-reaping state. A process runs in its own session; a timeout or
interruption kills its owned group and reaps the leader. No next process starts
until that attempt completes. The fixed deadline is 60 seconds.

Only one strict JSON object with the exact six harness fields is accepted.
Duplicate keys, nonfinite numbers, boolean/float counts, wrong index/counts,
nonpositive/over-deadline elapsed time, unexpected stderr, extra output,
nonzero exit, timeout and initialization failure stop the run. A 64 KiB parser
limit rejects unexpected output while retaining all bytes on disk. No missing
observation can become a valid timing. Failed runs retain partial observations
but publish no comparative summary. A completed run requires all 96 valid
records and successful final binding checks.

Host records include uname, CPU information/count, affinity, nice priority,
readable governors, process status, load and selected allocation/runtime
environment variables. The driver changes none of those settings. These facts
cannot prove the absence of unrelated system load; root owns the operational
choice to avoid deliberate competing work.

For each toolchain separately, all 24 baseline/candidate elapsed arrays and all
24 index-paired candidate/baseline ratios are retained. The summary reports
ratio median/minimum/maximum, Q1/Q3/IQR using linear inclusive interpolation,
and each arm's median nanoseconds per initialization (batch time / 1024).
Ratios below one indicate lower measured time for that pair; no automatic
performance verdict or significance threshold is applied. No pooling across
toolchains, discarded valid samples, per-initialization independence claim,
Chromium comparison or page-startup claim is made.
