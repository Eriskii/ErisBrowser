import hashlib,json,os,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent/'worktree'
env=os.environ.copy();env.update(CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup')
label='format-198-1';command=['cargo','+1.98.0','fmt','--all','--','--check'];log=HERE/(label+'.log');start=time.monotonic()
with log.open('xb') as f:result=subprocess.run(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
receipt=dict(command=command,exit=result.returncode,elapsed_seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (HERE/(label+'.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt),flush=True)
if result.returncode:print(log.read_text()[-10000:]);raise SystemExit(result.returncode)
checks=[
 ['clippy-native-198-1','1.98.0','Cargo.toml','vulkan-raster','clippy','--all-targets','--','-D','warnings'],
 ['clippy-presenter-188-1','1.88.0','Cargo.toml','vulkan-presenter','clippy','--all-targets','--','-D','warnings'],
 ['full-default-188-1','1.88.0','Cargo.toml','-','test','--','--include-ignored'],
 ['full-native-198-1','1.98.0','Cargo.toml','vulkan-raster','test','--','--include-ignored'],
 ['release-adapter-188-1','1.88.0','Cargo.toml','-','build','--release','--bin','eris-js']]
for args in checks:
 result=subprocess.run(['python3',str(HERE/'check.py'),*args],cwd=ROOT,env=env)
 if result.returncode:raise SystemExit(result.returncode)
