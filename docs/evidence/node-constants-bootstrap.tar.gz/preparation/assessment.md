# Bounded bootstrap optimization: batch Node constants

Recommend one narrow change in `src/script/dom_prototypes.rs`: replace the repeated insertion of Node's 18 constants into its constructor and prototype maps with two prepaid, sorted 21-entry builds. Keep the real mutable `ScriptObject` bags, their creation-order vectors, all function identities and the indexed interface representation. This removes repeated tree searches and shifts; it does not change the cost assigned to a UTF-16 comparison.

This assessment reads main commit `7765fbf8f44c3dea96b6a09316ea352f59a2a57d`. No implementation, compiler, engine, test or benchmark was run. The only calculation was arithmetic over the static source table and existing ledger formulas. The title worktree was not changed.

## Current boundary and useful hot spot

The held raw-bootstrap witness is 6,640 remaining work units, 1,798,334 charged bytes, 677 objects/capacity, 321 native registry entries and 25 legacy prototypes. Title's separate ledger predicts a 360-unit debit, leaving 6,280; that is a prediction, not a new measurement. Both bootstrap and author work limits are 100,000. `try_new` grants the author allowance only after successful `finish_bootstrap`; cumulative heap remains charged under the existing 8 MiB limit. These boundaries need no change for this proposal.

Most of the 154-interface installer already avoids redundant native/prototype name maps: eager indexed records and direct native bag handles are present, and globals already use a consuming sorted merge. The remaining conspicuous map hot spot is Node's long constant names. Immediately before the constant loop, both affected maps have three entries: constructor `length/name/prototype`, and prototype `Symbol.toStringTag/nodeValue/textContent`. Each then receives the same 18 constants, one at a time. Prototype `constructor` is still added afterward.

For each map, the current constant loop's map work is exactly the source formula summed over counts 3 through 20:

`sum(tree_bound(count).comparisons * (1 + key_units) + moves(count) + 1) = 6,050`.

Thus these 36 map insertions cost 12,100 logical work units, apart from the unchanged literal-string construction. The longest key has 41 UTF-16 units. This calculation is not elapsed-time evidence.

## Small algorithm

1. Keep all object allocations and nonconstant property installation in their existing positions. The owners' order vectors already reserve the eventual 21/22 entries; verify their spare capacity instead of introducing implicit growth.
2. Materialize the 18 literal keys once, as today, through `dom_proto_text`. A small fallibly reserved key vector is acceptable; charge its full requested storage and all handle clones/writes. Constants remain ordinary numeric, nonwritable, enumerable, nonconfigurable properties.
3. Prepare a final 21-entry vector for each owner. Emit constant entries in a static sorted permutation, then move the old three map entries in their existing sorted order. Current constant names are uppercase ASCII, while old string keys are lowercase and `PropertyKey::Symbol` sorts after strings. Do not rely only on that comment: check bounded owner counts/key lengths, and pay a strict adjacent-order/uniqueness check before collection. A malformed table must fail, never fall back to a cheaper unsorted assumption.
4. Separately append the 18 constant keys to each owner's ordinary order vector in the existing IDL/source order. Do not replace JavaScript property order with lexicographic map order. The prototype's later `constructor` insertion remains in its current position and retains its normal charge.
5. Collect each fresh, unadvanced vector directly into a `BTreeMap<PropertyKey, Property>`. Publish both completed maps and their order additions after admission/validation. Failure discards the private initializing Runtime; no author code or callback can observe an intermediate bag.

The static permutation of the current 18-entry table is `[1,3,7,10,8,16,15,12,14,17,13,9,0,5,4,11,6,2]`. It is an implementation candidate, not a reason to omit paid runtime order validation. Keep this helper scoped to Node's known bag shape; do not replace the general property insertion path.

## Preserve charges for reached work

For each final map, `N=21`, old entries `o=3`, old nodes at most one, fresh height bound `h=1`, fresh node allocation bound three. Pay 20 strict-order comparisons, 20 stable-sort comparisons and 20 adjacent-dedup comparisons. Charging each at `1 + 41` preserves the existing **full UTF-16** comparison unit: 2,520 work per map. The byte-key `bulk_plan` uses `1 + max_length/8`; it must not be reused unchanged for PropertyKey.

Using the existing conservative structural units gives a provisional 510 per map: fixed64, old consumption16, entry/vector transfer126, bulk writes168, overflow navigation16, border repair64, node headers24, root/iterator setup32. The transfer allowance remains conservative even though known order avoids a comparison merge. Combined map work is 3,030 each, leaving **6,040 gross units before new staging, owner guards, order writes, reservations and checked-arithmetic work**. Derive those remaining terms from the actual implementation before approval; this is not a target allowance or a promised net saving.

Keep all still-reached `dom_proto_text`, object-base, property fixed/payload and native metadata charges. Remove the repeated insertion search/split rows only when those operations disappear. Prepay both complete entry buffers, the temporary key handles, every new tree node using actual `PropertyKey/Property` sizes, and full sort scratch (`48 * sizeof((PropertyKey, Property))` per map is the existing conservative bound at N=21). Existing old-map storage stays cumulatively charged after its nodes are retired. No reference-count alias permits refunding old storage or sharing mutable bags. The direct Vec consumption avoids an extra collection buffer only on the pinned specialization; an adapter or different iterator requires another allocation allowance.

All checked work/storage admission and fallible vector reservations must precede taking an old map. Strict-order failure after consuming it is a terminal private-initializer error, as in current global publication. Do not promise reusable-map rollback. No successful realm can escape a later failure or receive an author allowance early. Allocation failure handling retains the existing distinction: checked Vec errors propagate; standard BTree allocation remains an inherited infallible allocator boundary.

## Why this bounded path

The earlier Node-bag idea was insufficient when the original three-registry design exceeded bootstrap by roughly 26,448 units. The current indexed representation already removed that larger problem. A several-thousand-unit candidate is now useful without redesigning runtime property access, lazy initialization, startup quotas or author entry resets.

The old generic `intrinsic_function` does contain repeated registry searches, descriptor rewrites and an overwritten Object prototype lookup. However, many historical callers do not meter those operations individually; deleting them cannot justify inventing a bootstrap credit. ArrayBuffer still has its separate conservative insertion allowance. Changing its 128-unit factor to 28 alone would be a fee/proof revision, not the requested algorithmic optimization. Both are separate work; keep them out of this change.

## Required later verification

Review the concrete ledger first, then measure raw bootstrap once on both supported Rust versions. Retain current quotas and success-only author grant. Bind all 18 values/descriptor flags and complete constructor/prototype own-key order, saved accessor and constructor identities, and separate mutable bags across two realms. Exercise exact/one-short work and storage admission plus wrong owner shape, duplicate/unsorted staging and insufficient order capacity; failure must not publish a usable partial realm. Existing complete-bootstrap failure tests and the unchanged browser fixtures should continue to pass. Do not update a descriptive bootstrap snapshot until the measured successful result exists.

## Primary implementation references

The version-pinned [Rust 1.88 BTreeMap](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/map.rs) and [Rust 1.98 BTreeMap](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/map.rs) both collect inputs to a Vec, stably sort and bulk-build. `extend` still inserts individually. [1.88 Vec specialization](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/vec/spec_from_iter.rs) and [1.98 specialization](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/vec/spec_from_iter.rs) reuse a direct unadvanced Vec iterator allocation. The [1.88 stable-sort entry](https://github.com/rust-lang/rust/blob/1.88.0/library/core/src/slice/sort/stable/mod.rs) and [1.98 entry](https://github.com/rust-lang/rust/blob/1.98.0/library/core/src/slice/sort/stable/mod.rs) allocate possible scratch before run detection above 20 entries; [1.88](https://github.com/rust-lang/rust/blob/1.88.0/library/core/src/slice/sort/stable/drift.rs) and [1.98](https://github.com/rust-lang/rust/blob/1.98.0/library/core/src/slice/sort/stable/drift.rs) ascending-run handling needs N−1 comparisons. These paths were re-read for this assessment. Existing reviewed structural bounds are retained, not replaced with guessed lower constants.
