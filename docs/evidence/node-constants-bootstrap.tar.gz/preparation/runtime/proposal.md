# Node constants: proposed bounded batch installer

Proceed with the two Node constant maps only. Keep eager mutable bags and every existing object/native identity. Replace the 36 repeated tree insertions with two guarded, sorted 21-entry builds. This is a source-only proposal, not an implemented or measured optimization. No repository edits, compiler, engine or benchmark runs were made for this review.

The title code is now integrated. Its focused measurement is **6,280 remaining bootstrap work, 1,804,200 charged bytes, 679 objects/capacity, 321 native registry entries and 25 legacy prototypes** (`/tmp/eris-document-title-1/validation/runtime-title-188-1.log`). This supersedes the assessment's title prediction, not any quota. Bootstrap/author allowances remain 100,000 each, cumulative heap remains 8 MiB, and only successful `try_new` grants author work.

## Scope and sequence

Add a private `install_node_constants(&mut self, prototype: usize, properties: usize, tag_key: &PropertyKey) -> Result<()>` near `dom_proto_property`. Call it at the existing Node constant-loop location, after `install_node_data_members`. Other interfaces, generic `dom_proto_property`, byte-key `bulk_plan`, global publication and later prototype `constructor` insertion stay on their current paths. A small private consuming helper may assemble/check one final map; no generic transaction or metadata representation is needed.

1. Pay the fixed guard/plan work below before inspecting owner contents. Check valid distinct IDs, three map/order entries each, and already reserved order capacity: prototype at least 22, constructor at least 21. Check exact expected keys in both sorted-map order and physical creation order without allocating strings or doing tree lookups. Use static ASCII-unit comparisons and the existing `tag_key` identity; reject overlong keys before comparisons.
2. Validate the fixed roster length 18 and permutation length 18, each index in range and each static key at most 41 ASCII bytes. Materialize each key once in original IDL order via unchanged `dom_proto_text`. Store the 18 handles in one fallibly prepaid vector. The production table remains the sole source of values.
3. Prepay both map-build allowances, all 36 existing per-property payload allowances, all order writes, and all temporary/sort/tree storage. Fallibly reserve both complete 21-entry vectors before taking either old map. No order growth is permitted. Arithmetic uses checked operations and returns the existing Resource error on overflow.
4. Emit 18 fresh numeric descriptors per vector using the static sorted permutation. Then move the old three entries from each bag into that vector using the old map's owning iterator. Constants currently sort before all old entries: uppercase strings precede lowercase strings; the Symbol variant follows all strings. Check each complete vector's 20 adjacent pairs with the actual `PropertyKey` ordering. A bad permutation, duplicate or collision returns Resource before `collect`; never sort an unchecked row under the sorted-input fee.
5. Collect each **unadvanced direct Vec iterator** into its replacement `BTreeMap`. Keep both completed maps local until both builds have succeeded. Append each constant key to both existing order vectors in original IDL order, then assign both completed maps; this final section has no callbacks, checked debits or recoverable allocations. Leave the subsequent prototype `constructor` insertion in place.

All quota checks and fallible reservations precede `mem::take`. A staging invariant failure discovered after taking a map is terminal for this private initializer; discarded old maps need not be restored. There is no public reusable-map rollback promise. No incomplete Runtime returns, no author allowance is granted, and cleanup retains all consumed counters. Standard BTree/sort allocator abort behavior remains an inherited limitation; checked vector refusal is not a physical-OOM simulation.

## Exact semantic invariants

At entry, constructor map/physical order is `length,name,prototype`. Prototype map order is `nodeValue,textContent,Symbol.toStringTag`, while its physical order is `Symbol.toStringTag,nodeValue,textContent`. Preserve the old descriptors and Native handles **by move**, including accessors, name/prototype values and flags; do not reconstruct them.

After all initialization, constructor string-key order stays `length,name,prototype` then the 18 constants in existing IDL order. Prototype string-key order stays `nodeValue,textContent`, those same 18 constants, then `constructor`; full `Reflect.ownKeys` places its `Symbol.toStringTag` after the strings. Physical symbol-first order remains unchanged internally. Constants stay numeric, nonwritable, enumerable and nonconfigurable. All other ScriptObject fields, object IDs, native metadata handles, realm isolation and saved function identities remain unchanged.

The reviewed sorted permutation is `[1,3,7,10,8,16,15,12,14,17,13,9,0,5,4,11,6,2]`. Runtime adjacent validation remains mandatory. A pure inventory test checks it is a permutation and its literal name order, independently of the installer.

## Proposed work ledger

Use the existing full UTF-16 comparison policy, **1+41=42** per guarded key comparison; do not call the byte-key `bulk_plan` or divide lengths by eight. Here `m=18`, `o=3`, `N=21`, old-node bound=1, fresh height=1 and fresh-node bound=3. The reviewed structural bounds apply identically to both maps.

| Per-map reached work | Units |
|---|---:|
| Strict final-vector ordering, ascending-run sort, adjacent dedup: 3×20×42 | 2,520 |
| Fixed map setup | 64 |
| Consume/retire old tree: 4×(3+1) | 16 |
| Emit/transfer complete entries: 6×21 | 126 |
| Fresh-tree writes and lengths: 8×21 | 168 |
| Overflow navigation: 4×(2×1+2)×floor(21/12) | 16 |
| Right-border repair bound: 64×1 | 64 |
| Three node headers: 8×3 | 24 |
| Root/iterator setup: 16×(1+1) | 32 |
| **Per map** | **3,030** |

The 6N transfer term covers indexed constant access, key-handle clone, fixed numeric descriptor/tuple construction, vector write and advancement. The separate 8N term covers fresh node writes and length transitions; it is not a second entry-buffer allocation. Old-tree reference inspection in the guard and owning consumption here are distinct traversals, both paid.

| Additional batch work | Units |
|---|---:|
| Roster/permutation shape, index/length/ASCII admission: 32+4m+sum(key bytes) | 475 |
| Exact owner guards: 2×[32 fixed +4×(o+1) traversal +6×42 map/order comparisons] | 600 |
| Original-order temporary key-handle stores: 2m | 36 |
| Original-order key reads/clones/pushes/lengths: 2×4m | 144 |
| Three fallible vector reservation calls | 3 |
| Checked plan arithmetic and fixed bookkeeping | 32 |
| Final two-owner publication | 8 |
| **Additional batch work** | **1,298** |

The roster has 371 key bytes; its explicit ASCII scan is included, rather than hidden in four fixed units per row. If implementation instead relies on an entirely static audited ASCII invariant, it must remove the actual scan and describe that narrower guard before revising this row. Exact owner comparisons are length-bounded and allocation-free; don't accidentally use `PropertyKey::from(&str)` there. Each owner has six map/order key comparisons, conservatively including the symbol identity under the full comparison bound. The guard rejects insufficient order capacity rather than growing it.

Thus the proposed nonliteral total is `2×3030+1298 = 7,358`, against current `2×6050 = 12,100`: **4,742 predicted saved work**. The existing 18 `dom_proto_text` calls retain all **886 work** and **2,636 bytes**; they are not counted as savings. Predicted raw remainder is **11,022** only if concrete code exactly follows this ledger and no other work changes. This is neither a quota target nor an execution result: bind the actual source and measure before updating descriptive assertions.

## Typed allocation ledger and pinned library behavior

Let `K=size_of::<PropertyKey>()`, `V=size_of::<Property>()`, `E=size_of::<(PropertyKey,Property)>()`, `U=size_of::<usize>()`, and retain the current conservative node bound `B=16×(K+V)+32×U+64`. Use actual compiled types and checked products, not historical numeric headers.

New requested blocks are `18K` for the shared key vector, `2×21E` for the entry vectors, `2×48E` for possible stable-sort scratch, and `2×3B` for output trees: **18K+138E+6B**. Preserve the old per-property allowance `2×sum(256+4L)=12,184` and all initial object/order/old-map/string charges. Old tree storage is never refunded. The old repeated insertion path charged 30B per owner during counts 11 through 20; those unperformed insertion allocation allowances disappear. Therefore the proposed delta versus current constants is **18K+138E−54B**, not an old-node refund. Keep it symbolic until typed measurement.

A lower cumulative bootstrap allocation debit legitimately leaves more author heap available; author work still starts at the same fixed 100,000. Preserve before/after resource observations and fixed ordinary-success expectations rather than claiming all resource outcomes are invariant. Exact/one-short tests should measure the new performed algorithm, while unrelated limits and success cases stay unchanged.

Both pinned BTreeMap implementations collect to Vec, stable-sort, then bulk-build; `extend` still inserts individually. Both Vec specializations reuse a direct unadvanced owning iterator's allocation. Therefore `entries.into_iter().collect()` needs no second collected-vector block; an adapter/advanced iterator would require a fresh proof or extra charge. Sources: [1.88 map](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/map.rs), [1.98 map](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/map.rs), [1.88 Vec](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/vec/spec_from_iter.rs), [1.98 Vec](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/vec/spec_from_iter.rs).

N=21 exceeds the small insertion-sort threshold 20. Both pinned stable-sort entries provision scratch before detecting the full ascending run; the requested bound here is 48E. A 4 KiB stack substitute may avoid the actual heap request, but retain the full conservative charge for each collect, including sequential allocations. Ascending input uses 20 comparisons even in eager mode; dedup performs another 20. Sources: [1.88 sort](https://github.com/rust-lang/rust/blob/1.88.0/library/core/src/slice/sort/stable/mod.rs), [1.98 sort](https://github.com/rust-lang/rust/blob/1.98.0/library/core/src/slice/sort/stable/mod.rs), [1.88 drift](https://github.com/rust-lang/rust/blob/1.88.0/library/core/src/slice/sort/stable/drift.rs), [1.98 drift](https://github.com/rust-lang/rust/blob/1.98.0/library/core/src/slice/sort/stable/drift.rs), [1.88 dedup](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/dedup_sorted_iter.rs), [1.98 dedup](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/dedup_sorted_iter.rs).

For 21 unique entries bulk construction needs two leaves and one internal root. Retain the reviewed height-1 structural upper bound even where a particular final repair is empty. `B` exceeds the pinned 11-key/11-value plus header and 12-edge node layouts. Sources: [1.88 bulk](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/append.rs), [1.98 bulk](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/append.rs), [1.88 nodes](https://github.com/rust-lang/rust/blob/1.88.0/library/alloc/src/collections/btree/node.rs), [1.98 nodes](https://github.com/rust-lang/rust/blob/1.98.0/library/alloc/src/collections/btree/node.rs). The proof is pinned to these standard-library implementations/normal supported 64-bit targets; a different collection path or library version requires review.

## Meaningful tests and later acceptance

- Preserve and run the independent literal 18-constant JS fixture. Add one concise separate assertion for complete public string/symbol order on both owners, all descriptor flags/values, and ordinary enumeration; it must not derive expectations from `NODE_CONSTANTS` or the permutation.
- In private tests, install into two independently prepared authentic three-entry bags with saved accessor/constructor handles and unusual unrelated ScriptObject fields. Verify those handles/fields/order prefixes remain exact, constants occupy distinct mutable maps, and one realm's unrelated property mutation cannot affect the other. Existing immutable constants cannot be used as the sole isolation witness.
- Measure successful helper work and heap on fresh equal setups. Re-run with exactly that allowance, one fewer work unit, and one fewer heap byte. Exact succeeds; either quota refusal leaves both original maps/order capacities intact and records consumed counters. Do not mirror the fee formula in assertions. Also retain the whole `finish_bootstrap` exact/one-short boundary tests.
- Wrong/aliased IDs, extra/missing/wrong old keys, malformed order correspondence, long old keys, and insufficient reserved order capacity must reject before either map is taken. Validate whole old bag state, not only its length.
- Exercise duplicate/out-of-range/unsorted permutation entries through the small private assembly seam, including bad data in the second owner. Assert Resource before unchecked collect and no publication of completed replacement maps. Consumed partial initializer state may be discarded; do not demand rollback after terminal invariant failure. Label any allocator-injection witness synthetic; no new framework is needed.
- Measure first successful raw bootstrap on Rust 1.88 and 1.98; preserve the title baseline and any initial failure. Expected inventory stays 679/321/25, numeric limits/reset sites unchanged. Update only measured descriptive counts. Existing Node accessor, constructor, native identity, bootstrap refusal and browser fixtures remain unchanged and must pass under root's later full validation.

No source change is authorized by this document. Review the concrete implementation/ledger together before starting that future increment.
