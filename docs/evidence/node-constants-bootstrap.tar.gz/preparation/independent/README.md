# Independent Node constant cases

These are unexecuted baseline-success expectations for the proposed internal
batching optimization. No parser, compiler, JavaScript engine or browser ran
during authorship. Run one `nodeConstantCases` body in each fresh Runtime and
Document, separately in sloppy and strict modes. Seven bodies give fourteen
ordinary modes; each must complete normally with literal `true`. Preserve any
failure or resource refusal without changing the expected values to match it.

The eighteen constant names, values and declaration order are literal inputs,
checked against the [DOM Node interface](https://dom.spec.whatwg.org/#interface-node).
The immutable, enumerable data descriptors on both owners follow
[Web IDL constants](https://webidl.spec.whatwg.org/#js-constants).
The current primary [Web IDL source](https://github.com/whatwg/webidl/blob/main/index.bs)
was read when the rendered constants page could not be retrieved. The constructor
and prototype creation rules preserve existing properties and place prototype
`constructor` after constants. No expected value is read from an engine result,
generated from `NODE_CONSTANTS`, or obtained by sorting actual reflected keys.

## Cases and deliberate scope

1. `constructor_constant_descriptors`: eighteen own numeric values, flags,
   absence of accessor fields and ordinary reads on Node.
2. `prototype_constant_descriptors`: the same independent literals on
   Node.prototype. The two owners are checked in separate bodies to keep work
   bounded.
3. `constructor_complete_key_order`: complete current string/symbol reflection
   and enumerable string keys. Prefix is length, name, prototype; constants keep
   their declaration order.
4. `prototype_complete_key_order`: complete **currently represented** inventory:
   nodeValue, textContent, eighteen constants, constructor, then Symbol.toStringTag
   for Reflect.ownKeys. Object.keys excludes constructor and the symbol. This is
   an implementation-preservation contract, not an assertion that other standard
   Node attributes/operations should be absent in a complete browser. Future
   intentional API additions require a separately reviewed inventory change.
5. `saved_nonconstant_metadata_and_accessors`: existing parent links and metadata
   flags, constructor back-reference, distinct saved getter/setter identities,
   and successful saved calls on a genuine Text with literal before/after data.
6. `separate_mutable_constructor_and_prototype_bags`: independent string and
   symbol additions, writes and deletions with different object identities on
   the two owners. Immutable constants alone would not prove mutable isolation.
   Finally removes only this case's fresh configurable properties.
7. `realm_markers_are_initially_absent`: pristine own slots used by the host
   protocol below. It is also an ordinary fresh-realm success case.

The only error helper throws on failed assertions. These cases do not turn a
missing prerequisite or incidental TypeError into a successful feature verdict.
They use existing Object/Reflect descriptors and keys, Symbol, EventTarget,
Node, Text, saved accessor `.call`, and configurable ordinary property operations.
They do not require propertyHelper, Document own-key enumeration, iframe realm
access, host setPrototypeOf, `new Node()`, or `$262.createRealm`.

## Two live realms through existing public host APIs

No supported JavaScript API in this runtime creates a second independent realm.
`new Document()` is not a substitute. `nodeConstantRealmSteps` is therefore a
separate host-driven protocol, **not four standalone fresh-realm cases**.

For each language mode, create Runtime A and Runtime B through public
`Runtime::try_new`, with separate `Document::parse("")` values. Keep both alive
through the entire sequence. Evaluate the complete held cases.js exactly once
in each Runtime; prepend `'use strict';` for the strict pair so the defined
functions inherit strict mode. Require successful definition evaluation. Then
use public execute/execute_strict with these literal expressions, requiring
`Value::Bool(true)` at every step:

1. A: `nodeConstantRealmSteps.seed_a()` — own values 41 on Node and 42 on its prototype.
2. B: `nodeConstantCases.realm_markers_are_initially_absent()` — A's live mutations are absent.
3. B: `nodeConstantRealmSteps.seed_b()` — own values 71 and 72 in B.
4. A: `nodeConstantRealmSteps.verify_a()` — A still has 41 and 42 after B's writes.
5. B: `nodeConstantRealmSteps.verify_b()` — B still has 71 and 72.

No JS object is imported into another Runtime's heap. This detects shared
mutable metadata storage; it does not test cross-realm equality, wrappers,
navigation, or cross-document ownership. The seeded properties intentionally
remain until both test-owned Runtimes are discarded. Merely running the fresh
case twice after dropping the first realm is weaker and does not implement this
protocol. No host runner has been authored or executed in this preparation.

## Internal boundaries remain separate

These public cases cannot witness allocation cutpoints, owner-shape guards,
partial private-initializer discard, exact bootstrap charges or physical OOM.
Those remain private tests in the batching proposal. There is no new browser
fixture or performance claim. Reflection groups have finite literal arrays;
ordinary quota feasibility is unmeasured. Source hashes and case/protocol names
are frozen in source-ready.json. Peer review, if received later, is a separate
receipt and does not rewrite this source.
