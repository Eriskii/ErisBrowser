# Concrete first candidate ledger (unexecuted)

The held implementation follows `bootstrap-optimization-preparation-1/runtime/proposal.md` and the independently reviewed `runtime/ledger.json`. No compiler, engine or benchmark has run on this candidate. Its receipt binds four changed/new paths; existing descriptive bootstrap assertions remain untouched.

`node_constants_with_order` reaches these paid work stages on success:

| Stage | Work |
|---|---:|
| Roster length, bounded indices/length sum, ASCII scan | 32 + 72 + 371 = 475 |
| Both exact owner map/order/capacity guards | 600 |
| Checked typed allocation planning | 32 |
| Two sorted-map builds | 2 × 3,030 = 6,060 |
| Key staging, both order additions, final publication | 36 + 144 + 8 = 188 |
| Three fallible vector reservation entries | 3 |
| Original 18 literal constructors, unchanged | 886 |
| **Total** | **8,244** |

The original general property path uses 12,100 insertion work plus the same 886 literal work: 12,986. Predicted saving is 4,742, leaving a raw bootstrap remainder of 11,022 from title's measured 6,280. These are source arithmetic, not test or timing results. Tests measure each implementation using the actual general insertion helper, then derive exact/one-short admission budgets from the successful batch; they do not mirror this formula.

Each map uses 60 actual PropertyKey comparisons charged at 42 full UTF-16 work units, plus the established 510 structural units. The shape guard makes the 21-entry, at-most-41-unit sorted-input assumptions explicit. The ASCII pass visits all 371 literal bytes. Borrowed key guards do not allocate strings or perform tree lookup. The same private permutation seam permits malformed bounded inputs in tests; only the reviewed static permutation is used by bootstrap.

Let K/V/E/U be actual PropertyKey/Property/pair/usize sizes and B=16(K+V)+32U+64. Charges are the unchanged 2,636 literal bytes and 12,184 property payload bytes, plus 18K shared key handles, 42E final entries, 96E sort scratch and 6B fresh tree nodes. The batch total is **14,820 + 18K + 138E + 6B**. The former path charged **14,820 + 60B** during these insertions. Already charged object/order/old-leaf blocks remain cumulative. This is elimination of unperformed insertion allocations, not a refund after taking old maps.

Rust 1.88/1.98 sorted-collect and node-layout references are retained in the reviewed preparation. The concrete code uses direct unadvanced `entries.into_iter().collect()`, with no adapter, no `extend` into a tree and no `BTreeMap::append`. Full possible 48-entry scratch is paid for each build, even if stack substitution avoids one physical allocation.

All work, heap checks and all three fallible reservations finish before either `mem::take`. Actual-key strict ordering is then checked before each collect. Both complete maps remain local until success; order keys are appended in original IDL order into preexisting capacity. A deliberate duplicate/unsorted test refuses after consuming the maps, preserves their order/non-map fields and discards that private test realm without execution or retry. No reusable-map rollback or physical-OOM recovery is claimed. Standard BTree/sort allocation behavior retains the inherited infallible allocator boundary.

The Node literal table, constant flags, existing descriptor/native handles, later constructor insertion, eager bag IDs, registries, numeric limits and reset sites are unchanged. No host speed claim follows from this ledger; the separately frozen public initialization/drop benchmark supplies that evidence later.
