import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def checked(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def totals(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(x[i]) for x in rows) for i in range(3)]
assert totals('full-default-188-1')==[1688,0,0]
assert totals('full-native-198-1')==[1811,0,0]
source=read('candidate-source-final.json');assert len(source['files'])==5
for row in source['files']:
 assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'held-source-final'/row['path'])
docs=read('documentation-ready.json');assert len(docs['files'])==9
for row in docs['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'documentation-draft'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(BASE/'candidate-source-final.json')
comparison=read('node-constants-comparison.json');assert not comparison['validation_failures']
s=comparison['summary']
for group,cases,controls in [('established',4162,420),('new',14,12)]:
 for kind,count in [('cases',cases),('controls',controls)]:
  row=s[group][kind];assert row['before_total']==row['after_total']==row['unchanged']==count
  assert row['gains']==row['losses']==row['other_changes']==0
ready=read('source-ready-final.json');assert ready['successful_focused_observations']==84 and ready['unique_successful_test_groups']==79
bench=read('benchmark/runs/run-1/result.json')
assert bench['complete'] and bench['error'] is None and not bench['postcheck_failures'] and len(bench['attempts'])==96
for attempt in bench['attempts']:assert attempt['exit']==0 and not attempt['timed_out'] and attempt['error'] is None and attempt['leader_reaped']
ci=read('document-title-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
summary=dict(
 kind='Batched Node constant initialization',base_commit=source['base'],
 scope='Replace repeated bootstrap insertion of eighteen Node constants on two ordinary owners with two guarded, admitted sorted builds. Preserve descriptors, physical creation order, native handles, IDs and separate mutable objects.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-1','clippy-native-198-1','clippy-presenter-188-1','full-default-188-1','full-native-198-1','release-adapter-188-1']},
 tests=dict(default=1688,native=1811,new_groups=16,passing_focused_executions=84,passing_focused_unique_groups=79,initial_failed_bootstrap=dict(passed=24,failed=1),final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False),
 accounting=ready['metrics'],
 compatibility=dict(path='node-constants-comparison.json',sha256=sha(BASE/'node-constants-comparison.json'),summary=s),
 timing=dict(path='benchmark/runs/run-1/result.json',sha256=sha(BASE/'benchmark/runs/run-1/result.json'),input_manifest_sha256=sha(BASE/'benchmark/timing-inputs.json'),valid_observations=96,discarded_valid_samples=0,summaries=bench['summaries'],interpretation='No demonstrated host-time speedup. Paired median ratios are about 0.22% and 0.13% higher, and both interquartile ranges span one. Retained for lower charged work and storage; no physical resident-memory, page, Vulkan or Chromium speed claim.'),
 retained_history=['Initial all-target compilation and all sixteen new groups passed. First bootstrap filter retained 24 passes and one stale remaining-work failure; only that descriptive literal was changed after actual measurement.','First baseline 1.88 benchmark wrapper used non-LTO linking and could not consume LLVM bitcode from the thin-LTO release library. The original plan, command and error remain retained; all four wrappers use the same corrected thin-LTO command before any timing.','Production source and independent fixture remained byte-identical after initial review. Final source passed formatting, strict Clippy, both full suites and release build without further correction.','Exactly one complete frozen timing run was performed: all 96 observations and pre/post byte bindings passed. No sample was excluded or retried.'],
 boundaries=['Numeric quotas and reset sites remain unchanged. Cumulative charged heap is lower, leaving more logical author headroom. Already spent old object/order/tree blocks are not refunded.','Fallible vector reservations and quota refusal precede map consumption. Postconsumption internal ordering failure discards the private initializer; reusable failed-map rollback is not promised.','Shared permutation and exact owner guards make second-only malformed ordering unreachable through the production caller. First-map failure is exercised; both-local publication ordering is also reviewed in source.','BTree and sort physical allocation failure remains an inherited infallible boundary; this is not comprehensive OOM recovery or production security.','No Web API or standards coverage is added. Established unsupported/failing outcomes remain. Full web compatibility and the requested Chromium threshold remain unachieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','target','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p.is_symlink() or name in {'eris-js','runtime-init','final-publication-review.json'}:continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/node-constants-bootstrap.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
p=ROOT/'docs/evidence/node-constants-bootstrap.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
