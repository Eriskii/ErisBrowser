# Node predicates: independent preparation

Preparation only, read against the held Normalize worktree. No implementation decision, baseline/candidate execution, compiler run, or measured quota claim is included. `cases.js` contains sixteen independently written ordinary-success bodies for fresh sloppy and strict realms. Its expected booleans, identities, exceptions and key lists are literal proposals. Missing prerequisites remain failures; no body is reclassified as expected Unsupported.

## Contract and primary references

`hasChildNodes()` reports whether ordinary children exist, including empty Text and Comment nodes. `contains(other)` includes the receiver itself and follows ordinary ancestry. `isSameNode(other)` compares node identity. Both nullable Node arguments are required: omission throws TypeError, explicit null/undefined returns false. Neither operation coerces an object into a node. [DOM Node](https://dom.spec.whatwg.org/#interface-node), [child predicate](https://dom.spec.whatwg.org/#dom-node-haschildnodes), [containment](https://dom.spec.whatwg.org/#dom-node-contains), [identity](https://dom.spec.whatwg.org/#dom-node-issamenode).

JavaScript evaluates arguments first. Native invocation validates its receiver, resolves required arity, then converts the nullable interface argument without author conversion hooks. Method lengths are 0, 1 and 1. The ordinary prototype properties are writable/enumerable/configurable. Functions have configurable, nonwritable, nonenumerable name/length and are not constructors. [Web IDL operations](https://webidl.spec.whatwg.org/#es-operations), [interface conversion](https://webidl.spec.whatwg.org/#es-interface), [nullable conversion](https://webidl.spec.whatwg.org/#es-nullable-type).

Regular attributes precede operations; represented operations retain IDL order, then constants and constructor. Template content remains a separate Fragment tree. [Prototype creation](https://webidl.spec.whatwg.org/#es-interface-prototype-object), [template contents](https://html.spec.whatwg.org/multipage/scripting.html#template-contents).

## Current source and narrow implementation seam

The source inventory in `inputs.json` pins the current Normalize hold. Searches found no Node predicates. The existing `contains` native is DOMTokenList.contains in `src/script/dom_bindings.rs`; its token conversion must not be reused for Node containment. ClassList lookup and legacy generic Node lookup are separate paths in `src/script.rs`.

The existing `DOM.Node.` route and cached metadata factory in `node_data.rs` are suitable ownership seams. Add qualified function identities for all three methods, then dispatch them under the existing paid invocation/stack-cleanup bridge. Retain current name-copy admission and all reached comparison costs; a new dispatch tree needs its own bounded comparison accounting. The result can be `Value::Bool` directly. These predicates need no DOM string builder, JS `childNodes` array, retained data copy or mutation hook.

After the receiver is authenticated, missing first argument must be distinguished from a present `Undefined`. Authenticate any non-null/non-undefined argument independently. Do not call string/number conversion or read `nodeType`, `parentNode`, `childNodes`, `prototype`, or `Symbol.toPrimitive` through the property system. Fake objects inheriting from Node.prototype do not gain a brand; an authentic Text with a different mutable prototype retains its brand. Saved functions continue to work after replacement/deletion, while ordinary property lookup must not resurrect deleted functions through a legacy fallback.

Normalize's receiver handling can guide validation of `Value::Document` and `Value::Node(id)`. Canonicalize the authentic Document singleton to `doc.root` before comparing internal node IDs. Check root kind and ID bounds; an arbitrary out-of-range `Value::Node` must not pass by comparing equal to itself. Public `document.documentElement.parentNode` already returns the canonical `Value::Document`, as `script.rs` explicitly maps that parent. The JS fixture tests this public alias, not an invented way to manufacture internal `Value::Node(doc.root)`. Reserve the latter equivalence for private Rust tests.

`hasChildNodes` can read the actual child vector's emptiness after authentic receiver admission. `isSameNode` can compare authenticated IDs. `contains` starts at the authenticated argument ID and walks parent links until it finds the receiver or reaches an ordinary root. A detached node contains itself. No template host/content jump, subtree scan, arena scan or payload decoding is needed. All argument expressions, including ignored extra expressions, have already completed; the traversal must see their resulting tree.

Do not directly reuse private `Document::is_descendant_of` at `dom.rs:1805`: it is unmetered and its `0..MAX_DEPTH` loop checks only MAX_DEPTH nodes, missing a root at exactly MAX_DEPTH edges. It is an existing form-state helper, not a predicate implementation. The new path needs paid reached checks, a bounded terminal refusal for malformed parent chains, and an inclusive accepted-depth witness. Keep any change to the unrelated form helper out of this increment.

A parent-only walk would be O(reached ancestor count). The coordinated Runtime proposal also validates unique reciprocal membership by scanning each followed parent's child IDs, without dereferencing unrelated siblings. That chosen path is O(reached ancestors + scanned sibling IDs), with constant scratch and no owned DOM allocations. Debit each reached ID/kind/parent check and the bounded sibling scan before performing it. Wide valid sibling vectors may exhaust ordinary work admission; no quota feasibility is claimed. Accept edge-depth MAX_DEPTH, requiring up to MAX_DEPTH+1 node checks; do not silently return false when a valid boundary root is reached. Invalid IDs, self-parent/cycles and links beyond the accepted structural bound need explicit internal rejection rather than unbounded traversal. Private host-malformed behavior is an implementation policy, not a newly invented DOM exception. Do not claim a constant upper bound on whole-call allocation: existing native invocation/name-copy and language machinery still have their own charged allocations. No work resets, heap refunds or larger limits are warranted.

## Metadata and constant batching

Current represented Node prototype strings are nodeValue, textContent, normalize, eighteen constants, constructor. The proposed strings are:

```
nodeValue, textContent,
hasChildNodes, normalize, isSameNode, contains,
ELEMENT_NODE, ATTRIBUTE_NODE, TEXT_NODE, CDATA_SECTION_NODE,
ENTITY_REFERENCE_NODE, ENTITY_NODE, PROCESSING_INSTRUCTION_NODE,
COMMENT_NODE, DOCUMENT_NODE, DOCUMENT_TYPE_NODE,
DOCUMENT_FRAGMENT_NODE, NOTATION_NODE,
DOCUMENT_POSITION_DISCONNECTED, DOCUMENT_POSITION_PRECEDING,
DOCUMENT_POSITION_FOLLOWING, DOCUMENT_POSITION_CONTAINS,
DOCUMENT_POSITION_CONTAINED_BY, DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC,
constructor
```

Symbol.toStringTag follows these 25 strings in Reflect.ownKeys: 26 total. Object.keys has the same first 24 strings without constructor. Node constructor inventory stays length/name/prototype plus the same eighteen constants: 21 total, eighteen enumerable. This is the represented inventory, not a claim that every Node member in the standard exists.

At the preconstant installation point the prototype has seven entries, while the constructor retains three. Physical prototype order is tag, nodeValue, textContent, hasChildNodes, normalize, isSameNode, contains. Sorted owner keys are contains, hasChildNodes, isSameNode, nodeValue, normalize, textContent, tag. Prototype values map has 25 entries after constants and needs order capacity26 for the later constructor; constructor map/order remains21. New methods add three cached mutable metadata bags; include them in the actual arena reservation. Existing function/descriptor handles and bag IDs must move intact.

The current sorted builder's N=21/22 proof explicitly covers one overflow and three new tree nodes. N=25 crosses that specialization: review pinned Rust 1.88/1.98 sorted construction and its additional overflow/allocation rather than retaining the three-node proof. Recompute every affected owner guard, sorted comparison pass, copied/moved entry, order growth and typed storage fee. A loose bound may be safe only if its actual work/allocation argument is documented; do not lower unrelated fees or raise quotas. Script owns the independent concrete ledger. No unmeasured bootstrap remainder or byte delta is promised here.

## Exact historical inventories

`historical-inventory.json` pins the original source files and lists exact affected cases/controls. No historical fixture, expected result or raw observation is edited here.

Compared with the held Normalize feature shape, predicates introduce two new ordinary inventory losses: represented_complete_key_order in sloppy and strict modes. Its 23-key literal becomes false and should produce its Error assertion. The represented-node-order positive/wrong controls in both modes also fail their old 23-key prerequisite with TypeError, so all four are unhealthy. The wrong controls do not become healthy merely because they threw. A future companion classifier must keep these six complete raw changed rows, require the specified exception distinctions, and reject any other established change.

The older Node constants suite already has two case losses (prototype_complete_key_order) and four unhealthy reflected-order controls from Normalize's addition. These remain historical losses; predicates do not turn them into successes. Across the two historical snapshots, four case modes and eight control modes use now-stale inventories, but only two case modes and four control modes are newly invalidated relative to Normalize. Actual complete-row comparisons are still required; a static prediction is not evidence of unchanged observations.

The private Rust wrapper around the original Node inventory currently deletes only normalize in a disposable realm. It will need an explicit, renamed adaptation deleting all four later operations while running the original 22-key source unchanged. The frozen Normalize inventory can similarly remain exact inside a separate, clearly labeled disposable compatibility setup that removes the three new methods. Restoring descriptors does not restore their original insertion order, so these disposable wrappers cannot double as pristine current-inventory tests. `represented_complete_key_order` in the new fixture independently fixes the 26-key current oracle, and its paired control sketch uses its own literal list.

## Independent validation plan and remaining gaps

The sixteen bodies cover metadata and current inventory; empty/Comment children; containment direction/moves; identity despite exact data and moves; missing vs nullable arguments; noncoercing interface/receiver brands; ignored arguments and their evaluation side effects; template content boundaries; Document identity and detachment; saved/overridden/deleted functions; poisoned JS getters; authentic alternate prototypes; and detached exact Text/Comment/PI payloads.

Each body first captures all three defining-interface functions and proves authentic leaf and one-child behavior before any negative TypeError check. Run the complete definition source plus one invocation in each fresh realm, with strict mode applied to the whole definition. Every ordinary body expects successful runtime completion. `controls.json` holds four independent positive/wrong source pairs, proposed for both modes: literal syntax, actual relations, required/nullable conversion, and the current reflected order. The wrong tail requires Error after a healthy same-mode positive; prerequisite TypeErrors, missing functions, parser errors, Unsupported or Resource never count as a successful negative control. These are frozen sources, not executed observations or a replay driver.

Future private tests should cover authentic root aliases and invalid IDs; accepted MAX_DEPTH edge containment built through an accepted reciprocal snapshot; reached-only work independent of unrelated arena size; exact/one-short work for each method; unchanged node count, links, retained payload bytes, native properties and Document side metadata on success/refusal; no retained heap allocation in the pure DOM traversal; and both fields synchronized if a DOM budget wrapper is chosen. Distinguish the unavoidable invocation bridge charge from the pure predicate helper. A two-live-Runtime test can verify metadata isolation without pretending two adapter processes share a realm.

DocumentType can receive the methods on an authentic parsed/host node; no ordinary body assumes a doctype exists in the adapter document. Attr, CDATA, XMLDocument, ShadowRoot, Proxy-to-Node semantics, cross-document adoption and cross-realm wrappers are separate unavailable prerequisites. No getters, complete Node inventory, isEqualNode, compareDocumentPosition, event dispatch, custom-element reactions, mutation observers or Range support is added by these three queries. Existing classList.contains semantics stay separate. The operations themselves mutate nothing and perform no author callbacks, but caller argument evaluation may already have mutated the DOM or thrown; those earlier effects are not rolled back on a later brand or Resource refusal.
