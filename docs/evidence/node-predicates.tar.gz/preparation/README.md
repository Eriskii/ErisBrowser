# Held independent Node predicate preparation

This directory contains a source-only proposal for hasChildNodes, isSameNode and contains. No engine, JavaScript parser, compiler, baseline or candidate ran. Ordinary success is required for every case; feasibility remains unmeasured.

- `proposal.md`: primary references, current-source seams, bounded query behavior, installer shape and exact historical inventory consequences.
- `cases.js` / `cases.json`: sixteen fresh-realm bodies, proposed in sloppy and strict modes (32 ordinary modes). The strict directive belongs before the entire definition source, not only the invocation.
- `controls.json`: four independent positive/wrong pairs in both modes (16 proposed controls). Negative health requires a healthy same-mode positive and the exact Error tail; TypeError prerequisites are distinct.
- `historical-inventory.json`: two additional Normalize inventory case modes and four control modes predicted to fail, alongside older already-unhealthy Node inventory rows. Original oracles remain untouched.
- `inputs.json` / `deferred.json`: exact source bindings and explicit non-fixture future witnesses.
- `static-validation.json`: data-only count/hash/pairing and source-escape checks, including the retained reader correction.
- `cases-initial.js` / `boolean-assertion-correction.*`: original unexecuted draft and stricter literal-boolean assertion delta.
- `runtime-peer-review*.json`: bounded review of the separately owned Runtime proposal, with earlier draft receipt retained.

The independent expected Node prototype inventory has 25 strings and its tag symbol (26 total), with represented operation order hasChildNodes, normalize, isSameNode, contains. The constructor remains at 21 keys. No complete DOM Node binding claim is made.

`runtime/` is owned by the Runtime planning agent. Any later peer receipt is additive and does not rewrite these fixture oracles. No replay driver or execution authorization is supplied by this hold.
