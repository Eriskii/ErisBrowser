# Node predicate release replay preparation

The permanent original driver location is `/tmp/eris-node-predicates-preparation-1/replay/replay.py`. Keep the entire preparation at this absolute location. Root owns selecting and running the published Normalize baseline and any later candidate; neither has run here.

The matrix has sixteen held independent sources in sloppy and strict modes: **32 ordinary rows plus 16 control rows, 48 total**. Each ordinary source is the complete immutable definition fixture plus one case invocation, passed in the selected adapter mode. The source definitions therefore receive strict semantics when the adapter selects strict mode. All ordinary rows require successful runtime completion. No missing prerequisite, Unsupported, Resource or parser error is accepted as ordinary success.

`independent/cases.js` remains exact SHA `119b41f4a50a0a3de691c172ffe053d80f88ec6a7339764603e19b9dd02bf909`. Every control source and expected observation is copied exactly from the previously held `controls.json`, not regenerated from candidate observations. Four positive/wrong pairs cover:

- UTF-16 literal syntax and literal booleans, without any new-method dependency.
- Actual leaf identity and inclusive containment, one-child containment, detachment and retained data.
- Required arguments versus explicit null/undefined, with working authentic calls before negative TypeError checks.
- The new literal 26-key Node prototype order and unchanged 21-key constructor order.

Each wrong source consists of its positive partner's entire exact source followed only by an intentional Error. Explicit prerequisites throw TypeError. The inherited verifier requires the expected observation and a healthy same-mode positive before marking a negative control verified. A missing-method TypeError cannot become a healthy wrong-tail observation. The runner's coarse `failed` status for a deliberate Error is retained even when the negative observation matches.

`replay.py.diff` changes only feature wording, the fixed fixture digest, the collection identifier and the case filename from the held Normalize driver. Counts happen to remain identical. All process supervision, response checks, complete-row recording, binding checks, exit statuses and control-health logic are unchanged. The three helper files are byte-exact copies. They retain ERJS1 requests/ERJR2 responses, a four-MiB request cap, a three-second per-child timeout, 96-KiB stdout and 64-KiB stderr limits, sequential execution and inherited direct-child cleanup. This is not a descendant-process supervisor.

The driver checks 31 input files against the frozen matrix before any run. These inputs, the matrix and the chosen binary are hashed again after all observations. The 28 copied history/input/helper files retain original absolute origin paths and exact copy mappings. A fresh output path is claimed exclusively before the first adapter launch. Returned rows, absent observations, caught runner exceptions and post-run binding errors all remain in the report. Optimized Python invocation is rejected. External termination or output-filesystem failure may still prevent final report serialization; this inherited boundary is not disguised as complete crash recovery.

The copied historical fixtures and original replay inputs are provenance, not rows in this new matrix. Relative to the held Normalize shape, predicates newly invalidate exactly two `represented_complete_key_order` modes and four `represented-node-order` positive/wrong control modes. The older Node `prototype_complete_key_order` two modes and four `reflected-order` control modes were already unhealthy after Normalize. Preserve both histories and all original expectations; do not describe all twelve stale-inventory modes as new losses relative to Normalize. A later established-row comparison must retain the new Error case observations and TypeError prerequisite control observations, preserve already-unhealthy old rows, and reject unanticipated changes. Neither unhealthy negative control is waived merely because it threw. The new matrix has an independent pristine 26-key oracle and positive/wrong order pair.

The copied deferred inventory contains private malformed-graph/depth/alias and two-live-Runtime witnesses, and unrepresented-interface prerequisites. None is silently converted into a public JS success row. Separate adapter processes do not establish shared-lifetime realm isolation.

`prepare-static.py` performed only exclusive byte copies, JSON construction, Python AST parsing and static hash/count/pairing/fingerprint checks. It never imports the driver/helpers or parses/executes JavaScript. `static-validation.json` records that scope. The one later inert `--verify` completed with exit0 and empty stderr, retaining all31 input bindings and the matrix unchanged; its full receipt and outputs are retained. No driver `--prepare`, engine, baseline, candidate, browser or compiler has run in this preparation. A source-only peer review and root review precede any baseline execution.

The inherited inert check launches no adapter and remains available to root:

```sh
python3 /tmp/eris-node-predicates-preparation-1/replay/replay.py --verify
```

After explicit binary selection, each authorized observation attempt requires a new report path:

```sh
python3 /tmp/eris-node-predicates-preparation-1/replay/replay.py \
  /absolute/path/to/published-eris-js FULL_SHA256 /absolute/path/to/fresh-report.json
```

The binary must match the supplied SHA before the report path is claimed or any adapter launches. Exit0 requires all ordinary cases and paired controls to meet their fixed expectations. Exit1 retains unmet outcomes; exit2 reports binding failures; exit3 reports a caught runner exception. Baseline outcome counts remain unknown until root runs the fixed sources.
