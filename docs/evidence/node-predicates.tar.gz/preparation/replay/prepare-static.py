#!/usr/bin/env python3
"""Exclusive data-only predicate replay preparation; no imports of runner/driver."""
import ast
import difflib
import hashlib
import json
import re
from pathlib import Path

HERE = Path(__file__).resolve().parent
PREP = HERE.parent
PRIOR = Path('/tmp/eris-node-normalize-preparation-1/replay')
FIXTURE_SHA = '119b41f4a50a0a3de691c172ffe053d80f88ec6a7339764603e19b9dd02bf909'


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def binding(path):
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=digest(raw))


held = json.loads((PREP / 'source-ready.json').read_text())
sources = [(PREP / row['path'], 'independent/' + row['path']) for row in held['files']]
for row in held['files']:
    assert binding(PREP / row['path']) == dict(path=str(PREP / row['path']), bytes=row['bytes'], sha256=row['sha256'])
sources += [
    (PREP / 'source-ready.json', 'independent/source-ready.json'),
    (PREP / 'layout/fixture-source-review.json', 'history/layout-fixture-source-review.json'),
    *[(PRIOR / name, 'history/normalize-' + name) for name in (
        'replay.py', 'source-ready.json', 'README.md', 'preparation-history.json',
        'replay-inputs.json', 'replay-matrix.json')],
    (PRIOR / 'independent/cases.js', 'history/historical-normalize.js'),
    (PRIOR / 'history/historical-node-constants.js', 'history/historical-node-constants.js'),
    (PRIOR / 'history/historical-node-replay-inputs.json', 'history/historical-node-replay-inputs.json'),
    *[(PRIOR / 'tools' / name, 'tools/' + name) for name in (
        'test262_conformance.py', 'html_conformance.py', 'import_test262.py')],
]
history = []
for origin, relative in sources:
    raw = origin.read_bytes()
    copy = HERE / relative
    copy.parent.mkdir(parents=True, exist_ok=True)
    with copy.open('xb') as stream:
        stream.write(raw)
    history.append(dict(origin=str(origin), copy=relative, bytes=len(raw), sha256=digest(raw)))
save(HERE / 'preparation-history.json', history)

fixture = (HERE / 'independent/cases.js').read_bytes()
assert digest(fixture) == FIXTURE_SHA
case_data = json.loads((HERE / 'independent/cases.json').read_text())
assert case_data['case_modes'] == 32 and case_data['collection'] == 'nodePredicateCases'
assert re.findall(r'^  ([a-z_]+): function\(\)\{', fixture.decode(), re.M) == [row['name'] for row in case_data['cases']]
controls = json.loads((HERE / 'independent/controls.json').read_text())['controls']
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
assert len(case_data['cases']) == 16 and len(controls) == 8
for row in controls:
    assert digest(row['source'].encode()) == row['source_sha256']
    positive = next(x for x in controls if x['pair'] == row['pair'] and x['positive'])
    assert row['source'] == positive['source'] + ('' if row['positive'] else "throw new Error('deliberately wrong expectation');")
    assert row['modes'] == ['sloppy', 'strict']
    assert row['expected_observation'] == (complete if row['positive'] else wrong)
    assert all('TypeError' in throw for throw in re.findall(r'throw new ([^;]+)', positive['source']))
inventory = dict(
    fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA, collection='nodePredicateCases',
    cases=[dict(name=row['name'], modes=['sloppy', 'strict'], expected_observation=row['expected_observation']) for row in case_data['cases']],
    controls=controls, case_modes=32, control_modes=16,
    baseline_binary='Pending explicit root selection of published Normalize release; no baseline is run or silently selected by this preparation.',
    deferred='independent/deferred.json; private host malformed/depth/alias cases and unrepresented interfaces are not JS matrix rows.',
    historical_inventory=dict(
        policy='independent/historical-inventory.json',
        new_relative_to_normalize=dict(case_modes=2, control_modes=4),
        already_unhealthy_older_node=dict(case_modes=2, control_modes=4),
        run_in_this_matrix=False,
        purpose='Retain exact old sources and oracles. Later established comparison must expose both histories, with no negative-control health waiver.'))
save(HERE / 'replay-inputs.json', inventory)

old = (PRIOR / 'replay.py').read_text()
new = old
for before, after in [
    ('Frozen Node normalize observations', 'Frozen Node predicate observations'),
    ('337b5acb013b8e1aea04e933913c50746c0372185117edd32f84b48c648d3f20', FIXTURE_SHA),
    ('nodeNormalizeCases', 'nodePredicateCases'),
    ("file='node-normalize.js'", "file='node-predicates.js'"),
]:
    assert before in new
    new = new.replace(before, after)
ast.parse(new)
with (HERE / 'replay.py').open('x') as stream:
    stream.write(new)
with (HERE / 'replay.py.diff').open('x') as stream:
    stream.write(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='held-normalize/replay.py', tofile='predicates/replay.py')))
# Reconstruct all fingerprints without importing the driver or any copied helper.
rows = []
for kind, inputs in [('case', inventory['cases']), ('control', controls)]:
    for row in inputs:
        assert row['expected_observation'] == (complete if kind == 'case' or row['positive'] else wrong)
        body = (fixture + b'\nif(nodePredicateCases.' + row['name'].encode() + b'() !== true) throw new Error("case did not return true");' if kind == 'case' else row['source'].encode())
        assert len(body) + 15 <= 4 * 1024 * 1024
        for mode in row['modes']:
            identity = dict(source_sha256=digest(body), mode=mode, metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None), harness=[])
            fingerprint = digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())
            item = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind, source_sha256=digest(body), case_sha256=fingerprint, expected_observation=row['expected_observation'])
            if kind == 'control':
                item.update(pair=row['pair'], positive=row['positive'], area=row['area'], partner=row['pair'] + '-positive#' + mode)
            rows.append(item)
assert len(rows) == len({row['id'] for row in rows}) == 48
paths = [HERE / name for name in ('replay.py', 'replay-inputs.json', 'preparation-history.json')]
paths += [HERE / row['copy'] for row in history]
frozen = dict(fixture_sha256=FIXTURE_SHA, inventory_sha256=binding(HERE / 'replay-inputs.json')['sha256'], replay_sha256=binding(HERE / 'replay.py')['sha256'], runner_sha256=binding(HERE / 'tools/test262_conformance.py')['sha256'], bounds=dict(timeout_seconds=3, stdout_limit=96*1024, stderr_limit=64*1024, execution='sequential inherited run_case'), bound_inputs=[binding(path) for path in paths], rows=rows)
save(HERE / 'replay-matrix.json', frozen)
for row in frozen['bound_inputs']:
    assert binding(Path(row['path'])) == row
save(HERE / 'static-validation.json', dict(status='passed data-only construction/hash/roster/pairing checks', rows=48, case_modes=32, control_modes=16, bound_files=len(paths), history_copies=len(history), driver='AST parsed only; identity substitutions only; supervisor/reporting identical to held Normalize driver', fingerprints='all48 independently constructed from inherited source/mode/metadata/harness formula', fixture='original16-case bytes and all8 control source strings/expectations unchanged', history='New Normalize2case+4control losses and already-unhealthy older Node2case+4control history remain separate, neither run in this matrix', executions=dict(engine=0,compiler=0,js_parser=0,driver=0,helper_import=0)))
print(json.dumps(dict(driver=binding(HERE / 'replay.py'), matrix=binding(HERE / 'replay-matrix.json'), bound_files=len(paths), history_copies=len(history)), indent=2))
