# Node.normalize release replay preparation

Keep this preparation at its original absolute path, `/tmp/eris-node-normalize-preparation-1/replay`. It contains the exact sixteen previously held case bodies, each invoked independently in sloppy and strict mode with an ordinary-success expectation. The matrix has **32 case rows and 16 control rows, 48 total**. Neither expected results nor case bodies have changed.

Four independently authored positive/wrong pairs cover:

- Literal UTF-16 source units, including an isolated surrogate.
- The inherited normalize function's method/name/length descriptors and an actual saved call on an authentic Text leaf.
- A successful fragment append followed by exact surrogate-pair merging, survivor identity, empty removal, and unchanged detached tail units.
- The new represented Node prototype inventory and the unchanged Node constructor inventory.

Every wrong source is its positive partner's exact source followed only by the intentional intrinsic `Error` tail. Explicit prerequisite checks throw `TypeError`. The inherited verifier requires the same-mode positive partner to match before a negative row is verified. Missing normalize can therefore leave feature controls unhealthy; that is retained as a feature prerequisite outcome and never converted into adapter success. The common syntax pair can pass independently of normalize.

`replay.py.diff` changes only names, source identity, and population counts from the held Text driver. The helpers and all supervision/report logic are byte-exact. ERJS1 requests, ERJR2 responses, the four-MiB request ceiling, three-second per-process timeout, 96-KiB stdout and 64-KiB stderr limits, sequential execution, and inherited direct-child cleanup remain unchanged. This is not a general descendant-process supervisor. Ordinary helper classification is separate from control observation matching: the intentional Error can be classified `failed` by the helper while satisfying the negative control expectation.

Sixteen input files are checked against the frozen matrix before a run. Those sources and helper/provenance copies, the matrix, and the selected binary are hashed again afterward. The report retains every returned row, missing observations, caught runner exceptions, and post-run binding failures. It claims the report path exclusively before launching any adapter. Python optimization is refused. External termination or an output-filesystem failure can still prevent final report serialization; this preparation does not change that inherited limit.

The old `historical-node-constants.js` is retained byte-exact at SHA `e3253ef6cdc80310be70fa6975e5bbe41ba9482177ac568e6bc5dc2156685d1a`. Its `prototype_complete_key_order` strict/sloppy modes stay available for a separate historical comparison. They are not rewritten, appended to this new matrix, or relabeled as the new expectation. The new ordinary `represented_complete_key_order` case and its control use an independently frozen expectation: nodeValue, textContent, normalize, eighteen constants, constructor, then the symbol in Reflect.ownKeys. Constructor inventory stays unchanged. The complete old Node replay inventory is also retained unchanged. Its reflected-order positive/wrong controls in both modes require the former 22-key prototype. The historical comparison must therefore retain two changed case modes and four changed control modes, including both unhealthy negative controls when their positive partner fails. No historical control expectation is weakened. The original earlier replay location and expectations are untouched; historical-inventory-addendum.md records this correction to the initial proposal.

The two CDATA/live Range sketches remain excluded from this matrix. The copied original preparation inventory's statement that external controls had not yet been authored describes that earlier freeze; controls here are additive. The prior Text readiness receipt is provenance, not a selection of its older baseline binary for this run.

`prepare-static.py` only copied bytes, constructed JSON/fingerprints, parsed Python AST, and performed literal/roster/hash checks. The first explicitly authorized inert `--verify` passed with fourteen inputs plus the matrix unchanged. After adding historical control provenance, the second inert `--verify` passed with all sixteen inputs plus the revised matrix unchanged. Both complete outputs and receipts are retained. `update-historical-bindings.py` preserved the initial history/input/matrix/verification draft, then added provenance only; all 48 source/expectation rows and the driver remained exact. No JavaScript parser, engine, baseline, candidate, browser or compiler execution occurred in this preparation.

Root owns baseline selection and execution after publishing the Text checkpoint; the announced release digest begins `6dfda069`. The full binary path and SHA must be supplied explicitly, so no matrix or source change is required when the release is selected:

```sh
python3 /tmp/eris-node-normalize-preparation-1/replay/replay.py \
  /absolute/path/to/published-eris-js FULL_SHA256 /absolute/path/to/fresh-report.json
```

Use a new report path for each authorized baseline/candidate attempt. Exit 0 requires all ordinary cases and paired controls to satisfy their fixed expectations. Exit 1 retains ordinary/control mismatches, exit 2 reports changed bindings, and exit 3 reports a caught runner exception. A missing-feature baseline is expected to retain unmet rows; no result is known until root runs it.
