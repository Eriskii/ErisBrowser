#!/usr/bin/env python3
"""Read JSON, logs and bytes only; never import a reviewed helper or run an engine."""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent
SOURCE = 'a4ae87eeeacd46964f1f8b193f45412bf2e11a9bcca1f10358aae741336cf9ef'
BASE_BINARY = 'e46518df6539cae705c36dc0856143e9849808046a6ec7fc6e4d274039a35bdb'
CANDIDATE = '1d0a4eaa3a900f759b574de1454c91ae5be7570e0a7c3be51a9db169162dc07f'
INPUTS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def raw(path):
    path = B / path
    data = path.read_bytes()
    binding = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    require(str(path) not in INPUTS or INPUTS[str(path)] == binding, 'input changed: ' + str(path))
    INPUTS[str(path)] = binding
    return data


def read(path):
    return json.loads(raw(path))


def bound(row, prefix=B):
    data = raw(prefix / row['path'])
    require(hashlib.sha256(data).hexdigest() == row['sha256'], 'hash: ' + row['path'])
    if 'bytes' in row:
        require(len(data) == row['bytes'], 'length: ' + row['path'])
    return data


def command(path, exit_code):
    record = read(path)
    require(record['exit'] == exit_code, 'command exit: ' + path)
    log = Path(path).parent / record['log']
    data = raw(log)
    require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)
    return record, data.decode()


def tests(path, exit_code, totals):
    record, log = command('validation/' + path + '.json', exit_code)
    rows = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    observed = [sum(int(row[i]) for row in rows) for i in range(3)]
    require(observed == totals, 'test summary: ' + path)
    names = re.findall(r'^test (.+) \.\.\. (ok|FAILED|ignored)$', log, re.M)
    require([sum(status == s for _, status in names) for s in ['ok', 'FAILED', 'ignored']] == totals,
            'literal test rows: ' + path)
    return record, names, log


def validation():
    source = read('candidate-source-final-2.json')
    require(INPUTS[str(B / 'candidate-source-final-2.json')]['sha256'] == SOURCE, 'final source identity')
    require(len(source['files']) == 16, 'final source population')
    for row in source['files']:
        bound(row, B / 'worktree')
        bound(row, B / 'held-source-final')
    before = read('lint-source-correction/candidate-source-final.json')
    old = {r['path']: r for r in before['files']}
    current = {r['path']: r for r in source['files']}
    require(old.keys() == current.keys(), 'source path drift')
    require([p for p in old if old[p] != current[p]] == ['src/script/node_predicates/tests.rs'], 'lint scope')
    original = raw('lint-source-correction/tests.rs.before')
    require(hashlib.sha256(original).hexdigest() == old['src/script/node_predicates/tests.rs']['sha256'], 'retained test')
    for name in ['arg', 'bad', 'other']:
        needle = ('&[' + name + '.clone()]').encode()
        require(original.count(needle) == 1, 'slice site count')
        original = original.replace(needle, ('std::slice::from_ref(&' + name + ')').encode())
    require(original == raw('worktree/src/script/node_predicates/tests.rs'), 'exact lint replacement')
    correction = read('measured-source-correction/receipt.json')
    for row in correction['files']:
        data = raw('measured-source-correction/before/' + row['path'])
        require(hashlib.sha256(data).hexdigest() == row['before_sha256'], 'measured original')
        for old_text, new_text in row['replacements']:
            require(data.count(old_text.encode()) == 1, 'measured replacement count')
            data = data.replace(old_text.encode(), new_text.encode())
        require(data == raw('worktree/' + row['path']), 'exact measured replacement')
    focus = Counter()
    for label, count in [('predicates-188-1', 30), ('bootstrap-188-2', 28), ('constants-188-1', 17),
                         ('node-data-188-1', 34), ('normalize-188-1', 40)]:
        _, rows, _ = tests(label, 0, [count, 0, 0])
        focus.update(n for n, _ in rows)
    require(sum(focus.values()) == 149 and len(focus) == 145, 'focused recount')
    _, failed, log = tests('bootstrap-188-1', 101, [26, 2, 0])
    require({n for n, s in failed if s == 'FAILED'} == {
        'script::bootstrap_tests::bootstrap_convenience_and_try_paths_separate_work_and_retain_heap',
        'script::dom_bindings::identity_tests::dom_parent_bootstrap_reports_actual_remaining_budget_and_capacities'}, 'bootstrap failures')
    require('NODE_PREDICATES_BOOTSTRAP steps=8807 allocated=1755715 objects=685 capacity=685 native=321 prototypes=25' in log,
            'measured diagnostic')
    for label in ['compile-188-1', 'clippy-native-198-2', 'clippy-presenter-188-1', 'format-198-1', 'format-198-2', 'release-adapter-188-1']:
        record, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(record['command'][-2:] == ['-D', 'warnings'], 'strict Clippy')
    _, lint = command('validation/clippy-native-198-1.json', 101)
    require(lint.count('error: unnecessary use of `clone` to create a slice from a reference') == 3, 'retained lint errors')
    default, _, _ = tests('full-default-188-1', 0, [1805, 0, 0])
    first, failed, log = tests('full-native-198-1', 101, [1616, 1, 0])
    retry, _, _ = tests('full-native-198-2', 0, [1928, 0, 0])
    isolated, rows, _ = tests('host-silent-198-1', 0, [1, 0, 0])
    test = 'date_host::tests::host_run_capture_silent_blocked_helper_obeys_cancel_and_deadline'
    require([n for n, s in failed if s == 'FAILED'] == [test] and rows == [(test, 'ok')], 'native failure and isolated identity')
    require('helper must reach the silent blocking read' in log and 'src/date_host/tests.rs:663:9' in log, 'marker assertion')
    require(retry['command'] == first['command'] + ['--test-threads=4'], 'only native retry command delta')
    require('--include-ignored' in default['command'] and '--include-ignored' in retry['command'], 'ignored tests included')
    require('--exact' in isolated['command'] and test in isolated['command'], 'isolated exact test')
    raw('native-deadline-investigation.json')
    raw('native-deadline-layout-review.json')
    return dict(default=1805, native=1928, new_groups=30, focused_observations=149,
                focused_unique=145, earlier_bootstrap_passes=26, retained_bootstrap_failures=2,
                retained_clippy_diagnostics=3, first_native_passes=1616, first_native_failures=1,
                isolated_exact_passes=1, native_retry_threads=4,
                native_failure='Startup marker absent when capture returned under unchanged deadline; action/result variant unrecorded. Scheduling sensitivity is an inference.')


OUTCOMES = {'status', 'observation', 'reason', 'stderr', 'matches_expectation', 'matches_implementation_policy',
            'verified', 'verified_with_protocol_prerequisite', 'positive_partner_matches'}


def key(row):
    row = row.get('result', row)
    return row['id'], row.get('mode', '')


def inputs(row):
    if 'result' in row:
        return {**{k: v for k, v in row.items() if k not in {'result', 'verified'}}, 'result': inputs(row['result'])}
    return {k: v for k, v in row.items() if k not in OUTCOMES}


def healthy(row):
    if 'result' in row:
        return row.get('verified') is True and row['result'].get('status') == row['expected']
    if 'expected_observation' not in row:
        return row.get('status') == 'passed'
    observation = row.get('observation', {})
    return (isinstance(observation, dict) and all(observation.get(k) == v for k, v in row['expected_observation'].items())
            and row.get('matches_expectation') is True and row.get('verified', True) is True
            and row.get('verified_with_protocol_prerequisite', True) is True)


def complete_rows(before, after):
    old, new = {key(r): r for r in before}, {key(r): r for r in after}
    require(len(old) == len(before) and len(new) == len(after) and old.keys() == new.keys(), 'row identity/population')
    result = dict(before_total=len(before), after_total=len(after), before_healthy=sum(map(healthy, before)),
                  after_healthy=sum(map(healthy, after)), unchanged=0, gains=0, losses=0, other_changes=0)
    changes = []
    for identity, a in old.items():
        b = new[identity]
        require(inputs(a) == inputs(b), 'row inputs changed: ' + repr(identity))
        if a == b:
            result['unchanged'] += 1
            continue
        category = 'gains' if not healthy(a) and healthy(b) else 'losses' if healthy(a) and not healthy(b) else 'other_changes'
        result[category] += 1
        changes.append(dict(id=identity[0], mode=identity[1], classification=category, before=a, after=b))
    return result, changes


def comparisons():
    release = read('release.json')
    require(release['sha256'] == CANDIDATE and release['bytes'] == 3756760 and release['source_manifest_sha256'] == SOURCE, 'release binding')
    bound(release)
    require(release['source_manifest'] == 'candidate-source-final-2.json' and release['build_receipt'] == 'validation/release-adapter-188-1.json', 'release source/build')
    for manifest in ['comparison-preparation-ready.json', 'compare-predicates-inputs.json', 'before-comparison-inputs.json']:
        for row in read(manifest)['files']:
            data = bound(row)
            if 'original' in row:
                require(data == raw(row['original']), 'original copy: ' + row['path'])
    comparison = read('predicates-comparison.json')
    require(not comparison['validation_failures'] and comparison['candidate']['sha256'] == CANDIDATE, 'comparison status')
    require(len(comparison['profiles']) == 16, 'profile count')
    totals = {'established': {'cases': Counter(), 'controls': Counter()}, 'new': {'cases': Counter(), 'controls': Counter()}}
    all_changes = []; reports = {}
    for profile in comparison['profiles']:
        a = json.loads(bound(profile['before'])); b = json.loads(bound(profile['after']))
        require(a['binary_sha256'] == BASE_BINARY and b['binary_sha256'] == CANDIDATE, 'raw binary binding')
        require(not b.get('binding_failures'), 'raw binding failure')
        require(not profile['header_input_changes'], 'header drift')
        for header in set(a) | set(b):
            if (header.endswith('_sha256') and header != 'binary_sha256') or header in {'bounds', 'harness', 'tool_hashes', 'revision', 'runner_policy', 'mode_cases', 'bound_inputs'}:
                require(a.get(header) == b.get(header), 'raw input header: ' + header)
        reports[profile['profile']] = (a, b)
        for kind in ['cases', 'controls']:
            left = a[kind] if kind in a else a.get('harness_preflight', [])
            right = b[kind] if kind in b else b.get('harness_preflight', [])
            stats, changes = complete_rows(left, right)
            actual = profile[kind]
            require(all(actual[k] == v for k, v in stats.items()) and actual['changes'] == changes, 'complete-row reconstruction')
            require(not actual['added'] and not actual['removed'] and not actual['input_changes'], 'raw population drift')
            totals[profile['group']][kind].update(stats)
            all_changes.extend(dict(profile=profile['profile'], kind=kind, **r) for r in changes)
    require(totals == comparison['summary'], 'summary reconstructed from complete raw rows')
    policy = read('anticipated-inventory-changes.json')
    expected = {(r['kind'], r['id'], r['mode']): r for r in policy['rows']}
    historical = [r for r in all_changes if r['profile'] != 'node-predicates']
    require(len(historical) == 6, 'exact historical change count')
    for row in historical:
        require(row['profile'] == 'node-normalize', 'unanticipated established profile')
        expected_row = expected.pop((row['kind'], row['id'], row['mode']))
        require(row['classification'] == 'losses' and row['before'] == expected_row['before'], 'historical identity/health')
        after = row['after']
        require(after['status'] == 'failed' and after['matches_expectation'] is False, 'retained raw failure')
        require(all(after['observation'].get(k) == v for k, v in expected_row['expected_after_observation'].items()), 'Error versus TypeError')
        if row['kind'] == 'controls':
            require(after['verified'] is False and after['positive_partner_matches'] is False, 'no control-health waiver')
    require(not expected, 'all expected historical changes reached')
    old_before, old_after = reports['node-constants']
    for row in policy['already_unhealthy_unchanged']:
        wanted = row['before']; found = [r for r in old_after[row['kind']] if key(r) == key(wanted)]
        require(found == [wanted] and not healthy(wanted), 'older unhealthy row changed')
    new_before, new_after = reports['node-predicates']
    require([sum(map(healthy, r[k])) for r in [new_before, new_after] for k in ['cases', 'controls']] == [0, 4, 32, 16], 'new ordinary and paired control health')
    for mode in ['sloppy', 'strict']:
        case = next(r for r in new_after['cases'] if r['id'] == 'represented_complete_key_order#' + mode)
        require(healthy(case), 'current pristine inventory')
        for variant in ['positive', 'wrong']:
            control = next(r for r in new_after['controls'] if r['id'] == 'represented-node-order-' + variant + '#' + mode)
            require(healthy(control) and control['positive_partner_matches'] is True, 'current reflected-order pair')
    annotation = read('inventory-classification.json')
    require(annotation['comparison_sha256'] == INPUTS[str(B / 'predicates-comparison.json')]['sha256'], 'annotation comparison binding')
    require(annotation['policy_sha256'] == INPUTS[str(B / 'anticipated-inventory-changes.json')]['sha256'], 'annotation policy binding')
    require(annotation['expected_case_losses'] == 2 and annotation['expected_unhealthy_controls'] == 4 and annotation['unexpected_established_changes'] == 0, 'annotation totals')
    for label, expected_exit in [('replay-jobs', 1), ('comparison', 0), ('inventory-classification', 0)]:
        command(label + '-command.json', expected_exit)
    replay_receipts = sorted(B.glob('*-replay-command.json'))
    require(len(replay_receipts) == 16, 'replay command population')
    for path in replay_receipts:
        command(path.name, 1 if path.name in {'node-constants-replay-command.json', 'node-normalize-replay-command.json'} else 0)
    for profile in ['symbols', 'array-descriptors', 'reflect-construction']:
        command(profile + '-command.json', 0)
    return dict(summary=comparison['summary'], profiles=16, complete_historical_changes=historical,
                preserved_older_unhealthy_rows=6, aggregate_exit=1, comparison_exit=0, classifier_exit=0,
                release_sha256=CANDIDATE)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(not args.output.exists(), 'audit output must be new')
    report = dict(status='incomplete', findings=[], execution='Only byte/JSON/log parsing; no engine, compiler, helper import or subprocess.')
    try:
        raw(Path(__file__))
        report['validation'] = validation()
        report['comparison'] = comparisons()
        for path, expected in list(INPUTS.items()):
            data = Path(path).read_bytes()
            require(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) == expected, 'post-audit input drift: ' + path)
        report['status'] = 'clear'
    except Exception as error:
        report['status'] = 'failed'
        report['findings'].append(dict(type=type(error).__name__, message=str(error)))
    report['inputs'] = [{'path': path, **binding} for path, binding in sorted(INPUTS.items())]
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k not in {'inputs', 'comparison'}}, indent=2))
    return 0 if report['status'] == 'clear' else 1


if __name__ == '__main__':
    raise SystemExit(main())
