import concurrent.futures,hashlib,json,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent
BINARY=OUT/'eris-js'
sha=hashlib.sha256(BINARY.read_bytes()).hexdigest()
jobs=[]
for profile,prep in [('dom-method-identity','eris-dom-method-identity-preparation-1'),('object-is','eris-object-is-preparation-1')]:
 jobs.append((profile,['python3',f'/tmp/{prep}/local-preparation/run.py','--binary',str(BINARY),'--sha256',sha,'--output',str(OUT/(profile+'-after.json'))]))
for profile in ['symbols','array-descriptors','reflect-construction']:
 jobs.append((profile,['python3',str(OUT/'formal-check.py'),profile]))
for label,runner,output in [('CharacterData','/tmp/eris-character-data-1/replay.py','local-after.json'),('PI','/tmp/eris-processing-instruction-1/replay.py','pi-regression-after.json'),('production','/tmp/eris-dom-production-1/replay-production.py','production-after.json'),('node-original','/tmp/eris-node-data-1/replay-original.py','original-after.json'),('node-exact','/tmp/eris-node-data-1/replay-exact.py','exact-after.json')]:
 jobs.append((label,['python3',runner,str(BINARY),str(OUT/output)]))
jobs.append(('append',['python3','/tmp/eris-append-domstrings-1/replay.py',str(BINARY),sha,str(OUT/'append-after.json')]))
jobs.append(('title',['python3','/tmp/eris-document-title-1/replay.py',str(BINARY),sha,str(OUT/'title-after.json')]))
jobs.append(('node-constants',['python3','/tmp/eris-node-constants-batch-1/replay-preparation/replay.py',str(BINARY),sha,str(OUT/'node-constants-after.json')]))
jobs.append(('text-operations',['python3','/tmp/eris-text-operations-preparation-1/replay/replay.py',str(BINARY),sha,str(OUT/'text-after.json')]))
jobs.append(('node-normalize',['python3','/tmp/eris-node-normalize-preparation-1/replay/replay.py',str(BINARY),sha,str(OUT/'normalize-after.json')]))
jobs.append(('node-predicates',['python3','/tmp/eris-node-predicates-preparation-1/replay/replay.py',str(BINARY),sha,str(OUT/'predicates-after.json')]))
def run(job):
 label,argv=job;p=OUT/(label+'-replay.log');start=time.monotonic()
 with p.open('xb') as f:r=subprocess.run(argv,stdout=f,stderr=subprocess.STDOUT)
 record=dict(label=label,command=argv,exit=r.returncode,elapsed_seconds=time.monotonic()-start,log=p.name,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
 (OUT/(label+'-replay-command.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
 return record
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:records=list(pool.map(run,jobs))
assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==sha
raise SystemExit(any(r['exit'] for r in records))
