from pathlib import Path
import hashlib,json,shutil,subprocess
R=Path(__file__).resolve().parent;P=Path('/tmp/eris-node-predicates-preparation-1');OLD=Path('/tmp/eris-node-normalize-1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def binding(name):
 p=R/name;return dict(path=name,bytes=p.stat().st_size,sha256=sha(p))
baseline=json.loads((R/'predicates-before.json').read_text());assert len(baseline['cases'])==32 and len(baseline['controls'])==16
assert not baseline['binding_failures']
assert all(x['observation']['status']=='exception' and x['observation']['phase']=='runtime' and x['observation']['error_type']==x['observation']['error_identity']=='TypeError' for x in baseline['cases'])
assert sum(x['verified'] for x in baseline['controls'])==4
shutil.copytree(P,R/'preparation',ignore=shutil.ignore_patterns('browser','__pycache__'))
files=['before-comparison-inputs.json','predicates-before.json','predicates-baseline-command.json','predicates-baseline.log','predicates-verify-command.json','predicates-verify.log','preparation/replay/source-ready.json','preparation/replay/replay.py','preparation/replay/replay-inputs.json','preparation/replay/replay-matrix.json','preparation/replay/preparation-history.json','preparation/replay/inert-verify.json','preparation/cases.js','preparation/controls.json','preparation/root-plan-review.json']
config=dict(base='618fa35912e130ab3bc21396b2f1d37219eaac42',baseline_release_sha256=baseline['binary_sha256'],established_cases=4236,established_controls=460,new_cases=32,new_controls=16,files=[binding(n) for n in files])
path=R/'compare-predicates-inputs.json';path.write_text(json.dumps(config,indent=2)+'\n')
s=(OLD/'compare-normalize.py').read_text().replace('compare-normalize-inputs.json','compare-predicates-inputs.json').replace('0d52b9c5c3fa5ac8957ffd4a2f88dcbff9204209b5d6b72e05b1b8e6db09d7bb',sha(path))
s=s.replace("('node-normalize', 'normalize-after.json', 32, 16, 'new'),","('node-normalize', 'normalize-after.json', 32, 16, 'established'),\n    ('node-predicates', 'predicates-after.json', 32, 16, 'new'),")
s=s.replace("if name == 'node-normalize':","if name == 'node-predicates':").replace('complete-node-normalize-replay-comparison','complete-node-predicates-replay-comparison').replace("'normalize-comparison.json'","'predicates-comparison.json'")
(R/'compare-predicates.py').write_text(s)
s=(OLD/'classify-inventory.py').read_text().replace('396002bf1bdff3c814a8e17bd6d4c503ec01be3d5e9453ae5a27c69344088a3f',sha(R/'anticipated-inventory-changes.json')).replace('comparison-before/node-constants-after.json','comparison-before/normalize-after.json').replace("'normalize-comparison.json'","'predicates-comparison.json'").replace("('cases',4204,2),('controls',444,4)","('cases',4236,2),('controls',460,4)").replace("current_path=B/'normalize-after.json'","current_path=B/'predicates-after.json'").replace("x['profile']=='node-normalize'","x['profile']=='node-predicates'")
marker="if sys.argv[1:]==['--verify-before']:"
addition="""older=json.loads((B/'comparison-before/node-constants-after.json').read_text())
assert len(policy['already_unhealthy_unchanged'])==6
for row in policy['already_unhealthy_unchanged']:
 assert [x for x in older[row['kind']] if x['id']==row['id'] and x['mode']==row['mode']]==[row['before']]
 assert row['before']['matches_expectation'] is False
 if row['kind']=='controls':assert row['before']['verified'] is False
"""
assert s.count(marker)==1;s=s.replace(marker,addition+marker)
marker="assert seen==set(policies)"
addition="""assert seen==set(policies)
older_profile=next(x for x in result['profiles'] if x['profile']=='node-constants')
for kind in ['cases','controls']:
 assert not older_profile[kind]['changes']
for kind,before,after in [('cases',4148,4146),('controls',456,452)]:
 assert result['summary']['established'][kind]['before_healthy']==before
 assert result['summary']['established'][kind]['after_healthy']==after"""
assert s.count(marker)==1;s=s.replace(marker,addition)
s=s.replace('Six retained historical inventory assumptions are invalidated by the new ordinary Node method. Raw losses and unhealthy controls remain unchanged; no historical control-health waiver.','Six Normalize inventory assumptions are invalidated by the three new Node methods. Older Node inventory failures remain unchanged. Raw losses and unhealthy controls retain their health; no waiver.')
(R/'classify-inventory.py').write_text(s)
for label,script in [('compare-before','compare-predicates.py'),('classify-before','classify-inventory.py')]:
 log=R/(label+'.log');argv=['python3',str(R/script),'--verify-before']
 with log.open('xb') as stream:result=subprocess.run(argv,stdout=stream,stderr=subprocess.STDOUT)
 (R/(label+'-command.json')).write_text(json.dumps(dict(command=argv,exit=result.returncode,log=log.name,sha256=sha(log)),indent=2)+'\n')
 assert result.returncode==0,log.read_text()
files=['before-comparison-inputs.json','compare-predicates-inputs.json','compare-predicates.py','replay-jobs.py','formal-check.py','anticipated-inventory-changes.json','classify-inventory.py','prepare-comparison.py','predicates-before.json','compare-before-command.json','compare-before.log','classify-before-command.json','classify-before.log']
ready=dict(phase='Frozen after published Normalize baseline and inert before checks; no predicate compiler/candidate execution',files=[binding(n) for n in files],established_cases=4236,established_controls=460,new_cases=32,new_controls=16,baseline_healthy_cases=4148,baseline_healthy_controls=456,expected_new_historical_losses=dict(cases=2,controls=4),older_unhealthy_unchanged=dict(cases=2,controls=4),profile_count=16,runner_path='Use original absolute preparation drivers; copies under preparation are archival only',aggregate_runner='Expected1 from oldNode and newly staleNormalize profiles; retain raw nonzero command and independently classify exact differences')
(R/'comparison-preparation-ready.json').write_text(json.dumps(ready,indent=2)+'\n');print('Prepared16profiles; before checks passed')
