# Node predicates

This candidate adds ordinary `Node.prototype.hasChildNodes`, `isSameNode` and
`contains` methods for the represented nodes. They read current internal node
identity, children and parent links. They do not change the Document or decode
character data. Candidate validation and measured bootstrap values are pending;
the descriptions below record the held implementation and its authored checks.

## Ordinary methods and conversion

| Method | Length | Result |
| --- | --- | --- |
| `hasChildNodes()` | 0 | Whether the receiver has any ordinary children, including empty Text or Comment nodes. |
| `isSameNode(other)` | 1 | Whether the nullable Node argument identifies the receiver. |
| `contains(other)` | 1 | Whether the nullable Node argument is the receiver or an ordinary descendant. |

All three prototype properties are writable, enumerable and configurable data
properties. Each realm has one cached native function identity per method, with
ordinary `name` and `length` descriptors and Function prototype inheritance.
They are not constructors. Saved functions continue to work after a property is
shadowed, replaced or deleted. Deletion does not expose a hidden fallback.

Invocation checks the authentic receiver before required argument presence and
nullable interface conversion. `isSameNode()` and `contains()` throw TypeError
when the first argument is absent. A present `null` or `undefined` converts to
nullable null and returns false. Any other non-node value throws TypeError;
inheriting from `Node.prototype` does not manufacture a node brand. An authentic
node constructed with an alternate prototype retains its brand.

No authored `toString`, `valueOf`, `Symbol.toPrimitive`, `parentNode`, `childNodes`
or prototype getter participates in these native checks. Extra arguments are
ignored without conversion. JavaScript still evaluates all argument expressions
before invocation, including ignored extras. A move or removal performed by an
argument expression is therefore visible to the method's current tree read.

The authentic Document singleton and its public parent alias compare as the
same node. `isSameNode` compares identities, regardless of equal payloads or
position. Detached nodes contain themselves; unrelated detached trees do not
contain each other. These operations do not introduce a cross-document identity
scheme for reusing a Runtime with unrelated Rust Documents.

## Ordinary tree boundaries and local validation

`hasChildNodes` tests the receiver's direct child vector. A template's separate
content fragment is not an ordinary child. `contains` starts with its argument,
checks inclusive identity, and follows only ordinary parent links. It does not
follow a template fragment's host or enter descendants through a host
association. Explicitly calling the same methods on the content fragment reads
that separate tree.

The path validates each reached node's local shape and each followed parent's
container shape. It scans that parent's child IDs to require exactly one
reciprocal membership for the current node. Unrelated siblings' payloads and
subtrees are not read. No whole-arena scan, traversal vector, visited-ID map or
hidden cache is introduced.

A match at the snapshot-admitted boundary of 256 ordinary edges is accepted;
this can require 257 node visits. Self-parent links refuse directly. Cycles and
longer paths that do not first reach a result refuse within the bound. Reached
invalid IDs, missing or duplicate membership, noncontainer parents, childful
leaves, parented Fragments and misplaced Documents produce TypeError. This is
an internal malformed-host-data policy, not an additional standard hierarchy
exception or a complete graph validator. A self or ancestor result does not
inspect links above that result; null needs no traversal, and identity alone
does not validate unrelated graph state.

## Work and allocation admission

Each method pays receiver admission before inspecting its internal ID. Required
methods separately pay presence and nullable conversion checks. `contains`
pays each local visit and parent check, then prepays the entire selected
parent's child-ID scan. Its work is proportional to reached ancestors plus
scanned sibling IDs. It is not claimed to be independent of sibling count.
A wide valid sibling vector can exhaust the existing author work allowance.

The bodies allocate no owned traversal or payload storage. They return booleans
and leave all Document fields unchanged on success or refusal. The existing
native dispatch still allocates and charges its temporary invocation-name
copy, and generic VM paths retain their own admission. Inherited diagnostic
String construction and physical allocator failure remain outside any claim
of complete allocation accounting or recoverable memory exhaustion.

Admitted work remains spent even if a later check refuses; an early duplicate
may retain the full prepaid sibling-scan charge. Resource refusal follows the
existing terminal entry behavior and does not run an ordinary JavaScript
`catch` or `finally`. The predicates themselves cannot roll back earlier author
argument effects. Numeric limits, cumulative heap accounting, execution reset
sites, process authority and ERWA transport remain unchanged.

## Metadata order and constant publication

The represented Node operations appear in IDL order: `hasChildNodes`,
`normalize`, `isSameNode`, `contains`. The pristine prototype now has 26 own
keys: `nodeValue`, `textContent`, those four operations, the eighteen constants,
`constructor`, then `Symbol.toStringTag` in `Reflect.ownKeys`. This is the
current represented subset, not complete Node interface coverage. The original
constants, existing accessor/native identities and constructor flags remain
unchanged.

Before constant installation the prototype has seven entries, including its
tag; the constructor has three. Exact owner and physical-order guards use
these separate shapes and reserved order capacities of 26 and 21. Adding the
constants produces a 25-entry prototype map before its later constructor
property, and a 21-entry constructor map.

The pinned Rust 1.88 and 1.98 sorted map builders need four allocated tree nodes
for the 25-entry map: the initial leaf, root and second leaf at item 12, and a
third leaf at item 24. The final right-border repair moves four pairs without
allocating. The 21-entry constructor still needs three nodes. Admission covers
both prototype overflows, all typed nodes, complete map buffers, full UTF-16 key
comparison costs and the 48-entry sort scratch per map even for sorted input.
Old map/order charges remain cumulative.

All work, heap charges and fallible vector reservations finish before either old
map is consumed. Actual key ordering is checked before collecting each map;
both completed maps stay local until both succeed. A quota refusal occurs
before consumption. A later private invariant failure discards the incomplete
initializer instead of publishing a usable Runtime. Standard BTree/sort
allocation retains its inherited infallible process-memory boundary.

**Bootstrap measurement pending.** The source ledger predicts additional work
and storage for three metadata bags and the larger guarded build. These are
not observed counters; final measurements must precede any descriptive snapshot
update. No quota or reset change accompanies the implementation.

## Historical inventories and validation status

The frozen Node-constant fixture and frozen Normalize fixture remain byte-exact.
The older Node inventory already has two failing case modes and four unhealthy
reflected-order controls after Normalize; those six historical observations
remain. The new predicates are expected to change two Normalize full-inventory
case modes and four Normalize reflected-order controls as well. Their original
expectations must remain attached to the raw candidate outcomes. A matching
negative exception is insufficient when its same-mode positive partner fails.
These expected inventory differences are not blanket permission for other
regressions or a claim that all historical controls are healthy.

Private historical inventory wrappers run in disposable realms. The old Node
wrapper saves and removes all four later operations; the old Normalize wrapper
saves and removes the three predicates. Each invokes its unchanged historical
oracle, then restores descriptor/value identities. Restoring a property cannot
restore its creation order, so these realms are discarded. Separate pristine
realms run the new independently authored literal 26-key inventory. External
historical observations are never wrapped or relabeled as passes.

The new source contains sixteen independent bodies, each intended for fresh
strict and sloppy realms, and twelve private runtime groups. Private witnesses
cover exact and one-short work/heap admission, every cut of an ancestor walk,
receiver/arity order, nullish arguments, all represented leaves and Document
aliases, the accepted 256-edge boundary, malformed local links and cycles,
unrelated-arena independence, terminal wide-sibling refusal, saved-call cleanup,
and metadata isolation between two live realms. Existing constant tests retain
their identity/order and refusal assertions with the seven/three input shapes.

**Candidate results pending:** first compilation, focused checks, full suites,
browser integration, release replay and final source/evidence binding. No pass
count, measured bootstrap figure, host speedup or broader conformance rate is
claimed by this draft. These methods do not add shadow-tree/composed ancestry,
cross-document adoption, CDATA/XMLDocument construction, or missing Node
members. Existing unrelated DOM and allocation limitations remain.

Normative references: [Node](https://dom.spec.whatwg.org/#interface-node),
[hasChildNodes](https://dom.spec.whatwg.org/#dom-node-haschildnodes),
[isSameNode](https://dom.spec.whatwg.org/#dom-node-issamenode),
[contains](https://dom.spec.whatwg.org/#dom-node-contains),
[interface conversion](https://webidl.spec.whatwg.org/#es-interface), and
[operation bindings](https://webidl.spec.whatwg.org/#es-operations).
