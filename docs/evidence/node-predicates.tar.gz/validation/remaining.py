import subprocess
from pathlib import Path
H=Path(__file__).resolve().parent
for args in [
 ['full-native-198-2','1.98.0','Cargo.toml','vulkan-raster','test','--','--include-ignored','--test-threads=4'],
 ['release-adapter-188-1','1.88.0','Cargo.toml','-','build','--release','--bin','eris-js']]:
 r=subprocess.run(['python3',str(H/'check.py'),*args])
 if r.returncode:raise SystemExit(r.returncode)
