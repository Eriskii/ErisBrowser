import hashlib,json,shutil,re
from pathlib import Path
B=Path(__file__).resolve().parent
R=B/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((B/p).read_text())
for label,count in [('full-default-188-1',1805),('full-native-198-2',1928)]:
 r=read('validation/'+label+'.json');assert r['exit']==0 and sha(B/'validation'/r['log'])==r['sha256']
 totals=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (B/'validation'/r['log']).read_text())
 assert [sum(int(x[i]) for x in totals) for i in range(3)]==[count,0,0]
r=read('validation/release-adapter-188-1.json');assert r['exit']==0 and sha(B/'validation'/r['log'])==r['sha256']
s=read('candidate-source-final-2.json');assert len(s['files'])==16
held=B/'held-source-final';held.mkdir()
for row in s['files']:
 p=R/row['path'];assert sha(p)==row['sha256'] and p.stat().st_size==row['bytes']
 dest=held/row['path'];dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
p=B/'eris-js';assert not p.exists();shutil.copy2('/tmp/eris-vulkan-raster-prototype/target-msrv/release/eris-js',p)
result=dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size,source_manifest='candidate-source-final-2.json',source_manifest_sha256=sha(B/'candidate-source-final-2.json'),build_receipt='validation/release-adapter-188-1.json')
with (B/'release.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
