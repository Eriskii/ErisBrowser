import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads((BASE/p).read_text())
def checked(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def totals(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', (BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(x[i]) for x in rows) for i in range(3)]
assert totals('full-default-188-1')==[1805,0,0]
assert totals('full-native-198-2')==[1928,0,0]
source=read('candidate-source-final-2.json');assert len(source['files'])==16
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'held-source-final'/row['path'])
docs=read('documentation-ready.json');assert len(docs['files'])==10
for row in docs['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'documentation-draft'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
assert release['source_manifest_sha256']==sha(BASE/'candidate-source-final-2.json')
comparison=read('predicates-comparison.json');assert not comparison['validation_failures'];s=comparison['summary']
for kind,count,unchanged,losses in [('cases',4236,4234,2),('controls',460,456,4)]:
 row=s['established'][kind];assert row['before_total']==row['after_total']==count and row['unchanged']==unchanged and row['losses']==losses
 assert row['gains']==row['other_changes']==0
for kind,count,before in [('cases',32,0),('controls',16,4)]:
 row=s['new'][kind];assert row['before_total']==row['after_total']==row['after_healthy']==count
 assert row['before_healthy']==before and row['gains']==count-before and row['unchanged']==before
 assert row['losses']==row['other_changes']==0
classification=read('inventory-classification.json')
assert classification['comparison_sha256']==sha(BASE/'predicates-comparison.json')
ci=read('node-normalize-ci.json');assert ci['headSha']==source['base'] and ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
summary=dict(
 kind='Represented Node child, identity and containment predicates',base_commit=source['base'],
 scope='Ordinary cached Node.prototype.hasChildNodes, isSameNode and contains; authentic receivers, required nullable Node conversion and live ordinary tree links. Read-only bodies and separately retained template content; no ShadowRoot support.',
 source=source,release=release,
 final_validation={label:checked(label) for label in ['format-198-2','clippy-native-198-2','clippy-presenter-188-1','full-default-188-1','full-native-198-2','release-adapter-188-1']},
 tests=dict(default=1805,native=1928,new_groups=30,focused=read('focused-validation-review.json'),final_failed=0,final_ignored=0,all_commands_passed_first_attempt=False,native_retry_test_threads=4),
 accounting=dict(remaining_bootstrap_work=8807,allocated_bytes=1755715,objects=685,object_capacity=685,native_entries=321,legacy_prototype_entries=25,additional_work=1392,additional_charged_bytes=11214,bootstrap_work_limit=100000,author_work_limit=100000,cumulative_heap_limit=8388608,numeric_limits_and_resets_changed=False),
 compatibility=dict(path='predicates-comparison.json',sha256=sha(BASE/'predicates-comparison.json'),summary=s,inventory_classification=dict(path='inventory-classification.json',sha256=sha(BASE/'inventory-classification.json'),report=classification)),
 retained_history=[
 'Initial all-target compilation and all30 new groups passed; compiler warned about one unused mutable reference helper binding. Initial bootstrap filter retained26 passes/two stale descriptive assertion failures; exactly three descriptive literals across two files changed after measurement and the helper mut was removed.',
 'Strict Clippy refused three unnecessary clones in test-only temporary argument slices. Exactly those three expressions changed to borrowed slices; production and independently frozen fixtures remain unchanged.',
 'First full native run retained1616 passes/one failure observing the date-host helper startup marker before capture returned under its existing one-second deadline. The failed assertion does not identify the action or returned error. The unchanged exact test passed in isolation and unchanged full suite passed with four test threads. Existing deadline and all assertions retained; scheduling sensitivity is inferred, not proven as sole cause.',
 'New replay baseline retains32 missing-method TypeErrors and4/16 healthy controls. Candidate preserves raw nonzero historical Node and Normalize profile exits and aggregate exit: the earlier Node2+4 unhealthy inventory rows remain byte-exact; two Normalize inventory cases newly fail with Error and four controls become unhealthy with TypeError. No health waiver or fixture rewrite.'],
 boundaries=[
 'Represented ordinary node tree only; no ShadowRoot/composed ancestry, cross-document adoption, XMLDocument/CDATA construction or remaining Node methods.',
 'Contains validates reached local shapes and reciprocal ordinary parent membership, up to256edges/257visits. Early true/null results do not validate irrelevant links. Malformed host graph TypeError is an implementation policy, not an extra standard hierarchy exception.',
 'Work includes prepaid scans of reached parent child-ID vectors; wide sibling counts can exhaust author allowance. No owned traversal/payload storage, but generic VM dispatch/name-copy and diagnostic String allocation remain; no universal linear-time, complete allocation or physical allocator recovery claim.',
 'Page and confined-worker real-click witnesses retain18IDs without new click nodes, follow moves and detachment, and check literal whole-canvas/style/text results with separate template trees. No summary-cache priming claim.',
 'No page/GPU/physical-memory performance measurement. Full web compatibility, production security and requested Chromium performance threshold remain unachieved.'])
with (BASE/'result.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','target','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p.is_symlink() or name in {'eris-js','final-publication-review.json'}:continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/node-predicates.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  b=tar.extractfile(row['path']).read();assert len(b)==row['bytes'] and hashlib.sha256(b).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
p=ROOT/'docs/evidence/node-predicates.json';assert not p.exists();p.write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
