from pathlib import Path
import json,hashlib,difflib
P=Path('/tmp/eris-microtask-1/runtime/migration-followup-1');W=Path('/tmp/eris-microtask-1/worktree')
s=(W/'src/script.rs').read_text();before=s
start=s.index('    fn disclosure_task_cleanup_preserves_reentrant_queue_after_resource_or_listener_errors()')
a=s.index('            if failure.starts_with("while") {',start);b=s.index('            } else {\n                result.unwrap();',a)
old=s[a:b]
new='''            if failure.starts_with("while") {
                assert!(result.unwrap_err().is_resource_limit());
                assert!(runtime.microtasks_suspended());
                let a = document.query_selector("#a").unwrap();
                let b = document.query_selector("#b").unwrap();
                let first = document.peek_details_toggle().unwrap();
                assert_eq!(first.event.node, b);
                assert_eq!(
                    runtime.execute("caught", &mut document).unwrap(),
                    Value::Bool(false)
                );
                // Cleared tracker must not cancel the already queued closed>closed task.
                // Later synchronous edits remain allowed; suspended host tasks do not resume.
                runtime.execute("a.open=true;", &mut document).unwrap();
                assert_eq!(document.peek_details_toggle(), Some(first));
                assert_eq!(
                    runtime.execute("trace+'|'+count", &mut document).unwrap().to_string(),
                    "closed>open;|1"
                );
                for steps in [0, 7, 123, MAX_STEPS] {
                    runtime.steps = steps;
                    let allocated = runtime.allocated;
                    assert!(runtime.dispatch_details_toggles(&mut document).unwrap_err().is_resource_limit());
                    assert!(runtime.microtasks_suspended());
                    assert_eq!(runtime.steps, steps);
                    assert_eq!(runtime.allocated, allocated);
                    assert_eq!(document.peek_details_toggle(), Some(first));
                    assert!(!document.details_toggle_running());
                    assert_eq!(document.attr(a, "open"), Some(""));
                    assert_eq!(document.attr(b, "open"), Some(""));
                }
                assert_eq!(
                    runtime.execute("trace+'|'+caught+'|'+count", &mut document).unwrap().to_string(),
                    "closed>open;|false|1"
                );
                // Manual Rust fixture inspection of the inert queue, not callback resumption.
                // This retains the old cleared-tracker and reentrant-order witness.
                for (node, old_open, new_open) in [(b, false, true), (a, false, false), (a, false, true)] {
                    let task = document.peek_details_toggle().unwrap();
                    assert_eq!((task.event.node, task.event.old_open, task.event.new_open), (node, old_open, new_open));
                    assert_eq!(document.begin_details_toggle(task.id), Some(task));
                    assert!(document.finish_details_toggle(task.id));
                }
                assert!(runtime.microtasks_suspended());
                assert_eq!(document.attr(a, "open"), Some(""));
                assert_eq!(document.attr(b, "open"), Some(""));
                assert_eq!(
                    runtime.execute("trace+'|'+caught+'|'+count", &mut document).unwrap().to_string(),
                    "closed>open;|false|1"
                );
'''
s=s[:a]+new+s[b:]
# Exact reversal confirms there is only this one old fatal-branch replacement.
assert s.replace(new,old,1)==before
for folder,data in [('before',before),('raw',s)]:
    path=P/folder/'src/script.rs';assert not path.exists();path.write_text(data)
diff=''.join(difflib.unified_diff(before.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='before/src/script.rs',tofile='raw/src/script.rs'));(P/'change.diff').write_text(diff)
def rec(p):
    raw=p.read_bytes();return {'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
log=Path('/tmp/eris-microtask-1/validation/native-full-1.log');assert rec(log)['sha256']=='7b2056566ce5db0e9a019cf76e4b9fe266582c09eadf441afc58e7883396bfa7'
reason={
 'status':'explicit test-only policy migration after retained full-suite failure; no production correction',
 'test':'script::tests::disclosure_task_cleanup_preserves_reentrant_queue_after_resource_or_listener_errors',
 'observed_failure':'native-full-1:2673 passed/1 failed; the old fatal branch unwrapped a second direct details pump and received ResourceLimit suspension as preselected',
 'selected_policy':'Fatal Runtime failure is sticky. Direct dispatch_details_toggles refuses before reset/preflight/consumption; later synchronous author edits may run while asynchronous jobs remain inert.',
 'changes':['Only the existing fatal while(true) branch changes. Ordinary reported-error branch and common setup/cleanup assertions remain byte-identical.','Retain initial ResourceLimit, cleared running state/calls/stack, first queued b, caught=false and later synchronous a.open=true.','Assert sticky state and repeat direct pump refusal at0/7/123/MAX_STEPS without work reset, heap change, task consumption or DOM change. Trace/caught/count remain closed>open;|false|1.','Inspect and remove only via manual Rust peek/begin/finish fixture APIs, explicitly not callback resumption: b:false>true, a:false>false, a:false>true. This preserves the old cleared-tracker and reentrant-queue geometry guarantee.'],
 'unchanged':'Production prefix and every source byte outside the one fatal test arm reconstruct exactly; no budget, timeout, assertion weakening or retry mechanism.',
 'log':rec(log),'run_receipt':rec(log.with_suffix('.json')),
 'execution':'Source read/write/hash/diff only; no project execution or live edits.'}
(P/'reason.json').write_text(json.dumps(reason,indent=2)+'\n')
manifest={'status':'external test-only migration ready for independent peer','target':'src/script.rs','before':rec(P/'before/src/script.rs'),'after':rec(P/'raw/src/script.rs'),'diff':rec(P/'change.diff'),'reason':rec(P/'reason.json'),'selected_policy':rec(Path('/tmp/eris-microtask-1/root/design-selection.json')),'original_production_hold':rec(Path('/tmp/eris-microtask-1/runtime/production-1/source-ready.json')),'execution':'none'}
(P/'source-ready.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps(rec(P/'source-ready.json')))
