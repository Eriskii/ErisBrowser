from pathlib import Path
import hashlib,json,difflib,re
P=Path('/tmp/eris-microtask-1/runtime/production-1')
R=P.parent.parent

def record(p):
    b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(p,v):
    assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n')
rows=[]
for p in sorted((P/'raw').rglob('*.rs')):
    rel=p.relative_to(P/'raw');before=P/'before'/rel
    old=before.read_bytes() if before.exists() else b''
    after=p.read_bytes()
    diff=''.join(difflib.unified_diff(old.decode().splitlines(keepends=True),after.decode().splitlines(keepends=True),fromfile='before/'+str(rel),tofile='raw/'+str(rel)))
    row={'target':str(rel),'before':record(before) if before.exists() else None,'after':record(p),'changed':old!=after}
    if diff:
        d=P/'diffs'/('__'.join(rel.parts)+'.diff');d.write_text(diff);row['diff']=record(d)
    rows.append(row)
# Existing public-API groups, corrected private source, and all unaffected old migration spans stay literal.
selected=R/'runtime/tests-before'
for rel,source in [('src/script/microtask_budget_tests.rs',selected/'reporter-prefix-correction-1/raw/src/script/microtask_budget_tests.rs'),('src/script/microtask_tests.rs',selected/'src/script/microtask_tests.rs'),('src/script/microtask_binding_tests.rs',selected/'src/script/microtask_binding_tests.rs')]:
    assert (P/'raw'/rel).read_bytes()==source.read_bytes()
for rel in ['src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/dom_bindings/identity_tests.rs']:
    assert (P/'raw'/rel).read_bytes()==(R/'runtime/migrations-before/raw'/rel).read_bytes()
notes={
 'status':'source self-review complete; independent peer and all project execution remain outstanding',
 'scope':['Runtime-owned FIFO and separately admitted geometric capacity','Last direct metadata installer; one global Entry, no native registry change','Top-level author wrapper and complete listener callback/handleEvent lookup wrapper','Public parse/evaluation/event/details fatal epilogues; sticky Runtime flag observed by Page','Immutable-input prepaid report plan and transactional queue/console publication'],
 'preserved':['MAX_STEPS/MAX_HEAP/all call and process bounds','Generic Runtime::call and machine/event unconditional cleanup','Existing binding/semantic/Page/worker registrations copied from current AF source','Eleven semantic, four binding, eight corrected private groups and four frozen old migrations','Render/layout/SVG transport never execute callbacks; no Promise/timer API'],
 'accounting':{'bootstrap_work':327,'bootstrap_remaining':793,'objects':741,'globals':211,'native_registry':299,'installer_heap':'1004+A+D+2K+Bpp+N+4Bsb; plus State and one reserved ScriptObject in whole bootstrap','queue':'enqueue8; logical growth8+2len and full32+target*sizeof(Value); no refunds or spare bypass','checkpoint':'entry8; eligible drain8; dispatch8+entry8 before pop; original call fee afterward','reporter':'prefix30, B36/46/47 literals; cap-full returns after work8 without heap debit or formatting'},
 'cleanup':['Author depth restored before attempting drain, including ordinary/fatal errors','Performing guard restored before returning any drain error','Suspended private checkpoint is a no-op; direct details pump refuses before reset','Popped jobs never replay; failed pre-pop admission retains unstarted handle','Native call special branch stays within existing result expression, preserving native stack epilogue'],
 'review_notes':['HTML source audit found no author-reachable recursive .call Native receiver chain: prototype lookup returns stored callable data; dynamic receiver substitution is temporary and Function.bind uses an arena id. Retained FIFO handles do not deep-copy code/environments.','Fatal parser/source-storage/event-preflight failures are observed even when FIFO is empty. Later synchronous calls remain allowed but cannot enqueue/drain suspended jobs.','No source-derived accounting values are described as physical allocator memory or executed CPU instructions.'],
 'execution':'Inert file reads/writes, diffs, byte comparisons and hashes only. No compiler, formatter, project imports/tests, browser, git or live writes.'}
write(P/'source-review-notes.json',notes)
manifest={
 'status':'external production source hold; no runtime result claims',
 'base_commit':'4abb76abf186980500040052f20b982f2f1d861a',
 'worktree':'/tmp/eris-microtask-1/worktree',
 'selected_tests_api_ledger':record(selected/'source-ready-2.json'),
 'selected_tests_peer':record(selected/'html-review.json'),
 'migrations':record(R/'runtime/migrations-before/source-ready.json'),
 'root_selection':record(R/'root/design-selection.json'),
 'files':rows,
 'source_review_notes':record(P/'source-review-notes.json'),
 'authorship_tools':[record(P/'author-overlay.py'),record(P/'seal.py')],
 'registrations':'Current AF src/script.rs binding/semantic registrations and src/page.rs integration registration retained. Adds only private budget module and production microtasks module.',
 'frozen_groups':{'semantic':11,'binding':4,'private_budget':8,'total':23},
 'execution':'None; root alone imports, formats and executes. Before copies include root-installed baseline test registrations.'}
write(P/'source-ready.json',manifest)
print(json.dumps(record(P/'source-ready.json')))
