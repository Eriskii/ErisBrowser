from pathlib import Path
import difflib, shutil
ROOT=Path('/tmp/eris-microtask-1')
OUT=ROOT/'runtime/production-1'
W=ROOT/'worktree'
paths=['src/script.rs','src/page.rs','src/script/machine/calls.rs','src/script/dom_prototypes.rs','src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/dom_bindings/identity_tests.rs']
for rel in paths:
    for folder in ['before','raw']:
        p=OUT/folder/rel;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/rel,p)
# Apply only the held migration spans, allowing root's independent registrations.
for rel in ['src/page.rs','src/script/bootstrap_tests.rs','src/script/typed_array/tests.rs','src/script/dom_bindings/identity_tests.rs']:
    old=(ROOT/'runtime/migrations-before/before'/rel).read_text()
    new=(ROOT/'runtime/migrations-before/raw'/rel).read_text()
    current=(OUT/'raw'/rel).read_text()
    matcher=difflib.SequenceMatcher(None,old.splitlines(keepends=True),new.splitlines(keepends=True),autojunk=False)
    for tag,a,b,c,d in reversed(matcher.get_opcodes()):
        if tag=='equal': continue
        before=''.join(old.splitlines(keepends=True)[a:b]);after=''.join(new.splitlines(keepends=True)[c:d])
        if not before:
            anchor=''.join(old.splitlines(keepends=True)[a-2:a]);assert current.count(anchor)==1
            current=current.replace(anchor,anchor+after,1)
        else:
            assert current.count(before)==1,(rel,before)
            current=current.replace(before,after,1)
    (OUT/'raw'/rel).write_text(current)

def replace(s,a,b):
    assert s.count(a)==1,a[:150]
    return s.replace(a,b,1)
p=OUT/'raw/src/script.rs';s=p.read_text()
s=replace(s,'mod machine;','mod machine;\nmod microtasks;\n#[cfg(test)]\nmod microtask_budget_tests;')
s=replace(s,'    dom_prototypes: dom_prototypes::State,','    dom_prototypes: dom_prototypes::State,\n    microtasks: microtasks::State,')
s=replace(s,'            dom_prototypes: dom_prototypes::State::default(),','            dom_prototypes: dom_prototypes::State::default(),\n            microtasks: microtasks::State::default(),')
s=replace(s,'                + std::mem::size_of::<dom_prototypes::State>()','                + std::mem::size_of::<dom_prototypes::State>()\n                + std::mem::size_of::<microtasks::State>()')
s=replace(s,'        self.initialize_reflect_property_intrinsics()','        self.initialize_reflect_property_intrinsics()?;\n        self.install_microtask_intrinsic()')
s=replace(s,'''        let program = parser::Parser::program(source)?;
        self.execute_program(source, program, document)''','''        let result = parser::Parser::program(source)
            .and_then(|program| self.execute_program(source, program, document));
        self.observe_microtask_failure(result)''')
s=replace(s,'''        let program = parser::Parser::program_context(source, false, true)?;
        self.execute_program(source, program, document)''','''        let result = parser::Parser::program_context(source, false, true)
            .and_then(|program| self.execute_program(source, program, document));
        self.observe_microtask_failure(result)''')
a='''        let saved = self.environments[1].strict;
        self.environments[1].strict = program.strict;
        let completion =
            machine::evaluate_statements(self, &program, machine::ListOwner::Program, 1, document);
        self.environments[1].strict = saved;
        match completion? {
            Flow::Normal(value) => Ok(value.unwrap_or(Value::Undefined)),
            Flow::Return(_) => Err(ScriptError::new("return outside function")),
            _ => Err(ScriptError::new("loop control outside loop")),
        }'''
b='''        self.with_author_entry(document, |runtime, document| {
            let saved = runtime.environments[1].strict;
            runtime.environments[1].strict = program.strict;
            let completion = machine::evaluate_statements(
                runtime, &program, machine::ListOwner::Program, 1, document,
            );
            runtime.environments[1].strict = saved;
            match completion? {
                Flow::Normal(value) => Ok(value.unwrap_or(Value::Undefined)),
                Flow::Return(_) => Err(ScriptError::new("return outside function")),
                _ => Err(ScriptError::new("loop control outside loop")),
            }
        })'''
s=replace(s,a,b)
start=s.index('            let result = (|| {',s.index('    fn invoke_event_listeners('))
end=s.index('            self.events[id].passive = false;',start)
old=s[start:end]
new=old.replace('let result = (|| {','let result = self.with_author_entry(doc, |runtime, doc| {',1).replace('self.','runtime.').replace('let result = runtime.with_author_entry','let result = self.with_author_entry',1).replace('            })();','            });')
s=replace(s,old,new)
# Wrap entire public host bodies without changing their internal returned-error cleanup.
for name,endmarker in [('dispatch_dom_content_loaded','    pub fn dispatch_click('),('dispatch_details_toggles','    pub fn dispatch_event('),('dispatch_event','    fn tick(')]:
    start=s.index('    pub fn '+name+'(')
    begin=s.index(' {\n',start)+3
    end=s.index(endmarker,begin)
    close=s.rfind('    }',begin,end)
    body=s[begin:close]
    prefix=''
    if name=='dispatch_details_toggles':
        prefix='''        if self.microtasks_suspended() {
            return Err(ScriptError::resource("microtask dispatch suspended until reload"));
        }
'''
    indented=''.join('    '+line if line.strip() else line for line in body.splitlines(keepends=True))
    replacement=prefix+'        let result = (|| {\n'+indented+'        })();\n        self.observe_microtask_failure(result)\n'
    s=s[:begin]+replacement+s[close:]
p.write_text(s)
p=OUT/'raw/src/script/machine/calls.rs';s=p.read_text();s=replace(s,'    let result = if NumberPredicate::from_name(&native.name).is_some()','''    let result = if native.name == "queueMicrotask" {
        // This Window operation uses the dynamic receiver without allocating a
        // temporary Native name or bypassing unconditional stack cleanup.
        runtime.queue_microtask(&receiver, &arguments)
    } else if NumberPredicate::from_name(&native.name).is_some()''');p.write_text(s)
p=OUT/'raw/src/script/dom_prototypes.rs';s=p.read_text();s=replace(s,'    + object_has_own::METADATA_OBJECTS','    + microtasks::METADATA_OBJECTS\n    + object_has_own::METADATA_OBJECTS');p.write_text(s)
p=OUT/'raw/src/page.rs';s=p.read_text();s=replace(s,'        } else if self.tasks_suspended {','        } else if self.tasks_suspended || self.runtime.microtasks_suspended() {');p.write_text(s)
# Preserve the corrected private module exactly; existing imported tests remain untouched.
shutil.copyfile(ROOT/'runtime/tests-before/reporter-prefix-correction-1/raw/src/script/microtask_budget_tests.rs',OUT/'raw/src/script/microtask_budget_tests.rs')
for rel in ['src/script/microtask_tests.rs','src/script/microtask_binding_tests.rs']:
    assert (W/rel).read_bytes()==(ROOT/'runtime/tests-before'/rel).read_bytes()
    shutil.copyfile(W/rel,OUT/'raw'/rel)
    dest=OUT/'before'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/rel,dest)
for p in sorted((OUT/'raw').rglob('*.rs')):
    rel=p.relative_to(OUT/'raw');old=OUT/'before'/rel
    before=old.read_text().splitlines(keepends=True) if old.exists() else []
    diff=''.join(difflib.unified_diff(before,p.read_text().splitlines(keepends=True),fromfile='before/'+str(rel),tofile='raw/'+str(rel)))
    if diff:(OUT/'diffs'/('__'.join(rel.parts)+'.diff')).write_text(diff)
print('External source overlay authored; no project execution.')
