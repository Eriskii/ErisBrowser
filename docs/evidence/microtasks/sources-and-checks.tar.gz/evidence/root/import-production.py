import hashlib
import json
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
worktree = checkpoint / 'worktree'
manifest = checkpoint / 'runtime/production-1/source-ready.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == 'b941ddd3fe878700f06043c70f8e777a58bd74c9fd1e35beda79d6e3a00a93e4'
record = json.loads(manifest.read_text())
def check(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    return data
for key in ['selected_tests_api_ledger', 'selected_tests_peer', 'migrations', 'root_selection', 'source_review_notes']:
    check(record[key])
for row in record['files']:
    assert row['target'].startswith('src/') and '..' not in Path(row['target']).parts
    target = worktree / row['target']
    if row['before'] is None:
        assert not target.exists(), target
    else:
        assert target.read_bytes() == check(row['before']), target
    check(row['after'])
    if 'diff' in row:
        check(row['diff'])
for row in record['files']:
    if row['changed']:
        target = worktree / row['target']
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(check(row['after']))
receipt = {
    'status': 'imported after root source review; independent production peer runs alongside compilation',
    'source_ready_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'selected_tests_sha256': record['selected_tests_api_ledger']['sha256'],
    'changed_files': [row['target'] for row in record['files'] if row['changed']],
    'unchanged_baseline_tests': [row['target'] for row in record['files'] if not row['changed']],
}
with (checkpoint / 'root/import-production.json').open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(receipt))
