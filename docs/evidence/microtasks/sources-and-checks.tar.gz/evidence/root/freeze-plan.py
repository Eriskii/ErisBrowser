import hashlib
import json
import shutil
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
source = Path('/tmp/eris-microtask-plan-1')
target = checkpoint / 'root/plan-before'
target.mkdir()
names = [
    'proposal.json', 'resource-contract.json', 'oracles.json', 'api.txt',
    'source-ready.json', 'page-boundaries.json', 'html-spec-review.json',
    'html-binding-review.json', 'bootstrap-review.json',
]
entries = []
for name in names:
    data = (source / name).read_bytes()
    (target / name).write_bytes(data)
    entries.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
record = {
    'scope': 'Architectural and source-only review holds before queue implementation. Numeric implementation ledger is separate.',
    'parent': '4abb76abf186980500040052f20b982f2f1d861a',
    'entries': entries,
    'binding_baseline': 'validation/baseline-binding-1.json',
    'baseline_result': 'Four tests compiled and failed with missing queueMicrotask ReferenceError; no production implementation imported.',
}
(target / 'freeze.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
