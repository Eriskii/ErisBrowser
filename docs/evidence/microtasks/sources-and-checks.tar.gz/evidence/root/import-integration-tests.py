import hashlib
import json
import shutil
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
worktree = checkpoint / 'worktree'
source = Path('/tmp/eris-microtask-plan-1/page-tests-before')
record = json.loads((source / 'source-ready.json').read_text())
def check(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
    return data
for row in record['source_context']:
    check(row)
for row in record['files']:
    check(row['raw'])
    assert not (worktree / row['relative']).exists()
check(record['literal_freeze'])
check(record['oracles'])
registration = worktree / 'tests/worker.rs'
original = registration.read_bytes()
assert b'mod microtasks;' not in original
hold = checkpoint / 'root/integration-tests-before'
assert not hold.exists()
shutil.copytree(source, hold)
for row in record['files']:
    target = worktree / row['relative']
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(check(row['raw']))
registration.write_bytes(original + b'\n#[path = "worker/microtasks.rs"]\nmod microtasks;\n')
print('Imported four integration groups, five raw sources and worker registration.')
