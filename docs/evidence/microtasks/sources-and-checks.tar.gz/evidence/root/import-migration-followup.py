import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[1]
hold = root / 'runtime/migration-followup-1'
manifest = hold / 'source-ready.json'
assert hashlib.sha256(manifest.read_bytes()).hexdigest() == 'a2b42ff44e4581ac8d0b120885550651702b02ffa3b048d8401f17c8371257c5'
record = json.loads(manifest.read_text())
review = hold / 'html-review.json'
assert hashlib.sha256(review.read_bytes()).hexdigest() == '6878a1f5e167aa6445ea3b4c084b02fd5fc6472d642aee5b63c44a3ccef4948b'
assert json.loads(review.read_text())['status'] == 'clear'
def check(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']
    return data
for key in ['before', 'after', 'diff', 'reason', 'selected_policy', 'original_production_hold']:
    check(record[key])
target = root / 'worktree' / record['target']
assert target.read_bytes() == check(record['before'])
target.write_bytes(check(record['after']))
receipt = {
    'status': 'imported explicit old-test migration; production and budgets unchanged',
    'target': record['target'],
    'before': record['before']['sha256'], 'after': record['after']['sha256'],
    'manifest_sha256': hashlib.sha256(manifest.read_bytes()).hexdigest(),
    'peer_sha256': hashlib.sha256(review.read_bytes()).hexdigest(),
}
with (root / 'root/import-migration-followup.json').open('x') as out:
    json.dump(receipt, out, indent=2)
    out.write('\n')
print(json.dumps(receipt))
