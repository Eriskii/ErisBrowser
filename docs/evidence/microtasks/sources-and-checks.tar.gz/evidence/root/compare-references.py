"""Compare all unchanged reference PNGs with the published parent archive."""
from pathlib import Path
import hashlib
import json
import tarfile

root = Path(__file__).resolve().parent.parent
worktree = root / "worktree"
parent = worktree / "docs/evidence/cssom-wide-getter"
summary = json.loads((parent / "summary.json").read_text())
archive = parent / "sources-and-checks.tar.gz"
archive_bytes = archive.read_bytes()
assert len(archive_bytes) == summary["archive"]["bytes"]
assert hashlib.sha256(archive_bytes).hexdigest() == summary["archive"]["sha256"]
report_path = root / "reftests-final/report.json"
report = json.loads(report_path.read_text())
assert report["total"] == 102 and report["failed"] == 0
prefix = "evidence/reftests-final/"
seen = set()
rows = []
with tarfile.open(archive, "r:gz") as stream:
    for member in stream:
        if not member.name.startswith(prefix) or not member.name.endswith(".png"):
            continue
        name = member.name[len(prefix):]
        assert member.isfile() and "/" not in name and name not in seen
        assert 0 < member.size <= 4 * 1024 * 1024
        seen.add(name)
        prior = stream.extractfile(member).read()
        current = (root / "reftests-final" / name).read_bytes()
        assert len(prior) == member.size and current == prior, name
        rows.append({"name": name, "bytes": len(current),
                     "sha256": hashlib.sha256(current).hexdigest()})
assert len(seen) == 204
assert seen == {p.name for p in (root / "reftests-final").glob("*.png")}
result = {"status": "pass", "pairs": 102, "unchanged_pngs": 204,
          "parent_archive_sha256": summary["archive"]["sha256"],
          "report_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
          "images": sorted(rows, key=lambda row: row["name"])}
with (root / "root/reference-comparison-final.json").open("x") as output:
    json.dump(result, output, indent=2)
    output.write("\n")
print(json.dumps({key: value for key, value in result.items() if key != "images"}))
