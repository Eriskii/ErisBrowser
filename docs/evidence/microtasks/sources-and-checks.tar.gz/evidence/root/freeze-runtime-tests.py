import hashlib
import json
import shutil
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
source = checkpoint / 'runtime'
selected = source / 'tests-before/source-ready-2.json'
record = json.loads(selected.read_text())
def check(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'], row['path']
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row['path']
for row in record['files']:
    check(row)
for key in ['migrations', 'previous_hold', 'correction']:
    check(record[key])
migrations = json.loads(Path(record['migrations']['path']).read_text())
for migration in migrations['changes']:
    for key in ['before', 'after', 'diff']:
        check(migration[key])
prefix = b'Uncaught microtask exception: '
assert len(prefix) == 30
assert len(prefix + b'marker') == 36
assert 8 + 2 * len(prefix + b'marker') == 80
assert 8 + 2 * len(prefix + b'marker at byte 0') == 100
assert 8 + 2 * len(prefix + b'marker at byte 12') == 102
hold = checkpoint / 'root/runtime-tests-before'
hold.mkdir()
for directory in ['tests-before', 'migrations-before']:
    shutil.copytree(source / directory, hold / directory)
receipt = {
    'selection_sha256': hashlib.sha256(selected.read_bytes()).hexdigest(),
    'runtime_groups': 23,
    'existing_api_baseline_groups': 15,
    'private_groups': 8,
    'integration_groups': 4,
    'existing_api_parent_baselines': 'All19 compiled and failed at missing behavior; all4 integration failures were literal red-x2 versusx6.',
    'reporter_prefix': 'Root independently counted30 UTF8 bytes; marker36, spare80, cold88.',
    'status': 'Hashes verified and held before production; private tests/migrations not yet imported.'
}
(hold / 'freeze.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
