import hashlib
import json
import shutil
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
worktree = checkpoint / "worktree"
manifest = checkpoint / "runtime/tests-before/binding-source-ready.json"
record = json.loads(manifest.read_text())
source = Path(record["source"]["path"])
data = source.read_bytes()
assert len(data) == record["source"]["bytes"]
assert hashlib.sha256(data).hexdigest() == record["source"]["sha256"]
script = worktree / "src/script.rs"
original = script.read_bytes()
assert hashlib.sha256(original).hexdigest() == "5242fcd08aead0de4ecc78e906e0e774ba01d9604eef5864da6c719f0ae213df"
anchor = b"#[cfg(test)]\nmod bootstrap_tests;\n"
assert original.count(anchor) == 1
target = worktree / "src/script/microtask_binding_tests.rs"
assert not target.exists()
hold = checkpoint / "root/binding-tests-before"
hold.mkdir()
shutil.copy2(manifest, hold / manifest.name)
shutil.copy2(source, hold / source.name)
target.write_bytes(data)
script.write_bytes(original.replace(anchor, anchor + b"#[cfg(test)]\nmod microtask_binding_tests;\n"))
print("Imported four existing-API binding tests; production source unchanged except test registration.")
