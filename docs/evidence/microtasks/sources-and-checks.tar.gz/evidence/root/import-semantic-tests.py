import hashlib
import json
import shutil
from pathlib import Path

checkpoint = Path(__file__).resolve().parents[1]
worktree = checkpoint / 'worktree'
manifest = checkpoint / 'runtime/tests-before/semantic-source-ready.json'
record = json.loads(manifest.read_text())
source = Path(record['file']['path'])
data = source.read_bytes()
assert len(data) == record['file']['bytes']
assert hashlib.sha256(data).hexdigest() == record['file']['sha256']
script = worktree / 'src/script.rs'
original = script.read_bytes()
prior_registration = b'#[cfg(test)]\nmod microtask_binding_tests;\n'
assert original.count(prior_registration) == 1
assert hashlib.sha256(original.replace(prior_registration, b'')).hexdigest() == '5242fcd08aead0de4ecc78e906e0e774ba01d9604eef5864da6c719f0ae213df'
target = worktree / 'src/script/microtask_tests.rs'
assert not target.exists()
hold = checkpoint / 'root/semantic-tests-before'
hold.mkdir()
shutil.copy2(manifest, hold / manifest.name)
shutil.copy2(source, hold / source.name)
target.write_bytes(data)
script.write_bytes(original.replace(prior_registration, prior_registration + b'#[cfg(test)]\nmod microtask_tests;\n'))
print('Imported eleven semantic groups, production unchanged except test registration.')
