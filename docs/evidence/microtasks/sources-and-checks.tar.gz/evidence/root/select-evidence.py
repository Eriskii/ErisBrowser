from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

inventory = root / 'source-2.json'
sources = json.loads(inventory.read_text())['source_sha256']
assert len(sources) == 760
for name, sha in sources.items():
    assert bind(root / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['native-full-2', 'default-full-1', 'strict-msrv-1', 'strict-current-1',
              'format-check-1', 'browser-final-build-1', 'references-final-1']:
    result = json.loads((root / 'validation' / (label + '.json')).read_text())
    assert result['exit'] == 0
    assert bind(root / 'validation' / result['log'])['sha256'] == result['sha256']
    checks[label] = result
for name in ['final-source-review.json', 'validation-review.json']:
    assert json.loads((root / 'root' / name).read_text())['status'] == 'clear'
totals = json.loads((root / 'root/full-suite-totals.json').read_text())
assert totals['native-full-2']['passed'] == 3093
assert totals['default-full-1']['passed'] == 2789
parent_ci = json.loads((root / 'validation/parent-ci-final-1.log').read_text())
assert parent_ci['headSha'] == '4abb76abf186980500040052f20b982f2f1d861a'
assert parent_ci['conclusion'] == 'success' and len(parent_ci['jobs']) == 9
assert all(job['conclusion'] == 'success' for job in parent_ci['jobs'])
reference = json.loads((root / 'root/reference-comparison-final.json').read_text())
assert reference['status'] == 'pass'
assert reference['pairs'] == 102 and reference['unchanged_pngs'] == 204
artifacts = {}
for directory in ['runtime', 'validation', 'reftests-final', 'root']:
    for path in sorted((root / directory).rglob('*')):
        if path.is_file():
            assert not path.is_symlink()
            assert path.name not in ('selection-final.json', 'publication-verification.json')
            artifacts[str(path.relative_to(root))] = bind(path)
for path in sorted(root.glob('*')):
    if path.is_file() and path.suffix in ('.json', '.py'):
        artifacts[path.name] = bind(path)
for name in ['README.md', 'docs/ROADMAP.md', 'docs/ARCHITECTURE.md', 'docs/microtasks.md']:
    artifacts['documentation/' + name] = bind(root / 'worktree' / name)
selection = {
    'source_inventory': bind(inventory),
    'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': parent_ci['headSha'],
        'scope': 'Single-Window queueMicrotask FIFO, author-entry cleanup checkpoints, prepaid queue/reporting work and heap, and sticky asynchronous suspension through Page and confined worker.',
        'source_inputs': 760,
        'new_test_groups': {'runtime_semantic': 11, 'binding': 4, 'private_budget': 8, 'page': 2, 'confined_worker': 2, 'total': 27},
        'parent_baselines': {'public_groups': 19, 'compiled': 19, 'failed_as_predicted': 19,
            'private_budget_baseline': 'Eight new private API groups cannot compile meaningfully on the parent; no parent failure claimed.',
            'integration_failure_stage': 'All four Page/worker parent groups stop at the initial pixel comparison; later ordering assertions are not parent observations.'},
        'history': {
            'preproduction_reporter_correction': 'Reporter prefix was independently recounted as 30 bytes before production and execution. Test fees changed from 86/78 to 88/80; original holds and correction receipts retained.',
            'initial_complete_attempt': {'label': 'native-full-1', 'lib_passed': 2673, 'lib_failed': 1, 'later_targets_ran': False,
                'reason': 'Missed legacy test expected disclosure dispatch to resume after fatal resource failure. The selected sticky suspension policy refuses that retry.'},
            'followup': 'Only the legacy fatal test arm changed: repeated preflight refusals preserve budgets, DOM and three queued notifications. Rust fixture inspection, explicitly not callback dispatch, checks their FIFO. Production and quotas unchanged.',
            'source1_sha256': bind(root / 'source-1.json')['sha256'],
            'final_source2_sha256': bind(inventory)['sha256']
        },
        'checks': checks,
        'full_suite_totals': {key: {field: val[field] for field in ['passed','failed','ignored','result_rows','log_sha256']} for key,val in totals.items()},
        'integration_oracles': {'unique_literal_rgba_frames': 12, 'literal_rgba_bytes': 1802496, 'page_worker_layout_or_render_calls': 40,
            'interpretation': 'Page and confined worker CPU pixels plus packed native-plan CPU interpretation; no new GPU execution claim.'},
        'references': {key: reference[key] for key in ['pairs','unchanged_pngs','parent_archive_sha256','report_sha256']},
        'browser': json.loads((root / 'root/final-browser.json').read_text()),
        'parent_ci': {'head':parent_ci['headSha'], 'url':parent_ci['url'], 'conclusion':'success', 'jobs':9,
            'raw':bind(root / 'validation/parent-ci-final-1.log')},
        'resource_policy': {'bootstrap_work':100000, 'raw_bootstrap_remaining':793, 'startup_added_work':327,
            'author_work':100000, 'cumulative_heap_bytes':8388608,
            'new_runtime_header':True, 'unchanged_numeric_caps':True,
            'measurement_scope':'Logical charges; no physical allocator or processor-work guarantee.'},
        'limits': [
            'Authored local tests, not imported WPT conformance results.',
            'No Promise, timer, MutationObserver, rejection notification or full HTML event-loop implementation.',
            'Ordinary asynchronous exceptions use Runtime.console, not full HTML ErrorEvent/onerror reporting.',
            'Single Runtime/Window realm; no cross-realm callback settings implementation.',
            'Post-parse classic script loading remains; no new async/defer/module scheduler.',
            'No Chromium performance comparison, full web compatibility, or production-security claim.',
            'No new GPU or acquired-window observation. Existing Vulkan backend is unchanged.',
            'Build caches reused; times are not cold-build measurements.'
        ]
    }
}
with (root / 'root/selection-final.json').open('x') as stream:
    json.dump(selection, stream, indent=2)
    stream.write('\n')
print(json.dumps({'sources':len(sources), 'artifacts':len(artifacts)}))
