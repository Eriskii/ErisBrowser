# Microtask callbacks and host checkpoints

`queueMicrotask(callback)` schedules a callable in the current Window realm.
The runtime drains the FIFO when the outermost script or host callback finishes,
including callbacks appended during that drain. Enqueuing returns `undefined`;
missing or noncallable callbacks synchronously throw `TypeError`. A callback
receives no arguments and an undefined receiver through ordinary JavaScript
invocation, preserving strict, sloppy, arrow and bound-function behavior.

For example, the script below finishes with `SABC` after its checkpoint. The
script's own final expression still evaluates to `S`: cleanup does not change
an already computed completion value.

```js
var log = '';
queueMicrotask(function () {
    log += 'A';
    queueMicrotask(function () { log += 'C'; });
});
queueMicrotask(function () { log += 'B'; });
log += 'S';
log;
```

The installed function is one writable, enumerable and configurable Window
property, shared by bare, `window` and initial `globalThis` access. Saved
references survive replacement or deletion of that property. Detached calls
and null/undefined receivers use the operation's realm global; unrelated
receivers throw `TypeError`. Replacing the `globalThis` property does not change
that realm identity. The function has name `queueMicrotask`, length one, no
own `prototype` initially, and cannot be used as a constructor.

## Where callbacks run

An explicit author-entry counter distinguishes host callbacks from nested
JavaScript calls. A host event listener can therefore finish its queued jobs
before the next listener runs. Synchronous `dispatchEvent` called from a
script defers those jobs until the enclosing author entry finishes. An object
listener's `handleEvent` lookup and method invocation share one entry; cleanup
does not run queued work between its getter and method.

Listener cleanup checkpoints occur while `currentTarget`, `eventPhase` and
the passive-listener state still apply. Ordinary return handling, exception
reporting and propagation checks follow. Queued mutations settle before the
existing click default action, form-data collection, SVG refresh and layout.
Script checkpoints also precede the next script and readiness events.

Rendering, layout and resource preparation execute no author callbacks.
The worker protocol carries no callback queue. The existing `RunTasks`
mechanism continues to handle disclosure notifications; it does not provide
a separate microtask budget or resume an unfinished drain.

## Resource and failure policy

Jobs retain existing callable handles in a runtime-owned `VecDeque`. Logical
capacity grows geometrically, independently of any extra capacity granted by
the allocator. Capacity, relocation, enqueue, dispatch and cleanup are charged
before publication or removal. The queue and its jobs share the initiating
host entry's existing work allowance and cumulative runtime heap allowance.
There is no per-job reset or successful yield after a fixed number of jobs.

An ordinary callback exception is reported once through the bounded
`Runtime.console` path, then the next callback runs. Callback return values
are ignored without coercion or thenable assimilation. Reporting computes its
required size from the immutable error record and pays for formatting and
storage before constructing the message. Its 1,024-entry admission threshold
is specific to this asynchronous reporter; existing console producers retain
their own policies. This path does not implement the full HTML
`ErrorEvent`/`onerror` reporting algorithm or copy messages to Page diagnostics.

A resource failure, unsupported execution or failed report permanently
suspends asynchronous work in that Runtime. A removed job is never replayed.
Unstarted jobs remain bounded and inert until the Runtime is destroyed;
further enqueue attempts fail. Page task state exposes suspension even if the
failure occurred outside disclosure dispatch. Repeated `Render`, `RunTasks`
or a later work-budget reset cannot resume the queue. Later synchronous input
may still execute its existing handlers. Full navigation creates a fresh
Runtime; same-document navigation retains the current one.

These are the engine's explicit bounded-execution policies. Logical charges
are not physical-memory measurements or a guarantee against all allocator
failures. The worker's confinement, resource broker and request deadlines
remain in place.

## Scope

This foundation covers the existing single Runtime/Window realm. Promise jobs,
MutationObserver delivery, rejection notifications, hosted timers, animation
callbacks, worker-global realms and cross-realm callback settings remain
separate work. The existing script loader still runs supported classic scripts
after parsing and resource preparation; this change does not add parser-interleaved
execution. The runtime keeps one FIFO model for later job integration.
This is not a complete HTML event loop or a web-compatibility claim.

The behavior follows the HTML [microtask API](https://html.spec.whatwg.org/multipage/timers-and-user-prompts.html#microtask-queuing)
and [cleanup checkpoints](https://html.spec.whatwg.org/multipage/webappapis.html#perform-a-microtask-checkpoint),
Web IDL [callback invocation](https://webidl.spec.whatwg.org/#invoke-a-callback-function),
and DOM [listener invocation](https://dom.spec.whatwg.org/#concept-event-listener-inner-invoke).

<!-- Draft: replace this marker with actual validation and evidence after execution. -->
