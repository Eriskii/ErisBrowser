from pathlib import Path
import hashlib,json,re,subprocess,difflib
K=Path('/tmp/eris-super-properties-plan-1'); P=K/'runtime-producer-1'; R=K/'runtime-review-1';W=K/'worktree'
BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(K)),'bytes':len(b),'sha256':sha(b)}
def block(s,name):
 # Test-only source partition: declaration starts at a whole Rust function line;
 # slices terminate at next same-indentation function, retaining exact bodies.
 m=re.search(r'(?m)^( *)(?:pub(?:\([^\n]*?\))? )?fn '+re.escape(name)+r'\(',s); assert m,name
 indent=m[1];tail=s[m.start():]
 n=re.search(r'(?m)^'+re.escape(indent)+r'(?:pub(?:\([^\n]*?\))? )?fn ',tail[len(m[0]):])
 return tail if n is None else tail[:len(m[0])+n.start()]
draft=json.loads((P/'draft-ready.json').read_text()); rows=[]
for row in draft['paths']:
 path=row['path'];raw=P/'raw'/path;b=raw.read_bytes()
 assert len(b)==row['bytes'] and sha(b)==row['after']
 old=P/'before'/path
 if row['before'] is not None:
  a=old.read_bytes();assert sha(a)==row['before']
  assert a==subprocess.check_output(['git','show',BASE+':'+path],cwd=W)
 else:a=b''
 patch=P/'diffs'/Path(path+'.diff'); expected=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/'+path,tofile='b/'+path))
 assert patch.read_text()==expected
 rows.append({'repository_path':path,'before':bind(old) if old.exists() else None,'raw':bind(raw),'diff':bind(patch)})
# Whole function preservation, using adjacent top-level function partitions.
exact=[]
for path,names in {
 'src/script/classes.rs':['this_environment','class_this_value','class_bind_this','class_validate_superclass','construct_class'],
 'src/script/machine.rs':['super_arguments_start','super_arguments_next','super_spread_next','finish_super','push','enter_frame','enter','child','eval_child','named_class_child','reference_child','drive','assign_reference'],
 'src/script/machine/calls.rs':['forward','class_completion','parameters','initialize_parameter','body']
}.items():
 old=(P/'before'/path).read_text();new=(P/'raw'/path).read_text()
 for name in names:
  a=block(old,name);b=block(new,name);assert a==b,(path,name)
  exact.append({'repository_path':path,'function_partition':name,'bytes':len(a.encode()),'sha256':sha(a.encode())})
# Old direct-super target and class entry differ only by selected field rename.
renamed=[]
for path,name in [('src/script/classes.rs','class_super_target'),('src/script/machine/calls.rs','class_start')]:
 a=block((P/'before'/path).read_text(),name);b=block((P/'raw'/path).read_text(),name)
 assert a.replace('active_constructor','active_function')==b
 renamed.append({'repository_path':path,'function_partition':name,'before_sha256':sha(a.encode()),'after_sha256':sha(b.encode())})
a=(P/'before/src/script/classes/quota_tests.rs').read_text();b=(P/'raw/src/script/classes/quota_tests.rs').read_text();assert a.replace('active_constructor','active_function')==b
# Generic old factory is preserved inside the prepaid entry except one new field.
a=block((P/'before/src/script.rs').read_text(),'function_value');b=block((P/'raw/src/script.rs').read_text(),'function_value_prepaid_home')
old_body=a[a.index('{'):];new_body=b[b.index('{'):].replace('            home_object: None,\n','')
assert old_body==new_body
# Verify published runtime Function literal sites all acquire one home field.
s=(P/'raw/src/script.rs').read_text();c=(P/'raw/src/script/classes.rs').read_text()
assert s.count('self.functions.push(Function {')==3 and c.count('self.functions.push(Function {')==1
assert s.count('home_object: None,')==3 and c.count('home_object: Some(prototype_id),')==1
assert 'self.function_value_prepaid_home(code, class_env)?' in c and 'self.function_value(code, class_env)?' not in c
assert s.count('self.charge(FUNCTION_HOME_BYTES)?;')==1
# Root measured representation record is explicitly observational, not rerun here.
layout=json.loads((K/'root/layout-measurements-1.json').read_text())
for m in layout['measurements']:
 if m['runtime']:
  assert m['runtime']['Function.before']['bytes']==104
  assert m['runtime']['Function.proposed']['bytes']==120
  assert m['runtime']['Frame.before']['bytes']==m['runtime']['Frame.proposed']['bytes']==184
  assert m['runtime']['Environment.before']['bytes']==m['runtime']['Environment.proposed']['bytes']==112
proof={'files':rows,'exact_preserved_partitions':exact,'field_rename_only_partitions':renamed,'generic_factory_body_preserved_except_home_initialization':True,'class_quota_source_field_rename_only':True,'runtime_function_literal_sites':4,'execution':False}
(R/'source-checks.json').write_text(json.dumps(proof,indent=2)+'\n')
report={
 'status':'clear for bounded held runtime draft source review',
 'base':BASE,'reviewed_draft':bind(P/'draft-ready.json'),'source_checks':bind(R/'source-checks.json'),
 'selected_interfaces':bind(K/'root/selection-1.json'),'measured_layout_record':bind(K/'root/layout-measurements-1.json'),'property_hold':bind(K/'property-producer-1/source-ready.json'),
 'findings':[],
 'checks':[
  'Class constructors retain the instance prototype bag as home. Instance methods/accessors attach that same bag; static methods/accessors attach the constructor property bag. Attachment work8 precedes descriptor publication; inherited extraction/binding keeps the target closure home.',
  'Ordinary non-arrow activation pays1 and records active_function before parameter defaults. Arrows leave their own environment lexical and resolve persistent owner environments; class constructor entry keeps its previous ordering under a field rename.',
  'Capture pays8 then existing charged environment hops and obtains initialized this before key evaluation. Prepaid2 covers incoming raw key; completion pays8, rereads the live home parent after key effects, and retains base/receiver/raw name separately.',
  'Read/write work4 precedes raw key conversion. Existing reference_key rejects null before ToPropertyKey. Successful read stores normalized String/Symbol in the Reference so compound writes do not repeat object coercion. Simple assignment retains raw name through RHS; no receiver is reconstructed from base.',
  'Member call pays2 for actual Receiver ownership, then GetValue before arguments. New uses the value route. Delete evaluates the Super Reference then pays1 and raises ReferenceError without key conversion. For-heads use the unchanged shared reference path.',
  'All four runtime Function insertion routes initialize home. Generic closures, bound functions and bootstrap retain their old allowances plus the measured Option<usize> delta. Class constructor/method plans already include the complete typed Function slot and growth; the prepaid-home factory prevents charging this delta twice.',
  'New Reference/Phase/Output values remain flat. Existing frame allocation and unwind/weight logic is byte-exact; measured top Frame184 and Environment112 remain unchanged. No new limit, heap ceiling, Runtime arena or private syntax ownership is introduced.',
  'Direct super target, ordinary/spread argument scheduling, superclass validation, bind-this and class construction/return completion remain byte-exact except the selected activation field rename.',
  'The two Reflect visibility changes and wrapper bodies come from a separate producer-authored hold. Existing host Unsupported and terminal observer boundaries are preserved; this review does not expand those capabilities.'
 ],
 'fees':{'Function_delta':'sizeof(Option<usize>) = observed16 on the two recorded configurations','ordinary_nonarrow_activation':1,'method_home_attach':8,'capture':'8 + existing per-environment-hop tick','raw_key_receipt':2,'completion':8,'read_reference':4,'write_reference':4,'member_call_receiver':2,'delete':1},
 'qualifications':[
  'No project execution, tests, compilation or live edits by this reviewer. Compilation, public/private behavior and exhaustive historical quota migrations remain root execution obligations.',
  'This receipt binds the seven-path draft exactly. Any later payload change requires an additive binding/review.',
  'draft-ready retains its earlier second-toolchain-pending sentence; root/layout-measurements-1 now records both selected runtime configurations and subsequent parser probes. Proposed-shape observations do not substitute for final candidate layout checks.',
  'Ordinary function activation work1 and method home attachment work8 are selected behavior-independent accounting changes; historical numeric witnesses must be migrated explicitly rather than weakening assertions.',
  'This reviewer authored the separate property helper hold; its hash is an interface binding, not an independent review of that hold.'
 ],
 'primary_spec':{'consulted':'2026-10-17','source':'https://tc39.es/ecma262/2026/multipage/ecmascript-language-expressions.html#sec-super-keyword','paraphrase':'The current algorithm captures actual this before evaluating a computed name, then forms the reference using the live super base. Key conversion is deferred to value access; simple assignment evaluates its RHS first.'},
 'execution':False,'live_edits':False}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(bind(R/'review.json'),indent=2))
