"""Source-only additive replay correction. Does not execute replay/project code."""
from pathlib import Path
import ast
from collections import Counter
import difflib
import hashlib
import json
import re

P = Path(__file__).resolve().parent
K = P.parent
OLD = K / 'profile-replay-2'

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def put(name, value):
    (P / name).write_text(json.dumps(value, indent=2) + '\n')

old_contract = json.loads((OLD / 'contract.json').read_text())
contract = json.loads((OLD / 'contract.json').read_text())
immutable = {item['path']: item for item in contract['immutable_published_inputs']}
policies = {}
sources = {}
profiles = []
policy_counts = Counter()
previous_evidence = 0
for profile in contract['profiles']:
    if profile['binary_kind'] != 'host':
        continue
    binding = profile['reference_report']
    assert bind(Path(binding['path'])) == binding
    report = json.loads(Path(binding['path']).read_text())
    selected = {}
    counts = Counter()
    for case in report['cases']:
        relative = profile['corpus'] + '/' + case['file']
        path = K / 'worktree' / relative
        data = path.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        assert immutable[relative] == dict(path=relative, bytes=len(data), sha256=digest)
        assert digest == case['source_sha256']
        frontmatters = re.findall(r'/\*---(.*?)---\*/', data.decode('utf-8'), re.S)
        assert len(frontmatters) == 1
        frontmatter = frontmatters[0]
        flag_lines = re.findall(r'^flags:[ \t]*(.*)$', frontmatter, re.M)
        assert len(flag_lines) <= 1
        flags_text = flag_lines[0].strip() if flag_lines else '[]'
        # This is a closed source census, not a new general YAML parser. All
        # 637 authenticated selected bodies use this one-line flow-list form.
        assert re.fullmatch(r'\[[^\]\n]*\]', flags_text)
        flags = [word.strip().strip("'\"") for word in flags_text[1:-1].split(',') if word.strip()]
        assert all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', flag) for flag in flags)
        policy = int('async' in flags)
        assert case['id'] not in selected
        selected[case['id']] = policy
        counts[policy] += 1
        policy_counts[policy] += 1
        if 'observation' in case:
            assert case['observation']['completion']['policy'] == policy
            previous_evidence += 1
        record = dict(path=relative, bytes=len(data), sha256=digest,
                      frontmatter_sha256=hashlib.sha256(frontmatter.encode()).hexdigest(),
                      flags=flags, completion_policy=policy)
        if relative in sources:
            assert sources[relative] == record
        else:
            sources[relative] = record
    policies[profile['profile']] = selected
    profiles.append(dict(profile=profile['profile'], cases=len(selected),
                         policy_counts=dict(counts), reference_report=binding))
assert sum(map(len, policies.values())) == 1268
assert len(sources) == 637
contract['case_completion_policies'] = policies
contract['acceptance'].append('Every observed host case completion policy must equal the immutable source async-flag policy pinned by existing case ID, including previously metadata-excluded cases. No self-selected completion policy is accepted.')
contract['commands'] = [command.replace('/profile-replay-2/', '/profile-replay-3/') for command in contract['commands']]

edits = [
    dict(name='pass source-derived case policy into comparison',
         before='def compare(profile, before, report, binary, receipt, command):\n',
         after='def compare(profile, before, report, binary, receipt, command, case_policies):\n'),
    dict(name='check observed policy against immutable case metadata',
         before="        observation = new.get('observation')\n        if (new['status'] not in NORMAL_CASE_STATUSES\n",
         after="        observation = new.get('observation')\n        if host and type(observation) is dict:\n            completion = observation.get('completion')\n            check(type(completion) is dict\n                  and equal(completion.get('policy'), case_policies[new['id']]),\n                  'case completion policy differs from source metadata: ' + new['id'])\n        if (new['status'] not in NORMAL_CASE_STATUSES\n"),
    dict(name='require complete host policy table before dispatch',
         before="    contract = load_bound(contract_binding)\n    selection_binding = bound(args.selection.resolve())\n",
         after="    contract = load_bound(contract_binding)\n    policy_tables = contract['case_completion_policies']\n    require(type(policy_tables) is dict and set(policy_tables) ==\n            {profile['profile'] for profile in contract['profiles'] if profile['binary_kind'] == 'host'},\n            'host case-policy profile census')\n    selection_binding = bound(args.selection.resolve())\n"),
    dict(name='bind each policy table to exact predecessor case IDs before command',
         before="        before = load_bound(profile['reference_report'])\n        load_bound(profile['reference_receipt'])\n",
         after="        before = load_bound(profile['reference_report'])\n        case_policies = policy_tables.get(profile['profile'])\n        if profile['binary_kind'] == 'host':\n            require(type(case_policies) is dict\n                    and set(case_policies) == {case['id'] for case in before['cases']}\n                    and all(type(policy) is int and policy in (0, 1) for policy in case_policies.values()),\n                    'host case-policy identity/types')\n        else:\n            require(case_policies is None, 'ordinary profile has host case policies')\n        load_bound(profile['reference_receipt'])\n"),
    dict(name='supply selected policy table',
         before='            row = compare(profile, before, report, binary, receipt, command)\n',
         after='            row = compare(profile, before, report, binary, receipt, command, case_policies)\n'),
]
before = (OLD / 'replay.py').read_text()
after = before
for edit in edits:
    assert after.count(edit['before']) == 1, edit['name']
    after = after.replace(edit['before'], edit['after'])
ast.parse(after)
inverse = after
for edit in reversed(edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'])
assert inverse == before
(P / 'replay.py').write_text(after)
put('contract.json', contract)
for name, old, new in [('replay.py', before, after),
                       ('contract.json', (OLD / 'contract.json').read_text(), (P / 'contract.json').read_text())]:
    (P / (name + '.diff')).write_text(''.join(difflib.unified_diff(
        old.splitlines(True), new.splitlines(True),
        fromfile='profile-replay-2/' + name, tofile='profile-replay-3/' + name)))
put('metadata-policy-census.json', dict(base=contract['base'], source='Authenticated published corpus bytes pinned in unchanged immutable_published_inputs; no project metadata parser imported.',
    profiles=profiles, host_mode_cases=1268, unique_sources=637,
    policy_counts=dict(policy_counts), previously_observed_host_rows=previous_evidence,
    previously_unobserved_host_rows=1268-previous_evidence, sources=list(sources.values()),
    parser_qualification='Closed census: every selected flags value is a single-line YAML flow list, or absent; no general YAML support claimed.'))
def functions(source):
    lines=source.splitlines(True)
    return {node.name: ''.join(lines[node.lineno-1:node.end_lineno])
            for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}
old_functions, new_functions = functions(before), functions(after)
changed = [name for name in old_functions if old_functions[name] != new_functions[name]]
assert changed == ['compare', 'main']
changed_fields = [key for key in contract if old_contract.get(key) != contract[key]]
assert set(changed_fields) == {'case_completion_policies', 'acceptance', 'commands'}
put('delta.json', dict(original_hold=bind(OLD/'source-ready.json'),
    finding=bind(K/'profile-review-1/recipe2-review.json'),
    original_runner=bind(OLD/'replay.py'), runner=bind(P/'replay.py'),
    original_contract=bind(OLD/'contract.json'), contract=bind(P/'contract.json'),
    edits=edits, changed_functions=changed,
    unchanged_functions=[name for name in old_functions if name not in changed],
    contract_changed_fields=changed_fields, whole_source_inverse=True,
    all_profile_metadata_case_identity_controls_and_input_pins_unchanged=True))
put('source-checks.json',dict(status='Source-only author checks; independent peer pending.',
    host_case_policies=1268, unique_authenticated_sources=637,
    policy_counts=dict(policy_counts), predecessor_observed_policies_match=previous_evidence,
    previously_unobserved_cases_also_bound=1268-previous_evidence,
    exact_whole_runner_inverse=True, changed_functions=changed,
    refusal_matrix=[
        'Async case identity with policy0 and zero completion counts refuses despite otherwise clean complete evidence.',
        'Sync case identity with policy1 and authenticated done/success counts refuses despite otherwise clean complete evidence.',
        'Missing/extra case or host profile policy-table entries and bool/non-0/1 values refuse before dispatch.',
        'Previously metadata-excluded host cases still have a source-derived policy if any observation is reported.',
        'Raw Resource/harness-error classification and infrastructure refusals from recipe2 remain exact.',
        'Ordinary profiles cannot acquire a host policy table; ordinary decoder behavior remains unchanged.'
    ], no_candidate_results_read=True, project_imports=False, project_execution=False,
    replay_execution=False, live_edits=False))
files=[dict(bind(path),path=path.name) for path in sorted(P.iterdir()) if path.is_file() and path.name!='source-ready.json']
put('source-ready.json',dict(format=1,status='Sealed source-only recipe3 correction; independent peer pending.',
    base=contract['base'],supersedes=bind(OLD/'source-ready.json'),
    findings=bind(K/'profile-review-1/recipe2-review.json'),contract=bind(P/'contract.json'),
    runner=bind(P/'replay.py'),metadata_census=bind(P/'metadata-policy-census.json'),
    delta=bind(P/'delta.json'),checks=bind(P/'source-checks.json'),files=files,
    profiles=8,cases=1330,controls=724,host_case_policy_bindings=1268,
    baseline_writes=False,project_execution=False,live_edits=False))
print(json.dumps(bind(P/'source-ready.json')))
