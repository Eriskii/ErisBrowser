
// Additive completion-kind controls. All fixtures and snapshots are prepared
// outside the measured helper call; the original seven groups stay unchanged.
fn completion_storage(runtime: &Runtime) -> Vec<String> {
    let mut snapshot = vec![format!(
        "arrays={:?}; properties={:?}; holes={:?}; lengths={:?}; capacities={:?}",
        runtime.arrays,
        runtime.array_properties,
        runtime.array_holes,
        runtime.array_lengths.iter().map(|length| (length.value, length.writable)).collect::<Vec<_>>(),
        (runtime.arrays.capacity(), runtime.array_properties.capacity(),
         runtime.array_holes.capacity(), runtime.array_lengths.capacity(),
         runtime.arrays.iter().map(Vec::capacity).collect::<Vec<_>>()),
    )];
    snapshot.push(format!("native={:?}; prototypes={:?}", runtime.native_properties, runtime.prototypes));
    for object in &runtime.objects {
        snapshot.push(format!(
            "object={:?}|{:?}|{}|{:?}|{:?}|{}|{:?}|{:?}|{}|{:?}|{:?}|{:?}|{}|{:?}|{:?}",
            object.values, object.order, object.order.capacity(), object.prototype,
            object.boxed, object.non_extensible, object.intrinsic_error,
            object.parameter_map, object.arguments,
            object.regexp.as_ref().map(std::rc::Rc::as_ptr), object.date_value,
            object.event, object.event_target,
            object.abort.map(|slot| match slot {
                AbortSlot::Controller(id) => (false, id),
                AbortSlot::Signal(id) => (true, id),
            }), object.namespace,
        ));
    }
    for function in &runtime.functions {
        snapshot.push(format!(
            "function={:?}|{:?}|{}|{}|{:?}|{:?}",
            std::rc::Rc::as_ptr(&function.code.unit), function.code.id(),
            function.environment, function.properties, function.home_object,
            function.bound.as_ref().map(|bound| (&bound.target, &bound.receiver, &bound.arguments)),
        ));
    }
    for environment in &runtime.environments {
        let this = match &environment.this_binding {
            ThisBinding::Lexical => "lexical".to_owned(),
            ThisBinding::Uninitialized => "uninitialized".to_owned(),
            ThisBinding::Initialized(value) => format!("initialized:{value:?}"),
        };
        snapshot.push(format!(
            "environment={this}|{:?}|{:?}|{:?}|{}|{}",
            environment.active_function, environment.new_target_binding,
            environment.parent, environment.function_scope, environment.strict,
        ));
        for (name, binding) in &environment.bindings {
            snapshot.push(format!(
                "binding={name:?}|{:?}|{:?}|{}|{}|{}|{}|{}|{}|{}",
                binding.value,
                binding.accessor.as_ref().map(|accessor| (&accessor.get, &accessor.set)),
                binding.mutable, binding.initialized, binding.strict_immutable,
                binding.global_property, binding.global_order, binding.enumerable,
                binding.deletable,
            ));
        }
    }
    snapshot
}

fn completion_base_fixture() -> (Runtime, usize, usize, Value, usize, usize, usize) {
    let (mut runtime, home, _, owner, receiver) = fixture();
    let Value::Function(parent_function) = runtime.function_value(&method_code(), 1).unwrap() else {
        panic!("parent function");
    };
    let Value::Array(parent_array) = runtime.array(vec![Value::Number(17.0)]).unwrap() else {
        panic!("parent array");
    };
    let Value::Object(native_bag) = runtime.object_ordered([("sentinel".into(), Value::Number(23.0))]).unwrap() else {
        panic!("native bag");
    };
    // An explicit Native bag cannot use zero, which is the legacy sentinel.
    assert_ne!(native_bag, 0);
    runtime.native_properties.insert("capture.legacy".into(), native_bag);
    (runtime, home, owner, receiver, parent_function, parent_array, native_bag)
}

fn completion_native(properties: Option<std::num::NonZeroUsize>) -> Value {
    Value::Native(std::rc::Rc::new(Native {
        name: "capture.legacy".into(), receiver: Value::Window, properties,
    }))
}

#[test]
fn super_property_private_completion_rejects_malformed_base_ids_and_bags() {
    // Function ID/bag, Array ID/missing-or-invalid bag, and explicit Native bag.
    // Both first-out-of-range and maximal IDs must refuse without indexing.
    for fault in 0..11 {
        for work in [7, 8] {
            let (mut runtime, home, owner, receiver, function, array, _) = completion_base_fixture();
            let base = match fault {
                0 => Value::Function(runtime.functions.len()),
                1 => Value::Function(usize::MAX),
                2 => { runtime.functions[function].properties = runtime.objects.len(); Value::Function(function) }
                3 => { runtime.functions[function].properties = usize::MAX; Value::Function(function) }
                4 => Value::Array(runtime.arrays.len()),
                5 => Value::Array(usize::MAX),
                6 => { runtime.array_properties.truncate(array); Value::Array(array) }
                7 => { runtime.array_properties[array] = runtime.objects.len(); Value::Array(array) }
                8 => { runtime.array_properties[array] = usize::MAX; Value::Array(array) }
                9 => completion_native(std::num::NonZeroUsize::new(runtime.objects.len())),
                10 => completion_native(std::num::NonZeroUsize::new(usize::MAX)),
                _ => unreachable!(),
            };
            runtime.objects[home].prototype = Some(base.clone());
            let key = Value::String(vec![0x96ea, 0xd800].into());
            let before = shape(&runtime);
            let storage = completion_storage(&runtime);
            cut(&mut runtime, work);
            let refusal = error(runtime.class_super_property_reference(owner, receiver, key, true));
            assert!(refusal.is_resource_limit(), "fault={fault} work={work}: {refusal:?}");
            assert_eq!(refusal.message, if work == 7 {
                "script instruction limit exceeded"
            } else {
                "invalid super property runtime state"
            });
            assert_eq!(runtime.steps, 0);
            assert_eq!(completion_storage(&runtime), storage, "fault={fault} work={work}");
            assert_eq!(runtime.objects[home].prototype.as_ref(), Some(&base));
            if let Value::Native(expected) = &base {
                let Some(Value::Native(actual)) = &runtime.objects[home].prototype else { panic!("native base"); };
                assert!(std::rc::Rc::ptr_eq(expected, actual));
            }
            clean(&runtime, before);
        }
    }
}

#[test]
fn super_property_private_completion_accepts_valid_function_array_and_native_bases() {
    for kind in 0..4 {
        for work in [7, 8] {
            let (mut runtime, home, owner, receiver, function, array, native_bag) = completion_base_fixture();
            let base = match kind {
                0 => Value::Function(function),
                1 => Value::Array(array),
                2 => completion_native(std::num::NonZeroUsize::new(native_bag)),
                3 => completion_native(None),
                _ => unreachable!(),
            };
            runtime.objects[home].prototype = Some(base.clone());
            let key = Value::String(vec![0x96ea, 0xd800].into());
            let raw_key = key.clone();
            let actual_receiver = receiver.clone();
            let strict = kind % 2 == 0;
            let before = shape(&runtime);
            let storage = completion_storage(&runtime);
            cut(&mut runtime, work);
            let result = runtime.class_super_property_reference(owner, receiver, key, strict);
            if work == 7 {
                let refusal = error(result);
                assert!(refusal.is_resource_limit());
                assert_eq!(refusal.message, "script instruction limit exceeded");
            } else {
                let Reference::SuperProperty { base: captured, name, receiver, strict: captured_strict } = result.unwrap() else {
                    panic!("super reference");
                };
                assert_eq!(captured, base);
                assert_eq!(name, raw_key);
                assert_eq!(receiver, actual_receiver);
                assert_eq!(captured_strict, strict);
                let (Value::String(before), Value::String(after)) = (&raw_key, &name) else { panic!("raw key"); };
                assert_eq!(before.units().as_ptr(), after.units().as_ptr());
                if let (Value::Native(expected), Value::Native(actual)) = (&base, &captured) {
                    assert!(std::rc::Rc::ptr_eq(expected, actual));
                    assert_eq!(actual.properties, if kind == 2 { std::num::NonZeroUsize::new(native_bag) } else { None });
                }
            }
            assert_eq!(runtime.steps, 0);
            assert_eq!(completion_storage(&runtime), storage, "kind={kind} work={work}");
            clean(&runtime, before);
        }
    }
}
