#!/usr/bin/env python3
"""Verify each archived member against frozen K origins without extracting."""
import argparse
import gzip
import hashlib
import json
import tarfile
from evidence_common import K, OUTPUT, CHECKPOINT, SCOPE, MAX_BYTES, binding, check_output_ancestors, digest, options, policy, preconditions, read_json, require, require_selected_members, scan


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    options(parser)
    args = parser.parse_args()
    check_output_ancestors(allow_missing=False)
    manifest_path = OUTPUT / 'manifest.json'
    manifest = read_json(manifest_path)
    require(set(manifest) == {'format', 'checkpoint', 'origin_root', 'archive', 'member_count', 'member_bytes', 'members',
                             'excluded_at_packaging', 'selection_policy', 'receipts', 'deterministic', 'scope'}, 'manifest schema')
    require(manifest['format'] == 1 and manifest['checkpoint'] == CHECKPOINT and manifest['origin_root'] == str(K), 'manifest identity')
    require(manifest['selection_policy'] == policy(), 'selection policy differs')
    require(manifest['scope'] == SCOPE, 'manifest scope differs')
    require(manifest['receipts'] == preconditions(args), 'selected source/documentation/review receipts differ')
    expected, _ = scan()
    require_selected_members(manifest['receipts'], expected)
    require(manifest['members'] == expected and len(expected) == manifest['member_count'], 'missing/extra/changed frozen origins')
    require(sum(row['bytes'] for row in expected) == manifest['member_bytes'] <= MAX_BYTES, 'member byte total')
    require(manifest['archive']['path'] == 'sources-and-checks.tar.gz', 'archive path')
    archive = OUTPUT / manifest['archive']['path']
    binding(archive)  # Reject a symlink or non-regular archive before opening.
    data = archive.read_bytes()
    require(len(data) == manifest['archive']['bytes'] and digest(data) == manifest['archive']['sha256'], 'archive bytes/hash')
    require(data[:4] == b'\x1f\x8b\x08\x00' and data[4:8] == b'\x00'*4, 'gzip header/time/name metadata')
    observed = []
    with tarfile.open(archive, mode='r|gz') as tar:
        for index, member in enumerate(tar):
            require(index < len(expected), 'extra archive member')
            row = expected[index]
            require(member.isfile() and member.type == tarfile.REGTYPE and member.name == row['path'], 'member type/order/name')
            require(member.size == row['bytes'] and member.mode == 0o644 and member.uid == member.gid == member.mtime == 0,
                    'member deterministic size/metadata')
            require(member.uname == member.gname == member.linkname == '' and not member.pax_headers, 'member owner/link/extended header')
            stream = tar.extractfile(member)
            require(stream is not None, 'member missing body')
            body = stream.read(member.size + 1)
            require(len(body) == row['bytes'] and digest(body) == row['sha256'], 'member bytes/hash')
            require(body == (K / row['origin']).read_bytes(), 'member differs from exact current frozen origin')
            observed.append(member.name)
    require(len(observed) == len(expected) and len(set(observed)) == len(observed), 'missing or duplicate archive member')
    # Read through the gzip trailer so CRC/truncation errors cannot hide after tar EOF.
    with gzip.open(archive, 'rb') as stream:
        total = 0
        while True:
            chunk = stream.read(1024*1024)
            if not chunk: break
            total += len(chunk)
            require(total <= MAX_BYTES + (len(expected) + 1) * 1024 + 10240, 'unexpected tar padding/expansion')
    # Canonical re-encoding also rejects hidden tar tails, alternate gzip metadata,
    # concatenated streams and trailing bytes without extracting or writing files.
    class HashSink:
        def __init__(self):
            self.sha = hashlib.sha256()
            self.size = 0
        def write(self, data):
            self.sha.update(data)
            self.size += len(data)
            return len(data)
        def flush(self):
            pass
    sink = HashSink()
    with gzip.GzipFile(filename='', mode='wb', compresslevel=9, mtime=0, fileobj=sink) as zipped:
        with tarfile.open(mode='w|', format=tarfile.USTAR_FORMAT, fileobj=zipped) as tar:
            for row in expected:
                info = tarfile.TarInfo(row['path'])
                info.size = row['bytes']; info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with (K / row['origin']).open('rb') as source:
                    tar.addfile(info, source)
    require(sink.size == len(data) and sink.sha.hexdigest() == digest(data), 'archive differs from deterministic exact re-encoding')
    require(manifest['deterministic'] == dict(tar='USTAR', uid=0, gid=0, mode='0644', mtime=0, gzip_mtime=0, gzip_level=9), 'manifest deterministic metadata')
    require(scan()[0] == expected, 'eligible origins changed during verification')
    require(manifest['receipts'] == preconditions(args), 'selected receipts/source/docs changed during verification')
    print(json.dumps(dict(status='clear', manifest=binding(manifest_path), archive=binding(archive),
                          member_count=len(expected), member_bytes=manifest['member_bytes'], exact_frozen_origins=True,
                          qualification=SCOPE)))


if __name__ == '__main__':
    main()
