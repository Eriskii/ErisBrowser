"""Frozen K evidence selection. Only root executes these held tools."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess

K = Path(__file__).resolve().parent.parent
W = K / 'worktree'
CHECKPOINT = 'class-super-properties'
BASE = 'db02f8c890a459b979378900f113b67460a49121'
OUTPUT = W / 'docs/evidence' / CHECKPOINT
EXCLUDED_TOP = {'worktree', 'publication'}
EXCLUDED_DIRS = {'__pycache__', '.git', 'target'}
EXCLUDED_PATHS = {'root/publication-verification.json', 'root/github-publication.json',
                  'root/git-publication.json'}
INPUTS = {'source_parent', 'source_inventory', 'source_snapshots', 'final_validation', 'validation_review',
          'documentation_hold', 'documentation_review'}
MAX_MEMBERS = 20000
MAX_BYTES = 128 * 1024 * 1024
SCOPE = ('Selected source snapshots, implementation/test holds, reviews, probe sources/results, '
         'validation attempts, profile comparisons and documentation. Failed and superseded '
         'artifacts are retained as history, not accepted results. Runtime binaries are '
         'represented by bound sidecars/build receipts. This is not a complete self-contained '
         'build graph or a whole-browser compatibility, security, performance or hardware claim.')


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def normalized(value):
    require(type(value) is str and value, 'nonempty relative path required')
    rel = PurePosixPath(value)
    require(rel.parts and not rel.is_absolute() and str(rel) == value and '..' not in rel.parts
            and '.' not in rel.parts and '\\' not in value,
            'noncanonical relative path: ' + value)
    return rel


def directory(path):
    for ancestor in (path, *path.parents):
        require(stat.S_ISDIR(ancestor.lstat().st_mode),
                'symlink/non-directory ancestor: ' + str(ancestor))


def regular(path):
    require(stat.S_ISREG(path.lstat().st_mode), 'not a regular file: ' + str(path))
    directory(path.parent)


def binding(path):
    regular(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def read_json(path):
    regular(path)
    return json.loads(path.read_bytes())


def relative_file(value):
    path = K.joinpath(*normalized(value).parts)
    regular(path)
    return path


def sealed(row):
    require(type(row) is dict and set(row) == {'path', 'bytes', 'sha256'}, 'binding schema')
    require(type(row['bytes']) is int and row['bytes'] >= 0, 'binding byte count')
    require(type(row['sha256']) is str and re.fullmatch('[0-9a-f]{64}', row['sha256']), 'binding hash')
    actual = binding(relative_file(row['path']))
    require((actual['bytes'], actual['sha256']) == (row['bytes'], row['sha256']),
            'selected binding differs: ' + row['path'])
    return actual


def contains_hash(value, expected):
    if isinstance(value, dict):
        return any(contains_hash(v, expected) for v in value.values())
    if isinstance(value, list):
        return any(contains_hash(v, expected) for v in value)
    return value == expected


def source_rows(inventory):
    # Current K inventories use files; older selected inventories used a map.
    if 'files' in inventory:
        require('source_sha256' not in inventory and type(inventory['files']) is list,
                'ambiguous source inventory')
        rows = inventory['files']
    else:
        hashes = inventory.get('source_sha256')
        require(type(hashes) is dict, 'missing source inventory')
        rows = [dict(path=path, sha256=sha) for path, sha in hashes.items()]
    result = {}
    for row in rows:
        require(type(row) is dict and 'path' in row and 'sha256' in row, 'source row schema')
        rel = str(normalized(row['path']))
        require(rel not in result and type(row['sha256']) is str
                and re.fullmatch('[0-9a-f]{64}', row['sha256']), 'duplicate/bad source row')
        if 'bytes' in row:
            require(type(row['bytes']) is int and row['bytes'] >= 0, 'source byte count')
        result[rel] = row
    require(result, 'empty source inventory')
    return result


def files_below(root):
    directory(root)
    files = {}
    for current, dirs, names in os.walk(root, followlinks=False):
        for name in dirs:
            directory(Path(current) / name)
        for name in names:
            path = Path(current) / name
            regular(path)
            files[path.relative_to(root).as_posix()] = path
    return files


def options(parser):
    parser.add_argument('--selection', required=True,
                        help='Frozen K-relative selection JSON, normally root/evidence-selection-1.json')


def preconditions(args):
    selection_path = relative_file(args.selection)
    selection = read_json(selection_path)
    require(set(selection) == {'format', 'checkpoint', 'inputs', 'documents',
                              'source_snapshot_root', 'required_artifacts'}, 'selection schema')
    require(type(selection['format']) is int and selection['format'] == 1
            and selection['checkpoint'] == CHECKPOINT, 'selection identity')
    require(type(selection['inputs']) is dict and set(selection['inputs']) == INPUTS, 'selected input names')
    selected = {name: sealed(row) for name, row in selection['inputs'].items()}
    loaded = {name: read_json(Path(row['path'])) for name, row in selected.items()}
    require(loaded['final_validation'].get('status') == 'pass', 'final validation must pass')
    for name in ('validation_review', 'documentation_review'):
        require(loaded[name].get('status') == 'clear', name + ' must be clear')
    joins = [('final_validation', 'source_inventory'), ('validation_review', 'final_validation'),
             ('documentation_review', 'documentation_hold'), ('documentation_hold', 'final_validation'),
             ('documentation_review', 'final_validation')]
    for owner, target in joins:
        require(contains_hash(loaded[owner], selected[target]['sha256']), owner + ' does not bind ' + target)
    current = source_rows(loaded['source_inventory'])
    parent = source_rows(loaded['source_parent'])
    require(loaded['source_inventory'].get('base') == loaded['source_parent'].get('base') == BASE,
            'source inventory base differs')
    require(set(parent) <= set(current), 'selected parent inputs removed; unsupported by this checkpoint recipe')
    # The parent inventory is intentionally narrower. New inventory coverage is
    # not a source change: compare absent parent rows with the pinned Git tree.
    object_format = subprocess.check_output(['git', 'rev-parse', '--show-object-format'], cwd=W).strip()
    require(object_format == b'sha1', 'this pinned Git base uses SHA-1 object identities')
    tree = subprocess.check_output(['git', 'ls-tree', '-r', '-z', '--full-tree', BASE], cwd=W)
    base_blobs = {}
    for record in tree.split(b'\0'):
        if not record:
            continue
        header, path = record.split(b'\t', 1)
        mode, kind, oid = header.split(b' ')
        name = path.decode('utf-8')
        require(name not in base_blobs, 'duplicate pinned tree path')
        base_blobs[name] = (mode.decode(), kind.decode(), oid.decode())
    changed = set()
    fallback = []
    for rel, row in current.items():
        path = W.joinpath(*normalized(rel).parts)
        actual = binding(path)
        require(actual['sha256'] == row['sha256'] and
                ('bytes' not in row or actual['bytes'] == row['bytes']), 'worktree source differs: ' + rel)
        if rel in parent:
            if row['sha256'] != parent[rel]['sha256']:
                changed.add(rel)
        else:
            data = path.read_bytes()
            oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            previous = base_blobs.get(rel)
            same = previous is not None and previous[0] in {'100644', '100755'} and previous[1:] == ('blob', oid)
            if not same:
                changed.add(rel)
            fallback.append(dict(path=rel, base_blob=previous, current_blob=oid, unchanged=same))
    fallback.sort(key=lambda row: row['path'])
    base_comparison = dict(base=BASE, method='read-only Git tree and canonical SHA-1 blob comparison for newly inventoried paths',
                           tree_sha256=digest(tree), compared_paths=len(fallback),
                           unchanged_paths=sum(row['unchanged'] for row in fallback),
                           rows_sha256=digest(json.dumps(fallback, sort_keys=True, separators=(',', ':')).encode()),
                           changed_paths=sorted(changed))
    snapshot_root = K.joinpath(*normalized(selection['source_snapshot_root']).parts)
    snapshots = files_below(snapshot_root)
    require(set(snapshots) == changed and changed, 'snapshot roster must equal the complete selected source delta')
    snapshot_receipt = loaded['source_snapshots']
    require(set(snapshot_receipt) == {'root', 'files'} and snapshot_receipt['root'] == str(snapshot_root),
            'snapshot receipt root/schema')
    snapshot_rows = source_rows(snapshot_receipt)
    require(set(snapshot_rows) == changed, 'snapshot receipt roster differs')
    snapshot_bindings = {}
    for rel, path in sorted(snapshots.items()):
        row = binding(path)
        require(row['sha256'] == current[rel]['sha256'] and path.read_bytes() == (W / rel).read_bytes(),
                'candidate snapshot differs: ' + rel)
        require(snapshot_rows[rel]['sha256'] == row['sha256']
                and snapshot_rows[rel].get('bytes') == row['bytes'], 'snapshot receipt bytes/hash differ')
        snapshot_bindings[rel] = row
    docs = selection['documents']
    require(type(docs) is list and docs and docs == sorted(set(docs)), 'document roster must be sorted/unique')
    for rel in docs:
        normalized(rel)
        require(rel == 'README.md' or rel.startswith('docs/'), 'unexpected documentation path')
        require(not rel.startswith('docs/evidence/'), 'documentation cannot include archive outputs')
    raw = Path(selected['documentation_hold']['path']).parent / 'raw'
    documents = files_below(raw)
    require(set(documents) == set(docs), 'documentation raw roster differs')
    doc_bindings = {}
    for rel, path in sorted(documents.items()):
        row = binding(path)
        require(contains_hash(loaded['documentation_hold'], row['sha256']), 'raw documentation not sealed: ' + rel)
        regular(W / rel)
        require((W / rel).read_bytes() == path.read_bytes(), 'imported documentation differs: ' + rel)
        doc_bindings[rel] = row
    required = selection['required_artifacts']
    require(type(required) is list and required, 'explicit required artifact bindings missing')
    required_bindings = [sealed(row) for row in required]
    require(len({row['path'] for row in required_bindings}) == len(required_bindings), 'duplicate required artifact')
    return dict(selection=binding(selection_path), inputs=selected, required_artifacts=required_bindings,
                documents=doc_bindings, source_snapshots=snapshot_bindings,
                selected_source_count=len(current), changed_source_count=len(changed),
                base_comparison=base_comparison, scope=SCOPE)


def check_output_ancestors(allow_missing):
    for path in reversed((OUTPUT, *OUTPUT.parents)):
        try:
            mode = path.lstat().st_mode
        except FileNotFoundError:
            require(allow_missing, 'missing output directory: ' + str(path))
            continue
        require(stat.S_ISDIR(mode), 'output ancestor is a symlink or non-directory: ' + str(path))


def require_selected_members(receipts, members):
    included = {row['origin'] for row in members}
    required = [receipts['selection'], *receipts['inputs'].values(), *receipts['required_artifacts'],
                *receipts['documents'].values(), *receipts['source_snapshots'].values()]
    for row in required:
        require(Path(row['path']).relative_to(K).as_posix() in included,
                'selected artifact excluded: ' + row['path'])


def scan():
    members, skipped = [], []
    total = 0
    def walk(directory_path):
        nonlocal total
        for entry in sorted(os.scandir(directory_path), key=lambda item: item.name):
            path = Path(entry.path)
            rel = path.relative_to(K).as_posix()
            top = rel.split('/')[0]
            if entry.is_symlink():
                skipped.append(dict(path=rel, reason='symlink; never followed'))
                continue
            if (top in EXCLUDED_TOP or top.startswith('target') or rel in EXCLUDED_PATHS
                    or (entry.is_dir(follow_symlinks=False) and entry.name in EXCLUDED_DIRS)):
                skipped.append(dict(path=rel, reason='explicit worktree/build/publication exclusion'))
                continue
            if entry.is_dir(follow_symlinks=False):
                walk(path)
                continue
            require(entry.is_file(follow_symlinks=False), 'unsupported filesystem object: ' + rel)
            if ((top == 'binaries' or (len(Path(rel).parts) == 1 and top.startswith('eris-js-')))
                    and path.suffix != '.json'):
                skipped.append(dict(path=rel, reason='runtime binary excluded; JSON provenance retained'))
                continue
            require(rel not in {'manifest.json', 'sources-and-checks.tar.gz'}, 'unexpected root archive output: ' + rel)
            require(entry.name not in {'.env', 'id_rsa', 'id_ed25519', 'credentials', 'credentials.json'}
                    and path.suffix not in {'.pem', '.p12', '.key'}, 'credential-shaped artifact requires separate review: ' + rel)
            regular(path)
            data = path.read_bytes()
            require(not data.startswith((b'\x7fELF', b'MZ')), 'unexpected executable outside excluded binary paths: ' + rel)
            total += len(data)
            members.append(dict(path=rel, origin=rel, bytes=len(data), sha256=digest(data)))
            require(len(members) <= MAX_MEMBERS and total <= MAX_BYTES, 'evidence selection exceeds bound')
    directory(K)
    walk(K)
    members.sort(key=lambda row: row['path'])
    skipped.sort(key=lambda row: row['path'])
    return members, skipped


def policy():
    return dict(excluded_top=sorted(EXCLUDED_TOP), excluded_top_prefixes=['target'],
                excluded_directories=sorted(EXCLUDED_DIRS), excluded_paths=sorted(EXCLUDED_PATHS),
                symlinks='never followed', binaries='non-JSON binaries/ and root eris-js-* files excluded',
                max_members=MAX_MEMBERS, max_uncompressed_member_bytes=MAX_BYTES)
