from pathlib import Path
import json, hashlib, subprocess, difflib, re
K=Path('/tmp/eris-super-properties-plan-1'); O=K/'parser-producer-1'; W=K/'worktree'; BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p); b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(p,s):
 p.parent.mkdir(parents=True,exist_ok=True); p.write_text(s)
def put(p,x): write(p,json.dumps(x,indent=2)+'\n')
def replace(s,a,b):
 assert s.count(a)==1,(a[:100],s.count(a));return s.replace(a,b,1)
paths=['src/script/code.rs','src/script/parser.rs','src/script/parser/driver.rs','src/script/parser/driver/functions.rs','src/script/parser/driver/expressions.rs','src/script/parser/driver/statements.rs']
before={p:subprocess.check_output(['git','show',BASE+':'+p],cwd=W).decode() for p in paths}
for p,s in before.items():
 write(O/'before'/p,s)
after=dict(before)
p='src/script/code.rs'; s=after[p]
s=replace(s,'    SuperCallSpread(Vec<ExprId>),\n','    SuperCallSpread(Vec<ExprId>),\n    // Class home-object reference; the child remains an unevaluated raw key.\n    SuperProperty(ExprId),\n')
s=replace(s,'            Expr::Class(_) | Expr::SuperCall(_) | Expr::SuperCallSpread(_) => {','            Expr::Class(_)\n            | Expr::SuperCall(_)\n            | Expr::SuperCallSpread(_)\n            | Expr::SuperProperty(_) => {')
after[p]=s
p='src/script/parser.rs';s=after[p]
s=replace(s,'    super_call_allowed: bool,\n','    super_call_allowed: bool,\n    super_property_allowed: bool,\n    super_property_deferred: bool,\n')
s=replace(s,'            super_call_allowed: false,\n','            super_call_allowed: false,\n            super_property_allowed: false,\n            super_property_deferred: false,\n')
s=replace(s,'&& !matches!(target, Expr::Member(..))','&& !matches!(target, Expr::Member(..) | Expr::SuperProperty(_))')
after[p]=s
p='src/script/parser/driver.rs';s=after[p]
s=replace(s,'    super_call_allowed: bool,\n','    super_call_allowed: bool,\n    super_property_allowed: bool,\n    super_property_deferred: bool,\n')
s=replace(s,'        super_call_allowed: parser.super_call_allowed,\n','        super_call_allowed: parser.super_call_allowed,\n        super_property_allowed: parser.super_property_allowed,\n        super_property_deferred: parser.super_property_deferred,\n')
s=replace(s,'        parser.super_call_allowed = entry.super_call_allowed;\n','        parser.super_call_allowed = entry.super_call_allowed;\n        parser.super_property_allowed = entry.super_property_allowed;\n        parser.super_property_deferred = entry.super_property_deferred;\n')
after[p]=s
p='src/script/parser/driver/functions.rs';s=after[p]
s=replace(s,'    ClassMethod(bool),\n','    ClassMethod(bool),\n    // Object methods have a valid super grammar but no selected runtime home object.\n    ObjectMethod,\n')
s=replace(s,'    super_call_allowed: bool,\n','    super_call_allowed: bool,\n    super_property_allowed: bool,\n    super_property_deferred: bool,\n')
s=replace(s,'            super_call_allowed: p.super_call_allowed,\n','            super_call_allowed: p.super_call_allowed,\n            super_property_allowed: p.super_property_allowed,\n            super_property_deferred: p.super_property_deferred,\n')
s=replace(s,'            p.super_call_allowed = false;\n','            p.super_call_allowed = false;\n            p.super_property_allowed = false;\n            p.super_property_deferred = false;\n')
s=replace(s,'        p.super_call_allowed = self.super_call_allowed;\n','        p.super_call_allowed = self.super_call_allowed;\n        p.super_property_allowed = self.super_property_allowed;\n        p.super_property_deferred = self.super_property_deferred;\n')
s=replace(s,'            p.super_call_allowed = derived_constructor;\n','            p.super_call_allowed = derived_constructor;\n            p.super_property_allowed = true;\n')
s=replace(s,'        Frame::Dynamic => {','''        Frame::ObjectMethod => {
            p.expect("(")?;
            let saved = Context::enter(p, false);
            p.super_property_deferred = true;
            let state = State {
                params: Vec::new(),
                saved,
                unique: true,
                arrow: false,
                dynamic: false,
            };
            if p.eat(")") {
                function_body(p, state)
            } else {
                parameters(p, state)
            }
        }
        Frame::Dynamic => {''')
after[p]=s
p='src/script/parser/driver/expressions.rs';s=after[p]
s=replace(s,'    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),\n','    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),\n    SuperPropertyKey(bool),\n')
# Property references enter the MemberExpression/New path, unlike direct super calls.
a='            if p.is("super") {\n                return super_start(p, '
assert s.count(a)==2
s=s.replace(a,'            if p.is("super") && !p.token_is(p.pos + 1, ".") && !p.token_is(p.pos + 1, "[") {\n                return super_start(p, ')
s=replace(s,'        Frame::ClassDone => done_expr(p, Expr::Class(class(output))),','''        Frame::ClassDone => done_expr(p, Expr::Class(class(output))),
        Frame::SuperPropertyKey(saved_in) => {
            let key = expression(output);
            p.expect("]")?;
            p.allow_in = saved_in;
            done_expr(p, Expr::SuperProperty(key))
        }''')
assert s.count('functions::Frame::Start(true)')==2
s=s.replace('functions::Frame::Start(true)','functions::Frame::ObjectMethod')
s=replace(s,'''    if p.is(".") || p.is("[") {
        return Err(ScriptError::unsupported(
            "super property references are not implemented",
        ));
    }
''','')
s=replace(s,'''            if p.is(".") || p.is("[") {
                Err(ScriptError::unsupported(
                    "super property references are not implemented",
                ))
            } else {''','''            if p.is(".") || p.is("[") {
                super_property(p)
            } else {''')
s=replace(s,'fn super_start(p:', '''// Called after consuming the super keyword in the MemberExpression grammar.
// Keep the key as an expression edge: runtime owns this/key/coercion ordering.
fn super_property(p: &mut Parser<'_>) -> Result<Transition> {
    if !p.super_property_allowed {
        return Err(if p.super_property_deferred {
            ScriptError::unsupported("object method super properties are not implemented")
        } else {
            p.error("super property outside a class method")
        });
    }
    if p.eat(".") {
        let name = p.identifier()?;
        let key = p.identifier_key(&name)?;
        let key = p.emit_expr(Expr::Literal(Value::String(key)))?;
        done_expr(p, Expr::SuperProperty(key))
    } else {
        p.expect("[")?;
        let saved_in = p.allow_in;
        p.allow_in = true;
        child(Frame::SuperPropertyKey(saved_in), Frame::Sequence)
    }
}
fn super_start(p:''')
after[p]=s
p='src/script/parser/driver/statements.rs';s=after[p]
s=replace(s,'if matches!(p.unit.expr(target), Expr::Ident(_) | Expr::Member(..)) =>','if matches!(\n                    p.unit.expr(target),\n                    Expr::Ident(_) | Expr::Member(..) | Expr::SuperProperty(_)\n                ) =>')
after[p]=s
test_path='src/script/parser/super_property_tests.rs'
tests=(O/'focused-tests.rs').read_text()
after['src/script/parser.rs'] += '\n#[cfg(test)]\nmod super_property_tests;\n'
write(O/'raw'/test_path,tests)
for p,s in after.items():
 write(O/'raw'/p,s)
 write(O/'diffs'/(p.replace('/','__')+'.diff'),''.join(difflib.unified_diff(before[p].splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
old=Path('/tmp/eris-super-property-readiness-1')
r=json.loads((old/'source-bindings.json').read_text()); refreshed=[]
for row in r['sources']+r['fixtures']:
 p=row['path'];b=subprocess.check_output(['git','show',BASE+':'+p],cwd=W)
 same=sha(b)==row['sha256'] and len(b)==row['bytes']
 assert same or p.startswith('docs/'),p
 refreshed.append({'path':p,'bytes':len(b),'sha256':sha(b),'prior_equal':same,'published_git_equal':True,'worktree_equal':(W/p).read_bytes()==b})
put(O/'readiness-base-refresh.json',{'base':BASE,'prior_readiness':bind(old/'source-ready.json'),'prior_bindings':bind(old/'source-bindings.json'),'bindings':refreshed,'scope':'Selected readiness inputs only, not a complete source graph. Prior readiness and H remain frozen.','project_execution':False})
put(O/'interfaces.json',{'base':BASE,'ast':'Expr::SuperProperty(ExprId): raw literal/computed key in same flat Unit','parser_flags':['super_property_allowed: bool','super_property_deferred: bool'],'function_frame':'ObjectMethod; class methods allow properties regardless of direct-super constructor permission; object methods defer; arrows inherit; ordinary functions reset','expression_frame':'SuperPropertyKey(bool): saved allow_in only','new_routing':'Property form uses Primary/New/MemberExpression; direct super() retains existing Unary/LeftHandSide interception. New super.C(args) valid; new super(args) invalid.','other_targets':'assignment_target and for_head admit SuperProperty. Call/New/Unary-delete retain unmodified expression record forms. No new code helper is needed.','runtime_owner':'Root: reference creation/read/write/delete, call receiver, home-object state, active-function binding and machine continuations.','canonical':'Existing legacy inverse refusal includes new variant; legacy parser remains unchanged.','project_execution':False})
print(json.dumps({'status':'draft production generated; not sealed','paths':paths,'refresh':bind(O/'readiness-base-refresh.json')}))
