from pathlib import Path
import json,hashlib,difflib,re,subprocess
K=Path('/tmp/eris-super-properties-plan-1');O=K/'parser-producer-1';W=K/'worktree';BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n')
paths=sorted(str(p.relative_to(O/'raw')) for p in (O/'raw').rglob('*') if p.is_file())
rows=[];inverses=[]
for path in paths:
 a=(O/'raw'/path).read_bytes();bpath=O/'before'/path
 if bpath.exists():
  b=bpath.read_bytes();assert b==subprocess.check_output(['git','show',BASE+':'+path],cwd=W)
  bt=b.decode();at=a.decode();ops=[]
  bl=bt.splitlines(True); al=at.splitlines(True)
  bo=[0]; ao=[0]
  for line in bl:bo.append(bo[-1]+len(line))
  for line in al:ao.append(ao[-1]+len(line))
  for tag,i,j,k,l in difflib.SequenceMatcher(a=bl,b=al,autojunk=False).get_opcodes():
   if tag!='equal':ops.append({'before_start':bo[i],'before_end':bo[j],'after_start':ao[k],'after_end':ao[l],'before':bt[bo[i]:bo[j]],'after':at[ao[k]:ao[l]]})
  rebuilt=bt
  for op in reversed(ops):rebuilt=rebuilt[:op['before_start']]+op['after']+rebuilt[op['before_end']:]
  assert rebuilt==at
  restored=at
  for op in reversed(ops):restored=restored[:op['after_start']]+op['before']+restored[op['after_end']:]
  assert restored==bt
  dp=O/'diffs'/(path.replace('/','__')+'.diff')
  assert dp.read_text()==''.join(difflib.unified_diff(bt.splitlines(True),at.splitlines(True),fromfile='a/'+path,tofile='b/'+path))
  inverses.append({'path':path,'before_sha256':sha(b),'after_sha256':sha(a),'edits':ops,'forward_exact':True,'inverse_exact':True})
  rows.append({'path':path,'before':bind(bpath),'raw':bind(O/'raw'/path),'diff':bind(dp)})
 else:
  assert path=='src/script/parser/super_property_tests.rs'
  assert a==(O/'focused-tests.rs').read_bytes()
  dp=O/'diffs'/(path.replace('/','__')+'.diff');dp.write_text(''.join(difflib.unified_diff([],a.decode().splitlines(True),fromfile='/dev/null',tofile='b/'+path)))
  rows.append({'path':path,'new':True,'raw':bind(O/'raw'/path),'diff':bind(dp)})
put(O/'edit-inverses.json',{'base':BASE,'files':inverses,'new_file_inverse':'Remove the new parser test module and its exact appended cfg(test) registration. No old test body or expectation changes.'})
ledger={
'src/script/code.rs':['Expr: append SuperProperty(ExprId)','cfg(test) canonical expression inverse: explicit refusal alongside existing class-only syntax'],
'src/script/parser.rs':['Parser: add two permission flags','Parser::start: initialize both false','Parser::assignment_target: accept SuperProperty','append new focused-test registration'],
'src/script/parser/driver.rs':['EntryContext: save both flags','run: restore both flags on error; successful dynamic-function handoff unchanged'],
'src/script/parser/driver/functions.rs':['Frame: append ObjectMethod','Context::enter/restore: save, reset ordinary, inherit arrow, restore flags','step ClassMethod: allow property','step ObjectMethod: valid-but-deferred context, unchanged parameter/body helpers'],
'src/script/parser/driver/expressions.rs':['Frame: append SuperPropertyKey(bool)','step Unary/LeftHandSide: property form follows MemberExpression route','step SuperPropertyKey: finish raw computed child and restore allow_in','step object methods/accessors: use ObjectMethod context','new super_property: context guard and raw key emission','super_start: no longer handles property form','primary: delegate consumed super property to helper'],
'src/script/parser/driver/statements.rs':['for_head: accept SuperProperty assignment target']}
put(O/'changed-seams.json',{'base':BASE,'seams':ledger,'invariants':['No runtime machine, helper, Function, Environment, or Reference change in this payload.','No class parser body change; nested class heritage/computed keys inherit surrounding flags through the unchanged class context.','No new recursive syntax ownership; one nonowning same-Unit ExprId edge.','All source lists, record pages and continuation admissions retain existing helper bodies and sizeof formulas.','Legacy parser and all historical tests are byte-unchanged in this payload.','Object methods without super still use identical parameter/body helper operations and uniqueness; only the deferred permission context differs.'],'ambiguities':'None requiring selection for this surface. Optional chaining/tagged templates and existing private/field/async/generator boundaries remain deferred.'})
put(O/'test-expectations.json',{'authorship':'Producer-authored focused parser tests; not independent public/runtime oracle. No execution claimed.','new_module':'src/script/parser/super_property_tests.rs','groups':re.findall(r'(?m)^fn (super_property_parser_\w+)\(', (O/'focused-tests.rs').read_text()),'planned_parse_attempts':37,'contracts':['Exact raw-key AST/reference-consumer edges including new/delete/call/assignment/update/for-in/of and comma extraction','Class/default/accessor/static/arrow/nested-class contexts; ordinary-function and direct-super early errors','Object-method super remains Unsupported, deferred class syntax unchanged','Both new scalar flags restored on syntax/unsupported/work-refusal paths; work remains spent'],'historical_expectation_edits_in_payload':[],'root_owned_expected_migrations':[{'path':'src/script/class_semantics_tests.rs','function':'class_public_super_named_property','old':'Unsupported','selected':'supported class-only property syntax; root independently chooses replacement observation'},{'path':'src/script/class_semantics_tests.rs','function':'class_public_super_computed_assignment','old':'Unsupported','selected':'supported class-only property assignment syntax; root independently chooses replacement observation'}],'layout_sentinel':'Existing parser/driver/call_spread_layout_tests.rs remains unchanged; root measures complete inert proposal before deciding whether an expectation migration is required.'})
# The probe is separately frozen and matches these declarations; no measured width is inferred here.
probe=json.loads((K/'parser-layout-probe-1/checks.json').read_text())
for row in probe['inputs']:
 p=O/'raw'/row['path']
 if p.exists() and row['path']!='src/script/parser.rs':
  # For-head formatting can change outside declarations; exact declaration probe is bound separately.
  pass
put(O/'checks.json',{'base':BASE,'before_git_joins':6,'existing_payloads':6,'new_test_modules':1,'exact_diffs_and_inverses':True,'focused_test_source_exact':True,'probe':bind(K/'parser-layout-probe-1/source-ready.json'),'selection':bind(K/'root/selection-1.json'),'source_readiness_refresh':bind(O/'readiness-base-refresh.json'),'execution':{'project_imports':False,'project_tests':False,'project_builds':False,'javascript':False,'live_source_edits':False},'qualification':'This held parser/code change requires root runtime implementation for exhaustive Expr matches and semantic operation. No compilation, formatting, size, or outcome claim.'})
put(O/'authoring-qualification.json',{'inverse_checker':'Initial character-level difflib pass was stopped before writing receipt outputs; replaced by exact line-derived offset edits and complete forward/inverse byte checks.','producer_change':False,'project_execution':False})
files=[dict(bind(f),path=str(f.relative_to(O))) for f in sorted(O.rglob('*')) if f.is_file() and f.name!='source-ready.json']
put(O/'source-ready.json',{'format':1,'status':'sealed_source_only_parser_code_payload','base':BASE,'selection':bind(K/'root/selection-1.json'),'readiness_refresh':bind(O/'readiness-base-refresh.json'),'interfaces':bind(O/'interfaces.json'),'checks':bind(O/'checks.json'),'edit_inverses':bind(O/'edit-inverses.json'),'changed_seams':bind(O/'changed-seams.json'),'test_expectations':bind(O/'test-expectations.json'),'payloads':rows,'files':files,'integration':'Apply six exact published-parent payload diffs and add focused test module. Root removes inert probe registration first or composes shared driver registration separately. No runtime source supplied.','project_execution':False})
print(json.dumps(bind(O/'source-ready.json')))
