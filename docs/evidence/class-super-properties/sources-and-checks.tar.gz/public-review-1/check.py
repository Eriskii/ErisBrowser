"""Independent inert byte/roster checks; never imports or executes project code."""
import collections
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

P = Path('/tmp/eris-super-properties-plan-1')
BASE = 'db02f8c890a459b979378900f113b67460a49121'
OUT = P / 'public-review-1'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(relative):
    return json.loads((P / relative).read_text())

checked = {}
def verify(item):
    path = Path(item['path'])
    actual = binding(path)
    assert actual['bytes'] == item['bytes'], path
    assert actual['sha256'] == item['sha256'], path
    checked[str(path)] = actual

def git(relative):
    return subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=P/'worktree')

control = read('public-controls-1/source-ready.json')
adapter = read('public-adapter-1/source-ready.json')
migration = read('historical-migration-1/source-ready.json')
for item in control['files']:
    verify(item)
for field in ['before', 'raw', 'diff']:
    verify(migration[field])
for item in adapter['files']:
    verify(dict(item, path=str(P/'public-adapter-1/raw'/item['path'])))
assert adapter['oracle_sha256'] == control['oracle']['sha256']
assert adapter['adapter_sha256'] == sha((P/'public-controls-1/adapter-proposal.rs').read_bytes())
rows = read('public-controls-1/complete-cases.json')['rows']
assert rows[:64] == read('public-controls-1/cases.json')['rows']
assert rows[64:] == read('public-controls-1/supplement-1.json')['rows']
assert len(rows) == len({r['id'] for r in rows}) == 65
assert len({r['proposed_test_name'] for r in rows}) == 65
assert all(r['modes'] == ['sloppy', 'strict'] for r in rows)
assert all(r['proposed_test_name'] == 'super_property_' + r['id'] for r in rows)
families = dict(collections.Counter(r['family'] for r in rows))
assert families == {'semantic':41, 'early-error':8, 'unsupported':5, 'resource-terminal':6, 'unsupported-terminal':5}

published = []
for path in sorted((P/'public-controls-1/published').rglob('*')):
    if path.is_file():
        relative = path.relative_to(P/'public-controls-1/published').as_posix()
        assert path.read_bytes() == git(relative), relative
        published.append(dict(binding(path), relative_path=relative))
registration = (P/'public-adapter-1/registration.txt').read_text()
assert registration == '\n#[cfg(test)]\nmod super_property_semantics_tests;\n#[cfg(test)]\nmod super_property_abort_tests;\n'
assert (P/'public-adapter-1/registration-before.rs').read_bytes() == git('src/script.rs')
assert b'mod super_property_semantics_tests;' not in git('src/script.rs')
assert b'mod super_property_abort_tests;' not in git('src/script.rs')

raw_re = re.compile(r'r(#+)"(.*?)"\1', re.S)
test_re = re.compile(r'^#\[test\]\nfn (\w+)\(\) \{\n', re.M)
test_bodies = {}
module_rosters = {}
helper_rosters = {}
proposal = (P/'public-controls-1/adapter-proposal.rs').read_text()
def helpers(text):
    starts = list(re.finditer(r'^fn (\w+)', text, re.M))
    return {m[1]: text[m.start(): starts[i+1].start() if i+1 < len(starts) else len(text)].rstrip()
            for i,m in enumerate(starts)}
proposed_helpers = helpers(proposal)
for item in adapter['files']:
    text = (P/'public-adapter-1/raw'/item['path']).read_text()
    matches = list(test_re.finditer(text))
    assert len(matches) == item['tests']
    head = text[:matches[0].start()]
    actual_helpers = helpers(head)
    for name, body in actual_helpers.items():
        assert body == proposed_helpers[name], name
    helper_rosters[item['path']] = list(actual_helpers)
    module_rosters[item['path']] = [m[1] for m in matches]
    for i,m in enumerate(matches):
        assert m[1] not in test_bodies
        test_bodies[m[1]] = text[m.end():matches[i+1].start() if i+1<len(matches) else len(text)].strip()
assert helper_rosters == {
    'src/script/super_property_semantics_tests.rs': ['execute_mode', 'observe', 'early_error', 'deferred'],
    'src/script/super_property_abort_tests.rs': ['execute_mode', 'retained', 'fatal']}

literal_rows = []
row_checks = []
for r in rows:
    fields = [f for f in ['source','setup','readback'] if isinstance(r.get(f), str)]
    for field in fields:
        verify(r[field+'_binding'])
        assert Path(r[field+'_binding']['path']).read_bytes() == r[field].encode()
        literal_rows.append({'id': r['id'], 'field': field, 'sha256': sha(r[field].encode())})
    body = test_bodies[r['proposed_test_name']]
    actual_args = [m[2] for m in raw_re.finditer(body)]
    family = r['family']
    tail = ''
    if family == 'semantic':
        call = 'observe'
        expected_args = [r['id'], r['source'], r['readback'], r['expected']['sloppy'], r['expected']['strict']]
    elif family == 'early-error':
        call = 'early_error'
        expected_args = [r['id'], r['setup'], r['source'], r['readback']]
        assert r['expected'] == {'sloppy':0,'strict':0}
        assert r['error'] == {'intrinsic':'SyntaxError','is_parse_error':True}
    elif family == 'unsupported':
        call = 'deferred'
        expected_args = [r['id'],r['source']]
        assert r['readback'] is None and r['error'] == {'is_unsupported':True}
    else:
        call = 'fatal'
        expected_args = [r['id'],r['source'],r['expected_retained']['trace']]
        unsupported = family == 'unsupported-terminal'
        tail = ',' + str(unsupported).lower()
        assert r['readback'] is None
        assert r['expected_retained'] == dict(trace=expected_args[-1],caught=0,finalized=0,after=0,queuedRan=0)
        assert r['error']['is_unsupported'] == unsupported
        assert r['error']['is_resource_limit'] == (not unsupported)
        observer = dict(microtasks_suspended=True,frames=0,calls=0,eval_depth=0,stack_units=0,author_depth=0,
                        performing_checkpoint=False,queued_callback_count=1,queued_callback_identity='queued',console_empty=True)
        if not unsupported:
            observer['steps'] = 0
            assert r['error']['message'] == 'script instruction limit exceeded'
        assert r['observer'] == observer
    assert actual_args == expected_args, r['id']
    skeleton = re.sub(r'\s+', '', raw_re.sub('ARG',body))
    expected_skeleton = call + '(' + ','.join(['ARG']*len(expected_args)) + tail + ');}'
    assert skeleton == expected_skeleton, (r['id'],skeleton)
    row_checks.append({'id':r['id'],'family':family,'test':r['proposed_test_name'],'modes':r['modes'],
                       'literal_fields_exact':fields,'helper':call,'expectations_exact':True})
assert len(literal_rows) == 122
assert sorted(literal_rows,key=lambda x:(x['id'],x['field'])) == sorted(adapter['literals'],key=lambda x:(x['id'],x['field']))
assert set(test_bodies) == {r['proposed_test_name'] for r in rows}
assert module_rosters['src/script/super_property_semantics_tests.rs'] == [r['proposed_test_name'] for r in rows if 'terminal' not in r['family']]
assert module_rosters['src/script/super_property_abort_tests.rs'] == [r['proposed_test_name'] for r in rows if 'terminal' in r['family']]

before = (P/'historical-migration-1/before.rs').read_text()
after = (P/'historical-migration-1/after.rs').read_text()
assert before.encode() == git(migration['path'])
diff = ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+migration['path'],tofile='b/'+migration['path']))
assert diff == (P/'historical-migration-1/migration.diff').read_text()
expected_after = before
for name, source, suffix, value in [
    ('super_named_property','class C {m(){return super.x;}}\n',"Object.setPrototypeOf(C.prototype, {x:17});\nvar result=(new C()).m();\n",17),
    ('super_computed_assignment','class C {m(k,v){super[k]=v;}}\n',"var item=new C();item.m('x',23);var result=item.x;\n",23)]:
    old = '    unsupported(\n        "'+name+'",\n        r###"'+source+'"###,\n    );'
    new = '    observe(\n        "'+name+'",\n        r###"'+source+suffix+'"###,\n        "result",\n        Value::Number('+str(value)+'.0),\n    );'
    assert expected_after.count(old) == 1
    expected_after = expected_after.replace(old,new,1)
assert expected_after == after
assert test_re.findall(before) == test_re.findall(after)

report = {
    'schema':1,'status':'clear','base':BASE,
    'method':'stdlib byte/hash/regex checks and read-only git show; no project imports or execution',
    'inputs':[binding(P/x) for x in ['public-controls-1/source-ready.json','public-adapter-1/source-ready.json','historical-migration-1/source-ready.json']],
    'all_declared_file_bindings':{'checked':len(checked),'exact':True},
    'published_snapshots':published,'groups':65,'planned_modes':130,'family_counts':families,
    'literal_fields':122,'original_64_exact':True,'supplement_exact':True,
    'module_rosters':module_rosters,'helper_rosters':helper_rosters,'helper_bodies_exact_to_proposal':True,
    'registration':{'before_exact_published':True,'fragment':binding(P/'public-adapter-1/registration.txt')},
    'rows':row_checks,
    'historical_migrations':{'names':migration['names'],'only_two_exact_replacements':True,'original_source_lines_retained':True,'entire_remainder_exact':True,'roster_unchanged':True},
    'outcome_logs_read':False,'candidate_execution':False
}
(OUT/'source-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(binding(OUT/'source-checks.json')))
