"""Author additive source only; do not import or execute either replay recipe."""
from pathlib import Path
import ast, difflib, hashlib, json
K=Path('/tmp/eris-super-properties-plan-1'); A=K/'profile-replay-1'; B=K/'profile-replay-2'
def bind(p):
    d=p.read_bytes(); return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def put(name,value): (B/name).write_text(json.dumps(value,indent=2)+'\n')
source=(A/'replay.py').read_text(); before=source; edits=[]
def edit(name,old,new):
    global source
    assert source.count(old)==1,name
    source=source.replace(old,new)
    edits.append({'name':name,'before':old,'after':new})
edit('immutable tree census rejects symlinks and unknown directories',
"""        actual = {str(path.relative_to(W)) for path in (W / root).rglob('*') if path.is_file()}
        expected = {name for name in immutable if name.startswith(root + '/')}
        require(actual == expected, 'exact corpus/baseline file census changed: ' + root)
""",
"""        directory = W / root
        require(directory.is_dir() and not directory.is_symlink(), 'immutable tree root changed: ' + root)
        entries = list(directory.rglob('*'))
        require(all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in entries),
                'immutable tree has symlink/special entry: ' + root)
        actual = {str(path.relative_to(W)) for path in entries if path.is_file()}
        expected = {name for name in immutable if name.startswith(root + '/')}
        require(actual == expected, 'exact tooling/corpus/baseline file census changed: ' + root)
        expected_dirs = {str(parent) for name in expected for parent in PurePosixPath(name).parents
                         if str(parent).startswith(root + '/')}
        actual_dirs = {str(path.relative_to(W)) for path in entries if path.is_dir()}
        require(actual_dirs == expected_dirs, 'exact immutable directory census changed: ' + root)
""")
edit('binary is the selected canonical release output',
"""        require(env['target_dir'] == str(K / target), 'build target directory')
""",
"""        require(env['target_dir'] == str(K / target), 'build target directory')
        release_output = Path(env['target_dir']) / 'release' / 'eris-js'
        require(record['binary'] == str(release_output), 'binary is not the selected release output')
        require(not release_output.is_symlink(), 'release executable must not be a symlink')
        require(bound(release_output) == binary, 'release output bytes/binary mismatch')
""")
edit('classification must agree with raw evidence',
"""        raw_schema(row['observation'], host)
    else:
""",
"""        observation = row['observation']
        raw_schema(observation, host)
        status, negative = observation['status'], row['expected_negative']
        if status in {'unsupported', 'resource', 'harness-error'}:
            classified = status
        elif host:
            if status == 'complete':
                evidence = observation['completion']
                counts = (evidence['done_calls'], evidence['success_prints'], evidence['failure_prints'])
                require(observation['phase'] == 'runtime'
                        and not any(observation[name] for name in ('error_type', 'error_identity', 'message', 'harness'))
                        and evidence['flags'] == 0 and evidence['quiescent'] and evidence['audited']
                        and evidence['unhandled'] == 0
                        and counts == ((0, 0, 0) if evidence['policy'] == 0 else (1, 1, 0)),
                        'raw complete lacks passing Promise completion evidence')
            classified = 'passed' if status == 'complete' and negative is None else 'failed'
        elif negative is None:
            classified = 'passed' if status == 'complete' and observation['phase'] == 'runtime' else 'failed'
        else:
            classified = ('passed' if status == 'exception' and observation['phase'] == negative['phase']
                          and observation['error_identity'] == negative['type'] else 'failed')
        require(row['status'] == classified, 'classified/raw status mismatch')
    else:
""")
edit('raw infrastructure always blocks case acceptance',
"""        if new['status'] not in NORMAL_CASE_STATUSES:
            row['infrastructure_cases'].append(new)
""",
"""        observation = new.get('observation')
        if (new['status'] not in NORMAL_CASE_STATUSES
                or (type(observation) is dict and observation.get('status') in {'resource', 'harness-error'})):
            row['infrastructure_cases'].append(new)
""")
assert ast.parse(source)
undo=source
for item in reversed(edits):
    assert undo.count(item['after'])==1
    undo=undo.replace(item['after'],item['before'])
assert undo==before
(B/'replay.py').write_text(source)
(B/'replay.py.diff').write_text(''.join(difflib.unified_diff(before.splitlines(True),source.splitlines(True),fromfile='profile-replay-1/replay.py',tofile='profile-replay-2/replay.py')))
old=json.loads((A/'contract.json').read_bytes()); new=json.loads((A/'contract.json').read_bytes())
assert 'tools' not in new['exact_tree_roots']; new['exact_tree_roots'].append('tools')
new['commands']=[x.replace('/profile-replay-1/replay.py','/profile-replay-2/replay.py') for x in old['commands']]
new['acceptance'] += [
 'Classified case status must agree with raw transport evidence; raw resource/harness-error cases block acceptance independently of the classified status. Exact deliberately expected Resource controls remain permitted.',
 'The complete immutable tools tree is included in the exact file/directory census; no unknown additions, symlinks, special entries or cache exclusions are accepted.',
 'Each sidecar binary must be exactly its bound environment target_dir/release/eris-js output with matching bytes. Alternate/copy binary paths are not admitted by this recipe.'
]
put('contract.json',new)
(B/'contract.json.diff').write_text(''.join(difflib.unified_diff((A/'contract.json').read_text().splitlines(True),(B/'contract.json').read_text().splitlines(True),fromfile='profile-replay-1/contract.json',tofile='profile-replay-2/contract.json')))
check=dict(new);check['exact_tree_roots']=old['exact_tree_roots'];check['commands']=old['commands'];check['acceptance']=old['acceptance'];assert check==old
oldnodes={x.name:ast.get_source_segment(before,x) for x in ast.parse(before).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
newnodes={x.name:ast.get_source_segment(source,x) for x in ast.parse(source).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
changed=[x for x in oldnodes if oldnodes[x]!=newnodes[x]]
assert changed==['source_checks','binaries','result_schema','compare']
put('delta.json',{'original_hold':bind(A/'source-ready.json'),'independent_findings':bind(K/'profile-review-1/review.json'),'original_runner':bind(A/'replay.py'),'runner':bind(B/'replay.py'),'original_contract':bind(A/'contract.json'),'contract':bind(B/'contract.json'),'edits':edits,'changed_functions':changed,'unchanged_functions':[x for x in oldnodes if x not in changed],'contract_changed_fields':['exact_tree_roots','commands','acceptance'],'whole_source_inverse':True,'all_profile_policy_identity_control_and_immutable_hash_records_preserved':True,'project_execution':False,'live_edits':False})
print(json.dumps({'runner':bind(B/'replay.py'),'contract':bind(B/'contract.json'),'changed_functions':changed}))
