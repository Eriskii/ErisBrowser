"""AST/JSON/source checks only. Does not import or execute replay/project code."""
from collections import Counter
from pathlib import Path, PurePosixPath
import ast, hashlib, json
K=Path('/tmp/eris-super-properties-plan-1');P=K/'profile-replay-2';A=K/'profile-replay-1'
def bind(path):
    data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def put(name,value): (P/name).write_text(json.dumps(value,indent=2)+'\n')
def bound_json(binding):
    path=Path(binding['path']);assert bind(path)==binding
    return json.loads(path.read_bytes())
oldseal=json.loads((A/'source-ready.json').read_bytes())
for item in oldseal['files']:
    found=bind(A/item['path']);assert found['bytes']==item['bytes'] and found['sha256']==item['sha256']
c=json.loads((P/'contract.json').read_bytes());old=json.loads((A/'contract.json').read_bytes())
for key in c.keys()-{'exact_tree_roots','commands','acceptance'}:assert c[key]==old[key],key
assert c['exact_tree_roots']==old['exact_tree_roots']+['tools']
tree=ast.parse((P/'replay.py').read_text());imports=[]
for node in ast.walk(tree):
    if isinstance(node,ast.Import):imports.extend(alias.name for alias in node.names)
    if isinstance(node,ast.ImportFrom):imports.append(node.module)
assert set(imports)<= {'argparse','collections','hashlib','json','math','pathlib','subprocess','sys'}
source=(P/'replay.py').read_text()
assert "'--baseline'" not in source and "'--record-baseline'" not in source
rows=[];status_pairs=Counter();observed=0;unobserved=0
for profile in c['profiles']:
    report=bound_json(profile['reference_report']);bound_json(profile['reference_receipt'])
    assert bind(Path(profile['reference_log']['path']))==profile['reference_log']
    host=profile['binary_kind']=='host'
    for result in report['cases']+[x['result'] for x in report['harness_preflight']]:
        if 'observation' not in result:
            unobserved+=1;continue
        observed+=1;o=result['observation'];s=o['status'];negative=result['expected_negative']
        # Independent source-derived compatibility census, not replay execution.
        if s in ('resource','unsupported','harness-error'): expected=s
        elif host: expected='passed' if s=='complete' and negative is None else 'failed'
        else:
            success=(s=='complete' and o['phase']=='runtime') if negative is None else (
                s=='exception' and o['phase']==negative['phase'] and o['error_identity']==negative['type'])
            expected='passed' if success else 'failed'
        assert result['status']==expected,(profile['name'],result['id'])
        if host and s=='complete':
            e=o['completion'];assert o['phase']=='runtime'
            assert not any(o[k] for k in ('error_type','error_identity','message','harness'))
            assert e['flags']==0 and e['quiescent'] and e['audited'] and e['unhandled']==0
            assert tuple(e[k] for k in ('done_calls','success_prints','failure_prints'))==((0,0,0) if e['policy']==0 else (1,1,0))
        status_pairs[(host,result['status'],s)]+=1
    controls=report['harness_preflight'];by={(x['name'],x['result']['mode']):x for x in controls}
    assert len(by)==profile['controls'];edges=0;graph={key:[] for key in by}
    for key,row in by.items():
        assert row['verified'] is True
        for ref in row['prerequisites']:
            target=(ref['name'],ref['mode']);other=by[target];edges+=1
            for field in ('case_sha256','source_sha256'):assert ref[field]==other['result'][field]
            if 'id' in ref:assert ref['id']==other['result']['id'] and ref['expected']==other['expected']
            if 'verified' in ref:assert ref['verified'] is True
            graph[key].append(target)
    visited=set();active=set()
    def walk(key):
        assert key not in active
        if key in visited:return
        active.add(key)
        for target in graph[key]:walk(target)
        active.remove(key);visited.add(key)
    for key in graph:walk(key)
    rows.append({'profile':profile['profile'],'cases':len(report['cases']),'controls':len(controls),'ordered_edges':edges,'report':profile['reference_report']})
immutable={x['path']:x for x in c['immutable_published_inputs']}
tools={name:item for name,item in immutable.items() if name.startswith('tools/')}
entries=list((K/'worktree/tools').rglob('*'))
assert all(not x.is_symlink() and (x.is_file() or x.is_dir()) for x in entries)
actual={str(x.relative_to(K/'worktree')) for x in entries if x.is_file()};assert actual==set(tools)
expected_dirs={str(p) for name in tools for p in PurePosixPath(name).parents if str(p).startswith('tools/')}
assert {str(x.relative_to(K/'worktree')) for x in entries if x.is_dir()}==expected_dirs
for name,item in tools.items():
    found=bind(K/'worktree'/name);assert found['bytes']==item['bytes'] and found['sha256']==item['sha256']
delta=bound_json(bind(P/'delta.json'))
new=(P/'replay.py').read_text()
for edit in reversed(delta['edits']):
    assert new.count(edit['after'])==1;new=new.replace(edit['after'],edit['before'])
assert new==(A/'replay.py').read_text()
checks={'status':'inert source checks passed','imports':sorted(set(imports)),'ast_syntax':True,'old_hold_all_members_unchanged':True,'whole_runner_inverse':True,'changed_functions':delta['changed_functions'],'preserved_contract_fields':sorted(c.keys()-{'exact_tree_roots','commands','acceptance'}),'predecessor_profiles':rows,'cases':sum(x['cases'] for x in rows),'controls':sum(x['controls'] for x in rows),'edges':sum(x['ordered_edges'] for x in rows),'observed_rows':observed,'unobserved_rows':unobserved,'published_status_pairs':[{'host':k[0],'classified':k[1],'raw':k[2],'rows':v} for k,v in sorted(status_pairs.items())],'exact_current_tools_files':len(tools),'exact_current_tools_directories':len(expected_dirs),'source_only_refusal_matrix':[
 {'input':'case raw Resource/harness-error, outer passed or failed','required':'classification mismatch and independent infrastructure flag; acceptance blocked'},
 {'input':'case raw Resource/harness-error, outer same status','required':'schema consistent but infrastructure flag still blocks acceptance'},
 {'input':'raw unsupported, outer passed/failed','required':'classification mismatch; ordinary unsupported remains allowed only when classified unsupported'},
 {'input':'complete/exception/host-failure with incompatible classified status','required':'classification mismatch; host complete additionally requires passing completion evidence'},
 {'input':'deliberate control raw Resource and outer resource','required':'schema allowed, but full frozen control row equality and healthy graph still required'},
 {'input':'new tools/hashlib.py, package directory, symlink or special entry','required':'exact file/directory/type census refuses before any CLI dispatch'},
 {'input':'sidecar binary is an older retained path or a copy path','required':'canonical release-output join refuses even when that file hash is accurate'},
 {'input':'canonical output changed after selection or during replay','required':'binary/sidecar/source/build/environment/log hashes rechecked before and after serial runs'}
 ],'no_executed_synthetic_fixture':True,'project_imports':False,'project_execution':False,'replay_execution':False,'live_edits':False,'qualifications':['No candidate binary or runtime outcome is accepted here. Root supplies bound source inventory/builds and executes the held recipe.','Selected input closure is not the entire compiler/system build graph.','Alternate copied binary paths are intentionally not supported; root can bind canonical release outputs.','The schema/classification addition supplements exact raw control comparisons; it does not modify any repository decoder, validator, classifier, policy, corpus, helper or baseline.']}
put('source-checks.json',checks)
files=[dict(bind(p),path=p.name) for p in sorted(P.iterdir()) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',{'format':1,'status':'sealed_source_only_additive_root_replay_recipe','base':c['base'],'supersedes':bind(A/'source-ready.json'),'findings':bind(K/'profile-review-1/review.json'),'contract':bind(P/'contract.json'),'runner':bind(P/'replay.py'),'delta':bind(P/'delta.json'),'checks':bind(P/'source-checks.json'),'files':files,'profiles':8,'cases':1330,'controls':724,'baseline_writes':False,'project_execution':False,'live_edits':False})
print(json.dumps(bind(P/'source-ready.json')))
