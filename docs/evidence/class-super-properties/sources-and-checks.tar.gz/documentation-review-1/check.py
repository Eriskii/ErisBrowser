"""Read-only stdlib/Git review of sealed documentation and retained evidence."""
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

P = Path('/tmp/eris-super-properties-plan-1')
W = P / 'worktree'
BASE = 'db02f8c890a459b979378900f113b67460a49121'
OUT = P / 'documentation-review-1'
seen = {}

def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def checked(record):
    actual = binding(record['path'])
    assert actual == {k: record[k] for k in actual}, record['path']
    seen[actual['path']] = actual
    return Path(record['path']).read_bytes()

def walk(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and Path(value['path']).is_absolute():
            checked(value)
        for child in value.values():
            walk(child)
    elif isinstance(value, list):
        for child in value:
            walk(child)

def read(relative):
    return json.loads((P / relative).read_bytes())

def git(path):
    return subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + path])

seal = read('documentation-2/source-ready.json')
ledger = read('root/final-validation.json')
assert binding(P/'documentation-2/source-ready.json')['sha256'] == '8fe96825470982e24bc579c5a1a38d3ec7f8f3a3f66a94ad7a6b999dc9b66bb5'
assert binding(P/'root/final-validation.json')['sha256'] == '1806253b13ebfd8367bf924cfa13728999f379450e1260ad800d233d0c531db3'
walk(seal)
walk(ledger)
assert ledger['status'] == 'pass'
assert seal['final_validation'] == binding(P/'root/final-validation.json')
paths = [f['relative_path'] for f in seal['files']]
assert paths == ['README.md', 'docs/ROADMAP.md', 'docs/classes.md', 'docs/class-super-properties.md']
documents = []
for row in seal['files']:
    path = row['relative_path']
    before = checked(row['before']) if row['before'] else b''
    after = checked(row['raw'])
    if row['before']:
        assert before == git(path)
        assert after == (P/'documentation-1/raw'/path).read_bytes()
    else:
        assert not subprocess.check_output(['git','-C',str(W),'ls-tree',BASE,'--',path])
    expected = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/'+path, tofile='b/'+path)).encode()
    assert checked(row['diff']) == expected
    documents.append(dict(path=path, before_published=bool(row['before']), exact_diff=True, raw=row['raw']))
edit = read('documentation-2/edit.json')
draft = (P/'documentation-1/raw/docs/class-super-properties.md').read_text()
final = (P/'documentation-2/raw/docs/class-super-properties.md').read_text()
assert draft.count(edit['old']) == final.count(edit['new']) == 1
assert final == draft.replace(edit['old'], edit['new'])
assert draft == final.replace(edit['new'], edit['old'])
assert not re.search(r'pending|TBD|TODO', final, re.I)
historical = git('docs/VALIDATION.md')
assert (W/'docs/VALIDATION.md').read_bytes() == historical

attempts = {x['label']: x for x in ledger['attempts']}
counts = {}
pattern = r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
expected_counts = {
    'candidate-full-msrv-2': (55,3432,0,0,0,0),
    'candidate-full-host-vulkan-1': (55,3796,0,0,0,0),
    'candidate-full-msrv-1': (1,3085,3,0,0,0),
}
for label in expected_counts:
    rows = [tuple(map(int,r)) for r in re.findall(pattern, checked(attempts[label]['log']).decode())]
    result = (len(rows), *(sum(row[i] for row in rows) for i in range(5)))
    assert result == expected_counts[label], (label,result)
    counts[label] = dict(rows=result[0], passed=result[1], failed=result[2], ignored=result[3], measured=result[4], filtered=result[5])
for label,p,f in [('parent-public-1',10,55),('parent-browser-1',0,1),('candidate-capture-msrv-1',6,1),('candidate-capture-msrv-2',9,0),('parent-full-msrv-1',2994,6),('parent-full-msrv-2',3218,0)]:
    rows = [tuple(map(int,r)) for r in re.findall(pattern,checked(attempts[label]['log']).decode())]
    assert sum(r[0] for r in rows)==p and sum(r[1] for r in rows)==f
    counts[label] = dict(rows=len(rows),passed=p,failed=f,ignored=sum(r[2] for r in rows),filtered=sum(r[4] for r in rows))
for label in ledger['accepted_labels']:
    assert attempts[label]['exit'] == 0
    receipt = json.loads(checked(attempts[label]['receipt']))
    assert receipt['exit'] == 0

replay = read('root/profile-replay-1.json')
walk(replay)
assert (P/'root/profile-replay-1.json').read_bytes() == (P/'root/profile-replay-1-recheck.json').read_bytes()
profiles = []
total = Counter()
for row in replay['profiles']:
    old = json.loads(checked(row['before']))
    new = json.loads(checked(row['report']))
    for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256']:
        assert old[key] == new[key], (row['name'],key)
    assert new['harness_preflight_passed'] is True
    assert all(x['verified'] is True for x in new['harness_preflight'])
    statuses = Counter(x['status'] for x in new['cases'])
    assert dict(statuses) == row['counts'] == new['counts']
    assert len(new['cases']) == row['cases'] and len(new['harness_preflight']) == row['controls']
    total.update(statuses)
    profiles.append(dict(name=row['name'],cases=row['cases'],controls=row['controls'],counts=dict(statuses),complete_arrays_equal=True,policy_and_corpus_equal=True))
assert len(profiles)==8 and sum(x['cases'] for x in profiles)==1330 and sum(x['controls'] for x in profiles)==724
assert dict(total)==dict(passed=1258,failed=64,unsupported=8)==ledger['profile_counts']
assert all(x==0 for x in replay['transition_counts'].values())
for role,item in replay['binaries'].items():
    sidecar=json.loads(checked(item['sidecar']))
    assert sidecar==item['record'] and sidecar['source_inventory']==ledger['source_inventory']
    assert sidecar['sha256']==item['binary']['sha256'] and sidecar['bytes']==item['binary']['bytes']
    assert sidecar['features']==([] if role=='ordinary' else ['test262-host'])
    assert sidecar['toolchain']==('1.88.0' if role=='ordinary' else '1.99.0')
    assert json.loads(checked(sidecar['build']))['exit']==0

layout=read('root/actual-layout-measurements-1.json')
for measurement in layout['measurements']:
    raw=checked(attempts[measurement['label']]['log']).decode()
    for name,size in [('Function',120),('Reference',80),('Frame',184),('Environment',112)]:
        assert measurement['runtime'][name+'.actual']==[size,8]
        assert 'SUPER_LAYOUT '+name+'.actual '+str(size)+' 8' in raw
snapshot=read('root/candidate-snapshots-2.json')
inventory=read('source-candidate-2.json')
index={r['path']:r for r in inventory['files']}
assert len(index)==15289 and len(snapshot['files'])==28
for row in snapshot['files']:
    assert row==index[row['path']]
    actual=binding(Path(snapshot['root'])/row['path'])
    assert actual['sha256']==row['sha256'] and actual['bytes']==row['bytes']
assert not any(r['path'].startswith(('tools/','tests/upstream/','tests/conformance/')) for r in snapshot['files'])
old_index={r['path']:r for r in read('source-candidate-1.json')['files']}
delta=sorted(p for p,r in index.items() if r!=old_index[p])
assert delta==['src/script/classes/quota_tests.rs','src/script/machine/call_spread_phase_tests.rs','src/script/typed_array/tests.rs']
script=(Path(snapshot['root'])/'src/script.rs').read_text()
base_script=git('src/script.rs').decode()
limits=['const MAX_STEPS: usize = 100_000;','const BOOTSTRAP_STEPS: usize = 1_000_000;','const MAX_HEAP: usize = 8 * 1024 * 1024;']
assert all(line in script and line in base_script for line in limits)
assert ledger['new_coverage']==dict(public_groups=65,public_modes=130,exact_js_fields=122,parser_groups=4,receiver_wrapper_groups=8,capture_groups=9,capture_measured_calls=84,browser_groups=2)

result=dict(status='clear',method='Independent stdlib hash/raw-log/complete-array comparison and read-only Git; no project imports, execution, builds or tests.',documentation_hold=binding(P/'documentation-2/source-ready.json'),final_validation=binding(P/'root/final-validation.json'),documents=documents,exact_draft_tail_inverse=True,historical_validation=dict(path='docs/VALIDATION.md',bytes=len(historical),sha256=hashlib.sha256(historical).hexdigest(),published_and_current_exact=True),attempt_recounts=counts,profiles=profiles,profile_totals=dict(cases=1330,controls=724,counts=dict(total)),selected_inputs=15289,changed_source_paths=28,candidate2_test_only_delta=delta,limits=limits,all_checked_bindings=sorted(seen.values(),key=lambda r:r['path']),reviewer_orchestration='An initial ad hoc checker stopped before writing output because its path-prefix assertion omitted browser fixture/support/worker paths. This review uses the exact 28-path snapshot roster. No product, documentation or evidence bytes were changed.')
(OUT/'evidence-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(binding(OUT/'evidence-checks.json')))
