from pathlib import Path
import hashlib,json,subprocess
K=Path('/tmp/eris-super-properties-plan-1');O=K/'profile-replay-1';W=K/'worktree';H=Path('/tmp/eris-promise-class-admission-plan-1');BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def put(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
old=json.loads((H/'profile-replay-2/contract.json').read_text());summary=json.loads((H/'root/profile-candidate-1.json').read_text());assert summary['status']=='pass'
profiles=[]
for p,s in zip(old['profiles'],summary['profiles']):
 assert p['profile']==s['profile'] and s['report']==bind(Path(s['report']['path']))
 r=json.loads(Path(s['report']['path']).read_text());assert len(r['cases'])==p['cases'] and r['harness_preflight_passed'] is True
 assert all(x['verified'] is True for x in r['harness_preflight'])
 policy=r['runner_policy'];assert sha(json.dumps(policy,sort_keys=True).encode())==r['runner_policy_sha256']
 profiles.append({'name':p['name'],'profile':p['profile'],'binary_kind':p['binary_kind'],'reference_report':s['report'],'reference_receipt':s['receipt'],'reference_log':s['log'],'cases':len(r['cases']),'controls':len(r['harness_preflight']),'policy':policy,'policy_sha256':r['runner_policy_sha256'],'corpus':'tests/upstream/test262-'+p['profile'],'corpus_manifest_sha256':r['corpus_manifest_sha256']})
assert sum(p['cases'] for p in profiles)==1330 and sum(p['controls'] for p in profiles)==724
entries=[]
for row in subprocess.check_output(['git','ls-tree','-rz',BASE],cwd=W).split(b'\0'):
 if not row:continue
 left,path=row.split(b'\t',1);mode,kind,oid=left.split();path=path.decode()
 if path.startswith(('src/','crates/','assets/','shaders/','tools/','tests/upstream/','tests/conformance/')) or path in ('Cargo.toml','Cargo.lock','build.rs'):
  assert kind==b'blob' and mode in (b'100644',b'100755'),(path,mode,kind)
  entries.append((path,oid.decode()))
# Batch Git blob reads, no repository module imports or commands executed.
request=''.join(oid+'\n' for _,oid in entries).encode();raw=subprocess.check_output(['git','cat-file','--batch'],cwd=W,input=request);pos=0;immut=[];runtime=[]
for path,oid in entries:
 end=raw.index(b'\n',pos);got,kind,size=raw[pos:end].split();size=int(size);pos=end+1;b=raw[pos:pos+size];pos+=size
 assert raw[pos:pos+1]==b'\n';pos+=1
 assert got.decode()==oid and kind==b'blob'
 if path.startswith(('tools/','tests/upstream/','tests/conformance/')):immut.append({'path':path,'bytes':size,'sha256':sha(b)})
 else:runtime.append(path)
assert pos==len(raw)
put('contract.json',{'format':1,'base':BASE,'scope':'Eight fixed published profiles, full retained raw comparisons and selected candidate inventory plus tracked runtime/build closure. Not a complete external compiler/system build graph.','predecessor':bind(H/'root/profile-candidate-1.json'),'predecessor_contract':bind(H/'profile-replay-2/contract.json'),'profiles':profiles,'totals':{'cases':1330,'controls':724,'profiles':8},'immutable_published_inputs':immut,'tracked_runtime_closure':runtime,'exact_tree_roots':[p['corpus'] for p in profiles]+['tests/conformance'],'root_runner':bind(K/'run-tool.py'),'selection_schema':{'source_inventory':'{path,bytes,sha256} binding to {base,scope,files:[{path,bytes,sha256}]}','binaries':{'ordinary':'{path,bytes,sha256} binding to sidecar','host':'{path,bytes,sha256} binding to sidecar'}},'binary_schema':['binary','bytes','sha256','source_inventory','build','environment','features','toolchain'],'expected_builds':{'ordinary':{'toolchain':'1.88.0','features':[],'config':'msrv'},'host':{'toolchain':'1.99.0','features':['test262-host'],'config':'host'}},'run':{'jobs':1,'timeout':3.0,'baseline_arguments':False,'record_baseline':False},'acceptance':['All selected source and frozen tool/corpus/baseline inputs and binary transitive bindings must remain exact before/after each serial run.','All 1330 ordered case identities and policies retain exact values. No status count is predicted.','All 724 ordered controls retain schema, identity, prerequisites, expected semantics and complete published raw observations, including deliberate resource controls. Any changed control raw record is retained and flagged.','Every gate and control verified flag must remain true.','Every case full-row transition is retained/classified. Any previously passed case becoming a nonpass blocks acceptance; transport/resource/blocked case statuses also block acceptance without suppressing reports.','Full predecessor and candidate arrays remain bound. No baseline is written.'],'commands':['python3 -B '+str(O/'replay.py')+' --selection '+str(K/'root/profile-selection-1.json')+' --attempt 1','python3 -B '+str(O/'replay.py')+' --selection '+str(K/'root/profile-selection-1.json')+' --attempt 1 --check-only'],'project_execution':False})
put('author-checks.json',{'base':BASE,'profiles':len(profiles),'cases':sum(p['cases'] for p in profiles),'controls':sum(p['controls'] for p in profiles),'immutable_files':len(immut),'tracked_runtime_paths':len(runtime),'predecessor_report_bindings_verified':True,'predecessor_policy_digests_recomputed':True,'project_imports':False,'project_execution':False,'live_edits':False})
print(json.dumps(bind(O/'contract.json')))
