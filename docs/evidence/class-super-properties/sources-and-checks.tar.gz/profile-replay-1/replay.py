#!/usr/bin/env python3
"""Root-only serial replay of eight frozen profiles; never records a baseline."""
import argparse
from collections import Counter
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import subprocess
import sys

P = Path(__file__).resolve().parent
K = P.parent
W = K / 'worktree'
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
RAW = ('status', 'phase', 'error_type', 'error_identity', 'message', 'harness')
INTEGERS = ('policy', 'done_calls', 'success_prints', 'failure_prints', 'flags', 'unhandled')
CASE_STATUSES = {'passed', 'failed', 'unsupported', 'resource', 'harness-error', 'adapter-error', 'timeout', 'blocked'}
NORMAL_CASE_STATUSES = {'passed', 'failed', 'unsupported'}
ROOTS = ('src/', 'crates/', 'assets/', 'shaders/')
BUILD_FILES = {'Cargo.toml', 'Cargo.lock', 'build.rs'}


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bound(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=digest(data))


def load_bound(binding):
    require(type(binding) is dict and set(binding) == {'path', 'bytes', 'sha256'}, 'binding schema')
    require(type(binding['path']) is str and type(binding['bytes']) is int and binding['bytes'] >= 0,
            'binding types')
    require(bound(binding['path']) == binding, 'binding changed: ' + binding['path'])
    return json.loads(Path(binding['path']).read_bytes())


def equal(a, b):
    if type(a) is not type(b):
        return False
    if type(a) is dict:
        return a.keys() == b.keys() and all(equal(a[key], b[key]) for key in a)
    if type(a) is list:
        return len(a) == len(b) and all(equal(x, y) for x, y in zip(a, b))
    return a == b


def identity(row):
    return {key: row[key] for key in IDENTITY}


def local_path(relative):
    require(type(relative) is str and relative and '\\' not in relative, 'relative source path')
    path = PurePosixPath(relative)
    require(not path.is_absolute() and all(part not in ('', '.', '..') for part in path.parts), 'source traversal')
    require(path.as_posix() == relative, 'noncanonical source path')
    result = W / relative
    require(result.resolve().is_relative_to(W.resolve()) and not result.is_symlink(), 'source outside worktree')
    return result


def source_checks(contract, selection_binding, selection):
    require(equal(load_bound(selection_binding), selection), 'selection changed')
    require(set(selection) == {'source_inventory', 'binaries'} and set(selection['binaries']) == {'ordinary', 'host'}, 'selection schema')
    inventory = load_bound(selection['source_inventory'])
    require(set(inventory) == {'base', 'scope', 'files'} and inventory['base'] == contract['base'], 'candidate source schema/base')
    require(type(inventory['scope']) is str and type(inventory['files']) is list, 'candidate source scope')
    current = {}
    for item in inventory['files']:
        require(type(item) is dict and set(item) == {'path', 'bytes', 'sha256'}, 'candidate input schema')
        relative = item['path']
        require(relative not in current, 'duplicate candidate source')
        path = local_path(relative)
        require(equal(dict(bound(path), path=relative), item), 'candidate source changed: ' + relative)
        current[relative] = item
    require(set(contract['tracked_runtime_closure']).issubset(current), 'candidate inventory omits tracked runtime/build input')
    for root in ROOTS:
        directory = W / root
        actual = {str(path.relative_to(W)) for path in directory.rglob('*') if path.is_file()}
        expected = {name for name in current if name.startswith(root)}
        require(actual == expected, 'runtime directory/inventory closure changed: ' + root)
    for item in contract['immutable_published_inputs']:
        path = local_path(item['path'])
        require(equal(dict(bound(path), path=item['path']), item), 'published tooling/corpus/baseline changed: ' + item['path'])
    immutable = {row['path']: row for row in contract['immutable_published_inputs']}
    for root in contract['exact_tree_roots']:
        actual = {str(path.relative_to(W)) for path in (W / root).rglob('*') if path.is_file()}
        expected = {name for name in immutable if name.startswith(root + '/')}
        require(actual == expected, 'exact corpus/baseline file census changed: ' + root)
    require(bound(contract['root_runner']['path']) == contract['root_runner'], 'root command runner changed')
    load_bound(contract['predecessor'])
    load_bound(contract['predecessor_contract'])
    return inventory


def binaries(contract, selection):
    result = {}
    for kind in ('ordinary', 'host'):
        sidecar = selection['binaries'][kind]
        record = load_bound(sidecar)
        require(set(record) == set(contract['binary_schema']), 'binary sidecar schema')
        require(equal(record['source_inventory'], selection['source_inventory']), 'binary/source inventory mismatch')
        load_bound(record['source_inventory'])
        binary = dict(path=record['binary'], bytes=record['bytes'], sha256=record['sha256'])
        require(bound(binary['path']) == binary, 'binary bytes changed')
        expected = contract['expected_builds'][kind]
        require(record['toolchain'] == expected['toolchain'] and equal(record['features'], expected['features']), 'binary toolchain/features')
        build = load_bound(record['build'])
        env = load_bound(record['environment'])
        command = ['cargo', '+' + expected['toolchain'], 'build', '--locked', '--offline']
        feature_args = [] if kind == 'ordinary' else ['--features', 'test262-host']
        command += feature_args + ['--release', '--bin', 'eris-js']
        require(equal(build['command'], command) and type(build['exit']) is int and build['exit'] == 0, 'successful exact release command')
        require(env['config'] == expected['config'] and env['toolchain'] == expected['toolchain']
                and equal(env['features'], feature_args), 'build environment config')
        target = 'target-msrv' if kind == 'ordinary' else 'target-1990'
        require(env['target_dir'] == str(K / target), 'build target directory')
        require(type(env['rustc']) is str and ('release: ' + expected['toolchain'] + '\n') in env['rustc'], 'rustc version receipt')
        require(Path(build['log']).name == build['log'], 'build log path')
        log = bound(Path(record['build']['path']).parent / build['log'])
        require(log['sha256'] == build['sha256'], 'build log hash')
        result[kind] = dict(binary=binary, sidecar=sidecar, record=record, build_log=log)
    return result


def binary_checks(items):
    for item in items.values():
        for binding in (item['binary'], item['sidecar'], item['record']['source_inventory'],
                        item['record']['build'], item['record']['environment'], item['build_log']):
            require(bound(binding['path']) == binding, 'binary provenance changed: ' + binding['path'])


def raw_schema(observation, host):
    require(type(observation) is dict and set(observation) == set(RAW) | ({'completion'} if host else set()), 'observation schema')
    for name in RAW:
        require(type(observation[name]) is str and len(observation[name].encode('utf-8')) <= 16384, 'bounded raw field ' + name)
    if host:
        evidence = observation['completion']
        require(type(evidence) is dict and set(evidence) == set(INTEGERS) | {'quiescent', 'audited'}, 'completion schema')
        require(all(type(evidence[name]) is int for name in INTEGERS), 'completion integer types')
        require(type(evidence['quiescent']) is bool and type(evidence['audited']) is bool, 'completion bool types')
        require(evidence['policy'] in (0, 1), 'completion policy')
        require(all(evidence[name] in (0, 1, 2) for name in ('done_calls', 'success_prints', 'failure_prints')), 'completion counts')
        require(0 <= evidence['flags'] <= 511 and 0 <= evidence['unhandled'] <= 0xffffffff, 'completion scalar bounds')
    require(observation['status'] in {'complete', 'exception', 'unsupported', 'resource', 'harness-error'} | ({'host-failure'} if host else set()), 'raw status')
    require(observation['phase'] in {'parse', 'runtime', 'harness', 'mode'} | ({'host'} if host else set()), 'raw phase')


def result_schema(row, host):
    require(type(row) is dict and set(IDENTITY).issubset(row), 'case identity schema')
    require(row['status'] in CASE_STATUSES and type(row['status']) is str, 'case classification')
    if 'observation' in row:
        require(set(row) == set(IDENTITY) | {'status', 'observation'}, 'observed case schema')
        raw_schema(row['observation'], host)
    else:
        require(set(row) in (set(IDENTITY) | {'status', 'reason'}, set(IDENTITY) | {'status', 'reason', 'stderr'}), 'unobserved case schema')
        require(type(row['reason']) is str and ('stderr' not in row or type(row['stderr']) is str), 'reason/stderr schema')
        require(row['status'] in {'unsupported', 'adapter-error', 'timeout', 'blocked'}, 'unobserved classification')


def control_checks(controls, reference, host):
    require(type(controls) is list and len(controls) == len(reference), 'control denominator')
    by_key = {}
    graph = {}
    changes = []
    for index, (row, old) in enumerate(zip(controls, reference)):
        require(type(row) is dict and set(row) == {'name', 'expected', 'verified', 'result', 'prerequisites'}, 'control schema')
        require(row['verified'] is True, 'unverified control')
        result_schema(row['result'], host)
        require('observation' in row['result'], 'control missing raw observation')
        key = (row['name'], row['result']['mode'])
        require(key not in by_key, 'duplicate control')
        require(type(row['name']) is str and type(row['expected']) is str and type(row['prerequisites']) is list, 'control scalar/list schema')
        require(row['name'] == old['name'] and row['expected'] == old['expected']
                and equal(identity(row['result']), identity(old['result']))
                and equal(row['prerequisites'], old['prerequisites']), 'ordered control identity/graph changed')
        if not equal(row, old):
            changes.append(dict(index=index, name=row['name'], mode=row['result']['mode'], before=old, after=row))
        by_key[key] = row
        graph[key] = []
    for key, row in by_key.items():
        for ref in row['prerequisites']:
            target_key = (ref['name'], ref['mode'])
            require(target_key in by_key, 'missing prerequisite target')
            target = by_key[target_key]
            require(target['verified'] is True, 'unhealthy prerequisite target')
            require(ref['case_sha256'] == target['result']['case_sha256'] and ref['source_sha256'] == target['result']['source_sha256'], 'prerequisite fingerprint')
            if 'id' in ref:
                require(ref['id'] == target['result']['id'] and ref['expected'] == target['expected'], 'prerequisite identity/semantics')
            if 'verified' in ref:
                require(ref['verified'] is True, 'prerequisite recorded unverified')
            graph[key].append(target_key)
    visited, active = set(), set()
    def visit(key):
        require(key not in active, 'prerequisite cycle')
        if key in visited:
            return
        active.add(key)
        for target in graph[key]:
            visit(target)
        active.remove(key)
        visited.add(key)
    for key in graph:
        visit(key)
    return changes


def compare(profile, before, report, binary, receipt, command):
    errors = []
    def check(value, label):
        if not value:
            errors.append(label)
    row = dict(name=profile['name'], profile=profile['profile'], errors=errors,
               case_record_changes=[], control_record_changes=[], prior_pass_regressions=[],
               newly_passed=[], nonpass_status_changes=[], raw_only_changes=[], infrastructure_cases=[])
    require(type(report) is dict and set(report) == set(before), 'report schema changed')
    for key in ('suite', 'full_test262_conformance', 'repository', 'revision', 'corpus_manifest_sha256',
                'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases'):
        check(equal(report[key], before[key]), 'immutable report field: ' + key)
    check(report['full_test262_conformance'] is False, 'full conformance overclaim')
    check(equal(report['runner_policy'], profile['policy']), 'published profile policy changed')
    check(report['runner_policy_sha256'] == profile['policy_sha256'] == digest(json.dumps(report['runner_policy'], sort_keys=True).encode()), 'policy digest')
    check(report['binary'] == binary['binary']['path'] and report['binary_sha256'] == binary['binary']['sha256'], 'report binary binding')
    check(type(report['seconds']) in (int, float) and math.isfinite(report['seconds']) and report['seconds'] >= 0, 'elapsed time schema')
    check(equal(report['regressions'], []) and equal(report['improvements'], []), 'baseline-derived report comparisons')
    cases, controls = report['cases'], report['harness_preflight']
    require(type(cases) is list and len(cases) == profile['cases'], 'case denominator')
    check(equal([identity(case) for case in cases], [identity(case) for case in before['cases']]), 'ordered case identities changed')
    check(len({case['id'] for case in cases}) == len(cases), 'duplicate case identity')
    check(equal(report['counts'], dict(Counter(case['status'] for case in cases))), 'observed counts mismatch')
    check(report['harness_preflight_passed'] is True, 'unhealthy profile gate')
    host = profile['binary_kind'] == 'host'
    if type(controls) is list:
        for index in range(max(len(controls), len(before['harness_preflight']))):
            old = before['harness_preflight'][index] if index < len(before['harness_preflight']) else None
            new = controls[index] if index < len(controls) else None
            if not equal(old, new):
                row['control_record_changes'].append(dict(index=index, before=old, after=new))
    try:
        control_checks(controls, before['harness_preflight'], host)
        check(not row['control_record_changes'], 'published raw control observations/classifications changed')
    except (KeyError, TypeError, ValueError, UnicodeError) as error:
        errors.append('control integrity: ' + str(error))
    for old, new in zip(before['cases'], cases):
        try:
            result_schema(new, host)
        except (KeyError, TypeError, ValueError, UnicodeError) as error:
            errors.append('case schema ' + str(new.get('id')) + ': ' + str(error))
        if new['status'] not in NORMAL_CASE_STATUSES:
            row['infrastructure_cases'].append(new)
        if not equal(old, new):
            transition = dict(id=new['id'], before_status=old['status'], after_status=new['status'],
                              changed_fields=[key for key in sorted(set(old) | set(new)) if not equal(old.get(key), new.get(key))], before=old, after=new)
            row['case_record_changes'].append(transition)
            if old['status'] == 'passed' and new['status'] != 'passed':
                row['prior_pass_regressions'].append(transition)
            elif old['status'] != 'passed' and new['status'] == 'passed':
                row['newly_passed'].append(transition)
            elif old['status'] != new['status']:
                row['nonpass_status_changes'].append(transition)
            else:
                row['raw_only_changes'].append(transition)
    check(not row['prior_pass_regressions'], 'prior passed cases regressed')
    check(not row['infrastructure_cases'], 'resource/adapter/timeout/blocked case result requires review')
    expected_exit = 0 if all(case['status'] == 'passed' for case in cases) and report['harness_preflight_passed'] is True else 1
    check(type(receipt['exit']) is int and receipt['exit'] == expected_exit, 'actual command exit/report mismatch')
    check(equal(receipt['command'], command) and not any('baseline' in arg for arg in command), 'exact measurement command')
    row.update(counts=report['counts'], cases=len(cases), controls=len(controls), observed_exit=receipt['exit'],
               case_arrays_equal=equal(cases, before['cases']), control_arrays_equal=equal(controls, before['harness_preflight']),
               policy_sha256=report['runner_policy_sha256'])
    return row


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--attempt', type=int, default=1)
    parser.add_argument('--check-only', action='store_true')
    args = parser.parse_args()
    require(args.attempt > 0, 'positive attempt number')
    contract_binding = bound(P / 'contract.json')
    contract = load_bound(contract_binding)
    selection_binding = bound(args.selection.resolve())
    selection = load_bound(selection_binding)
    source_checks(contract, selection_binding, selection)
    selected_binaries = binaries(contract, selection)
    destination = K / 'root' / ('profile-replay-' + str(args.attempt) + ('-recheck' if args.check_only else '') + '.json')
    require(not destination.exists(), 'summary exists; use a new attempt')
    rows = []
    for profile in contract['profiles']:
        require(bound(P / 'contract.json') == contract_binding, 'contract changed during run')
        source_checks(contract, selection_binding, selection)
        binary_checks(selected_binaries)
        before = load_bound(profile['reference_report'])
        load_bound(profile['reference_receipt'])
        require(bound(profile['reference_log']['path']) == profile['reference_log'], 'predecessor log changed')
        label = 'super-profile-' + profile['name'] + '-' + str(args.attempt)
        report_path = K / ('upstream-super-' + profile['name'] + '-' + str(args.attempt) + '.json')
        receipt_path = K / 'validation' / (label + '.json')
        log_path = K / 'validation' / (label + '.log')
        binary = selected_binaries[profile['binary_kind']]
        command = [sys.executable, '-B', 'tools/test262_conformance.py', '--binary', binary['binary']['path'],
                   '--profile', profile['profile'], '--output', str(report_path), '--jobs', '1', '--timeout', '3.0']
        if not args.check_only:
            require(not any(path.exists() for path in (report_path, receipt_path, log_path)), 'attempt output already exists')
            subprocess.run([sys.executable, '-B', contract['root_runner']['path'], label, *command], check=False)
        try:
            receipt_binding = bound(receipt_path)
            receipt = load_bound(receipt_binding)
            require(equal(receipt['command'], command) and receipt['log'] == log_path.name, 'measurement command/log path')
            log_binding = bound(log_path)
            require(log_binding['sha256'] == receipt['sha256'], 'measurement log hash')
            report_binding = bound(report_path)
            report = load_bound(report_binding)
            row = compare(profile, before, report, binary, receipt, command)
            row.update(before=profile['reference_report'], report=report_binding, receipt=receipt_binding, log=log_binding)
        except (OSError, KeyError, TypeError, ValueError, UnicodeError) as error:
            row = dict(name=profile['name'], profile=profile['profile'], errors=['retained report invalid: ' + str(error)],
                       before=profile['reference_report'], attempted_command=command,
                       retained=[bound(path) for path in (report_path, receipt_path, log_path) if path.is_file()])
        rows.append(row)
        # A binding failure stops further execution. Measurement failures remain recorded,
        # and the remaining profiles are attempted serially without overwriting this attempt.
        source_checks(contract, selection_binding, selection)
        binary_checks(selected_binaries)
        print(json.dumps(dict(profile=profile['profile'], counts=row.get('counts'), errors=row['errors'])), flush=True)
    require(len(rows) == 8, 'all eight profiles must be attempted')
    summary = dict(status='pass' if all(not row['errors'] for row in rows) else 'fail', attempt=args.attempt,
                   contract=contract_binding, runner=bound(Path(__file__)), selection=selection_binding,
                   source_inventory=selection['source_inventory'], binaries=selected_binaries,
                   predecessor=contract['predecessor'], profiles=rows, expected_cases=1330, expected_controls=724,
                   counts=dict(sum((Counter(row.get('counts', {})) for row in rows), Counter())), baseline_writes=False,
                   qualification='Measured transitions only; no predicted status totals, no baseline recording, no complete external build-graph claim. Changed control raw records and prior-pass regressions block acceptance.')
    summary['transition_counts'] = {key: sum(len(row.get(key, [])) for row in rows) for key in
                                   ('case_record_changes', 'control_record_changes', 'prior_pass_regressions',
                                    'newly_passed', 'nonpass_status_changes', 'raw_only_changes', 'infrastructure_cases')}
    with destination.open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    print(json.dumps(bound(destination)), flush=True)
    return 0 if summary['status'] == 'pass' else 1


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, KeyError, TypeError, ValueError, UnicodeError) as error:
        print('Replay binding refusal: ' + str(error), file=sys.stderr)
        raise SystemExit(2)
