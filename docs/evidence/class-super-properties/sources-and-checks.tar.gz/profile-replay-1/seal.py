from pathlib import Path
import ast,json,hashlib
K=Path('/tmp/eris-super-properties-plan-1');O=K/'profile-replay-1'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def put(name,v):(O/name).write_text(json.dumps(v,indent=2)+'\n')
c=json.loads((O/'contract.json').read_text());script=(O/'replay.py').read_text();tree=ast.parse(script)
imports=[]
for n in ast.walk(tree):
 if isinstance(n,ast.Import):imports.extend(a.name for a in n.names)
 if isinstance(n,ast.ImportFrom):imports.append(n.module)
assert set(imports)<= {'argparse','collections','hashlib','json','math','pathlib','subprocess','sys'}
assert "'--record-baseline'" not in script and "'--baseline'" not in script
rows=[]
for p in c['profiles']:
 r=json.loads(Path(p['reference_report']['path']).read_text());assert bind(Path(p['reference_report']['path']))==p['reference_report']
 by={(x['name'],x['result']['mode']):x for x in r['harness_preflight']};assert len(by)==p['controls']
 graph={k:[] for k in by};edges=0
 for key,row in by.items():
  assert row['verified'] is True
  for ref in row['prerequisites']:
   target=(ref['name'],ref['mode']);t=by[target]
   assert ref['case_sha256']==t['result']['case_sha256'] and ref['source_sha256']==t['result']['source_sha256']
   if 'id' in ref:assert ref['id']==t['result']['id'] and ref['expected']==t['expected']
   if 'verified' in ref:assert ref['verified'] is True
   graph[key].append(target);edges+=1
 active=set();visited=set()
 def visit(key):
  assert key not in active
  if key in visited:return
  active.add(key)
  for target in graph[key]:visit(target)
  active.remove(key);visited.add(key)
 for key in graph:visit(key)
 rows.append({'profile':p['profile'],'cases':len(r['cases']),'controls':len(by),'ordered_edges':edges,'canonical_graph_acyclic':True,'reference_report':p['reference_report']})
put('source-checks.json',{'base':c['base'],'ast_syntax':True,'imports':sorted(set(imports)),'repository_imports':False,'project_execution':False,'script_execution':False,'profiles':rows,'counts':{'cases':sum(x['cases'] for x in rows),'controls':sum(x['controls'] for x in rows),'edges':sum(x['ordered_edges'] for x in rows)},'selection_boundary':'Candidate/build hashes are supplied later by root through one explicit bound selection record, checked before any project dispatch; no predicted runtime outcome.','source_closure':'Candidate selected-input manifest plus all published tracked src/crates/assets/shaders/Cargo/build.rs names; all files in actual runtime directories must be inventoried. External compiler/system build graph is not claimed.','candidate_inventory_obligation':'Root candidate must include five tracked assets missing from source-parent: assets/DejaVuSans-Bold.ttf, assets/DejaVuSans.ttf, assets/DejaVuSansMono.ttf, assets/FONTS-LICENSE.txt, assets/home.html. Root notified before seal.','commands':'Serial existing runner via bound root run-tool.py; --jobs 1 --timeout 3.0; no baseline argument. Check-only inspects existing reports and writes a distinct recheck receipt.','limitations':['This is an unexecuted root recipe; AST parsing and JSON/Git provenance checks only.','Full raw control differences are preserved and fail closed against published expected observations. A legitimate diagnostic difference requires separate review; the recipe never silently loosens it.','Successful bookkeeping does not mean all upstream cases pass; observed per-profile nonpasses remain in reports and transition arrays.','Resource controls are expected negative controls and may be healthy; resource case outcomes require review.']})
files=[dict(bind(p),path=str(p.relative_to(O))) for p in sorted(O.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',{'format':1,'status':'sealed_source_only_root_replay_recipe','base':c['base'],'contract':bind(O/'contract.json'),'runner':bind(O/'replay.py'),'checks':bind(O/'source-checks.json'),'files':files,'profiles':8,'cases':1330,'controls':724,'baseline_writes':False,'project_execution':False,'live_edits':False})
print(json.dumps(bind(O/'source-ready.json')))
