function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',outer={},inner={},seen;class C { add(){return super.x+=(trace+='R',2);} side(){return super.y;} }
var A={get x(){trace+='G';check(C.prototype.side.call(inner)===inner);Object.setPrototypeOf(C.prototype,B);return 3;},get y(){trace+='Y';return this;},set x(v){trace+='S';seen=this;check(v===5);}};
var B={set x(v){throw 'retarget';}};Object.setPrototypeOf(C.prototype,A);
check(C.prototype.add.call(outer)===5&&seen===outer);return trace;
})();
