function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='C';throw 'conversion';};
class A { get x(){trace+='G';return 1;} }
class C extends A { remove(){return delete (super[(trace+='K',key)]);} type(){return typeof super.x;} }
var c=new C();expect(ReferenceError,()=>c.remove());check(c.type()==='number'&&Object.getOwnPropertyDescriptor(A.prototype,'x')!==undefined);return trace;
})();
