var object={get x(){return ()=>super.x;}};
