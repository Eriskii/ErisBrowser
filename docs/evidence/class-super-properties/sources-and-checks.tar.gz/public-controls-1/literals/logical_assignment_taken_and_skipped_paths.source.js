function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',stored,key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { get x(){trace+='G';return stored;} set x(v){trace+='S';stored=v;} }
class C extends A { and(){return super[(trace+='K',key)]&&=(trace+='R',7);} or(){return super[(trace+='K',key)]||=(trace+='R',7);} nullish(){return super[(trace+='K',key)]??=(trace+='R',7);} }
var c=new C(),out=[];
function run(name,initial,want){trace='';stored=initial;check(c[name]()===want&&stored===want);out.push(trace);}
run('and',0,0);run('and',2,7);run('or',2,2);run('or',0,7);run('nullish',false,false);run('nullish',null,7);run('nullish',undefined,7);
return out.join('|');
})();
