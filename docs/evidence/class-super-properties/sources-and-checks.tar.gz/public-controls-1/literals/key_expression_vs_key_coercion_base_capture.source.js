function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='';class C { read(key){return super[key];} changed(){return super[(trace+='E',Object.setPrototypeOf(C.prototype,B),'x')];} }
var A={x:'A'},B={x:'B'},D={x:'D'};
Object.setPrototypeOf(C.prototype,A);check(C.prototype.changed.call({})==='B');
Object.setPrototypeOf(C.prototype,A);
var key={};key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='C';Object.setPrototypeOf(C.prototype,D);return 'x';};
check(C.prototype.read.call({},key)==='A');check(C.prototype.read.call({},'x')==='D');
return trace;
})();
