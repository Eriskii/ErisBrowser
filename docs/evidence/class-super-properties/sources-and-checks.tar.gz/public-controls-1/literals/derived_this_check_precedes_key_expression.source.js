function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='';class A { get x(){trace+='G';return this;} }
class C extends A { constructor(){try{super[(trace+='K','x')];}catch(e){check(e instanceof ReferenceError);trace+='T';}super();check(super[(trace+='k','x')]===this);trace+='B';} }
new C();return trace;
})();
