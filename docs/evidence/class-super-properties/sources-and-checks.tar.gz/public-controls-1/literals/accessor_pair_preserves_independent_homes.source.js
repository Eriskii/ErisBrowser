function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var seen;class A { get x(){return super.value;} }class B { set x(v){super.value=v;} }
Object.setPrototypeOf(A.prototype,{value:'A'});Object.setPrototypeOf(B.prototype,{set value(v){seen=this;this.received='B'+v;}});
var descriptor={get:Object.getOwnPropertyDescriptor(A.prototype,'x').get,set:Object.getOwnPropertyDescriptor(B.prototype,'x').set,configurable:true};
var receiver={};Object.defineProperty(receiver,'x',descriptor);check(receiver.x==='A');receiver.x=7;check(seen===receiver&&receiver.received==='B7');
Object.setPrototypeOf(A.prototype,{value:'C'});check(receiver.x==='C');receiver.x=8;check(receiver.received==='B8');return 'get:A:C|set:B';
})();
