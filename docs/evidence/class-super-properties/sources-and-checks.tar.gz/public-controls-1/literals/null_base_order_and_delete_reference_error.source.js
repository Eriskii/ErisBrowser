function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class C { read(){return super[(trace+='K',key)];} write(){return super[(trace+='K',key)]=(trace+='R',1);} remove(){return delete super[(trace+='K',key)];} type(){return typeof super[(trace+='K',key)];} }
Object.setPrototypeOf(C.prototype,null);var c=new C(),parts=[];
expect(TypeError,()=>c.read());parts.push(trace);trace='';expect(TypeError,()=>c.write());parts.push(trace);trace='';expect(ReferenceError,()=>c.remove());parts.push(trace);trace='';expect(TypeError,()=>c.type());parts.push(trace);
return parts.join('|');
})();
