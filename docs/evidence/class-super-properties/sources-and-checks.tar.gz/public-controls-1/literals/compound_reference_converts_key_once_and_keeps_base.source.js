function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',key={},receiver={},seen,old={valueOf:function(){trace+='V';return 4;}};
class A { get x(){trace+='G';return old;} set x(v){trace+='S';seen=this;check(v===7);} }
class C extends A { add(){return super[(trace+='K',key)]+=(trace+='R',Object.setPrototypeOf(C.prototype,{set x(v){throw 'retarget';}}),3);} }
key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
check(C.prototype.add.call(receiver)===7&&seen===receiver);return trace;
})();
