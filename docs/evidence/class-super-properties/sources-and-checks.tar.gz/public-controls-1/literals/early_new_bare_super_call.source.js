sentinel=1;
class C extends Object { constructor(){return new super();} }
