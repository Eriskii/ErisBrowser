sentinel=1;
class C { m(){return super;} }
