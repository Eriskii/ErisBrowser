function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='';
class Base { constructor(v=super.seed){this.v=v;trace+='B';} }
Object.setPrototypeOf(Base.prototype,{seed:3});check(new Base().v===3);
class A { constructor(){trace+='A';this.tag=4;} get seed(){trace+='G';return this.tag;} }
class C extends A { constructor(v=(super(),super.seed)){trace+='C';this.v=v;} method(v=super.seed){return v;} arrow(){return (v=super.seed)=>v;} }
var c=new C();check(c.v===4&&c.method()===4&&c.arrow()()===4);
return trace;
})();
