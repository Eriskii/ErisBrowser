function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',value={valueOf:function(){trace+='V';return 260;}};class C { write(k,v){return super[k]=v;} }
var base={};Object.defineProperty(base,'0',{value:0,writable:true});Object.defineProperty(base,'2',{value:0,writable:true});Object.setPrototypeOf(C.prototype,base);
var a=new Uint8Array(2);check(C.prototype.write.call(a,'0',value)===value&&a[0]===4);expect(TypeError,()=>C.prototype.write.call(a,'2',value));check(trace==='V'&&a.length===2&&a[2]===undefined);
Object.defineProperty(base,'1',{value:0,writable:false});expect(TypeError,()=>C.prototype.write.call(a,'1',value));check(a[1]===0);return trace;
})();
