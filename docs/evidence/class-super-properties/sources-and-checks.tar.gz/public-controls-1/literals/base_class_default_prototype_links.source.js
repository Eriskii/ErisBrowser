function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C { objectString(){return super.toString();} static invoke(receiver){return super.call(receiver);} }
var c=new C();check(c.objectString()==='[object Object]');expect(TypeError,()=>C.invoke({}));
var seen;function fn(){seen=this;return 8;}var receiver={};check(C.invoke.call(fn,receiver)===8&&seen===receiver);return 'Object:Function';
})();
