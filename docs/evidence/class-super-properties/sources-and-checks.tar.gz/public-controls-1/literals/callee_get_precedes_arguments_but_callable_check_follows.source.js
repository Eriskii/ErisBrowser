function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',marker={};class A { get x(){trace+='G';return 1;} get y(){trace+='H';throw marker;} }
class C extends A { bad(){return super.x((trace+='A',2));} abrupt(){return super.y((trace+='X',2));} }
var c=new C();try{c.bad();}catch(e){check(e instanceof TypeError);trace+='T';}var caught=false;try{c.abrupt();}catch(e){check(e===marker);caught=true;}check(caught);return trace;
})();
