function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var initialize,read,trace='',alternate={};
class A { constructor(){trace+='A';this.tag='A';} }
class B { constructor(){trace+='B';this.tag='B';check(new.target===Target);} }
class C extends A { constructor(){initialize=()=>super();read=()=>super.x;return alternate;} }
function Target(){}Target.prototype={target:true};
check(Reflect.construct(C,[],Target)===alternate);
expect(ReferenceError,()=>read());
Object.setPrototypeOf(C,B);Object.setPrototypeOf(C.prototype,{get x(){return this.tag;}});
var instance=initialize();check(Object.getPrototypeOf(instance)===Target.prototype&&read()==='B');
expect(ReferenceError,()=>initialize());
return trace;
})();
