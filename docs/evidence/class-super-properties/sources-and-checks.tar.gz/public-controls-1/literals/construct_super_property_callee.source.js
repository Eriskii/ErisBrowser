function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',seen;function Target(v){trace+='C';check(new.target===Target);this.v=v;seen=this;}
class A { get ctor(){trace+='G';return Target;} get bad(){trace+='B';return ()=>0;} }
class C extends A { build(){return new super.ctor((trace+='A',6));} bad(){return new super.bad((trace+='X',7));} }
var c=new C(),made=c.build();check(made===seen&&made.v===6&&Object.getPrototypeOf(made)===Target.prototype);
expect(TypeError,()=>c.bad());return trace;
})();
