function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',stored=4,key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { get x(){trace+='G';return stored;} set x(v){trace+='S';stored=v;} }
class C extends A { pre(){return ++super[(trace+='K',key)];} post(){return super[(trace+='K',key)]++;} down(){return --super[(trace+='K',key)];} postDown(){return super[(trace+='K',key)]--;} }
var c=new C();check(c.pre()===5&&c.post()===5&&c.down()===5&&c.postDown()===5&&stored===4);return trace;
})();
