function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',values=[],key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';values.push(v);} }
class C extends A { run(){for(super[(trace+='K',key)] in {a:1,b:2}){trace+='B';}} }
new C().run();check(values.join(',')==='a,b');return trace;
})();
