function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C { write(k,v){return super[k]=v;} push(v){return super.push(v);} }
var base={};Object.defineProperty(base,'2',{value:0,writable:true});Object.defineProperty(base,'length',{value:0,writable:true});base.push=Array.prototype.push;Object.setPrototypeOf(C.prototype,base);
var a=[];C.prototype.write.call(a,'2',7);check(a.length===3&&a[2]===7);C.prototype.write.call(a,'length',1);check(a.length===1&&a[2]===undefined);check(C.prototype.push.call(a,8)===2&&a[1]===8);
Object.defineProperty(a,'length',{writable:false});expect(TypeError,()=>C.prototype.write.call(a,'2',9));check(a.length===2&&a[2]===undefined);return 'array:2:8';
})();
