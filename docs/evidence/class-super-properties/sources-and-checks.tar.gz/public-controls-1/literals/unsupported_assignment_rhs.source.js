var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';} }class C extends A { run(){return super[(trace+='K',key)]=(trace+='R',eval('1'));} }

try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
