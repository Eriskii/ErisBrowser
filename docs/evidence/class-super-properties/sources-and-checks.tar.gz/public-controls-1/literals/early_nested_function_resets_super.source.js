sentinel=1;
class C { m(){return function(){return super.x;};} }
