function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',seen;
class A { get x(){trace+='G';seen=this;return this.mark;} set x(v){trace+='S';seen=this;this.received=v;return 900;} }
class C extends A { get x(){return super.x;} set x(v){super.x=v;} write(v){return super.x=v;} }
var receiver={mark:7};Object.defineProperty(receiver,'x',{value:40,writable:false});
var d=Object.getOwnPropertyDescriptor(C.prototype,'x');
check(d.get.call(receiver)===7&&seen===receiver);
d.set.call(receiver,8);check(receiver.received===8&&seen===receiver);
check(C.prototype.write.call(receiver,9)===9&&receiver.received===9&&receiver.x===40);
return trace;
})();
