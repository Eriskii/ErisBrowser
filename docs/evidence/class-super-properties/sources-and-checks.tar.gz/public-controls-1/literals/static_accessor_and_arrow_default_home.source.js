function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',receiver={tag:'R'};
class A { static get x(){trace+='G';return this.tag;} static set x(v){trace+='S';this.tag=v;} }
class C extends A { static get x(){trace+='g';return super.x;} static set x(v){trace+='s';super.x=v;} static arrow(){return (v=super.x)=>super.x=v;} }
var d=Object.getOwnPropertyDescriptor(C,'x');check(d.get.call(receiver)==='R');d.set.call(receiver,'V');check(receiver.tag==='V');
var arrow=C.arrow.call(receiver);Object.setPrototypeOf(C,{get x(){trace+='H';return this.tag+'!';},set x(v){trace+='T';this.tag=v;}});
check(arrow.call({tag:'wrong'})==='V!'&&receiver.tag==='V!');return trace;
})();
