function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { get x(){return this.marker;} }
class C extends A { constructor(){super();this.marker=6;this.seen=super.x;} }
function Target(){}Target.prototype={get x(){throw 'wrong prototype';}};
var made=Reflect.construct(C,[],Target);check(Object.getPrototypeOf(made)===Target.prototype&&made.seen===6);return 'newtarget:receiver:home';
})();
