function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C { read(){return super.data;} write(v){return super.data=v;} append(v){return super.appendData(v);} length(){return super.length;} }
Object.setPrototypeOf(C.prototype,CharacterData.prototype);var text=new Text('ab');
check(C.prototype.read.call(text)==='ab');check(C.prototype.write.call(text,'x')==='x');check(C.prototype.append.call(text,'yz')===undefined);check(C.prototype.read.call(text)==='xyz'&&C.prototype.length.call(text)===3);
expect(TypeError,()=>C.prototype.read.call({}));expect(TypeError,()=>C.prototype.write.call({},'bad'));expect(TypeError,()=>C.prototype.append.call({},'bad'));return 'xyz:3';
})();
