function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',marker={},key={},source={},index=0;
key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
var iterator={next:function(){trace+='N';index++;return {value:index,done:false};},return:function(){trace+='R';return {};}};source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { set x(v){trace+='S';if(v===2)throw marker;} }
class C extends A { run(){for(super[(trace+='K',key)] of source){trace+='B';}} }
var caught=false;try{new C().run();}catch(e){caught=true;check(e===marker);}check(caught);return trace;
})();
