function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',receiver={},key={},A={},B={},D={},seen;
Object.defineProperty(B,'x',{set:function(v){trace+='S';seen=this;check(v===9);}});
Object.defineProperty(D,'x',{set:function(){throw 'retarget';}});
class C { write(){return super[(trace+='K',Object.setPrototypeOf(C.prototype,B),key)]=(trace+='R',Object.setPrototypeOf(C.prototype,D),9);} }
Object.setPrototypeOf(C.prototype,A);
key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='C';Object.setPrototypeOf(C.prototype,A);return 'x';};
check(C.prototype.write.call(receiver)===9&&seen===receiver);return trace;
})();
