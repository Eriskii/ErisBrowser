function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',marker={},stage=0,key={};
function keyValue(){trace+='K';if(stage===0)throw marker;return key;}
function rhs(){trace+='R';if(stage===1)throw marker;return 1;}
key[Symbol.toPrimitive]=function(){trace+='C';if(stage===2)throw marker;return 'x';};
class A { set x(v){trace+='S';throw marker;} }
class C extends A { write(){super[keyValue()]=rhs();} }
var c=new C(),parts=[];for(stage=0;stage<4;stage++){trace='';var caught=false;try{c.write();}catch(e){caught=true;check(e===marker);}check(caught);parts.push(trace);}return parts.join('|');
})();
