function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C extends Promise { bridge(f){return super.then(f);} }
var trace='S',p=C.resolve(4),q=p.bridge(function(v){check(v===4);trace+='F';});check(q instanceof C);
expect(TypeError,()=>C.prototype.bridge.call({},function(){trace+='bad';}));trace+='X';trace+='E';
return {read:function(){return trace;}};
})();
