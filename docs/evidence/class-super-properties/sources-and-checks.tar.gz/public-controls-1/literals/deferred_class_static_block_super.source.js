class C { static { super.x; } }
