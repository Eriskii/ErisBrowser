function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { static get value(){return this.tag;} static method(){return this;} }
class C extends A { static read(){return super.value;} static call(){return super.method();} }
var receiver={tag:'R',value:'shadow'},saved=C.read;
check(saved.call(receiver)==='R'&&C.call.call(receiver)===receiver);
var replacement={get value(){return 'N'+this.tag;}};
Object.setPrototypeOf(C,replacement);
check(saved.call(receiver)==='NR');
Object.setPrototypeOf(receiver,{value:'wrong'});
check(saved.call(receiver)==='NR');
return 'static:live';
})();
