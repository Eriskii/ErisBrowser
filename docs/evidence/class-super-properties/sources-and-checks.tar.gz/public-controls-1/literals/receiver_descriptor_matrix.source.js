function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var setterCalls=0,protoSetter=0;class C { write(k,v){return super[k]=v;} }
var base={};Object.defineProperty(base,'w',{value:1,writable:true});Object.defineProperty(base,'r',{value:2,writable:false});Object.defineProperty(base,'g',{get:function(){return 3;}});Object.defineProperty(base,'s',{set:function(v){setterCalls++;this.received=v;}});Object.setPrototypeOf(C.prototype,base);
var write=C.prototype.write,own={};Object.defineProperty(own,'w',{value:4,writable:true,enumerable:false,configurable:false});check(write.call(own,'w',5)===5);var d=Object.getOwnPropertyDescriptor(own,'w');check(d.value===5&&d.writable&&!d.enumerable&&!d.configurable&&base.w===1);
var readonly={};Object.defineProperty(readonly,'w',{value:6,writable:false});expect(TypeError,()=>write.call(readonly,'w',9));check(readonly.w===6);
var accessor={};Object.defineProperty(accessor,'w',{set:function(){setterCalls++;}});expect(TypeError,()=>write.call(accessor,'w',9));check(setterCalls===0);
var inherited=Object.create({set w(v){protoSetter++;}});write.call(inherited,'w',8);d=Object.getOwnPropertyDescriptor(inherited,'w');check(d.value===8&&d.writable&&d.enumerable&&d.configurable&&protoSetter===0);
var fixed={w:7};Object.preventExtensions(fixed);write.call(fixed,'w',8);check(fixed.w===8);expect(TypeError,()=>write.call(fixed,'missing',9));
expect(TypeError,()=>write.call({},'r',9));expect(TypeError,()=>write.call({},'g',9));
Object.defineProperty(readonly,'s',{value:0,writable:false});write.call(readonly,'s',11);check(setterCalls===1&&readonly.received===11&&readonly.s===0);
return 'own:inherited:fixed:accessor';
})();
