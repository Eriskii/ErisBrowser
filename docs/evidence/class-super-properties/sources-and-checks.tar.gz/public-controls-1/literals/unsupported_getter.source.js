var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
class A { get x(){trace+='G';return eval('1');} }class C extends A { run(){return super[(trace+='K','x')];} }

try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
