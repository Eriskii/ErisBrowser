function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C { write(v){return super[0]=v;} }Object.setPrototypeOf(C.prototype,{0:0});
return (function(a){C.prototype.write.call(arguments,9);var first=a,saved=arguments[0];a=5;return first+':'+saved+':'+arguments[0];})(1);
})();
