function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var expected,seen,received;class A { get x(){seen=this;return this;} set x(v){seen=this;received=v;} }
class C extends A { read(){return super.x;} write(v){return super.x=v;} data(v){return super.d=v;} missing(){return super.absent;} }
Object.defineProperty(A.prototype,'d',{value:1,writable:true});var values=[undefined,null,7,'s',Symbol('r')];
for(var i=0;i<values.length;i++){expected=values[i];check(C.prototype.read.call(expected)===expected&&seen===expected);check(C.prototype.write.call(expected,9)===9&&seen===expected&&received===9);expect(TypeError,()=>C.prototype.data.call(expected,9));check(C.prototype.missing.call(expected)===undefined);}
return 'five:primitive:receivers';
})();
