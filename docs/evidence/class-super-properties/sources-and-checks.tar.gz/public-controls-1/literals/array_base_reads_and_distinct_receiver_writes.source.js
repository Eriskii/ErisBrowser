function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base=[3],receiver={};Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call(receiver,'0')===3&&C.prototype.read.call(receiver,'length')===1);C.prototype.write.call(receiver,'0',8);C.prototype.write.call(receiver,'length',9);
check(receiver[0]===8&&receiver.length===9&&base[0]===3&&base.length===1);return 'array:base:receiver';
})();
