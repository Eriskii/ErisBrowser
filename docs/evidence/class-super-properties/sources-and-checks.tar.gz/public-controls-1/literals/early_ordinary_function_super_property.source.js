sentinel=1;
function f(){return super.x;}
