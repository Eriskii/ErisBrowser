result.read()
