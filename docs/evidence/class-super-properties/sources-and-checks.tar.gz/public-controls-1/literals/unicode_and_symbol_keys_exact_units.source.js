function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var lone='\uD800',symbol=Symbol(lone),other=Symbol(lone),trace='',key={};
class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base={};base['雪']=1;base[lone]=2;base[symbol]=3;Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call({},'雪')===1&&C.prototype.read.call({},lone)===2&&C.prototype.read.call({},symbol)===3&&C.prototype.read.call({},other)===undefined);
key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='K';return symbol;};var receiver={};C.prototype.write.call(receiver,key,4);check(receiver[symbol]===4&&base[symbol]===3&&lone.charCodeAt(0)===55296);return trace;
})();
