function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
function make(parent){class C { read(){return super.x;} }Object.setPrototypeOf(C.prototype,parent);return C;}
var A=make({x:'A'}),B=make({x:'B'}),a=A.prototype.read,b=B.prototype.read;
check(a.call(B.prototype)==='A'&&b.call(A.prototype)==='B');
A.prototype.read=function(){return 'replacement';};delete B.prototype.read;
check(a.call({})==='A'&&b.call({})==='B');
Object.setPrototypeOf(A.prototype,{x:'C'});
check(a.call({})==='C'&&b.call({})==='B');
return 'distinct:saved';
})();
