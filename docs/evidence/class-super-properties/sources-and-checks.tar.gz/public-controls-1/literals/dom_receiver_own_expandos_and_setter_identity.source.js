function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var seen;class C { write(k,v){return super[k]=v;} }
var symbol=Symbol('node'),base={};Object.defineProperty(base,'extra',{value:0,writable:true});Object.defineProperty(base,'sink',{set:function(v){seen=this;this.received=v;}});Object.setPrototypeOf(C.prototype,base);
var text=new Text('ab');C.prototype.write.call(text,'extra',7);C.prototype.write.call(text,symbol,8);C.prototype.write.call(text,'sink',9);
check(text.extra===7&&text[symbol]===8&&seen===text&&text.received===9&&text.data==='ab');var d=Object.getOwnPropertyDescriptor(text,'extra');check(d.value===7&&d.writable&&d.enumerable&&d.configurable);return 'node:identity';
})();
