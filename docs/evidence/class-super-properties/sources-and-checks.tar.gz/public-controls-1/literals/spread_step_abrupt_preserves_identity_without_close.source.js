function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',marker={},source={},iterator={next:function(){trace+='N';throw marker;},return:function(){trace+='R';return {};}};
source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { get f(){trace+='G';return function(){trace+='F';};} }
class C extends A { call(){return super.f(...source);} }
var caught=false;try{new C().call();}catch(e){caught=true;check(e===marker);}check(caught);return trace;
})();
