sentinel=1;
class C extends Object { m(){super();} }
