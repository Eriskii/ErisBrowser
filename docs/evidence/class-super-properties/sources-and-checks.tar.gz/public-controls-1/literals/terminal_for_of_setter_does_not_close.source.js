var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var source={},iterator={next:function(){trace+='N';return {value:1,done:false};},return:function(){trace+='R';return {};}};source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { set x(v){trace+='S';spin();} }class C extends A { run(){for(super.x of source){trace+='B';}} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
