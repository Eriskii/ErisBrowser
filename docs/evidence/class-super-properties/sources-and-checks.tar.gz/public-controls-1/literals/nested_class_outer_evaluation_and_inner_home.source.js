function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='';class Parent { value(){return 'inner';} }
class A { get parent(){trace+='H';return Parent;} get key(){trace+='K';return 'm';} }
class C extends A { make(){return class D extends super.parent { [super.key](){return super.value();} };} }
var D=new C().make();check(new D().m()==='inner');return trace;
})();
