function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',value={valueOf:function(){trace+='V';return 9;}};class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base=new Uint8Array([3]),receiver={};Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call(receiver,'0')===3);check(C.prototype.write.call(receiver,'0',value)===value&&receiver[0]===value&&base[0]===3&&trace==='');
C.prototype.write.call(receiver,'1',value);C.prototype.write.call(receiver,'-0',value);check(!Object.prototype.hasOwnProperty.call(receiver,'1')&&!Object.prototype.hasOwnProperty.call(receiver,'-0')&&trace==='');
C.prototype.write.call(base,'1',value);check(trace==='V'&&base[0]===3&&base[1]===undefined);
var symbol=Symbol('extra');C.prototype.write.call(receiver,'01',7);C.prototype.write.call(receiver,symbol,8);check(receiver['01']===7&&receiver[symbol]===8);return trace;
})();
