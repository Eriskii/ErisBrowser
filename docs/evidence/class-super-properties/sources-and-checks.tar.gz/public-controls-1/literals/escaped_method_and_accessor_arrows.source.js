function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { get x(){return this.tag;} }
class C extends A { arrow(){return ()=>super.x;} get arrowGetter(){return ()=>super.x;} }
var receiver={tag:'R'},a=C.prototype.arrow.call(receiver);
var b=Object.getOwnPropertyDescriptor(C.prototype,'arrowGetter').get.call(receiver);
check(a.call({tag:'wrong'})==='R'&&b()==='R');
Object.setPrototypeOf(C.prototype,{get x(){return 'N'+this.tag;}});
check(a()==='NR'&&b.call(null)==='NR');
return 'arrow:receiver:live';
})();
