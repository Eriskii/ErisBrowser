class C { async m(){return super.x;} }
