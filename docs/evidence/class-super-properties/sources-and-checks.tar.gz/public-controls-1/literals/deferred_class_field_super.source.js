class C { x=super.x; }
