var object={m(){return super.x;}};
