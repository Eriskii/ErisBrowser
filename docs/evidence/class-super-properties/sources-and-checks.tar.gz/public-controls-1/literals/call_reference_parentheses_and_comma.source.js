function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { method(){check(new.target===undefined);return this;} }
class C extends A { paren(){return (super.method)();} comma(){return (0,super.method)();} }
var receiver={};check(C.prototype.paren.call(receiver)===receiver);check(C.prototype.comma.call(receiver)===undefined);return 'reference:lost';
})();
