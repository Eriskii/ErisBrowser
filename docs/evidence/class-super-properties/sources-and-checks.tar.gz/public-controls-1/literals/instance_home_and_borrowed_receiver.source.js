function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { get value(){return this.tag;} method(){return this;} }
class C extends A { read(){return super.value;} call(){return super.method();} }
var receiver={tag:'receiver',value:'shadow',method:function(){throw 'shadow';}};
var inherited={value:'wrong',method:function(){throw 'receiver prototype';}};
Object.setPrototypeOf(receiver,inherited);
check(C.prototype.read.call(receiver)==='receiver');
check(C.prototype.call.apply(receiver,[])===receiver);
check(C.prototype.call.bind(receiver)()===receiver);
var replacement={get value(){return 'live:'+this.tag;},method:function(){return this;}};
Object.setPrototypeOf(C.prototype,replacement);
check(C.prototype.read.call(receiver)==='live:receiver');
return 'home:receiver:live';
})();
