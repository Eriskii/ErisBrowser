function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='';
class A { constructor(){trace+='A';this.tag='a';} }
class B { constructor(){trace+='B';this.tag='b';} }
class C extends A { constructor(){super();trace+=super.label;this.read=()=>super.label;} }
Object.setPrototypeOf(C,B);Object.setPrototypeOf(C.prototype,{get label(){return this.tag+'P';}});
var c=new C();check(c.read()==='bP'&&Object.getPrototypeOf(c)===C.prototype);
Object.setPrototypeOf(C.prototype,{label:'Q'});check(c.read()==='Q');
return trace;
})();
