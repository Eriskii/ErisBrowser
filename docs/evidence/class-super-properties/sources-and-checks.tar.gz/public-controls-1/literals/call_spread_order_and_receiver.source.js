function check(v){if(!v)throw new Error('super property oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',receiver={},iterator={},source={};var n=0;
iterator.next=function(){trace+='N';n++;return n===1?{value:2,done:false}:{done:true};};
source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { get f(){trace+='G';return function(a,b,c){trace+='F';check(this===receiver&&a===1&&b===2&&c===3);return 9;};} }
class C extends A { call(){return super.f((trace+='A',1),...source,(trace+='Z',3));} }
check(C.prototype.call.call(receiver)===9);return trace;
})();
