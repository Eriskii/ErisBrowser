//! Held adapter proposal only. Root selects module wiring and executable payload.
//! No test invocation or literal conversion is included in this proposal.
use super::*;

fn execute_mode(runtime: &mut Runtime, document: &mut Document, strict: bool, source: &str) -> Result<Value> {
    if strict { runtime.execute_strict(source, document) } else { runtime.execute(source, document) }
}

fn observe(case_id: &str, source: &str, readback: &str, sloppy: &str, strict_expected: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, source)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} source: {error:?}"));
        let result = execute_mode(&mut runtime, &mut document, strict, readback)
            .unwrap_or_else(|error| panic!("{case_id} strict={strict} readback: {error:?}"));
        let expected = if strict { strict_expected } else { sloppy };
        assert_eq!(result, Value::String(expected.into()), "{case_id} strict={strict}");
    }
}

fn early_error(case_id: &str, setup: &str, source: &str, readback: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, setup).unwrap();
        let error = execute_mode(&mut runtime, &mut document, strict, source)
            .expect_err("invalid SuperProperty context completed");
        assert_eq!(error.intrinsic_error_name(), Some("SyntaxError"), "{case_id} strict={strict}");
        assert!(error.is_parse_error(), "{case_id} strict={strict}: {error:?}");
        let observed = execute_mode(&mut runtime, &mut document, strict, readback).unwrap();
        assert_eq!(observed, Value::Number(0.0), "{case_id} strict={strict}");
    }
}

fn deferred(case_id: &str, source: &str) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let error = execute_mode(&mut runtime, &mut document, strict, source)
            .expect_err("deferred valid syntax completed");
        assert!(error.is_unsupported(), "{case_id} strict={strict}: {error:?}");
        // No JS readback after a terminal Unsupported refusal.
    }
}

fn retained<'a>(runtime: &'a Runtime, name: &str) -> &'a Value {
    &runtime.environments[0].bindings.get(name)
        .unwrap_or_else(|| panic!("retained global {name} was never initialized")).value
}

fn fatal(case_id: &str, source: &str, expected_trace: &str, unsupported: bool) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        let error = execute_mode(&mut runtime, &mut document, strict, source)
            .expect_err("fatal source completed");
        assert_eq!(error.is_unsupported(), unsupported, "{case_id} strict={strict}: {error:?}");
        assert_eq!(error.is_resource_limit(), !unsupported, "{case_id} strict={strict}: {error:?}");
        if !unsupported {
            assert_eq!(error.message, "script instruction limit exceeded");
            assert_eq!(runtime.steps, 0);
        }
        assert!(runtime.microtasks_suspended(), "{case_id} strict={strict}");
        assert!(runtime.console.is_empty());
        assert_eq!((runtime.frames.len(), runtime.calls, runtime.eval_depth, runtime.stack_units), (0, 0, 0, 0));
        assert_eq!(runtime.microtasks.author_depth, 0);
        assert!(!runtime.microtasks.performing_checkpoint);
        // Borrowed reads only: no second execute, checkpoint or allowance reset.
        assert_eq!(retained(&runtime, "trace"), &Value::String(expected_trace.into()), "{case_id} strict={strict}");
        for name in ["caught", "finalized", "after", "queuedRan"] {
            assert_eq!(retained(&runtime, name), &Value::Number(0.0), "{case_id} strict={strict} {name}");
        }
        assert_eq!(runtime.microtasks.queue.len(), 1);
        let Some(promises::QueueJob::Callback(callback)) = runtime.microtasks.queue.front() else {
            panic!("{case_id} strict={strict}: saved queued callback missing");
        };
        assert_eq!(callback, retained(&runtime, "queued"));
    }
}
