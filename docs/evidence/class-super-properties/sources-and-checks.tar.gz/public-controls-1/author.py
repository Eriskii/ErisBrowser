#!/usr/bin/env python3
"""Independent literal authoring; stdlib only, never executes project/JS code."""
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
BASE = 'db02f8c890a459b979378900f113b67460a49121'
WORKTREE = ROOT.parent / 'worktree'
ROWS = []
PRELUDE = "function check(v){if(!v)throw new Error('super property oracle');}\nfunction expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}\n"

def semantic(name, body, expected, purpose, *, strict_expected=None, prerequisites=()):
    source = PRELUDE + 'var result=(function(){\n' + body.strip() + '\n})();\n'
    row = dict(id=name, family='semantic', modes=['sloppy','strict'], source=source,
               readback='result\n', expected=dict(sloppy=expected, strict=expected if strict_expected is None else strict_expected),
               purpose=purpose, prerequisites=list(prerequisites))
    ROWS.append(row)

semantic('instance_home_and_borrowed_receiver', r"""
class A { get value(){return this.tag;} method(){return this;} }
class C extends A { read(){return super.value;} call(){return super.method();} }
var receiver={tag:'receiver',value:'shadow',method:function(){throw 'shadow';}};
var inherited={value:'wrong',method:function(){throw 'receiver prototype';}};
Object.setPrototypeOf(receiver,inherited);
check(C.prototype.read.call(receiver)==='receiver');
check(C.prototype.call.apply(receiver,[])===receiver);
check(C.prototype.call.bind(receiver)()===receiver);
var replacement={get value(){return 'live:'+this.tag;},method:function(){return this;}};
Object.setPrototypeOf(C.prototype,replacement);
check(C.prototype.read.call(receiver)==='live:receiver');
return 'home:receiver:live';
""", 'home:receiver:live', 'Borrowing/binding does not change home; own/receiver-prototype shadows cannot redirect lookup; home prototype remains live.')

semantic('static_home_is_original_constructor', r"""
class A { static get value(){return this.tag;} static method(){return this;} }
class C extends A { static read(){return super.value;} static call(){return super.method();} }
var receiver={tag:'R',value:'shadow'},saved=C.read;
check(saved.call(receiver)==='R'&&C.call.call(receiver)===receiver);
var replacement={get value(){return 'N'+this.tag;}};
Object.setPrototypeOf(C,replacement);
check(saved.call(receiver)==='NR');
Object.setPrototypeOf(receiver,{value:'wrong'});
check(saved.call(receiver)==='NR');
return 'static:live';
""", 'static:live', 'Static home is constructor identity, independent of borrowed receiver and its prototype.')

semantic('accessor_receiver_and_setter_result', r"""
var trace='',seen;
class A { get x(){trace+='G';seen=this;return this.mark;} set x(v){trace+='S';seen=this;this.received=v;return 900;} }
class C extends A { get x(){return super.x;} set x(v){super.x=v;} write(v){return super.x=v;} }
var receiver={mark:7};Object.defineProperty(receiver,'x',{value:40,writable:false});
var d=Object.getOwnPropertyDescriptor(C.prototype,'x');
check(d.get.call(receiver)===7&&seen===receiver);
d.set.call(receiver,8);check(receiver.received===8&&seen===receiver);
check(C.prototype.write.call(receiver,9)===9&&receiver.received===9&&receiver.x===40);
return trace;
""", 'GSS', 'Inherited setter uses actual receiver and wins over receiver own nonwritable data; assignment returns RHS, not setter return.')

semantic('repeated_evaluation_and_saved_homes', r"""
function make(parent){class C { read(){return super.x;} }Object.setPrototypeOf(C.prototype,parent);return C;}
var A=make({x:'A'}),B=make({x:'B'}),a=A.prototype.read,b=B.prototype.read;
check(a.call(B.prototype)==='A'&&b.call(A.prototype)==='B');
A.prototype.read=function(){return 'replacement';};delete B.prototype.read;
check(a.call({})==='A'&&b.call({})==='B');
Object.setPrototypeOf(A.prototype,{x:'C'});
check(a.call({})==='C'&&b.call({})==='B');
return 'distinct:saved';
""", 'distinct:saved', 'A shared parsed function cannot carry mutable home state across class evaluations; saved functions keep original home.')

semantic('escaped_method_and_accessor_arrows', r"""
class A { get x(){return this.tag;} }
class C extends A { arrow(){return ()=>super.x;} get arrowGetter(){return ()=>super.x;} }
var receiver={tag:'R'},a=C.prototype.arrow.call(receiver);
var b=Object.getOwnPropertyDescriptor(C.prototype,'arrowGetter').get.call(receiver);
check(a.call({tag:'wrong'})==='R'&&b()==='R');
Object.setPrototypeOf(C.prototype,{get x(){return 'N'+this.tag;}});
check(a()==='NR'&&b.call(null)==='NR');
return 'arrow:receiver:live';
""", 'arrow:receiver:live', 'Escaped arrows retain lexical this/home after method or accessor return, while each new reference reads current home prototype.')

semantic('constructor_call_parent_and_property_home_are_distinct', r"""
var trace='';
class A { constructor(){trace+='A';this.tag='a';} }
class B { constructor(){trace+='B';this.tag='b';} }
class C extends A { constructor(){super();trace+=super.label;this.read=()=>super.label;} }
Object.setPrototypeOf(C,B);Object.setPrototypeOf(C.prototype,{get label(){return this.tag+'P';}});
var c=new C();check(c.read()==='bP'&&Object.getPrototypeOf(c)===C.prototype);
Object.setPrototypeOf(C.prototype,{label:'Q'});check(c.read()==='Q');
return trace;
""", 'BbP', 'super() uses live constructor parent, SuperProperty uses constructor home C.prototype; later lexical arrow retains that home.')

semantic('constructor_method_and_arrow_parameter_defaults', r"""
var trace='';
class Base { constructor(v=super.seed){this.v=v;trace+='B';} }
Object.setPrototypeOf(Base.prototype,{seed:3});check(new Base().v===3);
class A { constructor(){trace+='A';this.tag=4;} get seed(){trace+='G';return this.tag;} }
class C extends A { constructor(v=(super(),super.seed)){trace+='C';this.v=v;} method(v=super.seed){return v;} arrow(){return (v=super.seed)=>v;} }
var c=new C();check(c.v===4&&c.method()===4&&c.arrow()()===4);
return trace;
""", 'BAGCGG', 'Base constructor defaults have initialized this; derived default super() initializes before SuperProperty and body; method/arrow defaults retain home.')

semantic('nested_class_outer_evaluation_and_inner_home', r"""
var trace='';class Parent { value(){return 'inner';} }
class A { get parent(){trace+='H';return Parent;} get key(){trace+='K';return 'm';} }
class C extends A { make(){return class D extends super.parent { [super.key](){return super.value();} };} }
var D=new C().make();check(new D().m()==='inner');return trace;
""", 'HK', 'Nested class heritage/computed key inherit outer method context; nested method installs an independent home.')

semantic('derived_this_check_precedes_key_expression', r"""
var trace='';class A { get x(){trace+='G';return this;} }
class C extends A { constructor(){try{super[(trace+='K','x')];}catch(e){check(e instanceof ReferenceError);trace+='T';}super();check(super[(trace+='k','x')]===this);trace+='B';} }
new C();return trace;
""", 'TkGB', 'An uninitialized derived this throws before evaluating computed key; successful later reference uses actual instance.')

semantic('escaped_uninitialized_constructor_activation', r"""
var initialize,read,trace='',alternate={};
class A { constructor(){trace+='A';this.tag='A';} }
class B { constructor(){trace+='B';this.tag='B';check(new.target===Target);} }
class C extends A { constructor(){initialize=()=>super();read=()=>super.x;return alternate;} }
function Target(){}Target.prototype={target:true};
check(Reflect.construct(C,[],Target)===alternate);
expect(ReferenceError,()=>read());
Object.setPrototypeOf(C,B);Object.setPrototypeOf(C.prototype,{get x(){return this.tag;}});
var instance=initialize();check(Object.getPrototypeOf(instance)===Target.prototype&&read()==='B');
expect(ReferenceError,()=>initialize());
return trace;
""", 'BB', 'Escaped constructor arrows keep uninitialized activation and original NewTarget; super validates/calls live parent before duplicate BindThisValue refusal.')

semantic('key_expression_vs_key_coercion_base_capture', r"""
var trace='';class C { read(key){return super[key];} changed(){return super[(trace+='E',Object.setPrototypeOf(C.prototype,B),'x')];} }
var A={x:'A'},B={x:'B'},D={x:'D'};
Object.setPrototypeOf(C.prototype,A);check(C.prototype.changed.call({})==='B');
Object.setPrototypeOf(C.prototype,A);
var key={};key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='C';Object.setPrototypeOf(C.prototype,D);return 'x';};
check(C.prototype.read.call({},key)==='A');check(C.prototype.read.call({},'x')==='D');
return trace;
""", 'EC', 'Paired discriminator: key-expression mutation precedes live base capture; key coercion occurs after capture and cannot retarget it.')

semantic('simple_assignment_delays_conversion_until_after_rhs', r"""
var trace='',receiver={},key={},A={},B={},D={},seen;
Object.defineProperty(B,'x',{set:function(v){trace+='S';seen=this;check(v===9);}});
Object.defineProperty(D,'x',{set:function(){throw 'retarget';}});
class C { write(){return super[(trace+='K',Object.setPrototypeOf(C.prototype,B),key)]=(trace+='R',Object.setPrototypeOf(C.prototype,D),9);} }
Object.setPrototypeOf(C.prototype,A);
key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='C';Object.setPrototypeOf(C.prototype,A);return 'x';};
check(C.prototype.write.call(receiver)===9&&seen===receiver);return trace;
""", 'KRCS', 'Simple assignment holds raw key/base/receiver across RHS and converts only during PutValue; assignment result and setter receiver remain exact.')

semantic('abrupt_key_rhs_conversion_and_setter_identity', r"""
var trace='',marker={},stage=0,key={};
function keyValue(){trace+='K';if(stage===0)throw marker;return key;}
function rhs(){trace+='R';if(stage===1)throw marker;return 1;}
key[Symbol.toPrimitive]=function(){trace+='C';if(stage===2)throw marker;return 'x';};
class A { set x(v){trace+='S';throw marker;} }
class C extends A { write(){super[keyValue()]=rhs();} }
var c=new C(),parts=[];for(stage=0;stage<4;stage++){trace='';var caught=false;try{c.write();}catch(e){caught=true;check(e===marker);}check(caught);parts.push(trace);}return parts.join('|');
""", 'K|KR|KRC|KRCS', 'Abrupt completion is original author identity at each ordered stage; later hooks cannot run.')

semantic('null_base_order_and_delete_reference_error', r"""
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class C { read(){return super[(trace+='K',key)];} write(){return super[(trace+='K',key)]=(trace+='R',1);} remove(){return delete super[(trace+='K',key)];} type(){return typeof super[(trace+='K',key)];} }
Object.setPrototypeOf(C.prototype,null);var c=new C(),parts=[];
expect(TypeError,()=>c.read());parts.push(trace);trace='';expect(TypeError,()=>c.write());parts.push(trace);trace='';expect(ReferenceError,()=>c.remove());parts.push(trace);trace='';expect(TypeError,()=>c.type());parts.push(trace);
return parts.join('|');
""", 'K|KR|K|K', 'Null base fails ToObject before ToPropertyKey; simple assignment still evaluates RHS; delete fails as super ReferenceError instead.')

semantic('compound_reference_converts_key_once_and_keeps_base', r"""
var trace='',key={},receiver={},seen,old={valueOf:function(){trace+='V';return 4;}};
class A { get x(){trace+='G';return old;} set x(v){trace+='S';seen=this;check(v===7);} }
class C extends A { add(){return super[(trace+='K',key)]+=(trace+='R',Object.setPrototypeOf(C.prototype,{set x(v){throw 'retarget';}}),3);} }
key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
check(C.prototype.add.call(receiver)===7&&seen===receiver);return trace;
""", 'KCGRVS', 'Read converts and stores the property key once; numeric conversion follows RHS, write reuses captured base/key/receiver.')

semantic('logical_assignment_taken_and_skipped_paths', r"""
var trace='',stored,key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { get x(){trace+='G';return stored;} set x(v){trace+='S';stored=v;} }
class C extends A { and(){return super[(trace+='K',key)]&&=(trace+='R',7);} or(){return super[(trace+='K',key)]||=(trace+='R',7);} nullish(){return super[(trace+='K',key)]??=(trace+='R',7);} }
var c=new C(),out=[];
function run(name,initial,want){trace='';stored=initial;check(c[name]()===want&&stored===want);out.push(trace);}
run('and',0,0);run('and',2,7);run('or',2,2);run('or',0,7);run('nullish',false,false);run('nullish',null,7);run('nullish',undefined,7);
return out.join('|');
""", 'KCG|KCGRS|KCG|KCGRS|KCG|KCGRS|KCGRS', 'Each logical assignment converts/reads once; skipped paths omit RHS/setter and taken paths preserve reference.')

semantic('prefix_and_postfix_updates', r"""
var trace='',stored=4,key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { get x(){trace+='G';return stored;} set x(v){trace+='S';stored=v;} }
class C extends A { pre(){return ++super[(trace+='K',key)];} post(){return super[(trace+='K',key)]++;} down(){return --super[(trace+='K',key)];} postDown(){return super[(trace+='K',key)]--;} }
var c=new C();check(c.pre()===5&&c.post()===5&&c.down()===5&&c.postDown()===5&&stored===4);return trace;
""", 'KCGSKCGSKCGSKCGS', 'Prefix/postfix update results differ while each reference performs one conversion/get/set.')

semantic('call_reference_parentheses_and_comma', r"""
class A { method(){check(new.target===undefined);return this;} }
class C extends A { paren(){return (super.method)();} comma(){return (0,super.method)();} }
var receiver={};check(C.prototype.paren.call(receiver)===receiver);check(C.prototype.comma.call(receiver)===undefined);return 'reference:lost';
""", 'reference:lost', 'Parentheses preserve receiver reference; comma GetValue loses it; ordinary class method invocation has no NewTarget.')

semantic('callee_get_precedes_arguments_but_callable_check_follows', r"""
var trace='',marker={};class A { get x(){trace+='G';return 1;} get y(){trace+='H';throw marker;} }
class C extends A { bad(){return super.x((trace+='A',2));} abrupt(){return super.y((trace+='X',2));} }
var c=new C();try{c.bad();}catch(e){check(e instanceof TypeError);trace+='T';}var caught=false;try{c.abrupt();}catch(e){check(e===marker);caught=true;}check(caught);return trace;
""", 'GATH', 'Getter failure skips arguments; noncallable value still permits argument effects before TypeError.')

semantic('call_spread_order_and_receiver', r"""
var trace='',receiver={},iterator={},source={};var n=0;
iterator.next=function(){trace+='N';n++;return n===1?{value:2,done:false}:{done:true};};
source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { get f(){trace+='G';return function(a,b,c){trace+='F';check(this===receiver&&a===1&&b===2&&c===3);return 9;};} }
class C extends A { call(){return super.f((trace+='A',1),...source,(trace+='Z',3));} }
check(C.prototype.call.call(receiver)===9);return trace;
""", 'GAINNZF', 'Call captures getter/receiver before left-to-right arguments and complete spread iteration.')

semantic('spread_step_abrupt_preserves_identity_without_close', r"""
var trace='',marker={},source={},iterator={next:function(){trace+='N';throw marker;},return:function(){trace+='R';return {};}};
source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { get f(){trace+='G';return function(){trace+='F';};} }
class C extends A { call(){return super.f(...source);} }
var caught=false;try{new C().call();}catch(e){caught=true;check(e===marker);}check(caught);return trace;
""", 'GIN', 'A throwing iterator step during argument spread does not call iterator.return or callee; original exception escapes.')

semantic('construct_super_property_callee', r"""
var trace='',seen;function Target(v){trace+='C';check(new.target===Target);this.v=v;seen=this;}
class A { get ctor(){trace+='G';return Target;} get bad(){trace+='B';return ()=>0;} }
class C extends A { build(){return new super.ctor((trace+='A',6));} bad(){return new super.bad((trace+='X',7));} }
var c=new C(),made=c.build();check(made===seen&&made.v===6&&Object.getPrototypeOf(made)===Target.prototype);
expect(TypeError,()=>c.bad());return trace;
""", 'GACBX', 'new super.C uses retrieved constructor/NewTarget rather than method receiver; invalid constructor check follows arguments.')

semantic('receiver_descriptor_matrix', r"""
var setterCalls=0,protoSetter=0;class C { write(k,v){return super[k]=v;} }
var base={};Object.defineProperty(base,'w',{value:1,writable:true});Object.defineProperty(base,'r',{value:2,writable:false});Object.defineProperty(base,'g',{get:function(){return 3;}});Object.defineProperty(base,'s',{set:function(v){setterCalls++;this.received=v;}});Object.setPrototypeOf(C.prototype,base);
var write=C.prototype.write,own={};Object.defineProperty(own,'w',{value:4,writable:true,enumerable:false,configurable:false});check(write.call(own,'w',5)===5);var d=Object.getOwnPropertyDescriptor(own,'w');check(d.value===5&&d.writable&&!d.enumerable&&!d.configurable&&base.w===1);
var readonly={};Object.defineProperty(readonly,'w',{value:6,writable:false});expect(TypeError,()=>write.call(readonly,'w',9));check(readonly.w===6);
var accessor={};Object.defineProperty(accessor,'w',{set:function(){setterCalls++;}});expect(TypeError,()=>write.call(accessor,'w',9));check(setterCalls===0);
var inherited=Object.create({set w(v){protoSetter++;}});write.call(inherited,'w',8);d=Object.getOwnPropertyDescriptor(inherited,'w');check(d.value===8&&d.writable&&d.enumerable&&d.configurable&&protoSetter===0);
var fixed={w:7};Object.preventExtensions(fixed);write.call(fixed,'w',8);check(fixed.w===8);expect(TypeError,()=>write.call(fixed,'missing',9));
expect(TypeError,()=>write.call({},'r',9));expect(TypeError,()=>write.call({},'g',9));
Object.defineProperty(readonly,'s',{value:0,writable:false});write.call(readonly,'s',11);check(setterCalls===1&&readonly.received===11&&readonly.s===0);
return 'own:inherited:fixed:accessor';
""", 'own:inherited:fixed:accessor', 'Base descriptors and receiver own descriptors jointly control writes; inherited receiver setters are ignored and attributes preserved.')

semantic('primitive_receivers_getters_setters_and_data', r"""
var expected,seen,received;class A { get x(){seen=this;return this;} set x(v){seen=this;received=v;} }
class C extends A { read(){return super.x;} write(v){return super.x=v;} data(v){return super.d=v;} missing(){return super.absent;} }
Object.defineProperty(A.prototype,'d',{value:1,writable:true});var values=[undefined,null,7,'s',Symbol('r')];
for(var i=0;i<values.length;i++){expected=values[i];check(C.prototype.read.call(expected)===expected&&seen===expected);check(C.prototype.write.call(expected,9)===9&&seen===expected&&received===9);expect(TypeError,()=>C.prototype.data.call(expected,9));check(C.prototype.missing.call(expected)===undefined);}
return 'five:primitive:receivers';
""", 'five:primitive:receivers', 'Strict class accessors receive primitive/null/undefined this exactly; data writes require object receivers.')

semantic('reentrant_getter_preserves_outer_reference', r"""
var trace='',outer={},inner={},seen;class C { add(){return super.x+=(trace+='R',2);} side(){return super.y;} }
var A={get x(){trace+='G';check(C.prototype.side.call(inner)===inner);Object.setPrototypeOf(C.prototype,B);return 3;},get y(){trace+='Y';return this;},set x(v){trace+='S';seen=this;check(v===5);}};
var B={set x(v){throw 'retarget';}};Object.setPrototypeOf(C.prototype,A);
check(C.prototype.add.call(outer)===5&&seen===outer);return trace;
""", 'GYRS', 'Reentrant author getter creates independent reference; later home mutation cannot alter retained outer write base/receiver.')

semantic('delete_evaluates_key_expression_not_coercion', r"""
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='C';throw 'conversion';};
class A { get x(){trace+='G';return 1;} }
class C extends A { remove(){return delete (super[(trace+='K',key)]);} type(){return typeof super.x;} }
var c=new C();expect(ReferenceError,()=>c.remove());check(c.type()==='number'&&Object.getOwnPropertyDescriptor(A.prototype,'x')!==undefined);return trace;
""", 'KG', 'Delete performs reference creation then unconditional ReferenceError without key coercion/Get/delete; typeof remains ordinary GetValue.')

semantic('for_of_super_target_and_iterator_close', r"""
var trace='',marker={},key={},source={},index=0;
key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
var iterator={next:function(){trace+='N';index++;return {value:index,done:false};},return:function(){trace+='R';return {};}};source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { set x(v){trace+='S';if(v===2)throw marker;} }
class C extends A { run(){for(super[(trace+='K',key)] of source){trace+='B';}} }
var caught=false;try{new C().run();}catch(e){caught=true;check(e===marker);}check(caught);return trace;
""", 'INKCSBNKCSR', 'Each for-of iteration creates/assigns a super reference; setter abrupt closes acquired iterator and preserves thrown identity.')

semantic('for_in_super_assignment_target', r"""
var trace='',values=[],key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';values.push(v);} }
class C extends A { run(){for(super[(trace+='K',key)] in {a:1,b:2}){trace+='B';}} }
new C().run();check(values.join(',')==='a,b');return trace;
""", 'KCSBKCSB', 'For-in LHS assignment retains receiver-aware super behavior on each enumerated property.')

semantic('array_receiver_indices_length_and_native_method', r"""
class C { write(k,v){return super[k]=v;} push(v){return super.push(v);} }
var base={};Object.defineProperty(base,'2',{value:0,writable:true});Object.defineProperty(base,'length',{value:0,writable:true});base.push=Array.prototype.push;Object.setPrototypeOf(C.prototype,base);
var a=[];C.prototype.write.call(a,'2',7);check(a.length===3&&a[2]===7);C.prototype.write.call(a,'length',1);check(a.length===1&&a[2]===undefined);check(C.prototype.push.call(a,8)===2&&a[1]===8);
Object.defineProperty(a,'length',{writable:false});expect(TypeError,()=>C.prototype.write.call(a,'2',9));check(a.length===2&&a[2]===undefined);return 'array:2:8';
""", 'array:2:8', 'Array receiver definitions retain index/length coupling and native method receiver; length refusal cannot publish an index.')

semantic('array_base_reads_and_distinct_receiver_writes', r"""
class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base=[3],receiver={};Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call(receiver,'0')===3&&C.prototype.read.call(receiver,'length')===1);C.prototype.write.call(receiver,'0',8);C.prototype.write.call(receiver,'length',9);
check(receiver[0]===8&&receiver.length===9&&base[0]===3&&base.length===1);return 'array:base:receiver';
""", 'array:base:receiver', 'An Array in base position exposes its own descriptors while writes target the distinct ordinary receiver.')

semantic('typed_array_receiver_conversion_and_invalid_index', r"""
var trace='',value={valueOf:function(){trace+='V';return 260;}};class C { write(k,v){return super[k]=v;} }
var base={};Object.defineProperty(base,'0',{value:0,writable:true});Object.defineProperty(base,'2',{value:0,writable:true});Object.setPrototypeOf(C.prototype,base);
var a=new Uint8Array(2);check(C.prototype.write.call(a,'0',value)===value&&a[0]===4);expect(TypeError,()=>C.prototype.write.call(a,'2',value));check(trace==='V'&&a.length===2&&a[2]===undefined);
Object.defineProperty(base,'1',{value:0,writable:false});expect(TypeError,()=>C.prototype.write.call(a,'1',value));check(a[1]===0);return trace;
""", 'V', 'TypedArray receiver numeric definition converts valid value once; invalid index or readonly base refuses before conversion.')

semantic('typed_array_base_same_and_distinct_receivers', r"""
var trace='',value={valueOf:function(){trace+='V';return 9;}};class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base=new Uint8Array([3]),receiver={};Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call(receiver,'0')===3);check(C.prototype.write.call(receiver,'0',value)===value&&receiver[0]===value&&base[0]===3&&trace==='');
C.prototype.write.call(receiver,'1',value);C.prototype.write.call(receiver,'-0',value);check(!Object.prototype.hasOwnProperty.call(receiver,'1')&&!Object.prototype.hasOwnProperty.call(receiver,'-0')&&trace==='');
C.prototype.write.call(base,'1',value);check(trace==='V'&&base[0]===3&&base[1]===undefined);
var symbol=Symbol('extra');C.prototype.write.call(receiver,'01',7);C.prototype.write.call(receiver,symbol,8);check(receiver['01']===7&&receiver[symbol]===8);return trace;
""", 'V', 'Integer-indexed base distinguishes same receiver conversion from distinct receiver early success; invalid canonical indices are terminal, ordinary strings/Symbols fall through.')

semantic('mapped_and_unmapped_arguments_receiver', r"""
class C { write(v){return super[0]=v;} }Object.setPrototypeOf(C.prototype,{0:0});
return (function(a){C.prototype.write.call(arguments,9);var first=a,saved=arguments[0];a=5;return first+':'+saved+':'+arguments[0];})(1);
""", '9:9:5', 'Receiver own definition must preserve mapped arguments aliasing in sloppy mode and unmapped strict arguments.', strict_expected='1:9:9')

semantic('dom_character_data_brand_and_actual_receiver', r"""
class C { read(){return super.data;} write(v){return super.data=v;} append(v){return super.appendData(v);} length(){return super.length;} }
Object.setPrototypeOf(C.prototype,CharacterData.prototype);var text=new Text('ab');
check(C.prototype.read.call(text)==='ab');check(C.prototype.write.call(text,'x')==='x');check(C.prototype.append.call(text,'yz')===undefined);check(C.prototype.read.call(text)==='xyz'&&C.prototype.length.call(text)===3);
expect(TypeError,()=>C.prototype.read.call({}));expect(TypeError,()=>C.prototype.write.call({},'bad'));expect(TypeError,()=>C.prototype.append.call({},'bad'));return 'xyz:3';
""", 'xyz:3', 'Native DOM getters/setters/methods receive actual Node identity and retain brand refusal for ordinary fake receiver.', prerequisites=('Text and CharacterData public prototype tests at published base',))

semantic('dom_receiver_own_expandos_and_setter_identity', r"""
var seen;class C { write(k,v){return super[k]=v;} }
var symbol=Symbol('node'),base={};Object.defineProperty(base,'extra',{value:0,writable:true});Object.defineProperty(base,'sink',{set:function(v){seen=this;this.received=v;}});Object.setPrototypeOf(C.prototype,base);
var text=new Text('ab');C.prototype.write.call(text,'extra',7);C.prototype.write.call(text,symbol,8);C.prototype.write.call(text,'sink',9);
check(text.extra===7&&text[symbol]===8&&seen===text&&text.received===9&&text.data==='ab');var d=Object.getOwnPropertyDescriptor(text,'extra');check(d.value===7&&d.writable&&d.enumerable&&d.configurable);return 'node:identity';
""", 'node:identity', 'Receiver-aware data writes use DOM expando routing, and accessor call preserves Node identity rather than exposing backing ordinary storage.')

semantic('promise_native_receiver_and_species', r"""
class C extends Promise { bridge(f){return super.then(f);} }
var trace='S',p=C.resolve(4),q=p.bridge(function(v){check(v===4);trace+='F';});check(q instanceof C);
expect(TypeError,()=>C.prototype.bridge.call({},function(){trace+='bad';}));trace+='X';trace+='E';
return {read:function(){return trace;}};
""", 'SXEF', 'Native Promise method sees genuine receiver and species-created subclass; jobs run at public execute checkpoint, fake receiver fails synchronously.')
ROWS[-1]['readback'] = 'result.read()\n'

semantic('unicode_and_symbol_keys_exact_units', r"""
var lone='\uD800',symbol=Symbol(lone),other=Symbol(lone),trace='',key={};
class C { read(k){return super[k];} write(k,v){return super[k]=v;} }
var base={};base['雪']=1;base[lone]=2;base[symbol]=3;Object.setPrototypeOf(C.prototype,base);
check(C.prototype.read.call({},'雪')===1&&C.prototype.read.call({},lone)===2&&C.prototype.read.call({},symbol)===3&&C.prototype.read.call({},other)===undefined);
key[Symbol.toPrimitive]=function(h){check(h==='string');trace+='K';return symbol;};var receiver={};C.prototype.write.call(receiver,key,4);check(receiver[symbol]===4&&base[symbol]===3&&lone.charCodeAt(0)===55296);return trace;
""", 'K', 'Property keys retain exact UTF-16 string content and Symbol identity, including lone-surrogate descriptions.')

semantic('alternate_new_target_does_not_replace_constructor_home', r"""
class A { get x(){return this.marker;} }
class C extends A { constructor(){super();this.marker=6;this.seen=super.x;} }
function Target(){}Target.prototype={get x(){throw 'wrong prototype';}};
var made=Reflect.construct(C,[],Target);check(Object.getPrototypeOf(made)===Target.prototype&&made.seen===6);return 'newtarget:receiver:home';
""", 'newtarget:receiver:home', 'Alternate NewTarget chooses instance prototype but cannot replace constructor home; getter receives that alternate-prototype instance.')

semantic('accessor_pair_preserves_independent_homes', r"""
var seen;class A { get x(){return super.value;} }class B { set x(v){super.value=v;} }
Object.setPrototypeOf(A.prototype,{value:'A'});Object.setPrototypeOf(B.prototype,{set value(v){seen=this;this.received='B'+v;}});
var descriptor={get:Object.getOwnPropertyDescriptor(A.prototype,'x').get,set:Object.getOwnPropertyDescriptor(B.prototype,'x').set,configurable:true};
var receiver={};Object.defineProperty(receiver,'x',descriptor);check(receiver.x==='A');receiver.x=7;check(seen===receiver&&receiver.received==='B7');
Object.setPrototypeOf(A.prototype,{value:'C'});check(receiver.x==='C');receiver.x=8;check(receiver.received==='B8');return 'get:A:C|set:B';
""", 'get:A:C|set:B', 'Combining copied getter/setter functions into one descriptor cannot conflate their distinct original homes.')

semantic('base_class_default_prototype_links', r"""
class C { objectString(){return super.toString();} static invoke(receiver){return super.call(receiver);} }
var c=new C();check(c.objectString()==='[object Object]');expect(TypeError,()=>C.invoke({}));
var seen;function fn(){seen=this;return 8;}var receiver={};check(C.invoke.call(fn,receiver)===8&&seen===receiver);return 'Object:Function';
""", 'Object:Function', 'A base class instance home starts at Object.prototype; static home starts at Function.prototype, with actual callable receiver.')

def early(name, source, purpose):
    ROWS.append(dict(id=name,family='early-error',modes=['sloppy','strict'],setup='var sentinel=0;\n',source='sentinel=1;\n'+source+'\n',readback='sentinel\n',expected={'sloppy':0,'strict':0},error={'intrinsic':'SyntaxError','is_parse_error':True},purpose=purpose,prerequisites=[]))

early('early_top_level_super_property','super.x;','Top-level super property has no valid home/context; parse rejects before preceding statement executes.')
early('early_ordinary_function_super_property','function f(){return super.x;}','Ordinary function body cannot acquire super context.')
early('early_nested_function_resets_super','class C { m(){return function(){return super.x;};} }','Nested ordinary function resets class super context.')
early('early_base_constructor_super_call','class C { constructor(){super();} }','Property support must not permit direct super() in base constructor.')
early('early_method_super_call','class C extends Object { m(){super();} }','Derived class method is not derived constructor for direct super().')
early('early_bare_super','class C { m(){return super;} }','Bare super is not an expression.')
early('early_new_bare_super_call','class C extends Object { constructor(){return new super();} }','new super() is invalid even in derived constructor; new super.property() is separately supported.')
early('early_optional_super_base','class C { m(){return super?.x;} }','Optional chaining cannot directly start at bare super; this is a syntax error, not the valid deferred super.x?.() surface.')

def deferred(name, source, purpose):
    ROWS.append(dict(id=name,family='unsupported',modes=['sloppy','strict'],source=source+'\n',error={'is_unsupported':True},purpose=purpose,prerequisites=[],readback=None))

deferred('deferred_object_literal_method_super','var object={m(){return super.x;}};','Valid object concise method super remains outside selected class-only support.')
deferred('deferred_object_literal_accessor_arrow_super','var object={get x(){return ()=>super.x;}};','Object accessor lexical arrow must not be enabled accidentally.')
deferred('deferred_class_field_super','class C { x=super.x; }','Valid public field initializer remains Unsupported.')
deferred('deferred_class_static_block_super','class C { static { super.x; } }','Valid class static block remains Unsupported.')
deferred('deferred_class_async_super','class C { async m(){return super.x;} }','Async class methods remain Unsupported even though ordinary method super is selected.')

TERMINAL_PREFIX = "var trace='',caught=0,finalized=0,after=0,queuedRan=0;\nvar queued=function(){queuedRan++;};queueMicrotask(queued);\nfunction spin(){while(true){}}\n"
def terminal(name, source, trace, purpose):
    ROWS.append(dict(id=name,family='resource-terminal',modes=['sloppy','strict'],source=TERMINAL_PREFIX+source.strip()+'\n',readback=None,
                    expected_retained={'trace':trace,'caught':0,'finalized':0,'after':0,'queuedRan':0},
                    error={'is_resource_limit':True,'is_unsupported':False,'message':'script instruction limit exceeded'},
                    observer={'steps':0,'microtasks_suspended':True,'frames':0,'calls':0,'eval_depth':0,'stack_units':0,'author_depth':0,'performing_checkpoint':False,'queued_callback_count':1,'queued_callback_identity':'queued','console_empty':True},
                    purpose=purpose,prerequisites=['Existing public class terminal observer; inspect retained state by borrowing, no post-terminal execute or reset.']))

terminal('terminal_computed_key_expression',r"""
class A { get x(){trace+='G';return 1;} }class C extends A { run(){return super[(trace+='K',spin())];} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'K','Work exhaustion in raw computed-key expression stops getter and all catch/finally/queued effects; reference capture unwinds.')
terminal('terminal_key_conversion',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';spin();return 'x';};
class A { get x(){trace+='G';return 1;} }class C extends A { run(){return super[(trace+='K',key)];} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KC','Work exhaustion during delayed key conversion prevents getter and terminal observer restores frame/call state.')
terminal('terminal_getter',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { get x(){trace+='G';spin();return 1;} }class C extends A { run(){return super[(trace+='K',key)];} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KCG','Getter exhaustion preserves completed key conversion and prevents all later author effects or queued work.')
terminal('terminal_assignment_rhs_before_conversion',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';} }class C extends A { run(){super[(trace+='K',key)]=(trace+='R',spin());} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KR','RHS exhaustion occurs before conversion/setter, preserving raw-reference ordering with no resumed author effects.')
terminal('terminal_setter',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';spin();} }class C extends A { run(){super[(trace+='K',key)]=(trace+='R',1);trace+='B';} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KRCS','Setter exhaustion retains earlier stages but prevents subsequent body/catch/finally/jobs, including nested call restoration.')
terminal('terminal_for_of_setter_does_not_close',r"""
var source={},iterator={next:function(){trace+='N';return {value:1,done:false};},return:function(){trace+='R';return {};}};source[Symbol.iterator]=function(){trace+='I';return iterator;};
class A { set x(v){trace+='S';spin();} }class C extends A { run(){for(super.x of source){trace+='B';}} }
try{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'INS','Fatal work failure bypasses author IteratorClose as well as catch/finally/queued callbacks; contrast catchable setter case.')

for name,body,trace,purpose in [
    ('unsupported_key_expression',r"""
class A { get x(){trace+='G';return 1;} }class C extends A { run(){return super[(trace+='K',eval('1'))];} }
""",'K','Unsupported eval during key expression precedes reference base capture and all property hooks.'),
    ('unsupported_key_conversion',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return eval('1');};
class A { get x(){trace+='G';return 1;} }class C extends A { run(){return super[(trace+='K',key)];} }
""",'KC','Unsupported eval during key conversion prevents getter.'),
    ('unsupported_getter',r"""
class A { get x(){trace+='G';return eval('1');} }class C extends A { run(){return super[(trace+='K','x')];} }
""",'KG','Unsupported eval during inherited getter is terminal, not an ordinary catchable getter exception.'),
    ('unsupported_assignment_rhs',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';} }class C extends A { run(){return super[(trace+='K',key)]=(trace+='R',eval('1'));} }
""",'KR','Unsupported RHS bypasses delayed key conversion and setter.'),
    ('unsupported_setter',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
class A { set x(v){trace+='S';eval('1');} }class C extends A { run(){return super[(trace+='K',key)]=(trace+='R',1);} }
""",'KRCS','Unsupported setter preserves reached stages but bypasses catch/finally/tail/jobs.'),
]:
    terminal(name,body+"\ntry{new C().run();after++;}catch(e){caught++;}finally{finalized++;}after++;",trace,purpose)
    ROWS[-1]['family']='unsupported-terminal'
    ROWS[-1]['error']={'is_resource_limit':False,'is_unsupported':True}
    ROWS[-1]['observer'].pop('steps')

def sha(data): return hashlib.sha256(data).hexdigest()
def dump(path, value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2,ensure_ascii=True)+'\n')
def binding(path):
    data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}

if __name__ == '__main__':
    assert len({r['id'] for r in ROWS})==len(ROWS)
    for row in ROWS:
        for key in ('source','setup','readback'):
            if isinstance(row.get(key),str):
                path=ROOT/'literals'/f"{row['id']}.{key}.js";path.parent.mkdir(parents=True,exist_ok=True);path.write_text(row[key]);row[key+'_binding']=binding(path)
        row['proposed_test_name']='super_property_'+row['id']
    dump(ROOT/'cases.json',{'schema':1,'base':BASE,'status':'source-derived independent public contract; no project/JS execution or candidate outcomes','rows':ROWS})
    sources=['src/script/class_semantics_tests.rs','src/script/class_abort_tests.rs','src/script/machine/calls.rs','src/script/processing_instruction/character_data/tests.rs','src/script/processing_instruction/key_cache_tests.rs','src/script/array_splice/tests.rs','src/script/typed_array/set_key/tests.rs','src/script/typed_array/index/tests.rs','src/script/dom_prototypes/tests.rs']
    bindings=[]
    for relative in sources:
        data=subprocess.check_output(['git','show',BASE+':'+relative],cwd=WORKTREE)
        dest=ROOT/'published'/relative;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
        bindings.append({'relative_path':relative,'base':BASE,**binding(dest)})
    counts={family:sum(r['family']==family for r in ROWS) for family in dict.fromkeys(r['family'] for r in ROWS)}
    dump(ROOT/'literal-ready.json',{'schema':1,'base':BASE,'cases':binding(ROOT/'cases.json'),'counts':counts,'groups':len(ROWS),'planned_modes':len(ROWS)*2,'literal_bindings':sum(sum(isinstance(r.get(k),str) for k in ('source','setup','readback')) for r in ROWS),'published_sources':bindings,'selected_inputs':[binding(ROOT.parent/'root/selection-1.json')],'retained_outline':[binding(pathlib.Path('/tmp/eris-super-property-readiness-1')/n) for n in ['readiness.json','independent-test-outline.json','spec-provenance.json','source-bindings.json','source-ready.json']],'execution':'none; author.py only assembles literals and reads published Git bytes'} )
    print(json.dumps({'groups':len(ROWS),'counts':counts,'planned_modes':len(ROWS)*2,'literal_ready':binding(ROOT/'literal-ready.json')}))
