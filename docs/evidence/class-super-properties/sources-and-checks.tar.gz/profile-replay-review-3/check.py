"""Independent AST and authenticated-source review; no replay/project imports."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,re
K=Path('/tmp/eris-super-properties-plan-1');A=K/'profile-replay-2';B=K/'profile-replay-3';P=K/'profile-replay-review-3'
def sha(data):return hashlib.sha256(data).hexdigest()
def bind(path):
    data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def load(path):return json.loads(path.read_bytes())
seal=load(B/'source-ready.json')
for item in seal['files']:
    found=bind(B/item['path']);assert found['bytes']==item['bytes'] and found['sha256']==item['sha256']
for name in ('supersedes','findings','contract','runner','metadata_census','delta','checks'):
    assert bind(Path(seal[name]['path']))==seal[name]
old=load(A/'contract.json');new=load(B/'contract.json');delta=load(B/'delta.json')
changed={k for k in set(old)|set(new) if old.get(k)!=new.get(k)}
assert changed=={'case_completion_policies','acceptance','commands'}
assert new['acceptance'][:-1]==old['acceptance']
assert new['commands']==[x.replace('/profile-replay-2/','/profile-replay-3/') for x in old['commands']]
previous=(A/'replay.py').read_text();current=(B/'replay.py').read_text();inverse=current
for item in reversed(delta['edits']):
    assert inverse.count(item['after'])==1;inverse=inverse.replace(item['after'],item['before'])
assert inverse==previous
def functions(source):
    return {n.name:ast.get_source_segment(source,n) for n in ast.parse(source).body if isinstance(n,ast.FunctionDef)}
oldf=functions(previous);newf=functions(current);assert oldf.keys()==newf.keys()
assert [name for name in oldf if oldf[name]!=newf[name]]==['compare','main']
pins={x['path']:x for x in new['immutable_published_inputs']};unique={};profiles=[];allcounts=Counter();observed=0;unobserved=[]
for profile in new['profiles']:
    if profile['binary_kind']!='host':assert profile['profile'] not in new['case_completion_policies'];continue
    report_binding=profile['reference_report'];assert bind(Path(report_binding['path']))==report_binding
    report=load(Path(report_binding['path']));table={};counts=Counter()
    for case in report['cases']:
        name=profile['corpus']+'/'+case['file'];path=K/'worktree'/name;data=path.read_bytes()
        assert dict(bind(path),path=name)==pins[name] and sha(data)==case['source_sha256']
        text=data.decode();assert text.count('/*---')==text.count('---*/')==1
        front=text.split('/*---',1)[1].split('---*/',1)[0]
        selected=[line for line in front.splitlines() if re.match(r'^flags\s*:',line)]
        assert len(selected)<=1
        flags=[]
        if selected:
            value=selected[0].split(':',1)[1].strip()
            assert re.fullmatch(r'\[\s*(?:[A-Za-z][A-Za-z0-9_-]*\s*(?:,\s*[A-Za-z][A-Za-z0-9_-]*\s*)*)?\]',value)
            flags=[x.strip() for x in value[1:-1].split(',') if x.strip()]
        policy=1 if 'async' in flags else 0
        assert case['id'] not in table;table[case['id']]=policy;counts[policy]+=1;allcounts[policy]+=1
        if 'observation' in case:
            assert type(case['observation']['completion']['policy']) is int
            assert case['observation']['completion']['policy']==policy;observed+=1
        else:unobserved.append({'profile':profile['profile'],'id':case['id'],'policy':policy,'status':case['status']})
        record={'path':name,'bytes':len(data),'sha256':sha(data),'frontmatter_sha256':sha(front.encode()),'flags':flags,'completion_policy':policy}
        if name in unique:assert unique[name]==record
        unique[name]=record
    assert table==new['case_completion_policies'][profile['profile']]
    profiles.append({'profile':profile['profile'],'cases':len(table),'policy_counts':dict(counts)})
census=load(B/'metadata-policy-census.json')
assert {x['path']:x for x in census['sources']}==unique
assert len(unique)==637 and sum(allcounts.values())==1268 and observed==1262 and len(unobserved)==6
assert allcounts=={0:554,1:714}
checks={'status':'clear source-only checks','seal':bind(B/'source-ready.json'),'runner':bind(B/'replay.py'),'contract':bind(B/'contract.json'),'exact_five_replacement_inverse':True,'changed_functions':['compare','main'],'unchanged_functions':[n for n in oldf if n not in ('compare','main')],'contract_changed_fields':sorted(changed),'all_old_profile_policy_case_control_source_pins_exact':True,'profiles':profiles,'authenticated_unique_sources':len(unique),'host_modes':sum(allcounts.values()),'policy_counts':dict(allcounts),'observed_predecessor_policy_joins':observed,'previously_unobserved_policies':unobserved,'metadata_census_exact':True,'metadata_grammar':'Every selected flags row is an unquoted one-line list of identifier tags, or absent; independent closed census, not a general YAML parser.','raw_resource_tools_and_binary_path_corrections_preserved':True,'project_imports':False,'project_execution':False,'replay_execution':False,'live_edits':False}
(P/'checks.json').write_text(json.dumps(checks,indent=2)+'\n');print(json.dumps(bind(P/'checks.json')))
