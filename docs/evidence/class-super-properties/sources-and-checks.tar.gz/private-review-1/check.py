"""Inert peer checks: reads source/receipts and Git blobs; imports no project code."""
from pathlib import Path
import hashlib, json, re, subprocess
K=Path('/tmp/eris-super-properties-plan-1')
P=K/'private-review-1'
BASE='db02f8c890a459b979378900f113b67460a49121'
def bind(path):
    path=Path(path); data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
verified={}
def verify(value):
    if isinstance(value,dict):
        if {'path','bytes','sha256'} <= value.keys():
            path=Path(value['path']); path=path if path.is_absolute() else K/path
            found=bind(path)
            assert found['bytes']==value['bytes'] and found['sha256']==value['sha256'],path
            verified[str(path)]=found
        for item in value.values(): verify(item)
    elif isinstance(value,list):
        for item in value: verify(item)
seals=[K/name/'source-ready.json' for name in ('capture-controls-1','property-producer-1','base-validation-correction-1')]
for path in seals: verify(json.loads(path.read_bytes()))
contract=json.loads((K/'capture-controls-1/contract-ready.json').read_bytes())
verify(contract)
joins=[]
for item in contract['source_bindings']:
    path=Path(item['path']); relative=path.relative_to(K/'capture-controls-1/published')
    data=subprocess.check_output(['git','show',BASE+':'+str(relative)],cwd=K/'worktree')
    assert data==path.read_bytes(),relative
    joins.append({'path':str(relative),'sha256':hashlib.sha256(data).hexdigest()})
before=K/'property-producer-1/before/src/script/reflect_properties.rs'
raw=K/'property-producer-1/raw/src/script/reflect_properties.rs'
assert before.read_bytes()==subprocess.check_output(['git','show',BASE+':src/script/reflect_properties.rs'],cwd=K/'worktree')
old=before.read_text(); new=raw.read_text()
assert old.replace('    fn reflect_find(', '    pub(super) fn reflect_find(').replace('    fn reflect_set(', '    pub(super) fn reflect_set(')==new
groups={}
for path in [K/'capture-controls-1/raw/src/script/class_super_properties/tests.rs',K/'property-producer-1/raw/src/script/super_properties/tests.rs']:
    groups[str(path)]=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',path.read_text())
assert [len(x) for x in groups.values()]==[7,8]
old=(K/'base-validation-correction-1/before.rs').read_text()
new=(K/'base-validation-correction-1/after.rs').read_text()
prefix=old.index('        let base = home.prototype.clone()')
assert old[:prefix]==new[:prefix]
suffix='name, receiver, strict })\n'
assert old[old.index(suffix):]==new[new.index(suffix):]
assert old.count('self.work(8)?;')==new.count('self.work(8)?;')==3
report={'status':'source checks passed','seals':[bind(p) for p in seals], 'verified_bindings':list(verified.values()),'published_joins':joins,'test_groups':groups,'reflect_visibility_only_inverse':True,'correction_prefix_suffix_and_fixed_fees_preserved':True,'project_execution':False,'live_edits':False}
(P/'checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(bind(P/'checks.json')))
