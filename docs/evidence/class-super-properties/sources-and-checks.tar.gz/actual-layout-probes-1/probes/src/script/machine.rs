//! Inert full-shape layout experiment; no execution semantics.
#![allow(dead_code)]
use super::*;
use crate::script::{Binding, BoundFunction, ThisBinding};
use std::collections::BTreeMap;

struct ProposedFunction {
    code: code::FunctionRef,
    environment: usize,
    properties: usize,
    bound: Option<BoundFunction>,
    home_object: Option<usize>,
}
struct ProposedEnvironment {
    bindings: BTreeMap<String, Binding>,
    // Execution receiver, never an author-visible property or lexical name.
    this_binding: ThisBinding,
    active_function: Option<usize>,
    new_target_binding: Option<Value>,
    parent: Option<usize>,
    function_scope: bool,
    strict: bool,
}
enum ProposedReference {
    CodeName {
        unit: Rc<code::Unit>,
        expression: code::ExprId,
        owner: Option<usize>,
        strict: bool,
    },
    // Computed names stay uncoerced until GetValue/PutValue. A successful read
    // replaces the name with a string or symbol so compound assignments convert once.
    Property(Value, Value, bool),
    SuperProperty { base: Value, name: Value, receiver: Value, strict: bool },
}
enum ProposedPhase {
    Start,
    ReferenceObject,
    ReferenceKey(Value),
    Unary,
    Delete,
    BinaryHead,
    BinaryRight {
        index: usize,
        left: Value,
    },
    Conditional,
    Identity,
    Sequence(usize),
    Array {
        index: usize,
        values: Vec<Value>,
        holes: BTreeSet<usize>,
    },
    ObjectKey {
        index: usize,
        object: Value,
    },
    ObjectValue {
        index: usize,
        object: Value,
        key: PropertyKey,
    },
    ObjectPrototype {
        index: usize,
        object: Value,
    },
    Template {
        index: usize,
        output: Vec<u16>,
    },
    AssignReference,
    AssignValue {
        reference: ProposedReference,
        old: Option<Value>,
        logical: bool,
    },
    Update,
    Callee,
    MemberCallee,
    Arguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: Vec<Value>,
    },
    SpreadArguments {
        index: usize,
        function: Value,
        receiver: Value,
        arguments: call_spread::Arguments,
    },
    NamedStart(PropertyKey),
    SuperArguments {
        owner: usize,
        new_target: Value,
        superclass: Value,
        index: usize,
        arguments: Vec<Value>,
    },
    SuperSpreadArguments {
        owner: usize,
        new_target: Value,
        superclass: Value,
        index: usize,
        arguments: call_spread::Arguments,
    },
    SuperReferenceKey { owner: usize, receiver: Value },
}
pub(super) struct ProposedExprFrame {
    unit: Rc<code::Unit>,
    expression: code::ExprId,
    env: usize,
    reference: bool,
    phase: ProposedPhase,
}
pub(super) enum ProposedFrame {
    Expression(ProposedExprFrame),
    Statement(statements::Frame),
    Call(calls::Frame),
    Class(classes::Frame),
}
enum ProposedOutput {
    Flow(Flow),
    Value(Value),
    ProposedReference(ProposedReference),
}
#[test]
fn super_property_layout_probe() {
    println!("SUPER_LAYOUT Value {} {}", std::mem::size_of::<Value>(), std::mem::align_of::<Value>());
    println!("SUPER_LAYOUT BoundFunction {} {}", std::mem::size_of::<BoundFunction>(), std::mem::align_of::<BoundFunction>());
    println!("SUPER_LAYOUT Function.actual {} {}", std::mem::size_of::<crate::script::Function>(), std::mem::align_of::<crate::script::Function>());
    println!("SUPER_LAYOUT Function.proposed {} {}", std::mem::size_of::<ProposedFunction>(), std::mem::align_of::<ProposedFunction>());
    println!("SUPER_LAYOUT Environment.actual {} {}", std::mem::size_of::<crate::script::Environment>(), std::mem::align_of::<crate::script::Environment>());
    println!("SUPER_LAYOUT Environment.proposed {} {}", std::mem::size_of::<ProposedEnvironment>(), std::mem::align_of::<ProposedEnvironment>());
    println!("SUPER_LAYOUT Reference.actual {} {}", std::mem::size_of::<Reference>(), std::mem::align_of::<Reference>());
    println!("SUPER_LAYOUT Reference.proposed {} {}", std::mem::size_of::<ProposedReference>(), std::mem::align_of::<ProposedReference>());
    println!("SUPER_LAYOUT Phase.actual {} {}", std::mem::size_of::<Phase>(), std::mem::align_of::<Phase>());
    println!("SUPER_LAYOUT Phase.proposed {} {}", std::mem::size_of::<ProposedPhase>(), std::mem::align_of::<ProposedPhase>());
    println!("SUPER_LAYOUT ExprFrame.actual {} {}", std::mem::size_of::<ExprFrame>(), std::mem::align_of::<ExprFrame>());
    println!("SUPER_LAYOUT ExprFrame.proposed {} {}", std::mem::size_of::<ProposedExprFrame>(), std::mem::align_of::<ProposedExprFrame>());
    println!("SUPER_LAYOUT Frame.actual {} {}", std::mem::size_of::<Frame>(), std::mem::align_of::<Frame>());
    println!("SUPER_LAYOUT Frame.proposed {} {}", std::mem::size_of::<ProposedFrame>(), std::mem::align_of::<ProposedFrame>());
    println!("SUPER_LAYOUT Output.actual {} {}", std::mem::size_of::<Output>(), std::mem::align_of::<Output>());
    println!("SUPER_LAYOUT Output.proposed {} {}", std::mem::size_of::<ProposedOutput>(), std::mem::align_of::<ProposedOutput>());
    println!("SUPER_LAYOUT CodeExpr.actual {} {}", std::mem::size_of::<code::Expr>(), std::mem::align_of::<code::Expr>());
}
