//! Inert complete super-property parser/code layout mirrors; no parser methods run.
#![allow(dead_code, unused_mut, unused_imports)]
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct LayoutRow { name: &'static str, size: usize, align: usize }
fn row<T>(name: &'static str) -> LayoutRow {
    LayoutRow { name, size: size_of::<T>(), align: align_of::<T>() }
}

mod before {
    use super::*;
    mod code {
        use super::*;

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ExprId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct StmtId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct FunctionId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ClassId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassKind {
            ExplicitBase,
            ExplicitDerived,
            DefaultBase,
            DefaultDerived,
        }

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassElementKind {
            Method,
            Getter,
            Setter,
        }

        #[derive(Debug)]
        pub(super) struct Class {
            pub name: Option<String>,
            pub heritage: Option<ExprId>,
            pub constructor: FunctionId,
            pub elements: Vec<ClassElement>,
        }

        #[derive(Debug)]
        pub(super) struct ClassElement {
            pub name: PropertyName,
            pub function: FunctionId,
            pub kind: ClassElementKind,
            pub is_static: bool,
        }

        #[derive(Debug)]
        pub(super) struct Parameter {
            pub name: String,
            pub initializer: Option<ExprId>,
            pub rest: bool,
        }

        #[derive(Debug)]
        pub(super) struct Function {
            pub params: Vec<Parameter>,
            pub body: Vec<StmtId>,
            pub name: Option<String>,
            pub arrow: bool,
            pub self_name: bool,
            pub constructable: bool,
            pub strict: bool,
            pub class_kind: Option<ClassKind>,
        }

        #[derive(Debug)]
        pub(super) struct Unit {
            expressions: Records<Expr>,
            statements: Records<Stmt>,
            functions: Records<Function>,
            pub body: Vec<StmtId>,
            pub strict: bool,
            pub compiled_storage: usize,
            classes: Records<Class>,
        }

        #[derive(Clone, Debug)]
        pub(super) struct FunctionRef {
            pub unit: Rc<Unit>,
            id: FunctionId,
        }

        #[derive(Debug)]
        pub(super) enum Expr {
            Literal(Value),
            RegExp(Rc<RegExp>),
            Ident(String),
            NewTarget,
            Array(Vec<Option<ExprId>>),
            Object(Vec<(PropertyName, ObjectEntry)>),
            Unary(String, ExprId),
            BinaryChain(ExprId, Vec<(String, ExprId)>),
            Conditional(ExprId, ExprId, ExprId),
            Assign(String, ExprId, ExprId),
            Update(ExprId, f64, bool),
            Member(ExprId, ExprId),
            Call(ExprId, Vec<ExprId>),
            New(ExprId, Vec<ExprId>),
            CallSpread(ExprId, Vec<ExprId>),
            NewSpread(ExprId, Vec<ExprId>),
            SpreadArgument(ExprId),
            Function(FunctionId),
            Sequence(Vec<ExprId>),
            Template(JsString, Vec<(ExprId, JsString)>),
            Class(ClassId),
            SuperCall(Vec<ExprId>),
            SuperCallSpread(Vec<ExprId>),
        }

        #[derive(Debug)]
        pub(super) enum PropertyName {
            Literal(JsString),
            Computed(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum ObjectEntry {
            Data(ExprId),
            Method(FunctionId),
            Accessor(FunctionId, bool),
            Prototype(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum Stmt {
            Empty,
            Label(usize, StmtId),
            Expr(ExprId),
            Var(Vec<(String, Option<ExprId>)>, DeclarationKind),
            Block(Vec<StmtId>),
            If(ExprId, StmtId, Option<StmtId>),
            While(ExprId, StmtId),
            DoWhile(ExprId, StmtId),
            For(Option<StmtId>, Option<ExprId>, Option<ExprId>, StmtId),
            ForIn(ForBinding, ExprId, StmtId),
            ForOf(ForBinding, ExprId, StmtId),
            Switch(ExprId, Vec<(Option<ExprId>, Vec<StmtId>)>),
            Function(String, FunctionId),
            Return(Option<ExprId>),
            Throw(ExprId),
            Try(StmtId, Option<CatchClause>, Option<StmtId>),
            Break(Option<usize>),
            Continue(Option<usize>),
            Class(ClassId),
        }

        #[derive(Debug)]
        pub(super) enum ForBinding {
            Declaration(String, DeclarationKind),
            Target(ExprId),
        }

        #[derive(Debug)]
        pub(super) struct CatchClause {
            pub binding: Option<String>,
            pub body: Vec<StmtId>,
        }

        #[derive(Debug)]
        pub(super) struct Records<T> {
            pages: Vec<Vec<T>>,
            length: usize,
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<ExprId>("code::ExprId"),
                row::<StmtId>("code::StmtId"),
                row::<FunctionId>("code::FunctionId"),
                row::<ClassId>("code::ClassId"),
                row::<ClassKind>("code::ClassKind"),
                row::<ClassElementKind>("code::ClassElementKind"),
                row::<Class>("code::Class"),
                row::<ClassElement>("code::ClassElement"),
                row::<Parameter>("code::Parameter"),
                row::<Function>("code::Function"),
                row::<Unit>("code::Unit"),
                row::<FunctionRef>("code::FunctionRef"),
                row::<Expr>("code::Expr"),
                row::<PropertyName>("code::PropertyName"),
                row::<ObjectEntry>("code::ObjectEntry"),
                row::<Stmt>("code::Stmt"),
                row::<ForBinding>("code::ForBinding"),
                row::<CatchClause>("code::CatchClause"),
                row::<Records<Expr>>("code::Records<Expr>"),
                row::<Records<Class>>("code::Records<Class>"),
                row::<Records<Function>>("code::Records<Function>"),
            ];
            rows
        }
    }
    mod parser {
        use super::*;
        use code::{CatchClause, ClassId, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId};

        enum PropertyName {
            Literal(JsString, bool),
            Computed(ExprId),
        }

        struct ActiveLabel {
            name: String,
            target: usize,
            iteration: bool,
        }

        pub(super) struct Parser<'source> {
            tokens: tokens::Tokens,
            source: &'source str,
            lex_work: usize,
            compile_budget: regexp::Budget,
            unit: code::Unit,
            pos: usize,
            function_depth: usize,
            new_target_allowed: bool,
            loop_depth: usize,
            switch_depth: usize,
            labels: Vec<ActiveLabel>,
            next_label: usize,
            allow_in: bool,
            strict: bool,
            super_call_allowed: bool,
            in_class: bool,
        }

        mod driver {
            use super::*;

            enum Output {
                Expression(ExprId),
                Statement(StmtId),
                Body(Body),
                Function(FunctionCode),
                Parameters(functions::State),
                Key(PropertyName),
                Declaration(Stmt),
                Class(ClassId),
            }

            struct Body {
                statements: Vec<StmtId>,
                own_strict: bool,
                has_lexical: bool,
            }

            enum Kind {
                Expression(expressions::Frame),
                Statement(statements::Frame),
                Function(functions::Frame),
                Body(statements::BodyFrame),
                Class(classes::Frame),
            }

            enum Transition {
                Done(Output),
                Again(Kind),
                Child(Kind, Kind),
            }

            struct EntryContext {
                allow_in: bool,
                strict: bool,
                super_call_allowed: bool,
                in_class: bool,
            }

            mod expressions {
                use super::*;

                pub(super) enum Frame {
                    Assignment,
                    AssignmentHead,
                    ConditionalYes(ExprId, bool),
                    ConditionalNo(ExprId, ExprId),
                    AssignmentRight(String, ExprId),
                    Sequence,
                    SequenceHead,
                    SequenceNext(Vec<ExprId>),
                    Binary(u8),
                    BinaryHead(u8),
                    BinaryRight(Binary, &'static str),
                    Unary,
                    Prefix(&'static str),
                    PrefixUpdate(f64),
                    Base(bool),
                    PostfixResume(Postfix),
                    Computed(Postfix, bool),
                    // Argument flags are (any spread, current operand is spread, saved allow_in).
                    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
                    New,
                    NewHead,
                    NewComputed(NewState, bool),
                    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
                    Primary,
                    CoverItem(Cover, bool),
                    ArrayItem(Array),
                    ObjectKey(Object, bool, bool),
                    AccessorKey(Object, bool),
                    ObjectFunction(Object, PropertyName, Option<bool>),
                    ObjectValue(Object, PropertyName, bool),
                    NamedFunction(Option<String>),
                    Key,
                    ComputedKey(bool),
                    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
                    Pass,
                    LeftHandSide,
                    LeftHandSideBase(bool),
                    ClassDone,
                    // Flags: any spread, current spread, saved allow_in, permit postfix update.
                    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),
                }

                pub(super) struct Binary {
                    left: ExprId,
                    operations: Vec<(String, ExprId)>,
                    min: u8,
                    chain: usize,
                }

                pub(super) struct Postfix {
                    value: ExprId,
                    chain: usize,
                    async_call: bool,
                    allow_update: bool,
                }

                pub(super) struct NewState {
                    value: ExprId,
                }

                pub(super) struct Cover {
                    items: Vec<(ExprId, bool)>,
                    saved_in: bool,
                }

                pub(super) struct Array {
                    items: Vec<Option<ExprId>>,
                    saved_in: bool,
                }

                pub(super) struct Object {
                    items: Vec<(code::PropertyName, ObjectEntry)>,
                    saved_in: bool,
                    prototype: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("expressions::Frame"),
                        row::<Binary>("expressions::Binary"),
                        row::<Postfix>("expressions::Postfix"),
                        row::<NewState>("expressions::NewState"),
                        row::<Cover>("expressions::Cover"),
                        row::<Array>("expressions::Array"),
                        row::<Object>("expressions::Object"),
                    ];
                    rows
                }
            }

            mod functions {
                use super::*;

                pub(super) enum Frame {
                    Start(bool),
                    Dynamic,
                    Default(State, String),
                    Body(State),
                    Arrow(Vec<Parameter>),
                    ArrowExpression(State),
                    // true only for a derived literal constructor; class methods use false.
                    ClassMethod(bool),
                }

                pub(super) struct State {
                    params: Vec<Parameter>,
                    saved: Context,
                    unique: bool,
                    arrow: bool,
                    dynamic: bool,
                }

                struct Context {
                    loop_depth: usize,
                    switch_depth: usize,
                    allow_in: bool,
                    strict: bool,
                    labels: Vec<ActiveLabel>,
                    new_target_allowed: bool,
                    super_call_allowed: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("functions::Frame"),
                        row::<State>("functions::State"),
                        row::<Context>("functions::Context"),
                    ];
                    rows
                }
            }

            mod statements {
                use super::*;

                pub(super) enum Frame {
                    Start { declarations: bool },
                    Controlled,
                    ControlledDone,
                    Expression,
                    Declaration(bool),
                    DeclarationDone,
                    DeclarationDefault(Vec<(String, Option<ExprId>)>, DeclarationKind, String, bool),
                    Function(String),
                    Block,
                    Label(usize, usize),
                    SwitchExpression,
                    SwitchCase(Switch),
                    SwitchNext(Switch),
                    SwitchStatement(Switch, Option<ExprId>, Vec<StmtId>),
                    IfCondition,
                    IfYes(ExprId),
                    IfNo(ExprId, StmtId),
                    WhileCondition,
                    WhileBody(ExprId),
                    DoBody,
                    DoCondition(StmtId),
                    ForDeclaration(bool),
                    ForExpression(bool, bool),
                    ForTest(Option<Stmt>),
                    ForUpdate(Option<Stmt>, Option<ExprId>),
                    ForBody(Option<Stmt>, Option<ExprId>, Option<ExprId>),
                    ForInObject(ForBinding),
                    ForInBody(ForBinding, ExprId),
                    ForOfObject(ForBinding),
                    ForOfBody(ForBinding, ExprId),
                    Return,
                    Throw,
                    TryBody,
                    CatchBody(StmtId, Option<String>),
                    FinallyBody(StmtId, Option<CatchClause>),
                    ClassDone,
                }

                pub(super) struct Switch {
                    value: ExprId,
                    cases: Vec<(Option<ExprId>, Vec<StmtId>)>,
                    default: bool,
                    lexical: bool,
                }

                pub(super) enum BodyFrame {
                    Start { block: bool, directive: bool },
                    Waiting(BodyState, Before),
                }

                pub(super) struct BodyState {
                    block: bool,
                    directive: bool,
                    start: usize,
                    prologue: bool,
                    body: Body,
                }

                pub(super) struct Before {
                    pos: usize,
                    string: bool,
                    strict: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("statements::Frame"),
                        row::<Switch>("statements::Switch"),
                        row::<BodyFrame>("statements::BodyFrame"),
                        row::<BodyState>("statements::BodyState"),
                        row::<Before>("statements::Before"),
                    ];
                    rows
                }
            }

            mod classes {
                use super::*;

                pub(super) enum Frame {
                    Start { declaration: bool },
                    Heritage(State),
                    Elements(State),
                    Key(State, Header),
                    Member(State, PropertyName, Header),
                }

                pub(super) struct State {
                    name: Option<String>,
                    heritage: Option<ExprId>,
                    constructor: Option<FunctionId>,
                    elements: Vec<code::ClassElement>,
                    saved: Context,
                }

                pub(super) struct Header {
                    kind: code::ClassElementKind,
                    is_static: bool,
                    is_constructor: bool,
                }

                struct Context {
                    strict: bool,
                    allow_in: bool,
                    in_class: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("classes::Frame"),
                        row::<State>("classes::State"),
                        row::<Header>("classes::Header"),
                        row::<Context>("classes::Context"),
                    ];
                    rows
                }
            }

            pub(super) fn rows() -> Vec<LayoutRow> {
                let mut rows = vec![
                    row::<Output>("driver::Output"),
                    row::<Body>("driver::Body"),
                    row::<Kind>("driver::Kind"),
                    row::<Transition>("driver::Transition"),
                    row::<EntryContext>("driver::EntryContext"),
                ];
                rows.extend(expressions::rows());
                rows.extend(functions::rows());
                rows.extend(statements::rows());
                rows.extend(classes::rows());
                rows
            }
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<PropertyName>("parser::PropertyName"),
                row::<ActiveLabel>("parser::ActiveLabel"),
                row::<Parser<'static>>("parser::Parser"),
            ];
            rows.extend(driver::rows());
            rows
        }
    }
    pub(super) fn rows() -> Vec<LayoutRow> { let mut rows = code::rows(); rows.extend(parser::rows()); rows }
}
mod proposed {
    use super::*;
    mod code {
        use super::*;

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ExprId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct StmtId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct FunctionId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) struct ClassId(usize);

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassKind {
            ExplicitBase,
            ExplicitDerived,
            DefaultBase,
            DefaultDerived,
        }

        #[derive(Clone, Copy, Debug, PartialEq, Eq)]
        pub(super) enum ClassElementKind {
            Method,
            Getter,
            Setter,
        }

        #[derive(Debug)]
        pub(super) struct Class {
            pub name: Option<String>,
            pub heritage: Option<ExprId>,
            pub constructor: FunctionId,
            pub elements: Vec<ClassElement>,
        }

        #[derive(Debug)]
        pub(super) struct ClassElement {
            pub name: PropertyName,
            pub function: FunctionId,
            pub kind: ClassElementKind,
            pub is_static: bool,
        }

        #[derive(Debug)]
        pub(super) struct Parameter {
            pub name: String,
            pub initializer: Option<ExprId>,
            pub rest: bool,
        }

        #[derive(Debug)]
        pub(super) struct Function {
            pub params: Vec<Parameter>,
            pub body: Vec<StmtId>,
            pub name: Option<String>,
            pub arrow: bool,
            pub self_name: bool,
            pub constructable: bool,
            pub strict: bool,
            pub class_kind: Option<ClassKind>,
        }

        #[derive(Debug)]
        pub(super) struct Unit {
            expressions: Records<Expr>,
            statements: Records<Stmt>,
            functions: Records<Function>,
            pub body: Vec<StmtId>,
            pub strict: bool,
            pub compiled_storage: usize,
            classes: Records<Class>,
        }

        #[derive(Clone, Debug)]
        pub(super) struct FunctionRef {
            pub unit: Rc<Unit>,
            id: FunctionId,
        }

        #[derive(Debug)]
        pub(super) enum Expr {
            Literal(Value),
            RegExp(Rc<RegExp>),
            Ident(String),
            NewTarget,
            Array(Vec<Option<ExprId>>),
            Object(Vec<(PropertyName, ObjectEntry)>),
            Unary(String, ExprId),
            BinaryChain(ExprId, Vec<(String, ExprId)>),
            Conditional(ExprId, ExprId, ExprId),
            Assign(String, ExprId, ExprId),
            Update(ExprId, f64, bool),
            Member(ExprId, ExprId),
            Call(ExprId, Vec<ExprId>),
            New(ExprId, Vec<ExprId>),
            CallSpread(ExprId, Vec<ExprId>),
            NewSpread(ExprId, Vec<ExprId>),
            SpreadArgument(ExprId),
            Function(FunctionId),
            Sequence(Vec<ExprId>),
            Template(JsString, Vec<(ExprId, JsString)>),
            Class(ClassId),
            SuperCall(Vec<ExprId>),
            SuperCallSpread(Vec<ExprId>),
            // Class home-object reference; the child remains an unevaluated raw key.
            SuperProperty(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum PropertyName {
            Literal(JsString),
            Computed(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum ObjectEntry {
            Data(ExprId),
            Method(FunctionId),
            Accessor(FunctionId, bool),
            Prototype(ExprId),
        }

        #[derive(Debug)]
        pub(super) enum Stmt {
            Empty,
            Label(usize, StmtId),
            Expr(ExprId),
            Var(Vec<(String, Option<ExprId>)>, DeclarationKind),
            Block(Vec<StmtId>),
            If(ExprId, StmtId, Option<StmtId>),
            While(ExprId, StmtId),
            DoWhile(ExprId, StmtId),
            For(Option<StmtId>, Option<ExprId>, Option<ExprId>, StmtId),
            ForIn(ForBinding, ExprId, StmtId),
            ForOf(ForBinding, ExprId, StmtId),
            Switch(ExprId, Vec<(Option<ExprId>, Vec<StmtId>)>),
            Function(String, FunctionId),
            Return(Option<ExprId>),
            Throw(ExprId),
            Try(StmtId, Option<CatchClause>, Option<StmtId>),
            Break(Option<usize>),
            Continue(Option<usize>),
            Class(ClassId),
        }

        #[derive(Debug)]
        pub(super) enum ForBinding {
            Declaration(String, DeclarationKind),
            Target(ExprId),
        }

        #[derive(Debug)]
        pub(super) struct CatchClause {
            pub binding: Option<String>,
            pub body: Vec<StmtId>,
        }

        #[derive(Debug)]
        pub(super) struct Records<T> {
            pages: Vec<Vec<T>>,
            length: usize,
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<ExprId>("code::ExprId"),
                row::<StmtId>("code::StmtId"),
                row::<FunctionId>("code::FunctionId"),
                row::<ClassId>("code::ClassId"),
                row::<ClassKind>("code::ClassKind"),
                row::<ClassElementKind>("code::ClassElementKind"),
                row::<Class>("code::Class"),
                row::<ClassElement>("code::ClassElement"),
                row::<Parameter>("code::Parameter"),
                row::<Function>("code::Function"),
                row::<Unit>("code::Unit"),
                row::<FunctionRef>("code::FunctionRef"),
                row::<Expr>("code::Expr"),
                row::<PropertyName>("code::PropertyName"),
                row::<ObjectEntry>("code::ObjectEntry"),
                row::<Stmt>("code::Stmt"),
                row::<ForBinding>("code::ForBinding"),
                row::<CatchClause>("code::CatchClause"),
                row::<Records<Expr>>("code::Records<Expr>"),
                row::<Records<Class>>("code::Records<Class>"),
                row::<Records<Function>>("code::Records<Function>"),
            ];
            rows
        }
    }
    mod parser {
        use super::*;
        use code::{CatchClause, ClassId, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId};

        enum PropertyName {
            Literal(JsString, bool),
            Computed(ExprId),
        }

        struct ActiveLabel {
            name: String,
            target: usize,
            iteration: bool,
        }

        pub(super) struct Parser<'source> {
            tokens: tokens::Tokens,
            source: &'source str,
            lex_work: usize,
            compile_budget: regexp::Budget,
            unit: code::Unit,
            pos: usize,
            function_depth: usize,
            new_target_allowed: bool,
            loop_depth: usize,
            switch_depth: usize,
            labels: Vec<ActiveLabel>,
            next_label: usize,
            allow_in: bool,
            strict: bool,
            super_call_allowed: bool,
            super_property_allowed: bool,
            super_property_deferred: bool,
            in_class: bool,
        }

        mod driver {
            use super::*;

            enum Output {
                Expression(ExprId),
                Statement(StmtId),
                Body(Body),
                Function(FunctionCode),
                Parameters(functions::State),
                Key(PropertyName),
                Declaration(Stmt),
                Class(ClassId),
            }

            struct Body {
                statements: Vec<StmtId>,
                own_strict: bool,
                has_lexical: bool,
            }

            enum Kind {
                Expression(expressions::Frame),
                Statement(statements::Frame),
                Function(functions::Frame),
                Body(statements::BodyFrame),
                Class(classes::Frame),
            }

            enum Transition {
                Done(Output),
                Again(Kind),
                Child(Kind, Kind),
            }

            struct EntryContext {
                allow_in: bool,
                strict: bool,
                super_call_allowed: bool,
                super_property_allowed: bool,
                super_property_deferred: bool,
                in_class: bool,
            }

            mod expressions {
                use super::*;

                pub(super) enum Frame {
                    Assignment,
                    AssignmentHead,
                    ConditionalYes(ExprId, bool),
                    ConditionalNo(ExprId, ExprId),
                    AssignmentRight(String, ExprId),
                    Sequence,
                    SequenceHead,
                    SequenceNext(Vec<ExprId>),
                    Binary(u8),
                    BinaryHead(u8),
                    BinaryRight(Binary, &'static str),
                    Unary,
                    Prefix(&'static str),
                    PrefixUpdate(f64),
                    Base(bool),
                    PostfixResume(Postfix),
                    Computed(Postfix, bool),
                    // Argument flags are (any spread, current operand is spread, saved allow_in).
                    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
                    New,
                    NewHead,
                    NewComputed(NewState, bool),
                    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
                    Primary,
                    CoverItem(Cover, bool),
                    ArrayItem(Array),
                    ObjectKey(Object, bool, bool),
                    AccessorKey(Object, bool),
                    ObjectFunction(Object, PropertyName, Option<bool>),
                    ObjectValue(Object, PropertyName, bool),
                    NamedFunction(Option<String>),
                    Key,
                    ComputedKey(bool),
                    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
                    Pass,
                    LeftHandSide,
                    LeftHandSideBase(bool),
                    ClassDone,
                    // Flags: any spread, current spread, saved allow_in, permit postfix update.
                    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),
                    SuperPropertyKey(bool),
                }

                pub(super) struct Binary {
                    left: ExprId,
                    operations: Vec<(String, ExprId)>,
                    min: u8,
                    chain: usize,
                }

                pub(super) struct Postfix {
                    value: ExprId,
                    chain: usize,
                    async_call: bool,
                    allow_update: bool,
                }

                pub(super) struct NewState {
                    value: ExprId,
                }

                pub(super) struct Cover {
                    items: Vec<(ExprId, bool)>,
                    saved_in: bool,
                }

                pub(super) struct Array {
                    items: Vec<Option<ExprId>>,
                    saved_in: bool,
                }

                pub(super) struct Object {
                    items: Vec<(code::PropertyName, ObjectEntry)>,
                    saved_in: bool,
                    prototype: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("expressions::Frame"),
                        row::<Binary>("expressions::Binary"),
                        row::<Postfix>("expressions::Postfix"),
                        row::<NewState>("expressions::NewState"),
                        row::<Cover>("expressions::Cover"),
                        row::<Array>("expressions::Array"),
                        row::<Object>("expressions::Object"),
                    ];
                    rows
                }
            }

            mod functions {
                use super::*;

                pub(super) enum Frame {
                    Start(bool),
                    Dynamic,
                    Default(State, String),
                    Body(State),
                    Arrow(Vec<Parameter>),
                    ArrowExpression(State),
                    // true only for a derived literal constructor; class methods use false.
                    ClassMethod(bool),
                    // Object methods have a valid super grammar but no selected runtime home object.
                    ObjectMethod,
                }

                pub(super) struct State {
                    params: Vec<Parameter>,
                    saved: Context,
                    unique: bool,
                    arrow: bool,
                    dynamic: bool,
                }

                struct Context {
                    loop_depth: usize,
                    switch_depth: usize,
                    allow_in: bool,
                    strict: bool,
                    labels: Vec<ActiveLabel>,
                    new_target_allowed: bool,
                    super_call_allowed: bool,
                    super_property_allowed: bool,
                    super_property_deferred: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("functions::Frame"),
                        row::<State>("functions::State"),
                        row::<Context>("functions::Context"),
                    ];
                    rows
                }
            }

            mod statements {
                use super::*;

                pub(super) enum Frame {
                    Start { declarations: bool },
                    Controlled,
                    ControlledDone,
                    Expression,
                    Declaration(bool),
                    DeclarationDone,
                    DeclarationDefault(Vec<(String, Option<ExprId>)>, DeclarationKind, String, bool),
                    Function(String),
                    Block,
                    Label(usize, usize),
                    SwitchExpression,
                    SwitchCase(Switch),
                    SwitchNext(Switch),
                    SwitchStatement(Switch, Option<ExprId>, Vec<StmtId>),
                    IfCondition,
                    IfYes(ExprId),
                    IfNo(ExprId, StmtId),
                    WhileCondition,
                    WhileBody(ExprId),
                    DoBody,
                    DoCondition(StmtId),
                    ForDeclaration(bool),
                    ForExpression(bool, bool),
                    ForTest(Option<Stmt>),
                    ForUpdate(Option<Stmt>, Option<ExprId>),
                    ForBody(Option<Stmt>, Option<ExprId>, Option<ExprId>),
                    ForInObject(ForBinding),
                    ForInBody(ForBinding, ExprId),
                    ForOfObject(ForBinding),
                    ForOfBody(ForBinding, ExprId),
                    Return,
                    Throw,
                    TryBody,
                    CatchBody(StmtId, Option<String>),
                    FinallyBody(StmtId, Option<CatchClause>),
                    ClassDone,
                }

                pub(super) struct Switch {
                    value: ExprId,
                    cases: Vec<(Option<ExprId>, Vec<StmtId>)>,
                    default: bool,
                    lexical: bool,
                }

                pub(super) enum BodyFrame {
                    Start { block: bool, directive: bool },
                    Waiting(BodyState, Before),
                }

                pub(super) struct BodyState {
                    block: bool,
                    directive: bool,
                    start: usize,
                    prologue: bool,
                    body: Body,
                }

                pub(super) struct Before {
                    pos: usize,
                    string: bool,
                    strict: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("statements::Frame"),
                        row::<Switch>("statements::Switch"),
                        row::<BodyFrame>("statements::BodyFrame"),
                        row::<BodyState>("statements::BodyState"),
                        row::<Before>("statements::Before"),
                    ];
                    rows
                }
            }

            mod classes {
                use super::*;

                pub(super) enum Frame {
                    Start { declaration: bool },
                    Heritage(State),
                    Elements(State),
                    Key(State, Header),
                    Member(State, PropertyName, Header),
                }

                pub(super) struct State {
                    name: Option<String>,
                    heritage: Option<ExprId>,
                    constructor: Option<FunctionId>,
                    elements: Vec<code::ClassElement>,
                    saved: Context,
                }

                pub(super) struct Header {
                    kind: code::ClassElementKind,
                    is_static: bool,
                    is_constructor: bool,
                }

                struct Context {
                    strict: bool,
                    allow_in: bool,
                    in_class: bool,
                }

                pub(super) fn rows() -> Vec<LayoutRow> {
                    let mut rows = vec![
                        row::<Frame>("classes::Frame"),
                        row::<State>("classes::State"),
                        row::<Header>("classes::Header"),
                        row::<Context>("classes::Context"),
                    ];
                    rows
                }
            }

            pub(super) fn rows() -> Vec<LayoutRow> {
                let mut rows = vec![
                    row::<Output>("driver::Output"),
                    row::<Body>("driver::Body"),
                    row::<Kind>("driver::Kind"),
                    row::<Transition>("driver::Transition"),
                    row::<EntryContext>("driver::EntryContext"),
                ];
                rows.extend(expressions::rows());
                rows.extend(functions::rows());
                rows.extend(statements::rows());
                rows.extend(classes::rows());
                rows
            }
        }

        pub(super) fn rows() -> Vec<LayoutRow> {
            let mut rows = vec![
                row::<PropertyName>("parser::PropertyName"),
                row::<ActiveLabel>("parser::ActiveLabel"),
                row::<Parser<'static>>("parser::Parser"),
            ];
            rows.extend(driver::rows());
            rows
        }
    }
    pub(super) fn rows() -> Vec<LayoutRow> { let mut rows = code::rows(); rows.extend(parser::rows()); rows }
}
fn actual_rows() -> Vec<LayoutRow> {
    vec![
        row::<code::ExprId>("code::ExprId"),
        row::<code::StmtId>("code::StmtId"),
        row::<code::FunctionId>("code::FunctionId"),
        row::<code::ClassId>("code::ClassId"),
        row::<code::ClassKind>("code::ClassKind"),
        row::<code::ClassElementKind>("code::ClassElementKind"),
        row::<code::Class>("code::Class"),
        row::<code::ClassElement>("code::ClassElement"),
        row::<code::Parameter>("code::Parameter"),
        row::<code::Function>("code::Function"),
        row::<code::Unit>("code::Unit"),
        row::<code::FunctionRef>("code::FunctionRef"),
        row::<code::Expr>("code::Expr"),
        row::<code::PropertyName>("code::PropertyName"),
        row::<code::ObjectEntry>("code::ObjectEntry"),
        row::<code::Stmt>("code::Stmt"),
        row::<code::ForBinding>("code::ForBinding"),
        row::<code::CatchClause>("code::CatchClause"),
        row::<super::super::PropertyName>("parser::PropertyName"),
        row::<super::super::ActiveLabel>("parser::ActiveLabel"),
        row::<super::super::Parser<'static>>("parser::Parser"),
        row::<super::Output>("driver::Output"),
        row::<super::Body>("driver::Body"),
        row::<super::Kind>("driver::Kind"),
        row::<super::Transition>("driver::Transition"),
        row::<super::EntryContext>("driver::EntryContext"),
        row::<super::expressions::Frame>("expressions::Frame"),
        row::<super::expressions::Binary>("expressions::Binary"),
        row::<super::expressions::Postfix>("expressions::Postfix"),
        row::<super::expressions::NewState>("expressions::NewState"),
        row::<super::expressions::Cover>("expressions::Cover"),
        row::<super::expressions::Array>("expressions::Array"),
        row::<super::expressions::Object>("expressions::Object"),
        row::<super::functions::Frame>("functions::Frame"),
        row::<super::functions::State>("functions::State"),
        row::<super::statements::Frame>("statements::Frame"),
        row::<super::statements::Switch>("statements::Switch"),
        row::<super::statements::BodyFrame>("statements::BodyFrame"),
        row::<super::statements::BodyState>("statements::BodyState"),
        row::<super::statements::Before>("statements::Before"),
        row::<super::classes::Frame>("classes::Frame"),
        row::<super::classes::State>("classes::State"),
        row::<super::classes::Header>("classes::Header"),
    ]
}
#[test]
fn super_property_layout_parser_actual() {
    let before = before::rows();
    let proposed = proposed::rows();
    let actual = actual_rows();
    for live in &actual {
        assert_eq!(proposed.iter().find(|row| row.name == live.name).unwrap(), live);
    }
    for (version, rows) in [("before", &before), ("proposed", &proposed), ("actual", &actual)] {
        let mut seen = std::collections::BTreeSet::new();
        for row in rows {
            assert!(seen.insert(row.name));
            eprintln!("SUPER_PARSER_LAYOUT version={version} type={} size={} align={}", row.name, row.size, row.align);
        }
        let kind = rows.iter().find(|row| row.name == "driver::Kind").unwrap();
        let expr = rows.iter().find(|row| row.name == "code::Expr").unwrap();
        eprintln!("SUPER_PARSER_FORMULAS version={version} frames4={} frames8={} frame_limit={} expr_page={}", 4 * kind.size + 32, 8 * kind.size + 32, MAX_HEAP / kind.size, 128 * expr.size + 32);
    }
    eprintln!("SUPER_PARSER_CONFIG rust_host={} vulkan_raster={}", cfg!(feature = "test262-host"), cfg!(feature = "vulkan-raster"));
    eprintln!("SUPER_PARSER_COUNTS actual={} before={} proposed={}", actual.len(), before.len(), proposed.len());
}
