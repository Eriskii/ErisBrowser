from pathlib import Path
import json,hashlib,subprocess,re,difflib
K=Path('/tmp/eris-super-properties-plan-1');P=K/'parser-producer-1';L=K/'parser-layout-probe-1';R=K/'parser-review-1';W=K/'worktree';BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return {'path':str(p.relative_to(K)),'bytes':len(b),'sha256':sha(b)}
def verify(binding,root=None):
 p=Path(binding['path']);p=p if p.is_absolute() else root/p
 b=p.read_bytes();assert len(b)==binding['bytes'] and sha(b)==binding['sha256'],p
 return p
ready=json.loads((P/'source-ready.json').read_text())
for row in ready['files']:verify(row,P)
for key in ['selection','readiness_refresh','interfaces','checks','edit_inverses','changed_seams','test_expectations']:verify(ready[key])
rows=[]
for row in ready['payloads']:
 raw=verify(row['raw']); after=raw.read_bytes();before=b''
 if 'before' in row:
  before=verify(row['before']).read_bytes();assert before==subprocess.check_output(['git','show',BASE+':'+row['path']],cwd=W)
 diff=verify(row['diff']);exp=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+row['path'] if before else '/dev/null',tofile='b/'+row['path']))
 assert exp==diff.read_text()
 rows.append({'repository_path':row['path'],'before_sha256':sha(before) if before else None,'raw':bind(raw),'diff':bind(diff)})
inverses=json.loads((P/'edit-inverses.json').read_text());edits=0
for row in inverses['files']:
 a=(P/'before'/row['path']).read_text();b=(P/'raw'/row['path']).read_text()
 assert sha(a.encode())==row['before_sha256'] and sha(b.encode())==row['after_sha256']
 forward=a;reverse=b
 for e in reversed(row['edits']):
  assert a[e['before_start']:e['before_end']]==e['before']
  assert b[e['after_start']:e['after_end']]==e['after']
  forward=forward[:e['before_start']]+e['after']+forward[e['before_end']:]
  reverse=reverse[:e['after_start']]+e['before']+reverse[e['after_end']:]
 assert forward==b and reverse==a
 edits+=len(row['edits'])
# Compare full declaration blocks independently, including every neighboring variant.
def declarations(s):
 result={}
 for m in re.finditer(r'(?m)^(?:pub(?:\([^\n]*?\))?\s+)?(?:struct|enum)\s+(\w+)',s):
  name=m[1];brace=s.find('{',m.end());semi=s.find(';',m.end())
  if semi>=0 and (brace<0 or semi<brace):end=semi+1
  else:
   depth=0;end=None
   for n in range(brace,len(s)):
    if s[n]=='{':depth+=1
    elif s[n]=='}':
     depth-=1
     if depth==0:end=n+1;break
   assert end is not None
  start=m.start()
  while start:
   prev=s.rfind('\n',0,start-1)+1;line=s[prev:start].strip()
   if line.startswith('#[') and line.endswith(']'):start=prev
   else:break
  result[name]=s[start:end]
 return result
sources={'code':'src/script/code.rs','records':'src/script/code/records.rs','parser':'src/script/parser.rs','driver':'src/script/parser/driver.rs','expressions':'src/script/parser/driver/expressions.rs','functions':'src/script/parser/driver/functions.rs','statements':'src/script/parser/driver/statements.rs','classes':'src/script/parser/driver/classes.rs'}
shape_rows=[]
for version in ['before','proposed']:
 for group,path in sources.items():
  old=subprocess.check_output(['git','show',BASE+':'+path],cwd=W).decode()
  text=(P/'raw'/path).read_text() if version=='proposed' and (P/'raw'/path).exists() else old
  actual=declarations(text);shape=L/'shapes'/version/(group+'.rs');want=declarations(shape.read_text())
  for name,decl in want.items():
   assert decl==actual[name],(version,group,name)
   shape_rows.append({'version':version,'group':group,'type':name,'bytes':len(decl.encode()),'sha256':sha(decl.encode())})
probe=json.loads((L/'source-ready.json').read_text())
for row in probe['files']:verify(row,L)
# Read, hash and parse each completed root execution receipt/log independently.
measurements=json.loads((K/'root/layout-measurements-1.json').read_text());observed=[]
for m in measurements['measurements']:
 receipt=K/'validation'/(m['label']+'.json');j=json.loads(receipt.read_text());log=K/'validation'/j['log'];text=log.read_text()
 assert sha(receipt.read_bytes())==m['receipt_sha256']
 assert sha(log.read_bytes())==m['log_sha256']==j['sha256'] and j['exit']==0
 runtime={name:{'bytes':int(size),'alignment':int(align)} for name,size,align in re.findall(r'SUPER_LAYOUT (\S+) (\d+) (\d+)',text)}
 assert runtime==m['runtime']
 parser={v:{} for v in ['actual','before','proposed']}
 for version,name,size,align in re.findall(r'SUPER_PARSER_LAYOUT version=(\w+) type=(\S+) size=(\d+) align=(\d+)',text):
  assert name not in parser[version]
  parser[version][name]={'bytes':int(size),'alignment':int(align)}
 assert parser==m['parser']
 result=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
 assert len(result)==1 and result[0][1:4]==('0','0','0')
 expected=2 if m['label'].startswith('parser-') else 1
 assert int(result[0][0])==expected
 formulas=re.findall(r'SUPER_PARSER_FORMULAS version=(\w+) frames4=(\d+) frames8=(\d+) frame_limit=(\d+) expr_page=(\d+)',text)
 if parser['before']:
  assert len(parser['before'])==len(parser['proposed'])==48
  assert formulas==[('before','512','992','69905','6176'),('proposed','512','992','69905','6176')]
  delta={k:(parser['before'][k],parser['proposed'][k]) for k in parser['before'] if parser['before'][k]!=parser['proposed'][k]}
  assert delta=={'driver::EntryContext':({'bytes':4,'alignment':1},{'bytes':6,'alignment':1})}
  assert 'SUPER_PARSER_COUNTS actual=43 before=48 proposed=48' in text
 observed.append({'label':m['label'],'receipt':bind(receipt),'log':bind(log),'passed_groups':expected,'runtime':runtime,'parser':parser,'formulas':formulas})
checks={'payloads':rows,'exact_offset_edits':edits,'forward_and_inverse_all_six_existing_paths':True,'declaration_joins':shape_rows,'executed_layout_receipts':observed,'project_execution_by_reviewer':False}
(R/'source-and-layout-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
report={
 'status':'clear for bounded source and retained-layout review','base':BASE,'producer':bind(P/'source-ready.json'),'layout_probe':bind(L/'source-ready.json'),'measurement_summary':bind(K/'root/layout-measurements-1.json'),'checks':bind(R/'source-and-layout-checks.json'),'findings':[],
 'permission_review':[
  'Parser starts with both property flags false. Non-arrow Context entry saves then clears both and super-call permission; ClassMethod enables properties and enables calls only for the selected derived literal constructor. ObjectMethod enables only the deferred property flag, preserving old unique parameter/body processing.',
  'Arrow Context preserves enclosing flags, including defaults parsed by the existing cover grammar. A nested ordinary function clears allowed and deferred states before parameters. finish restores both flags on success; driver run restores both entry values on any error without refunding work.',
  'The unchanged class context changes strict/in_class/allow_in only. Nested class heritage and computed element names inherit enclosing property permission; each actual member gets a fresh ClassMethod context and restores it afterward. Top-level class heritage/names have no inherited super permission.'
 ],
 'grammar_review':[
  'Unary and LeftHandSide route super-dot/bracket through New/Primary; direct super-call stays in the existing super_start path. SuperProperty is a flat ExprId key edge and participates in existing member/new/postfix handling, without a recursive syntax owner.',
  'Dot names use the existing IdentifierName reader, including keyword/escaped names where that grammar permits them. Computed names parse Sequence under +In then restore the saved flag, so comma and in inside brackets do not consume an enclosing for-head delimiter.',
  'Assignment/update accept SuperProperty directly; delete emits the existing Unary record for runtime ReferenceError. For-in/of use ForBinding::Target, while ordinary member descendants remain ordinary Member nodes. Parentheses retain the direct reference; comma produces a distinct Sequence boundary.',
  'Malformed bare super and direct new super-call remain parse errors; disallowed ordinary/top-level super properties are parse errors. Valid object-method super remains explicitly Unsupported. Existing private/field/static-block/async/generator/tagged-template/optional boundaries are not expanded.',
  'Legacy canonical inverse explicitly refuses the new node alongside existing class-only records. Old legacy parser and historical test literals are unchanged; complete offset inverses recover all old bytes beyond selected seams.'
 ],
 'layout_review':{
  'all_declarations':'Every complete before/proposed code/parser/driver declaration in the inert probe matches the published/current selected source, including all old enum variants.',
  'recorded_runs':'Four completed receipts: runtime-only probes in two configurations, then combined runtime/parser probes in those configurations. They are not four distinct toolchain configurations.',
  'parser_delta':'Only stack EntryContext changes 4 to6 bytes in the 48-row parser mirror; Parser328, Unit168, code Expr48, driverKind120 and Transition240 remain exact. Actual43 accessible parent-layout assertions passed in each parser run.',
  'parser_heap':'frames4=512, frames8=992, frame_limit=69905, expression page=6176 remain exact. Existing typed allocation/admission formulas and heap ceiling are unchanged.',
  'runtime_delta':'The four retained logs repeat the selected Function104→120, Reference56→80, Phase96→112, ExprFrame128→144, Output56→80 measurements; Environment112 and topFrame184 remain unchanged.'
 },
 'qualifications':[
  'No parser execution, project import, build/test, live edits or new measurement by this reviewer. Semantic candidate compilation and tests remain root-owned.',
  'Measurements are inert proposed-shape observations on Rust1.88 ordinary and Rust1.99 host+Vulkan. Final actual candidate declarations/layout must still be checked; no all-architecture claim.',
  'This is a bounded review of the selected class-only grammar. It does not assert a complete ECMAScript parser or alter prior unsupported syntax policies.',
  'The producer retains its stopped initial inverse-checker orchestration attempt; the payload was unchanged and final forward/inverse checks are independently reproduced here.'
 ],'project_execution':False,'live_edits':False}
(R/'review.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(R/'review.json'),indent=2))
