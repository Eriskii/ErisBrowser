"""External source-only historical expectation migration; no project execution."""
from pathlib import Path
import difflib,hashlib,json,re
K=Path('/tmp/eris-super-properties-plan-1');P=K/'historical-layout-migration-1'
def sha(data):return hashlib.sha256(data).hexdigest()
def b(path):
    data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def put(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
inventory=json.loads((K/'source-candidate-1.json').read_bytes());items={x['path']:x for x in inventory['files']}
layout=json.loads((K/'root/actual-layout-measurements-1.json').read_bytes())
for measurement in layout['measurements']:
    for name,expected in [('Function.actual',[120,8]),('Phase.actual',[112,8]),('ExprFrame.actual',[144,8]),('Reference.actual',[80,8]),('Frame.actual',[184,8]),('Output.actual',[80,8])]:
        assert measurement['runtime'][name]==expected,(measurement['label'],name)
    receipt=K/'validation'/(measurement['label']+'.json');log=K/'validation'/(measurement['label']+'.log')
    assert b(receipt)['sha256']==measurement['receipt_sha256'] and b(log)['sha256']==measurement['log_sha256']
edits={
 'src/script/classes/quota_tests.rs': [('assert_eq!(size_of::<Function>(), 104);','assert_eq!(size_of::<Function>(), 120);')],
 'src/script/machine/call_spread_phase_tests.rs': [
 ('fn actual_call_spread_machine_layout_matches_both_held_mirrors() {',
  'fn actual_call_spread_machine_layout_after_super_property_extension() {\n    // Historical call-spread mirrors remain retained. SuperProperty enlarges\n    // Phase, ExprFrame and Reference; the top frame and its capacity stay fixed.'),
 ('assert_eq!((size_of::<Phase>(), align_of::<Phase>()), (96, 8));','assert_eq!((size_of::<Phase>(), align_of::<Phase>()), (112, 8));'),
 ('assert_eq!((size_of::<ExprFrame>(), align_of::<ExprFrame>()), (128, 8));','assert_eq!((size_of::<ExprFrame>(), align_of::<ExprFrame>()), (144, 8));'),
 ('assert_eq!((size_of::<Reference>(), align_of::<Reference>()), (56, 8));','assert_eq!((size_of::<Reference>(), align_of::<Reference>()), (80, 8));')],
 'src/script/typed_array/tests.rs': [
 ('    // The cumulative remainder below starts from MAX_STEPS; only its',
  '    // SuperProperty adds one saved home slot to the retained intrinsic Function.\n    // Its bootstrap charge is separate from every historical installation term.\n    let function_home_added = size_of::<Option<usize>>();\n    // The cumulative remainder below starts from MAX_STEPS; only its'),
 ('            + class_added\n','            + class_added\n            + function_home_added\n')]
}
rows=[]
for name,pairs in edits.items():
    origin=K/'candidate-source-1'/name
    if not origin.exists():origin=K/'worktree'/name
    data=origin.read_bytes();assert len(data)==items[name]['bytes'] and sha(data)==items[name]['sha256']
    before=data.decode();after=before
    for old,new in pairs:
        assert after.count(old)==1,(name,old);after=after.replace(old,new)
    inverse=after
    for old,new in reversed(pairs):
        assert inverse.count(new)==1;inverse=inverse.replace(new,old)
    assert inverse==before
    beforepath=P/'before'/name;rawpath=P/'raw'/name;diffpath=P/'diff'/(name+'.diff')
    for path in (beforepath,rawpath,diffpath):path.parent.mkdir(parents=True,exist_ok=True)
    beforepath.write_bytes(data);rawpath.write_text(after)
    diffpath.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name)))
    oldgroups=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',before);newgroups=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',after)
    normalized=[x.replace('actual_call_spread_machine_layout_matches_both_held_mirrors','actual_call_spread_machine_layout_after_super_property_extension') for x in oldgroups]
    assert normalized==newgroups
    rows.append({'path':name,'before':b(beforepath),'raw':b(rawpath),'diff':b(diffpath),'replacements':[{'before':x,'after':y} for x,y in pairs],'test_groups':len(oldgroups),'new_groups':0})
production=K/'runtime-producer-1/raw/src/script.rs'
assert 'const FUNCTION_HOME_BYTES: usize = std::mem::size_of::<Option<usize>>();' in production.read_text()
assert '+ FUNCTION_HOME_BYTES,' in production.read_text()
put('source-ready.json',{
 'status':'sealed additive historical expectation migration; no import or execution',
 'base':inventory['base'],'candidate1':b(K/'source-candidate-1.json'),'actual_layout_measurements':b(K/'root/actual-layout-measurements-1.json'),
 'production_tariff_source':b(production),'production_hold':b(K/'runtime-producer-1/source-ready.json'),
 'original_full_attempt':{'receipt':b(K/'validation/candidate-full-msrv-1.json'),'log':b(K/'validation/candidate-full-msrv-1.log')},
 'paths':rows,'whole_file_inverses':True,
 'function_renames':[{'path':'src/script/machine/call_spread_phase_tests.rs','before':'actual_call_spread_machine_layout_matches_both_held_mirrors','after':'actual_call_spread_machine_layout_after_super_property_extension'}],
 'derivation':{'Function':'Measured complete 104→120 with saved Option<usize> home; unchanged architecture guard.',
 'machine':'Measured Phase96→112, ExprFrame128→144, Reference56→80. Output80 is independently measured but this historical test contains no Output assertion to migrate.',
 'bootstrap':'Existing one retained intrinsic Function charge adds sizeof<Option<usize>>() exactly once, measured16. Retained historical expression1775930 becomes1775946 on measured targets; no numeric replacement of its terms.',
 'preserved':'Top Frame184, statements Frame184, calls Frame112, Arguments32, Value24, initial1504/MAX_FRAMES45590, both Runtime widths, work budget, arena counts, all old expression terms and unrelated test bodies.'},
 'qualification':'Three previously missed historical assertions are retained in candidate1 and its first failing full attempt. This hold changes only test expectations and one explanatory test name/comment; no production or tariff change. Candidate2 validation remains root-owned.',
 'project_execution':False,'live_edits':False})
print(json.dumps(b(P/'source-ready.json')))
