from pathlib import Path
import hashlib,json,re,subprocess,difflib
K=Path('/tmp/eris-super-properties-plan-1');O=K/'parser-layout-probe-1';P=K/'parser-producer-1';W=K/'worktree';BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':sha(b)}
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def put(p,v):write(p,json.dumps(v,indent=2)+'\n')
def declaration(s,name):
 m=re.search(r'(?m)^(?:pub(?:\([^\n]*?\))?\s+)?(?:struct|enum)\s+'+re.escape(name)+r'(?:\b|(?=<))',s);assert m,name
 start=m.start();brace=s.find('{',m.end());semi=s.find(';',m.end())
 if semi!=-1 and (brace==-1 or semi<brace):end=semi+1
 else:
  depth=0;end=None
  for i in range(brace,len(s)):
   if s[i]=='{':depth+=1
   elif s[i]=='}':
    depth-=1
    if depth==0:end=i+1;break
  assert end is not None,name
 while start>0:
  prev=s.rfind('\n',0,start-1)+1;line=s[prev:start].strip()
  if line.startswith('#[') and line.endswith(']'):start=prev
  else:break
 return s[start:end]
def ind(s):return '\n'.join('    '+x if x else '' for x in s.splitlines())+'\n'
specs={
'code':('src/script/code.rs',['ExprId','StmtId','FunctionId','ClassId','ClassKind','ClassElementKind','Class','ClassElement','Parameter','Function','Unit','FunctionRef','Expr','PropertyName','ObjectEntry','Stmt','ForBinding','CatchClause']),
'records':('src/script/code/records.rs',['Records']),
'parser':('src/script/parser.rs',['PropertyName','ActiveLabel','Parser']),
'driver':('src/script/parser/driver.rs',['Output','Body','Kind','Transition','EntryContext']),
'expressions':('src/script/parser/driver/expressions.rs',['Frame','Binary','Postfix','NewState','Cover','Array','Object']),
'functions':('src/script/parser/driver/functions.rs',['Frame','State','Context']),
'statements':('src/script/parser/driver/statements.rs',['Frame','Switch','BodyFrame','BodyState','Before']),
'classes':('src/script/parser/driver/classes.rs',['Frame','State','Header','Context'])}
frags={};inputs=[];rows=[]
for g,(path,names) in specs.items():
 before=subprocess.check_output(['git','show',BASE+':'+path],cwd=W).decode()
 proposed=(P/'raw'/path).read_text() if (P/'raw'/path).exists() else before
 inputs.append({'path':path,'before_sha256':sha(before.encode()),'proposed_sha256':sha(proposed.encode())})
 for version,text in [('before',before),('proposed',proposed)]:
  chunks=[]
  for name in names:
   d=declaration(text,name);chunks.append(d);rows.append({'version':version,'group':g,'type':name,'declaration_sha256':sha(d.encode()),'complete':True})
  frags[version,g]='\n\n'.join(chunks)+'\n';write(O/'shapes'/version/(g+'.rs'),frags[version,g])
def rowsfn(g,children=()):
 names=specs[g][1];body='pub(super) fn rows() -> Vec<LayoutRow> {\n    let mut rows = vec![\n'
 for n in names:
  ty=n+"<'static>" if n=='Parser' else n
  body+='        row::<'+ty+'>('+json.dumps(g+'::'+n)+'),\n'
 if g=='code':
  for n in ['Expr','Class','Function']:body+='        row::<Records<'+n+'>>('+json.dumps('code::Records<'+n+'>')+'),\n'
 body+='    ];\n'
 for c in children:body+='    rows.extend('+c+'::rows());\n'
 return body+'    rows\n}\n'
def mod(version,g,children=()):
 text='use super::*;\n'
 if g=='parser':text+='use code::{CatchClause, ClassId, Expr, ExprId, ForBinding, Function as FunctionCode, FunctionId, ObjectEntry, Parameter, Stmt, StmtId};\n'
 text+='\n'+frags[version,g]+'\n'
 if g=='code':text+=frags[version,'records']+'\n'
 for name,body in children:text+='mod '+name+' {\n'+ind(body)+'}\n\n'
 text+=rowsfn(g,[n for n,_ in children]);return text
def graph(v):
 driver=mod(v,'driver',[(g,mod(v,g)) for g in ['expressions','functions','statements','classes']])
 text='use super::*;\nmod code {\n'+ind(mod(v,'code'))+'}\nmod parser {\n'+ind(mod(v,'parser',[('driver',driver)]))+'}\n'
 text+='pub(super) fn rows() -> Vec<LayoutRow> { let mut rows = code::rows(); rows.extend(parser::rows()); rows }\n'
 return text
header='''//! Inert complete super-property parser/code layout mirrors; no parser methods run.
#![allow(dead_code, unused_mut, unused_imports)]
use super::*;
use std::mem::{align_of, size_of};

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
struct LayoutRow { name: &'static str, size: usize, align: usize }
fn row<T>(name: &'static str) -> LayoutRow {
    LayoutRow { name, size: size_of::<T>(), align: align_of::<T>() }
}
'''
raw=header+'\nmod before {\n'+ind(graph('before'))+'}\nmod proposed {\n'+ind(graph('proposed'))+'}\n'
actual=[]
for g,(path,names) in specs.items():
 if g=='records':continue
 for n in names:
  if g in ['functions','classes'] and n=='Context':continue
  if g=='code':ty='code::'+n
  elif g=='parser':ty='super::super::'+n+("<'static>" if n=='Parser' else '')
  elif g=='driver':ty='super::'+n
  else:ty='super::'+g+'::'+n
  actual.append((g+'::'+n,ty))
raw+='fn actual_rows() -> Vec<LayoutRow> {\n    vec![\n'+''.join('        row::<'+ty+'>('+json.dumps(label)+'),\n' for label,ty in actual)+'    ]\n}\n'
raw+='''#[test]
fn super_property_parser_complete_layouts() {
    let before = before::rows();
    let proposed = proposed::rows();
    let actual = actual_rows();
    for live in &actual {
        assert_eq!(before.iter().find(|row| row.name == live.name).unwrap(), live);
    }
    for (version, rows) in [("before", &before), ("proposed", &proposed)] {
        let mut seen = std::collections::BTreeSet::new();
        for row in rows {
            assert!(seen.insert(row.name));
            eprintln!("SUPER_PARSER_LAYOUT version={version} type={} size={} align={}", row.name, row.size, row.align);
        }
        let kind = rows.iter().find(|row| row.name == "driver::Kind").unwrap();
        let expr = rows.iter().find(|row| row.name == "code::Expr").unwrap();
        eprintln!("SUPER_PARSER_FORMULAS version={version} frames4={} frames8={} frame_limit={} expr_page={}", 4 * kind.size + 32, 8 * kind.size + 32, MAX_HEAP / kind.size, 128 * expr.size + 32);
    }
    eprintln!("SUPER_PARSER_CONFIG rust_host={} vulkan_raster={}", cfg!(feature = "test262-host"), cfg!(feature = "vulkan-raster"));
    eprintln!("SUPER_PARSER_COUNTS actual={} before={} proposed={}", actual.len(), before.len(), proposed.len());
}
'''
# Cargo's host feature spelling is checked against published Cargo before emission.
cargo=subprocess.check_output(['git','show',BASE+':Cargo.toml'],cwd=W).decode()
assert 'test262-host' in cargo and 'vulkan-raster' in cargo
path=O/'raw/src/script/parser/driver/super_property_layout_probe.rs';write(path,raw)
reg='\n#[cfg(test)]\nmod super_property_layout_probe;\n';write(O/'registration-append.txt',reg)
p='src/script/parser/driver.rs';before=subprocess.check_output(['git','show',BASE+':'+p],cwd=W)
write(O/'before'/p,before.decode());write(O/'registration.diff',''.join(difflib.unified_diff(before.decode().splitlines(True),(before.decode()+reg).splitlines(True),fromfile='a/'+p,tofile='b/'+p)))
put(O/'checks.json',{'base':BASE,'inputs':inputs,'declarations':rows,'actual_comparisons':len(actual),'complete_graph':True,'unchanged_leaves':'Actual Value, JsString, RegExp, tokens::Tokens, regexp::Budget and DeclarationKind; complete code Records and all neighboring continuation variants mirrored. No byte-array substitutes or visibility changes.','private_contexts':'Full functions/classes Context included; their actual containing State and Frame are compared.','project_execution':False})
put(O/'contract.json',{'base':BASE,'test':'script::parser::driver::super_property_layout_probe::super_property_parser_complete_layouts','scope':'Inert complete old/proposed declaration measurements only. Root imports onto published parent, executes configs, and removes probe before producer import. No numeric ABI assertion.','changes':['Expr::SuperProperty(ExprId)','Parser, functions::Context and EntryContext: two permission flags','functions::Frame::ObjectMethod','expressions::Frame::SuperPropertyKey(bool)'],'registration':'Append registration-append.txt to published driver.rs; do not overwrite later root imports.','existing_limits':'Unchanged sizeof-based record page and continuation formulas, printed from complete mirror sizes.','production':'No implementation methods or script/parser execution in probe.'})
files=[dict(bind(f),path=str(f.relative_to(O))) for f in sorted(O.rglob('*')) if f.is_file() and f.name!='source-ready.json']
put(O/'source-ready.json',{'status':'sealed_source_only_inert_probe','base':BASE,'raw':bind(path),'registration':bind(O/'registration-append.txt'),'contract':bind(O/'contract.json'),'checks':bind(O/'checks.json'),'files':files,'project_execution':False})
print(json.dumps(bind(O/'source-ready.json')))
