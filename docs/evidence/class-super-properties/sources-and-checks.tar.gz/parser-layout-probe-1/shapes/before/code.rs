#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct ExprId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct StmtId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct FunctionId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) struct ClassId(usize);

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ClassKind {
    ExplicitBase,
    ExplicitDerived,
    DefaultBase,
    DefaultDerived,
}

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(super) enum ClassElementKind {
    Method,
    Getter,
    Setter,
}

#[derive(Debug)]
pub(super) struct Class {
    pub name: Option<String>,
    pub heritage: Option<ExprId>,
    pub constructor: FunctionId,
    pub elements: Vec<ClassElement>,
}

#[derive(Debug)]
pub(super) struct ClassElement {
    pub name: PropertyName,
    pub function: FunctionId,
    pub kind: ClassElementKind,
    pub is_static: bool,
}

#[derive(Debug)]
pub(super) struct Parameter {
    pub name: String,
    pub initializer: Option<ExprId>,
    pub rest: bool,
}

#[derive(Debug)]
pub(super) struct Function {
    pub params: Vec<Parameter>,
    pub body: Vec<StmtId>,
    pub name: Option<String>,
    pub arrow: bool,
    pub self_name: bool,
    pub constructable: bool,
    pub strict: bool,
    pub class_kind: Option<ClassKind>,
}

#[derive(Debug)]
pub(super) struct Unit {
    expressions: Records<Expr>,
    statements: Records<Stmt>,
    functions: Records<Function>,
    pub body: Vec<StmtId>,
    pub strict: bool,
    pub compiled_storage: usize,
    classes: Records<Class>,
}

#[derive(Clone, Debug)]
pub(super) struct FunctionRef {
    pub unit: Rc<Unit>,
    id: FunctionId,
}

#[derive(Debug)]
pub(super) enum Expr {
    Literal(Value),
    RegExp(Rc<RegExp>),
    Ident(String),
    NewTarget,
    Array(Vec<Option<ExprId>>),
    Object(Vec<(PropertyName, ObjectEntry)>),
    Unary(String, ExprId),
    BinaryChain(ExprId, Vec<(String, ExprId)>),
    Conditional(ExprId, ExprId, ExprId),
    Assign(String, ExprId, ExprId),
    Update(ExprId, f64, bool),
    Member(ExprId, ExprId),
    Call(ExprId, Vec<ExprId>),
    New(ExprId, Vec<ExprId>),
    CallSpread(ExprId, Vec<ExprId>),
    NewSpread(ExprId, Vec<ExprId>),
    SpreadArgument(ExprId),
    Function(FunctionId),
    Sequence(Vec<ExprId>),
    Template(JsString, Vec<(ExprId, JsString)>),
    Class(ClassId),
    SuperCall(Vec<ExprId>),
    SuperCallSpread(Vec<ExprId>),
}

#[derive(Debug)]
pub(super) enum PropertyName {
    Literal(JsString),
    Computed(ExprId),
}

#[derive(Debug)]
pub(super) enum ObjectEntry {
    Data(ExprId),
    Method(FunctionId),
    Accessor(FunctionId, bool),
    Prototype(ExprId),
}

#[derive(Debug)]
pub(super) enum Stmt {
    Empty,
    Label(usize, StmtId),
    Expr(ExprId),
    Var(Vec<(String, Option<ExprId>)>, DeclarationKind),
    Block(Vec<StmtId>),
    If(ExprId, StmtId, Option<StmtId>),
    While(ExprId, StmtId),
    DoWhile(ExprId, StmtId),
    For(Option<StmtId>, Option<ExprId>, Option<ExprId>, StmtId),
    ForIn(ForBinding, ExprId, StmtId),
    ForOf(ForBinding, ExprId, StmtId),
    Switch(ExprId, Vec<(Option<ExprId>, Vec<StmtId>)>),
    Function(String, FunctionId),
    Return(Option<ExprId>),
    Throw(ExprId),
    Try(StmtId, Option<CatchClause>, Option<StmtId>),
    Break(Option<usize>),
    Continue(Option<usize>),
    Class(ClassId),
}

#[derive(Debug)]
pub(super) enum ForBinding {
    Declaration(String, DeclarationKind),
    Target(ExprId),
}

#[derive(Debug)]
pub(super) struct CatchClause {
    pub binding: Option<String>,
    pub body: Vec<StmtId>,
}
