#[derive(Debug)]
pub(super) struct Records<T> {
    pages: Vec<Vec<T>>,
    length: usize,
}
