pub(super) enum Frame {
    Start { declaration: bool },
    Heritage(State),
    Elements(State),
    Key(State, Header),
    Member(State, PropertyName, Header),
}

pub(super) struct State {
    name: Option<String>,
    heritage: Option<ExprId>,
    constructor: Option<FunctionId>,
    elements: Vec<code::ClassElement>,
    saved: Context,
}

pub(super) struct Header {
    kind: code::ClassElementKind,
    is_static: bool,
    is_constructor: bool,
}

struct Context {
    strict: bool,
    allow_in: bool,
    in_class: bool,
}
