pub(super) enum Frame {
    Assignment,
    AssignmentHead,
    ConditionalYes(ExprId, bool),
    ConditionalNo(ExprId, ExprId),
    AssignmentRight(String, ExprId),
    Sequence,
    SequenceHead,
    SequenceNext(Vec<ExprId>),
    Binary(u8),
    BinaryHead(u8),
    BinaryRight(Binary, &'static str),
    Unary,
    Prefix(&'static str),
    PrefixUpdate(f64),
    Base(bool),
    PostfixResume(Postfix),
    Computed(Postfix, bool),
    // Argument flags are (any spread, current operand is spread, saved allow_in).
    Arguments(Postfix, Vec<ExprId>, bool, bool, bool),
    New,
    NewHead,
    NewComputed(NewState, bool),
    NewArguments(ExprId, Vec<ExprId>, bool, bool, bool),
    Primary,
    CoverItem(Cover, bool),
    ArrayItem(Array),
    ObjectKey(Object, bool, bool),
    AccessorKey(Object, bool),
    ObjectFunction(Object, PropertyName, Option<bool>),
    ObjectValue(Object, PropertyName, bool),
    NamedFunction(Option<String>),
    Key,
    ComputedKey(bool),
    TemplatePart(JsString, Vec<(ExprId, JsString)>, bool),
    Pass,
    LeftHandSide,
    LeftHandSideBase(bool),
    ClassDone,
    // Flags: any spread, current spread, saved allow_in, permit postfix update.
    SuperArguments(Vec<ExprId>, bool, bool, bool, bool),
}

pub(super) struct Binary {
    left: ExprId,
    operations: Vec<(String, ExprId)>,
    min: u8,
    chain: usize,
}

pub(super) struct Postfix {
    value: ExprId,
    chain: usize,
    async_call: bool,
    allow_update: bool,
}

pub(super) struct NewState {
    value: ExprId,
}

pub(super) struct Cover {
    items: Vec<(ExprId, bool)>,
    saved_in: bool,
}

pub(super) struct Array {
    items: Vec<Option<ExprId>>,
    saved_in: bool,
}

pub(super) struct Object {
    items: Vec<(code::PropertyName, ObjectEntry)>,
    saved_in: bool,
    prototype: bool,
}
