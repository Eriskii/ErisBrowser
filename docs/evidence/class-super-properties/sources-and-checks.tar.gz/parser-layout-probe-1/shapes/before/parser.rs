enum PropertyName {
    Literal(JsString, bool),
    Computed(ExprId),
}

struct ActiveLabel {
    name: String,
    target: usize,
    iteration: bool,
}

pub(super) struct Parser<'source> {
    tokens: tokens::Tokens,
    source: &'source str,
    lex_work: usize,
    compile_budget: regexp::Budget,
    unit: code::Unit,
    pos: usize,
    function_depth: usize,
    new_target_allowed: bool,
    loop_depth: usize,
    switch_depth: usize,
    labels: Vec<ActiveLabel>,
    next_label: usize,
    allow_in: bool,
    strict: bool,
    super_call_allowed: bool,
    in_class: bool,
}
