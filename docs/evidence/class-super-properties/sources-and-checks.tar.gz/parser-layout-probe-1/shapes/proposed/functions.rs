pub(super) enum Frame {
    Start(bool),
    Dynamic,
    Default(State, String),
    Body(State),
    Arrow(Vec<Parameter>),
    ArrowExpression(State),
    // true only for a derived literal constructor; class methods use false.
    ClassMethod(bool),
    // Object methods have a valid super grammar but no selected runtime home object.
    ObjectMethod,
}

pub(super) struct State {
    params: Vec<Parameter>,
    saved: Context,
    unique: bool,
    arrow: bool,
    dynamic: bool,
}

struct Context {
    loop_depth: usize,
    switch_depth: usize,
    allow_in: bool,
    strict: bool,
    labels: Vec<ActiveLabel>,
    new_target_allowed: bool,
    super_call_allowed: bool,
    super_property_allowed: bool,
    super_property_deferred: bool,
}
