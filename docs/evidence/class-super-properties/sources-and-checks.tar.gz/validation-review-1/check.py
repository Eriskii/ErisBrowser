"""Independent read-only receipt/log/source reconciliation; no project imports."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
K=Path('/tmp/eris-super-properties-plan-1');P=K/'validation-review-1';W=K/'worktree'
EXPECTED='1806253b13ebfd8367bf924cfa13728999f379450e1260ad800d233d0c531db3'
def sha(data):return hashlib.sha256(data).hexdigest()
def bind(path):
    path=Path(path);data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def read(path):return json.loads(Path(path).read_bytes())
verified={}
def checked(binding):
    assert bind(binding['path'])==binding,binding['path'];verified[binding['path']]=binding
    return read(binding['path'])
def walk_bindings(value):
    if type(value) is dict:
        if set(value)=={'path','bytes','sha256'} and Path(value['path']).is_absolute():
            assert bind(value['path'])==value,value['path'];verified[value['path']]=value
        for x in value.values():walk_bindings(x)
    elif type(value) is list:
        for x in value:walk_bindings(x)
ledger_binding=bind(K/'root/final-validation.json');assert ledger_binding['sha256']==EXPECTED
ledger=read(ledger_binding['path']);assert ledger['status']=='pass';walk_bindings(ledger)
summary_re=re.compile(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',re.M)
attempts=[]
for attempt in ledger['attempts']:
    receipt=checked(attempt['receipt']);log=Path(attempt['log']['path']).read_text()
    assert receipt['command']==attempt['command'] and receipt['exit']==attempt['exit']
    assert receipt['elapsed_seconds']==attempt['elapsed_seconds'] and receipt['elapsed_seconds']>=0
    assert receipt['log']==Path(attempt['log']['path']).name and receipt['sha256']==attempt['log']['sha256']
    summaries=[tuple(map(int,m)) for m in summary_re.findall(log)]
    totals={'suites':len(summaries),'passed':sum(x[0] for x in summaries),'failed':sum(x[1] for x in summaries),'ignored':sum(x[2] for x in summaries)}
    if 'tests' in attempt:assert totals==attempt['tests'],attempt['label']
    else:assert not summaries,attempt['label']
    assert attempt['accepted']==(attempt['label'] in ledger['accepted_labels'])
    if attempt['accepted']:assert receipt['exit']==0
    if 'environment' in attempt:
        env=checked(attempt['environment']);command=attempt['command']
        assert command[0]=='cargo' and command[1]=='+'+env['toolchain']
        assert 'release: '+env['toolchain']+'\n' in env['rustc']
        features=command[command.index('--features'):command.index('--features')+2] if '--features' in command else []
        assert features==env['features']
    attempts.append({'label':attempt['label'],'exit':receipt['exit'],'accepted':attempt['accepted'],'tests':totals if summaries else None})
assert len(attempts)==36 and len(ledger['accepted_labels'])==11
# Current final inputs and every frozen final snapshot retain their receipt bytes.
inventory=checked(ledger['source_inventory']);imap={x['path']:x for x in inventory['files']}
assert len(imap)==len(inventory['files'])==ledger['selected_inputs']==15289
assert inventory['base']==ledger['base']
for row in inventory['files']:assert dict(bind(W/row['path']),path=row['path'])==row,row['path']
snapshots=checked(ledger['source_snapshots']);assert len(snapshots['files'])==ledger['changed_source_paths']==28
for row in snapshots['files']:
    assert dict(bind(K/'candidate-source-2'/row['path']),path=row['path'])==row==imap[row['path']]
# Complete raw test IDs, including the parent's ignored rows, without trusting a root parser.
def roster(path):
    text=Path(path).read_text();suite=None;rows={}
    for line in text.splitlines():
        match=re.match(r'^\s*Running (.+?) \(',line)
        if match:suite=match.group(1);continue
        match=re.match(r'^test (.+?) \.\.\. (ok|FAILED|ignored)(?:,.*)?$',line)
        if match:
            key=(suite,match.group(1));assert key not in rows,key;rows[key]=match.group(2)
    return rows
default=roster(K/'validation/candidate-full-msrv-2.log');host=roster(K/'validation/candidate-full-host-vulkan-1.log')
parent=roster(K/'validation/parent-full-msrv-2.log')
assert len(default)==3432 and set(default.values())=={'ok'}
assert len(host)==3796 and set(host.values())=={'ok'}
assert len(parent)==3344 and Counter(parent.values())=={'ok':3218,'ignored':126}
old_name='script::machine::call_spread_phase_tests::actual_call_spread_machine_layout_matches_both_held_mirrors'
new_name='script::machine::call_spread_phase_tests::actual_call_spread_machine_layout_after_super_property_extension'
parent_keys={(s,new_name if n==old_name else n) for s,n in parent}
new_tests=set();source_roster=[]
modules=[('src/script/super_property_semantics_tests.rs','script::super_property_semantics_tests::'),('src/script/super_property_abort_tests.rs','script::super_property_abort_tests::'),('src/script/parser/super_property_tests.rs','script::parser::super_property_tests::'),('src/script/super_properties/tests.rs','script::super_properties::tests::'),('src/script/class_super_properties/tests.rs','script::class_super_properties::tests::')]
for name,prefix in modules:
    text=(K/'candidate-source-2'/name).read_text();names=re.findall(r'#\[test\]\s*fn (\w+)\(',text)
    for n in names:new_tests.add(('unittests src/lib.rs',prefix+n))
    source_roster.append({'path':name,'groups':len(names)})
for name,suite,prefix in [('tests/class_super_properties.rs','tests/class_super_properties.rs',''),('tests/worker/class_super_properties.rs','tests/worker.rs','class_super_properties::')]:
    names=re.findall(r'#\[test\]\s*(?:#\[[^\n]+\]\s*)*fn (\w+)\(',(K/'candidate-source-2'/name).read_text())
    for n in names:new_tests.add((suite,prefix+n))
    source_roster.append({'path':name,'groups':len(names)})
assert len(new_tests)==88 and set(default)==parent_keys|new_tests and not parent_keys&new_tests
assert new_tests<=set(host)
# The published predecessor runtime/tests did not change between G and H.
G=Path('/tmp/eris-vulkan-line-accounting-plan-1')
git_delta=subprocess.check_output(['git','diff','--name-only','315300e6324fd4232fa53cb8d6a5b46a2c906dc5',ledger['base'],'--','src','crates','assets','shaders','Cargo.toml','Cargo.lock','build.rs',':(glob)tests/**/*.rs',':(glob)tests/*.rs'],cwd=W)
assert not git_delta
gledger=read(G/'root/final-validation.json');glog=G/'validation/host-vulkan-full-2.log'
host_parent=roster(glog);assert len(host_parent)==3708 and set(host_parent.values())=={'ok'}
host_keys={(s,new_name if n==old_name else n) for s,n in host_parent}
assert set(host)==host_keys|new_tests and not host_keys&new_tests
# Independently parse actual complete layouts from each raw observation log.
layouts=checked(ledger['layouts']);layout_rows=[]
for measurement in layouts['measurements']:
    path=K/'validation'/(measurement['label']+'.log');log=path.read_text();receipt=read(K/'validation'/(measurement['label']+'.json'))
    assert bind(path)['sha256']==measurement['log_sha256'] and receipt['sha256']==measurement['log_sha256']
    runtime={name:[int(size),int(alignment)] for name,size,alignment in re.findall(r'SUPER_LAYOUT (\S+) (\d+) (\d+)',log)}
    parser={}
    for version,name,size,alignment in re.findall(r'SUPER_PARSER_LAYOUT version=(\S+) type=(\S+) size=(\d+) align=(\d+)',log):
        assert name not in parser.setdefault(version,{})
        parser[version][name]=[int(size),int(alignment)]
    assert runtime==measurement['runtime'] and parser==measurement['parser']
    for name,size in [('Function.actual',120),('Reference.actual',80),('Phase.actual',112),('ExprFrame.actual',144),('Frame.actual',184),('Output.actual',80),('Environment.actual',112)]:assert runtime[name]==[size,8]
    layout_rows.append({'label':measurement['label'],'runtime_rows':len(runtime),'parser_rows':{k:len(v) for k,v in parser.items()},'log':bind(path)})
# Canonical final release paths, exact commands, environment and source joins.
selection=checked(ledger['binary_selection']);assert selection['source_inventory']==ledger['source_inventory']
binaries={}
for kind,sidecar in selection['binaries'].items():
    record=checked(sidecar);assert record['source_inventory']==ledger['source_inventory']
    env=checked(record['environment']);build=checked(record['build'])
    binary=dict(path=record['binary'],bytes=record['bytes'],sha256=record['sha256']);assert bind(binary['path'])==binary
    assert record['binary']==str(Path(env['target_dir'])/'release/eris-js') and not Path(record['binary']).is_symlink()
    version='1.88.0' if kind=='ordinary' else '1.99.0';features=[] if kind=='ordinary' else ['test262-host']
    command=['cargo','+'+version,'build','--locked','--offline']+([] if not features else ['--features','test262-host'])+['--release','--bin','eris-js']
    assert build['command']==command and build['exit']==0 and record['toolchain']==env['toolchain']==version and record['features']==features
    assert env['config']==('msrv' if kind=='ordinary' else 'host')
    assert bind(Path(record['build']['path']).parent/build['log'])['sha256']==build['sha256']
    binaries[kind]={'sidecar':sidecar,'binary':binary,'build':record['build'],'environment':record['environment']}
# All complete arrays, policies and graph identities, independently of recipe flags.
replay=checked(ledger['profiles'][0]);recheck=checked(ledger['profiles'][1]);assert replay==recheck and replay['status']=='pass'
assert replay['source_inventory']==ledger['source_inventory'] and replay['selection']==ledger['binary_selection']
contract=checked(replay['contract']);assert bind(replay['runner']['path'])==replay['runner']
contract_profiles={x['profile']:x for x in contract['profiles']};counts=Counter();profile_rows=[];edges=0;cross_mode=0
def canonical(value):return json.dumps(value,sort_keys=True,separators=(',',':')).encode()
for row in replay['profiles']:
    assert not row['errors'];profile=contract_profiles[row['profile']]
    before=checked(row['before']);report=checked(row['report']);receipt=checked(row['receipt']);assert bind(row['log']['path'])==row['log']
    assert receipt['sha256']==row['log']['sha256']
    assert row['before']==profile['reference_report']
    for field in before.keys()-{'binary','binary_sha256','seconds'}:assert canonical(before[field])==canonical(report[field]),(row['profile'],field)
    assert report['runner_policy']==profile['policy'] and report['runner_policy_sha256']==profile['policy_sha256']==sha(json.dumps(report['runner_policy'],sort_keys=True).encode())
    binary=binaries[profile['binary_kind']]['binary'];assert (report['binary'],report['binary_sha256'])==(binary['path'],binary['sha256'])
    assert report['harness_preflight_passed'] is True
    cases=report['cases'];controls=report['harness_preflight'];assert len(cases)==profile['cases'] and len(controls)==profile['controls']
    current=Counter(case['status'] for case in cases);assert dict(current)==report['counts'];counts+=current
    assert set(current)<={'passed','failed','unsupported'}
    for case in cases:
        observation=case.get('observation')
        if observation is not None:
            assert observation['status'] not in ('resource','harness-error')
            if profile['binary_kind']=='host':
                assert type(observation['completion']['policy']) is int
                assert observation['completion']['policy']==contract['case_completion_policies'][profile['profile']][case['id']]
    by={(x['name'],x['result']['mode']):x for x in controls};assert len(by)==len(controls)
    graph={key:[] for key in by};profile_edges=0
    for key,control in by.items():
        assert control['verified'] is True
        for ref in control['prerequisites']:
            target=(ref['name'],ref['mode']);other=by[target];assert other['verified'] is True
            assert ref['case_sha256']==other['result']['case_sha256'] and ref['source_sha256']==other['result']['source_sha256']
            if 'id' in ref:assert ref['id']==other['result']['id'] and ref['expected']==other['expected']
            if 'verified' in ref:assert ref['verified'] is True
            graph[key].append(target);profile_edges+=1;cross_mode+=key[1]!=target[1]
    active=set();visited=set()
    def visit(key):
        assert key not in active
        if key in visited:return
        active.add(key)
        for target in graph[key]:visit(target)
        active.remove(key);visited.add(key)
    for key in by:visit(key)
    expected_exit=0 if current.get('passed')==len(cases) else 1
    assert receipt['exit']==row['observed_exit']==expected_exit
    command=receipt['command'];assert command[1:3]==['-B','tools/test262_conformance.py']
    assert command[3:]==['--binary',binary['path'],'--profile',profile['profile'],'--output',row['report']['path'],'--jobs','1','--timeout','3.0']
    assert not any('baseline' in arg for arg in command)
    edges+=profile_edges
    profile_rows.append({'profile':row['profile'],'cases':len(cases),'controls':len(controls),'counts':dict(current),'exit':expected_exit,'case_array_sha256':sha(canonical(cases)),'control_array_sha256':sha(canonical(controls)),'full_arrays_equal_predecessor':True,'ordered_edges':profile_edges,'report':row['report']})
assert len(profile_rows)==8 and sum(x['cases'] for x in profile_rows)==1330 and sum(x['controls'] for x in profile_rows)==724
assert counts==ledger['profile_counts']==replay['counts']=={'passed':1258,'failed':64,'unsupported':8}
assert all(v==0 for v in ledger['profile_transition_counts'].values()) and ledger['profile_transition_counts']==replay['transition_counts']
assert edges==7758 and cross_mode==512
result={'status':'all independent reconciliations passed','final_ledger':ledger_binding,'verified_bindings':len(verified),'attempts':attempts,'source_inputs':len(imap),'changed_paths':len(snapshots['files']),'source_roster_additions':source_roster,'rosters':{'default':len(default),'host_vulkan':len(host),'new_tests':len(new_tests),'parent_default_passed':3218,'parent_default_ignored':126,'parent_host':len(host_parent),'selected_rename':{'before':old_name,'after':new_name},'all_old_ids_plus_88_exact':True,'host_parent_log':bind(glog),'host_parent_final_ledger':bind(G/'root/final-validation.json'),'published_G_to_H_runtime_test_diff_empty':True},'layouts':layout_rows,'binaries':binaries,'profiles':profile_rows,'profile_counts':dict(counts),'controls':724,'edges':edges,'cross_mode_edges_preserved':cross_mode,'zero_case_control_or_policy_changes':True,'no_baseline_writes':True,'project_execution':False,'live_edits':False}
(P/'checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(bind(P/'checks.json')))
