"""Read-only source composition/lexical audit; no Rust or project execution."""
from pathlib import Path
from collections import Counter
import difflib, hashlib, json, re, subprocess
K=Path('/tmp/eris-super-properties-plan-1');P=K/'final-source-review-1';W=K/'worktree'
BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(data):return hashlib.sha256(data).hexdigest()
def bind(path):
    data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def read(path):return json.loads(path.read_bytes())
def put(name,value):(P/name).write_text(json.dumps(value,indent=2)+'\n')
def verify(path,row):
    data=path.read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],path
    return data
def git(path):return subprocess.check_output(['git','show',BASE+':'+path],cwd=W)
def tokens(text):
    """Small lexical comparison, not a Rust parser. Comments/literals stay atomic."""
    out=[];i=0
    raw_re=re.compile(r'(?:br|cr|r)(#*)"')
    char_re=re.compile(r"(?:b)?'(?:[^'\\\n]|\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.))'")
    while i<len(text):
        start=i;c=text[i]
        if c.isspace():i+=1;continue
        if text.startswith('//',i):
            n=text.find('\n',i);i=len(text) if n<0 else n
        elif text.startswith('/*',i):
            i+=2;depth=1
            while depth:
                assert i<len(text)
                if text.startswith('/*',i):depth+=1;i+=2
                elif text.startswith('*/',i):depth-=1;i+=2
                else:i+=1
        else:
            raw=raw_re.match(text,i)
            char=char_re.match(text,i)
            if raw:
                close='"'+raw.group(1);end=text.find(close,raw.end());assert end>=0
                i=end+len(close)
            elif char:i=char.end()
            elif c=='"' or text.startswith('b"',i) or text.startswith('c"',i):
                i+=1 if c=='"' else 2
                while True:
                    assert i<len(text)
                    if text[i]=='\\':i+=2
                    elif text[i]=='"':i+=1;break
                    else:i+=1
            elif c.isalnum() or c=='_':
                i+=1
                while i<len(text) and (text[i].isalnum() or text[i]=='_'):i+=1
            else:i+=1
        out.append((text[start:i],start,i))
    return out
def test_bodies(text):
    ts=tokens(text);out={};i=0
    while i<len(ts)-4:
        if [x[0] for x in ts[i:i+4]]==['#','[','test',']']:
            j=i+4
            while ts[j][0]!='fn':j+=1
            name=ts[j+1][0];start=ts[j][1]
            while ts[j][0]!='{':j+=1
            depth=1;j+=1
            while depth:
                if ts[j][0]=='{':depth+=1
                if ts[j][0]=='}':depth-=1
                j+=1
            assert name not in out,name
            out[name]=text[start:ts[j-1][2]];i=j
        else:i+=1
    return out
def expression_arm_blocks(values):
    # Rustfmt can wrap/unwrap a single match-arm expression. Preserve all body
    # tokens; never discard a block containing a top-level statement semicolon.
    values=list(values);changes=[];i=0
    while i<len(values)-3:
        if values[i:i+3]!=['=','>','{']:i+=1;continue
        depth=1;j=i+3;statement=False
        while depth:
            if values[j]=='{':depth+=1
            if values[j]=='}':depth-=1
            if depth==1 and values[j]==';':statement=True
            j+=1
        if statement:i+=1;continue
        body=values[i+3:j-1]
        changes.append({'body':body,'following':values[j:j+3]})
        suffix=[] if j<len(values) and values[j]==',' else [',']
        values[i+2:j]=body+suffix
        i+=2
    return values,changes
inventory=read(K/'source-candidate-1.json');snap=read(K/'root/candidate-snapshots-1.json')
before=read(K/'format-1/before.json');after=read(K/'format-1/after.json')
assert inventory['base']==BASE
assert {x['path'] for x in before}=={x['path'] for x in after}=={x['path'] for x in snap['files']}
imap={x['path']:x for x in inventory['files']};assert len(imap)==len(inventory['files'])
tracked_rows=subprocess.check_output(['git','ls-tree','-rz','--full-tree',BASE],cwd=W).split(b'\0')
tracked={}
for row in tracked_rows:
    if not row:continue
    head,path=row.split(b'\t',1);mode,kind,oid=head.split();assert kind==b'blob'
    tracked[path.decode()]=oid.decode()
changed_paths={x['path'] for x in snap['files']}
requests=[(x['path'],tracked[x['path']]) for x in inventory['files'] if x['path'] not in changed_paths]
batch=subprocess.check_output(['git','cat-file','--batch'],input=''.join(oid+'\n' for _,oid in requests).encode(),cwd=W)
offset=0
for name,oid in requests:
    line_end=batch.index(b'\n',offset);head=batch[offset:line_end].split();assert head[:2]==[oid.encode(),b'blob']
    size=int(head[2]);data=batch[line_end+1:line_end+1+size];offset=line_end+size+2
    assert len(data)==imap[name]['bytes'] and sha(data)==imap[name]['sha256'],name
assert offset==len(batch)
for row in before:verify(K/'format-1/before'/row['path'],row)
for row in after:
    data=verify(K/'format-1/after'/row['path'],row)
    assert data==verify(K/'candidate-source-1'/row['path'],row)
    assert row==imap[row['path']]
assert sorted(after,key=lambda x:x['path'])==sorted(snap['files'],key=lambda x:x['path'])
expected={};origins={};holds=[]
def add(path,data,origin):
    assert path not in expected,path
    expected[path]=data;origins[path]=[origin]
runtime=read(K/'runtime-producer-1/source-ready.json');holds.append(bind(K/'runtime-producer-1/source-ready.json'))
for row in runtime['paths']:
    path=row['path'];data=(K/'runtime-producer-1/raw'/path).read_bytes();assert sha(data)==row['after']
    if row['before'] is not None:assert sha(git(path))==row['before']
    add(path,data,'runtime-producer-1')
for hold,key in [('parser-producer-1','payloads'),('property-producer-1','files')]:
    seal=read(K/hold/'source-ready.json');holds.append(bind(K/hold/'source-ready.json'))
    for row in seal[key]:
        path=row.get('repository_path',row.get('path'));raw=Path(row['raw']['path']);raw=raw if raw.is_absolute() else K/raw
        data=verify(raw,row['raw'])
        if row.get('before') is not None:assert sha(git(path))==row['before']['sha256']
        add(path,data,hold)
historical=read(K/'historical-migration-1/source-ready.json');holds.append(bind(K/'historical-migration-1/source-ready.json'))
assert git(historical['path'])==verify(Path(historical['before']['path']),historical['before'])
add(historical['path'],verify(Path(historical['raw']['path']),historical['raw']),'historical-migration-1')
public=read(K/'public-adapter-1/source-ready.json');holds.append(bind(K/'public-adapter-1/source-ready.json'))
for row in public['files']:add(row['path'],verify(K/'public-adapter-1/raw'/row['path'],row),'public-adapter-1')
expected['src/script.rs']+=(K/'public-adapter-1/registration.txt').read_bytes();origins['src/script.rs'].append('public-adapter-1/registration.txt')
browser=read(K/'browser-controls-2/source-ready.json');holds.append(bind(K/'browser-controls-2/source-ready.json'))
for row in browser['files']:
    if row['before_sha256'] is not None:assert sha(git(row['path']))==row['before_sha256']
    add(row['path'],verify(K/'browser-controls-2/raw'/row['path'],row),'browser-controls-2')
capture=read(K/'capture-controls-2/source-ready.json');holds.append(bind(K/'capture-controls-2/source-ready.json'))
assert verify(Path(capture['before']['path']),capture['before'])==(K/'capture-controls-1/raw'/capture['path']).read_bytes()
assert verify(Path(capture['raw']['path']),capture['raw'])==Path(capture['before']['path']).read_bytes()+Path(capture['append']['path']).read_bytes()
add(capture['path'],Path(capture['raw']['path']).read_bytes(),'capture-controls-2 exact original7 plus append2')
correction=read(K/'base-validation-correction-1/source-ready.json');holds.append(bind(K/'base-validation-correction-1/source-ready.json'))
target=correction['path'];reg=(K/'capture-controls-1/registration.txt').read_bytes()
assert expected[target]+reg==verify(Path(correction['before']['path']),correction['before'])
expected[target]=verify(Path(correction['raw']['path']),correction['raw']);origins[target]+=['capture-controls-1/registration.txt','base-validation-correction-1']
assert set(expected)=={x['path'] for x in before}
for path,data in expected.items():assert data==(K/'format-1/before'/path).read_bytes(),path
format_rows=[];punctuation=[]
for row in before:
    path=row['path'];a=(K/'format-1/before'/path).read_text();b=(K/'format-1/after'/path).read_text()
    if a==b:format_rows.append({'path':path,'bytes_exact':True});continue
    (P/(path.replace('/','__')+'.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+path,tofile='after/'+path)))
    # Explicit rustfmt module ordering; item attributes and paths travel together.
    if path=='src/script.rs':
        a=a.replace('mod classes;\nmod class_super_properties;\nmod super_properties;','mod class_super_properties;\nmod classes;')
        a=a.replace('mod string_builtins;\n','mod string_builtins;\nmod super_properties;\n')
        a=a.replace('#[cfg(test)]\nmod super_property_semantics_tests;\n#[cfg(test)]\nmod super_property_abort_tests;','#[cfg(test)]\nmod super_property_abort_tests;\n#[cfg(test)]\nmod super_property_semantics_tests;')
    if path=='tests/worker.rs':
        a=a.replace('#[path = "worker/classes.rs"]\nmod classes;\n#[path = "worker/class_super_properties.rs"]\nmod class_super_properties;', '#[path = "worker/class_super_properties.rs"]\nmod class_super_properties;\n#[path = "worker/classes.rs"]\nmod classes;')
    if path=='src/script/class_super_properties.rs':
        a=a.replace('Value::Array(id) => *id < self.arrays.len()\n                && self.array_properties.get(*id).is_some_and(|bag| *bag < self.objects.len()),', 'Value::Array(id) => { *id < self.arrays.len()\n                && self.array_properties.get(*id).is_some_and(|bag| *bag < self.objects.len()) }')
    if path=='src/script/machine.rs':
        a=a.replace('code::Expr::SuperProperty(key) => {\n                super_property_start(runtime, frame, *key)\n            }', 'code::Expr::SuperProperty(key) => super_property_start(runtime, frame, *key),')
    ta=tokens(a);tb=tokens(b)
    va,arms_a=expression_arm_blocks([x[0] for x in ta]);vb,arms_b=expression_arm_blocks([x[0] for x in tb])
    diffs=[];i=0;k=0
    while i<len(va) or k<len(vb):
        if i<len(va) and k<len(vb) and va[i]==vb[k]:i+=1;k+=1;continue
        if k+1<len(vb) and i<len(va) and vb[k]==',' and vb[k+1]==va[i] and va[i] in (')',']','}'):
            j=i;l=k+1;tag='insert'
        elif i+1<len(va) and k<len(vb) and va[i]==',' and va[i+1]==vb[k] and vb[k] in (')',']','}'):
            j=i+1;l=k;tag='delete'
        else:
            raise AssertionError(('unclassified lexical change',path,va[max(0,i-10):i+10],vb[max(0,k-10):k+10]))
        diffs.append({'kind':tag,'before':va[max(0,i-7):min(len(va),j+7)],'after':vb[max(0,k-7):min(len(vb),l+7)],'removed':va[i:j],'added':vb[k:l]})
        i=j;k=l
    punctuation.extend({'path':path,**x} for x in diffs)
    # Every remaining lexical change will be reviewed explicitly, not erased by normalization.
    format_rows.append({'path':path,'bytes_exact':False,'lexical_changes':diffs,'expression_arm_wrappers_before':arms_a,'expression_arm_wrappers_after':arms_b,'raw_literals_exact':[x[0] for x in ta if re.match(r'(?:br|cr|r)#*"',x[0])]==[x[0] for x in tb if re.match(r'(?:br|cr|r)#*"',x[0])]})
put('format-checks.json',{'rows':format_rows,'non_whitespace_non_module_changes':punctuation})
oracle=read(K/'public-controls-1/complete-cases.json');literal_rows=[]
for case in oracle['rows']:
    path='src/script/super_property_'+('abort_tests.rs' if case['family'] in ('resource-terminal','unsupported-terminal') else 'semantics_tests.rs')
    body=test_bodies((K/'candidate-source-1'/path).read_text())[case['proposed_test_name']]
    values=re.findall(r'r####"([\s\S]*?)"####',body)
    if case['family']=='semantic':
        expected_values=[case['id'],case['source'],case['readback'],case['expected']['sloppy'],case['expected']['strict']];helper='observe'
    elif case['family']=='early-error':
        expected_values=[case['id'],case['setup'],case['source'],case['readback']];helper='early_error'
    elif case['family']=='unsupported':
        expected_values=[case['id'],case['source']];helper='deferred'
    else:
        expected_values=[case['id'],case['source'],case['expected_retained']['trace']];helper='fatal'
    assert values==expected_values,(case['id'],'raw argument order')
    assert re.search(r'\{\s*'+helper+r'\(',body),(case['id'],'helper route')
    fields=[]
    for field in ('source','setup','readback'):
        if case.get(field) is not None:
            assert case[field] in values,(case['id'],field)
            assert Path(case[field+'_binding']['path']).read_bytes()==case[field].encode()
            fields.append({'field':field,'sha256':sha(case[field].encode())})
    literal_rows.append({'id':case['id'],'test':case['proposed_test_name'],'path':path,'fields':fields})
assert sum(len(x['fields']) for x in literal_rows)==122
proposal=(K/'public-controls-1/adapter-proposal.rs').read_text()
execute=proposal[proposal.index('fn execute_mode'):proposal.index('\nfn observe')]
helper_prefixes={'semantics':proposal[proposal.index('fn execute_mode'):proposal.index('\nfn retained')], 'abort':execute+'\n'+proposal[proposal.index('fn retained'):]}
for family,prefix in helper_prefixes.items():
    raw=(K/'public-adapter-1/raw/src/script'/('super_property_'+family+'_tests.rs')).read_text()
    assert raw[:raw.index('\n#[test]')]=='//! Independent public SuperProperty literals, frozen before implementation.\nuse super::*;\n\n'+prefix
test_rows=[]
for path in expected:
    if path not in tracked:continue
    old=git(path).decode()
    new=(K/'candidate-source-1'/path).read_text();oldtests=test_bodies(old);newtests=test_bodies(new)
    for name,body in oldtests.items():
        assert name in newtests,(path,name)
        classification='exact'
        if body!=newtests[name]:
            if name in historical['names'] and path==historical['path']:
                classification='documented semantic migration'
            elif body.replace('active_constructor','active_function')==newtests[name]:
                classification='active_function identifier rename only'
            else:raise AssertionError(('unexpected historical test change',path,name))
        test_rows.append({'path':path,'test':name,'body_sha256_before':sha(body.encode()),'body_sha256_after':sha(newtests[name].encode()),'classification':classification})
put('composition-checks.json',{'holds':holds,'all_26_preformat_files_exactly_reconstructed':True,'origins':origins,'candidate_inventory':bind(K/'source-candidate-1.json'),'candidate_snapshots':bind(K/'root/candidate-snapshots-1.json'),'format_before':bind(K/'format-1/before.json'),'format_after':bind(K/'format-1/after.json'),'selected_inputs_verified':len(imap),'literal_fields':122,'literal_records':literal_rows,'old_test_bodies_in_changed_files':test_rows,'old_test_body_classifications':dict(Counter(x['classification'] for x in test_rows)),'project_execution':False,'live_edits':False})
print(json.dumps({'composition':bind(P/'composition-checks.json'),'format':bind(P/'format-checks.json'),'lexical_deltas':len(punctuation),'historical_tests':len(test_rows)}))
