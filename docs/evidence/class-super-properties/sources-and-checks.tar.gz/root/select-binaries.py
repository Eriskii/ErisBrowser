from pathlib import Path
import hashlib, json, sys

K = Path(__file__).resolve().parents[1]
attempt = sys.argv[1]

def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

inventory = bound(K / ('source-candidate-' + attempt + '.json'))
sources = json.loads(Path(inventory['path']).read_bytes())
for item in sources['files']:
    assert dict(bound(K / 'worktree' / item['path']), path=item['path']) == item
selected = dict(source_inventory=inventory, binaries={})
for kind, target, toolchain, features in [
    ('ordinary', 'target-msrv', '1.88.0', []),
    ('host', 'target-1990', '1.99.0', ['test262-host']),
]:
    label = 'candidate-release-' + kind + '-' + attempt
    build = bound(K / 'validation' / (label + '.json'))
    environment = bound(K / 'validation' / (label + '-environment.json'))
    assert json.loads(Path(build['path']).read_bytes())['exit'] == 0
    binary = bound(K / target / 'release/eris-js')
    sidecar = dict(binary=binary['path'], bytes=binary['bytes'], sha256=binary['sha256'],
                   source_inventory=inventory, build=build, environment=environment,
                   features=features, toolchain=toolchain)
    path = K / 'root' / ('binary-' + kind + '-' + attempt + '.json')
    with path.open('x') as out:
        json.dump(sidecar, out, indent=2)
        out.write('\n')
    selected['binaries'][kind] = bound(path)
with (K / 'root' / ('profile-selection-' + attempt + '.json')).open('x') as out:
    json.dump(selected, out, indent=2)
    out.write('\n')
print('Selected two release outputs bound to candidate', attempt)
