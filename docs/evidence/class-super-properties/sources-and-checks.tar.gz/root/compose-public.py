from pathlib import Path
import json, hashlib, re

K=Path(__file__).resolve().parents[1]; W=K/'worktree'; H=K/'public-controls-1'; O=K/'public-adapter-1'
O.mkdir(exist_ok=False)
seal=json.loads((H/'source-ready.json').read_bytes())
for r in seal['files']:
    b=Path(r['path']).read_bytes()
    assert len(b)==r['bytes'] and hashlib.sha256(b).hexdigest()==r['sha256']
rows=json.loads((H/'complete-cases.json').read_bytes())['rows']; assert len(rows)==65
proposal=(H/'adapter-proposal.rs').read_text()
execute=proposal[proposal.index('fn execute_mode'):proposal.index('\nfn observe')]
semantics=proposal[proposal.index('fn execute_mode'):proposal.index('\nfn retained')]
abort=execute+'\n'+proposal[proposal.index('fn retained'):]
out={'super_property_semantics_tests':semantics, 'super_property_abort_tests':abort}
literals=[]
def raw(s):
    assert '"####' not in s
    return 'r####"'+s+'"####'
for r in rows:
    name=r['proposed_test_name']; assert re.fullmatch(r'[a-z0-9_]+',name)
    for field in ['source','setup','readback']:
        if r.get(field) is not None:
            binding=r[field+'_binding']; b=r[field].encode()
            assert b==Path(binding['path']).read_bytes()
            literals.append(dict(id=r['id'],field=field,sha256=hashlib.sha256(b).hexdigest()))
    family=r['family']; args=[raw(r['id'])]
    if family=='semantic':
        helper='observe'; module='super_property_semantics_tests'
        args += [raw(r['source']),raw(r['readback']),raw(r['expected']['sloppy']),raw(r['expected']['strict'])]
    elif family=='early-error':
        helper='early_error'; module='super_property_semantics_tests'
        assert r['expected']==dict(sloppy=0,strict=0)
        args += [raw(r['setup']),raw(r['source']),raw(r['readback'])]
    elif family=='unsupported':
        helper='deferred'; module='super_property_semantics_tests';args += [raw(r['source'])]
    else:
        assert family in ['resource-terminal','unsupported-terminal']
        helper='fatal'; module='super_property_abort_tests'
        args += [raw(r['source']),raw(r['expected_retained']['trace']),str(family=='unsupported-terminal').lower()]
    out[module] += '\n#[test]\nfn '+name+'() {\n    '+helper+'(\n        '+',\n        '.join(args)+'\n    );\n}\n'
assert len(literals)==122
files=[]
for module,body in out.items():
    path='src/script/'+module+'.rs'; payload='//! Independent public SuperProperty literals, frozen before implementation.\nuse super::*;\n\n'+body
    t=O/'raw'/path;t.parent.mkdir(parents=True,exist_ok=True);t.write_text(payload)
    actual=re.findall(r'r####"([\s\S]*?)"####',payload)
    for r in rows:
        if r['proposed_test_name']+'()' not in payload: continue
        for field in ['source','setup','readback']:
            if r.get(field) is not None: assert r[field] in actual
    files.append(dict(path=path,bytes=len(payload.encode()),sha256=hashlib.sha256(payload.encode()).hexdigest(),tests=payload.count('#[test]')))
registration='\n#[cfg(test)]\nmod super_property_semantics_tests;\n#[cfg(test)]\nmod super_property_abort_tests;\n'
(O/'registration.txt').write_text(registration)
(O/'source-ready.json').write_text(json.dumps(dict(status='exact122JSfieldconversion; no execution',oracle_sha256=hashlib.sha256((H/'complete-cases.json').read_bytes()).hexdigest(),adapter_sha256=hashlib.sha256((H/'adapter-proposal.rs').read_bytes()).hexdigest(),files=files,literals=literals),indent=2)+'\n')
for r in files:
    target=W/r['path'];assert not target.exists();target.write_bytes((O/'raw'/r['path']).read_bytes())
script=W/'src/script.rs'; (O/'registration-before.rs').write_bytes(script.read_bytes());script.write_text(script.read_text()+registration)
print('Imported 65 public groups, with all 122 frozen JS fields exact; no semantic imports.')
