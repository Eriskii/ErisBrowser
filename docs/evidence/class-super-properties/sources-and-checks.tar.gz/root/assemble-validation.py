from pathlib import Path
import hashlib, json, re, subprocess

K = Path(__file__).resolve().parents[1]
W = K / 'worktree'

def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def load(path):
    return json.loads(path.read_bytes())

inventory_path = K / 'source-candidate-2.json'
inventory = load(inventory_path)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == inventory['base']
for row in inventory['files']:
    assert dict(bound(W / row['path']), path=row['path']) == row
snapshots_path = K / 'root/candidate-snapshots-2.json'
snapshots = load(snapshots_path)
assert len(snapshots['files']) == 28
for row in snapshots['files']:
    assert dict(bound(Path(snapshots['root']) / row['path']), path=row['path']) == row
    assert (W / row['path']).read_bytes() == (Path(snapshots['root']) / row['path']).read_bytes()

accepted = [
    'actual-layout-msrv-1', 'actual-layout-host-vulkan-1',
    'candidate-capture-msrv-2', 'candidate-browser-msrv-1',
    'candidate-full-msrv-2', 'candidate-full-host-vulkan-1',
    'candidate-clippy-msrv-2', 'candidate-clippy-host-vulkan-2',
    'fmt-check-final-1', 'candidate-release-ordinary-2', 'candidate-release-host-2',
]
attempts = []
for path in sorted((K / 'validation').glob('*.json')):
    row = load(path)
    if 'command' not in row:
        continue
    log = path.parent / row['log']
    assert bound(log)['sha256'] == row['sha256']
    text = log.read_text()
    suites = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    item = dict(label=path.stem, receipt=bound(path), log=bound(log), command=row['command'],
                exit=row['exit'], elapsed_seconds=row['elapsed_seconds'], accepted=path.stem in accepted)
    if suites:
        item['tests'] = dict(suites=len(suites), passed=sum(int(r[1]) for r in suites),
                             failed=sum(int(r[2]) for r in suites), ignored=sum(int(r[3]) for r in suites))
    environment = path.with_name(path.stem + '-environment.json')
    if environment.exists():
        item['environment'] = bound(environment)
    attempts.append(item)
by_name = {row['label']: row for row in attempts}
assert all(by_name[label]['exit'] == 0 for label in accepted)
for label, count in [('candidate-full-msrv-2', 3432), ('candidate-full-host-vulkan-1', 3796)]:
    assert by_name[label]['tests'] == dict(suites=55, passed=count, failed=0, ignored=0)
    text = Path(by_name[label]['log']['path']).read_text()
    assert 'test super_properties_update_dom_and_pixels_through_native_promise_reactions ... ok' in text
    assert 'test class_super_properties::confined_super_properties_update_dom_and_pixels_through_native_promise_reactions ... ok' in text

profile_paths = [K / 'root/profile-replay-1.json', K / 'root/profile-replay-1-recheck.json']
for path in profile_paths:
    profile = load(path)
    assert profile['status'] == 'pass' and profile['baseline_writes'] is False
    assert profile['source_inventory'] == bound(inventory_path)
    assert profile['expected_cases'] == 1330 and profile['expected_controls'] == 724
    assert len(profile['profiles']) == 8 and all(not row['errors'] for row in profile['profiles'])
    for row in profile['profiles']:
        for field in ['report', 'receipt', 'log']:
            assert bound(Path(row[field]['path'])) == row[field]
    assert profile['transition_counts']['prior_pass_regressions'] == 0
    assert profile['transition_counts']['control_record_changes'] == 0
    assert profile['transition_counts']['infrastructure_cases'] == 0
assert load(profile_paths[0])['profiles'] == load(profile_paths[1])['profiles']
selection_path = K / 'root/profile-selection-2.json'
selection = load(selection_path)
assert selection['source_inventory'] == bound(inventory_path)
for item in selection['binaries'].values():
    assert bound(Path(item['path'])) == item
    sidecar = load(Path(item['path']))
    binary = bound(Path(sidecar['binary']))
    assert (binary['bytes'], binary['sha256']) == (sidecar['bytes'], sidecar['sha256'])
    for name in ['source_inventory', 'build', 'environment']:
        assert bound(Path(sidecar[name]['path'])) == sidecar[name]

reviews = [
    'runtime-review-1/review.json', 'parser-review-1/review.json', 'private-review-1/review.json',
    'public-review-1/review.json', 'browser-review-1/correction-review.json',
    'final-source-review-1/review.json', 'final-source-review-1/candidate2-addendum.json',
    'profile-replay-review-3/review.json',
]
profile = load(profile_paths[0])
record = dict(
    status='pass', checkpoint='class-super-properties', base=inventory['base'],
    source_inventory=bound(inventory_path), source_snapshots=bound(snapshots_path),
    selected_inputs=len(inventory['files']), changed_source_paths=28,
    accepted_labels=accepted, attempts=attempts,
    source_reviews=[bound(K / name) for name in reviews],
    layouts=bound(K / 'root/actual-layout-measurements-1.json'),
    profiles=[bound(path) for path in profile_paths], binary_selection=bound(selection_path),
    profile_counts=profile['counts'], profile_transition_counts=profile['transition_counts'],
    new_coverage=dict(public_groups=65, public_modes=130, exact_js_fields=122,
                      parser_groups=4, receiver_wrapper_groups=8, capture_groups=9,
                      capture_measured_calls=84, browser_groups=2),
    retained_failures=[
        dict(label='parent-full-msrv-1', reason='Sandbox denied six local TCP fixture sockets; unchanged parent passed on authorized rerun.'),
        dict(label='parent-public-1', reason='Frozen new public tests before implementation: 10 passed, 55 failed.'),
        dict(label='parent-browser-1', reason='New fixture retained baseline pixels because parent lacks class SuperProperty support.'),
        dict(label='candidate-capture-msrv-1', reason='Malformed Object arena ID admitted by kind-only check; corrected by bounded base validation.'),
        dict(label='candidate-full-msrv-1', reason='Three old layout/bootstrap expectations required explicit measured migrations; production unchanged.'),
    ],
    unchanged='Runtime limits, published runner/importer/protocol, feature policies, corpora and baseline files.',
    qualification='Selected class SuperProperty slice only. Existing deferred language/host paths remain. Full-suite native-plan assertions run on CPU; no new hardware GPU, whole-browser compatibility, security certification, or Chromium performance claim.',
)
with (K / 'root/final-validation.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
print(json.dumps(bound(K / 'root/final-validation.json')))
