from pathlib import Path
import hashlib, json

K = Path(__file__).resolve().parents[1]

def binding(relative):
    data = (K / relative).read_bytes()
    return dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

inputs = dict(
    source_parent='source-parent.json',
    source_inventory='source-candidate-2.json',
    source_snapshots='root/candidate-snapshots-2.json',
    final_validation='root/final-validation.json',
    validation_review='validation-review-1/review.json',
    documentation_hold='documentation-2/source-ready.json',
    documentation_review='documentation-review-1/review.json',
)
required = [
    'runtime-producer-1/source-ready.json', 'parser-producer-1/source-ready.json',
    'property-producer-1/source-ready.json', 'public-controls-1/source-ready.json',
    'public-adapter-1/source-ready.json', 'capture-controls-1/source-ready.json',
    'capture-controls-2/source-ready.json', 'base-validation-correction-1/source-ready.json',
    'browser-controls-1/source-ready.json', 'browser-controls-2/source-ready.json',
    'historical-migration-1/source-ready.json', 'historical-layout-migration-1/source-ready.json',
    'runtime-review-1/review.json', 'parser-review-1/review.json',
    'private-review-1/review.json', 'public-review-1/review.json',
    'browser-review-1/review.json', 'browser-review-1/correction-review.json',
    'final-source-review-1/review.json', 'final-source-review-1/candidate2-addendum.json',
    'profile-replay-1/source-ready.json', 'profile-replay-2/source-ready.json',
    'profile-replay-3/source-ready.json', 'profile-review-1/review.json',
    'profile-review-1/recipe2-review.json', 'profile-replay-review-3/review.json',
    'root/layout-measurements-1.json', 'root/actual-layout-measurements-1.json',
    'actual-layout-probes-1/imports.json', 'actual-layout-probes-1/removed.json',
    'root/profile-selection-2.json', 'root/profile-replay-1.json',
    'root/profile-replay-1-recheck.json', 'root/binary-ordinary-2.json', 'root/binary-host-2.json',
    'evidence-tools-1/source-ready.json', 'evidence-tools-review-1/review.json',
]
required.extend('validation/' + p.name for p in sorted((K / 'validation').glob('*.json')))
raw = K / 'documentation-2/raw'
documents = sorted(p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file())
assert documents == ['README.md', 'docs/ROADMAP.md', 'docs/class-super-properties.md', 'docs/classes.md']
record = dict(format=1, checkpoint='class-super-properties',
              inputs={name: binding(relative) for name, relative in inputs.items()},
              documents=documents, source_snapshot_root='candidate-source-2',
              required_artifacts=[binding(relative) for relative in sorted(set(required))])
with (K / 'root/evidence-selection-1.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
print('Selected', len(record['required_artifacts']), 'required evidence artifacts and four documents.')
