from pathlib import Path
import hashlib, json, re, subprocess

K = Path(__file__).resolve().parents[1]
W = K / 'worktree'
BASE = 'db02f8c890a459b979378900f113b67460a49121'
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == BASE
assert not subprocess.check_output(['git', 'status', '--porcelain'], cwd=W)
for name in ['validation', 'layout-probe-1', 'root/runtime-before', 'publication']:
    (K / name).mkdir(parents=True, exist_ok=True)

def binding(path):
    b = (W / path).read_bytes()
    return dict(path=path, bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

paths = subprocess.check_output(['git', 'ls-files', '-z', 'src', 'crates', 'Cargo.toml', 'Cargo.lock', 'tools', 'tests/conformance'], cwd=W).decode().split('\0')
rows = [binding(p) for p in sorted(paths) if p and (W / p).is_file()]
(K / 'source-parent.json').write_text(json.dumps(dict(base=BASE, scope='Selected runtime/build/tool/conformance inputs; not complete build graph', files=rows), indent=2)+'\n')
selection = dict(base=BASE, surface='Class SuperProperty reads/calls/assignment/update/delete/new/for-heads, public instance/static methods/accessors/constructors/defaults and their lexical arrows', deferred=['Object-literal method super properties', 'Fields/private elements/static blocks', 'Async/generator methods', 'Optional chaining/tagged templates', 'Proxy/multiple realms'], unchanged=['Runtime limits', 'Runner/importer/protocol/features/baselines'], representations=dict(home='Function.home_object: Option<usize> identifying actual ordinary home storage', activation='Environment.active_constructor renamed active_function, same type', reference='SuperProperty { base: Value, name: Value, receiver: Value, strict: bool }', capture='Phase::SuperReferenceKey { owner: usize, receiver: Value }; this before key evaluation, live home parent after raw key result'), status='Selected implementation; no results claimed')
(K / 'root/selection-1.json').write_text(json.dumps(selection, indent=2)+'\n')

def shape(text, name):
    m = re.search(r'(?m)^(?:pub(?:\([^\n]*?\))? )?(?:struct|enum) '+name+r'\s*\{', text)
    assert m, name
    start=m.start(); end=m.end(); level=1
    while level:
        if text[end]=='{': level+=1
        if text[end]=='}': level-=1
        end+=1
    return text[start:end]

runtime=(W/'src/script.rs').read_text()
machine=(W/'src/script/machine.rs').read_text()
parts=['//! Inert full-shape layout experiment; no execution semantics.\n#![allow(dead_code)]\nuse super::*;\nuse crate::script::{Binding, BoundFunction, ThisBinding};\nuse std::collections::BTreeMap;\n']
f=shape(runtime,'Function').replace('struct Function', 'struct ProposedFunction')
f=f[:-1]+'    home_object: Option<usize>,\n}'
parts.append(f)
e=shape(runtime,'Environment').replace('struct Environment','struct ProposedEnvironment').replace('active_constructor','active_function')
parts.append(e)
r=shape(runtime,'Reference').replace('enum Reference','enum ProposedReference')
r=r[:-1]+'    SuperProperty { base: Value, name: Value, receiver: Value, strict: bool },\n}'
parts.append(r)
p=shape(machine,'Phase').replace('enum Phase','enum ProposedPhase')
p=re.sub(r'\bReference\b','ProposedReference',p)
p=p[:-1]+'    SuperReferenceKey { owner: usize, receiver: Value },\n}'
parts.append(p)
e=shape(machine,'ExprFrame').replace('struct ExprFrame','struct ProposedExprFrame')
e=re.sub(r'\bPhase\b','ProposedPhase',e)
parts.append(e)
f=shape(machine,'Frame').replace('enum Frame','enum ProposedFrame')
f=re.sub(r'\bExprFrame\b','ProposedExprFrame',f)
parts.append(f)
o=shape(machine,'Output').replace('enum Output','enum ProposedOutput')
o=re.sub(r'\bReference\b','ProposedReference',o)
parts.append(o)
types=[('Value','Value'),('BoundFunction','BoundFunction'),('Function.before','crate::script::Function'),('Function.proposed','ProposedFunction'),('Environment.before','crate::script::Environment'),('Environment.proposed','ProposedEnvironment'),('Reference.before','Reference'),('Reference.proposed','ProposedReference'),('Phase.before','Phase'),('Phase.proposed','ProposedPhase'),('ExprFrame.before','ExprFrame'),('ExprFrame.proposed','ProposedExprFrame'),('Frame.before','Frame'),('Frame.proposed','ProposedFrame'),('Output.before','Output'),('Output.proposed','ProposedOutput'),('CodeExpr.before','code::Expr')]
parts.append('#[test]\nfn super_property_layout_probe() {')
for label,ty in types:
    parts.append(f'    println!("SUPER_LAYOUT {label} {{}} {{}}", std::mem::size_of::<{ty}>(), std::mem::align_of::<{ty}>());')
parts.append('}')
probe='\n'.join(parts)+'\n'
(K/'layout-probe-1/runtime.rs').write_text(probe)
(K/'layout-probe-1/machine-before.rs').write_text(machine)
(W/'src/script/machine/super_property_layout_probe.rs').write_text(probe)
(W/'src/script/machine.rs').write_text(machine+'\n#[cfg(test)]\nmod super_property_layout_probe;\n')
(K/'layout-probe-1/import.json').write_text(json.dumps(dict(base=BASE, imports=[binding('src/script/machine.rs'),binding('src/script/machine/super_property_layout_probe.rs')], semantic_changes=False),indent=2)+'\n')
print('Parent source frozen; inert full runtime/machine layout probe imported.')
