from pathlib import Path
import hashlib,json

K=Path(__file__).resolve().parents[1];W=K/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
registration=(K/'public-adapter-1/registration.txt').read_bytes()
changes={}; origins=[]
runtime=json.loads((K/'runtime-producer-1/source-ready.json').read_bytes())
for r in runtime['paths']:
    target=W/r['path']; current=target.read_bytes() if target.exists() else None
    if r['path']=='src/script.rs':
        assert current.endswith(registration);current=current[:-len(registration)]
    assert (sha(current) if current is not None else None)==r['before']
    raw=(K/'runtime-producer-1/raw'/r['path']).read_bytes();assert sha(raw)==r['after']
    if r['path']=='src/script.rs': raw+=registration
    changes[r['path']]=raw
for name in ['parser-producer-1','property-producer-1']:
    m=json.loads((K/name/'source-ready.json').read_bytes())
    payloads=m['payloads'] if 'payloads' in m else m['files']
    for r in payloads:
        path=r['path'] if 'path' in r else r['repository_path'];target=W/path
        assert path not in changes
        before=r.get('before')
        if before is None: assert not target.exists(),path
        else: assert sha(target.read_bytes())==before['sha256'],path
        raw_path=Path(r['raw']['path'])
        raw=(raw_path if raw_path.is_absolute() else K/raw_path).read_bytes();assert sha(raw)==r['raw']['sha256']
        changes[path]=raw
    origins.append(dict(hold=name,sha256=sha((K/name/'source-ready.json').read_bytes())))
m=json.loads((K/'historical-migration-1/source-ready.json').read_bytes())
assert sha((W/m['path']).read_bytes())==m['before']['sha256']
changes[m['path']]=Path(m['raw']['path']).read_bytes()
for path,b in changes.items():
    t=W/path;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(b)
(K/'root/production-import-1.json').write_text(json.dumps(dict(runtime_hold=sha((K/'runtime-producer-1/source-ready.json').read_bytes()),other_holds=origins,files=[dict(path=p,bytes=len(b),sha256=sha(b)) for p,b in sorted(changes.items())],qualification='Public test registrations explicitly composed; all semantic payloads otherwise exact'),indent=2)+'\n')
print('Imported',len(changes),'runtime/parser/property/test paths.')
