from pathlib import Path
import hashlib, json, sys

K = Path(__file__).resolve().parents[1]
W = K / 'worktree'
H = K / 'actual-layout-probes-1'

def binding(path):
    b = path.read_bytes()
    return dict(path=str(path), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

if sys.argv[1] == 'install':
    H.mkdir()
    runtime = (K / 'layout-probe-1/runtime.rs').read_text().replace('.before ', '.actual ')
    parser = (K / 'parser-layout-probe-1/raw/src/script/parser/driver/super_property_layout_probe.rs').read_text()
    parser = parser.replace('assert_eq!(before.iter().find', 'assert_eq!(proposed.iter().find')
    parser = parser.replace('fn super_property_parser_complete_layouts()', 'fn super_property_layout_parser_actual()')
    parser = parser.replace('[("before", &before), ("proposed", &proposed)]', '[("before", &before), ("proposed", &proposed), ("actual", &actual)]')
    imports = []
    for parent, raw in [('src/script/machine.rs', runtime), ('src/script/parser/driver.rs', parser)]:
        target = W / parent
        before = H / parent
        before.parent.mkdir(parents=True, exist_ok=True)
        before.write_bytes(target.read_bytes())
        probe = target.with_suffix('') / 'super_property_layout_probe.rs'
        assert not probe.exists()
        probe.write_text(raw)
        target.write_bytes(before.read_bytes() + b'\n#[cfg(test)]\nmod super_property_layout_probe;\n')
        imports.append(dict(parent=parent, before=binding(before), instrumented=binding(target), probe=binding(probe)))
    (H / 'imports.json').write_text(json.dumps(imports, indent=2) + '\n')
    print('Installed two temporary actual-layout probes.')
elif sys.argv[1] == 'remove':
    imports = json.loads((H / 'imports.json').read_bytes())
    for row in imports:
        assert binding(Path(row['instrumented']['path'])) == row['instrumented']
        assert binding(Path(row['probe']['path'])) == row['probe']
        assert binding(Path(row['before']['path'])) == row['before']
    for row in imports:
        target = W / row['parent']
        target.write_bytes(Path(row['before']['path']).read_bytes())
        held = H / 'probes' / row['parent']
        held.parent.mkdir(parents=True, exist_ok=True)
        held.write_bytes(Path(row['probe']['path']).read_bytes())
        Path(row['probe']['path']).unlink()
    (H / 'removed.json').write_text(json.dumps(dict(restored=[binding(W / r['parent']) for r in imports]), indent=2) + '\n')
    print('Removed both temporary probes; exact parent bytes restored.')
else:
    raise SystemExit('install or remove required')
