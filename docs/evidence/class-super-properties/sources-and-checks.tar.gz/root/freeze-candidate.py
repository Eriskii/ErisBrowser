from pathlib import Path
import hashlib, json, subprocess

K = Path(__file__).resolve().parents[1]
W = K / 'worktree'

def record(path, relative):
    assert path.is_file() and not path.is_symlink()
    data = path.read_bytes()
    return dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

paths = set()
for root in ['src', 'crates', 'assets', 'shaders', 'tools', 'tests']:
    paths.update(p.relative_to(W).as_posix() for p in (W / root).rglob('*') if p.is_file())
for name in ['Cargo.toml', 'Cargo.lock', 'build.rs']:
    if (W / name).is_file():
        paths.add(name)
assert not any('__pycache__' in p for p in paths)
rows = [record(W / p, p) for p in sorted(paths)]
inventory = dict(base=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip(),
                 scope='Complete current src/crates/assets/shaders and Cargo build inputs; all tools and tests including pinned conformance corpus. Excludes external compiler/system dependencies, documentation and build outputs.',
                 files=rows)
with (K / 'source-candidate-1.json').open('x') as out:
    json.dump(inventory, out, indent=2)
    out.write('\n')
changed = set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=W).decode().splitlines())
changed.update(subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W).decode().splitlines())
snapshots = []
for relative in sorted(changed):
    assert relative in paths, relative
    target = K / 'candidate-source-1' / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open('xb') as out:
        out.write((W / relative).read_bytes())
    snapshots.append(record(target, relative))
with (K / 'root/candidate-snapshots-1.json').open('x') as out:
    json.dump(dict(root=str(K / 'candidate-source-1'), files=snapshots), out, indent=2)
    out.write('\n')
print('Frozen', len(rows), 'inputs and', len(snapshots), 'changed source snapshots.')
