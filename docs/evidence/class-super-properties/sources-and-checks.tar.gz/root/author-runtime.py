from pathlib import Path
import hashlib, json, difflib, subprocess

K=Path(__file__).resolve().parents[1]; W=K/'worktree'; O=K/'runtime-producer-1'
BASE='db02f8c890a459b979378900f113b67460a49121'
O.mkdir(exist_ok=False)
def old(p): return subprocess.check_output(['git','show',BASE+':'+p],cwd=W).decode()
changes={}
def once(s,a,b):
    assert s.count(a)==1, (a,s.count(a))
    return s.replace(a,b)

s=old('src/script.rs')
s=s.replace('active_constructor','active_function')
s=once(s,'    bound: Option<BoundFunction>,\n}', '    bound: Option<BoundFunction>,\n    // Identity of the defining object, independent of this and the live parent.\n    home_object: Option<usize>,\n}')
s=once(s,'#[derive(Clone)]\nstruct Function {','// Complete Function layout grows from 104 to 120 bytes on both validated\n// toolchains. Class factories already charge typed arena/slot sizes; other\n// closure routes add this measured delta to their legacy allowances.\nconst FUNCTION_HOME_BYTES: usize = std::mem::size_of::<Option<usize>>();\n#[derive(Clone)]\nstruct Function {')
s=once(s,'    Property(Value, Value, bool),\n}', '    Property(Value, Value, bool),\n    SuperProperty {\n        base: Value,\n        name: Value,\n        receiver: Value,\n        strict: bool,\n    },\n}')
s=once(s,'mod classes;','mod classes;\nmod class_super_properties;\nmod super_properties;')
s=s.replace('            bound: None,\n','            bound: None,\n            home_object: None,\n')
s=once(s,'            std::mem::size_of::<code::Unit>() + std::mem::size_of::<code::Function>() + 64,','            std::mem::size_of::<code::Unit>()\n                + std::mem::size_of::<code::Function>()\n                + 64\n                + FUNCTION_HOME_BYTES,')
s=once(s,'    fn function_value(&mut self, code: &code::FunctionRef, environment: usize) -> Result<Value> {\n        self.charge_function_code_copy(code)?;', '''    fn function_value(&mut self, code: &code::FunctionRef, environment: usize) -> Result<Value> {
        self.charge(FUNCTION_HOME_BYTES)?;
        self.function_value_prepaid_home(code, environment)
    }
    // Class factories have already paid the complete typed slot and arena growth.
    fn function_value_prepaid_home(
        &mut self,
        code: &code::FunctionRef,
        environment: usize,
    ) -> Result<Value> {
        self.charge_function_code_copy(code)?;''')
s=once(s,'                    192 + bound_args','                    192 + FUNCTION_HOME_BYTES + bound_args')
s=once(s,'                    bound: Some(BoundFunction {','                    home_object: None,\n                    bound: Some(BoundFunction {')
s=once(s,'''                self.get_property_key(object.clone(), &key, doc)
            }
        }
    }
    fn write_reference''','''                self.get_property_key(object.clone(), &key, doc)
            }
            Reference::SuperProperty { base, name, receiver, .. } => {
                // Raw-key copy, normalized-key retention and both handle cleanups.
                self.work(4)?;
                let key = self.reference_key(base, name.clone(), doc)?;
                *name = key.value();
                self.get_super_property_key(base, &key, receiver, doc)
            }
        }
    }
    fn write_reference''')
s=once(s,'''                self.set_property_key(object, &key, value, strict, doc)
            }
        }
    }
    fn write_name''','''                self.set_property_key(object, &key, value, strict, doc)
            }
            Reference::SuperProperty { base, name, receiver, strict } => {
                // The capture producer funded retained owners, including refusal.
                self.work(4)?;
                let key = self.reference_key(&base, name, doc)?;
                self.set_super_property_key(&base, &key, &receiver, value, strict, doc)
            }
        }
    }
    fn write_name''')
changes['src/script.rs']=s

s=old('src/script/classes.rs').replace('active_constructor','active_function')
s=once(s,'        let id = self.functions.len();\n        self.functions.push(Function {', '''        let Value::Object(prototype_id) = prototype else {
            unreachable!()
        };
        let id = self.functions.len();
        self.functions.push(Function {''')
s=once(s,'            bound: None,','            bound: None,\n            home_object: Some(prototype_id),')
s=once(s,'''        let Value::Object(prototype_id) = prototype else {
            unreachable!()
        };
        self.class_define_property(''','''        self.class_define_property(''')
s=once(s,'let method = self.function_value(code, class_env)?;','let method = self.function_value_prepaid_home(code, class_env)?;')
changes['src/script/classes.rs']=s

s=old('src/script/machine/calls.rs').replace('active_constructor','active_function')
s=once(s,'    if !code.arrow {\n        let receiver =', '''    if !code.arrow {
        // The active closure owns super properties before any parameter default.
        runtime.work(1)?;
        runtime.environments[env].active_function = Some(id);
        let receiver =''')
changes['src/script/machine/calls.rs']=s

s=old('src/script/machine/classes.rs')
s=once(s,'''    let mut descriptor = PropertyDescriptor {''','''    let home = if element.is_static {
        runtime.functions[constructor].properties
    } else {
        prototype
    };
    runtime.class_attach_home(&method, home)?;
    let mut descriptor = PropertyDescriptor {''')
changes['src/script/machine/classes.rs']=s

s=old('src/script/machine.rs')
s=once(s,'    ReferenceKey(Value),','    ReferenceKey(Value),\n    SuperReferenceKey { owner: usize, receiver: Value },')
s=once(s,'''        Phase::Unary => {''','''        Phase::SuperReferenceKey { owner, receiver } => {
            let mut reference = runtime.class_super_property_reference(
                owner, receiver, value(output), runtime.environments[env].strict,
            )?;
            if frame.reference {
                Ok(Some(Output::Reference(reference)))
            } else {
                runtime.read_reference(&mut reference, doc)
                    .map(|value| Some(Output::Value(value)))
            }
        }
        Phase::Unary => {''')
s=once(s,'''            let Reference::Property(object, key, strict) = reference(output) else {
                unreachable!()
            };''','''            let (object, key, strict) = match reference(output) {
                Reference::Property(object, key, strict) => (object, key, strict),
                Reference::SuperProperty { .. } => {
                    runtime.work(1)?;
                    return Err(ScriptError::reference("cannot delete a super property"));
                }
                _ => unreachable!(),
            };''')
s=once(s,'''            let Reference::Property(receiver, _, _) = &reference else {
                unreachable!()
            };
            let receiver = receiver.clone();''','''            let receiver = match &reference {
                Reference::Property(receiver, _, _) => receiver.clone(),
                Reference::SuperProperty { receiver, .. } => {
                    runtime.work(2)?; // call receiver retain and eventual release
                    receiver.clone()
                }
                _ => unreachable!(),
            };''')
s=once(s,'''            _ => Err(ScriptError::type_error("invalid assignment target")),''','''            code::Expr::SuperProperty(key) => {
                super_property_start(runtime, frame, *key)
            }
            _ => Err(ScriptError::type_error("invalid assignment target")),''')
s=s.replace('code::Expr::Member(..)', 'code::Expr::Member(..) | code::Expr::SuperProperty(_)')
s=once(s,'''        code::Expr::Assign(_, left, _) => {''','''        code::Expr::SuperProperty(key) => super_property_start(runtime, frame, *key),
        code::Expr::Assign(_, left, _) => {''')
at='fn start(runtime: &mut Runtime, frame: ExprFrame, doc: &mut Document) -> Result<Option<Output>> {'
s=once(s,at,'''fn super_property_start(
    runtime: &mut Runtime,
    frame: ExprFrame,
    key: code::ExprId,
) -> Result<Option<Output>> {
    let (owner, receiver) = runtime.class_super_property_owner(frame.env)?;
    // Fund receipt/release of the raw key before the child can run author code.
    runtime.work(2)?;
    eval_child(runtime, frame, Phase::SuperReferenceKey { owner, receiver }, key)
}

'''+at)
changes['src/script/machine.rs']=s

s=old('src/script/classes/quota_tests.rs').replace('active_constructor','active_function')
changes['src/script/classes/quota_tests.rs']=s

new='src/script/class_super_properties.rs'
changes[new]='''//! Persistent class home identity and ordered SuperProperty capture.
use super::*;

fn invalid() -> ScriptError {
    ScriptError::resource("invalid super property runtime state")
}

impl Runtime {
    pub(super) fn class_attach_home(&mut self, method: &Value, home: usize) -> Result<()> {
        // Kind/range/metadata checks and the one immutable scalar publication.
        self.work(8)?;
        let Value::Function(id) = method else { return Err(invalid()); };
        if home >= self.objects.len() { return Err(invalid()); }
        let function = self.functions.get_mut(*id).ok_or_else(invalid)?;
        if function.bound.is_some() || function.home_object.is_some()
            || function.code.arrow || function.code.constructable
            || !function.code.strict || function.code.class_kind.is_some()
        {
            return Err(invalid());
        }
        function.home_object = Some(home);
        Ok(())
    }

    pub(super) fn class_super_property_owner(&mut self, environment: usize) -> Result<(usize, Value)> {
        // Validate ownership and prepay the receiver retain, handoff and cleanup.
        // Each lexical environment hop retains its existing separate tick.
        self.work(8)?;
        let owner = self.this_environment(environment)?;
        let receiver = self.class_this_value(owner)?;
        let row = self.environments.get(owner).ok_or_else(invalid)?;
        let function = self.functions.get(row.active_function.ok_or_else(invalid)?)
            .ok_or_else(invalid)?;
        let home = function.home_object.ok_or_else(invalid)?;
        if function.bound.is_some() || function.code.arrow || home >= self.objects.len() {
            return Err(invalid());
        }
        Ok((owner, receiver))
    }

    pub(super) fn class_super_property_reference(
        &mut self, owner: usize, receiver: Value, name: Value, strict: bool,
    ) -> Result<Reference> {
        // Initial capture/child scheduling funded incoming owners on refusal.
        // Revalidate IDs after key evaluation, retain the live base, then assemble.
        self.work(8)?;
        let row = self.environments.get(owner).ok_or_else(invalid)?;
        let function = self.functions.get(row.active_function.ok_or_else(invalid)?)
            .ok_or_else(invalid)?;
        if function.bound.is_some() || function.code.arrow { return Err(invalid()); }
        let home = self.objects.get(function.home_object.ok_or_else(invalid)?)
            .ok_or_else(invalid)?;
        let base = home.prototype.clone().unwrap_or(Value::Null);
        if base != Value::Null && !js_object(&base) { return Err(invalid()); }
        Ok(Reference::SuperProperty { base, name, receiver, strict })
    }
}
'''

files=[]
for p,s in changes.items():
    before='' if p==new else old(p)
    for label,text in [('before',before),('raw',s)]:
        target=O/label/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    diff=''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='a/'+p,tofile='b/'+p))
    d=O/'diffs'/(p+'.diff');d.parent.mkdir(parents=True,exist_ok=True);d.write_text(diff)
    files.append(dict(path=p,before=None if p==new else hashlib.sha256(before.encode()).hexdigest(),after=hashlib.sha256(s.encode()).hexdigest(),bytes=len(s.encode())))
manifest=dict(base=BASE,status='held draft; not imported or executed',paths=files,fees=dict(function_slot_delta=16,class_factories='complete typed slot/growth; prepaid-home helper avoids a duplicate delta',generic_bound_bootstrap='legacy allowance plus measured 16 byte delta',ordinary_activation_work=1,method_home_attach_work=8,capture_work='8 + existing environment hop ticks, then raw-key receipt/release 2, then reference completion 8',read_reference_work=4,write_reference_work=4,super_call_receiver_work=2,delete_work=1),qualification='Runtime/machine probe passed Rust 1.88; second toolchain probe pending. Parser/property producers and independent controls remain separate; no success claimed.')
(O/'draft-ready.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(dict(held=str(O),paths=len(files))))
