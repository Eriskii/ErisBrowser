from pathlib import Path
import hashlib,json,difflib,subprocess,re
P=Path(__file__).resolve().parent
K=P.parent
W=K/'worktree'
BASE='db02f8c890a459b979378900f113b67460a49121'
def sha(b):return hashlib.sha256(b).hexdigest()
def binding(path):
 b=path.read_bytes();return {'path':str(path.relative_to(K)),'bytes':len(b),'sha256':sha(b)}
def write(name,data):
 p=P/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(data,indent=2)+'\n');return binding(p)
paths=['src/script/reflect_properties.rs','src/script/super_properties.rs','src/script/super_properties/tests.rs']
rows=[]
for name in paths:
 raw=P/'raw'/name; after=raw.read_bytes(); old=P/'before'/name
 if old.exists():
  before=old.read_bytes(); assert before==subprocess.check_output(['git','show',BASE+':'+name],cwd=W)
 else:
  before=b''
  assert subprocess.run(['git','cat-file','-e',BASE+':'+name],cwd=W,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode!=0
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+name if old.exists() else '/dev/null',tofile='b/'+name))
 dp=P/'diff'/Path(name+'.diff');dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(patch)
 rows.append({'repository_path':name,'kind':'modified' if old.exists() else 'new','before':binding(old) if old.exists() else None,'raw':binding(raw),'diff':binding(dp)})
before=(P/'before'/paths[0]).read_text();after=(P/'raw'/paths[0]).read_text()
assert after.replace('    pub(super) fn reflect_find(', '    fn reflect_find(').replace('    pub(super) fn reflect_set(', '    fn reflect_set(')==before
assert after.count('    pub(super) fn reflect_find(')==after.count('    pub(super) fn reflect_set(')==1
proposal=json.loads((P/'proposal.json').read_text())
for row in proposal['source_bindings']:
 b=subprocess.check_output(['git','show',BASE+':'+row['repository_path']],cwd=W)
 assert len(b)==row['bytes'] and sha(b)==row['sha256']
selection=write('selection-addendum.json',{'status':'root selected proposal APIs and envelopes before implementation','proposal':binding(P/'proposal.json'),'selected_work':{'get_entry':6,'get_accessor_receiver_clone':1,'set_entry':6,'set_receiver_clone':1},'new_wrapper_heap':0,'caller_obligations':['Fund incoming RHS release before set entry refusal.','Fund retained raw key and normalized replacement separately.','GetValue/PutValue reject null base before deferred key conversion.'],'root_integration':'Root owns src/script.rs module registration and all Reference/home/active-function changes.','original_proposal_preserved':True})
tests=(P/'raw'/paths[2]).read_text()
names=re.findall(r'#\[test\]\s*fn ([a-zA-Z0-9_]+)\(',tests)
assert len(names)==8 and len(set(names))==8
contract=write('private-contract.json',{
 'authorship':'Producer-authored source-derived helper tests, written after wrapper implementation; independent peer/execution remain root-owned.',
 'groups':names,
 'fixture':'Fresh ordinary one-entry x bags, detached prototype chains and empty parameter maps. Public typed-array own probe demonstrates zero record-search charge without accessing private State fields.',
 'work_rows':[
 {'route':'Get data','sum':'6 + 2 + 8 + (4 + search(1,1))','search':2,'total':22,'cuts':[5,21,22],'heap_delta':0},
 {'route':'Get null base','cuts':[5,6],'outcomes':['Resource','TypeError']},
 {'route':'Get accessor before Call tick','sum':'22 + 1 receiver clone','cuts':[22,23],'outcome':'Resource before author entry and before call heap'},
 {'route':'Set base descriptor','sum':'6 + 1 clone + 4 + 8 + 6','total':25,'primitive_receiver_outcome':'false mapped to strict TypeError or sloppy success'},
 {'route':'Set receiver own descriptor','sum':'25 + 8 + 6','total':39,'cuts':[38,39],'accessor_conflict':'No setter call; strict TypeError/sloppy success'},
 {'route':'Set existing writable receiver data','sum':'39 + 1 ordinary_define_own_key','total':40,'cuts':[6,39,40],'heap_delta':0},
 {'route':'Set accessor argument admission','sum':'25 + 4','total':29,'cuts':[28,29],'heap':'32 + sizeof(Value)','heap_rows':['work one short: no heap added','heap one short: charged above cap then Resource','exact heap with zero remaining work: first Call tick refuses before author entry']}
 ],
 'semantic_rows':['Getter and setter strict primitive/null/undefined actual receivers.','Object payload identity and abrupt thrown object propagate unchanged.','Base writable data never calls a Receiver own accessor or Receiver prototype setter.','Typed numeric invalid distinct Receiver avoids coercion; valid distinct Receiver defines own data; same target invalid numeric index coerces; invalid Get stops prototype walk.','Represented DOM nodeValue preserves actual-receiver branding and targets the receiver node; unrepresented nodeType remains Unsupported.','Window descriptor storage exposes global var/accessor but omits lexical let; onclick remains Unsupported.'],
 'scope_limits':['No execution, target result or pass claim.','No sticky public observer witness here; root integration/public controls own that boundary.','Existing array, mapped-arguments, resizing/detachment, Symbol and depth controls remain unchanged and are not duplicated by these eight groups.','Quota cuts are valid for fixture shape and empty typed registry; no target layout constant is guessed.']})
manifest=write('manifest.json',{'base':BASE,'files':rows,'registration':{'root_owned':'Add mod super_properties; to src/script.rs.','held':'src/script/super_properties.rs declares #[cfg(test)] mod tests;'},'new_test_groups':names,'preservation':{'reflect_inverse':'Removing only two pub(super) visibility qualifiers recovers every published Reflect byte.','ordinary_get_set':'No ordinary get/set source is present in this hold.','limits':'No limit or core tariff changes.'}})
ready=write('source-ready.json',{'status':'sealed held source; not imported or executed','base':BASE,'selection':selection,'proposal':binding(P/'proposal.json'),'manifest':manifest,'private_contract':contract,'files':rows,'test_groups':8,'preserved_existing_file_inverse':True,'execution':False,'live_edits':False,'qualifications':['Producer-authored private tests require independent peer and root execution.','Existing Reflect unsupported host paths intentionally remain Unsupported.','Incoming RHS/Reference cleanup and null-before-ToPropertyKey ordering are caller responsibilities bound in selection addendum.']})
print(json.dumps(ready,indent=2))
