from pathlib import Path
import hashlib,importlib.util,json,sys
p=Path(__file__).resolve().parent
label=sys.argv[1]
spec=importlib.util.spec_from_file_location('eris_reference',p/'worktree/tools/reftest.py')
m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
r=json.loads((p/label/'report.json').read_text());assert (r['passed'],r['failed'],r['total'])==(81,0,81)
o=json.loads((p/'fixtures/oracles.json').read_text());w,h=o['viewport'];rows=[]
for case in o['cases']:
 expected=bytearray(bytes.fromhex(o['background']+'ff')*(w*h))
 for a in case['rectangles']:
  color=bytes.fromhex(a['rgb']+'ff')
  for y in range(a['y'],a['y']+a['height']):
   at=(y*w+a['x'])*4;expected[at:at+a['width']*4]=color*a['width']
 for suffix in ['', '-ref']:
  f=p/label/(case['name']+suffix+'.png');iw,ih,rgba=m.decode_png(f)
  assert (iw,ih)==(w,h) and rgba==expected,str(f)
 rows.append({'name':case['name'],'literal_rgba_sha256':hashlib.sha256(expected).hexdigest()})
parent=json.loads((p/'root/before/tests/reftests/manifest.json').read_text());now=json.loads((p/'worktree/tests/reftests/manifest.json').read_text());assert now['cases'][:76]==parent['cases'] and len(parent['cases'])==76
old=Path('/tmp/eris-rounded-boxes-1/reftests-final-3')
for case in parent['cases']:
 for suffix in ['', '-ref']:
  name=case['name']+suffix+'.png';assert m.decode_png(old/name)==m.decode_png(p/label/name),name
fixture=p/'root/positioned-only-candidate.png';pw,ph,actual=m.decode_png(fixture);assert (pw,ph)==(32,16)
expected=bytearray(bytes.fromhex('ffffffff')*(32*16))
for x,color in [(0,'ff0000ff'),(8,'00ff00ff')]:
 for y in range(4):
  at=(y*32+x)*4;expected[at:at+16]=bytes.fromhex(color)*4
assert actual==expected and m.decode_png(fixture)==m.decode_png(p/'root/positioned-only-parent.png')
result={'reference_report':label+'/report.json','new_literal_cases':rows,'unchanged_parent_pairs':76,'positioned_only':{'width':32,'height':16,'rgba_sha256':hashlib.sha256(expected).hexdigest(),'png_sha256':hashlib.sha256(fixture.read_bytes()).hexdigest()}}
with (p/(label+'-literals.json')).open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
