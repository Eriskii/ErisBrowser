"""Root-only publication of explicitly selected, completed inline-edge evidence."""
from pathlib import Path
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
BASE = '8595a6e8f4b00069cfa5c4a36e688a6e51cfd383'
D = W / 'docs/evidence/inline-edges'
CAP = 64 * 1024 * 1024
PARENT = Path('/tmp/eris-rounded-boxes-1')
NEW_NAMES = ['inline-edge-padding', 'inline-edge-wrap', 'inline-edge-nested-empty',
             'inline-edge-forced-break', 'inline-edge-float-percentage']
TYPE_NAMES = {'eris::graphics::Canvas', 'eris::graphics::DrawCommand',
              'eris::layout::Fragment', 'eris::layout::InlineItem', 'eris::layout::InlineKind'}

def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

def local(name, root=P):
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path

def binding(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}

def checked(spec, root=P):
    path = local(spec['path'], root)
    assert path.stat().st_size == spec['bytes'] and digest(path) == spec['sha256'], path
    return path

def read(spec, root=P):
    return json.loads(checked(spec, root).read_text())

def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)

def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return {'rows': len(rows), 'passed': sum(int(x[1]) for x in rows),
            'failed': sum(int(x[2]) for x in rows), 'ignored': sum(int(x[3]) for x in rows)}

selection_path = local(sys.argv[1] if len(sys.argv) == 2 else 'publication-selection.json')
selection = json.loads(selection_path.read_text())
source_path = checked(selection['source'])
source = json.loads(source_path.read_text())
assert source['base'] == BASE and git('rev-parse', 'HEAD').decode().strip() == BASE
inputs = source['source_sha256']
assert len(inputs) == selection['source_count'] and selection['source_count'] > 0
for name, sha in inputs.items():
    assert digest(local(name, W)) == sha, name
source_sha = digest(source_path)

# Every extant attempt is retained; selected roles alone assert final success.
checks = {}
for path in sorted((P / 'validation').glob('*.json')):
    receipt = json.loads(path.read_text())
    if not {'command', 'exit', 'log', 'sha256'} <= receipt.keys():
        continue
    log = local(receipt['log'], path.parent)
    assert digest(log) == receipt['sha256'], path
    checks[path.name] = {'receipt': binding(path), 'log': binding(log),
                        'command': receipt['command'], 'exit': receipt['exit'],
                        'rust': totals(log.read_text(errors='replace'))}
for name in ['full-native-1.json', 'full-default-198-1.json']:
    assert checks[name]['exit'] == 101 and checks[name]['rust']['failed'] == 1, name
roles = {}
for item in selection['checks']:
    path = checked(item['receipt'])
    assert path.parent == P / 'validation' and item['role'] not in roles
    record = checks[path.name]
    assert record['command'] == item['command'] and record['exit'] == item['exit'], path
    if 'rust' in item:
        assert record['rust'] == item['rust'], path
    if item.get('final'):
        assert item['exit'] == 0 and item['source_sha256'] == source_sha, path
    roles[item['role']] = {**record, 'final': item.get('final', False)}
required = {'full_native', 'full_default', 'focused', 'clippy_native_msrv',
            'clippy_native_current', 'clippy_default_current', 'format',
            'browser_build', 'browser_strip', 'reftests', 'final_pixel_literals', 'positioned_only'}
assert required <= roles.keys() and all(roles[name]['final'] for name in required)
for role, version, features in [('full_native', '1.88.0', ['--features', 'vulkan-raster']),
                                ('full_default', '1.98.0', [])]:
    assert roles[role]['command'] == ['cargo', '+' + version, 'test', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', *features, '--', '--include-ignored', '--test-threads=4']
    actual = roles[role]['rust']
    assert actual['rows'] == 34 and actual['passed'] > 0 and actual['failed'] == actual['ignored'] == 0
assert roles['focused']['command'] == ['cargo', '+1.88.0', 'test', '--locked', '--offline',
    '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--lib', 'layout::inline_edges::']
assert roles['focused']['rust']['passed'] > 0 and roles['focused']['rust']['failed'] == roles['focused']['rust']['ignored'] == 0
for role, version, features in [('clippy_native_msrv', '1.88.0', ['--features', 'vulkan-raster']),
                                ('clippy_native_current', '1.98.0', ['--features', 'vulkan-raster']),
                                ('clippy_default_current', '1.98.0', [])]:
    assert roles[role]['command'] == ['cargo', '+' + version, 'clippy', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', *features, '--all-targets', '--', '-D', 'warnings']
assert roles['format']['command'] == ['env', 'RUSTUP_HOME=/tmp/eris-vulkan-rustup',
    'CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home', 'cargo', '+1.98.0', 'fmt', '--all', '--', '--check']

browser_path = checked(selection['browser'])
browser = json.loads(browser_path.read_text())
binary = local(browser['path'])
assert binding(binary) == {k: browser[k] for k in ['path', 'bytes', 'sha256']}
assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
assert P / browser['build_receipt'] == Path(roles['browser_build']['receipt']['path'])
assert roles['browser_build']['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
    '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
assert roles['browser_strip']['command'] in [['strip', str(binary)], ['strip', '--strip-debug', str(binary)]]
parent_record_path = local('browser-final-3.json', PARENT)
parent_browser = json.loads(parent_record_path.read_text())
parent_binary = local(parent_browser['path'], PARENT)
assert parent_binary.stat().st_size == parent_browser['bytes'] and digest(parent_binary) == parent_browser['sha256']

manifest = json.loads((W / 'tests/reftests/manifest.json').read_text())
parent_manifest_bytes = git('show', BASE + ':tests/reftests/manifest.json')
parent_manifest = json.loads(parent_manifest_bytes)
additions = json.loads((P / 'fixtures/manifest-additions.json').read_text())
assert len(parent_manifest['cases']) == 76 and [r['name'] for r in additions] == NEW_NAMES
assert manifest['cases'] == parent_manifest['cases'] + additions and len(manifest['cases']) == 81
assert {k:v for k,v in manifest.items() if k != 'cases'} == {k:v for k,v in parent_manifest.items() if k != 'cases'}
allowed_refs = {'tests/reftests/manifest.json'} | {'tests/reftests/' + row[key] for row in additions for key in ['test', 'reference']}
assert set(git('diff', '--name-only', 'HEAD', '--', 'tests/reftests').decode().splitlines()) <= allowed_refs
assert not git('diff', 'HEAD', '--', 'crates/raster-core', 'src/graphics', 'src/graphics.rs', 'src/worker/codec.rs')
fixture_hold = json.loads((P / 'fixtures/source-ready.json').read_text())
assert len(fixture_hold['owned_files']) == 10
for row in fixture_hold['owned_files']:
    assert digest(checked(row['raw'])) == digest(local(row['relative'], W)) == inputs[row['relative']]
report_path = checked(selection['report'])
report = json.loads(report_path.read_text())
assert (report['passed'], report['failed'], report['total']) == (81, 0, 81)
assert len(report['cases']) == 81 and {c['name'] for c in report['cases']} == {c['name'] for c in manifest['cases']}
assert all(c['status'] == 'pass' and c['different_pixels'] == c['maximum_channel_error'] == 0 for c in report['cases'])
assert report['binary'] == str(binary)
assert roles['reftests']['command'] == ['python3', 'tools/reftest.py', '--binary', str(binary), '--output-dir', str(report_path.parent)]
parent_report = json.loads((P / 'parent-new-reftests-1/report.json').read_text())
assert (parent_report['passed'], parent_report['failed'], parent_report['total']) == (0, 5, 5)
assert parent_report['binary'] == str(parent_binary) and len(parent_report['cases']) == 5
assert {c['name'] for c in parent_report['cases']} == set(NEW_NAMES)
assert all(c['status'] == 'fail' and c['different_pixels'] > 0 for c in parent_report['cases'])
parent_run = checks['parent-new-reftests-1.json']
assert parent_run['exit'] == 1 and parent_run['command'] == ['python3', 'tools/reftest.py', '--binary', str(parent_binary),
    '--manifest', str(P / 'fixtures/new-manifest.json'), '--output-dir', str(P / 'parent-new-reftests-1')]
literals = json.loads((P / 'reference-literals-1.json').read_text())
assert literals['oracle_sha256'] == digest(checked(fixture_hold['oracles']))
assert {c['name'] for c in literals['cases']} == set(NEW_NAMES) and len(literals['cases']) == 5
for row in literals['cases']:
    assert digest(P / 'parent-new-reftests-1' / (row['name'] + '-ref.png')) == row['reference_png_sha256']
anchor = json.loads((P / 'root/positioned-only-parent.json').read_text())
assert anchor['parent_binary'] == str(parent_binary)
assert anchor['fixture_sha256'] == digest(P / 'root/positioned-only.html')
assert anchor['png_sha256'] == digest(P / 'root/positioned-only-parent.png')
assert checks['parent-positioned-only-1.json']['exit'] == 0
assert checks['parent-positioned-only-1.json']['command'] == [str(parent_binary), '--render', str(P / 'root/positioned-only.html'),
    '--output', str(P / 'root/positioned-only-parent.png'), '--width', '32', '--height', '16', '--no-scripts']

# The reviewed helper compares decoded pixels; publication authenticates its exact inputs/output.
checker = checked(selection['final_pixel_checker'])
assert checker == P / 'check-final-pixels-2.py'
final_literals_path = checked(selection['final_pixel_literals'])
final_literals = json.loads(final_literals_path.read_text())
assert final_literals_path == P / (report_path.parent.name + '-literals-2.json')
assert roles['final_pixel_literals']['command'] == ['python3', str(checker), report_path.parent.name]
assert json.loads(Path(roles['final_pixel_literals']['log']['path']).read_text()) == final_literals
assert final_literals['reference_report'] == str(report_path.relative_to(P))
assert final_literals['unchanged_parent_pairs'] == len(parent_manifest['cases']) == 76
assert len(final_literals['new_literal_cases']) == 5
assert {r['name']: r['literal_rgba_sha256'] for r in final_literals['new_literal_cases']} == {
    r['name']: r['literal_rgba_sha256'] for r in literals['cases']}
pairs = final_literals['image_inputs']
assert len(pairs) == 81 and {r['name'] for r in pairs} == {r['name'] for r in manifest['cases']}
old_names = {r['name'] for r in parent_manifest['cases']}
for row in pairs:
    expected_keys = {'name', 'test', 'reference'} | ({'parent_test', 'parent_reference'} if row['name'] in old_names else set())
    assert set(row) == expected_keys
    for key, suffix in [('test', ''), ('reference', '-ref')]:
        expected = report_path.parent / (row['name'] + suffix + '.png')
        assert local(row[key]['path']) == expected and digest(expected) == row[key]['sha256']
        if row['name'] in old_names:
            expected = PARENT / 'reftests-final-3' / (row['name'] + suffix + '.png')
            prior = row['parent_' + key]
            assert local(prior['path'], PARENT) == expected and digest(expected) == prior['sha256']
assert final_literals['positioned_only']['width'] == 32 and final_literals['positioned_only']['height'] == 16
assert final_literals['positioned_only']['png_sha256'] == digest(P / 'root/positioned-only-candidate.png')
assert final_literals['positioned_only']['rgba_sha256'] == 'bc550e4b32c53b6365d8a573a258ce8084726470dd110775219776dc9e529aad'
assert roles['positioned_only']['command'] == [str(binary), '--render', str(P / 'root/positioned-only.html'),
    '--output', str(P / 'root/positioned-only-candidate.png'), '--width', '32', '--height', '16', '--no-scripts']

sizes = {name: read(selection['type_sizes'][name]) for name in ['parent', 'candidate']}
for name, record in sizes.items():
    assert set(record['sizes']) == TYPE_NAMES and all(len(v) == 1 and v[0] > 0 for v in record['sizes'].values())
    expected = parent_browser if name == 'parent' else browser
    root = PARENT if name == 'parent' else P
    assert digest(local(record['binary'], root)) == record['binary_sha256'] == expected['unstripped_sha256']
    assert record['method'] == 'readelf --debug-dump=info; namespace-qualified DW_AT_byte_size'
assert sizes['parent']['sizes'] == sizes['candidate']['sizes']
docs = read(selection['docs'])
published_docs = docs.get('published_files', docs.get('drafts'))
assert {r['relative'] for r in published_docs} == {'README.md', 'docs/SECURITY.md', 'docs/inline-edges.md'}
for row in published_docs:
    assert digest(checked(row)) == digest(local(row['relative'], W)) == row['sha256']
for spec in selection['reviews']:
    review = read(spec)
    assert str(review.get('status', '')).lower().startswith('clear'), spec
assert selection['reviews']
published = selection['published_files']
assert len({r['path'] for r in published}) == len(published)
for spec in published:
    checked(spec, W)
changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
changed.discard('')
assert changed == {r['path'] for r in published}, sorted(changed ^ {r['path'] for r in published})
assert {r['relative'] for r in published_docs} <= changed

# Only owned preparation trees, observed report directories and explicit small files.
files = {selection_path, source_path, browser_path, report_path, checker, final_literals_path,
         Path(__file__).resolve(), P / 'publication-design.json'}
for dirname in ['layout', 'script', 'fixtures', 'root', 'docs', 'package-preparation', 'validation', 'parent-new-reftests-1', report_path.parent.name]:
    root = P / dirname
    assert root.is_dir() and root == root.resolve() and root.parent == P
    for path in root.rglob('*'):
        assert not path.is_symlink(), path
        if path.is_file():
            files.add(path)
files.update(checked(r) for r in selection.get('archive_files', []))
files.update(checked(r) for r in selection['reviews'])
files.update(checked(r) for r in selection['type_sizes'].values())
files.update(checked(r, W) for r in published)
files.update(P.glob('compiled-source-*.json'))
files.update(P.glob('authored-source-*.json'))
files.update(P / name for name in ['parent.json', 'parent-type-sizes.json', 'reference-literals-1.json', 'check-reference-literals.py', 'check-final-pixels.py', 'reftests-final-2-literals.json', 'measure-dwarf-types.py'])
assert sum(path.stat().st_size for path in files) < CAP
contents = {}
for path in sorted(files):
    path = local(path)
    name = str(path.relative_to(P))
    assert not any(part == 'target' or part.startswith('target-') for part in Path(name).parts), name
    assert path.suffix not in {'.gz', '.zip', '.tar', '.rlib', '.so', '.pyc'}, name
    data = path.read_bytes()
    assert not data.startswith(b'\x7fELF'), name
    contents[name] = data
contents['parent-bindings/browser-final-3.json'] = parent_record_path.read_bytes()
contents['parent-bindings/reftest-manifest.json'] = parent_manifest_bytes
assert sum(map(len, contents.values())) < CAP
for name, sha in inputs.items():
    assert digest(local(name, W)) == sha, name
index = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(contents.items())]
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as archive:
    for name, data in sorted(contents.items()):
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644; info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
assert raw.tell() < CAP
compressed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
assert len(compressed) < CAP
assert D == D.resolve()
D.mkdir(parents=True, exist_ok=True)
archive_path = D / 'validation.tar.gz'; summary_path = D / 'summary.json'
assert not archive_path.exists() and not summary_path.exists()
with archive_path.open('xb') as stream:
    stream.write(compressed)
assert archive_path.read_bytes() == compressed
with tarfile.open(archive_path, 'r:gz') as archive:
    assert [m.name for m in archive.getmembers()] == sorted(contents)
    for member in archive.getmembers():
        assert member.isfile() and archive.extractfile(member).read() == contents[member.name]
summary = {'base': BASE, 'scope': 'Ordinary inline horizontal edges and distinct per-line owner geometry; no new CSS property or decoration painting, GPU, or timing claim.',
    'compiled_source': binding(source_path), 'source_count': len(inputs), 'checks': checks, 'selected_roles': roles,
    'browser': browser, 'reftests': binding(report_path), 'parent_new_reftests': binding(P / 'parent-new-reftests-1/report.json'),
    'final_pixel_literals': binding(final_literals_path), 'final_pixel_checker': binding(checker),
    'reference_literals': binding(P / 'reference-literals-1.json'), 'positioned_only_parent': binding(P / 'root/positioned-only-parent.json'),
    'type_sizes': sizes, 'reviews': selection['reviews'], 'published_bindings': published,
    'published_document_sha256': {r['relative']: r['sha256'] for r in published_docs},
    'archive': {'path': 'validation.tar.gz', 'bytes': len(compressed), 'sha256': digest(archive_path), 'members': len(index)},
    'archive_inputs': index, 'selection': binding(selection_path),
    'limits': ['Self-authored cases do not establish full web compatibility.', 'DWARF sizes are this build’s emitted type sizes, not allocator instrumentation.', 'Historical failed attempts and pre-fix source holds remain in the archive.']}
with summary_path.open('x') as stream:
    json.dump(summary, stream, indent=2); stream.write('\n')
assert json.loads(summary_path.read_text()) == summary
print(json.dumps({'summary_sha256': digest(summary_path), 'archive': summary['archive'], 'source_count': len(inputs)}, indent=2))
