"""Read emitted Rust type sizes without adding instrumentation to project sources."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
binary=Path(sys.argv[1]);output=Path(sys.argv[2]);wanted={'InlineItem','InlineKind','Fragment','Canvas','DrawCommand'}
proc=subprocess.Popen(['readelf','--debug-dump=info',str(binary)],stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
stack=[];current=None;found={}
def save(node):
 if node and node.get('name') in wanted and 'bytes' in node:
  scope=node['parents']
  if 'eris' in scope and any(s in scope for s in ['layout','graphics']):
   key='::'.join([*scope,node['name']]);found.setdefault(key,set()).add(node['bytes'])
for line in proc.stdout:
 match=re.match(r'\s*<(\d+)><[0-9a-f]+>:.*?(DW_TAG_[a-z_]+)',line)
 if match:
  save(current)
  depth=int(match[1]);stack=stack[:depth]
  current={'tag':match[2],'parents':[n.get('name','') for n in stack if n['tag']=='DW_TAG_namespace']}
  stack.append(current)
 elif current:
  if 'DW_AT_name' in line:
   current['name']=line.rstrip().rsplit(': ',1)[-1]
  elif 'DW_AT_byte_size' in line:
   value=line.rstrip().rsplit(': ',1)[-1]
   if value.isdecimal():current['bytes']=int(value)
save(current)
error=proc.stderr.read();assert proc.wait()==0,error
assert found, 'No matching emitted type sizes'
result={'binary':str(binary),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'method':'readelf --debug-dump=info; namespace-qualified DW_AT_byte_size','sizes':{k:sorted(v) for k,v in sorted(found.items())}}
with output.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
