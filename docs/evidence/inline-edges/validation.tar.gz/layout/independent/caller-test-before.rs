
#[test]
fn actual_forced_break_caller_does_not_advance_a_refused_nonempty_line() {
    let doc = Document::parse("<style>body{margin:0}#owner{font-size:1px;line-height:4px;padding-left:1px;padding-right:1px}i{display:inline-block;width:4px;height:4px;vertical-align:top}</style><div id=row><span id=owner><i id=a></i><br></span></div>");
    let styles = crate::css::compute_styles(&doc, &doc.stylesheets(), 64.0, 100.0);
    let fonts = Fonts::new();
    let row = doc.query_selector("#row").unwrap();
    let owner = doc.query_selector("#owner").unwrap();
    let a = doc.query_selector("#a").unwrap();
    let (mut refusals, mut successes) = (0, 0);
    // Fixed bounded cuts exercise collection, line planning and the actual br
    // caller. No runtime-measured fee is used to select or adjust a cut.
    for budget in (0..=256).chain(std::iter::once(MAX_POSITION_WORK)) {
        let mut e = engine(&doc, &styles, &fonts);
        e.position_work_left = budget;
        let height = e.layout_inline(&doc.nodes[row].children, 0.0, 0.0, 64.0, "left", 0);
        if e.boxes.iter().any(|g| g.node == owner) {
            successes += 1;
            assert_eq!(height, 8.0, "successful original forced-break height, budget {budget}");
            assert_eq!(e.hits.iter().find(|h| h.node == a).unwrap().rect, rect(1.0, 0.0, 4.0, 4.0));
        } else {
            refusals += 1;
            assert_eq!(height, 0.0, "refusal must not become an empty successful br, budget {budget}");
            assert!(e.commands.is_empty() && e.owners.is_empty() && e.hits.is_empty() && e.boxes.is_empty());
            assert!(e.positioned.is_empty());
        }
    }
    assert!(refusals > 0 && successes > 0);
}
