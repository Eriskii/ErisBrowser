
#[test]
fn translated_line_subtracts_nominal_ascent_before_adding_line_top() {
    let s = InlineSpan { node: 0, parent: None, border: Sides::default(), padding: Sides::default(), margin: (0.0, 0.0), first: Some(0), last: Some(0), font_size: 16.0 };
    // At line top55, adding local15.2 first and then subtracting the same
    // ascent loses one f32 ULP. The local baseline contract preserves55 exactly.
    let g = s.geometry(0.0, 4.0, 55.0, 15.2, true, true);
    assert_eq!(g.content.y.to_bits(), 55.0f32.to_bits());
    assert_eq!(g.padding.y.to_bits(), 55.0f32.to_bits());
    assert_eq!(g.border.y.to_bits(), 55.0f32.to_bits());
}
