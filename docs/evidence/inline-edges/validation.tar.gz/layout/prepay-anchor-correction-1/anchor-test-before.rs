
#[test]
fn positioned_only_inline_retains_zero_width_containing_anchor() {
    let doc = Document::parse("<!doctype html><style>html,body{margin:0;padding:0;background:white;font-size:1px;line-height:4px}span{position:relative}i{position:absolute;left:0;top:0;width:4px;height:4px;background:red}b{display:block;margin-left:8px;width:4px;height:4px;background:lime}</style><span><i id=anchor></i></span><b></b>");
    let styles = crate::css::compute_styles(&doc, &doc.stylesheets(), 32.0, 16.0);
    let fonts = Fonts::new();
    let result = layout(&doc, &styles, 32.0, 16.0, &fonts);
    assert_eq!(hit(&doc, &result, "#anchor"), rect(0.0, 0.0, 4.0, 4.0));
    let mut canvas = crate::graphics::Canvas::new(32, 16).unwrap();
    canvas.paint(&result.commands, &fonts, &crate::graphics::ImageStore::new(), 0.0, 0.0);
    for y in 0..16 { for x in 0..32 {
        let expected = if y < 4 && x < 4 { 0xff0000 } else if y < 4 && (8..12).contains(&x) { 0x00ff00 } else { 0xffffff };
        assert_eq!(canvas.pixels[y * 32 + x], expected, "at {x},{y}");
    }}
}
