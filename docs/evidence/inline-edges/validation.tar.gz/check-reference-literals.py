from pathlib import Path
import hashlib,importlib.util,json
p=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('eris_reference',p/'worktree/tools/reftest.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
oracles=json.loads((p/'fixtures/oracles.json').read_text())
w,h=oracles['viewport'];rows=[]
for case in oracles['cases']:
 expected=bytearray(bytes.fromhex(oracles['background']+'ff')*(w*h))
 for r in case['rectangles']:
  color=bytes.fromhex(r['rgb']+'ff')
  assert r['x']+r['width']<=w and r['y']+r['height']<=h
  for y in range(r['y'],r['y']+r['height']):
   start=(y*w+r['x'])*4;expected[start:start+r['width']*4]=color*r['width']
 f=p/'parent-new-reftests-1'/(case['name']+'-ref.png')
 rw,rh,rgba=module.decode_png(f)
 assert (rw,rh)==(w,h) and rgba==expected,case['name']
 rows.append({'name':case['name'],'reference_png_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'literal_rgba_sha256':hashlib.sha256(expected).hexdigest(),'bytes':len(expected)})
result={'scope':'All five absolute-positioned reference renders match the independently frozen literal whole-frame RGBA expectations. Published browser still fails all five input pages.','oracle_sha256':hashlib.sha256((p/'fixtures/oracles.json').read_bytes()).hexdigest(),'cases':rows}
with (p/'reference-literals-1.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result,indent=2))
