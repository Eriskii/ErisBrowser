# Implemented ordinary position ledger

The implementation follows the held runtime plan db462040004773796a5cfc03a169cea57a82dcb92d585ca2cc62520178594227 and its full proposal/ledger, root acceptance, and layout review. Its actual base is published 53859161acf081bac70ee4c0e0daf000abe9088b. This agent has not compiled or executed the candidate. Numeric bootstrap and geometry values remain predictions until root measurement.

## Concrete helper correspondence

node_compare_document_position pays receiver16, required arity4, nonnullable interface12, each operand local16, and identity/result2. Same ID returns0 at66 after canonical/local checks without certifying ancestry. position_local adds the canonical-root-kind check to the unchanged predicate local helper; callers prepay it. Distinct operands finish both position_root_and_depth calls before root comparison4. Different roots use original operand IDs: other smaller gives35, larger gives37. No payload, namespace, author property, or template host is read to determine order.

The new walk is separate; getRootNode options, shared root walk, isConnected, equality and predicate bodies stay exact. Each new walk pays setup4, each current local16, each parent shape12 and complete membership scan1+4S, then endpoint4. Its total is24+29D+4ΣS. Both full paths retain the256-edge endpoint and explicit malformed-link/cycle refusal. It checks a false canonical root even at an intermediate reached node. No global/unrelated-node validation is claimed.

Same-root setup4 precedes alignment. The two loops each pay2 per condition including their false terminator and8 before each safe parent read/decrement, totaling10A+4. Aligned identity/containment result4 returns20 for other-descendant or10 for other-ancestor. Each remaining paired ascent pays4+8+8 before reading parents. The immutable document and absence of callbacks preserve the first-phase proof. position_parent only performs a checked, paid lookup; it allocates nothing.

position_branch_order pays8, then the entire1+6L scan before inspecting positions, then4 for final result/required-position validation. It detects duplicate/missing selected branch IDs; unrelated sibling IDs are compared but not dereferenced. The branch result is2 if the other selected sibling occurs earlier, otherwise4. Totals are same66, disconnected118+29D+4S, ancestor130+29D+4S+10A, and divergent143+29D+4S+10A+20J+6L. Bodies own no traversal or payload heap; inherited error diagnostics and generic invocation allocations remain separate.

The six held geometry predictions118/249/11138/17003/17014/22179 are tested at exact/one-short endpoints, in both directions. Small cases alone use exhaustive budget cuts. The final scan has its own moderate-width cutpoints; a separate8000-child public terminal setup measures both walks64106 and bounds the prefix64208 plus existing VM overhead before refusing the48001 scan. First/second wide-walk failures are distinct. No test or production limit is increased.

## Dispatch, metadata, and batch

node_data_native adds only a length23 arm paying23 after the existing discriminator1. The unchanged paid call-name preflight for32 ASCII bytes pays36 work/64 bytes, for scoped60 work/64 bytes before additional VM/property lookup. extraction-proof.json binds the old factory/preflight and complete dispatch tail as unchanged. The shared install_node_identity_members array becomes isSameNode, compareDocumentPosition, contains and retains its single4-work entry.

One new cached metadata bag and one Node order slot are reserved. Factory163, owner288 at old count9, shifted contains10, and batch232 total693 additional bootstrap work; no additional installer or later constructor delta. The ordinary method has length1 and writable/enumerable/configurable descriptor. Native handles, constants, creation order and mutable bag identities remain ordinary.

Prototype old11/final29/order capacity30; constructor old3/final21/capacity21. N29 map4206 and owner1004 plus constructor3030/300 and common1584 give10124 batch work. The two overflows at12/24 still need four prototype nodes; right leaf5 requires no redistribution while retaining64 repair allowance. Sort scratch and typed node admission remain unchanged except the one additional staged entry. Batch storage is14820+18K+146E+7B. Exact sorted and physical preconstant rosters include the new key in their reviewed positions; tests update all prebatch/final/capacity literals and retain saved Native identities.

Typed delta1516+(S+A+D+N)+3K+B+E is conditionally3412 at predecessor sizes304/16/1472/72. Against measured connected7292/1765502/688, predicted raw bootstrap is6599 steps remaining/1768914 bytes/689 objects and capacity, with321 native registry and25 legacy prototypes. Both descriptive bootstrap files are preserved byte-exact for root-owned measurement. No numeric quota, reset, refund, wire, DOM storage or authority change occurs.

## Tests, scope and hold

The owned source hold contains15 paths. The new module contributes17 direct and16 independent groups (33 unique Runtime groups,32 literal strict/sloppy observations); root owns two separate Page/worker groups. Direct groups include all128 ordered-pair cells of the independently held mixed-depth matrices before/after reorder, six measured geometries, local/ancestral malformed cases, original-ID disconnection, no-body-heap cuts, full terminal scan phases and ignored-extra-expression exhaustion, exact/one-short saved Native work/heap cleanup, unrelated-arena independence, and two-live-realm metadata.

All six historical JS fixtures are exact. Existing disposable wrappers explicitly remove/restore compareDocumentPosition as a method, preserving their separate getter handling. Connected's old pristine inventory now has a named disposable historical wrapper; its original source and literal mode parameter remain unchanged. Current Node-data order is explicit. Existing old root/options/getter/equality/predicate and generic VM tests remain available for root regression execution.

Original bytes are under originals; published unchanged dependencies are under preserved; all final owned paths are under held. Installed Rust1.88 rustfmt edition2024/skip_children=true and git diff --check passed. No compiler, engine, or commit ran by this agent. No root-owned browser/documentation or measured snapshot edits are included here.
