# Node.compareDocumentPosition

This draft describes the selected ordinary-node increment. Candidate source,
measured admission, test results, release comparison and independent result audit
are **pending**. The existing published predecessor is the connection checkpoint;
no candidate success follows from these planned semantics or formulas.

The method compares the argument with its receiver in represented ordinary
trees. The result is `0` for the same node, `2` or `4` for an earlier or later
branch, `10` for an ancestor and `20` for a descendant. Document aliases share
one canonical identity. A template's actual content fragment has a separate
ordinary root from its host; direct ordinary children of the template participate
in its own tree. Character data, element names, attributes, namespaces,
visibility and structural equality do not determine position.

Disconnected trees return `35` or `37`: DISCONNECTED and
IMPLEMENTATION_SPECIFIC together with one direction bit. The selected direction
uses the original canonical operand IDs: a smaller argument ID gives `35`, a
larger argument ID gives `37`. The IDs remain stable in the current append-only
arena, including retained detached nodes. This is a local implementation policy,
not pointer ordering, a cross-document ownership policy or a global tree order.
Portable independent cases accept either allowed direction, require opposite
reversal, and require stable results for unchanged disconnected operands. Private
tests must separately verify the chosen ID policy.

The cached nonconstructible method has name `compareDocumentPosition`, length
one, and an ordinary writable/enumerable/configurable descriptor. Its receiver
must be authentic. The required argument is **nonnullable**: omission, null,
undefined, primitives and forged nodes throw TypeError. Receiver authentication
precedes argument conversion; interface conversion calls no authored coercion
hook. Public `parentNode`, `childNodes`, `nodeType` or prototype lookalikes do not
replace internal identity and links. Saved calls, own shadows and prototype
property replacement, deletion and restoration follow ordinary lookup, without
fallback resurrection.

Receiver and argument expressions, including ignored extra arguments, finish
before invocation. Their completed mutations and thrown values remain observable.
The native body then uses one immutable Document borrow, calls no authored
callback and performs no DOM mutation. Resource refusal can retain those earlier
argument effects; it does not roll them back or refund work.

The [DOM algorithm](https://dom.spec.whatwg.org/#dom-node-comparedocumentposition)
and [ordinary tree order](https://dom.spec.whatwg.org/#concept-tree-order) define
the masks and relationships. [Web IDL interface conversion](https://webidl.spec.whatwg.org/#es-interface)
and [regular operation rules](https://webidl.spec.whatwg.org/#es-operations)
define authenticity, required arguments and method behavior. Actual Attr nodes
and their special comparison branches, ShadowRoot, CDATA and independent
cross-document ownership remain unrepresented. This is not the complete Node
interface.

## Traversal and planned work

Distinct operands undergo two complete ordinary root/depth walks before roots
are compared. Each reached parent must be a valid container and contain exactly
one reciprocal selected-child link. The endpoint at 256 edges is admitted; a
257th edge refuses. Reached local shape and canonical Document identity are
checked. A same-ID result performs those local checks but does not walk unvisited
ancestors or audit unrelated graph state.

Equal roots proceed through paid depth alignment. Divergent branches then ascend
in pairs to their common parent and scan that parent's entire child vector for
the two selected positions. The immutable borrow keeps the earlier edge checks
valid during alignment. No ancestor vector, visited bitmap, arena-global scan,
payload copy or template-host traversal is introduced. The comparison body owns
no traversal or payload allocation. Generic invocation, native-name copying,
metadata installation and error construction retain their separate allocation
charges and inherited allocator limitations.

The following are **planned successful-body work charges**, pending source and
measured validation. Let `D` be the sum of the two operand depths, `S` the sum of
all parent-vector lengths reached by both root walks, and `A` the original depth
difference. For divergent branches, `J` counts paired ascent rounds including
the final common-parent round, and `L` is that parent's child-vector length.

| Result path | Planned body work |
| --- | ---: |
| Same ID after local checks | `66` |
| Disconnected roots | `118 + 29D + 4S` |
| Ancestor or descendant | `130 + 29D + 4S + 10A` |
| Divergent branches | `143 + 29D + 4S + 10A + 20J + 6L` |

Each complete walk is planned as `24 + 29D_i + 4ΣS_i`. The selected native route
adds `60` work units and `64` charged bytes beyond the body; generic VM lookup,
invocation and diagnostics remain additional. Wide parent vectors can exhaust
the fixed work allowance at shallow depth. Admitting the depth endpoint is not
an unconditional promise that every 256-edge shape fits the allowance.
These are logical charges, not machine instruction counts, physical memory
measurements or wall-clock timings.

No quota, success-only author grant, script/event reset, worker authority or
transport format changes are selected. The existing root, connection, equality
and other predicate bodies and successful fees are regression obligations.
Whole-graph malformed-state detection and comprehensive allocator recovery are
not claimed.

## Metadata and unmeasured initialization plan

The new method is placed between `isSameNode` and `contains`. The represented
pristine prototype would have 30 keys: `isConnected`, `nodeValue`, `textContent`,
`getRootNode`, `hasChildNodes`, `normalize`, `isEqualNode`, `isSameNode`,
`compareDocumentPosition`, `contains`, the eighteen constants, `constructor`,
then `Symbol.toStringTag`. The constructor retains 21 keys.

The planned constant batch starts with eleven prototype entries, builds a
29-entry map and reserves thirty order slots for the later constructor property.
The constructor stays at three initial entries, 21 map entries and 21 order
slots. The pinned plan still admits four prototype tree nodes and three
constructor nodes. Guards, retained descriptors and native handles stay explicit;
adding the method does not waive admission or relax the owner shape.

The source-derived prediction is 693 additional initialization work units,
3,412 additional logical bytes under the previously measured type sizes, and
one additional object. It predicts 6,599 remaining raw work units, 1,768,914
charged bytes and 689 objects/capacity, with 321 native entries and 25 legacy
prototypes. **These figures are unmeasured predictions for this increment.**
They are not ABI promises, physical heap measurements, performance evidence or
security results. Actual diagnostic and source-bound snapshot updates remain
pending.

## Frozen expectations and pending validation

Sixteen independent bodies run separately in strict and sloppy modes: 32 case
expectations, plus four positive/wrong pairs in both modes: 16 controls. Genuine
successful prerequisites precede negative catches. The published connected
baseline has zero matching case modes and four healthy common controls; all
32 missing-feature cases and twelve feature-control modes report TypeError.
That is a predecessor observation, not a candidate result.

The Page and confined-worker browser sources describe one real click moving the
same branch through a detached fragment, template content, ordinary template
children and back to a visible pair. The expected visible order changes from
Alpha/Beta to Beta/Alpha. All 22 captured node identities and the arena length
must remain stable, with no click-created nodes. Saved and ordinary method
routes, reciprocal links, exact text, fixed base URL, title/status, two colored
samples and nonempty glyphs are checked. Separate script-free literal trees
specify each full canvas. Actual integration outcomes remain pending; explicit
mutations, not the comparison method itself, cause rendering changes.

Nineteen established profiles contain 4,364 case rows and 524 controls, with
4,268/504 healthy in the connected release. The prospective policy permits only
the old connected complete-inventory's two case losses and four unhealthy
controls. It requires 4,362/520 rows to remain byte-exact and all thirty older
unhealthy inventory rows to remain unchanged. Expected case failures are
Error/Error; the controls fail their old prerequisite with TypeError/TypeError.
No frozen source or raw health is rewritten. The new 30-key inventory and its
positive/wrong control pair must be healthy independently. These conditions
have not yet been observed for a position candidate.

- Final Runtime/private/browser group counts: **PENDING**.
- Exact initial/final source holds and any corrections: **PENDING**.
- Measured bootstrap and direct boundary charges: **PENDING**.
- Focused checks, full suites, Clippy and formatting: **PENDING**.
- Release binary and complete before/after comparison: **PENDING**.
- Independent result audit, including any failed reader attempts: **PENDING**.

The planned public [summary](evidence/node-position.json) and
[archive](evidence/node-position.tar.gz) will retain frozen inputs, complete
attempts, source corrections, raw rows and audit provenance after validation.
They are not available as evidence for this draft. Existing historical records
remain historical. Full web compatibility, production security, comprehensive
verification and the requested Chromium performance threshold remain unfinished.
