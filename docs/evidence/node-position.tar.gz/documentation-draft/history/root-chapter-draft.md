# Node.compareDocumentPosition

This unpublished draft describes the accepted implementation scope. Test counts,
measured costs and release results remain pending and must be filled from retained
observations before publication.

`Node.prototype.compareDocumentPosition` compares represented ordinary trees.
Its numeric result describes the argument relative to the receiver: zero for the
same node, 2 or 4 for earlier or later branches, 10 for an ancestor and 20 for a
descendant. Disconnected trees produce 35 or 37, with consistent opposite
directions for reversed operands. Document aliases share one canonical identity.
Template content belongs to a separate tree from its host and ordinary children.

The cached method has length one, an ordinary writable/enumerable/configurable
descriptor and no constructor behavior. Both operands must be authentic nodes.
The required argument is nonnullable; omitted, null and undefined arguments throw
TypeError. Receiver checks precede argument conversion, and no authored coercion
hooks or public tree properties determine the result. Extra argument expressions
finish before the method reads the current tree. Saved calls and ordinary
property shadowing, replacement and deletion retain their usual behavior.

The comparison uses constant traversal storage. Distinct nodes undergo two
complete root/depth walks, then depth alignment and a complete scan of the common
parent's selected sibling positions. Each selected parent-child edge must be
reciprocal and unique. An immutable Document borrow and absence of callbacks keep
those validated edges stable during alignment. Same-node comparisons validate
local shape and canonical identity without auditing unvisited ancestry.

Disconnected direction uses the original canonical operand IDs, which remain
stable in the append-only arena. This is an implementation choice for the current
ownership model. It is not a pointer ordering, cross-document policy or a claim
that disconnected results form a global tree order.

The existing work, heap and 256-edge traversal bounds remain. Wide reached parent
vectors can exhaust work at shallow depth. The body allocates no traversal or
payload storage; generic invocation, native-name copying and diagnostics retain
their separate costs. The previous root, connection, equality and predicate
bodies remain unchanged. No transport format, worker authority or execution reset
changes.

The [DOM algorithm](https://dom.spec.whatwg.org/#dom-node-comparedocumentposition)
also defines attribute comparisons; actual Attr nodes, ShadowRoot, CDATA and
independent document ownership remain absent. The
[Web IDL interface conversion](https://webidl.spec.whatwg.org/#es-interface)
requires authentic nonnullable Node operands.

## Validation to fill from observations

The independent source fixes sixteen strict/sloppy case bodies and four paired
controls. Its literal prototype inventory has 30 keys; the constructor retains
21. The published predecessor reports zero matching case modes and four healthy
common controls. All missing-feature cases and controls stop with TypeError.

Page and confined-worker witnesses will move one retained branch through a
detached fragment, template content, ordinary template children and back to the
visible pair. The expected result reverses Alpha/Beta order, retains 22 node IDs,
creates no click-time nodes and changes title/status and two painted samples.
Two script-free literal reference trees independently specify full-canvas pixels
and text order. Actual browser outcomes are pending.

Runtime/private tests, budget measurements, full test suites, historical release
comparison, corrections and independent result audit are pending. Full web
compatibility, production security and the Chromium performance target remain
unfinished.
