"""Package reviewed checkpoint data; run only after publication sources are ready."""
import hashlib, io, json, os, tarfile
from pathlib import Path
BASE = Path(__file__).resolve().parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def load(name):
    return json.loads((BASE / name).read_text())
source = load('candidate-source-final.json')
docs = load('documentation-ready-final.json')
for hold, directory in [(source, 'held-source-final'), (docs, 'documentation-final')]:
    for row in hold['files']:
        assert digest(ROOT / row['path']) == row['sha256'] == digest(BASE / directory / row['path'])
release = load('release.json')
assert digest(BASE / 'eris-js') == release['sha256']
assert release['source_manifest_sha256'] == digest(BASE / 'candidate-source-final.json')
assert load('independent-results-review.json')['status'] == 'clear'
summary = load('result.json')
assert summary['source'] == source and summary['release'] == release
files = []
for folder, dirs, names in os.walk(BASE):
    dirs[:] = sorted(d for d in dirs if d not in {'worktree', 'target', '__pycache__', '.git'})
    for name in sorted(names):
        path = Path(folder) / name
        if path.is_symlink():
            raise ValueError('Evidence contains symlink: ' + str(path))
        if name == 'eris-js' or (path.parent == BASE and name in {'final-publication-review.json', 'published.json'}):
            continue
        files.append(path)
rows = [dict(path=str(p.relative_to(BASE)), bytes=p.stat().st_size, sha256=digest(p)) for p in files]
assert len({r['path'] for r in rows}) == len(rows)
manifest = (json.dumps(dict(files=rows), indent=2) + '\n').encode()
archive = ROOT / 'docs/evidence/node-position.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'x:gz') as tar:
    for p in files:
        tar.add(p, arcname=str(p.relative_to(BASE)), recursive=False)
    entry = tarfile.TarInfo('archive-manifest.json')
    entry.size = len(manifest)
    tar.addfile(entry, io.BytesIO(manifest))
with tarfile.open(archive, 'r:gz') as tar:
    members = tar.getmembers()
    assert len(members) == len(rows) + 1 and all(m.isfile() for m in members)
    assert len({m.name for m in members}) == len(members)
    for row in rows:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
summary['archive'] = dict(path=archive.name, bytes=archive.stat().st_size, sha256=digest(archive), files=len(files), manifest_verified=True)
p = ROOT / 'docs/evidence/node-position.json'
with p.open('x') as stream:
    json.dump(summary, stream, indent=2)
    stream.write('\n')
print(json.dumps(summary['archive']))
