"""Source-only adaptation of the corrected ancestor; does not execute the reader."""
from pathlib import Path
import ast,difflib,json
P=Path(__file__).resolve().parent
old=(P/'inherited/connected-audit-results.py').read_text()
s=old
s=s.replace('Connected preparation derived from the retained equality audit.', 'Position preparation derived from the corrected connected audit.')
s=s.replace("BASE_BINARY = '19cb3f218ab907b9702c48e127cb9e311113b9347795a352932b05f79f8ec519'", "BASE_BINARY = 'd9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'")
s=s.replace('eris-node-connected-preparation-1','eris-node-position-preparation-1')
s=s.replace('nodeConnectedCases','nodePositionCases').replace('node_connected','node_position').replace('node-connected','node-position')
s=s.replace('connected-after.json','position-after.json').replace('connected-before.json','position-before.json').replace('connected-comparison.json','position-comparison.json')
s=s.replace('compare-connected','compare-position').replace('connected raw','position raw').replace('all connected source','all position source')
s=s.replace('connected_log','position_log')
s=s.replace('c2c1de5bbd786fd372c884087de6b7dd6407c125bf4705dc59b36be2fb99e636','e72d5ed28b6a2d5f85844221e97d4f17f450a9715b483617e405acf6bb0ee10a')
s=s.replace('9c4d02519ee3acff686609bd80047773055a4c15f135be1dfb2487ef95b1bb5f','8af1582c7dfaffcda0df53dec1d6a38b6353d860e83dd228889597947f1ca7a2')
s=s.replace('3c7ae9a513111513dad3a5ebe49b589af4319e0307e6a52784f317d95774a645','4a5bc81f3f6433d8e1d5c3c33b6a6a79f1891145d89b4dc0c49f7ab75d7d38f7')
s=s.replace('25e76612b7ff0e8f6ce0a68b5ae72399a77d27be2b745da0aad2b44ae885bc94','97855d380d9a18edbef4fd0c317ac5430265d78d07f9adeb5511542fcbb84575')
s=s.replace("'node-root.js', 'node-equality.js']", "'node-root.js', 'node-equality.js', 'node-connected.js']")
s=s.replace("inv['literal_prototype_total'] == 29 and len(inv['literal_prototype_string_keys']) == 28", "inv['literal_prototype_total'] == 30 and len(inv['literal_prototype_string_keys']) == 29")
s=s.replace("inv['literal_prototype_string_keys'][:9]", "inv['literal_prototype_string_keys'][:10]")
s=s.replace("'normalize', 'isEqualNode', 'isSameNode', 'contains']", "'normalize', 'isEqualNode', 'isSameNode', 'compareDocumentPosition', 'contains']")
# The current browser hold supplies literal source, not an inherited expected.json.
start=s.index("    expected = read(PREP / 'browser/expected.json')")
end=s.index('\n\n\ndef validation():',start)
s=s[:start]+'''    browser = read(PREP / 'browser/source-ready.json')
    require(browser['retained_ids'] == 22 and browser['phases'] == 2 and
            browser['real_clicks'] == 1 and browser['click_created_nodes'] == 0 and
            browser['worker_generation'] == 215, 'actual frozen browser inventory')
    helper = raw(PREP / 'browser/tests/support/node_position.rs').decode()
    html = raw(PREP / 'browser/tests/fixtures/node-position.html').decode()
    literal_ids = ['doc.root', 'html', 'body', 'heading', 'title', 'base', 'find("#probe")',
                   'find("#done")', 'find("#change")', 'pair', 'left', 'alpha', 'right', 'beta',
                   'result', 'status', 'template', 'content', 'inside', 'ordinary', 'parking', 'parked']
    held_ids = re.search(r'        ids: \\[\\n(.*?)        \\],', helper, re.S)
    require(held_ids is not None and
            [x.strip().rstrip(',') for x in held_ids.group(1).splitlines()] == literal_ids,
            'literal22 retained-ID fields')
    require('assert_eq!(state.ids, initial.ids);' in helper and
            'assert_eq!(state.nodes, initial.nodes, "click creates no DOM nodes");' in helper,
            'frozen no-growth/identity assertions')
    require('["Position ready", "Position done"]' in helper and
            '[0x008000, 0x0000ff][phase]' in helper and
            '<span id=left>Alpha</span><span id=right>Beta</span>' in helper and
            '<span id=right>Beta</span><span id=left>Alpha</span>' in helper and
            "phase===0?'':'fcop'" in html, 'literal browser scene and completed move trace')
    return dict(case_modes=32, control_modes=16, matrix_rows=48, explicit_literal_mode_argument=True,
                prototype_keys=30, constructor_keys=21, browser_retained_ids=22,
                historical_fixtures_unchanged='Six prior sources remain retained in the frozen replay')
'''+s[end:]
s=s.replace("'node_position_tracks_live_tree_membership'", "'node_position_tracks_reordered_ordinary_branches'").replace("'confined_node_position_tracks_live_tree_membership'", "'confined_node_position_tracks_reordered_ordinary_branches'")
# Exact actual source-only validation manifest is distinct from command receipts.
s=s.replace("    observed_labels = {p.stem for p in (B / 'validation').glob('*.json')}\n", "    setup = read('validation/source-ready.json')\n    require(INPUTS[str(B / 'validation/source-ready.json')]['sha256'] ==\n            'VALIDATION_RUNNER_SOURCE_DIGEST', 'validation runner hold')\n    for row in setup['files']:\n        bound(row)\n    observed_labels = {p.stem for p in (B / 'validation').glob('*.json') if p.name != 'source-ready.json'}\n")
import hashlib
source_ready=P.parent/'validation/source-ready.json'
s=s.replace('VALIDATION_RUNNER_SOURCE_DIGEST',hashlib.sha256(source_ready.read_bytes()).hexdigest())
# Current baseline receipt uses a bound absolute log object, unlike validation's relative log.
needle="    log = Path(path).parent / record['log']\n    data = raw(log)\n    require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)\n"
assert needle in s
s=s.replace(needle,"    if isinstance(record['log'], dict):\n        data = bound(record['log'])\n    else:\n        log = Path(path).parent / record['log']\n        data = raw(log)\n        require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)\n")
s=s.replace("read('comparison-before/release.json')", "read('comparison-preparation/before/release.json')")
start=s.index('    # This checkpoint retained separate pending-source and final-input receipts.')
end=s.index("    comparison = read('position-comparison.json')",start)
s=s[:start]+'''    # Bind the actual pending/final preparation schema and retained one-string correction.
    comparison_dir = B / 'comparison-preparation'
    pending_path = comparison_dir / 'input-manifest-correction/initial/compare-position.py'
    pending_hold = read(comparison_dir / 'source-ready-pending-inputs.json')
    for row in pending_hold['files']:
        held = {**row, 'path': str(pending_path)} if row['path'] == str(comparison_dir / 'compare-position.py') else row
        bound(held)
    for row in read(comparison_dir / 'source-ready-final.json')['files']:
        bound(row)
    correction = read(comparison_dir / 'input-manifest-correction/receipt.json')
    require(bound(correction['before']) == raw(pending_path) and
            bound(correction['after']) == raw(comparison_dir / 'compare-position.py'), 'comparator correction images')
    pending = raw(pending_path)
    marker = b"INPUT_SHA = 'PENDING_POSITION_BASELINE_AND_REPLAY_INPUT_MANIFEST'"
    manifest_sha = hashlib.sha256(raw(comparison_dir / 'compare-position-inputs.json')).hexdigest()
    require(pending.count(marker) == 1 and
            pending.replace(marker, ("INPUT_SHA = '" + manifest_sha + "'").encode()) == raw(comparison_dir / 'compare-position.py'),
            'only exact input digest substitution after pending source hold')
    root_review = read(comparison_dir / 'root-final-review.json')
    for row in root_review['bindings']:
        bound(row)
    require(len(root_review['commands']) == 2, 'both independently captured before checks')
    for helper, record in zip(['compare-position.py', 'classify-inventory.py'], root_review['commands']):
        require(record['command'] == ['python3', str(comparison_dir / helper), '--verify-before'] and
                record['exit'] == 0, 'actual before-check command')
        require(json.loads(bound(record['log']))['verified_before'] is True, 'before-check output')
        COMMANDS['comparison-preparation/root-final-review.json#' + helper] = record
    for manifest in ['compare-position-inputs.json', 'before-comparison-inputs.json']:
        for row in read(comparison_dir / manifest)['files']:
            data = bound(row)
            if 'original' in row:
                require(data == raw(row['original']), 'original copy: ' + row['path'])
'''+s[end:]
s=s.replace("require(len(comparison['profiles']) == 19", "require(len(comparison['profiles']) == 20")
s=s.replace("'node-predicates', 'node-root', 'node-equality', 'node-position'},", "'node-predicates', 'node-root', 'node-equality', 'node-connected', 'node-position'},")
s=s.replace("'node-root','node-equality','node-position'],", "'node-root','node-equality','node-connected','node-position'],")
s=s.replace("'root-after.json','equality-after.json','position-after.json']))", "'root-after.json','equality-after.json','connected-after.json','position-after.json']))")
s=s.replace("else 'comparison-before/' + filename", "else 'comparison-preparation/before/' + filename")
s=s.replace("read('anticipated-inventory-changes.json')", "read('comparison-preparation/anticipated-inventory-changes.json')")
s=s.replace("row['profile'] == 'node-equality', 'unanticipated established profile'", "row['profile'] == 'node-connected', 'unanticipated established profile'")
s=s.replace("len(policy['already_unhealthy_unchanged']) == 24", "len(policy['already_unhealthy_unchanged']) == 30")
s=s.replace("{'node-constants', 'node-normalize', 'node-predicates', 'node-root'}, 'older profile identity'", "{'node-constants', 'node-normalize', 'node-predicates', 'node-root', 'node-equality'}, 'older profile identity'")
s=s.replace("('cases', 4332, 4238, 4236, 2), ('controls', 508, 492, 488, 4)", "('cases', 4364, 4268, 4266, 2), ('controls', 524, 504, 500, 4)")
s=s.replace("B / 'anticipated-inventory-changes.json'", "B / 'comparison-preparation/anticipated-inventory-changes.json'")
s=s.replace("require(len(replay_receipts) == 19", "require(len(replay_receipts) == 20")
s=s.replace("'node-root-replay-command.json', 'node-equality-replay-command.json'}", "'node-root-replay-command.json', 'node-equality-replay-command.json', 'node-connected-replay-command.json'}")
# Root's actual baseline and before-check receipts are not inherited *-command paths.
start=s.index("    for label, code in [('connected-baseline', 1)")
end=s.index("    actual_commands = {p.name for p in B.glob('*-command.json')}",start)
s=s[:start]+'''    baseline_record, _ = command('baseline-execution.json', 1)
    require(baseline_record['command'] == ['python3', str(PREP / 'replay/replay.py'),
            str(Path(prior_release['path'])), BASE_BINARY, str(B / 'position-before.json')], 'actual baseline command')
    for row in read('replay-supervisor-ready.json')['files']:
        bound(row)
    expected_commands = {p.name for p in replay_receipts} | {p + '-command.json' for p in [
        'symbols', 'array-descriptors', 'reflect-construction', 'comparison', 'classification']}
'''+s[end:]
s=s.replace("profiles=19, complete_historical_changes", "profiles=20, complete_historical_changes")
s=s.replace("preserved_older_unhealthy_rows=24", "preserved_older_unhealthy_rows=30").replace('all19 individual job logs','all20 individual job logs')
# Existing raw record and serial parser behavior must remain byte-for-byte AST equivalent.
def functions(x):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(x).body if isinstance(n,ast.FunctionDef)}
a,b=functions(old),functions(s)
for name in ['key','inputs','healthy','complete_rows','test_rows']:assert a[name]==b[name],name
with (P/'audit-results.py').open('x') as f:f.write(s)
with (P/'reader-adaptation.diff').open('x') as f:f.write(''.join(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='connected/final-corrected-reader',tofile='position/draft-reader')))
print(json.dumps(dict(status='source-only draft authored',ast_preserved=['key','inputs','healthy','complete_rows','test_rows'],bytes=len(s.encode()),sha256=hashlib.sha256(s.encode()).hexdigest(),complete_audit=False)))
