#!/usr/bin/env python3
"""Read JSON, logs and bytes only; never import a reviewed helper or run an engine.

Position preparation derived from the corrected connected audit. Requires the final announced
release and all result files; counts come from literal test rows, including
serial nocapture status wraps. No prior SHA-specific log repair is used.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

B = Path(__file__).resolve().parent.parent
SOURCE = None  # Future announced final source manifest; never inferred from results.
BASE_BINARY = 'd9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'
PREP = Path('/tmp/eris-node-position-preparation-1')
PLAN = None
# Required independently from the eventual root release announcement; no guessed pin.
CANDIDATE = None
INPUTS = {}
COMMANDS = {}


def require(value, message):
    if not value:
        raise ValueError(message)


def raw(path):
    path = B / path
    data = path.read_bytes()
    binding = dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    require(str(path) not in INPUTS or INPUTS[str(path)] == binding, 'input changed: ' + str(path))
    INPUTS[str(path)] = binding
    return data


def read(path):
    return json.loads(raw(path))


def bound(row, prefix=B):
    data = raw(prefix / row['path'])
    require(hashlib.sha256(data).hexdigest() == row['sha256'], 'hash: ' + row['path'])
    if 'bytes' in row:
        require(len(data) == row['bytes'], 'length: ' + row['path'])
    return data


def command(path, exit_code):
    record = read(path)
    COMMANDS[path] = record
    require(record['exit'] == exit_code, 'command exit: ' + path)
    if isinstance(record['log'], dict):
        data = bound(record['log'])
    else:
        log = Path(path).parent / record['log']
        data = raw(log)
        require(hashlib.sha256(data).hexdigest() == record['sha256'], 'log hash: ' + path)
    return record, data.decode()


def test_rows(log, serial):
    """Associate a serial bare status with exactly one unfinished test header."""
    names, wraps = [], []
    pending = None
    for number, line in enumerate(log.splitlines(), 1):
        match = re.fullmatch(r'test (.+?) \.\.\. (.*)', line)
        if match:
            require(pending is None, 'new test before prior status at line ' + str(number))
            name, tail = match.groups()
            if tail in {'ok', 'FAILED', 'ignored'}:
                names.append((name, tail))
            else:
                require(serial, 'nonserial wrapped test status at line ' + str(number))
                pending = (name, number)
        elif line in {'ok', 'FAILED', 'ignored'}:
            require(pending is not None and serial, 'orphan test status at line ' + str(number))
            names.append((pending[0], line))
            wraps.append(dict(name=pending[0], header_line=pending[1], status_line=number, status=line))
            pending = None
        elif line.startswith('test result:'):
            require(pending is None, 'missing test status before summary')
    require(pending is None, 'unfinished test status')
    return names, wraps


def tests(path, exit_code, totals=None):
    record, log = command('validation/' + path + '.json', exit_code)
    summaries = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log, re.M)
    require(summaries, 'missing test summary: ' + path)
    observed = [sum(int(row[i]) for row in summaries) for i in range(3)]
    if totals is not None:
        require(observed == totals, 'test summary: ' + path)
    names, wraps = test_rows(log, '--test-threads=1' in record['command'])
    require([sum(status == status_name for _, status in names) for status_name in ['ok', 'FAILED', 'ignored']] == observed,
            'literal test rows: ' + path)
    if exit_code == 0:
        require(observed[0] > 0 and observed[1:] == [0, 0], 'successful complete test run: ' + path)
    record = {**record, 'serial_status_wraps': wraps}
    return record, names, log, observed


def frozen_inputs():
    """Rebuild source identities as data; do not import the supervisor/helpers."""
    holds = [
        ('independent/source-ready.json', 'e72d5ed28b6a2d5f85844221e97d4f17f450a9715b483617e405acf6bb0ee10a'),
        ('browser/source-ready.json', '8af1582c7dfaffcda0df53dec1d6a38b6353d860e83dd228889597947f1ca7a2'),
        ('replay/source-ready.json', '4a5bc81f3f6433d8e1d5c3c33b6a6a79f1891145d89b4dc0c49f7ab75d7d38f7'),
    ]
    for name, digest in holds:
        data = raw(PREP / name)
        require(hashlib.sha256(data).hexdigest() == digest, 'frozen preparation hold: ' + name)
        for row in json.loads(data)['files']:
            bound(row, PREP / Path(name).parent)
    fixture = raw(PREP / 'independent/cases.js')
    require(hashlib.sha256(fixture).hexdigest() ==
            '97855d380d9a18edbef4fd0c317ac5430265d78d07f9adeb5511542fcbb84575', 'exact independent fixture')
    require(fixture == raw('worktree/tests/fixtures/node-position.js'), 'integrated JS fixture unchanged')
    for name in ['node-constants.js', 'node-normalize.js', 'node-predicates.js', 'node-root.js', 'node-equality.js', 'node-connected.js']:
        require(raw(PREP / 'replay/history' / name) == raw('worktree/tests/fixtures/' + name),
                'historical JS fixture unchanged: ' + name)
    inv = read(PREP / 'independent/inventory.json')
    require(inv['collection'] == 'nodePositionCases' and len(inv['cases']) == 16, 'independent case population')
    require(inv['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True}, 'literal mode contract')
    require(inv['literal_prototype_total'] == 30 and len(inv['literal_prototype_string_keys']) == 29 and
            inv['literal_prototype_string_keys'][:10] == [
                'isConnected', 'nodeValue', 'textContent', 'getRootNode', 'hasChildNodes',
                'normalize', 'isEqualNode', 'isSameNode', 'compareDocumentPosition', 'contains'] and
            inv['literal_prototype_string_keys'][-1] == 'constructor' and
            inv['literal_prototype_final_symbol'] == 'Symbol.toStringTag' and
            len(inv['literal_constructor_keys']) == 21, 'current represented metadata oracle')
    replay = PREP / 'replay'
    inputs_json = read(replay / 'replay-inputs.json')
    matrix = read(replay / 'replay-matrix.json')
    require(inputs_json['fixture_sha256'] == hashlib.sha256(fixture).hexdigest() and
            inputs_json['collection'] == inv['collection'] and
            inputs_json['case_invocation_argument_by_mode'] == inv['case_invocation_argument_by_mode'],
            'replay invocation/fixture identity')
    require([r['name'] for r in inputs_json['cases']] == inv['cases'], 'ordered case identities')
    require(inputs_json['controls'] == read(PREP / 'independent/controls.json')['controls'], 'unchanged controls')
    complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
    wrong = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
    metadata = dict(flags=[], features=[], includes=[], locale=[], negative=None)
    identities = []
    positive_sources = {r['name']: r for r in inputs_json['controls'] if r['positive']}
    for kind, rows in [('case', inputs_json['cases']), ('control', inputs_json['controls'])]:
        for row in rows:
            require(row['modes'] == ['sloppy', 'strict'], 'frozen modes')
            require(row['expected_observation'] == (complete if kind == 'case' or row['positive'] else wrong),
                    'ordinary/wrong expected observation')
            if kind == 'control':
                positive = positive_sources[row['pair'] + '-positive']
                require(positive['area'] == row['area'] and row['source'] == positive['source'] +
                        ('' if row['positive'] else "throw new Error('deliberately wrong expectation');"),
                        'exact positive prefix and wrong tail')
            for mode in row['modes']:
                body = (fixture + b'\nif(nodePositionCases.' + row['name'].encode() +
                        (b'(true)' if mode == 'strict' else b'(false)') +
                        b' !== true) throw new Error("case did not return true");'
                        if kind == 'case' else row['source'].encode())
                source_sha = hashlib.sha256(body).hexdigest()
                fingerprint = dict(source_sha256=source_sha, mode=mode, metadata=metadata, harness=[])
                case_sha = hashlib.sha256(json.dumps(fingerprint, sort_keys=True, ensure_ascii=True).encode()).hexdigest()
                identity = dict(id=row['name'] + '#' + mode, mode=mode, kind=kind,
                                source_sha256=source_sha, case_sha256=case_sha,
                                expected_observation=row['expected_observation'])
                if kind == 'control':
                    identity.update(pair=row['pair'], positive=row['positive'], area=row['area'],
                                    partner=row['pair'] + '-positive#' + mode)
                identities.append(identity)
    require(len(identities) == 48 and identities == matrix['rows'], 'independent complete matrix reconstruction')
    for row in matrix['bound_inputs']:
        bound(row)
    require(matrix['bounds'] == dict(timeout_seconds=3, stdout_limit=96 * 1024,
                                    stderr_limit=64 * 1024, execution='sequential inherited run_case'), 'inherited runner bounds')
    for field, path in [('fixture_sha256', replay / 'independent/cases.js'),
                        ('inventory_sha256', replay / 'replay-inputs.json'),
                        ('replay_sha256', replay / 'replay.py'),
                        ('runner_sha256', replay / 'tools/test262_conformance.py')]:
        require(matrix[field] == hashlib.sha256(raw(path)).hexdigest(), 'matrix header binding: ' + field)
    for name in ['node-position.html', 'node_position.rs']:
        relative = 'tests/fixtures/' + name if name.endswith('.html') else 'tests/support/' + name
        require(raw(PREP / 'browser' / relative) == raw('worktree/' + relative), 'browser source unchanged: ' + name)
    browser = read(PREP / 'browser/source-ready.json')
    require(browser['retained_ids'] == 22 and browser['phases'] == 2 and
            browser['real_clicks'] == 1 and browser['click_created_nodes'] == 0 and
            browser['worker_generation'] == 215, 'actual frozen browser inventory')
    helper = raw(PREP / 'browser/tests/support/node_position.rs').decode()
    html = raw(PREP / 'browser/tests/fixtures/node-position.html').decode()
    literal_ids = ['doc.root', 'html', 'body', 'heading', 'title', 'base', 'find("#probe")',
                   'find("#done")', 'find("#change")', 'pair', 'left', 'alpha', 'right', 'beta',
                   'result', 'status', 'template', 'content', 'inside', 'ordinary', 'parking', 'parked']
    held_ids = re.search(r'        ids: \[\n(.*?)        \],', helper, re.S)
    require(held_ids is not None and
            [x.strip().rstrip(',') for x in held_ids.group(1).splitlines()] == literal_ids,
            'literal22 retained-ID fields')
    require('assert_eq!(state.ids, initial.ids);' in helper and
            'assert_eq!(state.nodes, initial.nodes, "click creates no DOM nodes");' in helper,
            'frozen no-growth/identity assertions')
    require('["Position ready", "Position done"]' in helper and
            '[0x008000, 0x0000ff][phase]' in helper and
            '<span id=left>Alpha</span><span id=right>Beta</span>' in helper and
            '<span id=right>Beta</span><span id=left>Alpha</span>' in helper and
            "phase===0?'':'fcop'" in html, 'literal browser scene and completed move trace')
    return dict(case_modes=32, control_modes=16, matrix_rows=48, explicit_literal_mode_argument=True,
                prototype_keys=30, constructor_keys=21, browser_retained_ids=22,
                historical_fixtures_unchanged='Six prior sources remain retained in the frozen replay')



def validation():
    """Use a separately frozen plan filled only after actual source/logs exist."""
    required = ['source_population', 'initial_population', 'runtime_inventory', 'runtime_tests',
                'focused_labels', 'new_focused_label', 'full_runs', 'gates',
                'retained_failure_runs', 'measured_correction', 'bootstrap_diagnostic']
    require(all(PLAN.get(k) is not None for k in required), 'validation plan has unmeasured pending fields')
    source = read('candidate-source-final.json')
    require(INPUTS[str(B / 'candidate-source-final.json')]['sha256'] == SOURCE, 'final source identity')
    require(len(source['files']) == PLAN['source_population'], 'final source population')
    current = {r['path']: r for r in source['files']}
    require(len(current) == len(source['files']), 'unique final source paths')
    for row in source['files']:
        bound(row, B / 'worktree')
        bound(row, B / 'held-source-final')
    initial = read('candidate-source-initial.json')
    old = {r['path']: r for r in initial['files']}
    require(len(old) == len(initial['files']) == PLAN['initial_population'], 'initial source population')
    for row in initial['files']:
        bound(row, B / 'held-source-initial')
    corrections = PLAN['measured_correction']
    changed = set()
    for spec in corrections:
        receipt = read(spec['receipt'])
        require(INPUTS[str(B / spec['receipt'])]['sha256'] == spec['sha256'], 'correction receipt binding')
        require(len(receipt['files']) == spec['file_count'] and
                sum(len(r['changes']) for r in receipt['files']) == spec['literal_count'], 'exact correction population')
        for row in receipt['files']:
            require(row['path'] not in changed, 'repeated correction path requires explicit staged review')
            require(row['path'] not in old or row['before_sha256'] == old[row['path']]['sha256'],
                    'existing correction before image must match initial source manifest')
            changed.add(row['path'])
            data = raw(Path(spec['before_directory']) / row['path'])
            require(hashlib.sha256(data).hexdigest() == row['before_sha256'], 'original corrected file')
            for change in row['changes']:
                before, after = change['before'].encode(), change['after'].encode()
                require(data.count(before) == 1, 'unique exact correction')
                data = data.replace(before, after)
            require(hashlib.sha256(data).hexdigest() == row['after_sha256'] == current[row['path']]['sha256'] and
                    data == raw('worktree/' + row['path']), 'exact final correction')
    require(current.keys() == old.keys() | changed, 'only enumerated correction paths added')
    require(all(current[p] == row for p, row in old.items() if p not in changed), 'unreported initial source drift')
    inventory = json.loads(bound(PLAN['runtime_inventory']))
    direct = re.findall(r'^#\[test\]\nfn ([A-Za-z_][A-Za-z0-9_]*)\(',
                        raw('worktree/' + PLAN['runtime_tests']).decode(), re.M)
    require(direct == inventory['direct_groups'], 'actual private Rust test names including digits')
    require(len(inventory['independent_groups']) == 16 and inventory['independent_modes'] == 32 and
            inventory['direct_count'] == len(direct) and
            inventory['new_runtime_groups'] == len(direct) + 16 and
            inventory['root_browser_groups_separate'] == 2 and
            inventory['new_groups_including_root_browser'] == inventory['new_runtime_groups'] + 2,
            'actual Runtime inventory population')
    focus = Counter(); focused_commands = {}; wraps = {}
    position_log = None
    for label in PLAN['focused_labels']:
        rec, rows, log, observed = tests(label, 0)
        require('--include-ignored' in rec['command'], 'focused include ignored: ' + label)
        if label == PLAN['new_focused_label']:
            expected_runtime = {'script::node_position::tests::' + n for n in inventory['independent_groups'] + direct}
            expected_browser = {'node_position_tracks_reordered_ordinary_branches',
                                'confined_node_position_tracks_reordered_ordinary_branches'}
            require({n for n, _ in rows} == expected_runtime | expected_browser and
                    observed == [inventory['new_runtime_groups'] + 2, 0, 0], 'actual Runtime plus two browser witnesses')
            position_log = log
        focus.update(n for n, _ in rows)
        focused_commands[label] = dict(command=rec['command'], totals=observed, test_names=[n for n, _ in rows])
        if rec['serial_status_wraps']:
            wraps[label] = rec['serial_status_wraps']
    require(position_log is not None, 'new focused run is present')
    receipt = read('focused-validation-review.json')
    require(receipt['successful_observations'] == sum(focus.values()) and
            receipt['successful_unique_test_names'] == len(focus) and
            len(receipt['commands']) == len(focused_commands), 'independently counted focus inventory')
    for row in receipt['commands']:
        got = focused_commands[row['label']]
        require(row['passed'] == got['totals'][0] and row['test_names'] == got['test_names'], 'focus literal names')
        require(row['log_sha256'] == INPUTS[str(B / 'validation' / (row['label'] + '.log'))]['sha256'] and
                row['receipt_sha256'] == INPUTS[str(B / 'validation' / (row['label'] + '.json'))]['sha256'], 'focus bindings')
    failures = []
    for spec in PLAN['retained_failure_runs']:
        rec, rows, log, observed = tests(spec['label'], spec['exit'], spec['totals'])
        require(spec['exit'] != 0 and [n for n, status in rows if status == 'FAILED'] == spec['failed_names'],
                'complete retained failure identities')
        failures.append(dict(label=spec['label'], command=rec['command'], totals=observed,
                             failed_names=spec['failed_names'], log_sha256=rec['sha256']))
        if rec['serial_status_wraps']:
            wraps[spec['label']] = rec['serial_status_wraps']
    require(receipt['all_attempt_passing_observations'] == sum(focus.values()) + sum(r['totals'][0] for r in failures) and
            receipt['all_attempt_failures'] == sum(r['totals'][1] for r in failures), 'all attempt failures retained')
    diagnostic = PLAN['bootstrap_diagnostic']
    require(diagnostic['literal'] in position_log, 'actual bootstrap literal from independently announced result')
    for label in diagnostic['other_logs']:
        require(diagnostic['literal'] in raw('validation/' + label + '.log').decode(), 'bootstrap second observation')
    gates = {}
    for label in PLAN['gates']:
        rec, _ = command('validation/' + label + '.json', 0)
        if label.startswith('clippy'):
            require(rec['command'][-2:] == ['-D', 'warnings'] and '--all-targets' in rec['command'], 'strict Clippy')
        if label.startswith('release'):
            require('--release' in rec['command'] and '--bin' in rec['command'] and 'eris-js' in rec['command'], 'release build')
        gates[label] = rec['command']
    full = {}
    for spec in PLAN['full_runs']:
        rec, _, _, observed = tests(spec['label'], 0, [spec['passed'], 0, 0])
        argv = rec['command']
        require('--include-ignored' in argv and '--test-threads=4' in argv, 'full command flags')
        if spec['feature']:
            require('--features' in argv and spec['feature'] in argv, 'native feature')
        else:
            require('--features' not in argv, 'default feature')
        full[spec['label']] = dict(command=argv, totals=observed)
    require(len(full) == 2 and {r['feature'] for r in PLAN['full_runs']} == {None, 'vulkan-raster'}, 'both full suites')
    permitted = set(PLAN['focused_labels'] + PLAN['gates'] + list(full) + [r['label'] for r in failures])
    setup = read('validation/source-ready.json')
    require(INPUTS[str(B / 'validation/source-ready.json')]['sha256'] ==
            '93cb769d809fcddc05855a801d93a4413c455a5e8e196ae51b66bbdf48a24ff9', 'validation runner hold')
    for row in setup['files']:
        bound(row)
    observed_labels = {p.stem for p in (B / 'validation').glob('*.json') if p.name != 'source-ready.json'}
    require(observed_labels == permitted, 'unreviewed validation attempts: ' + repr(observed_labels ^ permitted))
    return dict(full=full, new_groups=inventory['new_runtime_groups'] + 2,
                focused_observations=sum(focus.values()), focused_unique=len(focus),
                focused_commands=focused_commands, successful_gates=gates,
                retained_failure_runs=failures, bootstrap_diagnostic=diagnostic,
                serial_status_wraps=wraps, source_manifest_sha256=SOURCE)


OUTCOMES = {'status', 'observation', 'reason', 'stderr', 'matches_expectation', 'matches_implementation_policy',
            'verified', 'verified_with_protocol_prerequisite', 'positive_partner_matches'}


def key(row):
    row = row.get('result', row)
    return row['id'], row.get('mode', '')


def inputs(row):
    if 'result' in row:
        return {**{k: v for k, v in row.items() if k not in {'result', 'verified'}}, 'result': inputs(row['result'])}
    return {k: v for k, v in row.items() if k not in OUTCOMES}


def healthy(row):
    if 'result' in row:
        return row.get('verified') is True and row['result'].get('status') == row['expected']
    if 'expected_observation' not in row:
        return row.get('status') == 'passed'
    observation = row.get('observation', {})
    return (isinstance(observation, dict) and all(observation.get(k) == v for k, v in row['expected_observation'].items())
            and row.get('matches_expectation') is True and row.get('verified', True) is True
            and row.get('verified_with_protocol_prerequisite', True) is True)


def complete_rows(before, after):
    old, new = {key(r): r for r in before}, {key(r): r for r in after}
    require(len(old) == len(before) and len(new) == len(after) and old.keys() == new.keys(), 'row identity/population')
    result = dict(before_total=len(before), after_total=len(after), before_healthy=sum(map(healthy, before)),
                  after_healthy=sum(map(healthy, after)), unchanged=0, gains=0, losses=0, other_changes=0)
    changes = []
    for identity, a in old.items():
        b = new[identity]
        require(inputs(a) == inputs(b), 'row inputs changed: ' + repr(identity))
        if a == b:
            result['unchanged'] += 1
            continue
        category = 'gains' if not healthy(a) and healthy(b) else 'losses' if healthy(a) and not healthy(b) else 'other_changes'
        result[category] += 1
        changes.append(dict(id=identity[0], mode=identity[1], classification=category, before=a, after=b))
    return result, changes


def comparisons():
    prior_release = read('comparison-preparation/before/release.json')
    require(prior_release['sha256'] == BASE_BINARY, 'baseline release binding')
    bound(prior_release)
    release = read('release.json')
    require(release['sha256'] == CANDIDATE and release['bytes'] > 0 and release['source_manifest_sha256'] == SOURCE, 'release binding')
    bound(release)
    require(release['source_manifest'] == 'candidate-source-final.json' and release['build_receipt'] == 'validation/release-adapter-188-1.json', 'release source/build')
    # Bind the actual pending/final preparation schema and retained one-string correction.
    comparison_dir = B / 'comparison-preparation'
    pending_path = comparison_dir / 'input-manifest-correction/initial/compare-position.py'
    pending_hold = read(comparison_dir / 'source-ready-pending-inputs.json')
    for row in pending_hold['files']:
        held = {**row, 'path': str(pending_path)} if row['path'] == str(comparison_dir / 'compare-position.py') else row
        bound(held)
    for row in read(comparison_dir / 'source-ready-final.json')['files']:
        bound(row)
    correction = read(comparison_dir / 'input-manifest-correction/receipt.json')
    require(bound(correction['before']) == raw(pending_path) and
            bound(correction['after']) == raw(comparison_dir / 'compare-position.py'), 'comparator correction images')
    pending = raw(pending_path)
    marker = b"INPUT_SHA = 'PENDING_POSITION_BASELINE_AND_REPLAY_INPUT_MANIFEST'"
    manifest_sha = hashlib.sha256(raw(comparison_dir / 'compare-position-inputs.json')).hexdigest()
    require(pending.count(marker) == 1 and
            pending.replace(marker, ("INPUT_SHA = '" + manifest_sha + "'").encode()) == raw(comparison_dir / 'compare-position.py'),
            'only exact input digest substitution after pending source hold')
    root_review = read(comparison_dir / 'root-final-review.json')
    for row in root_review['bindings']:
        bound(row)
    require(len(root_review['commands']) == 2, 'both independently captured before checks')
    for helper, record in zip(['compare-position.py', 'classify-inventory.py'], root_review['commands']):
        require(record['command'] == ['python3', str(comparison_dir / helper), '--verify-before'] and
                record['exit'] == 0, 'actual before-check command')
        require(json.loads(bound(record['log']))['verified_before'] is True, 'before-check output')
        COMMANDS['comparison-preparation/root-final-review.json#' + helper] = record
    for manifest in ['compare-position-inputs.json', 'before-comparison-inputs.json']:
        for row in read(comparison_dir / manifest)['files']:
            data = bound(row)
            if 'original' in row:
                require(data == raw(row['original']), 'original copy: ' + row['path'])
    comparison = read('position-comparison.json')
    require(not comparison['validation_failures'] and comparison['candidate']['sha256'] == CANDIDATE, 'comparison status')
    require(bound(comparison['comparator']) == raw(comparison_dir / 'compare-position.py') and
            bound(comparison['input_manifest']) == raw(comparison_dir / 'compare-position-inputs.json'),
            'comparison helper and final manifest cross-binding')
    require(len(comparison['profiles']) == 20, 'profile count')
    require({p['profile'] for p in comparison['profiles']} == {
        'dom-method-identity', 'object-is', 'symbols', 'array-descriptors', 'reflect-construction',
        'prior-CharacterData', 'prior-PI', 'prior-production', 'node-original', 'node-exact',
        'append-exact', 'document-title', 'node-constants', 'text-operations', 'node-normalize',
        'node-predicates', 'node-root', 'node-equality', 'node-connected', 'node-position'}, 'exact profile identities')
    profile_files = dict(zip(
        ['dom-method-identity','object-is','symbols','array-descriptors','reflect-construction',
         'prior-CharacterData','prior-PI','prior-production','node-original','node-exact','append-exact',
         'document-title','node-constants','text-operations','node-normalize','node-predicates','node-root','node-equality','node-connected','node-position'],
        ['dom-method-identity-after.json','object-is-after.json','symbols-after.json','array-descriptors-after.json',
         'reflect-construction-after.json','local-after.json','pi-regression-after.json','production-after.json',
         'original-after.json','exact-after.json','append-after.json','title-after.json','node-constants-after.json',
         'text-after.json','normalize-after.json','predicates-after.json','root-after.json','equality-after.json','connected-after.json','position-after.json']))
    totals = {'established': {'cases': Counter(), 'controls': Counter()}, 'new': {'cases': Counter(), 'controls': Counter()}}
    all_changes = []; reports = {}
    for profile in comparison['profiles']:
        filename = profile_files[profile['profile']]
        before_file = 'position-before.json' if profile['profile'] == 'node-position' else 'comparison-preparation/before/' + filename
        require(profile['group'] == ('new' if profile['profile'] == 'node-position' else 'established'), 'profile group')
        require(raw(before_file) == bound(profile['before']) and raw(filename) == bound(profile['after']), 'canonical profile report cross-binding')
        a = json.loads(bound(profile['before'])); b = json.loads(bound(profile['after']))
        require(a['binary_sha256'] == BASE_BINARY and b['binary_sha256'] == CANDIDATE, 'raw binary binding')
        require(not b.get('binding_failures'), 'raw binding failure')
        require(not profile['header_input_changes'], 'header drift')
        for header in set(a) | set(b):
            if (header.endswith('_sha256') and header != 'binary_sha256') or header in {'bounds', 'harness', 'tool_hashes', 'revision', 'runner_policy', 'mode_cases', 'bound_inputs'}:
                require(a.get(header) == b.get(header), 'raw input header: ' + header)
        reports[profile['profile']] = (a, b)
        for kind in ['cases', 'controls']:
            left = a[kind] if kind in a else a.get('harness_preflight', [])
            right = b[kind] if kind in b else b.get('harness_preflight', [])
            stats, changes = complete_rows(left, right)
            actual = profile[kind]
            unwrap = lambda row: row.get('result', row)
            require(actual['before_status_counts'] == dict(Counter(unwrap(r).get('status') for r in left)) and
                    actual['after_status_counts'] == dict(Counter(unwrap(r).get('status') for r in right)), 'raw status counts')
            require(all(actual[k] == v for k, v in stats.items()) and actual['changes'] == changes, 'complete-row reconstruction')
            require(not actual['added'] and not actual['removed'] and not actual['input_changes'], 'raw population drift')
            totals[profile['group']][kind].update(stats)
            all_changes.extend(dict(profile=profile['profile'], kind=kind, **r) for r in changes)
    require(totals == comparison['summary'], 'summary reconstructed from complete raw rows')
    policy = read('comparison-preparation/anticipated-inventory-changes.json')
    expected = {(r['kind'], r['id'], r['mode']): r for r in policy['rows']}
    historical = [r for r in all_changes if r['profile'] != 'node-position']
    require(len(historical) == 6, 'exact historical change count')
    for row in historical:
        require(row['profile'] == 'node-connected', 'unanticipated established profile')
        expected_row = expected.pop((row['kind'], row['id'], row['mode']))
        require(row['classification'] == 'losses' and row['before'] == expected_row['before'], 'historical identity/health')
        after = row['after']
        require(after['status'] == 'failed' and after['matches_expectation'] is False, 'retained raw failure')
        require(all(after['observation'].get(k) == v for k, v in expected_row['expected_after_observation'].items()), 'Error versus TypeError')
        if row['kind'] == 'controls':
            require(after['verified'] is False and after['positive_partner_matches'] is False, 'no control-health waiver')
    require(not expected, 'all expected historical changes reached')
    require(len(policy['already_unhealthy_unchanged']) == 30, 'older unhealthy population')
    for row in policy['already_unhealthy_unchanged']:
        require(row['profile'] in {'node-constants', 'node-normalize', 'node-predicates', 'node-root', 'node-equality'}, 'older profile identity')
        old_before, old_after = reports[row['profile']]
        wanted = row['before']
        require([r for r in old_before[row['kind']] if key(r) == key(wanted)] == [wanted], 'older before binding')
        require([r for r in old_after[row['kind']] if key(r) == key(wanted)] == [wanted] and not healthy(wanted), 'older unhealthy row changed')
    new_before, new_after = reports['node-position']
    frozen = read(PREP / 'replay/replay-matrix.json')
    frozen_rows = {r['id']: r for r in frozen['rows']}
    matrix_sha = INPUTS[str(PREP / 'replay/replay-matrix.json')]['sha256']
    for report in [new_before, new_after]:
        require(report['matrix_sha256'] == matrix_sha and report['bound_inputs'] == frozen['bound_inputs'],
                'position raw report frozen input/matrix binding')
        for header in ['fixture_sha256', 'inventory_sha256', 'replay_sha256', 'runner_sha256', 'bounds']:
            require(report[header] == frozen[header], 'position raw header: ' + header)
        rows = report['cases'] + report['controls']
        require(len(rows) == 48 and len({r['id'] for r in rows}) == 48 and
                {r['id'] for r in rows} == frozen_rows.keys(), 'all position source identities retained')
        for row in rows:
            identity = frozen_rows[row['id']]
            require({k: row[k] for k in identity} == identity, 'raw row literal-mode source binding')
    require([sum(map(healthy, r[k])) for r in [new_before, new_after] for k in ['cases', 'controls']] == [0, 4, 32, 16], 'new ordinary and paired control health')
    current_profile = next(p for p in comparison['profiles'] if p['profile'] == 'node-position')
    require(raw('position-after.json') == bound(current_profile['after']), 'current oracle raw report cross-binding')
    require(new_after['binary_sha256'] == CANDIDATE, 'current oracle candidate cross-binding')
    for kind, count, before_health, after_health, losses in [
        ('cases', 4364, 4268, 4266, 2), ('controls', 524, 504, 500, 4)]:
        stats = totals['established'][kind]
        require(stats['before_total'] == stats['after_total'] == count, 'established population')
        require(stats['before_healthy'] == before_health and stats['after_healthy'] == after_health, 'raw established health')
        require(stats['unchanged'] == count-losses and stats['losses'] == losses and
                stats['gains'] == stats['other_changes'] == 0, 'only exact established losses')
    for kind, count, before_health in [('cases', 32, 0), ('controls', 16, 4)]:
        stats = totals['new'][kind]
        require(stats['before_total'] == stats['after_total'] == stats['after_healthy'] == count,
                'new complete population')
        require(stats['before_healthy'] == before_health and stats['gains'] == count-before_health and
                stats['unchanged'] == before_health and stats['losses'] == stats['other_changes'] == 0,
                'new exact gains and unchanged controls')
    for report in [new_before, new_after]:
        controls = {r['id']: r for r in report['controls']}
        for row in report['controls']:
            partner = controls[row['partner']]
            require(partner['positive'] is True and partner['mode'] == row['mode'] and
                    partner['pair'] == row['pair'], 'same-mode positive partner')
            def observation_matches(r):
                observation = r.get('observation', {})
                return isinstance(observation, dict) and all(observation.get(k) == v for k, v in r['expected_observation'].items())
            matches = observation_matches(row)
            partner_matches = observation_matches(partner)
            require(row['matches_expectation'] is matches and row['positive_partner_matches'] is partner_matches,
                    'independent raw control matches')
            require(row['verified'] is (matches and partner_matches), 'independent paired control health')
    for mode in ['sloppy', 'strict']:
        case = next(r for r in new_after['cases'] if r['id'] == 'represented_complete_key_order#' + mode)
        require(healthy(case), 'current pristine inventory')
        for variant in ['positive', 'wrong']:
            control = next(r for r in new_after['controls'] if r['id'] == 'represented-node-order-' + variant + '#' + mode)
            require(healthy(control) and control['positive_partner_matches'] is True, 'current reflected-order pair')
    annotation = read('inventory-classification.json')
    require(annotation['comparison_sha256'] == INPUTS[str(B / 'position-comparison.json')]['sha256'], 'annotation comparison binding')
    require(annotation['policy_sha256'] == INPUTS[str(B / 'comparison-preparation/anticipated-inventory-changes.json')]['sha256'], 'annotation policy binding')
    require(annotation['expected_case_losses'] == 2 and annotation['expected_unhealthy_controls'] == 4 and annotation['unexpected_established_changes'] == 0, 'annotation totals')
    require(annotation['classifier_sha256'] == hashlib.sha256(raw(comparison_dir / 'classify-inventory.py')).hexdigest(),
            'annotation classifier source binding')
    aggregate = read('replay-execution.json')
    require(aggregate['exit'] == 1 and aggregate['command'] == ['python3', str(B / 'replay-jobs.py')], 'root-observed aggregate exit')
    COMMANDS['replay-execution.json'] = aggregate
    for label, expected_exit in [('comparison', 0), ('classification', 0)]:
        command(label + '-command.json', expected_exit)
    replay_receipts = sorted(B.glob('*-replay-command.json'))
    require(len(replay_receipts) == 20, 'replay command population')
    for path in replay_receipts:
        command(path.name, 1 if path.name in {'node-constants-replay-command.json', 'node-normalize-replay-command.json', 'node-predicates-replay-command.json', 'node-root-replay-command.json', 'node-equality-replay-command.json', 'node-connected-replay-command.json'} else 0)
    for profile in ['symbols', 'array-descriptors', 'reflect-construction']:
        command(profile + '-command.json', 0)
    baseline_record, _ = command('baseline-execution.json', 1)
    require(baseline_record['command'] == ['python3', str(PREP / 'replay/replay.py'),
            str(Path(prior_release['path'])), BASE_BINARY, str(B / 'position-before.json')], 'actual baseline command')
    for row in read('replay-supervisor-ready.json')['files']:
        bound(row)
    expected_commands = {p.name for p in replay_receipts} | {p + '-command.json' for p in [
        'symbols', 'array-descriptors', 'reflect-construction', 'comparison', 'classification']}
    actual_commands = {p.name for p in B.glob('*-command.json')}
    require(actual_commands == expected_commands, 'unreviewed command receipt inventory: ' + repr(actual_commands ^ expected_commands))
    return dict(summary=comparison['summary'], profiles=20, complete_historical_changes=historical,
                preserved_older_unhealthy_rows=30, aggregate_exit=1, comparison_exit=0, classifier_exit=0,
                release_sha256=CANDIDATE, aggregate_receipt='replay-execution.json',
                aggregate_capture_limit='Root-observed aggregate exit is retained; complete stdout/stderr hashes belong to all20 individual job logs, not an invented aggregate log.')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--binary-sha256', required=True, help='Actual announced release SHA256; no engine is run.')
    parser.add_argument('--source-sha256', required=True, help='Actual announced final source manifest SHA256.')
    parser.add_argument('--validation-plan', type=Path, required=True)
    parser.add_argument('--validation-plan-sha256', required=True)
    args = parser.parse_args()
    global CANDIDATE, SOURCE, PLAN
    require(re.fullmatch(r'[0-9a-f]{64}', args.binary_sha256), 'invalid release SHA256')
    CANDIDATE = args.binary_sha256
    require(re.fullmatch(r'[0-9a-f]{64}', args.source_sha256), 'invalid source SHA256')
    SOURCE = args.source_sha256
    require(not args.output.exists(), 'audit output must be new')
    report = dict(status='incomplete', findings=[], execution='Only byte/JSON/log parsing; no engine, compiler, helper import or subprocess.')
    try:
        raw(Path(__file__))
        plan_bytes = raw(args.validation_plan.resolve())
        require(hashlib.sha256(plan_bytes).hexdigest() == args.validation_plan_sha256, 'validation plan binding')
        PLAN = json.loads(plan_bytes)
        require(PLAN['status'] == 'final announced results ready for independent audit', 'validation remains explicitly pending')
        report['frozen_inputs'] = frozen_inputs()
        report['validation'] = validation()
        report['comparison'] = comparisons()
        for path, expected in list(INPUTS.items()):
            data = Path(path).read_bytes()
            require(dict(bytes=len(data), sha256=hashlib.sha256(data).hexdigest()) == expected, 'post-audit input drift: ' + path)
        report['status'] = 'clear'
    except Exception as error:
        report['status'] = 'failed'
        report['findings'].append(dict(type=type(error).__name__, message=str(error)))
    report['commands'] = COMMANDS
    report['nonzero_commands'] = {p: r for p, r in COMMANDS.items() if r['exit'] != 0}
    report['inputs'] = [{'path': path, **binding} for path, binding in sorted(INPUTS.items())]
    with args.output.open('x') as stream:
        json.dump(report, stream, indent=2)
        stream.write('\n')
    print(json.dumps({k: v for k, v in report.items() if k not in {'inputs', 'comparison', 'commands'}}, indent=2))
    return 0 if report['status'] == 'clear' else 1


if __name__ == '__main__':
    raise SystemExit(main())
