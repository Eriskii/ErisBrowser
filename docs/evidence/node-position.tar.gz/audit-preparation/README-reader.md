# Held position audit reader

This reader adapts the byte-exact corrected connected ancestor retained in
`inherited/`. It has not run a complete audit. Thirteen inert tests execute only
isolated pure Python row-health and serial-log functions; all five inherited
function ASTs remain identical. A final audit still requires root authorization,
complete results, an announced source manifest and release digest, and a separately
hash-bound plan whose status declares actual final results ready.

The actual Runtime inventory now uses `independent_groups`, `direct_groups`,
`direct_count`, `new_runtime_groups`, `root_browser_groups_separate` and
`new_groups_including_root_browser`. The current held source contains sixteen
independent groups, seventeen direct groups and two separate browser groups.
The reader extracts all direct Rust names including digits, checks the inventory
fields and compares the exact successful new-filter test population. It does not
turn predicted full-suite totals into observed results.

`validation-plan.concrete-pending.json` binds the real Runtime inventory and
initial19 source population, and lists authored runner labels: nine focused
filters, five gates (initial compile, format, two strict Clippy, release), and two
full suites supplied separately after results exist. All still-unmeasured fields
remain null. Runtime/private total is33; new filter total35. Final source counts,
all full/focused observations, corrections, failed attempts and measured diagnostic
must come from actual records in the final plan. No failed run can be omitted:
validation JSON inventory must exactly equal declared command receipts plus the
one hash-pinned source-readiness manifest. Other JSON schemas fail closed until
explicitly reviewed; there is no broad non-command exemption.

The schema-specific source changes are explicit. The current baseline receipt is
`baseline-execution.json`, with a bound absolute log object. Ordinary validation
and replay command receipts retain their relative-log/string schema. Existing
comparison inputs are under `comparison-preparation/`; there is no invented
inherited generic manifest. The reader checks the original pending hold by mapping
its one obsolete comparator image to the retained exact before copy. It then
checks the final hold, actual103-file manifest, root's captured two before checks,
and exact one-sentinel replacement. Independent raw reconstruction still compares
all input/header fields, complete rows, raw statuses and paired control health.

Twenty profiles comprise nineteen established histories and new position. Exactly
two connected complete-inventory cases must newly fail with Error and four controls
must remain unhealthy TypeError, with all thirty older unhealthy inventory rows
unchanged. Counts4364/524, initial health4268/504, exact4362/520 and resulting
health4266/500 are fixed policy. All32 new case modes and16 controls must be
healthy, with four unchanged common controls. The actual frozen matrix and every
new baseline/candidate source fingerprint are reconstructed using literal
false/true invocation. No supervisor is imported. Six historical fixtures remain
exact. Browser sources bind the held22 IDs, no click growth, literal fcop trace,
Alpha/Beta order, title/status and color references; this data check is not a
renderer execution or a replacement for the two integration tests.

All current historical replay locations and failure codes remain fixed. The six
historical inventory job receipts must retain exit1, as must the aggregate;
comparison and classification must exit0. Root's eventual command schemas must
match the source-held runner plan and this reader; unexpected receipt paths are
not silently ignored. Source/binary/report files are rehashed after reading, and
any reader failure is retained in a fresh exclusive output with reached input and
command bindings. Root must preserve the initial failed report and source before
any later correction and rerun.

`draft-history/` retains the first unheld adaptation and its refinement against
the newly available Runtime inventory. The independent comparison schema and
baseline were known before that draft; no candidate result was used to change
ordinary fixture expectations. Initial staging manifests and the documentation
drafts remain intact. The adapted source must receive peer review before complete
execution; no compiler, engine, JS parser or complete reader ran here.
