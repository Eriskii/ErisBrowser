# Position result auditor staging

This is an initial source-only stage, not a runnable final position auditor or
an executed result audit. The corrected connected reader is preserved verbatim
as `inherited/connected-audit-results.py` (SHA-256 `ce38a7a098919601579d78f52c14ba76d6eff943f988630e791ede1c4065ca0f`).
Its original pure-helper check script, final hold, and correction receipts are
retained for provenance. Do not execute that inherited reader here: its connected
paths deliberately remain historical.

`adaptation-plan.json` enumerates concrete known schema changes; `source-inputs.json`
binds current artifacts. The future reader must preserve the four complete-row
identity/input/health functions and serial test-log parser, including duplicate,
missing and drifting row refusal, raw failure retention, absent observation
rejection and same-mode positive partner verification. The earlier correction
requiring every existing file's before image to match its initial source hold
must remain. Its prior manifest/schema failures are not justification for
waiving checks or inventing current artifact paths.

Known current inputs include the actual source-ready-pending-inputs and
source-ready-final manifests under `comparison-preparation/`, their preserved
pending comparator, one-sentinel correction, final 103-file input manifest,
19 exact historical reports, actual baseline and frozen 48-row replay matrix.
The new comparator/classifier both passed only their data-only before checks.
No candidate results exist in this preparation. The expected historical
population is 4,364/524 with baseline health 4,268/504, exactly six prospective
connected-inventory losses, and 30 older unhealthy rows preserved. Current
success requires 32/16 new expectations. Those future conditions are not results.

The future fixture check reconstructs each exact source fingerprint with the
literal false/true mode argument and checks all baseline/candidate raw rows,
headers and paired controls against that frozen matrix. Its literal inventory
is now 30 prototype keys and 21 constructor keys, with six unchanged prior
fixtures. The root-authored browser hold has 22 retained IDs, two phases, no
click node creation and generation 215. The auditor must bind the actual scene
sources and integration tests; it does not render or invent a canvas proof.

`validation-plan.pending.json` deliberately leaves all actual source counts,
Runtime groups, successful/failed attempts, full totals, diagnostics, corrections
and release fields null. Root is still preparing implementation and validation.
The first compile, position filter, eight older focused families and broad gates
will be inventoried from their actual retained command receipts; their names and
outcomes must not be guessed. A validation source-readiness JSON is not itself
a command or test attempt. Once concrete Runtime/test inventory and root receipt
schemas are available, author and independently review the adapted reader,
preserve this stage, and run only inert pure-function checks. A complete audit
requires root's explicit authorization after all logs, release and replay are
complete, announced source/release pins, a hash-bound final plan and a fresh
exclusive output path. All failed audit attempts must remain intact.

No JavaScript parser, engine, compiler, candidate adapter, complete auditor or
reviewed replay/helper import has run in this stage. Published connected base is
`53859161acf081bac70ee4c0e0daf000abe9088b`; actual baseline release is
`d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715`.
The original replay path remains `/tmp/eris-node-position-preparation-1/replay/replay.py`.
