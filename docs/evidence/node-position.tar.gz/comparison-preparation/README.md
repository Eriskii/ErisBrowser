# Position comparison preparation

This data-only preparation uses published connected commit
`53859161acf081bac70ee4c0e0daf000abe9088b` and release
`d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715`.
It contains nineteen exact prior raw reports and four exact provenance files in
`before/`. No old expectation, source fingerprint, observation, verification
flag, stderr or unknown row field is rewritten. The twenty published production
source Git objects were checked against the predecessor's final manifest.

The retained reports actually contain 4,364 cases and 524 controls, with 4,268
healthy cases and 504 healthy controls. The anticipated policy permits only the
connected `represented_complete_key_order` sloppy/strict case losses and its
`represented-node-order-positive`/`represented-node-order-wrong` controls in both
modes. Cases must become runtime Error/Error failures, controls runtime
TypeError/TypeError failures with false match/partner/verified flags. All six
complete before rows are copied from the report. Thirty earlier unhealthy
inventory rows are bound separately from their actual current observations.
They and every other established row must stay exact.

Consequently the selected prospective outcome is 4,362 exact case rows and 520
exact control rows, with 4,266/500 healthy. The new position profile must gain all
32 case expectations and 12 controls from its future bound 0/4 baseline; the four
common controls remain exact, giving 32/16 healthy. These are acceptance rules,
not candidate observations. The new pristine 30-key inventory and both positive
and wrong controls must be healthy in both modes. The classifier cross-binds the
raw new report hash to the comparison and its binary hash to the actual candidate.
Raw historical exit failures and control health are retained, never waived.

`compare-position.py` is the connected complete-row reader adapted for one more
established profile and one new profile. Nine helper function ASTs are identical.
The tenth (`verify_before`) differs only in its before-manifest filesystem path;
reversing that one string makes its AST identical. Other changed functions are
path/identity changes in `before_path`, output identity in `compare`, and output
filename in `main`. The source and unified differences are retained. The row
health, input projection, duplicate rejection, complete raw comparison,
post-read checks and failure retention are unchanged.

All helpers stay at this directory. Their artifact root is the parent directory:
new baseline/candidate reports are `../position-before.json` and
`../position-after.json`; old copies and policy stay here. The eventual output
paths are `../position-comparison.json` and `../inventory-classification.json`.
The classifier may now run only with `--verify-before`, which reads existing
policy and historical JSON. Neither executable imports or invokes an engine.

The full comparator intentionally cannot run yet. Its `INPUT_SHA` is the explicit
`PENDING_POSITION_BASELINE_AND_REPLAY_INPUT_MANIFEST` sentinel. The pending JSON
lists known history and required missing inputs. After root's actual baseline
and replay hold are ready, create `compare-position-inputs.json` here with exact
root-relative binding rows for the baseline/commands/logs, replay sources,
matrix/history/readiness/verification/reviews, independent fixture/control
holds, scope/base and this history/policy. Preserve the pending helper and
readiness, replace its sentinel with that final manifest's actual SHA once, and
bind the exact one-string difference additively. Run and retain both
`--verify-before` commands before candidate replay. No digest or baseline outcome
has been guessed, and no check should be relaxed to make a missing binding pass.

`prepare-comparison.py` was run only for exclusive data copying, JSON counts,
source AST comparisons and published Git-object hashes. No candidate report,
JavaScript parser, compiler, adapter, engine or replay runner was run. Later
additive final-input holds must be read alongside this original readiness, not
mistaken for a nonexistent generic comparison manifest.
