"""Freeze published report copies and data-only comparison sources, exclusively."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

OUT=Path(__file__).resolve().parent
ROOT=OUT.parent
OLD=Path('/tmp/eris-node-connected-1')
PREP=Path('/tmp/eris-node-position-preparation-1')
BASE='53859161acf081bac70ee4c0e0daf000abe9088b'
RELEASE='d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'
PENDING='PENDING_POSITION_BASELINE_AND_REPLAY_INPUT_MANIFEST'
def sha(b):return hashlib.sha256(b).hexdigest()
def row(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,b):
 with p.open('xb') as f:f.write(b)
def jsave(p,v):write(p,(json.dumps(v,indent=2)+'\n').encode())
def controls(r):return r.get('controls',r.get('harness_preflight',[]))
def health(r):
 if 'result' in r:return r.get('verified') is True and r['result'].get('status')==r['expected']
 if 'expected_observation' in r:
  o=r.get('observation',{});return isinstance(o,dict) and all(o.get(k)==v for k,v in r['expected_observation'].items()) and r.get('matches_expectation') is True and r.get('verified',True) is True and r.get('verified_with_protocol_prerequisite',True) is True
 return r.get('status')=='passed'
def identity(r):
 r=r.get('result',r);return r['id'],r.get('mode','')
old_comparator=(OLD/'compare-connected.py').read_text()
old_tree=ast.parse(old_comparator)
specs=next(ast.literal_eval(x.value) for x in old_tree.body if isinstance(x,ast.Assign) and any(isinstance(n,ast.Name) and n.id=='SPECS' for n in x.targets))
assert len(specs)==19 and specs[-1]==('node-connected','connected-after.json',32,16,'new')
(OUT/'before').mkdir()
(OUT/'originals').mkdir()
files=[];reports={};totals=Counter()
for profile,filename,ncase,nctrl,_ in specs:
 original=OLD/filename;data=original.read_bytes();report=json.loads(data)
 assert report['binary_sha256']==RELEASE and not report.get('binding_failures')
 assert len(report['cases'])==ncase and len(controls(report))==nctrl
 assert len({identity(x) for x in report['cases']})==ncase
 assert len({identity(x) for x in controls(report)})==nctrl
 destination=OUT/'before'/filename;write(destination,data)
 files.append(dict(path=str(destination.relative_to(ROOT)),original=str(original),bytes=len(data),sha256=sha(data)))
 reports[profile]=report
 totals.update(cases=ncase,controls=nctrl,healthy_cases=sum(map(health,report['cases'])),healthy_controls=sum(map(health,controls(report))))
assert dict(totals)==dict(cases=4364,controls=524,healthy_cases=4268,healthy_controls=504)
for filename in ['release.json','candidate-source-final.json','connected-comparison.json','inventory-classification.json']:
 original=OLD/filename;data=original.read_bytes();destination=OUT/'before'/filename;write(destination,data)
 files.append(dict(path=str(destination.relative_to(ROOT)),original=str(original),bytes=len(data),sha256=sha(data)))
source=json.loads((OLD/'candidate-source-final.json').read_text())
repo=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
assert len(source['files'])==20
for entry in source['files']:
 data=subprocess.run(['git','show',BASE+':'+entry['path']],cwd=repo,stdout=subprocess.PIPE,check=True).stdout
 assert len(data)==entry['bytes'] and sha(data)==entry['sha256']
jsave(OUT/'before-comparison-inputs.json',dict(base=BASE,release_sha256=RELEASE,files=files,established_cases=totals['cases'],established_controls=totals['controls'],healthy_cases=totals['healthy_cases'],healthy_controls=totals['healthy_controls'],source_manifest=dict(path='comparison-preparation/before/candidate-source-final.json',historical_manifest_base=source['base'],public_base=BASE,all20_public_source_paths_verified=True),note='Exact published connected reports; historical source identities, failed observations and raw statuses remain unchanged. This file binds19 established profiles plus4 provenance files.'))
old_policy=json.loads((OLD/'anticipated-inventory-changes.json').read_text())
current=reports['node-connected'];new_rows=[]
for kind,ids in [('cases',['represented_complete_key_order#sloppy','represented_complete_key_order#strict']),('controls',['represented-node-order-positive#sloppy','represented-node-order-positive#strict','represented-node-order-wrong#sloppy','represented-node-order-wrong#strict'])]:
 for ident in ids:
  matches=[x for x in current[kind] if x['id']==ident];assert len(matches)==1
  before=matches[0];assert health(before)
  new_rows.append(dict(kind=kind,id=ident,mode=before['mode'],before=before,expected_after_observation=dict(status='exception',phase='runtime',error_type='Error' if kind=='cases' else 'TypeError',error_identity='Error' if kind=='cases' else 'TypeError')))
older=[]
for previous in old_policy['already_unhealthy_unchanged']:
 actual=[x for x in reports[previous['profile']][previous['kind']] if identity(x)==(previous['id'],previous['mode'])]
 assert actual==[previous['before']] and not health(actual[0])
 older.append(previous)
for previous in old_policy['rows']:
 actual=[x for x in reports[old_policy['profile']][previous['kind']] if identity(x)==(previous['id'],previous['mode'])]
 assert len(actual)==1 and not health(actual[0])
 assert all(actual[0]['observation'].get(k)==v for k,v in previous['expected_after_observation'].items())
 older.append(dict(profile=old_policy['profile'],filename='equality-after.json',kind=previous['kind'],id=previous['id'],mode=previous['mode'],before=actual[0]))
assert len(older)==30 and len(new_rows)==6
policy=dict(profile='node-connected',reason='New ordinary compareDocumentPosition invalidates the former complete29-key inventory. Frozen sources and expectations retain raw health; annotate only exact anticipated losses.',rows=new_rows,already_unhealthy_unchanged=older)
jsave(OUT/'anticipated-inventory-changes.json',policy)
policy_hash=sha((OUT/'anticipated-inventory-changes.json').read_bytes())
comparator=old_comparator.replace("HERE = Path(__file__).resolve().parent", "HERE = Path(__file__).resolve().parent.parent")
comparator=comparator.replace("INPUTS = HERE / 'compare-connected-inputs.json'", "INPUTS = HERE / 'comparison-preparation/compare-position-inputs.json'")
comparator=comparator.replace("INPUT_SHA = 'a7bc3f087d6c655a03cc1bcdec3e8da9174d2430d097e102e1d6009d5454c730'", "INPUT_SHA = '"+PENDING+"'")
comparator=comparator.replace("('node-connected', 'connected-after.json', 32, 16, 'new'),", "('node-connected', 'connected-after.json', 32, 16, 'established'),\n    ('node-position', 'position-after.json', 32, 16, 'new'),")
comparator=comparator.replace("if name == 'node-connected':", "if name == 'node-position':")
comparator=comparator.replace("HERE / 'comparison-before' / after", "HERE / 'comparison-preparation/before' / after")
comparator=comparator.replace("HERE / 'before-comparison-inputs.json'", "HERE / 'comparison-preparation/before-comparison-inputs.json'")
comparator=comparator.replace('complete-node-connected-replay-comparison','complete-node-position-replay-comparison').replace("HERE / 'connected-comparison.json'", "HERE / 'position-comparison.json'")
write(OUT/'compare-position.py',comparator.encode())
old_classifier=(OLD/'classify-inventory.py').read_text()
classifier=old_classifier.replace("B=Path(__file__).resolve().parent", "B=Path(__file__).resolve().parent.parent")
classifier=classifier.replace("P=B/'anticipated-inventory-changes.json'", "P=B/'comparison-preparation/anticipated-inventory-changes.json'")
classifier=classifier.replace("EXPECTED='67979b370e114f11d200fde2e1d2d4e2dc0c6851518570d3efcd27fb564ee798'", "EXPECTED='"+policy_hash+"'")
classifier=classifier.replace("comparison-before/equality-after.json", "comparison-preparation/before/connected-after.json").replace("B/'comparison-before'/", "B/'comparison-preparation/before'/")
classifier=classifier.replace("len(policy['already_unhealthy_unchanged'])==24", "len(policy['already_unhealthy_unchanged'])==30")
classifier=classifier.replace("B/'connected-comparison.json'", "B/'position-comparison.json'")
classifier=classifier.replace("['node-constants','node-normalize','node-predicates','node-root']", "['node-constants','node-normalize','node-predicates','node-root','node-equality']")
classifier=classifier.replace("('cases',4238,4236),('controls',492,488)", "('cases',4268,4266),('controls',504,500)")
classifier=classifier.replace("('cases',4332,2),('controls',508,4)", "('cases',4364,2),('controls',524,4)")
classifier=classifier.replace("B/'connected-after.json'", "B/'position-after.json'").replace("x['profile']=='node-connected'", "x['profile']=='node-position'")
classifier=classifier.replace('Six equality inventory assumptions are invalidated by isConnected. Older Nodeconstant, Normalize, Predicate and root inventory failures remain unchanged.', 'Six connected inventory assumptions are invalidated by compareDocumentPosition. Older Nodeconstant, Normalize, Predicate, root and equality inventory failures remain unchanged.')
write(OUT/'classify-inventory.py',classifier.encode())
write(OUT/'originals/compare-connected.py',old_comparator.encode())
write(OUT/'originals/classify-inventory.py',old_classifier.encode())
write(OUT/'originals/anticipated-inventory-changes.json',(OLD/'anticipated-inventory-changes.json').read_bytes())
for name,a,b in [('comparator',old_comparator,comparator),('classifier',old_classifier,classifier)]:
 write(OUT/(name+'.diff'),''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='connected/'+name,tofile='position/'+name)).encode())
def funcs(src):return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(src).body if isinstance(n,ast.FunctionDef)}
f0=funcs(old_comparator);f1=funcs(comparator)
unchanged=[k for k in f0 if f0[k]==f1[k]]
assert unchanged==['sha','read','require','underlying','identity','input_record','healthy','compare_rows','controls']
assert sorted(k for k in f0 if f0[k]!=f1[k])==['before_path','compare','main','verify_before']
# verify_before differs solely in the manifest's filesystem location.
old_verify=next(n for n in old_tree.body if isinstance(n,ast.FunctionDef) and n.name=='verify_before')
new_verify=next(n for n in ast.parse(comparator).body if isinstance(n,ast.FunctionDef) and n.name=='verify_before')
for node in ast.walk(new_verify):
 if isinstance(node,ast.Constant) and node.value=='comparison-preparation/before-comparison-inputs.json':node.value='before-comparison-inputs.json'
assert ast.dump(old_verify,include_attributes=False)==ast.dump(new_verify,include_attributes=False)
ast.parse(classifier)
jsave(OUT/'inert-verification.json',dict(status='passed source/JSON/hash checks; no candidate report or comparator execution',counts=dict(totals),established_profiles=19,future_profiles=20,exact_report_copies=19,provenance_copies=4,anticipated_new_case_losses=2,anticipated_new_unhealthy_controls=4,older_unhealthy_inventory_rows=30,identical_comparator_function_asts=unchanged,verify_before_ast='Identical after reversing only the before-manifest relative path literal',future_exact_rows=dict(cases=4362,controls=520),future_healthy_counts=dict(cases=4266,controls=500),new_expected=dict(cases=32,controls=16),files=[row(OUT/x) for x in ['compare-position.py','classify-inventory.py','anticipated-inventory-changes.json','before-comparison-inputs.json']],execution=dict(python_ast=True,json_hash_arithmetic=True,comparator_import_or_run=False,classifier_import_or_run=False,js_parser=False,engine=False,compiler=False)))
config=dict(status='Pending position baseline and replay input bindings; not runnable final manifest',base=BASE,baseline_release_sha256=RELEASE,established_cases=4364,established_controls=524,new_cases=32,new_controls=16,files=[dict(path=str((OUT/x).relative_to(ROOT)),bytes=(OUT/x).stat().st_size,sha256=sha((OUT/x).read_bytes())) for x in ['before-comparison-inputs.json','anticipated-inventory-changes.json']],pending=['Actual position-before.json and baseline command/log/binding review','Frozen new replay readiness/driver/input matrix/history/verify and source reviews','Current independent source/controls/readiness and root base binding','Final manifest SHA substituted once into held comparator with original retained'])
jsave(OUT/'compare-position-inputs-pending.json',config)
print(json.dumps(dict(status='held pending final input manifest',totals=dict(totals),new_policy_rows=len(new_rows),old_policy_rows=len(older),comparator=row(OUT/'compare-position.py'),classifier=row(OUT/'classify-inventory.py'),policy=row(OUT/'anticipated-inventory-changes.json'))))
