"""Bind actual baseline/replay inputs and replace exactly one pending digest."""
import hashlib,json
from pathlib import Path

P=Path(__file__).resolve().parent
ROOT=P.parent
REPLAY=Path('/tmp/eris-node-position-preparation-1/replay')
SCOPE=REPLAY.parent
TOKEN='PENDING_POSITION_BASELINE_AND_REPLAY_INPUT_MANIFEST'
def sha(b):return hashlib.sha256(b).hexdigest()
def record(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,b):
 with p.open('xb') as f:f.write(b)
def save(p,v):write(p,(json.dumps(v,indent=2)+'\n').encode())
# Preserve the held pending helper and every directly bound preparation file;
# the large exact historical copies remain in place and their manifest is retained.
original=P/'input-manifest-correction'/'initial';original.mkdir(parents=True)
old_hold=P/'source-ready-pending-inputs.json'
write(original/old_hold.name,old_hold.read_bytes())
for name in ['compare-position.py','classify-inventory.py','anticipated-inventory-changes.json','before-comparison-inputs.json','compare-position-inputs-pending.json','README.md','inert-verification.json','classifier-verify-before.log']:
 write(original/name,(P/name).read_bytes())
old=(P/'compare-position.py').read_bytes();assert old.count(TOKEN.encode())==1
assert sha(old)=='319d08653e2a7c233b37743bfdad16fef2de9cb1b398b1fa255934bc6d12e774'
before=json.loads((ROOT/'position-before.json').read_text());matrix=json.loads((REPLAY/'replay-matrix.json').read_text())
assert before['binary_sha256']=='d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'
assert not before['binding_failures']
assert len(before['cases'])==32 and len(before['controls'])==16
assert sum(r['matches_expectation'] is True for r in before['cases'])==0
assert sum(r['verified'] is True for r in before['controls'])==4
assert sha((ROOT/'position-before.json').read_bytes())=='94150a0e78e7d84089c0f3cd6b8201068ad59481be72b7589dad5b1de6a300a8'
assert before['matrix_sha256']==sha((REPLAY/'replay-matrix.json').read_bytes())
for k in ['fixture_sha256','inventory_sha256','replay_sha256','runner_sha256','bounds','bound_inputs']:assert before[k]==matrix[k]
actual={r['id']:r for r in before['cases']+before['controls']}
for identity in matrix['rows']:
 r=actual[identity['id']];assert all(r[k]==v for k,v in identity.items())
paths=[ROOT/x for x in ['base.json','run-baseline.py','baseline-execution.json','baseline-review.json','baseline.log','position-before.json']]
paths += [P/x for x in ['before-comparison-inputs.json','anticipated-inventory-changes.json']]
paths += [REPLAY/x for x in ['source-ready.json','replay.py','replay-inputs.json','replay-matrix.json','preparation-history.json','driver-transformation.json','inert-verification.json','html-source-review.json']]
paths += [SCOPE/'root/replay-source-review.json',SCOPE/'root/independent-source-review.json',SCOPE/'root/published-base.json']
ready=json.loads((REPLAY/'source-ready.json').read_text())
paths += [Path(r['path']) for r in ready['files']]
paths += [Path(r['path']) for r in matrix['bound_inputs']]
unique=list(dict.fromkeys(paths))
files=[]
for path in unique:
 b=path.read_bytes()
 try:name=str(path.relative_to(ROOT))
 except ValueError:name=str(path)
 files.append(dict(path=name,bytes=len(b),sha256=sha(b)))
config=dict(base='53859161acf081bac70ee4c0e0daf000abe9088b',baseline_release_sha256=before['binary_sha256'],established_cases=4364,established_controls=524,new_cases=32,new_controls=16,files=files,note='All paths are actual artifact-relative paths or fixed absolute preparation input paths. Original replay execution location remains immutable; no generic inherited manifest is assumed.')
save(P/'compare-position-inputs.json',config)
new_hash=sha((P/'compare-position-inputs.json').read_bytes())
new=old.replace(TOKEN.encode(),new_hash.encode());assert new.replace(new_hash.encode(),TOKEN.encode())==old
(P/'compare-position.py').write_bytes(new)
receipt=dict(status='Exact one-sentinel comparator correction after actual published baseline; no comparison/health logic changed',before=record(original/'compare-position.py'),after=record(P/'compare-position.py'),original_hold=record(original/'source-ready-pending-inputs.json'),input_manifest=record(P/'compare-position-inputs.json'),substitution=dict(before=TOKEN,after=new_hash),reverse_byte_exact=True,binding_files=len(files),baseline=record(ROOT/'position-before.json'),baseline_counts=dict(cases=32,case_matches=0,controls=16,healthy_controls=4),execution=dict(engine=False,compiler=False,js_parser=False,comparator_run=False))
save(P/'input-manifest-correction/receipt.json',receipt)
print(json.dumps(dict(comparator=record(P/'compare-position.py'),manifest=record(P/'compare-position-inputs.json'),receipt=record(P/'input-manifest-correction/receipt.json'),binding_files=len(files))))
