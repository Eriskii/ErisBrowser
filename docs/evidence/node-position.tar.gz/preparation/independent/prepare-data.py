"""Data-only authoring: literal controls and inventory; no JS parser or engine."""
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
error = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
tail = "throw new Error('deliberately wrong expectation');"
constants = ['ELEMENT_NODE','ATTRIBUTE_NODE','TEXT_NODE','CDATA_SECTION_NODE','ENTITY_REFERENCE_NODE','ENTITY_NODE','PROCESSING_INSTRUCTION_NODE','COMMENT_NODE','DOCUMENT_NODE','DOCUMENT_TYPE_NODE','DOCUMENT_FRAGMENT_NODE','NOTATION_NODE','DOCUMENT_POSITION_DISCONNECTED','DOCUMENT_POSITION_PRECEDING','DOCUMENT_POSITION_FOLLOWING','DOCUMENT_POSITION_CONTAINS','DOCUMENT_POSITION_CONTAINED_BY','DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC']
strings = ['isConnected','nodeValue','textContent','getRootNode','hasChildNodes','normalize','isEqualNode','isSameNode','compareDocumentPosition','contains'] + constants + ['constructor']
constructor = ['length','name','prototype'] + constants
guard = "if(typeof Node!=='function'||typeof Text!=='function'||typeof DocumentFragment!=='function')throw new TypeError('constructors');var d=Object.getOwnPropertyDescriptor(Node.prototype,'compareDocumentPosition');if(!d||typeof d.value!=='function')throw new TypeError('position method');var cmp=d.value,a=new Text('a'),b=new Text('b'),f=new DocumentFragment();f.append(a,b);if(cmp.call(a,a)!==0||cmp.call(a,b)!==4||cmp.call(b,a)!==2||cmp.call(f,a)!==20||cmp.call(a,f)!==10)throw new TypeError('genuine identity order ancestry');"
pairs = [
 ('literal-units','common',r"var value='A\uD800',tail='\uDC00';if(value.length!==2||value.charCodeAt(0)!==65||value.charCodeAt(1)!==55296||tail.length!==1||tail.charCodeAt(0)!==56320)throw new TypeError('exact literal units');"),
 ('authentic-required-position','feature',guard+"if(d.writable!==true||d.enumerable!==true||d.configurable!==true||cmp.name!=='compareDocumentPosition'||cmp.length!==1)throw new TypeError('method metadata');var count=0,poison={};Object.defineProperty(poison,'toString',{get:function(){count++;throw new Error('hook');}});var caught=0;try{cmp.call(a);}catch(e){if(e instanceof TypeError)caught++;}try{cmp.call(a,null);}catch(e){if(e instanceof TypeError)caught++;}try{cmp.call(a,undefined);}catch(e){if(e instanceof TypeError)caught++;}try{cmp.call(a,poison);}catch(e){if(e instanceof TypeError)caught++;}try{cmp.call(Object.create(Node.prototype),a);}catch(e){if(e instanceof TypeError)caught++;}if(caught!==5||count!==0||cmp.call(a,b)!==4)throw new TypeError('required nonnullable authentic operands');"),
 ('fresh-order-and-disconnected','feature',guard+"f.append(a);if(f.firstChild!==b||f.childNodes[1]!==a||cmp.call(a,b)!==2||cmp.call(b,a)!==4)throw new TypeError('fresh order after same-node move');var other=new DocumentFragment(),ab=cmp.call(a,other),ba=cmp.call(other,a);if(!((ab===35&&ba===37)||(ab===37&&ba===35))||cmp.call(a,other)!==ab)throw new TypeError('portable disconnected directions');var t=document.createElement('template'),inside=new Text('inside');if(!t.content||t.content.nodeType!==11)throw new TypeError('template content');t.content.append(inside);t.append(a);var ai=cmp.call(a,inside),ia=cmp.call(inside,a);if(cmp.call(t,a)!==20||cmp.call(a,t)!==10||!((ai===35&&ia===37)||(ai===37&&ia===35)))throw new TypeError('separate ordinary roots');"),
 ('represented-node-order','feature',guard+"var strings="+json.dumps(strings,separators=(',',':'))+",keys=Reflect.ownKeys(Node.prototype);if(strings.length!==29||keys.length!==30||keys[29]!==Symbol.toStringTag)throw new TypeError('prototype count');for(var i=0;i<29;i++)if(keys[i]!==strings[i])throw new TypeError('prototype order');var expected="+json.dumps(constructor,separators=(',',':'))+",actual=Reflect.ownKeys(Node);if(actual.length!==21)throw new TypeError('constructor count');for(var j=0;j<21;j++)if(actual[j]!==expected[j])throw new TypeError('constructor order');")
]
controls=[]
for name,area,source in pairs:
    for positive in [True,False]:
        code=source if positive else source+tail
        controls.append(dict(name=name+('-positive' if positive else '-wrong'),pair=name,positive=positive,area=area,modes=['sloppy','strict'],source=code,source_sha256=sha(code),expected_observation=complete if positive else error))
source=(OUT/'cases.js').read_text()
names=re.findall(r'^  ([a-z][a-z0-9_]+): function\(\)',source,re.M)
assert len(names)==len(set(names))==16
assert source.count('    return true;')==16
assert len(strings)==len(set(strings))==29 and len(constructor)==21
assert strings[7:10]==['isSameNode','compareDocumentPosition','contains']
assert '\\uD800' in source and '\\\\uD800' not in source
for positive,negative in zip(controls[::2],controls[1::2]):
    assert negative['source']==positive['source']+tail
    assert positive['pair']==negative['pair']
    assert sha(positive['source'])==positive['source_sha256']
    assert sha(negative['source'])==negative['source_sha256']
assert controls[0]['source_sha256']=='b57c612c3b715e0fe435b5b32ed7ae7533bf0b471570027c68d7eda84b61de7d'
inventory=dict(collection='nodePositionCases',fixture_filename='node-position.js',proposed_repository_path='tests/fixtures/node-position.js',execution='Load exact cases.js and invoke one named body in a fresh ordinary Runtime/Document: name(false) for sloppy and name(true) for strict, using literal mode metadata; never aggregate. Position bodies ignore this argument.',case_count=16,case_modes=32,control_modes=16,cases=names,ordinary_expectation=complete,ordinary_return=True,literal_prototype_string_keys=strings,literal_prototype_final_symbol='Symbol.toStringTag',literal_prototype_total=30,literal_constructor_keys=constructor,published_base='53859161acf081bac70ee4c0e0daf000abe9088b',published_release_sha256='d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715',case_invocation_argument_by_mode={'sloppy':False,'strict':True},literal_related_masks={'same_identity':0,'other_preceding_branch':2,'other_following_branch':4,'other_ancestor':10,'other_descendant':20},portable_disconnected_masks=[35,37],disconnected_policy='Require opposite reversal, repeated-call stability and stable directions for unchanged operands remaining disconnected across moves; do not infer a specific allowed direction from allocation IDs.',conditional_history=dict(new_connected_inventory_case_modes=2,new_connected_inventory_controls=4,older_unhealthy_rows=30,condition='Expected if this method is added in selected position; preserve all prior frozen sources and raw rows. This is not an executed position result.'),private_only=['Empty Document, authentic Document-parent Text and represented Doctype from separate host setup','Selected original-ID direction for disconnected operands and same canonical Document aliases','Depth256/257, wide sibling scans and work/heap refusal with immutable DOM','Malformed IDs/kinds/backlinks/duplicate membership/cycles and fast self policy'],unsupported=['Attr and its owner/attribute-order branches','ShadowRoot and shadow-including relations','CDATA, cross-document ownership, live Range and MutationObserver surfaces'])
control_data=dict(status='Fixed source-only proposals; unexecuted and unparsed',negative_health='Exact runtime Error/Error tail requires successful same-mode positive partner; prerequisite failures throw TypeError; absent observations cannot pass.',pairs=4,control_modes=16,controls=controls)
for filename,data in [('controls.json',control_data),('inventory.json',inventory)]:
    with (OUT/filename).open('x') as stream:
        json.dump(data,stream,indent=2)
        stream.write('\n')
print(json.dumps(dict(ordinary_cases=16,ordinary_modes=32,control_pairs=4,control_modes=16,source_bytes=len(source.encode()),source_sha256=sha(source),prototype_keys=30,constructor_keys=21,engine=False,fixture_parser=False)))
