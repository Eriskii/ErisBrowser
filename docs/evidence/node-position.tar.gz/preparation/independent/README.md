# Independent ordinary Node position expectations

These sources are held before any position implementation, JavaScript parser,
compiler or engine execution. They describe the selected represented ordinary
Node scope, not all DOM position branches or a successful candidate. The cases
began while connected was locally validated but unpublished. Before this first
hold, connected published as `53859161acf081bac70ee4c0e0daf000abe9088b`, with
release SHA-256 `d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715`.
The root's original anticipatory scope is unchanged; its additive
`root/published-base.json` binds the actual predecessor. Current public CI is
not claimed here.

## Invocation and fixed expectations

`cases.js` defines `nodePositionCases` with sixteen named bodies. Load the exact
file and invoke one body in a fresh ordinary Runtime/Document per mode. Keep the
established explicit mode contract: `nodePositionCases.name(false)` for sloppy
source and `nodePositionCases.name(true)` for source with the strict directive
prepended. These bodies ignore that Boolean argument. It is not inferred from
engine observations, and all bodies must return literal `true`. Do not execute
all bodies in one shared realm: prototype deletion, shadows, retained nodes and
ordinary mutations are intentionally local to one body.

All thirty-two ordinary rows require `complete/runtime` with empty error type
and identity. A parser refusal, missing observation, resource refusal, unexpected
exception or unsupported prerequisite is not ordinary success. No run or quota
feasibility is asserted. Each body first requires a saved genuine method to
produce literal identity, ancestor and sibling results; negative TypeError
catches therefore cannot pass merely because the method is absent.

`controls.json` has four positive/wrong pairs, each in both modes: sixteen rows.
The common exact UTF-16 literal pair is byte-identical to the prior frozen
control. Three independently authored feature pairs require (1) a working
method, metadata and nonnullable authentic operands, (2) fresh sibling order and
separate ordinary/template roots with allowed disconnected directions, and
(3) the current literal prototype/constructor inventory. Every wrong source is
its exact positive source followed by `throw new Error('deliberately wrong
expectation');`. A negative observation is healthy only with the successful
same-mode positive partner and exact runtime `Error/Error`. Prerequisite failures
use `TypeError`; missing methods or incidental exceptions cannot make these
wrong tails healthy. The supervisor must retain raw rows and partner health
separately rather than waive historical failed controls.

## Literal oracles

The method describes the other node relative to its receiver. Expected related
masks are authored literals: same node `0`; other preceding sibling/branch `2`;
other following sibling/branch `4`; other ancestor `10`; other descendant `20`.
They are not generated from existing Node constant values or candidate output.
The existing six constants are also checked separately as `1,2,4,8,16,32`.

Disconnected comparisons accept exactly `35` or `37`, require the opposite mask
on reversal, and require repeat stability for the same operands. One case moves
an existing operand between unrelated ordinary roots while it remains
disconnected, without choosing either direction as the portable expected value.
The selected private original-Node-ID tie-break is intentionally absent from
these literal public oracles. Private Runtime tests may check that policy;
allocation IDs must not supply expected ordinary fixture results.

The cases cover preorder across branches created in a different order;
reordering existing siblings; unequal-depth ancestors; canonical Document
aliases; retained detached fragments; ordinary template children versus actual
`template.content`; scalar and lone-unit Text/Comment/PI payloads; represented
HTML/SVG/MathML elements; payload, attribute and visibility independence;
no duck typing or coercion; receiver/argument/extra-expression effects and a
throwing expression's completed mutation prefix; public-field poisoning;
cached native descriptors; saved calls through own shadows and prototype
replacement/deletion/restoration; and authentic alternate-prototype Text
construction. `Reflect.construct(Text, ...)` is proved successful before the
nonconstructible-method negative. No unavailable sibling properties,
`removeChild`, `createElementNS` or arbitrary document constructor is required.

The method takes a required **nonnullable** `Node` argument. Missing, null,
undefined, primitives and forged Node lookalikes must throw TypeError without
calling `toString`, `valueOf` or `Symbol.toPrimitive`. A separate case preserves
the prior nullable `contains`, `isSameNode` and `isEqualNode` behavior. Receiver
and argument authenticity are independently exercised; two invalid operands
that both yield TypeError do not by themselves prove the internal check order.
The receiver-before-conversion rule remains a source/private-test obligation.

`represented_complete_key_order` contains a literal inventory of twenty-nine
strings plus final `Symbol.toStringTag`: thirty prototype keys if the selected
method is installed between `isSameNode` and `contains`. The constructor's
literal twenty-one keys are unchanged. This is the represented implementation
inventory after connected, not the complete browser Node interface.

## History and boundaries

No historical fixture is edited. The six predecessor JS files remain exact.
The anticipated new inventory changes are connected's two case modes and four
control modes. Thirty older unhealthy inventory rows must stay unchanged.
Those counts describe expected comparison policy, not a position replay result;
all raw failures and strict/sloppy identities must be preserved. A new current
inventory witness and positive/wrong control pair are provided separately.

Ordinary fixtures cannot manufacture the host's malformed graph states, an
empty Document, arbitrary authentic Document-parent Text, or all Doctype forms.
Private tests must cover reached IDs/kinds, canonical Document endpoints,
reciprocal links, duplicate membership, cycles, accepted depth 256/refused 257,
wide sibling-scan work exhaustion, exact budget cutpoints, the local same-ID
shortcut, DOM immutability on refusal, and selected disconnected ID direction.
There is no Attr API or attribute-owner ordering witness, ShadowRoot, CDATA,
cross-document ownership expansion, live Range or MutationObserver assertion.
Representation and allocation limits remain explicit. This fixture does not
justify a security guarantee, an allocator guarantee, a speed claim or global
malformed-graph validation.

The selected method's body has no authored callback and performs no mutation;
normal JavaScript argument expressions can mutate before invocation or throw
before the native body runs. Those completed effects remain. Layout/rendering,
observer delivery and parent vector allocation internals are not tested here.
No canvas/browser witness is included in this independent unit-source hold.

## Source basis and inert checks

The primary definitions were read during the bound feasibility assessment:
[DOM position algorithm](https://dom.spec.whatwg.org/#dom-node-comparedocumentposition),
[ordinary tree order](https://dom.spec.whatwg.org/#concept-tree-order),
[Web IDL interface conversion](https://webidl.spec.whatwg.org/#es-interface),
and [regular operation behavior](https://webidl.spec.whatwg.org/#es-operations).
`html/spec-inputs.json` records those section identities and access context;
no byte hash for a live standards page is claimed. The selected implementation
policy is separately recorded in the unchanged root scope. This independent
fixture does not derive semantic results from the candidate Runtime plan.

`prepare-data.py` creates the literal control/inventory JSON exclusively and
checks names, counts, exact positive/tail hashes, key counts and Unicode escape
bytes as inert text. `static-checks.json` records its data-only checks and the
six unchanged predecessor Git-object bindings. It does not parse JavaScript,
import a replay runner, invoke an adapter, compile the repository or test runtime
budget feasibility. Further corrections after this hold must retain these
original bytes and have an additive reason and receipt.
