# Independent browser position witness

Prepared before implementation or execution against published53859161. HTML checks saved and ordinary method routes with literal masks0/2/4/10/20; disconnected masks allow35/37 with opposite reversal and repeat stability. A genuine working prerequisite precedes negative/shadow checks.

One real click moves the same left branch through detached fragment, template content, ordinary template child and back to the pair, with exact trace fcop. The pair changes AlphaBeta to BetaAlpha by reordering existing nodes. It creates no nodes during the click. Template hosted content remains a separate root. Title and status Text mutate in place; class paints both samples green then blue.

The Rust helper pins22 distinct node identities, all pair/template/parking ordinary reciprocal child links, exact Text UTF-16 units, title, base URL, status and unchanged arena length. A separate script-free literal tree for each phase is rasterized to compare the entire320x240 canvas. Draw commands must contain Alpha/Beta in the literal phase order, each once, with visible glyphs and two color probes. Page and confined-worker integration will each perform one actual click; worker generation215 is reserved. No comparator implementation is called to derive Rust expected trees.

Body source and independent literal Rust reference are frozen here; no compiler, HTML/JS parser or browser has run for this fixture. This is a represented ordinary-tree check, not all-web compatibility or performance evidence.
