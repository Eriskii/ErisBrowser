# Position private-test design

This additive source-only design follows the held proposal/ledger and published connected base 53859161acf081bac70ee4c0e0daf000abe9088b. It does not replace source-ready.json, the proposal, cost examples, or any earlier review. No implementation, compiler, fixture parser, or engine has run for this design. Every numeric cost below remains a prediction until authorized candidate measurement.

## Test harness and scope

Use fresh Runtime/Document pairs for public fixture cases and isolated native boundary setups. Copy the held independent fixture exactly and call each of its 16 named bodies separately in both modes, passing the literal false/true argument required by its existing wrapper contract. Do not combine the cases into one budget. Public fixture sources and all six historical fixture sources remain immutable.

For direct body tests, reset only the test-owned counters before a separate invocation, never inside an executing program. Set allocated = MAX_HEAP to establish that successful body traversal admits no owned heap. Capture graph contents, node/child-vector capacities, retained IDs, metadata bag state where relevant, and execution cleanup. Error diagnostics and generic VM allocations retain inherited limitations; zero body heap is not a claim about all process allocations. Deep geometry tests compare the snapshot only at measured endpoints, not across a large budget sweep.

A small fixture constructor uses explicit reciprocal parent/children links. Prove the actual parent chain and edge count, then pass the complete arena through Document::from_snapshot for accepted deep cases. Raw append alone cannot establish the accepted 256-edge boundary. Host-malformation tests deliberately modify a valid setup afterward and record which local invariant should be reached.

## Six geometry measurements

Measure the direct body work against these source-derived predictions. In both directions verify masks independently of the result, unchanged graph/capacities, zero owned body heap, and cleanup. For disconnected private tests, derive the expected 35/37 from the documented original operand IDs, never from the method result.

| Geometry | Direct work | Scoped name/dispatch plus body | Expected orientation |
| --- | ---: | ---: | --- |
| Two detached leaves | 118 | 178 | 35/37 from original IDs; opposite reversal |
| Two siblings under a detached two-child parent | 249 | 309 | left-to-right 4, right-to-left 2 |
| Detached root versus unary leaf at 256 edges | 11138 | 11198 | root-to-leaf 20, reverse 10 |
| Unary nodes at depths 255 and 256 | 17003 | 17063 | ancestor-to-child 20, reverse 10 |
| Leaves under separate unary roots, each 256 edges | 17014 | 17074 | 35/37 from original IDs |
| Leaves of two branches, each 256 edges below one two-child root | 22179 | 22239 | first branch to second 4, reverse 2 |

The scoped column includes only the new 60-work call-name/dispatch route. Full Runtime::call can add existing VM and argument/stack charges and must be measured separately. Establish exact work and one-short work endpoints for each geometry, without raising MAX_STEPS. The largest prediction is comfortably below the fixed limit for this geometry only; arbitrary wide trees may refuse.

## Authentication, local shape, and no coercion

Use direct calls to distinguish receiver refusal at 16 work, valid receiver plus missing argument at 20, and explicit null/undefined/non-Node argument refusal at 32. Check one-short refusal at each admission, authentic Document aliases, and out-of-range Value::Node IDs. Unlike the existing nullable predicates, null and undefined never produce an ordinary mask.

For a genuine identical operand, check exactly 66 work, including both paid local validations and the final result debit. Confirm canonical Document aliases return zero. A malformed canonical root kind, noncanonical Document, parented Fragment, or childful Text refuses locally even on self. An otherwise valid Element with an invalid unvisited ancestor link may still return zero: document this limited shortcut rather than asserting a global graph audit. Include all represented leaf kinds and an empty Document setup.

Authored toString/valueOf/public parentNode/root fields must not be invoked by interface conversion or internal traversal. The independent ordinary cases cover these observable semantics; private tests focus on malformed host structures and the exact native budget route rather than duplicating every JS body.

## Complete paths and host-malformation matrix

Start from valid small pairs and introduce one fault per setup: missing selected child, duplicate selected child in a parent vector, out-of-range parent, non-container parent, false canonical root kind, noncanonical Document ancestor, parented Fragment, a childful leaf, immediate self-parent, and a reciprocal two-node ancestor cycle. Valid current IDs/local operand shapes should reach the intended parent-path guard. Bound cycle refusal with the unchanged edge limit; no visited storage is expected.

Exercise a malformed receiver chain and, separately, a clean receiver with a malformed OTHER chain. In the latter, make the two apparent roots disconnected but invalidate a higher link on the second path. Require TypeError, proving the method finishes the second path before emitting 35/37. Reverse operands as a separate case. Also keep a control with a structurally invalid unrelated sibling ID: the selected-child scan compares IDs but does not dereference every sibling, so this is not an all-sibling/global validation promise.

From a validated 256-edge fixture, add one explicit reciprocal host edge and prove it is now 257 before expecting TypeError. Test it as each operand, including a clean detached opposite operand. Keep heap headroom irrelevant by using direct body calls at MAX_HEAP.

For disconnected ordering, create roots whose ID order differs from the original operands' order, then move the same operands between still-disconnected roots. The private result must remain determined by the original operand IDs. This catches accidental use of cursor/root IDs after walking; portable independent fixtures continue to allow either conforming 35/37 direction.

## Work admission and separate scan cutpoints

Exhaustively sweep work 0..=measured_success only for small detached/sibling/ancestor representatives (hundreds, not tens of thousands). Each sub-success budget must be Resource, with zero remaining steps where work admission refuses, unchanged graph/capacities/heap, and clean frames/calls/eval_depth/stack_units. Deep cases use only exact and one-short endpoints.

Calibrate the final-sibling phase separately on a moderate-width sibling parent, such as L = 1024. Direct sibling body work is 221 + 14L; the prefix before position_branch_order is 208 + 8L; helper setup is 8, scan is 1 + 6L, and result is 4. These predictions must be checked against direct helper/body observations after implementation. Test refusal before the scan debit and at each of the four final-result work units, plus exact success. A focused helper test can reject duplicate/missing selected branch IDs without relying on a body route that already excludes those malformed states. Do not add a production injection seam.

Use separate fixed-budget terminal geometries:

- First-walk refusal: a receiver selected under a parent of 26000 children; the 1 + 4L membership debit itself exceeds MAX_STEPS. Opposite operand is a valid detached leaf.
- Second-walk refusal: swap which operand owns that wide parent, keeping the receiver walk cheap and valid. The second path must be reached and refuse before disconnected direction.
- Final-order refusal: two selected children of one 8000-child parent. Each complete walk costs 32053 and both are admissible together; the body prefix before the order helper is 64208. The final scan costs 48001, and total body work would be 112221. Thus the fixed budget can admit both root walks but cannot admit the final sibling scan. Validate these stage predictions directly with existing private helper calls before relying on the JS terminal witness; no steps value may exceed MAX_STEPS.

For public terminal runs, ordinary execute owns its existing execution reset. Do not try to select an exact cutpoint by setting steps before execute, because execute resets it. Instead use the host-created wide geometry and measure a matched cheap baseline program to bound dispatch/VM/argument overhead. On the final-order case, prove the actual prefix plus existing invocation overhead fits below MAX_STEPS while the full scan does not. If this cannot be established with actual measurements, adjust only the private test geometry and retain the first setup/diagnostic; do not claim final-phase coverage from a generic Resource error.

## Extra expressions, terminal propagation, and invocation storage

Run both strict and sloppy saved-native programs with a completed extra expression that sets effect = 1 before invocation. For each calibrated terminal geometry, require Resource, effect retained, catch/finally flags still false, and unchanged tree/metadata. This proves that the new body shares the active execution budget and does not reset it; it does not turn a work refusal into an ordinary catchable TypeError.

Add a distinct extra-expression exhaustion case: a small genuine self call would succeed, but a supplied ignored extra expression first records an effect then exhausts work in an authored loop. Require terminal Resource with catch/finally unrun and no completed call/result marker. This isolates argument evaluation before native invocation; do not mislabel it as a comparator traversal failure.

Measure a saved method Runtime::call on a small genuine pair after obtaining its cached Native value. Repeat with exact work/heap, work minus one, and heap minus one, checking name-copy admission, cleanup, unchanged metadata identity, and unchanged graph. The full native route owns at least the separately charged 64-byte name copy; do not demand zero heap there. Independently verify direct preflight 36 work/64 bytes and suffix dispatch 24 work, plus unchanged old operation/accessor route fees. Existing getRootNode/isConnected tests remain the regression for their preserved walk/options behavior.

Keep a two-live-Runtime metadata-bag witness (separate names/markers), and show that extra unrelated arena nodes or large unvisited payloads do not change direct position-body work. These are bounded tests, not a host performance benchmark.

## Metadata/history and source hold

Add the ordinary method between isSameNode and contains and explicitly test current 30-key prototype/21-key constructor inventory through the independent fixture. Audit every constant-test prebatch/final/capacity assumption: prototype 11/29/30, constructor 3/21/21. Preserve all six historical JS files exactly; each disposable historical wrapper removes/restores the new configurable method independently of the existing isConnected getter descriptor.

The raw bootstrap diagnostic must print actual counters before any descriptive assertion is updated. Predicted remaining work 6599, charged bytes 1768914, and 689 objects are hypotheses, not fixture expectations or measurements. Root owns measured literal updates and validation.

Before compilation, derive actual test function names with a digit-inclusive Rust identifier pattern, count independent cases separately from direct private groups, and hold all owned source hashes plus concrete helper-to-ledger correspondence. No fixed group count is promised by this design; avoid inflating observations into unique groups. Root's Page/worker groups remain separately owned.
