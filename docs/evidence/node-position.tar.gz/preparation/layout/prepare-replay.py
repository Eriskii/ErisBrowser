#!/usr/bin/env python3
"""Prepare the source-bound position matrix; never launch a JavaScript engine."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
import re
import shutil
import subprocess

if not __debug__:
    raise RuntimeError('run without Python optimization')
P = Path(__file__).resolve().parents[1]
R = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-node-connected-preparation-1/replay')
ART = Path('/tmp/eris-node-connected-1')
OUT = P / 'replay'
FIXTURE_SHA = '97855d380d9a18edbef4fd0c317ac5430265d78d07f9adeb5511542fcbb84575'
BASE = '53859161acf081bac70ee4c0e0daf000abe9088b'
RELEASE_SHA = 'd9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def verify(row, directory=None):
    p = Path(row['path'])
    if not p.is_absolute():
        assert directory is not None
        p = directory / p
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes'], str(p)
    return p


def write_json(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


for name in ['independent', 'runtime', 'html', 'browser']:
    hold = json.loads((P / name / 'source-ready.json').read_text())
    for row in hold['files']:
        verify(row, P / name)
for name in ['independent/layout-source-review.json', 'layout/runtime-plan-review.json',
             'root/independent-source-review.json']:
    review = json.loads((P / name).read_text())
    assert review['status'].startswith('clear ') and review['findings'] == []
acceptance = json.loads((P / 'root/plan-acceptance.json').read_text())
assert acceptance['status'] == 'accepted source-only ordinary Node position plan'
for row in acceptance['bindings']:
    verify(row)
base = json.loads((P / 'root/published-base.json').read_text())
assert base['commit'] == BASE == subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert base['release']['sha256'] == RELEASE_SHA == sha(Path(base['release']['path']))
assert Path(base['release']['path']).stat().st_size == base['release']['bytes']

# Refuse reused output; any failed preparation remains available for inspection.
OUT.mkdir()
history = []


def copy(p, rel):
    dest = OUT / rel
    if dest.exists():
        assert dest.read_bytes() == p.read_bytes(), str(dest)
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
    history.append(dict(origin=str(p), copy=str(rel), bytes=dest.stat().st_size,
                        sha256=sha(dest)))


# Includes original feasibility/context and the additive arithmetic correction.
# Browser material is provenance only and introduces no replay prerequisites.
for directory in ['independent', 'runtime', 'html', 'layout', 'browser']:
    for p in sorted((P / directory).rglob('*')):
        if p.is_file():
            assert '__pycache__' not in p.parts and not p.is_symlink()
            copy(p, p.relative_to(P))
for name in ['scope.md', 'independent-source-review.json', 'published-base.json',
             'plan-acceptance.json']:
    copy(P / 'root' / name, Path('root') / name)
for name in ['test262_conformance.py', 'html_conformance.py', 'import_test262.py']:
    assert (R / 'tools' / name).read_bytes() == (OLD / 'tools' / name).read_bytes()
    copy(OLD / 'tools' / name, Path('tools') / name)
for name in ['node-constants.js', 'node-normalize.js', 'node-predicates.js',
             'node-root.js', 'node-equality.js', 'node-connected.js']:
    raw = subprocess.check_output(['git', 'show', BASE + ':tests/fixtures/' + name], cwd=R)
    assert (R / 'tests/fixtures' / name).read_bytes() == raw
    copy(R / 'tests/fixtures' / name, Path('history') / name)
for name in ['source-ready.json', 'replay.py', 'replay-matrix.json', 'replay-inputs.json']:
    copy(OLD / name, Path('history/prior-replay') / name)
for name in ['candidate-source-final.json', 'release.json', 'published.json']:
    copy(ART / name, Path('history/published-connected') / name)

# Current Runtime inputs are published connected bytes. Earlier HTML feasibility
# inputs are deliberately rebound to equality Git objects, never mutable main.
sources = json.loads((P / 'runtime/source-inputs.json').read_text())
for row in sources['exact_published_source_population']:
    p = verify(row)
    rel = p.relative_to('/tmp/eris-node-position-1/worktree')
    assert p.read_bytes() == subprocess.check_output(['git', 'show', BASE + ':' + str(rel)], cwd=R)
for pair in sources['selected_sources']:
    p, held = verify(pair['source']), verify(pair['retained'])
    assert p.read_bytes() == held.read_bytes()
    rel = p.relative_to('/tmp/eris-node-position-1/worktree')
    assert held.read_bytes() == subprocess.check_output(['git', 'show', BASE + ':' + str(rel)], cwd=R)
legacy = json.loads((P / 'html/source-inputs.json').read_text())
for row in legacy['sources']:
    held = Path(row['held_copy'])
    assert sha(held) == row['sha256'] and held.stat().st_size == row['bytes']
    raw = subprocess.check_output(['git', 'show', legacy['published_base'] + ':' + row['repository_path']], cwd=R)
    assert raw == held.read_bytes()

# Preserve externally referenced inputs, including the actual prior release
# receipts. Engine executables themselves are deliberately not copied.
references = (json.loads((P / 'independent/source-inputs.json').read_text())['files']
              + list(json.loads((P / 'runtime/dependencies.json').read_text()).values()))
for row in references:
    p = verify(row)
    if p.is_relative_to(P):
        rel = p.relative_to(P)
    elif p.is_relative_to(R):
        rel = Path('history/published-main') / p.relative_to(R)
    else:
        assert p.is_relative_to(Path('/tmp')) and p.name != 'eris-js'
        rel = Path('history/dependencies') / p.relative_to('/tmp')
    copy(p, rel)

fixture = OUT / 'independent/cases.js'
assert sha(fixture) == FIXTURE_SHA
inv = json.loads((OUT / 'independent/inventory.json').read_text())
ctrl = json.loads((OUT / 'independent/controls.json').read_text())
assert len(inv['cases']) == 16 and inv['collection'] == 'nodePositionCases'
assert len(ctrl['controls']) == 8
assert inv['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True}
assert re.findall(r'^  ([A-Za-z0-9_]+): function\(\)', fixture.read_text(), re.M) == inv['cases']
inventory = dict(fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA,
                 collection=inv['collection'],
                 cases=[dict(name=name, modes=['sloppy', 'strict'],
                             expected_observation=inv['ordinary_expectation'])
                        for name in inv['cases']],
                 controls=ctrl['controls'], case_modes=32, control_modes=16,
                 case_invocation_argument_by_mode=inv['case_invocation_argument_by_mode'])
write_json(OUT / 'replay-inputs.json', inventory)

original = (OLD / 'replay.py').read_text()
changes = [('Frozen Node connected observations', 'Frozen Node position observations'),
           ('nodeConnectedCases', 'nodePositionCases'),
           ('node-connected.js', 'node-position.js'),
           ('25e76612b7ff0e8f6ce0a68b5ae72399a77d27be2b745da0aad2b44ae885bc94', FIXTURE_SHA)]
driver = original
for before, after in changes:
    assert before in driver
    driver = driver.replace(before, after)
reverse = driver
for before, after in reversed(changes):
    reverse = reverse.replace(after, before)
assert reverse == original
ast.parse(driver)  # Python supervisor only, never JavaScript parsing.
with (OUT / 'replay.py').open('x') as f:
    f.write(driver)
with (OUT / 'replay.py.diff').open('x') as f:
    f.writelines(difflib.unified_diff(original.splitlines(True), driver.splitlines(True),
                                    fromfile='connected/replay.py', tofile='position/replay.py'))
write_json(OUT / 'driver-transformation.json', dict(
    original=dict(path=str(OLD / 'replay.py'), sha256=sha(OLD / 'replay.py')),
    current=dict(path=str(OUT / 'replay.py'), sha256=sha(OUT / 'replay.py')),
    identity_substitutions=[dict(before=a, after=b) for a, b in changes],
    substantive_change=None, reverse_transform_is_byte_exact=True,
    unchanged='Literal per-mode Boolean invocation, observation matching, bounds, failure retention, bindings and positive-partner policy'))
write_json(OUT / 'preparation-history.json', history)

commands = []
for option in ['--prepare', '--verify']:
    args = ['python3', str(OUT / 'replay.py'), option]
    result = subprocess.run(args, capture_output=True, text=True)
    record = dict(command=args, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
    commands.append(record)
    if result.returncode != 0:
        write_json(OUT / 'inert-verification-failure.json', dict(commands=commands))
    assert result.returncode == 0, record
write_json(OUT / 'inert-verification.json', dict(engine_run=False, compiler_run=False,
                                               javascript_parser_run=False, commands=commands))
result = dict(
    status='Frozen position expectations; inert matrix verified; no position engine or JavaScript parser execution',
    location=str(OUT), location_must_remain_fixed=True,
    ordinary_bodies=16, ordinary_modes=32, control_pairs=4, control_modes=16, total_rows=48,
    history_copies=len(history),
    driver=dict(path=str(OUT / 'replay.py'), sha256=sha(OUT / 'replay.py')),
    matrix=dict(path=str(OUT / 'replay-matrix.json'), sha256=sha(OUT / 'replay-matrix.json')),
    fixture_sha256=FIXTURE_SHA,
    invocation='Named cases retain literal false for sloppy and true for strict; these bodies ignore the argument; controls unchanged',
    supervision='Exact connected driver after four reversible identity substitutions only; ERJS1/ERJR2,3s,96KiB stdout/64KiB stderr,4MiB request, exclusive fresh output, pre/post bindings, same-mode positive control health; inherited direct-child supervision',
    baseline=dict(status='Not executed by this preparation; root owns future baseline',
                  published_commit=BASE, binary=base['release']),
    history_policy='Original equality-context feasibility and anticipatory connected proposal remain retained, with actual538 publication rebound. All six historical fixture bytes unchanged. Six newly anticipated connected inventory rows and30 older unhealthy rows remain separate, not waived.',
    browser='Held source copied as additive provenance; browser is not executed or required by the JS matrix',
    files=[dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
           for p in sorted(OUT.rglob('*')) if p.is_file()])
write_json(OUT / 'source-ready.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, indent=2))
