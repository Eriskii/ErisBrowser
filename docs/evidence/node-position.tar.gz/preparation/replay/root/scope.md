# Selected follow-up: ordinary Node.compareDocumentPosition

Root selects preparation of this ordinary Node method after isConnected. The
actual published base remains equality9839259. Connected is locally validated
with release d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715
and final20source manifest d07f434be9dd87d0adf1c21a614fe77014311d83315ae0912dc3f931944620df;
its independent result audit and publication are still in progress. Preparation
does not authorize implementation, a candidate compiler, or engine execution.
Rebind to the actual connected publication before baseline or implementation.

Root read the independent HTML feasibility assessment, published predicate,
root/equality helpers and primary DOM/Web IDL definitions. The method describes
the other node relative to its receiver: same identity0, other ancestor10,
other descendant20, ordinary earlier/later branches2/4, disconnected35or37.
The required other argument is NONnullable: omission/null/undefined fail with
TypeError. Receiver authentication precedes argument conversion; conversion
must not invoke authored hooks. Extra expressions run before invocation and
their values are otherwise ignored. Regular cached nonconstructible method,
length1, writable/enumerable/configurable, with ordinary shadows/replacement/
deletion and no virtual fallback. Existing constants need no new semantics.

Scope is the existing ordinary Node kinds in one represented Document arena.
No Attr, ShadowRoot, CDATA, arbitrary document ownership or namespace expansion.
Template content remains a separate ordinary root; never follow its host.
Payloads, attributes, visibility and structural equality do not decide position.

Select constant-space traversal: validate each distinct operand's complete
ordinary ancestor path and depth, then perform paid depth alignment and a paid
common-parent sibling scan. The immutable document and callback-free body keep
the first phase's edge validation valid during alignment. Retain the existing
parent-kind, canonical Document endpoint, full selected-child reciprocal scan,
local shape and256edge admission policy. Both original walks and every reached
alignment/index/order operation need explicit work before execution. No ancestor
Vec, arena bitmap, whole-document traversal or comparison payload allocation.
Wide child vectors can exhaust the existing allowance at shallow depth.

After authentic conversion, validate the reached local operand shape and
canonical root-kind invariant before the same-ID shortcut. Same-ID then returns
zero without validating ancestors or unrelated graph state. Distinct operands
require the complete paid paths before root comparison. This is a local host
policy, not a claim that malformed trees are standard DOM inputs.

For different validated roots, choose stable original canonical operand IDs as
the implementation-specific tie-break: smaller other ID gives35, larger gives37.
Aliases of the canonical Document share its ID. This policy is scoped to one
append-only arena with retained detached nodes, never pointer addresses or a
cross-document claim. Portable independent cases should verify allowed masks,
opposite direction under reversal, repeated-call stability and unchanged-node
moves; private policy cases can assert the selected numeric-ID direction.

Do not extend or reprice the current shared getRootNode/isConnected walk merely
to return depth. Preserve their successful fees, options boundary and source
behavior. A separate position walk can reuse narrow paid local validation,
but any helper extraction must establish unchanged old behavior explicitly.
No quota changes, refunds, authority changes, execution resets or wire changes.

Install in the represented method order between isSameNode and contains. After
accepted connected29, pristine prototype inventory becomes30 and constructor21
stays fixed. Update guarded N29 batching with an independently reviewed typed
ledger, including actual right-border behavior and storage; do not extrapolate
old bootstrap literals before measurement. Preserve every historical fixture.
Anticipated next inventory differences are connected's two cases/four controls,
with30older unhealthy rows still retained; actual publication must be rebound.

Preparation may now produce a concrete Runtime plan and independently authored
case/control sources against this selected scope. Native/resource checks and
Page/worker witnesses follow after the plan is reviewed. The next ordinary
sources must be held before candidate execution; no successful engine result,
security guarantee or performance threshold follows from this scope selection.

Primary references read by root:
- https://dom.spec.whatwg.org/#dom-node-comparedocumentposition
- https://dom.spec.whatwg.org/#concept-tree-order
- https://webidl.spec.whatwg.org/#es-interface

DOM source reports last update2026-09-24. Feasibility hold:
127ac4d4855a337d098f7e763fd3b9110a49c5346fde6b61cfb1af577b96d92a.
