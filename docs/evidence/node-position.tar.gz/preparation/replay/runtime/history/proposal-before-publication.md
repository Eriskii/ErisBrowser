# Represented Node.compareDocumentPosition Runtime plan

This is source-only preparation for the scope selected in root/scope.md. The actual published base is equality 9839259eeaf10dfab8205d88e0f3b3c359d358b8. The anticipated predecessor is the locally validated, still unpublished connected candidate: final20 source d07f434be9dd87d0adf1c21a614fe77014311d83315ae0912dc3f931944620df and release d9f1df99e5cf879bb8e8c07423b047a5da89f3de8e4ec5a327967bf5a9738715. Its observed bootstrap is 7292 work remaining, 1765502 charged bytes, 688 objects/capacity, 321 native registry entries and 25 legacy prototypes. Publication and implementation acceptance require an additive binding; do not rewrite this context or claim this plan is measured. No repository source, executable fixture, compiler or engine changes/runs are part of preparation.

## Binding and result semantics

Install one cached nonconstructible method on Node.prototype, named compareDocumentPosition, length1, writable/enumerable/configurable. Name/length use the existing ordinary function descriptors and Function.prototype. It appears between isSameNode and contains. No virtual fallback, readonly host table or public-property tree lookup is added. Saved calls, ordinary shadows, descriptor replacement/deletion and genuine alternate-prototype objects follow existing behavior.

The required other argument is nonnullable. Pay/authenticate the receiver before required-arity and interface conversion; missing/null/undefined/forged receivers fail without author coercion. Argument expressions have already run in the VM; the body ignores extra values and invokes no callbacks. Document aliases canonicalize to the same arena ID. This is a represented ordinary-tree implementation, with no Attr, ShadowRoot, CDATA or cross-document ownership expansion. See [DOM position](https://dom.spec.whatwg.org/#dom-node-comparedocumentposition), [ordinary tree order](https://dom.spec.whatwg.org/#concept-tree-order), and [Web IDL interface conversion](https://webidl.spec.whatwg.org/#es-interface).

The result describes other relative to receiver: self0; other ancestor10; other descendant20; earlier/later unrelated branches2/4. For distinct validated roots, original canonical operand IDs decide the implementation-specific direction: smaller other ID35, larger other ID37. Keep original IDs even while alignment cursors advance. This policy is stable for unchanged identities inside the append-only arena; it is not a pointer policy or a guarantee across arbitrary host arena replacement. Attributes, data, namespaces, visibility and structural equality are irrelevant. Template hosts are never ordinary parents.

## Narrow helpers and unchanged old methods

New node_position.rs declares METADATA_OBJECTS=1 and these internal operations:

- `node_compare_document_position(&mut self, receiver: Value, args: &[Value], doc: &Document) -> Result<Value>`: authentication, identity, both complete walks, ordering.
- `position_root_and_depth(&mut self, current: NodeId, doc: &Document) -> Result<(NodeId, usize)>`: a separate paid root/depth walk.
- `position_local(doc: &Document, id: NodeId) -> Result<&Node>`: private pure helper, only after16 work; existing node_predicates::local_node plus an explicit requirement that id==doc.root implies Document kind.
- `position_parent(doc: &Document, id: NodeId) -> Result<NodeId>`: private pure bounded index/parent read, only after8 work in the second phase. It returns explicit TypeError on absent/out-of-range state, not a panic. Its immediate caller proves that this edge belonged to a successful full walk and that no mutation intervened.
- `position_branch_order(&mut self, parent: NodeId, receiver_branch: NodeId, other_branch: NodeId, doc: &Document) -> Result<Value>`: complete paid selected-sibling scan and numeric2/4 result.

Do not modify, extract or reprice node_root_options, node_ordinary_root_from_id, node_is_connected, or the existing predicate/equality bodies. Their source hashes and prior boundary tests are regression obligations. Reuse only node_id and local_node. The new complete walk pays a separate16 current-node check, including the canonical-root-kind guard even for an intermediate false-root host node; this stronger reached check does not change the old12-work walk.

## Ordered body phases and work ledger

All figures are logical admission units, not instruction counts or a wall-clock claim. No owned traversal/payload storage is allocated. Generic VM invocation and diagnostic allocation limitations remain inherited.

1. Pay16, then node_id(receiver). Pay4, then require args.first. Pay12, then node_id(other), with no nullable shortcut. Invalid receiver wins over missing/invalid argument. Missing arguments stop at20; an authentic receiver with explicit nullish/forged other stops at32.
2. Pay16 before position_local(receiver ID), then16 before position_local(other ID). These validate only reached local shape/canonical identity, not parent ancestry. Pay2 before the same-ID comparison/zero result. Valid self costs66 and performs no parent walk. A childful leaf, parented Document/fragment, noncanonical Document or false doc.root kind refuses before self; a same Element with an invalid but unvisited parent does not become a global graph-validation claim.
3. For each distinct operand in receiver-then-other order, call position_root_and_depth. Pay4 setup for the bounded depth counter/tuple bookkeeping. Each reached current node pays16 before position_local and parent/depth checks. A parentless endpoint pays4 before returning (root ID, depth). Each advancing edge checks depth<MAX_DEPTH and parent!=current before following it; pay12 for local_node(parent) and allowed container kind; check scan arithmetic and pay1+4*S before scanning the entire parent child vector for exactly one current ID. Missing or duplicate selected membership refuses. Then advance/increment within the proved256 bound. The endpoint at exactly256 is processed; a257th edge or a longer cycle refuses. The complete walk is `24 + 29*D + 4*sum(S_i)`.
4. After both complete walks, pay4 before root comparison and the disconnected ID direction/result. Different roots return35/37 here, only after both selected paths are validated. Invalid state on the second operand cannot be concealed by recognizing disconnection after the first.
5. For equal roots, pay4 to retain the original depths and initialize alignment cursors. Use two loops, receiver depth>other depth and vice versa. Each loop pays2 before each condition, including its terminating check. An advancing iteration pays8 before the parent index/Option read, cursor assignment and bounded depth decrement. Exactly A=abs(D_receiver-D_other) advances cost10*A+4 across the two loops.
6. Pay4 before comparing aligned IDs and producing a containment result. If they agree, original receiver depth<other depth returns20; original receiver depth>other depth returns10. Distinct original operands cannot reach equal aligned IDs with equal original depths. No original-ID swap is used.
7. Otherwise both aligned cursors have the same positive remaining depth. Each ascent round pays4 before loop/depth/result bookkeeping and8 before each of the two validated parent reads, total20. Require positive remaining depth. If parents differ, assign both cursors and decrement remaining depth; equality of roots and successful immutable walks bound this loop. If parents agree, call the sibling-order helper with these distinct branch IDs. J counts all parent-pair rounds, including this final round, so1<=J<=min(original depths).
8. The sibling-order helper pays8 for parent lookup, length and checked scan setup; it uses the already validated immutable parent but retains explicit indexing failure. Pay1+6*L before the full child-vector scan: iterator/index work, two selected-ID comparisons and at most one selected position/duplicate update per child. Keep two optional usize positions, finish the entire scan and reject absent/repeated selected IDs. Pay4 for final presence/order/numeric result. Other index lower than receiver index returns2, otherwise4. Total13+6*L. Do not dereference or audit unrelated sibling nodes.

The immutable Document borrow and lack of callbacks preserve the first phase's edge proof during alignment. No ancestor Vec, bitmap, tree map, cache, payload scan, template-host traversal, depth reset or sibling rescan during alignment is hidden in these figures. Work counters, scan multiplication/addition and depth/index bounds remain checked before the relevant operation. Refusals retain consumed work and perform no body mutation.

Let D be D_receiver+D_other, S be the sum of both walks' reached parent-vector lengths, A the depth difference, J ascent pair rounds, and L the final common-parent width. Successful body totals are:

| Branch | Work |
| --- | ---: |
| Same ID after local checks |66|
| Disconnected roots |118+29*D+4*S|
| Ancestor/descendant after alignment |130+29*D+4*S+10*A|
| Divergent branches |143+29*D+4*S+10*A+20*J+6*L|

Illustrative narrow-tree predictions: two detached leaf roots118; two sibling leaves under a two-child root249; root versus unary256-edge descendant11138; unary depth255 versus256 ancestry17003; separate unary256-edge roots17014; two depth256 branches diverging at a two-child root22179. Add the scoped60 invocation work below. These examples fit100000, but wide reached vectors can exhaust the unchanged budget even at shallow depth. They are planned costs pending implementation and measurement, not an unconditional depth-success claim.

## Dispatch and metadata ledger

Use the existing DOM.Node prefix and one new length23 arm in node_data_native. Pay the existing1 discriminator, then23 before the exact suffix comparison. All older operation/accessor paths remain unchanged, including the first/second length11 getRootNode/isEqualNode checks and the unmatched-only connection getter. Full native name DOM.Node.compareDocumentPosition has32 bytes; existing name-copy preflight pays36 work/64 bytes. Scoped new invocation is60 work/64 bytes, plus generic VM/property lookup/error work.

Deliberately extend the existing install_node_identity_members array to [isSameNode, compareDocumentPosition, contains]. Keep its single existing4-work entry charge; no extra installer wrapper is introduced. Each member still uses node_data_function(name,name,1) and dom_proto_named. Add one object to the global reservation through node_position::METADATA_OBJECTS and one Node order slot. The eight earlier members retain their charges; only contains shifts owner count9 to10.

| Added bootstrap work | Work |
| --- | ---: |
| Factory: object/order9, display54, length29, name31, full native name40 |163|
| New owner at count9: key54, full comparisons9*24, moves17, reserved order1 |288|
| Existing contains shift9 to10 |10|
| N28 to N29 batch |232|
| New installer entry / later constructor delta |0|
| Total |693|

Prototype preconstant count11, result map29, order capacity30; constructor remains3/21/21. Sorted prototype guard is compareDocumentPosition, contains, getRootNode, hasChildNodes, isConnected, isEqualNode, isSameNode, nodeValue, normalize, textContent, then tag. Physical creation order is tag, isConnected, nodeValue, textContent, getRootNode, hasChildNodes, normalize, isEqualNode, isSameNode, compareDocumentPosition, contains. Complete reflection has29 strings plus final tag=30; constructor has21 keys.

N29 still has two leaf overflows at12 and24, height1/four allocated nodes. Right leaf now has5 pairs, so no redistribution is required; retain the existing64 repair envelope,32 navigation/header bounds and48-entry sort scratch. Full comparisons3*28*42=3528 plus structure678 give map4206. Owner32+4*12+2*11*42=1004. With constructor3030+300 and common1584, batch10124, delta232. Batch storage becomes14820+18K+146E+7B, only E above N28. Old descriptor/Native handles remain moved unchanged; no quota or guard relaxation. The pinned Rust1.88/1.98 source provenance remains the retained earlier append/fix/node review, not a falsely claimed local pinned rust-src copy.

New total typed metadata storage is `1516 + (S+A+D+N) + 3K+B+E`. Fixed1516 comprises object72, display156, length key88/property280, name key80/property272, native-name64, owner key156/property348. K is PropertyKey; E is (PropertyKey,Property); B is the existing typed tree-node bound; S/A/D/N are ScriptObject/Option<AbortSlot>/Option<f64>/Native. Two getter/function order slots plus one Node order slot make3K. New owner at count9 and shifted contains at10 need no additional preconstant tree block; the function's first property does. With prior S+A+D+N304, K16, E72, B1472, delta3412. Conditional raw bootstrap prediction from the observed connected context is6599 remaining work /1768914 charged bytes /689 objects and capacity, native321/legacy25 unchanged. No descriptive literals change until root measures.

## Private witnesses, history and scope

Before compilation bind current old methods/options/dispatch fragments and all six frozen Node-family JS files. Keep existing successful route fees and callback-order tests as regressions. The new independent source must remain authored/reviewed separately from implementation, with true prerequisite controls and a literal current30-key prototype inventory. Portable disconnected cases assert allowed masks, reversal and stability; private policy tests pin original-ID35/37 direction.

Private tests should cover required nonnullable arity and receiver-first errors; exact self/Document aliases; local malformed self refusal and explicit unvisited-ancestry limitation; original operand ID policy under moves between still-disconnected trees; empty Document, Doctype and all represented leaf kinds; connected/detached/template ordinary/content relationships; reversed ancestor and unequal-depth branch direction; full second-root validation; missing/duplicate selected links, false root, wrong parent kind, self/cyclic and257th-edge refusal. Construct reciprocal depth geometry directly, prove it through from_snapshot and assert attachment/depth before measurements.

Use small exhaustive work cuts on representative self, disconnected, ancestor and sibling bodies with MAX_HEAP already exhausted, checking no DOM/metadata/capacity mutation and no body-owned allocation. Deep cases need measured exact/one-short endpoints only. Measure saved Native work and name-copy heap exact/one-short endpoints plus stack cleanup. A wide first or second walk and final ordering scan should have explicit terminal-refusal witnesses, with completed argument effects retained and no catch/finally/reset. Because first-walk scans also touch the eventual common parent, isolate a final-order refusal with a calibrated direct-call endpoint rather than assuming a width alone reaches that stage. Unrelated arena/payload size must not affect body cost; two live runtimes retain independent mutable method metadata.

All six old fixtures remain byte-exact. Add compareDocumentPosition to existing historical method-removal lists, preserving their separate isConnected accessor guards. Convert the connected complete-order private call into a disposable-realm wrapper that removes/restores the new ordinary method. Keep current small Node-data order witnesses explicit. Constants tests must change every prebatch/final/capacity expectation to11/29/30, including the setup old-count assertion missed in the previous increment; constructor3/21/21 remains unchanged. Record original failures and any later corrections rather than overwriting the initial hold.

Expected owned production/test scope is module/new node_position.rs/tests; node_data dispatch; node_predicates identity installer array; dom_prototypes reservation/metadata; node_constants roster/tests; six historical private inventory wrappers; small Node-data order; exact new JS source. DOM/storage/wire, machine invocation bridge, legacy tables and existing root/equality/connected bodies need no edits. Root owns browser integration, measured snapshots, compiler and publication. This plan does not authorize implementation.
