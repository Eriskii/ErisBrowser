"""Summarize this checkpoint's retained results; never invoke a test or engine."""

import hashlib
import json
import re
from pathlib import Path

B = Path(__file__).resolve().parent
BASE = '53859161acf081bac70ee4c0e0daf000abe9088b'
SOURCE_SHA = 'c6d4423dadf42a2812b69717fa86bb4ddae0543c9dd1b1caa092151b6c8f5377'
RELEASE_SHA = 'f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007'
AUDIT_SHA = 'bdb9c7ab31c89572627108ffa2c9d28abb8ca4705e80e9774f7d547b6ad69abc'
PINS = {
    'candidate-source-final.json': SOURCE_SHA,
    'independent-results-review.json': AUDIT_SHA,
    'audit-results-1.json': AUDIT_SHA,
    'position-comparison.json': '21ce19c22ba3a32b9c9ba5e6aa38be2328f67a66524503652a0a7ef210b93588',
    'inventory-classification.json': 'ef022e1b2c569f743873c00f33ddc67f27500b3b48154433d1f6005f220fea72',
    'focused-validation-review.json': '484d0684186e6cc703bf844f7d3a885d93def52803d76f9545666385860eecbc',
    'runtime/test-inventory.json': '10ccc89e804c03131d54af75b199cf8533dfdf24c6df254d83b2539111b717ae',
    'bootstrap-correction/receipt.json': '055e04731a01631323254b8adc184e27c37a98824eef680cc365a1ccbfdaca33',
    'audit-preparation/focused-summary-schema-correction/receipt.json': '6b6b619cb941a718d9d06b703c93ee252197d25e39d84ce24dff5eac045c3bb8',
}
seen = {}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def data(path):
    path = Path(path)
    raw = path.read_bytes()
    record = {'path': str(path), 'bytes': len(raw),
              'sha256': hashlib.sha256(raw).hexdigest()}
    require(str(path) not in seen or seen[str(path)] == record,
            'Input changed during summary preparation: ' + str(path))
    seen[str(path)] = record
    return raw


def read(name):
    raw = data(B / name)
    if name in PINS:
        require(hashlib.sha256(raw).hexdigest() == PINS[name], 'Pinned input drift: ' + name)
    return json.loads(raw)


def digest(name):
    return hashlib.sha256(data(B / name)).hexdigest()


def checked(label):
    row = read('validation/' + label + '.json')
    require(row['exit'] == 0, 'Nonzero validation command: ' + label)
    require(digest('validation/' + row['log']) == row['sha256'], 'Validation log drift: ' + label)
    return row


def main():
    audit = read('independent-results-review.json')
    require(audit['status'] == 'clear' and audit['findings'] == [], 'Independent audit is not clear')
    require(read('audit-results-1.json') == audit, 'First audit and publication copy differ')
    require(len(audit['inputs']) == 378, 'Unexpected audited input population')
    for row in audit['inputs']:
        raw = data(row['path'])
        require(len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256'],
                'Audited input drift: ' + row['path'])

    source = read('candidate-source-final.json')
    release = read('release.json')
    require(source['base'] == BASE and len(source['files']) == 21, 'Source context differs')
    require(release['sha256'] == RELEASE_SHA and release['bytes'] == 3793624,
            'Release identity differs')
    require(release['source_manifest'] == 'candidate-source-final.json'
            and release['source_manifest_sha256'] == SOURCE_SHA, 'Release/source binding differs')
    require(digest('eris-js') == RELEASE_SHA and len(data(B / 'eris-js')) == release['bytes'],
            'Release bytes differ')

    plan = read('audit-preparation/validation-plan-final.json')
    require(plan['status'] == 'final announced results ready for independent audit'
            and plan['retained_failure_runs'] == [], 'Validation plan is not the final passing plan')
    labels = plan['focused_labels'] + [row['label'] for row in plan['full_runs']] + plan['gates']
    require(len(labels) == len(set(labels)) == 16, 'Validation command population differs')
    require({p.stem for p in (B / 'validation').glob('*.json') if p.name != 'source-ready.json'}
            == set(labels), 'Unexpected validation attempt')
    validation = {label: checked(label) for label in labels}
    for label, total in [('full-default-188-1', 1938), ('full-native-198-1', 2061)]:
        rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                          data(B / 'validation' / validation[label]['log']).decode())
        require([sum(int(row[i]) for row in rows) for i in range(3)] == [total, 0, 0],
                'Full-suite totals differ: ' + label)
        require(audit['validation']['full'][label]['totals'] == [total, 0, 0], 'Audit totals differ')
        require('--include-ignored' in validation[label]['command']
                and '--test-threads=4' in validation[label]['command'], 'Full-suite command differs')

    focused = read('focused-validation-review.json')
    require((focused['passed_observations'], focused['unique_names'], focused['failed_observations'],
             focused['new_groups']) == (286, 278, 0, 35), 'Focused totals differ')
    av = audit['validation']
    require((av['focused_observations'], av['focused_unique'], av['all_attempt_failures'],
             av['new_groups']) == (286, 278, 0, 35), 'Audit focused totals differ')
    require(av['source_manifest_sha256'] == SOURCE_SHA, 'Audit source differs')
    inventory = read('runtime/test-inventory.json')
    require(len(inventory['independent_groups']) == 16 and len(inventory['direct_groups']) == 17
            and inventory['new_runtime_groups'] == 33
            and inventory['root_browser_groups_separate'] == 2, 'New group inventory differs')
    diagnostic = 'NODE_POSITION_BOOTSTRAP steps=6599 allocated=1768914 objects=689 capacity=689 native=321 prototypes=25'
    require(diagnostic in data(B / 'validation/position-188-1.log').decode(), 'Bootstrap diagnostic absent')
    correction = read('bootstrap-correction/receipt.json')
    require(len(correction['files']) == 2 and sum(len(row['changes']) for row in correction['files']) == 3,
            'Descriptive correction population differs')
    schema_correction = read('audit-preparation/focused-summary-schema-correction/receipt.json')
    require(schema_correction['complete_reader'] is False
            and schema_correction['engine'] is False and schema_correction['compiler'] is False,
            'Reader correction execution context differs')

    comparison = read('position-comparison.json')
    require(comparison['validation_failures'] == [] and comparison['candidate']['sha256'] == RELEASE_SHA,
            'Comparison validation or release differs')
    summary = comparison['summary']
    for kind, total, unchanged, losses, before, after in [
        ('cases', 4364, 4362, 2, 4268, 4266), ('controls', 524, 520, 4, 504, 500)
    ]:
        require(summary['established'][kind] == dict(before_total=total, after_total=total,
                before_healthy=before, after_healthy=after, unchanged=unchanged, gains=0,
                losses=losses, other_changes=0), 'Established comparison differs: ' + kind)
    for kind, total, before in [('cases', 32, 0), ('controls', 16, 4)]:
        require(summary['new'][kind] == dict(before_total=total, after_total=total,
                before_healthy=before, after_healthy=total, unchanged=before, gains=total-before,
                losses=0, other_changes=0), 'New comparison differs: ' + kind)
    ac = audit['comparison']
    require(ac['summary'] == summary and ac['release_sha256'] == RELEASE_SHA
            and ac['profiles'] == 20 and ac['preserved_older_unhealthy_rows'] == 30
            and (ac['aggregate_exit'], ac['comparison_exit'], ac['classifier_exit']) == (1, 0, 0),
            'Audited comparison differs')
    classification = read('inventory-classification.json')
    require(classification['comparison_sha256'] == digest('position-comparison.json')
            and (classification['expected_case_losses'], classification['expected_unhealthy_controls'],
                 classification['unexpected_established_changes']) == (2, 4, 0), 'Classification differs')
    replay_rows = {name: row for name, row in audit['commands'].items() if name.endswith('-replay-command.json')}
    require(len(replay_rows) == 20 and sum(row['exit'] == 1 for row in replay_rows.values()) == 6,
            'Replay command outcomes differ')
    require(read('replay-execution.json')['exit'] == 1, 'Aggregate exit was changed')
    ci = read('connected-ci.json')
    require(ci['headSha'] == BASE and ci['conclusion'] == 'success' and len(ci['jobs']) == 9
            and all(row['conclusion'] == 'success' for row in ci['jobs']), 'Predecessor CI differs')

    result = dict(
        kind='Represented ordinary Node document position', base_commit=BASE,
        scope='Ordinary cached Node.prototype.compareDocumentPosition with required nonnullable authentic Node conversion, paid current ordinary-tree order and deterministic original-operand-ID order for disconnected nodes.',
        source=source, release=release, final_validation=validation,
        tests=dict(default=1938, native=2061, new_groups=35, independent_groups=16,
                   private_groups=17, browser_groups=2, independent_modes=32,
                   focused=focused, final_failed=0, final_ignored=0,
                   validation_commands=16, all_commands_passed_first_attempt=True,
                   full_test_threads=4),
        accounting=dict(remaining_bootstrap_work=6599, allocated_bytes=1768914,
                        objects=689, object_capacity=689, native_entries=321,
                        legacy_prototype_entries=25, additional_work=693,
                        additional_charged_bytes=3412, additional_objects=1,
                        scoped_native_work=60, scoped_native_bytes=64,
                        self_body_work=66, detached_body_work=118,
                        disconnected_body='118 + 29D + 4S',
                        ancestor_body='130 + 29D + 4S + 10A',
                        divergent_body='143 + 29D + 4S + 10A + 20J + 6L',
                        variables='D and S are summed over both complete paths; S counts scanned sibling slots; A is depth difference; J is paired ascent rounds; L is the selected common-parent child count.',
                        six_measured_geometry_body_work=[118, 249, 11138, 17003, 17014, 22179],
                        prototype_map_entries=29, prototype_preconstant_entries=11,
                        prototype_order_capacity=30, prototype_bulk_typed_nodes=4,
                        batch_work=10124, bootstrap_work_limit=100000,
                        author_work_limit=100000, cumulative_heap_limit=8388608,
                        numeric_limits_and_resets_changed=False),
        compatibility=dict(path='position-comparison.json', sha256=digest('position-comparison.json'),
                           summary=summary, replay_profiles=20, replay_nonzero_commands=6,
                           aggregate_exit=1, older_unhealthy_rows_unchanged=30,
                           inventory_classification=dict(path='inventory-classification.json',
                               sha256=digest('inventory-classification.json'), report=classification)),
        independent_audit=dict(path='independent-results-review.json', sha256=AUDIT_SHA,
                               original_path='audit-results-1.json', bound_inputs=378,
                               status='clear', complete_attempts=1, failed_complete_attempts=0),
        retained_history=[
            'The sole published-base baseline preceded implementation: 0/32 new ordinary cases and 4/16 healthy controls, with missing-method TypeError outcomes and no binding drift.',
            'Initial compilation and all 35 new groups passed. Successful measurement preceded three descriptive snapshot literal updates in two files. All 19 initially held source paths remain exact in the final 21-path source; no failing bootstrap attempt or production correction occurred.',
            'All 16 local validation commands passed on their first attempts, including both full suites with ignored tests and four test threads. Nine focused commands contain 286 passing observations and 278 unique test names.',
            'Before any complete data-only audit, its source was corrected to read the actual focused-summary field names and per-command log schema. The original reader, hold and exact source-only correction remain retained; Runtime code, test expectations and raw outcomes did not change.',
            'The first complete data-only audit passed with 378 bound inputs. No failed complete-audit attempt is part of this checkpoint.',
            'Six historical inventory profile commands and the aggregate retain exit 1. Thirty older unhealthy inventory rows remain unchanged. Two connected inventory cases newly fail with Error, and four connected controls are unhealthy TypeError observations; no health waiver or all-history-healthy claim applies.',
            'Six frozen historical JavaScript fixtures remain byte-exact. Private historical inventory wrappers use disposable realms and explicitly remove and restore newer configurable descriptors; the new independent fixture asserts the current 30-key prototype inventory.',
            'Preceding connected commit 53859161 has nine successful GitHub CI jobs. That evidence is separate from current candidate local validation.'
        ],
        tested_boundaries=[
            'Required nonnullable argument and authentic receiver ordering; canonical Document aliases; no authored coercion; argument-expression effects and throws occur before the read.',
            'Two literal 8-by-8 matrices cover all 128 ordered comparisons before and after reordering a mixed-depth tree. Six geometry witnesses cover both directions, exact work and one-short refusal, including accepted 256-edge snapshots and a separately added 257th ordinary parent edge.',
            'Malformed reached shape, backlinks, duplicate selected-child membership, endpoint and intermediate false canonical roots, and bounded cycles refuse explicitly on either complete walk. Same-ID local checks intentionally do not certify ancestors or off-path graph state.',
            'Separate first-walk, second-walk and final-sibling-scan terminal refusals retain prior authored effects and suppress catch/finally completion. Ignored extra-expression exhaustion occurs before native invocation. Small representative calls exercise every work cut; deep cases use exact and one-short endpoints.',
            'Saved native work/heap boundaries preserve metadata identity and execution cleanup; two live realms retain distinct cached metadata. Method body succeeds with exhausted owned-allocation allowance because it owns no traversal or payload storage.',
            'Page and confined-worker real-click witnesses preserve 22 captured IDs and create no click-time nodes. They check literal masks, saved and ordinary calls, the fcop move trace, template separation, reordered text, title/status, command order and a full literal reference canvas.'
        ],
        boundaries=[
            'No Attr, ShadowRoot, CDATA or independent document ownership support. Template content uses its ordinary fragment root, never its host association.',
            'Disconnected 35/37 direction follows the original canonical operand IDs after both complete root walks. It is a deterministic represented policy, not a portable cross-browser ordering guarantee.',
            'Reached-local validation is not a whole-arena graph validator. Wide sibling vectors can consume the unchanged work allowance; malformed or resource-heavy input is not promised successful traversal.',
            'Zero owned method-body traversal/payload storage does not remove generic VM, native-name, exception or inherited allocator costs. Existing getRootNode, isConnected, equality and predicate body fees remain unchanged.',
            'Logical accounting and functional validation do not establish a host performance gain, production-security guarantee or complete web compatibility.'
        ])
    for record in list(seen.values()):
        raw = Path(record['path']).read_bytes()
        require(len(raw) == record['bytes'] and hashlib.sha256(raw).hexdigest() == record['sha256'],
                'Post-read input drift: ' + record['path'])
    with (B / 'result.json').open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'path': str(B / 'result.json'),
                      'sha256': hashlib.sha256((B / 'result.json').read_bytes()).hexdigest()}))


if __name__ == '__main__':
    main()
