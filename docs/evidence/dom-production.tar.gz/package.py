import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def check(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def total(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(r[i]) for r in rows) for i in range(3)]
assert total('full-default-188-1')==[1577,0,0] and total('full-native-198-1')==[1700,0,0]
source=read('main-source-final.json')
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'final-source'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
old=read('compatibility-comparison.json');new=read('production-comparison.json')
assert sum(r['total'] for r in old)==4064 and sum(r.get('controls_total',0) for r in old)==364
assert new['original_gains']==8 and new['after_matched']==24 and new['controls_matched']==8
for row in old:
 assert not row.get('controls_changes')
 if row['profile']=='prior-CharacterData-regression':assert len(row['cases_changes'])==8 and row['after_verified']==34
 else:assert not row['cases_changes']
summary=dict(kind='Exact JavaScript CharacterData production',base_commit=source['base_commit'],scope='Text/Comment/PI constructors, Document text/PI factories, data setter and five CharacterData methods preserve exact UTF-16 through canonical owned storage; existing ERWA transport and resource limits unchanged.',source=source,release=release,final_validation={label:check(label) for label in ['full-default-188-1','full-native-198-1','clippy-native-198-1','clippy-presenter-188-1','format-198-final','release-adapter-188-1']},tests=dict(default=1577,native=1700,new_groups=25,focused_unique=105,focused_executions=107,failed=0,ignored=0),raw_bootstrap=read('source-ready.json')['bootstrap'],compatibility=old,new_production_cases={k:v for k,v in new.items() if k!='case_changes'},established_case_modes=4064,established_gains=8,established_losses=0,established_other_changes=0,established_controls_unchanged=364,new_case_modes=24,new_controls=8,retained_corrections=['Source-review correction of integration test private API calls; scalar reference setup now uses a public API and asserts complete literal payload/ledger.','First compile E0616: removed a redundant sibling-private test assertion; production, public visibility, no-partial-node checks and constructor override tests unchanged.','Initial worker command selected one ignored test; corrected command executed the unchanged confined test.','Replay negative control intrinsic Error identity corrected using adapter contract; all JS bytes and ordinary success expectations unchanged.','Replay uses optional observation reads to retain timeout/adapter-error rows; all32 inputs and complete baseline records unchanged.'],boundaries=['Legacy container textContent, innerText, title, textarea, append-string and attribute writes remain separate work.','Two original PI host-prototype mutation expectations remain unmet.','Exact nonscalar HTML serialization, unit-aware native editing, complete Node interfaces and mutation reactions remain incomplete.','No new GPU performance or Chromium comparison. Full web compatibility and production security are not achieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p==BASE/'eris-js' or p.is_symlink():continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/dom-production.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
(ROOT/'docs/evidence/dom-production.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
