import hashlib,json
from pathlib import Path
HERE=Path(__file__).resolve().parent
BEFORE=Path('/tmp/eris-dom-string-1')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def compare_rows(old,new,fields):
 def key(r):return (r['id'],r.get('mode',''))
 a={key(r):r for r in old};b={key(r):r for r in new}
 assert len(a)==len(old) and len(b)==len(new) and a.keys()==b.keys()
 changes=[]
 for k in a:
  for field in fields:assert a[k].get(field)==b[k].get(field),(k,field)
  old={f:a[k].get(f) for f in ['status','observation','reason','expected_negative']}
  new={f:b[k].get(f) for f in ['status','observation','reason','expected_negative']}
  if old!=new:changes.append(dict(id=k[0],mode=k[1],before=old,after=new))
 return changes
reports=[]
for name in ['dom-method-identity','object-is','symbols','array-descriptors','reflect-construction']:
 old=BEFORE/(name+'-after.json');new=HERE/(name+'-after.json');a=json.loads(old.read_text());b=json.loads(new.read_text())
 local='controls' in a
 for f in (['fixture_sha256','matrix_sha256','runner_sha256','tool_hashes','harness','bounds'] if local else ['revision','corpus_manifest_sha256','runner_policy_sha256','mode_cases']):assert a.get(f)==b.get(f),(name,f)
 fields=['case_sha256','source_sha256','expected_negative','expected_observation','expectation_sha256']
 changes=compare_rows(a['cases'],b['cases'],fields)
 control='controls' if local else 'harness_preflight'
 if local:
  controls=compare_rows(a[control],b[control],fields)
 else:
  assert [(r['name'],r['expected']) for r in a[control]]==[(r['name'],r['expected']) for r in b[control]]
  controls=compare_rows([r['result'] for r in a[control]],[r['result'] for r in b[control]],fields)
 reports.append(dict(profile=name,before_sha256=sha(old),after_sha256=sha(new),counts=b['counts'],total=len(b['cases']),cases_changes=changes,controls_changes=controls,controls_total=len(b[control]),controls_verified=b.get('controls_verified',b.get('harness_preflight_passed')),before_verified=a.get('fixture_expectations_verified'),after_verified=b.get('fixture_expectations_verified')))
local_a=json.loads((HERE/'local-before.json').read_text());local_b=json.loads((HERE/'local-after.json').read_text())
for field in ['runner_sha256','replay_sha256']:assert local_a[field]==local_b[field]
changes=compare_rows(local_a['cases'],local_b['cases'],['case_sha256','source_sha256','fixture_sha256','expected_observation','standard_final_utf16'])
reports.append(dict(profile='prior-CharacterData-regression',before_sha256=sha(HERE/'local-before.json'),after_sha256=sha(HERE/'local-after.json'),cases_changes=changes,total=len(local_b['cases']),before_verified=sum(r['matches_expectation'] for r in local_a['cases']),after_verified=sum(r['matches_expectation'] for r in local_b['cases']),unmet=[r['id'] for r in local_b['cases'] if not r['matches_expectation']]))
pi_old=BEFORE/'pi-regression-after.json';pi_new=HERE/'pi-regression-after.json'
a=json.loads(pi_old.read_text());b=json.loads(pi_new.read_text())
for field in ['runner_sha256','replay_sha256']:assert a[field]==b[field]
changes=compare_rows(a['cases'],b['cases'],['case_sha256','source_sha256','fixture_sha256','expected_observation'])
reports.append(dict(profile='prior-PI-regression',before_sha256=sha(pi_old),after_sha256=sha(pi_new),cases_changes=changes,total=len(b['cases']),before_verified=sum(r['matches_expectation'] for r in a['cases']),after_verified=sum(r['matches_expectation'] for r in b['cases'])))
with (HERE/'compatibility-comparison.json').open('x') as f:json.dump(reports,f,indent=2);f.write('\n')
for r in reports:print(r['profile'],r.get('after_verified'),r['total'],'case_changes',len(r['cases_changes']),'control_changes',len(r.get('controls_changes',[])))
