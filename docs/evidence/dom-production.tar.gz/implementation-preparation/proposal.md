# Exact runtime CharacterData production after the storage foundation

Preparation only. No repository edits, compiler, JavaScript execution, changed expectations, or measured gain. `inputs.json` binds the evolving foundation source read for this note. `literal-cases.json` proposes small independent witnesses, not an executed test population.

The first delivery should migrate Text/Comment construction, PI construction/factory data, `Document.createTextNode`, the CharacterData data setter and five methods. This covers the four preserved policy sources in both modes and lets the public constructors produce exact stored strings. It requires no new methods, descriptors, interface bags, quota increases, or worker protocol changes. The foundation already supplies canonical storage, exact reads, cloning and tagged snapshots.

The relevant standards require DOMString to retain the same code-unit sequence, including unmatched surrogates. CharacterData slicing and replacement use UTF-16 positions. Conversion of offset, count and data precedes the operation's fresh data/length snapshot. Append chooses the resulting current length. Constructor optional undefined defaults and the data setter's null-to-empty rule differ from ordinary DOMString conversion. PI creation validates the target and rejects consecutive `?>` in data; later CharacterData mutation does not rerun those creation checks. These are requirements, not conclusions drawn from this implementation. [Web IDL DOMString](https://webidl.spec.whatwg.org/#es-DOMString), [CharacterData](https://dom.spec.whatwg.org/#interface-characterdata), [Text](https://dom.spec.whatwg.org/#interface-text), [Comment](https://dom.spec.whatwg.org/#interface-comment), [PI creation](https://dom.spec.whatwg.org/#dom-document-createprocessinginstruction).

## Observed producer inventory

| Path | Foundation state | Proposed delivery |
| --- | --- | --- |
| `dom_prototypes.rs::dom_interface_construct`, Text/Comment | `string_hint`; two scalar passes reject unmatched units; then a second UTF8 retained copy through borrowed DOM constructors | Exact canonical builder, owned create APIs. Keep ToString before `newTarget.prototype` Get, fresh admission afterward, and sparse override publication last. |
| `processing_instruction.rs::pi_construct/pi_initialize` | target → data → prototype Get; XML Name and exact `?>` validation; scalar conversion of target and data | Keep scalar target and validation. Change only data payload building. Factory brand/arity and target → data order stay intact. |
| `dom_bindings.rs`, `createTextNode` | authentic Document/arity checks, then shared replacement-producing `dom_string`, borrowed scalar create | Use `string_hint` plus exact builder and owned create; retain brand/arity and add the same fresh checked node/storage admission as constructors. |
| `processing_instruction.rs::pi_native("setData")` | authentic CharacterData brand; raw null special case; scalar conversion rejects unmatched units | Exact builder; fresh replacement-aware admission; owned replacement once. Missing/undefined remains literal `undefined`. |
| `character_data.rs` methods | conversions already correctly ordered; `.scalar()` rejects stored Units; splice rejects unmatched final units | Read `DomString::units()`, canonicalize complete splice, retain exact substring output. |
| `dom_bindings/append.rs` | converted `AppendValue::Text(String)` uses lossy shared helper; later creates detached text, then assembles fragment/moves | Defer separately. Changing the shared helper alone would miss owned staging, fresh per-node costs and partial-prefix effects. |
| legacy `script.rs` textContent/innerText/title setters | lossy scalar conversion; clear/replace container logic, legacy ignored-kind behavior | Defer. Exact storage does not fix inherited accessor/default/nullability/children-change semantics automatically. |
| textarea value | lossy scalar conversion followed by UTF8 CRLF/CR normalization and scalar text replacement | Defer exact-unit normalization with existing editor/form coupling. Avoid a blanket string-helper change. |
| innerHTML assignment | lossy conversion → scalar HTML tokenizer/fragment parser | Defer parser-input policy; exact character-data storage is not an exact UTF16 HTML tokenizer. The new strict read serializer is a separate boundary. |
| attributes/className/id/title/value/href/src/type/details name; selectors and tokens | shared lossy strings or explicit `to_utf8_lossy`, scalar attribute/URL/style storage | Defer. No claim that these IDL surfaces now preserve unmatched units. |

`Node.nodeValue` accessor migration, title normalization, innerText layout semantics, native editor text production, form serialization and PI pseudo-attributes remain separate work. Clone/import must continue moving exact owned payloads without creation-time PI validation.

## One paid canonical builder

Use one runtime-owned builder over a repeatable, allocation-free UTF16 iterator. For an ordinary converted `JsString`, pass its borrowed units directly. For mutation, pass a cloneable prefix/insertion/suffix chain. Keep author conversion outside the builder: it performs no callbacks, document writes or metadata changes.

1. Prepay the bounded iterator traversal and decoding before classifying. Count all result units and scalar UTF8 bytes with checked arithmetic; record whether any unmatched unit occurs. Continue to account for the entire result, including data after the first unmatched unit.
2. Choose exactly one payload: scalar UTF8 bytes for well-formed output, otherwise checked `2 * result_units` bytes. Check operation-specific DOM/node/replacement bounds against this chosen size before reserving. A scalar U+FFFD occupies three bytes; one unmatched code unit occupies two. UTF8 estimates must not stand in for the retained Units charge.
3. Prepay the repeat traversal/output writes and charge the chosen payload allocation. Use `try_reserve_exact`. Scalar output emits directly into a String and moves through `DomString::from(String)`; it must not first allocate a full UTF16 Vec. Nonscalar output emits directly into a Vec and moves through existing crate-private `from_nonscalar_units`.
4. Prepay the latter constructor's separate allocation-free canonicality validation (up to the entire Vec). Do not silently treat the first scan as paying both scans. No new unchecked representation constructor is necessary.
5. Publish only after all work, heap, DOM storage, typed node-vector growth and optional override-map admission succeed. Existing monotonic script heap accounting still charges a temporary allocated before a later refusal. No quota refund/reset is introduced.

A small `plan`/`emit` split allows the fresh DOM byte check between classification and allocation without building a rejected payload. The plan is private and valid only for the unchanged borrowed iterator with no intervening callback. Avoid a cached plan surviving author code. Whole constructors can finish ToString and prototype Get first, then plan and emit; this removes only the old internal representability refusal and redundant copy, not an observable conversion.

Preserve every unaffected base/storage debit. Remove the Text/Comment extra UTF8-copy work/storage only when replacing `create_text_node(&text)`/`create_comment(&text)` with their owned counterparts actually eliminates that copy. Object headers, real node-vector moves, logical node cap, override map and callback work remain charged. PI target still allocates its validated scalar representation separately.

## Exact splices and bounded scans

After all Web IDL conversions, borrow the fresh current `DomString`. Determine current unit length with an explicitly paid pass for mutation; apply the existing wrapping unsigned-long conversion and IndexSizeError rules. Compute `end` and result size with checked arithmetic. Recreate the complete stream as `old.units().take(offset) + inserted.units() + old.units().skip(end)`.

Canonicality is a property of that complete stream. An inserted low unit can pair with a retained high unit; deletion can join previously separated units; existing unmatched units can survive elsewhere. Never scalar-convert the insertion in isolation, reject an unmatched retained prefix early, or project either operand through U+FFFD.

For the existing two-old-iterator splice implementation, `old.stored_bytes()` bounds each full old-unit traversal for both storage variants. Retain the separately paid old-length pass. A reviewed per-pass bound must cover two old traversals, insertion visits, combined decode/control work and output writes; the final nonscalar validation is additional. Preserve existing coefficients where those loops remain, rather than changing global fee units. Avoid unchecked `offset + count`, `2 * units` or byte sums.

Substring keeps the current reached-only first pass, including charged EOF attempts. Replace `encode_utf16()` with `.units()`; keep the bounded second traversal and exact Vec→Rc storage/copy admission. Do not add a full-data classification/length scan: a small substring of a large valid DOM payload must retain its existing bounded path. Its returned JS result is constrained by `MAX_STRING`; whole DOM mutation is governed by DOM storage limits, not a newly imposed `MAX_STRING` limit on preexisting parser data. The scalar parser-expanded 18 MiB snapshot remains legal and is not made a constructible 18 MiB node by this proposal.

## Preserved observations and focused validation

The four original policy sources and their hashes remain unchanged; `inputs.json` records the expected final unit arrays separately. Do not overwrite their historical Unsupported results. A new execution receipt can record eight successful modes and private exact-data postchecks. Keep all thirteen existing ordinary cases and callback witnesses intact.

New small literal witnesses should cover unmatched constructor/factory data; null/undefined setter distinctions; substring from Units; repair at either boundary and across deletion; retention of unrelated unmatched units; and PI exact validation versus later `?>` data. Use the literals in `literal-cases.json`. Add independent private storage checks for canonical variant, payload bytes and replacement-aware ledger, not assertions computed by the production builder.

Retain deterministic exact/one-short work/heap tests and fresh callback-induced DOM/node/override exhaustion tests. Failures must leave no outer node/map/data publication while keeping the author callback's earlier mutations. Verify saved native accessors and method metadata still match the foundation; do not use a metadata reinstall to introduce this behavior. A small exact snapshot round trip after JS production can reuse the foundation codec, without another wire-version change.

This proposal does not extend MutationObserver/Range updates, PI pseudo-attributes, XML-name policy, HTML serialization of unmatched units, or all other scalar-only host interfaces.
