# Runtime exact CharacterData implementation handoff

Source-only review of `proposal.md` (`fb3fe0651cc028a4bbdce1e2f4d3795d09de75746ab8f8bdefc49fa7e13dfbb8`) against the held foundation. The plan is viable. No code, compiler, replay, policy source, expectation, metadata or quota changed for this review. The first delivery should include precisely the producers listed in the proposal; legacy append/container/attribute/HTML-parser writes remain separate.

## Small shared builder

Add `src/script/dom_data.rs`, declared by `script.rs`. Keep its fields private and expose only these sibling-visible seams:

```rust
pub(super) struct DomDataPlan<I> { /* original iterator, exact units,
    chosen encoding/bytes, bounded source-pass work */ }
impl<I> DomDataPlan<I> {
    pub(super) fn stored_bytes(&self) -> usize;
}
impl Runtime {
    pub(super) fn plan_dom_data<I>(
        &mut self, input: I, result_units: usize, source_work: usize,
    ) -> Result<DomDataPlan<I>>
    where I: Iterator<Item = u16> + Clone;

    pub(super) fn emit_dom_data<I>(
        &mut self, plan: DomDataPlan<I>,
    ) -> Result<crate::dom::DomString>
    where I: Iterator<Item = u16> + Clone;
}
```

The plan retains the original iterator and emits from it; emit cannot receive another source accidentally. All callers use borrowed slices or `DomUnits` plus `take/chain/skip`. Never pass author-defined iterators or retain a plan across author callbacks. Classification consumes a clone, decodes the complete result, counts exact consumed UTF16 units and checked UTF8 bytes, and records whether any isolated unit occurred. Check its unit count against the supplied trusted bound. Decode errors are data, not a refusal. Continue after the first error. Empty output is canonical Scalar with no payload allocation.

For a well-formed result, reserve one String and emit UTF8 directly. Otherwise reserve one Vec<u16>, copy the original exact stream and move through `DomString::from_nonscalar_units`. Do not use `from_units_owned` for the scalar branch: that would allocate a staging Vec and another String. No new unchecked DomString constructor or second cache is needed.

## Explicit fee schedule

Use checked arithmetic throughout. These are the proposed logical-operation debits, not CPU-instruction counts. Let R be exact result units, S the paid bound for one traversal of the source iterator, B the selected retained bytes, and P = S + 2R + 8. The `2R` covers combined decode/control/classification; eight covers fixed iterator/EOF and plan checks.

| Stage | Work before the stage | New heap charge |
| --- | --- | --- |
| Classify full stream | P | 0 |
| Emit Scalar | P + B | B before `try_reserve_exact(B)` |
| Emit Units | S + R + 8 (source traversal plus u16 writes) | 2R before `try_reserve_exact(R)` |
| Validate emitted Units canonicality | 2R + 1 before `from_nonscalar_units` | 0; buffer moves |

The Units validation may stop at its first isolated unit; the full bound is conservative and receives no refund. Its scan must not be silently absorbed into the already consumed classification allowance. Local plan/iterator/String/Vec headers are stack values; no new heap header allowance is needed. Historical runtime charges remain cumulative if a later charge/reserve/publication refuses.

For a borrowed JsString, R = text.len() and S = R. For splice, let A = old.stored_bytes(), I = inserted.len(), U = the freshly measured old unit length, and D = clipped deletion: R = U - D + I; S = 2A + I. Preserve the existing separate `1 + A` old-length debit. Thus the existing scalar splice bounds P = 2A + I + 2R + 8 and P+B remain numerically unchanged. Scalar UTF8 decoding visits are bounded by A; Units has U=A/2. The two-old-iterator bound includes prefix traversal and the suffix iterator's skip from zero. Changing the ordinary converted-string builder to this explicit shared schedule can change its operation cost; record it transparently rather than pretending the former `1+len` scan paid these extra stages.

All existing conversion/dispatch/brand, node logical allowance, real arena relocation, override-map and publication charges remain. Remove only eliminated Text/Comment/createTextNode retained-copy charges after switching to owned publication; the builder pays the single remaining buffer. PI target continues using its existing paid scalar converter after XML Name validation.

## Fresh admission and ordering

Creation uses existing `admits_text_node(chosen_bytes)` after every conversion and newTarget getter; for PI use checked `target_utf8_bytes + data_plan.stored_bytes()`. Admit before data allocation, then preserve typed node-vector and optional override-map precharges before publication. The checked owned DOM APIs repeat the final limit checks and move buffers. Default prototype elision and real brands remain unchanged. Reserving spare arena capacity before a later terminal refusal may change capacity, but must publish no node or override.

A narrow DOM helper is useful to reject replacement size before allocating its payload:

```rust
pub(crate) fn check_character_data_replacement(
    &self, id: NodeId, stored_bytes: usize,
) -> Result<usize, DomDataError>; // returns checked next retained-byte total
```

Extract the current authentic-kind, MAX_TEXT and `retained_bytes - old.stored_bytes() + new_bytes` checks from `replace_character_data`. Call this helper before emit and again from final replacement; do not duplicate private DOM limits in script. Preserve the existing eight-unit final publication debit and add an eight-unit debit before the additional read-only admission. No callback may run between these checks. This is the only proposed new DOM API; owned Text/Comment/PI publication already exists.

Text/Comment: convert the optional argument once (missing/undefined => empty), obtain newTarget.prototype, then plan/admit/emit/publish. This moves internal allocation and scalar checks after the getter; conversion order stays observable and lone-unit conversion no longer rejects prematurely. PI retains target conversion → data conversion → newTarget.prototype → XML Name validation → exact adjacent `?>` check; the factory omits the newTarget step. Then build scalar target and exact data. Setter authentic brand precedes conversion; raw null alone becomes empty, missing/undefined becomes `undefined`. Methods retain offset → count → data conversions, then read current data and length; append uses that fresh length. PI mutation never repeats creation-only target/`?>` checks.

## Substring remains a separate reached-prefix operation

Change the input from `&str` to `&DomString` and `encode_utf16()` to `units()`. Preserve eight work per attempted first-pass `next`, including EOF, and the existing second-pass `8*(offset+selected)+selected+1` plus `64+4*selected` Vec/Rc charge. Preserve MAX_STRING on the returned JS value only. No builder/classification/full-length pass belongs here. Test a one-unit substring of a host-supplied large Units value as well as the existing large Scalar case. Offset=end/count=0 and offset>length retain their distinct results.

## Paths and bounded validation

Production paths: new `script/dom_data.rs`; `script.rs` module declaration only; `script/dom_prototypes.rs` Text/Comment construction; `script/processing_instruction.rs` PI data and setter; `script/processing_instruction/character_data.rs`; `script/dom_bindings.rs` createTextNode; `dom.rs` read-only replacement admission shared with publication. No installer, descriptor inventory, wire version or bootstrap reservation change is needed. Raw bootstrap descriptive observations should remain unchanged, but measure rather than rewrite assertions in advance.

Keep the thirteen ordinary CharacterData cases, all original PI/constructor cases and all four policy source byte strings in both modes. Their historical terminal results remain retained evidence; the eight new observations must use the original standard success expectations plus literal final-unit checks. Preserve the original policy JSON and source hashes. Updating private tests that specifically asserted the old implementation restriction must be explicit, without relabeling those old outcomes.

Add focused witnesses for Scalar↔Units transitions and retained bytes, all producer defaults, complete-splice repair versus isolated units elsewhere, exact PI validation followed by unrestricted data mutation, and fresh callback-induced node/byte exhaustion. Measure exact/one-short work and heap at builder and public-operation boundaries; assert no outer node/data/override publication and preserved callback prefixes. Include whole traversal after a first isolated unit so a late work refusal cannot produce truncated success. Verify one owned payload and snapshot/clone exactness. Preserve existing constructor metadata/brand tests and the fixed 100,000-work/8MiB runtime limits. No success or cost result is predicted before execution.
