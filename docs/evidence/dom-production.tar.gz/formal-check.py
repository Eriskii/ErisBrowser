import hashlib,json,subprocess,sys,time
from pathlib import Path
root=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');out=Path(__file__).parent
profile=sys.argv[1];argv=['python3','tools/test262_conformance.py','--binary',str(out/'eris-js'),'--profile',profile,'--baseline','tests/conformance/test262-'+profile+'-current.json','--output',str(out/(profile+'-after.json'))]
log=out/(profile+'-after.log');start=time.monotonic()
with log.open('xb') as f:r=subprocess.run(argv,cwd=root,stdout=f,stderr=subprocess.STDOUT)
receipt=dict(command=argv,exit=r.returncode,elapsed_seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
with (out/(profile+'-command.json')).open('x') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt));print(log.read_text()[-2000:]);raise SystemExit(r.returncode)
