import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
sys.path.insert(0,str(ROOT/'tools'))
import test262_conformance as runner
HERE=Path(__file__).resolve().parent
prep=HERE/'independent-preparation'
fixture=(prep/'dom-production-cases.js').read_bytes()
assert hashlib.sha256(fixture).hexdigest()=='a3e376359b7fb74bc74e43b90ec2ecaa9972aeda2effbd6f50ae8382ee61d5f2'
inventory=json.loads((prep/'cases.json').read_text())
complete=dict(status='complete',phase='runtime',error_type='',error_identity='')
wrong=dict(status='exception',phase='runtime',error_type='Error',error_identity='Error')
inputs=[]
for row in inventory['cases']:
 source=fixture+b'\nif(domProductionCases.'+row['id'].encode()+b'() !== true) throw new Error("case did not return true");'
 inputs.append((row['id'],source,complete,'case'))
for name,source in [('literal-unit',br"if('\ud800'.charCodeAt(0)!==55296) throw new Error('literal');"),('saved-error',b"var marker={};var caught;try{throw marker;}catch(e){caught=e;}if(caught!==marker)throw new Error('identity');")]:
 inputs.append((name+'-positive',source,complete,'control'))
 inputs.append((name+'-wrong',source+b"throw new Error('deliberately wrong expectation');",wrong,'control'))
matrix=[]
for name,body,expected,kind in inputs:
 for mode in ('sloppy','strict'):
  case=dict(id=name+'#'+mode,file='dom-production-cases.js' if kind=='case' else 'controls',mode=mode,source=body,metadata=dict(flags=[],features=[],includes=[],locale=[],negative=None),harness=[])
  case['case_sha256']=runner.case_fingerprint(case)
  matrix.append((case,dict(id=case['id'],mode=mode,source_sha256=hashlib.sha256(body).hexdigest(),case_sha256=case['case_sha256'],expected_observation=expected,kind=kind)))
frozen=dict(fixture_sha256=hashlib.sha256(fixture).hexdigest(),inventory_sha256=hashlib.sha256((prep/'cases.json').read_bytes()).hexdigest(),replay_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),runner_sha256=hashlib.sha256(Path(runner.__file__).read_bytes()).hexdigest(),rows=[r for c,r in matrix])
freeze=HERE/'production-replay-matrix.json'
if sys.argv[1]=='--prepare':
 with freeze.open('x') as f:json.dump(frozen,f,indent=2);f.write('\n')
 print('Frozen 24 case modes and 8 controls before engine execution')
 raise SystemExit
assert frozen==json.loads(freeze.read_text())
binary=Path(sys.argv[1]).resolve();output=Path(sys.argv[2]);sha=hashlib.sha256(binary.read_bytes()).hexdigest()
records=[]
for case,row in matrix:
 result=runner.run_case(case,binary,3);result.update(row)
 result['matches_expectation']=all(result['observation'].get(k)==v for k,v in row['expected_observation'].items())
 records.append(result)
assert sha==hashlib.sha256(binary.read_bytes()).hexdigest()
record=dict(binary_sha256=sha,matrix_sha256=hashlib.sha256(freeze.read_bytes()).hexdigest(),**{k:v for k,v in frozen.items() if k!='rows'},cases=[r for r in records if r['kind']=='case'],controls=[r for r in records if r['kind']=='control'])
with output.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(dict(cases=sum(r['matches_expectation'] for r in record['cases']),total=len(record['cases']),controls=sum(r['matches_expectation'] for r in record['controls']),unmet=[dict(id=r['id'],observation=r['observation']) for r in records if not r['matches_expectation']]),indent=2))
