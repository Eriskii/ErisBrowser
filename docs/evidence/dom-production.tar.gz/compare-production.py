import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
a=json.loads((root/'production-before.json').read_text());b=json.loads((root/'production-after.json').read_text())
for field in ['matrix_sha256','fixture_sha256','inventory_sha256','replay_sha256','runner_sha256']:assert a[field]==b[field]
changes=[]
for category in ['cases','controls']:
 assert len(a[category])==len(b[category])
 for x,y in zip(a[category],b[category]):
  for f in ['id','mode','source_sha256','case_sha256','expected_observation','kind']:assert x[f]==y[f]
  if x.get('observation')!=y.get('observation') or x['status']!=y['status']:
   changes.append(dict(id=x['id'],category=category,before=x,after=y))
  assert y['matches_expectation']
assert len(changes)==22 and all(r['category']=='cases' and not r['before']['matches_expectation'] and r['after']['matches_expectation'] for r in changes)
old=json.loads((root/'compatibility-comparison.json').read_text());assert sum(r['total'] for r in old)==4064
for r in old:
 assert not r.get('controls_changes')
 if r['profile']=='prior-CharacterData-regression':
  assert r['before_verified']==26 and r['after_verified']==34 and len(r['cases_changes'])==8
  for c in r['cases_changes']:
   assert c['before']['observation']['status']=='unsupported' and c['after']['observation']['status']=='complete'
 else: assert not r['cases_changes']
report=dict(before_sha256=sha(root/'production-before.json'),after_sha256=sha(root/'production-after.json'),matrix_sha256=b['matrix_sha256'],before_matched=2,after_matched=24,total=24,controls=8,controls_matched=8,case_changes=changes,original_compared_modes=4064,original_gains=8,original_losses=0,original_other_changes=0,original_controls_unchanged=364)
(root/'production-comparison.json').write_text(json.dumps(report,indent=2)+'\n')
print('Established 4064 modes:8gains,no losses/other changes;364controls unchanged. New24 modes:2->24;8controls verified.')
