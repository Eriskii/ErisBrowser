from pathlib import Path
import json,hashlib
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OUT=Path('/tmp/eris-dom-production-1/documentation')
changes={}
def edit(name, old, new):
 s=changes.get(name,(ROOT/name).read_text())
 assert s.count(old)==1,(name,old[:80],s.count(old))
 changes[name]=s.replace(old,new)
edit('README.md','''[DOM string foundation](docs/dom-strings.md) now preserves exact character data
in canonical storage, tagged worker transport, host-supplied reads and clones.
JavaScript production of unpaired data remains deferred; the eight earlier
CharacterData standards-success modes remain unmet pending replay. Complete
interface members and Document reflection remain unfinished.''','''[DOM string foundation](docs/dom-strings.md) preserves exact character data
in canonical storage, tagged worker transport, reads and clones.
[Exact JavaScript data production](docs/dom-production.md) now covers Text,
Comment and PI constructors, the PI and text factories, the data setter and all
five CharacterData methods, including unpaired units and complete-splice repairs.
Final release replay of the eight earlier unmet modes is pending. Legacy
container/attribute writes, complete interface members and Document reflection
remain unfinished.''')
edit('README.md','''[Exact character-data storage](docs/dom-strings.md) is now available, but
runtime write paths and broader DOMString/Web IDL interfaces remain incomplete.''','''[Exact character-data production](docs/dom-production.md) now covers the named
constructors, factories, data setter and CharacterData methods. Legacy container,
append-string and attribute writes, HTML parser input and broader DOMString/Web
IDL interfaces remain incomplete.''')
edit('docs/COMPATIBILITY.md','''the Document factory, target and CharacterData data/length accessors for scalar
strings. Five [CharacterData methods](character-data.md) now add exact UTF-16
substring results and checked splicing, including repaired surrogate boundaries.
The [DOM string foundation](dom-strings.md) preserves host-supplied unpaired
units in Text, Comment and PI data, exact reads/clones and ERWA snapshots.
JavaScript constructors, setters and mutation paths have not yet migrated to
producing that data: the eight earlier standards-success modes remain unmet
pending replay.''','''the Document factory, target and CharacterData data/length accessors.
[Exact data production](dom-production.md) covers Text, Comment and PI
constructors, `createTextNode`, the PI factory and the data setter. Five
[CharacterData methods](character-data.md) preserve exact UTF-16 substring and
splice results, including isolated units and repaired boundaries. The
[DOM string foundation](dom-strings.md) supplies canonical storage, exact
reads/clones and unchanged ERWA snapshots. Final release replay of the eight
earlier standards-success modes remains pending.''')
edit('docs/COMPATIBILITY.md','''conversion rules. Exact character-data storage is described in
[DOM strings](dom-strings.md); legacy author write paths, remaining interface
members, general XML name handling, live collections and complete DOM hierarchy
semantics remain incomplete.''','''conversion rules. [Exact character-data production](dom-production.md) covers
its named constructors, factories, data setter and five methods. Legacy container,
append-string, attribute and HTML-parser writes remain separate, alongside
remaining interface members, general XML name handling, live collections and
complete DOM hierarchy semantics.''')
edit('docs/COMPATIBILITY.md','''data/length accessors, selected text readers and cloning preserve host-supplied
units. Presentation explicitly replaces unmatched units without changing storage.
Attributes, console output and other scalar host boundaries remain separate;
legacy writes can still replace unpaired units, and CharacterData production
still refuses them. Inline JavaScript source and JavaScript HTML serialization
explicitly refuse a nonscalar aggregate. This is not complete DOMString support.''','''data/length accessors, selected text readers and cloning preserve units from
[JavaScript CharacterData production](dom-production.md), the host or transport.
Presentation explicitly replaces unmatched units without changing storage.
Attributes, console output and other scalar host boundaries remain separate;
legacy container, append-string and HTML-parser writes can still replace unpaired
units. Inline JavaScript source and JavaScript HTML serialization explicitly
refuse a nonscalar aggregate. This is not complete DOMString support.''')
edit('docs/ROADMAP.md','''append, insert, delete and replace operations. The [DOM string foundation](dom-strings.md)
now supplies canonical Scalar/Units storage, tagged ERWA transport and exact
host-supplied reads/clones. The next runtime migration must preserve units through
constructors, setters and complete splices; the eight earlier standards-success
modes remain unmet pending replay. Legacy container/attribute writes, unit-aware
native editing, nonscalar source/HTML serialization, PI pseudo-attributes,
remaining Node/Text operations and mutation notifications remain open work.''','''append, insert, delete and replace operations. [Exact runtime production](dom-production.md)
now preserves units through the named Text/Comment/PI constructors, factories,
data setter and complete splices. It uses the [DOM string foundation](dom-strings.md)
for canonical storage, unchanged ERWA transport and exact reads/clones. Final
release replay of the eight earlier unmet modes is pending. Legacy container,
append-string and attribute writes, unit-aware native editing, nonscalar
source/HTML serialization, PI pseudo-attributes, remaining Node/Text operations
and mutation notifications remain open work.''')
edit('docs/ROADMAP.md','''Window extensibility and interface coverage, exact DOMString runtime production
and remaining Web IDL interfaces, remaining Symbol and iterator consumers, and broader''','''Window extensibility and interface coverage, exact DOMString production through
remaining legacy container/attribute/parser paths, remaining Web IDL interfaces,
remaining Symbol and iterator consumers, and broader''')
edit('docs/SECURITY.md','''ordinary own-property bags remain separate. These JavaScript constructor paths
still reject lone UTF-16 surrogates; the new [storage foundation](dom-strings.md)
does not yet migrate their production. Work limits and cumulative heap limits
are unchanged; the larger bootstrap object reservation is charged in full.''','''ordinary own-property bags remain separate. Text and Comment now use the
[exact data builder](dom-production.md) after conversion and prototype callbacks,
then move one admitted canonical payload into checked owned storage. Work limits
and cumulative heap limits are unchanged; the existing bootstrap object
reservation remains charged in full.''')
edit('docs/SECURITY.md','''publishing nodes or alternate prototypes. The current JavaScript writers still
produce scalar buffers and refuse lone-surrogate data. Checked owned storage
now also accepts canonical exact UTF-16 supplied by the host or transport.
Replacement admission subtracts the previous payload and refuses excess input
without truncation or partial mutation. Existing infallible Rc and B-tree
allocations remain.''','''publishing nodes or alternate prototypes. The scoped JavaScript data producers
classify the complete UTF-16 stream and allocate either one scalar UTF-8 payload
or one exact UTF-16 payload. PI targets keep their separate XML Name validation
and scalar storage. Replacement admission subtracts the previous payload and
refuses excess input without truncation or an outer data write. Existing
infallible Rc and B-tree allocations remain.''')
edit('docs/SECURITY.md','''and admits the selected UTF-16 result before allocation. Mutations prepay scans,
validate the complete UTF-16 splice, reserve exact scalar output and move it
through checked replacement. A terminal refusal preserves existing outer data
and earlier author effects; these JavaScript mutation paths still refuse final
lone-surrogate strings pending runtime migration.''','''and admits the selected UTF-16 result before allocation. Mutations prepay the
old-length pass and complete-splice classification, then reserve and emit the
chosen scalar or exact-unit payload. The Units path also pays its separate
canonicality validation. Fresh replacement admission precedes allocation and is
rechecked at publication. A terminal refusal leaves the outer write unpublished;
earlier author effects and cumulative temporary-allocation charges remain.''')
edit('docs/SECURITY.md','''The legacy conversion paths covered by that historical record still replace
unpaired units. [Exact character-data storage](dom-strings.md) does not yet
migrate every JavaScript writer or scalar host boundary.''','''Some legacy conversion paths covered by that historical record still replace
unpaired units. [Exact character-data production](dom-production.md) migrates the
named constructors, factories, data setter and five methods; container,
append-string, attribute and HTML-parser writes and scalar host boundaries remain
separate work.''')
edit('docs/dom-strings.md','''This is a storage and consumer foundation. JavaScript constructors, setters and
mutation methods have not yet migrated to exact nonscalar production. Older
legacy writes can still replace unmatched units; newer CharacterData writes
still refuse them. The eight existing [CharacterData](character-data.md)
standards-success modes remain unmet in the final release replay. Their original sources and
historical refusal records are preserved. This change does not establish full
DOMString compatibility, production security or Chromium performance parity.''','''This page describes the storage and consumer foundation. The subsequent
[JavaScript production increment](dom-production.md) uses it for Text, Comment
and PI construction, the PI/text factories, the data setter and five
CharacterData methods. Other legacy writes can still replace unmatched units.
The foundation release retained eight unmet CharacterData standards-success
modes; their original sources and refusal records remain historical evidence.
Final release validation of the new producer scope is pending. Neither increment
establishes full DOMString compatibility, production security or Chromium
performance parity.''')
edit('docs/dom-strings.md','''The final source passes 1,552 default tests on Rust 1.88 and 1,675 Vulkan-feature
tests on Rust 1.98, including confinement checks. All 4,064 compared case modes
and 364 controls retain their observations and expectations.''','''At the storage-foundation checkpoint, 1,552 default tests passed on Rust 1.88 and
1,675 Vulkan-feature tests passed on Rust 1.98, including confinement checks.
All 4,064 compared case modes and 364 controls retained their observations and
expectations. These counts describe that checkpoint, not the later producer
increment.''')
edit('docs/character-data.md','''length limit; traversal is bounded by the unchanged work allowance. Mutations
validate the complete splice before publishing scalar output. A retained
unit and an inserted unit may repair a pair. These runtime methods still require
scalar data in the target node and refuse a final unpaired sequence, with the outer write
refused. This is an implementation gap, not a DOM exception required by the
standard.

The [DOM string foundation](dom-strings.md) now stores host-supplied unpaired
units canonically and preserves them through data/length getters, selected text
reads, cloning and ERWA snapshots. It does not yet migrate these five methods or
the JavaScript constructors/setters to produce exact nonscalar data. The eight
existing standards-success modes remain unmet pending their next replay; their
sources and historical refusal observations remain unchanged.''','''length limit; traversal is bounded by the unchanged work allowance. The
[exact production increment](dom-production.md) now reads scalar and exact-unit
node data directly. Mutations classify the complete splice before choosing
canonical scalar or exact-unit storage. A retained unit and an inserted unit may
repair a pair; deletion may join formerly separated units. Unmatched units
elsewhere survive unchanged, and the insertion is never decoded in isolation.

The [DOM string foundation](dom-strings.md) preserves the result through exact
data/length getters, selected text reads, cloning and unchanged ERWA snapshots.
The eight original standards-success modes retain their source bytes and literal
unit expectations; final release replay is pending. Their earlier Unsupported
observations remain historical evidence, not a new expected outcome.''')
edit('docs/processing-instruction.md','''The JavaScript creation/setter paths still convert to scalar strings. Checked
storage now also takes ownership of canonical exact UTF-16 from the host or
transport, with two retained bytes per stored unit. Admission failure
refuses the operation instead of truncating data.''','''[Exact JavaScript data production](dom-production.md) now preserves unpaired
UTF-16 units through PI creation and the CharacterData data setter. Complete data
chooses one scalar UTF-8 payload or one exact UTF-16 payload, with two retained
bytes per unit in the latter. PI target validation remains separate. Admission
failure refuses the operation instead of truncating data.''')
edit('docs/processing-instruction.md','''This is partial CharacterData/ProcessingInstruction support. JavaScript data
production still explicitly refuses lone UTF-16 surrogates, although the
[storage foundation](dom-strings.md) now preserves host-supplied units in reads,
clones and tagged snapshots. Lone surrogates in a target remain invalid XML
names.''','''This remains partial CharacterData/ProcessingInstruction support. Exact data
production does not make unmatched units valid in PI targets: those remain
invalid XML names. The [storage foundation](dom-strings.md) keeps data exact in
reads, clones and tagged snapshots.''')
edit('docs/processing-instruction.md','''mutation methods with exact UTF-16 substring results and checked scalar storage.''','''mutation methods with exact UTF-16 substring results and checked canonical
scalar or exact-unit storage. Final producer release replay is pending.''')
def rec(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
for name,text in changes.items():
 p=OUT/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
(OUT/'base-inputs.json').write_text(json.dumps([rec(ROOT/p) for p in changes],indent=2)+'\n')
