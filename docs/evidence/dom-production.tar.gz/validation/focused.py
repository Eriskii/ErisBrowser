import pathlib,subprocess,sys
here=pathlib.Path(__file__).parent
checks=[
('builder-188-1',['--lib','script::dom_data::']),
('pi-character-data-188-1',['--lib','script::processing_instruction::']),
('constructors-188-1',['--lib','dom_constructor']),
('factory-188-1',['--lib','create_text_node_']),
('dom-admission-188-1',['--lib','character_data_preallocation_check']),
('dom-recheck-188-1',['--lib','character_data_publication_rechecks']),
('bootstrap-188-1',['--lib','bootstrap']),
('pipeline-188-1',['--test','pipeline','exact_dom_production']),
('worker-188-1',['--test','worker','confined_exact_dom_production']),
]
for name,args in checks:
 result=subprocess.run([sys.executable,str(here/'run.py'),name,*args,'--','--nocapture'])
 if result.returncode:raise SystemExit(result.returncode)
