import hashlib,json,os,pathlib,subprocess,sys,time
root=pathlib.Path('/tmp/eris-dom-production-1/worktree')
out=pathlib.Path(__file__).parent
name=sys.argv[1];args=sys.argv[2:]
env=os.environ.copy();env.update(CARGO_BUILD_JOBS='2',CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR='/tmp/eris-dom-own-properties-1/target')
env['PATH']='/tmp/eris-vulkan-rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
command=['cargo','test','--offline']+args
log=out/(name+'.log');receipt=out/(name+'.json')
if log.exists() or receipt.exists():raise SystemExit('Refusing to overwrite a prior attempt')
start=time.monotonic()
with log.open('wb') as f: result=subprocess.run(command,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
record={'command':command,'cwd':str(root),'environment':{key:env[key] for key in ['CARGO_BUILD_JOBS','CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','PATH']},'exit_code':result.returncode,'seconds':round(time.monotonic()-start,3),'log':str(log),'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
receipt.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True);sys.exit(result.returncode)
