from pathlib import Path
import ast, collections, hashlib, json, re, textwrap
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1'); W=Path('/tmp/eris-promise-all-settled-plan-1/worktree'); Q=Path('/tmp/eris-promise-race-upstream-1/corpus-fetch-1/data')
def digest(b): return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def write(name,obj): (P/name).write_text(json.dumps(obj,indent=2,sort_keys=True)+'\n')
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
fetch=json.loads((P/'fetch-receipt.json').read_text()); metas={};rows=[];features=collections.Counter(); flags=collections.Counter();includes=collections.Counter()
for item in fetch['sources']:
 b=(P/'data'/item['relative']).read_bytes(); assert digest(b)==item['binding']['sha256'] and blob(b)==item['git_blob']
 s=b.decode(); assert s.count('/*---')==1 and s.count('---*/')==1
 front=textwrap.dedent(s.split('/*---')[1].split('---*/')[0])
 fields={};key=None
 for line in front.splitlines():
  m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_-]*):[ \t]*(.*)',line)
  if m:
   key,value=m.groups();assert key not in fields;fields[key]=value
  elif line.strip() and not line.lstrip().startswith('#'):
   assert key and line[:1].isspace(),(item['relative'],line)
   fields[key]+='\n'+line
 md={}
 for key in ['flags','includes','features','locale']:
  value=fields.get(key,'').strip()
  if not value:md[key]=[]
  else:
   assert value.startswith('[') and value.endswith(']') and '\n' not in value,(item['relative'],key,value)
   md[key]=[v.strip().strip("'\"") for v in value[1:-1].split(',') if v.strip()]
 assert 'negative' not in fields and 'timeout' not in fields
 md['negative']=None;metas[item['relative']]=md
 features.update(md['features']);flags.update(md['flags']);includes.update(md['includes'])
 assert set(md['flags'])<= {'async'} and not md['locale']
 rows.append(dict(relative=item['relative'],git_blob=item['git_blob'],bytes=len(b),sha256=digest(b),metadata=md,modes=['sloppy','strict'],completion_policy=int('async' in md['flags']),harness=['assert.js','sta.js']+(['doneprintHandle.js'] if 'async' in md['flags'] else [])+md['includes']))
helpers=sorted({'assert.js','sta.js','doneprintHandle.js'}|set(includes))
root=json.loads((P/'inventory-proof/tree-91b2052adad1f066ae031e2ff3a1e9bd6d732886.json').read_text())['tree']; harness=json.loads((P/'inventory-proof/tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json').read_text())['tree'];aux=[]
for rel in ['INTERPRETING.md','LICENSE']+['harness/'+h for h in helpers]:
 b=(Q/rel).read_bytes(); tree=harness if rel.startswith('harness/') else root;sha=next(r['sha'] for r in tree if r['path']==rel.split('/')[-1]); assert blob(b)==sha
 path=P/'data'/rel;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(b);aux.append(dict(relative=rel,git_blob=sha,binding=bind(path)))
identities=[]
for r in rows:
 for mode in r['modes']:
  obj=dict(source_sha256=r['sha256'],mode=mode,metadata=r['metadata'],harness=[dict(name=n,sha256=digest((P/'data/harness'/n).read_bytes())) for n in r['harness']],completion_policy=r['completion_policy'])
  identities.append(dict(id=r['relative']+':'+mode,case_sha256=digest(json.dumps(obj,sort_keys=True,ensure_ascii=True).encode()),source_sha256=r['sha256'],completion_policy=r['completion_policy']))
write('metadata.json',metas);write('inventory.json',rows);write('auxiliary.json',aux);write('case-identities.json',identities)
write('census.json',dict(status='source_derived_no_engine_observation',revision=fetch['revision'],directory=fetch['directory'],directory_tree=fetch['directory_tree'],sources=len(rows),fixtures=0,modes=len(identities),modes_by_kind=dict(sloppy=len(rows),strict=len(rows)),async_sources=sum(r['completion_policy'] for r in rows),sync_sources=sum(1-r['completion_policy'] for r in rows),flags=dict(flags),features=dict(features),includes=dict(includes),helpers=helpers,negative_sources=0,timeout_sources=0,locale_sources=0,source_bytes=sum(r['bytes'] for r in rows),auxiliary_bytes=sum(r['binding']['bytes'] for r in aux),proof_documents=len(fetch['proof']),proof_bytes=sum(r['bytes'] for r in fetch['proof']),data_files=len(rows)+len(aux),future_corpus_files_with_proofs_manifest=len(rows)+len(aux)+len(fetch['proof'])+1,case_identity_vector_sha256=digest(json.dumps(identities,sort_keys=True,separators=(',',':')).encode()),metadata_method='Independent restricted frontmatter read: every selected list is inline; no negative/timeout/locale field. No project module import; absent timeout remains absent.',source_authentication='Every104 Git blob and six complete tree hashes reconstructed; root-linked six helper plus two legal blobs verified. No upstream byte changes.'))
print((P/'census.json').read_text())
