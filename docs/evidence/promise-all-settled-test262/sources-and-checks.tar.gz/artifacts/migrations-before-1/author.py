from pathlib import Path
import ast,difflib,hashlib,json
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');H=P/'migrations-before-1';W=Path('/tmp/eris-promise-all-settled-plan-1/worktree')
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
spec=json.loads((P/'legacy-adapters.json').read_text());parent=json.loads(Path('/tmp/eris-promise-all-settled-plan-1/parent-source.json').read_text())['source_sha256'];rows=[]
for entry in spec['adapters']:
 rel=entry['path'];before=(P/'source-snapshots'/rel).read_text();assert hashlib.sha256(before.encode()).hexdigest()==parent[rel] and (W/rel).read_text()==before
 if rel.endswith('test_test262_promise_race_profile.py'):
  assert before.count('if k != PROFILE')==2 and before.count('TREE_PROFILES - {PROFILE}')==1
  after=before.replace('if k != PROFILE',"if k not in {PROFILE, 'promise-all-settled'}").replace('TREE_PROFILES - {PROFILE}',"TREE_PROFILES - {PROFILE, 'promise-all-settled'}")
  inverse=after.replace("if k not in {PROFILE, 'promise-all-settled'}",'if k != PROFILE').replace("TREE_PROFILES - {PROFILE, 'promise-all-settled'}",'TREE_PROFILES - {PROFILE}')
 else:
  assert before.count("'promise-race'")==len(entry['entries'])
  after=before.replace("'promise-race'","'promise-race', 'promise-all-settled'")
  inverse=after.replace("'promise-race', 'promise-all-settled'","'promise-race'")
 assert inverse==before
 for side,text in [('before',before),('raw',after)]:
  p=H/side/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 diff=''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel));dp=H/'diffs'/ (rel.replace('/','__')+'.patch');dp.parent.mkdir(exist_ok=True);dp.write_text(diff)
 btree,atree=ast.parse(before),ast.parse(after)
 bn=[n.name for n in ast.walk(btree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];an=[n.name for n in ast.walk(atree) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert bn==an
 # Every numeric or other string literal is unchanged after removing only added profile literal.
 bconstants=[n.value for n in ast.walk(btree) if isinstance(n,ast.Constant)];aconstants=[n.value for n in ast.walk(atree) if isinstance(n,ast.Constant) and n.value!='promise-all-settled'];assert sorted(map(repr,bconstants))==sorted(map(repr,aconstants))
 rows.append(dict(path=rel,entries=len(entry['entries']),groups=bn,before=bind(H/'before'/rel),raw=bind(H/'raw'/rel),diff=bind(dp),exact_inverse=True,oracle_and_numeric_literals_unchanged=True))
assert len(rows)==16 and sum(r['entries'] for r in rows)==20
dump(H/'selection.json',dict(status='frozen_exclusion_only_test_migrations',base='c97b200c9bddf1527cdbbc5a652beedba27c1d6d',tooling_base='f3e70ba152fdd3b730b1dd1494963a77f5141161',profile='promise-all-settled',paths=16,entries=20,rows=rows,invariant='Only add the new profile to existing explicit newer-profile exclusions; retain all historical counts/maps/hashes/test names/branches and old profiles. No expected result adjustment or oracle regeneration.',parent_eligibility='All use existing Python APIs; with newprofile absent, exclusion is semantically inert. Root alone runs checks.',no_execution='AST parse and source/hash/diff only; no project imports or tests.'))
files=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
dump(H/'source-ready.json',dict(status='sealed_external_16path_20entry_migrations_before_production',selection=bind(H/'selection.json'),source_parent=bind(Path('/tmp/eris-promise-all-settled-plan-1/parent-source.json')),plan=bind(P/'source-ready.json'),files=files,live_edits=False,execution=False))
print(bind(H/'source-ready.json'));print('unchanged named tests',sum(len(r['groups']) for r in rows))
