from pathlib import Path
import difflib,hashlib,json
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');H=P/'ci-1';W=P/'worktree';rel='.github/workflows/check.yml'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
parent=json.loads((P/'parent-source.json').read_text());before=(W/rel).read_text();assert hashlib.sha256(before.encode()).hexdigest()==parent['source_sha256'][rel]
anchor='      - name: Preserve complete pinned Promise.race cases\n        run: python3 tools/test262_conformance.py --binary target/release/eris-js --profile promise-race --baseline tests/conformance/test262-promise-race-current.json --output artifacts/test262-promise-race-gate.json\n'
addition='      - name: Preserve complete pinned Promise.allSettled cases\n        run: python3 tools/test262_conformance.py --binary target/release/eris-js --profile promise-all-settled --baseline tests/conformance/test262-promise-all-settled-current.json --output artifacts/test262-promise-all-settled-gate.json\n'
assert before.count(anchor)==1 and 'promise-all-settled' not in before
raw=before.replace(anchor,anchor+addition);assert raw.replace(addition,'')==before
for name,text in [('before',before),('raw',raw)]:
 p=H/name/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
diff=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel));dp=H/'diffs/check.yml.patch';dp.parent.mkdir(parents=True,exist_ok=True);dp.write_text(diff)
dump(H/'inverse.json',dict(added=addition,exact_removal_restores_parent=True,adjacency='Immediately after existing race gate in test262-host job, using earlier release host build; existing steps/job matrix unchanged.',baseline='tests/conformance/test262-promise-all-settled-current.json',profile='promise-all-settled',result_claims=None))
dump(H/'source-ready.json',dict(status='sealed_external_ci_step_source_only',base='486bca305a08b3711077123dff8b2e968f13ef19',scope='One adjacent two-line step only; no live edit or execution. Actual healthy baseline must exist before publication.',files=[dict(relative=rel,before=bind(H/'before'/rel),raw=bind(H/'raw'/rel),diff=bind(dp))],inverse=bind(H/'inverse.json'),bindings=[bind(P/'parent-source.json'),bind(P/'root/selection-1.json'),bind(P/'production-1/source-ready.json'),bind(H/'author.py')],remote_ci_observation=None))
print(bind(H/'source-ready.json'))
