"""Read-only evidence joins using stdlib; does not import or execute project code."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT = Path('/tmp/eris-promise-all-settled-upstream-plan-1')
OUT = ROOT / 'validation-review-1'
W = ROOT / 'worktree'
verified = {}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def bind(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def read(path):
    return json.loads(path.read_text())


def verify(record):
    path = Path(record['path'])
    assert path.is_file() and not path.is_symlink(), path
    assert path.stat().st_size == record['bytes'], path
    assert sha(path) == record['sha256'], path
    verified[str(path)] = bind(path)
    return path


def verify_nested(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            verify(value)
        for item in value.values():
            verify_nested(item)
    elif isinstance(value, list):
        for item in value:
            verify_nested(item)


def projection(report):
    return {row['id']: {key: row[key] for key in ('status', 'case_sha256', 'source_sha256')}
            for row in report['cases']}


ledger_path = ROOT / 'root/final-validation.json'
ledger = read(ledger_path)
replay = read(ROOT / 'root/replay-validation.json')
assert ledger['status'] == replay['status'] == 'verified'
verify_nested(ledger)
verify_nested(replay)
provenance = read(Path(ledger['published_binary_provenance']['path']))
verify_nested(provenance)
identity = read(Path(provenance['original_binary_identity']['path']))
verify_nested(identity)
assert identity['source_inventory']['sha256'] == ledger['parent_source']['sha256']
assert identity['sha256'] == ledger['release_binary']['sha256'] == replay['binary']['sha256']
binary = verify(ledger['release_binary'])
assert binary.read_bytes() == Path(provenance['original_binary']['path']).read_bytes()
assert binary.read_bytes()[:4] == b'\x7fELF'
assert binary.stat().st_size == 4432600
build_receipt = read(Path(identity['build_receipt']['path']))
assert build_receipt['exit'] == 0
build_log = Path(identity['build_receipt']['path']).with_name(build_receipt['log'])
assert sha(build_log) == build_receipt['sha256']
verified[str(build_log)] = bind(build_log)

parent = read(ROOT / 'parent-source.json')['source_sha256']
candidate = read(ROOT / 'source-candidate-2.json')['source_sha256']
final = read(ROOT / 'source-final.json')['source_sha256']
assert (len(parent), len(candidate), len(final)) == (1549, 1671, 1672)
baseline_rel = 'tests/conformance/test262-promise-all-settled-current.json'
assert set(final) - set(candidate) == {baseline_rel}
assert all(final[key] == val for key, val in candidate.items())
assert set(parent) <= set(final)
changed = sorted(key for key, value in final.items() if parent.get(key) != value)
assert changed == ledger['changed_source_paths'] and len(changed) == 142
assert sum(key not in parent for key in changed) == ledger['new_paths'] == 123
assert sum(key in parent for key in changed) == ledger['existing_changed_paths'] == 19
assert not any(key.endswith(('.rs', 'Cargo.toml', 'Cargo.lock')) for key in changed)
for key, value in final.items():
    assert sha(W / key) == value, key
old_baselines = [key for key in parent if key.startswith('tests/conformance/') and 'promise' in key]
assert all(final[key] == parent[key] for key in old_baselines)

oracle_path = ROOT / 'tests-before-1/raw/tools/promise-all-settled-profile-oracle.json'
oracle = read(oracle_path)
assert sha(oracle_path) == final['tools/promise-all-settled-profile-oracle.json']
manifest_path = W / 'tests/upstream/test262-promise-all-settled/manifest.json'
assert read(manifest_path) == oracle['expected_manifest']
assert sha(manifest_path) == oracle['manifest_sha256']
observed = read(ROOT / 'all-settled-observed-1.json')
recorded = read(ROOT / 'all-settled-record-1.json')
replayed = read(ROOT / 'all-settled-replay-1.json')
same_keys = ['cases', 'harness_preflight', 'counts', 'runner_policy',
             'runner_policy_sha256', 'corpus_manifest_sha256', 'binary_sha256']
for report in (observed, recorded, replayed):
    assert report['full_test262_conformance'] is False
    assert report['suite'] == 'pinned-test262-promise-all-settled-selection'
    assert report['revision'] == oracle['expected_manifest']['revision']
    assert (report['source_files'], report['source_tests'], report['mode_cases']) == (104, 104, 208)
    assert report['negative_source_tests'] == 0 and report['fixture_files'] == []
    assert report['harness_preflight_passed'] is True
    assert report['runner_policy'] == oracle['policy']
    assert report['runner_policy_sha256'] == oracle['policy_sha256']
    assert report['corpus_manifest_sha256'] == oracle['manifest_sha256']
    assert report['binary'] == str(binary) and report['binary_sha256'] == sha(binary)
    assert report['regressions'] == report['improvements'] == []
    assert report['counts'] == Counter(row['status'] for row in report['cases'])
    assert report['counts'] == {'passed': 188, 'failed': 12, 'unsupported': 8}
    for key in same_keys:
        assert report[key] == observed[key], key
assert len({row['id'] for row in observed['cases']}) == 208
assert len(observed['harness_preflight']) == 94
assert all(row['verified'] is True for row in observed['harness_preflight'])
assert len({(row['name'], row['result']['mode']) for row in observed['harness_preflight']}) == 94
assert [row['id'] for row in observed['cases']] == [row['id'] for row in oracle['case_identities']]
passed_policy = Counter()
outcomes_by_policy = Counter()
failed_ids, metadata_ids, parsed_ids = [], [], []
for row, expected in zip(observed['cases'], oracle['case_identities']):
    assert row['case_sha256'] == expected['case_sha256']
    assert row['id'] == row['file'] + ':' + row['mode']
    assert row['source_sha256'] == sha(W / 'tests/upstream/test262-promise-all-settled' / row['file'])
    assert row['expected_negative'] is None
    outcomes_by_policy[(expected['policy'], row['status'])] += 1
    if row['status'] == 'unsupported' and 'reason' in row:
        assert expected['class_excluded'] and row['reason'] == 'unimplemented declared features: class'
        assert 'observation' not in row
        metadata_ids.append(row['id'])
        continue
    item = row['observation']
    completion = item['completion']
    assert type(completion['policy']) is int and completion['policy'] == expected['policy']
    if row['status'] == 'passed':
        assert (item['status'], item['phase'], item['error_type'], item['error_identity'], item['message'], item['harness']) == ('complete', 'runtime', '', '', '', '')
        policy = expected['policy']
        assert completion == dict(policy=policy, done_calls=policy, success_prints=policy,
            failure_prints=0, flags=0, quiescent=True, audited=True, unhandled=0)
        passed_policy[policy] += 1
    elif row['status'] == 'failed':
        assert (item['status'], item['phase'], item['error_type'], item['error_identity'], item['message'], item['harness']) == ('host-failure', 'host', '', '', 'unhandled-rejection', '')
        assert completion == dict(policy=0, done_calls=0, success_prints=0,
            failure_prints=0, flags=0, quiescent=True, audited=True, unhandled=1)
        failed_ids.append(row['id'])
    else:
        assert row['status'] == 'unsupported' and not expected['class_excluded']
        assert (item['status'], item['phase'], item['message']) == ('unsupported', 'parse', "'class' is not supported")
        assert completion == dict(policy=0, done_calls=0, success_prints=0,
            failure_prints=0, flags=0, quiescent=False, audited=False, unhandled=0)
        parsed_ids.append(row['id'])
assert passed_policy == {0: 76, 1: 112}
assert len(failed_ids) == 12 and len(metadata_ids) == len(parsed_ids) == 4
assert ledger['observations']['failed_ids'] == failed_ids
assert ledger['observations']['metadata_class_exclusions'] == metadata_ids
assert ledger['observations']['parser_class_refusals'] == parsed_ids
assert ledger['observations']['passed_policy_counts'] == {'0': 76, '1': 112}

controls = observed['harness_preflight']
control_map = {(row['name'], row['result']['mode']): row for row in controls}
expected_controls = read(ROOT / 'controls-proposed-1/observations.json')['rows']
assert len(expected_controls) == 20
for row, expected in zip(controls[74:], expected_controls):
    result = row['result']
    assert (row['name'], result['mode']) == (expected['name'], expected['mode'])
    for key in ('case_sha256', 'source_sha256'):
        assert result[key] == expected[key]
    assert row['expected'] == expected['expected']
    assert result['observation']['completion']['policy'] == expected['completion_policy']
    actual_deps = row['prerequisites']
    common_deps = [item['name'] for item in controls[:74] if item['result']['mode'] == expected['mode']]
    extra_deps = expected['required_same_mode'][1:]
    assert [item['name'] for item in actual_deps] == common_deps + extra_deps
    for dep in actual_deps:
        source = control_map[(dep['name'], dep['mode'])]
        assert dep['mode'] == expected['mode'] and dep['verified'] is True
        assert all(dep[key] == source['result'][key] for key in ('case_sha256', 'source_sha256'))
    ob = result['observation']
    if expected['expected'] == 'passed':
        assert result['status'] == 'passed' and ob['status'] == 'complete'
    elif expected['expected'] == 'synchronous-exception':
        assert result['status'] == 'failed'
        assert ob['status'] == 'exception' and ob['phase'] == 'runtime' and ob['error_type'] == 'Test262Error'
        assert ob['error_identity'] == ''
        assert ob['completion'] == dict(policy=0, done_calls=0, success_prints=0,
            failure_prints=0, flags=256, quiescent=True, audited=True, unhandled=0)
    else:
        assert expected['expected'] == 'completion-error'
        assert result['status'] == 'failed' and ob['status'] == 'host-failure'
        assert ob['phase'] == 'host' and ob['message'] == 'completion-error'
        assert ob['completion'] == dict(policy=1, done_calls=1, success_prints=0,
            failure_prints=1, flags=1, quiescent=True, audited=True, unhandled=0)

baseline = read(W / baseline_rel)
assert baseline['cases'] == projection(observed) and len(baseline['cases']) == 208
for key in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'binary_sha256'):
    assert baseline[key] == observed[key]
assert sha(W / baseline_rel) == final[baseline_rel] == replay['baseline']['sha256']

old_results = []
for comparison in replay['old_comparisons']:
    prior = read(Path(comparison['parent']['path']))
    current = read(Path(comparison['report']['path']))
    original = Path('/tmp/eris-promise-all-settled-plan-1') / Path(comparison['parent']['path']).name
    assert original.read_bytes() == Path(comparison['parent']['path']).read_bytes()
    verified[str(original)] = bind(original)
    for key in same_keys:
        assert prior[key] == current[key], (comparison['profile'], key)
    assert len(current['cases']) == comparison['cases']
    assert len(current['harness_preflight']) == comparison['controls']
    assert current['counts'] == comparison['counts'] == Counter(row['status'] for row in current['cases'])
    assert current['regressions'] == current['improvements'] == []
    assert current['harness_preflight_passed'] and all(row['verified'] for row in current['harness_preflight'])
    assert current['binary_sha256'] == sha(binary)
    prior_baseline = W / ('tests/conformance/test262-' + comparison['profile'] + '-current.json')
    old_base = read(prior_baseline)
    assert old_base['cases'] == projection(current)
    assert sha(prior_baseline) == parent[str(prior_baseline.relative_to(W))]
    old_results.append({'profile': comparison['profile'], 'cases': len(current['cases']),
        'controls': len(current['harness_preflight']), 'counts': current['counts'], 'arrays_equal': True})
assert sum(item['cases'] for item in old_results) == 842
assert sum(item['controls'] for item in old_results) == 254
common = read(ROOT / 'replay-parent/upstream-existing-1.json')['harness_preflight']
assert controls[:74] == common

exits = {}
for label, records in ledger['commands'].items():
    receipt = read(Path(records['receipt']['path']))
    log = Path(records['log']['path'])
    assert sha(log) == receipt['sha256'] == records['log']['sha256']
    exits[label] = receipt['exit']
    assert all('cargo' not in arg and 'rustc' not in arg for arg in receipt['command'])
    if label.startswith('all-settled-') or label in ('race-replay-1', 'all-replay-1', 'methods-replay-1'):
        cmd = receipt['command']
        assert cmd[cmd.index('--binary') + 1] == str(binary)
        assert 'Upstream harness preflight: passed' in log.read_text()
        assert cmd[cmd.index('--output') + 1] == str(ROOT / (label + '.json'))
        if label == 'all-settled-observed-1':
            assert '--baseline' not in cmd and '--record-baseline' not in cmd
        elif label == 'all-settled-record-1':
            assert cmd[cmd.index('--record-baseline') + 1] == baseline_rel
        else:
            assert '--baseline' in cmd
assert exits == {'parent-profile-1': 1, 'candidate-profile-1': 0, 'python-all-1': 0,
    'all-settled-observed-1': 1, 'all-settled-record-1': 0, 'all-settled-replay-1': 0,
    'race-replay-1': 0, 'all-replay-1': 0, 'methods-replay-1': 0}
assert ledger['python']['full_passed'] == 569 and ledger['python']['prior_preserved'] == 556
assert ledger['exact_new_case_control_arrays'] and ledger['exact_common74']
assert ledger['exact_old_case_records'] == 842 and ledger['exact_old_control_records'] == 254
assert ledger['old_baseline_changes'] == ledger['regressions'] == ledger['improvements'] == 0
result = {'status': 'clear', 'method': 'Independent inert JSON/hash/array comparisons; no project execution.',
    'ledger': bind(ledger_path), 'bindings_checked': list(verified.values()),
    'source': {'parent': 1549, 'candidate': 1671, 'final': 1672, 'removed': 0,
        'modified_existing': 19, 'new': 123, 'candidate_to_final_only_addition': baseline_rel,
        'rust_cargo_changes': [], 'old_promise_baselines_unchanged': old_baselines},
    'new_profile': {'cases': 208, 'controls': 94, 'case_fingerprints_join_frozen_oracle': True,
        'exact_three_run_arrays': True, 'counts': observed['counts'], 'pass_async': 112, 'pass_sync': 76,
        'outcomes_by_policy': [{'policy': policy, 'status': status, 'count': count}
            for (policy, status), count in sorted(outcomes_by_policy.items())],
        'failed_host_veto_ids': failed_ids, 'metadata_class_ids': metadata_ids, 'parser_class_ids': parsed_ids,
        'baseline_exact_projection': True, 'all_common74_equal': True, 'all20_new_dependencies_join': True},
    'old_profiles': old_results, 'command_exits': exits,
    'binary': bind(binary), 'binary_reused_byte_exact': True,
    'qualifications': ['No Rust build or suite rerun was performed for this Python/corpus checkpoint.',
        'No-baseline exit1 reports nonpassing cases despite healthy controls; record/replay exit0 retains all 12 failed and 8 unsupported modes.',
        '112 async passes contain authenticated DONE evidence; 76 sync passes contain audited completion. All 12 failed modes are final-quiescent unhandled-rejection vetoes with no reported assertion exception.',
        'The selected source map is not asserted to cover the complete build graph. Prior build provenance is reused and bound, not newly executed.']}
path = OUT / 'final-checks.json'
path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps({'status': 'clear', 'new': [208, 94], 'old': [842, 254], 'passes': [112, 76], 'output': bind(path)}))
