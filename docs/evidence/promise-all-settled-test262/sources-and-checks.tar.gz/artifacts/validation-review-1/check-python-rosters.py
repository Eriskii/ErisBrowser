"""Inert evidence review: read logs/JSON/Python AST; never import project code."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/tmp/eris-promise-all-settled-upstream-plan-1')
OLD = Path('/tmp/eris-promise-race-upstream-1/validation')
OUT = ROOT / 'validation-review-1'


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def binding(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def load(path):
    return json.loads(path.read_text())


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def verify_record(record):
    path = Path(record['path'])
    assert path.stat().st_size == record['bytes'], path
    assert digest(path) == record['sha256'], path


def success(receipt_path, expected):
    receipt = load(receipt_path)
    log = receipt_path.with_name(receipt['log'])
    assert receipt['exit'] == 0
    assert digest(log) == receipt['sha256']
    text = log.read_text()
    rows = re.findall(r'^\S+ \(([^\n]+)\) \.\.\. ok$', text, re.M)
    assert len(rows) == len(set(rows)) == expected
    status_lines = [line for line in text.splitlines() if ' ... ' in line]
    assert len(status_lines) == expected
    assert all(line.endswith(' ... ok') for line in status_lines)
    summaries = re.findall(r'^Ran (\d+) tests in ([\d.]+)s$', text, re.M)
    assert len(summaries) == 1 and int(summaries[0][0]) == expected
    assert text.endswith('\nOK\n')
    return {'receipt': binding(receipt_path), 'log': binding(log),
            'command': receipt['command'], 'distinct_passed': expected,
            'harness_seconds': float(summaries[0][1]),
            'receipt_elapsed_seconds': receipt['elapsed_seconds'],
            'names': sorted(rows)}


OUT.mkdir(exist_ok=True)
baseline_dir = OUT / 'baseline'
baseline_dir.mkdir(exist_ok=True)
retained = []
for name in ('candidate-python-1.json', 'candidate-python-1.log'):
    original = OLD / name
    target = baseline_dir / name
    if target.exists():
        assert target.read_bytes() == original.read_bytes()
    else:
        target.write_bytes(original.read_bytes())
    retained.append({'original': binding(original), 'copy': binding(target)})

old = success(baseline_dir / 'candidate-python-1.json', 556)
new = success(ROOT / 'validation/python-all-1.json', 569)
focused = success(ROOT / 'validation/candidate-profile-1.json', 13)
assert old['command'] == new['command'] == [
    'python3', '-B', '-m', 'unittest', 'discover', '-s', 'tools', '-p', 'test_*.py', '-v']
assert focused['command'] == [
    'python3', '-B', '-m', 'unittest', 'discover', '-s', 'tools', '-p',
    'test_test262_promise_all_settled_profile.py', '-v']

module_rel = 'tools/test_test262_promise_all_settled_profile.py'
raw = ROOT / 'tests-before-1/raw' / module_rel
tree = ast.parse(raw.read_text())
classes = [node for node in tree.body if isinstance(node, ast.ClassDef)]
assert len(classes) == 1 and classes[0].name == 'PromiseAllSettledProfileTests'
names = sorted(node.name for node in classes[0].body
               if isinstance(node, ast.FunctionDef) and node.name.startswith('test_'))
assert len(names) == 13
declared = ['test_test262_promise_all_settled_profile.PromiseAllSettledProfileTests.' + n
            for n in names]
assert sorted(set(new['names']) - set(old['names'])) == declared
assert not set(old['names']) - set(new['names'])
assert focused['names'] == declared
roster = load(ROOT / 'tests-before-1/roster.json')
assert sorted(row['name'] for row in roster['groups']) == names

source1_path = ROOT / 'source-candidate-1.json'
source2_path = ROOT / 'source-candidate-2.json'
source1 = load(source1_path)['source_sha256']
source2 = load(source2_path)['source_sha256']
assert len(source1) == len(source2) == 1671
assert source1.keys() == source2.keys()
assert [path for path in source1 if source1[path] != source2[path]] == ['.github/workflows/check.yml']
assert source1[module_rel] == source2[module_rel] == digest(raw)
assert digest(ROOT / 'worktree' / module_rel) == digest(raw)
for rel, sha in source2.items():
    assert digest(ROOT / 'worktree' / rel) == sha, rel
production_import = load(ROOT / 'root/production-import.json')
verify_record(production_import['source'])
assert production_import['source']['sha256'] == digest(source1_path)
ci = load(ROOT / 'root/ci-import.json')
assert ci['source_sha256'] == digest(source2_path)

parent_path = ROOT / 'root/parent-validation.json'
parent = load(parent_path)
for key in ('source', 'receipt', 'log'):
    verify_record(parent[key])
parent_receipt = load(Path(parent['receipt']['path']))
assert parent_receipt['exit'] == 1
assert parent_receipt['sha256'] == parent['log']['sha256']
text = Path(parent['log']['path']).read_text()
parent_names = re.findall(r'^(test_\w+) \([^\n]+\) \.\.\. ', text, re.M)
assert sorted(set(parent_names)) == names
assert Counter(parent_names) == Counter(names + ['test_complete_tree_and_every_ancestor_proof_refuse_mutation'])
passes = re.findall(r'^(test_\w+) \([^\n]+\) \.\.\. ok$', text, re.M)
assert sorted(passes) == sorted(parent['passed']) and len(passes) == 2
error_groups = set(re.findall(r'^ERROR: (test_\w+) ', text, re.M))
assert error_groups == set(parent['expected_failed_groups']) and len(error_groups) == 11
assert len(re.findall(r'^ERROR:', text, re.M)) == parent['unittest_error_rows'] == 35
errors = Counter(re.findall(r'^(KeyError|AttributeError): (.*)$', text, re.M))
assert errors[('KeyError', "'promise-all-settled'")] == 33
assert errors[('KeyError', "'success'")] == 1
assert sum(count for (kind, _), count in errors.items() if kind == 'AttributeError') == 1
assert sum(errors.values()) == 35
assert re.search(r'^Ran 13 tests in [\d.]+s$', text, re.M)
assert text.endswith('\nFAILED (errors=35)\n')

result = {
    'status': 'clear',
    'method': 'Independent stdlib reads, regular-expression rosters, hashes and AST only; no project imports or execution.',
    'retained_baseline': retained,
    'previous_full': old,
    'current_full': new,
    'current_focused': focused,
    'additions': declared,
    'removed_or_renamed': [],
    'source_attribution': {'candidate1': binding(source1_path), 'candidate2': binding(source2_path),
        'only_candidate1_to_2_change': '.github/workflows/check.yml',
        'current_selected_hashes_verified': 1671, 'held_module': binding(raw),
        'qualification': 'Receipts record command/log/exit; root import and CI receipts plus selected source hashes bind the reviewed source. This read does not independently attest process provenance or a complete build-input graph.'},
    'parent': {'receipt': binding(parent_path), 'groups': 13, 'passed_groups': sorted(passes),
        'error_groups': sorted(error_groups), 'error_rows': 35,
        'displayed_top_level_name_lines': 14,
        'repeated_display_name': 'test_complete_tree_and_every_ancestor_proof_refuse_mutation',
        'error_kinds': [{'kind': kind, 'detail': detail, 'count': count}
                        for (kind, detail), count in sorted(errors.items())],
        'qualification': parent['qualification']},
}
write(OUT / 'python-rosters.json', result)
print(json.dumps({'status': 'clear', 'previous': 556, 'current': 569,
                  'added': 13, 'removed': 0, 'parent_errors': 35,
                  'rosters': binding(OUT / 'python-rosters.json')}))
