from pathlib import Path
import difflib, hashlib, json, re

P = Path('/tmp/eris-promise-all-settled-upstream-plan-1')
H = P / 'documentation-1'
D = P / 'documentation-draft-1'
W = P / 'worktree'
def read(p): return json.loads(p.read_text())
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def dump(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(value, indent=2) + '\n')
def check_bindings(value):
    if isinstance(value, dict):
        if {'path','bytes','sha256'} <= value.keys():
            assert bind(Path(value['path'])) == {k:value[k] for k in ['path','bytes','sha256']}
        for child in value.values(): check_bindings(child)
    elif isinstance(value,list):
        for child in value: check_bindings(child)

final = read(P/'root/final-validation.json')
check_bindings(final)
assert final['observed_counts'] == {'passed':188,'failed':12,'unsupported':8}
assert final['controls_verified'] == final['new_controls'] == 94
assert final['python']['full_passed'] == 569 and final['python']['focused_passed'] == 13
assert final['exact_new_case_control_arrays'] and final['exact_common74']
assert (final['exact_old_case_records'],final['exact_old_control_records']) == (842,254)
assert final['observations']['passed_policy_counts'] == {'0':76,'1':112}
observed = read(P/'all-settled-observed-1.json')
assert final['observations']['failed_ids'] == [r['id'] for r in observed['cases'] if r['status']=='failed']
assert final['observations']['metadata_class_exclusions'] == [r['id'] for r in observed['cases'] if r['status']=='unsupported' and 'reason' in r]
assert final['observations']['parser_class_refusals'] == [r['id'] for r in observed['cases'] if r['status']=='unsupported' and 'observation' in r]

replacements = {
'RESULT_SUMMARY': '''Eris records **188 passed, 12 failed and
8 unsupported**. All 94 harness controls verify their expected outcomes.''',
'OBSERVED_RESULT_TABLE_AND_NONPASS_ANALYSIS': '''| Observation | Modes |
| --- | ---: |
| Passed | 188 |
| Host failure: final unhandled rejection | 12 |
| Unsupported class feature declared in metadata | 4 |
| Unsupported class syntax encountered by the parser | 4 |
| Total | 208 |

The passed rows comprise 112 asynchronous and 76 synchronous modes. Two of the
114 asynchronous modes are class-feature exclusions; the result does not claim
that every asynchronous mode passed.

The twelve host failures come from six synchronous sources, each in both modes:
`capability-resolve-throws-no-close.js`, `invoke-resolve-error-close.js`,
`invoke-then-error-close.js`, `invoke-then-get-error-close.js`,
`iter-next-val-err-no-close.js` and `iter-step-err-no-close.js`. Each raw record
reports `host-failure` / `unhandled-rejection`, audited quiescence and exactly
one unhandled rejection, with no completion, body-abrupt or terminal flags.
These are final host-policy vetoes, not observed upstream assertion exceptions.
Source inspection shows discarded aggregate promises on the relevant abrupt
paths; the reports do not serialize their rejection values or establish an
additional exact rejection-object identity result.''',
'OBSERVED_PYTHON_PARENT_AND_CANDIDATE_VALIDATION': '''All 13 new Python test groups pass. The complete Python suite passes
569 groups: the prior 556 names plus the exact 13 additions, with no skipped or
renamed groups. On the published parent with only the frozen corpus and tests
imported, two metadata/preservation groups pass and eleven new-profile groups
produce 35 error rows. Those are group/subtest counts, not 35 independent tests.
The errors arise at missing profile symbols or dispatch; one old generic
preflight reaches a profile-specific mock and raises `KeyError('success')`.
Deeper refusal assertions are not claimed as reached on that parent.
No prospective source, control, assertion or expected outcome was changed after
these observations.''',
'OBSERVED_REPLAY_AND_BINARY_BINDINGS': '''The first unbaselined measurement exits 1 because it retains nonpassing cases,
while all controls are healthy. The normal `--record-baseline` command then
records the measured statuses, and the `--baseline` replay exits 0 with exactly
the same case and control arrays. Recording and replay preserve all twelve
failures and eight unsupported modes; there are no resource, timeout, blocked
or adapter-error rows. The baseline is the report's exact status/identity
projection, not a manually edited outcome table.

All executions reuse the published API release adapter byte-for-byte:
4,432,600 bytes, SHA-256
`b653280c13235292194de1491cf134e3523e6b10e21c0eb73f9f19d6301d872a`.
Rust execution inputs and build manifests are unchanged. This tooling/corpus
checkpoint does not claim a local Rust rebuild or Rust-suite rerun.''',
'OBSERVED_CI_CONFIGURATION_STATUS': '''CI is configured with an adjacent `promise-all-settled` gate after the existing
Promise gates, using their release host build. No remote CI result for this
profile checkpoint is claimed here.
''',
'README_OBSERVED_RESULT_SUMMARY': '''It records 188 passed, 12 failed and 8 unsupported, with all 94 controls verified.
The twelve failures are final-unhandled host-policy vetoes; the eight unsupported
modes retain their class metadata or parser reasons.''',
'COMPATIBILITY_OBSERVED_RESULT_SUMMARY': '''It records **188 passed, 12 failed and
8 unsupported**, with all 94 controls verified. The twelve failures are final
unhandled-rejection host vetoes; four modes are class-feature exclusions and
four encounter unsupported class syntax in the parser.''',
'ROADMAP_OBSERVED_RESULT_SUMMARY': '''It records 188 passed, 12 failed and 8 unsupported,
with all 94 controls verified. The twelve failures retain the final-unhandled
host-policy reason, and eight class-bearing modes remain unsupported.''',
'VALIDATION_OBSERVED_CHECKS_AND_REPLAYS': '''Observed results are **188 passed, 12 failed and 8 unsupported**, with all
94 controls verified. The twelve failures are final-quiescent unhandled-rejection
vetoes; four unsupported modes have class metadata and four reach a parser class
refusal. All 13 new Python groups and the complete 569-group Python suite pass.
The test-only parent observation is two groups passing and eleven affected
groups producing 35 error rows, including one old generic-preflight mock lookup;
deeper negative assertions were not reached there.

Healthy baseline recording and replay retain the exact 208 case and 94 control
records. The older methods, all and race profiles retain all 842 case and
254 control records, with no old baseline changes. The common 74 controls also
remain exact. The published API release adapter is reused byte-for-byte; this
checkpoint changes no Rust execution inputs and claims no Rust-suite rerun.
CI is configured with the new adjacent gate; no remote result is claimed here.''',
}
old_class = '''Two sources declare the unsupported `class` feature. Two further bodies contain
class syntax without that declaration; one also contains `0n`. The untagged
sources remain subject to normal adapter execution and reporting. Source syntax
inspection does not determine their observed result. Any final-quiescent
unhandled-rejection veto retains its separate host-policy reason, rather than
being relabeled as an upstream assertion failure or a pass.'''
new_class = '''The tagged sources `ctx-ctor.js` and
`invoke-resolve-on-promises-every-iteration-of-custom.js` account for four
metadata exclusions. The untagged
`resolve-throws-iterator-return-is-not-callable.js` and
`resolve-throws-iterator-return-null-or-undefined.js` reach the adapter and
produce four actual parser refusals: `'class' is not supported`. The former
also contains `0n`, but class refusal is observed first. These results establish
no separate BigInt execution or refusal outcome. All original bytes and modes
remain in the manifest, reports and baseline.'''
index = read(D/'draft-index.json')
check_bindings(index)
files=[]
used=[]
for entry in index['files']:
    rel=entry['relative']
    before=Path(entry['before']['path']).read_text()
    raw=Path(entry['raw']['path']).read_text()
    if rel == 'docs/promise-all-settled-test262.md':
        assert raw.count(old_class)==1
        raw=raw.replace(old_class,new_class)
        raw=raw.replace('<!-- External draft: result placeholders must be replaced from reviewed reports before import. -->\n\n','')
    for key,value in replacements.items():
        marker='{{'+key+'}}'
        if marker in raw:
            assert raw.count(marker)==1
            raw=raw.replace(marker,value)
            used.append(key)
    assert '{{' not in raw and 'External draft:' not in raw
    if before:
        assert (W/rel).read_text()==before, rel
    else:
        assert not (W/rel).exists(), rel
    for side,text in [('before',before),('raw',raw)]:
        path=H/side/rel
        path.parent.mkdir(parents=True,exist_ok=True)
        path.write_text(text)
    diff=''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='before/'+rel if before else '/dev/null',tofile='raw/'+rel))
    dp=H/'diffs'/(rel.replace('/','__')+'.patch')
    dp.parent.mkdir(parents=True,exist_ok=True)
    dp.write_text(diff)
    files.append(dict(relative=rel,new=not bool(before),before=bind(H/'before'/rel),raw=bind(H/'raw'/rel),diff=bind(dp)))
assert sorted(used)==sorted(replacements)
assert len(files)==5
historical=index['historical_chapters_untouched']
for item in historical:
    assert bind(Path(item['path']))=={k:item[k] for k in ['path','bytes','sha256']}
    assert item['relative'] not in [x['relative'] for x in files]
notes=dict(status='source_ready_documentation_only',
    rationale='Replace only current summaries and add one new historical chapter. All claims derive from observed reports, frozen identities and final validation/replay receipts. Original unsealed draft with placeholders is retained unchanged.',
    actual=dict(sources=104,modes=208,passed=188,host_vetoes=12,metadata_class=4,parser_class=4,controls=94,
        passed_async=112,passed_sync=76,python_full=569,python_new=13,parent_pass=2,parent_affected=11,parent_error_rows=35,
        new_exact_records=[208,94],old_exact_records=[842,254]),
    qualifications=['No full ECMAScript or Promise conformance claim.',
        'No independent BigInt outcome: class refusal occurs first in the untagged source containing0n.',
        'No Rust test/build rerun claim; published release binary reused exactly.',
        'CI configuration is reported without remote CI success.',
        'The selected1672 input map is not a complete build dependency graph; prose snapshots are bound separately.',
        'Historical Promise chapters and old baseline records are unchanged.'],
    evidence_link='docs/evidence/promise-all-settled-test262/summary.json is the root-owned pending compact evidence publication target; the final raw result receipts already exist.',
    project_execution=False,live_edits=False)
dump(H/'notes.json',notes)
bindings=[bind(P/p) for p in [
    'root/final-validation.json','root/replay-validation.json','source-final.json','parent-source.json',
    'root/parent-validation.json','root/selection-1.json',
    'first-results-review-1/source-review.json','first-results-review-1/replay-addendum.json',
    'documentation-draft-1/draft-index.json','ci-1/source-ready.json','ci-1/layout-review.json',
    'tests-before-1/source-ready.json','migrations-before-1/source-ready.json',
    'controls-proposed-1/source-ready.json','all-settled-observed-1.json',
    'all-settled-record-1.json','all-settled-replay-1.json']]
bindings += index['bindings'][:3]
dump(H/'source-ready.json',dict(status='ready_for_independent_source_review',base=final['base'],files=files,
    bindings=bindings,notes=bind(H/'notes.json'),author=bind(H/'compose.py'),
    historical_chapters_untouched=historical,
    before_source_qualification=index['inventory_qualification'],
    no_result_placeholders=True,source_inventory_includes_docs=False,project_execution=False,live_edits=False))
print(bind(H/'source-ready.json'))
