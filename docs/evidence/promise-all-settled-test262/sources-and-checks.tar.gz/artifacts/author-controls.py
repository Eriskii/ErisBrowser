from pathlib import Path
import hashlib,json
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1'); C=P/'controls-proposed-1'; (C/'raw').mkdir(parents=True,exist_ok=True)
variants=[]
def pair(name,source,wrong,includes,policy=0,dependencies=None):
 assert source != wrong
 for suffix,text,expect,req in [('',source,'passed',None),('-mismatch',wrong,'completion-error' if policy else 'synchronous-exception',name)]:
  (C/'raw'/(name+suffix+'.js')).write_text(text)
  variants.append(dict(name=name+suffix,source=text,expected=expect,completion_policy=policy,includes=includes,origin='promise-all-settled-pair',prerequisite=req,additional_prerequisites=dependencies or []))
api="""assert.sameValue(typeof Promise.allSettled, 'function');
verifyProperty(Promise, 'allSettled', {
  value: Promise.allSettled, writable: true, enumerable: false, configurable: true
}, { restore: true });
verifyProperty(Promise.allSettled, 'name', {
  value: 'allSettled', writable: false, enumerable: false, configurable: true
}, { restore: true });
verifyProperty(Promise.allSettled, 'length', {
  value: 1, writable: false, enumerable: false, configurable: true
}, { restore: true });
assert.sameValue(isConstructor(Promise.allSettled), false);
assert.throws(TypeError, function() { new Promise.allSettled([]); });
"""
pair('api',api,"Promise.allSettled = function allSettled(value) {};\n"+api,['propertyHelper.js','isConstructor.js'])
helper="""assert.sameValue(typeof checkSettledPromises, 'function');
var value = {}, reason = {}, wrong = {};
var settled = [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }];
checkSettledPromises(settled, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }]);
assert.throws(Test262Error, function() {
  checkSettledPromises(settled, [{ status: 'fulfilled', value: wrong }, { status: 'rejected', reason: reason }]);
});
assert.throws(Test262Error, function() {
  checkSettledPromises(settled, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: wrong }]);
});
"""
pair('settled-helper',helper,"checkSettledPromises = function() {};\n"+helper,['promiseHelper.js'])
settlement="""var value = {}, reason = {}, release;
var pending = new Promise(function(resolve) { release = resolve; });
Promise.allSettled([pending, Promise.reject(reason), 7]).then(function(values) {
  checkSettledPromises(values, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }, { status: 'fulfilled', value: 7 }]);
  assert.sameValue(Object.getPrototypeOf(values[0]), Object.prototype);
  assert.sameValue(Object.getPrototypeOf(values[1]), Object.prototype);
  verifyProperty(values[0], 'status', { value: 'fulfilled', writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[0], 'value', { value: value, writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[1], 'status', { value: 'rejected', writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[1], 'reason', { value: reason, writable: true, enumerable: true, configurable: true }, { restore: true });
}).then($DONE, $DONE);
release(value);
"""
pair('settlement',settlement,settlement.replace("{ status: 'fulfilled', value: 7 }]);","{ status: 'fulfilled', value: 8 }]);"),['promiseHelper.js','propertyHelper.js'],1,['settled-helper'])
gate="""var fulfilled = [], rejected = [], calls = 0, values, returnValue = {}, first = {}, second = {};
function C(executor) {
  executor(function(result) { calls++; values = result; return returnValue; }, function() { throw new Test262Error('unexpected aggregate rejection'); });
}
C.resolve = function(value) { return value; };
function input(index) { return { then: function(f, r) { fulfilled[index] = f; rejected[index] = r; } }; }
var result = Promise.allSettled.call(C, [input(0), input(1)]);
assert.sameValue(result instanceof C, true);
assert.sameValue(calls, 0);
assert.notSameValue(fulfilled[0], rejected[0]);
assert.notSameValue(fulfilled[0], fulfilled[1]);
assert.notSameValue(rejected[0], rejected[1]);
assert.sameValue(rejected[1](second), undefined);
assert.sameValue(fulfilled[1](first), undefined);
assert.sameValue(rejected[1](first), undefined);
assert.sameValue(calls, 0);
assert.sameValue(fulfilled[0](first), returnValue);
assert.sameValue(rejected[0](second), undefined);
assert.sameValue(fulfilled[0](second), undefined);
assert.sameValue(calls, 1);
checkSettledPromises(values, [{ status: 'fulfilled', value: first }, { status: 'rejected', reason: second }]);
"""
pair('shared-gate',gate,gate.replace('assert.sameValue(calls, 1);','assert.sameValue(calls, 2);'),['promiseHelper.js'],0,['settled-helper'])
close="""var marker = {}, rejected, rejects = 0, resolves = 0, nexts = 0, resolveCalls = 0, returnGets = 0, returnCalls = 0, savedF, savedR;
function C(executor) {
  executor(function() { resolves++; }, function(reason) { rejects++; rejected = reason; });
}
C.resolve = function(value) {
  resolveCalls++;
  if (resolveCalls === 2) throw marker;
  return { then: function(f, r) { savedF = f; savedR = r; } };
};
var iterator = { next: function() { nexts++; return { done: false, value: nexts }; } };
Object.defineProperty(iterator, 'return', { get: function() {
  returnGets++;
  return function() { returnCalls++; return {}; };
} });
var input = {};
input[Symbol.iterator] = function() { return iterator; };
var result = Promise.allSettled.call(C, input);
assert.sameValue(result instanceof C, true);
assert.sameValue(rejected, marker);
assert.sameValue(rejects, 1);
assert.sameValue(returnGets, 1);
assert.sameValue(returnCalls, 1);
assert.sameValue(nexts, 2);
assert.sameValue(resolveCalls, 2);
assert.sameValue(savedF(marker), undefined);
assert.sameValue(savedR(marker), undefined);
assert.sameValue(resolves, 0);
assert.sameValue(rejects, 1);
"""
pair('abrupt-close',close,close.replace('assert.sameValue(rejected, marker);','assert.sameValue(rejected, undefined);'),[],0)
W=Path('/tmp/eris-promise-all-settled-plan-1/worktree'); old=json.loads((W/'tools/promise-race-profile-oracle.json').read_text()); common=old['common74']
# Common74 in existing oracle is the retained row observation vector, not new source.
(C/'variants.json').write_text(json.dumps(dict(status='proposed_source_literals_before_selection_or_execution',profile='promise-all-settled',variants=variants,source_count=10,new_mode_count=20,common_mode_count=74,total_mode_count=94),indent=2)+'\n')
rows=[]
for mode in ['sloppy','strict']:
 for r in variants:
  md=dict(flags=['async'] if r['completion_policy'] else [],includes=r['includes'],features=[],locale=[],negative=None)
  h=['assert.js','sta.js']+(['doneprintHandle.js'] if r['completion_policy'] else [])+r['includes']
  ident=dict(source_sha256=hashlib.sha256(r['source'].encode()).hexdigest(),mode=mode,metadata=md,harness=[dict(name=n,sha256=hashlib.sha256((P/'data/harness'/n).read_bytes()).hexdigest()) for n in h],completion_policy=r['completion_policy'])
  rows.append(dict(name='promise-all-settled-'+r['name'],mode=mode,case_sha256=hashlib.sha256(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode()).hexdigest(),source_sha256=ident['source_sha256'],expected=r['expected'],completion_policy=r['completion_policy'],required_same_mode=['all 37 original promise-methods controls']+['promise-all-settled-'+x for x in r['additional_prerequisites']]+(['promise-all-settled-'+r['prerequisite']] if r['prerequisite'] else [])))
(C/'observations.json').write_text(json.dumps(dict(status='prospective_expectations_not_observed',rows=rows),indent=2)+'\n')
(C/'notes.json').write_text(json.dumps(dict(scope='Five bounded positive/mismatch pairs. They are a proposed selection, not executable runner production or observations.',expected_semantics={'api':'Own method flags/name/arity plus nonconstruction; replacement is an ordinary constructor with matching name/arity so nonconstruction checks discriminate. verifyProperty always restores.','settled-helper':'Both fulfilled-value and rejected-reason mismatches must throw exact Test262Error. No-op replacement is rejected by assert.throws, independently of Promise.allSettled. Common74 only establishes checkSequence, so this additional path is necessary.','settlement':'Input order is preserved when first promise is deferred; mixed rejection becomes a rejected snapshot without rejecting aggregate. Expected payload7->8 is the sole mismatch. Authenticated async error is completion-error, not serialized thrown-object identity.','shared-gate':'Saved reject for element1 wins; later fulfill/reject ignored; element0 final fulfillment triggers aggregate once and returns custom resolve return value. Sole mismatch expects two aggregate calls.','abrupt-close':'Second cached C.resolve throws marker with iterator open; return getter/call run once, aggregate reject gets exact marker, prior saved callbacks cannot consume normal-exhaustion sentinel. Sole mismatch expects undefined rejection.'},gate='Require common74 exact unchanged prefix, all20 new exact unique name/mode identities, verified true, same-mode common prerequisites and named positive helper/pair prerequisites. Missing/duplicate/extra/forged/wrong-mode controls are nonhealthy. No case/baseline admission without healthy94.',execution='No JavaScript or project Python execution. Expected outcomes derive from selected API/spec and literal mutations.'),indent=2)+'\n')
print('wrote',len(variants),'control literals and',len(rows),'mode expectations')
