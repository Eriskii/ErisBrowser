from pathlib import Path
from collections import Counter
import hashlib,json,re
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');H=P/'first-results-review-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
report_path=P/'all-settled-observed-1.json';r=json.loads(report_path.read_text());oracle_path=P/'tests-before-1/raw/tools/promise-all-settled-profile-oracle.json';o=json.loads(oracle_path.read_text());inv={x['relative']:x for x in json.loads((P/'inventory.json').read_text())};ids=o['case_identities'];cases=r['cases']
assert len(cases)==208 and len({x['id'] for x in cases})==208
assert [(x['id'],x['case_sha256']) for x in cases]==[(x['id'],x['case_sha256']) for x in ids]
for x in cases:
 source=P/'data'/x['file'];assert bind(source)['sha256']==x['source_sha256']==inv[x['file']]['sha256']
 assert x['expected_negative'] is None
counts=Counter(x['status'] for x in cases);assert dict(counts)==r['counts']=={'passed':188,'failed':12,'unsupported':8}
assert (r['source_files'],r['source_tests'],r['mode_cases'],r['negative_source_tests'],r['fixture_files'])==(104,104,208,0,[])
assert r['runner_policy']==o['policy'] and r['runner_policy_sha256']==o['policy_sha256'] and r['corpus_manifest_sha256']==o['manifest_sha256']
assert r['full_test262_conformance'] is False
binary=Path(r['binary']);assert bind(binary)['sha256']==r['binary_sha256']=='b653280c13235292194de1491cf134e3523e6b10e21c0eb73f9f19d6301d872a'
parent=json.loads((P/'replay-parent/upstream-existing-1.json').read_text());controls=r['harness_preflight'];assert controls[:74]==parent['harness_preflight']
expected=o['old_control_identities']['promise-methods-async']+o['preflight'];actual=[dict(name=x['name'],mode=x['result']['mode'],case_sha256=x['result']['case_sha256'],source_sha256=x['result']['source_sha256']) for x in controls];assert actual==expected and len(controls)==94 and all(x['verified'] is True for x in controls) and r['harness_preflight_passed'] is True
by={(x['name'],x['result']['mode']):x for x in controls};common=[x['name'] for x in parent['harness_preflight'][:37]]
for item,row in zip(controls[74:],[v for mode in ['sloppy','strict'] for v in o['controls']]):
 mode=item['result']['mode'];need=common+['promise-all-settled-'+n for n in row['additional_prerequisites']]+(['promise-all-settled-'+row['prerequisite']] if row['prerequisite'] else [])
 expected_prereq=[dict(name=n,mode=mode,verified=True,case_sha256=by[n,mode]['result']['case_sha256'],source_sha256=by[n,mode]['result']['source_sha256']) for n in need]
 assert item['prerequisites']==expected_prereq
 obs=item['result']['observation'];ev=obs['completion'];assert ev['policy']==row['completion_policy'] and ev['quiescent'] and ev['audited'] and ev['unhandled']==0
 if row['expected']=='passed':assert item['result']['status']=='passed' and obs['status']=='complete' and ev['flags']==0
 elif row['expected']=='synchronous-exception':assert item['result']['status']=='failed' and obs['status']=='exception' and obs['error_type']=='Test262Error' and ev['flags']==256
 else:assert row['expected']=='completion-error' and obs['status']=='host-failure' and obs['message']=='completion-error' and ev['flags']==1 and (ev['done_calls'],ev['success_prints'],ev['failure_prints'])==(1,0,1)
analysis={
'capability-resolve-throws-no-close.js':'The iterator immediately reports done. Custom P returns a real Promise whose capability resolve throws Test262Error while the capability reject belongs to that real Promise. The source discards the returned rejected promise and asserts returnCount=0. No close is required after normal exhaustion.',
'invoke-resolve-error-close.js':'A replacement Promise.resolve throws Error while the iterator remains open. The source discards Promise.allSettled(iterDoneSpy) and only asserts return called once. Its returned aggregate can be rejected without an attached handler.',
'invoke-then-error-close.js':'The input promise has a then method that throws Test262Error. The source discards the aggregate and checks one iterator return call.',
'invoke-then-get-error-close.js':'The input promise has a then getter that throws Test262Error. The source discards the aggregate and checks one iterator return call.',
'iter-next-val-err-no-close.js':'The iterator result value getter throws its original Test262Error. The source discards the aggregate and checks no close plus exactly one next; this is the IteratorStepValue abrupt path.',
'iter-step-err-no-close.js':'The iterator result done getter throws its original Test262Error. The source discards the aggregate and checks no close; no normal value read is required.'}
failed=[x for x in cases if x['status']=='failed'];assert {Path(x['file']).name for x in failed}==set(analysis)
rows=[]
for name,explanation in analysis.items():
 matches=[x for x in failed if Path(x['file']).name==name];assert [x['mode'] for x in matches]==['sloppy','strict']
 for x in matches:
  obs=x['observation'];ev=obs['completion'];assert obs['status']=='host-failure' and obs['phase']=='host' and obs['message']=='unhandled-rejection' and obs['error_type']==obs['error_identity']==obs['harness']==''
  assert ev==dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1)
  assert inv[x['file']]['metadata']['flags']==[]
 rows.append(dict(source=matches[0]['file'],binding=bind(P/'data'/matches[0]['file']),modes=[x['id'] for x in matches],observed='Host final audit veto: one unhandled rejection, audited quiescence, no sticky body/queued/fatal/completion flags.',source_interpretation=explanation,limit='Report does not serialize rejected value; source interpretation is not an observed exact rejection-object identity assertion.'))
unsupported=[x for x in cases if x['status']=='unsupported'];meta=[x for x in unsupported if 'reason' in x];parse=[x for x in unsupported if 'observation' in x];assert len(meta)==len(parse)==4
assert {x['file'] for x in meta}==set(o['class_sources'])
for x in meta:assert x['reason']=='unimplemented declared features: class' and 'class' in inv[x['file']]['metadata']['features']
for x in parse:
 obs=x['observation'];assert obs['status']=='unsupported' and obs['phase']=='parse' and obs['error_type']=='UnsupportedFeature' and obs['message']=="'class' is not supported"
 assert 'class' not in inv[x['file']]['metadata']['features'] and all(not v for k,v in obs['completion'].items() if k!='policy')
assert {Path(x['file']).name for x in parse}=={'resolve-throws-iterator-return-is-not-callable.js','resolve-throws-iterator-return-null-or-undefined.js'}
assert '0n' in (P/'data/test/built-ins/Promise/allSettled/resolve-throws-iterator-return-is-not-callable.js').read_text()
# Log parsing only; preserve exact old Python roster and the thirteen added names.
def tests(log):return re.findall(r'(?m)^(test_\w+ \([^\n]+\)) \.\.\. ok$',log.read_text())
newlog=P/'validation/python-all-1.log';oldlog=Path('/tmp/eris-promise-race-upstream-1/validation/candidate-python-1.log');new=tests(newlog);old=tests(oldlog);focused=tests(P/'validation/candidate-profile-1.log')
assert len(new)==len(set(new))==569 and len(old)==len(set(old))==556 and len(focused)==13 and set(new)==set(old)|set(focused)
receipts=[]
for stem in ['all-settled-observed-1','candidate-profile-1','python-all-1','parent-profile-1']:
 receipt=P/'validation'/(stem+'.json');d=json.loads(receipt.read_text());log=P/'validation'/d['log'];assert bind(log)['sha256']==d['sha256'];receipts +=[bind(receipt),bind(log)]
assert json.loads((P/'validation/all-settled-observed-1.json').read_text())['exit']==1
result=dict(status='clear_independent_static_result_audit',report=bind(report_path),oracle=bind(oracle_path),cases=208,counts=dict(counts),controls_verified=94,control_identity_and_prerequisite_join=True,old_common74_full_records_exact=True,by_policy={str(policy):dict(Counter(x['status'] for x in cases if inv[x['file']]['completion_policy']==policy)) for policy in [0,1]},nonpass_records=[x for x in cases if x['status']!='passed'],failed_source_analysis=rows,unsupported=dict(metadata_modes=4,parser_modes=4,parser_message="'class' is not supported",bigint_qualification='One untagged source contains0n, but these reports stop on class. No independent BigInt refusal or execution observation.'),classification='No synthetic relabeling: all12 report failed rows retain raw host-failure/unhandled-rejection; eight unsupported rows retain four metadata reasons and four actual parser observations. No assertion-failure claim.',python=dict(full=569,prior_exact_names=556,additional_exact_names=13,focused=13,parent='2 groups pass /11 groups error,35 subtest error records; old generic success lookup qualification remains in root parent receipt.'),observed_exit='First unbaselined observation exits1 because retained failed cases exist, despite94 healthy controls. It is not a resource/timeout/adapter failure or a failed control. Baseline recording/replay are separate pending root actions.',bindings=[bind(binary),bind(P/'root/selection-1.json'),bind(P/'replay-parent/upstream-existing-1.json'),bind(oldlog),bind(P/'root/parent-validation.json'),*receipts],pending='Final baseline/replay ledger and final documentation seal; no replay success inferred here.',execution='Read-only JSON/source/log/hash analysis only; no project module import, engine, tests, build, Git or live edits.')
dump(H/'source-review.json',result);print(bind(H/'source-review.json'));print(result['by_policy'])
