from pathlib import Path
import hashlib, json

P = Path('/tmp/eris-promise-all-settled-upstream-plan-1')
W = P / 'worktree'
H = P / 'first-results-review-1'
def read(p): return json.loads(p.read_text())
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())
def check_bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            assert bind(Path(value['path'])) == {k:value[k] for k in ['path','bytes','sha256']}
        for child in value.values(): check_bindings(child)
    elif isinstance(value, list):
        for child in value: check_bindings(child)

ledger = read(P / 'root/replay-validation.json')
check_bindings(ledger)
observed = read(P / 'all-settled-observed-1.json')
keys = ['cases', 'harness_preflight', 'counts', 'runner_policy', 'runner_policy_sha256',
        'corpus_manifest_sha256', 'binary_sha256']
receipts = []
for label in ['all-settled-record-1', 'all-settled-replay-1']:
    current = read(P / (label + '.json'))
    assert all(current[key] == observed[key] for key in keys)
    assert current['regressions'] == current['improvements'] == []
    receipt_path = P / 'validation' / (label + '.json')
    receipt = read(receipt_path)
    assert receipt['exit'] == 0
    assert bind(P / 'validation' / receipt['log'])['sha256'] == receipt['sha256']
    receipts.extend([bind(receipt_path), bind(P / 'validation' / receipt['log'])])
baseline_path = W / 'tests/conformance/test262-promise-all-settled-current.json'
baseline = read(baseline_path)
assert baseline == dict(revision=observed['revision'],
    corpus_manifest_sha256=observed['corpus_manifest_sha256'],
    runner_policy_sha256=observed['runner_policy_sha256'],
    binary_sha256=observed['binary_sha256'],
    cases={row['id']:{k:row[k] for k in ['status','case_sha256','source_sha256']} for row in observed['cases']})
old_counts = []
for comparison in ledger['old_comparisons']:
    old = read(Path(comparison['parent']['path']))
    new = read(Path(comparison['report']['path']))
    assert all(new[key] == old[key] for key in keys)
    assert new['regressions'] == new['improvements'] == []
    assert new['harness_preflight_passed'] and all(x['verified'] for x in new['harness_preflight'])
    receipt = read(Path(comparison['receipt']['path']))
    assert receipt['exit'] == 0
    log = P / 'validation' / receipt['log']
    assert bind(log)['sha256'] == receipt['sha256']
    receipts.extend([comparison['receipt'], bind(log)])
    old_counts.append(dict(profile=comparison['profile'], cases=len(new['cases']), controls=len(new['harness_preflight'])))
assert sum(x['cases'] for x in old_counts) == 842
assert sum(x['controls'] for x in old_counts) == 254
assert observed['harness_preflight'][:74] == read(P/'replay-parent/upstream-existing-1.json')['harness_preflight']
before = read(P/'parent-source.json')['source_sha256']
after = read(P/'source-final.json')['source_sha256']
assert len(before) == 1549 and len(after) == 1672
assert not set(before) - set(after)
changed = sorted(k for k,v in after.items() if before.get(k) != v)
added = sorted(set(after) - set(before))
assert len(changed) == 142 and len(added) == 123
for path, sha in after.items(): assert bind(W/path)['sha256'] == sha, path
rust_inputs = [k for k in before if k.endswith(('.rs','.wgsl')) or Path(k).name in ['Cargo.toml','Cargo.lock']]
assert all(before[k] == after[k] for k in rust_inputs)
old_baselines = [k for k in before if k.startswith('tests/conformance/')]
assert all(before[k] == after[k] for k in old_baselines)
assert all(not k.endswith(('.rs','.wgsl')) for k in added)
result = dict(status='clear_independent_static_replay_addendum',
    first_review=bind(H/'source-review.json'), ledger=bind(P/'root/replay-validation.json'),
    baseline=bind(baseline_path), exact_baseline_projection=True,
    new=dict(cases=208, controls=94, counts=observed['counts'],
        exact_arrays_across_measurement_record_replay=True), old=old_counts,
    old_common74_full_records_exact=True, old_baselines_unchanged=len(old_baselines),
    source=dict(parent=bind(P/'parent-source.json'), final=bind(P/'source-final.json'),
        selected_parent=1549, selected_final=1672, changed_or_new=142, added=123,
        existing_changed=19, unchanged_selected_rust_cargo_shader_inputs=len(rust_inputs),
        current_live_bytes_join=True, changed_paths=changed),
    binary=ledger['binary'], receipt_and_log_bindings=receipts,
    qualification='Baseline command receipt records healthy --record-baseline, followed by a successful --baseline replay. The baseline equals the exact report projection. No old baseline changed. This static audit does not independently observe file-write history. The immutable published API binary was reused; no Rust test/build execution is claimed for this tooling checkpoint.',
    method='Read JSON/log/source bytes and hashes only. No project imports, tests, engine, build, Git mutation or live edits.')
(H/'replay-addendum.json').write_text(json.dumps(result,indent=2)+'\n')
print(bind(H/'replay-addendum.json'))
