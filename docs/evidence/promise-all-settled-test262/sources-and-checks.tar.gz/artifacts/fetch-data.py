from pathlib import Path
import concurrent.futures, hashlib, json, shutil, urllib.request
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1')
Q=Path('/tmp/eris-promise-race-upstream-1/corpus-fetch-1')
REV='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
TREE='bb56695b0f924495618e34495079f998fe83581a'
proof=P/'inventory-proof'; proof.mkdir(exist_ok=True)
for n in ['commit.json','tree-91b2052adad1f066ae031e2ff3a1e9bd6d732886.json','tree-a2eada339f3c7e678edfc08497985f261a9ae258.json','tree-b42c4a8f19ad479b70ee2f64ecd683735d83cde9.json','tree-176043820c3a0729f2da2a047303a984cca036c6.json','tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json']:
 (proof/n).write_bytes((Q/'inventory-proof'/n).read_bytes())
(proof/f'tree-{TREE}.json').write_bytes((Path('/tmp/eris-promise-test262-plan-1/proof')/f'tree-{TREE}.json').read_bytes())
def binding(p):
 b=p.read_bytes(); return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def gitsha(kind,b): return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
for f in proof.glob('tree-*.json'):
 d=json.loads(f.read_text()); assert d['truncated'] is False
 rows=sorted(d['tree'], key=lambda r:(r['path']+('/' if r['type']=='tree' else '')).encode())
 raw=b''.join((r['mode'].lstrip('0')+' '+r['path']).encode()+b'\0'+bytes.fromhex(r['sha']) for r in rows)
 assert gitsha('tree',raw)==d['sha'],f
commit=json.loads((proof/'commit.json').read_text()); assert commit['sha']==REV
root=commit['tree']['sha']; assert root=='91b2052adad1f066ae031e2ff3a1e9bd6d732886'
for name in ['test','built-ins','Promise','allSettled']:
 d=json.loads((proof/f'tree-{root}.json').read_text()); root=next(r['sha'] for r in d['tree'] if r['path']==name and r['type']=='tree')
assert root==TREE
listing=json.loads((proof/f'tree-{TREE}.json').read_text())['tree']
assert len(listing)==104 and all(r['type']=='blob' and r['mode']=='100644' and r['path'].endswith('.js') for r in listing)
def fetch(row):
 rel='test/built-ins/Promise/allSettled/'+row['path']; path=P/'data'/rel; path.parent.mkdir(parents=True,exist_ok=True)
 url=f'https://raw.githubusercontent.com/tc39/test262/{REV}/{rel}'
 b=path.read_bytes() if path.exists() else urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'ErisBrowser-source-inventory'}),timeout=40).read()
 assert gitsha('blob',b)==row['sha'],rel
 path.write_bytes(b)
 return {'relative':rel,'git_blob':row['sha'],'url':url,'binding':binding(path)}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
 rows=list(ex.map(fetch,listing))
result={'status':'authenticated_raw_source_retrieval_only','revision':REV,'directory':'test/built-ins/Promise/allSettled','directory_tree':TREE,'sources':rows,'proof':[binding(f) for f in sorted(proof.glob('*.json'))],'proof_method':'All six tree hashes reconstructed from modes/names/blob IDs; complete root->test->built-ins->Promise->allSettled path checked against pinned commit tree. Commit JSON is retained pinned primary evidence; every source Git blob recomputed from raw bytes.','execution':'No project module import, engine, build, tests, Git command or live edits.'}
(P/'fetch-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
print('authenticated',len(rows),'sources',sum(r['binding']['bytes'] for r in rows),'bytes',flush=True)
