assert.sameValue(typeof checkSettledPromises, 'function');
var value = {}, reason = {}, wrong = {};
var settled = [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }];
checkSettledPromises(settled, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }]);
assert.throws(Test262Error, function() {
  checkSettledPromises(settled, [{ status: 'fulfilled', value: wrong }, { status: 'rejected', reason: reason }]);
});
assert.throws(Test262Error, function() {
  checkSettledPromises(settled, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: wrong }]);
});
