var value = {}, reason = {}, release;
var pending = new Promise(function(resolve) { release = resolve; });
Promise.allSettled([pending, Promise.reject(reason), 7]).then(function(values) {
  checkSettledPromises(values, [{ status: 'fulfilled', value: value }, { status: 'rejected', reason: reason }, { status: 'fulfilled', value: 7 }]);
  assert.sameValue(Object.getPrototypeOf(values[0]), Object.prototype);
  assert.sameValue(Object.getPrototypeOf(values[1]), Object.prototype);
  verifyProperty(values[0], 'status', { value: 'fulfilled', writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[0], 'value', { value: value, writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[1], 'status', { value: 'rejected', writable: true, enumerable: true, configurable: true }, { restore: true });
  verifyProperty(values[1], 'reason', { value: reason, writable: true, enumerable: true, configurable: true }, { restore: true });
}).then($DONE, $DONE);
release(value);
