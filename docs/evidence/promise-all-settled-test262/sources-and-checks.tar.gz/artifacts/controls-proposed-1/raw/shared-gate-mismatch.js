var fulfilled = [], rejected = [], calls = 0, values, returnValue = {}, first = {}, second = {};
function C(executor) {
  executor(function(result) { calls++; values = result; return returnValue; }, function() { throw new Test262Error('unexpected aggregate rejection'); });
}
C.resolve = function(value) { return value; };
function input(index) { return { then: function(f, r) { fulfilled[index] = f; rejected[index] = r; } }; }
var result = Promise.allSettled.call(C, [input(0), input(1)]);
assert.sameValue(result instanceof C, true);
assert.sameValue(calls, 0);
assert.notSameValue(fulfilled[0], rejected[0]);
assert.notSameValue(fulfilled[0], fulfilled[1]);
assert.notSameValue(rejected[0], rejected[1]);
assert.sameValue(rejected[1](second), undefined);
assert.sameValue(fulfilled[1](first), undefined);
assert.sameValue(rejected[1](first), undefined);
assert.sameValue(calls, 0);
assert.sameValue(fulfilled[0](first), returnValue);
assert.sameValue(rejected[0](second), undefined);
assert.sameValue(fulfilled[0](second), undefined);
assert.sameValue(calls, 2);
checkSettledPromises(values, [{ status: 'fulfilled', value: first }, { status: 'rejected', reason: second }]);
