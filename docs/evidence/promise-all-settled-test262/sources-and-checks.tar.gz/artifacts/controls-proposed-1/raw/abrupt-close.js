var marker = {}, rejected, rejects = 0, resolves = 0, nexts = 0, resolveCalls = 0, returnGets = 0, returnCalls = 0, savedF, savedR;
function C(executor) {
  executor(function() { resolves++; }, function(reason) { rejects++; rejected = reason; });
}
C.resolve = function(value) {
  resolveCalls++;
  if (resolveCalls === 2) throw marker;
  return { then: function(f, r) { savedF = f; savedR = r; } };
};
var iterator = { next: function() { nexts++; return { done: false, value: nexts }; } };
Object.defineProperty(iterator, 'return', { get: function() {
  returnGets++;
  return function() { returnCalls++; return {}; };
} });
var input = {};
input[Symbol.iterator] = function() { return iterator; };
var result = Promise.allSettled.call(C, input);
assert.sameValue(result instanceof C, true);
assert.sameValue(rejected, marker);
assert.sameValue(rejects, 1);
assert.sameValue(returnGets, 1);
assert.sameValue(returnCalls, 1);
assert.sameValue(nexts, 2);
assert.sameValue(resolveCalls, 2);
assert.sameValue(savedF(marker), undefined);
assert.sameValue(savedR(marker), undefined);
assert.sameValue(resolves, 0);
assert.sameValue(rejects, 1);
