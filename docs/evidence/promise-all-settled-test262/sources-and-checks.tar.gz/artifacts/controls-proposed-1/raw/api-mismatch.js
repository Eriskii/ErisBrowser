Promise.allSettled = function allSettled(value) {};
assert.sameValue(typeof Promise.allSettled, 'function');
verifyProperty(Promise, 'allSettled', {
  value: Promise.allSettled, writable: true, enumerable: false, configurable: true
}, { restore: true });
verifyProperty(Promise.allSettled, 'name', {
  value: 'allSettled', writable: false, enumerable: false, configurable: true
}, { restore: true });
verifyProperty(Promise.allSettled, 'length', {
  value: 1, writable: false, enumerable: false, configurable: true
}, { restore: true });
assert.sameValue(isConstructor(Promise.allSettled), false);
assert.throws(TypeError, function() { new Promise.allSettled([]); });
