import hashlib
import json
import re
import shutil
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(name):
    return json.loads((A / name).read_bytes())


parent = read('source-parent-controls.json')['source_sha256']
assert len(parent) == 1671
for name, sha in parent.items():
    assert bind(W / name)['sha256'] == sha, name
receipt = read('validation/parent-profile-1.json')
log = A / 'validation/parent-profile-1.log'
assert receipt['exit'] == 1 and receipt['sha256'] == bind(log)['sha256']
text = log.read_text()
passed = re.findall(r'^(test_\w+) \([^\n]*\) \.\.\. ok$', text, re.M)
failed = sorted(set(re.findall(r'^ERROR: (test_\w+) ', text, re.M)))
assert len(passed) == 2 and len(failed) == 11
assert 'Ran 13 tests' in text and 'FAILED (errors=35)' in text
observed = dict(status='observed_expected_parent_boundaries',
    source=bind(A / 'source-parent-controls.json'),
    receipt=bind(A / 'validation/parent-profile-1.json'), log=bind(log),
    groups=13, passed=passed, expected_failed_groups=failed, unittest_error_rows=35,
    qualification='Two independent metadata/old-profile groups pass. Eleven new-profile groups error on absent profile symbols/dispatch. One callback reaches old generic preflight success and its profile-specific mock raises KeyError(success); the other errors are absent-profile keys or the absent variant function. Subtest errors are not additional test groups; deeper refusal assertions are not reached on parent.')
(A / 'root/parent-validation.json').write_text(json.dumps(observed, indent=2) + '\n')

for name in ['tests-before-1/html-review.json', 'migrations-before-1/layout-review.json',
             'migrations-before-1/html-review.json', 'production-1/layout-review.json']:
    assert read(name)['status'].startswith('clear'), name
imports = {}
for hold_name, count in [('production-1', 2), ('migrations-before-1', 16)]:
    held = read(hold_name + '/source-ready.json')
    for row in held['files']:
        assert bind(Path(row['path'])) == row, row['path']
    raw_root = A / hold_name / 'raw'
    raw_files = sorted(p for p in raw_root.rglob('*') if p.is_file())
    assert len(raw_files) == count
    for raw in raw_files:
        name = str(raw.relative_to(raw_root))
        assert name in parent and name not in imports
        before = A / hold_name / 'before' / name
        assert bind(before)['sha256'] == parent[name]
        assert any(row == bind(raw) for row in held['files'])
        imports[name] = raw
assert len(imports) == 18
for name, raw in imports.items():
    shutil.copyfile(raw, W / name)
source = dict(parent)
source.update({name: bind(W / name)['sha256'] for name in imports})
final = A / 'source-candidate-1.json'
assert not final.exists()
final.write_text(json.dumps(dict(source_sha256=dict(sorted(source.items())),
    qualification='Selected map: published1549, complete120-file new corpus, new test and oracle. Eighteen existing Python paths modified; Rust execution sources unchanged.'), indent=2) + '\n')
(A / 'root/production-import.json').write_text(json.dumps(dict(status='verified',
    source=bind(final), imported_paths=sorted(imports),
    production=bind(A / 'production-1/source-ready.json'),
    migrations=bind(A / 'migrations-before-1/source-ready.json'),
    parent_observation=bind(A / 'root/parent-validation.json')), indent=2) + '\n')
print('Imported two production and16 migration paths; source1671 frozen.')
