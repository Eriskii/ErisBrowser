import hashlib
import json
import subprocess
import sys
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
binary = A / 'eris-js-host-published-api'


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(path):
    return json.loads(path.read_bytes())


def run(label, profile, option, baseline):
    report = A / (label + '.json')
    assert not report.exists()
    subprocess.run([sys.executable, str(A / 'run-tool.py'), label, sys.executable, '-B',
        'tools/test262_conformance.py', '--binary', str(binary), '--profile', profile,
        option, baseline, '--output', str(report)], cwd=W, check=True)
    return read(report)


source = read(A / 'source-candidate-2.json')['source_sha256']
for path, sha in source.items():
    assert bind(W / path)['sha256'] == sha, path
binary_hash = 'b653280c13235292194de1491cf134e3523e6b10e21c0eb73f9f19d6301d872a'
assert bind(binary)['sha256'] == binary_hash
observed = read(A / 'all-settled-observed-1.json')
assert observed['counts'] == {'passed': 188, 'failed': 12, 'unsupported': 8}
assert observed['harness_preflight_passed'] and len(observed['harness_preflight']) == 94
assert all(row['verified'] for row in observed['harness_preflight'])
assert len(observed['cases']) == 208 and observed['binary_sha256'] == binary_hash
base_path = 'tests/conformance/test262-promise-all-settled-current.json'
assert not (W / base_path).exists()
recorded = run('all-settled-record-1', 'promise-all-settled', '--record-baseline', base_path)
replayed = run('all-settled-replay-1', 'promise-all-settled', '--baseline', base_path)
keys = ['cases', 'harness_preflight', 'counts', 'runner_policy', 'runner_policy_sha256',
        'corpus_manifest_sha256', 'binary_sha256']
for current in [recorded, replayed]:
    for key in keys:
        assert current[key] == observed[key], key
    assert current['regressions'] == current['improvements'] == []
baseline = read(W / base_path)
assert baseline['cases'] == {row['id']: {key: row[key] for key in
    ['status', 'case_sha256', 'source_sha256']} for row in observed['cases']}
comparisons = []
for profile, parent_name, label in [
        ('promise-race', 'upstream-race-1.json', 'race-replay-1'),
        ('promise-all', 'upstream-all-1.json', 'all-replay-1'),
        ('promise-methods-async', 'upstream-existing-1.json', 'methods-replay-1')]:
    parent = read(A / 'replay-parent' / parent_name)
    report = run(label, profile, '--baseline', 'tests/conformance/test262-' + profile + '-current.json')
    for key in keys:
        assert report[key] == parent[key], (profile, key)
    assert report['regressions'] == report['improvements'] == []
    assert report['harness_preflight_passed'] and all(row['verified'] for row in report['harness_preflight'])
    comparisons.append(dict(profile=profile, cases=len(report['cases']),
        controls=len(report['harness_preflight']), counts=report['counts'],
        parent=bind(A / 'replay-parent' / parent_name), report=bind(A / (label + '.json')),
        receipt=bind(A / 'validation' / (label + '.json')), exact_arrays=True))
assert sum(row['cases'] for row in comparisons) == 842
assert sum(row['controls'] for row in comparisons) == 254
common = read(A / 'replay-parent/upstream-existing-1.json')['harness_preflight']
assert observed['harness_preflight'][:74] == common
for path, sha in source.items():
    assert bind(W / path)['sha256'] == sha, path
assert bind(binary)['sha256'] == binary_hash
source[base_path] = bind(W / base_path)['sha256']
assert len(source) == 1672
final = A / 'source-final.json'
assert not final.exists()
final.write_text(json.dumps(dict(source_sha256=dict(sorted(source.items())),
    qualification='Selected1672-file map: published1549 plus120 corpus files, two prospective test/oracle files and the actual baseline; nineteen existing Python/CI paths modified. Rust execution inputs unchanged.'), indent=2) + '\n')
receipt = dict(status='verified', base='486bca305a08b3711077123dff8b2e968f13ef19',
    source=bind(final), binary=bind(binary), baseline=bind(W / base_path),
    original_observation=bind(A / 'all-settled-observed-1.json'),
    baseline_record=bind(A / 'all-settled-record-1.json'),
    baseline_replay=bind(A / 'all-settled-replay-1.json'),
    new_cases=208, new_controls=94, new_counts=observed['counts'],
    exact_new_case_control_arrays=True, common74_exact=True,
    old_cases=842, old_controls=254, old_comparisons=comparisons,
    regressions=0, improvements=0, old_baseline_changes=0,
    qualification='The first measurement exits1 because not every case passes, despite a healthy harness. Recording and baseline-check commands exit0 while retaining ordinary failed/unsupported cases. No case, assertion, helper, policy or baseline outcome was edited after observation. The immutable published API adapter is reused, not rebuilt.')
(A / 'root/replay-validation.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('New208/94 exactly replay; old842/254 unchanged; source1672 frozen.')
