import hashlib
import json
import re
from collections import Counter
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def read(name):
    return json.loads((A / name).read_bytes())


def command(label, exit_code):
    receipt = A / 'validation' / (label + '.json')
    data = json.loads(receipt.read_bytes())
    log = receipt.with_suffix('.log')
    assert data['exit'] == exit_code and bind(log)['sha256'] == data['sha256'], label
    return dict(receipt=bind(receipt), log=bind(log))


source = read('source-final.json')['source_sha256']
parent = read('parent-source.json')['source_sha256']
assert len(source) == 1672 and len(parent) == 1549 and set(parent) <= set(source)
changed = sorted(name for name, sha in source.items() if parent.get(name) != sha)
assert len(changed) == 142
assert sum(name not in parent for name in changed) == 123
for name, sha in source.items():
    assert bind(W / name)['sha256'] == sha, name
assert not any(name.endswith('.rs') or name.endswith('Cargo.toml') or name.endswith('Cargo.lock') for name in changed)
peer_paths = ['html-corpus-audit-1/review.json', 'controls-proposed-1/layout-review.json',
    'tests-before-1/html-review.json', 'migrations-before-1/layout-review.json',
    'migrations-before-1/html-review.json', 'production-1/layout-review.json',
    'ci-1/layout-review.json', 'validation-review-1/python-review.json',
    'current-source-review-1/source-review.json']
for name in peer_paths:
    assert read(name)['status'].startswith('clear'), name
replay = read('root/replay-validation.json')
assert replay['status'] == 'verified'
assert (replay['new_cases'], replay['new_controls'], replay['old_cases'], replay['old_controls']) == (208, 94, 842, 254)
observed = read('all-settled-observed-1.json')
assert observed['counts'] == {'passed': 188, 'failed': 12, 'unsupported': 8}
failed = [row for row in observed['cases'] if row['status'] == 'failed']
metadata = [row for row in observed['cases'] if row['status'] == 'unsupported' and 'reason' in row]
parsed = [row for row in observed['cases'] if row['status'] == 'unsupported' and 'observation' in row]
assert len(failed) == 12 and len(metadata) == len(parsed) == 4
for row in failed:
    item = row['observation']
    assert (item['status'], item['phase'], item['message']) == ('host-failure', 'host', 'unhandled-rejection')
    assert item['completion'] == dict(policy=0, done_calls=0, success_prints=0,
        failure_prints=0, flags=0, quiescent=True, audited=True, unhandled=1)
assert all(row['reason'] == 'unimplemented declared features: class' for row in metadata)
assert all((row['observation']['status'], row['observation']['phase'], row['observation']['message'])
    == ('unsupported', 'parse', "'class' is not supported") for row in parsed)
commands = {name: command(name, code) for name, code in [
    ('parent-profile-1', 1), ('candidate-profile-1', 0), ('python-all-1', 0),
    ('all-settled-observed-1', 1), ('all-settled-record-1', 0), ('all-settled-replay-1', 0),
    ('race-replay-1', 0), ('all-replay-1', 0), ('methods-replay-1', 0)]}
assert 'Ran 569 tests' in (A / 'validation/python-all-1.log').read_text()
assert re.search(r'^OK$', (A / 'validation/python-all-1.log').read_text(), re.M)
ledger = dict(status='verified', base='486bca305a08b3711077123dff8b2e968f13ef19',
    scope='Add the complete pinned104-source/208-mode Promise.allSettled conformance profile with94 authenticated harness controls and a measured baseline, preserving existing profiles.',
    source=bind(A / 'source-final.json'), parent_source=bind(A / 'parent-source.json'),
    selected_source_inputs=1672, changed_source_paths=changed,
    existing_changed_paths=19, new_paths=123,
    change_components=dict(production_python=2, existing_test_adapters=16,
        exclusion_entries=20, ci=1, new_tests_and_oracle=2, corpus_files=120, baseline=1),
    corpus=dict(revision='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd',
        root_tree='91b2052adad1f066ae031e2ff3a1e9bd6d732886',
        subtree='bb56695b0f924495618e34495079f998fe83581a',
        raw_sources=104, modes=208, async_sources=57, sync_sources=47,
        raw_source_bytes=136313, helper_and_legal_bytes=49033,
        proof_documents=7, proof_bytes=69114, helpers=6, auxiliary_files=8,
        manifest=bind(W / 'tests/upstream/test262-promise-all-settled/manifest.json'),
        raw_source_or_harness_edits=0, filtered_sources=0),
    observed_counts=observed['counts'], new_controls=94, controls_verified=94,
    observations=dict(failed_ids=[row['id'] for row in failed],
        metadata_class_exclusions=[row['id'] for row in metadata],
        parser_class_refusals=[row['id'] for row in parsed],
        passed_policy_counts=dict(Counter(str(row['observation']['completion']['policy'])
            for row in observed['cases'] if row['status'] == 'passed')),
        qualification='The12 failed modes are final-quiescent host-policy vetoes, not observed assertion exceptions. Four modes are class metadata exclusions; four untagged modes actually reach the parser and refuse class syntax. One untagged source also contains0n, but class refusal is observed first; no separate BigInt result is inferred.'),
    baseline=replay['baseline'], release_binary=replay['binary'],
    published_binary_provenance=bind(A / 'root/parent-controls-import.json'),
    replay=bind(A / 'root/replay-validation.json'),
    exact_new_case_control_arrays=True, exact_common74=True,
    exact_old_case_records=842, exact_old_control_records=254,
    regressions=0, improvements=0, old_baseline_changes=0,
    python=dict(full_passed=569, prior_preserved=556, new_groups=13,
        focused_passed=13, parent_passed=2, parent_affected_groups=11,
        parent_error_rows=35, group_renames=0, skipped=0,
        old_adapter_test_groups=245, old_profile_maps=56,
        peer=bind(A / 'validation-review-1/python-review.json')),
    commands=commands, peers=[bind(A / name) for name in peer_paths],
    qualifications=[
        'Parent execution occurs after exact corpus/test import and before profile production import. Two metadata/old-profile groups pass; eleven absent-profile groups generate35 error rows. One error is old generic success dispatch reaching a profile-specific mock, not an engine failure. Deeper negative assertions are not reached on the parent.',
        'All prospective test/oracle, control and production bytes remain unchanged after execution. No assertion, outcome, helper or source was retuned to obtain the baseline.',
        'The initial no-baseline command exits1 because some cases are nonpassing, despite a healthy harness. Baseline recording and checking exit0 while retaining all failed and unsupported cases. No resource, timeout, blocked or adapter-error row is admitted.',
        'The published API release adapter is reused byte-exact. No Rust sources, build manifests, host protocol, runtime caps or library behavior change; no local Rust rebuild or Rust-suite rerun is claimed for this Python/corpus checkpoint.',
        'All56 prior profile tables/features and the245 touched old test-group names/literals are preserved. Actual full case/control replay is limited to the three existing Promise profiles, totaling842/254.',
        'The1672-entry map is a selected input inventory, not the full dependency/build graph. Historical selected maps and evidence archives remain unchanged.',
        'The CI change is an adjacent gate using the existing release host build. No remote CI outcome for this unpublished profile commit is claimed.',
    ],
    limitations=[
        'This complete directory at one pinned Test262 revision is not full ECMAScript conformance.',
        'All12 failed and8 unsupported modes remain visible in the baseline and reports.',
        'Classes, async functions, Promise.any, multiple realms and browser rejection notifications remain unfinished.',
        'No GPU execution, Chromium-relative speed measurement or general security proof is established here.',
        'Full web compatibility and the overall browser objective remain incomplete.',
    ])
path = A / 'root/final-validation.json'
assert not path.exists()
path.write_text(json.dumps(ledger, indent=2) + '\n')
print(json.dumps(dict(status='verified', changed=142, python=569,
    counts=observed['counts'], controls=94, old_cases=842, old_controls=254)))
