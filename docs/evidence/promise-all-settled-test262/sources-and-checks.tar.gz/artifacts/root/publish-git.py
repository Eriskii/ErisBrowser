import json
import subprocess
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
MAIN = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def git(directory, *args):
    return subprocess.check_output(['git', '-C', str(directory), *args], text=True).strip()

v = json.loads((A / 'root/publication-verification.json').read_bytes())
assert v['status'] == 'verified'
base = '486bca305a08b3711077123dff8b2e968f13ef19'
assert git(W, 'rev-parse', 'HEAD') == git(MAIN, 'rev-parse', 'HEAD') == base
assert not git(MAIN, 'status', '--porcelain') and not git(W, 'diff', '--cached', '--name-only')
paths = v['expected_commit_paths']
actual = set(git(W, 'diff', '--name-only').splitlines()) | set(git(W, 'ls-files', '--others', '--exclude-standard').splitlines())
assert actual == set(paths)
subprocess.run(['git', '-C', str(W), 'diff', '--check'], check=True)
subprocess.run(['git', '-C', str(W), 'add', '--', *paths], check=True)
assert set(git(W, 'diff', '--cached', '--name-only').splitlines()) == set(paths)
message = A / 'commit-message.txt'
message.write_text('Add complete pinned Promise.allSettled conformance profile\n\nRetain all 104 original sources and 208 modes with root-linked Git proofs,\nsix unchanged helpers and 94 authenticated harness controls. Record 188\npassed, 12 final-unhandled host-policy failures and eight class exclusions\nor parser refusals without filtering sources or changing host policy.\n\nValidate 569 Python tests and exact new 208-case/94-control replay. Preserve\nall 842 prior Promise cases, 254 controls and historical baselines. Reuse\nthe published API adapter; add the adjacent CI gate and retained evidence.\n')
subprocess.run(['git', '-C', str(W), 'commit', '-F', str(message)], check=True)
commit = git(W, 'rev-parse', 'HEAD')
assert not git(W, 'status', '--porcelain')
subprocess.run(['git', '-C', str(MAIN), 'merge', '--ff-only', commit], check=True)
subprocess.run(['git', '-C', str(MAIN), 'push', 'origin', 'main'], check=True)
assert git(MAIN, 'rev-parse', 'HEAD') == commit and not git(MAIN, 'status', '--porcelain')
(A / 'root/github-publication.json').write_text(json.dumps(dict(commit=commit,
    remote='https://github.com/Eriskii/ErisBrowser', push='success', ci_status='pending',
    note='Postpublication state intentionally outside the immutable evidence archive.'), indent=2) + '\n')
print('Published ' + commit)
