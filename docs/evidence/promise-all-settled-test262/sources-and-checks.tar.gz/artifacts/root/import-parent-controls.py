import hashlib
import json
import shutil
import subprocess
from pathlib import Path, PurePosixPath

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
B = Path('/tmp/eris-promise-all-settled-plan-1')


def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def verify(row):
    assert bind(Path(row['path'])) == row, row['path']


base = '486bca305a08b3711077123dff8b2e968f13ef19'
assert subprocess.check_output(['git', '-C', str(W), 'rev-parse', 'HEAD'], text=True).strip() == base
assert not subprocess.check_output(['git', '-C', str(W), 'status', '--porcelain'], text=True).strip()
parent = json.loads((A / 'parent-source.json').read_bytes())['source_sha256']
assert len(parent) == 1549
for name, sha in parent.items():
    assert bind(W / name)['sha256'] == sha, name

held = json.loads((A / 'tests-before-1/source-ready.json').read_bytes())
for row in held['files']:
    verify(row)
corpus_path = Path(held['corpus_ready']['path'])
verify(held['corpus_ready'])
corpus = json.loads(corpus_path.read_bytes())
assert len(corpus['files']) == corpus['count'] == 120
destinations = {}
prefix = 'tests/upstream/test262-promise-all-settled/'
for row in corpus['files']:
    rel = PurePosixPath(row['relative'])
    assert not rel.is_absolute() and '..' not in rel.parts
    source = Path(row['source'])
    assert bind(source)['sha256'] == row['sha256'] and source.stat().st_size == row['bytes']
    name = prefix + str(rel)
    assert name not in destinations and not (W / name).exists()
    destinations[name] = source
for name in held['new_paths']:
    source = A / 'tests-before-1/raw' / name
    assert any(row == bind(source) for row in held['files'])
    assert name not in destinations and not (W / name).exists()
    destinations[name] = source
assert len(destinations) == 122
for name, source in destinations.items():
    destination = W / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, destination)
    assert bind(source)['sha256'] == bind(destination)['sha256']
source = dict(parent)
source.update({name: bind(W / name)['sha256'] for name in destinations})
assert len(source) == 1671
inventory = A / 'source-parent-controls.json'
inventory.write_text(json.dumps(dict(source_sha256=dict(sorted(source.items())),
    qualification='Selected source map, not a complete build graph; published1549 plus120 corpus files and two prospective test/oracle files. Production unchanged.'), indent=2) + '\n')
binary = A / 'eris-js-host-published-api'
assert not binary.exists()
shutil.copy2(B / 'eris-js-host-final-1', binary)
assert bind(binary)['sha256'] == 'b653280c13235292194de1491cf134e3523e6b10e21c0eb73f9f19d6301d872a'
replay = A / 'replay-parent'
replay.mkdir()
for name in ['upstream-race-1.json', 'upstream-all-1.json', 'upstream-existing-1.json']:
    shutil.copyfile(B / name, replay / name)
    assert bind(B / name)['sha256'] == bind(replay / name)['sha256']
receipt = dict(status='verified_parent_controls_import', base=base,
    parent=bind(A / 'parent-source.json'), source=bind(inventory),
    hold=bind(A / 'tests-before-1/source-ready.json'), corpus=bind(corpus_path),
    new_paths=sorted(destinations), binary=bind(binary),
    original_binary=bind(B / 'eris-js-host-final-1'),
    original_binary_identity=bind(B / 'eris-js-host-final-1.json'),
    original_api_validation=bind(B / 'root/final-validation.json'),
    qualification='Reused immutable published API release adapter. This checkpoint changes Python profile tooling and corpus, not Rust execution sources.')
(A / 'root/parent-controls-import.json').write_text(json.dumps(receipt, indent=2) + '\n')
print('Imported122 exact prospective paths; all1549 published source hashes preserved.')
