from pathlib import Path
import json,hashlib,ast,difflib
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');T=P/'tests-before-1';M=P/'migrations-before-1'
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def sha(b):return hashlib.sha256(b).hexdigest()
def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
verified=0
def refs(v):
 global verified
 if isinstance(v,dict):
  if all(k in v for k in ['path','bytes','sha256']):
   b=bind(v['path']);assert(b['bytes'],b['sha256'])==(v['bytes'],v['sha256']),v['path'];verified+=1
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
def read(p):return json.loads(Path(p).read_text())
h=read(T/'source-ready.json');refs(h);mh=read(M/'source-ready.json');refs(mh)
o=read(T/'raw/tools/promise-all-settled-profile-oracle.json');raw=T/'raw/tools/test_test262_promise_all_settled_profile.py';tree=ast.parse(raw.read_text())
const={t.id:ast.literal_eval(n.value)for n in tree.body if isinstance(n,ast.Assign)and isinstance(n.value,ast.Constant)for t in n.targets if isinstance(t,ast.Name)}
assert const['ORACLE_SHA']==bind(T/'raw/tools/promise-all-settled-profile-oracle.json')['sha256']
names=[n.name for n in ast.walk(tree)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert len(names)==13
assert o['metadata']==read(P/'metadata.json')and o['counts']==read(P/'census.json')
rows=read(P/'html-corpus-audit-1/census.json')['rows'];ids=read(P/'case-identities.json');byid={r['id']:r for r in ids}
expected=[]
for row in rows:
 for mode in row['modes']:
  cid=row['path']+':'+mode;expected.append({'id':cid,'case_sha256':byid[cid]['case_sha256'],'policy':row['completion_policy'],'harness':row['harness'],'class_excluded':'class'in row['metadata']['features']})
assert o['case_identities']==expected and o['case_identities_sha256']==sha(canon(expected))
assert o['class_sources']==[r['path']for r in rows if 'class'in r['metadata']['features']]
manifest=read(T/'expected-manifest.json');assert manifest==o['expected_manifest']and bind(T/'expected-manifest.json')['sha256']==o['manifest_sha256']=='bca16210396a6aa07adac947ff47166cde4b4da97f4f7a82d24e9d8763b7ef8e'
assert (T/'expected-manifest.json').read_text()==json.dumps(manifest,indent=2)+'\n'
assert manifest['scope']==read(P/'plan.json')['scope_literal']and manifest['format']==1 and manifest['test_files']==104
assert manifest['directories']=={'Promise/allSettled':sorted(Path(r['path']).name for r in rows)}
for row in manifest['files']:
 b=bind(P/'data'/row['path']);assert row['upstream_path']==row['path']and(b['bytes'],b['sha256'])==(row['bytes'],row['sha256'])
proof=manifest['inventory_proof'];assert proof['method']=='complete-nonrecursive-git-trees'and proof['root_tree']==read(P/'plan.json')['root_tree']and proof['directory_trees']=={'Promise/allSettled':'bb56695b0f924495618e34495079f998fe83581a'}
assert proof['auxiliary_blobs']=={x['relative']:x['git_blob']for x in read(P/'auxiliary.json')}
for row in proof['files']:
 b=bind(P/row['path']);assert(b['bytes'],b['sha256'])==(row['bytes'],row['sha256']);j=read(P/row['path']);assert row['url']==j['url']
assert len(manifest['files'])==112 and len(proof['files'])==7
corpus=read(T/'corpus-ready.json');assert corpus['count']==len(corpus['files'])==120
assert {r['relative']for r in corpus['files']}=={r['path']for r in manifest['files']+proof['files']}|{'manifest.json'}
for row in corpus['files']:
 b=bind(row['source']);assert(b['bytes'],b['sha256'])==(row['bytes'],row['sha256'])
controls=read(P/'controls-proposed-1/variants.json')['variants'];assert controls==o['controls']
old={name:read(P/'source-snapshots/tools'/name)for name in o['existing_oracles']}
for name,binding in o['existing_oracles'].items():
 b=bind(P/'source-snapshots/tools'/name);assert(b['bytes'],b['sha256'])==(binding['bytes'],binding['sha256'])
common=old['promise-methods-runner-oracle.json']['controls'];assert len(common)==37
helpers={r['relative']:r['binding']['sha256']for r in read(P/'auxiliary.json')}
def control_ids(variants,prefix,extra_helpers=None):
 helper_hash=dict(helpers);helper_hash.update(extra_helpers or {});result=[]
 for mode in ['sloppy','strict']:
  for row in variants:
   policy=row['completion_policy'];hs=['assert.js','sta.js']+(['doneprintHandle.js']if policy else[])+row['includes'];md={'flags':['async']if policy else[],'includes':row['includes'],'features':[],'locale':[],'negative':None};source=sha(row['source'].encode())
   ident={'source_sha256':source,'mode':mode,'metadata':md,'harness':[{'name':n,'sha256':helper_hash['harness/'+n]}for n in hs],'completion_policy':policy}
   result.append({'name':prefix+row['name'],'mode':mode,'case_sha256':sha(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode()),'source_sha256':source})
 return result
assert o['preflight']==control_ids(controls,'promise-all-settled-')and len(o['preflight'])==20
commonids=control_ids(common,'promise-methods-');assert len(commonids)==74
for profile,name in [('promise-methods-async',None),('promise-all','promise-all-profile-oracle.json'),('promise-race','promise-race-profile-oracle.json')]:
 tail=[]
 if name:
  oldmanifest=old[name]['expected_manifest'];extra={r['path']:r['sha256']for r in oldmanifest['files']if r['path'].startswith('harness/')};tail=control_ids(old[name]['controls'],profile+'-',extra)
 assert o['old_control_identities'][profile]==commonids+tail
 manifest_path=P/'source-snapshots/tests/upstream'/('test262-'+profile)/'manifest.json';assert bind(manifest_path)['sha256']==o['old_manifest_hashes'][profile]
assert sum(map(len,o['old_control_identities'].values()))==254
maps=read(P/'existing-profile-tables.json');assert o['old_tables']=={k:maps[k]for k in ['profiles','roots','tree_profiles']}and o['old_features']==maps['features'];assert sha(canon(o['old_tables']))==o['old_tables_sha256']
assert o['features']==read(P/'plan.json')['features']['proposed'];assert sha(json.dumps(o['policy'],sort_keys=True).encode())==o['policy_sha256']
previous=old['promise-race-profile-oracle.json']['policy'];assert {k:v for k,v in o['policy'].items()if k!='supported_features'}=={k:v for k,v in previous.items()if k!='supported_features'}
# Exact inverses and all old AST literals/test names, including the race old55 control.
selection=read(M/'selection.json');refs(selection);assert selection['paths']==16 and selection['entries']==20
migrated=[];total_groups=0;entrycount=0
for row in selection['rows']:
 oldtext=Path(row['before']['path']).read_text();newtext=Path(row['raw']['path']).read_text();inverse=newtext.replace(", 'promise-all-settled'",'')
 if row['path']=='tools/test_test262_promise_race_profile.py':inverse=inverse.replace('if k not in {PROFILE}','if k != PROFILE')
 assert inverse==oldtext
 assert ''.join(difflib.unified_diff(oldtext.splitlines(True),newtext.splitlines(True),fromfile='before/'+row['path'],tofile='raw/'+row['path']))==Path(row['diff']['path']).read_text()
 assert oldtext==(P/'source-snapshots'/row['path']).read_text()
 before_ast=ast.parse(oldtext);after_ast=ast.parse(inverse);assert ast.dump(before_ast)==ast.dump(after_ast)
 groupnames=[n.name for n in ast.walk(before_ast)if isinstance(n,ast.FunctionDef)and n.name.startswith('test_')];assert groupnames==row['groups'];total_groups+=len(groupnames)
 assert newtext.count("'promise-all-settled'")-oldtext.count("'promise-all-settled'")==row['entries'];entrycount+=row['entries'];migrated.append({'path':row['path'],'groups':len(groupnames),'entries':row['entries']})
assert total_groups==245 and entrycount==20
migration_review={'status':'clear','hold':bind(M/'source-ready.json'),'selection':bind(M/'selection.json'),'checker':bind(T/'html-check.py'),'paths':16,'exclusion_entries':20,'old_test_groups_preserved':245,'checks':'All before bytes join held published tooling snapshots. Removing only new-profile exclusions, plus restoring two race old55 inequality spellings, exactly recovers every old file and AST. All old numeric/hash/assertion literals and test names remain unchanged.','rows':migrated,'findings':[],'execution':'Inert stdlib hash/AST/diff only; no importer/runner/tests or live writes.'}
(M/'html-review.json').write_text(json.dumps(migration_review,indent=2)+'\n')
review={'status':'clear','hold':bind(T/'source-ready.json'),'oracle':bind(T/'raw/tools/promise-all-settled-profile-oracle.json'),'raw_module':bind(raw),'checker':bind(T/'html-check.py'),'corpus_review':bind(P/'html-corpus-audit-1/review.json'),'migration_review':bind(M/'html-review.json'),'bindings_verified':verified,'groups':13,'manifest_files':120,'mode_identities':208,'new_control_modes':20,'common_control_modes':74,'selected_gate':94,'old_profile_maps':56,'old_mode_fingerprints':842,'old_control_fingerprints':254,'checks':['Module imports use existing parent modules and do not resolve the new profile or new functions at module scope. The two metadata/preservation groups are source-predicted parent passes after corpus installation; eleven require absent new-profile/API seams. This is not an execution result.','All104 metadata rows and208 fingerprints derive from authenticated raw bytes, ordered harness bytes and integer policy; absent timeout stays absent. Complete120-file manifest joins112 data files,7 proof documents and manifest.','All20 new control fingerprints and254 old per-profile control fingerprints independently rederive from literal source, mode, completion policy and ordered helper bytes. Existing old cases are checked against unchanged hash-bound old oracles/complete manifests.','Old56 preservation method avoids new-profile lookups, keeps all37/8/8 existing control literals and full842 identities, and compares each existing policy/hash.','Corruption cases isolate raw Git authentication after recomputing local checksums; missing entries, truncated/changed tree proof and listed-but-unbound proofs are distinguished. Unlisted non-JS files are explicitly outside the asserted proof-rejection claim.','Same-mode common/pair/helper positive failures invalidate dependent negative rows; opposite-mode success cannot substitute. Negative-verifier corruptions preserve healthy positives to isolate wrong error identity, missing/unauthenticated completion and fatal refusal.','Missing/duplicate/extra/wrong-name/wrong-mode/unverified gate rows block all208 cases and prevent baseline creation. Valid legacyERJR2 remains failed/unverified; disabled-host response is adapter-error, with complete frames avoiding truncation confounds.','Synthetic204 failed/4 unsupported rows are expressly mock host-veto observations, not upstream predictions. Resource/timeout/adapter-error suppress baseline creation.','All16 migration paths have exact narrow inverses, preserving245 old test names and all original count/hash/assertion literals.'],'findings':[],'execution':'Source/AST/JSON/hash/diff arithmetic only. No project imports, tests, engine/compiler/network execution or live-source edits.'}
(T/'html-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({'tests':bind(T/'html-review.json'),'migrations':bind(M/'html-review.json')},indent=2))
