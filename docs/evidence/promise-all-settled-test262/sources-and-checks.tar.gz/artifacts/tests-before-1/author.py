from pathlib import Path
import ast,copy,difflib,hashlib,json,re
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1'); H=P/'tests-before-1'; W=Path('/tmp/eris-promise-all-settled-plan-1/worktree')
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(v):return json.dumps(v,sort_keys=True,separators=(',',':')).encode()
def binding(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def dump(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n')
plan=json.loads((P/'plan.json').read_text());rows=json.loads((P/'inventory.json').read_text());aux=json.loads((P/'auxiliary.json').read_text());census=json.loads((P/'census.json').read_text())
rev=plan['revision'];profile=plan['profile'];proofroot=P/'inventory-proof'
proof_description=dict(method='complete-nonrecursive-git-trees',revision=rev,root_tree=plan['root_tree'],directory_trees={'Promise/allSettled':census['directory_tree']},auxiliary_blobs={r['relative']:r['git_blob'] for r in sorted(aux,key=lambda r:r['relative'])})
# Match existing helper insertion order (sorted helpers, then LICENSE/INTERPRETING).
proof_description['auxiliary_blobs']={r['relative']:r['git_blob'] for r in sorted(aux,key=lambda r:r['relative']) if r['relative'].startswith('harness/')}
for n in ['LICENSE','INTERPRETING.md']:proof_description['auxiliary_blobs'][n]=next(r['git_blob'] for r in aux if r['relative']==n)
manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=rev,scope=plan['scope_literal'],directories={'Promise/allSettled':[r['relative'].split('/')[-1] for r in rows]},test_files=104,files=[],inventory_proof=dict(proof_description,files=[]))
for p in sorted(proofroot.glob('*.json')):
 rel='inventory-proof/'+p.name;route='commits/'+rev if p.name=='commit.json' else 'trees/'+p.stem.removeprefix('tree-')
 b=p.read_bytes();manifest['inventory_proof']['files'].append(dict(path=rel,bytes=len(b),sha256=sha(b),url='https://api.github.com/repos/tc39/test262/git/'+route))
for p in sorted((P/'data').rglob('*')):
 if p.is_file():
  rel=str(p.relative_to(P/'data'));b=p.read_bytes();manifest['files'].append(dict(path=rel,upstream_path=rel,bytes=len(b),sha256=sha(b)))
assert len(manifest['files'])==112 and len(manifest['inventory_proof']['files'])==7
manifest_path=H/'expected-manifest.json';dump(manifest_path,manifest)
ids=[];selected_by_id={r['id']:r for r in json.loads((P/'case-identities.json').read_text())}
for r in rows:
 for mode in ['sloppy','strict']:
  name=r['relative']+':'+mode
  ids.append(dict(id=name,case_sha256=selected_by_id[name]['case_sha256'],policy=r['completion_policy'],harness=r['harness'],class_excluded='class' in r['metadata']['features']))
oldnames=['promise-all-profile-oracle.json','promise-methods-runner-oracle.json','promise-race-profile-oracle.json'];existing={n:json.loads((W/'tools'/n).read_text()) for n in oldnames};common=existing[oldnames[1]]['controls'];oldall=existing[oldnames[0]];oldrace=existing[oldnames[2]]
controls=json.loads((P/'controls-proposed-1/variants.json').read_text())['variants'];preflight=[{k:r[k] for k in ['name','mode','case_sha256','source_sha256']} for r in json.loads((P/'controls-proposed-1/observations.json').read_text())['rows']]
policy=copy.deepcopy(oldrace['policy']);policy['supported_features']=plan['features']['proposed']
tables=json.loads((P/'existing-profile-tables.json').read_text());oldtables={k:tables[k] for k in ['profiles','roots','tree_profiles']}
old_control_identities={}
def control_rows(variants,prefix,corpus):
 out=[]
 for mode in ['sloppy','strict']:
  for r in variants:
   md=dict(flags=['async'] if r['completion_policy'] else [],includes=r['includes'],features=[],locale=[],negative=None)
   names=['assert.js','sta.js']+(['doneprintHandle.js'] if r['completion_policy'] else [])+r['includes']
   ident=dict(source_sha256=sha(r['source'].encode()),mode=mode,metadata=md,harness=[dict(name=n,sha256=sha((corpus/'harness'/n).read_bytes())) for n in names],completion_policy=r['completion_policy'])
   out.append(dict(name=prefix+r['name'],mode=mode,case_sha256=sha(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode()),source_sha256=ident['source_sha256']))
 return out
for prof in ['promise-methods-async','promise-all','promise-race']:
 corpus=W/'tests/upstream'/('test262-'+prof)
 value=control_rows(common,'promise-methods-',corpus)
 assert value==oldrace['common74']
 if prof!='promise-methods-async':value+=control_rows(oldall['controls'] if prof=='promise-all' else oldrace['controls'],prof+'-',corpus)
 if prof=='promise-race':assert value[74:]==oldrace['preflight']
 old_control_identities[prof]=value
oracle=dict(schema=1,profile=profile,expected_manifest=manifest,manifest_sha256=sha(manifest_path.read_bytes()),counts=census,metadata=json.loads((P/'metadata.json').read_text()),auxiliary_files=sorted(r['relative'] for r in aux),case_identities=ids,case_identities_sha256=sha(canonical(ids)),class_sources=[r['relative'] for r in rows if 'class' in r['metadata']['features']],features=plan['features']['proposed'],policy=policy,policy_sha256=sha(json.dumps(policy,sort_keys=True).encode()),controls=controls,preflight=preflight,old_tables=oldtables,old_tables_sha256=sha(canonical(oldtables)),old_features=tables['features'],existing_oracles={n:{k:binding(W/'tools'/n)[k] for k in ['bytes','sha256']} for n in oldnames},old_manifest_hashes={prof:sha((W/'tests/upstream'/('test262-'+prof)/'manifest.json').read_bytes()) for prof in old_control_identities},old_control_identities=old_control_identities,scope='All source/test expectations derive before production from raw pinned bytes and preserved source/oracles. No new upstream outcome prediction or observed-output correction.')
op=H/'raw/tools/promise-all-settled-profile-oracle.json';dump(op,oracle)
source=(P/'source-snapshots/tools/test_test262_promise_race_profile.py').read_text()
# Retain established independent transport/policy/corruption test machinery, adapt selected identities.
source=source.replace('Frozen race profile','Frozen allSettled profile').replace('PromiseRaceProfileTests','PromiseAllSettledProfileTests').replace('promise-race','promise-all-settled').replace('promise_race','promise_all_settled').replace('Promise/race','Promise/allSettled').replace('RACE_TREE','SETTLED_TREE').replace('fe8e0bf36a2323ffb4f03d63d56e1516e0855900',census['directory_tree'])
source=re.sub(r"ORACLE_SHA = '[0-9a-f]+'","ORACLE_SHA = '"+sha(op.read_bytes())+"'",source)
# Only new-profile section numeric changes; preserved old controls are rewritten explicitly below.
a,tail=source.split('    def test_existing_55_tables_and_both_promise_profiles_remain_exact',1)
a=a.replace('test_complete_94_selection','test_complete_104_selection').replace("{'Promise/allSettled': 94}","{'Promise/allSettled': 104}").replace('(94, 103, 7)','(104, 112, 7)').replace('66506','69114').replace('(94, 63, 102171)','(104, 57, 136313)').replace("'doneprintHandle.js', 'compareArray.js',","'doneprintHandle.js',").replace("{'Promise/allSettled': 93}","{'Promise/allSettled': 103}").replace("{'Promise/allSettled': 94, 'Promise/all': 98}","{'Promise/allSettled': 104, 'Promise/all': 98}")
a=a.replace('188','208').replace('(94, 103, 208, [])','(104, 112, 208, [])').replace('[94, 94]','[104, 104]').replace("for c in cases), 126)","for c in cases), 114)").replace("'harness/compareArray.js'","'harness/promiseHelper.js'")
a=a.replace('test_exact_90_preflights','test_exact_94_preflights').replace('(90, 90)','(94, 94)').replace('len(results), 90','len(results), 94').replace('process.call_count, 90','process.call_count, 94').replace("{'failed': 184, 'unsupported': 4}","{'failed': 204, 'unsupported': 4}")
a=a.replace("self.all_oracle = self.existing['promise-all-profile-oracle.json']","self.all_oracle = self.existing['promise-all-profile-oracle.json']\n        self.race_oracle = self.existing['promise-race-profile-oracle.json']")
a=a.replace("names = self.oracle['auxiliary_files'] if profile == PROFILE else self.all_oracle['auxiliary_files']","names = (self.oracle['auxiliary_files'] if profile == PROFILE else\n                 self.race_oracle['auxiliary_files'] if profile == 'promise-race' else\n                 self.all_oracle['auxiliary_files'])")
a=a.replace("rows.update({'promise-all-' + r['name']: r for r in self.all_oracle['controls']})","rows.update({'promise-all-' + r['name']: r for r in self.all_oracle['controls']})\n        rows.update({'promise-race-' + r['name']: r for r in self.race_oracle['controls']})")
a=a.replace("            if row['prerequisite']:\n                required.append", "            required.extend(('promise-all-settled-' + name, mode)\n                            for name in row['additional_prerequisites'])\n            if row['prerequisite']:\n                required.append")
needle="        def break_host(case, row, result):"
extra="""        # The newly used settled helper is a same-mode prerequisite of both
        # settlement and shared-gate pairs, not merely a file-presence check.
        def break_helper(case, row, result):
            return dict(status='failed') if case['mode'] == 'strict' and case['id'] == 'harness-preflight:promise-all-settled-settled-helper' else result
        _, results = self.capture(break_helper)
        for item in results[74:]:
            dependent = any(item['name'] == 'promise-all-settled-' + name + suffix
                            for name in ('settled-helper', 'settlement', 'shared-gate')
                            for suffix in ('', '-mismatch'))
            self.assertEqual(item['verified'], not (dependent and item['result']['mode'] == 'strict'))
"""
assert needle in a;a=a.replace(needle,extra+needle)
old="""    def test_existing_56_tables_and_all_three_promise_profiles_remain_exact(self):
        # Parent-compatible: no new profile, function or transport is looked up.
        tables = dict(profiles={k: v for k, v in importer.PROFILES.items() if k != PROFILE},
                      roots={k: v for k, v in importer.PROFILE_ROOTS.items() if k != PROFILE},
                      tree_profiles=sorted(importer.TREE_PROFILES - {PROFILE}))
        self.assertEqual(tables, self.oracle['old_tables'])
        self.assertEqual((len(tables['profiles']), digest(canonical(tables))), (56, self.oracle['old_tables_sha256']))
        self.assertEqual({k: sorted(v) for k, v in runner.PROFILE_FEATURES.items() if k != PROFILE},
                         self.oracle['old_features'])
        self.assertEqual(runner.promise_preflight_variants(), self.common)
        self.assertEqual(runner.promise_all_preflight_variants(), self.all_oracle['controls'])
        self.assertEqual(runner.promise_race_preflight_variants(), self.race_oracle['controls'])
        for profile in ('promise-methods-async', 'promise-all', 'promise-race'):
            corpus = importer.ROOT / 'tests/upstream' / ('test262-' + profile)
            old = (self.all_oracle['old_profile'] if profile == 'promise-methods-async' else
                   self.all_oracle if profile == 'promise-all' else self.race_oracle)
            expected_manifest = old['manifest'] if profile == 'promise-methods-async' else old['expected_manifest']
            self.assertEqual(digest((corpus / 'manifest.json').read_bytes()), self.oracle['old_manifest_hashes'][profile])
            self.assertEqual(json.loads((corpus / 'manifest.json').read_bytes()), expected_manifest)
            manifest, _, cases, fixtures, _ = runner.load_corpus(corpus, profile)
            self.assertEqual(identities(cases), old['case_identities'])
            self.assertTrue(all('timeout' not in c['metadata'] for c in cases))
            self.assertEqual(fixtures, [])
            expected_counts = {'promise-methods-async': (232, 458, 74),
                               'promise-all': (98, 196, 90), 'promise-race': (94, 188, 90)}[profile]
            _, preflight = self.capture(profile=profile)
            self.assertEqual((manifest['test_files'], len(cases), len(preflight)), expected_counts)
            actual = [dict(name=r['name'], mode=r['result']['mode'],
                           case_sha256=r['result']['case_sha256'], source_sha256=r['result']['source_sha256'])
                      for r in preflight]
            self.assertEqual(actual, self.oracle['old_control_identities'][profile])
            code, report, recorded, _ = legacy.PromiseRunnerTests().report(profile, preflight)
            self.assertEqual((code, recorded), (0, True))
            self.assertEqual((report['runner_policy'], report['runner_policy_sha256']), (old['policy'], old['policy_sha256']))


if __name__ == '__main__':
    unittest.main()
"""
source=a+old
parsed=ast.parse(source);test_class=next(n for n in parsed.body if isinstance(n,ast.ClassDef));groups=[n.name for n in test_class.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')];assert len(groups)==13
# Syntax parsing only; no compilation/module import or execution.
mp=H/'raw/tools/test_test262_promise_all_settled_profile.py';mp.write_text(source)
(H/'before/tools').mkdir(parents=True,exist_ok=True);(H/'before/tools/test_test262_promise_race_profile.py').write_text((P/'source-snapshots/tools/test_test262_promise_race_profile.py').read_text())
patch=''.join(difflib.unified_diff((P/'source-snapshots/tools/test_test262_promise_race_profile.py').read_text().splitlines(True),source.splitlines(True),fromfile='reference/tools/test_test262_promise_race_profile.py',tofile='raw/tools/test_test262_promise_all_settled_profile.py'))
(H/'adaptation.patch').write_text(patch)
roster=[]
for name in groups:
 preservation='raw_metadata_modes' in name or 'existing_56_tables' in name
 roster.append(dict(name=name,parent_api_eligible=True,predicted_parent='pass' if preservation else 'fail: absent promise-all-settled profile lookup; no new helper called at import',candidate_requirement='pass',qualification='Source prediction only; corpus and new oracle/module must be imported before parent baseline.'))
dump(H/'roster.json',dict(groups=roster,total=13,parent_prediction=dict(pass_groups=2,fail_groups=11),not_observed=True))
corpus_files=[dict(relative=r['path'],source=str(P/'data'/r['path']),bytes=r['bytes'],sha256=r['sha256']) for r in manifest['files']]
corpus_files += [dict(relative=r['path'],source=str(P/r['path']),bytes=r['bytes'],sha256=r['sha256']) for r in manifest['inventory_proof']['files']]
corpus_files.append(dict(relative='manifest.json',source=str(manifest_path),bytes=len(manifest_path.read_bytes()),sha256=sha(manifest_path.read_bytes())))
dump(H/'corpus-ready.json',dict(status='prospective_exact_manifest_no_project_execution',profile=profile,files=corpus_files,count=120,scope_literal=plan['scope_literal'],manifest=binding(manifest_path),derivation='Existing source schema/order and held raw bytes only; no importer or project module invoked.'))
dump(H/'notes.json',dict(status='frozen_tests_before_profile_production',groups=13,reuse='Adapted established race13 source-only test machinery; source reference and exact adaptation diff retained. Own data/metadata/fingerprints/caps derive from complete authenticated104.',source_census='104 sources/208 modes,57async/47sync,sixhelpers,eightauxiliary,sevenproofs69114bytes.',controls='Selected proposed ten literals/twenty mode rows + exactcommon74; extra helperpositive dependencies tested independently. No source literal changes.',old_preservation='56 tables/features, all three existingprofile manifests, exact842 case fingerprints and254 preflight fingerprints; historical source/oracles/hash expectations are bound, not regenerated.',parent_eligibility='All13 import/run through old public Python APIs, but11 intentionally require absent newprofile. Metadata census and old56 preservation should pass after corpus import. No parent observation claimed.',limits='No host protocol, Runtime, resource cap or shared-verifier changes. Legacy ERJR2 remains failed/nonverified, unavailablehost adapter-error; finalunhandled synthetic report rows remain separate host policy.',no_execution='AST syntax parse, literal source construction, JSON/hash/diff only. No project imports, test, build, engine, browser, or live edits.'))
# Bind frozen source inputs including standard schema and controls. New raw files are additions only.
inputs=[P/'source-ready.json',P/'controls-proposed-1/source-ready.json',P/'source-bindings.json',P/'inventory.json',P/'case-identities.json',P/'metadata.json',P/'census.json',P/'existing-profile-tables.json',P/'source-snapshots/tools/import_test262.py',P/'source-snapshots/tools/test262_conformance.py']+[W/'tools'/n for n in oldnames]+[W/'tools/test_test262_promise_runner.py']
dump(H/'source-bindings.json',dict(inputs=[binding(p) for p in inputs],base='c97b200c9bddf1527cdbbc5a652beedba27c1d6d',tooling_base='f3e70ba152fdd3b730b1dd1494963a77f5141161',no_live_source_edits=True))
files=[binding(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
dump(H/'source-ready.json',dict(status='sealed_external_test_oracle_hold_before_production',groups=13,new_paths=['tools/test_test262_promise_all_settled_profile.py','tools/promise-all-settled-profile-oracle.json'],corpus_ready=binding(H/'corpus-ready.json'),files=files,roster=binding(H/'roster.json'),parent_eligibility='13 groups use importable parent APIs; source-predicted2pass11absent-profile failures with corpus installed. No execution.',controls=binding(P/'controls-proposed-1/source-ready.json'),no_production=True))
print(binding(H/'source-ready.json'));print('manifest',binding(manifest_path));print('oracle',binding(op));print('groups',groups)
