from pathlib import Path
import ast,difflib,hashlib,json,pprint
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');H=P/'production-1';W=Path('/tmp/eris-promise-all-settled-plan-1/worktree')
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def dump(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n')
def function(s,name):
 n=next(x for x in ast.parse(s).body if isinstance(x,ast.FunctionDef) and x.name==name);return ''.join(s.splitlines(True)[n.lineno-1:n.end_lineno])
plan=json.loads((P/'plan.json').read_text());variants=json.loads((P/'controls-proposed-1/variants.json').read_text())['variants'];edits={};rows=[]
for rel in ['tools/import_test262.py','tools/test262_conformance.py']:
 before=(P/'source-snapshots'/rel).read_text();assert (W/rel).read_text()==before
 s=before;changes=[]
 def replace(old,new,count=1):
  global s
  assert s.count(old)==count,(rel,old[:70],s.count(old),count)
  s=s.replace(old,new);changes.append(dict(old=old,new=new,count=count))
 if rel.endswith('import_test262.py'):
  const="PROMISE_ALL_SETTLED_DIRECTORIES = {'Promise/allSettled': 104}\nPROMISE_ALL_SETTLED_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js',\n                               'isConstructor.js', 'promiseHelper.js', 'propertyHelper.js'}\n"
  replace("TREE_PROFILES = {'promise-race'",const+"TREE_PROFILES = {'promise-all-settled', 'promise-race'")
  replace("PROFILES = {'promise-race':", "PROFILES = {'promise-all-settled': PROMISE_ALL_SETTLED_DIRECTORIES, 'promise-race':")
  replace("PROFILE_ROOTS = {'promise-race':", "PROFILE_ROOTS = {'promise-all-settled': 'test/built-ins', 'promise-race':")
  old="def profile_tree_inventory(profile, read=None):\n"
  new=old+"""    if profile == 'promise-all-settled':
        if (PROFILES[profile] != PROMISE_ALL_SETTLED_DIRECTORIES
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.allSettled frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            PROMISE_ALL_SETTLED_DIRECTORIES, 'test/built-ins', read,
            auxiliary_helpers=PROMISE_ALL_SETTLED_HELPERS)
        if any(len(listings[name]) != count for name, count in PROMISE_ALL_SETTLED_DIRECTORIES.items()):
            raise ValueError('Promise.allSettled complete directory counts differ')
        return listings, proof, description
"""
  replace(old,new)
  old="    if profile == 'promise-race' and harness != PROMISE_RACE_HELPERS:\n"
  replace(old,"    if profile == 'promise-all-settled' and harness != PROMISE_ALL_SETTLED_HELPERS:\n        raise ValueError('Promise.allSettled requested harness differs from the frozen six helpers')\n"+old)
  replace("    if profile in {'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'", "    if profile in {'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'")
  old="    scope = {\n"
  replace(old,old+"        'promise-all-settled': "+repr(plan['scope_literal'])+",\n")
 else:
  old="PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE, PROMISE_RACE_PROFILE}\n"
  new="""PROMISE_ALL_SETTLED_PROFILE = 'promise-all-settled'
PROMISE_ALL_SETTLED_FEATURES = PROMISE_RACE_FEATURES | {'Promise.allSettled'}
PROFILE_FEATURES[PROMISE_ALL_SETTLED_PROFILE] = PROMISE_ALL_SETTLED_FEATURES
PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE, PROMISE_RACE_PROFILE, PROMISE_ALL_SETTLED_PROFILE}
"""
  replace(old,new)
  replace("profile in {'promise-race', 'promise-all', 'promise-methods-async'", "profile in {'promise-all-settled', 'promise-race', 'promise-all', 'promise-methods-async'",2)
  old="    if profile == PROMISE_RACE_PROFILE:\n        return promise_race_harness_preflight(files, binary, timeout)\n"
  replace(old,"    if profile == PROMISE_ALL_SETTLED_PROFILE:\n        return promise_all_settled_harness_preflight(files, binary, timeout)\n"+old)
  newfn="def promise_all_settled_preflight_variants():\n    # Literal pairs frozen before this profile's runner implementation.\n    return "+pprint.pformat(variants,width=100,sort_dicts=False).replace('\n','\n    ')+"\n\n\n"
  gate=function(before,'promise_race_preflight_healthy').replace('promise_race','promise_all_settled').replace('promise-race-','promise-all-settled-')
  harness=function(before,'promise_race_harness_preflight').replace('promise_race','promise_all_settled').replace('promise-race-','promise-all-settled-').replace('PROMISE_RACE','PROMISE_ALL_SETTLED')
  old="            required = common_names.copy()\n"
  assert harness.count(old)==1
  harness=harness.replace(old,old+"            required.extend('promise-all-settled-' + name\n                            for name in row['additional_prerequisites'])\n")
  newfn+=gate+'\n\n'+harness+'\n\n'
  replace('def check_baseline(previous, current):\n',newfn+'def check_baseline(previous, current):\n')
  old='        preflight_ok = (promise_race_preflight_healthy(preflight) if args.profile == PROMISE_RACE_PROFILE\n'
  replace(old,'        preflight_ok = (promise_all_settled_preflight_healthy(preflight) if args.profile == PROMISE_ALL_SETTLED_PROFILE\n                        else promise_race_preflight_healthy(preflight) if args.profile == PROMISE_RACE_PROFILE\n')
 inverse=s
 for change in reversed(changes):
  assert inverse.count(change['new'])==change['count'],(rel,'inverse',change['old'][:40])
  inverse=inverse.replace(change['new'],change['old'])
 assert inverse==before
 ast.parse(s)
 for which,text in [('before',before),('raw',s)]:
  p=H/which/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text)
 diff=''.join(difflib.unified_diff(before.splitlines(True),s.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel));p=H/'diffs'/(rel.replace('/','__')+'.patch');p.parent.mkdir(exist_ok=True);p.write_text(diff)
 edits[rel]=changes
 # All untouched functions retain exact full source, not just matching test outputs.
 bfunc={n.name:function(before,n.name) for n in ast.parse(before).body if isinstance(n,ast.FunctionDef)}
 afunc={n.name:function(s,n.name) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
 changed=[n for n,v in bfunc.items() if afunc[n]!=v]
 allowed=['profile_tree_inventory','import_corpus'] if rel.endswith('import_test262.py') else ['load_corpus','harness_preflight','main']
 assert sorted(changed)==sorted(allowed)
 rows.append(dict(path=rel,before=bind(H/'before'/rel),raw=bind(H/'raw'/rel),diff=bind(p),exact_inverse=True,changed_existing_functions=changed,unchanged_functions=[dict(name=n,sha256=hashlib.sha256(v.encode()).hexdigest()) for n,v in bfunc.items() if n not in changed]))
# Full literal vector exactness without executing a production function.
r=(H/'raw/tools/test262_conformance.py').read_text();n=next(n for n in ast.parse(r).body if isinstance(n,ast.FunctionDef) and n.name=='promise_all_settled_preflight_variants');assert ast.literal_eval(next(x.value for x in n.body if isinstance(x,ast.Return)))==variants
for name in ['promise_preflight_variants','promise_all_preflight_variants','promise_race_preflight_variants','case_fingerprint','promise_preflight_verified','encode_request','decode_response']:
 assert function((H/'before/tools/test262_conformance.py').read_text(),name)==function(r,name)
dump(H/'inverse-edits.json',edits)
dump(H/'notes.json',dict(status='external_production_draft_source_only',scope='Only importer/runner two paths; no corpus/test/migration/CI/docs/Runtime/protocol/cap edit.',base='Exact published AX tooling retained through AY/allSettled candidate; root will bind published allSettled API checkout before live import.',selection='Complete immediate104 sources,208 modes, sixhelpers+twolegal, sevenrootproofs; newprofileonly Promise.allSettled featuretag; exact held94control contract.',gate='Originalcommon74 unchanged prefix;20new literalrows with exact identities and same-mode common/helper/pair prerequisites. Missing/duplicate/extra/wrong/unverified rows nonhealthy. New controls reuse existing authenticated verifier.',preservation='Reverse the recorded exact additions to recover both parent files byte-for-byte; all old variants/transport/verifier/fingerprint/helper/branches remain unchanged. Existing maps gain only newprofile entry.',files=rows,tests='13 frozen prospective groups and16path/20exclusion migrations remain separate, unedited holds. No tests executed.',execution='Stdlib AST/literal formatting/hash/diff only; no project module imports, JS, Rust/compiler/build/tests/browser/Git or live edits.'))
inputs=[P/'source-ready.json',P/'tests-before-1/source-ready.json',P/'migrations-before-1/source-ready.json',P/'controls-proposed-1/source-ready.json',P/'controls-proposed-1/layout-review.json']
dump(H/'source-bindings.json',dict(inputs=[bind(p) for p in inputs],before_parent=bind(Path('/tmp/eris-promise-all-settled-plan-1/parent-source.json'))))
files=[bind(p) for p in sorted(H.rglob('*')) if p.is_file() and p.name!='source-ready.json']
dump(H/'source-ready.json',dict(status='sealed_external_two_file_profile_production',paths=['tools/import_test262.py','tools/test262_conformance.py'],files=files,source_bindings=bind(H/'source-bindings.json'),notes=bind(H/'notes.json'),inverse=bind(H/'inverse-edits.json'),import_gate='Root-owned parent corpus/test observation, published API/binary refresh and independent source peer required before live import. No outcome assertion.'))
print(bind(H/'source-ready.json'));print('new literals exact; full before inverse both paths; changed functions',[r['changed_existing_functions'] for r in rows])
