from pathlib import Path
import json,hashlib,re,collections,textwrap
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');D=P/'html-corpus-audit-1';W=Path('/tmp/eris-promise-all-settled-plan-1/worktree')
def bind(p):
 b=Path(p).read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def obj(kind,b):return hashlib.sha1(kind.encode()+b' '+str(len(b)).encode()+b'\0'+b).hexdigest()
f=json.loads((P/'fetch-receipt.json').read_text());trees={};proofs=[]
for ref in f['proof']:
 assert bind(ref['path'])==ref;v=json.loads(Path(ref['path']).read_bytes());proofs.append(ref)
 if 'truncated' not in v:commit=v;continue
 assert v['truncated'] is False
 entries=sorted(v['tree'],key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
 payload=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
 assert obj('tree',payload)==v['sha'];trees[v['sha']]=v
assert len(trees)==6 and commit['sha']==f['revision'];sha=commit['tree']['sha'];route=[]
for name in f['directory'].split('/'):
 entry=next(e for e in trees[sha]['tree'] if e['path']==name);assert entry['type']=='tree';sha=entry['sha'];route.append({'name':name,'tree':sha})
assert sha==f['directory_tree'];leaf=trees[sha]['tree'];assert len(leaf)==104
assert {e['path']:e['sha'] for e in leaf}=={Path(e['relative']).name:e['git_blob']for e in f['sources']}
assert all(e['mode']=='100644' and e['type']=='blob' for e in leaf)
assert {x.relative_to(P/'data').as_posix()for x in (P/'data'/f['directory']).rglob('*.js')}=={e['relative']for e in f['sources']}
counts={k:collections.Counter() for k in ['flags','features','includes','locale']};rows=[];class_bodies=[];bigint_literals=[];spreads=[]
for source in f['sources']:
 assert bind(source['binding']['path'])==source['binding'];b=Path(source['binding']['path']).read_bytes();assert obj('blob',b)==source['git_blob'];t=b.decode()
 assert t.count('/*---')==t.count('---*/')==1
 front=textwrap.dedent(t.split('/*---',1)[1].split('---*/',1)[0]);meta={}
 for key in counts:
  matches=re.findall(r'^'+key+r':[ \t]*(.*)$',front,re.M);assert len(matches)<=1
  if matches:
   field=matches[0].strip();assert field.startswith('[')and field.endswith(']'),(source['relative'],key)
   vals=[v.strip().strip('\"\'') for v in field[1:-1].split(',') if v.strip()];assert len(vals)==len(set(vals))
   assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',v)for v in vals)
  else:vals=[]
  meta[key]=vals;counts[key].update(vals)
 assert not re.search(r'^(negative|timeout):',front,re.M)
 meta['negative']=None
 assert set(meta['flags']) <= {'async'} and not meta['locale']
 mode_list=['sloppy','strict'];policy=int('async'in meta['flags'])
 rows.append({'path':source['relative'],'source':source['binding'],'git_blob':source['git_blob'],'metadata':meta,'modes':mode_list,'completion_policy':policy,'harness':['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+meta['includes']})
 body=re.sub(r'/\*.*?\*/|//[^\n]*','',t,flags=re.S)
 if re.search(r'\bclass\b',body):class_bodies.append(source['relative'])
 if re.search(r'(?<![\w$])(?:0[xX][0-9A-Fa-f]+|0[bB][01]+|0[oO][0-7]+|[0-9]+)n\b',body):bigint_literals.append(source['relative'])
 if '...' in body:spreads.append(source['relative'])
 assert not re.search(r'\$262\b|\bProxy\b',body)
helper_names=sorted({h for row in rows for h in row['harness']});assert len(helper_names)==6
root=trees[commit['tree']['sha']]['tree'];harness_id=next(e['sha']for e in root if e['path']=='harness');harness={e['path']:e for e in trees[harness_id]['tree']};helpers=[]
for name in helper_names:
 p=W/'tests/upstream/test262-promise-race/harness'/name;b=p.read_bytes();assert obj('blob',b)==harness[name]['sha'];helpers.append({'name':name,'source':bind(p),'git_blob':harness[name]['sha']})
legal=[]
for name in ['LICENSE','INTERPRETING.md']:
 entry=next(e for e in root if e['path']==name);p=W/'tests/upstream/test262-promise-race'/name;b=p.read_bytes();assert obj('blob',b)==entry['sha'];legal.append({'name':name,'source':bind(p),'git_blob':entry['sha']})
assert len(rows)==104 and sum(r['completion_policy']for r in rows)==57
census={'status':'independent_source_census_before_profile_selection_or_execution','fetch_receipt':bind(P/'fetch-receipt.json'),'revision':f['revision'],'directory':f['directory'],'authentication':{'six_tree_hashes_reconstructed':True,'complete_route':route,'leaf_entries':104,'raw_blob_ids_verified':104,'commit_scope':'Pinned unsigned GitHub commit JSON retained as primary evidence; original Git commit object bytes/timezone were not independently reconstructed.'},'proof':proofs,'sources':104,'modes':208,'async_sources':57,'async_modes':114,'sync_sources':47,'sync_modes':94,'metadata_counts':{k:dict(sorted(v.items()))for k,v in counts.items()},'negative_fields':0,'timeout_fields':0,'raw_module_only_strict_no_strict_flags':0,'helpers':helpers,'license_and_interpretation':legal,'class_bodies':class_bodies,'bigint_literal_bodies':bigint_literals,'spread_bodies':spreads,'source_scanning_scope':'Bounded lexical scan after removing comments, not a JavaScript parse or exhaustive compatibility proof. A prior message checked only BigInt identifier; this audit explicitly includes the untagged 0n literal.','policy_conditions':'A new profile must add Promise.allSettled only to its selected feature policy and remain an authenticated Promise host profile. Under that proposed policy, two class-declared files are metadata-ineligible; both untagged class files remain adapter-dispatched. Eligibility does not predict parser/test success.','helper_path':'Existing promiseHelper.js checkSettledPromises checks ordered own status/value/reason records, both status variants, payloads and absence of the opposite payload key; selecting the helper file alone does not exercise its function.','runner_source':bind(W/'tools/test262_conformance.py'),'metadata_parser_source':bind(W/'tools/import_test262.py'),'rows':rows,'execution':'No project imports, engine execution, compilation or live-source changes; independent stdlib/hash/metadata read only.'}
(D/'census.json').write_text(json.dumps(census,indent=2)+'\n');print(json.dumps({'census':bind(D/'census.json'),'derive':bind(D/'derive.py')},indent=2))
