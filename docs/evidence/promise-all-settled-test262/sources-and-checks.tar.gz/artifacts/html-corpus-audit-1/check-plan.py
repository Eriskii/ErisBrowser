from pathlib import Path
import hashlib,json,ast
P=Path('/tmp/eris-promise-all-settled-upstream-plan-1');D=P/'html-corpus-audit-1';W=Path('/tmp/eris-promise-all-settled-plan-1/worktree')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
checked=0
def refs(v):
 global checked
 if isinstance(v,dict):
  if all(k in v for k in ['path','bytes','sha256']):
   b=bind(v['path']);assert(b['bytes'],b['sha256'])==(v['bytes'],v['sha256']),v['path'];checked+=1
  for x in v.values():refs(x)
 elif isinstance(v,list):
  for x in v:refs(x)
# Read only literal data and simple set/dict operations from the AST; never import/execute project code.
def data_env(path):
 env={}
 def ev(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return env[n.id]
  if isinstance(n,ast.Dict):return {ev(k):ev(v)for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.Set):return set(ev(x)for x in n.elts)
  if isinstance(n,(ast.List,ast.Tuple)):return [ev(x)for x in n.elts]
  if isinstance(n,ast.BinOp)and isinstance(n.op,ast.BitOr):return ev(n.left)|ev(n.right)
  if isinstance(n,ast.BinOp)and isinstance(n.op,ast.Add):return ev(n.left)+ev(n.right)
  if isinstance(n,ast.Call)and isinstance(n.func,ast.Attribute)and n.func.attr=='copy'and not n.args and not n.keywords:return ev(n.func.value).copy()
  raise ValueError(type(n).__name__)
 for node in ast.parse(Path(path).read_text()).body:
  if not isinstance(node,ast.Assign):continue
  try:v=ev(node.value)
  except (ValueError,KeyError,TypeError):continue
  for target in node.targets:
   if isinstance(target,ast.Name):env[target.id]=v
   elif isinstance(target,ast.Subscript)and isinstance(target.value,ast.Name):
    try:env[target.value.id][ev(target.slice)]=v
    except KeyError:pass
 return env
h=json.loads((P/'source-ready.json').read_text());refs(h)
assert bind(P/'source-ready.json')['sha256']=='365a74f55944cdda5b2c48f7f35c7ceb8034b5114ef2609a0194818523d488ab'
own=json.loads((D/'census.json').read_text());c=json.loads((P/'census.json').read_text());meta=json.loads((P/'metadata.json').read_text());inventory=json.loads((P/'inventory.json').read_text());ids=json.loads((P/'case-identities.json').read_text())
assert own['sources']==c['sources']==104 and own['modes']==c['modes']==208
assert own['async_sources']==c['async_sources']==57 and own['sync_sources']==c['sync_sources']==47
for k in ['features','includes','flags']:assert own['metadata_counts'][k]==c[k]
assert own['negative_fields']==own['timeout_fields']==c['negative_sources']==c['timeout_sources']==c['locale_sources']==0
assert {r['path']:r['metadata']for r in own['rows']}==meta
expected_inventory=[];expected_ids=[]
for row in own['rows']:
 rel=row['path'];sb=row['source'];expected_inventory.append({'relative':rel,'bytes':sb['bytes'],'sha256':sb['sha256'],'git_blob':row['git_blob'],'metadata':row['metadata'],'modes':row['modes'],'completion_policy':row['completion_policy'],'harness':row['harness']})
 for mode in row['modes']:
  identity={'source_sha256':sb['sha256'],'mode':mode,'metadata':row['metadata'],'harness':[{'name':n,'sha256':bind(P/'data/harness'/n)['sha256']}for n in row['harness']],'completion_policy':row['completion_policy']}
  digest=hashlib.sha256(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()).hexdigest()
  expected_ids.append({'id':rel+':'+mode,'case_sha256':digest,'source_sha256':sb['sha256'],'completion_policy':row['completion_policy']})
assert expected_inventory==inventory and expected_ids==ids
assert c['case_identity_vector_sha256']==hashlib.sha256(json.dumps(ids,sort_keys=True,separators=(',',':')).encode()).hexdigest()
assert c['source_bytes']==sum(r['source']['bytes']for r in own['rows'])==136313
aux=json.loads((P/'auxiliary.json').read_text());refs(aux);assert len(aux)==8 and c['auxiliary_bytes']==sum(r['binding']['bytes']for r in aux)==49033
own_aux={('harness/'+r['name']):r for r in own['helpers']};own_aux.update({r['name']:r for r in own['license_and_interpretation']})
assert {r['relative']for r in aux}==set(own_aux)
for row in aux:
 r=own_aux[row['relative']];assert row['git_blob']==r['git_blob']and row['binding']['sha256']==r['source']['sha256']and row['binding']['bytes']==r['source']['bytes']
assert c['proof_documents']==7 and c['proof_bytes']==sum(r['bytes']for r in own['proof'])==69114
assert c['data_files']==112 and c['future_corpus_files_with_proofs_manifest']==120
bindings=json.loads((P/'source-bindings.json').read_text());refs(bindings);parent=json.loads(Path(bindings['parent_inventory']['path']).read_text())['source_sha256']
for s in bindings['sources']:
 assert s['parent_sha256']==s['snapshot']['sha256']==parent[s['relative']]==bind(W/s['relative'])['sha256']
imp=data_env(P/'source-snapshots/tools/import_test262.py');run=data_env(P/'source-snapshots/tools/test262_conformance.py');old=json.loads((P/'existing-profile-tables.json').read_text())
assert old['profiles']==imp['PROFILES']and old['roots']==imp['PROFILE_ROOTS']and old['tree_profiles']==sorted(imp['TREE_PROFILES'])
assert old['features']=={k:sorted(v)for k,v in run['PROFILE_FEATURES'].items()}
assert len(old['profiles'])==len(old['roots'])==len(old['features'])==56
plan=json.loads((P/'plan.json').read_text());assert plan['features']['proposed']==sorted(set(old['features']['promise-race'])|{'Promise.allSettled'})
assert sum(2 for r in own['rows']if set(r['metadata']['features'])-set(plan['features']['proposed']))==4
legacy=json.loads((P/'legacy-adapters.json').read_text());assert legacy['paths']==len(legacy['adapters'])==16 and legacy['exclusion_entries']==sum(len(x['entries'])for x in legacy['adapters'])==20
assert legacy['existing_profiles']==56 and legacy['proposed_profiles']==57
for row in legacy['adapters']:
 lines=(P/'source-snapshots'/row['path']).read_text().splitlines()
 for entry in row['entries']:assert lines[entry['line']-1]==entry['source']and ('promise-race'in entry['source']or(row['path']=='tools/test_test262_promise_race_profile.py'and 'PROFILE'in entry['source']))
assert plan['old_preservation']['promise_sources']==424 and plan['old_preservation']['promise_modes']==842 and plan['old_preservation']['promise_control_rows']==254
control=json.loads((P/'controls-proposed-1/source-ready.json').read_text());refs(control);assert control['common_modes']==74 and control['variants']==10 and control['modes']==20 and control['total_controls']==94
r={'status':'clear','scope':'Complete source inventory, metadata/fingerprint derivation, helper/proof closure and proposed importer/runner preservation seams. Control literal semantics remain assigned to the separate Layout peer; executable tests/production are separate holds.','hold':bind(P/'source-ready.json'),'plan':bind(P/'plan.json'),'independent_census':bind(D/'census.json'),'independent_derivation':bind(D/'derive.py'),'checker':bind(D/'check-plan.py'),'bindings_verified':checked,'authentication':own['authentication'],'source_and_modes':{'sources':104,'modes':208,'async_sources':57,'async_modes':114,'sync_sources':47,'sync_modes':94,'all208_fingerprints_rederived':True,'timeout_absent_not_null':True,'source_bytes':136313,'helpers':6,'license_and_interpretation_files':2,'data_files':112,'proof_documents':7,'prospective_manifest_inclusive_files':120},'metadata_counts':own['metadata_counts'],'policy_caveats':['Only two class-tagged sources are metadata-ineligible under the proposed profile feature set, preserving all208 denominator rows. Two untagged class sources remain adapter-dispatched; one also contains untagged0n. Eligibility204 is not a parser/test outcome prediction.','Three bodies use call spread/rest; the existing implementation behavior must be observed, not inferred from metadata alone.','The common helper bytes are unchanged, but checkSettledPromises is a separately relevant function path; the proposed helper positive/no-op-poison pair supplies targeted coverage pending its literal peer.','Discarded rejected promises can trigger the existing final-quiescent host-policy veto independently of upstream assertion success. Source caveats remain conditional and do not copy another profile\'s observed counts.'],'preservation':{'old_profile_maps':56,'old_feature_maps':56,'old_tree_profiles':25,'selected_migration_paths':16,'selected_exclusion_entries':20,'prior_promise_sources':424,'prior_promise_mode_records':842,'prior_per_profile_controls':254,'source_snapshots_join_published_parent':True,'semantics':'New profile-local feature tag, proof selection, control factory/gate and dispatch additions only. Existing parser/fingerprint/transport/verifier functions, old tables and old oracle/count/hash literals must remain unchanged in future production. All16/20 entries match the exact old source lines; this does not pre-clear an unreviewed migration implementation.'},'proposed_control_roster':{'common_rows':74,'new_pairs':5,'new_rows':20,'total':94,'status':'proposed contract, no observed run or production claim'},'remaining_gates':['Published allSettled parent and release-binary binding before next-checkpoint execution.','Separate executable13-group tests/oracle and16-path migration peer, then additive two-file production peer.','Healthy actual94-control gate before208-case execution; retain all statuses and complete old842/254 comparisons.'],'findings':[],'execution':'Independent source reads, restricted AST data interpretation and stdlib hash/JSON arithmetic only; no project imports, engine, compiler, project tests or live-source edits.'}
p=D/'review.json';p.write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(bind(p),indent=2))
