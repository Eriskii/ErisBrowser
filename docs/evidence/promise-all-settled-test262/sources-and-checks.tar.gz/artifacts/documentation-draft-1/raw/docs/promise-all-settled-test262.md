# Promise.allSettled upstream results

<!-- External draft: result placeholders must be replaced from reviewed reports before import. -->

The complete immediate Test262 `test/built-ins/Promise/allSettled` directory at
revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd` contains 104 sources and
208 required sloppy/strict modes. {{RESULT_SUMMARY}}
Every selected mode remains in the denominator. This is a bounded selection,
not full Promise or ECMAScript conformance.

The [manifest](../tests/upstream/test262-promise-all-settled/manifest.json)
binds every original source, six unchanged harness helpers and two
legal/instruction files to the pinned Git root. Seven complete nonrecursive
proof documents establish the directory ancestry and raw blob identities.
There are 57 asynchronous sources (114 modes) and 47 synchronous sources
(94 modes). No source is rewritten or removed because of its feature tags,
syntax or eventual result. File, proof, byte and runtime limits remain unchanged.

{{OBSERVED_RESULT_TABLE_AND_NONPASS_ANALYSIS}}

Two sources declare the unsupported `class` feature. Two further bodies contain
class syntax without that declaration; one also contains `0n`. The untagged
sources remain subject to normal adapter execution and reporting. Source syntax
inspection does not determine their observed result. Any final-quiescent
unhandled-rejection veto retains its separate host-policy reason, rather than
being relabeled as an upstream assertion failure or a pass.

The profile reuses the optional `test262-host` adapter and its authenticated
`$DONE` completion, sticky error observations and final audit. It adds only
`Promise.allSettled` to its own supported feature set. The three older Promise
profiles keep their existing feature policies, source identities and baselines.
No Rust, resource-cap, transport or host-policy change belongs to this checkpoint.
The release adapter comes from the published
[Promise.allSettled implementation](promise-all-settled.md) at `486bca305a08`.

The gate requires 94 verified control rows: the unchanged 74 common controls,
then five positive/mismatch pairs in both modes. The new pairs check method
metadata and nonconstruction; both branches of `checkSettledPromises`; mixed
settlement order, payloads and own descriptors; paired callback gates and the
last callback's generic resolve return value; and ordinary abrupt iterator
closing with the unfinished-iteration sentinel retained. The helper pair also
requires exact assertion failures for wrong fulfilled values and rejected
reasons; its poisoned variant replaces the helper with a no-op.

Each new row requires all 37 common controls in its mode. The settlement and
shared-gate pairs additionally require the same-mode healthy settled helper;
each mismatch requires its matching positive. Missing, duplicate, extra,
wrong-mode or unverified controls block the upstream cases and baseline
recording. A deliberate mismatch is healthy only when its expected exact
synchronous assertion or authenticated asynchronous completion error is verified.
The pinned `promiseHelper.js` remains unchanged; this profile exercises its
already-defined `checkSettledPromises` path as well as the common sequence helper.

{{OBSERVED_PYTHON_PARENT_AND_CANDIDATE_VALIDATION}}

The 13 frozen profile groups cover complete source/proof/helper authentication,
metadata and mode identities, locally rehashed mutations, missing or unbound
inputs, exact control dependencies, unavailable host capability, malformed
completion evidence, blocked reports and old-profile preservation. Sixteen old
test files add the new profile to 20 existing exclusion sites, preserving their
historical table counts and hash expectations. The new preservation group
separately binds all 56 prior profile maps and feature sets.

{{OBSERVED_REPLAY_AND_BINARY_BINDINGS}}

The preservation comparisons cover the prior 842 Promise case identities and
254 control rows across the methods, all and race profiles. Their reports retain
all prior statuses. New-profile replay compares all 208 case records and all
94 control records, rather than only aggregate counts.

To run the regression gate:

```sh
cargo build --locked --release --features test262-host --bin eris-js
python3 tools/test262_conformance.py --binary target/release/eris-js \
  --profile promise-all-settled \
  --baseline tests/conformance/test262-promise-all-settled-current.json \
  --output artifacts/test262-promise-all-settled-gate.json
```

{{OBSERVED_CI_CONFIGURATION_STATUS}}
The [baseline](../tests/conformance/test262-promise-all-settled-current.json)
preserves every mode's status and identity. A successful regression gate means
the controls are healthy and no recorded pass regressed; it does not establish
that every mode passed. The
[evidence record](evidence/promise-all-settled-test262/summary.json) binds the
raw reports, immutable source and binary identities, frozen controls and tests,
parent observations and any retained corrections. Earlier checkpoint chapters
and their measured figures remain historical records.
