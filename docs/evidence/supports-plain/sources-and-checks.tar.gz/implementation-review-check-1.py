from pathlib import Path
import json,hashlib,difflib,subprocess,re
R=Path('/tmp/eris-supports-plain-plan-1');BASE='64cd81afb7ab38e61872253f3d3665c23eb9435a'
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(n):return json.loads((R/n).read_text())
def blob(n):return subprocess.run(['git','-C',str(R/'worktree'),'show',BASE+':'+n],check=True,capture_output=True).stdout
checked=set()
def walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys():
   p=Path(v['path'])
   if p.is_absolute() and not str(p).startswith(str(R/'worktree')+'/'):
    assert bind(p)=={k:v[k]for k in ['path','bytes','sha256']};checked.add(str(p))
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
names=['implementation-1/source-ready.json','implementation-1/accounting.json','implementation-1/special-lifetime-proof.json','implementation-1/checks.json','migrations-1/source-ready.json']
for n in names:walk(read(n))
prod=read(names[0]);mig=read('migrations-1/source-ready.json');edits=read('implementation-1/edits.json');medits=read('migrations-1/edits.json')
assert len(prod['files'])==1 and prod['files'][0]['path']=='src/css.rs';assert len(edits)==7
before=Path(prod['files'][0]['before']['path']).read_text();after=Path(prod['files'][0]['raw']['path']).read_text();assert before.encode()==blob('src/css.rs')
def apply(source,es,inverse=False):
 for x in reversed(es)if inverse else es:
  a,b=(x['after'],x['before'])if inverse else(x['before'],x['after']);assert source.count(a)==1,x['label'];source=source.replace(a,b,1)
 return source
assert apply(before,edits)==after;assert apply(after,edits,True)==before
files=prod['files']+mig['files']
for f in files:
 old=Path(f['before']['path']).read_text();new=Path(f['raw']['path']).read_text();assert old.encode()==blob(f['path'])
 for k,a,b in [('forward',old,new),('inverse',new,old)]:
  patch=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='a/'+f['path'],tofile='b/'+f['path']))
  assert Path(f[k]['path']).read_text()==patch
for f,m in zip(mig['files'],medits):
 assert f['path']==m['path'];old=Path(f['before']['path']).read_text();new=Path(f['raw']['path']).read_text();assert apply(old,m['edits'])==new;assert apply(new,m['edits'],True)==old
 assert re.findall(r'#\[test\]\s*fn (\w+)',old)==re.findall(r'#\[test\]\s*fn (\w+)',new)
 # Migration replaces only selected booleans or relocates one identical raw literal.
 tokens=lambda s:sorted(re.findall(r'r"(?:[^"\\]|\\.)*"|"(?:[^"\\]|\\.)*"',s))
 assert tokens(old)==tokens(new)
combined1=apply(after,medits[0]['edits']);combined2=apply(Path(mig['files'][0]['raw']['path']).read_text(),edits);assert combined1==combined2
assert apply(apply(combined1,medits[0]['edits'],True),edits,True)==before
assert before[:before.index('pub(crate) fn supports_declaration_with_budget(')]==after[:after.index('pub(crate) fn supports_declaration_with_budget(')]
marker='fn supports_declaration_parts(source:';assert before[before.index(marker):]==after[after.index(marker):]
# Same-indent function boundaries give complete top-level/impl member slices.
def method(s,name):
 m=re.search(r'(?m)^( *)(?:(?:pub(?:\([^\n]*\))? )?)fn '+re.escape(name)+r'\(',s);assert m,name
 indent=m.group(1);tail=s[m.start():];end=re.search(r'(?m)^'+re.escape(indent)+r'}\s*$',tail);assert end,name
 return tail[:end.end()].rstrip()
unchanged=[]
for n in ['pending_declaration','pending_value','supports_property','supports_length','supports_number','supports_declaration_parts','css_identifier','css_identifier_checked','property_alias','supported_ordinary_property','keyword_value_property','valid_calculations','valid_declaration_value','valid_object_property','valid_background_property','parse_object_fit','parse_object_position','parse_calculation','parse_length','finite_number','supports_matches_with_budget','spend','tokens','condition','leaf']:
 a=method(before,n);b=method(after,n);assert a==b,n;unchanged.append(dict(name=n,bytes=len(a.encode()),sha256=hashlib.sha256(a.encode()).hexdigest()))
proof=read('implementation-1/special-lifetime-proof.json');git_sources=[]
for x in proof['source_bindings']:
 b=blob(x['repository_path']);assert len(b)==x['bytes']and hashlib.sha256(b).hexdigest()==x['sha256'];git_sources.append(dict(repository_path=x['repository_path'],base=BASE,bytes=len(b),sha256=hashlib.sha256(b).hexdigest()))
font=method(after,'font_size_plain');decode=method(after,'decoded_plain_condition_name');decl=method(after,'declaration');two=method(after,'supports_declaration_with_budget')
assert font.index('self.spend(value.len().saturating_mul(16).saturating_add(256))?')<font.index('css_wide(value)')<font.index('media_number_end(value)')<font.index("split(['e', 'E'])")<font.index('supports_length(value, true, false)')
assert "nonzero && (value.starts_with('-') || end == value.len())"in font
assert 'number_end as media_number_end'in before
for text in ['tokens(original, &mut self.work)','self.spend(tokens.len() + 1)?','names.len() != 1 || names[0].kind != Kind::Ident || names[0].raw.len() > 256','self.spend(raw.len().saturating_mul(8).saturating_add(1))?','css_identifier_checked(raw)','self.exhausted = true;','consumed != raw.len() || name.len() > 256','name.make_ascii_lowercase();']:assert text in decode
assert decode.index('self.spend(raw.len().saturating_mul(8).saturating_add(1))?')<decode.index('css_identifier_checked(raw)')
assert decl.index('return self.pending_declaration(original);')<decl.index('let keyword_property =')<decl.index('self.decoded_plain_condition_name(original)?')
assert decl.index('drop(decoded_name.take());')<decl.index('let spacing_property =')<decl.index('tokens(original, &mut self.work)')
assert "let decoded_special: Option<&'static str>"in decl
special=re.findall(r'"([a-z-]+)" => Some\("\1"\)',decl);assert special==proof['special_names']
assert 'owned_name = decoded_name.unwrap_or_else(|| raw_name.to_ascii_lowercase());'in decl
assert 'valid_declaration_value(name, media_trim(&clean), &mut self.work)'in decl
assert 'valid_declaration_value(name, value, &mut self.work)'in decl
assert two.index('return evaluator.pending_value(property, value);')<two.index('property == "font-size"')
assert 'supports_property(&property, clean)'in two
assert 'value.contains' in decl and 'if value.contains(\'\\\\\')'in decl
# No added constants, types, or global supports_property edits; exact seven-chunk inverse proves full scope.
report={
 'schema':1,'status':'clear','reviewer':'script','base':BASE,
 'bindings':[bind(R/n)for n in ['design-1.json','semantic-contract-1.json','design-precision-addendum-1.json','design-special-addendum-1.json','budget-contract-1.json','implementation-1/source-ready.json','implementation-1/edits.json','implementation-1/accounting.json','implementation-1/special-lifetime-proof.json','migrations-1/source-ready.json','migrations-1/edits.json']],
 'manifest_leaf_bindings_verified':len(checked),'published_git_inputs':git_sources,
 'scope_checks':{'production_paths':['src/css.rs'],'selected_old_functions':['supports_declaration_with_budget','SupportsEvaluator::declaration'],'new_methods':['SupportsEvaluator::font_size_plain','SupportsEvaluator::decoded_plain_condition_name'],'edit_chunks':7,'whole_file_forward_inverse_exact':True,'prefix_before_two_argument_api_exact':True,'suffix_from_supports_declaration_parts_exact':True,'unchanged_function_slices':unchanged,'no_CSSOM_or_Runtime_or_parser_file_change':True},
 'semantics':[
  'Query-only font dispatch follows existing no-var token/structural/value/priority guards and lowercase property handling. css_wide is reached only after the selected full16*v+256 debit.',
  'media_number_end is the unchanged selectors::number_end alias. The borrowed numeric-prefix mantissa scan stops before e/E; signed zero survives, negative nonzero and unitless nonzero are rejected before existing f32 conversion. Primitive supported units/finite magnitude remain delegated to unchanged supports_length and parse_length. No calc or escaped font-unit admission.',
  'Two-argument literal property checks remain byte-exact; new condition decoding applies only when the parsed name contains a backslash and no old keyword route matched.',
  'Original declaration tokens determine the property: one Ident before colon, raw<=256, full checked-decoder consumption and decoded<=256, ASCII fold only. Split/commented identifiers remain separate tokens. Generic decoded values are never normalized beyond their existing route.',
  'Q actual-var early returns, pending helpers and the legacy keyword-name decoder/dispatch precede the new path. Their validators, work source and order are retained.',
  'Image/box/spacing routes retain original colon/value spans, terminal important token checks, per-property escape allowances, raw valid_calculations before comments, and the same valid_declaration_value with caller work. Object-position retains its previous value-escape refusal and original math guard.',
  'Generic ordinary names reuse unchanged supports_property; no property_alias or global query/CSSOM roster widening. Structural/cap/decoder Limit paths return Err; typed decoder Limit marks exhausted and cannot be negated into true.'
 ],
 'accounting':{'font':'One16*v+256 spend precedes new helper allocations; invalid grammar has no rebate.','decoded_name':'Existing tokenizer2*d+1, scan t+1, then8*n+1 before String decode: total2*d+t+8*n+3. Failure propagates with caller work; no reset.','old_paths':'Seven exact chunks show no old spend/helper/limit changes. Old keyword/unescaped route dynamic allocation occurs at its original stage.','limits':'Query16384, twoarg name256/value4096, work ceiling262144, Runtime entry100000, depth16/terms64 and decoder1024 remain unchanged.','precision':'Selected Eris lexical underflow boundary; no universal precision or query/render parity claim.'},
 'lifetime_review':{
  'preparation':'decoded_plain_condition_name owns only borrowed-token Vec and decoded String; all return paths drop token Vec. Returned String is the sole new owner. No callback or validator inside the helper.',
  'special':'Option<&static str> contains no String borrow. Explicit drop(decoded_name.take()) precedes every special route tokenization and raw/calculation/comment/validator allocation. Static name replaces old lowercase name, adding no retained decoder owner during special validation.',
  'ordinary':'Canonical String moves through unwrap_or_else into the old owned_name slot; lazy closure avoids a second lowercase copy. Values remain borrowed.',
  'comparison':'Existing special validators may have more than two simultaneous token vectors. The proof is incremental: with equal canonical property/value, validator calls/storage lifetimes are the old sequence with no added decoder heap owner. It does not establish a new global numerical bound for historical special validators.',
  'scratch':'No new Runtime reservation or caps. The existing256*B+4096 includes original escaped-name bytes. Preparation/font arithmetic is separately bounded; the special proof rests on source lifetimes and unchanged helpers, not a blanket219*B estimate.',
  'no_added_value_copy':True
 },
 'migrations':{'paths':2,'rows':3,'retained_groups':2,'literal_bytes_and_group_ids_exact':True,'changes':['Move identical escaped display condition from negative to positive table.','Flip only font-size/12px no-var expectation.','Flip only escaped width/1px no-var expectation.'],'two_order_composition_exact':True,'inverse_restores_published_whole_files':True},
 'findings':[],
 'qualifications':['Source-only review. No compile/test outcome inferred or executed.','Mutable worktree paths inside producer proof were authenticated against published Git blobs, not assumed still unchanged after root imports.','Controls authorship remains qualified in controls-review-1; source producer was independently authored.','No full CSS compatibility, security/performance, memory-RSS or browser-comparison claim.'],
 'check_script':bind(Path(__file__)),'project_execution':False,'live_edits':False}
out=R/'implementation-review-1.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(bind(out)))
