
#[path = "worker/supports_plain_pixels.rs"]
mod supports_plain_pixels;
