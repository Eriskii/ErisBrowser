from pathlib import Path
import hashlib, json

q = Path('/tmp/eris-supports-plain-plan-1')
w = q / 'worktree'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def verify_refs(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys() and value['path'].startswith('/'):
            data = Path(value['path']).read_bytes()
            assert len(data) == value['bytes'] and digest(data) == value['sha256'], value['path']
        for child in value.values():
            verify_refs(child)
    elif isinstance(value, list):
        for child in value:
            verify_refs(child)

holds = {}
for name, expected in [
    ('implementation-1', '386cd984da747cb3505b7cdf34c9afa910efd6f79e8aefb75cdf1d566ada29ca'),
    ('migrations-1', 'a096b0fa8e21ef7a12f51b8f4a82c9ff68885f00061eaf38c63fbb5829a187bc'),
    ('budget-controls-1', 'df987b6609b10c8e555960284de057c978b27ff268dbe0e46bc77400b915ae7b'),
]:
    manifest = q / name / 'source-ready.json'
    assert digest(manifest.read_bytes()) == expected
    holds[name] = read_json(manifest)
    verify_refs(holds[name])

# Build the composition in memory and check every precondition before live writes.
composed = {}
for row in holds['implementation-1']['files']:
    assert (w / row['path']).read_bytes() == Path(row['before']['path']).read_bytes()
    composed[row['path']] = Path(row['raw']['path']).read_bytes()
for row in holds['migrations-1']['files']:
    assert (w / row['path']).read_bytes() == Path(row['before']['path']).read_bytes()
    composed.setdefault(row['path'], (w / row['path']).read_bytes())
for group in read_json(q / 'migrations-1/edits.json'):
    path = group['path']
    for chunk in group['edits']:
        old, new = chunk['before'].encode(), chunk['after'].encode()
        assert composed[path].count(old) == 1, chunk
        composed[path] = composed[path].replace(old, new, 1)
for row in holds['budget-controls-1']['files']:
    assert not (w / row['path']).exists()
    composed[row['path']] = Path(row['raw']['path']).read_bytes()
registration = read_json(q / 'budget-controls-1/registration.json')
verify_refs(registration)
fragment = Path(registration['append']['path']).read_bytes()
assert b'mod supports_plain_budget_tests;' not in composed['src/css.rs']
composed['src/css.rs'] += fragment

receipt = {'holds': {name: digest((q/name/'source-ready.json').read_bytes()) for name in holds},
           'composition': 'production, exact three-row historical migration chunks, separate budget registration',
           'root_review': 'Reviewed full source and ownership diff, selected query-only numeric guard, existing validator preservation, exact three-row migrations, and all five independently selected budget groups. Root source-review receipt retains qualifications.',
           'files': []}
for name, data in sorted(composed.items()):
    out = q / 'candidate-import-1/after' / name
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('xb') as f:
        f.write(data)
    target = w / name
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    receipt['files'].append({'path': name, 'bytes': len(data), 'sha256': digest(data)})
with (q / 'root/production-import-1.json').open('x') as f:
    json.dump(receipt, f, indent=2)
    f.write('\n')
print(json.dumps(receipt, indent=2))
