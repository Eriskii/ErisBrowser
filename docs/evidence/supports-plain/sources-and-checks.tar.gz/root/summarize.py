from pathlib import Path
from collections import Counter
import hashlib, json, re

q = Path(__file__).resolve().parents[1]
w = q / 'worktree'
parent = Path('/tmp/eris-supports-var-plan-1')

def load(path):
    return json.loads(path.read_bytes())

def bound(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def roster(path):
    return Counter(re.findall(r'^test (\S+) \.\.\. ok$', path.read_text(), re.M))

inventory_path = q / 'source-candidate-2.json'
inventory = load(inventory_path)
for row in inventory['files']:
    assert dict(bound(w / row['path']), path=row['path']) == row, row['path']
changed = load(q / 'root/candidate-snapshots-2.json')['changed_paths']
state = {'base': inventory['base'], 'changed': changed}
attempts = []
for receipt in sorted((q / 'validation').glob('*.json')):
    data = load(receipt)
    if 'command' not in data:
        continue
    log = q / 'validation' / data['log']
    assert bound(log)['sha256'] == data['sha256']
    if 'format' not in receipt.stem:
        assert data['source_before'] == data['source_after'], receipt
    rows = [tuple(map(int, row)) for row in re.findall(
        r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text(), re.M)]
    attempts.append({'label': receipt.stem, 'receipt': bound(receipt),
                     'command': data['command'], 'exit': data['exit'], 'log': bound(log),
                     'totals': {'passed': sum(row[0] for row in rows),
                                'failed': sum(row[1] for row in rows),
                                'ignored': sum(row[2] for row in rows), 'suites': len(rows)}})
by_label = {row['label']: row for row in attempts}
control = by_label['parent-controls-1']
assert control['exit'] == 101
assert control['totals'] == {'passed': 2, 'failed': 14, 'ignored': 0, 'suites': 3}
special = by_label['parent-controls-special-1']
assert special['exit'] == 101 and special['totals'] == {'passed': 1, 'failed': 3, 'ignored': 0, 'suites': 1}
new = Counter()
for path, prefix in [
    ('src/css/supports_plain_budget_tests.rs', 'css::supports_plain_budget_tests::'),
    ('tests/supports_plain.rs', ''),
    ('tests/supports_plain_special.rs', ''),
    ('tests/supports_plain_pixels.rs', ''),
    ('tests/worker/supports_plain_pixels.rs', 'supports_plain_pixels::'),
]:
    names = re.findall(r'#\[test\]\s*(?:#\[[^\n]*\]\s*)*fn (\w+)\(', (w/path).read_text())
    assert names, path
    new.update(prefix + name for name in names)
assert sum(new.values()) == 25
for label, parent_label, expected in [('candidate-full-msrv-2', 'candidate-full-msrv-1', 3622), ('candidate-full-host-vulkan-1', 'candidate-full-host-vulkan-1', 3987)]:
    result = by_label[label]
    assert result['exit'] == 0 and result['totals'] == {'passed': expected, 'failed': 0, 'ignored': 0, 'suites': 67}, result
    assert roster(q/'validation'/f'{label}.log') == roster(parent/'validation'/f'{parent_label}.log') + new
first = load(q/'validation/candidate-focused-msrv-1.json')
first_state = {'base': inventory['base'], 'changed': load(q/'root/candidate-snapshots-1.json')['changed_paths']}
assert first['exit'] == 0 and first['source_before'] == first['source_after'] == first_state
assert by_label['candidate-focused-msrv-1']['totals'] == {'passed':25,'failed':0,'ignored':0,'suites':66}
assert by_label['candidate-full-msrv-1']['totals'] == {'passed':3621,'failed':1,'ignored':0,'suites':67}
assert by_label['candidate-full-msrv-1']['exit'] == 101
failed_first = load(q/'validation/candidate-full-msrv-1.json')
assert failed_first['source_before'] == failed_first['source_after'] == first_state
failed_names = re.findall(r'^test (\S+) \.\.\. FAILED$', (q/'validation/candidate-full-msrv-1.log').read_text(), re.M)
assert failed_names == ['css::background::box_tests::box_escape_exception_does_not_broaden_other_supports_values_or_names']
prior_inventory = {row['path']:row for row in load(q/'source-candidate-1.json')['files']}
assert [row['path'] for row in inventory['files'] if row != prior_inventory[row['path']]] == ['src/css/background/box_tests.rs']
for label in ['candidate-full-msrv-2',
              'candidate-full-host-vulkan-1', 'candidate-clippy-msrv-1',
              'candidate-clippy-host-vulkan-1', 'candidate-format-check-1',
              'candidate-release-1', 'candidate-reftests-1']:
    result = load(q/'validation'/f'{label}.json')
    assert result['exit'] == 0 and result['source_before'] == state and result['source_after'] == state, label
report = load(q/'reftests-1/report.json')
assert (report['passed'], report['failed'], report['total']) == (102, 0, 102)
previous = {row['name']: row for row in load(parent/'reftests-1/report.json')['cases']}
assert set(previous) == {row['name'] for row in report['cases']}
images = []
for case in report['cases']:
    assert case['status'] == 'pass' and case['different_pixels'] == 0
    for kind in ['test_image', 'reference_image']:
        before, after = Path(previous[case['name']][kind]), Path(case[kind])
        assert before.read_bytes() == after.read_bytes()
        images.append({'name': case['name'], 'kind': kind, 'parent': bound(before), 'candidate': bound(after)})
summary = {'status': 'pass', 'checkpoint': 'supports-plain', 'base': inventory['base'],
           'source_inventory': bound(inventory_path), 'inputs': len(inventory['files']),
           'changed_sources': changed, 'attempts': attempts, 'new_test_names': sorted(new),
           'old_rosters_preserved': True, 'reftest_pairs': 102, 'parent_identical_pngs': len(images),
           'reftest_report': bound(q/'reftests-1/report.json'), 'images': images,
           'release_binary': bound(q/'target-msrv/release/eris-browser'),
           'inventory_note': 'The tested inventory includes tests/conformance/supports.md. Its later prose-only update is separately bound by the documentation manifest; executable and test-code inputs remain unchanged.',
           'qualification': 'Selected primitive font-size and CSS-wide feature-query admission, plus escaped plain condition names through existing validators. Extreme numeric cases are Eris source-admission choices, not universally mandatory CSS precision. Other omitted plain values and escaped-value limitations remain. No new GPU hardware, Chromium comparison, whole-browser compatibility or security certification. All local ignored tests explicitly included. Parent failures retained; New control expectations were frozen before first candidate execution. Its full run found one additional historical escaped background-clip condition expectation; the separately reviewed migration follows the original generic-name design and standards, and only that old test file changed for candidate2. The failed run remains retained.'}
with (q/'root/final-validation.json').open('x') as out:
    json.dump(summary, out, indent=2)
    out.write('\n')
print(json.dumps({key: summary[key] for key in ['status', 'inputs', 'reftest_pairs', 'parent_identical_pngs']}))
print(bound(q/'root/final-validation.json'))
