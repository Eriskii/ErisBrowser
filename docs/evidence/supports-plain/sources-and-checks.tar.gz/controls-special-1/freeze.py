"""Freeze selected literals using only stdlib and published Git blobs."""
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/tmp/eris-supports-plain-plan-1')
HOLD = ROOT / 'controls-special-1'
BASE = '64cd81afb7ab38e61872253f3d3665c23eb9435a'


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    path = HOLD / name
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


selection = ROOT / 'design-special-addendum-1.json'
proposal = ROOT / 'controls-special-proposal-1.json'
assert binding(selection)['sha256'] == 'e85be32996497e08006911b00549d7d14143500e2d2f3fcec4776c902cb1a5a6'
assert binding(proposal)['sha256'] == '2af16e110666065d0d9373f5ae9dcda46a3f19644c604c8cfece22b294d30848'
rows = json.loads(proposal.read_text())
assert len(rows['conditions']) == 24
assert len(rows['literal_two_argument_refusals']) == 3
sources = []
for row in rows['conditions']:
    source = 'CSS.supports(' + json.dumps(row['condition'], ensure_ascii=False) + ');'
    sources.append({'id': row['id'], 'form': 'condition', 'source': source, 'expected': row['expected']})
for row in rows['literal_two_argument_refusals']:
    source = 'CSS.supports(' + json.dumps(row['property']) + ', ' + json.dumps(row['value']) + ');'
    sources.append({'id': row['id'], 'form': 'pair', 'source': source, 'expected': row['expected']})
assert len({r['id'] for r in sources}) == 27
for row in sources:
    target = HOLD / 'literals' / (row['id'] + '.js')
    target.parent.mkdir(parents=True, exist_ok=True)
    assert not target.exists()
    target.write_text(row['source'])
save('cases.json', {
    'conditions': rows['conditions'],
    'literal_two_argument_refusals': rows['literal_two_argument_refusals'],
    'runtime_sources': sources,
})
inputs = []
for name in ['src/css.rs', 'src/page.rs', 'src/script.rs', 'tests/supports_var.rs']:
    data = subprocess.run(['git', '-C', str(ROOT / 'worktree'), 'show', BASE + ':' + name], check=True, capture_output=True).stdout
    path = HOLD / 'source-inputs' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)
    inputs.append({'repository_path': name, 'base': BASE, **binding(path)})
old = [binding(p) for p in sorted((ROOT / 'controls-1').rglob('*')) if p.is_file()]
save('original-controls-before.json', old)
save('literal-ready.json', {
    'status': 'selected literal subset frozen before Rust adapter conversion',
    'base': BASE,
    'selection': binding(selection),
    'proposal': binding(proposal),
    'original_controls': binding(ROOT / 'controls-1/source-ready.json'),
    'cases': binding(HOLD / 'cases.json'),
    'source_inputs': inputs,
    'literals': [binding(p) for p in sorted((HOLD / 'literals').glob('*.js'))],
    'prospective_counts': {'groups': 4, 'direct_queries': 27, 'runtime_executions_if_complete': 54},
    'basis': 'Exact root-selected proposal literals and expectations; no candidate implementation read or project execution.',
    'qualification': 'Existing special value grammar only; escaped object-position value remains false. URL checks are syntax-only. Budget controls are separate. Numeric precision qualification belongs to controls-1; this subset adds no numeric policy.',
    'freezer': binding(Path(__file__)),
    'project_execution': False,
    'producer_inspected': False,
    'live_edits': False,
})
print(json.dumps(binding(HOLD / 'literal-ready.json')))
