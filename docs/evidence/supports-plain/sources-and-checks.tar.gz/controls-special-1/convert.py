"""Convert the frozen JSON/JavaScript literals to an inert Rust test payload."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/tmp/eris-supports-plain-plan-1')
HOLD = ROOT / 'controls-special-1'
BASE = '64cd81afb7ab38e61872253f3d3665c23eb9435a'
REL = 'tests/supports_plain_special.rs'


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    path = HOLD / name
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


literal_seal = HOLD / 'literal-ready.json'
assert binding(literal_seal)['sha256'] == '54f305025f21b72854453369e4d68b4074fdb6550bbad24469f08287fe8202b4'
seal = json.loads(literal_seal.read_text())
for item in [seal['cases'], *seal['literals'], *seal['source_inputs']]:
    assert binding(Path(item['path'])) == {k: item[k] for k in ['path', 'bytes', 'sha256']}
cases = json.loads((HOLD / 'cases.json').read_text())
proposal = json.loads((ROOT / 'controls-special-proposal-1.json').read_text())
for key in ['conditions', 'literal_two_argument_refusals']:
    assert cases[key] == proposal[key]
runtime = {row['id']: row for row in cases['runtime_sources']}
for row in cases['conditions'] + cases['literal_two_argument_refusals']:
    js = runtime[row['id']]['source']
    args = json.loads('[' + js[len('CSS.supports('):-2] + ']')
    assert args == ([row['condition']] if 'condition' in row else [row['property'], row['value']])
    assert runtime[row['id']]['expected'] is row['expected']
    assert js == (HOLD / 'literals' / (row['id'] + '.js')).read_text()

raw_literals = []


def rust(value):
    assert '"###' not in value
    raw_literals.append(value)
    return 'r###"' + value + '"###'


source = '''//! Selected existing value validators reached through decoded condition property names.
//! These controls preserve raw token boundaries and literal two-argument name refusal.
use eris::{css, page::Page, script::Value};
use url::Url;

fn runtime(id: &str, source: &str, expected: bool) {
    // Every row and mode gets a fresh Page and the ordinary public execution allowance.
    for strict in [false, true] {
        let mut page = Page::from_html(
            Url::parse("https://supports-plain-special.invalid/").unwrap(),
            "<div id=target></div>",
            false,
        );
        let result = if strict {
            page.runtime.execute_strict(source, &mut page.document)
        } else {
            page.runtime.execute(source, &mut page.document)
        };
        assert_eq!(
            result.unwrap(),
            Value::Bool(expected),
            "id={id}, strict={strict}"
        );
        assert!(page.diagnostics.is_empty(), "id={id}: {:?}", page.diagnostics);
    }
}

fn conditions(rows: &[(&str, &str, &str, bool)]) {
    for &(id, condition, source, expected) in rows {
        assert_eq!(
            css::supports_matches(condition),
            expected,
            "id={id}, condition={condition:?}"
        );
        runtime(id, source, expected);
    }
}

'''
groups = []
for family in ['background-image', 'border-spacing', 'object-position']:
    name = 'supports_plain_special_' + family.replace('-', '_')
    groups.append(name)
    source += '#[test]\nfn ' + name + '() {\n    conditions(&[\n'
    selected = [r for r in cases['conditions'] if r['ordinary_property'] == family]
    assert len(selected) == 8
    for row in selected:
        fields = [rust(row['id']), rust(row['condition']), rust(runtime[row['id']]['source']), str(row['expected']).lower()]
        source += '        (\n' + ''.join('            ' + f + ',\n' for f in fields) + '        ),\n'
    source += '    ]);\n}\n\n'
name = 'supports_plain_special_literal_property_names'
groups.append(name)
source += '#[test]\nfn ' + name + '() {\n    for (id, property, value, source) in [\n'
for row in cases['literal_two_argument_refusals']:
    assert row['expected'] is False
    fields = [rust(row['id']), rust(row['property']), rust(row['value']), rust(runtime[row['id']]['source'])]
    source += '        (\n' + ''.join('            ' + f + ',\n' for f in fields) + '        ),\n'
source += '''    ] {
        assert!(
            !css::supports_declaration(property, value),
            "id={id}, property={property:?}, value={value:?}"
        );
        runtime(id, source, false);
    }
}
'''

absence = subprocess.run(['git', '-C', str(ROOT / 'worktree'), 'cat-file', '-e', BASE + ':' + REL], capture_output=True)
assert absence.returncode != 0
before = HOLD / 'before' / REL
raw = HOLD / 'raw' / REL
forward = HOLD / 'diffs' / (REL + '.patch')
inverse = HOLD / 'inverse' / (REL + '.patch')
for path in [before, raw, forward, inverse]:
    assert not path.exists()
    path.parent.mkdir(parents=True, exist_ok=True)
before.write_bytes(b'')
raw.write_text(source)
lines = source.splitlines(keepends=True)
forward.write_text(''.join(difflib.unified_diff([], lines, fromfile='/dev/null', tofile='b/' + REL)))
inverse.write_text(''.join(difflib.unified_diff(lines, [], fromfile='a/' + REL, tofile='/dev/null')))
assert ''.join(line[1:] for line in forward.read_text().splitlines(keepends=True) if line.startswith('+') and not line.startswith('+++')) == source
assert ''.join(line[1:] for line in inverse.read_text().splitlines(keepends=True) if line.startswith('-') and not line.startswith('---')) == source
assert re.findall(r'r###"(.*?)"###', source, re.S) == raw_literals
assert re.findall(r'#\[test\]\nfn (\w+)\(', source) == groups
original = json.loads((HOLD / 'original-controls-before.json').read_text())
current = [binding(p) for p in sorted((ROOT / 'controls-1').rglob('*')) if p.is_file()]
assert current == original
css = (HOLD / 'source-inputs/src/css.rs').read_text()
page = (HOLD / 'source-inputs/src/page.rs').read_text()
script = (HOLD / 'source-inputs/src/script.rs').read_text()
for pattern in ['pub fn supports_matches(', 'pub fn supports_declaration(']:
    assert pattern in css
assert 'pub fn from_html(' in page
for pattern in ['pub fn execute(', 'pub fn execute_strict(']:
    assert pattern in script
save('conversion-checks.json', {
    'selection_literals_exact': True,
    'runtime_json_arguments_round_trip': 27,
    'raw_rust_literal_fields_exact': len(raw_literals),
    'published_api_signatures_present': True,
    'published_target_absent': True,
    'groups': groups,
    'forward_reconstructs_raw': True,
    'inverse_removes_only_new_payload': True,
    'original_controls_tree_unchanged': current,
    'prospective_counts': {'groups': 4, 'direct_queries': 27, 'runtime_executions_if_complete': 54},
    'qualification': 'Loops stop at the first failure; counts describe complete adapters, not executed parent outcomes. No project code was imported, compiled or run.',
})
save('source-ready.json', {
    'status': 'source-ready independent selected special-validator controls',
    'base': BASE,
    'selection': binding(ROOT / 'design-special-addendum-1.json'),
    'proposal': binding(ROOT / 'controls-special-proposal-1.json'),
    'literal_seal': binding(literal_seal),
    'cases': binding(HOLD / 'cases.json'),
    'converter': binding(Path(__file__)),
    'checks': binding(HOLD / 'conversion-checks.json'),
    'files': [{'path': REL, 'change': 'new integration test; no registration required', 'before': binding(before), 'raw': binding(raw), 'forward': binding(forward), 'inverse': binding(inverse)}],
    'groups': groups,
    'prospective_counts': {'groups': 4, 'direct_queries': 27, 'runtime_executions_if_complete': 54},
    'preservation': 'controls-1 complete file census unchanged; no old source, test, fixture, registration, fee or policy changed.',
    'qualification': 'No new value grammar selected. Object-position escaped-value refusal remains a legacy limitation. URL parsing has no fetch claim. No outcome, budget, complete conformance or rendering claim.',
    'project_execution': False,
    'producer_inspected': False,
    'live_edits': False,
})
print(json.dumps(binding(HOLD / 'source-ready.json')))
