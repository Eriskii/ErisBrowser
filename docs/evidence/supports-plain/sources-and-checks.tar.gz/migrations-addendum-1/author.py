"""Held one-row historical migration, derived from selected grammar and published source."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

R = Path('/tmp/eris-supports-plain-plan-1')
H = R / 'migrations-addendum-1'
BASE = '64cd81afb7ab38e61872253f3d3665c23eb9435a'
REL = 'src/css/background/box_tests.rs'


def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    path = H / name
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists()
    path.write_text(json.dumps(value, indent=2) + '\n')


def published(path):
    return subprocess.run(['git', '-C', str(R / 'worktree'), 'show', BASE + ':' + path], check=True, capture_output=True).stdout


old = published(REL).decode()
assert (R / 'worktree' / REL).read_text() == old
old_chunk = r'''    for (name, value) in [
        (r"background-\63 lip", "content-box"),
        ("color", r"r\65 d"),
        ("background", r"r\65 d content-box"),
        ("background-repeat", r"r\65 peat"),
        ("background-origin", r"\0 content-box"),
    ] {
        assert!(!css::supports_declaration(name, value), "{name}:{value}");
        assert!(
            !css::supports_matches(&format!("({name}:{value})")),
            "{name}:{value}"
        );
    }
'''
new_chunk = r'''    for (name, value, condition_supported) in [
        (r"background-\63 lip", "content-box", true),
        ("color", r"r\65 d", false),
        ("background", r"r\65 d content-box", false),
        ("background-repeat", r"r\65 peat", false),
        ("background-origin", r"\0 content-box", false),
    ] {
        assert!(!css::supports_declaration(name, value), "{name}:{value}");
        assert_eq!(
            css::supports_matches(&format!("({name}:{value})")),
            condition_supported,
            "{name}:{value}"
        );
    }
'''
assert old.count(old_chunk) == 1
new = old.replace(old_chunk, new_chunk, 1)
assert new.count(new_chunk) == 1 and new.replace(new_chunk, old_chunk, 1) == old
assert old.split(old_chunk) == new.split(new_chunk)
strings = lambda text: re.findall(r'r"(?:[^"\\]|\\.)*"|"(?:[^"\\]|\\.)*"', text)
assert strings(old) == strings(new)
assert re.findall(r'#\[test\]\s*fn (\w+)', old) == re.findall(r'#\[test\]\s*fn (\w+)', new)
for kind, data in [('before', old), ('raw', new)]:
    path = H / kind / REL
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists()
    path.write_text(data)
for kind, a, b in [('forward', old, new), ('inverse', new, old)]:
    path = H / 'diffs' / kind / (REL + '.patch')
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True), fromfile='a/' + REL, tofile='b/' + REL)))
save('edits.json', [{'path': REL, 'before': old_chunk, 'after': new_chunk}])
inputs = []
for name in ['src/css.rs', 'src/css/background.rs', 'src/css/background/layers.rs']:
    path = H / 'source-inputs' / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(published(name))
    inputs.append({'repository_path': name, 'base': BASE, **bind(path)})
save('expectation-derivation.json', {
    'status': 'one historical expectation migration justified by pre-existing selected scope',
    'selection': bind(R / 'design-1.json'),
    'selected_scope': 'Generic condition declaration names are decoded and ASCII-folded before existing validators; two-argument names stay literal. This includes background-clip, not only the three supplemental validator families.',
    'literal': {'property': r'background-\63 lip', 'value': 'content-box'},
    'expectations': {'two_argument': False, 'condition': True},
    'derivation': [
        'The property is one CSS identifier. Hex escape63 followed by its terminating space decodes to c, yielding background-clip; the value is unchanged.',
        'Published css_identifier_checked handles complete hexadecimal escapes; parse_declaration_group decodes a complete property token and ASCII-folds before declaration expansion/application.',
        'Published valid_background_property -> background::valid -> layers::valid_list routes background-clip to list(..., parse_box). box_from_token recognizes the complete content-box identifier as BackgroundBox::Content.',
        'Published layers::apply uses that same parse_box list and pool.set_clips to apply background-clip. Existing longhands_accept_complete_decoded_identifiers checks the canonical property and content-box through both support APIs and computed style; no new value grammar is inferred.',
        'The separate two-argument supports API rejects a backslash in the literal property before value dispatch. That refusal remains asserted for all five rows.',
        'The four other rows escape values or contain an invalid replacement-codepoint box, not newly selected condition property spellings. Their condition expectations remain false. The later object-position refusal/background-position success and every other assertion remain exact.'
    ],
    'primary_sources': [
        {'url': 'https://www.w3.org/TR/2024/CRD-css-conditional-3-20240815/#the-css-interface', 'claim': 'The property/value overload performs literal property-name matching without CSS escape processing; the condition overload parses CSS condition syntax.'},
        {'url': 'https://www.w3.org/TR/2024/CRD-css-backgrounds-3-20240311/#the-background-clip', 'claim': 'content-box is a background-clip visual-box value and selects clipping at the content box.'},
        {'url': 'https://www.w3.org/TR/2026/CRD-css-syntax-3-20261001/#consume-a-declaration', 'claim': 'Selected design binds declaration-name identifier parsing; this migration applies that pre-existing rule to the already supported background-clip property.'}
    ],
    'source_bindings': inputs,
    'failure_qualification': 'Root reported the historical assertion failure after full MSRV execution. This prompted the census addendum, but the expected condition result is derived from the frozen generic-name design and published validator/application code. No outcome is generated or asserted by this hold.',
    'historical_census_correction': 'The earlier three-row census was incomplete. This additive fourth row preserves migrations-1 and its receipt; it does not change implementation or scope.',
    'project_execution': False,
})
save('checks.json', {
    'published_before_exact': True,
    'current_target_still_published_exact_at_authoring': True,
    'one_unique_chunk': True,
    'inverse_restores_whole_file': True,
    'all_literal_bytes_and_order_exact': True,
    'test_names_and_count_exact': True,
    'two_argument_false_all_five': True,
    'condition_results': [True, False, False, False, False],
    'changed_expectation_rows': 1,
    'outside_loop_and_later_assertions_exact': True,
    'project_execution': False,
    'live_edits': False,
})
save('source-ready.json', {
    'schema': 1,
    'status': 'source-ready additive historical expectation migration; root imports and executes',
    'base': BASE,
    'selection': bind(R / 'design-1.json'),
    'prior_migration_seal': bind(R / 'migrations-1/source-ready.json'),
    'derivation': bind(H / 'expectation-derivation.json'),
    'checks': bind(H / 'checks.json'),
    'edits': bind(H / 'edits.json'),
    'author': bind(Path(__file__)),
    'files': [{'path': REL, 'before': bind(H / 'before' / REL), 'raw': bind(H / 'raw' / REL), 'forward': bind(H / 'diffs/forward' / (REL + '.patch')), 'inverse': bind(H / 'diffs/inverse' / (REL + '.patch'))}],
    'selected_rows': 1,
    'retained_group': 'box_escape_exception_does_not_broaden_other_supports_values_or_names',
    'preservation': 'Exact original property/value literals, group identity, all five twoarg refusals, four unrelated condition refusals, later assertions and all other file bytes. Existing production and migrations-1 remain frozen.',
    'project_execution': False,
    'live_edits': False,
})
print(json.dumps(bind(H / 'source-ready.json')))
