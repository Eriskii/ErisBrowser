from pathlib import Path
import json,hashlib,re,subprocess
R=Path('/tmp/eris-supports-plain-plan-1');BASE='64cd81afb7ab38e61872253f3d3665c23eb9435a'
def binding(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(n):return json.loads((R/n).read_text())
verified=set()
def walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and Path(v['path']).is_absolute():
   assert binding(v['path'])=={k:v[k]for k in ('path','bytes','sha256')};verified.add(v['path'])
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
seals=['controls-1/source-ready.json','controls-1/literal-ready.json','controls-1/precision-addendum-binding.json','budget-controls-1/source-ready.json','budget-controls-1/registration.json','budget-controls-1/checks.json']
for n in seals:walk(read(n))
sem=read('semantic-contract-1.json');cases=read('controls-1/cases.json');budget=read('budget-contract-1.json')
for key in ('assessment_rows','numeric_discriminators','cross_path_fixtures'):assert sem[key]==cases[key]
s=(R/'controls-1/raw/tests/supports_plain.rs').read_text()
def functions(s):return {m.group(1):m.group(2)for m in re.finditer(r'#\[test\]\nfn (\w+)\(\) \{(.*?)(?=\n#\[test\]|\Z)',s,re.S)}
f=functions(s);assert len(f)==14
raw=r'r###"((?:(?!"###).)*)"###'
pair=re.compile(r'\('+raw+r', '+raw+r', '+raw+r', (true|false)\)',re.S)
cond=re.compile(r'\('+raw+r', '+raw+r', (true|false)\)',re.S)
pairs=[];conditions=[]
for n,b in f.items():
 if n.startswith('supports_plain_runtime')or n=='supports_plain_cssom_query_parity_fixture':continue
 pairs.extend((a,b,c,d=='true')for a,b,c,d in pair.findall(b))
 conditions.extend((a,b,c=='true')for a,b,c in cond.findall(b))
assert pairs==[(x['id'],x['property'],x['value'],x['expected'])for x in sem['assessment_rows']if 'property'in x]+[('numeric-'+str(i),x['property'],x['value'],x['expected'])for i,x in enumerate(sem['numeric_discriminators'],1)]
assert conditions==[(x['id'],x['condition'],x.get('at_supports_without_parentheses_expected',x['expected']))for x in sem['assessment_rows']if 'condition'in x]+[('numeric-'+str(i),'('+x['property']+':'+x['value']+')',x['expected'])for i,x in enumerate(sem['numeric_discriminators'],1)]
assert len(pairs)+len(conditions)==75
for name,rows in [('supports_plain_runtime_selected_rows',sem['assessment_rows']),('supports_plain_runtime_numeric_both_forms',None)]:
 got=[]
 for ident,source,expect in cond.findall(f[name]):
  source=source.strip();assert source.startswith('CSS.supports(')and source.endswith(');');got.append((ident,json.loads('['+source[13:-2]+']'),expect=='true'))
 if rows is not None:want=[(x['id'],[x['property'],x['value']]if 'property'in x else[x['condition']],x['expected'])for x in rows]
 else:
  want=[]
  for i,x in enumerate(sem['numeric_discriminators'],1):want.extend([('numeric-'+str(i)+'-pair',[x['property'],x['value']],x['expected']),('numeric-'+str(i)+'-condition',['('+x['property']+':'+x['value']+')'],x['expected'])])
 assert got==want
 assert 'runtime(id, "<div id=target></div>", source, expected);'in f[name]
for x,n in zip(sem['cross_path_fixtures'][:3],['supports_plain_stylesheet_font_fixture','supports_plain_stylesheet_percentage_fixture','supports_plain_stylesheet_escaped_name_fixture']):
 assert re.findall(raw,f[n],re.S)==[x['html']]
 for key,v in x['expected_computed'].items():
  field=key.split('.')[1];needle=f'assert_eq!(styles[target].{field}, {v});'if field=='font_size'else f'assert_eq!(styles[target].{field[:-3]}, Length::Px({v}));';assert needle in f[n]
x=sem['cross_path_fixtures'][3];assert re.findall(raw,f['supports_plain_cssom_query_parity_fixture'],re.S)==[x['id'],x['setup'],x['script']]
assert '        true,\n'in f['supports_plain_cssom_query_parity_fixture']
helper=s[:s.index('#[test]')];assert helper.index('for strict in [false, true]')<helper.index('let mut page = Page::from_html')
for x in ['page.runtime.execute_strict(source, &mut page.document)','page.runtime.execute(source, &mut page.document)','Value::Bool(expected)','page.diagnostics.is_empty()']:assert x in helper
b=(R/'budget-controls-1/raw/src/css/supports_plain_budget_tests.rs').read_text();assert '\x00'not in b;bf=functions(b);assert len(bf)==5
lit=r'(r?"(?:\\.|[^"\\])*")'
def dec(x):return x[2:-1]if x.startswith('r"')else json.loads(x)
cut=re.compile(r'\('+lit+r', '+lit+r', (\d+)\)');ccut=re.compile(r'\('+lit+r', (true|false), (\d+)\)');row=re.compile(r'\('+lit+r', (\d+), (true|false)\)')
g={x['name']:x for x in budget['groups']}
for n,k in [('exact_font_declarations','positive_cuts'),('grammar_vs_exhaustion','invalid_declaration_exact_cuts')]:assert [[dec(a),dec(v),int(fee)]for a,v,fee in cut.findall(bf['supports_plain_budget_'+n])]==g[n][k]
assert [[dec(q),imp=='true',int(fee)]for q,imp,fee in ccut.findall(bf['supports_plain_budget_exact_condition_names'])]==g['exact_condition_names']['positive_cuts']
assert [{'query':dec(q),'work':int(w),'expected':e=='true'}for q,w,e in row.findall(bf['supports_plain_budget_grammar_vs_exhaustion'])]==[{k:x[k]for k in ('query','work','expected')}for x in g['grammar_vs_exhaustion']['conditions']]
for n in ('exact_font_declarations','exact_condition_names'):
 for x in ['let mut exact = fee;','assert_eq!(exact, 0);','let mut short = fee - 1;','assert_eq!(short, 0);','assert!(!supports_','assert!(supports_']:assert x in bf['supports_plain_budget_'+n]
for x in ['let mut work = 909;','assert_eq!(work, 454);','assert_eq!(work, 0);']:assert x in bf['supports_plain_budget_shared_work']
for x in ['"0".repeat(4096)','let mut exact = 106847;','let mut short = 106846;','"0".repeat(4097)','for initial in [0, 1, 200000]','assert_eq!(work, initial);']:assert x in bf['supports_plain_budget_raw_value_boundary']
for x in ['assert!(!supports_declaration_with_budget','assert_eq!(work, 0);','assert!(work > 0);','supports_matches_with_budget(query, false, &mut work)']:assert x in bf['supports_plain_budget_grammar_vs_exhaustion']
fees=[]
for p,v,fee in g['exact_font_declarations']['positive_cuts']+g['grammar_vs_exhaustion']['invalid_declaration_exact_cuts']:
 old=10*len(p)+10*len(v)+5;new=16*len(v)+256;assert old+new==fee;fees.append(dict(property=p,value=v,old=old,new=new,total=fee))
assert 10*9+10*4096+5+16*4096+256==106847
for q,implied,fee in g['exact_condition_names']['positive_cuts']:
 d=q if implied else q[1:-1];name,value=d.split(':');T=3 if implied else 5;old=5*len(q)+(T if implied else 4*T)+8*len(d)+(4 if implied else 6);prep=2*len(d)+3+8*len(name)+3 if '\\'in name else 0;font=16*len(value)+256 if name in ['font-size',r'font\2d size']else 0;assert old+prep+font==fee;fees.append(dict(query=q,implied=implied,old=old,decoded=prep,font=font,total=fee))
reg=read('budget-controls-1/registration.json');fragment=Path(reg['append']['path']).read_text();assert fragment=='\n#[cfg(test)]\nmod supports_plain_budget_tests;\n'
parent=subprocess.run(['git','-C',str(R/'worktree'),'show',BASE+':src/css.rs'],check=True,capture_output=True).stdout
assert hashlib.sha256(parent).hexdigest()==reg['published_before']['sha256'];assert b'mod supports_plain_budget_tests;'not in parent
for n in ('controls-1/source-ready.json','budget-controls-1/source-ready.json'):
 for x in read(n)['files']:
  assert Path(x['before']['path']).read_bytes()==b'';after=Path(x['raw']['path']).read_text()
  assert subprocess.run(['git','-C',str(R/'worktree'),'cat-file','-e',BASE+':'+x['path']],capture_output=True).returncode!=0
  for key,sign in [('forward','+'),('inverse','-')]:assert ''.join(y[1:]for y in Path(x[key]['path']).read_text().splitlines(keepends=True)if y.startswith(sign)and not y.startswith(sign*3))==after
report=dict(schema=1,status='clear',base=BASE,reviewer='script',independence={'controls_1':'Source re-audit by its original author, not an independent-authorship peer. Recomputed literals, adapters and hashes against root contracts.','budget_controls_1':'Independent source review of Layout-authored controls. No producer read or project execution.'},bindings=[binding(R/n)for n in ['design-1.json','semantic-contract-1.json','design-precision-addendum-1.json','budget-contract-1.json',*seals]],verified_manifest_bindings=len(verified),public_checks={'assessment49_exact':True,'numeric13_exact':True,'fixtures4_exact':True,'direct_tuple_count':75,'runtime_sources_exact':75,'runtime_calls_if_complete_including_cssom':152,'literal_style_assertions':6,'fresh_page_per_strict_sloppy_source':True,'groups':14,'implied_rule':'Strict direct condition false; selected Runtime implied declaration true.','precision':'Underflow rows select Eris query admission before f32, not universal conforming-browser precision or query/render parity.'},budget_checks={'groups':5,'calls_if_complete':30,'per_group':[6,10,2,5,7],'all_tuple_and_work_cuts_exact':True,'raw_boundary':'4096 zeros at106847 success/0; one-short false/0. 4097 zeros false with0/1/200000 unchanged. Private helper, not Runtime100000 success.','shared':'909 -> true/454 -> false/0, same work variable.','grammar_vs_exhaustion':'Fully paid invalid grammar false; ample not true; resource not/true-or false/0.','fee_recomputation':fees,'registration':'One cfg(test) child append; published API and base hash verified.','escaped_strings_exact_and_no_NUL':True},preservation={'new_paths_absent_at_base':True,'forward_inverse_exact':True,'old_sources_tests_modified_by_holds':False},findings=[],qualifications=['Original controls author re-audit is explicitly distinguished from independent budget peer.','No producer inspection: implementation scratch/lifetime proof remains a separate mandatory review.','Counts are prospective complete traversal; first assertions can stop later rows.','Reviewer first unsealed extraction regex crossed raw-string delimiters; corrected delimiter-bounded extraction before receipt. No source/oracle/hold bytes changed.','Budget author retained its pre-payload quoting failure separately; frozen module has no malformed escapes or NUL.'],check_script=binding(Path(__file__)),project_execution=False,producer_inspected=False,live_edits=False)
out=R/'controls-review-1.json';assert not out.exists();out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(binding(out)))
