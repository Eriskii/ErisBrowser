from pathlib import Path
import difflib, hashlib, json, re, subprocess
H=Path(__file__).resolve().parent
R=H.parent
BASE='64cd81afb7ab38e61872253f3d3665c23eb9435a'
CONTRACT=R/'budget-contract-1.json'
def bind(p):
 p=Path(p);data=p.read_bytes();return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def write(p,text):
 p=H/p;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(text);return bind(p)
def js(p,obj):return write(p,json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
c=json.loads(CONTRACT.read_text())
assert bind(CONTRACT)['sha256']=='79b08cb84dce4ecb5ee20a833262cf060e8e61d0788143b5d4af75aef347ca49'
assert c['base']==BASE and len(c['groups'])==5
path='src/css/supports_plain_budget_tests.rs'
assert not subprocess.check_output(['git','-C',str(R/'worktree'),'ls-tree',BASE,'--',path])
css=subprocess.check_output(['git','-C',str(R/'worktree'),'show',BASE+':src/css.rs'])
assert b'mod supports_plain_budget_tests;' not in css
raw=r'''//! Independent literal resource cuts selected before producer inspection or execution.
use super::{supports_declaration_with_budget, supports_matches_with_budget};

#[test]
fn supports_plain_budget_exact_font_declarations() {
    for (property, value, fee) in [
        ("font-size", "12px", 455),
        ("font-size", "0", 377),
        ("font-size", "initial", 533),
    ] {
        let mut exact = fee;
        assert!(supports_declaration_with_budget(property, value, &mut exact));
        assert_eq!(exact, 0);
        let mut short = fee - 1;
        assert!(!supports_declaration_with_budget(property, value, &mut short));
        assert_eq!(short, 0);
    }
}

#[test]
fn supports_plain_budget_exact_condition_names() {
    for (query, implied, fee) in [
        ("(font-size:12px)", false, 538),
        ("font-size:12px", true, 509),
        (r"(w\69 dth:1px)", false, 286),
        (r"w\69 dth:1px", true, 257),
        (r"(font\2d size:12px)", false, 713),
    ] {
        let mut exact = fee;
        assert!(supports_matches_with_budget(query, implied, &mut exact));
        assert_eq!(exact, 0);
        let mut short = fee - 1;
        assert!(!supports_matches_with_budget(query, implied, &mut short));
        assert_eq!(short, 0);
    }
}

#[test]
fn supports_plain_budget_shared_work() {
    let mut work = 909;
    assert!(supports_declaration_with_budget("font-size", "12px", &mut work));
    assert_eq!(work, 454);
    assert!(!supports_declaration_with_budget("font-size", "12px", &mut work));
    assert_eq!(work, 0);
}

#[test]
fn supports_plain_budget_raw_value_boundary() {
    // This is a private CSS allowance, not a Runtime 100000-work success claim.
    let at_cap = "0".repeat(4096);
    assert_eq!(at_cap.len(), 4096);
    let mut exact = 106847;
    assert!(supports_declaration_with_budget("font-size", &at_cap, &mut exact));
    assert_eq!(exact, 0);
    let mut short = 106846;
    assert!(!supports_declaration_with_budget("font-size", &at_cap, &mut short));
    assert_eq!(short, 0);
    let over_cap = "0".repeat(4097);
    assert_eq!(over_cap.len(), 4097);
    for initial in [0, 1, 200000] {
        let mut work = initial;
        assert!(!supports_declaration_with_budget("font-size", &over_cap, &mut work));
        assert_eq!(work, initial);
    }
}

#[test]
fn supports_plain_budget_grammar_vs_exhaustion() {
    // These are Eris source-admission boundaries, not universal precision claims.
    for (property, value, fee) in [
        ("font-size", "-1e-999px", 585),
        ("font-size", "1e-999", 507),
    ] {
        let mut work = fee;
        assert!(!supports_declaration_with_budget(property, value, &mut work));
        assert_eq!(work, 0);
    }
    for (query, initial, expected) in [
        ("not (font-size:-1px)", 100000, true),
        ("not (font-size:-1px)", 538, false),
        ("(display:block) or (font-size:12px)", 538, false),
        (r"not (w\69 dth:-1px)", 100000, true),
        (r"not (w\69 dth:-1px)", 286, false),
    ] {
        let mut work = initial;
        assert_eq!(supports_matches_with_budget(query, false, &mut work), expected, "{query}");
        if expected {
            assert!(work > 0);
        } else {
            assert_eq!(work, 0);
        }
    }
}
'''

# Independently decode selected Rust tuple literals and bind them to root JSON.
def rust_string(s):
 return s[2:-1] if s.startswith('r"') else json.loads(s)
def triples(body,kind):
 if kind=='declaration':pat=r'\(("[^"\\]*"),\s*("[^"\\]*"),\s*(\d+)\)'
 elif kind=='condition':pat=r'\(((?:r)?"[^"\n]*"),\s*(true|false),\s*(\d+)\)'
 else:pat=r'\(((?:r)?"[^"\n]*"),\s*(\d+),\s*(true|false)\)'
 out=[]
 for a,b,d in re.findall(pat,body):
  out.append([rust_string(a),json.loads(b) if kind=='condition' else int(b) if kind=='condition_results' else rust_string(b),json.loads(d) if kind=='condition_results' else int(d)])
 return out
bodies=re.split(r'\n#\[test\]\n',raw)[1:]
names=re.findall(r'^fn (supports_plain_budget_\w+)\(',raw,re.M)
assert len(names)==len(set(names))==5
assert triples(bodies[0],'declaration')==c['groups'][0]['positive_cuts']
assert triples(bodies[1],'condition')==c['groups'][1]['positive_cuts']
assert 'let mut work = 909;' in bodies[2] and 'assert_eq!(work, 454);' in bodies[2]
assert c['groups'][2]['calls']==[['font-size','12px',True,454],['font-size','12px',False,0]]
assert all(x in bodies[3] for x in ['"0".repeat(4096)','"0".repeat(4097)','let mut exact = 106847;','let mut short = 106846;','[0, 1, 200000]','assert_eq!(work, initial);'])
assert triples(bodies[4],'declaration')==c['groups'][4]['invalid_declaration_exact_cuts']
observations=triples(bodies[4],'condition_results')
assert observations==[[r['query'],r['work'],r['expected']] for r in c['groups'][4]['conditions']]
assert chr(0) not in raw
assert raw.count('fn supports_plain_budget_')==5
before=write('before/'+path,''); after=write('raw/'+path,raw)
fwd=''.join(difflib.unified_diff([],raw.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+path))
inv=''.join(difflib.unified_diff(raw.splitlines(keepends=True),[],fromfile='b/'+path,tofile='/dev/null'))
f=write('diffs/forward/'+path+'.patch',fwd); i=write('diffs/inverse/'+path+'.patch',inv)
append='\n#[cfg(test)]\nmod supports_plain_budget_tests;\n'
reg=write('registration-append.rs',append)
registration=js('registration.json',{'path':'src/css.rs','operation':'append','append':reg,'published_before':{'bytes':len(css),'sha256':hashlib.sha256(css).hexdigest()},'instructions':'Root appends the fragment once after existing test module declarations; no existing module or source body is replaced.'})
checks=js('checks.json',{'status':'clear','contract':bind(CONTRACT),'accounting_peer':bind('/tmp/eris-supports-plain-accounting-review-1.json'),'groups':names,'api_invocations':{'exact_font_declarations':6,'exact_condition_names':10,'shared_work':2,'raw_value_boundary':5,'grammar_vs_exhaustion':7,'total':30},'literal_tuple_equality':True,'escaped_names':'Rust raw strings preserve exactly one CSS backslash; root contract decoded strings compare exactly.','raw_hostile_NUL':'No NUL or hostile-NUL literal is present in this selected contract or module.','boundary_recipes':'4096 and4097 literal ASCII zeros; bytes equal character count. Thresholds are frozen literals, never inferred from producer or execution.','precision':bind(R/'design-precision-addendum-1.json'),'old_tests':'No visibility, pointer, Q-variable or other existing test is modified.','source_api':'Only the two published pub(crate) supports budget APIs are used; no new private producer interface.','authoring_qualification':'First unexecuted author script had nested Python quoting errors, including interpreted CSS octal escapes and a NUL. Stdlib AST inspection refused it before any payload write. It is retained as author-attempt1.py; this corrected author uses raw Rust text, and every decoded tuple is checked against the unchanged frozen contract before writing. No project or oracle result changed.','original_author_attempt':bind(H/'author-attempt1.py'),'project_execution':False,'project_imports':False,'producer_reads':False,'live_edits':False})
ready={'schema':1,'status':'source-ready','author':'layout','published_api_base':BASE,'contract':bind(CONTRACT),'files':[{'path':path,'operation':'add','before_absent_at_base':True,'before':before,'raw':after,'forward':f,'inverse':i}],'registration':registration,'checks':checks,'author_script':bind(__file__),'group_count':5,'api_invocations':30,'project_execution':False,'project_imports':False,'producer_reads':False,'live_edits':False}
js('source-ready.json',ready)
print(json.dumps(bind(H/'source-ready.json')))
