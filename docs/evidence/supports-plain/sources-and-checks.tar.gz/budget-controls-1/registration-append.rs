
#[cfg(test)]
mod supports_plain_budget_tests;
