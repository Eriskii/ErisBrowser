"""Freeze root-selected literal controls using stdlib only; no project imports."""
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/tmp/eris-supports-plain-plan-1')
HOLD = ROOT / 'controls-1'
BASE = '64cd81afb7ab38e61872253f3d3665c23eb9435a'


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def dump(path, data):
    write(path, (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode())


assert not (HOLD / 'literal-ready.json').exists()
design = ROOT / 'design-1.json'
contract_path = ROOT / 'semantic-contract-1.json'
assert binding(design)['sha256'] == '48707c207553a11373f2bf7794644d8e64d50310c9e4fea440ac9671c4080bca'
assert binding(contract_path)['sha256'] == 'd6213df51859f31606be542471b579431fd1f383180e48c365cc855ad39e4e4e'
contract = json.loads(contract_path.read_text())
assert contract['base'] == BASE
assert len(contract['assessment_rows']) == 49
assert len(contract['cross_path_fixtures']) == 4
assert len(contract['numeric_discriminators']) == 13

cases = {key: contract[key] for key in ('assessment_rows', 'cross_path_fixtures', 'numeric_discriminators')}
cases['numeric_conditions'] = [
    {'id': f'numeric-{i + 1}', 'condition': '(' + row['property'] + ':' + row['value'] + ')', 'expected': row['expected']}
    for i, row in enumerate(contract['numeric_discriminators'])
]
literal_paths = []
runtime = []
for row in contract['assessment_rows']:
    args = [row['property'], row['value']] if 'property' in row else [row['condition']]
    source = 'CSS.supports(' + ', '.join(json.dumps(arg, ensure_ascii=True) for arg in args) + ');\n'
    path = HOLD / 'literals' / 'runtime-assessment' / (row['id'] + '.js')
    write(path, source.encode())
    literal_paths.append(path)
    runtime.append({'id': row['id'], 'literal': str(path.relative_to(HOLD)), 'expected': row['expected']})
cases['runtime_assessment'] = runtime
runtime = []
for i, row in enumerate(contract['numeric_discriminators']):
    for form, args in [('pair', [row['property'], row['value']]), ('condition', ['(' + row['property'] + ':' + row['value'] + ')'])]:
        name = f'numeric-{i + 1}-{form}'
        source = 'CSS.supports(' + ', '.join(json.dumps(arg) for arg in args) + ');\n'
        path = HOLD / 'literals' / 'runtime-numeric' / (name + '.js')
        write(path, source.encode())
        literal_paths.append(path)
        runtime.append({'id': name, 'literal': str(path.relative_to(HOLD)), 'expected': row['expected']})
cases['runtime_numeric'] = runtime
for fixture in contract['cross_path_fixtures']:
    path = HOLD / 'literals' / (fixture['id'] + '.html')
    write(path, fixture.get('html', fixture.get('setup')).encode())
    literal_paths.append(path)
    if 'script' in fixture:
        path = HOLD / 'literals' / (fixture['id'] + '.js')
        write(path, fixture['script'].encode())
        literal_paths.append(path)
dump(HOLD / 'cases.json', cases)

api_inputs = []
for relative in [
    'tests/supports_var.rs', 'tests/pointer_events_cssom.rs', 'tests/network.rs',
    'src/page.rs', 'src/css.rs', 'src/script.rs', 'src/dom.rs',
]:
    data = subprocess.check_output(['git', 'show', BASE + ':' + relative], cwd=ROOT / 'worktree')
    assert (ROOT / 'worktree' / relative).read_bytes() == data
    path = HOLD / 'source-inputs' / relative
    write(path, data)
    api_inputs.append({'repository_path': relative, 'published_git_exact': True, **binding(path)})

dump(HOLD / 'literal-ready.json', {
    'status': 'frozen independent literals; executable adapter not yet authored',
    'base': BASE,
    'selected_contract': binding(contract_path),
    'selected_design': binding(design),
    'cases': binding(HOLD / 'cases.json'),
    'generator': binding(Path(__file__)),
    'literals': [binding(path) for path in literal_paths],
    'published_API_sources': api_inputs,
    'counts': {'assessment_rows': 49, 'numeric_rows': 13, 'derived_numeric_conditions': 13, 'cross_path_fixtures': 4, 'runtime_assessment_sources': 49, 'runtime_numeric_sources': 26, 'exact_cssom_source': 1},
    'conversion_contract': 'Preserve all selected rows and fixture bytes. Strict condition API accepts only parenthesized/boolean conditions; the two implied rows are false there and selected true through Runtime. Runtime executes each source in a fresh Page under both strict and sloppy modes. Derived numeric condition strings use the same selected expected boolean. No budget values or candidate results are used.',
    'independence': {'producer_read': False, 'project_imports': False, 'project_execution': False, 'live_edits': False},
})
print(json.dumps(binding(HOLD / 'literal-ready.json')))
