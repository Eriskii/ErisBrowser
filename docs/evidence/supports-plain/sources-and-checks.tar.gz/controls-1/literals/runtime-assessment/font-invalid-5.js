CSS.supports("font-size", "12px 13px");
