CSS.supports("not (font-size:12px)");
