CSS.supports("font-size", "1e1px");
