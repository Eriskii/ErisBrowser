CSS.supports("not (font-size:-1px)");
