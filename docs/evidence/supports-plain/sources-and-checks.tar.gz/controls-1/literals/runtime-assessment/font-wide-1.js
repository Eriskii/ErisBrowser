CSS.supports("font-size", "initial");
