CSS.supports("font-size", "0.5rem");
