CSS.supports("(font-size:-0.000e+9)");
