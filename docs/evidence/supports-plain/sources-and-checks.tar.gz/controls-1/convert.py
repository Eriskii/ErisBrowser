"""Convert frozen literal data into held Rust tests; no project imports or runs."""
import difflib
import hashlib
import json
import re
import subprocess
from pathlib import Path

ROOT = Path('/tmp/eris-supports-plain-plan-1')
HOLD = ROOT / 'controls-1'
BASE = '64cd81afb7ab38e61872253f3d3665c23eb9435a'
RELATIVE = 'tests/supports_plain.rs'


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(path, data):
    assert not path.exists(), path
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(data)


def dump(path, data):
    write(path, (json.dumps(data, indent=2, ensure_ascii=False) + '\n').encode())


literal_seal = HOLD / 'literal-ready.json'
assert binding(literal_seal)['sha256'] == '46df09b7e6ea77fafdec228fea628f619352158b6f59220f0d76e38fe9dd823b'
seal = json.loads(literal_seal.read_text())
for record in [seal['cases'], *seal['literals'], *seal['published_API_sources']]:
    assert binding(Path(record['path'])) == {key: record[key] for key in ('path', 'bytes', 'sha256')}
cases = json.loads((HOLD / 'cases.json').read_text())
contract = json.loads((ROOT / 'semantic-contract-1.json').read_text())
for key in ('assessment_rows', 'cross_path_fixtures', 'numeric_discriminators'):
    assert cases[key] == contract[key]

fields = []


def raw(value):
    assert '"###' not in value
    fields.append(value)
    return 'r###"' + value + '"###'


def boolean(value):
    assert type(value) is bool
    return 'true' if value else 'false'


text = '''//! Primitive font-size and escaped condition-name controls frozen before producer inspection.
//! Deferred font keywords, math, aliases and escaped numeric units are outside this slice.
use eris::{
    css::{self, Length},
    page::Page,
    script::Value,
};
use url::Url;

fn pairs(rows: &[(&str, &str, &str, bool)]) {
    for &(id, property, value, expected) in rows {
        assert_eq!(
            css::supports_declaration(property, value),
            expected,
            "id={id}, property={property:?}, value={value:?}"
        );
    }
}

fn conditions(rows: &[(&str, &str, bool)]) {
    for &(id, query, expected) in rows {
        assert_eq!(css::supports_matches(query), expected, "id={id}, query={query:?}");
    }
}

fn runtime(id: &str, setup: &str, source: &str, expected: bool) {
    // A fresh Page for every source and mode avoids assumptions about combined query budgets.
    for strict in [false, true] {
        let mut page = Page::from_html(
            Url::parse("https://supports-plain.invalid/").unwrap(),
            setup,
            false,
        );
        let result = if strict {
            page.runtime.execute_strict(source, &mut page.document)
        } else {
            page.runtime.execute(source, &mut page.document)
        };
        assert_eq!(result.unwrap(), Value::Bool(expected), "id={id}, strict={strict}");
        assert!(page.diagnostics.is_empty(), "id={id}: {:?}", page.diagnostics);
    }
}

'''
groups = []
assessment_ids = []
direct_calls = 0


def group(name, body, count, category):
    global text
    text += '#[test]\nfn ' + name + '() {\n' + body + '}\n\n'
    groups.append({'name': name, 'category': category, 'source_operations': count})


def pair_group(name, rows):
    global direct_calls
    body = '    pairs(&[\n'
    for row in rows:
        body += '        (' + ', '.join([raw(row['id']), raw(row['property']), raw(row['value']), boolean(row['expected'])]) + '),\n'
        assessment_ids.append(row['id'])
    body += '    ]);\n'
    group(name, body, len(rows), 'direct two-argument queries')
    direct_calls += len(rows)


def condition_group(name, rows, implied=False):
    global direct_calls
    body = '    conditions(&[\n'
    for row in rows:
        expected = row['at_supports_without_parentheses_expected'] if implied else row['expected']
        body += '        (' + ', '.join([raw(row['id']), raw(row['condition']), boolean(expected)]) + '),\n'
        assessment_ids.append(row['id'])
    body += '    ]);\n'
    group(name, body, len(rows), 'strict condition queries')
    direct_calls += len(rows)


rows = cases['assessment_rows']
pair_group('supports_plain_primitive_font_values', [row for row in rows if row['id'].startswith('font-numeric-')])
pair_group('supports_plain_font_css_wide_keywords', [row for row in rows if row['id'].startswith('font-wide-')])
pair_group('supports_plain_invalid_primitive_values', [row for row in rows if row['id'].startswith('font-invalid-')])
pair_group('supports_plain_literal_property_names', [row for row in rows if 'property' in row and not row['id'].startswith(('font-numeric-', 'font-wide-', 'font-invalid-'))])
condition_group('supports_plain_font_conditions', [row for row in rows if row['id'].startswith(('font-condition', 'font-negated-'))])
condition_group('supports_plain_escaped_condition_names_and_boolean_structure', [row for row in rows if 'condition' in row and not row['id'].startswith(('font-condition', 'font-negated-', 'implied-'))])
condition_group('supports_plain_implied_forms_require_runtime_parentheses_rule', [row for row in rows if row['id'].startswith('implied-')], implied=True)
assert assessment_ids == [row['id'] for row in rows]

body = '    pairs(&[\n'
for i, row in enumerate(cases['numeric_discriminators']):
    body += '        (' + ', '.join([raw(f'numeric-{i + 1}'), raw(row['property']), raw(row['value']), boolean(row['expected'])]) + '),\n'
body += '    ]);\n    conditions(&[\n'
for row in cases['numeric_conditions']:
    body += '        (' + ', '.join([raw(row['id']), raw(row['condition']), boolean(row['expected'])]) + '),\n'
body += '    ]);\n'
group('supports_plain_numeric_sign_and_zero', body, 26, 'direct numeric queries in both forms')
direct_calls += 26

runtime_checks = []
for key, group_name in [('runtime_assessment', 'supports_plain_runtime_selected_rows'), ('runtime_numeric', 'supports_plain_runtime_numeric_both_forms')]:
    body = '    for (id, source, expected) in [\n'
    for row in cases[key]:
        source = (HOLD / row['literal']).read_text()
        # Each call contains only JSON-encoded arguments. Verify original CSS bytes independently.
        assert source.startswith('CSS.supports(') and source.endswith(');\n')
        args = json.loads('[' + source[len('CSS.supports('):-3] + ']')
        if key == 'runtime_assessment':
            selected = next(item for item in rows if item['id'] == row['id'])
            expected_args = [selected['property'], selected['value']] if 'property' in selected else [selected['condition']]
        else:
            number, form = row['id'].removeprefix('numeric-').split('-', 1)
            selected = cases['numeric_discriminators'][int(number) - 1]
            expected_args = [selected['property'], selected['value']] if form == 'pair' else ['(' + selected['property'] + ':' + selected['value'] + ')']
        assert args == expected_args and row['expected'] == selected['expected']
        runtime_checks.append({'id': row['id'], 'arguments_exact': True, 'expected_exact': True})
        body += '        (' + ', '.join([raw(row['id']), raw(source), boolean(row['expected'])]) + '),\n'
    body += '    ] {\n        runtime(id, "<div id=target></div>", source, expected);\n    }\n'
    group(group_name, body, len(cases[key]) * 2, 'strict/sloppy Runtime calls, one fresh Page per call')

fixture_groups = [
    ('query-style-font', 'supports_plain_stylesheet_font_fixture'),
    ('query-style-percent', 'supports_plain_stylesheet_percentage_fixture'),
    ('escaped-declaration-and-query', 'supports_plain_stylesheet_escaped_name_fixture'),
]
for fixture_id, group_name in fixture_groups:
    fixture = next(row for row in cases['cross_path_fixtures'] if row['id'] == fixture_id)
    html = (HOLD / 'literals' / (fixture_id + '.html')).read_text()
    assert html == fixture['html']
    body = '    let page = Page::from_html(\n        Url::parse("https://supports-plain.invalid/").unwrap(),\n        ' + raw(html) + ',\n        false,\n    );\n'
    body += '''    assert!(page.diagnostics.is_empty(), "{:?}", page.diagnostics);
    let target = page.document.query_selector("#target").unwrap();
    let styles = css::compute_styles_from_sources(
        &page.document,
        &page.stylesheets(),
        800.0,
        600.0,
    );
'''
    for field, expected in fixture['expected_computed'].items():
        if field == 'target.font_size':
            body += f'    assert_eq!(styles[target].font_size, {expected:.1f});\n'
        elif field == 'target.width_px':
            body += f'    assert_eq!(styles[target].width, Length::Px({expected:.1f}));\n'
        elif field == 'target.height_px':
            body += f'    assert_eq!(styles[target].height, Length::Px({expected:.1f}));\n'
        else:
            raise AssertionError(field)
    group(group_name, body, len(fixture['expected_computed']), 'fixed HTML and literal computed-style assertions')

fixture = next(row for row in cases['cross_path_fixtures'] if row['id'] == 'CSSOM-query-parity')
setup = (HOLD / 'literals' / 'CSSOM-query-parity.html').read_text()
source = (HOLD / 'literals' / 'CSSOM-query-parity.js').read_text()
assert setup == fixture['setup'] and source == fixture['script']
body = '    runtime(\n        ' + raw(fixture['id']) + ',\n        ' + raw(setup) + ',\n        ' + raw(source) + ',\n        ' + boolean(fixture['expected']) + ',\n    );\n'
group('supports_plain_cssom_query_parity_fixture', body, 2, 'strict/sloppy exact CSSOM fixture')

assert len(groups) == 14 and direct_calls == 75
assert re.findall(r'r###"(.*?)"###', text, flags=re.S) == fields
assert re.findall(r'#\[test\]\nfn (\w+)\(', text) == [row['name'] for row in groups]
assert 'with_budget' not in text and 'parse_checked' not in text
absent = subprocess.run(['git', 'cat-file', '-e', BASE + ':' + RELATIVE], cwd=ROOT / 'worktree', stdout=subprocess.PIPE, stderr=subprocess.PIPE)
assert absent.returncode != 0
write(HOLD / 'before' / RELATIVE, b'')
write(HOLD / 'raw' / RELATIVE, text.encode())
forward = ''.join(difflib.unified_diff([], text.splitlines(True), fromfile='/dev/null', tofile='b/' + RELATIVE))
inverse = ''.join(difflib.unified_diff(text.splitlines(True), [], fromfile='b/' + RELATIVE, tofile='/dev/null'))
write(HOLD / 'diffs' / (RELATIVE + '.patch'), forward.encode())
write(HOLD / 'inverse' / (RELATIVE + '.patch'), inverse.encode())
dump(HOLD / 'conversion-checks.json', {
    'status': 'stdlib source conversion checks clear; no project execution',
    'all_49_assessment_rows_and_order_exact': True,
    'all_13_numeric_rows_exact': True,
    'numeric_condition_forms_derived_without_new_expectations': True,
    'all_four_cross_path_fixtures_exact': True,
    'raw_string_field_count': len(fields),
    'raw_string_extraction_order_and_bytes_exact': True,
    'runtime_json_argument_checks': runtime_checks,
    'implied_row_rule': 'The two selected implied texts are false in css::supports_matches and use their selected true result only in Runtime.',
    'groups': groups,
    'prospective_counts': {'test_groups': 14, 'direct_query_assertions': 75, 'runtime_executions_if_all_rows_complete': 152, 'computed_style_fixture_count': 3, 'literal_computed_style_assertions': 6},
    'registration': 'New standalone integration test auto-discovered from tests/supports_plain.rs; no shared test registration or existing source change.',
    'base_path_absent': True,
    'no_private_or_budget_api': True,
    'no_live_edits': True,
    'no_project_imports_or_execution': True,
    'producer_inspected': False,
})
dump(HOLD / 'source-ready.json', {
    'status': 'source-ready independent public controls; root owns execution',
    'base': BASE,
    'literal_seal': binding(literal_seal),
    'design': binding(ROOT / 'design-1.json'),
    'semantic_contract': binding(ROOT / 'semantic-contract-1.json'),
    'cases': binding(HOLD / 'cases.json'),
    'conversion': binding(Path(__file__)),
    'checks': binding(HOLD / 'conversion-checks.json'),
    'files': [{'path': RELATIVE, 'change': 'new file', 'before': binding(HOLD / 'before' / RELATIVE), 'raw': binding(HOLD / 'raw' / RELATIVE), 'forward': binding(HOLD / 'diffs' / (RELATIVE + '.patch')), 'inverse': binding(HOLD / 'inverse' / (RELATIVE + '.patch'))}],
    'groups': [row['name'] for row in groups],
    'prospective_counts': {'groups': 14, 'direct_queries': 75, 'runtime_executions_if_complete': 152, 'fixed_style_assertions': 6},
    'preservation': 'Only a new integration test payload. No old test, implementation, registration, budget, baseline or policy is modified.',
    'qualification': 'Static conversion and source API compatibility checks only. No compile/test result, browser comparison, performance or complete conformance claim.',
    'project_execution': False,
    'producer_inspected': False,
    'live_edits': False,
})
print(json.dumps(binding(HOLD / 'source-ready.json')))
