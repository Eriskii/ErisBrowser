import hashlib,json,subprocess,time
from pathlib import Path
A=Path(__file__).resolve().parent
P=Path('/tmp/eris-node-connected-preparation-1/replay')
assert json.loads((P/'root-source-review.json').read_text())['findings']==[]
assert json.loads((P/'layout-source-review.json').read_text())['findings']==[]
assert subprocess.check_output(['git','status','--porcelain'],cwd=A/'worktree',text=True)==''
for label,args in [('connected-verify',['python3',str(P/'replay.py'),'--verify']),('connected-baseline',['python3',str(P/'replay.py'),'/tmp/eris-node-equality-1/eris-js','19cb3f218ab907b9702c48e127cb9e311113b9347795a352932b05f79f8ec519',str(A/'connected-before.json')])]:
 log=A/(label+'.log');start=time.monotonic()
 with log.open('xb') as f:r=subprocess.run(args,stdout=f,stderr=subprocess.STDOUT)
 rec=dict(command=args,exit=r.returncode,elapsed_seconds=time.monotonic()-start,log=log.name,sha256=hashlib.sha256(log.read_bytes()).hexdigest())
 with (A/(label+'-command.json')).open('x') as f:json.dump(rec,f,indent=2);f.write('\n')
 print(json.dumps(rec),flush=True)
 if label=='connected-verify':assert r.returncode==0
