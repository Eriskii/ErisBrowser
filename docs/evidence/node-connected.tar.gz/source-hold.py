"""Retain a complete changed-source manifest and exact review copies."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

A = Path(__file__).resolve().parent
R = A / 'worktree'
phase = sys.argv[1]
assert phase in {'initial', 'final'}
base = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert base == '9839259eeaf10dfab8205d88e0f3b3c359d358b8'
changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=R, text=True).splitlines()
untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=R, text=True).splitlines()
paths = sorted(set(changed + untracked))
assert paths and all(p.startswith(('src/', 'tests/')) for p in paths)
held = A / ('held-source-' + phase)
held.mkdir()
rows = []
for path in paths:
    raw = (R / path).read_bytes()
    copy = held / path
    copy.parent.mkdir(parents=True, exist_ok=True)
    with copy.open('xb') as stream:
        stream.write(raw)
    rows.append(dict(path=path, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
out = A / ('candidate-source-' + phase + '.json')
with out.open('x') as stream:
    json.dump(dict(base=base, files=rows), stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(path=str(out), paths=len(rows), sha256=hashlib.sha256(out.read_bytes()).hexdigest())))
