from pathlib import Path
import hashlib,json,shutil
w=Path('/tmp/eris-node-connected-1/worktree'); r=w.parent/'runtime'
paths=['src/script.rs','src/script/node_connected.rs','src/script/node_connected/tests.rs','src/script/node_root.rs','src/script/node_data.rs','src/script/dom_prototypes.rs','src/script/dom_prototypes/node_constants.rs','src/script/dom_prototypes/node_constants/tests.rs','src/script/node_normalize/tests.rs','src/script/node_predicates/tests.rs','src/script/node_root/tests.rs','src/script/node_equality/tests.rs','src/script/node_data/tests.rs','tests/fixtures/node-connected.js']
rows=[]
for p in paths:
    f=w/p
    if f.exists():
        t=r/'source-before'/p;t.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,t)
        rows.append(dict(path=p,bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
(r/'before.json').write_text(json.dumps(rows,indent=2)+'\n')
def change(p,a,b):
    f=w/p;s=f.read_text();assert s.count(a)==1,(p,a,s.count(a));f.write_text(s.replace(a,b))
change('src/script.rs','mod node_data;','mod node_connected;\nmod node_data;')
change('src/script/dom_prototypes.rs','    + node_data::METADATA_OBJECTS','    + node_connected::METADATA_OBJECTS\n    + node_data::METADATA_OBJECTS')
change('src/script/dom_prototypes.rs','"Node" => 8,','"Node" => 9,')
change('src/script/dom_prototypes.rs','                self.install_node_data_members(prototype)?;','                self.install_node_connected(prototype)?;\n                self.install_node_data_members(prototype)?;')
change('src/script/node_root.rs','let mut current = node_id(&receiver, doc)?;','let current = node_id(&receiver, doc)?;')
change('src/script/node_root.rs','        let mut edges = 0;','        self.node_ordinary_root_from_id(current, doc)\n    }\n\n    pub(super) fn node_ordinary_root_from_id(\n        &mut self,\n        mut current: NodeId,\n        doc: &Document,\n    ) -> Result<Value> {\n        let mut edges = 0;')
(w/'src/script/node_connected.rs').write_text('''//! Ordinary connection state from the shared paid root walk. Template hosts
//! are not parent links. Getter traversal owns no storage and invokes no hooks.
use super::*;

#[cfg(test)]
mod tests;

pub(super) const METADATA_OBJECTS: usize = 1;

impl Runtime {
    pub(super) fn install_node_connected(&mut self, prototype: usize) -> Result<()> {
        self.work(4)?;
        let get = self.node_data_function("getIsConnected", "get isConnected", 0)?;
        self.dom_proto_named(
            prototype,
            "isConnected",
            Property {
                value: PropertyValue::Accessor { get, set: Value::Undefined },
                enumerable: true,
                configurable: true,
            },
        )
    }

    pub(super) fn node_is_connected(&mut self, receiver: Value, doc: &Document) -> Result<Value> {
        self.work(16)?;
        let id = node_predicates::node_id(&receiver, doc)?;
        let root = self.node_ordinary_root_from_id(id, doc)?;
        self.work(2)?;
        Ok(Value::Bool(matches!(root, Value::Document)))
    }
}
''')
change('src/script/node_data.rs','            _ => return Err(ScriptError::type_error("unknown Node accessor")),','''            _ => {
                // Keep the four successful accessor routes unchanged. Only an
                // unmatched suffix pays this additional getter comparison.
                self.work(1)?;
                if method.len() == 14 {
                    self.work(14)?;
                    if method == "getIsConnected" {
                        return self.node_is_connected(receiver, doc);
                    }
                }
                return Err(ScriptError::type_error("unknown Node accessor"));
            }''')
change('src/script/dom_prototypes/node_constants.rs','PROTOTYPE_OLD: usize = 9','PROTOTYPE_OLD: usize = 10')
change('src/script/dom_prototypes/node_constants.rs','// N=27 has height one','// N=28 has height one')
change('src/script/dom_prototypes/node_constants.rs','            ExpectedKey::Text("isEqualNode"),','            ExpectedKey::Text("isConnected"),\n            ExpectedKey::Text("isEqualNode"),') if False else None
p=w/'src/script/dom_prototypes/node_constants.rs';s=p.read_text();anchor='            ExpectedKey::Text("hasChildNodes"),\n            ExpectedKey::Text("isEqualNode"),';assert s.count(anchor)==1;s=s.replace(anchor,anchor.replace('            ExpectedKey::Text("isEqualNode"),','            ExpectedKey::Text("isConnected"),\n            ExpectedKey::Text("isEqualNode"),'));anchor='            ExpectedKey::Tag(tag),\n            ExpectedKey::Text("nodeValue"),';assert s.count(anchor)==1;s=s.replace(anchor,'            ExpectedKey::Tag(tag),\n            ExpectedKey::Text("isConnected"),\n            ExpectedKey::Text("nodeValue"),');p.write_text(s)
change('src/script/dom_prototypes/node_constants/tests.rs','if owner == prototype { 28 } else { 21 }','if owner == prototype { 29 } else { 21 }')
change('src/script/dom_prototypes/node_constants/tests.rs','assert_eq!(runtime.objects[prototype].values.len(), 27);','assert_eq!(runtime.objects[prototype].values.len(), 28);')
change('src/script/node_data/tests.rs',"if(keys[0]!=='nodeValue'||keys[1]!=='textContent'||keys[2]!=='getRootNode'||\n           keys[3]!=='hasChildNodes'||keys[4]!=='normalize'||keys[5]!=='isEqualNode'||\n           keys[6]!=='isSameNode'||keys[7]!=='contains'||keys[8]!=='ELEMENT_NODE'||", "if(keys[0]!=='isConnected'||keys[1]!=='nodeValue'||keys[2]!=='textContent'||keys[3]!=='getRootNode'||\n           keys[4]!=='hasChildNodes'||keys[5]!=='normalize'||keys[6]!=='isEqualNode'||\n           keys[7]!=='isSameNode'||keys[8]!=='contains'||keys[9]!=='ELEMENT_NODE'||")
f=Path('/tmp/eris-node-connected-preparation-1/independent/cases.js');assert hashlib.sha256(f.read_bytes()).hexdigest()=='25e76612b7ff0e8f6ce0a68b5ae72399a77d27be2b745da0aad2b44ae885bc94';shutil.copyfile(f,w/'tests/fixtures/node-connected.js')
# Save/remove/restore the new accessor independently of each old method list.
for p in ['src/script/dom_prototypes/node_constants/tests.rs','src/script/node_normalize/tests.rs','src/script/node_predicates/tests.rs','src/script/node_root/tests.rs']:
    f=w/p;s=f.read_text();begin=s.index('fn prior_');end=s.index('\n#[test]',begin);chunk=s[begin:end]
    marker='try{{';pos=chunk.index(marker);indent='          '
    pre="""const connection=Object.getOwnPropertyDescriptor(Node.prototype,'isConnected');
          if(!connection||typeof connection.get!=='function'||connection.set!==undefined||
             !connection.enumerable||!connection.configurable)throw new Error('connection descriptor');
          """
    chunk=chunk[:pos]+pre+chunk[pos:]
    chunk=chunk.replace('try{{',"try{{\n            if(!delete Node.prototype.isConnected)throw new Error('connection delete');",1)
    chunk=chunk.replace('}}finally{{',"}}finally{{\n            Object.defineProperty(Node.prototype,'isConnected',connection);",1)
    pos=chunk.index('return true;')
    verify="""const restoredConnection=Object.getOwnPropertyDescriptor(Node.prototype,'isConnected');
          if(restoredConnection.get!==connection.get||restoredConnection.set!==undefined||
             restoredConnection.enumerable!==connection.enumerable||restoredConnection.configurable!==connection.configurable)
            throw new Error('connection restoration');
          """
    chunk=chunk[:pos]+verify+chunk[pos:]
    s=s[:begin]+chunk+s[end:];s=s.replace('new equality fixture checks pristine order','new connection fixture checks pristine order').replace('independent equality fixture checks','independent connection fixture checks');f.write_text(s)
change('src/script/node_equality/tests.rs','    represented_complete_key_order,\n','')
f=w/'src/script/node_equality/tests.rs';s=f.read_text();pos=s.index('\n#[test]');wrapper='''
#[test]
fn prior_equality_inventory_after_removing_configurable_connection_accessor() {
    // Restoration changes creation order, so each mode uses a disposable realm.
    for strict in [false, true] {
        let (mut runtime, mut doc) = fresh();
        let source = format!(r#"{CASES}
        (function(){{
          const saved=Object.getOwnPropertyDescriptor(Node.prototype,'isConnected');
          if(!saved||typeof saved.get!=='function'||saved.set!==undefined||
             !saved.enumerable||!saved.configurable)throw new Error('connection descriptor');
          try{{
            if(!delete Node.prototype.isConnected)throw new Error('connection delete');
            if(nodeEqualityCases.represented_complete_key_order()!==true)throw new Error('prior equality inventory');
          }}finally{{Object.defineProperty(Node.prototype,'isConnected',saved);}}
          const d=Object.getOwnPropertyDescriptor(Node.prototype,'isConnected');
          if(d.get!==saved.get||d.set!==undefined||d.enumerable!==saved.enumerable||
             d.configurable!==saved.configurable)throw new Error('connection restoration');
          return true;
        }})()"#);
        assert_eq!(evaluate(&mut runtime, &mut doc, &source, strict), Value::Bool(true));
    }
}
''';s=s[:pos]+wrapper+s[pos:];f.write_text(s)
