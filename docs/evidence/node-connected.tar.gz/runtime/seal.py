from pathlib import Path
import hashlib,json,re,shutil,subprocess
w=Path('/tmp/eris-node-connected-1/worktree'); r=w.parent/'runtime'; prep=Path('/tmp/eris-node-connected-preparation-1')
base='9839259eeaf10dfab8205d88e0f3b3c359d358b8'
paths=['src/script.rs','src/script/node_connected.rs','src/script/node_connected/tests.rs','src/script/node_root.rs','src/script/node_data.rs','src/script/dom_prototypes.rs','src/script/dom_prototypes/node_constants.rs','src/script/dom_prototypes/node_constants/tests.rs','src/script/node_normalize/tests.rs','src/script/node_predicates/tests.rs','src/script/node_root/tests.rs','src/script/node_equality/tests.rs','src/script/node_data/tests.rs','tests/fixtures/node-connected.js']
def bind(p):
    b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def save(p,data):
    with p.open('x') as f:json.dump(data,f,indent=2);f.write('\n')
old=(r/'source-before/src/script/node_root.rs').read_bytes();new=(w/'src/script/node_root.rs').read_bytes()
start=b'        let mut edges = 0;'
oldwalk=old[old.index(start):];newwalk=new[new.index(start):]
# The retained loop excludes the two enclosing function/impl braces.
assert oldwalk==newwalk
heldwalk=(prep/'runtime/root-walk-before.txt').read_bytes()
assert heldwalk in oldwalk and len(heldwalk)==1771
options=lambda b:b[b.index(b'    fn node_root_options'):b.index(b'    pub(super) fn node_get_root_node')]
assert options(old)==options(new)
original_predicate=subprocess.check_output(['git','show',base+':src/script/node_predicates.rs'],cwd=w)
assert original_predicate==(w/'src/script/node_predicates.rs').read_bytes()
save(r/'extraction-proof.json',dict(status='Exact source extraction, no execution',base=base,before=bind(r/'source-before/src/script/node_root.rs'),after=bind(w/'src/script/node_root.rs'),retained_loop=bind(prep/'runtime/root-walk-before.txt'),unchanged_trailing_walk_bytes=len(oldwalk),unchanged_options_bytes=len(options(old)),unchanged_options_sha256=hashlib.sha256(options(old)).hexdigest(),unchanged_predicates=bind(w/'src/script/node_predicates.rs'),limits='No semantic result claimed before compilation; source bytes establish the extraction.'))
oldfixtures=[]
for name in ['node-constants.js','node-normalize.js','node-predicates.js','node-root.js','node-equality.js']:
    p='tests/fixtures/'+name;b=subprocess.check_output(['git','show',base+':'+p],cwd=w);assert b==(w/p).read_bytes();target=r/'historical-fixtures'/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b);oldfixtures.append(bind(w/p))
newfixture=w/'tests/fixtures/node-connected.js';assert newfixture.read_bytes()==(prep/'independent/cases.js').read_bytes();assert bind(newfixture)['sha256']=='25e76612b7ff0e8f6ce0a68b5ae72399a77d27be2b745da0aad2b44ae885bc94'
s=(w/'src/script/node_connected/tests.rs').read_text();direct=re.findall(r'^#\[test\]\nfn ([A-Za-z_][A-Za-z0-9_]*)\(',s,re.M);independent=re.findall(r'^    ([A-Za-z_][A-Za-z0-9_]*),$',s[s.index('cases!('):s.index('\n);',s.index('cases!('))],re.M)
assert len(direct)==12 and len(independent)==16,(direct,independent)
save(r/'test-inventory.json',dict(direct_private=direct,independent=independent,new_runtime_groups=len(direct)+len(independent),independent_modes=32,mode_invocation='nodeConnectedCases.{name}({strict}) with literal Rust Boolean true/false per fresh realm; no inference from outcome',historical_sources_unchanged=oldfixtures))
save(r/'formatting.json',dict(status='Formatted and diff check clear',successful_command=['/tmp/eris-vulkan-rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin/rustfmt','--edition','2024','--config','skip_children=true']+[p for p in paths if p.endswith('.rs')],initial_launch_failures=[dict(command='rustfmt +1.88.0 ...',exit=1,output='rustup attempted default home channel synchronization; could not create /home/eriskii/.rustup/tmp temporary file: Read-only file system (os error 30)'),dict(command='/home/eriskii/.rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt ...',exit=127,output='error while loading shared libraries: libz.so.1: cannot open shared object file: No such file or directory')],compiler=False,engine=False))
rows=[]
for p in paths:
    target=r/'held'/p;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(w/p,target);row=bind(w/p);row['path']=p;rows.append(row)
refs=[prep/'runtime/source-ready.json',prep/'root/plan-acceptance.json',prep/'root/published-base.json',prep/'layout/connected-source-review.json',prep/'independent/cases.js',r/'before.json',r/'ledger.md',r/'extraction-proof.json',r/'test-inventory.json',r/'formatting.json']
save(r/'source-ready.json',dict(status='Held before candidate compilation or execution',base=base,files=rows,references=[bind(p) for p in refs],owned_paths=len(rows),new_runtime_groups=28,independent_modes=32,bootstrap_predictions=dict(work_delta=524,charged_bytes_delta=3275,steps=7292,allocated=1765502,objects=688,capacity=688,native=321,prototypes=25),measurements='Unmeasured candidate; bootstrap descriptive source untouched',old_fixtures=oldfixtures,checks=['Exact 1771-byte loop and unchanged options/predicate source','Rust1.88 rustfmt edition2024 skip_children=true; git diff --check','Frozen independent source exact; full Rust identifier inventory','No compiler or engine run by this agent']))
print(json.dumps({'source_ready':bind(r/'source-ready.json'),'ledger':bind(r/'ledger.md'),'extraction':bind(r/'extraction-proof.json'),'inventory':bind(r/'test-inventory.json')},indent=2))
