import hashlib
import json
import re
from pathlib import Path

B = Path(__file__).resolve().parent


def read(name):
    return json.loads((B / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked(label):
    row = read('validation/' + label + '.json')
    assert row['exit'] == 0 and sha(B / 'validation' / row['log']) == row['sha256']
    return row


source = read('candidate-source-final.json')
assert len(source['files']) == 20
release = read('release.json')
assert sha(B / 'eris-js') == release['sha256']
assert release['source_manifest_sha256'] == sha(B / 'candidate-source-final.json')
comparison = read('connected-comparison.json')
assert not comparison['validation_failures']
summary = comparison['summary']
for kind, total, unchanged, losses in [('cases', 4332, 4330, 2), ('controls', 508, 504, 4)]:
    row = summary['established'][kind]
    assert row['before_total'] == row['after_total'] == total
    assert row['unchanged'] == unchanged and row['losses'] == losses
    assert row['gains'] == row['other_changes'] == 0
for kind, total, before in [('cases', 32, 0), ('controls', 16, 4)]:
    row = summary['new'][kind]
    assert row['before_total'] == row['after_total'] == row['after_healthy'] == total
    assert row['before_healthy'] == before and row['gains'] == total - before
    assert row['losses'] == row['other_changes'] == 0
classification = read('inventory-classification.json')
assert classification['comparison_sha256'] == sha(B / 'connected-comparison.json')
audit = read('independent-results-review.json')
assert audit['status'] == 'clear' and not audit['findings']
ci = read('equality-ci.json')
assert ci['headSha'] == source['base'] and ci['conclusion'] == 'success'
assert len(ci['jobs']) == 9 and all(row['conclusion'] == 'success' for row in ci['jobs'])
for label, total in [('full-default-188-1', 1903), ('full-native-198-1', 2026)]:
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',
                      (B / 'validation' / (label + '.log')).read_text())
    assert [sum(int(row[i]) for row in rows) for i in range(3)] == [total, 0, 0]
diagnostic = 'NODE_CONNECTED_BOOTSTRAP steps=7292 allocated=1765502 objects=688 capacity=688 native=321 prototypes=25'
assert diagnostic in (B / 'validation/connected-188-1.log').read_text()
result = dict(
    kind='Represented ordinary Node connection state', base_commit=source['base'],
    scope='Ordinary cached readonly Node.prototype.isConnected getter over authentic current ordinary parent links, sharing the paid getRootNode walk; template host associations remain separate.',
    source=source, release=release,
    final_validation={label: checked(label) for label in [
        'format-198-1', 'clippy-native-198-1', 'clippy-presenter-188-1',
        'full-default-188-1', 'full-native-198-1', 'release-adapter-188-1']},
    tests=dict(default=1903, native=2026, new_groups=30, independent_groups=16,
               private_groups=12, browser_groups=2,
               focused=read('focused-validation-review.json'), final_failed=0,
               final_ignored=0, all_commands_passed_first_attempt=False, full_test_threads=4),
    accounting=dict(remaining_bootstrap_work=7292, allocated_bytes=1765502,
                    objects=688, object_capacity=688, native_entries=321,
                    legacy_prototype_entries=25, additional_work=524,
                    additional_charged_bytes=3275, getter_body='34+25D+4*sum(S_i)',
                    unary_256_edge_body_work=7458, scoped_native_work=51,
                    scoped_native_bytes=55, bootstrap_work_limit=100000,
                    author_work_limit=100000, cumulative_heap_limit=8388608,
                    numeric_limits_and_resets_changed=False),
    compatibility=dict(path='connected-comparison.json', sha256=sha(B / 'connected-comparison.json'),
                       summary=summary, inventory_classification=dict(
                           path='inventory-classification.json', sha256=sha(B / 'inventory-classification.json'), report=classification)),
    independent_audit=dict(path='independent-results-review.json', sha256=sha(B / 'independent-results-review.json'), status='clear'),
    retained_history=[
        'Initial compilation and all30newgroups passed. Successful connected measurement preceded three descriptive bootstrap snapshot updates in two files; no failing bootstrap attempt was needed.',
        'First constant regression recorded11passes/6failures from one stale preconstant setup count9. Correcting that single private-test literal to10 produced17passes. Both attempts and exact before image remain. Production source did not change after initial compilation.',
        'Runtime formatter launch attempts initially hit a readonly default rustup home and then an unrelated stable formatter missing libz. Installed Rust1.88 formatter succeeded; no source changes or compiler execution from failed launches.',
        'Final layout source-review seal followed compiler start by about4seconds; earlier incremental peer reviews and root final source review preceded it. Original wording and additive correction remain.',
        'Auditor preparations preserve a before-image binding correction and an actual runtime-inventory schema correction. They do not change Runtime tests, raw expectations or health.',
        'Single baseline used published9839259 release before implementation:0/32newcases and4/16healthycontrols, with no binding failures.',
        'Five historical inventory profile commands and aggregate retain exit1. Twenty-four older unhealthy inventory rows remain byte-exact. Two equality inventory cases newly fail with Error; four controls remain unhealthy TypeError observations with no health waiver.',
        'Preceding equality commit9839259 has nine successful GitHub CI jobs; that is distinct from current candidate local validation.'
    ],
    boundaries=[
        'No ShadowRoot, Attr, CDATA, independent document ownership or full Node interface implementation.',
        'Reached-local shape and reciprocal membership checks retain the256-edge endpoint. No template-host traversal or off-path graph audit. Wide sibling scans can exhaust unchanged work limits.',
        'Getter body owns no traversal storage, but generic VM invocation, name copies, errors and inherited allocator limitations remain separate.',
        'Page and confined-worker real-click witnesses preserve21capturedIDs and create zero click nodes. They check four branch moves, saved/ordinary booleans and literal whole-canvas/text/title/status changes.',
        'No Chromium performance comparison or production-security guarantee. Full web compatibility and original browser requirements remain unfinished.'
    ])
with (B / 'result.json').open('x') as stream:
    json.dump(result, stream, indent=2)
    stream.write('\n')
print(json.dumps(dict(path=str(B / 'result.json'), sha256=sha(B / 'result.json'))))
