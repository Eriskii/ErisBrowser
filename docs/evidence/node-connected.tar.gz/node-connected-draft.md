# Node.isConnected

`Node.prototype.isConnected` is an ordinary readonly accessor for the represented
node kinds. It reports whether the current ordinary root is the canonical
Document. A connected template's content fragment remains a separate,
disconnected tree; ordinary children appended directly to that template are
connected. Visibility, names, character data and public property shadows do not
determine the result. Actual ShadowRoot and independent document ownership remain
unimplemented.

The getter checks its receiver's native identity. Its name is `get isConnected`,
its length is zero, and it cannot be constructed. The property is enumerable and
configurable, with no setter. Ordinary own properties and prototype replacement
or deletion work normally; saved getter calls retain their behavior. Extra
arguments are ignored after their expressions have been evaluated.

The implementation shares the bounded ordinary-root traversal with
[`getRootNode`](node-root.md). The existing options conversion, callback effects,
traversal charges and errors of that method are preserved. The connection getter
does not read options, call authored getters, or allocate traversal storage.
Generic invocation, native-name copies and error construction retain their
separate costs and limitations.

For `D` parent edges and parent child-vector lengths `S_i`, the getter body costs
`34 + 25D + 4ΣS_i` work units. Each visited parent must contain exactly one
reciprocal child link. The existing 256-edge limit and local shape checks remain;
wide parent scans can exhaust the work allowance at shallow depth. This is not a
whole-graph validation or a general browser performance result. No quotas,
execution resets, worker authority or transport formats change.

Validation results and source-bound evidence will be added after candidate
execution. This draft does not claim implementation success.
