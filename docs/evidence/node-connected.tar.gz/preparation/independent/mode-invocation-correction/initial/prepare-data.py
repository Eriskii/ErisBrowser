"""Data-only authoring: literal controls/inventory; never parses or runs JS."""
from pathlib import Path
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
sha = lambda text: hashlib.sha256(text.encode()).hexdigest()
complete = dict(status='complete', phase='runtime', error_type='', error_identity='')
error = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
tail = "throw new Error('deliberately wrong expectation');"
guard = "if(typeof Node!=='function'||typeof Text!=='function'||typeof DocumentFragment!=='function')throw new TypeError('constructors');var d=Object.getOwnPropertyDescriptor(Node.prototype,'isConnected');if(!d||typeof d.get!=='function')throw new TypeError('connection getter');var get=d.get,leaf=new Text('guard');if(get.call(document)!==true||!document.body||get.call(document.body)!==true||get.call(leaf)!==false||get.call(new DocumentFragment())!==false)throw new TypeError('genuine connection and disconnection');"
constants = ['ELEMENT_NODE','ATTRIBUTE_NODE','TEXT_NODE','CDATA_SECTION_NODE','ENTITY_REFERENCE_NODE','ENTITY_NODE','PROCESSING_INSTRUCTION_NODE','COMMENT_NODE','DOCUMENT_NODE','DOCUMENT_TYPE_NODE','DOCUMENT_FRAGMENT_NODE','NOTATION_NODE','DOCUMENT_POSITION_DISCONNECTED','DOCUMENT_POSITION_PRECEDING','DOCUMENT_POSITION_FOLLOWING','DOCUMENT_POSITION_CONTAINS','DOCUMENT_POSITION_CONTAINED_BY','DOCUMENT_POSITION_IMPLEMENTATION_SPECIFIC']
strings = ['isConnected','nodeValue','textContent','getRootNode','hasChildNodes','normalize','isEqualNode','isSameNode','contains'] + constants + ['constructor']
constructor = ['length','name','prototype'] + constants
pairs = [
    ('literal-units','common',r"var value='A\uD800',tail='\uDC00';if(value.length!==2||value.charCodeAt(0)!==65||value.charCodeAt(1)!==55296||tail.length!==1||tail.charCodeAt(0)!==56320)throw new TypeError('exact literal units');"),
    ('authentic-connection-getter','feature',guard+"if(d.set!==undefined||d.enumerable!==true||d.configurable!==true||get.name!=='get isConnected'||get.length!==0)throw new TypeError('accessor metadata');var fake=Object.create(Node.prototype),caught=false;try{get.call(fake);}catch(e){caught=e instanceof TypeError;}if(!caught||get.call(leaf)!==false)throw new TypeError('authentic getter brand');"),
    ('fresh-tree-and-template','feature',guard+"var branch=document.createElement('div'),park=new DocumentFragment();branch.append(leaf);document.body.append(branch);if(get.call(leaf)!==true||leaf.parentNode!==branch)throw new TypeError('connected branch');park.append(branch);if(get.call(leaf)!==false||park.firstChild!==branch)throw new TypeError('detached same branch');var t=document.createElement('template'),inside=new Text('inside'),ordinary=new Text('ordinary');if(!t.content||t.content.nodeType!==11)throw new TypeError('template content');t.content.append(inside);t.append(ordinary);document.body.append(t);if(get.call(t)!==true||get.call(ordinary)!==true||get.call(t.content)!==false||get.call(inside)!==false)throw new TypeError('ordinary versus content roots');"),
    ('represented-node-order','feature',guard+"var strings="+json.dumps(strings,separators=(',',':'))+",keys=Reflect.ownKeys(Node.prototype);if(strings.length!==28||keys.length!==29||keys[28]!==Symbol.toStringTag)throw new TypeError('prototype count');for(var i=0;i<28;i++)if(keys[i]!==strings[i])throw new TypeError('prototype order');var expected="+json.dumps(constructor,separators=(',',':'))+",actual=Reflect.ownKeys(Node);if(actual.length!==21)throw new TypeError('constructor count');for(var j=0;j<21;j++)if(actual[j]!==expected[j])throw new TypeError('constructor order');")
]
controls = []
for name,area,source in pairs:
    for positive in [True,False]:
        code = source if positive else source+tail
        controls.append(dict(name=name+('-positive' if positive else '-wrong'),pair=name,positive=positive,area=area,modes=['sloppy','strict'],source=code,source_sha256=sha(code),expected_observation=complete if positive else error))
control_data = dict(status='Fixed source-only proposals; unexecuted and unparsed',negative_health='Exact runtime Error/Error tail requires successful same-mode positive partner; prerequisites throw TypeError; absent observations cannot pass.',pairs=4,control_modes=16,controls=controls)
source = (OUT/'cases.js').read_text()
names = re.findall(r'^  ([a-z][a-z0-9_]+): function\(\)',source,re.M)
assert len(names)==len(set(names))==16
assert len(strings)==len(set(strings))==28 and len(constructor)==21
assert strings[:3]==['isConnected','nodeValue','textContent']
assert strings[6:9]==['isEqualNode','isSameNode','contains']
for positive,negative in zip(controls[::2],controls[1::2]):
    assert negative['source']==positive['source']+tail
    assert negative['pair']==positive['pair']
    assert sha(positive['source'])==positive['source_sha256']
    assert sha(negative['source'])==negative['source_sha256']
assert '\\uD800' in source and '\\\\uD800' not in source
assert controls[0]['source'].count('\\uD800')==1 and '\\\\uD800' not in controls[0]['source']
inventory = dict(collection='nodeConnectedCases',fixture_filename='node-connected.js',proposed_repository_path='tests/fixtures/node-connected.js',execution='Load exact cases.js and invoke one named body in a fresh ordinary Runtime/Document for each sloppy/strict mode; never aggregate.',case_count=16,case_modes=32,control_modes=16,cases=names,ordinary_expectation=complete,ordinary_return=True,literal_prototype_string_keys=strings,literal_prototype_final_symbol='Symbol.toStringTag',literal_prototype_total=29,literal_constructor_keys=constructor,published_base='51907b7b6b3a7465c7a2605f3762375ddaa97a26',anticipated_predecessor='Equality is a separate unpublished/unvalidated increment during this preparation. Rebind to its actual published source and release before baseline.',readonly_mode_case='The body uses ordinary-call this to identify its independently selected source strictness; setter outcomes are not used to choose the expectation. A separate explicit-strict body also requires TypeError and RHS-prefix retention.',conditional_history=dict(new_equality_inventory_case_modes=2,new_equality_inventory_controls=4,older_node_normalize_predicate_root_rows=24,condition='Only if equality publishes with its anticipated six root-inventory losses and preserved earlier observations; no current equality outcome is claimed.'),private_only=['empty Document and authentic Document-parent Text','connected Doctype from a separately parsed Document','depth256/257, wide sibling scans and exact work/heap refusal','malformed IDs/kinds/backlinks/duplicate membership/cycles','ShadowRoot/Attr/CDATA and cross-document realm ownership remain unrepresented/deferred'])
for name,data in [('controls.json',control_data),('inventory.json',inventory)]:
    with (OUT/name).open('x') as stream:
        json.dump(data,stream,indent=2)
        stream.write('\n')
print(json.dumps(dict(ordinary_cases=16,ordinary_modes=32,control_pairs=4,control_modes=16,source_bytes=len(source.encode()),source_sha256=sha(source),engine=False,fixture_parser=False)))
