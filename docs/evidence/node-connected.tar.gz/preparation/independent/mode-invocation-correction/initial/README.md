# Independent Node.isConnected expectations

These sources are authored before any isConnected implementation, baseline or
candidate execution. No JavaScript parser, Runtime or compiler has evaluated
them. The public source base is 51907b7b6b3a7465c7a2605f3762375ddaa97a26.
Structural equality is a separate anticipated, unvalidated predecessor during
this preparation. The conditional 29-key inventory includes its isEqualNode
member; rebind to the actual published predecessor before the first baseline.
No equality source or expectation is changed here.

`cases.js` defines `nodeConnectedCases`. Run each named body alone after loading
the exact file, in fresh strict and sloppy realms. Sixteen bodies mean 32
ordinary-success modes, each returning true. Do not aggregate bodies: prototype
deletion/restoration intentionally changes creation order, and realms with such
changes are disposable. Do not convert a Resource refusal, missing prerequisite
or parser failure into an accepted ordinary result.

`controls.json` has four positive/wrong pairs, each in both modes: 16 controls.
Each wrong source is its exact positive source followed by the fixed ordinary
Error tail. Its same-mode positive must succeed before that negative outcome is
healthy. Prerequisite failures use TypeError, distinct from the intentional
Error/Error runtime observation. Missing observations cannot satisfy a control.
The common exact-unit syntax pair remains independent of isConnected; the other
pairs require authentic getter behavior, live tree/template transitions and the
literal current inventory respectively.

## Literal semantic coverage

- Ordinary getter-only descriptor, shared cached identity, inherited
  enumeration, `get isConnected` name, zero length and Function inheritance.
  Successful Reflect.construct(Text) precedes the getter nonconstruction check.
- Authentic Document and canonical parent alias, connected Element/Text/Comment/
  ProcessingInstruction, detached leaves and retained descendant branches.
  The saved getter must return primitive true/false, never a truthy proxy result.
- Repeated moves through a connected element, an ordinary fragment and detached
  ancestors. Fragment append moves its children; the fragment remains detached.
  Existing node identities and exact unmatched Text data remain unchanged.
- Connected template ordinary children versus separate hosted contents; moves
  across that boundary change connection without treating the host as a parent.
  Parsed SVG/MathML and display:none nodes use the same ordinary connection rule.
- Receiver and extra argument expressions run left to right before the read;
  a later argument can disconnect the selected node. A thrown extra expression
  preserves its prior mutation and exact thrown identity. Getter extras are
  ignored without coercion or an options-member Get.
- Poisoned authored parent/root/owner fields and parent childNodes cannot affect
  the saved native getter. Forged prototypes fail after genuine positive calls
  prove the getter exists and works. Actual alternate-prototype Text construction
  keeps its brand when moved between roots.
- Readonly assignments create no own property and do not convert their RHS.
  The current-mode body expects silent ignoring in sloppy source and TypeError
  in strict source. It determines source strictness independently through an
  ordinary function's `this`, never through the target setter outcome. A second
  explicitly strict function requires TypeError after its RHS connects the node.
- Explicit own data/accessor shadows, deletion, prototype property replacement
  and saved getter identity. Deleting the prototype property must leave ordinary
  undefined/expando behavior, with no getter or readonly fallback resurrection.

The inventory is literal: isConnected comes before nodeValue/textContent, then
the existing represented operations including isEqualNode, eighteen constants,
constructor and the final toStringTag symbol. That is 28 strings plus one symbol;
the constructor retains 21 keys. It describes the selected represented subset,
not every standard Node member. A later feature's intentional inventory change
must preserve these frozen sources and historical raw outcomes.

If equality is accepted with its anticipated inventory results, adding
isConnected will create two new equality-inventory case losses and four unhealthy
controls. The 24 earlier Node-constant, Normalize, predicate and root observations
would then remain unchanged. Those counts are conditional context, not measured
equality or isConnected results. A new pristine inventory case/control pair is
kept separate from historical disposable wrappers.

## Prerequisites and deferred checks

Every body first captures the prototype descriptor and proves the saved getter
returns true for Document/body and false for detached Text/Fragment. No failure
of an absent getter can satisfy a forged-brand or nonconstruction negative.
The fixture uses existing append, exact Text/Comment/PI production, scalar
foreign innerHTML, property descriptors, call/bind and Reflect.construct APIs.
It does not need createElementNS, a public Document constructor, removeChild,
nextSibling or host Object.setPrototypeOf.

Empty Document, parsed Doctype and Document-parent Text belong in private host
tests because their setup is not assumed by the ordinary adapter. Malformed
IDs/backlinks, reciprocal cycles, the accepted 256-edge endpoint, wide scans and
precise budget refusal also require private tests. ShadowRoot/slot ancestry,
Attr, CDATA, cross-document identity and security wrappers remain deferred.
No fixture assertion implies that template content is a shadow tree.

`prepare-data.py` only emits literal JSON controls/inventory and checks source
bytes, names and hashes with Python standard-library operations. It does not
parse or execute JavaScript. Ordinary feasibility and work/storage costs remain
unmeasured; no quota, deadline or ordinary-success expectation is weakened.

Primary basis: [DOM isConnected](https://dom.spec.whatwg.org/#dom-node-isconnected),
[connected](https://dom.spec.whatwg.org/#connected),
[shadow-including root](https://dom.spec.whatwg.org/#concept-shadow-including-root),
[Web IDL attributes](https://webidl.spec.whatwg.org/#es-attributes), and the
separately held root scope/layout assessment and dispatch-placement refinement.
The source-input manifest binds those documents and the original equality
format references; their fixtures are never executed or edited by this task.
