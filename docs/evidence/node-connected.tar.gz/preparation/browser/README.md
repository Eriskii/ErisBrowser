# Node.isConnected browser witness

This is an independently authored, unexecuted browser fixture and public-API
reference helper. The actual published predecessor is equality commit
9839259eeaf10dfab8205d88e0f3b3c359d358b8, bound additively by
`../root/published-base.json` to release `19cb3f21…`. The earlier independent
case/source holds keep their original anticipatory context unchanged.
No isConnected implementation, compiler, engine or HTML/JS parser is exercised
by this preparation. Rust 1.88 rustfmt only formats the helper.

## Integration contract

Copy the two `tests/` paths unchanged into the eventual isolated implementation:

- `tests/fixtures/node-connected.html`
- `tests/support/node_connected.rs`

The helper exports `HTML`, `State`, `metadata(phase)` and
`check(doc, layout, images, fonts, phase, previous) -> State`. Use a 320×240
viewport and one retained Page or worker session. Check phase zero after initial
script execution, dispatch one real click to `#change`, then check phase one
with the prior State. The helper requires no runtime/private field access.
Root owns Page and confined-worker wrappers and reserves the generation; this
scratch source does not assign a worker generation or alter existing tests.

Require empty Page diagnostics and the established worker diagnostic policy,
the correct generation/edit sequence and literal metadata before calling the
helper. Worker transport must preserve the same 21 IDs and total arena count
across snapshots. No script re-evaluation or independent second page stands in
for the real click.

## Literal behavior

Initial HTML contains a connected `#branch` div with `#label` span/Text `Alpha`
and a Comment `kept`. A connected hidden template has a separately hosted content
Text `inside`; load appends a distinct ordinary Text `ordinary` to the template.
A detached unhosted fragment contains Text `parked`. The saved getter first
proves true on Document and false on a genuine detached Text. An own data shadow
on the branch is explicitly defined/deleted at load; the saved getter still reads
its authentic connection, and ordinary reads resume afterward.

Each connection assertion checks **both** `get.call(node)` and the ordinary
`node.isConnected` property against literal booleans. The branch's div, span,
Text and Comment are checked with the same identities and reciprocal links.

The single click moves only the existing branch, in this order:

1. Into the detached fragment: all branch nodes are false.
2. Into the connected template's actual content fragment: all branch nodes are
   false, while the template and its ordinary Text remain true.
3. Into the connected template's ordinary children: all branch nodes are true,
   while hosted content and its retained Text remain false.
4. Back into the document body: all branch nodes are true again.

The exact trace is `fcob`. Each append has one Node argument, so no temporary
fragment or string Text materialization is needed. Moves leave the branch Text
equal to `Alpha`. After those checks, explicit data writes change that existing
Text to `Omega`, title to `Connection done` and status to `done`; the body class
changes from `ready` to `clicked`. No new Text, Element or fragment is created
on click. Connection reads themselves cause no render update.

Final tree structure matches the initial retained branch/template/fragment
structure, apart from body child insertion order and the three stated Text data
changes. Fixed absolute positions avoid incidental flow effects from that order.
The helper independently checks 21 distinct captured IDs, arena count, internal
kinds, exact scalar units, child vectors/backlinks, template host association and
the fixed base URL `https://connected.example/fixed/`.

## Independent rendering reference

The reference is separately written, script-free scalar markup. It contains
the same visible span/Text boundary and CSS, with `Alpha`/`Omega` and
`ready`/`done` chosen from phase literals. It does not clone, serialize or project
the actual DOM, consult actual isConnected results, or infer expected strings
from rendered output. Nonpainting script, Comment, template and detached
bookkeeping are omitted from reference markup.

Both marker centers are green (`0x008000`) after load and blue (`0x0000ff`) after
click. Full 320×240 canvas equality is supplemented by nonempty branch glyphs,
exactly one DrawCommand for the expected visible word and status, and absence
of the other phase's visible word. Metadata is `Connection ready`/`Connection
done`. These checks prevent matching blank or all-failed scenes from passing.

`expected.json` freezes scene/move literals; `inventory.json` records interface,
phase and capture counts. Static preparation checks CSS equality, exact ID list
length and absence of node-creation syntax in the click body. They do not prove
ordinary execution fits the unchanged 100,000-work allowance. That remains a
required ordinary-success result for later measured validation; neither
resource refusals nor missing prerequisites are accepted substitutes.

ShadowRoot/slots, Attr, CDATA, cross-document identity and malformed host graphs
are outside this browser witness. It tests represented ordinary trees and actual
template content separation, with no shadow-host traversal, allocation recovery,
security or performance claim.
