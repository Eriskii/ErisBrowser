#!/usr/bin/env python3
"""Prepare a source-bound connected matrix; never launch a JavaScript engine."""
from pathlib import Path
import ast
import hashlib
import json
import re
import shutil
import subprocess

if not __debug__:
    raise RuntimeError('run without Python optimization')
P = Path(__file__).resolve().parents[1]
R = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-node-equality-preparation-1/replay')
ART = Path('/tmp/eris-node-equality-1')
OUT = P / 'replay'
FIXTURE_SHA = '25e76612b7ff0e8f6ce0a68b5ae72399a77d27be2b745da0aad2b44ae885bc94'
BASE = '9839259eeaf10dfab8205d88e0f3b3c359d358b8'
RELEASE_SHA = '19cb3f218ab907b9702c48e127cb9e311113b9347795a352932b05f79f8ec519'


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def verify(row, directory=None):
    p = Path(row['path'])
    if not p.is_absolute():
        assert directory is not None
        p = directory / p
    assert sha(p) == row['sha256'] and p.stat().st_size == row['bytes'], str(p)
    return p


def write_json(p, obj):
    with p.open('x') as f:
        json.dump(obj, f, indent=2)
        f.write('\n')


ready = json.loads((P / 'independent/source-ready.json').read_text())
runtime = json.loads((P / 'runtime/source-ready.json').read_text())
layout = json.loads((P / 'layout/source-ready-2.json').read_text())
for row in ready['files'] + runtime['files']:
    verify(row)
for row in layout['files']:
    verify(row, P / 'layout')
root_review = json.loads((P / 'root/independent-source-review.json').read_text())
assert root_review['status'] == 'clear root source-only fixture review'
peer_review = json.loads((P / 'layout/connected-source-review.json').read_text())
assert peer_review['status'].startswith('clear ') and peer_review['findings'] == []
base = json.loads((P / 'root/published-base.json').read_text())
assert base['commit'] == BASE == subprocess.check_output(
    ['git', 'rev-parse', 'HEAD'], cwd=R, text=True).strip()
assert base['release']['sha256'] == RELEASE_SHA == sha(Path(base['release']['path']))
assert Path(base['release']['path']).stat().st_size == base['release']['bytes']

# Refuse a reused output directory; preserve every preparation attempt externally.
OUT.mkdir()
history = []


def copy(p, rel):
    dest = OUT / rel
    if dest.exists():
        assert dest.read_bytes() == p.read_bytes(), str(dest)
        return
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, dest)
    history.append(dict(origin=str(p), copy=str(rel), bytes=dest.stat().st_size,
                        sha256=sha(dest)))


# These directories are held source inputs; copy correction history unchanged.
for directory in ['independent', 'runtime', 'layout']:
    for p in sorted((P / directory).rglob('*')):
        if p.is_file():
            copy(p, p.relative_to(P))
for name in ['scope.md', 'independent-source-review.json', 'published-base.json',
             'plan-acceptance.json', 'browser-source-review.json', 'prepare-replay.py']:
    copy(P / 'root' / name, Path('root') / name)

for name in ['test262_conformance.py', 'html_conformance.py', 'import_test262.py']:
    assert (R / 'tools' / name).read_bytes() == (OLD / 'tools' / name).read_bytes()
    copy(OLD / 'tools' / name, Path('tools') / name)
for name in ['node-constants.js', 'node-normalize.js', 'node-predicates.js',
             'node-root.js', 'node-equality.js']:
    raw = subprocess.check_output(['git', 'show', BASE + ':tests/fixtures/' + name], cwd=R)
    assert (R / 'tests/fixtures' / name).read_bytes() == raw
    copy(R / 'tests/fixtures' / name, Path('history') / name)
for name in ['source-ready.json', 'replay.py', 'replay-matrix.json', 'replay-inputs.json']:
    copy(OLD / name, Path('history/prior-replay') / name)
for name in ['candidate-source-final.json', 'release.json', 'published.json']:
    copy(ART / name, Path('history/published-equality') / name)

# Rebind held Runtime inputs to actual published equality Git bytes. Original
# manifests retain their historical anticipated-publication wording unchanged.
sources = json.loads((P / 'runtime/source-inputs.json').read_text())['sources']
for row in sources:
    held = Path(row['held_copy'])
    assert sha(held) == row['sha256'] and held.stat().st_size == row['bytes']
    raw = subprocess.check_output(['git', 'show', BASE + ':' + row['repository_path']], cwd=R)
    assert raw == held.read_bytes()
    copy(held, held.relative_to(P))

# Layout examined the earlier published root commit. Recover precisely those
# objects, rather than reading changed paths from current main or either tree.
legacy = json.loads((P / 'layout/source-inputs.json').read_text())
for row in legacy['files']:
    rel = Path('history/layout-base-source') / row['path']
    dest = OUT / rel
    dest.parent.mkdir(parents=True, exist_ok=True)
    raw = subprocess.check_output(
        ['git', 'show', legacy['published_base'] + ':' + row['path']], cwd=R)
    assert len(raw) == row['bytes'] and hashlib.sha256(raw).hexdigest() == row['sha256']
    with dest.open('xb') as f:
        f.write(raw)
    history.append(dict(origin='git:' + legacy['published_base'] + ':' + row['path'],
                        copy=str(rel), bytes=len(raw), sha256=sha(dest)))

# Preserve referenced frozen documents/results as well as their reference lists.
references = (json.loads((P / 'independent/source-inputs.json').read_text())['files']
              + json.loads((P / 'runtime/dependencies.json').read_text())['references'])
for row in references:
    p = verify(row)
    if p.is_relative_to(P):
        rel = p.relative_to(P)
    else:
        assert p.is_relative_to(Path('/tmp'))
        rel = Path('history/dependencies') / p.relative_to('/tmp')
    copy(p, rel)

fixture = OUT / 'independent/cases.js'
assert sha(fixture) == FIXTURE_SHA
inv = json.loads((OUT / 'independent/inventory.json').read_text())
ctrl = json.loads((OUT / 'independent/controls.json').read_text())
assert len(inv['cases']) == 16 and inv['collection'] == 'nodeConnectedCases'
assert len(ctrl['controls']) == 8
assert inv['case_invocation_argument_by_mode'] == {'sloppy': False, 'strict': True}
assert set(re.findall(r'^  ([A-Za-z0-9_]+): function\((?:strict)?\)',
                      fixture.read_text(), re.M)) == set(inv['cases'])
inventory = dict(fixture='independent/cases.js', fixture_sha256=FIXTURE_SHA,
                 collection=inv['collection'],
                 cases=[dict(name=name, modes=['sloppy', 'strict'],
                             expected_observation=inv['ordinary_expectation'])
                        for name in inv['cases']],
                 controls=ctrl['controls'], case_modes=32, control_modes=16,
                 case_invocation_argument_by_mode=inv['case_invocation_argument_by_mode'])
write_json(OUT / 'replay-inputs.json', inventory)

original = (OLD / 'replay.py').read_text()
changes = [('Frozen Node equality observations', 'Frozen Node connected observations'),
           ('nodeEqualityCases', 'nodeConnectedCases'),
           ('node-equality.js', 'node-connected.js'),
           ('675e9c85be938da35f929c8b9f661b2493789648074e92de2816367795474597', FIXTURE_SHA)]
driver = original
for before, after in changes:
    assert before in driver
    driver = driver.replace(before, after)
old_loop = '''        body = (fixture + b'\\nif(nodeConnectedCases.' + row['name'].encode() +
                b'() !== true) throw new Error("case did not return true");'
                if kind == 'case' else row['source'].encode())
        for mode in row['modes']:
'''
new_loop = '''        for mode in row['modes']:
            body = (fixture + b'\\nif(nodeConnectedCases.' + row['name'].encode() +
                    (b'(true)' if mode == 'strict' else b'(false)') +
                    b' !== true) throw new Error("case did not return true");'
                    if kind == 'case' else row['source'].encode())
'''
assert driver.count(old_loop) == 1
driver = driver.replace(old_loop, new_loop)
reverse = driver.replace(new_loop, old_loop)
for before, after in reversed(changes):
    reverse = reverse.replace(after, before)
assert reverse == original
ast.parse(driver)  # Python supervisor syntax only; never a JavaScript parser.
(OUT / 'replay.py').write_text(driver)
write_json(OUT / 'driver-transformation.json', dict(
    original=dict(path=str(OLD / 'replay.py'), sha256=sha(OLD / 'replay.py')),
    current=dict(path=str(OUT / 'replay.py'), sha256=sha(OUT / 'replay.py')),
    identity_substitutions=[dict(before=a, after=b) for a, b in changes],
    substantive_change=dict(before=old_loop, after=new_loop,
                            reason='Explicit literal Boolean from frozen strict/sloppy mode metadata'),
    reverse_transform_is_byte_exact=True,
    unchanged='All observation, subprocess bounds, error retention, binding and positive-partner policy'))
write_json(OUT / 'preparation-history.json', history)

commands = []
for option in ['--prepare', '--verify']:
    args = ['python3', str(OUT / 'replay.py'), option]
    result = subprocess.run(args, capture_output=True, text=True)
    record = dict(command=args, exit=result.returncode, stdout=result.stdout, stderr=result.stderr)
    commands.append(record)
    # Retain an inert preparation failure too, before propagating it.
    if result.returncode != 0:
        write_json(OUT / 'inert-verification-failure.json', dict(commands=commands))
    assert result.returncode == 0, record
write_json(OUT / 'inert-verification.json', dict(engine_run=False, compiler_run=False,
                                               javascript_parser_run=False, commands=commands))

result = dict(
    status='Frozen connected expectations; inert matrix verified; no connected engine or parser execution',
    location=str(OUT), location_must_remain_fixed=True,
    ordinary_bodies=16, ordinary_modes=32, control_pairs=4, control_modes=16, total_rows=48,
    history_copies=len(history),
    driver=dict(path=str(OUT / 'replay.py'), sha256=sha(OUT / 'replay.py')),
    matrix=dict(path=str(OUT / 'replay-matrix.json'), sha256=sha(OUT / 'replay-matrix.json')),
    fixture_sha256=FIXTURE_SHA,
    invocation='Every named case gets literal false in sloppy mode and true in strict mode; controls unchanged',
    supervision='Exact prior equality driver except four reversible identity substitutions and explicit per-mode Boolean case invocation; ERJS1/ERJR2, 3s, 96KiB stdout/64KiB stderr, 4MiB request, exclusive fresh report, pre/post bindings, same-mode positive controls. Inherited direct-child supervision.',
    baseline=dict(status='Not executed by this preparation; root owns future baseline',
                  published_commit=BASE, binary=base['release']),
    history_policy='Initial anticipated-equality holds and corrections remain exact; additive published base binds actual equality. Five prior fixtures unchanged. Six new equality inventory losses are conditional; 24 older unhealthy historical rows stay distinct.',
    files=[dict(path=str(p), bytes=p.stat().st_size, sha256=sha(p))
           for p in sorted(OUT.rglob('*')) if p.is_file()])
write_json(OUT / 'source-ready.json', result)
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, indent=2))
