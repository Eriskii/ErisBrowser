# Concrete represented Node.isConnected proposal

This is a source-only plan, not an implementation or candidate result. The actual published source remains 51907b7b6b3a7465c7a2605f3762375ddaa97a26. The immediate anticipated predecessor is the validated, still unpublished equality source bound by final19 manifest 08dc5dc8c66fe1d77fe93501179a109ee2baf66ad653c7f676d1d4eafeb7784b. Root reports its measured bootstrap as 7816 remaining work / 1762227 charged bytes / 687 objects and capacity. Earlier scope/layout wording about unvalidated equality remains historical; the additive dependency binding records this later context. Publication must be rebound before baseline or implementation acceptance. No tracked files, executable fixtures, compiler or engine are changed/run by this plan.

## Ordinary accessor and represented scope

Install an enumerable/configurable accessor on Node.prototype before nodeValue and textContent. Its cached getter has display name `get isConnected`, length0, Function.prototype and ordinary configurable, nonenumerable, nonwritable name/length metadata. The setter is Undefined; there is no setter function or virtual readonly entry. Use `node_data_function("getIsConnected", "get isConnected", 0)` and one new metadata bag. Getter construction remains refused by the existing native binding machinery.

The DOM getter reflects whether the shadow-including root is a Document; within the represented ordinary node tree this is the canonical Document endpoint. A template content fragment is a separate root, even when its template host is connected. Ordinary children attached to a connected template element remain connected. Document itself, including an empty Document, is true. Native kinds/prototype overrides, visibility, node data, namespace and public parent/root properties do not decide the answer. Genuine ShadowRoot and cross-document ownership remain absent. [DOM getter](https://dom.spec.whatwg.org/#dom-node-isconnected).

Authentic receiver conversion precedes any traversal. Saved getter extra arguments have already had their expressions evaluated by the VM, but no value is converted and no `composed` property is read. No getter body author callback or mutation occurs. Fake prototype inheritors fail branding; genuine alternate-prototype constructed nodes remain authentic. Sloppy missing-setter assignment does not create an own property; strict assignment throws after normal RHS evaluation. Explicit own properties, prototype replacement/deletion and saved getter calls keep ordinary behavior. The existing legacy attribute/fallback sources contain no isConnected branch, so do not add one. Web IDL defines this regular readonly getter, with no setter and length zero. [Web IDL attributes](https://webidl.spec.whatwg.org/#es-attributes).

## Exact shared traversal extraction

Choose these internal signatures:

- `node_ordinary_root_from_id(&mut self, current: NodeId, doc: &Document) -> Result<Value>` in node_root.rs, visible only to sibling script modules. The only successful variants are canonical `Value::Document` or `Value::Node(root_id)`.
- `node_is_connected(&mut self, receiver: Value, doc: &Document) -> Result<Value>` in a small node_connected.rs module. It pays16, calls `node_predicates::node_id`, invokes the shared walk, pays2, then returns Bool based on the canonical Document variant.
- `install_node_connected(&mut self, prototype: usize) -> Result<()>`, paying4 before cached factory/property installation.

Keep the existing paid walk's Value endpoint instead of converting it to NodeId. This permits a mechanical extraction of the complete region from `let mut edges = 0;` through the current loop into the new helper: same work calls, messages, checks, comparisons, branch ordering, iteration and endpoint conversion. Only the `mut current` parameter binding and surrounding function declaration move. No new wrapper fee is inserted into getRootNode.

The getRootNode entry keeps receiver16 and node_id, then unchanged node_root_options over mutable Document, then calls the shared immutable walk with the surviving ID. Its dictionary Get still occurs exactly once on the original options receiver before any fresh traversal read. Conversion effects/throws, no-options path, canonical return and invalid/resource precedence stay unchanged. The shared helper deliberately retains the existing Node-root error messages; the new getter does not relabel traversal errors.

Retain every current local policy: bounded arena/child counts, canonical parentless Document, parentless Fragment, childless leaves, valid allowed parent container, self-link refusal, exactly one reciprocal membership in the parent's complete child vector, and the 256-edge endpoint. Cycles fail on a self-link or at the unchanged depth bound. An unrelated sibling's own graph is not audited. Template host links are never followed. A false-root host kind at doc.root still reaches the existing explicit canonical endpoint check; there is no new global scan.

Extraction proof before compilation should compare the retained source region with the helper body byte-for-byte, ignoring only outer indentation if necessary. Also bind unchanged node_root_options and node_predicates helpers. Existing getRootNode callback/depth/cutpoint tests remain unchanged except its historical complete-inventory wrapper. Add direct helper/getRootNode/default comparisons showing equal return/error and a constant26-work difference (receiver16 + default options10), with zero body-owned heap in both. Compare getter with helper showing18 extra work; stop before the getter's final2 debit to witness terminal final-result refusal. These are meaningful measured endpoint tests, not production fee resets.

## Dispatch and invocation accounting

Keep the current operation-length switch and all of its successful arms unchanged. Keep work8 and the four old accessor match arms unchanged. Only in that match's unmatched branch, pay1 for length discrimination; at length14 pay14 before comparing `getIsConnected` and dispatch on equality. Other suffixes retain an ordinary unknown-accessor TypeError after their reached admission. Successful old getNodeValue/setNodeValue/getTextContent/setTextContent routes never enter the new branch, so they pay no new comparison. getRootNode and isEqualNode retain their existing first/second length11 comparisons.

The new full native name has23 ASCII bytes. Existing cleanup-protected name preflight therefore pays27 work and55 charged bytes. New suffix routing pays1 existing operation discrimination +8 old accessor match +1 new length discrimination +14 comparison =24. Scoped invocation total is51 work /55 bytes, in addition to generic VM calls, property lookup and error behavior. The getter body has no owned traversal/payload storage; the entire JS call is not allocation-free.

For D ordinary parent edges and scanned parent child-vector lengths S_i, the unchanged shared walk costs `12*(D+1) + 12*D + sum(1+4*S_i) + 4 = 16 + 25*D + 4*sum(S_i)`. Getter brand16 and Bool2 yield `34 + 25*D + 4*sum(S_i)`. Document/detached root body is34; a unary 256-edge body is7458. Existing default getRootNode remains `42 + 25*D + 4*sum(S_i)`, unary7466. All arithmetic admission and error paths remain shared. A wide parent can exhaust100000 work at shallow depth; no universal depth-success or pure O(depth) claim. No quota, refund, authority or reset changes.

## Metadata and constant batch ledger

One new cached function and one prototype accessor use one additional object bag. The physical preconstant prototype order becomes tag,isConnected,nodeValue,textContent,getRootNode,hasChildNodes,normalize,isEqualNode,isSameNode,contains. Its exact sorted string guard becomes contains,getRootNode,hasChildNodes,isConnected,isEqualNode,isSameNode,nodeValue,normalize,textContent, then the tag symbol. Strings remain in IDL creation order for reflection; the tag still groups after strings. Preserve all old descriptor/Native identities by move.

The constructor remains old3/map21/order21. Prototype old10/map28/order29 replaces9/27/28. N28's sorted build has the same overflows at12 and24, height1 and four allocated nodes. Right leaf4 needs one-pair repair to5; retain the existing64 repair allowance,32 navigation,32 headers and48E sort scratch. Three27-comparison passes at42 give3402; structural work660 gives map4062. Owner guard32+4*11+2*10*42=916. These replace3918/828: batch delta232. Including unchanged constructor3030/300 and common1584 gives total9892. Both-map guards, reserves, no-partial-publication and post-take terminal failure behavior remain.

| Added work row | Work |
| --- | ---: |
| Cached getter factory:9+38+29+31+31 |138|
| New isConnected key/property at old count1:30+12+9+1 |52|
| New installer entry |4|
| Existing nodeValue shift1→2 |11|
| Existing textContent shift2→3 |13|
| Existing getRootNode shift3→4 |13|
| Existing hasChildNodes shift4→5 |15|
| Existing normalize shift5→6 |11|
| Existing isEqualNode shift6→7 |13|
| Existing isSameNode shift7→8 |12|
| Existing contains shift8→9 |10|
| N27→N28 batch |232|
| Later constructor property |0|
| Total |524|

These eight shifted owner insertions remain below the first potential tree-split charge; reserved order capacity avoids growth. The later constructor insertion still has the same conservative lookup height/movement/admission. The new accessor needs no setter bag.

Typed storage delta is `1379 + (S+A+D+N) + 3K+B+E`: S is one object-arena slot; A/D the existing optional per-object allowances; N the Native header;2K getter order plus1K additional Node order;B one first getter-property tree block;E the constant staging entry. The fixed1379 decomposes into object72, display string124, length key88/property280, name key80/property272, native name55, owner key108/property300. No extra tree block comes from shifting count1..8 to2..9. Batch storage becomes `14820+18K+145E+7B`. With prior64-bit types K16/E72/B1472 and S+A+D+N304, the delta is3275 bytes. Relative to observed equality7816/1762227/687, conditional isConnected output is7292 work remaining /1765502 charged bytes /688 objects and capacity; native registry321 and legacy prototypes25 stay unchanged. These are predictions pending fresh candidate measurement and predecessor publication binding.

## Private witnesses and history

Plan small direct work-cut sweeps for connected/detached/root cases, no heap needed by the body; deep cases get measured exact/one-short checks, not an exhaustive7458-step state-copy sweep. Construct reciprocal links and prove the accepted256-edge geometry through from_snapshot. Cover overdepth, missing/duplicate reciprocity, bad ID/kind, childful leaf, false root, cycles and ignored template host. Test Document-parent Text and private connected Doctype/PI/Comment without requiring absent public Document enumeration.

Exercise the shared walk equivalence with existing getRootNode defaults, object options, getter mutation/throw identities and saved invocation cleanup. Explicitly show isConnected ignores public getRootNode/parentNode/ownerDocument shadows, Object.prototype.composed getters and uncoercible extra values. Test current mutation effects before native entry, strict/sloppy readonly assignment, own shadow/delete, prototype getter replacement/deletion and no fallback resurrection. Include real positive Reflect.construct(Text) before nonconstructible getter negatives and genuine alternate prototypes. Use two live runtimes to check mutable getter metadata isolation.

A wide parent call should preserve completed argument/RHS effects and terminal Resource semantics, with no body mutation, hidden budget reset or catch/finally execution. Saved native exact/one-short work and name-copy heap checks retain complete DOM/capacity/metadata snapshots. Unrelated arena nodes and payload bytes must not affect direct body costs.

Keep all five prior Node constants/Normalize/predicates/root/equality JS sources byte-exact. Their existing full-inventory inputs remain historical expectations, including earlier unhealthy rows; do not weaken or rewrite their external oracles. Each private historical wrapper must explicitly save the new accessor descriptor, require callable get/undefined set and flags, delete it, invoke its unchanged old case with existing later-operation removals as needed, restore the exact descriptor, and discard the realm because creation order changes. Do not add isConnected to an old list that requires d.value to be a method. Convert equality's current full-inventory private invocation into the corresponding named wrapper. The new independently authored current witness must assert28 strings plus the tag=29. Update only the small current node_data index witness and constants setup shapes explicitly. Full historical loss counts come from frozen matrices, not assumptions.

Planned source scope: module/new node_connected.rs and private tests; node_root extraction; node_data unmatched dispatch branch; dom_prototypes metadata reservation/install; node_constants guards/tests; five historical private wrappers and current node_data order witness; exact new independently held fixture. DOM storage, dom_own_properties legacy table, machine invocation bridge, old JS fixtures and measured bootstrap literals need no implementation edits beyond root's later authorized measurements. Source-only planning is not permission to implement these paths yet.
