# Conditional N27 and equality metadata arithmetic

Source-only follow-up to the held equality scope, using the unpublished getRootNode candidate as an anticipated predecessor. No new source implementation or measurements are claimed.

For prototype old-count 9/result-count 27/order capacity 28, the held pinned sorted-collect algorithm has two leaf overflow events, at items 12 and 24. Height remains one and four nodes have been allocated. The right leaf has three pairs, so right-border repair transfers two pairs to reach five, without allocating another node. The existing 64-work repair, 32 navigation, 32 header and 48-entry sort-scratch allowances remain. Constructor N21 is unchanged. This follows the same version-tagged Rust 1.88/1.98 append/fix/node proof retained in `/tmp/eris-node-predicates-preparation-1/layout/n25-bulk-review.md`; there is no retained pinned local rust-src directory.

Three sorted/order/dedup passes give `3*26*42 = 3276` comparison work. Structural work is `64+4*10+6*27+8*27+32+64+32+32 = 642`, so map work is 3918. Owner validation is `32+4*10+2*9*42 = 828`. Compared with N26 map3774/owner740, the batch adds `144+88 = 232` work and one staged `(PropertyKey, Property)` entry E. The additional initial order slot K is accounted separately, not hidden in this map delta.

The new operation's metadata factory costs 127. At owner count6, key construction costs30, then `6*12+14+1 = 87` comparison/move/order work, giving117. Installer entry4, shifted existing isSameNode/contains properties12+10, and batch232 sum to **502** added work. Existing getRootNode's first 11-unit dispatcher comparison remains paid; equality's second 11-unit comparison is additional invocation work and is not this bootstrap calculation.

Typed metadata delta remains `1360 + (S+A+D+N) + 3K+B+E`. With prior observed types this is3256bytes. The root-reported but unpublished getRootNode context8318/1758971/686 therefore implies conditional equality predictions7816remaining work/1762227charged bytes/687objects. Freeze and measure the actual predecessor/candidate before treating any prediction as an observation. Quotas and reset sites are unchanged.
