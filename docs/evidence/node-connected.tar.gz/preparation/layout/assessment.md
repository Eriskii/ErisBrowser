# Node.isConnected feasibility — source only

The represented ordinary-tree getter is a small feasible increment: reuse the paid internal parent walk behind getRootNode, return a boolean, and publish a normal readonly Node prototype accessor. No DOM storage, mutation, serialization, rendering or worker-transport change is needed. This is a proposal, not an implementation or measured result.

The inspected published base is **51907b7b6b3a7465c7a2605f3762375ddaa97a26**. Its Node prototype has getRootNode and the three predicates but no isEqualNode or isConnected. Equality is an anticipated separate increment; its draft is not a published prerequisite. Rebase the concrete metadata/dispatch plan onto its eventual accepted source, rather than assuming its current implementation succeeds.

## Contract and represented scope

The DOM getter returns whether the receiver's shadow-including root is a Document. Without ShadowRoot, this reduces to the ordinary parent root. Document itself is connected, including an empty Document. Detached branches, ordinary fragments and actual template contents are disconnected; an ordinary child attached directly to a connected template element remains connected. Visibility, namespace, node data and owner-document identity do not decide connection. [DOM getter](https://dom.spec.whatwg.org/#dom-node-isconnected), [connected](https://dom.spec.whatwg.org/#connected), [shadow-including root](https://dom.spec.whatwg.org/#concept-shadow-including-root).

Web IDL requires an enumerable/configurable prototype accessor with no setter, authentic Node branding, getter name `get isConnected`, and length zero. It has no options conversion. Readonly assignment uses normal missing-setter behavior; explicit own-property definition can shadow it. [Web IDL attributes](https://webidl.spec.whatwg.org/#es-attributes).

The existing seven NodeKind alternatives suffice, including connected Text/Comment/PI/Doctype and a structurally admitted Document-parent Text. Genuine ShadowRoot/slot traversal, Attr and CDATA, other document ownership and cross-realm/security machinery remain outside this increment. A template fragment's `host` is not a shadow host and must never be followed. Independent Document construction is unnecessary for the public fixture; private Document setup can cover the empty-root case.

## Small implementation seam

`src/script/node_root.rs::node_get_root_node` already authenticates, converts options, then walks current ordinary parents through `node_predicates::{node_id,local_node}`. Extract only its callback-free paid traversal into an internal helper returning an authenticated root NodeId (or retain an equivalent explicitly paid private path). Leave getRootNode's receiver check, dictionary Get, charges, endpoint conversion and failure order intact. The new getter authenticates and calls that traversal without creating an options object, reading `composed`, or invoking any overridable public method. Compare the validated endpoint with the canonical Document root.

Do not call JavaScript getRootNode/contains, follow `host_including_parent`, or reuse DOM's unmetered `is_descendant_of`: those alternatives either introduce author callbacks, cross template boundaries, omit reciprocal checks, or differ at the depth endpoint. The read itself has no authored callbacks. Receiver/argument expressions may mutate before it begins; saved getter calls must use the resulting current links. Ignore own/prototype shadows of parentNode, getRootNode and ownerDocument internally.

`node_data_function` supplies a paid cached native function bag and normal Function.prototype/name/length metadata. Add one getter bag and accessor with `set: Undefined`, before the represented nodeValue/textContent attributes in creation order. Authentic alternate-prototype Texts retain their brand; inheriting from Node.prototype does not grant one. Ordinary deletion/replacement must remain effective, with a previously saved getter still callable.

No isConnected entry exists in the inspected `script.rs` fallback or `dom_own_properties.rs::ATTRIBUTES`. Both ordinary reads and `dom_set_ordinary` can therefore resolve the new accessor without a migration exception. Keep it out of the legacy table: adding a virtual readonly rule would intercept writes even after prototype deletion. Existing expandos named isConnected are ordinary own shadows.

Native dispatch requires an explicit paid comparison. A suggested `getIsConnected` suffix has length 14, shared with existing getTextContent/setTextContent fallback names. The anticipated equality operation also shares length 11 with getRootNode. Neither branch may rely on globally unique suffix lengths or skip UTF-16/string comparison work. No dispatch fee or bootstrap prediction is derived here.

The constant batch helper has exact owner-shape/order guards. On published source it admits eight old prototype properties and 26 before the constructor; adding only this attribute would require nine/27 and 28 total Reflect.ownKeys entries. If equality is accepted first, the corresponding conditional shapes become ten/28 and 29 total keys; the constructor's 21 entries stay unchanged. Update roster, ordering, capacity, sorted-build and metadata allocation plans against actual final types before implementation. Preserve frozen historical full-inventory inputs/outcomes; author a separate new inventory witness. Existing attribute-index assertions need an explicit recorded migration, not silent oracle replacement.

## Boundaries and resource policy

Retain getRootNode's scoped host-integrity policy: valid IDs and local kinds; canonical parentless Document; parentless Fragment; childless noncontainers; parent ID and allowed container kind; exactly one reciprocal occurrence of the current child. Charge each complete parent child-vector scan before reading it, including duplicate detection and failures. Accept a root reached after exactly MAX_DEPTH ordinary edges; reject a further edge, self-link or a cycle that cannot terminate within that bound. Do not scan unrelated descendants or validate template-host links at a fragment endpoint.

This is not complete graph validation. A malformed unrelated sibling/branch is outside the selected path. A noncanonical Document is refused as a malformed host state rather than silently treated as another supported document. Invalid state should retain existing TypeError policy; budget exhaustion remains terminal Resource and consumes the absolute allowance. Wide valid parents can exhaust work even at small depth.

The parent walk needs only current ID/edge counter/scan state, no visited map or arena-sized allocation. Work follows reached depth plus the lengths of scanned parent child vectors, not just depth. Generic property lookup, invocation-name copies, diagnostics and cached metadata still have their existing allocation costs and limitations; do not advertise an entirely allocation-free JS call or universal OOM recovery. No charge discounts, resets, revised quotas, measurements or timing claims are proposed.

## Concrete checks to prepare after scope approval

- Descriptor/name/length/function identity, inherited enumeration and pristine member order; prove a successful authentic call before forged-receiver negatives. Prove Reflect.construct(Text, ...) succeeds before testing getter nonconstruction.
- Document and every represented connected kind; empty Document and Document-parent Text privately. Detached leaf/branch, unhosted fragment, actual template content, ordinary template child and all represented namespaces.
- Move a retained subtree between document, fragment and detached ancestor, checking current boolean and stable IDs. Poison public parent/root getters and pass uncoercible extra values to a saved getter; no native conversion or public property read occurs.
- Sloppy readonly assignment leaves no own property; strict assignment throws after RHS effects, without coercing the RHS. Explicit own shadow/delete restores inherited behavior; prototype replacement/deletion has no virtual resurrection; restore the original descriptor for later assertions.
- Private accepted-depth endpoint constructed with coherent reciprocal links, overdeep links, duplicate/missing backlink, wrong parent kind, bad IDs, leaf-with-children and reciprocal cycles. Check every admitted-work boundary and unchanged DOM; compare small selected paths with large unrelated arenas without charging/scanning the latter.
- A compact Page/worker load-click witness can move a retained visible branch and a hidden branch through document/fragment/template roots, gate literal status/color/title checks on exact booleans, and assert unchanged IDs. The getter itself causes no render invalidation; existing mutations and rendering remain the tested path. No fixture is authored in this preparation.

There is no ordinary-tree semantic blocker. The remaining preimplementation decisions are the exact shared traversal seam and its unchanged getRootNode charge contract, plus a fresh metadata/constant ledger after equality's outcome is known. Genuine shadow semantics require a separate representation first.
