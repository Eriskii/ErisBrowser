import hashlib,json,os,subprocess,sys,time
from pathlib import Path
A=Path(__file__).resolve().parent;W=A/'worktree';label,start=sys.argv[1:]
argv=[sys.executable,'-m','unittest','discover','-s',start,'-p','test_*.py','-v']
log=A/'validation'/(label+'.log');t=time.monotonic()
with log.open('xb') as f:r=subprocess.run(argv,cwd=W,env={**os.environ,'PYTHONDONTWRITEBYTECODE':'1'},stdout=f,stderr=subprocess.STDOUT)
row={'command':argv,'exit':r.returncode,'elapsed_seconds':time.monotonic()-t,'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
log.with_suffix('.json').write_text(json.dumps(row,indent=2)+'\n');print(json.dumps(row));print(log.read_text()[-5000:]);sys.exit(r.returncode)
