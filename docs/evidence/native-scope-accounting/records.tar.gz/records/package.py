from pathlib import Path
import hashlib,json,re,gzip,tarfile,io,subprocess
B=Path(__file__).resolve().parent;W=B/'worktree';D=W/'docs/evidence/native-scope-accounting';D.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def data(x):return (json.dumps(x,indent=2)+'\n').encode()
def load(p):return json.loads((B/p).read_text())
for name in ['bridge-188-1','native-full-188-2','native-clippy-188-final','fmt-final']:
 r=load('validation/'+name+'.json');assert r['exit']==0;assert sha((B/'validation'/r['log']).read_bytes())==r['sha256']
count=sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',(B/'validation/native-full-188-2.log').read_text())));assert count==2145
paths=sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()));paths=[p for p in paths if not p.startswith('docs/evidence/')]
entries={};sources=[]
for path in paths:
 b=(W/path).read_bytes();sources.append({'path':path,'bytes':len(b),'sha256':sha(b)});entries['source/'+path]=b
(B/'final-source.json').write_bytes(data(sources))
for p in sorted(B.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(B)
 if rel.parts[0]=='worktree' or '__pycache__' in rel.parts:continue
 entries['records/'+str(rel)]=p.read_bytes()
items=[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(entries.items())]
archive=D/'records.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name,b in sorted(entries.items()):
    i=tarfile.TarInfo(name);i.size=len(b);i.mode=0o644;tf.addfile(i,io.BytesIO(b))
index={'schema':1,'base_commit':'da2d75b618159bfa9d3e6ef95d5fb67424bd8c88','archive':{'path':'records.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'files':len(items),'payload_bytes':sum(i['bytes'] for i in items),'members':items};(D/'index.json').write_bytes(data(index))
summary={'schema':1,'checkpoint':'Native coordinate-scope pixel accounting','base_commit':index['base_commit'],'scope':'Only PushClip/PopClip/PushFixed/PopFixed stop reserving full-frame CPU pixel work. Original/lowered command slots, nesting and complete validation remain. Primitives and opacity markers retain full-frame reserves.','limits_raised':False,'package':{'path':'native-scope-accounting/index.json','sha256':sha((D/'index.json').read_bytes()),'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes']},'record_paths':'records/ and source/ members inside the archive','validation':{'rust':'1.88.0','bridge_groups':69,'full_native_tests':2145,'ignored_confinement_tests_included':True,'strict_clippy':'validation/native-clippy-188-final.json','formatting':'validation/fmt-final.json','discovery':'validation/discovery.json','full_suite':'validation/native-full-188-2.json'},'page_witness':{'construction':'Page::from_html; no network load','size':[512,512],'clip_pairs':8,'fixed_pairs':1,'rectangles':2,'original_commands':20,'old_pixel_reserve':5242880,'new_pixel_reserve':524288,'unchanged_pixel_limit':4194304,'comparison':'Complete native-plan CPU interpretation and Canvas both equal a literal white target with red32x32 at16,16 and blue16x16 at64,16.'},'coverage':['fixed escape and caller clip restoration across phases','original256 commands and mixed32 scope exact/one-over limits','malformed and hidden invalid scopes','Rect/Image/Line full-area charges across phases','empty zero/unit/partial opacity reserves unchanged','shared glyph remainder and late-phase precharge','already admitted compact/scoped encoded plans remain identical'],'retained_failure':{'record':'validation/native-full-188-1.json','cause':'Existing zoom test expected CPU fallback for a scene that now admits. Updated only its expectation to successful three-phase native preparation, retaining complete CPU pixel comparison and the unchanged limit.','correction':'zoom-test-correction/receipt.json'},'production_changed_paths':['src/graphics/raster_bridge/native.rs'],'gpu_changes':False,'gpu_execution_this_increment':False,'security_or_performance_claim':False,'preceding_checkpoint':{'commit':'da2d75b618159bfa9d3e6ef95d5fb67424bd8c88','all_nine_CI_jobs_successful':True,'CI':'vulkan-native-opacity-ci.json','publication_review':'vulkan-native-opacity-publication-review.json'},'remaining':'General native admission, transparent group compositing, complete web compatibility, production security and Chromium-relative performance remain unfinished.'};(W/'docs/evidence/native-scope-accounting.json').write_bytes(data(summary));print(json.dumps({'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes'],'source_paths':len(sources),'summary_sha256':sha((W/'docs/evidence/native-scope-accounting.json').read_bytes())}))
