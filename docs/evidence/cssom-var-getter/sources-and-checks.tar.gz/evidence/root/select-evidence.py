from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent.parent


def bind(path):
    data = path.read_bytes()
    return {"path": str(path), "bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}


inventory = root / "source-1.json"
sources = json.loads(inventory.read_text())["source_sha256"]
assert len(sources) == 745
for name, sha in sources.items():
    assert bind(root / "worktree" / name)["sha256"] == sha, name
checks = {}
for label in ["native-full-1", "default-full-1", "strict-msrv-1", "strict-current-1",
              "format-check-1", "browser-final-build-1", "references-final-1"]:
    result = json.loads((root / "validation" / (label + ".json")).read_text())
    assert result["exit"] == 0
    assert bind(root / "validation" / result["log"])["sha256"] == result["sha256"]
    checks[label] = result
review = json.loads((root / "root/layout-validation-review.json").read_text())
assert review["status"] == "clear", review
artifacts = {}
for directory in ["before", "raw", "diffs", "tests-before", "plan", "integration",
                  "validation", "reftests-final", "root"]:
    for path in sorted((root / directory).rglob("*")):
        if path.is_file():
            assert not path.is_symlink()
            assert path.name not in ("selection-final.json", "publication-verification.json")
            artifacts[str(path.relative_to(root))] = bind(path)
for path in sorted(root.glob("*")):
    if path.is_file() and path.suffix in (".json", ".py"):
        artifacts[path.name] = bind(path)
for name in ["README.md", "docs/ROADMAP.md", "docs/cssom-var-getter.md"]:
    artifacts["documentation/" + name] = bind(root / "worktree" / name)
selection = {
    "source_inventory": bind(inventory),
    "artifacts": artifacts,
    "max_uncompressed_bytes": 128 * 1024 * 1024,
    "claims": {
        "base": "ccde5c04c1248daf85feac31d73399342a6b1efa",
        "scope": "Refuse ordinary shorthand synthesis from unresolved variable longhands while preserving complete original pending shorthands and actual removal.",
        "source_inputs": 745,
        "new_test_groups": 10,
        "unit_parent_baseline": {"passed": 2, "failed_as_predicted": 6},
        "integration_parent_baseline": {"passed": 0, "failed_as_predicted": 2,
            "initial_pixel_and_hit_controls_passed": True},
        "checks": checks,
        "full_suite_totals": json.loads((root / "root/full-suite-totals.json").read_text()),
        "references": {"pairs": 102, "passed": 102, "parent_identical_pngs": 204,
            "parent_archive_sha256": "a01b37aeb3e620d1154253f78e99dea6e98d6f776cd6b93d8252dae00a5f5ac3"},
        "browser": json.loads((root / "root/final-browser.json").read_text()),
        "parent_ci": json.loads((root / "root/parent-ci-final.json").read_text()),
        "limits": ["Local authored tests, not imported WPT conformance results.",
            "Native pixel witnesses interpret packed plans on CPU; no new GPU or acquired-window observation.",
            "No Chromium comparison, general web compatibility or production-security claim.",
            "Build caches reused; run times are not cold-build measurements.",
            "No new metadata or type fields; no fresh allocator or stack measurement."]
    }
}
with (root / "root/selection-final.json").open("x") as stream:
    json.dump(selection, stream, indent=2)
    stream.write("\n")
print(json.dumps({"sources": len(sources), "artifacts": len(artifacts)}))
