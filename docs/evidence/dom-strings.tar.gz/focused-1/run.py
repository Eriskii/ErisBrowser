import os, json, pathlib, subprocess, time, hashlib
out=pathlib.Path(__file__).parent
cwd='/tmp/eris-dom-string-1/worktree'
env=os.environ.copy()
env.update(CARGO_BUILD_JOBS='2',CARGO_HOME='/tmp/eris-vulkan-browser-cargo-home',RUSTUP_HOME='/tmp/eris-vulkan-rustup',CARGO_TARGET_DIR='/tmp/eris-dom-own-properties-1/target')
env['PATH']='/tmp/eris-vulkan-rustup/toolchains/1.88.0-x86_64-unknown-linux-gnu/bin:'+env['PATH']
checks=[
('storage',['--lib','dom::string']),
('wire-dom-string',['--lib','worker::codec::tests::','dom_string']),
('wire-version',['--lib','worker::codec::tests::four_byte_wire_version']),
('wire-large-scalar',['--lib','worker::codec::tests::expanded_dom_character_data']),
('script-exact-dom',['--lib','script::tests::exact_dom_']),
('script-strict-html',['--lib','script::tests::strict_script_html_']),
('pi-exact-accessors',['--lib','character_data_accessors_preserve_host_supplied_exact_units']),
('pi-callback-boundary',['--lib','exact_data_method_callbacks_run_before_fresh_scalar_boundary_check']),
('page-inline-source',['--lib','inline_source_joins_exact_units']),
('page-inline-svg',['--lib','inline_svg_serialization_preserves_pair_split']),
('browser-unpaired-editor',['--bin','eris-browser','nonscalar_textarea_cannot_enter_or_retain']),
('browser-paired-editor',['--bin','eris-browser','textarea_editor_decodes_pairs']),
('bootstrap',['--lib','bootstrap']),
]
# Cargo accepts one test filter; the shared substring selects the five wire string groups.
checks[1]=('wire-dom-string',['--lib','dom_string_'])
results=[]
for label,args in checks:
    cmd=['cargo','test','--offline']+args+['--','--nocapture']
    log=out/(label+'.log')
    start=time.monotonic()
    with log.open('wb') as f:r=subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT)
    record={'label':label,'command':cmd,'exit_code':r.returncode,'seconds':round(time.monotonic()-start,3),'log':log.name,'sha256':hashlib.sha256(log.read_bytes()).hexdigest()}
    results.append(record)
    (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(record),flush=True)
    if r.returncode:raise SystemExit(r.returncode)
