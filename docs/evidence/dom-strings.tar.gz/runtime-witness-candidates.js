// FUTURE exact-JS-path candidates, not foundation acceptance tests.
// Each named function gets a fresh realm in each mode. Never executed here.
// https://webidl.spec.whatwg.org/#es-DOMString
// https://dom.spec.whatwg.org/#interface-characterdata
function domUnitsEqual(value, expected) {
  if (value.length !== expected.length) throw new Error('unit length');
  for (let i = 0; i < expected.length; i++) {
    if (value.charCodeAt(i) !== expected[i]) throw new Error('unit value');
  }
}
var domStringFutureCases = {
  character_data_preserves_each_kind: function () {
    const input = 'A\uD800B\uDC00';
    const nodes = [new Text(input), new Comment(input), new ProcessingInstruction('probe', input)];
    for (let i = 0; i < nodes.length; i++) {
      const node = nodes[i]; domUnitsEqual(node.data, [65, 55296, 66, 56320]);
      if (node.length !== 4) throw new Error('length');
      const copy = node.cloneNode(false);
      if (copy === node) throw new Error('clone identity');
      node.data = 'changed'; domUnitsEqual(copy.data, [65, 55296, 66, 56320]);
      domUnitsEqual(JSON.parse(JSON.stringify(copy.data)), [65, 55296, 66, 56320]);
    }
    return true;
  },
  mutation_roundtrip_and_cross_node_concatenation: function () {
    const text = new Text('\uD83E\uDD80');
    text.deleteData(1, 1); domUnitsEqual(text.data, [55358]);
    text.appendData('\uDD80'); domUnitsEqual(text.data, [55358, 56704]);
    const e = document.createElement('div'), high = new Text('\uD83E');
    const span = document.createElement('span'), low = new Text('\uDD80');
    span.append(low); e.append(high, new Comment('ignored'), span);
    domUnitsEqual(e.textContent, [55358, 56704]);
    domUnitsEqual(high.data, [55358]); domUnitsEqual(low.data, [56704]);
    return true;
  },
  js_html_serialization_is_not_display_projection: function () {
    const e = document.createElement('div');
    e.append(new Text('\uD800'));
    domUnitsEqual(e.innerHTML, [55296]);
    e.append(new Comment('\uDC00'));
    domUnitsEqual(e.innerHTML, [55296, 60, 33, 45, 45, 56320, 45, 45, 62]);
    return true;
  }
};
