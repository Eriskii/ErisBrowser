import hashlib, io, json, os, re, tarfile
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def check(label, expected=None):
    path = BASE / 'validation' / (label + '.json')
    result = json.loads(path.read_text())
    if expected is not None:
        assert result['exit'] == expected
    return result
def totals(label):
    text = (BASE / 'validation' / (label + '.log')).read_text()
    rows = re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return [sum(int(row[n]) for row in rows) for n in range(3)]

comparisons = json.loads((BASE / 'compatibility-comparison.json').read_text())
assert all(not row['cases_changes'] and not row.get('controls_changes') for row in comparisons)
assert totals('full-default-188-final-2') == [1552, 0, 0]
assert totals('full-native-198-final') == [1675, 0, 0]
summary = {
    'kind': 'Exact DOM string storage and consumer foundation',
    'base_commit': '7416797e9cee1ce9b4caa41efd3076307e6b9b72',
    'scope': 'Canonical Scalar/Units character data, ERWA transport, exact host-supplied reads/clones, explicit display/source/editor boundaries. JavaScript producer migration remains open.',
    'source': json.loads((BASE / 'main-source-final.json').read_text()),
    'release': json.loads((BASE / 'release.json').read_text()),
    'final_validation': {label: check(label, 0) for label in [
        'full-default-188-final-2', 'full-native-198-final',
        'clippy-native-198-2', 'clippy-presenter-188-1',
        'format-198-final', 'release-adapter-188-1',
    ]},
    'tests': {'default': 1552, 'native': 1675, 'new_groups': 32,
              'focused_unique': 55, 'focused_executions': 56, 'failed': 0, 'ignored': 0},
    'headers_rust_188_64bit': {'old_string': 24, 'dom_string': 32,
                             'old_node_kind': 96, 'node_kind': 96, 'old_node': 136, 'node': 136},
    'raw_bootstrap': {'remaining_work': 8246, 'charged_bytes': 1777574,
                      'objects': 673, 'capacity': 673, 'native': 321, 'legacy_prototypes': 25},
    'compatibility': comparisons,
    'case_modes_compared': sum(row['total'] for row in comparisons),
    'controls_compared': sum(row.get('controls_total', 0) for row in comparisons),
    'retained_attempts': {
        'cli_dump': check('full-default-188-1', 101),
        'fixed_slice_lint': check('clippy-native-198-1', 101),
        'date_fixture_prerequisite': check('full-default-188-final', 101),
        'date_isolated_unchanged': check('date-eof-isolated-188-1', 0),
        'note': 'Original CLI expectation preserved by scalar Debug formatting. Fixed-size slice cleanup preserves bytes. Date prerequisite failure did not log capture Result; exact cause unproven. Date source, deadline and assertions unchanged; isolated and complete final runs passed.',
    },
    'boundaries': [
        'All eight original CharacterData standards-success expectations for final unmatched data remain unmet; their terminal Unsupported observations are unchanged.',
        'Two PI host-prototype mutation expectations remain unmet.',
        'No Chromium comparison or new GPU performance measurement.',
        'Complete web compatibility, production security, unit-aware native editing, full DOMString production and mutation reactions remain incomplete.',
    ],
}
(BASE / 'result.json').write_text(json.dumps(summary, indent=2) + '\n')
files = []
for directory, dirs, names in os.walk(BASE):
    dirs[:] = sorted(d for d in dirs if d not in {'worktree', '__pycache__', '.git'})
    for name in sorted(names):
        path = Path(directory) / name
        if path == BASE / 'eris-js' or path.is_symlink():
            continue
        files.append(path)
inventory = [{'path': str(path.relative_to(BASE)), 'bytes': path.stat().st_size,
              'sha256': sha(path)} for path in files]
manifest = (json.dumps({'files': inventory}, indent=2) + '\n').encode()
archive = ROOT / 'docs/evidence/dom-strings.tar.gz'
with tarfile.open(archive, 'w:gz') as tar:
    for path in files:
        tar.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
    entry = tarfile.TarInfo('archive-manifest.json')
    entry.size = len(manifest)
    tar.addfile(entry, io.BytesIO(manifest))
with tarfile.open(archive, 'r:gz') as tar:
    for row in inventory:
        data = tar.extractfile(row['path']).read()
        assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
summary['archive'] = {'path': archive.name, 'bytes': archive.stat().st_size,
                      'sha256': sha(archive), 'files': len(files), 'manifest_verified': True}
(ROOT / 'docs/evidence/dom-strings.json').write_text(json.dumps(summary, indent=2) + '\n')
print(json.dumps({'archive': summary['archive'], 'cases': summary['case_modes_compared'],
                  'controls': summary['controls_compared']}))
