from pathlib import Path
p=Path('/tmp/eris-dom-string-1/worktree/src/dom.rs');s=p.read_text().replace('pub use string::{DomString, DomUnits};','pub use string::{DomScalars, DomString, DomUnits};')
a=s.index('\n#[derive(Debug, Clone)]\npub struct Node {')
s=s[:a]+'''
/// Allocation-free common text-content shapes shared with script admission.
pub(crate) enum TextContentShape<'a> {
    Empty,
    Single(&'a DomString),
    Tree,
}

enum TextSegments<'a> {
    Empty,
    One(&'a DomString),
    Many(Vec<&'a DomString>),
}
impl TextSegments<'_> {
    fn as_slice(&self) -> &[&DomString] {
        match self {
            Self::Empty => &[],
            Self::One(text) => std::slice::from_ref(text),
            Self::Many(texts) => texts,
        }
    }
    fn scalar_output(&self, maximum: usize, replace: bool, truncate: bool) -> Result<String, DomDataError> {
        if let Self::Empty = self { return Ok(String::new()); }
        if let Self::One(text) = self
            && let Some(text) = text.scalar() {
            let length = if text.len() <= maximum { text.len() }
                else if truncate { floor_boundary(text, maximum) }
                else { return Err(DomDataError::LimitExceeded); };
            let mut output = String::new();
            output.try_reserve_exact(length).map_err(|_| DomDataError::AllocationFailed)?;
            output.push_str(&text[..length]);
            return Ok(output);
        }
        string::scalar_from_units(self.as_slice().iter().flat_map(|text| text.units()), maximum, replace, truncate)
    }
}
''' +s[a:]
a=s.index('    /// Bounded replacement projection for presentation.')
s=s[:a]+'''    pub(crate) fn text_content_shape(&self, id: NodeId) -> Result<TextContentShape<'_>, DomDataError> {
        let node = self.nodes.get(id).ok_or(DomDataError::InvalidNode)?;
        if self.nodes.len() > MAX_NODES { return Err(DomDataError::LimitExceeded); }
        match &node.kind {
            NodeKind::Text(text) | NodeKind::Comment(text) | NodeKind::ProcessingInstruction { data: text, .. } => {
                if !node.children.is_empty() { return Err(DomDataError::InvalidData); }
                Ok(TextContentShape::Single(text))
            }
            NodeKind::Document | NodeKind::DocumentFragment { .. } | NodeKind::Element(_) => {
                if node.children.is_empty() { return Ok(TextContentShape::Empty); }
                if let [child] = node.children.as_slice() {
                    if *child == id { return Err(DomDataError::InvalidData); }
                    let child = self.nodes.get(*child).ok_or(DomDataError::InvalidNode)?;
                    if let NodeKind::Text(text) = &child.kind {
                        if !child.children.is_empty() { return Err(DomDataError::InvalidData); }
                        return Ok(TextContentShape::Single(text));
                    }
                }
                Ok(TextContentShape::Tree)
            }
            NodeKind::Doctype(_) => {
                if !node.children.is_empty() { return Err(DomDataError::InvalidData); }
                Ok(TextContentShape::Empty)
            }
        }
    }

''' +s[a:]
# Presentation/strict/projection share the fast scalar copy.
s=s.replace('''            .and_then(|segments| {
                string::scalar_from_units(
                    segments.iter().flat_map(|text| text.units()),
                    MAX_TEXT,
                    true,
                    true,
                )
            })''','''            .and_then(|segments| segments.scalar_output(MAX_TEXT, true, true))''',1)
s=s.replace(') -> Result<Vec<&DomString>, DomDataError> {',') -> Result<TextSegments<\'_>, DomDataError> {',1)
a=s.index('        let mut pending = Vec::new();',s.index('    fn text_segments('))
s=s[:a]+'''        let shape = self.text_content_shape(id)?;
        let needed = match &shape {
            TextContentShape::Single(_) if matches!(self.nodes[id].kind,
                NodeKind::Document | NodeKind::DocumentFragment { .. } | NodeKind::Element(_)) => 3,
            _ => 1,
        };
        match shape {
            TextContentShape::Empty | TextContentShape::Single(_) => {
                if needed > *visits_left { *visits_left = 0; return Err(DomDataError::LimitExceeded); }
                *visits_left -= needed;
                return Ok(match shape {
                    TextContentShape::Empty => TextSegments::Empty,
                    TextContentShape::Single(text) => TextSegments::One(text),
                    TextContentShape::Tree => unreachable!(),
                });
            }
            TextContentShape::Tree => {}
        }
''' +s[a:]
s=s.replace('        Ok(segments)\n    }','        Ok(TextSegments::Many(segments))\n    }',1)
s=s.replace('''        string::scalar_from_units(
            segments.iter().flat_map(|text| text.units()),
            maximum,
            false,
            false,
        )''','''        segments.scalar_output(maximum, false, false)''',1)
s=s.replace('''        string::scalar_from_units(
            segments.iter().flat_map(|text| text.units()),
            maximum,
            true,
            false,
        )''','''        segments.scalar_output(maximum, true, false)''',1)
s=s.replace('let units = segments.iter().flat_map(|text| text.units());','let units = segments.as_slice().iter().flat_map(|text| text.units());',1)
p.write_text(s)
