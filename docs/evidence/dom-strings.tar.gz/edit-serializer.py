from pathlib import Path
p=Path('/tmp/eris-dom-string-1/worktree/src/dom.rs');s=p.read_text();a=s.index('    pub fn outer_html(');b=s.index('    fn push_text(',a);part=s[a:b]
part=part.replace('let mut out = String::new();','let mut out = SerializedText::default();',1)
part=part.replace('push_serialized(&mut out, text);','out.push_units(text.units());').replace('push_serialized(&mut out, data);','out.push_units(data.units());')
part=part.replace('escape_serialized(&mut out, text, false);','escape_serialized_units(&mut out, text.units(), false);')
part=part.replace('        out\n    }','        out.finish()\n    }')
s=s[:a]+part+s[b:]
a=s.index('fn push_serialized(');b=s.index('fn floor_boundary(',a)
s=s[:a]+'''/// Bounded presentation output with one pending high unit. Keeping that state
/// across pieces preserves a pair split across adjacent Text nodes; markup
/// naturally ends a pending pair. No exact source payload is changed.
#[derive(Default)]
struct SerializedText {
    output: String,
    high: Option<u16>,
    failed: bool,
}
impl SerializedText {
    fn len(&self) -> usize { self.output.len() }
    fn emit(&mut self, value: char) -> bool {
        if self.failed || value.len_utf8() > MAX_TEXT.saturating_sub(self.output.len()) {
            return false;
        }
        if self.output.try_reserve(value.len_utf8()).is_err() {
            self.failed = true;
            return false;
        }
        self.output.push(value);
        true
    }
    fn unit(&mut self, unit: u16) -> bool {
        if let Some(high) = self.high.take() {
            if (0xdc00..=0xdfff).contains(&unit) {
                let value = 0x10000 + (((high as u32) - 0xd800) << 10) + (unit as u32 - 0xdc00);
                return self.emit(char::from_u32(value).unwrap());
            }
            if !self.emit(char::REPLACEMENT_CHARACTER) { return false; }
        }
        match unit {
            0xd800..=0xdbff => { self.high = Some(unit); true }
            0xdc00..=0xdfff => self.emit(char::REPLACEMENT_CHARACTER),
            _ => self.emit(char::from_u32(unit as u32).unwrap()),
        }
    }
    fn push_units(&mut self, units: impl Iterator<Item = u16>) {
        for unit in units {
            if !self.unit(unit) { break; }
        }
    }
    fn finish(mut self) -> String {
        if self.high.take().is_some() { self.emit(char::REPLACEMENT_CHARACTER); }
        self.output
    }
}
fn push_serialized(out: &mut SerializedText, text: &str) {
    out.push_units(text.encode_utf16());
}
fn escape_serialized(out: &mut SerializedText, text: &str, attribute: bool) {
    escape_serialized_units(out, text.encode_utf16(), attribute);
}
fn escape_serialized_units(out: &mut SerializedText, units: impl Iterator<Item = u16>, attribute: bool) {
    for unit in units {
        if out.len() >= MAX_TEXT { break; }
        match unit {
            38 => push_serialized(out, "&amp;"),
            0xa0 => push_serialized(out, "&nbsp;"),
            60 => push_serialized(out, "&lt;"),
            62 => push_serialized(out, "&gt;"),
            34 if attribute => push_serialized(out, "&quot;"),
            _ => { out.unit(unit); }
        }
    }
}
''' +s[b:]
p.write_text(s)
