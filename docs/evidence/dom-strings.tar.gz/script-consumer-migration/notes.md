# Script consumer migration notes

Only worktree `src/script.rs` is owned by layout. No compiler or runtime execution by this agent. The original source is retained as script-before.rs. Root authorized implementation and the oversized-HTML behavior correction.

Exact getters now gather UTF-16 directly, prepay traversal/output/Rc copies, and normalize textarea CR/CRLF in place without replacing isolated units. Node accessor prototype placement remains future work. Legacy DOM setters and their intentionally lossy test remain unchanged.

clone_dom_shallow and import_node publish owned exact DomString payloads. Actual reached Node Vec growth is typed and paid before copying/publishing; cloning does not reapply PI creation validation to mutated data. Existing caps and normal node/descriptor behavior remain unchanged. Deep clone/import are not claimed transactional on a later resource refusal; their previous partial allocation model remains.

The old recursive serializer constructed child Strings, then silently stopped appending when their UTF-8 sum exceeded MAX_STRING. It could return only `kept` when a later child exceeded that limit. Root explicitly approved replacing that edge with terminal resource refusal. The new serializer keeps ordinary scalar formatting/template/depth behavior and the same numeric cap, plans before allocation, carries surrogate pairs across adjacent text output, and returns terminal Unsupported for a final non-scalar serialized string. Exact JS serialization is a later increment; this code does not project replacement glyphs into an observable HTML string.

Precompile peer review found that String.into() used an implicitly growing UTF16 Vec after admission. Corrected to an explicit fallible exact reserve with the already charged size. Peer also found reached depth-limit calls before their work debit in serialization/import; ticks now precede those retained guards. No failures or execution outcomes are inferred from those source findings.

Six new tests cover exact getters and split CRLF, unrelated-arena fast reads, exact clone/import of Text/Comment/PI, typed growth one-short refusal before clone publication, scalar/pair/template serialization, and unpaired/oversized terminal refusal. Core requested empty/single-Text fastpath integration before the first coordinated compile; source-ready will bind that final version.

Shared TextContentShape is integrated with a fixed 16-work classification admission. Empty and single-Text containers avoid whole-arena scratch; the existing simple-read group now checks CharacterData, single-Text, and empty-container outputs with 1,000 unrelated comments. The first attempted formatting command mistakenly specified Rust 2021 and rejected existing let-chains without changing source; Rust 2024 formatting then succeeded. No compiler/runtime was executed by layout.
