# Exact DOM string storage

Text, Comment and ProcessingInstruction data now use an opaque `DomString`
with one canonical payload. Scalar strings retain UTF-8 storage. Strings with
an unpaired surrogate retain exact UTF-16 units. There is no implicit `Display`
or `Deref<str>` conversion and no second cached representation. PI targets,
element names and attributes retain their existing scalar storage.

The retained DOM payload charge is UTF-8 bytes for scalar data or two bytes per
stored UTF-16 unit. Checked owned creation and replacement move admitted data;
replacement accounts for the old payload before checking the shared limit.
Detached nodes remain included. Snapshot admission recomputes the ledger.
The 32 MiB document payload and existing node and script limits remain unchanged.

The worker protocol moves from ERW9 to ERWA. Character data carries a scalar or
UTF-16 tag followed by its byte or unit count. UTF-16 payloads use little-endian
units. The decoder checks the tag, length, remaining frame, shared DOM allowance
and canonical representation before allocating. A Units payload containing only
scalar sequences is rejected. Old protocol frames are rejected. The independent
EWB1 raster capture format does not contain DOM data and is unchanged.

Data and length accessors, selected existing text readers and cloning can read
exact data supplied by the host or transport. Selected descendant text units
are joined before decoding, so a pair can cross Text nodes. These paths do not
establish complete Node attribute descriptors or children-changed reactions.

Presentation explicitly replaces unpaired units without changing stored data.
CSS direct-child text and SVG text aggregate before replacement. HTML used for
inline SVG carries pending high units across adjacent serialized Text pieces;
actual markup separates them. The layout engine still processes individual
text runs, so this is not a claim of complete cross-node Unicode shaping.

The inline JavaScript loader requires a scalar aggregate and reports unsupported
nonscalar source before execution. JavaScript HTML serialization also explicitly
refuses a final unpaired sequence pending an exact-unit serializer. Its bounded
streaming implementation reports resource failure for oversized output instead
of silently dropping later child pieces. Existing serialization coverage gaps
remain separate from this storage change.

The native editor still owns a UTF-8 buffer. A textarea whose aggregate cannot
be represented there cannot enter or retain that editor, including while an edit
acknowledgement is pending. This avoids replacing preserved units elsewhere in
the value when the UI submits a whole-string edit. Unit-aware native editing is
unfinished. Form output and native titles remain scalar presentation/encoding
boundaries, distinct from JavaScript DOMString values.

This foundation does not yet enable exact lone-surrogate input across the
JavaScript constructors, setters and mutation methods. Older legacy write paths
can still project to scalar strings; newer CharacterData operations still refuse
unpaired final data. The existing eight unmet standards-success expectations are
retained for the following runtime migration. Full web compatibility, production
security and Chromium performance parity are not established.

Normative references: [DOMString conversion](https://webidl.spec.whatwg.org/#es-DOMString),
[CharacterData](https://dom.spec.whatwg.org/#interface-characterdata),
[HTML fragment serialization](https://html.spec.whatwg.org/multipage/parsing.html#serialising-html-fragments)
and [CSS input preprocessing](https://drafts.csswg.org/css-syntax-3/#input-preprocessing).
