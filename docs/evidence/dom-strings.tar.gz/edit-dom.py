from pathlib import Path
p=Path('/tmp/eris-dom-string-1/worktree/src/dom.rs');s=p.read_text()
s=s.replace('use std::collections::{BTreeMap, BTreeSet};','use std::collections::{BTreeMap, BTreeSet};\n\nmod string;\npub use string::{DomString, DomUnits};')
s=s.replace('    Text(String),\n    Comment(String),\n    Doctype(Doctype),\n    ProcessingInstruction { target: String, data: String },','    Text(DomString),\n    Comment(DomString),\n    Doctype(Doctype),\n    ProcessingInstruction { target: String, data: DomString },',1)
s=s.replace('    InvalidNode,\n    LimitExceeded,','    InvalidNode,\n    InvalidData,\n    LimitExceeded,',1)
s=s.replace('NodeKind::Text(s) | NodeKind::Comment(s) => s.len(),','NodeKind::Text(s) | NodeKind::Comment(s) => s.stored_bytes(),')
s=s.replace('NodeKind::Text(value) | NodeKind::Comment(value) => value.len(),','NodeKind::Text(value) | NodeKind::Comment(value) => value.stored_bytes(),')
s=s.replace('NodeKind::ProcessingInstruction { target, data } => target.len() + data.len(),','NodeKind::ProcessingInstruction { target, data } => target.len() + data.stored_bytes(),')
a=s.index('    pub fn text_content(&self, id: NodeId) -> String {');b=s.index('    /// HTML style\'s exact type check',a)
s=s[:a]+'''    /// Bounded replacement projection for presentation. Script DOMString reads
    /// must use the exact-unit or strict-scalar helper below instead.
    pub fn text_content(&self, id: NodeId) -> String {
        let mut visits = MAX_NODES * 2;
        self.text_segments(id, &mut visits)
            .and_then(|segments| {
                string::scalar_from_units(
                    segments.iter().flat_map(|text| text.units()),
                    MAX_TEXT,
                    true,
                    true,
                )
            })
            .unwrap_or_default()
    }

    // Scratch is bounded by the arena size: two NodeId/reference buffers and a
    // visited byte per node. Script callers must admit that typed scratch before
    // entering these allocation-bearing helpers. No callbacks occur inside.
    fn text_segments(
        &self,
        id: NodeId,
        visits_left: &mut usize,
    ) -> Result<Vec<&DomString>, DomDataError> {
        if id >= self.nodes.len() {
            return Err(DomDataError::InvalidNode);
        }
        if self.nodes.len() > MAX_NODES {
            return Err(DomDataError::LimitExceeded);
        }
        let mut pending = Vec::new();
        let mut seen = Vec::new();
        let mut segments = Vec::new();
        pending.try_reserve_exact(self.nodes.len()).map_err(|_| DomDataError::AllocationFailed)?;
        seen.try_reserve_exact(self.nodes.len()).map_err(|_| DomDataError::AllocationFailed)?;
        segments.try_reserve_exact(self.nodes.len()).map_err(|_| DomDataError::AllocationFailed)?;
        seen.resize(self.nodes.len(), false);
        pending.push(id);
        while let Some(next) = pending.pop() {
            if *visits_left == 0 {
                return Err(DomDataError::LimitExceeded);
            }
            *visits_left -= 1;
            let Some(node) = self.nodes.get(next) else {
                return Err(DomDataError::InvalidNode);
            };
            if seen[next] {
                return Err(DomDataError::InvalidData);
            }
            seen[next] = true;
            match &node.kind {
                NodeKind::ProcessingInstruction { data, .. } if next == id => segments.push(data),
                NodeKind::Text(text) | NodeKind::Comment(text)
                    if next == id || matches!(node.kind, NodeKind::Text(_)) => segments.push(text),
                NodeKind::Document | NodeKind::DocumentFragment { .. } | NodeKind::Element(_) => {
                    if node.children.len() > *visits_left
                        || node.children.len() > self.nodes.len().saturating_sub(pending.len()) {
                        return Err(DomDataError::LimitExceeded);
                    }
                    *visits_left -= node.children.len();
                    pending.extend(node.children.iter().rev().copied());
                }
                _ => {}
            }
        }
        Ok(segments)
    }

    /// Exact concatenation before scalar validation; pairs may cross Text nodes.
    pub(crate) fn text_content_scalar_bounded(
        &self,
        id: NodeId,
        maximum: usize,
        visits_left: &mut usize,
    ) -> Result<String, DomDataError> {
        let segments = self.text_segments(id, visits_left)?;
        string::scalar_from_units(
            segments.iter().flat_map(|text| text.units()), maximum, false, false,
        )
    }

    pub(crate) fn text_content_units_bounded(
        &self,
        id: NodeId,
        maximum: usize,
        visits_left: &mut usize,
    ) -> Result<Vec<u16>, DomDataError> {
        let segments = self.text_segments(id, visits_left)?;
        let units = segments.iter().flat_map(|text| text.units());
        let mut length = 0usize;
        for _ in units.clone() {
            length = length.checked_add(1).filter(|length| *length <= maximum)
                .ok_or(DomDataError::LimitExceeded)?;
        }
        let mut output = Vec::new();
        output.try_reserve_exact(length).map_err(|_| DomDataError::AllocationFailed)?;
        output.extend(units);
        Ok(output)
    }

    /// Direct child text for CSS input: combine units before replacing isolated
    /// surrogates. Both visits and projected UTF-8 bytes retain explicit bounds.
    pub fn child_text_content_bounded(
        &self,
        id: NodeId,
        bytes_left: &mut usize,
        child_visits_left: &mut usize,
    ) -> Option<String> {
        let node = self.nodes.get(id)?;
        let visits = node.children.len().checked_mul(2)?;
        if visits > *child_visits_left {
            *child_visits_left = 0;
            return None;
        }
        *child_visits_left -= visits;
        let units = node.children.iter().filter_map(|child| {
            match &self.nodes.get(*child)?.kind {
                NodeKind::Text(text) => Some(text.units()),
                _ => None,
            }
        }).flatten();
        let output = string::scalar_from_units(units, (*bytes_left).min(MAX_TEXT), true, false).ok()?;
        *bytes_left -= output.len();
        Some(output)
    }
''' +s[b:]
s=s.replace('| NodeKind::ProcessingInstruction { data: t, .. } => t.len(),','| NodeKind::ProcessingInstruction { data: t, .. } => t.stored_bytes(),')
s=s.replace('self.retained_bytes.saturating_sub(t.len()) + text.len()','self.retained_bytes.saturating_sub(t.stored_bytes()) + text.len()')
s=s.replace('*t = text.to_owned();','*t = text.into();',1)
# Checked owned publication signatures.
s=s.replace('        data: String,\n    ) -> Result<NodeId, DomDataError> {','        data: DomString,\n    ) -> Result<NodeId, DomDataError> {',1)
s=s.replace('.checked_add(data.len())\n            .ok_or(DomDataError::LimitExceeded)?;','.checked_add(data.stored_bytes())\n            .ok_or(DomDataError::LimitExceeded)?;',1)
s=s.replace('        data: String,\n    ) -> Result<(), DomDataError> {','        data: DomString,\n    ) -> Result<(), DomDataError> {',1)
s=s.replace('| Some(NodeKind::ProcessingInstruction { data: text, .. }) => text.len(),','| Some(NodeKind::ProcessingInstruction { data: text, .. }) => text.stored_bytes(),',1)
s=s.replace('.and_then(|bytes| bytes.checked_add(data.len()))','.and_then(|bytes| bytes.checked_add(data.stored_bytes()))',1)
s=s.replace('        if data.len() > MAX_TEXT {','        if data.stored_bytes() > MAX_TEXT {',1)
a=s.index('    pub fn create_doctype(')
s=s[:a]+'''    /// Checked exact storage, moving the already admitted data buffer.
    pub(crate) fn create_text_node_owned(&mut self, data: DomString) -> Result<NodeId, DomDataError> {
        self.create_character_data_owned(data, false)
    }
    pub(crate) fn create_comment_owned(&mut self, data: DomString) -> Result<NodeId, DomDataError> {
        self.create_character_data_owned(data, true)
    }
    fn create_character_data_owned(&mut self, data: DomString, comment: bool) -> Result<NodeId, DomDataError> {
        let bytes = data.stored_bytes();
        if !self.admits_text_node(bytes) {
            return Err(DomDataError::LimitExceeded);
        }
        self.nodes.try_reserve_exact(1).map_err(|_| DomDataError::AllocationFailed)?;
        let id = self.nodes.len();
        self.nodes.push(Node {
            parent: None,
            children: Vec::new(),
            kind: if comment { NodeKind::Comment(data) } else { NodeKind::Text(data) },
        });
        self.retained_bytes += bytes;
        Ok(id)
    }
''' + s[a:]
# Parser-only scalar coalescing; all parser-owned text starts scalar. Unexpected
# pre-existing exact data stays intact and the new scalar is a separate node.
s=s.replace('&& let NodeKind::Text(s) = &mut self.nodes[last].kind\n        {','&& let NodeKind::Text(s) = &mut self.nodes[last].kind\n            && let Some(s) = s.scalar_mut()\n        {')
s=s.replace('kind: NodeKind::Text(text),','kind: NodeKind::Text(text.into()),',1)
s=s.replace('&& let NodeKind::Text(value) = &mut self.doc.nodes[previous].kind\n            {','&& let NodeKind::Text(value) = &mut self.doc.nodes[previous].kind\n                && let Some(value) = value.scalar_mut()\n            {')
# Old scalar-only tests preserve payload pointer and literal assertions.
s=s.replace('NodeKind::Comment(data) => Some(data.as_str()),','NodeKind::Comment(data) => data.scalar(),')
s=s.replace('data.as_ptr(), data_ptr','data.scalar().unwrap().as_ptr(), data_ptr')
s=s.replace('stored.as_ptr(), ptr','stored.scalar().unwrap().as_ptr(), ptr')
s=s.replace('.create_processing_instruction_owned(target, data)','.create_processing_instruction_owned(target, data.into())')
s=s.replace('doc.replace_character_data(id, replacement)','doc.replace_character_data(id, replacement.into())')
s=s.replace('NodeKind::Text(String::new())','NodeKind::Text(DomString::default())')
s=s.replace('"a".repeat(MAX_TEXT))','"a".repeat(MAX_TEXT).into())')
s=s.replace('"a".repeat(MAX_TEXT - 1))','"a".repeat(MAX_TEXT - 1).into())')
s=s.replace('"b".repeat(MAX_TEXT + 1))','"b".repeat(MAX_TEXT + 1).into())')
s=s.replace('create_processing_instruction_owned("x".into(), String::new())','create_processing_instruction_owned("x".into(), DomString::default())')
s=s.replace('replace_character_data(pi, String::new())','replace_character_data(pi, DomString::default())')
p.write_text(s)
