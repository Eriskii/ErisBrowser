from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
R=Path(__file__).resolve().parent;W=R/'worktree';D=W/'docs/evidence/native-rect-accounting'
def sha(b):return hashlib.sha256(b).hexdigest()
def enc(v):return (json.dumps(v,indent=2)+'\n').encode()
def rec(p):return json.loads((R/p).read_text())
for name in ['predecessor-rect-188-1','predecessor-page-188-1','bridge-migration-188-1','bridge-188-1','native-full-188-1','native-clippy-188-1']:
 r=rec('validation/'+name+'.json');assert r['exit']==0 and sha((R/'validation'/r['log']).read_bytes())==r['sha256']
for name,count in [('bridge-188-1',82),('native-full-188-1',2161)]:assert sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',(R/'validation'/(name+'.log')).read_text())))==count
assert all(r['exit']==0 for r in rec('validation/fmt-final.json'))
build=rec('validation/browser-build-1.json');assert build['exit']==0 and build['sources_unchanged'];assert all(sha((W/p).read_bytes())==h for p,h in build['sources'].items())
assert sha((R/'validation'/build['log']).read_bytes())==build['log_sha256']
for p in ['layout/script-source-review.json','test-migration/script-review.json','bridge/layout-review.json']:assert (R/p).is_file()
ci=rec('full-opacity-ci.json');assert ci['conclusion']=='success' and len(ci['jobs'])==9 and all(j['conclusion']=='success' for j in ci['jobs'])
unchanged=rec('unchanged-core-and-presenter.json');assert all(sha((W/r['path']).read_bytes())==r['sha256'] for r in unchanged['files'])
D.mkdir(exist_ok=False)
paths=sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()));paths=[p for p in paths if not p.startswith('docs/evidence/')]
entries={};sources=[]
for p in paths:
 data=(W/p).read_bytes();sources.append({'path':p,'bytes':len(data),'sha256':sha(data)});entries['source/'+p]=data
(R/'final-source.json').write_bytes(enc(sources))
for p in sorted(R.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(R)
 if rel.parts[0]=='worktree' or '__pycache__' in rel.parts:continue
 if p.suffix not in {'.json','.log','.rs','.wgsl','.md','.py','.diff','.txt','.html'}:continue
 entries['records/'+str(rel)]=p.read_bytes()
items=[{'path':p,'bytes':len(b),'sha256':sha(b)} for p,b in sorted(entries.items())];archive=D/'records.tar.gz'
with archive.open('xb') as f:
 with gzip.GzipFile(fileobj=f,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(entries.items()):
    i=tarfile.TarInfo(name);i.size=len(data);i.mode=0o644;tar.addfile(i,io.BytesIO(data))
index={'schema':1,'base_commit':rec('base.json')['base_commit'],'archive':{'path':'records.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'files':len(items),'payload_bytes':sum(i['bytes'] for i in items),'members':items};(D/'index.json').write_bytes(enc(index))
summary={'schema':1,'checkpoint':'Native Rect preblend CPU work reservation','base_commit':index['base_commit'],'scope':'Reserve clipped Rect loop area before glyph preparation; preserve full Image/Line/Opacity charges, complete input validation and all limits. Shared typed coordinates retain per-phase clip/fixed semantics.','renderer_limits_raised':False,'package':{'path':'native-rect-accounting/index.json','sha256':sha((D/'index.json').read_bytes()),'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes']},'record_paths':'records/ and source/ archive members; absolute paths identify original local inputs','baseline':{'receipt':'baseline/receipt.json','synthetic_run':'validation/predecessor-rect-188-1.json','Page_run':'validation/predecessor-page-188-1.json','actual_native_refusal':'CpuPaintBudget','old_rect_cpu':10485760,'unchanged_cpu_limit':4194304,'new_rect_cpu':9600,'viewport':[512,512],'rectangles':40,'rectangle_size':[20,12],'core_draws':41,'core_gpu_invocations':539648,'core_gpu_buffer_bytes':2107664},'validation':{'rust':'1.88.0','bridge_tests':82,'new_rect_groups':6,'full_native_tests':2161,'ignored_confinement_tests_included':True,'new_Page_worker_groups':2,'loaded_Page_and_worker_each_test_both_click_phases':True,'each_full_canvas_pixels':262144,'observed_ids_retained':44,'parent_child_graph_retained':True,'changed_pixels_per_click':240,'strict_clippy':'validation/native-clippy-188-1.json','formatting':'validation/fmt-final.json','actual_test_identity_discovery':'validation/discovery.json'},'test_migrations':{'receipt':'test-migration/receipt.json','independent_review':'test-migration/script-review.json','scope':'Existing exact-budget witnesses use full-frame transparent Rects. Genuine smaller/clipped Rect fees change; pixels and other primitive charges remain.','registration':'registration/receipt.json','formatting':'formatting/receipt.json'},'implementation_review':'layout/script-source-review.json','new_test_review':'bridge/layout-review.json','unchanged_core_shaders_and_presenter':'unchanged-core-and-presenter.json','browser':{'release_build':'validation/browser-build-1.json','binary':build['binary'],'example':'examples/vulkan-small-boxes.html','new_gpu_execution':False,'new_window_execution':False},'executed_unexpected_failures':[],'preceding_checkpoint':{'commit':index['base_commit'],'all_nine_CI_jobs_successful':True,'CI':'full-opacity-ci.json','publication_review':'full-opacity-publication-review.json'},'remaining':'Broader native scene admission, full web compatibility, production security and performance within30% of Chromium remain unfinished.','security_or_performance_claim':False};(W/'docs/evidence/native-rect-accounting.json').write_bytes(enc(summary))
print(json.dumps({'archive':index['archive'],'files':len(items),'payload_bytes':index['payload_bytes'],'source_paths':len(sources),'summary_sha256':sha((W/'docs/evidence/native-rect-accounting.json').read_bytes())}))
