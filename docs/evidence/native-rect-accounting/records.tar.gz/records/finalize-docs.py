from pathlib import Path
import re,json,hashlib,subprocess
R=Path(__file__).resolve().parent;W=R/'worktree'
p=W/'docs/native-rect-accounting.md';s=p.read_text();needle='This increment makes no new GPU execution or acquired-window measurement.';s=s.replace(needle,'''Rust 1.88 passes all82 bridge groups and2,161 native-feature browser tests,
including the ignored confinement checks. The direct Page and confined-worker
witnesses each compare the complete512×512 scene before and after a real click,
retain44 observed node identities and the complete parent/child graph, and
change exactly240 pixels. The resulting plan retains41 draws,539,648 invocations
and2,107,664 GPU bytes. Exact pixel-budget admission and a one-pixel excess are
both checked. Strict Clippy, formatting and the native release build pass.

This increment makes no new GPU execution or acquired-window measurement.''');s=s.replace('all82','all 82').replace('and2,161','and 2,161').replace('complete512','complete 512').replace('retain44','retain 44').replace('exactly240','exactly 240').replace('retains41 draws,539,648','retains 41 draws, 539,648').replace('and2,107,664','and 2,107,664');p.write_text(s)
p=W/'docs/VALIDATION.md';s=p.read_text().replace('# Validation record\n','# Validation record\n\n## Native rectangle accounting\n\n[Precise Rect reservations](native-rect-accounting.md) admit the fixed forty-box\npage with9,600 CPU pixel-work units instead of10,485,760 under the unchanged\n4,194,304 allowance. All82 bridge groups and2,161 native-feature tests pass on\nRust1.88, including direct Page and confined-worker click witnesses, strict\nClippy and formatting. The release browser builds. No shader or GPU limits\nchange; this is CPU preparation and pixel-reference evidence.\n',1);s=s.replace('with9,600','with 9,600').replace('of10,485,760','of 10,485,760').replace('All82','All 82').replace('and2,161','and 2,161').replace('Rust1.88','Rust 1.88');p.write_text(s)
p=W/'README.md';s=p.read_text();needle='Software remains the default and headless path. The\nseparate [raster probe]';assert s.count(needle)==1;s=s.replace(needle,'[Precise rectangle reservations](docs/native-rect-accounting.md) admit more\nsmall-shape scenes under the existing CPU work limits.\nSoftware remains the default and headless path. The\nseparate [raster probe]');p.write_text(s)
modules=[('src/graphics/raster_bridge/tests.rs','graphics::raster_bridge::tests::',21),('src/graphics/raster_bridge/text/tests.rs','graphics::raster_bridge::text::tests::',7),('src/graphics/raster_bridge/native/tests.rs','graphics::raster_bridge::native::tests::',25),('src/graphics/raster_bridge/native/opacity_tests.rs','graphics::raster_bridge::native::tests::opacity_tests::',17),('src/graphics/raster_bridge/native/scope_accounting_tests.rs','graphics::raster_bridge::native::tests::scope_accounting_tests::',6),('src/graphics/raster_bridge/native/rect_accounting_tests.rs','graphics::raster_bridge::native::tests::rect_accounting_tests::',6)]
expected=set()
for source,prefix,count in modules:
 names=re.findall(r'(?m)^#\[test\]\s*\nfn ([A-Za-z_]\w*)\(', (W/source).read_text());assert len(names)==len(set(names))==count;expected.update(prefix+n for n in names)
log=R/'validation/bridge-188-1.log';found=re.findall(r'(?m)^test (graphics::raster_bridge::\S+) \.\.\. ok$',log.read_text());assert len(found)==82 and set(found)==expected
(R/'validation/discovery.json').write_text(json.dumps({'source':'actual successful filtered bridge test log','log':str(log),'log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'distinct_tests':len(found),'expected':sorted(expected),'all_executed_and_passed':True},indent=2)+'\n')
base=json.loads((R/'base.json').read_text())['base_commit'];paths=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'crates/raster-core','Cargo.toml','Cargo.lock','src/presenter'],cwd=W,text=True).splitlines();records=[]
for name in paths:
 a=subprocess.check_output(['git','show',base+':'+name],cwd=W);assert a==(W/name).read_bytes();records.append({'path':name,'sha256':hashlib.sha256(a).hexdigest()})
(R/'unchanged-core-and-presenter.json').write_text(json.dumps({'base_commit':base,'same_current_bytes':True,'files':records,'scope':'Shared core, shaders, root manifest/lock and presenter sources; CPU browser admission alone changes.'},indent=2)+'\n')
print('Bound82 actual test identities and unchanged core/presenter sources; finalized measured documentation.')
