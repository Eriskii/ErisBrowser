# Recommended next increment: Native Rect pixel reservations

Source-only recommendation against published `d25c5d407eb398b4819450d719c4aef42377bed6` and the current, still unpublished full-opacity candidate in `/tmp/eris-vulkan-full-opacity-1/worktree`. This assessment does not presume the candidate's publication or broader validation. No repository source was changed and no compiler, test, browser, renderer or GPU was run for this assessment.

The next useful increment is to replace **only Rect's full-frame CPU pixel reservation** with the existing Canvas pre-blend loop bound. Keep Image, Line and both opacity markers at their current full-frame reservations. Keep every command, scope, font, source, mask, row, CPU/GPU storage and GPU invocation limit. All current browser DrawCommand families already have native lowering after the opacity candidate; this proposal improves admission precision, not drawing-language coverage.

## Concrete blocker and benefit

Native preflight currently counts every Rect/Image/Line/opacity marker in `pixel_work_commands`. Before constructing the font session it debits `frame_area * pixel_work_commands`, against `(frame_area * 16).clamp(1_000_000,32_000_000)`. Thus forty tiny rectangles fail CPU preparation even when their actual painting and GPU dispatch work are small. A single 20×12 rectangle at512×512 reserves262,144 pixels for a240-pixel loop. Browser borders/backgrounds and small controls make this a practical admission obstacle even below the256-command ceiling.

A prospective scene of forty distinct, integer-aligned20×12 opaque Rects at512×512 has the following source-derived numbers; these are not execution results:

| Quantity | Current reservation | Proposed reservation |
|---|---:|---:|
| Rect CPU pixels |10,485,760|9,600|
| Unchanged CPU allowance |4,194,304|4,194,304|
| Original/lowered primitives |40/40|40/40|
| Core draws including clear |41|41|
| Padded GPU work including clear/conversion |539,648|539,648|
| Core planned buffers, no sources/scratch |2,107,664 bytes|2,107,664 bytes|

The GPU figures are `2*512*512 +40*(ceil(20/8)*ceil(12/8)*64)` and `2*512*512*4 +41*256 +16`. The existing adapter refuses before reaching that plan today. No shader, buffer format, arithmetic, compositing, command order or native GPU admission change is needed to admit it under the tighter CPU estimate.

## Exact bound already available

Canvas::rect validates finite geometry, checks positive dimensions, intersects the translated rectangle with the active clip, and charges the full integer loop rectangle **before** radius-dependent coverage or blend's upper-clip rejection:

```
visible = translated_rect.intersect(active_clip)  // same f32 operation order
x0 = max(floor(visible.x), ceil(active_clip.x), 0)
y0 = max(floor(visible.y), ceil(active_clip.y), 0)
x1 = min(ceil(visible.x + visible.width), frame.width)
y1 = min(ceil(visible.y + visible.height), frame.height)
loop_work = max(x1-x0,0) * max(y1-y0,0)
```

`RoundedTiles::prepare_native` already obtains this exact bound before radius handling. Calling it with radius0 for the **reservation calculation only** returns Empty/ZeroRadius and does not allocate, generate coverage, or impose rounded mask dimensions/coverage limits. It therefore supplies the same conservative loop bound for every Rect, regardless of its real radius. The real radius is still validated in the original complete preflight and still passed unchanged to the existing lowering/materialization call. Keep those later rounded masks, rows, sources, extra tile operations and errors unchanged.

The new work calculation intentionally need not skip transparent colors or rectangles within zero-opacity scopes. Charging their geometry is conservative and avoids adding another visibility proof. Geometrically empty/offscreen/clipped rectangles can return zero. Every original field remains validated, including invalid hidden radius/geometry and later commands. Negative/zero radius still has existing Canvas semantics.

Do not debit stored coverage, clipped shader bounds or rounded tile sum instead. The retained `rounded_loop_work_precedes_blend_upper_clip_rejection` witness has loop_work2 but coverage1: reconstructing an f32 endpoint can extend the pre-blend loop by one pixel. Its exact bits are already in rounded_tests.rs. Square opaque rectangles also retain their current upper-bound behavior; this proposal changes no endpoint or pixel.

## Minimal implementation shape

Keep the existing complete structural/input preflight. Add a bounded coordinate-only reservation pass before Session::new, using the shared CoordinateState, not a copied clip/fixed implementation. For each phase, start a fresh state from that phase's actual caller clip and document/viewport offsets. Apply every typed scope in order. For Rect, translate x/y once using state.offset(), retain extents, and obtain the zero-radius loop_work under state.clip(). Sum checked u64 work across all phases.

Preserve `counts.nontext` and all original/lowered command counts. The private full-area count can exclude Rect (rename it to make the meaning explicit); calculate `cpu_nontext = frame_area * full_area_count + rect_loop_work`. Initialize both Ledger.cpu_pixels and the font Session's remaining allowance from this one amount before any glyph rasterization. Do not debit per-Rect work again during lowering. Existing rounded_loop_work statistics still record actual rounded primitives once; their meaning need not expand to all Rects.

The extra traversal is bounded by256 original commands and at most4 phase states, with fixed work per command. It runs geometry arithmetic only, no pixel loop or payload copy. CoordinateState does make a bounded fallible32-scope reservation. Keep one state alive at a time and drop the entire prepass before later lowering/planning; document this new allocation point rather than calling the pass allocation-free. Existing preparation accounting already includes two core metadata envelopes, each with four CoordinateStates and scope arrays, plus rounded partition metadata. Confirm exact lifetime/type coverage during implementation and retain that existing reserve; do not add an unaccounted vector or increase the16MiB quota. A u64 local accumulator and reuse of the existing count field suffice; a per-command metadata cache is unnecessary.

This is a pixel-work bound, not CPU instruction metering or a performance promise. It adds a small bounded geometry pass; whether end-to-end time improves requires later measurement. Since CPU admission becomes less conservative, a formerly early CPU refusal can instead reach an existing mask/source/GPU refusal. Keep that history and do not mislabel a later refusal as a regression of rendering correctness.

## Traps and retained exclusions

* Fixed resets to the caller clip/viewport offset and can escape an empty document clip; it cannot inherit a zero-work conclusion from an earlier clip. Pops restore the saved state. Nested opacity does not change coordinate state.
* Do not reuse this Rect formula for Image: its lower loop bound uses different floor/clip rules. Keep Image and Line unchanged in this increment even though Line currently lowers to Rect.
* Keep both opacity marker reserves, including tiny, zero, unit and empty groups. Cropped GPU scratch does not replace the CPU layer reservation.
* Do not relax rounded mask coverage262,144, per-axis1024, rows65,536 or two-strip rules. A small pixel-work bound does not admit an oversized rounded mask.
* Probe stays unchanged. Full-frame Rects retain their previous full-area charge. GPU work4M, GPU storage16MiB, original/lowered256, mixed scopes32 and1280×1024 viewport remain hard limits.
* Chrome includes generated status text with the page command count. When comparing two browser preparations, fix that text or isolate text.paint_pixels_used; total glyph fees need not match after changing command count. The just-retained full-opacity zoom failure documents this exact trap.

## Bounded validation and browser witness

Six focused source groups should be enough before existing suites:

1. Rect loop bounds for integer/fractional/negative/empty geometry, zero/positive radius and alpha, with the existing loop2/coverage1 literal. Check full pixels and unchanged Plan bytes for already admitted scenes.
2. Clip/Fixed nesting, fixed escape from empty clip, restored offsets, caller clipping and multiple phases. Include hidden malformed source/radius/scope tail refusal; zero work must not skip validation.
3. At512×512, sixteen full-frame transparent Rects reserve exactly4,194,304 CPU pixels while remaining cheap on GPU. A further1×1 Rect exceeds by one pixel and refuses. This deliberately retains a charge for transparent geometry. Keep Image/Line/full opacity boundary tests unchanged.
4. A nonempty real text run shares the reduced remaining allowance across phases, with exact/one-short glyph admission where appropriate. Isolate the glyph debit rather than assuming two different chrome strings have identical glyph areas.
5. Rounded tiling and source/storage boundaries are unchanged. Confirm a shape can still fail mask limits even when CPU geometry fits and that no double pixel debit occurs during materialization. Preserve old private literals before correcting affected Rect-only accounting expectations.
6. A loaded Page of forty absolute20×12 colored boxes in an8×5 grid, no body background and no visible text, supplies a literal full-canvas pattern. Its first existing div can handle a real click changing only that box color/title/body phase; use a div to avoid native button-focus outlines. Retain IDs/no click-created nodes. Require actual native preparation and compare every Canvas pixel. A later root-owned real window can reuse existing host/supervisor paths; chrome/fonts receive their existing charges and no window success is assumed in advance.

Several current scope-accounting tests intentionally use hidden Rects to consume one frame each. They will need honest, preserved accounting migrations; Image/Line alternatives can retain unchanged full-area exhaustion witnesses. Do not loosen all primitive assertions together. This increment improves a bounded class of small-box pages; it does not solve large/HiDPI windows, the256-command ceiling, general web rendering gaps or whole-browser security/conformance claims.

Suggested ownership: one agent owns native.rs reservation pass/count ledger; an independent agent owns new native Rect-accounting tests and the loaded Page witness. Existing core rounded helpers and shaders can remain byte-exact. Root owns before-image retention, actual runs, any narrow stale accounting updates, docs/evidence and optional real-window validation.
