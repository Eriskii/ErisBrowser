#![cfg(feature = "raster-bridge")]
use eris::graphics::{Color, DrawCommand, Fonts, ImageStore, Rect, raster_bridge::{FallbackKind, native::{NativePhase, plan_native_scene}}};
use eris_raster_core::{Command, Frame, Profile};
#[test]
fn predecessor_reserves_a_frame_for_each_small_rectangle() {
    let target = Frame::new(512, 512, 0xffffff);
    let mut commands = Vec::new();
    let mut core = Vec::new();
    for i in 0..40 {
        let x = (16 + (i % 8) * 32) as f32;
        let y = (16 + (i / 8) * 24) as f32;
        commands.push(DrawCommand::Rect {rect: Rect {x, y, width: 20.0, height: 12.0}, color: Color::rgb(255, 0, 0), radius: 0.0});
        core.push(Command::Rect {rect: eris_raster_core::Rect::new(x,y,20.0,12.0), rgba: [255,0,0,255], radius: 0.0});
    }
    let error = plan_native_scene(target, &[NativePhase {frame:target, commands:&commands}], &ImageStore::new(), &Fonts::new()).unwrap_err();
    assert_eq!(error.kind, FallbackKind::CpuPaintBudget);
    let plan = eris_raster_core::plan_with_masks_for_profile(Profile::Native, target, &core, &[], &[], &[]).unwrap();
    assert_eq!(plan.invocations(), 539_648);
    assert_eq!(plan.gpu_buffer_bytes(), 2_107_664);
    assert_eq!(plan.draws().len(), 41);
    println!("BASELINE native=CpuPaintBudget rect_cpu=10485760 cpu_limit=4194304 rect_loop=9600 core_draws=41 gpu_invocations=539648 gpu_bytes=2107664");
}
