from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parent;W=R/'worktree';D=R/'test-migration';D.mkdir(exist_ok=False)
def update(name,transform):
 p=W/name;a=p.read_text();b=transform(a);assert b!=a
 (D/(p.stem+'-before.rs')).write_text(a);p.write_text(b);(D/(p.stem+'-after.rs')).write_text(b)
 return {'path':name,'before':hashlib.sha256(a.encode()).hexdigest(),'after':hashlib.sha256(b.encode()).hexdigest()}
def once(s,a,b):assert s.count(a)==1,a;return s.replace(a,b)
def native(s):
 # Keep the original zero-geometry command-count witness. Only budget-saturating scenes change.
 s=once(s,'let a = vec![hidden(); 10];\n    let mut b = vec![hidden(); 10];','let full = fill(0.0, 0.0, 250.0, 200.0, Color::TRANSPARENT, 0.0);\n    let a = vec![full.clone(); 10];\n    let mut b = vec![full.clone(); 10];')
 s=once(s,'assert_eq!(accepted.stats().cpu_pixel_upper_bound, 1_000_000);\n    b.push(hidden());','assert_eq!(accepted.stats().cpu_pixel_upper_bound, 1_000_000);\n    b.push(full);')
 s=once(s,'let first = vec![hidden(); 20];','let first = vec![fill(0.0, 0.0, 250.0, 200.0, Color::TRANSPARENT, 0.0); 20];')
 s=once(s,'stats.cpu_pixel_upper_bound,\n            u64::from(width) * u64::from(height)','stats.cpu_pixel_upper_bound,\n            u64::from(bar_width) * 34')
 return s

def scope(s):
 s=once(s,'assert_eq!(scene.stats().cpu_pixel_upper_bound, 128);','assert_eq!(scene.stats().cpu_pixel_upper_bound, 8); // 4 + 0 + 2 + 2 loop pixels')
 s=once(s,'fn native_scope_accounting_keeps_each_primitive_area_charge_across_phases()', 'fn native_scope_accounting_keeps_full_rect_image_line_charges_across_phases()')
 s=once(s,'let primitives = [\n        hidden(),','let primitives = [\n        fill(0.0, 0.0, 250.0, 200.0, Color::TRANSPARENT, 0.0),')
 s=once(s,'let first = vec![hidden(); 19];','let full = fill(0.0, 0.0, 250.0, 200.0, Color::TRANSPARENT, 0.0);\n    let first = vec![full.clone(); 19];')
 s=once(s,'let exhausted = vec![hidden(); 20];','let exhausted = vec![full; 20];')
 s=once(s,'// Independently fixed old and new admission totals: only the 18 scopes change.','// Historical all-command reservation; scope and Rect refinements preserve these pixels.')
 s=once(s,'assert_eq!(scene.stats().cpu_pixel_upper_bound, 524_288);','assert_eq!(scene.stats().cpu_pixel_upper_bound, 1_280); // 32*32 + 16*16')
 return s

def opacity(s):
 s=once(s,'assert_eq!(first.stats().cpu_pixel_upper_bound, 9);','assert_eq!(first.stats().cpu_pixel_upper_bound, 7); // two full-area markers + one pixel')
 s=once(s,'assert_eq!(result.stats().cpu_pixel_upper_bound, 8);','assert_eq!(result.stats().cpu_pixel_upper_bound, 7); // two full-area markers + 2 + 1 pixels')
 return s
records=[update('src/graphics/raster_bridge/native/tests.rs',native),update('src/graphics/raster_bridge/native/scope_accounting_tests.rs',scope),update('src/graphics/raster_bridge/native/opacity_tests.rs',opacity)]
(D/'receipt.json').write_text(json.dumps({'changes':records,'reason':'Rect reservation now uses preblend geometry. Quota witnesses use full-frame transparent Rects to preserve exact/full-plus-one exhaustion; no quotas or pixel literals changed.','changed_fees':{'fixed_scopes':[128,8],'loaded_scope_page':[524288,1280],'half_opacity':[9,7],'zero_opacity':[8,7],'wide_bar':'bar_width*34 replaces viewport area'},'full_image_line_opacity_charges_unchanged':True},indent=2)+'\n')
p=W/'tests/native_rect_baseline.rs';assert p.read_bytes()==(R/'baseline/witness-2.rs').read_bytes();p.unlink()
print('Preserved before/after test accounting changes; removed only the retained temporary predecessor witness.')
