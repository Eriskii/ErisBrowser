import hashlib
import json
from pathlib import Path
A=Path(__file__).resolve().parents[1]
W=A/'worktree'
def bind(path):
    data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
validation=json.loads((A/'root/final-validation.json').read_text())
assert validation['status']=='pass'
for relative in ['plans/html-review-2.json','production-1/layout-review.json','root/results-html-review.json']:
    review=json.loads((A/relative).read_text())
    assert 'clear' in review['status'],relative
artifacts={}
excluded={'selection-final.json','publication-verification.json'}
for folder in ['plans','planning-tools','production-1','upstream-plan-1','root','validation']:
    for path in sorted((A/folder).rglob('*')):
        assert not path.is_symlink(),path
        if not path.is_file() or path.name in excluded: continue
        assert '__pycache__' not in path.parts
        artifacts[str(path.relative_to(A))]=bind(path)
for path in sorted(A.iterdir()):
    if path.is_file() and path.suffix in ['.json','.py']:
        artifacts[path.name]=bind(path)
for relative in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/promise-all.md','docs/promise-test262-host.md','docs/promise-all-test262.md']:
    artifacts['documentation/'+relative]=bind(W/relative)
claims={'base':'5dc150e27e924fedc873017ca07c15981559bf8c','scope':'Complete pinned98-source196-mode Promise.all profile, exact source authentication,90-control gate, recorded baseline and additive CI check. No Rust production change.','validation':validation,'limits':'All previous transport/resource caps and old profile source/policy/case identities retained.','limitations':'Selected corpus only.170passed18failed8unsupported; no full Promise/ECMAScript/web compatibility, security or Chromium performance claim.'}
selection={'source_inventory':bind(A/'source2.json'),'artifacts':artifacts,'claims':claims,'max_uncompressed_bytes':128*1024*1024}
(A/'root/selection-final.json').write_text(json.dumps(selection,indent=2)+'\n')
print(json.dumps({'artifacts':len(artifacts),'source_inputs':1221}))
