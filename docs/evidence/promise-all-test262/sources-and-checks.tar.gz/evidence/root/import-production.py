import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def checked(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
    return data

peer = json.loads((A / 'production-1/layout-review.json').read_text())
assert 'clear' in peer['status']
plan_peer = json.loads((A / 'plans/html-review-2.json').read_text())
assert 'clear' in plan_peer['status']
data = (A / 'production-1/source-ready.json').read_bytes()
assert digest(data) == '55a5eab68d80fa8d5988a963be35f0ce0eb2ee3d7011a8a9a8e1cecf82edd976'
manifest = json.loads(data)
for row in manifest['selected_bindings']:
    checked(row)
snapshot = json.loads((A / 'source-tests.json').read_text())
for relative, expected in snapshot['source_sha256'].items():
    assert digest((W / relative).read_bytes()) == expected, relative
selected = []
for row in manifest['paths']:
    before, raw = checked(row['before']), checked(row['raw'])
    checked(row['diff'])
    assert (W / row['relative']).read_bytes() == before
    selected.append((row['relative'], raw))
assert {relative for relative, _ in selected} == {'tools/import_test262.py', 'tools/test262_conformance.py'}
for relative, raw in selected:
    (W / relative).write_bytes(raw)
    snapshot['source_sha256'][relative] = digest(raw)
snapshot['scope'] = 'Reviewed Promise.all importer/runner plus frozen controls and roster adapters; before pinned corpus import.'
(A / 'source-production.json').write_text(json.dumps(snapshot, indent=2) + '\n')
(A / 'root/production-import-receipt.json').write_text(json.dumps({'selected_hold': digest(data), 'paths': [{'path': r, 'sha256': digest(b)} for r, b in selected]}, indent=2) + '\n')
print(json.dumps({'imported_paths': 2, 'source_inputs': len(snapshot['source_sha256'])}))
