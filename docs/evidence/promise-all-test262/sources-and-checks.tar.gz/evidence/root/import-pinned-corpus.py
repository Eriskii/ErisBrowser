"""Import the complete held profile from authenticated cached source bytes."""
import hashlib
import json
from pathlib import Path
import sys
from unittest.mock import patch

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
sys.path.insert(0, str(W / 'tools'))
import import_test262 as importer

held = A / 'plans/tests-before-2/raw/tools/promise-all-profile-oracle.json'
raw = held.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '0a8c1db76b33216daec60e0062363708f0a8bbb3910f8b9b150b0b227faab2d2'
expected = json.loads(raw)['expected_manifest']
cache = A / 'upstream-plan-1'
raw_prefix = 'https://raw.githubusercontent.com/tc39/test262/7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd/'
urls = {}
for row in expected['files']:
    urls[raw_prefix + row['path']] = (cache / 'primary-cache' / row['path'], row)
for row in expected['inventory_proof']['files']:
    urls[row['url']] = (cache / 'proof' / Path(row['path']).name, row)
assert len(urls) == 113

def cached_fetch(url):
    assert url in urls, url
    path, row = urls[url]
    data = path.read_bytes()
    assert len(data) == row['bytes'], path
    assert hashlib.sha256(data).hexdigest() == row['sha256'], path
    return data

destination = W / 'tests/upstream/test262-promise-all'
assert not destination.exists()
with patch.object(importer, 'fetch', cached_fetch):
    importer.import_corpus(destination, 'promise-all')
assert json.loads((destination / 'manifest.json').read_bytes()) == expected
for row in expected['files'] + expected['inventory_proof']['files']:
    data = (destination / row['path']).read_bytes()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
print(json.dumps({'sources': 98, 'mode_cases': 196, 'auxiliary': 8, 'proof_documents': 7, 'network_requests': 0, 'manifest_exact': True}))
