import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
P = A / 'plans'

def digest(data):
    return hashlib.sha256(data).hexdigest()

def check(row):
    data = Path(row['path']).read_bytes()
    assert len(data) == row['bytes'] and digest(data) == row['sha256'], row['path']
    return data

hold = (P / 'tests-before-2/source-ready.json').read_bytes()
assert digest(hold) == '8d9f406d76908ecde9395c402da58df1cd9f8835e90b5774c71cc53820618ad2'
manifest = json.loads(hold)
for row in manifest['bindings']:
    check(row)
snapshot = json.loads((A / 'parent-source.json').read_text())
for relative, expected in snapshot['source_sha256'].items():
    assert digest((W / relative).read_bytes()) == expected, relative
selected = []
for row in json.loads((P / 'migrations-before/selection.json').read_text())['paths']:
    before, raw = check(row['before']), check(row['raw'])
    check(row['diff'])
    assert (W / row['path']).read_bytes() == before
    selected.append((row['path'], raw))
for name in ['promise-all-profile-oracle.json', 'test_test262_promise_all_profile.py']:
    relative = 'tools/' + name
    raw = (P / 'tests-before-2/raw' / relative).read_bytes()
    assert not (W / relative).exists()
    selected.append((relative, raw))
assert len(selected) == len({r[0] for r in selected}) == 17
for relative, raw in selected:
    (W / relative).write_bytes(raw)
    snapshot['source_sha256'][relative] = digest(raw)
snapshot['scope'] = 'Frozen new11 Python control groups and15 historical-roster adapters; no new profile production or corpus yet.'
(A / 'source-tests.json').write_text(json.dumps(snapshot, indent=2) + '\n')
(A / 'root/test-import-receipt.json').write_text(json.dumps({'selected_hold': digest(hold), 'paths': [{'path': r, 'sha256': digest(b)} for r, b in selected], 'production_changed': False}, indent=2) + '\n')
print(json.dumps({'imported_paths': len(selected), 'source_inputs': len(snapshot['source_sha256']), 'new_groups': 11}))
