from pathlib import Path
import json,hashlib,collections
R=Path('/tmp/eris-promise-all-test262-1'); W=R/'worktree'; Q=R/'plans'
load=lambda p:json.loads(Path(p).read_text())
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
digest=lambda b:hashlib.sha256(b).hexdigest()
o=load(Q/'tests-before-2/raw/tools/promise-all-profile-oracle.json')
new=load(R/'promise-all-report.json'); old=load(R/'promise-existing-report.json')
binary=load(R/'binary.json');assert sha(binary['path'])==binary['sha256']
summary={}
for profile,report,expected,policy,corpus in [('promise-all',new,o['case_identities'],o['policy'],'test262-promise-all'),('promise-methods-async',old,o['old_profile']['case_identities'],o['old_profile']['policy'],'test262-promise-methods-async')]:
 rows=report['cases']; assert len(rows)==len(expected)
 assert [r['id'] for r in rows]==[r['id'] for r in expected]
 assert len({r['id'] for r in rows})==len(rows)
 assert report['binary_sha256']==binary['sha256'] and report['binary']==binary['path']
 assert report['runner_policy']==policy
 assert digest(json.dumps(policy,sort_keys=True).encode())==report['runner_policy_sha256']
 assert sha(W/'tests/upstream'/corpus/'manifest.json')==report['corpus_manifest_sha256']
 assert report['mode_cases']==len(rows) and report['source_files']==len({r['file'] for r in rows})
 assert report['full_test262_conformance'] is False and report['negative_source_tests']==0 and report['fixture_files']==[]
 assert report['regressions']==report['improvements']==[]
 categories=collections.defaultdict(list)
 for r,e in zip(rows,expected):
  assert r['case_sha256']==e['case_sha256']
  assert r['id']==r['file']+':'+r['mode'] and r['mode'] in ('sloppy','strict')
  assert r['source_sha256']==sha(W/'tests/upstream'/corpus/r['file'])
  assert r['expected_negative'] is None
  obs=r.get('observation')
  if obs:
   c=obs['completion']; assert c['policy']==e['policy']
   if r['status']=='passed':
    assert obs['status']=='complete' and obs['phase']=='runtime'
    assert c==dict(policy=e['policy'],done_calls=e['policy'],success_prints=e['policy'],failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=0)
    assert obs['error_type']==obs['error_identity']==obs['message']==obs['harness']==''
    cat='passed'
   elif obs['status']=='host-failure':
    assert r['status']=='failed' and obs['phase']=='host' and obs['message']=='unhandled-rejection'
    assert obs['error_type']==obs['error_identity']==obs['harness']==''
    assert c==dict(policy=e['policy'],done_calls=e['policy'],success_prints=e['policy'],failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1)
    cat='final_unhandled_policy'
   elif obs['status']=='exception' and obs['phase']=='parse':
    assert r['status']=='failed' and obs['error_type']==obs['error_identity']=='SyntaxError' and obs['message']=='expected expression'
    assert c==dict(policy=e['policy'],done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=False,audited=False,unhandled=0)
    cat='parse_SyntaxError'
   elif obs['status']=='unsupported':
    assert r['status']=='unsupported' and obs['phase']=='parse' and obs['error_type']=='UnsupportedFeature' and obs['message']=="'class' is not supported"
    assert c==dict(policy=e['policy'],done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=False,audited=False,unhandled=0)
    cat='parse_class_unsupported'
   else:
    assert r['status']=='failed' and obs['status']=='exception' and obs['phase']=='runtime' and obs['error_type']==obs['error_identity']=='ReferenceError' and obs['message']=="'Proxy' is not defined"
    assert c==dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=256,quiescent=True,audited=True,unhandled=0)
    cat='runtime_Proxy_ReferenceError'
  else:
   assert r['status']=='unsupported';cat='metadata_or_host_unsupported'
  categories[cat].append(r['id'])
 counts=dict(collections.Counter(r['status'] for r in rows));assert counts==report['counts']
 summary[profile]=dict(counts=counts,categories=dict(categories),manifest_sha256=report['corpus_manifest_sha256'],policy_sha256=report['runner_policy_sha256'])
 # Every saved baseline status and identity remains exact, including all failures.
 baseline=load(R/'promise-all-baseline.json') if profile=='promise-all' else load(W/'tests/conformance/test262-promise-methods-async-current.json')
 assert baseline['cases']=={r['id']:{k:r[k] for k in ('status','case_sha256','source_sha256')} for r in rows}
 for k in ['revision','corpus_manifest_sha256','runner_policy_sha256']:assert baseline[k]==report[k]
 if profile=='promise-all':assert baseline['binary_sha256']==binary['sha256']
 assert report['harness_preflight_passed'] is True
 # Independently join literal controls, source/harness metadata fingerprints, exact prerequisites.
 held=[('promise-methods-',x) for x in o['old_profile']['controls']]
 expected_guards=[(prefix,row,mode) for mode in ('sloppy','strict') for prefix,row in held]
 if profile=='promise-all':expected_guards += [('promise-all-',row,mode) for mode in ('sloppy','strict') for row in o['controls']]
 assert len(report['harness_preflight'])==len(expected_guards)
 lookup={}
 for actual,(prefix,row,mode) in zip(report['harness_preflight'],expected_guards):
  name=prefix+row['name'];r=actual['result'];pol=row['completion_policy']
  assert actual['name']==name and actual['expected']==row['expected'] and actual['verified'] is True
  assert r['mode']==mode and r['id']=='harness-preflight:'+name and r['file']=='<preflight>'
  assert r['source_sha256']==digest(row['source'].encode())
  names=['assert.js','sta.js']+(['doneprintHandle.js'] if pol else [])+row['includes']
  identity=dict(source_sha256=r['source_sha256'],mode=mode,metadata=dict(flags=['async'] if pol else [],includes=row['includes'],features=[],locale=[],negative=None),harness=[dict(name=n,sha256=sha(W/'tests/upstream'/corpus/'harness'/n)) for n in names],completion_policy=pol)
  assert r['case_sha256']==digest(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())
  obs=r['observation']; c=obs['completion']; exp=row['expected'];assert c['policy']==pol
  if exp=='passed':assert r['status']=='passed' and obs['status']=='complete'
  elif exp=='synchronous-exception':assert r['status']=='failed' and obs['status']=='exception' and obs['phase']=='runtime' and obs['error_type']=='Test262Error' and obs['error_identity']=='' and c['flags']==256 and c['quiescent'] and c['audited'] and c['unhandled']==0
  elif exp=='resource':assert r['status']=='resource' and obs['status']=='resource' and obs['phase']=='runtime' and obs['error_type']=='ResourceLimit' and c['flags']&8 and not c['audited']
  else:assert r['status']=='failed' and obs['status']=='host-failure' and obs['message']==exp
  lookup[(name,mode)]=actual
 for actual,(prefix,row,mode) in zip(report['harness_preflight'],expected_guards):
  if prefix=='promise-all-':required=['promise-methods-'+r['name'] for r in o['old_profile']['controls']]+([prefix+row['prerequisite']] if row['prerequisite'] else [])
  else:
   required=[prefix+row['prerequisite']] if row['prerequisite'] else []
   if row['origin']=='original-literal':
    required += [prefix+r['name'] for r in o['old_profile']['controls'] if r['origin']=='new-prerequisite']
    if row['name']!='one-async-completion':required += [prefix+'one-async-completion']
  expected_pr=[dict(name=n,mode=mode,verified=True,case_sha256=lookup[(n,mode)]['result']['case_sha256'],source_sha256=lookup[(n,mode)]['result']['source_sha256']) for n in required]
  assert actual['prerequisites']==expected_pr
 summary[profile]['preflight_rows']=len(expected_guards)
assert new['harness_preflight'][:74]==old['harness_preflight']
for name in ['upstream-all-1','upstream-existing-1','host-release-for-upstream-1']:
 rec=load(R/'validation'/f'{name}.json');assert rec['exit']==0 and sha(R/'validation'/rec['log'])==rec['sha256']
base=load('/tmp/eris-promise-all-1/source2.json')['source_sha256'];cur=load(R/'source-production.json')['source_sha256']
rustkeys=[k for k in base if k.endswith('.rs') or k.endswith('Cargo.toml') or k=='Cargo.lock']
for k in rustkeys:assert cur[k]==base[k]==sha(W/k),k
summary['binary']=binary;summary['unchanged_binary_source_input_count']=len(rustkeys)
(R/'root/html-results-data.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({k:({x:v[x] for x in ['counts','preflight_rows']} if k in ['promise-all','promise-methods-async'] else v) for k,v in summary.items()},indent=2))
print('categories',{p:{c:len(v) for c,v in summary[p]['categories'].items()} for p in ['promise-all','promise-methods-async']})
