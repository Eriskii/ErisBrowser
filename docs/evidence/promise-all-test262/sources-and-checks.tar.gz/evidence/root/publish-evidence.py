#!/usr/bin/env python3
"""Archive explicitly bound checkpoint inputs; claims remain root-authored."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import tarfile
import tempfile

ROOT = Path("/tmp/eris-promise-all-test262-1")
WORKTREE = ROOT / "worktree"
SELECTION = ROOT / "root/selection-final.json"
OUTPUT = WORKTREE / "docs/evidence/promise-all-test262"
SUMMARY = OUTPUT / "summary.json"
ARCHIVE = OUTPUT / "sources-and-checks.tar.gz"
MAX_JSON = 16 * 1024 * 1024
MAX_TAR = 256 * 1024 * 1024
MAX_MEMBERS = 10_000
CHUNK = 1024 * 1024
SHA = re.compile(r"[0-9a-f]{64}\Z")


def require(condition, message):
    if not condition:
        raise ValueError(message)


def unique_object(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"duplicate JSON key: {key!r}")
        result[key] = value
    return result


def invalid_constant(value):
    raise ValueError(f"non-finite JSON constant: {value}")


def json_object(data):
    value = json.loads(data, object_pairs_hook=unique_object,
                       parse_constant=invalid_constant)
    require(type(value) is dict, "JSON root must be an object")
    return value


def encode_json(value):
    return (json.dumps(value, sort_keys=True, indent=2, ensure_ascii=True,
                       allow_nan=False) + "\n").encode("utf-8")


def relative_name(value):
    require(type(value) is str and value and len(value.encode("utf-8")) <= 4096,
            "invalid archive/source name")
    require(not value.startswith("/") and "\\" not in value,
            f"non-relative path: {value!r}")
    parts = value.split("/")
    require(all(part not in ("", ".", "..") for part in parts),
            f"noncanonical or traversing path: {value!r}")
    require(not any(ord(char) < 32 or ord(char) == 127 for char in value),
            f"control character in path: {value!r}")
    return value


def no_symlinks(path):
    require(path.is_absolute(), f"absolute path required: {path}")
    current = Path(path.anchor)
    for part in path.parts[1:]:
        require(part not in ("", ".", ".."), f"invalid path: {path}")
        current /= part
        require(not stat.S_ISLNK(current.lstat().st_mode),
                f"symlink component: {current}")


def input_path(value):
    require(type(value) is str, "input path must be text")
    path = Path(value)
    require(path.is_absolute() and str(path) == value, "noncanonical input path")
    no_symlinks(path)
    require(path.is_relative_to(ROOT), f"input outside checkpoint: {path}")
    require(not path.is_relative_to(OUTPUT), "output cannot be an input")
    parts = path.relative_to(ROOT).parts
    require(not any(p == ".git" or p == "target" or p.startswith("target-")
                    for p in parts), f"excluded input tree: {path}")
    lower = path.name.lower()
    forbidden = (".o", ".obj", ".a", ".so", ".dll", ".exe", ".rlib",
                 ".rmeta", ".dylib", ".bc", ".wasm", ".pdb", ".tar",
                 ".gz", ".tgz", ".zip", ".xz", ".bz2", ".zst", ".7z")
    require(not lower.endswith(forbidden), f"excluded binary/archive suffix: {path}")
    return path


def check_magic(prefix, path):
    forbidden = (b"\x7fELF", b"MZ", b"!<arch>\n", b"\0asm", b"\x1f\x8b",
                 b"PK\x03\x04", b"PK\x05\x06", b"\xfd7zXZ\0", b"BZh",
                 b"7z\xbc\xaf\x27\x1c", b"\x28\xb5\x2f\xfd",
                 b"\xfe\xed\xfa\xce", b"\xce\xfa\xed\xfe",
                 b"\xfe\xed\xfa\xcf", b"\xcf\xfa\xed\xfe",
                 b"\xca\xfe\xba\xbe", b"\xbe\xba\xfe\xca")
    require(not prefix.startswith(forbidden) and prefix[257:262] != b"ustar",
            f"compiled binary or archive payload: {path}")


def opened(path):
    no_symlinks(path)
    fd = os.open(path, os.O_RDONLY | os.O_CLOEXEC | os.O_NOFOLLOW)
    try:
        require(stat.S_ISREG(os.fstat(fd).st_mode), f"nonregular input: {path}")
        return os.fdopen(fd, "rb")
    except BaseException:
        os.close(fd)
        raise


def binding(value):
    require(type(value) is dict and set(value) == {"path", "bytes", "sha256"},
            "binding requires exactly path, bytes, sha256")
    require(type(value["bytes"]) is int and 0 <= value["bytes"] <= MAX_TAR,
            "invalid bound size")
    require(type(value["sha256"]) is str and SHA.fullmatch(value["sha256"]),
            "invalid SHA-256")
    input_path(value["path"])
    return value


def inspect(path, expected_sha=None, expected_size=None, retain=False):
    path = input_path(str(path))
    digest = hashlib.sha256()
    chunks = []
    with opened(path) as stream:
        before = os.fstat(stream.fileno())
        ceiling = MAX_JSON if retain else MAX_TAR
        require(before.st_size <= ceiling, f"input too large: {path}")
        size = 0
        first = True
        while chunk := stream.read(CHUNK):
            if first:
                check_magic(chunk, path)
                first = False
            size += len(chunk)
            require(size <= ceiling, f"growing/oversized input: {path}")
            digest.update(chunk)
            if retain:
                chunks.append(chunk)
        after = os.fstat(stream.fileno())
        require((before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns)
                == (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns),
                f"input changed during read: {path}")
    require(size == before.st_size, f"short input read: {path}")
    sha = digest.hexdigest()
    require(expected_size is None or size == expected_size, f"size mismatch: {path}")
    require(expected_sha is None or sha == expected_sha, f"hash mismatch: {path}")
    record = {"path": str(path), "bytes": size, "sha256": sha}
    return record, b"".join(chunks) if retain else None


def info(name, size):
    value = tarfile.TarInfo(name)
    value.size = size
    value.mode = 0o644
    value.uid = value.gid = value.mtime = 0
    value.uname = value.gname = ""
    value.type = tarfile.REGTYPE
    value.pax_headers = {}
    return value


def tar_bytes(members):
    size = 1024
    for member in members:
        size += len(info(member["name"], member["bytes"]).tobuf(tarfile.PAX_FORMAT))
        size += ((member["bytes"] + 511) // 512) * 512
    return ((size + tarfile.RECORDSIZE - 1) // tarfile.RECORDSIZE) * tarfile.RECORDSIZE


def verify_archive(path, members, expected_tar_bytes):
    size = 0
    with gzip.open(path, "rb") as stream:
        while chunk := stream.read(CHUNK):
            size += len(chunk)
            require(size <= expected_tar_bytes, "oversized decompressed archive")
    require(size == expected_tar_bytes, "tar framing size mismatch")
    with tarfile.open(path, "r:gz") as archive:
        for expected in members:
            member = archive.next()
            require(member is not None and member.name == expected["name"],
                    "archive order/roster mismatch")
            require(member.type == tarfile.REGTYPE and member.size == expected["bytes"]
                    and member.mode == 0o644 and member.uid == member.gid == member.mtime == 0
                    and member.uname == member.gname == "" and member.linkname == "",
                    "archive metadata mismatch")
            require(set(member.pax_headers) <= {"path"}, "unexpected PAX metadata")
            digest = hashlib.sha256()
            with archive.extractfile(member) as stream:
                while chunk := stream.read(CHUNK):
                    digest.update(chunk)
            require(digest.hexdigest() == expected["sha256"], "archive member hash mismatch")
        require(archive.next() is None, "extra archive member")


def file_digest(path):
    digest = hashlib.sha256()
    with opened(path) as stream:
        while chunk := stream.read(CHUNK):
            digest.update(chunk)
    return {"bytes": path.stat().st_size, "sha256": digest.hexdigest()}


def publish(staged):
    no_symlinks(WORKTREE)
    for directory in (WORKTREE / "docs", WORKTREE / "docs/evidence", OUTPUT):
        directory.mkdir(exist_ok=True)
        no_symlinks(directory)
        require(directory.is_dir(), "output parent is not a directory")
    require(not any(os.path.lexists(dst) for _, dst in staged), "output already exists")
    created = []
    try:
        for src, dst in staged:
            fd = os.open(dst, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644)
            identity = os.fstat(fd)
            created.append((dst, identity.st_dev, identity.st_ino))
            with os.fdopen(fd, "wb") as target, opened(src) as source:
                while chunk := source.read(CHUNK):
                    target.write(chunk)
                target.flush()
                os.fsync(target.fileno())
            require(file_digest(dst) == file_digest(src), "published copy mismatch")
    except BaseException:
        for path, device, inode in reversed(created):
            try:
                current = path.lstat()
            except FileNotFoundError:
                continue
            if (current.st_dev, current.st_ino) == (device, inode):
                path.unlink()
        raise


def main():
    selection_record, raw = inspect(SELECTION, retain=True)
    selection = json_object(raw)
    require(set(selection) == {"source_inventory", "artifacts", "claims", "max_uncompressed_bytes"},
            "unexpected selection fields")
    limit = selection["max_uncompressed_bytes"]
    require(type(limit) is int and 0 < limit <= MAX_TAR, "invalid selected tar cap")
    require(type(selection["claims"]) is dict, "claims must be a root-authored object")
    require(type(selection["artifacts"]) is dict, "artifacts must be an object")
    bound = binding(selection["source_inventory"])
    inventory_record, raw = inspect(bound["path"], bound["sha256"], bound["bytes"], retain=True)
    inventory = json_object(raw)
    sources = inventory.get("source_sha256")
    require(type(sources) is dict and sources, "missing source_sha256 map")
    require(len(sources) + len(selection["artifacts"]) <= MAX_MEMBERS, "too many members")
    members = []
    for relative, sha in sources.items():
        relative_name(relative)
        require(type(sha) is str and SHA.fullmatch(sha), "invalid source SHA-256")
        record, _ = inspect(WORKTREE / relative, sha)
        members.append({"name": "sources/" + relative, **record})
    for name, value in selection["artifacts"].items():
        relative_name(name)
        bound = binding(value)
        record, _ = inspect(bound["path"], bound["sha256"], bound["bytes"])
        members.append({"name": "evidence/" + name, **record})
    members.sort(key=lambda item: item["name"])
    require(len({item["name"] for item in members}) == len(members), "duplicate member path")
    names = {item["name"] for item in members}
    for name in names:
        parts = name.split("/")
        require(not any("/".join(parts[:i]) in names for i in range(1, len(parts))),
                "file/directory archive collision")
    member_bytes = sum(item["bytes"] for item in members)
    uncompressed = tar_bytes(members)
    require(member_bytes <= limit and uncompressed <= limit, "selected archive cap exceeded")
    require(not os.path.lexists(SUMMARY) and not os.path.lexists(ARCHIVE), "output already exists")
    with tempfile.TemporaryDirectory(prefix="packager-staging-", dir=ROOT / "root") as temporary:
        stage = Path(temporary)
        archive_path = stage / ARCHIVE.name
        with archive_path.open("xb") as output:
            with gzip.GzipFile(filename="", mode="wb", fileobj=output, mtime=0, compresslevel=9) as compressed:
                with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                    for member in members:
                        with opened(Path(member["path"])) as source:
                            archive.addfile(info(member["name"], member["bytes"]), source)
        archive_record = file_digest(archive_path)
        require(archive_record["bytes"] <= limit + CHUNK, "compressed archive exceeds cap")
        verify_archive(archive_path, members, uncompressed)
        for record in [selection_record, inventory_record, *members]:
            inspect(record["path"], record["sha256"], record["bytes"])
        summary = {
            "schema": "promise-all-test262-evidence-v1",
            "status": "archive-byte-bindings-verified",
            "claims_authority": "Root-authored; packager does not infer or validate result semantics.",
            "selection": selection_record,
            "source_inventory": inventory_record,
            "source_count": len(sources),
            "artifact_count": len(selection["artifacts"]),
            "claims": selection["claims"],
            "archive": {"path": ARCHIVE.name, **archive_record,
                        "member_bytes": member_bytes, "uncompressed_tar_bytes": uncompressed,
                        "selected_max_uncompressed_bytes": limit},
            "members": members,
        }
        summary_path = stage / SUMMARY.name
        with summary_path.open("xb") as output:
            output.write(encode_json(summary))
        require(json_object(summary_path.read_bytes()) == summary, "summary readback mismatch")
        publish([(archive_path, ARCHIVE), (summary_path, SUMMARY)])
    print(json.dumps({"summary": str(SUMMARY), "archive": str(ARCHIVE), **archive_record}, sort_keys=True))


if __name__ == "__main__":
    main()
