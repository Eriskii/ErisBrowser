import hashlib
import json
from collections import Counter
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def sha(data):
    return hashlib.sha256(data).hexdigest()
def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
def read(path):
    return json.loads(path.read_bytes())

source1, source2 = read(A/'source1.json'), read(A/'source2.json')
assert len(source1['source_sha256']) == 1220
assert len(source2['source_sha256']) == 1221
for relative, expected in source2['source_sha256'].items():
    assert sha((W/relative).read_bytes()) == expected, relative
assert {r for r,h in source2['source_sha256'].items() if source1['source_sha256'].get(r)!=h} == {'.github/workflows/check.yml', 'tests/conformance/test262-promise-all-current.json'}
parent = read(A/'parent-source.json')
for relative, expected in parent['source_sha256'].items():
    if relative.startswith('src/') or relative in {'Cargo.toml','Cargo.lock'}:
        assert source2['source_sha256'][relative] == expected, relative
binary = read(A/'binary.json')
assert bind(Path(binary['path'])) == {k:binary[k] for k in ['path','bytes','sha256']}
oracle = read(W/'tools/promise-all-profile-oracle.json')
assert read(W/'tests/upstream/test262-promise-all/manifest.json') == oracle['expected_manifest']
reports = {}
for filename,old,total,guards,counts in [('promise-all-report.json',False,196,90,{'passed':170,'failed':18,'unsupported':8}), ('promise-existing-report.json',True,458,74,{'passed':420,'failed':8,'unsupported':30})]:
    report = read(A/filename)
    held = oracle['old_profile'] if old else oracle
    cases = report['cases']
    assert len(cases) == total == report['mode_cases']
    assert len({c['id'] for c in cases}) == total
    assert report['counts'] == counts == dict(Counter(c['status'] for c in cases))
    assert {c['id']:c['case_sha256'] for c in cases} == {c['id']:c['case_sha256'] for c in held['case_identities']}
    assert report['runner_policy'] == held['policy']
    assert report['runner_policy_sha256'] == held['policy_sha256']
    assert report['binary_sha256'] == binary['sha256']
    preflight = report['harness_preflight']
    assert report['harness_preflight_passed'] is True and len(preflight) == guards
    assert len({(c['name'],c['result']['mode']) for c in preflight}) == guards
    assert all(c['verified'] is True for c in preflight)
    assert not report['regressions'] and not report['improvements']
    reports[filename] = {'report':bind(A/filename),'counts':counts,'mode_cases':total,'verified_controls':guards,'policy_sha256':report['runner_policy_sha256']}
new, old = read(A/'promise-all-report.json'),read(A/'promise-existing-report.json')
assert new['harness_preflight'][:74] == old['harness_preflight']
base = read(A/'promise-all-baseline.json')
assert (A/'promise-all-baseline.json').read_bytes() == (W/'tests/conformance/test262-promise-all-current.json').read_bytes()
assert base['cases'] == {c['id']:{k:c[k] for k in ['status','case_sha256','source_sha256']} for c in new['cases']}
oldbase=read(W/'tests/conformance/test262-promise-methods-async-current.json')
assert oldbase['cases']=={c['id']:{k:c[k] for k in ['status','case_sha256','source_sha256']} for c in old['cases']}
failed = [c for c in new['cases'] if c['status']=='failed']
host = [c for c in failed if c['observation']['status']=='host-failure']
parse = [c for c in failed if c['observation']['phase']=='parse']
assert len(host)==14 and len(parse)==4
assert all(c['observation']['message']=='unhandled-rejection' and c['observation']['completion']['unhandled']==1 and c['observation']['completion']['quiescent'] and c['observation']['completion']['audited'] for c in host)
assert all(c['observation']['error_type']=='SyntaxError' for c in parse)
unsupported=[c for c in new['cases'] if c['status']=='unsupported']
assert sum('reason' in c for c in unsupported)==4 and sum('observation' in c for c in unsupported)==4
logs={}
for label,expected in [('parent-preservation-corrected-1',0),('pinned-corpus-import-1',0),('python-profile-1',0),('python-full-1',0),('upstream-all-1',0),('upstream-existing-1',0),('upstream-parent-preservation-1',1),('host-release-for-upstream-1',0)]:
    path=A/'validation'/(label+'.json'); receipt=read(path); log=A/'validation'/receipt['log']
    assert receipt['exit']==expected and sha(log.read_bytes())==receipt['sha256'],label
    logs[label]={'receipt':bind(path),'log':bind(log),'exit':expected}
assert 'Ran 543 tests' in (A/'validation/python-full-1.log').read_text()
assert 'Ran 11 tests' in (A/'validation/python-profile-1.log').read_text()
result={'status':'pass','base':parent['base'],'source1':bind(A/'source1.json'),'source2':bind(A/'source2.json'),'execution_scope':'All Python and upstream executions use source1. Source2 adds only the byte-exact observed baseline and additive CI step. Rust production matches published5dc150e2.','binary':binary,'reports':reports,'python_tests':543,'new_python_groups':11,'failure_breakdown':{'host_unhandled':14,'parse_syntax_error':4,'unsupported_metadata_class':4,'unsupported_parser_class':4},'old_results_and_identities_unchanged':True,'all_source_and_log_bindings_checked':True,'logs':logs,'limitations':'No complete ECMAScript/browser conformance, new Rust suite, GPU-device measurement, production-security assurance or Chromium performance result.'}
(A/'root/final-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'pass','sources':1221,'python':543,'new':[170,18,8],'old':[420,8,30]}))
