from pathlib import Path
import urllib.request,json,hashlib,concurrent.futures,re,textwrap,collections
P=Path('/tmp/eris-promise-all-1/upstream-plan-1'); inv=json.loads((P/'inventory.json').read_text());rev=inv['revision']
selected={'Promise/all'}
rows=[f for f in inv['files'] if str(Path(f['path']).parent).removeprefix('test/built-ins/') in selected]
assert len(rows)==98
D=P/'primary-cache'
def get(row):
 path=row['path'];p=D/path;p.parent.mkdir(parents=True,exist_ok=True)
 if p.exists():data=p.read_bytes()
 else:
  u='https://raw.githubusercontent.com/tc39/test262/'+rev+'/'+path
  data=urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Eris-source-audit'}),timeout=20).read(2*1024*1024+1)
 assert len(data)<=2*1024*1024
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
 if not p.exists():p.write_bytes(data)
 s=data.decode();assert s.count('/*---')==1 and s.count('---*/')==1
 fields={};key=None
 for line in textwrap.dedent(s.split('/*---',1)[1].split('---*/',1)[0]).splitlines():
  m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_-]*):[ \t]*(.*)',line)
  if m:key=m[1];assert key not in fields;fields[key]=m[2]
  elif not line.strip() or line.lstrip().startswith('#'):continue
  elif key and line[:1].isspace():fields[key]+='\n'+line
  else:raise ValueError((path,line))
 def items(key):
  raw=fields.get(key,'').strip()
  if not raw:return []
  if raw.startswith('[') and raw.endswith(']'):values=raw[1:-1].split(',')
  else:
   assert all(not l.strip() or l.strip().startswith('- ') for l in raw.splitlines())
   values=[l.strip()[2:] for l in raw.splitlines() if l.strip()]
  result=[v.strip().strip('\"\'') for v in values if v.strip()]
  assert all(re.fullmatch(r'[A-Za-z0-9_.-]+',v) for v in result)
  return result
 return dict(row,sha256=hashlib.sha256(data).hexdigest(),metadata={k:items(k) for k in ['flags','features','includes','locale']},negative=fields.get('negative'),timeout=fields.get('timeout'),host_tokens=[name for name,pat in [('$262',r'\$262\b'),('print',r'\bprint\s*\('),('$DONE',r'\$DONE\b')] if re.search(pat,s)])
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:results=list(pool.map(get,rows))
helpers={'assert.js','sta.js'}|{v for r in results for v in r['metadata']['includes']}
if any('async' in r['metadata']['flags'] for r in results):helpers.add('doneprintHandle.js')
harness=json.loads((P/'proof/tree-e7917cf01aee95d5ed85ba370c550d02cea533c7.json').read_text())['tree'];hmap={e['path']:e for e in harness}
aux=[{'path':'harness/'+h,'blob':hmap[h]['sha'],'bytes':hmap[h]['size']} for h in sorted(helpers)]
for name,blob in [('LICENSE','a56b038f0e01b05b004d92097d4601ba629afdf3'),('INTERPRETING.md','ecf7ec7003a1e3ea937fb4e7d3348d22733b50b5')]:aux.append({'path':name,'blob':blob})
for row in aux:
 p=D/row['path'];p.parent.mkdir(parents=True,exist_ok=True)
 data=p.read_bytes() if p.exists() else urllib.request.urlopen('https://raw.githubusercontent.com/tc39/test262/'+rev+'/'+row['path'],timeout=20).read(2*1024*1024+1)
 assert len(data)<=2*1024*1024 and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']
 if not p.exists():p.write_bytes(data)
 row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
counts=collections.Counter();modes=0
for r in results:
 f=r['metadata']['flags'];counts['async' if 'async' in f else 'sync']+=1
 modes+=1 if set(f)&{'noStrict','onlyStrict','module','raw'} else 2
out={'status':'source_only_metadata_inventory_no_import_or_execution','selected_directories':sorted(selected),'source_files':len(results),'mode_cases':modes,'counts':dict(counts),'flags':dict(collections.Counter(v for r in results for v in r['metadata']['flags'])),'features':dict(collections.Counter(v for r in results for v in r['metadata']['features'])),'auxiliary':aux,'sources':results}
(P/'selected-metadata.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k!='sources'},indent=2))
