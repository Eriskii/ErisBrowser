from pathlib import Path
import json,hashlib,re,textwrap
D=Path('/tmp/eris-promise-all-1/upstream-profile-plan-1');assert not D.exists();D.mkdir()
P=Path('/tmp/eris-promise-all-1/upstream-plan-1');W=Path('/tmp/eris-promise-all-1/worktree')
def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def write(n,v):
 p=D/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n');return bind(p)
meta=json.loads((P/'selected-metadata.json').read_text());inv=json.loads((P/'inventory.json').read_text());rev=inv['revision'];root=inv['root_tree']
proof={};trees={}
def tree(sha):
 p=P/'proof'/('tree-'+sha+'.json');data=p.read_bytes();v=json.loads(data);assert v['sha']==sha and v['truncated'] is False
 encoded=[];names={}
 for e in v['tree']:
  name=e['path'];assert name not in names and '/' not in name and name not in ('','.','..');names[name]=e
  encoded.append((name.encode()+(b'/' if e['type']=='tree' else b''),e['mode'].lstrip('0').encode()+b' '+name.encode()+b'\0'+bytes.fromhex(e['sha'])))
 body=b''.join(b for _,b in sorted(encoded));assert hashlib.sha1(b'tree '+str(len(body)).encode()+b'\0'+body).hexdigest()==sha
 proof['inventory-proof/'+p.name]=data;trees[sha]=names;return names
commit=(P/'proof/commit.json').read_bytes();cv=json.loads(commit);assert cv['sha']==rev and cv['tree']['sha']==root;proof['inventory-proof/commit.json']=commit
entries=tree(root)
for part in ['test','built-ins','Promise','all']:
 e=entries[part];assert e['type']=='tree';selected_sha=e['sha'];entries=tree(selected_sha)
assert selected_sha=='ce292ad759c9c9c91d7b67b134af45c93668d702'
names=sorted(n for n,e in entries.items() if e['type']=='blob' and n.endswith('.js'));assert len(names)==98 and len(entries)==98
root_entries=trees[root];h=tree(root_entries['harness']['sha'])
aux={}
for row in meta['auxiliary']:
 data=(P/'primary-cache'/row['path']).read_bytes();assert len(data)==row['bytes'] and digest(data)==row['sha256']
 e=h[row['path'][8:]] if row['path'].startswith('harness/') else root_entries[row['path']]
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest();assert blob==row['blob']==e['sha'];aux[row['path']]=blob
for row in meta['sources']:
 data=(P/'primary-cache'/row['path']).read_bytes();assert len(data)==row['bytes'] and digest(data)==row['sha256']
 assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['blob']==entries[Path(row['path']).name]['sha']
assert len(proof)==7
scope='all 98 original .js files in the complete immediate Promise/all directory; root-linked nonrecursive Git proofs and unchanged harness bytes; both class-tagged sources retained; no execution or conformance claim'
manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=rev,scope=scope,directories={'Promise/all':names},test_files=98,files=[])
for row in sorted(meta['sources']+meta['auxiliary'],key=lambda r:r['path']):manifest['files'].append(dict(path=row['path'],upstream_path=row['path'],bytes=row['bytes'],sha256=row['sha256']))
description=dict(method='complete-nonrecursive-git-trees',revision=rev,root_tree=root,directory_trees={'Promise/all':selected_sha},auxiliary_blobs={k:aux[k] for k in sorted(aux)})
manifest['inventory_proof']=dict(description,files=[])
for p,data in sorted(proof.items()):
 route='commits/'+rev if p.endswith('commit.json') else 'trees/'+Path(p).name[5:-5]
 manifest['inventory_proof']['files'].append(dict(path=p,bytes=len(data),sha256=digest(data),url='https://api.github.com/repos/tc39/test262/git/'+route))
# Independent case identity reconstruction from pinned metadata and helper bytes.
def identity(path,source,md,mode,files):
 policy=int('async' in md['flags']);names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+md['includes'];assert len(names)==len(set(names))
 v=dict(source_sha256=digest(source),mode=mode,metadata=md,harness=[dict(name=n,sha256=digest(files['harness/'+n])) for n in names],completion_policy=policy)
 return {'id':path+':'+mode,'case_sha256':digest(json.dumps(v,sort_keys=True,ensure_ascii=True).encode()),'policy':policy,'harness':names,'class_excluded':'class' in md['features']}
auxbytes={r['path']:(P/'primary-cache'/r['path']).read_bytes() for r in meta['auxiliary']}
cases=[]
for row in meta['sources']:
 md=dict(row['metadata'],negative=None,timeout=None);assert row['negative'] is None and row['timeout'] is None
 for mode in ['sloppy','strict']:cases.append(identity(row['path'],(P/'primary-cache'/row['path']).read_bytes(),md,mode,auxbytes))
assert len(cases)==196 and sum(r['policy'] for r in cases)==114 and sum(r['class_excluded'] for r in cases)==4
oldrun=json.loads((W/'tools/promise-methods-runner-oracle.json').read_text());oldimp=json.loads((W/'tools/promise-methods-importer-oracle.json').read_text())
oldcor=W/'tests/upstream/test262-promise-methods-async';oldmanifest=(oldcor/'manifest.json').read_bytes();assert json.loads(oldmanifest)==oldimp['expected_manifest']
def metadata(source):
 fields={};key=None
 for line in textwrap.dedent(source.split('/*---',1)[1].split('---*/',1)[0]).splitlines():
  m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_-]*):[ \t]*(.*)',line)
  if m:key=m[1];assert key not in fields;fields[key]=m[2]
  elif not line.strip() or line.lstrip().startswith('#'):continue
  elif key and line[:1].isspace():fields[key]+='\n'+line
  else:raise AssertionError(line)
 def items(k):
  raw=fields.get(k,'').strip()
  if not raw:return []
  if raw.startswith('[') and raw.endswith(']'):vals=raw[1:-1].split(',')
  else:vals=[line.strip()[2:] for line in raw.splitlines() if line.strip()]
  return [s.strip().strip('\"\'') for s in vals if s.strip()]
 assert not fields.get('negative') and not fields.get('timeout')
 return dict(flags=items('flags'),includes=items('includes'),features=items('features'),negative=None,locale=items('locale'),timeout=None)
oldcases=[];oldfiles={r['path']:(oldcor/r['path']).read_bytes() for r in oldimp['expected_manifest']['files']}
for path,source in sorted(oldfiles.items()):
 if not path.startswith('test/'):continue
 md=metadata(source.decode());flags=md['flags'];modes=['strict'] if 'onlyStrict' in flags else ['sloppy'] if 'noStrict' in flags else ['sloppy','strict']
 for mode in modes:oldcases.append(identity(path,source,md,mode,oldfiles))
assert len(oldcases)==458
features=sorted(set(oldrun['features'])|{'Symbol.iterator'})
policy=dict(oldrun['new_policy'],supported_features=features)
controls=[]
def pair(name,good,bad,includes=[],asynchronous=False):
 for suffix,source,expected in [('',good,'passed'),('-mismatch',bad,'completion-error' if asynchronous else 'synchronous-exception')]:
  controls.append(dict(name=name+suffix,source=source,expected=expected,completion_policy=int(asynchronous),includes=includes,origin='promise-all-pair',prerequisite=name if suffix else None))
api="verifyProperty(Promise.all,'name',{value:'all',writable:false,enumerable:false,configurable:true});verifyProperty(Promise.all,'length',{value:1,writable:false,enumerable:false,configurable:true});assert.throws(TypeError,function(){new Promise.all([]);});"
pair('api',api,'Promise.all=function all(x){};'+api,['propertyHelper.js'])
order="var release;var pending=new Promise(function(r){release=r;});Promise.all([pending,2]).then(function(values){assert.sameValue(values.join(','),'7,2');}).then($DONE,$DONE);release(7);"
pair('order',order,order.replace("'7,2'","'2,7'"),asynchronous=True)
reject="var marker={};Promise.all([Promise.reject(marker),new Promise(function(){})]).then(function(){throw new Test262Error('unexpected fulfillment');},function(reason){assert.sameValue(reason,marker);}).then($DONE,$DONE);"
pair('reject',reject,reject.replace('assert.sameValue(reason,marker)','assert.notSameValue(reason,marker)'),asynchronous=True)
iterator="var values,resolves=0,rejects=0,n=0;function C(executor){executor(function(v){values=v;resolves++;},function(){rejects++;});}C.resolve=function(x){return {then:function(f){f(x);f(99);}};};var it={next:function(){n++;return n<=2?{done:false,value:n}:{done:true};}};var source={};source[Symbol.iterator]=function(){return it;};Promise.all.call(C,source);assert.sameValue(values.join(','),'1,2');assert.sameValue(resolves,1);assert.sameValue(rejects,0);assert.sameValue(n,3);"
pair('iterator-once',iterator,iterator.replace('assert.sameValue(resolves,1)','assert.sameValue(resolves,2)'))
assert len(controls)==8
oracle={
 'schema':1,'profile':'promise-all','expected_manifest':manifest,'counts':{'source_files':98,'all_bound_files':106,'source_bytes':109176,'async_files':57,'sync_files':41,'mode_cases':196,'async_modes':114,'sync_modes':82,'sloppy':98,'strict':98,'class_files':2,'class_modes':4,'eligible_modes_by_policy':192,'proof_files':7,'proof_bytes':sum(map(len,proof.values()))},
 'auxiliary_files':{r['path']:{k:r[k] for k in ['bytes','sha256','blob']} for r in meta['auxiliary']},
 'case_identities':cases,'features':features,'policy':policy,'policy_sha256':digest(json.dumps(policy,sort_keys=True).encode()),
 'class_sources':[r['path'] for r in meta['sources'] if 'class' in r['metadata']['features']],
 'controls':controls,'preflight':{'existing_common_groups':37,'existing_common_mode_rows':74,'new_pairs':4,'new_mode_rows':16,'total_mode_rows':90,'old_names_prefix':'promise-methods-','new_names_prefix':'promise-all-','dependency':'Every new all guard requires all37 existing common host guard outcomes verified in its same mode; mismatch additionally requires its matching positive. Exact90 identity set, no duplicates, missing, extras or wrong modes.'},
 'old_profile':{'name':'promise-methods-async','manifest_sha256':digest(oldmanifest),'manifest':oldimp['expected_manifest'],'case_identities_sha256':digest(json.dumps(oldcases,sort_keys=True,separators=(',',':')).encode()),'case_identities':oldcases,'policy':oldrun['new_policy'],'policy_sha256':oldrun['new_policy_sha256'],'controls':oldrun['controls'],'controls_sha256':digest(json.dumps(oldrun['controls'],sort_keys=True,separators=(',',':')).encode()),'sources_and_proofs':'All253 manifest-bound original payloads plus manifest remain byte-exact; old corpus is not enlarged or regenerated.'},
 'scope':'All fields are data/source-derived expectations before profile implementation or execution. Eligible192 is not a success count; host final-unhandled remains a separate policy veto.'}
write('tests-before/raw/tools/promise-all-profile-oracle.json',oracle)
write('contract.json',{'status':'proposed_bounded_profile_contract_before_production','profile':'promise-all','parent':'AP8e3db775','source_revision':rev,'selection':'Complete immediate Promise/all,98 originals; no outcome filtering or changes to upstream blobs. Root broad retrieval has21 docs; the new minimal selected proof needs7 unchanged docs including harness.','importer':{'new_constants':{'PROMISE_ALL_DIRECTORIES':{'Promise/all':98},'PROMISE_ALL_HELPERS':sorted(p[8:] for p in aux if p.startswith('harness/'))},'new_tables':['PROFILES','PROFILE_ROOTS','TREE_PROFILES'],'inventory':'New exact-selector profile branch calling existing git_tree_inventory(auxiliary_helpers), exact counts/helper-set checks, Git blob validation and scope string frozen in oracle. No general reader/cap changes.','destination':'tests/upstream/test262-promise-all'},'runner':{'profile_features':features,'host_profile':'Same ERJS2/ERJR3/test262-host authenticated DONE contract for both checked-sync and async cases; no runtime, protocol, helper or quota changes.','load':'Authenticate all source/auxiliary/proof bytes, retain both class files, set exact integer completion_policy from async flag before fingerprint, use current helper ordering and duplicate-helper rejection.','classification':'Class excluded explicitly4modes; all196 retained. Unsupported reasons are separate from failed runtime observations and host policy vetoes.','preflight_api':['promise_all_preflight_variants() returns eight held rows','promise_all_harness_preflight(files,binary,timeout) preserves existing74 rows then adds16','promise_all_preflight_healthy(outcomes) exact90 set and true flags'], 'preflight_reuse':'Leave old37 variants and old74 outcomes byte-for-byte; new profile may use existing common observer and verifier. Require all37 common outcomes in same mode and pair-positive prerequisites for new guards. Never accept incidental TypeError/resource/missing evidence as an expected mismatch.','failure':'Any malformed/failed preflight blocks all196 and refuses baseline recording. Final-unhandled is labeled host policy, not an upstream assertion result.','policy':policy,'policy_sha256':oracle['policy_sha256']},'old_profile_preservation':'Original232/458 source/proof/helper/manifest bytes, policy hashcc53ccb2…, case fingerprints,37variant literals and74row identities remain exact. New name is excluded explicitly from prior profile-set snapshot tests; no legacy expected counts/hashes regenerated.','old_test_adapter_candidates':['tools/test_import_test262_promise.py','tools/test_test262_promise_runner.py','tools/test_test262_typedarray_copy_within.py','tools/test_test262_typedarray_to_reversed.py','tools/test_test262_typedarray_reverse.py','tools/test_test262_typedarray_fill.py','tools/test_test262_typedarray_search.py','tools/test_test262_typedarray_views.py','tools/test_test262_typedarray_foundation.py','tools/test_test262_reflect_properties.py','tools/test_test262_object_has_own.py','tools/test_test262_construction.py','tools/test_test262_conformance.py','tools/test_test262_array_predicates.py','tools/test_test262_object_integrity.py'],'baseline_eligibility':'New tests use existing importer/runner call signatures plus three selected new preflight helpers. Before profile/corpus import only literal/source integrity and unchanged-old-profile assertions are meaningful; no passing parent baseline is claimed. All Python tests mock adapters/network. RealJS guards and196cases remain root-owned later.','limits':'Existing importer MAX_FILE/MAX_TOTAL/proof caps, runner jobs/timeouts, transport and Runtime work/heap unchanged. This checkpoint needs no new bootstrap work.','execution':False,'production':False})
write('source-inputs.json',{'bindings':[bind(P/n) for n in ['selection-before-fetch.json','inventory.json','selected-metadata.json']]+[bind(W/'tools'/n) for n in ['import_test262.py','test262_conformance.py','promise-methods-runner-oracle.json','promise-methods-importer-oracle.json','test_import_test262_promise.py','test_test262_promise_runner.py']]+[bind(P/'proof'/Path(p).name) for p in proof]+[bind(P/'primary-cache'/r['path']) for r in meta['sources']+meta['auxiliary']],'minimal_selected_proof':{'documents':len(proof),'bytes':sum(map(len,proof.values())),'tree_hashes_reconstructed':True},'original_scope_unchanged':True,'execution':False})
print(json.dumps({'oracle':bind(D/'tests-before/raw/tools/promise-all-profile-oracle.json'),'proof_bytes':sum(map(len,proof.values())),'policy':oracle['policy_sha256'],'old_cases':oracle['old_profile']['case_identities_sha256']}))
