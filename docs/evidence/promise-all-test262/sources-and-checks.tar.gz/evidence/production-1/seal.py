from pathlib import Path
import ast,difflib,hashlib,json
A=Path('/tmp/eris-promise-all-test262-1');D=A/'production-1';W=A/'worktree';P=Path('/tmp/eris-promise-all-1/upstream-profile-plan-1')
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def write(p,v):p.write_text(json.dumps(v,indent=2)+'\n');return bind(p)
def functions(s):return {n.name:ast.get_source_segment(s,n) for n in ast.parse(s).body if isinstance(n,ast.FunctionDef)}
parent=json.loads((A/'parent-source.json').read_bytes())['source_sha256'];rows=[];function_review={}
for rel in ['tools/import_test262.py','tools/test262_conformance.py']:
 before=D/'before'/rel;raw=D/'raw'/rel;patch=D/'diffs'/(rel.replace('/','__')+'.patch');a=before.read_text();b=raw.read_text();ast.parse(a);ast.parse(b)
 assert bind(before)['sha256']==parent[rel] and before.read_bytes()==(W/rel).read_bytes()
 assert ''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel))==patch.read_text()
 x=functions(a);y=functions(b);function_review[rel]=dict(changed_old=[n for n in x if x[n]!=y[n]],new=sorted(y.keys()-x.keys()),unchanged_functions={n:hashlib.sha256(x[n].encode()).hexdigest() for n in x if x[n]==y[n]})
 rows.append(dict(relative=rel,before=bind(before),raw=bind(raw),diff=bind(patch)))
assert function_review['tools/import_test262.py']['changed_old']==['profile_tree_inventory','import_corpus']
assert function_review['tools/test262_conformance.py']['changed_old']==['load_corpus','unsupported_reason','harness_preflight','main']
source=(D/'raw/tools/test262_conformance.py').read_text();tree=ast.parse(source);o=json.loads((P/'tests-before-2/raw/tools/promise-all-profile-oracle.json').read_bytes())
for name,held in [('promise_preflight_variants',o['old_profile']['controls']),('promise_all_preflight_variants',o['controls'])]:
 f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name==name);assert ast.literal_eval(next(n for n in f.body if isinstance(n,ast.Return)).value)==held
m=json.loads((P/'migrations-before/selection.json').read_bytes());rebase=[]
for row in m['paths']:
 assert bind(W/row['path'])['sha256']==row['before']['sha256']==parent[row['path']]
 rebase.append(dict(relative=row['path'],before_sha256=row['before']['sha256'],matches_published_parent=True))
notes='''External two-file Promise.all profile production draft. No project execution, module import, live edit or corpus import by this author. Python AST/literal extraction and text/hash/diff checks only.

Importer adds a separate promise-all selector for all98 immediate Promise/all sources at the already pinned revision. The unchanged nonrecursive Git reader authenticates seven original documents and the six helpers plus two legal files. Counts and helper sets are fixed before output. Source and auxiliary Git hashes remain checked; limits and the existing232-source profile path are unchanged.

Runner adds a distinct feature set (old Promise features plus Symbol.iterator), adopts the existing authenticated checked-sync/DONE policy and exposes three new private helpers. Existing parser, case_fingerprint, encoder/decoder, classifier, observation validation, host-reason rules,37literal controls, verifier and74-row producer are byte-identical. The old profile keeps its original set, policy and fingerprints.

The new preflight calls the unchanged74-row producer first. It then evaluates eight frozen rows in each mode, preserving exact source/helper bytes. Each new row requires all37 common outcomes in the same mode; mismatches also require the paired positive. The exact90-identity gate rejects missing, extra, duplicate, wrong-mode or unverified rows. Failure blocks all196 cases and forbids baseline recording. No incidental error is accepted as a verified mismatch. No actual guard or upstream outcome is claimed here.

Both class-tagged files/four modes stay explicit exclusions, and untagged syntax is passed to the unchanged adapter. All196 modes stay in reports. Final-unhandled remains a host-policy observation, not an upstream assertion result. No source filtering, Runtime/cap/protocol change or new startup fee.

The fifteen historical roster migrations and eleven selected verifier groups remain separately held, unmodified here. Their before bytes join published5dc150e2. The source-derived timeout-absence correction remains explicit; it changes oracle hashes only, not production metadata or fingerprint rules. Root's corrected old-profile parent control passed before this candidate existed. Root owns candidate imports, mocked tests, corpus replay and actual90/196 execution.
'''
(D/'notes.txt').write_text(notes)
review={'status':'ready_for_independent_source_review_no_execution','owned_paths':2,'parent_commit':'5dc150e27e924fedc873017ca07c15981559bf8c','function_change_inventory':function_review,'held_controls':{'new_rows':8,'new_modes':16,'old_rows':37,'old_modes':74,'total_modes':90,'all_literal_rows_match_static_AST':True},'migrations_rebase':rebase,'source_review':{'proof_authentication':'New profile reuses unchanged git_tree_inventory and source/auxiliary blob checks, exact directory98/helper6 guards. No generic reader limits changed.','old_profile':'Existing37 guards,74-row producer/verifier, serialized policy fields and feature set unchanged. Existing parser/fingerprint/transport/classifier remain byte-identical.','new_profile':'Typed completion_policy is attached before fingerprint; selected host profiles share existing policy checks and conservative realm-hook exclusion. No source class filter added.','preflight':'Old74 produced first. New rows require all37 same-mode results and paired positive; final exact90 gate additionally checks old74 gate and complete unique identities.','report':'On preflight failure every196case including metadata-excluded rows is blocked and baseline refused; healthy mode execution preserves existing classification/reason fields.','resource':'No Runtime, caps, transport, process bounds, helper bytes or startup charges changed.'},'candidate_tests_run':False,'project_imports':False,'live_edits':False}
write(D/'source-review.json',review)
refs=[A/'parent-source.json',P/'source-ready-2.json',P/'tests-before-2/source-ready.json',P/'contract-2.json',P/'tests-before-2/raw/tools/promise-all-profile-oracle.json',P/'tests-before-2/raw/tools/test_test262_promise_all_profile.py',P/'migrations-before/selection.json',P/'correction-1/receipt.json',P/'html-fingerprint-derivation.json',A/'root/preflight-literal-review.json',A/'validation/parent-preservation-corrected-1.json',A/'validation/parent-preservation-corrected-1.log',D/'notes.txt',D/'source-review.json',D/'author.py',D/'seal.py']
hold={'schema':'eris-promise-all-profile-production-v1','status':'external_source_ready_for_independent_peer','parent':'5dc150e27e924fedc873017ca07c15981559bf8c','paths':rows,'selected_bindings':[bind(p) for p in refs],'selected_tests':{'groups':11,'separately_held_old_migration_paths':15,'candidate_execution':False},'old_profile':'232sources/458modes plus37guards/74rows preserved.','new_profile':'98sources/196modes; same existing host policy;74common+16new preflight rows. No result prediction.','pending':'Independent final corrected-test byte peer and production source peer before root import/execution.','runtime_caps_protocol_changes':False,'live_edits':False,'execution':False}
write(D/'source-ready.json',hold);print(json.dumps(bind(D/'source-ready.json')))
