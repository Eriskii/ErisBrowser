from pathlib import Path
import ast,difflib,hashlib,json,pprint
A=Path('/tmp/eris-promise-all-test262-1');D=A/'production-1';W=A/'worktree';P=Path('/tmp/eris-promise-all-1/upstream-profile-plan-1')
oracle=json.loads((P/'tests-before-2/raw/tools/promise-all-profile-oracle.json').read_bytes())
parent=json.loads((A/'parent-source.json').read_bytes())['source_sha256']
def replace_once(s,a,b):
 assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
def publish(rel,s):
 before=(W/rel).read_bytes();assert hashlib.sha256(before).hexdigest()==parent[rel]
 target=D/'before'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(before)
 target=D/'raw'/rel;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(s)
 ast.parse(s)
 patch=''.join(difflib.unified_diff(before.decode().splitlines(True),s.splitlines(True),fromfile='before/'+rel,tofile='raw/'+rel))
 target=D/'diffs'/(rel.replace('/','__')+'.patch');target.parent.mkdir(parents=True,exist_ok=True);target.write_text(patch)

rel='tools/import_test262.py';s=(W/rel).read_text()
s=replace_once(s,"TREE_PROFILES = {'promise-methods-async',", "PROMISE_ALL_DIRECTORIES = {'Promise/all': 98}\nPROMISE_ALL_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js',\n                       'isConstructor.js', 'promiseHelper.js', 'propertyHelper.js'}\nTREE_PROFILES = {'promise-all', 'promise-methods-async',")
s=replace_once(s,"PROFILES = {'promise-methods-async':", "PROFILES = {'promise-all': PROMISE_ALL_DIRECTORIES, 'promise-methods-async':")
s=replace_once(s,"PROFILE_ROOTS = {'promise-methods-async':", "PROFILE_ROOTS = {'promise-all': 'test/built-ins', 'promise-methods-async':")
s=replace_once(s,"def profile_tree_inventory(profile, read=None):\n",'''def profile_tree_inventory(profile, read=None):
    if profile == 'promise-all':
        if (PROFILES[profile] != PROMISE_ALL_DIRECTORIES
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.all frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            PROMISE_ALL_DIRECTORIES, 'test/built-ins', read,
            auxiliary_helpers=PROMISE_ALL_HELPERS)
        if any(len(listings[name]) != count for name, count in PROMISE_ALL_DIRECTORIES.items()):
            raise ValueError('Promise.all complete directory counts differ')
        return listings, proof, description
''')
s=replace_once(s,"    if profile == 'promise-methods-async' and harness != PROMISE_METHOD_HELPERS:\n",'''    if profile == 'promise-all' and harness != PROMISE_ALL_HELPERS:
        raise ValueError('Promise.all requested harness differs from the frozen six helpers')
    if profile == 'promise-methods-async' and harness != PROMISE_METHOD_HELPERS:
''')
s=replace_once(s,"    if profile in {'promise-methods-async', 'typedarray-views',", "    if profile in {'promise-all', 'promise-methods-async', 'typedarray-views',")
s=replace_once(s,"    scope = {\n", "    scope = {\n        'promise-all': "+repr(oracle['expected_manifest']['scope'])+",\n")
publish(rel,s)

rel='tools/test262_conformance.py';s=(W/rel).read_text()
s=replace_once(s,"PROFILE_FEATURES[PROMISE_PROFILE] = PROMISE_FEATURES\n",'''PROFILE_FEATURES[PROMISE_PROFILE] = PROMISE_FEATURES
PROMISE_ALL_PROFILE = 'promise-all'
PROMISE_ALL_FEATURES = PROMISE_FEATURES | {'Symbol.iterator'}
PROFILE_FEATURES[PROMISE_ALL_PROFILE] = PROMISE_ALL_FEATURES
PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE}
''')
assert s.count("{'promise-methods-async',")==2;s=s.replace("{'promise-methods-async',","{'promise-all', 'promise-methods-async',")
assert s.count('profile == PROMISE_PROFILE')==8;s=s.replace('profile == PROMISE_PROFILE','profile in PROMISE_HOST_PROFILES')
assert s.count('profile != PROMISE_PROFILE')==1;s=s.replace('profile != PROMISE_PROFILE','profile not in PROMISE_HOST_PROFILES')
s=replace_once(s,'''    if profile in PROMISE_HOST_PROFILES:
        return promise_harness_preflight(files, binary, timeout)
''','''    if profile == PROMISE_ALL_PROFILE:
        return promise_all_harness_preflight(files, binary, timeout)
    if profile == PROMISE_PROFILE:
        return promise_harness_preflight(files, binary, timeout)
''')
s=replace_once(s,'''        preflight_ok = (promise_preflight_healthy(preflight) if args.profile in PROMISE_HOST_PROFILES
                        else all(item['verified'] for item in preflight))
''','''        preflight_ok = (promise_all_preflight_healthy(preflight) if args.profile == PROMISE_ALL_PROFILE
                        else promise_preflight_healthy(preflight) if args.profile == PROMISE_PROFILE
                        else all(item['verified'] for item in preflight))
''')
new='''def promise_all_preflight_variants():
    """Four held positive/mismatch pairs, separate from the unchanged host guards."""
    return '''+pprint.pformat(oracle['controls'],width=100,sort_dicts=False).replace('\n', '\n    ')+'''


def promise_all_preflight_healthy(outcomes):
    common_count = 2 * len(promise_preflight_variants())
    if not promise_preflight_healthy(outcomes[:common_count]):
        return False
    expected = {('promise-methods-' + row['name'], mode)
                for mode in ('sloppy', 'strict') for row in promise_preflight_variants()}
    expected.update(('promise-all-' + row['name'], mode)
                    for mode in ('sloppy', 'strict') for row in promise_all_preflight_variants())
    if len(outcomes) != len(expected):
        return False
    observed = set()
    for item in outcomes:
        identity = (item.get('name'), item.get('result', {}).get('mode'))
        if identity not in expected or identity in observed or item.get('verified') is not True:
            return False
        observed.add(identity)
    return observed == expected


def promise_all_harness_preflight(files, binary, timeout):
    # Preserve the original74 rows, their policy and all prerequisite evidence.
    outcomes = promise_harness_preflight(files, binary, timeout)
    by_identity = {(item['name'], item['result']['mode']): item for item in outcomes}
    common_names = ['promise-methods-' + row['name'] for row in promise_preflight_variants()]
    for mode in ('sloppy', 'strict'):
        for row in promise_all_preflight_variants():
            policy = row['completion_policy']
            names = ['assert.js', 'sta.js'] + (['doneprintHandle.js'] if policy else []) + row['includes']
            name = 'promise-all-' + row['name']
            case = dict(id='harness-preflight:' + name, file='<preflight>', mode=mode,
                        metadata=dict(flags=['async'] if policy else [], includes=row['includes'],
                                      features=[], locale=[], negative=None),
                        source=row['source'].encode(), harness=[(n, files['harness/' + n]) for n in names],
                        completion_policy=policy)
            case['case_sha256'] = case_fingerprint(case)
            result = run_case(case, binary, timeout, PROMISE_ALL_FEATURES, PROMISE_ALL_PROFILE)
            required = common_names.copy()
            if row['prerequisite']:
                required.append('promise-all-' + row['prerequisite'])
            prerequisites = [dict(name=required_name, mode=mode,
                verified=by_identity[(required_name, mode)]['verified'],
                case_sha256=by_identity[(required_name, mode)]['result']['case_sha256'],
                source_sha256=by_identity[(required_name, mode)]['result']['source_sha256'])
                for required_name in required]
            item = dict(name=name, expected=row['expected'],
                        verified=(promise_preflight_verified(case, result, row['expected'])
                                  and all(prerequisite['verified'] for prerequisite in prerequisites)),
                        result=result, prerequisites=prerequisites)
            outcomes.append(item)
            by_identity[(name, mode)] = item
    return outcomes


'''
s=replace_once(s,'def check_baseline(previous, current):\n',new+'def check_baseline(previous, current):\n')
publish(rel,s)
print('Wrote two external before/raw/diff sets; Python AST parsing only.')
