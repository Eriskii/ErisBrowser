from pathlib import Path
import ast,copy,difflib,hashlib,json,re,textwrap
D=Path('/tmp/eris-promise-all-1/upstream-profile-plan-1'); A=D.parent; P=A/'upstream-plan-1'; W=A/'worktree'; C=D/'correction-1'; T=D/'tests-before-2'
def digest(b):return hashlib.sha256(b).hexdigest()
def binding(p):
 p=Path(p); b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=digest(b))
def write(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n');return binding(p)
def metadata(source):
 assert source.count('/*---')==source.count('---*/')==1
 fields={};key=None
 for line in textwrap.dedent(source.split('/*---',1)[1].split('---*/',1)[0]).splitlines():
  m=re.fullmatch(r'([A-Za-z][A-Za-z0-9_-]*):[ \t]*(.*)',line)
  if m:key=m[1];assert key not in fields;fields[key]=m[2]
  elif not line.strip() or line.lstrip().startswith('#'):continue
  elif key and line[:1].isspace():fields[key]+='\n'+line
  else:raise AssertionError(line)
 def items(k):
  raw=fields.get(k,'').strip()
  if not raw:return []
  if raw.startswith('[') and raw.endswith(']'):vals=raw[1:-1].split(',')
  else:
   lines=[line.strip() for line in raw.splitlines() if line.strip()];assert all(line.startswith('- ') for line in lines);vals=[line[2:] for line in lines]
  result=[s.strip().strip('\"\'') for s in vals if s.strip()]
  assert len(result)==len(set(result)) and all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in result)
  return result
 assert not fields.get('negative') and not fields.get('timeout')
 return dict(flags=items('flags'),includes=items('includes'),features=items('features'),negative=None,locale=items('locale'))
def identity(path,source,md,mode,files):
 policy=int('async' in md['flags']);names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+md['includes'];assert len(names)==len(set(names))
 value=dict(source_sha256=digest(source),mode=mode,metadata=md,harness=[dict(name=n,sha256=digest(files['harness/'+n])) for n in names],completion_policy=policy)
 encoded=json.dumps(value,sort_keys=True,ensure_ascii=True).encode()
 row=dict(id=path+':'+mode,case_sha256=digest(encoded),policy=policy,harness=names,class_excluded='class' in md['features'])
 return row,encoded
oldoracle=D/'tests-before/raw/tools/promise-all-profile-oracle.json'; oracle=json.loads(oldoracle.read_bytes()); corrected=copy.deepcopy(oracle)
case_metadata=[];payloads={};bindings=[]
for roster,base,manifest in [('case_identities',P/'primary-cache',oracle['expected_manifest']),('old_profile',W/'tests/upstream/test262-promise-methods-async',oracle['old_profile']['manifest'])]:
 files={}
 for row in manifest['files']:
  p=base/row['path']; data=p.read_bytes(); assert len(data)==row['bytes'] and digest(data)==row['sha256'];files[row['path']]=data;bindings.append(binding(p))
 oldrows=oracle['case_identities'] if roster=='case_identities' else oracle['old_profile']['case_identities']; out=[]
 for row in oldrows:
  path,mode=row['id'].rsplit(':',1);source=files[path];md=metadata(source.decode()); assert 'timeout' not in md
  wrong,wrongbytes=identity(path,source,dict(md,timeout=None),mode,files); assert wrong==row,(roster,path,mode)
  right,rightbytes=identity(path,source,md,mode,files);assert {k:v for k,v in right.items() if k!='case_sha256'}=={k:v for k,v in row.items() if k!='case_sha256'}
  assert right['case_sha256']!=wrong['case_sha256'];out.append(right)
  case_metadata.append(dict(profile='promise-all' if roster=='case_identities' else 'promise-methods-async',id=row['id'],metadata=md,wrong_sha256=wrong['case_sha256'],correct_sha256=right['case_sha256']))
  if not payloads.get(roster):payloads[roster]=dict(id=row['id'],metadata=md,wrong=wrongbytes.decode(),correct=rightbytes.decode(),wrong_sha256=wrong['case_sha256'],correct_sha256=right['case_sha256'])
 if roster=='case_identities':corrected['case_identities']=out
 else:
  corrected['old_profile']['case_identities']=out
  corrected['old_profile']['case_identities_sha256']=digest(json.dumps(out,sort_keys=True,separators=(',',':')).encode())
assert len(case_metadata)==654
for row in case_metadata:assert set(row['metadata'])=={'flags','includes','features','locale','negative'}
neworacle=T/'raw/tools/promise-all-profile-oracle.json';write(neworacle,corrected)
oldtest=D/'tests-before/raw/tools/test_test262_promise_all_profile.py'; test=oldtest.read_text();test=test.replace(digest(oldoracle.read_bytes()),digest(neworacle.read_bytes()));assert test!=oldtest.read_text()
needle="            self.assertIs(type(case['completion_policy']), int)\n";assert test.count(needle)==1;test=test.replace(needle,needle+"            self.assertNotIn('timeout', case['metadata'])\n")
needle="        self.assertEqual(identities(cases), old['case_identities'])\n";assert test.count(needle)==1;test=test.replace(needle,"        self.assertTrue(all('timeout' not in case['metadata'] for case in cases))\n"+needle)
newtest=T/'raw/tools/test_test262_promise_all_profile.py';newtest.parent.mkdir(parents=True,exist_ok=True);newtest.write_text(test);tree=ast.parse(test);assert len([x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')])==11
for name in ['tools/promise-all-profile-oracle.json','tools/test_test262_promise_all_profile.py']:
 before=D/'tests-before/raw'/name; after=T/'raw'/name; saved=C/'before'/name;saved.parent.mkdir(parents=True,exist_ok=True);saved.write_bytes(before.read_bytes());diff=''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='hold1/'+name,tofile='hold2/'+name));p=C/'diffs'/(name.replace('/','__')+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(diff)
contract=json.loads((D/'contract.json').read_bytes());contract['paired_guard_literals']['source_oracle']=binding(neworacle);write(D/'contract-2.json',contract)
write(C/'metadata-derivation.json',{'scope':'Independent inert metadata extraction and JSON/hash derivation; no importer/runner module import or test execution.','rows':case_metadata,'literal_first_payloads':payloads})
receipt={'status':'source_derived_oracle_correction_before_profile_production','cause':'Author inserted timeout:null in every metadata object. Existing parse_metadata always emits flags/includes/features/locale/negative, but emits timeout only when a nonempty frontmatter value exists. All330 selected source files omit timeout; case_fingerprint serializes the complete metadata mapping with ordinary json.dumps separators, sort_keys=True and ensure_ascii=True. Extra null therefore changed all654 mode fingerprints.','changed_expectations':{'old_profile_case_sha256':458,'new_profile_case_sha256':196,'old_profile_case_array_sha256':1,'test_oracle_sha256':1,'new_assertions':'Two absence-of-timeout controls added within existing groups; no test group removed or count changed.'},'unchanged':'All source/helper/proof/manifest bytes, cases IDs/modes/harness/policy/class fields, policy hashes, eight new guard literals,37oldguard literals,15roster migrations and all numerical expected counts. No production correction is proposed.','reconstruction':'For every mode, re-extracted source metadata plus timeout:null reproduces the original held hash exactly; removing only that absent field produces the corrected hash. Actual observed hashes are not read as oracle inputs.','retained_hold':binding(D/'tests-before/source-ready.json'),'baseline_failure_log':binding(A/'validation/upstream-parent-preservation-1.log'),'parser_source':binding(W/'tools/import_test262.py'),'fingerprint_source':binding(W/'tools/test262_conformance.py'),'source_shape_lines':{'parse_metadata':list(range(295,317)),'case_fingerprint':list(range(277,284))},'derivation':binding(C/'metadata-derivation.json'),'literal_first_payloads':payloads,'old_case_aggregate_before':oracle['old_profile']['case_identities_sha256'],'old_case_aggregate_after':corrected['old_profile']['case_identities_sha256'],'input_bindings':bindings,'execution':False,'live_edits':False}
write(C/'receipt.json',receipt)
review={'status':'corrected_source_only_tests_before_production','prior_review':binding(D/'tests-before/source-review.json'),'correction_receipt':binding(C/'receipt.json'),'groups':11,'numeric_counts_guards_profiles_and_migrations_unchanged':True,'original11assertiongroups_retained':True,'source_derived_fingerprint_rows':654,'root_parent_control_rerun_pending':True,'independent_peer_pending':True,'execution':False,'live_edits':False};write(T/'source-review.json',review)
oldhold=json.loads((D/'tests-before/source-ready.json').read_bytes());hold=copy.deepcopy(oldhold); replacements={str(oldoracle):neworacle,str(oldtest):newtest,str(D/'contract.json'):D/'contract-2.json',str(D/'tests-before/source-review.json'):T/'source-review.json'}
hold['bindings']=[binding(replacements.get(row['path'],row['path'])) for row in oldhold['bindings']];hold['bindings'] += [binding(C/'receipt.json'),binding(C/'metadata-derivation.json'),binding(C/'derive.py')];hold['status']='corrected_ready_for_independent_source_review';hold['retained_original_hold']=binding(D/'tests-before/source-ready.json');hold['correction']=binding(C/'receipt.json');write(T/'source-ready.json',hold)
write(D/'source-ready-2.json',{'schema':'eris-bounded-profile-plan-v2','status':'corrected_plan_and_tests_frozen_no_production','retained_prior_hold':binding(D/'source-ready.json'),'selected_tests_hold':binding(T/'source-ready.json'),'selected_contract':binding(D/'contract-2.json'),'correction':binding(C/'receipt.json'),'execution':False,'production':False,'live_edits':False})
for p in [neworacle,T/'source-ready.json',D/'source-ready-2.json',C/'receipt.json']:print(json.dumps(binding(p)))
