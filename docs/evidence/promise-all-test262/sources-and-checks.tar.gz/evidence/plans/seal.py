from pathlib import Path
import json,hashlib,ast,difflib,re
D=Path('/tmp/eris-promise-all-1/upstream-profile-plan-1');W=Path('/tmp/eris-promise-all-1/worktree')
def bind(p):
 p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def write(n,v):
 p=D/n;assert not p.exists();p.write_text(json.dumps(v,indent=2)+'\n');return bind(p)
op=D/'tests-before/raw/tools/promise-all-profile-oracle.json';o=json.loads(op.read_text());t=D/'tests-before/raw/tools/test_test262_promise_all_profile.py';s=t.read_text();a=ast.parse(s)
assert len([x for x in ast.walk(a) if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')])==11
assert "ORACLE_SHA = '"+bind(op)['sha256']+"'" in s
assert len(o['controls'])==8 and len(o['case_identities'])==196 and len(o['old_profile']['case_identities'])==458
assert [r['policy'] for r in o['case_identities']].count(1)==114
assert [r['policy'] for r in o['case_identities']].count(0)==82
assert len({r['id'] for r in o['case_identities']})==196
assert len(o['old_profile']['controls'])==37
assert sum(r['class_excluded'] for r in o['case_identities'])==4
m=D/'migrations-before/selection.json';md=json.loads(m.read_text());assert len(md['paths'])==15
for row in md['paths']:
 for key in ['before','raw','diff']:assert bind(row[key]['path'])==row[key]
 b=Path(row['before']['path']).read_text();r=Path(row['raw']['path']).read_text();assert b==(W/row['path']).read_text()
 assert ''.join(difflib.unified_diff(b.splitlines(True),r.splitlines(True),fromfile='a/'+row['path'],tofile='b/'+row['path']))==Path(row['diff']['path']).read_text()
 # The additions are profile literals/condition spelling, never expected counts or hashes.
 before_numbers=re.findall(r'\b\d+\b',b);after_numbers=re.findall(r'\b\d+\b',r);assert before_numbers==after_numbers,row['path']
 ast.parse(r)
inputs=json.loads((D/'source-inputs.json').read_text())
for row in inputs['bindings']:assert bind(row['path'])==row
notes='''Bounded Promise.all Test262 profile plan and held verifier controls. No production implementation, imports, JS/Rust/Python test execution, compiler/browser/network request or live edits were performed here. Inert JSON/Git-tree/blob hashing, text generation, diff checks and Python AST syntax parsing only.

The new promise-all profile selects all98 immediate Promise/all sources at7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd:196sloppy/strict modes,57async sources/114modes and41sync sources/82modes. Six original helpers and two legal files are authenticated through seven original root-linked proof documents totaling67567bytes. Root's broader retrieval archive has21documents; this selected subset does not rewrite any proof response.

Both class-tagged sources/four modes stay in the denominator. Two additional sources contain untagged class syntax, one also0n. No new source filter is proposed; the unchanged adapter must produce its actual outcomes. No real outcome count or conformance forecast is held. The192failed/4unsupported report fixture is deliberately synthetic mocked policy data.

The prior promise-methods-async232/458 profile, original253manifest-bound payloads, manifest, case fingerprints, policy hash and37guards/74rows remain exact. The fifteen old test adapters add only a new-profile exclusion to historical roster snapshots; all old counts and hashes remain unchanged.

New controls are four literal positive/mismatch pairs in both modes, added after the unchanged74common host observations, for90total. They exercise all metadata/nonconstructability, ordered fulfillment, exact rejection and generic iterator+once behavior. New controls depend on all37common outcomes in their mode; each mismatch also requires its corresponding positive. Missing/duplicate/wrong-mode/failed controls block all196 and refuse baseline recording. No incidental exception can count as a verified mismatch.

The new Python test module has11groups and mocks network/process execution. One unchanged-old-profile group is parent-compatible using the existing corpus. The other10require the new profile/corpus or selected helper APIs; no parent pass/fail run is claimed. All actual guard and upstream executions remain root-owned after separate production authorization and after corePromise.all publication. The tools before bytes can rebase unchanged to that commit.
'''
(D/'README.txt').write_text(notes)
review={'status':'frozen_source_only_tests_before_profile_production','groups':11,'parent_compatible_group':'test_existing_232_458_profile_bytes_identities_guards_and_policy_are_unchanged','remaining_groups_require_new_profile':10,'preflight_guards':{'old_rows':74,'new_rows':16,'combined':90},'upstream_modes':196,'source_counts_and_hashes':'Independent pinned metadata plus full binary Git-tree/blob reconstruction; no project importer function executed.','syntax':'ast.parse on authored test modules and migrated test files only, not test execution.','migrations':{'paths':15,'exact_diff_reconstruction':True,'all_numeric_literals_unchanged':True,'current_before_bindings_verified':True},'old_profile':{'case_identities':458,'source_files':232,'policy_sha256':o['old_profile']['policy_sha256'],'unchanged_guards':37},'implementation_seams':'Explicit contract.json. No importer/runner/Runtime production authored. Existing ERJS2/ERJR3 host semantics and all caps stay selected.','observation_scope':'No actual upstream outcomes are predicted. Both metadata exclusions and untagged syntax hazards stay in denominator.','execution':False,'live_edits':False}
write('tests-before/source-review.json',review)
files=[op,t,D/'tests-before/source-review.json',D/'contract.json',D/'source-inputs.json',D/'README.txt',m]
for row in md['paths']:files.extend(Path(row[key]['path']) for key in ['before','raw','diff'])
hold={'schema':'eris-upstream-profile-tests-before-v1','status':'ready_for_independent_source_review','profile':'promise-all','revision':'7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd','source_files':98,'mode_cases':196,'groups':11,'old_migration_paths':15,'bindings':[bind(p) for p in files],'execution':False,'production':False,'live_edits':False,'core_checkpoint':'Separate from current corePromise.all source1 and publication; prospective tools before bytes unchanged.'}
write('tests-before/source-ready.json',hold)
write('source-ready.json',{'schema':'eris-bounded-profile-plan-v1','status':'plan_and_tests_frozen_no_production','selected_tests_hold':bind(D/'tests-before/source-ready.json'),'selection':bind('/tmp/eris-promise-all-1/upstream-plan-1/selection-before-fetch.json'),'source_inputs':bind(D/'source-inputs.json'),'contract':bind(D/'contract.json'),'authoring_tools':[bind('/tmp/eris-promise-all-1/author-upstream-profile.py'),bind(D/'seal.py')],'limits_and_protocol_unchanged':True,'upstream_originals_unchanged':True,'old_profile_unchanged':True,'live_edits':False,'execution':False})
print(json.dumps(bind(D/'source-ready.json')))
print(json.dumps(bind(D/'tests-before/source-ready.json')))
