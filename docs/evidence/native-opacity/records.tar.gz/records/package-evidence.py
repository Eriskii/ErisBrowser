from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
A=Path(__file__).resolve().parent;W=A/'worktree';P=Path('/tmp/eris-next-rendering-assessment-1')
DEST=W/'docs/evidence/native-opacity';DEST.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def json_bytes(x):return (json.dumps(x,indent=2)+'\n').encode()
changed=sorted(set(subprocess.check_output(['git','diff','--name-only'],cwd=W,text=True).splitlines()+subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=W,text=True).splitlines()))
changed=[s for s in changed if not s.startswith('docs/evidence/native-opacity/') and s!='docs/evidence/vulkan-native-opacity.json']
source=[];entries={}
for name in changed:
 b=(W/name).read_bytes();entries['final-source/'+name]=b;source.append({'path':name,'bytes':len(b),'sha256':sha(b)})
(A/'final-source.json').write_bytes(json_bytes(source))
for p in sorted(A.rglob('*')):
 if not p.is_file() or p.is_symlink():continue
 rel=p.relative_to(A)
 if rel.parts[0]=='worktree' or '__pycache__' in rel.parts:continue
 if len(rel.parts)==1 and p.name.startswith(('eris-browser-','eris-vulkan-')):continue
 if p.suffix=='.pyc':continue
 entries['records/'+str(rel)]=p.read_bytes()
for p in sorted(P.iterdir()):
 if p.is_file():entries['preparation/'+p.name]=p.read_bytes()
items=[{'path':k,'bytes':len(v),'sha256':sha(v)} for k,v in sorted(entries.items())]
archive=DEST/'records.tar.gz'
with archive.open('xb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tf:
   for name,data in sorted(entries.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tf.addfile(info,io.BytesIO(data))
index={'schema':1,'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip(),'archive':{'path':'records.tar.gz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes())},'payload_files':len(items),'payload_bytes':sum(r['bytes'] for r in items),'members':items,'omitted':'Compiled executables and the worktree are omitted; executable hashes/build logs and changed source files are retained. Prior failed attempts remain unchanged.'}
(DEST/'index.json').write_bytes(json_bytes(index))
print(json.dumps({'archive':index['archive'],'payload_files':len(items),'payload_bytes':index['payload_bytes'],'source_files':len(source),'index_sha256':sha((DEST/'index.json').read_bytes())}))
