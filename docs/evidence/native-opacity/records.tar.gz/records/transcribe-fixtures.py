import json,shutil
from pathlib import Path
A=Path(__file__).resolve().parent;W=A/'worktree';S=Path('/tmp/eris-next-rendering-assessment-1/literal-fixtures.json')
D=W/'tools/vulkan-raster-probe/opacity-fixtures';D.mkdir(exist_ok=True);shutil.copyfile(S,D/'literal-fixtures.json')
data=json.loads(S.read_text())
def f(v): return str(float(v))
def rect(v): return 'Rect::new('+', '.join(map(f,v))+')'
def array(v):return '['+', '.join(map(str,v))+']'
out=['//! Literal fixtures transcribed from opacity-fixtures/literal-fixtures.json.', '//! Expectations were authored before candidate execution, not painted from it.', 'use eris_raster_core::{Command, Frame, Profile, Rect, Result, SourceImage, SourceMask, plan_with_masks_for_profile};','use crate::reuse_fixtures::Fixture;', 'pub fn fixtures() -> Result<Vec<Fixture>> {','    let mut cases = Vec::new();']
for c in data['cases']:
 fr=c['frame'];images=c.get('images',[]);masks=c.get('masks',[])
 out+=['    {',f'        let frame = Frame {{ width: {fr["width"]}, height: {fr["height"]}, clear: 0x{fr["clear"]}, caller_clip: {rect(fr["caller_clip"])}, document_offset: ({f(fr["document_offset"][0])}, {f(fr["document_offset"][1])}), viewport_offset: ({f(fr["fixed_offset"][0])}, {f(fr["fixed_offset"][1])}) }};','        let commands = [']
 for cmd in c['commands']:
  op=cmd['op']
  if op=='rect':s=f'Command::Rect {{ rect: {rect(cmd["rect"])}, rgba: {array(cmd["rgba"])}, radius: 0.0 }}'
  elif op=='push_opacity':s=f'Command::PushOpacity({f(cmd["value"])})'
  elif op=='pop_opacity':s='Command::PopOpacity'
  elif op=='push_clip':s=f'Command::PushClip({rect(cmd["rect"])})'
  elif op=='pop_clip':s='Command::PopClip'
  elif op=='push_fixed':s='Command::PushFixed'
  elif op=='pop_fixed':s='Command::PopFixed'
  elif op=='image':s=f'Command::Image {{ rect: {rect(cmd["rect"])}, source: {next(i for i,x in enumerate(images) if x["id"]==cmd["id"])} }}'
  elif op=='mask':
   i=next(i for i,x in enumerate(masks) if x['id']==cmd['id']);s=f'Command::Glyph {{ source: {i}, rows: {i}, y: {masks[i]["y"]}, rgba: {array(cmd["rgba"])} }}'
  else:raise ValueError(op)
  out+=['            '+s+',']
 out+=['        ];','        let images = [']
 out+=['            SourceImage { width: '+str(x['width'])+', height: '+str(x['height'])+', rgba: &'+array(x['rgba'])+' },' for x in images]
 out+=['        ];','        let masks = [']
 out+=['            SourceMask { width: '+str(x['width'])+', height: '+str(x['height'])+', coverage: &'+array(x['coverage'])+' },' for x in masks]
 out+=['        ];','        let rows: &[&[i32]] = &['+', '.join('&'+array(x['row_origins']) for x in masks)+'];','        let plan = plan_with_masks_for_profile(Profile::Native, frame, &commands, &images, &masks, rows);']
 if c['native_expectation'].startswith('admit'):
  out += ['        let plan = plan?;']
  if c['native_expectation']=='admit_in_certified_domain':out += ['        if plan.group_scratch_bytes() == 0 { return Err("literal group lost its native scratch route".into()); }']
  else:out += ['        if plan.group_scratch_bytes() != 0 { return Err("zero/unit scope unexpectedly allocated a layer".into()); }']
  out += [f'        cases.push(Fixture {{ name: "{c["name"]}", plan, expected: vec!['+', '.join('0x'+x for x in c['expected_pixels'])+'] });']
 else:
  expected='unsupported opacity value' if 'outside_exact_grid' in c['native_expectation'] else 'opacity group requires opaque rectangular backing'
  out += [f'        if plan.as_ref().err().map(String::as_str) != Some("{expected}") {{ return Err("{c["name"]}: refusal mismatch".into()); }}']
 out+=['    }']
out+=['    Ok(cases)','}']
(W/'tools/vulkan-raster-probe/src/opacity_fixtures.rs').write_text('\n'.join(out)+'\n')
print('Transcribed 9 native cases and 3 explicit refusals; literal JSON preserved')
