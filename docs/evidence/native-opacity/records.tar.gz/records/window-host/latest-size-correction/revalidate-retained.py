#!/usr/bin/env python3
"""Read retained run2 only; never invoke a browser or controller."""
from pathlib import Path
import copy
import hashlib
import json
import sys

W = Path('/tmp/eris-vulkan-opacity-1/worktree')
A = W.parent
sys.path.insert(0, str(W / 'tools'))
import native_opacity_host as host


def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


inputs = [Path(__file__), W / 'tools/native_opacity_host.py', W / 'tools/test_native_opacity_host.py']
inputs += [p for p in sorted((A / 'window-run-2').iterdir()) if p.is_file()]
before = [binding(p) for p in inputs]
result = {'scope': 'posthoc data-only retained-log validation; no browser/controller/compiler/GPU run',
          'inputs_before': before, 'normalizations': [], 'runs': [], 'success': False}
try:
    for label, verified in [('opacity-click-verified', True), ('opacity-normal', False)]:
        directory = A / 'window-run-2'
        original = json.loads((directory / (label + '.window-control.json')).read_text())
        record = copy.deepcopy(original)
        if not verified:
            old = record['observations']['scope']
            assert old == 'acquired texture before compositor; two opacity states among four serials, no performance claim'
            new = 'native presentation without CPU reference; initial opacity state, no performance claim'
            record['observations']['scope'] = new
            result['normalizations'].append({'run': label, 'path': 'observations.scope', 'old': old, 'new': new,
                                             'application': 'in-memory copy only; retained original unchanged'})
        checked = host.validate((directory / (label + '.stdout.log')).read_bytes(),
                                (directory / (label + '.stderr.log')).read_bytes(), verified, record,
                                Path(record['commands'][0]['argv'][0]))
        result['runs'].append({'label': label, 'observations': checked})
    result['inputs_after'] = [binding(p) for p in inputs]
    assert result['inputs_after'] == before
    result['success'] = True
except BaseException as error:
    result['error'] = {'type': type(error).__name__, 'message': str(error)}
    raise
finally:
    with (A / 'window-host/posthoc-run2-review.json').open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
print('retained run2: both modes clear; original records and logs unchanged')
