# Owned native opacity window check

`tools/native_opacity_host.py` runs two separate windows: four acquired-texture Canvas comparisons including both sides of one actual mouse click, followed by a normal native run without any CPU reference or verification. It is source-ready; actual window/Vulkan execution remains root-owned.

The new helper imports the existing ownership, loader, subreaper, bounded process/output, delayed-document server, stderr drain and cleanup mechanisms. Existing host files are unchanged. A process-local route context maps the same two bounded GETs to `/admitted.html` and `/vulkan-opacity.png`, serving the exact public example bytes. The server's original physical1280x880/loading gate opens only after owned PID sizing/focus/pointer preparation. The immutable HTML/PNG must both finish. Maximums remain48 controller commands,8 accepted/4 active connections,8KiB request headers,2MiB captured output,4096 lines,16KiB lines,2..20 browser seconds and an outer deadline at least10 seconds longer (maximum120). There are no retries.

The click is window coordinate(20,96): public page point(20,20) plus the76px browser toolbar. Native physical dimensions and owned compositor client size must both be1280x880. Temporary compositor queries retain only the owned client; process PID, parent, group and start time are checked before/after control, with the child unreaped until no more controls are possible. Geometry is reread before click. Commands are `focuswindow pid:PID`, `movecursor X+20 Y+96`, then one `sendshortcut ,mouse:272,pid:PID`. This uses the documented [Hyprland dispatcher key/window contract](https://wiki.hypr.land/0.52.0/Configuring/Dispatchers/) and is accepted only if the changed acquired frame subsequently proves delivery.

The ordinary scene line is paired by serial with root's new opacity line. Both must prove two groups and262144 scratch bytes. Initial composite numerator sum256 must reach an exact acquired-texture comparison before the one mouse dispatch. At least one later compared serial must have sum320. `--vulkan-verify-frames` counts serials, so the immediate pre-worker redraw may still show256. After the first changed verification only, one targeted Escape redraw at a time completes quota4; these redraws are not claimed to be extra DOM states. Four exact frames compare18,022,400 bytes before the desktop compositor. The normal run proves a nonzero-scratch native presentation, all reference flags false, no click/redraw controls and zero compared bytes. Any unexpected fallback after admission, missing phase, incomplete quota, crossed identity or hidden unhealthy result fails.

A proposed root command after a release binary is held is:

```sh
python3 tools/native_opacity_host.py --binary /absolute/held/eris-browser --binary-sha256 HELD_SHA256 --loader-directory /absolute/held/vulkan-loader --output /tmp/eris-vulkan-opacity-1/window-run-1 --window-seconds 12 --timeout 30 --allow-experimental-gpu
```

The command is a proposal, not an executed receipt. No `--no-scripts` or headless-only `--click` is used. No screenshots, compositor pixels, arbitrary transparent opacity, timing improvement or driver isolation is claimed.

Eleven synthetic tests exercise the log and retained HTTP receipt oracles, including healthy positive paths, unchanged pre-click frames exhausting a quota, scratch/serial/mode mismatch, duplicate/stale verification, phase reversal, late fallback and modified fixed-response receipts. The first nine parser groups passed before the retained-response/mode peer correction; the final eleven pass with their complete logs retained. No browser, worker, window, shader or GPU was launched by these tests.
