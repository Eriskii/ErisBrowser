from pathlib import Path
import hashlib,json,re
A=Path(__file__).resolve().parent;W=A/'worktree';D=W/'docs/evidence';I=D/'native-opacity/index.json';index=json.loads(I.read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p):return json.loads((A/p).read_text())
def rust_count(name):
 r=load('validation/'+name+'.json');assert r['exit']==0
 log=A/'validation'/r['log'];assert digest(log)==r['sha256']
 return sum(map(int,re.findall(r'test result: ok\. (\d+) passed;',log.read_text())))
def py_count(name):
 r=load('validation/'+name+'.json');assert r['exit']==0
 log=A/'validation'/r['log'];assert digest(log)==r['sha256'];m=re.search(r'Ran (\d+) tests in ',log.read_text());assert m
 return int(m[1])
rust={n:rust_count(n) for n in ['core-cpu-188-1','core-gpu-188-2','bridge-native-188-1','browser-opacity-188-2','probe-tests-188-1','native-full-188-2']}
assert list(rust.values())==[97,128,63,2,7,2139],rust
py={n:py_count(n) for n in ['root-python-final','probe-python-1']}
for n in ['core-clippy-188-1','probe-clippy-188-1','native-clippy-188-final']:
 assert load('validation/'+n+'.json')['exit']==0
for name in ['offscreen-1','no-group-reuse-1','window-run-2']:
 assert load(name+'/host-results.json')['success']
summary={
 'schema':1,'checkpoint':'Bounded Vulkan nested opacity','base_commit':index['base_commit'],
 'status':'Implemented and locally validated within the explicit admission domain; full browser requirements remain unfinished.',
 'package':{'path':'native-opacity/index.json','sha256':digest(I),'archive':index['archive'],'payload_files':index['payload_files'],'payload_bytes':index['payload_bytes']},
 'record_paths':'Paths below refer to records/ members inside native-opacity/records.tar.gz, except preparation/ and final-source/ paths.',
 'admission':{'opacity':'k/256 for integer 1..255; 0 suppresses pixels after validation; 1 preserves the target','backing':'First effective direct opaque unrounded rectangle covers the full conservative descendant union in every materialized group.','scratch':'Disjoint cropped premultiplied RGBA16 regions, 8 bytes/pixel; no intraframe alias/reuse.','limits_raised':False,'planned_gpu_bytes':16777216,'padded_invocations':4000000,'commands':256,'mixed_scopes':32,'maximum_phases':4,'legacy':'Probe APIs still reject opacity; original four shaders remain byte-exact.'},
 'builds':{n:load(p) for n,p in [('browser','native-release-1.json'),('opacity_checker','checker-build-2.json'),('no_group_checker','reuse-check-build-1.json')]},
 'build_binding_notes':{'check':'final-build-source-check.json','production_unchanged_after_browser_build':True,'later_changes':'Only cfg(test) assertions in native_scene.rs and test interpreter parentheses in native/opacity_tests.rs changed after browser build.'},
 'validation':{'rust_version':'1.88.0','rust_passed_by_command':rust,'python_passed_by_command':py,'strict_clippy':['validation/core-clippy-188-1.json','validation/probe-clippy-188-1.json','validation/native-clippy-188-final.json'],'formatting':'validation/format-final.json','included_ignored_confinement_tests':True,'CI_for_this_commit':'Not included in this local checkpoint; preceding publication CI is retained separately at preceding-ci.json.'},
 'offscreen':{'report':'offscreen-1/host-results.json','review':'offscreen-result-review.json','adapters':3,'names':['NVIDIA GeForce RTX 4070 SUPER','AMD RADV RAPHAEL_MENDOCINO','llvmpipe LLVM21.1.8'],'literal_frames':54,'reuse_frames':42,'total_frames':96,'compared_bytes':2472,'cancellation_checkpoints':24,'successful_sequence_allocations':21,'successful_sequence_reuses':21,'successful_sequence_evictions':21,'planner_refusal_cases':3,'formats':['Bgra8Unorm','Rgba8Unorm'],'reference':'Fixed independent literal arrays; 3 refusal assertions execute on every adapter run before Vulkan, not GPU frames.','acquired_surface':False},
 'no_group_regression':{'report':'no-group-reuse-1/host-results.json','adapters':3,'frames':84,'compared_bytes':4680,'reference':'Unchanged preexisting literal fixture inventory and expected reuse sequence.'},
 'window':{'report':'window-run-2/host-results.json','surface':'NVIDIA RTX4070SUPER Bgra8Unorm Srgb Opaque Fifo','size':[1280,880],'verified_serials':[8,9,10,11],'opacity_numerator_sums':[256,256,320,320],'compared_bytes':18022400,'clicks':1,'escape_redraws':1,'group_scratch_bytes':262144,'distinct_dom_states':2,'separate_reference_free_window':True,'all_owned_children_reaped':True,'surviving_owned_descendants':0,'scope':'Acquired texture bytes before compositor; normal separate run establishes native route with no reference, not pixel comparison.','executed_host_hold':'window-host/source-ready-3.json','final_host_hold':'window-host/source-ready-4.json','posthoc_validation':'window-host/posthoc-run2-review.json','posthoc_note':'After run2, retained parser takes latest physical-size observation and reports accurate normal-run scope. Existing logs revalidated without another engine run. Only that descriptive scope field is normalized in memory; original raw receipts remain unchanged.'},
 'retained_failures':[
 {'record':'validation/core-gpu-188-1.json','cause':'SurfaceLayout::for_plan omitted the new scratch reservation; one-line accounting fix.'},
 {'record':'validation/browser-opacity-188-1.json','cause':'New witness incorrectly expected Button element hit instead of its Text child. Corrected exact child/parent/literal contract and source-derived nontext count; pixel expectations unchanged.'},
 {'record':'validation/native-clippy-188-1.json','cause':'Three test-only precedence/filter-map lint findings corrected.'},
 {'record':'validation/native-full-188-1.json','cause':'Old zoom assertion expected empty grid-aligned opacity to refuse; original case retained as positive and non-grid refusal added.'},
 {'record':'window-run-1/host-results.json','cause':'New observer rejected legitimate pre-release startup sizes. Browser killed before document release; supervisor reaped two residual owned descendants, cleanup complete. Passing second attempt preserved separately.'}],
 'additional_reviews':['documentation-review.json','host/offscreen-layout-review.json','window-host/script-source-review.json','browser/html-correction-followup.json'],
 'proofs':['preparation/numerical-contract.md','preparation/literal-fixtures.json','preparation/additional-rounding-fixtures.json','preparation/gpu-interface.md'],
 'not_established':['arbitrary non-grid opacity','transparent-backed groups','general CSS compositing','broader native scene/viewport admission','GPU font shaping or outline rasterization','compositor/scanout pixel equality','driver isolation','production security','full web compatibility','performance within 30% of Chromium']}
(D/'vulkan-native-opacity.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'path':str(D/'vulkan-native-opacity.json'),'sha256':digest(D/'vulkan-native-opacity.json'),'rust':rust,'python':py}))
