# Exact first domain: opaque-backed groups with opacity k/256

This narrows the broader milestone in `assessment.md` before implementation. It proposes exact native rendering of opaque rectangular faded cards, including nested opaque-backed cards and translucent text/image/rounded decoration over their backing. Unsupported transparent group surfaces and other opacity values retain the complete CPU route. There is no numerical tolerance or CPU behavior change.

## Admission certificate

- Preserve existing full input validation and combined scope typing. Recognize a finite opacity exactly equal to `k/256`, integer `k` from 0 through 256; do not round an arbitrary opacity onto this grid. Canonicalizing either signed zero to k=0 preserves existing zero behavior.
- `k=256` is a typed no-layer scope. This is source-specific: `Canvas::paint_with_viewport` at `graphics.rs:803` creates a layer only when `opacity < 1.0`, and pop composites only when that flag is true. A unit scope retains its current destination, including an enclosing RGBA16 layer. Introducing a layer would change existing pixels.
- `k=0` suppresses its descendants' pixel work after full validation. It needs no backing certificate or scratch region. Do not let suppression bypass malformed input or scope validation.
- For each remaining nonempty group, conservatively bound all contributing lowered descendants in absolute pixel coordinates. Its first retained contributing draw must be an unrounded, alpha-255 rectangle whose **actual group-mode covered pixel rectangle contains the entire group region**. It must execute before any child group composite. Do not infer coverage from the DOM element box, source color alone, or a rounded mask's rectangle. An image is not a backing certificate in this first version.
- Every nested materialized group must satisfy the same certificate. The outer group's first backing covers its complete region, which contains every child region. Thus every group source pixel and every nested destination pixel is opaque at pop. The root destination is already opaque RGB.
- Bounds include fixed descendants after coordinate/clip changes. A fixed child beyond the backing expands the group region and fails the certificate, causing complete CPU fallback. A fixed child outside an ancestor clip but still inside the backing remains eligible.
- All admitted primitives after the backing may have normal source alpha or partial glyph/rounded coverage. Integer source-over preserves the established destination alpha 65535. Shapes outside the backing, transparent group holes, image-only groups and rounded-only group backgrounds currently fall back. A rectangular opaque backing with rounded decorations inside is eligible; this does not claim isolated rounded translucent cards are supported.

An empty group has no pixel output or scratch region after complete validation. Conservative bounds are acceptable even if they make the certificate fail; underestimating bounds is not. Start with one certificate rectangle rather than unioning many opaque regions. Work/byte/source/preparation limits and Probe refusal behavior remain unchanged.

## Exact integer primitive blend

Use premultiplied RGBA16 represented by four logical u16 channels packed into two u32 words; WGSL u64 is not needed. For primitive source RGB component `c` and effective alpha `a`, both 0..255:

```
a = floor(color_alpha * coverage / 255)       # ordinary image/rect coverage is 255
A = a * 257
S = floor((c * A + 127) / 255)
O = S + floor((D * (65535 - A) + 32767) / 65535)
```

Use the same over expression for alpha with source component A. This is exactly the current `Canvas::blend` plus `premultiplied_over`, not newly quantized opacity. The largest multiply-plus-bias is `65535*65535+32767 = 4,294,868,992`, below `u32::MAX`. Each channel is bounded by its alpha and the result is at most 65535. The backing starts at alpha 65535; thereafter output alpha is `A + (65535-A) = 65535` exactly. Primitive geometry, image sampling and coverage production retain their existing semantics.

## Exact group pop

Let S and D be source and destination premultiplied 16-bit channels. The source alpha certificate makes the CPU's `source_alpha / 65535` exactly one. For opacity k/256, its inverse is exactly `(256-k)/256`.

```
N = S*k + D*(256-k)
parent_channel16 = floor((N + 128) / 256)
```

For a root destination RGB channel d, first use D=257*d, then:

```
N = S*k + (257*d)*(256-k)
root_channel8 = floor((N + 32896) / 65792)     # 65792 = 256*257
```

All shader arithmetic in these expressions is u32. Do not use WGSL floating division or `round` for pop. The alpha component of a nested pop is exactly 65535, preserving the induction.

Why this matches the CPU, including its intermediate f32 operations:

1. Every S, D, k and 256-k is exactly representable; `0 <= N <= 65535*256 = 16,776,960 < 2^24`. Both weighted products and their sum are exact binary32 values divided by 256. There is no precision loss in the CPU's multiply/add path, whether combined or separate.
2. A nested group's final `round()` on N/256 is exactly half-up for these nonnegative values, implemented by the first integer formula. Arbitrary previous 16-bit channel values are permitted; they need not be multiples of 257.
3. A root group's final division is `(N/256)/257 = N/65792`, lying in `[0,255]`. If it is not exactly a half-integer, its distance from the closest half-integer is at least `1/65792`, greater than the maximum binary32 **half ULP** in this range, `2^-17`. Correctly rounded CPU division cannot cross that integer-rounding boundary. If it is exactly a half-integer, that value is exactly representable and the CPU rounds it upward. This proves the second integer formula. The argument compares with half an ULP, not a whole ULP.
4. Numerator plus either bias remains within u32. The shader avoids floating contraction, division approximation and tie policy entirely, while the CPU is left unchanged.

Dyadic opacity **alone** is not the certificate. A transparent source has arbitrary RGBA16 alpha; CPU pop then evaluates `alpha/65535` and subsequent f32 operations. No equivalence proof for that broader expression is supplied. Likewise this document does not claim that arbitrary f32 opacity can be quantized without changing output.

## Why a direct WGSL translation is insufficient

WGSL `round` chooses even at halfway values; Rust f32 `round` chooses away from zero. WGSL permits floating reassociation/fusion, does not mandate one rounding direction for inexact arithmetic, and allows division error. Integer pop avoids those differences in the certified domain. [WGSL numeric rules](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#floating-point-evaluation), [WGSL round](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#round-builtin), [Rust round](https://doc.rust-lang.org/std/primitive.f32.html#method.round).

The simplest tie fixture paints opaque red 65 at opacity 0.5 over black: expected red 33 (`0x210000`), not 32. The fixture set also fixes nested and translucent-input values. They are authored expectations, not outputs collected from a candidate.

## Geometry and ownership details that remain mandatory

Inside a materialized CPU group, even an alpha-255 unrounded rectangle runs through `Canvas::blend`; it uses half-open integer-origin clip containment. The root opaque rectangle fast path does not make that call. Native lowering must select the group-mode containment behavior when determining bounds and the backing certificate, preserving the existing f32 rectangle reconstruction. Unit scopes do not switch this mode on their own.

Use each group's conservative region for storage and dispatch, with absolute placement and checked local indexing. Groups remain isolated in the same paint order; no child alpha multiplication and no fusion of successive pops. Sum scratch storage for all retained regions, charge their clear/composite passes, preserve current CPU preparation estimates, and include the region arena in Native lease compatibility, retirement and destruction. The numerical proof is not an exemption from any scene ledger.

`literal-fixtures.json` freezes a small implementation-independent command vocabulary, sources and full packed RGB arrays. These are intended to be transcribed into future tests without changing expectations. No JavaScript parser, painter, planner or engine was executed. The three fallback rows remain positive CPU rendering expectations with explicit native refusal; they are not native successes. One deliberately rejects a union that happens to end opaque because the first single-rectangle certificate is insufficient; that conservative refusal can be revisited later. The unit-scope fixture requires the current no-layer behavior. Future native tests must assert the selected route as well as every output pixel.
