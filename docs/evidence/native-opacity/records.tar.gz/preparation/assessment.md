# Proposed next rendering milestone: bounded native group opacity

Recommend adding nested CSS group opacity to the existing optional native Vulkan raster route, within the current command, scope, work and memory limits. A small faded card containing overlapping backgrounds, text, rounded corners and an image should remain on the native route after a real click changes its opacity. This is a rendering capability milestone, not a timing or audit feature.

Current inspected source is published clone commit `3ee89d4835a40d652b1be6fe73cff425f7598289`. This assessment contains no implementation, fixture execution, JavaScript parsing, compiler or GPU run. The current Object.hasOwn upstream increment and closed clone artifacts are untouched. Source hashes are in `source-inputs.json`.

## The actual gap

The rendering docket explicitly lists nested opacity in `docs/ROADMAP.md` under Vulkan acceptance work. The current native documentation likewise lists group opacity as unfinished. This is supported by concrete code, rather than inferred from an old roadmap:

| Existing boundary | Current behavior |
| --- | --- |
| `src/layout.rs`, opacity chains and paint-order assembly around 2110–2406 | Builds typed `PushOpacity`/`PopOpacity` around stacking groups, preserving clip/fixed relations. |
| `src/worker/codec.rs`, opacity command encoding/decoding and scope tests | Carries existing opacity commands across the worker boundary; no new DOM, CSS property or wire command is needed. |
| `src/graphics.rs:237`, `begin_opacity`, `blend`, `end_opacity` | CPU painter has nested premultiplied RGBA16 intermediate surfaces and composites a group once. |
| `src/graphics/raster_bridge/native.rs:273` | Immediately refuses every opacity command as `UnsupportedOpacity`, including opacity zero and one. |
| `crates/raster-core/src/lib.rs` and `scope.rs` | Core command/coordinate model represents rectangles, images, glyphs, clip and fixed scopes, but no opacity target. |
| `src/browser.rs:1518` and `src/presenter/vulkan/native.rs:117` | Refusal selects complete CPU painting; native owner accepts only an admitted immutable plan. |

The user currently gets correctly faded pixels through CPU fallback. The improvement is that these already-supported pages can be composited by the native shaders without forcing a full CPU-painted upload. Source inspection establishes no speedup. The script peer independently confirmed that opacity is the only represented DrawCommand family categorically refused by Native; Rect, rounded lowering, Image, Line, Text, Clip and Fixed already have handling.

## Recommended bounded scope

Admit existing finite opacity values in `[0,1]`, including nested groups, for Native plans whose complete lowered scene fits the unchanged limits. Preserve the combined 32-scope limit, 256 original commands and 256 lowered operations, four phases, 4,000,000 padded invocations, 16 MiB explicit GPU buffers, existing source/mask caps and presenter ownership limits. Do not promise that every opacity page or maximum-sized window will fit.

Keep Probe entry points and their frozen refusal fixtures unchanged. Introduce Native-only typed opacity commands and target metadata, with full validation of hidden/zero-opacity content before admission. Unit-opacity groups must preserve scope typing without creating a layer; zero-opacity groups can suppress drawing after input validation. Neither case may hide a malformed image, geometry, scope or later unsupported command. Phase boundaries must have balanced scopes and must not reset the frame ledger.

This milestone includes existing text masks, rounded masks and nearest-neighbor images inside a group. Supporting only rectangles would leave ordinary faded cards with text falling back, so it would not satisfy the proposed visible acceptance scene. It adds no filters, blend modes, author fonts, shaping, arbitrary transforms, screenshots, driver isolation or new browser/worker privileges.

## Representation and implementation seams

1. Extend the Native bridge's initial scope validator and lowering to retain opacity boundaries alongside Clip/Fixed. Preserve original phase/command error positions. Coordinate scopes retain their current arithmetic; opacity changes the destination, not document or fixed offsets.
2. In `raster-core` planning, record a group tree and ordered operations. Derive each group's conservative pixel rectangle from the union of its already-lowered descendant draw bounds, including child groups. Keep absolute framebuffer coordinates; translate only when indexing the group's storage. This must include rounded antialias coverage and glyph row-origin extents. A fixed descendant can escape an ancestor clip and still belongs to the opacity group, so an element box or entry clip is not a valid group bound.
3. Give each nonempty nonunit group a transparent premultiplied RGBA16 region in one bounded scratch arena, stored as two u32 words per pixel. Initially retain disjoint regions for all groups in the admitted frame; avoiding reuse inside a frame keeps the allocation/lifetime proof simple. Include every region in the byte sum. Later pooling is a separate optimization, not required here.
4. Add ordered clear-group and composite-group operations. Ordinary draws write either the existing opaque RGB target or the current RGBA16 group. Group pop composites into the parent group, or the opaque root, exactly once. Do not replace this with multiplying each child's alpha; overlap would be wrong. Keep one ordered dispatch per operation and one writer per destination pixel.
5. Extend core draw/parameter encoding and the Native GPU encoders in `gpu.rs`/`gpu/reuse.rs`; keep the existing no-group pipelines/bytes available for Probe and existing Native scenes. The Native lease requirements, descriptor checks, byte sums, compatibility key and destruction path must include the scratch arena. Every reused frame clears its group regions and rewrites its metadata. Conversion still consumes the final packed RGB target and remains unchanged.
6. Extend bridge preparation bounds before allocation and final plan admission before encoding. Preserve the owner in `src/presenter/vulkan/native.rs`: no second submission, no partial-frame presentation, unchanged stale-frame checks/deadline/retirement, and no caching after uncertain work. A late plan refusal still requests the complete CPU frame.

The main files are therefore the Native bridge, core `lib.rs`/`scope.rs`, Native-compatible shaders/encoders, and `surface/reuse.rs` requirements. Layout, worker command schema, CPU painter and surface color conversion should not need semantic changes. New isolated core group-planning and shader files would keep the existing planner readable. This is a medium-sized renderer increment, not a one-condition removal.

## Why cropped regions matter

For pixel rectangle `R=(w,h)`, let `P(R)=ceil(w/8)*ceil(h/8)*64`. Budget the existing clear, every draw, mandatory surface conversion and `2*P(R)` for each materialized group's clear and composite. Unit/zero/empty groups have no scratch dispatches after validation. Per-frame work remains at most 4,000,000; scopes and phases do not renew it.

Explicit buffer accounting adds `8*sum(group_width*group_height)` scratch bytes, all new per-operation uniforms/metadata and their actual padding to the existing RGB output, aligned conversion buffer and source arenas. Check device buffer/binding limits too. Retained CPU vectors and temporary group-planning tables belong in the existing preparation and pending-packet accounting. Caller readback remains additional storage under the existing 24 MiB verification limit. These payload bounds exclude opaque driver/allocator overhead as before.

A 1280×880 frame already spends 2,252,800 padded invocations on root clear plus conversion. Giving one opacity group a full 1280×880 intermediate would add 2,252,800 more before its contents or chrome, exceeding 4M. Even the actual 779-pixel page height after the current 76-pixel toolbar and 25-pixel status bar adds 2,007,040 padded invocations, for 4,259,840 before drawing. A 128×64 group instead adds 16,384 invocations and 65,536 scratch bytes. This arithmetic is a design calculation, not measured admission or timing. A caller-viewport-sized CPU layer is semantically safe, but indiscriminately copying that storage strategy to GPU would make desktop admission unnecessarily rare. Conservative bounds preserve transparent pixels outside the region because they contribute nothing at group pop.

The bridge separately charges `target_area * nontext_command_count` against its clamped CPU preparation allowance before text work. That conservative admission can reject a desktop scene even when the cropped GPU surfaces fit. Scope handling must retain an honest CPU-work estimate; cropping does not authorize silently dropping this existing debit. The proposed desktop witness must be designed and checked against every actual ledger, not just scratch storage and GPU invocations.

Do not conflate nested depth with storage: the simple first version keeps all group regions until the frame retires, so charge the sum, not just the deepest simultaneous chain. A future arena allocator could lower that requirement with its own lifetime proof.

## Arithmetic gate before implementation is considered ready

The CPU group's primitive blending is integer premultiplied RGBA16, while group pop uses the original unquantized f32 opacity and Rust `round()`. The existing GPU shaders operate on opaque RGB8. A direct translation using WGSL `round()` is incorrect at ties: Rust rounds halfway values away from zero, while WGSL rounds them to even. [Rust f32::round](https://doc.rust-lang.org/std/primitive.f32.html#method.round), [WGSL round](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#round-builtin).

A literal discriminator is an opaque `(65,0,0)` pixel in a 0.5 group over black: the expected final pixel is `(33,0,0)`, packed `0x210000`; rounding 32.5 to even produces the wrong red value 32. Preserve CPU evaluation order and audit shader floating-point accuracy/contraction as well as the final rounding step. A half-up helper alone is not proof of all intermediate f32 equivalence. [WGSL floating-point evaluation](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#floating-point-evaluation).

Specify and review that numerical path first. Do not quantize opacity early to u8/u16, change the CPU reference, or silently introduce a tolerance to make a shader pass. If matching the CPU's intermediate arithmetic cannot be established for the proposed values/devices, retain fallback for the unresolved domain and report the narrower domain explicitly rather than calling arbitrary-opacity support complete. No claim of universal cross-driver bit equivalence follows from a few adapters.

## Concrete acceptance checks

Freeze small literal oracles before candidate execution, keeping them separate from CPU-derived large-frame comparisons:

| Check | Exact discriminator |
| --- | --- |
| Group overlap, 8×4 white target | 0.5 group: opaque red `[0,4)` then blue `[2,6)`; columns 0–1 `0xff8080`, 2–5 `0x8080ff`, 6–7 `0xffffff`, every row. Existing CPU test at graphics.rs:905 is a retained independent predecessor witness. |
| Nested group/image | Existing 8×4 CPU witness at graphics.rs:928 has columns 0–1 `0xbf80bf`, 2–3 `0xbfbfff`, 4–5 `0xffbfbf`, 6–7 white. It distinguishes inner isolation, outer composition and source alpha. |
| Halfway rounding | One `(65,0,0)` pixel, opacity 0.5, black root must become `0x210000`; include additional exact-half and neighboring-opacity cases fixed before implementation. |
| Ordering | Add an opaque green draw after a group's pop: its covered pixels must be `0x00ff00`, not faded or drawn into a stale intermediate. |
| Transparent holes and empty groups | Untouched root pixels remain exact; empty/zero groups do not leak prior-frame scratch contents, and malformed hidden input still refuses. |
| Clip/fixed/nesting | A group contains a fully clipped ordinary child and a fixed child outside that clip; the fixed pixels remain faded and present. After popping Fixed and Opacity, the next draw sees the restored coordinates/target. |
| Text, rounded mask and image | Small literal coverage arrays with zero/full/partial coverage and fractional clips, plus a two-pixel RGBA image, compare all bytes in both group and root destinations. Separately compare real font/rounded lowering against the published CPU painter. |

Planner tests need exact and one-short byte/work admissions; combined-scope exhaustion/mismatch; nested/phase sum accounting; negative/NaN/>1 opacity; malformed last command; invalid hidden image; legal missing-image no-op; fully clipped bounds; signed/fractional coordinates; checked extent/index arithmetic; unchanged Probe behavior; and no-group Native plan identity.

GPU tests should compare the entire output on each available adapter, not only selected samples. Reuse must render changed colors and opacity with identical buffer sizes, then exercise a changed region size, cancellation before and during encoding, retirement and fallback. Route assertions must prove the result came from a native opacity plan; CPU fallback matching itself is not success.

The browser witness should be compact: an existing-property opacity change on a real button click switches an outer faded panel, with a nested faded child, overlapping colored boxes, short text, rounded background and a decoded tiny image. Keep stable DOM IDs and no click node creation. Check phase-specific CPU literals where possible, then the whole acquired native texture including unchanged chrome. Use a small controlled window first; separately target a 1280×880 scene with a small group region to demonstrate useful desktop admission. Verification failure, fallback, incomplete sampling or unexpected descendants fails the relevant run. A normal run must also present without a CPU reference/readback. Native snapshots are before the compositor, not a screenshot guarantee.

## Recommendation and stopping boundary

Select this milestone because it extends an existing visible CSS behavior through the actual renderer and exercises compositing instead of adding more conformance machinery. The arithmetic contract and conservative region proof are the two substantive design risks. Freeze those and a small ordinary browser scene before coding; then implement planner/encoder/lease changes and run focused pixel checks. Keep existing fallback and limits rather than broadening viewport, allocating unbounded layers or claiming performance from admission alone.

This assessment selects a concrete candidate for root review; it does not authorize implementation or execute the proposed checks. There are no measured results for this proposal.
