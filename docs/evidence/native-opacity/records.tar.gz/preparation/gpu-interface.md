# Native cropped RGBA16 encoder interface proposal

Source-only design against published clone `3ee89d4835a40d652b1be6fe73cff425f7598289`. No implementation, compiler, engine or GPU execution. Root owns the planner and has accepted the API names below; encoder work waits for its isolated checkout. The selected numerical domain is opaque-backed nontrivial groups with opacity `k/256`, `1 <= k <= 255`. HTML owns the precise admission proof. Existing public CPU commands deliberately flatten unit opacity (graphics.rs:803); zero scopes suppress only after complete validation.

## Shared Plan/Draw seam

Keep `Plan::draws()` as the single ordered dispatch stream. Add `DrawKind::GroupClear` and `DrawKind::GroupComposite`; existing Rectangle/Image/Glyph kinds stay unchanged. Add `Draw::target_is_group()` and `Plan::group_scratch_bytes()`. The latter is exactly zero for all old plans. Draw bounds and `groups()` continue to describe the absolute pixel dispatch rectangle and ceil(width/8), ceil(height/8). The planner privately owns validated destination/source region metadata and emits its immutable uniforms; encoders do not reconstruct scope trees or eligibility.

No extra GPU group table is needed. The optional arena retains disjoint regions for all materialized groups for the whole frame. Every group has an ordered clear, its existing primitive draws, then one ordered composite. Existing root clear and RGB surface conversion remain unchanged. All clear/composite draws consume normal operation slots, PARAM_STRIDE records, padded invocations and per-operation cancellation checks. Retained CPU accounting must use the actual extended Draw size/capacity and any retained planner vectors.

## Exact 128-byte uniform layout

PARAM_STRIDE stays 256. Bytes 0..64 retain the existing encoding and meaning. Every record is initialized to zero; old no-group records remain byte-for-byte unchanged including their tail. New group-aware bind groups expose a 128-byte dynamic uniform window. All fields below are little-endian u32; each table row is one vec4<u32>.

| Byte offset | Four words | Meaning |
| --- | --- | --- |
| 0 | origin_x, origin_y, extent_w, extent_h | Absolute dispatch pixel rectangle, unchanged. |
| 16 | canvas_w, canvas_h, color, reserved_zero | Existing canvas and AARRGGBB color, unchanged. |
| 32 | source_base, source_w, source_h, source_count | Existing image/mask input metadata; zero for clear/composite. |
| 48 | table_x, table_y, table_w, table_h | Existing image coordinate tables; for glyph keep existing row_base, signed_y_bits, row_count, zero. |
| 64 | dst_word_base, dst_origin_x, dst_origin_y, dst_width | Destination group region; for root use 0,0,0,canvas_w. |
| 80 | dst_height, dst_kind, zero, zero | dst_kind=0 root RGB, 1 scratch RGBA16; root height=canvas_h. |
| 96 | src_word_base, src_origin_x, src_origin_y, src_width | Source group for GroupComposite only; zero otherwise. |
| 112 | src_height, opacity_k, zero, zero | GroupComposite source height and k in 1..255; zero otherwise. |

GroupClear targets its exact destination region with dst_kind=1; color/source/table/source-group words are zero. GroupComposite uses the exact source rectangle as its dispatch rectangle, the source region at96, and parent group or root at64. Ordinary group draws use the old primitive input prefix and destination region at64, with source-group words zero. Ordinary root draws keep all bytes64..256 zero and continue using only the old32/64-byte binding windows.

Arena offsets are in u32 WORDS, always even, not bytes or pixels. A group pixel index is `dst_word_base + 2*((y-dst_origin_y)*dst_width + (x-dst_origin_x))`. Pack word0 as B in low16 and G in high16, word1 as R in low16 and A in high16. This matches the low/high halves of the current CPU u64 pixel. Source and destination group regions in a composite are disjoint; source reads and destination writes use one read_write arena binding, avoiding aliasing the same buffer through independent read-only/read-write bindings. Bounds guards must check coordinate subtraction, extent products, base+2*pixel_count and final two-word accesses without wrapping, even though Plan construction already proves them.

## Additive pipelines and binding layouts

Leave rect.wgsl, image.wgsl, glyph.wgsl and surface.wgsl byte-identical. Keep `Rasterizer::new(device, glyphs)` as the old constructor. Add an explicit Native-capable constructor (suggest `Rasterizer::new_native(device, glyphs)`) which retains old kernels and creates optional group kernels. NativeEncoder::new selects it; old Probe callers remain unchanged. Group kernels are owned by the same Arc kernel graph as existing pipelines, so submitted frames retain them. Missing group support is rejected before buffer allocation/uploads, as existing missing-glyph admission does.

Use two new explicit layouts:

- Group rectangle/clear/composite: binding0 root RGB read_write storage; binding1 dynamic128-byte uniform; binding2 RGBA16 scratch read_write storage.
- Group image/glyph: same first three bindings, plus binding3 immutable input read-only storage.

The root buffer remains bound for all group kernels even when not used by that entry point; there is no dummy scratch or input buffer. Group input bindings exist only when plan input is nonempty. Native-capable pipeline construction adds driver work even for later no-group frames; no startup/performance equivalence claim is made. No-group shader code, uniform bytes, dispatch choice and explicit buffer descriptors remain unchanged.

Dispatch choice is `(draw.kind(), draw.target_is_group())`: existing root Rectangle/Image/Glyph keep their old pipeline/group; group primitives use the new kernels; GroupClear/GroupComposite use their new kernels. Both one-shot Rasterizer::encode and reusable RasterBuffers::encode need the same exhaustive routing. Each operation remains a separate compute pass and invokes the existing callback before it. No submission, polling, readback or new owner lifecycle is added.

## Primitive/composite arithmetic

Group primitive alpha remains `a8 = source_alpha * coverage /255`, then `a16=a8*257`; channels are `(color8*a16+127)/255`. Integer source-over is `source16 + (destination16*(65535-a16)+32767)/65535`, including alpha. Its largest product-plus-bias is65535^2+32767=4294868992, below u32::MAX; premultiplied invariants bound the final channel to65535. Existing image nearest-neighbor tables and glyph signed-origin logic remain exact.

For an admitted opaque group pixel, source alpha is65535. Let `n = source16*k + destination16*(256-k)`. Parent-group output is `(n+128)/256`; root RGB output is `(n+32896)/65792`, using destination16=257*root8. Products and sum are at most65535*256=16776960. Group alpha composited into an opaque parent remains65535. These formulas require the planner's opaque source proof; arbitrary-alpha groups cannot enter this path merely because opacity is dyadic. No WGSL floating-point division or final WGSL round is used. The CPU equivalence proof, including final257 division and integer-half behavior, is being held separately by HTML.

## Exact accounting and device preflight

Add scratch bytes to BufferAccounting::checked/for_plan, RasterRequirements, surface reuse Key::bytes, both owned/planned totals, NativeRequirements::buffer_bytes documentation and descriptor checks. Arena usage is STORAGE only: group clear is GPU-written, no COPY_DST or CPU painted pixels. Allocate one extra buffer iff scratch>0; destroy it only with the existing after-completion owner path. The limit remains16MiB including output, parameters, immutable input, scratch and conversion buffers/uniform. The separate optional verification readback allowance is unchanged.

Check scratch nonzero/aligned-to8 and each exact planned range; scratch <= max_buffer_size and max_storage_buffer_binding_size; dynamic uniform binding limit >=128 for group plans; and unchanged256 stride alignment. Check the group layout's two storage bindings (three with immutable input), one dynamic uniform binding and up to four bindings against device limits before creation; check workgroups for ALL ordered draws including new clear/composite operations. Old plans keep their existing32/64-byte requirements.

Reusable RasterBuffers owns optional scratch and its group bind groups. RasterRequirements/Key includes exact scratch bytes, so size changes refuse reuse. No region-geometry hash is required: every metadata byte is rewritten and every region that the new frame may read is cleared before use. Reusing equal-size arenas with different region shapes is safe under that invariant; unreferenced stale pixels are never read. The context Arc still binds device/queue/pipeline identity. Exact buffer size/usage is verified just like output/input, including None iff required size is zero.

All rejection checks precede first creation in NativeEncoder::allocate. Encoding failure poisons the lease and retains all handles for queued-write retirement; cancellation or uncertain submission must not return it to cache. Extend both one-shot EncodedFrame and reusable RasterBuffers destruction paths; ordinary Drop must not explicitly destroy in-flight buffers. Conversion still reads only the final root RGB output, so SurfaceConverter and surface shader behavior remain unchanged.

## Focused checks to preserve at implementation

Source/deterministic planner checks: zero scratch/no-group byte identity; exact/one-short total memory including scratch; missing pipeline and synthetic device-limit refusals; no wrap at last two-word region index; all per-draw metadata128 fits unchanged stride256. Reuse checks: same size/different group layout and opacity rewrites, changed scratch size incompatible, clear prevents prior-frame pixels, exact owner/descriptor checks, failed encoding cannot become reusable. GPU/root-owned checks: literal overlap/nesting/half-rounding oracles, full CPU equality, source alpha/image/glyph partial coverage over proved opaque backdrops, and callback refusal before clear/draw/composite with no partial presentation. This document authorizes no execution and claims no measured result.
