# Validation record

## Bounded native opacity

The [Vulkan opacity route](vulkan-opacity.md) adds cropped RGBA16 intermediates
for nested groups at `k/256` opacity with a proved opaque rectangular backing.
All scratch, operations and clear/composite work share the existing frame
limits. Unsupported groups still use complete CPU fallback.

Rust 1.88 passes **2,139 native-feature tests**, including ignored confinement
tests, and **128 GPU-feature / 97 default core tests**. The native bridge's
**63 groups** and both Page/worker opacity witnesses pass. Strict Clippy passes.
Three actual Vulkan adapters each pass 32 literal/reuse frames and eight
cancellation checks, for **96 frames and 2,472 compared bytes** in total.
The NVIDIA native window verifies **18,022,400 acquired bytes** over four
frames spanning an actual opacity-changing click. A separate reference-free
native window also passes; both exit with no surviving owned descendants.

Retained failures include the first core scratch-accounting omission, a test
fixture's incorrect button/Text hit expectation, test-only Clippy findings and
an old zoom test that expected every opacity scope to refuse. The first window
attempt stopped before document release because the new controller rejected
ordinary startup sizes; its supervisor cleaned up the remaining owned children.
The corrected controller also recognizes the existing confinement diagnostics.
All literal pixel expectations and production CPU rendering remain unchanged.
The [source-bound evidence](evidence/vulkan-native-opacity.json) separates these
attempts from the passing results. Transparent-backed groups, arbitrary opacity,
full compatibility, production security and Chromium-relative speed remain open.

## Doctypes and nonbreaking spaces in HTML serialization

The serializer now follows the same HTML algorithm for doctype names and
nonbreaking spaces: public/system identifiers remain in the DOM, while HTML
output writes `<!DOCTYPE name>`; ordinary text and attributes escape U+00A0 as
`&nbsp;`. Raw script text retains the literal character. Existing serialization
tests cover these distinctions, and all 1,210 default library tests pass on
Rust 1.88, including ignored confinement tests. See the
[evidence](evidence/html-serialization.json).

## Processing-instruction serialization

HTML serialization now writes the separate `?>` terminator required by the
[current standard](https://html.spec.whatwg.org/multipage/parsing.html#serialising-html-fragments).
Previously, reparsing serialized data ending in `?` silently consumed that last
data character. The new regression covers empty data, literal markup characters,
a trailing question mark and Unicode, with exact output and reparsed node data.
The existing tree-position assertion now uses the correct terminators.

All 1,210 default library tests pass on Rust 1.88, including confinement tests;
formatting passes. The first run's two confinement preflights failed inside the
outer sandbox; unchanged code passes outside it. Both attempts are retained in
the [evidence](evidence/processing-instruction-serialization.json).

## Runtime initialization

The [fallible initialization checkpoint](runtime-initialization.md) passes all
1,377 default and 1,494 native-feature tests on Rust 1.88 and 1.98, including
ignored tests. Six strict Clippy variants and formatting pass. Sixteen tests
were added; all prior identities and the exhaustive UTF-16 JSON test remain
unchanged and pass. All twelve validation commands and the release build passed
on their first attempts.

The release preserves all complete observations across 44 formal profiles and
11 local suites: 21,483 case modes and 5,152 controls, with no gains, losses or
other changes. All 36 established gates and 48 local resource-policy rows are
unchanged. The [summary](evidence/runtime-initialization.json) and
[evidence index](evidence/runtime-initialization/index.json) retain the exact
source, build and replay records. The result covers checked initialization
failure propagation; it does not establish comprehensive allocation recovery.

## DOM defining-interface methods

The [DOM method follow-up](../tests/conformance/dom-method-identity.md) separates
eight query/append function identities and checks their defining-interface
receiver before conversion. The original 58-mode local inventory now has
48 passes, six ordinary prerequisite failures and four expected resource stops;
52 expectations and all 44 controls verify. Four earlier Object.is identity
failures also pass. Across 11 local suites, all 1,756 case modes and 588 controls
are retained: 22 gains, no losses or other complete-record changes, and all
48 explicit resource expectations match. All 44 formal profiles retain their
19,727 case and 4,564 control records; all 36 established gates pass unchanged.

The corrected frozen candidate passes 21 focused groups, 1,361 default tests
and 1,478 native-feature tests on each of Rust 1.88 and 1.98, including ignored
confinement tests and initial/click pixel checks. All six strict Clippy variants
and formatting pass. Source, release binaries and results are bound by the
[runtime summary](../tests/conformance/dom-method-identity-runtime.json) and
[evidence index](evidence/dom-method-identity-runtime/index.json).

Both first-candidate full runs failed the existing exhaustive UTF-16 JSON test
after bootstrap used too much work. The correction removes repeated metadata
work and prepays the full bootstrap object arena; the unchanged test passes.
One later parallel MSRV attempt timed out in an unchanged timezone stress test;
its isolated check and complete matrix then passed without source/deadline
changes. All attempts remain retained. This establishes the scoped result,
not full Web IDL compatibility, production security or Chromium performance.

## Native retired-buffer reuse

The owner retains one exact-size complete GPU buffer lease only after tracked
retirement, successful scopes and presentation. Every frame rewrites its full
input/uniform arenas and clears/draws the whole target. Resize, format/shape
mismatch and CPU fallback evict before replacement; failed or uncertain work
cannot enter the cache. The retained charge survives idle under unchanged
16 MiB native, 24 MiB native-plus-readback and 128 MiB application bounds.

Rust 1.88 and 1.98 each pass **1,397 native-feature tests** and **107 GPU-feature
core groups**. Rust 1.88 also passes **84 default core groups**. All **450 Python
groups** pass. Separate real-GPU
checks on three adapters pass **84 frames, 45 reuse hits, 18 cancellation
guards and 4,680 literal comparison bytes**. The **39 successful-frame buffer
allocations** exclude the 18 extra cancellation leases. These offscreen counts
are distinct from browser-window timings. The initial checker compile failure
(`E0599` during Clippy), preexecution oracle literal correction and host
source-sort correction remain retained with corrected records. No probe unit
test failed in this increment.

The first native baseline/reuse comparison passes **eight owned processes**:
two correctness processes match **9,011,200 acquired bytes** in total, followed
by six processes completing **96 measured frames**. Both independently bound
executables use Rust 1.98's normal release profile. One URL, exact 269-byte paint
identity, scale and NVIDIA BGRA8/FIFO adapter configuration remain equal; all
owned children are reaped with no survivors. Subsequent prepare-through-present
median/p95 are **2.086/4.790 ms baseline** and **1.309/4.117 ms reuse**. First-frame
and owner-total distributions remain separate, and all second-frame submission
tails remain included. Environment snapshots change from P5/360 MHz before
to P0/2505 MHz after; GPU clocks were unlocked. Those snapshots do not measure
per-frame clocks or attribute the entire difference to reuse. No compositor,
throughput or Chromium result is inferred.
Final cached-buffer destruction happens during positive owner release outside
frame timing; successful report output still waits for that release.
See [interpretation and reproduction](native-render-benchmark.md#native-baseline-versus-retired-buffer-reuse),
[source-bound evidence](evidence/vulkan-native-buffer-reuse.json) and the
[artifact index](evidence/native-buffer-reuse/index.json).

## First controlled native timing comparison

All **eight owned window processes** pass using the frozen release from
`51ca9ed`, a single loopback URL and exactly equal canonical paint inputs.
Two separate CPU/native acquired-texture checks each match **4,505,600 bytes**.
Six processes complete **96 measured frames** with no reference/readback; every
owned child exits and is reaped without cleanup failure. The host and helper
changes pass **96 focused Python groups**, including **25 new groups**.
The complete tool suites pass **347 root / 90 raster-probe groups**. All nine
[public API checkpoint CI jobs](evidence/vulkan-native-timing-api-ci.json) pass.

For the tiny admitted fixture on NVIDIA RTX 4070 SUPER/BGRA8/FIFO, subsequent
prepare-to-present medians are **2.429 ms CPU / 2.085 ms native**. The corresponding
p95 values are **2.625 ms / 4.830 ms**, and first-frame medians are
**3.039 ms / 5.744 ms**. Every early slow sample remains in the declared population.
These are host work intervals, with unlocked clocks and no compositor/scanout
measurement; there is no Chromium comparison or general browser-speed claim.
See [full interpretation and reproduction](native-render-benchmark.md) and
[all source-bound raw records](evidence/vulkan-native-timing-host.json).

## Native timing API and exact-scene checks

The opt-in `--benchmark-native` and `--benchmark-native-check` modes add bounded
host-clock records and a separate one-frame correctness process. They require
Linux and the native Vulkan build. Scene identity includes full image payloads
and ordered paint inputs; a fixed status avoids load-time text differences.
Only positive presentation and post-retirement completion advance sampling.
Owner release is required before JSON output.

Both Rust 1.88 and 1.98 pass **1,387 native-feature tests**, including **95
browser/presenter groups**, with **32 new private groups**. Strict Clippy passes
for default, Vulkan-presenter and native-raster configurations; default and
presenter binary suites pass **41** and **62** groups. The frozen release passes
**15 CLI rejection cases** before window startup. Two initial lint failures and
an outer-sandbox socket-preflight failure remain retained; corrected checks
and unchanged confinement tests pass.

This API checkpoint contains source/unit/CLI evidence. The controlled host
comparison above followed using the same release binary; neither establishes
isolated GPU timing, compositor latency or a Chromium result.
See the [measurement contract](native-render-benchmark.md) and
[hash-bound evidence](evidence/vulkan-native-timing-api.json).

## Native wide rounded masks

Native rounded rectangles can now use two disjoint horizontal masks while
preserving the original floating-point geometry. Every mask keeps its 1024-pixel
axis cap. Shared coverage, source, row, operation, storage and invocation limits
are unchanged; the whole group is checked before allocation. Original primitive
work is counted once. The legacy single-mask and Probe refusals are preserved.

Both Rust 1.88 and 1.98 pass **1,355 native-feature tests**, **53 adapter groups**,
**84 default / 95 GPU-feature core groups**, and strict all-target Clippy.
Twelve added Rust groups cover exact translucent seams, fractional/fixed
coordinates, original ordering, allocation failures and global cutpoints.
All **48 native host Python groups** pass. Synthetic tests found and corrected
a buffered-log ordering bug in the new controller before desktop execution;
the preliminary failures and source versions remain retained.

Two actual **1280×880** window cases pass on NVIDIA RTX 4070 SUPER/BGRA8:
**4,505,600 acquired texture bytes** match the full Canvas reference, and a
separate normal frame uses no reference or readback. Both use the new two-strip
address bar and finish with no owned descendants. The controller releases the
frozen HTML/PNG over its bounded loopback origin only after owned-window sizing
and the browser's latest physical-size diagnostic agree. Different ephemeral
ports affect address-bar text; these runs are not a performance comparison.
See the [source-bound evidence](evidence/vulkan-native-wide-rounded.json) and
[current window-check instructions](vulkan-native-window.md#wide-mask-validation).
The earlier 1180×880 fallback/reload results below remain evidence for their
original executable. This change establishes no broader viewport, web-standard,
security or Chromium-relative performance guarantee.

## Native GPU window integration

The optional `vulkan-raster` feature now connects the custom rasterizer to the
browser's actual Vulkan surface. A single plan preserves page, overlay and
chrome order, independent fixed-coordinate caller clips and global resource
limits. Startup/loading and unsupported scenes use the complete original CPU
painter. Normal admitted frames carry no CPU framebuffer or readback; explicit
verification carries one complete Canvas reference.

Rust 1.88 and 1.98 each pass **1,349 native-feature tests**, strict all-target
Clippy across the affected feature variants, **47 adapter groups**, and
**78 default / 89 GPU-feature core groups**. This adds 19 native-adapter and
12 phased-core groups while preserving the old adapter/planner tests. The
browser/presenter suite has 63 groups. CI adds native-feature rows on both
Rust versions and explicitly discovers all 47 adapter groups.

Four controlled native-window cases pass on NVIDIA RTX 4070 SUPER/BGRA8:
**4,153,600 acquired bytes** match the full CPU reference; a separate loaded
scene renders with no reference; opacity and redundant-background scenes use
complete CPU fallback. Fallback runs prove admission/route behavior, not pixel
comparison of their uploaded textures. All four supervised runs exit zero and
leave no owned descendants. The first two failed attempts are retained: an
address-bar mask exceeded its axis cap at compositor-selected size, then the
original two-background scene exceeded the unchanged work cap at 1180×880.
That original input is now the explicit overdraw-fallback fixture.

Two additional supervised checks pass. A reload dispatched after actual native
presentation starts a new confined page worker and broker, then prepares a
generation-two native scene; this does not establish a second presentation or
pixel comparison. Requesting one native verification frame for the opacity
fixture exits with the expected `0/1` incomplete quota, proving CPU fallback
cannot satisfy native verification. Both leave no owned descendants.

The [native-window documentation](vulkan-native-window.md) and
[source-bound evidence](evidence/vulkan-native-window.json) separate acquired
pixels, normal rendering, fallback and failures. The host has **22 synthetic
test groups** covering protocol ordering/identity and PID-owned window control;
the follow-up harness adds **13 groups**, for **35 passing Python tests**.
This remains hybrid CPU coverage/GPU compositing. Group opacity, wider admission,
zoom, shaping, native GPU screenshots, independent security auditing and the
requested Chromium performance threshold remain unfinished. No compositor or
performance result is inferred from exact acquired-texture bytes.

All nine [CI jobs for `9a30882`](https://github.com/Eriskii/ErisBrowser/actions/runs/36980781764)
passed, including both native-feature rows. The
[terminal receipt](evidence/vulkan-native-window-ci.json) is retained separately
from the original local evidence.

All seven [CI jobs for the preceding `d07c827` checkpoint](https://github.com/Eriskii/ErisBrowser/actions/runs/36974379124)
passed; its [terminal receipt](../tools/vulkan-raster-probe/evidence/host-native-prerequisites-ci.json)
is retained separately.

## Native frame prerequisites

The reusable core adds a closed `Profile::Native` alongside the unchanged Probe
policy. Native plans admit up to 1280×1024, with 16 MiB of explicit planned
buffers and the existing four-million invocation ceiling. Both limits include
the padded surface-conversion buffer, its 16-byte uniform and its complete
dispatch. Original command, scope, image and mask limits remain in force.

Rounded preparation computes geometry-only coverage using the CPU painter's
exact arithmetic, including fractional clipping, radius clamping and coverage
below 255 for radii below 0.5. It exposes a checked work/storage estimate before
fallible allocation. GPU kernels apply color and ordered blending. The new
conversion kernel emits opaque BGRA/RGBA words into padded rows, owns the source
frame until completion, and never receives expected pixels or performs readback.

Both Rust 1.88 and 1.98 pass formatting, strict all-target Clippy and **66 core
default / 77 core GPU test groups**; the probe passes **6 default / 14 feature
groups**, and all **28 browser adapter groups** pass. Seven new Python host tests
cover strict protocol handling and mocked process outcomes. Initial compilation
caught a test-only u32 cast and two redundant conversions of wgpu's u64 limits;
those were corrected before GPU execution. Review also corrected the host's
bytes-to-text decoding before the first real run.

All **11 cases × two byte formats × three adapters** pass complete active-pixel
and alpha comparison: **81,393,120 GPU-compared bytes**. This comprises
**56,471,520 bytes from independent literal geometry/coverage references** and
**24,921,600 bytes from the existing Canvas painting a normal-sized address bar**.
The latter is a CPU differential reference, not an independent rounded oracle.
Padding is allocated/accounted but excluded from pixel counts. Existing 30-case
rectangle/image/alpha and 26-case glyph suites also pass all three adapters,
adding **3,799,728 regression bytes**. Every process exits zero with empty stderr;
eight new/glyph processes have complete subreaper cleanup, while the four old
standalone processes retain their existing process-group supervision contract.

The [evidence](../tools/vulkan-raster-probe/evidence/host-native-prerequisites.json)
binds sources, binaries, initial correction and host runs. The new checker is
offscreen: it acquires no window surface, runs no renderer worker and establishes
no native-browser or performance result. Native scene construction and actual
surface integration remain unfinished.

## Browser-owned raster adapter

The optional root `raster-bridge` feature now exposes the existing display-list
and font adapter as `graphics::raster_bridge`. The probe reexports the same
types and functions. Four implementation/test files move with only import paths
and formatting changed; their algorithms, bounds and fallback rules are preserved.
The core, shaders, CPU painter, worker startup and native presenter are unchanged.

Rust 1.88 and 1.98 pass formatting, strict all-target Clippy and all **28 moved
test groups** in both bridge-only and bridge+presenter configurations. The probe
passes its **13 remaining groups** on both toolchains. Exact test identities are
checked, and CI explicitly discovers the 21 adapter and seven text groups before
running them. No registry package changes; the standalone bridge dependency graph
contains no wgpu, and combining it with the presenter does not enable core GPU
encoding or WGSL.

The unchanged glyph, browser and worker-text contracts pass on all three Vulkan
adapters: **1,958,280 GPU-compared bytes**, with **154,152 CPU fallback reference
bytes counted separately**. All twelve supervised processes exit zero with empty
stderr and complete cleanup; six worker-to-GPU grants preserve capture ordering.
The existing confined browser executable is reused as the snapshot producer;
only the checker consumes the relocated adapter. See the
[source-bound evidence](../tools/vulkan-raster-probe/evidence/host-adapter-relocation.json).
This makes the adapter available to native integration; native scenes, rounded
geometry, broader frame budgets and GPU presentation remain unfinished.
All seven [CI jobs for `6aa7daa`](https://github.com/Eriskii/ErisBrowser/actions/runs/36971638243)
passed, including explicit discovery/execution of the moved tests; the
[terminal result](../tools/vulkan-raster-probe/evidence/host-adapter-relocation-ci.json)
is retained.

## Reusable raster core

[`eris-raster-core`](../crates/raster-core/README.md) now owns the unchanged
primitive planner and an optional GPU encoder on caller-owned devices. The
probe retains adapter selection, deadlines, error scopes and full pixel
comparison. Its old public planner paths are reexports of the same types.
Returned frame resources retain their buffers, bindings and pipelines through
submission; explicit destruction requires the caller to have confirmed
completion. Encoding errors require discarding the incomplete encoder.

The original planner body and three shader sources retain exact bytes.
Coordinate-state changes expose only the narrow API needed by the browser
adapter. Frame and work caps, source validation and two-target GPU accounting
are unchanged. The root Cargo files remain byte-identical; the probe adds one
local path package, and the core uses existing external versions and checksums.
The core default dependency graph contains only the core itself.

Both Rust 1.88 and 1.98 pass formatting and strict all-target Clippy. Core tests
pass **40 groups without GPU and 43 with GPU**; probe tests pass **5 default
and 41 with the browser bridge**. The combined feature runs preserve all 79
prior executions, add two duplicate alpha-fixture executions across crates and
three new accounting/alignment/glyph-admission groups. CI explicitly runs core
tests because dependency unit tests are not run by testing the probe alone.

All four existing GPU suites pass on NVIDIA, AMD and software Vulkan:

| Suite | GPU-compared bytes across three adapters | CPU fallback reference bytes |
| --- | ---: | ---: |
| 30 standalone rectangle/image/alpha cases | 2,764,860 | 0 |
| 26 literal-mask and parent-font cases | 1,034,868 | 0 |
| 16 browser bridge cases | 1,812 | 552 |
| 7 worker-text cases | 921,600 | 153,600 |

That is **4,723,140 GPU-compared bytes**, with **154,152 fallback reference
bytes kept separate**. The Rust 1.88 glyph CPU check also matches all fourteen
preserved-parent font references cold and warm. Existing fixture values and
Python protocols are unchanged. The [retained evidence](../tools/vulkan-raster-probe/evidence/host-core-extraction.json)
records exact source, binary and run bindings. This extraction establishes no
native-window rasterization or performance result; browser adapter relocation,
scene construction, rounded geometry and presentation remain unfinished.
All seven [CI jobs for `9765846`](https://github.com/Eriskii/ErisBrowser/actions/runs/36970711760)
passed; the [terminal record](../tools/vulkan-raster-probe/evidence/host-core-extraction-ci.json)
is retained.

## Vulkan text from actual worker snapshots

The [worker-text checker](../tools/vulkan-raster-probe/WORKER_TEXT.md) loads seven
frozen local documents through confined `WorkerClient` processes, retains each
complete snapshot and verifies its text, styles, scopes, paint order and decoded
image bytes. Six 160×80 frames match the original `Canvas` painting the exact
same inputs on **NVIDIA, AMD and software Vulkan**: **307,200 GPU-compared bytes
per adapter, 921,600 total**. The rounded-rectangle frame selects complete CPU
fallback; its **51,200 reference bytes per adapter** are excluded from GPU totals.
The [evidence](../tools/vulkan-raster-probe/evidence/host-worker-text.json) keeps
these same-snapshot differential results separate from independent glyph oracles.

Both Rust 1.88 and 1.98 checkers pass CPU-only capture: seven workers, fourteen
cold/warm paints and **716,800 compared CPU bytes per run**, with no GPU work.
Cold/warm plans match in their complete drawing parameters, input buffers and
metadata. Worker handles, snapshots and font objects are dropped before a
distinct supervisor grant permits Vulkan initialization. Every successful
capture and GPU process exits zero with empty stderr and complete cleanup;
no device error becomes fallback.

Formatting, strict feature-enabled all-target Clippy and **79 feature-enabled
Rust tests** pass on both toolchains. Fourteen supervisor groups exercise real
disposable process trees, eighteen protocol groups use synthetic snapshots,
and nine mocked host groups check failure ordering and input bindings. Initial
compilation exposed a fixture lifetime error; explicit const contexts fix the
representation without changing any fixture values. Review corrected an
empty-diagnostics assumption and tightened metadata accounting before actual
worker runs. An oversized debug browser was refused before process creation;
stripping debug sections fits the unchanged executable-size limit.

The old browser checker now shares its unchanged capture helpers with the new
binary. Its original sixteen cases retain their GPU/fallback populations on
all three adapters. Existing WGSL and renderer admission limits are unchanged.
Native-window rasterization, shaping, rounded geometry, group opacity,
production security, full web compatibility and the Chromium performance target
remain unfinished.
All seven [CI jobs for `a744eb1`](https://github.com/Eriskii/ErisBrowser/actions/runs/36969011123)
passed; the exact [terminal result](../tools/vulkan-raster-probe/evidence/host-worker-text-ci.json)
is retained alongside the host evidence.

## Bounded Vulkan glyph masks

The [glyph path](../tools/vulkan-raster-probe/GLYPHS.md) composites bounded
CPU-generated font coverage with a custom integer WGSL kernel. Its
[host evidence](../tools/vulkan-raster-probe/evidence/host-glyphs.json) records
**26 exact cases on NVIDIA, AMD and software Vulkan**: **344,956 compared GPU
bytes per adapter, 1,034,868 total**. Twelve cases contain 223 independently
calculated literal-mask pixels. Fourteen direct font lists contain 86,016 pixels
from the preserved CPU implementation at `5ad2cfd`; those references are explicitly
CPU-derived, not independent font goldens. They cover all three faces, monospace
precedence, kerning, italic placement, Unicode/missing glyphs, fractional sizes,
clipping, fixed coordinates and image/text order.

The preserved parent produces identical cold/warm outputs for all fourteen
references. Both candidate toolchains also match those full references with cold
and warm CPU caches and retain identical GPU plans. Each admitted glyph uses
absolute signed row origins and ordered source-over passes. The original CPU
painter functions remain byte-identical; the root graphics file only adds the
new preparation module. The session precharges mask/row/GPU storage and repeated
paint work, while explicitly retaining the pinned font library's infallible
outline/raster allocation boundary. No downloaded or system fonts are accepted.

Rust **1.88.0 and 1.98.0** pass strict Clippy, builds, **41 default / 73
feature-enabled probe tests**, and **34 root graphics tests**, including nine
new mask-preparation groups. Two additional integration groups on each toolchain
execute all **25 frozen refusal variants and three positive limit plans**.
All **16 new protocol tests and two host-boundary tests** pass. Naga 30.0.1
validates the new glyph shader offline. Original rectangle/image shaders retain
their bytes and earlier validation. Neither dependency lock changes.

The first probe checks find an omitted Glyph arm in an old positive-fixture test
converter. The next default run passes 39 tests and fails two existing exact
diagnostic assertions because the combined source check precedes the old image
validator. A rejecting test-converter arm and restoration of image validation
order resolve those failures. No original expectation or fixture changes.
Static review also strengthens full cold/warm plan equality and bounds loader
directory traversal before sorting. Initial failures and corrections are retained.

After the shared planner change, all **30 original standalone cases** still
match on all three adapters (**2,764,860 bytes**), and all **16 original browser
bridge cases** pass with unchanged GPU/fallback populations. The glyph checker
itself launches no page workers. Every supervised glyph/reference process has
zero exit status, empty stderr and complete cleanup; device/readback failure
never becomes fallback. The later worker-text suite above adds actual text
captures. Native-window rasterization, shaping, rounded geometry, opacity groups,
full compatibility, production security and the Chromium performance target
remain open. All seven
[remote CI jobs for `f0987e2`](https://github.com/Eriskii/ErisBrowser/actions/runs/36966972245)
passed; the exact terminal result is retained in
[the CI record](../tools/vulkan-raster-probe/evidence/host-glyphs-ci.json).

## Vulkan bridge for actual browser snapshots

The optional [browser bridge](../tools/vulkan-raster-probe/BROWSER_BRIDGE.md)
borrows Eris worker snapshots and original display lists for the custom WGSL
renderer. The [host evidence](../tools/vulkan-raster-probe/evidence/host-browser-bridge.json)
records all **16 cases passing on NVIDIA, AMD and software Vulkan**. Each adapter
captures five real local HTML/image documents through the confined page worker
and resource broker. Eleven other inputs are direct display lists. Every actual
worker geometry, scope, decoded image and diagnostic assumption is checked
against the independently frozen inputs; no pixel target changed after execution.

Each adapter has **nine GPU cases / 151 pixels / 604 compared bytes**, plus
**seven complete CPU fallbacks / 46 pixels / 184 compared bytes**. The combined
total is **197 pixels / 788 bytes per adapter, 2,364 bytes across three adapters**;
the fallback bytes are not GPU output. Both original Canvas results and GPU
readbacks must match the literal targets where GPU admission succeeds. Text,
rounded rectangles, opacity, excessive original commands and excessive scope
depth exercise complete CPU fallback. Unsupported hidden content still refuses
the entire GPU frame.

All four supervised processes exit successfully with empty stderr and complete
cleanup. Each adapter receives its Vulkan grant only after all worker clients
and snapshots are dropped, every checker task has no children, and the dedicated
subreaper has no adopted descendants. The raw canonical snapshot records retain
complete commands, sorted image keys and shared source identities, exact RGBA,
diagnostics and request metadata. DOM and hit-test regions are outside those
records. No worker starts after the grant.

Rust **1.88.0 and 1.98.0** pass formatting, strict all-target Clippy, builds and
**50 feature-enabled tests**, including 21 bridge admission groups and four
checker utilities. Both default builds pass the unchanged **25 tests**. All
**11 new real-process supervisor tests** and **14 synthetic protocol tests** pass.
The first feature runs fail one private test because its 250×250 viewport exceeds
the existing 240-pixel height cap. The corrected 250×200 test checks exactly
1,000,000 units of CPU work with 20 commands and refusal with 21. Production
code, every oracle and all existing limits remain unchanged by that correction.
Earlier precompile review corrections and the initial failure logs are retained.

After extracting the shared GPU executor, all **30 original standalone cases**
also pass on all three adapters: **2,764,860 exact compared bytes**. Their fixture
definitions, shaders, original protocol and limits are unchanged. The two shader
validation results are reused from the preceding checkpoint because the bytes
are identical. The expanded optional path-dependency lock retains all original
97 probe package versions and checksums; the root browser lock is unchanged.

This checkpoint changes the standalone tool and its optional adapter, with no
browser runtime source change. Native window rendering, text, rounded geometry,
group opacity, broader web compatibility, production security and performance
within 30% of Chromium remain open. Existing browser conformance and CPU pixel
results retain their earlier attribution; no new full-browser suite is claimed
as part of the local bridge checks. All seven
[remote CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36962835734)
passed for published commit `5ad2cfd`; the
[terminal record](../tools/vulkan-raster-probe/evidence/host-browser-bridge-ci.json)
includes the full job and step results.

## ArrayBuffer storage, resizing, slicing and transfers

The [ArrayBuffer evidence](../tests/conformance/array-buffer.json) compares the
frozen candidate against published commit `77866e93f4d8486807aa843667619ea4ccccccfa`.
At the original ArrayBuffer checkpoint, the independently authored local sources retain **88 passed, eight failed, two
unsupported and six resource outcomes**: **92 of 104 expectations and all 76
controls verify**. Four resource outcomes are expected engine-policy checks;
both modes of an ordinary metadata test also exhaust the unchanged instruction
budget. Ten view/shared-buffer/Proxy/foreign-realm prerequisite modes remain
unmet. No local expectation or source was changed after observing results.

The later [for-in length-bucket follow-up](../tests/conformance/for-in-length-buckets.md)
closes both ordinary metadata stops: **90 passed, eight failed, two unsupported
and four expected terminal-resource outcomes**, with **94 of 104 expectations
and all 76 controls verified**. The original ArrayBuffer reports remain unchanged.

The [complete pinned profile](../tests/conformance/test262-array-buffer.md)
retains all **221 sources / 442 modes**: **262 passed, 50 failed and 130 excluded**,
with **160 verified controls** and no resource, timeout or adapter errors.
Forty-eight failures require Uint8Array; two reach untagged BigInt syntax.
The exclusions retain 112 declared-feature and eighteen host-hook exclusions.
Its known-state baseline records every observation, including the failures.
Two strengthened older baselines retain four new Array.from/Object.seal passes.
All **34 final gates** are checked against completed reports without rerunning
the engine. The combined inventory has **42 profiles / 18,563 modes / 4,252 controls**.

At the original ArrayBuffer checkpoint, the **41 older profiles / 18,121 modes / 4,092 controls** have exactly those four
gains, with no other case or control changes and all 33 preceding gates passing.
Seven older local suites retain **1,378 cases and 316 controls** byte-for-byte
at the observation level. A stale two-tool hash binding prevented the first
historical-local attempt from starting any engine; the reviewed replacement
manifest changes only bindings for new-profile additions. All old source,
helper, runner, expectation and before-report bytes remain intact.

That original checkpoint's Rust **1.88 and 1.98** runs pass strict all-target Clippy and **1,269 default / 1,280
Vulkan-feature tests**. The evidence includes **24 private buffer test groups**,
**274 Python tests**, direct page integration and the actual confined worker.
Both release variants pass all **57 CPU pixel references**. Byte-identical HTML
adapters and 68 unchanged inputs justify reuse of **3,868 matches, two mismatches
and six unsupported outcomes**; no fresh HTML run is claimed. The single
mutation smoke run covers **15,000 cases**, with zero caught panics or invariant
failures and seventeen bounded paint stops.

One private-test Clippy expression was corrected without changing semantics.
The first Rust 1.98 feature test run failed an existing Date helper readiness
assertion. Tracing passed that test but encountered a different large-request
timeout; one untraced full follow-up passed. Both failures remain in the
[Date follow-up record](../tests/conformance/array-buffer-date-host-followup.json).
The original cause remains unresolved; tracing overhead is a plausible,
unproven explanation for the second failure. No deadline or assertion was relaxed.

All existing quotas remain unchanged. Private tests cover byte initialization,
copying, shrink/regrow zeroing, species-result suffixes, callback ordering and
allocation/copy refusal. Typed arrays, DataView, shared memory and broader
accounting remain unfinished. This checkpoint adds no GPU execution, Chromium
performance comparison or security certification. All seven
[remote CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36959177431)
passed for published commit `9a7b8dc`.

## Standalone Vulkan source-alpha rasterization

The [custom raster probe](../tools/vulkan-raster-probe/README.md) now blends
unrounded rectangles and nearest-neighbor source images into an opaque RGB
target using Canvas's integer source-over rule. The [alpha host record](../tools/vulkan-raster-probe/evidence/host-alpha.json)
preserves actual offscreen Vulkan results: **all 30 fixtures pass on each of
three adapters**, comparing **921,620 bytes per adapter / 2,764,860 total**.
NVIDIA RTX 4070 SUPER (595.99.02), AMD RADV (Mesa 26.2.3) and llvmpipe
(LLVM 21.1.8/Mesa 26.2.3) each exited normally with empty stderr, as did enumeration.
The original 21 fixture definitions, expected pixels and protocol tuples remain
unchanged; their earlier rectangle/image host records retain historical attribution.

Nine independently frozen literal targets add alpha 0/1/127/128/254/255,
ordered accumulation, fractional clips, fixed restoration and transparent hidden
RGB. Valid alpha-zero rectangles are validated then omitted; visible images
retain dispatch/source storage even for zero-alpha samples. Per-draw integer
rounding and opaque clear are preserved. Translucent rectangles enforce both
half-open clip edges; opaque fast-path coverage is unchanged. No oracle, work,
scope, source or buffer limit changed after execution.

Both **Rust 1.88.0 and 1.98.0** pass **25 tests**, formatting, strict all-target
Clippy and builds. All **ten Python tests** pass, and both shaders pass offline
**Naga 30.0.1** validation. The first alpha candidate's test-helper compile failure
is retained; explicit `u32` types on three lines resolved it without changing
production code, expectations or limits. Source and binary identities were
checked before and after the actual GPU run.

This is an isolated probe checkpoint. The browser still paints with the CPU,
with an optional Vulkan upload presenter; software remains the default and
headless path. Browser GPU integration, text, rounded coverage, group opacity,
color conversion, production security and a performance comparison remain open.
No new browser conformance or CPU pixel-reference execution is claimed here.

## Array concat, live spreadability and aliased results

The [concat evidence](../tests/conformance/array-concat.json) compares against
published commit `dffca3d69c39de5c58e55838918c0b704b275d5d`. Independent sources,
expectations, modes and guarded controls were reviewed and frozen before
implementation and engine observations. The [local report](../tests/conformance/array-concat-final.json)
retains **80 passed, four failed, two unsupported and four expected resource
stops**: **84 of 90 expectations and all 68 controls verify**. Proxy, typed-array
and cross-realm cases retain their unmet ordinary-success expectations. The
[before report](../tests/conformance/array-concat-initial.json) preserves 88
availability failures, two host-hook exclusions and only twelve verified common
controls; failed positive guards prevent incidental wrong assertions from
proving feature health.

The [complete pinned profile](../tests/conformance/test262-array-concat.md)
retains **69 sources / 137 modes**: **113 passed, four failed, eighteen unsupported
and two resource outcomes**, with **96 verified controls**. Four failures require
`Uint8Array`; sixteen unsupported modes retain metadata exclusions and two
admitted modes reach unsupported class syntax. Both modes of an ordinary
4,000-hole test exhaust work. The fourteen incidental before TypeError passes
remain recorded; the candidate gains **99 passes with none lost**. The unchanged
runner classifies resource outcomes as bad runs, so **no concat baseline or CI
gate is added**. The catalog has **41 profiles / 18,121 modes / 4,092 controls**
and retains **33 established known-state gates**.

All **40 older profiles / 17,984 case observations / 3,996 controls** remain
exactly unchanged, and all 33 existing gates pass. Six selected older local
suites preserve **1,288 fixture observations and 248 controls**. Comparisons
retain complete records, including failures, exclusions, resource outcomes and
error identities. Frozen sources, expectations, policies and quotas are unchanged.

Formatting passes. Rust **1.88 and 1.98** each pass strict all-target Clippy and
**1,243 default / 1,254 Vulkan-feature tests**. All **thirteen concat private
groups** and **264 Python tests** pass. Both release configurations pass all
**57 CPU pixel references**. The load/click fixture passes directly and through
the real confined worker in the full test matrices. The HTML adapters and all
68 retained HTML inputs are byte-identical to the preceding checkpoint, so its
**3,868 matches, two mismatches and six unsupported outcomes** are reused;
there is no fresh HTML run. One mutation-smoke run covers **15,000 cases** with
zero caught panics or invariant failures and **seventeen bounded paint stops**.
The [validation record](../tests/conformance/array-concat-validation.json) and
[integration record](../tests/conformance/array-concat-integration-validation.json)
bind the exact source, binaries, logs and reuse attribution.

Concat uses live Has/Get and own data definitions, then a strict result-length
write. Same-realm species can alias any input; prior effects remain observable
after failure. Shared helper charges and constant-size loop state preserve the
existing limits. Public huge hole walks are resource-policy checks; seeded
private tests cover the later Array u32 length boundary. General accounting,
unsupported prerequisites and broader compatibility remain open. Published
concat commit `f65c666ffd22ed80759445e3af13531384b53f7c` passed all seven jobs in
[CI run 36570342566](https://github.com/Eriskii/ErisBrowser/actions/runs/36570342566).
That checkpoint added no GPU execution, performance comparison or
production-security claim.

## Generic Array splice and same-realm species

The [splice evidence](../tests/conformance/array-splice.json) compares against
published commit `605725f6df10be6a346de15c220fcf7e3e6f6aed`. Its source, local
expectations, complete upstream selection, policies and paired assertion controls
were frozen before candidate execution. The [local report](../tests/conformance/array-splice-final.json)
retains **86 passed, four failed, two unsupported and four expected resource
stops**: **90 of 96 expectations and all 76 controls verify**. Both modes of
Proxy, typed-array and cross-realm prerequisites remain unmet ordinary-success
expectations. The [before report](../tests/conformance/array-splice-initial.json)
retains 94 availability failures, two unsupported outcomes and only twelve
verified common controls.

The [complete pinned profile](../tests/conformance/test262-array-splice.md)
retains **81 sources / 162 modes**, recording **138 passed / 24 unchanged
metadata exclusions** and **96 verified controls**. Its twelve incidental
before TypeError passes remain visible; failed availability guards prevented
them from proving method support. The original **39 profiles / 17,822 modes /
3,900 controls** gain exactly ten passes: eight find-family callback modes and
two Array.from iterator modes. Every other complete observation and every control
is unchanged, with no lost pass. All **32 established baseline gates** pass.
The new splice baseline and strengthened find/Array.from baselines give **33
configured known-state gates**. All 33 final baseline projections check against
the completed reports with zero regressions or improvements; this was an offline
comparison, with no engine rerun or claim of remote CI execution.
Five selected older local suites preserve **1,192 cases and 172 controls**.
The combined inventory is **40 profiles / 17,984 modes / 3,996 controls**.

Formatting passes. Rust **1.88 and 1.98** each pass strict all-target Clippy and
**1,228 default / 1,239 Vulkan-feature tests**, with zero failed or ignored tests.
All **18 new private groups** pass, covering species/aliasing, partial effects,
mapped-name work, vector-growth storage, sparse lengths and terminal cleanup.
Python validation comprises **212 Test262 tests** on exact staged/imported
tooling and **42 remaining tests**. Both release configurations pass all
**57 CPU pixel references**. The six-block page fixture checks load/click pixels,
classes and result text, directly and through the real confined renderer.
The HTML gate retains **3,868 matches, two mismatches and six unsupported modes**,
with zero regressions. One mutation-smoke run exercises **15,000 generated
cases**, with zero caught panics or invariant failures and seventeen bounded
paint stops. The [integration record](../tests/conformance/array-splice-integration-validation.json)
binds the archives, eight release binaries, reports, logs and independent reviews.

Splice streams live Has/Get and strict mutations without reserving logical
ranges. Same-realm species may return the source, another Array or a supported
ordinary object. Reached tree searches, borrowed mapped names, vector growth
and short-key deletion work receive scoped precharges; Array shrink shares the
existing charged enumeration path. All [quotas](../tests/conformance/array-splice-limits.json)
remain unchanged. General constructor/property/JSON accounting, allocator
fallibility, Proxy/typed-array/cross-realm support and wider compatibility remain
open. These CPU/browser checks make no new GPU or performance claim.

## Standalone Vulkan image rasterization

The [custom raster probe](../tools/vulkan-raster-probe/README.md) adds opaque
nearest-neighbor image commands to the earlier rectangle shader. Its separate
[host record](../tools/vulkan-raster-probe/evidence/host-images.json) binds the
tested source, binary, installed loader, all raw output and independent reviews.
All **21 fixtures on each of three adapters** pass exactly: **921,272 compared
bytes per adapter, 2,763,816 total**. NVIDIA RTX 4070 SUPER (595.99.02), AMD RADV
(Mesa 26.2.3) and llvmpipe (LLVM 21.1.8/Mesa 26.2.3) all exited normally with
empty stderr, as did enumeration. The original seven fixture definitions,
rectangle shader, dependencies and earlier evidence remain byte-identical.

Fourteen image cases use independently frozen literal pixels or direct integer
band predicates, covering scaling, clipping with the original sampling origin,
negative/fractional geometry, exact/ULP/subnormal edges, source reuse, ordered
overlap, fixed-scope restoration, dispatch tails and empty draws. Data-only
review checks fixture transcription, all **642 axis-table entries**, nine scalar
sampling cases and the independently counted protocol. Negative tests retain
25 definitions, 15 hidden-input variants and five exact boundaries; matching
pops isolate the over-depth rejection from unclosed-scope rejection.

Both **Rust 1.88.0 and 1.98.0** pass all **17 tests**, formatting, strict all-target
Clippy and builds. All **ten Python protocol/supervisor tests** pass, including
missing/altered image records and rejection of the earlier seven-only footer.
Both WGSL shaders pass independent offline Naga 30.0.1 validation. The first
Clippy failure in six single-element scalar-test loops is retained; equivalent
direct assertions resolved it. The shader checker's initial linker failure to
create a thread is also retained; the same checker and shaders passed after
single-threaded linking. Neither correction changed expected results or limits.

The actual GPU binary is SHA-256
`20e34cfb03510d5ed02027ebf792fe9988ba069e837a94f7a6988f96a70d46b4`.
Its source and binary hashes were checked before and after execution. All 100
browser production input files remain identical to commit `8133250`; that
checkpoint's full browser matrices, conformance rows and CPU references are
reused, not reported as newly executed here. This isolated crate changes no
browser dependency graph or native-window behavior. Browser GPU integration,
text, blending, opacity groups, total driver memory accounting, production
security and a Chromium performance comparison remain open.

## Shared own-key enumeration accounting

The [enumeration evidence](../tests/conformance/own-keys.json) compares against
published commit `aa22523`. The final release preserves all **17,822 historical
case observations and 3,900 controls** across 39 profiles; all **32 existing gates**
pass with unchanged baselines. The independently frozen local fixture preserves
86 cases and 24 controls. Four selected older local suites preserve another 1,106
case observations and 148 controls. Complete observation records are compared,
including existing failures, exclusions and resource outcomes.

The first candidate preserved every ordinary upstream case but exhausted the
unchanged instruction budget in four Number-statics controls. Those results remain
recorded. Reusing a cached visited-tree entry removes an actual duplicate search;
the original control sources now complete or throw their intended Test262Error.
No quota, oracle, metadata exclusion or baseline was widened.

Rust **1.88 and 1.98** each pass strict all-target Clippy and **1,208 default /
1,219 Vulkan-feature tests**, with zero failed or ignored tests. Both release
variants preserve all **57 CPU pixel references**. The new document/click fixture
passes directly and through the confined renderer. Both HTML adapter binaries
are unchanged, so no new HTML replay is assigned. One deterministic mutation-smoke
run covers **15,000 generated inputs**, with zero caught panics or invariant
failures and seventeen bounded paint stops. Root Python tooling is unchanged
from its preceding 244-test validation.

The [validation record](../tests/conformance/own-keys-integration-validation.json)
retains source, binary, log, fixture and independent-review identities. This
checkpoint covers shared string-key snapshots and reached visited-name operations;
general live property/JSON accounting, allocator fallibility, broader standards,
production security and the requested Chromium comparison remain open.

## Array.from and unchanged historical observations

The [Array.from evidence](../tests/conformance/array-from.json) compares against
published commit `cbb970d`. Its independently frozen local fixture verifies
**388 of 402 expectations**: 376 ordinary passes and twelve expected resource
stops. Ten failures and four unsupported modes retain seven missing language or
platform prerequisites. All **76 controls** verify. The original expectations,
source bytes and denominators remain unchanged.

The [complete pinned upstream profile](../tests/conformance/test262-array-from.md)
has **82 passed, four failed and four metadata exclusions** across 90 modes,
with **96 verified controls**. It gains 74 passes and loses none. Missing
`splice` and `ArrayBuffer` account for the retained failures; generators and
cross-realm features remain excluded. Eight incidental TypeError passes from
the before release remain recorded. The new known-state gate preserves every
remaining gap.

All **38 historical profiles / 17,732 complete case observations / 3,804
controls** remain identical, and all 31 earlier regression gates pass without
baseline changes. Including Array.from, the inventory now contains 39 profiles,
17,822 modes, 3,900 verified controls and 32 known-state gates. Seven profiles
remain observation-only.

Rust **1.88 and 1.98** each pass strict all-target Clippy and **1,187 default /
1,198 Vulkan-feature tests**, with zero failures or ignored tests. All **244
Python tests** pass. Both release variants preserve **57 CPU pixel references**.
A page fixture verifies six visible outcomes before and after a click, directly
and through the real confined renderer. The two HTML adapter binaries are
byte-identical to their published-before versions; the HTML inventory was not
rerun for this checkpoint. One deterministic mutation-smoke run exercises
**15,000 cases**, with no caught panic or invariant failure and seventeen bounded
paint stops. This is not coverage-guided fuzzing.

Independent review verified the frozen inputs, release binaries, logs and
observations. It also identified long-name work undercharging during Array
length shrink; the new Array.from path now prepays those costs. The related
[shared enumeration accounting gap](../tests/conformance/array-from-enumeration-followup.json)
remained open for other callers at that checkpoint and is addressed by the later
own-key follow-up above. Existing runtime limits are unchanged.
This checkpoint does not establish GPU execution, full web compatibility,
production security or the requested Chromium performance bound.

## Date, explicit host rules and complete recursive inventory

The [Date evidence](../tests/conformance/date.json) retains the published-before,
first-candidate and final-release observations. The unchanged recursive Test262
tree contains 594 sources in 51 directories, producing 1,188 modes under a
policy frozen before candidate execution. The final release records 1,162
passes, four existing `for…of` parser failures and 22 metadata exclusions, with
all 340 controls verified. Negative Date controls require their same-mode
positive partner to succeed. Eight focused tooling groups and independent
ancestor/helper/source mutation checks validate the recursive proof path.

All 406 independently frozen local modes and twelve controls pass. Across the
35 older profiles, 130 modes gain passes; no previous pass is lost and all
3,252 control observations remain identical. The combined inventory is 36
profiles, 16,146 modes and 3,592 controls. Twenty-eight existing healthy gates
pass; the new Date gate makes twenty-nine. Seven profiles with resource or
unverified-control outcomes remain observation inventories. No quota or
metadata policy was widened to obtain these results.

Both Rust 1.88 and 1.95 pass strict Clippy and the complete test suite: 1,138
tests in the default configuration and 1,149 with the Vulkan presenter, with
zero ignored tests in these runs. The 223 Python tests pass. Both release
variants pass all 57 rendering references; the HTML inventory stays at 3,868
matching, two mismatched and six unsupported modes. The mutation smoke run
accepts or rejects 45,000 inputs across HTML, scripting and SVG without a
caught panic or invariant failure.

Independent review corrected permanent-DST recurrence equivalence, uncharged
repeated timezone-designation scans, unspecified `-00` rules and Date-slot
storage accounting. Pinned IANA 2026d archives reproduce five timezone fixtures
with the release's own source-built zic. Arithmetic tests and a separate exact
integer/Fraction review cover extreme Date rounding; the renderer receives only
validated zone bytes after confinement. Real-worker tests verify non-UTC Date
execution, while CLI tests verify that missing rules fail clearly and do not
prevent scripts-disabled rendering.

The [worker timing report](benchmark-worker-date.json) records the added roughly
10 ms discovery-polling startup cost and similar warm-frame medians on nine
fixtures. These checks neither certify production security nor establish full
web compatibility or the requested Chromium performance bound.

## Array find methods

The [implementation and frozen fixture](../tests/conformance/array-find.md)
compare against published commit `9bb0684`. The corrected final release passes
all **504 unchanged local variants** and verifies all **twelve controls**;
the before release fails the semantic sources at method-availability guards.
The [evidence record](../tests/conformance/array-find.json) retains the original
source, mode, helper, expectation and runner identities. All **thirteen private
groups** and **75 focused array groups** pass. One initial private test used an
invalid native-callback lookup; its setup was corrected to retrieve installed
Boolean. The failed run is retained, with no production or frozen fixture
change for that correction.

The [complete pinned profile](../tests/conformance/test262-array-find.md)
retains **94 sources / 180 modes**. Its final release has **140 passed,
eight failed and 32 metadata unsupported**, with **288 verified controls**.
It gains **116 passes**; **64 other complete records** remain identical. The
eight retained runtime TypeErrors now reach missing `splice` in callback bodies;
source inspection establishes this dependency because the generic error text
is unchanged. All 24 incidental before TypeError passes remain recorded, while
all 128 new positive before controls fail availability. No healthy before
baseline is claimed.

The first release candidate regressed both modes of
`Array/prototype/lastIndexOf/15.4.4.15-3-16.js` to work-limit stops. Stronger
lookup charges combined with fixed sixteen-digit formatting charges over 2,574
keys exhausted the existing budget. Decimal key construction now precharges
one unit plus its actual one-to-sixteen digit count before the unchanged
64-byte allocation charge, and fills exactly that many stack slots. Both cases
pass again. Stronger lookup charges, all quotas and every corpus contract remain
unchanged. Initial binaries, sources, full reports and the two regressions are
preserved alongside the corrected release.

All **34 prior profiles / 14,778 modes / 2,964 controls** retain their contracts
and complete observations. No previous pass is lost. The combined inventory
has **35 profiles / 14,958 modes / 3,252 verified controls** and **28 healthy
regression gates**, including the new find baseline. Its gate passes while
preserving all eight failures and 32 unsupported modes.

Rust **1.88 / 1.95** pass strict all-target Clippy and **1,084 default / 1,095
Vulkan-feature tests**, none ignored. All **207 Python tests** pass. Both release
configurations preserve **57 CPU pixel references**, and all HTML observations
are unchanged. The corrected deterministic mutation smoke completes **15,000
cases** with zero caught panics or invariant failures in **3.31 seconds**;
17 paint-limit stops remain within the checked invariants. This is smoke
testing, not coverage-guided fuzzing. Final source and binary hashes are retained
in the evidence. No GPU exercise, security certification or Chromium
performance comparison was performed.

## Object integrity

The [implementation and frozen local fixtures](../tests/conformance/object-integrity.md)
compare against published commit `ff48c939`. The final release passes all
**228 unchanged local variants** and verifies all **12 assertion controls**.
Successful method guards precede error assertions; the before release failed
all semantic variants at those guards. The
[complete evidence](../tests/conformance/object-integrity.json) preserves
their original sources, modes, expectations, before/after observations and
publication provenance. Fifteen private runtime test groups check snapshot
refusal, partial descriptor and argument progress, virtual-string flags,
binding-name work, host refusal and terminal resource cleanup.

The [complete pinned profile](../tests/conformance/test262-object-integrity.md)
retains **239 sources / 474 modes**. The final release records **378 passed,
58 failed and 38 unsupported**, compared with **440 failed / 34 unsupported**
before implementation. All **224 controls** verify. There are 378 gains, four
failures now reaching explicit global-host refusal and **92 other identical
observations**. No resource, timeout, adapter or harness errors occur in the
new-profile run. All remaining failures are missing-prerequisite
ReferenceErrors; metadata, parser and host refusals remain separate categories.

All **33 prior profiles / 14,304 cases / 2,740 controls** retain their captured
source, mode, helper, policy, exclusion and generated-control contracts.
Eight older descriptor modes gain passes; the other **14,296 complete older
observations** and all older controls are identical. No previous pass is lost.
The combined **34-profile / 14,778-mode** inventory has **2,964 verified
controls** and **27 healthy regression gates**, including the new integrity
gate and refreshed descriptor baseline. Retained failures and unsupported
cases remain visible in those baselines.

Rust **1.88 / 1.95** pass strict all-target Clippy and **1,071 default / 1,082
Vulkan-feature tests**, none ignored. The full **201-test Python suite** passes,
including proof-tampering and assertion-integrity tests. Both release
configurations preserve all **57 CPU pixel references**, and HTML observations
are unchanged. Deterministic mutation smoke completes **15,000 cases** with
zero caught panics or invariant failures in **3.20 seconds**; 17 paint-limit
stops remain within the checked invariants. This is smoke testing, not
coverage-guided fuzzing. Final binary and source hashes are retained in the
linked evidence. No GPU exercise, security certification or Chromium
performance comparison was performed.

## Array every and some

The [implementation and local fixtures](../tests/conformance/array-predicates.md)
and [complete evidence](../tests/conformance/array-predicates.json) compare
against `f5a5a855`. All **164 unchanged local variants** pass and all **eight
assertion controls** verify. Method-presence and successful-result guards
precede error assertions. Focused runtime tests cover callback allocation
preflight, prior getter effects, recursive paths, sparse scan exhaustion,
early-return allocation and frame cleanup.

The [complete pinned paired inventory](../tests/conformance/test262-array-predicates.md)
retains **437 sources / 867 modes** and gains **801 passes**, reaching **835
passed / 12 failed / four resource stops / 16 metadata exclusions**. Before
implementation it recorded 34 raw passes, 817 failures and 16 exclusions, with
the method preflights unsatisfied. Twelve final failures require missing Date;
four sparse scans exhaust the existing instruction budget. These remain
separate outcomes and prevent a healthy predicate baseline. All **128 new
profile preflights** now verify. Source, mode, expectation and policy
fingerprints are unchanged.

Four older descriptor metadata modes also pass. All **13,433 other older case
records** and **2,612 older controls** are identical. In the new profile, the
other changes are four failures reaching resource limits and four failures
reaching missing Date; the remaining **58 observations** are identical. No
previous pass is lost. The combined **33-profile / 14,304-mode** inventory has
**2,740 verified controls** and retains **26 healthy gates**.

Rust **1.88 / 1.95** pass strict Clippy and **1,056 default / 1,067 Vulkan-feature
tests**. **195 Python tests**, **15,000 mutation cases**, unchanged HTML
observations and both release configurations' **57 CPU pixel references** pass.
Final binary and source provenance are retained in the linked evidence.
No GPU exercise, security certification or Chromium performance comparison
was performed.

## Array descriptors and sparse storage

The [implementation record](../tests/conformance/array-descriptors.md) and
[evidence](../tests/conformance/array-descriptors.json) compare against `48fce52d`.
The complete **1,793-source / 3,574-mode** property-definition/array-length
inventory gains **664 passes**, reaching **3,466 passed / 88 failed / 20
unsupported**. Its source inventory is verified through complete pinned Git
trees, including all 1,131 defineProperty entries. Older profiles gain **233
passes**: 150 reduction modes, 45 lastIndexOf modes, 32 sort modes and six JSON
modes. Two lastIndexOf modes still stop at the shared work budget while scanning
huge sparse ranges; their earlier resource stop occurred during dense setup.
All other **9,628 older observations / 2,528 older controls** are unchanged.
The **32-profile / 13,437-mode** inventory has **2,612 verified controls** and
**26 healthy regression gates**, including the new descriptor gate. No
previous pass, source, feature policy or case fingerprint is lost.

All **72 frozen local modes** pass. One new preflight pair initially left its
readonly element configurable and therefore expected an invalid TypeError;
the corrected setup makes the element nonconfigurable. Original before/after
observations and all four changed control fingerprints are retained. Independent
bounded code and tooling reviews found no concrete defect; eight additional
proof-tampering probes were rejected.

Rust **1.88 / 1.95** pass strict all-target Clippy and **1,053 default / 1,064
Vulkan-feature tests**, none ignored. **189 Python tests**, **15,000 mutation
cases**, unchanged HTML observations and both releases' **57 CPU pixel references**
pass. Sparse storage changes required replacing old allocation-pressure fixtures
with actual dense values; persistent page suspension remains checked. JSON key
snapshots and sort/reverse retain documented resource bounds. No GPU exercise,
security certification or Chromium performance comparison was performed.

## Array lastIndexOf

The [implementation record](../tests/conformance/array-last-index-of.md) and
[evidence](../tests/conformance/array-last-index-of.json) compare against `e52d3fa`.
The complete new **198-source / 395-mode** inventory gains **328 passes**, reaching
**338 passed / two failed / eight resource stops / 47 unsupported**. All other
new observations are identical. Date, dense array storage and indexed descriptors
remain dependencies; declared Proxy/resizable-buffer modes remain excluded.
The profile remains an observation inventory because resource stops persist.

Both older String.lastIndexOf failures now pass. All other **9,466 older
observations / 2,448 older controls** are identical. The **31-profile / 9,863-mode**
inventory has **2,528 verified controls** and retains 25 healthy gates. No prior
pass, policy, case fingerprint or source byte is lost. All **24 unchanged local
modes** pass. Rust **1.88 / 1.95** pass strict all-target Clippy and **1,033 default /
1,044 Vulkan-feature tests**, none ignored. **183 Python tests**, **15,000 mutation
cases**, unchanged HTML observations and both releases' **57 CPU pixel references**
pass. No independent review, GPU exercise or Chromium comparison was performed.

## String lastIndexOf

The [implementation record](../tests/conformance/string-last-index-of.md) and
[evidence](../tests/conformance/string-last-index-of.json) compare against `569991c`.
The complete new **25-source / 50-mode** inventory gains **46 passes**, reaching
**48 passed / two failed**, with no exclusions. The remaining modes invoke missing
Array.lastIndexOf. Match/search gains **12 older passes**; all other **9,406 older
observations / 2,368 older controls** are identical. The **30-profile / 9,468-mode**
inventory has **2,448 verified controls** and 25 regression gates.

All **28 corrected local modes** pass. The original descriptor fixture accidentally
deleted its method through `verifyProperty`; its original before/after observations
remain in the evidence. A one-line restoration fix changes exactly two fingerprints,
and both binaries were rerun. No pinned source changed. Rust **1.88 / 1.95** pass
strict all-target Clippy and **1,030 default / 1,041 Vulkan-feature tests**, none
ignored. A deterministic search differential checks **12,288** UTF-16 inputs and
positions. **180 Python tests**, **15,000 mutation cases**, unchanged HTML observations
and both release builds' **57 CPU pixel references** pass. No independent review,
GPU exercise, security audit or Chromium performance comparison was performed.

## String and RegExp match/search protocols

The [implementation record](../tests/conformance/regexp-match-search.md) and
[evidence](../tests/conformance/regexp-match-search.json) compare against `d7cee45`.
The complete new **170-source / 340-mode** selection gains **138 passes**, reaching
**304 passed / 16 failed / 20 unsupported**. Remaining failures expose lastIndexOf
and BigInt dependencies. Every other new observation is identical, as are all
**9,078 older observations / 2,288 older controls**. Source fingerprints, policies
and 23 older baselines remain unchanged. The combined **29-profile / 9,418-mode**
inventory has **2,368 verified controls** and adds a 24th regression gate.

All **44 supported local modes** pass; two original modes still stop at the
unimplemented Array indexed-descriptor API. Their source/outcomes and all 24
original diagnostic fingerprints are retained. A separate inherited Object
prototype setter test passes. All 80 new-profile controls verify, versus 56 before.
Rust **1.88 / 1.95** pass strict all-target Clippy and **1,026 default / 1,037
Vulkan-feature tests**, none ignored. Both releases preserve **57 CPU pixel
references**. **177 Python tests**, **15,000 mutation cases** and unchanged HTML
observations pass. Callback recursion, infinite match results, heap refusal and
cleanup are tested. No independent agent review, GPU exercise or Chromium
performance comparison was performed.

## Required literal counts before regexp matching

The [implementation record](../tests/conformance/regexp-required-literals.md) and
[evidence](../tests/conformance/regexp-required-literals.json) compare against
`45fb59e`. Both unchanged XML-pattern modes now complete, bringing the constructor
directory to **774 passed / 200 unsupported / two script-work resource stops**.
All **9,076 other observations / 2,288 controls** are identical; sources, policies,
mode fingerprints and 23 healthy baseline gates are unchanged. All **30 frozen
local modes** pass, including eight former resource stops.

The direct comparison preserves **3,888 parse outcomes / 106,040 complete capture
or error outcomes**. Rust **1.88 / 1.95** pass strict all-target Clippy and **1,023
default / 1,034 Vulkan-feature tests**, none ignored. Both releases preserve
**57 CPU pixel references**. **174 Python tests**, **15,000 mutation cases** and
unchanged HTML observations pass. Seven alternating timing samples retain the
measured compilation overhead and matching results; they are synthetic direct
Rust calls, not browser workloads or Chromium measurements. No independent agent
review or GPU exercise was performed.

## Flat regexp group parsing and prefix analysis

The [implementation record](../tests/conformance/regexp-deep-groups.md) and
[evidence](../tests/conformance/regexp-deep-groups.json) compare against `1c660e8`.
Four unchanged Test262 modes for 200 nested groups now pass, bringing the complete
constructor directory to **772 passed / 200 unsupported / four resource stops**.
All **9,074 other observations / 2,288 controls** are identical. No source,
policy, mode fingerprint or healthy baseline changes. The remaining work-budget
stops keep this profile an observation inventory.

All **20 frozen local modes** pass after previously stopping on depth/capture
limits. A direct comparison preserves **3,888 parse outcomes / 106,040 complete
capture or error outcomes**. Small-stack regressions compile and match 2,000
nested groups; syntax, resource and lookahead execution guards remain tested.
Rust **1.88 / 1.95** pass strict all-target Clippy and **1,020 default / 1,031
Vulkan-feature tests**, none ignored. Both releases preserve **57 CPU pixel
references**. **174 Python tests**, **15,000 mutation cases** and unchanged HTML
observations pass. No independent agent review, GPU exercise or Chromium
performance comparison was performed.

## RegExp constructor classification and conversion

The [implementation record](../tests/conformance/regexp-constructor.md) and
[evidence](../tests/conformance/regexp-constructor.json) retain all 488 direct
constructor-directory sources: **768 passed / 200 unsupported / 8 resource
stops**, gaining **16 passes** over the preserved `f3a786b` binary. The resource
cases remain identical and prevent a healthy baseline for this new profile.
No old baseline changes. All **8,102 older case objects / 2,216 controls** remain
identical; the combined inventory reaches **28 profiles / 9,078 modes / 2,288
verified assertion controls**, with unchanged policies between comparisons.

All **36 corrected local modes** pass. An added fixture's unrelated prototype
assumption was corrected and remeasured on both binaries; its initial source and
observations are retained, as are all 20 original diagnostic fingerprints. Rust
**1.88 / 1.95** pass strict all-target Clippy and full tests: **1,017 default /
1,028 Vulkan-feature tests**, none ignored. Both release builds preserve all
**57 CPU pixel references**. **174 Python tests**, **15,000 mutation cases** and
unchanged upstream HTML observations pass. Resource tests cover parser charges
on success/failure, every representative work cutoff, recursion and heap refusal.
Agent quota remains unavailable; no independent agent review, GPU rendering or
Chromium comparison is claimed.

## RegExp split and species construction

The [implementation record](../tests/conformance/regexp-split.md) and
[evidence](../tests/conformance/regexp-split.json) cover 48 complete pinned sources:
**88 passed / 2 failed / 6 unsupported modes**, gaining **86 passes** over the
preserved `cd1c016` binary. The remaining failures now reach missing Date; realm
and Unicode regexp prerequisites remain unsupported. Every older case object and
assertion control is identical. The inventory reaches **27 profiles / 8,102 modes /
2,216 verified controls**, with only one new baseline and no old policy changes.

All **32 supported local modes** pass; the two original array-descriptor
prerequisite modes remain unsupported. Rust **1.88 / 1.95**, strict all-target
Clippy and full tests pass: **1,014 default / 1,025 Vulkan-feature tests**, none
ignored. Both release builds preserve all **57 CPU pixel references**. **171
Python tests**, **15,000 mutation cases** and the unchanged upstream HTML baseline
pass. Resource tests cover recursive callbacks, hostile capture lengths and
indices, heap refusal and cleanup. Agent quota remains unavailable; no independent
agent review, GPU rendering or Chromium comparison is claimed.

## String conversion, search and custom splitting

The [implementation record](../tests/conformance/string-conversion.md) and
[evidence](../tests/conformance/string-conversion.json) retain a new complete
242-source String search/split selection: **470 passed / 2 failed / 12 unsupported
modes**, gaining 18 passes over the frozen `707ada1` binary. The two older
string-slice failures also pass; every other old case observation is identical.
All **8,006 modes** preserve their fingerprints and previous passes. All **2,144
assertion controls** verify; the 2,072 older controls and all old policies remain
unchanged. One existing baseline and one new baseline record these results.

The frozen local conversion and split-hook fixtures now pass all **54 modes**.
Rust **1.88 / 1.95** pass strict all-target Clippy and full tests: **1,011 default /
1,022 Vulkan-feature Rust tests**, none ignored. Both release configurations
preserve all **57 CPU pixel references**. **168 Python tests** and **45,000
mutation cases** pass. Upstream HTML case objects remain identical. Resource
tests cover recursive conversion, Symbol getters/calls, exhausted heap refusal
and counter/frame cleanup. No GPU rendering or Chromium comparison was run.
Agent quota remains unavailable; no independent-agent review is claimed.

The two remaining failures require undeclared BigInt syntax in unchanged upstream
sources. Unsupported eval and RegExp parsing cases remain visible. Built-in
RegExp Symbol.split/species, other String symbol protocols and Function source
printing remain incomplete; this is not full standards conformance or audited
security.

## Dynamic ordinary Function construction

The [implementation record](../tests/conformance/function-constructor.md) and
[evidence](../tests/conformance/function-constructor.json) cover the 200-source
Function constructor selection: **241 passed / 50 unsupported modes**, gaining
157 passes over the frozen old binary. Older selections gain another 35 passes;
two previously unsupported string-slice modes now reach retained failures. All
**7,522 mode fingerprints** and prior passes remain preserved, with **2,072
verified assertion controls**. Existing policies and all 2,008 old controls are
unchanged. Three old baselines and one new baseline record the reviewed results.

All **30 frozen local semantic modes** move from unsupported to passed. On Rust
**1.88 / 1.95**, strict all-target Clippy and full tests pass: **1,008 default /
1,019 Vulkan-feature Rust tests**, none ignored. Both release builds preserve
**57 CPU pixel references**; GPU rendering was not exercised. **165 Python tests**
and **15,000 mutation cases** pass. All upstream HTML case objects remain identical.
Resource tests exercise successful and failed compilation charges, every work
cutoff for representative parses, heap refusals, recursion and counter cleanup.

The initial full Rust run exposed an obsolete assertion that Function was
unsupported; it now asserts the constructed function's result. A Python policy
test was updated to recognize the new profile's explicitly selected rest support.
The original malformed resource-test draft and rest-parser failure are described
in the implementation record. Function string conversion/source printing and
literal unpaired surrogate source remain incomplete. Full web compatibility,
independently audited security and Chromium performance parity remain unfulfilled.

## Symbol targets and constructor policy expansion

The [policy checkpoint](../tests/conformance/constructor-policy.md) admits 88
previously excluded modes. Its [evidence](../tests/conformance/constructor-policy.json)
separates 86 cases that already passed from two Symbol constructor failures fixed
by the implementation. All 7,231 mode fingerprints remain unchanged and no prior
pass is lost. Two cross-realm exclusion diagnostics change without admitting
those tests. All other observations and all 1,960 old assertion controls are
unchanged; 48 added controls bring the verified total to 2,008.

The ten frozen local modes pass after failing before the fix. On Rust 1.88 and
1.95, strict all-target Clippy and all tests pass: **1,005 default / 1,016 feature
Rust tests**, none ignored. Both release builds preserve **57 CPU pixel references**.
**162 Python tests** and **15,000 mutation cases** pass. HTML case objects remain
exactly unchanged. Eighteen policy baselines were reviewed and updated; the four
resource-observation profiles remain observations. These checks do not establish
full platform compatibility, audited security or Chromium performance parity.

## Reflect calls and constructor targets

The [constructor checkpoint](../tests/conformance/construction.md) adds private
`new.target` state, Reflect call/construction operations, bound forwarding and
alternate allocation prototypes. Its [evidence](../tests/conformance/construction.json)
binds the source, binaries, complete inventories, controls and observations.

The 33 newly imported Test262 sources produce 66 modes: **52 passed, four failed,
ten unsupported**, gaining **46 passes** against the preserved prior binary.
All **160 new assertion controls** verify. The four failed modes reach missing
Date support; unsupported modes and unchanged sources remain in the inventory.
All **7,165 modes and 1,800 controls** in the older 22 profiles are exactly
unchanged, including observations and policies. All upstream HTML case objects
are also unchanged: 3,868 matched, two mismatched, six unsupported.

On Rust **1.88 / 1.95**, formatting, strict all-target Clippy and full tests pass:
**1,003 default / 1,014 Vulkan-feature Rust tests**, none ignored. Both release
builds preserve **57 headless CPU pixel references**; GPU presentation is outside
these checks. **161 Python tests**, all **26 local constructor modes**, and
**45,000 deterministic mutation cases** pass. Existing resource quotas and call guards remain in force; private slots and forwarded argument storage are charged. A targeted
exhausted-heap test first exposed allocation before bound-arrow rejection, then
passed after validation moved ahead of copying. No compatibility-wide, audited
security or Chromium performance conclusion follows from these results.

## Optional Vulkan upload presenter

The optional Linux presenter uploads frames produced by the custom CPU painter.
Software remains the default/headless path. The [implementation record](vulkan-rendering.md)
and [compact evidence](evidence/vulkan-presenter.json) bind the final source,
dependencies, binaries, case inventories and native outcomes to their hashes.

Formatting passes. On both Rust **1.88** and local **1.95**, strict all-target
Clippy and full tests pass: **997 default / 1,008 feature-enabled Rust tests**, none ignored.
Both release binaries preserve all **57 headless CPU pixel references**. Those
references do not exercise the GPU. **158 Python checks** pass, and **45,000
generated cases** finish without a caught panic or invariant failure. Three
pre-existing Clippy findings were fixed without changing their operations.

The actual browser presented on **Wayland / NVIDIA GeForce RTX 4070 SUPER** using
Bgra8Unorm, Srgb display color space, opaque composition and FIFO. **Eight distinct
acquired textures matched all 30,841,144 bytes** before presentation, including
changed viewport revisions and odd widths. A missing-driver run cleanly selected
software after confirmed release. Missing-driver verification and insufficient
sampling both exited nonzero. **20 additional missing-driver launches** passed,
including ten traced runs. All tracked test processes exited and were reaped.
No new compositor capture, alternate-adapter result or performance claim is made.

Initial native failures remain recorded. The first presenter exposed transient
Vulkan loader manifest descriptors inherited by the page worker. Four of ten
traced diagnostic launches reproduced rejection. A graphics/spawn mutex candidate
still failed: hardware initialization retained an inheritable `/dev/udmabuf`
handle, rejected in three diagnostic launches. The mutex was removed. The final
feature-enabled launch stage marks all non-stdio descriptors close-on-exec and
execs the worker; its strict descriptor rejection stays intact. The real-binary
regression checks both direct rejection and sanitized startup, preserving the
parent's descriptor flags and handle. Renderer/broker/decoder policies and IPC
framing are unchanged; only the internal feature-enabled launch command changes.

All **22 Test262 profiles / 7,165 modes / 1,800 controls** have identical sources,
policies, cases and observations to the concat checkpoint. No baseline changes.
HTML remains **3,868 matched / two mismatched / six unsupported**. The combined
optional graph adds 47 lock packages (35 extra active Linux dependencies); no
existing version, source or checksum changes. The two stripped browser binaries
are 11,327,312 bytes by default and 15,123,208 with the optional feature. These
sizes are observations, not startup, throughput or memory benchmarks.

The tests cover mailbox storms, stale epochs, conversion/padding, fixed deadlines,
callback reentrancy, simulated stuck cleanup, panic and late release. They do not
establish real driver-hang recovery. Native minimize/restore, forced surface/device
loss, broader platform coverage and full GPU reference coverage remain open.
The earlier four non-exact compositor captures remain failures. Agent sessions
were unavailable; this implementation has local self-review and tests, not an
independent implementation review. Full web compatibility, audited security and
the requested Chromium performance bound remain unmet.


## String.prototype.concat

The [concat implementation](../tests/conformance/string-concat.md) passes **995
Rust tests** with `--include-ignored` (813 library, none ignored), formatting,
strict all-target Clippy, release compilation, **158 Python checks**, **57 exact
pixel references**, and **15,000 mutation cases** without a caught panic or
invariant failure. Seven Rust groups and three Python groups cover conversion,
UTF-16/resource boundaries, complete corpus integrity and assertion failures.

The new complete **22-source / 44-mode** directory records **42 passed / two
metadata-unsupported** modes. The same frozen before binary records 40 failed,
two passed and two unsupported; its new feature preflight fails (34/56 verify).
Those two initial passes accept a construction exception even when the method is
absent. The new binary verifies all **56 controls**. The two unsupported modes
still require Reflect.construct. The new healthy baseline retains all 44 modes.

All **21 previous profiles / 7,121 modes / 1,744 controls** preserve their sources
and policies. No pass is lost and no control changes. Two existing Symbol failures
now reach missing Date instead of missing concat; all other observations remain
identical, including resource stops. Existing baselines are unchanged. The combined
inventory is **22 profiles / 7,165 modes / 1,800 verified controls**, with 18 healthy
baseline gates and four resource observation profiles. HTML remains 3,868 matched,
two mismatched and six unsupported.

The **28 frozen local probe modes** retain all sources and fingerprints: 26 improve,
while two original metadata probes remain failed because their own use of upstream
verifyProperty deletes the method without restoration. The initial focused Rust
run exposed this fixture error. The unchanged original source now has a regression
check for its TypeError and deletion; a separate corrected metadata probe passes
both modes using `{restore:true}`. These retained failures are not counted as
conformance passes, and no upstream source or helper was changed.

The [public comparison](../tests/conformance/string-concat.json) records exact
cases, controls, policies and hashes. Local evidence is `artifacts/*string-concat*`.
Prior commit `ab5740b` passed all jobs in [CI run 36492738848](https://github.com/Eriskii/ErisBrowser/actions/runs/36492738848).
Quotas remain unchanged. Agent sessions were unavailable, so no independent-agent
review is claimed. No native-window check, browser Vulkan integration, security
audit or Chromium comparison is claimed. The full browser requirements remain unmet.


## Window properties and global bindings

The [binding checkpoint](../tests/conformance/window-global-bindings.md) adds
ordinary Window definitions/accessors, exact UTF-16 keys, private execution
receivers and general global declaration validation. **988 Rust tests** pass
with `--include-ignored` (806 library, none ignored), along with formatting,
strict all-target Clippy, release compilation, **155 Python checks**, **57 exact
pixel references**, and **15,000 mutation cases** with no caught panic or invariant
failure. Seven new Rust groups cover the change. Three older groups initially
expected definitions to be unsupported; they retain the original operations and
now check successful property creation. Unimplemented event-handler deletion
remains an explicit unsupported result.

All **64 frozen self-authored modes** now pass: 32 gains and 32 preserved passes.
Their sources, language modes and fingerprints are unchanged. All **21 upstream
profiles / 7,121 modes / 1,744 controls** retain their inventories and policies.
**13 cases gain passes** (11 compound assignment, two RegExp), with no lost passes
or other observation/control changes. Both healthy improved baselines preserve
all cases. All 17 healthy gates pass; four resource-stopped profiles remain
observations. HTML retains 3,868 matched / two mismatched / six unsupported.

The [public comparison](../tests/conformance/window-global-bindings.json) records
source/release hashes, exact probe outcomes, full profile comparisons and baseline
updates. Local evidence is `artifacts/*global-bindings*`. Prior commit `5e69e4a`
passed all jobs in [CI run 36490270776](https://github.com/Eriskii/ErisBrowser/actions/runs/36490270776).
Quotas are unchanged; accounting remains estimated. Agent sessions were unavailable,
so no independent-agent review is claimed. Full Window/ECMAScript compatibility,
production security and the Chromium target remain unmet. No native-window check
or browser Vulkan integration is claimed for this change.


## Window property order and reflection

Formatting, strict all-target Clippy and release compilation pass. **981 Rust
tests** pass with `--include-ignored` (799 library; none ignored), alongside
**155 Python checks**, **57 exact pixel references** and **15,000 mutation cases**
without a caught panic or invariant failure.

[Window binding reflection](../tests/conformance/window-reflection.md) adds own
membership/enumerability and ordered key snapshots, preserves live `for-in`
deletion/shadowing, and corrects intrinsic binding flags. Six new Rust groups cover
these behaviors and resource refusals. Two older groups initially failed because
they expected Window enumeration to be unsupported. They now check successful
enumeration; the old `finally` source is retained as a success check and unsupported
Document enumeration preserves the host-stop check. Original resource cuts and
looping checks are unchanged.

The **32 frozen self-authored modes** retain all sources and fingerprints:
**26 improve**, two earlier passes remain, and four general Window definition
cases remain unsupported. All **21 upstream profiles / 7,121 modes / 1,744 controls**
retain their sources and policies. Exactly **54 modes improve**: global values 22,
Symbols two, Number statics two, numeric conversion four, numeric parsing eight
and URI functions 16. No passes are lost; all controls verify. Every other
observation, including resource stops, is unchanged.

Four healthy baseline files gain the new passes while preserving their complete
inventories. Numeric parsing and URI remain resource-stopped observations. All
17 existing baseline gates pass. HTML retains **3,868 matched / two mismatched /
six unsupported** modes without change. The
[public comparison](../tests/conformance/window-reflection.json) records all probe
outcomes, profile comparisons, source/release hashes and baseline changes. Local
evidence is `artifacts/*global-reflection*`. Prior commit `6b4d18e` passed all jobs
in [CI run 36488324312](https://github.com/Eriskii/ErisBrowser/actions/runs/36488324312).

Creation serial storage and snapshots use the existing estimated ledger; no quota
increased. Full Window interfaces, general property definitions/accessors and
arbitrary UTF-16 host property storage remain incomplete. Agent sessions were
unavailable, so no independent-agent review is claimed. No native-window, Vulkan
integration or Chromium comparison was run. Full compatibility and production
security remain unverified.

## DOM string conversion and operation receivers

Formatting, strict all-target Clippy and release compilation pass. **975 Rust
tests** pass with `--include-ignored` (793 library; none remain ignored), along
with **155 Python checks**, **57 exact pixel references** and **15,000 mutation
cases** without a caught panic or invariant failure.

Supported [DOM methods](../tests/conformance/dom-string-conversion.md) now use
their actual receiver, validate required arguments, and convert strings before
their DOM effects. Six Rust groups cover method identity/call/apply/bind, abrupt
and reentrant hooks, nullable/Boolean rules, token validation and resource limits.
Two existing private native-call fixtures initially failed because they used old
internal method identifiers. Updating those identifiers retained their original
budgets, input trees, operations and no-mutation assertions; the full suite passes.

All **22 frozen self-authored probe modes** remain in the
[comparison](../tests/conformance/dom-string-conversion.json): **16 improve**, two
prior passes remain, and four unrelated global-reflection modes remain unsupported.
Sources, case fingerprints and language modes are unchanged. The nine DOM sources
also run in both modes as Rust regression fixtures. This is focused implementation
evidence, not a full upstream DOM or Web IDL conformance result.

All **21 existing Test262 profiles / 7,121 modes / 1,744 controls** preserve every
source/case fingerprint, policy and observation, including resource stops. All
controls verify; no passing case is lost. Seventeen healthy baseline gates pass;
four resource-stopped inventories remain observations. No baseline was changed.
HTML retains **3,868 matched / two mismatched / six unsupported** modes, with no
regression or improvement.

The public comparison records the source-input digest, source and release binary
hashes, exact probe outcomes and per-profile comparisons. Local evidence is
`artifacts/*dom-conversion*`. Prior commit `cbbfd22` passed all jobs in
[CI run 36485477521](https://github.com/Eriskii/ErisBrowser/actions/runs/36485477521).

Quotas remain unchanged. DOM storage still replaces lone UTF-16 surrogates, and
full interfaces, live collections, XML name validation and hierarchy semantics
remain incomplete. Agent sessions were unavailable; no independent-agent review
is claimed. No native-window, Vulkan integration or Chromium performance result
is assigned to this change. Full compatibility and production security remain
unverified.

## Symbol identities and property-key integration

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy and release
compilation pass. **969 Rust tests** pass with `--include-ignored` (787 library;
none remain ignored), alongside **155 Python checks**, **57 exact pixel references**
and a **15,000-case** mutation run with no caught panic or invariant failure.

[Symbol support](../tests/conformance/symbols.md) introduces distinct primitive
identities and property keys, boxed/registry/description behavior, computed key
names, descriptors, JSON omission, primitive/tag/instance hooks and key reflection.
Ten focused Rust groups cover both language modes, abrupt effects, mutation order,
resource refusals and callback cleanup. Numeric consumers now reject Symbol
conversion. Symbol descriptions are charged before legacy host/display formatting.
No quota changed. Existing host string conversions and broader protocols still
need work.

The new complete **123-source / 242-mode** Symbol and key-reflection profile
records **166 passed / 6 failed / 70 unsupported**, with all **64 controls** verified.
Sixty-six unsupported modes are excluded by metadata; four stop on class syntax or
host/global reflection. The six failures reach missing String concat/Date, Proxy
and collection-species dependencies. The frozen prior binary ran the same inventory
and policy but failed preflights; its raw report is retained without treating it as
a healthy baseline.

All **20 existing profiles / 6,879 modes / 1,680 controls** retain their source
identities and policies. Exactly **14 modes improve**: eight reduction cases use the
actual Math/JSON tags, and six logical-assignment cases gain Symbol conversion.
There are no lost passes, changed controls or other changed observations, including
resource stops. The new profile brings the total to **7,121 modes / 1,744 controls**.
Seventeen healthy passing-case gates are now enabled; four resource-stopped profiles
remain explicit observations. HTML remains 3,868 matched, two mismatched and six
unsupported modes. The new Symbol baseline and the two improved baselines preserve
all failures and unsupported cases.

The [public comparison](../tests/conformance/symbol-properties.json) and complete
[before](../tests/conformance/test262-symbols-before-properties.json)/
[after](../tests/conformance/test262-symbols-properties.json) Symbol reports retain
provenance. Local evidence is `artifacts/*symbols*`. Prior checkpoint `97ea66c`
passed all jobs in [CI run 36480560165](https://github.com/Eriskii/ErisBrowser/actions/runs/36480560165).

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `cbe8691a6bc4c5af6edaba8bbf15349a3aedd669a17d5d52e130ff9a8f04aea4` |
| `eris-js` | `4b890d92a4027dc929be92ba366b0cf670f94f18e4bfb28025e365aba6bbab57` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `3335cf7c7732ac618dee11202075241ce00fb8c00dab452b37e33bb13538b381` |

Source-input SHA-256: `857547575004ab839a59028a72d9e709413f2b1ced8cad2d52c2da5bb39dc0c9`.

Agent sessions remain unavailable; no independent-agent review is claimed.
No native-window, Vulkan integration or Chromium performance comparison was run.
Full web compatibility and production security remain unverified.

## Bounded JavaScript grammar continuations

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **959 Rust tests** pass with `--include-ignored`: 777 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks** and
**57 exact pixel references** pass.

[Grammar continuations](../tests/conformance/parser-continuations.md) replace
supported JavaScript grammar recursion with a parser-owned flat work stack.
Expressions, statements, function/default contexts and template substitutions
retain the shared compile ledger. Obsolete grammar-depth and member/constructor
chain guards are removed after the guarded conversion passed its initial checks.
Source/token/work/storage quotas, active-label and declaration-walk bounds,
logical calls and native-helper guards remain unchanged.

Six new driver test groups cover small-stack source parsing, unchanged upstream
32-IIFE parsing/execution/release, 128-link member/call/constructor chains,
malformed deep input cleanup, refused frame growth and literal dispatch. Requested
128 KiB stacks parse and release 256 nested IIFEs, 512 blocks/functions and the
other documented shapes. The literal test compares 28 sources in four contexts
against the private oracle and parses the unchanged 2,048-element sort source.
Existing grammar/scope/completion, work-cutoff, heap-refusal and flat-destruction
checks remain. Earlier guard-refusal assertions retain their original sources
and now assert acceptance, with larger independent-quota cases added.

The initial complete upstream run exposed two earlier resource stops in the
2,048-element sort test: redundant grammar dispatch exhausted compile work.
Terminated numeric/string literals now finish directly instead of suspending
empty grammar layers. The unchanged source again reaches the same runtime
instruction-limit outcome as before, under the original budgets. Initial logs,
source/binary hashes and reports remain recorded locally.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** preserve source identities
and policies. Exactly two upstream observations improve: both modes of the original
32-nested-IIFE function test now pass. Every other case and all controls are identical.
The function profile reaches **511 passed / 620 unsupported** and now has a healthy
CI baseline. Sixteen healthy gates pass; four resource-stopped profiles remain
nonpassing observations. No old baseline, upstream test, assertion or policy changed.
HTML remains 3,868 matches, two mismatches and six unsupported modes.

All **480 existing depth sources** remain unchanged. All three shapes parse
through the tested depth of 40 and execute through 32 calls, with call 33 stopped
by the logical ceiling. The nested-IIFE shape gains 104 completions and changes
16 parse-resource outcomes to runtime logical-call stops, with no lost completion.
Ordinary/default observations are identical.

The final **15,000-case** mutation run catches no panic or invariant failure.
An earlier 45,000-case run also completed without caught panics before the literal
dispatch correction; the final release was checked again after that change.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `dfc989f3cff62c3422bc78972b1bd53f0e2bd74f54a92fe4f141e97d6c32459f` |
| `eris-js` | `af3f3205e0a7f13ade2a9236ca22bf8bfefe20ef947a3c106e48c7f0bb711da7` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `36bef395c7f9b391e5e3ac7d53c622ffa7dd67e832d29a82393fccf744f618aa` |

Source-input SHA-256: `e314cfc86bed205fa1f32ae17320d4dead05055c468d81e94f424afe9ab107fb`.
Local evidence is `artifacts/*parser-continuations*`; the
[public comparison](../tests/conformance/parser-continuations.json),
[full function report](../tests/conformance/test262-functions-parser-continuations.json)
and [depth inventory](../tests/conformance/parser-continuations-depth.json)
preserve provenance. Prior checkpoint `e546e7a` passed every job in
[CI run 36474559666](https://github.com/Eriskii/ErisBrowser/actions/runs/36474559666).

Agent sessions remain unavailable; no independent-agent review is assigned.
Declaration depth, remaining allocation accounting and native bridges need further
work. No native-window, Vulkan or Chromium comparison was run for this change.
Full compatibility, production security and the requested performance threshold
remain unverified.

## Direct flat parser ownership

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **953 Rust tests** pass with `--include-ignored`: 771 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

[Direct flat parsing](../tests/conformance/flat-parser.md) replaces the production
owning AST and second lowering pass. Typed record IDs cover defaults, methods,
function bodies and inline handlers from their initial construction. Record pages
and parser lists share the original compile ledger; one-pass cover grammar moves
names/default IDs into parameters and retains charged tombstones. The old owning
parser remains only as a private frozen test oracle. Ordinary driver source tests
now use the production parser.

Seven new parser groups include **85 grammar sources / 340 mode-context cases**,
144 existing name-diagnostic modes, 240 completion-fixture modes and 144 nesting
guard comparisons. Payloads and early errors match the oracle. Every work cutoff
and sampled heap refusals in five fixtures share the same compile/publication
ledger. Other checks cover default/RegExp/template identity, handler metadata and
partial-unit release. Two record-page groups verify indices, descriptor work,
retained values and precharged refusals. A thread requesting **64 KiB** releases
directly constructed **16,000 unary edges and 8,000 labeled-statement edges** after
successful or refused publication. This is a destruction test, not deeper parsing.

The initial complete library run exposed a compile-work regression in the existing
8,327-declaration Unicode fixture. Paged records alone were insufficient; the root
body now also reserves its ID slots from the already lexed prefix, avoiding
repeated copies. The unchanged fixture passes with the original quotas. Initial
build/test-integration diagnostics and those failed attempts remain in local logs.
Grammar recursion and its depth guards have not changed.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** retain identical case
identities, policies, preflight observations and every case observation. Fifteen
healthy baseline gates pass; five resource-stopped profiles remain nonpassing
observations, with no new baselines. HTML remains at 3,868 matches, two mismatches
and six unsupported modes. All **480 depth observations** are unchanged: ordinary
and default recursion reaches 32 calls, while nested IIFEs still stop in parsing
at depth eleven. The original upstream 32-nested-IIFE source remains unchanged.

The **15,000-case** mutation run catches no panic or invariant failure: 5,000
accepted HTML, 623 accepted/4,377 rejected scripts and 3,347 accepted/1,653 rejected
SVG inputs. Maximum DOM/display-list sizes are 191 nodes/1,173 commands;
17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `9abb7c64d2a0af29bf671db035416774e9b48bca9706f8c094f192fc0ae49143` |
| `eris-js` | `caf321e9de54b1e24268d6d8b8b9bfbe99e97dd9f1e7320a5d6e07ae1d38590e` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `511ff5a9db04537425b304ed5fe28f4146d64eee2810fc68ece14d100f0473b7` |

Source-input SHA-256: `d7f8d3fea81a4f2d89aabd02aab976961f44c2d044b91aca2806a18fee884cd2`.
Local evidence is `artifacts/*flat-parser*`; the
[public comparison](../tests/conformance/flat-parser.json) and
[depth inventory](../tests/conformance/flat-parser-depth.json) preserve provenance.
The prior activation checkpoint `2c6cf75` passed every job in
[CI run 36470693599](https://github.com/Eriskii/ErisBrowser/actions/runs/36470693599).

Agent sessions remain unavailable; no independent-agent review is assigned.
Grammar continuations, remaining allocation accounting and bounded declaration
traversal still need work. No native-window, Vulkan or Chromium comparison was
run for this parser change. Full compatibility, production security and the
requested performance threshold remain unverified.

## Ordinary activation and default continuations

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **944 Rust tests** pass with `--include-ignored`: 762 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

[Ordinary activations, defaults and bound forwarding](../tests/conformance/activation-frames.md)
now share the expression/statement driver. Queued invocations own their logical
count after a successful reservation; native callback roots retain their external
count and guard. Parameter environments, TDZ, argument mapping, default closures
and body completion preserve their behavior. Bound arguments use one checked,
precharged copy; parameter evaluation drops its actual-value buffer before body
execution. Native helpers and constructors remain guarded bridges.

Fully iterative JavaScript no longer consumes obsolete native-depth charges.
Continuation storage now derives its ceiling from the unchanged 8 MiB allowance
and actual record size, with growth work/storage prepaid. The 32-call, 100,000-work,
96-native-stack-unit and parser constants remain. This changes depth behavior:
the [480-case inventory](../tests/conformance/activation-frames-depth.json) gains
**72 successful runs**, while **32 resource diagnostics** change to the logical
call ceiling. These exact ordinary/default sources now complete **32 calls**
instead of 13/15, with call 33 refused. All parsing and nested-IIFE observations
remain unchanged; the original upstream 32-nested-IIFE source still stops in parsing.

Seven new groups cover strict/sloppy call boundaries, every work cutoff in eight
activation fixtures, storage refusal, bound/preentered ownership, TDZ/closures,
finally identity and native recursion. A thread requesting a **128 KiB native
stack** completes directly constructed 32-call ordinary/default fixtures in both
modes and refuses call 33. Equivalent source parsing is checked separately.
The prior 96-unary and 95/96-block fixtures now complete; 97 blocks stops through
the independent declaration-traversal limit. Exhausted growth preserves queued
frames and the caller's count. Refused charges remain in the cumulative ledger.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** retain identical case
identities, policies and every observation. All controls verify; fifteen healthy
baseline gates pass. Five resource-stopped profiles remain nonpassing observations,
with no new baselines. HTML stays at 3,868 matches, two mismatches and six unsupported
modes. The **15,000-case** mutation smoke run has zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and 3,347 accepted/
1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and display-list size
1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `a3c76c013ae8fcab2180a794f7e393cb6574af606b2812ab6673aed7268b9568` |
| `eris-js` | `7dd5587f39f42f26c629ac3f195825b4f171a93c2cade8337c980e6dc50f540c` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `4cb0c8a03832268c1c8ca88f22eb7dc91ba38ee276dd2ef1394f62f5c64aeeef` |

Source-input SHA-256:
`832ffcee3212595a1b67dbb8fa5ef75a15adf444dbf9c87abd05fb3d3aae88aa`.
Local records are `artifacts/*activation-frames*`; the
[public comparison](../tests/conformance/activation-frames.json) preserves provenance
and all profile checks. Initial private-test failures came from an unsupported
String.repeat call in a fixture and an incorrect assumption that refused charges
were absent from the ledger; corrected checks retain exact expected output and
verify actual retained capacity. Parser ownership/accounting and native recursion
remain separate work. Agent sessions remain unavailable, so no independent-agent
review is assigned. No native-window, Vulkan or Chromium performance result is
assigned. Full compatibility, production security and the requested performance
threshold remain unverified.

## Shared statement continuations

Published checkpoint `3564451` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36467482921),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **937 Rust tests** pass with `--include-ignored`: 755 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

[Statement/list continuations](../tests/conformance/statement-frames.md) share
the expression driver, including declarations, branches, loops, switch and
try/catch/finally. Typed body locators avoid copying lists; for-loop iteration
bindings borrow their declaration names. Ordinary exceptions unwind to try
continuations; resource/unsupported host termination bypasses catch/finally.
Reentrant drives retain their own frame boundaries. Existing depth counters and
execution quotas remain; one additional continuation slot accommodates the
program root list. Function activation and defaults still enter through native
recursion, so this stage establishes no deeper-call acceptance.

Five new test groups check work/storage cutoffs, cleanup/code release, cross-unit
callback exceptions, finally overrides, per-iteration closures and live for-in
mutation. A thread requesting a 128 KiB native stack executes directly constructed
80- and 94-block chains. The 95-block fixture retains the existing combined-depth
refusal; the frame cache reaches its 193-slot bound. These isolate execution from
parsing. Existing 144 declaration-name and 240 scalar completion variants pass.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** retain identical case
identities, policies and every observation. All controls verify; fifteen healthy
baseline gates pass. Five resource-stopped profiles remain nonpassing observations,
with no new baselines. All [480 depth observations](../tests/conformance/statement-frames-depth.json)
are unchanged. HTML stays at 3,868 matches, two mismatches and six unsupported
modes. The **15,000-case** mutation smoke run has zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and 3,347 accepted/
1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and display-list size
1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `83f06d277b5c776a082ec42782806ef335b846eaaae6d29d419cb0b74b699639` |
| `eris-js` | `9cbd79075a71145f7f6fb7f7c646a87b64ea0d8c462d6c95fee45f338cdbe706` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `a2fd6339ad68ebd6aa649e4738e4193e00445c7503ecb59673721eeaf73280bc` |

Source-input SHA-256:
`b745b416797170ae95f7d7986ad447d0b7c400e966151895c1f1d56e5ca3a809`.
Local records are `artifacts/*statement-frames*`; the
[public comparison](../tests/conformance/statement-frames.json) preserves provenance
and all profile checks. Parser syntax remains recursive and incompletely
accounted; runtime allocation accounting is also incomplete. Agent sessions
remain unavailable, so no independent-agent review is assigned. No native-window,
Vulkan or Chromium performance result is assigned. Full compatibility, production
security and the requested performance threshold remain unverified.

## Expression and reference continuations

Published checkpoint `57e9a0c` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36465368973),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **932 Rust tests** pass with `--include-ignored`: 750 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

[Expression/reference frames](../tests/conformance/expression-frames.md) retain
code units, environments and pending values in a checked runtime vector. Reentrant
native callbacks preserve their outer frame boundary. Work/storage refusal drops
only the current drive's frames and restores depth counters without fresh quotas.
Identifier references retain code rather than copying names. Array and argument
payloads are precharged; property allocation failure cannot leave the parallel
array arenas out of sync. Statements, function bodies/defaults and native bridges
remain guarded native recursion. No limits were raised.

Six private test groups cover resource cutoffs, growth/reuse, code release,
callback order and identity, global references and allocation refusal. Directly
constructed 80- and 95-unary chains execute on a thread requesting a 128 KiB native
stack; 96 hits the retained guard. Parsing is checked separately. The
[480-case depth record](../tests/conformance/expression-frames-depth.json) preserves
all previous observations: these ordinary-call sources first stop at 14 calls,
default-initializer sources at 16 and nested IIFEs at parser depth eleven. This
stage establishes no deeper-call acceptance.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** retain identical case
identities, policies and every observation. All controls verify; fifteen healthy
baseline gates pass. Five resource-stopped profiles remain nonpassing observations,
with no new baselines. HTML stays at 3,868 matches, two mismatches and six unsupported
modes. The **15,000-case** mutation smoke run has zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and 3,347 accepted/
1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and display-list size
1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `22ce7be21f1c7e761e3122444e68d7d442ed23394db17da636ef67d4444f46bd` |
| `eris-js` | `4c9fbe276d4fd08006b692613513d6e5d3479c969d5ea389439a50e650d80081` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `1670858039f7d22dd3e88c8b2cd7fbb895f75596ca2edc0dd21ebc698fa835ee` |

Source-input SHA-256:
`cbd36365629468ceb6322490c597fc068966802abde992f16488423a1a8dcd23`.
Local records are `artifacts/*expression-frames*`; the
[public comparison](../tests/conformance/expression-frames.json) preserves provenance
and all profile checks. The parser remains recursive and incompletely accounted;
this is not a total memory bound. Agent sessions remain unavailable, so no
independent-agent review is assigned. No native-window, Vulkan or Chromium
performance result is assigned. Full compatibility, production security and the
requested performance threshold remain unverified.

## Flat executable ownership and paged tokens

Published checkpoint `58a0ef7` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36461625132),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **926 Rust tests** pass with `--include-ignored`: 744 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

[Flat executable units](../tests/conformance/flat-code.md) own expression,
statement and function records connected by typed IDs. Closures/defaults and
cross-script callbacks retain their own unit; inline handlers use the same form.
Iterative lowering shares the remaining compile ledger and releases temporary
parser syntax on success. Exact edge reservations and direct leaf emission remove
redundant growth and worklist visits. Paged tokens avoid relocating the complete
prefix. These changes preserve the existing 8,327-declaration Unicode regression,
which the initial lowering candidate resource-stopped. No quota increases.

Six code groups and three token groups cover structure, lifetimes, precharges,
truncation and boundaries. Directly constructed flat code with 32,000 expression,
8,000 statement and 8,000 function records releases its last handle on a thread
requesting a 64 KiB native stack. This is an ownership check, not deeper source
acceptance or execution. Existing 144 declaration-name and 240 scalar completion
variants pass. The final validation includes an exact reservation for the fixed
intrinsic empty unit; earlier validation artifacts remain separate.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** preserve case identities,
policies and all preflight observations. Every control verifies and every prior
pass remains. The escaped Unicode 5.2 identifier source gains both modes, leaving
**509 passed / 154 unsupported / six compile resource stops** in that profile.
Array sort retains four resource stops; its two 2,048-element stability modes now
stop on instructions instead of allocation. Every other observation is identical.
Fifteen healthy baseline gates pass. Five resource-stopped profiles remain
nonpassing observations, with no new baselines. HTML stays at 3,868 matches,
two mismatches and six unsupported modes.

The **15,000-case** deterministic mutation smoke run reports zero caught panics
or invariant failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts,
and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size 1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `7b99a721b25cb0864a6d10a58b28f02c7e40f4b5a052c8e60c1be750dc0b56cf` |
| `eris-js` | `822b017948d135761cc0074dd910b55dba9cb79941c4c30a27eb7d2158f3ba80` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `e27fbacdfb8472823e588c2bc3bbc032a59744b7fcc2f702639d56c9b77332c1` |

Source-input SHA-256:
`abc454be3cea7233cdbd00ba8315fbb650b0020918dbb378aa4a93386e805f77`.
Local records are `artifacts/*flat-code*`; the
[public comparison](../tests/conformance/flat-code.json) retains provenance and
all four changed observations. The complete updated
[identifier](../tests/conformance/test262-identifiers-flat-code.json) and
[sort](../tests/conformance/test262-array-sort-flat-code.json) observations remain
explicitly nonpassing profiles.

Temporary parser syntax and evaluator/callback execution remain recursive.
Parser allocations are not comprehensively accounted, so the compile ledger does
not prove total peak memory. Whole-unit retention can keep otherwise unused code
alive; conservative legacy activation metadata allowances remain. Agent sessions
remain unavailable, so this is local validation without independent-agent review.
No native-window, Vulkan or Chromium performance result is assigned. Full
compatibility, production security and the requested performance threshold remain
unverified.

## Metered declaration-name validation

Published checkpoint `faa7298` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36458164451),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **917 Rust tests** pass with `--include-ignored`: 735 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, one declaration-name matrix, nine completion
and 44 confined-worker tests. None remain ignored. All **151 Python checks**
and **57 exact pixel references** pass.

The [implementation and evidence](../tests/conformance/scope-names.md) charge
borrowed declaration-name collection, buffer growth, stable iterative sorting,
string comparisons and named diagnostic construction before the corresponding
work or allocation. Scope/for-header/parameter/catch validation uses the shared
compile ledger; existing limits and no-lexical-scope skips remain. Earliest source
duplicates, diagnostic kinds and sorted first-conflict selection are preserved.
Five private test groups cover ordering, independent oracles, pointer identity and
resource boundaries. A root-authored **72-source / 144-mode** syntax/diagnostic
matrix passes before and after with identical observations.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** preserve every case and
preflight fingerprint, policy and observation. Every control verifies; fifteen
healthy gates pass. Resource-stopped profiles remain nonpassing observations,
with no baseline re-recording. HTML stays at 3,868 matches, two mismatches and
six unsupported modes.

The **15,000-case** deterministic mutation smoke run reports zero caught panics
or invariant failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts,
and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size 1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `fc708729306aa5c7d5acb9cdf9944751da183c22d6e23f18eb58b1fd6c998037` |
| `eris-js` | `6cd0a1426298b533c262ff1796ec6fec49bdd52a63ad8d860d8f2e8f72da621c` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `de1d825f74d7f73bf632cbfe0d36992226ac5960bd1763e1a0988cb5ecc7fbe0` |

Source-input SHA-256:
`e43f320ee08598bb1419c120b736e447674393f40fab3d42cad156de5d60a6c0`.
Local records are `artifacts/*scope-names*`; the
[public comparison](../tests/conformance/scope-names.json) retains report/provenance
hashes and the complete local matrix. Sorting precedes duplicate selection, so
resource exhaustion can precede syntax reporting on larger inputs; duplicates
occupy temporary records and accounting does not refund released storage.
Other parser operations and runtime maps remain separate accounting work.
Owned syntax and parser/evaluator execution still have recursive paths. Agent
sessions remain unavailable, so this is local validation without independent-agent
review. No native-window, Vulkan or Chromium performance result is assigned.
Full compatibility, production security and the requested performance threshold
remain unverified.

## Bounded borrowed declaration traversal

Published checkpoint `2715048` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36455629280),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **911 Rust tests** pass with `--include-ignored`: 730 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, nine completion and 44 confined-worker tests.
None remain ignored. All **151 Python checks** and **57 exact pixel references**
pass.

The [implementation and evidence](../tests/conformance/scope-walk.md) replace
recursive declaration-name collection and var hoisting with a borrowed preorder
walk. Ninety-six fixed ancestor cursors bound depth independently of list width;
work is charged before advancing, including empty case lists, and errors are
terminal. Switch scope checks no longer recursively clone their bodies. Parsing
records direct lexical declarations and skips unnecessary conflict analysis when
none exist. Owner scope, function boundaries, diagnostic order and declaration
insertion/validation modes are preserved. Existing limits are unchanged.

Four focused groups exercise order/boundaries, 96/97-depth handling, terminal
work failures, empty cases, 16,000-statement width and lexical conflicts. The
nine completion groups also pass. Initial unnecessary analysis scans exhausted
the compile allowance on the preserved 8,327-declaration Unicode 10 identifier
case; eliminating actual redundant scans/set construction restores both modes.
No quota increase or source change was used. Final validation includes the later
empty root-case precharge; preliminary results remain separate local artifacts.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** preserve every case and
preflight fingerprint, policy and observation. Every control verifies; fifteen
healthy gates pass. Resource-stopped profiles remain nonpassing observations,
with no baseline re-recording. HTML stays at 3,868 matches, two mismatches and
six unsupported modes.

The **15,000-case** deterministic mutation smoke run reports zero caught panics
or invariant failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts,
and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size 1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `d1ffd7ec0925c7e65d9bd5564c1c6f56a08ad814973798d3d9267b6b4b7d9b27` |
| `eris-js` | `93e5893a39bbdb36398561bb518be6b3649c0a8d64981fcef342528938c117e2` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `ff770b0b0eaf6ea2ae72deabea8e1cb24ca01a5339e316ebb6b05fd759d39ba2` |

Source-input SHA-256:
`d12aeb709649fe291b6a24ef70fdd555b2c58ffca5ed7cda83864efe929b7fe4`.
Local records are `artifacts/*scope-walk*`; the
[public comparison](../tests/conformance/scope-walk.json) retains report/provenance
hashes. Borrowed name-set comparison/storage accounting needs further auditing;
owned syntax and parser/evaluator execution still have recursive paths. Agent
sessions remain unavailable, so this is local validation without independent-agent
review. No native-window, Vulkan or Chromium performance result is assigned.
Full compatibility, production security and the requested performance threshold
remain unverified.

## Statement completion values and runtime stack correction

Published checkpoint `a56597e` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36453447238),
including all existing conformance gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **907 Rust tests** pass with `--include-ignored`: 726 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline, nine completion and 44 confined-worker tests.
None remain ignored. All **151 Python checks** and **57 exact pixel references**
pass.

The [implementation and evidence](../tests/conformance/statement-completion.md)
distinguish internal empty completions from JavaScript undefined. Lists, labels,
branches, four supported loops, switches and try/catch/finally preserve or replace
values according to their completion rules. Return/throw identity, loop ordering,
lexical environments and uncatchable host termination remain intact. No execution,
allocation or nesting ceiling changes; no dynamic eval implementation is added.

The root-authored direct-API table has **120 sources / 240 strict-sloppy modes**.
A frozen release-library probe at `f4c287c` passes 118; the final probe passes all
240, adding 122 without losses. The public report retains all expected/before/after
values and source/library/executable hashes. Additional Rust checks cover reference
identity, NaN, host stops and nine recursive statement forms. These checks are not
upstream conformance evidence; original eval-based cases remain unsupported.

The initial implementation overflowed the native stack in the existing nested
statement/function regression. Extracting declaration setup before nested execution
and four runtime branch helpers reduced local debug dispatcher size from 15,400
to 7,000 bytes and statement-list size from 7,800 to 1,352 bytes. The original
regression and new recursive forms pass, without increasing stacks or quotas.
The measurements compare initial/final candidates in this increment, are
compiler-specific, and do not prove a portable native-stack bound.

All **20 Test262 profiles / 6,879 modes / 1,680 controls** preserve every case and
preflight fingerprint, policy and observation. Every control verifies; fifteen
healthy gates pass. Existing resource stops remain nonpassing observations, with
no new baseline recording. HTML remains at 3,868 matches, two mismatches and six
unsupported modes. No upstream source or runner-policy changes.

The **15,000-case** deterministic mutation smoke run reports zero caught panics
or invariant failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts,
and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size 1,173 commands; 17 cases stop within paint limits.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `746d1cb755ce7fa74a32ec8fc1be7b597c47de265c09a2b66c07c8bdd7944a5e` |
| `eris-js` | `760a8821afc3bd83928b01be4caf0d729113eb26c843051265197043f9326459` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `d568d90d7756fe839a2b1588809f1797a611c82ac813a941c109ae0f58bcdfb3` |

Source-input SHA-256:
`0fe716f518fcb4c21499cfdd974479494a4d2121f1fee2057e1c6ddf4880aca2`.
Local records are `artifacts/*completion*`; the
[public report](../tests/conformance/statement-completion.json) retains probe and
comparison provenance. Agent sessions remain unavailable; this is local validation,
not independent-agent review. No native-window, Vulkan or Chromium performance
measurement is assigned to this checkpoint. Full compatibility, production security
and the requested performance threshold remain unverified.

## Ordinary labeled control flow and parser stack correction

Published checkpoint `f4c287c` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36450662664),
including the labels gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **898 Rust tests** pass with `--include-ignored`: 726 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 53 pipeline and 44 confined-worker tests. None remain
ignored. All **151 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/labels.md) resolves labeled statements,
break and continue to numeric targets, retaining loop updates, lexical iteration
bindings, finally overrides, exact exceptions and function boundaries. Consecutive
aliases share one AST target. Active names, copies, lookup work and storage are
bounded. Strict reserved names and invalid targets are syntax errors; newline ASI
and statement-only grammar are preserved. Existing resource ceilings are unchanged.
Nine focused groups and page/worker fixtures cover these behaviors.

A new deep-label debug test initially aborted with a native stack overflow.
Counting the two extra label helper frames was insufficient alone. Extracting
nine keyword parsers reduced the local debug statement-dispatch frame from
40,216 bytes to 6,344 bytes in the final build. The regression and excessive
nesting of eight statement forms now return resource errors. No thread stack
or global quota was enlarged. Compiler-specific sizes and local failure/prologue
logs are evidence for this fix, not a portable stack bound or security proof.

The [complete upstream profile](../tests/conformance/test262-labels.md) retains
**68 sources / 125 modes / 80 preflights**. It moves from **30 passed / 95
unsupported** to **100 passed / 25 unsupported**, with all controls. The 70 gains,
four changed passing-negative diagnostics and four shifts to dynamic-eval
unsupported outcomes are all retained. Fifty-two negative modes pass. The 25
remaining unsupported modes cover metadata prerequisites and dynamic eval;
there are no ordinary failures, resource stops, harness errors, timeouts or
adapter errors in this profile. Recording and a subsequent gate reproduce all
candidate observations, and CI now protects them.

A preliminary release measured 95 passes, one failure and 29 unsupported modes.
The unchanged labeled-let/newline case exposed a Statement-versus-Declaration
ambiguity. Correcting it also handles the block/array variants and rejects class
declarations in statement position. Five further passes result. Both preliminary
reports and validation are retained locally; all full checks above were repeated
on the final frozen source and binary.

All nineteen previous profiles preserve **6,754 case and 1,600 preflight
fingerprints** and policies. Eighteen preserve every observation. The
[URI comparison](../tests/conformance/test262-uri-labels.json) adds two passes
and eight instruction stops from formerly unsupported labels: **210 passed /
24 unsupported / 112 resources**, with all 128 controls. All 104 prior resource
stops remain; no healthy URI baseline is recorded. HTML stays at 3,868 matches,
two mismatches and six unsupported modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `8d84259900e9112511c11b92f754801f1e0f8de2b77e3bdf8b61ff85e833637e` |
| `eris-js` | `9e643c885523b75a1e1a991bb3e7c7a9c84601b6adacb1243932f379716c2cc0` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `b643203b66afced4d41636fee61b448c694d75b17c69a8637ef15cda2596d657` |

Source-input SHA-256:
`e34329d60bba0a821277b13b537bf0021285d2d2add3e554160f51e48e684c61`.
Local records are `artifacts/*labels*`. Agent sessions remain unavailable;
this is local validation, not independent-agent review. No native window,
Vulkan or Chromium performance measurement is assigned to this checkpoint.
Full compatibility, production security and the requested performance threshold
remain unverified.

## Ordinary equality conversion

Published checkpoint `52b373f` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36447803488),
including the equality gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **887 Rust tests** pass with `--include-ignored`: 717 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 52 pipeline and 43 confined-worker tests. None remain
ignored. All **145 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/equality.md) adds iterative type
dispatch for == and !=, including ordinary object conversion and Boolean,
Number and String coercion. It fixes false == null while preserving null/undefined
equivalence and ordinary object identity. Strict equality, object/object and
object/nullish pairs do not run conversion hooks. String work and numeric scratch
storage are charged before use; no resource ceiling changes. Seven focused
groups and the page/worker fixtures cover coercion order, exact exceptions,
UTF-16, skipped hooks and resource boundaries. A repeated-getter test was fixed
to declare its redefined property configurable; no runtime relaxation was made.

The [complete equality inventory](../tests/conformance/test262-equality.md)
retains **145 sources / 286 modes / 128 preflights**. It moves from **146 passed /
44 failed / 96 unsupported** to **190 passed / 96 unsupported**, with all 128
controls. The gains are 20 equals and 24 does-not-equals modes; strict-operator
observations are unchanged. Exotic-value metadata and dynamic-eval prerequisites
remain explicit. There are no resource stops, harness errors, timeouts or adapter
errors in this profile. Actual recording and a subsequent gate reproduce every
candidate observation; CI now preserves the gains and complete inventory.

All eighteen previous profiles preserve every observation, all **6,468 case
and 1,472 preflight fingerprints**, and their policies. Existing resource stops
remain nonpassing. HTML stays at 3,868 matches, two mismatches and six unsupported
modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `b871833f233728553ebc26170bbfbfc3f4ed48dba7c8ecac37c300448924e65c` |
| `eris-js` | `5663f74effc73282db269e77aeede8ece73795c324713a4646a2e4c73df0dfb8` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `65c696ecf715332851d48771a4a9bef628d61486b9ebb6ef8d3f19fc6fca122c` |

Source-input SHA-256:
`816e4c1ee47a2096de279c92b7ac0b7b55ddf14283ad0590ee92d1141e70f2f4`.
Local records are `artifacts/*equality*`. Agent sessions remain unavailable;
this is local validation, not independent-agent review. No native window,
Vulkan or Chromium performance measurement is assigned to this checkpoint.
Full compatibility, production security and the requested performance threshold
remain unverified.

## Ordinary relational comparisons

Published checkpoint `9adf86a` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36446347264),
including the comparison gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **878 Rust tests** pass with `--include-ignored`: 710 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 51 pipeline and 42 confined-worker tests. None remain
ignored. All **139 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/relational.md) converts both saved
operands in source order, then selects UTF-16 string ordering or numeric
comparison. This fixes boxed strings and objects that produce strings while
preserving live conversion hooks, receivers, abrupt identity and unordered NaN.
Seven focused groups cover conversion, chains, Unicode boundaries and resource
accounting. The page and confined-worker fixtures retain six green then six blue
samples after a click. No resource ceiling changes.

The [complete comparison inventory](../tests/conformance/test262-relational.md)
retains **184 sources / 364 modes / 128 preflights**. It moves from **292 passed /
eight failed / 64 unsupported** to **300 passed / 64 unsupported**, with all
128 controls. The eight gains are boxed-string comparisons in both modes of each
operator. BigInt/Symbol metadata and dynamic-eval prerequisites remain explicit.
There are no resource stops, harness errors, timeouts or adapter errors in this
profile. Actual recording and a subsequent gate reproduce every candidate
observation; CI now protects these passes and the unchanged inventory.

All seventeen previous profiles preserve every observation, all **6,104 case
and 1,344 preflight fingerprints**, and their policies. Existing resource stops
remain nonpassing. HTML stays at 3,868 matches, two mismatches and six unsupported
modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 618 accepted/4,382 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `45455784bcc92aa20c46e7c09f17dcb52a4270703df2701745d1116cff30ecbc` |
| `eris-js` | `a1697ac1b5fa8c70b6c8dc2990bc473bcd5680e892b6f9cfbdc8fc5788740157` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `2dd59004ebcc6122242e3528c339e5e20ad960249fbc9815bdec363c2a3448b9` |

Source-input SHA-256:
`6838e6c870859dfd799bfe7204775ad81c61e4bd27ef2c8ca7f996ad429f4e88`.
Local records are `artifacts/*relational*`. Agent sessions remain unavailable;
this is local validation, not independent-agent review. No native window,
Vulkan or Chromium performance measurement is assigned to this checkpoint.
Full compatibility, production security and the requested performance threshold
remain unverified.

## URI encoding and decoding

Published checkpoint `bf0fa0d` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36444302786),
including the updated global-values gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **869 Rust tests** pass with `--include-ignored`: 703 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 50 pipeline and 41 confined-worker tests. None remain
ignored. All **133 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/uri.md) adds all four global URI
functions with ordinary string conversion, stable native identity and standard
metadata. A bounded-stack visitor validates UTF-16/UTF-8 percent transformations,
preserves reserved escape case and raw decoded surrogates, and rejects malformed
encoding with canonical URIError. Both traversal passes, result copy work and
simultaneous Vec/Rc storage are precharged; resource ceilings remain unchanged.
Two codec and seven runtime groups cover boundaries, all isolated surrogates,
metadata, hook order, abrupt identity and resource stops. Page and confined-worker
fixtures preserve six green then six blue samples. A preliminary test cleanup
was changed from unsupported Window descriptor redefinition to assignment;
that separate runtime gap remains.

The [complete URI profile](../tests/conformance/test262-uri.md) retains
**173 sources / 346 modes / 128 preflights**. It moves from **zero passed /
260 failed / 34 unsupported / 52 resources** to **208 passed / 34 unsupported /
104 resources**, with all 128 controls. All 52 old instruction stops persist;
52 former failures now reach the instruction limit in full loops. These are
not passes. Labeled statements, host reflection and Reflect prerequisites
remain explicit. There are no harness errors, timeouts or adapter errors.
An actual baseline-recording attempt returns one, reproduces every candidate
observation and writes no healthy URI baseline. No URI CI gate is added.

All sixteen previous profiles retain **5,758 case and 1,216 preflight
fingerprints** and policies. Fifteen preserve every observation. The
[global-values comparison](../tests/conformance/test262-global-values-uri.json)
adds four passes: **42 passed / six failed / 40 unsupported**, with all 64
controls. Actual recording and a subsequent gate protect the gains, preserving
historical evidence. HTML remains at 3,868 matches, two mismatches and six
unsupported modes.

A root-authored Python codec oracle checks **414 input strings / 3,312 assertions /
104 strict/sloppy batches** across ASCII, scalar boundaries and all Unicode
planes. All candidate batches pass; the old adapter fails every guarded batch.
A wrong-answer control produces Test262Error. Its input digest and local reports
are recorded in the implementation scope. This supplements the complete upstream
inventory and is not independent-agent review.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 623 accepted/4,377 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `632df680fc4a9db8604939d8bc020a1889b186b8729946c46ec0c26cb791ce4d` |
| `eris-js` | `1c7c0853356cc5282833d3ab0ed5deede421cbab3022668e1ba3cb5bcb7f7d06` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `476c97cb80d389651b62723e13abd97afe2f460f35a63ad0c4fd4985e306dc6d` |

Source-input SHA-256:
`9b4cf0cd976c9fe947cbbe8addf0bfc281dc5ec5dcd19a8c7026a7835bdbfe50`.
Local records are `artifacts/*uri*`. Agent sessions remain unavailable; this is
local validation, not independent-agent review. No native window, Vulkan or
Chromium performance measurement is assigned to this checkpoint. Full
compatibility, production security and the requested performance threshold
remain unverified.

## Short-circuit logical assignment

Published checkpoint `dbe8990` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36442294655),
including the logical-assignment gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **858 Rust tests** pass with `--include-ignored`: 694 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 49 pipeline and 40 confined-worker tests. None remain
ignored. All **127 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/logical-assignment.md) recognizes &&=,
||= and ??=, reads a single saved reference and skips RHS/write when appropriate.
Taken paths preserve original receivers, keys, exact right values and abrupt
identity. Anonymous ordinary/arrow functions receive inferred names only for
identifier targets; conversion storage is precharged. Eight focused groups
cover truthiness without hooks, readonly and const skip/take paths, name flags,
right association, early rejection, exhausted-allocation short circuits and
uncatchable callback limits. Page and confined-worker fixtures verify six green
then six blue samples. Resource ceilings remain unchanged.

The [complete profile](../tests/conformance/test262-logical-assignment.md)
retains **78 sources / 132 modes / 104 preflights**. It moves from **18 passed /
66 failed / 48 unsupported** to **72 passed / twelve failed / 48 unsupported**,
adding 54 passes without losses. All 104 controls verify, with no resources,
harness errors, timeouts or adapter errors. Eighteen negative cases retain
passes with specific target/binding diagnostics. Twelve failures now reach
class syntax or missing Symbol; they remain explicit failures because their
metadata does not declare those prerequisites. Every diagnostic change is
retained. Actual baseline recording and a subsequent gate reproduce the full
candidate observations; CI protects the complete baseline.

All fifteen previous profiles retain **5,626 case and 1,112 preflight
fingerprints**, policies and every observation. Existing resource outcomes in
numeric parsing, identifiers, functions and sort remain nonpassing; no healthy
baseline is assigned to them. HTML remains at 3,868 matches, two mismatches
and six unsupported modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 620 accepted/4,380 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `112145418bf22b4d9a0e78b9b0cf277677a3edf88538bcc633475266273860bc` |
| `eris-js` | `e9d33d19a55217d159ab6e337e6f4af21a69651a7325b762247505f7c3b5cdf4` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `9e457b906d96c731d00859d9b49979832a7943ad38e73ac22672117198002b6a` |

Source-input SHA-256:
`8c452cdea5acad7f74b0af769ec0686ed0f6eeda2ec67f47464a0230537dfbed`.
Local records are `artifacts/*logical-assignment*`. Agent sessions remain
unavailable; this is local validation, not independent-agent review. No native
window, Vulkan or Chromium performance measurement is assigned to this
checkpoint. Full compatibility, production security and the requested
performance threshold remain unverified.

## Ordinary addition conversion

Published checkpoint `789165b` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36440734155),
including the addition gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **848 Rust tests** pass with `--include-ignored`: 686 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 48 pipeline and 39 confined-worker tests. None remain
ignored. All **121 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/addition.md) converts saved operands
left-to-right using live ordinary hooks before selecting numeric addition or
UTF-16 string concatenation. Boxed values, original receivers, abrupt identity,
left association and compound references retain their effects and order.
Primitive formatting, copying work and simultaneous Vec/Rc storage are charged
before allocation. Seven focused groups include exact resource boundaries,
late result-size rejection after both hooks and uncatchable recursive/looping
hooks. Existing instruction, allocation, string and nesting limits are unchanged.
Page and confined-worker fixtures preserve six green then six blue samples.

The [complete addition profile](../tests/conformance/test262-addition.md) retains
**48 sources / 95 modes / 64 preflights**. It moves from **51 passed / 16 failed /
28 unsupported** to **65 passed / two failed / 28 unsupported**, adding 14 passes
without losses. All 64 controls verify, with no resources, harness errors,
timeouts or adapter errors. Both remaining failures require Date; unsupported
Symbol/BigInt prerequisites and dynamic eval remain explicit. Actual baseline
recording and a subsequent gate reproduce every observation; CI protects the
full baseline without presenting it as all-pass conformance.

All fourteen prior profiles retain **5,531 case and 1,048 preflight fingerprints**.
Every observation in thirteen is identical. The
[compound-assignment comparison](../tests/conformance/test262-compound-assignment-addition.json)
records all ten remaining += failures becoming passes: **606 passed /
180 unsupported**, with 128 controls. Actual recording and gate verification
protect the gains; historical evidence remains linked. Existing resource stops
in numeric parsing, identifiers, functions and sort remain nonpassing and have
no healthy baselines. HTML remains at 3,868 matches, two mismatches and six
unsupported modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 598 accepted/4,402 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so these counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `ba2f27941a6f25065d11c898da7d86bbd2bbcfd8ae868cb2f7da2ac17e56c5cf` |
| `eris-js` | `c9e47a8245eaa6e14c60f1ae0874213bdef2b00a6dacb4648c845155fdb136a3` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `c9a60e9432b13016dbd77a126c319522e65a690f99a8514cf63f27761dec6d48` |

Source-input SHA-256:
`dc2e14d6e60eb413384ed88b7518a3207b5a79f1052f18be6549731a637d25a6`.
Local records are `artifacts/*addition*`. Agent sessions remain unavailable;
this is local validation, not independent-agent review. No native window,
Vulkan or Chromium performance measurement is assigned to this checkpoint.
Full compatibility, production security and the requested performance
threshold remain unverified.

## Compound bitwise assignment

Published checkpoint `09fe914` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36438219734),
including the compound-assignment gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **839 Rust tests** pass with `--include-ignored`: 679 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 47 pipeline and 38 confined-worker tests. None remain
ignored. All **115 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/compound-assignment.md) adds lexer/parser
recognition for <<=, >>=, >>>=, &=, ^= and |= and reuses the existing assignment
reference evaluator. Target/key evaluation occurs once, Get precedes the RHS,
operand conversion precedes Put, and abrupt stages preserve identity and prior
effects. Seven focused groups check reference order, live conversion, strict
writes, const/TDZ/missing bindings, integer boundaries, early rejection, shared
resource stops and actual execution of unchanged decimalToHexString.js.
A preliminary stress test's unsupported String.repeat prerequisite was replaced
with direct recursive conversion; runtime limits were not changed. Page and
real confined-worker fixtures preserve six green then six blue samples through
callbacks exercising all six operators.

The [complete profile](../tests/conformance/test262-compound-assignment.md)
retains **454 sources / 786 modes / 128 preflights**. It moves from **290 passed /
328 failed / 168 unsupported** to **596 passed / ten failed / 180 unsupported**,
adding 306 passes without losses. All 128 controls verify, with no resources,
harness errors, timeouts or adapter errors. Twelve previous failures now reach
explicit unsupported eval/host-definition operations. Twenty-four negative
syntax cases preserve their passing status with more specific invalid-target
or strict-binding diagnostics. All transitions are recorded. The ten remaining
failures concern existing boxed/string += conversion. Actual baseline recording
and a subsequent gate reproduce every observation; CI protects the full baseline.

All thirteen earlier profiles retain **4,745 case and 920 preflight fingerprints**.
Every observation in twelve of them is identical. The
[parsing comparison](../tests/conformance/test262-numeric-parsing-compound-assignment.json)
records four former helper parse errors becoming instruction-limit stops in
complete Unicode loops: **164 passed / 46 unsupported / eight resources**,
with all 80 controls. This is helper-loading progress, not new parsing passes;
no healthy parsing baseline is recorded. HTML remains at 3,868 matches, two
mismatches and six unsupported modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 621 accepted/4,379 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `0949c4474fcd7ecda1f944df6870ee108229c28996430f055a6b063d39f393a0` |
| `eris-js` | `92710e2646cc80ba2d2839837941e5c6fe62242f6cad772396074bb880805d78` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `6a17607e6de61fadd2ca42c6a26805752435cca94e7df50816df7855d216f056` |

Source-input SHA-256:
`100da85dd37e4aee42d21f6b83afa7ff6459a21e87042cd4b9274a4a9e6f6931`.
Local records are `artifacts/*compound-assignment*`. Agent sessions remain
unavailable; this is local validation, not independent-agent review. No native
window, Vulkan or Chromium performance measurement is assigned to this
checkpoint. Full compatibility, production security and the requested
performance threshold remain unverified.

## Numeric parsing conversion and aliases

Published checkpoint `479e6b7` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36436404985),
including the Number alias regression gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **830 Rust tests** pass with `--include-ignored`: 672 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 46 pipeline and 37 confined-worker tests. None remain
ignored. All **109 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/numeric-parsing.md) gives parseInt and
parseFloat ordinary string-hint conversion, with parseInt's radix converted
afterward. Live hooks, receiver identity, argument effects and abrupt completion
are preserved. Number.parseInt and Number.parseFloat share the global intrinsic
objects; standard metadata and independent mutable bindings preserve aliases.
Dispatch avoids scanning ignored values. Shared conversion keys and worst-case
UTF-8 scratch are precharged; all resource ceilings are unchanged.

Seven focused groups cover these semantics, prefix grammar, radix wrapping,
signed zero, rounding and shared resource termination. An initially incorrect
private-test expectation that failed charges were refunded was corrected; the
runtime's cumulative ledger was preserved. Page and actual confined-worker
fixtures retain six green then six blue pixel samples through a callback using
saved aliases after both global and Number-property replacement.

The new [complete parsing profile](../tests/conformance/test262-numeric-parsing.md)
retains **109 sources / 218 modes / 80 preflights**. It moves from **142 passed /
20 failed / 48 unsupported / four harness errors / four resources** to **164
passed / 46 unsupported / four harness errors / four resources**. All 80 controls
verify. Twenty gains resolve failures and two resolve parseInt's own length
reflection. Every prior pass is retained. The unchanged hexadecimal helper uses
unsupported >>>= syntax; full nested radix loops retain instruction-limit stops.
An actual baseline-recording attempt reproduces the candidate and refuses to
create a baseline. This profile remains a complete local observation.

The [Number comparison](../tests/conformance/test262-number-statics-numeric-parsing.json)
adds four alias passes: **248 passed / 92 unsupported**, with all 104 controls.
Actual recording and a subsequent gate preserve identical results; the existing
Number CI gate protects the gains. All twelve prior profiles retain **4,527 case
and 840 preflight fingerprints**. Every result in the other eleven profiles is
identical, including all prior resources. HTML remains at 3,868 matches, two
mismatches and six unsupported modes.

A root-authored supplemental matrix checks **1,050 signed inputs** across radices
2–36 and widths 1–10. Python integer arithmetic supplies expectations below 2^53;
direct calls and coercing aliases pass **4,200 assertions / 132 bounded batches**
in both modes. The frozen before adapter fails at the guard in every batch;
a wrong candidate assertion throws Test262Error. These cases do not replace
upstream loops or remove their resource outcomes. Input SHA-256:
`0b09024529f5d2cf8488e9741faccee6ef103e2a56f15ba10c844a1a89574073`.

The **15,000-case** deterministic smoke run reports zero caught panics or
invariant failures: 5,000 accepted HTML, 630 accepted/4,370 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory; counts are not an acceptance-rate comparison.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `d2dd4c8ac2526202e35bef4dc1672d28fc1568e9f9887e1104fc6c136806984b` |
| `eris-js` | `528693af5794bc16e18b956ffe781cbab91b335615c82ea773eca6fe2b13c126` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `dfdfde7d066e0c411f2523aa3dc16d2adb5a279e9cd36c00b434b05aad3b4aab` |

Source-input SHA-256:
`4e98b1e45cd79f3b964d213cfc6c2bbfd012977d7243e9a1e9fe69bfd144a58c`.
Local records are `artifacts/*numeric-parsing*`; matrix source is retained in
session scratch storage. Agent sessions remain unavailable, so this is local
validation, not independent-agent review. No native-window, Vulkan or Chromium
performance measurement is assigned to this checkpoint. Full compatibility,
production security and the requested performance threshold remain unverified.

## Ordinary numeric conversion

Published checkpoint `cf28fc4` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36434500199),
including the new conversion regression gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **821 Rust tests** pass with `--include-ignored`: 665 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 45 pipeline and 36 confined-worker tests. None remain
ignored. All **103 Python checks** and **57 exact pixel references** pass.

The [implementation](../tests/conformance/numeric-conversion.md) routes Number,
global isFinite and global isNaN through ordinary numeric conversion. Live
valueOf/toString lookup preserves the original receiver, hook mutations,
exceptions and prior effects. Omitted Number arguments remain distinct from
explicit undefined. Native and bound construction box the converted result;
saved functions survive global replacement. Static Number predicates retain
non-coercing behavior.

Eight focused groups check conversion order, primitives, UTF-16 grammar,
boxing/aliases and resource accounting. Private calls ignore prebuilt large
extra values at the heap ceiling; strings returned from getters consume scratch
storage before conversion, and failed conversion unwinds call/stack guards.
Recursive or looping hooks cannot catch resource termination. Array-index
recognition is allocation-free with canonical boundary checks and 30,000
comparisons against the previous decoder's definition. No resource ceiling
was increased. The Page and actual confined-worker fixtures preserve six green
then six blue pixel samples, including saved conversions inside a click callback.

The new [complete global profile](../tests/conformance/test262-numeric-conversion.md)
retains **30 sources / 60 modes / 80 preflights**. It moves from **16 passed /
eight failed / 36 unsupported** to **24 passed / 36 unsupported**, with all
80 assertion controls verified. Initial conversion-guard failures are retained.
The 36 unsupported modes include 32 unchanged prerequisite exclusions and four
runtime global-reflection outcomes. There are no resources, timeouts or adapter
errors. Actual baseline recording and a subsequent gate reproduce the candidate
exactly; CI now runs this complete regression gate.

The existing Number inventory gains ten constructor-conversion passes:
**244 passed / four failed / 92 unsupported**, with all 104 preflights.
Its [full comparison](../tests/conformance/test262-number-statics-numeric-conversion.json)
retains all prior outcomes; the updated baseline protects the gains. Missing
parseInt/parseFloat aliases account for the remaining four failures. All eleven
earlier profiles retain **4,467 case and 760 preflight fingerprints**. Every
observation in the other ten profiles is identical, including the 14 retained
function/sort/identifier resource stops. HTML remains at 3,868 matches, two
mismatches and six unsupported modes.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 611 accepted/4,389 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. A new
conversion seed changes the inventory, so counts are not acceptance-rate comparisons.

Release SHA-256 values:

| Binary | SHA-256 |
| --- | --- |
| `eris-browser` | `6d516838ae17232e01cbc37d2bc59369c23159727467b26124da4c944780d8a3` |
| `eris-js` | `b3b0964931661f63d570d6b3bbb52061a9054fe00e4ec8a1025f624326c95d12` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `23d94649dcdaeae35a8c0b21a9f3bb6d4b6fb69c00e3bc077b93f916a1e50876` |

Source-input SHA-256:
`41577621af344b5f9301064d69abbf7a65dcdf4f46de8a5d1524e9e03734004d`.
Local records are `artifacts/*numeric-conversion*`. Agent sessions were unavailable;
these are local implementation and validation results, not independent-agent
review. No native-window, Vulkan or Chromium performance measurement is assigned
to this checkpoint. Full web compatibility, production security and the requested
performance threshold remain unverified.

## Number constants and non-coercing predicates

Published checkpoint `a2b22a1` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36431356192),
including both numeric regression gates, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **811 Rust tests** pass with `--include-ignored`: 657 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 44 pipeline and 35 confined-worker tests. None remain
ignored. All **97 Python checks** and **57 exact pixel references** pass.

The [Number implementation](../tests/conformance/number-statics.md) adds five
constants and four static predicates, preserving the three existing constants.
MIN_VALUE is the smallest positive binary64 subnormal; integer classification
handles the actual rounded value without an integer cast. Predicates borrow
their first argument and do not coerce objects, inspect ignored arguments or
allocate result storage. New bootstrap metadata is precharged; shared work,
heap and stack limits remain unchanged.

Ten focused script groups check exact bits, descriptors, strict/sloppy writes,
boundaries, noncoercion, aliases, argument effects and accounting. Private tests
call the actual native path at the heap ceiling with prebuilt large string/array
arguments; the same fixed work suffices and failure cleans call/stack guards.
Page and real confined-worker fixtures retain six green then six blue pixel
samples, including native aliases called after method replacement and restoration.

The complete [Number inventory](../tests/conformance/test262-number-statics.md)
retains **170 sources / 340 variants / 104 preflights**. It moves from **158
passed / 90 failed / 92 unsupported** to **234 passed / 14 failed / 92
unsupported**, adding 76 passes without losses. Every preflight verifies and
there are no resources, timeouts or adapter errors. Ten remaining failure modes
exercise Number constructor conversion; four exercise parsing aliases. The
unsupported inventory retains 90 metadata exclusions and two host-reflection
outcomes. Actual baseline recording and a subsequent gate preserve identical
observations. CI checks the new complete regression baseline, including its
nonpassing inventory.

All ten prior profiles retain **4,127 case and 656 preflight fingerprints**.
The [reduction comparison](../tests/conformance/test262-array-reduce-number-statics.json)
adds two passes for the unchanged near-safe-integer source in strict and sloppy
modes: **848 passed / 16 failed / 170 unsupported**, with all 128 preflights.
Its updated baseline protects both gains. Every other earlier profile preserves
all passing cases and reported outcomes, including the retained function, sort
and identifier resource stops. HTML retains 3,868 matches, two mismatches and
six unsupported modes.

A separate local check derives expected classification from binary64 exponent
and significand fields, rather than using floating-point truncation. It maps
**2,300 bit patterns** to numeric literals, including 2,048 deterministic random
patterns and targeted boundaries. NaN payloads map to the same JavaScript NaN.
The adapter passes **18,400 predicate assertions** across both modes in 144
bounded batches; a deliberately wrong control throws Test262Error. The frozen
before adapter fails all 144 batches at method-availability checks. These are
sampled local checks, not exhaustive binary64 or independent-agent review.
Inputs SHA-256:
`d2b60045ddcefe6c3f4f3340767ac72145c1bbfc473b6e9f98ac53a9a389287e`.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 609 accepted/4,391 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
seed changes the inventory; these counts are not an acceptance-rate comparison.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `5a1b85733ffdd20cdd50860278efa8baafe257765d31d9718e2f7358f2fde3ad` |
| `eris-js` | `f6ee32dffda7d56c3197cac56586cb9442134f141af1ed69528baf15d8e23675` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `29182360b91d9e31870ee50a8766143f4c38064852fa25459e1bfab07a64a233` |

Source-input SHA-256:
`f9f8fbdd7b40a1a276b7eb493113639e9bd9478913571e7543e4141b8ed324a5`.
Local records are `artifacts/*number-statics*`; the bit-field oracle script is
retained in session scratch storage. No native-window, GPU or Chromium
performance measurement is assigned to this checkpoint. Full web compatibility,
production security and the requested performance threshold remain unverified.

## Streaming array reductions

Published checkpoint `58c027a` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36420373943),
including the new reduction gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **799 Rust tests** pass with `--include-ignored`: 647 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 43 pipeline and 34 confined-worker tests. None remain
ignored. All **91 Python checks** and **57 exact pixel references** pass.

The [reduction implementation](../tests/conformance/array-reduce.md) adds
reduce/reduceRight with one captured ToLength, live sparse/inherited property
reads, omitted-initial distinction and four callback arguments. It streams over
the full safe-integer logical range with a fixed stack key formatter. Separate
presence and value walks precharge work and temporary storage at each prototype
edge; callbacks share the unchanged work, allocation and stack limits. Fourteen
new script groups include conversion order, boxed strings, actual-callee this,
mutation, exceptions, reentrancy and accounting boundaries.

Direct Page and real confined-worker fixtures preserve six green samples and
six blue samples after a retained callback. They check callback direction,
captured length, live values, abrupt effects and object accumulator identity.
Worker pixels equal the direct output.

The complete [paired upstream inventory](../tests/conformance/test262-array-reduce.md)
retains **520 sources / 1,034 variants / 128 preflights**. Results move from
**84 passed / 780 failed / 170 unsupported** to **846 passed / 18 failed /
170 unsupported**: 762 gains and no lost passes. All 128 preflights verify;
there are no resource stops, timeouts or adapter errors. The initial 84 raw
passes are retained with their missing-method exception caveat, rather than
counted as gains. Remaining failures expose Date, Math/JSON receiver tags and
Number.MAX_SAFE_INTEGER prerequisites. The full reports preserve all unchanged
identities and every nonpassing outcome.

Baseline recording and a subsequent CLI gate both succeed with identical
outcomes, zero regressions and zero additional passes. CI now checks this
separate regression baseline. It retains all 1,034 statuses, including every
failure and unsupported case; a plain conformance run still fails.

Independent frozen-release review matches **370 unchanged outcomes**: 312
normal completions, 20 explicit unsupported controls, 16 intended missing-global
ReferenceErrors, two deliberately failed assertion controls and 20 uncatchable
resources. Three bounded private groups pass, covering failure after getter
effects, exact key/callback allocation boundaries, prototype cycles and
per-edge scratch accounting, shared work and recursion. Static delta review
found no concrete scoped defect.

All nine prior JavaScript profiles preserve their **3,093 case identities and
528 preflight identities**, with no prior passing case lost. The
[full sort comparison](../tests/conformance/test262-array-sort-reduce.json)
gains four modes: the unchanged 5- and 11-element stability sources now pass
in both modes. Sort totals are **57 passed / 46 unsupported / four resources**.
The 513-element source now reaches the runtime instruction limit instead of a
missing-method failure; the two 2,048-element allocation stops are unchanged.
Functions remain 509 passed / 620 unsupported / two parser resources, and
identifiers remain 507 passed / 154 unsupported / eight compiler resources,
with unchanged diagnostics. The six existing healthy JavaScript gates and HTML
gate preserve all results; HTML retains 3,868 matches, two mismatches and six
unsupported modes. No sort, function or identifier baseline is invented.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 615 accepted/4,385 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The
added reduction seed changes the inventory, so these counts are not an
acceptance-rate comparison.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `b7bac529a1fb2739c806d955ad186aa2894a3cc40b6c6873be334bbab745dceb` |
| `eris-js` | `2b0e59686ff8fb8db409c8a54b8f92df592f00668fcd9ff00da2de0b3585705a` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `01f92eac3d21d87bdfd9e2bed7b892980d040e3266e8b11d7108a0aa8d61f4f1` |

Source-input SHA-256:
`be187dd3a00025c8461dc08013ca49696231b350d5b4490ea8166c15de83a79f`.
Local logs and reports use `artifacts/*-reduce-final*`; independent review
records remain in session scratch storage. No native-window run, GPU execution
or Chromium performance comparison is assigned to this checkpoint. The Vulkan
docket incorporates a reviewed upload/ownership contract; its browser backend
remains unimplemented. These results do not establish full web compatibility
or production security.

## Unicode identifiers and bounded compilation

Published checkpoint `9d5add8` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36418501821),
including Rust 1.88, the offline Unicode check and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **783 Rust tests** pass with `--include-ignored`: 633 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 42 pipeline and 33 confined-worker tests. None remain
ignored. All **85 Python checks**, offline table verification and **57 exact
pixel references** pass.

The [identifier implementation](../tests/conformance/identifiers.md) decodes
valid Unicode escapes, distinguishes raw grammar terminals from decoded names,
and uses exact pinned Unicode 18.0.0 ID properties. It preserves combining marks,
supplementary characters and distinct normalization forms while rejecting
invalid start/continuation characters, surrogate escapes and escaped reserved
bindings. Numeric adjacency, RegExp flag scanning and ECMAScript whitespace have
their separate rules. Sixteen script groups cover these paths, compiler limits,
diagnostic offsets, parse atomicity and retained callbacks after source disposal.

The [pinned data and generator](../tests/conformance/unicode-identifiers-data.md)
retain official bytes, license, version evidence and hashes. A deterministic
two-level packed table has 4,352 byte indices and 132 unique 64-byte pages:
**12,800 bytes** of static payload. Membership uses two bounded table reads and
fixed shifts/masks. Independent parsing of source records and generated numeric
literals matches all 1,114,112 code-point positions; the compiled predicate test
checks every scalar. Invalid indices and changed membership bits are rejected
by the independent corruption controls.

Initial scanning and all suffix rescans share the existing work/allocation
ledger. No source, token, nesting, work or heap ceiling increased. Actual token
storage shrank from **120 to 48 bytes** on the tested target by sharing rare
provisional diagnostics. Their allocation is precharged and offset adjustment
requires unique ownership. The parser borrows source during compilation and
retains owned syntax/string data, removing a real whole-source allocation/copy.
Raw first-character membership is reused instead of searched twice.

Direct Page and real confined-worker fixtures preserve six green samples and
six blue samples after an event callback changes retained Unicode bindings.
Worker pixels equal direct output. Separate Page checks reject invalid scripts
before any effects and allow later valid scripts to execute.

The complete [identifier/whitespace inventory](../tests/conformance/test262-identifiers.md)
retains **335 sources / 669 variants / 88 preflights**. It moves from **377
passed / 138 failed / 154 unsupported** to **507 passed / 154 unsupported /
eight resources**: 130 new passes, no lost passes and all 88 preflights verified.
The remaining resources are both modes of four large escaped-Unicode sources.
The runner refuses a healthy baseline; no passing conformance gate was added.
Syntax-negative preflights also require a separately executed positive lexer
control in the same mode, preserving raw results even when that prerequisite
fails.

The [preliminary report](../tests/conformance/test262-identifiers-preliminary.json)
is retained: it had 483 passes and 32 resources, including 16 prior passes that
regressed to compile limits. All 16 are restored by the real work/storage
reductions above, with the same corpus and assertion contract. One private
20,000-character identifier sample now fits the unchanged limits; its exact
input remains a positive control, accompanied by a larger 50,001-character
resource control. No upstream or independent-matrix expectation changed.

Independent frozen-release review matches **435 unchanged outcomes**: 175
normal completions, 229 intended parse SyntaxErrors, 25 unsupported controls
and six resources. Seven private groups pass under 512 MiB address-space,
three-second CPU and eight-second wall limits, including the real exhaustive
scalar test and largest raw Unicode file in both modes. Four resource diagnostics
change as different existing limits become the first exhausted resource; all
remain parse-phase resource outcomes. Static delta review found no concrete
scoped defect. Original and optimized sources, binaries and review records are
retained separately in session scratch storage.

All prior passing conformance cases remain passing. The
[function inventory](../tests/conformance/test262-functions-identifiers.json)
adds six passes, reaching **509 passed / 620 unsupported / two parser resources**
with 48 verified preflights. The
[sort comparison](../tests/conformance/test262-array-sort-identifiers.json)
retains **53 passed / six failed / 46 unsupported / two resources**, with all
80 preflights. Its two large stability cases now stop at runtime allocation
rather than instruction limits; exact diagnostics are retained. HTML retains
3,868 matching trees, two mismatches and six unsupported modes. String/JSON,
RegExp, templates, rest, prototype membership and global-value gates retain
their prior results and policies. All eight earlier profiles preserve their
2,424 case and 440 preflight identities.

The **15,000-case** mutation smoke run reports zero caught panics or invariant
failures: 5,000 accepted HTML, 627 accepted/4,373 rejected scripts and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
identifier seed changes the inventory; these counts are not an acceptance-rate
comparison.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `8b4a850f591997e3e4a716d821b89e1980e0c87856fe673b4edd1aa7b684c943` |
| `eris-js` | `b7f77cbbc11f14297b7b34716668a10c0522be62562a33a07756dcc89f17d12f` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `d909fc7cd0b21c52b6d3afcbdb4759a563381b66f30667bb32b27cf1be4a8eef` |

Source-input digest:
`aa1d611fc199bdff6eab451307c2166ca0fe71ab3b8c39dd1bf0182ca5431cb7`.
Session logs use `identifiers-final` under `artifacts/`. Classes/modules,
generators/async execution, labels, eval, full goal validation and Unicode
RegExp capture names remain incomplete. No Chromium performance result or new
native-window measurement is assigned to this increment. Full compatibility,
audited security and the requested performance threshold remain unfulfilled;
Vulkan browser integration remains on the development docket.

## Stable array sorting

The runtime checkpoint `eee6586` exposed a race in the existing Python process
cleanup test: Linux procfs returned ESRCH while a terminated child disappeared
during a read. Test-only follow-up `d678745` accepts that specific disappearance
alongside ENOENT, while still failing for live descendants and unrelated errors.
All 68 Python checks and 20 repetitions of the process-group cleanup check pass.
The follow-up passed [all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36415370021),
including Rust 1.88 and the Vulkan probe. No browser runtime changed in that fix.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **762 Rust tests** pass with `--include-ignored`: 615 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 40 pipeline and 32 confined-worker tests. None remain
ignored. All **68 Python checks** and **57 exact pixel references** pass.

The [custom sort implementation](../tests/conformance/array-sort.md) collects
live indexed values, performs stable iterative comparison, then applies strict
ordered writes and tail deletions. Thirteen new script groups cover generic
receivers, inherited indices, holes versus undefined, UTF-16 default order,
comparator conversion/receivers, abrupt completion, reentrant mutation and
resource accounting. Collection and merge buffers, index keys and callback
arguments are charged before allocation. Earlier callback effects and successful
write-back operations survive later exceptions or resource failure.

Direct Page and real confined-worker fixtures produce six green samples and
six blue samples after an event callback sorts the retained records by descending
rank. They check metadata, UTF-16 ordering, stable ties, sparse entries, inherited
ordinary-object values, comparator exceptions and partial strict write failure.
Worker pixels match the direct Page output, with no script diagnostics.

Independent frozen-release review matches **170 unchanged expected outcomes**:
148 normal completions, ten explicitly unsupported controls and twelve
uncatchable resource stops. Both private scratch/prior-effect and work/heap/
recursion groups pass under 512 MiB, three-second CPU and eight-second wall
limits. Before/candidate source, assertion-helper, mode and expectation
fingerprints match, and all recorded source/binary hashes remain frozen.
Static review found no concrete new defect in the collection, comparison,
callback, allocation or copy-back paths. Receiver-mutating comparator probes
are identified as engine invariants where the specification leaves ordering
implementation-defined.

The complete [pinned sort directory](../tests/conformance/test262-array-sort.md)
retains all 54 sources, 107 modes and six unchanged harness files. It moves
from **zero passed / 61 failed / 46 unsupported** to **53 passed / six failed /
46 unsupported / two resource stops**, with all **80 preflights verified**.
All 107 case and 80 corrected preflight fingerprints, manifest and policy match
between frozen adapters. The 46 unsupported observations retain their exact
diagnostics. The six failures now reach missing reduce calls in the 5-, 11-
and 513-element stability files. Both modes of the unchanged 2,048-element
file reach the instruction limit; those failed-to-resource transitions are
explicit in the [full report](../tests/conformance/test262-array-sort-latest.json).
They are not passing tests. A requested healthy baseline was refused because
resource outcomes remain, and no sort baseline or passing CI gate was added.

One new metadata preflight initially misused the unchanged property helper:
it checked a configurable property and then read it after the helper deleted it.
Only the new paired setup gained the helper's documented restore option.
Both frozen adapters were rerun with the same corrected contract; all earlier
profiles stayed unchanged. The
[correction record](../tests/conformance/test262-array-sort-preflight-correction.json)
and both preliminary full reports retain the four changed preflight fingerprints
and original setup failures. Full Python and prior-profile checks were rerun
after this tooling correction; no engine rebuild or changed expectation was
needed for the independent semantic matrix.

The complete functions inventory improves to **503 passed / 620 unsupported /
six failed / two resource stops**. Both modes of the unchanged closure case
`statements/function/S13.2.1_A5_T1.js` newly pass, with no lost passes and all
48 preflights verified. The
[full comparison](../tests/conformance/test262-functions-sort.json) preserves
all 1,131 identities and the policy. Six identifier-escape failures and both
original nested-function parser stops remain; there is still no healthy
functions baseline.

Earlier regression gates retain their outcomes: HTML **3,868 matched /
two mismatched / six unsupported**, String/JSON **536 passed / 116 unsupported**,
RegExp **250 / 40**, templates **82 / 32**, rest parameters **16 / six**,
prototype membership **ten / ten**, and global values **38 passed / ten failed /
40 unsupported**. All earlier inventories, policies, assertions and baselines
remain unchanged.

The **15,000-case** mutation smoke run has zero caught panics or invariant
failures: 5,000 accepted HTML, 627 accepted/4,373 rejected scripts, and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
sort seed changes the inventory, so acceptance counts are not a comparison
against the previous run.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `580e75688c07d916a3caf326731ed788becad6ef6b442fc3cffaa87290e82fcc` |
| `eris-js` | `c039eb6be9360342f9cec2fd8da08cd0efc4245a04370bca0c114e1ff812825c` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `de77d3948aa0486c326d92aaab251c32dd21571e209b18c82543b02c28ea0ace` |

The final source-input digest is
`dce62370c4dbfa806975d8c207bc38ad955997f89d653357848bc2e1b36a148c`.
Session logs use `sort-final` under `artifacts/`; independent review records
remain session scratch files. General Array exotic/host semantics, reduce,
Proxy, typed arrays and larger workloads remain incomplete. No new native-window
or Chromium performance measurement is assigned to this increment. Full web
compatibility and independently audited security remain unverified.

## Global value properties

Published checkpoint `cbe6efa` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36412306983),
including the new global-value regression gate, Rust 1.88 and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **747 Rust tests** pass with `--include-ignored`: 602 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 39 pipeline and 31 confined-worker tests. None remain
ignored. All **63 Python checks** and **57 exact pixel references** pass.

The [global-value implementation](../tests/conformance/global-values.md) gives
globalThis, undefined, NaN and Infinity their actual initial descriptor flags
and shares the existing Window.self property machinery through an exact
five-name selector. Eleven new script groups cover immutable writes/deletes,
SameValue descriptor compatibility, reentrant accessors, inherited and captured
references, lexical separation, private Window/event identity and allocation/work
limits. Tracked global functions are checked before declaration insertion;
reverse-order checks and the last declaration of each name avoid partial
bindings and unnecessary function allocations.

Direct Page and real confined-worker fixtures produce six green samples and
six blue samples after a callback replaces the public property and a separate
lexical binding. Initial descriptors, strict immutable writes, deletion,
restoration, sloppy/strict receiver rules and Window events are checked before
the pixels are accepted. Worker pixels match the direct Page output.

Independent frozen-release review matches **178 expected outcomes**: 138 normal
completions, 18 intrinsic declaration errors, 14 explicitly unsupported controls
and eight uncatchable resource stops. All eight strict/sloppy continuation pages
match exact final text and the single intended declaration-error diagnostic.
They confirm a rejected function declaration leaves no earlier lexical, var or
function binding behind, permits later declarations, and preserves the locked
property and private Window identity. The review uses unchanged expectations,
upstream assertion helpers and before/candidate source and binary fingerprints.
Four compiled private resource/declaration groups also pass under 512 MiB,
three-second CPU and eight-second wall limits. Static review found no concrete
new defect in the changed descriptor, declaration, callback or allocation paths.

The complete new [global-value profile](../tests/conformance/test262-global-values.md)
retains 49 upstream files and all 88 required modes. It improves from
**32 passed / 16 failed / 40 unsupported** to **38 passed / ten failed /
40 unsupported**, with all **64 preflights verified**. The six gains are the
undefined, NaN and Infinity direct descriptor tests in both modes. All earlier
passes are preserved, with identical source/harness/mode, manifest and execution
policy fingerprints. The ten failures still require missing Date/URI globals;
the 40 unsupported cases still require eval or host reflection/enumeration.
The [full report](../tests/conformance/test262-global-values-latest.json) keeps
every observation. The new regression baseline and its CLI gate pass; this
execution-health gate permits documented ordinary failures and does not mean
the entire selection passes.

All earlier regression gates retain their outcomes: HTML **3,868 matched /
two mismatched / six unsupported**, String/JSON **536 passed / 116 unsupported**,
RegExp **250 / 40**, templates **82 / 32**, rest parameters **16 / six**, and
prototype membership **ten / ten**. The complete unchanged functions inventory
retains **501 passed / 620 unsupported / eight failed / two resource stops**
with all 48 preflights verified, no gained/lost passes and identical case/policy
fingerprints. Its two parser stops still prevent a healthy functions baseline.
No previously imported corpus, baseline or assertion helper was modified.

The **15,000-case** mutation smoke run has zero caught panics or invariant
failures: 5,000 accepted HTML, 628 accepted/4,372 rejected scripts, and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
global-property seed changes the inventory, so acceptance counts are not a
comparison against the previous run.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `3f42c2e722c16c97f8d4021fcb0128d56c06aef6dbccd25f788ee2a8aea29e0c` |
| `eris-js` | `3bcf5b560c662c70568c0748c6646f85fe056710231bd339b0317b67ec3c7663` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `d0a80ce7ca3255a95b4bf31103020a26fd851f7d1b8478d2f2ca1449380e4c96` |

The final source-input digest is
`7ab85433d856ca68c585e4a02c3f52a96dcb3ae90f72414b8e8282b1f6415975`.
Session logs use `global-values-final` under `artifacts/`; independent review
records remain session scratch files. General host definitions/reflection,
window/document descriptor correctness, WindowProxy and cross-realm behavior
remain incomplete. No new native-window or performance measurement is assigned
to this increment. Full web compatibility, independently audited security and
Chromium-relative performance remain unverified.

## Replaceable Window.self

Published checkpoint `a9f4530` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36410428928),
including every pinned regression gate, Rust 1.88 compilation and the Vulkan probe.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **734 Rust tests** pass with `--include-ignored`: 591 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 38 pipeline and 30 confined-worker tests. None remain
ignored. All **59 Python checks** and **57 exact pixel references** pass.

The [Window.self correction](../tests/conformance/window-self.md) installs a
real replaceable accessor and keeps bare identifiers, member accesses, saved
descriptors, deletion and lexical shadows coherent. Nine new script groups
cover brands/metadata, strictness, reentrancy, inherited lookup, declaration
rejection before inserting bindings, shared work and allocation failure.
The shared Object.defineProperty key conversion also observes ordinary
array/function overrides and key-before-descriptor evaluation order.

Direct Page and real confined-worker fixtures produce six green samples and
six blue samples after replacement in a callback. They preserve Window event
identity and runtime state across fragment navigation. Fresh Page/worker
instances restore the initial accessor. A separate three-script Page check
confirms a rejected declaration leaves no lexical, var or function bindings
behind for later scripts.

Independent release review matches **113 expected outcomes**: 95 successful
cases, eight intrinsic declaration errors, four explicitly unsupported host
reflection controls and six uncatchable resource stops. Both strict/sloppy
continuation pages confirm absent names after rejection, successful later
redeclaration and an unchanged locked accessor. Private declaration and
allocation/work/cycle tests also pass under 512 MiB, three-second CPU and
eight-second wall limits. Static source review found no concrete new defect
within the changed descriptor, declaration and callback paths. The final
Clippy predicate simplification produces byte-identical release binaries;
the reviewer verified both source snapshots and final binary identities.

The complete unchanged functions profile records **501 passed / 620 unsupported /
eight failed / two resource stops**, with all 48 preflights verified. Only
`statements/function/13.2-30-s.js:strict` newly passes: its `var self = {}` now
replaces the browser binding before the intended bound-function checks run.
The sloppy variant already passed without checking receiver identity; focused
tests now verify the assignment in both modes. The
[full comparison report](../tests/conformance/test262-functions-self.json)
preserves all 1,131 source/harness/mode identities and the exact execution policy,
with no lost passes. The two original parser stops still prevent a healthy
functions baseline. No upstream source or assertion helper was modified.

All existing regression gates retain their outcomes: HTML **3,868 matched /
two mismatched / six unsupported**, String/JSON **536 passed / 116 unsupported**,
RegExp **250 / 40**, templates **82 / 32**, rest parameters **16 / six**, and
prototype membership **ten / ten**. Their corpus bytes, policies and baselines
are unchanged. The **15,000-case** mutation smoke run has zero caught panics
or invariant failures: 5,000 accepted HTML, 634 accepted/4,366 rejected scripts,
and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 191 nodes and
display-list size is 1,173 commands; 17 cases stop within paint limits. The new
accessor-mutation seed changes the inventory, so these acceptance counts are
not a comparison against the previous run.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `76f1325b20285310fcce91f6c55253214f96417a64d6657936b136976b30ad0e` |
| `eris-js` | `073e46ca2273fb55e458432d2b17c4edac6b6f6110f61a83d79b3eaeb2bc6d8b` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `cf5cd6881ba508b5db736da36c918419989af8ad87edc1644f96bf955ee62133` |

The final source-input digest is
`5e4cfb6d251433ae56cc1900fd3380dc19e8b759de5bc2a162a45ac3efddcab2`.
Session logs use `self-final` under `artifacts/`; independent reviewer records
remain session scratch files. Host own-key/reflection APIs, other initial
global-property flags, WindowProxy and cross-realm behavior remain incomplete.
No new native-window or performance measurement is assigned to this increment.
Full web compatibility, independently audited security and Chromium-relative
performance remain unverified.

## Prototype membership

Published checkpoint `9d6aa9e` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36407861216),
including the new prototype-membership gate and Rust 1.88 compilation.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **720 Rust tests** pass with `--include-ignored`: 582 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 35 pipeline and 28 confined-worker tests. None remain
ignored. All **59 Python checks** and **57 exact pixel references** pass.

The [prototype-membership implementation](../tests/conformance/is-prototype-of.md)
preserves receiver-conversion order and walks internal links without invoking
author getters. Six new script groups check metadata/aliases, identity and
mutation, ordering, noncoercion, work/allocation limits and ten unchanged
upstream function variants. Direct Page and real-worker fixtures verify six
green samples and six blue samples after a callback changes a prototype link.

Independent final-release review passes **48 semantic probes** across sloppy
and strict modes, including native/array/function identity and current host
links. The private malformed-graph/resource group also passes under 512 MiB,
three-second CPU and eight-second wall limits: valid-record cycles, exact
96/97-read boundaries, retained-allocation nonmutation, shared work exhaustion
and low-heap boxing. Frozen binary and source hashes remain unchanged. These
checks do not establish unrestricted depth, Proxy or full host conformance.

The complete new [method inventory](../tests/conformance/test262-is-prototype-of.md)
records **ten passed / ten unsupported**, with all **64 preflights verified**.
Compared with the frozen pre-method adapter, six variants newly pass and none
lose a pass; every source/harness/mode and execution-policy fingerprint matches.
The old four receiver-error passes could arise from calling a missing method;
its failing positive method preflight correctly prevented a healthy baseline.
The new baseline and its CLI gate now pass while retaining all ten Proxy,
Reflect.construct and Symbol-dependent unsupported variants.

The complete unchanged functions profile improves to **500 passed / 620
unsupported / nine failed / two resource stops**. Ten previously failing
variants now pass with no lost passes and all 48 existing preflights verified.
The full [comparison report](../tests/conformance/test262-functions-prototypes.json)
retains the same 1,131 identities and policy. The two resource stops still
prevent recording a healthy functions baseline.

All other pinned outcomes are unchanged: HTML **3,868 matched / two mismatched /
six unsupported**, String/JSON **536 passed / 116 unsupported**, RegExp **250 / 40**,
templates **82 / 32**, and rest parameters **16 / six**. Their corpus bytes,
policies and baselines are unchanged. A **15,000-case** mutation smoke run has
zero caught panics or invariant failures: 5,000 accepted HTML, 617 accepted/4,383
rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size
is 191 nodes and display-list size is 1,173 commands; 17 cases stop within paint
limits. One new prototype-mutation seed changes the inventory, so these counts
are not an acceptance-rate comparison.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `975853abcae9e7e6ce9ccb68e040fcd76f09df3846b0946dd521172629597684` |
| `eris-js` | `566886403cd490547bf5475078b60f68fdc0a5d5c5f3007d36ee1179a50f6e0c` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `25a575936a81c4cc2731927d152cb1da4e55a542c8ac7f0f4d3a68fe98f594f2` |

The source-input digest is
`ebcdac762343020bcb6ba88090738526933567fdf496d0468c204706b71f9a17`.
Session logs use `prototype-final` under `artifacts/`; reviewer probes remain
separate session scratch files. No new performance claim is assigned to this
runtime increment. Full web compatibility, independently audited security and
Chromium-relative performance remain unverified.

## Identifier rest parameters

Published checkpoint `5a38ff7` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36406582688),
including the rest-parameter regression gate and Rust 1.88 compilation.

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **712 Rust tests** pass with `--include-ignored`: 576 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 34 pipeline and 27 confined-worker tests. None remain
ignored. All **55 Python checks** and **57 exact pixel references** pass.

The [rest implementation](../tests/conformance/rest-parameters.md) distinguishes
non-simple parameter lists from lists containing default expressions. Six new
script groups cover dense intrinsic arrays, original actual values, arguments
non-aliasing, scope, strictness, arrow parsing, metadata, call entry points and
allocation/work failure before array retention. The direct Page and real worker
fixtures each verify six green samples, then six blue samples after a callback
receives its event through a rest array.

An independent final-release audit passes 18 semantic checks, 28 early-error
checks, three unsupported-destructuring controls, 300 deterministic UTF-8
mutations and ten hostile controls. Seed `0x524553545441494c` and per-child
512 MiB, two-second CPU and three-second wall limits produce no panic, signal
or timeout. Nine hostile cases reach resource limits; 5,000 short defaults
followed by rest parse within bounds. The frozen source/binary hashes remain
unchanged throughout. These are bounded observations, not proof of security.

The complete pinned [rest directory](../tests/conformance/test262-rest-parameters.md)
improves from **two passed / 20 unsupported** to **16 passed / six unsupported**,
with the same 22 source/harness/mode fingerprints and execution policy. All
64 assertion preflights pass, including deliberate mismatches. A new healthy
regression baseline retains all unsupported variants; its CI command passes
locally with no regressions. The six remaining variants require destructuring
or classes, not a modified assertion harness.

Existing upstream outcomes are unchanged: HTML **3,868 matched / two mismatched /
six unsupported**, String/JSON **536 passed / 116 unsupported**, RegExp **250 / 40**,
templates **82 / 32**, and functions **490 passed / 620 unsupported / 19 failed /
two resource stops**. The functions profile still cannot record a healthy
baseline. Its policy and all previous corpora/baselines remain unchanged.

A **15,000-case** mutation smoke run has zero caught panics or invariant failures:
5,000 accepted HTML, 628 accepted/4,372 rejected scripts, and 3,347 accepted/1,653
rejected SVG inputs. Maximum DOM size is 191 nodes and maximum display-list size
is 1,173 commands; 17 cases stop within paint limits. Three new rest seeds change
the inventory, so these counts are not an acceptance-rate comparison.

Release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `e75c159e64bd3f64bd798991567848e4362fd96cdcb39451089f7b0a6931a98b` |
| `eris-js` | `f7303916323638bd7965ffbffeee4afd27e8f630bed6c8357a8a51fc10621b56` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `fabe4f0713477e2be903d02b74b84866dd8b46edfffd19c1f72e4f1e7b6e21fc` |

The source-input digest is
`a61c16761f309ea4e51f42b44ef2bd3471a04d1b5c8843a4d8ec15b4fc0d191c`.
Session logs use the `rest-final` suffix under `artifacts/`. This increment
changes parser/runtime behavior, not native presentation. No new performance
claim is assigned. The unchanged WPT harness now passes the former rest syntax
blocker and stops at destructuring; it still cannot execute. Full web
compatibility, independently audited security and Chromium-relative performance
remain unverified.

## Length-percentage calculations and default parameters

Published checkpoint `ed7dcb8` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36405141684),
including all-target compilation with Rust 1.88.

Recorded September 28, 2026 UTC. The recorded integrated run passes formatting,
strict all-target Clippy, release compilation and **704 Rust tests** with
`--include-ignored`: 570 library, 39 browser/editor, four HTML adapter, six
JavaScript adapter, five stress, four CLI, 17 network, 33 pipeline and 26
real-worker tests. None remain ignored. All **51 Python checks** and **57 exact
pixel references** pass. The five new references use independently specified
SVG rectangles for containing-block bases, Grid tracks/gaps, definite and
indefinite flex bases, range/token rejection and cyclic Grid/Flex gaps.

The [calculation scope](../tests/conformance/calc-lengths.md) records the shared
CSS/CSSOM additive grammar, retained percentage dependency, context-sensitive
resolution and explicit limits. Nine new geometry groups bring layout coverage
to **120 passing tests**. Independent release probes pass **34 calculation
grammar cases** and **24 default-parameter cases**. A separate cross-layer audit
passes **100 checks** across authored declarations, variable substitution,
unrelated inline mutations and CSSOM round trips, plus **39 invalid-value and
priority nonmutation checks**. Its deterministic seed `0x43414c4320260928`
generates 2,000 mutated values and 39 hostile cases: 2,007 evaluations succeed,
32 reach resource limits without changing the original style attribute, and
none produce a caught panic. External limits are 30 seconds wall time,
10 seconds CPU and 512 MiB address space. These malformed-input probes establish
bounded observed behavior, not acceptance conformance.

An independent default-parameter audit adds 12 semantic checks, 14 early-error
controls, three valid-but-unsupported rest controls, 1,200 deterministic UTF-8
mutations and 12 hostile inputs, with no panic, signal or timeout. Each child
has external 512 MiB, two-second CPU and three-second wall limits. Eleven hostile
inputs reach resource limits; 5,000 short defaults parse within the existing
budgets. The audit found that extra ellipses were classified as unsupported
instead of `SyntaxError`. A narrow correction and four regression cases fix
that classification; valid rest remains unsupported. After the correction,
all 704 Rust tests, formatting, strict Clippy, release compilation and all four
Test262 profiles pass their applicable checks with unchanged outcome counts.

An independent layout audit passes **38 bounded probes** for counter
monotonicity, state restoration and finite output. A 24-level cyclic Grid case
terminates at its shared Grid-work limit after 16,145 visits. Nine of ten
ordinary fixed-pixel before/after controls remain exact; the remaining change
corrects a control's paint height to its resolved content box instead of its
old overflowing intrinsic height. Five additional storage/work probes complete
under 512 MiB. Repeated declarations over 99,000 siblings share three nonempty
Grid track arrays totaling **3,096 bytes**. Distinct plain and calculated track
lists both stop retaining new lists at **4,193,304 bytes**, with 2,730 populated
column lists; later values take the documented bounded fallback. The larger
calculation representation is included in retained-byte accounting.

The [unchanged function inventory](../tests/conformance/test262-functions.md)
now reports **490 passed / 620 unsupported / 19 failed / two resource stops**
across 1,131 required variants, with **140 new passes and no lost passes**
against the same sources, harnesses, modes and execution policy. All **48
preflights** pass, including deliberately incorrect assertions. The remaining
resource outcomes prevent recording a healthy baseline; failures and
unsupported variants remain in the denominator. The
[default-parameter implementation record](../tests/conformance/default-parameters.md)
separates supported identifier defaults from remaining rest, destructuring,
async and host gaps. The unchanged WPT JavaScript harness advances past its
first default-parameter blocker but still cannot execute.

Existing pinned upstream outcomes remain HTML **3,868 matched / two mismatched /
six unsupported**, String/JSON Test262 **536 passed / 116 unsupported**, RegExp
**250 / 40**, and templates **82 / 32**. Existing policies, corpus bytes and
baselines are unchanged. A separate **15,000-case** mutation run has zero caught
panics or invariant failures: 5,000 accepted HTML inputs, 637 accepted/4,363
rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size
is 191 nodes, maximum display-list size 1,173 commands, and 17 cases stop within
paint limits. New calculation/default-parameter seeds change this inventory;
these counts are not an acceptance-rate comparison or coverage-guided fuzzing.

Direct Page and confined-worker fixtures pass calculation resize/mutation and
default-parameter interactions. A bounded native software-window check confirms
the default-parameter fixture's green framebuffer state, exits successfully,
and leaves no tracked UI, renderer or broker process alive. This checks the
owned CPU framebuffer, not compositor pixels or a Vulkan browser backend.
All nine existing benchmark views are pixel-identical to frozen `3491721`;
the [warm measurement record](PERFORMANCE.md#calculation-and-default-parameter-checkpoint)
reports both builds without claiming a speed change.

Session records use `calc-params-final`, `calc-params-corrected`, `calc-storage-final` and
`default-parameters-native` names under `artifacts/`; focused peer-review
reproducers remain session scratch artifacts. Native, stress and adversarial
audits preceded the narrow extra-ellipsis correction; their reports retain the
original binary/source hashes. Final release SHA-256 values are:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `371a91b712ea2d112948ae905bf381faeb3ec2908ef363b024c5c536dc61e7eb` |
| `eris-js` | `77003eefd7a91dccb2b418e0d59bc234091edbfb1a7bb6a217de63cd1ece8b69` |
| `eris-dom` | `b775436e90fd2c6c8ffd97f0fabffebde7129b6c206f0efe325e4276b22a1bfb` |
| `eris-stress` | `8b5babf065524debe90ecd7714bb0a89f74dd419b9cc2c308af01654e7223b48` |

The final source-input digest is
`e6d4d857c922db8942abaec7cf230454b3487313f1121dbc6e7babbe0385bcd6`.
Full CSS/JavaScript conformance, independently
audited security and the requested Chromium-relative performance threshold
remain unverified.

## Expanded upstream function inventory

Recorded September 28, 2026 UTC. The new complete four-directory
[function selection](../tests/conformance/test262-functions.md) imports 663
unchanged Test262 files at the existing pinned revision. A frozen pre-change
adapter records **350 passed / 718 unsupported / 61 failed / two resource stops**
across 1,131 required variants. All 32 existing assertion preflights pass, but
the resource outcomes prevent recording a healthy baseline. No cases are
removed or limits raised to change that result. The report identifies every
source, mode, expected negative, observation and source/harness fingerprint.

Metadata handling now accepts common top-level indentation without rewriting
upstream bytes. Inventory, negative-mode and feature-policy checks bring the
Python suite to **50 passing checks**. The original three Test262 profile
policies and baselines remain unchanged. The preceding CSSOM compatibility
correction `cfee40f` passed
[all GitHub CI jobs](https://github.com/Eriskii/ErisBrowser/actions/runs/36402059569),
including actual all-target compilation with Rust 1.88.

## Inline CSSOM and computed property references

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **676 Rust tests** pass with `--include-ignored`: 546 library,
39 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 31 pipeline and 24 real-worker tests. None remain ignored.
The existing **47 Python checks** and all **52 exact pixel references** pass.

Inline declaration bindings now use bounded token-aware storage, ordered author
conversions and a single final DOM write. Eight helper groups and seven script
groups exercise priorities, aliases, shorthands, custom names, reentrancy,
serialization boundaries and resource nonmutation. Three further script groups
check deferred computed-key conversion and cached keys for compound operations.
The [CSSOM scope record](../tests/conformance/cssom-inline.md) documents the
supported operations and remaining storage, grammar and reflection limitations.

Independent final-binary probes pass **42 binding, key-order and malformed-value
cases**, plus **47 preservation/precedence cases**. A separate deterministic
robustness audit uses seed `0x4353534f4d202609`: **2,120 cases** produce 2,060
successful evaluations and 60 expected resource failures, all failures preserving
the original style attribute byte for byte, with no other errors or caught
panics. Another **90 name/value injection combinations** preserve sentinel
declarations across serialization and reparsing. These scratch audits used
external 30-second wall, 10-second CPU and 512 MiB address-space limits. They are
focused safety checks, not upstream WPT conformance or performance measurements.

Pinned upstream outcomes remain HTML **3,868 matched / two mismatched / six
unsupported**, Test262 **536 passed / 116 unsupported**, RegExp **250 / 40**, and
templates **82 / 32**, with passing preflights and no regressions or improvements.
Corpus bytes, runner policies and baselines are unchanged. A separate
**15,000-case** mutation run has zero caught panics or invariant failures:
5,000 accepted HTML, 642 accepted/4,358 rejected scripts, and 3,347 accepted/1,653
rejected SVG inputs. Maximum DOM size is 229 nodes, maximum display-list size
349 commands, and 21 cases stop within paint limits. The added CSSOM seed changes
the inventory; these counts are not an acceptance-rate comparison.

The inline-style fixture passes direct Page and confined-worker tests for six
green initial samples and six blue samples after a click. A bounded native
software-window run exits successfully and reaps the UI, renderer and broker
processes. Inspection of its own framebuffer confirms the initial green samples
and browser chrome; no compositor capture or Vulkan backend is involved.
Nine existing 1180×880 views remain pixel-identical to frozen commit `738f492`.
This comparison measures decoded pixels only, not speed.

Release SHA-256 values for checkpoint `3491721`:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `7497619b9c11606fd6415a387860d9ee395e8cfbf56da5def70e53136f355783` |
| `eris-js` | `15902a07b1ef9c866942c9418264a3fee8e5d045ef64ccef8b60a83794f75edc` |
| `eris-dom` | `ecf9052c43c5a3a968596c31c43a6baca92a4bdd3b309d127ebe23058d64bafc` |
| `eris-stress` | `ec0cd72c861a2e23d1cd3e5a84e41b9923c376714edef788794d245ba3a28c31` |

The source-input digest is
`5fb0934ebb83e25d634853caac2d6ef133aaa1458313a4bcfe182acc063dcb14`,
using the benchmark tool's documented inventory. Session logs and reports use
the `cssom-final` suffix or `cssom-native` / `cssom-pixels` directories under
`artifacts/`. Local checks used Rust 1.95. The new engine CI job
[passed all-target checking with Rust 1.88](https://github.com/Eriskii/ErisBrowser/actions/runs/36401843150/job/108861294379).
That run's newer stable Clippy rejected one constant-size `chunks_exact` call;
a subsequent equivalent `as_chunks` rewrite addresses the lint. The hashes
above identify the locally validated pre-rewrite build, not a later binary.
The previous software-presenter checkpoint passed
[GitHub CI](https://github.com/Eriskii/ErisBrowser/actions/runs/36399652737).
Full web compatibility, independently audited security and the requested
Chromium-relative performance threshold remain unverified.

## Software presentation boundary and native Vulkan investigation

Recorded September 28, 2026 UTC. The software presenter extraction passes all
**39 browser/editor tests**, including four new frame-boundary checks, strict
binary Clippy and formatting. The boundary borrows completed pixels, rejects
invalid dimensions and mismatched source/destination lengths, and preserves
pixel words without conversion. No GPU dependency or browser Vulkan backend
was added. The preceding custom-property checkpoint also completed
[GitHub CI](https://github.com/Eriskii/ErisBrowser/actions/runs/36398730489).

A separately reviewed native Vulkan prototype matched **3,316,800 bytes** in
five acquired-surface readbacks on the NVIDIA adapter, including changed frames
and resize. Full compositor comparisons remain failed, with mismatch counts
172,800 / 252 / 252 / 252; later inset agreement is diagnostic only. Normal
exit and cleanup were verified; forced hang recovery was not exercised.
[Sanitized evidence](evidence/vulkan-native-surface.json) retains source,
binary, log and capture hashes, independently checked against the frozen
session artifacts. The [milestone record](vulkan-rendering.md) explains the
capabilities, provenance and limitations. This is neither browser GPU
integration nor a performance result.

## Computed custom properties and Window descriptors

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **652 Rust tests** pass with `--include-ignored`: 528 library,
35 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 30 pipeline and 23 real-worker tests. None remain ignored.
The existing **47 Python checks** and all **52 exact pixel references** pass.

Custom values now compute before inheritance and substitute through CSS tokens.
The new ten-tile independent rectangle reference covers inherited aliases,
complete RGB fallbacks, case-insensitive functions, token separation, comments,
active cycles and unselected fallbacks. It differs from the preceding release
on **18,400 pixels**, then matches exactly after the correction. Page and real
worker tests also agree after a click changes the parent's variable while a
child shadows the referenced name. All **62 CSS tests** pass.

Review corrected two additional defects: rescanning large cached values after
an earlier substitution failed, and applying an empty ordinary font-family
instead of its unset behavior. Instrumented scratch code verifies that 300
discarded references scan zero cached-value bytes after the correction. Thirteen
independent semantic probes, three empty-value inheritance controls, 10,000
deterministic UTF-8-safe mutations and eight hostile inputs pass without caught
panics, timeouts or nonfinite geometry. The
[custom-property scope](../tests/conformance/custom-properties.md) records
current short-circuit semantics, bounds and remaining grammar/CSSOM limitations.

Window descriptor queries expose authoritative global data bindings with
ordered key conversion, current flags/values, lexical/prototype exclusion and
non-aliasing UTF-16 keys. Five new runtime groups and seven independent probes
cover mutations, deletion/recreation, getter avoidance, descriptor independence
and resource preflight. All **129 script tests** pass. This is bounded host
reflection; other Window operations and full Web IDL semantics remain incomplete.
The [API record](../tests/conformance/css-supports-api.md) gives exact coverage.

Pinned upstream outcomes remain HTML **3,868 matched / two mismatched / six
unsupported**, Test262 **536 passed / 116 unsupported**, RegExp **250 / 40**, and
templates **82 / 32**, with all preflights passing and no regressions. Corpus
bytes, runner policies and baselines are unchanged. A separate 15,000-case
mutation run has zero caught panics or invariant failures: 5,000 accepted HTML,
632 accepted/4,368 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs.
Maximum DOM size is 229 nodes, maximum display-list size 349 commands, and
21 cases stop within paint limits. New variable and descriptor seeds change
the mutation inventory, so these counts are not an acceptance-rate comparison.

The [before/after warm records](PERFORMANCE.md#computed-custom-property-checkpoint)
use verified frozen inputs and binaries, nine views, 1180×880 and 100 iterations.
All nine decoded final frames remain identical. Later medians and p95 values
are higher in this uncontrolled desktop run; they do not isolate the change's
cost or establish any Chromium-relative result. Script execution, native
presentation and the isolated Vulkan prototype are outside the measured loop.

Final release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `34ca6655dd8d0ec1873ba85e9f82716e75eca79b1b6d9223264d657f0069a621` |
| `eris-js` | `21c192148042d482cbed21403e20c6c2e360d31e0058c1c6cf70a2b7b14ad4eb` |
| `eris-dom` | `ecf9052c43c5a3a968596c31c43a6baca92a4bdd3b309d127ebe23058d64bafc` |
| `eris-stress` | `ed1c2a27e07044da41a58f110982d7c17adfe6994b59a7923e1e0300056805fd` |

The source-input digest is
`dde5ce131ea272fb5a737fddf4d048a7d1578371895ec17387cff6e5b689b86c`,
using the benchmark tool's documented inventory. Adapter report hashes match
these release binaries. Detailed session logs use the `vars-descriptors-final`
suffix under `artifacts/`. These checks do not establish full web compatibility,
independently audited security or the requested Chromium performance threshold.

## Isolated Vulkan transfer probe

Recorded September 28, 2026 UTC. The independently built
[`tools/vulkan-probe`](../tools/vulkan-probe/README.md) passes three Rust checks,
12 Python runner checks, formatting and strict Clippy on the installed Rust
1.95 toolchain. These counts are separate from the engine suite below. The
standalone crate pins its own wgpu 30.0.1 resolution; browser dependencies and
rendering behavior are unchanged. The separate [Rust 1.88 CI job for
`dde3ff1`](https://github.com/Eriskii/ErisBrowser/actions/runs/36396836593/job/108845129192)
subsequently passed formatting, strict Clippy and the Rust/Python checks with
the pinned lockfile. That compiler was not installed or executed for this local
host record; CI did not run GPU transfers.

The published source performs **18 exact comparisons across three adapters**:
NVIDIA RTX 4070 SUPER, AMD integrated RADV and CPU llvmpipe. Each adapter receives
three changed frames at 320×240 and three at 319×239. Uploads/readbacks preserve
all **5,509,476 compared RGBA bytes**, including alpha, changed frames and
non-aligned source rows. Enumeration and all device processes exit successfully
within their separate 25-second deadlines, with empty stderr logs. The runner
rejects changed adapter identities, missing/duplicate results, nonzero exits,
timeouts and excessive combined output; fake-process tests verify descendant
cleanup on success, timeout, interruption and read failure.

The [compact host evidence](../tools/vulkan-probe/evidence/host-transfer.json)
binds these results to final source, lockfile, runner, tests and binary hashes,
independently rechecked against the raw local run. The existing Vulkan loader
needed a subprocess-local library directory override; no host setting changed.
The probe forbids unsafe Rust in its source but uses native driver/library
implementations. Its explicit payload sizes exclude staging and driver storage;
process termination cannot guarantee recovery from uninterruptible kernel work.

This checks offscreen transfers only. No surface, shader, browser integration,
native presentation, custom GPU rasterization or performance comparison is
exercised. The [Vulkan rendering milestones](vulkan-rendering.md) remain open.

## JavaScript feature-query API

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and **637 Rust tests** pass with `--include-ignored`: 515 library,
35 browser/editor, four HTML adapter, six JavaScript adapter, five stress,
four CLI, 17 network, 29 pipeline and 22 real-worker tests. None remain ignored.
The existing **47 Python checks** and **51 exact pixel references** also pass.

`CSS.supports` exposes both overloads through the existing conservative
feature-query evaluator. Independent review checked argument evaluation and
ordered string conversion, literal property names, separate value parsing,
function/namespace descriptors and shared work/allocation limits. Five new
runtime groups and two CSS groups cover exceptions, surplus arguments, invalid
syntax, UTF-16 conversion, repeated calls and uncatchable resource failures.
All **124 script tests** pass. This is focused implementation coverage, not an
unchanged upstream WPT run or complete CSSOM/Web IDL conformance; the
[API record](../tests/conformance/css-supports-api.md) lists the remaining gaps.

A new original HTML fixture selects green initial pixels and blue clicked
pixels through feature queries. Direct Page and confined-worker execution
agree exactly, without diagnostics; disabling scripts prevents the state
changes. Property/value injection probes remain false, and undeclared selector
namespaces invalidate the complete condition through negation.

Pinned upstream outcomes are unchanged: HTML **3,868 matched / two mismatched /
six unsupported**; Test262 **536 passed / 116 unsupported**, RegExp **250 / 40**,
and templates **82 / 32**. All assertion preflights pass. Source inventories,
runner policies and baselines are unchanged; no prior pass regresses. The
15,000-case deterministic mutation run reports zero caught panics or invariant
failures, with the same seeds and acceptance/output counts as the preceding
checkpoint. Existing performance measurements retain their historical build
identities; this API checkpoint adds no new performance or Chromium claim.

Final release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `b1834e4dbbbe3e0ef00ef68b80dfe0287b0adae31db46068383845fb3e3dedf4` |
| `eris-js` | `fb9215d17c8cff5e8f0593065983d7185c9d3e1272f1f2c1009597b31d6f8147` |
| `eris-dom` | `ecf9052c43c5a3a968596c31c43a6baca92a4bdd3b309d127ebe23058d64bafc` |
| `eris-stress` | `00bf46bad353886c718ec2b518414db54c75e118bd3e2e65ad5984f8748000f3` |

The source-input digest is
`33bc844220ee8758d7a60176d08914a96a97dc4fdd13049c9f016a66719b6d8a`,
using the benchmark tool's documented input inventory. Adapter report hashes
match these final binaries. Session reports use the `css-supports-final` suffix
under `artifacts/`. Full web compatibility, independently audited security and
the requested performance threshold remain unfulfilled.

## Selector tokens and bounded native task continuation

Recorded September 28, 2026 UTC. Formatting, strict all-target Clippy, release
compilation and the explicit `--include-ignored` run pass. The **628 Rust tests**
comprise 508 library, 35 browser/editor, four HTML adapter, six JavaScript
adapter, five stress-invariant, four CLI, 17 network, 28 pipeline and 21
real-worker tests. None remain ignored. **47 Python checks** and **51 exact
pixel references** pass, including the new independent selector-comment pair.
These are bounded implementation checks, not platform-wide conformance or an
independent security audit.

Matching, specificity, candidate indexing and selector capability queries now
share token-aware grammar. Comments preserve token separation without creating
whitespace or merging names. Direct conditions, raw stylesheet preludes and
conditional imports agree. Review corrected malformed functional pseudo
acceptance, quoted delimiters affecting specificity, pseudo/modifier casing,
large `An+B` arithmetic and empty forgiving-list behavior. Thirteen independent
DOM/CSS matching comparisons, 10,000 UTF-8-safe mutations and four hostile
bounds probes pass. Escaped selectors, namespaces, advanced selector features
and complete declaration tokenization remain unsupported; the
[feature-query record](../tests/conformance/supports.md) gives exact scope and
work/storage bounds.

Disclosure tasks now keep queued records, element trackers and the active task
separate. Reentrant changes retain the correct original old state; finishing
clears the tracker without deleting its queued replacement. Exact identities,
nested synthetic dispatch, named groups, batch-boundary interleavings and
failure cleanup are covered. All **119 script tests** pass.

The native bridge continues pending notifications in interruptible batches,
with at most 64 events and one shared 100,000-step budget per checkpoint. Input,
navigation and shutdown retain priority. ERW8 carries validated
idle/pending/suspended state and a separate task command; rendering invokes no
author callbacks. The parent also checks task state against its trusted script
authorization. Quota failure suspends automatic retries until document
replacement, preserving unstarted notifications. Regressions cover 150 queued
events, persistent allocation exhaustion, callback instruction exhaustion,
partial SVG updates, disabled scripts and cancellation after sending the task
command. The complete HTML event loop, timers and microtasks remain absent.

The native-window probe first captured **64** delivered notifications. A later
capture of that same owned window showed **150**, without clicking or editing
page controls. UI process `1876256` exited with status zero; it, renderer `1876259`
and broker `1876260` were all gone afterward. The later compositor
capture was restricted to the focused test window; it is a visual continuation
check, not a GPU backend result. Session artifacts are
`artifacts/window-idle-tasks.png`, `window-idle-tasks-settled.png` and
`window-idle-tasks-processes.json`.

Pinned upstream results remain **3,868 matched / two mismatched / six
unsupported** HTML trees; Test262 **536 passed / 116 unsupported**, RegExp
**250 / 40**, and templates **82 / 32**. Harness preflights pass and no prior
pass regresses. Corpus bytes, selection policy and baselines are unchanged.
The final 15,000-case deterministic mutation run reports zero caught panics or
invariant failures. A new comment-token seed changes the HTML mutation inputs;
its acceptance/output counts are not a comparison against earlier seeds.

The [warm measurement](benchmark-tasks-selectors.json) covers nine views at
1180×880 over 100 iterations, with verified input/binary hashes. It measures
style/layout/software painting, excludes task execution and the native loop,
and establishes no Chromium performance result. Vulkan remains a documented
[future backend](vulkan-rendering.md).

Final release SHA-256 values:

| Binary | SHA-256 |
|---|---|
| `eris-browser` | `f9cd09b5d56b79e4ac8c157047e03b1cf8ae5edbf747455317e1bc2073114a1f` |
| `eris-js` | `52a14ad7a57803237be0c9b020321528171221024476324f5b20644a5c86a8da` |
| `eris-dom` | `ecf9052c43c5a3a968596c31c43a6baca92a4bdd3b309d127ebe23058d64bafc` |
| `eris-stress` | `165bdaa729f49e142a77c9ba93bfcd8e61365f8ac929354652cf8f9dc0d76f68` |

Detailed session logs and reports use the `tasks-selectors-final` suffix under
`artifacts/`. Source, adapter and benchmark hashes were checked after the final
build. The earlier records below retain their own historical scope and counts.

## Disclosures, feature queries, object literals and worker measurements

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The final
explicit `--include-ignored` run passes **604 Rust tests**: 489 library, 33
browser/editor, four HTML adapter, six JavaScript adapter, five stress-invariant,
four CLI, 17 network, 28 pipeline and 18 real-worker tests. None remain ignored.
Formatting, strict all-target Clippy, release compilation, **47 Python checks**
and **50 exact pixel references** pass. These are bounded implementation checks,
not a platform-wide conformance result or security certification.

Object initializers add computed names with ordered string-hint conversion,
UTF-16 method/accessor names and descriptors, and static prototype setters.
Generic Array.reverse preserves supported ordinary property operations, holes,
inherited indices and abrupt completion. Number radix formatting covers finite
safe integers in bases 2–36; nondecimal fractions and larger magnitudes remain
unsupported. All **115 script tests** pass. Independent review found uncharged
owned parameter/name copies when functions were created and called. Those copies
now reserve work and allocation before retention. An identical 40,938-byte probe
creating 1,000 methods with 1,000 long parameters now stops with an uncatchable
Resource error at about 14 MiB observed process RSS, versus normal completion at
about 79 MiB before; a one-parameter control still completes. RSS includes more
than the interpreter's estimated heap accounting and is not its allocation limit.

All earlier upstream passes and source/mode/harness identities survive. The
original Test262 inventory is now **536 passed/116 unsupported**: both unchanged
JSON ASCII-escaping variants newly execute successfully. Its 32 preflights pass.
The RegExp inventory remains **250/40**, and templates **82/32**, with 44
preflights each. None report failures, harness errors, resource limits or timeouts.
The original baseline advances only those two statuses and its adapter hash;
corpus bytes and runner policy are unchanged. HTML remains **3,868 exact matches,
two mismatches and six unsupported modes**. Final adapter hashes are verified.

Feature queries use strict condition grammar and a conservative positive
property/value/selector inventory. False conditional imports neither fetch nor
register layers; true imports retain media resize behavior and fetch authority.
All **51 CSS** and **19 loader** tests pass. Review found positive sticky queries,
comment-separated selector tokens becoming descendant combinators, and long
undeclared namespace prefixes evading invalidation. Raw prelude preservation,
a bounded conservative commented-selector policy and token-span validation fix
those cases. Twenty independent direct/block/import probes pass, as does a
20,000-case malformed supports/stylesheet smoke. These checks do not establish
complete CSS Syntax or feature-query conformance.

Disclosures add first-summary/default-header behavior, closed-content visibility,
exclusive name groups, open/name reflection and coalesced ToggleEvents. Closed
contents retain DOM, script, stylesheet, resource and form activity. ERW7 carries
validated generated-summary actions; forged commands fail closed. Native focus
and pending edits follow disclosure visibility. Three independent rectangle
references and pipeline/real-worker checks cover these paths. Review also found
stale inline SVG rasters after toggle/input callbacks; refresh now follows each
interaction's callbacks and default actions, including partial mutations before
handled exceptions or quota termination. Two pixel regressions failed before
that correction and pass afterward. Toggle delivery remains a bounded checkpoint
approximation, including documented reentrant tracker differences, with no idle
pump, full task/microtask scheduling, complete keyboard timing or accessibility
implementation.

The deterministic **15,000-case** mutation run has zero caught panics or invariant
failures: 5,000 accepted HTML pipelines, 620 accepted/4,380 rejected scripts, and
3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size is 210 nodes and maximum
display-list size 1,173 commands; **27 cases reach paint limits** within checked
invariants. Added disclosure/feature-query/object seeds change the inventory, so
these totals are not comparisons with earlier acceptance counts.

The new field-guide example is checked at wide/narrow viewports, through grouped
summary/button clicks and toggle handlers, and against identical direct/worker
pixels. Release pixels match the visually inspected debug images. The final
native framebuffer is visually inspected, and the UI plus renderer/broker exit
with no tracked process remaining. The worker benchmark rejects document-load
error pages, preserves script/fragment pixels, and its Python runner validates
measurements and terminates the process group on timeout. These controls retain
the production confinement and snapshot validation path.

[Performance records](PERFORMANCE.md) retain verified source/binary hashes and
nine fixture views. Warm in-process runs use 100 iterations; the separate
confined-worker baseline uses five fresh processes with 100 warm frames each and
retains raw phase samples. The disclosure view records 1.222 ms in-process median
and 1.371 ms confined warm-frame median. These measure different paths in an
uncontrolled local environment, exclude native presentation and establish no
Chromium comparison. Vulkan remains planned; full compatibility, independently
audited security and the requested performance threshold remain unfulfilled.


## Template literals, media conditions and wrapped flex lines

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The explicit `--include-ignored` run passes **550 Rust tests**: 444 library, 31 browser/editor, four HTML adapter, six JavaScript adapter, five stress-invariant, one CLI, 16 network, 27 pipeline and 16 real-worker tests. Formatting, strict all-target Clippy, release compilation, **44 Python harness tests** and **46 exact pixel references** pass. These remain bounded implementation checks, not a full-platform conformance or security certification.

Untagged template literals now retain cooked UTF-16 segments, nested substitutions, line normalization and string-hint coercion in observable evaluation order. Five focused implementation groups cover grammar boundaries, side effects, malformed escapes, large strings, nesting and uncatchable limits. Independent review checked source rescans, allocation preflight and callback ordering; 318 deterministic adversarial parse probes completed without crashes or timeouts. Tagged templates, raw/call-site identity, dynamic eval and other missing language features remain explicit limitations.

The new pinned Test262 template directory retains all **57 unchanged sources and 114 modes**, including 32 parse-negative variants. It records **82 passed/32 unsupported**, with all 44 assertion preflights passing. Against the preceding binary with the same corpus/policy, all 34 prior passes survive and 48 variants newly pass; 20 old syntax failures are now classified as unsupported tagged templates rather than credited as passes. All source/mode/harness fingerprints match. The original String/JSON and RegExp inventories remain **534/118** and **250/40** passed/unsupported with zero regressions. HTML remains **3,868 exact matches, two mismatches and six unsupported modes**. Final adapter hashes are checked against the release binaries.

Media evaluation adds width/height range operators, grouped and/or/not conditions, escaped identifiers, exact equality and strict finite length parsing. Unknown truth remains unknown under negation, and recursive evaluation consumes both local and shared stylesheet work. Independent review found URL tokens mistaken for general-enclosed functions and bad URLs accepted inside unknown syntax; the corrected token validation has negative and positive controls in unit and pixel tests. This is still a bounded media-query subset, without complete CSS Syntax, full feature coverage or matchMedia.

Flex layout forms column lines against definite or maximum heights without incorrectly resolving indefinite percentage bases. Each line retains bounded flexible sizing and min/max freezing. Row and column align-content distribution, line stretch, wrap-reverse and overflow fallback have ten new implementation groups and four independent SVG-rectangle reference pairs. A 35,000-item test reaches output limits while retaining finite geometry and balanced clipping. Baselines, full intrinsic/automatic minimum sizing and writing modes remain incomplete.

The deterministic 15,000-case mutation run completed with zero caught panics or invariant failures: 5,000 accepted HTML pipelines, 651 accepted/4,349 rejected scripts and 3,347 accepted/1,653 rejected SVG samples. Maximum DOM size was 211 nodes and maximum display-list size 402 commands; **26 cases reached paint limits** within the checked invariants. New template/range/flex/URL-token seeds change the mutation inventory, so acceptance totals are not a comparison with earlier runs.

The responsive field-notes example exercises all three paths. Pipeline and real-worker tests click through nested interpolation, resize between wide/medium/narrow layouts and return to the original width while retaining script state. The final native framebuffer is visually inspected; the UI, renderer and broker exit and leave no tracked process behind. This is concrete integration evidence, not a complete security audit or full-platform compatibility claim. The eight-case [warm-render record](PERFORMANCE.md) has verified source/binary hashes; the new responsive fixture records a 1.949 ms median and 2.004 ms p95. Measurements exclude script execution, native startup/IPC and presentation and establish no Chromium comparison. Full compatibility, independently audited security and the requested performance threshold remain unfulfilled.


## Abort signals and deferred opacity allocation

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The final explicit `--include-ignored` run passed **525 Rust tests**: 421 library, 31 browser/editor, four HTML adapter, six JavaScript adapter, five stress-invariant, one CLI, 16 network, 26 pipeline and 15 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, **41 Python harness tests** and all **41 exact pixel references** passed.

AbortController and AbortSignal now provide stable signal identity, branded readonly state, reason identity, idempotent abort, throwIfAborted, onabort, static AbortSignal.abort and signal-backed event-listener removal. Abort removes registered listeners before firing its synchronous trusted event; already-aborted signals suppress registration, while duplicate listeners retain their original signal. Five implementation groups and one review regression join the prior event tests, bringing the script suite to 90 tests. A real-worker integration test verifies that abort removes a canceling click listener and restores subsequent native fragment navigation. Dependent signals, timers, fetch cancellation and the broader asynchronous lifecycle remain unsupported.

Independent review found a work-accounting gap in repeated throwIfAborted calls with a long string reason. The shared thrown-value helper now reserves proportional work and UTF-8 diagnostic allocation before formatting, without reading properties from object reasons. Ordinary throws use the same preflight. A 65,536-unit reason repeatedly thrown and caught now reaches the uncatchable limit; a lone-surrogate allocation test preserves the stored reason. Signal state, observer IDs, removal traversal and recursive abort callbacks continue to share the interpreter's existing budgets.

Opacity groups now remain pending until a clipped nonzero-alpha pixel needs a surface. Pending ancestors materialize in order; empty, offscreen and transparent groups require no intermediate pixels. Scope commands still execute, preserving fixed descendants that escape document clips. Five new graphics groups exercise pending/suppressed states, first visible contributions, fixed escape, peak/cumulative caps, partial allocation failure and cleanup. All 25 graphics and 99 layout tests pass. Independent comparison with commit 2caff22 produced identical pixels for **3,000 mixed drawing streams, painted twice each**, including fractional clips, text, images, transparent sources and canvas reuse. This is bounded differential evidence, not proof of complete compositing correctness.

The CSS-wide keyword helper also avoids temporary identifier/lowercase strings for unescaped ordinary values while retaining escaped-token parsing and the existing work model. All 35 CSS tests pass. All previous upstream fingerprints and passing outcomes remain unchanged: HTML has **3,868 exact matches, two mismatches and six unsupported modes**; the original Test262 selection has **534 passed/118 unsupported** and the separate RegExp selection **250 passed/40 unsupported**. Their 32 and 44 preflights pass, and final adapter hashes were verified.

The deterministic 15,000-case mutation run completed with no caught panics or invariant failures: 5,000 HTML pipelines, 612 accepted/4,388 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size was 197 nodes and maximum display-list size 228 commands. **27 cases reached paint limits** and stopped within the checked invariants. The new AbortSignal seed changes the mutation inventory; these totals are not a comparison with the previous run.

The final native framebuffer was visually inspected, and its UI, renderer and broker exited and were confirmed absent from procfs. Nine decoded headless images match the preceding implementation exactly, including clicked desktop/narrow pages and both offscreen/visible opacity views. The seven-case [warm-render record](PERFORMANCE.md) has verified source/binary hashes and ran after heavy checks and the native window finished. The offscreen event median fell from 11.047 to 1.155 ms; the separately measured visible view rose from 11.763 to 12.385 ms. The benefit is specific to avoiding invisible groups, and the measurements remain uncontrolled and unrelated to Chromium parity. Full compatibility, independently audited security and the Chromium performance requirement remain unfulfilled.

Public [GitHub CI for commit 077feee](https://github.com/Eriskii/ErisBrowser/actions/runs/36387717213) passed every step after the following corrections. Initial public GitHub CI exposed newer Clippy slice-iteration warnings and inherited descriptors reaching worker startup. Fixed-size slice iteration resolves the lint warnings. The descriptor failure was reproduced locally with explicitly inherited pipes; the remote log does not identify their original source. A CI-only Cargo target runner now starts each test executable with inherited descriptors closed and stale jobserver variables removed. All **525 tests also pass through that runner with deliberately inherited pipes**, including the test that opens an unexpected descriptor after startup and verifies worker rejection. Six Python regressions cover descriptor closure, stdio/arguments/cwd, environment filtering, exit/signal status and startup errors. Production descriptor rejection and confinement are unchanged.

## Cascade layers, grouped opacity and DOM event dispatch

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The final explicit `--include-ignored` run passed **513 Rust tests**: 410 library, 31 browser/editor, four HTML adapter, six JavaScript adapter, five stress-invariant, one CLI, 16 network, 26 pipeline and 14 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, 35 Python harness tests and all **41 exact pixel references** passed. These remain checks of implemented subsets, not certification of full standards support or production security.

Author cascade layers now preserve first declaration order, nested/anonymous identities, reversed important precedence, inline/unlayered tiers and bounded `revert-layer` candidates across source segments. Layered imports retain structured identities and media conjunctions, including conditional registration after failed fetches. Three new pixel pairs use independently specified opaque SVG rectangles. Loader review found and fixed malformed backslash/newline and EOF escapes being shortened into valid import keywords; regressions verify rejection, no unintended layer registration or fetch, valid escaped keywords and later-rule recovery. The loader has 15 focused tests and the CSS suite 35, including ten layer groups. [Cascade coverage](../tests/conformance/cascade-layers.md) documents grammar, allocation/work bounds and missing semantics.

Group opacity now paints an entire stacking context into premultiplied RGBA16 intermediates and composites it once into its parent. Six independent opaque-SVG references cover overlap, borders, nested contexts, fixed clips, wrapped inline groups, translucent images and root backgrounds. Transparent loaded images no longer paint fallback backgrounds underneath. ERW6 adds validated opacity commands and a shared typed clip/fixed/opacity stack; mixed closures, nonfinite/out-of-range opacity and excess nesting are rejected. Real-worker coverage exercises layered imports, scrolling and fixed opacity pixels across the process boundary. [Opacity coverage](../tests/reftests/opacity.md) records 64 MiB peak/128 MiB cumulative intermediate limits and the current full-viewport allocation cost.

Event, CustomEvent and EventTarget use private state and synchronous capture/target/bubble dispatch, with listener snapshots/removals, once/passive callbacks, cancellation, inline handlers and distinct Document/Window paths. Native events retain trusted state; author dispatch cannot create it. The 84-test script suite includes eleven event groups, with listener assertions also checked through the runtime console. Independent review exercised reentrancy, getter-side mutation, readonly/private metadata and exception cleanup. It found and fixed uncharged comparisons of cached inline-handler source: a 30 KiB handler read 3,000 times now reaches the script work limit before performing the former repeated scan. No additional concrete trust-state bypass, panic or cleanup error was found in that bounded review; this is not a general security audit. [Event limitations](../tests/conformance/events.md), including asynchronous tasks, shadow retargeting and specialized UI interfaces, remain explicit.

Inline stylesheet collection now validates media/type before copying, uses direct Text children for HTML and SVG styles, and shares limits of 256 styles, 8 MiB text and 200,000 direct-child visits per collection. Allocation is fallible and follows size/work preflight. This removes a nested SVG-style amplification path that repeatedly copied descendant text; tests cover initial loading, re-layout, exact style type matching, nested children and aggregate limits. JavaScript `textContent` retains its descendant semantics. Existing link MIME handling remains separate.

Every prior case/source fingerprint and pass survives the unchanged upstream gates. HTML records **3,868 exact matches, two mismatches and six unsupported modes**. The original Test262 selection remains **534 passed and 118 unsupported** across 652 modes; the separate RegExp selection remains **250 passed and 40 unsupported** across 290 modes. Their 32 and 44 harness preflights pass. Adapter hashes were checked against the final release binaries. No new upstream event or CSS WPT pass count is claimed.

The deterministic mutation run completed **15,000 cases** without caught panics or invariant failures: 5,000 HTML pipelines, 632 accepted/4,368 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size was 197 nodes and maximum display-list size 228 commands. **31 cases reached the configured paint-work/storage limits** and stopped within the tested invariants. Seeds now include layers, grouped opacity and custom event dispatch; changed seeds make acceptance totals incomparable with prior runs. This remains smoke mutation testing rather than coverage-guided fuzzing.

The new `examples/events.html` page was clicked and visually inspected at desktop and narrow widths. Its final release native framebuffer was also inspected; the logged renderer and broker enabled the existing confinement and were absent from procfs after the UI exited successfully. The six-fixture [warm-render benchmark](PERFORMANCE.md) ran after heavy checks and the window finished, with source and executable hashes verified. It includes software opacity compositing but excludes loading, scripts, process startup and IPC. Full web compatibility, independently audited security and the Chromium performance requirement remain unfulfilled.

## HTML recovery, document bases, RegExp, positioning and stylesheet imports

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The final explicit `--include-ignored` run passed **462 Rust tests**: 362 library, 31 browser/editor, four HTML adapter, six JavaScript adapter, five stress-invariant, one CLI, 15 network, 25 pipeline and 13 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, 35 Python harness tests and all **32 exact pixel references** passed. These checks exercise implemented subsets; they do not certify complete standards support or production security.

The unchanged HTML inventory records **3,868 exact matches, two mismatches and six unsupported modes**. Every prior case/source fingerprint and all 3,716 prior matches were retained, with 152 newly matching trees. Recovery now covers additional block, ruby, list, select and frameset cases, leading line feeds, foreign NUL handling, and selected-option cloning into `selectedcontent`. The two remaining mismatches are the two modes of one pinned processing-instruction case whose expected tree has an extra trailing blank line; the harness and fixture remain unchanged. Six synchronous parser-script modes remain unsupported. Exact trees do not establish complete HTML conformance or parse-error accounting.

Documents now retain their authoritative URL and the first connected HTML base element's frozen URL. Tests cover detached/template bases, invalid first bases, moves/removal, mutation budgets, encoded query resolution, and same-document navigation. The native snapshot protocol preserves and validates frozen base state, including expanded non-ASCII URLs and fallback bases frozen before a fragment change. A base URL controls resolution without replacing the resource broker's document-origin authority. A regression prevents fragment syntax from bypassing a changed-origin or file target, and form fallback uses the document URL.

The custom RegExp parser and explicit-stack matcher add bounded non-Unicode UTF-16 patterns, captures/backreferences, lookahead, indices, flags and String integration. The original 326-source, 652-mode Test262 selection now records **534 passed and 118 unsupported**: all 532 prior passes and every case/source fingerprint remain intact. Its 32 preflights pass. A separate complete-directory selection at the same pinned revision contains 145 unchanged sources and 290 modes, recording **250 passed and 40 unsupported** with all 44 preflights passing. Neither selection has failed, harness-error, resource, timeout or adapter outcomes in this measurement. The new selection does not replace or narrow the original inventory. Unicode modes, lookbehind, Symbol/species and other missing semantics remain documented.

Independent RegExp review compared 5,600 generated supported pattern/input capture results with an installed Node oracle and found no differences or execution errors. Node is used only for this check and is not a runtime dependency. Ten targeted resource probes completed without a caught panic or observed quota bypass, including catastrophic backtracking, callback recursion and oversized custom capture results. Review also fixed bare named-reference escapes, observable flag coercion and capture-name enumeration order. These limited differential and adversarial checks are not an audit or proof of general correctness.

Positioning now defers out-of-flow geometry until containing-block dimensions are known; resolves opposing insets, auto margins and relative offsets; and reconstructs stacking contexts and clips in paint/hit order. Fixed commands retain viewport coordinates during native and headless scrolling and cross the validated IPC boundary. Six new independently constructed pixel references cover containing blocks, insets, stacking isolation, clips, fixed coordinates and relative flow. A 40,000-leaf nested fixed/overflow regression preserves typed scope balance and shared command/hit budgets. Remaining inline/static-position, sticky, bidi, transform and group-opacity gaps are explicit.

Stylesheet imports use redirected response URLs, parent encoding fallback, recursion-path cycle checks, media conditions and separate source segments. Loopback tests verify request ordering, no unintended origin escalation, encoding, redirects and cache behavior. A long-base/many-import probe that previously aborted now completes under a 512 MiB test cap after URL construction/cache work received shared limits. Review also fixed retained-segment accounting across loader calls, malformed import recovery, media-wrapper injection through attributes or unmatched source braces, and accidental matching of unknown media types/features or invalid dimensions. These bounds can reject valid but expensive or unusually malformed input; [stylesheet loading](STYLESHEET_LOADING.md) documents the supported grammar and remaining behavior.

The deterministic 15,000-case mutation run completed without caught panics or invariant failures: 5,000 HTML pipelines, 625 accepted/4,375 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size was 229 nodes and maximum display-list size 1,173 commands, with no painter budget stops. Seeds include named RegExp captures, backreferences, indices, replacement and splitting. Changed seeds make acceptance totals incomparable with earlier records; this remains smoke mutation testing rather than coverage-guided fuzzing.

The new `examples/positioning.html` page was exercised through a script click, fixed-position scroll assertions and the real confined worker path. Its final release native framebuffer was visually inspected; the UI, renderer and broker exited and were reaped after the window closed. The five-fixture [warm-render benchmark](PERFORMANCE.md) was run after the native window and heavy checks finished, with source and binary hashes checked against the frozen build. It excludes loading, scripts, process startup and IPC. Full web compatibility, audited security and the Chromium performance requirement remain unfulfilled.

## Templates, strict JavaScript, Grid and byte encodings

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The final explicit `--include-ignored` run passed **393 Rust tests**: 299 library, 30 browser/editor, four HTML adapter, six JavaScript adapter, four stress-invariant, one CLI, 13 network, 24 pipeline and 12 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, 34 Python harness tests and all **26 exact pixel references** passed. These are checks of implemented subsets, not certification of complete standards support or production security.

The unchanged HTML inventory records **3,716 exact matches, 154 mismatches and six unsupported modes**. All 3,272 prior matches were retained, with 444 newly matching trees. All 412 fragment-mode cases and all 254 template.dat mode cases match. Templates now own separate hosted document fragments, with insertion modes, scoped queries, serialization, clone/transfer behavior and host-inclusive graph checks. Documents retain their doctype mode and encoding. The corpus still does not certify parse-error counts, complete quirks rendering, encoding detection or synchronous parser scripts.

The unchanged 326-source, 652-mode Test262 selection records **532 passed and 120 explicitly unsupported**, with no failed, harness, resource, timeout or adapter outcomes. Both sloppy and strict modes execute, with 266 passes each. All 265 previous passes survived the old-policy gate; the comma-expression slice case added one. The strict-policy change was reviewed against every original case/source/harness fingerprint before recording the new baseline. All 32 preflights pass. Four previously failing sources are now explicitly unsupported because they need dynamic eval, regular-expression literals or template interpolation; this does not represent implementation of those features. Strict directives/references/receivers, lexical initialization/loop scopes and mapped/unmapped arguments have separate regressions.

Fetched HTML uses BOM/transport/prescan selection and can reparse cached bytes once for an accepted late declaration. CSS and classic scripts select their own encodings with a document fallback. Tests cover quoted and duplicate MIME parameters, prescan bounds, actual meta processing, template declarations, readonly encoding getters, canonical IPC metadata and differing script charset cache entries. A loopback Shift_JIS page reaches decoded DOM text and CSS pixels with one original POST and one request per subresource. No author script or subresource request runs before the encoding reparse. String-based DOM APIs retain Unicode input unchanged.

Grid adds signed lines/spans, explicit and implicit tracks, row/column dense placement, minmax/fr sizing, spanning contributions, gaps and alignment. Seven new references use independently specified absolute rectangles. Review found and fixed copied track-list amplification, refunded source-scanning work during nested reflow, and case-folding of custom property names. Identical computed lists now share storage; unique track data is capped at 4 MiB plus shared defaults and bounded indexing metadata. Targeted 99,000-element inheritance and repeated-declaration probes completed under a tighter 512 MiB test cap; the actual native process cap remains 1.5 GiB. Existing cascade limits deliberately leave part of the universal-declaration probe unstyled. A nested-grid whitespace probe now consumes at most the shared 500,000-character source budget. Exhaustion can yield partial layout, and these probes are not a security audit.

Independent script review found and fixed a panic when RHS evaluation deletes a captured global binding, plus uncharged subtree/sibling traversal during DOM moves/removals. Regressions cover strict and sloppy writes, coercion side effects, hosted-template traversal, uncatchable exhaustion, and unchanged failed moves/fragment transfers. Native snapshot validation now checks template ownership edges, mode tags and canonical encodings; a real-process test clones template cards and invokes strict callbacks through the confined renderer/broker path.

The deterministic 15,000-case mutation run completed without caught panics or invariant failures: 5,000 HTML pipelines, 607 accepted/4,393 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size was 211 nodes and maximum display-list size 1,175 commands, with no painter budget stops. Seeds now include Grid, hosted templates, strict mode, arguments, cloning and global deletion. DOM invariants include hosted and detached graphs. Changed seeds make acceptance totals incomparable with previous runs; this remains smoke mutation testing rather than coverage-guided fuzzing.

The new `examples/templates.html` page was exercised through headless clicks, pipeline assertions and real worker commands, then visually inspected in the final release browser's native framebuffer. Its renderer and broker exited and were reaped after the window closed. The expanded four-fixture [warm-render benchmark](PERFORMANCE.md) retains source and binary hashes and excludes scripting, loading and native process costs. Full web compatibility, audited security and the Chromium performance requirement remain unfulfilled.

## Fragments, property descriptors, floats and isolated images

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The explicit `--include-ignored` run passed **330 Rust tests**: 245 library, 30 browser/editor, three HTML adapter, six JavaScript adapter, one stress-invariant, one CLI, 11 network, 22 pipeline and 11 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, 34 Python harness tests and all 19 exact pixel references passed. These checks cover implemented subsets and concrete regressions; they do not certify full standards compatibility or production security.

The unchanged HTML inventory now has **3,272 exact matches, 590 mismatches and 14 unsupported modes**. All 2,856 prior matches were preserved. The 416 additions include all 404 supported fragment-mode cases; eight template-fragment and six synchronous-script modes remain unsupported. Fragment initialization uses its real context, tokenizer state, insertion mode and form pointer. The document's quirks mode is not retained, so fragment parsing still uses no-quirks mode.

The unchanged 652-mode Test262 selection now records **265 passed, five failed and 382 unsupported**, with no harness/resource/timeout/adapter errors. All 108 prior passes were retained. The original runner policy gained 155 passes; enabling the implemented for-in-order feature added two more. Every test/source/harness fingerprint was checked before the reviewed baseline update. Thirteen unchanged assertion/property-helper preflights pass. Strict mode, exotic array descriptors and many other language features remain unsupported.

Float support adds margin-box exclusions, same/opposite-side placement, clearance, shrink-to-fit widths and partial formatting-context isolation. Six new independently positioned pixel references bring the total to 19. A 30,000-leaf nested float/clip test exhausts command creation while preserving balanced clips; its output also passes the IPC snapshot validator. Complex margin collapse and painting order remain incomplete. Native focus now follows positive clipped layout geometry, while offscreen controls remain eligible; stale snapshots cannot restore hidden editing targets.

Cross-origin native images now use a fresh confined decoder for each response. Real-process tests cover PNG/SVG pixels, invalid JSON bodies, direct and redirected HTTP failure redaction, one-request decoder exit, process reaping and enabled confinement. Redirect taint is retained even when the final URL returns to the document origin, including cached aliases. Protocol tests reject malformed geometry, truncated payloads and oversized advertised response frames before payload allocation. PNG ancillary-metadata fixtures verify limits before decoder construction; WebP container/frame preflight addresses inner-frame allocations that the dependency's canvas limits do not cover. Remaining codec scratch storage and native process limits are documented in [security](SECURITY.md).

The expanded mutation seeds cover descriptors/accessors, for-in, contextual table fragments and floats. The 15,000-case run completed without caught panics or invariant failures: 5,000 HTML pipelines, 616 accepted/4,384 rejected scripts, and 3,347 accepted/1,653 rejected SVG inputs. Maximum DOM size was 223 nodes, maximum display-list size 261 commands, and there were no painter budget stops. Changed seeds make acceptance counts incomparable with earlier runs; this remains bounded mutation smoke coverage.

The new `examples/flow.html` demo was clicked and visually inspected headlessly, then opened in the native browser and captured from its framebuffer. It combines floats, a descriptor setter and context-sensitive table replacement. Its pipeline test checks all three chapter updates reaching DOM/layout/paint. The native renderer and broker exited and were reaped after the window closed. Full web compatibility, audited security and the Chromium performance requirement remain unfulfilled.

## Brokered resources, foreign namespaces and Test262

Recorded September 28, 2026 UTC on the same x86-64 Linux/Rust setup. The complete explicit `--include-ignored` run passed **281 Rust tests**: 204 library, 26 browser/editor, two HTML adapter, six JavaScript adapter, one stress-invariant, one CLI, 10 network, 21 pipeline and 10 real-worker tests. None failed or remained ignored. Formatting, strict all-target Clippy, release compilation, 31 Python harness tests and all 13 exact pixel comparisons passed.

Native page resources now pass through a separate confined broker. The renderer has no filesystem read/write/execute grants and cannot create sockets. The parent authorizes one document URL/form body, records the broker's final URL, and checks subsequent snapshots against it. Real-process tests cover cross-origin document redirects, final-origin scripts, direct and redirected cross-origin image rejection, authorized POST bodies and 303 rewriting, cancellation during stalled broker I/O, one-shot cancellation propagation, and reaping both children. Kernel probes demonstrate renderer file/TCP/UDP/Unix-socket denial. Filter interpretation checks the added System V/POSIX queue restrictions and rejection of mutating process limits/scheduling. These are bounded tests of specific controls, not a complete sandbox audit.

Review found and fixed an image-kind origin bypass, namespace-map allocation amplification, and unmediated IPC syscall families. Native network images remain restricted to the committed origin until an opaque image-decoding boundary exists. The broker retains outbound IP access and scoped resolver/library/local-file reads; the UI still paints validated untrusted snapshots. Headless/library paths do not install this native confinement. These remaining boundaries are detailed in [security](SECURITY.md).

HTML now retains SVG/MathML namespace identity, adjusted foreign names and attribute namespaces, integration points and foreign CDATA. DOM metadata, selectors, layout controls, SVG painting and IPC were updated with it. The unchanged 3,876-mode HTML inventory yields **2,856 exact matches, 602 mismatches and 418 unsupported cases**: 410 additional matches with no previously matching trees lost. The old baseline gate passed before recording the new baseline. Both conformance runners now reject report/baseline aliases and adapters changed during a measurement.

The pinned [Test262 selection](../tests/conformance/test262.md) contains 326 unchanged upstream test files and all 652 required modes. Its release measurement is **108 passed, 140 failed, 23 harness errors and 381 unsupported**. All nine unchanged upstream assertion preflights pass, with no resource, timeout or adapter errors. Strict execution remains unsupported, and the 23 harness errors reflect unimplemented syntax in `propertyHelper.js`. Canonical intrinsic Error identity prevents forged constructor names from satisfying negative tests; actual subprocess regressions cover spoofed values, renamed genuine errors and wrong phases. Updating that runner policy preserved every case identity and outcome before the reviewed baseline was recorded. These results are a selected inventory, not a complete ECMAScript pass rate.

Interpreter work includes constructors, basic prototype chains, `this`, `instanceof`, function properties/hoisting and `switch`. A hostile JSON callback test exposed native stack exhaustion; calls, expressions, statements/hoisting and JSON traversal now share a weighted nesting guard. Mixed-recursion regressions terminate with uncatchable resource errors and verify restored accounting. Native focus/editing and page mutations also share namespace, attachment, inert, disabled-fieldset and readonly policies; stale snapshots cannot restore revoked editing authority.

The expanded deterministic mutation seeds cover foreign-content boundaries, namespace attributes, constructors, prototypes, switch and Error paths. The 15,000-case run completed without caught panics or invariant failures: 5,000 HTML pipelines, 623 accepted/4,377 rejected scripts and 3,347 accepted/1,653 rejected SVG samples. Maximum DOM size was 223 nodes; maximum display-list size was 136 commands, with no paint-budget stops. The seed inventory changed, so these acceptance counts are not a comparison against the previous run.

The new namespace demo was clicked and visually inspected headlessly; its pipeline test checks three colors reaching pixels, preserved namespaces/case, viewport scaling and released obsolete rasters. Native windows rendered the local demo and public `https://example.com` through distinct renderer/broker processes, captured their own framebuffers, and exited successfully. Both children were confirmed reaped afterward. [Warm fixture timings](PERFORMANCE.md) remain limited to style/layout/software paint and exclude the broker path. Full web compatibility, production security and the Chromium performance requirement remain unfulfilled.

## Isolated native pages, formatting recovery and UTF-16

Recorded September 28, 2026 UTC on x86-64 Linux with Landlock ABI 6 and seccomp enabled. The integrated suite passed **232 Rust tests**: 171 library, 22 browser/editor, one tree adapter, one CLI, 10 network, 20 pipeline and seven real-worker tests. No tests failed or remained ignored in the explicit `--include-ignored` run. Formatting, strict all-target Clippy, release compilation and ten Python harness tests passed. All 13 exact rendering comparisons passed. The deterministic stress run completed 15,000 cases with zero caught panics or invariant failures; one case reached the configured paint-work limit. These remain limited regression and smoke tests.

The native browser now starts a fresh child for each document. Real-kernel tests verify allowed document reads and rejection of reads outside the grant, symlink escapes, writes, deletes, metadata mutations, filesystem-flag ioctls, execution, Unix sockets/socket pairs, thread creation and TCP listeners; allowed nonblocking/bytes-available socket ioctls remain usable. A separate subprocess verifies rejection of an inherited descriptor. Worker tests cover load/render, shared raster transfer, edits/events, stale edit sequences, POST navigation, fragments, cancellation, reaping, bounded malformed framing and HTTP loading with the synchronous resolver. Nonblocking-pipe tests cover both stalled reads and a full input pipe. These tests are evidence for specific controls, not a sandbox escape audit or complete security certification.

Snapshot checks have regressions for disconnected cycles, parent links, depth and storage bounds, invalid geometry/clip stacks/rasters, strict framing, and 1,000 deterministic protocol mutations. Review also caught valid-output mismatches: unavailable images must preserve their fallback, expanded DOM text must use the DOM budget, and generated alt/control/marker/tab text must share the emitted-glyph cap. Those cases now have regressions. The syscall-filter tests independently interpret the emitted filter for native/foreign architecture and x32/argument-width edge cases.

HTML exact-tree comparisons now yield **2,446 matches, 1,012 mismatches and 418 unsupported cases** across the unchanged 3,876-case inventory. Formatting reconstruction and adoption recovery added 194 matches with zero regressions against the prior 2,252-match baseline; that gate passed before the new baseline was recorded. Disabled-mode matches are 1,233 and enabled-mode matches 1,213. Fragment contexts, parser scripting, namespaces and other incomplete semantics remain visible in the inventory.

The script suite includes 37 interpreter tests and two string-representation tests. They cover UTF-16 indexing, slicing, search and property keys, every code unit from 0x0000 through 0xFFFF in a JSON round trip, lone-surrogate callback/indentation behavior, and uncatchable resource limits. DOM/display conversion still replaces unpaired surrogates; this is documented as an incomplete boundary. Test262 is not yet integrated.

The Unicode/formatting example was exercised through a script click and visually inspected as a headless image. A native window rendered the same page through the confined worker and exited successfully. A separate native `https://example.com` run verified actual DNS, TLS and rendering with the syscall filter enabled. The headless benchmark still excludes process startup and IPC; no Chromium performance comparison or full-platform conformance claim is made.

## Parser, JSON and flex compatibility increment

Recorded September 28, 2026 UTC on the same Linux/Rust setup. The integrated run passed 183 Rust tests (131 library, 20 browser/editor, one tree adapter, one CLI, 10 network and 20 pipeline tests), ten Python harness tests, formatting, strict all-target Clippy, release compilation, and 13 exact rendering reference pairs.

The pinned WPT corpus contains 1,959 inputs and 3,876 scripting-mode cases. Exact-tree comparison produced **2,252 matches, 1,206 mismatches and 418 unsupported cases**, with zero regressions against the original matched trees. In directly comparable scripting-disabled mode, matches increased from 380 to 1,136: 756 newly matching trees. Enabled-mode support accounts for the remaining added matches. These are tree comparisons, not complete WPT passes; [the harness documentation](../tests/conformance/README.md) states the omitted checks and records the full inventory.

The harness checks input, expected-tree, context and corpus fingerprints. Tests verify preservation of CR and multiline node data, case/flag handling, corpus integrity, bounded subprocess output/time, and refusal to overwrite a regression baseline or record process errors. Previously matched cases gate CI, while remaining mismatches and unsupported cases continue to be reported.

The updated mutation run again completed 15,000 cases with no caught panics or invariant failures: 5,000 HTML pipelines, 627 accepted/4,373 rejected scripts, and 3,201 accepted/1,799 rejected SVG inputs. Maximum generated DOM size was 251 nodes; one case reached the painter's work limit and stopped within the configured bounds. JSON unit tests also include 500 malformed-input mutations. This remains limited smoke coverage.

The new `examples/standards.html` was rendered after clicking its JSON action, and its exact formatted result is an integration assertion. Both the full headless image and a native-window framebuffer were visually inspected. The native window closed successfully after a five-second smoke run. [Updated fixture timings](PERFORMANCE.md) cover the same limited phases as before.

Full platform compatibility, production security and performance within 30% of Chromium remain unfulfilled requirements.

## Initial implementation

Recorded September 28, 2026 UTC (September 27 local time), on Linux x86-64/NixOS with Rust 1.95.0. These checks cover this implementation's explicit subsets and regressions. They do not establish full web compatibility, production security, or Chromium performance parity.

| Check | Observed result |
|---|---|
| `cargo fmt --all -- --check` | Pass |
| `cargo clippy --locked --offline --all-targets -- -D warnings` | Pass |
| `cargo test --locked --offline -- --include-ignored` | 149 passed, none failed or ignored |
| `cargo build --locked --offline --release` | Both browser and stress binaries built |
| `python3 tools/reftest.py --binary target/release/eris-browser` | 10/10 exact pixel comparisons passed |
| `timeout 180s target/release/eris-stress 5000` | 15,000 generated cases, zero caught panics or invariant failures |
| `python3 -m py_compile tools/benchmark.py tools/reftest.py tools/run.py` | Pass |
| `./run.sh --window-screenshot artifacts/window-final.png --exit-after 5` | Native window opened, framebuffer captured, exit status 0 |
| HTTPS render of `https://example.com` | PNG produced, exit status 0 |
| HTTPS load of `https://expired.badssl.com` | Rejected with expired-certificate error, exit status 1 |
| HTTPS load of `https://self-signed.badssl.com` | Rejected with unknown-issuer error, exit status 1 |

The Rust suite contains 100 library tests, 20 browser/editor tests, one executable integration test, 10 loopback HTTP tests, and 18 pipeline tests. It includes POST body/redirect behavior, MIME and origin restrictions, compressed-body limits, text decoding, inert content, disabled controls, DOM mutation, event cancellation, resource-limit termination, clipping, stale worker results, editing acknowledgements, and fragment navigation. Loopback tests require permission to bind temporary local sockets.

Reference fixtures cover box geometry, cascade/inheritance, flex, grid and fractional tracks, hidden content, preformatted text, table spacing, media/custom properties, and overflow clipping. Both sides use the same rasterizer; shared defects can go undetected. No upstream WPT or Test262 pass rate is claimed.

The deterministic mutation run used seed `0xe2152026` and at most 8 KiB per generated input. Of 5,000 script samples, 622 were accepted and 4,378 rejected; of 5,000 SVG samples, 3,252 were accepted and 1,748 rejected. Rejections are expected for malformed or unsupported input. The largest generated DOM had 272 nodes. This is a small mutation smoke test, not broad adversarial coverage, coverage-guided fuzzing, or an audit.

Native and headless output for the home page, forms, gallery, and a narrow viewport was visually inspected. Native clipboard contents were not read during validation. Windows and macOS were not validated.

The [performance record](PERFORMANCE.md) defines the measured phases and includes three fixture timings. There was no Chromium comparison. The [compatibility inventory](COMPATIBILITY.md) and [security boundary](SECURITY.md) list material unfulfilled requirements, including missing platform APIs and, at that initial checkpoint, the absence of OS process isolation.

### DataView startup prototype lookup removal

The DataView installer now constructs its 21 function bags with their final
Function prototype. It no longer looks up Object.prototype only to overwrite it.
This removes 462 charged work units, leaving 70,796 after initialization; all
heap charges, object identities, numeric limits and script-entry resets remain
unchanged. This is a logical accounting result, not a timing benchmark.

Rust 1.88 passes all 1,378 default tests and Rust 1.98 passes all 1,495 native
feature tests, including ignored tests and the unchanged exhaustive UTF-16 JSON
regression. Native strict Clippy and formatting pass. The new test compares
identical installs with normal, empty, absent and misdirected prototype tables;
existing exact/one-short admission tests remain unchanged. The release DataView
profile retains all 1,122 case rows and 232 control rows exactly (694 passes,
12 failures, 416 exclusions), and its existing gate passes. The
[summary and raw records](evidence/data-view-bootstrap-lookup.json) bind these
checks. The previous initialization checkpoint also passes all nine
[GitHub CI jobs](evidence/runtime-initialization-ci.json).

### Checked Document.append and insertion hierarchy

The [append implementation](document-append.md) adds Document.append and shares
hierarchy validation with script-facing appendChild. Variadic conversion, text
creation, temporary-fragment assembly and final insertion retain their specified
order; later errors preserve earlier observable effects. Text storage refusals
terminate execution before truncation can occur.

Rust 1.88 passes **1,401 default tests**; Rust 1.98 passes **1,518 native-feature
tests**, including ignored tests. The 23 added groups include direct-page and
confined-worker checks of six literal pixels and result text on load and click.
Native strict Clippy and formatting pass. Independent source review found no
concrete defect. The frozen DOM identity corpus gains two passes, reaching
**54/58 verified expectations**, with all 44 controls unchanged. Every Object.is
local case and control row remains unchanged (72/78 expectations, 60 controls).

Installing the ninth method uses 140 additional logical work units; initialization
now leaves 70,656, charges 738,522 bytes and uses 352 objects and 321 native
entries. Numeric quotas, script-entry resets and the exhaustive UTF-16 JSON test
are unchanged. The [summary and raw records](evidence/document-append.json)
bind source, checks and complete local reports. These checks do not establish
complete DOM compatibility or production security. The previous DataView
optimization passed all nine [GitHub CI jobs](evidence/data-view-bootstrap-lookup-ci.json).

### Native Vulkan page zoom

The [native zoom checkpoint](vulkan-native-window.md#zoom-validation) adds bounded
page-command scaling and invalidates queued old-scale frames on zoom changes.
Rust 1.88 passes **1,403 default tests**, Rust 1.98 passes **1,526 native-feature
tests**, native strict Clippy passes on both versions, and all **91 native-host
Python tests** pass. Formatting passes. The six new scene groups include complex
full-frame CPU comparisons and separate admitted-page checks at 75% and 125%.
Two keyboard groups cover loading, unchanged zoom limits and revision exhaustion.

Three actual 1280×880 release-browser windows pass on NVIDIA/BGRA8: acquired
textures at 90% and 110% match **9,011,200 bytes** in total, and a separate 110%
normal run has no reference/readback. Every process exits zero with no owned
descendants remaining. The original failing admission assertion and oversized
debug-binary preflight refusal remain in the [raw record](evidence/vulkan-native-zoom.json).
Numeric limits and the original CPU painter are unchanged. These are correctness
and admission checks, not Chromium or general performance measurements.
The preceding DOM checkpoint passed all nine [CI jobs](evidence/document-append-ci.json).

### DOM own properties and native-member shadows

[DOM own properties](dom-own-properties.md) adds lazy per-object string/symbol
descriptors, accessors and method replacement. The reached native attribute
fallbacks now distinguish node kinds and element types, preventing ordinary
properties on fragments/text nodes from coercing values or installing listeners.
Real DOM prototypes and complete Document reflection remain unfinished.

Rust 1.88 passes **1,424 default tests**, and Rust 1.98 passes **1,547 native-feature
tests**, including ignored confinement tests. The 21 added groups include 19
focused groups and direct-page/confined-worker checks of six literal pixels and
result text on load and click. Native strict Clippy and formatting pass.
Independent source and own-key consumer review found no remaining concrete
defect within this scope. Numeric quotas and entry resets are unchanged.

The frozen DOM corpus retains **54/58 verified expectations** and all 44 controls.
Two method-replacement modes now stop at unsupported full Document enumeration;
their ordinary-success expectations remain unmet. The other 56 complete case
rows and all controls are unchanged. The Object.is local corpus preserves every
complete case/control row (72/78 expectations, 60 controls).

The complete existing symbols profile preserves all 242 source/status rows
(184 passed, four failed, 54 unsupported). The array-descriptors profile has
3,556 passed and 18 unsupported modes; the form getter-retention test gains both
modes, with no lost pass. Both unchanged regression gates pass.

Initial focused compilation/test failures and the first full-suite run remain in
the [raw record](evidence/dom-own-properties.json). Two historical private tests
needed corrections: Boolean native setters belong on input rather than div,
and newly implemented own-descriptor reads return undefined for inherited DOM
attributes. The original failing sources are retained; the frozen external
oracle and all five Window reflection refusals are unchanged. The previous
Vulkan zoom checkpoint passed all nine [CI jobs](evidence/vulkan-native-zoom-ci.json).

### Explicit initialization and author-work boundary

The [runtime work boundary](runtime-budget-boundary.md) grants a fresh fixed
author allowance only after raw bootstrap succeeds. Both phase limits remain
100,000, allocation accounting remains cumulative, and existing script/event
entry resets are unchanged. Raw bootstrap still leaves 70,656 units and charges
738,522 bytes. Diagnostic witnesses now observe the raw phase directly.

Rust 1.88 passes **1,426 default tests**, Rust 1.98 passes **1,549 native-feature
tests**, native strict Clippy and formatting pass. Two new groups verify exact
first-script observation/debit equivalence and terminal shared work across
getters, conversions and nested event dispatch. Existing raw exact/one-short
bootstrap and heap boundaries remain intact. Independent source review is clear.

Every complete row in the frozen DOM and Object.is local corpora remains
unchanged: 136 cases and 104 controls, including all eight expected resource
outcomes. There is no conformance or timing gain claimed. All checks passed on
their first attempts; the [raw results](evidence/runtime-budget-boundary.json)
retain commands, observations, the source diff and review. The prior DOM
own-property commit passed all nine [CI jobs](evidence/dom-own-properties-ci.json).


### Represented DOM interface prototypes

The [interface prototype implementation](dom-prototypes.md) eagerly installs
154 interface records, including reused EventTarget, with represented HTML,
SVG and MathML inheritance. The existing nine ParentNode operations now live
on their defining prototypes; saved calls, replacement and deletion use those
ordinary mutable bags. Text, Comment and DocumentFragment constructors create
authentic nodes after ordered conversion, prototype access and fresh admission.

Rust 1.88 passes **1,460 default tests** and Rust 1.98 passes **1,583 native-feature
tests**, both including every ignored test. Strict native all-target Clippy and
format checks pass. The 31 focused prototype groups include six separately
executable JavaScript categories in both modes, namespace mapping, cached native
identity, constructor callbacks and exact/one-short admission. The unchanged HTML
fixture passes direct and confined worker checks with six green samples on load,
six blue samples after clicking, and result text changing from `ready` to `6`.

The first integrated full run retained six failures. Three private installer
witnesses lacked the scratch capacity needed to replay an early bootstrap stage
after the larger completed realm. Their setup now reserves nine slots before
measurement; the full-capacity guard and exact/one-short assertions are unchanged.
A newly added native-slot charge ran after generic intrinsic publication; moving
it before publication restores the Object.is failure contract without changing
successful cost. AbortSignal now owns its required class-string tag, so the new
EventTarget tag cannot mask it. Value-member evaluation now consumes its reference
in one continuation, removing a redundant frame and restoring the unchanged
5,000-member unbound-base ReferenceError witness within the same heap limit.

Early per-entry and then bulk name-map algorithms exceeded bootstrap work.
Eager indexed records remove two redundant name registries; cached native bag IDs
and direct node mapping remove actual lookups. No work/storage limit increased.
Final raw bootstrap leaves **11,133 of 100,000 work units**, charges **1,746,193
cumulative bytes**, and uses 663 objects. Successful author allowance remains
100,000 and cumulative heap remains 8 MiB.

The original 12,699-byte aggregate fixture is retained unchanged. Both of its
ordinary-success expectations still reach the author work limit; smaller cases
are separate coverage and do not reclassify those outcomes. Complete native
members, Document reflection, host prototype mutation and further constructors
remain unfinished. The [evidence record](evidence/dom-prototypes.json) retains
attempts, integration failures and compatibility observations.

Frozen local replays change only the two real-interface-prototype modes: the
DOM method suite verifies **56/58 expectations**, with all 44 controls healthy.
Object.is retains **72/78** and all 60 controls. Compared with the preceding
own-property reports, Symbol retains 184 passes, 54 unsupported and four failed
modes (80 controls), and array descriptors retain 3,556 passes and 18 unsupported
modes (84 controls). Reflect construction retains all 38 passes and 96 controls
against a fresh replay of the prior release. Every compared case fingerprint,
expectation, corpus/policy hash and control observation remains unchanged except
the two stated DOM gains. The array-descriptor gate's two gains over its older
baseline were already present before this change; they are not new gains here.


### ProcessingInstruction and CharacterData accessors

[Evidence](evidence/processing-instruction.json) records checked PI construction,
Document.createProcessingInstruction, the target getter and CharacterData
data/UTF-16 length accessors. XML Name validation uses the literal XML 1.0 Fifth
Edition ranges. Scalar DOM strings retain exact data; lone-surrogate data remains
explicitly unsupported. The previous prototype commit passed all nine
[GitHub CI jobs](evidence/dom-prototypes-ci.json).

Rust 1.88 passes **1,497 default tests** and Rust 1.98 passes **1,620 native-feature
tests**, with no failures or ignored tests. Strict all-target native Clippy and
formatting checks pass. The focused PI filter passes 36 groups; the DOM checked
filter passes 13, including three new owned-storage boundary groups. A six-sample
HTML fixture verifies green load states, blue click states and ready→6 text in
both the direct pipeline and the confined worker.

The independent release replay executes twelve unchanged construction categories,
seven unchanged accessor categories and one separately authored constructor-
override brand case, each in sloppy and strict mode. It progresses from **0/40 to
38/40 ordinary-success expectations**. The original authentic-brands case reaches
the unsupported host Object.setPrototypeOf operation in both modes. Its source
and ordinary-success expectation are unchanged and remain unmet. The separate
constructor-override case tests genuine accessors with an alternate initial
prototype. These local cases do not establish upstream DOM conformance.

All case identities, source fingerprints, expectations and observations remain
unchanged in the five compared established profiles: DOM method identity
**56/58 verified**, Object.is **72/78 verified**, Symbol **184 passed / 54
unsupported / 4 failed**, array descriptors **3,556 passed / 18 unsupported**,
and Reflect construction **38 passed**. Their respective 44, 60, 80, 84 and 96
controls remain healthy. The array gate's two gains over its older baseline were
already present before this change; they are not new PI gains.

Constructor and setter witnesses measure exact and one-short work/heap admission,
assert no partial node/prototype publication or data replacement, and verify
callback side effects survive later capacity refusal. Actual full document-byte
and node-count boundaries are checked without changing production limits.
Getter/setter brands precede conversion; argument conversion and new-target
prototype access precede creation validation. Saved function calls restore outer
stack ownership after refusal. Owned UTF-8 buffers move into DOM storage.

Raw bootstrap leaves **9,511 of 100,000 work units**, charges **1,761,677 cumulative
bytes** and holds **668 objects/capacity**. Legacy native/prototype registries
remain at 321/25 entries. Only descriptive bootstrap snapshots changed; exact
resource contracts and all quotas remain unchanged. Independent source review
covered metadata, call ordering, admission and fixtures; runtime validation was
performed separately.

The first focused attempt retained 34 passing groups and one failure at the
pre-existing host-prototype gap; no production correction followed that run.
The original unmet source remains alongside the separate passing brand case.
Independent documents, complete CharacterData/Node members, PI pseudo-attribute
APIs, exact surrogate-preserving document storage, mutation observers and live
ranges remain unfinished. No new GPU pixel or Chromium performance measurement
is assigned to this DOM change; full compatibility and production security remain
unachieved.


### Five CharacterData methods

The initial public run at `916d293` passed the default, minimum-Rust and two
probe jobs, but Rust 1.88 presenter Clippy rejected two assertion diagnostic
format strings. Four matrix jobs were cancelled by fail-fast. Inlining the
same variables fixes the two diagnostics; the exact Rust 1.88 presenter Clippy
command and formatting pass locally. Test expressions and production behavior
are unchanged. The [CI fix receipt](evidence/character-data-ci-fix.json) retains
the failed run, minimal patch and successful local check.

[Evidence](evidence/character-data.json) records ordinary prototype substringData,
appendData, insertData, deleteData and replaceData for Text, Comment and PI nodes.
The previous PI commit passed all nine [CI jobs](evidence/processing-instruction-ci.json).
Rust 1.88 passes **1,520 default tests** and Rust 1.98 passes **1,643 native-feature
tests**, with no failures or ignored tests. Strict native all-target Clippy and
formatting checks pass. Focused CharacterData and bootstrap filters pass 27 and
22 groups respectively, including 20 new method groups.

The independent 13-case fixture passes all **26 ordinary modes**. Four separate
unchanged policy sources, each in two modes, reach the documented terminal
Unsupported boundary for final lone-surrogate DOM data. Their eight ordinary
standards-success expectations remain unmet; policy observations are counted
separately. The combined release replay moves from **0/34 to 26/34 standards
expectations**. Substring results may contain individual surrogate units, and
mutations that repair a pair across the complete splice succeed.

A 5,046-byte browser fixture retains one connected Text node and changes its
visible data from ready to 6 on click. Direct and confined-worker checks verify
literal draw-command text, all six green/blue pixel samples and complete
worker/direct pixel equality. A separate Page test checks connected text and
style changes, title updates, clean textarea values and form serialization.
Dirty/default textarea separation and complete children-changed reactions remain
unfinished.

Exact and one-short work/heap witnesses cover all five operations across all
three supported brands. Additional checks cover fresh post-conversion bounds,
retained-byte refusal after callback effects, authentic receivers, prototype
replacement/deletion, call cleanup, whole-splice repairs and selected substring
reads from a node larger than the JavaScript string limit. Substring avoids an
untouched-tail scan; mutation scans and exact output storage are prepaid.
Raw bootstrap leaves **8,246 work units**, charges **1,777,574 cumulative bytes**
and reserves **673 objects**. Native/legacy prototype registries remain 321/25;
quotas and raw exact/one-short bootstrap contracts are unchanged.

All case/control observations, fingerprints and expectations remain unchanged
in the DOM method, Object.is, Symbol, array-descriptor and Reflect-construction
replays. Their counts remain 56/58 verified, 72/78 verified, 184/54/4
passed/unsupported/failed, 3,556/18 passed/unsupported, and 38 passed; all controls
are healthy. The previous PI replay remains 38/40 ordinary expectations, with
host prototype mutation still unmet. The array gate's two improvements over its
older baseline predate this change.

The initial compile failure referenced an unavailable serde_json test dependency.
Four static fixture files were then extracted byte-for-byte from the original
JSON source fields, with their hashes checked and no dependency added. No
production correction followed the first draft. The final formatter collapsed
one worker-test call and removed its optional trailing comma; exact comparison
confirmed that sole formatting change. A whitespace-only comparison initially
rejected that comma removal; its corrected result and the original source are
retained. Independent source reviews cover production scan bounds, metadata,
browser outcomes and policy extraction. Full DOM compatibility, exact arbitrary
UTF-16 document storage, reaction hooks, production security and Chromium
performance remain unachieved.


### Exact DOM string storage

The [storage foundation](dom-strings.md) adds canonical single-payload Scalar
UTF-8 / exact UTF-16 Units storage for Text, Comment and PI data. ERWA tags those
payloads and rejects unknown tags, noncanonical Units, truncated/oversized data
and older versions. Detached payload accounting and snapshot graph checks remain;
the existing parser-expanded 18 MiB scalar case still passes. EWB1 is unchanged.
All nine jobs for the preceding `7416797` checkpoint
[passed](evidence/character-data-ci.json).

The final source passes **1,552 default tests on Rust 1.88** and **1,675
Vulkan-feature tests on Rust 1.98**, with no failed or ignored tests. There are
32 new groups. The initial all-target build and 55 unique focused tests passed
on their first attempts; one header group ran twice, for 56 focused executions.
Strict all-target Rust 1.98 native and Rust 1.88 presenter Clippy checks and final
formatting pass. The [evidence](evidence/dom-strings.json) binds source manifests,
release binary, raw logs, reviews, comparisons and a verified artifact archive.

Tests cover canonical transitions and retained bytes, exact clones and snapshots,
paired units across selected nodes, bounded CSS/SVG projections, hostile wire
claims, exact script reads and textarea line-ending normalization. Independent
canvas comparisons match literal replacement glyphs while retained units stay
unchanged. The inline SVG pair test compares complete raster bytes with a literal
scalar source. The inline script loader refuses unpaired source before execution;
the native UTF-8 editor refuses nonscalar textarea data even before a pending
edit acknowledgement. Exact JavaScript HTML serialization and unit-aware native
editing remain unfinished.

On the measured 64-bit Rust 1.88 target, String/DomString headers are 24/32 bytes,
while NodeKind and Node remain 96/136 bytes. Empty/single-text reads avoid
unrelated arena scratch; scalar glyph iteration keeps the direct UTF-8 path.
Raw bootstrap remains **8,246 work units**, **1,777,574 charged bytes**, 673
objects/capacity and native/legacy prototype counts 321/25. Numerical quotas,
metadata installation and reset sites are unchanged.

The release retains all **4,064 case modes and 364 controls** across five
selected compatibility profiles and the existing PI/CharacterData suites.
Source fingerprints, expectations and complete observations are unchanged.
CharacterData remains 26/34 standards expectations: eight final-unpaired-data
modes still reach their original Unsupported boundary. PI remains 38/40 because
two host-prototype mutation modes are unimplemented. Those are remaining
compatibility gaps; this checkpoint prepares exact runtime string production.

The first full default run failed an existing CLI assertion because derived
Debug exposed the new storage wrapper. Explicit Debug preserves the established
scalar dump and shows nonscalar data as UTF16 numeric arrays; the original
assertion passes unchanged. Rust 1.98 Clippy then requested the equivalent
fixed-size slice API in two codec loops and one pixel witness; no wire bytes,
expectations or quotas changed. Both corrections and the earlier successful
full runs remain retained.

A repeated default run failed the existing timezone helper's live-marker
prerequisite. Its capture result was not logged, so the exact cause is unproven;
review found the prerequisite shares the one-second startup/IO/exit deadline.
Date sources, assertions and deadlines were unchanged. The isolated test and
a complete final default rerun passed, as did the final native suite. All attempts
and the bounded review are retained. No new GPU speed or Chromium comparison is
assigned to this DOM change; full web compatibility and production security
remain unachieved.

### Exact JavaScript character-data production

[Exact production](dom-production.md) now covers Text/Comment/PI constructors,
Document text/PI factories, the CharacterData data setter and all five data
methods. A paid canonical builder retains every UTF-16 unit, emits one chosen
payload and validates a complete splice before publication. Fresh replacement
admission precedes output allocation. Conversion order, genuine brands,
creation-only PI validation, callback effects and sparse constructor overrides
remain covered; substring still visits only its reached prefix and result.

The final source passes **1,577 default tests on Rust 1.88** and **1,700 tests
with Vulkan rasterization on Rust 1.98**, including confinement checks, with no
failures or ignored tests. Strict all-target Clippy passes on Rust 1.98 with
Vulkan rasterization and Rust 1.88 with the presenter; formatting passes.
The 25 added test groups include complete-splice pair repair, retained isolated
units, measured exact/one-short work and allocation boundaries, fresh callback
state and direct/worker pixel witnesses. Focused validation passes 105 distinct
tests across 107 executions. Bootstrap remains 8,246 unused work units,
1,777,574 charged bytes, 673 objects/capacity, 321 native entries and 25 legacy
prototype entries. Limits, reset behavior, ERWA and EWB1 are unchanged.

The final release SHA-256 is
`4e613cf659787db1093ba1993bb4739e1ac0eb795d30ab164bbecca0df4ad207`.
The original 34 CharacterData modes now all pass, including eight unchanged
standards-success expectations previously observed as Unsupported. No source
or expected final unit array changed. Across 4,064 established case modes, only
these eight gains occur; there are no losses or other complete-record changes.
All 364 existing controls are unchanged. The 24 new independent modes advance
from 2 to 24 passing expectations, with all eight new controls verified on both
releases. PI remains 38/40. The array-descriptor report's two gains against its
older gate predate this increment and are unchanged versus the foundation.

Initial observations are retained: source review corrected integration tests'
private API calls before compilation; compile one found a test accessing a
sibling-private override map, fixed without changing production or public APIs;
the first worker command selected one ignored test, then the corrected command
executed it unchanged. Replay preparation corrected an intrinsic Error identity
expectation and made absent observations retain timeout/adapter-error rows.
All case source bytes and ordinary-success expectations stayed unchanged.

See [the summary](evidence/dom-production.json) and its verified archive for
source manifests, exact commands/logs, all before/after records and independent
reviews. The [preceding storage checkpoint CI](evidence/dom-strings-ci.json)
passed all nine jobs. Legacy container text writers, attributes, exact HTML
serialization, unit-aware editing and broader Node/reaction semantics remain
unfinished. No new GPU performance or Chromium comparison is claimed.

### Ordinary Node data accessors

[Node data accessors](node-data.md) provide ordinary mutable `nodeValue` and
`textContent` descriptors over represented node kinds. Exact CharacterData and
descendant reads preserve UTF-16 units. Container writes prepare payload,
children and affected base/details state before detachment, then publish zero
or one fresh Text. Detached old subtrees retain their identities and bytes.
Both runtime work and cumulative allocation counters survive success/refusal;
no quota or reset rule changes.

The final source passes **1,619 default tests on Rust 1.88** and **1,742
Vulkan-feature tests on Rust 1.98**, including confinement tests, with zero
failures or ignored tests. Strict all-target Clippy passes for Rust 1.98 native
and Rust 1.88 presenter builds; formatting passes. The 42 added groups cover
runtime descriptors/brands/conversion, checked DOM replacement and four direct
Page/worker witnesses. Focused runs passed 83 distinct tests across 87 executions.
Raw bootstrap has 6,640 remaining work units, 1,798,334 charged bytes, 677
objects/capacity, 321 native entries and 25 legacy prototype entries.

Final release SHA-256:
`30269af68b3c87349c122104a7da0be0cd1b5f3ad20816620c66cd2c5d8058f1`.
Across 4,088 established case modes and 372 controls, complete observations and
expectations are unchanged. CharacterData remains 34/34 and PI remains 38/40.
The two new Node inventories advance from 0/16 and 0/20 to all 36 expectations
passing. Their 16 controls advance from eight healthy generic controls to all
16; the other eight deliberately depend on the formerly absent accessors.
No source or ordinary success expectation was weakened to produce these gains.

Both preexisting lossy DOM getter assertions are retained and explicitly
migrated: the UTF-16 boundary test and a String.concat test. The first full
default run exposed the latter; its log remains retained, and the fix changes
only the exact-value assertion. Measured bootstrap counter assertions were
updated without changing budgets. The [summary](evidence/node-data.json) and
[archive](evidence/node-data.tar.gz) bind final source, original fixtures,
release binary, commands/logs and independent reviews. The prior producer
checkpoint [passed all nine CI jobs](evidence/dom-production-ci.json).

Remaining work includes legacy string writers and full DOM reactions/interfaces.
Standard B-tree and URL/encoding/IDNA allocation remains infallible; logical
script accounting is not complete process allocation recovery. This checkpoint
adds no GPU timing or Chromium-performance result.

### Exact string arguments in ParentNode.append

[Exact append production](append-domstrings.md) preserves UTF-16 string
arguments as separate canonical Text nodes. All conversions complete before
materialization. Each Text and the later temporary fragment pay actual typed
arena growth before publication; earlier detached Texts and completed argument
moves survive later refusal. Existing hierarchy checks, metadata and reset
rules are unchanged.

All **1,637 default tests on Rust 1.88** and **1,760 Vulkan-feature tests on
Rust 1.98** pass, including confinement tests. Strict all-target Clippy passes
for Rust 1.98 native and Rust 1.88 presenter builds; formatting passes. The
18 added groups include independent ordinary cases, measured resource boundaries
and direct/worker load/click witnesses. Focused runs passed 78 distinct tests
across 81 executions. Every compile/test command passed on its first attempt.
Raw bootstrap remains 6,640 work units, 1,798,334 charged bytes, 677
objects/capacity, 321 native entries and 25 legacy prototype entries.

Release SHA-256:
`71bb4c92d432ed247c483cf588d1cebaae9364194c5e9d0ed45c1c44b44a47b0`.
All complete observations across 4,124 established case modes and 388 controls
are unchanged. The new append inventory advances from 4/14 to 14/14 matched
ordinary expectations; its controls advance from 12/16 to 16/16. Only the four
exact-payload controls depend on the newly implemented fidelity. Source bytes,
expected success records, and earlier failure records remain retained.

Before compilation, two existing private tests received explicit test-owned
spare capacity to preserve their original node-cap and second-move scenarios;
all original assertions remain. New tests separately exercise real growth
refusal. The original unexecuted literal draft also gained a successful saved
Document.append prerequisite guard before freezing. These preparation changes
and reviews are retained in the [summary](evidence/append-domstrings.json) and
[archive](evidence/append-domstrings.tar.gz). The previous Node checkpoint
[passed all nine CI jobs](evidence/node-data-ci.json).

General insertion allocation limits, remaining scalar writers and full DOM
reactions/interfaces remain open. No new GPU timing, Chromium comparison or
production-security claim accompanies this change.


### Ordinary exact Document.title

[Document.title](document-title.md) now has ordinary configurable/enumerable
prototype accessors. Exact UTF-16 direct-Text reads strip/collapse only ASCII
whitespace, with HTML tree-order or direct SVG selection. Raw writes perform
DOMString conversion before current-tree selection and preserve staged creation,
insertion and later replacement effects under resource refusal. Host metadata
projects the same normalized units, retains URL fallback and caps worker titles
at 512 Unicode scalars. Author quotas, reset points and transport are unchanged.

The sixteen-path final source passes **1,672 default Rust 1.88 tests** and
**1,795 Vulkan-feature Rust 1.98 tests**, with zero failures or ignored tests.
Strict all-target Clippy passes for Vulkan rasterization and the Rust 1.88
presenter; formatting passes. Thirty-five groups were added: 12 independent
case bodies in both modes, 21 other private groups, and two Page/worker tests.
Final passing focused commands contain 82 executions of 78 unique tests.

The first compile caught an ambiguous empty-array assertion; an equivalent
is_empty assertion fixed its type. The initial bootstrap filter retained 22
passes and two stale descriptive-count failures. After a successful measurement,
three work/object count literals were updated. Strict Clippy then requested a
nested-conditional rewrite; a let-chain preserves
the same short-circuit order and budget/error behavior. Both full suites were
rechecked on that final source. Original source, failures, formatting-edition mistakes,
pre-execution depth correction and all retries remain retained.

Raw bootstrap is 6,280 remaining work units, 1,804,200 charged bytes, 679 objects
and capacity, 321 native entries and 25 legacy prototypes. Title installation adds
360 work units, including its two accessor bags and subsequent property-insertion
costs; no budget increased.

The final release preserves complete rows for all 4,138 established case modes
and 404 controls. The 24 new ordinary-success title modes advance from 4 to 24;
the 16 controls advance from 12 to 16. There are 20 case gains and four
title-dependent control gains, with no losses, other changes or input drift.
Sources and expectations remain frozen. A compact three-phase browser witness
checks exact storage and identities, retained old subtrees, full Page title versus
worker scalar truncation, matching text draw commands, and full-canvas literal
glyph references with six colored squares.

The [summary](evidence/document-title.json) and
[verified archive](evidence/document-title.tar.gz) bind all sources, commands,
raw reports, reviews, measured bootstrap and release fingerprints.
The [preceding append CI receipt](evidence/append-domstrings-ci.json) records
all nine jobs passing for `7765fbf`. It is separate from title validation.

Existing B-tree/URL allocation qualifications, incomplete reactions, Document
ownership, XML parsing and remaining interfaces still apply. This is not a
production-security certification or a new GPU/Chromium performance measurement.

### Batched Node constant initialization

The [batch initializer](node-constants-bootstrap.md) preserves the eighteen
constants on Node and Node.prototype, their descriptors and creation order,
existing native accessor handles and independent mutable runtime objects.
Sixteen new groups cover those semantics, interleaved live runtimes, exact and
one-short quota admission, malformed owner shapes and terminal private staging
failure. All 84 passing focused observations cover 79 unique groups.

Rust 1.88 passes **1,688 default tests** and Rust 1.98 passes **1,811 native-feature
tests**, including ignored confinement tests. Strict native/presenter Clippy and
formatting pass. All-target compilation and the release build pass. The first
bootstrap filter retained 24 passes and one stale remaining-work assertion;
its single literal changes only after measuring 11,022 remaining units. No quota,
reset, descriptor expectation or independent fixture changes.

The release comparison retains all **4,162 established case records and 420
controls**, plus **14 independent Node modes and 12 controls**, without gains,
losses, input drift or other complete-record changes. Existing unmet outcomes
remain visible. This optimization adds no standards coverage. Helper charges
fall from 12,986 to 8,244 work units and 103,140 to 33,876 bytes. Complete bootstrap
charges become 1,734,936 bytes, with unchanged 679 objects, 321 native entries
and 25 legacy prototypes.

The [summary and archive](evidence/node-constants-bootstrap.json) retain source,
reviews, all attempts, raw compatibility rows and the separate initialization/drop
benchmark. The initial non-LTO benchmark wrapper link failure is retained; all
four arms use the same corrected thin-LTO wrapper before any timing. No page,
Vulkan or Chromium performance claim follows from these checks. The preceding
Document.title commit passed all nine [GitHub CI jobs](evidence/document-title-ci.json).


### Exact Text splitting and adjacent reads

[Text operations](text-operations.md) add ordinary cached `splitText` and
`wholeText` functions over authentic represented Text. UTF-16 offsets use Web IDL
unsigned-long conversion after receiver and required-argument checks. Data and
parent reads follow author callbacks. Suffix creation, local insertion and
original-prefix replacement are separately admitted; a late refusal retains
completed stages. Adjacent reads use exact units, separate template lists and
separately charged Vec/Rc copies.

Rust 1.88 passes **1,733 default tests** and Rust 1.98 passes **1,856 native Vulkan
tests**, including ignored confinement checks. Formatting, strict native Clippy,
strict presenter Clippy and the release adapter build pass. Forty-five new groups
cover 15 DOM, 28 runtime, one Page and one worker. Passing focused commands yield 149 observations
covering 143 distinct groups, with six overlaps named in the evidence.

Initial all-target compilation and all 43 new DOM/runtime groups passed. The first
bootstrap filter retained 24 passes and two stale descriptive failures; the identity
filter retained 20 passes and one repeated failure. Raw initialization measured 10,636
remaining work, 1,741,271 charged bytes, 681 objects/capacity, 321 native entries and 25
legacy prototypes. Only three descriptive literals across two tests changed
after measurement. All production and independent fixture source stayed exact
from initial review. Numeric limits and entry/reset behavior are unchanged.

All **4,176 established case records and 432 controls** remain unchanged in the
release replay. All 28 new independent strict/sloppy modes pass (baseline zero), and
all 12 controls are healthy (baseline four). The baseline's missing-prerequisite
TypeErrors and nonzero runner exit remain visible. No sources, expectations or
control pairings changed; comparison retains complete rows and bindings.

The browser fixture checks seven stable Text pairs and one additional split
through a real click. Exact UTF-16 data, node IDs, backlinks, title metadata,
style pixels, clean textarea text, separate template lists and base URL survive
both Page and confined-worker paths. A summary's index shifts while its ID stays
fixed; Page primes its cache before mutation. Per-node replacement-glyph canvas
references preserve the split boundaries, with nonempty glyph and literal color
checks. This does not establish cross-node text shaping, Range/observer delivery,
CDATA support, complete security or the requested Chromium performance target.

See the [summary](evidence/text-operations.json),
[archive](evidence/text-operations.tar.gz), and
[preceding Node constant CI receipt](evidence/node-constants-ci.json). All nine
jobs passed for that preceding `774c275` checkpoint.

### Exact descendant Text normalization

[Node.normalize](node-normalize.md) adds one ordinary cached Node method. It
removes empty ordinary Text descendants and joins each contiguous run into its
first nonempty node, preserving exact UTF-16 units and retained detached data.
It excludes the receiver and keeps template content separate. Canonical
replacement and tail removal have distinct admitted stages; Resource refusal
can retain earlier mutations, a joined survivor beside its attached tails, or
a fully normalized tree before final bookkeeping.

Rust 1.88 passes **1,775 default tests** and Rust 1.98 passes **1,898 native Vulkan
tests**, including ignored confinement checks. Formatting and both strict
Clippy configurations pass. The 42 new groups comprise eleven DOM, twenty-nine
runtime and two browser/worker groups. Successful focused commands contain
120 observations across 117 distinct groups.

Initial compilation and all forty new DOM/runtime groups passed. The first
bootstrap filter retained 25 passes and two stale descriptive assertion
failures. Measurements were 10,199 remaining work units, 1,744,501 charged bytes,
682 objects/capacity, 321 native entries and 25 legacy prototype entries. Only
three descriptive literals changed in response. The first full default run
then retained 1,535 passes and one old partial property-order assertion failure;
that private group is explicitly renamed and now requires `normalize` between
`textContent` and `ELEMENT_NODE`. Original sources, failures and independent
review are retained. The initial sixteen source and fixture paths stayed
byte-exact. No quota or execution reset changed.

The Page and confined-worker witnesses load once and dispatch one real click.
Eight five-Text runs retain eight original survivors and detach 32 original
nodes without creating any. Both phases check exact payloads and IDs, title,
stylesheet pixels, clean textarea text, separate template trees, summary ID and
fixed base. Page primes its actual summary cache; the worker checks its decoded
snapshot without claiming to prime the original worker's cache. Full-canvas
literal references and nonempty glyph bands compare per-node replacement glyphs
before joining and the scalar surrogate pair after joining.

The release replay passes all **32 new strict/sloppy case modes**, up from zero,
and all **16 controls**, up from four. All **4,202 other established case
records and 440 controls** remain byte-exact. Two earlier Node constant case
modes now fail with Error because they require the former full property list.
Four old reflected-order controls are unhealthy with TypeError at their old
inventory prerequisite; their positive partners fail, so matching an expected
exception does not make a negative control healthy. The old sources and
expectations are unchanged. Both the old Node profile and the aggregate replay
command retain exit one. A separate classifier verifies these exact six
anticipated changes, while preserving their raw losses. Current inventory
cases and positive/wrong controls pass in the independent new profile.

The release build passes. The [summary](evidence/node-normalize.json) and
[archive](evidence/node-normalize.tar.gz) retain source holds, source-review
corrections, failed and passing attempts, command logs, complete before/after
reports, the predeclared inventory policy and the classifier's input bindings.
The preceding [Text checkpoint CI receipt](evidence/text-operations-ci.json)
records all nine GitHub jobs passing for `9825a53`.

These selected records do not establish full DOM conformance. CDATA/XML,
Range updates, mutation records, slotting and custom-element reactions remain
unimplemented. No page, GPU, physical-memory or Chromium performance result is
claimed, and complete compatibility and production security remain unmet.

### Node child, identity and containment predicates

[Node predicates](node-predicates.md) add ordinary cached `hasChildNodes`,
`isSameNode` and `contains` methods. They authenticate represented receivers,
apply required nullable Node argument conversion, and read current ordinary
children and parent links. Containment includes the receiver and preserves the
boundary between a template element and its separate content fragment.

Rust 1.88 passes **1,805 default tests** and Rust 1.98 passes **1,928 native Vulkan
tests**, including ignored confinement checks. Formatting, both strict Clippy
configurations and the release build pass. The thirty new groups comprise
sixteen independently authored runtime bodies, twelve private runtime checks,
one Page test and one confined-worker test. Successful feature-focused commands
contain 149 observations across 145 distinct groups.

The first bootstrap filter retained 26 passes and two stale descriptive assertion
failures. Exactly three literals changed to match measured initialization:
8,807 remaining work units, 1,755,715 charged bytes, 685 objects/capacity,
321 native entries and 25 legacy prototype entries. The change adds 1,392 work
units, 11,214 bytes and three metadata bags. Limits and reset sites are unchanged.
An unused mutable test-helper binding and three test-only cloned argument slices
were corrected after compiler/Clippy diagnostics. Production and independent
fixture bytes stayed unchanged after their initial source hold; all earlier
sources and attempts remain retained.

The first native full run retained 1,616 passes and one failure: a date-host
helper's startup marker was not observed before capture returned under its
existing one-second deadline. The failing assertion did not record the action
or returned error. The unchanged exact test passed in isolation, and the unchanged full native suite
passed with four test threads. Scheduling sensitivity is an inference, not a
proven sole cause. No deadline, assertion or test inclusion was relaxed.

Both browser paths load once and dispatch a real click that moves a branch and
detaches a different subtree. Eighteen captured node identities remain stable,
and the click creates no nodes. Saved predicate functions follow current links,
retained detached descendants and separate template trees despite own-property
shadowing. The tests check title/status, literal full-canvas references, text
commands and green-to-blue pixels. They do not claim summary-cache priming.

The release replay passes all **32 new strict/sloppy case modes** and all
**16 controls**, up from zero and four. Of 4,236 established case records,
**4,234 remain byte-exact**; of 460 established controls, **456 remain byte-exact**.
The two newly failing cases and four newly unhealthy controls require Normalize's
former complete property inventory. Raw case observations are Error and control
observations are TypeError; their positive partners fail, so a matching negative
exception is not healthy. The earlier Node-constant inventory's two case failures
and four unhealthy controls remain unchanged. Both historical profile commands
and the aggregate command retain exit one. Frozen sources, expectations and
pairings are unchanged. A separately reviewed classifier verifies only these six
anticipated new differences; the current independent 26-key inventory and its
positive/wrong controls pass.

The [summary](evidence/node-predicates.json) and
[archive](evidence/node-predicates.tar.gz) retain the source holds and corrections,
failed and passing attempts, all complete before/after records, comparison policy,
release binding and reviews. The preceding [Normalize CI receipt](evidence/node-normalize-ci.json)
records all nine GitHub jobs passing for `618fa35`.

These methods do not add shadow trees, composed ancestry, cross-document
adoption or the remaining Node interface. Traversal validates reached local
shapes and reciprocal membership within the existing depth bound, and charges
scanned sibling IDs. It allocates no owned traversal/payload storage; generic VM
and inherited diagnostic allocation limits remain. This checkpoint makes no
page/GPU/physical-memory speed claim and does not establish complete web
compatibility, production security or the requested Chromium performance target.

### Vulkan probe cleanup observation race

The predicate checkpoint's GitHub Vulkan probe job exposed a Linux process-exit
race in its Python test helper: reading an already opened `/proc/<pid>/stat`
raised `ProcessLookupError` after the process disappeared. The helper now accepts
that specific disappearance alongside `FileNotFoundError`; permission errors
still propagate. Production process supervision is unchanged.

The new regression first reproduced the failure, then all **13 Vulkan probe
Python tests** passed, including the existing real descendant-cleanup checks.
The [record](evidence/vulkan-probe-proc-race.json) retains the original CI failure,
source hashes and local before/after outputs. It does not claim a new GPU result
or substitute a retry for the original failed observation.

The [original CI receipt](evidence/node-predicates-ci-first.json) records eight
successful jobs and the Vulkan probe failure for `6834288`. The separate
[corrective CI receipt](evidence/probe-fix-ci.json) records all nine jobs passing
for `066435f`. The [binding record](evidence/preceding-ci-review.json) distinguishes
these two commits; the correction does not change Runtime source.

### Ordinary Node roots after options conversion

`Node.prototype.getRootNode` is an ordinary cached nonconstructible method for
represented nodes. Receiver authentication precedes dictionary conversion;
object options perform one inherited `composed` Get with their original receiver.
Only the node ID survives that callback, and the root walk reads fresh links.
Default/nullish options perform no Get. Template content remains a separate
ordinary root for both composed values; ShadowRoot is not represented.

Rust 1.88 passes **1,837 default tests**, and Rust 1.98 passes **1,960 native Vulkan
tests**, including ignored confinement tests. Both full suites use four test
threads. Formatting, both strict Clippy checks and the release build pass.
The **32 new groups** are 16 independent and 14 direct Runtime groups plus Page
and confined-worker witnesses. Focused checks retain 182 passing observations
covering 177 unique test names.

The initial bootstrap filter retained 27 passes and two stale descriptive
snapshot failures. Exactly three literals across two test files were corrected
after actual measurement: 8,318 work units remaining, 1,758,971 charged bytes,
686 objects/capacity, 321 native entries and 25 legacy prototype entries. The
new method adds 489 work units and 3,256 charged bytes. Numeric quotas and reset
sites remain unchanged. Initial compilation and all new groups passed; no
production source correction was needed. A data-only correction-preparation
assertion first used the wrong local variable name and stopped before editing;
that attempt and the retained original file remain in the evidence.

Both browser paths load once and dispatch one real click. Three inherited
options getters temporarily move a receiver, move its ancestor and detach a
retained branch. Returned roots follow the resulting internal links. Twenty
captured identities and the total node count stay unchanged. Titles, status,
literal full-canvas references, green-to-blue pixels, text placement and distinct
template/fragment trees all pass.

The release passes all **32 new case modes** and **16 controls**, from baseline
zero and four. Of 4,268 established case records, **4,266 remain byte-exact**;
of 476 controls, **472 remain byte-exact**. Two predicate full-inventory cases
newly fail with Error and four controls become unhealthy with TypeError because
their positive prerequisites require the earlier complete prototype inventory.
The twelve older Node-constant and Normalize inventory observations remain
unhealthy and byte-exact. All three historical profile exits and the aggregate
exit remain one. Frozen inputs and pairings are unchanged; the classifier
annotates only the six anticipated new losses. The current pristine 27-key
inventory and its paired controls pass. Established healthy counts change from
4,178 to 4,176 cases and from 468 to 464 controls; no historical failure is waived.

The [summary](evidence/node-root.json) and [archive](evidence/node-root.tar.gz)
retain the held sources, failed and passing attempts, original and corrected
fixture preparation, complete comparisons and independent reviews. The preceding
CI receipts above distinguish the predicate commit's failure from the separate
probe test correction's nine successful jobs.

The method charges reached local checks and full reciprocal sibling-ID scans,
with up to 256 edges and 257 visits. It allocates no traversal storage, while
object options separately pay their member key and ordinary Get/callback costs.
Generic VM and inherited allocation limitations remain. No shadow ancestry,
cross-document adoption, general graph validation, performance threshold,
complete compatibility or production-security result follows from this increment.

### Represented Node structural equality

`Node.prototype.isEqualNode` is an ordinary cached, nonconstructible method with
required nullable Node conversion. It compares exact retained character data,
represented namespaces and attributes, and ordered ordinary children without
authored getters or coercion in the native body. Template content is a separate
operand tree. Local same-ID and early-mismatch paths are explicitly scoped;
paired traversal validates reached backlinks, kinds, depth and per-side repeats.

Rust 1.88 passes **1,873 default tests**, and Rust 1.98 passes **1,996 native Vulkan
tests**, including ignored confinement tests. Both full suites use four test
threads. Formatting, both strict Clippy checks and the release build pass.
The **36 new groups** comprise 16 independent Runtime groups, 18 private groups
and Page/worker integration. Focused checks retain **219 passing observations**
covering **213 unique names**. Initial compilation and all new groups passed.

Measured raw bootstrap leaves **7,816 work units** and charges **1,762,227 bytes**,
with 687 objects and capacity, 321 native entries and 25 legacy prototype entries.
This matches the forecast of 502 additional work units and 3,256 charged bytes.
The initial bootstrap filter retains 28 passes and two stale descriptive snapshot
failures. Exactly three literals in two files were corrected after measurement;
no production source correction followed initial compilation. All numeric quotas
and reset sites remain unchanged.

The tested contiguous and alternating 256-edge branches consume 65,681 and
70,989 body work units, respectively, and 13,416 charged bytes each. Exact and
one-short work/heap retries retain the entire Document and its capacities.
A sparse layout refuses under the ordinary work allowance; its full calculated
schedule is not a measured success. These are logical accounting results, with
construction and invocation charges separate, not timing or physical memory.

Both browser paths load once and dispatch one real click. Independently created
live/detached peers compare equal before temporary changes to exact Comment data,
an attribute and visible Text. Intermediate mismatches and restored equality
are checked. All 29 recorded identities and the total node count stay unchanged,
with zero click-created nodes. Literal full-canvas references, green/blue markers,
glyph bands, text placement, `Equality ready`/`Equality done` titles and status
checks pass. Rendering changes follow explicit mutations, not equality itself.

The release passes all **32 new case modes** and **16 controls**, from baseline
zero and four. Of 4,300 established cases, **4,298 remain byte-exact**; of 492
controls, **488 remain byte-exact**. Two frozen getRootNode inventory cases newly
fail with Error and four controls become unhealthy with TypeError because their
positive prerequisites require the former complete member list. Eighteen older
Node-constant, Normalize and predicate inventory observations remain unhealthy
and byte-exact. Established healthy totals move from 4,208 to 4,206 cases and
480 to 476 controls. No frozen input, pairing or raw health is rewritten.

All four historical inventory profile commands and the aggregate replay retain
exit one. The independent classifier identifies only the six anticipated new
losses. The pristine 28-key inventory and its paired controls pass. Source-only
test corrections, the original truncated-name inventory and its data correction,
and the final HTML review's corrected timing statement are retained. That final
binding followed compiler start; root and layout final reviews plus the earlier
HTML incremental review preceded it. No engine rerun substitutes for a failure.

The [summary](evidence/node-equality.json) and
[archive](evidence/node-equality.tar.gz) retain held inputs, source, all attempts,
full comparisons and reviews. The preceding [root CI receipt](evidence/node-root-ci.json)
records all nine jobs passing for `51907b7`; it is distinct from these local checks.

The fixed namespace model, absent ShadowRoot/Attr/CDATA, cross-document ownership,
remaining DOM/JS interfaces and inherited allocator boundaries remain limits.
Sparse reached pages and active-depth frames are paid before growth and cleanup;
standard BTree allocation still has its inherited infallible process-OOM boundary.
This increment does not establish complete web compatibility, production security
or the requested Chromium performance threshold.

## Ordinary Node connection state

[Node.isConnected](node-connected.md) adds a cached readonly getter over current
ordinary parent links. Its shared root traversal preserves `getRootNode` options,
fees, validation, errors and the 256-edge endpoint. Template content remains a
separate root; real ShadowRoot and independent documents remain unimplemented.

Rust 1.88 passes **1,903 default tests** and Rust 1.98 passes **2,026 native Vulkan
tests**, including ignored confinement tests with four test threads. Both strict
Clippy checks, formatting and the release adapter build pass. All thirty new
groups passed initially: sixteen independent cases in both language modes,
twelve direct boundary groups and Page/worker real-click witnesses. The browser
checks retain 21 identities and zero click-created nodes while testing four
branch moves and literal full frames/text/title/status changes.

Focused successful runs contain 250 observations across 243 test names. The first
constant regression retains eleven passes and six failures from one shared stale
preconstant size assertion. A one-literal nine-to-ten correction yields seventeen
passes. Three other descriptive bootstrap literals were updated after measurement.
All focused attempts retain 261 passes and the six original failures. No production
source changed after initial compilation.

Raw initialization measures 7,292 remaining work units / 1,765,502 charged bytes /
688 objects and capacity, with 321 native entries and 25 legacy prototypes. The
524-work/3,275-byte increase matches the preimplementation ledger. Numeric quotas
and reset sites remain unchanged. The direct unary 256-edge getter uses 7,458
work units; wide sibling scans can exhaust the unchanged allowance.

The release records **32/32 new modes and 16/16 healthy controls**, versus 0/32
and 4/16 in the prior published release. Complete comparison retains **4,330 of
4,332 historical case rows and 504 of 508 controls byte-exact**. Only the old
equality inventory's two cases and four controls change, as anticipated; the
24 older unhealthy inventory rows stay unchanged. Historical healthy totals move
from 4,238/492 to 4,236/488. The six losses remain Error/TypeError failures; the
current 29-key cases and paired controls pass independently. Five historical
profile commands and their aggregate retain exit one.

The first independent result audit stopped at a stale preparation-manifest path
after verifying source and test results. A reviewed reader-only correction binds
the actual retained preparation records; the second audit passes with 369 bound
inputs. The failed report and original reader remain in the evidence archive.

The [summary](evidence/node-connected.json) and
[archive](evidence/node-connected.tar.gz) retain frozen inputs, twenty final
source paths, all attempts, exact corrections and an independent result audit.
The [previous equality commit CI](evidence/node-equality-ci.json) has nine
successful jobs. Local tests and prior CI do not establish full standards support,
production security or a Chromium performance comparison.

## Ordinary Node document position

[Node.compareDocumentPosition](node-position.md) adds ordinary masks over authentic
represented nodes, with required nonnullable input, canonical Document identity,
preorder and stable disconnected directions. Template content remains a separate
root. Paid complete root/depth walks, alignment and sibling scans use constant
body traversal storage and preserve the existing 256-edge/work bounds. Actual
Attr, ShadowRoot and independent document ownership remain unrepresented.

Rust 1.88 passes **1,938 default tests** and Rust 1.98 passes **2,061 native Vulkan
tests**, including ignored confinement tests. Initial compilation, formatting,
both strict Clippy checks and release construction pass. All **sixteen validation
commands pass on their first attempt**. Thirty-five new groups comprise sixteen
independent Runtime bodies in strict/sloppy modes, seventeen private groups and
Page/worker witnesses. Nine focused commands contain **286 observations across
278 unique names**, with no failed attempt.

Raw bootstrap measures **6,599 remaining work / 1,768,914 charged bytes /
689 objects and capacity**, with 321 native entries and 25 legacy prototypes.
The increase is 693 work units and 3,412 charged bytes relative to connected,
matching the held typed ledger. Three descriptive literals in two test files
were updated after the successful measurement; no failing bootstrap run occurred.
The initial nineteen source/fixture paths and final twenty-one paths retain exact
before images and the correction. No production source changed after initial
compilation, and no numeric quota or execution reset changed.

Both browser paths load once and dispatch one actual click. A retained branch
moves through a detached fragment, actual template content, an ordinary template
child and back into the visible pair. All 22 captured identities and total node
count remain stable, with no click-created nodes. The literal Alpha/Beta order
reverses, title/status and green/blue samples change, and independent full-canvas
references and nonempty glyph assertions pass. Comparisons themselves do not
mutate the tree or render the scene.

The release passes **32/32 new modes and 16/16 paired controls**, from the published
predecessor's 0/32 and 4/16. Among **4,364 established case rows and 524 controls**,
**4,362 and 520 remain byte-exact**. The only new changes are connected's two
complete-inventory Error failures and four unhealthy TypeError controls; all
thirty older unhealthy rows stay exact. Established healthy totals move from
4,268/504 to 4,266/500. The new pristine 30-key inventory and its same-mode
positive/wrong controls pass independently. Six historical job exits and the
aggregate retain exit one; comparison and classification exit zero. No raw
expectation, input or health flag is rewritten to hide those losses.

The first complete independent data-only audit clears with **378 bound inputs**,
no findings and unchanged pre/post hashes. Source preparation retained its
focused-summary schema correction and original reader before execution; no
complete audit failed. It reconstructs complete raw records and literal test
statuses, binds the actual baseline and final manifests, checks every correction,
and preserves all recorded command results.

The [summary](evidence/node-position.json) and [archive](evidence/node-position.tar.gz)
retain the exact source, release, raw observations, before images and audit
provenance. Release SHA-256 is
`f0b249ba7a726e943685315c95bb55b5ba8ca5e3add50051e1c6553bbcbb7007`;
final source-manifest SHA-256 is
`c6d4423dadf42a2812b69717fa86bb4ddae0543c9dd1b1caa092151b6c8f5377`.
These checks do not establish complete web compatibility, production security,
comprehensive verification or the Chromium performance requirement.

## Checked Node cloning and Object.hasOwn

[Node.cloneNode](node-clone.md) now copies selected non-Document graphs with fresh
identities, exact stored payloads and separate template content. Checked staging
precedes publication; ordinary Result refusals preserve the original document.
Document ownership, complete element-specific cloning state and inherited
allocator boundaries remain unfinished. The unchanged browser fixture exposed
missing `Object.hasOwn`, which this increment also implements for represented
own descriptors.

Rust 1.88 passes **2,004 default tests** and Rust 1.98 passes **2,127 native Vulkan
tests**, including confinement tests. Formatting, strict Clippy in both feature
configurations and release construction pass. The **66 new groups** comprise
49 cloning groups and 17 ownership groups. Fourteen successful focused commands
contain 420 observations across 407 unique names. Three failed test observations
and 109 passing observations in those failed commands remain retained; the
initial compiler error and a Cargo cache failure are recorded separately.

The release passes **34/34 clone modes with 16/16 controls**, and a separate
**16/16 ownership modes with 8/8 controls**. The established 4,396 cases and 540
controls retain 4,394 and 536 byte-exact rows. Only the six anticipated previous
prototype-inventory expectations change; all 36 older unhealthy rows remain
unchanged. Seven historical jobs retain exit one, while comparison and
classification pass. The page and worker witnesses preserve 20 original captured
identities, add exactly ten copies, and pass exact canvas and glyph checks.

The [summary](evidence/node-clone.json) and [archive](evidence/node-clone.tar.gz)
retain all attempts and source corrections. The new release SHA-256 is
`e77a1efcd0b08a2ac570d65e0d0a4579aa55b51f02a4c99188b6bbbf19e7310d`;
the final 31-path source manifest is
`76b82bdfc67a7bc28f364be0caa9cf13c9f8105a707e873fb95db389df018196`.
The [preceding position CI](evidence/node-position-ci.json) records nine
successful jobs. These results do not establish complete standards coverage,
production security or performance within 30% of Chromium.

The first complete independent result audit passes with 686 bound inputs and no
findings. It reconstructs the raw outcomes, source corrections and all recorded
commands, including failed attempts, and verifies unchanged input hashes.

## Complete pinned Object.hasOwn directory

The [new upstream profile](../tests/conformance/object-has-own.md) passes all
**124 modes from 62 unchanged sources**, with all **64 harness controls healthy**.
The actual release is the published cloning executable `e77a1efc…`; no Rust
source, executable or resource limit changed. The compact baseline and raw
report agree on every case and source fingerprint. CI now gates this profile.

All **394 Python tooling tests pass**, including ten new ownership regression
groups. The initial 261-test Test262-only run had three failures because old
fixed-population tests also included the new profile. Their corrections exclude
only this later profile and retain all historical counts and hash expectations.
The original failed run is retained with the successful full rerun in the
[evidence](evidence/object-has-own-upstream/index.json).

The 44 existing profiles' complete case, policy and control definitions remain
byte-identical: 19,727 case modes and 4,564 preflights. This is a data-only
contract comparison, not a fresh execution of those cases. The preceding
[cloning commit CI](evidence/node-clone-ci.json) passed all nine jobs.
No new Rust build, GPU rendering or Chromium performance comparison is claimed
for this validation-only increment. Full browser compatibility remains unfinished.
