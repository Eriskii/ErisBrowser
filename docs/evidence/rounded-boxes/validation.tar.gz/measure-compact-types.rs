extern crate eris;
use std::mem::size_of;
use std::sync::Arc;
use eris::graphics::{DrawCommand,Canvas,Rect};
use eris::graphics::box_decoration::{BoxDecoration,BoxPaint,RoundedBox};
fn main() {
    println!("DrawCommand={} Canvas={} Rect={} RoundedBox={} BoxPaint={} BoxDecoration={} ArcPointer={}", size_of::<DrawCommand>(),size_of::<Canvas>(),size_of::<Rect>(),size_of::<RoundedBox>(),size_of::<BoxPaint>(),size_of::<BoxDecoration>(),size_of::<Arc<BoxDecoration>>());
    assert_eq!(size_of::<DrawCommand>(),64);
}
