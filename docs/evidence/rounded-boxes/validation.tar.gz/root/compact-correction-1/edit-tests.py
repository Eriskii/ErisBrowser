from pathlib import Path
import re
w=Path('/tmp/eris-rounded-boxes-1/worktree')
for name in ['src/browser/box_decoration_tests.rs','src/browser/native_benchmark_identity/box_decoration_tests.rs','src/layout/box_decoration_tests.rs']:
 p=w/name;s=p.read_text();s=s.replace('::{BoxPaint, RoundedBox}','::{BoxDecoration, BoxPaint, RoundedBox}')
 if name.startswith('src/layout'):s+='\nuse std::sync::Arc;\n'
 changes=[];offset=0;needed=set()
 while True:
  start=s.find('DrawCommand::BoxDecoration {',offset)
  if start<0:break
  opening=s.index('{',start);depth=1;end=opening+1
  while depth:
   if s[end]=='{':depth+=1
   elif s[end]=='}':depth-=1
   end+=1
  body=s[opening:end];is_pattern=s[:start].rstrip().endswith('let')
  if is_pattern:
   tail=s[end:];m=re.match(r'\s*=\s*(.*?)\s+else\s*\{\s*panic!\(\)\s*\};',tail,re.S)
   assert m,(name,tail[:100]);expr=m[1].strip();helper='decoration_mut' if expr.startswith('&mut ') else 'unpack';needed.add(helper)
   replacement='BoxDecoration '+body+' = '+helper+'('+expr+')'
   if 'BoxPaint::' in body:replacement+=' else { panic!() }'
   replacement+=';';changes.append((start,end+m.end(),replacement));offset=end+m.end()
  else:
   changes.append((start,end,'DrawCommand::BoxDecoration(Arc::new(BoxDecoration '+body+'))'));offset=end
 for a,b,r in reversed(changes):s=s[:a]+r+s[b:]
 if 'unpack' in needed:s+='''
fn unpack(command: DrawCommand) -> BoxDecoration {
    let DrawCommand::BoxDecoration(payload) = command else { panic!() };
    Arc::unwrap_or_clone(payload)
}
'''
 if 'decoration_mut' in needed:s+='''
fn decoration_mut(command: &mut DrawCommand) -> &mut BoxDecoration {
    let DrawCommand::BoxDecoration(payload) = command else { panic!() };
    Arc::make_mut(payload)
}
'''
 p.write_text(s)
