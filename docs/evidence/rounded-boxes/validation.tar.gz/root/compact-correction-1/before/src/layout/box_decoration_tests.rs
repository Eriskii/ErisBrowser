use super::*;
use crate::graphics::box_decoration::{BoxPaint, RoundedBox};

fn command() -> DrawCommand {
    DrawCommand::BoxDecoration {
        shape: RoundedBox {
            rect: rect(1.0, 2.0, 8.0, 6.0),
            radii: [[1.0, 2.0]; 4],
        },
        cutout: Some(RoundedBox {
            rect: rect(2.0, 3.0, 4.0, 3.0),
            radii: [[0.0, 1.0]; 4],
        }),
        paint: BoxPaint::Image {
            tile: rect(-2.0, 0.5, 2.0, 1.0),
            repeat: [false, true],
            key: "tile".into(),
        },
    }
}

#[test]
fn box_decoration_translation_moves_outer_inner_and_sampling_phase() {
    let mut input = command();
    translate(&mut input, 3.0, -4.0);
    let DrawCommand::BoxDecoration {
        shape,
        cutout,
        paint: BoxPaint::Image { tile, repeat, key },
    } = input
    else {
        panic!()
    };
    assert_eq!(shape.rect, rect(4.0, -2.0, 8.0, 6.0));
    assert_eq!(shape.radii, [[1.0, 2.0]; 4]);
    assert_eq!(cutout.unwrap().rect, rect(5.0, -1.0, 4.0, 3.0));
    assert_eq!(tile, rect(1.0, -3.5, 2.0, 1.0));
    assert_eq!((repeat, key.as_str()), ([false, true], "tile"));
}

#[test]
fn box_decoration_unrepresentable_phase_is_omitted_without_clamping() {
    let mut input = command();
    translate(&mut input, 1_000_010.0, 0.0);
    let DrawCommand::BoxDecoration { shape, .. } = input else {
        panic!()
    };
    assert_eq!(shape.rect, Rect::default());
}

#[test]
fn box_decoration_translation_rejects_far_edge_overflow_atomically() {
    for move_inner in [false, true] {
        let mut input = command();
        let DrawCommand::BoxDecoration { shape, cutout, .. } = &mut input else {
            panic!()
        };
        let wide = Rect {
            x: 0.0,
            y: 0.0,
            width: 16_000_000.0,
            height: 1.0,
        };
        if move_inner {
            cutout.as_mut().unwrap().rect = wide;
        } else {
            shape.rect = wide;
        }
        let original_cutout = *cutout;
        translate(&mut input, 1.0, 0.0);
        let DrawCommand::BoxDecoration {
            shape,
            cutout,
            paint: BoxPaint::Image { tile, .. },
        } = input
        else {
            panic!()
        };
        assert_eq!(shape.rect, Rect::default());
        assert_eq!(cutout, original_cutout);
        assert_eq!(tile, rect(-2.0, 0.5, 2.0, 1.0));
        assert!(shape.valid());
        assert!(cutout.unwrap().valid());
    }
}
