from pathlib import Path
w=Path('/tmp/eris-rounded-boxes-1/worktree')
p=w/'src/browser.rs';s=p.read_text();s=s.replace('use eris::graphics::box_decoration::BoxPaint;','use eris::graphics::box_decoration::{BoxDecoration, BoxPaint};',1)
s=s.replace('''        DrawCommand::BoxDecoration {
            shape,
            cutout,
            paint,
        } => DrawCommand::BoxDecoration {
''','''        DrawCommand::BoxDecoration(decoration) => {
            let BoxDecoration { shape, cutout, paint } = decoration.as_ref();
            DrawCommand::BoxDecoration(Arc::new(BoxDecoration {
''',1)
s=s.replace('''        },
        DrawCommand::PushClip { rect: r } => DrawCommand::PushClip { rect: rect(r) },''','''            }))
        },
        DrawCommand::PushClip { rect: r } => DrawCommand::PushClip { rect: rect(r) },''',1);p.write_text(s)
p=w/'src/browser/native_scene.rs';s=p.read_text().replace('DrawCommand::BoxDecoration { .. }','DrawCommand::BoxDecoration(_)');p.write_text(s)
p=w/'src/browser/native_benchmark_identity.rs';s=p.read_text().replace('::{BoxPaint, RoundedBox}','::{BoxDecoration, BoxPaint, RoundedBox}').replace('DrawCommand::BoxDecoration { .. }','DrawCommand::BoxDecoration(_)')
s=s.replace('''            DrawCommand::BoxDecoration {
                shape,
                cutout,
                paint,
            } => {
''','''            DrawCommand::BoxDecoration(decoration) => {
                let BoxDecoration { shape, cutout, paint } = decoration.as_ref();
''',1);p.write_text(s)
p=w/'src/layout.rs';s=p.read_text().replace('''                        DrawCommand::BoxDecoration { shape, .. } => {
                            shape.rect.width > 0.0 && shape.rect.height > 0.0
                        }''','''                        DrawCommand::BoxDecoration(decoration) => {
                            decoration.shape.rect.width > 0.0 && decoration.shape.rect.height > 0.0
                        }''')
s=s.replace('''        DrawCommand::BoxDecoration {
            shape,
            cutout,
            paint,
        } => {
            use crate::graphics::box_decoration::BoxPaint;''','''        DrawCommand::BoxDecoration(decoration) => {
            use crate::graphics::box_decoration::{BoxDecoration, BoxPaint};
            let BoxDecoration { shape, cutout, paint } = std::sync::Arc::make_mut(decoration);''',1)
s=s.replace('''                DrawCommand::BoxDecoration {
                    shape,
                    cutout,
                    paint,
                } => {
                    use crate::graphics::box_decoration::BoxPaint;''','''                DrawCommand::BoxDecoration(decoration) => {
                    use crate::graphics::box_decoration::{BoxDecoration, BoxPaint};
                    let BoxDecoration { shape, cutout, paint } = decoration.as_ref();''',1);p.write_text(s)
p=w/'src/bin/eris-stress.rs';s=p.read_text().replace('''            DrawCommand::BoxDecoration {
                shape,
                cutout,
                paint,
            } => {
                use eris::graphics::box_decoration::BoxPaint;''','''            DrawCommand::BoxDecoration(decoration) => {
                use eris::graphics::box_decoration::{BoxDecoration, BoxPaint};
                let BoxDecoration { shape, cutout, paint } = decoration.as_ref();''',1);p.write_text(s)
for name in ['tools/vulkan-raster-probe/src/bin/worker-text-check.rs','tools/vulkan-raster-probe/src/bin/checker_support/mod.rs']:
 p=w/name;s=p.read_text().replace('DrawCommand::BoxDecoration { .. }','DrawCommand::BoxDecoration(_)');p.write_text(s)
p=w/'examples/rounded-boxes.rs';s=p.read_text().replace('::{BoxPaint, RoundedBox}','::{BoxDecoration, BoxPaint, RoundedBox}')
s=s.replace('commands.push(DrawCommand::BoxDecoration {','commands.push(DrawCommand::BoxDecoration(Arc::new(BoxDecoration {').replace('''            paint,
        });''','''            paint,
        })));''');p.write_text(s)
