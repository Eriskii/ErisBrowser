// Tag13 carries raw, unnormalized elliptical corners. Normalization is an
// explicit caller operation; the wire validates and preserves supplied values.
fn encode_rounded_box(e: &mut Encoder, shape: RoundedBox) {
    e.rect(shape.rect);
    for corner in shape.radii {
        e.f32(corner[0]);
        e.f32(corner[1]);
    }
}

fn decode_rounded_box(d: &mut Decoder<'_>) -> Result<RoundedBox> {
    let rect = d.rect()?;
    let mut radii = [[0.0; 2]; 4];
    for corner in &mut radii {
        corner[0] = d.f32()?;
        corner[1] = d.f32()?;
    }
    let shape = RoundedBox { rect, radii };
    if !shape.valid() {
        return Err("invalid IPC rounded box".into());
    }
    Ok(shape)
}

fn valid_box_tile(tile: Rect) -> bool {
    [tile.x, tile.y, tile.width, tile.height]
        .iter()
        .all(|value| value.is_finite() && value.abs() <= 16_000_000.0)
        && tile.width > 0.0
        && tile.height > 0.0
}

fn encode_box_decoration(
    e: &mut Encoder,
    shape: RoundedBox,
    cutout: Option<RoundedBox>,
    paint: &BoxPaint,
    keys: &mut usize,
    gradients: &mut usize,
) {
    if e.failed || !shape.valid() || cutout.is_some_and(|inner| !inner.valid()) {
        e.failed = true;
        return;
    }
    let valid_paint = match paint {
        BoxPaint::Color(_) => true,
        BoxPaint::Image { tile, .. } => valid_box_tile(*tile),
        BoxPaint::LinearGradient { tile, stop_scale, .. } => {
            valid_box_tile(*tile)
                && stop_scale.is_finite()
                && *stop_scale > 0.0
                && *stop_scale <= 16_000_000.0
        }
    };
    if !valid_paint {
        e.failed = true;
        return;
    }
    e.byte(13);
    encode_rounded_box(e, shape);
    e.boolean(cutout.is_some());
    if let Some(inner) = cutout {
        encode_rounded_box(e, inner);
    }
    match paint {
        BoxPaint::Color(color) => {
            e.byte(0);
            e.color(*color);
        }
        BoxPaint::Image { tile, repeat, key } => {
            e.byte(1);
            e.byte(u8::from(repeat[0]) | (u8::from(repeat[1]) << 1));
            e.rect(*tile);
            e.budget_string(key, keys);
        }
        BoxPaint::LinearGradient {
            tile,
            repeat,
            gradient,
            current_color,
            stop_scale,
        } => {
            e.byte(2);
            e.byte(u8::from(repeat[0]) | (u8::from(repeat[1]) << 1));
            e.rect(*tile);
            e.color(*current_color);
            e.f32(*stop_scale);
            encode_gradient(e, gradient, gradients);
        }
    }
}

fn decode_box_decoration(
    d: &mut Decoder<'_>,
    keys: &mut usize,
    gradients: &mut usize,
) -> Result<DrawCommand> {
    let shape = decode_rounded_box(d)?;
    let cutout = if d.boolean()? {
        Some(decode_rounded_box(d)?)
    } else {
        None
    };
    let paint = match d.byte()? {
        0 => BoxPaint::Color(d.color()?),
        kind @ (1 | 2) => {
            let flags = d.byte()?;
            if flags & !3 != 0 {
                return Err("unknown IPC box repeat flags".into());
            }
            let repeat = [flags & 1 != 0, flags & 2 != 0];
            let tile = d.rect()?;
            if !valid_box_tile(tile) {
                return Err("invalid IPC box paint tile".into());
            }
            if kind == 1 {
                // Missing keys stay opaque ImageStore references, never I/O.
                BoxPaint::Image { tile, repeat, key: d.budget_string(keys)? }
            } else {
                let current_color = d.color()?;
                let stop_scale = d.f32()?;
                if stop_scale <= 0.0 {
                    return Err("invalid IPC box gradient scale".into());
                }
                let gradient = decode_gradient(d, gradients)?;
                BoxPaint::LinearGradient { tile, repeat, gradient, current_color, stop_scale }
            }
        }
        _ => return Err("unknown IPC box paint subtype".into()),
    };
    Ok(DrawCommand::BoxDecoration { shape, cutout, paint })
}

