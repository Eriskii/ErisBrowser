"""Verify observed checkpoint receipts and package bounded local evidence."""
from pathlib import Path
import gzip,hashlib,io,json,re,subprocess,tarfile
P=Path(__file__).resolve().parent
W=P/'worktree'
D=W/'docs/evidence/rounded-boxes'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def bind(p):return {'path':str(p.relative_to(P)),'bytes':p.stat().st_size,'sha256':digest(p)}
def totals(t):
 rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',t)
 return {'rows':len(rows),'passed':sum(int(x[1]) for x in rows),'failed':sum(int(x[2]) for x in rows),'ignored':sum(int(x[3]) for x in rows)}
source=P/'compiled-source-3.json'
inputs=json.loads(source.read_text())['source_sha256']
assert len(inputs)==603
for name,sha in inputs.items():assert digest(W/name)==sha,name
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()=='b27341aea5600b451e2559a0bda9b28f75f10601'
assert not subprocess.check_output(['git','diff','HEAD','--','tests/reftests','crates/raster-core'],cwd=W)
final='deep-layout-3 focused-boxes-3 full-native-3 full-default-198-3 native-clippy-msrv-3 native-clippy-198-3 default-clippy-198-3 probe-clippy-msrv-3 probe-tests-msrv-3 bridge-list-3 bridge-roster-3 bridge-presenter-list-3 bridge-presenter-roster-3 root-format-check-3 probe-format-check-3 browser-build-3 browser-strip-3 example-render-3 reftests-final-3 compact-size-build-3 compact-size-3'.split()
checks={}
for p in sorted((P/'validation').glob('*.json')):
 r=json.loads(p.read_text())
 if not {'command','exit','log','sha256'}<=r.keys():continue
 log=p.parent/r['log'];assert digest(log)==r['sha256'],p
 item={'receipt':bind(p),'log':bind(log),'exit':r['exit'],'command':r['command']}
 t=totals(log.read_text())
 if t['rows']:item['rust']=t
 if p.stem in final:
  assert r['exit']==0,p
  item['compiled_source']=source.name
 checks[p.stem]=item
assert set(final)<=checks.keys()
for name,total in [('full-native-3',2755),('full-default-198-3',2517),('focused-boxes-3',44),('deep-layout-3',1),('probe-tests-msrv-3',15)]:
 assert checks[name]['rust']['passed']==total and checks[name]['rust']['failed']==0 and checks[name]['rust']['ignored']==0,name
for name,code in [('focused-boxes-1',101),('full-native-1',134),('full-default-198-1',134)]:assert checks[name]['exit']==code
report=P/'reftests-final-3/report.json';r=json.loads(report.read_text());assert r['passed']==76 and r['failed']==0 and r['total']==76
manifest=json.loads((W/'tests/reftests/manifest.json').read_text())
assert len(r['cases'])==len(manifest['cases'])==76
assert len({c['name'] for c in r['cases']})==76
assert {c['name'] for c in r['cases']}=={c['name'] for c in manifest['cases']}
assert all(c['status']=='pass' and c['different_pixels']==0 and c['maximum_channel_error']==0 for c in r['cases'])
assert r['binary']==str(P/'eris-browser-final-3')
assert checks['reftests-final-3']['command']==['python3','tools/reftest.py','--binary',r['binary'],'--output-dir',str(report.parent)]
for name,version,features in [('full-native-3','1.88.0',['--features','vulkan-raster']),('full-default-198-3','1.98.0',[])]:
 assert checks[name]['command']==['cargo','+'+version,'test','--locked','--offline','--manifest-path','Cargo.toml',*features,'--','--include-ignored','--test-threads=4']
for name,version,manifest_path,features in [('native-clippy-msrv-3','1.88.0','Cargo.toml',['--features','vulkan-raster']),('native-clippy-198-3','1.98.0','Cargo.toml',['--features','vulkan-raster']),('default-clippy-198-3','1.98.0','Cargo.toml',[]),('probe-clippy-msrv-3','1.88.0','tools/vulkan-raster-probe/Cargo.toml',['--features','browser-bridge'])]:
 assert checks[name]['command']==['cargo','+'+version,'clippy','--locked','--offline','--manifest-path',manifest_path,*features,'--all-targets','--','-D','warnings']
browser=json.loads((P/'browser-final-3.json').read_text());assert digest(Path(browser['path']))==browser['sha256']
assert browser['path']==r['binary'] and browser['bytes']==Path(browser['path']).stat().st_size
assert browser['source']==source.name and browser['source_sha256']==digest(source)
assert browser['build_receipt']=='validation/browser-build-3.json'
assert checks['browser-build-3']['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--features','vulkan-raster','--bin','eris-browser']
assert (P/'validation/compact-size-3.log').read_text().strip()=='DrawCommand=64 Canvas=232 Rect=16 RoundedBox=48 BoxPaint=48 BoxDecoration=152 ArcPointer=8'
assert (P/'validation/parent-size-1.log').read_text().strip()=='DrawCommand=64 Canvas=136 Rect=16'
assert (P/'validation/candidate-size-1.log').read_text().strip()=='DrawCommand=152 Canvas=232 Rect=16'
docs=json.loads((P/'docs/source-ready-3.json').read_text())
assert {v['relative'] for v in docs['published_files']}=={'README.md','docs/SECURITY.md','docs/rounded-boxes.md'}
for v in docs['published_files']:assert digest(W/v['relative'])==digest(Path(v['path']))==v['sha256']
reviews=['graphics/layout-review-2.json','codec/root-review-3.json','adapter/root-review-3.json','root/script-review-3.json','security-review-3.json','example-visual-review-3.json']
for name in reviews:assert (P/name).is_file()
summary={'base':'b27341aea5600b451e2559a0bda9b28f75f10601','scope':'Software rounded-box decoration foundation; no new CSS property acceptance or layout emission; no new GPU lowering or timing result.','compiled_source':bind(source),'source_count':len(inputs),'checks':checks,'final_checks':final,'browser':browser,'reftests':bind(report),'reviews':[bind(P/n) for n in reviews],'sizes_x86_64':{'DrawCommand_parent':64,'DrawCommand_initial':152,'DrawCommand_final':64,'Canvas_parent':136,'Canvas_final':232,'BoxDecoration_payload':152,'Arc_pointer':8,'Arc_count_words':16},'corrections':['Initial focused fixture used a helper that clamped width; corrected to a literal Rect before the intended boundary could be tested.','Initial inline enum payload expanded DrawCommand64 to152 and caused existing deep-layout stack-overflow aborts in both full suites. Arc payload restores64; exact regression and both suites pass. No stack or quota increase.'],'limits':['Self-authored tests do not establish complete web compatibility or security.','The unchanged GPU core and shaders were not reexecuted on hardware for this software-only addition.','Size measurements exclude allocator bookkeeping; work units are bounded geometry queries, not CPU instructions.']}
files=set()
for dirname in ['graphics','codec','adapter','root','docs','validation','reftests-final-3']:
 for p in (P/dirname).rglob('*'):
  if p.is_file() and p.suffix not in ['.pyc']:files.add(p)
for pattern in ['*.py','*.json','*.rs','*.png']:
 files.update(P.glob(pattern))
files={p for p in files if p.is_file()}
assert all(p==p.resolve() and not p.is_symlink() for p in files)
assert sum(p.stat().st_size for p in files)<64*1024*1024
for p in files:
 assert not any(part.startswith('target') for part in p.relative_to(P).parts)
 assert p.suffix not in ['.gz','.zip','.tar','.rlib','.so']
 with p.open('rb') as f:assert f.read(4)!=b'\x7fELF'

D.mkdir(parents=True,exist_ok=True)
archive=D/'validation.tar.gz';assert not archive.exists()
raw=io.BytesIO()
with tarfile.open(fileobj=raw,mode='w',format=tarfile.PAX_FORMAT) as tar:
 for p in sorted(files):
  data=p.read_bytes();info=tarfile.TarInfo(str(p.relative_to(P)));info.size=len(data);info.mode=0o644;info.mtime=0
  tar.addfile(info,io.BytesIO(data))
with archive.open('xb') as f:f.write(gzip.compress(raw.getvalue(),compresslevel=9,mtime=0))
summary['archive']={'path':'validation.tar.gz','bytes':archive.stat().st_size,'sha256':digest(archive),'members':len(files)}
summary['archive_inputs']=[bind(p) for p in sorted(files)]
summary['published_document_sha256']={n:digest(W/n) for n in ['README.md','docs/SECURITY.md','docs/rounded-boxes.md']}
with (D/'summary.json').open('x') as f:json.dump(summary,f,indent=2);f.write('\n')
with tarfile.open(archive,'r:gz') as tar:
 assert len(tar.getmembers())==len(files)
 for member in tar.getmembers():assert hashlib.sha256(tar.extractfile(member).read()).hexdigest()==digest(P/member.name)
print(json.dumps({'archive':summary['archive'],'summary_sha256':digest(D/'summary.json'),'inputs':len(inputs),'final_checks':len(final)},indent=2))
