#[cfg(test)]
mod tests {
    use super::*;
    use crate::graphics::{DrawCommand, Fonts, PaintBudget, RasterImage};
    use crate::graphics::gradient::{GradientColor, GradientDirection, GradientStop};

    fn rect(x: f32, y: f32, width: f32, height: f32) -> Rect {
        Rect { x, y, width, height }
    }
    fn shape(rect: Rect, radii: [[f32; 2]; 4]) -> RoundedBox {
        RoundedBox { rect, radii }
    }
    fn square(rect: Rect) -> RoundedBox { shape(rect, [[0.0; 2]; 4]) }
    fn solid(shape: RoundedBox, color: Color) -> DrawCommand {
        DrawCommand::BoxDecoration { shape, cutout: None, paint: BoxPaint::Color(color) }
    }
    fn constant_gradient(color: Color) -> Arc<LinearGradient> {
        Arc::new(LinearGradient {
            direction: GradientDirection::Angle(90.0),
            stops: Arc::from([GradientStop { color: GradientColor::Color(color), position: None }]),
        })
    }
    fn paint(width: u32, height: u32, commands: &[DrawCommand], images: &ImageStore) -> Canvas {
        let mut canvas = Canvas::new(width, height).unwrap();
        canvas.paint(commands, &Fonts::new(), images, 0.0, 0.0);
        assert!(!canvas.exhausted());
        assert!(canvas.box_mask.is_none());
        canvas
    }

    #[test]
    fn geometry_validation_is_finite_bounded_and_allows_empty_shapes() {
        let valid = square(rect(-16_000_000.0, 0.0, 16_000_000.0, 0.0));
        assert!(valid.valid());
        for bad in [
            square(rect(16_000_000.0, 0.0, 1.0, 1.0)),
            square(rect(0.0, 0.0, -1.0, 1.0)),
            square(rect(f32::NAN, 0.0, 1.0, 1.0)),
            shape(rect(0.0, 0.0, 1.0, 1.0), [[f32::INFINITY, 1.0]; 4]),
            shape(rect(0.0, 0.0, 1.0, 1.0), [[-1.0, 1.0]; 4]),
            shape(rect(0.0, 0.0, 1.0, 1.0), [[16_000_002.0, 1.0]; 4]),
        ] { assert!(!bad.valid()); assert!(bad.normalized().is_none()); }
    }

    #[test]
    fn overlap_normalization_uses_one_factor_and_zero_axis_is_square() {
        let source = shape(rect(0.0, 0.0, 12.0, 8.0), [[8.0, 6.0]; 4]);
        assert_eq!(source.normalized().unwrap().radii, [[16.0 / 3.0, 4.0]; 4]);
        let zero = shape(rect(0.0, 0.0, 10.0, 10.0), [[100.0, 0.0], [1.0, 1.0], [0.0, 0.0], [0.0, 0.0]]);
        assert_eq!(zero.normalized().unwrap().radii, [[0.0, 0.0], [10.0 / 101.0, 10.0 / 101.0], [0.0, 0.0], [0.0, 0.0]]);
        assert_eq!(square(rect(0.0, 0.0, 0.0, 0.0)).normalized().unwrap().radii, [[0.0; 2]; 4]);
    }

    #[test]
    fn asymmetric_insets_keep_truncated_inner_ellipses() {
        let outer = shape(rect(0.0, 0.0, 20.0, 16.0), [[6.0; 2]; 4]);
        let padding = outer.inset([1.0, 2.0, 3.0, 4.0]).unwrap();
        assert_eq!(padding.rect, rect(4.0, 1.0, 14.0, 12.0));
        assert_eq!(padding.radii, [[2.0, 5.0], [4.0, 5.0], [4.0, 3.0], [2.0, 3.0]]);
        let narrow = shape(rect(0.0, 0.0, 10.0, 10.0), [[5.0; 2]; 4]).inset([0.0, 9.0, 0.0, 0.0]).unwrap();
        assert_eq!(narrow.rect, rect(0.0, 0.0, 1.0, 10.0));
        assert_eq!(narrow.radii, [[5.0, 5.0], [0.0, 5.0], [0.0, 5.0], [5.0, 5.0]]);
        assert!(!narrow.contains(0.5, 0.5));
        assert!(narrow.contains(0.5, 4.5));
        assert!(outer.inset([-1.0, 0.0, 0.0, 0.0]).is_none());
        assert!(outer.inset([f32::NAN, 0.0, 0.0, 0.0]).is_none());
    }

    #[test]
    fn translate_and_scale_preserve_corner_order_and_do_not_normalize() {
        let source = shape(rect(1.0, 2.0, 3.0, 4.0), [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0], [7.0, 8.0]]);
        assert_eq!(source.translated(-2.0, 3.0).rect, rect(-1.0, 5.0, 3.0, 4.0));
        assert_eq!(source.translated(-2.0, 3.0).radii, source.radii);
        let scaled = source.scaled(2.0);
        assert_eq!(scaled.rect, rect(2.0, 4.0, 6.0, 8.0));
        assert_eq!(scaled.radii, [[2.0, 4.0], [6.0, 8.0], [10.0, 12.0], [14.0, 16.0]]);
        assert!(!source.translated(f32::INFINITY, 0.0).valid());
        assert!(!source.scaled(-1.0).valid());
    }

    #[test]
    fn four_by_four_ellipse_and_circle_counts_are_literal() {
        let ellipse = shape(rect(0.0, 0.0, 4.0, 2.0), [[2.0, 1.0]; 4]);
        let canvas = paint(4, 2, &[solid(ellipse, Color::BLACK)], &ImageStore::new());
        assert_eq!(canvas.pixels, [0x707070, 0, 0, 0x707070, 0x707070, 0, 0, 0x707070]);
        let circle = shape(rect(0.0, 0.0, 4.0, 4.0), [[1.0, 1.0]; 4]);
        let canvas = paint(4, 4, &[solid(circle, Color::BLACK)], &ImageStore::new());
        assert_eq!(canvas.pixels, [0x303030, 0, 0, 0x303030, 0, 0, 0, 0, 0, 0, 0, 0, 0x303030, 0, 0, 0x303030]);
    }

    #[test]
    fn fractional_rect_and_correlated_cutout_use_the_same_sample_grid() {
        let fractional = square(rect(0.25, 0.25, 1.0, 1.0));
        let canvas = paint(2, 2, &[solid(fractional, Color::BLACK)], &ImageStore::new());
        assert_eq!(canvas.pixels, [0x707070, 0xd0d0d0, 0xd0d0d0, 0xf0f0f0]);
        let ring = DrawCommand::BoxDecoration { shape: square(rect(0.0, 0.0, 2.0, 2.0)), cutout: Some(fractional), paint: BoxPaint::Color(Color::BLACK) };
        assert_eq!(paint(2, 2, &[ring], &ImageStore::new()).pixels, [0x909090, 0x303030, 0x303030, 0x101010]);
        let empty_ring = DrawCommand::BoxDecoration { shape: fractional, cutout: Some(fractional), paint: BoxPaint::Color(Color::BLACK) };
        assert_eq!(paint(2, 2, &[empty_ring], &ImageStore::new()).pixels, [0xffffff; 4]);
    }

    #[test]
    fn color_raster_and_gradient_share_the_literal_elliptical_outline() {
        let shape = shape(rect(0.0, 0.0, 4.0, 2.0), [[2.0, 1.0]; 4]);
        let mut images = ImageStore::new();
        images.insert("black".into(), Arc::new(RasterImage { width: 1, height: 1, rgba: vec![0, 0, 0, 255] }));
        for source in [
            BoxPaint::Color(Color::BLACK),
            BoxPaint::Image { tile: rect(0.0, 0.0, 1.0, 1.0), repeat: [true, true], key: "black".into() },
            BoxPaint::LinearGradient { tile: rect(0.0, 0.0, 1.0, 1.0), repeat: [true, true], gradient: constant_gradient(Color::BLACK), current_color: Color::BLACK, stop_scale: 1.0 },
        ] {
            let command = DrawCommand::BoxDecoration { shape, cutout: None, paint: source };
            assert_eq!(paint(4, 2, &[command], &images).pixels, [0x707070, 0, 0, 0x707070, 0x707070, 0, 0, 0x707070]);
        }
    }

    #[test]
    fn image_sampling_and_nonrepeat_holes_remain_center_based() {
        let mut images = ImageStore::new();
        images.insert("rb".into(), Arc::new(RasterImage { width: 2, height: 1, rgba: vec![255, 0, 0, 255, 0, 0, 255, 255] }));
        for (repeat, expected) in [([false, false], [0xff0000, 0x0000ff, 0xffffff, 0xffffff]), ([true, false], [0xff0000, 0x0000ff, 0xff0000, 0x0000ff])] {
            let command = DrawCommand::BoxDecoration { shape: square(rect(0.0, 0.0, 4.0, 1.0)), cutout: None, paint: BoxPaint::Image { tile: rect(0.25, 0.0, 2.0, 1.0), repeat, key: "rb".into() } };
            assert_eq!(paint(4, 1, &[command], &images).pixels, expected);
        }
    }

    #[test]
    fn alpha_and_nested_groups_apply_shape_coverage_once() {
        let ellipse = shape(rect(0.0, 0.0, 4.0, 2.0), [[2.0, 1.0]; 4]);
        assert_eq!(paint(4, 2, &[solid(ellipse, Color::rgba(255, 0, 0, 128))], &ImageStore::new()).pixels,
            [0xffb8b8, 0xff7f7f, 0xff7f7f, 0xffb8b8, 0xffb8b8, 0xff7f7f, 0xff7f7f, 0xffb8b8]);
        let canvas = paint(4, 2, &[DrawCommand::PushOpacity { opacity: 0.5 }, DrawCommand::PushOpacity { opacity: 0.5 }, solid(ellipse, Color::rgb(255, 0, 0)), DrawCommand::PopOpacity, DrawCommand::PopOpacity], &ImageStore::new());
        assert_eq!(canvas.pixels, [0xffdbdb, 0xffbfbf, 0xffbfbf, 0xffdbdb, 0xffdbdb, 0xffbfbf, 0xffbfbf, 0xffdbdb]);
    }

    #[test]
    fn fixed_clip_restoration_and_following_primitive_do_not_reuse_mask() {
        let mut canvas = Canvas::new(4, 2).unwrap();
        canvas.paint_with_viewport(&[
            DrawCommand::PushClip { rect: rect(0.0, 0.0, 1.0, 1.0) },
            solid(square(rect(0.0, 0.0, 2.0, 1.0)), Color::rgb(255, 0, 0)),
            DrawCommand::PushFixed,
            solid(square(rect(3.0, 0.0, 1.0, 1.0)), Color::rgb(0, 0, 255)),
            DrawCommand::PopFixed, DrawCommand::PopClip,
            DrawCommand::Rect { rect: rect(0.0, 1.0, 1.0, 1.0), color: Color::BLACK, radius: 0.0 },
        ], &Fonts::new(), &ImageStore::new(), (1.0, 0.0), (0.0, 0.0));
        assert_eq!(canvas.pixels, [0xffffff, 0xff0000, 0xffffff, 0x0000ff, 0xffffff, 0, 0xffffff, 0xffffff]);
        assert!(canvas.box_mask.is_none());
        assert!(!canvas.exhausted());
    }

    #[test]
    fn classifier_and_sample_fees_are_prepaid_at_literal_boundaries() {
        let shape = square(rect(0.25, 0.25, 0.5, 0.5));
        for allowance in [0, 8, 9, 25, 26, 27] {
            let mut canvas = Canvas::new(1, 1).unwrap();
            canvas.budget = Some(PaintBudget { pixels: allowance, glyphs: 0 });
            canvas.box_decoration(shape, None, &BoxPaint::Color(Color::BLACK), &ImageStore::new());
            assert_eq!(canvas.pixels, [if allowance == 27 { 0xc0c0c0 } else { 0xffffff }]);
            assert_eq!(canvas.exhausted(), allowance != 27);
            assert_eq!(canvas.budget.as_ref().unwrap().pixels, 0);
            assert!(canvas.box_mask.is_none());
        }
        let mut canvas = Canvas::new(1, 1).unwrap();
        canvas.budget = Some(PaintBudget { pixels: 11, glyphs: 0 });
        canvas.box_decoration(square(rect(0.0, 0.0, 1.0, 1.0)), None, &BoxPaint::Color(Color::BLACK), &ImageStore::new());
        assert_eq!(canvas.pixels, [0]);
        assert_eq!(canvas.budget.as_ref().unwrap().pixels, 0);
        assert!(!canvas.exhausted());
    }

    #[test]
    fn empty_missing_transparent_and_suppressed_commands_leave_no_mask_or_layer() {
        let images = ImageStore::new();
        let shape = square(rect(0.0, 0.0, 2.0, 2.0));
        let missing = DrawCommand::BoxDecoration { shape, cutout: None, paint: BoxPaint::Image { tile: shape.rect, repeat: [true, true], key: "missing".into() } };
        let canvas = paint(2, 2, &[
            solid(square(rect(0.0, 0.0, 0.0, 2.0)), Color::BLACK),
            solid(shape, Color::TRANSPARENT), missing,
            DrawCommand::PushOpacity { opacity: 0.0 }, solid(shape, Color::BLACK), DrawCommand::PopOpacity,
        ], &images);
        assert_eq!(canvas.pixels, [0xffffff; 4]);
        assert_eq!(canvas.layer_allocated, 0);
        assert!(canvas.layers.is_empty());
    }

    #[test]
    fn arbitrary_overlapping_corner_constraints_are_all_applied() {
        let overlapping = shape(rect(0.0, 0.0, 2.0, 2.0), [[4.0, 4.0]; 4]);
        assert!(overlapping.valid());
        assert!(!overlapping.contains(0.5, 0.5));
        assert!(!overlapping.contains(1.5, 1.5));
        assert_eq!(paint(2, 2, &[solid(overlapping, Color::BLACK)], &ImageStore::new()).pixels, [0xffffff; 4]);
    }
}
