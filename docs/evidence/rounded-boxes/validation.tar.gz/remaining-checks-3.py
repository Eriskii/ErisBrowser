import subprocess,sys
from pathlib import Path
p=Path(__file__).resolve().parent
v=sys.argv[1]
if v=='msrv':
 checks=[
 ('check','probe-clippy-msrv-3','1.88.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','clippy','--all-targets','--','-D','warnings'),
 ('check','probe-tests-msrv-3','1.88.0','tools/vulkan-raster-probe/Cargo.toml','browser-bridge','test','--all-targets','--','--include-ignored','--test-threads=4'),
 ('check','browser-build-3','1.88.0','Cargo.toml','vulkan-raster','build','--bin','eris-browser'),
 ('check','example-render-3','1.88.0','Cargo.toml','vulkan-raster','run','--example','rounded-boxes','--',str(p/'rounded-boxes.png')),
 ]
else:
 checks=[
 ('check','bridge-list-3','1.98.0','Cargo.toml','raster-bridge','test','--lib','graphics::raster_bridge::','--','--list'),
 ('tool','bridge-roster-3','python3',str(p/'check-bridge-roster.py'),str(p/'validation/bridge-list-3.log')),
 ('check','bridge-presenter-list-3','1.98.0','Cargo.toml','raster-bridge,vulkan-presenter','test','--lib','graphics::raster_bridge::','--','--list'),
 ('tool','bridge-presenter-roster-3','python3',str(p/'check-bridge-roster.py'),str(p/'validation/bridge-presenter-list-3.log')),
 ('tool','root-format-check-3','env','CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.98.0','fmt','--all','--check'),
 ('tool','probe-format-check-3','env','CARGO_HOME=/tmp/eris-vulkan-browser-cargo-home','RUSTUP_HOME=/tmp/eris-vulkan-rustup','cargo','+1.98.0','fmt','--manifest-path','tools/vulkan-raster-probe/Cargo.toml','--all','--check'),
 ]
for kind,*args in checks:
 r=subprocess.run(['python3',str(p/f'run-{kind}.py'),*args],cwd=p/'worktree',close_fds=True)
 if r.returncode:raise SystemExit(r.returncode)
