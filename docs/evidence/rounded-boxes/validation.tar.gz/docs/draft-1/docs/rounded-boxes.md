# Rounded box decorations

`DrawCommand::BoxDecoration` adds one self-contained software painting command:
an outer elliptical shape, an optional cutout, and a color, linear gradient or
already decoded image. It supplies geometry needed for future background-box
work. This checkpoint adds no CSS `background-origin` or `background-clip`
acceptance or layout emission of the command.

Run the direct example from the repository root:

```sh
cargo run --example rounded-boxes -- OUTPUT.png
```

It renders a fill, an unequal-width border ring, a repeated raster and a gradient.
The command itself performs no fetching, URL resolution or image decoding.

`RoundedBox` stores a rectangle and four `(x, y)` radius pairs in top-left,
top-right, bottom-right, bottom-left order. `valid()` accepts finite used
geometry: raw coordinates and endpoints are bounded to ±16,000,000, while
sizes and radii are nonnegative. Zero-size shapes are inert. Painting consumes
the supplied radii directly, including truncated inner arcs, and checks every
applicable corner constraint.

Outer preparation is explicit. `normalized()` applies one common overlap
factor using all original radii, then makes zero-axis corners square.
`inset([top, right, bottom, left])` normalizes its outer input and subtracts the
adjacent side thicknesses from each radius, floored at zero. For a content
shape, combine border and padding insets before calling it once; repeatedly
insetting would renormalize an already truncated inner curve. The geometry
follows [CSS Backgrounds §4.2](https://drafts.csswg.org/css-backgrounds-3/#corner-shaping)
and the [overlap rule in §4.5](https://drafts.csswg.org/css-backgrounds-3/#corner-overlap).
This helper is not complete CSS border or background support.

Coverage uses a fixed 4×4 grid at offsets `0.125`, `0.375`, `0.625` and `0.875`
on each pixel axis. Its byte value is `floor(255 * hits / 16)`. For a ring,
each sample must be inside the outer shape and outside the cutout; two
independently rounded masks are never multiplied. This is the new command's
rasterization contract, not a CSS-mandated antialiasing algorithm. Existing
primitive coverage and image sampling remain unchanged.

The painter uses no mask or tile bitmap. Conservative classification identifies
full interior/exterior pixels; ambiguous pixels use the sixteen samples. For
`P` candidate pixels, `A` ambiguous pixels and `S` shapes (one outer, or two
with a cutout), mask work is `8 + 2*P*S + 16*A*S`. One unit represents a
fixed, bounded geometry query, not a CPU instruction. The first classification
pass and remaining mask work are prepaid separately, before painting; the
candidate window can include transparent or nonrepeated holes. Existing
primitive costs and opacity allocation/composition limits apply additionally.
The per-command mask is cleared on completion or refusal and is not reapplied
when opacity groups composite. Fixed-coordinate scopes keep their established
clip restoration.

Worker tag 13 carries validated geometry and paint data, sharing existing
image-key and gradient-stop counters. Old valid command encodings remain
unchanged. Primitive, text and Native bridges refuse the complete frame before
payload preparation, after their earlier cheap guards; browser zoom preserves
that fallback. This checkpoint adds no GPU lowering, hardware result or timing
claim. Representation-size measurements and validation results are pending.
