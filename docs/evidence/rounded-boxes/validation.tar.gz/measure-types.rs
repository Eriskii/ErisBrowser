extern crate eris;
fn main() {
    println!("DrawCommand={} Canvas={} Rect={}", std::mem::size_of::<eris::graphics::DrawCommand>(), std::mem::size_of::<eris::graphics::Canvas>(), std::mem::size_of::<eris::graphics::Rect>());
}
