from pathlib import Path
import hashlib, importlib.util, json, sys
sys.dont_write_bytecode = True
U=Path('/tmp/eris-native-box-gradient-1')
T=Path('/tmp/eris-native-box-image-1')
spec=importlib.util.spec_from_file_location('eris_reftest', U/'worktree/tools/reftest.py')
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
def bind(p):
    return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
a=json.loads((T/'reftests-final-1/report.json').read_text())
b=json.loads((U/'reftests-final-1/report.json').read_text())
assert (a['passed'],a['failed'],a['total']) == (b['passed'],b['failed'],b['total']) == (90,0,90)
aa={c['name']:c for c in a['cases']}; bb={c['name']:c for c in b['cases']}
assert len(aa)==len(bb)==90 and aa.keys()==bb.keys()
rows=[]
for name in sorted(aa):
    for field in ['test_image','reference_image']:
        old=Path(aa[name][field]); new=Path(bb[name][field])
        op=m.decode_png(old); np=m.decode_png(new)
        assert op==np,(name,field)
        rows.append({'case':name,'side':field,'width':op[0],'height':op[1], 'decoded_sha256':hashlib.sha256(op[2]).hexdigest(),'old':bind(old),'new':bind(new),'encoded_equal':old.read_bytes()==new.read_bytes()})
report={'status':'clear','parent_report':bind(T/'reftests-final-1/report.json'),'candidate_report':bind(U/'reftests-final-1/report.json'),'decoded_equal':True,'frames':len(rows),'all_encoded_equal':all(r['encoded_equal'] for r in rows),'inputs':rows}
with (U/'root/parent-image-comparison-1.json').open('x') as f: json.dump(report,f,indent=2); f.write('\n')
print(json.dumps({k:v for k,v in report.items() if k!='inputs'}))
