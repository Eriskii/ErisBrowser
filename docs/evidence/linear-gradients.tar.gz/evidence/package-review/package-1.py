#!/usr/bin/env python3
"""Package explicitly selected evidence, rejecting changed or oversized inputs."""
from pathlib import Path, PurePosixPath
import hashlib, json, gzip, io, tarfile, subprocess, sys
P=Path(__file__).resolve().parent
W=P/'worktree'
Q=Path('/tmp/eris-linear-gradient-preparation-1')
BASE='530022279229c7fa7c1cd497929c07f36e712797'
STEM='linear-gradients'
def sha(data):return hashlib.sha256(data).hexdigest()
def encoded(value):return (json.dumps(value,indent=2,sort_keys=True)+'\n').encode()
def require(value,message):
 if not value:raise ValueError(message)
def binding(path):
 path=Path(path);require(path.is_absolute() and path.is_file(),'regular absolute file required')
 require(not any(p.is_symlink() for p in (path,*path.parents)),'symlink input')
 data=path.read_bytes();return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
def read(row):
 require(binding(row['path'])==row,'input binding changed: '+row['path'])
 return Path(row['path']).read_bytes()
def git(*args):return subprocess.check_output(['git','-C',str(W),*args]).decode()
def main():
 selected=binding(sys.argv[1]);selection=json.loads(read(selected))
 require(git('rev-parse','HEAD').strip()==BASE,'unexpected base')
 inventory=json.loads(read(selection['live_source']))
 require(inventory['base']==BASE,'source base')
 for name,digest in inventory['source_sha256'].items():
  require(not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts,'source path')
  require(sha((W/name).read_bytes())==digest,'live source changed: '+name)
 changed=set(git('diff','HEAD','--name-only','-z').split('\0'))|set(git('ls-files','--others','--exclude-standard','-z').split('\0'))
 require(changed-{''}==set(selection['published']),'published roster differs from worktree')
 for name,row in selection['published'].items():
  require(row['path']==str(W/name),'published path')
  read(row)
  if not name.endswith('.md'):require(inventory['source_sha256'].get(name)==row['sha256'],'unbound runtime input: '+name)
 receipts={}
 for label,item in selection['checks'].items():
  receipt=json.loads(read(item['receipt']));log=read(item['log'])
  require(receipt['sha256']==sha(log) and receipt['exit']==item['expected_exit'],'check mismatch: '+label)
  receipts[label]=receipt
 for label,count in selection['full_suites'].items():
  import re
  log=read(selection['checks'][label]['log']).decode()
  rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log)
  require(receipts[label]['exit']==0 and len(rows)==28,'incomplete suite')
  require(sum(int(r[1]) for r in rows)==count and all(r[0]=='ok' and r[2]=='0' and r[3]=='0' for r in rows),'suite counts')
 for label,item in selection['reports'].items():
  report=json.loads(read(item['report']));manifest=json.loads(read(item['manifest']))
  require(report['suite']=='eris-self-authored-reftests' and report['conformance_claim'] is False,'reference scope')
  require((report['passed'],report['failed'],report['total'])==tuple(item['counts']),'reference counts')
  require([r['name'] for r in report['cases']]==[r['name'] for r in manifest['cases']],'reference roster')
  require(report['total']==len(manifest['cases']),'reference population')
 candidate=json.loads(read(selection['candidate']))
 require(binding(candidate['path'])=={k:candidate[k] for k in ('path','bytes','sha256')},'candidate binary')
 require(candidate['source_sha256']==selection['live_source']['sha256'],'candidate source')
 require(candidate['build_receipt']==selection['checks']['candidate-browser-build-2']['receipt']['path'],'candidate build')
 members={}
 def add(row):
  path=Path(row['path']);require(row['bytes']<=8*1024*1024,'oversized archive member')
  require(not any(x in ('.git','__pycache__') or x.startswith('target-') for x in path.parts),'excluded archive tree')
  data=read(row);require(not data.startswith((b'\x7fELF',b'\x1f\x8b',b'PK\x03\x04')) and data[257:262]!=b'ustar','binary/recursive archive')
  for root,prefix in [(W,'worktree'),(P,'evidence'),(Q,'preparation')]:
   if path.is_relative_to(root):name=prefix+'/'+path.relative_to(root).as_posix();break
  else:raise ValueError('unlisted archive root: '+str(path))
  require(name not in members or members[name]==data,'archive collision');members[name]=data
 add(selected);add(binding(__file__))
 for row in selection['archive_inputs']:add(row)
 for row in selection['published'].values():add(row)
 manifest={name:{'bytes':len(data),'sha256':sha(data)} for name,data in members.items()}
 members['MANIFEST.json']=encoded(manifest)
 stream=io.BytesIO()
 with gzip.GzipFile(fileobj=stream,mode='wb',mtime=0) as compressed:
  with tarfile.open(fileobj=compressed,mode='w') as tar:
   for name,data in sorted(members.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;tar.addfile(info,io.BytesIO(data))
 archive=stream.getvalue();out=W/'docs/evidence';out.mkdir(exist_ok=True)
 for suffix in ['.json','.tar.gz']:require(not (out/(STEM+suffix)).exists(),'exclusive output already exists')
 (out/(STEM+'.tar.gz')).write_bytes(archive)
 summary={**selection['summary'],'base':BASE,'live_source':selection['live_source'],'source_count':len(inventory['source_sha256']),'candidate':candidate,'checks':selection['checks'],'reports':selection['reports'],'published':{name:{k:row[k] for k in ('bytes','sha256')} for name,row in selection['published'].items()},'archive':{'path':STEM+'.tar.gz','bytes':len(archive),'sha256':sha(archive),'members':len(members)}}
 (out/(STEM+'.json')).write_bytes(encoded(summary))
 print(json.dumps({'archive':summary['archive'],'published_files':len(selection['published']),'check_count':len(selection['checks'])},indent=2))
if __name__=='__main__':main()
