from pathlib import Path
w=Path('/tmp/eris-linear-gradient-1/worktree')
p=w/'src/css.rs';s=p.read_text()
def replace(a,b,count=1):
 global s
 assert s.count(a)>=count,a[:120]
 s=s.replace(a,b,count)
replace('use crate::graphics::Color;','use crate::graphics::{Color, gradient::LinearGradient};\nmod gradient;')
replace('    pub background_color: Color,','    pub background_color: Color,\n    pub background_image: Option<Arc<LinearGradient>>,')
replace('            background_color: Color::TRANSPARENT,','            background_color: Color::TRANSPARENT,\n            background_image: None,')
replace('"background" => &["background-color"],','"background" => &["background-color", "background-image"],')
replace('    "background-color",\n    "font-size",','    "background-color",\n    "background-image",\n    "font-size",')
replace('        "background-color" => s.background_color = p.background_color,','        "background-color" => s.background_color = p.background_color,\n        "background-image" => s.background_image = p.background_image.clone(),')
replace('    let mut grid_tracks = GridTrackPool::default();','    let mut grid_tracks = GridTrackPool::default();\n    let mut gradients = gradient::GradientPool::default();')
replace('''                if name != "font-size" && name != "color" {
                    apply_property(''','''                if name == "background-image" && !css_wide(value) {
                    // Parse and admit immutable storage before publishing the
                    // computed image. Refusal leaves the initial none value.
                    style.background_image = match gradient::parse_image(
                        value, [style.font_size, root_font, width, height], &mut work,
                    ) {
                        Ok(Some(gradient::ParsedImage::Gradient(parsed))) =>
                            gradients.intern(&parsed, &mut work).ok().flatten(),
                        _ => None,
                    };
                } else if name != "font-size" && name != "color" {
                    apply_property(''')
replace('''        expand_declaration(&name, value, important, &mut declarations);''','''        if expand_declaration_with_budget(&name, value, important, &mut declarations, work).is_err() {
            declarations.truncate(start);
            break;
        }''')
replace('''                expand_declaration(shorthand, &value, false, &mut expanded);''','''                expand_declaration_with_budget(shorthand, &value, false, &mut expanded, work).ok()?;''')
replace('''pub(crate) fn expand_declaration(
''','''pub(crate) fn expand_declaration_with_budget(
    name: &str,
    value: &str,
    important: bool,
    out: &mut Vec<Declaration>,
    work: &mut usize,
) -> Result<(), crate::selectors::Error> {
    if name == "background" && !css_wide(value) && !contains_var_function(value) {
        if let Some((image, color)) = gradient::background_parts(value, work)? {
            crate::selectors::spend(work, image.len() + color.len() + 128)?;
            for (name, value) in [("background-color", color), ("background-image", image)] {
                out.push(Declaration { name: name.into(), value: value.into(), important, pending_shorthand: None });
            }
        }
    } else {
        expand_declaration(name, value, important, out);
    }
    Ok(())
}
fn expand_declaration(
''')
a=s.index('    } else if name == "background" {',s.index('fn expand_declaration('))
b=s.index('    } else if name == "flex" {',a)
s=s[:a]+'    } else if name == "background" {\n        // Ordinary backgrounds use the metered atomic wrapper.\n'+s[b:]
# Shared validation in both supports entry points, retaining original comments/calc grammar.
replace('''        if matches!(property.as_str(), "object-fit" | "object-position") {''','''        if matches!(property.as_str(), "object-fit" | "object-position" | "background" | "background-image") {''')
replace('''            valid_object_property(&property, value, &mut evaluator.work).map_err(|_| ())''','''            valid_declaration_value(&property, value, &mut evaluator.work).map_err(|_| ())''')
replace('''        if matches!(name.as_str(), "object-fit" | "object-position") {''','''        if matches!(name.as_str(), "object-fit" | "object-position" | "background" | "background-image") {''')
replace('''            valid_object_property(&name, value, &mut self.work).map_err(|_| ())''','''            valid_declaration_value(&name, value, &mut self.work).map_err(|_| ())''')
replace('''pub(crate) fn supports_property(name: &str, value: &str) -> bool {
''','''pub(crate) fn supports_property(name: &str, value: &str) -> bool {
    if matches!(name, "background" | "background-image") {
        return valid_background_property(name, value, &mut MAX_SUPPORTS_WORK).unwrap_or(false);
    }
''')
replace('''fn valid_declaration_value(
''','''pub(crate) fn valid_background_property(name: &str, value: &str, work: &mut usize) -> Result<bool, crate::selectors::Error> {
    gradient::valid(name, value, work)
}
fn valid_declaration_value(
''')
replace('''        valid_object_property(name, value, work)
    } else {
        Ok(valid_math_property(name, value))''','''        valid_object_property(name, value, work)
    } else if matches!(name, "background" | "background-image") {
        valid_background_property(name, value, work)
    } else {
        Ok(valid_math_property(name, value))''')
p.write_text(s)
p=w/'src/cssom.rs';s=p.read_text()
replace('''        "background" => values[0].into(),''','''        "background" => {
            if values[1] == "none" { values[0].into() }
            else if values[0] == "transparent" { values[1].into() }
            else { format!("{} {}", values[1], values[0]) }
        },''')
replace('''    css::expand_declaration(property, value, important, &mut expanded);''','''    css::expand_declaration_with_budget(property, value, important, &mut expanded, work).map_err(|_| Error::Limit)?;''')
replace('''        "background" => color(value),''','''        "background" => css::valid_background_property(property, value, work).map_err(|_| Error::Limit)?,''')
replace('''    if matches!(property, "object-fit" | "object-position") {''','''    if property == "background-image" {
        return css::valid_background_property(property, value, work).map_err(|_| Error::Limit);
    }
    if matches!(property, "object-fit" | "object-position") {''')
s += '\n#[cfg(test)]\nmod gradient_tests;\n'
p.write_text(s)
