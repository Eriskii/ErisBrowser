from pathlib import Path
import hashlib,json,subprocess,shutil
P=Path(__file__).resolve().parent
W=P/'worktree';Q=Path('/tmp/eris-linear-gradient-preparation-1')
def bind(p):
 p=Path(p);d=p.read_bytes();return {'path':str(p),'bytes':len(d),'sha256':hashlib.sha256(d).hexdigest()}
def write(p,value):
 with Path(p).open('x') as f:json.dump(value,f,indent=2,sort_keys=True);f.write('\n')
def git(*a):return subprocess.check_output(['git','-C',str(W),*a]).decode()
old=json.loads((P/'compiled-source-2.json').read_bytes())['source_sha256']
new=json.loads((P/'compiled-source-3.json').read_bytes())['source_sha256']
assert {n for n in new if new[n]!=old[n]}=={'src/layout.rs','src/layout/gradient_tests.rs'}
write(P/'references-review-final.json',{'status':'clear unchanged reference and interaction fixtures after reviewed root-color correction','reviewer':'root','prior_peer':bind(Q/'root/layout-review.json'),'correction_peer':bind(Q/'layout/implementation/html-review-3.json'),'previous_source':bind(P/'compiled-source-2.json'),'final_source':bind(P/'compiled-source-3.json'),'verified':'Only src/layout.rs and src/layout/gradient_tests.rs differ between the 501-input inventories. All reference fixtures, Page/worker assertions and CPU evaluator bytes remain identical. The final full suites and 68-reference run are recorded separately.'})
shutil.copyfile('/tmp/eris-image-identity-1/candidate-browser-binary.json',P/'baseline-browser-binary.json')
write(P/'initial-browser-binary.json',json.loads((P/'initial-binaries.json').read_bytes())[0])
labels1=['focused-gradient-1','initial-reftests-1','initial-witness-1']
labels2=['full-native-1','full-default-198-1','clippy-msrv-1','clippy-198-1','candidate-browser-build-1','candidate-browser-strip-1','candidate-reftests-1','format-check-1','bridge-discovery-1','bridge-roster-1']
labels3=['full-native-2','full-default-198-2','clippy-msrv-2','clippy-198-2','candidate-browser-build-2','candidate-browser-strip-2','candidate-reftests-2','format-check-2']
checks={}
for label in labels1+labels2+labels3+['baseline-reftests-1','format-1','format-2','format-3','parent-ci-1','parent-ci-2']:
 receipt=P/'validation'/f'{label}.json';r=json.loads(receipt.read_bytes())
 expected={'focused-gradient-1':101,'baseline-reftests-1':1,'format-1':2}.get(label,0)
 assert r['exit']==expected,(label,r['exit'])
 item={'receipt':bind(receipt),'log':bind(receipt.parent/r['log']),'expected_exit':expected,'command':r['command']}
 if label in labels1+labels2+labels3:item['source']=bind(P/f'compiled-source-{1 if label in labels1 else 2 if label in labels2 else 3}.json')
 checks[label]=item
reports={}
for name,directory,check,manifest,binary_record,counts in [
 ('baseline','reftests-baseline-1','baseline-reftests-1',Q/'root/only-new.json',P/'baseline-browser-binary.json',[0,3,3]),
 ('initial','reftests-initial-1','initial-reftests-1',Q/'root/only-new.json',P/'initial-browser-binary.json',[3,0,3]),
 ('before-root-color','reftests-candidate-1','candidate-reftests-1',W/'tests/reftests/manifest.json',P/'candidate-browser-binary.json',[68,0,68]),
 ('final','reftests-candidate-2','candidate-reftests-2',W/'tests/reftests/manifest.json',P/'candidate-browser-binary-2.json',[68,0,68])]:
 reports[name]={'report':bind(P/directory/'report.json'),'manifest':bind(manifest),'counts':counts,'check':check,'binary':json.loads(binary_record.read_bytes())['path'],'binary_record':bind(binary_record)}
names=(set(git('diff','HEAD','--name-only','-z').split('\0'))|set(git('ls-files','--others','--exclude-standard','-z').split('\0')))-{''}
assert {'README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','tests/reftests/README.md','docs/linear-gradients.md'}<=names
published={n:bind(W/n) for n in sorted(names)}
reviews={
 'documentation':bind(Q/'docs/html-review-final.json'),
 'css':bind(P/'css/script-review-2.json'),
 'layout':bind(Q/'layout/implementation/html-review-3.json'),
 'transport':bind(P/'script-integration/root-review-2.json'),
 'evaluator':bind(P/'evaluator-review/script-review.json'),
 'references':bind(P/'references-review-final.json'),
}
paths=set()
for tree in [Q,P/'css',P/'script-integration',P/'evaluator-review',P/'package-review',P/'validation',P/'reftests-baseline-1',P/'reftests-initial-1',P/'reftests-candidate-1',P/'reftests-candidate-2']:
 for p in tree.rglob('*'):
  if p.is_file():paths.add(p)
for name in ['run-check.py','run-tool.py','snapshot-source.py','select-evidence.py','check-bridge-roster.py','initial-binaries.json','compiled-source-1.json','compiled-source-2.json','compiled-source-3.json','candidate-browser-binary.json','candidate-browser-binary-2.json','references-review-final.json']:
 paths.add(P/name)
selection={'live_source':bind(P/'compiled-source-3.json'),'published':published,'checks':checks,'full_suites':{'full-native-2':2502,'full-default-198-2':2326},'reports':reports,'candidate':bind(P/'candidate-browser-binary-2.json'),'reviews':reviews,'archive_inputs':[bind(p) for p in sorted(paths)],'summary':{
 'scope':'One linear-gradient background layer, strict bounded legacy-color/in-srgb grammar, computed-style sharing, layout canvas/inline/table placement, direct software sampling and confined-worker transport.',
 'results':{'rust_1_88_vulkan_feature':2502,'rust_1_98_default':2326,'full_suites_failed':0,'full_suites_ignored':0,'self_authored_visual_references':68,'visual_failures':0,'bridge_discovery_names':96,'strict_lint':'Both toolchains pass all-target Clippy with warnings denied.'},
 'corrections':['First focused run: 45 passes and one table fixture failure from an unsupported border-spacing prerequisite; retained and corrected using existing two-pixel spacing plus a color-only baseline.','Root padding-box lookup charged to layout work budget; mixed CSS-wide shorthand serialization corrected.','Canvas gradient currentColor now resolves against root style, including body propagation; primary-source chain, one-line change and literal regression retained.','First formatter wrapper invocation rejected unsupported --locked/--offline arguments before editing source.'],
 'limitations':['No complete web-standards, broad security or Chromium performance claim.','Self-authored references, not Web Platform Tests or external browser comparisons.','Scenes containing gradients explicitly fall back to software rasterization; no native gradient shader/GPU execution claim.','Modern color spaces, radial/conic/repeating gradient functions, URL/multiple image layers and author background sizing/repeat/origin/clip controls remain unsupported.'],
 'provenance':'Raw source holds, reviewed corrections, historical failures, final input hashes, immutable binary identity, check commands/logs and reference pixels are retained in the archive. Historical live paths denote bytes at their recorded phase; retained raw copies and source inventories distinguish phases.'}}
write(P/'selection.json',selection)
print(json.dumps({'published':len(published),'archive_extra_files':len(paths),'extra_bytes':sum(p.stat().st_size for p in paths),'checks':len(checks)},indent=2))
