from pathlib import Path
import json,hashlib
w=Path('/tmp/eris-linear-gradient-1/worktree');r=w/'tests/reftests';p=Path(__file__).resolve().parent
base='<!doctype html><meta charset="utf-8"><style>html,body{margin:0;background:white}div{position:absolute}</style>\n'
def box(x,y,width,height,color):
    return f'<div style="left:{x}px;top:{y}px;width:{width}px;height:{height}px;background:{color}"></div>\n'
def gradient_box(x,y,width,height,value,extra=''):
    return f'<div style="left:{x}px;top:{y}px;width:{width}px;height:{height}px;background:{value};{extra}"></div>\n'
actual=base;reference=base
for y,value,colors in [
    (10,'linear-gradient(to right, #000, #f8f8f8)',['#1f1f1f','#5d5d5d','#9b9b9b','#d9d9d9']),
    (35,'linear-gradient(in srgb to right, #000, #f8f8f8)',['#1f1f1f','#5d5d5d','#9b9b9b','#d9d9d9']),
    (60,'linear-gradient(to right, rgb(248 0 0), transparent)',['#f92020','#fb6060','#fc9f9f','#fedfdf']),
    (85,'linear-gradient(to right, red 75%, lime 25%)',['red','red','red','lime']),
]:
    actual+=gradient_box(20,y,4,16,value)
    for i,color in enumerate(colors): reference+=box(20+i,y,1,16,color)
actual+=gradient_box(40,10,80,40,'linear-gradient(to right, red 0% 50%, lime 50% 100%)')
reference+=box(40,10,40,40,'red')+box(80,10,40,40,'lime')
actual+=gradient_box(40,60,4,2,'linear-gradient(to top right, red 50%, blue 50%)')
for row,colors in enumerate([['red','blue','blue','blue'],['red','red','red','blue']]):
    for i,color in enumerate(colors): reference+=box(40+i,60+row,1,1,color)
actual+=gradient_box(40,85,80,20,'linear-gradient(currentColor)','color:lime')
reference+=box(40,85,80,20,'lime')
pairs=[('linear-gradient-colors',actual,reference,'Legacy sRGB interpolation, premultiplied transparency, double stops, fixup, corner geometry and currentColor against literal rectangles.')]
actual=base+gradient_box(20,20,40,20,'linear-gradient(to right, red 50%, lime 50%)','padding:4px;border:8px solid transparent')
reference=base
for x,width,color in [(20,8,'lime'),(28,24,'red'),(52,24,'lime'),(76,8,'red')]: reference+=box(x,20,width,44,color)
# A following shorthand removes the image, while a color longhand retains it.
actual+=gradient_box(20,85,32,20,'linear-gradient(red,blue)','background:lime')
reference+=box(20,85,32,20,'lime')
actual+=gradient_box(65,85,4,16,'linear-gradient(to right, rgb(248 0 0), transparent)','background-color:white')
for i,color in enumerate(['#f92020','#fb6060','#fc9f9f','#fedfdf']): reference+=box(65+i,85,1,16,color)
pairs.append(('linear-gradient-background-box',actual,reference,'Padding-box sizing repeats under transparent borders; color/image shorthand resets and longhand preservation remain independent.'))
actual='<!doctype html><meta charset="utf-8"><style>html{margin:0;height:40px;background:linear-gradient(red 50%,blue 50%)}body{margin:0;background:lime}</style>\n'
reference=base
for y in range(0,240,20):reference+=box(0,y,320,20,'red' if y%40==0 else 'blue')
pairs.append(('linear-gradient-canvas',actual,reference,'The root image suppresses body propagation and repeats its forty-pixel tile across the viewport canvas.'))
manifest=json.loads((r/'manifest.json').read_text());new=[];files=[]
for name,actual,reference,description in pairs:
    for suffix,content in [('',actual),('-ref',reference)]:
        path=r/(name+suffix+'.html');path.write_text(content);files.append({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()})
    case={'name':name,'description':description,'test':name+'.html','reference':name+'-ref.html'};manifest['cases'].append(case)
    new.append({**case,'test':str(r/case['test']),'reference':str(r/case['reference'])})
(r/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(p/'only-new.json').write_text(json.dumps({'width':320,'height':240,'cases':new},indent=2)+'\n')
(p/'references-source-ready.json').write_text(json.dumps({'status':'literal oracles frozen before candidate render','files':files},indent=2)+'\n')
print(json.dumps({'pairs':len(pairs),'total':len(manifest['cases']),'files':files},indent=2))
