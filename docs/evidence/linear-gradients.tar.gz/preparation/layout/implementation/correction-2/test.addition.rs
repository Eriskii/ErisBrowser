#[test]
fn propagated_body_gradient_resolves_current_color_on_root_with_root_padding_tile() {
    let (doc, styles) = prepare(
        "<style>html{margin:0;width:8px;height:4px;box-sizing:border-box;padding:1px;border:1px solid transparent;color:red}body{margin:0;width:2px;height:2px;color:blue;background-image:linear-gradient(to right,currentColor 50%,lime 50%)}</style>",
        12.0,
        8.0,
    );
    let html = doc.query_selector("html").unwrap();
    let body = doc.query_selector("body").unwrap();
    assert_eq!(styles[html].color, Color::rgb(255, 0, 0));
    assert_eq!(styles[body].color, Color::rgb(0, 0, 255));
    assert!(styles[html].background_image.is_none());
    assert_eq!(styles[html].background_color.a, 0);
    let source = styles[body].background_image.as_ref().unwrap();
    assert!(matches!(source.stops[0].color, GradientColor::CurrentColor));
    let result = layout(&doc, &styles, 12.0, 8.0, &Fonts::new());
    assert_eq!(
        gradients(&result),
        vec![(
            rect(0.0, 0.0, 12.0, 8.0),
            rect(1.0, 1.0, 6.0, 2.0),
            0.0,
            Color::rgb(255, 0, 0),
        )]
    );
    // The body's computed image remains intact but has no local used image.
    // Root tile repeats across the canvas, including through the body box.
    assert!(styles[body].background_image.is_some());
    let row = [
        0x00ff00, 0xff0000, 0xff0000, 0xff0000, 0x00ff00, 0x00ff00,
        0x00ff00, 0xff0000, 0xff0000, 0xff0000, 0x00ff00, 0x00ff00,
    ];
    assert_eq!(pixels(&result, 12, 8), row.repeat(8));
}

