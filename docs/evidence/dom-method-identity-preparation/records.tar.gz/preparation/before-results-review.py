#!/usr/bin/env python3
"""Independent data-only audit of the retained DOM BEFORE, using its held archive."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import tarfile

HERE = Path(__file__).resolve().parent
PREP = HERE / 'local-preparation'
RESULT = HERE / 'local-before'


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def bind(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as handle:
        sha = hashlib.file_digest(handle, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha)


def verify(row):
    assert bind(row['path']) == row


assert __debug__
manifest = read(PREP / 'replay-inputs.json')
assert bind(PREP / 'replay-inputs.json')['sha256'] == '1e895a5052be2d60e3809107f972caa1dead9002aff96fa7fbbe70c3ac4f9512'
for name, row in manifest['files'].items():
    verify(dict(path=name, **row))
execution = read(RESULT / 'execution.json')
assert execution['completed'] and execution['inputs_unchanged'] and execution['post_inputs_unchanged']
assert not any('failure' in k for k in execution)
assert execution['driver_sha256'] == bind(PREP / 'replay.py')['sha256']
assert execution['manifest_sha256'] == bind(PREP / 'replay-inputs.json')['sha256']
assert execution['counts'] == dict(cases=58, feature_controls=32, common_controls=12, total=102)
assert execution['process_limits'] == dict(wall_seconds=120, cpu_seconds=45,
    address_space_bytes=512*1024**2, log_file_bytes=32*1024**2, reap_seconds=5)
assert execution['adapter_limits'] == dict(per_case_wall_seconds=3, cpu_seconds=30,
    address_space_bytes=512*1024**2, stdout_bytes=96*1024, stderr_bytes=64*1024)
for row in list(execution['release'].values()) + list(execution['artifacts'].values()):
    verify(row)
assert set(execution['artifacts']) == {'start.json', 'report.json', 'local.execution.json',
                                      'local.stdout.log', 'local.stderr.log'}
assert set(p.name for p in RESULT.iterdir()) == set(execution['artifacts']) | {'execution.json'}
start = read(RESULT / 'start.json')
assert start['completed'] is False
assert all(execution[k] == v for k, v in start.items() if k != 'completed')
process = read(RESULT / 'local.execution.json')
assert process['command'] == execution['command']
assert process['returncode'] == 0 and process['leader_reaped'] is True
assert process['exit_observed_unreaped'] == dict(pid=process['pid'], code=1, status=0)
assert not any('failure' in k for k in process)
assert 0 < process['timeout_seconds'] <= 120
assert (RESULT / 'local.stderr.log').read_bytes() == b''

# Verify immutable saved inputs, never the concurrently changing production tree.
candidate = Path(manifest['before']['candidate'])
assert execution['release']['eris-js']['sha256'] == manifest['before']['binary_sha256']
assert execution['release']['archive-inputs.json']['sha256'] == manifest['before']['archive_inventory_sha256']
inventory = read(candidate / 'archive-inputs.json')['files']
mapping = {r['path']: r['sha256'] for r in inventory}
assert len(mapping) == len(inventory) == 418
with tarfile.open(candidate / 'source.tar', 'r:') as archive:
    members = archive.getmembers()
    assert len(members) <= 2048 and len({m.name for m in members}) == len(members)
    regular = {}
    for member in members:
        path = Path(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        assert member.isfile() or member.isdir()
        if member.isfile():
            assert member.name in mapping and 0 <= member.size <= 16*1024**2
            with archive.extractfile(member) as handle:
                raw = handle.read()
            assert len(raw) == member.size and digest(raw) == mapping[member.name]
            regular[member.name] = raw
    assert set(regular) == set(mapping)
    inputs = read(candidate / 'inputs.json')
    production = {r['path']: r['sha256'] for r in inputs['files']}
    assert len(production) == len(inputs['files']) == 123
    assert production == {n: mapping[n] for n in mapping if n in ('Cargo.toml', 'Cargo.lock')
                          or n.startswith(('src/', 'assets/', 'examples/'))}
    total = hashlib.sha256()
    for name in sorted(production, key=Path):
        assert digest(regular[name]) == production[name]
        total.update(name.encode()); total.update(b'\0'); total.update(regular[name]); total.update(b'\0')
    assert total.hexdigest() == inputs['input_sha256'] == manifest['before']['input_sha256']

matrix_record = read(PREP / 'runner-matrix.json')
matrix = matrix_record['cases']
draft = read(PREP / 'draft.json')
report = read(RESULT / 'report.json')
assert bind(RESULT / 'report.json')['sha256'] == '334bb174fb8cfd0d5490a09e56a49885e84f47b6569497f36d4a370176dc46b7'
assert report['binary'] == str(candidate / 'eris-js')
assert report['binary_sha256'] == manifest['before']['binary_sha256']
for key, name in [('fixture_sha256', 'dom-method-identity.js'),
                  ('matrix_sha256', 'runner-matrix.json'), ('runner_sha256', 'run.py')]:
    assert report[key] == bind(PREP / name)['sha256']
assert report['harness'] == matrix_record['harness']
assert report['tool_hashes'] == matrix_record['tool_hashes']
assert report['bounds'] == dict(per_case_wall_seconds=3, address_space_bytes=512*1024**2,
    per_process_cpu_seconds=30, core_bytes=0, adapter_stdout_bytes=96*1024, adapter_stderr_bytes=64*1024)
assert len(report['cases']) == 58 and len(report['controls']) == 44
rows = report['cases'] + report['controls']
by_id = {r['id']: r for r in rows}
assert len(by_id) == len(rows) == len(matrix) == 102
assert len(draft['cases']) == 29 and len(draft['feature_controls']) == 16
for expected, actual in zip(matrix, rows):
    for key in ('id', 'mode', 'case_sha256', 'source_sha256', 'source', 'expectation_sha256',
                'category', 'area', 'prerequisites', 'positive', 'partner'):
        assert actual.get(key) == expected.get(key), (expected['id'], key)
    assert actual['expected_observation'] == expected['expected']
    assert actual['source_sha256'] == digest(actual['source'].encode())
    assert actual['expected_negative'] is None
    assert actual['file'] == {'fixture': 'dom-method-identity.js',
                             'preflight-control': 'preflight-controls',
                             'harness-control': 'harness-controls'}[actual['category']]
    matched = all(actual['observation'].get(k) == v for k, v in expected['expected'].items())
    assert actual['matches_expectation'] is matched
    observation = actual['observation']
    # These raw statuses follow the ordinary runner, before the separate expected-policy check.
    assert actual['status'] == {'complete': 'passed', 'exception': 'failed',
                                'resource': 'resource'}[observation['status']]
    assert observation['phase'] == 'runtime' and observation['harness'] == ''
assert report['counts'] == dict(Counter(r['status'] for r in report['cases'])) == {
    'passed': 30, 'failed': 24, 'resource': 4}
areas = {name: dict(Counter(r['status'] for r in report['cases'] if r['area'] == name))
         for name in {r['area'] for r in report['cases']}}
assert areas == report['areas'] == {'ordinary': {'passed': 30, 'failed': 18},
    'missing-prerequisite': {'failed': 6}, 'terminal-policy': {'resource': 4}}
assert set(report['protocol_prerequisites']) == {'sloppy', 'strict'}
for mode, entry in report['protocol_prerequisites'].items():
    guard_id = 'preflight-document-query-selector-positive#' + mode
    assert entry == dict(id=guard_id, matches_expectation=True, observation=by_id[guard_id]['observation'])
    assert by_id[guard_id]['status'] == 'passed'
assert report['protocol_prerequisite_verified'] is True
for row in report['controls']:
    partner = by_id[row['partner']]
    assert partner['positive'] and partner['mode'] == row['mode']
    assert row['verified'] == (row['matches_expectation'] and partner['matches_expectation']) is True
    assert row['status'] == ('passed' if row['positive'] else 'failed')
    if not row['positive']:
        assert row['observation']['error_type'] == 'Test262Error'
assert report['controls_verified'] == 44
for row in report['cases']:
    assert row['prerequisite'] == report['protocol_prerequisites'][row['mode']]
    assert row['verified_with_protocol_prerequisite'] == (row['matches_expectation'] and row['prerequisite']['matches_expectation'])
assert sum(r['matches_expectation'] for r in report['cases']) == report['fixture_expectations_matched'] == 34
assert sum(r['verified_with_protocol_prerequisite'] for r in report['cases']) == report['fixture_expectations_verified'] == 34
assert report['resource_expectations_are_engine_policy_not_ecmascript_errors'] is True
policies = [r for r in report['cases'] if r['area'] == 'terminal-policy']
assert len(policies) == 4
assert all(r['expected_observation'] == dict(status='resource', phase='runtime') and
           r['observation']['status'] == 'resource' and
           r['observation']['error_type'] == 'ResourceLimit' and
           r['observation']['message'] == 'script instruction limit exceeded' for r in policies)
assert execution['summary'] == {k: report[k] for k in (
    'counts', 'controls_verified', 'fixture_expectations_matched',
    'fixture_expectations_verified', 'protocol_prerequisite_verified')}
stdout = (RESULT / 'local.stdout.log').read_text().splitlines()
assert len(stdout) == 103
for row, line in zip(rows, stdout[:102]):
    assert line == row['id'] + ' ' + row['status'] + ' ' + row['observation']['message']
assert stdout[-1].startswith('RESULT 58 ') and stdout[-1].endswith('CONTROLS 44 / 44')

receipt = dict(schema=1, result='clear', findings=[],
    parent=manifest['parent'], reviewed_binary_sha256=report['binary_sha256'],
    counts=dict(case_modes=58, feature_controls=32, common_controls=12, total_rows=102),
    raw_case_outcomes=report['counts'], areas=areas, controls_verified=44,
    expected_outcomes_matched=34, expected_outcomes_verified_with_selector_guard=34,
    terminal_policy_ids=[r['id'] for r in policies],
    missing_prerequisite_ids=[r['id'] for r in report['cases'] if r['area'] == 'missing-prerequisite'],
    failure_decomposition=dict(Counter(r['observation']['error_type'] for r in report['cases'] if r['status'] == 'failed')),
    exact_manifest_files=len(manifest['files']), exact_archive_members=418, exact_production_members=123,
    process=dict(returncode=0, empty_stderr=True, exit_observed_before_reap=True,
                 leader_reaped=True, inputs_unchanged=execution['inputs_unchanged'],
                 post_inputs_unchanged=execution['post_inputs_unchanged']),
    bindings=[bind(Path(__file__)), bind(PREP / 'replay-inputs.json'), bind(PREP / 'runner-matrix.json'),
              bind(PREP / 'draft.json'), *[bind(p) for p in sorted(RESULT.iterdir())]],
    qualifications=['This audit starts no engines, parsers, compilers or replay drivers.',
                    'Current production files were not read; the complete preserved archive and binary were verified.',
                    'Raw wrong-control failures are intentional and require their successful same-mode positive partners.',
                    'The six prerequisite failures remain ordinary complete/runtime expectations, with no exclusion or expected-error substitution.',
                    'The four resource outcomes are explicit bounded-engine policies, not ECMAScript exception requirements.',
                    'The inherited supervisor receipt records unreaped leader observation and positive reap; its bound source preserves group signalling before reaping. No stronger descendant census is inferred.'])
with (HERE / 'before-results-review.json').open('x') as handle:
    json.dump(receipt, handle, indent=2); handle.write('\n')
with (HERE / 'before-results-review.md').open('x') as handle:
    handle.write('The retained DOM BEFORE is consistent with the frozen 102-row population: '
                 '30 passed, 24 failed and four terminal-resource case modes; all 44 controls verify. '
                 'Both successful-selector prerequisites passed, so 34 of 58 case expectations are verified.\n\n'
                 'The 24 failures include 18 ordinary scope modes and six visible prerequisite modes; '
                 '22 report Test262Error and two host-property replacement modes report TypeError. '
                 'All four authored policy modes report the instruction limit. No rows or expectations were changed.\n\n'
                 'All 72 manifest inputs, 418 archived source members, 123 production inputs, binary bindings, '
                 'raw logs and process receipts verify. The runner exited zero with empty stderr, recorded an '
                 'unreaped exit before positive leader reap, and retained successful pre/post input checks. '
                 'This data-only audit used the preserved archive rather than the concurrently changing production tree.\n')
print(json.dumps(dict(result='clear', receipt=bind(HERE / 'before-results-review.json')), sort_keys=True))
