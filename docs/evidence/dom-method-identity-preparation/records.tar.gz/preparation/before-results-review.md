The retained DOM BEFORE is consistent with the frozen 102-row population: 30 passed, 24 failed and four terminal-resource case modes; all 44 controls verify. Both successful-selector prerequisites passed, so 34 of 58 case expectations are verified.

The 24 failures include 18 ordinary scope modes and six visible prerequisite modes; 22 report Test262Error and two host-property replacement modes report TypeError. All four authored policy modes report the instruction limit. No rows or expectations were changed.

All 72 manifest inputs, 418 archived source members, 123 production inputs, binary bindings, raw logs and process receipts verify. The runner exited zero with empty stderr, recorded an unreaped exit before positive leader reap, and retained successful pre/post input checks. This data-only audit used the preserved archive rather than the concurrently changing production tree.
