#!/usr/bin/env python3
"""Data-only adaptation of the sealed Object.is local runner and supervisor."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
OLD = Path('/tmp/eris-object-is-preparation-1/local-preparation')
DRAFT_SHA = '8b67525bc0c44b8caf741d2828317861e7306d2c025f4ee3ccefdcecb49ba5b5'
ORIGINS = {
    'run.py': 'e1f0024d25c2deb44a84d43244dfac3f880863693c5eb191764a7ec94b1422d8',
    'replay.py': '525fdd29e0846c77cc258cd859d2fb2419afe139259c67327557f2f823c953ae',
}


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, value):
    with (HERE / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


def copy(source, target):
    with Path(target).open('xb') as handle:
        handle.write(Path(source).read_bytes())


assert __debug__, 'Optimized Python is not allowed'
draft = PARENT / 'local-oracle-draft-2.json'
assert sha(draft) == DRAFT_SHA
data = json.loads(draft.read_bytes())
assert (data['case_sources'], data['case_modes'], data['feature_control_modes'],
        data['feature_pairs'], data['protocol_positive_pair']) == (
            29, 58, 32, 8, 'document-query-selector')
assert len(data['cases']) == 29 and len(data['feature_controls']) == 16
for rows in (data['cases'], data['feature_controls']):
    assert len({row['id'] for row in rows}) == len(rows)
    for row in rows:
        assert row['modes'] == ['sloppy', 'strict']
        assert hashlib.sha256(row['source'].encode()).hexdigest() == row['sha256']
for name, digest in ORIGINS.items():
    assert sha(OLD / name) == digest, name
copy(draft, HERE / 'draft.json')
copy(PARENT / 'local-oracle-draft-2.js', HERE / 'dom-method-identity.js')
copy(OLD / 'TEST262-LICENSE', HERE / 'TEST262-LICENSE')
for directory in ('tools', 'harness'):
    shutil.copytree(OLD / directory, HERE / directory,
                    ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))

changes = {}
for name in ('run.py', 'replay.py'):
    original = (OLD / name).read_text()
    source = original.replace('object-is', 'dom-method-identity')
    replacements = []
    if name == 'run.py':
        assert source.count('preflight-nan-positive#') == 3
        source = source.replace('preflight-nan-positive#',
                                'preflight-document-query-selector-positive#')
        replacements.append(['preflight-nan-positive#',
                             'preflight-document-query-selector-positive#'])
    else:
        replacements = [
            ('len(matrix)==138 and len(draft[\'cases\'])==39',
             'len(matrix)==102 and len(draft[\'cases\'])==29'),
            ('matrix[:78]', 'matrix[:58]'),
            ('matrix[78:126]', 'matrix[58:90]'),
            ("len(report['cases'])==78 and len(report['controls'])==60",
             "len(report['cases'])==58 and len(report['controls'])==44"),
            ("len({r['id'] for r in rows})==138", "len({r['id'] for r in rows})==102"),
            ('rows=138,cases=78,controls=60', 'rows=102,cases=58,controls=44'),
            ('archive_members=413', 'archive_members=418'),
            ('cases=78,feature_controls=48,common_controls=12,total=138',
             'cases=58,feature_controls=32,common_controls=12,total=102'),
            ("    draft=old.read(HERE/'draft.json')",
             "    require(data['counts']==dict(source_cases=29,case_modes=58,feature_controls=32,common_controls=12,rows=102),'population counts changed')\n"
             "    require(len(old.read(candidate/'archive-inputs.json')['files'])==418,'archive member count changed')\n"
             "    draft=old.read(HERE/'draft.json')"),
            ("    helper.verify_health(report)",
             "    require(set(report['protocol_prerequisites'])=={'sloppy','strict'},'protocol modes changed')\n"
             "    for mode,entry in report['protocol_prerequisites'].items():\n"
             "        require(entry['id']=='preflight-document-query-selector-positive#'+mode,'working-selector prerequisite changed')\n"
             "    helper.verify_health(report)"),
        ]
        for before, after in replacements:
            assert source.count(before) == 1, before
            source = source.replace(before, after)
    with (HERE / name).open('x') as handle:
        handle.write(source)
    with (HERE / (name + '.diff')).open('x') as handle:
        handle.writelines(difflib.unified_diff(original.splitlines(True), source.splitlines(True),
                                             fromfile=str(OLD / name), tofile=str(HERE / name)))
    changes[name] = dict(origin=str(OLD / name), origin_sha256=sha(OLD / name),
                         result_sha256=sha(HERE / name),
                         suite_rename=['object-is', 'dom-method-identity'],
                         replacements=replacements)
save('freeze.json', dict(phase='Independent DOM defining-interface oracle; no engine execution',
    fixture_sha256=sha(HERE / 'dom-method-identity.js'), generator_sha256=sha(__file__),
    draft_sha256=sha(HERE / 'draft.json'), source_cases=29, mode_cases=58))
save('runner-adaptation.json', dict(schema=1, changes=changes, draft_sha256=DRAFT_SHA,
    source_handling='Exact JSON source bytes; JS companion is a bound readable artifact.',
    protocol_positive_pair='document-query-selector',
    common_controls='All twelve prior common modes, order, source and expectation bytes are unchanged.',
    supervision='Unchanged limits, waitid WNOWAIT, group signal before leader reap, signal handling and post-input checks.',
    narrow_verifier_additions=['Assert the new fixed population and actual 418-member archive count.',
                              'Require the exact successful-selector prerequisite for both modes.'],
    engines_executed=False))
print('Prepared exact 58 fixture modes, 32 feature controls and 12 common controls; no engines.')
