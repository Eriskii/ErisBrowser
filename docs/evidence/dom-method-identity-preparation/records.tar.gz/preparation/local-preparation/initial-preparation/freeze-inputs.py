#!/usr/bin/env python3
"""Bind the DOM local population and its preserved BEFORE release; data only."""
from pathlib import Path
import ast
import collections
import hashlib
import json

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
OLD = Path('/tmp/eris-object-is-preparation-1/local-preparation')
CANDIDATE = Path('/tmp/eris-object-is-runtime-1/candidate-2')
PARENT_COMMIT = '8e2a2740ef1d63c9b3d0d2626400f8b125e4575c'


def read(path):
    return json.loads(Path(path).read_bytes())


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def bind(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    raw = path.read_bytes()
    return dict(bytes=len(raw), sha256=digest(raw))


def save(name, value):
    with (HERE / name).open('x') as handle:
        json.dump(value, handle, indent=2)
        handle.write('\n')


assert __debug__, 'Optimized Python is not allowed'
draft = read(HERE / 'draft.json')
assert bind(HERE / 'draft.json') == bind(PARENT / 'local-oracle-draft.json')
assert bind(HERE / 'dom-method-identity.js') == bind(PARENT / 'local-oracle-draft.js')
matrix = read(HERE / 'runner-matrix.json')
rows = matrix['cases']
assert len(rows) == len({r['id'] for r in rows}) == 102
assert collections.Counter(r['category'] for r in rows) == {
    'fixture': 58, 'preflight-control': 32, 'harness-control': 12}
assert rows[90:] == read(OLD / 'runner-matrix.json')['cases'][-12:]
assert matrix['harness'] == read(OLD / 'runner-matrix.json')['harness']
assert [r['name'] for r in matrix['harness']] == ['assert.js', 'sta.js', 'propertyHelper.js']
assert matrix['tool_hashes'] == read(OLD / 'runner-matrix.json')['tool_hashes']
assert matrix['license_sha256'] == bind(OLD / 'TEST262-LICENSE')['sha256']
authored = [(row, mode) for row in draft['cases'] for mode in row['modes']]
controls = [(row, mode) for row in draft['feature_controls'] for mode in row['modes']]
assert len(authored) == 58 and len(controls) == 32
complete = dict(status='complete', phase='runtime', error_identity='', error_type='')
wrong = dict(status='exception', phase='runtime', error_identity='', error_type='Test262Error')
for (source, mode), actual in zip(authored + controls, rows[:90]):
    assert actual['source'] == source['source']
    assert actual['source_sha256'] == source['sha256'] == digest(source['source'].encode())
    assert actual['mode'] == mode
    if 'variant' in source:
        positive = source['variant'] == 'positive'
        assert actual['id'] == 'preflight-' + source['pair'] + ('-positive#' if positive else '-wrong#') + mode
        assert actual['positive'] == positive
        assert actual['partner'] == 'preflight-' + source['pair'] + '-positive#' + mode
        assert actual['expected'] == (complete if positive else wrong)
    else:
        assert actual['id'] == source['id'] + '#' + mode
        assert actual['area'] == source['kind'] and actual['prerequisites'] == source['requires']
        assert actual['expected'] == (complete if source['expectation'] == 'pass'
                                      else dict(status='resource', phase='runtime'))
for row in rows:
    identity = dict(source_sha256=row['source_sha256'], mode=row['mode'],
                    metadata=dict(flags=[], features=[], includes=[], locale=[], negative=None),
                    harness=matrix['harness'])
    assert row['case_sha256'] == digest(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode())
    assert row['expectation_sha256'] == digest(json.dumps(row['expected'], sort_keys=True, separators=(',', ':')).encode())
for mode in ('sloppy', 'strict'):
    guard = next(r for r in rows if r['id'] == 'preflight-document-query-selector-positive#' + mode)
    assert guard['positive'] and guard['expected'] == complete
assert sum(r['expected']['status'] == 'resource' for r in rows[:58]) == 4
assert sum(r['area'] == 'missing-prerequisite' for r in rows[:58]) == 6
for directory in ('tools', 'harness'):
    for path in (HERE / directory).iterdir():
        assert bind(path) == bind(OLD / directory / path.name)
for name in ('prepare.py', 'run.py', 'replay.py', 'freeze-inputs.py'):
    ast.parse((HERE / name).read_bytes(), filename=str(HERE / name))
inputs = read(CANDIDATE / 'inputs.json')
assert inputs['input_sha256'] == '505dba3242fd9f28364c2ced18708773eb46acb4d7f56ae0ac39cabc75f96d28'
assert bind(CANDIDATE / 'eris-js')['sha256'] == '804bc8dd688182641be37be577feade9fe043a0869000cd272977707c320b4df'
assert bind(CANDIDATE / 'archive-inputs.json')['sha256'] == '5c28bc9c91d729801a77851cf4c6da411d246e6e4eef67c8dd74d4a49a1ff02b'
assert len(read(CANDIDATE / 'archive-inputs.json')['files']) == 418
for row in inputs['files']:
    assert bind(ROOT / row['path'])['sha256'] == row['sha256']
save('population-check.json', dict(schema=1, success=True,
    counts=dict(sources=29, case_modes=58, feature_control_modes=32, common_control_modes=12, rows=102),
    authored_case_and_feature_source_modes_preserved=90,
    independently_recomputed_case_and_expectation_fingerprints=102,
    exact_old_common_rows=12, explicit_terminal_policy_modes=4, ordinary_prerequisite_modes=6,
    harness_order=matrix['harness'], copied_tool_hashes=matrix['tool_hashes'],
    current_production_bindings=len(inputs['files']), archive_members=418,
    engines_or_compilers_executed=0,
    limits_and_observations='No engine observations. The inherited limits, raw row retention and health semantics are unchanged.'))
paths = [p for p in HERE.rglob('*') if p.is_file() and '__pycache__' not in p.parts]
paths += [PARENT / name for name in (
    'local-oracle-draft.json', 'local-oracle-draft.js', 'local-oracle-notes.md',
    'local-oracle-source-ready.json', 'prepare-local-draft.py')]
paths += [OLD / name for name in ('run.py', 'replay.py', 'runner-matrix.json')]
paths += [Path('/tmp/eris-for-in-length-buckets-1/replay-preparation/replay.py'),
          Path('/tmp/eris-array-buffer-historical-local-replay.py'), ROOT / 'tools/run.py']
save('replay-inputs.json', dict(schema=1, phase='before', parent=PARENT_COMMIT,
    before=dict(candidate=str(CANDIDATE), input_sha256=inputs['input_sha256'],
                binary_sha256=bind(CANDIDATE / 'eris-js')['sha256'],
                archive_inventory_sha256=bind(CANDIDATE / 'archive-inputs.json')['sha256']),
    counts=dict(source_cases=29, case_modes=58, feature_controls=32, common_controls=12, rows=102),
    files={str(p): bind(p) for p in sorted(set(paths))}))
print(json.dumps(dict(manifest=bind(HERE / 'replay-inputs.json'),
                     population_check=bind(HERE / 'population-check.json')), sort_keys=True))
