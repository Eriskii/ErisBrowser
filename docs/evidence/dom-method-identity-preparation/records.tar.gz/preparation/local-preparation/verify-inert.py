#!/usr/bin/env python3
"""Exercise only the wrapper's inert verification path; prohibit child/network starts."""
from pathlib import Path
import contextlib
import hashlib
import io
import json
import runpy
import sys
import traceback

HERE = Path(__file__).resolve().parent
EXPECTED = '1e895a5052be2d60e3809107f972caa1dead9002aff96fa7fbbe70c3ac4f9512'
denied = []


def bind(path):
    path = Path(path)
    raw = path.read_bytes()
    return dict(path=str(path), bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest())


def forbid(event, args):
    if event in {'subprocess.Popen', 'os.system', 'os.fork', 'os.forkpty',
                 'os.posix_spawn', 'os.exec', 'socket.connect', 'socket.bind'}:
        denied.append(event)
        raise RuntimeError('Inert verification denied ' + event)


sys.addaudithook(forbid)
sys.dont_write_bytecode = True
assert not (HERE.parent / 'local-before').exists()
assert bind(HERE / 'replay-inputs.json')['sha256'] == EXPECTED
sys.argv = [str(HERE / 'replay.py'), '--manifest-sha256', EXPECTED]
out, err = io.StringIO(), io.StringIO()
success = False
try:
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        runpy.run_path(str(HERE / 'replay.py'), run_name='__main__')
    result = json.loads(out.getvalue())
    assert result == dict(inert=True, rows=102, cases=58, controls=44,
                         binary_sha256='804bc8dd688182641be37be577feade9fe043a0869000cd272977707c320b4df',
                         archive_members=418)
    assert not denied and not err.getvalue()
    assert not (HERE.parent / 'local-before').exists()
    success = True
except BaseException:
    traceback.print_exc(file=err)
    raise
finally:
    for suffix, data in [('stdout.log', out.getvalue()), ('stderr.log', err.getvalue())]:
        with (HERE / ('inert.' + suffix)).open('x') as handle:
            handle.write(data)
    receipt = dict(schema=1, success=success, engine_or_compiler_executions=0,
                   child_or_network_attempts=denied,
                   before_output_absent=not (HERE.parent / 'local-before').exists(),
                   bindings=[bind(HERE / name) for name in (
                       'verify-inert.py', 'replay.py', 'replay-inputs.json',
                       'inert.stdout.log', 'inert.stderr.log')])
    with (HERE / 'inert-result.json').open('x') as handle:
        json.dump(receipt, handle, indent=2)
        handle.write('\n')
print(out.getvalue(), end='')
