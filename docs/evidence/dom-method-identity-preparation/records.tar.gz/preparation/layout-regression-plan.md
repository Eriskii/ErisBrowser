Source-only regression plan, 2026-10-02. No fixture, runtime, compiler or engine was executed. This is a proposed inventory to freeze before implementation, not observed pass results.

The eight-row design is sound for the named increment. WebIDL creates operation functions for the defining interface and checks that interface before argument conversion. ParentNode is included by Document, Element and DocumentFragment. This supports separate function identity/property bags and rejects cross-interface borrowing. It does not supply the missing interface prototypes or host property bags. Sources: [WebIDL operations](https://webidl.spec.whatwg.org/#es-operations), [DOM ParentNode](https://dom.spec.whatwg.org/#interface-parentnode), independently read on 2026-10-02. The remaining test recipes below are proposed regression design from the source seams, not quotations or execution-derived expectations.

Use exactly these eight fixture labels, in this order:

| Label | Acquisition | Public name | length |
| --- | --- | --- | --- |
| DQ | document.querySelector | querySelector | 1 |
| DA | document.querySelectorAll | querySelectorAll | 1 |
| EQ | element.querySelector | querySelector | 1 |
| EA | element.querySelectorAll | querySelectorAll | 1 |
| FQ | fragment.querySelector | querySelector | 1 |
| FA | fragment.querySelectorAll | querySelectorAll | 1 |
| EP | element.append | append | 0 |
| FP | fragment.append | append | 0 |

Create two Elements with different tag names, two ordinary fragments, one template content fragment, one Text, and distinct identifiable child nodes under the two Element/Fragment targets. A small HTML wrapper can also supply an SVG element without depending on the currently absent createElementNS. Keep every source isolated in a fresh Runtime/Document; do not let metadata mutation from one row affect another. The Document positive route uses the same document: a second Document construction API is not assumed.

Concrete ordinary regression recipes (each runs in sloppy and strict mode; final source counts depend on whether the indicated bounded matrices are split into rows):

| Proposed ID | Exact checks |
| --- | --- |
| eight-identities | Guard all eight values as callable and working. Compare the complete 8×8 table using both === and Object.is: only the diagonal matches. In addition, repeat acquisition and compare aliases from a second instance of the same interface. |
| element-interface-not-tag-or-namespace | Save EQ/EA/EP from one HTML element, compare another tag and the fixture SVG element. No tag/namespace-specific identity. |
| fragment-interface-and-template | FQ/FA/FP from two ordinary fragments and template.content match; they remain distinct from Element counterparts. |
| aliases-survive-tree-changes | Save methods, detach/move receivers, and compare fresh method acquisitions. Calls use the current receiver/tree; a node id never enters function identity. |
| isolated-function-expandos | For each of eight functions, set an ordinary expando to a unique object. Reacquisition/same-interface aliases see that object; all seven other functions lack the expando. Delete and verify own absence. |
| isolated-name-length-descriptors | For each row, assert own name/length values and writable=false/enumerable=false/configurable=true. Redefine name and length, verify only same-function aliases change, and restore exact saved descriptors. |
| deleted-metadata-not-reinitialized | Delete own name/length, reacquire, and assert own descriptors remain absent; restore. Do not expect property reads to be undefined: Function.prototype can supply inherited name/length. |
| public-metadata-not-dispatch-key | Rename EQ to querySelectorAll and set length=99; it still returns the selected single node and keeps identity. Rename EA to querySelector; it still returns the expected indexed collection. Restore both. |
| selectors-call-other-instance | Save EQ/EA on element A and call them on distinct element B; save FQ/FA on fragment A and call on fragment B/template.content. Assert B's child, not A's. DQ/DA call on document. |
| selectors-apply | Repeat the actual-other-instance checks with plain argument arrays through apply. Use collection length/index checks, not Array/NodeList branding. |
| selectors-bind | Bind saved selectors to another valid same-interface instance. Bound aliases are stable; two bind results are distinct; the bound result differs from the original function. Calling a bound function with a different this does not change its bound target. |
| selectors-cross-interface-brand | For each of six selector functions, both other ParentNode interfaces throw TypeError before a selector conversion getter/callback is touched: 12 combinations. Pair each with a valid receiver that demonstrably converts once. |
| selectors-noninterface-brand | Each selector rejects null, undefined, Window, plain object and Text. Include a plain object with nodeType/tagName-like fields and one with the receiver's current prototype. Do not infer a brand from properties or prototypes. |
| selector-required-argument | Every valid selector receiver with no argument throws TypeError. Explicit undefined is a separate conversion case; use a known absent selector result. Do not confuse omission with an undefined argument. |
| selector-conversion-order | A valid selector argument's Symbol.toPrimitive getter runs once, receives hint string, and returns the literal selector. A throwing getter/callback propagates its exact sentinel. An ignored extra argument's conversion hook remains untouched. |
| selector-live-tree-after-conversion | Valid argument conversion changes the target's descendants then returns a simple selector; the result reflects the new tree. Repeat on Element and Fragment. |
| append-borrow-and-return | EP/FP share within their interface, differ across interfaces, and call/apply/bind on another valid instance. Check undefined return, exact child/text order, and no mutation of the acquisition receiver. |
| append-brand-before-conversion | EP rejects Document/Fragment and FP rejects Document/Element before touching argument hooks; also plain object/Text/null/undefined. Valid same-interface control converts once. |
| append-all-conversions-before-mutation | Two conversion objects record order; second throws a unique sentinel. Check first callback's deliberate author effect survives, but the operation has not appended its prepared text/node arguments. Run both interfaces. |
| append-conversion-reentry | A conversion changes the destination before returning text; append reads that live destination. Include ordinary fragment child moves and template content without asserting custom-element reactions. |
| nonconstructable-and-no-own-prototype | All eight have no own prototype and reject new. Guard Reflect.construct on an ordinary constructor before using it to test a method as target/newTarget. Bound methods remain nonconstructable. |
| wrong-kind-member-absence | Fresh Text has no querySelector/querySelectorAll/append. A fixture comment is another public negative. Private tests cover other NodeKind variants and invalid ids. Avoid the in operator until its host-property behavior has its own guard. |
| inherited-node-methods-stay-shared | Element, Fragment and Text retain shared appendChild/removeChild/cloneNode function identities. Do not split these inherited Node operations by concrete kind. Exercise a valid borrowed Node operation. |

Keep the following ordinary standards-expectation rows separately visible as remaining prerequisites, rather than converting them into successful absence assertions: Document.append works; Document/Element/DocumentFragment constructors/prototypes and operation descriptors exist; own host method replacement/defineProperty/deletion behave as ordinary inherited properties. Proxy/foreign-realm variants, ShadowRoot, prepend/replaceChildren/moveBefore, NodeList/HTMLCollection branding and custom-element reactions are outside this increment. Existing Object.is Document-vs-Element rows must be replayed unchanged, with any gains observed rather than reauthored.

Guard and quota plan: one positive/wrong pair per operation row should perform a known successful call before the wrong expected literal. The wrong pair must fail with Test262Error in the same mode and reference the positive source fingerprint. Retain the exact common controls. Expected TypeError tests must also assert zero argument-hook effects; a missing method can otherwise create a false positive. Normal JavaScript argument-expression evaluation and apply's argument-list construction occur before native dispatch: do not claim those effects are suppressed by a receiver check. Keep policy rows distinct from ordinary behavior: bounded repeated method acquisition and cumulative function-property growth should retain terminal resource outcomes at unchanged limits, with no catch/reset that converts exhaustion to success.

Private admission tests should bind all eight static rows, unchanged legacy rows and exact initial descriptors; exact/one-short work and heap boundaries; a failed charge before any registry/object/order publication; invalid NodeId rejection before indexing; all public hot lookup and branding paths charged; no registry/DOM borrow across author conversion. Preserve the six existing dom_bindings test groups and dom-string-conversion.tsv bytes. Existing long-string/bootstrap tests remain relevant because the new eager initialization adds five metadata bags.

Current source anchors: dom_bindings.rs:4 shared21-row table, :35 eager metadata, :45 fresh wrapper lookup, :81 DOM receiver dispatch, :125 brand rejection, :226 append conversion, :271 selector conversion; script.rs:2225 metadata creation, :4390 name-keyed property bag, :4401 host prototype fallback, :5433/:5568 inherited lookup, :5698 Document and :5818 Node materialization, :7732 dispatch; machine/calls.rs:120 temporary invocation receiver; construction.rs:90 constructability.

The scratch browser fixture is a six-category integration smoke test, not the full matrix. Its initial/click phases, metadata restoration and brand effect counters are coherent. Two concrete changes were requested from root before freezing: (1) use genuinely different same-interface receivers in call/apply/bind positives, since calling on the acquisition receiver cannot detect accidental binding; (2) positively guard all three querySelectorAll functions and invoke each before pairwise inequality, because one missing value plus two distinct functions can satisfy all three inequality comparisons. Preserve its initial bytes and any correction receipt. Pixel samples should continue to use the established six-square helper; no rendered result is claimed here.

Root corrected both integration-fixture findings before execution. The reviewed final browser-fixture.html is SHA256 6033de0d5392516d3aa390dd3cf50e70d877dce289c943f4404c69d2c4635a04; the original and browser-fixture-correction.json remain retained. The delta seeds separate c/d children, targets other/second through call/apply/bind, and adds callable plus functional querySelectorAll guards. No further concrete fixture defect found in this bounded read.
