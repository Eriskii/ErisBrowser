# Scoped DOM defining-interface implementation and charging plan

Source-only, following Object.is runtime commit `8e2a2740ef1d63c9b3d0d2626400f8b125e4575c`. No production edits, compiler, engine, corpus or quota changes. This refines proposal.md; it does not release implementation before independent oracles and BEFORE runs.

## Owned seams and exact surface

Limit production changes to `src/script/dom_bindings.rs`, the Document/Node getter arms in `src/script.rs`, and a narrowly guarded **pre-clone** hook in `src/script/machine/calls.rs::invoke_native`. Root explicitly approved that third seam after source review found that the existing dotted-native call path clones `Native.name` before entering dom_native. Private additions can live in `src/script/dom_bindings/identity_tests.rs`; preserve all six existing test bodies and conversion fixture bytes.

Use private copied enums `ParentInterface::{Document,Element,DocumentFragment}`, `ParentOperation::{QuerySelector,QuerySelectorAll,Append}` and a static method descriptor with full internal name, dispatch suffix, public name, length, interface and operation. Eight rows:

| Interface | Operation | Full name | Public length |
| --- | --- | --- | ---: |
| Document | QuerySelector | DOM.Document.querySelector | 1 |
| Element | QuerySelector | DOM.Element.querySelector | 1 |
| DocumentFragment | QuerySelector | DOM.DocumentFragment.querySelector | 1 |
| Document | QuerySelectorAll | DOM.Document.querySelectorAll | 1 |
| Element | QuerySelectorAll | DOM.Element.querySelectorAll | 1 |
| DocumentFragment | QuerySelectorAll | DOM.DocumentFragment.querySelectorAll | 1 |
| Element | Append | DOM.Element.append | 0 |
| DocumentFragment | Append | DOM.DocumentFragment.append | 0 |

Public names are the operation spellings; longest full key is 37 ASCII bytes and longest public name is 16. No dynamically concatenated key, receiver node ID, namespace, tag or public name/length property participates in identity. Receiver keys remain Undefined for returned wrappers. Eager metadata registration has 26 rows, replacing the old three shared rows and adding five bags overall. Old shared names must no longer be registered or synthesized by author-reachable getters.

Keep the 18 unrelated rows, their full names, lengths and original initialization body (`work(full.len()+1)`, `charge(512+8*full.len())`, then intrinsic_function) exact. A simple scoped organization is the 18 legacy rows in their original relative order followed by the eight new static rows. No author code runs during that order change; arena indices remain private. Legacy getter lookup searches only the 18 legacy rows, so its existing `1 + METHODS.len()/8 + full.len()/8` debit is numerically unchanged (18/8 equals the old21/8). Do not route the new qualified rows through that legacy getter. This preserves legacy behavior and charges; it is not a claim that this increment audits every old generic DOM lookup/allocation.

## Per-row eager installer

Copy the small pinned B=6 bound locally rather than exporting/refactoring unrelated Object.is/DataView machinery. Define `(C(n),H(n))=tree_bound(n)` exactly as the accepted installers: n0 gives(0,0); otherwise start capacity=(n+1)/2, height1 and divide by6 while capacity>=6; C=min(n,11*height). Let `S(n,k)=C(n)*(1+k/8)` and `I(n)=28*(H(n)+1)`. Arithmetic saturates into terminal refusal or uses checked overflow errors before allocation.

Let R be the actual current native registry count, P the actual prototype-map count, F the row's full ASCII key length and L its public name's ASCII/UTF-16 length. For each new row, prepay the following before constructing keys, display strings, wrappers or a metadata bag:

`Wrow = (64 + 2*F + 2*L) + 2*S(R,F) + I(R) + S(P,6) + 2*S(0,4) + 2*S(1,6) + S(2,4) + S(2,6) + 15`.

The terms correspond to:

- Fixed setup and bounded text construction: two full-name copies (registry and returned Native), public-name UTF-16 construction and final payload copying. The64 allowance covers fixed name/length keys including both temporary attribute keys, short records/handles and setup. Do not infer this fee from desired bootstrap headroom.
- Registry contains+insert traversals and the full possible existing-tree insertion chain, including a new root.
- Object-prototype lookup performed by unchanged object_ordered.
- Fresh name/length contains+insert pairs, then both descriptor-rewrite lookups.
- Three fresh-leaf entry moves, four leaf/root setup operations, two order appends and six descriptor flag writes:15 logical units.

The28 units per possible level are24 fixed-size entry/edge updates plus4 setup operations, not bytes or CPU instructions. It is the reviewed pinned split bound, not amortized credit taken from earlier insertions.

Prepay external storage separately:

`Brow = 1536 + 8*(F+L) + N<PropertyKey,Property> + 4*sizeof(PropertyKey) + (H(R)+1)*N<String,usize>`

where `N<K,V> =16*(sizeof(K)+sizeof(V)) +32*sizeof(usize)+64` is the existing conservative actual-type B-tree node allowance.

The bounded1536+8*(F+L) payload allowance covers both full-name allocations, returned Native/Rc record (even though bootstrap discards it), display UTF-16 temporary/final payloads, name/length keys, temporary attribute keys, and fixed handle/header storage. This is limited to the eight short literal rows, not a formula for arbitrary text. Verify the actual Native/Rc and key type sizes remain within the declared fixed allowance in private tests. Four PropertyKey slots cover the pinned initial Vec growth for the fresh two-key order list; keep the existing size/growth premise explicit.

**Keep the generic object's base and both ordinary property debits intact:** `72 + sizeof(Option<AbortSlot>) + sizeof(Option<f64>)`, plus552 property bytes, are still charged inside intrinsic_function/object_ordered. Do not remove them, hide them in Brow, or charge a nonexistent owner-interface property insertion: real interface prototypes are still absent, so there is no owner property map/order for these new rows. The native registry and each function's own metadata bag are the only method maps published here.

There is also a reached **Runtime.objects arena growth** obligation for each new bag. Before the generic push, inspect length/capacity. If full, compute checked `requested=max(4,2*capacity,length+1)`, prepay `requested*sizeof(ScriptObject)` (the whole new requested block, no refund) and `1+2*length` fixed-size ScriptObject/header movement/setup work, then `try_reserve_exact(requested-length)`. The moved ScriptObject headers do not traverse their trees or Rc payloads. If spare capacity, do not charge or reserve an unperformed buffer growth. This is scoped to the newly installed rows; it does not retrofit every generic object allocation. Charge the row's work/storage first, then any reached arena reservation, then call unchanged intrinsic_function. Generic base/property refusals leave the partially built local bag unpublished; failed arena reservation leaves no row metadata published. Earlier completely installed rows may remain in the discarded initialization state; no rollback/refund is claimed.

One-time row uniqueness is a static integration premise, independently checked in tests. Do not silently add an uncharged contains_key duplicate precheck. If implementation chooses an explicit duplicate error, it must be an added charged lookup with a separately reviewed test. Generic already-registered behavior need not change. Physical allocator rounding, overhead and existing infallible B-tree/fresh-order allocation boundaries remain outside logical requested-byte guarantees; try_reserve is only the explicit arena reserve boundary.

## Getter and wrapper admission

Suggested helper: `pub(super) fn dom_parent_method(&mut self, receiver:&Value, operation:ParentOperation, doc:&Document)->Result<Value>`; ParentOperation also needs parent-visible visibility for the script.rs arms. No borrowed document node survives the helper.

1. Pay4 fixed units before a copied receiver classification: Value tag, NodeId/root bounds, indexed node access and NodeKind tag. Use `get`, never unchecked node indexing. Recognize actual Document, Element or DocumentFragment kinds; ordinary/template fragments share the same interface. Reject other kinds. Existing get's invalid-Node error guard stays in place; a direct helper invalid ID returns no method safely.
2. Pay2 fixed units before selecting the `(interface,operation)` descriptor by a fixed enum match. Missing combinations return Undefined without wrapper allocation. Document.append remains absent in its outer getter arm; the helper's missing combination is defensive, not a new exposure.
3. Before Self::native, pay `8+F` wrapper setup/name-copy work and `32+sizeof(Native)+2*sizeof(usize)+F` requested bytes. This covers the owned String payload, Native body, Rc strong/weak header and conservative allocation/header slack. Native already contains its String/Value headers: do not add their inline sizes again. The name is copied from the static row, never synthesized.
4. Return a fresh wrapper with Undefined receiver. Same-interface function properties resolve through the same registered full key, while other interfaces have separate bags. Getter success does not allocate another metadata bag. Failed work/heap admission leaves registry/objects/document unchanged.

Ordinary and inherited property lookup before host fallback stays where it is and retains its existing charges. Reflection/access through the resulting Native uses the existing registry/property lookup charging (reduce_property already accounts the name-tree searches). No new lookup of native_properties is needed merely to return an eagerly registered wrapper. Returned aliases can still be called after deleting/changing public name or length; those properties never control dispatch.

## Exact row resolution and branded dispatch

For borrowed full internal names at pre-clone, or borrowed dispatch suffixes after the existing `DOM.` strip, use a bounded eight-row resolver with static fields; no split allocation or constructed String. For each reached row, pay1 before the length comparison. When lengths match, pay `1 + compared_bytes/8` before the byte comparison. Stop at the first match. The two formats use their own stored static full/suffix strings and actual query length; do not compare full strings after subtracting an unvalidated prefix.

The fixed namespace guard checks only the first four ASCII bytes `DOM.` and next byte D/E before attempting this resolver in invoke_native. It reads at most five bytes, allocates nothing, and leaves all other native routes unchanged. These are the only selected namespaces, with the eight-row resolver validating the complete name. Include4 fixed recognition units on the selected route before resolver/copy admission. Unknown names in that private selected namespace are rejected without allocating a clone; no public author can invent Native.name. The corresponding suffix guard at dom_native checks only its first D/E byte before the paid suffix resolver. Preserve the existing dispatcher tick; selected dispatch then pays resolver work and4 units for copied receiver classification.

For a recognized row, compare its defining-interface tag with the current receiver before required-argument checks or DOMString conversion. A mismatched receiver gives TypeError with no author coercion. After a successful brand check, pass the row's static operation name into the unchanged existing operation body. Retain its argument count, dom_string conversion, append conversion-before-tree-mutation sequence, node/output/work charges, and error precedence. An extracted private operation-body helper or local normalized `name` is sufficient; do not duplicate selector/append algorithms. Keep direct private calls of existing tests to unqualified dom_native("append",...) working as the private shared algorithm entry, while all author-reachable selected getters emit only qualified keys. Never expose an unqualified alias or fall back to a broad receiver union after qualified brand failure.

No node/registry borrow crosses a conversion callback. The validated node ID and enum row are copied. Existing post-conversion DOM-operation checks/charges remain unchanged, including mutation caused by a coercion hook.

## Pre-clone call accounting and mandatory cleanup

Root approved this narrow extension to the initial proposal. `machine/calls.rs::invoke_native` currently enters its four stack units, then creates a temporary Native with `name: native.name.clone()` for dotted functions. Charging only inside dom_native would occur **after** that allocation. A getter debit cannot cover arbitrarily many calls of a saved alias.

For the selected namespace only, call a parent-visible `dom_parent_call_preflight(full:&str)->Result<()>` after enter_stack but **before** clone. It pays the selected guard/resolver above, rejects a non-row, then prepays `4+F` copy/setup work and `32+F` requested bytes for the temporary owned String. The temporary Native itself is stack storage, not another Rc allocation. The receiver is moved into it; do not charge or clone its contents. Existing argument forwarding/call frames retain their charges.

Put the fallible preflight and current cloned call inside the existing `result` expression, for example `preflight(...).and_then(|()| runtime.native_call(&Native{...}, arguments, doc))`. A closure returning Result is also suitable. **Do not use an early `?` between successful enter_stack and the final decrement.** Both refusal and DOM completion must reach `if !already_guarded { stack_units -=4; }`. The already_guarded path retains its outer ownership convention. Do not change NumberPredicate's shortcut, other Native name copies, bound/call/apply machinery, or any equality rule.

The pre-clone and branded-dispatch lookups are two real traversals and both are charged. Eliminating that duplicate traversal would require a different invocation interface; it is unnecessary for this bounded increment. This plan does not claim to fix the pre-existing name-copy accounting of every other intrinsic.

## Meaningful checks and limits

Layout owns independent fixture expectations; preserve its oracle and all old Object.is rows. Add private checks for:

- Exactly eight unique new registry keys with correct public metadata; no three stale shared keys; all18 legacy rows retain exact metadata/identity behavior. Net registration count +5 is a diagnostic, not a hardcoded runtime admission rule.
- Actual map sizes/types, pinned tree change points, full-node prepayment, four-slot order premise, exact/one-short per-row work and heap, and forced Runtime.objects capacity growth. A refusal never inserts that row or exposes a partial metadata bag; cumulative charged work/heap and earlier completed rows are not refunded.
- Getter at exact/one-short work/heap, wrong-kind/invalid IDs, no registry/bag creation on access, shared properties within an interface and isolation across interfaces, public-name edits without changed dispatch.
- Resolver exact reached row/length/text charges and selected invalid full names, never allocating concatenated keys.
- Pre-clone exact/one-short work and heap through an actual saved-function call. On refusal, no temporary-name allocation is reached, no author conversion or DOM mutation runs, and call/stack/frame ownership is clean. Exercise both unguarded and already-guarded forwarding ownership without double decrement.
- Brand failures preceding argument count/coercion; successful same-interface coercion once; append's existing all-conversion-before-mutation and terminal cutpoints. Preserve the six old DOM groups unchanged.
- Actual Runtime::new remaining work/heap and registry/object/order capacities, followed by unchanged maximum-string regressions and full historical replay. Eight fully charged installations cost more than a net-five count suggests; make no bootstrap-success prediction and do not lower fees or raise quotas to manufacture headroom.

The result fixes represented identity, independent function metadata and receiver branding for these eight existing operations. It does not add Document.append, real interface prototype objects/descriptors or host-member replacement, ShadowRoot, HTMLCollection/NodeList completeness, Proxy, foreign realms, or general DOM conformance.
