#!/usr/bin/env python3
"""Package one fixed, reviewed DOM preparation inventory into fresh scratch output."""
from pathlib import Path, PurePosixPath
import argparse
import gzip
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent


def require(ok, message):
    if not ok:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def safe_name(name):
    p = PurePosixPath(name)
    require(not p.is_absolute() and str(p) == name and p.parts and
            all(x not in ('', '.', '..') for x in p.parts), 'unsafe member name')
    require('__pycache__' not in p.parts and p.name not in ('STATE.md', 'source.tar')
            and p.suffix != '.pyc', 'forbidden payload name')


def read_bound(row, maximum=32*1024**2):
    p = Path(row['path'])
    require(p.is_file() and not p.is_symlink(), 'nonregular input: ' + str(p))
    require(0 <= row['bytes'] <= maximum and p.stat().st_size == row['bytes'], 'input size changed')
    raw = p.read_bytes()
    require(len(raw) == row['bytes'] and digest(raw) == row['sha256'], 'input hash changed: ' + str(p))
    return raw


def add(archive, name, raw):
    safe_name(name)
    require(not raw.startswith(b'\x7fELF'), 'binary payload prohibited')
    info = tarfile.TarInfo(name)
    info.size = len(raw)
    info.mode = 0o644
    info.mtime = info.uid = info.gid = 0
    info.uname = info.gname = ''
    archive.addfile(info, io.BytesIO(raw))


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest', type=Path, default=HERE / 'inputs.json')
    ap.add_argument('--sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    args = ap.parse_args()
    raw_manifest = args.manifest.read_bytes()
    require(len(raw_manifest) <= 1024**2 and digest(raw_manifest) == args.sha256, 'manifest binding')
    manifest = json.loads(raw_manifest)
    own = next(r for r in manifest['payloads'] if r['member'] == 'packaging/pack.py')
    require(Path(own['path']).resolve() == Path(__file__).resolve(), 'wrong packer path')
    require(read_bound(own) == Path(__file__).read_bytes(), 'packer binding')
    rows = manifest['payloads']
    require(0 < len(rows) <= 256 and len({r['member'] for r in rows}) == len(rows), 'payload inventory')
    require('MANIFEST.json' not in {r['member'] for r in rows}, 'manifest collision')
    require(sum(r['bytes'] for r in rows) <= 16*1024**2, 'payload total limit')
    for row in rows:
        safe_name(row['member'])
        read_bound(row)
    for row in manifest['external_bindings']:
        read_bound(row, 64*1024**2)
    output = args.output.absolute()
    require(output.parent == HERE.parent and output.name.startswith('publication-package-')
            and not output.exists(), 'fresh adjacent scratch package required')
    output.mkdir()
    archive_path = output / 'records.tar.gz'
    with archive_path.open('xb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
                add(archive, 'MANIFEST.json', raw_manifest)
                for row in rows:
                    add(archive, row['member'], read_bound(row))
    expected = {'MANIFEST.json': dict(bytes=len(raw_manifest), sha256=digest(raw_manifest)),
                **{r['member']: r for r in rows}}
    with tarfile.open(archive_path, 'r:gz') as archive:
        members = archive.getmembers()
        require(len(members) == len(expected) and len({m.name for m in members}) == len(members), 'archive count')
        require({m.name for m in members} == set(expected), 'archive member inventory')
        for member in members:
            row = expected[member.name]
            require(member.isfile() and member.size == row['bytes'] and member.mode == 0o644
                    and member.mtime == member.uid == member.gid == 0, 'archive metadata')
            with archive.extractfile(member) as handle:
                raw = handle.read()
            require(digest(raw) == row['sha256'] and not raw.startswith(b'\x7fELF'), 'archive payload')
    require(args.manifest.read_bytes() == raw_manifest, 'manifest changed during package')
    for row in rows:
        read_bound(row)
    for row in manifest['external_bindings']:
        read_bound(row, 64*1024**2)
    archive_raw = archive_path.read_bytes()
    index = dict(schema=1, scope='DOM defining-interface local preparation and BEFORE only; no implementation result',
        parent=manifest['parent'], archive=dict(path='records.tar.gz', bytes=len(archive_raw), sha256=digest(archive_raw)),
        manifest_sha256=digest(raw_manifest), payload_count=len(rows), archive_member_count=len(rows)+1,
        payload_bytes=sum(r['bytes'] for r in rows), payloads=rows,
        counts=manifest['counts'], before=manifest['before'], reviews=manifest['reviews'],
        external_provenance=manifest['external_provenance'], omissions=manifest['omissions'],
        no_new_runtime_or_conformance_gate_claim=True)
    with (output / 'index.json').open('x') as handle:
        json.dump(index, handle, indent=2); handle.write('\n')
    print(json.dumps(dict(output=str(output), payloads=len(rows), archive=index['archive']), sort_keys=True))


if __name__ == '__main__':
    main()
