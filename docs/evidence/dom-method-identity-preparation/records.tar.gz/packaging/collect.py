#!/usr/bin/env python3
"""Seal only immutable DOM preparation data and public predecessor references."""
from pathlib import Path
import hashlib
import json
import tarfile

HERE = Path(__file__).resolve().parent
WORK = HERE.parent
ROOT = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
PARENT = '8e2a2740ef1d63c9b3d0d2626400f8b125e4575c'


def read(path):
    return json.loads(Path(path).read_bytes())


def bind(path):
    path = Path(path)
    assert path.is_file() and not path.is_symlink()
    with path.open('rb') as handle:
        digest = hashlib.file_digest(handle, 'sha256').hexdigest()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=digest)


def save(name, value):
    with (HERE / name).open('x') as handle:
        json.dump(value, handle, indent=2); handle.write('\n')


assert __debug__
save('read-errors.json', dict(schema=1, events=[dict(
    operation='Interactive inspection of the two predecessor evidence index schemas',
    failure='TypeError: object of type int has no len()',
    cause='The preparation index payloads field is a count; the runtime index uses a list.',
    resolution='Read the preparation archive member inventory using its actual index schema.',
    effect='No source, report, manifest or verdict changed; no engines or packer were executed.')]))
roots = ('initial-property-helper-review', 'local-preparation', 'local-before')
paths = [p for p in WORK.iterdir() if p.is_file() and p.name != 'STATE.md']
paths += [p for name in roots for p in (WORK / name).rglob('*')
          if p.is_file() and '__pycache__' not in p.parts and p.suffix != '.pyc']
rows = [dict(**bind(p), member='preparation/' + str(p.relative_to(WORK))) for p in paths]
public = ('tests/conformance/dom-method-identity-local-oracle.json',
          'tests/conformance/dom-method-identity-local-before.json',
          'tests/conformance/dom-method-identity-local.js',
          'tests/conformance/dom-method-identity.md', 'docs/ROADMAP.md',
          'docs/evidence/object-is-runtime-ci.json')
rows += [dict(**bind(ROOT / name), member='public/' + name) for name in public]
for name in ('pack.py', 'collect.py', 'read-errors.json'):
    rows.append(dict(**bind(HERE / name), member='packaging/' + name))
rows.sort(key=lambda r: r['member'])
assert len(rows) <= 256 and len({r['member'] for r in rows}) == len(rows)
for original, published in [('local-oracle-draft-2.json', public[0]),
                            ('local-before/report.json', public[1]),
                            ('local-oracle-draft-2.js', public[2])]:
    assert (WORK / original).read_bytes() == (ROOT / published).read_bytes()
assert bind(ROOT / public[3])['sha256'] == '31e02978a7df25c8f45321dc89eaf9db746bf5601291b27b9dc40fd56c04abf1'
report = read(WORK / 'local-before/report.json')
audit = read(WORK / 'before-results-review.json')
assert audit['result'] == 'clear' and audit['findings'] == []
assert report['counts'] == {'passed': 30, 'failed': 24, 'resource': 4}
assert report['controls_verified'] == 44 and report['fixture_expectations_verified'] == 34
external = []
provenance = []
for label in ('object-is-runtime', 'object-is-preparation'):
    index_path = ROOT / 'docs/evidence' / label / 'index.json'
    index = read(index_path)
    archive_path = index_path.parent / index['archive']['path']
    archive_row = bind(archive_path)
    assert {k: archive_row[k] for k in ('bytes', 'sha256')} == {k: index['archive'][k] for k in ('bytes', 'sha256')}
    external.extend([bind(index_path), archive_row])
    provenance.append(dict(label=label, published_index=str(index_path.relative_to(ROOT)),
                           index=bind(index_path), archive=archive_row))
runtime_index = read(ROOT / 'docs/evidence/object-is-runtime/index.json')
helper_references = []
for name in ('/tmp/eris-array-buffer-historical-local-replay.py',
             '/tmp/eris-for-in-length-buckets-1/replay-preparation/replay.py'):
    matches = [r for r in runtime_index['payloads'] if r['path'] == name]
    assert len(matches) == 1
    row = matches[0]
    assert {k: bind(name)[k] for k in ('bytes', 'sha256')} == {k: row[k] for k in ('bytes', 'sha256')}
    helper_references.append(dict(origin=name, public_index='docs/evidence/object-is-runtime/index.json',
                                  member=row['member'], bytes=row['bytes'], sha256=row['sha256']))
preparation_index = read(ROOT / 'docs/evidence/object-is-preparation/index.json')
with tarfile.open(ROOT / 'docs/evidence/object-is-preparation' / preparation_index['archive']['path'], 'r:gz') as archive:
    for name in ('run.py', 'replay.py', 'runner-matrix.json'):
        member = 'local-preparation/' + name
        path = Path('/tmp/eris-object-is-preparation-1') / member
        with archive.extractfile(member) as handle:
            raw = handle.read()
        assert raw == path.read_bytes()
        helper_references.append(dict(origin=str(path), public_index='docs/evidence/object-is-preparation/index.json',
                                      member=member, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest()))
before = read(WORK / 'local-preparation/replay-inputs.json')['before']
candidate = Path(before['candidate'])
release = read(WORK / 'local-before/execution.json')['release']
for row in release.values():
    assert bind(row['path']) == row
    external.append(row)
assert len(read(candidate / 'archive-inputs.json')['files']) == 418
references = dict(parent_commit=PARENT, packages=provenance,
    candidate_runtime_public_index='docs/evidence/object-is-runtime/index.json',
    candidate_archive_input_member='work/candidate-2/archive-inputs.json',
    candidate_source_reconstruction='Published runtime parent9eddd040 plus its six candidate2 overlays reconstruct all418 members; the full original archive remains scratch-only.',
    inherited_helpers=helper_references,
    root_launch_environment=dict(git_commit=PARENT, path='tools/run.py', **{k:v for k,v in bind(ROOT/'tools/run.py').items() if k!='path'}))
save('inputs.json', dict(schema=1, parent=PARENT,
    scope='New local DOM defining-interface preparation and BEFORE; original Object.is controls and provenance retained',
    payloads=rows, external_bindings=sorted({r['path']:r for r in external}.values(), key=lambda r:r['path']),
    counts=dict(sources=29, case_modes=58, feature_control_modes=32, common_control_modes=12, rows=102),
    before=dict(**before, archive_members=418, raw_counts=report['counts'],
                controls_verified=44, matched_expectations=34,
                observations='One root-owned BEFORE; six ordinary prerequisite modes remain failures and four explicit policy modes remain terminal resources.'),
    reviews={name:bind(WORK/name) for name in (
        'before-results-review.json', 'script-local-oracle-review-final.json',
        'layout-local-runner-review-final.json', 'layout-charge-plan-review.json',
        'root-before-driver-review.json', 'root-source-review-followup.json')},
    external_provenance=references,
    omissions=['Mutable STATE.md, __pycache__ and bytecode.',
               'Concurrent runtime implementation and future candidate replay preparation/results.',
               'No ELF executable or duplicate old source.tar; the published Object.is source reconstruction and binary/archive hashes are referenced.',
               'No new upstream corpus import or Git proof collection belongs to this local DOM increment.']))
print(json.dumps(dict(manifest=bind(HERE / 'inputs.json'), payloads=len(rows),
                     payload_bytes=sum(r['bytes'] for r in rows)), sort_keys=True))
