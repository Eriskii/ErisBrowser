"""Root-only execution handoff. Authoring this file does not run the importer."""
import hashlib
import json
from pathlib import Path
import sys

HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parent / 'worktree'
sys.path.insert(0, str(WORKTREE / 'tools'))
import import_test262 as importer

roster = json.loads((HERE / 'offline-inventory.json').read_bytes())
files = {}
for row in roster['files']:
    path = HERE / 'offline-inputs' / row['path']
    if path.is_symlink():
        raise ValueError('offline source symlink')
    data = path.read_bytes()
    if len(data) != row['bytes'] or hashlib.sha256(data).hexdigest() != row['sha256']:
        raise ValueError('offline source changed: ' + row['path'])
    files[row['path']] = data

requests = []
raw = f'https://raw.githubusercontent.com/{importer.REPOSITORY}/{importer.REVISION}/'
api = f'https://api.github.com/repos/{importer.REPOSITORY}/git/'


def fetch(url):
    if url.startswith(api):
        path = importer.tree_proof_path(url[len(api):])
    elif url.startswith(raw):
        path = url[len(raw):]
    else:
        raise ValueError('unbound offline URL: ' + url)
    requests.append(path)
    return files[path]


importer.fetch = fetch
importer.import_corpus(WORKTREE / 'tests/upstream/test262-typedarray-views', 'typedarray-views')
if len(requests) != 125 or set(requests) != files.keys():
    raise ValueError('offline request inventory differs from 103 sources, 10 auxiliaries, 12 proofs')
print(json.dumps({'profile': 'typedarray-views', 'offline_requests': len(requests),
                  'network': False, 'engine': False, 'bodies': 103, 'modes': 206}, sort_keys=True))
