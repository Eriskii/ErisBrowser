# Startup cost and admissible next step

The current Reflect candidate has a root-owned raw diagnostic of496 remaining work,1872268 charged bytes,730 objects/capacity,320 native-registry entries and25 intrinsic prototypes. The original496 prediction and later diagnostic are separately retained. Publication is still pending. The following is an explicit **conservative planning envelope**, not a measured fee, a minimum theoretical cost, or a source-ready implementation ledger.

An append-last installer preserves all existing installer input shapes and metadata IDs. It allocates one cached subarray native/bag after the existing objects, retrieves and clones the actual Array.prototype.toString value, and appends subarray then toString to the shared TypedArray prototype. It publishes no global/registry entry and adds no State. Its guard admits the known private stage: original10-entry shared owner/order,25 intrinsic prototypes, the30-entry Array owner, one reserved arena slot. The new keys are source-proven absent at that private stage; the two paid Entry operations each enforce vacancy without an extra contains_key search. Array's30 stored keys derive from constructor1, initial methods4, subsequent methods19, splice/concat2 and iterator properties4; Array length is virtual.

| Work row | Proposed reservation |
|---|---:|
| Fixed stage checks |32|
| Array intrinsic lookup, at most22 comparisons of5-byte key plus setup per comparison |132|
| Array.toString own lookup, at most22 comparisons of8-unit key |198|
| Four texts length/name/subarray/toString:26 units,8+2n each |84|
| Fresh bag helper |9|
| Fresh two-entry sorted leaf:16+2×18+6 |58|
| Cached native full name TypedArray.subarray:8+19 |27|
| Two owner Entry lookups:10×9+11×9 |189|
| First insertion at10 entries, no split, three suffix pairs:32+4×3 |44|
| Full-leaf insertion with new root:256×2+32 |544|
| Ten old order handles moved plus reserve/control |28|
| Remaining fixed handle/descriptor/publication control |32|
| **Total** |**1377**|

The guard/control rows are proposed logical-operation envelopes and require line correspondence once an implementation exists; they do not certify code not yet written. The entry structural rows reuse the previously accepted conservative movement convention. A 12-key result has exactly one root and two leaves here, so admit two additional owner nodes. This avoids pretending the old all-leaf proof covers the new owner. The second structural reservation alone is544, already above496. The complete conservative plan exceeds startup headroom by881.

Storage is `360 +(72+A+D) +2K +(N+32+19) +3Bpp +20K +S`: four text buffers; new bag base and two order slots; cached native/name; new bag leaf plus two owner nodes; replacement/grown20-slot owner order vector; and one additional ScriptObject in the early arena reservation. At retained A16,D16,K16,N56,Bpp1472,S216 this is5555 newly charged bytes. The toString alias clones an Rc and adds no native allocation. No source buffer or element bytes are copied. These typed terms are a plan, not newly measured allocation.

A tighter implementation could preserve the single-leaf first insertion and prove the one concrete full-leaf split operation-by-operation, or build the final12-key owner directly from a sorted fixed roster before publication. It would still need to pay all new names, metadata, alias lookup/identity, typed nodes/order storage and cleanup, and preserve original IDs/creation order. Reusing the old MAP_WORK constant or dropping its split allowance is not a proof. If the complete peer-reviewed ledger still exceeds496, the next prerequisite should remove actual repeated bootstrap lookup/construction work, with the original fees/measurement retained and the saving measured separately. There is no proposed budget reset, quota increase, lazy metadata exposure or blanket test weakening.

This assessment therefore supports the semantic increment but does **not** claim its bootstrap installation is ready. Choose and seal the exact construction/saving ledger before production implementation; root owns subsequent measurement and descriptive snapshot changes.
