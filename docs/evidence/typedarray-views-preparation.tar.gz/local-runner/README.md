# Local runner source handoff

The only project-owned paths are tools/typedarray_views_local.py,
tools/test_typedarray_views_local.py and tests/conformance/typedarray-views-local.
The ten originally held fixture/data files are byte-exact. RUNNER.md is an
additional execution contract, not a modification of the frozen oracles.

The new runner is the published Reflect local runner with only profile
identities, counts and input pins changed. Since the original new fixture
manifest already includes matrix.json, the supplemental input list omits its
duplicate. transformation.json proves exact reversal for the entire runner and
four byte-identical helper bodies. runner.diff and the original are retained.
No project runner import, verification, test, compiler, engine or parser was
executed by this author. Ten mocked protocol groups are source-only pending
root execution. These tests use an inert module substitute and an unexecutable
byte placeholder instead of any adapter process.

Root handoff commands, to be executed only after source/dependency review:

    python3 tools/typedarray_views_local.py --verify-only
    python3 -m unittest discover -s tools -p 'test_typedarray_views_local.py'
    python3 tools/typedarray_views_local.py --engine /tmp/eris-typedarray-views-1/eris-js-before --engine-sha256 c21074ad37ed121547e6386dd529c67c6c438a6a0b2a6583d453118c49ef78e8 --output /tmp/eris-typedarray-views-1/local-before.json

The third command will produce actual baseline rows; none have been generated
here. No candidate observations are predicted. Shared test262_conformance,
import_test262 and html_conformance bytes are captured as read context, while
Script owns their upstream-profile edits/final hold. Root must bind the final
shared source before executing. The runner also binds actual helper files both
before import and after every request has been collected. Upstream feature
controls are an exact copy of the independent six pairs; they are read only by
that profile's preflight, not by the local execution path.
