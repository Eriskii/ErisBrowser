from pathlib import Path
import gzip,hashlib,io,json,subprocess,tarfile
R=Path(__file__).resolve().parent;W=R/'worktree'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def js(p):return json.loads(p.read_text())
up=js(R/'upstream-before.json');local=js(R/'local-before.json')
assert up['counts']=={'passed':10,'failed':88,'unsupported':96,'resource':12}
assert up['mode_cases']==206 and not up['harness_preflight_passed']
assert len(up['harness_preflight'])==56 and sum(x['verified'] for x in up['harness_preflight'])==36
assert local['summary']=={'case_matches':0,'case_total':46,'control_matches':4,'controls_verified':4,'control_total':24,'runner_errors':0}
assert not local['binding_failures']
assert up['binary_sha256']==local['binary_sha256']==js(R/'before-adapter.json')['sha256']
labels=['local-verify-1','local-protocols-1','local-before-1','upstream-offline-import-1','upstream-before-1','test262-protocols-1']
for label in labels:
 record=js(R/'validation'/(label+'.json'))
 assert record['exit']==(1 if label in ['local-before-1','upstream-before-1'] else 0)
 assert record['sha256']==sha(R/'validation'/(label+'.log'))
assert 'Ran 284 tests' in (R/'validation/test262-protocols-1.log').read_text()
assert 'Ran 10 tests' in (R/'validation/local-protocols-1.log').read_text()
roots=['before-adapter.json','local-before.json','upstream-before.json','reflect-ci-observation-1.json','run-tool.py','package-preparation.py','foundation-context.json','acquisition-note.json','source-bindings.json','proposal.md','candidate-followthrough.json','bootstrap-plan.json','bootstrap-cost.md','primary-sources.json','source-ready.json']
dirs=['local-fixtures','local-runner','conformance','upstream','source','root-evidence','join-expansion']
paths=[p for d in dirs for p in (R/d).rglob('*') if p.is_file()]+[R/n for n in roots]+[R/'validation'/(label+suffix) for label in labels for suffix in ['.log','.json']]
assert all(not p.is_symlink() for p in paths)
rows=[{'path':str(p.relative_to(R)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(set(paths))]
manifest={'format':1,'scope':'TypedArray views and string conversion corpus preparation and published-engine before observations; no runtime implementation result','files':rows}
raw=(json.dumps(manifest,indent=2)+'\n').encode()
out=W/'docs/evidence/typedarray-views-preparation.tar.gz'
with out.open('xb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w',format=tarfile.PAX_FORMAT) as tar:
   for name,data in [('manifest.json',raw)]+[(row['path'],(R/row['path']).read_bytes()) for row in rows]:
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
modified=subprocess.check_output(['git','ls-files','-m','-o','--exclude-standard'],cwd=W,text=True).splitlines()
public={rel:sha(W/rel) for rel in modified if (W/rel).is_file() and (rel.startswith(('tools/','tests/upstream/test262-typedarray-views/','tests/conformance/typedarray-views-local/')) or rel in {'docs/typedarray-views-test262.md','tests/conformance/typedarray-views-local-before.json','tests/conformance/test262-typedarray-views-before.json'})}
record={'format':1,'status':'Frozen TypedArray views and string conversion test preparation; full browser goal remains incomplete','base':'a3c0bb1d5167236cdf676247f17aea3720dcb866','revision':up['revision'],'before_adapter':js(R/'before-adapter.json'),'upstream':{'source_files':103,'modes':206,'counts':up['counts'],'controls_verified':36,'control_modes':56,'harness_healthy':False,'exit':1,'report':'tests/conformance/test262-typedarray-views-before.json','sha256':sha(R/'upstream-before.json'),'note':'Absent methods can throw TypeError expected by negative tests; unhealthy preflight prevents a compatibility claim.'},'local':{'summary':local['summary'],'binding_failures':[],'exit':1,'report':'tests/conformance/typedarray-views-local-before.json','sha256':sha(R/'local-before.json')},'protocol_tests':{'test262_groups':284,'local_groups':10,'test262_run':'validation/test262-protocols-1.json','local_run':'validation/local-protocols-1.json'},'public_file_sha256':public,'archive':{'path':out.name,'bytes':out.stat().st_size,'sha256':sha(out),'records':len(rows),'manifest_sha256':hashlib.sha256(raw).hexdigest()},'limits':['No Rust runtime change in this preparation commit.','All103 original bodies and206 modes retained;96 explicit unsupported modes.','The complete resizableArrayBufferUtils.js helper exclusion is restricted to this new profile; original sources remain present.','Existing profiles, policies and committed baseline reports retained.','Before executable is byte-identical to the validated published Reflect adapter.','No conformance, production-security or Chromium-performance completion claim.']}
dest=W/'docs/evidence/typedarray-views-preparation.json'
with dest.open('x') as f:json.dump(record,f,indent=2);f.write('\n')
stage=sorted([*public,'docs/evidence/typedarray-views-preparation.tar.gz','docs/evidence/typedarray-views-preparation.json'])
(R/'preparation-stage-paths.json').write_text(json.dumps(stage,indent=2)+'\n')
print(json.dumps({'archive':record['archive'],'evidence_sha256':sha(dest),'stage_paths':len(stage)},indent=2))
