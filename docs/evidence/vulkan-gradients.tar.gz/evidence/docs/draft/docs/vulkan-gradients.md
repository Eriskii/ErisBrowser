# Native gradient fragments

The native raster path accepts an opaque, square-corner linear gradient outside
all opacity scopes. The CPU evaluates its visible pixels with the same helper
as Canvas, then the existing GPU image shader copies that fragment into the
scene. Gradient interpolation remains on the CPU.

```sh
cargo run --locked --release --features vulkan-raster -- \
  ./examples/vulkan-gradients.html --presenter=vulkan --raster=gpu
```

The example has an interpolated ramp, a clickable hard edge using `currentColor`,
and a fixed-position solid gradient. Clicking changes the two hard-edge colors
without changing the element tree or hit regions.

## Admission and pixels

Every resolved stop, including `currentColor`, must have alpha 255; the radius
must be zero. Any enclosing opacity scope refuses the gradient, including an
explicit opacity of one. Transparent stops and rounded gradients also retain
whole-scene software fallback even when clipped or hidden. Existing non-gradient
opacity rendering is unchanged.

The helper samples the original translated tile at framebuffer pixel centers.
It preserves angle/corner geometry, length and percentage stops, zoom scaling,
background repetition, fractional clips and document/fixed offsets. The fragment
covers only the effective integer window; cropping does not restart its tile.
No cache or persistent generated image is added.

A bounded core `ScreenImage` command places that fragment at an absolute integer
framebuffer origin. It checks source, window, viewport and active clip bounds,
then uses the existing source packing, identity lookup tables and image shader.
Offsets are not applied a second time. The browser display-list/worker command
remains `LinearGradient`; `ScreenImage` is internal to native preparation.

## Shared limits

For `N` stops and `P` candidate pixels in Canvas's clipped destination loop,
the existing evaluation tariff is `T = 4*N + P*(ceil(log2(N)) + 2)`.
Native preparation reserves `T + Q`, where `Q` is the number of pixels written
to the generated fragment. It also retains the existing source packing, lookup,
command and GPU admission checks. Allocation and writes follow admission.

Loaded images and generated fragments share the unchanged **1 MiB RGBA-source
allowance** and **256 source slots** across the whole scene. A large gradient
may therefore still fall back. Viewport, command, scope, phase, invocation and
GPU-buffer caps are unchanged. Partially prepared owners are dropped on refusal;
no partial native scene is submitted.

Statistics keep loaded-image and generated-gradient counts/bytes separate and
report generated evaluation/preparation work. Generated pixels are uploaded to
the GPU, so avoiding a whole CPU framebuffer upload does not mean avoiding CPU
pixel generation or all pixel uploads. Preparation peak storage includes both
the temporary generated owners and their packed-plan copy.

## Validation status

**Pending:** root-run predecessor/candidate tests, strict checks and actual
adapter observations. The frozen fixture inventory contains three independent
literal frames: interpolation/pixel-stop scaling/currentColor, repeated corners
with fractional clipping, and fractional document/fixed scope restoration.
Canvas and packed Native records are checked against the literals before GPU
work. The dedicated checker reuses the existing offscreen Native surface runner
in BGRA and RGBA formats: six expected frame comparisons, 608 active pixel bytes
per adapter. These are planned checks, not observed results.

Direct Page and confined-worker click tests use the same HTML and literal pixel
expectations; their retained predecessor wrapper changes only the expected
native admission. Earlier GPU fixture rosters and caps remain unchanged.
No acquired-window or timing run is part of this checkpoint's current evidence.
There is no performance, full CSS, security or broad hardware-compatibility claim.
