#!/usr/bin/env python3
"""Root-only publisher for explicitly selected native-gradient evidence."""
from pathlib import Path, PurePosixPath
import gzip, hashlib, io, json, re, subprocess, sys, tarfile

P = Path(__file__).resolve().parent
W = P / 'worktree'
Q = Path('/tmp/eris-gradient-vulkan-preparation-1')
BASE = '71697d5539c932291ea245b4092b1261bea609e6'
STEM = 'vulkan-gradients'
LIMIT = 64 * 1024 * 1024

def require(value, message):
    if not value: raise ValueError(message)

def sha(data): return hashlib.sha256(data).hexdigest()
def encoded(value): return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()
def binding(path):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and path == path.resolve(), 'canonical regular file required')
    require(not any(p.is_symlink() for p in (path, *path.parents)), 'symlink input')
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}

def read(row):
    require(binding(row['path']) == row, 'changed input: ' + row['path'])
    return Path(row['path']).read_bytes()

def git(root, *args): return subprocess.check_output(['git', '-C', str(root), *args])
def relative(name):
    path = PurePosixPath(name)
    require(name and not path.is_absolute() and '..' not in path.parts and path.as_posix() == name, 'relative path')
    return name

def rust_totals(log, expected):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log)
    actual = {'rows': len(rows), 'passed': sum(int(r[1]) for r in rows),
              'failed': sum(int(r[2]) for r in rows), 'ignored': sum(int(r[3]) for r in rows)}
    require(actual == expected, 'raw Rust totals')
    require(all(r[0] == ('ok' if r[2] == '0' else 'FAILED') for r in rows), 'Rust result labels')

def main():
    selected = binding(sys.argv[1]); selection = json.loads(read(selected))
    require(git(W, 'rev-parse', 'HEAD').decode().strip() == BASE, 'worktree base')
    source = selection['live_source']; inventory = json.loads(read(source))
    require(inventory['base'] == BASE and len(inventory['source_sha256']) == selection['source_count'] and selection['source_count'] >= 509, 'source identity/population')
    for name, digest in inventory['source_sha256'].items():
        require(binding(W / relative(name))['sha256'] == digest, 'live source changed: ' + name)
    changed = set((git(W, 'diff', 'HEAD', '--name-only', '-z') + git(W, 'ls-files', '--others', '--exclude-standard', '-z')).decode().split('\0')) - {''}
    require(changed == set(selection['published']), 'exact changed/publication roster')
    for name, row in selection['published'].items():
        require(row['path'] == str(W / relative(name)), 'published path')
        read(row)
        if not name.endswith('.md'):
            require(inventory['source_sha256'].get(name) == row['sha256'], 'unbound changed runtime input')
    verified = [source]; receipts = {}; logs = {}
    for label, item in selection['checks'].items():
        receipt = json.loads(read(item['receipt'])); raw = read(item['log'])
        require(receipt['command'] == item['command'] and receipt['exit'] == item['expected_exit'], 'check argv/exit: ' + label)
        require(receipt['sha256'] == sha(raw), 'log hash: ' + label)
        require(str(Path(item['receipt']['path']).parent / receipt['log']) == item['log']['path'], 'receipt log path')
        verified.extend([item['receipt'], item['log']]); receipts[label] = receipt; logs[label] = raw.decode()
        if 'source' in item: read(item['source']); verified.append(item['source'])
        if 'rust' in item: rust_totals(logs[label], item['rust'])
    for label in ('core-test-1', 'core-clippy-198-1', 'core-clippy-198-2', 'core-gpu-test-2', 'probe-clippy-1', 'clippy-native-198-1'):
        require(receipts[label]['exit'] == 101, 'retained original failed check: ' + label)
    require(set(selection['full_suites']) == {'native', 'default'}, 'both full suites required')
    for role, label in selection['full_suites'].items():
        item = selection['checks'][label]; result = item['rust']
        require(receipts[label]['exit'] == 0 and result['rows'] == 29 and result['failed'] == result['ignored'] == 0, 'complete successful suite')
        require(item['source'] == source, 'suite/final source join')
        argv = receipts[label]['command']
        expected = ['cargo', '+1.88.0' if role == 'native' else '+1.98.0', 'test', '--locked', '--offline', '--manifest-path', 'Cargo.toml']
        if role == 'native': expected += ['--features', 'vulkan-raster']
        require(argv == expected + ['--', '--include-ignored', '--test-threads=4'], 'full suite command')
    binaries = {}
    require(set(selection['binaries']) == {'browser', 'probe'}, 'two selected binaries')
    for role, item in selection['binaries'].items():
        record = json.loads(read(item['record'])); binaries[role] = record
        require(binding(record['path']) == {k: record[k] for k in ('path', 'bytes', 'sha256')}, 'binary bytes')
        require((record['source'], record['source_sha256']) == (source['path'], source['sha256']), 'binary/source join')
        build = selection['checks'][item['build']]; strip = selection['checks'][item['strip']]
        require(record['build_receipt'] == build['receipt']['path'] and record['strip_receipt'] == strip['receipt']['path'], 'binary receipt joins')
        require(build['source'] == strip['source'] == source, 'build/source joins')
        manifest, binary = ('Cargo.toml', 'eris-browser') if role == 'browser' else ('tools/vulkan-raster-probe/Cargo.toml', 'eris-vulkan-gradient-check')
        argv = ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path', manifest,
                '--features', 'vulkan-raster' if role == 'browser' else 'browser-bridge']
        require(receipts[item['build']]['command'] == argv + ['--bin', binary], 'selected binary build command')
        require(receipts[item['strip']]['command'] == ['strip', '--strip-debug', record['path']], 'strip command')
        require(receipts[item['build']]['exit'] == receipts[item['strip']]['exit'] == 0, 'successful binary preparation')
        verified.append(item['record'])
    report_item = selection['reftests']; report = json.loads(read(report_item['report'])); manifest = json.loads(read(report_item['manifest']))
    require(report['suite'] == 'eris-self-authored-reftests' and report['conformance_claim'] is False, 'reference scope')
    require((report['passed'], report['failed'], report['total']) == (68, 0, 68), 'final references')
    require(len(manifest['cases']) == 68 and [r['name'] for r in report['cases']] == [r['name'] for r in manifest['cases']], 'reference roster')
    require(len({r['name'] for r in report['cases']}) == 68, 'duplicate references')
    require(all(r['status'] == 'pass' and r['different_pixels'] == r['maximum_channel_error'] == 0 for r in report['cases']), 'reference pixels')
    require(report['viewport'] == {'width': manifest['width'], 'height': manifest['height']}, 'reference viewport')
    require(report_item['manifest']['path'] == str(W / 'tests/reftests/manifest.json'), 'reference manifest path')
    require(sha(git(W, 'show', BASE + ':tests/reftests/manifest.json')) == report_item['manifest']['sha256'], 'unchanged reference manifest')
    argv = receipts[report_item['check']]['command']
    require(argv == ['python3', str(W / 'tools/reftest.py'), '--binary', binaries['browser']['path'], '--output-dir', str(Path(report_item['report']['path']).parent)], 'reference command/binary/output')
    require(report['binary'] == binaries['browser']['path'] and receipts[report_item['check']]['exit'] == 0, 'reference selected binary')
    verified.extend([report_item['report'], report_item['manifest']])
    fixtures = {'gradient-ramp-px-scale-current-color': (4, 48), 'gradient-repeated-corner-fractional-clip': (3, 128), 'gradient-document-fixed-fractional-restoration': (5, 128)}
    prefix = selection['gpu_prefix']
    require(len(prefix) == 2 and prefix[0] == 'env' and prefix[1].startswith('LD_LIBRARY_PATH='), 'explicit GPU loader prefix')
    loader = Path(prefix[1].split('=', 1)[1]); require(loader.is_absolute() and loader.is_dir() and loader == loader.resolve(), 'canonical loader directory')
    list_label = selection['gpu_list']; require(receipts[list_label]['exit'] == 0 and receipts[list_label]['command'] == prefix + [binaries['probe']['path'], '--list'], 'GPU enumeration')
    identities = [s for s in logs[list_label].splitlines() if s.startswith('ADAPTER ')]
    ids = [int(re.match(r'ADAPTER (\d+) ', s).group(1)) for s in identities]
    require(identities and len(set(ids)) == len(ids), 'adapter identity inventory')
    adapters = set(); require(len(selection['gpu']) == 3, 'three GPU observations')
    for item in selection['gpu']:
        label, adapter = item['check'], item['adapter']; require(isinstance(adapter, int) and adapter >= 0 and adapter not in adapters, 'distinct adapters'); adapters.add(adapter)
        require(receipts[label]['exit'] == 0 and receipts[label]['command'] == prefix + [binaries['probe']['path'], '--adapter', str(adapter)], 'GPU binary/argv/exit')
        lines = logs[label].splitlines(); passes = [s for s in lines if s.startswith('PASS ')]; complete = [s for s in lines if s.startswith('COMPLETE ')]
        require(adapter in ids and [s for s in lines if s.startswith('ADAPTER ')] == identities, 'GPU driver/adapter identity join')
        expected = {f'PASS {name} format={fmt} draws={draws} compared_bytes={size} exact=true reference=literal canvas=true cpu_prepared_gradient=true' for name, (draws, size) in fixtures.items() for fmt in ('Bgra8Unorm', 'Rgba8Unorm')}
        require(len(passes) == 6 and set(passes) == expected and not any(s.startswith('FAIL ') for s in lines), 'six exact GPU records')
        require(complete == [f'COMPLETE adapter={adapter} fixtures=3 frames=6 compared_bytes=608 exact=true cpu_prepared_gradient=true custom_image_shader=true offscreen=true acquired_surface=false'], 'GPU completion')
    baseline = selection['baseline']; B = P / 'baseline/worktree'; fixture_source = json.loads(read(baseline['source']))
    require(git(B, 'rev-parse', 'HEAD').decode().strip() == BASE and not git(B, 'diff', 'HEAD', '--name-only'), 'parent baseline engine')
    expected_fixture_paths = {'tests/vulkan_gradients.rs', 'tests/support/vulkan_gradients.rs', 'examples/vulkan-gradients.html'}
    require(set(git(B, 'ls-files', '--others', '--exclude-standard', '-z').decode().split('\0')) - {''} == expected_fixture_paths, 'exact baseline additions')
    require(fixture_source['base'] == BASE and set(fixture_source['source_sha256']) == expected_fixture_paths, 'baseline fixture inventory')
    require(set(baseline['candidate_raw']) == expected_fixture_paths, 'raw candidate fixture roster')
    for name, digest in fixture_source['source_sha256'].items():
        row = binding(B / name); require(row['sha256'] == digest, 'baseline fixture bytes'); verified.append(row)
        raw = read(baseline['candidate_raw'][name]); verified.append(baseline['candidate_raw'][name])
        if name != 'tests/vulkan_gradients.rs': require(digest == sha(raw), 'same raw baseline fixture')
    before = read(baseline['wrapper']); require(before == (B / 'tests/vulkan_gradients.rs').read_bytes(), 'frozen baseline wrapper')
    require(before.count(b'const EXPECT_NATIVE: bool = false;') == 1 and before.replace(b'const EXPECT_NATIVE: bool = false;', b'const EXPECT_NATIVE: bool = true;') == read(baseline['candidate_raw']['tests/vulkan_gradients.rs']), 'false-admission-only raw witness delta')
    formatting = json.loads(read(baseline['formatting_review'])); require(formatting['status'].startswith('clear'), 'fixture formatting review')
    require(formatting['raw'] == baseline['candidate_raw'], 'reviewed raw fixtures')
    require(set(formatting['formatted']) == expected_fixture_paths, 'reviewed formatted fixtures')
    for name, row in formatting['formatted'].items():
        require(row['path'] == str(W / name) and row['sha256'] == inventory['source_sha256'][name], 'formatted fixture/source join'); read(row)
    format_check = formatting['check']; require(receipts[format_check]['exit'] == 0 and formatting['receipt'] == selection['checks'][format_check]['receipt'], 'formatting receipt join')
    label = baseline['check']; require(receipts[label]['exit'] == 0, 'baseline witness success'); rust_totals(logs[label], {'rows': 1, 'passed': 3, 'failed': 0, 'ignored': 0})
    require(receipts[label]['command'] == ['cargo', '+1.88.0', 'test', '--locked', '--offline', '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--test', 'vulkan_gradients', '--', '--include-ignored', '--test-threads=1'], 'baseline witness command')
    verified.extend([baseline['source'], baseline['wrapper'], baseline['formatting_review']])
    require({'documentation', 'native', 'core', 'fixtures'} <= set(selection['reviews']), 'mandatory peers')
    for name, row in selection['reviews'].items():
        review = json.loads(read(row)); require(review['status'].startswith('clear'), 'review conclusion: ' + name); verified.append(row)
    docs = json.loads(read(selection['reviews']['documentation'])); reviewed = {r['relative']: r['sha256'] for r in docs['published_files']}
    require(all(reviewed.get(name) == row['sha256'] for name, row in selection['published'].items() if name.endswith('.md')), 'complete documentation review coverage')
    members = {}
    def add(row):
        path = Path(row['path']); require(row['bytes'] <= 8 * 1024 * 1024, 'archive member limit')
        require(not any(x in ('.git', '__pycache__', 'target') or x.startswith('target-') for x in path.parts), 'excluded archive tree')
        data = read(row); require(not data.startswith((b'\x7fELF', b'\x1f\x8b', b'PK\x03\x04')) and data[257:262] != b'ustar', 'ELF or recursive archive')
        for root, prefix in ((W, 'worktree'), (P, 'evidence'), (Q, 'preparation')):
            if path.is_relative_to(root): name = prefix + '/' + path.relative_to(root).as_posix(); break
        else: raise ValueError('unlisted archive root')
        require(name not in members or members[name] == data, 'archive collision'); members[name] = data
    add(selected); add(binding(__file__)); add(binding(P / 'package-design.json'))
    for row in verified + selection['archive_inputs'] + list(selection['published'].values()): add(row)
    retained = ['implementation/source-ready.json', 'implementation/source-ready-2.json', 'implementation/native.raw.rs', 'implementation/native-2.raw.rs',
                'script-tests/source-ready.json', 'script-tests/gradient_tests.raw.rs', 'root/raw-1/source-ready.json', 'root/tests-before-implementation/source-ready.json',
                'root/clippy-correction/changes.json', 'root/clippy-correction/script-review.json', 'fixtures/source-ready.json', 'fixtures/source-ready-2.json', 'fixtures/source-ready-3.json']
    require(all('evidence/' + name in members for name in retained), 'retained original/corrected source holds')
    members['MANIFEST.json'] = encoded({name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(members.items())})
    require(sum(map(len, members.values())) <= LIMIT, 'aggregate archive payload cap')
    stream = io.BytesIO()
    with gzip.GzipFile(fileobj=stream, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w') as tar:
            for name, data in sorted(members.items()):
                info = tarfile.TarInfo(name); info.size = len(data); info.mtime = 0; info.mode = 0o644; tar.addfile(info, io.BytesIO(data))
    archive = stream.getvalue(); require(len(archive) <= LIMIT, 'compressed archive cap')
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
        require(len(tar.getnames()) == len(members) and set(tar.getnames()) == set(members), 'archive member roster')
        for member in tar: require(member.isfile() and tar.extractfile(member).read() == members[member.name], 'archive readback')
    out = W / 'docs/evidence'; require(out.is_dir() and out == out.resolve(), 'canonical output directory')
    for suffix in ('.json', '.tar.gz'): require(not (out / (STEM + suffix)).exists(), 'exclusive publication output')
    with (out / (STEM + '.tar.gz')).open('xb') as handle: handle.write(archive)
    require((out / (STEM + '.tar.gz')).read_bytes() == archive, 'disk archive readback')
    summary = {**selection['summary'], 'base': BASE, 'source': source, 'source_count': len(inventory['source_sha256']), 'binaries': binaries, 'checks': selection['checks'], 'reftests': report_item, 'gpu': selection['gpu'], 'baseline': baseline,
               'published': {name: {k: row[k] for k in ('bytes', 'sha256')} for name, row in selection['published'].items()},
               'archive': {'path': STEM + '.tar.gz', 'bytes': len(archive), 'sha256': sha(archive), 'members': len(members)}}
    with (out / (STEM + '.json')).open('xb') as handle: handle.write(encoded(summary))
    print(json.dumps({'archive': summary['archive'], 'published_files': len(selection['published']), 'checks': len(receipts)}, indent=2))

if __name__ == '__main__': main()
