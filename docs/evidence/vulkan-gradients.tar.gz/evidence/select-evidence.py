from pathlib import Path
import hashlib,json,re,subprocess
P=Path(__file__).resolve().parent;W=P/'worktree';Q=Path('/tmp/eris-gradient-vulkan-preparation-1')
def bind(p):
 p=Path(p);d=p.read_bytes();return dict(path=str(p),bytes=len(d),sha256=hashlib.sha256(d).hexdigest())
def read(p):return json.loads(Path(p).read_text())
source=bind(P/'compiled-source-2.json')
failed={'core-test-1','core-clippy-198-1','core-clippy-198-2','core-gpu-test-2','probe-clippy-1','clippy-native-198-1'}
final={'full-native-2','full-default-198-2','clippy-native-198-2','probe-clippy-2','probe-test-1','candidate-browser-build-2','candidate-browser-strip-2','candidate-probe-build-2','candidate-probe-strip-2','candidate-reftests-2','gpu-list-2','gpu-adapter-1-2','gpu-adapter-2-2','gpu-adapter-3-2','bridge-list-1','bridge-roster-1','format-check-2','format-core-check-2','format-probe-check-2'}
checks={}
for f in sorted((P/'validation').glob('*.json')):
 r=read(f);n=f.stem
 if not {'command','exit','log','sha256'}<=r.keys():continue
 assert r['exit']==(101 if n in failed else 0),(n,r['exit'])
 log=f.parent/r['log'];item=dict(receipt=bind(f),log=bind(log),command=r['command'],expected_exit=101 if n in failed else 0)
 if n in final:item['source']=source
 if n in {'full-native-1','full-default-198-1'}:item['source']=bind(P/'compiled-source-1.json')
 if n.startswith('full-') or n in {'core-test-2','core-gpu-test-1','core-gpu-test-3','probe-test-1'}:
  rows=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',log.read_text())
  item['rust']=dict(rows=len(rows),passed=sum(int(r[1]) for r in rows),failed=sum(int(r[2]) for r in rows),ignored=sum(int(r[3]) for r in rows))
 checks[n]=item
f=P/'baseline/validation/witness-1.json';r=read(f)
checks['baseline-witness-1']=dict(receipt=bind(f),log=bind(f.parent/r['log']),command=r['command'],expected_exit=0,rust=dict(rows=1,passed=3,failed=0,ignored=0))
changed=set((subprocess.check_output(['git','-C',str(W),'diff','HEAD','--name-only','-z'])+subprocess.check_output(['git','-C',str(W),'ls-files','--others','--exclude-standard','-z'])).decode().split('\0'))-{''}
assert len(changed)==26,sorted(changed)
raw={'tests/vulkan_gradients.rs':'fixtures/correction-1/after/tests/vulkan_gradients.rs','tests/support/vulkan_gradients.rs':'fixtures/correction-2/after/tests/support/vulkan_gradients.rs','examples/vulkan-gradients.html':'fixtures/raw/examples/vulkan-gradients.html'}
reviews={'documentation':'docs/layout-review-3.json','native':'implementation/html-review.json','core':'root/layout-review.json','fixtures':'fixtures/layout-review.json','final_corrections':'root/final-check-correction/html-review.json','publisher':'package-layout-review-2.json'}
files=set()
for name in ['root','implementation','script-tests','fixtures','docs','package-correction-1','package-correction-2','validation','reftests-candidate-1','reftests-candidate-2']:
 files.update(p for p in (P/name).rglob('*') if p.is_file())
files.update(p for p in Q.rglob('*') if p.is_file())
files.update(p for p in (P/'baseline/validation').glob('*') if p.is_file())
for pattern in ['compiled-source-*.json','core-source-*.json','candidate-*-binary*.json','package-layout-review-*.json']:
 files.update(P.glob(pattern))
files.update(P/n for n in ['run-check.py','run-tool.py','snapshot-source.py','check-bridge-roster.py','select-evidence.py','package.py','package-design.json','baseline/fixture-source.json'])
selection=dict(live_source=source,source_count=509,published={n:bind(W/n) for n in sorted(changed)},checks=checks,full_suites=dict(native='full-native-2',default='full-default-198-2'),binaries={role:dict(record=bind(P/f'candidate-{role}-binary-2.json'),build=f'candidate-{role}-build-2',strip=f'candidate-{role}-strip-2') for role in ['browser','probe']},reftests=dict(report=bind(P/'reftests-candidate-2/report.json'),manifest=bind(W/'tests/reftests/manifest.json'),check='candidate-reftests-2'),gpu_prefix=['env','LD_LIBRARY_PATH=/nix/store/iahmf8kl215rjcvb3zz3l7i9w2sf9x5v-vulkan-loader-1.4.357.0/lib'],gpu_list='gpu-list-2',gpu=[dict(check=f'gpu-adapter-{i+1}-2',adapter=i) for i in range(3)],baseline=dict(source=bind(P/'baseline/fixture-source.json'),wrapper=bind(P/'fixtures/baseline-wrapper-2.rs'),candidate_raw={n:bind(P/f) for n,f in raw.items()},formatting_review=bind(P/'root/fixture-formatting-review.json'),check='baseline-witness-1'),reviews={n:bind(P/f) for n,f in reviews.items()},archive_inputs=[bind(f) for f in sorted(files)],summary=dict(status='bounded native opaque gradient fragments verified; broader browser goal remains incomplete',scope='CPU prepares opaque square-corner gradient fragments; existing custom Vulkan image shader composites them. No GPU gradient interpolation.',validation=dict(native_tests=2520,default_tests=2326,raster_core_gpu_tests=154,probe_tests=15,bridge_roster=107,self_authored_reftests=68,gpu_adapters=3,gpu_frames_per_adapter=6,gpu_compared_bytes_per_adapter=608),limits=['Native frame ceiling1280x1024 physical pixels; shared generated/loaded source count256 and RGBA1MiB; prepared gradient work shares existing CPU admission budget.','Translucent stops, rounded corners and retained opacity scopes use existing whole-frame CPU fallback.','Offscreen GPU observations only; no acquired-window observation, performance comparison, full web conformance or universal security claim.'],retained_failures=['Initial raster enum match and test-only Clippy corrections retained with raw logs and before/after source.','Parent71697d55 CI38120637715 had8 successful jobs and one failing legacy probe job. Two explicit legacy gradient rejection arms restore probe compilation; final local all-target checks pass. New commit CI outcome is not yet known.'],binary_identity='Final source2 rebuilds produce the same browser and dedicated-checker bytes as source1; original source1 observations retained and final observations rerun from final paths.'))
with (P/'selection.json').open('x') as f:json.dump(selection,f,indent=2);f.write('\n')
print(json.dumps(dict(checks=len(checks),archive_inputs=len(files),published=len(changed),selection=bind(P/'selection.json'))))
