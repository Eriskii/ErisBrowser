# Root selection after initial proposal

The new worktree is `/tmp/eris-vulkan-gradients-1/worktree`, parent `71697d55`. Initial proposal/source-ready remain unchanged.

Use the stricter first admission: refuse a gradient inside **any opacity scope**, including opacity1. This keeps the initial proof independent of group materialization details. Loaded-image metadata remains separate from generated source count/bytes/evaluation work.

Root owns the checked core `ScreenImage { x: i32, y: i32, source: u32 }` and shared opaque evaluator. The adapter generates nonnegative visible framebuffer windows; the signed core interface must independently validate checked extents and clip/viewport behavior without an offset round-trip. Script owns native lowering/ledger; HTML owns the three probe fixtures and Page/worker witness. Layout owns independent source/oracle and resource-boundary review. The initial proposal’s suggested layout fixture ownership and opacity1 allowance are superseded by this selection.

No implementation or project execution by this author. The conservative T+Q work row is a proposal awaiting the concrete helper/ledger proof, not a measured value.
