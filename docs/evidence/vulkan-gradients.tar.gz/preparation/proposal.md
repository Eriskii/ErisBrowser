# First native gradient admission

Recommend CPU-prepared **opaque, unrounded gradient fragments** copied by the existing integer image shader. This moves composition into the Native plan; it does **not** move gradient interpolation to the GPU or eliminate CPU pixel preprocessing. Keep the current whole-scene software fallback for every unsupported gradient.

The CPU evaluator uses f64 stop resolution, direction, repetition, interpolation and final rounding. WGSL runtime scalar types do not include f64, and f32 arithmetic has specified accuracy latitude. A direct f32 shader is therefore not an exact replacement for arbitrary current inputs. A general exact shader would require a new common arithmetic contract or expensive emulation. Sources: [WGSL numeric types](https://www.w3.org/TR/WGSL/#numeric-scalar-types), [floating-point accuracy](https://www.w3.org/TR/WGSL/#floating-point-accuracy).

## Admission and shared evaluation

Admit 1–32 valid stops only when every resolved stop alpha is255, radius is exactly0, and the command is outside every active opacity scope below1. Explicit opacity1 remains legal. Other scene content may still use existing opacity support. Invalid fields/resolution, translucent/currentColor-alpha stops, rounded coverage and any nonunit ancestor opacity retain whole-scene fallback, even if apparently hidden. No limits increase and no changed CPU color results.

Extract the existing resolved-gradient logic and opaque RGB rounding into a crate-private helper shared with Canvas, preserving operation order. The native adapter samples that helper at the original **framebuffer pixel centers**, after the same f32 translation of both paint rect and tile through CoordinateState. Keep untrimmed tile origin/extent, arbitrary angle/corner, px/% stops, currentColor and stop_scale; never rebase the tile to the clip or rasterize one rounded tile then scale it. Recompute per plan initially: no cache or stale scroll/style witness.

An RGBA8 texture is not sufficient for the excluded cases. For example, half-transparent black over white gives128 in Canvas’s floating gradient blend, whereas rounding alpha to128 then using the existing image blend gives127. Under opacity, even an opaque gradient is first rounded into16-bit channels by Canvas; pre-rounding to8bit changes that input. Those routes need a separate design.

## Exact ScreenImage seam

Add a core-only `Command::ScreenImage { origin: (u32,u32), source: u32 }` or equivalent. Its validated source dimensions define a1:1 integer framebuffer window. Validate source index, checked origin+extent, viewport containment and containment within the current integer-origin clip; do not apply document/fixed offsets again and do not reconstruct/clip a floating rect. Construct a PendingDraw directly, then use the unchanged source packing, identity lookup tables and image shader. This follows the existing absolute-placement Glyph precedent; no worker DrawCommand/IPC variant is needed.

Derive preparation’s effective integer window from Canvas’s exact translated rect/clip loop, including its floor/ceil order and final half-open clip.contains check. Its charged loop area P may conservatively exceed the final generated area Q at floating clip edges; retain P. Empty effective windows allocate no source. The ScreenImage validator must refuse out-of-clip windows rather than silently resample them. Subtracting the current offset to fabricate a document-space image and reapplying it later is not an accepted parity proof.

Root owns this core seam and shared CPU helper. Script owns adapter preflight, scope/opacity tracking, generated source ownership and ledgers. Layout’s next ownership is independent fixtures and limit/source review. No code is authorized by this plan itself.

## Bound every new owner before preparation

Retain all existing caps:256 original/lowered commands,32 scopes,4 phases,256 combined image sources, **1,048,576 aggregate RGBA bytes** across original images and generated fragments,4,000,000 GPU invocations, Native1280×1024 viewport and16MiB GPU buffers. A large gradient may therefore continue to fall back; do not raise the source cap. Cardinal1D compression is a later optimization, not implicit in this increment.

For N stops, current Canvas reserves T=P*(bit_width(N-1)+2)+4*N. Geometry admission must include T instead of the old full-frame UnsupportedGradient slot; charge a further Q preparation units for writing the generated RGBA owner. Thus proposed native preparation reservation is T+Q, shared with existing CPU work under `(frame_area*16).clamp(1_000_000,32_000_000)`. Also account bounded stop scans, each full source packing pass and exact LUT construction under their existing structural/source limits; no free warm-cache path. The extra Q is a conservative proposed new-site reservation, not a reduction of an old tariff.

Before the first generated allocation, reserve all source slots,4*Q payload bytes, width+height lookup words, operation/parameter slots and padded8×8 invocations, with checked sums across all phases. Keep original images’ validation and unused-source accounting. Build owned fragments first; only then borrow them into the final SourceImage table, preventing stale pointers during Vec growth. Drop partial owners on any refusal and submit nothing. Extend preparation_peak_bytes by the additional live generated payload (at most1MiB), owner/descriptors and helper scratch: packed Plan input already counts the other copy, so neither omit this overlap nor count it twice. Recompute metadata sizeof bounds after the new Command variant.

Expose generated source count/bytes, evaluation work and preparation time separately in stats/evidence. The old `CPU_upload=false` description must be qualified as no whole CPU framebuffer upload; generated primitive pixels are explicitly CPU-produced uploads.

## Three independent GPU fixtures

Use a dedicated browser-bridge-enabled checker with three Native plans passed through the existing `surface_gpu::run` path, which understands Native surface conversion and both output formats. Do not append to the old30-case default probe or use its Probe-only allocation equation. Each plan must originate in the actual native adapter, not hand-authored prepared bytes. Before GPU work, compare Canvas output and prepared source/count/window against independently frozen literals.

1. **Ramp and px zoom:** frame4×2, white. First row is a4px black→#f8f8f8 horizontal ramp: `[1f1f1f,5d5d5d,9b9b9b,d9d9d9]`. Second row has red and blue coincident stops at1px with stop_scale2: `[ff0000,ff0000,0000ff,0000ff]`. Each command is height1. Tests final rounding, px scaling and ordering.
2. **Fractional scroll, clip and repetition:** frame8×4, white; phase document offset(.25,-.75), caller clip(1.25,.25,5.5,3.5); paint rect(.5,1,8,4), tile(0,1,4,2), rightward red50%/blue50%. Expected first row allwhite; remaining three rows `WWBBRRBW`. Effective source window is(2,1,5,3), with tile translated to(.25,.25,4,2). Tests exact clipping and phase, with no crop-based restart.
3. **Fixed corner and currentColor:** frame8×4, white; document offset(0,-10.5), viewport offset(1,1). A document PushClip(0,0,1,1) is empty; PushFixed escapes it. Paint/tile(0,0,4,2), to-top-right CurrentColor-red50%/blue50%, then close both scopes. Expected white perimeter; at x1..4 row1 `RBBB`, row2 `RRRB`. Tests fixed clip reset, root-resolved color transport and corner direction.

Private boundary tests additionally cover maximum source slots/aggregate bytes with existing images, exact/one-short CPU and GPU admission, late refusal dropping earlier generated owners, invalid/zero/overlong inputs, fractional negative tile origins, every forbidden alpha/radius/opacity case, and multiple phases sharing one ledger. Compare every GPU output byte on every available adapter and both existing surface formats. Keep predecessor refusals. Time preparation separately from encoding/submission with fixed fixtures; report CPU-prepared bytes and no speed claim before measurements.
