"""Inert source/data derivation. Does not import or execute project modules."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import textwrap

AX = Path('/tmp/eris-promise-race-upstream-1')
OUT = AX / 'tests-outline-1'
REV = '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
ROOT = '91b2052adad1f066ae031e2ff3a1e9bd6d732886'
RACE = 'fe8e0bf36a2323ffb4f03d63d56e1516e0855900'
PREFIX = 'test/built-ins/Promise/race/'
FETCH = AX / 'corpus-fetch-1'
DATA = FETCH / 'data'
CORPUS = AX / 'corpus-1/raw/tests/upstream/test262-promise-race'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':')).encode()

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2, ensure_ascii=True) + '\n')

receipt = json.loads((FETCH / 'receipt.json').read_bytes())
assert receipt['revision'] == REV
# Check commit/root assertion; reconstruct binary trees independently. The commit
# JSON is unsigned; this is a join to the separately pinned root, not signature verification.
proofs = {}
for row in receipt['proof']:
    path = Path(row['path'])
    assert bind(path) == row
    proofs[path.name] = json.loads(path.read_bytes())
assert proofs['commit.json']['sha'] == REV
assert proofs['commit.json']['tree']['sha'] == ROOT
trees = {}
for name, obj in proofs.items():
    if name == 'commit.json':
        continue
    expected = name[5:-5]
    assert obj['sha'] == expected and obj['truncated'] is False
    rows = obj['tree']
    assert len(rows) <= 16384 and len({r['path'] for r in rows}) == len(rows)
    encoded = []
    for r in rows:
        assert r['type'] == {'040000':'tree','100644':'blob','100755':'blob','120000':'blob','160000':'commit'}[r['mode']]
        assert r['path'] not in ('', '.', '..') and not any(c in r['path'] for c in '/\0')
        key = r['path'].encode() + (b'/' if r['type'] == 'tree' else b'')
        encoded.append((key, r['mode'].lstrip('0').encode() + b' ' + r['path'].encode() + b'\0' + bytes.fromhex(r['sha'])))
    payload = b''.join(b for _, b in sorted(encoded))
    assert hashlib.sha1(b'tree ' + str(len(payload)).encode() + b'\0' + payload).hexdigest() == expected
    trees[expected] = {r['path']: r for r in rows}
sha_path = ROOT
chain = [ROOT]
for name in ('test', 'built-ins', 'Promise', 'race'):
    row = trees[sha_path][name]
    assert row['type'] == 'tree'
    sha_path = row['sha']
    chain.append(sha_path)
assert sha_path == RACE
race_rows = trees[RACE]
assert len(race_rows) == 94
assert all(r['type'] == 'blob' and r['mode'] in ('100644','100755') and n.endswith('.js') and '_FIXTURE' not in n for n,r in race_rows.items())
root = trees[ROOT]
harness_tree = root['harness']['sha']
assert set(trees) == set(chain + [harness_tree])

metadata = {}
raw_rows = {}
# A separate deliberately narrow parser: inspect only execution-field lines. All
# 94 authenticated files use one-line unquoted lists; assert that prerequisite.
# Do not infer absent timeout as null or import importer.parse_metadata.
for name in sorted(race_rows):
    path = PREFIX + name
    data = (DATA / path).read_bytes()
    text = data.decode('utf-8')
    assert text.count('/*---') == text.count('---*/') == 1
    front = textwrap.dedent(text.split('/*---',1)[1].split('---*/',1)[0])
    fields = {}
    for key in ('flags','includes','features','locale','negative','timeout'):
        matches = re.findall(r'^' + key + r':[ \t]*(.*)$', front, re.M)
        assert len(matches) <= 1
        if matches:
            fields[key] = matches[0].strip()
    assert 'negative' not in fields and 'timeout' not in fields
    record = {}
    for key in ('flags','includes','features','locale'):
        value = fields.get(key, '[]')
        assert re.fullmatch(r'\[[A-Za-z0-9_., \t-]*\]', value)
        items = [item.strip() for item in value[1:-1].split(',') if item.strip()]
        assert len(items) == len(set(items))
        record[key] = items
    record['negative'] = None
    assert set(record['flags']) <= {'async'} and not record['locale']
    metadata[path] = record

helpers = {'assert.js','sta.js'}
for row in metadata.values():
    helpers.update(row['includes'])
    if 'async' in row['flags']:
        helpers.add('doneprintHandle.js')
aux = {f'harness/{name}': trees[harness_tree][name]['sha'] for name in sorted(helpers)}
aux.update({name:root[name]['sha'] for name in ('LICENSE','INTERPRETING.md')})
expected_blobs = {PREFIX+n:r['sha'] for n,r in race_rows.items()} | aux
assert set(expected_blobs) == {r['relative'] for r in receipt['files']}
for row in receipt['files']:
    relative = row['relative']
    path = DATA / relative
    data = path.read_bytes()
    assert bind(path) == row['binding']
    blob = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert blob == expected_blobs[relative] == row['git_blob']
    assert (CORPUS / relative).read_bytes() == data
    raw_rows[relative] = dict(bytes=len(data),sha256=sha(data),git_blob=blob)

manifest = json.loads((CORPUS / 'manifest.json').read_bytes())
assert manifest['format'] == 1 and manifest['revision'] == REV
assert manifest['repository'] == 'https://github.com/tc39/test262'
assert manifest['directories'] == {'Promise/race':sorted(race_rows)}
assert manifest['test_files'] == 94
assert manifest['files'] == [dict(path=p,upstream_path=p,bytes=v['bytes'],sha256=v['sha256']) for p,v in sorted(raw_rows.items())]
proof_rows=[]
for row in sorted(receipt['proof'],key=lambda x:Path(x['path']).name):
    name=Path(row['path']).name
    assert (CORPUS/'inventory-proof'/name).read_bytes() == Path(row['path']).read_bytes()
    route='commits/'+REV if name=='commit.json' else 'trees/'+name[5:-5]
    proof_rows.append(dict(path='inventory-proof/'+name,bytes=row['bytes'],sha256=row['sha256'],url='https://api.github.com/repos/tc39/test262/git/'+route))
expected_description=dict(method='complete-nonrecursive-git-trees',revision=REV,root_tree=ROOT,directory_trees={'Promise/race':RACE},auxiliary_blobs=dict(sorted(aux.items())),files=proof_rows)
assert manifest['inventory_proof'] == expected_description
cases=[]
for path, meta in sorted(metadata.items()):
    policy=int('async' in meta['flags'])
    names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+meta['includes']
    assert len(set(names)) == len(names)
    for mode in ('sloppy','strict'):
        identity=dict(source_sha256=raw_rows[path]['sha256'],mode=mode,metadata=meta,harness=[dict(name=n,sha256=raw_rows['harness/'+n]['sha256']) for n in names],completion_policy=policy)
        cases.append(dict(id=path+':'+mode,case_sha256=sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode()),policy=policy,harness=names,class_excluded='class' in meta['features']))
counts=dict(source_files=len(metadata),mode_cases=len(cases),sloppy=94,strict=94,async_sources=sum('async' in m['flags'] for m in metadata.values()),sync_sources=sum('async' not in m['flags'] for m in metadata.values()),negative_sources=0,class_sources=sum('class' in m['features'] for m in metadata.values()),source_bytes=sum(raw_rows[p]['bytes'] for p in metadata),all_blob_bytes=sum(v['bytes'] for v in raw_rows.values()),proof_documents=len(proof_rows),proof_bytes=sum(r['bytes'] for r in proof_rows),flags=dict(Counter(x for m in metadata.values() for x in m['flags'])),features=dict(Counter(x for m in metadata.values() for x in m['features'])),includes=dict(Counter(x for m in metadata.values() for x in m['includes'])))
# Static AST interpretation of literal importer tables, never Python execution.
module=ast.parse((AX/'worktree/tools/import_test262.py').read_text())
constants={}
for node in module.body:
    if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
        try: constants[node.targets[0].id]=ast.literal_eval(node.value)
        except (ValueError,TypeError): pass
profile_node=next(n.value for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='PROFILES' for t in n.targets))
profiles={ast.literal_eval(k):constants[v.id] for k,v in zip(profile_node.keys,profile_node.values)}
assert len(profiles)==55
old_tables=dict(profiles=profiles,roots=constants['PROFILE_ROOTS'],tree_profiles=sorted(constants['TREE_PROFILES']))
prior53=dict(profiles={k:v for k,v in profiles.items() if k not in {'promise-all','promise-methods-async'}},roots={k:v for k,v in constants['PROFILE_ROOTS'].items() if k not in {'promise-all','promise-methods-async'}},tree_profiles=sorted(constants['TREE_PROFILES']-{'promise-all','promise-methods-async'}))
assert sha(canonical(prior53))=='e51b4b6882c1163b10fa3eb84321fac4b923acadc8a29a41b648c0d399a502e6'
write('source-oracle.json',dict(status='independently_derived_from_authenticated_raw_bytes_no_engine_execution',revision=REV,root_tree=ROOT,directory_tree=RACE,counts=counts,helpers=sorted(helpers),metadata=metadata,raw_files=raw_rows,case_identities=cases,case_identities_sha256=sha(canonical(cases)),expected_manifest=manifest,manifest_sha256=sha((CORPUS/'manifest.json').read_bytes()),class_sources=[p for p,m in metadata.items() if 'class' in m['features']],old_tables=old_tables,old_tables_sha256=sha(canonical(old_tables)),original53_sha256=sha(canonical(prior53))))
write('derivation-receipt.json',dict(status='source_data_only_clear',fetch=bind(FETCH/'receipt.json'),corpus_hold=bind(AX/'corpus-1/source-ready.json'),manifest=bind(CORPUS/'manifest.json'),oracle=bind(OUT/'source-oracle.json'),script=bind(Path(__file__)),tree_chain=chain,harness_tree=harness_tree,verified_binary_trees=len(trees),verified_blobs=len(raw_rows),commit_qualification='Unsigned API commit description joined to the separately pinned revision/root; no signature or reconstructed commit-object claim.',metadata_algorithm='Independently parsed only inline execution fields in all94 original frontmatter; all missing fields remain absent as specified, especially timeout; no importer or runner module imported.',mode_algorithm='Only async flags occur; existing precedence therefore yields sloppy and strict for every original body.',fingerprint_algorithm='source sha256 + mode + exact execution metadata + ordered helper name/hash + integer completion policy; json.dumps sort_keys=True ensure_ascii=True default separators, as current source specifies.',counts=counts,old_profile_tables=55,no_runtime_outcome_claim=True))
print(json.dumps(counts,sort_keys=True))
