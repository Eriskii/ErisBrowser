"""Independent inert source/AST/byte review; never import candidate modules."""
import ast,copy,difflib,hashlib,json
from pathlib import Path
A=Path('/tmp/eris-promise-race-upstream-1'); H=A/'production-runner-1'; O=A/'runner-script-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def verify(b):
 p=Path(b['path']);assert bind(p)==b
hold=json.loads((H/'source-ready.json').read_bytes())
assert sha((H/'source-ready.json').read_bytes())=='dbe0bf913a968eb7921eddf786d02f823bbc2065564577662ff564ee88b7b58c'
assert len(hold['files'])==1
for x in hold['inputs']+[hold['inverse']]:verify(x)
r=hold['files'][0]
for key in ('before','raw','diff'):verify(r[key])
before=Path(r['before']['path']).read_text();raw=Path(r['raw']['path']).read_text()
parent=json.loads((A/'parent-source.json').read_bytes())['source_sha256']
assert sha(before.encode())==parent[r['relative']]
assert ''.join(difflib.unified_diff(before.splitlines(keepends=True),raw.splitlines(keepends=True),fromfile='a/'+r['relative'],tofile='b/'+r['relative']))==Path(r['diff']['path']).read_text()
# Reconstruct old bytes independently of the author's inverse replacement log.
recovered=raw
start=recovered.index('def promise_race_preflight_variants():')
end=recovered.index('def check_baseline(',start)
recovered=recovered[:start]+recovered[end:]
recovered=recovered.replace("PROMISE_RACE_PROFILE = 'promise-race'\nPROMISE_RACE_FEATURES = PROMISE_ALL_FEATURES.copy()\nPROFILE_FEATURES[PROMISE_RACE_PROFILE] = PROMISE_RACE_FEATURES\n",'')
recovered=recovered.replace('PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE, PROMISE_RACE_PROFILE}', 'PROMISE_HOST_PROFILES = {PROMISE_PROFILE, PROMISE_ALL_PROFILE}')
assert recovered.count("if profile in {'promise-race', 'promise-all',")==2
recovered=recovered.replace("if profile in {'promise-race', 'promise-all',", "if profile in {'promise-all',")
recovered=recovered.replace('    if profile == PROMISE_RACE_PROFILE:\n        return promise_race_harness_preflight(files, binary, timeout)\n','')
recovered=recovered.replace('preflight_ok = (promise_race_preflight_healthy(preflight) if args.profile == PROMISE_RACE_PROFILE\n                        else promise_all_preflight_healthy(preflight)', 'preflight_ok = (promise_all_preflight_healthy(preflight)')
assert recovered==before
old_ast,new_ast=ast.parse(before),ast.parse(raw)
old={n.name:n for n in old_ast.body if isinstance(n,ast.FunctionDef)}
new={n.name:n for n in new_ast.body if isinstance(n,ast.FunctionDef)}
new_names=set(new)-set(old)
assert new_names=={'promise_race_preflight_variants','promise_race_preflight_healthy','promise_race_harness_preflight'}
changed=[n for n in old if ast.dump(old[n])!=ast.dump(new[n])]
assert changed==['load_corpus','harness_preflight','main']
# Existing all dispatch/gate topology is copied under race names; no new verifier.
for suffix in ('preflight_healthy','harness_preflight'):
 proposed=ast.get_source_segment(raw,new['promise_race_'+suffix])
 renamed=proposed.replace('promise_race_','promise_all_').replace('PROMISE_RACE_','PROMISE_ALL_').replace('promise-race-','promise-all-')
 assert ast.dump(ast.parse(renamed).body[0])==ast.dump(old['promise_all_'+suffix])
variants=ast.literal_eval(next(n for n in new['promise_race_preflight_variants'].body if isinstance(n,ast.Return)).value)
expected=json.loads((A/'controls-2/variants.json').read_bytes())['variants']
oracle=json.loads((A/'tests-before-1/raw/tools/promise-race-profile-oracle.json').read_bytes())
assert variants==expected==oracle['controls']
common=ast.literal_eval(next(n for n in old['promise_preflight_variants'].body if isinstance(n,ast.Return)).value)
assert len(common)==37 and len(variants)==8
common_names=['promise-methods-'+r['name'] for r in common]
known=set(common_names)
pre=[]
for mode in ('sloppy','strict'):
 for row in variants:
  name='promise-race-'+row['name']
  required=common_names.copy()
  if row['prerequisite']:
   dep='promise-race-'+row['prerequisite'];assert dep in known;required.append(dep)
  known.add(name)
  pre.append(dict(name=name,mode=mode,required=required))
assert len({(r['name'],r['mode']) for r in pre})==16
checks=dict(independently_recovered_parent_bytes=True,parent_sha256=sha(recovered.encode()),embedded_controls_exact=True,new_functions=sorted(new_names),changed_existing_functions=changed,unchanged_existing_functions=len(old)-len(changed),common_sources=37,new_sources=8,exact_identity_count=90,new_dependency_rows=pre,renamed_existing_all_gate_and_composer_AST_equal=True)
(O/'source-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
receipt=dict(status='clear_source_only',findings=[],scope='One runner source; static comparison against controls2, frozen13 and published parent. Importer/profile registration and runtime observations remain separate.',hold=bind(H/'source-ready.json'),test_hold=bind(A/'tests-before-1/source-ready.json'),test_peer=bind(A/'tests-before-1/html-review.json'),controls=bind(A/'controls-2/source-ready.json'),checks=bind(O/'source-checks.json'),checker=bind(Path(__file__)),conclusions=[
'Exact inverse independently recovers all287903 parent bytes. Three new functions, three guarded existing function changes, additive profile constants only; old common/all controls and transport/classifier/verifier/baseline policy remain exact.',
'Common74 remain first. New16 are mode-major, source/order/metadata/harness/policy exact. Each requires all37 common same-mode identities and each mismatch additionally requires its own earlier positive, carrying source/case hashes.',
'Healthy gate requires exact90 unique(name,mode) identities, unchanged common gate on first74, and verified is True. Missing/common-only/truncated/duplicate/extra/wrong name/mode/unverified outcomes are nonhealthy.',
'Gate consumes private producer-computed verification flags, not arbitrary serialized approval flags. Producer runs existing strict observation validator/verifier first; response cannot supply verified. Bare, missing, contradictory or unauthenticated completion evidence cannot satisfy held success/error checks. Sync mismatch needs exact runtime Test262Error; async mismatch retains existing authenticated completion-error semantics, without new audit-policy restrictions.',
'Unavailable host exit2 is adapter-error; a valid legacy ERJR2 complete response lacks completion evidence and stays failed/unverified. Main blocks all188 identities after unhealthy preflight and records no baseline; no metadata exclusion bypasses gate.',
'Race copies existing all feature set; original profile paths keep identical memberships/branches. New loader memberships retain root-linked helper/legal authentication and exact file inventory. No source filtering, protocol/cap/Rust change.'],limits='No project imports, tests, JS, compiler or adapter execution; no claim of actual upstream outcomes. This receipt does not authenticate the separately authored importer or CI changes.')
(O/'source-review.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(bind(O/'source-review.json')))
