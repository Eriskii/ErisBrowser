#!/usr/bin/env python3
"""Additive, stdlib-only source/identity check of the descriptor restoration correction."""
from pathlib import Path
import copy
import difflib
import hashlib
import json
ROOT=Path('/tmp/eris-promise-race-upstream-1')
OLD=ROOT/'controls-1'; NEW=ROOT/'controls-2'; DATA=ROOT/'corpus-fetch-1/data'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(Path(p).read_text())
h=load(NEW/'source-ready.json');oldh=load(OLD/'source-ready.json')
assert sha((NEW/'source-ready.json').read_bytes())=='d2c8757adecd7220c0931e64629ce440c7b238eb291fc9b967d97431b870c4ca'
assert bind(h['prior_hold']['path'])==h['prior_hold'] and bind(h['correction']['path'])==h['correction']
for r in h['files']:
 b=(NEW/r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256']
oldv=load(OLD/'variants.json');newv=load(NEW/'variants.json');inverse=copy.deepcopy(newv)
for old,new,inv in zip(oldv['variants'],newv['variants'],inverse['variants']):
 assert (NEW/'raw'/(new['name']+'.js')).read_text()==new['source']
 if new['name'] in ['api','api-mismatch']:
  assert new['source'].count(', { restore: true }')==3
  inv['source']=new['source'].replace(', { restore: true }','')
  assert inv['source']==old['source']
 else:assert new==old and (NEW/'raw'/(new['name']+'.js')).read_bytes()==(OLD/'raw'/(new['name']+'.js')).read_bytes()
assert inverse==oldv
assert (NEW/'prerequisites.json').read_bytes()==(OLD/'prerequisites.json').read_bytes()
assert (NEW/'bindings.json').read_bytes()==(OLD/'bindings.json').read_bytes()
for pair in ['api','winner','rejection-identity','shared-callbacks']:
 a=(NEW/'raw'/(pair+'.js')).read_text();b=(NEW/'raw'/(pair+'-mismatch.js')).read_text()
 diff=''.join(difflib.unified_diff(a.splitlines(keepends=True),b.splitlines(keepends=True),fromfile=pair+'.js',tofile=pair+'-mismatch.js'))
 assert diff==(NEW/'pair-diffs'/(pair+'.patch')).read_text()
 if pair!='api':assert (NEW/'pair-diffs'/(pair+'.patch')).read_bytes()==(OLD/'pair-diffs'/(pair+'.patch')).read_bytes()
assert newv['variants'][1]['source']=='Promise.race = function race(value) {};\n'+newv['variants'][0]['source']
oldo=load(OLD/'observations.json');newo=load(NEW/'observations.json');correction=load(NEW/'correction.json')
reverse_hashes={}; changed=[]
for mode_index,mode in enumerate(['sloppy','strict']):
 for v_index,v in enumerate(newv['variants']):
  i=mode_index*8+v_index;n=newo['cases'][i];o=oldo['cases'][i]
  policy=v['completion_policy'];names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+v['includes']
  identity=dict(source_sha256=sha(v['source'].encode()),mode=mode,metadata=dict(flags=['async'] if policy else [],includes=v['includes'],features=[],locale=[],negative=None),harness=[dict(name=name,sha256=sha((DATA/'harness'/name).read_bytes())) for name in names],completion_policy=policy)
  assert identity==n['identity']
  assert sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())==n['case_sha256']
  if v_index in [0,1]:
   reverse_hashes[n['case_sha256']]=o['case_sha256'];reverse_hashes[n['identity']['source_sha256']]=o['identity']['source_sha256']
   changed.append(dict(name=n['name'],mode=mode,old_case_sha256=o['case_sha256'],new_case_sha256=n['case_sha256']))
  else:assert n==o
assert correction['changed_cases']==changed and len(reverse_hashes)==6
b=(NEW/'observations.json').read_bytes()
for new,old in reverse_hashes.items():b=b.replace(new.encode(),old.encode())
assert b==(OLD/'observations.json').read_bytes()
for i in [1,9]:
 assert newo['cases'][i]['prerequisites'][:-1]==oldo['cases'][i]['prerequisites'][:-1]
 positive=newo['cases'][i-1];last=newo['cases'][i]['prerequisites'][-1]
 assert last==dict(name=positive['name'],mode=positive['mode'],case_sha256=positive['case_sha256'],source_sha256=positive['identity']['source_sha256'])
review=dict(status='clear',scope='Selected controls-2 composition, incorporating controls-1 source review and its retained finding.',hold=bind(NEW/'source-ready.json'),prior_review=bind(OLD/'html-review.json'),correction=bind(NEW/'correction.json'),audit=bind(Path(__file__)),inputs=[bind(NEW/'variants.json'),bind(NEW/'observations.json'),bind(NEW/'prerequisites.json'),bind(DATA/'harness/propertyHelper.js')],checks=[
'Every selected file binding is exact. Both API source inverses remove exactly three fourth-argument restore options, recovering the old source strings. All six other scripts are byte-identical.',
'PropertyHelper verifies configurability by deleting obj[name] at line140, calls that path at line122, and restores originalDesc at lines131-132 when options.restore is true. Corrected owner/name/length checks restore the exact descriptor before later observations.',
'The ordinary replacement function still has name race, length1 and matching owner/name/length descriptors. Its constructibility is the sole intended behavior difference; new returns normally, so the pinned assert.throws raises Test262Error. The positive native method remains nonconstructible and satisfies the same descriptor checks.',
'All 16 complete fingerprint identities independently rederived. Exactly four API case hashes and two API source hashes change; replacing those six hashes in the entire new observations bytes recovers the entire original observations bytes, including only the two same-mode API-positive prerequisite references.',
'Twelve other prospective observations, all 74 common identities, exact 90 unique roster, modes, completion policies, harness order and 37/38 dependency names remain unchanged. Expected results and host evidence fields are unchanged.',
'Pair deltas still isolate exactly the four selected mutations. No runner/host/runtime implementation, caps or upstream test data changed by this hold.'
],findings=[],limits=['Source-only review; no project code, importer, runner, compiler, JS or engine execution. These are prospective control expectations, not observed outcomes.','Control1 finding and immutable inputs remain preserved; this clear receipt applies only to the complete controls-2 composition.','Retains prior finite-checkpoint empty-race qualification and asynchronous completion-error versus serialized exception distinction.'])
(NEW/'html-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(NEW/'html-review.json'),indent=2))
