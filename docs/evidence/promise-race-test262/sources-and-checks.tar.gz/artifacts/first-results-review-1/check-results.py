"""Read-only receipt/source parsing; no project imports or execution."""
from collections import Counter
import hashlib,json
from pathlib import Path
A=Path('/tmp/eris-promise-race-upstream-1');O=A/'first-results-review-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p):return json.loads(p.read_bytes())
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
r=read(A/'race-first-report.json');b=read(A/'race-first-baseline.json')
o=read(A/'tests-before-1/raw/tools/promise-race-profile-oracle.json')
parent_controls=read(A/'controls-parent-report.json')
assert r['mode_cases']==188 and r['source_files']==r['source_tests']==94
assert len(r['cases'])==188 and len({c['id'] for c in r['cases']})==188
assert r['counts']==dict(Counter(c['status'] for c in r['cases']))=={'passed':170,'failed':10,'unsupported':8}
assert r['full_test262_conformance'] is False and r['negative_source_tests']==0 and r['fixture_files']==[]
assert r['runner_policy']==o['policy'] and r['runner_policy_sha256']==o['policy_sha256']
assert sha(json.dumps(r['runner_policy'],sort_keys=True).encode())==r['runner_policy_sha256']
assert r['corpus_manifest_sha256']==o['manifest_sha256']
held={c['id']:c for c in o['case_identities']}
assert [c['id'] for c in r['cases']]==[c['id'] for c in o['case_identities']]
source_entries={x['path']:x for x in o['expected_manifest']['files']}
for c in r['cases']:
 expected=held[c['id']]
 assert c['case_sha256']==expected['case_sha256'] and c['id']==c['file']+':'+c['mode']
 assert c['source_sha256']==source_entries[c['file']]['sha256']
 assert c['expected_negative'] is None
 data=(A/'corpus-fetch-1/data'/c['file']).read_bytes()
 assert sha(data)==c['source_sha256']
 if 'observation' in c:assert c['observation']['completion']['policy']==expected['policy']
projection={k:r[k] for k in ('revision','corpus_manifest_sha256','runner_policy_sha256','binary_sha256')}
projection['cases']={c['id']:{k:c[k] for k in ('status','case_sha256','source_sha256')} for c in r['cases']}
assert b==projection
controls=r['harness_preflight'];assert len(controls)==90 and all(c['verified'] is True for c in controls)
assert r['harness_preflight_passed'] is True
assert controls[:74]==parent_controls['common']
assert len(parent_controls['new_controls'])==16
by_control={(c['name'],c['result']['mode']):c for c in controls}
assert len(by_control)==90
for c,old,h in zip(controls[74:],parent_controls['new_controls'],o['preflight']):
 assert {k:c[k] for k in ('name','expected','verified','result')}==old
 assert (c['name'],c['result']['mode'],c['result']['case_sha256'],c['result']['source_sha256'])==(h['name'],h['mode'],h['case_sha256'],h['source_sha256'])
 row=next(x for x in o['controls'] if 'promise-race-'+x['name']==c['name'])
 common=[x['name'] for x in o['common74'] if x['mode']==h['mode']]
 if row['prerequisite']:common.append('promise-race-'+row['prerequisite'])
 assert c['prerequisites']==[dict(name=n,mode=h['mode'],verified=True,case_sha256=by_control[(n,h['mode'])]['result']['case_sha256'],source_sha256=by_control[(n,h['mode'])]['result']['source_sha256']) for n in common]
# Classify observed nonpasses, preserving raw statuses and evidence. Source
# descriptions explain the visible mechanism without inventing rejected payloads.
host_sources={
 'invoke-resolve-error-close.js':'Replaces Promise.resolve with a function evaluating throw err, discards the returned race promise, then asserts one return call. The rejected payload is not serialized by this host-policy observation.',
 'invoke-then-error-close.js':'Replaces a pending input then with a throwing Test262Error function, discards the returned race promise, then asserts one return call.',
 'invoke-then-get-error-close.js':'Defines a throwing Test262Error then getter on a pending input, discards the returned race promise, then asserts one return call.',
 'iter-next-val-err-no-close.js':'Defines a throwing value getter, discards the returned race promise, then asserts return was never called.',
 'iter-step-err-no-close.js':'Defines a throwing done getter and poisoned value getter, discards the returned race promise, then asserts return was never called.'}
classes={
 'ctx-ctor.js':('metadata-class','Tagged class; source declares SubPromise extends Promise.'),
 'invoke-resolve-on-promises-every-iteration-of-custom.js':('metadata-class','Tagged class; source declares Custom extends Promise.'),
 'resolve-throws-iterator-return-is-not-callable.js':('parser-class','Untagged class BadPromise with constructor/static method. Original also contains0n; the observed diagnostic stops at class, so no separate BigInt result is claimed.'),
 'resolve-throws-iterator-return-null-or-undefined.js':('parser-class','Untagged class BadPromise with constructor/static method; observed parse refusal names class.')}
nonpass=[]
for c in r['cases']:
 if c['status']=='passed':continue
 name=Path(c['file']).name
 if c['status']=='failed':
  assert name in host_sources
  expected=dict(status='host-failure',phase='host',error_type='',error_identity='',message='unhandled-rejection',harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=1))
  assert c['observation']==expected
  category='final-quiescent-unhandled-policy-veto';note=host_sources[name]
 else:
  category,note=classes[name]
  if category=='metadata-class':
   assert c['reason']=='unimplemented declared features: class' and 'observation' not in c
   assert 'class' in o['metadata'][c['file']]['features']
  else:
   assert 'class' not in o['metadata'][c['file']]['features']
   assert c['observation']==dict(status='unsupported',phase='parse',error_type='UnsupportedFeature',error_identity='',message="'class' is not supported",harness='',completion=dict(policy=0,done_calls=0,success_prints=0,failure_prints=0,flags=0,quiescent=False,audited=False,unhandled=0))
  assert 'class ' in (A/'corpus-fetch-1/data'/c['file']).read_text()
 nonpass.append(dict(id=c['id'],status=c['status'],category=category,source_note=note,raw_record=c,source=bind(A/'corpus-fetch-1/data'/c['file'])))
assert Counter(c['category'] for c in nonpass)=={'final-quiescent-unhandled-policy-veto':10,'metadata-class':4,'parser-class':4}
write(O/'nonpass-classification.json',dict(status='observed_statuses_preserved',rows=nonpass,qualification='Five synchronous bodies each retain one final unhandled rejection in both modes. Flags0 and empty error fields indicate host-policy veto, not a reported body assertion exception. No claim of full conformance or exact rejected-value identity.'))
binary=read(A/'parent-binary.json');actual=bind(Path(binary['path']))
assert actual=={k:binary[k] for k in ('path','bytes','sha256')}
assert actual['bytes']==4416216 and actual['sha256']==r['binary_sha256']==parent_controls['binary']['sha256']
assert actual['sha256']=='80a2bc01eeb9d786c2a6042eced35d5a0da974fdc955d8c194943e9cbc22352e'
build_path=Path(binary['build_receipt']);build=read(build_path)
assert build['exit']==0 and sha((build_path.parent/build['log']).read_bytes())==build['sha256']
assert build['command']==['cargo','+1.88.0','build','--locked','--offline','--manifest-path','Cargo.toml','--features','test262-host','--release','--bin','eris-js']
old_source=read(Path(binary['published_source']))['source_sha256'];parent=read(A/'parent-source.json')['source_sha256']
assert old_source==parent
# All Rust/build inputs remain published parent bytes; Python/profile work did not rebuild the engine.
build_paths=[p for p in parent if p.startswith('src/') or p in ('Cargo.toml','Cargo.lock','build.rs')]
for p in build_paths:assert sha((A/'worktree'/p).read_bytes())==parent[p]
run_path=A/'validation/race-profile-first-1.json';run=read(run_path)
assert run['exit']==0 and sha((run_path.parent/run['log']).read_bytes())==run['sha256']
assert run['command']==['python3','-B','tools/test262_conformance.py','--binary',binary['path'],'--profile','promise-race','--output',str(A/'race-first-report.json'),'--record-baseline',str(A/'race-first-baseline.json')]
write(O/'source-review.json',dict(status='clear_static_first_result_audit',findings=[],report=bind(A/'race-first-report.json'),baseline=bind(A/'race-first-baseline.json'),run=bind(run_path),run_log=bind(run_path.parent/run['log']),oracle=bind(A/'tests-before-1/raw/tools/promise-race-profile-oracle.json'),controls2=bind(A/'controls-2/source-ready.json'),parent_controls=bind(A/'controls-parent-report.json'),parent_binary=bind(A/'parent-binary.json'),actual_binary=actual,published_source=bind(Path(binary['published_source'])),release_receipt=bind(build_path),source_build_inputs_checked=len(build_paths),classification=bind(O/'nonpass-classification.json'),checker=bind(Path(__file__)),verified=dict(case_identities=188,source_files=94,passed=170,failed_host_policy=10,unsupported_metadata_class=4,unsupported_parser_class=4,controls=90,common74_full_records_equal_parent=True,new16_full_results_equal_parent=True,all_prerequisite_hashes_exact=True,baseline_exact_report_projection=True,policy_exact_frozen_oracle=True,parent_binary_exact=True),limits='Static reconciliation of root-owned completed first run; no project execution, rerun, report mutation or synthetic relabeling. Replays and final CI/publication are separate evidence.'))
print(json.dumps(bind(O/'source-review.json')))
