"""Inert oracle assembly from independently authenticated source data."""
import ast,hashlib,json
from pathlib import Path
A=Path('/tmp/eris-promise-race-upstream-1'); W=A/'worktree'; O=A/'tests-before-1/raw/tools'
def sha(b):return hashlib.sha256(b).hexdigest()
def canonical(x):return json.dumps(x,sort_keys=True,separators=(',',':')).encode()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
s=json.loads((A/'tests-outline-1/source-oracle.json').read_bytes())
v=json.loads((A/'controls-2/variants.json').read_bytes())['variants']
o=json.loads((A/'controls-2/observations.json').read_bytes())['cases']
p=json.loads((A/'controls-2/prerequisites.json').read_bytes())
old=json.loads((W/'tools/promise-all-profile-oracle.json').read_bytes())
pre=[]
for row in o:
 variant=next(x for x in v if 'promise-race-'+x['name']==row['name'])
 policy=variant['completion_policy']
 names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+variant['includes']
 identity=dict(source_sha256=sha(variant['source'].encode()),mode=row['mode'],metadata=dict(flags=['async'] if policy else [],includes=variant['includes'],features=[],locale=[],negative=None),harness=[dict(name=n,sha256=s['raw_files']['harness/'+n]['sha256']) for n in names],completion_policy=policy)
 assert identity==row['identity']
 assert sha(json.dumps(identity,sort_keys=True,ensure_ascii=True).encode())==row['case_sha256']
 pre.append(dict(name=row['name'],mode=row['mode'],case_sha256=row['case_sha256'],source_sha256=identity['source_sha256']))
assert len(v)==8 and len(pre)==16
oracle=dict(schema=1,profile='promise-race',expected_manifest=s['expected_manifest'],manifest_sha256=s['manifest_sha256'],counts=s['counts'],metadata=s['metadata'],auxiliary_files={k:dict(bytes=r['bytes'],sha256=r['sha256']) for k,r in s['raw_files'].items() if not k.startswith('test/')},case_identities=s['case_identities'],case_identities_sha256=s['case_identities_sha256'],class_sources=s['class_sources'],features=old['features'],policy=old['policy'],policy_sha256=old['policy_sha256'],controls=v,preflight=pre,common74=p['common74'],old_tables=s['old_tables'],old_tables_sha256=s['old_tables_sha256'],original53_sha256=s['original53_sha256'],existing_oracles={name:dict(bytes=(W/'tools'/name).stat().st_size,sha256=sha((W/'tools'/name).read_bytes())) for name in ['promise-all-profile-oracle.json','promise-methods-runner-oracle.json']},old_manifest_hashes={name:sha((W/'tests/upstream'/('test262-'+name)/'manifest.json').read_bytes()) for name in ('promise-methods-async','promise-all')},scope='Source-derived identities and prospective mocked controls only; no engine results. Preserve both old Promise corpora and complete common/all guard records via their existing immutable oracles, without duplicating their source archives.')
(O/'promise-race-profile-oracle.json').write_text(json.dumps(oracle,indent=2)+'\n')
print(json.dumps(bind(O/'promise-race-profile-oracle.json')))
