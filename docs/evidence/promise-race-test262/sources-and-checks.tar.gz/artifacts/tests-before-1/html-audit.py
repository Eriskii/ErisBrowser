#!/usr/bin/env python3
"""Independent source/data peer; never imports project modules or executes tests."""
from pathlib import Path
import ast
import collections
import difflib
import hashlib
import json
ROOT=Path('/tmp/eris-promise-race-upstream-1'); HERE=ROOT/'tests-before-1'; WORK=ROOT/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(Path(p).read_text())
def canon(o):return json.dumps(o,sort_keys=True,separators=(',',':')).encode()
def check(b):assert bind(b['path'])==b,b
hold=load(HERE/'source-ready.json')
assert sha((HERE/'source-ready.json').read_bytes())=='4f04ae5e749a35bcdb93ce182d6c899186f05ffc3a254a4f90cad2b0282d7681'
for b in hold['inputs']+hold['artifacts']:check(b)
parent=load(ROOT/'parent-source.json')
for entry in hold['paths']:
 check(entry['raw']);check(entry['diff']);assert entry['path'] not in parent['source_sha256']
 raw=Path(entry['raw']['path']).read_text()
 diff=''.join(difflib.unified_diff([],raw.splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+entry['path']))
 assert diff==Path(entry['diff']['path']).read_text()
source_path=HERE/'raw/tools/test_test262_promise_race_profile.py'
source=source_path.read_text();syntax=ast.parse(source)
cls=next(x for x in syntax.body if isinstance(x,ast.ClassDef))
names=[x.name for x in cls.body if isinstance(x,ast.FunctionDef) and x.name.startswith('test_')]
roster=load(HERE/'roster.json')
assert len(names)==hold['groups']==roster['count']==13
assert ['test_test262_promise_race_profile.PromiseRaceProfileTests.'+n for n in names]==[r['name'] for r in roster['groups']]
assert sum(r['expected_parent']=='pass' for r in roster['groups'])==2
oracle_path=HERE/'raw/tools/promise-race-profile-oracle.json';oracle=load(oracle_path)
assert ast.literal_eval(next(n.value for n in syntax.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ORACLE_SHA' for t in n.targets)))==sha(oracle_path.read_bytes())
census=load(ROOT/'corpus-fetch-1/html-census.json');by_path={r['file']:r for r in census['rows']}
manifest_path=ROOT/'corpus-1/raw/tests/upstream/test262-promise-race/manifest.json';manifest=load(manifest_path)
assert oracle['expected_manifest']==manifest and oracle['manifest_sha256']==sha(manifest_path.read_bytes())
assert oracle['metadata']=={k:r['metadata'] for k,r in by_path.items()}
helpers={p.name:sha(p.read_bytes()) for p in (ROOT/'corpus-fetch-1/data/harness').glob('*.js')}
identities=[]
for rel,row in sorted(by_path.items()):
 for mode in ['sloppy','strict']:
  ident=dict(source_sha256=row['sha256'],mode=mode,metadata=row['metadata'],harness=[dict(name=n,sha256=helpers[n]) for n in row['ordered_harness']],completion_policy=row['completion_policy'])
  fingerprint=sha(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode())
  identities.append(dict(id=rel+':'+mode,case_sha256=fingerprint,policy=row['completion_policy'],harness=row['ordered_harness'],class_excluded='class' in row['metadata']['features']))
assert identities==oracle['case_identities'] and sha(canon(identities))==oracle['case_identities_sha256']
assert oracle['class_sources']==census['summary']['class_tagged_sources']
expected_counts=dict(source_files=94,mode_cases=188,sloppy=94,strict=94,async_sources=63,sync_sources=31,negative_sources=0,class_sources=2,source_bytes=sum(r['bytes'] for r in by_path.values()),all_blob_bytes=census['summary']['data_bytes'],proof_documents=7,proof_bytes=census['summary']['proof_bytes'],flags=census['summary']['flags'],features=census['summary']['features'],includes=census['summary']['includes'])
assert oracle['counts']==expected_counts
aux={r['path']:dict(bytes=r['bytes'],sha256=r['sha256']) for r in manifest['files'] if not r['path'].startswith('test/')}
assert oracle['auxiliary_files']==aux
selected_variants=load(ROOT/'controls-2/variants.json')['variants'];selected_obs=load(ROOT/'controls-2/observations.json')['cases'];selected_prereq=load(ROOT/'controls-2/prerequisites.json')
assert oracle['controls']==selected_variants and oracle['common74']==selected_prereq['common74']
assert oracle['preflight']==[dict(name=r['name'],mode=r['mode'],case_sha256=r['case_sha256'],source_sha256=r['identity']['source_sha256']) for r in selected_obs]
# Interpret literal/name-only assignment data. This is not module execution.
module=ast.parse((WORK/'tools/import_test262.py').read_text())
assignments={t.id:n.value for n in module.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
def literal(n):
 if isinstance(n,ast.Constant):return n.value
 if isinstance(n,ast.Name):return literal(assignments[n.id])
 if isinstance(n,ast.Dict):return {literal(k):literal(v) for k,v in zip(n.keys,n.values)}
 if isinstance(n,ast.List):return [literal(v) for v in n.elts]
 if isinstance(n,ast.Tuple):return tuple(literal(v) for v in n.elts)
 if isinstance(n,ast.Set):return {literal(v) for v in n.elts}
 raise AssertionError(type(n).__name__)
tables=dict(profiles=literal(assignments['PROFILES']),roots=literal(assignments['PROFILE_ROOTS']),tree_profiles=sorted(literal(assignments['TREE_PROFILES'])))
assert len(tables['profiles'])==55 and tables==oracle['old_tables'] and sha(canon(tables))==oracle['old_tables_sha256']
oldall=load(WORK/'tools/promise-all-profile-oracle.json')
assert oracle['features']==oldall['features'] and oracle['policy']==oldall['policy'] and oracle['policy_sha256']==oldall['policy_sha256']
assert sha(json.dumps(oracle['policy'],sort_keys=True).encode())==oracle['policy_sha256']
for name,b in oracle['existing_oracles'].items():
 data=(WORK/'tools'/name).read_bytes();assert len(data)==b['bytes'] and sha(data)==b['sha256']
for profile,want in oracle['old_manifest_hashes'].items():assert sha((WORK/'tests/upstream'/('test262-'+profile)/'manifest.json').read_bytes())==want
checks=dict(status='clear_source_only',new_paths=2,test_groups=13,exact_roster=names,verified_hold_bindings=len(hold['inputs'])+len(hold['artifacts'])+4,independently_rederived_case_fingerprints=188,strict_modes=94,sloppy_modes=94,async_modes=126,sync_modes=62,class_tagged_modes_retained=4,corrected_control_sources=8,corrected_preflight_identities=16,common_identities=74,total_controls=90,old_profile_tables=55,source_predicted_parent=dict(passes=2,missing_profile_or_api_failures=11),observed_parent_results_used=False)
(HERE/'html-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
review=dict(status='clear',scope='Frozen AX 13-group profile test/oracle hold; source correctness and independent data joins only.',hold=bind(HERE/'source-ready.json'),checks=bind(HERE/'html-checks.json'),audit=bind(Path(__file__)),dependencies=[bind(ROOT/'corpus-fetch-1/html-review.json'),bind(ROOT/'corpus-fetch-1/html-census.json'),bind(ROOT/'controls-1/html-review.json'),bind(ROOT/'controls-2/html-review.json')],findings=[],checks_detail=[
'Both new paths are absent from the published parent inventory; exact full new-file diffs and all held input/artifact hashes verified. Python AST parses; all 13 discovered test methods exactly match the roster. Parent API references at import time exist, with new profile/functions only accessed when corresponding tests execute.',
'Independently rederived every one of the 188 new case fingerprints from the previously audited original source bytes, exact metadata and ordered helper hashes. Timeout remains absent. 94 sources, 63 async/31 sync, 126/62 completion policies, and both class-tagged sources/four modes remain in the full denominator.',
'Oracle manifest, all nine helper/legal auxiliary bindings, census, selected corrected control sources, 16 preflight identities and common74 join the reviewed immutable holds exactly. The old descriptor-deletion defect is not reintroduced.',
'Tree mutations cover the commit and every ancestor, truncated/drop/hash/rename/duplicate leaf entries and wrong selection inventories. Offline replay requires exact manifest and full source/proof bytes. Source, all seven helpers and both legal files are corrupted independently.',
'Rehashed-loader mutations update local bytes/SHA256 before loading, so root-linked Git blobs must reject them. Deleted listed/unlisted sources, compareArray helper and declared proof controls preserve their intended boundary. Added unbound JS and listed extraneous proof are tested; unlisted inert JSON rejection is deliberately not claimed.',
'90 preflight producer outputs must preserve literal sources, complete fingerprints, exact ordered harnesses, policy integers and same-mode prerequisite data. Pair-positive failure is mode-isolated. Wrong exact sync error, unauthenticated/missing async completion and fatal-resource negative evidence are injected while positives remain healthy.',
'Gate controls cover empty/common-only/missing/duplicate/extra/wrong-mode/wrong-name/unverified rosters and require blocked188, no case calls and no baseline. Missing feature exit2 produces adapter-error; complete valid legacy ERJR2 lacks evidence and remains failed/unverified. Both are transport mocks, not actual binary observations.',
'Synthetic reporting deliberately supplies final-unhandled host failures for all metadata-eligible rows: mock184failed/4class-unsupported is not an outcome forecast. Resource/timeout/adapter-error injection prevents baseline publication. Ordinary failures remain recorded under unchanged host policy.',
'All 55 old profile/root/tree tables independently reconstructed from literal/name-only parent AST data. The old232/458 and98/196 corpora, policies, original common37/74 and all8/16 added guards are checked through hash-bound existing immutable oracles. Original53 policy checks remain in their existing suite; the separate root-owned17 exclusion entries across15 old files are outside this new-test hold.',
'All adapters and network calls are mocked or explicitly forbidden by setUp. Reused selected_observation/report helpers stay source-bound. No runtime, host, feature, cap or protocol changes are requested by these tests.'
],limits=['No project code, importer, runner, JS, compiler or test was executed by this peer. stdlib AST/JSON/hash/diff inspection only.','Predicted parent2pass/11fail is source-derived after the corpus111 and two test files are made available. Later assertions and subcases in failing parent groups would be unreached.','Parent Python543 and separately observed90 controls supplied by root were not used as oracle inputs or represented as execution of these 13 groups.','Final production correctness and actual candidate/upstream results require separate root-owned execution and review.'])
(HERE/'html-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(review=bind(HERE/'html-review.json'),checks=bind(HERE/'html-checks.json')),indent=2))
