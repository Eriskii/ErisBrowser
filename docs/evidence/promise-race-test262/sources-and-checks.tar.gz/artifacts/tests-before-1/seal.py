"""Inert source-only hold verification and binding; does not run tests."""
import ast,difflib,hashlib,json
from pathlib import Path
A=Path('/tmp/eris-promise-race-upstream-1'); H=A/'tests-before-1'; W=A/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
parent=json.loads((A/'parent-source.json').read_bytes())['source_sha256']
paths=['tools/test_test262_promise_race_profile.py','tools/promise-race-profile-oracle.json']
for path in paths:assert path not in parent and not (W/path).exists()
code=(H/'raw'/paths[0]).read_text(); module=ast.parse(code)
cls=next(n for n in module.body if isinstance(n,ast.ClassDef))
groups=[n.name for n in cls.body if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')]
assert len(groups)==13
oracle=json.loads((H/'raw'/paths[1]).read_bytes())
assert "ORACLE_SHA = '"+sha((H/'raw'/paths[1]).read_bytes())+"'" in code
controls=json.loads((A/'controls-2/variants.json').read_bytes())['variants']
assert oracle['controls']==controls
assert len(oracle['case_identities'])==188
assert oracle['manifest_sha256']==sha((A/'corpus-1/raw/tests/upstream/test262-promise-race/manifest.json').read_bytes())
# Cross-check every held control artifact and exact unchanged source joins.
control_hold=json.loads((A/'controls-2/source-ready.json').read_bytes())
for r in control_hold['files']:
 data=(A/'controls-2'/r['path']).read_bytes();assert (len(data),sha(data))==(r['bytes'],r['sha256'])
source_paths=['tools/import_test262.py','tools/test262_conformance.py','tools/test_test262_promise_runner.py','tools/test_test262_promise_all_profile.py','tools/promise-all-profile-oracle.json','tools/promise-methods-runner-oracle.json']
for path in source_paths:assert sha((W/path).read_bytes())==parent[path]
(H/'diffs').mkdir(exist_ok=True)
patches=[]
for path in paths:
 raw=H/'raw'/path;patch=H/'diffs'/(Path(path).name+'.patch')
 patch.write_text(''.join(difflib.unified_diff([],raw.read_text().splitlines(keepends=True),fromfile='/dev/null',tofile='b/'+path)))
 patches.append(dict(path=path,before='absent in published parent and current worktree',raw=bind(raw),diff=bind(patch)))
roster=[]
for name in groups:
 preservation=name in {'test_all_raw_metadata_modes_and_requested_helpers_match_independent_census','test_existing_55_tables_and_both_promise_profiles_remain_exact'}
 roster.append(dict(name='test_test262_promise_race_profile.PromiseRaceProfileTests.'+name,parent_api_eligible=True,expected_parent='pass' if preservation else 'missing-profile or new-preflight API failure',qualification='Parent compile/import does not require new APIs at module scope; corpus111 and two test artifacts must be imported first. Synthetic mocks do not run any JS or subprocess.'))
write(H/'roster.json',dict(groups=roster,count=13,source_predicted_parent=dict(pass_groups=2,nonpass_groups=11),actual_parent_observation=None))
write(H/'notes.json',dict(status='frozen_source_only_before_profile_production',scope='13 selected Python groups; one new test module and oracle; no existing tests altered by this hold.',derivation='Independent reconstruction of six binary Git trees and103 root-linked blobs; inline metadata census and188 case hashes derive from original bytes. All absent timeout fields remain absent. Existing55 tables extracted from source AST; no project import.',controls='Selected corrected controls2; both API sources use verifyProperty restore:true. Six other sources/common74 unchanged. Four API mode identities independently recomputed from source; no parent-observation outcomes used.',draft_correction='Unsealed controls1 oracle/build script retained under draft-before-control-correction. No tests executed before this freeze.',outline_refinements=['A valid legacy ERJR2 complete response is failed/nonverified, whereas unavailable host exit2 is adapter-error; neither can admit upstream cases.','Unbound proof witness is declared in manifest; unlisted inert JSON is not claimed to be rejected by current loader.','Final-unhandled synthetic results are report-policy fixtures, not predictions for any upstream source.','Existing unaudited completion-error verifier policy is unchanged; negative controls use wrong exact sync errors, missing/unauthenticated async completion, and fatal resource evidence.'],limits='No new feature, resource allowance, loader limit, protocol, host behavior, Rust or old profile policy.',reuse='Existing selected_observation/report helpers are reused. Both old Promise profile oracles are hash-bound, avoiding duplicate old654 identity archives. Original53 policy witnesses remain independently covered by existing tests plus root-owned exclusion adapters.',old_test_migrations='Root owns17 exclusion entries across15 files in selection2. None authored here.',no_execution='Only stdlib AST/JSON/source/hash/diff work; parent and candidate test execution remain root-owned.'))
inputs=[A/'parent-source.json',A/'root/selection-1.json',A/'root/selection-2.json',A/'tests-outline-1/source-ready.json',A/'tests-outline-1/derivation-receipt.json',A/'corpus-1/source-ready.json',A/'controls-1/source-ready.json',A/'controls-2/source-ready.json']+[W/p for p in source_paths]
write(H/'source-ready.json',dict(status='frozen_executable_test_source_no_project_execution',base='4819802e878be7a88f90fb1a214f89f81fb87b98',groups=13,paths=patches,inputs=[bind(p) for p in inputs],artifacts=[bind(H/p) for p in ['build-oracle.py','roster.json','notes.json']],eligibility='All13 import against parent APIs; two preservation groups source-predicted pass, eleven fail on absent profile/new preflight. Actual baseline not yet observed.',literal_result_scope='Metadata/identities/prospective mock verifier results only; no real upstream pass/failed/unsupported counts predicted.'))
print(json.dumps(bind(H/'source-ready.json')))
