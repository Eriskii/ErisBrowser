#!/usr/bin/env python3
"""Source/data-only independent control audit; no project import or engine invocation."""
from pathlib import Path
import ast
import difflib
import hashlib
import json

ROOT = Path('/tmp/eris-promise-race-upstream-1')
HERE = ROOT / 'controls-1'
DATA = ROOT / 'corpus-fetch-1/data'

def sha(b): return hashlib.sha256(b).hexdigest()
def binding(p):
    p=Path(p); b=p.read_bytes(); return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(name): return json.loads((HERE/name).read_text())
def fingerprint(o): return sha(json.dumps(o,sort_keys=True,ensure_ascii=True).encode())
def check(b): assert binding(b['path'])==b,b

hold=read('source-ready.json'); variants=read('variants.json')['variants']; observations=read('observations.json'); prereqs=read('prerequisites.json'); bindings=read('bindings.json')
assert sha((HERE/'source-ready.json').read_bytes())=='4df919f6d67be17e51a3ec82b92b8da7c705e907f1136dd36037d0a54dbf51d5'
for entry in hold['files']:
    b=(HERE/entry['path']).read_bytes()
    assert len(b)==entry['bytes'] and sha(b)==entry['sha256']
for key in ['parent','runner','methods_oracle','full_fetch_receipt','plan']:
    check(bindings[key])
for b in bindings['helpers']:check(b)
source=Path(bindings['runner']['path']).read_text()
module=ast.parse(source)
function=next(n for n in module.body if isinstance(n,ast.FunctionDef) and n.name=='promise_preflight_variants')
common=ast.literal_eval(next(n for n in function.body if isinstance(n,ast.Return)).value)
old_oracle=json.loads(Path(bindings['methods_oracle']['path']).read_text())
assert common==old_oracle['controls'] and len(common)==37
assert sha(json.dumps(common,sort_keys=True,separators=(',',':')).encode())==prereqs['common_variants_canonical_sha256']
assert [v['name'] for v in variants]==['api','api-mismatch','winner','winner-mismatch','rejection-identity','rejection-identity-mismatch','shared-callbacks','shared-callbacks-mismatch']
for row in variants:assert (HERE/'raw'/ (row['name']+'.js')).read_text()==row['source']
by_name={row['name']:row for row in variants}
mutations={'api':('','Promise.race = function race(value) {};\n'),'winner':('assert.compareArray([value], [7]);','assert.compareArray([value], [3]);'),'rejection-identity':('assert.sameValue(reason, marker);','assert.notSameValue(reason, marker);'),'shared-callbacks':('assert.sameValue(resolves, 4);','assert.sameValue(resolves, 2);')}
for name,(a,b) in mutations.items():
    original=by_name[name]['source'];changed=by_name[name+'-mismatch']['source']
    assert changed==(b+original if name=='api' else original.replace(a,b,1))
    patch=''.join(difflib.unified_diff(original.splitlines(keepends=True),changed.splitlines(keepends=True),fromfile=name+'.js',tofile=name+'-mismatch.js'))
    assert patch==(HERE/'pair-diffs'/(name+'.patch')).read_text()

def identity(row,mode):
    policy=row['completion_policy']; names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+row['includes']
    assert len(names)==len(set(names))
    return dict(source_sha256=sha(row['source'].encode()),mode=mode,metadata=dict(flags=['async'] if policy else [],includes=row['includes'],features=[],locale=[],negative=None),harness=[dict(name=name,sha256=sha((DATA/'harness'/name).read_bytes())) for name in names],completion_policy=policy)

derived_common=[]
for mode in ['sloppy','strict']:
    for v in common:
        ident=identity(v,mode)
        derived_common.append(dict(name='promise-methods-'+v['name'],mode=mode,case_sha256=fingerprint(ident),source_sha256=ident['source_sha256']))
assert prereqs['common74']==derived_common
assert len(observations['cases'])==16
for index,(mode,v) in enumerate((mode,v) for mode in ['sloppy','strict'] for v in variants):
    row=observations['cases'][index];ident=identity(v,mode)
    assert row['identity']==ident and row['case_sha256']==fingerprint(ident)
    assert row['mode']==mode and row['name']=='promise-race-'+v['name'] and row['id']=='harness-preflight:'+row['name']
    assert row['expected']==v['expected'] and row['expected_verification'] is True
    required=[x for x in derived_common if x['mode']==mode]
    if v['prerequisite']:
        previous=by_name[v['prerequisite']]; prev_id=identity(previous,mode)
        required=required+[dict(name='promise-race-'+previous['name'],mode=mode,case_sha256=fingerprint(prev_id),source_sha256=prev_id['source_sha256'])]
    assert row['prerequisites']==required
    policy=v['completion_policy']; evidence=dict(policy=policy,done_calls=policy,success_prints=policy,failure_prints=0,flags=0,quiescent=True,audited=True,unhandled=0)
    result=dict(status='passed',observation=dict(status='complete',phase='runtime',error_type='',error_identity='',message='',harness='',completion=evidence))
    unconstrained=[]
    if v['expected']=='synchronous-exception':
        evidence['flags']=256; result['status']='failed';result['observation'].update(status='exception',error_type='Test262Error');del result['observation']['message'];unconstrained=['observation.message']
    elif v['expected']=='completion-error':
        evidence.update(success_prints=0,failure_prints=1,flags=1);result['status']='failed';result['observation'].update(status='host-failure',phase='host',message='completion-error')
    assert row['prospective_result']==result and row['unconstrained_fields']==unconstrained
expected_new=[dict(name='promise-race-'+v['name'],mode=mode) for mode in ['sloppy','strict'] for v in variants]
assert prereqs['new16']==expected_new
assert prereqs['full90']==[dict(name=x['name'],mode=x['mode']) for x in derived_common]+expected_new
assert len({(x['name'],x['mode']) for x in prereqs['full90']})==90
checks=dict(status='source_and_identity_checks_complete_with_api_literal_finding',bound_files=len(hold['files']),raw_sources=8,pair_diffs=4,new_identities=16,unchanged_common_sources=37,unchanged_common_identities=74,exact_unique_roster=90,dependencies='37 same-mode common controls for every row; corresponding same-mode positive added for each mismatch',prospective_observation_schemas='All 16 declared result structures agree with their intended expected classes and selected host protocol. The API source defect prevents two declared positive mode outcomes from actually reaching that class.',common_ast_extraction='Only ast.literal_eval of the literal return value; no project module import or function execution.')
(HERE/'html-checks.json').write_text(json.dumps(checks,indent=2)+'\n')
review=dict(status='finding',hold=binding(HERE/'source-ready.json'),checks=binding(HERE/'html-checks.json'),audit=binding(Path(__file__)),source_bindings=[binding(ROOT/'worktree/src/script/promises/all_semantics.rs'),binding(ROOT/'worktree/src/script/test262_host.rs'),binding(DATA/'harness/propertyHelper.js'),binding(DATA/'harness/assert.js'),binding(DATA/'harness/doneprintHandle.js')],findings=[dict(id='api-descriptor-helper-deletes-api',severity='blocks_control_freeze',paths=['raw/api.js','raw/api-mismatch.js'],source_proof='Pinned propertyHelper.js verifyProperty calls isConfigurable at line119; isConfigurable deletes obj[name] at line140. verifyProperty only restores originalDesc when options.restore is supplied at lines131-132. The first descriptor check therefore removes Promise.race, so the next name check receives undefined. Both sources omit restoration.',impact='The positive API control cannot pass under the declared helper contract. The mismatch fails before the intended constructibility-only difference, so its observed exception would not prove the intended guard.',correction='Retain this hold; add { restore: true } to all three verifyProperty calls in both API sources and regenerate only their hashes/fingerprints and dependent control records. Keep the replacement function and all assertions unchanged.')],clear_other_checks=['All 18 held file bindings, all bound parent/helper inputs and four exact pair diffs verified.','All 37 common variants exactly equal the published runner literal return and original oracle; all 74 common fingerprints independently reproduced. All 16 new fingerprints, harness order, absent timeout, mode-major order and 37/38 prerequisite lists independently reproduced.','Winner queue order is 7, then 9, then released3; race result observes7. Empty race handlers remain pending through the finite result checkpoint. Equal/unequal compareArray controls exercise the authentic assert.js implementation; mismatch only changes expected7 to3.','Rejection identity is preserved; input/race/child rejections are handled. The mismatched identity assertion is forwarded to authenticated DONE(error), yielding completion-error, not an exact serialized intrinsic or Test262Error identity claim.','Generic C returns the explicit capability object; both then calls receive the exact reusable ordinary fulfilled/rejected functions, each executes twice per input and its actual return is asserted. Four calls per callback and third next exhaustion are correct; mismatch expects resolve count2.','Declared successful/synchronous-exception/completion-error snapshots match current protocol field/flag rules, with synchronous message unconstrained and no predicted timing.'],limits=['Source-only review. No project import, runner, compiler, JS, engine or test execution.','This is not clearance of hold1: the API control finding must be corrected and resealed.','The positive empty-race witness establishes only its stated finite checkpoint; no claim of observing permanent pending state.'])
(HERE/'html-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(review=binding(HERE/'html-review.json'),checks=binding(HERE/'html-checks.json')),indent=2))
