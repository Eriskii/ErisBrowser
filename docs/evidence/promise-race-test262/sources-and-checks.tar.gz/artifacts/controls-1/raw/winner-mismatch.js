assert.sameValue(typeof compareArray, 'function');
assert.sameValue(typeof assert.compareArray, 'function');
assert.sameValue(compareArray([1, 2], [1, 2]), true);
assert.sameValue(compareArray([1, 2], [2, 1]), false);
var emptyCalls = 0;
Promise.race([]).then(
  function() { emptyCalls++; },
  function() { emptyCalls++; }
);
var release;
var pending = new Promise(function(resolve) { release = resolve; });
Promise.race([pending, Promise.resolve(7), 9]).then(function(value) {
  assert.sameValue(emptyCalls, 0);
  assert.compareArray([value], [3]);
}).then($DONE, $DONE);
release(3);
