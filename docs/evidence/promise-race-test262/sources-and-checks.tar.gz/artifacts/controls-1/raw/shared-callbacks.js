var capability = {};
var resolves = 0;
var rejects = 0;
var nextCalls = 0;
function fulfilled(value) { resolves++; return 'F' + value; }
function rejected(value) { rejects++; return 'R' + value; }
function C(executor) {
  executor(fulfilled, rejected);
  return capability;
}
C.resolve = function(value) {
  assert.sameValue(this, C);
  return { then: function(onFulfilled, onRejected) {
    assert.sameValue(onFulfilled, fulfilled);
    assert.sameValue(onRejected, rejected);
    assert.sameValue(onFulfilled(value), 'F' + value);
    assert.sameValue(onFulfilled(value + 10), 'F' + (value + 10));
    assert.sameValue(onRejected(value), 'R' + value);
    assert.sameValue(onRejected(value + 10), 'R' + (value + 10));
  } };
};
var iterator = { next: function() {
  nextCalls++;
  return nextCalls <= 2 ? { done: false, value: nextCalls } : { done: true };
} };
var source = {};
source[Symbol.iterator] = function() { return iterator; };
assert.sameValue(Promise.race.call(C, source), capability);
assert.sameValue(resolves, 4);
assert.sameValue(rejects, 4);
assert.sameValue(nextCalls, 3);
