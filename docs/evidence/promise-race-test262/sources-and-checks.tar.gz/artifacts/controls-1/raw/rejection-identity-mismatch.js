var marker = {};
Promise.race([Promise.reject(marker), new Promise(function() {})]).then(
  function() { throw new Test262Error('unexpected fulfillment'); },
  function(reason) { assert.notSameValue(reason, marker); }
).then($DONE, $DONE);
