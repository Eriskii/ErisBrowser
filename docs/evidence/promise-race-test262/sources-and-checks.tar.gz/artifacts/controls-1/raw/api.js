verifyProperty(Promise, 'race', {
  value: Promise.race, writable: true, enumerable: false, configurable: true
});
verifyProperty(Promise.race, 'name', {
  value: 'race', writable: false, enumerable: false, configurable: true
});
verifyProperty(Promise.race, 'length', {
  value: 1, writable: false, enumerable: false, configurable: true
});
assert.throws(TypeError, function() { new Promise.race([]); });
