var marker = {};
Promise.race([Promise.reject(marker), new Promise(function() {})]).then(
  function() { throw new Test262Error('unexpected fulfillment'); },
  function(reason) { assert.sameValue(reason, marker); }
).then($DONE, $DONE);
