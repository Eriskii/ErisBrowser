#!/usr/bin/env python3
"""Source-only importer peer. Reads Python AST/literals; no project execution."""
from pathlib import Path
import ast
import difflib
import hashlib
import json
ROOT=Path('/tmp/eris-promise-race-upstream-1');HERE=ROOT/'production-importer-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(Path(p).read_text())
h=load(HERE/'source-ready.json')
assert sha((HERE/'source-ready.json').read_bytes())=='d7c5c3995ece945a2979687abcd48ca800c6d9c896dc1abb98576e2b5bb777bd'
assert len(h['paths'])==1 and h['paths'][0]['path']=='tools/import_test262.py'
row=h['paths'][0]
for b in [row['before'],row['raw'],row['diff'],h['source_contract'],h['corpus']]:assert bind(b['path'])==b
before=Path(row['before']['path']).read_text();raw=Path(row['raw']['path']).read_text()
assert sha(before.encode())==load(ROOT/'parent-source.json')['source_sha256']['tools/import_test262.py']
assert ''.join(difflib.unified_diff(before.splitlines(keepends=True),raw.splitlines(keepends=True),fromfile='a/tools/import_test262.py',tofile='b/tools/import_test262.py'))==Path(row['diff']['path']).read_text()
newtree=ast.parse(raw);oldtree=ast.parse(before)
newfuncs={n.name:n for n in newtree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))};oldfuncs={n.name:n for n in oldtree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}
assert set(newfuncs)==set(oldfuncs)
unchanged=[]
for name in newfuncs:
 if name not in ['profile_tree_inventory','import_corpus']:
  assert ast.get_source_segment(raw,newfuncs[name])==ast.get_source_segment(before,oldfuncs[name]),name
  unchanged.append(name)
block="""PROMISE_RACE_DIRECTORIES = {'Promise/race': 94}
PROMISE_RACE_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js', 'compareArray.js',
                        'isConstructor.js', 'promiseHelper.js', 'propertyHelper.js'}
"""
branch="""    if profile == 'promise-race':
        if (PROFILES[profile] != PROMISE_RACE_DIRECTORIES
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.race frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            PROMISE_RACE_DIRECTORIES, 'test/built-ins', read,
            auxiliary_helpers=PROMISE_RACE_HELPERS)
        if any(len(listings[name]) != count for name, count in PROMISE_RACE_DIRECTORIES.items()):
            raise ValueError('Promise.race complete directory counts differ')
        return listings, proof, description
"""
guard="""    if profile == 'promise-race' and harness != PROMISE_RACE_HELPERS:
        raise ValueError('Promise.race requested harness differs from the frozen seven helpers')
"""
scope=load(ROOT/'corpus-1/raw/tests/upstream/test262-promise-race/manifest.json')['scope']
assert scope==h['scope']
operations=[(block+"TREE_PROFILES = {'promise-race', ","TREE_PROFILES = {"),("PROFILES = {'promise-race': PROMISE_RACE_DIRECTORIES, ","PROFILES = {"),("PROFILE_ROOTS = {'promise-race': 'test/built-ins', ","PROFILE_ROOTS = {"),(branch,''),(guard,''),("    if profile in {'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'","    if profile in {'promise-all', 'promise-methods-async', 'typedarray-views'"),("        'promise-race': "+repr(scope)+",\n",'')]
inverse=raw
for a,b in operations:
 assert inverse.count(a)==1,a
 inverse=inverse.replace(a,b,1)
assert inverse==before and ast.dump(ast.parse(inverse),include_attributes=False)==ast.dump(oldtree,include_attributes=False)
# Resolve only literal/name-containing constant data; never evaluate calls or code.
def tables(tree):
 assignments={t.id:n.value for n in tree.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
 def lit(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return lit(assignments[n.id])
  if isinstance(n,ast.Dict):return {lit(k):lit(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.Set):return {lit(v) for v in n.elts}
  if isinstance(n,ast.List):return [lit(v) for v in n.elts]
  if isinstance(n,ast.Tuple):return tuple(lit(v) for v in n.elts)
  raise AssertionError(type(n).__name__)
 return {key:lit(assignments[key]) for key in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES']},assignments,lit
old,_,_=tables(oldtree);new,constants,lit=tables(newtree)
assert len(old['PROFILES'])==55 and len(new['PROFILES'])==56
assert new['PROFILES'].pop('promise-race')=={'Promise/race':94}
assert new['PROFILE_ROOTS'].pop('promise-race')=='test/built-ins'
new['TREE_PROFILES'].remove('promise-race');assert new==old
assert lit(constants['PROMISE_RACE_DIRECTORIES'])=={'Promise/race':94}
assert lit(constants['PROMISE_RACE_HELPERS'])==set(load(ROOT/'corpus-fetch-1/html-census.json')['summary']['helper_names'])
review=dict(status='clear',scope='One-file source-only importer production review; frozen race selection and unchanged old paths.',hold=bind(HERE/'source-ready.json'),raw=row['raw'],audit=bind(Path(__file__)),dependencies=[bind(ROOT/'tests-before-1/html-review.json'),bind(ROOT/'corpus-fetch-1/html-review.json'),bind(ROOT/'corpus-1/source-ready.json')],checks=dict(exact_full_diff=True,exact_seven_replacement_inverse=True,ast_inverse=True,old_profiles=55,new_profiles=56,unchanged_existing_functions=unchanged,selected_sources=94,selected_helpers=7),findings=[],assessment=[
'New static selection is exactly Promise/race94 at test/built-ins, with the reviewed seven helpers including compareArray. Removing the new profile entry from profile/root/tree tables recovers all55 old entries exactly.',
'New dispatch rejects altered frozen selection/root and delegates to the byte-identical git_tree_inventory with the selected helper set. Its existing complete binary-tree reconstruction, pinned revision/root links, safe regular JS inventory and helper/legal blob authentication are retained.',
'Import validates every fetched test blob against the authenticated leaf before parsing its unchanged metadata. Derived harness closure must equal the frozen seven, then every helper/legal blob is independently checked against the pinned auxiliary map. No class/source filtering, repair or mode manipulation is added.',
'Existing limits, proof document/binary-tree bounds, network path construction, byte parsing, output serialization, defaults, old profile scope strings and all unchanged helper/function bodies remain exact. The only widened auxiliary-verification set adds race itself.',
'New manifest scope string is byte-for-byte the independently frozen corpus scope. Existing writer sorting/schema and selected raw/proof data therefore align with the held111-file corpus. This is a source correspondence check, not an observed importer replay.',
'All seven localized changes reverse to the complete parent bytes and AST. No Rust/runtime/host/runner changes are present in this hold; runner review is separately assigned.'
],limitations=['No project module import, importer/runner execution, tests, compiler, JS or network calls by this peer. Only inert stdlib source/AST/hash/diff inspection.','Root-reported parent13 result2pass/11error with36 subtest errors is separate evidence; it was not used to alter frozen assertions or establish candidate success.'])
(HERE/'html-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(bind(HERE/'html-review.json'),indent=2))
