import hashlib
import json
import sys
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

source = json.loads((A / 'source-parent-tests.json').read_bytes())
baseline = json.loads((A / 'root/parent-profile-baseline.json').read_bytes())
assert (baseline['groups'], baseline['passed'], baseline['error_groups']) == (13, 2, 11)
for path, sha in source['source_sha256'].items():
    assert bind(W / path)['sha256'] == sha, path
holds = [('production-importer-1', Path(sys.argv[1])),
         ('production-runner-1', A / 'runner-script-review-1/source-review.json'),
         ('adapters-1', A / 'adapters-1/layout-review.json')]
rows, receipts = [], []
for hold, peer in holds:
    assert 'clear' in json.loads(peer.read_bytes())['status'], peer
    ready = A / hold / 'source-ready.json'
    record = json.loads(ready.read_bytes())
    for row in record.get('paths', record.get('files', [])):
        path = row.get('path', row.get('relative'))
        assert bind(W / path)['sha256'] == row['before']['sha256'], path
        assert bind(Path(row['raw']['path'])) == row['raw']
        rows.append((path, row['raw']))
    receipts.append(dict(hold=bind(ready), peer=bind(peer)))
assert len(rows) == len({p for p, _ in rows}) == 17
for path, raw in rows:
    (W / path).write_bytes(Path(raw['path']).read_bytes())
    source['source_sha256'][path] = raw['sha256']
source['source_sha256'] = dict(sorted(source['source_sha256'].items()))
source['scope'] = 'Candidate Promise.race profile: published Rust/build sources unchanged, complete corpus, frozen tests, two production tools and fifteen historical enumeration adapters.'
(A / 'source-candidate.json').write_text(json.dumps(source, indent=2) + '\n')
(A / 'root/production-import.json').write_text(json.dumps(dict(
    status='verified_import', source=bind(A/'source-candidate.json'),
    baseline=bind(A/'root/parent-profile-baseline.json'), holds=receipts,
    changed_paths=[p for p, _ in rows]), indent=2) + '\n')
print('Imported 2 production tools and 15 narrow historical enumeration adapters; source inventory1360.')
