import gzip
import hashlib
import io
import json
import tarfile
from pathlib import Path, PurePosixPath

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
E = W / 'docs/evidence/promise-race-test262'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))

def read(name):
    return json.loads((A/name).read_bytes())

final = read('source-final.json')
parent = read('parent-source.json')
changed = sorted(p for p,h in final['source_sha256'].items() if parent['source_sha256'].get(p) != h)
assert len(changed) == 132
for p,h in final['source_sha256'].items():
    assert sha((W/p).read_bytes()) == h, p
members = {}

def add(name, path, role):
    assert not path.is_symlink() and path.is_file(), path
    assert name not in members and not PurePosixPath(name).is_absolute() and '..' not in PurePosixPath(name).parts
    data = path.read_bytes()
    members[name] = dict(data=data, origin=str(path), role=role)

for p in changed:
    add('sources/'+p, W/p, 'changed-source')
for row in read('documentation-1/source-ready.json')['files']:
    assert bind(W/row['relative'])['sha256'] == row['raw']['sha256']
    add('documentation/'+row['relative'], W/row['relative'], 'published-documentation')

directories = ['controls-1', 'controls-2', 'tests-outline-1', 'tests-before-1',
               'production-importer-1', 'production-runner-1', 'adapters-1', 'ci-1',
               'runner-script-review-1', 'ci-script-review-1', 'candidate-source-review-1',
               'first-results-review-1', 'final-validation-review-1',
               'documentation-outline-1', 'documentation-1', 'parent-build',
               'validation', 'replay-parent']
for directory in directories:
    assert (A/directory).is_dir(), directory
    for path in sorted((A/directory).rglob('*')):
        if path.is_file() and '__pycache__' not in path.parts:
            add('artifacts/'+str(path.relative_to(A)), path, 'validation-artifact')
for path in sorted((A/'root').glob('*')):
    if path.is_file() and path.name not in ('evidence-selection.json', 'publication-verification.json', 'git-publication.json'):
        add('artifacts/root/'+path.name, path, 'root-receipt-or-script')
for name in ['parent-source.json', 'source-parent-corpus.json', 'source-parent-tests.json',
             'source-candidate.json', 'source-candidate-ci.json', 'source-final.json',
             'parent-binary.json', 'controls-parent-report.json',
             'race-first-report.json', 'race-first-baseline.json', 'race-replay-report.json',
             'all-replay-report.json', 'existing-replay-report.json', 'run-tool.py',
             'corpus-1/source-ready.json', 'corpus-fetch-1/receipt.json',
             'corpus-fetch-1/html-review.json', 'corpus-fetch-1/html-census.json',
             'plans/source-ready.json', 'plans/source-bindings.json']:
    add('artifacts/'+name, A/name, 'validation-artifact')
ledger = read('root/final-validation.json')
peer = read('final-validation-review-1/source-review.json')
assert 'clear' in peer['status']
selection = [dict(path=name, bytes=len(item['data']), sha256=sha(item['data']),
                  origin=item['origin'], role=item['role']) for name,item in sorted(members.items())]
assert sum(row['bytes'] for row in selection) < 32*1024*1024
selection_path = A/'root/evidence-selection.json'
selection_path.write_text(json.dumps(dict(status='frozen', members=selection,
    excluded='Compiled binary, full unchanged repository, raw fetch duplicate cache and subsequent publication/CI state. Absolute origins preserve provenance; archive paths provide portable retained bytes.'), indent=2)+'\n')
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for name,item in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(item['data'])
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(item['data']))
packed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
assert len(packed) < 8*1024*1024
E.mkdir(parents=True, exist_ok=True)
archive_path = E/'sources-and-checks.tar.gz'
assert not archive_path.exists()
archive_path.write_bytes(packed)
summary = dict(schema=1, status='verified',
    archive=dict(path=archive_path.name, bytes=len(packed), sha256=sha(packed),
                 member_bytes=sum(row['bytes'] for row in selection), uncompressed_tar_bytes=len(raw.getvalue()),
                 selected_max_uncompressed_bytes=32*1024*1024),
    source_count=132, documentation_count=5, artifact_count=len(selection)-137,
    source_inventory=bind(A/'source-final.json'),
    claims=dict(base=ledger['base'], scope=ledger['scope'], source_files=94, mode_cases=188,
        counts=dict(passed=170, failed=10, unsupported=8), verified_controls=90,
        python_passed=556, old_python_names_preserved=543, new_test_groups=13,
        old_case_records_preserved=654, old_control_records_preserved=164,
        race_replay_exact_cases=188, race_replay_exact_controls=90,
        source_inputs=1361, changed_source_inputs=132,
        binary_sha256=ledger['parent_binary']['sha256'],
        rust_validation=ledger['rust_validation'], limitations=ledger['limitations']),
    claims_authority=dict(ledger=bind(A/'root/final-validation.json'),
                          peer=bind(A/'final-validation-review-1/source-review.json')),
    selection=bind(selection_path), members=selection)
(E/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
with tarfile.open(archive_path,'r:gz') as archive:
    assert archive.getnames() == [row['path'] for row in selection]
    for row in selection:
        m=archive.getmember(row['path']); assert m.isfile() and not m.issym() and not m.islnk()
        data=archive.extractfile(m).read(); assert len(data)==row['bytes'] and sha(data)==row['sha256']
print(json.dumps(dict(members=len(selection),sources=132,docs=5,archive=bind(archive_path))))
