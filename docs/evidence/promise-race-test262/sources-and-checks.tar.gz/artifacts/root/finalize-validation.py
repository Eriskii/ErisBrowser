import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(name):
    return json.loads((A/name).read_bytes())

source = read('source-final.json')['source_sha256']
parent = read('parent-source.json')['source_sha256']
for path, sha in source.items():
    assert bind(W/path)['sha256'] == sha, path
changed = sorted(p for p, sha in source.items() if parent.get(p) != sha)
assert len(source) == 1361 and len(changed) == 132
assert not any(p.endswith('.rs') or p.startswith('crates/') or p.startswith('src/') or 'Cargo' in p for p in changed)
assert len([p for p in changed if p in parent]) == 18
peers = [A/name for name in (
    'tests-before-1/html-review.json', 'production-importer-1/html-review.json',
    'runner-script-review-1/source-review.json', 'adapters-1/layout-review.json',
    'ci-script-review-1/source-review.json', 'candidate-source-review-1/source-review.json',
    'first-results-review-1/source-review.json')]
assert all('clear' in json.loads(p.read_bytes())['status'] for p in peers)
python = read('root/python-validation.json')
replays = read('root/replay-validation.json')
assert python['full']['passed'] == 556 and replays['counts'] == dict(passed=170, failed=10, unsupported=8)
record = dict(status='verified', base='4819802e878be7a88f90fb1a214f89f81fb87b98',
    scope='Complete pinned94-source Promise.race test profile; no Rust engine/runtime/host policy or resource limit changes.',
    source=bind(A/'source-final.json'), source_count=len(source), changed_source_count=len(changed),
    changed_sources=changed, unchanged_parent_sources=1229,
    parent_source=bind(A/'parent-source.json'), parent_python=bind(A/'root/parent-python-baseline.json'),
    parent_new_tests=bind(A/'root/parent-profile-baseline.json'),
    python=python, replays=replays, peer_reviews=[bind(p) for p in peers],
    parent_binary=read('parent-binary.json'),
    rust_validation='Published AW release binary reused, all Rust/build inputs unchanged; no new local Rust build/test claim in this profile-only checkpoint. GitHub CI will independently rebuild after publication.',
    correction_history='Controls1 had destructive propertyHelper calls; static review caught this before any execution. Controls2 adds restore:true to six calls. All thirteen executable test expectations then remained unchanged through parent/candidate runs.',
    limitations='This completes only the pinned immediate Promise/race selection. No full Promise/ECMAScript/web compatibility, production-security, GPU-device or Chromium-relative performance claim.')
(A/'root/final-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(bind(A/'root/final-validation.json')))
