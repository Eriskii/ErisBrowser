import concurrent.futures,hashlib,importlib.util,json,re,sys,time
from pathlib import Path
sys.dont_write_bytecode=True
A=Path(__file__).resolve().parents[1];W=A/'worktree';P=Path('/tmp/eris-promise-race-1/plans');OUT=A/'corpus-fetch-1';DATA=OUT/'data'
spec=importlib.util.spec_from_file_location('pinned_importer',W/'tools/import_test262.py');imp=importlib.util.module_from_spec(spec);spec.loader.exec_module(imp)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def read(route):
 relative=imp.tree_proof_path(route);p=P/'proof'/Path(relative).name
 if not p.exists():p=W/'tests/upstream/test262-promise-all'/relative
 return p.read_bytes()
listings,proof,desc=imp.git_tree_inventory({'Promise/race':94},'test/built-ins',read)
rows=listings['Promise/race'];assert len(rows)==94 and len({r['name'] for r in rows})==94
entries={f'test/built-ins/Promise/race/{r["name"]}':r['sha'] for r in rows};assert all(re.fullmatch(r'[A-Za-z0-9_.-]+\.js',r['name']) for r in rows)
def gitblob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def retrieve(pair):
 path,expected=pair;p=DATA/path;assert not p.exists()
 cached=P/'primary-cache'/path
 origin='retained_sample' if cached.exists() else 'pinned_raw_https'
 if cached.exists():data=cached.read_bytes()
 else:
  data=imp.fetch(f'https://raw.githubusercontent.com/{imp.REPOSITORY}/{imp.REVISION}/{path}')
 assert gitblob(data)==expected,path
 p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 return dict(relative=path,git_blob=expected,origin=origin,binding=bind(p))
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:files=list(pool.map(retrieve,sorted(entries.items())))
metadata={};helpers={'assert.js','sta.js'}
for path in sorted(entries):
 m=imp.parse_metadata((DATA/path).read_text());metadata[path]=m;helpers.update(m['includes'])
 if 'async' in m['flags']:helpers.add('doneprintHandle.js')
listings,proof,desc=imp.git_tree_inventory({'Promise/race':94},'test/built-ins',read,auxiliary_helpers=helpers)
for path,sha in sorted(desc['auxiliary_blobs'].items()):
 p=DATA/path;cached=W/'tests/upstream/test262-promise-all'/path
 if not cached.exists():cached=W/'tests/upstream/test262-array-from'/path
 if not cached.exists():cached=P/'primary-cache'/path
 if cached.exists():data=cached.read_bytes();origin='retained_pinned_auxiliary'
 else:data=imp.fetch(f'https://raw.githubusercontent.com/{imp.REPOSITORY}/{imp.REVISION}/{path}');origin='pinned_raw_https'
 assert gitblob(data)==sha,path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);files.append(dict(relative=path,git_blob=sha,origin=origin,binding=bind(p)))
for path,data in proof.items():p=OUT/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
report=dict(status='complete_authenticated_data_only_no_engine_execution',revision=imp.REVISION,directory='test/built-ins/Promise/race',test_sources=len(entries),helpers=sorted(helpers),metadata=metadata,proof_description=desc,files=files,proof=[bind(OUT/p) for p in sorted(proof)],importer=bind(W/'tools/import_test262.py'),note='Full source/metadata retrieval precedes importer/profile implementation. No mode or conformance outcome inferred here.')
(OUT/'receipt.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(sources=len(entries),helpers=sorted(helpers),files=len(files),proof_documents=len(proof))))
