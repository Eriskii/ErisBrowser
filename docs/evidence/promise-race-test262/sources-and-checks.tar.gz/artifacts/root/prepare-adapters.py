import ast,difflib,hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'adapters-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
plan=json.loads((A/'plans/legacy-adapters.json').read_bytes());files=[]
for row in plan['adapters']:
 relative=row['path'];before=(W/relative).read_text();lines=before.splitlines(keepends=True)
 for n in row['lines']:
  old=lines[n-1];assert old.count("'promise-all'")==1 and "'promise-race'" not in old;lines[n-1]=old.replace("'promise-all'", "'promise-all', 'promise-race'")
 raw=''.join(lines);assert raw.replace(", 'promise-race'",'')==before
 tree=ast.parse(raw)
 class RemoveRace(ast.NodeTransformer):
  def visit_Set(self,node):
   node.elts=[x for x in node.elts if not(isinstance(x,ast.Constant) and x.value=='promise-race')];return self.generic_visit(node)
 assert ast.dump(RemoveRace().visit(tree),include_attributes=False)==ast.dump(ast.parse(before),include_attributes=False)
 paths={}
 for kind,text in [('before',before),('raw',raw),('diffs',''.join(difflib.unified_diff(before.splitlines(True),raw.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))]:
  p=H/kind/(relative+('.patch' if kind=='diffs' else ''));p.parent.mkdir(parents=True,exist_ok=True);p.write_text(text);paths[kind]=bind(p)
 files.append(dict(relative=relative,added_exclusions=len(row['lines']),**paths))
assert len(files)==15 and sum(x['added_exclusions'] for x in files)==17
(H/'source-ready.json').write_text(json.dumps(dict(status='frozen_historical_enumeration_adapters',base='4819802e878be7a88f90fb1a214f89f81fb87b98',files=files,scope='Only17 promise-race set entries in15 historical tests. Exact byte inverse and AST inverse checked. Existing populations/hash literals/assertions unmodified; new profile receives independent new controls. No live edits or project execution.'),indent=2)+'\n')
print('Frozen15 adapters/17 exclusion entries, exact inverse.')
