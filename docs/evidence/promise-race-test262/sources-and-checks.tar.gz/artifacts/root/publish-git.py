import json
import subprocess
from pathlib import Path

A=Path(__file__).resolve().parents[1]
W=A/'worktree'
MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')

def git(directory,*args):
    return subprocess.check_output(['git','-C',str(directory),*args],text=True).strip()

v=json.loads((A/'root/publication-verification.json').read_bytes())
assert v['status']=='verified'
base='4819802e878be7a88f90fb1a214f89f81fb87b98'
assert git(W,'rev-parse','HEAD')==git(MAIN,'rev-parse','HEAD')==base
assert not git(MAIN,'status','--porcelain') and not git(W,'diff','--cached','--name-only')
paths=v['expected_commit_paths']
actual=set(git(W,'diff','--name-only').splitlines())|set(git(W,'ls-files','--others','--exclude-standard').splitlines())
assert actual==set(paths)
subprocess.run(['git','-C',str(W),'diff','--check'],check=True)
subprocess.run(['git','-C',str(W),'add','--',*paths],check=True)
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
message=A/'commit-message.txt'
message.write_text('Add complete pinned Promise.race conformance profile\n\nAuthenticate all 94 original sources and seven helpers, retain all 188\nmode cases, and require 90 verified host controls before baseline recording.\nRecord 170 passes, 10 final-unhandled host failures and 8 unsupported class\nmodes without changing Rust, runtime limits or the existing host policy.\n\nValidate 556 Python tests and exact replay of the new profile plus all\n654 existing Promise case records and 164 harness records. Add the CI\ngate, source and observation evidence, and explicit compatibility limits.\n')
subprocess.run(['git','-C',str(W),'commit','-F',str(message)],check=True)
commit=git(W,'rev-parse','HEAD')
assert not git(W,'status','--porcelain')
subprocess.run(['git','-C',str(MAIN),'merge','--ff-only',commit],check=True)
subprocess.run(['git','-C',str(MAIN),'push','origin','main'],check=True)
assert git(MAIN,'rev-parse','HEAD')==commit and not git(MAIN,'status','--porcelain')
(A/'root/github-publication.json').write_text(json.dumps(dict(commit=commit,
    remote='https://github.com/Eriskii/ErisBrowser',push='success',ci_status='pending',
    note='Postpublication state intentionally outside the immutable evidence archive.'),indent=2)+'\n')
print('Published '+commit)
