import hashlib,json,sys
from pathlib import Path
sys.dont_write_bytecode=True
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'controls-2';sys.path.insert(0,str(W/'tools'))
import test262_conformance as runner

def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=json.loads((H/'source-ready.json').read_bytes())
for row in r['files']:
 p=H/row['path'];assert bind(p)==dict(row,path=str(p))
peer=json.loads((H/'html-review.json').read_bytes());assert peer['status']=='clear'
base=json.loads((A/'parent-source.json').read_bytes())
for p,h in base['source_sha256'].items():assert bind(W/p)['sha256']==h,p
binary=json.loads((A/'parent-binary.json').read_bytes());assert bind(Path(binary['path']))=={k:binary[k] for k in ['path','bytes','sha256']}
files={'harness/'+p.name:p.read_bytes() for p in (A/'corpus-fetch-1/data/harness').iterdir() if p.is_file()}
common=runner.promise_harness_preflight(files,Path(binary['path']),3.0);assert len(common)==74 and runner.promise_preflight_healthy(common)
variants=json.loads((H/'variants.json').read_bytes())['variants'];prospective=json.loads((H/'observations.json').read_bytes())['cases'];by_expected={(r['name'],r['mode']):r for r in prospective};out=[]
for mode in ['sloppy','strict']:
 for row in variants:
  name='promise-race-'+row['name'];e=by_expected[name,mode];identity=e['identity'];policy=row['completion_policy'];names=['assert.js','sta.js']+(['doneprintHandle.js'] if policy else [])+row['includes']
  case=dict(id='harness-preflight:'+name,file='<preflight>',mode=mode,metadata=dict(flags=['async'] if policy else [],includes=row['includes'],features=[],locale=[],negative=None),source=row['source'].encode(),harness=[(n,files['harness/'+n]) for n in names],completion_policy=policy)
  case['case_sha256']=runner.case_fingerprint(case);assert case['case_sha256']==e['case_sha256'];assert runner.digest(case['source'])==identity['source_sha256']
  result=runner.run_case(case,Path(binary['path']),3.0,runner.PROMISE_ALL_FEATURES,runner.PROMISE_ALL_PROFILE)
  verified=runner.promise_preflight_verified(case,result,row['expected'])
  out.append(dict(name=name,expected=row['expected'],verified=verified,result=result))
report=dict(status='pass' if all(x['verified'] for x in out) else 'failed_control',scope='Preproduction control execution through unchanged parent run_case/verifier and existing Promise.all host-profile policy, which equals the selected race feature/completion policy. This is not execution of the prospective race preflight gate or any upstream race case.',base=base['base'],binary=binary,source=bind(A/'parent-source.json'),controls=bind(H/'source-ready.json'),peer=bind(H/'html-review.json'),common=common,new_controls=out)
(A/'controls-parent-report.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(status=report['status'],common_verified=sum(x['verified'] for x in common),new_verified=sum(x['verified'] for x in out))));assert report['status']=='pass'
