import ast
import difflib
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'production-importer-1'
relative = 'tools/import_test262.py'
before = (W / relative).read_text()
assert hashlib.sha256(before.encode()).hexdigest() == '46d6a69f91c6baf8edb7cd98fd7a62d911aefe82d6b281196b2572ec89ee2b87'
after = before
edits = []

def replace(old, new):
    global after
    assert after.count(old) == 1, old
    after = after.replace(old, new)
    edits.append((old, new))

replace("TREE_PROFILES = {'promise-all',", "PROMISE_RACE_DIRECTORIES = {'Promise/race': 94}\nPROMISE_RACE_HELPERS = {'assert.js', 'sta.js', 'doneprintHandle.js', 'compareArray.js',\n                        'isConstructor.js', 'promiseHelper.js', 'propertyHelper.js'}\nTREE_PROFILES = {'promise-race', 'promise-all',")
replace("PROFILES = {'promise-all':", "PROFILES = {'promise-race': PROMISE_RACE_DIRECTORIES, 'promise-all':")
replace("PROFILE_ROOTS = {'promise-all':", "PROFILE_ROOTS = {'promise-race': 'test/built-ins', 'promise-all':")
replace("def profile_tree_inventory(profile, read=None):\n", """def profile_tree_inventory(profile, read=None):
    if profile == 'promise-race':
        if (PROFILES[profile] != PROMISE_RACE_DIRECTORIES
                or PROFILE_ROOTS[profile] != 'test/built-ins'):
            raise ValueError('Promise.race frozen directory selection mismatch')
        listings, proof, description = git_tree_inventory(
            PROMISE_RACE_DIRECTORIES, 'test/built-ins', read,
            auxiliary_helpers=PROMISE_RACE_HELPERS)
        if any(len(listings[name]) != count for name, count in PROMISE_RACE_DIRECTORIES.items()):
            raise ValueError('Promise.race complete directory counts differ')
        return listings, proof, description
""")
replace("    if profile == 'promise-all' and harness != PROMISE_ALL_HELPERS:\n", "    if profile == 'promise-race' and harness != PROMISE_RACE_HELPERS:\n        raise ValueError('Promise.race requested harness differs from the frozen seven helpers')\n    if profile == 'promise-all' and harness != PROMISE_ALL_HELPERS:\n")
replace("    if profile in {'promise-all', 'promise-methods-async', 'typedarray-views'", "    if profile in {'promise-race', 'promise-all', 'promise-methods-async', 'typedarray-views'")
scope = 'all 94 original .js files in the complete immediate Promise/race directory; root-linked nonrecursive Git proofs and unchanged harness bytes; all original feature metadata retained; no execution or conformance claim'
replace("    scope = {\n", "    scope = {\n        'promise-race': " + repr(scope) + ",\n")
inverse = after
for old, new in reversed(edits):
    assert inverse.count(new) == 1
    inverse = inverse.replace(new, old)
assert inverse == before
assert ast.dump(ast.parse(inverse)) == ast.dump(ast.parse(before))
ast.parse(after)

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

for sub, data in [('before', before), ('raw', after)]:
    p = H / sub / relative
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(data)
diff = H / 'importer.patch'
diff.write_text(''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True), 'a/' + relative, 'b/' + relative)))
record = dict(status='sealed_source_only_no_project_execution', base='4819802e878be7a88f90fb1a214f89f81fb87b98',
              paths=[dict(path=relative, before=bind(H/'before'/relative), raw=bind(H/'raw'/relative), diff=bind(diff))],
              inverse=dict(byte_exact=True, ast_exact=True, replacements=len(edits)),
              scope=scope, helpers=7, sources=94,
              source_contract=bind(A/'tests-before-1/source-ready.json'),
              corpus=bind(A/'corpus-1/source-ready.json'))
(H / 'source-ready.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(bind(H/'source-ready.json')))
