import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'corpus-1'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=json.loads((H/'source-ready.json').read_bytes());peer=A/'corpus-fetch-1/html-review.json';assert 'clear' in json.loads(peer.read_bytes())['status'];s=json.loads((A/'parent-source.json').read_bytes())
for p,h in s['source_sha256'].items():assert bind(W/p)['sha256']==h,p
for relative,binding in r['files'].items():
 p=Path(binding['path']);assert bind(p)==binding;out=W/relative;assert not out.exists();out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes());s['source_sha256'][relative]=binding['sha256']
assert len(s['source_sha256'])==1358
s['source_sha256']=dict(sorted(s['source_sha256'].items()));s['scope']='Published AW plus independently authenticated complete race corpus only; importer/runner absent.'
(A/'source-parent-corpus.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/corpus-import.json').write_text(json.dumps(dict(status='verified_import',hold=bind(H/'source-ready.json'),peer=bind(peer),source=bind(A/'source-parent-corpus.json')),indent=2)+'\n')
print('Imported111 corpus files; no code changes.')
