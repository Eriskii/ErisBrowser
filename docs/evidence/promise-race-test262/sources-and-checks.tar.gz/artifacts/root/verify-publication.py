import hashlib
import json
import re
import subprocess
import tarfile
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A/'worktree'

def digest(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def read(name):
    return json.loads((A/name).read_bytes())

final = read('source-final.json')['source_sha256']
parent = read('parent-source.json')['source_sha256']
changed = sorted(p for p,h in final.items() if parent.get(p) != h)
for p,h in final.items():
    assert digest(W/p) == h, p
docs = [r['relative'] for r in read('documentation-1/source-ready.json')['files']]
for r in read('documentation-1/source-ready.json')['files']:
    assert digest(W/r['relative']) == r['raw']['sha256']
    # Check only new chapter links, avoiding unrelated historical anchors.
    if r['relative'] == 'docs/promise-race-test262.md':
        for link in re.findall(r'\]\(([^)]+)\)', (W/r['relative']).read_text()):
            if '://' not in link:
                assert ((W/r['relative']).parent/link.split('#')[0]).exists(), link
evidence = ['docs/evidence/promise-race-test262/summary.json',
            'docs/evidence/promise-race-test262/sources-and-checks.tar.gz']
summary = json.loads((W/evidence[0]).read_bytes())
assert digest(W/evidence[1]) == summary['archive']['sha256']
with tarfile.open(W/evidence[1],'r:gz') as archive:
    assert archive.getnames() == [r['path'] for r in summary['members']]
    for r in summary['members']:
        m=archive.getmember(r['path']);assert m.isfile()
        data=archive.extractfile(m).read();assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
        assert digest(Path(r['origin'])) == r['sha256'], r['origin']
expected = sorted(changed+docs+evidence)
assert len(expected) == len(set(expected)) == 139
def git(*args):
    return subprocess.check_output(['git','-C',str(W),*args],text=True).strip()
actual = set(git('diff','--name-only').splitlines()) | set(git('ls-files','--others','--exclude-standard').splitlines())
assert actual == set(expected), actual^set(expected)
assert git('rev-parse','HEAD') == '4819802e878be7a88f90fb1a214f89f81fb87b98'
subprocess.run(['git','-C',str(W),'diff','--check'],check=True)
record = dict(status='verified', expected_commit_paths=expected,
    source_count=1361, changed_sources=132, documentation=5, evidence_files=2,
    archive_sha256=summary['archive']['sha256'], archive_members=len(summary['members']),
    source_sha256=digest(A/'source-final.json'), validation_sha256=digest(A/'root/final-validation.json'),
    full_python_passed=556, race=dict(passed=170,failed=10,unsupported=8,controls=90),
    old_case_records_exact=654, old_control_records_exact=164,
    rust_source_changes=0, full_web_compatibility=False)
(A/'root/publication-verification.json').write_text(json.dumps(record,indent=2)+'\n')
print('Verified139 exact publication paths, archive members, source state and relative links.')
