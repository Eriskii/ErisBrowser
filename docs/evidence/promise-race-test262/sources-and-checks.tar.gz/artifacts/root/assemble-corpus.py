import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];F=A/'corpus-fetch-1';H=A/'corpus-1';OUT=H/'raw/tests/upstream/test262-promise-race';OUT.mkdir(parents=True,exist_ok=False)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
r=json.loads((F/'receipt.json').read_bytes());scope='all 94 original .js files in the complete immediate Promise/race directory; root-linked nonrecursive Git proofs and unchanged harness bytes; all original feature metadata retained; no execution or conformance claim'
paths=sorted(r['metadata']);manifest=dict(format=1,repository='https://github.com/tc39/test262',revision=r['revision'],scope=scope,directories={'Promise/race':[Path(p).name for p in paths]},test_files=94,files=[])
manifest['inventory_proof']=dict(r['proof_description'],files=[])
for row in sorted(r['proof'],key=lambda x:x['path']):
 p=Path(row['path']);assert bind(p)==row;relative=p.relative_to(F).as_posix();data=p.read_bytes();target=OUT/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 route='commits/'+r['revision'] if p.name=='commit.json' else 'trees/'+p.stem.removeprefix('tree-')
 manifest['inventory_proof']['files'].append(dict(path=relative,bytes=len(data),sha256=row['sha256'],url='https://api.github.com/repos/tc39/test262/git/'+route))
for row in sorted(r['files'],key=lambda x:x['relative']):
 p=Path(row['binding']['path']);assert bind(p)==row['binding'];data=p.read_bytes();relative=row['relative'];assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==row['git_blob'];target=OUT/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
 manifest['files'].append(dict(path=relative,upstream_path=relative,bytes=len(data),sha256=row['binding']['sha256']))
assert len(manifest['files'])==103 and len(manifest['inventory_proof']['files'])==7
(OUT/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
files={str(p.relative_to(H/'raw')):bind(p) for p in sorted(OUT.rglob('*')) if p.is_file()};assert len(files)==111
(H/'source-ready.json').write_text(json.dumps(dict(status='frozen_authenticated_corpus_before_profile_production',base='4819802e878be7a88f90fb1a214f89f81fb87b98',fetch=bind(F/'receipt.json'),manifest=bind(OUT/'manifest.json'),scope_literal=scope,files=files,source_count=94,mode_count=188,notes='Independent manifest assembly uses existing schema and exact fetched bytes; no candidate importer, engine execution or observed pass totals.'),indent=2)+'\n');print(json.dumps(dict(files=111,manifest=bind(OUT/'manifest.json'))))
