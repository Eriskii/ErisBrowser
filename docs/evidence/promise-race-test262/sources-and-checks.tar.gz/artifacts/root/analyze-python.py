import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def passing(label, expected):
    receipt = A / 'validation' / (label + '.json')
    log = receipt.with_suffix('.log')
    r = json.loads(receipt.read_bytes())
    assert r['exit'] == 0 and r['sha256'] == bind(log)['sha256']
    data = log.read_text()
    assert '\nOK\n' in data and f'Ran {expected} tests in ' in data
    names = re.findall(r'^test_\w+ \(([^)]+)\) \.\.\. ok$', data, re.M)
    assert len(names) == len(set(names)) == expected
    return dict(receipt=bind(receipt), log=bind(log), names=sorted(names), passed=expected)

focused = passing('candidate-profile-1', 13)
full = passing('candidate-python-1', 556)
old = json.loads((A / 'root/parent-python-baseline.json').read_bytes())
assert set(full['names']) == set(old['names']) | set(focused['names'])
assert not set(old['names']) & set(focused['names'])
assert all('promise_race_profile.' in name for name in focused['names'])
source = A / 'source-candidate-ci.json'
for path, sha in json.loads(source.read_bytes())['source_sha256'].items():
    assert bind(A / 'worktree' / path)['sha256'] == sha, path
result = dict(status='pass', source=bind(source), focused=focused, full=full,
              parent_roster=bind(A/'root/parent-python-baseline.json'),
              old_names_unchanged=543, new_names=13,
              expectation_corrections_after_parent_baseline=0)
(A / 'root/python-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print('556 passed: exact543 parent names plus13 frozen new groups; no skipped/renamed tests.')
