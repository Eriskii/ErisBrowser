import hashlib
import json
from collections import Counter
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

def read(name):
    return json.loads((A / name).read_bytes())

binary = read('parent-binary.json')
assert bind(A/'eris-js-parent') == {k: binary[k] for k in ('path', 'bytes', 'sha256')}
first = read('race-first-report.json')
assert first['counts'] == dict(passed=170, failed=10, unsupported=8)
assert first['source_files'] == first['source_tests'] == 94
assert first['mode_cases'] == 188 and not first['full_test262_conformance']
assert first['harness_preflight_passed'] and len(first['harness_preflight']) == 90
assert all(r['verified'] is True for r in first['harness_preflight'])
oracle = read('tests-before-1/raw/tools/promise-race-profile-oracle.json')
assert [(r['id'], r['case_sha256']) for r in first['cases']] == [(r['id'], r['case_sha256']) for r in oracle['case_identities']]
assert (first['runner_policy'], first['runner_policy_sha256']) == (oracle['policy'], oracle['policy_sha256'])
controls = read('controls-parent-report.json')
assert first['harness_preflight'][:74] == controls['common']
for before, after in zip(controls['new_controls'], first['harness_preflight'][74:]):
    assert all(after[k] == v for k, v in before.items())
comparisons = []
for parent, final, label, cases, controls_count in [
    ('race-first-report.json', 'race-replay-report.json', 'race-replay-1', 188, 90),
    ('replay-parent/promise-all-report.json', 'all-replay-report.json', 'all-replay-1', 196, 90),
    ('replay-parent/promise-existing-report.json', 'existing-replay-report.json', 'existing-replay-1', 458, 74),
]:
    old, new = read(parent), read(final)
    for key in ('cases', 'harness_preflight', 'counts', 'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256', 'binary_sha256'):
        assert old[key] == new[key], (label, key)
    assert len(new['cases']) == cases and len(new['harness_preflight']) == controls_count
    assert new['binary_sha256'] == binary['sha256']
    assert new['regressions'] == new['improvements'] == []
    receipt = read('validation/' + label + '.json')
    assert receipt['exit'] == 0 and receipt['sha256'] == bind(A/'validation'/receipt['log'])['sha256']
    comparisons.append(dict(parent=bind(A/parent), replay=bind(A/final), receipt=bind(A/'validation'/(label+'.json')),
                            log=bind(A/'validation'/receipt['log']), exact_cases=cases, exact_controls=controls_count,
                            counts=new['counts'], regressions=0, improvements=0))
failures = [r for r in first['cases'] if r['status'] == 'failed']
assert all(r['observation']['status'] == 'host-failure' and r['observation']['message'] == 'unhandled-rejection'
           and r['observation']['completion'] == dict(policy=0, done_calls=0, success_prints=0, failure_prints=0,
                flags=0, quiescent=True, audited=True, unhandled=1) for r in failures)
excluded = [r for r in first['cases'] if r['status'] == 'unsupported']
assert Counter('metadata' if 'reason' in r else 'parser' for r in excluded) == {'metadata': 4, 'parser': 4}
baseline = read('race-first-baseline.json')
for key in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256', 'binary_sha256'):
    assert baseline[key] == first[key]
assert baseline['cases'] == {r['id']: {k:r[k] for k in ('status','case_sha256','source_sha256')} for r in first['cases']}
source = read('source-candidate-ci.json')
for path, sha in source['source_sha256'].items():
    assert bind(W/path)['sha256'] == sha, path
destination = W/'tests/conformance/test262-promise-race-current.json'
assert not destination.exists()
destination.write_bytes((A/'race-first-baseline.json').read_bytes())
source['source_sha256']['tests/conformance/test262-promise-race-current.json'] = bind(destination)['sha256']
source['source_sha256'] = dict(sorted(source['source_sha256'].items()))
assert len(source['source_sha256']) == 1361
(A/'source-final.json').write_text(json.dumps(source,indent=2)+'\n')
record = dict(status='pass', first=bind(A/'race-first-report.json'), first_receipt=bind(A/'validation/race-profile-first-1.json'),
              first_baseline=bind(A/'race-first-baseline.json'), installed_baseline=bind(destination),
              binary=binary, source=bind(A/'source-final.json'), comparisons=comparisons,
              counts=first['counts'], controls=90, old_cases_unchanged=654, old_controls_unchanged=164,
              host_failure_sources=sorted({r['file'] for r in failures}),
              unsupported_sources=sorted({r['file'] for r in excluded}),
              control_parent_observations_exact=True, engine_or_host_policy_changes=False,
              full_test262_conformance=False)
(A/'root/replay-validation.json').write_text(json.dumps(record,indent=2)+'\n')
print('Race188/90 exact replay; old654/164 records exact; healthy baseline imported; build source1361.')
