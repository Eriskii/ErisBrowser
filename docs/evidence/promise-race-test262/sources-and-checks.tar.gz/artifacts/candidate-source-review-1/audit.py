#!/usr/bin/env python3
"""Independent source composition audit; only stdlib and read-only Git commands."""
from pathlib import Path
import ast
import hashlib
import json
import subprocess
ROOT=Path('/tmp/eris-promise-race-upstream-1');WORK=ROOT/'worktree';OUT=ROOT/'candidate-source-review-1'
BASE='4819802e878be7a88f90fb1a214f89f81fb87b98'
def sha(b):return hashlib.sha256(b).hexdigest()
def bind(p):
 p=Path(p);assert p.is_file() and not p.is_symlink();b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def load(p):return json.loads(Path(p).read_text())
def check(b):assert bind(b['path'])==b,b
parent=load(ROOT/'parent-source.json');candidate=load(ROOT/'source-candidate-ci.json');old=parent['source_sha256'];new=candidate['source_sha256']
assert parent['base']==candidate['base']==BASE
assert len(old)==1247 and len(new)==1360 and old.keys()<=new.keys()
for rel,value in new.items():assert bind(WORK/rel)['sha256']==value,rel
changed={p for p in old if old[p]!=new[p]};added=set(new)-set(old)
assert len(changed)==18 and len(added)==113
expected_changed={};expected_added={};holds=[]
for hold_path in ['production-importer-1/source-ready.json','production-runner-1/source-ready.json','adapters-1/source-ready.json','ci-1/source-ready.json']:
 hold=load(ROOT/hold_path);holds.append(bind(ROOT/hold_path))
 for entry in hold.get('paths',hold.get('files',[])):
  rel=entry.get('relative',entry.get('path'))
  for key in ['before','raw','diff','diffs']:
   if key in entry:check(entry[key])
  assert old[rel]==entry['before']['sha256'] and new[rel]==entry['raw']['sha256']
  assert (WORK/rel).read_bytes()==Path(entry['raw']['path']).read_bytes()
  assert rel not in expected_changed
  expected_changed[rel]=dict(before=entry['before']['sha256'],after=entry['raw']['sha256'],hold=hold_path)
  if hold_path.startswith('adapters'):
   raw=Path(entry['raw']['path']).read_text();before=Path(entry['before']['path']).read_text()
   assert raw.count(", 'promise-race'")==entry['added_exclusions']
   assert raw.replace(", 'promise-race'",'')==before
assert sum(x['added_exclusions'] for x in load(ROOT/'adapters-1/source-ready.json')['files'])==17
for entry in load(ROOT/'tests-before-1/source-ready.json')['paths']:
 rel=entry['path'];check(entry['raw']);assert new[rel]==entry['raw']['sha256'] and rel not in old
 expected_added[rel]=dict(sha256=new[rel],hold='tests-before-1/source-ready.json')
corpus_hold=load(ROOT/'corpus-1/source-ready.json')
for rel,b in corpus_hold['files'].items():
 check(b);assert new[rel]==b['sha256'] and rel not in old
 assert (WORK/rel).read_bytes()==Path(b['path']).read_bytes()
 expected_added[rel]=dict(sha256=new[rel],hold='corpus-1/source-ready.json')
assert set(expected_changed)==changed and set(expected_added)==added
corpus_root=WORK/'tests/upstream/test262-promise-race'
assert {str(p.relative_to(WORK)) for p in corpus_root.rglob('*') if p.is_file()}==set(corpus_hold['files'])
assert all(not p.is_symlink() for p in corpus_root.rglob('*'))
assert len(corpus_hold['files'])==111
# Bound previous peers and import receipts, with their embedded bindings intact.
receipts=['root/corpus-import.json','root/tests-import.json','root/production-import.json','root/ci-import.json','production-importer-1/html-review.json','runner-script-review-1/source-review.json','adapters-1/layout-review.json','tests-before-1/html-review.json','controls-2/html-review.json','corpus-fetch-1/html-review.json']
for rel in receipts:assert (ROOT/rel).is_file()
for row in load(ROOT/'root/production-import.json')['holds']:
 check(row['hold']);check(row['peer'])
# Independently check all tracked Rust/Cargo/build-config and old corpus,
# conformance JSON and oracle blobs, including items omitted from the snapshot.
records=subprocess.check_output(['git','ls-tree','-r','-z',BASE],cwd=WORK).split(b'\0')
selected={};categories={k:[] for k in ['rust','cargo','build_configuration','old_upstream_corpus','conformance_json','oracle']}
for rec in records:
 if not rec:continue
 meta,path=rec.split(b'\t',1);mode,kind,oid=meta.decode().split();rel=path.decode();p=Path(rel)
 cats=[]
 if rel.endswith('.rs'):cats.append('rust')
 if p.name in ['Cargo.toml','Cargo.lock']:cats.append('cargo')
 if rel.startswith('.cargo/') or p.name in ['build.rs','rust-toolchain.toml','rust-toolchain'] or p.suffix in ['.wgsl','.glsl','.vert','.frag','.comp']:cats.append('build_configuration')
 if rel.startswith('tests/upstream/'):cats.append('old_upstream_corpus')
 if rel.startswith('tests/conformance/') and rel.endswith('.json'):cats.append('conformance_json')
 if 'oracle' in p.name and rel.endswith('.json'):cats.append('oracle')
 if not cats:continue
 assert kind=='blob' and mode in ['100644','100755'],rel
 f=WORK/rel;assert not f.is_symlink();data=f.read_bytes()
 actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert actual==oid,rel
 selected[rel]=dict(git_blob=oid,bytes=len(data),sha256=sha(data))
 for cat in cats:categories[cat].append(rel)
# Final source adds only the independently observed baseline while this audit
# proceeds; keep its attribution separate from the candidate execution source.
final=load(ROOT/'source-final.json');final_map=final['source_sha256']
baseline_rel='tests/conformance/test262-promise-race-current.json'
assert len(final_map)==1361 and set(final_map)-set(new)=={baseline_rel}
assert all(final_map[k]==v for k,v in new.items())
assert bind(WORK/baseline_rel)['sha256']==final_map[baseline_rel]
replay=load(ROOT/'root/replay-validation.json')
for key in ['first_baseline','installed_baseline','source']:check(replay[key])
assert Path(replay['first_baseline']['path']).read_bytes()==(WORK/baseline_rel).read_bytes()
# Read-only full worktree change inventory rules out unselected tracked/untracked
# source changes, even outside the 1,360-input candidate snapshot plus baseline.
dirty=subprocess.check_output(['git','ls-files','-d','-m','-o','--exclude-standard','-z'],cwd=WORK).decode().split('\0')
assert {x for x in dirty if x}==changed|added|{baseline_rel}
tracked=subprocess.check_output(['git','diff','--name-status',BASE],cwd=WORK).decode().splitlines()
assert {line[2:] for line in tracked}==changed and all(line.startswith('M\t') for line in tracked)
# Literal data tables and producer bodies, without project evaluation.
def constants(text):
 tree=ast.parse(text);assign={t.id:n.value for n in tree.body if isinstance(n,ast.Assign) for t in n.targets if isinstance(t,ast.Name)}
 def lit(n):
  if isinstance(n,ast.Constant):return n.value
  if isinstance(n,ast.Name):return lit(assign[n.id])
  if isinstance(n,ast.Dict):return {lit(k):lit(v) for k,v in zip(n.keys,n.values)}
  if isinstance(n,ast.Set):return {lit(v) for v in n.elts}
  if isinstance(n,ast.List):return [lit(v) for v in n.elts]
  if isinstance(n,ast.Tuple):return tuple(lit(v) for v in n.elts)
  raise AssertionError(type(n).__name__)
 return {key:lit(assign[key]) for key in ['PROFILES','PROFILE_ROOTS','TREE_PROFILES']}
tables=constants((WORK/'tools/import_test262.py').read_text())
assert tables['PROFILES'].pop('promise-race')=={'Promise/race':94};assert tables['PROFILE_ROOTS'].pop('promise-race')=='test/built-ins';tables['TREE_PROFILES'].remove('promise-race')
assert tables==constants((ROOT/'production-importer-1/before/tools/import_test262.py').read_text())
runner=(WORK/'tools/test262_conformance.py').read_text();prior=(ROOT/'production-runner-1/before/tools/test262_conformance.py').read_text()
funcs={n.name:n for n in ast.parse(runner).body if isinstance(n,ast.FunctionDef)};oldfuncs={n.name:n for n in ast.parse(prior).body if isinstance(n,ast.FunctionDef)}
for name in ['parse_metadata','modes','harness_names','case_fingerprint','encode_request','decode_response','classify','run_case','promise_preflight_variants','promise_harness_preflight','promise_all_preflight_variants','promise_all_harness_preflight','promise_host_reason','promise_preflight_verified']:
 if name in oldfuncs:assert ast.get_source_segment(runner,funcs[name])==ast.get_source_segment(prior,oldfuncs[name]),name
variants=ast.literal_eval(next(n.value for n in funcs['promise_race_preflight_variants'].body if isinstance(n,ast.Return)))
assert variants==load(ROOT/'controls-2/variants.json')['variants']
ci=load(ROOT/'ci-1/inverse.json');step=ci['removed_step']
assert (WORK/'.github/workflows/check.yml').read_text().replace(step,'',1)==(ROOT/'ci-1/before/.github/workflows/check.yml').read_text()
checks=dict(status='clear_source_composition',base=BASE,parent_inputs=1247,candidate_inputs=1360,dropped=0,unchanged_parent_inputs=1229,changed_parent_inputs=18,new_inputs=113,changed=expected_changed,added=expected_added,corpus_files=111,candidate_change_roster=131,current_git_change_roster=132,final_source_inputs=1361,final_addition=baseline_rel,supplemental_git_blob_counts={k:len(v) for k,v in categories.items()},unique_supplemental_git_blobs=len(selected),supplemental_git_blob_bytes=sum(r['bytes'] for r in selected.values()),supplemental_inventory_sha256=sha(json.dumps(selected,sort_keys=True,separators=(',',':')).encode()),rust_outside_parent_snapshot=len(set(categories['rust'])-set(old)),cargo_outside_parent_snapshot=len(set(categories['cargo'])-set(old)),old_profile_tables=55,legacy_adapter_files=15,legacy_exclusion_additions=17)
(OUT/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
review=dict(status='clear',scope='Live source-candidate-ci composition against parent and exact imported holds; no candidate execution by this peer.',source=bind(ROOT/'source-candidate-ci.json'),parent=bind(ROOT/'parent-source.json'),final_source=bind(ROOT/'source-final.json'),baseline=bind(WORK/baseline_rel),baseline_receipt=bind(ROOT/'root/replay-validation.json'),checks=bind(OUT/'checks.json'),audit=bind(Path(__file__)),holds=holds+[bind(ROOT/'corpus-1/source-ready.json'),bind(ROOT/'tests-before-1/source-ready.json')],receipts=[bind(ROOT/rel) for rel in receipts],findings=[],conclusions=[
'All 1,360 candidate snapshot file hashes independently checked against live bytes. All 1,247 old entries retained: 1,229 unchanged and 18 intentionally changed. Exactly 113 candidate additions are corpus111 plus the two frozen profile test/oracle files.',
'The 18 modified paths are exactly importer1, runner1, historical tests15 and CI1. Every live raw file joins its sealed hold byte-for-byte; all before bindings join the parent. No formatting or expectation corrections are present. Full read-only Git dirty roster is exactly those 131 changed/new paths plus the final baseline.',
'All tracked Rust, Cargo/build configuration, old upstream corpora, conformance JSON and JSON oracles checked directly against parent Git blob IDs, including files outside the source snapshot. Supplemental counts and hash inventory are recorded in checks.json. No old corpus, baseline or oracle changed.',
'New corpus retains all111 frozen bytes and exact on-disk inventory. The importer old55 tables are unchanged after removal of the added race entry. Existing Promise control producers, transport, fingerprints, classifier and host verifier functions remain byte-identical; new eight control source literals equal controls2.',
'The15 historical adapters reverse exactly by removal of their17 explicit promise-race exclusion entries. Counts, hashes, existing test assertions and old profile scope are preserved.',
'CI adds only the selected two-line Promise.race regression step adjacent to Promise.all; exact removal recovers the complete old workflow. It uses the existing test262-host build/matrix without changing old jobs.',
'Additive source-final.json contains 1,361 inputs: its sole difference from the reviewed candidate snapshot is tests/conformance/test262-promise-race-current.json. That file is byte-identical to the bound race-first-baseline.json (a583bd92…). No candidate execution is attributed to the later baseline addition.'
],limitations=['Source and hold review only; no project module import, tests, compiler, runner, JS, browser or network execution. Read-only Git and stdlib hashing/AST inspection were used.','The final baseline addition is verified as an exact source composition/copy only. Full outcome and replay validation remains a separate review; this receipt does not imply all upstream cases passed.','Root-reported13 candidate groups passing, full Python and later188-case execution are separate result evidence; no result claims are inferred from source composition.'])
(OUT/'source-review.json').write_text(json.dumps(review,indent=2)+'\n')
print(json.dumps(dict(review=bind(OUT/'source-review.json'),counts=checks['supplemental_git_blob_counts'],unique=checks['unique_supplemental_git_blobs'],bytes=checks['supplemental_git_blob_bytes']),indent=2))
