from pathlib import Path
import difflib
import hashlib
import json
import re
import shutil

D=Path('/tmp/eris-promise-try-runtime-plan-1')
H=D/'documentation-1'

def bind(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

assert not (H/'content-ready.json').exists()
bindings=[]
receipts=[]
for p in sorted((D/'validation').glob('*.json')):
    row=json.loads(p.read_bytes())
    log=D/'validation'/row['log']
    assert bind(log)['sha256']==row['sha256'],p
    assert row['exit']==(101 if p.name=='try-parent-public-1.json' else 0),p
    receipts.append({'receipt':bind(p),'log':bind(log),'exit':row['exit']})
assert len(receipts)==17
full=[]
for name,count in [('default-full-1',3246),('host-vulkan-full-1',3600)]:
    p=D/'validation'/f'{name}.log'
    rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',p.read_text())
    assert len(rows)==52,(name,len(rows))
    totals=[sum(int(r[i]) for r in rows) for i in range(5)]
    assert totals==[count,0,0,0,0],(name,totals)
    full.append({'name':name,'result_rows':len(rows),'totals':totals})
profiles=[]
for name in ['aggregate-error','existing','all','race','settled','any','with-resolvers']:
    p=D/f'upstream-{name}-1.json'
    q=D/'replay-parent'/p.name
    current=json.loads(p.read_bytes());parent=json.loads(q.read_bytes())
    for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','mode_cases']:
        assert current[key]==parent[key],(name,key)
    assert current['harness_preflight_passed'] is True
    assert all(x['verified'] is True for x in current['harness_preflight'])
    assert current['regressions']==[] and current['improvements']==[]
    profile_binary='ordinary' if name in ['aggregate-error','with-resolvers'] else 'host'
    identity=json.loads((D/f'eris-js-{profile_binary}-1.json').read_bytes())
    assert current['binary_sha256']==identity['sha256']
    profiles.append({'name':name,'cases':len(current['cases']),'controls':len(current['harness_preflight']),
                     'report':bind(p),'parent':bind(q),'complete_arrays_policy_corpus_exact':True})
assert sum(x['cases'] for x in profiles)==1300
assert sum(x['controls'] for x in profiles)==546
for label in ['ordinary','host']:
    p=D/f'eris-js-{label}-1.json';r=json.loads(p.read_bytes())
    assert bind(Path(r['binary']))['sha256']==r['sha256']
    assert Path(r['binary']).stat().st_size==r['bytes']
    assert bind(Path(r['source_inventory']))['sha256']==r['source_sha256']
    bindings.append(bind(p))
candidate=json.loads((D/'source-candidate-1.json').read_bytes())
final=json.loads((D/'source-final.json').read_bytes())
assert candidate['base']==final['base']
assert candidate['source_sha256']==final['source_sha256']
assert len(final['source_sha256'])==1778
assert set(k for k in final if final[k]!=candidate[k])=={'scope'}
for p in ['root/rust-validation.json','root/profile-validation.json','root/source-scope-qualification.json',
          'root/format-check-orchestration.json','source-final.json']:
    bindings.append(bind(D/p))
full_prose='''Complete `--include-ignored` runs pass **3,246 Rust 1.88 default tests** and
**3,600 Rust 1.99 tests with `test262-host,vulkan-raster`**. Each has 52 result
rows and no failed, ignored or filtered tests. The full parent rosters survive
four selected boundary renames and gain the 25 new groups. Strict all-target
Clippy passes in both configurations, and formatting passes.'''
replay_prose='''Rebuilt Rust 1.88 ordinary and host adapters preserve all **1,300 case records
and 546 control records** across the seven existing upstream profiles. Complete
arrays, policies and corpus identities match the parent, including existing
failed and unsupported outcomes; no baseline changes are made. Python tooling,
host protocols and CI gates are unchanged, and no full Python-suite rerun is
claimed.'''
qualification='''The first source-inventory comparison was interrupted before writing its output
because the lexical matcher was slow; its replacement avoids redundant matching.
The final inventory also corrects inherited descriptive scope text while keeping
the same base and all 1,778 source hashes. Both bookkeeping corrections are
retained; neither changes candidate source, tests, expectations or outcomes.'''
for rel in ['docs/promise-try.md','docs/VALIDATION.md']:
    p=H/'raw'/rel
    initial=H/'initial-draft/raw'/rel
    initial.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(p,initial)
    text=p.read_text()
    assert text.count('PENDING_FULL_AND_STRICT')==1
    assert text.count('PENDING_RELEASE_AND_REPLAYS')==1
    text=text.replace('PENDING_FULL_AND_STRICT',full_prose)
    text=text.replace('PENDING_RELEASE_AND_REPLAYS',replay_prose+'\n\n'+qualification)
    assert 'PENDING_' not in text
    p.write_text(text)
    diffpath=H/'diffs'/(rel.replace('/','__')+'.diff')
    olddiff=H/'initial-draft/diffs'/diffpath.name
    olddiff.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(diffpath,olddiff)
    old=(H/'before'/rel).read_text() if (H/'before'/rel).exists() else ''
    diffpath.write_text(''.join(difflib.unified_diff(old.splitlines(True),text.splitlines(True),
             fromfile=rel if old else '/dev/null',tofile=rel)))
old_validation=(H/'before/docs/VALIDATION.md').read_bytes()
assert (H/'raw/docs/VALIDATION.md').read_bytes().endswith(old_validation[len(b'# Validation record\n\n'):])
assert (D/'worktree/docs/promise-with-resolvers.md').read_bytes()==(H/'parent/docs/promise-with-resolvers.md').read_bytes()
files=[]
for p in sorted((H/'raw').rglob('*.md')):
    rel=str(p.relative_to(H/'raw'))
    files.append({'relative_path':rel,'raw':bind(p),'before':bind(H/'before'/rel) if (H/'before'/rel).exists() else None,
                  'diff':bind(H/'diffs'/(rel.replace('/','__')+'.diff'))})
record={'status':'content complete; final ledger/source peer binding still pending; not an import seal',
        'files':files,'receipts':receipts,'full_raw_counts':full,'profiles':profiles,'bindings':bindings,
        'history':'Prior VALIDATION suffix and withResolvers chapter remain byte-exact.',
        'initial_draft':'Two replaced raw/diff payloads are retained under initial-draft; draft-status is historical.',
        'limitations':'Static stdlib evidence readback only; no project execution or live edits.'}
(H/'content-ready.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'content_ready':bind(H/'content-ready.json'),'chapter_words':len((H/'raw/docs/promise-try.md').read_text().split())}))
