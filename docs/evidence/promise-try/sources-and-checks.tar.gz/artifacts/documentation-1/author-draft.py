from pathlib import Path
import difflib
import hashlib
import json
import subprocess

D = Path('/tmp/eris-promise-try-runtime-plan-1')
W = D / 'worktree'
H = D / 'documentation-1'
BASE = '7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'

def binding(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def save(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    assert not path.exists(), path
    path.write_bytes(data if isinstance(data, bytes) else data.encode())

def before(rel):
    data = subprocess.check_output(['git', 'show', f'{BASE}:{rel}'], cwd=W)
    assert data == (W / rel).read_bytes(), rel
    save(H / 'before' / rel, data)
    return data.decode()

def insert(text, anchor, addition):
    assert text.count(anchor) == 1, anchor
    return text.replace(anchor, addition + anchor)

paths = ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
         'docs/SECURITY.md', 'docs/VALIDATION.md']
old = {rel: before(rel) for rel in paths}
new = dict(old)
new['README.md'] = insert(old['README.md'], '[`AggregateError`](docs/aggregate-error.md)', '''[`Promise.try`](docs/promise-try.md) calls the callback synchronously before
resolving its result or creating a rejection capability, following the current
ECMAScript 2027 draft. It preserves generic receiver behavior, argument identity
and existing terminal suspension. This runtime checkpoint adds no dedicated
Promise.try upstream profile.

''')
new['docs/COMPATIBILITY.md'] = insert(old['docs/COMPATIBILITY.md'], '[`AggregateError`](aggregate-error.md)', '''[`Promise.try`](promise-try.md) follows the current draft's callback-first
algorithm. Primitive receivers fail before the callback; object receivers call
it before constructor validation. Normal results use the existing abstract
PromiseResolve operation, including genuine Promise identity when its constructor
matches. Ordinary callback throws create a rejection capability; constructor,
conversion and rejection failures can still escape synchronously. Thenable jobs
and terminal resource/unsupported failures retain their existing behavior.
There is no dedicated Promise.try upstream result in this checkpoint.

''')
needle = '`Promise.any` and `Promise.withResolvers`, DOM bindings'
assert new['docs/COMPATIBILITY.md'].count(needle) == 1
new['docs/COMPATIBILITY.md'] = new['docs/COMPATIBILITY.md'].replace(
    needle, '`Promise.any`, `Promise.withResolvers` and `Promise.try`, DOM bindings')
new['docs/ROADMAP.md'] = insert(old['docs/ROADMAP.md'],
    'Older profile policies remain unchanged. Remaining asynchronous work\n', '''[`Promise.try`](promise-try.md) now implements the current draft's callback-first
operation, generic completion paths and terminal boundaries under the existing
limits. A dedicated pinned upstream profile remains subsequent work; reference
sources and readiness notes alone establish no upstream outcomes.
''')
new['docs/SECURITY.md'] = insert(old['docs/SECURITY.md'], '## Representative limits\n', '''[`Promise.try`](promise-try.md) prepays callback ownership and ordered argument
copies before invoking author code. The separate tail helper checks its bound,
work, heap and reserve admissions before cloning values. Ordinary callback
errors survive capability construction before existing error conversion;
terminal resource or unsupported-operation failures bypass rejection conversion
and retain sticky suspension through the public operation. Constructor effects
already performed are not rolled back by later refusal. Existing helper fees,
host authority, decoder policies and runtime limits remain unchanged. Logical
charges do not certify complete allocation coverage or process-memory bounds.

''')
validation = '''## Promise.try runtime

The [Promise.try checkpoint](promise-try.md) implements the current draft's
callback-first operation, including generic receiver behavior and the distinct
normal-result and ordinary-error paths. The frozen public contract has twelve
semantic groups and three terminal groups. The published parent fails all 15 at
the missing-method guard on their first sloppy source; later phases, strict
attempts and terminal readbacks are unreached. All **25 new groups pass on the
first candidate**: those 15 plus ten private groups. The completed loops cover
140 public execute calls, 78 private measured attempts and four private sticky
readbacks; these are not additional Rust test groups.

PENDING_FULL_AND_STRICT

The recorded x86_64 startup uses **101,580 work units**, leaves **898,420** and
accounts for **1,775,866 heap bytes** across 757 objects. This adds 268 work and
7,595 accounted bytes over the preceding runtime. Constructor property order
grows from length/capacity 11/11 to 12/12; the 300 native entries, 26 prototypes
and 213 globals are unchanged. The 1,000,000-unit bootstrap, 100,000-unit author
and cumulative 8 MiB heap limits are unchanged. These are logical accounting
observations, not CPU or process-memory measurements.

PENDING_RELEASE_AND_REPLAYS

The selected source inventory covers 1,778 inputs and has a separate tracked
source review; it is not a complete build-graph inventory. No Python tooling,
host protocol, profile or baseline changes are selected. There is no dedicated
Promise.try upstream outcome. Prior CI success belongs to published commit
`7149ab72`; this checkpoint makes no new remote CI claim. Evidence is linked from
the chapter. All earlier validation text below remains byte-exact.

'''
heading = '# Validation record\n\n'
assert old['docs/VALIDATION.md'].startswith(heading)
new['docs/VALIDATION.md'] = heading + validation + old['docs/VALIDATION.md'][len(heading):]
new['docs/promise-try.md'] = '''# Promise.try

`Promise.try(callback, ...args)` invokes the callback synchronously and uses its
completion to return a Promise or a generic capability result. This checkpoint
implements the callback-first algorithm in the [current ECMAScript 2027
draft](https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.try).
The method has name `try`, length one and no constructor behavior.

A primitive receiver throws TypeError before invoking the callback. An object
receiver reaches the callback before constructor validation. The callback
receives `undefined` as its supplied `this` and the remaining arguments in order;
ordinary function strictness and bound-function behavior still apply. Values
retain their identities, and no argument iterator or `length` getter is read.

On normal completion, the existing abstract PromiseResolve operation receives
the captured receiver and callback result. A genuine Promise whose observable
`constructor` equals that receiver is returned unchanged, even when the receiver
is not a constructor. Constructor-getter errors escape synchronously. Other
results use a new capability and its resolve callback; failure in either step
also escapes synchronously. The method does not read `C.resolve` or species.
Existing thenable adoption still separates synchronous getter access from
deferred jobs and reactions on the shared FIFO.

An ordinary callback throw takes a different path: create the capability,
convert the retained error through the existing exception helper, then call its
reject callback once. Explicitly thrown values preserve identity. Constructor,
conversion or reject failures take precedence and escape synchronously; they
are not retried. Terminal resource and unsupported-operation failures bypass
this ordinary rejection path. Through public execution they keep author
catch/finally work and unstarted jobs suspended across later checkpoints.

Public dispatch retains its eight-unit fee. The new body prepays 16 work units
for control and ownership, then one for the callback copy. A separate tail
helper prepays `8 + 3n` work and `32 + n * sizeof(Value)` accounted bytes before
copying `n` values. The empty tail keeps the 8-unit/32-byte logical charge. The
helper rejects lengths above 65,536 after its fixed entry fee, before element
work or storage admission. This internal bound does not enlarge the ordinary
100,000-unit work allowance. Existing Call, capability, PromiseResolve and error
materialization charges remain separate and unchanged. These tariffs are
logical accounting, not instruction counts or complete physical memory costs.

Late installation adds one metadata object after `withResolvers`, preserving
earlier IDs and helper tariffs. The private controls cover 246 work units with
spare owner order capacity and 268 when the 11-entry order must grow. The
recorded x86_64 startup takes the latter branch: order length/capacity moves from
11/11 to 12/12, work rises by 268 and accounted heap by 7,595 bytes, including
the extra upfront object slot. Raw startup consumes **101,580** units, leaves
**898,420** and accounts for **1,775,866 bytes** with 757 objects. Native entries,
prototypes and globals remain 300, 26 and 213. Trusted initialization stays
bounded at 1,000,000 work units; successful public construction still restores
the 100,000-unit author allowance under the cumulative 8 MiB heap ceiling.

The published parent fails all 15 public groups at the availability guard in
their first sloppy source. Later phases, strict attempts and terminal readbacks
are unreached there. All **25 new groups pass on the first candidate**, comprising
twelve semantic, three terminal and ten private groups. The completed controls
cover 140 public execute calls, 78 private measured attempts and four private
sticky readbacks. No candidate expectation correction was needed.

PENDING_FULL_AND_STRICT

PENDING_RELEASE_AND_REPLAYS

There is no dedicated Promise.try upstream profile or outcome in this runtime
checkpoint; readiness references do not establish one. Classes, async functions
and multiple realms remain outside the current language subset. The evidence
binds 1,778 selected inputs plus a separate tracked-source review, rather than
claiming a complete build graph. Logical fees and regression results establish
no full-conformance, production-security or Chromium-performance result.
The existing withResolvers chapter and earlier validation sections remain
byte-exact with their historical scope.

The [evidence manifest](evidence/promise-try/manifest.json) and
[source/check archive](evidence/promise-try/sources-and-checks.tar.gz) retain the
source contracts, accounting, parent observations and final validation evidence.
'''

entries = []
for rel, value in new.items():
    save(H / 'raw' / rel, value)
    diff = ''.join(difflib.unified_diff(old.get(rel, '').splitlines(True), value.splitlines(True),
                    fromfile=rel if rel in old else '/dev/null', tofile=rel))
    diffpath = H / 'diffs' / (rel.replace('/', '__') + '.diff')
    save(diffpath, diff)
    entries.append({'relative_path': rel, 'raw': binding(H/'raw'/rel),
                    'before': binding(H/'before'/rel) if rel in old else None,
                    'diff': binding(diffpath)})

historical = subprocess.check_output(['git', 'show', f'{BASE}:docs/promise-with-resolvers.md'], cwd=W)
assert historical == (W/'docs/promise-with-resolvers.md').read_bytes()
save(H/'parent/docs/promise-with-resolvers.md', historical)
assert new['docs/VALIDATION.md'].endswith(old['docs/VALIDATION.md'][len(heading):])
sources = ['source-parent.json', 'source-candidate-1.json', 'root/selection-1.json',
           'root/public-selection-1.json', 'root/startup-observation.json',
           'root/parent-startup-observation.json', 'root/focused-validation.json',
           'root/parent-public-observation.json', 'root/spec-observation-1.json',
           'root/prior-ci-observation-1.json', 'root/format-check-orchestration.json',
           'root/source-closure-review-1/source-review.json',
           'production-review-1/review.json', 'public-contract-1/source-ready.json',
           'private-contract-1/roster.json']
status = {'status':'draft; final outcome paragraphs pending; not an import seal',
          'base':BASE, 'files':entries, 'bindings':[binding(D/n) for n in sources],
          'historical_with_resolvers':binding(H/'parent/docs/promise-with-resolvers.md'),
          'pending':['complete full-suite receipts and exact rosters', 'strict Clippy and format',
                     'rebuilt release adapters and seven full replay arrays', 'root final-validation ledger'],
          'checks':['all five old document bytes join published base and current worktree',
                    'old VALIDATION body after heading is exact suffix',
                    'withResolvers chapter is absent from proposed edits and exact published bytes'],
          'scope':'Documentation only; no live writes, project execution or new outcome inference.'}
save(H/'draft-status.json', json.dumps(status,indent=2)+'\n')
print(json.dumps({'draft_files':len(entries), 'chapter_words':len(new['docs/promise-try.md'].split()),
                  'status':binding(H/'draft-status.json')}))
