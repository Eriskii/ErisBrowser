from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

D=Path('/tmp/eris-promise-try-runtime-plan-1')
H=D/'documentation-1'
W=D/'worktree'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
def bind(p):
    data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def write(p,x):
    assert not p.exists(),p
    p.write_text(json.dumps(x,indent=2)+'\n')
def check_binding(b):
    assert bind(Path(b['path']))==b,b['path']

assert not (H/'source-ready.json').exists()
ledger_path=D/'root/final-validation.json'
assert bind(ledger_path)['sha256']=='954e5cdb2e1766bd6ae42792aa9becb2b6bbb70a38815a152c1b952382df358b'
ledger=json.loads(ledger_path.read_bytes())
content=json.loads((H/'content-ready.json').read_bytes())
for x in content['files']:
    for k in ['raw','before','diff']:
        if x[k] is not None:check_binding(x[k])
for x in content['bindings']:check_binding(x)
for row in content['receipts']:
    check_binding(row['receipt']);check_binding(row['log'])
for row in content['profiles']:
    check_binding(row['report']);check_binding(row['parent'])
assert ledger['status']=='pass' and ledger['base']==BASE
for key,file in [('parent_public','root/parent-public-observation.json'),
                 ('candidate','root/focused-validation.json'),('rust','root/rust-validation.json'),
                 ('startup','root/startup-observation.json'),('profiles','root/profile-validation.json')]:
    assert ledger[key]==json.loads((D/file).read_bytes()),key
assert len(ledger['checks'])==17
for x in ledger['checks']:
    check_binding(x['receipt']);check_binding(x['log'])
for x in ledger['source_peers']:check_binding(x)
for key in ['source_final','source_candidate','scope_qualification','source_peer']:
    check_binding(ledger['source'][key])
assert json.loads(Path(ledger['source']['source_peer']['path']).read_bytes())['status']=='clear'
assert ledger['source']['selected_inputs']==1778
assert ledger['candidate']['groups']==25
assert ledger['candidate']['source_or_expectation_corrections']==0
assert ledger['profiles']['cases']==1300 and ledger['profiles']['controls']==546
assert ledger['startup']['work']==101580 and ledger['startup']['remaining']==898420
assert ledger['startup']['accounted_heap']==1775866 and ledger['startup']['objects']==757
assert ledger['startup']['delta']=={'work':268,'accounted_heap':7595,'objects':1}
assert ledger['accounting']['tail_work']=='8+3n'
assert ledger['accounting']['tail_heap']=='32+n*sizeof(Value)'
assert ledger['accounting']['installer_work_spare']==246 and ledger['accounting']['installer_work_growth']==268
assert ledger['prior_ci']['head']==BASE and ledger['prior_ci']['jobs']==11
assert ledger['prior_ci']['conclusion']=='success'
check_binding(ledger['prior_ci']['receipt'])
source=json.loads((D/'source-final.json').read_bytes())
for rel,digest in source['source_sha256'].items():
    assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==digest,rel

rows=[];inverses=[];changed_links=[]
for entry in content['files']:
    rel=entry['relative_path']
    raw=(H/'raw'/rel).read_bytes()
    assert b'PENDING_' not in raw
    assert all(line.rstrip(b' \t')==line for line in raw.splitlines()),rel
    if entry['before']:
        before=(H/'before'/rel).read_bytes()
        git=subprocess.check_output(['git','show',f'{BASE}:{rel}'],cwd=W)
        assert before==git==(W/rel).read_bytes(),rel
    else:
        before=b''
        assert not (W/rel).exists(),rel
    a=before.decode().splitlines(True);b=raw.decode().splitlines(True)
    generated=''.join(difflib.unified_diff(a,b,fromfile=rel if before else '/dev/null',tofile=rel))
    assert generated==(H/'diffs'/(rel.replace('/','__')+'.diff')).read_text()
    changes=[]
    for tag,i,j,k,l in difflib.SequenceMatcher(a=a,b=b,autojunk=False).get_opcodes():
        if tag!='equal':
            changes.append({'old_start':i,'old_end':j,'new_start':k,'new_end':l,
                            'before':''.join(a[i:j]),'after':''.join(b[k:l])})
            changed_links.extend((rel,url) for url in re.findall(r'\]\(([^)]+)\)',''.join(b[k:l])))
    restored=b[:]
    for edit in reversed(changes):
        restored[edit['new_start']:edit['new_end']]=edit['before'].splitlines(True)
    assert ''.join(restored).encode()==before,rel
    inverses.append({'relative_path':rel,'changes':changes,'inverse_recovers_exact_before':True})
    rows.append(entry)
assert len(rows)==6
heading=b'# Validation record\n\n'
old=(H/'before/docs/VALIDATION.md').read_bytes()
new=(H/'raw/docs/VALIDATION.md').read_bytes()
assert new.startswith(heading) and new.endswith(old[len(heading):])
historical=H/'parent/docs/promise-with-resolvers.md'
assert historical.read_bytes()==(W/'docs/promise-with-resolvers.md').read_bytes()
assert historical.read_bytes()==subprocess.check_output(['git','show',f'{BASE}:docs/promise-with-resolvers.md'],cwd=W)
links=[]
future={'evidence/promise-try/manifest.json','evidence/promise-try/sources-and-checks.tar.gz'}
for rel,url in sorted(set(changed_links)):
    if url.startswith('https://'):
        assert url=='https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.try'
        kind='primary specification; reviewed in bound public readiness/spec observation'
    elif url in future:
        kind='root-selected future evidence destination'
    else:
        destination=(Path(rel).parent/url).as_posix()
        assert (H/'raw'/destination).exists() or (W/destination).exists(),(rel,url)
        kind='existing repository path or proposed chapter'
    links.append({'from':rel,'target':url,'status':kind})
write(H/'inverse-checks.json',{'files':inverses,'history':{'validation_suffix_exact':True,
     'with_resolvers_untouched':bind(historical)},'links':links})
bindings=[bind(ledger_path),bind(D/'source-final.json'),bind(D/'source-final-review-1/review.json'),
          bind(D/'root/spec-observation-1.json'),bind(D/'public-readiness-1/primary-observation.json'),
          bind(D/'root/selection-1.json'),bind(D/'production-review-1/review.json'),
          bind(D/'root/focused-validation.json'),bind(D/'root/parent-public-observation.json'),
          bind(D/'root/startup-observation.json'),bind(D/'root/rust-validation.json'),
          bind(D/'root/profile-validation.json'),bind(D/'root/prior-ci-observation-1.json'),
          bind(D/'root/source-scope-qualification.json'),bind(D/'root/format-check-orchestration.json')]
checks={'status':'clear','ledger':bind(ledger_path),'content_checks':bind(H/'content-ready.json'),
        'inverse_history_links':bind(H/'inverse-checks.json'),'bindings':bindings,
        'claims':{'parent':'0 pass/15 first-sloppy availability failures; later phases/strict/readbacks unreached',
                  'first_candidate':'25 pass, 15 public plus10 private;140 public calls,78 private attempts,4 private readbacks',
                  'full':'3246/3600 with52 result rows each;25 additions/four boundary renames',
                  'strict':'both all-target Clippy plus formatting pass; two Rust1.88 release adapters rebuilt',
                  'replays':'all1300 case and546 control arrays/policies/corpus exact, including existing nonpassing outcomes',
                  'startup':'101580work/898420remaining/1775866accountedbytes/757objects; measured268/7595delta',
                  'preservation':'old VALIDATION body and withResolvers chapter exact; no Python-suite or new remote CI claim',
                  'scope':'1778 selected source hashes unchanged between candidate/final; scope text alone corrected'},
        'qualification':'Documentation author stdlib/read-only Git checks, not an independent project execution or final validation peer.'}
write(H/'claims-and-checks.json',checks)
record={'status':'sealed documentation payload; six paths; no pending result markers','base':BASE,
        'files':rows,'final_validation':bind(ledger_path),'source_final':bind(D/'source-final.json'),
        'source_review':bind(D/'source-final-review-1/review.json'),
        'claims_and_checks':bind(H/'claims-and-checks.json'),'inverse_history':bind(H/'inverse-checks.json'),
        'content_evidence':bind(H/'content-ready.json'),
        'author_scripts':[bind(H/x) for x in ['author-draft.py','complete-content.py','seal.py']],
        'historical_chapter':bind(historical),
        'evidence_destinations':['docs/evidence/promise-try/manifest.json','docs/evidence/promise-try/sources-and-checks.tar.gz'],
        'scope':'External documentation payload only; no live edits or project execution.'}
write(H/'source-ready.json',record)
print(json.dumps(bind(H/'source-ready.json')))
