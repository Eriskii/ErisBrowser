import pathlib,json,re,hashlib,subprocess,difflib
D=pathlib.Path('/tmp/eris-promise-try-runtime-plan-1');W=D/'worktree';B='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9';O=D/'migrations-review-1'
m=json.loads((D/'migrations-1/source-ready.json').read_text())
rs=sorted(p for p in subprocess.check_output(['git','-C',str(W),'ls-tree','-r','--name-only',B]).decode().splitlines() if p.endswith('.rs'))
x=subprocess.check_output(['git','-C',str(W),'cat-file','--batch'],input=''.join(B+':'+p+'\n' for p in rs).encode());off=0;blobs={}
for p in rs:
 e=x.index(b'\n',off);n=int(x[off:e].split()[2]);blobs[p]=x[e+1:e+1+n];off=e+n+2
assert off==len(x)
bind=json.loads((D/'migration-census-1/published-rust-bindings.json').read_text())
assert len(rs)==598 and {r['path'] for r in bind['files']}==set(rs)
for r in bind['files']:assert hashlib.sha256(blobs[r['path']]).hexdigest()==r['sha256']
rows=[];groups=0
for r in m['files']:
 p=r['relative_path'];before=blobs[p].decode();after=pathlib.Path(r['raw']['path']).read_text()
 for key in ['before','raw','diff']:
  rr=r[key];b=pathlib.Path(rr['path']).read_bytes();assert len(b)==rr['bytes'] and hashlib.sha256(b).hexdigest()==rr['sha256']
 assert pathlib.Path(r['before']['path']).read_bytes()==blobs[p]
 new=before
 for ed in r['edits']:
  assert new.count(ed['before'])==ed['count'],(p,'forward')
  new=new.replace(ed['before'],ed['after'])
 assert new==after,p
 inv=after
 for ed in reversed(r['edits']):
  assert inv.count(ed['after'])==ed['count'],(p,'inverse')
  inv=inv.replace(ed['after'],ed['before'])
 assert inv==before,p
 assert ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=p,tofile=p))==pathlib.Path(r['diff']['path']).read_text()
 names=lambda s:re.findall(r'#\[test\]\s*fn\s+(\w+)',s)
 oldnames=names(before);newnames=names(after)
 assert [r['renames'].get(n,n) for n in oldnames]==newnames
 assert len(oldnames)==r['groups'];groups+=len(oldnames)
 lit=lambda s:re.findall(r'r(#+)"(.*?)"\1',s,re.S)
 oldlit=lit(before);newlit=lit(after);assert len(oldlit)==len(newlit)
 changes=[]
 for i,(a,b) in enumerate(zip(oldlit,newlit)):
  if a!=b:
   assert a[0]==b[0] and a[1].replace('allSettled,any,withResolvers','allSettled,any,withResolvers,try')==b[1]
   changes.append(i)
 rows.append({'path':p,'groups':len(oldnames),'before_sha256':hashlib.sha256(blobs[p]).hexdigest(),'raw_sha256':hashlib.sha256(after.encode()).hexdigest(),'exact_forward_inverse_and_diff':True,'raw_js_changed_indices':changes,'renames':r['renames']})
assert groups==135 and len(rows)==17
assert sum(len(r['raw_js_changed_indices']) for r in rows)==3
for p,fn in [('src/script/promises/any_quota_tests.rs','any_raw_startup'),('src/script/promises/with_resolvers_quota_tests.rs','with_resolvers_startup')]:
 before=blobs[p].decode();after=(D/'migrations-1/raw'/p).read_text()
 a=re.search(r'(?m)^fn '+fn+r'\w*\(',before);b=re.search(r'(?m)^fn '+fn+r'\w*\(',after);assert a and b
 assert before[:a.start()]==after[:b.start()]
 nexta=before.find('\n#[test]',a.end());nextb=after.find('\n#[test]',b.end());assert before[nexta:]==after[nextb:]
# Independent broader fixed-total/owner scan; source-review evaluates hits rather than automatically migrating numbers.
pattern=re.compile(r'101_?31[12]|898_?688|1_?768_?271|\b(?:756|767|768)\b|finish_bootstrap|initialize_bootstrap|objects\[constructor\]\.values\.len\(\)|getOwnPropertyNames\((?:P|Promise)\)')
hits=[{'path':p,'lines':[{'line':i,'text':l} for i,l in enumerate(v.decode().splitlines(),1) if pattern.search(l)]} for p,v in blobs.items() if pattern.search(v.decode())]
(O/'mechanical-checks.json').write_text(json.dumps({'base':B,'published_rust_files':len(rs),'retained_groups':groups,'files':rows,'independent_scan':hits},indent=2)+'\n')
print(json.dumps({'rust_files':len(rs),'paths':len(rows),'groups':groups,'raw_js_changes':3,'scan_hit_paths':len(hits),'all_checks':True}))
