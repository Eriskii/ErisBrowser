from pathlib import Path
import hashlib,json,shutil,subprocess
D=Path(__file__).resolve().parents[1];C=Path('/tmp/eris-promise-with-resolvers-upstream-plan-1');B=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1');MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser');W=D/'worktree'
publication=json.loads((C/'root/github-publication.json').read_bytes());assert publication['status']=='pushed';base=publication['commit']
def git(*args):return subprocess.check_output(['git',*args],cwd=MAIN,text=True).strip()
assert git('rev-parse','HEAD')==base and git('status','--porcelain')=='';assert not W.exists()
subprocess.run(['git','worktree','add','-b','promise-try-runtime',str(W),base],cwd=MAIN,check=True)
source=json.loads((C/'source-final.json').read_bytes());source['base']=base
for rel,sha in source['source_sha256'].items():assert hashlib.sha256((W/rel).read_bytes()).hexdigest()==sha,rel
(D/'source-parent.json').write_text(json.dumps(source,indent=2)+'\n')
for name in ['run-tool.py','run-check.py']:shutil.copyfile(C/name,D/name)
for name in ['target-msrv','target-1990']:(D/name).symlink_to((C/name).resolve(),target_is_directory=True)
for directory in ['validation','replay-parent','rust-parent']:(D/directory).mkdir()
for short in ['aggregate-error','existing','all','race','settled','any','with-resolvers']:shutil.copyfile(C/f'upstream-{short}-1.json',D/'replay-parent'/f'upstream-{short}-1.json')
for name in ['default-full-1','host-vulkan-full-1']:
 for suffix in ['log','json']:shutil.copyfile(B/'validation'/f'{name}.{suffix}',D/'rust-parent'/f'{name}.{suffix}')
shutil.copyfile(B/'root/startup-observation.json',D/'root/parent-startup-observation.json')
record=dict(base=base,branch='promise-try-runtime',worktree=str(W),parent_source_count=len(source['source_sha256']),parent_source_sha256=hashlib.sha256((D/'source-parent.json').read_bytes()).hexdigest(),scope='Custom Promise.try runtime; current draft callback-first semantics. Existing Python tooling/upstream profiles remain unchanged; retained seven profile reports include all1300cases546controls. Raw Rust parent observations remain BH3221/3575 because C had no Rust changes.')
(D/'root/setup.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
