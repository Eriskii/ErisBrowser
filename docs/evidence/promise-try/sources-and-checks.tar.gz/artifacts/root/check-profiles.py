"""Compare all retained parent cases and controls without resetting baselines."""
from pathlib import Path
import hashlib,json
B=Path(__file__).resolve().parents[1]
rows=[]
for name in ('aggregate-error','existing','all','race','settled','any','with-resolvers'):
 path=B/f'upstream-{name}-1.json'
 report=json.loads(path.read_bytes());parent=json.loads((B/'replay-parent'/path.name).read_bytes())
 for field in ('cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','mode_cases'):
  assert report[field]==parent[field],(name,field)
 assert report['harness_preflight_passed'] and not report['regressions'] and not report['improvements']
 assert all(row['verified'] is True for row in report['harness_preflight'])
 rows.append({'name':name,'cases':len(report['cases']),'controls':len(report['harness_preflight']),'counts':report['counts'],'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'binary_sha256':report['binary_sha256']})
assert sum(row['cases'] for row in rows)==1300
assert sum(row['controls'] for row in rows)==546
assert len({row['binary_sha256'] for row in rows if row['name']not in ('aggregate-error','with-resolvers')})==1
record={'status':'pass','profiles':rows,'cases':1300,'controls':546,'comparison':'Complete case/control arrays, policy and corpus identities exact; rebuilt binary identities intentionally differ. No baseline changes.'}
with (B/'root/profile-validation.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
