from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parents[1];W=D/'worktree'
def load(p):return json.loads((D/p).read_bytes())
def bind(p):
 p=D/p;b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
final=load('source-final.json');candidate=load('source-candidate-1.json')
assert final['source_sha256']==candidate['source_sha256'] and final['base']==candidate['base']
assert len(final['source_sha256'])==1778
for rel,sha in final['source_sha256'].items():assert bind('worktree/'+rel)['sha256']==sha,rel
source_review=load('source-final-review-1/review.json');assert source_review['status']=='clear'
rust=load('root/rust-validation.json');profiles=load('root/profile-validation.json')
assert rust['status']==profiles['status']=='pass'
assert profiles['cases']==1300 and profiles['controls']==546
labels=['try-parent-public-1','format-candidate-1','try-candidate-focused-1','default-full-1','host-vulkan-full-1','clippy-default-1','clippy-host-vulkan-1','try-release-ordinary-1','try-release-host-1','fmt-check-1']+['upstream-'+n+'-1' for n in ['aggregate-error','existing','all','race','settled','any','with-resolvers']]
checks=[]
for label in labels:
 receipt=load('validation/'+label+'.json');log=bind('validation/'+label+'.log')
 assert receipt['exit']==(101 if label=='try-parent-public-1' else 0),label
 assert receipt['sha256']==log['sha256'],label
 checks.append(dict(label=label,exit=receipt['exit'],receipt=bind('validation/'+label+'.json'),log=log))
assert {p.stem for p in (D/'validation').glob('*.json')}==set(labels)
binaries=[]
for kind in ['ordinary','host']:
 row=load('eris-js-'+kind+'-1.json');assert bind('eris-js-'+kind+'-1')['sha256']==row['sha256']
 assert row['source_sha256']==bind('source-candidate-1.json')['sha256'];binaries.append(row)
ci=load('root/prior-ci-observation-1.json');assert ci['headSha']==final['base'] and ci['conclusion']=='success';assert len(ci['jobs'])==11 and all(j['conclusion']=='success' for j in ci['jobs'])
peers=[bind(n+'/review.json') for n in ['public-review-1','private-review-1','production-review-1','migrations-review-1','source-final-review-1']]
result=dict(status='pass',checkpoint='Custom Promise.try runtime',base=final['base'],scope='Seven production files,17 historical test migrations,3 new test modules. No runtime types/fields, limits, host protocol, Python tooling, corpus, baseline, or CI changes.',source=dict(selected_inputs=1778,source_paths=27,changed_existing=24,new_modules=3,source_final=bind('source-final.json'),source_candidate=bind('source-candidate-1.json'),scope_qualification=bind('root/source-scope-qualification.json'),source_peer=bind('source-final-review-1/review.json'),qualification='Selected inventory plus independent tracked-source census; not a complete build graph.'),parent_public=load('root/parent-public-observation.json'),candidate=load('root/focused-validation.json'),rust=rust,startup=load('root/startup-observation.json'),accounting=dict(public_operation=8,body=16,callback_copy=1,tail_work='8+3n',tail_heap='32+n*sizeof(Value)',tail_limit=65536,installer_work_spare=246,installer_work_growth=268,installer_heap='A+D+(2 or14)K+4Bpp+N+1179; one upfront ScriptObject slot charged separately',existing_capability_and_resolution='Unchanged helper charges apply separately',qualification='Logical work/heap accounting, not CPU instructions or process RSS.'),profiles=profiles,binaries=binaries,source_peers=peers,checks=checks,prior_ci=dict(head=ci['headSha'],id=38813728239,jobs=11,conclusion='success',receipt=bind('root/prior-ci-observation-1.json')),receipt_corrections=[bind('root/format-check-orchestration.json'),bind('root/source-scope-qualification.json')],limitations=['Dedicated Promise.try upstream selection is reference-only here; no imported profile or outcome claimed.','Classes, async functions, Proxy and multiple realms remain outside current language scope.','Selected passing tests do not establish full web compatibility, a security audit, or Chromium-relative performance.','No hardware Vulkan, process RSS, native stack, or unchanged Python-suite rerun is claimed.'],history='All25 new groups pass the first candidate execution. Parent public15 fail as expected at absence guards. No source or expectation correction after execution; formatting preserves literals and comments.')
with (D/'root/final-validation.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(dict(record=bind('root/final-validation.json'),checks=len(checks),rust=[r['totals'][0] for r in rust['runs']],cases=profiles['cases'],controls=profiles['controls'])))
