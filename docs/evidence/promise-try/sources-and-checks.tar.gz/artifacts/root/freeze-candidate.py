from pathlib import Path
import hashlib,json,difflib,runpy,subprocess
D=Path(__file__).resolve().parents[1];W=D/'worktree';R=D/'root/source-closure-review-1';R.mkdir(exist_ok=True)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
parent=json.loads((D/'source-parent.json').read_text());old=parent['source_sha256'];new=dict(old)
imported=json.loads((D/'root/candidate-import-1.json').read_text());rows=[];punctuation=[]
tokens=runpy.run_path(str(D/'root/rust-lexical.py'))['tokens']
for row in imported['files']:
 rel=row['relative'];before=Path(row['composed']['path']).read_text();after=(W/rel).read_text()
 ta,la,ca=tokens(before);tb,lb,cb=tokens(after)
 assert la==lb and ca==cb,rel
 edits=[]
 for kind,i,j,a,b in difflib.SequenceMatcher(a=ta,b=tb,autojunk=False).get_opcodes():
  if kind=='equal':continue
  left,right=ta[i:j],tb[a:b]
  assert [v for v in left if v not in {',','{','}'}]==[v for v in right if v not in {',','{','}'}],(rel,left,right)
  edits.append(dict(kind=kind,before=left,after=right,left_context=ta[max(0,i-10):i],right_context=ta[j:j+10]))
 if before!=after:
  p=R/(rel.replace('/','__')+'.diff');p.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='composed/'+rel,tofile='formatted/'+rel)))
 if edits:punctuation.append(dict(relative=rel,edits=edits))
 new[rel]=bind(W/rel)['sha256'];rows.append(dict(relative=rel,composed=row['composed'],formatted=bind(W/rel),literal_vector_exact=True,comments_exact=True,punctuation_edits=len(edits)))
for rel,sha in new.items():assert bind(W/rel)['sha256']==sha,rel
changed={r for r in old if old[r]!=new[r]};added=set(new)-set(old)
assert len(changed)==24 and len(added)==3 and len(new)==1778
assert changed|added=={r['relative'] for r in imported['files']}
result=dict(status='source closure verified; formatting punctuation contexts require root review',parent=bind(D/'source-parent.json'),selected_input_count=len(new),changed_existing=len(changed),added=len(added),unchanged_selected=len(old)-len(changed),files=rows,punctuation=punctuation)
(R/'checks.json').write_text(json.dumps(result,indent=2)+'\n')
candidate=dict(parent,source_sha256=dict(sorted(new.items())))
(D/'source-candidate-1.json').write_text(json.dumps(candidate,indent=2)+'\n')
print(json.dumps(dict(source=bind(D/'source-candidate-1.json'),closure=bind(R/'checks.json'),punctuation=punctuation)))
