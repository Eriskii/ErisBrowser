import json
from pathlib import Path
import subprocess
B=Path(__file__).resolve().parents[1];W=B/'worktree';MAIN=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9';P=B/'publication';P.mkdir(exist_ok=True);record_path=B/'root/github-publication.json';assert not record_path.exists()
verified=json.loads((B/'root/publication-verification.json').read_bytes());assert verified['status']=='verified' and verified['path_count']==35

def git(directory,*args):
 r=subprocess.run(['git',*args],cwd=directory,text=True,capture_output=True,check=True);return r.stdout.strip()

assert git(MAIN,'branch','--show-current')=='main'
assert git(MAIN,'rev-parse','HEAD')==git(W,'rev-parse','HEAD')==BASE
assert git(MAIN,'status','--porcelain')=='' and git(W,'diff','--cached','--name-only')==''
paths=verified['expected_commit_paths'];pathspec=P/'paths.nul';pathspec.write_bytes(b'\0'.join(p.encode() for p in paths)+b'\0')
git(W,'add','--pathspec-from-file='+str(pathspec),'--pathspec-file-nul')
assert set(git(W,'diff','--cached','--name-only').splitlines())==set(paths)
git(W,'diff','--cached','--check')
message=P/'commit-message.txt';message.write_text('Implement custom Promise.try\n\nCall the callback synchronously before resolving through the captured constructor,\npreserving existing Promise identity and exact rejection values. Bound argument\ncopies and metadata installation without raising runtime resource limits.\n\nValidate 25 new groups, full Rust suites (3246 default and 3600 host/Vulkan),\nstrict Clippy and formatting. Rebuilt adapters retain all 1300 case records and\n546 harness controls across seven existing conformance profiles.\n')
(P/'commit.log').write_text(git(W,'commit','-F',str(message))+'\n');commit=git(W,'rev-parse','HEAD')
assert git(W,'status','--porcelain')==''
assert set(git(W,'diff-tree','--no-commit-id','--name-only','-r',commit).splitlines())==set(paths)
record={'status':'committed','base':BASE,'commit':commit,'repository':'https://github.com/Eriskii/ErisBrowser','paths':len(paths)};record_path.write_text(json.dumps(record,indent=2)+'\n')
(P/'merge.log').write_text(git(MAIN,'merge','--ff-only','promise-try-runtime')+'\n')
assert git(MAIN,'rev-parse','HEAD')==commit and git(MAIN,'status','--porcelain')==''
(P/'push.log').write_text(git(MAIN,'push','origin','main')+'\n');remote=git(MAIN,'ls-remote','origin','refs/heads/main').split()[0];assert remote==commit
record.update(status='pushed',remote_head=remote,ci='not yet observed');record_path.write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
