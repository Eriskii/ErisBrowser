from pathlib import Path
from collections import Counter
import hashlib,json,re
D=Path(__file__).resolve().parents[1]
def load(p):return json.loads((D/p).read_bytes())
def bind(p):
 b=(D/p).read_bytes();return dict(path=str(D/p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
renames=load('migrations-1/source-ready.json')['renames']
public=load('public-contract-1/roster.json');private=load('private-contract-1/roster.json')
added=Counter(['script::try_semantics_tests::'+n for n in public['semantic_roster']]+['script::try_abort_tests::'+n for n in public['terminal_roster']]+['script::promises::try_quota_tests::'+g['name'] for g in private['per_group']])
assert sum(added.values())==25
records=[]
for name,total in [('default-full-1',3246),('host-vulkan-full-1',3600)]:
 s=(D/'validation'/f'{name}.log').read_text();old=(D/'rust-parent'/f'{name}.log').read_text();receipt=load('validation/'+name+'.json')
 assert receipt['exit']==0 and receipt['sha256']==hashlib.sha256(s.encode()).hexdigest()
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s)
 totals=[sum(int(r[i]) for r in rows) for i in range(5)];assert len(rows)==52 and totals==[total,0,0,0,0],(name,totals,len(rows))
 now=Counter(re.findall(r'^test (\S+) \.\.\. ok$',s,re.M));before=Counter(re.findall(r'^test (\S+) \.\.\. ok$',old,re.M))
 assert sum(now.values())==total and sum(before.values())==total-25
 for rename in renames:
  keys=[k for k in before if k.endswith('::'+rename['before'])];assert len(keys)==1
  key=keys[0];count=before.pop(key);before[key[:-len(rename['before'])]+rename['after']]=count
 assert now==before+added,(name,now-before-added,before+added-now)
 records.append(dict(configuration=name,totals=totals,result_rows=len(rows),parent_tests=total-25,new_groups=25,old_renames=4,complete_test_identity_multiset_preserved=True,log=bind('validation/'+name+'.log'),receipt=bind('validation/'+name+'.json')))
result=dict(status='pass',runs=records,qualification='Selected configurations only; no complete web standards, security, hardware Vulkan, or Chromium performance conclusion.')
with (D/'root/rust-validation.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps(result))
