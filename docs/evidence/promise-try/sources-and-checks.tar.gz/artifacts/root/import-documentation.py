from pathlib import Path
import hashlib,json
D=Path(__file__).resolve().parents[1];W=D/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def verify(row):assert bind(Path(row['path']))==row
m=json.loads((D/'documentation-1/source-ready.json').read_text());peer=json.loads((D/'documentation-review-1/review.json').read_text());assert peer['status']=='clear'
expected={'README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/SECURITY.md','docs/VALIDATION.md','docs/promise-try.md'}
assert {r['relative_path'] for r in m['files']}==expected
for row in m['files']:
 verify(row['raw']);verify(row['diff']);p=W/row['relative_path']
 if row['before']:
  verify(row['before']);assert p.read_bytes()==Path(row['before']['path']).read_bytes()
 else:assert not p.exists()
old=(W/'docs/VALIDATION.md').read_text();new=(D/'documentation-1/raw/docs/VALIDATION.md').read_text();assert new.endswith(old[len('# Validation record\n\n'):])
historical=W/'docs/promise-with-resolvers.md';prior=bind(historical)
for row in m['files']:(W/row['relative_path']).write_bytes(Path(row['raw']['path']).read_bytes())
assert bind(historical)==prior
result=dict(status='reviewed documentation imported',source_ready=bind(D/'documentation-1/source-ready.json'),peer=bind(D/'documentation-review-1/review.json'),files=[bind(W/r['relative_path']) for r in m['files']],historical_with_resolvers_unchanged=prior,old_validation_body_exact=True)
(D/'root/documentation-import-1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(paths=len(m['files']),receipt=bind(D/'root/documentation-import-1.json'))))
