from pathlib import Path
import difflib,hashlib,json,re
D=Path(__file__).resolve().parents[1];W=D/'worktree';H=D/'migrations-1';H.mkdir()
census=json.loads((D/'migration-census-1/census.json').read_bytes());rows={r['path']:r for r in census['rows']};texts={p:(W/p).read_text() for p in rows};before=dict(texts);edits={p:[] for p in rows}
def replace(path,old,new,count=1):
 assert texts[path].count(old)==count,(path,old,texts[path].count(old),count)
 texts[path]=texts[path].replace(old,new);edits[path].append(dict(before=old,after=new,count=count))
def replace_numbers(path,mapping):
 pattern=r'\b(?:'+ '|'.join(map(str,mapping)) +r')\b'
 old=texts[path];new=re.sub(pattern,lambda m:str(mapping[int(m[0])]),old)
 assert new!=old
 # One full-file inverse is explicit and prevents serial numeric remapping.
 texts[path]=new;edits[path].append(dict(before=old,after=new,count=1,reason='simultaneous full-realm/fixture-count substitutions only'))
for p in rows:
 if p in ['src/script/promises/any_quota_tests.rs','src/script/promises/with_resolvers_quota_tests.rs']:continue
 if p=='src/script/promises/shared_key_tests.rs':replace_numbers(p,{756:757,757:758,768:769})
 elif p=='src/script/promises/install_tests.rs':replace_numbers(p,{756:757,767:768})
 elif re.search(r'\b756\b',texts[p]):replace_numbers(p,{756:757})
 for old,new in [('898_688','898_420')]:
  count=texts[p].count(old)
  if count:replace(p,old,new,count)
for r in census['proposed_renames']:replace(r['path'],r['before'],r['after'])
for p in ['src/script/processing_instruction/key_cache_tests.rs','src/script/promises/install_tests.rs','src/script/text_operations/key_cache_tests.rs']:
 replace(p,'        (101_311, false, 0),\n        (101_312, true, 0),','        (101_311, false, 0),\n        (101_312, false, 0),\n        (101_579, false, 0),\n        (101_580, true, 0),')
p='src/script/processing_instruction/display_key_tests.rs';replace(p,'assert_eq!(BOOTSTRAP_STEPS - runtime.steps, 101_312);','assert_eq!(BOOTSTRAP_STEPS - runtime.steps, 101_580);')
p='src/script/bootstrap_tests.rs';old='    // Later withResolvers adds326 work and one bag on the selected order-growth path.\n';replace(p,old,old+'    // Promise.try adds268 work at the next B-tree threshold and one reserved bag.\n')
p='src/script/promises/shared_key_tests.rs';replace(p,'    // the retained99693/99694/100000/100986 refusals and new101312 boundary, not this replay.','    // the retained99693/99694/100000/100986/101312 refusals and new101580 boundary, not this replay.')
for p in ['src/script/promises/shared_key_identity_tests.rs','src/script/promise_semantic_tests.rs','src/script/promise_race_semantic_tests.rs']:
 replace(p,'length,name,prototype,resolve,reject,all,race,allSettled,any,withResolvers','length,name,prototype,resolve,reject,all,race,allSettled,any,withResolvers,try')
p='src/script/promises/shared_key_identity_tests.rs';replace(p,'assert_eq!(runtime.objects[constructor].values.len(), 11);','assert_eq!(runtime.objects[constructor].values.len(), 12);')
p='src/script/typed_array/tests.rs';old='    let with_resolvers_added = s + a + d + 13 * k + bpp + n + 1269;\n';replace(p,old,old+'    // Try crosses the count11 B-tree threshold and grows owner order to12.\n    let try_added = s + a + d + 14 * k + 4 * bpp + n + 1179;\n');replace(p,'            - 326\n','            - 326\n            - 268\n');replace(p,'            + with_resolvers_added\n','            + with_resolvers_added\n            + try_added\n')
late='''    // Complete the later Try installer only after the old isolated measurements.
    // The initial bootstrap preparation already paid its extra ScriptObject slot.
    let try_before_order = (
        runtime.objects[id].order.len(),
        runtime.objects[id].order.capacity(),
    );
    assert_eq!(try_before_order.0, 11);
    let try_grow = try_before_order.0 == try_before_order.1;
    let try_work = if try_grow { 268 } else { 246 };
    let try_heap = size_of::<Option<AbortSlot>>()
        + size_of::<Option<f64>>()
        + (if try_grow { 14 } else { 2 }) * size_of::<PropertyKey>()
        + 4 * node_bytes()
        + size_of::<Native>()
        + 1179;
    let try_before_heap = runtime.allocated;
    runtime.steps = try_work;
    runtime.install_promise_try_intrinsic().unwrap();
    assert_eq!(runtime.steps, 0);
    assert_eq!(runtime.allocated - try_before_heap, try_heap);
    assert_eq!(runtime.objects[id].order.len(), 12);
'''
p='src/script/promises/any_quota_tests.rs';replace(p,'    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();',late+'    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();');replace(p,'BOOTSTRAP_STEPS - 100_797 - work - with_resolvers_work','BOOTSTRAP_STEPS - 100_797 - work - with_resolvers_work - try_work');replace(p,'assert_eq!((raw.objects.len(), raw.objects.capacity()), (756, 756));','assert_eq!((raw.objects.len(), raw.objects.capacity()), (757, 757));');replace(p,'// Both retained order observations select fees without guessing allocator capacity.','// Each retained order observation selects fees without guessing allocator capacity.')
p='src/script/promises/with_resolvers_quota_tests.rs';replace(p,'    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();',late+'    let raw = Runtime::uninitialized().finish_bootstrap().unwrap();');replace(p,'assert_eq!(raw.steps, BOOTSTRAP_STEPS - 100_797 - any_work - work);','assert_eq!(raw.steps, BOOTSTRAP_STEPS - 100_797 - any_work - work - try_work);');replace(p,'assert_eq!(raw.objects.len(), 756);','assert_eq!(raw.objects.len(), 757);');replace(p,'assert!(raw.objects.capacity() >= 756);','assert!(raw.objects.capacity() >= 757);')
def info(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
files=[];total=0
for p,new in texts.items():
 old=before[p];inverse=new
 for e in reversed(edits[p]):assert inverse.count(e['after'])==e['count'],(p,e['before'][:50]);inverse=inverse.replace(e['after'],e['before'])
 assert inverse==old and old!=new
 old_names=re.findall(r'#\[test\]\s*fn (\w+)',old);new_names=re.findall(r'#\[test\]\s*fn (\w+)',new);rename={r['before']:r['after'] for r in census['proposed_renames'] if r['path']==p};assert [rename.get(n,n) for n in old_names]==new_names;total+=len(old_names)
 raw=H/'raw'/p;raw.parent.mkdir(parents=True,exist_ok=True);raw.write_text(new);diff=H/'diff'/(p+'.diff');diff.parent.mkdir(parents=True,exist_ok=True);diff.write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=p,tofile=p)))
 files.append(dict(relative_path=p,before=info(W/p),raw=info(raw),diff=info(diff),edits=edits[p],groups=len(old_names),renames=rename,inverse_exact=True))
assert len(files)==17 and total==135
s=dict(status='frozen historical migrations before candidate execution; target projections remain to be measured',base=census['base'],selection=info(D/'root/selection-1.json'),census=info(D/'migration-census-1/source-ready.json'),files=files,retained_groups=135,renames=census['proposed_renames'],qualification='Whole-realm witnesses advance; old raw successful101312 becomes retained refusal. Earlier installer stages/tariffs and metadata IDs remain exact; Any/withResolvers raw observers execute the new late stage only after old isolated assertions.')
p=H/'source-ready.json';p.write_text(json.dumps(s,indent=2)+'\n');print(info(p))
