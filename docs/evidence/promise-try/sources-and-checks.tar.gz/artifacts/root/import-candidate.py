from pathlib import Path
import hashlib,json,subprocess
D=Path(__file__).resolve().parents[1];W=D/'worktree'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def load(p):return json.loads((D/p).read_bytes())
def verify(v):
 actual=bind(Path(v['path']));assert all(actual[k]==v[k] for k in actual),v['path']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==load('source-parent.json')['base']
reviews=[]
for name in ['public','private','production','migrations']:
 p=D/(name+'-review-1')/('review.json');assert p.exists();reviews.append(bind(p))
parent=load('source-parent.json')['source_sha256']
registration={r['relative_path']:r for r in load('registrations-1/source-ready.json')['files']}
expected={};origins={};before=[]
for hold in ['production-1','migrations-1','public-contract-1','private-contract-1']:
 for row in load(hold+'/source-ready.json')['files']:
  rel=row.get('relative_path',row.get('relative'));assert rel not in expected
  verify(row['raw']);expected[rel]=Path(row['raw']['path']).read_bytes();origins[rel]=[row['raw']]
  if rel in parent:
   target=W/rel;b=target.read_bytes()
   if rel=='src/script.rs':
    suffix=registration[rel]['append'].encode();assert b.endswith(suffix);b=b[:-len(suffix)]
   assert hashlib.sha256(b).hexdigest()==parent[rel],rel
   p=D/'before-import'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b);before.append(bind(p))
  else:
   assert not (W/rel).exists() or (hold=='public-contract-1' and (W/rel).read_bytes()==expected[rel]),rel
for rel,row in registration.items():expected[rel]+=row['append'].encode();origins[rel].append({'registration_append':row['append']})
assert len(expected)==27
for rel,data in expected.items():
 p=D/'composed-candidate'/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (W/rel).write_bytes(data)
result=dict(status='reviewed holds composed and imported before formatting or candidate execution',reviews=reviews,holds=[bind(D/h/'source-ready.json') for h in ['production-1','migrations-1','public-contract-1','private-contract-1']],before=before,files=[dict(relative=rel,composed=bind(D/'composed-candidate'/rel),origins=origins[rel]) for rel in sorted(expected)])
(D/'root/candidate-import-1.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'paths':len(expected),'record':bind(D/'root/candidate-import-1.json')}))
