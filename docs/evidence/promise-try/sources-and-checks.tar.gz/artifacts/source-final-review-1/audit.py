"""Independent read-only Git/source closure audit; no project imports/execution."""
from pathlib import Path
import collections,difflib,hashlib,json,os,re,stat,subprocess
D=Path('/tmp/eris-promise-try-runtime-plan-1');W=D/'worktree';O=D/'source-final-review-1';BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def load(p):return json.loads(p.read_text())
def verify(r):
 p=Path(r['path']);assert bind(p)==r,(p,'binding');return p.read_bytes()
candidate=load(D/'source-candidate-1.json');final=load(D/'source-final.json');parent=load(D/'source-parent.json')
assert bind(D/'source-candidate-1.json')['sha256']=='f0966e6e4e617bdf81f510306fdf3bf3109098e4ac780d6f99bc61091f415050'
assert bind(D/'source-final.json')['sha256']=='1a176700a84d40a1fe8a2afec7ad3d5b42f18d08d4a9997afee0d30ef54bc958'
assert candidate['base']==final['base']==BASE and candidate['source_sha256']==final['source_sha256']
assert set(candidate)==set(final) and candidate['scope']!=final['scope']
for p,h in final['source_sha256'].items():assert hashlib.sha256((W/p).read_bytes()).hexdigest()==h,p
assert len(final['source_sha256'])==1778
added=set(final['source_sha256'])-set(parent['source_sha256']);changed={p for p in parent['source_sha256'] if final['source_sha256'].get(p)!=parent['source_sha256'][p]};assert len(added)==3 and len(changed)==24
receipt=load(D/'root/candidate-import-1.json');assert {r['relative'] for r in receipt['files']}==added|changed
for r in receipt['reviews']+receipt['holds']+receipt['before']:verify(r)
# Validate every composed source against its held payload plus only explicit append registrations.
composed={}
for row in receipt['files']:
 chunks=[]
 for origin in row['origins']:
  if 'registration_append' in origin:chunks.append(origin['registration_append'].encode())
  else:chunks.append(verify(origin))
 raw=b''.join(chunks);assert raw==verify(row['composed']);composed[row['relative']]=raw
# Production current bytes are exactly composed; selected edit inverses recover all parent bytes.
production=load(D/'production-1/source-ready.json');edits=load(D/'production-1/edit-manifest.json')['edits'];inverses=[]
for row in production['files']:
 p=row['relative_path'];raw=verify(row['raw']);before=verify(row['before']);assert (W/p).read_bytes()==composed[p]
 after=composed[p]
 origins=next(r for r in receipt['files'] if r['relative']==p)['origins']
 for origin in reversed(origins[1:]):
  suffix=origin['registration_append'].encode();assert after.endswith(suffix);after=after[:-len(suffix)]
 assert after==raw
 s=after.decode()
 for e in reversed([e for e in edits if e['path']==p]):
  assert s.count(e['after'])==1;s=s.replace(e['after'],e['before'],1)
 baseline=subprocess.check_output(['git','-C',str(W),'show',BASE+':'+p]);assert s.encode()==before==baseline
 inverses.append({'path':p,'parent_sha256':hashlib.sha256(baseline).hexdigest(),'production_raw_exact':True,'inverse_exact':True,'registration_only':len(origins)>1})
# Scan Rust source lexically without evaluating it. Keep comments/literals verbatim.
def lex(s):
 tokens=[];literals=[];comments=[];i=0
 while i<len(s):
  if s[i].isspace():i+=1;continue
  if s.startswith('//',i):
   e=s.find('\n',i);e=len(s) if e<0 else e;comments.append(s[i:e]);i=e;continue
  if s.startswith('/*',i):
   j=i+2;depth=1
   while depth:
    assert j<len(s)
    if s.startswith('/*',j):depth+=1;j+=2
    elif s.startswith('*/',j):depth-=1;j+=2
    else:j+=1
   comments.append(s[i:j]);i=j;continue
  raw=re.match(r'(?:br|cr|r)(#*)"',s[i:])
  if raw:
   end='"'+raw[1];j=s.index(end,i+raw.end())+len(end);v=s[i:j];tokens.append(v);literals.append(v);i=j;continue
  quoted=re.match(r'(?:b|c)?"',s[i:])
  if quoted:
   j=i+quoted.end()
   while s[j]!='"':j+=2 if s[j]=='\\' else 1
   j+=1;v=s[i:j];tokens.append(v);literals.append(v);i=j;continue
  char=re.match(r"(?:b)?'(?:[^\\'\n]|\\(?:[\\'\"nrt0]|x[0-9a-fA-F]{2}|u\{[0-9a-fA-F_]+\}))'",s[i:])
  if char:
   v=char[0];tokens.append(v);literals.append(v);i+=len(v);continue
  word=re.match(r'[A-Za-z_0-9]+',s[i:])
  if word:tokens.append(word[0]);i+=len(word[0]);continue
  tokens.append(s[i]);i+=1
 return tokens,literals,comments
formatting=[]
for p,b in sorted(composed.items()):
 if b==(W/p).read_bytes():
  formatting.append({'path':p,'composed_sha256':hashlib.sha256(b).hexdigest(),'current':bind(W/p),'literal_and_comment_vectors_exact':True,'formatting_only':False,'token_hunks':[],'check':'whole-file bytes exact'})
  continue
 a=b.decode();z=(W/p).read_text();ta,la,ca=lex(a);tz,lz,cz=lex(z);assert la==lz and ca==cz,p
 hunks=[]
 for op,ai,aj,bi,bj in ([] if ta==tz else difflib.SequenceMatcher(None,ta,tz,autojunk=False).get_opcodes()):
  if op!='equal':hunks.append({'kind':op,'before':ta[ai:aj],'after':tz[bi:bj],'before_context':[ta[max(0,ai-5):ai],ta[aj:aj+5]],'after_context':[tz[max(0,bi-5):bi],tz[bj:bj+5]]})
 for h in hunks:
  assert all(t in ',{}' for t in h['before']+h['after']), (p,h)
 # The only braces introduced are wrappers around the two assignment-only match arms.
 if any('{' in h['after'] for h in hunks):
  assert p=='src/script/promises/try_quota_tests.rs'
  for arm,nextarm in [('3','4'),('4','5')]:
   starts=[i for i in range(len(tz)-3) if tz[i:i+4]==[arm,'=','>','{']];assert len(starts)==1
   start=starts[0]+3;j=start+1;depth=1
   while depth:
    if tz[j]=='{':depth+=1
    if tz[j]=='}':depth-=1
    j+=1
   assert tz[j]==nextarm and ';' not in tz[start+1:j-1]
   tz=tz[:start]+tz[start+1:j-1]+[',']+tz[j:]
 def no_trailing(t):return [v for i,v in enumerate(t) if not(v==',' and i+1<len(t) and t[i+1] in [')',']','}'])]
 assert no_trailing(ta)==no_trailing(tz),p
 formatting.append({'path':p,'composed_sha256':hashlib.sha256(b).hexdigest(),'current':bind(W/p),'literal_count':len(la),'comments_count':len(ca),'literal_and_comment_vectors_exact':True,'formatting_only':b!=(W/p).read_bytes(),'token_hunks':hunks})
# Separately compare every tracked Git blob, with the requested source/build/data roots identified.
raw=subprocess.check_output(['git','-C',str(W),'ls-tree','-rz',BASE]);tracked=[];scope_counts=collections.Counter();changed_git=[]
for record in raw.split(b'\0'):
 if not record:continue
 header,path=record.split(b'\t',1);mode,kind,oid=header.decode().split();p=path.decode();assert kind=='blob'
 f=W/p;data=os.readlink(f).encode() if mode=='120000' else f.read_bytes();actual=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 executable=bool(f.stat().st_mode & stat.S_IXUSR) if mode!='120000' else False
 assert (mode=='100755')==executable,(p,'mode')
 same=actual==oid
 if not same:changed_git.append(p)
 scope=(p.split('/')[0] if p.startswith(('src/','crates/','tools/','tests/','.github/')) else 'Cargo' if p in ['Cargo.toml','Cargo.lock'] else 'other-tracked')
 scope_counts[scope]+=1
 tracked.append({'path':p,'scope':scope,'mode':mode,'base_git_blob':oid,'current_git_blob':actual,'current_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'unchanged':same})
assert set(changed_git)==changed
untracked=subprocess.check_output(['git','-C',str(W),'ls-files','--others','--exclude-standard','-z']).split(b'\0');untracked={p.decode() for p in untracked if p};assert untracked==added,untracked
all_diff=set(subprocess.check_output(['git','-C',str(W),'diff','--name-only',BASE]).decode().splitlines());assert all_diff==changed
(O/'tracked-census.json').write_text(json.dumps({'base':BASE,'scope_counts':dict(scope_counts),'tracked_blobs':len(tracked),'changed_tracked':sorted(changed_git),'new_untracked':sorted(untracked),'files':tracked},indent=2)+'\n')
(O/'composition-and-format.json').write_text(json.dumps({'base':BASE,'candidate':bind(D/'source-candidate-1.json'),'final':bind(D/'source-final.json'),'map_equality':True,'production_inverses':inverses,'files':formatting},indent=2)+'\n')
summary={'selected_inputs':1778,'changed_existing':24,'new_modules':3,'unmodified_selected':1751,'tracked_blobs':len(tracked),'scope_counts':dict(scope_counts),'changed_paths':27,'formatted_paths':[r['path'] for r in formatting if r['formatting_only']],'literal_vectors_exact':True,'comments_exact':True,'old_production_inverse_exact':True,'all_other_tracked_blobs_exact':True}
(O/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');print(json.dumps(summary,indent=2))
