"""Independent documentation peer; stdlib/read-only Git, no project execution."""
from collections import Counter
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

D = Path('/tmp/eris-promise-try-runtime-plan-1')
R = D / 'documentation-review-1'
W = D / 'worktree'
BASE = '7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
bindings = {}

def read(path):
    path = Path(path)
    data = path.read_bytes()
    bindings[str(path)] = dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
    return data

def load(path):
    return json.loads(read(path))

def bound(row):
    data = read(row['path'])
    assert len(data) == row['bytes'], row
    assert hashlib.sha256(data).hexdigest() == row['sha256'], row
    return data

def verify_bindings(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            bound(value)
        for child in value.values():
            verify_bindings(child)
    elif isinstance(value, list):
        for child in value:
            verify_bindings(child)

def git_before(path):
    return subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + path])

seal_path = D / 'documentation-1/source-ready.json'
seal = load(seal_path)
assert bindings[str(seal_path)]['sha256'] == 'ed2892d83165919267a5787998498a86d8240576d42e0138ac5ed8d77bb270d9'
verify_bindings(seal)
assert seal['base'] == BASE
expected = ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/SECURITY.md', 'docs/VALIDATION.md', 'docs/promise-try.md']
assert [row['relative_path'] for row in seal['files']] == expected
assert sorted(p.relative_to(D / 'documentation-1/raw').as_posix() for p in (D / 'documentation-1/raw').rglob('*') if p.is_file()) == sorted(expected)
doc_rows = []
raws = {}
for row in seal['files']:
    rel = row['relative_path']
    raw = bound(row['raw'])
    before = bound(row['before']) if row['before'] else b''
    patch = bound(row['diff'])
    if row['before']:
        assert before == git_before(rel), rel
    else:
        names = subprocess.check_output(['git', '-C', str(W), 'ls-tree', '--name-only', BASE, '--', rel])
        assert names == b''
    # Recreate the held unified diff with its recorded headers, then independently
    # invert the disjoint changed spans derived directly from before/raw text.
    headers = patch.decode().splitlines()
    exact = ''.join(difflib.unified_diff(before.decode().splitlines(True), raw.decode().splitlines(True), fromfile=headers[0][4:], tofile=headers[1][4:])).encode()
    assert exact == patch, rel
    old_lines, new_lines = before.decode().splitlines(True), raw.decode().splitlines(True)
    ops = difflib.SequenceMatcher(None, old_lines, new_lines, autojunk=False).get_opcodes()
    restored = list(new_lines)
    changed = []
    for tag, a, b, c, d in reversed(ops):
        if tag != 'equal':
            changed.append(dict(operation=tag, old_lines=[a,b], new_lines=[c,d]))
            restored[c:d] = old_lines[a:b]
    assert ''.join(restored).encode() == before
    doc_rows.append(dict(path=rel, parent_git_exact=bool(row['before']), new_file=not bool(row['before']), exact_diff=True, inverse_exact=True, change_spans=list(reversed(changed))))
    raws[rel] = raw

old_validation = git_before('docs/VALIDATION.md')
title, suffix = old_validation.split(b'\n', 1)
assert raws['docs/VALIDATION.md'].startswith(title + b'\n')
assert raws['docs/VALIDATION.md'].endswith(suffix)
assert raws['docs/VALIDATION.md'].count(suffix) == 1
chapter = bound(seal['historical_chapter'])
assert chapter == git_before('docs/promise-with-resolvers.md') == read(W / 'docs/promise-with-resolvers.md')

ledger = load(D / 'root/final-validation.json')
assert bindings[str(D / 'root/final-validation.json')]['sha256'] == '954e5cdb2e1766bd6ae42792aa9becb2b6bbb70a38815a152c1b952382df358b'
verify_bindings(ledger)
assert ledger['status'] == 'pass' and ledger['base'] == BASE
assert len(ledger['checks']) == 17
for check in ledger['checks']:
    receipt = json.loads(bound(check['receipt']))
    assert receipt['exit'] == check['exit']
    assert receipt['sha256'] == hashlib.sha256(bound(check['log'])).hexdigest()
    assert check['exit'] == (101 if check['label'] == 'try-parent-public-1' else 0)

source_candidate = load(D / 'source-candidate-1.json')
source_final = load(D / 'source-final.json')
assert source_candidate['base'] == source_final['base'] == BASE
assert source_candidate['source_sha256'] == source_final['source_sha256']
assert len(source_final['source_sha256']) == 1778
assert {k for k in source_candidate if source_candidate[k] != source_final[k]} == {'scope'}

modules = {
    'script::try_semantics_tests::': D / 'public-contract-1/raw/src/script/try_semantics_tests.rs',
    'script::try_abort_tests::': D / 'public-contract-1/raw/src/script/try_abort_tests.rs',
    'script::promises::try_quota_tests::': D / 'private-contract-1/raw/src/script/promises/try_quota_tests.rs',
}
added = Counter()
for prefix, path in modules.items():
    names = re.findall(r'#\[test\]\s*fn\s+(\w+)\s*\(', read(path).decode())
    added.update(prefix + name for name in names)
assert sum(added.values()) == 25 and len(added) == 25

def outcomes(path):
    text = read(path).decode()
    rows = re.findall(r'^test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text, re.M)
    passed = Counter(re.findall(r'^test (\S+) \.\.\. ok$', text, re.M))
    failed = Counter(re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.M))
    return text, rows, passed, failed

focus, rows, passed, failed = outcomes(D / 'validation/try-candidate-focused-1.log')
assert passed == added and not failed and len(rows) == 1 and list(map(int, rows[0])) == [25,0,0,0,2881]
parent, parent_rows, parent_passed, parent_failed = outcomes(D / 'validation/try-parent-public-1.log')
public_names = Counter({k:v for k,v in added.items() if '::promises::' not in k})
assert not parent_passed and parent_failed == public_names and sum(parent_failed.values()) == 15
assert ledger['startup']['raw_line'] in focus
assert ledger['startup']['work'] == 101580 and ledger['startup']['remaining'] == 898420 and ledger['startup']['accounted_heap'] == 1775866
parent_startup = load(D / 'root/parent-startup-observation.json')
assert ledger['startup']['work'] - parent_startup['work'] == 268
assert ledger['startup']['accounted_heap'] - parent_startup['accounted_heap'] == 7595

renames = load(D / 'migrations-1/source-ready.json')['renames']
assert len(renames) == 4
full_runs = []
for name, total in [('default-full-1',3246),('host-vulkan-full-1',3600)]:
    text, rows, passed, failed = outcomes(D / 'validation' / (name + '.log'))
    _, _, old_passed, old_failed = outcomes(D / 'rust-parent' / (name + '.log'))
    assert not failed and not old_failed
    totals = [sum(int(row[i]) for row in rows) for i in range(5)]
    assert len(rows) == 52 and totals == [total,0,0,0,0]
    assert sum(passed.values()) == total and sum(old_passed.values()) == total - 25
    for rename in renames:
        matches = [key for key in old_passed if key.endswith('::' + rename['before'])]
        assert len(matches) == 1
        key = matches[0]
        old_passed[key[:-len(rename['before'])] + rename['after']] = old_passed.pop(key)
    assert passed == old_passed + added
    full_runs.append(dict(name=name, groups=total, result_rows=52, parent_plus_25_and_four_renames_exact=True))

profiles = []
for row in ledger['profiles']['profiles']:
    name = row['name']
    path = D / ('upstream-' + name + '-1.json')
    report, old = load(path), load(D / 'replay-parent' / path.name)
    assert bindings[str(path)]['sha256'] == row['sha256']
    fields = ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','mode_cases']
    assert all(report[field] == old[field] for field in fields), name
    assert len(report['cases']) == row['cases'] and len(report['harness_preflight']) == row['controls']
    assert Counter(case['status'] for case in report['cases']) == Counter(row['counts'])
    assert report['harness_preflight_passed'] and all(control['verified'] is True for control in report['harness_preflight'])
    assert not report['regressions'] and not report['improvements']
    assert report['binary_sha256'] == row['binary_sha256']
    profiles.append(dict(name=name, cases=row['cases'], controls=row['controls'], counts=row['counts'], compared_fields=fields))
assert sum(row['cases'] for row in profiles) == 1300
assert sum(row['controls'] for row in profiles) == 546
for binary in ledger['binaries']:
    data = read(binary['binary'])
    assert len(data) == binary['bytes'] and hashlib.sha256(data).hexdigest() == binary['sha256']
    assert binary['source_sha256'] == bindings[str(D / 'source-candidate-1.json')]['sha256']
    build = load(binary['build'])
    assert build['exit'] == 0 and '+1.88.0' in build['command'] and '--release' in build['command']

public_roster = load(D / 'public-contract-1/roster.json')
private_roster = load(D / 'private-contract-1/roster.json')
public_calls = 14 * 2 * 2 + 12 * 2 * 3 + 3 * 2 * 2
assert public_calls == 140 == public_roster['planned_public_execute_calls']
assert sum(row['measured_attempts'] for row in private_roster['per_group']) == 78
assert private_roster['sticky_checkpoint_readbacks'] == 4

prior_ci = load(D / 'root/prior-ci-observation-1.json')
assert prior_ci['headSha'] == BASE and prior_ci['conclusion'] == 'success'
assert len(prior_ci['jobs']) == 11 and all(job['conclusion'] == 'success' for job in prior_ci['jobs'])

for rel in ['root/spec-observation-1.json','public-readiness-1/primary-observation.json','root/selection-1.json','accounting-proposal-1/contract.json','accounting-proposal-1/ownership-proof.json','accounting-proposal-1/error-materialization.json','source-final-review-1/review.json','root/source-scope-qualification.json','root/format-check-orchestration.json']:
    load(D / rel)

planned_links = set(seal['evidence_destinations'])
link_rows = []
for rel, raw in raws.items():
    # Only added text is in review scope; historical links remain unchanged.
    before = git_before(rel) if rel != 'docs/promise-try.md' else b''
    changed = [line[1:] for line in difflib.unified_diff(before.decode().splitlines(), raw.decode().splitlines()) if line.startswith('+') and not line.startswith('+++')]
    for target in re.findall(r'\]\(([^)]+)\)', '\n'.join(changed)):
        if target.startswith(('https://','http://','#')):
            continue
        path = (Path(rel).parent / target).as_posix()
        assert path in planned_links or path in raws or (W / path).is_file(), (rel,target)
        link_rows.append(dict(document=rel,target=target,planned_evidence=path in planned_links))

result = dict(status='clear', base=BASE, files=doc_rows,
    history=dict(validation_prior_body_exact=True, with_resolvers_chapter_exact=True),
    selected_inventory=dict(count=1778,candidate_final_only_scope_diff=True,complete_build_graph_claim=False),
    focused=dict(parent_public_failures=15,candidate_first_pass_groups=25,public_execute_calls=140,private_measured_attempts=78,private_sticky_readbacks=4),
    full_runs=full_runs, profiles=profiles, case_total=1300, control_total=546,
    startup=ledger['startup'], links=link_rows,
    qualification='Static review of retained root-run evidence; no project execution, live edit, or independent hardware/performance/security claim.',
    bindings=sorted(bindings.values(),key=lambda row:row['path']))
with (R / 'checks.json').open('x') as out:
    json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({'status':result['status'],'files':len(doc_rows),'full_runs':full_runs,'cases':1300,'controls':546,'bindings':len(bindings)}))
