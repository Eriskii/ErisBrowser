"""Write a source-only public test proposal; no JavaScript/Rust payload or execution."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess

D=Path('/tmp/eris-promise-try-runtime-plan-1')
O=Path(__file__).parent
W=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1/worktree')
BASE='dbbb86c0b3330bbe3bd5213896f2460cedfa02d0'

def bind(p):
    p=Path(p); data=p.read_bytes()
    return {'path':str(p),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}

def write(name,obj):
    p=O/name
    assert not p.exists(),p
    p.write_text(json.dumps(obj,indent=2)+'\n')
    return bind(p)

published=[]
for rel in ['src/script.rs','src/script/promises/semantics.rs','src/script/microtasks.rs',
            'src/script/with_resolvers_semantics_tests.rs','src/script/with_resolvers_abort_tests.rs',
            'src/script/promise_semantic_tests.rs','src/script/promise_any_abort_tests.rs']:
    raw=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
    assert raw==(W/rel).read_bytes(),rel
    h=hashlib.sha256(raw).hexdigest()
    inherited=D/'readiness-1/parent'/rel
    if inherited.exists(): assert hashlib.sha256(inherited.read_bytes()).hexdigest()==h
    if 'with_resolvers_' in rel:
        p=O/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(raw)
        retained=str(p)
    else:retained=str(inherited if inherited.exists() else W/rel)
    published.append({'relative_path':rel,'base':BASE,'bytes':len(raw),'sha256':h,
                      'git_blob_sha1':hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest(),
                      'read_source':retained})

spec=write('primary-observation.json',{
 'observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'source':'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise.try',
 'related':['https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-promise-resolve',
            'https://tc39.es/ecma262/multipage/control-abstraction-objects.html#sec-newpromisecapability',
            'https://tc39.es/ecma262/multipage/ecmascript-standard-built-in-objects.html#sec-ecmascript-standard-built-in-objects'],
 'edition_observed':'ECMAScript 2027 current draft; Promise.try section 27.5.4.8',
 'method':'Independent browser read of official current algorithm and related operations. No pinned upstream commit or raw-page snapshot is claimed.',
 'paraphrase':'The receiver must be an object before the callback runs. The callback receives undefined this and the tail arguments. Ordinary callback failure enters capability construction and rejection; normal completion enters PromiseResolve. Genuine Promise constructor equality may return the original object before constructor validation. Later getter, constructor or settler failures propagate from their own stages.',
 'host_boundary':'Unsupported/resource-limit suspension is existing local host policy, not an ECMAScript Promise.try rejection rule.',
 'version_risk':'Recheck the official algorithm before final implementation selection; an older capability-first recipe has different observables.'})

ordinary=[
 {'id':'metadata_cached_alias_nonconstruction','phases':1,
  'scenario':'Capture the installed method twice, inspect owner and function metadata, then mutate configurable name/length through one alias. Exercise detached/bound dynamic receivers and both new and Reflect.construct refusal.',
  'discriminator':'Same cached function identity; name try, length 1; standard descriptor flags, Function.prototype, no own prototype. Metadata mutation is shared by aliases and a fresh strict-mode runtime starts with original metadata. Construction refuses before callback entry.',
  'readiness':['metadata-and-isolation','saved-receiver-mutation']},
 {'id':'receiver_guard_and_late_constructor_validation','phases':1,
  'scenario':'Table of supported primitives (undefined/null/boolean/number/string/symbol), then plain-object and arrow-function receivers. Mark tail-argument evaluation separately from callback entry; cover normal and throwing callback under nonconstructors.',
  'discriminator':'Argument expressions have already run at call entry. Primitive receiver produces synchronous TypeError without callback entry. Object nonconstructor runs callback first, then produces capability TypeError for either normal non-Promise result or ordinary callback throw.',
  'readiness':['receiver-before-callback']},
 {'id':'generic_normal_callback_before_constructor','phases':1,
  'scenario':'Callback returns an identity token; custom C captures strict resolver/rejector functions and returns an unrelated object as its capability promise.',
  'discriminator':'FCR order: callback, constructor, resolve. Resolve is called once with undefined this, one exact token argument; reject stays unused. Method returns the exact arbitrary capability object, ignoring resolver return.',
  'readiness':['callback-before-construction']},
 {'id':'callback_throw_constructor_and_reject_precedence','phases':1,
  'scenario':'Object and primitive callback throws; normal custom rejection; constructor throws a second token; reject throws a third token. Use separate counters and fresh constructor fixtures within the group.',
  'discriminator':'FCJ on normal rejection, preserving the original reason and undefined reject this. A constructor throw replaces the callback reason at FC. A reject throw escapes once after FCJ, with no retry or resolve call. Normal reject return is ignored.',
  'readiness':['ordinary-throw-precedence']},
 {'id':'genuine_identity_before_constructor_check','phases':1,
  'scenario':'Return precreated pending, fulfilled and handled-rejected genuine Promises. Match constructor with the intrinsic P, a plain nonconstructor object and a nonconstructible arrow; use one observable constructor getter.',
  'discriminator':'Exact input Promise identity is returned; getter once after F (FG). No new C/resolve/reject call is required, including nonconstructor matches. Attach rejection handling before replacing constructor; do not attach new then handlers while it is poisoned.',
  'readiness':['genuine-identity-bypass']},
 {'id':'genuine_constructor_getter_mismatch_and_throw','phases':1,
  'scenario':'A genuine Promise constructor getter returns a different C, or throws a token. Pair the throwing getter with both valid and nonconstructor receiver objects.',
  'discriminator':'Mismatch proceeds FGCR and passes the exact Promise to the custom resolver. Throwing getter yields FG then synchronous exact-token failure; reject is unused and getter failure precedes later nonconstructor TypeError.',
  'readiness':['constructor-getter-normal-path']},
 {'id':'invalid_callback_and_capability_capture','phases':1,
  'scenario':'Missing, null and object callbacks under valid C; absent or noncallable capability callbacks; constructor captures then throws. Use strict custom reject to inspect received TypeError without relying on a diagnostic string.',
  'discriminator':'Bad callback is an ordinary callback completion routed through C then reject. Invalid capability capture instead throws after C with no settler call. A constructor throw after capture still escapes. Keep existing executor reentry suite rather than duplicate it.',
  'readiness':['missing-and-noncallable-callback','ordinary-throw-precedence']},
 {'id':'exact_this_tail_arguments_and_evaluation_order','phases':1,
  'scenario':'Zero, one and several tail arguments including object, function, symbol, undefined and signed zero; strict callback and bound strict callback; mark evaluation of each argument before invocation.',
  'discriminator':'Exact arguments.length/order/reference identity; ordinary strict callback this is undefined, bound callback retains its bound this/arguments. The helper neither turns the tail into a JS array nor performs indexed author Gets.',
  'readiness':['argument-and-this-forwarding']},
 {'id':'normal_resolve_abrupt_is_not_callback_rejection','phases':1,
  'scenario':'Custom resolver first returns a sentinel and then in a separate fixture throws a token; give reject an observable side effect/throw if incorrectly invoked.',
  'discriminator':'Normal return still yields the capability object. Resolver throw escapes synchronously after FCR exactly once; reject is never invoked. Distinguishes catch-around-the-entire-body from catch-of-callback-only.',
  'readiness':['normal-resolve-abrupt']},
 {'id':'fake_brand_and_thenable_getter_boundary','phases':1,
  'scenario':'Fake Promise-prototype object with poisoned constructor getter under generic C; regular thenable under intrinsic P; separate ordinary thenable whose then getter throws. Read each trace independently.',
  'discriminator':'Fake has no identity shortcut or constructor Get: FCR with exact fake passed to resolve. Regular then getter runs synchronously once (FG); then invocation is a later job with the thenable receiver and first-settlement wins. Throwing then getter produces a rejected Promise and later exact-reason handler, unlike group 6 synchronous constructor-getter throw.',
  'trace_plan':'Regular thenable: sync FGE, post-drain FGETQV when T resolves before a previously queued Q and reaction V. Throwing getter: sync FGE, post-drain FGEJ. These are proposed traces to freeze with the actual source ordering.',
  'readiness':['thenable-and-fake-brand']},
 {'id':'genuine_pending_deferred_and_handled_jobs','phases':3,
  'scenario':'Phase 1 returns a precreated pending Promise unchanged and queues a sentinel. Phase 2 settles it externally. Phase 3 creates ordinary fulfilled and rejected try results with handlers attached before checkpoint.',
  'discriminator':'Callback executes synchronously, handlers drain only at the host checkpoint. Exact fulfillment/rejection identities are checked; no unhandled-rejection artifact is needed.',
  'trace_plan':['Phase 1 sync SFE; post-drain SFEQ.', 'Phase 2 sync SFEQAB; post-drain SFEQABV.', 'Independent phase-3 jobs variable: sync SFTE; post-drain SFTEVJQ.'],
  'readiness':['intrinsic-settlement']},
 {'id':'captured_receiver_and_poisoned_lookup_bypass','phases':1,
  'scenario':'Save P and try, poison C.resolve and C[Symbol.species], replace global Promise inside the callback, and mutate a later custom C.prototype before construction. Use saved Object helpers and a normal custom constructor.',
  'discriminator':'Captured receiver remains the original object; static resolve/species/global replacements are not consulted. Post-callback C.prototype mutation is visible to ordinary construction. Assert absence of poison counters before any unrelated then call and restore descriptors before later handler attachment.',
  'readiness':['saved-receiver-mutation','thenable-and-fake-brand']}
]

terminal=[
 {'id':'callback_terminal_direct_and_queued',
  'placements':[{'entry':'direct','stage':'callback','prefix':'F'}, {'entry':'queued','stage':'callback','prefix':'SF'}],
  'forbidden':'Capability constructor, resolve/reject, author catch/finally/continuation and later queue sentinel.',
  'purpose':'Neither direct callback fatal completion nor callback fatal completion reached while draining becomes ordinary rejection.'},
 {'id':'constructor_and_genuine_constructor_getter_terminal',
  'placements':[{'entry':'direct','stage':'capability constructor after normal callback','prefix':'FC'},
                {'entry':'direct','stage':'genuine Promise constructor getter after normal callback','prefix':'FG'}],
  'forbidden':'Later capture/resolve/reject, author catch/finally/continuation and queue sentinel.',
  'purpose':'Normal callback effects survive a later fatal failure; getter path remains separate from capability construction.'},
 {'id':'resolver_and_rejector_terminal',
  'placements':[{'entry':'direct','stage':'resolve after normal callback','prefix':'FCR'},
                {'entry':'direct','stage':'reject after ordinary callback throw','prefix':'FCJ'}],
  'forbidden':'Second settler call/retry, author catch/finally/continuation and queue sentinel.',
  'purpose':'Both chosen settler branches propagate fatal status once and suspend outstanding author jobs.'}
]
assert len(ordinary)==12 and len(terminal)==3
assert sum(x['phases'] for x in ordinary)==14
matrix=write('matrix.json',{
 'status':'proposed source scenarios only; no executable literals, Rust module or observed results',
 'ordinary':ordinary,'terminal':terminal,
 'terminal_variants':{'resource':'Existing finite author work limit reached by a loop at the named stage; no manually assigned counter.',
                      'unsupported':'Existing eval call at the named stage, not unsupported syntax that fails before the intended effect.',
                      'public_checks':'Assert actual Rust error classification first, then sticky microtasks_suspended, exact counters/prefix and two repeated public readbacks; no manual queue/budget reset. Each terminal family includes a separate fresh-runtime ordinary queue preservation control.'},
 'planned_counts':{'groups':15,'ordinary_groups':12,'terminal_groups':3,'group_mode_pairs':30,
                   'modes':['sloppy','strict'],'ordinary_case_mode_instances':24,'ordinary_source_phases_per_mode':14,
                   'ordinary_source_phase_executions':28,'ordinary_post_checkpoint_readbacks':28,
                   'terminal_placements':6,'terminal_sources_after_resource_unsupported_pairing':12,
                   'terminal_case_mode_instances':24,'terminal_failing_entries':24,'terminal_post_failure_readbacks':48,
                   'fresh_queue_preservation_mode_instances':6,
                   'qualification':'Prospective scaffold counts, not invocation/assertion totals or observed passes. Exact literal/operation roster must be frozen after selection; table variants within an ordinary group are not extra Rust groups.'},
 'deferred_private_scope':['Exact borrowed-tail work/heap refusal and logical/physical allocation cuts.',
                           'Post-callback allocation refusal coupled to terminal state, using selected private fees.',
                           'No public guessed heap total or allocator-capacity assertion.']})

conventions=write('conventions.json',{
 'published_base':BASE,
 'semantic_helper':'Use the published withResolvers observe/execute_mode pattern: fresh Runtime per sloppy/strict case, source phase followed by separate observation expression in the same Runtime. Place synchronous assertions in source before its checkpoint.',
 'fatal_helper':'Use the existing fatal_stop pattern: classify the returned ScriptError before readbacks, then two same-runtime observations and sticky queue checks, followed by a separate fresh Runtime queue preservation check.',
 'work_reset_qualification':'No explicit test reset. The existing public execute_program entry replenishes author work normally; sticky suspension must still prevent queued jobs from resuming across those entries.',
 'parent_absence':'Every eventual source needs an explicit Promise.try presence guard outside ordinary JS catches. The absent method must not produce incidental passing TypeError rows. Parent fatal groups must fail classification before any readback if the guard produces an ordinary error.',
 'fixture_discipline':['Use ordinary functions/arrows and existing Reflect/Object APIs; no class, Proxy, realms, BigInt or new syntax prerequisite.',
                       'Precreate callbacks and fixtures before measuring phase-specific side effects.',
                       'Use strict ordinary callbacks/settlers to observe undefined this in both outer modes; arrows cannot test dynamic this.',
                       'Bind callback/reason/object identity, not serialized error diagnostics.',
                       'Constructor/species poison can affect test-authored then calls. Pre-attach handlers or restore properties before reading deferred results.',
                       'An accessor descriptor used after poisoning Object.prototype must have a null prototype or explicit safe own fields; avoid inherited mixed descriptors.',
                       'Keep generic constructor fixtures separate from genuine Promise fixtures; arbitrary returned object identity is valid capability behavior.'],
 'sources':published})

review=write('review.json',{
 'status':'clear readiness audit with bounded coverage refinements; selection pending',
 'base':BASE,
 'readiness':bind(D/'readiness-1/source-ready.json'),
 'readiness_matrix':bind(D/'readiness-1/test-matrix.json'),
 'root_spec_observation':bind(D/'root/spec-observation-1.json'),
 'primary_observation':spec,'matrix':matrix,'conventions':conventions,
 'findings':[],
 'refinements':['Explicitly discriminate genuine Promise constructor-getter failure from ordinary thenable.then getter rejection.',
                'Treat primitive-receiver-before-callback as method-entry order; argument evaluation precedes method entry.',
                'Test genuine identity against a nonconstructor receiver before IsConstructor; pair a fake Promise-prototype object to prevent duck-typing shortcuts.',
                'Do not let test-authored then handlers trigger poisoned constructor/species getters and invalidate the intended oracle.',
                'Separate later constructor/resolve/reject abrupts from the callback completion catch; no retry is introduced.',
                'Cover both direct and queued callback fatal entry with the inherited suspension policy, separately from language-level rejections.'],
 'scope':'Source-only behavioral proposal. No implementation, exact executable literal/test payload, fee selection, project import, engine/compiler/test execution, live edit, network mutation or C-directory write.',
 'unresolved':['Root semantic/fee selection remains pending.',
               'Exact JS source bytes, readback literals and operation roster require a later frozen test hold.',
               'No Promise.try upstream corpus/version compatibility or result is inferred from this current-draft review.']})

seal=write('source-ready.json',{'status':'source-only public readiness sealed; not executable tests',
 'base':BASE,'files':[spec,matrix,conventions,review,bind(__file__)],
 'prospective_groups':15,'ordinary_groups':12,'terminal_groups':3,
 'scope':'Independent official-spec and published-source audit; original readiness and prior checkpoints untouched.'})
print(json.dumps(seal))
