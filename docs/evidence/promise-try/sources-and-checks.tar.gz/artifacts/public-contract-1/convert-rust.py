"""Convert the frozen literal contract to Rust text; no project import or execution."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import subprocess

D=Path('/tmp/eris-promise-try-runtime-plan-1')
O=Path(__file__).parent
W=D/'worktree'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'

def bind(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def save(name,text):
    p=O/name;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(text);return bind(p)

def js(s):
    assert '"###' not in s
    return 'r###"'+s+'"###'

def rs(s):return json.dumps(s,ensure_ascii=False)

seal=json.loads((O/'literals-ready.json').read_bytes())
assert bind(O/'literals-ready.json')['sha256']=='4fa8dcf48432897583cc1e764c07e9e7909064f0b8f2a3ed943a8835caf5cee4'
for item in seal['payloads']+[seal[k] for k in ['semantic','terminal','preservation','roster']]:assert bind(item['path'])==item
groups=json.loads((O/'semantic-cases.json').read_bytes())
terminal=json.loads((O/'terminal-cases.json').read_bytes())
preservation=json.loads((O/'terminal-preservation.json').read_bytes())
roster=json.loads((O/'roster.json').read_bytes())
parent=json.loads((D/'source-parent.json').read_bytes())['source_sha256']

helper='''//! Promise.try public contracts, frozen independently before production.
use super::*;

fn execute_mode(
    runtime: &mut Runtime,
    document: &mut Document,
    strict: bool,
    source: &str,
) -> Result<Value> {
    if strict {
        runtime.execute_strict(source, document)
    } else {
        runtime.execute(source, document)
    }
}

fn observe(case_id: &str, phases: &[(&str, &str, Value)]) {
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        for (phase, (source, expression, expected)) in phases.iter().enumerate() {
            execute_mode(&mut runtime, &mut document, strict, source).unwrap_or_else(|error| {
                panic!("{case_id} strict={strict} phase={phase} source: {error:?}")
            });
            let observed = execute_mode(&mut runtime, &mut document, strict, expression)
                .unwrap_or_else(|error| {
                    panic!("{case_id} strict={strict} phase={phase} observation: {error:?}")
                });
            assert_eq!(&observed, expected, "{case_id} strict={strict} phase={phase}");
        }
    }
}
'''
semantic_text=helper
semantic_strings=[]
for group in groups:
    semantic_text+='\n#[test]\nfn '+group['rust_test']+'() {\n    observe(\n        '+rs(group['id'])+',\n        &[\n'
    for p in group['phases']:
        assert p['expected']['type']=='string'
        semantic_text+='            (\n                '+js(p['source'])+',\n                '+js(p['observation'])+',\n                Value::String('+rs(p['expected']['value'])+'.into()),\n            ),\n'
        semantic_strings += [p['source'],p['observation']]
    semantic_text+='        ],\n    );\n}\n'
assert re.findall(r'r###"(.*?)"###',semantic_text,re.S)==semantic_strings

fatal_helper=helper[:helper.index('fn observe(')]+'''fn fatal_stop(cases: &[(&str, bool, &str, &str)], expression: &str) {
    for &(case_id, unsupported, source, expected) in cases {
        for strict in [false, true] {
            let mut runtime = Runtime::try_new().unwrap();
            let mut document = Document::parse("");
            let error = execute_mode(&mut runtime, &mut document, strict, source).unwrap_err();
            assert_eq!(error.is_unsupported(), unsupported, "{case_id} strict={strict}: {error:?}");
            assert_eq!(error.is_resource_limit(), !unsupported, "{case_id} strict={strict}: {error:?}");
            assert!(runtime.microtasks_suspended(), "{case_id} strict={strict}");
            for _ in 0..2 {
                let observed = execute_mode(&mut runtime, &mut document, strict, expression).unwrap();
                assert_eq!(observed, Value::String(expected.into()), "{case_id} strict={strict}");
                assert!(runtime.microtasks_suspended());
                assert!(runtime.console.is_empty());
            }
        }
    }
    // Ordinary queued work still drains in a fresh Runtime. Suspended runtimes
    // above are never manually reset or used for this preservation control.
    for strict in [false, true] {
        let mut runtime = Runtime::try_new().unwrap();
        let mut document = Document::parse("");
        execute_mode(&mut runtime, &mut document, strict, '''+js(preservation['source'])+''').unwrap();
        let observed = execute_mode(&mut runtime, &mut document, strict, '''+js(preservation['observation'])+''').unwrap();
        assert_eq!(observed, Value::String('''+rs(preservation['expected'])+'''.into()));
        assert!(!runtime.microtasks_suspended());
    }
}
'''
fatal_text=fatal_helper
fatal_strings=[preservation['source'],preservation['observation']]
for group in terminal:
    observation=group['cases'][0]['observation']
    assert all(c['observation']==observation for c in group['cases'])
    fatal_text+='\n#[test]\nfn '+group['rust_test']+'() {\n    fatal_stop(\n        &[\n'
    for case in group['cases']:
        flag='true' if case['kind']=='unsupported' else 'false'
        fatal_text+='            (\n                '+rs(case['id'])+',\n                '+flag+',\n                '+js(case['source'])+',\n                '+rs(case['expected']['value'])+',\n            ),\n'
        fatal_strings.append(case['source'])
    fatal_text+='        ],\n        '+js(observation)+',\n    );\n}\n'
    fatal_strings.append(observation)
assert re.findall(r'r###"(.*?)"###',fatal_text,re.S)==fatal_strings

files=[]
for rel,content in [('src/script/try_semantics_tests.rs',semantic_text),('src/script/try_abort_tests.rs',fatal_text)]:
    assert rel not in parent
    raw=save('raw/'+rel,content)
    diff=''.join(difflib.unified_diff([],content.splitlines(True),fromfile='/dev/null',tofile=rel))
    diff_ref=save('diffs/'+rel+'.patch',diff)
    files.append({'relative_path':rel,'before_absent':True,'raw':raw,'diff':diff_ref})
assert re.findall(r'#\[test\]\s*fn (\w+)',semantic_text)==roster['semantic_roster']
assert re.findall(r'#\[test\]\s*fn (\w+)',fatal_text)==roster['terminal_roster']
assert all(name.startswith('promise_try_') for name in roster['semantic_roster']+roster['terminal_roster'])

# Source-only feasibility joins. Git is read-only; no parser/compiler is run.
sources=[]
for rel in ['src/script.rs','src/script/with_resolvers_semantics_tests.rs','src/script/with_resolvers_abort_tests.rs',
            'src/script/promise_semantic_tests.rs','src/script/promises/semantics.rs','src/script/microtasks.rs',
            'src/script/parser.rs','src/script/parser/driver/expressions.rs']:
    data=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
    h=hashlib.sha256(data).hexdigest();assert parent[rel]==h
    p=O/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(data)
    sources.append({'relative_path':rel,'base':BASE,'copy':bind(p)})
parser=(O/'parent/src/script/parser/driver/expressions.rs').read_text()
assert 'if p.eat(".") {\n            let name = p.identifier()?;' in parser
feasibility={
 'status':'source-feasible under existing published APIs and syntax; not an actual parser/compiler execution result',
 'sources':sources,
 'checks':['Both helpers use existing Runtime::try_new, execute/execute_strict, Document::parse, Value::String and terminal predicates.',
           'Existing withResolvers modules prove the same fresh-runtime/per-phase observation and terminal-readback shape.',
           'Published postfix/new_members dot grammar uses identifier() without binding-identifier validation, allowing the reserved property name try.',
           'Ordinary functions, explicit strict directives, arrows, getter descriptors, conditional expressions, new.target, new expression, Reflect.construct, symbols and Object.is are existing syntax/APIs; no new class/Proxy/realm/BigInt prerequisite.',
           'All 14 ordinary and 12 fatal source payloads start with the frozen availability guard. Observations are separate exact readbacks.',
           'No private fields beyond the existing sibling-helper console read; no manual counter/queue reset or private fee assertion.',
           'Public execute_program normally resets author work on entry; sticky suspension is tested across those public readbacks.',
           'Semantic genuine-Promise poison cases do not attach new handlers after constructor/species poisoning; thenable errors and constructor-getter errors remain separate.'],
 'conversion':{'semantic_raw_strings_exact':len(semantic_strings),'terminal_raw_strings_exact':len(fatal_strings),
               'rust_groups':15,'all_prefix_promise_try':True,'literal_changes':0},
 'registration':{'owner':'root','modules':['try_semantics_tests','try_abort_tests'],'edited':False,
                 'instruction':'Root adds separate cfg(test) sibling module declarations in src/script.rs; this hold contains no registration replacement or append file.'}}
f=save('source-checks.json',json.dumps(feasibility,indent=2)+'\n')
ready={'status':'frozen public source payloads ready for independent peer and root parent execution',
 'base':BASE,'files':files,'literals':bind(O/'literals-ready.json'),'roster':bind(O/'roster.json'),
 'source_checks':f,'conversion':bind(__file__),'source_parent':bind(D/'source-parent.json'),
 'public_selection':bind(D/'root/public-selection-1.json'),
 'scope':'Two new modules only; root owns registration/import/execution. No production inspection, project execution, private fee assertions, limits changes or live edits.',
 'parent_prediction':roster['parent_prediction'],'counts':{k:v for k,v in roster.items() if k not in ['semantic_roster','terminal_roster','parent_prediction']}}
out=save('source-ready.json',json.dumps(ready,indent=2)+'\n')
print(json.dumps(out))
