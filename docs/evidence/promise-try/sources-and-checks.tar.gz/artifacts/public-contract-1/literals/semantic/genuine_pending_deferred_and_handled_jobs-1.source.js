if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}

var P=Promise,f=P.try,release,token={},reason={},trace='S';
var pending=new P(function(resolve){release=resolve;});
var returned=f.call(P,function(){trace+='F';return pending;});check(returned===pending);
returned.then(function(v){check(v===token);trace+='V';},function(){trace+='x';});
trace+='E';queueMicrotask(function(){trace+='Q';});check(trace==='SFE');
