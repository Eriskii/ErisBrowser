if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var P=Promise,O=Object,f=P.try,alias=P.try,has=O.prototype.hasOwnProperty;
var d=O.getOwnPropertyDescriptor(P,'try'),n=O.getOwnPropertyDescriptor(f,'name'),l=O.getOwnPropertyDescriptor(f,'length');
check(f===alias&&d.value===f&&d.writable&&!d.enumerable&&d.configurable);
check(n.value==='try'&&!n.writable&&!n.enumerable&&n.configurable);
check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable);
check(O.getPrototypeOf(f)===Function.prototype&&!has.call(f,'prototype'));
var entered=0,caught=0;function callback(){entered++;return 1;}
try{f(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{f.bind(undefined)(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{new f(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{Reflect.construct(f,[callback]);}catch(e){check(e instanceof TypeError);caught++;}
check(caught===4&&entered===0);
O.defineProperty(f,'name',{value:'renamed'});O.defineProperty(f,'length',{value:9});
check(alias===P.try&&alias.name==='renamed'&&alias.length===9);
var p=P.resolve(7),run=alias.bind(P);check(run(function(){entered++;return p;})===p&&entered===1);
var result='metadata:4|alias:true|callback:1';
