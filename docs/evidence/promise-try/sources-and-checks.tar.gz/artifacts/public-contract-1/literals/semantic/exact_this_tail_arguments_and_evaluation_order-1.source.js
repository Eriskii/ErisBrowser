if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,O=Object,object={},fn=function(){},symbol=Symbol('arg'),returned={},holder={},trace='',expected=[],counts=[],seen=[],resolves=0;
O.defineProperty(object,'length',{get:function(){throw new Error('argument length Get');}});
O.defineProperty(object,Symbol.iterator,{get:function(){throw new Error('argument iterator Get');}});
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===returned);trace+='R';resolves++;}
function reject(){throw new Error('unexpected reject');}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
function arg(v){trace+='A';return v;}
function callback(){'use strict';check(this===undefined&&arguments.length===expected.length);trace+='F';counts.push(arguments.length);
 for(var i=0;i<expected.length;i++){check(O.is(arguments[i],expected[i]));}return returned;}
check(f.call(C,callback)===holder&&trace==='FCR');seen.push(trace);
trace='';expected=[object];check(f.call(C,callback,arg(object))===holder&&trace==='AFCR');seen.push(trace);
trace='';expected=[object,fn,symbol,undefined,-0,'tail'];
check(f.call(C,callback,arg(object),arg(fn),arg(symbol),arg(undefined),arg(-0),arg('tail'))===holder&&trace==='AAAAAAFCR');seen.push(trace);
var receiver={},prefix={};
function boundTarget(first,second,third){'use strict';check(this===receiver&&arguments.length===3&&first===prefix&&second===object&&third===symbol);trace+='F';counts.push(arguments.length);return returned;}
var bound=boundTarget.bind(receiver,prefix);trace='';
check(f.call(C,bound,arg(object),arg(symbol))===holder&&trace==='AAFCR');seen.push(trace);
check(resolves===4);var result=counts.join(',')+'|'+seen.join(',');
