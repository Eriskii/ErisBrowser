if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var P=Promise,O=Object,f=P.try,token={},trace='',poisons=0,newPrototype={fresh:true},p=P.resolve(7);
function trap(){poisons++;throw new Error('unrelated lookup');}
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);trace+='R';}
function reject(){throw new Error('unexpected reject');}
function C(ex){check(new.target===original);trace+='C';ex(resolve,reject);this.marker=token;}
var original=C;
O.defineProperty(original,'resolve',{get:trap});O.defineProperty(original,Symbol.species,{get:trap});
O.defineProperty(P,'resolve',{configurable:true,get:trap});O.defineProperty(P,Symbol.species,{configurable:true,get:trap});
var resultObject=f.call(C,function(){
 trace+='F';original.prototype=newPrototype;C={replaced:true};
 Promise=function(){throw new Error('global Promise used');};Object=function(){throw new Error('global Object used');};return token;
});
check(O.getPrototypeOf(resultObject)===newPrototype&&resultObject.marker===token&&trace==='FCR');
check(f.call(P,function(){trace+='F';return p;})===p&&trace==='FCRF'&&poisons===0);
var result=trace+'|'+poisons+'|'+(C!==original);
