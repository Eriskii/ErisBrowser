if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
trace+='A';check(release(token)===undefined);trace+='B';check(trace==='SFEQAB');
