if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var P=Promise,f=P.try,O=Object,fake=O.create(P.prototype),holder={},fakeTrace='',fakeReads=0,token={},reason={},ignored={};
O.defineProperty(fake,'constructor',{get:function(){fakeReads++;throw new Error('fake constructor Get');}});
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===fake);fakeTrace+='R';}
function reject(){throw new Error('fake reject');}
function C(ex){fakeTrace+='C';ex(resolve,reject);return holder;}
check(f.call(C,function(){fakeTrace+='F';return fake;})===holder&&fakeTrace==='FCR'&&fakeReads===0);
var trace='',throwTrace='',thenable={};
function then(resolveValue,rejectValue){'use strict';check(this===thenable&&arguments.length===2);trace+='T';resolveValue(token);rejectValue(reason);resolveValue(ignored);throw ignored;}
O.defineProperty(thenable,'then',{get:function(){trace+='G';return then;}});
var p=f.call(P,function(){trace+='F';return thenable;});check(trace==='FG');
p.then(function(v){check(v===token);trace+='V';},function(){trace+='x';});
trace+='E';queueMicrotask(function(){trace+='Q';});
var bad={};O.defineProperty(bad,'then',{get:function(){throwTrace+='G';throw reason;}});
var rejected=f.call(P,function(){throwTrace+='F';return bad;});check(throwTrace==='FG');
rejected.then(function(){throwTrace+='x';},function(v){check(v===reason);throwTrace+='J';});throwTrace+='E';
check(trace==='FGE'&&throwTrace==='FGE');
