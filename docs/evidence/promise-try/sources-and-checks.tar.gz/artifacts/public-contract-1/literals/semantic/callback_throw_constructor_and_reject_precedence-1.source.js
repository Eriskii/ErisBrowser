if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,reason={},constructorToken={},rejectToken={},holder={},ignored={},trace='',resolves=0,rejects=0,seen=[];
function resolve(){resolves++;trace+='R';}
function reject(v){'use strict';check(this===undefined&&arguments.length===1&&v===reason);rejects++;trace+='J';return ignored;}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
var reasons=[reason,7];
for(var i=0;i<reasons.length;i++){
 reason=reasons[i];trace='';
 var value=f.call(C,function(){trace+='F';throw reason;});
 check(value===holder&&trace==='FCJ');seen.push(trace);
}
function BadC(ex){trace+='C';throw constructorToken;}
trace='';var caught=false;
try{f.call(BadC,function(){trace+='F';throw reason;});}catch(e){check(e===constructorToken);caught=true;}
check(caught&&trace==='FC');seen.push(trace);
function ThrowReject(v){'use strict';check(this===undefined&&arguments.length===1&&v===reason);rejects++;trace+='J';throw rejectToken;}
function RejectC(ex){trace+='C';ex(resolve,ThrowReject);return holder;}
trace='';caught=false;
try{f.call(RejectC,function(){trace+='F';throw reason;});}catch(e){check(e===rejectToken);caught=true;}
check(caught&&trace==='FCJ'&&resolves===0&&rejects===3);seen.push(trace);
var result=seen.join(',')+'|rejects:'+rejects;
