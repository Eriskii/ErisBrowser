if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,holder={},token={},trace='',badCallbacks=0,badCapabilities=0,settlers=0,unexpected=0;
function resolve(){unexpected++;trace+='R';}
function reject(v){'use strict';check(this===undefined&&arguments.length===1&&v instanceof TypeError);settlers++;trace+='J';}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
var callbacks=[undefined,null,{},17];
for(var i=0;i<callbacks.length;i++){
 trace='';var resultObject=i===0?f.call(C):f.call(C,callbacks[i]);
 check(resultObject===holder&&trace==='CJ');badCallbacks++;
}
function Missing(ex){trace+='C';return holder;}
function BadResolve(ex){trace+='C';ex(1,reject);return holder;}
function BadReject(ex){trace+='C';ex(resolve,1);return holder;}
var constructors=[Missing,BadResolve,BadReject];
for(var j=0;j<constructors.length;j++){
 trace='';var caught=false;
 try{f.call(constructors[j],function(){trace+='F';return token;});}catch(e){check(e instanceof TypeError);caught=true;}
 check(caught&&trace==='FC');badCapabilities++;
}
function AfterCapture(ex){trace+='C';ex(resolve,reject);throw token;}
trace='';var captureThrow=false;
try{f.call(AfterCapture,function(){trace+='F';throw 7;});}catch(e){check(e===token);captureThrow=true;}
check(captureThrow&&trace==='FC'&&settlers===4&&unexpected===0);
var result='bad-callbacks:'+badCallbacks+'|bad-capabilities:'+badCapabilities+'|capture-throw:1|settlers:'+settlers;
