if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var P=Promise,f=P.try,O=Object,p=P.resolve(7),other={},holder={},token={},trace='',reads=0,constructors=0,resolves=0,rejects=0,seen=[];
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===p);trace+='R';resolves++;}
function reject(){trace+='J';rejects++;}
function C(ex){trace+='C';constructors++;ex(resolve,reject);return holder;}
O.defineProperty(p,'constructor',{configurable:true,get:function(){reads++;trace+='G';return other;}});
check(f.call(C,function(){trace+='F';return p;})===holder&&trace==='FGCR');seen.push(trace);
O.defineProperty(p,'constructor',{configurable:true,get:function(){reads++;trace+='G';throw token;}});
var receivers=[C,{}];
for(var i=0;i<receivers.length;i++){
 trace='';var caught=false;
 try{f.call(receivers[i],function(){trace+='F';return p;});}catch(e){check(e===token);caught=true;}
 check(caught&&trace==='FG');seen.push(trace);
}
check(reads===3&&constructors===1&&resolves===1&&rejects===0);
var result=seen.join(',')+'|'+reads+'|'+constructors+'|'+resolves+'|'+rejects;
