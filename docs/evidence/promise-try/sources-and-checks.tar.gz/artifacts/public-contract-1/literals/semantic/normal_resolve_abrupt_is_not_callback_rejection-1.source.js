if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,token={},holder={},ignored={},resolveToken={},rejectToken={},fail=false,trace='',resolves=0,rejects=0,seen=[];
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);resolves++;trace+='R';if(fail)throw resolveToken;return ignored;}
function reject(){rejects++;trace+='J';throw rejectToken;}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
check(f.call(C,function(){trace+='F';return token;})===holder&&trace==='FCR');seen.push(trace);
fail=true;trace='';var caught=false;
try{f.call(C,function(){trace+='F';return token;});}catch(e){check(e===resolveToken);caught=true;}
check(caught&&trace==='FCR'&&resolves===2&&rejects===0);seen.push(trace);
var result=seen.join(',')+'|'+resolves+'|'+rejects;
