if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
var jobs='S';
var a=f.call(P,function(){jobs+='F';return token;});
a.then(function(v){check(v===token);jobs+='V';},function(){jobs+='x';});
var b=f.call(P,function(){jobs+='T';throw reason;});
b.then(function(){jobs+='x';},function(v){check(v===reason);jobs+='J';});
jobs+='E';queueMicrotask(function(){jobs+='Q';});check(jobs==='SFTE');
