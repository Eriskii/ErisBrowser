if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,token={},holder={},ignored={},trace='',resolves=0,rejects=0;
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);resolves++;trace+='R';return ignored;}
function reject(){rejects++;trace+='J';}
function C(ex){check(new.target===C&&arguments.length===1&&typeof ex==='function');trace+='C';check(ex(resolve,reject)===undefined);return holder;}
var value=f.call(C,function(){'use strict';check(this===undefined&&arguments.length===0);trace+='F';return token;});
check(value===holder&&trace==='FCR'&&resolves===1&&rejects===0);
var result=trace+'|'+resolves+'|'+rejects;
