if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var f=Promise.try,bad=[undefined,null,true,1,'x',Symbol('x')],trace='',args=0,entered=0,primitive=0,objects=0,token={};
function argument(){args++;trace+='A';return token;}
function callback(){entered++;trace+='F';return 9;}
for(var i=0;i<bad.length;i++){
 trace='';var caught=false;
 try{f.call(bad[i],callback,argument());}catch(e){check(e instanceof TypeError);trace+='T';caught=true;primitive++;}
 check(caught&&trace==='AT'&&entered===0);
}
var nonconstructors=[{},()=>{}];
for(var j=0;j<nonconstructors.length;j++){
 trace='';var normal=false;
 try{f.call(nonconstructors[j],callback,argument());}catch(e){check(e instanceof TypeError);trace+='T';normal=true;objects++;}
 check(normal&&trace==='AFT');
 trace='';var abrupt=false;
 try{f.call(nonconstructors[j],function(){entered++;trace+='F';throw token;},argument());}
 catch(e){check(e instanceof TypeError&&e!==token);trace+='T';abrupt=true;objects++;}
 check(abrupt&&trace==='AFT');
}
check(primitive===6&&objects===4&&entered===4&&args===10);
var result='primitive:'+primitive+'|object:'+objects+'|callbacks:'+entered+'|args:'+args;
