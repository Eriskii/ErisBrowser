if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
function check(v){if(!v)throw new Error('oracle');}
var P=Promise,f=P.try,O=Object,token={},reason={},handled=false,trace='',reads=0,seen=[];
var pending=new P(function(){}),fulfilled=P.resolve(token),rejected=P.reject(reason);
rejected.then(function(){throw new Error('wrong fulfillment');},function(v){check(v===reason);handled=true;});
var promises=[pending,fulfilled,rejected],targets=[P,{},()=>{}],target;
for(var i=0;i<promises.length;i++){
 target=targets[i];trace='';
 O.defineProperty(promises[i],'constructor',{configurable:true,get:function(){reads++;trace+='G';return target;}});
 var resultObject=f.call(target,function(){trace+='F';return promises[i];});
 check(resultObject===promises[i]&&trace==='FG');seen.push(trace);
}
check(reads===3&&!handled);
