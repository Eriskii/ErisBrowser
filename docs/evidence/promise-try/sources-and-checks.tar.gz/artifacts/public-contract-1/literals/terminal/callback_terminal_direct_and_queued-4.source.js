if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
var P=Promise,f=P.try,token={},holder={},trace='',constructors=0,captures=0,resolves=0,rejects=0,gets=0,after=false;
function resolve(){resolves++;trace+='R';}
function reject(){rejects++;trace+='J';}
function C(ex){constructors++;trace+='C';ex(resolve,reject);captures++;return holder;}
function callback(){trace+='F';eval('0');}
queueMicrotask(function(){try{f.call(C,callback);after=true;}catch(e){trace+='X';}finally{trace+='Z';}trace+='A';});
queueMicrotask(function(){trace+='Q';console.log('late');});trace+='S';
