if(typeof Promise.try!=='function')throw new Error('Promise.try missing');
var P=Promise,f=P.try,token={},holder={},trace='',constructors=0,captures=0,resolves=0,rejects=0,gets=0,after=false;
function resolve(){resolves++;trace+='R';}
function reject(){rejects++;trace+='J';}
function C(ex){constructors++;trace+='C';ex(resolve,reject);captures++;return holder;}
var p=P.resolve(token);Object.defineProperty(p,'constructor',{get:function(){gets++;trace+='G';while(true){}}});
function callback(){trace+='F';return p;}
queueMicrotask(function(){trace+='Q';console.log('late');});
try{f.call(C,callback);after=true;}catch(e){trace+='X';}finally{trace+='Z';}trace+='A';
