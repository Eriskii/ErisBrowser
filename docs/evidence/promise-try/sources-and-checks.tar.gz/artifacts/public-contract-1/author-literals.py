"""Author independent public literals, without project/engine execution."""
from pathlib import Path
import hashlib
import json
import textwrap

D=Path('/tmp/eris-promise-try-runtime-plan-1')
O=Path(__file__).parent
GUARD="if(typeof Promise.try!=='function')throw new Error('Promise.try missing');\n"
CHECK="function check(v){if(!v)throw new Error('oracle');}\n"
groups=[]

def phase(source, observation, expected):
    return {'source':GUARD+textwrap.dedent(source).lstrip('\n'),
            'observation':observation,'expected':{'type':'string','value':expected}}

def add(name,source,observation,expected):
    groups.append({'id':name,'rust_test':'promise_try_'+name,
                   'phases':[phase(CHECK+textwrap.dedent(source).lstrip('\n'),observation,expected)]})

add('metadata_cached_alias_nonconstruction',r'''
var P=Promise,O=Object,f=P.try,alias=P.try,has=O.prototype.hasOwnProperty;
var d=O.getOwnPropertyDescriptor(P,'try'),n=O.getOwnPropertyDescriptor(f,'name'),l=O.getOwnPropertyDescriptor(f,'length');
check(f===alias&&d.value===f&&d.writable&&!d.enumerable&&d.configurable);
check(n.value==='try'&&!n.writable&&!n.enumerable&&n.configurable);
check(l.value===1&&!l.writable&&!l.enumerable&&l.configurable);
check(O.getPrototypeOf(f)===Function.prototype&&!has.call(f,'prototype'));
var entered=0,caught=0;function callback(){entered++;return 1;}
try{f(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{f.bind(undefined)(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{new f(callback);}catch(e){check(e instanceof TypeError);caught++;}
try{Reflect.construct(f,[callback]);}catch(e){check(e instanceof TypeError);caught++;}
check(caught===4&&entered===0);
O.defineProperty(f,'name',{value:'renamed'});O.defineProperty(f,'length',{value:9});
check(alias===P.try&&alias.name==='renamed'&&alias.length===9);
var p=P.resolve(7),run=alias.bind(P);check(run(function(){entered++;return p;})===p&&entered===1);
var result='metadata:4|alias:true|callback:1';
''','result','metadata:4|alias:true|callback:1')

add('receiver_guard_and_late_constructor_validation',r'''
var f=Promise.try,bad=[undefined,null,true,1,'x',Symbol('x')],trace='',args=0,entered=0,primitive=0,objects=0,token={};
function argument(){args++;trace+='A';return token;}
function callback(){entered++;trace+='F';return 9;}
for(var i=0;i<bad.length;i++){
 trace='';var caught=false;
 try{f.call(bad[i],callback,argument());}catch(e){check(e instanceof TypeError);trace+='T';caught=true;primitive++;}
 check(caught&&trace==='AT'&&entered===0);
}
var nonconstructors=[{},()=>{}];
for(var j=0;j<nonconstructors.length;j++){
 trace='';var normal=false;
 try{f.call(nonconstructors[j],callback,argument());}catch(e){check(e instanceof TypeError);trace+='T';normal=true;objects++;}
 check(normal&&trace==='AFT');
 trace='';var abrupt=false;
 try{f.call(nonconstructors[j],function(){entered++;trace+='F';throw token;},argument());}
 catch(e){check(e instanceof TypeError&&e!==token);trace+='T';abrupt=true;objects++;}
 check(abrupt&&trace==='AFT');
}
check(primitive===6&&objects===4&&entered===4&&args===10);
var result='primitive:'+primitive+'|object:'+objects+'|callbacks:'+entered+'|args:'+args;
''','result','primitive:6|object:4|callbacks:4|args:10')

add('generic_normal_callback_before_constructor',r'''
var f=Promise.try,token={},holder={},ignored={},trace='',resolves=0,rejects=0;
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);resolves++;trace+='R';return ignored;}
function reject(){rejects++;trace+='J';}
function C(ex){check(new.target===C&&arguments.length===1&&typeof ex==='function');trace+='C';check(ex(resolve,reject)===undefined);return holder;}
var value=f.call(C,function(){'use strict';check(this===undefined&&arguments.length===0);trace+='F';return token;});
check(value===holder&&trace==='FCR'&&resolves===1&&rejects===0);
var result=trace+'|'+resolves+'|'+rejects;
''','result','FCR|1|0')

add('callback_throw_constructor_and_reject_precedence',r'''
var f=Promise.try,reason={},constructorToken={},rejectToken={},holder={},ignored={},trace='',resolves=0,rejects=0,seen=[];
function resolve(){resolves++;trace+='R';}
function reject(v){'use strict';check(this===undefined&&arguments.length===1&&v===reason);rejects++;trace+='J';return ignored;}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
var reasons=[reason,7];
for(var i=0;i<reasons.length;i++){
 reason=reasons[i];trace='';
 var value=f.call(C,function(){trace+='F';throw reason;});
 check(value===holder&&trace==='FCJ');seen.push(trace);
}
function BadC(ex){trace+='C';throw constructorToken;}
trace='';var caught=false;
try{f.call(BadC,function(){trace+='F';throw reason;});}catch(e){check(e===constructorToken);caught=true;}
check(caught&&trace==='FC');seen.push(trace);
function ThrowReject(v){'use strict';check(this===undefined&&arguments.length===1&&v===reason);rejects++;trace+='J';throw rejectToken;}
function RejectC(ex){trace+='C';ex(resolve,ThrowReject);return holder;}
trace='';caught=false;
try{f.call(RejectC,function(){trace+='F';throw reason;});}catch(e){check(e===rejectToken);caught=true;}
check(caught&&trace==='FCJ'&&resolves===0&&rejects===3);seen.push(trace);
var result=seen.join(',')+'|rejects:'+rejects;
''','result','FCJ,FCJ,FC,FCJ|rejects:3')

add('genuine_identity_before_constructor_check',r'''
var P=Promise,f=P.try,O=Object,token={},reason={},handled=false,trace='',reads=0,seen=[];
var pending=new P(function(){}),fulfilled=P.resolve(token),rejected=P.reject(reason);
rejected.then(function(){throw new Error('wrong fulfillment');},function(v){check(v===reason);handled=true;});
var promises=[pending,fulfilled,rejected],targets=[P,{},()=>{}],target;
for(var i=0;i<promises.length;i++){
 target=targets[i];trace='';
 O.defineProperty(promises[i],'constructor',{configurable:true,get:function(){reads++;trace+='G';return target;}});
 var resultObject=f.call(target,function(){trace+='F';return promises[i];});
 check(resultObject===promises[i]&&trace==='FG');seen.push(trace);
}
check(reads===3&&!handled);
''',"seen.join(',')+'|'+handled",'FG,FG,FG|true')

add('genuine_constructor_getter_mismatch_and_throw',r'''
var P=Promise,f=P.try,O=Object,p=P.resolve(7),other={},holder={},token={},trace='',reads=0,constructors=0,resolves=0,rejects=0,seen=[];
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===p);trace+='R';resolves++;}
function reject(){trace+='J';rejects++;}
function C(ex){trace+='C';constructors++;ex(resolve,reject);return holder;}
O.defineProperty(p,'constructor',{configurable:true,get:function(){reads++;trace+='G';return other;}});
check(f.call(C,function(){trace+='F';return p;})===holder&&trace==='FGCR');seen.push(trace);
O.defineProperty(p,'constructor',{configurable:true,get:function(){reads++;trace+='G';throw token;}});
var receivers=[C,{}];
for(var i=0;i<receivers.length;i++){
 trace='';var caught=false;
 try{f.call(receivers[i],function(){trace+='F';return p;});}catch(e){check(e===token);caught=true;}
 check(caught&&trace==='FG');seen.push(trace);
}
check(reads===3&&constructors===1&&resolves===1&&rejects===0);
var result=seen.join(',')+'|'+reads+'|'+constructors+'|'+resolves+'|'+rejects;
''','result','FGCR,FG,FG|3|1|1|0')

add('invalid_callback_and_capability_capture',r'''
var f=Promise.try,holder={},token={},trace='',badCallbacks=0,badCapabilities=0,settlers=0,unexpected=0;
function resolve(){unexpected++;trace+='R';}
function reject(v){'use strict';check(this===undefined&&arguments.length===1&&v instanceof TypeError);settlers++;trace+='J';}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
var callbacks=[undefined,null,{},17];
for(var i=0;i<callbacks.length;i++){
 trace='';var resultObject=i===0?f.call(C):f.call(C,callbacks[i]);
 check(resultObject===holder&&trace==='CJ');badCallbacks++;
}
function Missing(ex){trace+='C';return holder;}
function BadResolve(ex){trace+='C';ex(1,reject);return holder;}
function BadReject(ex){trace+='C';ex(resolve,1);return holder;}
var constructors=[Missing,BadResolve,BadReject];
for(var j=0;j<constructors.length;j++){
 trace='';var caught=false;
 try{f.call(constructors[j],function(){trace+='F';return token;});}catch(e){check(e instanceof TypeError);caught=true;}
 check(caught&&trace==='FC');badCapabilities++;
}
function AfterCapture(ex){trace+='C';ex(resolve,reject);throw token;}
trace='';var captureThrow=false;
try{f.call(AfterCapture,function(){trace+='F';throw 7;});}catch(e){check(e===token);captureThrow=true;}
check(captureThrow&&trace==='FC'&&settlers===4&&unexpected===0);
var result='bad-callbacks:'+badCallbacks+'|bad-capabilities:'+badCapabilities+'|capture-throw:1|settlers:'+settlers;
''','result','bad-callbacks:4|bad-capabilities:3|capture-throw:1|settlers:4')

add('exact_this_tail_arguments_and_evaluation_order',r'''
var f=Promise.try,O=Object,object={},fn=function(){},symbol=Symbol('arg'),returned={},holder={},trace='',expected=[],counts=[],seen=[],resolves=0;
O.defineProperty(object,'length',{get:function(){throw new Error('argument length Get');}});
O.defineProperty(object,Symbol.iterator,{get:function(){throw new Error('argument iterator Get');}});
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===returned);trace+='R';resolves++;}
function reject(){throw new Error('unexpected reject');}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
function arg(v){trace+='A';return v;}
function callback(){'use strict';check(this===undefined&&arguments.length===expected.length);trace+='F';counts.push(arguments.length);
 for(var i=0;i<expected.length;i++){check(O.is(arguments[i],expected[i]));}return returned;}
check(f.call(C,callback)===holder&&trace==='FCR');seen.push(trace);
trace='';expected=[object];check(f.call(C,callback,arg(object))===holder&&trace==='AFCR');seen.push(trace);
trace='';expected=[object,fn,symbol,undefined,-0,'tail'];
check(f.call(C,callback,arg(object),arg(fn),arg(symbol),arg(undefined),arg(-0),arg('tail'))===holder&&trace==='AAAAAAFCR');seen.push(trace);
var receiver={},prefix={};
function boundTarget(first,second,third){'use strict';check(this===receiver&&arguments.length===3&&first===prefix&&second===object&&third===symbol);trace+='F';counts.push(arguments.length);return returned;}
var bound=boundTarget.bind(receiver,prefix);trace='';
check(f.call(C,bound,arg(object),arg(symbol))===holder&&trace==='AAFCR');seen.push(trace);
check(resolves===4);var result=counts.join(',')+'|'+seen.join(',');
''','result','0,1,6,3|FCR,AFCR,AAAAAAFCR,AAFCR')

add('normal_resolve_abrupt_is_not_callback_rejection',r'''
var f=Promise.try,token={},holder={},ignored={},resolveToken={},rejectToken={},fail=false,trace='',resolves=0,rejects=0,seen=[];
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);resolves++;trace+='R';if(fail)throw resolveToken;return ignored;}
function reject(){rejects++;trace+='J';throw rejectToken;}
function C(ex){trace+='C';ex(resolve,reject);return holder;}
check(f.call(C,function(){trace+='F';return token;})===holder&&trace==='FCR');seen.push(trace);
fail=true;trace='';var caught=false;
try{f.call(C,function(){trace+='F';return token;});}catch(e){check(e===resolveToken);caught=true;}
check(caught&&trace==='FCR'&&resolves===2&&rejects===0);seen.push(trace);
var result=seen.join(',')+'|'+resolves+'|'+rejects;
''','result','FCR,FCR|2|0')

add('fake_brand_and_thenable_getter_boundary',r'''
var P=Promise,f=P.try,O=Object,fake=O.create(P.prototype),holder={},fakeTrace='',fakeReads=0,token={},reason={},ignored={};
O.defineProperty(fake,'constructor',{get:function(){fakeReads++;throw new Error('fake constructor Get');}});
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===fake);fakeTrace+='R';}
function reject(){throw new Error('fake reject');}
function C(ex){fakeTrace+='C';ex(resolve,reject);return holder;}
check(f.call(C,function(){fakeTrace+='F';return fake;})===holder&&fakeTrace==='FCR'&&fakeReads===0);
var trace='',throwTrace='',thenable={};
function then(resolveValue,rejectValue){'use strict';check(this===thenable&&arguments.length===2);trace+='T';resolveValue(token);rejectValue(reason);resolveValue(ignored);throw ignored;}
O.defineProperty(thenable,'then',{get:function(){trace+='G';return then;}});
var p=f.call(P,function(){trace+='F';return thenable;});check(trace==='FG');
p.then(function(v){check(v===token);trace+='V';},function(){trace+='x';});
trace+='E';queueMicrotask(function(){trace+='Q';});
var bad={};O.defineProperty(bad,'then',{get:function(){throwTrace+='G';throw reason;}});
var rejected=f.call(P,function(){throwTrace+='F';return bad;});check(throwTrace==='FG');
rejected.then(function(){throwTrace+='x';},function(v){check(v===reason);throwTrace+='J';});throwTrace+='E';
check(trace==='FGE'&&throwTrace==='FGE');
''',"[fakeTrace,trace,throwTrace,fakeReads].join('|')",'FCR|FGETQV|FGEJ|0')

groups.append({'id':'genuine_pending_deferred_and_handled_jobs',
 'rust_test':'promise_try_genuine_pending_deferred_and_handled_jobs','phases':[
 phase(CHECK+r'''
var P=Promise,f=P.try,release,token={},reason={},trace='S';
var pending=new P(function(resolve){release=resolve;});
var returned=f.call(P,function(){trace+='F';return pending;});check(returned===pending);
returned.then(function(v){check(v===token);trace+='V';},function(){trace+='x';});
trace+='E';queueMicrotask(function(){trace+='Q';});check(trace==='SFE');
''','trace','SFEQ'),
 phase(r'''
trace+='A';check(release(token)===undefined);trace+='B';check(trace==='SFEQAB');
''','trace','SFEQABV'),
 phase(r'''
var jobs='S';
var a=f.call(P,function(){jobs+='F';return token;});
a.then(function(v){check(v===token);jobs+='V';},function(){jobs+='x';});
var b=f.call(P,function(){jobs+='T';throw reason;});
b.then(function(){jobs+='x';},function(v){check(v===reason);jobs+='J';});
jobs+='E';queueMicrotask(function(){jobs+='Q';});check(jobs==='SFTE');
''','jobs','SFTEVJQ')
 ]})

add('captured_receiver_and_poisoned_lookup_bypass',r'''
var P=Promise,O=Object,f=P.try,token={},trace='',poisons=0,newPrototype={fresh:true},p=P.resolve(7);
function trap(){poisons++;throw new Error('unrelated lookup');}
function resolve(v){'use strict';check(this===undefined&&arguments.length===1&&v===token);trace+='R';}
function reject(){throw new Error('unexpected reject');}
function C(ex){check(new.target===original);trace+='C';ex(resolve,reject);this.marker=token;}
var original=C;
O.defineProperty(original,'resolve',{get:trap});O.defineProperty(original,Symbol.species,{get:trap});
O.defineProperty(P,'resolve',{configurable:true,get:trap});O.defineProperty(P,Symbol.species,{configurable:true,get:trap});
var resultObject=f.call(C,function(){
 trace+='F';original.prototype=newPrototype;C={replaced:true};
 Promise=function(){throw new Error('global Promise used');};Object=function(){throw new Error('global Object used');};return token;
});
check(O.getPrototypeOf(resultObject)===newPrototype&&resultObject.marker===token&&trace==='FCR');
check(f.call(P,function(){trace+='F';return p;})===p&&trace==='FCRF'&&poisons===0);
var result=trace+'|'+poisons+'|'+(C!==original);
''','result','FCRF|0|true')

terminal=[]
readback="[trace,constructors,captures,resolves,rejects,gets,after].join('|')"
for family,placements in [
 ('callback_terminal_direct_and_queued',[('callback_direct','F|0|0|0|0|0|false'),('callback_queued','SF|0|0|0|0|0|false')]),
 ('constructor_and_genuine_constructor_getter_terminal',[('constructor','FC|1|0|0|0|0|false'),('constructor_getter','FG|0|0|0|0|1|false')]),
 ('resolver_and_rejector_terminal',[('resolve','FCR|1|1|1|0|0|false'),('reject','FCJ|1|1|0|1|0|false')]),
]:
    cases=[]
    for stage,expected in placements:
        for kind,stop in [('resource','while(true){}'),('unsupported',"eval('0');")]:
            callback="trace+='F';"+(stop if stage.startswith('callback') else ('throw token;' if stage=='reject' else 'return token;'))
            ctor="constructors++;trace+='C';"+(stop if stage=='constructor' else 'ex(resolve,reject);captures++;return holder;')
            res="resolves++;trace+='R';"+(stop if stage=='resolve' else '')
            rej="rejects++;trace+='J';"+(stop if stage=='reject' else '')
            source=GUARD+"var P=Promise,f=P.try,token={},holder={},trace='',constructors=0,captures=0,resolves=0,rejects=0,gets=0,after=false;\n"
            source+='function resolve(){'+res+'}\nfunction reject(){'+rej+'}\nfunction C(ex){'+ctor+'}\n'
            if stage=='constructor_getter':
                source+='var p=P.resolve(token);Object.defineProperty(p,\'constructor\',{get:function(){gets++;trace+=\'G\';'+stop+'}});\n'
                callback="trace+='F';return p;"
            source+='function callback(){'+callback+'}\n'
            invoke="try{f.call(C,callback);after=true;}catch(e){trace+='X';}finally{trace+='Z';}trace+='A';"
            if stage=='callback_queued':
                source+='queueMicrotask(function(){'+invoke+'});\n'
                source+="queueMicrotask(function(){trace+='Q';console.log('late');});trace+='S';\n"
            else:
                source+="queueMicrotask(function(){trace+='Q';console.log('late');});\n"+invoke+'\n'
            cases.append({'id':stage+'_'+kind,'stage':stage,'kind':kind,'source':source,
                          'observation':readback,'expected':{'type':'string','value':expected}})
    terminal.append({'id':family,'rust_test':'promise_try_'+family,'cases':cases})

assert len(groups)==12 and sum(len(g['phases']) for g in groups)==14
assert len(terminal)==3 and sum(len(g['cases']) for g in terminal)==12
assert len({g['rust_test'] for g in groups+terminal})==15
for group in groups:
    for row in group['phases']:assert row['source'].startswith(GUARD)
for group in terminal:
    for row in group['cases']:assert row['source'].startswith(GUARD)

def bind(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}

def write(name,obj):
    p=O/name;assert not p.exists();p.parent.mkdir(parents=True,exist_ok=True)
    p.write_text(json.dumps(obj,indent=2)+'\n');return bind(p)

semantic=write('semantic-cases.json',groups)
fatal=write('terminal-cases.json',terminal)
payloads=[]
for family,collection in [('semantic',groups),('terminal',terminal)]:
    for group in collection:
        for index,row in enumerate(group.get('phases',group.get('cases'))):
            for role,key in [('source','source'),('readback','observation')]:
                p=O/'literals'/family/(group['id']+f'-{index+1}.'+role+'.js')
                p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_text(row[key])
                payloads.append(bind(p))
preservation_source=GUARD+"var trace='S';queueMicrotask(function(){trace+='Q';});"
preservation=write('terminal-preservation.json',{'source':preservation_source,'observation':'trace','expected':'SQ',
 'runtime':'Separate fresh Runtime per mode and terminal family; suspended runtimes are never reset.'})
counts=write('roster.json',{
 'groups':15,'semantic_groups':12,'terminal_groups':3,
 'semantic_roster':[g['rust_test'] for g in groups],'terminal_roster':[g['rust_test'] for g in terminal],
 'modes':['sloppy','strict'],'semantic_phase_payloads':14,'semantic_phase_executions':28,'semantic_readback_executions':28,
 'terminal_literal_sources':12,'terminal_failing_entries':24,'terminal_readbacks':48,'fresh_preservation_source_entries':6,'fresh_preservation_readbacks':6,
 'planned_public_execute_calls':140,
 'qualification':'Counts assume every preceding assertion succeeds. Source-internal table iterations/assertions are not Rust test groups. No candidate outcome is claimed.',
 'parent_prediction':{'groups_pass':0,'groups_fail':15,'basis':'Published parent has no Promise.try; each first sloppy source throws the explicit availability Error.',
  'unreached':'For each semantic group, first observation, later phases and strict mode. For each fatal group, actual ResourceLimit/Unsupported classification fails first; sticky-state/readbacks/later cases/strict mode/fresh controls are unreached.'}})
seal=write('literals-ready.json',{
 'status':'independent executable literal contract frozen before production payload authoring; no engine execution',
 'base':'7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9',
 'semantic':semantic,'terminal':fatal,'preservation':preservation,'roster':counts,'payloads':payloads,
 'public_selection':bind(D/'root/public-selection-1.json'),
 'readiness':bind(D/'public-readiness-1/source-ready.json'),'published_refresh':bind(D/'public-readiness-1/published-base-refresh.json'),
 'author':bind(__file__),
 'scope':'No private fee assertions, future production inspection, project import/execution or live edits. Rust conversion follows additively.'})
print(json.dumps(seal))
