"""Author inert external Rust payloads; never import or execute project code."""
from pathlib import Path
import json,hashlib,difflib,subprocess
D=Path('/tmp/eris-promise-try-runtime-plan-1');O=D/'production-1';BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
def binding(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def frozen(p,sha):
 assert binding(p)['sha256']==sha
 return binding(p)
public=frozen(D/'public-contract-1/literals-ready.json','4fa8dcf48432897583cc1e764c07e9e7909064f0b8f2a3ed943a8835caf5cee4')
private=frozen(D/'private-contract-1/contract-ready.json','c3d658e4a4993480b94cb5f8d188724e9c43a802218dbc5013aa33c18f885be1')
selection=frozen(D/'root/selection-1.json','5b55b32a129cf78e025b5f3fd9ddff495284db408957de15382656b1aecab9fa')
files={r['relative']:(O/'before'/r['relative']).read_text() for r in json.loads((O/'source-before.json').read_text())['files']}
manifest=[]
def edit(path,before,after,reason):
 assert files[path].count(before)==1,(path,before)
 files[path]=files[path].replace(before,after,1)
 manifest.append({'path':path,'before':before,'after':after,'count':1,'reason':reason})
edit('src/script.rs','        self.install_promise_with_resolvers_intrinsic()\n','        self.install_promise_with_resolvers_intrinsic()?;\n        self.install_promise_try_intrinsic()\n','Append late installation only after all earlier intrinsics succeed.')
edit('src/script/dom_prototypes.rs','    + promises::WITH_RESOLVERS_METADATA_OBJECTS\n','    + promises::WITH_RESOLVERS_METADATA_OBJECTS\n    + promises::TRY_METADATA_OBJECTS\n','Prepay one additional ScriptObject in the existing initial reservation.')
edit('src/script/promises.rs','pub(super) const WITH_RESOLVERS_METADATA_OBJECTS: usize = 1;\n','pub(super) const WITH_RESOLVERS_METADATA_OBJECTS: usize = 1;\npub(super) const TRY_METADATA_OBJECTS: usize = 1;\n','Independent one-bag reservation; earlier metadata counts and IDs stay fixed.')
installer='''    pub(in crate::script) fn install_promise_try_intrinsic(&mut self) -> Result<()> {
        // Eight bounded guards/control roles and four temporary releases.
        // Append after withResolvers to preserve every earlier metadata ID.
        self.work(12)?;
        let intrinsics = self
            .promises
            .intrinsics
            .as_ref()
            .ok_or_else(|| ScriptError::resource("Promise intrinsics missing"))?;
        let Value::Native(constructor) = &intrinsics.constructor else {
            return Err(ScriptError::resource("invalid Promise constructor"));
        };
        let owner = constructor
            .properties
            .map(NonZeroUsize::get)
            .filter(|id| *id < self.objects.len())
            .ok_or_else(|| ScriptError::resource("Promise metadata missing"))?;
        let bag = &self.objects[owner];
        if bag.values.len() != 11 || bag.order.len() != 11 || bag.order.capacity() < bag.order.len()
        {
            return Err(ScriptError::resource("invalid Promise metadata shape"));
        }
        let length = self.dom_proto_text("length")?;
        let name = self.dom_proto_text("name")?;
        let key = self.dom_proto_text("try")?;
        // Two metadata key copies and the display-name copy.
        self.work(3)?;
        let method =
            self.promise_intrinsic_method("Promise.try", key.clone(), 1, [&length, &name])?;
        // Existing insertion pays the B-tree threshold and physical order growth.
        self.dom_proto_property(owner, key.into(), Property::data(method, true, false, true))
    }

'''
anchor='    fn check_promise_install_state(&self) -> Result<()> {\n'
edit('src/script/promises/install.rs',anchor,installer+anchor,'Add the selected late installer; existing method metadata/property helpers stay exact.')
body='''    fn promise_try(
        &mut self,
        constructor: Value,
        args: &[Value],
        doc: &mut Document,
    ) -> Result<Value> {
        // Nine control roles and seven path-dependent owned values. Incoming
        // constructor cleanup is already funded by the public/caller envelope.
        self.work(16)?;
        if !js_object(&constructor) {
            return Err(ScriptError::type_error(
                "Promise.try receiver is not an object",
            ));
        }
        self.work(1)?;
        let callback = args.first().cloned().unwrap_or(Value::Undefined);
        let arguments = self.promise_try_arguments(args.get(1..).unwrap_or(&[]))?;
        // Call owns its copied callback and prepaid vector even if its first
        // tick refuses. Normal completion enters the unchanged PromiseResolve.
        match self.call(callback, arguments, Value::Undefined, doc) {
            Ok(value) => self.promise_resolve_with_constructor(constructor, value, doc),
            Err(error) if error.is_resource_limit() || error.is_unsupported() => Err(error),
            Err(error) => {
                let Capability {
                    promise,
                    resolve: _,
                    reject,
                } = self.new_promise_capability(constructor, doc)?;
                // Preserve a thrown Value exactly; materialize an ordinary
                // runtime error only after successful author construction.
                let reason = self.exception_value(error)?;
                let arguments = self.promise_arguments([reason])?;
                self.call(reject, arguments, Value::Undefined, doc)?;
                Ok(promise)
            }
        }
    }

'''
anchor='    pub(in crate::script) fn promise_native_operation(\n'
edit('src/script/promises/semantics.rs',anchor,body+anchor,'Add callback-first body without widening or replacing existing abstract operations.')
edit('src/script/promises/semantics.rs','                "Promise.withResolvers" => self.promise_with_resolvers(receiver, doc),\n','                "Promise.withResolvers" => self.promise_with_resolvers(receiver, doc),\n                "Promise.try" => self.promise_try(receiver, args, doc),\n','Use the existing public8 envelope and terminal observer for the new operation.')
helper='''    pub(super) fn promise_try_arguments(&mut self, arguments: &[Value]) -> Result<Vec<Value>> {
        let result = (|| {
            // Fixed planning/header cleanup, then clone, placement and eventual
            // release for each borrowed handle. Zero keeps the same envelope.
            self.work(8)?;
            let count = arguments.len();
            if count > 65_536 {
                return Err(ScriptError::resource("Promise.try argument limit exceeded"));
            }
            let work = mul(3, count)?;
            let bytes = add(32, mul(count, size_of::<Value>())?)?;
            self.work(work)?;
            self.charge(bytes)?;
            let mut values = Vec::new();
            values
                .try_reserve_exact(count)
                .map_err(|_| ScriptError::resource("Promise argument allocation failed"))?;
            // Reserve and every fallible debit precede all handle copies.
            for value in arguments {
                values.push(value.clone());
            }
            Ok(values)
        })();
        self.observe_microtask_failure(result)
    }

'''
anchor='    pub(super) fn promise_arguments<const N: usize>(\n'
edit('src/script/promises/factories.rs',anchor,helper+anchor,'Separate bounded borrowed-tail builder; the old owned singleton/pair helper stays exact.')
edit('src/script/machine/calls.rs','                    | "Promise.withResolvers"\n','                    | "Promise.withResolvers"\n                    | "Promise.try"\n','Route the new native method through the existing Promise operation wrapper.')
rows=[]
for path,after in files.items():
 before=(O/'before'/path).read_text()
 assert subprocess.check_output(['git','-C',str(D/'worktree'),'show',BASE+':'+path])==before.encode()
 edits=[e for e in manifest if e['path']==path]
 inv=after
 for e in reversed(edits):
  assert inv.count(e['after'])==1
  inv=inv.replace(e['after'],e['before'],1)
 assert inv==before
 raw=O/'raw'/path;diff=O/'diff'/(path+'.diff');raw.parent.mkdir(parents=True,exist_ok=True);diff.parent.mkdir(parents=True,exist_ok=True)
 raw.write_text(after);diff.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=path,tofile=path)))
 rows.append({'relative_path':path,'before':binding(O/'before'/path),'raw':binding(raw),'diff':binding(diff),'exact_inverse':True,'new':False})
(O/'edit-manifest.json').write_text(json.dumps({'base':BASE,'edits':manifest,'new_functions':['install_promise_try_intrinsic','promise_try','promise_try_arguments'],'changed_existing_functions':['initialize_intrinsics','promise_native_operation','machine::calls::invoke_native'],'new_fields_types_or_state':False},indent=2)+'\n')
(O/'payload-index.json').write_text(json.dumps({'status':'external raw payload authored after both independent contract freezes; pending source review/seal','base':BASE,'public_literals':public,'private_contract':private,'selection':selection,'files':rows},indent=2)+'\n')
print(json.dumps({'files':len(rows),'edits':len(manifest),'raw_authored':True}))
