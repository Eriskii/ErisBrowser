"""Independent static validation evidence audit: stdlib and read-only Git only."""
from pathlib import Path
from collections import Counter
import hashlib,json,re,subprocess
D=Path('/tmp/eris-promise-try-runtime-plan-1');W=D/'worktree';O=D/'validation-review-1'
def load(p): return json.loads(Path(p).read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def digest(v): return sha(json.dumps(v,sort_keys=True,separators=(',',':')).encode())
def bind(p):
 p=Path(p);b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def write(n,v): (O/n).write_text(json.dumps(v,indent=2)+'\n')
def bound(r):
 b=bind(r['path']);assert b['sha256']==r['sha256'],r['path']
 if 'bytes' in r:assert b['bytes']==r['bytes'],r['path']
 return b
base='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
def git_bytes(p):return subprocess.check_output(['git','show',f'{base}:{p}'],cwd=W)
def rust(p):
 target='';rows=[];s=Path(p).read_text()
 for line in s.splitlines():
  m=re.search(r'Running .*? \(([^)]+)\)',line)
  if m:target=re.sub(r'-[0-9a-f]{16}$','',Path(m[1]).name)
  m=re.match(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:\b.*)?$',line)
  if m: rows.append((target,m[1],m[2]))
 totals=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',s)
 assert len(rows)==len({r[:2] for r in rows})
 return rows,totals
scaffold=load(O/'scaffold-ready.json')
for b in scaffold['contracts']+scaffold['derived']:bound(b)
L=load(D/'root/final-validation.json');assert sha((D/'root/final-validation.json').read_bytes())=='954e5cdb2e1766bd6ae42792aa9becb2b6bbb70a38815a152c1b952382df358b'
assert L['status']=='pass' and L['base']==base
# Bind every terminal receipt and raw log; outcome claims below use parsed data.
checks=[]
for c in L['checks']:
 bound(c['receipt']);bound(c['log']);r=load(c['receipt']['path'])
 assert r['exit']==c['exit']==(101 if c['label']=='try-parent-public-1' else 0)
 assert r['sha256']==c['log']['sha256']
 assert Path(c['log']['path']).name==r['log']
 checks.append({'label':c['label'],'exit':r['exit'],'command':r['command'],'log':c['log']})
assert len(checks)==17
for r in L['source_peers']+L['receipt_corrections']:bound(r)
bound(L['source']['source_peer']);bound(L['prior_ci']['receipt'])
for k in ['source_final','source_candidate','scope_qualification']:bound(L['source'][k])
# Exact selected source and narrow entire-file production inverse.
parent=load(D/'source-parent.json');candidate=load(D/'source-candidate-1.json');final=load(D/'source-final.json')
assert candidate['base']==final['base']==parent['base']==base
assert candidate['source_sha256']==final['source_sha256']
assert set(candidate)==set(final) and candidate['scope']!=final['scope']
assert len(final['source_sha256'])==1778 and len(parent['source_sha256'])==1775
changed=[];added=[]
for p,h in final['source_sha256'].items():
 assert sha((W/p).read_bytes())==h,p
 if p not in parent['source_sha256']:added.append(p)
 elif parent['source_sha256'][p]!=h:changed.append(p)
assert len(added)==3 and len(changed)==24
prod=['src/script.rs','src/script/dom_prototypes.rs','src/script/machine/calls.rs','src/script/promises.rs','src/script/promises/factories.rs','src/script/promises/install.rs','src/script/promises/semantics.rs']
# Removing a new standalone function by balanced braces; these three functions
# contain no braces in string literals, so brace depth is unambiguous.
def remove_function(s,needle):
 a=s.index(needle);o=s.index('{',a);depth=1;i=o+1
 while depth:
  depth += (s[i]=='{')-(s[i]=='}');i+=1
 assert s[i:i+2]=='\n\n';return s[:a]+s[i+2:]
inv=[]
for p in prod:
 s=(W/p).read_text()
 if p=='src/script.rs':
  s=s.replace('        self.install_promise_with_resolvers_intrinsic()?;\n        self.install_promise_try_intrinsic()','        self.install_promise_with_resolvers_intrinsic()')
  suffix='\n#[cfg(test)]\nmod try_abort_tests;\n#[cfg(test)]\nmod try_semantics_tests;\n';assert s.endswith(suffix);s=s[:-len(suffix)]
 elif p=='src/script/dom_prototypes.rs':s=s.replace('    + promises::TRY_METADATA_OBJECTS\n','')
 elif p=='src/script/machine/calls.rs':s=s.replace('                    | "Promise.try"\n','')
 elif p=='src/script/promises.rs':
  s=s.replace('pub(super) const TRY_METADATA_OBJECTS: usize = 1;\n','')
  suffix='\n#[cfg(test)]\nmod try_quota_tests;\n';assert s.endswith(suffix);s=s[:-len(suffix)]
 elif p.endswith('factories.rs'):s=remove_function(s,'    pub(super) fn promise_try_arguments(')
 elif p.endswith('install.rs'):s=remove_function(s,'    pub(in crate::script) fn install_promise_try_intrinsic(')
 elif p.endswith('semantics.rs'):
  s=remove_function(s,'    fn promise_try(')
  s=s.replace('                "Promise.try" => self.promise_try(receiver, args, doc),\n','')
 assert s.encode()==git_bytes(p),p
 inv.append(p)
# Frozen raw string/ordinary-string sequences are exact after rustfmt.
strpat=re.compile(r'r(#+)?"[\s\S]*?"\1|"(?:\\.|[^"\\])*"')
literals=[]
for p,hold in [('src/script/try_semantics_tests.rs','public-contract-1'),('src/script/try_abort_tests.rs','public-contract-1'),('src/script/promises/try_quota_tests.rs','private-contract-1')]:
 raw=(D/hold/'raw'/p).read_text();actual=(W/p).read_text()
 a=[m[0] for m in strpat.finditer(raw)];b=[m[0] for m in strpat.finditer(actual)];assert a==b,p
 assert re.findall(r'#\[test\]\s*fn (\w+)',raw)==re.findall(r'#\[test\]\s*fn (\w+)',actual)
 literals.append({'path':p,'string_tokens':len(a),'literal_vector_sha256':digest(a),'raw':bind(D/hold/'raw'/p),'formatted':bind(W/p)})
# Old corpus/baseline/tooling/CI are also independently checked against published Git.
tracked=subprocess.check_output(['git','ls-tree','-r','--name-only',base,'--','tests/conformance','tests/upstream','tools','.github','Cargo.toml','Cargo.lock'],cwd=W).decode().splitlines()
# Use git hash-object's normal hash computation only via pure stdlib, joined to
# ls-tree IDs; no project importer or executable is used.
tree=subprocess.check_output(['git','ls-tree','-r',base,'--','tests/conformance','tests/upstream','tools','.github','Cargo.toml','Cargo.lock'],cwd=W).decode().splitlines()
for line in tree:
 meta,p=line.split('\t',1);mode,kind,oid=meta.split();assert kind=='blob'
 b=(W/p).read_bytes();assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,p
source_result={'selected_inputs':1778,'changed_existing':changed,'new_modules':added,'candidate_to_final_only_scope':True,'old_production_entire_file_inverses':inv,'literal_comparisons':literals,'independently_unchanged_git_blobs':len(tree),'qualification':'Selected hashes plus named preservation scopes; complete tracked-source census is separately bound to Script peer.'}
# Complete target-qualified Rust rosters from raw logs vs frozen independent scaffold.
contract=load(O/'rust-roster-contract.json');rename={r['before']:r['after'] for r in contract['renames']}
new={('eris',n) for n in contract['new_groups_fully_qualified']};assert len(new)==25
rust_result=[];layoutname='script::promises::all_layout_tests::all_actual_private_layout_matches_four_configuration_prospective_mirror'
for c in contract['parent_configurations']:
 bound(c['parent_log']);bound(c['parent_receipt'])
 label=c['configuration'];old,oldsum=rust(c['parent_log']['path']);rows,sums=rust(D/'validation'/f'{label}.log')
 assert all(r[2]=='ok' for r in old+rows)
 expected={(target,rename.get(name,name)) for target,name,_ in old}|new
 observed={r[:2] for r in rows};assert observed==expected
 assert digest(sorted(observed))==c['expected_candidate_roster_sha256']
 assert len(sums)==52 and all(r[0]=='ok' and all(int(n)==0 for n in r[2:]) for r in sums)
 assert sum(int(r[1]) for r in sums)==len(rows)==c['required_candidate_total_not_observed']
 assert sum(r[0]=='worker' for r in rows)==93
 assert ('eris',layoutname,'ok') in rows
 rust_result.append({'configuration':label,'tests':len(rows),'parent_tests':len(old),'renames':len(rename),'new_groups':len(new),'result_rows':len(sums),'worker_checks':93,'roster_sha256':digest(sorted(observed)),'actual_layout_group_passed':True,'log':bind(D/'validation'/f'{label}.log')})
focused,fs=rust(D/'validation/try-candidate-focused-1.log');pr,ps=rust(D/'validation/try-parent-public-1.log')
assert len(focused)==25 and {r[:2] for r in focused}==new and all(r[2]=='ok' for r in focused)
public={n for _,n in new if 'try_quota_tests' not in n}
assert len(pr)==15 and {r[1] for r in pr}==public and all(r[2]=='FAILED' for r in pr)
assert len(fs)==len(ps)==1 and int(fs[0][1])==25 and int(ps[0][2])==15
# Source-frozen operation counts, qualified as successful loop coverage.
priv=load(D/'private-contract-1/roster.json');pub=load(D/'public-contract-1/roster.json')
assert sum(r['measured_attempts'] for r in priv['per_group'])==78
assert sum(pub[k] for k in ['semantic_phase_executions','semantic_readback_executions','terminal_failing_entries','terminal_readbacks','fresh_preservation_source_entries','fresh_preservation_readbacks'])==140
assert priv['sticky_checkpoint_readbacks']==4
layoutpath='src/script/promises/all_layout_tests.rs';layout=(W/layoutpath).read_bytes();assert layout==git_bytes(layoutpath)
layoutrows=re.findall(r'row!\("([^"]+)", ([^\n]+), (\d+), (\d+)\);',layout.decode());assert len(layoutrows)==24
assert [r for r in layoutrows if r[0]=='Runtime']==[('Runtime','Runtime','1808','16'),('Runtime','Runtime','1872','16')]
# Startup diagnostics, prior raw evidence and typed arithmetic.
startup=load(D/'root/startup-observation.json');prior=load(D/'root/parent-startup-observation.json')
priorlog=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1/validation/with-resolvers-candidate-1.log')
assert sha(priorlog.read_bytes())==prior['log_sha256'] and prior['raw_line'] in priorlog.read_text()
log=(D/'validation/try-candidate-focused-1.log').read_text();assert startup['raw_line'] in log
assert startup['log_sha256']==sha(log.encode())
assert (startup['work'],startup['remaining'],startup['accounted_heap'],startup['objects'])==(101580,898420,1775866,757)
assert startup['prior_order']==[11,11] and startup['final_order']==[12,12] and startup['capacity']==757
assert 'before_objects=(756, 757)' in startup['raw_line']
assert startup['work']-prior['work']==268 and startup['accounted_heap']-prior['accounted_heap']==7595
assert startup['objects']-prior['objects']==1 and startup['maps']==prior['maps']=={'native':300,'prototype':26,'global':213}
assert startup['budgets']==prior['budgets']=={'bootstrap_work':1000000,'author_work':100000,'heap':8388608}
# Target measurements: A/D/K/Bpp/N/S come from unchanged concrete declarations,
# selected accounting and actual layout assertions; independently expand constants.
account=load(D/'accounting-proposal-1/contract.json')
node=16*(16+56)+32*8+64
assert node==1472
installer_grow=16+16+14*16+4*node+56+1179
installer_spare=16+16+2*16+4*node+56+1179
assert installer_grow+216==7595 and installer_spare==7187 and installer_grow==7379
assert 12+(20+16+14)+3+52+129==246 and 12+(20+16+14)+3+52+151==268
# Limits are included in byte-exact script.rs inverse, whose only executable
# change is late installer invocation. Also confirm explicit definitions.
script=(W/'src/script.rs').read_text()
assert re.search(r'const MAX_STEPS: usize = 100_000;',script)
assert re.search(r'const BOOTSTRAP_STEPS: usize = 1_000_000;',script)
assert re.search(r'const MAX_HEAP: usize = 8 \* 1024 \* 1024;',script)
# Binary provenance and all seven complete arrays.
binaries=[]
for b in L['binaries']:
 real=bind(b['binary']);assert real['sha256']==b['sha256'] and real['bytes']==b['bytes']
 assert b['source_sha256']==sha((D/'source-candidate-1.json').read_bytes())
 r=load(b['build']);assert r['exit']==0 and '+1.88.0' in r['command'] and '--release' in r['command']
 assert ('--features' in r['command'])==bool(b['features'])
 if b['features']:assert r['command'][r['command'].index('--features')+1]=='test262-host'
 assert 'Finished `release` profile' in (D/'validation'/r['log']).read_text()
 binaries.append(real)
profile_contract=load(O/'profile-contract.json');profiles=[]
for c in profile_contract['profiles']:
 bound(c['parent_report'])
 old=load(c['parent_report']['path']);p=D/c['profile_name'];now=load(p)
 for key in ['cases','harness_preflight','runner_policy','runner_policy_sha256','corpus_manifest_sha256','counts','repository','revision','suite']:
  assert now[key]==old[key],(p,key)
 assert digest(now['cases'])==c['case_array_sha256'] and digest(now['harness_preflight'])==c['control_array_sha256']
 assert Counter(r['status'] for r in now['cases'])==now['counts']
 assert len({r['id'] for r in now['cases']})==len(now['cases'])
 assert all(r['verified'] is True for r in now['harness_preflight']) and now['harness_preflight_passed'] is True
 assert now['regressions']==[] and now['improvements']==[]
 ordinary=any(n in p.name for n in ['aggregate-error','with-resolvers']);chosen=binaries[0 if ordinary else 1]
 assert now['binary_sha256']==chosen['sha256'] and now['binary']==chosen['path']
 profiles.append({'report':bind(p),'cases':len(now['cases']),'controls':len(now['harness_preflight']),'counts':now['counts'],'cases_sha256':digest(now['cases']),'controls_sha256':digest(now['harness_preflight']),'policy_sha256':now['runner_policy_sha256'],'corpus_sha256':now['corpus_manifest_sha256'],'binary_sha256':now['binary_sha256'],'complete_arrays_exact':True})
assert sum(r['cases'] for r in profiles)==1300 and sum(r['controls'] for r in profiles)==546
# Compare final ledger summaries to independently read data and retained CI.
assert L['candidate']==load(D/'root/focused-validation.json') and L['startup']==startup
assert L['rust']==load(D/'root/rust-validation.json') and L['profiles']==load(D/'root/profile-validation.json')
for r in rust_result:
 a=next(x for x in L['rust']['runs'] if x['configuration']==r['configuration']);assert a['totals']==[r['tests'],0,0,0,0]
for r in profiles:
 a=next(x for x in L['profiles']['profiles'] if x['sha256']==r['report']['sha256']);assert all(a[k]==r[k] for k in ['cases','controls','counts','binary_sha256'])
ci=load(D/'root/prior-ci-observation-1.json');assert ci['headSha']==base and ci['conclusion']=='success' and len(ci['jobs'])==11 and all(j['conclusion']=='success' for j in ci['jobs'])
strict=[]
for n in ['clippy-default-1','clippy-host-vulkan-1']:
 r=load(D/'validation'/f'{n}.json');assert '--all-targets' in r['command'] and r['command'][-2:]==['-D','warnings']
 assert 'Finished `dev` profile' in (D/'validation'/r['log']).read_text();strict.append(bind(D/'validation'/f'{n}.json'))
fmt=load(D/'validation/fmt-check-1.json');assert '--check' in fmt['command'] and fmt['exit']==0
write('actual-checks.json',{'status':'clear','ledger':bind(D/'root/final-validation.json'),'source':source_result,'terminal_receipts':checks,'rust':rust_result,'focused':{'groups':25,'first_candidate':True,'parent_public':{'passed':0,'failed':15,'later_modes_unreached':True},'public_execute_calls_source_derived':140,'private_attempts_source_derived':78,'private_checkpoint_readbacks_source_derived':4},'types':{'source':bind(W/layoutpath),'unchanged_from_parent':True,'rows_per_observed_configuration':23,'both_full_configurations_pass':True,'declared_rows':layoutrows,'qualification':'Two current measured configurations; historical test name does not imply four current runs. Not stack/RSS measurement.'},'startup':startup,'typed_installation':{'Bpp':node,'spare_helper_heap':installer_spare,'growth_helper_heap':installer_grow,'upfront_ScriptObject':216,'measured_growing_delta':7595,'prior_startup_log':bind(priorlog)},'binaries':binaries,'profiles':profiles,'profile_totals':{'cases':1300,'controls':546},'strict':strict,'fmt':bind(D/'validation/fmt-check-1.json'),'prior_ci':{'head':base,'jobs':11,'conclusion':'success'},'execution':'No project imports, builds, tests or live writes. Stdlib file/log/hash/JSON comparisons and read-only Git only.'})
print(json.dumps(bind(O/'actual-checks.json'),indent=2))
