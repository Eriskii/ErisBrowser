"""Independent parent evidence/scaffold derivation. Never executes project code."""
from pathlib import Path
import collections,hashlib,json,re
D=Path('/tmp/eris-promise-try-runtime-plan-1'); O=D/'validation-review-1'
def load(path):return json.loads(Path(path).read_text())
def binding(path):
    path=Path(path);data=path.read_bytes()
    return {'path':str(path),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
def digest(data):return hashlib.sha256(json.dumps(data,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(name,data):(O/name).write_text(json.dumps(data,indent=2)+'\n')
def rust_log(path):
    text=Path(path).read_text();target='';records=[]
    for line in text.splitlines():
        match=re.search(r'Running (.*?) \(([^)]+)\)',line)
        if match:target=re.sub(r'-[0-9a-f]{16}$','',Path(match[2]).name)
        match=re.match(r'test (.+) \.\.\. (ok|FAILED|ignored)(?:\b.*)?$',line)
        if match:records.append((target,match[1],match[2]))
    summaries=re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;',text)
    assert len(records)==len({(r[0],r[1]) for r in records})
    return records,summaries

public=load(D/'public-contract-1/roster.json')
private=load(D/'private-contract-1/roster.json')
new_names=(['script::try_semantics_tests::'+n for n in public['semantic_roster']]
           +['script::try_abort_tests::'+n for n in public['terminal_roster']]
           +['script::promises::try_quota_tests::'+n for n in private['files'][0]['names']])
assert len(new_names)==len(set(new_names))==25
new_records={('eris',n) for n in new_names}
migrations=load(D/'migrations-1/source-ready.json')
renames=[]
for row in migrations['files']:
    path=row['relative_path']
    before=(D/'migration-census-1/parent'/path).read_text()
    after=Path(row['raw']['path']).read_text()
    old=set(re.findall(r'#\[test\]\s*fn (\w+)\(',before))
    new=set(re.findall(r'#\[test\]\s*fn (\w+)\(',after))
    removed=old-new; added=new-old
    assert {n.replace('101312','101580') for n in removed}==added
    module=path.removeprefix('src/').removesuffix('.rs').replace('/','::')
    for name in sorted(removed):
        assert '101312' in name
        renames.append({'before':module+'::'+name,'after':module+'::'+name.replace('101312','101580')})
assert len(renames)==4
rename_map={row['before']:row['after'] for row in renames}
rust=[]
for label,parent_total,candidate_total in [('default-full-1',3221,3246),('host-vulkan-full-1',3575,3600)]:
    log=D/'rust-parent'/f'{label}.log';records,summaries=rust_log(log)
    assert len(records)==parent_total and len(summaries)==52
    assert all(status=='ok' for _,_,status in records)
    assert sum(int(r[1]) for r in summaries)==parent_total
    assert all(r[0]=='ok' and all(int(n)==0 for n in r[2:]) for r in summaries)
    assert sum(target=='worker' for target,_,_ in records)==93
    roster={(target,name) for target,name,_ in records}
    assert all(('eris',old) in roster for old in rename_map)
    renamed={(target,rename_map.get(name,name)) for target,name in roster}
    assert len(renamed)==parent_total and not (renamed & new_records)
    expected=renamed|new_records;assert len(expected)==candidate_total
    rust.append({'configuration':label,'observed_parent_total':parent_total,'parent_result_rows':52,
                 'parent_worker_tests':93,'parent_log':binding(log),'parent_receipt':binding(D/'rust-parent'/f'{label}.json'),
                 'parent_roster_sha256':digest(sorted(roster)),
                 'required_candidate_total_not_observed':candidate_total,
                 'expected_candidate_roster_sha256':digest(sorted(expected))})
write('rust-roster-contract.json',{'status':'derived_expected_rosters_candidate_pending','new_groups':25,
      'new_groups_fully_qualified':sorted(new_names),'renames':renames,'parent_configurations':rust,
      'qualification':'Parent counts are observed from retained logs. Candidate totals/hashes are exact expectations only, not claimed execution outcomes.'})

profiles=[]
for path in sorted((D/'replay-parent').glob('upstream-*.json')):
    report=load(path);cases=report['cases'];controls=report['harness_preflight']
    assert len({r['id'] for r in cases})==len(cases)
    assert all(c['verified'] is True for c in controls)
    assert dict(collections.Counter(r['status'] for r in cases))==report['counts']
    profiles.append({'parent_report':binding(path),'profile_name':path.name,'cases':len(cases),'controls':len(controls),
        'counts':report['counts'],'case_array_sha256':digest(cases),'control_array_sha256':digest(controls),
        'runner_policy':report['runner_policy'],'runner_policy_sha256':report['runner_policy_sha256'],
        'corpus_manifest_sha256':report['corpus_manifest_sha256'],'parent_binary_sha256':report['binary_sha256']})
assert len(profiles)==7 and sum(r['cases'] for r in profiles)==1300 and sum(r['controls'] for r in profiles)==546
write('profile-contract.json',{'status':'observed_parent_arrays_candidate_replays_pending','profiles':profiles,
    'totals':{'profiles':7,'cases':1300,'controls':546},'six_before_with_resolvers':{'cases':1288,'controls':502},
    'required_final_comparison':'Compare complete cases and harness_preflight arrays, corpus and runner-policy bindings; retain every old failed/unsupported row. Compare old baseline file bytes independently. New adapter hashes are expected after runtime rebuild and must bind final source/build logs; do not require parent binary hash equality.',
    'scope':'No Promise.try upstream corpus/profile or outcome claims. No unchanged Python suite rerun implied.'})

parent_log=D/'validation/try-parent-public-1.log'
records,summaries=rust_log(parent_log)
assert len(records)==15 and all(r[2]=='FAILED' for r in records)
assert {r[1] for r in records}==set(new_names[:15])
assert hashlib.sha256(parent_log.read_bytes()).hexdigest()=='dc84e80c3d7451e0ad739835a12b9693ff815fbc4bb5b26594085ff2eae8ea12'
write('parent-public-observation.json',{'status':'observed','log':binding(parent_log),'receipt':binding(D/'validation/try-parent-public-1.json'),
    'groups':15,'passed':0,'failed':15,'qualification':'First sloppy availability assertions fail. Later semantic phases, strict attempts and terminal readbacks are unreached; not140 observed failing executions.'})

checks={
 'source':[
  'Final selected inventory binds published7149ab parent and every production/test/migration/registration input. Compare formatted source against frozen raw holds; preserve JS source/assertion literals and all17 migration inverses.',
  'No CallbackKind/State/Runtime fields, new persistent arena, changed old helper body or old local tariff. Only one late metadata bag and selected Try helper/body/dispatch/initializer seams.',
  'Verify exactly25 new #[test] functions and four selected numeric-boundary renames; no disappearance of old target-qualified tests.'],
 'startup':{'selected_conditional_projection':{'work':101580,'remaining':898420,'accounted_heap':1775866,'objects':757,'owner_order_length':12,'maps':[300,26,213]},
    'prior_observed':binding(D/'root/parent-startup-observation.json'),
    'required':'Read actual Promise.try startup diagnostic: beforeowner11/capacity, afterowner12/capacity, objectlen/capacity, maps/work/heap. Verify the actual physical branch246or268 and typed delta, rather than asserting predicted physical capacities. Recorded x86_64 growingdelta268work/7595bytes includes one upfrontScriptObject.'},
 'limits':['Trusted bootstrap1,000,000 work; successful public100,000 author work; cumulative8MiB heap; callback/stack/string/list ceilings unchanged.',
  '65,536-tail direct helper test uses inert Rust allowance196616 to check helper ceiling; this does not enlarge or promise reachability under public100000.',
  'Ordinary callback error entersNPC before legacy materialization; terminalResource/Unsupported bypassNPC. Natural final-message refusal keeps traceSC and queued sentinel after work-only reset.'],
 'types':{'existing_group':'eris::script::promises::all_layout_tests::all_actual_private_layout_matches_four_configuration_prospective_mirror',
    'required':'Require unchanged assertions and actual successful retained type groups in final configured suites; if separate diagnostics run, bind them. Do not claim allfour configurations from onlytwo new runs.',
    'prior_target_bytes':{'Value':24,'ScriptObject':216,'CallbackKind':16,'CallbackRecord':24,'State':256,'Runtime_default':1808,'Runtime_test262_host':1872}},
 'functional':['New focused25 groups must pass against exact frozen source before claiming planned public140 calls/private78 attempts/fourreadbacks completed. Keep any failed attempts/corrections with additive lineage.',
  'Parent eligibility differs: public15 use existing APIs and observed missingmethod; private10 complete module needs new helper APIs and has no parent execution claim.'],
 'strict_release':['Both final full configured suites, fmt and strict Clippy need terminal source-bound receipts; no forecast counted as actual.',
  'Rebuilt ordinary and test262-host Rust1.88 adapters must have hash/bytes/build command/final source linkage and be the actual report binaries.'],
 'claims':['Logical work/accounted heap are not CPU instructions, RSS or a universal physical allocator bound.','No fullECMAScript/webcompatibility, security audit, Chromium speed, newTryupstream profile or unobserved remoteCI result.']}
write('required-checks.json',{'status':'candidate_validation_pending','checks':checks})
contracts=[D/'root/selection-1.json',D/'public-contract-1/source-ready.json',D/'public-contract-1/literals-ready.json',
 D/'private-contract-1/contract-ready.json',D/'private-contract-1/source-ready.json',D/'private-review-1/review.json',
 D/'migrations-1/source-ready.json',D/'migration-census-1/source-ready.json',D/'production-1/source-ready.json',D/'source-parent.json']
write('scaffold-ready.json',{'status':'scaffold_ready_candidate_outcomes_pending','base':'7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9',
 'contracts':[binding(p) for p in contracts],
 'derived':[binding(O/n) for n in ['rust-roster-contract.json','profile-contract.json','parent-public-observation.json','required-checks.json','prepare.py']],
 'authorship':'Reviewer authored private expectations and migration census; root independently peered private payload. Final review will independently read execution records and compare them to frozen contracts, not certify independent authorship of those private tests.',
 'execution':'Read-only retained logs/JSON and standalone stdlib calculations only. No candidate outcome or project execution claimed.'})
print(json.dumps(binding(O/'scaffold-ready.json'),indent=2))
