"""Independent source/hash/arithmetic review; no project import or execution."""
from pathlib import Path
from collections import Counter
import difflib
import hashlib
import json
import re
import subprocess

D=Path('/tmp/eris-promise-try-runtime-plan-1')
O=Path(__file__).parent
P=D/'production-1'
W=D/'worktree'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'

def digest(b):return hashlib.sha256(b).hexdigest()
def bind(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':digest(b)}
def read(p):return json.loads(Path(p).read_bytes())
def check_ref(ref):assert bind(ref['path'])=={k:ref[k] for k in ['path','bytes','sha256']}
def write(name,obj):
    p=O/name;assert not p.exists();p.write_text(json.dumps(obj,indent=2)+'\n');return bind(p)

seal=read(P/'source-ready.json')
assert bind(P/'source-ready.json')['sha256']=='93bd8dbf6d821c4dda07eb39415fb1191fd5b0eba4f872b0c77ea67b64a68866'
selection=read(D/'root/selection-1.json')
assert seal['base']==selection['base']==BASE
for key in ['selection','source_parent','independent_public_literals','independent_private_contract',
            'public_conversion','accounting_contract','before_snapshots','edit_manifest',
            'stage_and_ownership_proof','preauthor_recipe','author']:
    check_ref(seal[key])
for key in ['selected_body_contract','ownership_proof','materialization','public_selection']:
    check_ref(selection[key])
private_seal=read(Path(seal['independent_private_contract']['path']))
check_ref(private_seal['contract'])
private=read(private_seal['contract']['path'])
assert len(private['groups'])==10
public=read(D/'public-contract-1/roster.json')
assert public['semantic_groups']==12 and public['terminal_groups']==3
parent=read(D/'source-parent.json')['source_sha256']
edits=read(P/'edit-manifest.json')['edits']
assert len(edits)==8
expected_paths=set(selection['planned_source_paths'])
assert len(expected_paths)==7 and {row['relative_path'] for row in seal['files']}==expected_paths

def mask_rust(s):
    """Mask comments and literal contents while preserving offsets for brace extraction."""
    out=list(s);i=0;n=len(s)
    def hide(start,end):
        for j in range(start,end):
            if s[j]!='\n':out[j]=' '
    while i<n:
        start=i
        if s.startswith('//',i):
            j=s.find('\n',i);i=n if j<0 else j;hide(start,i);continue
        if s.startswith('/*',i):
            depth=1;i+=2
            while depth and i<n:
                if s.startswith('/*',i):depth+=1;i+=2
                elif s.startswith('*/',i):depth-=1;i+=2
                else:i+=1
            assert depth==0;hide(start,i);continue
        raw=re.match(r'(?:br|r)(\#*)"',s[i:])
        if raw:
            end='"'+raw.group(1);j=s.find(end,i+raw.end());assert j>=0
            i=j+len(end);hide(start,i);continue
        if s[i]=='"':
            i+=1
            while i<n:
                if s[i]=='\\':i+=2
                elif s[i]=='"':i+=1;break
                else:i+=1
            hide(start,i);continue
        if s[i]=="'":
            char=re.match(r"'(?:\\(?:u\{[0-9a-fA-F_]+\}|x[0-9a-fA-F]{2}|.)|[^'\\\n])'",s[i:])
            if char:i+=char.end();hide(start,i);continue
        i+=1
    return ''.join(out)

def functions(s):
    masked=mask_rust(s);counts=Counter();result={}
    for m in re.finditer(r'\bfn\s+([A-Za-z_][A-Za-z_0-9]*)\s*(?:<|\()',masked):
        name=m.group(1);start=m.start();opening=masked.find('{',m.end())
        semi=masked.find(';',m.end())
        if semi>=0 and (opening<0 or semi<opening):continue
        assert opening>=0,name
        depth=1;i=opening+1
        while depth:
            assert i<len(masked),name
            if masked[i]=='{':depth+=1
            elif masked[i]=='}':depth-=1
            i+=1
        index=counts[name];counts[name]+=1
        result[(name,index)]=s[start:i]
    return result

new_functions={'install_promise_try_intrinsic','promise_try','promise_try_arguments'}
allowed_changed={'src/script.rs':{'initialize_intrinsics'},
                 'src/script/promises/semantics.rs':{'promise_native_operation'},
                 'src/script/machine/calls.rs':{'invoke_native'}}
rows=[];protected=[];changed_functions=[];new_observed=[];texts={}
for row in seal['files']:
    rel=row['relative_path']
    for key in ['before','raw','diff']:check_ref(row[key])
    before=Path(row['before']['path']).read_bytes();raw=Path(row['raw']['path']).read_bytes()
    assert digest(before)==parent[rel]
    git=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
    assert git==before,rel
    a=before.decode();b=raw.decode();texts[rel]=(a,b)
    expected_diff=''.join(difflib.unified_diff(a.splitlines(True),b.splitlines(True),fromfile=rel,tofile=rel))
    assert Path(row['diff']['path']).read_text()==expected_diff,rel
    selected=[e for e in edits if e['path']==rel]
    composed=a
    for e in selected:
        assert composed.count(e['before'])==e['count']==1
        composed=composed.replace(e['before'],e['after'],1)
    assert composed==b,rel
    recovered=b
    for e in reversed(selected):
        assert recovered.count(e['after'])==1
        recovered=recovered.replace(e['after'],e['before'],1)
    assert recovered==a,rel
    oldfn=functions(a);newfn=functions(b)
    assert not set(oldfn)-set(newfn)
    for key,body in oldfn.items():
        if newfn[key]==body:
            protected.append({'path':rel,'name':key[0],'ordinal':key[1],'sha256':digest(body.encode())})
        else:
            assert key[0] in allowed_changed.get(rel,set()),(rel,key)
            changed_functions.append({'path':rel,'name':key[0],'ordinal':key[1]})
    for key in set(newfn)-set(oldfn):
        assert key[0] in new_functions,(rel,key)
        new_observed.append({'path':rel,'name':key[0]})
    rows.append({'relative_path':rel,'before':row['before'],'raw':row['raw'],'diff':row['diff'],
                 'published_git_exact':True,'exact_edit_inverse':True,'old_functions':len(oldfn),'new_functions':len(newfn)-len(oldfn)})
assert len(changed_functions)==3 and len(new_observed)==3
assert {x['name'] for x in new_observed}==new_functions

# Independently derive installer work and symbolic heap from unchanged helpers.
def tree(n):
    if n==0:return 0,0
    cap=(n+1)//2;height=1
    while cap>=6:cap//=6;height+=1
    return min(n,11*height),height
def moves(n):return n+8 if n<11 else 28*(tree(n)[1]+1)
def property_work(n,length,grow):return tree(n)[0]*(1+length)+moves(n)+(1+2*n if grow else 1)
work=12;prefixes=[work]
for text in ['length','name','try']:
    work+=8+2*len(text);prefixes.append(work)
for cost in [3,8,1,property_work(0,6,False),property_work(1,4,False),8+len('Promise.try')]:
    work+=cost;prefixes.append(work)
spare=work+property_work(11,3,False);growth=work+property_work(11,3,True)
assert prefixes==[12,32,48,62,65,73,74,83,98,117]
assert (spare,growth)==(246,268)
constant=sum(64+4*len(t) for t in ['length','name','try'])+72+(256+4*6)+(256+4*4)+(32+len('Promise.try'))+(256+4*3)
assert constant==1179
assert tree(11)==(11,2) and moves(11)==84

# Independently verify ordered admission and branch topology in the three additions.
body=functions(texts['src/script/promises/semantics.rs'][1])[('promise_try',0)]
ordered=['self.work(16)?;','if !js_object(&constructor)','self.work(1)?;',
         'args.first().cloned().unwrap_or(Value::Undefined)','self.promise_try_arguments(args.get(1..).unwrap_or(&[]))?',
         'match self.call(callback, arguments, Value::Undefined, doc)',
         'Ok(value) => self.promise_resolve_with_constructor(constructor, value, doc)',
         'Err(error) if error.is_resource_limit() || error.is_unsupported() => Err(error)',
         'self.new_promise_capability(constructor, doc)?','self.exception_value(error)?',
         'self.promise_arguments([reason])?','self.call(reject, arguments, Value::Undefined, doc)?','Ok(promise)']
positions=[body.index(x) for x in ordered];assert positions==sorted(positions)
assert 'observe_microtask_failure' not in body and '.clone()' not in body
tail=functions(texts['src/script/promises/factories.rs'][1])[('promise_try_arguments',0)]
tail_order=['self.work(8)?','arguments.len()','count > 65_536','mul(3, count)?',
            'add(32, mul(count, size_of::<Value>())?)?','self.work(work)?','self.charge(bytes)?',
            'Vec::new()','.try_reserve_exact(count)','for value in arguments','values.push(value.clone())',
            'Ok(values)','self.observe_microtask_failure(result)']
positions=[tail.index(x) for x in tail_order];assert positions==sorted(positions)
assert tail.count('.clone()')==1
install=functions(texts['src/script/promises/install.rs'][1])[('install_promise_try_intrinsic',0)]
install_order=['self.work(12)?','invalid Promise constructor','Promise metadata missing',
               'bag.values.len() != 11','self.dom_proto_text("length")?',
               'self.dom_proto_text("name")?','self.dom_proto_text("try")?',
               'self.work(3)?','self.promise_intrinsic_method("Promise.try", key.clone(), 1, [&length, &name])?',
               'self.dom_proto_property(owner, key.into(), Property::data(method, true, false, true))']
positions=[install.index(x) for x in install_order];assert positions==sorted(positions)

# Preserve all limit/type declarations through the exact inverse, and bind
# additional unchanged entry/queue/bootstrap helpers directly to published blobs.
extra=[]
for rel in ['src/script/microtasks.rs','src/script/dom_bindings.rs']:
    b=subprocess.check_output(['git','show',BASE+':'+rel],cwd=W)
    assert digest(b)==parent[rel]
    p=O/'parent'/rel;p.parent.mkdir(parents=True,exist_ok=True);assert not p.exists();p.write_bytes(b)
    extra.append({'relative_path':rel,'copy':bind(p)})
limits=re.findall(r'^const (MAX_[A-Z_]+|BOOTSTRAP_STEPS):[^\n]+$',texts['src/script.rs'][0],re.M)
assert limits
assert re.findall(r'^const (?:MAX_[A-Z_]+|BOOTSTRAP_STEPS):[^\n]+$',texts['src/script.rs'][0],re.M)==re.findall(r'^const (?:MAX_[A-Z_]+|BOOTSTRAP_STEPS):[^\n]+$',texts['src/script.rs'][1],re.M)

checks=write('checks.json',{
 'status':'clear source checks','production_paths':rows,'exact_edits':8,
 'old_function_body_hashes':protected,'old_functions_preserved':len(protected),
 'changed_existing_functions':changed_functions,'new_functions':new_observed,
 'new_types_fields_callback_tags':False,'limits_exact':limits,'additional_published_sources':extra,
 'installer':{'prefix_work':prefixes,'spare_work':spare,'growth_work':growth,
              'owner11_tree':list(tree(11)),'owner11_moves':moves(11),
              'spare_final_property_work':property_work(11,3,False),'growth_final_property_work':property_work(11,3,True),
              'heap_spare':'A+D+2K+4Bpp+N+1179','heap_growth':'A+D+14K+4Bpp+N+1179',
              'upfront_heap':'sizeof(ScriptObject)','metadata_bag':756,'owner_order_after':12,
              'qualification':'Static logical-accounting derivation, not observed target allocation/capacity or CPU cost.'},
 'body':{'public_prefix':'33+3*n','private_prefix':'25+3*n','tail_heap':'32+n*sizeof(Value)',
         'callback_clone_after_guard':True,'terminal_before_capability':True,'normal_helper_direct_return':True,
         'error_conversion_after_capability':True,'no_later_abrupt_retry':True,'public_and_tail_observers_preserved':True},
 'hold_bindings':{k:seal[k] for k in ['selection','source_parent','independent_public_literals','independent_private_contract','public_conversion','accounting_contract']},
 'activities':'Read-only Git and stdlib source/hash/JSON/arithmetic. No project execution, imports, compiler, test, formatting or live writes.'})

review=write('review.json',{
 'status':'clear','findings':[],
 'production':bind(P/'source-ready.json'),'selection':bind(D/'root/selection-1.json'),
 'checks':checks,'audit_source':bind(__file__),
 'independent_contracts':[seal['independent_public_literals'],seal['independent_private_contract']],
 'source_assessment':[
  'All seven before files are exact published 7149ab72 blobs and selected parent hashes. All diffs independently regenerated; eight selected inverse edits recover every before byte.',
  'Exactly three new functions and three narrowly changed old functions. Every other parsed old function body in these seven files is byte-exact; no tests/registrations or other production paths are in this hold.',
  'Receiver object guard precedes callback ownership and call; object receivers are not prematurely IsConstructor-checked. Callback is called synchronously with Undefined this and copied ordered tail values.',
  'Normal completion delegates directly to unchanged PromiseResolve, preserving genuine same-constructor identity before constructor validation and synchronous constructor-getter errors.',
  'Terminal callback errors bypass capability creation. Ordinary callback errors survive NPC, then unchanged exception_value; original thrown Values move exactly. NPC, conversion, argument and reject failures propagate once outside the callback match.',
  'Body16 plus callback1 and tail8+3n follow the selected ownership plan. Incoming constructor ownership is caller-funded before body refusal; copied callback/completion/capability handles and ignored reject result have prepaid cleanup roles.',
  'Tail helper validates the selected 65536 bound and all checked arithmetic/work/heap/reserve admissions before copying any Value. Its observer covers direct-helper failure. Zero retains the selected8/32 envelope; no public quota increase is implied.',
  'The existing operation wrapper supplies public8 and sticky failure observation. Old Call first-tick/stack behavior, singleton/pair helper, PromiseResolve, NPC and Error materialization bodies remain exact.',
  'Late installer pays12 before saved-constructor/owner11 checks, then static texts and clone3. It creates one bag after withResolvers and publishes owner.try last with arity1 and selected descriptors. Existing IDs and old installer bodies remain exact.',
  'Independent installer arithmetic yields246 spare/268 growing work and the selected typed heap formulas, including the count11 B-tree threshold and optional12K order growth. Initial object reservation adds one ScriptObject without changing author/heap/bootstrap limits.'
 ],
 'public_contract_alignment':'Read against the frozen12 semantic groups and3 terminal families, including nonconstructor genuine identity, getter/thenable distinction, captured receiver poisoning, constructor/reject precedence, exact arguments and queued terminal suspension. No frozen expectation was changed.',
 'private_contract_alignment':'Read all ten frozen private groups for selected entry, tail, installer, materialization and observer boundaries. This is a production-to-contract check, not a peer review or execution of its eventual Rust test conversion.',
 'limits':['No compile, runtime, layout, allocator-capacity or test outcome is inferred from this source review.',
           'Logical fee envelopes are selected contracts, not instruction counts or complete physical-allocation accounting.',
           'Existing Error conversion allocation limitations remain unchanged and explicitly qualified.',
           'No host decoder, Python tooling, corpus, baseline, old helper tariff, Runtime/State field or CallbackKind expansion.']})
print(json.dumps(review))
