"""Read published Rust blobs only. This does not import or execute project code."""
from pathlib import Path
import hashlib,json,re,subprocess
D=Path('/tmp/eris-promise-try-runtime-plan-1')
W=D/'worktree'
O=D/'migration-census-1'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
inventory=json.loads((D/'source-parent.json').read_text())
assert hashlib.sha256((D/'source-parent.json').read_bytes()).hexdigest()=='d007628849566151227641aad4381c71e1393f8d4b5208836a114cc4072776f2'
inventory_paths=sorted(p for p in inventory['source_sha256'] if p.endswith('.rs'))
tracked=subprocess.run(['git','-C',str(W),'ls-tree','-r','--name-only',BASE],stdout=subprocess.PIPE,check=True).stdout.decode().splitlines()
paths=sorted(p for p in tracked if p.endswith('.rs'))
outside_inventory=[p for p in paths if p not in inventory_paths]
assert len(outside_inventory)==35
process=subprocess.run(['git','-C',str(W),'cat-file','--batch'],input=''.join(BASE+':'+p+'\n' for p in paths).encode(),stdout=subprocess.PIPE,check=True)
data=process.stdout; offset=0; blobs={}; joins=[]
for path in paths:
    end=data.index(b'\n',offset); header=data[offset:end].decode().split();assert header[1]=='blob'
    size=int(header[2]);blob=data[end+1:end+1+size];assert data[end+1+size:end+2+size]==b'\n'
    offset=end+2+size
    sha=hashlib.sha256(blob).hexdigest()
    if path in inventory['source_sha256']:assert sha==inventory['source_sha256'][path]
    blobs[path]=blob;joins.append({'path':path,'bytes':len(blob),'sha256':sha,'git_blob':header[0],
                                 'selected_inventory_join':path in inventory['source_sha256']})
assert offset==len(data)
previous=json.loads(Path('/tmp/eris-promise-with-resolvers-runtime-plan-1/migrations-1/test-roster.json').read_text())
selected=sorted([row['path'] for row in previous['files']]+['src/script/promises/with_resolvers_quota_tests.rs'])
assert len(selected)==17
pattern=re.compile(r'101_?31[12]|898_?688|1_?768_?271|\b(?:756|757|767|768)\b|finish_bootstrap|initialize_bootstrap|withResolvers.*(?:join|every)|getOwnPropertyNames\((?:P|Promise)\)|objects\[constructor\]\.values\.len\(\)')
hits=[]
for path,blob in blobs.items():
    text=blob.decode();lines=text.splitlines();fn=None;fn_line=None
    found=[]
    for number,line in enumerate(lines,1):
        match=re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?fn\s+(\w+)\s*[<(]',line)
        if match:fn=match[1];fn_line=number
        if pattern.search(line):found.append({'line':number,'function':fn,'function_line':fn_line,'text':line})
    if found:hits.append({'path':path,'selected_migration_path':path in selected,'hits':found})
for path in selected:
    target=O/'parent'/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(blobs[path])
(O/'published-rust-bindings.json').write_text(json.dumps({'base':BASE,'rust_files':len(paths),'files':joins,
    'selected_inventory_rust_files':len(inventory_paths),'additional_published_rust_scanned':outside_inventory},indent=2)+'\n')
(O/'scan-hits.json').write_text(json.dumps({'patterns':pattern.pattern,'files':hits},indent=2)+'\n')
print(json.dumps({'rust_files':len(paths),'selected_paths':len(selected),'hit_paths':len(hits),
                  'nonselected':[{ 'path':x['path'],'hits':x['hits']} for x in hits if not x['selected_migration_path']]},indent=2))
