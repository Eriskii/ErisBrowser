"""Author source-only migration census; no project imports or execution."""
from pathlib import Path
import hashlib,json,re
D=Path('/tmp/eris-promise-try-runtime-plan-1'); O=D/'migration-census-1'
BASE='7149ab7260dd554a833f3cdd1c6dfc62ed24f9b9'
def binding(p):
    p=Path(p);b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def dump(name,data):
    (O/name).write_text(json.dumps(data,indent=2)+'\n')
def source(path):return (O/'parent'/path).read_text()
rows=[]
def add(path,functions,lines,change,preserve):
    text=source(path);ls=text.splitlines(); declarations={}
    for number,line in enumerate(ls,1):
        match=re.match(r'fn (\w+)',line)
        if match:declarations[match[1]]=number
    assert all(name in declarations for name in functions),(path,functions)
    assert all(0<n<=len(ls) for n in lines)
    rows.append({'path':path,'functions':[{'name':n,'line':declarations[n]} for n in functions],
                 'touchpoints':[{'line':n,'text':ls[n-1]} for n in lines],
                 'prospective_change':change,'preserve':preserve})

add('src/script/bootstrap_tests.rs',
 ['bootstrap_convenience_and_try_paths_separate_work_and_retain_heap'],[200,201,202],
 'Append the selected late-Try work explanation; whole-bootstrap remaining898688→898420 and object count756→757 on the proposed growing branch.',
 'Keep the public100000 reset, shared cumulative heap comparison, finite1m bootstrap allowance, all dynamically measured late-boundary tests and earlier-stage assertions.')
add('src/script/dom_bindings/identity_tests.rs',
 ['dom_parent_bootstrap_reports_actual_remaining_budget_and_capacities'],[950],
 'Complete-realm objects756→757 only.', 'Keep all local DOM installer fees, IDs, layouts, native/prototype/global counts and raw diagnostics.')
add('src/script/node_data/key_cache_fee_tests.rs',
 ['node_borrowed_factory_keeps_the_existing_eager_object_reservation_guard'],[271,286],
 'Both complete Runtime fixture object len/capacity pairs756/756→757/757 on the observed exact-reservation target.',
 'Keep cold eager-reservation refusal and all existing Node factory work/heap expectations; no extra old-helper charge.')
add('src/script/node_data/key_cache_tests.rs',
 ['node_accessor_keys_share_existing_constructor_payloads_with_four_distinct_bags'],[129],
 'Whole-realm objects756→757.', 'Keep four bags, identities, shared key pointers and all existing IDs.')
add('src/script/node_data/method_key_tests.rs',
 ['node_method_keys_share_constructor_payloads_after_preserving_all_nine_bags'],[192],
 'Whole-realm objects756→757.', 'Keep nine bags, methods, descriptors and pointer-sharing controls unchanged.')
add('src/script/processing_instruction/display_key_tests.rs',
 ['startup_headroom_raw_observation_precedes_the_frozen_101312_work_witness'],[203,216,217,227,228],
 'Rename the explicit boundary suffix101312→101580; whole objects/minimum capacity756→757, work101312→101580, remainder898688→898420 after selection and observation.',
 'Keep raw observation before assertions, maps300/26/213, clean state and all Title/PI key ownership checks.')
add('src/script/processing_instruction/key_cache_tests.rs',
 ['cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_101312_work_boundary'],[264,278,279,280,295],
 'Rename the explicit boundary suffix; preserve101311 as refusal and change retained101312 success to refusal. Add101579 refusal and101580 success with0 remaining; default1m remainder898420; successful objects757.',
 'Keep every older injected raw input (including99693/99694/100000/100796/100797/100985/100986), public100000 reset and original metadata assertions.')
add('src/script/promises/install_tests.rs',
 ['replay_fixture','promise_installer_exact1570_and_one_short1569_precede_global_cache_publication',
  'promise_installer_exact_helper_heap_and_one_short_keep_refused_realm_unpublished',
  'promise_full_raw101312_and_public_reset_preserve_empty_paid_arenas'],[79,85,86,108,142,158,168,169,170,182],
 'Replay starts from complete757 objects, appends exactly the same11 bags, so final767→768. Whole-bootstrap boundary gets the retained101312 refusal and new101579/101580 rows, remainder898420 and757/757; rename only its whole-boundary test.',
 'Keep11 replay slots, original standalone1570/1569 and helper_bytes unchanged; no Try installation in this isolated old installer replay, no shift to old saved production IDs or map counts.')
add('src/script/promises/shared_key_tests.rs',
 ['replay','consumer_fixture','shared_key_producer_exact331_and_heap_publish_only_after_full_admission',
  'shared_key_consumer_exact1532_and_heap_preserve_the_published_producer_on_refusal',
  'shared_key_pair_exact1863_and_heap_keep_late_partial_state_unreturned',
  'shared_key_producer_prepays_retained_cleanup_before_either_key_can_exist',
  'standalone_guard_then_key_order_and_shared_move_have_distinct_exact_prefixes'],
 [52,69,70,82,149,153,200,257,283,285,407],
 'Replay complete prefix756→757; retain12 extra slots so minimum capacity768→769; new producer owner756→757, after-producer length757→758, complete pair768→769, indexed partial bag756→757. Update only historical boundary comment to retain former refusals and name101580.',
 'Keep queue producer331, shared consumer1532, pair1863, all prefix cuts/helper_bytes, removal of late AggregateError global and order210/211, retained original metadata bags, registry entries and no Any/withResolvers/Try replay.')
add('src/script/promises/shared_key_identity_tests.rs',
 ['shared_job_key_payloads_preserve_all_eleven_function_bags_and_existing_ids',
  'shared_job_keys_keep_public_descriptors_mutation_and_callable_identity_independent'],[66,67,93,117],
 'Whole objects756/756→757/757; saved Promise constructor property count11→12; append ,try to the exact public own-name literal after withResolvers.',
 'Keep the eleven shared-key bag roster740,741,743..751, Promise prototype742, all old method identities and pointer-sharing checks. The title all_eleven_function_bags remains accurate and must not be renamed.')
add('src/script/promises/any_quota_tests.rs',
 ['any_raw_startup_observes_physical_order_branch_and_keeps_public_reset'],[247,250,251,257,259,260,262,263,268,270,271],
 'After the already isolated Any and withResolvers installers, observe current owner order len/cap11, select late-Try246/268 from physical spare/growth, execute only that late stage, assert its separately selected typed heap, then compare full raw work/heap and757/757.',
 'Keep before_any threshold100797, stage objects754→755, owner9→10, Any171/189 and typed helper heap exactly; keep withResolvers306/326 and bag755. Upfront new object slot was already paid by initial preparation, so stage delta excludes S.')
add('src/script/promises/with_resolvers_quota_tests.rs',
 ['with_resolvers_startup_records_physical_growth_and_public_budget_reset'],[267,274,277,279,281,282,283,287,288,289,290,291],
 'After isolated withResolvers measurement and installed(runtime,true), capture its owner11 len/cap and run the later Try stage before the whole-realm raw comparison. Add separately measured late work/heap; full raw objects757 and minimum capacity757.',
 'Do not globally replace756: before_with_resolvers capacity>=756, installed() length756, owner10 guard and11 after success, native metadata755,306/326 cuts, refusal prefixes, result156 and public8/outer3 remain exact. Only the whole-startup observer changes.')
add('src/script/text_operations/key_cache_tests.rs',
 ['text_metadata_keys_preserve_both_bags_before_sharing_constructor_payloads',
  'text_metadata_keys_raw_bootstrap_uses_101312_work_and_preserves_public_reset'],[116,117,228,243,244,245,260,261,276],
 'Complete-object checks756→757. Rename explicit boundary101312→101580; retain101311/101312 as refusals, append101579 refusal/101580 success/default898420.',
 'Keep all older inputs, shared Text pointers, descriptors, literal public behavior, successful public100000 and unchanged registry/global counts.')
add('src/script/typed_array/tests.rs',
 ['typed_array_bootstrap_reports_types_and_reconciles_installation_ledger'],[165,166,186,213,217],
 'Append a separate try_added=S+A+D+14K+4Bpp+N+1179 for proposed len11 growing branch; subtract268 after existing -326 in work ledger; add try_added after with_resolvers_added; fullobjects756/756→757/757. Projected extra7595bytes on recorded x86_64 types.',
 'Keep every existing cumulative term including +BOOTSTRAP_STEPS-MAX_STEPS before large deductions, Any and withResolvers deltas, symbolic type sizes and maps300/26/213. Do not flatten the ledger into one unexplained final literal.')
add('src/script/test262_host/quota_tests.rs',
 ['host_actual_inline_layout_and_inactive_bootstrap_are_observed_without_new_allowance'],[405,406],
 'Complete startup remainder898688→898420 and objects756→757.',
 'Keep host actual type sizes, inactive host state, hook/setup/reporting budgets and default public author allowance unchanged.')
add('src/script/promise_semantic_tests.rs',
 ['promise_selected_surface_brand_newtarget_and_callback_controls'],[237],
 'Append ,try after withResolvers in the one full constructor own-name literal.',
 'Keep every existing callback, descriptor, species, brand and constructor behavior check and both modes.')
add('src/script/promise_race_semantic_tests.rs',
 ['promise_race_metadata_and_nonconstructor'],[146],
 'Append ,try after withResolvers in the one full constructor own-name literal.',
 'Keep all Race metadata, nonconstructibility, errors and both-mode assertions.')

assert len(rows)==17
rosters=[]
for row in rows:
    names=re.findall(r'#\[test\]\s*fn\s+(\w+)\(',source(row['path']))
    rosters.append({'path':row['path'],'groups':len(names),'names':names})
assert sum(r['groups'] for r in rosters)==135
renames=[{'path':row['path'],'before':fn['name'],'after':fn['name'].replace('101312','101580')}
         for row in rows for fn in row['functions'] if '101312' in fn['name']]
assert len(renames)==4
hits=json.loads((O/'scan-hits.json').read_text())['files']
exclusions=[]
for row in hits:
    if row['selected_migration_path']:continue
    path=row['path']
    if path=='src/script/aggregate_error/install/tests.rs':
        reason='Stops at earlier99694 boundary; original752/753 bags,1103 work and typed17554 remain exact. Existing minimum reserved capacity>=754 tolerates later prepaid slot; no new map entries.'
    elif path in ('src/script.rs','src/script/typed_array/intrinsics.rs'):
        reason='Production implementation/initializer text, outside historical-test migration scope.'
    elif path.startswith('src/script/'):
        reason='Source-reviewed raw diagnostic, symbolic BOOTSTRAP_OBJECTS, dynamically derived current boundary or invariant/map-count assertions; no fixed final work/heap/object literal requires migration.'
    else:
        reason='Unrelated graphics/probe numeric literal or immutable archived evidence, not a scripting startup witness.'
    exclusions.append({'path':path,'functions':sorted({h['function'] for h in row['hits'] if h['function']}),'reason':reason})
exclusions.extend([
 {'path':'src/script/array_buffer/bootstrap/tests.rs','functions':['stage'],'reason':'Existing stage retains BEFORE_REGISTRY, removes only late AggregateError prototype, truncates objects to old first bag. Try adds no registry/prototype/global entry, so no new exclusion or old25-prototype guard migration.'},
 {'path':'src/script/data_view/bootstrap/tests.rs','functions':['stage'],'reason':'Same earlier-stage truncate and explicit AggregateError prototype exclusion; later Try bag automatically disappears with truncation and maps remain unchanged.'},
 {'path':'src/script/promises/with_resolvers_quota_tests.rs','functions':['before_with_resolvers','installed','with_resolvers_installer12_guards_precede_all_allocations','with_resolvers_installer306_or326_exact_work_and_heap_publish_last'],'reason':'Isolated setup stops before Try. Preserve owner10, success owner11, metadata755, partial objects755/756, old306/326 and helper heaps. Only whole-startup observer is selected.'},
 {'path':'src/script/promises/any_quota_tests.rs','functions':['before_any','installed','any_late_installer171_or189_work_cuts_preserve_all_prior_ids','any_late_installer_typed_heap_exact_and_one_short_precede_owner_publication','any_late_installer12_admission_and_shape_guards_precede_text_or_method_allocation'],'reason':'Isolated setup stops before withResolvers/Try. Preserve owner9/10, bag754, objects754/755,171/189 and typed heap. Only whole-startup observer is selected.'}
])
result={
 'status':'source_only_census_ready_unselected_arithmetic', 'base':BASE,
 'scope':'Historical Rust-test migration census for one independent late Promise.try method after withResolvers; no implementation or executable test payload authored.',
 'selected_inventory':binding(D/'source-parent.json'),
 'coverage':{'published_tracked_rust_files_scanned':598,'selected_inventory_rust_joins':563,
             'additional_published_rust_scanned':35,'note':'34 additional files are immutable docs/evidence Rust snapshots; the other is tools/vulkan-probe/src/main.rs. They were scanned but are not migration targets.',
             'prospective_migration_paths':17,'retained_groups_in_those_paths':135,'proposed_explicit_boundary_renames':4,
             'qualification':'135 is the complete preserved roster across the17 paths, not135 newly affected assertions or new tests. Text scan plus bounded source review identifies concrete fixed-witness and fixture dependencies; candidate/full validation remains required.'},
 'proposal_not_selection':{'installer_entry':12,'owner_property_count_before':11,'spare_work':246,'growing_work':268,
   'metadata_bag':756,'upfront_extra_objects':1,'final_objects':757,'final_owner_property_count':12,
   'helper_heap_spare':'A+D+2K+4Bpp+N+1179','helper_heap_growing':'A+D+14K+4Bpp+N+1179',
   'whole_bootstrap_extra_heap_growing':'S+A+D+14K+4Bpp+N+1179',
   'recorded_x86_64_conditional_projection':{'added_work':268,'added_heap':7595,'raw_work':101580,'raw_remaining_of_one_million':898420,'allocated':1775866,'objects':757},
   'required_observation':'The published parent records constructor order11/11 and objects756/756. Candidate must print/check actual before/after order capacity and object capacity; projection is not an observed new execution or universal allocator/ABI promise.'},
 'rows':rows,'proposed_renames':renames,'unchanged_controls':exclusions,
 'global_preservation':['All old productive bag IDs remain unchanged; proposed Try appends756 only. Replay-fixture newly appended objects shift because their complete-runtime prefix grows.',
  'Saved AggregateError752/753, Any754, withResolvers755 and original Promise/DOM bags remain unchanged.',
  'No native/prototype/global map growth:300/26/213 remain. No Runtime/State/CallbackKind field or layout change is assumed or selected by this census.',
  'Keep public100000 author work, trusted1m bootstrap and cumulative8MiB heap limits; preserve all older raw work inputs as refusals instead of silently raising them.',
  'Raw comparisons in Any/withResolvers observers must complete later real stages in Rust-only setup, with a per-stage counter reset and physically selected branch; this does not resume author code or assert accounting rollback.',
  'New slotS belongs to upfront reserve; do not charge it again when replaying late installer helper after earlier preparation.'],
 'unresolved':['Root must select the installer envelope and API before any migration authoring.','Candidate physical branch/layout/startup counters are unmeasured in this task.','No test execution or overall pass prediction is made.']}
dump('census.json',result);dump('retained-roster.json',{'paths':17,'groups':135,'files':rosters,'proposed_renames':renames})
prior=Path('/tmp/eris-promise-with-resolvers-runtime-plan-1/validation/with-resolvers-candidate-1.log')
line=next(x for x in prior.read_text().splitlines() if x.startswith('withResolvers startup:'))
assert 'before_order=(10, 10) after_order=(11, 11)' in line and 'raw_objects=(756, 756)' in line
assert 'work=101312 remaining=898688 allocated=1768271 maps=(300, 26, 213)' in line
dump('parent-observation.json',{'source':binding(prior),'exact_line':line,'qualification':'Retained published BH target observation; later tools-only bases preserve Rust. No new Promise.try execution.'})
parents=[binding(p) for p in sorted((O/'parent').rglob('*.rs'))]
artifacts=[binding(O/n) for n in ['census.json','retained-roster.json','parent-observation.json','published-rust-bindings.json','scan-hits.json','scan-output.json','scan.py','seal.py']]
dump('source-ready.json',{'status':'source_ready','base':BASE,'scope':'17-path prospective historical migration census, all selected arithmetic unselected/unmeasured.',
 'source_parent':binding(D/'source-parent.json'),'artifacts':artifacts,'published_parent_snapshots':parents,
 'execution':'Standalone stdlib/hash/JSON and read-only Git only; no project imports/execution, implementation, candidate source inspection or live edits.'})
print(json.dumps(binding(O/'source-ready.json'),indent=2))
