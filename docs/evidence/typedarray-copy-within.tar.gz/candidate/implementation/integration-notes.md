# External copyWithin candidate

Apply only the three candidate paths after comparing the two existing beforeimages and confirming the new module is absent. They match published b46879dd in K at this seal. The tests and quota_tests child declarations intentionally require the independent files from Script and root before compilation. No formatter or project code has been run.

The separate metadata-migration hold predicts five existing test changes. Root must first measure raw bootstrap/site fees, then replay both original descriptor modes under their unchanged quota; preserve any failure before considering full validation. No pass forecast is made from the remaining1,241 work.

The candidate retains all old helpers and operation bodies. The new raw loop pays existing read/write/checked-offset tariffs. Every new stage is prepaid as described by the parent ledger. The 256-work driftsort route is a new separate envelope; old owner/sort rows and scratch allowance stay. Independent ledger/source peer is required before integration.

Recommended source peer inputs: candidate production3, diffs, preservation.json, ../ledger.json, ../metadata-sort-proof.md and exact pinned Rust paths in ../inputs/source-bindings.json. Root alone owns formatting, compilation, tests and publication.
