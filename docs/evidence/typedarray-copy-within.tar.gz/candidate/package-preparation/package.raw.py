"""Root-run evidence publisher; never imports project code or runs an engine.

Selection names completed pending artifacts explicitly. A clear comparison is
distinct from healthy conformance: all resource observations remain published.
"""
from collections import Counter
from pathlib import Path
import gzip
import hashlib
import io
import json
import math
import os
import re
import statistics
import subprocess
import tarfile
import tomllib

K = Path(__file__).resolve().parent
J = Path('/tmp/eris-own-keys-one-pass-1')
W = K / 'worktree'
B = K / 'visited-pair/benchmark'
BASE = 'b46879dd20ee1b04b16a0baac5c33b35264db60b'
CASES = ('same1', 'same2', 'same3', 'same12', 'varied12', 'hidden-chain', 'long2', 'long3')
UNITS = (3, 6, 9, 36, 90, 20, 1026, 1539)
inputs = {}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def relative(root, name):
    path = Path(name)
    assert isinstance(name, str) and name and not path.is_absolute() and '..' not in path.parts
    return root / path


def payload(path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    row = dict(path=str(path), bytes=len(data), sha256=sha(data))
    assert inputs.setdefault(str(path), row) == row, ('changed input', path)
    return data


def read(path):
    return json.loads(payload(path))


def bound(row):
    data = payload(Path(row['path']))
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']


def receipt(path, expected_exit=0, passed=None, protocols=None):
    value = read(path)
    assert value['exit'] == expected_exit, path
    log = payload(path.parent / value['log'])
    assert sha(log) == value['sha256'], path
    if passed is not None:
        rows = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed;', log)
        assert rows and sum(int(a) for a, _ in rows) == passed
        assert all(int(b) == 0 for _, b in rows)
    if protocols is not None:
        assert re.search(rb'Ran ' + str(protocols).encode() + rb' tests? in ', log)
        assert re.search(rb'\nOK\s*$', log)
    return value


def tree(binding_path, root, count):
    value = read(binding_path)
    assert len(value['source_sha256']) == count
    for name, expected in value['source_sha256'].items():
        assert sha(payload(relative(root, name))) == expected, name
    return value


def statistics_for(rows):
    result = []
    for case in CASES:
        values = sorted(ns / 5 for name, ns in rows if name == case)
        assert len(values) in (21, 63)
        result.append(dict(case=case, samples=len(values),
                           median_ns_per_execute=statistics.median(values),
                           p95_ns_per_execute=values[math.ceil(.95 * len(values)) - 1]))
    return result


def benchmark(selection):
    summary_path = relative(K, selection['summary'])
    assert summary_path.parent.parent == B
    result = read(summary_path)
    assert result['status'] == 'complete' and result['rounds'] == 3
    assert result['literal_checks_before_any_timing'] == 48
    assert result['timed_execute_calls'] == 5040
    assert result['statistic_unit'] == 'nanoseconds per execute, from five-call sample totals'
    before = read(summary_path.parent / 'inputs-before.json')
    assert before == read(summary_path.parent / 'inputs-after.json')
    for key in ('benchmark',):
        for row in before[key]:
            bound(row)
    for key in ('source_bindings', 'binaries'):
        for row in before[key].values():
            bound(row)
    for rows in before['dependencies'].values():
        for row in rows:
            bound(row)
    bound(before['python_executable'])
    if before['wrapper'] is not None:
        bound(before['wrapper'])
    assert payload(B / 'before/Cargo.lock') == payload(B / 'after/Cargo.lock')
    manifests = [payload(B / phase / 'Cargo.toml').decode() for phase in ['before', 'after']]
    assert manifests[0].replace(str(B / 'before-engine'), 'ENGINE') == manifests[1].replace(str(W), 'ENGINE')
    parent_lock = tomllib.loads(payload(W / 'Cargo.lock').decode())['package']
    new_lock = tomllib.loads(payload(B / 'after/Cargo.lock').decode())['package']
    old_packages = {(p['name'], p['version'], p.get('source')): p for p in parent_lock}
    additions = []
    for package in new_lock:
        key = (package['name'], package['version'], package.get('source'))
        if key not in old_packages:
            additions.append(key)
        else:
            assert package.get('checksum') == old_packages[key].get('checksum')
    assert additions == [('eris-visited-pair-benchmark', '0.1.0', None)]
    assert set(selection['binaries']) == {'before', 'after'}
    binaries = {}
    for label, source_name in [('before', 'compiled-source-1.json'), ('after', 'compiled-source-2.json')]:
        record = read(relative(K, selection['binaries'][label]))
        row = dict(path=record['binary'], bytes=record['bytes'], sha256=record['sha256'])
        bound(row)
        assert before['binaries'][label] == row
        assert record['engine_source'] == str(K / source_name)
        assert record['engine_source_sha256'] == sha(payload(K / source_name))
        assert before['source_bindings'][label] == inputs[str(K / source_name)]
        source_root = B / 'before-engine' if label == 'before' else W
        roster = read(K / source_name)['source_sha256']
        actual = {row['path']: row['sha256'] for row in before['dependencies'][label]}
        assert len(actual) == len(before['dependencies'][label]) == len(roster)
        assert actual == {str(relative(source_root, name)): digest for name, digest in roster.items()}
        source_receipt = relative(K, record['benchmark_source'])
        assert sha(payload(source_receipt)) == record['benchmark_source_sha256']
        source_rows = read(source_receipt)['files']
        for item in source_rows:
            bound(item)
        assert str(B / 'src/main.rs') in {item['path'] for item in source_rows}
        build = receipt(relative(K, record['build']))
        assert '+1.88.0' in build['command'] and '--release' in build['command']
        assert '--locked' in build['command']
        binaries[label] = record
    assert binaries['before']['benchmark_source_sha256'] == binaries['after']['benchmark_source_sha256']
    for name in selection['successful_receipts']:
        receipt(relative(K, name))
    run_receipt = receipt(relative(K, selection['run_receipt']))
    command = run_receipt['command']
    assert str(B / 'run.py') in command
    for flag, expected in [('--before-binary', binaries['before']['binary']),
                           ('--after-binary', binaries['after']['binary']),
                           ('--before-source-binding', str(K / 'compiled-source-1.json')),
                           ('--after-source-binding', str(K / 'compiled-source-2.json')),
                           ('--output', str(summary_path.parent))]:
        assert command[command.index(flag) + 1] == expected
    pooled = {'before': [], 'after': []}
    schedule = [(0, 0, 'before'), (0, 1, 'after'), (1, 0, 'after'),
                (1, 1, 'before'), (2, 0, 'before'), (2, 1, 'after')]
    assert len(result['runs']) == len(schedule)
    for run, (round_number, position, label) in zip(result['runs'], schedule):
        assert (run['round'], run['position'], run['label']) == (round_number, position, label)
        assert run['returncode'] == 0 and run['timed_out'] is False
        bound(run['stdout']); bound(run['stderr'])
        assert run['stderr']['bytes'] == 0
        command = run['command']
        expected = [binaries[label]['binary'], str(round_number)]
        if before['wrapper'] is not None:
            assert Path(command[0]).resolve() == Path(before['python_executable']['path'])
            expected = [command[0], before['wrapper']['path'], *expected]
        assert command == expected
        stem = f'round-{round_number}-{position}-{label}'
        raw_receipt = read(summary_path.parent / (stem + '.json'))
        assert raw_receipt == {k: v for k, v in run.items() if k != 'statistics'}
        assert run['stdout']['path'] == str(summary_path.parent / (stem + '.stdout'))
        assert run['stderr']['path'] == str(summary_path.parent / (stem + '.stderr'))
        lines = payload(Path(run['stdout']['path'])).decode('ascii').splitlines()
        assert len(lines) == 178
        assert lines[0] == f'ERIS_VISITED_PAIR_BENCH\t1\t{round_number}\t21\t2\t5'
        assert lines[1:9] == [f'CHECK\t{case}\t{units}' for case, units in zip(CASES, UNITS)]
        assert lines[-1] == 'END\t168\t840'
        rows = []
        for line, (case, sample) in zip(lines[9:-1], [(c, i) for c in CASES for i in range(21)]):
            fields = line.split('\t')
            assert len(fields) == 5 and fields[:3] == ['ROW', case, str(sample)] and fields[4] == '5'
            ns = int(fields[3]); assert str(ns) == fields[3] and 0 < ns <= 300_000_000_000
            rows.append((case, ns))
        assert run['statistics'] == statistics_for(rows)
        pooled[label].extend(rows)
    assert sum(map(len, pooled.values())) == 1008
    assert result['statistics'] == {label: statistics_for(rows) for label, rows in pooled.items()}
    table = read(relative(K, selection['table']))
    assert [row['case'] for row in table['rows']] == list(CASES)
    for row, old, new in zip(table['rows'], result['statistics']['before'], result['statistics']['after']):
        for prefix, stats in [('before', old), ('after', new)]:
            assert row[prefix + '_median_ns'] == stats['median_ns_per_execute']
            assert row[prefix + '_p95_ns'] == stats['p95_ns_per_execute']
        assert math.isclose(row['median_change_percent'],
                            (new['median_ns_per_execute'] / old['median_ns_per_execute'] - 1) * 100,
                            rel_tol=1e-12, abs_tol=1e-12)
    return result, table, binaries


def main():
    selection = read(K / 'package-selection.json')
    assert set(selection) == {'historical', 'benchmark', 'reviews'}
    assert set(selection['reviews']) == {'observations', 'documentation', 'benchmark', 'package'}
    sources = tree(K / 'compiled-source-2.json', W, 291)
    assert sources['base'] == BASE
    source1 = tree(K / 'compiled-source-1.json', B / 'before-engine', 289)
    prior = tree(J / 'compiled-source-3.json', J / 'worktree', 284)
    adapter = read(K / 'candidate-adapter-1.json')
    bound(dict(path=str(K / adapter['binary']), bytes=adapter['bytes'], sha256=adapter['sha256']))
    assert adapter['source_binding'] == 'compiled-source-2.json'
    assert adapter['source_binding_sha256'] == sha(payload(K / adapter['source_binding']))
    assert adapter['full_suite'] == 'validation/full-native-1.json' and adapter['full_suite_passed'] == 2407
    assert adapter['build'] == 'validation/adapter-1.json'
    counts = {'copy-within-focused-1': 21, 'own-keys-focused-1': 75, 'metadata-focused-2': 7,
              'prior-pass-3': 1, 'full-native-1': 2407, 'full-default-1': 2250, 'script-198-1': 1393}
    checks = {name: receipt(K / 'validation' / (name + '.json'), passed=count)
              for name, count in counts.items()}
    for name in ['adapter-1', 'clippy-msrv-1', 'clippy-198-1', 'format-check-1', 'import-copy-within-1']:
        checks[name] = receipt(K / 'validation' / (name + '.json'))
    for name, count in [('protocols-1', 329), ('comparison-protocols-1', 11),
                        ('new-profile-comparison-protocols-1', 11)]:
        checks[name] = receipt(K / 'validation' / (name + '.json'), protocols=count)
    for name in ['clippy-msrv-1', 'clippy-198-1']:
        assert checks[name]['command'][-3:] == ['--', '-D', 'warnings']
    assert checks['format-check-1']['command'][-2:] == ['--', '--check']
    # Preserve the actual failed source-1 runs, rather than converting them to
    # prospective failure claims or letting later successes overwrite them.
    retained_failures = {name: receipt(K / 'validation' / (name + '.json'), expected_exit=code)
                         for name, code in [('prior-pass-1', 101), ('prior-pass-2', 101),
                                            ('metadata-focused-1', 101), ('candidate-format-1', 1),
                                            ('historical-comparison-1', 1)]}
    h = selection['historical']
    assert h['source'] == 'comparison-preparation/compare-2.py'
    historical = read(relative(K, h['report']))
    assert historical['status'] == 'clear' and historical['errors'] == historical['review_findings'] == []
    assert historical['after_adapter_sha256'] == adapter['sha256']
    assert historical['before_adapter_sha256'] == 'b366575d98cffdedbf20f5345ab44d11fb2d615d57ba7e7b94a30c756a38d8a9'
    summary = historical['summary']
    assert summary['profiles'] == 45 and summary['historical_profiles'] == 38
    assert summary['case_rows'] == 18298 and summary['control_rows'] == 4284 and summary['prior_pass_losses'] == 0
    assert summary['exact_case_rows'] == 18298 and summary['exact_control_rows'] == 4284
    assert summary['changed_case_rows'] == summary['changed_control_rows'] == 0
    for row in historical['inputs']:
        bound(row)
    h_run = receipt(relative(K, h['receipt']))
    assert h_run['command'] == ['python3', str(relative(K, h['source'])), '--selection', str(K / 'comparison-selection.json')]
    h_protocol = receipt(relative(K, h['protocol_receipt']), protocols=h['protocol_groups'])
    assert h['protocol_groups'] == 17 and h['protocol_source'] == 'comparison-preparation/test_compare-2.py'
    assert h_protocol['command'] == ['python3', str(relative(K, h['protocol_source']))]
    new = read(K / 'new-profile-comparison.json')
    assert new['status'] == 'clear' and new['errors'] == new['raw_before_pass_losses'] == []
    assert new['after_adapter'] == adapter
    assert new['comparison_source_sha256'] == sha(payload(K / 'new-profile-comparison/compare-2.py'))
    assert (new['case_rows'], new['policy_excluded_rows'], new['control_rows']) == (130, 64, 56)
    assert new['after_health']['counts'] == {'passed': 20, 'resource': 46, 'unsupported': 64}
    assert new['after_health']['controls_verified'] == 56 and new['after_health']['report_healthy'] is False
    for row in new['inputs']:
        bound(row)
    new_run = receipt(K / 'validation/new-profile-comparison-1.json')
    assert new_run['command'] == ['python3', str(K / 'new-profile-comparison/compare-2.py'),
                                 '--selection', str(K / 'new-profile-selection.json'),
                                 '--output', str(K / 'new-profile-comparison.json')]
    for phase, report_name, receipt_name in [('before', 'upstream-before.json', 'copy-within-before-1'),
                                             ('after', 'upstream-1.json', 'copy-within-after-1')]:
        report = read(K / report_name)
        assert new[phase + '_cases'] == report['cases'] and new[phase + '_controls'] == report['harness_preflight']
        assert Counter(row['status'] for row in report['cases']) == report['counts']
        receipt(K / 'validation' / (receipt_name + '.json'), expected_exit=1)
        public = W / 'tests/conformance' / ('test262-typedarray-copy-within-' + phase + '.json')
        assert payload(public) == payload(K / report_name)
    corpus = W / 'tests/upstream/test262-typedarray-copy-within'
    manifest = read(corpus / 'manifest.json')
    assert manifest['test_files'] == 65 and len(manifest['files']) == 76
    assert len(manifest['inventory_proof']['files']) == 8
    for row in manifest['files'] + manifest['inventory_proof']['files']:
        bound({**row, 'path': str(relative(corpus, row['path']))})
    benchmark_result, table, binaries = benchmark(selection['benchmark'])
    reviews = {}; coverage = {}
    for category, names in selection['reviews'].items():
        assert names and isinstance(names, list)
        coverage[category] = set()
        for name in names:
            path = relative(K, name); value = read(path)
            assert value['status'].startswith('clear'), name
            rows = value.get('files', value.get('inputs'))
            assert rows, name
            for row in rows:
                bound(row); coverage[category].add(row['path'])
            reviews[name] = inputs[str(path)]
    assert {str(K / 'compiled-source-2.json'), str(K / 'new-profile-comparison.json'),
            str(relative(K, h['report']))} <= coverage['observations']
    assert {str(relative(K, selection['benchmark']['summary'])),
            str(relative(K, selection['benchmark']['table']))} <= coverage['benchmark']
    assert str(K / 'package.py') in coverage['package']
    records = {}; exclusions = []

    def add(path, name):
        assert not name.startswith('/') and '..' not in Path(name).parts and name not in records, name
        data = payload(path)
        assert not data.startswith(b'\x7fELF'), ('ELF excluded', path)
        records[name] = data

    for path in sorted(K.iterdir()):
        if path.is_file() and path.suffix in {'.json', '.py', '.md'} and path.name != 'publication.json':
            add(path, 'candidate/' + path.name)
    directories = ['validation', 'implementation', 'private-tests', 'metadata-migration', 'browser',
                   'conformance', 'comparison-preparation', 'new-profile-comparison', 'observations',
                   'visited-pair', 'descriptor-optimization', 'package-preparation', 'regressions-candidate-1']
    for optional in ['docs-preparation', 'documentation-preparation']:
        if (K / optional).is_dir():
            directories.append(optional)
    for directory in directories:
        root = K / directory; assert root.is_dir(), root
        for current, dirs, files in os.walk(root, followlinks=False):
            # Prune before descent: the reconstructed full worktree can contain
            # old archives, .git data and build outputs unrelated to this record.
            dirs[:] = sorted(d for d in dirs if d not in {'before-engine', '.git', '__pycache__', 'target'}
                             and not d.startswith('target-') and not (Path(current) / d).is_symlink())
            for filename in sorted(files):
                path = Path(current) / filename
                if path.is_symlink() or path.suffix == '.pyc':
                    continue
                if directory == 'validation' and filename.startswith('package-'):
                    continue
                with path.open('rb') as stream:
                    elf = stream.read(4) == b'\x7fELF'
                if elf:
                    assert B in path.parents, ('unexpected binary in evidence directory', path)
                    exclusions.append(str(path.relative_to(K))); continue
                add(path, 'candidate/' + str(path.relative_to(K)))
    for prefix, snapshot, root in [('prior-source', prior, J / 'worktree'),
                                   ('pre-pair-source', source1, B / 'before-engine'),
                                   ('published-source', sources, W)]:
        for name in sorted(snapshot['source_sha256']):
            add(relative(root, name), prefix + '/' + name)
    changed = subprocess.check_output(['git', 'diff', '--name-only', 'HEAD'], cwd=W).decode().splitlines()
    changed += subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W).decode().splitlines()
    changed = sorted(set(changed))
    for name in changed:
        if name.startswith('docs/evidence/') or name in sources['source_sha256']:
            continue
        assert name == 'README.md' or name.startswith(('docs/', 'src/', 'tests/', 'tools/', 'examples/')), name
        add(relative(W, name), 'published-source/' + name)
    docs = {str(W / name) for name in changed if name == 'README.md' or
            (name.startswith('docs/') and not name.startswith('docs/evidence/'))}
    assert str(W / 'docs/typedarray-copy-within.md') in docs
    assert docs <= coverage['documentation'], docs - coverage['documentation']
    for path, row in list(inputs.items()):
        bound(row)
    index = {name: dict(bytes=len(data), sha256=sha(data)) for name, data in sorted(records.items())}
    records['MANIFEST.json'] = encoded(index)
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w') as archive:
        for name, data in sorted(records.items()):
            item = tarfile.TarInfo(name); item.size = len(data); item.mode = 0o644; item.mtime = 0
            archive.addfile(item, io.BytesIO(data))
    compressed = io.BytesIO()
    with gzip.GzipFile(fileobj=compressed, mode='wb', filename='', mtime=0) as stream:
        stream.write(raw.getvalue())
    archive_bytes = compressed.getvalue()
    archive_path = W / 'docs/evidence/typedarray-copy-within.tar.gz'
    summary_path = W / 'docs/evidence/typedarray-copy-within.json'
    assert not archive_path.exists() and not summary_path.exists()
    summary_value = dict(feature='Number TypedArray copyWithin and two inline visited names',
        base=BASE, archive=archive_path.name, archive_bytes=len(archive_bytes), archive_sha256=sha(archive_bytes),
        manifest_sha256=sha(records['MANIFEST.json']), records=len(index), candidate_adapter=adapter,
        source_trees={'prior-source': 284, 'pre-pair-source': 289, 'published-source_compiled': 291},
        checks=checks, retained_failures=retained_failures, historical_comparison=historical,
        new_profile_comparison=new, comparison_selection=selection['historical'],
        benchmark=benchmark_result, benchmark_table=table, benchmark_binaries=binaries,
        benchmark_samples=1008, benchmark_timed_executes=5040, reviews=reviews,
        baseline_recorded=False, new_gate_added=False, excluded_elf_paths=exclusions,
        source_change_after_validation=None,
        known_limits=['46 scheduled copyWithin modes still stop at resource limits; 64 policy-excluded modes remain visible',
                      'Healthy controls and clear comparisons do not make the new upstream report healthy',
                      'Source-1 descriptor and metadata failures, and first historical comparator failure, are retained',
                      'Pair timing is descriptive whole-script data; retain every median and p95 increase without a significance or Chromium claim',
                      'Full web compatibility, production security and general performance remain unproved'],
        published_bindings={name: dict(bytes=len(payload(W / name)), sha256=sha(payload(W / name)))
                            for name in changed if not name.startswith('docs/evidence/')})
    with archive_path.open('xb') as stream:
        stream.write(archive_bytes)
    with summary_path.open('xb') as stream:
        stream.write(encoded(summary_value))
    # Reopen the final product and verify every member, not only its index.
    assert sha(archive_path.read_bytes()) == summary_value['archive_sha256']
    assert archive_path.stat().st_size == summary_value['archive_bytes']
    assert read(summary_path) == summary_value
    with tarfile.open(archive_path) as archive:
        assert len(archive.getmembers()) == len(records) and set(archive.getnames()) == set(records)
        for item in archive.getmembers():
            assert item.isfile() and archive.extractfile(item).read() == records[item.name], item.name
    assert sha(records['MANIFEST.json']) == summary_value['manifest_sha256']
    print(json.dumps(dict(archive_bytes=len(archive_bytes), archive_sha256=sha(archive_bytes), records=len(index))))


if __name__ == '__main__':
    main()
