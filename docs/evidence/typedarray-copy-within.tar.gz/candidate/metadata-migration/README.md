# Proposed existing-test migrations

These are external candidate copies, not edits to K or J. Beforeimages equal published b46879dd at the source hold. The eight metadata groups keep their original assertions and strengthen the identity/order prefix from39/19 to40/20 before appending copyWithin. The site ledger adds the independent fixed256 sort route alongside the retained append rows. Malformed-owner tests keep all five failure mechanisms with capacity/array dimensions updated to21.

The other count snapshots update one reserved object and the predicted492 work/2,125-byte increment. No author quota or production tariff changes are present. The54 retained BEFORE rows are byte-exact; only12 absent-own Reflect/splice endpoint calculations gain one shared-owner entry. Heap and all other42 fee endpoints remain unchanged. No semantic JavaScript body is replaced.

Root measures the new site/raw diagnostic first and preserves any forecast failure. The old original descriptor case remains outside these migrations and must pass unchanged under its original quota before publication.
