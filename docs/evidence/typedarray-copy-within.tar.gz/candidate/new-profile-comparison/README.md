# New copyWithin report comparison

This data-only comparator covers the newly frozen 65-body / 130-mode profile separately from the prior 45-profile preservation comparator. It imports no project module and executes no engine. The independently held literal-header and harness hashes reconstruct all 130 case fingerprints; all 64 policy exclusions must retain their exact full row. Scheduled engine `unsupported` outcomes remain observations, not new policy exclusions. Missing or null observations cannot disguise a policy change.

All 56 before and after controls are retained. The 32 common controls must equal the exact healthy published J rows. The 24 feature controls are bound to the frozen six pairs, exact source and fingerprint, modes, expected result and same-mode positive prerequisite. Wrong partners require a runtime exception with authentic intrinsic Error identity. Before feature controls may be unhealthy when the method is absent; all candidate controls must be healthy. Every raw before-pass loss is an explicit finding and a nonzero comparison, even when before controls were unhealthy. Such passes are separately labeled as insufficient evidence of working method support.

The output keeps both complete case/control arrays, every changed full row and field, row hashes, counts, status transitions, raw pass losses, newly passing rows, engine unsupported details, and reconstructed report/control health. A clear comparison is not a claim of a healthy or fully passing suite. Resources, timeout and adapter/protocol failures remain visible. No baseline or CI gate is created.

Root supplies the actual completed record/receipt names in a fresh selection JSON using these exact keys:

```json
{
  "before_adapter_record": "candidate-adapter-1.json",
  "after_adapter_record": "candidate-adapter-N.json",
  "before_report": "upstream-before.json",
  "after_report": "upstream-1.json",
  "before_receipt": "validation/ACTUAL-BEFORE-RECEIPT.json",
  "after_receipt": "validation/ACTUAL-AFTER-RECEIPT.json"
}
```

The before adapter record is resolved under published J; its binary hash is pinned to `b366575d98cffdedbf20f5345ab44d11fb2d615d57ba7e7b94a30c756a38d8a9`. The after adapter record is under K; it chooses the actual source/build/full-suite binding. Reports and run receipts are under K. The comparator authenticates both executables, complete bound compiled source, successful build/full-suite receipts and logs, exact conformance arguments, all report input hashes and legitimate nonzero exits. It also authenticates the full imported corpus, selected importer/runner/control source, and both policies. Fresh output and final rehash are mandatory.

Root-only commands after review and actual observations:

```sh
python3 /tmp/eris-typedarray-copy-within-1/new-profile-comparison/test_compare.py
python3 /tmp/eris-typedarray-copy-within-1/new-profile-comparison/compare.py --selection /tmp/eris-typedarray-copy-within-1/new-profile-selection.json --output /tmp/eris-typedarray-copy-within-1/new-profile-comparison.json
```

Ten source-authored protocol groups use clearly synthetic observations and inert retained data. They cover unhealthy-before admission, complete observations, resource/unsupported details, raw pass loss, excluded-row and null drift, module/duplicate/order rejection, forged passes, policy hashes, intrinsic Error and same-mode positive gates, common-control preservation, nonzero receipt binding, exclusive output and post-read mutation. They were not run by the author. No final before or candidate counts were guessed.
