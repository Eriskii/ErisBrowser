"""Root-only data protocol tests. No project modules or engines are imported."""
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

HERE = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location('copy_within_comparison', HERE/'compare-2.py')
C = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(C)


def observation(status='complete', phase='runtime', error_type='', identity='', message=''):
    return dict(status=status, phase=phase, error_type=error_type,
                error_identity=identity, message=message, harness='')


def synthetic_report(frozen, healthy):
    # Synthetic observations only; none are candidate or predecessor results.
    cases = []
    for held in frozen['cases']:
        row = copy.deepcopy(held['identity'])
        if held['reason'] is not None:
            row.update(status='unsupported', reason=held['reason'])
        elif healthy:
            row.update(status='passed', observation=observation())
        else:
            row.update(status='failed', observation=observation('exception', error_type='TypeError', identity='TypeError', message='synthetic missing method'))
        cases.append(row)
    controls = copy.deepcopy(frozen['common'])
    for held in frozen['controls']:
        result = copy.deepcopy(held['identity'])
        if not healthy:
            result.update(status='failed', observation=observation('exception', error_type='TypeError', identity='TypeError', message='synthetic missing method'))
        elif held['expected'] == 'passed':
            result.update(status='passed', observation=observation())
        else:
            result.update(status='failed', observation=observation('exception', error_type='Error', identity='Error', message='synthetic wrong literal'))
        controls.append(dict(name=held['name'], expected=held['expected'], verified=healthy, result=result))
    indexed = {(r['name'], r['result']['mode']): r for r in controls}
    for held, row in zip(frozen['controls'], controls[32:]):
        if held['partner']:
            partner = indexed[(held['partner'], row['result']['mode'])]
            result = partner['result']
            row['prerequisite'] = dict(name=partner['name'], mode=result['mode'],
                case_sha256=result['case_sha256'], source_sha256=result['source_sha256'],
                expected='passed', verified=partner['verified'])
    policy = C.expected_policy(frozen)
    return dict(suite='pinned-test262-typedarray-copy-within-selection',
        full_test262_conformance=False, repository='https://github.com/tc39/test262',
        revision=C.REVISION, source_files=65, source_tests=65, negative_source_tests=0,
        fixture_files=[], mode_cases=130, runner_policy=policy,
        runner_policy_sha256=C.sha(json.dumps(policy, sort_keys=True).encode()),
        corpus_manifest_sha256='a'*64, binary_sha256='b'*64,
        counts=dict(C.Counter(r['status'] for r in cases)), cases=cases,
        harness_preflight=controls, harness_preflight_passed=healthy,
        regressions=[], improvements=[])


class NewProfileProtocols(unittest.TestCase):
    def setUp(self):
        C.inputs.clear()
        self.frozen = C.frozen_inputs()
        self.before = synthetic_report(self.frozen, False)
        self.after = synthetic_report(self.frozen, True)

    def compare(self):
        return C.compare_reports(self.before, self.after, self.frozen)

    def recount(self):
        self.after['counts'] = dict(C.Counter(r['status'] for r in self.after['cases']))

    def scheduled(self, report):
        return next(r for r in report['cases'] if r['status'] != 'unsupported')

    def test_unhealthy_before_and_healthy_candidate_keep_every_row(self):
        result = self.compare()
        self.assertEqual(result['status'], 'clear')
        self.assertEqual((result['case_rows'], result['policy_excluded_rows'], result['control_rows']), (130,64,56))
        self.assertEqual(result['transitions'], {'failed -> passed':66, 'unsupported -> unsupported':64})
        self.assertEqual(result['before_health']['controls_verified'],32)
        self.assertEqual(result['after_health']['controls_verified'],56)
        self.assertFalse(result['before_passes_establish_feature_support'])
        self.assertEqual(result['before_cases'], self.before['cases'])
        self.assertEqual(result['after_cases'], self.after['cases'])
        self.assertEqual(result['before_controls'], self.before['harness_preflight'])
        self.assertEqual(result['after_controls'], self.after['harness_preflight'])
        self.assertEqual(len(result['changed_controls']),24)

    def test_resource_and_engine_unsupported_details_are_retained(self):
        row = self.scheduled(self.after)
        row.update(status='resource', observation=observation('resource', error_type='ResourceLimit', message='synthetic terminal work limit'))
        self.recount()
        result = self.compare()
        self.assertEqual(result['status'],'clear')
        self.assertFalse(result['after_health']['report_healthy'])
        self.assertEqual(result['changed_rows'][0]['after'],row)
        row.update(status='unsupported', observation=observation('unsupported', error_type='UnsupportedFeature', message='synthetic later API'))
        self.recount()
        result=self.compare()
        self.assertEqual(result['engine_unsupported_rows'],[row])
        self.assertEqual(result['transitions']['failed -> unsupported'],1)
        self.assertNotIn(row['id'],result['newly_passing'])

    def test_raw_before_pass_loss_remains_a_finding_with_unhealthy_controls(self):
        before = self.scheduled(self.before)
        before.update(status='passed', observation=observation())
        self.before['counts']=dict(C.Counter(r['status'] for r in self.before['cases']))
        after = next(r for r in self.after['cases'] if r['id']==before['id'])
        after.update(status='resource', observation=observation('resource', error_type='ResourceLimit', message='synthetic resource'))
        self.recount()
        result=self.compare()
        self.assertEqual(result['status'],'findings')
        self.assertEqual(result['raw_before_pass_losses'],[after['id']])
        self.assertEqual(result['errors'][0]['kind'],'raw-before-pass-losses-require-review')
        self.assertFalse(result['errors'][0]['before_feature_controls_healthy'])

    def test_policy_exclusion_and_null_observation_cannot_be_disguised(self):
        excluded=next(r for r in self.after['cases'] if r['status']=='unsupported')
        excluded['reason'] += ' changed'
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        row=self.scheduled(self.after)
        row.update(status='unsupported',reason='invented exclusion',observation=None)
        self.recount()
        with self.assertRaises(AssertionError):self.compare()
        del row['observation']
        with self.assertRaises(AssertionError):self.compare()

    def test_module_extra_duplicate_and_reordered_rows_are_rejected(self):
        row=self.after['cases'][0]
        row['mode']='module';row['id']=row['file']+':module'
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        self.after['cases'].append(copy.deepcopy(self.after['cases'][0]))
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        self.after['cases'][1]=copy.deepcopy(self.after['cases'][0])
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        self.after['cases'].reverse()
        with self.assertRaises(AssertionError):self.compare()

    def test_forged_pass_missing_observation_and_policy_hash_drift_fail(self):
        row=self.scheduled(self.after)
        row['observation']=observation('resource',error_type='ResourceLimit')
        with self.assertRaises(AssertionError):self.compare()
        del row['observation']
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        self.after['runner_policy']['timeout_seconds']=4.0
        self.after['runner_policy_sha256']=C.sha(json.dumps(self.after['runner_policy'],sort_keys=True).encode())
        with self.assertRaises(AssertionError):self.compare()

    def test_wrong_partner_requires_authentic_runtime_error_identity(self):
        wrong=next(r for r in self.after['harness_preflight'][32:] if r['expected']=='failed')
        for field,value in [('error_type','TypeError'),('error_identity','TypeError'),('phase','parse')]:
            saved=copy.deepcopy(wrong['result']['observation'])
            wrong['result']['observation'][field]=value
            with self.assertRaises(AssertionError):self.compare()
            wrong['result']['observation']=saved
        wrong['expected']='unsupported'
        with self.assertRaises(AssertionError):self.compare()

    def test_same_mode_positive_partner_and_common_controls_are_required(self):
        wrong=next(r for r in self.after['harness_preflight'][32:] if r['expected']=='failed')
        wrong['prerequisite']['mode']='strict'
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,True)
        self.after['harness_preflight'][0]['result']['observation']['message']+=' altered'
        with self.assertRaises(AssertionError):self.compare()
        self.after=synthetic_report(self.frozen,False)
        result=self.compare()
        self.assertEqual(result['status'],'findings')
        self.assertEqual(result['errors'],[{'kind':'candidate-controls-unhealthy'}])

    def test_receipts_bind_nonzero_exit_command_report_and_log(self):
        report=self.after
        healthy=C.report_health(report,self.frozen)
        # Even this healthy synthetic report has 64 unsupported modes, so the
        # existing non-baseline runner invocation must retain exit 1.
        with tempfile.TemporaryDirectory() as temporary:
            root=Path(temporary);(root/'validation').mkdir()
            report_path=root/'upstream-1.json';report_path.write_text(json.dumps(report))
            C.read(report_path)
            log=b'synthetic retained log\n';(root/'validation/run.log').write_bytes(log)
            binary=root/'candidate'
            command=['python3','tools/test262_conformance.py','--profile',C.PROFILE,
                '--binary',str(binary),'--output',str(report_path),'--jobs','2']
            receipt=dict(command=command,exit=1,log='run.log',sha256=C.sha(log))
            path=root/'validation/run.json';path.write_text(json.dumps(receipt))
            result=C.receipt_check(root,'validation/run.json','upstream-1.json',report,binary,healthy)
            self.assertEqual(result['exit'],1)
            C.inputs.clear();C.read(report_path)
            receipt['exit']=0;path.write_text(json.dumps(receipt))
            with self.assertRaises(AssertionError):C.receipt_check(root,'validation/run.json','upstream-1.json',report,binary,healthy)
            C.inputs.clear();C.read(report_path)
            receipt['exit']=1;receipt['command'][-1]='3';path.write_text(json.dumps(receipt))
            with self.assertRaises(AssertionError):C.receipt_check(root,'validation/run.json','upstream-1.json',report,binary,healthy)

    def test_absent_to_null_observation_lists_the_changed_field(self):
        before = self.scheduled(self.before)
        before.update(status='adapter-error', reason='synthetic truncated adapter protocol')
        del before['observation']
        after = next(r for r in self.after['cases'] if r['id'] == before['id'])
        after.clear()
        after.update(copy.deepcopy(before), observation=None)
        self.before['counts'] = dict(C.Counter(r['status'] for r in self.before['cases']))
        self.recount()
        result = self.compare()
        changed = next(r for r in result['changed_rows'] if r['id'] == before['id'])
        self.assertEqual(changed['changed_fields'], ['observation'])
        self.assertNotIn('observation', changed['before'])
        self.assertIsNone(changed['after']['observation'])
        self.assertNotEqual(changed['before_sha256'], changed['after_sha256'])
        self.assertEqual(result['transitions']['adapter-error -> adapter-error'], 1)
        self.assertFalse(result['after_health']['report_healthy'])

    def test_fresh_output_and_final_input_rehash(self):
        C.inputs.clear()
        with tempfile.TemporaryDirectory() as temporary:
            directory=Path(temporary);source=directory/'input.json';source.write_text('{}')
            C.payload(source)
            output=directory/'output.json'
            C.publish(output,dict(status='clear'))
            self.assertEqual(json.loads(output.read_bytes())['status'],'clear')
            with self.assertRaises(FileExistsError):C.publish(output,dict(status='clear'))
            source.write_text('{"changed":true}')
            with self.assertRaises(AssertionError):C.publish(directory/'other.json',dict(status='clear'))
            self.assertFalse((directory/'other.json').exists())


if __name__=='__main__':
    unittest.main()
