"""Data-only comparison for the frozen new copyWithin population.

Root executes after review. No project module, importer or engine is imported.
A clear comparison does not imply a healthy or fully passing conformance report.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
BEFORE_ROOT = Path('/tmp/eris-own-keys-one-pass-1')
PROFILE = 'typedarray-copy-within'
REVISION = '7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
BEFORE_BINARY_SHA256 = 'b366575d98cffdedbf20f5345ab44d11fb2d615d57ba7e7b94a30c756a38d8a9'
FROZEN_INPUTS_SHA256 = 'c96fb1dad5817dfe2064d8ea47773f77fe4f002a201b23e42174e57706b479ea'
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
POLICY = ('suite', 'full_test262_conformance', 'repository', 'revision',
          'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256',
          'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases')
BAD_RUN = {'adapter-error', 'timeout', 'resource', 'runner-error'}
STATUSES = {'passed', 'failed', 'unsupported', 'harness-error'} | BAD_RUN
INTRINSIC_ERRORS = {'Error', 'TypeError', 'RangeError', 'SyntaxError', 'ReferenceError', 'EvalError', 'URIError'}
inputs = {}

def sha(data):
    return hashlib.sha256(data).hexdigest()


def row_hash(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def payload(path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    entry = dict(path=str(path), bytes=len(data), sha256=sha(data))
    assert inputs.setdefault(str(path), entry) == entry, ('input changed', path)
    return data


def read(path):
    return json.loads(payload(path))


def beneath(root, relative):
    assert isinstance(relative, str) and relative, relative
    path = Path(relative)
    assert not path.is_absolute() and '..' not in path.parts, relative
    return root / path


def require_binding(row):
    data = payload(Path(row['path']))
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']


def adapter(root, record):
    value = read(beneath(root, record))
    data = payload(beneath(root, value['binary']))
    assert len(data) == value['bytes'] and sha(data) == value['sha256']
    source_path = beneath(root, value['source_binding'])
    source = read(source_path)
    assert inputs[str(source_path)]['sha256'] == value['source_binding_sha256']
    for name, digest in source['source_sha256'].items():
        assert sha(payload(beneath(root/'worktree', name))) == digest, name
    for key in ('build', 'full_suite'):
        receipt = read(beneath(root, value[key]))
        log = payload(beneath(root/'validation', receipt['log']))
        assert receipt['exit'] == 0 and sha(log) == receipt['sha256'], (record, key)
    return value, source


def validate_observation(row):
    observed = row.get('observation')
    if observed is None:
        assert row['status'] in {'unsupported', 'adapter-error', 'timeout', 'runner-error'}
        assert isinstance(row['reason'], str) and row['reason']
        return
    assert set(observed) == {'status', 'phase', 'error_type', 'error_identity', 'message', 'harness'}
    assert all(isinstance(v, str) for v in observed.values())
    status, phase = observed['status'], observed['phase']
    assert status in {'complete', 'exception', 'unsupported', 'resource', 'harness-error'}
    assert phase in {'parse', 'runtime', 'harness', 'mode'}
    assert observed['error_identity'] == '' or observed['error_identity'] in INTRINSIC_ERRORS
    if status == 'complete':
        assert phase in {'parse', 'runtime'}
        assert not any(observed[k] for k in ('error_type', 'error_identity', 'harness'))
    if status == 'exception':
        assert phase in {'parse', 'runtime'} and observed['error_type'] and not observed['harness']
    if status == 'harness-error':
        assert phase == 'harness' and observed['harness']
    negative = row['expected_negative']
    if status in {'unsupported', 'resource', 'harness-error'}:
        classified = status
    elif negative is None:
        classified = 'passed' if status == 'complete' and phase == 'runtime' else 'failed'
    else:
        classified = ('passed' if status == 'exception' and phase == negative['phase']
                      and observed['error_identity'] == negative['type'] else 'failed')
    assert row['status'] == classified, row['id']


def frozen_inputs():
    manifest_path = HERE / 'frozen-inputs.json'
    assert sha(payload(manifest_path)) == FROZEN_INPUTS_SHA256
    held = read(manifest_path)
    for item in held['files']:
        data = payload(beneath(HERE, item['path']))
        assert len(data) == item['bytes'] and sha(data) == item['sha256'], item['path']
    require_binding(held['common_controls_original'])
    original = read(Path(held['common_controls_original']['path']))
    common = read(HERE / 'frozen/common-controls.json')
    assert original['harness_preflight'][:32] == common
    assert len(common) == 32 and all(c['verified'] for c in common)
    return dict(held=held, cases=read(HERE/'frozen/case-index.json'),
        controls=read(HERE/'frozen/control-index.json'), common=common,
        policy=read(HERE/'frozen/policy-inventory.json'),
        inventory=read(HERE/'frozen/discovery/inventory.json'),
        control_sources=read(HERE/'frozen/controls/controls.json'))


def expected_policy(frozen):
    return dict(format=2, supported_features=frozen['policy']['supported_features'],
        negative_intrinsic_errors=sorted(INTRINSIC_ERRORS), strict=True, modules=False,
        async_completion=False, host_hooks=False, timeout_seconds=3.0,
        excluded_harness=['resizableArrayBufferUtils.js'])


def verify_controls(report, frozen):
    rows = report['harness_preflight']
    assert len(rows) == 56 and rows[:32] == frozen['common'], 'common controls drift'
    indexed = {(r['name'], r['result']['mode']): r for r in rows}
    assert len(indexed) == 56, 'duplicate controls'
    for row in rows[:32]:
        validate_observation(row['result'])
        correct = row['result']['status'] == row['expected']
        assert row['expected'] in {'passed', 'failed'}
        if row['expected'] == 'failed':
            correct = correct and row['result'].get('observation', {}).get('error_type') == 'Test262Error'
        assert row['verified'] is True and correct
    assert len(frozen['controls']) == 24
    for row, expected in zip(rows[32:], frozen['controls']):
        result = row['result']
        assert {k: result[k] for k in IDENTITY} == expected['identity'], row['name']
        assert result['mode'] in {'sloppy', 'strict'}
        assert row['name'] == expected['name'] and row['expected'] == expected['expected']
        assert row['expected'] in {'passed', 'failed'}
        validate_observation(result)
        correct = result['status'] == row['expected']
        if expected['partner'] is None:
            assert 'prerequisite' not in row
        else:
            observed = result.get('observation') or {}
            correct = correct and all(observed.get(k) == v for k, v in dict(
                status='exception', phase='runtime', error_type='Error', error_identity='Error').items())
            partner = indexed[(expected['partner'], result['mode'])]
            assert partner['expected'] == 'passed'
            pr = partner['result']
            assert row['prerequisite'] == dict(name=partner['name'], mode=result['mode'],
                case_sha256=pr['case_sha256'], source_sha256=pr['source_sha256'],
                expected='passed', verified=partner['verified'])
            correct = correct and partner['verified']
        assert type(row['verified']) is bool and row['verified'] == correct, row['name']
    return all(r['verified'] for r in rows)


def report_health(report, frozen):
    assert report['suite'] == 'pinned-test262-' + PROFILE + '-selection'
    assert report['full_test262_conformance'] is False
    assert report['repository'] == 'https://github.com/tc39/test262'
    assert report['revision'] == REVISION
    assert (report['source_files'], report['source_tests'], report['negative_source_tests'],
            report['fixture_files'], report['mode_cases']) == (65, 65, 0, [], 130)
    assert report['runner_policy'] == expected_policy(frozen)
    assert report['runner_policy_sha256'] == sha(json.dumps(report['runner_policy'], sort_keys=True).encode())
    # This invocation has neither an existing baseline nor --record-baseline.
    assert report['regressions'] == report['improvements'] == []
    cases = report['cases']
    assert len(cases) == len(frozen['cases']) == 130
    assert len({r['id'] for r in cases}) == 130
    for row, expected in zip(cases, frozen['cases']):
        assert {k: row[k] for k in IDENTITY} == expected['identity'], row['id']
        assert row['mode'] in {'sloppy', 'strict'} and row['expected_negative'] is None
        assert row['status'] in STATUSES
        validate_observation(row)
        if expected['reason'] is not None:
            assert row == dict(expected['identity'], status='unsupported', reason=expected['reason']), row['id']
        elif row['status'] == 'unsupported':
            # Scheduled engine limitations must carry their actual observation;
            # absent/null observations cannot invent a new policy exclusion.
            assert isinstance(row.get('observation'), dict), row['id']
    counts = dict(Counter(r['status'] for r in cases))
    assert report['counts'] == counts
    preflight = verify_controls(report, frozen)
    assert type(report['harness_preflight_passed']) is bool
    assert report['harness_preflight_passed'] == preflight
    return dict(counts=counts, controls=56,
        controls_verified=sum(r['verified'] for r in report['harness_preflight']),
        common_controls_verified=32,
        feature_controls_verified=sum(r['verified'] for r in report['harness_preflight'][32:]),
        preflight_healthy=preflight,
        report_healthy=preflight and not any(counts.get(s) for s in BAD_RUN))


def compare_reports(before, after, frozen):
    before_health, after_health = report_health(before, frozen), report_health(after, frozen)
    for key in POLICY:
        assert before[key] == after[key], ('policy/population drift', key)
    errors, changes, losses = [], [], []
    transitions = Counter()
    for b, a in zip(before['cases'], after['cases']):
        transitions[b['status'] + ' -> ' + a['status']] += 1
        if b['status'] == 'passed' and a['status'] != 'passed':
            losses.append(a['id'])
        if b != a:
            changes.append(dict(id=a['id'], before=b, after=a,
                changed_fields=sorted(k for k in set(b) | set(a) if b.get(k) != a.get(k)),
                before_sha256=row_hash(b), after_sha256=row_hash(a)))
    if losses:
        errors.append(dict(kind='raw-before-pass-losses-require-review', ids=losses,
            before_feature_controls_healthy=before_health['preflight_healthy']))
    if not after_health['preflight_healthy']:
        errors.append(dict(kind='candidate-controls-unhealthy'))
    controls_changed = [dict(before=b, after=a) for b, a in zip(
        before['harness_preflight'], after['harness_preflight']) if b != a]
    return dict(status='clear' if not errors else 'findings', errors=errors,
        case_rows=130, policy_excluded_rows=64, scheduled_rows=66, control_rows=56,
        exact_case_rows=130-len(changes), exact_control_rows=56-len(controls_changed),
        before_health=before_health, after_health=after_health,
        transitions=dict(sorted(transitions.items())), raw_before_pass_losses=losses,
        newly_passing=[r['id'] for r in changes if r['before']['status'] != 'passed' and r['after']['status'] == 'passed'],
        engine_unsupported_rows=[r for r in after['cases'] if r['status'] == 'unsupported' and r.get('observation') is not None],
        before_passes_establish_feature_support=before_health['preflight_healthy'],
        before_pass_note='Raw passes with unhealthy method controls do not establish working copyWithin support; every raw loss still requires review and makes this comparison nonzero.',
        before_cases_sha256=row_hash(before['cases']), after_cases_sha256=row_hash(after['cases']),
        before_controls_sha256=row_hash(before['harness_preflight']), after_controls_sha256=row_hash(after['harness_preflight']),
        changed_rows=changes, changed_controls=controls_changed,
        before_cases=before['cases'], after_cases=after['cases'],
        before_controls=before['harness_preflight'], after_controls=after['harness_preflight'])


def verify_corpus(frozen):
    corpus = ROOT / 'worktree/tests/upstream/test262-typedarray-copy-within'
    manifest = read(corpus/'manifest.json')
    roster = read(HERE/'frozen/offline-inventory.json')['files']
    expected = {r['path']: {k: r[k] for k in ('bytes', 'sha256')} for r in roster}
    listed = manifest['files'] + manifest['inventory_proof']['files']
    assert len(listed) == len(expected) == 84
    assert len({r['path'] for r in listed}) == 84
    assert {r['path']: {k: r[k] for k in ('bytes', 'sha256')} for r in listed} == expected
    for row in listed:
        data = payload(beneath(corpus, row['path']))
        assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']
    assert manifest['test_files'] == 65 and manifest['revision'] == REVISION
    assert {k: len(v) for k, v in manifest['directories'].items()} == frozen['inventory']['directories']
    for r in frozen['inventory']['rows']:
        assert manifest['directories'][r['path'].removeprefix('test/built-ins/').rsplit('/',1)[0]].count(Path(r['path']).name) == 1
    # Reconstruct fingerprints from independently held header order and the
    # actual authenticated corpus helpers, not from before/after agreement.
    recomputed = []
    for source in sorted(frozen['policy']['rows'], key=lambda r: r['path']):
        for mode in source['modes']:
            identity = dict(source_sha256=source['source_sha256'], mode=mode,
                metadata=source['metadata'], harness=[dict(name=n,
                    sha256=sha(payload(corpus/'harness'/n))) for n in ['assert.js','sta.js',*source['metadata']['includes']]])
            recomputed.append(sha(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode()))
    assert recomputed == [r['identity']['case_sha256'] for r in frozen['cases']]
    controls = frozen['control_sources']['controls']
    actual = payload(ROOT/'worktree/tools/typedarray-copy-within-controls.json')
    assert actual == payload(HERE/'frozen/controls/controls.json')
    observed = []
    for control in controls:
        assert sha(control['source'].encode()) == control['source_sha256']
        for mode in control['modes']:
            identity = dict(source_sha256=control['source_sha256'], mode=mode,
                metadata=dict(flags=[], includes=[], features=[], locale=[], negative=None),
                harness=[dict(name=n, sha256=sha(payload(corpus/'harness'/n))) for n in ['assert.js','sta.js']])
            observed.append(sha(json.dumps(identity, sort_keys=True, ensure_ascii=True).encode()))
    assert observed == [r['identity']['case_sha256'] for r in frozen['controls']]
    hold = read(HERE/'frozen/source-ready.json')
    for name in ['tools/import_test262.py','tools/test262_conformance.py','tools/typedarray-copy-within-controls.json']:
        binding = next(r['held'] for r in hold['tool_paths'] if r['relative'] == name)
        data = payload(ROOT/'worktree'/name)
        assert len(data) == binding['bytes'] and sha(data) == binding['sha256'], name
    return sha(payload(corpus/'manifest.json'))


def receipt_check(root, receipt_name, report_name, report, binary, healthy):
    receipt = read(beneath(root, receipt_name))
    log = payload(beneath(root/'validation', receipt['log']))
    assert sha(log) == receipt['sha256'], receipt_name
    command = ['python3', 'tools/test262_conformance.py', '--profile', PROFILE,
        '--binary', str(binary), '--output', str(beneath(root, report_name)), '--jobs', '2']
    assert receipt['command'] == command, receipt_name
    expected_exit = int(not healthy['report_healthy'] or bool(report['regressions']) or
                        report['counts'].get('passed', 0) != report['mode_cases'])
    assert receipt['exit'] == expected_exit, (receipt_name, receipt['exit'], expected_exit)
    return dict(path=str(root/receipt_name), exit=receipt['exit'],
        sha256=sha(payload(root/receipt_name)), log=inputs[str(root/'validation'/receipt['log'])],
        report=inputs[str(root/report_name)])


def publish(output, result):
    # Reject paths aliasing any consumed input, even before the exclusive write.
    assert output.resolve() not in {Path(p).resolve() for p in inputs}
    for entry in inputs.values():
        data = Path(entry['path']).read_bytes()
        assert len(data) == entry['bytes'] and sha(data) == entry['sha256'], entry['path']
    result['inputs'] = list(inputs.values())
    with output.open('x') as handle:
        json.dump(result, handle, indent=2, sort_keys=True)
        handle.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    assert not args.output.exists(), 'fresh output required'
    inputs.clear()
    selection = read(args.selection)
    assert set(selection) == {'before_adapter_record', 'after_adapter_record', 'before_report',
                              'after_report', 'before_receipt', 'after_receipt'}
    assert selection['before_adapter_record'] == 'candidate-adapter-1.json'
    assert selection['before_report'] == 'upstream-before.json'
    assert selection['after_report'] == 'upstream-1.json'
    before_adapter, _ = adapter(BEFORE_ROOT, selection['before_adapter_record'])
    after_adapter, _ = adapter(ROOT, selection['after_adapter_record'])
    assert before_adapter['sha256'] == BEFORE_BINARY_SHA256
    frozen = frozen_inputs()
    manifest_hash = verify_corpus(frozen)
    before = read(beneath(ROOT, selection['before_report']))
    after = read(beneath(ROOT, selection['after_report']))
    assert before['binary_sha256'] == before_adapter['sha256']
    assert after['binary_sha256'] == after_adapter['sha256']
    assert before['corpus_manifest_sha256'] == after['corpus_manifest_sha256'] == manifest_hash
    result = compare_reports(before, after, frozen)
    receipts = [receipt_check(ROOT, selection['before_receipt'], selection['before_report'], before,
        BEFORE_ROOT/before_adapter['binary'], result['before_health']),
        receipt_check(ROOT, selection['after_receipt'], selection['after_report'], after,
        ROOT/after_adapter['binary'], result['after_health'])]
    result.update(scope='New frozen copyWithin population only; source, receipts and complete raw observations. No baseline or conformance gate.',
        before_commit='b46879dd20ee1b04b16a0baac5c33b35264db60b',
        before_adapter=before_adapter, after_adapter=after_adapter, receipts=receipts,
        comparison_source_sha256=sha(payload(Path(__file__))))
    publish(args.output, result)
    print(json.dumps(dict(status=result['status'], before=result['before_health'],
        after=result['after_health'], errors=result['errors']), sort_keys=True))
    return int(bool(result['errors']))


if __name__ == '__main__':
    raise SystemExit(main())
