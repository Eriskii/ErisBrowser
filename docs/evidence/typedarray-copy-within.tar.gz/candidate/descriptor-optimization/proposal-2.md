# TypedArray stored-key snapshot filtering

Source-only proposal against K compiled-source-1. No worktree edits, executions, quota changes, fixture changes, exclusions or tariff discounts.

## Finding and boundary

`own_keys` and `for_in_snapshot` first call `typed_array_own_length(receiver)`. Only `Some(length)` reaches the private `typed_array_own_strings(receiver, length)` helper; both are its only production callers. This authenticates the object, including detached/out-of-bounds/uninitialized `Some(0)` cases. The helper builds the dense prefix and then filters retained stored strings. Its current `typed_array_own_property(receiver, key, false)` call is used solely to distinguish `Exotic::Ordinary` from any `Handled` result.

For an authenticated receiver that distinction equals `typed_array_index(key) == Index::Ordinary`. Replace only the predicate call and enum pattern with the existing paid key classifier. Keep the classifier implementation, all prefix/count/work/storage admissions, key-handle clones, output allocation, ordering and append path unchanged. Keep every reached for-in descriptor read and visited-name operation unchanged.

No author callback occurs between authentication and filtering. No record reference, Live, pointer, descriptor, buffer state or classification cache is added. Appends/resizes/detaches during a later for-in body still run through the original fresh descriptor reader. Canonical sidecars remain excluded even in malformed private fixtures: valid, invalid, out-of-bounds, detached and uninitialized numeric keys all choose Numeric; ordinary strings remain included. Symbols are still skipped before this predicate. No raw bytes were read by the old false-value descriptor route.

The exact replaced predicate is:

```rust
matches!(self.typed_array_index(&key)?, typed_array::Index::Ordinary)
```

The index child module is private. To name this already script-scoped enum from sibling own_keys, change only `use index::Index;` to `pub(super) use index::Index;` in typed_array.rs. This is an internal re-export, with no Runtime/public API or added dynamic operation. The method already returns that script-scoped type. No other index visibility or classifier body changes.

This is a proposal, not an applied patch.

## Removed work and unchanged charges

Each stored string currently repeats binary search over TypedArray records. Every reached node has an existing 4-work charge. For ordinary names it then runs the canonical classifier and returns Ordinary. The replacement removes that entire redundant binary search, retains the exact classifier and the existing branch/clone envelope, and needs no new storage or semantic stage.

For a canonical numeric sidecar the old predicate also validates the number (8), and for a finite nonnegative integer consults current Live (12 plus the existing buffer metadata tick when initialized), constructs/discards a no-value descriptor if present, and finally discards the key either way. All those operations disappear because validity is irrelevant to this snapshot filter. Their exact reachability-dependent charges disappear with their bodies; no existing tariff changes. A resource cutoff may therefore advance, as with any real work removal. The independent tests must retain terminal error and partially built output cleanup checks, not emulate the removed discarded descriptor stages.

The ordinary descriptor path was also inspected. `for_in_proven_ordinary_property` reads/clones a full Property and the parameter-map value although the machine consumes only `enumerable`. Removing that would reduce actual handle work, but these operations have no separate existing debit here. The 4-work debit is explicitly proof use, and cannot be reduced merely because an unused Property clone is removed. Thus it is not presented as a quota-headroom fix.

## Exact old-fixture component

The frozen DefineOwnProperty/key-is-not-numeric-index fixture selects only the passthrough argument factory. It creates one view per ten constructor callbacks. The two verifyNotEnumerable calls fully walk each sample because foo/bar are hidden. The first sample snapshot has one ordinary stored string (foo), the second has two (foo/bar). All have 2 dense keys; the samples are the newest authentic record, with record populations 1..10. The rightmost-search comparison counts are [1,1,2,2,2,2,3,3,3,3]. Three repeated searches per callback therefore cost 3*4*22 = 264 work units across a complete execution.

This algebra describes complete-path removed work only. The actual predecessor currently fails at remaining=0, records=10, allocated=4503645 and does not report its exact stop point. No total required budget, new completion, new remaining-work value or complete strict-mode observation is claimed. The candidate must be measured at the unchanged quota. The original failure stays retained. Root's separate visited-bucket route is independent and not assumed by this proposal.

For a latest authentic initialized length-2 view, with b=4*comparison_count, the helper/own_keys/for_in_snapshot fees are:

| stored strings | old helper | new helper | old own_keys | new own_keys | for_in_snapshot |
| --- | --- | --- | --- | --- | --- |
| foo | 52+b | 52 | 65+2b | 65+b | each own_keys total +4 |
| foo,bar | 75+2b | 75 | 88+3b | 88+b | each own_keys total +4 |

Output/storage admission remains 188 and 204 bytes respectively on x86_64 (16-byte JsString); do not hard-code these sizes for other targets. The source formula is 2*(64+6)+(2+stored)*size_of::<JsString>(). Pure classifier fees for foo/bar remain 16 each. These are complete snapshot boundaries, not full JavaScript expressions.

## Independent validation and measurement

1. Preserve the current source/failure. Add focused boundary tests using fresh real constructor-created views with record populations 1,2,3,7,10 and literal name/order oracles. Check helper, own_keys and for_in_snapshot exact and one-short reached work, identical heap admission, and cleanup. Compute predecessor formulas from the retained old helper, not candidate observations.
2. Keep all prior own-key/for-in tests and literal assertions, especially existing authentic-zero-state canonical-sidecar tests. Add ordinary empty/nonscalar/long names, interspersed symbols and numeric spellings 0, -0, NaN, Infinity, fractions, exponent and large-index cases. Check ordinary expandos remain after detached/fixed-OOB/uninitialized views and numeric sidecars never appear.
3. Mutation cases must continue to verify fresh per-key resize/detach/delete/redefine descriptors, hidden shadowing, later prototype enumeration, reentrant record growth and target setters. This proposal changes no reader or visit path.
4. Root runs the unchanged original descriptor case in both modes before broader tests, without raising limits or editing the harness. Then full own-key/TypedArray tests, all frozen profile comparisons and healthy controls establish regression bounds.
5. If pursued beyond correctness, use identical release benchmark source for old/new snapshots with 0/1/8/32 ordinary expandos, symbols and canonical private-sidecar stress separately. Alternate process order; exclude setup/bootstrap; report full sampled work/heap and wall time including JavaScript interpretation. No performance win is inferred from removed logical work; no engine/browser equivalence claim.
