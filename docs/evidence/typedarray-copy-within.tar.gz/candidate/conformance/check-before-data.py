"""Inert source/JSON/hash audit only. No project import or execution."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json
K=Path('/tmp/eris-typedarray-copy-within-1'); J=Path('/tmp/eris-own-keys-one-pass-1')
C=K/'conformance'; O=C/'offline-inputs'; corpus=K/'worktree/tests/upstream/test262-typedarray-copy-within'
def sha(b): return hashlib.sha256(b).hexdigest()
def rec(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=sha(b))
def read(p):return json.loads(p.read_text())
r=read(K/'upstream-before.json'); policy=read(C/'policy-inventory.json'); manifest=read(corpus/'manifest.json')
assert r['revision']==manifest['revision']=='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd'
assert r['repository']==manifest['repository']=='https://github.com/tc39/test262'
assert r['corpus_manifest_sha256']==sha((corpus/'manifest.json').read_bytes())
assert r['runner_policy_sha256']==sha(json.dumps(r['runner_policy'],sort_keys=True).encode())
assert r['runner_policy']['supported_features']==policy['supported_features']
assert r['runner_policy']['excluded_harness']==policy['excluded_harness']
assert r['runner_policy']==dict(format=2,supported_features=policy['supported_features'],negative_intrinsic_errors=['Error','EvalError','RangeError','ReferenceError','SyntaxError','TypeError','URIError'],strict=True,modules=False,async_completion=False,host_hooks=False,timeout_seconds=3.0,excluded_harness=['resizableArrayBufferUtils.js'])
for row in manifest['files']:
 data=(corpus/row['path']).read_bytes(); assert len(data)==row['bytes'] and sha(data)==row['sha256']; assert data==(O/row['upstream_path']).read_bytes()
assert manifest['test_files']==r['source_files']==r['source_tests']==65
assert r['negative_source_tests']==0 and not r['fixture_files'] and r['full_test262_conformance'] is False
byid={x['id']:x for x in r['cases']}; assert len(byid)==r['mode_cases']==130

def fingerprint(source, mode, metadata, names):
 ident=dict(source_sha256=sha(source),mode=mode,metadata=metadata,harness=[dict(name=n,sha256=sha((O/'harness'/n).read_bytes())) for n in names])
 return sha(json.dumps(ident,sort_keys=True,ensure_ascii=True).encode())
expected=set(); exclusions=Counter()
for x in policy['rows']:
 data=(O/x['path']).read_bytes(); assert sha(data)==x['source_sha256']
 for mode in x['modes']:
  id=x['path']+':'+mode;expected.add(id); a=byid[id]
  assert a['file']==x['path'] and a['mode']==mode and a['source_sha256']==sha(data) and a['expected_negative']==x['metadata']['negative']
  assert a['case_sha256']==fingerprint(data,mode,x['metadata'],['assert.js','sta.js']+x['metadata']['includes'])
  if x['reason'] is not None:
   assert a['status']=='unsupported' and a['reason']==x['reason'] and a.get('observation') is None;exclusions[x['reason']]+=1
  else: assert a['status']!='unsupported' and a['observation']
assert expected==set(byid); assert sum(exclusions.values())==64
counts=Counter(x['status'] for x in r['cases']); assert dict(counts)==r['counts']=={'unsupported':64,'failed':56,'resource':6,'passed':4}
controls=read(C/'held/tools/typedarray-copy-within-controls.json')['controls']
# Literal AST values only; do not execute/import the runner.
runner_ast=ast.parse((C/'held/tools/test262_conformance.py').read_text()); fn=next(n for n in runner_ast.body if isinstance(n,ast.FunctionDef) and n.name=='harness_preflight')
scripts=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.Assign) and isinstance(n.targets[0],ast.Name) and n.targets[0].id=='scripts'))
extra=ast.literal_eval(next(n.value for n in fn.body if isinstance(n,ast.AugAssign) and isinstance(n.target,ast.Name) and n.target.id=='variants' and isinstance(n.value,ast.List)))
variants=[(n,s,e,'sloppy') for n,s,e in scripts]+[('strict-'+n,s,e,'strict') for n,s,e in scripts]+extra
assert len(variants)==32
common_report=read(J/'fill-1.json')['harness_preflight'][:32]; assert common_report==r['harness_preflight'][:32]
for c in controls:
 assert sha(c['source'].encode())==c['source_sha256']
 assert 'if (typeof copy !== "function") throw new TypeError("copyWithin prerequisite");' in c['source']
 assert 'working overlap prerequisite' in c['source']
 variants.extend(('typedarray-copy-within-'+c['name'],c['source'],'passed' if c['positive'] else 'failed',m) for m in c['modes'])
assert len(variants)==len(r['harness_preflight'])==56
for (name,src,exp,mode),a in zip(variants,r['harness_preflight']):
 assert a['name']==name and a['expected']==exp;res=a['result']; assert res['mode']==mode and res['source_sha256']==sha(src.encode())
 includes=['propertyHelper.js'] if 'property-' in name else []
 metadata=dict(flags=[],includes=includes,features=[],locale=[],negative=None)
 assert res['case_sha256']==fingerprint(src.encode(),mode,metadata,['assert.js','sta.js']+includes)
 if name.startswith('typedarray-copy-within-'):
  assert not a['verified'] and res['status']=='failed';o=res['observation']; assert (o['status'],o['phase'],o['error_type'],o['error_identity'])==('exception','runtime','TypeError','TypeError')
  if exp=='failed':
   p=a['prerequisite']; assert p['mode']==mode and p['name']==name.removesuffix('-wrong')+'-positive' and p['verified'] is False
 else: assert a['verified']
assert r['harness_preflight_passed'] is False
adapter=read(J/'candidate-adapter-1.json'); assert r['binary_sha256']==adapter['sha256']==sha(Path(r['binary']).read_bytes())
assert adapter['source_binding_sha256']==sha((J/adapter['source_binding']).read_bytes())
sources=read(J/adapter['source_binding'])['source_sha256']; source_refs=[]
for path in ['src/script/typed_array/intrinsics.rs','src/script/typed_array.rs']:
 p=J/'worktree'/path; assert sha(p.read_bytes())==sources[path]; assert 'copyWithin' not in p.read_text();source_refs.append(rec(p))
receipts=[]
for name in ['import-copy-within-1','protocols-1','copy-within-before-1']:
 p=K/'validation'/f'{name}.json';a=read(p);log=K/'validation'/a['log']; assert sha(log.read_bytes())==a['sha256'];assert a['exit']==(1 if name=='copy-within-before-1' else 0);receipts.extend([rec(p),rec(log)])
assert read(K/'validation/copy-within-before-1.json')['command']==['python3','tools/test262_conformance.py','--profile','typedarray-copy-within','--binary',str(J/'eris-js-candidate-1'),'--output',str(K/'upstream-before.json'),'--jobs','2']
assert 'Ran 329 tests' in (K/'validation/protocols-1.log').read_text()
passes=[x for x in r['cases'] if x['status']=='passed']; assert {x['file'].rsplit('/',1)[1] for x in passes}=={'this-is-not-object.js','this-is-not-typedarray-instance.js'}
review=dict(status='clear as an unhealthy predecessor observation; raw passes do not establish method support',report=rec(K/'upstream-before.json'),bindings=[rec(C/'source-ready.json'),rec(C/'policy-inventory.json'),rec(C/'held/tools/typedarray-copy-within-controls.json'),rec(C/'held/tools/test262_conformance.py'),rec(corpus/'manifest.json'),rec(J/'candidate-adapter-1.json'),rec(J/adapter['source_binding']),rec(J/'fill-1.json')]+source_refs,receipts=receipts,population=dict(sources=65,modes=130,case_and_harness_fingerprints_verified=130,manifest_files_exact=len(manifest['files']),scheduled=66,policy_excluded=64,excluded_reasons=dict(exclusions)),observed_counts=dict(counts),controls=dict(total=56,common32_exact_to_published_J_fill_report=True,common_verified=32,new_unverified=24,new_positive_unverified=12,new_wrong_unverified=12,all_new_observations='runtime exception / TypeError / TypeError',same_mode_positive_prerequisites_unverified=True,health=False),raw_passes=passes,pass_source_bindings=[rec(O/p) for p in sorted(set(x['file'] for x in passes))]+[rec(O/'harness/assert.js'),rec(O/'harness/testTypedArray.js')],analysis=[
'The two source files alias TypedArray.prototype.copyWithin without a callable or successful-call guard. Every later copyWithin.call access is inside assert.throws(TypeError, callback). The first covers seven primitive receivers; the second covers four ordinary/non-TypedArray objects. Neither proves that method validation was entered.',
'Published J metadata/dispatch source bound to the actual predecessor adapter contains no copyWithin registration. Resolving the absent property gives undefined; accessing its .call raises the same intrinsic TypeError accepted by assert.throws. This is a source-derived explanation consistent with each complete observation, not an engine trace or evidence of copyWithin support.',
'The frozen assert.throws checks that its callback is callable and that the thrown object constructor matches the expected constructor. It does not distinguish the throw site within that callback. Both tests therefore accept this absent-method TypeError before any intended ValidateTypedArray operation.',
'All 24 method-specific control rows fail with intrinsic TypeError and remain unverified. Each frozen source begins with explicit callable and successful overlap guards; wrong partners require exact intrinsic Error and a verified same-mode positive. The report correctly rejects incidental TypeError negatives.',
'The six resource rows are the sloppy/strict end/start/target-is-symbol cases, observed runtime ResourceLimit with script instruction limit exceeded. No exact exhaustion location is inferred from the report.',
'The predecessor runner exits1 and harness_preflight_passed is false; this report cannot form a healthy upstream baseline. All four pass statuses remain recorded exactly. The source-only audit does not relabel outcomes or infer conformance support.',
'Root importer/protocol/predecessor executions are bound to their actual receipts; candidate compilation cache restoration is separate and is not classified as an engine outcome here.'],resource_rows=[x for x in r['cases'] if x['status']=='resource'],execution='Reviewer only parsed inert JSON/AST and read/hashed files. No project import, compiler, formatter, JavaScript parser, engine or test execution.',audit_source=rec(Path(__file__)))
p=C/'before-observation-review.json';p.write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(rec(p)));print('population, controls and all hashes clear')
