"""Inert source/data freeze. No project imports or execution."""
from pathlib import Path
import ast,hashlib,json,shutil
C=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
def row(p):
    raw=p.read_bytes();return dict(path=str(p),bytes=len(raw),sha256=sha(raw))
paths=json.loads((C/'changed-existing-paths.json').read_bytes())+['tools/typedarray-copy-within-controls.json','tools/test_test262_typedarray_copy_within.py']
assert len(paths)==25
held=[]
for rel in paths:
    p=C/'draft'/rel;dest=C/'held'/rel;dest.parent.mkdir(parents=True,exist_ok=True)
    if dest.exists():raise ValueError('already held')
    shutil.copyfile(p,dest)
    held.append(dict(relative=rel,draft=row(p),held=row(dest)))
# Standard-library AST syntax inspection does not load a module or run its code.
for p in (C/'draft/tools').glob('*.py'):ast.parse(p.read_bytes())
files=[row(p) for p in sorted(C.rglob('*')) if p.is_file() and p.name!='source-ready.json']
# Existing controls source-ready is an input too, unlike the new root hold.
files.append(row(C/'controls/source-ready.json'))
external=[row(C.parent/'upstream-inventory.json'),row(C.parent/'source-ready.json')]
result=dict(status='source-ready; no project execution',profile='typedarray-copy-within',base='b46879dd20ee1b04b16a0baac5c33b35264db60b',worktree='/tmp/eris-typedarray-copy-within-1/worktree',revision='7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd',sources=65,modes=130,scheduled_modes=66,excluded_modes=64,helpers=9,offline_inputs=84,proof_documents=8,control_pairs=6,feature_control_modes=24,all_control_modes=56,protocol_groups=9,unchanged_existing_profile_policies=52,changed_existing_modules=23,tool_paths=held,files=files,external_inputs=external,limits='No engine/compiler/formatter/parser/importer/test execution; no implementation outcome used to choose sources or literals')
p=C/'source-ready.json';assert not p.exists();p.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(hold=str(p),sha256=sha(p.read_bytes()),tool_paths=len(held),bound_files=len(files),bytes=p.stat().st_size)))
