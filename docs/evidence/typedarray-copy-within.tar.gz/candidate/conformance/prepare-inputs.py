"""Inert copies and source header/policy inventory. No project imports."""
from pathlib import Path
import hashlib,json,re,shutil
C=Path(__file__).resolve().parent;W=Path('/tmp/eris-typedarray-copy-within-1/worktree'); I=Path('/tmp/eris-typedarray-to-reversed-1/conformance')
sha=lambda b:hashlib.sha256(b).hexdigest()
inv=json.loads((C/'discovery/inventory.json').read_bytes())
O=C/'offline-inputs'; (O/'inventory-proof').mkdir(exist_ok=True)
for p in (C.parent/'upstream-proof').glob('*.json'):
    name='recursive-9ad9819eb4153745c4cbc561d43541a5e5a2fc5e.json' if p.name=='copyWithin-subtree.json' else p.name
    shutil.copyfile(p,O/'inventory-proof'/name)
# The root-linked harness tree and original auxiliary bytes share the same pin.
provenance=[]
for name in inv['helpers']:
    candidates=[I/'offline-inputs/harness'/name,Path('/tmp/eris-typedarray-reverse-1/conformance/offline-inputs/harness')/name,Path('/tmp/eris-typedarray-fill-1/conformance/offline-inputs/harness')/name,Path('/tmp/eris-typedarray-search-1/conformance/offline-inputs/harness')/name]
    src=next((p for p in candidates if p.is_file()),None)
    if src is None: raise ValueError(name)
    dst=O/'harness'/name;dst.parent.mkdir(exist_ok=True);shutil.copyfile(src,dst)
    provenance.append(dict(path='harness/'+name,original=str(src),bytes=dst.stat().st_size,sha256=sha(dst.read_bytes())))
root=json.loads((O/'inventory-proof/tree-91b2052adad1f066ae031e2ff3a1e9bd6d732886.json').read_bytes())
h=next(x['sha'] for x in root['tree'] if x['path']=='harness');shutil.copyfile(I/'offline-inputs/inventory-proof'/('tree-'+h+'.json'),O/'inventory-proof'/('tree-'+h+'.json'))
for name in ['LICENSE','INTERPRETING.md']: shutil.copyfile(I/'offline-inputs'/name,O/name)
(C/'helper-provenance.json').write_text(json.dumps(dict(revision=inv['revision'],files=provenance),indent=2)+'\n')
rows=[]
for p in [W/'tools/import_test262.py',W/'tools/test262_conformance.py',*sorted((W/'tools').glob('test_test262*.py'))]:
    out=C/'original'/p.name;shutil.copyfile(p,out)
    rows.append(dict(path=str(p),copy=str(out),bytes=p.stat().st_size,sha256=sha(p.read_bytes())))
(C/'base-context.json').write_text(json.dumps(dict(base='b46879dd20ee1b04b16a0baac5c33b35264db60b',files=rows),indent=2)+'\n')
features={'TypedArray','ArrayBuffer','Symbol','Reflect.construct','arrow-function','resizable-arraybuffer'}
counts={};policy=[]
for row in inv['rows']:
    m=row['metadata']; assert m['flags']==[] and m['negative'] is None and m['locale']==[]
    missing=set(m['features'])-features
    if missing: reason='unimplemented declared features: '+', '.join(sorted(missing))
    elif 'resizableArrayBufferUtils.js' in m['includes']: reason='TypedArray copyWithin policy excludes the complete resizableArrayBufferUtils helper'
    elif any(re.search(rb'\$262\b|\$DONE\b|\bprint\s*\(',p.read_bytes()) for p in [O/row['path'],*[O/'harness'/x for x in ['assert.js','sta.js',*m['includes']]]]): reason='Test262 host hooks are not implemented (conservative source check)'
    else: reason=None
    counts[reason or 'scheduled']=counts.get(reason or 'scheduled',0)+2
    policy.append(dict(path=row['path'],source_sha256=row['sha256'],metadata=m,modes=['sloppy','strict'],reason=reason))
(C/'policy-inventory.json').write_text(json.dumps(dict(profile='typedarray-copy-within',source_only=True,bodies=65,modes=130,supported_features=sorted(features),excluded_harness=['resizableArrayBufferUtils.js'],counts=counts,rows=policy),indent=2)+'\n')
print(json.dumps(dict(counts=counts,helpers=inv['helpers'])))
