"""Independently authored JS literals; builds source data only, never executes JS."""
from pathlib import Path
import hashlib,json
C=Path(__file__).resolve().parent
sha=lambda s:hashlib.sha256(s.encode() if isinstance(s,str) else s).hexdigest()
guard='''var owner = Object.getPrototypeOf(Uint8Array.prototype);
var copy = owner.copyWithin;
if (typeof copy !== "function") throw new TypeError("copyWithin prerequisite");
var guardView = new Uint8Array([1, 2, 3]);
if (copy.call(guardView, 1, 0, 2) !== guardView || guardView[0] !== 1 || guardView[1] !== 1 || guardView[2] !== 2) throw new TypeError("working overlap prerequisite");
function same(actual, expected) { if (actual !== expected) throw new Error("copyWithin literal mismatch"); }
function values(view, expected) { same(view.length, expected.length); for (var q = 0; q < expected.length; q++) same(view[q], expected[q]); }
function typeError(action) { var caught = false; try { action(); } catch (error) { if (!(error instanceof TypeError)) throw error; caught = true; } if (!caught) throw new Error("missing TypeError"); }
'''
pairs=[('ten-kinds-overlap-and-offset', '''var kinds = [Int8Array, Uint8Array, Uint8ClampedArray, Int16Array, Uint16Array, Int32Array, Uint32Array, Float16Array, Float32Array, Float64Array];
var score = 0;
for (var k = 0; k < kinds.length; k++) {
  var Kind = kinds[k];
  var all = new Kind([99, 11, 22, 33, 44, 88]);
  var selected = new Kind(all.buffer, Kind.BYTES_PER_ELEMENT, 4);
  var alias = new Kind(all.buffer, Kind.BYTES_PER_ELEMENT, 4);
  same(copy.call(selected, 1, 0, 3), selected);
  values(all, [99, 11, 11, 22, 33, 88]);
  values(alias, [11, 11, 22, 33]);
  same(copy.call(selected, 0, 1, 4), selected);
  values(all, [99, 11, 22, 33, 33, 88]);
  values(alias, [11, 22, 33, 33]);
  score += alias[3];
}
''', 'score', '330', '440'),
('raw-floating-bits', '''var kinds = [Float16Array, Float32Array, Float64Array];
var seeds = [[1,126,0,128,0,60], [1,0,192,127,0,0,0,128,0,0,128,63], [1,0,0,0,0,0,248,127,0,0,0,0,0,0,0,128,0,0,0,0,0,0,240,63]];
var right = [[1,126,1,126,0,128], [1,0,192,127,1,0,192,127,0,0,0,128], [1,0,0,0,0,0,248,127,1,0,0,0,0,0,248,127,0,0,0,0,0,0,0,128]];
var left = [[1,126,0,128,0,128], [1,0,192,127,0,0,0,128,0,0,0,128], [1,0,0,0,0,0,248,127,0,0,0,0,0,0,0,128,0,0,0,0,0,0,0,128]];
var score = 0;
for (var k = 0; k < kinds.length; k++) {
  var bytes = new Uint8Array(seeds[k]);
  var floating = new kinds[k](bytes.buffer);
  same(copy.call(floating, 1, 0, 2), floating);
  values(bytes, right[k]);
  same(copy.call(floating, 0, 1, 3), floating);
  values(bytes, left[k]);
  score += bytes[0];
}
''','score','3','0'),
('conversion-order-and-ranges', '''var a = new Uint8Array([1,2,3,4,5]);
var order = "";
var target = {valueOf:function(){order += "T"; return -2.9;}};
var start = {valueOf:function(){order += "S"; return 1.9;}};
var end = {valueOf:function(){order += "E"; return 4.9;}};
same(copy.call(a,target,start,end),a);
same(order,"TSE"); values(a,[1,2,3,2,3]);
same(copy.call(a,-Infinity,3,Infinity),a); values(a,[2,3,3,2,3]);
order="";
same(copy.call(a,{valueOf:function(){order+="T";return Infinity;}},{valueOf:function(){order+="S";return NaN;}},{valueOf:function(){order+="E";return 5;}}),a);
same(order,"TSE"); values(a,[2,3,3,2,3]);
var token={}; var observed; order="";
try { copy.call(a,{valueOf:function(){order+="T";return 0;}},{valueOf:function(){order+="S";throw token;}},{valueOf:function(){order+="E";return 5;}}); } catch(error) { observed=error; }
same(observed,token); same(order,"TS"); values(a,[2,3,3,2,3]);
var empty=new Uint8Array(0); order="";
same(copy.call(empty,{valueOf:function(){order+="T";return 0;}},{valueOf:function(){order+="S";return 0;}},{valueOf:function(){order+="E";return 0;}}),empty);
''','order','"TSE"','""'),
('captured-length-and-refreshed-prefix', '''var b=new ArrayBuffer(4,{maxByteLength:8}); var a=new Uint8Array(b);
a[0]=1;a[1]=2;a[2]=3;a[3]=4;
same(copy.call(a,{valueOf:function(){b.resize(8);a[4]=9;a[5]=9;a[6]=9;a[7]=9;return 1;}},0),a);
values(a,[1,1,2,3,9,9,9,9]);
var c=new ArrayBuffer(8,{maxByteLength:8});var t=new Uint8Array(c);
for(var i=0;i<8;i++)t[i]=i+1;
same(copy.call(t,2,0,{valueOf:function(){c.resize(5);return 8;}}),t);
values(t,[1,2,1,2,3]);c.resize(8);values(t,[1,2,1,2,3,0,0,0]);
var d=new ArrayBuffer(8,{maxByteLength:8});var words=new Uint16Array(d);
words[0]=257;words[1]=514;words[2]=771;words[3]=1028;
same(copy.call(words,1,{valueOf:function(){d.resize(7);return 0;}},4),words);
values(words,[257,257,514]);d.resize(8);values(words,[257,257,514,4]);
''','words[3]','4','0'),
('initial-and-late-invalidity', '''var calls=0;var arg={valueOf:function(){calls++;return 0;}};
typeError(function(){copy.call({},arg,arg,arg);});same(calls,0);
var b=new ArrayBuffer(4);var detached=new Uint8Array(b);b.transfer();
typeError(function(){copy.call(detached,arg,arg,arg);});same(calls,0);
var c=new ArrayBuffer(4,{maxByteLength:4});var fixed=new Uint8Array(c,0,4);c.resize(2);
typeError(function(){copy.call(fixed,arg,arg,arg);});same(calls,0);
var d=new ArrayBuffer(4);var late=new Uint8Array(d);var order="";
same(copy.call(late,{valueOf:function(){order+="T";d.transfer();return 4;}},{valueOf:function(){order+="S";return 0;}},{valueOf:function(){order+="E";return 4;}}),late);
same(order,"TSE");same(d.byteLength,0);
var e=new ArrayBuffer(4,{maxByteLength:4});var lateFixed=new Uint8Array(e,0,4);
same(copy.call(lateFixed,4,{valueOf:function(){e.resize(0);return 0;}},4),lateFixed);
same(e.byteLength,0);
var f=new ArrayBuffer(4,{maxByteLength:4});var badFixed=new Uint8Array(f,0,4);order="";
typeError(function(){copy.call(badFixed,{valueOf:function(){order+="T";return 0;}},{valueOf:function(){order+="S";f.resize(2);return 1;}},{valueOf:function(){order+="E";return 3;}});});same(order,"TSE");
var g=new ArrayBuffer(4);var badDetached=new Uint8Array(g);order="";
typeError(function(){copy.call(badDetached,{valueOf:function(){order+="T";return 0;}},{valueOf:function(){order+="S";return 1;}},{valueOf:function(){order+="E";g.transfer();return 3;}});});
''','order','"TSE"','"TS"'),
('saved-metadata-and-internal-length', '''same(copy.name,"copyWithin");same(copy.length,2);
var descriptor=Object.getOwnPropertyDescriptor(owner,"copyWithin");
same(descriptor.value,copy);same(descriptor.writable,true);same(descriptor.enumerable,false);same(descriptor.configurable,true);
same(Object.prototype.hasOwnProperty.call(copy,"prototype"),false);
var kinds=[Int8Array,Uint8Array,Uint8ClampedArray,Int16Array,Uint16Array,Int32Array,Uint32Array,Float16Array,Float32Array,Float64Array];
for(var k=0;k<kinds.length;k++)same(kinds[k].prototype.copyWithin,copy);
function Constructor(){this.ok=1;}
same(Reflect.construct(Constructor,[]).ok,1);
typeError(function(){Reflect.construct(copy,[]);});
var a=new Uint8Array([1,2,3,4]);var hooks=0;
Object.defineProperty(a,"length",{get:function(){hooks++;throw new Error("public length");}});
Object.defineProperty(a,"constructor",{get:function(){hooks++;throw new Error("constructor");}});
var ignored={valueOf:function(){hooks++;throw new Error("extra argument");}};
delete owner.copyWithin;
same(copy.call(a,1,0,3,ignored),a);
same(a[0],1);same(a[1],1);same(a[2],2);same(a[3],3);
''','hooks','0','1')]
controls=[]
for name,body,actual,good,bad in pairs:
    prefix=guard+body
    for positive,expected in [(True,good),(False,bad)]:
        source=prefix+'same('+actual+', '+expected+');\ntrue;\n'
        controls.append(dict(name=name+('-positive' if positive else '-wrong'),pair=name,positive=positive,modes=['sloppy','strict'],common_prefix_sha256=sha(prefix),source=source,source_sha256=sha(source)))
raw=json.dumps(dict(profile='typedarray-copy-within',scope='independent literal controls; ten Number kinds, nonshared buffers, no engine execution',controls=controls),indent=2)+'\n'
(C/'controls.json').write_text(raw)
(C/'source-ready.json').write_text(json.dumps(dict(status='frozen source-only before any copyWithin conformance execution',source=str(C/'controls.json'),source_bytes=len(raw.encode()),source_sha256=sha(raw),pairs=6,mode_observations=24,guard_sha256=sha(guard),specification='https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.copywithin',scope='Literal raw-byte preservation; little-endian partial Uint16 trailing-byte expectation follows retained buffer contract; no shared/BigInt claim',execution='No JS parser, project importer, compiler, tests, engine or browser'),indent=2)+'\n')
print(json.dumps(dict(pairs=6,bytes=len(raw.encode()),sha256=sha(raw))))
