"""Source transformations only; never import or execute project modules."""
from pathlib import Path
import difflib,json,shutil
C=Path(__file__).resolve().parent; D=C/'draft/tools';O=C/'original'
inv=json.loads((C/'discovery/inventory.json').read_bytes())
control_hash=json.loads((C/'controls/source-ready.json').read_bytes())['source_sha256']
def once(s,a,b):
    assert s.count(a)==1,(a,s.count(a));return s.replace(a,b,1)
p=D/'import_test262.py';s=(O/p.name).read_text()
s=once(s,'TYPEDARRAY_TO_REVERSED_DIRECTORIES =','TYPEDARRAY_COPY_WITHIN_DIRECTORIES = '+repr(inv['directories'])+'\nTYPEDARRAY_COPY_WITHIN_HELPERS = '+repr(set(inv['helpers']))+'\nTYPEDARRAY_TO_REVERSED_DIRECTORIES =')
s=once(s,'ITERATION_SUBTREES = {',"ITERATION_SUBTREES = {\n    'typedarray-copy-within': {'TypedArray/prototype/copyWithin': '9ad9819eb4153745c4cbc561d43541a5e5a2fc5e'},")
s=once(s,'ITERATION_HELPERS = {',"ITERATION_HELPERS = {\n    'typedarray-copy-within': TYPEDARRAY_COPY_WITHIN_HELPERS,")
s=once(s,"TREE_PROFILES = {'typedarray-to-reversed'","TREE_PROFILES = {'typedarray-copy-within', 'typedarray-to-reversed'")
s=once(s,"PROFILES = {'typedarray-to-reversed':","PROFILES = {'typedarray-copy-within': TYPEDARRAY_COPY_WITHIN_DIRECTORIES, 'typedarray-to-reversed':")
s=once(s,"PROFILE_ROOTS = {'typedarray-to-reversed':","PROFILE_ROOTS = {'typedarray-copy-within': 'test/built-ins', 'typedarray-to-reversed':")
a="    if profile == 'typedarray-to-reversed' and harness != TYPEDARRAY_TO_REVERSED_HELPERS:"
s=once(s,a,"    if profile == 'typedarray-copy-within' and harness != TYPEDARRAY_COPY_WITHIN_HELPERS:\n        raise ValueError('TypedArray copyWithin requested harness differs from the frozen nine helpers')\n"+a)
s=once(s,'    scope = {',"    scope = {\n        'typedarray-copy-within': 'all 65 original .js files in the complete TypedArray prototype copyWithin tree, including all 24 BigInt bodies; full root-linked Git proof; no implementation',")
p.write_text(s)
p=D/'test262_conformance.py';s=(O/p.name).read_text()
s=once(s,'TYPEDARRAY_TO_REVERSED_FEATURES =',"TYPEDARRAY_COPY_WITHIN_FEATURES = {'TypedArray', 'ArrayBuffer', 'Symbol', 'Reflect.construct',\n                                  'arrow-function', 'resizable-arraybuffer'}\nTYPEDARRAY_TO_REVERSED_FEATURES =")
s=once(s,"PROFILE_FEATURES = {'typedarray-to-reversed':","PROFILE_FEATURES = {'typedarray-copy-within': TYPEDARRAY_COPY_WITHIN_FEATURES, 'typedarray-to-reversed':")
a="profile in {'typedarray-to-reversed', 'typedarray-reverse'";assert s.count(a)==2;s=s.replace(a,"profile in {'typedarray-copy-within', 'typedarray-to-reversed', 'typedarray-reverse'")
a="    if (profile == 'typedarray-reverse'\n";s=once(s,a,"    if (profile == 'typedarray-copy-within'\n            and 'resizableArrayBufferUtils.js' in metadata['includes']):\n        return 'TypedArray copyWithin policy excludes the complete resizableArrayBufferUtils helper'\n"+a)
a=s.index('def typedarray_to_reversed_preflight_variants():');b=s.index('\ndef typedarray_reverse_preflight_variants():',a)
copy=s[a:b].replace('typedarray_to_reversed','typedarray_copy_within').replace('typedarray-to-reversed','typedarray-copy-within').replace('TypedArray toReversed','TypedArray copyWithin').replace('4ee0fa10856baf96b8a676766650dc91e0ebb27e83d574b48b1f8d7285d96ebc',control_hash)
s=s[:a]+copy+'\n'+s[a:]
a="    if profile == 'typedarray-to-reversed':\n        variants += typedarray_to_reversed_preflight_variants()";s=once(s,a,"    if profile == 'typedarray-copy-within':\n        variants += typedarray_copy_within_preflight_variants()\n"+a)
s=once(s,"            if ((profile == 'typedarray-to-reversed'","            if ((profile == 'typedarray-copy-within' and name.startswith('typedarray-copy-within-'))\n                    or (profile == 'typedarray-to-reversed'")
a=s.index("    if profile == 'typedarray-to-reversed':\n        # Preserve");b=s.index("    if profile == 'typedarray-reverse':\n        # Preserve",a)
s=s[:a]+s[a:b].replace('typedarray-to-reversed','typedarray-copy-within')+s[a:]
s=once(s,"if args.profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill', 'typedarray-reverse'}:","if args.profile in {'typedarray-views', 'typedarray-search', 'typedarray-fill', 'typedarray-reverse', 'typedarray-copy-within'}:")
p.write_text(s)
for source in sorted(O.glob('test_test262*.py')):
    lines=source.read_text().splitlines(True)
    for i,line in enumerate(lines):
        if "'typedarray-to-reversed'" in line and any(x in line for x in ['excluded=', 'excluded =', 'if profile in', 'if name in', 'set(runner.PROFILES)']):
            lines[i]=line.replace("'typedarray-to-reversed'","'typedarray-copy-within', 'typedarray-to-reversed'",1)
    s=''.join(lines)
    if source.name=='test_test262_typedarray_to_reversed.py':
        s=once(s,'len(runner.PROFILES), 52',"len(set(runner.PROFILES) - {'typedarray-copy-within'}), 52")
    (D/source.name).write_text(s)
shutil.copyfile(C/'controls/controls.json',D/'typedarray-copy-within-controls.json')
changed=[]
for old in sorted(O.iterdir()):
    after=D/old.name
    if old.read_bytes()!=after.read_bytes():
        changed.append('tools/'+old.name)
        (C/(old.name+'.diff')).write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),after.read_text().splitlines(True),fromfile='before/tools/'+old.name,tofile='tools/'+old.name)))
(C/'changed-existing-paths.json').write_text(json.dumps(changed,indent=2)+'\n')
print(json.dumps(dict(changed_existing_paths=len(changed))))
