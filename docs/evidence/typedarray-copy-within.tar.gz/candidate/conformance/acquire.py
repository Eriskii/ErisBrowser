"""Public raw byte acquisition and inert literal header scan; no project import."""
from pathlib import Path
import concurrent.futures, hashlib, json, re, shutil, urllib.request
C=Path(__file__).resolve().parent
I=C.parent/'upstream-inventory.json'
inv=json.loads(I.read_bytes()); revision=inv['revision']
base='https://raw.githubusercontent.com/tc39/test262/'+revision+'/'
def fetch(row):
    path=row['path']; out=C/'offline-inputs'/path; out.parent.mkdir(parents=True,exist_ok=True)
    if out.exists(): raise ValueError('fresh acquisition required')
    url=base+path
    with urllib.request.urlopen(url,timeout=30) as response:
        raw=response.read(); status=response.status; final=response.url; headers=dict(response.headers)
    assert len(raw)==row['bytes']
    assert hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==row['git_blob']
    out.write_bytes(raw)
    return dict(path=path,url=url,final_url=final,status=status,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),git_blob=row['git_blob'],headers=headers)
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
    rows=list(pool.map(fetch,inv['files']))
(C/'discovery/acquisition.json').write_text(json.dumps(dict(revision=revision,source_inventory_sha256=hashlib.sha256(I.read_bytes()).hexdigest(),scope='raw network requests only, no project parser/importer/engine',requests=rows),indent=2)+'\n')
result=[]; counts={}; dirs={}; helpers={'assert.js','sta.js'}
for row in rows:
    raw=(C/'offline-inputs'/row['path']).read_text(); match=re.search(r'/\*---(.*?)---\*/',raw,re.S); assert match
    header=match.group(1); metadata={}
    for key in ('flags','includes','features','locale'):
        m=re.search(r'^'+key+r':\s*\[([^\]]*)\]',header,re.M)
        assert m or not re.search(r'^'+key+':',header,re.M),(row['path'],key)
        metadata[key]=[x.strip().strip('"\'') for x in m.group(1).split(',') if x.strip()] if m else []
    assert not re.search(r'^negative:|^timeout:',header,re.M),row['path']
    metadata['negative']=None
    helpers.update(metadata['includes'])
    for feature in metadata['features']: counts[feature]=counts.get(feature,0)+1
    directory=row['path'].removeprefix('test/built-ins/').rsplit('/',1)[0];dirs[directory]=dirs.get(directory,0)+1
    result.append({k:row[k] for k in ('path','git_blob','bytes','sha256')}|{'metadata':metadata})
(C/'discovery/inventory.json').write_text(json.dumps(dict(revision=revision,sources=len(rows),directories=dirs,feature_counts=counts,helpers=sorted(helpers),rows=result,inspection='Independent literal inline-header scan; no project parser'),indent=2)+'\n')
print(json.dumps(dict(sources=len(rows),directories=dirs,feature_counts=counts,helpers=sorted(helpers))))
