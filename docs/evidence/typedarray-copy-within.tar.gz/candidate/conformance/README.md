# Number TypedArray copyWithin preparation

The proposed `typedarray-copy-within` profile retains the complete pinned `TypedArray/prototype/copyWithin` tree at Test262 revision `7ab7fafa0003f73fc85c1b95d88094d33f7eb8bd`. Tree `9ad9819eb4153745c4cbc561d43541a5e5a2fc5e` contains 41 direct JavaScript bodies plus all 24 BigInt child bodies. The root-linked tree chain and both directory objects reconstruct exactly. All 65 original bodies, nine original helpers, two legal files and eight selected Git proof documents give 84 exact offline inputs.

All bodies have ordinary sloppy/strict scheduling: 130 modes. The source-only policy schedules 66 and excludes 48 BigInt, six modes requiring the complete `resizableArrayBufferUtils.js`, eight requiring Test262 host hooks, and two declaring immutable ArrayBuffers. Exclusions follow the existing runner's feature-first precedence; originals and helpers are retained whole. The profile admits only the six declared feature tags already admitted by the Number reverse/fill slices: TypedArray, ArrayBuffer, Symbol, Reflect.construct, arrow-function and resizable-arraybuffer. Existing 52 profiles, feature sets, exclusions, defaults and harness behavior remain exact.

Six independently authored positive/wrong pairs supply 24 feature observations alongside the unchanged 32 common controls. Both partners first require a working authentic overlapping copy and returned receiver identity. The wrong partner changes one literal expectation after the common semantic checks, throws intrinsic Error, and is verified only with a successful positive in the same mode. Controls cover all ten Number kinds, both overlap directions, offset aliases and untouched sentinels, raw Float16/32/64 NaN and negative-zero encodings, ordered target/start/end conversion, clamping and abrupt callback identity, initial versus refreshed bounds, no-op behavior after late invalidity, captured length during growth, shrink-limited prefixes, partial trailing Uint16 bytes, saved metadata, ignored extra argument values and internal rather than public length.

The [copyWithin algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.copywithin) validates initially, converts indices against the captured length, and revalidates only if the initial copy count is positive. The byte copy preserves encodings and overlap semantics; no numeric codec is used to derive the controls. The partial Uint16 trailing-byte literal uses the runtime's previously held little-endian buffer contract. These controls make no shared-buffer, BigInt, complete conformance or performance claim.

Nine mocked protocol groups cover the complete inventory, exact helper/proof/body hashes, retained excluded rows, paired-control identity and mode gating, protocol errors, unchanged common controls, resource health and offline import identity. Policy serialization includes the profile-local helper exclusion in the hash. Removing only the new profile additions from the AST reconstructs all 23 changed original modules: the two shared tools plus 21 historical registration-test exclusions. Their prior population/count/hash oracles remain unchanged.

The author performed raw public-source retrieval, inert Git-tree/blob reconstruction, literal/header inspection and Python AST/source transformations only. No project importer, parser, test, formatter, compiler, engine or browser was executed. The initial restricted-network DNS failure and successful authorized source acquisition are distinguished. All drafts remain under this preparation directory until root-authorized copying to the new worktree.

## Root handoff

Target worktree: `/tmp/eris-typedarray-copy-within-1/worktree`, base `b46879dd20ee1b04b16a0baac5c33b35264db60b`. After copying the held 25 tooling paths, run from that worktree:

```sh
python3 /tmp/eris-own-keys-one-pass-1/next-method/conformance/offline_import.py
python3 -m unittest discover -s tools -p 'test_test262*.py'
python3 tools/test262_conformance.py --profile typedarray-copy-within --binary /tmp/eris-own-keys-one-pass-1/eris-js-candidate-1 --output /tmp/eris-typedarray-copy-within-1/upstream-before.json --jobs 2
```

The published predecessor binary SHA256 is `b366575d98cffdedbf20f5345ab44d11fb2d615d57ba7e7b94a30c756a38d8a9`. The offline handoff refuses an existing target, authenticates importer and all 84 inputs before/after, and has no network fallback. The network equivalent is `python3 tools/import_test262.py --profile typedarray-copy-within`; choose one route and retain all attempts.

Before and candidate outcomes are unknown in this preparation. Preserve every mode and nonzero exit. Healthy controls do not make a report healthy when resource, timeout or adapter-error rows remain. No baseline or CI gate is proposed from unrun observations.
