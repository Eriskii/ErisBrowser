"""Source text adaptation of mocked protocols only; no project execution."""
from pathlib import Path
import json
C=Path(__file__).resolve().parent
s=(C/'original/test_test262_typedarray_reverse.py').read_text()
s=s.replace('typedarray-reverse','typedarray-copy-within').replace('TypedArrayReverseTests','TypedArrayCopyWithinTests').replace('TypedArray reverse','TypedArray copyWithin').replace('prototype/reverse','prototype/copyWithin').replace('Pinned reverse','Pinned copyWithin')
a=s.index('PAIRS = ');b=s.index('\nDIRECTORIES =',a)
s=s[:a]+"PAIRS = "+repr([r['pair'] for r in json.loads((C/'controls/controls.json').read_bytes())['controls'] if r['positive']])+s[b:]
s=s.replace("DIRECTORIES = {'TypedArray/prototype/copyWithin': 16, 'TypedArray/prototype/copyWithin/BigInt': 6}","DIRECTORIES = {'TypedArray/prototype/copyWithin': 41, 'TypedArray/prototype/copyWithin/BigInt': 24}")
s=s.replace('(22, 44, 32, [])','(65, 130, 76, [])').replace('[22, 22]','[65, 65]')
s=s.replace("'compareArray.js'})","'compareArray.js', 'nans.js'})")
s=s.replace('reasons.count(None), 26','reasons.count(None), 66').replace("reasons.count('unimplemented declared features: BigInt'), 12","reasons.count('unimplemented declared features: BigInt'), 48")
s=s.replace("reasons.count('Test262 host hooks are not implemented (conservative source check)'), 2","reasons.count('Test262 host hooks are not implemented (conservative source check)'), 8")
s=s.replace("reasons.count('TypedArray copyWithin policy excludes the complete resizableArrayBufferUtils helper'), 2","reasons.count('TypedArray copyWithin policy excludes the complete resizableArrayBufferUtils helper'), 6")
s=s.replace('is None for c in cases), 28','is None for c in cases), 72').replace("'/BigInt/' in c['file'] for c in cases), 12","'/BigInt/' in c['file'] for c in cases), 48")
s=s.replace("len(set(runner.PROFILES) - {'typedarray-to-reversed'}), 51","len(runner.PROFILES), 53")
s=s.replace('c85cbbe7be55bc264403165a554d3b85de858358bd97583d614b66d766669c28',json.loads((C/'controls/source-ready.json').read_bytes())['source_sha256'])
s=s.replace('(52, 52)','(56, 56)').replace('len(results), 52','len(results), 56').replace("sum(o['verified'] for o in outcomes[32:]), 10","sum(o['verified'] for o in outcomes[32:]), 12")
s=s.replace('cfbd5368520d987e1256f9981c2e587d898f1df7','9ad9819eb4153745c4cbc561d43541a5e5a2fc5e')
s=s.replace("[(PROFILE, 26), ('typedarray-fill', 54)","[(PROFILE, 66), ('typedarray-reverse', 26), ('typedarray-fill', 54)")
s=s.replace("'harness/testTypedArray.js', 'harness/resizableArrayBufferUtils.js', 'LICENSE']","'harness/testTypedArray.js', 'harness/nans.js', 'harness/resizableArrayBufferUtils.js', 'LICENSE']")
s=s.replace("['harness/testTypedArray.js', 'harness/detachArrayBuffer.js', 'harness/isConstructor.js', 'LICENSE']","['harness/testTypedArray.js', 'harness/nans.js', 'harness/detachArrayBuffer.js', 'harness/isConstructor.js', 'LICENSE']")
(C/'draft/tools/test_test262_typedarray_copy_within.py').write_text(s)
