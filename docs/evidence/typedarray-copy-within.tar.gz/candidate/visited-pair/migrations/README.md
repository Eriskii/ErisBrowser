# Inline visited-pair test migrations

Source-only drafts for exactly `src/script/own_keys/singleton_tests.rs` and `src/script/own_keys/tests.rs`. The live worktree is untouched. Both original files and their hashes are preserved. Root owns production, integration, formatting, compilation and execution; Layout owns separate new semantic cases.

The chosen `Single / Pair([JsString; 2]) / Tree` shape retains insertion order inside Pair and stores no live descriptor, prototype or buffer state. JsString is a retained `Rc<[u16]>` handle, so constructing Pair clones handles without copying UTF-16 or allocating an inner node. The test-only `keys()` adapter returns the two references in lexical order to preserve the old BTreeMap inspection contract. Duplicate setup and inspection keep the original Rc payload. Production enumeration order never comes from this visited-set ordering.

On the held 64-bit representation, JsString is16 bytes and Tree's map header24. A third32-byte Pair payload is expected to make the enum40 rather than the current32; root must measure the actual Rust layouts. The existing `sizeof(NameBucket)` outer-node formula then rises960→1088 charged bytes for every fresh length, including lengths that stay singleton. A pair's second key costs zero additional heap. The third key precharges one unchanged576-byte inner-node allowance before all three inserts. This is not an unconditional heap reduction: all-singleton inputs pay the larger outer allowance. VisitedNames still contains only the outer map header, so the frame need not grow merely because node payloads do.

Literal admission arithmetic follows the independently read reached operations, with a zero-cost descriptor reader and one outer length bucket:

- Second distinct present key: outer4 + enum2 + equality(1+L) + publication8 =15+L, zero heap. L2 gives17. All resource cuts before publication retain Single; the full-heap endpoint succeeds.
- Pair duplicate first:7+L. Reaching the second comparison or a missing descriptor:8+2L. Every reached comparison prepays its own full UTF-16 bound.
- Third distinct present key: outer4 + enum2 + two equalities2(1+L) + promotion88+3L =96+5L. L2 gives106 and one inner allowance. The promotion envelope is three bounded local insertions25 each, one-key search3+L, two-key search4+2L and six handle/publication/retirement operations. The three-entry leaf cannot split. The pair remains intact through unpaid work/heap and while staging the new map.
- An existing three-key Tree inserting the fourth L2 name retains the old general formula:4+2+(1+1+3*3)+(1+2*24)=66, one inner allowance. The general tree branch and its height/split bounds are unchanged.

The singleton file retains all eight original groups. Four groups are byte-identical. The changed groups preserve UTF-16/pointer assertions, both insertion orders, all-stage work cuts, exact/one-short heap promotion checks, immutable object/order state, cumulative heap refusal and outer-allocation independence. The smallest actual Tree population in the general-tree group changes2→3; the two-name boundary is now tested as Pair and the third insertion receives explicit staged failure checks. Original hidden-name/deletion/VM-effect bodies are unchanged.

The legacy file retains all26 original groups; only two allocation contracts change. The cumulative test admits the second name at MAX_HEAP, then refuses the third. The prepayment test now has four branches: fresh bucket, second inline name, third-key promotion and existing-tree insertion. Every branch retains exact/one-short work and unchanged-set checks. Heap one-short cuts apply to the three allocating branches; subtracting one from zero heap is deliberately avoided, and the Pair success endpoint runs at MAX_HEAP. Frozen JS fixtures and every other original group remain unchanged.

No Rust source was formatted, parsed, compiled or executed by this author. No recovery, benchmark, final size or conformance result is claimed.
