"""Source text migration only; never compile or execute Rust."""
from pathlib import Path
M=Path(__file__).resolve().parent
s=(M/'original/singleton_tests.rs').read_text()
s=s.replace('    Single(std::iter::Once<&\'a JsString>),','    Single(std::iter::Once<&\'a JsString>),\n    Pair(std::array::IntoIter<&\'a JsString, 2>),')
s=s.replace('            Self::Single(keys) => keys.next(),','            Self::Single(keys) => keys.next(),\n            Self::Pair(keys) => keys.next(),')
s=s.replace('''            Self::Single(old) => {
                let mut tree = BTreeMap::new();
                tree.insert(old.clone(), ());
                tree.insert(key, ());
                *self = Self::Tree(tree);
            }
''','''            Self::Single(old) => {
                *self = Self::Pair([old.clone(), key]);
            }
            Self::Pair(pair) if pair[0] == key || pair[1] == key => {}
            Self::Pair(pair) => {
                let mut tree = BTreeMap::new();
                tree.insert(pair[0].clone(), ());
                tree.insert(pair[1].clone(), ());
                tree.insert(key, ());
                *self = Self::Tree(tree);
            }
''')
s=s.replace('''            Self::Single(key) => BucketKeys::Single(std::iter::once(key)),
''','''            Self::Single(key) => BucketKeys::Single(std::iter::once(key)),
            // Test-only inspection keeps the old map's lexical view. Production
            // Pair retains insertion order; visited ordering is not observable.
            Self::Pair(pair) => BucketKeys::Pair(if pair[0] <= pair[1] {
                [&pair[0], &pair[1]].into_iter()
            } else {
                [&pair[1], &pair[0]].into_iter()
            }),
''')
s=s.replace('''            Self::Single(_) => None,
            Self::Tree(tree) => tree.get_key_value(key),''','''            Self::Single(_) => None,
            Self::Pair(pair) if &pair[0] == key => Some((&pair[0], &())),
            Self::Pair(pair) if &pair[1] == key => Some((&pair[1], &())),
            Self::Pair(_) => None,
            Self::Tree(tree) => tree.get_key_value(key),''')
s=s.replace('            Self::Single(_) => false,','            Self::Single(_) | Self::Pair(_) => false,')
s=s.replace('''                assert_eq!(spent(&runtime), (64 + 2 * key.len(), VISITED_NAME_BYTES));
''','''                assert_eq!(spent(&runtime), (15 + key.len(), 0));
            } else if i == 2 {
                assert_eq!(spent(&runtime), (96 + 5 * key.len(), VISITED_NAME_BYTES));
''')
s=s.replace('''            } else {
                assert!(matches!(visited.buckets[&key.len()], NameBucket::Tree(_)));
''','''            } else if i == 1 {
                assert!(matches!(visited.buckets[&key.len()], NameBucket::Pair(_)));
            } else {
                assert!(matches!(visited.buckets[&key.len()], NameBucket::Tree(_)));
''')
a=s.index('#[test]\nfn singleton_promotion_all_stage_cuts_retain_original_single()');b=s.index('\n#[test]',a+2)
s=s[:a]+'''#[test]
fn singleton_promotion_all_stage_cuts_retain_original_single() {
    for (first, second) in [("aa", "bb"), ("bb", "aa")] {
        let prepare = || {
            let (mut runtime, doc) = fresh();
            let old = JsString::from(first);
            let new = JsString::from(second);
            let third = JsString::from("cc");
            let target = object(&mut runtime, &[old.clone(), new.clone(), third.clone()]);
            let mut visited = VisitedNames::default();
            runtime.for_in_visit(&mut visited, &target, &old).unwrap().unwrap();
            (runtime, doc, target, old, new, third, visited)
        };
        // 4 outer +2 enum +3 equality +8 Pair admission. Reader costs0.
        // No heap is needed for the second retained handle.
        for steps in [0, 3, 5, 8, 9, 16, 17] {
            let (mut runtime, _, target, old, new, _, mut visited) = prepare();
            let before = visited.clone();
            let object_count = runtime.objects.len();
            let id = runtime.property_object(&target).unwrap();
            let order = runtime.objects[id].order.clone();
            runtime.steps = steps;
            runtime.allocated = MAX_HEAP;
            let result = runtime.for_in_visit(&mut visited, &target, &new);
            if steps == 17 {
                assert!(result.unwrap().is_some());
                assert_eq!(runtime.steps, 0);
                assert!(matches!(visited.buckets[&2], NameBucket::Pair(_)));
                assert_eq!(retain(&visited, &new).units().as_ptr(), new.units().as_ptr());
            } else {
                assert!(result.unwrap_err().is_resource_limit());
                assert_eq!(visited, before);
            }
            assert_eq!(runtime.allocated, MAX_HEAP);
            assert_eq!(retain(&visited, &old).units().as_ptr(), old.units().as_ptr());
            assert_eq!(runtime.objects.len(), object_count);
            assert_eq!(runtime.objects[id].order, order);
            clean(&runtime);
        }
        // The former tree-promotion heap contract moves to the third distinct
        // key: 4 outer +2 enum +3 +3 equality +94 complete promotion =106.
        for steps in [0, 3, 5, 8, 9, 11, 12, 105, 106] {
            let (mut runtime, _, target, old, new, third, mut visited) = prepare();
            runtime.for_in_visit(&mut visited, &target, &new).unwrap().unwrap();
            let before = visited.clone();
            let object_count = runtime.objects.len();
            let id = runtime.property_object(&target).unwrap();
            let order = runtime.objects[id].order.clone();
            runtime.steps = steps;
            runtime.allocated = MAX_HEAP - VISITED_NAME_BYTES;
            let result = runtime.for_in_visit(&mut visited, &target, &third);
            if steps == 106 {
                assert!(result.unwrap().is_some());
                assert_eq!(runtime.steps, 0);
                assert_eq!(runtime.allocated, MAX_HEAP);
                assert!(matches!(visited.buckets[&2], NameBucket::Tree(_)));
                assert_eq!(retain(&visited, &third).units().as_ptr(), third.units().as_ptr());
            } else {
                assert!(result.unwrap_err().is_resource_limit());
                assert_eq!(visited, before);
            }
            assert_eq!(retain(&visited, &old).units().as_ptr(), old.units().as_ptr());
            assert_eq!(retain(&visited, &new).units().as_ptr(), new.units().as_ptr());
            assert_eq!(runtime.objects.len(), object_count);
            assert_eq!(runtime.objects[id].order, order);
            clean(&runtime);
        }
        let (mut runtime, _, target, old, new, third, mut visited) = prepare();
        runtime.for_in_visit(&mut visited, &target, &new).unwrap().unwrap();
        let before = visited.clone();
        runtime.steps = 106;
        runtime.allocated = MAX_HEAP - VISITED_NAME_BYTES + 1;
        assert!(runtime.for_in_visit(&mut visited, &target, &third).unwrap_err().is_resource_limit());
        assert_eq!(visited, before);
        assert_eq!(retain(&visited, &old).units().as_ptr(), old.units().as_ptr());
        assert_eq!(retain(&visited, &new).units().as_ptr(), new.units().as_ptr());
        clean(&runtime);
    }
}
''' +s[b:]
s=s.replace('for count in [2, 10, 11, 12, 70, 71, 72]', 'for count in [3, 10, 11, 12, 70, 71, 72]')
a=s.index('#[test]\nfn singleton_outer_search_and_cumulative_storage_are_independent()');b=s.index('\n#[test]',a+2)
s=s[:a]+'''#[test]
fn singleton_outer_search_and_cumulative_storage_are_independent() {
    let (mut runtime, _) = fresh();
    let keys: Vec<JsString> = ["aa", "bb", "cc", "dd"].into_iter().map(JsString::from).collect();
    let target = object(&mut runtime, &keys);
    let mut visited = VisitedNames::default();
    reset(&mut runtime);
    runtime.for_in_visit(&mut visited, &target, &keys[0]).unwrap().unwrap();
    assert_eq!(spent(&runtime), (31, VISITED_BUCKET_BYTES));
    runtime.steps = 17;
    runtime.allocated = MAX_HEAP;
    runtime.for_in_visit(&mut visited, &target, &keys[1]).unwrap().unwrap();
    assert_eq!(runtime.steps, 0);
    assert_eq!(runtime.allocated, MAX_HEAP);
    let pair = visited.clone();
    runtime.steps = 106;
    assert!(runtime.for_in_visit(&mut visited, &target, &keys[2]).unwrap_err().is_resource_limit());
    assert_eq!(visited, pair);
    runtime.steps = 106;
    runtime.allocated = MAX_HEAP - VISITED_NAME_BYTES;
    runtime.for_in_visit(&mut visited, &target, &keys[2]).unwrap().unwrap();
    assert_eq!(runtime.steps, 0);
    assert_eq!(runtime.allocated, MAX_HEAP);
    let before = visited.clone();
    // The unchanged general-tree path now begins after three retained names.
    runtime.steps = 66;
    assert!(runtime.for_in_visit(&mut visited, &target, &keys[3]).unwrap_err().is_resource_limit());
    assert_eq!(visited, before);
    // A fresh independent set cannot reuse the previous outer allocation.
    let mut other = VisitedNames::default();
    runtime.steps = 31;
    assert!(runtime.for_in_visit(&mut other, &target, &keys[0]).unwrap_err().is_resource_limit());
    assert!(other.buckets.is_empty());
    println!(
        "SINGLETON_STORAGE bucket={} tree={} visited={} inner_allowance={} outer_allowance={}",
        std::mem::size_of::<NameBucket>(),
        std::mem::size_of::<BTreeMap<JsString, ()>>(),
        std::mem::size_of::<VisitedNames>(),
        VISITED_NAME_BYTES,
        VISITED_BUCKET_BYTES
    );
}
''' +s[b:]
(M/'draft/singleton_tests.rs').write_text(s)
s=(M/'original/tests.rs').read_text()
s=s.replace('''    // The second distinct name promotes the inline singleton to one inner leaf.
    runtime.allocated = MAX_HEAP - VISITED_NAME_BYTES;''','''    // The second distinct name stays inline even at the heap limit; the third
    // still needs its independently admitted inner-leaf allowance.
    runtime.allocated = MAX_HEAP;''')
a='''        .for_in_visit(&mut visited, &target, &"b".into())
        .unwrap()
        .unwrap();
    assert!('''
b='''        .for_in_visit(&mut visited, &target, &"b".into())
        .unwrap()
        .unwrap();
    assert_eq!(runtime.allocated, MAX_HEAP);
    assert!('''
assert s.count(a)==1;s=s.replace(a,b)
s=s.replace('''    // Fresh length, inline promotion and an already-promoted tree are
    // separately reached storage contracts. All semantic/cut assertions remain.
    for branch in 0..3 {''','''    // Fresh length, second inline name, third-key promotion and general-tree
    // insertion are separate storage contracts. Semantic assertions remain.
    for branch in 0..4 {''')
s=s.replace('''            1 => &["bb"],
            _ => &["aa", "bb"],''','''            1 => &["bb"],
            2 => &["aa", "bb"],
            _ => &["aa", "bb", "cc"],''')
s=s.replace('''                VISITED_BUCKET_BYTES
            } else {
                VISITED_NAME_BYTES''','''                VISITED_BUCKET_BYTES
            } else if branch == 1 {
                0
            } else {
                VISITED_NAME_BYTES''')
s=s.replace('''        // Every new path has one reached allocation allowance. The old cuts
        // for half of two allocations no longer describe a possible operation.
        let cuts = [(work - 1, heap), (work, heap - 1), (work, 0)];''','''        // Pair admission allocates nothing. Keep exact/one-short heap cuts for
        // the three allocating paths, and a work cut for every branch.
        let mut cuts = vec![(work - 1, heap)];
        if heap != 0 {
            cuts.extend([(work, heap - 1), (work, 0)]);
        }''')
(M/'draft/tests.rs').write_text(s)
