# Visited-name Pair benchmark

This is a source-only, fixed-input before/after benchmark. Root alone reconstructs sources, builds, verifies and executes it. No measurements have informed the fixtures or assertions. The scope is complete JavaScript for-in statements, not the visited-set helper in isolation.

## Fixed population and oracle

Eight workloads are frozen in fixtures/manifest.json, with literal setup sources and exact expected UTF-16LE bytes. Every own name is nonnumeric. Seven fixtures use null-prototype ordinary objects so unrelated Object or TypedArray prototype growth cannot change the targeted bucket sizes. The eighth has a fixed three-object chain ending in null.

- same1/2/3/12 contain respectively one, two, three and twelve length-two names in deliberately nonlexicographic creation order. They expose unchanged Single, inline Pair, immediate third-name promotion and an already-general-tree path.
- varied12 has twelve distinct UTF-16 name lengths, each forming an outer singleton. It exposes increased outer-node storage without using Pair.
- hidden-chain has own bb/zz, middle hidden aa plus mm/nn, and top aa/bb/cc/tail. The exact result is bb,zz,mm,nn,cc,tail,. A throwing hidden getter must not execute; duplicate names remain suppressed.
- long2/3 contain two/three 512-code-unit names. Each starts with 511 lone U+D800 units and ends with a distinct literal a/b/c. The expected files contain the exact units plus comma separators. Equality must reach the final code unit; no UTF-8 replacement or normalization is accepted.

The reference files were authored from these literal definitions, not candidate output, a project parser, a codec or runtime observations. Rust compares every returned unit and the entire length against the frozen bytes. Any Resource/error/wrong type/wrong result fails. Each process checks all eight complete results on fresh runtimes before starting any timer, emits eight CHECK receipts, then checks every warmup and timed result outside the timer. No fixture may be dropped, shortened or retuned after results.

## What is timed

Each process takes 21 fresh-runtime samples for every fixture. A sample creates Runtime and Document and executes the fixed object setup outside timing, then performs two checked warmup calls followed by five timed execute calls. The body parses and executes a complete for-in, snapshots own keys, reads live descriptors, manages visited names and concatenates the emitted keys. Runtime::execute resets its work budget per call; the fresh runtime per sample bounds cumulative heap. Limits are unchanged.

Rust Instant encloses only Runtime::execute. Bootstrap/object setup, preflight/warmup, exact result verification, Rust formatting/I/O, process/wrapper startup and rendering are excluded. Elapsed times of all five calls are summed per sample. All 168 raw sample totals per process are retained; medians and nearest-rank p95 describe these five-call sample means, not individual invocation tails.

## Identical builds and source isolation

The before manifest points at benchmark/before-engine. Root reconstructs the exact K compiled-source-1 production snapshot there from held source, without .git or target outputs. The after manifest points at K/worktree and binds the chosen frozen Pair source snapshot (initially compiled-source-2). Root verifies the complete production delta is the intended visited-pair change; historical tests/migrations are not compiled into this release harness. Both roots already include copyWithin, so method metadata is not a before/after confounder.

The two manifests share this exact Rust source and fixtures and differ only in the Eris dependency path. Both explicitly use default-features=false, Rust1.88 release, thin LTO, one codegen unit and strip=true. No new dependency or production API is added. Root seeds both benchmark locks from the same parent Cargo.lock, resolves only the benchmark root package and unused-package pruning if necessary, then checks every retained registry version/checksum and exact lock equality. Build both with the same toolchain/features/environment and repeat --locked. A fresh resolver selecting alternate dependency versions is unacceptable.

Before timing root records source manifests, compiler version, build commands/features, final harness source, both binary hashes and their exact build/source joins. run.py requires --before-source-binding and --after-source-binding: each must be a root-produced JSON snapshot with source_sha256. The runner verifies every bound source path/hash in the corresponding root, including crates and assets, rather than inferring identity from HEAD. The reconstructed root needs no Git metadata. Build-to-binary provenance remains a separate root receipt; hashing a binary alone does not prove how it was built.

## Fixed execution protocol

Use run.py with the two binary paths, source bindings and a fresh output directory. It runs three process pairs in order AB, BA, AB (before/after, after/before, before/after). The same optional Python FD-sanitizing wrapper and child environment apply to both binaries. Wrapper/loader paths and LD_LIBRARY_PATH/LD_PRELOAD/LD_AUDIT are recorded; wrapper wall time is not part of Rust timing. No compilers, corpus replays or unrelated benchmarks should run concurrently.

Each process must return exit0, no stderr, the exact versioned header, all eight literal CHECK rows in roster order, 168 ordered timing rows with positive canonical integer times and an exact END168/840 record. A timeout or interruption terminates/reaps the owned process group. Completed or timed-out child stdout/stderr and failures are retained and must not be relabeled as successful timing samples. A manual external interruption still kills/reaps the owned group; it can precede receipt publication, so report that interrupted attempt explicitly instead of silently replacing it.

A full measurement is six processes, 48 semantic preflight calls, 2,016 warmup calls and 5,040 timed execute calls. It yields 63 sample means per variant/workload, 1,008 timing rows overall. Root retains all six raw stdout/stderr pairs, process receipts, both source/binary/input snapshots and before/after environment records. Inputs must remain byte-exact during execution. Per-process and pooled median/p95 are reported for all eight fixtures, including every regression. P95 uses ceil(0.95*N), i.e. the twentieth of21 or sixtieth of63 sorted sample means.

These are descriptive local timings. Report process order, sample counts, timing units, tail changes and limitations. Do not infer statistical significance, browser/Chromium parity, isolated helper speed, general security or all-program performance. The known ordinary-descriptor regression and full corpus checks are separate correctness evidence, not benchmark outcomes.
