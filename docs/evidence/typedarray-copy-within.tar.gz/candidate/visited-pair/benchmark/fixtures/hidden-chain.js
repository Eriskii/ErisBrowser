var benchTop=Object.create(null);benchTop.aa=10;benchTop.bb=11;benchTop.cc=12;benchTop.tail=13;
var benchMiddle=Object.create(benchTop);
Object.defineProperty(benchMiddle,'aa',{get:function(){throw new Error('enumeration read hidden value');},enumerable:false});
benchMiddle.mm=21;benchMiddle.nn=22;
var benchObject=Object.create(benchMiddle);benchObject.bb=30;benchObject.zz=31;
