var benchObject=Object.create(null);
benchObject['ba']=0;
benchObject['aa']=1;
benchObject['ca']=2;
