var benchObject=Object.create(null);
benchObject['ba']=0;
