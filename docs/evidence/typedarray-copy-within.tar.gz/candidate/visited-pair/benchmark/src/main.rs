use eris::{
    dom::Document,
    script::{Runtime, Value},
};
use std::{env, process::ExitCode, time::Instant};

const SAMPLES: usize = 21;
const WARMUP: usize = 2;
const REPS: usize = 5;
const BODY: &str =
    "var benchOut='';for(var benchKey in benchObject){benchOut+=benchKey+',';}benchOut;";

struct Case {
    name: &'static str,
    setup: &'static str,
    expected: &'static [u8],
}
fn cases() -> [Case; 8] {
    [
        Case {
            name: "same1",
            setup: include_str!("../fixtures/same1.js"),
            expected: include_bytes!("../fixtures/same1.utf16le"),
        },
        Case {
            name: "same2",
            setup: include_str!("../fixtures/same2.js"),
            expected: include_bytes!("../fixtures/same2.utf16le"),
        },
        Case {
            name: "same3",
            setup: include_str!("../fixtures/same3.js"),
            expected: include_bytes!("../fixtures/same3.utf16le"),
        },
        Case {
            name: "same12",
            setup: include_str!("../fixtures/same12.js"),
            expected: include_bytes!("../fixtures/same12.utf16le"),
        },
        Case {
            name: "varied12",
            setup: include_str!("../fixtures/varied12.js"),
            expected: include_bytes!("../fixtures/varied12.utf16le"),
        },
        Case {
            name: "hidden-chain",
            setup: include_str!("../fixtures/hidden-chain.js"),
            expected: include_bytes!("../fixtures/hidden-chain.utf16le"),
        },
        Case {
            name: "long2",
            setup: include_str!("../fixtures/long2.js"),
            expected: include_bytes!("../fixtures/long2.utf16le"),
        },
        Case {
            name: "long3",
            setup: include_str!("../fixtures/long3.js"),
            expected: include_bytes!("../fixtures/long3.utf16le"),
        },
    ]
}
fn check(value: Result<Value, eris::script::ScriptError>, case: &Case) -> Result<(), String> {
    match value {
        Ok(Value::String(text))
            if text.len().checked_mul(2) == Some(case.expected.len())
                && text
                    .units()
                    .iter()
                    .zip(case.expected.chunks_exact(2))
                    .all(|(unit, bytes)| *unit == u16::from_le_bytes([bytes[0], bytes[1]])) =>
        {
            Ok(())
        }
        other => Err(format!(
            "{} enumeration mismatch: {other:?}; expected {} literal UTF16 units",
            case.name,
            case.expected.len() / 2
        )),
    }
}
fn fixture(case: &Case) -> Result<(Runtime, Document), String> {
    let mut runtime = Runtime::try_new().map_err(|error| error.to_string())?;
    let mut document = Document::parse("<!doctype html><title>Visited names benchmark</title>");
    runtime
        .execute(case.setup, &mut document)
        .map_err(|error| error.to_string())?;
    Ok((runtime, document))
}
fn run() -> Result<(), String> {
    let args: Vec<_> = env::args().skip(1).collect();
    if args.len() != 1 {
        return Err("expected round number 0..3".into());
    }
    let round: usize = args[0].parse().map_err(|_| "invalid round")?;
    if round >= 3 {
        return Err("round number outside 0..3".into());
    }
    println!("ERIS_VISITED_PAIR_BENCH\t1\t{round}\t{SAMPLES}\t{WARMUP}\t{REPS}");
    let cases = cases();
    // Every literal oracle is checked before this process starts any timer.
    for case in &cases {
        if !case.expected.chunks_exact(2).remainder().is_empty() {
            return Err("odd UTF16 fixture byte count".into());
        }
        let (mut runtime, mut document) = fixture(case)?;
        check(runtime.execute(BODY, &mut document), case)?;
        println!("CHECK\t{}\t{}", case.name, case.expected.len() / 2);
    }
    let mut rows = 0;
    for case in &cases {
        for sample in 0..SAMPLES {
            let (mut runtime, mut document) = fixture(case)?;
            for _ in 0..WARMUP {
                check(runtime.execute(BODY, &mut document), case)?;
            }
            let mut total = 0u128;
            for _ in 0..REPS {
                let start = Instant::now();
                let value = runtime.execute(BODY, &mut document);
                let elapsed = start.elapsed().as_nanos();
                check(value, case)?;
                if elapsed == 0 {
                    return Err("zero timer interval".into());
                }
                total = total.checked_add(elapsed).ok_or("timer overflow")?;
            }
            println!("ROW\t{}\t{sample}\t{total}\t{REPS}", case.name);
            rows += 1;
        }
    }
    println!("END\t{rows}\t{}", rows * REPS);
    Ok(())
}
fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => {
            eprintln!("BENCH_FAIL\t{error}");
            ExitCode::FAILURE
        }
    }
}
