# Independent visited-pair tests

Ten groups authored from root's stated Single → Pair([JsString; 2]) → Tree design and the held predecessor own_keys.rs. The candidate production source was not read before this hold. No project importer, compiler, formatter, parser, tests or engine was executed by this author. Install as a new child of script::own_keys (for example pair_tests); root adds registration and owns execution. The test file has no dependency on historical singleton representation adapters.

All direct targets are newly created ordinary objects without TypedArray records. Their own-descriptor reader adds no work; the tests isolate the existing visited operation. Object setup, visited seeds/clones and inspection are outside observed counters. Public programs separately exercise the real for-in machine in sloppy and strict modes.

## Literal arithmetic

With one outer length bucket, entry admission is tick1 + (1+node1+comparison1) =4. Occupied variant dispatch is2. Each reached same-length comparison costs L+1. Root specifies second-name admission8, and third-name promotion88+3L. Therefore:

- First name: empty outer admission2 + first-inline insertion29 =31; one actual-type VISITED_BUCKET_BYTES.
- Single duplicate/missing: 4+2+(L+1)=7+L; no allocation or reader for duplicates.
- Single → Pair: 4+2+(L+1)+8=15+L; no new heap. At L=2,17.
- Pair first duplicate:7+L. Pair second duplicate/missing:8+2L. At L=2,9 and12 respectively.
- Pair → Tree:4+2+2*(L+1)+(88+3L)=96+5L. At L=2,106; one VISITED_NAME_BYTES.
- Independent refused reader explicitly consumes5 before returning Resource; visited prefixes remain2(empty),9(Single L2),12(Pair L2).
- New missing length under one occupied outer bucket consumes4 and creates no bucket. New present length consumes4+(4+1+2*24)=57 and one VISITED_BUCKET_BYTES.

All available-work integers0..17 and0..106 are checked around second/third admission. Below the complete boundary the prior set and retained key pointers remain exact. Pair formation succeeds with already-full cumulative heap because it allocates nothing. Tree promotion checks exact and one-short heap; the existing charge function counts the rejected addition, so one-short allocated becomes MAX_HEAP+1 while Pair remains unchanged. The tests intentionally preserve this cumulative accounting behavior.

The unchanged general-tree row for a length4 name and one occupied outer bucket is 4+2+(1+nodes+5*comparisons)+(1+24*(nodes+1)). Literal expected rows, independently calculated from the original B=6 height envelope, are:

| Existing inner count | comparisons | nodes | work |
| --- | --- | --- | --- |
|3|3|1|72|
|10|10|1|107|
|11|11|2|137|
|12|12|2|142|
|70|22|2|192|
|71|33|3|272|
|72|33|3|272|

Each successful general-tree insertion retains the old one-node allocation allowance and all existing identities. Exact/one-short work and heap are checked at each size. These are conservative logical admission formulas; actual comparator counts or machine cycles are not inferred.

The Pair enum can enlarge the outer node and continuation storage. Tests use VISITED_BUCKET_BYTES computed from the actual enum, and never assert old byte sizes. Root must measure relevant type sizes/bootstrap allocation after integration. No runtime quota or charge is adjusted to fit a regression budget.

## Literal semantic oracles

- Empty keys remain Single on equal-content duplicates. NUL, lone high/low surrogates, reversed surrogate pairs and 512-unit common-prefix strings are independent UTF-16 keys. Fresh equal-content allocations must match without replacing the original payload pointer.
- Pair insertion order is first-arrival order, even when reverse lexicographic. Third promotion in ascending, descending and mixed arrival order preserves all original Rc payload identities. Public iteration order is independent of the visited-set representation.
- Duplicate first and second names use a panic reader, proving no descriptor read occurs. Missing names and a terminal Resource reader preserve Single/Pair and do not insert empty length buckets.
- First public program: start is emitted; hidden aa/bb never call getters and shadow inherited copies; deleted own cc remains eligible at its later prototype. Literal result start|cc|dd|.
- Second public program: already-visited hidden aa/bb keep shadowing after later redefinition/deletion. Literal result zz|cc|.
- Third public program: prototype replacement in the first body is read after the current own-key snapshot. Literal result aa|bb|cc|, inherited duplicate bb suppressed.
- Fourth public program: shrinking a real tracking Uint8Array after index0 makes snapshotted own1 absent, so prototype1 remains eligible. Literal result 0|1|x|y|. No stale descriptor or TypedArray state is permitted.

The mutation order literals deliberately test existing interpreter snapshot semantics, not a claim of universal enumeration order under all ECMAScript mutation scenarios. Existing historical own-key and N tests remain required. These new sources do not edit any original semantic assertion, quota, harness, fixture or policy.
