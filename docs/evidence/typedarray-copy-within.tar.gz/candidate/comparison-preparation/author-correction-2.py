from pathlib import Path
import ast,difflib,hashlib,json,shutil
P=Path(__file__).resolve().parent; K=P.parent; C=K/'conformance'; retain=P/'shared-tool-lineage-correction-1'
retain.mkdir(exist_ok=False)
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
for p in [P/'compare.py',P/'test_compare.py',P/'source-ready.json',P/'layout-review.json',K/'validation/historical-comparison-1.json',K/'validation/historical-comparison-1.log']:
 shutil.copyfile(p,retain/p.name)
(retain/'retention.json').write_text(json.dumps({'originals':[bind(p) for p in [P/'compare.py',P/'test_compare.py',P/'source-ready.json',P/'layout-review.json',K/'validation/historical-comparison-1.json',K/'validation/historical-comparison-1.log']],'copies':[bind(p) for p in sorted(retain.iterdir())]},indent=2)+'\n')
addition='''

SHARED_TOOLS = ('tools/import_test262.py', 'tools/test262_conformance.py')
CONFORMANCE_HOLD_SHA256 = 'd6adc1b0f05afb55babfe5ee4ac2a90894796271c443e880969dea904d88a800'
CONFORMANCE_REVIEW_SHA256 = '71e85d1ad269750e6bcc7e6bf9cdfc04614548a145d0ab076f1c08a98ec36983'


def new_profile_literal(node):
    return isinstance(node, ast.Constant) and node.value == 'typedarray-copy-within'


def new_profile_test(node):
    return (isinstance(node, ast.Compare) and len(node.ops) == 1
            and isinstance(node.ops[0], ast.Eq)
            and isinstance(node.left, ast.Name) and node.left.id == 'profile'
            and len(node.comparators) == 1 and new_profile_literal(node.comparators[0]))


class RemoveCopyWithinRegistration(ast.NodeTransformer):
    """Only reverse the independently reviewed, byte-pinned profile additions."""
    def visit_Assign(self, node):
        if any(isinstance(target, ast.Name) and target.id in {
                'TYPEDARRAY_COPY_WITHIN_DIRECTORIES', 'TYPEDARRAY_COPY_WITHIN_HELPERS',
                'TYPEDARRAY_COPY_WITHIN_FEATURES'} for target in node.targets):
            return None
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == 'typedarray_copy_within_preflight_variants':
            return None
        return self.generic_visit(node)

    def visit_Dict(self, node):
        keep = [i for i, key in enumerate(node.keys) if not new_profile_literal(key)]
        node.keys = [node.keys[i] for i in keep]
        node.values = [node.values[i] for i in keep]
        return self.generic_visit(node)

    def visit_Set(self, node):
        node.elts = [item for item in node.elts if not new_profile_literal(item)]
        return self.generic_visit(node)

    def visit_If(self, node):
        if (new_profile_test(node.test) or
                (isinstance(node.test, ast.BoolOp) and isinstance(node.test.op, ast.And)
                 and any(new_profile_test(item) for item in node.test.values))):
            return None
        return self.generic_visit(node)

    def visit_BoolOp(self, node):
        if isinstance(node.op, ast.Or):
            node.values = [item for item in node.values if not (
                isinstance(item, ast.BoolOp) and isinstance(item.op, ast.And)
                and any(new_profile_test(term) for term in item.values))]
        node = self.generic_visit(node)
        return node.values[0] if len(node.values) == 1 else node


def verify_shared_tool_ast(before, after):
    old_ast = ast.dump(ast.parse(before), include_attributes=False)
    restored = ast.dump(RemoveCopyWithinRegistration().visit(ast.parse(after)),
                        include_attributes=False)
    assert old_ast == restored, 'shared tool old-profile AST drift'
    return sha(old_ast.encode())


def shared_tool_lineage(before_root):
    # Pin both the source hold and its independent clear review. No caller can
    # supply a new allowlist or replace the accepted hashes through selection.
    hold_path = J/'conformance/source-ready.json'
    review_path = J/'conformance/layout-source-review.json'
    hold = read(hold_path)
    review = read(review_path)
    assert sha(payload(hold_path)) == CONFORMANCE_HOLD_SHA256
    assert sha(payload(review_path)) == CONFORMANCE_REVIEW_SHA256
    assert hold['profile'] == 'typedarray-copy-within'
    assert hold['unchanged_existing_profile_policies'] == 52
    assert review['status'] == 'clear' and review['findings'] == []
    assert review['hold']['sha256'] == CONFORMANCE_HOLD_SHA256
    require_binding(review['hold'])
    lineage = {}
    for name in SHARED_TOOLS:
        rows = [row for row in hold['tool_paths'] if row['relative'] == name]
        assert len(rows) == 1, name
        new = rows[0]['held']
        old_rows = [row for row in hold['files']
                    if Path(row['path']).parts[-2:] == ('original', Path(name).name)]
        assert len(old_rows) == 1, name
        old = old_rows[0]
        require_binding(old)
        require_binding(new)
        before = payload(before_root/'worktree'/name)
        after = payload(J/'worktree'/name)
        assert before == payload(Path(old['path'])), ('before shared tool lineage', name)
        assert after == payload(Path(new['path'])), ('after shared tool lineage', name)
        restored_ast = verify_shared_tool_ast(before, after)
        lineage[name] = dict(
            before=dict(bytes=len(before), sha256=sha(before)),
            after=dict(bytes=len(after), sha256=sha(after)),
            original=old, held=new, restored_old_ast_sha256=restored_ast)
    return lineage


def compare_local_inputs(before_rows, after_rows, before_root):
    lineage = shared_tool_lineage(before_root)
    def normalized(rows, root):
        result = []
        for row in rows:
            assert set(row) == {'path', 'bytes', 'sha256'}
            result.append(dict(path=str(Path(row['path']).relative_to(root/'worktree')),
                               bytes=row['bytes'], sha256=row['sha256']))
        return result
    before = normalized(before_rows, before_root)
    after = normalized(after_rows, J)
    assert len(before) == len(after) == 15
    assert [row['path'] for row in before] == [row['path'] for row in after]
    assert len({row['path'] for row in before}) == 15
    assert set(SHARED_TOOLS) <= {row['path'] for row in before}
    for old, new in zip(before, after):
        name = old['path']
        if name in lineage:
            assert old == dict(path=name, **lineage[name]['before']), name
            assert new == dict(path=name, **lineage[name]['after']), name
        else:
            assert old == new, ('unchanged local input drift', name)
    return lineage
'''
old=(P/'compare.py').read_text();new=old.replace('import argparse\n','import argparse\nimport ast\n',1)
new=new.replace('\ndef compare(entry, before, after, before_root):',addition+'\n\ndef compare(entry, before, after, before_root):',1)
oldcheck="""        def normalized(rows, root):
            return [dict(path=str(Path(r['path']).relative_to(root/'worktree')),
                         bytes=r['bytes'], sha256=r['sha256']) for r in rows]
        assert normalized(before['inputs'], before_root) == normalized(after['inputs'], J)"""
assert new.count(oldcheck)==1
new=new.replace(oldcheck,"        compare_local_inputs(before['inputs'], after['inputs'], before_root)",1)
oldmain="""    for name in ('tools/test262_conformance.py', 'tools/import_test262.py'):
        payload(J/'worktree'/name)
        payload(before_root/'worktree'/name)"""
assert new.count(oldmain)==1
new=new.replace(oldmain,'    lineage = shared_tool_lineage(before_root)',1)
new=new.replace('after_adapter_sha256=after_adapter[\'sha256\'], summary=summary, comparisons=comparisons,','after_adapter_sha256=after_adapter[\'sha256\'], shared_tool_lineage=lineage,\n        summary=summary, comparisons=comparisons,',1)
(P/'compare-2.py').write_text(new)
(P/'compare-2.diff').write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='compare.py',tofile='compare-2.py')))
test_add='''

class SharedToolLineageProtocols(unittest.TestCase):
    def setUp(self):
        COMPARATOR.inputs.clear()
        self.before_root = Path('/tmp/eris-own-keys-one-pass-1')
        self.before = load('local-1.json')['inputs']
        self.after = copy.deepcopy(self.before)
        for row in self.after:
            relative = Path(row['path']).relative_to(self.before_root/'worktree')
            row['path'] = str(COMPARATOR.J/'worktree'/relative)
            if str(relative) in COMPARATOR.SHARED_TOOLS:
                data = Path(row['path']).read_bytes()
                row.update(bytes=len(data), sha256=COMPARATOR.sha(data))

    def check(self):
        return COMPARATOR.compare_local_inputs(self.before, self.after, self.before_root)

    def test_only_two_reviewed_tools_change_and_old_ast_is_reconstructed(self):
        lineage = self.check()
        self.assertEqual(set(lineage), set(COMPARATOR.SHARED_TOOLS))
        self.assertEqual(sum(a['sha256'] == b['sha256'] for a,b in zip(self.before,self.after)), 13)
        for name, row in lineage.items():
            self.assertNotEqual(row['before']['sha256'], row['after']['sha256'])
            self.assertEqual(len(row['restored_old_ast_sha256']), 64)
            self.assertIn('/original/', row['original']['path'])
            self.assertIn('/held/', row['held']['path'])

    def test_every_other_input_row_rejects_drift_and_order_or_population_changes(self):
        lineage = COMPARATOR.shared_tool_lineage(self.before_root)
        with mock.patch.object(COMPARATOR, 'shared_tool_lineage', return_value=lineage):
            for index,row in enumerate(self.after):
                if Path(row['path']).name in {'import_test262.py','test262_conformance.py'}:
                    continue
                changed = copy.deepcopy(self.after)
                changed[index]['sha256'] = '0'*64
                with self.subTest(path=row['path']), self.assertRaises(AssertionError):
                    COMPARATOR.compare_local_inputs(self.before, changed, self.before_root)
            for changed in [list(reversed(self.after)), self.after[:-1], self.after+[self.after[0]]]:
                with self.assertRaises(AssertionError):
                    COMPARATOR.compare_local_inputs(self.before, changed, self.before_root)

    def test_shared_tool_report_rows_cannot_substitute_unreviewed_hashes(self):
        lineage = COMPARATOR.shared_tool_lineage(self.before_root)
        with mock.patch.object(COMPARATOR, 'shared_tool_lineage', return_value=lineage):
            for side in ['before','after']:
                before,after = copy.deepcopy(self.before),copy.deepcopy(self.after)
                rows = before if side == 'before' else after
                for row in rows:
                    if Path(row['path']).name == 'import_test262.py':
                        row['sha256'] = '0'*64
                with self.subTest(side=side), self.assertRaises(AssertionError):
                    COMPARATOR.compare_local_inputs(before, after, self.before_root)

    def test_altered_shared_tool_bytes_fail_even_when_old_ast_would_match(self):
        original_payload = COMPARATOR.payload
        for root in [self.before_root,COMPARATOR.J]:
            for name in COMPARATOR.SHARED_TOOLS:
                target = root/'worktree'/name
                def changed(path):
                    data = original_payload(path)
                    return data+b'\\n' if path == target else data
                COMPARATOR.inputs.clear()
                with mock.patch.object(COMPARATOR,'payload',side_effect=changed):
                    with self.subTest(path=target), self.assertRaises(AssertionError):
                        COMPARATOR.shared_tool_lineage(self.before_root)

    def test_bad_hold_or_review_lineage_is_rejected(self):
        original_payload = COMPARATOR.payload
        for basename in ['source-ready.json','layout-source-review.json']:
            target = COMPARATOR.J/'conformance'/basename
            def changed(path):
                data = original_payload(path)
                if path != target:
                    return data
                document = json.loads(data)
                if basename == 'source-ready.json':
                    document['tool_paths'][0]['held']['sha256'] = '0'*64
                else:
                    document['hold']['sha256'] = '0'*64
                return json.dumps(document).encode()
            COMPARATOR.inputs.clear()
            with mock.patch.object(COMPARATOR,'payload',side_effect=changed):
                with self.subTest(file=basename), self.assertRaises(AssertionError):
                    COMPARATOR.shared_tool_lineage(self.before_root)

    def test_ast_reversal_rejects_unrelated_code_changes(self):
        for name in COMPARATOR.SHARED_TOOLS:
            before = (self.before_root/'worktree'/name).read_bytes()
            after = (COMPARATOR.J/'worktree'/name).read_bytes()
            COMPARATOR.verify_shared_tool_ast(before,after)
            with self.subTest(name=name), self.assertRaises(AssertionError):
                COMPARATOR.verify_shared_tool_ast(before,after+b'\\ndef unrelated_change():\\n    return 1\\n')
'''
test=(P/'test_compare.py').read_text();newtest=test.replace('import unittest\n','import unittest\nfrom unittest import mock\n',1).replace("ROOT/'compare.py'","ROOT/'compare-2.py'",1)
newtest=newtest.replace("\n\nif __name__ == '__main__':",test_add+"\n\nif __name__ == '__main__':",1)
(P/'test_compare-2.py').write_text(newtest)
(P/'test_compare-2.diff').write_text(''.join(difflib.unified_diff(test.splitlines(True),newtest.splitlines(True),fromfile='test_compare.py',tofile='test_compare-2.py')))
ast.parse(new); ast.parse(newtest)
a=ast.parse(test);b=ast.parse(newtest)
afunc={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(a) if isinstance(n,ast.FunctionDef)}
bfunc={n.name:ast.dump(n,include_attributes=False) for n in ast.walk(b) if isinstance(n,ast.FunctionDef) and n.name.startswith('test_')}
assert all(bfunc[n]==body for n,body in afunc.items() if n.startswith('test_'))
print('authored',len(bfunc),'test groups; source parse only, no import/execution')
