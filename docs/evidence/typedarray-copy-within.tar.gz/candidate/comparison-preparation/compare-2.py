"""Data-only preservation comparison for the copyWithin checkpoint.

Root supplies completed candidate records in a separate selection JSON. This
script does not import a project module or execute an engine or test runner.
Clear means the comparison invariants hold, not that every profile is healthy.
"""
import argparse
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path

PREPARATION = Path(__file__).resolve().parent
J = PREPARATION.parent
IDENTITY = ('id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative')
POLICY = ('suite', 'full_test262_conformance', 'repository', 'revision',
          'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256',
          'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases')
BAD_RUN = {'adapter-error', 'timeout', 'resource', 'runner-error'}
STATUSES = {'passed', 'failed', 'unsupported', 'harness-error'} | BAD_RUN
INTRINSIC_ERRORS = {'Error', 'TypeError', 'RangeError', 'SyntaxError', 'ReferenceError', 'EvalError', 'URIError'}
INTRINSIC_ERROR_PROFILES = {'typedarray-to-reversed', 'typedarray-reverse',
    'typedarray-fill', 'typedarray-search', 'typedarray-views',
    'typedarray-foundation', 'reflect-properties'}
inputs = {}
errors = []
review_findings = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def row_hash(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':')).encode())


def payload(path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    entry = dict(path=str(path), bytes=len(data), sha256=sha(data))
    assert inputs.setdefault(str(path), entry) == entry, ('input changed', path)
    return data


def read(path):
    return json.loads(payload(path))


def beneath(root, relative):
    assert isinstance(relative, str) and relative, relative
    path = Path(relative)
    assert not path.is_absolute() and '..' not in path.parts, relative
    return root / path


def require_binding(row):
    data = payload(Path(row['path']))
    assert len(data) == row['bytes'] and sha(data) == row['sha256'], row['path']


def adapter(root, record):
    value = read(beneath(root, record))
    data = payload(beneath(root, value['binary']))
    assert len(data) == value['bytes'] and sha(data) == value['sha256']
    source_path = beneath(root, value['source_binding'])
    source = read(source_path)
    assert inputs[str(source_path)]['sha256'] == value['source_binding_sha256']
    for name, digest in source['source_sha256'].items():
        assert sha(payload(beneath(root/'worktree', name))) == digest, name
    for key in ('build', 'full_suite'):
        receipt = read(beneath(root, value[key]))
        log = payload(beneath(root/'validation', receipt['log']))
        assert receipt['exit'] == 0 and sha(log) == receipt['sha256'], (record, key)
    return value, source


def validate_observation(row):
    observed = row.get('observation')
    if observed is None:
        assert row['status'] in {'unsupported', 'adapter-error', 'timeout', 'runner-error'}
        assert isinstance(row['reason'], str) and row['reason']
        return
    assert set(observed) == {'status', 'phase', 'error_type', 'error_identity', 'message', 'harness'}
    assert all(isinstance(v, str) for v in observed.values())
    status, phase = observed['status'], observed['phase']
    assert status in {'complete', 'exception', 'unsupported', 'resource', 'harness-error'}
    assert phase in {'parse', 'runtime', 'harness', 'mode'}
    assert observed['error_identity'] == '' or observed['error_identity'] in INTRINSIC_ERRORS
    if status == 'complete':
        assert phase in {'parse', 'runtime'}
        assert not any(observed[k] for k in ('error_type', 'error_identity', 'harness'))
    if status == 'exception':
        assert phase in {'parse', 'runtime'} and observed['error_type'] and not observed['harness']
    if status == 'harness-error':
        assert phase == 'harness' and observed['harness']
    negative = row['expected_negative']
    if status in {'unsupported', 'resource', 'harness-error'}:
        classified = status
    elif negative is None:
        classified = 'passed' if status == 'complete' and phase == 'runtime' else 'failed'
    else:
        classified = ('passed' if status == 'exception' and phase == negative['phase']
                      and observed['error_identity'] == negative['type'] else 'failed')
    assert row['status'] == classified, row['id']


def local_matches(row):
    expected = row['expected_observation']
    status = 'passed' if expected['status'] == 'complete' else 'failed'
    observed = row.get('observation')
    return (row['status'] == status and isinstance(observed, dict)
            and all(observed.get(k) == v for k, v in expected.items()))


def control_identity(row, local):
    if local:
        return {k: v for k, v in row.items() if k not in {
            'status', 'observation', 'reason', 'matches_expectation',
            'positive_partner_matches', 'verified'}}
    result = {k: v for k, v in row.items() if k not in {'result', 'verified', 'prerequisite'}}
    result['result'] = {k: row['result'][k] for k in IDENTITY}
    if 'prerequisite' in row:
        p = {k: v for k, v in row['prerequisite'].items() if k not in {'verified', 'result'}}
        if 'result' in row['prerequisite']:
            p['result'] = {k: row['prerequisite']['result'][k] for k in IDENTITY}
        result['prerequisite'] = p
    return result


def controls_health(report, profile, local):
    controls = report['controls' if local else 'harness_preflight']
    if local:
        lookup = {r['id']: r for r in controls}
        assert len(lookup) == len(controls)
        for row in controls:
            validate_observation(row)
            matches = local_matches(row)
            partner = lookup[row['partner']]
            assert partner['mode'] == row['mode'] and partner['positive'] is True
            partner_matches = local_matches(partner)
            assert row['matches_expectation'] == matches
            assert row['positive_partner_matches'] == partner_matches
            assert row['verified'] == (matches and partner_matches)
        return all(r['verified'] for r in controls)
    lookup = {(r['name'], r['result']['mode']): r for r in controls}
    assert len(lookup) == len(controls)
    for row in controls:
        expected, result = row['expected'], row['result']
        validate_observation(result)
        assert expected in {'passed', 'failed', 'unsupported'}
        assert result['mode'] in {'sloppy', 'strict'}
        correct = result['status'] == expected
        if expected == 'failed':
            observed = result.get('observation', {})
            if profile in INTRINSIC_ERROR_PROFILES and row['name'].startswith(profile+'-'):
                correct = correct and all(observed.get(k) == v for k, v in dict(
                    status='exception', phase='runtime', error_type='Error', error_identity='Error').items())
            else:
                correct = correct and observed.get('error_type') == 'Test262Error'
        if 'prerequisite' in row:
            prerequisite = row['prerequisite']
            partner = lookup[(prerequisite['name'], prerequisite['mode'])]
            assert partner['result']['mode'] == result['mode']
            assert partner['expected'] == prerequisite['expected'] == 'passed'
            assert prerequisite['verified'] == partner['verified']
            for key in ('case_sha256', 'source_sha256'):
                assert prerequisite[key] == partner['result'][key]
            if 'result' in prerequisite:
                assert prerequisite['result'] == partner['result']
            correct = correct and partner['verified']
        assert row['verified'] == correct, (profile, row['name'], result['mode'])
    return all(r['verified'] for r in controls)


def health(report, profile, local, root):
    cases = report['cases']
    assert len({r['id'] for r in cases}) == len(cases)
    assert all(r['mode'] in {'sloppy', 'strict', 'module'} for r in cases)
    for row in cases:
        validate_observation(row)
    counts = dict(Counter(r['status'] for r in cases))
    assert set(counts) <= STATUSES
    preflight = controls_health(report, profile, local)
    controls = report['controls' if local else 'harness_preflight']
    if local:
        assert report['binding_failures'] == []
        assert report['observed_after'] == report['inputs'] + [dict(
            path=report['binary'], bytes=report['binary_bytes'], sha256=report['binary_sha256'])]
        for row in report['observed_after']:
            require_binding(row)
        assert all(r['matches_expectation'] == local_matches(r) for r in cases)
        expected_summary = dict(case_matches=sum(local_matches(r) for r in cases),
            case_total=len(cases), control_matches=sum(local_matches(r) for r in controls),
            controls_verified=sum(r['verified'] for r in controls), control_total=len(controls),
            runner_errors=sum(r['status'] == 'runner-error' for r in cases + controls))
        assert report['summary'] == expected_summary
        healthy = preflight and all(local_matches(r) for r in cases)
    else:
        assert report['counts'] == counts and report['mode_cases'] == len(cases)
        assert report['runner_policy_sha256'] == sha(json.dumps(report['runner_policy'], sort_keys=True).encode())
        assert report['harness_preflight_passed'] == preflight
        healthy = preflight and not any(counts.get(s) for s in BAD_RUN)
    return dict(counts=counts, controls=len(controls),
        controls_verified=sum(r['verified'] for r in controls),
        preflight_healthy=preflight, report_healthy=healthy)


def receipt_check(root, path, report_name, report, binary, profile, local, historical, baseline=None):
    receipt = read(beneath(root, path))
    h = health(report, profile, local, root)
    if historical:
        output = beneath(root, report_name)
        command = ['python3', str(root/'worktree/tools/test262_conformance.py'),
            '--binary', str(binary), '--profile', profile, '--baseline', str(baseline),
            '--output', str(output), '--jobs', '2']
        assert receipt['binary_sha256'] == report['binary_sha256']
        assert receipt['report_sha256'] == sha(payload(output))
        assert receipt['log_sha256'] == sha(payload(output.with_suffix('.log')))
        for key in ('counts', 'mode_cases', 'harness_preflight_passed'):
            assert receipt[key] == report[key]
        for key in ('regressions', 'improvements'):
            assert receipt[key] == len(report[key])
        expected_exit = int(not h['report_healthy'] or bool(report['regressions']))
    else:
        log = payload(beneath(root/'validation', receipt['log']))
        assert sha(log) == receipt['sha256']
        if local:
            command = ['python3', 'tools/typedarray_views_local.py', '--engine', str(binary),
                '--engine-sha256', report['binary_sha256'], '--output', str(root/report_name)]
            expected_exit = 3 if report['summary']['runner_errors'] else int(not h['report_healthy'])
        else:
            command = ['python3', 'tools/test262_conformance.py', '--profile', profile,
                '--binary', str(binary), '--output', str(root/report_name), '--jobs', '2']
            expected_exit = int(not h['report_healthy'] or bool(report['regressions']) or
                                report['counts'].get('passed', 0) != report['mode_cases'])
    assert receipt['command'] == command, (path, receipt['command'])
    assert receipt['exit'] == expected_exit, (path, receipt['exit'], expected_exit)
    return dict(path=str(root/path), exit=receipt['exit'], sha256=sha(payload(root/path)))


def baseline_check(report, baseline):
    for key in ('revision', 'corpus_manifest_sha256', 'runner_policy_sha256'):
        assert baseline[key] == report[key]
    current = {r['id']: r for r in report['cases']}
    assert baseline['cases'].keys() == current.keys()
    regressions, improvements = [], []
    for name, old in baseline['cases'].items():
        new = current[name]
        assert old['case_sha256'] == new['case_sha256']
        if old['status'] == 'passed' and new['status'] != 'passed':
            regressions.append(name)
        if old['status'] != 'passed' and new['status'] == 'passed':
            improvements.append(name)
    assert report['regressions'] == regressions and report['improvements'] == improvements



SHARED_TOOLS = ('tools/import_test262.py', 'tools/test262_conformance.py')
CONFORMANCE_HOLD_SHA256 = 'd6adc1b0f05afb55babfe5ee4ac2a90894796271c443e880969dea904d88a800'
CONFORMANCE_REVIEW_SHA256 = '71e85d1ad269750e6bcc7e6bf9cdfc04614548a145d0ab076f1c08a98ec36983'


def new_profile_literal(node):
    return isinstance(node, ast.Constant) and node.value == 'typedarray-copy-within'


def new_profile_test(node):
    return (isinstance(node, ast.Compare) and len(node.ops) == 1
            and isinstance(node.ops[0], ast.Eq)
            and isinstance(node.left, ast.Name) and node.left.id == 'profile'
            and len(node.comparators) == 1 and new_profile_literal(node.comparators[0]))


class RemoveCopyWithinRegistration(ast.NodeTransformer):
    """Only reverse the independently reviewed, byte-pinned profile additions."""
    def visit_Assign(self, node):
        if any(isinstance(target, ast.Name) and target.id in {
                'TYPEDARRAY_COPY_WITHIN_DIRECTORIES', 'TYPEDARRAY_COPY_WITHIN_HELPERS',
                'TYPEDARRAY_COPY_WITHIN_FEATURES'} for target in node.targets):
            return None
        return self.generic_visit(node)

    def visit_FunctionDef(self, node):
        if node.name == 'typedarray_copy_within_preflight_variants':
            return None
        return self.generic_visit(node)

    def visit_Dict(self, node):
        keep = [i for i, key in enumerate(node.keys) if not new_profile_literal(key)]
        node.keys = [node.keys[i] for i in keep]
        node.values = [node.values[i] for i in keep]
        return self.generic_visit(node)

    def visit_Set(self, node):
        node.elts = [item for item in node.elts if not new_profile_literal(item)]
        return self.generic_visit(node)

    def visit_If(self, node):
        if (new_profile_test(node.test) or
                (isinstance(node.test, ast.BoolOp) and isinstance(node.test.op, ast.And)
                 and any(new_profile_test(item) for item in node.test.values))):
            return None
        return self.generic_visit(node)

    def visit_BoolOp(self, node):
        if isinstance(node.op, ast.Or):
            node.values = [item for item in node.values if not (
                isinstance(item, ast.BoolOp) and isinstance(item.op, ast.And)
                and any(new_profile_test(term) for term in item.values))]
        node = self.generic_visit(node)
        return node.values[0] if len(node.values) == 1 else node


def verify_shared_tool_ast(before, after):
    old_ast = ast.dump(ast.parse(before), include_attributes=False)
    restored = ast.dump(RemoveCopyWithinRegistration().visit(ast.parse(after)),
                        include_attributes=False)
    assert old_ast == restored, 'shared tool old-profile AST drift'
    return sha(old_ast.encode())


def shared_tool_lineage(before_root):
    # Pin both the source hold and its independent clear review. No caller can
    # supply a new allowlist or replace the accepted hashes through selection.
    hold_path = J/'conformance/source-ready.json'
    review_path = J/'conformance/layout-source-review.json'
    hold = read(hold_path)
    review = read(review_path)
    assert sha(payload(hold_path)) == CONFORMANCE_HOLD_SHA256
    assert sha(payload(review_path)) == CONFORMANCE_REVIEW_SHA256
    assert hold['profile'] == 'typedarray-copy-within'
    assert hold['unchanged_existing_profile_policies'] == 52
    assert review['status'] == 'clear' and review['findings'] == []
    assert review['hold']['sha256'] == CONFORMANCE_HOLD_SHA256
    require_binding(review['hold'])
    lineage = {}
    for name in SHARED_TOOLS:
        rows = [row for row in hold['tool_paths'] if row['relative'] == name]
        assert len(rows) == 1, name
        new = rows[0]['held']
        old_rows = [row for row in hold['files']
                    if Path(row['path']).parts[-2:] == ('original', Path(name).name)]
        assert len(old_rows) == 1, name
        old = old_rows[0]
        require_binding(old)
        require_binding(new)
        before = payload(before_root/'worktree'/name)
        after = payload(J/'worktree'/name)
        assert before == payload(Path(old['path'])), ('before shared tool lineage', name)
        assert after == payload(Path(new['path'])), ('after shared tool lineage', name)
        restored_ast = verify_shared_tool_ast(before, after)
        lineage[name] = dict(
            before=dict(bytes=len(before), sha256=sha(before)),
            after=dict(bytes=len(after), sha256=sha(after)),
            original=old, held=new, restored_old_ast_sha256=restored_ast)
    return lineage


def compare_local_inputs(before_rows, after_rows, before_root):
    lineage = shared_tool_lineage(before_root)
    def normalized(rows, root):
        result = []
        for row in rows:
            assert set(row) == {'path', 'bytes', 'sha256'}
            result.append(dict(path=str(Path(row['path']).relative_to(root/'worktree')),
                               bytes=row['bytes'], sha256=row['sha256']))
        return result
    before = normalized(before_rows, before_root)
    after = normalized(after_rows, J)
    assert len(before) == len(after) == 15
    assert [row['path'] for row in before] == [row['path'] for row in after]
    assert len({row['path'] for row in before}) == 15
    assert set(SHARED_TOOLS) <= {row['path'] for row in before}
    for old, new in zip(before, after):
        name = old['path']
        if name in lineage:
            assert old == dict(path=name, **lineage[name]['before']), name
            assert new == dict(path=name, **lineage[name]['after']), name
        else:
            assert old == new, ('unchanged local input drift', name)
    return lineage


def compare(entry, before, after, before_root):
    name, local, profile = entry['name'], entry['local'], entry['profile']
    for key in ('matrix_sha256', 'schema', 'scope') if local else POLICY:
        if before[key] != after[key]:
            errors.append([name, 'policy or population drift', key])
    if local:
        compare_local_inputs(before['inputs'], after['inputs'], before_root)
    bhealth = health(before, profile, local, before_root)
    ahealth = health(after, profile, local, J)
    assert bhealth['preflight_healthy'], name
    if not ahealth['preflight_healthy']:
        errors.append([name, 'candidate controls unhealthy'])
    bcases, acases = before['cases'], after['cases']
    assert [r['id'] for r in bcases] == [r['id'] for r in acases], name
    changes, losses, newly_passing, resource_advances, resource_entries = [], [], [], [], []
    engine_unsupported_changes = []
    transitions = Counter()
    for b, a in zip(bcases, acases):
        for key in IDENTITY + (('kind', 'expected_observation') if local else ()):
            if b[key] != a[key]:
                errors.append([name, b['id'], 'case identity drift', key])
        # Policy exclusions never reached the engine. They must remain exact.
        b_excluded = b['status'] == 'unsupported' and b.get('observation') is None
        a_excluded = a['status'] == 'unsupported' and a.get('observation') is None
        if (b_excluded or a_excluded) and b != a:
            errors.append([name, b['id'], 'policy-excluded row changed'])
        # An engine can reach a later unsupported operation after using less
        # work. Retain that as a review finding, not a policy change or a pass.
        b_engine_unsupported = b['status'] == 'unsupported' and isinstance(b.get('observation'), dict)
        a_engine_unsupported = a['status'] == 'unsupported' and isinstance(a.get('observation'), dict)
        if b != a and (b_engine_unsupported or a_engine_unsupported):
            engine_unsupported_changes.append(a['id'])
            review_findings.append([name, a['id'], 'engine unsupported observation changed'])
        transitions[b['status']+' -> '+a['status']] += 1
        if b['status'] == 'passed' and a['status'] != 'passed':
            losses.append(a['id'])
        if b['status'] != 'passed' and a['status'] == 'passed':
            newly_passing.append(a['id'])
        if b['status'] == 'resource' and a['status'] == 'failed':
            resource_advances.append(a['id'])
        if b['status'] != 'resource' and a['status'] == 'resource':
            resource_entries.append(a['id'])
        if a['status'] in {'adapter-error', 'timeout', 'runner-error', 'harness-error'}:
            errors.append([name, a['id'], 'candidate infrastructure error', a['status']])
        if b != a:
            changes.append(dict(id=a['id'], before=b, after=a,
                changed_fields=sorted(k for k in set(a)|set(b) if k not in a or k not in b or a[k] != b[k]),
                before_sha256=row_hash(b), after_sha256=row_hash(a)))
    if losses:
        errors.append([name, 'prior-pass losses', losses])
    key = 'controls' if local else 'harness_preflight'
    bc, ac = before[key], after[key]
    assert len(bc) == len(ac)
    for b, a in zip(bc, ac):
        if control_identity(b, local) != control_identity(a, local):
            errors.append([name, 'control identity/oracle drift', control_identity(b, local)])
    return dict(report=name, before_counts=bhealth['counts'], after_counts=ahealth['counts'],
        before_health=bhealth, after_health=ahealth, case_rows=len(acases),
        exact_case_rows=len(acases)-len(changes), control_rows=len(ac),
        exact_control_rows=sum(b == a for b, a in zip(bc, ac)),
        before_rows_sha256=row_hash(bcases), after_rows_sha256=row_hash(acases),
        before_controls_sha256=row_hash(bc), after_controls_sha256=row_hash(ac),
        transitions=dict(sorted(transitions.items())), prior_pass_losses=losses,
        newly_passing=newly_passing, resource_to_failed=resource_advances,
        new_resource_stops=resource_entries, engine_unsupported_changes=engine_unsupported_changes,
        changed_rows=changes,
        changed_controls=[dict(before=b, after=a) for b, a in zip(bc, ac) if b != a])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--selection', type=Path, required=True)
    args = parser.parse_args()
    selection = read(args.selection.resolve())
    snapshot = read(PREPARATION/'before-index.json')
    before_root = Path(snapshot['before_root'])
    for held in snapshot['files']:
        require_binding(held['original'])
        require_binding(held['copy'])
        assert held['original']['sha256'] == held['copy']['sha256']
    before_adapter, _ = adapter(before_root, snapshot['adapter_record'])
    after_adapter, after_source = adapter(J, selection['candidate_adapter_record'])
    assert before_adapter['sha256'] == snapshot['adapter_sha256']
    assert after_source['base'] == snapshot['before_commit']
    assert read(J/'parent-checkpoint.json')['base'] == snapshot['before_commit']
    assert read(J/'regression-plan.json')['profiles'] == read(before_root/'regression-plan.json')['profiles']
    # A new profile is registered separately. Existing reports must retain
    # their exact per-profile policies, complete populations, assembled source
    # hashes and control identities, as checked by compare() below.
    # The local runner remains byte-identical. Record both general tools.
    name = 'tools/typedarray_views_local.py'
    assert payload(J/'worktree'/name) == payload(before_root/'worktree'/name), name
    lineage = shared_tool_lineage(before_root)
    profiles = snapshot['profiles']
    assert set(selection['top_receipts']) == {p['name'] for p in profiles if not p['historical']}
    history = beneath(J, selection['historical_directory'])
    comparisons = []
    for entry in profiles:
        historical = entry['historical']
        before_name = entry['before']
        after_name = str((history/entry['after_basename']).relative_to(J)) if historical else entry['after']
        before, after = read(before_root/before_name), read(J/after_name)
        assert before['binary_sha256'] == before_adapter['sha256']
        assert after['binary_sha256'] == after_adapter['sha256']
        result = compare(entry, before, after, before_root)
        result.update(before_report=str(before_root/before_name), after_report=str(J/after_name))
        for root, value, record, report_name, receipt_path in [
            (before_root, before_adapter, before, before_name, entry['before_receipt']),
            (J, after_adapter, after, after_name,
             str((history/(entry['profile']+'-receipt.json')).relative_to(J)) if historical
             else selection['top_receipts'][entry['name']])]:
            baseline = None
            if historical:
                baseline = beneath(root/'worktree', entry['baseline'])
                assert sha(payload(baseline)) == entry['baseline_sha256']
                baseline_check(record, read(baseline))
            else:
                if not entry['local']:
                    assert record['regressions'] == record['improvements'] == []
            receipt = receipt_check(root, receipt_path, report_name, record,
                root/value['binary'], entry['profile'], entry['local'], historical, baseline)
            result['before_receipt' if root == before_root else 'after_receipt'] = receipt
            if historical and receipt['exit'] != 0:
                errors.append([entry['name'], 'historical gate failed', receipt])
        comparisons.append(result)
    summary = dict(profiles=len(comparisons), historical_profiles=sum(p['historical'] for p in profiles),
        case_rows=sum(r['case_rows'] for r in comparisons),
        exact_case_rows=sum(r['exact_case_rows'] for r in comparisons),
        control_rows=sum(r['control_rows'] for r in comparisons),
        exact_control_rows=sum(r['exact_control_rows'] for r in comparisons),
        changed_case_rows=sum(len(r['changed_rows']) for r in comparisons),
        changed_control_rows=sum(len(r['changed_controls']) for r in comparisons),
        prior_pass_losses=sum(len(r['prior_pass_losses']) for r in comparisons),
        newly_passing=sum(len(r['newly_passing']) for r in comparisons),
        resource_to_failed=sum(len(r['resource_to_failed']) for r in comparisons),
        new_resource_stops=sum(len(r['new_resource_stops']) for r in comparisons),
        engine_unsupported_changes=sum(len(r['engine_unsupported_changes']) for r in comparisons))
    assert (summary['profiles'], summary['historical_profiles'], summary['case_rows'], summary['control_rows']) == (45, 38, 18298, 4284)
    for row in list(inputs.values()):
        require_binding(row)
    result = dict(status='findings' if errors or review_findings else 'clear',
        errors=errors, review_findings=review_findings,
        scope='Complete observations retained; clear means stable identity/policy/control health and no prior-pass losses. Changed engine unsupported observations require review; resource reports may remain unhealthy.',
        before_commit=snapshot['before_commit'], before_adapter_sha256=before_adapter['sha256'],
        after_adapter_sha256=after_adapter['sha256'], shared_tool_lineage=lineage,
        summary=summary, comparisons=comparisons,
        inputs=list(inputs.values()))
    output_path = beneath(J, selection['output'])
    with output_path.open('x') as output:
        json.dump(result, output, indent=2, sort_keys=True)
        output.write('\n')
    print(json.dumps(dict(status=result['status'], summary=summary, errors=errors,
                          review_findings=review_findings)))
    return int(bool(errors or review_findings))


if __name__ == '__main__':
    raise SystemExit(main())
