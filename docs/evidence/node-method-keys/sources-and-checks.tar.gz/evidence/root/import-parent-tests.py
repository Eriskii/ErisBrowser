import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-before-1'
def sha(data):return hashlib.sha256(data).hexdigest()
def checked(row):
 data=Path(row['path']).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],row['path'];return data
hold=(H/'parent-ready.json').read_bytes();assert sha(hold)=='e783a2b2eb4c2e48b3b6f23972e8980dc09c20ed1e1f846b4d02a207a8e009c2'
peer=json.loads((H/'html-parent-review.json').read_text());assert 'clear' in peer['status']
m=json.loads(hold)
for key in ['parent_source','new_test','before','registration','patch']:checked(m[key])
s=json.loads((A/'parent-source.json').read_text())
for relative,h in s['source_sha256'].items():assert sha((W/relative).read_bytes())==h,relative
assert (W/'src/script/node_data.rs').read_bytes()==checked(m['before'])
newpath=W/'src/script/node_data/method_key_tests.rs';assert not newpath.exists()
newpath.write_bytes(checked(m['new_test']));(W/'src/script/node_data.rs').write_bytes(checked(m['registration']))
for path in [newpath,W/'src/script/node_data.rs']:s['source_sha256'][str(path.relative_to(W))]=sha(path.read_bytes())
s['scope']='Parent-compatible nine-Node metadata/public controls only; no production changes.'
(A/'source-parent-tests.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/parent-test-import.json').write_text(json.dumps({'hold_sha256':sha(hold),'peer_sha256':sha((H/'html-parent-review.json').read_bytes()),'source_inputs':len(s['source_sha256'])},indent=2)+'\n')
print('Imported parent-compatible2groups; no production changes')
