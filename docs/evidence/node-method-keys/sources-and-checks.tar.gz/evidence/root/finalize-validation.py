import hashlib
import json
import re
from collections import Counter
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
def read(p):
    return json.loads(p.read_bytes())
def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

inventory = read(A/'source1.json')
assert len(inventory['source_sha256']) == 1223
for relative, digest in inventory['source_sha256'].items():
    assert bind(W/relative)['sha256'] == digest, relative
source_review = read(A/'root/final-source-review.json')
assert source_review['status'] == 'clear'
assert source_review['final_source'] == bind(A/'source1.json')
oracle = read(A/'tests-before-1/oracles.json')
ledger = read(A/'tests-before-1/ledger.json')
roster = oracle['parent_groups'] + oracle['private_groups']
assert len(roster) == len(set(roster)) == 8
attempts = ledger['factory_endpoint_attempts'] + len(ledger['longest_work_prefixes']) + len(ledger['longest_heap_prefixes']) + ledger['handoff']['entry_attempts'] + ledger['installer_endpoints']['attempts'] + ledger['owner_capacity']['attempts']
assert attempts == ledger['private_literal_attempts'] == 102
assert sum(len(r['modes']) for r in oracle['public_rows']) == 18
checks = {}
for path in sorted((A/'validation').glob('*.json')):
    receipt = read(path)
    log = A/'validation'/receipt['log']
    assert bind(log)['sha256'] == receipt['sha256'], path
    expected = 101 if path.stem.startswith('parent-controls') else 0
    assert receipt['exit'] == expected, (path,receipt['exit'])
    checks[path.stem] = {'receipt':bind(path),'log':bind(log),'exit':receipt['exit']}

pattern = r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;'
def results(name):
    text = (A/'validation'/f'{name}.log').read_text()
    return text, [(status, *map(int, counts)) for status,*counts in re.findall(pattern,text,re.M)]
for name,total in [('default-full-1',2953),('host-vulkan-full-1',3307)]:
    text, rows = results(name)
    assert len(rows) == 49 and sum(r[1] for r in rows) == total
    assert all(r[0]=='ok' and r[2:]==(0,0,0,0) for r in rows)
    assert len(re.findall(r'^test .+ \.\.\. ok$',text,re.M)) == total
    checks[name].update(passed=total,result_rows=49,failed=0,ignored=0,filtered=0)
text,rows=results('focused-method-keys-1')
assert len(rows)==1 and rows[0][1:5]==(8,0,0,0)
observed = re.findall(r'^test \S+::(\w+) \.\.\. ok$',text,re.M)
assert set(observed)==set(roster) and len(observed)==8
checks['focused-method-keys-1'].update(passed=8,roster=roster,private_attempts=102,public_rows=18)
for name in ['parent-controls-1','parent-controls-corrected-1']:
    _, rows = results(name)
    assert len(rows)==1 and rows[0][0:5]==('FAILED',1,1,0,0)
assert read(A/'root/parent-baseline-2.json')['status']=='intended_parent_delta_observed'
diagnostic=(A/'validation/startup-diagnostic-1.log').read_text()
assert 'TYPED_ARRAY_BOOTSTRAP remaining=275 allocated=1740043 objects=750 capacity=750 native=299 prototypes=25 globals=212' in diagnostic
binary = read(A/'binary.json')
assert bind(Path(binary['path'])) == {k:binary[k] for k in ('path','bytes','sha256')}
assert binary['source_inventory']==str(A/'source1.json')
assert binary['build_receipt']==str(A/'validation/host-release-1.json')
reports = {}
for name,baseline,total,guards,counts in [
    ('promise-all-report.json','test262-promise-all-current.json',196,90,{'passed':170,'failed':18,'unsupported':8}),
    ('promise-existing-report.json','test262-promise-methods-async-current.json',458,74,{'passed':420,'failed':8,'unsupported':30}),
]:
    report=read(A/name)
    base=read(W/'tests/conformance'/baseline)
    assert report['counts']==counts==dict(Counter(c['status'] for c in report['cases']))
    assert len(report['cases'])==report['mode_cases']==total
    assert len({c['id'] for c in report['cases']})==total
    assert base['cases']=={c['id']:{k:c[k] for k in ('status','case_sha256','source_sha256')} for c in report['cases']}
    assert report['binary_sha256']==binary['sha256']
    assert report['harness_preflight_passed'] and len(report['harness_preflight'])==guards
    assert all(c['verified'] for c in report['harness_preflight'])
    assert not report['regressions'] and not report['improvements']
    old=read(Path('/tmp/eris-promise-all-test262-1')/name)
    assert {k:v for k,v in report.items() if k not in ('seconds','binary','binary_sha256')}=={k:v for k,v in old.items() if k not in ('seconds','binary','binary_sha256')}
    reports[name]={'report':bind(A/name),'baseline':bind(W/'tests/conformance'/baseline),'counts':counts,'mode_cases':total,'verified_controls':guards,'all_observation_and_identity_records_exact_parent':True,'regressions':0,'improvements':0}

out={'status':'pass','base':inventory['base'],'source_inventory':bind(A/'source1.json'),'source_inputs':1223,'composition_peer':bind(A/'root/final-source-review.json'),'test_hold':bind(A/'tests-before-1/source-ready.json'),'production_hold':bind(A/'production-1/source-ready.json'),'checks':checks,'startup':{'raw_work':99725,'remaining_work':275,'accounted_heap':1740043,'objects':750,'object_capacity':750,'native_registry':299,'prototypes':25,'globals':212,'saved_work':250,'saved_accounted_heap':1512},'binary':binary,'replays':reports,'parent_controls':{'original_defect':bind(A/'root/parent-baseline-1.json'),'corrected_observation':bind(A/'root/parent-baseline-2.json'),'interpretation':'Original order assertion defect retained. Corrected parent fails first isConnected length pointer only after all nine bags pass; public18 rows pass. Final eight groups pass.'},'limitations':['Abstract startup accounting, not wall-clock/RSS improvement.','No new full Python suite, GPU device run or Chromium comparison in this checkpoint.','Selected conformance profiles retain known failures and unsupported cases. No full web compatibility or production-security claim.']}
(A/'root/final-validation.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'pass','source_inputs':1223,'default':2953,'host_vulkan':3307,'private_attempts':attempts}))
