import hashlib,json
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-before-1';P=A/'production-1'
def sha(b):return hashlib.sha256(b).hexdigest()
def checked(r):
 b=Path(r['path']).read_bytes();assert len(b)==r['bytes'] and sha(b)==r['sha256'],r['path'];return b
h=(H/'source-ready.json').read_bytes();assert sha(h)=='71ca18feb3068a9da8bdde9137121b2d6899013d3c026387a4a170444279f908';tests=json.loads(h)
p=(P/'source-ready.json').read_bytes();assert sha(p)=='4b66eb6b12c215b5d93892f71862e41f3044fccdcf2d250d3039a2843feb8192';production=json.loads(p)
for path in [H/'html-review.json',P/'script-review.json']:assert 'clear' in json.loads(path.read_text())['status'],path
for row in tests['artifacts']:checked(row)
for key in ['plan','controls','parent_inventory']:checked(production[key])
s=json.loads((A/'source-parent-tests-2.json').read_text())
for r,v in s['source_sha256'].items():assert sha((W/r).read_bytes())==v,r
assert (W/'src/script/node_data/method_key_tests.rs').read_bytes()==checked(tests['selected_public_test'])
updates={}
def current(relative):return updates[relative] if relative in updates else (W/relative).read_bytes()
assert current('src/script/node_data.rs')==checked(tests['registrations']['parent'])
updates['src/script/node_data.rs']=checked(tests['registrations']['complete'])
new='src/script/node_data/method_key_fee_tests.rs';assert not (W/new).exists();updates[new]=checked(tests['selected_private_test'])
migrations=json.loads(checked(tests['migrations']))
assert len(migrations['files'])==7
for row in migrations['files']:
 assert current(row['relative'])==checked(row['before']);checked(row['diff']);updates[row['relative']]=checked(row['raw'])
for row in production['paths']:
 assert current(row['relative'])==checked(row['before']),row['relative'];checked(row['diff']);updates[row['relative']]=checked(row['raw'])
assert len(updates)==16
for relative,raw in updates.items():
 (W/relative).write_bytes(raw);s['source_sha256'][relative]=sha(raw)
s['scope']='Reviewed8productionpaths plus8newgroups and7narrowtestmigrations; before formatting or implementation execution.'
(A/'source-unformatted.json').write_text(json.dumps(s,indent=2)+'\n')
(A/'root/implementation-import.json').write_text(json.dumps({'tests_hold':sha(h),'production_hold':sha(p),'updated_paths':len(updates),'source_inputs':len(s['source_sha256'])},indent=2)+'\n')
print('Imported16paths;1223sourceinputs; no tests run yet')
