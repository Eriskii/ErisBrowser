import hashlib,json,difflib
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';H=A/'tests-before-1';D=A/'production-1'
def bind(path):
 b=path.read_bytes();return {'path':str(path),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
assert hashlib.sha256((H/'source-ready.json').read_bytes()).hexdigest()=='71ca18feb3068a9da8bdde9137121b2d6899013d3c026387a4a170444279f908'
selected={
 'node_connected':['install_node_connected'],
 'node_root':['install_node_root'],
 'node_predicates':['install_node_has_child_nodes','install_node_identity_members'],
 'node_normalize':['install_node_normalize'],
 'node_clone':['install_node_clone'],
 'node_equality':['install_node_equality'],
}
paths=[]
def retain(relative,before,after):
 assert before!=after
 bp=D/'before'/relative;rp=D/'raw'/relative;dp=D/'diffs'/(relative.replace('/','__')+'.patch')
 for path in [bp,rp,dp]:path.parent.mkdir(parents=True,exist_ok=True);assert not path.exists()
 bp.write_text(before);rp.write_text(after);dp.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
 paths.append({'relative':relative,'before':bind(bp),'raw':bind(rp),'diff':bind(dp)})
for stem,installers in selected.items():
 relative='src/script/'+stem+'.rs';before=(W/relative).read_text();after=before
 for name in installers:
  old='    pub(super) fn '+name+'(&mut self, prototype: usize) -> Result<()> {\n        self.work(4)?;'
  new='    pub(super) fn '+name+'(\n        &mut self,\n        prototype: usize,\n        metadata_keys: [&PropertyKey; 2],\n    ) -> Result<()> {\n        // Transfer the existing immutable length/name keys before metadata work.\n        self.work(8)?;\n        self.work(4)?;'
  assert after.count(old)==1,name;after=after.replace(old,new)
 # Only the selected installer bodies call the old factory in these modules.
 import re
 after,count=re.subn(r'self\.node_data_function\(([^\n]+)\)\?',r'self.node_data_function_with_keys(\1, metadata_keys)?',after)
 assert count==len(installers),(stem,count)
 retain(relative,before,after)
relative='src/script/dom_prototypes.rs';before=(W/relative).read_text();after=before
for names in selected.values():
 for name in names:
  old='self.'+name+'(prototype)?;';new='self.'+name+'(prototype, [&keys[1], &keys[0]])?;';assert after.count(old)==1;after=after.replace(old,new)
retain(relative,before,after)
relative='src/script/node_data.rs';before=(H/'registration-complete'/relative).read_text();old='    pub(super) fn node_data_function(\n';assert before.count(old)==1;after=before.replace(old,'    #[cfg(test)]\n'+old);retain(relative,before,after)
m={'status':'source_ready_external_root_authored_no_execution','scope':'Nine factory invocations in seven Node installers reuse the existing metadata pair. Only eight production files. Runtime semantics and caps unchanged.','plan':bind(A/'plans/source-ready.json'),'controls':bind(H/'source-ready.json'),'parent_inventory':bind(A/'parent-source.json'),'paths':paths,'constraints':['Seven8work handoffs before old4','Original installer/callable/owner insertion order','Existing borrowed factory body unchanged','Original fresh factory body retained unchanged undercfg(test)','No live edit or project execution by this script']}
(D/'source-ready.json').write_text(json.dumps(m,indent=2)+'\n');print(json.dumps({'paths':len(paths),'hold':bind(D/'source-ready.json')}))
