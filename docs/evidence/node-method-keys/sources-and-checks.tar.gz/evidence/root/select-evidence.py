import hashlib
import json
from pathlib import Path
A=Path(__file__).resolve().parents[1]
W=A/'worktree'
def bind(p):
    b=p.read_bytes()
    return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
validation=json.loads((A/'root/final-validation.json').read_bytes())
assert validation['status']=='pass'
for relative in ['tests-before-1/html-review.json','production-1/script-review.json','root/final-source-review.json','root/final-validation-review.json']:
    assert 'clear' in json.loads((A/relative).read_bytes())['status'],relative
artifacts={}
excluded={'selection-final.json','publication-verification.json'}
for folder in ['plans','tests-before-1','production-1','root','validation']:
    for p in sorted((A/folder).rglob('*')):
        assert not p.is_symlink(),p
        if not p.is_file() or p.name in excluded: continue
        assert '__pycache__' not in p.parts
        artifacts[str(p.relative_to(A))]=bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.json','.py']:
        artifacts[p.name]=bind(p)
for relative in ['README.md','docs/COMPATIBILITY.md','docs/ROADMAP.md','docs/node-method-keys.md']:
    artifacts['documentation/'+relative]=bind(W/relative)
claims={'base':validation['base'],'scope':'Nine Node method metadata factories share immutable name and length key payloads through seven installers. Public metadata bags remain independent; no runtime invocation or cap change.','validation':validation,'peer':bind(A/'root/final-validation-review.json'),'limitations':'Accounted startup savings only. No full ECMAScript/web compatibility, production-security, physical-memory or Chromium-performance claim.'}
selection={'source_inventory':bind(A/'source1.json'),'artifacts':artifacts,'claims':claims,'max_uncompressed_bytes':128*1024*1024}
(A/'root/selection-final.json').write_text(json.dumps(selection,indent=2)+'\n')
print(json.dumps({'artifacts':len(artifacts),'source_inputs':1223}))
