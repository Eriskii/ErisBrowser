from pathlib import Path
import difflib,json,hashlib
root=Path('/tmp/eris-node-method-keys-1/worktree')
base=Path('/tmp/eris-node-method-keys-1/tests-before-1')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
changes=[
 ('src/script/bootstrap_tests.rs',[("    assert_eq!(reference.steps, 25);","    // Nine further Node factories share immutable keys:250 work/1512 bytes saved.\n    assert_eq!(reference.steps, 275);",1)],'Only aggregate remaining work changes25->275; all shapes, independent dynamic failure boundaries, public resets and comparisons remain.'),
 ('src/script/typed_array/tests.rs',[("            - 108\n", "            - 108\n            + 250\n",1),("            + all_added\n", "            + all_added\n            - 1512\n",1)],'Append source-derived+250work and-1512heap to historical aggregate expressions; retain every existing typed term, historical delta and shape literal.'),
 ('src/script/processing_instruction/key_cache_tests.rs',[("cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99975_work_boundary", "cached_pi_keys_raw_bootstrap_with_promise_uses_the_frozen_99725_work_boundary",1),("[(99_974, false, 0), (99_975, true, 0), (100_000, true, 25)]", "[(99_724, false, 0), (99_725, true, 0), (100_000, true, 275)]",1)],'Current raw boundary only99975->99725; exact/one-short/public remainder follows unchanged100000 cap. PI helper fees/identity unchanged.'),
 ('src/script/promises/install_tests.rs',[("promise_full_raw99975_and_public_reset_preserve_empty_paid_arenas", "promise_full_raw99725_and_public_reset_preserve_empty_paid_arenas",1),("[(99_974, false, 0), (99_975, true, 0), (100_000, true, 25)]", "[(99_724, false, 0), (99_725, true, 0), (100_000, true, 275)]",1)],'Current raw boundary and label only; standalone/shared Promise installer endpoints, empty arenas and public resets unchanged.'),
 ('src/script/promises/shared_key_tests.rs',[("independently migrated99974/99975/100000 witnesses", "independently migrated99724/99725/100000 witnesses",1)],'Comment tracks the current independent raw-boundary witness; every assertion and isolated shared-job-key tariff unchanged.'),
 ('src/script/test262_host/quota_tests.rs',[("    assert_eq!(runtime.steps, 25);", "    assert_eq!(runtime.steps, 275);",1)],'Feature-enabled raw remaining changes only; enabled Runtime header, absent session, registry shapes and host405/49/24/66/audit fees unchanged.'),
 ('src/script/node_data/key_cache_fee_tests.rs',[("node_unselected_original_factory_keeps_its_exact_fees_and_private_key_payloads", "node_standalone_original_factory_keeps_its_exact_fees_and_private_key_payloads",1)],'Label now describes the retained cfg(test) original factory. Its127/126 endpoints, one-short heap and nonshared-payload assertions remain byte-identical; AP98/104/503/90 controls untouched.'),
]
rows=[]
for rel,replacements,reason in changes:
 before=(root/rel).read_text();after=before
 for old,new,n in replacements:
  assert after.count(old)==n,(rel,old,after.count(old));after=after.replace(old,new)
 bp=base/'migrations/before'/rel;rp=base/'migrations/raw'/rel;dp=base/'migrations/diffs'/(rel+'.patch')
 for p in (bp,rp,dp):p.parent.mkdir(parents=True,exist_ok=True)
 bp.write_text(before);rp.write_text(after)
 dp.write_text(''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+rel,tofile='b/'+rel)))
 rows.append({'relative':rel,'before':bind(bp),'raw':bind(rp),'diff':bind(dp),'reason':reason,'replacements':[{'before':a,'after':b,'occurrences':n} for a,b,n in replacements]})
(base/'migrations/selection.json').write_text(json.dumps({'status':'frozen_test_only_migrations_before_production','base':'f3f47af4; exact Rust joins5dc150e2','files':rows,'execution':False,'production_changes':False},indent=2)+'\n')
print(len(rows),'migration files')
