from pathlib import Path
import json,hashlib,difflib,re
base=Path('/tmp/eris-node-method-keys-1/tests-before-1')
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def check_binding(row):
 assert bind(Path(row['path']))=={k:row[k] for k in ['path','bytes','sha256']}
parent=json.loads(Path('/tmp/eris-node-method-keys-1/parent-source.json').read_text())['source_sha256']
inputs=json.loads((base/'source-bindings.json').read_text())
for row in inputs['inputs']:
 check_binding(row);assert parent[row['relative']]==row['sha256']
for row in inputs['references']:check_binding(row)
selection=json.loads((base/'migrations/selection.json').read_text())
for row in selection['files']:
 for k in ['before','raw','diff']:check_binding(row[k])
 old=Path(row['before']['path']).read_text();new=Path(row['raw']['path']).read_text();rebuilt=old
 for r in row['replacements']:
  assert rebuilt.count(r['before'])==r['occurrences'];rebuilt=rebuilt.replace(r['before'],r['after'])
 assert rebuilt==new
 inverse=new
 for r in reversed(row['replacements']):
  assert inverse.count(r['after'])==r['occurrences'];inverse=inverse.replace(r['after'],r['before'])
 assert inverse==old
 expected=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+row['relative'],tofile='b/'+row['relative']))
 assert Path(row['diff']['path']).read_text()==expected
rel='src/script/node_data.rs';before=(base/'before'/rel).read_text()
for kind,extra in [('parent','#[cfg(test)]\nmod method_key_tests;\n'),('complete','#[cfg(test)]\nmod method_key_tests;\n#[cfg(test)]\nmod method_key_fee_tests;\n')]:
 raw=(base/f'registration-{kind}'/rel).read_text()
 assert raw==before.replace('#[cfg(test)]\nmod tests;',extra+'#[cfg(test)]\nmod tests;',1)
 assert raw.replace(extra,'',1)==before
 original=base/'parent-ready.json' if kind=='parent' else None
 if original:
  assert json.loads(original.read_text())['registration']==bind(base/f'registration-{kind}'/rel)
old=(base/'raw/src/script/node_data/method_key_tests.rs').read_text()
new=(base/'correction-1/raw/src/script/node_data/method_key_tests.rs').read_text()
a='    assert_eq!(&runtime.objects[prototype].order[..11], expected_order.as_slice());'
b='    assert_eq!(runtime.objects[prototype].order.first(), Some(&runtime.well_known_key("toStringTag")));\n    assert_eq!(&runtime.objects[prototype].order[1..12], expected_order.as_slice());'
assert old.count(a)==new.count(b)==1 and old.replace(a,b)==new
for f in ['parent-ready.json','parent-ready-2.json']:
 h=json.loads((base/f).read_text());check_binding(h['new_test'])
private=(base/'raw/src/script/node_data/method_key_fee_tests.rs').read_text()
assert new.count('#[test]')==2 and private.count('#[test]')==6
assert sum([27,7,6,28,28,6])==102
result={'status':'passed_inert_source_checks','source_inputs_join_parent':len(inputs['inputs']),'migrations_exact_forward_and_inverse':len(selection['files']),'registration_variants_exact':2,'public_correction':'One explicitly checked tag assertion plus slice shift only; all old bytes otherwise exact.','parent_groups':2,'private_groups':6,'private_attempts':102,'execution':'Only Python text/JSON/hash/diff checks; no Rust/compiler/browser/project tests or imports.','legacy_fees':'All existing AP assertions preserved; original factory migration is function label only.'}
(base/'mechanical-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
