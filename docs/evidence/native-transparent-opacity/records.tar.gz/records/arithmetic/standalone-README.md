# Transparent-opacity arithmetic verifier

Source-only handoff; nothing here has been compiled or executed by its author.
Root owns the first build and run. `integer.rs` is a separable, dependency-free
u32/two-u32 implementation intended for a direct WGSL translation. `main.rs`
contains an independent oracle using explicit separate f32 operators, with
non-inlined arithmetic calls. No renderer/project modules are imported.

Suggested root command (choose the pinned toolchain explicitly):

```
rustc +1.88.0 --edition=2024 -O -C overflow-checks=yes main.rs -o arithmetic-188
./arithmetic-188
```

The fixed schedule checks 16,711,170 interior A/k inverse pairs plus 510 zero/
opaque endpoints; 184 pair multiplication/addition checks; 347 R24 witnesses;
26,000 targeted channel cases; 1,400 root-division boundary cases; 262,144
xorshift32 samples with seed 0x91e10da5; and three literal cases, including both
held rational-rounding counterexamples. Each broad sample compares color,
alpha and root stages and checks premultiplication. Stage bit patterns are
checked before integer output; matching pixels alone is insufficient.

Predicted final counters, conditional on the source completing successfully:
pair_checks184, round24_checks347, inverse_checks16711680,
channel_checks812438, root_checks275247, root_boundary_checks1400,
broad_samples262144, literal_checks3. These are schedule counts, not results.
The program prints actual completed counters and the first failure, then exits
nonzero on failure. No adaptive corpus or expected-value correction is present.

Wide helpers document their admitted operands. `product` accepts u16 times a
24-bit inverse or the exact identity2^24; pair addition is bounded to41 input
bits; R24 preserves significand carry. All shifts have bounded nonzero branches.
Root normalization checks 8421375/8421376/8421377 and quotient bits around every
RGB8 half-integer; the final overshift-to-zero branch is explicit. A/k rows around
P=1/2 are in the channel grid. The verifier's u64/f64 conversions are confined
to independent expected values and diagnostics, never the portable algorithm.

This handoff does not claim shader correspondence, renderer admission, measured
performance or exhaustive coverage of all channel combinations. The actual GPU
shader is deliberately not an input to the independently authored integer module.
