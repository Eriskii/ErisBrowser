# Transparent group opacity: arithmetic assessment

Source-only research against the completed opaque-backed candidate, now committed as `da2d75b` (publication status is outside this assessment). No renderer, shader, compiler, test suite or GPU was executed. Small standalone rational arithmetic calculations derive the numbers below; they are not observed Canvas output. The existing milestone and its artifacts are untouched.

**Conclusion:** arbitrary transparent source alpha at `k/256` cannot use ideal rational source-over as a replacement for Canvas pop. A one-pixel counterexample already differs by one RGB8 level. Exact equivalence is nevertheless algebraically feasible with bounded integer emulation of the existing binary32 stages. That costs more shader arithmetic, but needs neither larger surfaces nor new passes, buffers, lookups or public limits. It remains a proposal requiring independent proof and eventual implementation/measurement.

## The operation that must be reproduced

`Canvas::end_opacity` (`src/graphics.rs:424–481`) uses source alpha A, source premultiplied channel S, destination channel D and opacity k/256. Let R mean binary32 round-to-nearest, ties-to-even:

```
Q = R(A / 65535)
P = R(Q * k/256)
I = R(1 - P)
C = R(R(S * k/256) + R(D * I))
parent = round_away(C)
root   = round_away(R(C / 257))  # D is 257 times the RGB8 destination
```

All inputs are nonnegative, `0 <= S <= A <= 65535`, `0 <= D <= 65535`, and `1 <= k <= 255`. Alpha is another channel for a parent destination. Zero and unit opacity keep the existing suppression/no-layer behavior. Primitive RGBA16 source-over is already integer-exact and need not change.

Rust documents the primitive operations as roundTiesToEven and distinguishes ordinary multiply/add from fused `mul_add`; its `round()` has halfway-away behavior. The source uses ordinary operations. [Rust f32](https://doc.rust-lang.org/std/primitive.f32.html). Direct WGSL float translation is insufficient: its numeric contract permits choices of rounding and division error. [WGSL numeric accuracy, 21 September 2026](https://www.w3.org/TR/2026/CRD-WGSL-20260921/#floating-point-accuracy).

## Two reachable rounding counterexamples

1. **One transparent primitive:** root gray 34; a group at 192/256 containing one black rectangle with alpha 55. The primitive produces S=0 and A=14135; D=8738. Canvas stages are:

   - Q = 14474461/67108864;
   - P = 5427923/33554432;
   - I = 7031627/8388608;
   - C = 15000575/2048 = 7324.49951171875;
   - R(C/257) = 14942207/524288 = 28.499998092651367;
   - RGB8 result **28**, or `1c1c1c`.

   Ideal rational source-over yields `34*(1-(55/255)*(192/256)) = 28.5`, which rounds to **29**. This disproves even a root-only ideal-rational extension.

2. **Nested difference becomes visible:** root gray 44; outer group at 127/256, opaque gray-151 backing, then an inner half-opacity group containing black alpha 38. Before inner pop, A=9766, S=0 and parent D=38807. The inverse is 15527149/16777216. Canvas rounds its channel to 35915.5, then stores **35916**; parent alpha remains 65535. Ideal rational pop gives 9158452/255, storing **35915**. The outer opaque-source pop produces **92** (`5c5c5c`) from Canvas's value and **91** (`5b5b5b`) from the rational substitute.

The static candidate file supplies complete tiny command descriptions and these expectations. It is a prospective oracle, not an executable fixture or evidence of admission.

## A bounded exact integer construction

Define E(x/2^s) as nearest-integer ties-even (quotient, guard and remainder); E(x/d) for odd d has no halfway tie. Define R24(X) as rounding a nonnegative integer to at most 24 significant bits, keeping the result on its original integer scale. Zero is explicit. All bit counts below are mathematical, not WGSL instructions with unchecked shift counts.

### Recover the CPU inverse with u32 only

Handle A=0 as identity and A=65535 with the existing opaque-source formula. Otherwise:

```
h = floor(log2(A))                         # 0..15
X = A << (23-h)                            # < 2^24
M = X + E(X / 65535)                       # < 2^24
T = M*k                                   # < 2^32
s = max(bit_length(T)-24, 0)               # 0..8
U = E(T / 2^s)
r = 47-h-s                                # 24..47
J = 2^24 - E(U / 2^(r-24))                 # inverse is exactly J / 2^24
```

The alpha division identity is `A*2^(39-h)/65535 = X + X/65535`. Therefore M gives exactly R(A/65535), scaled by `2^(h-39)`. T and U reproduce the following multiplication rounding. For P below 1/2, `1-P` is in [1/2,1], so its binary32 lattice is `2^-24`; ties-even rounding commutes with subtraction from the even integer `2^24`. For P at least 1/2, r=24 and subtraction is already exact on that lattice. Thus J reproduces the subtraction stage too. No approximate division or table is involved.

### Preserve both channel roundings

Represent fixed-point integers using two u32 words:

```
B = R24(D*J)                              # D*J < 2^40
Z = (S*k) << 16                           # exact source term on the 2^-24 scale
V = R24(Z+B)                              # C is exactly V / 2^24
parent = floor((V + 2^23) / 2^24)
```

A 16×24-bit product can be formed from two ordinary u32 products of 16-bit pieces and one carry. Addition needs at most 41 bits by the conservative operand bounds. R24 removes at most 17 low bits, so its tie/guard decisions need only bounded shifts, remainder and parity; no variable loop, u64 WGSL feature or global scratch is needed. Source multiplication is exact because S*k has fewer than 24 significant bits. The two R24 calls intentionally remain separate.

Premultiplied channel monotonicity is retained. Ideal over is at most 65535; accumulated binary32 error is less than 1/64 (three inverse-stage errors, destination multiplication and addition bounds suffice), so final parent rounding cannot exceed 65535. All nonzero channel values here are normal binary32; special NaN/infinity/subnormal semantics are unnecessary in this admitted integer-input domain.

### Reproduce the root division, not just its rational value

Normalize nonzero C to `M_c * 2^(e-23)`, with 24-bit M_c and `-8 <= e <= 15`. The lower bound follows because nonzero source weighting and inverse weighting are at least 1/256. Let:

```
if M_c >= 8421376: t=8; B_c=M_c
else:             t=9; B_c=2*M_c
M_root = B_c - E(B_c / 257)
root_f32 = M_root * 2^(e-t-23)
root = round_away(root_f32)
```

The threshold is exactly `2^23 * 257/256`. The identity `B_c*256/257 = B_c-B_c/257` reproduces binary32 division rounding without a wide divide. B_c is below 2^25; the odd divisor precludes halfway quotient ties. The final positive integer rounding is a checked shift plus half-bit; shifts beyond the significand width take an explicit zero branch. This stage must not be replaced by rounding the unrounded rational C/257, which can differ near half-integers.

## Scope, cost and next decision

The proposed general extension retains premultiplied RGBA16 storage, cropped disjoint regions, 128-byte metadata, ordered clear/paint/pop passes, the existing source-over primitive shader and every current command/source/scope/work/byte limit. It removes the opaque-backing prerequisite only once the general pop path is proved and implemented. Empty, zero and unit groups stay unchanged; primitive geometry and source validation still run under the current rules. A=0 pixels are identity, A=65535 can retain the existing fast path, and only intermediate alpha needs the staged path. Nested destinations can have any valid premultiplied alpha.

The logical dispatch count and allocated bytes can stay identical for a given region tree. Additional integer instructions and register pressure are real; no wall-time claim or blanket admission claim follows. Newly eligible scenes may still fail existing padded-invocation, CPU preparation, 16 MiB GPU-buffer or readback budgets. Before implementation, the peer should check carry/tie normalization, the inverse identity and root division. Future meaningful checks should include both counterexamples, every rounding branch, zero/opaque identities, transparent parent alpha and multi-level re-use; their implementation and execution are not part of this assessment.

A smaller alternative is groups with only binary source alpha (0 or 65535), with every partial-opacity child landing on a certified opaque parent region or the root. Transparent pixels skip and opaque pixels use the existing formula. This would support holes between opaque shapes, but not the translucent-image/glyph case in the first counterexample. It is a separate restricted feature choice, not a proof of general transparency.
