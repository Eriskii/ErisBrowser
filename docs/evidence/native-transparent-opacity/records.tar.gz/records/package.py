from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import tarfile

A = Path(__file__).resolve().parent
W = A / 'worktree'
D = W / 'docs/evidence/native-transparent-opacity'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()

def record(path):
    return json.loads((A / path).read_text())

for name in ['bridge-188-1', 'native-full-188-1', 'core-gpu-188-1',
             'core-default-188-1', 'core-clippy-188-1', 'native-clippy-188-1',
             'probe-tests-188-1', 'probe-clippy-188-final']:
    r = record('validation/' + name + '.json')
    assert r['exit'] == 0
    assert sha((A / 'validation' / r['log']).read_bytes()) == r['sha256']
for name, expected in [('native-full-188-1', 2149), ('core-gpu-188-1', 137),
                       ('core-default-188-1', 106), ('probe-tests-188-1', 7)]:
    passed = sum(map(int, re.findall(r'test result: ok\. (\d+) passed;',
                                    (A / 'validation' / (name + '.log')).read_text())))
    assert passed == expected
assert all(r['exit'] == 0 for r in record('validation/fmt-final.json'))
assert record('validation/probe-python-1.json')['exit'] == 0
assert record('validation/browser-build-2.json')['sources_unchanged']
assert record('validation/browser-build-2.json')['exit'] == 0
gpu = record('offscreen-2/host-results.json')
assert gpu['success'] and gpu['adapter_count'] == 3
for run in gpu['runs']:
    assert run['returncode'] == 0 and run['cleanup']['complete']
    assert run['cleanup']['descendants'] == 0
    if run['name'] == 'enumeration':
        continue
    v = run['validation']
    assert (v['literal_frames'], v['literal_bytes']) == (34, 512)
    assert (v['reuse_frames'], v['reuse_bytes']) == (14, 448)
    assert (v['transparent_reuse_frames'], v['transparent_reuse_bytes']) == (14, 448)

D.mkdir(exist_ok=False)
paths = sorted(set(subprocess.check_output(['git', 'diff', '--name-only'], cwd=W, text=True).splitlines()
                   + subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard'], cwd=W, text=True).splitlines()))
paths = [p for p in paths if not p.startswith('docs/evidence/')]
entries = {}
sources = []
for path in paths:
    data = (W / path).read_bytes()
    sources.append({'path': path, 'bytes': len(data), 'sha256': sha(data)})
    entries['source/' + path] = data
(A / 'final-source.json').write_bytes(encoded(sources))
for p in sorted(A.rglob('*')):
    if not p.is_file() or p.is_symlink():
        continue
    rel = p.relative_to(A)
    if rel.parts[0] == 'worktree' or '__pycache__' in rel.parts:
        continue
    # Executables stay local; their exact build/source/hash records are retained.
    if p.suffix not in {'.json', '.log', '.rs', '.wgsl', '.md', '.py'}:
        continue
    entries['records/' + str(rel)] = p.read_bytes()
items = [{'path': p, 'bytes': len(b), 'sha256': sha(b)} for p, b in sorted(entries.items())]
archive = D / 'records.tar.gz'
with archive.open('xb') as f:
    with gzip.GzipFile(fileobj=f, mode='wb', filename='', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w') as tar:
            for name, data in sorted(entries.items()):
                info = tarfile.TarInfo(name)
                info.size = len(data)
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
index = {
    'schema': 1,
    'base_commit': record('base.json')['base_commit'],
    'archive': {'path': 'records.tar.gz', 'bytes': archive.stat().st_size,
                'sha256': sha(archive.read_bytes())},
    'files': len(items), 'payload_bytes': sum(i['bytes'] for i in items),
    'members': items,
}
(D / 'index.json').write_bytes(encoded(index))
summary = {
    'schema': 1,
    'checkpoint': 'Transparent native Vulkan opacity at k/256',
    'base_commit': index['base_commit'],
    'scope': 'Remove opaque-backing prerequisite; reproduce separate Canvas binary32 stages with u32 pairs. Zero/opaque fast paths and complete-scene admission remain.',
    'renderer_limits_raised': False,
    'harness_inventory_changes': {'surface_cases': [16, 17], 'host_records': [96, 128]},
    'package': {'path': 'native-transparent-opacity/index.json',
                'sha256': sha((D / 'index.json').read_bytes()),
                'archive': index['archive'], 'files': len(items),
                'payload_bytes': index['payload_bytes']},
    'record_paths': 'records/ and source/ members inside the archive; recorded absolute paths identify original local inputs',
    'validation': {'rust': '1.88.0', 'full_native_tests': 2149,
                   'ignored_confinement_tests_included': True, 'bridge_groups': 73,
                   'core_gpu_tests': 137, 'core_default_tests': 106,
                   'probe_tests': 7, 'probe_python_tests': 98,
                   'strict_clippy': ['validation/native-clippy-188-1.json',
                                     'validation/core-clippy-188-1.json',
                                     'validation/probe-clippy-188-final.json'],
                   'formatting': 'validation/fmt-final.json'},
    'arithmetic': {'inverse_pairs': 16711680, 'channel_checks': 812438,
                   'root_checks': 275247, 'root_boundary_checks': 1400,
                   'seeded_premultiplied_samples': 262144,
                   'standalone': 'arithmetic/run-1.json',
                   'also_retained_as_six_core_tests': True,
                   'root_literal': {'gray': 34, 'black_alpha': 55, 'opacity_numerator': 192, 'result': 28, 'ideal_rational_result': 29},
                   'nested_literal': {'result': 92, 'ideal_rational_result': 91}},
    'offscreen': {'record': 'offscreen-2/host-results.json',
                  'binary': record('validation/checker-build-2.json')['binary'],
                  'adapters': gpu['runs'][0]['validation']['adapters'],
                  'frames_per_adapter': 62, 'bytes_per_adapter': 1408,
                  'total_frames': 186, 'total_compared_bytes': 4224,
                  'per_adapter': {'literal': [34, 512], 'opaque_reuse': [14, 448],
                                  'transparent_reuse': [14, 448],
                                  'successful_allocations': 14, 'successful_reuses': 14,
                                  'successful_evictions': 14, 'separate_cancellation_checks': 16},
                  'unique_planner_refusals': 1, 'acquired_surface': False,
                  'all_owned_children_cleaned_up': True},
    'browser': {'release_build': 'validation/browser-build-2.json',
                'binary': record('validation/browser-build-2.json')['binary'],
                'new_example': 'examples/vulkan-transparent-opacity.html',
                'Page_and_worker_each_test_three_scenes_before_and_after_real_click': True,
                'new_window_execution': False},
    'retained_failures': [
        {'record': 'offscreen-1/host-results.json',
         'cause': 'Offline checker16-case inventory cap rejected17 literals before Vulkan initialization.',
         'correction': 'harness-correction/receipt.json'},
        {'record': 'validation/browser-build-1.json',
         'cause': 'Root supplied library name eris as --bin; corrected to declared eris-browser target. No source change.'},
    ],
    'preceding_checkpoint': {'commit': index['base_commit'], 'all_nine_CI_jobs_successful': True,
                             'CI': 'native-scope-accounting-ci.json',
                             'publication_review': 'native-scope-accounting-publication-review.json'},
    'remaining': 'Non-grid opacity, broader native admission, complete CSS/web compatibility, production security and Chromium-relative performance remain unfinished.',
    'security_or_performance_claim': False,
}
(W / 'docs/evidence/vulkan-transparent-opacity.json').write_bytes(encoded(summary))
print(json.dumps({'archive': index['archive'], 'files': len(items),
                  'payload_bytes': index['payload_bytes'], 'source_paths': len(sources),
                  'summary_sha256': sha((W / 'docs/evidence/vulkan-transparent-opacity.json').read_bytes())}))
