# Independent append producer review

Source-only review of proposal-2.md and literal-cases-2.js. No compiler, engine or repository mutation.

The conversion/materialization/fragment-assembly/final-append ordering is coherent with the current DOM and Web IDL algorithms. All seven literal cases, including the corrected Document callable/success guard, have sound expectations. A caught later hierarchy failure retains completed moves and exact detached Text payloads; abrupt argument conversion permits only author callback effects. Genuine Node arguments must not invoke ToString. Empty, undefined and null remain actual string arguments, distinct from zero arguments.

Two concrete test setup findings must be preserved:

1. `all_text_nodes_materialize_before_any_argument_moves` fills to MAX_NODES-1 but does not guarantee spare arena capacity. Reserve its one test-owned slot before the measured call to continue testing second-Text node-cap refusal. Keep all original assertions and retain original source. Separately test actual full-arena growth refusal with no current Text publication. At approximately100k nodes, work(1+2*N) already exceeds100000, so work refuses before the >8MiB requested buffer charge is reached.
2. `terminal_second_move_keeps_the_first_node_in_the_temporary_fragment` calibrates on `initial.clone()`, whose Vec capacity is its length. New fragment growth introduces roughly2000 work and breaks its budget<1024 isolation, while the original arena may have spare capacity. Materialize the calibration clone in a local variable, explicitly reserve one slot in both calibration and actual trees, and preserve the complete existing prefix assertions and budget guard. Keep a distinct growth-sensitive witness; do not hide the real paid reserve by changing production fees.

Bounded implementation:

- Change AppendValue::Text(String) to JsString and use one string_hint conversion per non-Node argument. Use checked argument-count/storage arithmetic and actual size_of<AppendValue>; immutable retained strings require no extra projection copy.
- After every conversion succeeds, materialize each string separately with plan_dom_data, fixed fresh-admission debit, fresh stored_bytes/node admission, existing logical128-byte node charge, emit_dom_data, and the fixed publication debit before dom_reserve_node_growth(doc,1). Move through create_text_node_owned. No fallible admission follows real reserve except redundant unchanged checked creation guards; no callback intervenes.
- A narrow private append Text-materialization helper is reasonable if it lets exact/one-short tests measure this phase directly, without mistaking a whole-append final failure (where nodes have already been published) for a materialization failure. Keep the outer sequence and every dom_checked_append call unchanged.
- Reserve the temporary fragment only at its existing zero/multiple-argument point after every Text exists; charge its actual growth before raw creation. Do not batch reserve future nodes or prevalidate final Document hierarchy.

For N retained source units, plan pays3N+8. Scalar emit pays3N+8+B and B heap bytes; Units emit pays2N+8 and2N bytes, then separately2N+1 validation. These are the existing shared-builder fees, not new discounts. Keep both fixed admission/publication work payments. Real arena growth retains1+2*len work and required*sizeof(Node) bytes; spare capacity has no relocation charge. Removing the lossy conversion buffer and raw retained copy is a genuine algorithm change, and can permit later conversion callbacks that previously lost their allowance to the removed buffer. Document that resource-observation difference explicitly.

No metadata/constructor/property placement changes are needed, so bootstrap inventory and fees should remain unchanged. Existing insertion details/base/child-vector bookkeeping and infallible allocation limitations remain separate; this producer migration must not claim Node replacement-style whole-commit admission for append.

Required new boundaries: scalar and Units materialization with spare/full arena, first completed Text retained on later byte/node refusal, all completed Texts retained on temporary-fragment refusal, original argument nodes unmoved until materialization ends, later-move prefix retained, and fresh callback node/byte changes. Keep zero versus empty cases and per-argument high/low nodes distinct. Existing complete-splice or nullable setter rules do not apply to append.

Primary sources checked: https://dom.spec.whatwg.org/#converting-nodes-into-a-node and https://webidl.spec.whatwg.org/#es-overloads (variadic undefined conversion). All observations here are source-derived; no outcome is predicted as a measured pass.
