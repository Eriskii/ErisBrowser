# Exact append replay

The frozen input is the reviewed seven-case `literal-cases-2.js`, copied byte-for-byte into preparation-history. Each named case runs separately in a fresh adapter process in sloppy and strict mode, for14 ordinary-success modes. The wrapper requires its return value to be true. No expected outcome is replaced by a resource or unsupported policy.

Four guarded positive/wrong pairs run in both modes (16 controls): literal UTF16 units, actual scalar append/move across the three defining interfaces, abrupt conversion prefix identity, and separate exact append Text payloads. Every negative source is the exact positive source plus a deliberate intrinsic Error. Prerequisite failures use TypeError, so a missing callable or incorrect feature cannot impersonate the expected negative error. The exact-payload pair may remain unmet in the baseline; those observations must remain visible. Raw negative adapter status may be failed while its separately declared complete error observation matches.

`replay.py --prepare` and `--verify` ran Python/data checks only. They freeze source, expected observations, case fingerprints, all copied preparation history, and the three imported tooling files. Timeout/adapter-error/static refusal rows with absent observations, explicit null/non-object observations, and malformed empty observations are tested without an engine and cannot match. Unexpected runner exceptions are retained as infrastructure-error rows and cause exit3 after writing the report. Post-run input/matrix/binary changes or disappearance are recorded alongside all observations and cause exit2.

The existing `test262_conformance.run_case` and bounded-process helper are reused unchanged: sequential execution, three-second per-case timeout,96KiB stdout and64KiB stderr limits. This does not broaden their process-cleanup or raw-output retention contract. Existing Runtime quotas and reset sites remain unchanged.

Only after source review, invoke the pinned Node baseline with a fresh output path:

```sh
python3 /tmp/eris-append-domstrings-1/replay.py /tmp/eris-node-data-1/eris-js 30269af68b3c87349c122104a7da0be0cd1b5f3ad20816620c66cd2c5d8058f1 /tmp/eris-append-domstrings-1/before.json
```

A later release replay uses the same frozen matrix and independently pinned new binary digest with a different fresh output. Exclusive creation prevents overwriting a prior report. The supplied digest must match before any adapter invocation, and all bindings are rechecked after the final case. No baseline or release invocation has run during preparation.

Preparation history includes the unchanged first/second proposals and fixture drafts, corrected callable-guard review, independent script review, and both explicit capacity-sensitive test findings. The later browser fixture is a separate preparation stream. No repository code was edited to prepare this replay.
