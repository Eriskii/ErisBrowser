# Exact append browser overlay

Held source overlay for parent c47fe953a97c45f98045f1f75e43587e50479110. Copy only the four `tests/` files into the isolated append worktree after review. Existing pipeline/worker contents are exact prefixes; rustfmt removed one extra blank line at each appended seam. HTML is the already reviewed source byte-for-byte.

One Page test and one confined-worker test retain a load/click realm. Worker generation 207 was unused in the published base. The shared public-API helper checks literal UTF-16 units, separate Text identities, detached earlier nodes/subtree, cross-node pair aggregation, restored Document root and retained hierarchy-failure fragments. A script-disabled cloned-document reference changes only the three visible Text payloads to independently literal replacement-glyph strings, each four UTF-8 bytes, preserving chosen storage bytes, node identities and boundaries. Both complete 320×240 canvases must agree.

Source formatting and data-only base/hash checks passed. No compiler, test, engine or GUI execution was performed. Scope/feasibility remain to be measured by root.

Root's later targeted commands from the isolated worktree (not executed here):

```sh
cargo +1.88 test --test pipeline append_exact_strings_preserve_separate_nodes_and_retained_hierarchy_prefixes -- --exact
cargo +1.88 test --test worker confined_append_exact_strings_preserve_nodes_units_and_restored_root -- --exact --ignored
```

The confined command requires the existing Linux Landlock ABI 6 environment. Cleanup uses the existing Fixture/client paths. No new process protocol, waits or engine hooks are added.
