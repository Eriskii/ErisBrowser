#!/usr/bin/env python3
"""Data checks only: this file imports the stdlib-only comparator, never a runner."""
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('append_comparator', BASE.parent / 'compare-append.py')
c = importlib.util.module_from_spec(spec)
spec.loader.exec_module(c)
checks = []

good = dict(id='probe', mode='strict', source_sha256='fixed', status='passed')
bad = dict(good, status='failed', reason='literal failure')
assert c.compare_rows([good], [good])['unchanged'] == 1
assert c.compare_rows([bad], [good])['gains'] == 1
assert c.compare_rows([good], [bad])['losses'] == 1
changed = dict(bad, stderr='retained diagnostic')
assert c.compare_rows([bad], [changed])['other_changes'] == 1
drift = dict(good, source_sha256='changed')
result = c.compare_rows([bad], [drift])
assert result['gains'] == 0 and result['other_changes'] == 1 and result['input_changes']
assert result['changes'][0]['before'] == bad and result['changes'][0]['after'] == drift
assert c.compare_rows([good], [])['removed'] == [good]
assert c.compare_rows([], [good])['added'] == [good]
try:
    c.compare_rows([good, good], [good])
except ValueError:
    pass
else:
    raise AssertionError('duplicate identity accepted')
checks.append('unchanged, gain, loss, other, input drift, full rows, added/removed, duplicate refusal')

expected = dict(status='complete', phase='runtime', error_type='', error_identity='')
declared = dict(good, expected_observation=expected, matches_expectation=True)
for observation in [None, [], {}, dict(expected, phase='parse')]:
    assert not c.healthy(dict(declared, observation=observation))
assert not c.healthy(declared)
assert c.healthy(dict(declared, observation=expected))
assert not c.healthy(dict(declared, observation=expected, verified_with_protocol_prerequisite=False))
negative = dict(status='exception', phase='runtime', error_type='Error', error_identity='Error')
guard = dict(good, status='failed', expected_observation=negative,
             observation=negative, matches_expectation=True)
assert c.healthy(guard)
assert not c.healthy(dict(guard, observation=dict(negative, error_identity='TypeError')))
wrapper = dict(expected='failed', verified=True, result=bad)
assert c.healthy(wrapper)
assert not c.healthy(dict(wrapper, verified=False))
checks.append('missing/malformed observation, protocol flag, intrinsic Error identity and wrapped controls')

config, bindings, totals = c.verify_before()
for name, filename, cases, controls, group in c.SPECS:
    report, _ = c.read(c.before_path(name, filename))
    assert c.compare_rows(report['cases'], report['cases'])['unchanged'] == cases
    assert c.compare_rows(c.controls(report), c.controls(report))['unchanged'] == controls
checks.append('all eleven frozen complete case/control collections compare equal to themselves')

# Run comparison against explicitly synthetic JSON and inert nonexecutable bytes.
# No real after-report paths are populated; no process is launched.
tmp = BASE / 'synthetic-records'
tmp.mkdir()
binary = tmp / 'inert-bytes.txt'
binary.write_bytes(b'synthetic digest input; never executable\n')
binary_sha = hashlib.sha256(binary.read_bytes()).hexdigest()
input_path = tmp / 'inputs.json'
input_path.write_text('{}\n')
_, input_binding = c.read(input_path)
c.HERE = tmp
c.SPECS = [('append-exact', 'append-after.json', 1, 1, 'new')]
c.verify_before = lambda: ({'baseline_release_sha256': 'old'}, [input_binding],
                          {'established_cases': 0, 'established_controls': 0,
                           'new_cases': 1, 'new_controls': 1})
old = dict(binary_sha256='old', source_sha256='fixed', bounds={'timeout': 3},
           unknown_header={'kept': 'old'}, cases=[bad], controls=[guard])
new = dict(binary_sha256=binary_sha, source_sha256='fixed', bounds={'timeout': 3},
           unknown_header={'kept': 'new'}, cases=[good], controls=[guard])
(tmp / 'append-before.json').write_text(json.dumps(old))
(tmp / 'append-after.json').write_text(json.dumps(new))
with contextlib.redirect_stdout(io.StringIO()):
    assert c.compare(binary, tmp / 'clear-comparison.json') == 0
output = json.loads((tmp / 'clear-comparison.json').read_bytes())
assert output['summary']['new']['cases']['gains'] == 1
assert output['summary']['new']['controls']['unchanged'] == 1
assert output['profiles'][0]['before_header']['unknown_header'] == {'kept': 'old'}
assert output['profiles'][0]['after_header']['unknown_header'] == {'kept': 'new'}
saved = (tmp / 'clear-comparison.json').read_bytes()
try:
    c.compare(binary, tmp / 'clear-comparison.json')
except ValueError:
    pass
else:
    raise AssertionError('existing output accepted')
assert (tmp / 'clear-comparison.json').read_bytes() == saved
new = copy.deepcopy(new)
new['binary_sha256'] = 'incorrect'
new['source_sha256'] = 'changed'
new['binding_failures'] = [{'path': 'retained-input', 'reason': 'synthetic mutation'}]
new['cases'][0]['source_sha256'] = 'changed'
(tmp / 'append-after.json').write_text(json.dumps(new))
with contextlib.redirect_stdout(io.StringIO()):
    assert c.compare(binary, tmp / 'failed-comparison.json') == 2
output = json.loads((tmp / 'failed-comparison.json').read_bytes())
assert len(output['validation_failures']) == 4
assert output['summary']['new']['cases']['gains'] == 0
assert output['summary']['new']['cases']['other_changes'] == 1
assert output['profiles'][0]['cases']['changes'][0]['after'] == new['cases'][0]
checks.append('synthetic end-to-end header/full-row retention, binary/input/binding failures and exclusive output')
print(json.dumps(dict(status='passed', checks=checks, frozen_populations=totals,
                     engine_runs=[], compiler_runs=[]), indent=2))
