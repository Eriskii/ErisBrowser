import hashlib,io,json,os,re,tarfile
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads((BASE/path).read_text())
def check(label):
 r=read('validation/'+label+'.json');assert r['exit']==0
 assert sha(BASE/'validation'/r['log'])==r['sha256'];return r
def total(label):
 rows=re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',(BASE/'validation'/(label+'.log')).read_text())
 return [sum(int(r[i]) for r in rows) for i in range(3)]
assert total('full-default-188-1')==[1637,0,0] and total('full-native-198-1')==[1760,0,0]
source=read('main-source-final.json');assert len(source['files'])==9
for row in source['files']:assert sha(ROOT/row['path'])==row['sha256']==sha(BASE/'final-source'/row['path'])
release=read('release.json');assert sha(BASE/'eris-js')==release['sha256']
comparison=read('append-comparison.json');assert not comparison['validation_failures']
s=comparison['summary'];assert s['established']['cases']['unchanged']==4124 and s['established']['controls']['unchanged']==388
assert s['new']['cases']['before_healthy']==4 and s['new']['cases']['after_healthy']==14
assert s['new']['cases']['gains']==10 and s['new']['cases']['losses']==0 and s['new']['cases']['other_changes']==0
assert s['new']['controls']['before_healthy']==12 and s['new']['controls']['after_healthy']==16 and s['new']['controls']['gains']==4
summary=dict(kind='Exact ParentNode.append string production',base_commit=source['base'],scope='Document/Element/DocumentFragment append retains exact UTF-16 string arguments, materializes separate canonical Texts after complete conversion, and prepays typed arena growth immediately before Text/fragment publication while preserving earlier completed effects.',source=source,release=release,final_validation={label:check(label) for label in ['full-default-188-1','full-native-198-1','clippy-native-198-1','clippy-presenter-188-1','format-198-final','release-adapter-188-1']},tests=dict(default=1637,native=1760,new_groups=18,focused_unique=78,focused_executions=81,failed=0,ignored=0,all_build_and_test_commands_passed_first_attempt=True),raw_bootstrap=read('source-ready.json')['raw_bootstrap'],compatibility=dict(path='append-comparison.json',sha256=sha(BASE/'append-comparison.json'),summary=s),retained_preparation_history=['The initial unexecuted fixture draft gained an explicit successful Document.append prerequisite guard; original draft retained, corrected bytes frozen before every engine invocation.','Two existing private test setups gained explicit test-owned spare capacity to isolate their unchanged node-cap and second-move assertions; separate tests exercise newly paid real growth refusal. Original files retained.','Capacity assessment clarified that large-arena growth work refusal precedes the unaffordable buffer charge. No quotas/reset points or original assertions changed.'],boundaries=['General raw insertion child-vector/BTree/URL/encoding/IDNA allocations retain their existing limitations; this is not a fully fallible transaction or process-wide allocator meter.','Legacy innerText/title/textarea setters, attribute and parser writes remain separate work.','Prepend, replaceChildren, complete mutation reactions and cross-document adoption remain incomplete.','Two original PI host-prototype mutation expectations remain unmet.','No new GPU performance or Chromium comparison. Full web compatibility and production security are not achieved.'])
(BASE/'result.json').write_text(json.dumps(summary,indent=2)+'\n')
files=[]
for folder,dirs,names in os.walk(BASE):
 dirs[:]=sorted(d for d in dirs if d not in {'worktree','__pycache__','.git'})
 for name in sorted(names):
  p=Path(folder)/name
  if p==BASE/'eris-js' or p.is_symlink() or name=='final-publication-review.json':continue
  files.append(p)
rows=[dict(path=str(p.relative_to(BASE)),bytes=p.stat().st_size,sha256=sha(p)) for p in files]
manifest=(json.dumps(dict(files=rows),indent=2)+'\n').encode()
archive=ROOT/'docs/evidence/append-domstrings.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(BASE)),recursive=False)
 entry=tarfile.TarInfo('archive-manifest.json');entry.size=len(manifest);tar.addfile(entry,io.BytesIO(manifest))
with tarfile.open(archive,'r:gz') as tar:
 for row in rows:
  data=tar.extractfile(row['path']).read();assert len(data)==row['bytes'] and hashlib.sha256(data).hexdigest()==row['sha256']
summary['archive']=dict(path=archive.name,bytes=archive.stat().st_size,sha256=sha(archive),files=len(files),manifest_verified=True)
(ROOT/'docs/evidence/append-domstrings.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary['archive']))
