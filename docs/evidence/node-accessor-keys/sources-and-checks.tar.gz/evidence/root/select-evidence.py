import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

validation = json.loads((A / 'root/final-validation.json').read_text())
assert validation['status'] == 'pass'
peer = A / 'root/final-validation-review.json'
assert 'clear' in json.loads(peer.read_text())['status']
artifacts = {}
for folder in ['plans', 'production-1', 'documentation-1', 'root', 'validation']:
    for path in sorted((A / folder).rglob('*')):
        assert not path.is_symlink(), path
        if not path.is_file() or path.name in ['selection-final.json', 'publication-verification.json']:
            continue
        assert '__pycache__' not in path.parts
        artifacts[str(path.relative_to(A))] = bind(path)
for path in sorted(A.iterdir()):
    if path.is_file() and path.suffix in ['.py', '.json']:
        artifacts[path.name] = bind(path)
for relative in ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/node-accessor-keys.md']:
    assert 'PENDING_' not in (W / relative).read_text()
    artifacts['documentation/' + relative] = bind(W / relative)
claims = {
    'base': '720127cb078b9eb671ae1ecf5b16b2d20f3a8d60',
    'scope': 'Share existing immutable DOM name/length keys among four Node accessor metadata bags; preserve existing identities, descriptors, author behavior and limits.',
    'startup_saving': {'work_units': 128, 'accounted_heap_bytes': 672},
    'parent_baseline': {'groups': 2, 'passed': 1, 'failed': 1, 'failure': 'Backing pointer differs at getNodeValue length; descriptor/order/saved behavior control passes both modes.'},
    'tests': {'new_groups': 8, 'focused_passed': 37, 'aggregate_migration_files': 6},
    'validation': validation,
    'validation_peer': bind(peer),
    'limitations': 'No API coverage addition, cap increase, whole-initialization rollback, GPU-device execution or Chromium performance/security result. Existing partial private-prefix retention is explicitly tested.',
}
selection = {'source_inventory': bind(A / 'source1.json'), 'artifacts': artifacts, 'claims': claims,
             'max_uncompressed_bytes': 128 * 1024 * 1024}
(A / 'root/selection-final.json').write_text(json.dumps(selection, indent=2) + '\n')
print(json.dumps({'artifacts': len(artifacts), 'source_inputs': 1093}))
