import hashlib
import json
import re
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def checked(label):
    path = A / 'validation' / (label + '.json')
    receipt = json.loads(path.read_text())
    assert receipt['exit'] == 0, label
    log = path.parent / receipt['log']
    assert bind(log)['sha256'] == receipt['sha256'], label
    return {'receipt': bind(path), 'log': bind(log), 'command': receipt['command']}, log.read_text()

snapshot = json.loads((A / 'source1.json').read_text())
for relative, digest in snapshot['source_sha256'].items():
    assert bind(W / relative)['sha256'] == digest, relative
results = {}
rosters = []
for label, expected in [('full-default-msrv-1', 2895), ('full-host-vulkan-199-1', 3249)]:
    result, text = checked(label)
    rows = [list(map(int, match)) for match in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', text)]
    assert len(rows) == 48 and all(row[1:] == [0, 0, 0, 0] for row in rows)
    assert sum(row[0] for row in rows) == expected
    result.update(passed=expected, result_rows=len(rows), failed=0, ignored=0)
    new = re.findall(r'^test (script::node_data::key_cache(?:_fee)?_tests::\S+) \.\.\. ok$', text, re.M)
    assert len(new) == 8
    result['new_groups'] = sorted(new)
    rosters.append(sorted(new))
    results[label] = result
assert rosters[0] == rosters[1]
for label in ['node-controls-msrv-1', 'clippy-default-msrv-1', 'clippy-host-vulkan-199-1', 'fmt-check-1']:
    results[label], _ = checked(label)
validation = {'status': 'pass', 'source_inventory': bind(A / 'source1.json'), 'results': results,
              'raw_default_focused': {'remaining_work': 133, 'accounted_heap': 1738688, 'objects': 749, 'object_capacity': 749, 'native_registry': 299, 'prototype_registry': 25},
              'scope': 'Eight new Rust groups; unchanged web/API behavior. Two complete Rust configurations, including all ignored tests; no new GPU execution or Chromium performance claim.'}
(A / 'root/final-validation.json').write_text(json.dumps(validation, indent=2) + '\n')
draft = A / 'documentation-1/raw/docs/node-accessor-keys.md'
assert bind(draft)['sha256'] == '80d5d69063719c19df27a2a4f13acbd83d917d9bafd4e91fd1cb4fcf8fd73b93'
text = draft.read_text()
marker = 'PENDING_FINAL_VALIDATION: Full-suite and remaining validation results will be\nfilled from their completed receipts before publication.'
assert text.count(marker) == 1
text = text.replace(marker, 'The complete Rust 1.88 default suite passes 2,895 tests. Rust 1.99 with\n`test262-host,vulkan-raster` passes 3,249. Both runs include ignored tests and\nreport zero failures or ignored cases; strict Clippy passes in both configurations,\nand Rust 1.88 formatting checks pass. The [evidence summary](evidence/node-accessor-keys/summary.json)\nbinds the source, frozen controls, parent failure, reviews and completed logs.\nThis validation does not establish a new GPU-device or browser-speed result.')
assert 'PENDING_' not in text
(W / 'docs/node-accessor-keys.md').write_text(text)
print(json.dumps({'status': 'pass', 'source_inputs': len(snapshot['source_sha256']), 'full_totals': [2895, 3249]}))
