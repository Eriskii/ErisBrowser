import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'plans/tests-before'
data = (H / 'source-ready.json').read_bytes()
assert hashlib.sha256(data).hexdigest() == 'f7b1b53b50c54ace5a3c03e59750106fee02947f88d7a1319314e9d7e3b9239f'
manifest = json.loads(data)
for entry in manifest['files']:
    payload = Path(entry['path']).read_bytes()
    assert len(payload) == entry['bytes'], entry['path']
    assert hashlib.sha256(payload).hexdigest() == entry['sha256'], entry['path']
registration = H / 'registration/parent-compatible'
before = (registration / 'before.rs').read_bytes()
raw = (registration / 'raw.rs').read_bytes()
assert raw.replace(b'#[cfg(test)]\nmod key_cache_tests;\n', b'', 1) == before
target = W / 'src/script/node_data.rs'
assert target.read_bytes() == before
module_path = 'src/script/node_data/key_cache_tests.rs'
assert not (W / module_path).exists()
target.write_bytes(raw)
(W / module_path).write_bytes((H / 'raw' / module_path).read_bytes())
snapshot = json.loads((A / 'parent-source.json').read_text())
for rel in ('src/script/node_data.rs', module_path):
    snapshot['source_sha256'][rel] = hashlib.sha256((W / rel).read_bytes()).hexdigest()
snapshot['scope'] = 'Node key-sharing parent-compatible tests only, before formatting; production unchanged.'
(A / 'source-tests-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
print(json.dumps({'inputs': len(snapshot['source_sha256']), 'groups': 2, 'production_changed': False}))
