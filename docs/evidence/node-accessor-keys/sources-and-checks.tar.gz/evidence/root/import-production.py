import difflib
import hashlib
import json
from pathlib import Path

A = Path(__file__).resolve().parents[1]
W = A / 'worktree'
H = A / 'plans/tests-before'
P = A / 'production-1'

def verify(value):
    if isinstance(value, dict):
        if {'path', 'bytes', 'sha256'} <= value.keys():
            data = Path(value['path']).read_bytes()
            assert len(data) == value['bytes'], value['path']
            assert hashlib.sha256(data).hexdigest() == value['sha256'], value['path']
        for item in value.values():
            verify(item)
    elif isinstance(value, list):
        for item in value:
            verify(item)

hold = (P / 'source-ready.json').read_bytes()
assert hashlib.sha256(hold).hexdigest() == 'b1de51d03190b0c8f04feaf6c183ce155a28e15b1e49a9d9f3ebd8df4bac15b1'
prod = json.loads(hold)
migrations = json.loads((H / 'migrations/selection.json').read_text())
verify(prod)
verify(json.loads((H / 'source-ready.json').read_text()))
verify(migrations)
pending = []
for row in prod['paths'] + migrations['paths']:
    before = Path(row['before']['path']).read_bytes()
    raw = Path(row['raw']['path']).read_bytes()
    assert (W / row['path']).read_bytes() == before, row['path']
    expected = ''.join(difflib.unified_diff(before.decode().splitlines(True), raw.decode().splitlines(True),
                                          fromfile='a/' + row['path'], tofile='b/' + row['path']))
    assert Path(row['diff']['path']).read_text() == expected, row['path']
    pending.append((W / row['path'], raw))
module = 'src/script/node_data/key_cache_fee_tests.rs'
assert not (W / module).exists()
pending.append((W / module, (H / 'raw' / module).read_bytes()))
for target, data in pending:
    if target == W / 'src/script/node_data.rs':
        marker = b'#[cfg(test)]\nmod key_cache_tests;\n'
        assert data.count(marker) == 1
        data = data.replace(marker, b'#[cfg(test)]\nmod key_cache_fee_tests;\n' + marker)
    target.write_bytes(data)
snapshot = json.loads((A / 'source-tests-formatted.json').read_text())
for target, _ in pending:
    rel = str(target.relative_to(W))
    snapshot['source_sha256'][rel] = hashlib.sha256(target.read_bytes()).hexdigest()
snapshot['scope'] = 'Node accessor key sharing, frozen controls and six aggregate startup migrations, before rustfmt.'
(A / 'source-production-raw.json').write_text(json.dumps(snapshot, indent=2) + '\n')
receipt = {'production_hold_sha256': hashlib.sha256(hold).hexdigest(), 'production_paths': prod['raw_paths'],
           'migration_paths': [r['path'] for r in migrations['paths']], 'new_private_test_module': module,
           'inputs': len(snapshot['source_sha256'])}
(A / 'root/import-production.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt))
