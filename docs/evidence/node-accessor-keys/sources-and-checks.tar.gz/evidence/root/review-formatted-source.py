from pathlib import Path
import json,hashlib,re,difflib
r=Path('/tmp/eris-node-accessor-keys-1');w=r/'worktree';t=r/'plans/tests-before';p=r/'production-1'
def b(q):
 q=Path(q);v=q.read_bytes();return {'path':str(q),'bytes':len(v),'sha256':hashlib.sha256(v).hexdigest()}
def sha(q):return b(q)['sha256']
inv=json.loads((r/'source1.json').read_text())['source_sha256'];assert len(inv)==1093
for path,h in inv.items(): assert sha(w/path)==h,path
parent=json.loads(Path('/tmp/eris-promise-test262-1/source-2.json').read_text())['source_sha256']
added=sorted(set(inv)-set(parent));removed=sorted(set(parent)-set(inv));changed=sorted(k for k in parent if k in inv and parent[k]!=inv[k])
assert added==['src/script/node_data/key_cache_fee_tests.rs','src/script/node_data/key_cache_tests.rs'];assert not removed
migrations=json.loads((t/'migrations/selection.json').read_text())['paths'];expected=sorted([x['path'] for x in migrations]+['src/script/node_data.rs','src/script/dom_prototypes.rs']);assert changed==expected,(changed,expected)
for x in json.loads((p/'source-ready.json').read_text())['paths']:
 for typ in ['before','raw','diff']:assert b(x[typ]['path'])==x[typ]
for x in migrations:
 for typ in ['before','raw','diff']:assert b(x[typ]['path'])==x[typ]
# Exact production composition, including sole post-hold private test registration.
raw=(p/'raw/src/script/node_data.rs').read_text();live=(w/'src/script/node_data.rs').read_text()
reg='#[cfg(test)]\nmod key_cache_fee_tests;\n';assert live.count(reg)==1;assert live.replace(reg,'',1)==raw
assert (p/'raw/src/script/dom_prototypes.rs').read_bytes()==(w/'src/script/dom_prototypes.rs').read_bytes()
original=raw[raw.index('    pub(super) fn node_data_function('):raw.index('    pub(super) fn node_data_function_with_keys(')]
old=(p/'before/src/script/node_data.rs').read_text();assert original==old[old.index('    pub(super) fn node_data_function('):old.index('    pub(super) fn install_node_data_members(')]
# Lexical comparison only for held tests. Raw/normal string tokens preserved;
# sort only the existing imports and normalize only optional trailing commas.
rx=re.compile(r'r(?P<h>\#*)".*?"(?P=h)|"(?:\\.|[^"\\])*"|//[^\n]*|\s+|[A-Za-z_][A-Za-z_0-9]*|[0-9][A-Za-z_0-9]*|[^\s]',re.S)
def tokens(s):
 imports=re.findall(r'^use [^\n]+;',s,re.M)
 s=re.sub(r'^use [^\n]+;\n','',s,flags=re.M)
 ts=[m.group() for m in rx.finditer(s) if not m.group().isspace() and not m.group().startswith('//')]
 ts=[v for i,v in enumerate(ts) if not(v==',' and i+1<len(ts) and ts[i+1] in [')',']','}'])]
 return sorted(imports),ts
formatted=[]
for rel in added:
 held=(t/'raw'/rel).read_text();actual=(w/rel).read_text();assert tokens(held)==tokens(actual),rel
 assert re.findall(r'#\[test\]\s*fn (\w+)',held)==re.findall(r'#\[test\]\s*fn (\w+)',actual)
 formatted.append({'path':rel,'held':b(t/'raw'/rel),'formatted':b(w/rel),'semantic_tokens_and_literals_equal':True})
for row in migrations:
 rel=row['path'];held=Path(row['raw']['path']).read_text();actual=(w/rel).read_text()
 if rel=='src/script/promises/install_tests.rs':assert re.sub(r'\s+','',held)==re.sub(r'\s+','',actual)
 else: assert held==actual,rel
# Explicitly keep the full JS oracle bytes unchanged, not whitespace-normalized.
rel='src/script/node_data/key_cache_tests.rs';extract=lambda s:re.findall(r'r#"(.*?)"#',s,re.S)
assert extract((t/'raw'/rel).read_text())==extract((w/rel).read_text())
for name in ['node-controls-msrv-1','parent-controls-baseline-1']:
 rec=json.loads((r/'validation'/f'{name}.json').read_text());assert sha(r/'validation'/rec['log'])==rec['sha256']
log=(r/'validation/node-controls-msrv-1.log').read_text();assert '37 passed; 0 failed; 0 ignored;' in log
assert 'NODE_DATA_BOOTSTRAP steps=133 allocated=1738688 objects=749 capacity=749 native=299 prototypes=25' in log
roster=json.loads((t/'notes.json').read_text())['roster']
for rel,names in roster.items():
 for name in names:assert f'::{name} ... ok' in log
assert len(re.findall(r'^test script::node_data::.* \.\.\. ok$',log,re.M))==37
review={'schema':'eris-final-source-review-v1','status':'clear_source_only','reviewer':'html_css','source_inventory':b(r/'source1.json'),'parent_inventory':b('/tmp/eris-promise-test262-1/source-2.json'),'inventory_inputs':1093,'all_live_hashes_match':True,'parent_comparison':{'added':added,'changed':changed,'removed':removed,'unchanged_parent_inputs':len(parent)-len(changed)},'production_hold':b(p/'source-ready.json'),'independent_production_peer':b(p/'script-review.json'),'tests_hold':b(t/'source-ready.json'),'independent_tests_peer':b(t/'script-review.json'),'composition':'Two held production paths byte-exact after removing sole private fee-module registration. Six exact held migration files, with Promise install_tests line wrap only. Two held new modules retain all semantic tokens and literal JS bytes; only rustfmt whitespace/trailing commas and fee-module import reorder differ. Original unselected factory remains byte-exact. All other1083 parent inputs unchanged.','new_module_bindings':formatted,'registration_roster':{'key_cache_tests':2,'key_cache_fee_tests':6,'old_node_groups_unchanged':29,'focused_total':37},'format_record':b(r/'root/format-receipt.json'),'format_preparation':'Root retained first allowlist and token-comparison snapshot rejections; neither was a project/test failure or a source mutation. Both final formatting diffs inspected.','observed_receipts':[b(r/'validation/node-controls-msrv-1.json'),b(r/'validation/node-controls-msrv-1.log'),b(r/'validation/parent-controls-baseline-1.json'),b(r/'validation/parent-controls-baseline-1.log')],'observed_focus':'37/0/0 on Rust1.88 default library; all8 new groups explicitly present. Raw remaining133, accounted heap1738688, objects/capacity749, native299/prototypes25. Parent had1 intended backing failure and1 public success; held expectations unchanged.','limits':'This is source composition and bounded focused-receipt review, not final full-suite/lint/browser/CI clearance. Peer did not execute project code.','findings':[],'project_execution':False,'live_edits':False}
(r/'root/final-source-review.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps(b(r/'root/final-source-review.json')))
