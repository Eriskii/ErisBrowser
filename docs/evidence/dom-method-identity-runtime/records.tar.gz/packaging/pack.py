#!/usr/bin/env python3
"""Data-only evidence packaging; exact root sequencing release is required.

No compiler, engine, replay or semantic validator is invoked. The only child
command is read-only git ls-tree for parent-plus-overlay reconstruction.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import subprocess
import tarfile

WORK = Path('/tmp/eris-dom-method-identity-runtime-1')
REPO = Path('/home/eriskii/Documents/Programming/Projects/ErisBrowser')
PARENT = 'af81786de5c339fe38ac7fc5567ab6bbb0eeb616'
OVERLAYS = {'src/script.rs', 'src/script/dom_bindings.rs',
    'src/script/dom_bindings/identity_tests.rs', 'src/script/machine/calls.rs',
    'tests/pipeline.rs', 'tests/worker.rs', 'tests/fixtures/dom-method-identity.html'}
ROLES = {'runtime', 'replays', 'validation', 'packer', 'documentation',
         'root_acceptance', 'gate_review'}
POPULATION = {'formal_profiles': 44, 'formal_cases': 19727, 'formal_controls': 4564,
              'existing_gates': 36, 'local_suites': 11, 'local_cases': 1756,
              'local_controls': 588, 'explicit_local_resource_expectations': 48}
MAX_FILE = 64 * 1024**2
MAX_TOTAL = 1024 * 1024**2
MAX_FILES = 4096


def require(value, message):
    if not value:
        raise ValueError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def name(value):
    p = PurePosixPath(value)
    require(p.parts and not p.is_absolute() and str(p) == value
            and all(x not in ('.', '..') for x in p.parts), 'unsafe member/name: ' + value)
    return value


def read_bound(row):
    p = Path(row['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink(), 'nonregular input: ' + str(p))
    require(0 <= row['bytes'] <= MAX_FILE and p.stat().st_size == row['bytes'], 'input size: ' + str(p))
    with p.open('rb') as f:
        raw = f.read(MAX_FILE + 1)
    require(len(raw) == row['bytes'] and digest(raw) == row['sha256'], 'input changed: ' + str(p))
    return raw


def pinned(path, sha):
    row = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha}
    return row, read_bound(row)


def binary_binding(row):
    p = Path(row['path'])
    require(p.is_absolute() and p.is_file() and not p.is_symlink(), 'binary path')
    require(0 < row['bytes'] <= 128 * 1024**2 and p.stat().st_size == row['bytes'], 'binary size')
    h, count = hashlib.sha256(), 0
    with p.open('rb') as f:
        while block := f.read(1024**2):
            count += len(block)
            require(count <= row['bytes'], 'growing binary')
            h.update(block)
    require(count == row['bytes'] and h.hexdigest() == row['sha256'], 'binary changed')


def external_data(specs):
    """Verify published index/container bindings and requested regular members."""
    result = {}
    for key, spec in specs.items():
        index = json.loads(read_bound(spec['index']))
        raw = read_bound(spec['archive'])
        require(index['archive']['sha256'] == digest(raw)
                and index['archive']['bytes'] == len(raw), 'external archive/index conflict')
        wanted = set(spec['members'])
        legacy = isinstance(index['payloads'], int)
        needed = wanted | ({'MANIFEST.json'} if legacy else set())
        captured = {}
        seen, total = set(), 0
        with tarfile.open(fileobj=io.BytesIO(raw), mode='r:*') as archive:
            for entry in archive:
                member = name(entry.name)
                require(entry.isfile() and member not in seen and len(seen) < MAX_FILES,
                        'external archive member type/count/duplicate')
                seen.add(member)
                require(0 <= entry.size <= MAX_FILE, 'external member size')
                total += entry.size
                require(total <= MAX_TOTAL, 'external archive total')
                if member in needed:
                    data = archive.extractfile(entry).read(MAX_FILE + 1)
                    require(len(data) == entry.size, 'external member length')
                    captured[member] = data
        require(wanted <= seen, 'external container missing member')
        if legacy:
            require('MANIFEST.json' in captured and digest(captured['MANIFEST.json'])
                    == index['manifest_sha256'], 'external manifest binding')
            listed = json.loads(captured['MANIFEST.json'])['files']
            require(len(listed) == index['payloads'], 'legacy payload count')
            entries = {row['path']: row for row in listed}
        else:
            listed = index['payloads']
            entries = {row['member']: row for row in listed}
        require(len(entries) == len(listed) and wanted <= set(entries), 'external member ledger')
        for member in wanted:
            data = captured[member]
            require(len(data) == entries[member]['bytes']
                    and digest(data) == entries[member]['sha256'], 'external member changed')
            result[(key, member)] = data
    return result


def check_tree(spec, records, raw):
    directory = Path(spec['directory'])
    require(directory.is_absolute() and directory.is_dir() and not directory.is_symlink(), 'result directory')
    actual = set()
    for p in directory.rglob('*'):
        require(not p.is_symlink(), 'result symlink')
        if p.is_file():
            actual.add(str(p.relative_to(directory)))
            require(len(actual) <= MAX_FILES, 'result count')
    require(actual == set(spec['files']), 'incomplete or extra result files')
    for relative, key in spec['files'].items():
        p = directory / name(relative)
        row = records[key]
        require(str(p) in row['origins'], 'result origin omitted')
        require(read_bound(dict(path=str(p), bytes=row['bytes'], sha256=row['sha256'])) == raw[key],
                'result differs from retained content')


def reconstruct(spec, records, raw, parent):
    def item(role):
        return json.loads(raw[spec['roles'][role]])
    required = {'inputs', 'verification_inputs', 'archive_inputs', 'literal_includes', 'provenance'}
    if spec['name'] == 'candidate2':
        required |= {'binaries', 'build_bindings', 'build_validation'}
    require(set(spec['roles']) == required, 'candidate role inventory')
    inputs, provenance = item('inputs'), item('provenance')
    require(provenance['parent'] == PARENT and inputs['input_sha256'] == spec['input_sha256'], 'source parent/digest')
    for role, key in [('inputs', 'inputs_sha256'), ('verification_inputs', 'verification_inputs_sha256')]:
        require(provenance[key] == digest(raw[spec['roles'][role]]), 'candidate provenance hash')
    inventory = item('archive_inputs')['files']
    expected = {name(row['path']): row for row in inventory}
    require(len(expected) == len(inventory) == provenance['archive_files'] == 421, 'source inventory count')
    production = {row['path']: row for row in inputs['files']}
    verification = {row['path']: row for row in item('verification_inputs')}
    require(set(expected) == set(production) | set(verification), 'source union differs')
    for rows in (production.values(), verification.values(), item('literal_includes')):
        for row in rows:
            require(row['path'] in expected and row['sha256'] == expected[row['path']]['sha256'], 'source subset differs')
    archive_raw = read_bound(spec['source_tar'])
    require(digest(archive_raw) == provenance['source_tar_sha256'], 'source tar provenance')
    require(set(spec['overlays']) == OVERLAYS, 'seven overlays required')
    seen, changed = set(), set()
    with tarfile.open(fileobj=io.BytesIO(archive_raw), mode='r:') as archive:
        for entry in archive:
            member = name(entry.name)
            require(entry.isfile() and member in expected and member not in seen, 'source archive member')
            require(0 <= entry.size <= 16 * 1024**2, 'source member size')
            data = archive.extractfile(entry).read(16 * 1024**2 + 1)
            require(len(data) == entry.size == expected[member]['bytes']
                    and digest(data) == expected[member]['sha256'], 'source member bytes')
            seen.add(member)
            oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
            if parent.get(member) != oid:
                changed.add(member)
                require(member in OVERLAYS and raw[spec['overlays'][member]] == data, 'unretained overlay')
    require(seen == set(expected) and changed == OVERLAYS, 'source reconstruction differs')
    if spec['name'] == 'candidate1':
        require(spec['build_status'] == 'full-default-test-regression-no-release'
                and spec['binaries'] == [], 'candidate1 history')
        directory = Path(spec['source_tar']['path']).parent
        require(not (directory / 'default-binaries.json').exists(), 'unexpected candidate1 binaries')
    else:
        binaries, build, validation = item('binaries'), item('build_bindings'), item('build_validation')
        require(set(binaries) == {'eris-js', 'eris-browser'} and build['binaries'] == binaries, 'binary inventory')
        require(build['all_source_inputs_unchanged'] is True
                and build['source_archive_sha256'] == digest(archive_raw)
                and build['archive_inventory_sha256'] == digest(raw[spec['roles']['archive_inputs']]), 'release source binding')
        require(validation['complete'] is True and validation['exit'] == 0
                and validation['failure'] is None and validation['postcheck_failure'] is None
                and validation['process']['leader_reaped'] is True, 'release build not completed')
        require({Path(row['path']).name for row in spec['binaries']} == set(binaries), 'binary records')
        for row in spec['binaries']:
            require(row['sha256'] == binaries[Path(row['path']).name], 'binary manifest hash')
            binary_binding(row)
    return expected


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--manifest', type=Path, required=True)
    ap.add_argument('--manifest-sha256', required=True)
    ap.add_argument('--authorization', type=Path, required=True)
    ap.add_argument('--authorization-sha256', required=True)
    ap.add_argument('--output', type=Path, required=True)
    ap.add_argument('--execute-packaging', action='store_true', required=True)
    args = ap.parse_args()
    manifest_row, manifest_raw = pinned(args.manifest, args.manifest_sha256)
    release_row, release_raw = pinned(args.authorization, args.authorization_sha256)
    manifest, release = json.loads(manifest_raw), json.loads(release_raw)
    self_row, self_raw = pinned(Path(__file__).resolve(), release['packer_sha256'])
    require(manifest['state'] == 'ready-for-packaging' and manifest['schema'] == 1
            and manifest['parent'] == PARENT and manifest['population'] == POPULATION, 'pending/wrong manifest')
    require(release['state'] == 'root-sequencing-release' and release['manifest_sha256'] == digest(manifest_raw), 'sequencing release')
    output = args.output
    require(output.is_absolute() and output.parent.resolve() == WORK
            and output.name.startswith('runtime-publication-package-')
            and not output.exists() and not output.is_symlink(), 'fresh scratch output required')
    external = external_data(manifest['external_archives'])
    historical = manifest['historical_nonpayload_bindings']
    require(len(historical) <= MAX_FILES, 'historical binding count')
    for row in historical:
        require(row['kind'] in ('executable', 'source_archive'), 'historical binding kind')
        if row['kind'] == 'executable':
            binary_binding(row)
        else:
            require(Path(row['path']).name == 'source.tar', 'historical archive name')
            read_bound(row)
    records, raw, total = {}, {}, 0
    require(0 < len(manifest['records']) <= MAX_FILES, 'record count')
    for row in manifest['records']:
        key = name(row['id'])
        require(key not in records and row['origins'] and len(row['origins']) <= MAX_FILES, 'record identity/origins')
        require(all(isinstance(p, str) and Path(p).is_absolute() for p in row['origins']), 'absolute origin paths')
        require(('input' in row) != ('external' in row), 'one content location required')
        data = (read_bound(row['input']) if 'input' in row else
                external[(row['external']['archive'], row['external']['member'])])
        require(len(data) == row['bytes'] and digest(data) == row['sha256'], 'record bytes')
        require(not data.startswith(b'\x7fELF') and all(Path(p).name != 'source.tar' for p in row['origins']), 'excluded binary/source archive')
        total += len(data)
        require(total <= MAX_TOTAL, 'aggregate referenced byte bound')
        records[key], raw[key] = row, data
    require(len(manifest['complete_trees']) == 2, 'two final result trees required')
    require({t['kind'] for t in manifest['complete_trees']} == {'formal', 'local'}, 'formal/local tree kinds')
    for tree in manifest['complete_trees']:
        require(tree['directory'] == str(WORK / (tree['kind'] + '-candidate-2')), 'result tree stage')
        check_tree(tree, records, raw)
    require(not (WORK / 'formal-candidate-1').exists() and not (WORK / 'local-candidate-1').exists(), 'unexpected candidate1 replay')
    parent = {}
    for line in subprocess.check_output(['git', 'ls-tree', '-r', '-z', PARENT], cwd=REPO).split(b'\0'):
        if line:
            meta, path = line.split(b'\t', 1)
            mode, kind, oid = meta.split()
            if kind == b'blob' and mode in (b'100644', b'100755'):
                parent[path.decode()] = oid.decode()
    candidates = manifest['candidates']
    require([c['name'] for c in candidates] == ['candidate1', 'candidate2'], 'two ordered histories')
    inventories = [reconstruct(c, records, raw, parent) for c in candidates]
    require(set(inventories[0]) == set(inventories[1]), 'candidate member-name delta')
    delta = sorted(p for p in inventories[0] if inventories[0][p] != inventories[1][p])
    require(delta == manifest['candidate_delta_paths'] and set(delta) <= OVERLAYS, 'unbound correction delta')
    require(manifest['correction_review'] in records, 'missing correction review')
    require(set(manifest['reviews']) == set(release['accepted_reviews']) == ROLES, 'review roles')
    for role, key in manifest['reviews'].items():
        require(key in records and records[key]['sha256'] == release['accepted_reviews'][role], 'unreleased review')
    attempts_key = manifest['attempt_inventory']
    require(attempts_key in records and records[attempts_key]['sha256'] == release['attempt_inventory_sha256'], 'attempt release')
    attempts = json.loads(raw[attempts_key])
    require(attempts['state'] == 'complete-and-reviewed' and attempts['attempts'], 'pending attempts')
    for attempt in attempts['attempts']:
        require(attempt['artifacts'] and all(k in records for k in attempt['artifacts']), 'attempt evidence missing')
    require(manifest['candidate_observations'] is not None and manifest['final_summary'] in records, 'pending observations')
    # One physical copy per new content hash; every logical/original path remains
    # in the manifest. Public external members are referenced, never copied.
    payloads = {}
    for key, row in records.items():
        if 'input' in row:
            payloads.setdefault('objects/' + row['sha256'], raw[key])
    for key, data in [('packaging/manifest.json', manifest_raw), ('packaging/release.json', release_raw), ('packaging/pack.py', self_raw)]:
        payloads[key] = data
    output.mkdir()
    archive_path = output / 'records.tar.gz'
    with archive_path.open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as archive:
                for member, data in sorted(payloads.items()):
                    info = tarfile.TarInfo(member)
                    info.size, info.mode, info.mtime = len(data), 0o644, 0
                    archive.addfile(info, io.BytesIO(data))
    # A changed input leaves an incomplete directory, never a completed index.
    for row in (manifest_row, release_row, self_row):
        read_bound(row)
    for row in records.values():
        if 'input' in row:
            read_bound(row['input'])
    for spec in manifest['external_archives'].values():
        read_bound(spec['index']); read_bound(spec['archive'])
    for row in historical:
        binary_binding(row) if row['kind'] == 'executable' else read_bound(row)
    for candidate in candidates:
        read_bound(candidate['source_tar'])
        for row in candidate['binaries']:
            binary_binding(row)
    for tree in manifest['complete_trees']:
        check_tree(tree, records, raw)
    archive_bytes = archive_path.read_bytes()
    index = {'schema': 1, 'parent': PARENT, 'scope': 'DOM method identity runtime evidence; bounded feature, not complete DOM/browser',
        'archive': {'path': archive_path.name, 'bytes': len(archive_bytes), 'sha256': digest(archive_bytes)},
        'payloads': [{'member': k, 'bytes': len(v), 'sha256': digest(v)} for k, v in sorted(payloads.items())],
        'records': [{**row, 'content_member': 'objects/' + row['sha256'] if 'input' in row else None} for row in records.values()],
        'population': POPULATION, 'candidates': candidates, 'candidate_delta_paths': delta,
        'candidate_observations': manifest['candidate_observations'], 'reviews': manifest['reviews'],
        'external_archives': manifest['external_archives'], 'complete_trees': manifest['complete_trees'],
        'historical_nonpayload_bindings': historical,
        'authority': {'manifest': manifest_row, 'release': release_row, 'packer': self_row},
        'omissions': 'No ELF, source.tar container, duplicate historical corpus or already-public BEFORE payloads. Source members reconstruct from parent plus seven overlays; original tar encoding is separately hash-bound.'}
    with (output / 'index.json').open('xb') as f:
        f.write(encoded(index))
    print(json.dumps({'complete': True, 'index_sha256': digest(encoded(index)),
                      'new_payloads': len(payloads), 'logical_records': len(records), 'archive': index['archive']}))


if __name__ == '__main__':
    main()
