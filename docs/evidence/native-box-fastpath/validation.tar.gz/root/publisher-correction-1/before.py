"""Root-only bounded publication of selected Native integer-box fast-path evidence."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import re
import subprocess
import sys
import tarfile

P = Path(__file__).resolve().parent.parent
W = P / 'worktree'
BASE = '4b19b8538689f94900c9375bfe0e6382251f3936'
D = W / 'docs/evidence/native-box-fastpath'
CAP = 64 * 1024 * 1024
TREES = {'plan', 'root', 'tests', 'gpu', 'docs', 'validation'}
VERIFIED = {}
REQUIRED = {'full_native', 'full_default', 'clippy_native_msrv', 'clippy_native_current',
            'clippy_default_current', 'format', 'probe_cpu', 'browser_build', 'browser_strip', 'reftests'}


def digest(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def local(name, root=P):
    path = Path(name)
    if not path.is_absolute():
        path = root / path
    assert path == path.resolve() and path.is_relative_to(root), path
    assert path.is_file() and not path.is_symlink(), path
    return path


def binding(path):
    result = {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}
    assert VERIFIED.setdefault(path, result) == result, path
    return result


def checked(spec, root=P):
    path = local(spec['path'], root)
    actual = binding(path)
    assert actual['bytes'] == spec['bytes'] and actual['sha256'] == spec['sha256'], path
    return path


def read(spec):
    return json.loads(checked(spec).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=W)


def totals(text):
    rows = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)
    return {'rows': len(rows), 'passed': sum(int(x[1]) for x in rows),
            'failed': sum(int(x[2]) for x in rows), 'ignored': sum(int(x[3]) for x in rows)}


def main():
    assert __debug__ and len(sys.argv) == 2, 'usage: python3 publish-evidence.py SELECTION.json; no -O'
    selected_path = local(sys.argv[1])
    binding(selected_path)
    s = json.loads(selected_path.read_text())
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    source_path = checked(s['source'])
    source = read(s['source'])
    assert re.fullmatch(r'compiled-source-\d+\.json', source_path.name)
    assert source['base'] == BASE
    inputs = source['source_sha256']
    assert len(inputs) == s['source_count'] and len(inputs) > 0
    for name, sha in inputs.items():
        assert digest(local(name, W)) == sha, name
    source_sha = digest(source_path)

    # Preserve every actual attempt; selected successes do not erase failed/partial runs.
    attempts = {}
    for path in sorted((P / 'validation').glob('*.json')):
        record = json.loads(path.read_text())
        if not {'command', 'exit', 'log', 'sha256'} <= record.keys():
            continue
        log = local(record['log'], path.parent)
        assert digest(log) == record['sha256'], path
        attempts[path.name] = {'receipt': binding(path), 'log': binding(log),
            'command': record['command'], 'exit': record['exit'],
            'rust': totals(log.read_text(errors='replace'))}

    def attempt(spec):
        path = checked(spec)
        assert path.parent == P / 'validation'
        return attempts[path.name]

    roles = {}
    for item in s['checks']:
        assert item['role'] not in roles
        actual = attempt(item['receipt'])
        assert actual['command'] == item['command'] and actual['exit'] == item['exit']
        if 'rust' in item:
            assert actual['rust'] == item['rust']
        if item.get('final'):
            assert actual['exit'] == 0 and item['source_sha256'] == source_sha
        roles[item['role']] = {**actual, 'final': item.get('final', False)}
    assert REQUIRED <= roles.keys() and all(roles[k]['final'] for k in REQUIRED)
    for role, version, features in [('full_native', '1.88.0', ['--features', 'vulkan-raster']),
                                    ('full_default', '1.98.0', [])]:
        assert roles[role]['command'] == ['cargo', '+' + version, 'test', '--locked', '--offline',
            '--manifest-path', 'Cargo.toml', *features, '--', '--include-ignored', '--test-threads=4']
        rust = roles[role]['rust']
        assert rust['rows'] > 0 and rust['passed'] > 0 and rust['failed'] == rust['ignored'] == 0
    for role, version, features in [('clippy_native_msrv', '1.88.0', ['--features', 'vulkan-raster']),
                                    ('clippy_native_current', '1.98.0', ['--features', 'vulkan-raster']),
                                    ('clippy_default_current', '1.98.0', [])]:
        assert roles[role]['command'] == ['cargo', '+' + version, 'clippy', '--locked', '--offline',
            '--manifest-path', 'Cargo.toml', *features, '--all-targets', '--', '-D', 'warnings']
    assert roles['format']['command'][-6:] == ['cargo', '+1.98.0', 'fmt', '--all', '--', '--check']
    probe = roles['probe_cpu']
    assert probe['command'][:3] in [['cargo', '+1.88.0', 'test'], ['cargo', '+1.98.0', 'test']]
    assert ['--manifest-path', 'tools/vulkan-raster-probe/Cargo.toml'] == probe['command'][5:7]
    assert probe['command'][3:5] == ['--locked', '--offline']
    assert ['--features', 'browser-bridge'] == probe['command'][7:9]
    assert probe['rust']['passed'] > 0 and probe['rust']['failed'] == probe['rust']['ignored'] == 0

    # Authenticate immutable artifacts without adding executable payloads to the archive.
    browser = read(s['browser'])
    binary = checked(browser)
    assert browser['source'] == source_path.name and browser['source_sha256'] == source_sha
    assert local(browser['build_receipt']) == Path(roles['browser_build']['receipt']['path'])
    assert roles['browser_build']['command'] == ['cargo', '+1.88.0', 'build', '--locked', '--offline',
        '--manifest-path', 'Cargo.toml', '--features', 'vulkan-raster', '--bin', 'eris-browser']
    assert roles['browser_strip']['command'] in [['strip', str(binary)], ['strip', '--strip-debug', str(binary)]]
    # Both checker groups and browser executions bind this exact final snapshot.
    # The historical ten-case protocol stays unchanged; the new checker is separate.
    protocols = {
        'native_box': ('eris-vulkan-native-box-check', [
            ('ellipse-opaque-blue', 4, 2), ('correlated-fractional-ring', 2, 2),
            ('used-truncated-left-ellipse', 1, 4),
            ('fixed-fractional-mask-and-document-clip', 4, 2),
            ('source-alpha-over-yellow', 4, 2), ('nested-half-opacity-blue', 4, 2),
            ('identical-fractional-cutout', 2, 2), ('fractional-caller-clip', 4, 2),
            ('two-mask-absolute-seam', 1280, 2), ('page-translucent-rounded-ring', 12, 12)],
            20, 22048, 'color_box_masks=true', 'custom_glyph_shader=true'),
        'box_rect': ('eris-vulkan-box-rect-check', [
            ('integer-box-full-viewport', 1280, 1024),
            ('integer-box-fractional-clip', 5, 3),
            ('integer-box-zero-axis-alpha-order', 4, 2),
            ('integer-box-document-fixed-restoration', 5, 3),
            ('integer-box-nested-alpha-opacity', 4, 2)],
            10, 10486128, 'box_rectangles=true zero_masks=true', 'custom_rectangle_shader=true'),
    }
    assert set(s['gpu']) == set(protocols)
    gpu_groups, common_inventory = {}, None
    for group, (bin_name, cases, frames, byte_count, pass_flags, kernel) in protocols.items():
        choice = s['gpu'][group]
        gpu = read(choice['binary'])
        gpu_binary = checked(gpu)
        assert gpu['source'] == source_path.name and gpu['source_sha256'] == source_sha
        gpu_build = attempt(choice['build'])
        assert local(gpu['build_receipt']) == checked(choice['build']) and gpu_build['exit'] == 0
        prefix = ['cargo', '+1.88.0', 'build', '--locked', '--offline', '--manifest-path',
                  'tools/vulkan-raster-probe/Cargo.toml', '--features', 'browser-bridge']
        assert gpu_build['command'][:len(prefix)] == prefix
        bins = gpu_build['command'][len(prefix):]
        assert len(bins) in {2, 4} and all(bins[i] == '--bin' for i in range(0, len(bins), 2))
        assert len(set(bins[1::2])) == len(bins) // 2 and bin_name in bins[1::2]
        assert set(bins[1::2]) <= {p[0] for p in protocols.values()}
        assert gpu.get('strip') == 'none' and gpu['unstripped_sha256'] == gpu['sha256']
        expected_passes = [(name, fmt, width * height * 4)
            for name,width,height in cases for fmt in ['Bgra8Unorm', 'Rgba8Unorm']]
        assert len(expected_passes) == frames and sum(row[2] for row in expected_passes) == byte_count
        listing = attempt(choice['list'])
        prefix = ['env', choice['loader_environment'], str(gpu_binary)]
        assert choice['loader_environment'].startswith('LD_LIBRARY_PATH=')
        assert listing['exit'] == 0 and listing['command'] == prefix + ['--list']
        listing_text = Path(listing['log']['path']).read_text()
        inventory = re.findall(r'^ADAPTER (\d+) (.+)$', listing_text, re.M)
        assert len(inventory) == 3 and [int(i) for i,_ in inventory] == [0, 1, 2]
        assert all('backend=Vulkan ' in details for _, details in inventory)
        assert not re.search(r'^(PASS|COMPLETE|FAIL)\b', listing_text, re.M)
        if common_inventory is None:
            common_inventory = inventory
        assert inventory == common_inventory
        adapters = []
        assert len(choice['adapters']) == 3 and {v['index'] for v in choice['adapters']} == {0, 1, 2}
        pattern = (r'^PASS (\S+) format=(Bgra8Unorm|Rgba8Unorm) draws=(\d+) compared_bytes=(\d+) '
            r'exact=true reference=literal canvas=true packed_native=true ' + re.escape(pass_flags) + '$')
        for item in choice['adapters']:
            actual = attempt(item['receipt'])
            assert actual['exit'] == 0 and actual['command'] == prefix + ['--adapter', str(item['index'])]
            text = Path(actual['log']['path']).read_text()
            assert re.findall(r'^ADAPTER (\d+) (.+)$', text, re.M) == inventory
            rows = re.findall(pattern, text, re.M)
            assert [(name, fmt, int(size)) for name,fmt,draws,size in rows] == expected_passes
            assert all(int(draws) > 0 for _,_,draws,_ in rows)
            assert len(re.findall(r'^PASS\b', text, re.M)) == frames
            assert sum(int(row[3]) for row in rows) == byte_count
            completion_flags = pass_flags.split(' ')[0]
            completion = (f'COMPLETE adapter={item["index"]} fixtures={len(cases)} frames={frames} '
                f'compared_bytes={byte_count} exact=true {completion_flags} {kernel} '
                'offscreen=true acquired_surface=false')
            assert re.findall(r'^COMPLETE.*$', text, re.M) == [completion]
            assert not re.search(r'^FAIL\b', text, re.M)
            adapters.append({'index': item['index'], 'receipt': actual['receipt'], 'log': actual['log'],
                'frames': frames, 'compared_bytes': byte_count, 'adapter': dict(inventory)[str(item['index'])]})
        gpu_groups[group] = {'binary': gpu, 'build': gpu_build, 'list': listing,
            'adapters': adapters, 'total_frames': 3 * frames, 'total_compared_bytes': 3 * byte_count}

    # This milestone changes no reftest definition, source or asset.
    parent_refs = git('ls-tree', '-r', '--name-only', BASE, '--', 'tests/reftests').decode().splitlines()
    for name in parent_refs:
        assert local(name, W).read_bytes() == git('show', BASE + ':' + name), name
    assert not git('ls-files', '--others', '--exclude-standard', '--', 'tests/reftests').strip()
    manifest = json.loads(local('tests/reftests/manifest.json', W).read_text())
    names = {row['name'] for row in manifest['cases']}
    assert len(names) == len(manifest['cases']) == 90
    report_path = checked(s['report'])
    report = read(s['report'])
    assert (report['passed'], report['failed'], report['total']) == (90, 0, 90)
    assert len(report['cases']) == 90 and {c['name'] for c in report['cases']} == names
    assert all(c['status'] == 'pass' and c['different_pixels'] == c['maximum_channel_error'] == 0 for c in report['cases'])
    assert report['binary'] == str(binary)
    assert roles['reftests']['command'] == ['python3', 'tools/reftest.py', '--binary', str(binary), '--output-dir', str(report_path.parent)]

    pngs = {local(c[field]) for c in report['cases'] for field in ['test_image', 'reference_image']}
    assert len(pngs) == 180
    for path in pngs:
        assert path.parent == report_path.parent and path.suffix == '.png'
        assert path.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        binding(path)

    docs = read(s['docs'])['published_files']
    assert docs and len({row['path'] for row in docs}) == len(docs)
    doc_review = read(s['documentation_review'])
    assert doc_review['status'] == 'clear'
    coverage = {r['relative']: r['sha256'] for r in doc_review['published_files']}
    assert len(coverage) == len(docs)
    for row in docs:
        assert digest(checked(row['draft'])) == digest(local(row['path'], W)) == coverage[row['path']]
    reviews = [read(spec) for spec in s['reviews']]
    assert reviews and all(review['status'] == 'clear' for review in reviews)
    published = s['published_files']
    assert len({row['path'] for row in published}) == len(published)
    for row in published:
        checked(row, W)
    changed = set(git('diff', '--name-only', '-z', 'HEAD').decode().split('\0')) | set(git('ls-files', '--others', '--exclude-standard', '-z').decode().split('\0'))
    changed.discard('')
    assert changed == {row['path'] for row in published}, sorted(changed ^ {row['path'] for row in published})
    assert {row['path'] for row in docs} == {name for name in changed if name.endswith('.md')}

    # Explicit bounded owned trees only: no traversal of V/worktree or V itself.
    files = {selected_path, source_path, checked(s['browser']), report_path,
        checked(s['docs']), checked(s['documentation_review']), Path(__file__).resolve(),
        P / 'root/publication-design.json'}
    files.update(checked(choice['binary']) for choice in s['gpu'].values())
    files.update(pngs)
    files.update(checked(v) for v in s['reviews'])
    files.update(local(name, W) for name in inputs)
    files.update(checked(v, W) for v in published)
    reports = set(s.get('report_directories', [])) | {report_path.parent.name}
    assert all(re.fullmatch(r'reftests-[A-Za-z0-9_-]+', name) for name in reports)
    for dirname in TREES | reports:
        root = P / dirname
        assert root.is_dir() and root == root.resolve() and root.parent == P
        for path in root.rglob('*'):
            assert not path.is_symlink(), path
            if path.is_file():
                files.add(path)
    files.update(P.glob('compiled-source-*.json'))
    files.update(checked(v) for v in s.get('archive_files', []))
    assert sum(path.stat().st_size for path in files) < CAP
    contents = {}
    for path in sorted(files):
        path = local(path)
        name = str(path.relative_to(P))
        assert not any(part in {'target', '.git', 'archive', 'archives', '__pycache__'} or part.startswith('target-') for part in Path(name).parts), name
        assert path.suffix not in {'.gz', '.zip', '.tar', '.xz', '.bz2', '.7z', '.zst', '.rlib', '.a', '.so', '.dll', '.dylib', '.pyc'}, name
        with path.open('rb') as stream:
            assert stream.read(4) != b'\x7fELF', name
        contents[name] = path.read_bytes()
    assert sum(map(len, contents.values())) < CAP
    for path, expected in VERIFIED.items():
        assert path.stat().st_size == expected['bytes'] and digest(path) == expected['sha256'], path
        captured = contents.get(str(path.relative_to(P)))
        if captured is not None:
            assert len(captured) == expected['bytes'] and hashlib.sha256(captured).hexdigest() == expected['sha256'], path
    for name, sha in inputs.items():
        assert digest(local(name, W)) == sha and hashlib.sha256(contents['worktree/' + name]).hexdigest() == sha
    for row in published:
        assert hashlib.sha256(contents['worktree/' + row['path']]).hexdigest() == row['sha256']
    index = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name,data in sorted(contents.items())]
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode='w', format=tarfile.PAX_FORMAT) as archive:
        for name,data in sorted(contents.items()):
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            archive.addfile(info, io.BytesIO(data))
    assert raw.tell() < CAP
    compressed = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
    assert len(compressed) < CAP and D == D.resolve()
    archive_path, summary_path = D / 'validation.tar.gz', D / 'summary.json'
    assert not archive_path.exists() and not summary_path.exists()
    D.mkdir(parents=True, exist_ok=True)
    with archive_path.open('xb') as stream:
        stream.write(compressed)
    assert archive_path.read_bytes() == compressed
    with tarfile.open(archive_path, 'r:gz') as archive:
        assert [m.name for m in archive.getmembers()] == sorted(contents)
        for member in archive.getmembers():
            assert member.isfile() and archive.extractfile(member).read() == contents[member.name]
    summary = {'base': BASE,
        'scope': 'Native integer square Color boxes use existing rectangle kernels; other Color boxes retain coverage masks; image/gradient decorations retain fallback.',
        'source': binding(source_path), 'source_count': len(inputs), 'checks': attempts,
        'selected_roles': roles, 'browser': browser, 'reftests': s['report'], 'gpu_groups': gpu_groups,
        'gpu_totals': {'adapters': 3, 'groups': 2, 'frames': 90, 'compared_bytes': 31524528},
        'documentation_review': s['documentation_review'], 'reviews': s['reviews'],
        'published_bindings': published, 'selection': binding(selected_path),
        'archive': {'path': 'validation.tar.gz', 'bytes': len(compressed), 'sha256': digest(archive_path), 'members': len(index)},
        'archive_inputs': index, 'limits': ['Browser, both checker binaries and final checks bind the same selected source snapshot.',
            'Offscreen comparisons do not establish acquired-surface behavior or performance.',
            'Unsuccessful attempts retain their original exit codes and partial totals.']}
    with summary_path.open('x') as stream:
        json.dump(summary, stream, indent=2)
        stream.write('\n')
    assert json.loads(summary_path.read_text()) == summary
    print(json.dumps({'summary_sha256': digest(summary_path), 'archive': summary['archive']}, indent=2))


if __name__ == '__main__':
    main()
