# Existing fill tests: proposed narrow migrations

The source held in `context/src/script/typed_array/fill/tests.rs` contains twelve groups. Keep every existing JavaScript body, input value, whole-byte literal, receiver/metadata identity assertion and callback result. Do not replace the literal `encoded()` or `prefix_bytes()` oracle with the codec under test. This document proposes changes only; no worktree tests have been edited.

The first nine semantic groups stay byte-identical. They cover all ten kinds; integer, clamp and floating values; ranges; ordered conversions; initial invalidity; unconditional final checks; tracking shrink/growth; fixed recovery; and saved identity/record growth.

For the tenth group, `literal_body_fees_prepay_complete_scalars_and_preserve_only_finished_prefixes`, replace the old single per-element tariff table with two independently stated literal tables:

| Kinds | Nonempty preparation (8 + C) | Reached scalar (13 + width) |
| --- | ---: | ---: |
| Int8 / Uint8 | 58 | 14 |
| Uint8Clamped | 74 | 14 |
| Int16 / Uint16 / Float16 | 60 | 15 |
| Int32 / Uint32 / Float32 | 64 | 17 |
| Float64 | 72 | 21 |

`prelude` remains exactly 58/62. For a requested three-element fill, `ready = prelude + preparation`; complete cost becomes `ready + 3*per`. Retain cuts 0, prelude-1 and prelude. Add setup exact/one-short at prelude+7/+8 and encoding exact/one-short at ready-1/ready. Add the Uint8Clamped internal cut after its separate16-work admission. Retain per-element exact/one-short coverage at ready+j*per for j=1,2,3, and add reached offset and writer cuts where useful.

Before ready, completed scalars are zero. At or above ready, use `min(3, (allowance-ready)/per)`. This formula derives from each unchanged `buffer_view_write` prepaying its whole scalar before mutation. The three-element success point is exactly ready+3*per. All earlier listed cuts fail with zero remaining work and unchanged allocation, while preserving only their completed scalar prefixes. Equal-value writes still pay the complete preparation plus all three per-element fees.

Keep the existing two valid-empty cuts as an explicitly separate unchanged block: 58 for omitted/undefined end and62 for defined end, allocated=MAX_HEAP, same receiver, zero work remaining and zero new allocation. These calls must not pay preparation or encoding. Preserve their arguments and assertions exactly; add one-short empty cases rather than changing the successful endpoints.

In the eleventh saved-call group, retain the genuine Runtime.call measurement followed by exact/one-short replay,47-byte name-copy heap checks, original bag identity, counts and whole-byte expectations. Change only the source-derived lower-bound assertion from `58 + 3*old_element` to `58 + preparation + 3*new_element`. The measured whole-call endpoint remains distinct from the private body formula; no test should compute its expected bytes from the implementation. At work-1, exactly two of the three requested scalars remain written because the unchanged final byte copy is still the last charged operation.

The twelfth callback/resource group needs no semantic or expected-byte change: it measures the complete call, replays work-1 and verifies that the first fill scalar remains while the second is untouched and the callback's later element mutation survives. Terminal callback work/heap exhaustion, catch/finally suppression and guard cleanup remain unchanged. Retain its source verbatim unless an independently reviewed new implementation requires a demonstrable API-only adaptation.

Add focused hoisting-specific groups separately: repeated special-value bytes for every float width and Uint8Clamp ties; nonzero aligned view offsets with untouched prefix/suffix bytes; valid empty range with a value that would require codec work; and callback-induced ArrayBuffer/TypedArray record growth before final validation. Existing direct scalar-writer/DataView tests and their old tariffs remain untouched.

No measured value is supplied as an expected result here. These rows follow only from the proposed setup8, unchanged codec/clamp tariffs, unchanged offset4, unchanged loop8 and unchanged buffer writer1+width. If concrete implementation differs, revise the source ledger and obtain review before root executes endpoint migrations.
