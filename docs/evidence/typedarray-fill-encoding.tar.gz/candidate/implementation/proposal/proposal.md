# Fill scalar preparation and final-witness reuse

The smallest useful next change is confined to `typed_array/fill.rs`: retain the final `Live` returned after every conversion, prepare one encoded scalar for a nonempty range, and call the existing checked offset and ArrayBuffer writer for each element. Keep `typed_array_write_number`, the codec, ArrayBuffer APIs, metadata, quotas and all other operations unchanged. This removes repeated work that the present loop actually performs; it does not reduce a tariff for work still performed.

This is a source-only proposal against the context copies in `source-bindings.json`. No implementation, compiler, test, adapter, importer, profiling or renderer was run for it. The current root report is retained unchanged: 22 passed, 32 resource, 50 excluded and 52 healthy controls. No outcome for the proposed change is predicted.

## Semantic and lifetime boundary

The current [ECMA fill algorithm](https://tc39.es/ecma262/multipage/indexed-collections.html#sec-%typedarray%.prototype.fill), read 2026-10-07, validates first, converts value/start/end in order against the captured length, validates again even for an empty range, clips the end to the new length, then performs element stores. The second validation must remain after all callbacks. Nothing in the store loop calls author code. These facts permit reuse of a final witness in this engine's admitted nonshared-buffer domain.

Replace only the final `typed_array_length(record)` with `typed_array_live(record)?.ok_or_else(...)`, retaining the identical TypeError text and 13-work validation path. Retain the resulting copied `Live { buffer, offset, length }`, not a Rust reference into either record table. The captured start and end still derive from the original length; clip only the end against `live.length`. A fixed view can recover during a later conversion; a tracking view can shrink to a partial final element; a detached or finally OOB view must throw even if no store is requested.

After the existing final range debit and clamp, return the original receiver if the range is empty. For a nonempty range, admit a new fixed 8-work setup, select width/codec, perform the existing 16-work Uint8Clamped conversion if needed, and pay the unchanged codec work before encoding once. Retain the local `[u8; 8]` scratch. Each iteration keeps its existing 8-work loop debit, calls the unchanged 4-work `typed_array_offset(live, kind, index)`, then calls unchanged `buffer_view_write(live.buffer, offset, &bytes[..width])` and increments the index.

The setup envelope is explicit: two units for retaining/addressing the final witness and width, two for codec and clamp-kind selection, two for the encoded-scalar binding/lifetime, and two for the source byte-slice binding/lifetime. This is a conservative logical charge, not a machine-instruction count. The existing codec charge still pays every bit/rounding/scratch operation once. The body must place the setup debit before those new bindings, and codec/clamp admission before their operations.

`Live` and `BufferId` are copied values. All author callbacks and possible record-vector growth precede the final witness; records are append-only and backed by nonshared buffers. The remaining operations are `work`, checked integer arithmetic, pure scalar encoding and synchronous byte writes. They cannot resize/detach a backing buffer or call JavaScript. No borrowed backing slice may span `Runtime.work`; `buffer_view_write` already takes its destination borrow only after admission. Keep that API's defensive attached-length/range checks and its unchanged byte-copy tariff. No generic prepaid-write capability or exposed buffer-table accessor is needed.

Using the same codec with the same Number, element kind and little-endian flag produces identical bytes every time. This includes canonical NaNs, signed zero, direct binary64-to-Float16 rounding, integer wrapping and Uint8Clamped ties. Do not substitute a Float32 intermediary, compare destination bytes, or skip equal-value stores.

## Conservative work and storage ledger

Let `w` be the element width, `C = 48 + 2*w + clamp`, where `clamp` is 16 for Uint8Clamped and zero otherwise. Let `B` be the existing prefix: 58 work with omitted/undefined end, or 62 with a defined end, plus the exact existing conversion work `X`. All initial-brand/native dispatch charges remain outside and unchanged.

| Row | Current fill | Proposed fill |
| --- | ---: | ---: |
| Initial validation and all conversions/final validation | B | B |
| Nonempty scalar setup/encoding | 0 | 8 + C |
| Reached element loop | 8 | 8 |
| Repeated TypedArray live witness | 13 | 0 |
| Checked element byte offset | 4 | 4 |
| Repeated scalar conversion/encoding | C | 0 |
| Unchanged buffer writer and full byte copy | 1 + w | 1 + w |

For zero stores, the exact existing B remains. For `n > 0`, current body work is `B + n*(26+w+C)`; proposed body work is `B + 8+C + n*(13+w)`. Removed work is `13*n + (n-1)*C - 8`. One-element fill therefore removes 5 real net work units; larger fills additionally remove repeated encoding. No new heap allocation, state slot, object/native metadata or machine-frame variant is introduced. Scratch remains a fixed local byte array; retaining Live does not put it in Runtime/Frame storage. Actual generated native stack size is not measured here.

| Kind family | C | Old per element | New per element after preparation |
| --- | ---: | ---: | ---: |
| Int8 / Uint8 | 50 | 77 | 14 |
| Uint8Clamped | 66 | 93 | 14 |
| Int16 / Uint16 / Float16 | 52 | 80 | 15 |
| Int32 / Uint32 / Float32 | 56 | 86 | 17 |
| Float64 | 64 | 98 | 21 |

Every reached element is still entirely prepaid before its first byte changes. A setup/codec refusal writes nothing. A later loop, offset or writer refusal leaves the completed scalar prefix and no part of the next scalar. Do not prepay the whole range or replace the loop with an all-or-nothing bulk copy. Same-budget prefixes naturally change when actual work is removed; the preserved contract is full-scalar prefix admission under the new source-derived tariff, not the previous numeric cut positions. Retain old endpoint evidence and explain each migration arithmetically before execution.

## What the 32 resource rows establish

`resource-analysis.json` binds all 32 actual runtime instruction-limit observations and all 16 unchanged original bodies. It independently derives complete-path store counts and prospective work removal. These are hypothetical completed-source-path totals, not consumed-work measurements or stop locations.

Six bodies, twelve modes, throw during value/start/end conversion and never reach a fill store: `fill-values-symbol-throws`, `return-abrupt-from-set-value`, both `return-abrupt-from-start` variants and both `return-abrupt-from-end` variants. This change cannot remove any work on those fill paths. Their constructor factories, call/bind scaffolding and exception assertions remain material.

The other ten bodies use one or more real stores. With all ten Number kinds available, the original helper normally runs ten constructors times eight factories: passthrough, Array, array-like, iterable, ordinary buffer, resizable buffer, grown buffer and shrunk buffer. Immutable factories are absent/excluded. The NaN body instead runs three float kinds times eight factories times nine NaNs. The conversion-matrix helper explicitly selects only passthrough and applies 56 inputs to ten kinds.

The clearest target is `return-this.js`: its nonempty call fills 42 elements for each constructor/factory. Just the existing complete-path scalar loop is 283,248 work; the proposed setup plus loop is 58,496, a source-derived difference of 224,752. This proves substantial removable repeated work on the complete path, not that the case will pass: helper construction and assertions still run and the actual exhausted instruction is unrecorded. The primitive grown/shrunk factories alone perform 2*42*29 = 2,436 indexed byte-copy iterations across the ten widths. They also fall through into full ordinary-buffer construction after their initial primitive branch.

Smaller opportunities are correspondingly limited: the one-element, 560-call conversion matrix removes only 2,800 work, while conversion-once removes 5,872 over its complete 80 two-element fills. In particular, do not infer that encoding hoisting repairs constructor/helper overhead or all resource cases. Preserve every original body/helper, policy exclusion and resource observation.

## Focused regression obligations before integration

1. Keep the existing twelve fill semantic groups and all ten independent whole-byte codec oracles. Add two-or-more equal-value stores per width and a multi-element special-value matrix (Uint8Clamp ties, wrapped integers, signed zero, NaN and Float16 midpoint/subnormal values) so one-time encoding cannot change later elements.
2. Keep initial-invalid rejection before hooks, value/start/end order, later callback markers after intermediate invalidity, fixed shrink/recovery, tracking shrink/partial final element, growth clipping and final-invalid empty-range TypeError. Include callbacks growing both buffer and TypedArray record tables before the retained final witness.
3. Derive direct-body exact work cuts at setup, clamp/codec, each loop, offset, writer tick and last byte debit. Inspect complete backing bytes through the existing test-only metered read helper; verify exactly the admitted prefix and untouched bytes outside the view. Empty calls retain their exact old fees and never encode.
4. Preserve saved-native full-call name-copy/heap cuts and guard cleanup, zero body allocation and callback effects on later resource refusal. Keep direct `typed_array_write_number` and DataView writer tariffs/tests unchanged.
5. Root reruns the original 104-mode fill profile, the two recovered original lastIndexOf cases, all healthy controls and relevant prior profiles at unchanged quotas. Compare complete observations; retain any continued resource rows without treating them as semantic failures or silently authorizing baselines.

The recommended next implementation is this fill-only local change. Removing ArrayBuffer range checks or introducing a long-lived write capability is a separate, unnecessary expansion for this increment.
