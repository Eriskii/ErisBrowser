# Encode a TypedArray fill value once

Number TypedArray `fill` now prepares one encoded scalar and reuses it for the
selected elements. The previous loop repeated scalar encoding and TypedArray
validation for every write. This change is confined to `typed_array/fill.rs`;
the shared scalar codec, ordinary indexed writer, ArrayBuffer writer, metadata
and runtime limits are unchanged.

Initial validation and value/start/end conversion keep their order. After the
last conversion, the method obtains a fresh copied buffer handle, byte offset
and view length. All author callbacks have completed before it uses this
snapshot. The remaining loop cannot resize or detach the admitted nonshared
buffer. It still checks every byte offset and calls the existing checked
ArrayBuffer writer, which admits the complete scalar copy before changing any
bytes. A resource stop can leave completed elements; it cannot leave a partial
scalar. Earlier callback effects remain observable.

The same codec preserves integer wrapping, clamped ties, signed zero, canonical
NaNs and direct Float16 rounding. Empty ranges still perform conversions and
final validation, then return without preparing a scalar.

## Work accounting

For a nonempty fill with `n` elements of byte width `w`, let `C` be the unchanged
codec charge: `48 + 2*w`, plus 16 for Uint8Clamped. Let `B` be the existing
validation/conversion prefix: 58 for omitted or undefined end, or 62 for a
defined end, plus argument-conversion work.

| Body | Previous charge | Current charge |
| --- | ---: | ---: |
| Empty range | B | B |
| Nonempty range | B + n × (26 + w + C) | B + 8 + C + n × (13 + w) |

The new eight-unit preparation charge pays for fixed witness, width, codec and
encoded-slice setup. Each scalar retains loop, checked-offset and full-copy
charges. The body allocates no runtime heap storage. Numeric resource cut
positions change because repeated work has been removed; the tests retain
independent byte-prefix expectations and exact/one-short admission checks.

## Validation and measurements

ROOT_TO_FILL_AFTER_EXECUTION

The benchmark uses the public Rust Runtime API with identical harness source
and release settings for both engine versions. It measures complete JavaScript
executions, including parsing, method dispatch, fill and identity/endpoint
checks. Setup, warmup and full-element verification are outside the timers.
Every timed call changes the array value, and all elements are verified before
accepting the sample. Resource stops or incorrect results fail the run.

Local host timings do not establish Chromium parity or overall browser speed.
The full web-compatibility, security and performance requirements remain open.
