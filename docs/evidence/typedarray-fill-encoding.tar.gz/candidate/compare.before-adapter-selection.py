"""Compare complete inert observations from the published and candidate engines."""
from collections import Counter
from pathlib import Path
import hashlib
import json

G = Path(__file__).resolve().parent
F = Path('/tmp/eris-typedarray-fill-1')
inputs = {}
errors = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def read(path):
    data = path.read_bytes()
    inputs[str(path)] = {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}
    return json.loads(data)


def row_hash(rows):
    return sha(json.dumps(rows, sort_keys=True, separators=(',', ':')).encode())


before_adapter = read(F / 'candidate-adapter-1.json')
after_adapter = read(G / 'candidate-adapter-1.json')
for root, adapter in [(F, before_adapter), (G, after_adapter)]:
    binary = root / adapter['binary']
    assert sha(binary.read_bytes()) == adapter['sha256']
    source_path = root / adapter['source_binding']
    source = read(source_path)
    assert sha(source_path.read_bytes()) == adapter['source_binding_sha256']
    for name, digest in source['source_sha256'].items():
        assert sha((root / 'worktree' / name).read_bytes()) == digest, name

plan = read(G / 'regression-plan.json')
names = ['upstream-1.json', 'search-1.json', 'foundation-1.json',
         'views-1.json', 'local-1.json']
names += ['regressions-candidate-1/' + p['profile'] + '.json' for p in plan['profiles']]
comparisons = []
for name in names:
    before = read(F / name)
    after = read(G / name)
    assert before['binary_sha256'] == before_adapter['sha256'], name
    assert after['binary_sha256'] == after_adapter['sha256'], name
    local = name == 'local-1.json'
    policy_keys = ['matrix_sha256', 'schema', 'scope'] if local else [
        'suite', 'full_test262_conformance', 'repository', 'revision',
        'corpus_manifest_sha256', 'runner_policy', 'runner_policy_sha256',
        'source_files', 'source_tests', 'negative_source_tests', 'fixture_files', 'mode_cases']
    for key in policy_keys:
        if before[key] != after[key]:
            errors.append([name, 'policy or population changed', key])
    b_rows, a_rows = before['cases'], after['cases']
    assert len({r['id'] for r in b_rows}) == len(b_rows)
    assert [r['id'] for r in b_rows] == [r['id'] for r in a_rows], name
    if not local:
        for report in [before, after]:
            assert dict(Counter(r['status'] for r in report['cases'])) == report['counts']
            assert report['mode_cases'] == len(report['cases'])
            assert report['harness_preflight_passed']
            assert all(r['verified'] for r in report['harness_preflight'])
    else:
        assert all(r['matches_expectation'] for r in a_rows)
        assert all(r['verified'] for r in after['controls'])
        assert before['summary'] == after['summary']
        assert before['binding_failures'] == after['binding_failures'] == []
    changes, losses, transitions = [], [], Counter()
    for b, a in zip(b_rows, a_rows):
        for key in ['id', 'file', 'mode', 'case_sha256', 'source_sha256', 'expected_negative']:
            if b[key] != a[key]:
                errors.append([name, b['id'], 'case identity changed', key])
        transitions[b['status'] + ' -> ' + a['status']] += 1
        if b['status'] == 'passed' and a['status'] != 'passed':
            losses.append(a['id'])
        if b != a:
            changes.append({'id': a['id'], 'before': b['status'], 'after': a['status'],
                            'changed_fields': sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k)),
                            'before_sha256': row_hash(b), 'after_sha256': row_hash(a)})
    if losses:
        errors.append([name, 'prior pass losses', losses])
    ck = 'controls' if local else 'harness_preflight'
    b_controls, a_controls = before[ck], after[ck]
    if b_controls != a_controls:
        errors.append([name, 'controls changed'])
    comparisons.append({'report': name, 'case_rows': len(a_rows),
                        'exact_case_rows': len(a_rows) - len(changes),
                        'control_rows': len(a_controls),
                        'exact_control_rows': sum(a == b for a, b in zip(a_controls, b_controls)),
                        'before_rows_sha256': row_hash(b_rows), 'after_rows_sha256': row_hash(a_rows),
                        'before_controls_sha256': row_hash(b_controls), 'after_controls_sha256': row_hash(a_controls),
                        'before_counts': dict(Counter(r['status'] for r in b_rows)),
                        'after_counts': dict(Counter(r['status'] for r in a_rows)),
                        'transitions': dict(sorted(transitions.items())),
                        'prior_pass_losses': losses, 'changed_rows': changes})

for p in plan['profiles']:
    baseline = G / 'worktree' / p['baseline']
    assert sha(baseline.read_bytes()) == p['sha256'], p['profile']
    receipt = read(G / 'regressions-candidate-1' / (p['profile'] + '-receipt.json'))
    assert receipt['exit'] == 0 and receipt['regressions'] == 0
    for kind in ['report', 'log']:
        extension = '.json' if kind == 'report' else '.log'
        payload = (G / 'regressions-candidate-1' / (p['profile'] + extension)).read_bytes()
        assert sha(payload) == receipt[kind + '_sha256']

summary = {'profiles': len(comparisons), 'historical_profiles': len(plan['profiles']),
           'case_rows': sum(r['case_rows'] for r in comparisons),
           'exact_case_rows': sum(r['exact_case_rows'] for r in comparisons),
           'control_rows': sum(r['control_rows'] for r in comparisons),
           'exact_control_rows': sum(r['exact_control_rows'] for r in comparisons),
           'prior_pass_losses': sum(len(r['prior_pass_losses']) for r in comparisons)}
result = {'status': 'clear' if not errors else 'findings',
          'scope': 'Full ordered decoded case/control rows, identity/policy bindings, preserved baseline hashes and receipts.',
          'before_commit': '02c32143e2e130b783a4bb5db7551899d79b646b',
          'before_adapter_sha256': before_adapter['sha256'], 'after_adapter_sha256': after_adapter['sha256'],
          'summary': summary, 'errors': errors, 'comparisons': comparisons,
          'inputs': list(inputs.values())}
with (G / 'comparison.json').open('x') as stream:
    json.dump(result, stream, indent=2, sort_keys=True)
    stream.write('\n')
print(json.dumps({'status': result['status'], 'summary': summary, 'errors': errors}))
raise SystemExit(bool(errors))
