# Checked Number TypedArray fill comparison

This is a source-only handoff. Root builds and runs it. No benchmark, compiler,
formatter, parser or JavaScript execution was performed by the author.

The two Cargo manifests reference one `src/main.rs`, use Rust 1.88.0 release,
disable Eris default features, and have identical release settings. Their only
difference is the Eris path dependency: published fill in
`/tmp/eris-typedarray-fill-1/worktree` versus the encoding-once candidate in
`/tmp/eris-typedarray-fill-encoding-1/worktree`. No dependency or production API
is added. The root benchmark package owns the release profile in both builds.

## Workload and checks

The fixed matrix is all ten Number kinds, each at lengths 0, 1, 16 and 512.
Each case has 21 fresh-runtime samples. A sample sets up its array with 73,
warms it with 17 then 73, and times four executions using 17, 73, 17, 73.
These integers are exactly representable in every kind. Every present element
changes on every measured call; length zero is the explicit empty control.

Only `Runtime::execute` lies inside each Rust `Instant` interval. Its JavaScript
expression calls fill and checks returned identity, length, and both endpoints
when nonempty. Any error, resource limit, non-true result or zero interval fails
the process. The setup, warmups, and every measured call are also followed by
untimed literal checks of every element, in chunks of at most 64 positions.
The expected values are independent literals, not a candidate-produced oracle.
The checks deliberately avoid `join`, new APIs or private Runtime access.

Runtime/bootstrap, Document parsing, array setup, Rust source-string assembly,
warmup, full-element verification, printing and process/launcher startup are
outside timers. JS parsing, interpreter dispatch, native fill and the small
identity/length/endpoint expressions are inside. Verification touches the
array between measurements, so this describes a warm checked script workload.
It is not an isolated native-kernel benchmark or a cold-cache measurement.

Each sample gets a new Runtime because public execute resets the work allowance
but keeps cumulative charged heap. Normal limits apply throughout. Length 512
keeps the old full write loop below the unchanged per-script work quota; any
unexpected setup/check/resource refusal aborts instead of silently skipping it.
There are 840 rows and 3,360 measured execute calls per process. Four rounds
run both binaries, for 6,720 rows and 26,880 measured calls total. Per engine,
each case contributes 84 four-call sample means across the four rounds.

## Root build and run handoff

1. Preserve the Rust/manifests raw hold in `rust-source-ready.json`. If root
   formats the Rust source, retain its formatted binding and use those exact
   bytes for both builds. Do not modify any harness input between binaries.
2. Seed both benchmark Cargo.lock files with the exact published parent's lock.
   Root's first offline builds may add only the benchmark root package. Retain
   before/after lock differences, reject any other dependency change, and require
   the two resolved locks to be byte-identical. This avoids selecting alternate
   cached dependency versions with a fresh resolver. Then use `--locked`.
3. Build both manifests with `cargo +1.88.0 build --release --offline --locked
   --manifest-path <before-or-after/Cargo.toml>` and the same environment. The
   initial seeded-lock build omits `--locked` only for the documented root entry.
   Use separate target directories or copy/hash the first completed executable
   before a shared target is reused. Matching existing dependency caches are
   permitted. Retain actual commands, source bindings, logs and binary hashes;
   do not infer a binary's build inputs only from a later filesystem snapshot.
4. Finish all compilation, tests and replays before timing. Run on the same
   otherwise idle host without concurrent compilers/replays. Do not change CPU
   policy or scheduler settings between labels. Record any host disturbance.
5. Invoke the authored runner, for example:

   ```text
   python3 run.py --before-binary <frozen-before-executable> --after-binary <frozen-after-executable> --output <new-result-directory> --wrapper /tmp/eris-typedarray-fill-encoding-1/worktree/tools/ci_test_runner.py
   ```

   The wrapper is optional and is identical for both labels. The existing
   `ci_test_runner.py` sanitizes inherited jobserver descriptors/flags; it does
   not configure the dynamic loader. Root supplies any required common
   `LD_LIBRARY_PATH` before starting the runner. The runner records its exact
   value, `LD_PRELOAD`, `LD_AUDIT`, wrapper hash and Python executable binding.
   Root should retain loader/dependency bindings with build receipts when these
   external library paths are required. A loader failure is retained as failure,
   never a timing sample. Wrapper and process wall time is diagnostic only.

The runner alternates process order before/after, after/before, before/after,
after/before. It starts each child in an owned process group, uses the same
inherited environment, and gives each process 300 seconds. A timeout kills and
reaps that group, retains partial stdout/stderr and a failed receipt. It does
not retry or trim slow samples. It requires a fresh output directory.

## Records and interpretation

The ASCII protocol contains an exact header, all 840 ordered unique rows and
an exact final count. Nonzero exit, any stderr, missing/extra/reordered rows,
wrong counters, malformed numbers or changed source/binary inputs fail the run.
Each process's raw output and command/status/hash receipt is retained. Inputs
bind both source trees and assets, Cargo files, shared benchmark, wrapper and
binaries before and after. Environment records include toolchains, CPU model,
affinity, governor, load average, flags and loader paths. These checks detect
changes during the comparison; root's retained build receipts establish the
separate source-to-binary binding.

Summary statistics are descriptive medians and nearest-rank p95 values of
four-call sample means, in nanoseconds per checked execute. The runner reports
each round and the pooled per-label cases. It makes no outlier removal,
significance, universal throughput, rendering, browser or Chromium comparison
claim. In particular, p95 is a percentile of sample means, not individual-call
tail latency. Inspect all rounds and raw rows before interpreting small changes.
