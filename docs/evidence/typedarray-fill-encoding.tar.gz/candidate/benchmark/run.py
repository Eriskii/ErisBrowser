#!/usr/bin/env python3
"""Root-run only: alternate two prebuilt binaries and retain checked raw rows."""
import argparse
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import signal
import stat
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOTS = {
    "before": Path("/tmp/eris-typedarray-fill-1/worktree"),
    "after": Path("/tmp/eris-typedarray-fill-encoding-1/worktree"),
}
KINDS = ("Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Uint16Array",
         "Int32Array", "Uint32Array", "Float16Array", "Float32Array", "Float64Array")
LENGTHS = (0, 1, 16, 512)
SAMPLES, WARMUP, REPS, CHUNK, ROUNDS = 21, 2, 4, 64, 4


def digest(path):
    if not stat.S_ISREG(path.lstat().st_mode):
        raise ValueError(f"expected regular nonsymlink file: {path}")
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return {"path": str(path), "bytes": path.stat().st_size, "sha256": h.hexdigest()}


def write_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, sort_keys=True)
        stream.write("\n")


def source_inputs(root):
    paths = [root / "Cargo.toml", root / "Cargo.lock"]
    paths.extend(sorted((root / "src").rglob("*.rs")))
    paths.extend(sorted(path for path in (root / "assets").rglob("*") if path.is_file()))
    for name in ("build.rs", ".cargo/config", ".cargo/config.toml"):
        path = root / name
        if path.exists():
            paths.append(path)
    return [digest(path) for path in paths]


def command_text(arguments):
    result = subprocess.run(arguments, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                            check=True, timeout=30)
    return result.stdout.decode("utf-8").strip()


def inputs(binaries, wrapper):
    return {
        "benchmark": [digest(HERE / name) for name in
                      ("src/main.rs", "run.py", "plan.md", "before/Cargo.toml", "after/Cargo.toml",
                       "before/Cargo.lock", "after/Cargo.lock")],
        "dependencies": {label: source_inputs(root) for label, root in ROOTS.items()},
        "heads": {label: command_text(["git", "-C", str(root), "rev-parse", "HEAD"])
                  for label, root in ROOTS.items()},
        "binaries": {label: digest(path) for label, path in binaries.items()},
        "wrapper": digest(wrapper) if wrapper is not None else None,
        "python_executable": digest(Path(sys.executable).resolve()),
    }


def environment():
    cpu = "unavailable"
    info = Path("/proc/cpuinfo")
    if info.exists():
        cpu = next((line.split(":", 1)[1].strip() for line in info.read_text().splitlines()
                    if line.startswith("model name") and ":" in line), cpu)
    governor = Path("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor")
    return {
        "utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "platform": platform.platform(), "machine": platform.machine(),
        "cpu_model": cpu, "cpu_count": os.cpu_count(),
        "affinity": sorted(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else None,
        "cpu0_governor": governor.read_text().strip() if governor.exists() else None,
        "load_average": os.getloadavg() if hasattr(os, "getloadavg") else None,
        "python": platform.python_version(),
        "rustc": command_text(["rustc", "+1.88.0", "--version", "--verbose"]),
        "cargo": command_text(["cargo", "+1.88.0", "--version"]),
        "build_environment": {key: os.environ.get(key) for key in
                              ("RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "CARGO_BUILD_TARGET",
                               "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER", "CARGO_TARGET_DIR")},
        "loader_environment": {key: os.environ.get(key) for key in
                               ("LD_LIBRARY_PATH", "LD_PRELOAD", "LD_AUDIT")},
    }


def run_owned(command, child_environment):
    # The optional wrapper and binary share this owned process group. A timeout
    # kills/reaps that group and preserves output already produced by either.
    start = time.monotonic()
    with subprocess.Popen(command, cwd=HERE, env=child_environment, close_fds=True,
                          start_new_session=True, stdout=subprocess.PIPE,
                          stderr=subprocess.PIPE) as process:
        timed_out = False
        try:
            stdout, stderr = process.communicate(timeout=300)
        except subprocess.TimeoutExpired:
            timed_out = True
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            stdout, stderr = process.communicate()
        except BaseException:
            try:
                os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:
                pass
            process.communicate()
            raise
        return stdout, stderr, process.returncode, timed_out, time.monotonic() - start


def integer(text):
    number = int(text)
    if str(number) != text or number < 0:
        raise ValueError("noncanonical protocol integer")
    return number


def parse(raw, round_number):
    lines = raw.decode("ascii").splitlines()
    header = f"ERIS_FILL_BENCH\t1\t{round_number}\t{SAMPLES}\t{WARMUP}\t{REPS}\t{CHUNK}"
    roster = [(kind, length, sample) for kind in KINDS for length in LENGTHS
              for sample in range(SAMPLES)]
    if len(lines) != len(roster) + 2 or lines[0] != header:
        raise ValueError("incomplete or incorrect benchmark protocol")
    if lines[-1] != f"END\t{len(roster)}\t{len(roster) * REPS}":
        raise ValueError("incorrect final row/call count")
    rows = []
    for line, identity in zip(lines[1:-1], roster):
        fields = line.split("\t")
        if len(fields) != 6 or fields[0] != "ROW":
            raise ValueError("malformed timing row")
        kind, length, sample = fields[1], integer(fields[2]), integer(fields[3])
        ns, calls = integer(fields[4]), integer(fields[5])
        if (kind, length, sample) != identity or calls != REPS or not 0 < ns <= 300_000_000_000:
            raise ValueError("wrong identity, call count or timing")
        rows.append({"kind": kind, "length": length, "sample": sample,
                     "nanoseconds": ns, "calls": calls})
    return rows


def statistics_by_case(rows):
    result = []
    for kind in KINDS:
        for length in LENGTHS:
            values = sorted(row["nanoseconds"] / row["calls"] for row in rows
                            if row["kind"] == kind and row["length"] == length)
            if not values:
                raise ValueError("missing case samples")
            result.append({"kind": kind, "length": length, "samples": len(values),
                           "median_ns_per_checked_execute": statistics.median(values),
                           "p95_ns_per_checked_execute": values[math.ceil(0.95 * len(values)) - 1]})
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--before-binary", type=Path, required=True)
    parser.add_argument("--after-binary", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--wrapper", type=Path,
                        help="Optional Python FD-sanitizing launcher; one path used for both binaries")
    args = parser.parse_args()
    binaries = {"before": args.before_binary.absolute(), "after": args.after_binary.absolute()}
    if binaries["before"] == binaries["after"]:
        raise ValueError("two distinct binary paths required")
    for path in binaries.values():
        digest(path)
        if not os.access(path, os.X_OK):
            raise ValueError(f"binary is not executable: {path}")
    if (HERE / "before/Cargo.lock").read_bytes() != (HERE / "after/Cargo.lock").read_bytes():
        raise ValueError("resolved benchmark dependency locks differ")
    before_manifest = (HERE / "before/Cargo.toml").read_text()
    after_manifest = (HERE / "after/Cargo.toml").read_text()
    if before_manifest.replace(str(ROOTS["before"]), "ERIS_PATH") != after_manifest.replace(str(ROOTS["after"]), "ERIS_PATH"):
        raise ValueError("manifests differ beyond the Eris dependency path")
    wrapper = args.wrapper.absolute() if args.wrapper is not None else None
    if wrapper is not None:
        digest(wrapper)
    # This fixed environment is shared by every before/after child. The wrapper
    # may remove only inherited build jobserver flags; it supplies no libraries.
    child_environment = os.environ.copy()
    initial = inputs(binaries, wrapper)
    args.output.mkdir(parents=True, exist_ok=False)
    write_json(args.output / "inputs-before.json", initial)
    write_json(args.output / "environment-before.json", environment())
    runs, pooled = [], {"before": [], "after": []}
    try:
        for round_number in range(ROUNDS):
            order = ("before", "after") if round_number % 2 == 0 else ("after", "before")
            for position, label in enumerate(order):
                stem = f"round-{round_number}-{position}-{label}"
                command = [str(binaries[label]), str(round_number)]
                if wrapper is not None:
                    command = [sys.executable, str(wrapper), *command]
                raw_stdout, raw_stderr, returncode, timed_out, elapsed = run_owned(command, child_environment)
                stdout, stderr = args.output / f"{stem}.stdout", args.output / f"{stem}.stderr"
                with stdout.open("xb") as stream:
                    stream.write(raw_stdout)
                with stderr.open("xb") as stream:
                    stream.write(raw_stderr)
                receipt = {"label": label, "round": round_number, "position": position,
                           "command": command, "timed_out": timed_out,
                           "returncode": returncode, "process_seconds": elapsed,
                           "stdout": digest(stdout), "stderr": digest(stderr)}
                write_json(args.output / f"{stem}.json", receipt)
                if returncode != 0 or raw_stderr or timed_out:
                    raise ValueError(f"benchmark failed: {stem}; raw output retained")
                rows = parse(raw_stdout, round_number)
                pooled[label].extend(rows)
                runs.append({**receipt, "statistics": statistics_by_case(rows)})
        final = inputs(binaries, wrapper)
        write_json(args.output / "inputs-after.json", final)
        write_json(args.output / "environment-after.json", environment())
        if final != initial:
            raise ValueError("benchmark inputs or binaries changed during execution")
        summary = {"status": "complete", "rounds": ROUNDS, "runs": runs,
                   "statistics": {label: statistics_by_case(rows) for label, rows in pooled.items()},
                   "statistic_unit": "nanoseconds per checked execute, from four-call sample totals",
                   "p95_definition": "nearest rank ceil(0.95*N) in sorted sample means",
                   "scope": "Includes JS parse/interpreter/native and literal identity/endpoint checks. Excludes runtime/array setup, warmup, full-element verification, wrapper/process startup, I/O and rendering.",
                   "limits": "Descriptive local timings only; no statistical significance, isolated native-kernel timing or Chromium claim."}
        write_json(args.output / "summary.json", summary)
    except Exception as error:
        write_json(args.output / "failure.json", {"status": "failed", "error": repr(error),
                                                  "completed_runs": len(runs)})
        raise


if __name__ == "__main__":
    main()
