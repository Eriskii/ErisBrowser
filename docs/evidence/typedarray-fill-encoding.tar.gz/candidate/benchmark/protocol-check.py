"""Reject corrupt timing populations; verify statistics against known data."""
from pathlib import Path
import importlib.util
import json

spec = importlib.util.spec_from_file_location('fill_benchmark_runner', Path(__file__).with_name('run.py'))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)
lines = ['ERIS_FILL_BENCH\t1\t0\t21\t2\t4\t64']
for kind in runner.KINDS:
    for length in (0, 1, 16, 512):
        for sample in range(21):
            lines.append(f'ROW\t{kind}\t{length}\t{sample}\t{4 * (sample + 1)}\t4')
lines.append('END\t840\t3360')
raw = ('\n'.join(lines) + '\n').encode('ascii')
rows = runner.parse(raw, 0)
assert len(rows) == 840
stats = runner.statistics_by_case(rows)
assert len(stats) == 40
assert all(row['samples'] == 21 and row['median_ns_per_checked_execute'] == 11
           and row['p95_ns_per_checked_execute'] == 20 for row in stats)
bad = {
    'missing_row': ('\n'.join(lines[:3] + lines[4:]) + '\n').encode(),
    'duplicated_identity': raw.replace(b'\t0\t1\t8\t4\n', b'\t0\t0\t8\t4\n', 1),
    'zero_duration': raw.replace(b'\t0\t0\t4\t4\n', b'\t0\t0\t0\t4\n', 1),
    'wrong_call_count': raw.replace(b'\t0\t0\t4\t4\n', b'\t0\t0\t4\t3\n', 1),
    'wrong_end_count': raw.replace(b'END\t840\t3360', b'END\t840\t3359'),
    'noncanonical_integer': raw.replace(b'\t0\t0\t4\t4\n', b'\t0\t0\t04\t4\n', 1),
    'truncated_output': raw[:-8],
    'extra_output': raw + b'extra\n',
    'wrong_round': raw.replace(b'ERIS_FILL_BENCH\t1\t0', b'ERIS_FILL_BENCH\t1\t1'),
}
for name, payload in bad.items():
    assert payload != raw, name
    try:
        runner.parse(payload, 0)
    except (ValueError, IndexError):
        pass
    else:
        raise AssertionError(f'accepted corrupt population: {name}')
print(json.dumps({'status': 'passed', 'valid_rows': len(rows),
                  'literal_statistic_groups': len(stats), 'rejected_controls': sorted(bad)}))
