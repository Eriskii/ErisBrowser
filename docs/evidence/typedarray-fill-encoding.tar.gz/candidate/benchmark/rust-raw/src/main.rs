use eris::{dom::Document, script::{Runtime, Value}};
use std::{env, process::ExitCode, time::Instant};

const KINDS: [&str; 10] = [
    "Int8Array", "Uint8Array", "Uint8ClampedArray", "Int16Array", "Uint16Array",
    "Int32Array", "Uint32Array", "Float16Array", "Float32Array", "Float64Array",
];
const LENGTHS: [usize; 4] = [0, 1, 16, 512];
const SAMPLES: usize = 21;
const WARMUP: usize = 2;
const REPETITIONS: usize = 4;
const VALUES: [usize; 2] = [17, 73];
const CHECK_CHUNK: usize = 64;

fn checked(runtime: &mut Runtime, document: &mut Document, source: &str) -> Result<(), String> {
    match runtime.execute(source, document) {
        Ok(Value::Bool(true)) => Ok(()),
        Ok(value) => Err(format!("result mismatch: {value:?}")),
        Err(error) => Err(format!("execution failed: {error}")),
    }
}

fn fill_source(length: usize, value: usize) -> String {
    let mut source = format!("benchView.fill({value}) === benchView && benchView.length === {length}");
    if length != 0 {
        source.push_str(&format!(" && benchView[0] === {value} && benchView[{}] === {value}", length - 1));
    }
    source.push(';');
    source
}

fn check_sources(length: usize, value: usize) -> Vec<String> {
    (0..length).step_by(CHECK_CHUNK).map(|first| {
        let last = (first + CHECK_CHUNK).min(length);
        format!("var benchOk = true; for (var benchIndex = {first}; benchIndex < {last}; benchIndex++) {{ if (benchView[benchIndex] !== {value}) benchOk = false; }} benchOk;")
    }).collect()
}

fn run() -> Result<(), String> {
    let arguments: Vec<_> = env::args().skip(1).collect();
    if arguments.len() != 1 {
        return Err("expected one round number in 0..4".into());
    }
    let round: usize = arguments[0].parse().map_err(|_| "invalid round")?;
    if round >= 4 { return Err("round must be in 0..4".into()); }
    println!("ERIS_FILL_BENCH\t1\t{round}\t{SAMPLES}\t{WARMUP}\t{REPETITIONS}\t{CHECK_CHUNK}");
    let mut rows = 0usize;
    for kind in KINDS {
        for length in LENGTHS {
            // Strings and all runtime/array/bootstrap setup are outside timers.
            let setup = format!("var benchView = new {kind}({length}); benchView.fill(73) === benchView && benchView.length === {length};");
            let sources = VALUES.map(|value| fill_source(length, value));
            let verification = VALUES.map(|value| check_sources(length, value));
            for sample in 0..SAMPLES {
                // Fresh per sample bounds cumulative VM heap without bypassing
                // any VM limit. Each execute retains its normal script budget.
                let mut runtime = Runtime::try_new().map_err(|e| format!("bootstrap: {e}"))?;
                let mut document = Document::parse("<!doctype html><title>Fill benchmark</title>");
                checked(&mut runtime, &mut document, &setup)?;
                for source in &verification[1] { checked(&mut runtime, &mut document, source)?; }
                for warmup in 0..WARMUP {
                    let which = warmup % VALUES.len();
                    checked(&mut runtime, &mut document, &sources[which])?;
                    for source in &verification[which] { checked(&mut runtime, &mut document, source)?; }
                }
                let mut nanoseconds = 0u128;
                for repetition in 0..REPETITIONS {
                    // Setup/warmup ends at73; every timed call changes all
                    // present elements:17,73,17,73. No equal-byte shortcut.
                    let which = repetition % VALUES.len();
                    let start = Instant::now();
                    let result = runtime.execute(&sources[which], &mut document);
                    let elapsed = start.elapsed().as_nanos();
                    match result {
                        Ok(Value::Bool(true)) => {}
                        Ok(value) => return Err(format!("{kind}/{length}/{sample}: result mismatch {value:?}")),
                        Err(error) => return Err(format!("{kind}/{length}/{sample}: {error}")),
                    }
                    if elapsed == 0 { return Err("zero timer interval".into()); }
                    nanoseconds = nanoseconds.checked_add(elapsed).ok_or("timer sum overflow")?;
                    // Verify every element, not merely the timed endpoints.
                    // Chunking keeps validation within the unchanged VM quota.
                    for source in &verification[which] { checked(&mut runtime, &mut document, source)?; }
                }
                println!("ROW\t{kind}\t{length}\t{sample}\t{nanoseconds}\t{REPETITIONS}");
                rows += 1;
            }
        }
    }
    println!("END\t{rows}\t{}", rows * REPETITIONS);
    Ok(())
}

fn main() -> ExitCode {
    match run() {
        Ok(()) => ExitCode::SUCCESS,
        Err(error) => { eprintln!("BENCH_FAIL\t{error}"); ExitCode::FAILURE }
    }
}
