from pathlib import Path
import hashlib
import json

A = Path(__file__).resolve().parents[1]
def bind(p):
    b = p.read_bytes()
    return {'path': str(p), 'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}

source = A / 'source-1.json'
inventory = json.loads(source.read_text())['source_sha256']
assert len(inventory) == 783
for name, sha in inventory.items():
    assert bind(A / 'worktree' / name)['sha256'] == sha, name
checks = {}
for label in ['current-small-stack-1', 'current-native-full-1', 'msrv-default-full-1',
              'ci-stable-native-full-1', 'strict-msrv-1', 'strict-stable-1', 'format-check-1']:
    r = json.loads((A / 'validation' / (label + '.json')).read_text())
    assert r['exit'] == 0
    assert bind(A / 'validation' / r['log'])['sha256'] == r['sha256']
    checks[label] = r
for name in ['source-review.json', 'validation-review.json']:
    assert json.loads((A / 'root' / name).read_text())['status'] in ['clear', 'clear_source_only']
artifacts = {}
for directory in ['root', 'validation']:
    for p in sorted((A / directory).rglob('*')):
        if p.is_file() and p.name not in ['selection-final.json', 'publication-verification.json']:
            artifacts[str(p.relative_to(A))] = bind(p)
for p in sorted(A.iterdir()):
    if p.is_file() and p.suffix in ['.py', '.json', '.log']:
        artifacts[p.name] = bind(p)
for name in ['docs/runtime-bootstrap-stack.md', 'docs/promise-foundation.md']:
    artifacts['documentation/' + name] = bind(A / 'worktree' / name)
selection = {
    'source_inventory': bind(source), 'artifacts': artifacts,
    'max_uncompressed_bytes': 128 * 1024 * 1024,
    'claims': {
        'base': 'c275ea188c753de3f51f347283ad46a1a789b261',
        'scope': 'Borrow Runtime through bootstrap; avoid whole-runtime return temporaries on the nested installer path.',
        'source_inputs': 783, 'changed_production_paths': ['src/script.rs'],
        'old_tests_unchanged': True, 'new_tests': 0, 'numeric_limits_unchanged': True,
        'parent_failure': 'Rust 1.99 CI default and Vulkan suites overflowed an existing 128 KiB thread; Rust 1.98 reproduced the same witness locally. GDB identified DataView metadata initialization before script execution.',
        'change': 'try_new constructs a local, initializes by mutable borrow and resets author work only after success. Test-only consuming wrapper retains raw initialization fixtures. Initialization order, original error propagation, fees and state layout remain unchanged.',
        'checks': checks,
        'full_suite_totals': {k: {f: v[f] for f in ['passed', 'failed', 'ignored', 'result_rows', 'log_sha256']} for k, v in json.loads((A / 'root/full-suite-totals.json').read_text()).items()},
        'ci_compiler': bind(A / 'ci-stable-version.json'),
        'limitations': ['No exact stack-byte savings measurement.', 'No claim for every compiler/target.', 'No new rendering feature, browser performance comparison or full compatibility/security claim.', 'Existing tests were retained; temporary stage instrumentation was never compiled and was removed before candidate execution.']
    }
}
with (A / 'root/selection-final.json').open('x') as out:
    json.dump(selection, out, indent=2)
    out.write('\n')
print(json.dumps({'sources': len(inventory), 'artifacts': len(artifacts)}))
