// Proposal only. Not executed; use an existing empty element with id="target".
const style = document.getElementById("target").style;
style.cssText = "margin-top:initial;margin-right:1px;margin-bottom:1px;margin-left:1px";
const generic = style.getPropertyValue("margin"); // expected ""; source infers "initial 1px 1px"
const named = style.margin;                     // expected the same empty string
const retained = style.getPropertyValue("margin-top"); // expected "initial"
const removed = style.removeProperty("margin"); // expected "", while all four margins are removed
