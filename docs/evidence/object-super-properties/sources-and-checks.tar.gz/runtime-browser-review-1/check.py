"""Independent stdlib/Git source checks; no project import, compilation or execution."""
import difflib
import hashlib
import json
from pathlib import Path
import subprocess

L = Path('/tmp/eris-object-super-properties-plan-1')
OUT = L / 'runtime-browser-review-1'
W = L / 'worktree'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def bind(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}


def base(path):
    return subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + path])


def write(name, value):
    (OUT / name).write_text(json.dumps(value, indent=2) + '\n')


tracked = set(subprocess.check_output(['git', '-C', str(W), 'ls-tree', '-r', '--name-only', BASE]).decode().splitlines())
joins = []
for name in ['runtime-producer-1', 'browser-controls-1']:
    hold = L / name
    manifest = json.loads((hold / 'source-ready.json').read_text())
    assert manifest['base'] == BASE
    for row in manifest['paths']:
        path = row['path']
        before = (hold / 'before' / path).read_bytes()
        after = (hold / 'raw' / path).read_bytes()
        assert len(after) == row['bytes'] and digest(after) == row['after']
        if row['before'] is None:
            assert before == b'' and path not in tracked
        else:
            assert digest(before) == row['before'] and before == base(path)
        forward = ''.join(difflib.unified_diff(before.decode().splitlines(True), after.decode().splitlines(True), fromfile='a/' + path, tofile='b/' + path)).encode()
        inverse = ''.join(difflib.unified_diff(after.decode().splitlines(True), before.decode().splitlines(True), fromfile='a/' + path, tofile='b/' + path)).encode()
        assert (hold / 'diffs' / (path + '.forward.patch')).read_bytes() == forward
        assert (hold / 'diffs' / (path + '.inverse.patch')).read_bytes() == inverse
        joins.append({'hold': name, 'path': path, 'before_bytes': len(before),
                      'after': bind(hold / 'raw' / path),
                      'forward': bind(hold / 'diffs' / (path + '.forward.patch')),
                      'inverse': bind(hold / 'diffs' / (path + '.inverse.patch'))})

runtime = L / 'runtime-producer-1/raw'
script = (runtime / 'src/script.rs').read_text()
registration = 'mod object_super_properties;\n'
assert script.count(registration) == 1
assert script.replace(registration, '', 1).encode() == base('src/script.rs')
machine = (runtime / 'src/script/machine.rs').read_text()
attachment = '                runtime.object_attach_home(&function, &object)?;\n'
assert machine.count(attachment) == 2
assert machine.replace(attachment, '').encode() == base('src/script/machine.rs')
for arm in ['Method(id)', 'Accessor(id, setter)']:
    prefix = '            code::ObjectEntry::' + arm + ' => {\n' + \
             '                let function = runtime.function_value(&code::FunctionRef::new(&unit, *id), env)?;\n' + attachment
    assert machine.count(prefix) == 1
helper = (runtime / 'src/script/object_super_properties.rs').read_text()
assert helper.count('self.work(8)?;') == 1
assert helper.count('function.home_object = Some(*home);') == 1
assert helper.index('self.work(8)?;') < helper.index('let (Value::Function') < helper.index('function.home_object = Some(*home);')
assert all(word not in helper for word in ['self.charge(', '.clone()', 'function.code.strict', 'self.call(', 'self.tick('])
assert 'self.functions.get_mut(*id).ok_or_else(invalid)?' in helper
assert '*home >= self.objects.len()' in helper
assert all(word in helper for word in ['function.bound.is_some()', 'function.home_object.is_some()',
    'function.code.arrow', 'function.code.constructable', 'function.code.class_kind.is_some()'])

browser = L / 'browser-controls-1/raw'
worker = (browser / 'tests/worker.rs').read_text()
worker_append = '\n#[path = "worker/object_super_properties.rs"]\nmod object_super_properties;\n'
assert worker.endswith(worker_append)
assert worker[:-len(worker_append)].encode() == base('tests/worker.rs')

def equivalent(old_path, new_path, replacements):
    old = base(old_path).decode()
    for before, after in replacements:
        assert before in old
        old = old.replace(before, after)
    assert old == (browser / new_path).read_text(), new_path


equivalent('tests/class_super_properties.rs', 'tests/object_super_properties.rs', [
    ('//! Classes retain inherited accessors', '//! Object methods retain inherited accessors'),
    ('support/class_super_properties.rs', 'support/object_super_properties.rs'),
    ('fn super_properties_update_', 'fn object_super_properties_update_'),
    ('https://super-properties.invalid/', 'https://object-super-properties.invalid/'),
])
equivalent('tests/support/class_super_properties.rs', 'tests/support/object_super_properties.rs', [
    ('//! Literal class, Promise', '//! Literal object-method, Promise'),
    ('../fixtures/class-super-properties.html', '../fixtures/object-super-properties.html'),
    ('SBDTQRPG', 'STQRPG'),
])
equivalent('tests/worker/class_super_properties.rs', 'tests/worker/object_super_properties.rs', [
    ('//! Class construction, native Promise', '//! Object method inheritance, native Promise'),
    ('../support/class_super_properties.rs', '../support/object_super_properties.rs'),
    ('fn confined_super_properties_update_', 'fn confined_object_super_properties_update_'),
    ('661', '671'), ('662', '672'),
])
html = (browser / 'tests/fixtures/object-super-properties.html').read_text()
assert html.split('<script>')[0].encode() == base('tests/fixtures/class-super-properties.html').split(b'<script>')[0]
support = (browser / 'tests/support/object_super_properties.rs').read_text()
initial = ''.join(['S', 'T', 'Q', 'R', 'P', 'G'])
clicked = initial + ''.join(['C', 'T', 'R', 'W', 'P', 'G', 'L'])
assert f'pub const INITIAL: &str = "{initial}";' in support
assert f'pub const CLICKED: &str = "{clicked}";' in support
assert json.loads((L / 'browser-controls-1/source-ready.json').read_text())['expected']['initial'] == initial
assert json.loads((L / 'browser-controls-1/source-ready.json').read_text())['expected']['clicked'] == clicked

source_paths = [
    'src/script.rs', 'src/script/machine.rs', 'src/script/machine/calls.rs', 'src/script/class_super_properties.rs',
    'src/script/promises/semantics.rs', 'src/script/microtasks.rs', 'src/page.rs',
    'tests/worker.rs', 'tests/class_super_properties.rs', 'tests/support/class_super_properties.rs',
    'tests/worker/class_super_properties.rs', 'tests/fixtures/class-super-properties.html',
    'tests/support/vulkan_backgrounds.rs',
]
published = [{'path': p, 'bytes': len(base(p)), 'sha256': digest(base(p))} for p in source_paths]
write('checks.json', {
    'status': 'source-only checks passed', 'base': BASE, 'payload_joins': joins,
    'published_inputs': published,
    'runtime_exact_addition_checks': {
        'script_module_registration_only': True,
        'machine_attachment_calls_exactly_two': True,
        'both_after_function_value_before_naming': True,
        'all_other_machine_and_script_bytes_equal_published': True,
        'class_home_and_capture_helpers_untouched': True,
        'work8_precedes_all_validation_and_one_scalar_mutation': True,
        'no_heap_charge_no_clone_no_author_callback': True,
        'strictness_not_an_eligibility_condition': True,
    },
    'browser_plumbing_checks': {
        'direct_adapter_equal_published_after_four_naming_substitutions': True,
        'worker_adapter_equal_published_after_naming_and_generation_substitutions': True,
        'pixel_helper_equal_published_after_fixture_trace_comment_substitutions': True,
        'html_head_css_and_literal_dom_equal_published': True,
        'worker_registration_explicit_correct_path_append_only': True,
        'direct_oracle_path': 'tests/support/object_super_properties.rs',
        'worker_oracle_path': 'tests/worker/../support/object_super_properties.rs',
        'fixture_include': 'tests/support/../fixtures/object-super-properties.html',
        'initial_trace': initial, 'clicked_trace': clicked,
        'pixel_geometry': {'widths': [320, 300], 'height': 240, 'red_x': [2, 12, 16],
            'blue_x': 20, 'rectangles': '4x4 at y=2; 16 red and 16 blue pixels; all others white'},
        'planned_render_observations_per_group': 12,
        'native_comparison': 'Feature-gated CPU packed-plan interpreter only',
    },
    'no_project_execution': True,
})
print(json.dumps(bind(OUT / 'checks.json'), indent=2))
