"""Add a current compatibility preface to the sealed final-doc hold; stdlib/read-only Git only."""
from pathlib import Path
import hashlib,json,difflib,subprocess,re
P=Path(__file__).resolve().parent;L=P.parent;D=L/'documentation-2';W=L/'worktree'
def bind(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def put(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
seal=json.loads((D/'source-ready.json').read_bytes());assert seal['path_count']==5
for row in seal['artifacts']:
 path=D/row['path'];assert dict(bind(path),path=row['path'])==row
rows=[]
for row in seal['files']:
 relative=row['relative_path'];raw=P/'raw'/relative;write(raw,Path(row['raw']['path']).read_bytes())
 before=P/'before'/relative
 if row['before']:write(before,Path(row['before']['path']).read_bytes())
 diff=P/'diffs'/(relative.replace('/','__')+'.diff');write(diff,Path(row['diff']['path']).read_bytes())
 rows.append(dict(relative_path=relative,before=bind(before) if row['before'] else None,raw=bind(raw),diff=bind(diff),same_as_documentation2=True))
relative='docs/COMPATIBILITY.md'
before=subprocess.check_output(['git','show',seal['base']+':'+relative],cwd=W)
assert (W/relative).read_bytes()==before
heading=b'# Compatibility status\n\n';assert before.startswith(heading)
preface='''[Class `super` properties](class-super-properties.md) and
[object-literal method/accessor `super`](object-super-properties.md) now support
dot/computed reads, calls and writes with the defining home kept separate from
the receiver. Object methods preserve ordinary strict/sloppy behavior;
optional chaining and the other documented deferrals remain unsupported.

The [Promise class-admission checkpoint](promise-class-admission.md) enables
declared class metadata in seven existing profiles. Current eight-profile
replays retain **1,330 cases: 1,258 passed, 64 failed and eight unsupported**,
with **724 healthy controls**, unchanged in the object-method checkpoint.
The opening class-runtime summary and API/profile results below record earlier
checkpoints; their feature deferrals, policies and totals remain historical.

'''.encode()
after=heading+preface+before[len(heading):]
assert after.replace(preface,b'',1)==before
write(P/'before'/relative,before);write(P/'raw'/relative,after)
diff=P/'diffs'/(relative.replace('/','__')+'.diff')
write(diff,''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)).encode())
rows.append(dict(relative_path=relative,before=bind(P/'before'/relative),raw=bind(P/'raw'/relative),diff=bind(diff),exact_prepended_preface_inverse=True))
write(P/'compatibility-preface.md',preface)
ledger=json.loads((L/'root/final-validation.json').read_bytes())
assert bind(L/'root/final-validation.json')==seal['final_ledger']
assert ledger['profile_counts']==dict(passed=1258,failed=64,unsupported=8)
assert not any(ledger['profile_transition_counts'].values())
links=json.loads((D/'links.json').read_bytes())
for label,url in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',preface.decode()):
 assert (P/'raw/docs'/url).exists() or (W/'docs'/url).is_file()
 links.append(dict(label=label,url=url,from_path=relative,state='Existing or selected held document.'))
put('links.json',links)
put('claims-and-checks.json',dict(status='Additive six-doc final hold; independent peer pending.',
 previous_hold=bind(D/'source-ready.json'),previous_full_claim_checks=bind(D/'claims-and-checks.json'),
 final_ledger=seal['final_ledger'],source_inventory=seal['source_inventory'],source_review=seal['source_review'],
 exactly_five_previous_raw_files_unchanged=True,compatibility_before_git_exact=True,
 compatibility_old_body_exact=True,compatibility_preface_inverse=True,
 compatibility_current_metrics=ledger['profile_counts'],cases=1330,controls=724,
 qualification='The additive preface marks all older compatibility opening/profile claims as historical, without changing any old totals. Original five docs, their historical suffixes, final counts, evidence links and qualifications remain byte-exact to documentation2.',
 links=bind(P/'links.json'),evidence_destinations=['docs/evidence/object-super-properties/manifest.json','docs/evidence/object-super-properties/sources-and-checks.tar.gz'],
 full_final_claim_checks_inherited=True,project_execution=False,live_edits=False,documentation2_modified=False))
artifacts=[dict(bind(p),path=str(p.relative_to(P))) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',dict(schema=1,status='Sealed final six-file documentation hold; independent peer pending.',
 base=seal['base'],supersedes=bind(D/'source-ready.json'),supersedes_draft=seal['supersedes_draft'],
 final_ledger=seal['final_ledger'],source_inventory=seal['source_inventory'],source_review=seal['source_review'],
 files=rows,path_count=6,claims=bind(P/'claims-and-checks.json'),prior_complete_claim_checks=bind(D/'claims-and-checks.json'),
 links=bind(P/'links.json'),artifacts=artifacts,final_counts=seal['final_counts'],
 historical_text_preserved=True,all_five_previous_raw_files_exact=True,documentation2_unchanged=True,
 project_execution=False,live_edits=False))
print(json.dumps(bind(P/'source-ready.json')))
