"""Stdlib-only held source construction; never imports or executes project code."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/tmp/eris-object-super-properties-plan-1')
HOLD = ROOT / 'parser-producer-1'
WORKTREE = ROOT / 'worktree'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'
PRODUCTION = 'src/script/parser/driver/functions.rs'
TEST = 'src/script/parser/super_property_tests.rs'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': sha(data)}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')


def published(path):
    data = subprocess.check_output(['git', '-C', str(WORKTREE), 'show', f'{BASE}:{path}'])
    assert (WORKTREE / path).read_bytes() == data, path
    return data.decode()


def diff(before, after, path):
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                        fromfile='a/' + path, tofile='b/' + path))


assert subprocess.check_output(['git', '-C', str(WORKTREE), 'rev-parse', 'HEAD']).decode().strip() == BASE
before = {path: published(path) for path in [PRODUCTION, TEST]}
raw = dict(before)
edits = []


def replace(path, category, old, new):
    assert raw[path].count(old) == 1, (path, old)
    raw[path] = raw[path].replace(old, new, 1)
    edits.append({'path': path, 'category': category, 'old': old, 'new': new, 'count': 1})


replace(PRODUCTION, 'production comment',
        '// Object methods have a valid super grammar but no selected runtime home object.',
        '// Object methods permit super properties, but never direct super calls.')
replace(PRODUCTION, 'production permission',
        '        Frame::ObjectMethod => {\n'
        '            p.expect("(")?;\n'
        '            let saved = Context::enter(p, false);\n'
        '            p.super_property_deferred = true;',
        '        Frame::ObjectMethod => {\n'
        '            p.expect("(")?;\n'
        '            let saved = Context::enter(p, false);\n'
        '            p.super_property_allowed = true;')
replace(TEST, 'historical test name',
        'fn super_property_parser_object_methods_and_deferred_class_syntax_stay_unsupported()',
        'fn super_property_parser_object_methods_are_admitted_and_class_deferrals_remain()')
replace(TEST, 'historical six selected classifications',
        '        "class C {m(){return {m(){return super.x;}};}}",\n        "class C {field;}",',
        '        "class C {m(){return {m(){return super.x;}};}}",\n'
        '    ] {\n'
        '        Parser::program(source).unwrap_or_else(|error| panic!("{source}: {error:?}"));\n'
        '    }\n'
        '    for source in [\n'
        '        "class C {field;}",')
replace(TEST, 'historical explanatory comment',
        '// A nested ordinary function does not inherit even the deferred method permission.',
        '// A nested ordinary function does not inherit the method permission.')
replace(TEST, 'historical context-error fixture',
        '        "class C {m(){return super[;}}",\n'
        '        "class C {m(){return {m(){return super.x;}};}}",\n'
        '        "class C {m(){return super[key];}} trailing = ;",',
        '        "class C {m(){return super[;}}",\n'
        '        "class C {m(){return class D {field;};}}",\n'
        '        "class C {m(){return super[key];}} trailing = ;",')
historical = raw[TEST]
new_tests = (HOLD / 'new-tests.rs').read_text()
assert new_tests.startswith('\n#[test]\n')
raw[TEST] += new_tests
edits.append({'path': TEST, 'category': 'three new producer-authored parser groups',
              'append': new_tests})

for path in before:
    for directory, value in [('before', before[path]), ('raw', raw[path])]:
        target = HOLD / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(value)
    target = HOLD / 'diffs' / (path + '.diff')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(diff(before[path], raw[path], path))
stage = HOLD / 'historical-migrations' / TEST
stage.parent.mkdir(parents=True, exist_ok=True)
stage.write_text(historical)
(HOLD / 'production.diff').write_text(diff(before[PRODUCTION], raw[PRODUCTION], PRODUCTION))
(HOLD / 'historical-migrations.diff').write_text(diff(before[TEST], historical, TEST))
(HOLD / 'new-tests.diff').write_text(diff(historical, raw[TEST], TEST))
write_json(HOLD / 'edits.json', edits)

# Exact replay and reverse, including separate test migration/addition boundaries.
replayed = dict(before)
for edit in edits:
    path = edit['path']
    if 'append' in edit:
        replayed[path] += edit['append']
    else:
        assert replayed[path].count(edit['old']) == 1
        replayed[path] = replayed[path].replace(edit['old'], edit['new'], 1)
assert replayed == raw
inverted = dict(raw)
for edit in reversed(edits):
    path = edit['path']
    if 'append' in edit:
        assert inverted[path].endswith(edit['append'])
        inverted[path] = inverted[path][:-len(edit['append'])]
    else:
        assert inverted[path].count(edit['new']) == 1
        inverted[path] = inverted[path].replace(edit['new'], edit['old'], 1)
assert inverted == before
for path in before:
    assert before[path].encode() == subprocess.check_output(
        ['git', '-C', str(WORKTREE), 'show', f'{BASE}:{path}'])

old_groups = re.findall(r'#\[test\]\s*fn (\w+)\(', before[TEST])
new_groups = re.findall(r'#\[test\]\s*fn (\w+)\(', raw[TEST])
added_groups = re.findall(r'#\[test\]\s*fn (\w+)\(', new_tests)
assert len(old_groups) == 4 and len(new_groups) == 7 and len(added_groups) == 3
rename = {'before': old_groups[2], 'after': new_groups[2]}
assert [rename['after'] if name == rename['before'] else name for name in old_groups] + added_groups == new_groups

unchanged_paths = [
    'src/script/code.rs', 'src/script/parser.rs', 'src/script/parser/driver.rs',
    'src/script/parser/driver/expressions.rs', 'src/script/parser/driver/classes.rs',
    'src/script/parser/driver/statements.rs', 'src/script/parser/driver/call_spread_layout_tests.rs',
]
unchanged = []
for path in unchanged_paths:
    data = published(path).encode()
    unchanged.append({'path': path, 'bytes': len(data), 'sha256': sha(data)})

write_json(HOLD / 'source-checks.json', {
    'status': 'source-only checks passed; no project execution or compilation',
    'base': BASE,
    'exact_forward_replay': True,
    'exact_inverse_to_published_bytes': True,
    'production_semantic_edits': 1,
    'production_comment_edits': 1,
    'production_representation_change': False,
    'declarations_before_step_exact_except_comment':
        before[PRODUCTION].split('pub(super) fn step')[0].replace(edits[0]['old'], edits[0]['new'])
        == raw[PRODUCTION].split('pub(super) fn step')[0],
    'unchanged_representation_context_and_consumer_inputs': unchanged,
    'old_parser_groups': old_groups,
    'renamed_old_group': rename,
    'new_parser_groups': added_groups,
    'worktree_payload_inputs_still_published': all((WORKTREE / p).read_text() == before[p] for p in before),
    'no_test_registration_change': True,
    'inert_authoring_correction': 'Initial inverse checker searched for the assignment alone, which also exists in ClassMethod. It stopped before sealing; the edit record now binds the unique ObjectMethod arm. Proposed Rust bytes were unchanged by this checker correction. No project execution occurred.',
})
write_json(HOLD / 'test-expectations.json', {
    'authorship': 'Producer-authored parser-only regression coverage. Independent public runtime contract is separately owned. No outcome or compiler result claimed.',
    'existing_groups_retained': 4,
    'renamed_group': rename,
    'historical_migrations': [
        {'kind': 'selected admission', 'sources': [
            '({m(){return super.x;}})', '({m(x=super.x){}})',
            '({get x(){return super.x;}})', '({set x(v){super.x=v;}})',
            '({m(){return ()=>super.x;}})', 'class C {m(){return {m(){return super.x;}};}}'],
         'before': 'Unsupported', 'after': 'successful parse; original six source strings exact'},
        {'kind': 'context unwind fixture',
         'before_source': 'class C {m(){return {m(){return super.x;}};}}',
         'after_source': 'class C {m(){return class D {field;};}}',
         'reason': 'Keep an actually unsupported nested class field after object-method super is admitted. Original accepted source remains in admission coverage.'},
    ],
    'new_groups': added_groups,
    'planned_new_parse_attempts': {'ast_ownership_and_strictness': 2,
        'context_acceptance': 12, 'context_early_errors': 26,
        'entry_unwind_syntax_and_unsupported': 4, 'entry_unwind_work_refusal': 1, 'total': 45},
    'existing_planned_parse_attempts': 37,
    'total_planned_parse_attempts': 82,
    'coverage': [
        'Existing flat ObjectEntry/FunctionId/ExprId ownership for methods, accessors, defaults, lexical arrows and ordinary function-valued data; no class-only tags introduced.',
        'Sloppy and strict entry contexts retained independently; concise methods and accessors remain nonconstructable.',
        'Computed definition keys retain outer permission; nested classes inherit only heritage/computed-name contexts; direct super() remains rejected in object methods/defaults/arrows.',
        'Ordinary functions reset super permission; sibling keys/data and following top-level syntax cannot inherit method permission.',
        'Syntax, deferred-class and exhausted-work refusals restore entry scalar context and retain spent work.',
    ],
    'out_of_scope_root_owned_runtime_migrations': [
        'src/script/super_property_semantics_tests.rs::super_property_deferred_object_literal_method_super',
        'src/script/super_property_semantics_tests.rs::super_property_deferred_object_literal_accessor_arrow_super',
    ],
})
write_json(HOLD / 'integration.json', {
    'scope': 'Two held existing files; one ObjectMethod permission assignment plus comment, separate historical parser migrations and three parser test groups.',
    'production': PRODUCTION,
    'tests': TEST,
    'unchanged': ['AST', 'Parser/Context/State/Frame representations', 'runtime', 'helper tariffs', 'limits', 'module registrations'],
    'semantic_order': [
        'Computed object definition keys finish in expressions::ObjectKey/AccessorKey before entering ObjectMethod.',
        'Context::enter(false) clears direct super and both property flags, retains inherited strictness, and saves the outer context.',
        'ObjectMethod enables only super_property_allowed before parameter defaults/body.',
        'Arrows inherit; ordinary functions clear; finish restores the saved outer context. Entry driver restores scalar context on failure.',
    ],
    'preserved_deferred_field': 'super_property_deferred and its old diagnostic branch remain unchanged to preserve selected representations and unrelated helper bodies; normal selected ObjectMethod entry no longer sets this field.',
    'instructions': 'Root reviews/imports exact raw or categorized diffs, compiles and executes independently. No test execution or runtime support is asserted by this hold.',
})

payloads = []
for path in before:
    payloads.append({'path': path, 'before': binding(HOLD / 'before' / path),
                     'after': binding(HOLD / 'raw' / path),
                     'diff': binding(HOLD / 'diffs' / (path + '.diff'))})
artifacts = [binding(path) for path in sorted(HOLD.rglob('*')) if path.is_file() and path.name != 'source-ready.json']
write_json(HOLD / 'source-ready.json', {
    'status': 'source-ready; not imported or executed',
    'base': BASE,
    'selection': binding(ROOT / 'root/selection-1.json'),
    'parent_source_inventory': binding(ROOT / 'source-parent.json'),
    'scope': 'Object-literal method/accessor SuperProperty parser permission only, plus explicit historical parser-test migrations and producer-authored parser regressions.',
    'payloads': payloads,
    'artifacts': artifacts,
    'exact_inverse': binding(HOLD / 'edits.json'),
    'checks': binding(HOLD / 'source-checks.json'),
    'tests': binding(HOLD / 'test-expectations.json'),
    'no_project_execution': True,
    'no_live_edits': True,
})
print(json.dumps(binding(HOLD / 'source-ready.json'), indent=2))
