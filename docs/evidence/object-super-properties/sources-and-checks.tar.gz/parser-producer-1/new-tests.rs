
#[test]
fn object_super_parser_method_records_own_defaults_and_arrows_without_class_strictness() {
    let source = "({[key](x=super[key]){super.m(x);return ()=>super[key];},get x(){return super.x;},set x(v){super.x=v;},ordinary:function(){return 1;}});";
    for strict in [false, true] {
        let unit = Parser::program_context(source, false, strict).unwrap();
        let Expr::Object(entries) = unit.expr(statement_expr(&unit, unit.body[0])) else {
            panic!("object expression");
        };
        assert_eq!(entries.len(), 4);
        let code::PropertyName::Computed(key) = &entries[0].0 else {
            panic!("computed definition key");
        };
        assert!(matches!(unit.expr(*key), Expr::Ident(name) if name == "key"));
        let ObjectEntry::Method(id) = &entries[0].1 else {
            panic!("concise method");
        };
        let method = unit.function(*id);
        assert!(!method.arrow && !method.constructable && method.class_kind.is_none());
        assert_eq!(method.strict, strict);
        assert_eq!(method.params.len(), 1);
        property_key(&unit, method.params[0].initializer.unwrap());
        let Expr::Call(callee, arguments) = unit.expr(statement_expr(&unit, method.body[0])) else {
            panic!("super method call");
        };
        property_key(&unit, *callee);
        assert_eq!(arguments.len(), 1);
        assert!(matches!(unit.expr(arguments[0]), Expr::Ident(name) if name == "x"));
        let Stmt::Return(Some(arrow)) = unit.stmt(method.body[1]) else {
            panic!("returned lexical arrow");
        };
        let Expr::Function(arrow) = unit.expr(*arrow) else {
            panic!("arrow function record");
        };
        let arrow = unit.function(*arrow);
        assert!(arrow.arrow && !arrow.constructable && arrow.class_kind.is_none());
        assert_eq!(arrow.strict, strict);
        let Stmt::Return(Some(target)) = unit.stmt(arrow.body[0]) else {
            panic!("arrow return");
        };
        property_key(&unit, *target);
        for (index, setter) in [(1, false), (2, true)] {
            let ObjectEntry::Accessor(id, is_setter) = &entries[index].1 else {
                panic!("accessor function record");
            };
            assert_eq!(*is_setter, setter);
            let accessor = unit.function(*id);
            assert!(!accessor.arrow && !accessor.constructable && accessor.class_kind.is_none());
            assert_eq!(accessor.strict, strict);
            assert_eq!(accessor.params.len(), usize::from(setter));
            if setter {
                let Expr::Assign(op, target, _) =
                    unit.expr(statement_expr(&unit, accessor.body[0]))
                else {
                    panic!("setter assignment");
                };
                assert_eq!(op, "=");
                property_key(&unit, *target);
            } else {
                let Stmt::Return(Some(target)) = unit.stmt(accessor.body[0]) else {
                    panic!("getter return");
                };
                property_key(&unit, *target);
            }
        }
        let ObjectEntry::Data(value) = &entries[3].1 else {
            panic!("ordinary function-valued property");
        };
        let Expr::Function(id) = unit.expr(*value) else {
            panic!("ordinary function record");
        };
        let ordinary = unit.function(*id);
        assert!(ordinary.constructable && !ordinary.arrow && ordinary.class_kind.is_none());
        assert_eq!(ordinary.strict, strict);
    }
}

#[test]
fn object_super_parser_contexts_inherit_only_through_selected_syntax() {
    for strict in [false, true] {
        for source in [
            "({m(x=()=>super.x){return (y=super[y])=>super[x];}});",
            "({m(){return {[super.key](x=super.x){return super[x];},get [super.getter](){return super.x;}};}});",
            "({m(){return class D extends super.C {[super.key](){return super.x;}};}});",
            "({constructor(){return super.x;},__proto__(){return super.x;}});",
            "class C extends Object {constructor(){super();({[super.key](){return super.x;}});super();}}",
            "({m(){super.x=1;super[x]++;for(super.x in obj){}for(super[x] of list){}new super.C;delete super.x;}});",
        ] {
            Parser::program_context(source, false, strict)
                .unwrap_or_else(|error| panic!("strict={strict}, {source}: {error:?}"));
        }
        for source in [
            "({m(){super();}});",
            "({m(x=super()){}});",
            "({m(){return ()=>super();}});",
            "({m(){return super;}});",
            "({m(){return {f:function(){return super.x;}};}});",
            "({m(x=function(){return super.x;}){}});",
            "({[super.key](){return 1;}});",
            "({m(){return 1;},[super.key](){return 1;}});",
            "({m(){return 1;},x:super.x});",
            "({m(){return super.x;}});super.x;",
            "({m(){return class C extends Object {[super()](){}};}});",
            "({m(x,x){return super.x;}});",
            "({get x(v){return super.x;}});",
        ] {
            let error = Parser::program_context(source, false, strict).unwrap_err();
            assert!(error.is_parse_error(), "strict={strict}, {source}: {error:?}");
        }
    }
}

#[test]
fn object_super_parser_entry_context_restores_after_errors_and_work_refusal() {
    for (source, unsupported) in [
        ("({m(){return super[;}});", false),
        ("({m(x=super[){}});", false),
        ("({m(){'use strict';return ()=>super[;}});", false),
        ("({m(){return class C {field;};}});", true),
    ] {
        let mut budget = regexp::Budget {
            steps: MAX_STEPS,
            allocated: 0,
            heap_limit: MAX_HEAP,
            stack_limit: 16,
        };
        let mut parser = Parser::start(source, false, false, &mut budget).unwrap();
        parser.allow_in = false;
        let error = parser.parse_body().unwrap_err();
        if unsupported {
            assert!(error.is_unsupported(), "{source}: {error:?}");
        } else {
            assert!(error.is_parse_error(), "{source}: {error:?}");
        }
        assert!(!parser.allow_in && !parser.strict && !parser.in_class);
        assert!(!parser.super_call_allowed);
        assert!(!parser.super_property_allowed && !parser.super_property_deferred);
        assert!(parser.compile_budget.steps < budget.steps);
    }
    let source = format!("({{m(){{{}return super[key];}}}});", ";".repeat(200));
    let mut budget = regexp::Budget {
        steps: MAX_STEPS,
        allocated: 0,
        heap_limit: MAX_HEAP,
        stack_limit: 16,
    };
    let mut parser = Parser::start(&source, false, false, &mut budget).unwrap();
    parser.allow_in = false;
    parser.compile_budget.steps = 64;
    let error = parser.parse_body().unwrap_err();
    assert!(error.is_resource_limit());
    assert_eq!(parser.compile_budget.steps, 0);
    assert!(!parser.allow_in && !parser.strict && !parser.in_class);
    assert!(!parser.super_call_allowed);
    assert!(!parser.super_property_allowed && !parser.super_property_deferred);
}
