"""Author a held replay adaptation with stdlib and read-only Git; never execute it."""
from pathlib import Path
from collections import Counter
import ast
import difflib
import hashlib
import json
import re
import subprocess

P = Path(__file__).resolve().parent
L = P.parent
W = L / 'worktree'
K = Path('/tmp/eris-super-properties-plan-1')
OLD = K / 'profile-replay-3'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def bind(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=sha(data))

def put(name, data):
    (P / name).write_text(json.dumps(data, indent=2) + '\n')

def bound_json(binding):
    path = Path(binding['path'])
    assert bind(path) == binding
    return json.loads(path.read_bytes())

def canonical(value):
    return sha(json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode())

old = json.loads((OLD / 'contract.json').read_bytes())
contract = json.loads((OLD / 'contract.json').read_bytes())
prior = json.loads((K / 'root/profile-replay-1.json').read_bytes())
assert (K / 'root/profile-replay-1.json').read_bytes() == (K / 'root/profile-replay-1-recheck.json').read_bytes()
assert prior['status'] == 'pass' and prior['expected_cases'] == 1330 and prior['expected_controls'] == 724
assert prior['baseline_writes'] is False
assert not any(prior['transition_counts'].values())
parent = json.loads((L / 'source-parent.json').read_bytes())
assert parent['base'] == BASE
parent_files = {row['path']: row for row in parent['files']}
assert len(parent_files) == len(parent['files']) == 15289
selection = json.loads((L / 'root/selection-1.json').read_bytes())
assert selection['base'] == BASE
assert selection['reference_source_inventory'] == bind(K / 'source-candidate-2.json')
prior_inventory = json.loads((K / 'source-candidate-2.json').read_bytes())
assert prior_inventory['files'] == parent['files']
# Read-only Git tree establishes the published base independently of working files.
tree_bytes = subprocess.check_output(['git', 'ls-tree', '-r', '-z', BASE], cwd=W)
tracked = {}
for entry in tree_bytes.split(b'\0'):
    if not entry:
        continue
    meta, path = entry.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    tracked[path.decode()] = dict(mode=mode, kind=kind, oid=oid)
immutable = {item['path']: item for item in contract['immutable_published_inputs']}
assert len(immutable) == len(contract['immutable_published_inputs']) == 14371
for relative, item in immutable.items():
    path = W / relative
    data = path.read_bytes()
    assert not path.is_symlink()
    assert dict(bind(path), path=relative) == item == parent_files[relative]
    assert tracked[relative]['kind'] == 'blob' and tracked[relative]['mode'] in ('100644', '100755')
    assert hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() == tracked[relative]['oid']
for root in contract['exact_tree_roots']:
    expected = {name for name in immutable if name.startswith(root + '/')}
    assert expected == {name for name in tracked if name.startswith(root + '/')}
    entries = list((W / root).rglob('*'))
    assert all(not path.is_symlink() and (path.is_file() or path.is_dir()) for path in entries)
    assert expected == {str(path.relative_to(W)) for path in entries if path.is_file()}
    expected_dirs = {str(parent_path) for name in expected for parent_path in Path(name).parents
                     if str(parent_path).startswith(root + '/')}
    assert expected_dirs == {str(path.relative_to(W)) for path in entries if path.is_dir()}
closure = sorted(name for name in tracked if name.startswith(('src/', 'crates/', 'assets/', 'shaders/'))
                 or name in {'Cargo.toml', 'Cargo.lock', 'build.rs'})
assert set(old['tracked_runtime_closure']).issubset(closure)
assert set(closure).issubset(parent_files)
contract['base'] = BASE
contract['predecessor'] = bind(K / 'root/profile-replay-1.json')
contract['predecessor_contract'] = bind(OLD / 'contract.json')
contract['tracked_runtime_closure'] = closure
contract['root_runner'] = bind(L / 'run-tool.py')
assert (L / 'run-tool.py').read_bytes() == (K / 'run-tool.py').read_bytes()
contract['commands'] = [
    'python3 -B ' + str(P / 'replay.py') + ' --selection ' + str(L / 'root/profile-selection-1.json') + ' --attempt 1',
    'python3 -B ' + str(P / 'replay.py') + ' --selection ' + str(L / 'root/profile-selection-1.json') + ' --attempt 1 --check-only',
]
prior_rows = {row['name']: row for row in prior['profiles']}
profiles = []
policies = {}
source_rows = {}
policy_counts = Counter()
counts = Counter()
observed_host = 0
for profile in contract['profiles']:
    original = next(row for row in old['profiles'] if row['name'] == profile['name'])
    prior_row = prior_rows[profile['name']]
    assert prior_row['errors'] == []
    before = bound_json(original['reference_report'])
    report = bound_json(prior_row['report'])
    receipt = bound_json(prior_row['receipt'])
    log = Path(prior_row['log']['path'])
    assert bind(log) == prior_row['log'] and sha(log.read_bytes()) == receipt['sha256']
    assert receipt['log'] == log.name
    assert Path(prior_row['report']['path']) == K / ('upstream-super-' + profile['name'] + '-1.json')
    assert len(report['cases']) == profile['cases'] and len(report['harness_preflight']) == profile['controls']
    assert report['harness_preflight_passed'] is True
    assert all(control['verified'] is True for control in report['harness_preflight'])
    assert report['cases'] == before['cases'] and report['harness_preflight'] == before['harness_preflight']
    assert report['runner_policy'] == profile['policy']
    assert report['runner_policy_sha256'] == profile['policy_sha256']
    assert sha(json.dumps(profile['policy'], sort_keys=True).encode()) == profile['policy_sha256']
    assert report['corpus_manifest_sha256'] == profile['corpus_manifest_sha256']
    assert report['counts'] == dict(Counter(row['status'] for row in report['cases']))
    counts.update(report['counts'])
    binary = prior['binaries'][profile['binary_kind']]
    assert report['binary'] == binary['binary']['path']
    assert report['binary_sha256'] == binary['binary']['sha256']
    assert receipt['command'][1:] == ['-B', 'tools/test262_conformance.py', '--binary', report['binary'],
        '--profile', profile['profile'], '--output', prior_row['report']['path'], '--jobs', '1', '--timeout', '3.0']
    assert receipt['exit'] == (0 if all(row['status'] == 'passed' for row in report['cases']) else 1)
    for field, key in [('reference_report', 'report'), ('reference_receipt', 'receipt'), ('reference_log', 'log')]:
        profile[field] = prior_row[key]
    if profile['binary_kind'] == 'host':
        table = {}
        for case in report['cases']:
            relative = profile['corpus'] + '/' + case['file']
            data = (W / relative).read_bytes()
            assert sha(data) == case['source_sha256'] == immutable[relative]['sha256']
            blocks = re.findall(r'/\*---(.*?)---\*/', data.decode('utf-8'), re.S)
            assert len(blocks) == 1
            lines = re.findall(r'^flags:[ \t]*(.*)$', blocks[0], re.M)
            assert len(lines) <= 1
            flags_text = lines[0].strip() if lines else '[]'
            assert re.fullmatch(r'\[[^\]\n]*\]', flags_text)
            flags = [word.strip().strip("'\"") for word in flags_text[1:-1].split(',') if word.strip()]
            assert all(re.fullmatch(r'[A-Za-z][A-Za-z0-9_-]*', flag) for flag in flags)
            policy = int('async' in flags)
            assert case['id'] not in table
            table[case['id']] = policy
            policy_counts[policy] += 1
            if 'observation' in case:
                assert case['observation']['completion']['policy'] == policy
                observed_host += 1
            record = dict(path=relative, bytes=len(data), sha256=sha(data), flags=flags,
                          completion_policy=policy, frontmatter_sha256=sha(blocks[0].encode()))
            assert relative not in source_rows or source_rows[relative] == record
            source_rows[relative] = record
        assert table == old['case_completion_policies'][profile['profile']]
        policies[profile['profile']] = table
    profiles.append(dict(name=profile['name'], profile=profile['profile'], binary_kind=profile['binary_kind'],
        reference_report=profile['reference_report'], reference_receipt=profile['reference_receipt'],
        reference_log=profile['reference_log'], cases=profile['cases'], controls=profile['controls'],
        counts=report['counts'], observed_exit=receipt['exit'],
        full_cases_sha256=canonical(report['cases']), full_controls_sha256=canonical(report['harness_preflight']),
        policy_sha256=profile['policy_sha256'], corpus_manifest_sha256=profile['corpus_manifest_sha256']))
assert counts == {'passed': 1258, 'failed': 64, 'unsupported': 8}
assert sum(row['cases'] for row in profiles) == 1330
assert sum(row['controls'] for row in profiles) == 724
assert len(source_rows) == 637 and sum(map(len, policies.values())) == 1268
assert policies == old['case_completion_policies']
# The reviewed algorithm and local root variable are deliberately preserved.
edits = [
    dict(name='new checkpoint receipt labels', before="        label = 'super-profile-' + profile['name'] + '-' + str(args.attempt)\n",
         after="        label = 'object-super-profile-' + profile['name'] + '-' + str(args.attempt)\n"),
    dict(name='new checkpoint report names', before="        report_path = K / ('upstream-super-' + profile['name'] + '-' + str(args.attempt) + '.json')\n",
         after="        report_path = K / ('upstream-object-super-' + profile['name'] + '-' + str(args.attempt) + '.json')\n"),
]
before = (OLD / 'replay.py').read_text()
after = before
for edit in edits:
    assert after.count(edit['before']) == 1
    after = after.replace(edit['before'], edit['after'])
ast.parse(after)
inverse = after
for edit in reversed(edits):
    assert inverse.count(edit['after']) == 1
    inverse = inverse.replace(edit['after'], edit['before'])
assert inverse == before
(P / 'replay.py').write_text(after)
put('contract.json', contract)
for name, a, b in [('replay.py', before, after), ('contract.json', (OLD / 'contract.json').read_text(), (P / 'contract.json').read_text())]:
    (P / (name + '.diff')).write_text(''.join(difflib.unified_diff(a.splitlines(True), b.splitlines(True),
        fromfile='K/profile-replay-3/' + name, tofile='L/profile-replay-1/' + name)))
def functions(source):
    lines = source.splitlines(True)
    return {node.name: ''.join(lines[node.lineno-1:node.end_lineno])
            for node in ast.parse(source).body if isinstance(node, ast.FunctionDef)}
old_functions, new_functions = functions(before), functions(after)
changed = [name for name in old_functions if old_functions[name] != new_functions[name]]
assert changed == ['main'] and set(old_functions) == set(new_functions)
changed_fields = [key for key in contract if old.get(key) != contract[key]]
assert set(changed_fields) == {'base','predecessor','predecessor_contract','profiles','tracked_runtime_closure','root_runner','commands'}
put('delta.json', dict(original_hold=bind(OLD / 'source-ready.json'), original_runner=bind(OLD / 'replay.py'),
    original_contract=bind(OLD / 'contract.json'), original_peer=bind(K / 'profile-replay-review-3/review.json'),
    edits=edits, whole_source_inverse=True, changed_functions=changed,
    unchanged_functions=[name for name in old_functions if name not in changed],
    contract_changed_fields=changed_fields, old_runtime_closure=len(old['tracked_runtime_closure']),
    published_runtime_closure=len(closure), added_published_runtime_paths=sorted(set(closure)-set(old['tracked_runtime_closure'])),
    unchanged_profile_fields=[key for key in contract['profiles'][0] if key not in ('reference_report','reference_receipt','reference_log')],
    same_case_policy_table=True, same_immutable_14371_pins=True, same_complete_predecessor_case_and_control_arrays=True,
    qualification='Internal K variable is the dynamic checkpoint root P.parent, now L. Only two output-label literals change in executable source. No candidate outcomes are used.'))
put('predecessor-census.json', dict(base=BASE, predecessor=contract['predecessor'],
    recheck=bind(K / 'root/profile-replay-1-recheck.json'), final_ledger=bind(K / 'root/final-validation.json'),
    published_source=bind(K / 'source-candidate-2.json'), parent_source=bind(L / 'source-parent.json'),
    previous_recipe=bind(OLD / 'source-ready.json'), previous_recipe_peer=bind(K / 'profile-replay-review-3/review.json'),
    profiles=profiles, cases=1330, controls=724, counts=dict(counts),
    qualification='These are measured published predecessor outcomes, not predicted candidate totals. Six profiles exited 1 with retained failures; the withResolvers and Try commands exited 0.'))
put('metadata-policy-census.json', dict(base=BASE, host_modes=1268, unique_sources=637, policy_counts=dict(policy_counts),
    previously_observed_host_rows=observed_host, previously_unobserved_host_rows=1268-observed_host,
    sources=list(source_rows.values()),
    qualification='Closed authenticated source census: flags are absent or single-line YAML flow lists. No project parser imported; no general YAML implementation claimed. Every future observed host case policy is checked against these fixed values.'))
put('required-inputs.json', dict(status='Prospective inputs only; no candidate source or build success is claimed.',
    base=BASE, source_inventory='Root must select and bind its final complete {base,scope,files} inventory; filename is not hardcoded and candidate 1 is not implicitly selected.',
    selection_example_path=str(L / 'root/profile-selection-1.json'), selection_schema=contract['selection_schema'],
    sidecar_fields=contract['binary_schema'],
    builds=[dict(kind=kind, toolchain=contract['expected_builds'][kind]['toolchain'], features=contract['expected_builds'][kind]['features'],
        binary=str(L / target / 'release/eris-js'), planned_label='candidate-release-' + kind + '-1',
        command=['python3','-B',str(L / 'root/run-config.py'),'candidate-release-' + kind + '-1',config,'build','--release','--bin','eris-js'],
        required='Actual successful build receipt, environment receipt, rustc release, exact command and log hash; same explicitly selected final source inventory in both binary sidecars.')
        for kind,target,config in [('ordinary','target-msrv','msrv'),('host','target-1990','host')]],
    root_runner=bind(L / 'run-tool.py'), root_build_wrapper=bind(L / 'root/run-config.py'),
    wrapper_qualification='Root build wrapper is pinned as authoring context; executed build command/environment/output joins are enforced by the inherited replay checks. Build labels are recommendations, not invented completed receipts.',
    commands=contract['commands'],
    execution='Root only, serial eight-profile execution with jobs 1 / timeout 3.0. Then separate --check-only recheck of retained reports/receipts; no recipe execution by author.',
    outputs=['upstream-object-super-{name}-{attempt}.json','validation/object-super-profile-{name}-{attempt}.{json,log}','root/profile-replay-{attempt}.json','root/profile-replay-{attempt}-recheck.json'],
    acceptance='No baseline option or mutation; all full transitions retained. Changed control records, prior passed-case regressions, schema/source/protocol/policy/provenance inconsistencies and infrastructure failures block acceptance. Other observed transitions remain explicit, not predicted.',
    pending=['Final explicitly selected source inventory binding','Actual ordinary and host successful release build/environment receipts','Direct release output byte bindings and binary sidecars','Root selection JSON binding those three inputs'],
    project_execution=False, candidate_results_read=False))
put('source-checks.json', dict(status='Source-only author checks complete; independent peer pending.',
    bound_base=BASE, exact_parent_source_rows=15289, immutable_published_files=14371,
    immutable_git_blob_and_hash_matches=14371, exact_immutable_trees=contract['exact_tree_roots'],
    published_runtime_closure=len(closure), source_schema_required=True,
    exact_runner_inverse=True, changed_functions=changed, unchanged_functions=len(old_functions)-1,
    cases=1330, controls=724, host_policy_rows=1268, host_policy_counts=dict(policy_counts),
    preserved_safeguards=[
        'Exact type-aware full case and control arrays, policy and identity checks, recursively validated canonical prerequisite graph.',
        'Raw Resource/harness-error refusals independent of classified status; deliberate expected resource controls remain exact.',
        'Every observed host completion policy equals authenticated source async flags, including six previously excluded host modes.',
        'Exact immutable tools/corpus/baseline file and directory closure; symlink/special entry/unknown file refusal.',
        'Final selected source inventory checked before/after every serial command; complete runtime directories plus published tracked build closure.',
        'Binary sidecars must bind the same final source, successful exact commands, environment and direct canonical release output paths/bytes.',
        'Changed controls and prior pass regressions block; all other actual case transitions are retained in full; no baseline writes.',
        'Exclusive output creation and attempt-specific labels retain failed attempts; --check-only rereads actual reports without rerunning project code.'
    ],
    no_candidate_inventory_preselected=True, no_completed_release_bindings_invented=True,
    project_imports=False, project_execution=False, replay_execution=False, live_edits=False))
files=[dict(bind(path),path=path.name) for path in sorted(P.iterdir()) if path.is_file() and path.name!='source-ready.json']
put('source-ready.json', dict(format=1,status='Sealed held source-only eight-profile replay recipe; root execution inputs pending.',
    base=BASE, selection=bind(L / 'root/selection-1.json'), parent_source=bind(L / 'source-parent.json'),
    previous_recipe=bind(OLD / 'source-ready.json'), previous_peer=bind(K / 'profile-replay-review-3/review.json'),
    contract=bind(P / 'contract.json'), runner=bind(P / 'replay.py'), delta=bind(P / 'delta.json'),
    required_inputs=bind(P / 'required-inputs.json'), predecessor_census=bind(P / 'predecessor-census.json'),
    metadata_census=bind(P / 'metadata-policy-census.json'), checks=bind(P / 'source-checks.json'),
    files=files, profiles=8,cases=1330,controls=724,host_case_policy_bindings=1268,
    baseline_writes=False,project_execution=False,live_edits=False,candidate_results_read=False))
print(json.dumps(bind(P / 'source-ready.json')))
