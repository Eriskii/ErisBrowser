"""Seal held documentation after checking actual data; no project execution."""
from pathlib import Path
from collections import Counter
import difflib,hashlib,json,re
P=Path(__file__).resolve().parent;L=P.parent;D=L/'documentation-1';W=L/'worktree'
def bind(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def put(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def canon(v):return hashlib.sha256(json.dumps(v,sort_keys=True,separators=(',',':')).encode()).hexdigest()
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
verified={}
def check_binding(row):
 path=Path(row['path']);actual=bind(path);assert actual=={k:row[k] for k in ['path','bytes','sha256']};verified[str(path)]=actual
 return path
def walk(v):
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and isinstance(v['path'],str) and v['path'].startswith('/'):
   check_binding(v)
  for child in v.values():walk(child)
 elif isinstance(v,list):
  for child in v:walk(child)
ledger_path=L/'root/final-validation.json';ledger=json.loads(ledger_path.read_bytes())
assert bind(ledger_path)==dict(path=str(ledger_path),bytes=33757,sha256='f1765e41d488a383ca1a56e11dfca372316a1ca4a5ea0f21e7e6babc1cd18bf3')
assert ledger['status']=='pass' and ledger['base']=='db880b867daa2ec7bfc82cb2041aec935d5b8189'
walk(ledger)
assert ledger['source_inventory']==bind(L/'source-candidate-3.json')
inv=json.loads(check_binding(ledger['source_inventory']).read_bytes())
assert len(inv['files'])==ledger['selected_inputs']==15297
assert len({r['path'] for r in inv['files']})==15297
for row in inv['files']:
 assert dict(bind(W/row['path']),path=row['path'])==row
snap=json.loads(check_binding(ledger['source_snapshots']).read_bytes())
assert len(snap['files'])==ledger['changed_source_paths']==15
for row in snap['files']:assert dict(bind(Path(snap['root'])/row['path']),path=row['path'])==row
attempts={a['label']:a for a in ledger['attempts']};assert len(attempts)==26
runs=[]
for label in ledger['accepted_labels']:
 row=attempts[label];assert row['accepted'] is True and row['exit']==0
 receipt=json.loads(check_binding(row['receipt']).read_bytes());log=check_binding(row['log'])
 assert receipt['exit']==row['exit'] and receipt['command']==row['command']
 assert receipt['sha256']==row['log']['sha256'] and receipt['log']==log.name
 text=log.read_text();results=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$',text,re.M)
 if label in ('candidate-full-msrv-2','candidate-full-host-vulkan-1'):
  total=3485 if label=='candidate-full-msrv-2' else 3849
  assert len(results)==56 and all(r[0]=='ok' and r[2:] == ('0','0') for r in results)
  assert sum(int(r[1]) for r in results)==total
  names=re.findall(r'^test (.+) \.\.\. ok$',text,re.M);assert len(names)==total and len(set(names))==total
  assert row['tests']==dict(suites=56,passed=total,failed=0,ignored=0)
  runs.append(dict(label=label,receipt=row['receipt'],log=row['log'],suites=56,passed=total,failed=0,ignored=0,complete_ok_roster_sha256=canon(names)))
for label,expected in [('parent-public-1',(10,31)),('candidate-object-msrv-1',(47,1)),('candidate-full-msrv-1',(3138,1))]:
 row=attempts[label];text=Path(row['log']['path']).read_text();rs=re.findall(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;.*$',text,re.M)
 assert len(rs)==1 and (int(rs[0][1]),int(rs[0][2]))==expected
assert ledger['new_coverage']==dict(public_groups=41,public_modes=82,exact_js_fields=80,parser_groups=6,capture_groups=4,capture_measured_calls=58,browser_groups=2)
assert sum(ledger['new_coverage'][k] for k in ['public_groups','parser_groups','capture_groups','browser_groups'])==53
profile_paths=[check_binding(x) for x in ledger['profiles']]
assert len(profile_paths)==2 and profile_paths[0].read_bytes()==profile_paths[1].read_bytes()
summary=json.loads(profile_paths[0].read_bytes());walk(summary)
assert summary['status']=='pass' and summary['expected_cases']==1330 and summary['expected_controls']==724
assert summary['source_inventory']==ledger['source_inventory'] and summary['baseline_writes'] is False
assert not any(summary['transition_counts'].values()) and summary['transition_counts']==ledger['profile_transition_counts']
assert summary['counts']==ledger['profile_counts']==dict(passed=1258,failed=64,unsupported=8)
profile_rows=[];total_cases=total_controls=0;counts=Counter()
for row in summary['profiles']:
 old=json.loads(check_binding(row['before']).read_bytes());new=json.loads(check_binding(row['report']).read_bytes())
 assert old['cases']==new['cases'] and old['harness_preflight']==new['harness_preflight']
 assert old['runner_policy']==new['runner_policy'] and old['runner_policy_sha256']==new['runner_policy_sha256']
 assert old['corpus_manifest_sha256']==new['corpus_manifest_sha256']
 assert row['errors']==[] and row['case_arrays_equal'] is True and row['control_arrays_equal'] is True
 assert new['harness_preflight_passed'] is True and all(x['verified'] is True for x in new['harness_preflight'])
 assert len(new['cases'])==row['cases'] and len(new['harness_preflight'])==row['controls']
 assert new['counts']==dict(Counter(x['status'] for x in new['cases']))
 counts.update(new['counts']);total_cases+=row['cases'];total_controls+=row['controls']
 profile_rows.append(dict(name=row['name'],profile=row['profile'],before=row['before'],report=row['report'],
  cases=row['cases'],controls=row['controls'],counts=row['counts'],observed_exit=row['observed_exit'],
  complete_cases_sha256=canon(new['cases']),complete_controls_sha256=canon(new['harness_preflight']),
  policy_sha256=new['runner_policy_sha256']))
assert (total_cases,total_controls)==(1330,724) and dict(counts)==ledger['profile_counts']
assert len(profile_rows)==8
# Check direct binary bytes and same-source provenance already bound in summary.
for kind,item in summary['binaries'].items():
 assert item['record']['source_inventory']==ledger['source_inventory']
 target='target-msrv' if kind=='ordinary' else 'target-1990'
 assert item['binary']['path']==str(L/target/'release/eris-js')
 assert bind(Path(item['binary']['path']))==item['binary']
 assert item['record']['toolchain']==('1.88.0' if kind=='ordinary' else '1.99.0')
 assert item['record']['features']==([] if kind=='ordinary' else ['test262-host'])
# Freeze draft1 unchanged and reuse its exact four existing-document edits.
draft=json.loads((D/'draft-ready.json').read_bytes())
for item in draft['artifacts']:
 path=D/item['path'];assert dict(bind(path),path=item['path'])==item
prep=json.loads((P/'preparation.json').read_bytes())
for row in prep['files']:check_binding(row['raw'])
chapter_path=P/'raw/docs/object-super-properties.md';prepared=chapter_path.read_text()
assert 'Logical assignments skip both the right-hand\nside and the write when they short-circuit.' in prepared
suffix='''
Final validation passes **3,485 tests with Rust 1.88 default features** and
**3,849 with Rust 1.99 and `test262-host,vulkan-raster`**, with no failures or
ignored tests across 56 suites in each run. Both final strict Clippy checks and
rustfmt pass. The 53 added groups comprise 41 independent public groups in 82
sloppy/strict modes, six parser groups, four private groups covering 58 measured
home-attachment calls, and two browser witnesses. The browser checks exercise
direct Page and confined-worker behavior; native-plan assertions run on the CPU.
No hardware GPU check was added.

The evidence retains the parent public result of ten passing and 31 failing
groups and the parent browser failure. The first candidate focused run passed
47 groups and failed one: the frozen optional-chain source was classified as
SyntaxError. The bounded prefix correction described above keeps that original
oracle. The first full attempt then stopped after 3,138 library passes and one
failure in an older aggregate test. Its exact object-method `super` literal
moved from an Unsupported list to a successful parse assertion; every other
row and all production bytes were retained. These failures remain recorded.

Temporary toolchain and Cargo-cache restoration were needed before the final
lint checks; the preflight/dependency failures did not require source changes.
The source review also retains a checker correction for one optional trailing
comma removed by rustfmt. That correction changed no source or test oracle.

Fresh ordinary and host release binaries replay all eight published profiles:
**1,330 cases comprise 1,258 passed, 64 failed and eight unsupported**. Every
complete case record and all **724 control records** match the published
`db880b86` predecessor exactly, including raw observations and classifications.
There are no transitions, prior-pass regressions or control changes. The
comparison recheck is byte-identical to the first summary. Existing failed and
unsupported outcomes remain visible; six profile commands return their expected
nonzero status for those failures. No baseline was rewritten.

The [evidence manifest](evidence/object-super-properties/manifest.json) and
[retained sources and checks](evidence/object-super-properties/sources-and-checks.tar.gz)
bind the final 15 changed source paths, independent contracts, retained attempts,
release provenance and complete replay comparisons. The 15,297 selected inputs
include unchanged tooling and authenticated corpora; this inventory is not a
self-contained external build graph.
'''
chapter_path.write_text(prepared+suffix)
write(P/'final-validation-addition.md',suffix.encode())
rows=[]
for oldrow in draft['files']:
 relative=oldrow['relative_path'];raw=P/'raw'/relative;before=P/'before'/relative
 if relative!='docs/object-super-properties.md':assert raw.read_bytes()==(D/'raw'/relative).read_bytes()
 old=before.read_text() if before.exists() else ''
 diff=P/'diffs'/(relative.replace('/','__')+'.diff')
 write(diff,''.join(difflib.unified_diff(old.splitlines(True),raw.read_text().splitlines(True),fromfile='a/'+relative if before.exists() else '/dev/null',tofile='b/'+relative)).encode())
 draftdiff=P/'from-draft-1'/(relative.replace('/','__')+'.diff')
 write(draftdiff,''.join(difflib.unified_diff((D/'raw'/relative).read_text().splitlines(True),raw.read_text().splitlines(True),fromfile='draft1/'+relative,tofile='final2/'+relative)).encode())
 rows.append(dict(relative_path=relative,before=bind(before) if before.exists() else None,raw=bind(raw),diff=bind(diff),from_draft=bind(draftdiff)))
# Exact final chapter inverse and historical preservation.
inverse=chapter_path.read_text();assert inverse.endswith(suffix);inverse=inverse[:-len(suffix)]
for edit in reversed(json.loads((P/'prose-edits.json').read_bytes())):
 assert inverse.count(edit['after'])==1;inverse=inverse.replace(edit['after'],edit['before'])
assert inverse==(D/'raw/docs/object-super-properties.md').read_text()
marker='The subsequent [Promise class-admission checkpoint]'
a=(P/'before/docs/classes.md').read_text();b=(P/'raw/docs/classes.md').read_text();assert a[a.index(marker):]==b[b.index(marker):]
marker='Final validation passes **3,432'
a=(P/'before/docs/class-super-properties.md').read_text();b=(P/'raw/docs/class-super-properties.md').read_text();assert a[a.index(marker):]==b[b.index(marker):]
oldclaims=json.loads((D/'claims-and-bindings.json').read_bytes());check_binding(oldclaims['untouched_validation'])
links=[]
for label,url in re.findall(r'\[([^\]]+)\]\(([^)]+)\)',chapter_path.read_text()):
 if url.startswith('https://'):
  assert url in [x['url'] for x in json.loads((P/'primary-links.json').read_bytes())['sources']];state='Official primary specification link checked during preparation.'
 elif url.startswith('evidence/object-super-properties/'):
  assert url in ['evidence/object-super-properties/manifest.json','evidence/object-super-properties/sources-and-checks.tar.gz'];state='Selected root publication destination; archive/manifest produced after documentation peer.'
 else:
  assert (W/'docs'/url).is_file();state='Existing repository document.'
 links.append(dict(label=label,url=url,state=state))
put('links.json',links)
put('claims-and-checks.json',dict(status='Final documentation claims checked against actual sealed evidence; independent peer pending.',
 base=ledger['base'],final_ledger=bind(ledger_path),source_inventory=ledger['source_inventory'],source_snapshots=ledger['source_snapshots'],
 source_review=bind(L/'candidate-source-review-1/candidate3-addendum.json'),
 immutable_draft=bind(D/'draft-ready.json'),full_runs=runs,accepted_labels=ledger['accepted_labels'],
 new_coverage=ledger['new_coverage'],replay=ledger['profiles'],profile_rows=profile_rows,
 total_cases=1330,total_controls=724,counts=dict(counts),transitions=ledger['profile_transition_counts'],
 retained_failures=ledger['retained_failures'],environment_recovery=ledger['environment_recovery'],source_checker_correction=ledger['source_checker_correction'],
 binary_selection=ledger['binary_selection'],verified_evidence_bindings=list(verified.values()),
 complete_inventory_hashes_checked=15297,exact_final_snapshot_hashes_checked=15,
 exact_four_existing_doc_draft_bytes=True,exact_chapter_inverse=True,historical_classes_suffix_exact=True,
 historical_class_super_validation_suffix_exact=True,validation_document_unchanged=oldclaims['untouched_validation'],
 links=bind(P/'links.json'),primary_links=bind(P/'primary-links.json'),
 final_chapter_words=len(chapter_path.read_text().split()),
 qualification='Source/log/report reads and stdlib comparisons only; independent final evidence peer remains separately owned. No project execution, live edits, old-hold writes or new whole-browser/security/performance/GPU claim.'))
artifacts=[dict(bind(p),path=str(p.relative_to(P))) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',dict(schema=1,status='Sealed final five-file documentation hold; independent peer pending.',
 base=ledger['base'],supersedes_draft=bind(D/'draft-ready.json'),
 final_ledger=bind(ledger_path),source_inventory=ledger['source_inventory'],source_review=bind(L/'candidate-source-review-1/candidate3-addendum.json'),
 files=rows,path_count=5,claims=bind(P/'claims-and-checks.json'),links=bind(P/'links.json'),artifacts=artifacts,
 final_counts=dict(default_passed=3485,host_vulkan_passed=3849,suites_each=56,failed_each=0,ignored_each=0,cases=1330,controls=724),
 historical_text_preserved=True,draft1_unchanged=True,project_execution=False,live_edits=False))
print(json.dumps(bind(P/'source-ready.json')))
