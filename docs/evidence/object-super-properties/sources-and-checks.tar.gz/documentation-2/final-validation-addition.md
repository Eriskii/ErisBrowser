
Final validation passes **3,485 tests with Rust 1.88 default features** and
**3,849 with Rust 1.99 and `test262-host,vulkan-raster`**, with no failures or
ignored tests across 56 suites in each run. Both final strict Clippy checks and
rustfmt pass. The 53 added groups comprise 41 independent public groups in 82
sloppy/strict modes, six parser groups, four private groups covering 58 measured
home-attachment calls, and two browser witnesses. The browser checks exercise
direct Page and confined-worker behavior; native-plan assertions run on the CPU.
No hardware GPU check was added.

The evidence retains the parent public result of ten passing and 31 failing
groups and the parent browser failure. The first candidate focused run passed
47 groups and failed one: the frozen optional-chain source was classified as
SyntaxError. The bounded prefix correction described above keeps that original
oracle. The first full attempt then stopped after 3,138 library passes and one
failure in an older aggregate test. Its exact object-method `super` literal
moved from an Unsupported list to a successful parse assertion; every other
row and all production bytes were retained. These failures remain recorded.

Temporary toolchain and Cargo-cache restoration were needed before the final
lint checks; the preflight/dependency failures did not require source changes.
The source review also retains a checker correction for one optional trailing
comma removed by rustfmt. That correction changed no source or test oracle.

Fresh ordinary and host release binaries replay all eight published profiles:
**1,330 cases comprise 1,258 passed, 64 failed and eight unsupported**. Every
complete case record and all **724 control records** match the published
`db880b86` predecessor exactly, including raw observations and classifications.
There are no transitions, prior-pass regressions or control changes. The
comparison recheck is byte-identical to the first summary. Existing failed and
unsupported outcomes remain visible; six profile commands return their expected
nonzero status for those failures. No baseline was rewritten.

The [evidence manifest](evidence/object-super-properties/manifest.json) and
[retained sources and checks](evidence/object-super-properties/sources-and-checks.tar.gz)
bind the final 15 changed source paths, independent contracts, retained attempts,
release provenance and complete replay comparisons. The 15,297 selected inputs
include unchanged tooling and authenticated corpora; this inventory is not a
self-contained external build graph.
