"""Prepare documentation prose only. Final evidence seal is a later operation."""
from pathlib import Path
import json,hashlib,difflib
P=Path(__file__).resolve().parent;L=P.parent;D=L/'documentation-1'
def bind(p):
 data=p.read_bytes();return dict(path=str(p),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def put(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def write(p,data):p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
seal=json.loads((D/'draft-ready.json').read_bytes())
for row in seal['artifacts']:
 p=D/row['path'];assert dict(bind(p),path=row['path'])==row
paths=[row['relative_path'] for row in seal['files']]
assert len(paths)==5
edits=[
 dict(reason='Primary method creation/home algorithms',
 before='Each method retains the actual object where it was defined as its home.\n',
 after='Each method retains the actual object where it was defined as its home.\nThe [DefineMethod](https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-method-definitions-runtime-semantics-definemethod)\nand [MakeMethod](https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-makemethod)\nalgorithms describe method creation and attachment of that home.\n'),
 dict(reason='Primary SuperProperty ordering algorithm',
 before="During property evaluation, the receiver is captured before a computed key's\neffects, and the home prototype is captured after those effects. The raw key\n",
 after="The [SuperProperty evaluation algorithm](https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword)\ncaptures the receiver before a computed key's effects and the home prototype\nafter those effects. The raw key\n"),
 dict(reason='Explicitly state both omitted short-circuit operations',
 before='the key converted for their read. Logical assignments omit the right-hand side\nand write when they short-circuit. Calls preserve the receiver through\n',
 after='the key converted for their read. Logical assignments skip both the right-hand\nside and the write when they short-circuit. Calls preserve the receiver through\n'),
]
rows=[]
for relative in paths:
 raw=(D/'raw'/relative).read_bytes();new=raw
 if relative=='docs/object-super-properties.md':
  text=raw.decode()
  for edit in edits:
   assert text.count(edit['before'])==1;text=text.replace(edit['before'],edit['after'])
  inverse=text
  for edit in reversed(edits):
   assert inverse.count(edit['after'])==1;inverse=inverse.replace(edit['after'],edit['before'])
  assert inverse.encode()==raw
  new=text.encode()
 before=D/'before'/relative
 if before.exists():write(P/'before'/relative,before.read_bytes())
 write(P/'raw'/relative,new)
 diff=P/'diffs'/(relative.replace('/','__')+'.diff')
 before_text=before.read_text() if before.exists() else ''
 write(diff,''.join(difflib.unified_diff(before_text.splitlines(True),new.decode().splitlines(True),fromfile='a/'+relative if before.exists() else '/dev/null',tofile='b/'+relative)).encode())
 rows.append(dict(relative_path=relative,before=bind(P/'before'/relative) if before.exists() else None,raw=bind(P/'raw'/relative),diff=bind(diff),same_as_draft1=new==raw))
put('prose-edits.json',edits)
put('primary-links.json',dict(checked='2026-10-21 via official TC39 primary pages; ECMAScript 2027 draft',
 sources=[
 dict(name='DefineMethod',url='https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-method-definitions-runtime-semantics-definemethod',section='15.4.4',supports='Property-name evaluation precedes function creation; the resulting closure is attached to the defining object through MakeMethod.'),
 dict(name='MakeMethod',url='https://tc39.es/ecma262/multipage/ordinary-and-exotic-objects-behaviours.html#sec-makemethod',section='10.2.7',supports='Stores the supplied defining object in the function home slot.'),
 dict(name='SuperProperty evaluation',url='https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-super-keyword',section='13.3.7.1 and 13.3.7.3',supports='Gets the this binding, evaluates the raw key, then forms the super reference from the live base. The note explicitly delays property-key conversion for simple assignment until after the RHS.')],
 qualification='Links support the selected semantics; no claim that the implementation covers every grammar form or the whole standard.'))
put('preparation.json',dict(status='Unsealed final-doc preparation; final ledger required before source-ready.',
 base='db880b867daa2ec7bfc82cb2041aec935d5b8189',source_inventory=bind(L/'source-candidate-3.json'),
 source_review=bind(L/'candidate-source-review-1/candidate3-addendum.json'),
 immutable_draft=bind(D/'draft-ready.json'),files=rows,
 prose_edits=bind(P/'prose-edits.json'),primary_links=bind(P/'primary-links.json'),
 pending_ledger=str(L/'root/final-validation.json'),
 evidence_paths=['docs/evidence/object-super-properties/manifest.json','docs/evidence/object-super-properties/sources-and-checks.tar.gz'],
 root_reported_results_not_yet_sealed_as_doc_claims={'default_passed':3485,'host_vulkan_passed':3849,'result_rows_each':56,'failed_each':0,'ignored_each':0,'both_clippy_and_fmt':'pass'},
 no_profile_outcome_assumption=True,live_edits=False,project_execution=False,draft1_modified=False))
print(json.dumps(bind(P/'preparation.json')))
