from pathlib import Path
import hashlib
import json
import re

L = Path(__file__).resolve().parents[1]
W = L / 'worktree'
H = L / 'documentation-4'

def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

hold = json.loads((H / 'source-ready.json').read_bytes())
ledger = json.loads((L / 'root/final-validation.json').read_bytes())
assert hold['final_ledger'] == bound(L / 'root/final-validation.json')
assert hold['source_inventory'] == bound(L / 'source-candidate-3.json')
assert ledger['status'] == 'pass'
expected = {'README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md',
            'docs/class-super-properties.md', 'docs/classes.md', 'docs/object-super-properties.md'}
assert {row['relative_path'] for row in hold['files']} == expected
assert {p.relative_to(H / 'raw').as_posix() for p in (H / 'raw').rglob('*') if p.is_file()} == expected
for row in hold['artifacts']:
    assert dict(bound(H / row['path']), path=row['path']) == row
for row in hold['files']:
    relative = row['relative_path']
    assert bound(H / 'raw' / relative) == row['raw']
    assert bound(Path(row['diff']['path'])) == row['diff']
    if row['before'] is None:
        assert not (W / relative).exists()
    else:
        assert bound(H / 'before' / relative) == row['before']
        assert (W / relative).read_bytes() == (H / 'before' / relative).read_bytes()
    if relative != 'docs/COMPATIBILITY.md':
        assert (H / 'raw' / relative).read_bytes() == (L / 'documentation-2/raw' / relative).read_bytes()

old = (H / 'before/docs/COMPATIBILITY.md').read_bytes()
new = (H / 'raw/docs/COMPATIBILITY.md').read_bytes()
preface = (H / 'compatibility-preface.md').read_bytes()
heading = b'# Compatibility status\n\n'
assert old.startswith(heading) and new == heading + preface + old[len(heading):]
assert (W / 'docs/VALIDATION.md').read_bytes() == __import__('subprocess').check_output(
    ['git', 'show', hold['base'] + ':docs/VALIDATION.md'], cwd=W)

attempts = {row['label']: row for row in ledger['attempts']}
for label, count in [('candidate-full-msrv-2', 3485), ('candidate-full-host-vulkan-1', 3849)]:
    assert attempts[label]['tests'] == dict(suites=56, passed=count, failed=0, ignored=0)
assert ledger['profile_counts'] == dict(passed=1258, failed=64, unsupported=8)
assert all(value == 0 for value in ledger['profile_transition_counts'].values())
assert ledger['new_coverage'] == dict(public_groups=41, public_modes=82, exact_js_fields=80,
                                    parser_groups=6, capture_groups=4, capture_measured_calls=58, browser_groups=2)
links = []
pending = {'docs/evidence/object-super-properties/manifest.json',
           'docs/evidence/object-super-properties/sources-and-checks.tar.gz'}
chapter = (H / 'raw/docs/object-super-properties.md').read_text()
for link in re.findall(r'\]\(([^)]+)\)', chapter):
    if link.startswith('https://'):
        continue
    relative = (Path('docs') / link.split('#')[0]).as_posix()
    assert relative in expected or (W / relative).is_file() or relative in pending
    links.append(relative)
record = dict(status='clear', reviewer='root, independent of html_css documentation producer',
              documentation_hold=bound(H / 'source-ready.json'), final_validation=bound(L / 'root/final-validation.json'),
              files=[row['raw'] for row in hold['files']], local_chapter_links=links,
              checks=['Six raw documents and every sealed artifact verified; existing before bytes match the worktree.',
                      'Read all five edits and complete new chapter; semantics agree with selected runtime and parser behavior.',
                      'COMPATIBILITY receives only the current preface; all older body bytes remain exact.',
                      'Final totals, 53 additions, unchanged profiles, retained failures and environment/checker corrections agree with ledger.',
                      'Optional-chain tail validation remains explicitly deferred; no new hardware, security certification or performance claim.',
                      'Historical validation totals retained; docs/VALIDATION.md unchanged; evidence links are pending package outputs.'])
with (L / 'documentation-review-1/review.json').open('x') as out:
    json.dump(record, out, indent=2); out.write('\n')
print(json.dumps(bound(L / 'documentation-review-1/review.json')))
