"""Convert frozen JSON literals to held Rust text; no project imports/execution."""
from pathlib import Path
import collections
import difflib
import hashlib
import json
import re
import subprocess

L = Path(__file__).resolve().parent.parent
H = L / 'public-controls-1'
A = L / 'public-adapter-1'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'


def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def raw(value):
    assert '"####' not in value
    return 'r####"' + value + '"####'


def invocation(name, args):
    return '    ' + name + '(\n' + ''.join('        ' + arg + ',\n' for arg in args) + '    );\n'


def body(row):
    kind = row['kind']
    if kind == 'semantic':
        args = [raw(row[k]) for k in ('id', 'source', 'readback')]
        args += [raw(row['expected'][k]) for k in ('sloppy', 'strict')]
        return invocation('observe', args)
    if kind == 'early-error':
        assert row['expected'] == dict(intrinsic_error='SyntaxError', parse_error=True, readback_number=0)
        return invocation('early_error', [raw(row[k]) for k in ('id', 'setup', 'source', 'readback')])
    if kind == 'deferred':
        assert row['expected'] == dict(unsupported=True, no_readback_after_terminal=True)
        return invocation('deferred', [raw(row[k]) for k in ('id', 'source')])
    assert kind in ('terminal-resource', 'terminal-unsupported')
    e = row['expected']
    common = dict(caught=0, finalized=0, after=0, queuedRan=0, queue_length=1,
                  queue_front_identity='queued', microtasks_suspended=True,
                  frames=0, calls=0, eval_depth=0, stack_units=0, author_depth=0,
                  performing_checkpoint=False, console_empty=True,
                  inspection='borrowed retained state only; no second execute/checkpoint/reset')
    for key, value in common.items():
        assert type(e[key]) is type(value) and e[key] == value
    assert e['unsupported'] == (kind == 'terminal-unsupported')
    assert e['resource_limit'] is not e['unsupported']
    extra = e.get('retained_string', {})
    expected_keys = set(common) | {'trace', 'unsupported', 'resource_limit'}
    if extra:
        expected_keys.add('retained_string')
    assert set(e) == expected_keys
    strings = '&[' + ', '.join('(' + raw(k) + ', ' + raw(v) + ')' for k, v in extra.items()) + ']'
    return invocation('fatal', [raw(row['id']), raw(row['source']), raw(e['trace']),
                                str(e['unsupported']).lower(), strings])


def main():
    original = json.loads((H / 'source-ready.json').read_bytes())
    assert binding(H / 'cases.json') == original['cases']
    rows = json.loads((H / 'cases.json').read_bytes())
    assert len(rows) == 41 and len({r['id'] for r in rows}) == 41
    old_semantics = H / 'reference/src/script/super_property_semantics_tests.rs'
    old_abort = H / 'reference/src/script/super_property_abort_tests.rs'
    for reference in (old_semantics, old_abort):
        rel = reference.relative_to(H / 'reference').as_posix()
        assert reference.read_bytes() == subprocess.check_output(['git', 'show', BASE + ':' + rel], cwd=L / 'worktree')
    sem_header = old_semantics.read_text().split('\n#[test]\n', 1)[0] + '\n'
    abort_header = old_abort.read_text().split('\n#[test]\n', 1)[0] + '\n'
    old_comment = '//! Independent public SuperProperty literals, frozen before implementation.'
    new_comment = '//! Frozen independent object-method SuperProperty literals.'
    assert sem_header.count(old_comment) == abort_header.count(old_comment) == 1
    sem_header = sem_header.replace(old_comment, new_comment)
    abort_header = abort_header.replace(old_comment, new_comment)
    old_signature = 'fn fatal(case_id: &str, source: &str, expected_trace: &str, unsupported: bool) {'
    new_signature = '''fn fatal(
    case_id: &str,
    source: &str,
    expected_trace: &str,
    unsupported: bool,
    retained_strings: &[(&str, &str)],
) {'''
    assert abort_header.count(old_signature) == 1
    abort_header = abort_header.replace(old_signature, new_signature)
    old_tail = '        assert_eq!(callback, retained(&runtime, "queued"));\n'
    new_tail = old_tail + '''        for &(name, value) in retained_strings {
            assert_eq!(
                retained(&runtime, name),
                &Value::String(value.into()),
                "{case_id} strict={strict} {name}"
            );
        }
'''
    assert abort_header.count(old_tail) == 1
    abort_header = abort_header.replace(old_tail, new_tail)
    paths = {'semantic': 'src/script/object_super_property_semantics_tests.rs',
             'abort': 'src/script/object_super_property_abort_tests.rs'}
    text = {'semantic': sem_header, 'abort': abort_header}
    roster = []
    literal_checks = []
    for row in rows:
        dest = 'abort' if row['kind'].startswith('terminal-') else 'semantic'
        name = 'object_super_property_' + row['id']
        generated_body = body(row)
        text[dest] += '\n#[test]\nfn ' + name + '() {\n' + generated_body + '}\n'
        roster.append(dict(case_id=row['id'], test_name=name, qualified_name='script::' + Path(paths[dest]).stem + '::' + name,
                           relative_path=paths[dest], kind=row['kind'], modes=row['modes'],
                           body_sha256=hashlib.sha256(generated_body.encode()).hexdigest()))
        for field in ('setup', 'source', 'readback'):
            if field in row:
                held = H / 'literals' / (row['id'] + '.' + field + '.js')
                assert held.read_text() == row[field]
                assert raw(row[field]) in generated_body
                literal_checks.append(dict(case_id=row['id'], field=field, literal=binding(held)))
    held_files = []
    for dest, rel in paths.items():
        assert rel not in subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '--', rel], cwd=L / 'worktree').decode().splitlines()
        p = A / 'raw' / rel
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(text[dest])
        diff = A / 'diffs' / (rel.replace('/', '__') + '.diff')
        diff.parent.mkdir(exist_ok=True)
        diff.write_text(''.join(difflib.unified_diff([], text[dest].splitlines(True), fromfile='/dev/null', tofile='b/' + rel)))
        held_files.append(dict(relative_path=rel, before=None, parent_absent=True, raw=binding(p), diff=binding(diff)))
    declaration = '\n#[cfg(test)]\nmod object_super_property_abort_tests;\n#[cfg(test)]\nmod object_super_property_semantics_tests;\n'
    old_script = subprocess.check_output(['git', 'show', BASE + ':src/script.rs'], cwd=L / 'worktree')
    for name in ('object_super_property_abort_tests', 'object_super_property_semantics_tests'):
        assert ('mod ' + name + ';').encode() not in old_script
    before = A / 'registration/before/src/script.rs'
    after = A / 'registration/raw/src/script.rs'
    for p in (before, after):
        p.parent.mkdir(parents=True, exist_ok=True)
    before.write_bytes(old_script)
    after.write_bytes(old_script + declaration.encode())
    snippet = A / 'registration/append.rs'
    snippet.write_text(declaration)
    diff = A / 'registration/src__script.rs.diff'
    diff.write_text(''.join(difflib.unified_diff(old_script.decode().splitlines(True), after.read_text().splitlines(True),
                                              fromfile='a/src/script.rs', tofile='b/src/script.rs')))
    registration = dict(relative_path='src/script.rs', before=binding(before), raw=binding(after),
                        snippet=binding(snippet), diff=binding(diff), semantics='Append these two cfg(test) declarations only; root composes with separately owned edits.')
    write_json(A / 'roster.json', roster)
    write_json(A / 'literal-checks.json', literal_checks)
    write_json(A / 'helpers.json', dict(published_semantic_helpers=binding(old_semantics), published_terminal_helpers=binding(old_abort),
                                      semantic_changes=[old_comment + ' -> ' + new_comment],
                                      terminal_changes=[dict(before=old_signature, after=new_signature), dict(before=old_tail, after=new_tail),
                                                        dict(before=old_comment, after=new_comment)],
                                      qualification='Only diagnostic comment plus retained string witness plumbing differ from published helper bodies. No new execution or reset policy.'))
    assert sum(len(re.findall(r'^#\[test\]$', t, re.M)) for t in text.values()) == 41
    assert len(literal_checks) == 80
    assert len(re.findall(r'^#\[test\]$', text['semantic'], re.M)) == 35
    assert len(re.findall(r'^#\[test\]$', text['abort'], re.M)) == 6
    write_json(A / 'checks.json', dict(status='source-only conversion checks; not compiled or executed', groups=41,
                                     mode_attempts_if_all_reached=82, exact_js_fields=80, semantic_module_groups=35,
                                     abort_module_groups=6, kinds=dict(collections.Counter(r['kind'] for r in rows)),
                                     full_bodies_reconstructed_from_frozen_json=True, parent_registration_append_inverse=True,
                                     published_helper_inverse=True, numeric_private_fee_assertions=False,
                                     generation_only=True, project_imports_or_execution=False, new_producer_reads=False,
                                     live_edits=False, K_writes=False))
    write_json(A / 'execution-contract.json', dict(
        status='Held parent-compatible adapters; root owns import, formatting and execution',
        mode_order=['sloppy', 'strict'], runtime='Fresh Runtime::try_new and empty Document per mode',
        semantic='Execute exact source, then exact readback in the same mode; compare exact frozen string. A source failure leaves readback and remaining mode unreached.',
        early_error='Execute setup, then require intrinsic SyntaxError and is_parse_error for source; read back numeric zero without resetting state.',
        deferred='Require Unsupported from one execute; no further author code.',
        terminal='Classify Resource versus Unsupported before borrowed state assertions. Assert instruction-limit message/steps0 for the four spin Resource rows. Check sticky suspension, restored frame/call/depth/stack counters, no console output, exact retained trace and zero effect sentinels, queue identity/count, plus published==old in the definition-key row. No second execute/checkpoint/manual budget reset.',
        parent_first_failures='Absent object-method SuperProperty prevents intended semantic/terminal source execution. Preserve actual first assertion and unreachable readbacks/state rows; no aggregate parent outcome count is inferred.',
        registration=registration['semantics'],
        phase_counts=json.loads((H / 'adapter-plan.json').read_bytes())['mode_phase_counts']))
    write_json(A / 'source-ready.json', dict(
        schema=1, status='source-ready independent public adapter; no compilation or execution', base=BASE,
        frozen_contract=binding(H / 'source-ready.json'), literal_ready=binding(H / 'literal-ready.json'),
        frozen_cases=binding(H / 'cases.json'), published_base_refresh=binding(L / 'public-base-refresh-1/source-ready.json'),
        files=held_files, registration=registration,
        roster=binding(A / 'roster.json'), literal_checks=binding(A / 'literal-checks.json'),
        helpers=binding(A / 'helpers.json'), checks=binding(A / 'checks.json'),
        execution_contract=binding(A / 'execution-contract.json'), author=binding(Path(__file__)),
        counts=dict(groups=41, planned_modes=82, exact_js_fields=80, semantic_module_groups=35, abort_module_groups=6),
        project_imports_or_execution=False, new_producer_reads=False, live_edits=False, K_writes=False))
    print(json.dumps(binding(A / 'source-ready.json'), indent=2))


if __name__ == '__main__':
    main()
