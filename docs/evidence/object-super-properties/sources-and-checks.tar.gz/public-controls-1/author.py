"""Author independent literal data only; never import or execute the project."""
from pathlib import Path
import hashlib
import json

HERE = Path(__file__).resolve().parent
CASES = []
PREFIX = """function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
"""


def semantic(name, body, expected, reason, strict=None):
    CASES.append(dict(id=name, kind='semantic', modes=['sloppy', 'strict'],
                      source=PREFIX+body.strip()+"\n})();\n", readback='result\n',
                      expected={'sloppy': expected, 'strict': expected if strict is None else strict},
                      derivation=reason))


semantic('home_receiver_copy_bind_live', r"""
var a={get x(){return 'A'+this.tag;},f(){return this;}},b={get x(){return 'B'+this.tag;},f(){return this;}};
var home={__proto__:a,read(){return super.x;},call(){return super.f();}};
var receiver={tag:'R',x:'shadow',f:function(){throw 'shadow';}},copy={tag:'C',read:home.read};
Object.setPrototypeOf(receiver,{x:'wrong'});Object.setPrototypeOf(copy,{x:'wrong'});
var saved=home.read,bound=saved.bind(receiver);
check(saved.call(receiver)==='AR'&&copy.read()==='AC'&&bound()==='AR');
check(home.call.call(receiver)===receiver);
Object.setPrototypeOf(home,b);delete home.read;
check(saved.call(receiver)==='BR'&&copy.read()==='BC'&&bound()==='BR');
return 'home:copy:bind:live';
""", 'home:copy:bind:live', 'Copies and bound calls retain the original defining object; its live prototype selects the base independently of receiver shadows.')

semantic('repeated_evaluation_separate_homes', r"""
function make(parent){return {read(){return super.x;},__proto__:parent};}
var a=make({x:1}),b=make({x:2}),fa=a.read,fb=b.read;
check(fa!==fb&&fa()===1&&fb()===2);
Object.setPrototypeOf(a,{x:3});check(fa.call(b)===3&&fb.call(a)===2);
Object.setPrototypeOf(b,null);expect(TypeError,function(){fb();});check(fa()===3);
return '1:2:3:null';
""", '1:2:3:null', 'Each evaluation attaches its own new object; changing one home has no effect on the other.')

semantic('inherited_method_keeps_its_own_home', r"""
var grand={get x(){return 'G'+this.tag;}},mid={__proto__:grand,m(){return super.x;}};
var home={__proto__:mid,m(){return super.m();}},receiver={tag:'R'};
check(home.m.call(receiver)==='GR');
Object.setPrototypeOf(mid,{get x(){return 'N'+this.tag;}});check(home.m.call(receiver)==='NR');
Object.setPrototypeOf(home,{m:mid.m});check(home.m.call(receiver)==='NR');
return 'GR:NR:NR';
""", 'GR:NR:NR', 'A super call carries its receiver into the selected method without changing that method\'s distinct home.')

semantic('accessor_merge_copy_and_receiver', r"""
var trace='',base={get x(){trace+='G';return this.tag;},set x(v){trace+='S';this.saved=v;}};
var home={__proto__:base,get slot(){return super.x;},set slot(v){super.x=v;},get slot(){trace+='g';return super.x;}};
var descriptor=Object.getOwnPropertyDescriptor(home,'slot'),copy={tag:7};
check(descriptor.enumerable&&descriptor.configurable&&descriptor.get.name==='get slot'&&descriptor.set.name==='set slot');
Object.defineProperty(copy,'slot',descriptor);check(copy.slot===7);copy.slot=8;check(copy.saved===8);
Object.setPrototypeOf(home,{get x(){trace+='N';return this.tag+1;},set x(v){trace+='T';this.saved=v+1;}});
check(copy.slot===8);copy.slot=9;check(copy.saved===10);
return trace;
""", 'gGSgNT', 'Repeated getter replacement preserves the setter. Copying the descriptor does not rehome either function.')

semantic('escaped_arrows_from_methods_and_accessors', r"""
var trace='',base={get x(){trace+='G';return this.tag;},set x(v){trace+='S';this.saved=v;}};
var savedSetter,home={__proto__:base,make(){return ()=>super.x;},get arrow(){return ()=>super.x;},set arrow(v){savedSetter=()=>super.x=v;}};
var r={tag:4},get=home.make.call(r),d=Object.getOwnPropertyDescriptor(home,'arrow'),access=d.get.call(r);
d.set.call(r,5);check(get.call({tag:99})===4&&access()===4);savedSetter();check(r.saved===5);
Object.setPrototypeOf(home,{get x(){trace+='N';return this.tag+1;}});check(get()===5&&access()===5);
return trace;
""", 'GGSNN', 'Escaped arrows retain lexical receiver and owning method activation while each property access reads the live home parent.')

semantic('method_and_arrow_parameter_defaults', r"""
var trace='',base={get x(){trace+='G';return this.tag;}};
var home={__proto__:base,m(v=super.x,f=()=>super.x){trace+='B';return [v,f];},make(){return (v=super.x)=>v;},set slot(v=super.x){trace+='S';this.saved=v;}};
var r={tag:6},pair=home.m.call(r);check(pair[0]===6);r.tag=7;check(pair[1]()===7);
var arrow=home.make.call(r);check(arrow.call({tag:99})===7);check(arrow(8)===8);
Object.getOwnPropertyDescriptor(home,'slot').set.call(r,undefined);check(r.saved===7);
return trace;
""", 'GBGGGS', 'Method and setter defaults see the attached home and bound receiver before the body; arrow defaults resolve the same lexical activation.')

semantic('primitive_receivers_follow_mode', r"""
var base={get receiver(){'use strict';return this;}},home={__proto__:base,read(){return super.receiver;}};
var number=home.read.call(7),nil=home.read.call(null),undef=home.read.call(undefined);
if(typeof number==='object'){check(number.valueOf()===7&&nil===globalThis&&undef===globalThis);return 'boxed:global:global';}
check(number===7&&nil===null&&undef===undefined);return 'primitive:null:undefined';
""", 'boxed:global:global', 'The object method inherits surrounding strictness; an explicitly strict base getter exposes the receiver actually supplied by super.', strict='primitive:null:undefined')

semantic('implicit_accessor_receivers_follow_mode', r"""
var seen,base={get x(){'use strict';return this;},set x(v){'use strict';seen=this;}},home={__proto__:base,get x(){return super.x;},set x(v){super.x=v;}};
var d=Object.getOwnPropertyDescriptor(home,'x'),got=d.get.call(7),nil=d.get.call(null);d.set.call(8,1);
if(typeof got==='object'){check(got.valueOf()===7&&typeof seen==='object'&&seen.valueOf()===8&&nil===globalThis);return 'boxed:boxed:global';}
check(got===7&&seen===8&&nil===null);return 'primitive:primitive:null';
""", 'boxed:boxed:global', 'Implicit accessor strictness follows enclosing code just like ordinary object methods; the base accessors expose its converted or preserved receiver.', strict='primitive:primitive:null')

semantic('explicit_strict_method_and_accessor', r"""
var seen,base={get x(){'use strict';return this;},set x(v){'use strict';seen=this;}};
var home={__proto__:base,m(){'use strict';return ()=>super.x;},get x(){'use strict';return super.x;},set x(v){'use strict';super.x=v;}};
check(home.m.call(7).call(99)===7);
var d=Object.getOwnPropertyDescriptor(home,'x');check(d.get.call(null)===null);d.set.call(8,1);check(seen===8);
return 'strict:7:null:8';
""", 'strict:7:null:8', 'Explicit directives preserve primitive/null receivers in both outer modes; home attachment must not replace ordinary strictness rules.')

semantic('failed_data_writes_follow_reference_strictness', r"""
var base={},home={__proto__:base,put(k,v){return super[k]=v;}};
Object.defineProperty(base,'locked',{value:1,writable:false});Object.defineProperty(base,'getonly',{get:function(){return 2;}});
var receiver={},other={};Object.defineProperty(other,'own',{get:function(){throw 'receiver getter';}});
var trace='';function attempt(r,k){try{check(home.put.call(r,k,9)===9);trace+='R';}catch(e){check(e instanceof TypeError);trace+='T';}}
attempt(receiver,'locked');attempt(receiver,'getonly');attempt(other,'own');
check(!Object.prototype.hasOwnProperty.call(receiver,'locked')&&!Object.prototype.hasOwnProperty.call(receiver,'getonly'));
check(typeof Object.getOwnPropertyDescriptor(other,'own').get==='function');return trace;
""", 'RRR', 'False internal writes return the RHS in sloppy methods but throw in strict methods; receiver accessors are inspected rather than invoked.', strict='TTT')

semantic('primitive_data_write_boxing_and_strict_failure', r"""
var base={x:1},home={__proto__:base,write(){super.x=9;return this;}};
try{var r=home.write.call(7);check(typeof r==='object'&&r.valueOf()===7&&r.x===9);return 'boxed:9';}
catch(e){check(e instanceof TypeError);return 'TypeError';}
""", 'boxed:9', 'A sloppy object method writes to its persistent boxed receiver; strict primitive receiver Set returns false and throws.', strict='TypeError')

semantic('mapped_arguments_are_not_forced_strict', r"""
var home={__proto__:{'0':0},m(a){var args=arguments;var helper={__proto__:{'0':0},put(v){super[0]=v;}};helper.put.call(args,9);return a+':'+args[0];}};
return home.m(1);
""", '9:9', 'Object method parameter mapping remains ordinary: sloppy arguments aliases the simple parameter, strict arguments does not.', strict='1:9')

semantic('definition_key_outer_home_and_body_inner_home', r"""
var trace='',key={};key[Symbol.toPrimitive]=function(hint){check(hint==='string');trace+='C';return 'made';};
var parent={get key(){trace+='K';return key;},x:'outer'};
var outer={__proto__:parent,build(){var inner={ [super.key](){trace+='M';return super.x;},__proto__:{x:'inner'}};trace+='B';check(super.x==='outer');return inner;}};
var inner=outer.build();check(inner.made()==='inner'&&inner.made.name==='made');return trace;
""", 'KCBM', 'Definition names use the enclosing object method, including conversion; the new method body uses the newly created inner home.')

semantic('key_expression_capture_and_conversion_order', r"""
var trace='',home,first={get x(){trace+='A';return 1;}},second={get x(){trace+='B';return 2;}},third={get x(){trace+='C';return 3;}},key={};
key[Symbol.toPrimitive]=function(){trace+='T';Object.setPrototypeOf(home,third);return 'x';};
home={__proto__:first,read(){return super[(trace+='K',Object.setPrototypeOf(home,second),key)];}};
check(home.read()===2);check(home.read.call({})===2);return trace;
""", 'KTBKTB', 'Raw key expression changes the live parent before capture, but later key coercion cannot replace the already captured base.')

semantic('proto_colon_after_method_and_ordinary_proto_names', r"""
var trace='',base={x:4},home={m(){return super.x;},__proto__:(trace+='P',base),['__proto__']:(trace+='D',7)};
check(home.m()===4&&home.__proto__===7&&Object.getPrototypeOf(home)===base);
var accessor={__proto__:base,get __proto__(){return super.x;},set __proto__(v){super.x=v;}};
check(accessor.__proto__===4);accessor.__proto__=8;check(accessor.x===8&&base.x===4);
var method={__proto__:base,__proto__(){return super.x;}};check(method.__proto__()===4);
return trace;
""", 'PD', 'A later colon prototype setter updates the actual home. Computed data, methods and accessors named __proto__ are ordinary properties and can coexist with it.')

semantic('proto_primitive_ignored_null_and_no_coercion', r"""
var trace='',p={x:5,toString(){throw 'coerced';},valueOf(){throw 'coerced';}};
var a={__proto__:p,m(){return super.x;}},b={__proto__:(trace+='P',17),m(){return super.toString;}},n={__proto__:null,m(){return super.x;}};
check(a.m()===5&&Object.getPrototypeOf(a)===p&&Object.getPrototypeOf(b)===Object.prototype);
check(b.m()===Object.prototype.toString);expect(TypeError,function(){n.m();});return trace;
""", 'P', 'Prototype colon syntax neither coerces its value nor creates a data property; primitive values are ignored and null is a valid parent that makes super property access throw.')

semantic('metadata_unicode_symbols_and_nonconstructability', r"""
var symbol=Symbol('λ\uD800'),key='雪\uD800',base={x:3};
var home={__proto__:base,[key](a,b=super.x){return b;},get [symbol](){return super.x;},constructor(){return super.x;}};
var m=home[key],get=Object.getOwnPropertyDescriptor(home,symbol).get;
check(m.name===key&&m.length===1&&m(0)===3&&get.name==='get [λ\uD800]'&&get.length===0&&get.call(home)===3);
var d=Object.getOwnPropertyDescriptor(home,key),name=Object.getOwnPropertyDescriptor(m,'name');
check(d.value===m&&d.writable&&d.enumerable&&d.configurable&&!name.writable&&!name.enumerable&&name.configurable);
check(!Object.prototype.hasOwnProperty.call(m,'prototype')&&!Object.prototype.hasOwnProperty.call(home.constructor,'prototype'));
expect(TypeError,function(){new m();});expect(TypeError,function(){new home.constructor();});return 'metadata:unicode:symbol';
""", 'metadata:unicode:symbol', 'Attaching home preserves ordinary concise-method/accessor names, descriptors, default-parameter length and lack of construction behavior.')

semantic('nested_object_and_colon_arrow_contexts', r"""
var outer={__proto__:{x:'outer'},build(){var inner={__proto__:{x:'inner'},arrow:()=>super.x,m(){return super.x;}};check(super.x==='outer');return inner;}};
var inner=outer.build();check(inner.arrow()==='outer'&&inner.m()==='inner');
Object.setPrototypeOf(outer,{x:'live'});check(inner.arrow.call({})==='live'&&inner.m()==='inner');
return 'outer:inner:live';
""", 'outer:inner:live', 'A colon arrow inherits its enclosing activation, whereas a nested concise method establishes its own home and parsing it does not leak context.')

semantic('class_object_context_restoration_both_directions', r"""
class A { get x(){return 'class';} }
class C extends A { build(){var o={__proto__:{x:'object'},m(){return super.x;},arrow:()=>super.x};check(super.x==='class');return o;} }
var o=new C().build();check(o.m()==='object'&&o.arrow()==='class');
var outer={__proto__:{Base:A,key:'read',x:'outer'},build(){class D extends super.Base {[super.key](){return super.x;}}check(super.x==='outer');return D;}};
var D=outer.build();check(new D().read()==='class');return 'class:object:outer:class';
""", 'class:object:outer:class', 'Nested class heritage/computed names retain the outer object context; class bodies get their own home and both enclosing contexts resume unchanged.')

semantic('ordinary_abrupts_preserve_identity_and_cleanup', r"""
var trace='',token={},base={get x(){trace+='G';throw token;},set x(v){trace+='S';throw token;}},home={__proto__:base,read(k){return super[k];},put(v){return super.x=v;}};
try{home.read('x');}catch(e){check(e===token);trace+='C';}finally{trace+='F';}
try{home.put(1);}catch(e){check(e===token);trace+='C';}finally{trace+='F';}
Object.setPrototypeOf(home,{x:8});check(home.read('x')===8);return trace;
""", 'GCFSCF', 'Ordinary accessor throws remain catchable with exact identity; finally executes and a later home lookup works after unwinding.')

semantic('assignment_update_logical_and_loop_routes', r"""
var trace='',stored=1,base={get x(){trace+='G';return stored;},set x(v){trace+='S';stored=v;}},home={__proto__:base,run(){
check((super.x+=2)===3);check(super.x++===3);check(++super.x===5);
check((super.x ||= (trace+='R',9))===5);check((super.x &&= (trace+='R',0))===0);check((super.x ??= (trace+='R',8))===0);
for(super.x of [6,7]){trace+='B';}for(super.x in {z:1}){trace+='I';}return stored;
}};check(home.run()==='z');return trace;
""", 'GSGSGSGGRSGSBSBSI', 'Existing reference routes receive object homes: compound/update read then write, logical short-circuits skip RHS/write, and loop targets write through the same base setter.')

semantic('call_new_and_delete_routes', r"""
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='T';return 'x';};
function Made(v){this.value=v;}
var base={get f(){trace+='G';return function(v){'use strict';check(this.tag==='R');trace+='F';return v;};},C:Made,x:1};
var home={__proto__:base,call(){return (super.f)((trace+='A',3));},make(){return new super.C(4);},del(){return delete super[(trace+='K',key)];}};
check(home.call.call({tag:'R'})===3);check(home.make().value===4);expect(ReferenceError,function(){home.del();});
check(base.x===1);return trace;
""", 'GAFK', 'Object methods retain super call receivers and constructor-valued reads; delete evaluates raw key but throws before conversion or deletion.')

semantic('definition_abrupt_and_accessor_replacement_order', r"""
var trace='',token={},key={};key[Symbol.toPrimitive]=function(){trace+='K';throw token;};var published='old';
try{published={m(){return super.x;},[key](){return super.x;},[(trace+='L','later')]:1};}catch(e){check(e===token);trace+='C';}
check(published==='old');
var home={__proto__:{x:4},get x(){return super.x;},set x(v){trace+='S';},x:9,get x(){trace+='G';return super.x;}};
var d=Object.getOwnPropertyDescriptor(home,'x');check(d.set===undefined&&home.x===4);return trace;
""", 'KCG', 'A throwing computed definition key prevents later definitions/publication. A data definition removes both old accessors; the later getter receives the same defining home.')


def early(name, fragment, reason):
    CASES.append(dict(id=name, kind='early-error', modes=['sloppy','strict'], setup='var touched=0;\n',
                      source='touched++;'+fragment+'\n', readback='touched\n',
                      expected={'intrinsic_error':'SyntaxError','parse_error':True,'readback_number':0}, derivation=reason))


early('super_call_method_forbidden','({m(){super();}});','Object methods cannot directly call super, despite allowing SuperProperty.')
early('super_call_default_forbidden','({m(v=super()){return v;}});','Direct super remains forbidden in parameter defaults.')
early('super_call_accessor_arrow_forbidden','({get x(){return ()=>super();}});','Lexical arrows inherit the object accessor context, which has no super-constructor capability.')
early('ordinary_function_value_resets_super','({m(){return {f:function(){return super.x;}};}});','An ordinary function-valued property does not inherit the containing method\'s super context.')
early('ordinary_nested_function_resets_super','({m(){function f(){return ()=>super.x;}return f;}});','An ordinary nested function blocks lexical super, including arrows nested inside it.')
early('computed_definition_name_needs_outer_context','({[super.x](){return 1;}});','A method\'s own future home does not grant super to its outer computed definition name.')
early('object_context_does_not_leak_to_next_function','({m(){return super.x;}});function later(){return super.x;}','Parsing an object method restores the prior context before a later ordinary function.')
early('duplicate_proto_colons_still_early_error',"({m(){return super.x;},__proto__:null,'__proto__':null});",'The new method context does not relax duplicate special prototype-setter early errors.')


for name, source, reason in [
 ('deferred_async_object_method','({async m(){return super.x;}});','Async concise methods remain a valid-but-unsupported surface.'),
 ('deferred_generator_object_method','({*m(){yield super.x;}});','Generator methods remain valid-but-unsupported.'),
 ('deferred_object_spread','var base={};({m(){return super.x;},...base});','Object spread remains deferred even next to a supported ordinary method.'),
 ('deferred_optional_super_result','({m(){return super.x?.y;}});','Optional chaining on a super-property result is valid syntax but remains deferred.')
]:
    CASES.append(dict(id=name,kind='deferred',modes=['sloppy','strict'],source=source+'\n',expected={'unsupported':True,'no_readback_after_terminal':True},derivation=reason))


TERMINAL_PREFIX="""var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
"""


def terminal(name, source, trace, reason, unsupported=False):
    CASES.append(dict(id=name,kind='terminal-unsupported' if unsupported else 'terminal-resource',modes=['sloppy','strict'],
                      source=TERMINAL_PREFIX+source.strip()+'\n',
                      expected={'trace':trace,'caught':0,'finalized':0,'after':0,'queuedRan':0,'queue_length':1,
                                'queue_front_identity':'queued','microtasks_suspended':True,'frames':0,'calls':0,
                                'eval_depth':0,'stack_units':0,'author_depth':0,'performing_checkpoint':False,
                                'console_empty':True,'unsupported':unsupported,'resource_limit':not unsupported,
                                'inspection':'borrowed retained state only; no second execute/checkpoint/reset'},derivation=reason))


terminal('terminal_computed_definition_key',r"""
var published='old';
try{published={m(){return super.x;},[(trace+='D',spin())](){return super.x;}};after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'D','An infinite computed definition key stops before publication or later effects, retaining the prior published value.')
CASES[-1]['expected']['retained_string']={'published':'old'}
terminal('terminal_super_key_coercion',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';spin();return 'x';};
var home={__proto__:{get x(){trace+='G';return 1;}},m(){return super[(trace+='K',key)];}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KC','Resource failure during delayed key conversion stops before the getter and unwinds the object method frames.')
terminal('terminal_parameter_default_getter',r"""
var home={__proto__:{get x(){trace+='G';spin();return 1;}},m(v=super.x){trace+='B';return v;}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'G','The method activation and its home exist during parameter defaults; fatal getter work never enters the body.')
terminal('terminal_escaped_arrow_setter',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
var home={__proto__:{set x(v){trace+='S';spin();}},make(){trace+='A';return v=>super[(trace+='K',key)]=v;}};
var arrow=home.make();try{arrow(3);after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'AKCS','Fatal setter work reached through an escaped lexical arrow preserves earlier effects while all live frames unwind and the queued sentinel remains stopped.')
terminal('unsupported_super_getter',r"""
var home={__proto__:{get x(){trace+='G';eval('1');return 1;}},m(){return super.x;}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'G','Existing runtime eval refusal is terminal even when reached through a supported object super getter.',True)
terminal('unsupported_assignment_rhs',r"""
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
var home={__proto__:{set x(v){trace+='S';}},m(){super[(trace+='K',key)]=(trace+='R',eval('1'));trace+='B';}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
""",'KR','Terminal Unsupported from the RHS stops before delayed key conversion, setter, catch/finally and queued work.',True)


def main():
    assert len({r['id'] for r in CASES})==len(CASES)
    literals=HERE/'literals';literals.mkdir(exist_ok=True)
    for row in CASES:
        for field in ('setup','source','readback'):
            if field in row:(literals/(row['id']+'.'+field+'.js')).write_text(row[field])
    (HERE/'cases.json').write_text(json.dumps(CASES,indent=2,ensure_ascii=True)+'\n')
    counts={}
    for row in CASES:counts[row['kind']]=counts.get(row['kind'],0)+1
    print(json.dumps({'groups':len(CASES),'modes':len(CASES)*2,'kinds':counts,'literal_fields':sum(sum(f in r for f in ('setup','source','readback')) for r in CASES)}))


if __name__=='__main__':main()
