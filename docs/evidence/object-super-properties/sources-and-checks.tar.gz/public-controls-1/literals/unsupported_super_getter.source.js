var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var home={__proto__:{get x(){trace+='G';eval('1');return 1;}},m(){return super.x;}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
