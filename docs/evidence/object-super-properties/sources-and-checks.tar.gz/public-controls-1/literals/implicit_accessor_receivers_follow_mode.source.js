function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var seen,base={get x(){'use strict';return this;},set x(v){'use strict';seen=this;}},home={__proto__:base,get x(){return super.x;},set x(v){super.x=v;}};
var d=Object.getOwnPropertyDescriptor(home,'x'),got=d.get.call(7),nil=d.get.call(null);d.set.call(8,1);
if(typeof got==='object'){check(got.valueOf()===7&&typeof seen==='object'&&seen.valueOf()===8&&nil===globalThis);return 'boxed:boxed:global';}
check(got===7&&seen===8&&nil===null);return 'primitive:primitive:null';
})();
