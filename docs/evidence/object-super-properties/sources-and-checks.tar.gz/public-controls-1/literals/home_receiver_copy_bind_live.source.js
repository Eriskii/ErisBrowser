function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var a={get x(){return 'A'+this.tag;},f(){return this;}},b={get x(){return 'B'+this.tag;},f(){return this;}};
var home={__proto__:a,read(){return super.x;},call(){return super.f();}};
var receiver={tag:'R',x:'shadow',f:function(){throw 'shadow';}},copy={tag:'C',read:home.read};
Object.setPrototypeOf(receiver,{x:'wrong'});Object.setPrototypeOf(copy,{x:'wrong'});
var saved=home.read,bound=saved.bind(receiver);
check(saved.call(receiver)==='AR'&&copy.read()==='AC'&&bound()==='AR');
check(home.call.call(receiver)===receiver);
Object.setPrototypeOf(home,b);delete home.read;
check(saved.call(receiver)==='BR'&&copy.read()==='BC'&&bound()==='BR');
return 'home:copy:bind:live';
})();
