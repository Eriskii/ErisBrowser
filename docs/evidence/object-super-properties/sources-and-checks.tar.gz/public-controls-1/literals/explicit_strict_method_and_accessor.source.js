function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var seen,base={get x(){'use strict';return this;},set x(v){'use strict';seen=this;}};
var home={__proto__:base,m(){'use strict';return ()=>super.x;},get x(){'use strict';return super.x;},set x(v){'use strict';super.x=v;}};
check(home.m.call(7).call(99)===7);
var d=Object.getOwnPropertyDescriptor(home,'x');check(d.get.call(null)===null);d.set.call(8,1);check(seen===8);
return 'strict:7:null:8';
})();
