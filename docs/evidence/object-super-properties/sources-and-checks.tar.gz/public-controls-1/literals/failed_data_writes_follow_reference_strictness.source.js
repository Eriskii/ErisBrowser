function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var base={},home={__proto__:base,put(k,v){return super[k]=v;}};
Object.defineProperty(base,'locked',{value:1,writable:false});Object.defineProperty(base,'getonly',{get:function(){return 2;}});
var receiver={},other={};Object.defineProperty(other,'own',{get:function(){throw 'receiver getter';}});
var trace='';function attempt(r,k){try{check(home.put.call(r,k,9)===9);trace+='R';}catch(e){check(e instanceof TypeError);trace+='T';}}
attempt(receiver,'locked');attempt(receiver,'getonly');attempt(other,'own');
check(!Object.prototype.hasOwnProperty.call(receiver,'locked')&&!Object.prototype.hasOwnProperty.call(receiver,'getonly'));
check(typeof Object.getOwnPropertyDescriptor(other,'own').get==='function');return trace;
})();
