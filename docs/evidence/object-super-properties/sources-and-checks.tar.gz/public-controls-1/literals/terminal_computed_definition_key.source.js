var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var published='old';
try{published={m(){return super.x;},[(trace+='D',spin())](){return super.x;}};after++;}catch(e){caught++;}finally{finalized++;}after++;
