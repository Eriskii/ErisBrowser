function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',home,first={get x(){trace+='A';return 1;}},second={get x(){trace+='B';return 2;}},third={get x(){trace+='C';return 3;}},key={};
key[Symbol.toPrimitive]=function(){trace+='T';Object.setPrototypeOf(home,third);return 'x';};
home={__proto__:first,read(){return super[(trace+='K',Object.setPrototypeOf(home,second),key)];}};
check(home.read()===2);check(home.read.call({})===2);return trace;
})();
