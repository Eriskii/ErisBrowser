var base={};({m(){return super.x;},...base});
