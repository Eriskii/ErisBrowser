function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var home={__proto__:{'0':0},m(a){var args=arguments;var helper={__proto__:{'0':0},put(v){super[0]=v;}};helper.put.call(args,9);return a+':'+args[0];}};
return home.m(1);
})();
