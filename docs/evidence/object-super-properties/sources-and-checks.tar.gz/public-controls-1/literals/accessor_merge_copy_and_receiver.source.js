function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',base={get x(){trace+='G';return this.tag;},set x(v){trace+='S';this.saved=v;}};
var home={__proto__:base,get slot(){return super.x;},set slot(v){super.x=v;},get slot(){trace+='g';return super.x;}};
var descriptor=Object.getOwnPropertyDescriptor(home,'slot'),copy={tag:7};
check(descriptor.enumerable&&descriptor.configurable&&descriptor.get.name==='get slot'&&descriptor.set.name==='set slot');
Object.defineProperty(copy,'slot',descriptor);check(copy.slot===7);copy.slot=8;check(copy.saved===8);
Object.setPrototypeOf(home,{get x(){trace+='N';return this.tag+1;},set x(v){trace+='T';this.saved=v+1;}});
check(copy.slot===8);copy.slot=9;check(copy.saved===10);
return trace;
})();
