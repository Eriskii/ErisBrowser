touched++;({m(){return super.x;},__proto__:null,'__proto__':null});
