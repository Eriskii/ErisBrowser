function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',base={get x(){trace+='G';return this.tag;}};
var home={__proto__:base,m(v=super.x,f=()=>super.x){trace+='B';return [v,f];},make(){return (v=super.x)=>v;},set slot(v=super.x){trace+='S';this.saved=v;}};
var r={tag:6},pair=home.m.call(r);check(pair[0]===6);r.tag=7;check(pair[1]()===7);
var arrow=home.make.call(r);check(arrow.call({tag:99})===7);check(arrow(8)===8);
Object.getOwnPropertyDescriptor(home,'slot').set.call(r,undefined);check(r.saved===7);
return trace;
})();
