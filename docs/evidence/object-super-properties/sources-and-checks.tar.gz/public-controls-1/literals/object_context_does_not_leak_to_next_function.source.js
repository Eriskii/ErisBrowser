touched++;({m(){return super.x;}});function later(){return super.x;}
