function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',p={x:5,toString(){throw 'coerced';},valueOf(){throw 'coerced';}};
var a={__proto__:p,m(){return super.x;}},b={__proto__:(trace+='P',17),m(){return super.toString;}},n={__proto__:null,m(){return super.x;}};
check(a.m()===5&&Object.getPrototypeOf(a)===p&&Object.getPrototypeOf(b)===Object.prototype);
check(b.m()===Object.prototype.toString);expect(TypeError,function(){n.m();});return trace;
})();
