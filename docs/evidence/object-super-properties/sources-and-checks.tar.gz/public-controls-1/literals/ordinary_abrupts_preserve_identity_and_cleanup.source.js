function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',token={},base={get x(){trace+='G';throw token;},set x(v){trace+='S';throw token;}},home={__proto__:base,read(k){return super[k];},put(v){return super.x=v;}};
try{home.read('x');}catch(e){check(e===token);trace+='C';}finally{trace+='F';}
try{home.put(1);}catch(e){check(e===token);trace+='C';}finally{trace+='F';}
Object.setPrototypeOf(home,{x:8});check(home.read('x')===8);return trace;
})();
