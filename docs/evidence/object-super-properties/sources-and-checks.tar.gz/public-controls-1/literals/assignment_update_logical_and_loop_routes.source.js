function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',stored=1,base={get x(){trace+='G';return stored;},set x(v){trace+='S';stored=v;}},home={__proto__:base,run(){
check((super.x+=2)===3);check(super.x++===3);check(++super.x===5);
check((super.x ||= (trace+='R',9))===5);check((super.x &&= (trace+='R',0))===0);check((super.x ??= (trace+='R',8))===0);
for(super.x of [6,7]){trace+='B';}for(super.x in {z:1}){trace+='I';}return stored;
}};check(home.run()==='z');return trace;
})();
