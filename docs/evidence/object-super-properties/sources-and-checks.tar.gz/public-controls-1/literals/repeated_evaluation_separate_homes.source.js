function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
function make(parent){return {read(){return super.x;},__proto__:parent};}
var a=make({x:1}),b=make({x:2}),fa=a.read,fb=b.read;
check(fa!==fb&&fa()===1&&fb()===2);
Object.setPrototypeOf(a,{x:3});check(fa.call(b)===3&&fb.call(a)===2);
Object.setPrototypeOf(b,null);expect(TypeError,function(){fb();});check(fa()===3);
return '1:2:3:null';
})();
