function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var base={x:1},home={__proto__:base,write(){super.x=9;return this;}};
try{var r=home.write.call(7);check(typeof r==='object'&&r.valueOf()===7&&r.x===9);return 'boxed:9';}
catch(e){check(e instanceof TypeError);return 'TypeError';}
})();
