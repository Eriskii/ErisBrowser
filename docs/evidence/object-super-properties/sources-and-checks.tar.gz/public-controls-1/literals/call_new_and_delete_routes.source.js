function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',key={};key[Symbol.toPrimitive]=function(){trace+='T';return 'x';};
function Made(v){this.value=v;}
var base={get f(){trace+='G';return function(v){'use strict';check(this.tag==='R');trace+='F';return v;};},C:Made,x:1};
var home={__proto__:base,call(){return (super.f)((trace+='A',3));},make(){return new super.C(4);},del(){return delete super[(trace+='K',key)];}};
check(home.call.call({tag:'R'})===3);check(home.make().value===4);expect(ReferenceError,function(){home.del();});
check(base.x===1);return trace;
})();
