function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',key={};key[Symbol.toPrimitive]=function(hint){check(hint==='string');trace+='C';return 'made';};
var parent={get key(){trace+='K';return key;},x:'outer'};
var outer={__proto__:parent,build(){var inner={ [super.key](){trace+='M';return super.x;},__proto__:{x:'inner'}};trace+='B';check(super.x==='outer');return inner;}};
var inner=outer.build();check(inner.made()==='inner'&&inner.made.name==='made');return trace;
})();
