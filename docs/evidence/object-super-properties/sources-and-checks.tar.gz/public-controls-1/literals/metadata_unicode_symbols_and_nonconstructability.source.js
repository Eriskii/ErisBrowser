function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var symbol=Symbol('λ\uD800'),key='雪\uD800',base={x:3};
var home={__proto__:base,[key](a,b=super.x){return b;},get [symbol](){return super.x;},constructor(){return super.x;}};
var m=home[key],get=Object.getOwnPropertyDescriptor(home,symbol).get;
check(m.name===key&&m.length===1&&m(0)===3&&get.name==='get [λ\uD800]'&&get.length===0&&get.call(home)===3);
var d=Object.getOwnPropertyDescriptor(home,key),name=Object.getOwnPropertyDescriptor(m,'name');
check(d.value===m&&d.writable&&d.enumerable&&d.configurable&&!name.writable&&!name.enumerable&&name.configurable);
check(!Object.prototype.hasOwnProperty.call(m,'prototype')&&!Object.prototype.hasOwnProperty.call(home.constructor,'prototype'));
expect(TypeError,function(){new m();});expect(TypeError,function(){new home.constructor();});return 'metadata:unicode:symbol';
})();
