var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var key={};key[Symbol.toPrimitive]=function(){trace+='C';return 'x';};
var home={__proto__:{set x(v){trace+='S';spin();}},make(){trace+='A';return v=>super[(trace+='K',key)]=v;}};
var arrow=home.make();try{arrow(3);after++;}catch(e){caught++;}finally{finalized++;}after++;
