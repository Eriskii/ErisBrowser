function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var grand={get x(){return 'G'+this.tag;}},mid={__proto__:grand,m(){return super.x;}};
var home={__proto__:mid,m(){return super.m();}},receiver={tag:'R'};
check(home.m.call(receiver)==='GR');
Object.setPrototypeOf(mid,{get x(){return 'N'+this.tag;}});check(home.m.call(receiver)==='NR');
Object.setPrototypeOf(home,{m:mid.m});check(home.m.call(receiver)==='NR');
return 'GR:NR:NR';
})();
