function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',token={},key={};key[Symbol.toPrimitive]=function(){trace+='K';throw token;};var published='old';
try{published={m(){return super.x;},[key](){return super.x;},[(trace+='L','later')]:1};}catch(e){check(e===token);trace+='C';}
check(published==='old');
var home={__proto__:{x:4},get x(){return super.x;},set x(v){trace+='S';},x:9,get x(){trace+='G';return super.x;}};
var d=Object.getOwnPropertyDescriptor(home,'x');check(d.set===undefined&&home.x===4);return trace;
})();
