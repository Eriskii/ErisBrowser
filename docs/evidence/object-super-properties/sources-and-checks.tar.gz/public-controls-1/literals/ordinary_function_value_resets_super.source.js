touched++;({m(){return {f:function(){return super.x;}};}});
