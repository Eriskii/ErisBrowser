({*m(){yield super.x;}});
