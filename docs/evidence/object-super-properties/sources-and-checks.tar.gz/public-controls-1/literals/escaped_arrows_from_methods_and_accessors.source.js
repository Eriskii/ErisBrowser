function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',base={get x(){trace+='G';return this.tag;},set x(v){trace+='S';this.saved=v;}};
var savedSetter,home={__proto__:base,make(){return ()=>super.x;},get arrow(){return ()=>super.x;},set arrow(v){savedSetter=()=>super.x=v;}};
var r={tag:4},get=home.make.call(r),d=Object.getOwnPropertyDescriptor(home,'arrow'),access=d.get.call(r);
d.set.call(r,5);check(get.call({tag:99})===4&&access()===4);savedSetter();check(r.saved===5);
Object.setPrototypeOf(home,{get x(){trace+='N';return this.tag+1;}});check(get()===5&&access()===5);
return trace;
})();
