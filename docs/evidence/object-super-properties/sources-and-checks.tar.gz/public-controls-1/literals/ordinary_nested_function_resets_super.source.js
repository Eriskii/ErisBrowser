touched++;({m(){function f(){return ()=>super.x;}return f;}});
