function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var outer={__proto__:{x:'outer'},build(){var inner={__proto__:{x:'inner'},arrow:()=>super.x,m(){return super.x;}};check(super.x==='outer');return inner;}};
var inner=outer.build();check(inner.arrow()==='outer'&&inner.m()==='inner');
Object.setPrototypeOf(outer,{x:'live'});check(inner.arrow.call({})==='live'&&inner.m()==='inner');
return 'outer:inner:live';
})();
