function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var trace='',base={x:4},home={m(){return super.x;},__proto__:(trace+='P',base),['__proto__']:(trace+='D',7)};
check(home.m()===4&&home.__proto__===7&&Object.getPrototypeOf(home)===base);
var accessor={__proto__:base,get __proto__(){return super.x;},set __proto__(v){super.x=v;}};
check(accessor.__proto__===4);accessor.__proto__=8;check(accessor.x===8&&base.x===4);
var method={__proto__:base,__proto__(){return super.x;}};check(method.__proto__()===4);
return trace;
})();
