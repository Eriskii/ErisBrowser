function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
var base={get receiver(){'use strict';return this;}},home={__proto__:base,read(){return super.receiver;}};
var number=home.read.call(7),nil=home.read.call(null),undef=home.read.call(undefined);
if(typeof number==='object'){check(number.valueOf()===7&&nil===globalThis&&undef===globalThis);return 'boxed:global:global';}
check(number===7&&nil===null&&undef===undefined);return 'primitive:null:undefined';
})();
