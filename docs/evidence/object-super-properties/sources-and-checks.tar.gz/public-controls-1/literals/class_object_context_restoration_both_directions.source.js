function check(v){if(!v)throw new Error('object super oracle');}
function expect(C,f){var caught=false;try{f();}catch(e){caught=true;check(e instanceof C);}check(caught);}
var result=(function(){
class A { get x(){return 'class';} }
class C extends A { build(){var o={__proto__:{x:'object'},m(){return super.x;},arrow:()=>super.x};check(super.x==='class');return o;} }
var o=new C().build();check(o.m()==='object'&&o.arrow()==='class');
var outer={__proto__:{Base:A,key:'read',x:'outer'},build(){class D extends super.Base {[super.key](){return super.x;}}check(super.x==='outer');return D;}};
var D=outer.build();check(new D().read()==='class');return 'class:object:outer:class';
})();
