var trace='',caught=0,finalized=0,after=0,queuedRan=0;
var queued=function(){queuedRan++;};queueMicrotask(queued);
function spin(){while(true){}}
var key={};key[Symbol.toPrimitive]=function(){trace+='C';spin();return 'x';};
var home={__proto__:{get x(){trace+='G';return 1;}},m(){return super[(trace+='K',key)];}};
try{home.m();after++;}catch(e){caught++;}finally{finalized++;}after++;
