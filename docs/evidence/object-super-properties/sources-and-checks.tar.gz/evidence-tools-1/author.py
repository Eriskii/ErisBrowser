"""Stdlib-only adaptation author; does not import or execute the evidence tools."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re

L = Path('/tmp/eris-object-super-properties-plan-1')
H = L / 'evidence-tools-1'
K = Path('/tmp/eris-super-properties-plan-1/evidence-tools-1')
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'
OLD_BASE = 'db02f8c890a459b979378900f113b67460a49121'
CHECKPOINT = 'object-super-properties'
OLD_CHECKPOINT = 'class-super-properties'


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def write(name, value):
    (H / name).write_text(json.dumps(value, indent=2) + '\n')


original_seal = json.loads((K / 'source-ready.json').read_text())
original_bindings = {Path(row['path']).name: row for row in original_seal['files']}
prior_peer = K.parent / 'evidence-tools-review-1/review.json'
peer = json.loads(prior_peer.read_text())
assert peer['status'] == 'clear'
assert peer['selected_hold'] == binding(K / 'source-ready.json')


class Normalize(ast.NodeTransformer):
    def visit_Name(self, node):
        if node.id == 'L':
            node.id = 'K'
        return node

    def visit_alias(self, node):
        if node.name == 'L':
            node.name = 'K'
        return node

    def visit_Constant(self, node):
        if isinstance(node.value, str):
            node.value = re.sub(r'\bL\b', 'K', node.value).replace(BASE, OLD_BASE).replace(CHECKPOINT, OLD_CHECKPOINT)
        return node


changes = []
checks = []
for name in ['package.py', 'verify.py', 'evidence_common.py']:
    origin = K / name
    assert binding(origin) == original_bindings[name]
    before = origin.read_text()
    after, renamed = re.subn(r'\bK\b', 'L', before)
    base_count = after.count(OLD_BASE)
    checkpoint_count = after.count(OLD_CHECKPOINT)
    after = after.replace(OLD_BASE, BASE).replace(OLD_CHECKPOINT, CHECKPOINT)
    assert renamed > 0
    assert base_count == (1 if name == 'evidence_common.py' else 0)
    assert checkpoint_count == (1 if name == 'evidence_common.py' else 0)
    inverse = after.replace(BASE, OLD_BASE).replace(CHECKPOINT, OLD_CHECKPOINT)
    inverse = re.sub(r'\bL\b', 'K', inverse)
    assert inverse == before
    old_ast = ast.parse(before, filename=str(origin))
    new_ast = ast.parse(after, filename=str(H / name))
    normalized = Normalize().visit(new_ast)
    assert ast.dump(old_ast, include_attributes=False) == ast.dump(normalized, include_attributes=False)
    (H / 'before').mkdir(exist_ok=True)
    (H / 'before' / name).write_text(before)
    (H / name).write_text(after)
    forward_diff = ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                                fromfile='K/evidence-tools-1/' + name,
                                                tofile='L/evidence-tools-1/' + name))
    inverse_diff = ''.join(difflib.unified_diff(after.splitlines(True), before.splitlines(True),
                                                fromfile='L/evidence-tools-1/' + name,
                                                tofile='K/evidence-tools-1/' + name))
    (H / (name + '.diff')).write_text(forward_diff)
    (H / (name + '.inverse.diff')).write_text(inverse_diff)
    changes.append({'name': name, 'origin': binding(origin), 'before': binding(H / 'before' / name),
                    'raw': binding(H / name), 'diff': binding(H / (name + '.diff')),
                    'inverse_diff': binding(H / (name + '.inverse.diff')),
                    'substitutions': {'standalone_K_to_L': renamed, 'base_literal': base_count,
                                      'checkpoint_literal': checkpoint_count}})
    checks.append({'module': name, 'ast_parse': True, 'full_module_ast_equal_after_identity_normalization': True,
                   'exact_inverse': True,
                   'top_level_functions': [node.name for node in old_ast.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef))]})

common = (H / 'evidence_common.py').read_text()
assert "require(set(snapshot_receipt) == {'root', 'files'}" in common
assert "snapshot_receipt['root'] == str(snapshot_root)" in common
assert "require(set(snapshot_rows) == changed" in common
assert "require(set(snapshots) == changed and changed" in common
assert "MAX_MEMBERS = 20000" in common and "MAX_BYTES = 128 * 1024 * 1024" in common

write('adaptation.json', {
    'status': 'held source-only identity adaptation; unexecuted',
    'adapted_from': binding(K / 'source-ready.json'),
    'prior_review': binding(prior_peer),
    'checkpoint': CHECKPOINT, 'published_base': BASE,
    'changes': changes,
    'permitted_changes': [
        'Rename the origin-root identifier and accompanying K labels to L.',
        'Set checkpoint to object-super-properties, deriving the new evidence output directory.',
        'Set the pinned source base to db880b867daa2ec7bfc82cb2041aec935d5b8189.',
    ],
    'unchanged': [
        'Every function/control-flow/validation operation after identity normalization.',
        'Path canonicality, regular-file/ancestor/symlink checks and exclusive output creation.',
        'Archive selection/exclusions, sorted exact origins, member/byte bounds and deterministic encoding.',
        'Source inventory/worktree/base closure, complete changed snapshot roster and exact root/files snapshot schema.',
        'Seven selected receipt names, pass/clear statuses, final source/ledger/document hold/peer hash joins.',
        'Required artifact membership and documentation raw/imported byte equality.',
        'Binary exclusions retain JSON sidecars/build provenance; failed and superseded artifacts stay eligible.',
        'No extraction; exact tar/gzip/body/metadata verification and deterministic re-encoding.',
    ],
    'checks': checks,
    'snapshot_schema_warning': 'The current root/candidate-snapshots-3.json has changed_paths and is not an accepted source_snapshots selector. Root supplies a separate final receipt with exactly root and files; no permissive fallback was added.',
    'scope': 'Selected source and evidence artifacts only; no complete self-contained build graph or hardware/performance/security/whole-browser compatibility claim.',
    'authored_tools_imported_or_executed': False,
})
write('selection-shape.json', {
    'purpose': 'Prospective schema only; not an executable selection and not a completed-input receipt. Root supplies the exact final bindings after validation and documentation peers are sealed.',
    'format': 1,
    'checkpoint': CHECKPOINT,
    'exact_top_level_keys': ['format', 'checkpoint', 'inputs', 'documents', 'source_snapshot_root', 'required_artifacts'],
    'binding_shape': {'path': 'normalized L-relative regular file path', 'bytes': 'nonnegative integer', 'sha256': '64 lowercase hexadecimal digits'},
    'inputs': {
        'source_parent': 'Actual source-parent.json binding at published db880; retain its recorded scope.',
        'source_inventory': 'Actual final selected source inventory binding. No candidate number or result count is hardcoded.',
        'source_snapshots': 'Root-supplied final selector with exactly {root, files}; files entries are repository-relative path, bytes and sha256 for every derived changed source.',
        'final_validation': 'Actual root ledger binding with status pass; pending at authoring.',
        'validation_review': 'Actual independent peer binding with status clear and selected final-ledger hash; pending at authoring.',
        'documentation_hold': 'Actual selected five-document source-ready binding, including selected final-ledger hash; pending at authoring.',
        'documentation_review': 'Actual clear independent doc peer binding both selected doc hold and final ledger; pending at authoring.',
    },
    'source_snapshots_receipt_shape': {
        'root': 'absolute L/candidate-source-N directory matching selected source_snapshot_root',
        'files': [{'path': 'normalized repository-relative path', 'bytes': 'nonnegative integer', 'sha256': '64 lowercase hexadecimal digits'}],
    },
    'source_snapshot_root': 'Normalized L-relative final candidate snapshot directory, whose physical files and selected rows exactly equal the complete derived source delta.',
    'documents': 'Sorted unique actual repository-relative paths, exactly equal to the selected documentation raw/ roster. Five paths are planned; no path names or completed hashes are invented here. Only README.md/docs paths are admitted, never docs/evidence outputs.',
    'required_artifacts': 'Nonempty unique binding list for accepted producer/control/correction/review/final release binary sidecar/build/environment/profile/result receipts and these evidence tools plus their peer. All selected artifacts must be included archive members.',
    'not_accepted_as_snapshot_selector': 'root/candidate-snapshots-3.json with changed_paths; root will create the existing exact root/files shape separately.',
})
write('execution-contract.json', {
    'status': 'Held recipe only; no packaging or verification executed',
    'checkpoint': CHECKPOINT, 'pinned_base': BASE,
    'adapted_from': binding(K / 'source-ready.json'),
    'prior_review': binding(prior_peer),
    'cwd': str(L),
    'commands': [
        'python3 -B evidence-tools-1/package.py --selection root/evidence-selection-1.json',
        'python3 -B evidence-tools-1/verify.py --selection root/evidence-selection-1.json',
    ],
    'commands_are_prospective_only': True,
    'outputs': ['worktree/docs/evidence/object-super-properties/sources-and-checks.tar.gz', 'worktree/docs/evidence/object-super-properties/manifest.json'],
    'execution': [
        'Root freezes eligible L artifacts after the actual final ledger, final source/snapshot selector, validation peer, five-document hold and document peer exist.',
        'Root imports the exact selected documents, then supplies a real selection receipt with all required artifact bindings, including final release sidecars/build provenance and accepted tool review. No illustrative receipt is executed.',
        'Use the same explicit --selection for package and verify. Do not mutate eligible inputs afterward. Precondition, origin and selected membership checks run before output and again after processing.',
        'Capture command output only under excluded publication/ or the three exact excluded root output receipts. Do not append included validation logs after freeze.',
        'Exclusive creation refuses old outputs. A failed attempt must remain retained; do not silently overwrite or modify the selection to evade a refusal.',
        'Failed tests, corrections, superseded candidates/holds and recipe findings remain eligible history and are not promoted to passing outcomes by inclusion.',
    ],
    'excluded_root_outputs': ['root/publication-verification.json', 'root/github-publication.json', 'root/git-publication.json'],
    'archive_selection': 'All sorted regular eligible L origins. Worktree, publication, target-prefixed top paths, cache/git/target directories, symlinks and specified non-JSON binary paths are excluded; source-hold manifests and JSON binary provenance remain eligible.',
    'bounds': {'members': 20000, 'uncompressed_member_bytes': 134217728},
    'safeguards': [
        'Exact seven-input selection schema, pass/clear statuses, source/base joins, final-ledger hash in both documentation hold and peer, and exact document-hold hash in its peer.',
        'Selected current source/worktree hashes and lengths, pinned Git fallback for added inventory coverage, exact derived delta and root/files snapshots.',
        'Exact sorted unique document roster, raw hashes sealed by selected hold, and byte-identical imported files.',
        'Canonical relative paths, lstat checks through ancestors, symlink refusal for selected artifacts, no untrusted extraction, output ancestors checked before/after mkdir.',
        'No recursive worktree outputs, exclusive output files, USTAR regular members with normalized owner/mode/time and deterministic gzip.',
        'Exact origin/member/body hashes, whole gzip trailer validation, bounded expansion and deterministic re-encoding to reject hidden tails or concatenated streams.',
        'Selected receipts, required artifacts, documents and snapshots must be included; unexpected executables/credential-shaped artifacts and special filesystem entries refuse.',
    ],
    'scope': 'A selected-source evidence archive, not a complete self-contained compiler/system build graph, exact Git publication verifier, or hardware/performance/security/whole-browser compatibility claim.',
    'validation_claim': 'Only stdlib AST parsing, identity-normalized source equality and exact inverse checks were performed. Authored tools were neither imported nor executed; no outputs were created.',
})
write('source-checks.json', {
    'status': 'inert source checks passed', 'modules': checks,
    'exact_snapshot_schema_retained': True, 'prior_review_and_source_hashes_verified': True,
    'no_control_flow_or_validation_changes_after_identity_normalization': True,
    'no_execution_of_packager_verifier_or_common_module': True,
    'no_live_edits_or_archive_outputs': True,
})
files = [binding(path) for path in sorted(H.rglob('*')) if path.is_file() and path.name != 'source-ready.json']
write('source-ready.json', {
    'schema': 1,
    'status': 'source-ready held evidence tools; root supplies actual final selection and executes after independent review',
    'checkpoint': CHECKPOINT, 'published_base': BASE,
    'adapted_from': binding(K / 'source-ready.json'), 'prior_review': binding(prior_peer),
    'files': files, 'adaptation': binding(H / 'adaptation.json'),
    'prospective_schema': binding(H / 'selection-shape.json'),
    'project_execution': False, 'live_edits': False, 'outputs_created': False,
    'pending_inputs_are_not_fabricated': True,
})
print(json.dumps(binding(H / 'source-ready.json'), indent=2))
