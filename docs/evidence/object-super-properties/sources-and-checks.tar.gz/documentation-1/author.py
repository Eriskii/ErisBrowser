"""Prepare held documentation draft using stdlib/read-only Git. No project execution."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

P=Path(__file__).resolve().parent
L=P.parent
W=L/'worktree'
BASE='db880b867daa2ec7bfc82cb2041aec935d5b8189'

def bind(path):
 data=path.read_bytes();return dict(path=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def put(name,value):
 (P/name).write_text(json.dumps(value,indent=2)+'\n')
def write(path,text):
 path.parent.mkdir(parents=True,exist_ok=True);path.write_text(text)

edits={
 'README.md':[(
 'arrows. Object-literal method `super`, fields, private elements, static blocks\nand async/generator methods remain unsupported. The separate [Promise class-admission checkpoint](docs/promise-class-admission.md)\n',
 'arrows. [Object-literal methods and accessors](docs/object-super-properties.md)\nnow support the same `super` property operations while preserving ordinary\nstrict/sloppy behavior. Fields, private elements, static blocks and\nasync/generator methods remain unsupported. The separate [Promise class-admission checkpoint](docs/promise-class-admission.md)\n')],
 'docs/ROADMAP.md':[(
 "method's home and actual receiver. Object-literal method `super`, fields,\nprivate elements, static blocks and async/generator methods remain future work. Upstream class feature admission\n",
 "method's home and actual receiver. [Object-literal methods and accessors](object-super-properties.md)\nnow retain their own defining home and ordinary strict/sloppy behavior for\nthese operations. Fields, private elements, static blocks and async/generator\nmethods remain future work. Upstream class feature admission\n")],
 'docs/classes.md':[(
 'Object-literal method `super` remains unsupported.\n',
 'The later [object-literal method/accessor checkpoint](object-super-properties.md)\nalso supports these property operations with ordinary strict/sloppy behavior.\n')],
 'docs/class-super-properties.md':[(
 'Object-literal method/accessor `super`, fields, private elements, static blocks,\nasync/generator methods, optional chaining and tagged templates remain outside\nthis slice. Proxy objects, multiple realms and the other documented language\n',
 'The later [object-literal method/accessor checkpoint](object-super-properties.md)\nadds `super` properties in ordinary object methods. The validation below records\nthis earlier class-only checkpoint. Fields, private elements, static blocks,\nasync/generator methods, optional chaining and tagged templates remain outside\nthis slice. Proxy objects, multiple realms and the other documented language\n')],
}
chapter='''# Object-literal `super` properties

Ordinary object-literal concise methods, getters and setters now support
`super.name` and `super[key]`, including their parameter defaults and lexical
arrows. They reuse the [class `super` property operations](class-super-properties.md):
reads, calls, assignments, compound/logical assignments, updates, constructor
property calls and loop assignment targets. `delete super.x` is accepted syntax
and throws ReferenceError when evaluated. Direct `super()` remains forbidden
in object methods, including their defaults and arrows.

Each method retains the actual object where it was defined as its home.
Copying, borrowing or binding the function changes neither that identity nor
its lookup origin. Each new `super` reference reads the home's current prototype,
so a later `Object.setPrototypeOf` is observable. The call receiver is separate:
base getters, setters and method calls receive the method's actual `this`.
An escaped arrow keeps both the defining home and its lexical receiver.

Object methods retain ordinary strict/sloppy behavior. Sloppy methods perform
normal receiver conversion, including boxing primitive receivers; strict
methods retain the supplied receiver. Failed writes follow that method's
strictness: strict writes throw TypeError, while sloppy writes can return their
assignment value without changing the property. A writable base data property
examines the receiver's own descriptor; it does not invoke a setter found on
the receiver's prototype. Base accessors use the real receiver. Existing Array,
TypedArray, mapped-arguments and represented DOM routes keep their established
behavior and limitations.

Computed definition names run in the surrounding context before the new
method receives its own home. Defaults and the method body use the new home;
nested ordinary functions reset the `super` context, while lexical arrows
inherit it. Definitions retain source order and getter/setter merging. The
special `__proto__: value` form changes the object's prototype for an object or
null value, including when it appears after a method. Computed `__proto__` keys
and methods/accessors with that name remain ordinary properties. Duplicate
special prototype definitions remain syntax errors.

During property evaluation, the receiver is captured before a computed key's
effects, and the home prototype is captured after those effects. The raw key
is converted during the property operation. Simple assignment therefore runs
its right-hand side before conversion; compound assignments and updates reuse
the key converted for their read. Logical assignments omit the right-hand side
and write when they short-circuit. Calls preserve the receiver through
parentheses; a comma expression loses that reference. Callee getters run before
arguments. These operations retain the existing class-reference ordering and
ordinary thrown-value identity.

Attaching the defining home charges **eight work units and no additional heap**.
Admission and eligibility checks precede the single home publication; attachment
runs after function creation and before naming or property publication. Existing
function storage already pays for its home slot, and object creation, metadata,
property definitions, lookup and receiver operations retain their charges. This
is a logical accounting statement, not a claim that creating a method is free.
Runtime representations and limits are unchanged: 100,000 author work units,
1,000,000 trusted initialization units and 8 MiB of cumulative heap accounting.
Natural Resource and Unsupported failures retain reached effects and suppress
later bodies, catch/finally work and queued jobs under the existing observer.
A private attachment refusal alone does not establish that terminal boundary.

Optional chaining remains unsupported. A bounded parser correction recognizes
its adjacent `?.` prefix at supported expression boundaries and returns
Unsupported instead of misreading it as a conditional expression. Existing
context errors and the forbidden unparenthesized optional constructor prefix
retain SyntaxError. This is refusal classification, not parsing or validation
of the unimplemented optional-chain tail. Async/generator methods, object
spread, tagged templates, fields/private elements/static blocks, Proxy objects,
multiple realms and the other documented gaps remain outside this slice.

Runner/importer/protocol code, profile features, authenticated corpora and
baseline files are outside this runtime change. This chapter does not claim
complete ECMAScript conformance, a security certification, a performance
comparison or new GPU correctness evidence.
'''
rows=[]
for relative, changes in edits.items():
 before=subprocess.check_output(['git','show',BASE+':'+relative],cwd=W).decode()
 assert (W/relative).read_text()==before,relative
 after=before
 for old,new in changes:
  assert after.count(old)==1,relative
  after=after.replace(old,new)
 inverse=after
 for old,new in reversed(changes):
  assert inverse.count(new)==1
  inverse=inverse.replace(new,old)
 assert inverse==before
 write(P/'before'/relative,before);write(P/'raw'/relative,after)
 diff=P/'diffs'/(relative.replace('/','__')+'.diff')
 write(diff,''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+relative,tofile='b/'+relative)))
 rows.append(dict(relative_path=relative,before=bind(P/'before'/relative),raw=bind(P/'raw'/relative),diff=bind(diff),exact_inverse=True))
relative='docs/object-super-properties.md'
assert not (W/relative).exists()
write(P/'raw'/relative,chapter)
diff=P/'diffs'/(relative.replace('/','__')+'.diff')
write(diff,''.join(difflib.unified_diff([],chapter.splitlines(True),fromfile='/dev/null',tofile='b/'+relative)))
rows.append(dict(relative_path=relative,before=None,raw=bind(P/'raw'/relative),diff=bind(diff),parent_absent=True))
# Exact historical suffixes keep earlier measurements attached to their checkpoints.
class_marker='The subsequent [Promise class-admission checkpoint]'
a=(P/'before/docs/classes.md').read_text();b=(P/'raw/docs/classes.md').read_text()
assert a[a.index(class_marker):]==b[b.index(class_marker):]
validation_marker='Final validation passes **3,432'
a=(P/'before/docs/class-super-properties.md').read_text();b=(P/'raw/docs/class-super-properties.md').read_text()
assert a[a.index(validation_marker):]==b[b.index(validation_marker):]
validation_before=subprocess.check_output(['git','show',BASE+':docs/VALIDATION.md'],cwd=W)
assert (W/'docs/VALIDATION.md').read_bytes()==validation_before
put('edits.json',edits)
source=bind(L/'source-candidate-2.json')
holds=[
 'root/selection-1.json','source-parent.json','public-controls-1/source-ready.json',
 'public-controls-1/cases.json','public-base-refresh-1/source-ready.json','public-adapter-1/source-ready.json',
 'runtime-producer-1/source-ready.json','runtime-producer-1/raw/src/script/object_super_properties.rs',
 'parser-producer-1/source-ready.json','optional-refusal-producer-1/source-ready.json',
 'optional-refusal-producer-1/spec-and-scope.json','capture-controls-1/source-ready.json',
 'browser-controls-1/source-ready.json','historical-public-migration-1/source-ready.json',
 'profile-replay-1/source-ready.json',
]
put('claims-and-bindings.json',dict(status='Static semantics draft only; final validation and source selection pending.',
 base=BASE,source_context=source,source_context_qualification='Candidate 2 was the supplied draft inventory. Root reported a historical expectation migration and plans final candidate 3; this draft does not select candidate 2 for publication.',
 bindings=[bind(L/name) for name in holds],
 claims=[
 dict(topic='home identity and strict/sloppy semantics',sources=['root/selection-1.json','public-controls-1/cases.json','runtime-producer-1/source-ready.json']),
 dict(topic='fixed 8 work / zero additional heap; publication ordering',sources=['root/selection-1.json','runtime-producer-1/raw/src/script/object_super_properties.rs']),
 dict(topic='parser context and retained deferrals',sources=['parser-producer-1/source-ready.json','optional-refusal-producer-1/spec-and-scope.json']),
 dict(topic='natural terminal retained/suppressed effects',sources=['public-controls-1/cases.json','public-adapter-1/source-ready.json']),
 dict(topic='unchanged profile policy and baseline scope',sources=['root/selection-1.json','profile-replay-1/source-ready.json']),
 ],
 historical_classes_suffix_exact=True,historical_class_super_validation_suffix_exact=True,
 untouched_validation=bind(W/'docs/VALIDATION.md'),
 new_chapter_words=len(chapter.split()),final_counts_authored=False,final_profile_outcomes_authored=False,
 scope_qualification='Existing index/chapter totals stay historical; no completed L validation is claimed.',
 no_live_edits=True,no_project_execution=True,no_K_writes=True))
put('pending-validation.json',dict(status='Await root final ledger before final documentation hold.',
 required=[
 'Final selected source inventory and exact delta roster, including historical acceptance migration.',
 'Actual full Rust rosters, both configurations, and completed lint/format receipts.',
 'Actual focused/public/private/browser outcomes; distinguish groups from mode attempts.',
 'Eight release reports with complete 1330 case and 724 control arrays, all transitions honestly recorded.',
 'Actual ordinary/host release provenance and replay recheck.',
 'Retained first optional-prefix classification failure and separate missed historical Unsupported fixture.',
 'Final independent evidence review and approved evidence destination.'
 ],
 proposed_evidence=['docs/evidence/object-super-properties/manifest.json','docs/evidence/object-super-properties/sources-and-checks.tar.gz'],
 policy='Do not turn pending runs into claims, alter old results, or infer security/performance/GPU outcomes. Final source binding must replace the draft context explicitly in a separate final hold.'))
files=[dict(bind(path),path=str(path.relative_to(P))) for path in sorted(P.rglob('*')) if path.is_file() and path.name!='draft-ready.json']
put('draft-ready.json',dict(schema=1,status='Held static-semantics proposal; not final publication documentation.',
 base=BASE,source_context=source,source_context_is_final=False,
 files=rows,artifacts=files,claims=bind(P/'claims-and-bindings.json'),pending=bind(P/'pending-validation.json'),
 path_count=5,live_edits=False,project_execution=False,K_writes=False))
print(json.dumps(bind(P/'draft-ready.json')))
