"""Additive, inert source comparison. Never imports or executes project code."""
import ast
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

P = Path('/tmp/eris-object-super-properties-plan-1')
OUT = P / 'candidate-source-review-1'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'

def load(path):
    return json.loads((P/path).read_bytes())

def bind(path):
    path = Path(path)
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def match(data, row):
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']

# Reuse only our previous inert lexical comparison function, extracted with
# stdlib AST. The old checker and all project modules remain unexecuted.
old_checker = (OUT/'check.py').read_text()
node = next(n for n in ast.parse(old_checker).body if isinstance(n, ast.FunctionDef) and n.name == 'nonformat')
ns = {'re': re}
exec(compile(ast.Module(body=[node], type_ignores=[]), '<inert-review-lexer>', 'exec'), ns)
nonformat = ns['nonformat']

inventories = [load(f'source-candidate-{n}.json') for n in [1, 2, 3]]
assert all(i['base'] == BASE for i in inventories)
assert all({k:v for k,v in i.items() if k != 'files'} == {k:v for k,v in inventories[0].items() if k != 'files'} for i in inventories)
maps = [{r['path']: r for r in i['files']} for i in inventories]
assert all(len(m) == len(i['files']) == 15297 for m,i in zip(maps,inventories))
assert set(maps[0]) == set(maps[1]) == set(maps[2])
delta12 = sorted(p for p in maps[0] if maps[0][p] != maps[1][p])
delta23 = sorted(p for p in maps[1] if maps[1][p] != maps[2][p])
assert delta12 == ['src/script/parser/driver/expressions.rs', 'src/script/parser/super_property_tests.rs']
assert delta23 == ['src/script.rs']
parent = load('source-parent.json')
parent_map = {r['path']:r for r in parent['files']}
changed = sorted(p for p in maps[2] if parent_map.get(p) != maps[2][p])
snap = load('root/candidate-snapshots-3.json')
assert len(changed) == 15
assert snap['changed_paths'] == [maps[2][p] for p in changed]
assert snap['source_inventory']['sha256'] == bind(P/'source-candidate-3.json')['sha256']
assert snap['source_inventory']['inputs'] == 15297
for n in [1, 2, 3]:
    folder = P/f'candidate-source-{n}'
    roster = sorted(p for p in maps[n-1] if parent_map.get(p) != maps[n-1][p])
    assert sorted(str(f.relative_to(folder)) for f in folder.rglob('*') if f.is_file()) == roster
    for p in roster:
        match((folder/p).read_bytes(), maps[n-1][p])

optional = load('optional-refusal-producer-1/source-ready.json')
assert optional['candidate_parent']['sha256'] == bind(P/'source-candidate-1.json')['sha256']
assert optional['published_base'] == BASE
for row in optional['artifacts']:
    match(Path(row['path']).read_bytes(), row)
for row in optional['payloads']:
    path = row['path']
    before = Path(row['before']['path']).read_bytes()
    raw = Path(row['raw']['path']).read_bytes()
    match(before, maps[0][path])
    if path == 'src/script/parser/driver/expressions.rs':
        published = subprocess.check_output(['git','-C',str(P/'worktree'),'show',BASE+':'+path])
        assert published == before
        assert raw == (P/'candidate-source-3'/path).read_bytes()
    else:
        assert before == (P/'candidate-source-1'/path).read_bytes()
        assert raw == before + (P/'optional-refusal-producer-1/new-tests.rs').read_bytes()
        formatted = (P/'candidate-source-3'/path).read_bytes()
        assert nonformat(raw.decode()) == nonformat(formatted.decode())
        assert formatted.startswith(before)
        diff = ''.join(difflib.unified_diff(raw.decode().splitlines(True), formatted.decode().splitlines(True), fromfile='raw/'+path, tofile='formatted/'+path))
        assert diff == (P/'format-2/diffs'/Path(path+'.patch')).read_text()
    reconstructed = before.decode()
    for edit in load('optional-refusal-producer-1/edits.json'):
        if edit['path'] != path:
            continue
        if 'append' in edit:
            reconstructed += edit['append']
        else:
            assert reconstructed.count(edit['old']) == edit['count'] == 1
            reconstructed = reconstructed.replace(edit['old'], edit['new'], 1)
    assert reconstructed.encode() == raw
    if path.endswith('expressions.rs'):
        for edit in reversed(load('optional-refusal-producer-1/edits.json')):
            if edit['path'] == path:
                assert reconstructed.count(edit['new']) == 1
                reconstructed = reconstructed.replace(edit['new'], edit['old'], 1)
        assert reconstructed.encode() == before

historical = load('historical-method-migration-1/source-ready.json')
assert historical['candidate_parent']['sha256'] == bind(P/'source-candidate-2.json')['sha256']
before = (P/'historical-method-migration-1/before/src/script.rs').read_bytes()
raw = (P/'historical-method-migration-1/raw/src/script.rs').read_bytes()
assert before == (P/'candidate-source-1/src/script.rs').read_bytes() == (P/'candidate-source-2/src/script.rs').read_bytes()
assert raw == (P/'candidate-source-3/src/script.rs').read_bytes()
match(raw, maps[2]['src/script.rs'])
anchor = b'        Runtime::parse_only("({m(a=1){return a;}})").unwrap();\n'
addition = b'        Runtime::parse_only("({m(){return super.x;}})").unwrap();\n'
removal = b'            "({m(){return super.x;}})",\n'
assert before.count(anchor) == before.count(removal) == 1
assert before.replace(anchor, anchor+addition, 1).replace(removal, b'', 1) == raw
assert raw.replace(addition, b'', 1).replace(b'            "({...x})",\n', b'            "({...x})",\n'+removal, 1) == before
assert before.count(b'({m(){return super.x;}})') == raw.count(b'({m(){return super.x;}})')
assert before.count(b'#[test]') == raw.count(b'#[test]')
for name,a,b in [('forward.patch',before,raw),('inverse.patch',raw,before)]:
    diff=''.join(difflib.unified_diff(a.decode().splitlines(True),b.decode().splitlines(True),fromfile='a/src/script.rs',tofile='b/src/script.rs'))
    assert diff == (P/'historical-method-migration-1'/name).read_text()

cases = load('public-controls-1/cases.json')
rawpat = re.compile(r'r####"(.*?)"####', re.S)
bodies = {}
for name in ['object_super_property_semantics_tests.rs','object_super_property_abort_tests.rs']:
    path = 'src/script/'+name
    text = (P/'candidate-source-3'/path).read_text()
    assert text == (P/'candidate-source-1'/path).read_text()
    starts = list(re.finditer(r'(?m)^#\[test\]\nfn (\w+)\(',text))
    for n,m in enumerate(starts):
        bodies[m[1]] = text[m.start():starts[n+1].start() if n+1<len(starts) else len(text)]
fields = 0
for row in cases:
    actual = rawpat.findall(bodies.pop('object_super_property_'+row['id']))
    expected = [row['id']]
    if row['kind'] == 'semantic':
        expected += [row['source'],row['readback'],row['expected']['sloppy'],row['expected']['strict']]
    elif row['kind'] == 'early-error':
        expected += [row['setup'],row['source'],row['readback']]
    elif row['kind'] == 'deferred':
        expected += [row['source']]
    else:
        expected += [row['source'],row['expected']['trace']]
        for key,value in row['expected'].get('retained_string',{}).items():
            expected += [key,value]
    assert actual == expected
    fields += sum(k in row for k in ['source','setup','readback'])
assert len(cases) == 41 and fields == 80 and not bodies
append = (P/'optional-refusal-producer-1/new-tests.rs').read_text()
groups = re.findall(r'(?m)^fn (optional_chain_parser_\w+)\(', append)
assert len(groups) == 3
arrays = re.findall(r'for source in \[\n(.*?)\n        \] \{', append, re.S)
sizes = [len(re.findall(r'^\s*"', a, re.M)) for a in arrays]
assert sizes == [13,15,4]
assert sum(sizes)*2+2 == 66

result = dict(status='clear', inventory_inputs=15297, parent_inputs=15289,
    changed_paths_from_base=changed, new_paths_from_base=sorted(set(maps[2])-set(parent_map)),
    unchanged_parent_paths=len(parent_map)-len(set(changed)&set(parent_map)),
    candidate1_to_2=delta12, candidate2_to_3=delta23,
    unchanged_candidate1_rows=15294, exact_snapshot_joins=[14,15,15],
    parser_production_inverse=True, parser_tests_exact_old_prefix=True,
    format2_nonwhitespace_strings_comments_exact=True,
    historical_literal_exact_move=True, historical_test_count_change=0,
    original_public_cases=41, original_js_fields=80,
    producer_parser_groups=groups, producer_planned_parse_attempts=66,
    source_inventory=bind(P/'source-candidate-3.json'),
    snapshots=bind(P/'root/candidate-snapshots-3.json'),
    prior_review=bind(OUT/'review.json'),
    optional_hold=bind(P/'optional-refusal-producer-1/source-ready.json'),
    historical_hold=bind(P/'historical-method-migration-1/source-ready.json'),
    formatting=bind(P/'format-2/diffs/src/script/parser/super_property_tests.rs.patch'),
    original_oracle=bind(P/'public-controls-1/cases.json'),
    checker=bind(Path(__file__)),
    project_execution=False, project_imports=False, outcome_logs_read=False, live_edits=False)
target=OUT/'candidate3-source-checks.json'
assert not target.exists()
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(bind(target)))
