"""Inert held-source/inventory comparison; no project code is imported or run."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

P = Path('/tmp/eris-object-super-properties-plan-1')
W = P/'worktree'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'
OUT = P/'candidate-source-review-1'

def load(path):
    return json.loads((P/path).read_bytes())

def binding(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

def matches(data, row):
    assert len(data) == row['bytes']
    assert hashlib.sha256(data).hexdigest() == row['sha256']

parent = load('source-parent.json')
candidate = load('source-candidate-1.json')
snapshots = load('root/candidate-snapshots-1.json')
assert parent['base'] == candidate['base'] == BASE
before = {r['path']: r for r in parent['files']}
after = {r['path']: r for r in candidate['files']}
assert len(before) == len(parent['files']) == 15289
assert len(after) == len(candidate['files']) == 15297
assert set(before) <= set(after)
changed = sorted(path for path, row in after.items() if before.get(path) != row)
selected = {r['path']: r for r in snapshots['changed_paths']}
assert len(changed) == len(selected) == 14 and changed == sorted(selected)
for path, row in selected.items():
    assert row == after[path]
    matches((P/'candidate-source-1'/path).read_bytes(), row)
assert sorted(str(q.relative_to(P/'candidate-source-1')) for q in (P/'candidate-source-1').rglob('*') if q.is_file()) == changed
assert snapshots['source_inventory']['sha256'] == binding(P/'source-candidate-1.json')['sha256']

# Verify all parent inventory bytes against the published commit without reading
# changing worktree source. One long-lived Git plumbing process bounds memory.
proc = subprocess.Popen(['git','-C',str(W),'cat-file','--batch'], stdin=subprocess.PIPE, stdout=subprocess.PIPE)
assert proc.stdin is not None and proc.stdout is not None
git_rows = []
for path, row in sorted(before.items()):
    proc.stdin.write((BASE+':'+path+'\n').encode())
    proc.stdin.flush()
    header = proc.stdout.readline().decode().strip().split()
    assert len(header) == 3 and header[1] == 'blob', (path,header)
    size = int(header[2])
    data = proc.stdout.read(size)
    assert len(data) == size and proc.stdout.read(1) == b'\n'
    matches(data,row)
    git_rows.append((path,header[0],row['sha256']))
proc.stdin.close()
assert proc.wait() == 0

expected = {}
origins = {}
for hold in ['runtime-producer-1','browser-controls-1','historical-public-migration-1']:
    seal = load(hold+'/source-ready.json')
    assert seal['base'] == BASE
    for row in seal['paths']:
        path = row['path']
        data = (P/hold/'raw'/path).read_bytes()
        assert hashlib.sha256(data).hexdigest() == row['after'] and len(data)==row['bytes']
        if row['before'] is None:
            assert path not in before
        else:
            assert before[path]['sha256'] == row['before']
        assert path not in expected
        expected[path]=data
        origins[path]=[hold]
parser=load('parser-producer-1/source-ready.json')
for row in parser['payloads']:
    path=row['path'];data=Path(row['after']['path']).read_bytes();matches(data,row['after'])
    assert before[path]['sha256']==row['before']['sha256']
    expected[path]=data;origins[path]=['parser-producer-1']
for hold in ['capture-controls-1','public-adapter-1']:
    for row in load(hold+'/source-ready.json')['files']:
        path=row['relative_path'];data=Path(row['raw']['path']).read_bytes();matches(data,row['raw'])
        assert path not in before and path not in expected
        expected[path]=data;origins[path]=[hold]
expected['src/script.rs'] += (P/'public-adapter-1/registration/append.rs').read_bytes()
origins['src/script.rs'].append('public-adapter-1 registration append')
expected['src/script/object_super_properties.rs'] += b'\n'+(P/'capture-controls-1/registration.rs').read_bytes()
origins['src/script/object_super_properties.rs'].append('capture-controls-1 cfg(test) child append')
assert sorted(expected)==changed

# Preserve string/character/comment bytes while removing only surrounding
# whitespace. This is an inert lexer, not a Rust parser or producer import.
def nonformat(text):
    tokens=[];i=0
    while i<len(text):
        if text[i].isspace(): i+=1;continue
        start=i
        if text.startswith('//',i):
            end=text.find('\n',i);i=len(text) if end<0 else end
        elif text.startswith('/*',i):
            depth=1;i+=2
            while depth:
                assert i<len(text)
                if text.startswith('/*',i):depth+=1;i+=2
                elif text.startswith('*/',i):depth-=1;i+=2
                else:i+=1
        else:
            raw=re.match(r'r(\#*)"',text[i:])
            char=re.match(r"'(?:[^'\\\n]|\\(?:[^u]|u\{[0-9a-fA-F_]+\}))'",text[i:])
            if raw:
                stop='"'+raw[1];end=text.find(stop,i+len(raw[0]));assert end>=0;i=end+len(stop)
            elif text[i]=='"':
                i+=1
                while i<len(text):
                    if text[i]=='\\':i+=2
                    elif text[i]=='"':i+=1;break
                    else:i+=1
                else:raise AssertionError('unclosed string')
            elif char:i+=len(char[0])
            else:i+=1
        tokens.append(text[start:i])
    return tokens

formatted={r['path']:r for r in snapshots['format_only_changes']}
assert set(formatted)=={
    'src/script/parser/super_property_tests.rs',
    'src/script/object_super_properties/tests.rs',
    'src/script/object_super_property_semantics_tests.rs',
    'src/script/object_super_property_abort_tests.rs',
}
joins=[]
for path, held in sorted(expected.items()):
    frozen=(P/'candidate-source-1'/path).read_bytes()
    if path in formatted:
        row=formatted[path]
        assert hashlib.sha256(held).hexdigest()==row['before']
        assert hashlib.sha256(frozen).hexdigest()==row['after']
        assert nonformat(held.decode())==nonformat(frozen.decode())
        diff=''.join(difflib.unified_diff(held.decode().splitlines(True),frozen.decode().splitlines(True),fromfile='held/'+path,tofile='formatted/'+path))
        assert diff==Path(row['diff']).read_text()
    else:assert frozen==held
    joins.append(dict(path=path,origins=origins[path],format_only=path in formatted,sha256=after[path]['sha256']))
imports=load('root/candidate-import-1.json')
for row in imports['paths']:
    path=row['path'];assert hashlib.sha256(expected[path]).hexdigest()==row['after']
    assert (P/'candidate-import-1/after'/path).read_bytes()==expected[path]
    before_path=P/'candidate-import-1/before'/path
    if row['before'] is None:assert not before_path.exists()
    else:assert binding(before_path)['sha256']==row['before']

cases=load('public-controls-1/cases.json')
rawpat=re.compile(r'r####"(.*?)"####',re.S)
body_rows={}
for name in ['object_super_property_semantics_tests.rs','object_super_property_abort_tests.rs']:
    text=(P/'candidate-source-1/src/script'/name).read_text()
    starts=list(re.finditer(r'(?m)^#\[test\]\nfn (\w+)\(',text))
    for n,m in enumerate(starts):body_rows[m[1]]=text[m.start():starts[n+1].start() if n+1<len(starts) else len(text)]
fields=0
for row in cases:
    actual=rawpat.findall(body_rows.pop('object_super_property_'+row['id']))
    kind=row['kind'];expected_literals=[row['id']]
    if kind=='semantic':expected_literals += [row['source'],row['readback'],row['expected']['sloppy'],row['expected']['strict']]
    elif kind=='early-error':expected_literals += [row['setup'],row['source'],row['readback']]
    elif kind=='deferred':expected_literals += [row['source']]
    else:
        expected_literals += [row['source'],row['expected']['trace']]
        for key,value in row['expected'].get('retained_string',{}).items():expected_literals += [key,value]
    assert actual==expected_literals
    fields += sum(key in row for key in ['source','setup','readback'])
assert len(cases)==41 and fields==80 and not body_rows

result=dict(status='clear source closure for candidate1 only',base=BASE,source_inventory=binding(P/'source-candidate-1.json'),snapshots=binding(P/'root/candidate-snapshots-1.json'),parent_inventory=binding(P/'source-parent.json'),inputs=15297,parent_inputs=15289,changed_paths=14,new_paths=len(set(after)-set(before)),unchanged_parent_paths=len(before)-len(set(changed)&set(before)),full_parent_git_blob_joins=len(git_rows),git_join_rows_digest=hashlib.sha256(json.dumps(git_rows,separators=(',',':')).encode()).hexdigest(),held_payload_joins=joins,format_only_paths=sorted(formatted),public_cases=41,exact_js_fields=80,checks='All parent inventory rows match published Git bytes; every remaining inventory row either stays exactly equal or belongs to the exact 14 changed snapshots. All 14 snapshot payloads compose from sealed holds, and only four have whitespace-only differences with strings/chars/comments unchanged. No execution outcomes read.',qualification='Root reports one candidate optional-chain classification failure. This receipt covers source closure and literal preservation only, not functional acceptance; a separately held correction and later inventory addendum are required.',project_execution=False,live_edits=False)
(OUT/'source-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(binding(OUT/'source-checks.json')))
