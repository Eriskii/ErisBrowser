"""Independent inert receipt/source audit; imports only Python standard library."""
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import subprocess

L = Path('/tmp/eris-object-super-properties-plan-1')
K = Path('/tmp/eris-super-properties-plan-1')
W = L / 'worktree'
O = L / 'validation-review-1'

def load(p):
    return json.loads(Path(p).read_bytes())

def bind(p):
    p = Path(p)
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=hashlib.sha256(b).hexdigest())

verified = {}
def verify(row):
    assert bind(row['path']) == row, row['path']
    verified[row['path']] = row
    return load(row['path']) if str(row['path']).endswith('.json') else None

def nested(x):
    if isinstance(x, dict):
        if set(x) == {'path', 'bytes', 'sha256'} and Path(x['path']).is_absolute():
            verify(x)
        else:
            for v in x.values(): nested(v)
    elif isinstance(x, list):
        for v in x: nested(v)

ledger_path = L / 'root/final-validation.json'
assert bind(ledger_path)['sha256'] == 'f1765e41d488a383ca1a56e11dfca372316a1ca4a5ea0f21e7e6babc1cd18bf3'
d = load(ledger_path)
nested(d)
assert d['status'] == 'pass'
base = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'
assert d['base'] == subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip() == base
inv = verify(d['source_inventory'])
parent = load(L/'source-parent.json')
assert parent['base'] == inv['base'] == base
rows = {r['path']: r for r in inv['files']}
old = {r['path']: r for r in parent['files']}
assert len(rows) == len(inv['files']) == d['selected_inputs'] == 15297
assert len(old) == 15289 and old.keys() <= rows.keys()
changed = sorted(p for p,r in rows.items() if old.get(p) != r)
assert len(changed) == d['changed_source_paths'] == 15
assert len(rows.keys()-old.keys()) == 8
for p,r in rows.items():
    assert dict(bind(W/p),path=p) == r, p

tree = {}
for entry in subprocess.check_output(['git','ls-tree','-rz',base],cwd=W).split(b'\0'):
    if not entry: continue
    meta,path = entry.split(b'\t',1)
    mode,kind,sha = meta.decode().split()
    if kind == 'blob': tree[path.decode()] = sha
git_changed=[]
for p in rows:
    b=(W/p).read_bytes()
    sha=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    if tree.get(p) != sha: git_changed.append(p)
assert sorted(git_changed) == changed
snap = verify(d['source_snapshots'])
assert set(snap)=={'root','files'}
assert [r['path'] for r in snap['files']] == changed
for r in snap['files']:
    assert rows[r['path']] == r
    assert dict(bind(Path(snap['root'])/r['path']),path=r['path']) == r
    assert (W/r['path']).read_bytes() == (Path(snap['root'])/r['path']).read_bytes()
assert sorted(str(p.relative_to(snap['root'])) for p in Path(snap['root']).rglob('*') if p.is_file()) == changed

accepted = set(d['accepted_labels'])
attempts = {}
summary = re.compile(r'^test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;',re.M)
for a in d['attempts']:
    rec=verify(a['receipt']); text=Path(a['log']['path']).read_text()
    assert rec['command']==a['command'] and rec['exit']==a['exit']
    assert rec['elapsed_seconds']==a['elapsed_seconds']
    assert rec['sha256']==a['log']['sha256']
    assert Path(a['log']['path']).name == rec['log']
    ss=summary.findall(text)
    if ss:
        actual=dict(suites=len(ss),passed=sum(int(s[1]) for s in ss),failed=sum(int(s[2]) for s in ss),ignored=sum(int(s[3]) for s in ss))
        assert actual==a['tests']
    assert a['accepted']==(a['label'] in accepted)
    if a['accepted']: assert a['exit']==0
    attempts[a['label']]=a
all_commands={p.stem for p in (L/'validation').glob('*.json') if 'command' in load(p)}
assert set(attempts)==all_commands and len(attempts)==26

renames = {
 'script::parser::super_property_tests::super_property_parser_object_methods_and_deferred_class_syntax_stay_unsupported': 'script::parser::super_property_tests::super_property_parser_object_methods_are_admitted_and_class_deferrals_remain',
 'script::super_property_semantics_tests::super_property_deferred_object_literal_method_super': 'script::super_property_semantics_tests::super_property_accepted_object_literal_method_super',
 'script::super_property_semantics_tests::super_property_deferred_object_literal_accessor_arrow_super': 'script::super_property_semantics_tests::super_property_accepted_object_literal_accessor_arrow_super',
}
rosters=[]
new_roster=None
for label,total,prior in [('candidate-full-msrv-2',3485,3432),('candidate-full-host-vulkan-1',3849,3796)]:
    assert attempts[label]['tests']==dict(suites=56,passed=total,failed=0,ignored=0)
    txt=(L/'validation'/f'{label}.log').read_text()
    oldpath=K/'validation'/f'{label}.log'
    a=Counter(re.findall(r'^test (.+) \.\.\. ok$',oldpath.read_text(),re.M))
    b=Counter(re.findall(r'^test (.+) \.\.\. ok$',txt,re.M))
    assert sum(a.values())==prior and sum(b.values())==total
    for before,after in renames.items():
        assert a[before]==1 and a[after]==0 and b[before]==0 and b[after]==1
        del a[before]; a[after]+=1
    assert not a-b
    added=b-a
    assert sum(added.values())==53 and all(v==1 for v in added.values())
    if new_roster is not None: assert added==new_roster
    new_roster=added
    rosters.append(dict(label=label,prior_log=bind(oldpath),prior_passed=prior,passed=total,suites=56,added=sorted(added),renames=renames))
public=load(L/'public-controls-1/cases.json')
assert len(public)==41 and sum(len(x['modes']) for x in public)==82
public_ids={x['id'] for x in public}
actual_public={x.rsplit('::',1)[1].removeprefix('object_super_property_') for x in new_roster if '::object_super_property_' in x}
assert actual_public==public_ids
assert sum('::object_super_properties::tests::' in x for x in new_roster)==4
assert sum('::parser::super_property_tests::' in x for x in new_roster)==6
assert sum(not x.startswith('script::') for x in new_roster)==2

selection=verify(d['binary_selection'])
assert selection['source_inventory']==d['source_inventory']
binary_records={}
for kind,ref in selection['binaries'].items():
    s=verify(ref); nested(s)
    actual=bind(s['binary'])
    assert (actual['bytes'],actual['sha256'])==(s['bytes'],s['sha256'])
    assert s['source_inventory']==d['source_inventory']
    env=verify(s['environment']); build=verify(s['build'])
    assert Path(s['binary'])==Path(env['target_dir'])/'release/eris-js'
    assert s['toolchain']==env['toolchain']==('1.88.0' if kind=='ordinary' else '1.99.0')
    assert s['features']==([] if kind=='ordinary' else ['test262-host'])
    expected=['cargo','+'+s['toolchain'],'build','--locked','--offline']
    if kind=='host': expected+=['--features','test262-host']
    expected+=['--release','--bin','eris-js']
    assert build['command']==expected and build['exit']==0
    assert env['features']==([] if kind=='ordinary' else ['--features','test262-host'])
    assert s['toolchain'] in env['rustc']
    binary_records[kind]=dict(sidecar=ref,binary=actual,toolchain=s['toolchain'],features=s['features'])

profile=verify(d['profiles'][0]); other=verify(d['profiles'][1])
assert profile==other and Path(d['profiles'][0]['path']).read_bytes()==Path(d['profiles'][1]['path']).read_bytes()
nested(profile)
contract=verify(profile['contract']); nested(contract['predecessor']); nested(contract['predecessor_contract'])
assert profile['status']=='pass' and profile['baseline_writes'] is False
assert profile['source_inventory']==d['source_inventory']
assert contract['base']==base
for r in contract['immutable_published_inputs']:
    assert dict(bind(W/r['path']),path=r['path'])==r
    assert r==rows[r['path']]
for root in contract['exact_tree_roots']:
    expected={r['path'] for r in contract['immutable_published_inputs'] if r['path'].startswith(root+'/')}
    actual={str(p.relative_to(W)) for p in (W/root).rglob('*') if p.is_file()}
    assert actual==expected, root
profiles=[]; counts=Counter(); edges=0; cross_mode=0; observed_policy=Counter()
assert len(profile['profiles'])==8
for r,c in zip(profile['profiles'],contract['profiles']):
    assert r['profile']==c['profile'] and r['name']==c['name']
    before=verify(r['before']); now=verify(r['report'])
    assert r['before']==c['reference_report']
    assert set(now)==set(before)
    diffs=[k for k in now if now[k]!=before[k]]
    assert set(diffs)<= {'seconds','binary','binary_sha256'}
    assert now['cases']==before['cases'] and now['harness_preflight']==before['harness_preflight']
    assert len(now['cases'])==r['cases']==c['cases']
    assert len(now['harness_preflight'])==r['controls']==c['controls']
    assert len({v['id'] for v in now['cases']})==len(now['cases'])
    status=Counter(v['status'] for v in now['cases'])
    assert dict(status)==now['counts']==r['counts']
    counts.update(status)
    assert now['runner_policy']==c['policy'] and now['runner_policy_sha256']==c['policy_sha256']
    assert hashlib.sha256(json.dumps(now['runner_policy'],sort_keys=True,separators=(',',':')).encode()).hexdigest()==c['policy_sha256']
    assert now['corpus_manifest_sha256']==c['corpus_manifest_sha256']
    assert now['harness_preflight_passed'] is True
    assert now['binary']==binary_records[c['binary_kind']]['binary']['path']
    assert now['binary_sha256']==binary_records[c['binary_kind']]['binary']['sha256']
    for case in now['cases']:
        obs=case.get('observation',{})
        assert case['status'] in {'passed','failed','unsupported'}
        assert obs.get('status') not in {'resource','timeout','crash','protocol-error','runner-error'}
        if 'completion' in obs:
            policy=contract['case_completion_policies'][r['profile']][case['id']]
            assert obs['completion']['policy']==policy
            observed_policy[policy]+=1
        if case['status']=='passed': assert obs['status']=='complete'
    controls=now['harness_preflight']
    lookup={(v['name'],v['result']['mode']):v for v in controls}
    assert len(lookup)==len(controls)
    ordered={k:i for i,k in enumerate(lookup)}
    for v in controls:
        assert v['verified'] is True
        key=(v['name'],v['result']['mode'])
        for pre in v['prerequisites']:
            target=(pre['name'],pre['mode']); t=lookup[target]
            assert ordered[target]<ordered[key]
            assert pre['case_sha256']==t['result']['case_sha256'] and pre['source_sha256']==t['result']['source_sha256']
            if 'verified' in pre: assert pre['verified'] is True
            if 'expected' in pre: assert pre['expected']==t['expected']
            edges+=1; cross_mode+=target[1]!=key[1]
    command=verify(r['receipt'])
    assert '--baseline' not in command['command'] and '--record-baseline' not in command['command']
    assert command['exit']==(0 if status=={'passed':len(now['cases'])} else 1)==r['observed_exit']
    for k in ['errors','case_record_changes','control_record_changes','prior_pass_regressions','newly_passed','nonpass_status_changes','raw_only_changes','infrastructure_cases']: assert r[k]==[]
    profiles.append(dict(name=r['name'],profile=r['profile'],cases=r['cases'],controls=r['controls'],counts=dict(status),observed_exit=command['exit'],before=r['before'],report=r['report'],only_differing_top_fields=diffs,policy_sha256=c['policy_sha256']))
assert dict(counts)==d['profile_counts']==profile['counts']=={'passed':1258,'failed':64,'unsupported':8}
assert sum(x['cases'] for x in profiles)==1330 and sum(x['controls'] for x in profiles)==724
assert all(v==0 for v in profile['transition_counts'].values()) and profile['transition_counts']==d['profile_transition_counts']
for ref in d['source_reviews']:
    review=verify(ref); assert review['status']=='clear'; nested(review)

result=dict(status='checks-pass',ledger=bind(ledger_path),assembler=bind(L/'root/assemble-validation.py'),source_inventory=d['source_inventory'],source_snapshots=d['source_snapshots'],source_scope=inv['scope'],source_counts=dict(parent=len(old),candidate=len(rows),modified_existing=7,added=8,unchanged_parent=15282),changed_source_paths=changed,selected_git_blob_comparison=True,attempt_count=len(attempts),accepted_labels=sorted(accepted),full_rosters=rosters,new_coverage=d['new_coverage'],binaries=binary_records,profile_replay=d['profiles'],profiles=profiles,profile_counts=dict(counts),control_edges=edges,cross_mode_edges=cross_mode,observed_case_completion_policies=dict(observed_policy),immutable_profile_input_count=len(contract['immutable_published_inputs']),exact_tree_roots=contract['exact_tree_roots'],verified_bindings=sorted(verified.values(),key=lambda r:r['path']),project_execution=False,project_imports=False,live_edits=False)
with (O/'checks.json').open('x') as f: json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({k:v for k,v in result.items() if k in ['status','source_counts','attempt_count','profile_counts','control_edges','cross_mode_edges']}))
