from pathlib import Path
import hashlib
import json
import difflib

root = Path(__file__).resolve().parents[1]
w = root / 'worktree'
h = root / 'historical-public-migration-1'
h.mkdir()
path = 'src/script/super_property_semantics_tests.rs'
before = (w / path).read_text()
after = before
rows = []
for suffix, readback in [
    ('method', "[typeof object.m,object.m()===undefined].join(':')"),
    ('accessor_arrow', "var arrow=object.x;[typeof arrow,arrow()===undefined].join(':')"),
]:
    name = 'super_property_deferred_object_literal_' + suffix + '_super'
    start = after.index('#[test]\nfn ' + name + '() {')
    end = after.index('\n#[test]', start + 1)
    old = after[start:end]
    new = old.replace('deferred_object_literal_', 'accepted_object_literal_').replace('    deferred(\n', '    observe(\n')
    needle = '"####,\n    );'
    assert new.count(needle) == 1
    new = new.replace(needle, '"####,\n        r####"' + readback + '"####,\n        "function:true",\n        "function:true",\n    );')
    after = after[:start] + new + after[end:]
    rows.append({'old_name':name, 'new_name':name.replace('deferred_', 'accepted_'), 'source_literal':'byte-exact preserved', 'readback':readback, 'expected_both_modes':'function:true', 'reason':'Object-literal method/accessor SuperProperty is selected; inherited Object.prototype.x is absent, so invoking the preserved method/escaped arrow yields undefined.'})
for directory, value in [('before',before), ('raw',after)]:
    target = h / directory / path
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_text(value)
for direction,old,new in [('forward',before,after),('inverse',after,before)]:
    (h / (direction + '.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='a/'+path,tofile='b/'+path)))
(h/'source-ready.json').write_text(json.dumps({'status':'held explicit historical public expectation migration; no execution or import','base':'db880b867daa2ec7bfc82cb2041aec935d5b8189','paths':[{'path':path,'before':hashlib.sha256(before.encode()).hexdigest(),'after':hashlib.sha256(after.encode()).hexdigest(),'bytes':len(after.encode())}],'migrations':rows,'all_other_test_bodies':'byte-exact'},indent=2)+'\n')
print((h/'forward.patch').read_text())
