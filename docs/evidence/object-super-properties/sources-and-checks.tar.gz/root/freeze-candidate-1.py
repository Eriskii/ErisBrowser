from pathlib import Path
import hashlib
import difflib
import json

l=Path(__file__).resolve().parents[1];w=l/'worktree'
def sha(b):return hashlib.sha256(b).hexdigest()
parent=json.loads((l/'source-parent.json').read_text())
expected={}
for row in json.loads((l/'root/candidate-import-1.json').read_text())['paths']:
    expected[row['path']]=l/'candidate-import-1/after'/row['path']
for hold in ['browser-controls-1','public-adapter-1']:
    receipt=json.loads((l/hold/'source-ready.json').read_text())
    if 'paths' in receipt:
        for row in receipt['paths']:expected[row['path']]=l/hold/'raw'/row['path']
    else:
        for row in receipt['files']:expected[row['relative_path']]=Path(row['raw']['path'])
rows={row['path']:row for row in parent['files']}
formatted=[];snapshots=[]
for path,prior in expected.items():
    before=prior.read_bytes();after=(w/path).read_bytes()
    snapshot=l/'candidate-source-1'/path;snapshot.parent.mkdir(parents=True,exist_ok=True);snapshot.write_bytes(after)
    snapshots.append({'path':path,'bytes':len(after),'sha256':sha(after)})
    if before!=after:
        diff=''.join(difflib.unified_diff(before.decode().splitlines(True),after.decode().splitlines(True),fromfile='held/'+path,tofile='formatted/'+path))
        p=l/'format-1/diffs'/(path+'.patch');p.parent.mkdir(parents=True,exist_ok=True);p.write_text(diff)
        formatted.append({'path':path,'before':sha(before),'after':sha(after),'diff':str(p)})
for path in sorted(set(rows)|set(expected)):
    b=(w/path).read_bytes()
    if path not in expected:
        assert len(b)==rows[path]['bytes'] and sha(b)==rows[path]['sha256'],path
    rows[path]={'path':path,'bytes':len(b),'sha256':sha(b)}
inventory={'base':parent['base'],'scope':parent['scope'],'files':[rows[p] for p in sorted(rows)]}
with (l/'source-candidate-1.json').open('x') as f:json.dump(inventory,f,indent=2);f.write('\n')
record={'status':'snapshot of imported source after recorded cargo fmt; source unchanged during first candidate execution','source_inventory':{'path':str(l/'source-candidate-1.json'),'sha256':sha((l/'source-candidate-1.json').read_bytes()),'inputs':len(rows)},'changed_paths':snapshots,'format_only_changes':formatted}
with (l/'root/candidate-snapshots-1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print('Frozen',len(rows),'inputs;',len(snapshots),'changed paths;',len(formatted),'formatted paths')
