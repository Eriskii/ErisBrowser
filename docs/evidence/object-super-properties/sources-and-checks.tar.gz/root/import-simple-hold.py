from pathlib import Path
import hashlib
import json
import sys

root=Path(__file__).resolve().parents[1]
name,label=sys.argv[1:]
hold=root/name
receipt=hold/'source-ready.json'
data=json.loads(receipt.read_text())
rows=data['paths']
for row in rows:
    dest=root/'worktree'/row['path']
    actual=hashlib.sha256(dest.read_bytes()).hexdigest() if dest.exists() else None
    assert actual==row['before'],(row['path'],actual,row['before'])
    raw=hold/'raw'/row['path']
    assert hashlib.sha256(raw.read_bytes()).hexdigest()==row['after'],row['path']
for row in rows:
    dest=root/'worktree'/row['path']
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes((hold/'raw'/row['path']).read_bytes())
record={'source_ready':str(receipt),'source_ready_sha256':hashlib.sha256(receipt.read_bytes()).hexdigest(),'paths':rows}
with (root/'root'/(label+'.json')).open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print('Imported',name,len(rows),'paths')
