from pathlib import Path
import hashlib
import json

L = Path(__file__).resolve().parents[1]

def binding(relative):
    data = (L / relative).read_bytes()
    return dict(path=relative, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

inputs = dict(
    source_parent='source-parent.json',
    source_inventory='source-candidate-3.json',
    source_snapshots='root/source-snapshots-final.json',
    final_validation='root/final-validation.json',
    validation_review='validation-review-1/review.json',
    documentation_hold='documentation-4/source-ready.json',
    documentation_review='documentation-review-1/review.json',
)
required = [
    'runtime-producer-1/source-ready.json', 'parser-producer-1/source-ready.json',
    'public-controls-1/source-ready.json', 'public-controls-1/literal-ready.json',
    'public-base-refresh-1/source-ready.json', 'public-adapter-1/source-ready.json',
    'capture-controls-1/source-ready.json', 'browser-controls-1/source-ready.json',
    'historical-public-migration-1/source-ready.json', 'historical-method-migration-1/source-ready.json',
    'optional-refusal-producer-1/source-ready.json',
    'runtime-browser-review-1/review.json', 'parser-review-1/review.json',
    'capture-review-1/review.json', 'public-adapter-review-1/review.json',
    'historical-public-review-1/review.json', 'optional-refusal-review-1/review.json',
    'candidate-source-review-1/review.json', 'candidate-source-review-1/candidate3-addendum.json',
    'candidate-source-review-1/checker-correction-1.json',
    'profile-replay-1/source-ready.json', 'profile-replay-review-1/review.json',
    'root/profile-selection-1.json', 'root/profile-replay-1.json',
    'root/profile-replay-1-recheck.json', 'root/binary-ordinary-1.json', 'root/binary-host-1.json',
    'root/toolchain-restoration-1.json',
    'evidence-tools-1/source-ready.json', 'evidence-tools-review-1/review.json',
]
required.extend('validation/' + p.name for p in sorted((L / 'validation').glob('*.json')))
raw = L / 'documentation-4/raw'
documents = sorted(p.relative_to(raw).as_posix() for p in raw.rglob('*') if p.is_file())
assert documents == ['README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/class-super-properties.md',
                     'docs/classes.md', 'docs/object-super-properties.md']
record = dict(format=1, checkpoint='object-super-properties',
              inputs={name: binding(relative) for name, relative in inputs.items()},
              documents=documents, source_snapshot_root='candidate-source-3',
              required_artifacts=[binding(relative) for relative in sorted(set(required))])
with (L / 'root/evidence-selection-1.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
print('Selected', len(record['required_artifacts']), 'required artifacts and', len(documents), 'documents.')
