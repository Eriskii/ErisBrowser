from pathlib import Path
import difflib
import hashlib
import json

root = Path(__file__).resolve().parents[1]
w = root / 'worktree'
h = root / 'browser-controls-1'
h.mkdir()
fixture = (w / 'tests/fixtures/class-super-properties.html').read_text()
start = fixture.index('class Marker {')
end = fixture.index("queueMicrotask(function(){trace+='Q';});")
fixture = fixture[:start] + '''var marker={
  get left(){return this.offset;},
  set left(value){this.offset=value;},
  paint(){this.node.style.left=this.left+'px';}
};
var leftKey='left';
var swatch={
  __proto__:marker,
  node:red,offset:12,
  get [leftKey](){trace+='G';return super.left;},
  set left(value){trace+='W';super.left=value;},
  paint(){trace+='P';var paint=()=>super.paint();paint();}
};
class Deferred extends Promise {}
''' + fixture[end:]
fixture = fixture.replace("if(value!==swatch || !(value instanceof Marker) || !(value instanceof Swatch)) throw 'class identity';", "if(value!==swatch || Object.getPrototypeOf(value)!==marker) throw 'object home identity';")
oracle = (w / 'tests/support/class_super_properties.rs').read_text()
oracle = oracle.replace('Literal class, Promise and rendering expectations', 'Literal object-method, Promise and rendering expectations').replace('class-super-properties.html','object-super-properties.html').replace('SBDTQRPG','STQRPG')
direct = (w / 'tests/class_super_properties.rs').read_text()
direct = direct.replace('Classes retain inherited accessors', 'Object methods retain inherited accessors').replace('class_super_properties.rs','object_super_properties.rs').replace('fn super_properties_', 'fn object_super_properties_').replace('https://super-properties.invalid/', 'https://object-super-properties.invalid/')
worker = (w / 'tests/worker/class_super_properties.rs').read_text()
worker = worker.replace('Class construction, native Promise reactions', 'Object method inheritance, native Promise reactions').replace('class_super_properties.rs','object_super_properties.rs').replace('fn confined_super_properties_', 'fn confined_object_super_properties_').replace('661','671').replace('662','672')
register = (w / 'tests/worker.rs').read_text() + '\n#[path = "worker/object_super_properties.rs"]\nmod object_super_properties;\n'
paths = {'tests/fixtures/object-super-properties.html': fixture, 'tests/support/object_super_properties.rs': oracle, 'tests/object_super_properties.rs': direct, 'tests/worker/object_super_properties.rs': worker, 'tests/worker.rs': register}
rows = []
for path, text in paths.items():
    source = w / path
    before = source.read_text() if source.exists() else ''
    for directory, value in [('before', before), ('raw', text)]:
        target = h / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(value)
    for direction, old, new in [('forward', before, text), ('inverse', text, before)]:
        target = h / 'diffs' / (path + '.' + direction + '.patch')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/' + path, tofile='b/' + path)))
    rows.append({'path': path, 'before': hashlib.sha256(before.encode()).hexdigest() if source.exists() else None, 'after': hashlib.sha256(text.encode()).hexdigest(), 'bytes': len(text.encode())})
receipt = {
    'status': 'held browser literals and adapters; no project execution or live import',
    'base': 'db880b867daa2ec7bfc82cb2041aec935d5b8189',
    'paths': rows,
    'groups': 2,
    'expected': {'initial': 'STQRPG', 'clicked': 'STQRPGCTRWPGL', 'disabled_title': 'base', 'red_left': {'disabled':2,'initial':12,'clicked':16}, 'blue_left':20, 'rectangles':'4x4 at y=2 on white; widths 320 and 300, height 240'},
    'derivation': [
        'Setup appends S; object creation and computed leftKey definition add no trace.',
        'Promise.try synchronously appends T; queued Q runs before reaction R.',
        'Reaction invokes swatch.paint: P, lexical arrow super.paint invokes marker.paint on swatch; this.left invokes swatch getter G then marker getter returns offset12.',
        'First click listener appends C,T; checkpoint reaction R assigns swatch.left: W then inherited setter stores offset16; paint P,G. Next listener appends L and sets title.',
        'No enabled pending tasks remain; disabled script leaves literal CSS red at2 and title base.'
    ],
    'qualification': 'Software raster and optional CPU native-plan comparison only; no GPU execution claim.'
}
(h / 'source-ready.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
