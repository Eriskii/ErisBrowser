from pathlib import Path
import difflib
import hashlib
import json

root = Path(__file__).resolve().parents[1]
worktree = root / 'worktree'
hold = root / 'runtime-producer-1'
hold.mkdir()
helper = '''//! Immutable home identity for ordinary object-literal methods and accessors.
use super::*;

fn invalid() -> ScriptError {
    ScriptError::resource("invalid object method home state")
}

impl Runtime {
    pub(super) fn object_attach_home(&mut self, method: &Value, home: &Value) -> Result<()> {
        // Admit the bounded checks and one scalar publication before any mutation.
        // function_value already paid for the home slot; this retains no new storage.
        self.work(8)?;
        let (Value::Function(id), Value::Object(home)) = (method, home) else {
            return Err(invalid());
        };
        if *home >= self.objects.len() {
            return Err(invalid());
        }
        let function = self.functions.get_mut(*id).ok_or_else(invalid)?;
        if function.bound.is_some()
            || function.home_object.is_some()
            || function.code.arrow
            || function.code.constructable
            || function.code.class_kind.is_some()
        {
            return Err(invalid());
        }
        // Object methods preserve their source's strict or sloppy this semantics.
        function.home_object = Some(*home);
        Ok(())
    }
}
'''
paths = {}
path = 'src/script.rs'
before = (worktree / path).read_text()
needle = 'mod object_is;\n'
assert before.count(needle) == 1
paths[path] = before.replace(needle, needle + 'mod object_super_properties;\n')
path = 'src/script/machine.rs'
before = (worktree / path).read_text()
needle = '                let function = runtime.function_value(&code::FunctionRef::new(&unit, *id), env)?;\n'
assert before.count(needle) == 2
paths[path] = before.replace(needle, needle + '                runtime.object_attach_home(&function, &object)?;\n')
paths['src/script/object_super_properties.rs'] = helper
rows = []
for path, after in paths.items():
    source = worktree / path
    before = source.read_text() if source.exists() else ''
    for directory, value in [('before', before), ('raw', after)]:
        target = hold / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(value)
    for direction, old, new in [('forward', before, after), ('inverse', after, before)]:
        target = hold / 'diffs' / (path + '.' + direction + '.patch')
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(''.join(difflib.unified_diff(old.splitlines(True), new.splitlines(True), fromfile='a/' + path, tofile='b/' + path)))
    rows.append({'path': path, 'before': hashlib.sha256(before.encode()).hexdigest() if source.exists() else None, 'after': hashlib.sha256(after.encode()).hexdigest(), 'bytes': len(after.encode())})
receipt = {
    'status': 'held runtime proposal; no project execution or live import',
    'base': 'db880b867daa2ec7bfc82cb2041aec935d5b8189',
    'paths': rows,
    'contract': {'work': 8, 'heap': 0, 'strict_and_sloppy': True, 'mutation': 'one home_object scalar after all eligibility checks'},
    'unchanged': ['class_attach_home and all capture/reference helpers', 'runtime representation and limits', 'ordinary function-valued properties', 'computed definition-key ordering'],
    'spec': 'https://tc39.es/ecma262/multipage/ecmascript-language-functions-and-classes.html#sec-method-definitions-runtime-semantics-definemethod',
    'test_registration': 'separate root integration of cfg(test) child when independent held controls arrive',
}
(hold / 'source-ready.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
