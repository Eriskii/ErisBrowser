from pathlib import Path
import hashlib
import json

l=Path(__file__).resolve().parents[1]
w=l/'worktree'
def sha(data):return hashlib.sha256(data).hexdigest()
def read(name):return json.loads((l/name).read_text())
def checked(path,expected):
    data=Path(path).read_bytes();assert sha(data)==expected,(str(path),sha(data),expected);return data
reviews=['runtime-browser-review-1','parser-review-1','historical-public-review-1','public-adapter-review-1','capture-review-1']
for name in reviews:assert read(name+'/review.json')['status']=='clear',name
planned={}
runtime=read('runtime-producer-1/source-ready.json')
public=read('public-adapter-1/source-ready.json')
capture=read('capture-controls-1/source-ready.json')
for row in runtime['paths']:
    path=row['path'];data=checked(l/'runtime-producer-1/raw'/path,row['after'])
    current=w/path
    if path=='src/script.rs':
        r=public['registration']
        assert row['before']==r['before']['sha256']
        checked(current,r['raw']['sha256'])
        data+=checked(r['snippet']['path'],r['snippet']['sha256'])
    elif current.exists():checked(current,row['before'])
    else:assert row['before'] is None
    planned[path]=data
for row in read('parser-producer-1/source-ready.json')['payloads']:
    checked(w/row['path'],row['before']['sha256'])
    planned[row['path']]=checked(row['after']['path'],row['after']['sha256'])
for row in read('historical-public-migration-1/source-ready.json')['paths']:
    checked(w/row['path'],row['before'])
    planned[row['path']]=checked(l/'historical-public-migration-1/raw'/row['path'],row['after'])
for row in capture['files']:
    assert not (w/row['relative_path']).exists()
    planned[row['relative_path']]=checked(row['raw']['path'],row['raw']['sha256'])
planned['src/script/object_super_properties.rs']+=b'\n#[cfg(test)]\nmod tests;\n'
rows=[]
for path,data in planned.items():
    target=w/path
    before=target.read_bytes() if target.exists() else None
    for stage,value in [('before',before),('after',data)]:
        if value is None:continue
        p=l/'candidate-import-1'/stage/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(value)
    rows.append({'path':path,'before':sha(before) if before is not None else None,'after':sha(data),'bytes':len(data)})
for path,data in planned.items():
    p=w/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
record={'status':'imported reviewed candidate; no execution yet','base':runtime['base'],'paths':rows,'composition':'Runtime registration plus exact public adapter append; helper plus cfg(test) child registration. Other selected raw payloads exact. Browser/public test overlays retained.', 'reviews':[{'path':name+'/review.json','sha256':sha((l/name/'review.json').read_bytes())} for name in reviews]}
with (l/'root/candidate-import-1.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
