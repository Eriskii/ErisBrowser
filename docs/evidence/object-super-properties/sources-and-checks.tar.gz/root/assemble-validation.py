from pathlib import Path
import hashlib
import json
import re
import subprocess

L = Path(__file__).resolve().parents[1]
W = L / 'worktree'
def load(path): return json.loads(path.read_bytes())
def bound(path):
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())

inventory_path = L / 'source-candidate-3.json'
inventory = load(inventory_path)
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W).decode().strip() == inventory['base']
for row in inventory['files']:
    assert dict(bound(W / row['path']), path=row['path']) == row
snapshots_path = L / 'root/source-snapshots-final.json'
snapshots = load(snapshots_path)
assert len(snapshots['files']) == 15
for row in snapshots['files']:
    assert dict(bound(Path(snapshots['root']) / row['path']), path=row['path']) == row
    assert (W / row['path']).read_bytes() == (Path(snapshots['root']) / row['path']).read_bytes()

accepted = [
    'candidate-full-msrv-2', 'candidate-full-host-vulkan-1',
    'candidate-clippy-msrv-3', 'candidate-clippy-host-vulkan-1',
    'fmt-check-final-1', 'candidate-release-ordinary-1', 'candidate-release-host-1',
]
attempts = []
for path in sorted((L / 'validation').glob('*.json')):
    row = load(path)
    if 'command' not in row:
        continue
    log = path.parent / row['log']
    assert bound(log)['sha256'] == row['sha256']
    suites = re.findall(r'test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored;', log.read_text())
    item = dict(label=path.stem, receipt=bound(path), log=bound(log), command=row['command'],
                exit=row['exit'], elapsed_seconds=row['elapsed_seconds'], accepted=path.stem in accepted)
    if suites:
        item['tests'] = dict(suites=len(suites), passed=sum(int(r[1]) for r in suites),
                             failed=sum(int(r[2]) for r in suites), ignored=sum(int(r[3]) for r in suites))
    environment = path.with_name(path.stem + '-environment.json')
    if environment.exists(): item['environment'] = bound(environment)
    attempts.append(item)
by_name = {row['label']: row for row in attempts}
assert all(by_name[label]['exit'] == 0 for label in accepted)
for label, count in [('candidate-full-msrv-2', 3485), ('candidate-full-host-vulkan-1', 3849)]:
    assert by_name[label]['tests'] == dict(suites=56, passed=count, failed=0, ignored=0)
    text = Path(by_name[label]['log']['path']).read_text()
    assert 'test object_super_properties_update_dom_and_pixels_through_native_promise_reactions ... ok' in text
    assert 'test object_super_properties::confined_object_super_properties_update_dom_and_pixels_through_native_promise_reactions ... ok' in text

profile_paths = [L / 'root/profile-replay-1.json', L / 'root/profile-replay-1-recheck.json']
for path in profile_paths:
    profile = load(path)
    assert profile['status'] == 'pass' and profile['baseline_writes'] is False
    assert profile['source_inventory'] == bound(inventory_path)
    assert profile['expected_cases'] == 1330 and profile['expected_controls'] == 724
    assert len(profile['profiles']) == 8 and all(not row['errors'] for row in profile['profiles'])
    for row in profile['profiles']:
        for field in ['report', 'receipt', 'log']: assert bound(Path(row[field]['path'])) == row[field]
    assert profile['transition_counts']['prior_pass_regressions'] == 0
    assert profile['transition_counts']['control_record_changes'] == 0
    assert profile['transition_counts']['infrastructure_cases'] == 0
assert load(profile_paths[0])['profiles'] == load(profile_paths[1])['profiles']
selection_path = L / 'root/profile-selection-1.json'
selection = load(selection_path)
assert selection['source_inventory'] == bound(inventory_path)
for item in selection['binaries'].values():
    assert bound(Path(item['path'])) == item
    sidecar = load(Path(item['path']))
    binary = bound(Path(sidecar['binary']))
    assert (binary['bytes'], binary['sha256']) == (sidecar['bytes'], sidecar['sha256'])
    for name in ['source_inventory', 'build', 'environment']: assert bound(Path(sidecar[name]['path'])) == sidecar[name]

reviews = [
    'runtime-browser-review-1/review.json', 'parser-review-1/review.json',
    'capture-review-1/review.json', 'public-adapter-review-1/review.json',
    'historical-public-review-1/review.json', 'optional-refusal-review-1/review.json',
    'candidate-source-review-1/review.json', 'candidate-source-review-1/candidate3-addendum.json',
    'profile-replay-review-1/review.json',
]
assert all(load(L / path)['status'] == 'clear' for path in reviews)
profile = load(profile_paths[0])
record = dict(
    status='pass', checkpoint='object-super-properties', base=inventory['base'],
    source_inventory=bound(inventory_path), source_snapshots=bound(snapshots_path),
    selected_inputs=len(inventory['files']), changed_source_paths=15,
    accepted_labels=accepted, attempts=attempts,
    source_reviews=[bound(L / name) for name in reviews],
    profiles=[bound(path) for path in profile_paths], binary_selection=bound(selection_path),
    profile_counts=profile['counts'], profile_transition_counts=profile['transition_counts'],
    new_coverage=dict(public_groups=41, public_modes=82, exact_js_fields=80,
                      parser_groups=6, capture_groups=4, capture_measured_calls=58, browser_groups=2),
    retained_failures=[
        dict(label='parent-public-1', reason='Frozen new public controls before implementation: 10 passed, 31 failed.'),
        dict(label='parent-browser-1', reason='New fixture retained baseline pixels because published parent lacks object-method SuperProperty support.'),
        dict(label='candidate-object-msrv-1', reason='47 passed, 1 failed: valid optional-chain prefix was incorrectly classified as SyntaxError. Bounded parser refusal correction retained the independent oracle.'),
        dict(label='candidate-full-msrv-1', reason='3138 passed, 1 failed: an older aggregate test still classified the now-supported object method source as Unsupported. Exact literal moved to accepted parse assertion; production unchanged.'),
        dict(label='candidate-clippy-msrv-2', reason='Expired temporary Cargo registry metadata prevented offline dependency resolution before compilation; locked cache restored, later Clippy passed.'),
    ],
    environment_recovery=bound(L / 'root/toolchain-restoration-1.json'),
    source_checker_correction=bound(L / 'candidate-source-review-1/checker-correction-1.json'),
    unchanged='Runtime representations and limits, published runner/importer/protocol, feature policies, corpora and baseline files.',
    qualification='Selected ordinary object-method/accessor SuperProperty support only. Optional chaining remains unsupported at its recognized prefix; its entire tail is not parsed or validated. Full-suite native-plan assertions run on CPU; no new hardware GPU, whole-browser compatibility, security certification or Chromium performance claim.',
)
with (L / 'root/final-validation.json').open('x') as out:
    json.dump(record, out, indent=2); out.write('\n')
print(json.dumps(bound(L / 'root/final-validation.json')))
