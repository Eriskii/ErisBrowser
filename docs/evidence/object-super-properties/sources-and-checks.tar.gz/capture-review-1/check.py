"""Independent inert source/manifest/count checks; no project imports/execution."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

L = Path('/tmp/eris-object-super-properties-plan-1')
H = L / 'capture-controls-1'
O = L / 'capture-review-1'
W = L / 'worktree'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'


def bind(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def verify(row):
    actual = bind(row['path'])
    assert actual['bytes'] == row['bytes'] and actual['sha256'] == row['sha256'], row['path']


seal = json.loads((H / 'source-ready.json').read_text())
assert seal['base'] == BASE
for key in ['selection', 'contract', 'published_source', 'registration']:
    verify(seal[key])
for row in seal['files']:
    verify(row['raw'])
    verify(row['diff'])
assert len(seal['files']) == 1
row = seal['files'][0]
path = row['relative_path']
raw = Path(row['raw']['path']).read_text()
tracked = subprocess.check_output(['git', '-C', str(W), 'ls-tree', '-r', '--name-only', BASE]).decode().splitlines()
assert path not in tracked and row['before'] is None
expected_diff = ''.join(difflib.unified_diff([], raw.splitlines(True), fromfile='/dev/null', tofile='b/' + path))
assert expected_diff == Path(row['diff']['path']).read_text()
registration = json.loads((H / 'registration.json').read_text())
verify(registration['fragment'])
assert Path(registration['fragment']['path']).read_text() == '#[cfg(test)]\nmod tests;\n'
assert registration['target'] == 'src/script/object_super_properties.rs'

source = json.loads((H / 'published-source.json').read_text())
assert source['base'] == BASE
for row in source['files']:
    data = subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + row['path']])
    blob = subprocess.check_output(['git', '-C', str(W), 'rev-parse', BASE + ':' + row['path']]).decode().strip()
    assert len(data) == row['bytes'] and hashlib.sha256(data).hexdigest() == row['sha256']
    assert blob == row['git_blob']

groups = re.findall(r'#\[test\]\s*fn (\w+)\(', raw)
assert groups == seal['names'] and len(groups) == seal['groups'] == 4
contract = json.loads((H / 'contract.json').read_text())
assert groups == contract['names']
assert raw.count('runtime.object_attach_home(method, home)') == 1
assert raw.count('let result = runtime.object_attach_home(method, home);') == 1
assert 'for fault in 0..13 {' in raw and 'for fault in 0..8 {' in raw
assert raw.count('for work in [7, 8] {') == 4
assert raw.count('for choose_other in [false, true] {') == 2
assert raw.count('for strict in [false, true] {') == 1
counts = [2 * 2 * 2, 13 * 2, 8 * 2, 2 * 2 * 2]
assert counts == [row['calls'] for row in contract['rows']]
assert sum(counts) == contract['measured_calls'] == seal['measured_calls'] == 58
measure = raw.split('fn measure(', 1)[1].split('#[test]', 1)[0]
assert measure.index('runtime.steps = work;') < measure.index('let mut expected = snapshot(runtime);')
assert measure.index('runtime.allocated = MAX_HEAP;') < measure.index('let mut expected = snapshot(runtime);')
assert measure.index('let mut expected = snapshot(runtime);') < measure.index('runtime.object_attach_home(method, home)')
assert measure.count('expected.homes[function] = Some(home);') == 1
assert all(s in measure for s in ['assert_eq!(runtime.steps, 0);', 'assert_eq!(snapshot(runtime), expected);',
    'assert_eq!(runtime.allocated, MAX_HEAP);', 'assert_eq!(runtime.microtasks.queue.len(), 1);',
    'assert!(!runtime.microtasks_suspended());'])
assert 'method_code(strict, false, false, Some(kind))' in raw
assert all('code::ClassKind::' + k in raw for k in ['ExplicitBase', 'ExplicitDerived', 'DefaultBase', 'DefaultDerived'])
assert 'runtime.functions[function].home_object = Some(usize::MAX)' in raw
assert raw.count('object_attach_home') == 1

checks = {
    'status': 'source-only checks passed', 'base': BASE,
    'seal': bind(H / 'source-ready.json'), 'payload': bind(H / 'raw' / path),
    'published_source': bind(H / 'published-source.json'),
    'source_bindings_verified': len(source['files']),
    'new_target_absent_at_base': True, 'exact_additive_diff': True,
    'registration': bind(H / 'registration.json'),
    'groups': groups, 'calls_by_group': counts, 'measured_calls': sum(counts),
    'calls_by_result': {'work7_admission_refusal': 27, 'work8_invalid_state_refusal': 23, 'work8_success': 8},
    'counts_are_static_loop_derivations_not_observations': True,
    'measured_call_sites': 1,
    'setup_and_faults_precede_cut': True,
    'allocation_cut_at_maximum': True,
    'snapshot_expected_change': 'Only expected.homes[function] may change to Some(home) on success; no field changes allowed on refusal. steps is separately checked at zero.',
    'class_kind_faults_isolated_with_nonconstructable_nonarrow_code': True,
    'same_and_different_home_rejections': True,
    'no_project_execution': True,
}
(O / 'checks.json').write_text(json.dumps(checks, indent=2) + '\n')
print(json.dumps(bind(O / 'checks.json'), indent=2))
