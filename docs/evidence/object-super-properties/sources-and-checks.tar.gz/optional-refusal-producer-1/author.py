"""Build and check an external classification-only patch using stdlib, not project code."""
import difflib
import hashlib
import json
from pathlib import Path
import re
import subprocess

L = Path('/tmp/eris-object-super-properties-plan-1')
H = L / 'optional-refusal-producer-1'
W = L / 'worktree'
BASE = 'db880b867daa2ec7bfc82cb2041aec935d5b8189'
P = 'src/script/parser/driver/expressions.rs'
T = 'src/script/parser/super_property_tests.rs'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': digest(data)}


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2) + '\n')


def diff(before, after, path):
    return ''.join(difflib.unified_diff(before.splitlines(True), after.splitlines(True),
                                        fromfile='a/' + path, tofile='b/' + path))


inventory = json.loads((L / 'source-candidate-1.json').read_text())
assert inventory['base'] == BASE
rows = {row['path']: row for row in inventory['files']}
before = {}
for path in [P, T]:
    data = (W / path).read_bytes()
    assert len(data) == rows[path]['bytes'] and digest(data) == rows[path]['sha256']
    frozen = L / 'candidate-source-1' / path
    if frozen.exists():
        assert frozen.read_bytes() == data
    before[path] = data.decode()
assert before[P].encode() == subprocess.check_output(['git', '-C', str(W), 'show', BASE + ':' + P])
raw = dict(before)
edits = []


def replace(path, old, new, reason):
    assert raw[path].count(old) == 1
    raw[path] = raw[path].replace(old, new, 1)
    edits.append({'path': path, 'old': old, 'new': new, 'count': 1, 'reason': reason})


head = "fn postfix(p: &mut Parser<'_>, mut state: Postfix) -> Result<Transition> {"
helper = '''// The unchanged lexer emits two symbols for ?. and one Number for .3.
// Require adjacent source offsets so ? . and ?/* comment */. stay conditional.
// This recognizes only the unsupported boundary, without consuming its tail.
fn optional_chain_start(p: &Parser<'_>) -> bool {
    p.is("?")
        && p.token_is(p.pos + 1, ".")
        && p.tokens[p.pos + 1].offset == p.tokens[p.pos].offset + 1
}
'''
replace(P, head, helper + head, 'Bounded adjacent-token recognition; no lexer, token, AST or frame representation change.')
replace(P,
        head + '\n    loop {\n        state.chain += 1;\n        if p.eat(".") {',
        head + '\n    loop {\n        state.chain += 1;\n'
        '        if optional_chain_start(p) {\n'
        '            return Err(ScriptError::unsupported(\n'
        '                "optional chaining is not implemented",\n'
        '            ));\n'
        '        }\n'
        '        if p.eat(".") {',
        'Ordinary postfix/CallExpression route refuses the optional-chain boundary before conditional parsing.')
new_head = "fn new_members(p: &mut Parser<'_>, mut state: NewState) -> Result<Transition> {"
replace(P,
        new_head + '\n    loop {\n        if p.eat(".") {',
        new_head + '\n    loop {\n'
        '        if optional_chain_start(p) {\n'
        '            return Err(p.error("optional chain cannot be a new constructor"));\n'
        '        }\n'
        '        if p.eat(".") {',
        'Unparenthesized optional chain cannot serve as the constructor operand. Completed new C() returns to postfix, where its optional result chain is deferred.')
addition = (H / 'new-tests.rs').read_text()
assert addition.startswith('\n#[test]\n')
raw[T] += addition
edits.append({'path': T, 'append': addition, 'reason': 'Three producer-authored source-derived parser regression groups; independent public oracle unchanged.'})

forward = dict(before)
for edit in edits:
    path = edit['path']
    if 'append' in edit:
        forward[path] += edit['append']
    else:
        assert forward[path].count(edit['old']) == 1
        forward[path] = forward[path].replace(edit['old'], edit['new'], 1)
assert forward == raw
inverse = dict(raw)
for edit in reversed(edits):
    path = edit['path']
    if 'append' in edit:
        assert inverse[path].endswith(edit['append'])
        inverse[path] = inverse[path][:-len(edit['append'])]
    else:
        assert inverse[path].count(edit['new']) == 1
        inverse[path] = inverse[path].replace(edit['new'], edit['old'], 1)
assert inverse == before

for path in before:
    for directory, content in [('before', before[path]), ('raw', raw[path])]:
        target = H / directory / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content)
    target = H / 'diffs' / (path + '.diff')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_text(diff(before[path], raw[path], path))
write_json(H / 'edits.json', edits)
old_groups = re.findall(r'#\[test\]\s*fn (\w+)\(', before[T])
new_groups = re.findall(r'#\[test\]\s*fn (\w+)\(', addition)
assert len(old_groups) == 7 and len(new_groups) == 3
assert raw[T].startswith(before[T])
assert raw[P].split('pub(super) fn step')[0] == before[P].split('pub(super) fn step')[0]

write_json(H / 'spec-and-scope.json', {
    'status': 'Classification-only refusal; optional chaining remains unimplemented.',
    'primary_sources': [
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-lexical-grammar.html#sec-punctuators',
         'section': '12.8', 'retrieved': '2026-10-18 via web tool',
         'paraphrase': 'The optional-chaining punctuator consists of adjacent question mark and dot, with no decimal digit immediately after the dot. Thus ?.3 belongs to conditional-expression tokenization.'},
        {'url': 'https://tc39.es/ecma262/multipage/ecmascript-language-expressions.html#sec-left-hand-side-expressions',
         'section': '13.3 grammar', 'retrieved': '2026-10-18 via web tool',
         'paraphrase': 'OptionalExpression extends MemberExpression or CallExpression. SuperProperty is a MemberExpression, but bare super is neither. A constructor operand uses NewExpression/MemberExpression, so an unparenthesized optional constructor chain is forbidden. A completed new call or parenthesized construction can be the base of a later optional chain.'},
    ],
    'source_cause': 'The published lexer emits ? and . separately. Postfix previously stopped and AssignmentHead consumed ? as conditional punctuation, then Primary raised expected-expression on the dot.',
    'selected_change': 'Recognize adjacent ? plus . at the current postfix boundary and return Unsupported. Reject the same boundary in the unparenthesized constructor operand route as SyntaxError.',
    'preservation': [
        'Lexer, token budgets, AST, Parser/Frame/State representations, runtime, limits and existing helper tariffs remain unchanged.',
        'The existing lexer emits .3 as a Number; no dot-symbol match occurs. Existing conditional parsing and its AST are retained.',
        'Whitespace/comments between ? and . fail the source-offset adjacency check. Whitespace/comments before or after the complete ?. punctuator do not split it.',
        'Direct super?. and out-of-context super properties fail on existing super grammar/context paths before optional recognition.',
        'Independent public source/expectation bytes and all existing parser-test bodies remain unchanged.',
    ],
    'accounting': 'Constant bounded token checks inside the existing charged expression-dispatch path; no source scan, allocation, new storage or optional-chain tail traversal. Existing parser tariffs are unchanged.',
    'qualification': 'Refusal occurs at the recognized unsupported boundary; this is not a full parser or validator for an unimplemented optional-chain tail. Later malformed suffixes, optional assignment targets, optional private syntax and optional tagged-template restrictions are not newly parsed or certified by this patch.',
    'not_implemented': ['optional property access', 'optional calls', 'optional short circuit evaluation', 'optional assignment', 'new runtime operations'],
})
write_json(H / 'test-expectations.json', {
    'authorship': 'Producer-authored parser regressions derived from primary grammar and unchanged lexer/driver source; no project execution.',
    'new_groups': new_groups,
    'planned_parse_attempts': {'valid_unsupported_boundaries': 26, 'syntax_boundaries': 30, 'decimal_conditional_AST': 10, 'total': 66},
    'existing_groups_retained_exact': old_groups,
    'both_entry_strictness_modes': True,
    'independent_public_oracle_changed': False,
    'root_failure': binding(L / 'validation/candidate-object-msrv-1.log'),
    'retained_failure_summary': 'Root-owned first selected run: 47 passed, 1 failed; valid deferred object super result optional chaining was reported as SyntaxError. No result from this correction is claimed.',
})
read_only_paths = ['src/script.rs', 'src/script/tokens.rs', 'src/script/parser.rs',
                   'src/script/object_super_property_semantics_tests.rs']
preserved = []
for path in read_only_paths:
    data = (W / path).read_bytes()
    assert digest(data) == rows[path]['sha256'] and len(data) == rows[path]['bytes']
    preserved.append({'path': path, 'bytes': len(data), 'sha256': digest(data)})
write_json(H / 'source-checks.json', {
    'status': 'source-only checks passed',
    'candidate_inventory': binding(L / 'source-candidate-1.json'),
    'before_files_match_exact_candidate_inventory': True,
    'expression_before_also_matches_published_base': True,
    'exact_forward_replay': True, 'exact_inverse_to_candidate1': True,
    'unchanged_all_existing_test_bodies': True,
    'unchanged_expression_type_declarations': True,
    'preserved_inputs': preserved,
    'live_inputs_unchanged_after_authoring': all((W / p).read_text() == before[p] for p in before),
    'no_project_execution': True,
})
payloads = [{'path': path, 'before': binding(H / 'before' / path),
             'raw': binding(H / 'raw' / path), 'diff': binding(H / 'diffs' / (path + '.diff'))} for path in before]
artifacts = [binding(path) for path in sorted(H.rglob('*')) if path.is_file() and path.name != 'source-ready.json']
write_json(H / 'source-ready.json', {
    'status': 'source-ready external classification correction; unexecuted',
    'published_base': BASE, 'candidate_parent': binding(L / 'source-candidate-1.json'),
    'selection': binding(L / 'root/selection-1.json'),
    'retained_failure': binding(L / 'validation/candidate-object-msrv-1.log'),
    'payloads': payloads, 'artifacts': artifacts,
    'scope': 'Two bounded optional-punctuator checks plus one helper in expressions.rs; append three parser-only groups. No optional-chain implementation or independent oracle edits.',
    'new_groups': 3, 'planned_parse_attempts': 66,
    'no_live_edits': True, 'no_project_execution': True,
})
print(json.dumps(binding(H / 'source-ready.json'), indent=2))
