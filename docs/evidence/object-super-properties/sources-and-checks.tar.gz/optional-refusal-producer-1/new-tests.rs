
#[test]
fn optional_chain_parser_refuses_valid_postfix_boundaries_without_implementing_them() {
    for strict in [false, true] {
        for source in [
            "value?.property;",
            "value?.[key];",
            "value?.(argument);",
            "value.method()?.property;",
            "value /* before */ ?. /* after */ property;",
            "value\n?.property;",
            "new Constructor()?.property;",
            "(new Constructor)?.property;",
            "new (value?.Constructor)();",
            "({m(){return super.x?.y;}});",
            "({m(x=super.x?.y){}});",
            "({m(){return ()=>super[key]?.();}});",
            "class C extends Object {constructor(){super()?.x;}}",
        ] {
            let error = Parser::program_context(source, false, strict).unwrap_err();
            assert!(error.is_unsupported(), "strict={strict}, {source}: {error:?}");
            assert_eq!(error.message, "optional chaining is not implemented");
        }
    }
}

#[test]
fn optional_chain_parser_preserves_separated_tokens_super_context_and_new_restrictions() {
    for strict in [false, true] {
        for source in [
            "value ? .property : other;",
            "value?/* gap */.property:other;",
            "value?\n.property:other;",
            "value? .[key]:other;",
            "({m(){return super?.property;}});",
            "class C extends Object {constructor(){super?.property;}}",
            "({m(){return super?.[key];}});",
            "({m(){return super?.();}});",
            "super.x?.y;",
            "function f(){return super.x?.y;}",
            "new Constructor?.property;",
            "new Constructor?.(argument);",
            "({m(){return new super.x?.y;}});",
            "new new Constructor()?.property;",
            "({m(){return new super?.C;}});",
        ] {
            let error = Parser::program_context(source, false, strict).unwrap_err();
            assert!(error.is_parse_error(), "strict={strict}, {source}: {error:?}");
        }
    }
}

#[test]
fn optional_chain_parser_keeps_decimal_question_dot_as_conditional_ast() {
    for strict in [false, true] {
        for source in [
            "flag?.3:0;",
            "flag ? .3 : 0;",
            "flag?/* gap */.3:0;",
            "new Constructor?.3:0;",
        ] {
            let unit = Parser::program_context(source, false, strict).unwrap();
            let Expr::Conditional(_, yes, no) =
                unit.expr(statement_expr(&unit, unit.body[0]))
            else {
                panic!("strict={strict}, {source}: conditional expression");
            };
            assert!(matches!(unit.expr(*yes), Expr::Literal(Value::Number(value)) if *value == 0.3));
            assert!(matches!(unit.expr(*no), Expr::Literal(Value::Number(value)) if *value == 0.0));
        }
        let unit = Parser::program_context(
            "class C {m(){super.x?.3:0;}}",
            false,
            strict,
        )
        .unwrap();
        let Expr::Conditional(condition, yes, no) =
            unit.expr(statement_expr(&unit, method_body(&unit)[0]))
        else {
            panic!("super property followed by a decimal conditional");
        };
        property_key(&unit, *condition);
        assert!(matches!(unit.expr(*yes), Expr::Literal(Value::Number(value)) if *value == 0.3));
        assert!(matches!(unit.expr(*no), Expr::Literal(Value::Number(value)) if *value == 0.0));
    }
}
