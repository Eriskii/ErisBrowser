"""Correct one superseded preparation binding; preserve all document bytes."""
from pathlib import Path
import json,hashlib
P=Path(__file__).resolve().parent;L=P.parent;D=L/'documentation-3';D2=L/'documentation-2'
def bind(p):
 b=p.read_bytes();return dict(path=str(p),bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def put(n,v):(P/n).write_text(json.dumps(v,indent=2)+'\n')
def copy(source,target):target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(source.read_bytes())
old=json.loads((D/'source-ready.json').read_bytes())
for row in old['artifacts']:
 path=D/row['path'];assert dict(bind(path),path=row['path'])==row
rows=[]
for row in old['files']:
 rel=row['relative_path'];raw=P/'raw'/rel;copy(Path(row['raw']['path']),raw)
 before=P/'before'/rel
 if row['before']:copy(Path(row['before']['path']),before)
 diff=P/'diffs'/(rel.replace('/','__')+'.diff');copy(Path(row['diff']['path']),diff)
 rows.append(dict(relative_path=rel,before=bind(before) if row['before'] else None,raw=bind(raw),diff=bind(diff),same_as_documentation3=True))
copy(D/'compatibility-preface.md',P/'compatibility-preface.md')
copy(D/'links.json',P/'links.json')
claims=json.loads((D2/'claims-and-checks.json').read_bytes())
path=D2/'raw/docs/object-super-properties.md';actual=bind(path)
old_entries=[r for r in claims['verified_evidence_bindings'] if r['path']==str(path)]
assert len(old_entries)==1 and old_entries[0]!=actual
stale=old_entries[0]
claims['verified_evidence_bindings']=[actual if r['path']==str(path) else r for r in claims['verified_evidence_bindings']]
for r in claims['verified_evidence_bindings']:assert bind(Path(r['path']))==r
claims['status']='Final six-document claims checked against actual sealed evidence, with one preparation-binding correction; independent peer pending.'
claims['metadata_correction']=dict(
 original_claims=bind(D2/'claims-and-checks.json'),
 previously_recorded_preparation_bytes=stale['bytes'],previously_recorded_preparation_sha256=stale['sha256'],
 corrected_final_binding=actual,
 cause='The earlier checker recorded the prepared chapter before appending the final validation tail, then inadvertently retained that old hash in the current verified-evidence list. Source-ready raw bindings and all prose were already correct.',
 scope='Exactly one claims-list binding replaced; no document/source/test/report/outcome bytes changed. Historical preparation and superseded holds remain intact.')
claims['compatibility_addendum']=dict(
 previous_hold=bind(D/'source-ready.json'),preface=bind(P/'compatibility-preface.md'),
 original_body_exact=True,prior_five_document_bytes_exact=True,
 current_counts=old['final_counts'],links=bind(P/'links.json'))
# Independently recheck the complete compatibility inverse with the exact heading.
a=(P/'before/docs/COMPATIBILITY.md').read_bytes();b=(P/'raw/docs/COMPATIBILITY.md').read_bytes();prefix=(P/'compatibility-preface.md').read_bytes();heading=b'# Compatibility status\n\n'
assert a.startswith(heading) and b==heading+prefix+a[len(heading):]
claims['links']=bind(P/'links.json')
put('claims-and-checks.json',claims)
put('metadata-correction.json',dict(status='Corrected current binding; all six raw documents unchanged.',
 previous_hold=bind(D/'source-ready.json'),previous_complete_claims=bind(D2/'claims-and-checks.json'),
 corrected_complete_claims=bind(P/'claims-and-checks.json'),
 correction=claims['metadata_correction'],raw_files_exact_to_documentation3=6,
 compatibility_inverse=True,project_execution=False,live_edits=False,previous_holds_modified=False))
# Every current binding in the corrected claims is now exact. Historical stale
# numbers are explicitly named as superseded values, not live file bindings.
count=0
def verify(v):
 global count
 if isinstance(v,dict):
  if {'path','bytes','sha256'}<=v.keys() and isinstance(v['path'],str) and v['path'].startswith('/'):
   assert bind(Path(v['path']))=={k:v[k] for k in ['path','bytes','sha256']};count+=1
  for x in v.values():verify(x)
 elif isinstance(v,list):
  for x in v:verify(x)
verify(claims)
put('final-checks.json',dict(status='clear',current_claim_binding_occurrences_verified=count,
 six_raw_files_same_as_documentation3=True,complete_compatibility_body_inverse=True,
 source_inventory=old['source_inventory'],final_ledger=old['final_ledger'],
 no_document_or_outcome_change=True,project_execution=False,live_edits=False))
artifacts=[dict(bind(p),path=str(p.relative_to(P))) for p in sorted(P.rglob('*')) if p.is_file() and p.name!='source-ready.json']
put('source-ready.json',dict(schema=1,status='Sealed final six-file documentation hold with corrected complete claim bindings; independent peer pending.',
 base=old['base'],supersedes=bind(D/'source-ready.json'),supersedes_draft=old['supersedes_draft'],
 final_ledger=old['final_ledger'],source_inventory=old['source_inventory'],source_review=old['source_review'],
 files=rows,path_count=6,claims=bind(P/'claims-and-checks.json'),links=bind(P/'links.json'),
 metadata_correction=bind(P/'metadata-correction.json'),checks=bind(P/'final-checks.json'),artifacts=artifacts,
 final_counts=old['final_counts'],historical_text_preserved=True,all_six_previous_raw_files_exact=True,
 previous_holds_unchanged=True,project_execution=False,live_edits=False))
print(json.dumps(bind(P/'source-ready.json')))
