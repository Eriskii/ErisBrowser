"""Static documentation provenance and claim checks; no project execution."""
from pathlib import Path
import difflib
import hashlib
import json
import subprocess

P = Path('/tmp/eris-bootstrap-budget-plan-1')
D = P / 'documentation-1'
H = P / 'documentation-review-1'
W = P / 'worktree'

def bind(path):
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}

def verify(value):
    if isinstance(value, dict):
        if 'path' in value and 'sha256' in value:
            actual = bind(Path(value['path']))
            assert actual['sha256'] == value['sha256']
            if 'bytes' in value:
                assert actual['bytes'] == value['bytes']
        for item in value.values():
            verify(item)
    elif isinstance(value, list):
        for item in value:
            verify(item)

assert not (H / 'review.json').exists()
assert bind(D / 'source-ready.json')['sha256'] == '4be54ac651dd59bf87f05468c650b99e2a2c04ad5ac4643f012ead1fee5c98cc'
hold = json.loads((D / 'source-ready.json').read_text())
verify(hold)
assert len(hold['files']) == 7
base = hold['published_base']
assert base == '15226307b153da0857f80486d5f23c375b6b2add'
files = {}
for row in hold['files']:
    relative = row['relative']
    before = Path(row['before']['path']).read_bytes() if row['before'] else b''
    raw = Path(row['raw']['path']).read_bytes()
    if row['before']:
        assert before == subprocess.check_output(['git', '-C', str(W), 'show', base + ':' + relative])
    expected = ''.join(difflib.unified_diff(before.decode().splitlines(keepends=True), raw.decode().splitlines(keepends=True), fromfile='a/' + relative, tofile='b/' + relative))
    assert Path(row['diff']['path']).read_text() == expected
    assert 'PENDING' not in raw.decode()
    files[relative] = (before.decode(), raw.decode())

assert set(files) == {'README.md', 'docs/COMPATIBILITY.md', 'docs/ROADMAP.md', 'docs/SECURITY.md', 'docs/runtime-budget-boundary.md', 'docs/VALIDATION.md', 'docs/bootstrap-budget.md'}
before, raw = files['docs/VALIDATION.md']
header = '# Validation record\n'
assert before.startswith(header) and raw.startswith(header)
assert raw.endswith(before[len(header):])
before, raw = files['docs/runtime-budget-boundary.md']
suffix = 'This makes the boundary explicit before adding DOM interface metadata.'
assert before.split(suffix, 1)[1] == raw.split(suffix, 1)[1]
assert '## Original boundary checkpoint' in raw

validation_path = P / 'validation-review-1/final-review.json'
assert bind(validation_path)['sha256'] == 'a5968fb2a34139bc5397e3b6c71c59039da4e0b1ccda9ac0de9c2c7cd276fa85'
validation = json.loads(validation_path.read_text())
assert validation['status'] == 'clear' and not validation['findings']
verify(validation['final_ledger'])
chapter = files['docs/bootstrap-budget.md'][1]
for literal in ['1,000,000', '100,000', '8 MiB', '99,694', '900,306', '1,744,317', '752', '299', '25 prototype', '212 global', '**53 tests**', '3,132', '3,486', '52 result', '1,050', '348', 'zero regressions', 'failed\nand unsupported', 'monotonic start', 'not reached', 'ten files', 'Twelve existing groups', 'evidence/bootstrap-budget/manifest.json', 'evidence/bootstrap-budget/sources-and-checks.tar.gz']:
    assert literal in chapter, literal
assert validation['observed_startup']['accounted_allocation'] == 1744317
assert validation['exact_cases'] == 1050 and validation['exact_controls'] == 348
assert [row['passed'] for row in validation['full_suites']] == [3132, 3486]

review = {
    'status': 'clear',
    'scope': 'Independent source-only review of seven sealed documentation changes against the completed bootstrap validation; no live edits or project execution.',
    'documentation_hold': bind(D / 'source-ready.json'),
    'validation_peer': bind(validation_path),
    'final_ledger': bind(P / 'root/final-validation.json'),
    'source_final': bind(P / 'source-final.json'),
    'reviewed_paths': [row['relative'] for row in hold['files']],
    'checks': [
        'All before/raw/diff hashes verify; six before files independently join published15226307 Git blobs and all seven diffs reconstruct exactly.',
        'The finite1000000 trusted initialization cap is distinguished from unchanged100000 author work, cumulative8MiB allocation, success-only public reset and unchanged operation costs.',
        'Parent first raw-allowance failure, later unreached debit checks, candidate53 focused passes and the ten-file/twelve-group accounting migration scope match the frozen control and completed evidence.',
        'Recorded99694 consumption,900306 remaining and1744317 accounted bytes with unchanged752/299/25/212 counts match the reviewed source/logs; no CPU/RSS saving is claimed.',
        'Complete3132/3486 suites,52 result rows each, exact old rosters plus one new group/no renames, strict all-target Clippy and formatting claims match actual receipts.',
        'Rust1.88 release and full1050 case/348 harness array preservation are accurate; existing failed/unsupported outcomes remain explicit, with no standalone Python rerun or new profile/API outcome claim.',
        'The existing monotonic timestamp qualifies the former no-host-reads wording; supplied DateHost discovery, author callbacks and document execution remain outside initialization.',
        'VALIDATION historical suffix is byte-exact; runtime-budget-boundary historical narrative after its updated opening is exact and explicitly labeled. README/ROADMAP306 is attributed to its original checkpoint.',
        'SECURITY updates the representative cap and preserves the separate author/heap boundary without adding a production-security guarantee. AggregateError/Promise.any remain separate future work.',
        'Evidence links identify the root-owned intended publication paths. This review does not assert archive contents or remote publication success.'
    ],
    'findings': [],
    'reviewer_script': bind(Path(__file__))
}
(H / 'review.json').write_text(json.dumps(review, indent=2) + '\n')
print(json.dumps(bind(H / 'review.json')))
