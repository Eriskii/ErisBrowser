from pathlib import Path
import difflib, hashlib, json, re, subprocess
P = Path('/tmp/eris-bootstrap-budget-plan-1')
W = P / 'worktree'
H = P / 'production-1'
BASE = '15226307b153da0857f80486d5f23c375b6b2add'
def sha(b):
    if isinstance(b, str): b = b.encode()
    return hashlib.sha256(b).hexdigest()
def bind(p):
    b = p.read_bytes()
    return dict(path=str(p), bytes=len(b), sha256=sha(b))
def dump(name, obj):
    p = H / name
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(obj, indent=2) + '\n')
def span(s, name):
    lines = s.splitlines(keepends=True)
    starts = [(i, re.search(r'\bfn\s+(\w+)', line).group(1)) for i, line in enumerate(lines)
              if re.match(r'\s*(?:pub(?:\([^)]*\))?\s+)?(?:async\s+)?fn\s+\w+', line)]
    matches = [(idx, i) for idx, (i, n) in enumerate(starts) if n == name]
    assert len(matches) == 1, (name, matches)
    idx, start = matches[0]
    end = starts[idx + 1][0] if idx + 1 < len(starts) else len(lines)
    return sum(map(len, lines[:start])), sum(map(len, lines[:end]))
selection = json.loads((P/'root/selection-1.json').read_text())
assert selection['published_base'] == BASE
parent = json.loads((P/'source-parent.json').read_text())
assert parent['base'] == BASE
inventory = parent['source_sha256']
census = json.loads((P/'migration-census.json').read_text())
assert census['files'] == 10 and census['groups'] == 12
source_bindings = json.loads((P/'source-bindings.json').read_text())
for row in source_bindings['files']:
    b = Path(row['snapshot']['path']).read_bytes()
    assert sha(b) == row['snapshot']['sha256'] == inventory[row['relative']]
    assert b == subprocess.check_output(['git', 'show', BASE + ':' + row['relative']], cwd=W)
paths = ['src/script.rs'] + sorted({row['path'] for row in census['rows']})
assert len(paths) == 11
before, raw = {}, {}
for rel in paths:
    b = (P/'source-snapshots'/rel).read_bytes()
    assert sha(b) == inventory[rel]
    before[rel] = b.decode()
    raw[rel] = b.decode()
edit_rows = []
# Exactly two selected production sites. The success-only public reset is untouched.
const_before = 'const MAX_STEPS: usize = 100_000;\n'
const_after = (const_before + '// Fixed intrinsic initialization has a separate finite work allowance.\n'
               '// Successful public construction resets author work to MAX_STEPS.\n'
               'const BOOTSTRAP_STEPS: usize = 1_000_000;\n')
assert raw['src/script.rs'].count(const_before) == 1
raw['src/script.rs'] = raw['src/script.rs'].replace(const_before, const_after, 1)
edit_rows.append(dict(path='src/script.rs', scope='private constants', before=const_before, after=const_after))
a, z = span(raw['src/script.rs'], 'uninitialized')
old = raw['src/script.rs'][a:z]
assert old.count('            steps: MAX_STEPS,\n') == 1
new = old.replace('            steps: MAX_STEPS,\n', '            steps: BOOTSTRAP_STEPS,\n', 1)
raw['src/script.rs'] = raw['src/script.rs'][:a] + new + raw['src/script.rs'][z:]
edit_rows.append(dict(path='src/script.rs', scope='Runtime::uninitialized', before='            steps: MAX_STEPS,\n', after='            steps: BOOTSTRAP_STEPS,\n', before_group_sha256=sha(old), after_group_sha256=sha(new)))
migration_rows = []
for row in census['rows']:
    rel, group = row['path'], row['group']
    a, z = span(raw[rel], group)
    old = raw[rel][a:z]
    assert sha(old) == row['current_group_source_sha256'], (rel, group, sha(old))
    new = old
    edits = []
    for idx, edit in enumerate(row['changes']):
        count = new.count(edit['before'])
        # This first PI fragment intentionally occurs in diagnostic and assert.
        first_pi = group == 'startup_headroom_raw_observation_precedes_the_frozen_99694_work_witness' and idx == 0
        assert count == (2 if first_pi else 1), (rel, group, edit, count)
        new = new.replace(edit['before'], edit['after'], 1)
        edits.append(dict(**edit, replacement_count=1, matches_before_step=count, selection='first occurrence' if first_pi else 'unique occurrence'))
    comments = []
    if rel == 'src/script/typed_array/tests.rs':
        needle = '    assert_eq!(\n        runtime.steps,\n'
        replacement = ('    // The cumulative remainder below starts from MAX_STEPS; only its\n'
                       '    // allowance origin changes, not the installation work or heap ledger.\n' + needle)
        assert new.count(needle) == 1
        new = new.replace(needle, replacement, 1)
        comments.append(dict(before=needle, after=replacement))
    if rel == 'src/script/test262_host/quota_tests.rs':
        needle = '    assert_eq!(runtime.steps, 900_306);\n'
        replacement = ('    // This is the raw startup remainder; host and author limits stay unchanged.\n' + needle)
        assert new.count(needle) == 1
        new = new.replace(needle, replacement, 1)
        comments.append(dict(before=needle, after=replacement))
    raw[rel] = raw[rel][:a] + new + raw[rel][z:]
    migration_rows.append(dict(path=rel, group=group, before_group_sha256=sha(old), after_group_sha256=sha(new), edits=edits, comment_edits=comments, reason=row['reason']))
# Independent inverse through held full group replacements preserves every other byte.
recovered = dict(raw)
for row in reversed(migration_rows):
    rel, group = row['path'], row['group']
    a, z = span(recovered[rel], group)
    assert sha(recovered[rel][a:z]) == row['after_group_sha256']
    ba, bz = span(before[rel], group)
    recovered[rel] = recovered[rel][:a] + before[rel][ba:bz] + recovered[rel][z:]
assert all(recovered[p] == before[p] for p in paths if p != 'src/script.rs')
recovered['src/script.rs'] = recovered['src/script.rs'].replace(const_after, const_before, 1)
a,z = span(recovered['src/script.rs'], 'uninitialized')
block = recovered['src/script.rs'][a:z]
assert block.count('            steps: BOOTSTRAP_STEPS,\n') == 1
block = block.replace('            steps: BOOTSTRAP_STEPS,\n','            steps: MAX_STEPS,\n',1)
recovered['src/script.rs'] = recovered['src/script.rs'][:a] + block + recovered['src/script.rs'][z:]
assert recovered['src/script.rs'] == before['src/script.rs']
assert raw['src/script.rs'].count('BOOTSTRAP_STEPS') == 2
for method in ['try_new', 'initialize_bootstrap', 'work']:
    a,z = span(before['src/script.rs'], method); x,y = span(raw['src/script.rs'], method)
    assert before['src/script.rs'][a:z] == raw['src/script.rs'][x:y], method
# All literal strings, including raw JS strings and diagnostic strings, remain unchanged.
string_re = re.compile(r'r(#+)?".*?"\1|"(?:\\.|[^"\\])*"', re.S)
for rel in paths:
    assert string_re.findall(before[rel]) == string_re.findall(raw[rel]), rel
    # Also compare full standard-string matches; raw strings unchanged by exact inverse scope.
    assert re.findall(r'"(?:\\.|[^"\\])*"', before[rel], re.S) == re.findall(r'"(?:\\.|[^"\\])*"', raw[rel], re.S), rel
# Explicit operation allowances remain outside the authored paths and byte-exact.
guards = []
for row in census['unchanged_explicit_allowances']:
    rel = row['path']; assert rel not in paths
    s = (P/'source-snapshots'/rel).read_text()
    a,z = span(s, row['group'])
    assert sha(s[a:z]) == row['source_sha256']
    assert sha(s) == inventory[rel]
    guards.append(dict(relative=rel, group=row['group'], source=bind(P/'source-snapshots'/rel), group_sha256=sha(s[a:z]), disposition='unchanged; not authored'))
# No test declaration or registration was added, removed or renamed.
for rel in paths:
    assert re.findall(r'(?m)^\s*fn\s+(\w+)', before[rel]) == re.findall(r'(?m)^\s*fn\s+(\w+)', raw[rel]), rel
    assert before[rel].count('#[test]') == raw[rel].count('#[test]'), rel
files=[]
for rel in paths:
    bp, rp = H/'before'/rel, H/'raw'/rel
    dp = H/'diffs'/(rel.replace('/', '__')+'.patch')
    for p in [bp,rp,dp]: p.parent.mkdir(parents=True, exist_ok=True)
    bp.write_text(before[rel]); rp.write_text(raw[rel])
    diff=''.join(difflib.unified_diff(before[rel].splitlines(keepends=True), raw[rel].splitlines(keepends=True), fromfile='a/'+rel, tofile='b/'+rel))
    assert diff
    dp.write_text(diff)
    files.append(dict(relative=rel, new=False, before=bind(bp), raw=bind(rp), diff=bind(dp), published_sha256=inventory[rel]))
dump('edit-manifest.json',dict(production_paths=1, production_sites=2, migration_paths=10, migration_groups=12, new_test_groups=0, production_edits=edit_rows, migration_edits=migration_rows, unchanged_explicit_matrices=guards, composition='The separate parent-controls-1 append must be composed onto this migrated bootstrap_tests.rs using its unchanged parent prefix. This hold intentionally contains no new test or registration.'))
dump('verification.json',dict(kind='static source and standard-library text/hash checks only', published_base=BASE, published_snapshot_joins=len(source_bindings['files']), paths=11, migration_groups=12, findings=[], checks=['Every before file joins the frozen source snapshot, published1675-input inventory and published Git object.', 'Ordered scoped replacements exactly implement all12 frozen migration rows, including PI first-occurrence diagnostic selection.', 'Full group inverse plus the two production inverses recover every before file byte-exact.', 'try_new, initialize_bootstrap and work bodies remain byte-exact; exactly two BOOTSTRAP_STEPS references exist in production source.', 'Every test name, test declaration count and string literal is retained; no new module or registration.', 'All three explicit99693/99694/100000 matrices are byte-exact and outside this hold.', 'Heap formula and allocated fields remain exact; only raw allowance-origin assertions migrate.'], observed_execution='None. No project module was imported or executed, no formatter/build/test was run, and no live worktree file was written.', expected_arithmetic=dict(startup_cap=1000000,consumed_work=99694,raw_remaining=900306,public_remaining=100000,heap_delta=0)))
notes='''This is the selected source-only production and existing-test migration hold on published 15226307b153da0857f80486d5f23c375b6b2add. It changes one private constant/initial field and twelve existing groups in ten test files. All operation charges, heap expressions, public success reset, fields, identities and explicit injected work matrices are retained. Two added test comments explain the allowance origin; the twelve frozen edit rows remain exact. The separate one-group parent control is not included. Expected raw remaining work is1,000,000−99,694=900,306; public successful construction still resets100,000. These are selected source-derived expectations, not candidate observations. No live writes or project execution occurred.\n'''
(H/'notes.txt').write_text(notes)
dump('source-ready.json',dict(status='source_ready_unexecuted',published_base=BASE,scope='One production path plus ten existing test paths/twelve migrated groups. No new control, registration, Runtime field or operation-budget change.',files=files,source_bindings=[bind(P/p) for p in ['source-ready.json','source-parent.json','source-bindings.json','migration-census.json','raw-controls-census.json','root/selection-1.json','html-census-review-1/review.json','public-entry-audit-1/review.json']],artifacts=[bind(H/p) for p in ['edit-manifest.json','verification.json','notes.txt','author.py']],selection=dict(production_paths=1,production_sites=2,migration_paths=10,migration_groups=12,new_test_groups=0),execution='None; external source authoring and read-only Git/stdlib verification only.'))
print(json.dumps(bind(H/'source-ready.json')))
