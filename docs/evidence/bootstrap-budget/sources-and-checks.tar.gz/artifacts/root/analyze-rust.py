import hashlib,json,re
from pathlib import Path
A=Path(__file__).resolve().parents[1]
def bind(p):
 b=p.read_bytes();return {'path':str(p),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()}
def parse(directory,label):
 receipt=directory/(label+'.json');r=json.loads(receipt.read_text());log=directory/(label+'.log');text=log.read_text()
 assert r['exit']==0 and r['sha256']==bind(log)['sha256']
 rows=[tuple(map(int,m)) for m in re.findall(r'test result: \w+\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out',text)]
 totals=[sum(row[i] for row in rows) for i in range(5)]
 assert totals[1:]==[0,0,0,0],(label,totals)
 harness=None;names=[]
 for line in text.splitlines():
  match=re.match(r'\s+Running (?:unittests )?(\S+) \(',line)
  if match:harness=match[1]
  if 'Doc-tests ' in line:harness='Doc-tests '+line.split('Doc-tests ',1)[1]
  result=re.match(r'^test (.+) \.\.\. ok$',line)
  if result:
   assert harness is not None
   names.append(harness+'::'+result[1])
 assert len(names)==len(set(names))==totals[0],(label,len(names),totals)
 return {'receipt':bind(receipt),'log':bind(log),'result_rows':len(rows),'totals':totals,'passed_names':sorted(names)}
new=['src/lib.rs::script::bootstrap_tests::bootstrap_raw_allowance_is_separate_and_still_finite']
comparisons=[]
for label,oldlabel,expected in [('default-full-1','default-full-2',3132),('host-vulkan-full-1','host-vulkan-full-1',3486)]:
 old=parse(A/'rust-parent',oldlabel);current=parse(A/'validation',label)
 assert current['totals']==[expected,0,0,0,0]
 assert set(current['passed_names'])==set(old['passed_names'])|set(new)
 assert not set(old['passed_names'])&set(new)
 comparisons.append({'current':current,'previous':old,'exact_old_roster_plus_new':True})
r={'status':'complete','new_test_groups':1,'new_names':new,'selected_existing_test_renames':{},'comparisons':comparisons}
(A/'root/rust-validation.json').write_text(json.dumps(r,indent=2)+'\n')
print('All3132 default and3486 host/Vulkan tests pass; exact old rosters plus1 new group.')
