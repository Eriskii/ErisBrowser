import hashlib,json,subprocess,tarfile
from pathlib import Path
A=Path(__file__).resolve().parents[1];W=A/'worktree';E=W/'docs/evidence/bootstrap-budget'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(n):return json.loads((A/n).read_text())
s=read('source-final.json')['source_sha256'];parent=read('source-parent.json')['source_sha256']
for p,h in s.items():assert sha((W/p).read_bytes())==h,p
m=json.loads((E/'manifest.json').read_text());P=E/m['archive']['path'];assert sha(P.read_bytes())==m['archive']['sha256']
with tarfile.open(P,'r:gz') as archive:
 assert archive.getnames()==[r['path'] for r in m['members']]
 for row in m['members']:
  x=archive.getmember(row['path']);assert x.isfile() and not x.issym() and not x.islnk();b=archive.extractfile(x).read();assert len(b)==row['bytes'] and sha(b)==row['sha256'];assert Path(row['origin']).read_bytes()==b,row['origin']
expected={p for p,h in s.items() if parent.get(p)!=h}
for row in read('documentation-1/source-ready.json')['files']:expected.add(row['relative'])
expected.update(['docs/evidence/bootstrap-budget/manifest.json','docs/evidence/bootstrap-budget/sources-and-checks.tar.gz']);assert len(expected)==20
r=subprocess.run(['git','status','--porcelain=v1','--untracked-files=all'],cwd=W,capture_output=True,text=True,check=True)
actual={line[3:] for line in r.stdout.splitlines()};assert actual==expected,(actual-expected,expected-actual)
subprocess.run(['git','diff','--check'],cwd=W,check=True)
receipt={'status':'verified','archive_sha256':m['archive']['sha256'],'archive_bytes':m['archive']['bytes'],'archive_members':len(m['members']),'source_paths':11,'documentation_paths':7,'evidence_paths':2,'expected_paths':sorted(expected),'all_archive_origins_exact':True,'source_inventory_exact':True}
(A/'root/publication-verification.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
